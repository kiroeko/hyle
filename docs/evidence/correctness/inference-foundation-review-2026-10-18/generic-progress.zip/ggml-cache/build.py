"""Reproduce only the two changed native members against an audited IQ1 cache.

No vendor checkout, existing library or product file is modified.
"""
from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
import time
import types

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
REFERENCE = ROOT / '.scratch/validation/cuda-final-u3-delivery/reference-windows'
RAW = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
REVISION = '7f6c9107235868d63892d9117a293d1007ba3471'
MSVC = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def git(path):
    return subprocess.run(['git', 'show', REVISION + ':' + path], cwd=ROOT,
                          check=True, capture_output=True).stdout


class MemoryText:
    def __init__(self, value=''):
        self.value = value.decode() if isinstance(value, bytes) else value

    def read_text(self, *args, **kwargs):
        return self.value

    def write_text(self, value, *args, **kwargs):
        self.value = value


def generate(historical=False):
    read = lambda p: git(p) if historical else (ROOT / p).read_bytes()

    def module(path):
        result = types.ModuleType('in_memory_source_preparation')
        exec(compile(read(path), path, 'exec'), result.__dict__)
        return result

    mixed = MemoryText()
    module('src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').derive(
        RAW, MemoryText(read('third_party/ggml_runtime/patches.json')),
        MemoryText(read('third_party/ggml_cpu_runtime/patches.json')), mixed)
    cuda = MemoryText()
    module('src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').derive(
        RAW, mixed, MemoryText(read('third_party/ggml_cuda_runtime/patches.json')),
        MemoryText(read('third_party/ggml_cuda_runtime/iq1-patches.json')), cuda)
    manifest = json.loads(cuda.value)
    contents = {}
    for item in manifest['files']:
        data = (RAW / item['path']).read_bytes().replace(b'\r\n', b'\n')
        assert sha(data) == item['before_sha256'], item['path']
        for edit in item['edits']:
            old, new = edit['before'].encode(), edit['after'].encode()
            assert data.count(old) == 1, item['path']
            data = data.replace(old, new, 1)
        assert sha(data) == item['after_sha256'], item['path']
        contents[item['path']] = data
    lock = {item['name']: item for item in json.loads(read('cmake/HyleDependencyLock.json'))['dependencies']}
    seed = (lock['ggml_runtime_patches']['vendored']['tree_sha256'] +
            lock['ggml_cpu_runtime_patches']['vendored']['tree_sha256'] +
            sha(read('src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py')) +
            sha(read('src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py')) +
            lock['ggml_cuda_runtime_patches']['vendored']['tree_sha256'])
    return contents, manifest, sha(seed.encode())[:16]


def arguments(command):
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    count = ctypes.c_int()
    pointer = shell.CommandLineToArgvW(command, ctypes.byref(count))
    try:
        return [pointer[index] for index in range(count.value)]
    finally:
        kernel.LocalFree(pointer)


def audit_and_prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    current, manifest, current_id = generate()
    before, _, historical_id = generate(True)
    identity = json.loads((REFERENCE / 'identity.json').read_text())
    assert historical_id == identity['source_id'] == 'f99368c68335266b'
    files = []
    for name, expected in identity['files'].items():
        path = REFERENCE / name
        actual = sha(path.read_bytes())
        assert actual == expected, name
        row = dict(path=str(path), bytes=path.stat().st_size, sha256=actual)
        if name.startswith(('include/', 'src/')):
            expected_current = current.get(name, (RAW / name).read_bytes().replace(b'\r\n', b'\n'))
            assert sha(expected_current) == actual, name
            row['current_locked_source_match'] = True
        files.append(row)
    changes = []
    for name in sorted(set(before) | set(current)):
        raw = (RAW / name).read_bytes().replace(b'\r\n', b'\n')
        old, new = before.get(name, raw), current.get(name, raw)
        if old != new:
            changes.append(dict(path=name, before_sha256=sha(old), current_sha256=sha(new)))
    assert [row['path'] for row in changes] == [
        'src/ggml-alloc.c', 'src/ggml-cpu/ops.cpp', 'src/ggml-cuda/ggml-cuda.cu']
    bridges = []
    for name in ['src/compute_provider_ggml_cuda/native_bridge.h',
                 'src/compute_provider_ggml_cuda/native_bridge_impl.h']:
        data = (ROOT / name).read_bytes()
        assert data == git(name), name
        bridges.append(dict(path=name, sha256=sha(data), historical_match=True))
    source_dir = OUT / 'source'
    source_dir.mkdir(exist_ok=True)
    for name in ['src/ggml-cuda/ggml-cuda.cu', 'src/ggml-alloc.c']:
        (source_dir / Path(name).name).write_bytes(current[name])
    save('cache-audit.json', dict(
        scope='Read-only audited existing IQ1 numerical archive; exactly two generated source overlays',
        original_pin=manifest['upstream_revision'], borrowed_iq1=manifest['borrowed_iq1_revision'],
        reference_candidate=REVISION, reference_source_id=historical_id,
        current_source_id=current_id, changes=changes, reference_files=files, bridge_headers=bridges,
        cpu_ops_boundary='CUDA-only closure contains no ggml CPU backend; changed CPU ops are not linked',
        main_boundary='ggml-cuda.cu includes one existing batched-pointer kernel; compiled as one original NVCC TU, not advertised as pure host C++',
        excluded_legacy='Old source-4e1a7b2f39afe15d/header/lib and old ggml-cuda.strict.obj are not used as current runtime'))
    save('current-native-manifest.json', manifest)
    recipes = []
    original = json.loads((ROOT / '.scratch/perf-review-2026-10-18/ggml-attention-provider/native-overlay-compile-command.json').read_text())
    nvcc = arguments(original)
    native = []
    for value in nvcc:
        lower = value.lower()
        if lower.startswith('-i') and 'source-4e1a7b2f39afe15d' in lower:
            if 'src\\..\\include' in lower:
                value = '-I' + str(REFERENCE / 'include')
            elif lower.endswith('src\\ggml-cuda'):
                value = '-I' + str(REFERENCE / 'src/ggml-cuda')
            else:
                value = '-I' + str(REFERENCE / 'src')
        elif lower.endswith('.cu'):
            value = str(source_dir / 'ggml-cuda.cu')
        elif lower.endswith('ggml-cuda.strict.obj.d'):
            value = str(OUT / 'ggml-cuda.obj.d')
        elif lower.endswith('ggml-cuda.strict.obj'):
            value = str(OUT / 'ggml-cuda.obj')
        elif lower.startswith('-xcompiler=-fd'):
            value = '-Xcompiler=-Fd' + str(OUT / 'ggml-cuda.pdb') + ',-FS'
        native.append(value)
    assert not any('source-4e1a7b2f39afe15d' in x or 'ggml-cuda.strict' in x for x in native)
    recipes.append(dict(tag='native-main', source='source/ggml-cuda.cu', object=str(OUT / 'ggml-cuda.obj'), command=native))
    database = json.loads((ROOT / '.scratch/legacy-root/hyle-scratch/ggml-native-static/compile_commands.json').read_text())
    alloc = arguments(next(x['command'] for x in database if Path(x['file']).name == 'ggml-alloc.c'))
    compiler = []
    for value in alloc:
        lower = value.lower()
        if lower.startswith('-i'):
            if 'src\\..\\include' in lower:
                value = '-I' + str(REFERENCE / 'include')
            else:
                value = '-I' + str(REFERENCE / 'src')
        elif lower.startswith('/fo'):
            value = '/Fo' + str(OUT / 'ggml-alloc.obj')
        elif lower.startswith('/fd'):
            value = '/Fd' + str(OUT / 'ggml-alloc.pdb')
        elif lower.endswith('ggml-alloc.c'):
            value = str(source_dir / 'ggml-alloc.c')
        compiler.append(value)
    assert not any('C:\\hyle-scratch' in x for x in compiler)
    recipes.append(dict(tag='native-allocator', source='source/ggml-alloc.c', object=str(OUT / 'ggml-alloc.obj'), command=compiler))
    save('compile-recipes.json', recipes)
    return recipes


def run_recipes(recipes):
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    from hyle_support import read_cache
    env = windows_compiler_environment(read_cache(ROOT / '.scratch/build-compute-v2-dev'))
    env['VSLANG'] = '1033'
    commands = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []
    for recipe in recipes:
        source = OUT / recipe['source']
        before_sha = sha(source.read_bytes())
        stem = f'{len(commands) + 1:02d}-' + recipe['tag']
        print('START', stem, flush=True)
        start = time.monotonic()
        with (OUT / (stem + '.stdout.log')).open('wb') as stdout, (OUT / (stem + '.stderr.log')).open('wb') as stderr:
            process = subprocess.run(recipe['command'], cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        row = dict(tag=recipe['tag'], command=recipe['command'], exit=process.returncode,
                   seconds=time.monotonic()-start, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log',
                   source_sha256=before_sha, source_unchanged=before_sha == sha(source.read_bytes()))
        if Path(recipe['object']).exists():
            row.update(object=recipe['object'], object_sha256=sha(Path(recipe['object']).read_bytes()), object_bytes=Path(recipe['object']).stat().st_size)
        commands.append(row)
        save('commands.json', commands)
        print('END', stem, process.returncode, row['seconds'], flush=True)
        if process.returncode:
            print((OUT / row['stdout']).read_text(errors='replace')[-8000:])
            print((OUT / row['stderr']).read_text(errors='replace')[-8000:])
            raise SystemExit(process.returncode)


def check_member_symbols():
    dump = MSVC / 'dumpbin.exe'
    checks = []
    for library, object_name, required in [
        ('ggml-cuda.lib', 'ggml-cuda.obj', '?root_stream@bridge@ggml_cuda@compute@hyle@@YAPEAUCUstream_st@@PEAUggml_backend@@@Z'),
        ('ggml-base.lib', 'ggml-alloc.obj', 'ggml_gallocr_new')]:
        lib = REFERENCE / 'lib' / library
        result = subprocess.run([str(dump), '/nologo', '/linkermember:1', str(lib)], check=True, capture_output=True, text=True)
        indexed = [(m.group(1), m.group(2)) for line in result.stdout.splitlines()
                   if (m := re.match(r'^\s*([0-9A-Fa-f]+)\s+(\S+)\s*$', line))]
        offset = next(offset for offset, name in indexed if name == required)
        old = {name for found, name in indexed if found == offset}
        result = subprocess.run([str(dump), '/nologo', '/symbols', str(OUT / object_name)], check=True, capture_output=True, text=True)
        definitions = {line.split('|', 1)[1].strip().split(' ', 1)[0] for line in result.stdout.splitlines()
                       if 'External' in line and 'UNDEF' not in line and '|' in line}
        missing = sorted(old - definitions)
        unreferenced_literals = []
        if missing:
            # __FILE__ literals encode the historical build path. They are
            # indexed COMDAT definitions, not another module's API. Prove no
            # member has an undefined reference before excluding them.
            symbols = subprocess.run([str(dump), '/nologo', '/symbols', str(lib)],
                                     check=True, capture_output=True, text=True)
            undefined = {line.split('|', 1)[1].strip().split(' ', 1)[0]
                         for line in symbols.stdout.splitlines()
                         if 'External' in line and 'UNDEF' in line and '|' in line}
            unreferenced_literals = [name for name in missing
                                     if name.startswith('??_C@') and name not in undefined]
            missing = [name for name in missing if name not in unreferenced_literals]
        checks.append(dict(library=str(lib), member_offset=offset, replacement=str(OUT/object_name),
                           original_indexed_symbols=len(old), replacement_definitions=len(definitions),
                           obsolete_path_literals_without_any_undefined_archive_reference=unreferenced_literals,
                           missing_indexed_symbols=missing, no_original_member_extraction_required=not missing))
        assert not missing, (library, missing)
    save('member-symbol-coverage.json', checks)
    save('native-closure.json', dict(explicit_objects=[str(OUT/'ggml-cuda.obj'), str(OUT/'ggml-alloc.obj')],
        numerical_libraries=[str(REFERENCE/'lib'/name) for name in ['ggml.lib','ggml-cuda.lib','ggml-base.lib']],
        include_directories=[str(REFERENCE/'include'), str(REFERENCE/'src')],
        rule='Both explicit objects precede the three audited archives; no old ggml/base set may be linked alongside them',
        remaining='Current Hyle provider/core/consumer ABI closure and model execution are parent-owned and not validated by this native-only compilation'))


if __name__ == '__main__':
    recipes = audit_and_prepare()
    if '--compile' in sys.argv:
        run_recipes(recipes)
        check_member_symbols()
    elif '--symbols' in sys.argv:
        check_member_symbols()
    print('READY', OUT, flush=True)
