from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


paths = [
    'cmake/HyleDependencyLock.json',
    'src/compute_ggml_runtime/CMakeLists.txt',
    'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py',
    'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py',
    'src/compute_provider_ggml_cuda/native_bridge.h',
    'src/compute_provider_ggml_cuda/native_bridge_impl.h',
    'third_party/ggml_runtime/patches.json',
    'third_party/ggml_cpu_runtime/patches.json',
    'third_party/ggml_cuda_runtime/patches.json',
    'third_party/ggml_cuda_runtime/iq1-patches.json',
    'third_party/ggml_cuda_runtime/NOTICE.md',
    'tools/qwen35_text/main.cc',
    '.scratch/perf-review-2026-10-18/ggml-attention-provider/native-overlay-compile-command.json',
    '.scratch/legacy-root/hyle-scratch/ggml-native-static/compile_commands.json',
    '.scratch/validation/cuda-final-u3-delivery/reference-windows/identity.json',
]
save('source-identities.json', [dict(path=name, bytes=(ROOT/name).stat().st_size,
    sha256=sha(ROOT/name)) for name in paths] + [dict(path=str(path.relative_to(ROOT)),
    bytes=path.stat().st_size, sha256=sha(path)) for path in [
        OUT/'source/ggml-cuda.cu', OUT/'source/ggml-alloc.c', OUT/'build.py', OUT/'finalize.py']])
commands = json.loads((OUT/'commands.json').read_text())
assert len(commands) == 2 and all(row['exit'] == 0 and row['source_unchanged'] for row in commands)
for row in commands:
    assert sha(Path(row['object'])) == row['object_sha256']
save('object-identities.json', [dict(path=row['object'], bytes=row['object_bytes'],
    sha256=row['object_sha256']) for row in commands])
checks = json.loads((OUT/'member-symbol-coverage.json').read_text())
assert all(row['no_original_member_extraction_required'] for row in checks)
audit = json.loads((OUT/'cache-audit.json').read_text())
save('initial-symbol-check.json', dict(
    invocation='python -B build.py --compile', compilation='2/2 exit0',
    checker_exit=1, classification='Overstrict scratch symbol coverage check',
    cause='Two indexed historical __FILE__ COMDAT strings differ because the actual overlay uses a new workspace path',
    missing=checks[0]['obsolete_path_literals_without_any_undefined_archive_reference'],
    correction='Query all UNDEF symbols in the unchanged archive. These two strings have no undefined archive consumer; all callable/data module symbols are covered',
    final_invocation='python -B build.py --symbols', final_exit=0,
    no_native_recompile_for_checker=True))
save('summary.json', dict(
    status='current_native_overlay_compiled_and_symbol_closure_audited_model_not_run',
    original_pin=audit['original_pin'], reference_source_id=audit['reference_source_id'],
    current_source_id=audit['current_source_id'],
    correction='The previously documented absence of resource-bridge/IQ1 cache is disproven: the exact recorded reference archive actually contains all five bridge exports, precise unary and three new IQ1 MMQ instances',
    audited_reference_files=len(audit['reference_files']),
    audited_current_headers=sum(bool(x.get('current_locked_source_match')) for x in audit['reference_files']),
    immutable_reference_libraries=[x for x in audit['reference_files'] if '/lib/' in x['path'].replace('\\','/')],
    incremental_sources=audit['changes'],
    compiled=[dict(source=row['tag'], seconds=row['seconds'], object=row['object'],
        object_sha256=row['object_sha256'], exit=row['exit']) for row in commands],
    compile_scope='One original CUDA main TU, including its existing batched-pointer helper; one original allocator C TU. No other numerical CUDA kernel or SDK rebuilt/copied',
    symbol_coverage='All old main and allocator module symbols needed by any archive member are supplied by the explicit new objects. Two unused historical path strings excluded with whole-archive UNDEF proof',
    exact_headers='All recorded reference headers match current generated locked headers byte for byte; bridge declaration and implementation also match their provenance commit',
    public_abi='Reference ggml.h has IQ1 ids64/65/66 and COUNT67. Do not use old source-4e1a7b2f39afe15d public header or its native core libraries',
    link_recipe='native-closure.json; both explicit objects before the single reference ggml/ggml-cuda/ggml-base archive set',
    hyle_host_boundary='Parent must use/recompile actual current Hyle Provider15/Region24/Batch5/MLA3 plus current Graph private layout. Earlier source-only tensor object and source-equal host objects do not alone validate their complete header/ABI closure',
    full_qwen='Current tools/qwen35_text/main.cc SHA in source-identities.json differs from the prior full-journey object. Rebuild current consumer and current matched Hyle host closure before running',
    previous_journey='qwen35-ragged/05-full-text: complete 24layers, phases23/23->4/27->1/28, tokens20/248046/198; it used a legacy native set and is not evidence for this new closure',
    numerical_boundary='No numeric/model test run in this native-overlay stage. Prior Qwen relative errors remain without an established acceptance tolerance',
    no_deletion=True, no_product_edits=True))
print(json.dumps(dict(status='ready',objects=[row['object'] for row in commands],
    summary_sha256=sha(OUT/'summary.json')), indent=2))
