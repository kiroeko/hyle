C:\public\project-hyle\hyle\.scratch\architecture-refactor-2026-10-18\generic-progress\ggml-cache\ggml-cuda.obj : C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/generic-progress/ggml-cache/source/ggml-cuda.cu \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/generic-progress/ggml-cache/source/ggml-cuda.cu \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_runtime.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_config.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/crtdefs.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/sal.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/concurrencysal.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vadefs.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdarg \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/yvals_core.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xkeycheck.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdarg.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/builtin_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_defines.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/ctype.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wctype.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/driver_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_types.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/limits.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stddef.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/surface_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/texture_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/library_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/channel_descriptor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_runtime_api.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_device_runtime_api.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stdlib.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_malloc.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_search.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstdlib.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/driver_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/common_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_defines.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/string.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_memory.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_memcpy_s.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/errno.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_string.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstring.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/time.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wtime.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/new \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/exception \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/yvals.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/crtdbg.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_new_debug.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_new.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/use_ansi.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdlib \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/math.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_math.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/type_traits \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstddef \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xtr1common \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdint \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdint.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/malloc.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_exception.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/eh.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_terminate.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stdio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstdio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_stdio_config.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/assert.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/math_functions.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cmath \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/math_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_double_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_double_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_35_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_60_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_60_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_30_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_30_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_35_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_61_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_61_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_70_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_70_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_80_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_80_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_90_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_90_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_100_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_100_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/texture_indirect_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/surface_indirect_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/cudacc_ext.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_launch_parameters.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/functional \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/tuple \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_iter_core.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/utility \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/initializer_list \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/typeinfo \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_typeinfo.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xmemory \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/limits \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cfloat \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/float.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/climits \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cwchar \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdio \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/wchar.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wconio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wdirect.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_share.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wprocess.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/sys/stat.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/sys/types.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin0.inl.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/setjmp.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/immintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/wmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/nmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/smmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/tmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/pmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/emmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/mmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/zmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ammintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin0.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xatomic.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xutility \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstring \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/unordered_map \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xhash \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/list \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xpolymorphic_allocator.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vector \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_bit_utils.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_sanitizer_annotate_container.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xbit_ops.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xnode_handle.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/include/ggml-cuda.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/include/ggml.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdbool.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/include/ggml-backend.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/include/ggml-alloc.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-impl.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/include/gguf.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/array \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-backend-impl.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/allreduce.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/common.cuh \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/memory \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/iosfwd \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/mutex \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_chrono.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ctime \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ratio \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xtimec.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/system_error \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_system_error_abi.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cerrno \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdexcept \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xstring \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_string_view.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xcall_once.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xerrc.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/atomic \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xthreads.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_threads_core.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/thread \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/process.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_startup.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_startup.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-common.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_fp16.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/target \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/detail/__target_macros \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/detail/__preprocessor \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp16.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/algorithm \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_heap_algorithms.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_minmax.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cassert \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/string \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cctype \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/vendors/cuda.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cublas_v2.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cublas_api.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuComplex.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_bf16.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_bf16.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/library_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_fp8.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp8.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_fp4.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp6.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp6.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp4.hpp \
    C:/public/project-hyle/hyle/src/compute_provider_ggml_cuda/native_bridge.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_runtime_api.h \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/acc.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/add-id.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/arange.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/argmax.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/argsort.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/binbcast.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/clamp.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/col2im-1d.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/concat.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/conv-transpose-1d.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/conv2d.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/conv2d-dw.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/conv2d-transpose.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/convert.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/count-equal.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/cpy.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/cross-entropy-loss.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/cumsum.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/diagmask.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/diag.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/fattn.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/fwht.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/getrows.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/im2col.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmf.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mma.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-pascal-older.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-pascal-dp4a.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-ampere.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-blackwell.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-gcn.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-cdna.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-rdna2.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-rdna3.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-rdna3-5.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-config-rdna4.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-load-tiles.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/vecdotq.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmq-vec-dot.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmvf.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mmvq.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/moe-weighted-reduction.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/norm.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/opt-step-adamw.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/opt-step-sgd.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/out-prod.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/pad.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/pool2d.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/pool1d.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/quantize.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/rope.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/roll.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/scale.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/snake.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/softcap.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/softmax.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/ssm-conv.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/ssm-scan.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/sum.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/sumrows.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/top-k.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/mean.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/tsembd.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/topk-moe.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/unary.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/upscale.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/wkv.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/gla.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/gated_delta_net.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/dsv4-hc.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/set.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/set-rows.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/pad_reflect_1d.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/solve_tri.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/tri.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/fill.cuh \
    C:/public/project-hyle/hyle/.scratch/validation/cuda-final-u3-delivery/reference-windows/src/ggml-cuda/lightning-indexer.cuh \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/charconv \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xcharconv.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xcharconv_ryu.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xcharconv_ryu_tables.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xcharconv_tables.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cinttypes \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/inttypes.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/condition_variable \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/map \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xtree \
    C:/public/project-hyle/hyle/src/compute_provider_ggml_cuda/native_bridge_impl.h
