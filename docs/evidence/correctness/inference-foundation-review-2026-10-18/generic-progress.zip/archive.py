"""Preserve this bounded execution batch, excluding reconstructible binaries."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(name, data):
    (STAGE/name).write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8', newline='\n')

records = json.loads((STAGE/'windows/commands.json').read_text())
names = ['executable', 'submission', 'resources', 'region_access', 'constant_artifact',
         'lease_submission', 'region_provider_test', 'constant_artifact_cache_test',
         'retained_completion', 'completion_test', 'progress', 'progress_test']
for name in names:
    row = next(row for row in reversed(records) if row['tag'] == name+'-compile' and row['exit'] == 0)
    assert row['before'] == row['after']
    for entry in row['after']:
        if identity(entry['path']) == entry:
            continue
        # This exact explanatory comment followed the final successful build.
        # No ABI or executable token changed; do not rebuild for prose.
        assert Path(entry['path']) == ROOT/'src/graph/submission_lifetime.h'
        current = Path(entry['path']).read_text().replace(
            '// progress. The caller ends cursor/job access before returning the sentinel.\n'
            '// Any later handoff holds its own short reference, so public success cannot\n'
            "// precede the original slot's result publication.\n",
            '// progress. The caller owns the cursor and returns the lifetime sentinel only\n'
            '// after handing off its real Completion and ending its last slot access.\n')
        assert hashlib.sha256(current.encode()).hexdigest() == entry['sha256']
result = json.loads((STAGE/'windows/results.json').read_text())
assert result['tests'] == 95 and not result['failures'] and not result['errors']
for part in ['cuda', 'qwen']:
    assert (STAGE/part/'summary.json').is_file()

sources = ['include/hyle/graph/progress.h', 'src/graph_progress/progress.cc',
 'src/graph_progress/CMakeLists.txt', 'src/graph/progress_internal.h',
 'src/graph/plan_state.h', 'src/graph/executable.cc', 'src/graph/submission.cc',
 'src/graph/submission_internal.h', 'src/graph/submission_lifetime.h', 'src/graph/resources.cc',
 'include/hyle/compute/detail/retained_completion.h', 'src/compute/retained_completion.cc',
 'tests/compute/completion_test.cc', 'tests/graph_progress/progress_test.cc',
 'tests/graph_progress/CMakeLists.txt', 'tests/graph/cpu_cuda_pipeline.cc',
 'tests/graph/cpu_cuda_contracts/CMakeLists.txt',
 'cmake/HyleComponents.cmake', 'include/hyle/visibility.h',
 'tests/build_system/component_selection/CMakeLists.txt']
docs = ['docs/architecture/compute-design.md', 'docs/architecture/graph-design.md',
 'docs/developer/current-work.md', 'docs/user/graph.md',
 'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md', 'test.ps1']
for name in sources+docs:
    target = STAGE/'candidate'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT/name, target)

files = []
for folder, stems in [('windows',['controls']), ('cuda',['finite-consumer','gated-pipeline']),
                      ('qwen',['qwen35'])]:
    for stem in stems:
        for extension in ['.exe','.map','.exp','.lib']:
            path = STAGE/folder/(stem+extension)
            if path.exists(): files.append(identity(path))
save('cleanup.json', dict(root=str(STAGE), files=files,
    retained_objects=[identity(path) for path in sorted(STAGE.rglob('*.obj'))],
    retained='all source, logs, raw tensor data, object caches and existing dependency caches'))
save('summary.json', dict(
    scope='Actual shared execution over the original Invocation; goal remains active',
    host_tests=95, host_failures=0, fresh_matched_core_test_tus=12,
    source_identities=[identity(ROOT/name) for name in sources],
    actual_cpu='Native RMS [8,4096], independent FP64; Scheduler1/BlockingPool1 progress, fiber drain, result gates, rejection, cancellation/abandon',
    actual_cuda='Original Invocation finite family, plus controlled native CPU RMS/CUDA Neg/CPU Add; two slots and changed inputs; not throughput',
    actual_full_qwen='Ordinary direct Invocation; 24 layers, 23/23 -> 4/27 -> 1/28. Tokens match; independent numerical acceptance unresolved',
    costs='Cold control/jobs/lifetime metadata and flags; per-run existing Scheduler task/stack; bounded 1ms HostWait fallback; handoff tail can conservatively reject immediate replay',
    native_cache='Original audited archives stay read-only. Only two changed native TUs compiled incrementally; no kernel collection or SDK rebuild',
    remaining='Legacy WeightBatch/paging and cross-runtime consumer migration, thread contracts, old runtime deletion, numerical differences, fair tokens/s comparison, remaining selected-model feature gaps',
    not_run='Mac/Linux this batch; default full mixed CUPTI pipeline; broad provider/shape matrix',
    cleanup_bytes=sum(row['bytes'] for row in files)))

archive = ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/generic-progress.zip'
excluded = {'.obj','.exe','.map','.lib','.exp','.pdb','.zip','.pyc','.bin','.bf16','.f16','.f32'}
entries = []
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
    for path in sorted(STAGE.rglob('*')):
        relative = path.relative_to(STAGE)
        if (not path.is_file() or path.suffix.lower() in excluded or
            any(part == '__pycache__' or part == 'cmake-selection' or part.startswith('trace-') or part.startswith('probe-trace-') for part in relative.parts) or
            path.name in ['archive-receipt.json','cleanup-result.json']):
            continue
        output.write(path,relative.as_posix())
        entries.append(relative.as_posix())
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    assert saved.read('cleanup.json') == (STAGE/'cleanup.json').read_bytes()
    for name in sources+docs:
        assert saved.read('candidate/'+name) == (ROOT/name).read_bytes()
receipt = identity(archive)
receipt['path'] = str(archive.relative_to(ROOT))
receipt['entries'] = len(entries)
save('archive-receipt.json', receipt)
print(json.dumps(receipt,indent=2),flush=True)
