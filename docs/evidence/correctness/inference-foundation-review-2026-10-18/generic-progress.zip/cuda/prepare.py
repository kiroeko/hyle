"""Generate only this round's source and exact cached host compile recipes."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
ARCH = OUT.parents[1]
PRIOR = ARCH / 'submission-frontier/cuda'
QUEUE = ARCH / 'admitted-queue-sequence/cuda'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')

def replace(text, before, after):
    assert text.count(before) == 1, (text.count(before), before[:80])
    return text.replace(before, after, 1)

def command(stage, tag):
    return next(row['command'] for row in reversed(json.loads((stage / 'commands.json').read_text()))
                if row['tag'] == tag and row['exit'] == 0)

def recipe(base, source, output):
    return [base[0], *(value for value in base[1:] if not value.lower().startswith('/fo')
            and not value.endswith('.cc')), str(source), '/Fo' + str(output)]

def generate():
    canonical = ROOT / 'tests/graph/cpu_cuda_pipeline.cc'
    text = canonical.read_text()
    text = replace(text, '#include <hyle/graph/cuda.h>',
        '#include <hyle/graph/cuda.h>\n#include <hyle/compute/providers/cuda.h>\n#include <chrono>\n#include <thread>')
    text = replace(text, 'HYLE_ASSIGN_OR_RETURN(auto cuda, g::cuda::create_context());', '''HYLE_ASSIGN_OR_RETURN(auto selected, c::cuda::device(0));
  // Actual expert CUDA assembly; the canonical default consumer is unchanged.
  const std::array providers{c::ProviderBinding{c::cuda_native::provider()}};
  HYLE_ASSIGN_OR_RETURN(auto cuda, c::Context::create(selected, {.providers = providers}));''')
    text = replace(text, 'constexpr std::size_t elements = 4 * 1024 * 1024;', 'constexpr std::size_t elements = 4096;')
    text = replace(text, 'for (unsigned step = 0; step < 8; ++step)', 'for (unsigned step = 0; step < 1; ++step)')
    text = replace(text, 'for (unsigned step = 0; step < 65; ++step)', 'for (unsigned step = 0; step < 2; ++step)')
    text = text.replace('single_episodes\\\":8', 'single_episodes\\\":1').replace('changed_steps\\\":65', 'changed_steps\\\":2')
    text = replace(text, '  std::atomic<unsigned> phase{0};', '''  std::atomic<unsigned> phase{0};
  std::atomic<bool> gate_armed{false}, cpu_entered{false}, cpu_released{false}, cpu_timeout{false};
  std::atomic<bool> begin_control{false}, begin_observed{false}, begin_timeout{false};
  std::atomic<cudaStream_t> watched_stream{nullptr};
  std::atomic<cudaEvent_t> native_event{nullptr};''')
    text = replace(text, '  const auto phase = trace.phase.load(std::memory_order_acquire);', '''  if (trace.gate_armed.exchange(false, std::memory_order_acq_rel)) {
    trace.cpu_entered.store(true, std::memory_order_release);
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    while (!trace.cpu_released.load(std::memory_order_acquire)) {
      if (std::chrono::steady_clock::now() >= deadline) {
        trace.cpu_timeout.store(true, std::memory_order_release);
        break;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
  }
  const auto phase = trace.phase.load(std::memory_order_acquire);''')
    text = replace(text, '''    {
      HYLE_ASSIGN_OR_RETURN(auto pending, slots[0].submit(queues[0]));
      HYLE_RETURN_IF_ERROR(pending.wait());
      HYLE_ASSIGN_OR_RETURN(auto result, slots[0].result(out));
    }
    trace.phase.store(0, std::memory_order_release);''', '''    trace.cpu_entered.store(false, std::memory_order_relaxed);
    trace.cpu_released.store(false, std::memory_order_relaxed);
    trace.cpu_timeout.store(false, std::memory_order_relaxed);
    trace.native_event.store(nullptr, std::memory_order_relaxed);
    trace.begin_observed.store(false, std::memory_order_relaxed);
    trace.begin_timeout.store(false, std::memory_order_relaxed);
    HYLE_ASSIGN_OR_RETURN(auto stream, c::cuda::stream(gq[0]));
    trace.watched_stream.store(stream, std::memory_order_release);
    trace.gate_armed.store(true, std::memory_order_release);
    trace.begin_control.store(true, std::memory_order_release);
    struct Release {
      ~Release() {
        trace.begin_control.store(false, std::memory_order_release);
        trace.cpu_released.store(true, std::memory_order_release);
      }
    } release;
    HYLE_ASSIGN_OR_RETURN(auto pending, slots[0].submit(queues[0]));
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
    while (!trace.cpu_entered.load(std::memory_order_acquire) && std::chrono::steady_clock::now() < deadline)
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    HYLE_RETURN_IF_ERROR(require(trace.cpu_entered.load(), "actual CPU executor did not enter its gate"));
    cudaEvent_t event = nullptr;
    cudaError_t observed = cudaErrorNotReady;
    while (std::chrono::steady_clock::now() < deadline) {
      event = trace.native_event.load(std::memory_order_acquire);
      if (event != nullptr) {
        observed = cudaEventQuery(event);
        if (observed == cudaSuccess) break;
        HYLE_RETURN_IF_ERROR(require(observed == cudaErrorNotReady, "native recorded event query failed"));
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    HYLE_RETURN_IF_ERROR(require(event != nullptr && observed == cudaSuccess && !trace.cpu_timeout.load() &&
        trace.begin_observed.load(std::memory_order_acquire) && !trace.begin_timeout.load(),
        "GPU completion did not retire while CPU branch remained held"));
    HYLE_ASSIGN_OR_RETURN(auto held, pending.poll());
    HYLE_RETURN_IF_ERROR(require(held == c::CompletionPoll::kPending && !slots[0].result(out),
        "held CPU work published its result"));
    std::puts("controlled CUDA begin followed actual CPU gate entry; real GPU event completed before CPU release");
    trace.begin_control.store(false, std::memory_order_release);
    trace.watched_stream.store(nullptr, std::memory_order_release);
    trace.cpu_released.store(true, std::memory_order_release);
    HYLE_RETURN_IF_ERROR(pending.wait());
    { HYLE_ASSIGN_OR_RETURN(auto result, slots[0].result(out)); }
    trace.phase.store(0, std::memory_order_release);''')
    text = text[:text.index('int main(int argc, char **argv) {')] + '''extern "C" bool hyle_wait_for_cpu_gate(cudaStream_t stream) noexcept {
  if (!trace.begin_control.load(std::memory_order_acquire) ||
      stream != trace.watched_stream.load(std::memory_order_acquire)) return true;
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
  while (!trace.cpu_entered.load(std::memory_order_acquire)) {
    if (std::chrono::steady_clock::now() >= deadline) {
      trace.begin_timeout.store(true, std::memory_order_release);
      return false;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  if (trace.cpu_released.load(std::memory_order_acquire)) return false;
  trace.begin_observed.store(true, std::memory_order_release);
  return true;
}

extern "C" cudaError_t CUDARTAPI hyle_counted_record(cudaEvent_t event, cudaStream_t stream) {
  const auto recorded = cudaEventRecord(event, stream);
  if (recorded == cudaSuccess && stream == trace.watched_stream.load(std::memory_order_acquire)) {
    cudaEvent_t empty = nullptr;
    trace.native_event.compare_exchange_strong(empty, event, std::memory_order_release);
  }
  return recorded;
}

int main() {
  const auto status = branches(true, false, 2);
  if (!status.ok()) {
    std::fprintf(stderr, "%.*s\\n", int(status.message().size()), status.message().data());
    return 1;
  }
  return 0;
}
'''
    (OUT / 'gated-pipeline.cc').write_text(text, encoding='utf-8', newline='\n')
    # The ordinary default Abs carrier need not use this executor. The gated
    # control uses a real native normalization that demonstrably invokes it.
    text = replace(text, '#include <hyle/compute/providers/cuda.h>',
        '#include <hyle/compute/providers/cuda.h>\n#include <hyle/compute/providers/native.h>')
    text = replace(text, '''  HYLE_ASSIGN_OR_RETURN(auto cpu, g::cpu::create_context(
      {.executor = c::ParallelExecutorRef{&trace, 1, &cpu_parallel}}));''', '''  HYLE_ASSIGN_OR_RETURN(auto cpu, c::Context::create(c::cpu::device(),
      c::native::provider({.executor = c::ParallelExecutorRef{&trace, 2, &cpu_parallel}})));''')
    text = replace(text, 'constexpr std::size_t elements = 4096;',
        'constexpr std::size_t rows = 8, width = 4096, elements = rows * width;')
    text = replace(text, 'std::array<std::int64_t, 1>{elements}', 'std::array<std::int64_t, 2>{rows, width}')
    assert text.count('c::Unary{c::UnaryKind::kAbs}') == 2
    text = text.replace('c::Unary{c::UnaryKind::kAbs}', 'c::RmsNorm{.epsilon = 1.0e-5F}')
    text = replace(text, '''  HYLE_ASSIGN_OR_RETURN(auto compiled, b::compile(graph,
      {.cpu = &cpu, .cuda = &cuda, .staging = &pinned, .device = &device},
      {.node_placements = placements, .external_resources = external}));''', '''  // This instrumented control intentionally queues real CPU work first.
  // The CUDA begin shim waits for that work to enter its executor gate; an
  // ordinary CUDA begin has no such wait. Target and storage identities stay
  // identical to the normal cold CPU/CUDA environment.
  const std::array storage{g::StorageDomain{.resource = device.ref()},
      g::StorageDomain{.resource = m::system_resource()},
      g::StorageDomain{.resource = pinned.ref()}};
  HYLE_ASSIGN_OR_RETURN(auto cuda_source, g::ExecutionSource::acquire(cuda));
  HYLE_ASSIGN_OR_RETURN(auto cpu_source, g::ExecutionSource::acquire(cpu));
  const std::array targets{g::ExecutionTarget{.source = std::move(cuda_source), .default_storage = b::kDeviceStorage},
      g::ExecutionTarget{.source = std::move(cpu_source), .default_storage = b::kHostStorage}};
  const std::array lanes{g::ExecutionLane{.target = b::kCpuTarget},
      g::ExecutionLane{.target = b::kCudaTarget}};
  HYLE_ASSIGN_OR_RETURN(auto compiled, g::compile(graph,
      {.storage_domains = storage, .targets = targets, .lanes = lanes},
      {.node_placements = placements, .external_resources = external}));''')
    text = replace(text, '''    queues[i] = {g::QueueBinding{g::ExecutionLaneId{0}, &gq[i]},
        g::QueueBinding{g::ExecutionLaneId{1}, &cq[i]}};''', '''    queues[i] = {g::QueueBinding{g::ExecutionLaneId{0}, &cq[i]},
        g::QueueBinding{g::ExecutionLaneId{1}, &gq[i]}};''')
    text = replace(text, '''    for (std::size_t i = 0; i < elements; ++i) {
      const auto source = float(int(i % 101) - 50) * 0.125f + float(step) * 0.0625f + float(slot) * 0.25f;
      if (values[i] != std::abs(source) - 1.25f)
        return Status::Internal("independent CPU/CUDA branch+join oracle differs");
    }''', '''    for (std::size_t row = 0; row < rows; ++row) {
      double sum = 0;
      for (std::size_t column = 0; column < width; ++column) {
        const auto i = row * width + column;
        const auto source = float(int(i % 101) - 50) * 0.125f + float(step) * 0.0625f + float(slot) * 0.25f;
        sum += double(source) * source;
      }
      const double scale = 1.0 / std::sqrt(sum / width + double(1.0e-5F));
      for (std::size_t column = 0; column < width; ++column) {
        const auto i = row * width + column;
        const auto source = float(int(i % 101) - 50) * 0.125f + float(step) * 0.0625f + float(slot) * 0.25f;
        const double expected = double(source) * scale - 1.25;
        if (std::abs(double(values[i]) - expected) > 3.0e-6)
          return Status::Internal("native RMS/CUDA Neg/CPU Add FP64 oracle differs");
      }
    }''')
    (OUT / 'gated-rms-pipeline.cc').write_text(text, encoding='utf-8', newline='\n')
    finite_source = ROOT / 'tests/graph/route_symmetry_cuda.cc'
    finite = finite_source.read_text()
    finite = replace(finite, '#include <hyle/graph/cpu_cuda.h>', '''#include <hyle/graph/cpu_cuda.h>
#include <hyle/graph/progress.h>
#include <hyle/graph/result.h>
#include <hyle/sched/blocking.h>
#include <hyle/compute/providers/cuda.h>''')
    finite = replace(finite, 'HYLE_ASSIGN_OR_RETURN(auto cuda,g::cuda::create_context());', '''HYLE_ASSIGN_OR_RETURN(auto selected,c::cuda::device(0));
  const std::array providers{c::ProviderBinding{c::cuda_native::provider()}};
  HYLE_ASSIGN_OR_RETURN(auto cuda,c::Context::create(selected,{.providers=providers}));''')
    finite = replace(finite, '  hyle::sched::Scheduler scheduler(1,hyle::mem::system_allocator(),32);', '''  hyle::sched::Scheduler scheduler(1,hyle::mem::system_allocator(),32);
  hyle::sched::BlockingPool pool(hyle::mem::system_allocator(),1);''')
    finite = replace(finite, '    HYLE_ASSIGN_OR_RETURN(auto invocation,b::Invocation::create(std::move(native),scheduler,queues));', '''    auto invocation=std::move(native);
    HYLE_RETURN_IF_ERROR(g::prepare_progress(invocation,scheduler,pool));''')
    finite = replace(finite, '''    HYLE_RETURN_IF_ERROR(invocation.prepare_replay());
    HYLE_ASSIGN_OR_RETURN(auto result,invocation.run());
    HYLE_ASSIGN_OR_RETURN(auto actual,result->output(output));''', '''    HYLE_RETURN_IF_ERROR(invocation.prepare_replay(queues));
    HYLE_ASSIGN_OR_RETURN(auto pending,invocation.submit(queues));
    HYLE_RETURN_IF_ERROR(pending.wait());
    HYLE_ASSIGN_OR_RETURN(auto result,invocation.result(output));
    HYLE_ASSIGN_OR_RETURN(auto actual,result.tensor());''')
    (OUT / 'finite-consumer.cc').write_text(finite, encoding='utf-8', newline='\n')
    assert 'b::Invocation' not in text + finite
    old = command(PRIOR, 'gated-pipeline-controlled-compile')
    recipes = [dict(source=str(canonical.relative_to(ROOT)), command=recipe(old, canonical, OUT / 'canonical-pipeline.obj')),
        dict(source=str((OUT / 'finite-consumer.cc').relative_to(ROOT)), command=recipe(old, OUT / 'finite-consumer.cc', OUT / 'finite-consumer.obj')),
        dict(source=str((OUT / 'gated-rms-pipeline.cc').relative_to(ROOT)), command=recipe(old, OUT / 'gated-rms-pipeline.cc', OUT / 'gated-rms-pipeline.obj'))]
    save('compile-recipes.json', recipes)
    original_backend = ROOT / 'src/compute_backend_cuda/cuda_backend.cc'
    counted = json.loads((PRIOR / 'counted-backend-identity.json').read_text())
    assert sha(original_backend) == counted['original_sha256']
    assert sha(counted['scratch']) == counted['scratch_sha256']
    assert sha(counted['object']) == counted['object_sha256']
    save('controlled-backend-reuse.json', counted)
    paths = [canonical, finite_source, OUT / 'gated-pipeline.cc', OUT / 'gated-rms-pipeline.cc', OUT / 'finite-consumer.cc']
    save('source-identities.json', [dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p)) for p in paths])

if __name__ == '__main__':
    generate()
