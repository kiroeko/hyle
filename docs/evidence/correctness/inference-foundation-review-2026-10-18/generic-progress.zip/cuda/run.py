"""Only consumer host compilation; numerical kernels and SDK are reused."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
ARCH = OUT.parents[1]
spec = importlib.util.spec_from_file_location('consumer_host_driver', ARCH / 'region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def compile_consumers():
    identities = []
    for row in json.loads((OUT / 'compile-recipes.json').read_text()):
        source = ROOT / row['source']
        command = row['command']
        target = Path(next(value[3:] for value in command if value.lower().startswith('/fo')))
        before = sha(source)
        b.run(target.stem + '-compile', command)
        assert sha(source) == before
        identities.append(dict(source=str(source), source_sha256=before,
            object=str(target), bytes=target.stat().st_size, object_sha256=sha(target)))
    (OUT / 'compiled-consumers.json').write_text(json.dumps(identities, indent=2) + '\n', encoding='utf-8')

def compile_gated():
    row = next(row for row in json.loads((OUT/'compile-recipes.json').read_text())
               if row['source'].endswith('gated-rms-pipeline.cc'))
    b.run('gated-rms-pipeline-compile', row['command'])
    source = ROOT/row['source']
    target = OUT/'gated-rms-pipeline.obj'
    save('compiled-gated-rms.json', dict(source=str(source), source_sha256=sha(source),
        object=str(target), bytes=target.stat().st_size, object_sha256=sha(target)))

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def last(stage, tag):
    return next(row['command'] for row in reversed(json.loads((stage / 'commands.json').read_text()))
                if row['tag'] == tag and row['exit'] == 0)

def link(gated=False):
    prior = ARCH / 'submission-frontier/cuda'
    base = last(prior, 'native-consumer-link')
    common = OUT.parent / 'windows'
    replacements = {name:common/name for name in ('executable.obj', 'submission.obj', 'resources.obj',
        'region_access.obj', 'constant_artifact.obj', 'lease_submission.obj')}
    replacements['expert-consumer.obj'] = OUT / ('gated-rms-pipeline.obj' if gated else 'finite-consumer.obj')
    if gated:
        replacements['compute_backend_cuda--cuda_backend.obj'] = prior / 'cuda-backend-controlled.obj'
        identity = json.loads((OUT / 'controlled-backend-reuse.json').read_text())
        assert sha(identity['original']) == identity['original_sha256']
        assert sha(identity['scratch']) == identity['scratch_sha256']
        assert sha(identity['object']) == identity['object_sha256']
    extras = [common/'retained_completion.obj', common/'progress.obj',
        ROOT/'.scratch/build-compute-v2-dev/bin/hyle_mem_vm.lib']
    args = [base[0], *map(str, extras)]
    removed = []
    replaced = []
    for value in base[1:]:
        path = Path(value)
        if value.upper().startswith(('/OUT:', '/MAP:')):
            continue
        if path.name in ('joint-invocation.obj', 'joint-progress.obj'):
            removed.append(value)
            continue
        if path.name in replacements:
            replaced.append(dict(before=value, after=str(replacements[path.name])))
            value = str(replacements[path.name])
        args.append(value)
    assert len(removed) == 2
    assert len(replaced) == len(replacements)
    for value in args:
        if Path(value).is_absolute() and Path(value).suffix.lower() in ('.obj', '.lib'):
            assert Path(value).is_file(), value
    name = 'gated-pipeline' if gated else 'finite-consumer'
    args += ['/OUT:' + str(OUT/(name+'.exe')), '/MAP:' + str(OUT/(name+'.map'))]
    save(name+'-closure.json', dict(base=str(prior/'commands.json'), removed_second_driver=removed,
        replacements=replaced, fresh_common=[str(p) for p in extras],
        inputs=[dict(path=v, bytes=Path(v).stat().st_size, sha256=sha(v)) for v in args
                if Path(v).is_file() and Path(v).suffix.lower() in ('.obj', '.lib')]))
    b.run(name+'-link', args)

def run(gated=False):
    name = 'gated-pipeline' if gated else 'finite-consumer'
    command = last(OUT, name+'-link')
    directories = [str(Path(v).parent) for v in command if Path(v).is_absolute() and v.endswith('.lib')]
    directories += ['C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64',
        'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin',
        str(ROOT/'.scratch/build-compute-v2-dev/bin')]
    os.environ['PATH'] = os.pathsep.join(dict.fromkeys(directories)) + os.pathsep + os.environ['PATH']
    b.run(name+'-run', [OUT/(name+'.exe')], timeout=30)

if __name__ == '__main__':
    {'compile': compile_consumers, 'compile-gated': compile_gated, 'link': link, 'gated-link': lambda:link(True),
     'run': run, 'gated-run': lambda:run(True)}[sys.argv[1]]()
