#include <hyle/graph/cpu.h>
#include <hyle/graph/cuda.h>
#include <hyle/compute/providers/cuda.h>
#include <hyle/compute/providers/native.h>
#include <chrono>
#include <thread>
#include <hyle/graph/cpu_cuda.h>
#include <hyle/graph/progress.h>
#include <hyle/graph/result.h>
#include <hyle/sched/blocking.h>

#include <array>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <vector>

#if defined(HYLE_G09_HAS_CUPTI)
#include <cupti.h>
#endif

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace b = g::cpu_cuda;
namespace m = hyle::mem;
using hyle::Status;

struct Interval { std::uint64_t begin = 0, end = 0; unsigned phase = 0; };
struct Trace {
  std::atomic<unsigned> phase{0};
  std::atomic<bool> gate_armed{false}, cpu_entered{false}, cpu_released{false}, cpu_timeout{false};
  std::atomic<bool> begin_control{false}, begin_observed{false}, begin_timeout{false};
  std::atomic<cudaStream_t> watched_stream{nullptr};
  std::atomic<cudaEvent_t> native_event{nullptr};
  std::mutex mutex;
  std::array<Interval, 4096> cpu{}, gpu{};
  std::size_t cpu_count = 0, gpu_count = 0;
  bool overflow = false;
  void record(bool native, Interval interval) noexcept {
    std::lock_guard lock(mutex);
    auto &count = native ? gpu_count : cpu_count;
    auto &records = native ? gpu : cpu;
    if (count == records.size()) { overflow = true; return; }
    records[count++] = interval;
  }
};
Trace trace;

std::uint64_t timestamp() noexcept {
#if defined(HYLE_G09_HAS_CUPTI)
  std::uint64_t value = 0;
  (void)cuptiGetTimestamp(&value);
  return value;
#else
  return 0;
#endif
}
void cpu_parallel(void *, std::size_t count, c::ParallelTaskFn task, void *context) noexcept {
  if (trace.gate_armed.exchange(false, std::memory_order_acq_rel)) {
    trace.cpu_entered.store(true, std::memory_order_release);
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
    while (!trace.cpu_released.load(std::memory_order_acquire)) {
      if (std::chrono::steady_clock::now() >= deadline) {
        trace.cpu_timeout.store(true, std::memory_order_release);
        break;
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
  }
  const auto phase = trace.phase.load(std::memory_order_acquire);
  const auto begin = phase == 0 ? 0 : timestamp();
  for (std::size_t i = 0; i < count; ++i) task(context, i, count);
  if (phase != 0) trace.record(false, {begin, timestamp(), phase});
}

#if defined(HYLE_G09_HAS_CUPTI)
void CUPTIAPI request_buffer(std::uint8_t **buffer, std::size_t *size, std::size_t *records) {
  *size = 1024 * 1024;
  *buffer = static_cast<std::uint8_t *>(std::malloc(*size));
  if (*buffer == nullptr) *size = 0;
  *records = 0;
}
void CUPTIAPI complete_buffer(CUcontext context, std::uint32_t stream,
    std::uint8_t *buffer, std::size_t, std::size_t valid) {
  CUpti_Activity *record = nullptr;
  while (cuptiActivityGetNextRecord(buffer, valid, &record) == CUPTI_SUCCESS) {
    if (record->kind != CUPTI_ACTIVITY_KIND_KERNEL &&
        record->kind != CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL) continue;
    // This route's qualified Toolkit floor is CUDA/CUPTI 13.3.
    const auto *kernel = reinterpret_cast<const CUpti_ActivityKernel12 *>(record);
    if (kernel->start != 0 && kernel->end >= kernel->start)
      trace.record(true, {kernel->start, kernel->end, 0});
  }
  std::size_t dropped = 0;
  if (cuptiActivityGetNumDroppedRecords(context, stream, &dropped) != CUPTI_SUCCESS || dropped != 0) {
    std::lock_guard lock(trace.mutex); trace.overflow = true;
  }
  std::free(buffer);
}
#endif

struct Tensor { m::Buffer buffer; c::TensorView view; };
hyle::Result<Tensor> tensor(m::MemoryResourceRef resource, c::TensorDesc desc) {
  HYLE_ASSIGN_OR_RETURN(auto bytes, desc.required_bytes());
  HYLE_ASSIGN_OR_RETURN(auto buffer, m::Buffer::create(resource, bytes, 256));
  HYLE_ASSIGN_OR_RETURN(auto view, c::TensorView::create(desc, buffer.view()));
  return Tensor{std::move(buffer), view};
}
Status require(bool condition, const char *message) {
  return condition ? Status::Ok() : Status::Internal(message);
}

Status branches(bool cpu_first, bool tracing, unsigned workers) {
  HYLE_ASSIGN_OR_RETURN(auto cpu, c::Context::create(c::cpu::device(),
      c::native::provider({.executor = c::ParallelExecutorRef{&trace, 2, &cpu_parallel}})));
  HYLE_ASSIGN_OR_RETURN(auto selected, c::cuda::device(0));
  // Actual expert CUDA assembly; the canonical default consumer is unchanged.
  const std::array providers{c::ProviderBinding{c::cuda_native::provider()}};
  HYLE_ASSIGN_OR_RETURN(auto cuda, c::Context::create(selected, {.providers = providers}));
  HYLE_ASSIGN_OR_RETURN(auto pinned, c::cuda::MemoryResource::create(cuda, c::cuda::MemoryKind::kPinnedHost));
  HYLE_ASSIGN_OR_RETURN(auto device, c::cuda::MemoryResource::create(cuda, c::cuda::MemoryKind::kDevice));
  constexpr std::size_t rows = 8, width = 4096, elements = rows * width;
  HYLE_ASSIGN_OR_RETURN(auto desc, c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 2>{rows, width}));
  HYLE_ASSIGN_OR_RETURN(auto a, tensor(device.ref(), desc));
  std::vector<float> values(elements, 1.25f);
  HYLE_RETURN_IF_ERROR(a.buffer.view().write(std::as_bytes(std::span(values))));
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto xi, builder.input(desc));
  HYLE_ASSIGN_OR_RETURN(auto ai, builder.input(desc));
  g::ValueId cv, av;
  if (cpu_first) {
    HYLE_ASSIGN_OR_RETURN(cv, builder.add(c::RmsNorm{.epsilon = 1.0e-5F}, xi));
    HYLE_ASSIGN_OR_RETURN(av, builder.add(c::Unary{c::UnaryKind::kNeg}, ai));
  } else {
    HYLE_ASSIGN_OR_RETURN(av, builder.add(c::Unary{c::UnaryKind::kNeg}, ai));
    HYLE_ASSIGN_OR_RETURN(cv, builder.add(c::RmsNorm{.epsilon = 1.0e-5F}, xi));
  }
  HYLE_ASSIGN_OR_RETURN(auto out, builder.add(c::Binary{}, cv, av));
  HYLE_RETURN_IF_ERROR(builder.publish(out));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  const std::array placements{
      g::NodePlacement{*graph.node_id(cpu_first ? 0 : 1), b::kCpuTarget, g::PlacementStrength::kRequired},
      g::NodePlacement{*graph.node_id(cpu_first ? 1 : 0), b::kCudaTarget, g::PlacementStrength::kRequired},
      g::NodePlacement{*graph.node_id(2), b::kCpuTarget, g::PlacementStrength::kRequired}};
  const std::array external{g::ExternalResourceContract{xi, b::kHostStorage},
      g::ExternalResourceContract{ai, b::kDeviceStorage}, g::ExternalResourceContract{out, b::kHostStorage}};
  HYLE_ASSIGN_OR_RETURN(auto compiled, b::compile(graph,
      {.cpu = &cpu, .cuda = &cuda, .staging = &pinned, .device = &device},
      {.node_placements = placements, .external_resources = external}));
  // Both orders must preserve an independent CPU segment before the join.
  HYLE_RETURN_IF_ERROR(require(compiled.report.segment_count() >= 3,
      "independent CPU prefix still inherits the GPU join entry wait"));
  hyle::sched::Scheduler scheduler(workers, m::system_allocator(), 64);
  hyle::sched::BlockingPool pool(m::system_allocator(), workers);
  std::array<c::Queue, 2> cq, gq;
  std::array<Tensor, 2> x, y;
  struct Drain { hyle::sched::Scheduler &scheduler; ~Drain() { scheduler.drain(); } } drain{scheduler};
  std::array<g::Invocation, 2> slots;
  std::array<std::array<g::QueueBinding, 2>, 2> queues;
  for (unsigned i = 0; i < 2; ++i) {
    HYLE_ASSIGN_OR_RETURN(cq[i], cpu.create_queue());
    HYLE_ASSIGN_OR_RETURN(gq[i], cuda.create_queue());
    HYLE_ASSIGN_OR_RETURN(x[i], tensor(m::system_resource(), desc));
    HYLE_ASSIGN_OR_RETURN(y[i], tensor(m::system_resource(), desc));
    HYLE_ASSIGN_OR_RETURN(slots[i], compiled.executable.create_invocation());
    queues[i] = {g::QueueBinding{g::ExecutionLaneId{0}, &gq[i]},
        g::QueueBinding{g::ExecutionLaneId{1}, &cq[i]}};
    HYLE_RETURN_IF_ERROR(g::prepare_progress(slots[i], scheduler, pool));
  }
  auto bind = [&](unsigned slot, unsigned step) -> Status {
    for (std::size_t i = 0; i < elements; ++i)
      values[i] = float(int(i % 101) - 50) * 0.125f + float(step) * 0.0625f + float(slot) * 0.25f;
    HYLE_RETURN_IF_ERROR(x[slot].buffer.view().write(std::as_bytes(std::span(values))));
    HYLE_RETURN_IF_ERROR(slots[slot].bind(xi, x[slot].view.as_const()));
    HYLE_RETURN_IF_ERROR(slots[slot].bind(ai, a.view.as_const()));
    HYLE_RETURN_IF_ERROR(slots[slot].bind(out, y[slot].view));
    return slots[slot].prepare_replay(queues[slot]);
  };
  auto verify = [&](unsigned slot, unsigned step) -> Status {
    HYLE_RETURN_IF_ERROR(y[slot].buffer.view().read(std::as_writable_bytes(std::span(values))));
    for (std::size_t row = 0; row < rows; ++row) {
      double sum = 0;
      for (std::size_t column = 0; column < width; ++column) {
        const auto i = row * width + column;
        const auto source = float(int(i % 101) - 50) * 0.125f + float(step) * 0.0625f + float(slot) * 0.25f;
        sum += double(source) * source;
      }
      const double scale = 1.0 / std::sqrt(sum / width + double(1.0e-5F));
      for (std::size_t column = 0; column < width; ++column) {
        const auto i = row * width + column;
        const auto source = float(int(i % 101) - 50) * 0.125f + float(step) * 0.0625f + float(slot) * 0.25f;
        const double expected = double(source) * scale - 1.25;
        if (std::abs(double(values[i]) - expected) > 3.0e-6)
          return Status::Internal("native RMS/CUDA Neg/CPU Add FP64 oracle differs");
      }
    }
    return Status::Ok();
  };
  // Warm original kernels/programs before observing the single-DAG timeline.
  HYLE_RETURN_IF_ERROR(bind(0, 0));
  {
    HYLE_ASSIGN_OR_RETURN(auto warm, slots[0].submit(queues[0]));
    HYLE_RETURN_IF_ERROR(warm.wait());
    HYLE_ASSIGN_OR_RETURN(auto result, slots[0].result(out));
  }
  for (unsigned step = 0; step < 1; ++step) {
    HYLE_RETURN_IF_ERROR(bind(0, step));
    trace.phase.store(tracing ? (cpu_first ? 1u : 2u) : 0u, std::memory_order_release);
    trace.cpu_entered.store(false, std::memory_order_relaxed);
    trace.cpu_released.store(false, std::memory_order_relaxed);
    trace.cpu_timeout.store(false, std::memory_order_relaxed);
    trace.native_event.store(nullptr, std::memory_order_relaxed);
    trace.begin_observed.store(false, std::memory_order_relaxed);
    trace.begin_timeout.store(false, std::memory_order_relaxed);
    HYLE_ASSIGN_OR_RETURN(auto stream, c::cuda::stream(gq[0]));
    trace.watched_stream.store(stream, std::memory_order_release);
    trace.gate_armed.store(true, std::memory_order_release);
    trace.begin_control.store(true, std::memory_order_release);
    struct Release {
      ~Release() {
        trace.begin_control.store(false, std::memory_order_release);
        trace.cpu_released.store(true, std::memory_order_release);
      }
    } release;
    HYLE_ASSIGN_OR_RETURN(auto pending, slots[0].submit(queues[0]));
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
    while (!trace.cpu_entered.load(std::memory_order_acquire) && std::chrono::steady_clock::now() < deadline)
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    HYLE_RETURN_IF_ERROR(require(trace.cpu_entered.load(), "actual CPU executor did not enter its gate"));
    cudaEvent_t event = nullptr;
    cudaError_t observed = cudaErrorNotReady;
    while (std::chrono::steady_clock::now() < deadline) {
      event = trace.native_event.load(std::memory_order_acquire);
      if (event != nullptr) {
        observed = cudaEventQuery(event);
        if (observed == cudaSuccess) break;
        HYLE_RETURN_IF_ERROR(require(observed == cudaErrorNotReady, "native recorded event query failed"));
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    HYLE_RETURN_IF_ERROR(require(event != nullptr && observed == cudaSuccess && !trace.cpu_timeout.load() &&
        trace.begin_observed.load(std::memory_order_acquire) && !trace.begin_timeout.load(),
        "GPU completion did not retire while CPU branch remained held"));
    HYLE_ASSIGN_OR_RETURN(auto held, pending.poll());
    HYLE_RETURN_IF_ERROR(require(held == c::CompletionPoll::kPending && !slots[0].result(out),
        "held CPU work published its result"));
    std::puts("controlled CUDA begin followed actual CPU gate entry; real GPU event completed before CPU release");
    trace.begin_control.store(false, std::memory_order_release);
    trace.watched_stream.store(nullptr, std::memory_order_release);
    trace.cpu_released.store(true, std::memory_order_release);
    HYLE_RETURN_IF_ERROR(pending.wait());
    { HYLE_ASSIGN_OR_RETURN(auto result, slots[0].result(out)); }
    trace.phase.store(0, std::memory_order_release);
    HYLE_RETURN_IF_ERROR(verify(0, step));
  }
  for (unsigned step = 0; step < 2; ++step) {
    HYLE_RETURN_IF_ERROR(bind(0, step)); HYLE_RETURN_IF_ERROR(bind(1, step));
    trace.phase.store(tracing ? (cpu_first ? 3u : 4u) : 0u, std::memory_order_release);
    {
      HYLE_ASSIGN_OR_RETURN(auto first, slots[0].submit(queues[0]));
      HYLE_ASSIGN_OR_RETURN(auto second, slots[1].submit(queues[1]));
      HYLE_RETURN_IF_ERROR(first.wait());
      HYLE_RETURN_IF_ERROR(second.wait());
      HYLE_ASSIGN_OR_RETURN(auto old, slots[0].result(out));
      HYLE_ASSIGN_OR_RETURN(auto other, slots[1].result(out));
      HYLE_RETURN_IF_ERROR(require(!slots[0].bind(xi, x[0].view.as_const()).ok(),
          "retained result did not prevent slot overwrite"));
      HYLE_RETURN_IF_ERROR(verify(0, step)); HYLE_RETURN_IF_ERROR(verify(1, step));
    }
    trace.phase.store(0, std::memory_order_release);
  }
  HYLE_RETURN_IF_ERROR(bind(0, 91));
  {
    HYLE_ASSIGN_OR_RETURN(auto pending, slots[0].submit(queues[0]));
    HYLE_RETURN_IF_ERROR(pending.request_cancel());
    auto result = pending.wait();
    if (result.ok()) HYLE_RETURN_IF_ERROR(verify(0, 91));
    else HYLE_RETURN_IF_ERROR(require(result.IsCancelled(), "cancellation lost its status"));
  }
  slots[0].close().IgnoreError();
  const auto drained = slots[0].drain();
  HYLE_RETURN_IF_ERROR(require(drained.ok() || drained.IsCancelled(), "cancelled slot did not drain"));
  HYLE_RETURN_IF_ERROR(bind(1, 92));
  {
    HYLE_ASSIGN_OR_RETURN(auto abandoned, slots[1].submit(queues[1]));
    auto moved = std::move(slots[1]);
    abandoned = {};
    moved = {};
  }
  scheduler.drain();
  std::printf("{\"case\":\"%s\",\"workers\":%u,\"oracle\":\"PASS\",\"single_episodes\":1,\"slots\":2,\"changed_steps\":2,\"cancel_abandon_drain\":\"PASS\"}\n",
      cpu_first ? "cpu-first" : "gpu-first", workers);
  return Status::Ok();
}

#if defined(HYLE_G09_HAS_CUPTI)
Status trace_verdict() {
  std::lock_guard lock(trace.mutex);
  std::array<unsigned, 5> overlap{};
  for (std::size_t i = 0; i < trace.cpu_count; ++i) {
    const auto &cpu = trace.cpu[i];
    std::printf("{\"cpu\":true,\"phase\":%u,\"begin\":%llu,\"end\":%llu}\n", cpu.phase,
        static_cast<unsigned long long>(cpu.begin), static_cast<unsigned long long>(cpu.end));
    for (std::size_t j = 0; j < trace.gpu_count; ++j) {
      const auto &gpu = trace.gpu[j];
      if (cpu.begin < gpu.end && gpu.begin < cpu.end) { ++overlap[cpu.phase]; break; }
    }
  }
  for (std::size_t i = 0; i < trace.gpu_count; ++i)
    std::printf("{\"gpu\":true,\"begin\":%llu,\"end\":%llu}\n",
        static_cast<unsigned long long>(trace.gpu[i].begin), static_cast<unsigned long long>(trace.gpu[i].end));
  std::printf("{\"actual_kernel_intervals\":%zu,\"cpu_intervals\":%zu,\"single_cpu_first_overlap\":%u,\"single_gpu_first_overlap\":%u,\"multi_cpu_first_overlap\":%u,\"multi_gpu_first_overlap\":%u}\n",
      trace.gpu_count, trace.cpu_count, overlap[1], overlap[2], overlap[3], overlap[4]);
  return require(!trace.overflow && overlap[1] != 0 && overlap[2] != 0 && overlap[3] != 0 && overlap[4] != 0,
      "required real CPU/kernel interval overlap not observed or activity records dropped");
}
#endif
} // namespace

extern "C" bool hyle_wait_for_cpu_gate(cudaStream_t stream) noexcept {
  if (!trace.begin_control.load(std::memory_order_acquire) ||
      stream != trace.watched_stream.load(std::memory_order_acquire)) return true;
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
  while (!trace.cpu_entered.load(std::memory_order_acquire)) {
    if (std::chrono::steady_clock::now() >= deadline) {
      trace.begin_timeout.store(true, std::memory_order_release);
      return false;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  if (trace.cpu_released.load(std::memory_order_acquire)) return false;
  trace.begin_observed.store(true, std::memory_order_release);
  return true;
}

extern "C" cudaError_t CUDARTAPI hyle_counted_record(cudaEvent_t event, cudaStream_t stream) {
  const auto recorded = cudaEventRecord(event, stream);
  if (recorded == cudaSuccess && stream == trace.watched_stream.load(std::memory_order_acquire)) {
    cudaEvent_t empty = nullptr;
    trace.native_event.compare_exchange_strong(empty, event, std::memory_order_release);
  }
  return recorded;
}

int main() {
  const auto status = branches(true, false, 2);
  if (!status.ok()) {
    std::fprintf(stderr, "%.*s\n", int(status.message().size()), status.message().data());
    return 1;
  }
  return 0;
}
