#pragma once
#include <cstdio>
#include "ggml.h"
inline int hyle_tile_softmaxes = 0, hyle_tile_mask_copies = 0;
inline void hyle_tile_graph(ggml_cgraph *graph, const char *backend) {
  int softmaxes = 0, copies = 0;
  for (int i = 0; i < ggml_graph_n_nodes(graph); ++i) {
    const auto *node = ggml_graph_node(graph, i);
    if (node->op == GGML_OP_SOFT_MAX && node->src[2] &&
        node->ne[0] == 2049 && node->ne[1] == 1 &&
        node->ne[2] == 128 && node->ne[3] == 8)
      ++softmaxes;
    if (node->op == GGML_OP_CONT && node->ne[0] == 2049 &&
        node->ne[1] == 1 && node->ne[2] == 1 && node->ne[3] == 8)
      ++copies;
  }
  hyle_tile_softmaxes = softmaxes; hyle_tile_mask_copies = copies;
  std::printf("SINK_TILE backend=%s graph_nodes=%d softmaxes=%d packed_batch_mask_tiles=%d\n",
      backend, ggml_graph_n_nodes(graph), softmaxes, copies);
}
