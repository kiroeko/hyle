from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,zipfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
product=['src/compute_ggml_runtime/sink_mask.h','src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_provider_ggml_vulkan/region.cc']
tests=['tests/compute_provider_ggml/attention_math_test.cc','tests/graph_route_cuda/ggml_test.cc','tests/compute_models/batched_sink_fixture.h','tests/graph_batched_sink_test.h','tests/graph_route_cpu/graph_test.cc','tests/compute_ggml_runtime/gallocr_faults.c','tests/compute_ggml_runtime/gallocr_faults.h']
for name in product+tests+['include/hyle/compute/model_ops.h']:
    to=OUT/'source'/name;to.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,to)
diff=[]
for name in product+tests[:2]:
    before=OUT/'before'/name
    diff.extend(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],(ROOT/name).read_text().splitlines(True),fromfile=name+'.before',tofile=name))
(OUT/'task-product-and-wrapper.diff').write_text(''.join(diff))
paths=[ROOT/p for p in product+tests]+list(OUT.glob('*.obj'))
(OUT/'fresh-identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths],indent=2)+'\n')
hardware=subprocess.run(['nvidia-smi','--query-gpu=name,compute_cap,driver_version,memory.total','--format=csv'],capture_output=True,check=True)
(OUT/'cuda-hardware.log').write_bytes(hardware.stdout)
summary={
 'scope':'GGML CPU/CUDA/Vulkan batched SinkAttention mask and resource admission, with root-owned public schema/fixtures. API fields and custom ID unchanged.',
 'changes':['Shared private sink_mask normalizes dense public [B,Q,S] native [S,Q,B,1] to [S,Q,1,B], while rank2 shared masks retain their original storage.','sink_mask_rows preserves full mask batch pitch in a 4D view, packing only noncontiguous tiles.','Three provider score limits use actual B*H*Q*S and retain their original native byte limits. Vulkan query alignment uses mask stride at rank-2.','Vulkan contiguous singleton KV-head input gets canonical same-shape strides when the batch pitch differs from nb2*ne2. This metadata repair preserves its existing F32 carrier.','Canonical CPU/CUDA wrappers cover root shared fixture; CUDA also calls real public Graph shared-cache Gather -> one batched Sink -> Neg with dual publication.'],
 'validation':{
   'cpu_direct':'Complete current tests/compute_provider_ggml/attention_math_test.cc compiled /W4 /WX; new B3 H64/128 Q1/3 shared/perBatch mask x2 phases PASS. Existing ColdSinkAllocationUsesBoundedScores PASS.',
   'cuda_direct':'Complete current tests/graph_route_cuda/ggml_test.cc compiled /W4 /WX; same direct eight geometries x2 phases PASS. Existing shared-Q8-gate/up SwiGLU numerical regression PASS.',
   'cpu_graph':'Complete root-owned canonical tests/graph_route_cpu/graph_test.cc fresh compiled. Public Gather(shared127x512,I32[3,17]) -> reshape -> one B3/Q1/H64 Sink -> Neg, both outputs published, two changed cache/ID phases PASS.',
   'cuda_graph':'Same public Graph consumer through graph::cuda::create_context, fresh full canonical TU, two changed cache/ID phases PASS.',
   'tile':'One additional geometry per CPU/CUDA, H128 B8 Q3 S2049 perBatch mask, two phases, complete independent scalar FP64 oracle at original abs2e-5+rel2e-5 PASS. Scratch-only native cold graph count CPU37nodes/CUDA45nodes; both exactly3 sink SOFT_MAX and3 [2049,1,1,8] mask CONT nodes. No product trace or alternate arithmetic.',
   'vulkan':'Current region.cc fresh host compile /W4 /WX PASS. Parent independently ran final canonical region object f369e2de...: eight Graph geometries x2 phases PASS; one scratch-forced-Q2 B2/H64/Q5/S64 rank3 tiny tile PASS (actual2+2+1 rows). Parent runtime package .scratch/inference-foundation-review-2026-10-18/batched-sink-vulkan-graph/source-results.zip SHA256 dabb2d63976945ebb2d0013b4f7b914a7a4ac5ee59d032859c0c5014a1f0d665. Those runtime logs are archived separately.'},
 'build_boundary':'Existing MSVC14.50.35717 Windows static closures and native SDKs reused. Fresh CPU provider, CUDA provider/tensor, Vulkan region and affected test TUs only; canonical CPU existing allocator fault test helper compiled as one local C test TU. No native SDK rebuild/download. Runner reads recorded commands and imports only scripts/hyle_environment.py, never execution-style build runners.',
 'cuda_cache_boundary':'Reused strict native pin lacks unrelated IQ1_XS/IQ1_XXS/IQ1_XXXS enums. Exactly those three return sites are declined only in scratch cuda-tensor.validation.cc; product source keeps its full domain. F32 Sink does not use these formats. No IQ1 domain pass claimed.',
 'limits':['No throughput, total allocator peak, full model, or joint paged selected-KV claim. Graph consumer explicitly gathers selected KV into dense batches.','Existing CUDA query tiling is standalone-only. This batch change preserves that gate; multi-node region tiling requires separately fixing copy-output dependencies and cold constant allocation.','Existing native CPU debug assert(sum>0) before adding sink can reject all-masked rows even for a finite sink. Existing release SDK tests here do not validate or repair that old debug boundary.','Apple changes and Vulkan runtime tests are owned and archived separately by root/parent.'],
 'self_review':'Exact task-only diffs generated against per-file pre-task snapshots; all unrelated dirty source changes preserved; git diff --check on touched product/tests PASS.',
 'reproduce':['python .scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/build.py cpu cuda vulkan','python .scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/build.py cpu_graph tile'],
 'fixture_only_fixes':['Added missing resource argument to direct prepare.','GraphBuilder.add_node requires explicit Operation(Gather).','Extracted direct_case(Context&,Queue&,resource,Fixture&) from the existing eight-geometry loop to reuse exactly the same submit/oracle code for the single tile geometry.']}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
allowed={'.json','.py','.h','.cc','.c','.log','.diff'}
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.suffix in allowed and '__pycache__' not in p.parts)
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:z.write(p,p.relative_to(OUT).as_posix())
print(json.dumps(dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
