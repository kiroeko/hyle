#include "tests/compute_models/batched_sink_fixture.h"
#include "tile_graph.h"
#if defined(HYLE_COMPUTE_CUDA)
#include "hyle/compute/cuda.h"
#include "hyle/compute/backends/cuda.h"
#else
#include "hyle/compute/cpu.h"
#endif

TEST(BatchedSinkTile, NativeBatchMasksKeepTheFullQueryPitchAcrossTwoPhases) {
  namespace c = hyle::compute;
#if defined(HYLE_COMPUTE_CUDA)
  auto context = c::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto resource = memory.ref();
#else
  auto context = c::cpu::create_context({.native_threads = 2}).value();
  auto resource = hyle::mem::system_resource();
#endif
  auto queue = context.create_queue().value();
  batched_sink_test::Fixture fixture(128, true, 3, 8, 2049);
  batched_sink_test::direct_case(context, queue, resource, fixture);
  EXPECT_EQ(hyle_tile_softmaxes, 3);
  EXPECT_EQ(hyle_tile_mask_copies, 3);
}
