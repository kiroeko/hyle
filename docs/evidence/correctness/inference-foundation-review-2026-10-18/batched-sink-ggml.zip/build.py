from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
def prior(path,tag):
    return next(r['command'] for r in reversed(json.loads((ROOT/path).read_text())) if r.get('tag',r.get('label'))==tag)
cpu_compile=prior('.scratch/inference-foundation-review-2026-10-18/cpu-mla/commands.json','2-provider-compile')
cuda_compile=prior('.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/commands.json','canonical-compile')
vk_compile=prior('.scratch/inference-foundation-review-2026-10-18/gather-elements-native/vulkan/commands.json','region-compile')
cpu_link=prior('.scratch/inference-foundation-review-2026-10-18/region-discovery/commands.json','cpu-after-link')
cuda_link=prior('.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/commands.json','canonical-link')
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':cpu_compile[0],'CMAKE_C_COMPILER':cpu_compile[0]})
env['VSLANG']='1033';env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
runtime=[str(ROOT/'.scratch/build-compute-v2-dev/bin')]
runtime += [str(Path(p).parent) for p in cpu_link+cuda_link if p.endswith('.lib') and Path(p).is_absolute()]
env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH']
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command):
    command=list(map(str,command));start=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=180)
    stem=f'{len(records)+1}-{tag}';(OUT/(stem+'.stdout.log')).write_bytes(p.stdout);(OUT/(stem+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,p.stdout.decode(errors='replace')[-7000:],p.stderr.decode(errors='replace')[-1600:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)
def compile(source,name,cached):
    flags=[x for x in cached if not x.lower().startswith(('/fo','/fp')) and not x.endswith(('.cc','.cpp')) and 'CUPTI' not in x]
    obj=OUT/(name+'.obj');run(name+'-compile',[*flags,source,'/Fo'+str(obj)]);return obj
def link(name,cached,omit,objects):
    command=[x for x in cached if not x.startswith(('/OUT:','/MAP:')) and x not in set(map(str,omit))]
    exe=OUT/(name+'.exe');run(name+'-link',[*command,*objects,'/OUT:'+str(exe)]);return exe
def cpu():
    provider=compile(ROOT/'src/compute_provider_ggml/ggml_cpu_provider.cc','cpu-provider',cpu_compile)
    tests=compile(ROOT/'tests/compute_provider_ggml/attention_math_test.cc','cpu-canonical',cpu_compile)
    fault_flags=[x for x in cpu_compile if x not in ['/std:c++latest','/EHsc','/permissive-'] and not x.lower().startswith('/fo') and not x.endswith('.cc')]
    faults=OUT/'cpu-gallocr-faults.obj'
    run('cpu-gallocr-faults-compile',[*fault_flags,'/std:c17','/TC',ROOT/'tests/compute_ggml_runtime/gallocr_faults.c','/Fo'+str(faults)])
    omit=[ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cpu-canonical.obj']
    exe=link('cpu',cpu_link,omit,[provider,tests,faults])
    run('cpu-canonical-tests',[exe,'--gtest_filter=GgmlCpuAttention.BatchedSinkMasksAndHeadDenominatorsReplay:GgmlCpuMathAttention.ColdSinkAllocationUsesBoundedScores','--gtest_color=no'])
def cuda():
    provider=compile(ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','cuda-provider',cuda_compile)
    source=(ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc').read_text()
    for codec in ['IQ1_XS','IQ1_XXS','IQ1_XXXS']:
        old='return GGML_TYPE_'+codec+';';assert source.count(old)==1
        source=source.replace(old,'return GGML_TYPE_COUNT; // Validation-only unrelated missing codec in reused native pin.')
    overlay=OUT/'cuda-tensor.validation.cc';overlay.write_text(source)
    tensor=compile(overlay,'cuda-tensor',cuda_compile)
    tests=compile(ROOT/'tests/graph_route_cuda/ggml_test.cc','cuda-canonical',cuda_compile)
    omit=[ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/provider.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/tensor-after.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/canonical.obj']
    exe=link('cuda',cuda_link,omit,[provider,tensor,tests])
    run('cuda-canonical-tests',[exe,'--gtest_filter=CudaDefaultGraph.BatchedSinkMasksAndHeadDenominatorsReplay:CudaDefaultGraph.SharedQ8GateUpSwiGluPreservesPublishedIntermediates','--gtest_color=no'])
def cuda_tests():
    tests=compile(ROOT/'tests/graph_route_cuda/ggml_test.cc','cuda-canonical',cuda_compile)
    omit=[ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/provider.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/tensor-after.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/canonical.obj']
    exe=link('cuda',cuda_link,omit,[OUT/'cuda-provider.obj',OUT/'cuda-tensor.obj',tests])
    run('cuda-public-graph-tests',[exe,'--gtest_filter=CudaDefaultGraph.SelectedKvSetsFeedOneBatchedSinkAttention:CudaDefaultGraph.BatchedSinkMasksAndHeadDenominatorsReplay:CudaDefaultGraph.SharedQ8GateUpSwiGluPreservesPublishedIntermediates','--gtest_color=no'])
def cpu_tests():
    tests=compile(ROOT/'tests/compute_provider_ggml/attention_math_test.cc','cpu-canonical',cpu_compile)
    omit=[ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cpu-canonical.obj']
    exe=link('cpu',cpu_link,omit,[OUT/'cpu-provider.obj',tests,OUT/'cpu-gallocr-faults.obj'])
    run('cpu-canonical-tests',[exe,'--gtest_filter=GgmlCpuAttention.BatchedSinkMasksAndHeadDenominatorsReplay:GgmlCpuMathAttention.ColdSinkAllocationUsesBoundedScores','--gtest_color=no'])
def cpu_graph():
    tests=compile(ROOT/'tests/graph_route_cpu/graph_test.cc','cpu-graph-canonical',cpu_compile)
    omit=[ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cpu-canonical.obj']
    exe=link('cpu-graph',cpu_link,omit,[OUT/'cpu-provider.obj',tests])
    run('cpu-public-graph-tests',[exe,'--gtest_filter=*SelectedKvSetsFeedOneBatchedSinkAttention*','--gtest_color=no'])
def vulkan():
    compile(ROOT/'src/compute_provider_ggml_vulkan/region.cc','vulkan-region',vk_compile)
def tile():
    for backend,cached,source,marker,call in [
        ('cpu',cpu_compile,'src/compute_provider_ggml/ggml_cpu_provider.cc',
         '    for (const auto id : recipe.outputs) {','    hyle_tile_graph(invocation->graph, "cpu");\n'),
        ('cuda',cuda_compile,'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
         '    const auto nodes = ggml_graph_n_nodes(graph);','    hyle_tile_graph(graph, "cuda");\n')]:
        data=(ROOT/source).read_text();assert data.count(marker)==1
        data='#include "tile_graph.h"\n'+data.replace(marker,call+marker,1)
        overlay=OUT/(backend+'-provider.tile-validation.cc');overlay.write_text(data)
        provider=compile(overlay,backend+'-tile-provider',cached+['/I'+str(OUT)])
        tests=compile(OUT/'tile_probe.cc',backend+'-tile-probe',cached+['/I'+str(OUT)])
        if backend=='cpu':
            omit=[ROOT/'.scratch/inference-foundation-review-2026-10-18/cpu-mla/provider.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/region-discovery/cpu-canonical.obj']
            exe=link('cpu-tile',cpu_link,omit,[provider,tests])
        else:
            omit=[ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-gather-elements/provider.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/tensor-after.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/canonical.obj']
            exe=link('cuda-tile',cuda_link,omit,[provider,OUT/'cuda-tensor.obj',tests])
        run(backend+'-tile-tests',[exe,'--gtest_color=no'])
if __name__=='__main__':
    for action in sys.argv[1:] or ['cpu','cuda','vulkan']:
        globals()[action]()
    sources=['src/compute_ggml_runtime/sink_mask.h','src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_provider_ggml_vulkan/region.cc','tests/compute_models/batched_sink_fixture.h','include/hyle/compute/model_ops.h']
    paths=[ROOT/p for p in sources]+[Path(x) for x in cpu_link+cuda_link if x.endswith(('.obj','.lib')) and Path(x).is_file()]
    (OUT/'identities.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in dict.fromkeys(paths)],indent=2)+'\n')
