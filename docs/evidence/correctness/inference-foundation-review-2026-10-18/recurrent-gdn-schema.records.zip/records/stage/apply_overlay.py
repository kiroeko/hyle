"""Apply the exact reviewed public schema and native qualification change."""
from pathlib import Path
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]


def identity(path):
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


freeze_path = STAGE / 'source-freeze.json'
freeze = json.loads(freeze_path.read_text())
for row in freeze['files']:
    for path, expected in ((ROOT / row['source'], row['before']),
                           (Path(row['after']['path']), row['after'])):
        actual = identity(path)
        if (actual['bytes'], actual['sha256']) != (expected['bytes'], expected['sha256']):
            raise ValueError('Source drift: ' + str(path))
for row in freeze['files']:
    (ROOT / row['source']).write_bytes(Path(row['after']['path']).read_bytes())
receipt = {'freeze': identity(freeze_path), 'files': [identity(ROOT / row['source']) for row in freeze['files']],
           'new_public_wrapper_or_compatibility_entry': False, 'build_or_GPU_run': False}
(STAGE / 'application.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('APPLIED', len(receipt['files']), flush=True)
