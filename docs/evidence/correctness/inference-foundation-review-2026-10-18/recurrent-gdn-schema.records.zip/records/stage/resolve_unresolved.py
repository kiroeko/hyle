"""Classify the old inventory's25 unknown objects without executing compilers."""
from pathlib import Path
import hashlib
import json
import re

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def key(path):
    return str(Path(path).resolve()).casefold()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('command', value.get('argv')), list):
            yield value
        for name, nested in value.items():
            if name not in ('command', 'argv') and isinstance(nested, (dict, list)):
                yield from walk(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from walk(nested)


def main():
    rows = []
    for old in read(STAGE / 'inline-dependencies.json')['unresolved_objects']:
        obj = Path(old['path'])
        candidates = []
        for directory in (obj.parent, obj.parent.parent):
            for path in directory.glob('*.json'):
                if not any(word in path.name for word in ('command', 'recipe', 'identity', 'identities', 'manifest')):
                    continue
                for row in walk(read(path)):
                    command = row.get('command', row.get('argv'))
                    if any(key(arg[3:] if arg.lower().startswith('/fo') else arg) == key(obj)
                           for arg in command if isinstance(arg, str) and (arg.lower().endswith('.obj') or arg.lower().startswith('/fo'))):
                        sources = [Path(arg) for arg in command if arg.lower().endswith(('.cc', '.cpp', '.c', '.cu'))]
                        if sources:
                            candidates.append((sources[-1], command, path))
        if candidates:
            source, command, recipe = candidates[-1]
            origin = 'literal retained object compile command'
        elif '.cu.obj' in obj.name:
            source = ROOT / 'src/compute_provider_cuda' / obj.name[:-4]
            command, recipe = [], None
            origin = 'retained CMake CUDA object source-relative basename plus current source include closure'
        else:
            raise ValueError('Unclassified original object: ' + str(obj))
        if not source.is_file():
            raise ValueError('Missing mathematical/native source for include review: ' + str(source))
        include_dirs = [ROOT / 'include', ROOT, ROOT / 'src/compute', ROOT / 'src/compute_ggml_runtime']
        for arg in command:
            for prefix in ('/external:i', '/i', '-i'):
                if arg.lower().startswith(prefix):
                    directory = Path(arg[len(prefix):].strip('"'))
                    if directory.is_dir() and directory.is_relative_to(ROOT):
                        include_dirs.append(directory)
                    break
        visited, pending, hyle_missing = {}, [source.resolve()], set()
        while pending:
            path = pending.pop()
            if key(path) in visited:
                continue
            visited[key(path)] = path
            text = path.read_text(encoding='utf-8-sig', errors='replace')
            for delimiter, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\n]+)[>"]', text, re.M):
                dirs = ([path.parent] if delimiter == '"' else []) + include_dirs
                resolved = next((directory / name for directory in dirs if (directory / name).is_file()), None)
                if resolved is not None:
                    resolved = resolved.resolve()
                    # System/CUDA/Torch SDK headers cannot own Hyle model_ops;
                    # inspect all reachable repository and retained GGML files.
                    if resolved.is_relative_to(ROOT):
                        pending.append(resolved)
                elif name.startswith('hyle/'):
                    hyle_missing.add(name)
        model = ROOT / 'include/hyle/compute/model_ops.h'
        if key(model) in visited or hyle_missing:
            raise ValueError('Potential inline model owner remains: ' + str(obj) + repr(sorted(hyle_missing)))
        family = ('GGML C allocation' if source.suffix == '.c' else
                  'CUDA device/native mathematics' if source.suffix == '.cu' else
                  'GGML CPU mathematical implementation' if source.name == 'ops.cpp' else
                  'GGML CPU runtime/ABI selector')
        rows.append({**old, 'object': identity(obj), 'source': identity(source),
                     'classification': family, 'source_origin': origin,
                     'recipe': identity(recipe) if recipe else None,
                     'include_closure_files': [identity(path) for path in sorted(visited.values())],
                     'model_ops_h_present': False,
                     'review_method': 'Conservative literal quoted/angle include closure, including disabled preprocessor branches; no preprocessor/compiler execution.',
                     'unresolved_hyle_includes': [], 'host_refresh_required': False})
    report = {
        'state': 'Read-only source/recipe include review; no builds, tests or source changes.',
        'original_unresolved_count': len(rows), 'resolved_nonowners': rows,
        'additional_model_header_owners': [], 'remaining_unresolved': [],
        'scope': 'The8 retained CMake CUDA object basenames resolve to current corresponding native source. Other17 sources bind to literal cached commands. This is a source-include classification, not a claim that old mathematical objects were freshly rebuilt.',
    }
    (STAGE / 'unresolved-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'resolved': len(rows), 'classification': {kind: sum(row['classification'] == kind for row in rows) for kind in sorted({row['classification'] for row in rows})}, 'additional_owners': 0}))


if __name__ == '__main__':
    main()
