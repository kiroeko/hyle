"""Run only the15 distinct GDN schema/provider regressions after a successful build."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
CPU_TESTS = [
    'OperationGatedDeltaNet.PreservesExplicitStateAndGroupedHeadContract',
    'OperationGatedDeltaNet.RejectsWrongGatesStateTypesAndArityAtomically',
    'OperationGatedDeltaNet.SnapshotCountKeepsFinalStateOrChronologicalTail',
    'OperationModelOps.RecurrentRegionKeepsQualifiedShapeAndPrivateGates',
    'OperationModelOps.RecurrentRegionRejectsUnqualifiedPortsAtomically',
    'OperationModelOps.RecurrentRegionBroadcastsParametersOverTokenBlock',
    'OperationModelOps.RecurrentRegionReusesParameterizedGdnAndAtomicInference',
    'GgmlCpuProvider.GatedDeltaNetSnapshotsKeepChronologicalBatchesOnRebind',
    'GgmlCpuProvider.RecurrentTokenBlockBroadcastsParametersAndPublishesSnapshots',
    'GgmlCpuProvider.RecurrentSchemaDoesNotGrantUnavailableNativeTypesOrState',
    'GgmlCpuProvider.D5Qwen38GroupedHeadsUseMatureGatedDeltaNet',
]
CUDA_TESTS = [
    'GgmlCudaTensor.GatedDeltaNetSnapshotsKeepChronologicalBatchesOnRebind',
    'GgmlCudaTensor.RecurrentTokenBlockBroadcastsParametersAndPublishesSnapshots',
    'GgmlCudaTensor.RecurrentSchemaDoesNotGrantUnavailableNativeDepthOrBatch',
    'GgmlCudaTensor.D5Qwen38GroupedHeadsUseMatureGatedDeltaNet',
]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    build = load('gdn_check_build', STAGE / 'build.py')
    b, c = build.b, build.c
    plan_path = Path(sys.argv[1]).resolve()
    plan = c.read(plan_path)
    build.check(plan)
    if not c.read(plan_path.parent / 'summary.json')['passed']:
        raise ValueError('Successful thirty-host build required before testing')
    if len(set(CPU_TESTS + CUDA_TESTS)) != 15:
        raise ValueError('Expected15 distinct exact GDN cases')
    reports = {}
    for arm, tests in (('cpu', CPU_TESTS), ('cuda', CUDA_TESTS)):
        link = plan['links'][arm]
        out = plan_path.parent / ('run-' + arm)
        out.mkdir(exist_ok=False)
        (out / 'tmp').mkdir()
        image = b.identity(link['image'])
        if image != c.read(plan_path.parent / (arm + '-image.json')):
            raise ValueError('Tested image identity differs: ' + arm)
        # Never use plan.cached_inputs here: it is the union of CPU and CUDA
        # SDKs. Construct each runtime PATH from this arm's actual link inputs.
        env, directories = b.environment(link['command'], link['inputs'], out)
        command = [image['path'], '--gtest_filter=' + ':'.join(tests),
                   '--gtest_color=no', '--gtest_output=xml:' + str(out / 'result.xml')]
        c.save(out / 'inputs.json', {
            'runner': b.identity(Path(__file__)), 'plan': b.identity(plan_path),
            'image': image, 'requested_tests': tests,
            'runtime_link_input_paths': link['inputs'], 'runtime_library_directories': directories,
            'CPU_CUDA_cached_input_union_used': False,
        })
        c.execute(arm, command, env, out)
        xml = ET.parse(out / 'result.xml').getroot()
        counts = {key: int(xml.get(key, 0)) for key in ('tests', 'failures', 'disabled', 'errors')}
        cases = list(xml.iter('testcase'))
        names = [case.get('classname') + '.' + case.get('name') for case in cases]
        skipped = sum(case.find('skipped') is not None or case.get('status') != 'run' for case in cases)
        passed = (set(names) == set(tests) and len(names) == len(tests) and counts['tests'] == len(tests)
                  and not any(counts[key] for key in ('failures', 'disabled', 'errors')) and skipped == 0)
        report = {'passed': passed, **counts, 'skipped_or_not_run': skipped, 'cases': names,
                  'limits': 'Only exact related GDN schema/provider cases; no general fusion or alias suite rerun.'}
        c.save(out / 'summary.json', report)
        reports[arm] = report
        if not passed:
            raise ValueError('Expected all exact GDN cases to execute with no skip: ' + arm)
        print('GDN_CHECK', arm, counts, flush=True)
    c.save(plan_path.parent / 'checks-summary.json', {
        'passed': all(row['passed'] for row in reports.values()),
        'different_cases': sum(row['tests'] for row in reports.values()),
        'reports': reports, 'CPU_CUDA_runtime_environments_separate': True,
        'model_run': False, 'throughput_claim': False,
    })


if __name__ == '__main__':
    main()
