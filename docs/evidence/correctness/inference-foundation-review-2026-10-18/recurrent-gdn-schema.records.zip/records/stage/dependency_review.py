"""Read retained dependency/recipe JSON for the actual host link closure; no build."""
from pathlib import Path
import hashlib
import json

STAGE=Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
ARCH=STAGE.parent
BASE=ARCH/'immutable-alias-index/checks/20261019T111822/plan.json'
V20=ARCH/'cuda-fusion-precision/checks/20261019T111328/plan.json'
HEADER=ROOT/'include/hyle/compute/model_ops.h'

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def key(path): return str(Path(path).resolve()).casefold()
def identity(path):
    path=Path(path)
    return {'path':str(path),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def source_path(value):
    if isinstance(value,dict): return value.get('path')
    return value

def main():
    old=ARCH/'immutable-constant-alias/object-inventory.json'
    lookup={key(row['object']):row for row in read(old)['objects']}
    base=read(BASE)
    plans=[(BASE,base),(V20,read(V20))]
    by_object={}
    for path,plan in plans:
        for row in plan.get('compile',[]):
            if row.get('object'): by_object[key(row['object'])]=(path,row)
    closures={name:base['links'][name]['inputs'] for name in ('cpu','qwen')}
    cuda=V20.parent/'cuda-link-plan.json'
    closures['cuda']=[row['path'] for row in read(cuda)['inputs']]
    membership={}
    for name,paths in closures.items():
        for path in paths:
            if Path(path).suffix.lower()=='.obj': membership.setdefault(key(path),{'path':path,'closures':[]})['closures'].append(name)
    owners=[]; unknown=[]; observations=[]
    for obj,entry in membership.items():
        path=Path(entry['path']); source=None; headers=[]; evidence=[]; command=None
        if obj in lookup:
            row=lookup[obj];source=source_path(row.get('source'));headers=row.get('headers',[])
            evidence.append({'path':str(old),'kind':'recorded complete object dependency inventory'})
        candidates=[]
        if obj in by_object:
            plan_path,row=by_object[obj];source=source_path(row.get('source'));command=row.get('command')
            evidence.append({'path':str(plan_path),'kind':'actual object compile recipe'})
        receipt=path.with_name(path.stem+'-identity.json')
        if receipt.exists():
            row=read(receipt);source=source or source_path(row.get('source'));command=command or row.get('command')
            evidence.append({'path':str(receipt),'kind':'matching object identity receipt'})
            headers=headers or [r.get('path') for r in row.get('current_hyle_dependency_identities',[])]
        if command:
            for i,arg in enumerate(command[:-1]):
                if arg.lower()=='/sourcedependencies':candidates.append(Path(command[i+1]))
            if source is None:
                source=next((arg for arg in command if arg.lower().endswith(('.cc','.cu'))),None)
        candidates.extend(path.with_name(path.stem+suffix) for suffix in ('-deps.json','-dependencies.json'))
        for candidate in dict.fromkeys(candidates):
            if not candidate.exists():continue
            data=read(candidate).get('Data',{})
            if data.get('Source') and data.get('Includes') is not None:
                source=source or data['Source'];headers=data['Includes']
                evidence.append({'path':str(candidate),'kind':'MSVC actual source dependencies'})
                break
        normalized=[source_path(value) for value in headers]
        has_header=any(value and key(value)==key(HEADER) for value in normalized)
        if has_header:
            if not source:raise ValueError('Header owner lacks source identity: '+str(path))
            owners.append({**entry,'source':source,'evidence':evidence,
                           'header':identity(HEADER),'command_template':command})
        elif not source or (not headers and Path(source).suffix.lower()!='.cu'):
            unknown.append({**entry,'source':source,'evidence':evidence})
        observations.append({'object':str(path),'source':source,'header_present':has_header,'dependency_entries':len(headers)})
    result={'state':'Offline dependency inventory only; no build or source application.',
        'base_plan':identity(BASE),'v20_plan':identity(V20),'cuda_link_plan':identity(cuda),
        'closure_absolute_input_counts':{name:len(paths) for name,paths in closures.items()},
        'header_dependent_object_count':len(owners),'owners':owners,'unresolved_objects':unknown,
        'scope':'Recompile these linked host owners against the new header, preserving their actual compile definitions/recipes. Newly added test TUs below also need fresh compilation. No CUDA native TU or SDK requires rebuilding for this header.',
        'additional_changed_test_TUs':['tests/compute_ops/operation_test.cc','tests/compute_provider_ggml/cpu_provider_test.cc','tests/compute_provider_ggml_cuda/tensor_test.cc'],
        'cuda_private_plan_note':'The retained v20 CUDA closure predates the alias-index private PlanState change. Replace its eight old core owners with the already-fresh corresponding 111822 alias objects before any future CUDA relink; CPU/Qwen bases already contain them. This needs no repeat core compilation.',
        'observations':observations}
    (STAGE/'inline-dependencies.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'owners':len(owners),'unknown':len(unknown),'counts':result['closure_absolute_input_counts']}))
    for row in unknown:print('UNRESOLVED',row['path'])

if __name__=='__main__': main()
