"""Scratch-only recurrent GDN schema/qualification and focused regression overlay."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def once(text, old, new):
    if text.count(old) != 1: raise ValueError('Nonunique anchor: '+old[:100])
    return text.replace(old, new)


def main():
    sources = {}
    def load(name):
        data = (ROOT/name).read_bytes()
        sources[name] = [data, None]
        return data.decode('utf-8').replace('\r\n', '\n')
    def put(name, text):
        # Existing files contain historical mixed line endings. Retain every
        # unchanged line byte-for-byte rather than normalize the whole TU.
        original = sources[name][0].decode('utf-8').splitlines(keepends=True)
        previous = [line.rstrip('\r\n') for line in original]
        current = text.splitlines()
        newline = '\r\n' if sources[name][0].count(b'\r\n') > sources[name][0].count(b'\n') / 2 else '\n'
        result = []
        for tag, a, b, c, d in difflib.SequenceMatcher(None, previous, current, autojunk=False).get_opcodes():
            result.extend(original[a:b] if tag == 'equal' else
                          [line + newline for line in current[c:d]])
        sources[name][1] = ''.join(result).encode('utf-8')

    name = 'include/hyle/compute/model_ops.h'
    text = load(name)
    text = once(text, '#include <array>\n', '#include <algorithm>\n#include <array>\n')
    text = once(text,
        '// Qwen recurrent region. Q/K are already normalized and use\n'
        "// GatedDeltaNet's head mapping. Inputs are Q, K, V, raw a, raw b, negative\n"
        '// decay coefficient, dt bias, state; outputs are attended values and state.\n'
        '// Raw a/b are [1,T,H,1]; the coefficient and dt bias broadcast [1,1,H,1].\n',
        '// Scalar-gated recurrent region. Q/K are already normalized and use\n'
        "// GatedDeltaNet's cyclic head mapping, QKV types and explicit state contract.\n"
        '// Inputs are Q, K, V, raw a, raw b, decay coefficient, dt bias, state;\n'
        '// outputs are attended values and state. Raw a/b are [B,T,Hv,1];\n'
        '// coefficient and dt bias are shared per-head [1,1,Hv,1] parameters.\n')
    begin = text.index('    for (const auto &input : inputs)\n', text.index('struct RecurrentGatedDeltaNet final'))
    end = text.index('\n  }\n};', begin)
    text = text[:begin] + '''    // Ordinary GDN is the single authority for Q/K/V type, shape, cyclic
    // head grouping, state orientation and snapshot-count/output rules.
    const std::array recurrent{inputs[0], inputs[1], inputs[2], inputs[3],
                               inputs[4], inputs[7]};
    std::array<TensorDesc, 2> inferred;
    const auto status = compute::infer_output_descriptions(
        Operation(GatedDeltaNet{.snapshot_count = snapshot_count}),
        recurrent, inferred);
    if (!status.ok()) return status;
    const auto value = inputs[2].dimensions();
    const std::array gate_shape{value[0], value[1], value[2], std::int64_t{1}};
    const std::array parameter_shape{std::int64_t{1}, std::int64_t{1},
                                     value[2], std::int64_t{1}};
    for (std::size_t port = 3; port != 7; ++port) {
      const auto &input = inputs[port];
      const auto &shape = port < 5 ? gate_shape : parameter_shape;
      if (!input.valid() || !input.is_plain() ||
          input.data_type() != DataType::kFloat32 || input.rank() != 4 ||
          !std::ranges::equal(input.dimensions(), shape))
        return Status::InvalidArgument(
            "RecurrentGatedDeltaNet requires F32 raw gates [B,T,Hv,1] and shared parameters [1,1,Hv,1]");
    }
    // Do not publish one output before all composite-port checks succeed.
    outputs[0] = inferred[0];
    outputs[1] = inferred[1];
    return Status::Ok();''' + text[end:]
    put(name, text)

    name = 'src/compute_provider_ggml_cuda/tensor_program.cc'
    text = load(name)
    text = once(text,
        '    return v[2] % q[2] == 0 && q[3] == v[3] &&\n'
        '           scores <= std::size_t{INT32_MAX} &&\n',
        '    // The native launch uses grid.y=B and only instantiates these\n'
        '    // square-state depths. Its supports_op alone does not check them.\n'
        '    return q[0] <= 65535 &&\n'
        '           (q[3] == 16 || q[3] == 32 || q[3] == 64 || q[3] == 128) &&\n'
        '           v[2] % q[2] == 0 && q[3] == v[3] &&\n'
        '           scores <= std::size_t{INT32_MAX} &&\n')
    put(name, text)

    name = 'tests/compute_ops/operation_test.cc'
    text = load(name)
    extra = r'''
TEST(OperationModelOps, RecurrentRegionReusesParameterizedGdnAndAtomicInference) {
  const auto f32 = DataType::kFloat32;
  // These are mathematical domains, deliberately outside the old model/head
  // list and native square-depth domains. Inference grants no provider route.
  const std::array<std::array<std::int64_t, 6>, 2> shapes{{
      {2, 5, 2, 6, 32, 48}, {3, 4, 3, 9, 17, 24}}};
  for (const auto type : {DataType::kFloat16, DataType::kBFloat16, f32})
    for (const auto &shape : shapes) {
      const auto [b, t, hk, hv, dk, dv] = shape;
      const auto raw = tensor(f32, b, t, hv, 1);
      const auto parameter = tensor(f32, 1, 1, hv, 1);
      std::array inputs{tensor(type, b, t, hk, dk), tensor(type, b, t, hk, dk),
          tensor(type, b, t, hv, dv), raw, raw, parameter, parameter,
          tensor(f32, b, hv, dv, dk)};
      const auto bytes = static_cast<std::int64_t>(data_type_size(type));
      const std::array padded{t * hk * (dk + 1) * bytes,
          hk * (dk + 1) * bytes, (dk + 1) * bytes, bytes};
      inputs[0] = inputs[1] = TensorDesc::strided_bytes(
          type, inputs[0].dimensions(), padded).value();
      for (const std::uint32_t snapshots : {1U, 3U}) {
        const std::array ordinary{inputs[0], inputs[1], inputs[2],
                                  inputs[3], inputs[4], inputs[7]};
        std::array<TensorDesc, 2> expected, actual;
        ASSERT_TRUE(infer_output_descriptions(
            Operation(GatedDeltaNet{.snapshot_count = snapshots}), ordinary, expected).ok());
        ASSERT_TRUE(infer_output_descriptions(
            model_ops::recurrent_gated_delta_net(snapshots), inputs, actual).ok());
        EXPECT_EQ(actual, expected);
        EXPECT_EQ(actual[0].data_type(), type);
        const auto sentinel = tensor(f32, 7);
        for (const std::size_t port : {3U, 4U, 5U, 6U}) {
          auto invalid = inputs;
          invalid[port] = port < 5 ? tensor(f32, b, t, hv, dv) : raw;
          actual = {sentinel, sentinel};
          EXPECT_TRUE(infer_output_descriptions(
              model_ops::recurrent_gated_delta_net(snapshots), invalid, actual).IsInvalidArgument());
          EXPECT_EQ(actual, (std::array{sentinel, sentinel}));
        }
        for (const std::uint32_t invalid_count : {0U, static_cast<std::uint32_t>(t + 1)}) {
          actual = {sentinel, sentinel};
          EXPECT_TRUE(infer_output_descriptions(
              model_ops::recurrent_gated_delta_net(invalid_count), inputs, actual).IsInvalidArgument());
          EXPECT_EQ(actual, (std::array{sentinel, sentinel}));
        }
      }
    }
}

'''
    text = once(text, 'TEST(OperationModelOps, BFloatLinearF32KeepsNativeScorePrecision) {',
                extra + 'TEST(OperationModelOps, BFloatLinearF32KeepsNativeScorePrecision) {')
    put(name, text)

    for name, suite in [('tests/compute_provider_ggml/cpu_provider_test.cc', 'GgmlCpuProvider'),
                         ('tests/compute_provider_ggml_cuda/tensor_test.cc', 'GgmlCudaTensor')]:
        text = load(name)
        start = text.index('TEST('+suite+', RecurrentTokenBlockBroadcastsParametersAndPublishesSnapshots) {')
        end = text.index('\nTEST(', start + 5)
        case = text[start:end]
        case = once(case,
            '  gdn_snapshot_fixture::Fixture fixture(3, 1, 3, 16, 16, 128);\n',
            '  const std::array<std::array<std::int64_t, 4>, 2> shapes{{\n'
            '      {1, 16, 16, 128}, {2, 2, 6, 32}}};\n'
            '  for (const auto &shape : shapes) {\n'
            '  SCOPED_TRACE(shape[0]);\n  SCOPED_TRACE(shape[2]);\n  SCOPED_TRACE(shape[3]);\n'
            '  gdn_snapshot_fixture::Fixture fixture(3, shape[0], 3, shape[1], shape[2], shape[3]);\n')
        case = case.replace('{1, 1, 16, 1}', '{1, 1, shape[2], 1}')
        case = once(case, 'std::vector<float> coefficient(16), bias(16);',
                    'std::vector<float> coefficient(static_cast<std::size_t>(shape[2])), bias(coefficient.size());')
        case = case.replace('bias[i % 16]', 'bias[i % bias.size()]')
        case = case.replace('coefficient[i % 16]', 'coefficient[i % coefficient.size()]')
        last_brace = case.rfind('\n}')
        body = case.index('  SCOPED_TRACE(shape[0]);')
        indented = '\n'.join('  '+line if line else ''
                             for line in case[body:last_brace].split('\n'))
        case = case[:body] + indented + '\n  }' + case[last_brace:]
        text = text[:start] + case + text[end:]
        if suite == 'GgmlCudaTensor':
            negative = r'''
TEST(GgmlCudaTensor, RecurrentSchemaDoesNotGrantUnavailableNativeDepthOrBatch) {
  auto ctx = context();
  auto memory = cuda::MemoryResource::create(ctx, cuda::MemoryKind::kDevice).value();
  const auto f32 = DataType::kFloat32;
  // Descriptor preparation must decline before native construction/launch.
  // No tensor payload or large batch backing is allocated by this test.
  for (const auto &shape : std::array<std::array<std::int64_t, 2>, 2>{{
           {1, 24}, {65536, 16}}}) {
    const auto b = shape[0], d = shape[1];
    const auto raw = dense(f32, {b, 1, 1, 1});
    const auto parameter = dense(f32, {1, 1, 1, 1});
    const std::array inputs{dense(f32, {b, 1, 1, d}), dense(f32, {b, 1, 1, d}),
        dense(f32, {b, 1, 1, d}), raw, raw, parameter, parameter,
        dense(f32, {b, 1, d, d})};
    const std::array ordinary{inputs[0], inputs[1], inputs[2],
                               inputs[3], inputs[4], inputs[7]};
    for (const bool composite : {false, true}) {
      const auto operation = composite ? model_ops::recurrent_gated_delta_net()
                                       : Operation(GatedDeltaNet{});
      const auto selected = composite ? std::span<const TensorDesc>(inputs)
                                      : std::span<const TensorDesc>(ordinary);
      std::array<TensorDesc, 2> outputs;
      ASSERT_TRUE(infer_output_descriptions(operation, selected, outputs).ok());
      const auto prepared = prepare(ctx, operation, selected, outputs, memory.ref());
      ASSERT_FALSE(prepared);
      EXPECT_TRUE(prepared.error().IsUnimplemented()) << prepared.error().message();
    }
  }
}

'''
        else:
            negative = r'''
TEST(GgmlCpuProvider, RecurrentSchemaDoesNotGrantUnavailableNativeTypesOrState) {
  auto context = Context::create(cpu::device(), ggml_cpu::provider()).value();
  const auto f32 = DataType::kFloat32;
  for (const auto type : {f32, DataType::kBFloat16}) {
    const auto dk = std::int64_t{32};
    const auto dv = std::int64_t{type == f32 ? 48 : 32};
    const auto raw = dense(f32, {2, 3, 6, 1});
    const auto parameter = dense(f32, {1, 1, 6, 1});
    const std::array inputs{dense(type, {2, 3, 2, dk}), dense(type, {2, 3, 2, dk}),
        dense(type, {2, 3, 6, dv}), raw, raw, parameter, parameter,
        dense(f32, {2, 6, dv, dk})};
    std::array<TensorDesc, 2> outputs;
    const auto operation = model_ops::recurrent_gated_delta_net();
    ASSERT_TRUE(infer_output_descriptions(operation, inputs, outputs).ok());
    const auto prepared = prepare(context, operation, inputs, outputs,
                                    hyle::mem::system_resource());
    ASSERT_FALSE(prepared);
    EXPECT_TRUE(prepared.error().IsUnimplemented()) << prepared.error().message();
  }
}

'''
        text = text[:start+len(case)] + negative + text[start+len(case):]
        put(name, text)

    changes, records = [], []
    for name, (before, after) in sources.items():
        for directory, data in [('before', before), ('source', after)]:
            target = STAGE/directory/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        changes.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
            fromfile='a/'+name, tofile='b/'+name))
        records.append({'source': name, 'before': identity(STAGE/'before'/name),
                        'after': identity(STAGE/'source'/name)})
    (STAGE/'changes.diff').write_text(''.join(changes).replace('\r\n','\n'), encoding='utf-8')
    (STAGE/'source-freeze.json').write_text(json.dumps({
        'state':'Scratch only; no product changes, compilation, tests or GPU.',
        'files':records, 'diff':identity(STAGE/'changes.diff'),
        'generator':identity(Path(__file__).resolve())}, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'files':len(records), 'diff':identity(STAGE/'changes.diff')}))


if __name__ == '__main__':
    main()
