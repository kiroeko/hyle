"""Read actual retained host recipes and prepare the GDN incremental closure.

No application, compilation, linking, tests, SDK changes, or native rebuild.
"""
from pathlib import Path
import collections
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parent
ROOT = STAGE.parents[2]
ALIAS = ARCH / 'immutable-alias-index/checks/20261019T111822'
CUDA = ARCH / 'cuda-fusion-precision/checks/20261019T111328'
INVENTORY = ARCH / 'immutable-constant-alias/object-inventory.json'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def key(path):
    return str(Path(path).resolve()).casefold()


def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def verify(row):
    if identity(row['path']) != row:
        raise ValueError('Retained linked identity differs: ' + row['path'])


def commands(path):
    data = read(path)
    return data if isinstance(data, list) else [data]


def definitions(command):
    return [item[2:] for item in command if item.lower().startswith('/d')]


def includes(command):
    result = []
    for item in command:
        for prefix in ('/external:i', '/i'):
            if item.lower().startswith(prefix):
                value = item[len(prefix):]
                result.append({'path': value, 'exists': Path(value).is_dir()})
                break
    return result


def main():
    dependency_path = STAGE / 'inline-dependencies.json'
    dependencies = read(dependency_path)
    original = {key(row['object']): row for row in read(INVENTORY)['objects']}
    bases = {'cpu': ALIAS / 'cpu-link-plan.json', 'qwen': ALIAS / 'qwen-link-plan.json',
             'cuda': CUDA / 'cuda-link-plan.json'}
    links = {name: read(path) for name, path in bases.items()}
    linked = {name: {key(row['path']): row for row in link['inputs']} for name, link in links.items()}
    expected_counts = {'cpu': 112, 'qwen': 125, 'cuda': 133}
    for name, rows in linked.items():
        if len(rows) != expected_counts[name]:
            raise ValueError('Unexpected retained closure: ' + name)
        if any(not Path(row['path']).is_file() for row in rows.values()):
            raise ValueError('Missing retained input: ' + name)
    freeze = read(STAGE / 'source-freeze.json')
    changed = {row['source']: row for row in freeze['files']}
    for name, row in changed.items():
        actual = identity(ROOT / name)
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Applied source differs from reviewed after: ' + name)
    header = identity(ROOT / 'include/hyle/compute/model_ops.h')

    compile_rows = []
    observed_dependencies = collections.Counter()
    for index, owner in enumerate(dependencies['owners']):
        objkey = key(owner['path'])
        old = [linked[name][objkey] for name in owner['closures']]
        if any(row['sha256'] != old[0]['sha256'] for row in old):
            raise ValueError('Same object has conflicting linked identities')
        verify(old[0])
        command = owner.get('command_template')
        evidence = list(owner['evidence'])
        origin = original.get(objkey)
        if command is None:
            if not origin or not origin.get('command') or not origin.get('recipe'):
                raise ValueError('No literal retained command for ' + owner['path'])
            command = origin['command']
            recipe_path = Path(origin['recipe'])
            matches = [(i, row) for i, row in enumerate(commands(recipe_path))
                       if row.get('command') == command]
            if len(matches) != 1:
                raise ValueError('Recorded literal command is not unique in its recipe')
            recipe_index, recipe_row = matches[0]
            if recipe_row.get('exit', recipe_row.get('exit_code')) != 0:
                raise ValueError('Retained command was not a successful compile')
        else:
            # Prefer the actual per-object identity, then the actual compile
            # plan. Both preserve the exact compiler command, not a new policy.
            candidates = []
            for item in evidence:
                p = Path(item['path'])
                if not p.is_file():
                    continue
                data = read(p)
                rows = data if isinstance(data, list) else data.get('compile', [data])
                for i, row in enumerate(rows):
                    if row.get('command') == command:
                        candidates.append((p, i, row))
            if not candidates:
                raise ValueError('Cannot locate actual compile recipe for ' + owner['path'])
            recipe_path, recipe_index, recipe_row = candidates[0]
        source = Path(owner['source']).resolve()
        name = source.relative_to(ROOT).as_posix()
        if not any(key(item) == key(source) for item in command if item.lower().endswith(('.cc', '.cpp'))):
            raise ValueError('Literal recipe source mismatch: ' + name)
        deps = []
        for item in evidence:
            if item['kind'] == 'MSVC actual source dependencies':
                deps.append(Path(item['path']))
        for position, argument in enumerate(command[:-1]):
            if argument.lower() == '/sourcedependencies' and Path(command[position + 1]).is_file():
                deps.append(Path(command[position + 1]))
        deps = list({key(path): path for path in deps}.values())
        actual_header_seen = False
        for path in deps:
            data = read(path).get('Data', {})
            actual_header_seen |= any(key(path) == key(header['path']) for path in data.get('Includes', []))
        basis = 'MSVC actual sourceDependencies' if actual_header_seen else 'conservative recorded dependency inventory plus current literal include traversal'
        observed_dependencies[basis] += 1
        compile_rows.append({
            'tag': f'{index:02d}-' + source.parent.name + '-' + source.stem,
            'source_name': name, 'source': identity(source), 'application_target': str(source),
            'operation': 'replace', 'closures': owner['closures'], 'old_object': old[0],
            'recipe': identity(recipe_path), 'recipe_index': recipe_index,
            'recipe_source_identity': recipe_row.get('source'),
            'command_template': command, 'definitions': definitions(command),
            'include_directories': includes(command), 'header': header,
            'dependency_basis': basis, 'actual_source_dependencies': [identity(path) for path in deps],
            'inventory_evidence': evidence,
            'reviewed_source_change': name in changed,
            'source_before_and_after': changed.get(name),
        })

    # Add the two complete public fixtures to CPU. HYLE_STATIC excludes the
    # unrelated shared-library tests in operation_test.cc, so no test DLL or
    # producer shim is required. The CUDA tensor fixture is already an owner.
    additions = (
        ('tests/compute_provider_ggml/cpu_provider_test.cc', ROOT / '.scratch/mtp-gdn-2026-10-18/commands.json', 14),
        ('tests/compute_ops/operation_test.cc', ARCH / 'native-ready-pages/schema/commands.json', 25),
    )
    for name, recipe_path, recipe_index in additions:
        recipe_row = commands(recipe_path)[recipe_index]
        if recipe_row.get('exit', recipe_row.get('exit_code')) != 0:
            raise ValueError('Additional fixture lacks successful retained recipe')
        command = recipe_row['command']
        defs = definitions(command)
        if 'HYLE_STATIC' not in defs or 'HYLE_TEST_GGML_CPU=1' not in defs or 'HYLE_COMPUTE_GGML_CPU=1' not in defs:
            raise ValueError('Additional fixture definitions differ from CPU closure')
        if not any(key(item) == key(ROOT / name) for item in command if item.lower().endswith('.cc')):
            raise ValueError('Additional fixture source mismatch')
        compile_rows.append({
            'tag': '28-cpu-provider-test' if name.endswith('cpu_provider_test.cc') else '29-ops-test',
            'source_name': name, 'source': identity(ROOT / name), 'application_target': str(ROOT / name),
            'operation': 'add', 'closures': ['cpu'], 'old_object': None,
            'recipe': identity(recipe_path), 'recipe_index': recipe_index,
            'recipe_source_identity': recipe_row.get('source'), 'command_template': command,
            'definitions': defs, 'include_directories': includes(command), 'header': header,
            'dependency_basis': 'changed public product fixture; fresh compilation required',
            'actual_source_dependencies': [], 'reviewed_source_change': True,
            'source_before_and_after': changed[name],
        })

    # CUDA tests still contain the eight pre-index Graph core objects. Replace
    # exactly these with the previously compiled alias-index object identities;
    # none of these owners includes model_ops.h and none requires recompilation.
    alias_plan = read(ALIAS / 'plan.json')
    alias_recipes = read(ARCH / 'immutable-alias-index/host-recipes.json')
    core = []
    for fresh, old in zip(alias_plan['compile'][:8], alias_recipes['compile'][:8], strict=True):
        if fresh['source']['path'] != old['application_target']:
            raise ValueError('Alias core recipe ordering differs')
        source_key = key(old['old_object']['path'])
        if source_key not in linked['cuda']:
            raise ValueError('Old Graph core not present in CUDA closure')
        current = read(ALIAS / (fresh['tag'] + '-identity.json'))['object']
        verify(current)
        if key(current['path']) not in linked['qwen'] or key(current['path']) not in linked['cpu']:
            raise ValueError('Fresh Graph core missing from latest alias closures')
        core.append({'source_name': Path(fresh['source']['path']).relative_to(ROOT).as_posix(),
                     'old_object': linked['cuda'][source_key], 'replacement_object': current,
                     'recipe': identity(ALIAS / (fresh['tag'] + '-identity.json'))})

    edits = {}
    for name in ('cpu', 'qwen', 'cuda'):
        replacements = [{'old_object': row['old_object'], 'replacement_compile_tag': row['tag']}
                        for row in compile_rows if name in row['closures'] and row['operation'] == 'replace']
        added = [row['tag'] for row in compile_rows if name in row['closures'] and row['operation'] == 'add']
        if len({key(row['old_object']['path']) for row in replacements}) != len(replacements):
            raise ValueError('Duplicate header owner replacement')
        for row in replacements:
            if sum(key(item) == key(row['old_object']['path']) for item in links[name]['command']) != 1:
                raise ValueError('Nonunique linked command owner')
        cached_core = core if name == 'cuda' else []
        if {key(row['old_object']['path']) for row in replacements}.intersection(key(row['old_object']['path']) for row in cached_core):
            raise ValueError('Graph ABI and inline header replacements overlap')
        edits[name] = {
            'base_link_plan': identity(bases[name]), 'base_absolute_inputs': expected_counts[name],
            'fresh_owner_replacements': replacements, 'fresh_owner_replacement_count': len(replacements),
            'cached_alias_core_replacements': cached_core, 'cached_alias_core_replacement_count': len(cached_core),
            'add_compile_tags': added, 'add_count': len(added),
            'expected_absolute_inputs': expected_counts[name] + len(added),
            'expected_total_replaced_objects': len(replacements) + len(cached_core),
        }
    result = {
        'state': 'Recipes only; no application, compilation, link, test or GPU command executed.',
        'source_freeze': identity(STAGE / 'source-freeze.json'), 'application': identity(STAGE / 'application.json'),
        'dependency_inventory': identity(dependency_path), 'legacy_object_inventory': identity(INVENTORY),
        'current_public_header': header, 'header_dependent_object_count': len(dependencies['owners']),
        'fresh_host_compile_count': len(compile_rows), 'native_compile_count': 0,
        'compile': compile_rows, 'links': edits, 'dependency_evidence_counts': dict(observed_dependencies),
        'additional_fixture_policy': 'Append the full CPU provider and Operation test TUs to CPU; replace the already-linked CUDA tensor fixture. All use the existing static test/provider libraries.',
        'extra_Dll_import_or_producer_required': False,
        'ops_fixture_reason': 'operation_test.cc guards all make_shared_* calls with !defined(HYLE_STATIC); the successful retained recipe defines HYLE_STATIC. The producer DLL is not linked or simulated.',
        'symbol_scope': 'No new non-header runtime/provider implementation is introduced by these fixtures. Existing CPU link owns ggml quantizers, hyle CPU/operation/memory and GTest; CUDA tensor fixture is a replacement, not a new symbol family. Actual link success remains unverified.',
        'command_adaptation': 'Compile current product application_target after applying the overlay. Preserve literal compiler, /D, /I, /external:I and /FI flags; replace only source and /Fo,/Fd,/sourceDependencies destinations into this stage/checks. Always emit fresh /sourceDependencies and verify exactly the current ROOT/include/hyle/compute/model_ops.h. Do not compile the scratch product copy using missing local private-header roots.',
        'public_header_resolution': 'All retained recipes place the sole Hyle public include directory at ROOT/include; no old SDK contains a Hyle public model_ops.h include root. Native GGML/CUDA headers are provider dependencies and are not recompiled.',
        'source_identity_note': 'Current/applied source hashes intentionally differ from historical recipe source hashes for the changed files. old_object SHA binds the actual linked artifact; source/source_before_and_after bind the new compile input.',
        'CPU_macro_policy': 'Preserve the original CPU provider/test macros including HYLE_STATIC and HYLE_TEST_GGML_CPU=1. Do not add TORCH test macros to the new plain GGML CPU fixture.',
        'CUDA_macro_policy': 'Preserve each original CUDA/FlashInfer/Torch-CUDA provider-specific recipe and the v20 provider-version forced include. Refresh every listed inline model owner; retain native math objects and SDK libraries.',
        'old_images_required': False,
        'unresolved_original_inventory_objects': dependencies['unresolved_objects'],
        'limits': 'This is an exact offline recipe and retained object identity check, not a compile/link success claim. The original inventory includes conservative literal-traversal owners where an old sourceDependencies JSON is not retained; they are included rather than risking a stale inline vtable.',
    }
    (STAGE / 'host-recipes.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'fresh_host_TUs': len(compile_rows), 'header_owners': len(dependencies['owners']),
                      'dependency_evidence_counts': dict(observed_dependencies),
                      'links': {name: {k: row[k] for k in ('fresh_owner_replacement_count', 'cached_alias_core_replacement_count', 'add_count', 'expected_absolute_inputs')} for name, row in edits.items()}}))


if __name__ == '__main__':
    main()
