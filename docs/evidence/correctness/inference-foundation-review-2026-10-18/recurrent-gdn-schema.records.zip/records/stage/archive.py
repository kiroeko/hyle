"""Archive the applied and tested GDN schema/host closure, without binary caches."""
from pathlib import Path
import hashlib
import json
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
PLAN = STAGE / 'checks/20261019T113131/plan.json'
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/recurrent-gdn-schema.zip'
EXCLUDED = {'.exe', '.obj', '.pdb', '.lib', '.exp', '.dll', '.pyc', '.map'}
DOCS = (
    'docs/user/compute.md',
    'docs/architecture/compute-design.md',
    'docs/developer/current-work.md',
    'docs/implementation/model-operators.md',
    'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md',
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def key(path):
    return str(Path(path).resolve()).casefold()


def verify(row):
    path = Path(row['path']).resolve()
    data = path.read_bytes()
    if len(data) != row['bytes'] or sha(data) != row['sha256']:
        raise ValueError('Frozen file drift: ' + str(path))
    return path


def match(path, row):
    data = path.read_bytes()
    if len(data) != row['bytes'] or sha(data) != row['sha256']:
        raise ValueError('Applied source/snapshot differs: ' + str(path))


def main():
    if DEST.exists():
        raise ValueError('Archive already exists; refusing replacement')
    plan = read(PLAN)
    freeze = read(STAGE / 'source-freeze.json')
    application = read(STAGE / 'application.json')
    if len(freeze['files']) != 5 or len(plan['compile']) != 30 or plan['native_TUs'] != 0:
        raise ValueError('Expected the five-file, thirty-host GDN increment')
    verify(application['freeze'])
    for row in freeze['files']:
        verify(row['before'])
        verify(row['after'])
        match(ROOT / row['source'], row['after'])
    verify(freeze['diff'])
    for row in application['files']:
        verify(row)
    header = plan['public_inline_header']
    verify(header)
    match(STAGE / 'source/include/hyle/compute/model_ops.h', header)
    snapshot_rows = {}
    deps_rows = []
    for row in plan['compile']:
        source = verify(row['source'])
        relative = source.relative_to(ROOT).as_posix()
        match(STAGE / 'source' / relative, row['source'])
        snapshot_rows[relative] = row['source']
        deps_path = PLAN.parent / (row['tag'] + '-deps.json')
        deps = read(deps_path)['Data']
        if key(deps['Source']) != key(source) or key(header['path']) not in {key(path) for path in deps['Includes']}:
            raise ValueError('Compiled owner did not read the current public header: ' + row['tag'])
        compiled = read(PLAN.parent / (row['tag'] + '-identity.json'))
        if compiled['public_header'] != header or compiled['source'] != row['source']:
            raise ValueError('Compiled source/public header receipt differs')
        deps_rows.append({'tag': row['tag'], 'path': str(deps_path), 'sha256': sha(deps_path.read_bytes()),
                          'current_public_model_header_present': True})
    if len(snapshot_rows) != 29:
        raise ValueError('Expected29 distinct host source snapshots')
    actual_snapshots = {path.relative_to(STAGE / 'source').as_posix()
                        for path in (STAGE / 'source').rglob('*') if path.is_file()}
    if actual_snapshots != set(snapshot_rows) | {'include/hyle/compute/model_ops.h'}:
        raise ValueError('Unmeasured source draft found in the retained source directory')

    external = []
    frozen_by_entry = {}
    for row in plan['frozen']:
        path = verify(row)
        if path.is_relative_to(STAGE) or path.suffix.lower() in EXCLUDED:
            continue
        if not path.is_relative_to(ROOT):
            raise ValueError('Unexpected non-workspace frozen text input')
        name = 'tested-inputs/' + path.relative_to(ROOT).as_posix()
        external.append((name, path))
        frozen_by_entry[name] = row
    counts = {'cpu': 114, 'cuda': 133, 'qwen': 125}
    for arm, count in counts.items():
        actual = read(PLAN.parent / (arm + '-link-plan.json'))
        if len(plan['links'][arm]['inputs']) != count or len(actual['inputs']) != count:
            raise ValueError('Actual link input count differs: ' + arm)
        if len({key(row['path']) for row in actual['inputs']}) != count:
            raise ValueError('Duplicate actual linked input')
        verify(read(PLAN.parent / (arm + '-image.json')))

    build = read(PLAN.parent / 'summary.json')
    checks = read(PLAN.parent / 'checks-summary.json')
    model = read(STAGE / 'correctness/summary.json')
    unknowns = read(STAGE / 'unresolved-review.json')
    if not all(row['passed'] for row in (build, checks, model)):
        raise ValueError('Expected successful retained build/tests/model observations')
    if checks['different_cases'] != 15 or any(row['skipped_or_not_run'] for row in checks['reports'].values()):
        raise ValueError('Expected15 exact executed GDN cases without skips')
    if model['observation']['equal_vectors'] != 64 or not model['observation']['all_outputs_finite']:
        raise ValueError('Expected64 exact finite model vectors')
    if len(unknowns['resolved_nonowners']) != 25 or unknowns['remaining_unresolved'] or unknowns['additional_model_header_owners']:
        raise ValueError('Original25 unknown objects were not fully classified')

    scope = {
        'plan_sha256': sha(PLAN.read_bytes()),
        'freeze_sha256': sha((STAGE / 'source-freeze.json').read_bytes()),
        'application_sha256': sha((STAGE / 'application.json').read_bytes()),
        'applied_product_after_files_verified': 5,
        'actual_compile_count': 30, 'distinct_source_snapshot_count': 29,
        'public_inline_header': header, 'actual_compiled_header_dependencies': deps_rows,
        'actual_link_inputs': counts,
        'different_executed_cases': 15, 'model_equal_vectors': 64,
        'original_unknown_objects_classified_nonowners': 25,
        'documentation_is_current_context_not_an_additional_test_claim': list(DOCS),
        'unmeasured_or_unapplied_source_drafts_included': False,
        'SDKs_models_binary_caches_maps_tmp_excluded': True,
        'historical_scratch_state_labels_are_preserved': True,
        'applied_and_tested_state_is_proven_by_application_actual_deps_build_and_results': True,
    }
    (STAGE / 'archive-scope.json').write_text(json.dumps(scope, indent=2) + '\n', encoding='utf-8', newline='\n')
    files = external + [('documentation/' + relative, ROOT / relative) for relative in DOCS]
    for path in sorted(STAGE.rglob('*')):
        if path.is_symlink():
            raise ValueError('Unexpected symlink')
        if not path.is_file() or 'tmp' in path.relative_to(STAGE).parts or path.suffix.lower() in EXCLUDED:
            continue
        if path.name == 'archive-verification.json':
            raise ValueError('Unexpected old archive receipt')
        files.append(('stage/' + path.relative_to(STAGE).as_posix(), path))
    if len({name for name, _ in files}) != len(files):
        raise ValueError('Duplicate archive entry')

    records = []
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in files:
            data = path.read_bytes()
            record = {'entry': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(data)}
            expected = frozen_by_entry.get(name)
            if expected and (record['bytes'], record['sha256']) != (expected['bytes'], expected['sha256']):
                raise ValueError('Frozen source changed during archive write')
            records.append(record)
            archive.writestr(name, data)
        archive.writestr('manifest.json', json.dumps(records, indent=2) + '\n')
    with zipfile.ZipFile(DEST) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive CRC failure')
        if len(archive.namelist()) != len(records) + 1:
            raise ValueError('Archive entry count differs')
        for row in records:
            data = archive.read(row['entry'])
            if len(data) != row['bytes'] or sha(data) != row['sha256']:
                raise ValueError('Archive payload hash differs')
        if any(Path(name).suffix.lower() in EXCLUDED or 'tmp' in Path(name).parts for name in archive.namelist()):
            raise ValueError('Excluded cache or map entered archive')
    receipt = {
        'path': str(DEST), 'bytes': DEST.stat().st_size, 'sha256': sha(DEST.read_bytes()),
        'payloads': len(records), 'entries_including_manifest': len(records) + 1,
        'uncompressed_payload_bytes': sum(row['bytes'] for row in records),
        'CRC_and_every_payload_SHA_verified': True,
        'applied_product_after_files_verified': 5,
        'actual_compiles_and_header_dependencies_verified': 30,
        'unique_host_source_snapshots_verified': 29,
        'public_header_snapshot_verified': True,
        'actual_link_inputs': counts,
        'exact_tests_and_model_raw_records_included': {'cases': 15, 'vectors': 64},
        'original_unknown_nonowner_records_included': 25,
        'SDK_models_binary_cache_maps_tmp_excluded': True,
        'unapplied_source_drafts_excluded': True,
    }
    text = json.dumps(receipt, indent=2) + '\n'
    (STAGE / 'archive-verification.json').write_text(text, encoding='utf-8', newline='\n')
    DEST.with_name('recurrent-gdn-schema-archive.json').write_text(text, encoding='utf-8', newline='\n')
    print(text, flush=True)


if __name__ == '__main__':
    main()
