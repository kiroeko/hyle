from pathlib import Path
import json
import os
import shlex
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
CACHE = ROOT / '.scratch/bench-api-runtime/vulkan/build'
DENSE = ROOT / '.scratch/inference-fusion-quantization-2026-10-18/vulkan-dense-constant'
old = json.loads((ROOT / '.scratch/inference-foundation-review-2026-10-18/batched-rope/vulkan-commands.json').read_text())
base = next(x['command'] for x in old if x['tag'] == '1-vulkan-region-compile')
cl = Path(base[0])
flags = base[1:-2]
if '/WX' not in flags:
    flags += ['/WX']
rows = (CACHE / 'build.ninja').read_text().splitlines()
start = next(i for i, s in enumerate(rows) if s.startswith('build ') and
             'native_program.cc.obj:' in s and 'iree_vulkan' in s)
fields = dict(s.strip().split(' = ', 1) for s in rows[start + 1:start + 11]
              if ' = ' in s)
native_flags = shlex.split(fields['DEFINES'] + ' ' + fields['FLAGS'] + ' ' +
                          fields['INCLUDES'], posix=False)
native_flags = ['/nologo', '/c', '/WX', *native_flags]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment
env = windows_compiler_environment({'CMAKE_CXX_COMPILER': str(cl),
                                    'CMAKE_C_COMPILER': str(cl)})
env['PATH'] = str(ROOT / '.scratch/build-compute-v2-dev/bin') + os.pathsep + env['PATH']
env.update(VSLANG='1033', DISABLE_VULKAN_OBS_CAPTURE='1', VK_LOADER_LAYERS_DISABLE='~all~')
records = json.loads((OUT / 'commands.json').read_text()) if (OUT / 'commands.json').exists() else []


def run(tag, command):
    command = list(map(str, command))
    number = sum(x['tag'] == tag for x in records)
    prefix = f'attempt{number}-' if number else ''
    started = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=180)
    (OUT / (prefix + tag + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (prefix + tag + '.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag=tag, command=command, exit=result.returncode,
                        seconds=time.monotonic() - started))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2) + '\n',
                                      encoding='utf-8', newline='\n')
    print(tag, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:])
        print(result.stderr.decode(errors='replace')[-2000:])
        raise SystemExit(result.returncode)


if __name__ == '__main__':
    products = [
        ('src/compute_provider_iree_vulkan/native_program.cc', 'native-program', native_flags),
        ('src/compute_route_vulkan/vulkan_iree.cc', 'iree', flags),
        ('tests/graph_route_vulkan/iree_test.cc', 'tests', flags),
    ]
    for source, name, options in products:
        obj = OUT / (name + '.obj')
        if not obj.is_file() or obj.stat().st_mtime < (ROOT / source).stat().st_mtime:
            run(name + '-compile', [cl, *options, ROOT / source, '/Fo' + str(obj)])
    link = next(x['command'] for x in json.loads((DENSE / 'commands.json').read_text())
                if 'final-link' in x['tag'])
    command = []
    for arg in link:
        if arg.startswith('/OUT:'):
            arg = '/OUT:' + str(OUT / 'tests.exe')
        elif arg.startswith('/MAP:'):
            arg = '/MAP:' + str(OUT / 'tests.map')
        elif arg == str(DENSE / 'tests.obj'):
            continue
        command.append(arg)
    command += [str(OUT / (name + '.obj')) for _, name, _ in products]
    run('link', command)
    run('tests', [OUT / 'tests.exe',
        '--gtest_filter=VulkanGraph.OfficialConstantBanksBorrowOwnedStorageAcrossSlots:VulkanGraph.OriginalOfficialGroupedFp4Fp8SharedDistinctAndChecked',
        '--gtest_color=no'])
