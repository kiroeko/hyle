from pathlib import Path
import difflib
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
FILES = [
    'src/compute_provider_iree_vulkan/native_program.h',
    'src/compute_provider_iree_vulkan/native_program.cc',
    'src/compute_route_vulkan/vulkan_internal.h',
    'src/compute_route_vulkan/vulkan_iree.h',
    'src/compute_route_vulkan/vulkan_iree.cc',
    'tests/graph_route_vulkan/iree_test.cc',
]


def identity(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(part)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n',
                            encoding='utf-8', newline='\n')


internal = ROOT / FILES[2]
before_internal = OUT / 'before' / FILES[2]
if not before_internal.exists():
    accessor = ('  static const std::shared_ptr<InvocationState> &\n'
                '  invocation(const Invocation &value) noexcept {\n'
                '    return value.state_;\n  }\n')
    text = internal.read_text()
    assert text.count(accessor) == 1
    before_internal.parent.mkdir(parents=True, exist_ok=True)
    before_internal.write_text(text.replace(accessor, ''), encoding='utf-8', newline='\n')

diff = []
for name in FILES:
    source = ROOT / name
    target = OUT / 'candidate' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    diff.extend(difflib.unified_diff((OUT / 'before' / name).read_text().splitlines(True),
        source.read_text().splitlines(True), fromfile='a/' + name, tofile='b/' + name))
(OUT / 'product.diff').write_text(''.join(diff), encoding='utf-8', newline='\n')
save('source-identities.json', [identity(ROOT / name) for name in FILES])
save('before-identities.json', [identity(OUT / 'before' / name) for name in FILES])
commands = json.loads((OUT / 'commands.json').read_text())
runs = [x for x in commands if x['tag'] == 'tests']
assert [x['exit'] for x in runs] == [1, 1, 0, 0]
last = (OUT / 'attempt3-tests.stdout.log').read_text()
assert '[  PASSED  ] 2 tests.' in last
assert 'scaleAliases=0 alignment=256 nativeAlignment=16' in last
assert last.count('codeAliases=2') == 3
artifacts = [identity(OUT / name) for name in
             ('native-program.obj', 'iree.obj', 'tests.obj', 'tests.exe')]
save('artifact-identities.json', artifacts)
link = next(x['command'] for x in reversed(commands) if x['tag'] == 'link')
reuse = []
for text in link:
    path = Path(text)
    if path.is_absolute() and path.suffix in ('.obj', '.lib') and path.parent != OUT:
        reuse.append(identity(path))
save('reused-link-identities.json', reuse)
save('static-cache-check.json', {
    'command': [
        'C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/dumpbin.exe',
        '/linkermember:1',
        str(ROOT / '.scratch/bench-api-runtime/vulkan/build/native/hyle/_deps/iv/build/runtime/src/iree/runtime/iree_runtime_unified.lib'),
    ],
    'executed_read_only': True,
    'matched_output': ['1DF4E4 iree_hal_vulkan_libvulkan_load_device_syms',
                       '34484A iree_hal_vulkan_buffer_create_borrowed'],
})
cleanup = {
    'platform': 'Windows', 'root': str(OUT), 'performed': False,
    'delete': [x for x in artifacts if Path(x['path']).name in ('tests.obj', 'tests.exe')],
    'retain': [x for x in artifacts if Path(x['path']).name in ('native-program.obj', 'iree.obj')],
    'note': 'Retain the two current small product host overlays for reuse; all source/log/JSON/diff/zip and original shared runtime/native/foundation caches remain. Root owns test.ps1 execution.',
}
for key in ('delete', 'retain'):
    cleanup[key + '_count'] = len(cleanup[key])
    cleanup[key + '_logical_bytes'] = sum(x['bytes'] for x in cleanup[key])
save('cleanup-candidates.json', cleanup)
save('summary.json', {
    'result': 'PASS',
    'scope': 'Vulkan official grouped FP8/FP4 immutable captured owned bank inputs borrow original Vulkan storage across public Graph slots',
    'api': 'Private NativeProgram::create overload and BorrowedInput; no public Hyle API, Buffer/NativeProgram State layout or VMFB change',
    'accepted_domain': [
        'Only official grouped4/grouped8 codes and scales whose PlanValue is a ready immutable captured constant',
        'Same-device directly owned Buffer: nonnull memory, empty external_owner, unmapped, offset0, DEVICE_LOCAL, allocation_bytes>=VkBuffer handle extent bytes',
        'Range checked against actual VkBuffer handle extent, not padded VkDeviceMemory allocation size; per-input minimum64 and real descriptor alignment plus4-byte origin',
    ],
    'unchanged_paths': ['Dynamic inputs still allocate and copy',
        'Lease, WeightBatch, Tensor views and unknown external buffers still allocate/copy',
        'An unaligned scale range keeps its original copy while aligned codes may borrow',
        'Whole-bank index guards remain; GLM3GiB shape is still rejected pending word-carrier compiler'],
    'ownership': 'HAL OWNS_NONE wrapper never frees or maps native memory/handle. READ access only, TRANSFER|DISPATCH_STORAGE usage matching actual owned VkBuffer and locked VMFB import assertion. Successful HAL callback owns a shared_ptr<const void> cookie; failure cleanup remains RAII. No Run capture/cycle.',
    'synchronization': 'Existing ready immutable constant contract and original upload visibility apply; input/constant copy submission and checked native completion are preserved for remaining copied ports',
    'tests': {
        'filter': 'VulkanGraph.OfficialConstantBanksBorrowOwnedStorageAcrossSlots:VulkanGraph.OriginalOfficialGroupedFp4Fp8SharedDistinctAndChecked',
        'final_passed': 2, 'final_failed': 0,
        'geometry': 'E3/N7, T2/A1/S2; FP8 F32 K256/K128 and FP4 BF16 K128, three rebindings with changed activations/IDs',
        'real_graph_alias': 'Both public slots import the exact original codes VkBuffer with offset0 and exact code byte length. Natural aligned scales share the same handle/offset.',
        'alias_observations': [
            dict(format='FP8', depth=256, slots=2, codes_bytes=5376, code_aliases=2, scale_aliases=2),
            dict(format='FP8', depth=128, slots=2, codes_bytes=2688, code_aliases=2, scale_aliases=2),
            dict(format='FP4', depth=128, slots=2, codes_bytes=1344, code_aliases=2, scale_aliases=0),
        ],
        'native_minimum_descriptor_alignment': 16,
        'effective_natural_alignment': 64,
        'scale_fallback': 'FP4 same-case cold creation conservatively overrides route cached alignment to256, then restores real16 before execution. Offset1344 is not256-aligned; original scale copy is asserted. This is a synthetic stricter-capability boundary, not a naturally misaligned hardware case.',
        'negative_parameters': 'Duplicate borrowed port, port4 and insufficient byte capacity each return InvalidArgument',
        'lifetime': 'External Graph/Program/weight tensor cleared before execution; two slots still rebind and complete full independent original oracle. Earlier output remains correct. After slots/output release the weak constant owner expires.',
        'original_dynamic': 'Original FP8/FP4 dtype/shared-distinct activation/checked bad-ID grouped test remains passing',
    },
    'failures_retained': [
        'First run: new alias passed but VMFB hal.buffer.assert required TRANSFER|DISPATCH_STORAGE. Wrapper originally declared only DISPATCH_STORAGE. Corrected usage to actual owned VkBuffer capabilities, READ remains unchanged.',
        'Second run: new FP4 fixture used inadmissible F32 activation and unchecked add_node.value threw Bad expected access. Corrected fixture to original required BF16 and explicit node assertion; no product precision/budget change.',
    ],
    'runs': runs,
    'build': 'Three fresh host TUs initially; subsequent corrections only respective native-program/test TU plus relink. All /W4 /WX. Existing full IREE/Vulkan native libraries and current host/Graph overlays reused. No configure, SDK, compiler, shader or runtime rebuild.',
    'evidence_limits': [
        'Small bank mechanism/alias/complete-output/lifetime evidence, no executed multi-GiB official bank',
        'Logical aliased bytes are not measured driver allocation/VRAM peak; no timing/speed claim',
        'Only HYLE_STATIC host closure exercised; no new shared install/configure validation',
        'No active capture or new mutable/foreign-buffer import domain',
    ],
    'word_carrier': 'Still not applied; exact source review and compiler-cache limitation in source-review.md',
    'cleanup_performed': False,
})

members = sorted((p for p in OUT.rglob('*') if p.is_file() and
                  p.suffix not in ('.obj', '.exe', '.lib', '.exp', '.zip') and
                  p.name != 'package-identity.json'),
                 key=lambda p: p.relative_to(OUT).as_posix())
archive = OUT / 'source-results.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for path in members:
        handle.write(path, path.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    assert len(handle.namelist()) == len(members)
record = {'archive': identity(archive), 'members': len(members),
          'summary': identity(OUT / 'summary.json'),
          'cleanup': identity(OUT / 'cleanup-candidates.json')}
save('package-identity.json', record)
print(json.dumps(record, indent=2))
