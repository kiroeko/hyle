# Vulkan official grouped bank: pending word carrier

Read-only review, 2026-10-18. No qualification was widened and no program was compiled.

The current registered `official` artifact is 150,046 bytes, SHA256
`9d95a49491acd89584ce884ade428b8fd35d67fd00588d1321bfbdc7a0702b64`.
Its recipe SHA256 is `d467d9d2ee15c68e407bef1d5e6b6ed22c4a64a046ad10644f9a292a8e58bc91`;
both are in `third_party/iree_vulkan_runtime/programs/manifest.json`.
The matching historical compilation is `.scratch/validation/vulkan-v2-official/offline-f32-boundary/compilation.json`,
with IREE `6ef606b6fa3e12bd2c12d36a07463069eb71185f` / compiler 3.12.0rc20260919.
The older `offline-final` artifact is 173,478 bytes and is not the current artifact.

## Source and generated addressing

`third_party/iree_vulkan_runtime/programs/generate_official.py:225,236,274,281`
declares the weight codes as `i8[E,N,Kbytes]` and extracts individual bytes.
In the matching current dump
`offline-f32-boundary/spirv/module_grouped8_f32_dispatch_4_grouped8_f32_dispatch_4_elementwise_broadcast_D_f32.spirv.mlir:98-105`,
the compiler first forms `(expert*N+row)*K+column` with i32 arithmetic, then
uses signed division by4 to address packed i32 storage. A byte address above
INT32_MAX can therefore become a negative word index. This is a source-level
counterexample, not a new executed full-bank failure.

`src/compute_route_vulkan/vulkan_official.cc:31-46` currently rejects the
whole-bank product conservatively, and `src/compute_provider_iree_vulkan/native_program.cc:497-505`
has another conservative product check. Simply loosening either is unsafe.

The narrow repair is grouped-only `i32[E,N,K/4]` for FP8 and
`i32[E,N,K/8]` for FP4, with direct word indexing, logical right shift and
8/4-bit masking. `generate_mlx.py:31,70-78` already uses this pattern.
The native buffer-view shape/type at `native_program.cc:637-650` must change
with the recipe. Payload bytes, scale offsets, quantization and dot/scale order
remain unchanged. Word-index bounds and real per-binding byte ranges must be
checked separately from existing selected-work/scratch bounds. Regenerated
SPIR-V must demonstrate safe bank and binding-base addressing without Int64.

GLM E256/N2048/K6144 has 3,221,225,472 code bytes /805,306,368 words.
Expert255 starts at byte3,208,642,560 /word802,160,640. Scales add786,432 bytes.
The existing hardware descriptor range and allocation/budget limits still apply.

## Available and missing tools

The matching IREE runtime/static libraries, generated programs source and
native-program object remain in `.scratch/bench-api-runtime/vulkan/build/native/hyle/`.
No IREE runtime/SDK rebuild is needed for a new bytecode plus small host overlays.
The historical compiler path `C:/hv/m2vk-tools/iree/compiler/_mlir_libs/iree-compile.exe`
does not exist. A basename-only search of `.scratch`, `Get-Command`, and bounded
checks of the existing WSL `/root/venv`, `/root/hyle-scratch/vulkan-v4` and pip wheel
cache found no compiler. No toolchain was downloaded, copied, built or run.
The word-carrier change remains pending a matching existing compiler.

## Independent constant-bank copy issue

In the frozen `before/` source, `NativeProgram::allocate_view` allocates private input buffers. Each stage's
`IreeStage::bind` copies the complete code/scale ranges. Captured constants
skip subsequent copies within a slot, but each slot still has its own bank.
For the GLM geometry, caller plus IREE codes/scales alone total6,444,023,808 bytes,
before staging, workspaces or driver allocations. A read-only borrowed HAL view
for ready immutable constants is independent of the word-index repair; it does
not make the currently rejected full-bank shape executable.

The candidate in this same evidence directory subsequently implements borrowing
only for directly owned immutable captured grouped codes/scales. Views and
dynamic inputs keep their original copy boundary. Its exact tested domain,
first failures and two-slot results are in `summary.json`; the word-carrier
repair above remains pending and was not implemented.
