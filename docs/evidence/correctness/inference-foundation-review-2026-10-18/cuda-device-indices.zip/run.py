from pathlib import Path
import importlib.util,sys,json
ROOT=Path.cwd();OUT=ROOT/'.scratch/inference-fusion-quantization-2026-10-18/cuda-device-indices'
spec=importlib.util.spec_from_file_location('dense_runner',ROOT/'.scratch/inference-fusion-quantization-2026-10-18/dense-constants/run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.OUT=OUT;r.records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
flags=r.cuda.flags+['/I'+str(ROOT)]
def build():
    r.compile('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','provider',r.cuda.cl,flags,r.cuda.env)
    r.run('guard-compile',[r.cuda.toolkit/'bin/nvcc.exe','--std=c++20','--gpu-architecture=sm_89','--compiler-bindir',r.cuda.cl.parent,'-Xcompiler=/MD,/EHsc,/Zc:preprocessor,/utf-8','-O2','-DNDEBUG','-DNOMINMAX','-I'+str(ROOT/'src/compute_backend_cuda'),'--cudart','shared','-c',ROOT/'src/compute_provider_ggml_cuda/index_guard.cu','-o',OUT/'guard.obj'],r.cuda.env)
    for source,stem in [('tests/compute_provider_ggml_cuda/tensor_test.cc','direct-tests'),('tests/graph_provider_ggml_cuda/region_test.cc','graph-tests')]:
        r.compile(source,stem,r.cuda.cl,flags,r.cuda.env)
    link()
def link():
    common=[OUT/'provider.obj',OUT/'guard.obj',ROOT/'.scratch/mtp-completion/operation.obj',ROOT/'.scratch/inference-foundation-review-2026-10-18/batched-rope/cuda-tensor.obj',OUT/'region.obj',r.cuda.OLD/'ggml-cuda.strict.obj']
    for stem in ['direct','graph']:
        r.run(stem+'-link',[r.cuda.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(OUT/(stem+'.exe')),'/MAP:'+str(OUT/(stem+'.map')),OUT/(stem+'-tests.obj'),*common,*r.cuda.libs,r.cuda.BASE/'lib/gtest_main.lib',r.cuda.BASE/'lib/gtest.lib',*r.cuda.system],r.cuda.env)
def test():
    filters={'direct':'GgmlCudaTensor.CheckedExpertIdsKeepOutputAndAllowRecreatedInvocationRetry:GgmlCudaTensor.NativeEmbeddingRowsUseTargetGgufFormatsAndCheckBounds:GgmlCudaTensor.NativeQ8GroupedExpertsUseExactExpertIds:GgmlCudaTensor.DenseBfloatGroupedExpertsUseNativeMulMatIdAndReplay:GgmlCudaTensor.LargeGroupedF32RowsRetainNonTf32OperandsAndRepeatedIds',
             'graph':'GgmlCudaGraph.CheckedIdsKeepEveryPublishedOutputAndOtherConsumersIntact:GgmlCudaGraph.SingleBfloatExpertConstantPacksOnceAndDynamicWeightRemainsRebindable:GgmlCudaGraph.BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable:GgmlCudaGraph.ConstantDenseRhsPacksWithoutChangingOtherConsumersOrDynamicInputs'}
    for stem,filt in filters.items():r.run(stem+'-tests',[OUT/(stem+'.exe'),'--gtest_filter='+filt,'--gtest_color=no'],r.cuda.env)
if __name__=='__main__':{'build':build,'test':test,'link':link}[sys.argv[1]]()
