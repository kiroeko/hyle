#include "hyle/graph/apple.h"
#include "native_region.h"

#include "../graph/execution_source_internal.h"
#include "../compute_route_apple/apple_copy_internal.h"
#include "hyle/mem/std_allocator.h"

#include <mutex>
#include <utility>
#include <vector>

namespace hyle::graph::apple {
namespace ca = compute::apple;
namespace gd = graph::detail;
namespace {
constexpr compute::BackendId apple_backend{0x48594c4500000001ULL, 0x4150504c00000001ULL};
extern const gd::ExecutionSourceVTable source_table;
struct AppleSource final : gd::ExecutionSourceState {
  AppleSource(std::shared_ptr<ca::detail::Runtime> owner, mem::AllocatorRef allocator) noexcept
      : ExecutionSourceState(&source_table, allocator, owner.get()), runtime(std::move(owner)) {}
  std::shared_ptr<ca::detail::Runtime> runtime;
};
const AppleSource &native(const gd::ExecutionSourceState &state) noexcept {
  return static_cast<const AppleSource &>(state);
}
Status admission(const AppleSource &source) noexcept {
  std::lock_guard lock(source.runtime->queue_mutex);
  if (!source.runtime->accepting) return Status::FailedPrecondition("Apple execution source is closed");
  return source.runtime->failure;
}
const gd::ExecutionSourceVTable source_table{
    [](gd::ExecutionSourceState *state) noexcept {
      state->allocator.destroy(static_cast<AppleSource *>(state));
    },
    [](const gd::ExecutionSourceState &state) noexcept { return admission(native(state)).ok(); },
    [](const gd::ExecutionSourceState &a, const gd::ExecutionSourceState &b) noexcept {
      return native(a).runtime->stream->device == native(b).runtime->stream->device;
    },
    [](const gd::ExecutionSourceState &) noexcept { return apple_backend; },
    [](const gd::ExecutionSourceState &) noexcept { return compute::DeviceClass::kGpu; },
    [](const gd::ExecutionSourceState &state) noexcept -> Result<compute::DeviceProperties> {
      return compute::DeviceProperties{.backend = apple_backend,
          .device_class = compute::DeviceClass::kGpu, .backend_name = "MLX Metal",
          .name = native(state).runtime->environment.device_name,
          .unified_memory = true, .asynchronous_queues = true};
    },
    [](const gd::ExecutionSourceState &, mem::MemoryResourceRef resource) noexcept {
      return ca::detail::is_copy_resource(resource) ? Status::Ok()
          : Status::InvalidArgument("Apple source requires its original shared Metal resource");
    },
    [](const gd::ExecutionSourceState &state, gd::SourceCall function, void *opaque) noexcept -> Status {
      HYLE_RETURN_IF_ERROR(admission(native(state)));
      // Original native preparation/submission owns its admission and FIFO.
      // Never hold queue_mutex across a cold owner Job or invent a Queue.
      return function(opaque);
    },
    nullptr,
    [](const gd::ExecutionSourceState &state) noexcept -> void * {
      // Borrow the actual shared owner only while Source lives. Artifacts copy
      // it, never manufacture a Context or a non-owning shared_ptr.
      return const_cast<std::shared_ptr<ca::detail::Runtime> *>(&native(state).runtime);
    },
    [](const gd::ExecutionSourceState &) noexcept { return detail::native_region_provider(); },
    [](const gd::ExecutionSourceState &state, const gd::ConstantCopy &copy) noexcept {
      return ca::detail::MemoryAccess::can_copy_constant(native(state).runtime,
          {copy.destination, copy.source});
    },
    [](const gd::ExecutionSourceState &state, std::span<const gd::ConstantCopy> copies,
       mem::AllocatorRef allocator) noexcept -> Status {
      if (!allocator.valid()) return Status::InvalidArgument("Apple constant metadata allocator is invalid");
      try {
        std::vector<ca::detail::ConstantCopy, mem::StdAllocator<ca::detail::ConstantCopy>> batch{
            mem::StdAllocator<ca::detail::ConstantCopy>(allocator)};
        batch.reserve(copies.size());
        for (const auto &copy : copies) batch.push_back({copy.destination, copy.source});
        return ca::detail::MemoryAccess::copy_constants(native(state).runtime, batch, allocator);
      } catch (const std::bad_alloc &) {
        return Status::ResourceExhausted("Apple constant batch metadata");
      }
    },
    [](const gd::ExecutionSourceState &, std::span<const gd::ConstantCopy>) noexcept
        -> Result<std::size_t> { return std::size_t{0}; },
    [](const gd::ExecutionSourceState &, mem::MemoryResourceRef nominated,
       mem::MemoryResourceRef actual) noexcept {
      return ca::detail::copy_source_resource_matches(nominated, actual);
    }};
}

Result<ExecutionSource> execution_source(const ca::Context &context, mem::AllocatorRef allocator) noexcept {
  if (!context || !allocator.valid())
    return std::unexpected(Status::InvalidArgument("Apple execution source requires a Context and allocator"));
  const auto &runtime = ca::detail::ContextAccess::runtime(context);
  {
    std::lock_guard lock(runtime->queue_mutex);
    if (!runtime->accepting) return std::unexpected(Status::FailedPrecondition("Apple execution source is closed"));
    HYLE_RETURN_IF_ERROR(runtime->failure);
  }
  auto *source = allocator.construct<AppleSource>(runtime, allocator);
  if (!source) return std::unexpected(Status::ResourceExhausted("Apple execution source metadata"));
  return gd::ExecutionSourceAccess::adopt(source);
}
} // namespace hyle::graph::apple
