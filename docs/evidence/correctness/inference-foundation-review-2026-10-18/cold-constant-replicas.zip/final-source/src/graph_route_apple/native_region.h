#pragma once

#include "hyle/graph/region_provider.h"

namespace hyle::graph::apple::detail {
const RegionProviderVTable *native_region_provider() noexcept;
}
