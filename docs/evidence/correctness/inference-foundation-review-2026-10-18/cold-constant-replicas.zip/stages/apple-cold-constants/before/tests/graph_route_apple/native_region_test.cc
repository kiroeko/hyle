#include <gtest/gtest.h>

#include "hyle/graph/apple.h"
#include "hyle/graph/executable.h"
#include "hyle/graph/detail/region_adapter.h"
#include "../../src/graph/execution_source_internal.h"
#include "hyle/compute/apple_memory.h"
#include "hyle/mem/stats.h"

#include <array>
#include <bit>
#include <iostream>

namespace {
namespace c = hyle::compute;
namespace a = c::apple;
namespace g = hyle::graph;
namespace m = hyle::mem;

const auto description = c::TensorDesc::dense(c::DataType::kFloat32,
    std::array<std::int64_t, 1>{4}).value();

template<class T, std::size_t N>
c::ReadLease input(const a::MemoryResource &memory, const c::TensorDesc &desc,
                   const std::array<T, N> &values) {
  auto array = memory.allocate(desc).value();
  auto host = m::Buffer::create(m::system_resource(), sizeof(values), alignof(T)).value();
  EXPECT_TRUE(host.view().write(std::as_bytes(std::span(values))).ok());
  const auto view = c::ConstTensorView::create(desc, host.view()).value();
  EXPECT_TRUE(memory.copy_from_host(array, view).ok());
  return memory.import_readonly(array, desc).value();
}
template<std::size_t N>
void expect(c::ConstTensorView tensor, const std::array<float, N> &wanted) {
  std::array<float, N> actual{};
  ASSERT_TRUE(tensor.storage().read(std::as_writable_bytes(std::span(actual))).ok());
  for (std::size_t i = 0; i < N; ++i)
    EXPECT_EQ(std::bit_cast<std::uint32_t>(actual[i]), std::bit_cast<std::uint32_t>(wanted[i])) << i;
}
hyle::Status submit(g::Invocation &invocation) {
  auto status = invocation.prepare_replay({});
  EXPECT_TRUE(status.ok()) << status.message();
  if (!status.ok()) return status;
  auto accepted = invocation.submit();
  if (!accepted) { ADD_FAILURE() << accepted.error().message(); return std::move(accepted).error(); }
  return accepted->wait();
}

TEST(AppleNativeRegion, UnifiedInvocationKeepsNativeFusionOwnersAndBorrowedLimits) {
  auto context = a::Context::create().value();
  RecordProperty("device", context.environment()->device_name);
  RecordProperty("os_runtime", context.environment()->os_runtime);
  auto memory = a::MemoryResource::create(context).value();
  const auto source = g::apple::execution_source(context).value();
  auto duplicate = g::apple::execution_source(context).value();
  EXPECT_TRUE(source.same_owner(duplicate));
  EXPECT_FALSE(source.validate_resource(m::system_resource()).ok());
  auto builder = g::GraphBuilder::create().value();
  const auto x = builder.input(description).value();
  const auto constant = builder.constant(description).value();
  const auto sum = builder.add(c::Binary{c::BinaryKind::kAdd}, x, constant).value();
  const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, sum).value();
  const auto shape = c::TensorShape::create(std::array<std::int64_t, 2>{2, 2}).value();
  const auto alias = builder.add(c::View::reshape(shape).value(), x).value();
  for (const auto value : {sum, negative, alias}) ASSERT_TRUE(builder.publish(value).ok());
  auto graph = std::move(builder).finish().value();
  auto weights = input(memory, description, std::array<float, 4>{0.5f, -0.25f, 1.25f, 2.0f});
  const std::array constants{g::ConstantBinding{constant, weights.tensor(description).value(), g::ConstantPolicy::kBorrow}};
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  auto compiled = g::compile(graph, {domains, targets}, {.constants = constants});
  ASSERT_TRUE(compiled) << compiled.error().message();
  EXPECT_EQ(compiled->executable.region_count(), 1U);
  EXPECT_EQ(compiled->executable.required_queue_count(), 0U);
  EXPECT_EQ(compiled->executable.workspace_bytes(), 0U);
  auto first = compiled->executable.create_invocation().value();
  auto second = compiled->executable.create_invocation({.resources = g::ResourceOptions{}}).value();
  EXPECT_FALSE(first.result(negative)); // A cold deferred port has no result/array yet.
  auto raw = input(memory, description, std::array<float, 4>{0.25f, 1.5f, -2.75f, 0.0f});
  ASSERT_TRUE(first.bind(x, raw.tensor(description).value()).ok());
  ASSERT_TRUE(submit(first).ok());
  auto old = first.result(negative).value();
  expect(old.tensor().value(), std::array<float, 4>{-0.75f, -1.25f, 1.5f, -2.0f});
  auto raw_alias = first.result(alias).value();
  expect(raw_alias.tensor().value(), std::array<float, 4>{0.25f,1.5f,-2.75f,0.0f});
  auto denied = raw_alias.storage_lease();
  ASSERT_FALSE(denied); // A borrowed alias cannot create independent payload ownership.
  EXPECT_FALSE(first.bind(x, raw.tensor(description).value()).ok());
  c::ReadLease escaped;
  for (const auto values : {std::array<float, 4>{-2.0f, 3.25f, 1.5f, -0.5f},
                            std::array<float, 4>{1.25f, -4.0f, 0.25f, 8.0f}}) {
    auto owned = input(memory, description, values);
    ASSERT_TRUE(second.bind(x, description, owned).ok());
    owned.reset(); // Only the actual binding/MLX array owns this input now.
    ASSERT_TRUE(submit(second).ok());
    const std::array<float, 4> wanted{values[0]+0.5f, values[1]-0.25f, values[2]+1.25f, values[3]+2.0f};
    auto result = second.result(negative).value();
    expect(result.tensor().value(), std::array<float, 4>{-wanted[0], -wanted[1], -wanted[2], -wanted[3]});
    auto input_alias = second.result(alias).value();
    escaped = input_alias.storage_lease().value();
    expect(escaped.tensor(description).value(), values);
  }
  expect(old.tensor().value(), std::array<float, 4>{-0.75f, -1.25f, 1.5f, -2.0f});
  first = {}; second = {}; compiled->executable = {}; graph = {};
  ASSERT_TRUE(context.close().ok());
  expect(old.tensor().value(), std::array<float, 4>{-0.75f, -1.25f, 1.5f, -2.0f});
  expect(escaped.tensor(description).value(), std::array<float, 4>{1.25f, -4.0f, 0.25f, 8.0f});
  EXPECT_FALSE(g::apple::execution_source(context));
}

TEST(AppleNativeRegion, DeferredNativePortsResolveOnOriginalOwnerAndKeepFailure) {
  auto context = a::Context::create().value();
  auto memory = a::MemoryResource::create(context).value();
  const auto ids_description = c::TensorDesc::dense(c::DataType::kInt32,
      std::array<std::int64_t, 1>{2}).value();
  auto builder = g::GraphBuilder::create().value();
  const auto x = builder.input(description).value();
  const auto ids = builder.input(ids_description).value();
  const auto selected_node = builder.add_node(c::Operation(c::Gather{.axis=0}), std::array{x, ids}).value();
  const auto selected = builder.result(selected_node).value();
  const auto negative_node = builder.add_node(c::Operation(c::Unary{c::UnaryKind::kNeg}), std::array{selected}).value();
  const auto negative = builder.result(negative_node).value();
  ASSERT_TRUE(builder.depends_on(negative_node, selected_node).ok());
  ASSERT_TRUE(builder.publish(selected).ok()); ASSERT_TRUE(builder.publish(negative).ok());
  auto graph = std::move(builder).finish().value();
  const auto source = g::apple::execution_source(context).value();
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  {
    // This dependency is legal inside one native region. Exercise deferred
    // Graph ports separately with cold fragment selection, not a product cut.
    auto fused = g::compile(graph, {domains, targets});
    ASSERT_TRUE(fused) << fused.error().message();
    EXPECT_EQ(fused->executable.region_count(), 1U);
  }
  auto capability = g::detail::ExecutionSourceAccess::region(source);
  ASSERT_TRUE(capability) << capability.error().message();
  auto native_context = g::detail::ExecutionSourceAccess::native_context(source);
  ASSERT_TRUE(native_context) << native_context.error().message();
  struct FragmentSelection final {
    const g::RegionProviderVTable *native = nullptr;
    void *context = nullptr;
    std::array<g::NodeId, 2> nodes{};
  } selection{static_cast<const g::RegionProviderVTable *>(capability->native_interface()),
              *native_context, {selected_node, negative_node}};
  ASSERT_NE(selection.native, nullptr);
  const g::RegionProviderVTable fragments{
      +[](void *opaque, const g::RegionDiscoveryRequest &request,
          m::AllocatorRef, g::RegionProposalWriter &writer) noexcept -> hyle::Status {
        const auto &chosen = *static_cast<const FragmentSelection *>(opaque);
        for (const auto node : chosen.nodes) {
          if (!request.allowed_nodes.empty() && !request.allowed_nodes[node.ordinal()])
            continue;
          HYLE_ASSIGN_OR_RETURN(auto more, writer.try_add({.nodes = std::span(&node, 1),
              .route = 1, .replay_class = c::ProviderReplayClass::kManaged,
              .implementation = c::ProviderImplementationId{1}, .preference = 0}));
          if (!more) break;
        }
        return hyle::Status::Ok();
      },
      +[](void *opaque, const g::RegionCompileRequest &request, m::AllocatorRef allocator,
          std::span<c::detail::ResourceBindingRequirement> inputs,
          std::span<c::detail::ResourceBindingRequirement> outputs,
          g::RegionResourceProposal *proposal) noexcept -> hyle::Status {
        const auto &chosen = *static_cast<const FragmentSelection *>(opaque);
        return chosen.native->propose_resources(chosen.context, request, allocator,
                                                inputs, outputs, proposal);
      },
      +[](void *opaque, const g::RegionCompileRequest &request, m::AllocatorRef allocator,
          g::ProviderRegionPrepared *prepared) noexcept -> c::ProviderPrepareOutcome {
        const auto &chosen = *static_cast<const FragmentSelection *>(opaque);
        return chosen.native->compile(chosen.context, request, allocator, prepared);
      }};
  std::array adapters{g::detail::RegionAdapter{.source = std::move(*capability),
      .target = g::ExecutionTargetId{0}, .interface = &fragments, .context = &selection}};
  {
    auto invalid = adapters;
    invalid[0].provider_index = 0; // Native sources have no Compute provider slot.
    auto rejected = g::detail::compile_with_adapters(graph, {domains, targets}, {}, invalid);
    ASSERT_FALSE(rejected);
    EXPECT_TRUE(rejected.error().IsInvalidArgument()) << rejected.error().message();
  }
  {
    auto invalid = adapters;
    invalid[0].target = g::ExecutionTargetId{1};
    auto rejected = g::detail::compile_with_adapters(graph, {domains, targets}, {}, invalid);
    ASSERT_FALSE(rejected);
    EXPECT_TRUE(rejected.error().IsInvalidArgument()) << rejected.error().message();
  }
  {
    // A second real owner on the same device cannot borrow this target's
    // admission simply because its interface has the same implementation.
    auto foreign_context = a::Context::create().value();
    auto foreign_source = g::apple::execution_source(foreign_context).value();
    auto foreign = g::detail::ExecutionSourceAccess::region(foreign_source);
    ASSERT_TRUE(foreign) << foreign.error().message();
    auto invalid = adapters;
    invalid[0].source = std::move(*foreign);
    auto rejected = g::detail::compile_with_adapters(graph, {domains, targets}, {}, invalid);
    ASSERT_FALSE(rejected);
    EXPECT_TRUE(rejected.error().IsInvalidArgument()) << rejected.error().message();
  }
  {
    // The cold override table is configuration, never the source capability.
    auto forged = g::detail::GraphRegionSource::native(source, &fragments);
    ASSERT_TRUE(forged) << forged.error().message();
    auto invalid = adapters;
    invalid[0].source = std::move(*forged);
    auto rejected = g::detail::compile_with_adapters(graph, {domains, targets}, {}, invalid);
    ASSERT_FALSE(rejected);
    EXPECT_TRUE(rejected.error().IsInvalidArgument()) << rejected.error().message();
  }
  auto compiled = g::detail::compile_with_adapters(graph, {domains, targets}, {}, adapters);
  ASSERT_TRUE(compiled) << compiled.error().message();
  // These compile-local controls are not an executor or a replay owner.
  adapters = {}; selection = {};
  EXPECT_EQ(compiled->executable.region_count(), 2U);
  EXPECT_EQ(compiled->executable.workspace_bytes(), 0U);
  auto slot = compiled->executable.create_invocation({.resources=g::ResourceOptions{}}).value();
  c::ReadLease retained;
  for (int phase = 0; phase < 2; ++phase) {
    auto values = input(memory, description, phase == 0 ? std::array<float, 4>{0.25f,-1.5f,3.75f,2.0f}
                                                       : std::array<float, 4>{4.0f,0.5f,-2.25f,-0.0f});
    auto indices = input(memory, ids_description, std::array<std::int32_t, 2>{3, 1});
    ASSERT_TRUE(slot.bind(x, description, values).ok());
    ASSERT_TRUE(slot.bind(ids, ids_description, indices).ok());
    ASSERT_TRUE(submit(slot).ok());
    const auto wanted = phase == 0 ? std::array<float, 2>{-2.0f,1.5f} : std::array<float, 2>{0.0f,-0.5f};
    auto result = slot.result(negative).value(); expect(result.tensor().value(), wanted);
    if (phase == 0) retained = result.storage_lease().value();
  }
  expect(retained.tensor(c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 1>{2}).value()).value(), std::array<float, 2>{-2.0f,1.5f});
  auto failed = compiled->executable.create_invocation({.resources=g::ResourceOptions{}}).value();
  auto values = input(memory, description, std::array<float, 4>{1,2,3,4});
  auto bad = input(memory, ids_description, std::array<std::int32_t, 2>{0,4});
  ASSERT_TRUE(failed.bind(x, description, values).ok());
  ASSERT_TRUE(failed.bind(ids, ids_description, bad).ok());
  ASSERT_TRUE(failed.prepare_replay({}).ok());
  auto accepted = failed.submit();
  ASSERT_TRUE(accepted) << accepted.error().message();
  const auto terminal = accepted->wait();
  EXPECT_TRUE(terminal.IsOutOfRange()) << terminal.message();
  EXPECT_FALSE(failed.result(selected)); EXPECT_FALSE(failed.result(negative));
}

TEST(AppleNativeRegion, OwnedViewFeedbackKeepsOneExactLeaseOwner) {
  auto counted = m::StatsAllocator::create(m::system_allocator()).value();
  {
    auto context = a::Context::create().value();
    auto memory = a::MemoryResource::create(context).value();
    const auto source = g::apple::execution_source(context, counted.get()).value();
    auto builder = g::GraphBuilder::create().value();
    const auto x = builder.input(description).value();
    const auto negative = builder.add(c::Unary{c::UnaryKind::kNeg}, x).value();
    const auto shape = c::TensorShape::create(std::array<std::int64_t, 2>{2, 2}).value();
    const auto alias = builder.add(c::View::reshape(shape).value(), x).value();
    ASSERT_TRUE(builder.publish(negative).ok());
    ASSERT_TRUE(builder.publish(alias).ok());
    auto graph = std::move(builder).finish().value();
    const std::array domains{g::StorageDomain{memory.ref()}};
    const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
    auto compiled = g::compile(graph, {domains, targets});
    ASSERT_TRUE(compiled) << compiled.error().message();
    ASSERT_EQ(compiled->executable.region_count(), 1U);
    auto slot = compiled->executable.create_invocation({.resources = g::ResourceOptions{}}).value();

    // The readable input is a strict subrange of a larger, independently owned
    // allocation. A view result must preserve this exact permission, not export
    // the whole Metal allocation through another owner wrapper.
    const auto backing_description = c::TensorDesc::dense(c::DataType::kFloat32,
        std::array<std::int64_t, 1>{8}).value();
    auto backing = input(memory, backing_description,
        std::array<float, 8>{99.0f, 98.0f, 0.25f, -1.5f, 3.75f, -0.0f, 97.0f, 96.0f});
    auto current = backing.subview(2 * sizeof(float), 4 * sizeof(float)).value();
    backing.reset();
    const auto original = current.view().value();
    const auto generation = current.generation();
    const std::array<float, 4> wanted{0.25f, -1.5f, 3.75f, -0.0f};
    const auto feedback = [&]() -> hyle::Status {
      HYLE_RETURN_IF_ERROR(slot.bind(x, description, current));
      HYLE_RETURN_IF_ERROR(submit(slot));
      auto result = slot.result(alias);
      if (!result) return std::move(result).error();
      auto next = result->storage_lease();
      if (!next) return std::move(next).error();
      expect(next->tensor(description).value(), wanted);
      const auto physical = next->view().value();
      EXPECT_EQ(physical.native_handle(), original.native_handle());
      EXPECT_EQ(physical.offset(), original.offset());
      EXPECT_EQ(physical.size(), original.size());
      current = std::move(*next);
      return hyle::Status::Ok();
    };
    // Warm the normal slot/report capacities before comparing live metadata.
    ASSERT_TRUE(feedback().ok());
    ASSERT_TRUE(feedback().ok());
    const auto baseline = counted.snapshot();
    std::array<m::AllocStatsSnapshot, 4> samples{};
    for (std::size_t round = 0; round < 64; ++round) {
      const auto status = feedback();
      ASSERT_TRUE(status.ok()) << status.message();
      if (round == 7 || round == 15 || round == 31 || round == 63) {
        const auto index = round == 7 ? 0U : round == 15 ? 1U : round == 31 ? 2U : 3U;
        samples[index] = counted.snapshot();
      }
    }
    std::cout << "owned_alias_feedback baseline=" << baseline.live_count << '/' << baseline.live_bytes;
    for (const auto &sample : samples) std::cout << " live=" << sample.live_count << '/' << sample.live_bytes;
    std::cout << '\n';
    EXPECT_EQ(current.view()->resource(), original.resource());
    EXPECT_EQ(current.generation(), generation);
    EXPECT_LE(samples.back().live_count, baseline.live_count);
    EXPECT_LE(samples.back().live_bytes, baseline.live_bytes);

    // A genuine computed result still owns its new Array, independently of the
    // input/view lease. This must not be flattened merely by graph provenance.
    auto result = slot.result(negative).value();
    auto computed = result.storage_lease().value();
    expect(computed.tensor(description).value(), std::array<float, 4>{-0.25f, 1.5f, -3.75f, 0.0f});
    EXPECT_NE(computed.view()->native_handle(), original.native_handle());
    result = {};
    slot = {};
    compiled->executable = {};
    graph = {};
    ASSERT_TRUE(context.close().ok());
    expect(current.tensor(description).value(), wanted);
    expect(computed.tensor(description).value(), std::array<float, 4>{-0.25f, 1.5f, -3.75f, 0.0f});
  }
  EXPECT_EQ(counted.snapshot().live_count, 0U);
}
} // namespace
