from pathlib import Path
import difflib
import hashlib
import io
import json
import tarfile
import zipfile
import stage

OUT = Path(__file__).resolve().parent
code = '''from pathlib import Path
import io,sys,tarfile
r=Path(''' + repr(stage.REMOTE) + ''')
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as a:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in {'.log','.json','.txt','.py'}:
   a.add(p,arcname=p.name)
sys.stdout.buffer.write(b.getvalue())
'''
payload = stage.ssh(code)
(OUT / 'remote-evidence.tar.gz').write_bytes(payload)
remote = OUT / 'remote'
remote.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
    assert all(member.isfile() and '/' not in member.name and '..' not in Path(member.name).parts
               for member in archive.getmembers())
    archive.extractall(remote, filter='data')
result = json.loads((remote / 'test-results.json').read_text())
assert result['tests'] == 7 and not result['failures'] and not result.get('errors', 0)
commands = json.loads((remote / 'commands.json').read_text())
assert len(commands) == 7 and all(row['exit'] == 0 for row in commands)
finite = next(row for row in commands if row['tag'] == 'finite-tests')
finite_output = (remote / finite['stdout']).read_text()
assert 'PASS' in finite_output
manifest = json.loads((OUT / 'staged-sources.json').read_text())
final_sources = json.loads((OUT / 'final-sha256.json').read_text())
for name, wanted in final_sources.items():
    assert hashlib.sha256((stage.ROOT / name).read_bytes()).hexdigest() == wanted, name
patch = []
for name in final_sources:
    before = (OUT / 'before' / name).read_text(encoding='utf-8-sig').splitlines(keepends=True)
    after = (stage.ROOT / name).read_text(encoding='utf-8-sig').splitlines(keepends=True)
    patch.extend(difflib.unified_diff(before, after, fromfile='before/' + name, tofile=name))
(OUT / 'source.diff').write_text(''.join(patch), encoding='utf-8')
cleanup = []
for name in ['native-tests', 'finite-native']:
    for row in json.loads((remote / (name + '-identities.json')).read_text()):
        if row['path'] in [stage.REMOTE + '/' + name, stage.REMOTE + '/' + name + '.map']:
            cleanup.append(row)
(OUT / 'cleanup-candidates.json').write_text(json.dumps(
    dict(host='kiro@172.22.10.198', candidates=cleanup, deletion_executed=False), indent=2) + '\n')
summary = dict(
    scope='Actual native Apple-only immutable host constant materialization on the common Graph path',
    host='kiro@172.22.10.198', remote_stage=stage.REMOTE,
    hardware_and_toolchain=(remote / 'machine.txt').read_text(),
    source_delivery=dict(files=len(manifest), archive_bytes=(OUT / 'minimal-sources.tar.gz').stat().st_size,
                         manifest='staged-sources.json', sdk_or_checkout_copied=False),
    fresh_host_tus=['src/compute_route_apple/apple_memory.mm',
                    'src/graph_route_apple/execution_source.cc',
                    'tests/graph_route_apple/native_region_test.cc'],
    final_sources=final_sources,
    common_graph_objects_reused_from='architecture-refactor-20261018-apple-constant-replicas',
    actual_results=dict(native_tests=result['tests'], failures=result['failures'],
                        filter='AppleNativeRegion.*:AppleLateInput.*',
                        native_log='remote/05-native-tests.stdout.log',
                        finite_exit=finite['exit'], finite_log='remote/' + finite['stdout'],
                        finite_output=finite_output.strip()),
    new_coverage=[
        'Real native Source without a CPU Context materializes one 16-byte host constant shared by two exact routes.',
        'Original host payload is released; two owned-input slots replay twice and share the same native canonical weight backing.',
        'Odd 3-byte payload copy and scratch_bytes=0 pure query.',
        'Whole-batch readonly imported destination rejection leaves prior writable destination sentinel untouched.',
        'Readonly native source copies to a second actual writable MemoryResource on the same Metal device.',
        'Host read Unimplemented remains fatal after route selection and is not retried.'],
    previous_controls='Original five native fusion/ownership/deferred-fragment/late-input cases retained unchanged.',
    input_identity_files=['remote/retained-identities.json', 'remote/native-tests-identities.json',
                          'remote/finite-native-identities.json'],
    commands='remote/commands.json', execution_terminal=True,
    limits=['No SDK, shader, common Graph TU, GraphBatch, whole checkout, model run or performance measurement.',
            'This cold path uses synchronous reads and writes to actual shared Metal storage; it does not add an execution Queue.',
            'Fresh and retained object identities are recorded; payload objects/binaries/maps excluded.',
            'No deletion executed; exact four binary/map candidates are in cleanup-candidates.json.'])
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
archive_path = OUT / 'source-results.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(OUT.rglob('*')):
        if not path.is_file() or path == archive_path or path.name == 'package-identity.json':
            continue
        if path.suffix in {'.py', '.json', '.log', '.txt', '.diff', '.h', '.cc', '.mm'} \
                or path.name == 'minimal-sources.tar.gz':
            archive.write(path, path.relative_to(OUT).as_posix())
identity = dict(path=str(archive_path), bytes=archive_path.stat().st_size,
                sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest())
(OUT / 'package-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(identity))
print(json.dumps(summary['actual_results']))
