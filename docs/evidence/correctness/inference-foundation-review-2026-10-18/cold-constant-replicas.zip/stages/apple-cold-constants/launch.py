from pathlib import Path
import json
import subprocess
import time

OUT = Path(__file__).resolve().parent
command = ['ssh', 'kiro@172.22.10.198',
           'python3 /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-apple-cold-constants/run_remote.py']
started = time.monotonic()
with (OUT / 'ssh.stdout.log').open('wb') as out, (OUT / 'ssh.stderr.log').open('wb') as err:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=err)
    (OUT / 'local-live.json').write_text(json.dumps(dict(pid=process.pid, command=command)) + '\n')
    for line in iter(process.stdout.readline, b''):
        out.write(line)
        out.flush()
        print(line.decode(errors='replace').rstrip(), flush=True)
    process.wait()
(OUT / 'ssh-command.json').write_text(json.dumps(dict(command=command, exit=process.returncode,
                                                   seconds=time.monotonic() - started), indent=2) + '\n')
(OUT / 'local-live.json').write_text(json.dumps(dict(terminal=True, exit=process.returncode)) + '\n')
raise SystemExit(process.returncode)
