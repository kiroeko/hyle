from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent
COMMON = ROOT.parent / 'architecture-refactor-20261018-apple-constant-replicas'
DISCOVERY = ROOT.parent / 'architecture-refactor-20261018-apple-discovery-spi'
NATIVE = ROOT.parent / 'architecture-refactor-20261018-apple-native-region'
SDK = Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
OLD = json.loads((COMMON / 'commands.json').read_text())
DISCOVERY_COMMANDS = json.loads((DISCOVERY / 'commands.json').read_text())
NATIVE_COMMANDS = json.loads((NATIVE / 'commands.json').read_text())
RECORDS = json.loads((ROOT / 'commands.json').read_text()) if (ROOT / 'commands.json').exists() else []


def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def run(tag, command):
    command = list(map(str, command))
    stem = f'{len(RECORDS) + 1:02d}-{tag}'
    started = time.monotonic()
    with (ROOT / (stem + '.stdout.log')).open('wb') as out, \
            (ROOT / (stem + '.stderr.log')).open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err)
        (ROOT / 'live.json').write_text(json.dumps(dict(tag=tag, pid=process.pid, command=command)) + '\n')
        try:
            code = process.wait(timeout=55)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            code = 124
    RECORDS.append(dict(tag=tag, command=command, cwd=str(ROOT), exit=code,
                        seconds=time.monotonic() - started,
                        stdout=stem + '.stdout.log', stderr=stem + '.stderr.log'))
    (ROOT / 'commands.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
    (ROOT / 'live.json').write_text(json.dumps(dict(terminal=True, tag=tag, exit=code)) + '\n')
    print(stem, code, flush=True)
    if code:
        print((ROOT / (stem + '.stdout.log')).read_text(errors='replace')[-6000:], flush=True)
        print((ROOT / (stem + '.stderr.log')).read_text(errors='replace')[-9000:], flush=True)
        raise SystemExit(code)


def preflight():
    model = subprocess.check_output(['sysctl', '-n', 'hw.model'], text=True).strip()
    assert model == 'Mac16,12', model
    (ROOT / 'machine.txt').write_text(subprocess.check_output(
        ['sysctl', 'hw.model', 'hw.memsize', 'machdep.cpu.brand_string'], text=True)
        + subprocess.check_output(['xcrun', 'clang++', '--version'], text=True))
    for row in json.loads((ROOT / 'staged-sources.json').read_text()):
        assert identity(ROOT / row['path'])['sha256'] == row['sha256'], row['path']
    (ROOT / 'mlx.metallib').symlink_to((SDK / 'lib/mlx.metallib').resolve())
    replaced = {NATIVE / 'memory.o', DISCOVERY / 'source.o', DISCOVERY / 'test-final.o'}
    retained = {}
    for name in ['native-tests-identities.json', 'finite-native-identities.json']:
        for row in json.loads((COMMON / name).read_text()):
            path = Path(row['path'])
            if path.suffix not in {'.o', '.a', '.dylib'} or path in replaced:
                continue
            actual = identity(path)
            assert actual['sha256'] == row['sha256'], path
            retained[str(path)] = actual
    (ROOT / 'retained-identities.json').write_text(json.dumps(list(retained.values()), indent=2) + '\n')


def compile_all():
    for source, name, history, tag in [
            ('src/compute_route_apple/apple_memory.mm', 'memory', NATIVE_COMMANDS, 'memory-compile'),
            ('src/graph_route_apple/execution_source.cc', 'source', DISCOVERY_COMMANDS, 'source-compile'),
            ('tests/graph_route_apple/native_region_test.cc', 'test', DISCOVERY_COMMANDS, 'test-compile')]:
        old = next(row['command'] for row in reversed(history) if row['tag'] == tag and row['exit'] == 0)
        prefix = old[:old.index('-c')]
        prefix[1:1] = ['-I' + str(ROOT / 'include'), '-I' + str(ROOT),
                       '-I' + str(ROOT / 'src/graph'), '-I' + str(ROOT / 'src/compute'),
                       '-I' + str(ROOT / 'src/compute_route_apple'),
                       '-I' + str(ROOT / 'src/graph_route_apple')]
        run(name + '-compile', prefix + ['-c', ROOT / source, '-o', ROOT / (name + '.o')])


def link(finite=False):
    tag = 'finite-native-link' if finite else 'native-tests-link'
    old = next(row['command'] for row in OLD if row['tag'] == tag and row['exit'] == 0)
    replace = {str(NATIVE / 'memory.o'): ROOT / 'memory.o',
               str(DISCOVERY / 'source.o'): ROOT / 'source.o'}
    if not finite:
        replace[str(DISCOVERY / 'test-final.o')] = ROOT / 'test.o'
    output = ROOT / ('finite-native' if finite else 'native-tests')
    command, seen = [], set()
    skip = False
    for arg in old:
        if skip:
            skip = False
            continue
        if arg == '-o':
            command += ['-o', str(output)]
            skip = True
            continue
        if arg.startswith('-Wl,-map,'):
            arg = '-Wl,-map,' + str(output) + '.map'
        if arg in replace:
            seen.add(arg)
            arg = str(replace[arg])
        command.append(arg)
    assert seen == set(replace), (seen, set(replace))
    run(output.name + '-link', command)
    (ROOT / (output.name + '-identities.json')).write_text(json.dumps(
        [identity(path) for path in command if path.endswith(('.o', '.a', '.dylib'))]
        + [identity(output), identity(str(output) + '.map')], indent=2) + '\n')
    return output


if __name__ == '__main__':
    preflight()
    compile_all()
    native = link()
    run('native-tests', [native, '--gtest_filter=AppleNativeRegion.*:AppleLateInput.*',
                        '--gtest_color=no', '--gtest_output=json:' + str(ROOT / 'test-results.json')])
    finite = link(True)
    run('finite-tests', [finite])
