# Vulkan cold constant readback

This extends the existing cold batch, now accurately named private ConstantCopy.
The Graph Source wrapper behavior, public ABI and replay path are unchanged.
Windows is the authoritative source.

## Actual carrier

- Host-to-device and device-to-host use one mapped TransferSlot sized to the
  maximum padded host-leg payload in this batch. Its original Run/Completion is waited
  before reusing that slot. A download writes the actual host MemoryResource
  only after the native completion succeeds.
- Device-to-device uses the existing same-Runtime CopyRecording, on exact
  four-byte-aligned logical spans. It adds the original copy recording/run
  metadata, not another executor or staging payload. Odd device-to-device
  spans and overlapping distinct ranges decline during pure qualification.
- A private exported MemoryAccess staging-cost query uses the same actual
  direction/qualification as execution. Graph Source takes its maximum, so a
  pure D2D batch costs zero staging, while D2D16B plus host3B costs four bytes.
  Actual allocation uses separate host/device maxima. The payload bound does
  not claim to bound driver-internal/recording metadata.
- The complete batch is qualified and its actual device Buffer owners retained
  before accepting work. Foreign device resources, unproven native ownership,
  misaligned origins and insufficient byte ranges do not reach native copy.
- Download source visibility covers ALL_COMMANDS/MEMORY_WRITE, including
  upload/copy producers; the old compute-only source barrier was insufficient.
- A wait/read/write error after acceptance is returned directly, including
  Unimplemented from the host destination. It is not a route-decline signal.

## Logical authorization versus private transfer padding

Before source only recognized the rounded view size as a whole root. A 3-byte
allocation and its first 2-byte slice both round to 4, so that did not prove
permission to overwrite/read the third logical byte. This was a source-level
counterexample, not a separately executed old binary.

The TU-private AllocationToken now records the logical byte authorization.
All three allocation/import/export construction sites initialize it from the
actual allocation request or authorized Tensor description. Private tail padding
is available only for origin zero, full logical span, full logical description,
and the matching padded backing. Otherwise the explicit span bounds the copy.
No external class layout changed; opaque imports are not inferred as owned.

The new raw control checks both 2-byte clipped spans and 2-byte descriptions on
the original 3-byte span, for source and destination. The complete 3-byte
roundtrip then verifies the third-byte sentinel and exact payload.

## Build and runtime separation

commands.json records thirteen small /W4 /WX compilation steps. Final product
objects are memory-staging.obj, source-staging.obj and transfer.obj; final test is
native-tests-staging.obj, with HYLE_TEST_VULKAN_CPU_CONSTANT=1. The private
type was renamed directly without an alias. The last three compiles add the
actual staging-cost correction. A subsequent header comment correction only
clarifies that driver metadata is excluded; no declaration/code changed.
object-identities.json and source-identities.json identify these inputs.

Runtime linking/running belongs to the root agent's constant-replicas stage.
Its original 12/14 failure logs are retained there: the new mixed test first
omitted caller CPU output bindings, then exposed the test host proxy's missing
system map/unmap delegation. Exact source versions are preserved locally in
failed-output-bind-fixture and failed-host-map-fixture. Neither required a
product change. Root's 16 run passed all nine native tests; 18 run passed the
original CPU/Vulkan consumer. These precede the private type rename. Final
19/20 link/run uses the four exact final objects and passes all nine tests;
21/22 relinks/runs the original CPU/Vulkan consumer and passes both rows=1/4
same-slot strict replay, plus the native finite/control/slot journey.
Those precede the staging-cost correction. Final 23/24 link/run uses the
staging-corrected objects and again passes all nine tests. Final 25/26 relinks
and passes the original CPU/Vulkan consumer. Phase source/object identities
are retained in phase-identities.json, including the pre-rename and pre-cost
snapshots; all earlier raw failures remain unchanged in the root stage.

No native SDK/kernel was rebuilt, no timing was run, and no files were removed.
