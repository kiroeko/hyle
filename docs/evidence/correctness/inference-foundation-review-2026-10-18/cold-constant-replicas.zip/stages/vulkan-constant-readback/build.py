from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('driver',
    ROOT / '.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
history = json.loads((ROOT / '.scratch/architecture-refactor-2026-10-18/vulkan-constant-copy/commands.json').read_text())

if __name__ == '__main__':
    for source, name, previous in [
        ('src/compute_route_vulkan/vulkan_memory.cc', 'memory-staging', 'memory-compile'),
        ('src/compute_route_vulkan/vulkan_transfer_slot.cc', 'transfer', 'transfer-compile'),
        ('src/graph_route_vulkan/execution_source.cc', 'source-staging', 'source-compile'),
        ('tests/graph_route_vulkan/native_region_test.cc', 'native-tests-staging', 'native-tests-compile'),
    ]:
        cc = next(row['command'] for row in reversed(history) if row['tag'] == previous)
        flags = [arg for arg in cc[1:] if not arg.lower().startswith('/fo') and not arg.endswith('.cc')]
        if name.startswith('native-tests'):
            flags += ['/DHYLE_TEST_VULKAN_CPU_CONSTANT=1']
        b.run(name + '-compile', [cc[0], *flags, ROOT / source, '/Fo' + str(OUT / (name + '.obj'))])
