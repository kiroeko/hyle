from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('driver',
    ROOT / '.scratch/architecture-refactor-2026-10-18/region-adapter/run.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.OUT = OUT
history = json.loads((ROOT / '.scratch/architecture-refactor-2026-10-18/canonical-constants-cache/commands.json').read_text())

if __name__ == '__main__':
    identities = []
    for source, name in [
        ('src/graph/constant_artifact.cc', 'constant-artifact'),
        ('tests/graph/constant_artifact_cache_test.cc', 'constant-cache-test'),
    ]:
        command = next(row['command'] for row in reversed(history)
            if any(str(arg).replace('\\', '/').endswith('/' + Path(source).name)
                   for arg in row['command']))
        flags = [arg for arg in command[1:]
            if not arg.lower().startswith('/fo') and not arg.endswith('.cc')]
        output = OUT / (name + '.obj')
        identity = {'source': source, 'source_sha256': hashlib.sha256((ROOT / source).read_bytes()).hexdigest()}
        b.run(name + '-compile', [command[0], *flags, ROOT / source, '/Fo' + str(output)])
        identity.update(object=str(output), object_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
        identities.append(identity)
        (OUT / 'identities.json').write_text(json.dumps(identities, indent=2)+'\n')
