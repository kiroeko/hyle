from pathlib import Path
import base64
import hashlib
import io
import json
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-apple-constant-replicas'


def ssh(code, payload=None):
    command = 'python3 -c "import base64;exec(base64.b64decode(\'' + base64.b64encode(code.encode()).decode() + '\'))"'
    result = subprocess.run(['ssh', 'kiro@172.22.10.198', command], input=payload,
                            capture_output=True, timeout=60)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace'))
    return result.stdout


def main():
    files = {'run_remote.py': OUT / 'run_remote.py'}
    seen = set()

    def add(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or '.scratch' in path.relative_to(ROOT).parts:
            return
        seen.add(path)
        files[path.relative_to(ROOT).as_posix()] = path
        for include in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]', path.read_text(encoding='utf-8-sig'), re.M):
            for candidate in [path.parent / include, ROOT / include, ROOT / 'include' / include,
                              ROOT / 'src/graph' / include, ROOT / 'src/compute' / include,
                              ROOT / 'src/compute_route_apple' / include,
                              ROOT / 'src/graph_route_apple' / include,
                              ROOT / 'src/compute_ggml_runtime' / include,
                              ROOT / 'src/compute_provider_ggml_metal' / include]:
                if candidate.is_file():
                    add(candidate)
                    break

    for name in ['executable', 'resources', 'region_access', 'constant_artifact']:
        add(ROOT / 'src/graph' / (name + '.cc'))
    rows = [dict(path=name, bytes=path.stat().st_size,
                 sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            for name, path in sorted(files.items())]
    (OUT / 'staged-sources.json').write_text(json.dumps(rows, indent=2) + '\n')
    files['staged-sources.json'] = OUT / 'staged-sources.json'
    data = io.BytesIO()
    with tarfile.open(fileobj=data, mode='w:gz') as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name)
    (OUT / 'minimal-sources.tar.gz').write_bytes(data.getvalue())
    code = '''from pathlib import Path
import io,sys,tarfile
r=Path(''' + repr(REMOTE) + ''')
assert not r.exists(),r
r.mkdir()
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as a:
 assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in a.getmembers())
 a.extractall(r)
print(r)
'''
    output = ssh(code, data.getvalue())
    (OUT / 'stage.log').write_bytes(output)
    print(output.decode().strip(), len(rows), 'files', len(data.getvalue()), 'bytes')


if __name__ == '__main__':
    main()
