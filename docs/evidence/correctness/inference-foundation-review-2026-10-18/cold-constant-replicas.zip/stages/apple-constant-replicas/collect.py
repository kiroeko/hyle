from pathlib import Path
import hashlib
import io
import json
import tarfile
import zipfile
import stage

OUT = Path(__file__).resolve().parent
code = '''from pathlib import Path
import io,sys,tarfile
r=Path(''' + repr(stage.REMOTE) + ''')
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as a:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.suffix in {'.log','.json','.txt','.py'}:
   a.add(p,arcname=p.name)
sys.stdout.buffer.write(b.getvalue())
'''
payload = stage.ssh(code)
(OUT / 'remote-evidence.tar.gz').write_bytes(payload)
remote = OUT / 'remote'
remote.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
    assert all(member.isfile() and '/' not in member.name and '..' not in Path(member.name).parts
               for member in archive.getmembers())
    archive.extractall(remote)
result = json.loads((remote / 'test-results.json').read_text())
assert result['tests'] == 5 and not result['failures'] and not result.get('errors', 0)
commands = json.loads((remote / 'commands.json').read_text())
assert len(commands) == 8 and all(row['exit'] == 0 for row in commands)
finite = next(row for row in commands if row['tag'] == 'finite-tests')
finite_output = (remote / finite['stdout']).read_text()
assert 'PASS' in finite_output
manifest = json.loads((OUT / 'staged-sources.json').read_text())
final_native = json.loads((remote / 'native-tests-identities.json').read_text())
final_finite = json.loads((remote / 'finite-native-identities.json').read_text())
cleanup = []
for name, rows in [('native-tests', final_native), ('finite-native', final_finite)]:
    for row in rows:
        if row['path'] in [stage.REMOTE + '/' + name, stage.REMOTE + '/' + name + '.map']:
            cleanup.append(row)
(OUT / 'cleanup-candidates.json').write_text(json.dumps(
    dict(host='kiro@172.22.10.198', candidates=cleanup, deletion_executed=False), indent=2) + '\n')
summary = dict(
    scope='Apple regression of common cold cross-storage constant replicas; original native consumers only',
    host='kiro@172.22.10.198', remote_stage=stage.REMOTE,
    hardware_and_toolchain=(remote / 'machine.txt').read_text(),
    source_delivery=dict(files=len(manifest), archive_bytes=(OUT / 'minimal-sources.tar.gz').stat().st_size,
                         manifest='staged-sources.json', sdk_or_checkout_copied=False),
    fresh_host_tus=['src/graph/executable.cc', 'src/graph/resources.cc',
                    'src/graph/region_access.cc', 'src/graph/constant_artifact.cc'],
    source_identity={row['path']: row['sha256'] for row in manifest
                     if row['path'] in ['src/graph/executable.cc', 'src/graph/resources.cc',
                         'src/graph/region_access.cc', 'src/graph/constant_artifact.cc',
                         'src/graph/plan_state.h']},
    actual_results=dict(native_tests=result['tests'], failures=result['failures'],
                        filter='AppleNativeRegion.*:AppleLateInput.*',
                        native_log='remote/06-native-tests.stdout.log',
                        finite_exit=finite['exit'], finite_log='remote/' + finite['stdout'],
                        finite_output=finite_output.strip()),
    input_identity_files=['remote/retained-identities.json', 'remote/native-tests-identities.json',
                          'remote/finite-native-identities.json'],
    commands='remote/commands.json', execution_terminal=True,
    limits=['Original native ownership/two-fragment deferred-port/late-input/finite/control paths retained.',
            'No SDK, shader, GraphBatch, whole checkout, model run or performance measurement.',
            'Cross-storage replica math/copy/family-budget assertions were run by root on host; this is the native regression closure.',
            'Objects retained remotely. Binary/map identities only; no payload included and no deletion executed.'])
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
archive_path = OUT / 'source-results.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(OUT.rglob('*')):
        if not path.is_file() or path == archive_path or path.name == 'package-identity.json':
            continue
        if path.suffix in {'.py', '.json', '.log', '.txt'} or path.name == 'minimal-sources.tar.gz':
            archive.write(path, path.relative_to(OUT).as_posix())
identity = dict(path=str(archive_path), bytes=archive_path.stat().st_size,
                sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest())
(OUT / 'package-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(identity))
print(json.dumps(summary['actual_results']))
