from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
history = json.loads((OUT.parent / 'region-adapter/commands.json').read_text())
old = next(row['command'] for row in reversed(history)
           if row['tag'] == 'region_provider_test-compile' and row['exit'] == 0)
command = [arg for arg in old if not arg.lower().startswith('/fo')]
command.append('/Fo' + str(OUT / 'region_provider_test.obj'))
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    paths = [ROOT / 'tests/graph/region_provider_test.cc',
             ROOT / 'src/graph/plan_state.h']
    before = {str(path): sha(path) for path in paths}
    env = windows_compiler_environment(
        {'CMAKE_CXX_COMPILER': command[0], 'CMAKE_C_COMPILER': command[0]})
    env['VSLANG'] = '1033'
    started = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                            timeout=180, creationflags=subprocess.CREATE_NO_WINDOW)
    records_path = OUT / 'commands.json'
    records = json.loads(records_path.read_text()) if records_path.exists() else []
    stem = f'{len(records) + 1:02d}-test-compile'
    (OUT / (stem + '.stdout.log')).write_bytes(result.stdout)
    (OUT / (stem + '.stderr.log')).write_bytes(result.stderr)
    records.append(dict(tag='test-compile', command=command, exit=result.returncode,
                        seconds=time.monotonic() - started,
                        stdout=stem + '.stdout.log', stderr=stem + '.stderr.log'))
    records_path.write_text(json.dumps(records, indent=2) + '\n')
    after = {str(path): sha(path) for path in paths}
    identity = dict(before=before, after=after, unchanged=before == after,
                    compiled=not result.returncode)
    obj = OUT / 'region_provider_test.obj'
    if not result.returncode:
        identity['object'] = dict(path=str(obj), sha256=sha(obj), size=obj.stat().st_size)
    (OUT / 'compile-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    print(stem, result.returncode, flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-7000:])
        print(result.stderr.decode(errors='replace')[-2000:])
    if before != after:
        raise SystemExit('Source or PlanState changed during compilation')
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
