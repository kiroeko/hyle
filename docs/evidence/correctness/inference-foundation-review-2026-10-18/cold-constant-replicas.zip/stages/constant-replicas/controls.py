from pathlib import Path
import json
import os
import sys
import build

ROOT, OUT, b = build.ROOT, build.OUT, build.b
ARCH = OUT.parent
history = json.loads((ARCH / 'native-replay-bridge/commands.json').read_text())
old = next(row['command'] for row in reversed(history)
           if row['tag'] == 'controls-link' and row['exit'] == 0)
replacements = {
    'executable.obj': OUT / 'executable.obj',
    'resources.obj': OUT / 'resources.obj',
    'region_access.obj': OUT / 'region_access.obj',
    'constant_artifact.obj': ARCH / 'constant-physical-owners/constant-artifact.obj',
    'constant_artifact_cache_test.obj': ARCH / 'constant-physical-owners/constant-cache-test.obj',
    'graph-batch.obj': ARCH / 'constant-physical-owners/graph-batch.obj',
    'region_provider_test.obj': ARCH / 'constant-replicas-tests/region_provider_test.obj',
}
command = []
for arg in old:
    if arg.upper().startswith('/OUT:'):
        command.append('/OUT:' + str(OUT / 'controls.exe'))
    elif arg.upper().startswith('/MAP:'):
        command.append('/MAP:' + str(OUT / 'controls.map'))
    else:
        command.append(str(replacements.get(Path(arg).name, arg)))
b.run('controls-link', command)
torch = next(Path(arg) for arg in command if Path(arg).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
b.run('controls-run', [OUT / 'controls.exe', '--gtest_color=no',
    '--gtest_filter=' + sys.argv[1], '--gtest_output=json:' + str(OUT / 'controls-results.json')])
