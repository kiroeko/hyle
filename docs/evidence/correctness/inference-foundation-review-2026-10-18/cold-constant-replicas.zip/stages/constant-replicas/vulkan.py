from pathlib import Path
import json
import os
import sys
import build

ROOT, OUT, b = build.ROOT, build.OUT, build.b
ARCH = OUT.parent
history = json.loads((ARCH / 'native-replay-bridge/commands.json').read_text())
consumer = len(sys.argv) > 1 and sys.argv[1] == 'consumer'
tag = 'vulkan-consumer-link' if consumer else 'native-tests-link'
old = next(row['command'] for row in reversed(history) if row['tag'] == tag and row['exit'] == 0)
replacements = {
    'executable.obj': OUT / 'executable.obj',
    'resources.obj': OUT / 'resources.obj',
    'region_access.obj': OUT / 'region_access.obj',
    'constant_artifact.obj': ARCH / 'constant-physical-owners/constant-artifact.obj',
    'graph-batch.obj': ARCH / 'constant-physical-owners/graph-batch.obj',
    'native-region-detached-test.obj': ARCH / 'vulkan-constant-readback/native-tests-staging.obj',
    'vulkan-source-final.obj': ARCH / 'vulkan-constant-readback/source-staging.obj',
}
name = 'vulkan-consumer' if consumer else 'native-tests'
command = []
for arg in old:
    path = Path(arg)
    if arg.upper().startswith('/OUT:'):
        command.append('/OUT:' + str(OUT / (name + '.exe')))
    elif arg.upper().startswith('/MAP:'):
        command.append('/MAP:' + str(OUT / (name + '.map')))
    elif path.parent.name == 'vulkan-constant-copy' and path.name == 'memory.obj':
        command.append(str(ARCH / 'vulkan-constant-readback/memory-staging.obj'))
    elif path.parent.name == 'vulkan-constant-copy' and path.name == 'transfer.obj':
        command.append(str(ARCH / 'vulkan-constant-readback/transfer.obj'))
    else:
        command.append(str(replacements.get(path.name, arg)))
b.run(name + '-link', command)
torch = next(Path(arg) for arg in command if Path(arg).name.lower() == 'torch_cpu.lib')
os.environ['PATH'] = str(torch.parent) + os.pathsep + os.environ['PATH']
if consumer:
    b.run(name + '-run', [OUT / (name + '.exe')])
else:
    b.run(name + '-run', [OUT / (name + '.exe'), '--gtest_color=no',
        '--gtest_filter=VulkanNativeRegion.*:VulkanCopyProgram.TwoSlotsPhaseReadyOldResultsAndReplayKeepActualMetadataFixed',
        '--gtest_output=json:' + str(OUT / 'native-results.json')])
