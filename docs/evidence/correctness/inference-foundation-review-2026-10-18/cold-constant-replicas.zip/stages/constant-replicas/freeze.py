from pathlib import Path
import hashlib
import json
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
DEST = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/cold-constant-replicas.zip'
STAGES = ['constant-replicas', 'constant-physical-owners', 'constant-replicas-tests',
          'vulkan-constant-readback', 'apple-constant-replicas', 'apple-cold-constants']
SOURCES = '''
include/hyle/graph/executable.h
include/hyle/graph/region_provider.h
src/graph/executable.cc
src/graph/resources.cc
src/graph/region_access.cc
src/graph/constant_artifact.cc
src/graph/constant_artifact.h
src/graph/plan_state.h
src/graph_batch/batch.cc
src/compute_route_vulkan/vulkan_memory.cc
src/compute_route_vulkan/vulkan_memory_internal.h
src/compute_route_vulkan/vulkan_transfer_slot.cc
src/graph_route_vulkan/execution_source.cc
src/compute_route_apple/apple_copy_internal.h
src/compute_route_apple/apple_memory.mm
src/graph_route_apple/execution_source.cc
tests/graph/constant_artifact_cache_test.cc
tests/graph/region_provider_test.cc
tests/graph_route_vulkan/native_region_test.cc
tests/graph_route_vulkan/CMakeLists.txt
tests/graph_route_apple/native_region_test.cc
docs/architecture/compute-design.md
docs/developer/current-work.md
docs/user/graph.md
'''.split()


def read(path):
    return json.loads(path.read_text())


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return {'path': path.relative_to(ROOT).as_posix(),
            'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def latest(rows, tag):
    row = next(row for row in reversed(rows) if row['tag'] == tag)
    assert row['exit'] == 0, (tag, row)
    return row


def main():
    host = read(OUT / 'controls-results.json')
    vulkan = read(OUT / 'native-results.json')
    apple = read(ARCH / 'apple-cold-constants/remote/test-results.json')
    for result, count in [(host, 11), (vulkan, 9), (apple, 7)]:
        assert result['tests'] == count and result['failures'] == 0 and result['errors'] == 0
    rows = read(OUT / 'commands.json')
    final_runs = [latest(rows, tag) for tag in ['controls-run', 'native-tests-run', 'vulkan-consumer-run']]
    closures = [latest(rows, tag)['command'] for tag in ['controls-link', 'native-tests-link', 'vulkan-consumer-link']]
    objects = sorted({Path(arg).resolve() for command in closures for arg in command
                      if Path(arg).suffix.lower() == '.obj' and Path(arg).is_file()})
    source_names = set(SOURCES)
    for stage in ['apple-constant-replicas', 'apple-cold-constants']:
        for entry in read(ARCH / stage / 'staged-sources.json'):
            name = entry['path']
            if (ROOT / name).is_file():
                source_names.add(name)
            else:
                assert name == 'run_remote.py', name
    dump('final-identities.json', {
        'sources': [identity(ROOT / name) for name in sorted(source_names)],
        'windows_link_objects': [identity(path) for path in objects],
        'apple_final_link_identities': 'apple-cold-constants/remote/native-tests-identities.json',
    })
    mac_roots, mac_files, retained = [], [], {}
    for stage in ['apple-constant-replicas', 'apple-cold-constants']:
        plan = read(ARCH / stage / 'cleanup-candidates.json')
        files = plan['candidates']
        roots = {str(Path(entry['path']).parent).replace('\\', '/') for entry in files}
        assert len(roots) == 1
        mac_roots.extend(roots)
        mac_files.extend(files)
    for stage in ['apple-constant-replicas', 'apple-cold-constants']:
        for entry in read(ARCH / stage / 'remote/native-tests-identities.json'):
            path = Path(entry['path'])
            if str(path.parent).replace('\\', '/') in mac_roots and path.suffix == '.o':
                retained[entry['path']] = entry
    assert len(retained) == 7
    dump('cleanup-mac.json', {'roots': mac_roots, 'files': mac_files,
                              'retain': list(retained.values())})
    dump('summary.json', {
        'scope': 'Cold physical constant owners and local packing; real Vulkan/Apple native constant transfers; architecture goal remains active',
        'host_result': host,
        'vulkan_result': vulkan,
        'apple_result': apple,
        'final_windows_run_commands': final_runs,
        'changes': [
            'Unique actual canonical owner arena with per-physical-instance indices; primary borrow policy stays unchanged',
            'Metadata Views share complete destination roots, preserve exact offsets and logical control dependencies',
            'Region packing reads selected physical bindings instead of global primary weights',
            'Ready retry owners reselected by real immutable key before pruning; shared bytes charged only once',
            'Actual copy or Completion errors remain fatal; only pure route qualification can decline a candidate',
            'Vulkan real H2D, D2H and aligned D2D reuse original TransferSlot/CopyRecording and terminal owners',
            'Vulkan padding authority respects logical allocation length and exact copied bytes, not only rounded capacity',
            'Vulkan host staging and D2D capacities/accounting separated so mixed batches do not stage large D2D payloads',
            'Apple native-only synchronous shared Metal copies retain actual allocation/device/write permissions without a CPU Context',
        ],
        'actual_evidence': [
            'Host double-storage borrowed root: one cold full copy, two same-shape offsets, two slots, strict replay and reset replay',
            'Finite-shape local packing: exact source resource/data, one copy/pack per storage, child lifetime and exact family budget boundary',
            'Vulkan native tests include odd roots, clipped/full-span-short-description rejection, accepted wait/write failures and real CPU/native math',
            'Original CPU/Vulkan/CPU finite consumer has two strict same-slot submits with changing contents at rows1/4',
            'Apple original5 + new2: native-only finite shared weights, caller source release, two-slot replay, readonly-target rejection and fatal source error',
            'Apple native-only finite/control consumer passes on final Source/memory/common object closure',
        ],
        'retained_failures': [
            'Initial added host test used Result as a pointer; fixture compile fixed',
            'Initial new alias creation checked provider alignment too early; restored prepare_replay admission and original domain regression passes',
            'First actual mixed Vulkan fixture omitted CPU caller output bindings',
            'Second mixed fixture advertised host mapping but omitted its real map/unmap implementation',
        ],
        'limits': [
            'No SDK/shader rebuild, whole checkout copy, broad matrix, new Linux validation, throughput or complete Qwen numerical/performance acceptance',
            'Vulkan D2D remains exact four-byte geometry and actual same-Runtime transfer backing; no permissions invented for unknown imports',
            'Apple source must already be ready/immutable; no implicit producer eval or unrelated Queue wait',
            'Copy payload bytes and supplied allocator metadata are tracked; native driver overhead is not claimed zero or bounded',
            'Cross-Runtime, remaining hybrid/page/custom/legacy execution migrations and inherited model-functional review remain incomplete',
        ],
    })
    with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(source_names):
            archive.write(ROOT / name, 'final-source/' + name)
        for stage in STAGES:
            for path in sorted((ARCH / stage).rglob('*')):
                if not path.is_file() or '__pycache__' in path.parts:
                    continue
                if path.name in {'archive.json', 'cleanup.json', 'cleanup-result.json', 'cleanup-mac-result.json'}:
                    continue
                if path.suffix.lower() in {'.py', '.json', '.log', '.jsonl', '.cc', '.mm', '.h', '.diff', '.patch', '.txt', '.md'}:
                    archive.write(path, 'stages/' + path.relative_to(ARCH).as_posix())
        for stage in ['apple-constant-replicas', 'apple-cold-constants']:
            path = ARCH / stage / 'minimal-sources.tar.gz'
            with tarfile.open(path) as source_archive:
                assert all(member.isfile() and not Path(member.name).is_absolute()
                           and '..' not in Path(member.name).parts
                           and Path(member.name).suffix in {'.h', '.cc', '.mm', '.py', '.json'}
                           for member in source_archive.getmembers())
            archive.write(path, 'deployed-apple/' + stage + '.tar.gz')
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
    receipt = identity(DEST)
    dump('archive.json', receipt)
    allowed = [ARCH / stage for stage in STAGES]
    files = [identity(path) for stage in allowed for path in sorted(stage.iterdir())
             if path.is_file() and path.suffix.lower() in {'.exe', '.map', '.lib', '.exp'}]
    dump('cleanup.json', {'evidence': receipt['path'],
        'allowed': [stage.relative_to(ROOT).as_posix() for stage in allowed], 'files': files})
    print(json.dumps({'archive': receipt, 'windows_files': len(files),
        'windows_bytes': sum(row['bytes'] for row in files), 'mac_files': len(mac_files),
        'mac_bytes': sum(row['bytes'] for row in mac_files)}))


if __name__ == '__main__':
    main()
