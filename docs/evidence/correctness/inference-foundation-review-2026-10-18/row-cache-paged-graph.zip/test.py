from pathlib import Path
import sys,json,os
sys.path.insert(0,str(Path(__file__).resolve().parent));import build as b
R=b.R;O=b.O;backend=sys.argv[1];D=R/'.scratch/inference-fusion-quantization-2026-10-18/derived-constant-implementation';P=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-reader';F=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-pages';old=json.loads((D/'commands.json').read_text());link=next(x['command']for x in reversed(old)if x['tag']==backend+'-link'and x['exit']==0)
if __name__=='__main__':
 flags=[*b.flags]+(['/DHYLE_ROW_CACHE_GRAPH_CUDA=1','/DHYLE_COMPUTE_CUDA=1','/IC:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include']if backend=='cuda'else[])
 b.run(backend+'-test-compile',[*flags,R/'tests/graph_batch/row_cache_graph_test.cc','/Fo'+str(O/(backend+'-test.obj'))])
 omit={'cpu-tests.obj','cuda-tests.obj','consumer.obj','batch-layout.obj','paged-arena.obj','graph-batch.obj','batch-execution.obj','cuda-cuda_provider.obj'}
 cmd=[str(O/'leased.obj')if x==str(D/'graph-leased_invocation.obj')else x for x in link if Path(x).name not in omit and not x.startswith(('/OUT:','/MAP:'))]
 cmd=[str(R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/cuda-tensor.obj')if x==str(R/'.scratch/inference-foundation-review-2026-10-18/native-shape-fusion/tensor-after.obj')else x for x in cmd]
 extras=[O/'batch.obj',O/'node.obj',O/(backend+'-test.obj'),F/'batch_layout.obj',F/'paged_arena.obj',F/'batch_execution.obj',R/'.scratch/inference-foundation-review-2026-10-18/row-cache-contracts/low-precision.obj']
 if backend=='cpu':extras +=[P/'cpu-codec.obj',P/'cpu-native-provider.obj',O/'native-node.obj',O/'native-node-test.obj',F/'batch_paged_native.obj']
 else:extras +=[P/'cuda-provider.obj',P/'cuda-row-provider.obj',P/'cuda-kernel.obj']
 runtime=[str(R/'.scratch/build-compute-v2-dev/bin'),'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin','C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/x64']+[str(Path(x).parent)for x in cmd if x.endswith('.lib')and Path(x).is_absolute()]
 env=dict(b.env);env['PATH']=os.pathsep.join(dict.fromkeys(runtime))+os.pathsep+env['PATH']
 b.run(backend+'-link',[*cmd,*extras,'/OUT:'+str(O/(backend+'-test.exe'))],env)
 b.run(backend+'-test',[O/(backend+'-test.exe')],env)
