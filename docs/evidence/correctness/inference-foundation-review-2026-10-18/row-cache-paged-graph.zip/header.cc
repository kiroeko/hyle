#include "hyle/graph/batch.h"
static_assert(sizeof(hyle::graph::batch::Invocation)==sizeof(void*));
