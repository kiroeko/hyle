from pathlib import Path
import json,sys,subprocess,os,time
R=Path.cwd();O=R/'.scratch/inference-foundation-review-2026-10-18/row-cache-paged-graph';sys.path.insert(0,str(R/'scripts'))
from hyle_environment import windows_compiler_environment
cache=json.loads((R/'.scratch/inference-foundation-review-2026-10-18/batched-sink-ggml/commands.json').read_text());host=next(x['command']for x in cache if x['tag']=='cpu-canonical-compile'and x['exit']==0)
flags=[x for x in host if not x.endswith('.cc')and not x.lower().startswith('/fo')]
env=windows_compiler_environment({'CMAKE_CXX_COMPILER':host[0],'CMAKE_C_COMPILER':host[0]});env['VSLANG']='1033';env['OMP_NUM_THREADS']='2';env['MKL_NUM_THREADS']='2'
records=json.loads((O/'commands.json').read_text())if(O/'commands.json').exists()else[]
def run(tag,cmd,environment=None):
 stem=str(len(records)+1)+'-'+tag;start=time.monotonic();p=subprocess.run(list(map(str,cmd)),cwd=R,env=environment or env,capture_output=True,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 (O/(stem+'.stdout.log')).write_bytes(p.stdout);(O/(stem+'.stderr.log')).write_bytes(p.stderr);records.append(dict(tag=tag,command=list(map(str,cmd)),exit=p.returncode,seconds=time.monotonic()-start));(O/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,p.returncode,p.stdout.decode(errors='replace')[-7500:],p.stderr.decode(errors='replace')[-3000:],flush=True);p.check_returncode()
def compile(source,name):run(name+'-compile',[*flags,R/source,'/Fo'+str(O/(name+'.obj'))])
if __name__=='__main__':
 for source,name in [('src/graph/leased_invocation.cc','leased'),('src/graph_batch/batch.cc','batch'),('src/graph_batch/row_cache_node.cc','node')]:compile(source,name)
