from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
paths = ['cmake/HyleComponents.cmake', 'include/hyle/compute/detail/builtin_provider_ids.h',
         'include/hyle/compute/providers/native.h', 'include/hyle/compute/providers/cuda.h',
         'src/graph/leased_invocation.cc', 'src/graph_batch/batch.cc']
identities = []
for name in paths:
    source = ROOT / name
    dest = OUT / 'applied' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)
    identities.append(dict(path=name, bytes=source.stat().st_size,
                           sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
manifest = (ROOT / paths[0]).read_text()
before = manifest.replace(' hyle/compute/apple_row_cache.h', '').replace(' hyle/compute/vulkan_row_cache.h', '')
before = before.replace('      hyle/compute/row_cache_paged.h\n', '')
before = before.replace('  _hyle_declare_component(graph_batch\n    PRIVATE_DEPS core util_core compute_ops',
                        '  _hyle_declare_component(graph_batch\n    PRIVATE_DEPS core util_core')
(OUT / 'manifest-before.cmake').write_text(before)
(OUT / 'source.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True), manifest.splitlines(True),
    fromfile=paths[0] + '.before', tofile=paths[0])))
for name in paths[2:4]:
    old = subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=ROOT).decode('utf-8')
    current = (ROOT / name).read_text()
    with (OUT / 'source.diff').open('a') as stream:
        stream.write(''.join(difflib.unified_diff(old.splitlines(True), current.splitlines(True),
                                               fromfile=name + '.before', tofile=name)))
source = OUT.parent / 'cuda-paged-indexer'
for name in ['neutral-header-check.cc', '09-neutral-cpu-headers-compile.stdout.log', '09-neutral-cpu-headers-compile.stderr.log']:
    shutil.copyfile(source / name, OUT / name)
commands = json.loads((source / 'commands.json').read_text())
selected = [record for record in commands if 'neutral' in json.dumps(record).lower()]
(OUT / 'compile-command.json').write_text(json.dumps(selected, indent=2) + '\n')
(OUT / 'source-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
(OUT / 'summary.json').write_text(json.dumps(dict(
    status='Fixed public header ownership and neutral Graph dependency errors; focused configure/compile PASS',
    defects=['Three new row-cache public headers defaulted to compute instead of their actual batch/Apple/Vulkan owners, contaminating selection/install lists.',
             'Backend-neutral Graph included optional native/CUDA factory headers merely for exact ID checks; actual graph_batch factor configure failed.',
             'New graph_batch row nodes directly include compute_ops schema but the factor did not declare that private edge.'],
    repair='Register exact three header owners, add only graph_batch private compute_ops edge, and share unchanged native/CUDA ProviderIds in one neutral compute detail header. Optional factories alias the same constants; original exact permission checks remain. No new provider/SDK link edge or provider-vtable ABI change.',
    validation='project(LANGUAGES NONE) includes the actual HyleComponents with HYLE_DEV_FACTORS=graph_batch. 1-configure.log retains the previous dependency failure; 2-configure.log passes in 0.1s and checks each header owner and owner install list. Separate four-core-header C++ TU compiles without optional factory headers. No dependency discovery, SDK or full build.',
    scope='Graph source snapshots include separately owned pending CUDA cold-span work. This package qualifies the include/identity/manifest changes, not the pending scorer mathematics or final whole-Graph snapshot.',
    retain='No binaries included or removed; all existing objects/SDK retained.'), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
bundle = OUT / 'source-results.zip'
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(OUT.rglob('*')):
        if file.is_file() and 'build' not in file.relative_to(OUT).parts and file != bundle:
            archive.write(file, file.relative_to(OUT))
print(json.dumps(dict(path=str(bundle.relative_to(ROOT)), bytes=bundle.stat().st_size,
                      sha256=hashlib.sha256(bundle.read_bytes()).hexdigest())))
