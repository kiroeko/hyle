#include "hyle/compute/detail/builtin_provider_ids.h"
static_assert(hyle::compute::detail::kNativeProviderId.valid());
static_assert(hyle::compute::detail::kCudaNativeProviderId.valid());
static_assert(hyle::compute::detail::kNativeProviderId != hyle::compute::detail::kCudaNativeProviderId);
