"""Archive the small source/log stage; omit reconstructible compiled artifacts."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

stage = Path(__file__).resolve().parent
root = stage.parents[3]
archive = root / "docs/evidence/correctness/inference-foundation-review-2026-10-18/completion-handoff.zip"
for name in ("docs/architecture/compute-design.md", "docs/developer/current-work.md",
             "docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md", "test.ps1"):
    target = stage / "candidate" / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / name, target)
paths = ("include/hyle/compute/detail/retained_completion.h",
         "src/compute/retained_completion.cc", "tests/compute/completion_test.cc")
identities = json.loads((stage / "source-identities.json").read_text(encoding="utf-8"))
for entry in identities:
    data = (root / entry["source"]).read_bytes()
    assert len(data) == entry["bytes"]
    assert hashlib.sha256(data).hexdigest() == entry["sha256"]
    assert data == (stage / "candidate" / entry["source"]).read_bytes()
current = (root / paths[1]).read_bytes()
old = (stage / "before/retained_completion.cc").read_bytes()
marker = b"struct DependentCompletionState"
assert current[current.index(marker):] == old[old.index(marker):]
excluded = {".obj", ".exe", ".map", ".lib", ".exp", ".pdb", ".zip", ".pyc"}
entries = []
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(stage.rglob("*")):
        if not path.is_file() or path.suffix.lower() in excluded or "__pycache__" in path.parts or path.name == "archive-receipt.json":
            continue
        name = path.relative_to(stage).as_posix()
        output.write(path, name)
        entries.append(name)
with zipfile.ZipFile(archive) as saved:
    assert saved.testzip() is None
    for source in paths:
        assert saved.read("candidate/" + source) == (root / source).read_bytes()
    assert saved.read("validation-summary.json") == (stage / "validation-summary.json").read_bytes()
data = archive.read_bytes()
receipt = {"path": str(archive.relative_to(root)), "entries": len(entries),
           "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
           "scope": "41 host ownership tests; no Graph async, native GPU, model or performance claim"}
(stage / "archive-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
