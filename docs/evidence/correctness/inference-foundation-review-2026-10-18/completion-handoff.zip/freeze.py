import hashlib,json,pathlib,subprocess
root=pathlib.Path.cwd()
stage=root/'.scratch/architecture-refactor-2026-10-18/async-progress/retained'
paths=['include/hyle/compute/detail/retained_completion.h','src/compute/retained_completion.cc','tests/compute/completion_test.cc']
identities=[]
for p in paths:
    source=root/p
    target=stage/'candidate'/p
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(source.read_bytes())
    identities.append({'source':p,'bytes':source.stat().st_size,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
old=(stage/'before/retained_completion.cc').read_bytes()
new=(root/paths[1]).read_bytes()
marker=b'struct DependentCompletionState'
assert old[old.index(marker):]==new[new.index(marker):], 'Dependent/CopyOutcome section changed'
proc=subprocess.run(['git','diff','--check','--',*paths],capture_output=True,text=True)
(stage/'diff-check.log').write_text(proc.stdout+proc.stderr,encoding='utf-8')
assert proc.returncode==0
proc=subprocess.run(['git','diff','--',*paths],capture_output=True)
(stage/'source.diff').write_bytes(proc.stdout)
(stage/'source-identities.json').write_text(json.dumps(identities,indent=2)+'\n',encoding='utf-8')
summary={'status':'source frozen; not compiled or run in this stage','scope':paths,'dependent_and_copy_outcome_tail':'byte-identical to before snapshot','diff_check':'PASS','new_tests':['RetainedPendingWaitPinsControlUntilConcurrentHandoffIsObserved','RetainedPendingCancelAndAbandonRaceActualInstallationSafely','RetainedPendingEarlyAbandonStillTransfersActualNativeRetirement','RetainedPendingInlineHandoffAllowsSynchronousRetirementCallbacks','RetainedPendingDeferredLatchAndColdSlotReuseKeepOriginalContracts','RetainedPendingTicketSurvivesObservationRootResetAndDestruction'],'handoff_ticket':'Move-only one-pointer ticket owns the existing driver State reference; successful claim empties it before synchronous callbacks; failure consumes neither ticket nor Completion. Pending member may reset or be destroyed independently. Unfulfilled ticket destruction is an internal protocol error.', 'concurrency':'Public/control observations remain externally serialized; handoff may overlap poll/wait/cancel/abandon. Native handle temporarily moves to observer stack for exclusive native calls outside State lock. Pending control owns only notification state, never Invocation.','retirement':'Existing reserve_retirement latch remains authoritative. Pending driver ref ends at handoff; public and actual-native-retirement refs independently prevent reuse.','validation_boundary':'No compiler, SDK build, or native execution performed by this agent; root will build matched host closure.'}
summary.update({'phase_refactor':'Mutually exclusive Unpublished/Pending/Installing/Installed enum; native_active and retirement remain orthogonal. reserve checks old phase before reset; Installing wait remains pending.', 'prior_validation':'Root matched 4 host TUs /W4 /WX and 41/41 passed before this enum-only refactor; original validation logs/scripts remain untouched. This final cc awaits root single-TU compile/relink.'})
(stage/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(identities,indent=2))
