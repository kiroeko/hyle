# 当前工作主线

2026-10-17，用户明确以下八项工作；后续按用户选择推进。
本页记录任务与范围，不引入状态机、审批、预算或新的开发门禁。

1. 已删除旧治理工具、状态源、审批与资格流程，精简相关说明；保留实际构建、数值、资源寿命和并发回归。
2. 删除、合并、简化文档，减少重复和失效规则，保留有用的设计依据与历史源码、日志、数据。
   已按“首次构建→接入 C++→按任务查模块”重排入口，保留四层分工；共用合同集中说明，
   复杂边界保留示例与反例，过程卡与过时规则已清理。入口见[文档导航](../README.md)。
3. 提供统一初始化入口，在受支持系统上用简单参数配置编译环境，复用工具链与依赖缓存。
   2026-10-18 已统一为 `scripts/init.py`、`build.py`、`test.py`：自动发现工具链，按后端与产品
   准备依赖，支持配置切换、增量构建和安装；基础系统工具仍按平台正常安装。用法见[初始化指南](setup/README.md)。
4. 检查 Compute/Graph 的公共 C++ 接口是否符合推理引擎调用需要，包括易用性、一致性、布局
   转换及暴露给用户的内部 CMake 变量和宏。不按旧六问重新审核全项目。
   构建系统已完成路线、依赖、target 宏与资源装配的统一，见[构建设计](../architecture/build-system.md)。
   2026-10-18 已静态核对四条后端路线及三种 CPU＋GPU 桥接的公开头、所属 target、能力宏和安装闭包，
   普通消费者仍只链接产品 target；本轮未重跑跨平台交付构建。已移除 direct submit 的双输出位置歧义，
   多输出改用既有 span 入口；禁止租约绑定借用临时 writer，并明确各 owner 的 drain 是否永久关闭接纳。
   同步修正独立 runtime 的公开 prepare 入口及初始化后端选择说明。
5. 狩猎剩余性能输项；只要确认超出仪器分辨率与测量噪声，即使差距小也继续调查。
   2026-10-18 全模块首轮调研及当前优化见[性能清单](../evidence/performance/library-review-2026-10-18/README.md)。
   先排除不同工作与过期实现，再处理真实复杂度问题；历史小输与当前待测项分开记录。
6. 尽快完成独立的 Qwen3.5-2B 纯文本、无 MTP、无多模态、完整 CUDA C++ 推理消费者，
   在同系统、同设备、同源权重与匹配精度/输入条件下对比 llama.cpp 的 prefill/decode tokens/s。
   通过实际调用发现接口、布局、状态管理和执行成本问题，不把外部参考或片段算作完整引擎。
7. 补全 MTP 所需的底座能力与真实消费者验证。
   2026-10-18 本轮补全 GDN 接受前缀快照、融合 recurrent 多 token 输入、页失败后的安全重试，
   并扩展公共状态消费者；用法与引擎边界见[状态版本](../user/state-versions.md#mtp-接受前缀并继续计算)。
8. 补全多模态所需的底座能力与真实消费者验证，优先图像 encoder/projector（mmproj）链路。

## 当前重构主线

2026-10-18，当前主线调整为 Compute/Graph 推理执行架构的设计与全量重构。
先把整体调用链和所有权设计清楚，再纵向迁移实现；目标同时包括算子自然扩展、推理全过程衔接和性能。
目标架构、动态变化边界、迁移次序与完成条件集中在[推理执行体系的重构形状](../architecture/compute-design.md#推理执行体系的重构形状)，
本页不另复制一套设计。

- 统一模型语义图、冷编译、不可变计划、独立执行槽、prepare/layout 更新与严格 submit；普通引擎中间层
  不判断平台、Provider 或原生算子，同一后端的承载事实供 Direct/Graph 共用。
- 纳入原生生成结果的真实所有权，收拢计划、执行槽和退休；保留 caller-buffer 快路径、原生融合与异步进度。
- 贯通 prefill、cached continuation、decode、多请求、页与状态反馈，以及已有分支/接受前缀、失败/重试/关闭能力；
  同时消除具体 op/Provider 在共同资源核心中的特殊判断。
- 以性能约束架构：路由和规划冷生成，动态变化有明确准备边界；追查重复分配、转换、上传、搬运、host 等待及
  时间/空间复杂度问题。单 GPU 不强制 CPU 数学 Context 或额外调度运行时，必要原生开销如实保留并报告。
- 独立 Qwen3.5-2B 文本 CUDA 消费者尽早贯穿新主链，作为实际接口与性能反馈；多模态模型接线和完整 MTP 引擎
  政策不在本 goal 内，其已有底座能力不得退化。普通 API、构建依赖与文档随迁移收拢，不增加治理或繁复验证。
  该引擎是架构测试产物，用真实模型推理发现并回修底座 gap，不作为正式推理引擎产品扩张。

当前不再按旧结构扩专用接口。已接通的共同基础包括：

- 原 Invocation 的资源、结果与 batch/page 控制；实际 ExecutionSource、QueueRef／QueueSequence
  的保活和接纳；原 Plan／Cursor 的提交、终点聚合和退休。共同核心不再按后端名字放宽准入。
- Vulkan／Apple 固定纯图的原生结果及 GraphOutput；同 Runtime 的 MLX 晚端口、源槽保护和只读 View
  反馈；CPU＋Apple dense 数据链与 CPU＋Vulkan 双向动态搬运／控制片段。仍不代表旧混合驱动已经删除。
- 共同有限形状 family、canonical 常量及跨存储根的冷物化与共享；Apple／Vulkan 的真实冷搬运。
  已删除专用形状表包装，默认 CPU Context 的 Provider 装配与 batch 编译分开 TU。
- 原依赖边的 O(S+E) 后继索引与就绪前沿。CPU＋CUDA 已删除重复依赖计划／frontier；共享实际 Queue
  的逻辑 lane 共用 producer group，最终前缀按真实接纳顺序选择，pending 不挡住独立工作。

最新设计收敛见[实际调用链约束](../architecture/compute-design.md#根据实际调用链收敛)：进度只驱动原 Cursor，
原提交寿命管理负责唯一槽终态，租约附件只管真实资源。先复用现有 Scheduler 任务，不在 Graph 增加 Fiber
重置协议；每轮 task record／stack pool 成本单列，严格无分配异步装配仍待完成。独立 Completion 移交凭据
保留原 observer root 清理，避免公开 Invocation 提前析构后丢失移交入口或恢复引用环。
该原语的 Windows 小闭包 41/41 通过；尚未接入完整 Graph 异步提交，不代签 GPU／混合旅程。

此前就绪前沿批次 Windows 72/72、指定 Air 27/27与实际 Apple finite 消费者通过；真实 CUDA 受控旅程
确认 CPU 被 gate 持住时 GPU 仍可录入并完成。相关数学、双槽旧结果和取消／退休通过，没有吞吐结论。
当前默认 ggml CUDA 缺匹配 native 缓存，未使用旧库或参考库代签运行。完整 Qwen 与独立 oracle 约 2%
的数值差异仍未接受，公平性能对照未完成。各批源码、原始结果与验证边界见
[本轮证据](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)。

接下来先把稳定 Admission、共同退休和异步移交接到原槽，再迁跨 Runtime、custom lowering、分页／pending
及其余专用消费者，删除旧混合 Plan／Invocation／Results／driver。默认 Context 与 batch／搬运的装配耦合、
共同冷编译文件过大仍需收敛；不添加转发层或兼容 alias。原功能审查未补齐的范围继续承接，不能以等价迁移
代替功能完成；此前约 75% 仅是粗略估计，不作为当前完成比例。

## 已确认范围

- 用户决定 G04/G05 先视为解决；公平实测与边界见
  [同 FP8 输入报告](../evidence/performance/g04-g05-bf16-partials-2026-10-17/same-fp8/README.md)。
- 用户澄清“多机器”指多系统上的**单机器推理**，不是多台机器协同推理。
- 底座应在受支持系统上覆盖 CPU、CPU＋一张 GPU、单 GPU 三种模式；硬件后端按实际系统支持。
- 除 MTP、多模态外，底座的稳定性和功能完整性仍是核心要求。不能仅用 Qwen3.5-2B
  单请求成功或若干算子片段推导三种模式均完整。
- Windows/Linux/macOS 平台能力、构建后端集合、CPU/GPU/混合执行模式和静态/动态交付应分开表达，
  合法组合由依赖图组装；混合执行所需桥接模块复用相应 CPU/GPU 后端。
- 普通用户无需决定算子分配到哪个 Provider 或启用哪些第三方库。后端选择带出完整实现依赖，
  运行时按请求与设备能力绑定实现；精度、设备放置和资源预算仍由引擎控制。
- 独立 Qwen3.5-2B CUDA 架构测试消费者已执行完整 prefill→续算→decode；数值接受、稳态性能对照与
  其余模型/系统的旅程仍未完成。该消费者不作为基础库交付的正式推理引擎。
- 模型格式、tokenizer、生成/接受策略与请求政策留在独立引擎；可复用计算、存储、
  状态、执行、搬运和图能力在 Compute/Graph 及相应基础模块解决。
- 后续融合和量化接线以既定 8 个文本模型、22 个官方/GGUF 制品配置为范围，
  使用实际 dtype、格式、形状与数值合同核对普通 Provider 路由；历史覆盖表仅提供模型事实，
  其中的旧通过、拒绝与流程状态不直接代表当前支持。
  2026-10-18 的接线补全、实际检查及剩余边界见[本轮报告](../evidence/correctness/model-route-completion-2026-10-18/README.md)。
  继续按 prefill、缓存接续、decode、多请求和接受前缀核对完整调用链；已扩充 CUDA/Vulkan
  量化 embedding，修复 Graph 非对称 attention 输出绑定，并补接四后端的部分高维原生批次。
  可组合的数学、原生分页承载和整模型执行分别记录，不能用当前白名单缩小功能需求。
  用户随后启动[非多模态底座全量审查](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)：
  在以上模型范围内持续review融合、量化接线及Compute/Graph完整推理行为，包括资源调度、
  重复分配/转换/搬运、状态与失败寿命；先查证再修复，不将局部修复视为全量完成。

## 讨论起点

并行准备最小开发入口与真实文本引擎，用实际引擎旅程核对三种执行模式的底座能力。
重点检查驻留与增量状态、布局与 dtype 承载、动态形状与重放、异步搬运与 CPU 预算、
取消/失败/关闭、可观测性、安装包最小消费者，以及正常规模下的性能与显存。
后续实施顺序和具体改动继续按用户讨论推进，不将本页扩展为新的治理流程。

后续接口检查线索：锁定 ggml 的 CUDA GDN/causal conv 原实现要求 F32；这不是已证实的
BF16/FP8 接入遗漏。本轮已接通锁定 ggml 的多 token recurrent snapshot；
默认仍只输出最终状态，MTP 验证块显式请求快照，并按接受前缀恢复。

首个完整消费者重点确认：prepare/repack 是否留在冷路径；KV 有效长度变化是否导致重编译或多余绑定；
GDN、conv、attention 之间是否出现实体转置、dtype 转换或 host 同步；常量与状态能否按真实寿命复用。
`TensorDesc::transposed()` 仅改变描述，不搬运 payload。静态合同无误不代表实际转换次数或热路径成本合理，
不提前规定新的统一布局或合并各原生 runtime。

## 首个 Qwen3.5-2B 消费者的复用材料

模型输入身份见[本地输入清单](../implementation/tasks/compute/qwen35-2b-local-input.json)，
独立公式与中间结果生成见[文本参考](../../tests/compute_models/qwen35_reference.py)，
原运行条件见[参考预检数据](../evidence/correctness/qwen35-cli-preflight/README.md)。
这些材料不代表 Hyle 已整模型执行；加载、tokenizer、chat template、生成循环属于独立引擎。

接线时保留模型特有的数值边界，而不是仅匹配算子名字：

- 普通 RMS 的 scale 为模型规定的 `1+weight`；GDN gated RMS 是另一公式。
- linear Q/K 的 L2 使用 `sum(x*x)+eps`，不是 mean RMS；不要重复施加 GDN 已包含的 `1/sqrt(Dk)`。
- full-attention 的 Q/gate 按 head 拆分；partial RoPE 旋转 64 维并使用实际绝对位置。
- conv history 和 F32 recurrent state 逐层、逐步真实反馈；KV active 长度与 capacity 分开，新请求重置状态。
- 首次 prefill、多 token cached continuation 和单 token decode 分别核对。旧参考依赖的 cached 分支
  曾重置初始 state，不能把该行为复制为数学标准，也不能每轮把候选 state 换成 oracle state 来掩盖累计误差。

完整 CUDA 首版仍按第六项约定关闭 MTP/视觉，并从同源权重、相同精度和完整生命周期与 llama.cpp 比较。
