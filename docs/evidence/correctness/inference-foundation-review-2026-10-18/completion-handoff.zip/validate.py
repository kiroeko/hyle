"""Focused Completion validation with current sources and existing base libraries."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
RECIPES = ROOT / ".scratch/architecture-refactor-2026-10-18/submission-frontier/windows/commands.json"
sys.path.insert(0, str(ROOT / "scripts"))
from hyle_environment import windows_compiler_environment

rows = json.loads(RECIPES.read_text(encoding="utf-8-sig"))
def recipe(tag):
    return next(row["command"] for row in reversed(rows) if row["tag"] == tag and row["exit"] == 0)

core = recipe("resources-compile")
env = windows_compiler_environment({"CMAKE_CXX_COMPILER": core[0], "CMAKE_C_COMPILER": core[0]})
env["VSLANG"] = "1033"

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

def run(tag, args, sources=()):
    history = OUT / "validation-commands.json"
    records = json.loads(history.read_text(encoding="utf-8")) if history.exists() else []
    stem = f"{len(records)+1:02d}-{tag}"
    before = [identity(ROOT / source) for source in sources]
    start = time.monotonic()
    try:
        result = subprocess.run(list(map(str, args)), cwd=ROOT, env=env,
                                capture_output=True, timeout=55,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        code, stdout, stderr = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr = 124, error.stdout or b"", error.stderr or b""
    (OUT / (stem + ".stdout.log")).write_bytes(stdout)
    (OUT / (stem + ".stderr.log")).write_bytes(stderr)
    after = [identity(ROOT / source) for source in sources]
    records.append({"tag": tag, "command": list(map(str, args)), "exit": code,
                    "seconds": time.monotonic()-start, "before": before,
                    "after": after, "unchanged": before == after,
                    "stdout": stem + ".stdout.log", "stderr": stem + ".stderr.log"})
    save("validation-commands.json", records)
    print(tag, code, flush=True)
    if code:
        print(stdout.decode(errors="replace"))
        print(stderr.decode(errors="replace"))
    if before != after:
        raise SystemExit("source changed during validation")
    if code:
        raise SystemExit(code)

def compile_sources(selected=None):
    flags = [arg for arg in core[1:] if not arg.lower().startswith(("/fo", "/tp"))
             and not arg.lower().endswith((".cc", ".cpp"))]
    for source in ("src/compute/completion.cc", "src/compute/resource_budget.cc",
                   "src/compute/retained_completion.cc", "tests/compute/completion_test.cc"):
        name = Path(source).stem
        if selected is not None and name != selected:
            continue
        run(name + "-compile", [core[0], *flags, ROOT / source, "/Fo" + str(OUT / (name + ".obj"))],
            [source, "include/hyle/compute/detail/retained_completion.h",
             "include/hyle/compute/detail/completion_access.h", "src/compute/completion_internal.h"])

def link():
    base = recipe("controls-link")
    keep = {"hyle_compute.lib", "hyle_compute_ops.lib", "hyle_container.lib", "hyle_mem.lib",
            "mimalloc_static.lib", "hyle_platform.lib", "hyle_error.lib", "hyle_platform_thread.lib",
            "hyle_time.lib", "hyle_simd.lib", "gtest_main.lib", "gtest.lib"}
    libs = [arg for arg in base[1:] if Path(arg).name.casefold() in keep
            or (arg.lower().endswith(".lib") and not Path(arg).is_absolute())]
    objects = [OUT / (stem + ".obj") for stem in
               ("completion_test", "completion", "resource_budget", "retained_completion")]
    save("validation-link-identities.json", [identity(path) for path in (*objects, *(Path(p) for p in libs if Path(p).is_absolute()))])
    run("completion-link", [base[0], "/nologo", "/MACHINE:X64", "/SUBSYSTEM:CONSOLE",
        "/INCREMENTAL:NO", "/NODEFAULTLIB:LIBCMT", *objects, *libs,
        "/OUT:" + str(OUT / "completion.exe"), "/MAP:" + str(OUT / "completion.map")])

def test():
    run("completion-run", [OUT / "completion.exe", "--gtest_color=no",
        "--gtest_output=json:" + str(OUT / "validation-results.json")])
    result = json.loads((OUT / "validation-results.json").read_text(encoding="utf-8"))
    assert not result["failures"] and not result["errors"]
    save("validation-summary.json", {"tests": result["tests"], "failures": result["failures"],
        "errors": result["errors"], "source": "four current Compute/test translation units",
        "scope": "host Completion and existing ownership regressions; no Graph async integration or native GPU claim",
        "vendor_rebuilt": False})
    print(result["tests"], "tests passed", flush=True)

if __name__ == "__main__":
    {"compile": compile_sources,
     "retained": lambda: compile_sources("retained_completion"),
     "link": link, "run": test}[sys.argv[1]]()
