from pathlib import Path
import importlib.util
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('local_runner',OUT/'run.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
source=(r.ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc').read_text()
marker='    bind_views();\n    for (const auto &constant : constants)'
probe='''    std::size_t bfloat_casts = 0;
    for (int i = 0; i < nodes; ++i) {
      const auto *value = ggml_graph_node(graph, i);
      if (value->op == GGML_OP_CPY && value->src[0] &&
          value->src[0]->type == GGML_TYPE_BF16 && value->type == GGML_TYPE_F32)
        ++bfloat_casts;
    }
    std::fprintf(stderr, "NATIVE_CENSUS recipe_nodes=%zu immutable_bindings=%zu BF16_to_F32_copies=%zu\\n",
        recipe.nodes.size(), recipe.constants.size(), bfloat_casts);
'''
assert source.count(marker)==1
(OUT/'provider-census.cc').write_text('#include <cstdio>\n'+source.replace(marker,probe+marker))
obj=r.compile(OUT/'provider-census.cc','provider-census')
exe=OUT/'census.exe'
objects=[obj,OUT/'region.obj',OUT/'tests.obj',r.ROOT/'.scratch/mtp-completion/operation.obj',
    r.ROOT/'.scratch/inference-feature-completion-2026-10-18/quantization/cuda-embedding18/tensor.obj',
    r.c.OLD/'ggml-cuda.strict.obj']
r.run('census-link',[r.c.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
    '/OUT:'+str(exe),'/MAP:'+str(OUT/'census.map'),*objects,*r.c.libs,
    r.c.BASE/'lib/gtest_main.lib',r.c.BASE/'lib/gtest.lib',*r.c.system])
r.run('census',[exe,'--gtest_filter=GgmlCudaGraph.BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable','--gtest_color=no'])
