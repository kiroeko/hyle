from pathlib import Path
import importlib.util, json, subprocess, time, sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cuda_cache',ROOT/'.scratch/mtp-completion/run.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
flags=c.flags+['/I'+str(ROOT)]
records=json.loads((OUT/'commands.json').read_text()) if (OUT/'commands.json').exists() else []
def run(tag,command):
    command=list(map(str,command));t=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,env=c.env,capture_output=True,timeout=180)
    (OUT/(tag+'.stdout.txt')).write_bytes(p.stdout);(OUT/(tag+'.stderr.txt')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-t))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(tag,p.returncode,round(records[-1]['seconds'],2),flush=True)
    if p.returncode:
        print(p.stdout.decode(errors='replace')[-7000:]);print(p.stderr.decode(errors='replace')[-2500:]);raise SystemExit(p.returncode)
def compile(source,stem):
    obj=OUT/(stem+'.obj');run(stem+'-compile',[c.cl,*flags,source,'/Fo'+str(obj)]);return obj
if __name__=='__main__':
    objects=[]
    for file,stem in [('src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','provider'),
                      ('src/graph_provider_ggml_cuda/ggml_cuda_region.cc','region'),
                      ('tests/graph_provider_ggml_cuda/region_test.cc','tests')]:
        objects.append(OUT/(stem+'.obj') if '--reuse-products' in sys.argv and stem!='tests' else compile(ROOT/file,stem))
    objects += [ROOT/'.scratch/mtp-completion/operation.obj',
        ROOT/'.scratch/inference-feature-completion-2026-10-18/quantization/cuda-embedding18/tensor.obj',
        c.OLD/'ggml-cuda.strict.obj']
    exe=OUT/'tests.exe'
    run('tests-link',[c.link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(exe),'/MAP:'+str(OUT/'tests.map'),*objects,*c.libs,
        c.BASE/'lib/gtest_main.lib',c.BASE/'lib/gtest.lib',*c.system])
    run('tests',[exe,'--gtest_filter=GgmlCudaGraph.BfloatExpertConstantsPackOnceAndDynamicWeightsRemainRebindable',
        '--gtest_color=no'])
