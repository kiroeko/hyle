spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_16bit_storage, SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<8 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.func @fp4_roundtrip_32_dispatch_2_elementwise_broadcast_D_i16() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst64_i32 = spirv.Constant 64 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst32768_i32 = spirv.Constant 32768 : i32
    %cst4194304_i32 = spirv.Constant 4194304 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst5_i32 = spirv.Constant 5 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst127_i32 = spirv.Constant 127 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst32767_i32 = spirv.Constant 32767 : i32
    %cst32_i32 = spirv.Constant 32 : i32
    %cst_f32 = spirv.Constant 7.812500e-03 : f32
    %cst_f32_0 = spirv.Constant 3.906250e-03 : f32
    %cst_f32_1 = spirv.Constant 6.000000e+00 : f32
    %cst_f32_2 = spirv.Constant 5.000000e-01 : f32
    %cst_f32_3 = spirv.Constant 1.000000e+00 : f32
    %cst_f32_4 = spirv.Constant 1.500000e+00 : f32
    %cst_f32_5 = spirv.Constant 2.000000e+00 : f32
    %cst_f32_6 = spirv.Constant 3.000000e+00 : f32
    %cst_f32_7 = spirv.Constant 4.000000e+00 : f32
    %cst = spirv.Constant dense<[0.000000e+00, 5.000000e-01, 1.000000e+00, 1.500000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 6.000000e+00]> : tensor<8xf32> : !spirv.array<8 x f32>
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<8 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<8 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<8 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<8 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<8 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %8 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %9 = spirv.CompositeExtract %8[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %14 = spirv.IMul %11, %cst64_i32 : i32
    %15 = spirv.IMul %13, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%14 : i32)
    ^bb1(%16: i32):  // 2 preds: ^bb0, ^bb2
      %17 = spirv.SLessThan %16, %1 : i32
      spirv.BranchConditional %17, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %18 = spirv.ISub %1, %16 : i32
      %19 = spirv.GL.SMin %18, %cst64_i32 : i32
      %20 = spirv.SGreaterThan %19, %9 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %20, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %22 = spirv.IAdd %16, %9 : i32
        %23 = spirv.GL.SAbs %22 : i32
        %24 = spirv.GL.SAbs %5 : i32
        %25 = spirv.UMod %23, %24 : i32
        %26 = spirv.IEqual %22, %23 : i32
        %27 = spirv.SNegate %25 : i32
        %28 = spirv.Select %26, %25, %27 : i1, i32
        %29 = spirv.SDiv %22, %5 : i32
        %30 = spirv.UDiv %28, %cst32_i32 : i32
        %31 = spirv.IMul %29, %5 : i32
        %32 = spirv.IAdd %31, %28 : i32
        %33 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %32] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        %34 = spirv.Load "StorageBuffer" %33 : i16
        %35 = spirv.UConvert %34 : i16 to i32
        %36 = spirv.BitwiseAnd %35, %cst32767_i32 : i32
        %37 = spirv.ShiftLeftLogical %36, %cst16_i32 : i32, i32
        %38 = spirv.Bitcast %37 : i32 to f32
        %39 = spirv.IMul %29, %7 : i32
        %40 = spirv.IAdd %39, %30 : i32
        %41 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %40] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %42 = spirv.Load "StorageBuffer" %41 : i32
        %43 = spirv.ShiftLeftLogical %42, %cst23_i32 : i32, i32
        %44 = spirv.Bitcast %43 : i32 to f32
        %45 = spirv.FDiv %38, %44 : f32
        %46 = spirv.ShiftRightLogical %36, %cst7_i32 : i32, i32
        %47 = spirv.BitwiseAnd %35, %cst127_i32 : i32
        %48 = spirv.IEqual %46, %cst0_i32 : i32
        %49 = spirv.Select %48, %cst0_i32, %cst128_i32 : i1, i32
        %50 = spirv.BitwiseOr %47, %49 : i32
        %51 = spirv.GL.UMax %46, %cst1_i32 : i32
        %52 = spirv.GL.UMin %51, %cst4_i32 : i32
        %53 = spirv.ISub %52, %cst1_i32 : i32
        %54 = spirv.ShiftLeftLogical %50, %53 : i32, i32
        %55 = spirv.ConvertUToF %54 : i32 to f32
        %56 = spirv.IEqual %42, %cst1_i32 : i32
        %57 = spirv.Select %56, %cst_f32, %cst_f32_0 : i1, f32
        %58 = spirv.FMul %55, %57 : f32
        %59 = spirv.ULessThanEqual %42, %cst2_i32 : i32
        %60 = spirv.Select %59, %58, %45 : i1, f32
        %61 = spirv.GL.FMin %60, %cst_f32_1 : f32
        %62 = spirv.IsNan %60 : f32
        %63 = spirv.IsNan %cst_f32_1 : f32
        %64 = spirv.Select %62, %60, %61 : i1, f32
        %65 = spirv.Select %63, %cst_f32_1, %64 : i1, f32
        %66 = spirv.GL.FAbs %65 : f32
        %67 = spirv.FSub %65, %cst_f32_2 : f32
        %68 = spirv.GL.FAbs %67 : f32
        %69 = spirv.FOrdLessThan %68, %66 : f32
        %70 = spirv.Select %69, %cst1_i32, %cst0_i32 : i1, i32
        %71 = spirv.Select %69, %68, %66 : i1, f32
        %72 = spirv.FSub %65, %cst_f32_3 : f32
        %73 = spirv.GL.FAbs %72 : f32
        %74 = spirv.FOrdLessThan %73, %71 : f32
        %75 = spirv.FOrdEqual %73, %71 : f32
        %76 = spirv.BitwiseAnd %70, %cst1_i32 : i32
        %77 = spirv.INotEqual %76, %cst0_i32 : i32
        %78 = spirv.LogicalAnd %75, %77 : i1
        %79 = spirv.LogicalOr %74, %78 : i1
        %80 = spirv.Select %79, %cst2_i32, %70 : i1, i32
        %81 = spirv.Select %79, %73, %71 : i1, f32
        %82 = spirv.FSub %65, %cst_f32_4 : f32
        %83 = spirv.GL.FAbs %82 : f32
        %84 = spirv.FOrdLessThan %83, %81 : f32
        %85 = spirv.Select %84, %cst3_i32, %80 : i1, i32
        %86 = spirv.Select %84, %83, %81 : i1, f32
        %87 = spirv.FSub %65, %cst_f32_5 : f32
        %88 = spirv.GL.FAbs %87 : f32
        %89 = spirv.FOrdLessThan %88, %86 : f32
        %90 = spirv.FOrdEqual %88, %86 : f32
        %91 = spirv.BitwiseAnd %85, %cst1_i32 : i32
        %92 = spirv.INotEqual %91, %cst0_i32 : i32
        %93 = spirv.LogicalAnd %90, %92 : i1
        %94 = spirv.LogicalOr %89, %93 : i1
        %95 = spirv.Select %94, %cst4_i32, %85 : i1, i32
        %96 = spirv.Select %94, %88, %86 : i1, f32
        %97 = spirv.FSub %65, %cst_f32_6 : f32
        %98 = spirv.GL.FAbs %97 : f32
        %99 = spirv.FOrdLessThan %98, %96 : f32
        %100 = spirv.Select %99, %cst5_i32, %95 : i1, i32
        %101 = spirv.Select %99, %98, %96 : i1, f32
        %102 = spirv.FSub %65, %cst_f32_7 : f32
        %103 = spirv.GL.FAbs %102 : f32
        %104 = spirv.FOrdLessThan %103, %101 : f32
        %105 = spirv.FOrdEqual %103, %101 : f32
        %106 = spirv.BitwiseAnd %100, %cst1_i32 : i32
        %107 = spirv.INotEqual %106, %cst0_i32 : i32
        %108 = spirv.LogicalAnd %105, %107 : i1
        %109 = spirv.LogicalOr %104, %108 : i1
        %110 = spirv.Select %109, %cst6_i32, %100 : i1, i32
        %111 = spirv.Select %109, %103, %101 : i1, f32
        %112 = spirv.FSub %65, %cst_f32_1 : f32
        %113 = spirv.GL.FAbs %112 : f32
        %114 = spirv.FOrdLessThan %113, %111 : f32
        %115 = spirv.Select %114, %cst7_i32, %110 : i1, i32
        %116 = spirv.Variable : !spirv.ptr<!spirv.array<8 x f32>, Function>
        spirv.Store "Function" %116, %cst : !spirv.array<8 x f32>
        %117 = spirv.AccessChain %116[%115] : !spirv.ptr<!spirv.array<8 x f32>, Function>, i32 -> !spirv.ptr<f32, Function>
        %118 = spirv.Load "Function" %117 : f32
        %119 = spirv.FMul %118, %44 : f32
        %120 = spirv.Bitcast %119 : f32 to i32
        %121 = spirv.IEqual %115, %cst1_i32 : i32
        %122 = spirv.LogicalAnd %56, %121 : i1
        %123 = spirv.Select %122, %cst4194304_i32, %120 : i1, i32
        %124 = spirv.IEqual %115, %cst0_i32 : i32
        %125 = spirv.Select %124, %cst0_i32, %123 : i1, i32
        %126 = spirv.BitwiseAnd %35, %cst32768_i32 : i32
        %127 = spirv.ShiftLeftLogical %126, %cst16_i32 : i32, i32
        %128 = spirv.BitwiseOr %125, %127 : i32
        %129 = spirv.ShiftRightLogical %128, %cst16_i32 : i32, i32
        %130 = spirv.SConvert %129 : i32 to i16
        %131 = spirv.IAdd %22, %cst32_i32 : i32
        %132 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %131] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        spirv.Store "StorageBuffer" %132, %130 : i16
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %21 = spirv.IAdd %16, %15 : i32
      spirv.Branch ^bb1(%21 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @fp4_roundtrip_32_dispatch_2_elementwise_broadcast_D_i16, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @fp4_roundtrip_32_dispatch_2_elementwise_broadcast_D_i16 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @fp4_roundtrip_32_dispatch_2_elementwise_broadcast_D_i16 "SignedZeroInfNanPreserve", 32
}