spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst16_i32 = spirv.Constant 16 : i32
    %cst14_i32 = spirv.Constant 14 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst12_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst14_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst16_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<18 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %18 = spirv.SLessThan %1, %cst0_i32 : i32
    %19 = spirv.ISub %cst-1_i32, %1 : i32
    %20 = spirv.Select %18, %19, %1 : i1, i32
    %21 = spirv.SDiv %20, %cst4_i32 : i32
    %22 = spirv.ISub %cst-1_i32, %21 : i32
    %23 = spirv.Select %18, %22, %21 : i1, i32
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %24 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %25 = spirv.CompositeExtract %24[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %26 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %27 = spirv.CompositeExtract %26[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %28 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %29 = spirv.CompositeExtract %28[0 : i32] : vector<3xi32>
    %30 = spirv.IMul %27, %cst64_i32 : i32
    %31 = spirv.IMul %29, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%30 : i32)
    ^bb1(%32: i32):  // 2 preds: ^bb0, ^bb2
      %33 = spirv.SLessThan %32, %3 : i32
      spirv.BranchConditional %33, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %34 = spirv.ISub %3, %32 : i32
      %35 = spirv.GL.SMin %34, %cst64_i32 : i32
      %36 = spirv.SGreaterThan %35, %25 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %36, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %38 = spirv.IAdd %32, %25 : i32
        %39 = spirv.GL.SAbs %38 : i32
        %40 = spirv.GL.SAbs %17 : i32
        %41 = spirv.UMod %39, %40 : i32
        %42 = spirv.IEqual %38, %39 : i32
        %43 = spirv.SNegate %41 : i32
        %44 = spirv.Select %42, %41, %43 : i1, i32
        %45 = spirv.SDiv %38, %17 : i32
        %46 = spirv.UDiv %44, %cst128_i32 : i32
        %47 = spirv.IMul %45, %9 : i32
        %48 = spirv.IAdd %47, %5 : i32
        %49 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %48] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %50 = spirv.Load "StorageBuffer" %49 : f32
        %51 = spirv.IMul %46, %15 : i32
        %52 = spirv.IAdd %51, %5 : i32
        %53 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %52] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %54 = spirv.Load "StorageBuffer" %53 : f32
        %55 = spirv.IMul %45, %17 : i32
        %56 = spirv.IAdd %55, %44 : i32
        %57 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %56] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %58 = spirv.Load "StorageBuffer" %57 : f32
        %59 = spirv.IAdd %23, %55 : i32
        %60 = spirv.IAdd %59, %44 : i32
        %61 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %60] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %62 = spirv.Load "StorageBuffer" %61 : f32
        %63 = spirv.FMul %58, %50 : f32
        %64 = spirv.FMul %63, %54 : f32
        %65 = spirv.FAdd %62, %64 : f32
        %66 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %38] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %66, %65 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %37 = spirv.IAdd %32, %31 : i32
      spirv.Branch ^bb1(%37 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}