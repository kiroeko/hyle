spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<12 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst24_i32 = spirv.Constant 24 : i32
    %cst255_i32 = spirv.Constant 255 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst_f32 = spirv.Constant 0.001953125 : f32
    %cst31_i32 = spirv.Constant 31 : i32
    %cst7_i32 = spirv.Constant 7 : i32
    %cst3_i32 = spirv.Constant 3 : i32
    %cst23_i32 = spirv.Constant 23 : i32
    %cst2143289344_i32 = spirv.Constant 2143289344 : i32
    %cst15_i32 = spirv.Constant 15 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst120_i32 = spirv.Constant 120 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst_f32_0 = spirv.Constant 0x7FC00000 : f32
    %cst127_i32 = spirv.Constant 127 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<12 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<12 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<12 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<12 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<12 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<12 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<12 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %12 = spirv.SLessThan %1, %cst0_i32 : i32
    %13 = spirv.ISub %cst-1_i32, %1 : i32
    %14 = spirv.Select %12, %13, %1 : i1, i32
    %15 = spirv.SDiv %14, %cst4_i32 : i32
    %16 = spirv.ISub %cst-1_i32, %15 : i32
    %17 = spirv.Select %12, %16, %15 : i1, i32
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %18 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %19 = spirv.CompositeExtract %18[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %20 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %21 = spirv.CompositeExtract %20[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %22 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %23 = spirv.CompositeExtract %22[0 : i32] : vector<3xi32>
    %24 = spirv.IMul %21, %cst64_i32 : i32
    %25 = spirv.IMul %23, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%24 : i32)
    ^bb1(%26: i32):  // 2 preds: ^bb0, ^bb2
      %27 = spirv.SLessThan %26, %3 : i32
      spirv.BranchConditional %27, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %28 = spirv.ISub %3, %26 : i32
      %29 = spirv.GL.SMin %28, %cst64_i32 : i32
      %30 = spirv.SGreaterThan %29, %19 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %30, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %32 = spirv.IAdd %26, %19 : i32
        %33 = spirv.GL.SAbs %32 : i32
        %34 = spirv.GL.SAbs %cst128_i32 : i32
        %35 = spirv.UMod %33, %34 : i32
        %36 = spirv.IEqual %32, %33 : i32
        %37 = spirv.SNegate %35 : i32
        %38 = spirv.Select %36, %35, %37 : i1, i32
        %39 = spirv.SDiv %32, %cst128_i32 : i32
        %40 = spirv.IAdd %5, %38 : i32
        %41 = spirv.IMul %39, %11 : i32
        %42 = spirv.IAdd %41, %40 : i32
        %43 = spirv.SDiv %42, %cst4_i32 : i32
        %44 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %43] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %45 = spirv.Load "StorageBuffer" %44 : i32
        %46 = spirv.UMod %42, %cst4_i32 : i32
        %47 = spirv.IMul %46, %cst8_i32 : i32
        %48 = spirv.ShiftRightArithmetic %45, %47 : i32, i32
        %49 = spirv.BitwiseAnd %48, %cst255_i32 : i32
        %50 = spirv.ShiftLeftLogical %49, %cst24_i32 : i32, i32
        %51 = spirv.ShiftRightArithmetic %50, %cst24_i32 : i32, i32
        %52 = spirv.BitwiseAnd %51, %cst255_i32 : i32
        %53 = spirv.ShiftRightLogical %52, %cst7_i32 : i32, i32
        %54 = spirv.ShiftRightLogical %52, %cst3_i32 : i32, i32
        %55 = spirv.BitwiseAnd %54, %cst15_i32 : i32
        %56 = spirv.BitwiseAnd %52, %cst7_i32 : i32
        %57 = spirv.ShiftLeftLogical %53, %cst31_i32 : i32, i32
        %58 = spirv.IEqual %56, %cst0_i32 : i32
        %59 = spirv.INotEqual %56, %cst0_i32 : i32
        %60 = spirv.IEqual %52, %cst127_i32 : i32
        %61 = spirv.IEqual %55, %cst0_i32 : i32
        %62 = spirv.LogicalAnd %61, %58 : i1
        %63 = spirv.LogicalAnd %61, %59 : i1
        %64 = spirv.IAdd %55, %cst120_i32 : i32
        %65 = spirv.ShiftLeftLogical %56, %cst20_i32 : i32, i32
        %66 = spirv.ShiftLeftLogical %64, %cst23_i32 : i32, i32
        %67 = spirv.BitwiseOr %66, %65 : i32
        %68 = spirv.BitwiseOr %57, %67 : i32
        %69 = spirv.ConvertUToF %56 : i32 to f32
        %70 = spirv.FMul %69, %cst_f32 : f32
        %71 = spirv.Bitcast %70 : f32 to i32
        %72 = spirv.BitwiseOr %57, %71 : i32
        %73 = spirv.Select %63, %72, %68 : i1, i32
        %74 = spirv.Select %62, %57, %73 : i1, i32
        %75 = spirv.Select %60, %cst2143289344_i32, %74 : i1, i32
        %76 = spirv.Bitcast %75 : i32 to f32
        %77 = spirv.BitwiseAnd %52, %cst127_i32 : i32
        %78 = spirv.IEqual %77, %cst127_i32 : i32
        %79 = spirv.Select %78, %cst_f32_0, %76 : i1, f32
        %80 = spirv.IAdd %32, %17 : i32
        %81 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %80] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %81, %79 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %31 = spirv.IAdd %26, %25 : i32
      spirv.Branch ^bb1(%31 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}