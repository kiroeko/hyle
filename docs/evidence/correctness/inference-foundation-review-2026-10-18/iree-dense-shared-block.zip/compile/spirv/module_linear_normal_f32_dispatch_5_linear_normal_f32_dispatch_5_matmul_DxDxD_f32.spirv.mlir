spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @linear_normal_f32_dispatch_5_matmul_DxDxD_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst8192_i32 = spirv.Constant 8192 : i32
    %cst-64_i32 = spirv.Constant -64 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst_f32 = spirv.Constant 0.000000e+00 : f32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<4 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %4 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %5 = spirv.CompositeExtract %4[0 : i32] : vector<3xi32>
    %6 = spirv.SLessThanEqual %3, %cst0_i32 : i32
    %7 = spirv.ISub %cst0_i32, %3 : i32
    %8 = spirv.ISub %3, %cst1_i32 : i32
    %9 = spirv.Select %6, %7, %8 : i1, i32
    %10 = spirv.SDiv %9, %cst64_i32 : i32
    %11 = spirv.ISub %cst0_i32, %10 : i32
    %12 = spirv.IAdd %10, %cst1_i32 : i32
    %13 = spirv.Select %6, %11, %12 : i1, i32
    %14 = spirv.IMul %1, %13 : i32
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %15 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %16 = spirv.CompositeExtract %15[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %17 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %18 = spirv.CompositeExtract %17[0 : i32] : vector<3xi32>
    spirv.mlir.loop {
      spirv.Branch ^bb1(%16 : i32)
    ^bb1(%19: i32):  // 2 preds: ^bb0, ^bb2
      %20 = spirv.SLessThan %19, %14 : i32
      spirv.BranchConditional %20, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %21 = spirv.SDiv %19, %13 : i32
      %22 = spirv.IMul %21, %13 : i32
      %23 = spirv.INotEqual %19, %22 : i32
      %24 = spirv.SLessThan %19, %cst0_i32 : i32
      %25 = spirv.SLessThan %13, %cst0_i32 : i32
      %26 = spirv.LogicalNotEqual %24, %25 : i1
      %27 = spirv.LogicalAnd %23, %26 : i1
      %28 = spirv.IAdd %21, %cst-1_i32 : i32
      %29 = spirv.Select %27, %28, %21 : i1, i32
      %30 = spirv.GL.SAbs %19 : i32
      %31 = spirv.GL.SAbs %13 : i32
      %32 = spirv.UMod %30, %31 : i32
      %33 = spirv.IEqual %19, %30 : i32
      %34 = spirv.SNegate %32 : i32
      %35 = spirv.Select %33, %32, %34 : i1, i32
      %36 = spirv.SLessThan %35, %cst0_i32 : i32
      %37 = spirv.IAdd %35, %13 : i32
      %38 = spirv.Select %36, %37, %35 : i1, i32
      %39 = spirv.IMul %38, %cst-64_i32 : i32
      %40 = spirv.IAdd %39, %3 : i32
      %41 = spirv.GL.SMin %40, %cst64_i32 : i32
      %42 = spirv.SGreaterThan %41, %5 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %42, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %44 = spirv.IMul %38, %cst64_i32 : i32
        %45 = spirv.IAdd %44, %5 : i32
        %46 = spirv.IMul %29, %3 : i32
        %47 = spirv.IAdd %45, %46 : i32
        %48 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %47] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %48, %cst_f32 : f32
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32 : i32)
        ^bb1(%49: i32):  // 2 preds: ^bb0, ^bb2
          %50 = spirv.SLessThan %49, %cst128_i32 : i32
          spirv.BranchConditional %50, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %51 = spirv.IMul %29, %cst128_i32 : i32
          %52 = spirv.IAdd %51, %49 : i32
          %53 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %52] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %54 = spirv.Load "StorageBuffer" %53 : f32
          %55 = spirv.IMul %38, %cst8192_i32 : i32
          %56 = spirv.IAdd %55, %49 : i32
          %57 = spirv.IMul %5, %cst128_i32 : i32
          %58 = spirv.IAdd %56, %57 : i32
          %59 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %58] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %60 = spirv.Load "StorageBuffer" %59 : f32
          %61 = spirv.Load "StorageBuffer" %48 : f32
          %62 = spirv.FMul %54, %60 : f32
          %63 = spirv.FAdd %61, %62 : f32
          spirv.Store "StorageBuffer" %48, %63 : f32
          %64 = spirv.IAdd %49, %cst1_i32 : i32
          spirv.Branch ^bb1(%64 : i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %43 = spirv.IAdd %19, %18 : i32
      spirv.Branch ^bb1(%43 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @linear_normal_f32_dispatch_5_matmul_DxDxD_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @linear_normal_f32_dispatch_5_matmul_DxDxD_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @linear_normal_f32_dispatch_5_matmul_DxDxD_f32 "SignedZeroInfNanPreserve", 32
}