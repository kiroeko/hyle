spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @encoded_block128_dispatch_3_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst18_i32 = spirv.Constant 18 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst14_i32 = spirv.Constant 14 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst12_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst14_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst16_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %18 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst18_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<20 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %19 = spirv.Load "PushConstant" %18 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %20 = spirv.SLessThan %1, %cst0_i32 : i32
    %21 = spirv.ISub %cst-1_i32, %1 : i32
    %22 = spirv.Select %20, %21, %1 : i1, i32
    %23 = spirv.SDiv %22, %cst4_i32 : i32
    %24 = spirv.ISub %cst-1_i32, %23 : i32
    %25 = spirv.Select %20, %24, %23 : i1, i32
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %26 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %27 = spirv.CompositeExtract %26[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %28 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %29 = spirv.CompositeExtract %28[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %30 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %31 = spirv.CompositeExtract %30[0 : i32] : vector<3xi32>
    %32 = spirv.IMul %29, %cst64_i32 : i32
    %33 = spirv.IMul %31, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%32 : i32)
    ^bb1(%34: i32):  // 2 preds: ^bb0, ^bb2
      %35 = spirv.SLessThan %34, %3 : i32
      spirv.BranchConditional %35, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %36 = spirv.ISub %3, %34 : i32
      %37 = spirv.GL.SMin %36, %cst64_i32 : i32
      %38 = spirv.SGreaterThan %37, %27 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %38, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %40 = spirv.IAdd %34, %27 : i32
        %41 = spirv.GL.SAbs %40 : i32
        %42 = spirv.GL.SAbs %19 : i32
        %43 = spirv.UMod %41, %42 : i32
        %44 = spirv.IEqual %40, %41 : i32
        %45 = spirv.SNegate %43 : i32
        %46 = spirv.Select %44, %43, %45 : i1, i32
        %47 = spirv.SDiv %40, %19 : i32
        %48 = spirv.UDiv %46, %cst128_i32 : i32
        %49 = spirv.IMul %47, %9 : i32
        %50 = spirv.IAdd %49, %5 : i32
        %51 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %50] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %52 = spirv.Load "StorageBuffer" %51 : f32
        %53 = spirv.IMul %48, %15 : i32
        %54 = spirv.IAdd %53, %5 : i32
        %55 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %54] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %56 = spirv.Load "StorageBuffer" %55 : f32
        %57 = spirv.IMul %47, %19 : i32
        %58 = spirv.IAdd %57, %46 : i32
        %59 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %58] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %60 = spirv.Load "StorageBuffer" %59 : f32
        %61 = spirv.IAdd %25, %57 : i32
        %62 = spirv.IAdd %61, %46 : i32
        %63 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %62] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %64 = spirv.Load "StorageBuffer" %63 : f32
        %65 = spirv.FMul %60, %52 : f32
        %66 = spirv.FMul %65, %56 : f32
        %67 = spirv.FAdd %64, %66 : f32
        %68 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %40] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %68, %67 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %39 = spirv.IAdd %34, %33 : i32
      spirv.Branch ^bb1(%39 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @encoded_block128_dispatch_3_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @encoded_block128_dispatch_3_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @encoded_block128_dispatch_3_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}