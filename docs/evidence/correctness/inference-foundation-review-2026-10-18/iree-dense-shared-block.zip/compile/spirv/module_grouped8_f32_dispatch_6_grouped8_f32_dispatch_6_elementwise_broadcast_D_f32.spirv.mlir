spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_4_ bind(0, 4) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @grouped8_f32_dispatch_6_elementwise_broadcast_D_f32() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst22_i32 = spirv.Constant 22 : i32
    %cst20_i32 = spirv.Constant 20 : i32
    %cst18_i32 = spirv.Constant 18 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst14_i32 = spirv.Constant 14 : i32
    %cst12_i32 = spirv.Constant 12 : i32
    %cst10_i32 = spirv.Constant 10 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst-1_i32 = spirv.Constant -1 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %10 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst10_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %11 = spirv.Load "PushConstant" %10 : i32
    %12 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst12_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %13 = spirv.Load "PushConstant" %12 : i32
    %14 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst14_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %15 = spirv.Load "PushConstant" %14 : i32
    %16 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst16_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %17 = spirv.Load "PushConstant" %16 : i32
    %18 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst18_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %19 = spirv.Load "PushConstant" %18 : i32
    %20 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst20_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %21 = spirv.Load "PushConstant" %20 : i32
    %22 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst22_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<24 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %23 = spirv.Load "PushConstant" %22 : i32
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %24 = spirv.SLessThan %1, %cst0_i32 : i32
    %25 = spirv.ISub %cst-1_i32, %1 : i32
    %26 = spirv.Select %24, %25, %1 : i1, i32
    %27 = spirv.SDiv %26, %cst4_i32 : i32
    %28 = spirv.ISub %cst-1_i32, %27 : i32
    %29 = spirv.Select %24, %28, %27 : i1, i32
    %__resource_var_0_4__addr = spirv.mlir.addressof @__resource_var_0_4_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %30 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %31 = spirv.CompositeExtract %30[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %32 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %33 = spirv.CompositeExtract %32[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %34 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %35 = spirv.CompositeExtract %34[0 : i32] : vector<3xi32>
    %36 = spirv.IMul %33, %cst64_i32 : i32
    %37 = spirv.IMul %35, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%36 : i32)
    ^bb1(%38: i32):  // 2 preds: ^bb0, ^bb2
      %39 = spirv.SLessThan %38, %3 : i32
      spirv.BranchConditional %39, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %40 = spirv.ISub %3, %38 : i32
      %41 = spirv.GL.SMin %40, %cst64_i32 : i32
      %42 = spirv.SGreaterThan %41, %31 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %42, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %44 = spirv.IAdd %38, %31 : i32
        %45 = spirv.GL.SAbs %44 : i32
        %46 = spirv.GL.SAbs %5 : i32
        %47 = spirv.UMod %45, %46 : i32
        %48 = spirv.IEqual %44, %45 : i32
        %49 = spirv.SNegate %47 : i32
        %50 = spirv.Select %48, %47, %49 : i1, i32
        %51 = spirv.SDiv %44, %5 : i32
        %52 = spirv.UDiv %51, %7 : i32
        %53 = spirv.UMod %51, %7 : i32
        %54 = spirv.IEqual %9, %cst1_i32 : i32
        %55 = spirv.Select %54, %cst0_i32, %53 : i1, i32
        %56 = spirv.IMul %52, %9 : i32
        %57 = spirv.IAdd %56, %55 : i32
        %58 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %51] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %59 = spirv.Load "StorageBuffer" %58 : i32
        %60 = spirv.UDiv %50, %cst128_i32 : i32
        %61 = spirv.IMul %57, %17 : i32
        %62 = spirv.IAdd %61, %11 : i32
        %63 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %62] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %64 = spirv.Load "StorageBuffer" %63 : f32
        %65 = spirv.IMul %59, %21 : i32
        %66 = spirv.IAdd %60, %65 : i32
        %67 = spirv.IMul %66, %23 : i32
        %68 = spirv.IAdd %11, %67 : i32
        %69 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %68] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %70 = spirv.Load "StorageBuffer" %69 : f32
        %71 = spirv.IMul %51, %5 : i32
        %72 = spirv.IAdd %71, %50 : i32
        %73 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %72] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %74 = spirv.Load "StorageBuffer" %73 : f32
        %75 = spirv.IAdd %29, %71 : i32
        %76 = spirv.IAdd %75, %50 : i32
        %77 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %76] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %78 = spirv.Load "StorageBuffer" %77 : f32
        %79 = spirv.FMul %74, %64 : f32
        %80 = spirv.FMul %79, %70 : f32
        %81 = spirv.FAdd %78, %80 : f32
        %82 = spirv.AccessChain %__resource_var_0_4__addr[%cst0_i32, %44] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        spirv.Store "StorageBuffer" %82, %81 : f32
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %43 = spirv.IAdd %38, %37 : i32
      spirv.Branch ^bb1(%43 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @grouped8_f32_dispatch_6_elementwise_broadcast_D_f32, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @grouped8_f32_dispatch_6_elementwise_broadcast_D_f32 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @grouped8_f32_dispatch_6_elementwise_broadcast_D_f32 "SignedZeroInfNanPreserve", 32
}