spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, StorageBuffer16BitAccess, Int16, SignedZeroInfNanPreserve, Matrix], [SPV_KHR_storage_buffer_storage_class, SPV_KHR_16bit_storage, SPV_KHR_float_controls]> {
  spirv.GlobalVariable @__builtin__NumWorkgroups__ built_in("NumWorkgroups") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__WorkgroupId__ built_in("WorkgroupId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__builtin__LocalInvocationId__ built_in("LocalInvocationId") : !spirv.ptr<vector<3xi32>, Input>
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_2_ bind(0, 2) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_3_ bind(0, 3) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
  spirv.func @fp8_roundtrip_128_dispatch_2_elementwise_broadcast_D_i8() "None" attributes {gpu.known_block_size = array<i32: 64, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst255_i32 = spirv.Constant 255 : i32
    %cst8_i32 = spirv.Constant 8 : i32
    %cst6_i32 = spirv.Constant 6 : i32
    %cst4_i32 = spirv.Constant 4 : i32
    %cst16_i32 = spirv.Constant 16 : i32
    %cst2_i32 = spirv.Constant 2 : i32
    %cst126_i32 = spirv.Constant 126 : i32
    %cst64_i32 = spirv.Constant 64 : i32
    %cst128_i32 = spirv.Constant 128 : i32
    %cst24_i32 = spirv.Constant 24 : i32
    %cst1_i32 = spirv.Constant 1 : i32
    %cst_f32 = spirv.Constant 4.480000e+02 : f32
    %cst_f32_0 = spirv.Constant -4.480000e+02 : f32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %2 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst2_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %3 = spirv.Load "PushConstant" %2 : i32
    %4 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst4_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %5 = spirv.Load "PushConstant" %4 : i32
    %6 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst6_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %7 = spirv.Load "PushConstant" %6 : i32
    %8 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst8_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<10 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %9 = spirv.Load "PushConstant" %8 : i32
    %__resource_var_0_2__addr = spirv.mlir.addressof @__resource_var_0_2_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_3__addr = spirv.mlir.addressof @__resource_var_0_3_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>
    %__builtin__LocalInvocationId___addr = spirv.mlir.addressof @__builtin__LocalInvocationId__ : !spirv.ptr<vector<3xi32>, Input>
    %10 = spirv.Load "Input" %__builtin__LocalInvocationId___addr : vector<3xi32>
    %11 = spirv.CompositeExtract %10[0 : i32] : vector<3xi32>
    %__builtin__WorkgroupId___addr = spirv.mlir.addressof @__builtin__WorkgroupId__ : !spirv.ptr<vector<3xi32>, Input>
    %12 = spirv.Load "Input" %__builtin__WorkgroupId___addr : vector<3xi32>
    %13 = spirv.CompositeExtract %12[0 : i32] : vector<3xi32>
    %__builtin__NumWorkgroups___addr = spirv.mlir.addressof @__builtin__NumWorkgroups__ : !spirv.ptr<vector<3xi32>, Input>
    %14 = spirv.Load "Input" %__builtin__NumWorkgroups___addr : vector<3xi32>
    %15 = spirv.CompositeExtract %14[0 : i32] : vector<3xi32>
    %16 = spirv.IMul %13, %cst64_i32 : i32
    %17 = spirv.IMul %15, %cst64_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%16 : i32)
    ^bb1(%18: i32):  // 2 preds: ^bb0, ^bb2
      %19 = spirv.SLessThan %18, %3 : i32
      spirv.BranchConditional %19, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %20 = spirv.ISub %3, %18 : i32
      %21 = spirv.GL.SMin %20, %cst64_i32 : i32
      %22 = spirv.SGreaterThan %21, %11 : i32
      spirv.mlir.selection {
        spirv.BranchConditional %22, ^bb1, ^bb2
      ^bb1:  // pred: ^bb0
        %24 = spirv.IAdd %18, %11 : i32
        %25 = spirv.GL.SAbs %24 : i32
        %26 = spirv.GL.SAbs %7 : i32
        %27 = spirv.UMod %25, %26 : i32
        %28 = spirv.IEqual %24, %25 : i32
        %29 = spirv.SNegate %27 : i32
        %30 = spirv.Select %28, %27, %29 : i1, i32
        %31 = spirv.SDiv %24, %7 : i32
        %32 = spirv.UDiv %30, %cst128_i32 : i32
        %33 = spirv.IMul %31, %7 : i32
        %34 = spirv.IAdd %33, %30 : i32
        %35 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %34] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i16, stride=2> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i16, StorageBuffer>
        %36 = spirv.Load "StorageBuffer" %35 : i16
        %37 = spirv.UConvert %36 : i16 to i32
        %38 = spirv.ShiftLeftLogical %37, %cst16_i32 : i32, i32
        %39 = spirv.Bitcast %38 : i32 to f32
        %40 = spirv.IMul %31, %9 : i32
        %41 = spirv.IAdd %40, %32 : i32
        %42 = spirv.AccessChain %__resource_var_0_1__addr[%cst0_i32, %41] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %43 = spirv.Load "StorageBuffer" %42 : f32
        %44 = spirv.FDiv %39, %43 : f32
        %45 = spirv.GL.FMax %44, %cst_f32_0 : f32
        %46 = spirv.IsNan %44 : f32
        %47 = spirv.IsNan %cst_f32_0 : f32
        %48 = spirv.Select %46, %44, %45 : i1, f32
        %49 = spirv.Select %47, %cst_f32_0, %48 : i1, f32
        %50 = spirv.GL.FMin %49, %cst_f32 : f32
        %51 = spirv.IsNan %49 : f32
        %52 = spirv.IsNan %cst_f32 : f32
        %53 = spirv.Select %51, %49, %50 : i1, f32
        %54 = spirv.Select %52, %cst_f32, %53 : i1, f32
        %55 = spirv.GL.FAbs %54 : f32
        %56 = spirv.GL.FMin %55, %cst_f32 : f32
        %57 = spirv.IsNan %55 : f32
        %58 = spirv.Select %57, %55, %56 : i1, f32
        %59 = spirv.Select %52, %cst_f32, %58 : i1, f32
        %60 = spirv.Variable : !spirv.ptr<i32, Function>
        %61 = spirv.Variable : !spirv.ptr<i32, Function>
        spirv.mlir.loop {
          spirv.Branch ^bb1(%cst0_i32, %cst126_i32 : i32, i32)
        ^bb1(%101: i32, %102: i32):  // 2 preds: ^bb0, ^bb2
          %103 = spirv.ULessThan %101, %102 : i32
          spirv.Store "Function" %60, %101 : i32
          spirv.Store "Function" %61, %102 : i32
          spirv.BranchConditional %103, ^bb2, ^bb3
        ^bb2:  // pred: ^bb1
          %104 = spirv.IAdd %101, %102 : i32
          %105 = spirv.IAdd %104, %cst1_i32 : i32
          %106 = spirv.UDiv %105, %cst2_i32 : i32
          %107 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %106] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
          %108 = spirv.Load "StorageBuffer" %107 : f32
          %109 = spirv.FOrdLessThanEqual %108, %59 : f32
          %110 = spirv.ISub %106, %cst1_i32 : i32
          %111 = spirv.Select %109, %106, %101 : i1, i32
          %112 = spirv.Select %109, %102, %110 : i1, i32
          spirv.Branch ^bb1(%111, %112 : i32, i32)
        ^bb3:  // pred: ^bb1
          spirv.mlir.merge
        }
        %62 = spirv.Load "Function" %61 : i32
        %63 = spirv.Load "Function" %60 : i32
        %64 = spirv.IAdd %63, %cst1_i32 : i32
        %65 = spirv.GL.UMin %64, %cst126_i32 : i32
        %66 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %63] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %67 = spirv.Load "StorageBuffer" %66 : f32
        %68 = spirv.AccessChain %__resource_var_0_2__addr[%cst0_i32, %65] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
        %69 = spirv.Load "StorageBuffer" %68 : f32
        %70 = spirv.FSub %59, %67 : f32
        %71 = spirv.FSub %59, %69 : f32
        %72 = spirv.GL.FAbs %70 : f32
        %73 = spirv.GL.FAbs %71 : f32
        %74 = spirv.FOrdLessThan %73, %72 : f32
        %75 = spirv.FOrdEqual %73, %72 : f32
        %76 = spirv.BitwiseAnd %63, %cst1_i32 : i32
        %77 = spirv.BitwiseAnd %65, %cst1_i32 : i32
        %78 = spirv.INotEqual %76, %cst0_i32 : i32
        %79 = spirv.IEqual %77, %cst0_i32 : i32
        %80 = spirv.LogicalAnd %75, %79 : i1
        %81 = spirv.LogicalAnd %80, %78 : i1
        %82 = spirv.LogicalOr %74, %81 : i1
        %83 = spirv.Select %82, %65, %63 : i1, i32
        %84 = spirv.Bitcast %54 : f32 to i32
        %85 = spirv.ShiftRightLogical %84, %cst24_i32 : i32, i32
        %86 = spirv.BitwiseAnd %85, %cst128_i32 : i32
        %87 = spirv.BitwiseOr %83, %86 : i32
        %88 = spirv.BitwiseAnd %87, %cst255_i32 : i32
        %89 = spirv.IAdd %1, %18 : i32
        %90 = spirv.IAdd %89, %11 : i32
        %91 = spirv.UMod %90, %cst4_i32 : i32
        %92 = spirv.IMul %91, %cst8_i32 : i32
        %93 = spirv.ShiftLeftLogical %cst255_i32, %92 : i32, i32
        %94 = spirv.Not %93 : i32
        %95 = spirv.BitwiseAnd %88, %cst255_i32 : i32
        %96 = spirv.ShiftLeftLogical %95, %92 : i32, i32
        %97 = spirv.SDiv %90, %cst4_i32 : i32
        %98 = spirv.AccessChain %__resource_var_0_3__addr[%cst0_i32, %97] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
        %99 = spirv.AtomicAnd <Device> <AcquireRelease|UniformMemory> %98, %94 : !spirv.ptr<i32, StorageBuffer>
        %100 = spirv.AtomicOr <Device> <AcquireRelease|UniformMemory> %98, %96 : !spirv.ptr<i32, StorageBuffer>
        spirv.Branch ^bb2
      ^bb2:  // 2 preds: ^bb0, ^bb1
        spirv.mlir.merge
      }
      %23 = spirv.IAdd %18, %17 : i32
      spirv.Branch ^bb1(%23 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @fp8_roundtrip_128_dispatch_2_elementwise_broadcast_D_i8, @__builtin__LocalInvocationId__, @__builtin__WorkgroupId__, @__builtin__NumWorkgroups__
  spirv.ExecutionMode @fp8_roundtrip_128_dispatch_2_elementwise_broadcast_D_i8 "LocalSize", 64, 1, 1
  spirv.ExecutionMode @fp8_roundtrip_128_dispatch_2_elementwise_broadcast_D_i8 "SignedZeroInfNanPreserve", 32
}