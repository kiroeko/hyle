spirv.module Logical GLSL450 requires #spirv.vce<v1.0, [Shader, Matrix], [SPV_KHR_storage_buffer_storage_class]> {
  spirv.GlobalVariable @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<2 x i32, stride=4> [0]), Block>, PushConstant>
  spirv.GlobalVariable @__resource_var_0_1_ bind(0, 1) : !spirv.ptr<!spirv.struct<(!spirv.array<1 x i32, stride=4> [0])>, StorageBuffer>
  spirv.GlobalVariable @__resource_var_0_0_ bind(0, 0) : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
  spirv.func @linear_normal_f32_dispatch_0_reduction_D_f32xi32() "None" attributes {gpu.known_block_size = array<i32: 1, 1, 1>, hal.executable.target = #hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>} {
    %cst1_i32 = spirv.Constant 1 : i32
    %cst2139095040_i32 = spirv.Constant 2139095040 : i32
    %cst0_i32 = spirv.Constant 0 : i32
    %__push_constant_var___addr = spirv.mlir.addressof @__push_constant_var__ : !spirv.ptr<!spirv.struct<(!spirv.array<2 x i32, stride=4> [0]), Block>, PushConstant>
    %0 = spirv.AccessChain %__push_constant_var___addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<2 x i32, stride=4> [0]), Block>, PushConstant>, i32, i32 -> !spirv.ptr<i32, PushConstant>
    %1 = spirv.Load "PushConstant" %0 : i32
    %__resource_var_0_1__addr = spirv.mlir.addressof @__resource_var_0_1_ : !spirv.ptr<!spirv.struct<(!spirv.array<1 x i32, stride=4> [0])>, StorageBuffer>
    %__resource_var_0_0__addr = spirv.mlir.addressof @__resource_var_0_0_ : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>
    %2 = spirv.InBoundsAccessChain %__resource_var_0_1__addr[%cst0_i32, %cst0_i32] : !spirv.ptr<!spirv.struct<(!spirv.array<1 x i32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<i32, StorageBuffer>
    spirv.Store "StorageBuffer" %2, %cst0_i32 : i32
    spirv.mlir.loop {
      spirv.Branch ^bb1(%cst0_i32 : i32)
    ^bb1(%3: i32):  // 2 preds: ^bb0, ^bb2
      %4 = spirv.SLessThan %3, %1 : i32
      spirv.BranchConditional %4, ^bb2, ^bb3
    ^bb2:  // pred: ^bb1
      %5 = spirv.AccessChain %__resource_var_0_0__addr[%cst0_i32, %3] : !spirv.ptr<!spirv.struct<(!spirv.rtarray<f32, stride=4> [0])>, StorageBuffer>, i32, i32 -> !spirv.ptr<f32, StorageBuffer>
      %6 = spirv.Load "StorageBuffer" %5 : f32
      %7 = spirv.Load "StorageBuffer" %2 : i32
      %8 = spirv.Bitcast %6 : f32 to i32
      %9 = spirv.BitwiseAnd %8, %cst2139095040_i32 : i32
      %10 = spirv.IEqual %9, %cst2139095040_i32 : i32
      %11 = spirv.Select %10, %cst1_i32, %cst0_i32 : i1, i32
      %12 = spirv.BitwiseOr %7, %11 : i32
      spirv.Store "StorageBuffer" %2, %12 : i32
      %13 = spirv.IAdd %3, %cst1_i32 : i32
      spirv.Branch ^bb1(%13 : i32)
    ^bb3:  // pred: ^bb1
      spirv.mlir.merge
    }
    spirv.Return
  }
  spirv.EntryPoint "GLCompute" @linear_normal_f32_dispatch_0_reduction_D_f32xi32
  spirv.ExecutionMode @linear_normal_f32_dispatch_0_reduction_D_f32xi32 "LocalSize", 1, 1, 1
}