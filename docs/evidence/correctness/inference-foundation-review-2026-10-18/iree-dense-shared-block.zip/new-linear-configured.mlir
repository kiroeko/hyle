util.func public @linear_normal_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: f32, %arg4: !hal.fence, %arg5: !hal.fence) -> (!hal.buffer_view, !hal.buffer_view) attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @linear_normal_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi8>, %input2: tensor<?x?x?xf32>, %input3: f32) -> (%output0: tensor<?x?xf32>, %output1: tensor<i32>)", iree.abi.model = "coarse-fences"}} {
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c1 = arith.constant 1 : index
    %c128 = arith.constant 128 : index
    %c0_i8 = arith.constant 0 : i8
    %c4 = arith.constant 4 : index
    %c512 = arith.constant 512 : index
    %c32_i64 = arith.constant 32 : i64
    %__constant_tensor_127xf32 = util.global.load immutable @__constant_tensor_127xf32 : !stream.resource<constant>
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i8) encoding(%dense_row_major)
    %9 = arith.muli %6, %7 : index
    %10 = arith.muli %9, %8 : index
    %11 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi8>{%6, %7, %8} in !stream.resource<external>{%10}
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%12, %13, %14]) type(%element_type_f32) encoding(%dense_row_major)
    %15 = arith.muli %12, %c4 : index
    %16 = arith.muli %15, %13 : index
    %17 = arith.muli %16, %14 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%12, %13, %14} in !stream.resource<external>{%17}
    %19 = arith.divui %1, %c128 : index
    %20 = arith.muli %0, %1 overflow<nsw> : index
    %21 = arith.muli %0, %19 overflow<nsw> : index
    %22 = arith.muli %21, %c4 : index
    %23 = arith.muli %2, %7 : index
    %24 = util.align %23, %c64 : index
    %25 = arith.addi %24, %c64 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%25} => !stream.timepoint
    %26 = stream.resource.subview %result[%c0] : !stream.resource<external>{%25} -> !stream.resource<external>{%c4}
    %27 = util.align %22, %c64 : index
    %28 = util.align %20, %c64 : index
    %29 = arith.addi %27, %28 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%29} => !stream.timepoint
    %30 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %31 = arith.index_castui %20 : index to i64
    %32 = arith.index_castui %20 : index to i32
    %33 = arith.shrui %31, %c32_i64 : i64
    %34 = arith.trunci %33 : i64 to i32
    %35 = arith.index_castui %21 : index to i64
    %36 = arith.index_castui %21 : index to i32
    %37 = arith.shrui %35, %c32_i64 : i64
    %38 = arith.trunci %37 : i64 to i32
    %39 = arith.bitcast %arg3 : f32 to i32
    %40 = arith.index_castui %27 : index to i64
    %41 = arith.index_castui %27 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %0 : index to i64
    %45 = arith.index_castui %0 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %1 : index to i64
    %49 = arith.index_castui %1 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %19 : index to i64
    %53 = arith.index_castui %19 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%30) => with(%4 as %arg6: !stream.resource<external>{%3}, %__constant_tensor_127xf32 as %arg7: !stream.resource<constant>{%c512}, %result as %arg8: !stream.resource<external>{%25}, %result_0 as %arg9: !stream.resource<transient>{%29}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_0::@vulkan_spirv_fb::@linear_normal_f32_dispatch_0_reduction_D_f32xi32[%20](%32, %34 : i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg8[%c0 for %25] : !stream.resource<external>{%25}
        }
        stream.cmd.dispatch @linear_normal_f32_dispatch_1::@vulkan_spirv_fb::@linear_normal_f32_dispatch_1_reduction_DxD_f32[%21, %c128](%36, %38, %39 : i32, i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          wo %arg9[%c0 for %29] : !stream.resource<transient>{%29}
        }
      }
      stream.cmd.concurrent {
        stream.cmd.dispatch @linear_normal_f32_dispatch_2::@vulkan_spirv_fb::@linear_normal_f32_dispatch_2_elementwise_broadcast_D_i8[%20, %0, %1, %19](%41, %43, %32, %34, %45, %47, %49, %51, %53, %55 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
          ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
          ro %arg9[%c0 for %29] : !stream.resource<transient>{%29},
          ro %arg7[%c0 for %c512] : !stream.resource<constant>{%c512},
          wo %arg9[%c0 for %29] : !stream.resource<transient>{%29}
        }
        stream.cmd.fill %c0_i8, %arg8[%c64 for %23] : i8 -> !stream.resource<external>{%25}
      }
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %c64, %23, %56 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb1(%57: index, %58: !stream.resource<external>, %59: index, %60: index, %61: index, %62: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %63 = arith.cmpi slt, %57, %19 : index
    cf.cond_br %63, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %64 = arith.muli %57, %c128 : index
    %65 = arith.muli %0, %c128 overflow<nsw> : index
    %66 = arith.muli %0, %c512 : index
    %67 = arith.muli %7, %c128 overflow<nsw> : index
    %68 = arith.muli %7, %c512 : index
    %69 = arith.addi %66, %68 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%56) => !stream.resource<transient>{%69} => !stream.timepoint
    %70 = arith.index_castui %65 : index to i64
    %71 = arith.index_castui %65 : index to i32
    %72 = arith.shrui %70, %c32_i64 : i64
    %73 = arith.trunci %72 : i64 to i32
    %74 = arith.index_castui %64 : index to i64
    %75 = arith.index_castui %64 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = arith.index_castui %66 : index to i64
    %79 = arith.index_castui %66 : index to i32
    %80 = arith.shrui %78, %c32_i64 : i64
    %81 = arith.trunci %80 : i64 to i32
    %82 = arith.index_castui %67 : index to i64
    %83 = arith.index_castui %67 : index to i32
    %84 = arith.shrui %82, %c32_i64 : i64
    %85 = arith.trunci %84 : i64 to i32
    %86 = arith.index_castui %6 : index to i64
    %87 = arith.index_castui %6 : index to i32
    %88 = arith.shrui %86, %c32_i64 : i64
    %89 = arith.trunci %88 : i64 to i32
    %90 = arith.index_castui %7 : index to i64
    %91 = arith.index_castui %7 : index to i32
    %92 = arith.shrui %90, %c32_i64 : i64
    %93 = arith.trunci %92 : i64 to i32
    %94 = arith.index_castui %8 : index to i64
    %95 = arith.index_castui %8 : index to i32
    %96 = arith.shrui %94, %c32_i64 : i64
    %97 = arith.trunci %96 : i64 to i32
    %98 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%result_0 as %arg6: !stream.resource<transient>{%29}, %11 as %arg7: !stream.resource<external>{%10}, %result_2 as %arg8: !stream.resource<transient>{%69}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_3::@vulkan_spirv_fb::@linear_normal_f32_dispatch_3_elementwise_broadcast_D_f32[%65, %64, %0, %1](%41, %43, %71, %73, %75, %77, %45, %47, %49, %51 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %29] : !stream.resource<transient>{%29},
        wo %arg8[%c0 for %69] : !stream.resource<transient>{%69}
      }
      stream.cmd.dispatch @linear_normal_f32_dispatch_4::@vulkan_spirv_fb::@linear_normal_f32_dispatch_4_elementwise_broadcast_D_f32[%67, %64, %6, %7, %8](%79, %81, %83, %85, %75, %77, %87, %89, %91, %93, %95, %97 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %10] : !stream.resource<external>{%10},
        wo %arg8[%c0 for %69] : !stream.resource<transient>{%69}
      }
    } => !stream.timepoint
    %99 = stream.timepoint.await %98 => %result_2 : !stream.resource<transient>{%69}
    %100 = stream.resource.subview %99[%c0] : !stream.resource<transient>{%69} -> !stream.resource<transient>{%66}
    %101 = stream.resource.subview %99[%66] : !stream.resource<transient>{%69} -> !stream.resource<transient>{%68}
    %102 = util.optimization_barrier %100 : !stream.resource<transient>
    %103 = util.optimization_barrier %101 : !stream.resource<transient>
    %104 = arith.muli %0, %7 overflow<nsw> : index
    %105 = arith.muli %104, %c4 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%62) => !stream.resource<external>{%105} => !stream.timepoint
    %106 = arith.addi %24, %24 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%62) => !stream.resource<transient>{%106} => !stream.timepoint
    %107 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %108 = arith.index_castui %24 : index to i64
    %109 = arith.index_castui %24 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %104 : index to i64
    %113 = arith.index_castui %104 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %57 : index to i64
    %117 = arith.index_castui %57 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = arith.index_castui %12 : index to i64
    %121 = arith.index_castui %12 : index to i32
    %122 = arith.shrui %120, %c32_i64 : i64
    %123 = arith.trunci %122 : i64 to i32
    %124 = arith.index_castui %13 : index to i64
    %125 = arith.index_castui %13 : index to i32
    %126 = arith.shrui %124, %c32_i64 : i64
    %127 = arith.trunci %126 : i64 to i32
    %128 = arith.index_castui %14 : index to i64
    %129 = arith.index_castui %14 : index to i32
    %130 = arith.shrui %128, %c32_i64 : i64
    %131 = arith.trunci %130 : i64 to i32
    %132 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%107) => with(%102 as %arg6: !stream.resource<transient>{%66}, %103 as %arg7: !stream.resource<transient>{%68}, %58 as %arg8: !stream.resource<external>{%59}, %result_0 as %arg9: !stream.resource<transient>{%29}, %18 as %arg10: !stream.resource<external>{%17}, %result_4 as %arg11: !stream.resource<external>{%105}, %result_6 as %arg12: !stream.resource<transient>{%106}) {
      stream.cmd.dispatch @linear_normal_f32_dispatch_5::@vulkan_spirv_fb::@linear_normal_f32_dispatch_5_matmul_DxDxD_f32[%c128, %0, %7](%45, %47, %91, %93 : i32, i32, i32, i32) {
        ro %arg6[%c0 for %66] : !stream.resource<transient>{%66},
        ro %arg7[%c0 for %68] : !stream.resource<transient>{%68},
        wo %arg12[%c0 for %106] : !stream.resource<transient>{%106}
      }
      stream.cmd.copy %arg8[%60], %arg12[%24], %23 : !stream.resource<external>{%59} -> !stream.resource<transient>{%106}
      stream.cmd.dispatch @linear_normal_f32_dispatch_6::@vulkan_spirv_fb::@linear_normal_f32_dispatch_6_elementwise_broadcast_D_f32[%104, %57, %0, %19, %12, %13, %14, %7](%109, %111, %113, %115, %117, %119, %45, %47, %53, %55, %121, %123, %125, %127, %129, %131, %91, %93 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %29] : !stream.resource<transient>{%29},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg12[%c0 for %106] : !stream.resource<transient>{%106},
        wo %arg11[%c0 for %105] : !stream.resource<external>{%105}
      }
    } => !stream.timepoint
    %133 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%132) => %result_6 : !stream.resource<transient>{%106} => !stream.timepoint
    %134 = arith.addi %57, %c1 : index
    cf.br ^bb1(%134, %result_4, %105, %c0, %105, %133 : index, !stream.resource<external>, index, index, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %135 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%62) => %result_0 : !stream.resource<transient>{%29} => !stream.timepoint
    %136 = stream.resource.subview %58[%60] : !stream.resource<external>{%59} -> !stream.resource<external>{%61}
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %135 => (%arg5 : !hal.fence)
    %137 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %136 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%23} -> !hal.buffer_view
    %138 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %26 : tensor<i32> in !stream.resource<external>{%c4} -> !hal.buffer_view
    util.return %137, %138 : !hal.buffer_view, !hal.buffer_view
  }
  hal.executable private @linear_power_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @linear_power_f32_dispatch_1_reduction_DxD_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @linear_power_f32_dispatch_1_reduction_DxD_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c8388607_i32 = arith.constant 8388607 : i32
          %c23_i32 = arith.constant 23 : i32
          %cst = arith.constant 0.00223214296 : f32
          %c0 = arith.constant 0 : index
          %c128 = arith.constant 128 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = arith.extui %1 : i32 to i64
          %4 = arith.shli %3, %c32_i64 : i64
          %5 = arith.extui %0 : i32 to i64
          %6 = arith.ori %5, %4 : i64
          %7 = arith.index_castui %6 : i64 to index
          %8 = arith.bitcast %2 : i32 to f32
          %9 = util.assume.int %7<umin = 0, umax = 9223372036854775807> : index
          %10 = iree_tensor_ext.dispatch.workload.ordinal %9, 0 : index
          %11 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%10, %c128}
          %12 = hal.interface.binding.subspan layout(<constants = 3, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          %13 = iree_tensor_ext.dispatch.tensor.load %11, offsets = [0, 0], sizes = [%10, 128], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%10, %c128} -> tensor<?x128xf32>
          %14 = tensor.empty(%10) : tensor<?xf32>
          %15 = linalg.fill ins(%8 : f32) outs(%14 : tensor<?xf32>) -> tensor<?xf32>
          %16 = linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0)>], iterator_types = ["parallel", "reduction"]} ins(%13 : tensor<?x128xf32>) outs(%15 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f32, %out: f32):
            %18 = math.absf %in : f32
            %19 = arith.maximumf %18, %out : f32
            linalg.yield %19 : f32
          } -> tensor<?xf32>
          %17 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%16 : tensor<?xf32>) outs(%14 : tensor<?xf32>) {
          ^bb0(%in: f32, %out: f32):
            %18 = arith.mulf %in, %cst : f32
            %19 = arith.bitcast %18 : f32 to i32
            %20 = arith.shrui %19, %c23_i32 : i32
            %21 = arith.andi %19, %c8388607_i32 : i32
            %22 = arith.cmpi ne, %21, %c0_i32 : i32
            %23 = arith.extui %22 : i1 to i32
            %24 = arith.addi %20, %23 : i32
            %25 = arith.shli %24, %c23_i32 : i32
            %26 = arith.bitcast %25 : i32 to f32
            linalg.yield %26 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %17, %12, offsets = [0], sizes = [%10], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%10}
          return
        }
        iree_codegen.dispatch_config @linear_power_f32_dispatch_1_reduction_DxD_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }