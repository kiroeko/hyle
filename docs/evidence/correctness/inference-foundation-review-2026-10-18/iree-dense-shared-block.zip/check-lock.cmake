get_filename_component(_root "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
include("${_root}/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(iree_vulkan_runtime_patches)
message(STATUS "IREE official dense resource tree/NOTICE identity PASS")
