from pathlib import Path
import ast, base64, hashlib, importlib.util, json, os, subprocess, sys, time
R = Path(__file__).resolve().parents[3]
O = Path(__file__).resolve().parent
CACHE = R/'.scratch/inference-foundation-review-2026-10-18/vulkan-official-bank'
records = json.loads((O/'commands.json').read_text()) if (O/'commands.json').exists() else []
old = json.loads((CACHE/'commands.json').read_text())
cc = next(x['command'] for x in old if x['tag'] == 'tests-compile')
flags = cc[1:-2]
native = next(x['command'] for x in old if x['tag'] == 'native-program-compile')
nflags = native[1:-2] + ['/I'+str(R/'src/compute_provider_iree_vulkan')]
sys.path.insert(0, str(R/'scripts'))
from hyle_environment import windows_compiler_environment
env = windows_compiler_environment({'CMAKE_CXX_COMPILER':cc[0],'CMAKE_C_COMPILER':cc[0]})
env.update(VSLANG='1033',DISABLE_VULKAN_OBS_CAPTURE='1',VK_LOADER_LAYERS_DISABLE='~all~')
env['PATH'] = str(R/'.scratch/build-compute-v2-dev/bin')+os.pathsep+env['PATH']

def run(tag, command):
    command = list(map(str, command))
    start = time.monotonic()
    p = subprocess.run(command,cwd=R,env=env,capture_output=True,timeout=180)
    stem = str(len(records)+1)+'-'+tag
    (O/(stem+'.stdout.log')).write_bytes(p.stdout)
    (O/(stem+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag,command=command,exit=p.returncode,seconds=time.monotonic()-start))
    (O/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(stem,p.returncode,p.stdout.decode(errors='replace')[-6000:],p.stderr.decode(errors='replace')[-2400:],flush=True)
    if p.returncode: raise SystemExit(p.returncode)

class Vendor:
    def __init__(self,arm,relative=''): self.arm,self.relative=arm,relative
    def __truediv__(self,name): return Vendor(self.arm,self.relative+'/'+name if self.relative else name)
    def actual(self):
        p=R/'third_party/iree_vulkan_runtime'/self.relative
        if self.arm=='old' and self.relative in ['programs/manifest.json','programs/official.mlir','programs/official.vmfb.b64']:
            p=O/'before/third_party/iree_vulkan_runtime'/self.relative
        return p
    def read_bytes(self): return self.actual().read_bytes()
    def read_text(self,**kw): return self.actual().read_text(**kw)

def generate():
    # Execute the actual product embedding block without replaying/copying its
    # unchanged native runtime source tree. All manifest recipe/binary hashes
    # are still checked by the same product statements before embedding.
    script=R/'src/compute_provider_iree_vulkan/prepare_source.py'
    node=next(n for n in ast.parse(script.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='prepare')
    start=next(i for i,n in enumerate(node.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='programs' for t in n.targets))
    code=compile(ast.fix_missing_locations(ast.Module(body=node.body[start:-1],type_ignores=[])),str(script),'exec')
    for arm in ['old','new']:
        generated=O/arm;generated.mkdir(exist_ok=True)
        exec(code,dict(vendor=Vendor(arm),generated=generated,json=json,base64=base64,sha=lambda x:hashlib.sha256(x).hexdigest()))
        run(arm+'-embedding-compile',[cc[0],*nflags,generated/'programs.cc','/Fo'+str(O/(arm+'-programs.obj'))])

def build():
    generate()
    run('tests-compile',[cc[0],*flags,R/'tests/graph_route_vulkan/iree_test.cc','/Fo'+str(O/'tests.obj')])
    link=next(x['command']for x in reversed(old)if x['tag']=='link'and x['exit']==0)
    for arm in ['old','new']:
        command=[a for a in link if not a.startswith(('/OUT:','/MAP:')) and a!=str(CACHE/'tests.obj')]
        missing=[a for a in command if a.endswith(('.obj','.lib'))and Path(a).is_absolute()and not Path(a).exists()]
        assert not missing,missing
        run(arm+'-link',[*command,O/'tests.obj',O/(arm+'-programs.obj'),'/OUT:'+str(O/(arm+'.exe')),'/MAP:'+str(O/(arm+'.map'))])

def test():
    filters='VulkanGraph.DenseOfficialBlocksShareOneWeightAcrossTokensAndSlots:VulkanGraph.OriginalOfficialDynamicLinearsAndWeightTailDecode:VulkanGraph.OriginalOfficialEncodedBlock128TailAndReplay:VulkanGraph.OriginalOfficialGroupedFp4Fp8SharedDistinctAndChecked'
    for arm in ['old','new']: run(arm+'-tests',[O/(arm+'.exe'),'--gtest_filter='+filters,'--gtest_color=no'])

def census():
    run('census-compile',[cc[0],*flags,'/I'+str(R),O/'census.cc','/Fo'+str(O/'census.obj')])
    link=next(x['command']for x in reversed(old)if x['tag']=='link'and x['exit']==0)
    command=[a for a in link if not a.startswith(('/OUT:','/MAP:'))and a!=str(CACHE/'tests.obj')]
    for arm in ['old','new']:
        exe=O/(arm+'-census.exe')
        run(arm+'-census-link',[*command,O/'census.obj',O/(arm+'-programs.obj'),'/OUT:'+str(exe),'/MAP:'+str(exe.with_suffix('.map'))])
        run(arm+'-census',[exe,'--gtest_color=no'])

if __name__=='__main__':
    for action in sys.argv[1:] or ['build','test']: globals()[action]()
