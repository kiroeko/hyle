#include <cstdio>
#include "tests/compute_route_vulkan/official_test_support.h"
#include "hyle/mem/quota_allocator.h"

TEST(IreeDenseResources, SameSmallDensePoint) {
  namespace c=hyle::compute;namespace v=c::vulkan;
  namespace t=vulkan_tensor_test;namespace o=vulkan_official_test;
  hyle::mem::QuotaAllocator quota(hyle::mem::system_allocator());
  {
    auto context=vulkan_test::context(&quota).value();
    constexpr int rows=3,n=129,k=256;
    o::Weight weight(1,n,k);
    const auto desc=t::dense(c::DataType::kFloat32,{rows,k});
    const std::array<v::Argument,2> arguments{desc,weight.description};
    auto program=v::prepare(context,c::model_ops::float8_block_linear(),arguments).value();
    const auto prepared=quota.used();
    auto slot=program.create_invocation().value();
    const auto created=quota.used();
    std::vector<double> values(rows*k),expected(rows*n);
    for(int i=0;i<rows*k;++i)values[i]=i%128==0?448.:double(i%7-3)/2;
    for(int row=0;row<rows;++row)for(int col=0;col<n;++col)
      for(int j=0;j<k;++j)expected[row*n+col]+=values[row*k+j]*double(weight.values[col*k+j])*weight.scale(0,col,j/128);
    const std::array inputs{t::make(context,desc,values),context.upload(weight.description,weight.bytes).value()};
    ASSERT_TRUE(slot.bind(inputs).ok());const auto bound=quota.used();
    auto work=slot.submit().value();auto result=work.wait();ASSERT_TRUE(result)<<result.error().message();
    const auto completed=quota.used(),peak=quota.peak();
    t::expect(context,result->get()->tensors()[0],expected,true);
    std::fprintf(stderr,"VK_MEMORY prepared=%zu created=%zu bound=%zu completed=%zu peak_through_completion=%zu logical_shared_w_bytes=%d\n",prepared,created,bound,completed,peak,n*128*4);
  }
  EXPECT_EQ(quota.used(),0u);
}
