from pathlib import Path
import importlib.util, json, subprocess, time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('cuda_cache', ROOT / '.scratch/mtp-completion/run.py')
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
flags = c.flags + ['/I'+str(ROOT)]
records = json.loads((OUT/'cuda-commands.json').read_text()) if (OUT/'cuda-commands.json').exists() else []

def run(tag, command):
    command = list(map(str, command)); start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=c.env, capture_output=True, timeout=150)
    tag = str(len(records)+1) + '-' + tag
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout)
    (OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag, command=command, exit=p.returncode, seconds=time.monotonic()-start))
    (OUT/'cuda-commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(tag, p.returncode, p.stdout.decode(errors='replace')[-3500:], p.stderr.decode(errors='replace')[-1500:], flush=True)
    if p.returncode: raise SystemExit(p.returncode)

source = (ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc').read_text()
for codec in ('IQ1_XS', 'IQ1_XXS', 'IQ1_XXXS'):
    needle = 'return GGML_TYPE_' + codec + ';'
    assert source.count(needle) == 1
    source = source.replace(needle, 'return GGML_TYPE_COUNT; // Validation only: reused native cache predates this unrelated IQ1 enum.')
probe = OUT/'tensor_program.probe.cc'; probe.write_text(source)
objects = []
for path, name in ((ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc', 'cuda-provider'),
                   (probe, 'cuda-tensor'),
                   (ROOT/'tests/compute_provider_ggml_cuda/tensor_test.cc', 'cuda-tests')):
    obj = OUT/(name+'.obj'); run(name+'-compile', [c.cl, *flags, path, '/Fo'+str(obj)]); objects.append(obj)
objects += [c.OUT/'operation.obj', c.OLD/'ggml-cuda.strict.obj']
exe = OUT/'cuda-tests.exe'
run('cuda-link', [c.link, '/nologo', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT',
    '/OUT:'+str(exe), *objects, *c.libs, c.BASE/'lib/gtest_main.lib', c.BASE/'lib/gtest.lib', *c.system])
run('cuda-test', [exe, '--gtest_color=no', '--gtest_filter=GgmlCudaTensor.BatchedRopePositionsAndPerTokenFrequenciesReplay:GgmlCudaTensor.MatureRopeCoversQualifiedTypesAndLayouts'])
