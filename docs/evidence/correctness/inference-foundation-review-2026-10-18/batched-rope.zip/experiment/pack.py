from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
DEST = ROOT/'docs/evidence/correctness/inference-foundation-review-2026-10-18/batched-rope.zip'
sources = [
    'src/compute_ggml_runtime/explicit_rope.h',
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'src/compute_provider_ggml_vulkan/region.cc',
    'tests/compute_models/batched_rope_fixture.h',
    'tests/compute_provider_ggml_cuda/tensor_test.cc',
    'tests/compute_route_vulkan/managed_region_test.cc',
]
summary = {
    'fix': 'Connect rank-four explicit RoPE to independent [B,S] positions and [S,pairs] frequencies; retain shared variants and normalized sequence axis -3.',
    'cuda': '2/2 canonical tests PASS. New test: F32/F16/BF16, two layouts, shared/per-request positions, fixed/per-token frequencies, two changed-input replays; old dtype/layout boundary test also passes.',
    'vulkan': '1/1 canonical test PASS. F32/F16, same layout/position/frequency/replay combinations.',
    'native': 'No new kernels, SPIR-V or SDK builds. Fresh changed host translation units with cached native CUDA/Vulkan closure.',
    'limits': 'CUDA cached native headers predate 3 unrelated IQ1 enums; exact probe substitutes GGML_TYPE_COUNT only for those 3 cases. No new BF16 Vulkan RoPE or I64/strided/high-rank domain claim. CPU/Apple already have composable batched support; CPU ggml admission handled separately.',
}
(OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
identities = []
for name in sources:
    path = ROOT/name
    identities.append(dict(path=name, bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
for filename in ('cuda-commands.json', 'vulkan-commands.json'):
    commands = json.loads((OUT/filename).read_text())
    for command in commands:
        if 'link' not in command['tag']: continue
        for argument in command['command']:
            path = Path(argument)
            if path.suffix == '.obj' and path.exists():
                identities.append(dict(path=str(path), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(OUT/'identities.json').write_text(json.dumps(identities, indent=2)+'\n')
with zipfile.ZipFile(DEST, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in sources: archive.write(ROOT/name, 'source/'+name)
    for path in sorted(OUT.iterdir()):
        if path.suffix in ('.py', '.json', '.log', '.cc'):
            archive.write(path, 'experiment/'+path.name)
    archive.writestr('source/worktree.diff', subprocess.check_output(['git','diff','--',*sources], cwd=ROOT))
print(DEST.name, DEST.stat().st_size, hashlib.sha256(DEST.read_bytes()).hexdigest())
