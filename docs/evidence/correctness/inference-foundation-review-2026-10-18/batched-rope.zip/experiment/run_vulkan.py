from pathlib import Path
import json, os, subprocess, sys, time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
old_dir = ROOT/'.scratch/inference-feature-completion-2026-10-18/vulkan-highdim'
old = json.loads((old_dir/'commands.json').read_text())
region = next(x['command'] for x in reversed(old) if x['label']=='region-compile')
cl = Path(region[0]); flags = region[1:-2]
env = windows_compiler_environment({'CMAKE_CXX_COMPILER':str(cl), 'CMAKE_C_COMPILER':str(cl)})
env['PATH'] = str(ROOT/'.scratch/build-compute-v2-dev/bin') + os.pathsep + env['PATH']
env['DISABLE_VULKAN_OBS_CAPTURE']='1'; env['VK_LOADER_LAYERS_DISABLE']='~all~'
records = json.loads((OUT/'vulkan-commands.json').read_text()) if (OUT/'vulkan-commands.json').exists() else []

def run(tag, command):
    command = list(map(str, command)); start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=150)
    tag = str(len(records)+1) + '-' + tag
    (OUT/(tag+'.stdout.log')).write_bytes(p.stdout)
    (OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
    records.append(dict(tag=tag, command=command, exit=p.returncode, seconds=time.monotonic()-start))
    (OUT/'vulkan-commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(tag, p.returncode, p.stdout.decode(errors='replace')[-3500:], p.stderr.decode(errors='replace')[-1500:], flush=True)
    if p.returncode: raise SystemExit(p.returncode)

for path, name in ((ROOT/'src/compute_provider_ggml_vulkan/region.cc', 'vulkan-region'),
                   (ROOT/'tests/compute_route_vulkan/managed_region_test.cc', 'vulkan-tests')):
    run(name+'-compile', [cl, *flags, path, '/Fo'+str(OUT/(name+'.obj'))])
link = next(x['command'] for x in reversed(old) if x['label']=='test-link')
command = []
for arg in link:
    if arg.startswith('/OUT:'): arg = '/OUT:'+str(OUT/'vulkan-tests.exe')
    elif Path(arg) == old_dir/'region.obj': arg = str(OUT/'vulkan-region.obj')
    elif Path(arg) == old_dir/'native-cache-test.obj': arg = str(OUT/'vulkan-tests.obj')
    command.append(arg)
run('vulkan-link', command)
run('vulkan-test', [OUT/'vulkan-tests.exe', '--gtest_color=no', '--gtest_filter=VulkanManaged.BatchedRopePositionsAndPerTokenFrequenciesReplay'])
