from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent


def identity(p):
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


records = json.loads((OUT / 'commands.json').read_text())
result = json.loads((OUT / 'controls-results.json').read_text())
assert result['tests'] == 24 and result['failures'] == 0 and result['errors'] == 0
assert all(r['unchanged'] for r in records)
assert next(r for r in records if r['tag'] == 'controls-run')['exit'] == 0
sources = [
    'src/graph_route_cpu/cpu_context.cc', 'src/graph_route_cpu/compile.cc',
    'src/graph_route_cpu/CMakeLists.txt', 'src/graph/executable.cc',
    'src/graph/submission.cc', 'src/graph/submission_internal.h',
    'src/graph/CMakeLists.txt', 'src/graph/plan_state.h',
    'tests/graph/executable_test.cc', 'tests/graph/native_analysis_test.cc',
    'tests/graph/CMakeLists.txt', 'include/hyle/graph/executable.h',
    'include/hyle/graph/region_provider.h',
]
manifest = [identity(ROOT / p) for p in sources]
(OUT / 'source-identities.json').write_text(json.dumps(manifest, indent=2) + '\n')
objects = {Path(arg) for r in records for arg in r['command']
           if arg.endswith('.obj') and Path(arg).is_file()}
objects.update(p for p in OUT.glob('*.obj'))
(OUT / 'object-identities.json').write_text(json.dumps(
    [identity(p) for p in sorted(objects)], indent=2) + '\n')
summary = json.loads((OUT / 'summary.json').read_text())
summary.update({
    'compiled_translation_units': 7,
    'core_source_name': 'src/graph/submission.cc',
    'context_only': {
        'compile_exit': 0, 'symbol_inspection_exit': 0,
        'direct_context_object_batch_or_compile_imports': 0,
        'runtime_run': False,
        'link_failures_preserved': [
            '11: default ggml provider requires actual native MLA batch table',
            '12: native batch table requires current BatchSchema::mla_layout',
            '13: old batch materialization archive extracts obsolete operation TU',
        ],
        'limit': 'Object separation proven; full default-provider closure still retains its real batch capability. No SDK rebuild or claim of complete batch independence.',
    },
    'plan_layout': 'Other matched PlanState readers retained from final carrier-copy-contract closure as instructed.',
    'test_scope': 'Original nine controls plus four exact specialization, three reachability, four partition, three finite-exact and one empty/zero test.',
    'failed_commands': [dict(tag=r['tag'], exit=r['exit'], stdout=r['stdout'], stderr=r['stderr'])
                        for r in records if r['exit']],
    'source_and_native_sdk_changes_by_this_stage': False,
})
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
target = OUT / 'source-results.zip'
assert not target.exists(), 'refuse overwrite'
with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(OUT.iterdir()):
        if p.suffix in {'.py', '.cc', '.json', '.log'}:
            z.write(p, p.name)
    for name in sources:
        z.write(ROOT / name, 'source/' + name)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
receipt = identity(target)
(OUT / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
