from pathlib import Path, PurePosixPath
import difflib
import hashlib
import json
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parent
BASE = STAGE.parent
TARGET = ROOT / 'docs/evidence/correctness/inference-foundation-review-2026-10-18/execution-convergence.zip'
TEXT = {'.py', '.cc', '.h', '.json', '.log', '.txt', '.md', '.cmake', '.diff'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=digest(data))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def checked_source(path, row):
    data = path.read_bytes()
    assert digest(data) == row['sha256'], (str(path), 'source changed')
    if 'bytes' in row:
        assert len(data) == row['bytes'], (str(path), 'size changed')
    return data


def main():
    assert not TARGET.exists(), 'refuse overwrite of frozen evidence'
    old_receipt = json.loads((STAGE / 'archive-receipt.json').read_text())
    assert old_receipt == identity(STAGE / 'source-results.zip'), 'Windows source package changed'
    write_json(STAGE / 'windows-source-results-receipt.json', old_receipt)
    images = sorted(p for p in STAGE.iterdir() if p.is_file() and p.suffix.lower() in {'.exe', '.map', '.exp', '.lib'})
    objects = sorted(STAGE.glob('*.obj'))
    assert len(images) == 7 and len(objects) == 7, (images, objects)
    assert all(p.resolve().parent == STAGE for p in images + objects)
    write_json(STAGE / 'cleanup.json', dict(root=str(STAGE), files=[identity(p) for p in images],
               retained_stage_objects=[identity(p) for p in objects]))
    original_mac_manifest = STAGE / 'mac/results/cleanup-mac.json'
    mac_data = original_mac_manifest.read_bytes()
    mac = json.loads(mac_data)
    assert len(mac['files']) == 4 and len(mac['retain']) == 6
    (STAGE / 'cleanup-mac.json').write_bytes(mac_data)

    entries = {}

    def add(name, data):
        name = PurePosixPath(name).as_posix()
        assert not name.startswith('/') and '..' not in PurePosixPath(name).parts
        assert name not in entries, ('duplicate archive entry', name)
        assert PurePosixPath(name).suffix.lower() in TEXT or PurePosixPath(name).name == 'CMakeLists.txt', name
        entries[name] = data

    def tree(directory, prefix):
        for path in sorted(directory.rglob('*')):
            if path.is_file() and (path.suffix in TEXT or path.name == 'CMakeLists.txt'):
                add(prefix + '/' + path.relative_to(directory).as_posix(), path.read_bytes())

    for path in sorted(STAGE.iterdir()):
        if path.is_file() and path.suffix in TEXT and path.name not in {'archive-receipt.json', 'archive-contents.json'}:
            add('windows/' + path.name, path.read_bytes())
    tree(STAGE / 'removed', 'windows/removed')
    tree(STAGE / 'mac', 'mac')
    tree(BASE / 'submission-split', 'submission-split')
    tree(BASE / 'apple-finite-common', 'apple-finite-common')

    for row in json.loads((STAGE / 'source-identities.json').read_text()):
        path = Path(row['path'])
        add('source/current/' + path.relative_to(ROOT).as_posix(), checked_source(path, row))
    for row in json.loads((BASE / 'apple-finite-common/final-sha256.json').read_text()):
        path = ROOT / row['path']
        add('source/current/' + row['path'], checked_source(path, row))
    for row in json.loads((BASE / 'submission-split/source-identities.json').read_text()):
        checked_source(ROOT / row['path'], row)
    with tarfile.open(STAGE / 'mac/minimal-sources.tar.gz', 'r:gz') as archive:
        staged = json.loads((STAGE / 'mac/staged-sources.json').read_text())
        staged = {row['path']: row for row in staged}
        for member in archive.getmembers():
            assert member.isfile(), member.name
            data = archive.extractfile(member).read()
            if member.name in staged:
                assert digest(data) == staged[member.name]['sha256'], member.name
            add('mac/source/' + member.name, data)
    remote_root = mac['root'].rstrip('/') + '/'
    for row in json.loads((STAGE / 'mac/results/final-source-identities.json').read_text()):
        assert row['path'].startswith(remote_root)
        relative = row['path'][len(remote_root):]
        checked_source(ROOT / relative, row)
    docs = ['docs/architecture/compute-design.md', 'docs/developer/current-work.md',
            'docs/evidence/correctness/inference-foundation-review-2026-10-18/README.md']
    for name in docs + ['test.ps1']:
        data = (ROOT / name).read_bytes()
        if name == 'test.ps1':
            entries['source/current/test.ps1'] = data
        else:
            add('source/current/' + name, data)
    inventory = [dict(entry=name, bytes=len(data), sha256=digest(data)) for name, data in sorted(entries.items())]
    write_json(STAGE / 'archive-contents.json', inventory)
    add('archive-contents.json', (STAGE / 'archive-contents.json').read_bytes())
    assert entries['windows/cleanup.json'] == (STAGE / 'cleanup.json').read_bytes()
    assert entries['windows/cleanup-mac.json'] == mac_data
    with zipfile.ZipFile(TARGET, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(entries.items()):
            archive.writestr(name, data)
    with zipfile.ZipFile(TARGET) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == set(entries)
    receipt = identity(TARGET)
    write_json(STAGE / 'archive-receipt.json', receipt)
    print(json.dumps(dict(**receipt, entries=len(entries), windows_cleanup_files=len(images),
                         retained_windows_objects=len(objects), mac_cleanup_files=len(mac['files']),
                         retained_mac_objects=len(mac['retain'])), indent=2))


if __name__ == '__main__':
    main()
