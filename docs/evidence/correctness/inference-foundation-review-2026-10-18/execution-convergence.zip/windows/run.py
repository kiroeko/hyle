from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ARCH = OUT.parent
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import windows_compiler_environment


def history(stage):
    return json.loads((ARCH / stage / 'commands.json').read_text())


def prior(stage, tag):
    return next(r['command'] for r in reversed(history(stage))
                if r['tag'] == tag and r['exit'] == 0)


BASE = prior('carrier-copy-contract', 'controls-link')
CORE = prior('carrier-copy-contract', 'executable-compile')
CPU = prior('cold-constant-copy', 'cpu-context.obj-compile')
TEST = prior('immutable-constant-alias', 'executable-test-overlap-compile')
ENV = windows_compiler_environment(
    {'CMAKE_CXX_COMPILER': CORE[0], 'CMAKE_C_COMPILER': CORE[0]})
ENV['VSLANG'] = '1033'
torch = next(Path(x) for x in BASE if Path(x).name.lower() == 'torch_cpu.lib')
ENV['PATH'] = str(torch.parent) + os.pathsep + ENV['PATH']


def identity(path):
    p = Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}


def run(tag, command, sources=(), timeout=55):
    record_path = OUT / 'commands.json'
    records = json.loads(record_path.read_text()) if record_path.exists() else []
    name = f'{len(records) + 1:02d}-{tag}'
    before = [identity(p) for p in sources]
    print('starting', name, 'driver_pid', os.getpid(), flush=True)
    started = time.monotonic()
    command = list(map(str, command))
    try:
        p = subprocess.run(command, cwd=ROOT, env=ENV, capture_output=True,
                           timeout=timeout, creationflags=subprocess.CREATE_NO_WINDOW)
        code, stdout, stderr = p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr = 124, error.stdout or b'', error.stderr or b''
    (OUT / (name + '.stdout.log')).write_bytes(stdout)
    (OUT / (name + '.stderr.log')).write_bytes(stderr)
    after = [identity(p) for p in sources]
    row = {'tag': tag, 'command': command, 'exit': code,
           'seconds': time.monotonic() - started,
           'stdout': name + '.stdout.log', 'stderr': name + '.stderr.log',
           'before': before, 'after': after, 'unchanged': before == after}
    outputs = [Path(x[3:]) for x in command if x.lower().startswith('/fo')]
    if not code:
        row['objects'] = [identity(p) for p in outputs]
    records.append(row)
    record_path.write_text(json.dumps(records, indent=2) + '\n')
    print(name, code, flush=True)
    if code:
        print(stdout.decode(errors='replace')[-8000:])
        print(stderr.decode(errors='replace')[-3000:])
    if before != after:
        raise SystemExit('Source changed during command')
    if code:
        raise SystemExit(code)


def compile_one(source, name, original):
    flags = [x for x in original[1:]
             if not x.lower().startswith(('/fo', '/tp')) and not x.endswith('.cc')]
    sources = [ROOT / source]
    if source.startswith('src/graph/'):
        sources += [ROOT / 'src/graph/plan_state.h',
                    ROOT / 'src/graph/submission_internal.h']
    run(name + '-compile', [original[0], *flags, ROOT / source,
                           '/Fo' + str(OUT / (name + '.obj'))], sources)


def compile_all():
    jobs = [('src/graph_route_cpu/cpu_context.cc', 'cpu-context', CPU),
            ('src/graph_route_cpu/compile.cc', 'cpu-compile', CPU),
            ('tests/graph/executable_test.cc', 'executable-test', TEST),
            ('tests/graph/native_analysis_test.cc', 'native-analysis-test', TEST),
            ('src/graph/executable.cc', 'executable', CORE),
            ('src/graph/submission.cc', 'submission', CORE)]
    for args in jobs:
        compile_one(*args)


def link_controls():
    replacements = {'executable.obj': OUT / 'executable.obj',
                    'cpu-context.obj': OUT / 'cpu-context.obj',
                    'executable_test-overlap.obj': OUT / 'executable-test.obj'}
    command = []
    for x in BASE:
        if x.upper().startswith('/OUT:'):
            x = '/OUT:' + str(OUT / 'controls.exe')
        elif x.upper().startswith('/MAP:'):
            x = '/MAP:' + str(OUT / 'controls.map')
        else:
            x = replacements.get(Path(x).name, x)
        command.append(x)
    command += [OUT / 'submission.obj', OUT / 'native-analysis-test.obj',
                OUT / 'cpu-compile.obj']
    objects = [str(x).lower() for x in command if str(x).endswith('.obj')]
    assert len(objects) == len(set(objects)), 'duplicate explicit object'
    run('controls-link', command)


def run_controls():
    previous = next(r['command'] for r in reversed(history('carrier-copy-contract'))
                    if r['tag'] == 'controls-run' and r['exit'] == 0)
    selected = next(x.split('=', 1)[1] for x in previous if x.startswith('--gtest_filter='))
    selected += (':ExactGraphSpecialization.*:NativeReachability.*:NativePartition.*'
                 ':GraphVariants.FiniteExact*:GraphVariants.EmptyAndZero*')
    run('controls-run', [OUT / 'controls.exe', '--gtest_color=no',
                        '--gtest_filter=' + selected,
                        '--gtest_output=json:' + str(OUT / 'controls-results.json')])
    result = json.loads((OUT / 'controls-results.json').read_text())
    assert result['failures'] == 0 and result['errors'] == 0
    (OUT / 'summary.json').write_text(json.dumps({
        'tests': result['tests'], 'failures': result['failures'],
        'errors': result['errors'], 'filter': selected,
        'sdk_rebuilt': False, 'product_modified_by_runner': False}, indent=2) + '\n')


def context_only():
    compile_one(str((OUT / 'context_only.cc').relative_to(ROOT)), 'context-only', CPU)
    dumpbin = Path(CORE[0]).with_name('dumpbin.exe')
    run('context-symbols', [dumpbin, '/symbols', OUT / 'cpu-context.obj'])
    records = json.loads((OUT / 'commands.json').read_text())
    symbols = (OUT / records[-1]['stdout']).read_text()
    undefined = [line for line in symbols.splitlines() if 'UNDEF' in line]
    assert not any('batch' in line.lower() or '?compile@cpu@graph' in line
                   for line in undefined), 'Context object still references batch compile'
    (OUT / 'context-undefined-symbols.json').write_text(json.dumps(undefined, indent=2) + '\n')
    context_link()


def context_link():
    keep = {'cpu-codec.obj', 'native-provider.obj', 'cpu-torch.obj', 'operation.obj',
            'selector-baseline.obj', 'allocator.obj', 'native-baseline.obj',
            'ggml-provider.obj', 'cpu-region.obj', 'low-precision.obj', 'device.obj',
            'indexing.obj', 'aten-provider.obj', 'constant_artifact.obj',
            'execution_source.obj', 'native-batch.obj', 'batch-layout.obj'}
    command = [BASE[0]]
    for x in BASE[1:]:
        p = Path(x)
        if p.suffix == '.obj' and p.name not in keep:
            continue
        if p.name.lower() in {'gtest.lib', 'gtest_main.lib', 'hyle_graph_batch.lib'}:
            continue
        if x.upper().startswith(('/OUT:', '/MAP:')):
            continue
        command.append(x)
    command += [OUT / 'cpu-context.obj', OUT / 'context-only.obj',
                '/OUT:' + str(OUT / 'context-only.exe'),
                '/MAP:' + str(OUT / 'context-only.map'), '/VERBOSE:LIB']
    run('context-only-link', command)
    run('context-only-run', [OUT / 'context-only.exe'])


if __name__ == '__main__':
    {'compile': compile_all, 'link': link_controls, 'run': run_controls,
     'context': context_only, 'context-link': context_link}[sys.argv[1]]()
