#include "hyle/graph/cpu.h"
#include <cstdio>

int main() {
  auto context = hyle::graph::cpu::create_context();
  if (!context) {
    const auto message = context.error().message();
    std::fprintf(stderr, "%.*s\n", static_cast<int>(message.size()), message.data());
    return 1;
  }
  std::puts("default Graph CPU create_context PASS");
  return 0;
}
