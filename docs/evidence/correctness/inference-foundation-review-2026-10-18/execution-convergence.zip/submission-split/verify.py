from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
before = (OUT / 'before/src/graph/executable.cc').read_text(encoding='utf-8')
after = (ROOT / 'src/graph/executable.cc').read_text(encoding='utf-8')
submission = (ROOT / 'src/graph/submission.cc').read_text(encoding='utf-8')

def block(text, first, following):
    begin = text.index(first)
    end = text.index(following, begin)
    return text[begin:end]

checks = {}
for name, first, following in [
    ('aggregate', 'void merge_aggregate_terminal(', 'std::uint64_t hash_word('),
    ('retirement', 'void mark_invocation_terminal(', 'bool owns('),
    ('delegated_submit', 'Result<compute::Completion>\nsubmit_delegated_segment(',
        'Status validate_transfer_routes('),
    ('submission', 'Result<compute::Completion> Invocation::submit(compute::Queue &queue)',
        '\nResult<CompiledGraph> compile(const Graph &graph,')]:
    original = block(before, first, following)
    checks[name] = submission.count(original) == 1 and original not in after

hook = '#if defined(HYLE_TESTING)\nthread_local detail::AcceptedCompletionFn accepted_observation_hook = nullptr;\n#endif\n'
checks['testing_hook'] = submission.count(hook) == 1 and hook not in after
for name, first, following, old, new in [
    ('lane_helpers', 'bool shared_lane(', 'bool delegated_can_import_endpoint(',
     ('bool shared_lane(', 'delegated_step_index(const detail::PlanState'),
     ('bool detail::shared_lane(', 'detail::delegated_step_index(const detail::PlanState')),
    ('enqueue', 'Status\nenqueue_segment_steps(', 'bool segment_capture_compatible(',
     ('enqueue_segment_steps(detail::InvocationState',),
     ('detail::enqueue_segment_steps(detail::InvocationState',))]:
    original = block(before, first, following)
    expected = original
    for previous, replacement in zip(old, new):
        expected = expected.replace(previous, replacement, 1)
    checks[name] = submission.count(expected) == 1 and original not in after

# Recover the old executable by removing only the new private using-declarations,
# restoring the moved blocks, their related includes and the explicitly retired
# native_shape_signature. This checks all untouched source without compiling.
moved = [(block(before, first, following), first, following) for first, following in [
    ('void merge_aggregate_terminal(', 'std::uint64_t hash_word('),
    ('void mark_invocation_terminal(', 'bool owns('),
    ('bool shared_lane(', 'bool delegated_can_import_endpoint('),
    ('Result<compute::Completion>\nsubmit_delegated_segment(', 'Status validate_transfer_routes('),
    ('Status\nenqueue_segment_steps(', 'bool segment_capture_compatible('),
    ('Result<compute::Completion> Invocation::submit(compute::Queue &queue)', '\nResult<CompiledGraph> compile(const Graph &graph,'),
    ('Result<SpecializationSignature> detail::native_shape_signature(', 'Status detail::collect_effect_bindings(')]]
expected = before
for original, _, _ in moved:
    expected = expected.replace(original, '', 1)
expected = expected.replace(hook, '', 1)
for include in ['#include "hyle/graph/native_variants.h"\n',
                '#include "../compute/completion_internal.h"\n',
                '#include "hyle/compute/detail/completion_access.h"\n',
                '#include <mutex>\n']:
    expected = expected.replace(include, '', 1)
expected = expected.replace('namespace hyle::graph {\n', '''namespace hyle::graph {
using detail::delegated_step_index;
using detail::enqueue_segment_steps;
using detail::shared_lane;

''', 1)
checks['all_remaining_executable_unchanged'] = expected == after
assert all(checks.values()), checks
(OUT / 'source-checks.json').write_text(json.dumps(checks, indent=2) + '\n',
    encoding='utf-8', newline='\n')

files = ['src/graph/executable.cc', 'src/graph/submission.cc',
         'src/graph/submission_internal.h', 'src/graph/CMakeLists.txt']
identities = []
diff = []
for relative in files:
    source = ROOT / relative
    data = source.read_bytes()
    target = OUT / 'candidate' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    identities.append(dict(path=relative, bytes=len(data),
                           sha256=hashlib.sha256(data).hexdigest()))
    previous = OUT / 'before' / relative
    diff.extend(difflib.unified_diff(previous.read_text().splitlines(True) if previous.exists() else [],
        source.read_text().splitlines(True), fromfile='before/' + relative, tofile=relative))
(OUT / 'source-identities.json').write_text(json.dumps(identities, indent=2) + '\n',
    encoding='utf-8', newline='\n')
(OUT / 'source.diff').write_text(''.join(diff), encoding='utf-8', newline='\n')
print(json.dumps(checks))
