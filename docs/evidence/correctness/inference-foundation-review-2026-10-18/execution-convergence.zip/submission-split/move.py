from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
files = [Path('src/graph/executable.cc'), Path('src/graph/submission_internal.h'),
         Path('src/graph/CMakeLists.txt')]
for relative in files:
    target = OUT / 'before' / relative
    if target.exists():
        raise SystemExit('before snapshot already exists')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((ROOT / relative).read_bytes())

path = ROOT / files[0]
original = path.read_text(encoding='utf-8')
source = original
blocks = {}

def take(name, first, following):
    global source
    begin = source.index(first)
    end = source.index(following, begin)
    blocks[name] = source[begin:end]
    source = source[:begin] + source[end:]

hook = '#if defined(HYLE_TESTING)\nthread_local detail::AcceptedCompletionFn accepted_observation_hook = nullptr;\n#endif\n'
assert source.count(hook) == 1
blocks['hook'] = hook
source = source.replace(hook, '', 1)
take('aggregate', 'void merge_aggregate_terminal(', 'std::uint64_t hash_word(')
take('retirement', 'void mark_invocation_terminal(', 'bool owns(')
take('lane_helpers', 'bool shared_lane(', 'bool delegated_can_import_endpoint(')
take('delegated_submit', 'Result<compute::Completion>\nsubmit_delegated_segment(',
     'Status validate_transfer_routes(')
take('enqueue', 'Status\nenqueue_segment_steps(', 'bool segment_capture_compatible(')
take('submission', 'Result<compute::Completion> Invocation::submit(compute::Queue &queue)',
     '\nResult<CompiledGraph> compile(const Graph &graph,')

uses = ('using detail::delegated_step_index;\n'
        'using detail::enqueue_segment_steps;\n'
        'using detail::shared_lane;\n')
source = source.replace('namespace hyle::graph {\n',
    'namespace hyle::graph {\n' + uses + '\n', 1)
source = source.replace('#include "../compute/completion_internal.h"\n', '', 1)
source = source.replace('#include "hyle/compute/detail/completion_access.h"\n', '', 1)
source = source.replace('#include <mutex>\n', '', 1)

helpers = blocks['lane_helpers'].replace('bool shared_lane(', 'bool detail::shared_lane(', 1)
helpers = helpers.replace('delegated_step_index(const detail::PlanState',
                          'detail::delegated_step_index(const detail::PlanState', 1)
enqueue = blocks['enqueue'].replace('enqueue_segment_steps(detail::InvocationState',
                                    'detail::enqueue_segment_steps(detail::InvocationState', 1)
submission = '''#include "submission_internal.h"

#include <array>
#include <mutex>
#include <utility>

#include "../compute/completion_internal.h"
#include "../compute/provider_internal.h"
#include "hyle/compute/detail/completion_access.h"
#include "hyle/compute/transfer.h"
#include "hyle/core/assert.h"
#include "hyle/graph/detail/region_access.h"
#include "hyle/obs/trace.h"
#include "plan_state.h"

namespace hyle::graph {
''' + uses + '\nnamespace {\n\n' + blocks['hook'] + '\n' + blocks['aggregate'] + \
    blocks['retirement'] + blocks['delegated_submit'] + '} // namespace\n\n' + \
    helpers + enqueue + blocks['submission'] + '\n} // namespace hyle::graph\n'
new_path = ROOT / 'src/graph/submission.cc'
if new_path.exists():
    raise SystemExit('submission.cc already exists')
path.write_text(source, encoding='utf-8', newline='\n')
new_path.write_text(submission, encoding='utf-8', newline='\n')

header = ROOT / files[1]
text = header.read_text(encoding='utf-8')
declarations = '''struct InvocationState;
struct PlanState;
struct PlanSegment;

// Cold replay preparation and strict submission share these exact lane and
// command operations; capture records the same commands used by replay.
bool shared_lane(const PlanState &, ExecutionLaneId) noexcept;
Result<std::size_t> delegated_step_index(const PlanState &,
                                       const PlanSegment &) noexcept;
Status enqueue_segment_steps(InvocationState &, const PlanSegment &,
                             compute::detail::QueueSequence &) noexcept;
'''
assert text.count('struct InvocationState;\n') == 1
header.write_text(text.replace('struct InvocationState;\n', declarations, 1),
                  encoding='utf-8', newline='\n')

cmake = ROOT / files[2]
text = cmake.read_text(encoding='utf-8')
assert text.count('effect_order.cc executable.cc execution_source.cc') == 1
cmake.write_text(text.replace('effect_order.cc executable.cc execution_source.cc',
    'effect_order.cc executable.cc submission.cc execution_source.cc', 1),
    encoding='utf-8', newline='\n')

(OUT / 'moved-blocks.json').write_text(json.dumps({name: dict(bytes=len(text.encode()),
    sha256=hashlib.sha256(text.encode()).hexdigest(), lines=len(text.splitlines()))
    for name, text in blocks.items()}, indent=2) + '\n', encoding='utf-8', newline='\n')
