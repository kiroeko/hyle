param([switch]$Mac, [switch]$MoveRowController, [switch]$MoveRegionDiscovery, [switch]$UnifyGraphResources, [switch]$ReclaimNativeOutput, [switch]$ReclaimColdConstants, [switch]$ReclaimNativePorts, [switch]$ReclaimCanonicalConstants, [switch]$ReclaimNativeReplay, [switch]$ReclaimConstantReplicas, [switch]$ReclaimReadonlyPorts, [switch]$ReclaimCarrierCopy, [switch]$RetireNativeVariants, [switch]$ReclaimExecutionConvergence)
# Reclaim frozen probe images; retain source, logs, data, all objects and SDKs.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$prefix = $workspace.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if ($RetireNativeVariants) {
    $header = Join-Path $workspace 'include/hyle/graph/native_variants.h'
    $source = Join-Path $workspace 'tests/graph/native_variants_test.cc'
    $destination = Join-Path $workspace 'tests/graph/native_analysis_test.cc'
    $archive = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/execution-convergence/removed/native_variants.h'
    foreach ($path in @($header, $source, $destination, $archive)) {
        $resolved = [IO.Path]::GetFullPath($path)
        if (-not $resolved.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Native variants retirement outside workspace' }
        $ancestor = [IO.Path]::GetDirectoryName($resolved)
        while ($ancestor.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            if ((Test-Path -LiteralPath $ancestor) -and ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected native variants path link' }
            $ancestor = [IO.Path]::GetDirectoryName($ancestor)
        }
    }
    foreach ($entry in @(
        @{Path=$header;Bytes=4431;SHA='21254F48725B0BFDC23CE55E2022ECB7AA02F9678BAF521B64538D027121CEBF'},
        @{Path=$source;Bytes=13213;SHA='94CD56E2ED3C4870C654E10DA0A31F44970B4861687381F2BCFBDCBD96885FD8'}
    )) {
        $item = Get-Item -LiteralPath $entry.Path
        if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
            $item.Length -ne $entry.Bytes -or (Get-FileHash -LiteralPath $entry.Path -Algorithm SHA256).Hash -ne $entry.SHA) { throw 'Native variants source changed before retirement' }
    }
    if ((Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath $archive)) { throw 'Native variants retirement destination exists' }
    New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($archive)) -Force | Out-Null
    Copy-Item -LiteralPath $header -Destination $archive
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne '21254F48725B0BFDC23CE55E2022ECB7AA02F9678BAF521B64538D027121CEBF') { throw 'Retired native variants archive changed' }
    Move-Item -LiteralPath $source -Destination $destination
    Remove-Item -LiteralPath $header
    Write-Output 'Removed the obsolete native variants template; original header archived. Common specialization and native analysis tests retained.'
    return
}
if ($ReclaimCarrierCopy -or $ReclaimExecutionConvergence) {
    if ($ReclaimCarrierCopy -and $ReclaimExecutionConvergence) { throw 'Select one frozen probe cleanup' }
    $name = if ($ReclaimExecutionConvergence) { 'execution-convergence' } else { 'carrier-copy-contract' }
    $stage = [IO.Path]::GetFullPath((Join-Path $workspace ('.scratch/architecture-refactor-2026-10-18/' + $name)))
    $receipt = Get-Content -LiteralPath (Join-Path $stage 'archive-receipt.json') -Raw | ConvertFrom-Json
    $evidence = Join-Path $workspace ('docs/evidence/correctness/inference-foundation-review-2026-10-18/' + $name + '.zip')
    if ((Get-Item -LiteralPath $evidence).Length -ne $receipt.bytes -or
        (Get-FileHash -LiteralPath $evidence -Algorithm SHA256).Hash -ne $receipt.sha256) { throw 'Carrier copy evidence changed' }
    $ancestor = $stage
    while ($ancestor.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        if ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected carrier cleanup directory link' }
        $ancestor = [IO.Path]::GetDirectoryName($ancestor)
    }
    $zip = [IO.Compression.ZipFile]::OpenRead($evidence)
    try {
        foreach ($name in @('cleanup.json', 'cleanup-mac.json')) {
            $entry = $zip.GetEntry('windows/' + $name)
            if ($null -eq $entry) { throw 'Missing frozen carrier cleanup manifest' }
            $reader = [IO.StreamReader]::new($entry.Open())
            try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
            if ($frozen -cne [IO.File]::ReadAllText((Join-Path $stage $name))) { throw 'Carrier cleanup manifest changed' }
        }
    } finally { $zip.Dispose() }
    $plan = Get-Content -LiteralPath (Join-Path $stage 'cleanup.json') -Raw | ConvertFrom-Json
    if ($plan.root -ne $stage) { throw 'Unexpected carrier cleanup root' }
    $targets = @()
    foreach ($entry in @($plan.files) + @($plan.retained_stage_objects)) {
        $path = [IO.Path]::GetFullPath($entry.path)
        if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or
            [IO.Path]::GetDirectoryName($path) -ne $stage) { throw 'Carrier artifact outside exact stage' }
        $retained = [IO.Path]::GetExtension($path) -eq '.obj'
        if (-not $retained -and
            ([IO.Path]::GetExtension($path) -notin @('.exe', '.map', '.exp', '.lib') -or
             [IO.Path]::GetFileNameWithoutExtension($path) -notin @('controls', 'vulkan-tests', 'vulkan-consumer', 'context-only'))) {
            throw 'Unexpected carrier cleanup target'
        }
        if (-not (Test-Path -LiteralPath $path)) {
            if ($retained) { throw 'Missing retained carrier object' }
            continue
        }
        $item = Get-Item -LiteralPath $path
        if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
            $item.Length -ne $entry.bytes -or
            (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) { throw 'Carrier artifact identity changed' }
        if (-not $retained) { $targets += $item }
    }
    $freed = 0L
    foreach ($item in $targets) {
        $freed += $item.Length
        Remove-Item -LiteralPath $item.FullName
    }
    $localResult = @{files=$targets.Count;bytes=$freed;retained_objects=$plan.retained_stage_objects.Count;retained_source_logs_data_sdk=$true} | ConvertTo-Json -Compress
    [IO.File]::WriteAllText((Join-Path $stage 'cleanup-result.json'), $localResult)
    $localResult | Write-Output
    if ($Mac) {
        $encoded = [Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $stage 'cleanup-mac.json')))
        $remoteName = if ($ReclaimExecutionConvergence) { 'architecture-refactor-20261018-execution-convergence' } else { 'architecture-refactor-20261018-apple-carrier-copy' }
        $remoteScript = @'
import base64, hashlib, json
from pathlib import Path
plan = json.loads(base64.b64decode('__MANIFEST__'))
base = Path('/Users/kiro/hyle-scratch/compute-unified').resolve(strict=True)
root = base / '__ROOT_NAME__'
overlay = root / 'cpu-overlay'
assert root.parent == base and root.resolve(strict=True) == root and not root.is_symlink()
if plan.get('retained_cpu_overlay_objects'):
    assert overlay.resolve(strict=True) == overlay and not overlay.is_symlink()
assert plan['root'] == str(root)
targets = []
for row in plan['files']:
    path = Path(row['path'])
    assert path.parent == root and path.name in {'native-tests', 'native-tests.map', 'finite-consumer', 'finite-consumer.map'} and not path.is_symlink()
    if not path.exists():
        continue
    assert path.is_file() and path.resolve(strict=True).parent == root
    data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], str(path)
    if path.name in {'native-tests', 'finite-consumer'}:
        assert data[:4] in (bytes.fromhex('cffaedfe'), bytes.fromhex('feedfacf'))
    targets.append((path, len(data)))
retained_root = plan.get('retain', plan.get('retained_root_objects', []))
retained_overlay = plan.get('retained_cpu_overlay_objects', [])
for records, parent in ((retained_root, root), (retained_overlay, overlay)):
    for row in records:
        path = Path(row['path'])
        assert path.parent == parent and path.suffix == '.o' and not path.is_symlink()
        assert path.is_file() and path.resolve(strict=True).parent == parent
        data = path.read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], str(path)
for path, size in targets:
    path.unlink()
print(json.dumps({'files': len(targets), 'bytes': sum(size for path, size in targets),
    'retained_objects': len(retained_root) + len(retained_overlay),
    'retained_source_logs_data_sdk': True}))
'@
        $remoteResult = $remoteScript.Replace('__MANIFEST__', $encoded).Replace('__ROOT_NAME__', $remoteName) | & ssh -o BatchMode=yes -o ConnectTimeout=10 kiro@172.22.10.198 'python3 -'
        if ($LASTEXITCODE -ne 0) { throw 'Carrier copy Mac cleanup failed' }
        [IO.File]::WriteAllText((Join-Path $stage 'cleanup-mac-result.json'), ($remoteResult | Out-String))
        $remoteResult | Write-Output
    }
    return
}
if ($ReclaimReadonlyPorts) {
    if (-not $Mac) { throw 'Readonly port probe cleanup requires -Mac' }
    $stage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/apple-readonly-ports'
    $receipt = Get-Content -LiteralPath (Join-Path $stage 'archive.json') -Raw | ConvertFrom-Json
    $evidence = Join-Path $workspace 'docs/evidence/correctness/inference-foundation-review-2026-10-18/apple-readonly-ports.zip'
    if ((Get-FileHash -LiteralPath $evidence -Algorithm SHA256).Hash -ne $receipt.sha256) {
        throw 'Readonly port evidence changed'
    }
    $manifestPath = Join-Path $stage 'cleanup-mac.json'
    $zip = [IO.Compression.ZipFile]::OpenRead($evidence)
    try {
        $entry = $zip.GetEntry('stage/cleanup-mac.json')
        if ($null -eq $entry) { throw 'Missing frozen readonly port cleanup manifest' }
        $reader = [IO.StreamReader]::new($entry.Open())
        try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
        if ($frozen -cne [IO.File]::ReadAllText($manifestPath)) { throw 'Readonly cleanup manifest changed' }
    } finally { $zip.Dispose() }
    $encoded = [Convert]::ToBase64String([IO.File]::ReadAllBytes($manifestPath))
    $remoteScript = @'
import base64, hashlib, json
from pathlib import Path
plan = json.loads(base64.b64decode('__MANIFEST__'))
base = Path('/Users/kiro/hyle-scratch/compute-unified').resolve(strict=True)
root = base / 'architecture-refactor-20261018-apple-readonly-ports'
assert root.parent == base and root.resolve(strict=True) == root and not root.is_symlink()
assert plan['root'] == str(root)
targets = []
for row in plan['files']:
    path = Path(row['path'])
    assert path.parent == root and path.name in {'native-tests', 'native-tests.map'} and not path.is_symlink()
    if not path.exists():
        continue
    assert path.is_file() and path.resolve(strict=True).parent == root
    data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], str(path)
    if path.name == 'native-tests':
        assert data[:4] in (bytes.fromhex('cffaedfe'), bytes.fromhex('feedfacf'))
    targets.append((path, len(data)))
for row in plan['retain']:
    path = Path(row['path'])
    assert path.parent == root and path.suffix == '.o' and not path.is_symlink()
    assert path.is_file() and path.resolve(strict=True).parent == root
    data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], str(path)
for path, size in targets:
    path.unlink()
print(json.dumps({'files': len(targets), 'bytes': sum(size for path, size in targets),
    'retained_objects': len(plan['retain']), 'retained_source_logs_data_sdk': True}))
'@
    $remoteResult = $remoteScript.Replace('__MANIFEST__', $encoded) | & ssh -o BatchMode=yes -o ConnectTimeout=10 kiro@172.22.10.198 'python3 -'
    if ($LASTEXITCODE -ne 0) { throw 'Readonly probe cleanup failed' }
    [IO.File]::WriteAllText((Join-Path $stage 'cleanup-mac-result.json'), ($remoteResult | Out-String))
    $remoteResult | Write-Output
    return
}
if ($MoveRegionDiscovery) {
    $source = [IO.Path]::GetFullPath((Join-Path $workspace 'src/graph_ggml_shared/region_discovery.h'))
    $destination = [IO.Path]::GetFullPath((Join-Path $workspace 'src/graph/region_discovery.h'))
    foreach ($path in @($source, $destination)) {
        if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Discovery move outside workspace' }
        $ancestor = [IO.Path]::GetDirectoryName($path)
        while ($ancestor.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            if ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected discovery directory link' }
            $ancestor = [IO.Path]::GetDirectoryName($ancestor)
        }
    }
    $item = Get-Item -LiteralPath $source
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or
        (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne '27141B0A1BA7AB66CED38FEB97156A6339634D7AF65EA0829AC1AEF37ABC040A' -or
        (Test-Path -LiteralPath $destination)) { throw 'Discovery source or destination changed' }
    Move-Item -LiteralPath $source -Destination $destination
    Write-Output 'Moved shared graph-only discovery to its owning graph module.'
    return
}
if (([int][bool]$ReclaimNativeOutput + [int][bool]$ReclaimColdConstants + [int][bool]$ReclaimNativePorts + [int][bool]$ReclaimCanonicalConstants + [int][bool]$ReclaimNativeReplay + [int][bool]$ReclaimConstantReplicas) -gt 1) { throw 'Select one frozen probe cleanup' }
if ($ReclaimNativeOutput -or $ReclaimColdConstants -or $ReclaimNativePorts -or $ReclaimCanonicalConstants -or $ReclaimNativeReplay -or $ReclaimConstantReplicas) {
    $name = if ($ReclaimConstantReplicas) { 'constant-replicas' } elseif ($ReclaimNativeReplay) { 'native-replay-bridge' } elseif ($ReclaimCanonicalConstants) { 'canonical-constants' } elseif ($ReclaimNativePorts) { 'finite-native-migration' } elseif ($ReclaimColdConstants) { 'cold-constant-copy' } else { 'native-output-core' }
    $stage = Join-Path $workspace ('.scratch/architecture-refactor-2026-10-18/' + $name)
    $plan = Get-Content -LiteralPath (Join-Path $stage 'cleanup.json') -Raw | ConvertFrom-Json
    $receipt = Get-Content -LiteralPath (Join-Path $stage 'archive.json') -Raw | ConvertFrom-Json
    $evidence = [IO.Path]::GetFullPath((Join-Path $workspace $plan.evidence))
    if (-not $evidence.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or
        (Get-FileHash -LiteralPath $evidence -Algorithm SHA256).Hash -ne $receipt.sha256) {
        throw 'Frozen probe evidence is missing or changed'
    }
    $allowed = @($plan.allowed | ForEach-Object {
        [IO.Path]::GetFullPath((Join-Path $workspace $_))
    })
    $targets = @()
    foreach ($entry in $plan.files) {
        $path = [IO.Path]::GetFullPath((Join-Path $workspace $entry.path))
        if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or
            [IO.Path]::GetDirectoryName($path) -notin $allowed -or
            [IO.Path]::GetExtension($path) -notin @('.exe', '.map', '.exp', '.lib')) {
            throw 'Cleanup target is outside the exact probe directories'
        }
        $ancestor = [IO.Path]::GetDirectoryName($path)
        while ($ancestor.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            if ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw 'Unexpected cleanup directory link'
            }
            $ancestor = [IO.Path]::GetDirectoryName($ancestor)
        }
        if (-not (Test-Path -LiteralPath $path)) { continue }
        $item = Get-Item -LiteralPath $path
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.PSIsContainer -or
            $item.Length -ne $entry.bytes -or
            (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) {
            throw 'Frozen probe identity changed; no files removed'
        }
        $targets += $item
    }
    $bytes = 0L
    foreach ($item in $targets) {
        Remove-Item -LiteralPath $item.FullName
        $bytes += $item.Length
    }
    @{files=$targets.Count; bytes=$bytes; retained='source, logs, data, cached objects, SDKs'} |
        ConvertTo-Json -Compress | Write-Output
    if ($ReclaimConstantReplicas -and $Mac) {
        $manifestPath = Join-Path $stage 'cleanup-mac.json'
        $zip = [IO.Compression.ZipFile]::OpenRead($evidence)
        try {
            $entry = $zip.GetEntry('stages/constant-replicas/cleanup-mac.json')
            if ($null -eq $entry) { throw 'Missing frozen Mac replica cleanup manifest' }
            $reader = [IO.StreamReader]::new($entry.Open())
            try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
            if ($frozen -cne [IO.File]::ReadAllText($manifestPath)) { throw 'Mac replica cleanup manifest changed' }
        } finally { $zip.Dispose() }
        $encoded = [Convert]::ToBase64String([IO.File]::ReadAllBytes($manifestPath))
        $remoteScript = @'
import base64, hashlib, json
from pathlib import Path
plan = json.loads(base64.b64decode('__MANIFEST__'))
base = Path('/Users/kiro/hyle-scratch/compute-unified').resolve(strict=True)
roots = {base / name for name in (
    'architecture-refactor-20261018-apple-constant-replicas',
    'architecture-refactor-20261018-apple-cold-constants')}
assert set(map(str, roots)) == set(plan['roots'])
assert all(p.parent == base and p.resolve(strict=True) == p and not p.is_symlink() for p in roots)
targets = []
for record in plan['files']:
    path = Path(record['path'])
    assert path.parent in roots and path.suffix in {'', '.map'} and not path.is_symlink()
    if not path.exists():
        continue
    assert path.is_file() and path.resolve(strict=True).parent in roots
    data = path.read_bytes()
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256'], str(path)
    if path.suffix == '':
        assert data[:4] in (bytes.fromhex('cffaedfe'), bytes.fromhex('feedfacf')), str(path)
    targets.append((path, len(data)))
for record in plan['retain']:
    path = Path(record['path'])
    assert path.parent in roots and path.suffix == '.o' and not path.is_symlink()
    assert path.is_file() and path.resolve(strict=True).parent in roots
    data = path.read_bytes()
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256'], str(path)
for path, size in targets:
    path.unlink()
print(json.dumps({'files': len(targets), 'bytes': sum(size for path, size in targets),
    'retained_objects': len(plan['retain']), 'retained_source_logs_data_sdk': True}))
'@
        $remoteResult = $remoteScript.Replace('__MANIFEST__', $encoded) | & ssh -o BatchMode=yes -o ConnectTimeout=10 kiro@172.22.10.198 'python3 -'
        if ($LASTEXITCODE -ne 0) { throw 'Mac constant replica cleanup verification failed' }
        $remoteResult | Set-Content -LiteralPath (Join-Path $stage 'cleanup-mac-result.json') -Encoding utf8
        $remoteResult | Write-Output
    }
    if ($ReclaimNativeReplay -and $Mac) {
        $appleStage = Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/apple-discovery-spi'
        $macPlanPath = Join-Path $appleStage 'cleanup-candidates.json'
        $retainPath = Join-Path $appleStage 'retained-objects.json'
        # The exact manifests used below must be the ones frozen in evidence.
        $zip = [IO.Compression.ZipFile]::OpenRead($evidence)
        try {
            foreach ($entryName in @('cleanup-candidates.json', 'retained-objects.json')) {
                $entry = $zip.GetEntry('stages/apple-discovery-spi/' + $entryName)
                if ($null -eq $entry) { throw 'Missing frozen Mac cleanup manifest' }
                $reader = [IO.StreamReader]::new($entry.Open())
                try { $frozen = $reader.ReadToEnd() } finally { $reader.Dispose() }
                if ($frozen -cne [IO.File]::ReadAllText((Join-Path $appleStage $entryName))) {
                    throw 'Mac cleanup manifest changed after evidence was frozen'
                }
            }
        } finally { $zip.Dispose() }
        $encodedPlan = [Convert]::ToBase64String([IO.File]::ReadAllBytes($macPlanPath))
        $encodedRetain = [Convert]::ToBase64String([IO.File]::ReadAllBytes($retainPath))
        $remoteScript = @'
import base64, hashlib, json
from pathlib import Path
plan = json.loads(base64.b64decode('__PLAN__'))
retain = json.loads(base64.b64decode('__RETAIN__'))
root = Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-apple-discovery-spi')
base = Path('/Users/kiro/hyle-scratch/compute-unified').resolve(strict=True)
assert root.parent == base and root.resolve(strict=True) == root and not root.is_symlink()
assert plan['allowed_root'] == str(root)
targets = []
for record in plan['files']:
    path = Path(record['path'])
    assert path.parent == root and path.suffix in {'', '.map'} and not path.is_symlink()
    if not path.exists():
        continue
    assert path.is_file() and path.resolve(strict=True).parent == root
    data = path.read_bytes()
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256'], str(path)
    if path.suffix == '':
        assert data[:4] in (bytes.fromhex('cffaedfe'), bytes.fromhex('feedfacf')), str(path)
    targets.append((path, len(data)))
for record in retain['files']:
    path = Path(record['path'])
    assert path.parent == root and path.suffix == '.o' and not path.is_symlink()
    assert path.is_file() and path.resolve(strict=True).parent == root
    data = path.read_bytes()
    assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256'], str(path)
for path, size in targets:
    path.unlink()
print(json.dumps({'files': len(targets), 'bytes': sum(size for path, size in targets),
    'retained_objects': len(retain['files']), 'retained_source_logs_data_sdk': True}))
'@
        $remoteScript = $remoteScript.Replace('__PLAN__', $encodedPlan).Replace('__RETAIN__', $encodedRetain)
        $remoteResult = $remoteScript | & ssh -o BatchMode=yes -o ConnectTimeout=10 kiro@172.22.10.198 'python3 -'
        if ($LASTEXITCODE -ne 0) { throw 'Mac replay cleanup verification failed' }
        $remoteResult | Set-Content -LiteralPath (Join-Path $stage 'cleanup-mac-result.json') -Encoding utf8
        $remoteResult | Write-Output
    }
    return
}
if ($UnifyGraphResources) {
    $source = [IO.Path]::GetFullPath((Join-Path $workspace 'src/graph/leased_invocation.cc'))
    $destination = [IO.Path]::GetFullPath((Join-Path $workspace 'src/graph/resources.cc'))
    $header = [IO.Path]::GetFullPath((Join-Path $workspace 'include/hyle/graph/leased_invocation.h'))
    $archive = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/architecture-refactor-2026-10-18/invocation-resources/removed-apis/leased_invocation.h'))
    foreach ($path in @($source, $destination, $header, $archive)) {
        if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Graph migration outside workspace' }
        $ancestor = [IO.Path]::GetDirectoryName($path)
        while ($ancestor.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            if ((Test-Path -LiteralPath $ancestor) -and ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected migration directory link' }
            $ancestor = [IO.Path]::GetDirectoryName($ancestor)
        }
    }
    foreach ($entry in @(
        @{Path=$source;Bytes=38169;SHA='EE5E7498A920B96ADC3C3BBC3753FCFF38DF12108CDFC84AF407C6B1D4752AB1'},
        @{Path=$header;Bytes=4694;SHA='D64ADB7098C5C92740540625C9DCC002F69C68413F5C0F93C59580F9B40AEDF1'}
    )) {
        $item = Get-Item -LiteralPath $entry.Path
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $entry.Bytes -or
            (Get-FileHash -LiteralPath $entry.Path -Algorithm SHA256).Hash -ne $entry.SHA) { throw 'Graph API source changed; review before migration' }
    }
    if ((Test-Path -LiteralPath $destination) -or (Test-Path -LiteralPath $archive)) { throw 'Graph migration destination already exists' }
    New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($archive)) -Force | Out-Null
    Copy-Item -LiteralPath $header -Destination $archive
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash -ne 'D64ADB7098C5C92740540625C9DCC002F69C68413F5C0F93C59580F9B40AEDF1') { throw 'Removed API archive identity mismatch' }
    Move-Item -LiteralPath $source -Destination $destination
    Remove-Item -LiteralPath $header
    Write-Output 'Unified Graph resource source renamed; replaced public API removed. Historical header preserved within workspace.'
    return
}
if ($MoveRowController) {
    $source = (Resolve-Path -LiteralPath (Join-Path $workspace 'src/compute_ggml_runtime/row_cache_native_controller.h')).Path
    $destination = [IO.Path]::GetFullPath((Join-Path $workspace 'src/compute_batch/row_cache_native_controller.h'))
    foreach ($path in @($source, $destination)) {
        if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Source move outside workspace' }
    }
    $destinationParent = (Resolve-Path -LiteralPath ([IO.Path]::GetDirectoryName($destination))).Path
    if ((Get-Item -LiteralPath $destinationParent).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected destination link' }
    if (Test-Path -LiteralPath $destination) { throw 'Source destination already exists' }
    $item = Get-Item -LiteralPath $source
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint -or $item.Length -ne 8923 -or
        (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne '7B05BE4D10455F6528C4A0784F4B444A82293CF90209AED624481EBC92D58455') {
        throw 'Source controller changed; review before moving'
    }
    Move-Item -LiteralPath $source -Destination $destination
    Write-Output 'Moved typed row/page controller to its owning compute_batch module; no source deleted.'
    return
}
$stage = Join-Path $workspace '.scratch/inference-foundation-review-2026-10-18'
$plan = Get-Content -LiteralPath (Join-Path $stage 'archive-cleanup/review-binaries.json') -Raw | ConvertFrom-Json
$allowed = @(
    (Join-Path $stage 'row-cache-indexer-native'),
    (Join-Path $stage 'cpu-grouped-expert-reuse'),
    (Join-Path $stage 'paged-indexer'),
    (Join-Path $stage 'cuda-row-cache-padded'),
    (Join-Path $stage 'cuda-row-cache-indexer'),
    (Join-Path $stage 'packed-indexer-cpu')
) | ForEach-Object { (Resolve-Path -LiteralPath $_).Path }
foreach ($directory in $allowed) {
    if (-not $directory.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Stage outside workspace' }
    if ((Get-Item -LiteralPath $directory).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected stage link' }
}
foreach ($archive in $plan.archives) {
    $path = Join-Path $workspace ('docs/evidence/correctness/inference-foundation-review-2026-10-18/' + $archive.name)
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $archive.sha256) { throw 'Archive identity mismatch' }
}
foreach ($entry in $plan.retain) {
    $path = [IO.Path]::GetFullPath($entry.path)
    if ([IO.Path]::GetDirectoryName($path) -notin $allowed -or [IO.Path]::GetExtension($path) -notin @('.obj','.o')) { throw 'Unexpected retained object' }
    $item = Get-Item -LiteralPath $path
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint -or $item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Changed retained object: $path" }
}
$targets = foreach ($entry in $plan.files) {
    $path = [IO.Path]::GetFullPath($entry.path)
    $parent = [IO.Path]::GetDirectoryName($path)
    $extension = [IO.Path]::GetExtension($path).ToLowerInvariant()
    if ($parent -notin $allowed -or $extension -notin @('.exe','.lib','.exp','.pdb')) { throw "Unexpected target: $path" }
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target outside workspace' }
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        $item = Get-Item -LiteralPath $path
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Unexpected file link: $path" }
        if ($item.Length -ne $entry.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $entry.sha256) { throw "Changed artifact: $path" }
        $item
    }
}
$freed = 0L
foreach ($item in $targets) {
    $freed += $item.Length
    Remove-Item -LiteralPath $item.FullName
}
Write-Output "Removed $($targets.Count) frozen probe binaries: $freed bytes. All objects, SDKs and source/results retained."
if ($Mac) {
    $manifestPath = Join-Path $stage 'archive-cleanup/mac-review-binaries.json'
    $macPlan = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    foreach ($archive in $macPlan.archives) {
        $path = Join-Path $workspace ('docs/evidence/correctness/inference-foundation-review-2026-10-18/' + $archive.name)
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $archive.sha256) { throw 'Mac archive identity mismatch' }
    }
    $encoded = [Convert]::ToBase64String([IO.File]::ReadAllBytes($manifestPath))
    $remoteScript = @'
import base64, hashlib, json
from pathlib import Path
plan = json.loads(base64.b64decode('__MANIFEST__'))
base = Path('/Users/kiro/hyle-scratch/compute-unified').resolve(strict=True)
roots = {Path(p).resolve(strict=True) for p in plan['roots']}
assert all(p.parent == base for p in roots)
targets = []
for record in plan['files']:
    path = Path(record['path'])
    assert path.parent.resolve(strict=True) in roots
    assert path.suffix == '' and not path.is_symlink()
    if not path.exists():
        continue
    assert path.is_file() and path.resolve(strict=True).parent in roots
    assert path.stat().st_size == record['bytes'], str(path)
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == record['sha256'], str(path)
    assert data[:4] in (bytes.fromhex('cffaedfe'), bytes.fromhex('feedfacf')), str(path)
    targets.append((path, record['bytes']))
for record in plan['retain']:
    path = Path(record['path'])
    assert path.is_file() and path.stat().st_size == record['bytes'], str(path)
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256'], str(path)
for path, size in targets:
    path.unlink()
print(json.dumps({'removed': len(targets), 'bytes': sum(size for path,size in targets),
    'retained_product_and_test_objects': len(plan['retain']), 'retained_source_logs_maps_sdk': True}))
'@
    $remoteScript.Replace('__MANIFEST__', $encoded) | & ssh -o BatchMode=yes -o ConnectTimeout=10 kiro@172.22.10.198 'python3 -'
    if ($LASTEXITCODE -ne 0) { throw 'Mac cleanup verification failed' }
}
