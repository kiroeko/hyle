from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261018-execution-convergence'
spec = importlib.util.spec_from_file_location('transport',
    OUT.parents[1] / 'apple-readonly-ports/stage.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.ROOT, b.OUT, b.REMOTE = ROOT, OUT, REMOTE
b.SEEDS = ['src/graph/executable.cc', 'src/graph/submission.cc',
           'src/graph_route_cpu/cpu_context.cc', 'src/graph_route_cpu/compile.cc',
           'tests/graph/native_analysis_test.cc', 'tests/graph/route_symmetry_apple.cc']
ssh = b.ssh
if __name__ == '__main__':
    b.main()
