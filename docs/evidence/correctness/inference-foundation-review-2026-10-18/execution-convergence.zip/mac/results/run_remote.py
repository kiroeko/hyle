from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'architecture-refactor-20261018-apple-carrier-copy'
HISTORY = json.loads((OLD / 'commands.json').read_text())
CPU = json.loads((OLD / 'cpu-overlay/commands.json').read_text())
RECORDS = json.loads((ROOT / 'commands.json').read_text()) if (ROOT / 'commands.json').exists() else []

def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def run(tag, command):
    command = list(map(str, command))
    stem = f'{len(RECORDS) + 1:02d}-{tag}'
    started = time.monotonic()
    with (ROOT / (stem + '.stdout.log')).open('wb') as out, (ROOT / (stem + '.stderr.log')).open('wb') as err:
        process = subprocess.Popen(command, cwd=ROOT, stdout=out, stderr=err)
        (ROOT / 'live.json').write_text(json.dumps(dict(tag=tag, pid=process.pid)) + '\n')
        code = process.wait()
    RECORDS.append(dict(tag=tag, command=command, exit=code,
                        seconds=time.monotonic()-started, stdout=stem+'.stdout.log', stderr=stem+'.stderr.log'))
    (ROOT / 'commands.json').write_text(json.dumps(RECORDS, indent=2)+'\n')
    (ROOT / 'live.json').write_text(json.dumps(dict(terminal=True, tag=tag, exit=code))+'\n')
    print(stem, code, flush=True)
    if code:
        print((ROOT / (stem+'.stdout.log')).read_text(errors='replace')[-3000:])
        print((ROOT / (stem+'.stderr.log')).read_text(errors='replace')[-6000:])
        raise SystemExit(code)

def command_for(records, tag):
    return next(row['command'] for row in reversed(records) if row['tag']==tag and row['exit']==0)

def compile_source(source, name, command):
    command = command[:command.index('-c')]
    command[1:1] = ['-I'+str(ROOT/'include'), '-I'+str(ROOT),
                    '-I'+str(ROOT/'src/graph'), '-I'+str(ROOT/'src/compute')]
    run(name+'-compile', command+['-c', ROOT/source, '-o', ROOT/(name+'.o')])

def main():
    assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip() == 'Mac16,12'
    (ROOT/'machine.txt').write_text(subprocess.check_output(
        ['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)
        +subprocess.check_output(['xcrun','clang++','--version'],text=True))
    for row in json.loads((ROOT/'staged-sources.json').read_text()):
        assert identity(ROOT/row['path'])['sha256']==row['sha256'],row['path']
    native_link = command_for(HISTORY,'native-tests-link')
    old_identities = json.loads((OLD/'native-tests-identities.json').read_text())
    replaced = {str(OLD/'executable.o'),str(OLD/'cpu-overlay/graph-context.o')}
    retained = []
    for row in old_identities:
        path=Path(row['path'])
        if path.suffix not in {'.o','.a','.dylib'} or str(path) in replaced:
            continue
        assert identity(path)['sha256']==row['sha256'],str(path)
        retained.append(row)
    (ROOT/'retained-identities.json').write_text(json.dumps(retained,indent=2)+'\n')
    metal=(OLD/'mlx.metallib').resolve(strict=True)
    if not (ROOT/'mlx.metallib').exists(): (ROOT/'mlx.metallib').symlink_to(metal)
    product=command_for(HISTORY,'executable-compile')
    test=command_for(HISTORY,'mixed-test-compile')
    cpu=next(row['command'] for row in reversed(CPU)
             if row['exit']==0 and any(str(arg).endswith('src/graph_route_cpu/cpu_context.cc') for arg in row['command']))
    source_list=[('src/graph/executable.cc','executable',product),
        ('src/graph/submission.cc','submission',product),
        ('src/graph_route_cpu/cpu_context.cc','graph-context',cpu),
        ('src/graph_route_cpu/compile.cc','cpu-compile',cpu),
        ('tests/graph/native_analysis_test.cc','analysis-test',test),
        ('tests/graph/route_symmetry_apple.cc','finite-consumer',test)]
    for source,name,flags in source_list:
        if '--link-only' not in sys.argv:
            compile_source(source,name,flags)
        assert (ROOT/(name+'.o')).is_file(),name
    command=[]
    skip=False
    for arg in native_link:
        if skip: skip=False;continue
        if arg=='-o':
            command+=['-o',str(ROOT/'native-tests')];skip=True;continue
        if arg.startswith('-Wl,-map,'): arg='-Wl,-map,'+str(ROOT/'native-tests.map')
        if arg==str(OLD/'executable.o'): arg=str(ROOT/'executable.o')
        if arg==str(OLD/'cpu-overlay/graph-context.o'): arg=str(ROOT/'graph-context.o')
        command.append(arg)
    command[1:1]=[str(ROOT/(name+'.o')) for name in ('submission','cpu-compile','analysis-test')]
    run('native-tests-link',command)
    (ROOT/'native-tests-identities.json').write_text(json.dumps(
        [identity(p) for p in command if str(p).endswith(('.o','.a','.dylib'))]
        +[identity(ROOT/'native-tests'),identity(ROOT/'native-tests.map')],indent=2)+'\n')
    run('native-tests',[ROOT/'native-tests','--gtest_filter=AppleNativeRegion.*:AppleLateInput.*:AppleMixedRegion.*:ExactGraphSpecialization.*:NativeReachability.*:NativePartition.*',
        '--gtest_color=no','--gtest_output=json:'+str(ROOT/'test-results.json')])
    consumer=[]
    skip=False
    test_objects={str(OLD/(name+'.o')) for name in ('test','late-test','mixed-test')}
    test_objects.add(str(ROOT/'analysis-test.o'))
    for arg in command:
        if skip: skip=False;continue
        if arg in test_objects: continue
        if arg=='-o': consumer+=['-o',str(ROOT/'finite-consumer')];skip=True;continue
        if arg.startswith('-Wl,-map,'): arg='-Wl,-map,'+str(ROOT/'finite-consumer.map')
        consumer.append(arg)
    consumer[1:1]=[str(ROOT/'finite-consumer.o')]
    run('finite-consumer-link',consumer)
    run('finite-consumer',[ROOT/'finite-consumer'])
    (ROOT/'final-source-identities.json').write_text(json.dumps(
        [identity(ROOT/source) for source,name,flags in source_list],indent=2)+'\n')

if __name__=='__main__': main()
