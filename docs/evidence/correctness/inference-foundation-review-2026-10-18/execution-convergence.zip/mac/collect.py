from pathlib import Path
import io
import json
import tarfile
import stage

code = '''from pathlib import Path
import hashlib,io,json,sys,tarfile
r=Path('''+repr(stage.REMOTE)+''')
def identity(p):
 data=p.read_bytes()
 return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
tests=json.loads((r/'test-results.json').read_text())
assert tests['tests']==22 and tests['failures']==0 and tests['errors']==0,tests
commands=json.loads((r/'commands.json').read_text())
assert commands[-1]['tag']=='finite-consumer' and commands[-1]['exit']==0
plan=dict(root=str(r),files=[identity(r/name) for name in (
 'native-tests','native-tests.map','finite-consumer','finite-consumer.map')],
 retain=[identity(p) for p in sorted(r.glob('*.o'))])
assert len(plan['retain'])==6
(r/'cleanup-mac.json').write_text(json.dumps(plan,indent=2)+'\\n')
out=io.BytesIO()
with tarfile.open(fileobj=out,mode='w:gz') as a:
 for p in sorted(r.iterdir()):
  if p.is_file() and not p.is_symlink() and p.suffix in {'.json','.log','.txt','.py'}:
   a.add(p,arcname=p.name)
sys.stdout.buffer.write(out.getvalue())
'''
data=stage.ssh(code)
(stage.OUT/'mac-results.tar.gz').write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as a:
    assert all(m.isfile() and '/' not in m.name and '..' not in m.name for m in a.getmembers())
    a.extractall(stage.OUT/'results', filter='data')
tests=json.loads((stage.OUT/'results/test-results.json').read_text())
print(json.dumps(dict(tests=tests['tests'],failures=tests['failures'],bytes=len(data),
                     consumer_exit=0,retained_objects=6)))
