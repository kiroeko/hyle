#!/bin/bash
set -euo pipefail
task=/Users/kiro/hyle-m1a
export PATH=/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/Users/kiro/hyle-verify-tools/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 TRACY_ONLY_LOCALHOST=1
export HYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1
tar -xzf "$task/product-worktree.tar.gz" -C "$task/source"
cmake -S "$task/source" -B "$task/native" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON \
  -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_WERROR=ON \
  -DHYLE_DEV_FACTORS=graph_route_apple,compute_provider_ggml_metal,compute_ops \
  -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=ON \
  -DHYLE_COMPUTE_VULKAN=OFF -DHYLE_COMPUTE_ONEDNN=OFF \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 > "$task/logs/route-configure.log" 2>&1
cmake --build "$task/native" --parallel 2 --target hyle_compute_route_apple_tests \
  hyle_graph_route_apple_tests hyle_compute_provider_ggml_metal_tests hyle_compute_ops_tests \
  > "$task/logs/route-build.log" 2>&1
ctest --test-dir "$task/native" -L '^(compute_route_apple|graph_route_apple|compute_provider_ggml_metal|compute_ops)$' \
  --output-on-failure --no-tests=error --timeout 360 > "$task/logs/route-tests.log" 2>&1
cat "$task/logs/route-tests.log"
