#!/bin/bash
set -euo pipefail
task=/root/hyle-m1a
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
export CMAKE_BUILD_PARALLEL_LEVEL=2 CTEST_INTERACTIVE_DEBUG_MODE=0 TRACY_ONLY_LOCALHOST=1
export HYLE_DEP_SOURCE_CACHE=/root/.cache/hyle/dependencies/v1
mkdir -p "$task/source" "$task/logs"
tar -xzf "$task/product-worktree.tar.gz" -C "$task/source"
cmake -S "$task/source" -B "$task/native" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=/usr/bin/g++-14 \
  -DHYLE_DEV_FACTORS=compute_ggml_runtime,compute_ops,graph_route_apple,compute_provider_ggml_metal \
  -DHYLE_STATIC=ON -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF \
  -DHYLE_WERROR=ON -DHYLE_SANITIZER=ubsan -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
  -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF \
  -DHYLE_COMPUTE_VULKAN=OFF -DHYLE_COMPUTE_ONEDNN=OFF \
  > "$task/logs/configure.log" 2>&1
cmake --build "$task/native" --parallel 2 --target hyle_compute_ggml_runtime_tests \
  hyle_compute_ops_tests > "$task/logs/build.log" 2>&1
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 ctest --test-dir "$task/native" \
  -L '^(compute_ggml_runtime|compute_ops|compute_route_apple|graph_route_apple)$' \
  --no-tests=error --output-on-failure --timeout 120 > "$task/logs/tests.log" 2>&1
cp "$task/native/CMakeCache.txt" "$task/logs/CMakeCache.txt"
cp "$task/native/compile_commands.json" "$task/logs/compile-commands.json"
cp "$task/native/Testing/Temporary/LastTest.log" "$task/logs/LastTest.log"
cat "$task/logs/tests.log"
