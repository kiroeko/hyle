"""Prepare local source-derived Qwen text inputs; no candidate model mathematics.

The C++ consumer reads the original checkpoint itself. This script only checks
its identity, writes tensor offsets, and invokes the installed local tokenizer.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[3]

if __package__:
    from . import geometry
else:
    import geometry


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            result.update(chunk)
    return result.hexdigest()


ROLE_SIZES = {"BF16": 2, "F16": 2, "F32": 4, "I32": 4, "I64": 8, "U8": 1, "F8_E4M3": 1}


def ct_symmetric_groups(roles: dict[str, dict]) -> dict[str, dict]:
    """Infer original CT group geometry; neither inspect values nor decode weights."""
    bases = {name[:-14] for name in roles if name.endswith(".weight_packed")}
    bases.update(name[:-13] for name in roles if name.endswith(".weight_shape"))
    result = {}
    for base in sorted(bases):
        names = [base + suffix for suffix in (".weight_packed", ".weight_scale", ".weight_shape")]
        if any(name not in roles for name in names):
            raise ValueError(f"incomplete original CT symmetric role group: {base}")
        codes, scales, shape = (roles[name] for name in names)
        if codes["dtype"] != "I32" or len(codes["shape"]) != 2 or any(type(v) is not int or v <= 0 for v in codes["shape"]):
            raise ValueError(f"original CT packed layout differs: {base}")
        n, packed_k = codes["shape"]
        k = packed_k * 8
        if k > (1 << 63) - 1 or scales["dtype"] not in ("BF16", "F16", "F32") or len(scales["shape"]) != 2:
            raise ValueError(f"original CT scale geometry differs: {base}")
        scale_n, groups = scales["shape"]
        if type(scale_n) is not int or type(groups) is not int or scale_n != n or groups <= 0 or k % groups or k // groups > (1 << 32) - 1:
            raise ValueError(f"original CT scale group geometry differs: {base}")
        if shape["dtype"] != "I64" or shape["shape"] != [2]:
            raise ValueError(f"original CT shape descriptor differs: {base}")
        if any(base + suffix in roles for suffix in (".weight", ".qweight", ".qzeros", ".scales", ".g_idx", ".input_scale", ".weight_scale_2")):
            raise ValueError(f"ambiguous original CT projection storage: {base}")
        result[base] = dict(logical_shape=[n, k], group_size=k // groups, scale_dtype=scales["dtype"])
    return result


def validate_ct_shape_values(raw: bytes, geometry: dict, name: str) -> None:
    if len(raw) != 16 or list(struct.unpack("<qq", raw)) != geometry["logical_shape"]:
        raise ValueError(f"original CT weight_shape values differ: {name}")


def logical_roles(names) -> set[str]:
    auxiliary = (".qzeros", ".scales", ".g_idx", ".input_scale", ".weight_scale", ".weight_scale_2", ".weight_scale_inv", ".weight_shape")
    result = set()
    for name in names:
        if name.endswith(auxiliary):
            continue
        logical = name[:-8] + ".weight" if name.endswith(".qweight") else name[:-14] + ".weight" if name.endswith(".weight_packed") else name
        if logical in result:
            raise ValueError(f"ambiguous original logical projection: {logical}")
        result.add(logical)
    return result


def validate_role_geometry(roles: dict[str, dict], model_geometry: dict) -> None:
    expected = geometry.role_shapes(model_geometry)
    if logical_roles(roles) != set(expected):
        raise ValueError("complete original text/MTP logical role inventory differs from source geometry")
    for name, shape in expected.items():
        if name in roles:
            row = roles[name]
            actual = list(row['shape'])
            if row['dtype'] == 'U8' and len(actual) == 2 and name[:-7]+'.weight_scale_2' in roles:
                actual[1] *= 2  # Original packed two-nibble NVFP4 storage.
        elif name[:-7]+'.qweight' in roles:
            row = roles[name[:-7]+'.qweight']
            if row['dtype'] != 'I32' or len(row['shape']) != 2:
                raise ValueError('invalid original GPTQ projection axes: '+name)
            actual = [row['shape'][1], row['shape'][0]*8]
        else:
            row = roles[name[:-7]+'.weight_packed']
            if row['dtype'] != 'I32' or len(row['shape']) != 2:
                raise ValueError('invalid original CT projection axes: '+name)
            actual = [row['shape'][0], row['shape'][1]*8]
        if actual != list(shape):
            raise ValueError('original role shape differs from source geometry: '+name)


def _read_role_source(role: dict) -> tuple[Path, bytes | None, str]:
    """Read one borrowed range once; retain only16-byte CT shape values."""
    name, count, offset = role["name"], role["bytes"], role["offset"]
    source = (ROOT / role["path"]).resolve()
    if type(offset) is not int or offset < 0 or offset + count > source.stat().st_size:
        raise ValueError(f"short original role source: {name}")
    received, remaining = hashlib.sha256(), count
    shape_value = bytearray() if name.endswith(".weight_shape") else None
    with source.open("rb") as stream:
        stream.seek(offset)
        while remaining:
            chunk = stream.read(min(1024 * 1024, remaining))
            if not chunk:
                raise ValueError(f"short original role read: {name}")
            received.update(chunk)
            if shape_value is not None:
                shape_value.extend(chunk)
            remaining -= len(chunk)
    if any(ch in source.as_posix() for ch in "\r\n\0"):
        raise ValueError("role file path contains an unsupported control character")
    return source, bytes(shape_value) if shape_value is not None else None, received.hexdigest()


def verify_role_source(role: dict) -> tuple[Path, bytes | None]:
    source, values, sha = _read_role_source(role)
    if sha != role["sha256"]:
        raise ValueError(f"original role SHA differs: {role['name']}")
    return source, values


def prepare_role_files(path: Path, mtp: bool, config: dict) -> tuple[list[str], dict]:
    """Bind original cached physical roles without copying their storage."""
    original = json.loads(path.read_bytes())
    if not original.get("complete") or not original.get("repository") or len(original.get("revision", "")) != 40:
        raise ValueError("role source requires a complete fixed repository/revision record")
    return _prepare_role_records(original, mtp, config, verify_role_source)


def _prepare_role_records(original, mtp, config, authenticate):
    model_geometry = geometry.from_hf(config)
    if mtp and not model_geometry['mtp_layers']:
        raise ValueError('source geometry has no NextN layer')
    all_roles = {}
    for role in original["roles"]:
        name, dtype, shape = role["name"], role["dtype"], role["shape"]
        if (not name.startswith(("model.language_model.", "mtp.")) and not name.startswith("lm_head.")) or name in all_roles:
            raise ValueError("role source contains a duplicate or non-text role")
        if dtype not in ROLE_SIZES or len(shape) > 3:
            raise ValueError(f"unsupported original role dtype/rank: {name}")
        count = ROLE_SIZES[dtype]
        for dimension in shape:
            if type(dimension) is not int or dimension <= 0:
                raise ValueError(f"invalid original role shape: {name}")
            count *= dimension
            if count > (1 << 64) - 1:
                raise ValueError(f"original role byte extent overflows: {name}")
        if type(role["bytes"]) is not int or count != role["bytes"]:
            raise ValueError(f"original role byte extent differs: {name}")
        all_roles[name] = role
    validate_role_geometry(all_roles, model_geometry)
    ct_groups = ct_symmetric_groups(all_roles)
    checked_shapes = {}
    for base, group_geometry in ct_groups.items():
        name = base + ".weight_shape"
        source, raw = authenticate(all_roles[name])
        validate_ct_shape_values(raw, group_geometry, name)
        checked_shapes[name] = source
    lines, identities = [], []
    for role in original["roles"]:
        name, dtype, shape = role["name"], role["dtype"], role["shape"]
        count, offset = role["bytes"], role["offset"]
        source = checked_shapes[name] if name in checked_shapes else authenticate(role)[0]
        filename = source.as_posix()
        quoted = '"' + filename.replace('\\', '\\\\').replace('"', '\\"') + '"'
        lines.append("\t".join((name, dtype, str(len(shape)), *(str(d) for d in shape),
                                 quoted, str(offset), str(count))))
        identities.append({key: role[key] for key in ("name", "dtype", "shape", "bytes", "sha256")})
    identity = dict(repository=original["repository"], revision=original["revision"],
                    geometry=model_geometry, roles=sorted(identities, key=lambda item: item["name"]))
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    chosen = [item for item in identities if mtp or not item['name'].startswith('mtp.')]
    return ["HYLE_QWEN_ROLE_FILES_V2", fingerprint, geometry.line(model_geometry), *sorted(lines)], dict(
        source_id=fingerprint, source_repository=original["repository"], source_revision=original["revision"],
        geometry=model_geometry, metadata_tensor_count=len(lines),
        physical_roles=len(chosen), selected_tensor_count=len(chosen),
        selected_weight_bytes=sum(item["bytes"] for item in chosen),
        text_weight_bytes=sum(item["bytes"] for item in identities if not item["name"].startswith("mtp.")),
        mtp_weight_bytes=sum(item["bytes"] for item in identities if item["name"].startswith("mtp.")),
        original_role_records=identity["roles"], storage="borrowed original cached files/ranges; no copied checkpoint")


def prepare_safetensors(model: Path, mtp: bool, config: dict) -> tuple[list[str], dict]:
    """Index complete local text roles, hash only their original ranges, no copies."""
    model = model.resolve()
    index = model / 'model.safetensors.index.json'
    if index.exists():
        mapping = json.loads(index.read_bytes()).get('weight_map')
        if not isinstance(mapping, dict) or not mapping:
            raise ValueError('invalid local safetensors index')
        shard_names = sorted({filename for name,filename in mapping.items()
                              if name.startswith(('model.language_model.','mtp.','lm_head.'))})
    else:
        mapping, shard_names = None, ['model.safetensors']
    roles, seen = [], set()
    for filename in shard_names:
        if not isinstance(filename,str) or Path(filename).is_absolute() or '..' in Path(filename).parts:
            raise ValueError('unsafe local safetensors shard path')
        shard = (model / filename).resolve()
        if not shard.is_relative_to(model):
            raise ValueError('local safetensors shard escapes model directory')
        size = shard.stat().st_size
        with shard.open('rb') as stream:
            first = stream.read(8)
            if len(first) != 8:
                raise ValueError('short safetensors preamble')
            length = struct.unpack('<Q',first)[0]
            if length > size-8 or length > 64*1024*1024:
                raise ValueError('invalid safetensors header extent')
            header = json.loads(stream.read(length))
        for name,row in sorted(header.items()):
            if not name.startswith(('model.language_model.','mtp.','lm_head.')):
                continue
            if name in seen or (mapping is not None and mapping.get(name) != filename):
                raise ValueError('duplicate or misplaced local safetensors role: '+name)
            seen.add(name)
            begin,end = row['data_offsets']
            if type(begin) is not int or type(end) is not int or not 0 <= begin < end <= size-8-length:
                raise ValueError('local role exceeds original safetensors shard: '+name)
            roles.append(dict(name=name,dtype=row['dtype'],shape=row['shape'],path=str(shard),
                              offset=8+length+begin,bytes=end-begin))
    original = dict(repository='local:'+model.as_posix(), revision=None, roles=roles)

    def discover(role):
        source,values,sha = _read_role_source(role)
        role['sha256'] = sha
        return source,values

    return _prepare_role_records(original,mtp,config,discover)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prompt", default="Please calculate 2 + 3. Answer briefly.")
    parser.add_argument("--continuation", default="", help="optional raw text cached continuation")
    parser.add_argument("--mtp", action="store_true",
                        help="select the source NextN layer; does not execute MTP")
    weight_source = parser.add_mutually_exclusive_group()
    weight_source.add_argument("--role-files", type=Path,
                        help="prepared fixed-source text role record; borrow original quantized files/ranges")
    weight_source.add_argument("--gguf-role-files", type=Path,
                        help="complete acquired GGUF payload-source record; preserve original codec and converted parameters")
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("output directory must be new")
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                      HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false")
    config_path = args.model / "config.json"
    config = json.loads(config_path.read_bytes())
    records = [dict(path="config.json", size_bytes=config_path.stat().st_size, sha256=digest(config_path))]
    if args.gguf_role_files:
        if __package__:
            from .gguf_roles import prepare_role_files as prepare_gguf_role_files
        else:
            from gguf_roles import prepare_role_files as prepare_gguf_role_files
        role_lines, role_receipt = prepare_gguf_role_files(args.gguf_role_files, args.mtp)
    elif args.role_files:
        role_lines, role_receipt = prepare_role_files(args.role_files, args.mtp, config)
    else:
        role_lines, role_receipt = prepare_safetensors(args.model, args.mtp, config)
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    encoded = tokenizer.apply_chat_template([{"role": "user", "content": args.prompt}],
        add_generation_prompt=True, enable_thinking=False, tokenize=True, return_dict=True)
    prompt = encoded["input_ids"]
    continuation = tokenizer.encode(args.continuation, add_special_tokens=False)
    args.output.mkdir(parents=True)
    with (args.output / "weights.tsv").open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(role_lines) + "\n")
    for name, values in (("prompt.ids", prompt), ("continuation.ids", continuation)):
        (args.output / name).write_text(" ".join(map(str, values)) + "\n", encoding="ascii")
    receipt = dict(kind="qwen_text_input_preparation_no_model_execution",
        original_files=records, tokenizer_directory=str(args.model.resolve()),
        prompt=args.prompt, prompt_ids=prompt, continuation_ids=continuation,
        script_sha256=digest(Path(__file__)), **role_receipt)
    receipt.update(weight_selection="text+mtp" if args.mtp else "text", manifest_signature=role_lines[0])
    (args.output / "input.json").write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    expected = geometry.role_shapes(role_receipt["geometry"])
    summary = {"text_tensors":sum(not n.startswith("mtp.") for n in expected),
               "prompt_tokens":len(prompt), "output":str(args.output)}
    if args.mtp:
        summary.update(mtp_tensors=sum(n.startswith("mtp.") for n in expected),
                       selected_tensors=role_receipt["physical_roles"])
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
