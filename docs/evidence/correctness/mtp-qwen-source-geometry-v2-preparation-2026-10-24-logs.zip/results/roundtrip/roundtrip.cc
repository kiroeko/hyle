#include "model_geometry.h"
#include <fstream>
#include <iostream>
int main(int argc,char**argv) {
  if(argc!=2)return 2;
  std::ifstream file(argv[1]);std::string line;std::getline(file,line);
  try {const auto g=qwen35::read_model_geometry(line);
    std::cout<<g.hidden<<" "<<g.intermediate<<" "<<g.vocabulary<<" "<<g.query_heads<<" "<<g.kv_heads<<" "<<g.key_depth<<" "<<g.value_depth<<" "<<g.rotary<<" "<<g.gdn_key_heads<<" "<<g.gdn_value_heads<<" "<<g.gdn_key_depth<<" "<<g.gdn_value_depth<<" "<<g.conv_kernel<<" "<<g.context_limit<<" "<<g.tied_head<<" "<<g.mtp_layers<<" "<<int(g.gdn_layout==qwen35::GdnHeadLayout::kCyclic)<<" "<<g.layers.size()<<" "<<g.attention_layers()<<" "<<g.recurrent_layers()<<" "<<g.gdn_qkv_width()<<" "<<g.attention_width()<<" "<<g.query_gate_width()<<" "<<g.head_role()<<"\n";
  }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
}
