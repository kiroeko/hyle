from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2];O=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check';A=O/'roundtrip';A.mkdir()
sys.path.insert(0,str(R))
from engine.models.qwen35 import geometry
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
checks=b.read(O/'offline-input-checks.json')['checks'];rows=[]
for i,x in enumerate(checks):
 line=geometry.line(x['geometry']);p=A/(str(i)+'.line');p.write_text(line+'\n');rows.append((p,x['geometry']))
source=A/'roundtrip.cc';source.write_text('''#include "model_geometry.h"
#include <fstream>
#include <iostream>
int main(int argc,char**argv) {
  if(argc!=2)return 2;
  std::ifstream file(argv[1]);std::string line;std::getline(file,line);
  try {const auto g=qwen35::read_model_geometry(line);
    std::cout<<g.hidden<<" "<<g.intermediate<<" "<<g.vocabulary<<" "<<g.query_heads<<" "<<g.kv_heads<<" "<<g.key_depth<<" "<<g.value_depth<<" "<<g.rotary<<" "<<g.gdn_key_heads<<" "<<g.gdn_value_heads<<" "<<g.gdn_key_depth<<" "<<g.gdn_value_depth<<" "<<g.conv_kernel<<" "<<g.context_limit<<" "<<g.tied_head<<" "<<g.mtp_layers<<" "<<int(g.gdn_layout==qwen35::GdnHeadLayout::kCyclic)<<" "<<g.layers.size()<<" "<<g.attention_layers()<<" "<<g.recurrent_layers()<<" "<<g.gdn_qkv_width()<<" "<<g.attention_width()<<" "<<g.query_gate_width()<<" "<<g.head_role()<<"\\n";
  }catch(const std::exception&e){std::cerr<<e.what()<<"\\n";return 1;}
}
''')
recipe=b.read(R/'.scratch/engine-product-20261024/cpu-build1/entry/identity.json');cc=recipe['command'][0]
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[cc,'/nologo','/std:c++latest','/EHsc','/MD','/O2','/W4','/WX','/utf-8','/I'+str(R/'engine/models/qwen35'),str(source),'/Fe'+str(A/'roundtrip.exe'),'/Fo'+str(A/'roundtrip.obj')]
before=b.identity(R/'engine/models/qwen35/model_geometry.h');b.execute(cmd,env,A/'compile',120);assert b.identity(R/'engine/models/qwen35/model_geometry.h')==before
results=[]
for i,(path,g)in enumerate(rows):
 result=b.execute([str(A/'roundtrip.exe'),str(path)],env,A/('case'+str(i)),15)
 actual=(A/('case'+str(i))/'stdout.log').read_text().split()
 expected=[*(g[k]for k in geometry.AXES),int(g['tied_head']),g['mtp_layers'],int(g['gdn_layout']=='cyclic'),len(g['layers']),g['layers'].count('A'),g['layers'].count('G'),2*g['gdn_key_heads']*g['gdn_key_depth']+g['gdn_value_heads']*g['gdn_value_depth'],g['query_heads']*g['value_depth'],g['query_heads']*(g['key_depth']+g['value_depth']), 'model.language_model.embed_tokens.weight' if g['tied_head']else 'lm_head.weight']
 assert actual==list(map(str,expected)),(actual,expected)
 results.append(dict(input=b.identity(path),process=result,actual=actual))
b.save(A/'results.json',dict(source=b.identity(source),geometry_header=before,image=b.identity(A/'roundtrip.exe'),cases=results,HTTP=0,model_execution=False))
print('ROUNDTRIP',len(results),'PASS',flush=True)
