#include "engine/models/qwen35/backend.h"
static_assert(qwen35::Backend::supports_cpu_gpu == EXPECT_MIXED);
static_assert(qwen35::Backend::host_only == EXPECT_HOST);
void check(qwen35::Backend &b) { (void)b.has_cpu_endpoint(); (void)b.host_device(); (void)b.queue_bindings(); }
