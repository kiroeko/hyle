#include "engine/models/qwen35/backend.h"
#include "hyle/graph/progress.h"
#include "hyle/sched/scheduler.h"
#include "hyle/sched/blocking.h"
#include <array>
#include <bit>
#include <cstdio>
#include <stdexcept>
#include <string>
namespace c=hyle::compute;namespace g=hyle::graph;namespace m=hyle::mem;
template<class T>T take(hyle::Result<T> value){if(!value)throw std::runtime_error(std::string(value.error().message()));return std::move(*value);}
void check(hyle::Status status){if(!status.ok())throw std::runtime_error(std::string(status.message()));}
int main(){try{
 auto backend=take(qwen35::Backend::create_cpu_gpu({1u<<20,1u<<20,1u<<20}));
 if(!backend.has_cpu_endpoint()||backend.queue_bindings().size()!=1||backend.queue_bindings()[0].lane!=g::ExecutionLaneId{1})throw std::runtime_error("actual Apple+CPU lane contract");
 hyle::sched::Scheduler scheduler(1,m::system_allocator(),32);hyle::sched::BlockingPool workers(m::system_allocator(),1);
 const auto desc=take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,1>{17}));
 std::array<std::uint16_t,17> words{},wanted{};for(std::size_t i=0;i<words.size();++i){words[i]=std::uint16_t(std::bit_cast<std::uint32_t>(float(int(i)-8)/4.F)>>16);wanted[i]=words[i]&0x7fff;}
 auto input_buffer=take(m::Buffer::create(backend.host_device(),sizeof(words),64));check(input_buffer.view().write(std::as_bytes(std::span(words))));
 auto input_lease=take(backend.adopt_buffer(std::move(input_buffer)));auto output_buffer=take(m::Buffer::create(backend.host_device(),sizeof(words),64));
 auto builder=take(g::GraphBuilder::create());const auto input=take(builder.input(desc));const auto first=take(builder.add(c::Unary{c::UnaryKind::kNeg},input));const auto native=take(builder.add(c::Unary{c::UnaryKind::kNeg},first));const auto output=take(builder.add(c::Unary{c::UnaryKind::kAbs},native));check(builder.publish(output));auto graph=take(std::move(builder).finish());
 const std::array placements{g::NodePlacement{take(graph.node_id(0)),g::ExecutionTargetId{1},g::PlacementStrength::kRequired},g::NodePlacement{take(graph.node_id(1)),g::ExecutionTargetId{0},g::PlacementStrength::kRequired},g::NodePlacement{take(graph.node_id(2)),g::ExecutionTargetId{1},g::PlacementStrength::kRequired}};
 const std::array external{g::ExternalResourceContract{input,g::StorageDomainId{1}},g::ExternalResourceContract{output,g::StorageDomainId{1}}};
 auto compiled=take(backend.compile(graph,{}, {.node_placements=placements,.external_resources=external}));std::size_t copies=0;
 for(std::size_t i=0;i<compiled.report.step_count();++i)copies+=take(compiled.report.step(i)).kind==g::CompileStepKind::kCopy;
 if(copies!=2)throw std::runtime_error("tiny needs two actual CPU/Apple copies");
 auto run=take(compiled.executable.create_invocation({.resources=g::ResourceOptions{}}));check(g::prepare_progress(run,scheduler,workers));
 check(run.bind(input,desc,input_lease));check(run.bind(output,take(c::TensorView::create(desc,output_buffer.view()))));
 const auto queues=backend.queue_bindings();check(g::batch::prepare(run,queues,{}, {.host_workspace=backend.host_device(),.max_float_workspace_bytes=1u<<20,.max_int_workspace_bytes=1u<<20}));
 for(int replay=0;replay<2;++replay){check(run.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}));{
 auto completion=take(run.submit(queues));check(completion.wait());auto result=take(run.result(output));auto tensor=take(result.tensor());
 if(tensor.description()!=desc)throw std::runtime_error("actual BF16 output description");std::array<std::uint16_t,17> actual{};check(tensor.storage().read(std::as_writable_bytes(std::span(actual))));if(actual!=wanted)throw std::runtime_error("BF16 original17 element oracle");
 if(run.bind(input,desc,input_lease).ok())throw std::runtime_error("held result must guard rebind");}
 check(run.bind(input,desc,input_lease));}
 check(run.close());scheduler.drain();std::printf("PASS CPU->Apple->CPU BF16 elements17 copies2 lane1 replays2 exact_bits ownership_guard1\n");return 0;
}catch(const std::exception&e){std::fprintf(stderr,"FAIL %s\n",e.what());return 1;}}
