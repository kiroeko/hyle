"""Archive finite native mixed-placement results; no builds, models or HTTP."""
from pathlib import Path
import hashlib, json, zipfile

R = Path(__file__).resolve().parents[2]
S = Path(__file__).resolve().parent
OUT = R / 'docs/evidence/correctness'
NAME = 'mtp-qwen35-cpu-native-placement-2026-10-24'

def read(path):
    return json.loads((R / path).read_text(encoding='utf-8-sig'))

def identity(path):
    p = (R / path).resolve()
    name = p.relative_to(R).as_posix()
    return dict(path=name, bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

win_path = '.scratch/qwen-cpu-vulkan-20261024/summary.json'
mac_path = '.scratch/qwen-cpu-apple-functional-20261024/summary.json'
reg_path = '.scratch/qwen-copy-release-regression-20261024/summary.json'
cuda_path = '.scratch/qwen-cpu-gpu-backend-20261024/cuda-regression1/summary.json'
win, mac, reg, cuda = map(read, [win_path, mac_path, reg_path, cuda_path])
assert win['engine']['exit'] == 0 and win['smoke']['exit'] == 0
assert mac['state'] == 'pass' and mac['complete_model']['process']['exit'] == 0
assert mac['tiny']['process']['exit'] == 0
assert all(row['matched_expectation'] for row in reg['results'])
assert cuda['tests']['tests'] == 4 and cuda['tests']['failures'] == 0

products = [
    'engine/models/qwen35/backend.h', 'engine/models/qwen35/main.cc',
    'src/graph_route_vulkan/execution_source.cc',
    'src/graph_route_apple/execution_source.cc',
    'tests/graph_route_vulkan/execution_source_test.cc',
    'tests/tools/qwen_backend_cpu_cuda_test.cc',
]
assert identity(products[0])['sha256'] == win['frozen_backend']['canonical']['sha256']
assert identity(products[1])['sha256'] == win['frozen_main']['canonical']['sha256']
files = set(read('.scratch/qwen-cpu-vulkan-20261024/archive-files.json')) | set(products)
files.update([win_path, mac_path, reg_path, cuda_path,
    '.scratch/qwen-cpu-gpu-backend-20261024/header-check-summary.json',
    '.scratch/qwen-cpu-gpu-backend-20261024/cpu-main-syntax1/summary.json',
    '.scratch/qwen-cpu-apple-functional-20261024/logs-and-commands.tar.gz',
    '.scratch/qwen-cpu-native-proof-20261024/package.py'])
for folder in ['.scratch/qwen-copy-release-regression-20261024',
               '.scratch/qwen-cpu-apple-functional-20261024/selected-source',
               '.scratch/qwen-cpu-gpu-backend-20261024/cuda-regression1',
               '.scratch/qwen-cpu-gpu-backend-20261024/header-check1',
               '.scratch/qwen-cpu-gpu-backend-20261024/header-check2']:
    for p in (R / folder).rglob('*'):
        if p.is_file() and p.suffix in {'.json', '.log', '.cc', '.h', '.py', '.ps1', '.patch'}:
            files.add(p.relative_to(R).as_posix())
records = [identity(p) for p in sorted(files)]
assert all(row['bytes'] < 16 * 1024 * 1024 for row in records)
archive = OUT / (NAME + '.zip')
report = OUT / (NAME + '.json')
assert not archive.exists() and not report.exists(), 'Do not overwrite evidence'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for row in records:
        z.write(R / row['path'], row['path'])
    z.writestr('archive-entries.json', json.dumps(records, ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    entries = len(z.infolist())
mr = mac['complete_model']['report']
proof = dict(
    status='finite_native_mixed_functional_pass', date='2026-10-24',
    scope='MTP and its necessary shared inference paths only; not ordinary-engine functional exhaustion, model-task quality or performance comparison.',
    changes=[
        'Expose original CPU endpoint and host loader for CPU+Apple and CPU+Vulkan, using the same cold Graph assembly and finite storage domains as CPU+CUDA.',
        'Vulkan native copy binding release now validates actual Run/Completion retirement before clearing retained VkBuffer owners and cached binding state; no skipped unbind or raised limits.',
        'The same permanent Graph regression uses two different staging backings, retires and unbinds twice; only replacing the copy object with its preserved old version reproduces the original failure.',
    ],
    product_sources=[identity(p) for p in products],
    source_id=win['engine']['source_id'], original_roles=335,
    original_text_and_mtp_bytes=3885311680,
    windows_cpu_vulkan=dict(
        summary=identity(win_path), image=win['engine']['image'],
        exit=0, prompt_rows=8, capacity=32, max_drafts=1,
        sampling='random', cpu_ffn_layers=1,
        generated_ids=win['engine']['generated_ids'],
        accepted_drafts=1, target_frontier=11, draft_frontier=11,
        RNG_cursor=5, host_weight_bytes=75501568, device_weight_bytes=3809810112,
        duplicated_original_weight_bytes=0,
        tiny=win['smoke']['observed']),
    macos_cpu_apple=dict(
        summary=identity(mac_path), hardware=mac['machine'],
        exit=0, prompt_rows=15, capacity=32, max_drafts=1,
        sampling='random', cpu_ffn_layers=2,
        generated_ids=mr['generated_ids'], accepted_drafts=1, rejected_rounds=1,
        target_frontier=18, draft_frontier=17, RNG_cursor=7,
        draft_lag='Valid lag1 retains final pending token for NextN catchup.',
        host_weight_bytes=151003136, device_weight_bytes=3734308544,
        duplicated_original_weight_bytes=0,
        cache_peak_requested_bytes=62476339, cache_requested_byte_limit=268435456,
        tiny=mac['tiny']),
    regressions=dict(copy_release=reg, cuda_backend_tests=4, cuda_failures=0,
        cpu_main_strict_syntax='PASS',
        backend_header_configurations=['cpu', 'cuda', 'cpu+cuda', 'vulkan', 'cpu+vulkan']),
    HTTP_for_validation=0, model_download_bytes_for_validation=0, SDK_builds=0,
    qualifications=[
        'Vulkan replay DMA requires four-byte transfer granularity. BF16[17] (34B) was rejected before arithmetic. The passing case is BF16[18] (36B), containing17 exact values and one explicit13.5 canary; selected model ports are aligned.',
        'Apple tiny uses17 BF16 elements and checks exact bits, two executions and held-output overwrite rejection.',
        'Finite random K1 complete-model journeys and selected current closure only; no full dtype/backend/model matrix, all-platform SDK rebuild, task-quality or throughput claim.',
        'Cache and workspace limits cover reported requested allocations; native private allocation sizes remain unknown, and no physical RAM/VRAM cap is asserted.',
        'Cached Hyle source/header changes and actual native ABI differences were reviewed and relevant leaves refreshed. Unrecorded inherited support/vendor objects are not claimed exact-current source; see archived closure summaries.',
        'Initial private setup failures, original missing-release failure, BF16 alignment rejection and old-object negative control are retained in selected logs.',
    ], archive=identity(archive), archive_entries=entries)
report.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(report), archive=identity(archive), entries=entries)))
