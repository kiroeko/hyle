from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parents[2]
S=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
    p=Path(p).resolve();return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,j):Path(p).write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
smoke=S/'smoke-attempt6';engine=S/'engine-attempt1'
sp=read(smoke/'run/process.json');ep=read(engine/'run3/process.json')
assert sp['exit']==ep['exit']==0 and not sp['timed_out'] and not ep['timed_out']
rows=[json.loads(x)for x in (smoke/'run/stdout.log').read_text().splitlines()if x.startswith('{')]
assert len(rows)==5 and all(x['cpu_gpu_cpu'] for x in rows[:4])
assert [x['episode']for x in rows[:4]]==[0,1,0,1]
assert [x['requested_type']for x in rows[:4]]==[6,6,5,5]
assert all(x['actual_generated_type']==x['requested_type'] for x in rows[:4])
assert rows[-1]['status']=='PASS' and rows[-1]['retired_unbind_rebind']
report=json.loads((engine/'run3/stdout.log').read_text())
assert report['mtp'] and report['cpu_ffn_layers']==1 and report['generated_tokens']==4
assert report['prefill_target_rows']==8 and report['mtp_max_drafts']==1
assert report['draft_lag']==0 and report['consumed_drafts']==1
assert report['generated_ids']==[364,264,2972,673]
assert report['original_host_weight_bytes']==75501568 and report['original_device_weight_bytes']==3809810112
assert report['sampling_draw_cursor']==5 and report['actual_target_rows']==report['committed_target_rows']==11
sources=read(engine/'sources.json');backend=next(x for x in sources if x['canonical']['path'].endswith('backend.h'))
assert backend['canonical']['sha256']=='67424eb918398b02165900131dcf1f46d9d3a924b1ff7e5a1c405d46e92c8b93'
main=next(x for x in sources if x['canonical']['path'].endswith('engine\\models\\qwen35\\main.cc'))
copy=read(S/'graph-batch-execution_source-current1/identity.json')
assert copy['source']['sha256']=='c275aa1d19c6e25cb1a767998bc6841632343143d36fdf1095045bf8185a2e49'
audit=read(S/'closure-audit.json');review=[];patches=[]
classifications={
 'include/hyle/compute/detail/lease_access.h':'New static declarations only, no object layout change; the new implementation is explicitly linked.',
 'include/hyle/compute/batch_execution.h':'Comments only.',
 'include/hyle/graph/executable.h':'Comments only.',
 'include/hyle/compute/low_precision.h':'CacheStorage remains8bytes, new encoding uses former padding. Its constructing/comparing cache consumers use current objects. Stale recorded sources have no CacheStorage/key_storage/value_storage use; this run is plain BF16.',
 'include/hyle/compute/model_ops.h':'DenseLinearF32 retains the same operation ID and BF16 semantics, extends F16/F32 eligibility; this source uses the unchanged BF16 branch.',
 'include/hyle/compute/vulkan.h':'New nonvirtual Context::drain declaration, no Context layout change; the current device implementation is linked.',
 'src/compute_route_vulkan/vulkan_internal.h':'New free-function declaration only. The comment explicitly retains Buffer ABI/layout; current memory/device objects supply the implementation.'}
for row in audit['distinct_changed_self_files']:
    path=row['path'].replace('\\','/');assert path in classifications,path
    old=subprocess.run(['git','show','HEAD:'+path],capture_output=True,check=True).stdout
    assert hashlib.sha256(old).hexdigest()==row['recorded'],path
    patch=subprocess.run(['git','diff','--',path],capture_output=True,check=True).stdout.decode('utf8')
    patches.append(patch);review.append(dict(**row,recorded_equals_HEAD=True,review=classifications[path]))
for row in audit['objects']:
    if not any(x['path'].endswith('low_precision.h')for x in row['stale']):continue
    p=Path(row['source'])
    if p.is_file():assert not re.search(r'CacheStorage|key_storage|value_storage',p.read_text(encoding='utf-8-sig')),str(p)
(S/'header-review.patch').write_text('\n'.join(patches),encoding='utf8')
save(S/'header-review.json',dict(review=review,boundary='Finite recorded canonical Hyle identities, including frozen src/header mapping. Unrecorded support/vendor archive members remain explicit in closure-audit.json; no whole SDK current-source claim.'))
failures=[]
for folder,reason in [
 ('smoke-attempt1/link','Private link selection omitted existing CPU standard_index/native_batch support. No product source failure.'),
 ('smoke-attempt1/run','Old Vulkan/host resource cache lacked current canonical host identity properties.'),
 ('smoke-attempt1/link3','Current Vulkan memory object requires its existing current device controller helper; retained device/run objects were then supplied.'),
 ('smoke-attempt1/run2','Old host resource object still lacked canonical host identity; exact existing mem-resource object was added.'),
 ('smoke-attempt1/run3','Private loader fixture capacity4096 could not hold its full4096B external pool plus64B staging; finite capacity corrected16384.'),
 ('smoke-attempt2/run','Private fixture tried to bind caller storage to native-generated Graph output; corrected to read the actual successful generated output.'),
 ('smoke-attempt4/run','Private unbind fixture omitted the API-required prepare_resources; F32 roundtrip itself completed.'),
 ('smoke-attempt5/run','Cold17-BF16/34B copy rejected at native four-byte transfer alignment. No BF16 numerical pass is claimed for this attempt.'),
 ('engine-attempt1/run','Original full journey failed at prefill unbind because native Vulkan copy had no binding-release contract.'),
 ('engine-attempt1/run2','Refreshing stale batch objects alone did not fix the true native copy-release omission; same actual failure retained.')]:
    p=S/folder/'process.json';j=read(p);assert j['exit']!=0
    failures.append(dict(folder=folder,exit=j['exit'],process=ident(p),reason=reason))
summary=dict(schema_version=1,date='2026-10-24',status='PASS finite original2B CPU+Vulkan explicit placement MTP journey',
 scope='Functional proof only. No throughput, memory comparison, whole SDK, all-codec or every mixed-shape claim.',
 HTTP_requests=0,model_download_bytes=0,SDK_builds=0,shader_builds=0,NVCC=0,
 fresh_TUs=dict(engine_main=1,private_smoke=6,Hyle_product=4),
 frozen_main=main,frozen_backend=backend,copy_release_source=copy['source'],copy_release_object=copy['object'],
 self_closure_audit=ident(S/'closure-audit.json'),header_review=ident(S/'header-review.json'),
 smoke=dict(image=ident(smoke/'hyle-cpu-vulkan.exe'),process=ident(smoke/'run/process.json'),
     exit=sp['exit'],process_wall_seconds=sp['process_wall_seconds'],observed=rows,
     pipeline='Original CPU Context/Queue host file pipeline16B, non-CPU destination rejected, actual CPU→Vulkan→CPU Graph with required placements, original native retirement and same-slot unbind/rebind twice per type.'),
 engine=dict(image=ident(engine/'hyle-cpu-vulkan.exe'),process=ident(engine/'run3/process.json'),
     command=ident(engine/'run3/command.json'),stdout=ident(engine/'run3/stdout.log'),stderr=ident(engine/'run3/stderr.log'),
     exit=ep['exit'],process_wall_seconds=ep['process_wall_seconds'],source_id=report['source_id'],
     selected_physical_roles=335,selected_weight_bytes=report['original_host_weight_bytes']+report['original_device_weight_bytes'],
     original_host_weight_bytes=report['original_host_weight_bytes'],original_device_weight_bytes=report['original_device_weight_bytes'],
     duplicated_original_weight_bytes=0,cpu_ffn_layers=1,prompt_rows=8,max_drafts=1,sampling='random',requested_outputs=4,
     generated_ids=report['generated_ids'],sampling_draw_cursor=5,committed_target_rows=11,
     actual_accepted_drafts=1,complete_draft_lag=0,successful_prefill=True,successful_two_row_verifier=True,successful_one_row_tail=True,
     raw_report_contains_internal_timings=True,timings_are_not_a_benchmark_comparison=True),
 failures_preserved=failures,
 limits=['Vulkan native replay copy requires four-byte transfer granularity. The17BF16/34B shape was honestly rejected before arithmetic; final BF16 shape18/36B carries17exact values plus13.5canary. Selected2B ports have aligned extents.',
 'The actual complete model run is P8/K1/random/+4 with1CPU FFN layer; it is not a mixed-mode/publisher/backend matrix or quality/acceptance-rate benchmark.',
 'Unrecorded inherited support/vendor archives are listed, not represented as exact-current source. Recorded incompatible leaves were refreshed; reviewed remaining header differences preserve this BF16 path.',
 'Root owns the combined public CPU+native proof and goal status. This private summary does not close the MTP goal.'])
save(S/'summary.json',summary)
files=[S/p for p in ['summary.json','prepare.py','audit_closure.py','summarize.py','backend_host_loader.cc','plan.json','closure-audit.json','header-review.json','header-review.patch']]
for folder in [smoke,engine]:
    files += [p for p in folder.rglob('*')if p.is_file()and p.suffix in ['.json','.log']and p.name!='dependencies.json']
files += list((engine/'source').rglob('*.h'))+list((engine/'source').rglob('*.cc'))
files += [smoke/'source/backend_host_loader.cc',smoke/'source/engine/models/qwen35/backend.h']
for folder in ['memory-current1','graph-batch-batch-current1','graph-batch-paged_append-current1','graph-batch-execution_source-current1']:
    files += [p for p in (S/folder).iterdir()if p.is_file()and p.suffix in ['.json','.log','.cc']]
for row in failures:
    folder=S/row['folder'];files += [p for p in folder.iterdir()if p.is_file()and p.suffix in ['.json','.log']]
files += [S/'smoke-attempt5/source/backend_host_loader.cc']
save(S/'archive-files.json',sorted({p.relative_to(R).as_posix()for p in files}))
print(json.dumps(dict(summary=ident(S/'summary.json'),smoke_image=summary['smoke']['image'],engine_image=summary['engine']['image'],archive_files=len(set(files))),indent=2))
