"""Finite CPU/Vulkan Backend and engine refresh; retain all SDK/native inputs.

Plan is read-only except this task's metadata. Build must be explicitly invoked
after canonical backend/main are stable. Runs are separate explicit commands.
"""
from pathlib import Path
import argparse, importlib.util, json, os, shutil, struct, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
spec = importlib.util.spec_from_file_location('retained_helpers', R / '.scratch/engine-product-20261024/cpu-build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
VK = R / '.scratch/qwen-vulkan-multik-20261024/build1'
CPU = R / '.scratch/q27-cold-search-20261024/fixed1'
INPUTS = R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
CPU_PLAN = CPU / 'link/command.json'
VK_PLAN = VK / 'link-plan.json'

def read(p): return b.read(p)
def save(p, value): b.save(p, value)
def command(p):
    value = read(p)
    return value['command'] if isinstance(value, dict) else value

def cpu_additions():
    cpu = command(CPU_PLAN)
    prefixes = ('compute_backend_cpu--', 'compute_route_cpu--', 'graph_route_cpu--', 'compute_provider_ggml--',
                'compute_provider_native--', 'compute_provider_onednn--', 'graph_provider_onednn--')
    explicit = {'cpu-file-stream.obj', 'cpu-execution.obj', 'cpu-hadamard.obj',
                'metadata-arena.obj', 'cpu-baseline.obj', 'native-batch.obj', 'mem-resource.obj', 'compute_ggml_runtime--cpu_program.obj'}
    result = [x for x in cpu if x.lower().endswith('.obj') and
        (Path(x).name.startswith(prefixes) or Path(x).name in explicit or
         '/dense-cpu-check1/provider/' in x.replace('\\', '/'))]
    result += [x for x in cpu if x.lower().endswith('.lib') and
        (Path(x).name.lower() in ('ggml-cpu.lib', 'dnnl.lib', 'torch.lib', 'torch_cpu.lib', 'c10.lib'))]
    # CPU and GPU use the same pinned core family in a mixed build. Pure CPU's
    # newer ffa4 core is intentionally excluded. Use the retained mixed core,
    # including its already existing fork-local IQ1 IDs; this journey is BF16.
    result += [x for x in cpu if '/reference-windows/lib/' in x.replace('\\', '/') and
        Path(x).name in ('ggml.lib', 'ggml-base.lib')]
    assert len(result) > 25 and all(Path(x).is_file() for x in result)
    assert not any('pure-cpu-deployment' in x for x in result)
    return list(dict.fromkeys(result))

def plan():
    additions = cpu_additions()
    old = read(VK / 'ready.json')
    b.require(old['image'])
    manifest = INPUTS / 'weights.tsv'
    source_files = {}
    import shlex
    for line in manifest.read_text(encoding='utf-8').splitlines()[3:]:
        parts = shlex.split(line, posix=True)
        if not parts: continue
        rank = int(parts[2]); path = Path(parts[3 + rank]); offset = int(parts[4 + rank]); size = int(parts[5 + rank])
        assert path.is_file() and offset + size <= path.stat().st_size
        source_files[str(path)] = path.stat().st_size
    record = dict(scope='Prepare only; no compile/GPU/model/network was started',
        plans=dict(vulkan=b.identity(VK_PLAN), cpu=b.identity(CPU_PLAN)),
        required_fresh_TUs=['backend_host_loader.cc', 'engine/models/qwen35/main.cc'],
        graph_replacement=b.identity(CPU / 'graph/graph.obj'),
        cpu_additions=[b.identity(x) for x in additions],
        cpu_native=b.identity(CPU / 'hyle_ggml_cpu_gdn_scale_v3.dll'),
        source_manifest=b.identity(manifest), original_source_files=source_files,
        model_copy_bytes=0, SDK_builds=0, HTTP=0,
        shared_core_boundary='Mixed CPU/GPU pinned GGML family; Vulkan vendor has no fork-local IQ1 IDs. Only original BF16 roles are exercised, no all-codec SDK claim.')
    save(S / 'plan.json', record)
    print(json.dumps(dict(cpu_added_inputs=len(additions), source_files=source_files,
        fresh_TUs=record['required_fresh_TUs'], SDK_builds=0, HTTP=0)), flush=True)

def compile_source(source, folder, frozen):
    old = command(VK / 'model-compile-attempt9/command.json')
    cc = old[0]
    env = b.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':cc,
        'CMAKE_CXX_COMPILER':cc, 'CMAKE_GENERATOR':'Ninja'}, backends=()).env
    flags=[]; skip=False
    for arg in old[1:]:
        if skip: skip=False; continue
        if arg.lower() == '/sourcedependencies': skip=True; continue
        if arg.lower().startswith(('/fo','/fd','/i','-i','/external:i')) or arg.lower().endswith(('.cc','.cpp','.mm')): continue
        flags.append(arg)
    flags += ['/DHYLE_COMPUTE_CPU=1', '/DHYLE_COMPUTE_VULKAN=1',
        '/I'+str(frozen), '/I'+str(R), '/I'+str(R/'include'), '/I'+str(R/'engine')]
    cmd = [cc, *flags, '/sourceDependencies', str(folder/'dependencies.json'),
           str(source), '/Fo'+str(folder/'unit.obj'), '/Fd'+str(folder/'unit.pdb')]
    before = b.identity(source)
    result = b.execute(cmd, env, folder, 240)
    assert b.identity(source) == before
    deps = read(folder/'dependencies.json')['Data']
    record = dict(source=before, object=b.identity(folder/'unit.obj'), command=cmd,
        dependencies=[b.identity(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])], process=result)
    save(folder/'identity.json',record)
    return record,env

def refresh_memory():
    folder=S/'memory-current1'
    recipe=read(R/'.scratch/gdn-vulkan-output-scale-20261024/compile1/route--vulkan_memory/identity.json')
    source=R/'src/compute_route_vulkan/vulkan_memory.cc';cmd=[];skip=False
    for arg in recipe['command']:
        if skip:skip=False;continue
        if arg.lower()=='/sourcedependencies':skip=True;continue
        if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
        cmd.append(arg)
    cmd[1:1]=['/I'+str(R/'include')]
    cmd+=['/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cmd[0],
        'CMAKE_CXX_COMPILER':cmd[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
    before=b.identity(source);result=b.execute(cmd,env,folder,180);assert b.identity(source)==before
    deps=read(folder/'dependencies.json')['Data'];shutil.copyfile(source,folder/'vulkan_memory.cc')
    save(folder/'identity.json',dict(source=before,object=b.identity(folder/'unit.obj'),command=cmd,
        dependencies=[b.identity(x)for x in dict.fromkeys([deps['Source'],*deps['Includes']])],process=result))

def refresh_graph_batch(names=('batch','paged_append')):
    for name in names:
        module='graph_route_vulkan' if name=='execution_source' else 'graph_batch'
        folder=S/('graph-batch-'+name+'-current1')
        recipe=read(R/('.scratch/qwen-vulkan-k1-20261024/build1/src--'+module+'--'+name+'-cc/identity.json'))
        source=R/('src/'+module+'/'+name+'.cc');cmd=[];skip=False
        for arg in recipe['command']:
            if skip:skip=False;continue
            if arg.lower()=='/sourcedependencies':skip=True;continue
            if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
            cmd.append(arg)
        cmd[1:1]=['/I'+str(R/'include')]
        cmd+=['/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
        env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cmd[0],
            'CMAKE_CXX_COMPILER':cmd[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
        before=b.identity(source);result=b.execute(cmd,env,folder,180);assert b.identity(source)==before
        deps=read(folder/'dependencies.json')['Data'];shutil.copyfile(source,folder/(name+'.cc'))
        save(folder/'identity.json',dict(source=before,object=b.identity(folder/'unit.obj'),command=cmd,
            dependencies=[b.identity(x)for x in dict.fromkeys([deps['Source'],*deps['Includes']])],process=result))

def build(kind, attempt):
    out = S / (kind+'-'+attempt)
    out.mkdir(exist_ok=False)
    frozen = out/'source'
    sources = []
    for path in sorted([*(R/'engine/models/qwen35').glob('*.h'), *(R/'engine/inference').glob('*.h'),
                        R/'engine/models/qwen35/main.cc']):
        dest=frozen/path.relative_to(R); dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,dest); sources.append(dict(canonical=b.identity(path), frozen=b.identity(dest)))
    if kind=='smoke':
        source=frozen/'backend_host_loader.cc'; shutil.copyfile(S/'backend_host_loader.cc',source)
    else:
        source=frozen/'entry.cc'
        source.write_text('#include "engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
    save(out/'sources.json',sources)
    compiled,env=compile_source(source,out/'compile',frozen)
    finish_link(kind, attempt, compiled, env)

def finish_link(kind, attempt, compiled, env):
    out = S / (kind+'-'+attempt)
    old_model=read(VK/'ready.json')['model']['object']['path']
    old_graph=read(VK/'ready.json')['graph']['object']['path']
    cmd=[]
    core_names={'ggml.lib','ggml-base.lib'}
    for arg in command(VK_PLAN):
        if arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:')):continue
        if arg==old_model:arg=compiled['object']['path']
        if arg==old_graph:arg=str(CPU/'graph/graph.obj')
        for name in ['batch','paged_append','execution_source']:
            module='graph_route_vulkan' if name=='execution_source' else 'graph_batch'
            refresh_path=S/('graph-batch-'+name+'-current1/identity.json')
            if refresh_path.exists() and arg==str(R/('.scratch/qwen-vulkan-k1-20261024/build1/src--'+module+'--'+name+'-cc/unit.obj')):
                refresh=read(refresh_path)
                for item in [refresh['source'],refresh['object'],*refresh['dependencies']]:b.require(item)
                arg=refresh['object']['path']
        # Both are replaced by the retained mixed core, one global GGML core.
        if Path(arg).name in core_names and 'vendor' in arg:continue
        cmd.append(arg)
    assert compiled['object']['path'] in cmd and str(CPU/'graph/graph.obj') in cmd
    cmd[1:1]=cpu_additions()
    memory=S/'memory-current1/identity.json'
    if memory.exists():
        refresh=read(memory)
        for item in [refresh['source'],refresh['object'],*refresh['dependencies']]:b.require(item)
        cmd.insert(1,refresh['object']['path'])
        retained=R/'.scratch/qwen-native-lifetime-audit-20261024'
        records=[]
        for name in ['device','run']:
            record=read(retained/name/'source.json')
            assert b.identity(record['path'])['sha256']==record['sha256']
            assert read(retained/name/'process.json')['exit']==0
            obj=retained/name/'unit.obj';cmd.insert(1,str(obj))
            records.append(dict(source=b.identity(record['path']),object=b.identity(obj),
                original_process=b.identity(retained/name/'process.json')))
        save(out/'retained-vulkan-owner-records.json',records)
    image=out/'hyle-cpu-vulkan.exe'
    cmd += ['/OUT:'+str(image),'/MAP:'+str(out/'hyle.map')]
    save(out/'link-plan.json',dict(command=cmd,compiled=compiled,SDK_builds=0,HTTP=0,
        retained_sources=b.identity(S/'plan.json')))
    link_folder=out/'link';suffix=1
    while link_folder.exists():
        suffix+=1;link_folder=out/('link'+str(suffix))
    b.execute(cmd,env,link_folder,120)
    native=CPU/'hyle_ggml_cpu_gdn_scale_v3.dll'
    if not(out/native.name).exists():os.link(native,out/native.name)
    assert b.identity(native)['sha256']==b.identity(out/native.name)['sha256']
    vkpath=read(R/'.scratch/qwen35-unsloth-mtp-20261024/native-runtime-readiness/vulkan-real/ready.json')['PATH']
    torchpath=str(Path(next(x for x in cpu_additions() if Path(x).name=='torch_cpu.lib')).parent)
    runtime=dict(PATH=os.pathsep.join([str(out),torchpath,vkpath]))
    save(out/'runtime.json',runtime)
    save(out/'ready.json',dict(image=b.identity(image),native=b.identity(out/native.name),
        sources=b.identity(out/'sources.json'),runtime=b.identity(out/'runtime.json'),
        SDK_builds=0,HTTP=0,models_started=0))
    print('READY',kind,image,flush=True)

def relink(kind, attempt):
    out=S/(kind+'-'+attempt);compiled=read(out/'compile/identity.json')
    for item in [compiled['source'],compiled['object'],*compiled['dependencies']]:b.require(item)
    cc=compiled['command'][0]
    env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,
        'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    finish_link(kind,attempt,compiled,env)

def run(kind, attempt):
    out=S/(kind+'-'+attempt);ready=read(out/'ready.json');b.require(ready['image']);b.require(ready['native'])
    env=dict(os.environ,**read(out/'runtime.json'))
    if kind=='smoke':
        payload=out/'payload.bin';payload.write_bytes(struct.pack('<4f',1,-2,3,-4))
        argv=[ready['image']['path'],str(payload)]
    else:
        inputs=out/'inputs';inputs.mkdir(exist_ok=True)
        if not(inputs/'weights.tsv').exists():shutil.copyfile(INPUTS/'weights.tsv',inputs/'weights.tsv')
        assert (inputs/'weights.tsv').read_bytes()==(INPUTS/'weights.tsv').read_bytes()
        ids=(INPUTS/'prompt.ids').read_text().split()
        (inputs/'prompt.ids').write_text(' '.join(ids[:8])+'\n')
        argv=[ready['image']['path'],'--inputs',str(inputs),'--capacity','32','--steps','4',
            '--max-sessions','1','--active-sequences','1','--cache-bytes','2147483648',
            '--prefix-cache','off','--replay','commands','--mtp','on','--mtp-max-drafts','1',
            '--cpu-ffn-layers','1','--sampling','random','--temperature','1','--top-k','40',
            '--top-p','0.9','--seed','424242']
    run_folder=out/'run';suffix=1
    while run_folder.exists():suffix+=1;run_folder=out/('run'+str(suffix))
    b.execute(argv,env,run_folder,240)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['plan','refresh-memory','refresh-graph-batch','refresh-copy','build-smoke','build-engine','relink-smoke','relink-engine','run-smoke','run-engine'])
    parser.add_argument('attempt',nargs='?',default='attempt1');args=parser.parse_args()
    if args.action=='plan':plan()
    elif args.action=='refresh-memory':refresh_memory()
    elif args.action=='refresh-graph-batch':refresh_graph_batch()
    elif args.action=='refresh-copy':refresh_graph_batch(('execution_source',))
    elif args.action.startswith('build-'):build(args.action[6:],args.attempt)
    elif args.action.startswith('relink-'):relink(args.action[7:],args.attempt)
    else:run(args.action[4:],args.attempt)
