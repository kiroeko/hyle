#include "engine/models/qwen35/backend.h"
#include "hyle/io/file.h"
#include "hyle/io/io_context.h"
#include "hyle/sched/scheduler.h"
#include "hyle/sched/blocking.h"

#include <array>
#include <bit>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
hyle::sched::Task<hyle::Result<hyle::io::File>> open_source(m::AllocatorRef,
    hyle::io::IoContext *io, std::string path) {
  co_return co_await hyle::io::open_file(*io, 0, path,
      {.access = hyle::io::FileAccess::kRead});
}
std::vector<float> decoded(qwen35::Backend &backend, c::ConstTensorView tensor, std::size_t count) {
  const auto &description=tensor.description();
  if (!description.is_dense() || description.rank()!=1 || description.dimensions()[0]!=static_cast<std::int64_t>(count))
    throw std::runtime_error("generated tensor has the wrong actual extent");
  std::vector<float> result(count);
  if (description.data_type()==c::DataType::kFloat32) {
    if(take(description.required_bytes())!=count*sizeof(float))throw std::runtime_error("F32 carrier extent");
    check(backend.read(tensor.storage(),std::as_writable_bytes(std::span(result))));
  } else if(description.data_type()==c::DataType::kBFloat16) {
    std::vector<std::uint16_t> bits(count);
    if(take(description.required_bytes())!=count*sizeof(std::uint16_t))throw std::runtime_error("BF16 carrier extent");
    check(backend.read(tensor.storage(),std::as_writable_bytes(std::span(bits))));
    for(std::size_t i=0;i<count;++i)result[i]=std::bit_cast<float>(std::uint32_t(bits[i])<<16);
  } else throw std::runtime_error("unexpected generated transport data type");
  return result;
}
void graph_roundtrip(qwen35::Backend &backend,c::ConstTensorView input,std::span<const float> expected) {
  const auto description=input.description();
  auto builder=take(g::GraphBuilder::create());
  const auto x=take(builder.input(description));
  const auto host_node=take(builder.add_node(c::Operation(c::Unary{c::UnaryKind::kNeg}),std::array{x}));
  const auto y=take(builder.result(host_node));
  const auto gpu_node=take(builder.add_node(c::Operation(c::Unary{c::UnaryKind::kNeg}),std::array{y}));
  const auto z=take(builder.result(gpu_node));
  const auto return_node=take(builder.add_node(c::Operation(c::Unary{c::UnaryKind::kNeg}),std::array{z}));
  const auto w=take(builder.result(return_node));
  check(builder.publish(z));check(builder.publish(w));
  const auto graph=take(std::move(builder).finish());
  const std::array placements{
      g::NodePlacement{host_node,g::ExecutionTargetId{1},g::PlacementStrength::kRequired},
      g::NodePlacement{gpu_node,g::ExecutionTargetId{0},g::PlacementStrength::kRequired},
      g::NodePlacement{return_node,g::ExecutionTargetId{1},g::PlacementStrength::kRequired}};
  const std::array external{g::ExternalResourceContract{x,g::StorageDomainId{1}},g::ExternalResourceContract{w,g::StorageDomainId{1}}};
  auto compiled=take(backend.compile(graph,{}, {.node_placements=placements,.external_resources=external}));
  if(compiled.report.target_count()!=2||compiled.report.storage_domain_count()!=3)
    throw std::runtime_error("mixed Backend lost its two real targets/three domains");
  auto output=take(m::Buffer::create(backend.host_device(),take(description.required_bytes()),64));
  auto invocation=take(compiled.executable.create_invocation());
  check(invocation.prepare_resources());
  check(invocation.bind(w,take(c::TensorView::create(description,output.view()))));
  for(unsigned episode=0;episode<2;++episode) {
    check(invocation.bind(x,input));
    check(invocation.prepare_replay(backend.queue_bindings(),{.mode=g::ReplayMode::kCommands}));
    {
      auto completion=take(invocation.submit(backend.queue_bindings()));
      check(completion.wait());
    }
    const auto generated=take(invocation.output(z));
    const auto actual=decoded(backend,generated,expected.size());
    const auto returned=decoded(backend,take(c::ConstTensorView::create(description,output.view())),expected.size());
    for(std::size_t i=0;i<expected.size();++i)
      if(actual[i]!=expected[i]||returned[i]!=-expected[i])throw std::runtime_error("CPU/Vulkan typed roundtrip differs mathematically");
    std::printf("{\"requested_type\":%u,\"actual_generated_type\":%u,\"values\":%zu,\"episode\":%u,\"cpu_gpu_cpu\":true}\n",
        unsigned(description.data_type()),unsigned(generated.description().data_type()),expected.size(),episode);
    // Release the actual retired copy/native owners, then rebind through the
    // same Graph slot. No reset, replacement runtime or implicit drain hides it.
    check(invocation.unbind(x));
  }
}
void run(const std::string &path) {
  static_assert(qwen35::Backend::supports_cpu_gpu);
  auto backend = take(qwen35::Backend::create_cpu_gpu({1u << 20, 1u << 20, 1u << 20}));
  if (!backend.has_cpu_endpoint() || backend.device() == backend.host_device())
    throw std::runtime_error("CPU/Vulkan original allocation domains were not retained");
  (void)take(backend.storage_owner_for(backend.host_device()));
  const auto description = take(c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 1>{4}));
  hyle::sched::Scheduler scheduler(2, m::system_allocator(), 256);
  hyle::io::IoContext io(scheduler, {.max_blocking_threads = 2});
  check(io.status());
  struct Shutdown final { hyle::sched::Scheduler &scheduler; ~Shutdown() { scheduler.shutdown(); } } shutdown{scheduler};
  const std::array targets{c::CopyResourceSpec{backend.host_device(), 16}};
  auto pipeline = take(backend.create_host_file_pipeline(io, targets, {
      .max_requests = 1, .max_groups_per_request = 1, .max_ranges_per_group = 1,
      .in_flight_slots = 1, .staging_bytes_per_slot = 64, .staging_alignment = 64,
      .max_active_backing_bytes = 16384}));
  struct Drain final { c::FileResourcePipeline &pipeline; ~Drain() { pipeline.drain().IgnoreError(); } } drain{pipeline};
  const std::array wrong_targets{c::CopyResourceSpec{backend.device(), 16}};
  const auto wrong = backend.create_host_file_pipeline(io, wrong_targets);
  if (wrong || !wrong.error().IsInvalidArgument())
    throw std::runtime_error("CPU loader accepted a Vulkan device destination");
  auto pool = take(c::LeasePool::create(backend.host_device(), 4096));
  auto file = take(take(hyle::sched::spawn_task_on(scheduler, 0, m::system_allocator(),
      open_source(m::system_allocator(), &io, path)).join()));
  auto source = take(c::StreamFile::adopt(std::move(file), 16));
  std::array ranges{c::StreamReadRange{.destination = take(pool.allocate(16)),
      .bytes = 16, .description = description}};
  std::array groups{c::StreamReadGroup{7, ranges}};
  auto ticket = take(pipeline.read(c::StreamSource::file(std::move(source)), groups));
  auto ready = take(ticket.wait_next_ready());
  auto input = take(ready.output(0));
  const auto transferred = ticket.wait();
  check(transferred.status);
  if (!transferred.retirement_proven || transferred.read_bytes != 16 || transferred.copied_bytes != 16)
    throw std::runtime_error("CPU loader failed finite read/copy retirement");
  std::array<float, 4> values{};
  check(take(input.view()).read(std::as_writable_bytes(std::span(values))));
  if (values != std::array<float, 4>{1.F, -2.F, 3.F, -4.F})
    throw std::runtime_error("CPU loader bytes differ from source");
  graph_roundtrip(backend,take(input.tensor(description)),values);
  std::array<float,17> exact{};std::array<std::uint16_t,17> bits{};
  for(std::size_t i=0;i<exact.size();++i){exact[i]=(float(i)-8.F)/4.F;bits[i]=std::uint16_t(std::bit_cast<std::uint32_t>(exact[i])>>16);}
  const auto bf16=take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,1>{17}));
  auto original=take(m::Buffer::create(backend.host_device(),sizeof(bits),64));
  check(backend.write(original.view(),std::as_bytes(std::span(bits))));
  graph_roundtrip(backend,take(c::ConstTensorView::create(bf16,original.view())),exact);
  check(pipeline.drain());
  check(backend.collect_retired());
  std::printf("{\"backend\":\"cpu+vulkan\",\"host_loaded_bytes\":16,\"targets\":2,\"storage_domains\":3,\"F32_values\":4,\"BF16_values\":17,\"episodes_each\":2,\"retired_unbind_rebind\":true,\"status\":\"PASS\"}\n");
}
} // namespace
int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("usage: backend_host_loader.exe payload.bin");
    run(argv[1]);
    return 0;
  } catch (const std::exception &error) {
    std::fprintf(stderr, "error: %s\n", error.what());
    return 1;
  }
}
