"""Audit only retained Hyle source/header identities, not SDK/model bodies."""
from pathlib import Path
import hashlib, json, subprocess
R=Path(__file__).resolve().parents[2]
S=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,j):Path(p).write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def norm(p):return str(Path(p).resolve()).lower()
def self_source(p):
    p=Path(p).resolve()
    return any(p.is_relative_to(R/name) for name in ['src','include','engine'])
def canonical(p):
    p=Path(p).resolve()
    if self_source(p):return p
    normalized=str(p).replace('\\','/')
    for marker,root in [('/src/',R/'src'),('/engine/',R/'engine'),('/hyle/',R/'include/hyle')]:
        if marker in normalized:
            candidate=root/normalized.rsplit(marker,1)[1]
            if candidate.is_file():return candidate.resolve()
    return None

command=read(S/'engine-attempt1/link-plan.json')['command']
compiler=Path(command[0]);lib=compiler.with_name('lib.exe')
objects={norm(x):dict(path=x,origin='direct') for x in command if x.lower().endswith('.obj')}
archives=[]
for item in command:
    p=Path(item)
    if not p.is_file() or p.suffix.lower()!='.lib':continue
    if not (p.name.startswith('hyle_') or 'gdn-vulkan-output-scale' in str(p)):continue
    listed=subprocess.run([str(lib),'/nologo','/list',str(p)],capture_output=True,check=True)
    members=listed.stdout.decode('utf8',errors='replace').splitlines()
    archives.append(dict(path=str(p),members=len(members)))
    for name in members:
        if name.lower().endswith('.obj'):
            objects.setdefault(norm(name),dict(path=name,origin=str(p)))

roots=[S,R/'.scratch/qwen-vulkan-multik-20261024/build1',R/'.scratch/qwen-vulkan-k1-20261024/build1',
 R/'.scratch/gdn-vulkan-output-scale-20261024/compile1',
 R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation',
 R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation',
 R/'.scratch/engine-product-20261024/cpu-budget-fix1',R/'.scratch/engine-product-20261024/cpu-build1',
 R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt2',
 R/'.scratch/q27-cold-search-20261024/fixed1',
 R/'.scratch/qwen35-unsloth-mtp-20261024/dense-cpu-check1',
 R/'.scratch/qwen35-unsloth-mtp-20261024/dense-vulkan-check1',
 R/'.scratch/qwen-native-lifetime-audit-20261024']
index={}
for root in roots:
    if not root.is_dir():continue
    for p in root.rglob('identity.json'):
        try:j=read(p)
        except Exception:continue
        if isinstance(j,dict) and isinstance(j.get('object'),dict) and isinstance(j.get('source'),dict):
            index[norm(j['object']['path'])]=(p,j)

def fallback(p):
    p=Path(p)
    options=[p.parent/'identity.json',p.parent/'records'/p.stem/'identity.json']
    for candidate in options:
        if candidate.is_file():
            j=read(candidate)
            if isinstance(j,dict) and j.get('object',{}).get('path') and norm(j['object']['path'])==norm(p):return candidate,j
    source=p.parent/'source.json';deps=p.parent/'deps.json'
    if source.exists() and p.name=='unit.obj':
        row=read(source)
        return source,dict(source=row,object=dict(path=str(p)),dependencies=[],
            boundary='Retained source hash exists; this old recorder did not retain per-header hashes.')
    return None

direct_sources={}
for key,item in objects.items():
    if item['origin']!='direct':continue
    found=index.get(key) or fallback(item['path'])
    if found:
        mapped=canonical(found[1]['source']['path'])
        if mapped:direct_sources[norm(mapped)]=key
results=[];changes={};unknown=[];superseded=[]
for key,item in objects.items():
    found=index.get(key) or fallback(item['path'])
    if not found:
        unknown.append(item);continue
    record,j=found
    source=j['source'];dependencies=j.get('dependencies',[])
    mapped_source=canonical(source['path'])
    if item['origin']!='direct' and mapped_source and norm(mapped_source)in direct_sources:
        superseded.append(dict(**item,source=source['path'],direct_override=objects[direct_sources[norm(mapped_source)]]['path']))
        continue
    checked=[];stale=[]
    for data in [source,*dependencies]:
        p=canonical(data['path'])
        if not p or 'sha256' not in data:continue
        current=sha(p) if p.is_file() else None
        checked.append(str(p.relative_to(R)))
        if current!=data['sha256']:
            change=dict(path=str(p.relative_to(R)),recorded=data['sha256'],current=current)
            stale.append(change);changes.setdefault(change['path'],change)
    results.append(dict(**item,record=str(record.relative_to(R)),source=source['path'],
        checked_self_files=len(checked),stale=stale,boundary=j.get('boundary')))
report=dict(scope='Finite link closure; only recorded Hyle canonical source/header identities are compared. No SDK/model bytes hashed.',
    link_plan=str((S/'engine-attempt1/link-plan.json').relative_to(R)),archives=archives,
    object_count=len(objects),recorded_objects=len(results),changed_recorded_objects=sum(bool(x['stale']) for x in results),
    distinct_changed_self_files=list(changes.values()),objects=results,unrecorded=unknown,superseded_archive_members=superseded,
    SDK_builds=0,HTTP=0,model_runs=0)
save(S/'closure-audit.json',report)
print(json.dumps({k:report[k]for k in ['object_count','recorded_objects','changed_recorded_objects','distinct_changed_self_files']},indent=2))
print('UNRECORDED',len(unknown))
