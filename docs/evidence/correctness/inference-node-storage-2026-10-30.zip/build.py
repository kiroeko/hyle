from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
PREV = R / '.scratch/inference-effect-views-20261030'
spec = importlib.util.spec_from_file_location('stage', R / '.scratch/inference-stage-resources-20261030/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.s.W = b.s.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def prepare():
    base = read(PREV / 'model-link-base.json')
    sdk = read(base['sdk_engine_dependencies']['path'])
    changed = {key(R / x) for x in subprocess.check_output(
        ['git','diff','--name-only','--','src','include','engine'], cwd=R, text=True).splitlines()}
    rows = {key(x['object']):x for x in sdk['inspected']}
    rows.update({key(x['object']):x for x in sdk['engine_consumers'] if 'dependencies' in x})
    actual_rows, unavailable, units = [], [], {}
    for item in base['retained']:
        exact(item)
        obj = Path(item['path'])
        row = rows.get(key(item['path']))
        for adjacent in (obj.parent/'dependencies.json',obj.with_name(obj.stem+'-deps.json'),obj.with_suffix('.deps.json')):
            if adjacent.is_file() and 'Data' in read(adjacent):
                row = dict(object=item['path'],dependencies=pin(adjacent))
                break
        if row is None:
            unavailable.append(item['path'])
            continue
        actual_rows.append(row)
        d = read(row['dependencies']['path'])['Data']
        if not any(key(x) in changed for x in [d['Source'],*d['Includes']]): continue
        args, recipe = b.s.command_for(item['path'],d['Source'])
        name = 'sdk-' + Path(d['Source']).relative_to(R).as_posix().replace('/','__').replace('.','_')
        units[name] = dict(source=d['Source'],original=item,recipe=recipe,compile=b.s.relocated(args,name))
    assert {'src/graph_batch/batch.cc','src/graph_batch/paged_append.cc','src/graph/slots_region.cc'} <= {
        Path(x['source']).relative_to(R).as_posix().lower() for x in units.values()}, units.keys()
    assert all(Path(x['source']).suffix.lower() == '.cc' for x in units.values())
    prior = read(PREV / 'plan.json')
    consumers = {name:dict(unit,compile=b.s.relocated(unit['compile'],name)) for name,unit in prior['consumers'].items()}
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'],W / 'bin' / Path(base['runtime']['path']).name)
    save(W / 'plan.json',dict(base=pin(PREV / 'model-link-base.json'),base_commit='c81aa4ef7',
        retained=base['retained'],runtime=base['runtime'],sdk=base['sdk_engine_dependencies'],
        original_link=base['link'],original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        units=units,consumers=consumers,actual_dependency_rows=actual_rows,unavailable_dependencies=unavailable,
        recursive=prior['cases']['recursive'],SDK_CXX=len(units),NVCC=0,downloads=0,performance_experiments=0,
        public_layout_changed=True,historical_baseline_already_executed=True))
    print(len(units),'actual SDK CXX and3 current consumer/test TUs;',227-len(units),
        'SDK inputs retained; no old-layout ABI mix, NVCC/download/benchmark.',flush=True)

def link(name,attempt):
    p = read(W / 'plan.json')
    if p.get('public_layout_changed') and name == 'baseline':
        raise ValueError('Historical old-layout baseline already executed; do not mix its SDK with new NodePlacement consumers.')
    retained = p['retained'] if name == 'baseline' else p['candidate_retained']
    objects = [read(W / 'compile' / x / 'receipt.json')['object'] for x in (('cli',) if name == 'cli' else ('views','paged'))]
    for item in [*retained,*objects]: exact(item)
    replacements = {key(a['path']):c['path'] for a,c in zip(p['retained'],retained)}
    args = []
    for arg in p['original_link']:
        if key(arg) == key(p['original_consumer']):
            args.extend(x['path'] for x in objects)
            continue
        arg = replacements.get(key(arg),arg)
        for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                break
        args.append(arg)
    if name != 'cli': args.extend(str(R / '.scratch/build-compute-v2-dev/lib' / x) for x in ('gtest_main.lib','gtest.lib'))
    b.s.b.execute(args,W / 'link' / name / attempt,240)
    save(W / ('ready-'+name+'.json'),pin(W / 'bin' / (name+'.exe')))

def run(name,attempt,filter=None,expected=None):
    p = read(W / 'plan.json')
    image = read(W / ('ready-'+('cli' if name == 'hybrid' else name)+'.json'));exact(image)
    folder = W / 'runs' / name / attempt
    save(folder / 'image.json',image)
    os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    args = [image['path']]
    if name in ('cli','hybrid'):
        model_args = list(p['recursive']['args'])
        if name == 'hybrid':
            model_args[model_args.index('--steps')+1] = '4'
            model_args[model_args.index('--mtp')+1] = 'off'
            index = model_args.index('--mtp-max-drafts')
            del model_args[index:index+2]
            model_args.extend(['--cpu-ffn-layers','2'])
        args.extend(model_args)
    else: args.extend(['--gtest_color=no','--gtest_filter='+filter,'--gtest_output=xml:'+str(folder / 'results.xml')])
    try: b.s.b.execute(args,folder,300)
    except SystemExit as error:
        if name != 'baseline' or error.code != 1: raise
    if name in ('cli','hybrid'):
        report = read(folder / 'stdout.log');assert report['live_committed_versions'] == 0
        if name == 'hybrid': assert report['cpu_ffn_layers'] == 2 and report['mtp'] is False
    else:
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(expected) and result.get('errors','0') == '0' and not result.findall('.//skipped')
        assert result.get('failures') == (str(expected) if name == 'baseline' else '0')
        report = dict(status='EXPECTED_ORIGINAL_DEFAULT_DOMAIN_ADMISSION_FAILURE' if name == 'baseline' else 'PASS',
            tests=expected,failures=int(result.get('failures')),skipped=0,
            cases=[dict(name=t.get('classname')+'.'+t.get('name'),
                failures=[v.text for v in t.findall('./failure')]) for t in result.findall('.//testcase')])
    save(folder / 'report.json',report)
    print(report.get('status','PASS'),name,flush=True)

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': b.compile_group(sys.argv[2],sys.argv[3:])
    elif action == 'seal': b.s.seal()
    elif action == 'link':
        for name in sys.argv[3:]: link(name,sys.argv[2])
    elif action == 'run': run(sys.argv[2],sys.argv[3],sys.argv[4] if len(sys.argv)>4 else None,int(sys.argv[5]) if len(sys.argv)>5 else None)
    else: raise ValueError(action)
