from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

SOURCES = ('include/hyle/graph/executable.h', 'engine/inference/graph_bindings.h',
    'src/graph/executable.cc', 'src/graph/effect_storage.h', 'src/graph/slots_region.h',
    'src/graph/slots_region.cc', 'src/graph_batch/batch.cc',
    'src/graph_batch/paged_append.h', 'src/graph_batch/paged_append.cc',
    'tests/tools/inference_submission_views_test.cc', 'tests/graph_batch/paged_append_source_test.cc')

def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items()
            if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list): return [stable(v) for v in value]
    return value

def historical_xml(relative):
    path = W / relative / 'results.xml'
    result = ET.parse(path).getroot()
    return dict(path=relative, tests=int(result.get('tests')),
        failures=int(result.get('failures')), errors=int(result.get('errors', '0')),
        cases=[dict(name=x.get('classname')+'.'+x.get('name'),
            failures=[y.text for y in x.findall('./failure')]) for x in result.findall('.//testcase')])

def prepare():
    p = read(W / 'plan.json')
    tests = read(W / 'runs/domains/node-storage-v2/report.json')
    recursive = read(W / 'runs/cli/node-storage-v2/report.json')
    hybrid = read(W / 'runs/hybrid/node-storage-v2/report.json')
    assert tests['tests'] == 17 and tests['failures'] == tests['skipped'] == 0
    anchor = b.PREV / 'runs/recursive/attempt1/report.json'
    assert stable(read(anchor)) == stable(recursive)
    assert hybrid['cpu_ffn_layers'] == 2 and hybrid['mtp'] is False
    assert hybrid['live_committed_versions'] == 0 and hybrid['generated_tokens'] == 4
    consumers = {}
    for name in p['consumers']:
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        for item in [receipt['object'], *receipt['source_identities']]: exact(item)
        consumers[name] = dict(receipt=pin(path), object=receipt['object'])
    for item in p['candidate_retained']: exact(item)
    assert len(p['units']) == 33 and len(p['candidate_retained']) == 227
    assert len(p['actual_dependency_rows']) == 158 and len(p['unavailable_dependencies']) == 69
    assert not [x for x in p['unavailable_dependencies']
        if '/graph' in x.replace('\\', '/').lower() or 'graph_' in x.lower()]
    previous = [historical_xml(x) for x in ('runs/baseline/attempt1',
        'runs/domains/attempt1', 'runs/domains/attempt2')]
    assert [(x['tests'], x['failures']) for x in previous] == [(2,2),(14,3),(14,3)]
    save(W / 'analysis.json', dict(status='PASS_FINITE_NODE_STORAGE_AND_EFFECT_OWNER_CHECKS',
        tests=17, finite_model_processes=2, failures=0, skipped=0,
        recursive_original_all_non_timing_fields_equal=True, recursive_baseline=pin(anchor),
        reports={name:pin(W / path) for name,path in {
            'tests':'runs/domains/node-storage-v2/report.json',
            'recursive':'runs/cli/node-storage-v2/report.json',
            'hybrid':'runs/hybrid/node-storage-v2/report.json'}.items()},
        historical_failures=previous,
        refinement_failure=dict(path='runs/domains/node-storage-v1',
            reason='Pinned H2D fixture used Commands despite original raw Copy lacking prepared-gap proof; Source refused, then early assertion unwind hit live-allocation guard.',
            fix='Only pinned-row producer uses original RequireCapture; no Source permission/runtime promise weakened.'),
        affected_SDK_CXX_units=33, affected_consumer_CXX_units=3, retained_SDK_inputs=194,
        actual_dependency_records=158, unavailable_dependency_records=69,
        Graph_objects_without_dependency_record=0, public_NodePlacement_layout_changed=True,
        ABI='Every affected SDK and current consumer rebuilt with the same NodePlacement definition. Historical baseline never relinked with new consumers.',
        NVCC=0, downloads=0, performance_experiments=0, performance_claim=False,
        checks=['Two actual Store banks and Page banks on one original CUDA Context/target/Queue.',
            'Wrong Store owner preserves partial cold metadata and original writer retry.',
            'Host rows retain exactly one original Graph Copy into the requested device bank.',
            'Preferred inaccessible pinned bank falls back to the original device bank.',
            'GraphBindings forwards actual node domain; two numerical Copy outputs need no inserted domain detour.',
            'Original Source pending/device_wait=1/host_wait=0, exact values, NaN/COW and old snapshots remain.',
            'Full P154+64 recursive K2 non-timing report unchanged; finite ordinary CPU+CUDA FFN2 generates four tokens and retires all versions.'],
        limits=['Not multi-GPU/cross-context support or a complete second engine model.',
            'No Apple/Vulkan native run or native fault injection in this batch.',
            'No throughput, peer or physical-memory benchmark; latest full performance window is unchanged.']))
    replacements = {key(a['path']):c['path'] for a,c in zip(p['retained'],p['candidate_retained'])}
    current_link = [consumers['cli']['object']['path'] if key(arg) == key(p['original_consumer'])
        else replacements.get(key(arg), arg) for arg in p['original_link']]
    base = read(p['base']['path'])
    base.update(schema='hyle.node-storage.current-link-base.v1', base=p['base'],
        current_consumers=consumers, previous_consumer=consumers['cli']['receipt'],
        consumer_source=pin(p['consumers']['cli']['source']), compile=p['consumers']['cli']['compile'],
        retained=p['candidate_retained'], sdk_engine_dependencies=p['candidate_sdk'], link=current_link,
        note='New NodePlacement layout: only the listed consumers have current-header receipts; historical family objects must be rebuilt before future links.')
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe','.dll','.lib','.exp')
        targets.append(pin(path))
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    diff = subprocess.check_output(['git','diff','--','include','src','engine','tests'], cwd=R)
    (W / 'product.diff').write_bytes(diff)
    print('PASS17 native tests + recursive report equality + finite CPU/CUDA FFN2; no performance claim.')

def finish():
    p, analysis = read(W / 'plan.json'), read(W / 'analysis.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'REMOVED_EXACT_FLAT_BATCH_IMAGES'
    shutil.copyfile(R / 'test.ps1', W / 'cleanup.ps1')
    out = R / 'docs/evidence/correctness/inference-node-storage-2026-10-30.json'
    save(out, dict(schema='hyle.correctness.node-storage.v1', date='2026-10-30', base_commit=p['base_commit'],
        status='EXPLICIT_NODE_STORAGE_AND_NATIVE_EFFECT_BANKS',
        contract=dict(node='NodePlacement.default_storage defaults selected-node allocation and effect bank; only applies on that actual target. Value/External/alias contracts retain precedence.',
            effects='Cold Store/Append candidates cover resources accessible by the original execution source. Required effect bank filters; preferred bank ranks with fallback. No inference from tensor source locality.',
            fusion='Each fused logical output uses its producer default; mixed-node workspace uses target default. No artificial fusion barrier.',
            authority='Original Context, Queue, Source, Store, Append, leases and retirement remain authoritative; cold placement spans are not retained by artifacts.',
            errors='Skip only non-native unsupported/inaccessible optional resource candidates; original errors and typed owner rejection/recovery remain.'),
        checks=analysis, final_common_review=read(W / 'architecture-review.json'),
        cleanup=cleanup, retained_build_plan=pin(W / 'model-link-base.json'),
        source_files=[pin(R / x) for x in SOURCES], archive='inference-node-storage-2026-10-30.zip'))
    files = [W / x for x in ('analysis.json','architecture-review.json','build.py','finish.py','product.diff','cleanup.ps1','cleanup-report.json','cleanup-targets.json')]
    for prefix in ('runs','compile','link'):
        files.extend(x for x in (W / prefix).rglob('*') if x.is_file() and x.suffix.lower() in ('.json','.log','.xml'))
    with zipfile.ZipFile(out.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(files)): archive.write(path, path.relative_to(W).as_posix())
        for path in SOURCES: archive.write(R / path, 'source/'+path)
    print('Recorded node-storage architecture change, failed refinements and bounded correctness checks.')

if __name__ == '__main__': {'prepare':prepare,'finish':finish}[sys.argv[1]]()
