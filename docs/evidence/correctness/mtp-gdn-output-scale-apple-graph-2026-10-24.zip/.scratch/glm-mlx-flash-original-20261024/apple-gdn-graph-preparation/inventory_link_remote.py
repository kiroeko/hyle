"""Read existing Apple Graph/MLX cache dependencies; no build or remote write."""
import collections
import hashlib
import json
import pathlib
import subprocess

BASE = pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation')
SDK = BASE / 'apple-current-sdk-2026-10-21'
SOURCE, BUILD = SDK / 'source', SDK / 'build'


def run(argv):
    result = subprocess.run(argv, capture_output=True, text=True)
    return dict(argv=argv, exit=result.returncode, stdout=result.stdout, stderr=result.stderr)


rows = json.loads((BUILD / 'compile_commands.json').read_text())
selected = [row for row in rows if any('/' + part + '/' in row['file']
    for part in ('error','time','platform','platform_thread','platform_fs','mem','mem_vm','container','sched','compute_ops','compute','graph','graph_progress','compute_batch','compute_ggml_runtime','graph_batch','compute_provider_ggml_metal','compute_route_apple','graph_route_apple','compute_state'))]
records, dependencies = [], set()
for row in selected:
    output = pathlib.Path(row['output'])
    if not output.is_absolute(): output = pathlib.Path(row['directory']) / output
    result = run(['/opt/homebrew/bin/ninja', '-C', str(BUILD), '-t', 'deps', str(output.relative_to(BUILD))])
    if result['exit'] != 0: raise RuntimeError(result)
    own = []
    for line in result['stdout'].splitlines()[1:]:
        value = pathlib.Path(line.strip())
        try: relative = value.relative_to(SOURCE)
        except ValueError: continue
        if relative.parts[0] in ('include', 'src'):
            own.append(relative.as_posix()); dependencies.add(relative.as_posix())
    records.append(dict(recipe=row, object_path=str(output), object_bytes=output.stat().st_size,
        dep_status=result['stdout'].splitlines()[0], own_dependencies=sorted(set(own))))
facts = {}
for name in sorted(dependencies):
    path = SOURCE / name; data = path.read_bytes()
    facts[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
result = dict(status='read_only_current_cache_inventory',
    hardware=[run(argv) for argv in (['sysctl', '-n', 'hw.model'], ['sysctl', '-n', 'hw.memsize'],
        ['sw_vers'], ['/usr/bin/clang++', '--version'], ['df', '-k', str(BASE)])],
    source=str(SOURCE), build=str(BUILD), current_gdn=str(BASE / 'gdn-output-scale-20261024/attempt2'),
    group_counts=dict(collections.Counter(pathlib.Path(row['file']).parent.name for row in selected)),
    records=records, own_dependency_facts=facts, remote_writes=0, builds=0, native_runs=0)
print(json.dumps(result))
