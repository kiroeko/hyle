"""Publish one actual current Apple Graph bridge, without running or building."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import zipfile

S=Path(__file__).resolve().parent
R=S.parents[2]
A=S/'actual-results'
spec=importlib.util.spec_from_file_location('_small_apple_graph_archive',R/'.scratch/glm-quark-selected-20261024/Q30/publish.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
helper.SMALL_SUFFIXES.update({'.mm','.hpp','.map','.md'})
read,identity=helper.read,helper.identity

def main():
 name='mtp-gdn-output-scale-apple-graph-2026-10-24'
 proof=R/'docs/evidence/correctness'/(name+'.json');target=proof.with_suffix('.zip')
 if proof.exists()or target.exists():raise ValueError('Keep published direct/Graph records immutable')
 actual=read(A/'actual-summary.json');checked=read(S/'canonical-dependency-check.json')
 assert(actual['status'],actual['tests'],actual['failures'],actual['skips'])==('passed',1,0,0)
 assert actual['host_translation_units']==63 and not checked['mismatches']
 inventory=read(S/'link-remote-inventory.json');delta=read(S/'link-current-dependency-delta.json')
 link=read(A/'logs/graph-link2/result.json')
 stable={}
 for row in link['inputs']:
  match=re.search(r'/relocated/sdk/lib/libhyle_([a-z_]+)\.a$',row['path'])
  if not match:continue
  module=match[1];records=[record for record in inventory['records']if '/source/src/'+module+'/' in record['recipe']['file']]
  assert records,module
  deps=set(x for record in records for x in record['own_dependencies'])
  changed=deps&delta['changed_dependencies'].keys()
  assert not changed,(module,changed)
  stable[module]=dict(library=row,source_objects=len(records),own_dependencies=len(deps),changed_dependencies=[])
 gdn=R/'.scratch/glm-mlx-flash-original-20261024/apple-gdn-scale-preparation/actual-results/actual-dependencies.json'
 old=read(gdn);matched=set()
 for row in old:
  if '/source/'not in row['path']:continue
  rel=row['path'].split('/source/',1)[1];path=R/rel
  if rel.startswith(('src/','include/')) and path.is_file():
   assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],rel
   matched.add(rel)
 assert len(matched)==141
 previous=R/'docs/evidence/correctness/mtp-gdn-output-scale-apple-2026-10-24.json'
 archive=helper.Archive([])
 for path in A.rglob('*'):
  if path.is_file()and path.suffix in helper.SMALL_SUFFIXES:archive.add(path)
 for path in [Path(__file__),S/'prepare.py',S/'inventory_remote.py',S/'inventory_link_remote.py',
              S/'remote-inventory.json',S/'link-remote-inventory.json',S/'link-current-dependency-delta.json',
              S/'canonical-dependency-check.json',S/'prepared.json',previous,gdn]:archive.add(path)
 result=dict(schema='hyle.correctness.apple-gdn-graph-bridge.v1',date='2026-10-24',status='passed',
  scope='One representative current common Graph/default Apple execution source, without model data or a systems/models matrix.',
  tests=1,failures=0,skips=0,actual=actual,
  hardware=inventory['hardware'],
  graph=dict(entry='hyle::graph::compile + hyle::graph::apple::execution_source(Context::create())',
    nodes=['BFloatLinearF32 F32[1,2,128] x BF16[1,128,128] -> F32[1,2,128]',
           'View Q -> [1,2,1,128]','GatedDeltaNet snapshot_count2/default scale',
           'GatedDeltaNet snapshot_count2/output_scale1'],
    fixture_invocations=2,published_outputs_per_invocation=5,
    checks=['F32 cancellation-sensitive activation low bits survive BF16-weight projection.',
      'Parallel default and raw1 final-dot scales keep their distinct semantics.',
      'Both state snapshots and original A/BF16 W/S input bytes remain intact.',
      'First invocation outputs remain intact after the second changed-input invocation.',
      'All returned GraphOutput owners survive Graph/Executable destruction.']),
  build=dict(host_translation_units=63,probe_translation_units=1,SDK_rebuilds=0,native_rebuilds=0,
    current_cmake_additions=['graph_route_apple/native_paged_append_region.cc','graph_batch/paged_append.cc','compute_batch/paged_append_program.cc'],
    fresh_compiled_own_dependencies=checked,
    reused_current_compute_and_native=dict(proof=identity(previous),actual_dependency_list=identity(gdn),
      matching_canonical_repo_dependencies=141,changed_dependencies=0,
      contracts=dict(provider=18,cpu_program_abi=3,recurrent_custom_id=9,native_gdn_scale='0x48594732')),
    retained_stable_core_libraries=stable,
    old_compiled_dependency_inventory=identity(S/'link-remote-inventory.json'),
    current_delta=identity(S/'link-current-dependency-delta.json'),
    source_bytes=read(S/'prepared.json')['source_bytes'],SDK_or_repo_tree_copied=False,
    cached_metallib='One hard link to the existing exact mlx.metallib; no download, SDK copy, or shader rebuild.'),
  history=dict(original_direct_record_unchanged=True,
    preparation_failures=['Precompile case-count adaptation guard was corrected back to CPU ABI3.',
      'Probe1 lacked cached GTest include; probe2 lacked explicit graph/executable.h.',
      'First link omitted two current CMake paged-append sources; both were actually compiled and included in link2.'],
    failed_records_retained=True,product_source_fixes=0,default_math_changed=False),
  limits=['One finite synthetic Graph is not a complete Apple model/MTP quality or performance result.',
    'The probe covers ordinary GDN output_scale; prior direct tests separately cover recurrent raw gates and inference-domain rejection.',
    'No Vulkan/Orin or other unrun backend is covered. No new throughput/memory claim.'],archive_files=[])
 with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for name,path in sorted(archive.files.items()):z.write(path,name)
 result['archive_files']=[dict(**identity(path),entry=name)for name,path in sorted(archive.files.items())]
 result['archive']=identity(target)
 proof.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 receipt=dict(proof=identity(proof),archive=identity(target),entries=len(archive.files),native_runs_by_publisher=0)
 (S/'publication.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

if __name__=='__main__':main()
