"""Collect this one current Graph bridge's small sources and actual records."""
from pathlib import Path
import hashlib
import json
import shlex
import tarfile
import xml.etree.ElementTree as ET

S=Path(__file__).resolve().parent
def identity(path):
 p=Path(path);data=p.read_bytes()
 return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def read(path):return json.loads(Path(path).read_text())
plan=read(S/'commands.json');manifest=read(S/'sync-manifest.json')
for item in manifest['files']:
 actual=identity(S/item['archive'])
 assert (actual['bytes'],actual['sha256'])==(item['local']['bytes'],item['local']['sha256'])
records=[]
for job in plan['host']+plan['probe']+plan['archive']+[plan['link']['metal'],plan['run']['metal']]+plan['preparation']:
 folder=S/'logs'/job['name'];result=read(folder/'result.json')
 assert result['exit_code']==0 and not result['timed_out'],job['name']
 assert read(folder/'command.json')==job,job['name']
 for expected in result['inputs']+result['outputs']:
  assert identity(expected['path'])==expected,expected['path']
 records.append(dict(name=job['name'],command=identity(folder/'command.json'),result=identity(folder/'result.json')))
root=ET.parse(S/'graph-tests2.xml').getroot()
assert int(root.get('tests'))==1 and all(int(root.get(x,'0'))==0 for x in ('failures','errors','disabled'))
assert not list(root.iter('skipped'))
case=list(root.iter('testcase'));assert len(case)==1
assert case[0].get('classname')== 'AppleGdnGraphBridge'
dependencies={}
for job in plan['host']+plan['probe']:
 dep=Path(job['outputs'][1]);words=shlex.split(dep.read_text().replace('\\\n',' '))
 assert words[0].endswith(':')
 for word in words[1:]:
  p=Path(word)
  # Restrict source facts to this project/its preserved overlays; SDK/MLX remain cached.
  if '/source/' in word:
   rel=word.split('/source/',1)[1]
   if rel.startswith(('src/','include/')):
    dependencies[(rel,word)]=dict(logical=rel,actual=identity(p))
maps=(S/'graph-bridge-checks2.map').read_text()
assert 'libhyle_graph_route_apple_current.a' in maps
assert '/metal-provider.o' in maps and '/metal-native-ops.o' in maps and '/metal-gdn-embed.o' in maps
assert 'libggml-metal.a(ggml-metal-ops.cpp.o)' not in maps
assert 'libggml-metal.a(ggml-metal-embed-gated_delta_net.s.o)' not in maps
facts=dict(status='passed',tests=1,failures=0,skips=0,host_translation_units=63,probe_translation_units=1,
 source_manifest=identity(S/'sync-manifest.json'),image=identity(S/'graph-bridge-checks2'),
 XML=identity(S/'graph-tests2.xml'),link_map=identity(S/'graph-bridge-checks2.map'),records=records,
 actual_own_dependencies=list(dependencies.values()),SDK_rebuilds=0,native_rebuilds=0,model_runs=0,
 scope='One current common Graph/default Apple source with mixed F32 by BF16 projection, parallel default/raw GDN and two snapshots; two explicit invocation phases and retained GraphOutput owners. No model/quality/performance claim.')
(S/'actual-summary.json').write_text(json.dumps(facts,indent=2)+'\n')
allowed={'.cc','.h','.cpp','.hpp','.mm','.py','.json','.xml','.log','.map','.d'}
with tarfile.open(S/'results.tar.gz','w:gz')as tar:
 for path in S.rglob('*'):
  if path.is_file() and path.suffix in allowed:tar.add(path,arcname=path.relative_to(S).as_posix())
print(json.dumps(dict(summary=identity(S/'actual-summary.json'),archive=identity(S/'results.tar.gz'))))
