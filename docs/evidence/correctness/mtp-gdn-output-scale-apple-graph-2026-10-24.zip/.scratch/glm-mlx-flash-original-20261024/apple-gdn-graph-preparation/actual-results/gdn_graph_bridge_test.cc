#include <gtest/gtest.h>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include "hyle/compute/apple_memory.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/apple.h"
#include "hyle/graph/executable.h"
#include "hyle/graph/result.h"

namespace {
namespace c=hyle::compute; namespace g=hyle::graph; namespace a=c::apple;
namespace m=hyle::mem;
template<class T> T take(hyle::Result<T> value,const char*where) {
  if(!value)throw std::runtime_error(std::string(where)+": "+std::string(value.error().message()));
  return std::move(*value);
}
void check(hyle::Status status,const char*where) {
  if(!status.ok())throw std::runtime_error(std::string(where)+": "+std::string(status.message()));
}
c::TensorDesc dense(c::DataType type,std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(type,{shape.begin(),shape.size()}),"description");
}
std::vector<float> read(const g::GraphOutput &output) {
  const auto view=take(output.tensor(),"retained output tensor");
  std::vector<float> values(take(view.description().element_count(),"output extent"));
  check(view.storage().read(std::as_writable_bytes(std::span(values))),"read retained output");
  return values;
}

TEST(AppleGdnGraphBridge, MixedBfloatProjectionDefaultAndRawRetainSnapshotsAndOwners) {
  constexpr std::int64_t D=128;
  constexpr float delta=1.F/1048576.F;
  auto context=take(a::Context::create(),"default Apple context");
  auto memory=take(a::MemoryResource::create(context),"Apple memory");
  const std::array domains{g::StorageDomain{memory.ref()}};
  const std::array targets{g::ExecutionTarget{take(g::apple::execution_source(context),"Apple Graph source"),g::StorageDomainId{0}}};
  const std::array descriptions{dense(c::DataType::kFloat32,{1,2,D}),
      dense(c::DataType::kBFloat16,{1,D,D}),dense(c::DataType::kFloat32,{1,2,1,D}),
      dense(c::DataType::kFloat32,{1,2,1,D}),dense(c::DataType::kFloat32,{1,2,1,D}),
      dense(c::DataType::kFloat32,{1,2,1,1}),dense(c::DataType::kFloat32,{1,1,D,D})};
  auto builder=take(g::GraphBuilder::create(),"builder");
  std::array<g::ValueId,7> inputs;
  for(std::size_t i=0;i<inputs.size();++i)inputs[i]=take(builder.input(descriptions[i]),"input");
  const auto projected=take(builder.add(c::model_ops::bfloat_linear_f32(),inputs[0],inputs[1]),"F32 by BF16 batch");
  const auto shape=take(c::TensorShape::create(std::array<std::int64_t,4>{1,2,1,D}),"Q shape");
  const auto q=take(builder.add(take(c::View::reshape(shape),"Q view"),projected),"Q view node");
  const std::array ports{q,inputs[2],inputs[3],inputs[4],inputs[5],inputs[6]};
  std::array<g::ValueId,5> outputs{projected};
  for(std::size_t mode=0;mode<2;++mode) {
    const auto scale=mode?std::optional<float>{1.F}:std::optional<float>{};
    const auto node=take(builder.add_node(c::Operation(c::GatedDeltaNet{.snapshot_count=2,.output_scale=scale}),ports),"GDN");
    outputs[1+mode*2]=take(builder.result(node,0),"Y");
    outputs[2+mode*2]=take(builder.result(node,1),"S snapshots");
  }
  for(auto output:outputs)check(builder.publish(output),"publish");
  auto graph=take(std::move(builder).finish(),"finish");
  auto compiled=take(g::compile(graph,{domains,targets}),"common Graph compile");
  ASSERT_GT(compiled.report.step_count(),0U);
  for(std::size_t i=0;i<compiled.report.step_count();++i) {
    const auto step=take(compiled.report.step(i),"step");
    if(step.kind==g::CompileStepKind::kProviderRegion)
      EXPECT_EQ(step.runtime.mode,c::ProviderRuntimeMode::kDelegated);
  }
  std::array<m::Buffer,7> buffers;
  for(std::size_t i=0;i<buffers.size();++i)
    buffers[i]=take(m::Buffer::create(memory.ref(),take(descriptions[i].required_bytes(),"buffer bytes"),256),"input buffer");
  std::vector<std::uint16_t> weights(D*D,0);
  for(std::size_t i=0;i<std::size_t(D);++i)weights[i*D+i]=0x3f80U;
  check(buffers[1].view().write(std::as_bytes(std::span(weights))),"original BF16 W bytes");
  const std::vector<float> zeros(2*D,0.F),beta(2,0.F);
  for(std::size_t i=2;i<=4;++i)check(buffers[i].view().write(std::as_bytes(std::span(zeros))),"zero K/V/g");
  check(buffers[5].view().write(std::as_bytes(std::span(beta))),"zero beta");
  std::vector<float> state(D*D,0.F);
  for(std::size_t row=0;row<std::size_t(D);++row)state[row*D]=state[row*D+1]=float(row%3+1);
  check(buffers[6].view().write(std::as_bytes(std::span(state))),"retained initial S");
  std::array<std::array<g::GraphOutput,5>,2> retained;
  for(std::size_t phase=0;phase<2;++phase) {
    std::vector<float> activation(2*D,0.F);
    for(std::size_t t=0;t<2;++t) {activation[t*D]=1.F+delta*float(phase+1);activation[t*D+1]=-1.F;}
    check(buffers[0].view().write(std::as_bytes(std::span(activation))),"actual F32 A");
    auto invocation=take(compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"Graph invocation");
    for(std::size_t i=0;i<inputs.size();++i)
      check(invocation.bind(inputs[i],take(c::ConstTensorView::create(descriptions[i],buffers[i].view()),"native tensor")),"bind");
    check(invocation.prepare_replay({}),"Graph prepare");
    auto completion=take(invocation.submit({}),"Graph submit");check(completion.wait(),"Graph completed");
    for(std::size_t i=0;i<outputs.size();++i)retained[phase][i]=take(invocation.result(outputs[i]),"Graph output");
    EXPECT_EQ(read(retained[phase][0]),activation); // No F32 activation narrowing.
    std::vector<float> still(state.size());
    check(buffers[6].view().read(std::as_writable_bytes(std::span(still))),"initial S after Graph");
    EXPECT_EQ(still,state);
    std::vector<float> still_a(activation.size());
    check(buffers[0].view().read(std::as_writable_bytes(std::span(still_a))),"A after Graph");
    EXPECT_EQ(still_a,activation);
  }
  compiled={};graph={}; // Returned aliases retain the actual native owner.
  for(std::size_t phase=0;phase<2;++phase) {
    for(std::size_t mode=0;mode<2;++mode) {
      const auto scores=read(retained[phase][1+mode*2]);
      const auto snapshots=read(retained[phase][2+mode*2]);
      ASSERT_EQ(scores.size(),2U*D);ASSERT_EQ(snapshots.size(),2U*state.size());
      for(std::size_t i=0;i<scores.size();++i) {
        const float raw=float((i%std::size_t(D))%3+1)*delta*float(phase+1);
        if(mode)EXPECT_EQ(scores[i],raw);
        else EXPECT_NEAR(scores[i],raw/std::sqrt(float(D)),1.e-12F);
      }
      for(std::size_t i=0;i<snapshots.size();++i)EXPECT_EQ(snapshots[i],state[i%state.size()]);
    }
  }
  std::vector<std::uint16_t> still_w(weights.size());
  check(buffers[1].view().read(std::as_writable_bytes(std::span(still_w))),"original W after Graph");
  EXPECT_EQ(still_w,weights);
}
} // namespace
