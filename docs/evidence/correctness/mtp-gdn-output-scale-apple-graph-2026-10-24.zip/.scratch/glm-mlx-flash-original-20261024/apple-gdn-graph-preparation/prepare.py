"""Prepare one current Apple Graph bridge using existing host/native caches."""
from pathlib import Path
import hashlib
import json
import re
import shlex
import tarfile

S=Path(__file__).resolve().parent
R=S.parents[2]
OLD=S.parent/'apple-gdn-scale-preparation'
BASE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation'
SDK=BASE+'/apple-current-sdk-2026-10-21'
OUT=BASE+'/gdn-graph-bridge-20261024/attempt1'
GDN=BASE+'/gdn-output-scale-20261024/attempt2'
inv=json.loads((S/'link-remote-inventory.json').read_text())
delta=json.loads((S/'link-current-dependency-delta.json').read_text())
gdn=json.loads((OLD/'commands.json').read_text())

def identity(path):
 p=Path(path);raw=p.read_bytes()
 return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def relative(row):return row['recipe']['file'].split('/source/',1)[1]
provided={}
for job in gdn['host']:
 for source in job['inputs']:
  if '/source/src/' in source:
   provided[source.split('/source/',1)[1]]=job['outputs'][0]
affected={row['source'] for row in delta['affected_records']}
records={relative(row):row for row in inv['records'] if '/source/src/' in row['recipe']['file']}
recompile=[name for name in records if name in affected and name not in provided]
new='src/graph_route_apple/native_paged_append_region.cc'
assert new not in records
base=records['src/graph_route_apple/native_paged_region.cc']
records[new]=dict(recipe=dict(base['recipe'],file=base['recipe']['file'].replace('native_paged_region.cc','native_paged_append_region.cc')),
                 own_dependencies=base['own_dependencies'])
recompile.append(new)
extra_sources=('src/graph_batch/paged_append.cc','src/compute_batch/paged_append_program.cc')
for source,recipe_source in zip(extra_sources,('src/graph_batch/native_pending_regions.cc','src/compute_batch/batch_paged_native.cc')):
 assert source not in records
 base=records[recipe_source]
 records[source]=dict(recipe=dict(base['recipe'],file=SDK+'/source/'+source),own_dependencies=base['own_dependencies'])
 recompile.append(source)
assert len(recompile)==63
files=set()
for name in recompile:
 files.add(name)
 files.update(x for x in records[name]['own_dependencies'] if (R/x).is_file())
files.add(new)
# Include newly introduced local headers too; external SDK/vendor headers stay cached.
todo=list(files)
while todo:
 name=todo.pop();p=R/name
 for include in re.findall(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]',p.read_text(encoding='utf-8',errors='replace'),re.M):
  candidates=[p.parent/include,R/'include'/include,R/'src/compute'/include]
  for candidate in candidates:
   if candidate.is_file() and candidate.resolve().is_relative_to(R):
    rel=candidate.resolve().relative_to(R).as_posix()
    if rel.startswith(('src/','include/')) and rel not in files:files.add(rel);todo.append(rel)
    break
jobs=[];objects={}
for name in recompile:
 row=records[name];argv=shlex.split(row['recipe']['command'])
 old_source=row['recipe']['file'];out=OUT+'/'+name.replace('/','--')+'.o'
 argv[argv.index('-o')+1]=out
 argv[argv.index('-c')+1]=OUT+'/source/'+name
 argv[1:1]=['-I'+OUT+'/source/include','-I'+OUT+'/source/'+str(Path(name).parent).replace('\\','/'),
              '-I'+OUT+'/source/src/compute','-I'+GDN+'/source/include']
 argv+=['-MD','-MF',out+'.d']
 jobs.append(dict(name=name.replace('/','--'),cwd=OUT,argv=argv,inputs=[OUT+'/source/'+name],outputs=[out,out+'.d']))
 objects[name]=out
probe=OUT+'/gdn_graph_bridge_test.cc';probeobj=OUT+'/probe3.o'
argv=shlex.split(records['src/graph_route_apple/apple_lowering.cc']['recipe']['command'])
argv[argv.index('-o')+1]=probeobj
argv[argv.index('-c')+1]=probe
test=gdn['host'][-1]
metaltest=next(job for job in gdn['host'] if job['name']=='metal-test')
includes=['-isystem',metaltest['argv'][metaltest['argv'].index('-isystem')+1]]
argv[1:1]=['-I'+OUT+'/source/include','-I'+GDN+'/source/include',*includes]
argv+=['-MD','-MF',probeobj+'.d']
probejob=dict(name='probe3',cwd=OUT,argv=argv,inputs=[probe],outputs=[probeobj,probeobj+'.d'])
groups=['graph','graph_route_apple','compute_route_apple','graph_progress','compute_batch','graph_batch','compute_state','mem_vm']
archives=[];newlibs=[]
for group in groups:
 members=[]
 for name,row in records.items():
  if not name.startswith('src/'+group+'/'):continue
  members.append(objects.get(name,provided.get(name,row.get('object_path'))))
 assert all(members),group
 suffix='current2' if group in ('compute_batch','graph_batch') else 'current'
 lib=OUT+'/libhyle_'+group+'_'+suffix+'.a';newlibs.append(lib)
 archives.append(dict(name=('archive2-' if suffix=='current2' else 'archive-')+group,cwd=OUT,argv=['/usr/bin/libtool','-static','-o',lib,*members],inputs=members,outputs=[lib]))
link=dict(gdn['link']['metal']);argv=list(link['argv'])
argv=[probeobj if x==GDN+'/metal-test.o' else x for x in argv]
argv[argv.index('-o')+1]=OUT+'/graph-bridge-checks2'
argv=[x.replace(GDN+'/metal-gdn-scale-checks.map',OUT+'/graph-bridge-checks2.map') for x in argv]
extra=[SDK+'/relocated/sdk/lib/libmlx.a',SDK+'/relocated/sdk/lib/libhyle_sched.a',SDK+'/relocated/sdk/lib/libhyle_platform_fs.a']
argv[1:1]=[*newlibs,*extra]
argv+=['-framework','Accelerate','-framework','MetalPerformanceShaders','-framework','QuartzCore']
link.update(name='graph-link2',cwd=OUT,argv=argv,inputs=[x for x in argv if x.endswith(('.o','.a','.dylib'))],
            outputs=[OUT+'/graph-bridge-checks2',OUT+'/graph-bridge-checks2.map'])
run=dict(name='graph-run2',cwd=OUT,argv=[OUT+'/graph-bridge-checks2','--gtest_filter=AppleGdnGraphBridge.*',
    '--gtest_throw_on_failure=1','--gtest_output=xml:'+OUT+'/graph-tests2.xml'],
    inputs=[OUT+'/graph-bridge-checks2'],outputs=[OUT+'/graph-tests2.xml'],expected_cases=1)
metallib=SDK+'/relocated/sdk/lib/mlx.metallib'
runtime_link=dict(name='retain-cached-metallib',cwd=OUT,
    argv=['python3','-c','import os; os.link('+repr(metallib)+','+repr(OUT+'/mlx.metallib')+')'],
    inputs=[metallib],outputs=[OUT+'/mlx.metallib'])
commands=dict(remote_directory=OUT,required_contracts=gdn['required_contracts'],host=jobs,archive=archives,
              link={'metal':link},run={'metal':run},probe=[probejob],native=[],preparation=[runtime_link],
              extra=[job for job in jobs if job['name'] in {x.replace('/','--') for x in extra_sources}],
              archive2=[job for job in archives if job['name'].startswith('archive2-')],
              SDK_builds=0,native_rebuilds=0,probe_scope='One common Graph over default Apple execution source, batched F32 by BF16 projection and parallel default/raw GDN, snapshots, retained native output owners.')
save(S/'commands.json',commands)
runner=(OLD/'run_commands.py').read_text()
runner=runner.replace("choices=('preparation', 'native', 'host', 'archive', 'link', 'run')", "choices=('preparation', 'native', 'host', 'probe', 'extra', 'archive', 'archive2', 'link', 'run')")
runner=runner.replace("job['expected_cases'] == 3", "job['expected_cases'] == 1").replace('tests=3','tests=1')
runner=runner.replace('CPU explicit ggml provider or direct Metal NativeProgram; default/raw GDN/KDA/Recurrent, two snapshots, retained state and cold optional/finite domains. No Graph/default Apple Context claim.',
    'Current common Graph/default Apple source bridge: batched F32 by BF16 projection, parallel default/raw GDN, two snapshots, input and output owner retention. No model quality/TPS claim.')
(S/'run_commands.py').write_text(runner,encoding='utf-8')
manifest=[]
with tarfile.open(S/'focused-source.tar.gz','w:gz') as tar:
 for name in sorted(files):
  path=R/name;arc='source/'+name;tar.add(path,arcname=arc)
  manifest.append(dict(archive=arc,local=identity(path)))
 for name in ['commands.json','run_commands.py','gdn_graph_bridge_test.cc']:
  tar.add(S/name,arcname=name);manifest.append(dict(archive=name,local=identity(S/name)))
 save(S/'sync-manifest.json',dict(remote_directory=OUT,files=manifest))
 tar.add(S/'sync-manifest.json',arcname='sync-manifest.json')
save(S/'prepared.json',dict(remote_directory=OUT,host_translation_units=63,probe_translation_units=1,
    files=len(files),source_bytes=sum((R/name).stat().st_size for name in files),
    package=identity(S/'focused-source.tar.gz'),current_gdn_dependencies=141,changed_gdn_dependencies=0,
    old_dependency_inventory=identity(S/'link-remote-inventory.json'),current_dependency_delta=identity(S/'link-current-dependency-delta.json'),
    SDK_copies=0,native_builds=0,build_executed=False,native_executed=False))
print((S/'prepared.json').read_text())
