"""Serial root-only B1/B2/peer window. Independent memory processes."""
from pathlib import Path
import argparse,importlib.util,json,os,re,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[1]
F=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21'
sp=importlib.util.spec_from_file_location('runner',F/'multiturn/multiturn_run.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
sp=importlib.util.spec_from_file_location('observer',R/'.scratch/shared-execution-20261021/observer.py');observer=importlib.util.module_from_spec(sp);sp.loader.exec_module(observer);observer.install(m)
p=argparse.ArgumentParser();p.add_argument('mode',choices=('timing','memory'));a=p.parse_args()
out=D/'performance'/a.mode;out.mkdir(parents=True,exist_ok=False)
manifest=D/'performance-sessions.txt';schedule=F/'multiturn/inputs/long/schedule.txt'
text=''.join(name+' '+str(schedule)+'\n'for name in ('alice','bob'))
if manifest.exists():assert manifest.read_text()==text
else:manifest.write_text(text)
receipts=dict(serial=D/'qwen-ready-attempt3.json',batch=D/'qwen-ready-attempt3.json',peer=D/'peer-ready.json')
images={k:m.ready_image(v)for k,v in receipts.items()}
hc,pc=m.original_commands();inputs=hc[hc.index('--inputs')+1];model=pc[1]
order=['serial','batch','peer','peer','batch','serial','batch','serial','peer']if a.mode=='timing'else['serial','batch','peer']
commands=[]
for i,variant in enumerate(order,1):
    folder=out/f'{i:02}-{variant}'
    if variant=='peer':command=[images[variant]['path'],model,'--session-schedules',str(manifest),'--capacity','1024','--cache-slots','2','--active-sequences','2','--pool-tokens','2048','--prefix-cache','off','--result',str(folder/'peer-result.json')]
    else:command=[images[variant]['path'],'--inputs',inputs,'--session-schedules',str(manifest),'--capacity','1024','--max-sessions','2','--active-sequences','1'if variant=='serial'else'2','--prefix-cache','off','--progress','direct','--replay','auto']
    commands.append(dict(variant=variant,folder=str(folder),command=command))
m.save(out/'inputs.json',dict(receipts={k:m.identity(v)for k,v in receipts.items()},images=images,manifest=m.identity(manifest),original_schedule=m.identity(schedule),commands=commands,mode=a.mode,profiler=False,diagnostic=False,concurrent_GPU=False,teacher_forced=True,synthetic=True,independent_quality_acceptance=False,scope='Two independent sessions of retained three-round fixed-token journey; same1728logical/actual input tokens,198returned decisions (1536prefill/192decode), C1024/N2, prefixoff/no eviction. Serial HyleR1 is same source/image; HyleB2 and llamaB2 use same equal-T wave order. Each owns complete hybrid recurrent state. Original token files and SDKs reused; no copied model.'))
runs=[];reference={};m.gpu_snapshot(out,'window-before')
try:
    for i,entry in enumerate(commands,1):
        variant=entry['variant'];folder=Path(entry['folder']);print('BATCH_BEGIN',a.mode,i,variant,flush=True)
        env=os.environ.copy();env['PATH']=m.read(m.read(receipts[variant])['runtime_environment']['path'])['PATH']
        process=m.execute(folder,'peer'if variant=='peer'else'hyle',entry['command'],env,a.mode=='memory')
        raw=m.read(folder/'peer-result.json')if variant=='peer'else json.loads((folder/'stdout.log').read_text(encoding='utf-8'))
        assert raw['processed_tokens']==1728 and raw['generated_tokens']==198 and raw['actual_graph_tokens']==1728 and raw['reused_tokens']==0
        waves=raw['waves'];assert all(w['kind']in('prefill','decode')for w in waves)
        assert sum(w['logical_tokens']for w in waves)==1728 and sum(w['actual_tokens']for w in waves)==1728 and sum(w['outputs']for w in waves)==198
        expected_calls=198 if variant=='serial' else 99
        assert raw['actual_graph_calls']==expected_calls and sum(w['graph_calls']for w in waves)==expected_calls
        if variant=='peer':
            episodes=raw['episodes'];assert all(x['requests']==2 for x in episodes)
            physical=[(x['kind'],x['T'],tuple(row['session']for row in x['members']))for x in episodes]
        else:
            assert raw['max_batch_requests']==(1 if variant=='serial' else 2)
            assert not any(s['restored_calls']or s['recomputed_decision_changes']for s in raw['sessions'])
            physical=[(x['kind'],x['query_rows'],tuple(x['session_ids']))for x in raw['batches']]
        if variant in('peer','batch'):
            if 'batch_order'in reference:assert physical==reference['batch_order']
            else:reference['batch_order']=physical
        ids={s['id'if variant=='peer'else'session_id']:s['generated_ids']for s in raw['sessions']}
        if variant in reference:assert ids==reference[variant]
        else:reference[variant]=ids
        phase_seconds={kind:sum(w['seconds']for w in waves if w['kind']==kind)for kind in('prefill','decode')}
        wall=raw['session_seconds'if variant=='peer'else'interleaved_seconds']
        assert 0<sum(phase_seconds.values())<=wall*1.001
        if variant=='peer':loading=dict(load_seconds=raw['model_load_seconds'],ready_seconds=raw['ready_seconds'])
        else:
            stderr=(folder/'stderr.log').read_text();match=re.search(r'initialized model_seconds=([^ ]+) shape_prepare_seconds=([^ ]+) startup_to_ready_seconds=([^\n]+)',stderr)
            loading=dict(load_seconds=float(re.search(r'weights_load_seconds=([^\n]+)',stderr)[1]),ready_seconds=float(match[3]),model_seconds=float(match[1]),shape_prepare_seconds=float(match[2]))
        metrics=dict(prefill_tps=1536/phase_seconds['prefill'],full_decode_tps=192/phase_seconds['decode'],session_output_tps=198/wall,session_seconds=wall,startup_total_seconds=raw['startup_total_seconds'],**loading)
        observation=dict(raw=raw,metrics=metrics,phase_seconds=phase_seconds,ids=ids)
        m.save(folder/'observation.json',observation);runs.append(dict(variant=variant,folder=str(folder),process=process,observation=observation));m.save(out/'runs.json',runs)
        print('BATCH_END',a.mode,i,variant,metrics,flush=True)
finally:m.gpu_snapshot(out,'window-after')
if a.mode=='timing':groups={v:{k:m.stats([r['observation']['metrics'][k]for r in runs if r['variant']==v])for k in next(r for r in runs if r['variant']==v)['observation']['metrics']}for v in receipts}
else:groups={v:m.read(Path(next(r for r in runs if r['variant']==v)['folder'])/'memory-summary.json')for v in receipts}
diffs={}
for v in('serial','peer'):
    diffs[v]=[dict(session=s,call=i,batch=b,other=o)for s in reference['batch']for i,(b,o)in enumerate(zip(reference['batch'][s],reference[v][s]))if b!=o]
m.save(out/'summary.json',dict(groups=groups,processes=len(runs),identical_actual_inputs=True,batch_episode_order_equal=True,within_arm_ids_equal=True,greedy_id_differences=diffs,throughput_evidence=a.mode=='timing',quality_acceptance=False,statistical_significance=False,limits=['Batch-size changes can alter legal BF16 reductions. Greedy mismatches are reported, never filtered or promoted to quality acceptance.','These are two synchronized synthetic fixed-token sessions, not free-running serving latency or a four-user forecast.','Same C/N/R and tokens do not make backing allocations or failure/cancellation contracts identical. Hyle hasN+R snapshot pools; peer can update unretained native versions in place.','Memory processes are sampled separately; unknown/missing counters remain null. One desktop GPU, fresh processes, OS page cache not cleared.']))
print('BATCH_COMPLETE',a.mode,len(runs),flush=True)
