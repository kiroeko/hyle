"""Explicit cached four-product-TU build, optional one test TU; no native runs.

After root SOURCE_FROZEN: plan [TEST_SOURCE.cc], then build.
Default prints usage only. Existing Model/weights/SDK archives are never rebuilt.
"""
from pathlib import Path
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-host-image-20261026'
CURRENT = R/'.scratch/inference-current-closure-20261026'
spec = importlib.util.spec_from_file_location('retained_helpers', B/'build.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
b = previous.b
CXX_RECIPE = CURRENT/'headers79/compute_provider_cuda--cuda_provider_cc/command.json'
GGML_RECIPE = R/'.scratch/dense-linear-f32-20261024/tensor-program/command.json'
NVCC_RECIPE = CURRENT/'native-current/scatter_kernel/command.json'
OLD_PROVIDER = CURRENT/'headers79/compute_provider_cuda--cuda_provider_cc/unit.obj'
OLD_TENSOR = R/'.scratch/dense-linear-f32-20261024/tensor-program/tensor-program.obj'
UNITS = (('kernel', 'src/compute_provider_cuda/causal_conv_kernel.cu', NVCC_RECIPE),
    ('provider', 'src/compute_provider_cuda/causal_conv_provider.cc', CXX_RECIPE),
    ('registration', 'src/compute_provider_cuda/cuda_provider.cc', CXX_RECIPE),
    ('ggml-supports', 'src/compute_provider_ggml_cuda/tensor_program.cc', GGML_RECIPE))


def commands(source, recipe, folder):
    old = b.read(recipe)['command']
    if source.suffix != '.cu': return b.compile_command(recipe, source, folder)
    original_source = next(arg for arg in old if arg.lower().endswith('.cu'))
    obj = old[old.index('-o')+1]; dep = old[old.index('-MF')+1]
    pdb = str(Path(obj).with_suffix('.pdb'))
    result = [str(source) if arg == original_source else str(folder/'unit.obj') if arg == obj
        else str(folder/'unit.d') if arg == dep else arg.replace(pdb, str(folder/'unit.pdb')) for arg in old]
    assert '--generate-code=arch=compute_89,code=[sm_89]' in result
    return result


def closure(seeds, recipes):
    dirs = [R, R/'include']
    for recipe in recipes:
        for arg in b.read(recipe)['command']:
            for prefix in ('/external:I', '/I', '-I'):
                if arg.startswith(prefix):
                    path = Path(arg[len(prefix):]).resolve()
                    if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'): dirs.append(path)
                    break
    todo, found = list(seeds), {}
    while todo:
        path = Path(todo.pop()).resolve()
        if b.key(path) in found: continue
        assert path.is_relative_to(R) and not path.is_relative_to(R/'.scratch')
        found[b.key(path)] = b.pin(path)
        for include in re.findall(r'^\s*#\s*include\s*["<]([^">\r\n]+)[">]', path.read_text(encoding='utf-8-sig'), re.M):
            for base in [path.parent, *dirs]:
                child = (base/include).resolve()
                if child.is_file():
                    if child.is_relative_to(R) and not child.is_relative_to(R/'.scratch'): todo.append(child)
                    break
    return list(found.values())


def plan(test=None):
    assert not (W/'plan.json').exists(), 'Preserve each frozen attempt'
    jobs = list(UNITS)
    if test:
        source = (R/test).resolve(); assert source.is_file() and source.is_relative_to(R/'tests')
        jobs.append(('test', str(source), B/'product2/compile/command.json'))
    units = [dict(name=name, source=b.pin(R/source), recipe=b.pin(recipe),
        language='CUDA' if Path(source).suffix == '.cu' else 'CXX',
        command=commands(R/source, recipe, W/'compile'/name)) for name,source,recipe in jobs]
    frozen = closure([row['source']['path'] for row in units], [recipe for _,_,recipe in jobs])
    b.save(W/'source-freeze.json', frozen)
    forced = [b.pin(arg[3:]) for row in units for arg in row['command'] if arg.startswith('/FI')]
    baselines = {}
    for name,folder in (('cli', B/'product2'), ('case', B/'cuda4')):
        ready = b.read(folder/'ready.json')
        for field in ('image', 'link_inputs', 'runtime', 'object'): b.exact(ready[field])
        inputs = b.read(ready['link_inputs']['path'])
        assert sum(b.key(row['path']) == b.key(OLD_PROVIDER) for row in inputs) == 1
        assert sum(b.key(row['path']) == b.key(OLD_TENSOR) for row in inputs) == 1
        for row in inputs: b.exact(row)
        b.save(W/(name+'-inputs-before.json'), inputs)
        baselines[name] = dict(ready=b.pin(folder/'ready.json'), image=ready['image'], object=ready['object'],
            runtime=ready['runtime'], inputs=b.pin(W/(name+'-inputs-before.json')),
            link_recipe=b.pin(folder/'link/command.json'))
    test_dependencies = None
    if test:
        test_command = next(row['command'] for row in units if row['name'] == 'test')
        gtest_include = next(arg[len('/external:I'):] for arg in test_command
            if arg.startswith('/external:I') and 'googletest' in arg)
        gtest_libraries = [row for row in b.read(baselines['cli']['inputs']['path'])
            if Path(row['path']).name.lower() in ('gtest_main.lib', 'gtest.lib')]
        assert len(gtest_libraries) == 2
        for row in gtest_libraries: b.exact(row)
        test_dependencies = dict(header=b.pin(Path(gtest_include)/'gtest/gtest.h'),
            libraries=gtest_libraries,
            origin='Already present in actual product2 CUDA compile/link recipes; no library build or CPU closure substitution.')
    b.save(W/'plan.json', dict(status='SOURCE_FROZEN_NOT_BUILT_OR_RUN', baseline_commit='b83710410',
        units=units, source_freeze=b.pin(W/'source-freeze.json'), declared_forced_includes=forced,
        baselines=baselines, replaced_provider=b.pin(OLD_PROVIDER), replaced_tensor=b.pin(OLD_TENSOR),
        test_dependencies=test_dependencies,
        product_TUs=4, test_TUs=int(test is not None), archive_rewrites=0,
        scope='Replace two existing direct OBJ inputs, append native causal-conv provider/kernel; reuse exact feature-consistent CUDA CLI and case closures.'))
    print('CAUSAL_CONV_PLAN', json.dumps(b.pin(W/'plan.json')), flush=True)


def build():
    plan = b.read(W/'plan.json')
    assert not (W/'compile').exists() and not (W/'ready.json').exists()
    b.exact(plan['source_freeze'])
    frozen = b.read(plan['source_freeze']['path'])
    for row in [*frozen, *plan['declared_forced_includes']]: b.exact(row)
    if plan['test_dependencies']:
        b.exact(plan['test_dependencies']['header'])
        for row in plan['test_dependencies']['libraries']: b.exact(row)
    for baseline in plan['baselines'].values():
        for field in ('ready', 'image', 'object', 'runtime', 'inputs', 'link_recipe'): b.exact(baseline[field])
        for row in b.read(baseline['inputs']['path']): b.exact(row)
    h = b.helper()
    compiler = b.read(CXX_RECIPE)['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    objects, results = {}, []
    by_key = {b.key(row['path']):row for row in frozen}
    for unit in plan['units']:
        b.exact(unit['source']); b.exact(unit['recipe'])
        out = W/'compile'/unit['name']
        process = h.execute(unit['command'], env, out, timeout=240 if unit['language'] == 'CUDA' else 180)
        if unit['language'] == 'CXX':
            dep = b.read(out/'dependencies.json')['Data']
            actual = [b.pin(path) for path in dict.fromkeys([dep['Source'], *dep['Includes']])]
            for row in actual:
                path = Path(row['path'])
                if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
                    assert b.key(path) in by_key and row['sha256'] == by_key[b.key(path)]['sha256'], str(path)
            b.save(out/'actual-dependencies.json', actual)
            dependency = b.pin(out/'actual-dependencies.json')
        else:
            dependency = b.pin(out/'unit.d')  # Preserve actual raw NVCC dependencies, no guessed parser.
        objects[unit['name']] = b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'], source=unit['source'], object=objects[unit['name']],
            compile=process, dependency_record=dependency))
        for row in [*frozen, *plan['declared_forced_includes']]: b.exact(row)
    artifacts = {}
    for name in ('cli', 'case', *(['test'] if 'test' in objects else [])):
        baseline = plan['baselines']['cli' if name == 'test' else name]
        inputs = b.read(baseline['inputs']['path'])
        removed = []
        if name == 'test':
            removed = [baseline['object'], next(row for row in inputs if b.key(row['path']).endswith('engine\\entry\\unit.obj'))]
        replacement = {b.key(plan['replaced_provider']['path']):objects['registration'],
                       b.key(plan['replaced_tensor']['path']):objects['ggml-supports']}
        image = W/name/'link'/('hyle.exe' if name == 'cli' else 'host-image-consumer.exe' if name == 'case' else 'causal-conv-test.exe')
        command, replaced, entry_removed = [], 0, 0
        for arg in b.read(baseline['link_recipe']['path'])['command']:
            if any(b.key(arg) == b.key(row['path']) for row in removed): entry_removed += 1; continue
            if b.key(arg) in replacement: arg = replacement[b.key(arg)]['path']; replaced += 1
            elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
            elif arg.upper().startswith('/MAP:'): continue
            command.append(arg)
        added = [objects['provider'], objects['kernel'], *([objects['test']] if name == 'test' else [])]
        command.extend(row['path'] for row in added)
        assert replaced == 2 and entry_removed == len(removed)
        linked = h.execute(command, env, image.parent, timeout=120)
        final = [replacement.get(b.key(row['path']),row) for row in inputs if row not in removed]+added
        b.save(W/name/'link-inputs.json', final)
        runtime = b.read(baseline['runtime']['path']); b.exact(runtime['native'])
        alias = image.parent/Path(runtime['native']['path']).name
        os.link(runtime['native']['path'], alias); runtime['native_hardlink'] = b.pin(alias)
        b.save(W/name/'runtime.json', runtime)
        artifact = dict(status='LINKED_NOT_RUN', image=b.pin(image), runtime=b.pin(W/name/'runtime.json'),
            link_inputs=b.pin(W/name/'link-inputs.json'), baseline=baseline['image'], link=linked,
            reused_Model_TUs=0 if name == 'test' else 1, Model_weight_report_SDK_archive_builds=0)
        b.save(W/name/'ready.json', artifact); artifacts[name] = artifact
    b.save(W/'ready.json', dict(status='CAUSAL_CONV_BUILT_NOT_RUN', plan=b.pin(W/'plan.json'),
        source_freeze=plan['source_freeze'], compiled=results, artifacts=artifacts,
        product_TUs=4, test_TUs=int('test' in objects), archive_rewrites=0, native_consumers=0))
    print('CAUSAL_CONV_READY', json.dumps(b.pin(W/'ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif len(sys.argv) == 3 and sys.argv[1] == 'plan': plan(Path(sys.argv[2]))
    elif sys.argv[1:] == ['build']: build()
    else: print(__doc__)
