"""Seven root-authorized finite function processes; no automatic retry."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch',W/'build.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b,R = m.b,m.R


def run():
    ready = b.read(W/'ready.json'); fixture = R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    jobs = [('append','test',[])]
    for backend,artifact in [('cpu','cpu-vulkan'),('vulkan','cpu-vulkan'),('cuda','cuda')]:
        jobs.extend([(backend,artifact,['--'+backend,str(fixture)]),
            (backend+'-lag1',artifact,['--'+backend,str(fixture),'--mtp-lag1'])])
    manifest = [dict(name=name,image=ready['artifacts'][artifact]['image'],runtime=ready['artifacts'][artifact]['runtime'],
        command=[ready['artifacts'][artifact]['image']['path'],*tail]) for name,artifact,tail in jobs]
    b.save(W/'run-manifest.json',dict(processes=manifest,fixture=b.pin(fixture/'weights.tsv'),scope='Seven finite function processes; no new performance, prefix or state-reuse probes.'))
    results = []
    for job in manifest:
        b.exact(job['image']); env = os.environ.copy(); env['PATH'] = b.read(job['runtime']['path'])['PATH']
        process = b.helper().execute(job['command'],env,W/'runs'/job['name'],timeout=60)
        if job['name'] != 'append': assert b.read(W/'runs'/job['name']/'stdout.log')['status'] == 'PASS'
        results.append(dict(name=job['name'],process=process)); print('FUNCTION',json.dumps(results[-1]),flush=True)
    b.save(W/'run-summary.json',dict(status='SEVEN_FINITE_FUNCTION_PROCESSES_PASS',processes=results,
        quality_claim=False,performance_claim=False,original335='NOT_RUN'))


if __name__ == '__main__':
    if sys.argv[1:] == ['run']: run()
    else: print(__doc__)
