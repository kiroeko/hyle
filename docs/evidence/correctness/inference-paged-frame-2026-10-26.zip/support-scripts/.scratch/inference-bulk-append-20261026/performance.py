"""After seven function PASS: six new formal-Hyle A/B timing + two memory runs."""
from pathlib import Path
import importlib.util
import json
import os
import re
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
P = W/'performance'
F = R/'.scratch/inference-b2-reusable-state-20261026'
O = R/'.scratch/inference-b2-current-window-20261026'
spec = importlib.util.spec_from_file_location('retained',O/'run.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def run():
    assert m.read(W/'run-summary.json')['status'] == 'SEVEN_FINITE_FUNCTION_PROCESSES_PASS'
    assert not P.exists()
    roots = {'control':F,'candidate':W/'formal'}
    ready = {arm:m.read(root/'ready.json') for arm,root in roots.items()}
    runtime = {arm:root/'runtime.json' for arm,root in roots.items()}
    images = {arm:ready[arm]['image'] for arm in roots}
    for image in images.values(): m.verify(image)
    before = m.read(F/'link-inputs.json'); after = m.read(W/'formal/link-inputs.json')
    assert len(before) == len(after) == 224
    changes = [(a,b) for a,b in zip(before,after) if a != b]
    assert len(changes) == 3 and sum(a == b for a,b in zip(before,after)) == 221
    expected = m.read(F/'expected-work.json')
    for row in [expected['manifest'],expected['schedule'],*[x['file'] for x in expected['tapes']]]: m.verify(row)
    historical = m.read(F/'runs/timing-01-hyle/observation.json')['raw']
    native = m.read(F/'pins.json')['harness']
    helper = m.module('finite_ab_runner',native['runner']['path'])
    m.module('finite_ab_observer',native['observer']['path']).install(helper)
    parse_code, parse_binding = m.legacy_phase_parser(native['old_performance_parser']['path'])
    argv = m.read(F/'plan.json')['commands'][0]['command']
    jobs = []
    order = ['control','candidate','candidate','control','control','candidate']
    for mode,arms in [('timing',order),('memory',['control','candidate'])]:
        for i,arm in enumerate(arms,1):
            command = list(argv); command[0] = images[arm]['path']
            jobs.append(dict(arm=arm,mode=mode,index=i,folder=str(P/f'{mode}-{i:02}-{arm}'),command=command,
                runtime=m.identity(runtime[arm])))
    P.mkdir()
    helper.save(P/'plan.json',dict(images=images,commands=jobs,linked_input_changes=changes,
        unchanged_link_inputs=221,build=m.identity(W/'ready.json'),function_checks=m.identity(W/'run-summary.json'),
        fixed_work=m.identity(F/'expected-work.json'),teacher_forced=True,mtp='off',quality_claim=False,
        same_window_control_rerun=True,prior_samples_pooled=False,step_timing_contract=m.read(F/'plan.json')['step_timing_contract']))
    helper.save(P/'phase-parser-binding.json',parse_binding)
    helper.gpu_snapshot(P,'window-before')
    reports,ids_by_arm,runs,memory = {},{},[],{}
    try:
        for job in jobs:
            arm,folder = job['arm'],Path(job['folder'])
            print('AB_BEGIN',job['mode'],job['index'],arm,flush=True)
            env = os.environ.copy(); env['PATH'] = m.read(runtime[arm])['PATH']
            env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
            process = helper.execute(folder,'hyle',job['command'],env,job['mode'] == 'memory')
            raw = json.loads((folder/'stdout.log').read_text(encoding='utf-8'))
            audit = []; normalized = m.normalize(raw,audit)
            helper.save(folder/'normalization-audit.json',audit)
            helper.save(folder/'complete-nontime-report.json',normalized)
            differences = m.differences(reports[arm],normalized) if arm in reports else []
            helper.save(folder/'within-arm-nontime-differences.json',differences)
            assert not differences,'Within-arm complete non-time report changed; no refill'
            ids = m.check_work(raw,'hyle',expected,historical)
            if arm not in reports: reports[arm],ids_by_arm[arm] = normalized,ids
            if len(ids_by_arm) == 2:
                cross_ids = m.differences(ids_by_arm['control'],ids_by_arm['candidate'])
                helper.save(P/'cross-arm-output-differences.json',cross_ids)
                assert not cross_ids,'Optimization changed returned IDs'
            ns = dict(folder=folder,raw=raw,waves=raw['waves'],variant='hyle',ids=ids,re=re)
            exec(parse_code,ns); observation = ns['observation']
            helper.save(folder/'observation.json',observation)
            runs.append(dict(arm=arm,mode=job['mode'],index=job['index'],folder=str(folder),process=process,
                metrics=observation['metrics'],within_arm_complete_nontime_differences=0))
            if job['mode'] == 'memory':
                mem = m.read(folder/'memory-summary.json')
                assert mem['setup_error'] is None and mem['thread_error'] is None
                memory[arm] = mem
            helper.save(P/'runs.json',runs)
            print('AB_END',job['mode'],job['index'],arm,observation['metrics'],flush=True)
        metrics = {arm:{key:helper.stats([x['metrics'][key] for x in runs if x['arm'] == arm and x['mode'] == 'timing'])
            for key in runs[0]['metrics']} for arm in roots}
        cross = m.differences(reports['control'],reports['candidate'])
        helper.save(P/'cross-arm-complete-nontime-differences.json',cross)
        assert not cross,'Direct same-contract A/B changed a non-time report field'
        comparisons = {k:dict(candidate_relative_to_control_percent=(metrics['candidate'][k]['median']/metrics['control'][k]['median']-1)*100,
            ranges_overlap=not(metrics['candidate'][k]['min'] > metrics['control'][k]['max'] or metrics['control'][k]['min'] > metrics['candidate'][k]['max'])) for k in metrics['control']}
        helper.save(P/'summary.json',dict(status='COMPLETE_8_DIRECT_AB_EXACT_WORK_AND_NONTIME_STABLE',
            runs=runs,metrics=metrics,comparisons=comparisons,memory=memory,
            cross_arm_complete_nontime_differences=0,cross_arm_returned_ID_differences=0,
            process_count=8,unmonitored_timing_processes=6,independent_memory_processes=2,
            old_or_peer_samples_pooled=False,statistical_significance_claim=False,
            limitations=['Exactly one bulk-append implementation change versus retained current control; three changed direct objects and221 identical inputs.',
                'Fixed teacher-forced ordinary equal-T B2 synthetic journey; no MTP speed/quality/general-serving conclusion.',
                'Three timing samples per arm: finite medians/ranges. RAM/VRAM independent sampled peaks are lower bounds, not exact phase allocation totals.',
                'OS page cache not cleared; loading endpoints retained separately, not cold-disk speed.']))
    except BaseException as error:
        helper.save(P/'failure.json',dict(status='STOPPED_FIRST_FAILURE_NO_REFILL',completed=len(runs),error=repr(error)))
        raise
    finally: helper.gpu_snapshot(P,'window-after')
    print('AB_COMPLETE_8_GPU_RELEASED',flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['run']: run()
    else: print(__doc__)
