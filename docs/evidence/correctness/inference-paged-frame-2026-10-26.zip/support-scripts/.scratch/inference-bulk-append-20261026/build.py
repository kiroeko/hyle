"""After root SOURCE_FROZEN: plan/build six cached TUs and four images only."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-reusable-state-20261026'
F = R/'.scratch/inference-b2-reusable-state-20261026'
spec = importlib.util.spec_from_file_location('cached',R/'.scratch/inference-stream-padding-20261026/build.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b = m.b
OLD_RESOURCE = B/'compile/resources/unit.obj'
OLD_APPEND = R/'.scratch/inference-f32-append-20261025/cpu1/compile/cpu-append/unit.obj'
SPECS = [
    ('resources','src/graph/resources.cc',OLD_RESOURCE.parent/'command.json'),
    ('append','src/graph_batch/paged_append.cc',OLD_APPEND.parent/'command.json'),
    ('test','tests/graph_batch/paged_append_graph_test.cc',R/'.scratch/paged-append-20261021/symbolic-rows/checks/attempt2/graph_batch--paged_append_graph_test/compile-plan.json'),
    ('cpu-vulkan','tests/tools/qwen_host_image_test.cc',B/'compile3/model/command.json'),
    ('cuda','tests/tools/qwen_host_image_test.cc',B/'cuda2/compile/model/command.json'),
    ('formal','engine/models/qwen35/main.cc',F/'compile/command.json')]


def plan():
    assert not (W/'plan.json').exists()
    units = []
    for name,source,recipe in SPECS:
        command = m.command(recipe,R/source,W/'compile'/name)
        shadow = str(R/'.scratch/inference-f32-append-20261025/cpu1/source')
        command = [x.replace(shadow,str(R)) for x in command]
        command[1:1] = ['/I'+str(R/'include'),'/I'+str(R),'/I'+str(R/'src/graph'),'/I'+str(R/'src/compute')]
        if name == 'test': assert '/DHYLE_APPEND_STANDALONE=1' in command
        units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),command=command))
    current_recipe = W/'canonical-recipes.json'
    b.save(current_recipe,dict(command=[x for u in units for x in u['command']]))
    frozen = m.c.closure([u['source']['path'] for u in units],[current_recipe])
    b.save(W/'source-freeze.json',frozen)
    baselines = {}
    for name,root,count in [('test',B/'case2',137),('cpu-vulkan',B/'case2',137),('cuda',B/'cuda2',223),('formal',F,224)]:
        inputs = b.read(root/'link-inputs.json')
        assert len(inputs) == count and all(Path(x['path']).is_file() for x in inputs)
        assert all(sum(b.key(x['path']) == b.key(q) for x in inputs) == 1 for q in (OLD_RESOURCE,OLD_APPEND))
        baselines[name] = dict(command=b.pin(root/'link/command.json'),inputs=b.pin(root/'link-inputs.json'),
            ready=b.pin(root/'ready.json'),runtime=b.pin(root/'runtime.json'))
    b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',base_commit='96af8f7e1',units=units,
        source_freeze=b.pin(W/'source-freeze.json'),baselines=baselines,compiled_TUs=6,new_images=4,
        weights_report_SDK_native_compiles=0,canonical_includes_precede_old_shadows=True))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)


def build():
    p = b.read(W/'plan.json'); frozen = b.read(p['source_freeze']['path'])
    assert not (W/'compile').exists() and not (W/'ready.json').exists()
    for row in frozen: b.exact(row)
    h = b.helper(); cl = p['units'][0]['command'][0]
    env = h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    own = {b.key(x['path']):x for x in frozen}
    objects,results = {},[]
    for u in p['units']:
        out = W/'compile'/u['name']
        process = h.execute(u['command'],env,out,timeout=180)
        dep = b.read(out/'dependencies.json')['Data']
        actual = [b.pin(q) for q in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            q = Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert own[b.key(q)]['sha256'] == row['sha256'],str(q)
            assert '.scratch\\inference-f32-append-20261025\\cpu1\\source' not in str(q),str(q)
        b.save(out/'actual-dependencies.json',actual)
        objects[u['name']] = b.pin(out/'unit.obj')
        results.append(dict(name=u['name'],source=u['source'],object=objects[u['name']],process=process,
            dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen: b.exact(row)
    artifacts = {}
    for name,base in p['baselines'].items():
        inputs = b.read(base['inputs']['path'])
        replacements = {b.key(OLD_RESOURCE):objects['resources'],b.key(OLD_APPEND):objects['append']}
        remove,added = set(),[]
        if name == 'test':
            remove = {b.key(B/'compile3/model/unit.obj'),b.key(R/'.scratch/inference-stream-padding-20261026/compile/weights/unit.obj'),
                b.key(R/'.scratch/inference-review-fixes-20261026/product2/report/unit.obj')}
            assert all(sum(b.key(x['path']) == key for x in inputs) == 1 for key in remove)
            added = [objects['test']]
        else:
            old = B/'compile3/model/unit.obj' if name == 'cpu-vulkan' else B/'cuda2/compile/model/unit.obj' if name == 'cuda' else F/'compile/unit.obj'
            replacements[b.key(old)] = objects[name]
        image = W/name/'link'/('append-test.exe' if name == 'test' else 'hyle.exe' if name == 'formal' else 'host-image-test.exe')
        args,changed,dropped = [],0,0
        for arg in b.read(base['command']['path'])['command']:
            if b.key(arg) in remove: dropped += 1; continue
            if b.key(arg) in replacements: arg = replacements[b.key(arg)]['path']; changed += 1
            elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
            args.append(arg)
        assert changed == len(replacements) and dropped == len(remove)
        args.extend(x['path'] for x in added)
        linked = h.execute(args,env,image.parent,timeout=120)
        final = [replacements.get(b.key(x['path']),x) for x in inputs if b.key(x['path']) not in remove]+added
        assert len(final) == {'test':135,'cpu-vulkan':137,'cuda':223,'formal':224}[name]
        b.save(W/name/'link-inputs.json',final)
        runtime = b.read(base['runtime']['path']); b.exact(runtime['native'])
        alias = image.parent/Path(runtime['native']['path']).name
        os.link(runtime['native']['path'],alias); runtime['native_hardlink'] = b.pin(alias)
        b.save(W/name/'runtime.json',runtime)
        artifacts[name] = dict(status='LINKED_NOT_RUN',image=b.pin(image),inputs=b.pin(W/name/'link-inputs.json'),
            runtime=b.pin(W/name/'runtime.json'),link=linked)
        b.save(W/name/'ready.json',artifacts[name])
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',plan=b.pin(W/'plan.json'),compiled=results,
        artifacts=artifacts,SDK_native_weights_report_compiles=0))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    else: print(__doc__)
