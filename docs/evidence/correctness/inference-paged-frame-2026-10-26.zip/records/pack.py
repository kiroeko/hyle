"""Package the completed Windows Frame batch only; no build/run/download/cleanup."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-bulk-append-20261026'
F = R / '.scratch/inference-b2-reusable-state-20261026'
BASE = 'b3ffcad5d7f719f7c435ef3221aedf36bb6fc063'


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(data): return hashlib.sha256(data).hexdigest()
def data_json(value): return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
def pin(path):
    path = Path(path); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))
def key(path): return str(Path(path).resolve()).lower()
def verified(record):
    assert pin(record['path']) == record, record['path']
    return read(record['path'])


def archive(path, entries):
    assert not path.exists(), str(path)
    manifest = [dict(path=name, bytes=len(data), sha256=digest(data)) for name, data in sorted(entries.items())]
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for name, data in sorted(entries.items()): out.writestr(name, data)
        out.writestr('archive-manifest.json', data_json(dict(entries=manifest,
            forbidden_payloads='No OBJ, executable, DLL, SDK, static library, PDB or model payload. Paths in JSON are provenance references only.')))
    with zipfile.ZipFile(path) as check:
        assert check.testzip() is None
        assert len(check.namelist()) == len(manifest) + 1
        for row in manifest:
            value = check.read(row['path'])
            assert len(value) == row['bytes'] and digest(value) == row['sha256']
            assert Path(row['path']).suffix.lower() not in {'.obj', '.exe', '.dll', '.lib', '.pdb', '.exp', '.bin'}
    return dict(**pin(path), entries=len(manifest) + 1, uncompressed_bytes=sum(x['bytes'] for x in manifest),
        crc_and_member_sha256_verified=True)


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == BASE
    changed = subprocess.check_output(['git', 'diff', '--name-only', '--', 'src', 'include', 'engine', 'tests'], cwd=R, text=True).splitlines()
    changed.append('include/hyle/compute/paged_frame.h'); changed = sorted(set(changed)); assert len(changed) == 19
    final_ready = read(W / 'engine/ready2.json'); assert pin(W / 'engine/ready2.json')['sha256'] == 'd005ee38ec0c970142c791b535c5a919c4db05286814d791e061c521f92f20b9'
    compute_ready = read(W / 'ready2.json'); prefix_ready = read(W / 'prefix/ready.json')
    function = read(W / 'function-summary.json'); recursive = read(W / 'recursive-summary.json'); perf = read(W / 'performance/summary.json')
    assert function['status'] == 'SEVEN_FINITE_FUNCTION_PROCESSES_PASS'
    assert recursive['status'] == 'FOUR_TINY_RECURSIVE_FUNCTION_PROCESSES_PASS'
    assert perf['status'] == 'COMPLETE_8_DIRECT_AB_EXACT_WORK_AND_NONTIME_STABLE'
    for group in (compute_ready['compiled'], final_ready['compiled']):
        for unit in group: assert unit['process']['exit'] == 0
    final_deps = [Path(x['actual_dependencies']['path']) for x in compute_ready['compiled'] + final_ready['compiled']]
    final_deps.append(W / 'prefix/compile/actual-dependencies.json')
    coverage = {}
    for dep in final_deps:
        for row in read(dep): coverage.setdefault(key(row['path']), []).append((row, dep))
    source_entries, sources = {}, []
    for relative in changed:
        path = R / relative; identity = pin(path); matches = coverage.get(key(path), [])
        for row, _ in matches: assert row['sha256'] == identity['sha256'] and row['bytes'] == identity['bytes'], relative
        source_entries['sources/' + relative] = path.read_bytes()
        sources.append(dict(path=relative, bytes=identity['bytes'], sha256=identity['sha256'],
            validation='MATCHES_FINAL_ACTUAL_COMPILER_DEPENDENCIES' if matches else 'ARCHIVED_CURRENT_ADAPTER_NOT_COMPILED_THIS_BATCH',
            actual_dependency_records=sorted({str(p.relative_to(W)) for _, p in matches})))
    uncompiled = [x['path'] for x in sources if not x['actual_dependency_records']]
    assert set(uncompiled) == {'engine/models/qwen35/batch_probe.cc', 'engine/models/qwen35/mtp_session_probe.cc',
        'engine/models/qwen35/retained_budget_probe.cc', 'engine/models/qwen35/retirement_probe.cc'}

    controls = [
        ('src/compute_batch/batch_layout.cc', R / '.scratch/inference-layout-storage-validation-20261025/cpu1/compile/compute_batch--batch_layout'),
        ('src/compute_batch/paged_arena.cc', R / '.scratch/inference-host-image-20261026/arena/implementation'),
        ('src/graph_batch/paged_append.cc', B / 'compile/append'),
        ('engine/models/qwen35/main.cc', B / 'compile/formal')]
    control_entries, control_sources = {}, []
    for relative, directory in controls:
        expected = next(x for x in read(directory / 'actual-dependencies.json') if key(x['path']) == key(R / relative))
        blob = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=R)
        if digest(blob) != expected['sha256']:
            blob = blob.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
        assert digest(blob) == expected['sha256'] and len(blob) == expected['bytes'], ('control source differs', relative)
        name = 'control-sources/' + BASE + '/' + relative; control_entries[name] = blob
        control_sources.append(dict(path=relative, archive_path=name, bytes=len(blob), sha256=digest(blob),
            actual_dependencies=pin(directory / 'actual-dependencies.json')))
        for name in ('actual-dependencies.json', 'command.json', 'process.json', 'stdout.log', 'stderr.log'):
            file = directory / name
            if file.exists(): control_entries['control-build/' + relative.replace('/', '--') + '/' + name] = file.read_bytes()

    common = dict(source_entries); common.update(control_entries)
    common['records/source-validation.json'] = data_json(dict(base_git=BASE, sources=sources, control_sources=control_sources))
    for relative in ('include/hyle/compute/batch_transfer.h', 'src/compute/batch_transfer.cc'):
        common['contract-support/' + relative] = (R / relative).read_bytes()
    common['contract-support/inference-copy-public-retention-2026-10-26.json'] = (R / 'docs/evidence/correctness/inference-copy-public-retention-2026-10-26.json').read_bytes()
    for path in [B / 'build.py', B / 'run.py', B / 'performance.py', R / '.scratch/inference-stream-padding-20261026/build.py',
                 R / '.scratch/inference-causal-conv-20261026/build.py', R / '.scratch/inference-host-image-20261026/build.py',
                 R / '.scratch/inference-b2-current-window-20261026/run.py']:
        common['support-scripts/' + str(path.relative_to(R)).replace('\\', '/')] = path.read_bytes()
    native = read(F / 'pins.json')['harness']
    for role, identity in native.items():
        assert pin(identity['path']) == identity
        common['support-scripts/harness/' + role + '.py'] = Path(identity['path']).read_bytes()

    allowed = {'.json', '.log', '.py', '.cc', '.h', '.ids', '.tsv', '.txt'}
    correctness_entries = dict(common); performance_entries = dict(common)
    for path in sorted(W.rglob('*')):
        if not path.is_file() or path.suffix.lower() not in allowed: continue
        relative = path.relative_to(W)
        if relative.parts[0] == 'mac': continue
        if relative.parts[0] == 'performance': performance_entries['records/' + relative.as_posix()] = path.read_bytes()
        else: correctness_entries['records/' + relative.as_posix()] = path.read_bytes()
    for relative in ('function-summary.json', 'function-manifest.json', 'recursive-summary.json', 'recursive-manifest.json',
                     'recursive-failure.json', 'run.py', 'recursive.py', 'performance.py', 'engine/ready2.json',
                     'engine/plan2.json', 'engine/source2-freeze.json', 'engine/formal/ready.json',
                     'engine/formal/link-inputs.json', 'engine/formal/runtime.json'):
        performance_entries['records/' + relative] = (W / relative).read_bytes()
    # Exact retained producer code and fixed-work metadata, not old timing samples.
    for relative in ('expected-work.json', 'plan.json', 'pins.json'):
        performance_entries['retained-work-metadata/' + relative] = (F / relative).read_bytes()
    fixed = read(F / 'expected-work.json')
    for identity in [fixed['manifest'], fixed['schedule'], *[x['file'] for x in fixed['tapes']]]:
        assert pin(identity['path']) == identity
        path = Path(identity['path']); performance_entries['fixed-inputs/' + path.name] = path.read_bytes()
    for relative in ('formal/ready.json', 'formal/link-inputs.json', 'formal/runtime.json', 'source-freeze.json'):
        performance_entries['control-bulk-append/' + relative] = (B / relative).read_bytes()

    compute_log = (W / 'run2/stdout.log').read_text(encoding='utf-8')
    frame_tests = re.findall(r'^\[ RUN      \] (PagedFrame\.[^\r\n]+)', compute_log, re.M)
    assert len(frame_tests) == 8 and '[  PASSED  ] 41 tests.' in compute_log
    prefix_lines = [x for x in (W / 'prefix/run1/stdout.log').read_text(encoding='utf-8').splitlines() if x.startswith('PASS ')]
    assert len(prefix_lines) == 23
    first_graph = (W / 'engine/compile/test/stdout.log').read_bytes()
    assert b'C2662' in first_graph and b'C4456' in first_graph
    assert read(W / 'recursive-failure.json')['error'] == "KeyError('requested_steps')"
    before = read(B / 'formal/link-inputs.json'); after = read(W / 'engine/formal/link-inputs.json')
    assert len(before) == len(after) == 224 and sum(a == b for a, b in zip(before, after)) == 220
    changes = [dict(index=i, before=a, after=b) for i, (a, b) in enumerate(zip(before, after)) if a != b]
    assert len(changes) == 4
    for item in read(W / 'performance/plan.json')['linked_input_changes']: assert item in changes
    identities = dict(control=read(B / 'formal/ready.json')['image'], candidate=final_ready['artifacts']['formal']['image'],
        final_engine_ready=pin(W / 'engine/ready2.json'), control_sources=control_sources)
    for value in (identities['control'], identities['candidate']): assert pin(value['path']) == value

    failures = [
        dict(kind='EXISTING_TEST_ASSERTION_MISMATCH_NOT_FRAME_PRODUCT_FAILURE', process=read(W / 'run1/process.json'),
            observed='First Compute run:40/41 total, all8 new Frame tests pass. Existing F2MutableWithdrawal test expected closed unbind to reject, but it succeeded.',
            resolution='Updated test to the already-existing closed-copy contract: closing admission does not strand a retired caller writer. Checks exact generation/content, rejects new submit/bind, and verifies re-publication/reacquisition. No copy product change in this batch.',
            prior_evidence='docs/evidence/correctness/inference-copy-public-retention-2026-10-26.json',
            code='src/compute/batch_transfer.cc:82 mutable_slot(recover_writer);:345 take_mutable retains submission/retirement/failure gates'),
        dict(kind='NEW_GRAPH_TEST_COMPILE_DIAGNOSTICS', process=read(W / 'engine/compile/test/process.json'),
            observed='Two C2662 errors:const PagedPageWriter loop calls nonconst lease(); C4456 warning:q shadows previous local under /WX.',
            resolution='Only test loop constness and local name changed. Failed original test source and raw compiler bytes retained; successful append object reused.'),
        dict(kind='RUNNER_REPORT_PARSER_ERROR_NOT_PRODUCT_FAILURE', process=read(W / 'recursive-runs/drafts2-control/process.json'),
            observed="Control process60576 exited0. Runner looked for requested_steps at top-level instead of sessions[0].result; KeyError('requested_steps').",
            resolution='Original failure JSON retained. Corrected parser reused that same successful process/logs; only the three remaining authorized processes were launched. No replacement sample.')]
    bounds = [
        'Windows receipt only. Apple/macOS NOT_RUN in this receipt; a separate independent Mac receipt may be appended later and will not retroactively change these Windows results.',
        'Four changed diagnostic probe translation units archived but not independently compiled/run in this finite batch; exact list is in sources validation.',
        'Eight new Frame cases plus existing arena/admission/budget tests are finite regressions, not an exhaustive proof of all possible models, devices, races or native failures.',
        'Tiny ordinary/MTP, lag1 and recursive checks use an untrained component fixture; no natural task quality or full335 MTP speed claim.',
        'No new llama.cpp/peer process. No historical peer or previous timing sample is pooled. B2 is Frame candidate versus retained bulk-append formal control only.',
        'Three unmonitored timing samples per arm; medians and observed ranges only, no statistical significance/generalization claim.',
        'Separate one-process-per-arm RAM/VRAM sampling yields peak lower bounds, not exact per-phase allocation totals. Both ready baselines are null/unknown.',
        'No clean disk-cache protocol; model loading/ready are separately reported and are not cold-disk bandwidth.',
        'No new SDK/native/weights/report compile, model download, driver-failure injection, services, extra retries, padding matrix or extra samples.']
    correctness = dict(date='2026-10-26', platform='Windows', status='FINITE_FRAME_FUNCTION_CHECKS_PASS_WITH_PRESERVED_DIAGNOSTICS',
        source_base=BASE, sources=sources, source_count=19, identities=identities,
        implementation=['Move-only mutable/sealed Frame reuses original arena leases and actual-sized guard metadata.',
            'Epoch-bound ready deltas stage fallible metadata before allocation-free commit; sealed snapshots never thaw.',
            'Required logical rows are shared immutable per-layout facts; bulk prefix export avoids quadratic scans.',
            'Graph ready_delta and engine collective preflight/handoff reuse original retirement and publication boundaries; private NextN/repair stay unpublished.'],
        compute=dict(final_process=read(W / 'run2/process.json'), final_passed=41, total=41, frame_passed=8, frame_tests=frame_tests,
            final_ready=pin(W / 'ready2.json')),
        prefix=dict(process=read(W / 'prefix/run1/process.json'), passed_groups=23, groups=prefix_lines, ready=pin(W / 'prefix/ready.json')),
        graph_model_build=dict(final_ready=pin(W / 'engine/ready2.json'), unique_new_TUs=5, images=4,
            compile_invocations_including_preserved_failure=6, compiled=final_ready['compiled'], artifacts=final_ready['artifacts'],
            reused_compute_TUs=2, new_SDK_native_weights_report_TUs=0),
        function_checks=function, recursive_checks=recursive, preserved_diagnostics=failures,
        b2_complete_report_check=dict(process_count=8, returned_IDs=198, rows=1728, executions=99,
            same_window_cross_arm_ID_differences=0, complete_nontime_differences=0,
            performance_receipt='docs/evidence/performance/inference-paged-frame-2026-10-26.json'),
        apple=dict(status='NOT_RUN_IN_THIS_WINDOWS_RECEIPT', subsequent_receipt='Separate independent receipt; not backfilled here'), limitations=bounds)
    correctness_entries['records/receipt-data.json'] = data_json(correctness)
    cp = R / 'docs/evidence/correctness/inference-paged-frame-2026-10-26'
    correctness['archive'] = archive(cp.with_suffix('.zip'), correctness_entries)
    cp.with_suffix('.json').write_bytes(data_json(correctness))

    performance = dict(date='2026-10-26', platform='Windows', status='COMPLETE_FINITE_SAME_WINDOW_AB_SMALL_DECODE_IMPROVEMENT',
        source_base=BASE, sources=sources, identities=identities,
        closure=dict(direct_inputs_per_arm=224, unchanged_exact_inputs=220, changed_inputs=changes,
            unchanged_runtime_PATH=True, unchanged_native_pin=True, reconstructed_control_sources_match_actual_dependencies=True),
        correctness_receipt=pin(cp.with_suffix('.json')), function_checks=pin(W / 'function-summary.json'),
        recursive_checks=pin(W / 'recursive-summary.json'),
        work=dict(ordinary_MTP='MTP_OFF', requests=2, turns_per_request=3, returned_IDs=198, rows=1728,
            executions=99, teacher_forced=True, fixed_manifest=read(F / 'expected-work.json')['manifest'],
            full_non_time_report_cross_arm_differences=0, returned_ID_cross_arm_differences=0),
        gpu_before=(W / 'performance/window-before-gpu.stdout.log').read_text(encoding='utf-8').strip(),
        gpu_after=(W / 'performance/window-after-gpu.stdout.log').read_text(encoding='utf-8').strip(),
        process_count=8, unmonitored_timing_processes=6, independent_memory_processes=2,
        metrics=perf['metrics'], comparisons=perf['comparisons'], memory_comparisons=perf['memory_comparisons'],
        memory=dict(control=perf['memory']['control'], candidate=perf['memory']['candidate']),
        delivery=dict(prefill_median_tps=[perf['metrics'][x]['prefill_tps']['median'] for x in ('control','candidate')],
            decode_median_tps=[perf['metrics'][x]['full_decode_tps']['median'] for x in ('control','candidate')],
            combined_output_median_tps=[perf['metrics'][x]['session_output_tps']['median'] for x in ('control','candidate')],
            combined_session_median_seconds=[perf['metrics'][x]['session_seconds']['median'] for x in ('control','candidate')],
            vram_sampled_peak_dedicated_bytes=[perf['memory'][x]['sampled_peaks']['sampled_peak_gpu_dedicated_bytes'] for x in ('control','candidate')],
            ready_memory_known=[not perf['memory'][x]['ready_baseline']['unknown'] for x in ('control','candidate')]),
        result='Decode median+1.0097%, combined output+0.9243%; prefill-1.4367% with overlapping observed ranges. Observed decode/combined ranges do not overlap, but three samples do not establish statistical significance.',
        prior_or_peer_samples_pooled=False, new_peer_processes=0, statistical_significance_claim=False,
        apple=dict(status='NOT_RUN_IN_THIS_WINDOWS_RECEIPT'), preserved_diagnostics=failures, limitations=bounds)
    performance_entries['records/receipt-data.json'] = data_json(performance)
    pp = R / 'docs/evidence/performance/inference-paged-frame-2026-10-26'
    performance['archive'] = archive(pp.with_suffix('.zip'), performance_entries)
    pp.with_suffix('.json').write_bytes(data_json(performance))
    for row in sources:
        assert pin(R / row['path'])['sha256'] == row['sha256'], 'Source changed while packaging'
    result = dict(outputs=[pin(x) for x in (cp.with_suffix('.json'), cp.with_suffix('.zip'), pp.with_suffix('.json'), pp.with_suffix('.zip'))],
        source_count=19, verified_by_final_actual_dependency_lists=15, explicitly_uncompiled_probe_sources=uncompiled,
        zip_member_crc_and_sha256='PASS', product_changes=0, experiments=0, downloads=0)
    (W / 'package-summary.json').write_bytes(data_json(result)); print(json.dumps(result, indent=2))


if __name__ == '__main__': main()
