"""After final root freeze: five Graph/Model TUs, four cached images. No default action."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
E=W/'engine'
R=W.parents[1]
B=R/'.scratch/inference-bulk-append-20261026'
spec=importlib.util.spec_from_file_location('cached_bulk',B/'build.py')
cache=importlib.util.module_from_spec(spec);spec.loader.exec_module(cache)
m,b=cache.m,cache.b
SPECS=[('append','src/graph_batch/paged_append.cc',B/'compile/append/command.json'),
    ('test','tests/graph_batch/paged_append_graph_test.cc',B/'compile/test/command.json'),
    ('cpu-vulkan','tests/tools/qwen_host_image_test.cc',B/'compile/cpu-vulkan/command.json'),
    ('cuda','tests/tools/qwen_host_image_test.cc',B/'compile/cuda/command.json'),
    ('formal','engine/models/qwen35/main.cc',B/'compile/formal/command.json')]
SHARED=[('arena',R/'.scratch/inference-host-image-20261026/arena/implementation/unit.obj'),
    ('layout',R/'.scratch/inference-layout-storage-validation-20261025/cpu1/compile/compute_batch--batch_layout/unit.obj')]


def plan():
    assert not (E/'plan.json').exists()
    jobs=[dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),
        command=m.command(recipe,R/source,E/'compile'/name)) for name,source,recipe in SPECS]
    assert '/DHYLE_APPEND_STANDALONE=1' in jobs[1]['command']
    assert '/DHYLE_COMPUTE_CUDA=1' in jobs[3]['command'] and '/DHYLE_COMPUTE_VULKAN=1' not in jobs[3]['command']
    frozen=m.c.closure([u['source']['path'] for u in jobs],[recipe for _,_,recipe in SPECS])
    b.save(E/'source-freeze.json',frozen)
    replacements=[]
    for name,old in SHARED:
        actual=b.read(W/'compile'/name/'actual-dependencies.json')
        for row in actual:b.exact(row)
        replacements.append(dict(name=name,before=b.pin(old),after=b.pin(W/'compile'/name/'unit.obj'),
            actual_dependencies=b.pin(W/'compile'/name/'actual-dependencies.json')))
    baselines={}
    for name,count in [('test',135),('cpu-vulkan',137),('cuda',223),('formal',224)]:
        root=B/name;inputs=b.read(root/'link-inputs.json')
        assert len(inputs)==count and all(Path(x['path']).is_file() for x in inputs)
        for old in [*[x[1] for x in SHARED],B/'compile/append/unit.obj',B/'compile'/name/'unit.obj']:
            assert sum(b.key(x['path'])==b.key(old) for x in inputs)==1,str(old)
        baselines[name]=dict(command=b.pin(root/'link/command.json'),inputs=b.pin(root/'link-inputs.json'),
            runtime=b.pin(root/'runtime.json'),ready=b.pin(root/'ready.json'))
    b.save(E/'plan.json',dict(status='FROZEN_NOT_BUILT',units=jobs,source_freeze=b.pin(E/'source-freeze.json'),
        shared_compute=replacements,Compute_test_summary=b.pin(W/'run-summary.json'),baselines=baselines,
        new_TUs=5,new_images=4,reused_Compute_TUs=2,weights_report_resources_SDK_native_compiles=0))
    print('ENGINE_PLAN',json.dumps(b.pin(E/'plan.json')),flush=True)


def build(second=False):
    plan_name='plan2.json' if second else 'plan.json'
    ready_name='ready2.json' if second else 'ready.json'
    p=b.read(E/plan_name);frozen=b.read(p['source_freeze']['path'])
    assert not (E/ready_name).exists()
    if not second:assert not (E/'compile').exists()
    for row in frozen:b.exact(row)
    for item in p['shared_compute']:
        b.exact(item['after'])
        for row in b.read(item['actual_dependencies']['path']):b.exact(row)
    h=b.helper();cl=p['units'][0]['command'][0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    own={b.key(x['path']):x for x in frozen};objects,results={},[]
    for unit in p['units']:
        out=Path(next(x[3:] for x in unit['command'] if x.lower().startswith('/fo'))).parent
        reused=second and unit['name']=='append'
        if reused:
            process=b.read(out/'process.json');assert process['exit']==0
            actual=b.read(out/'actual-dependencies.json')
            for row in actual:b.exact(row)
        else:
            process=h.execute(unit['command'],env,out,timeout=180)
            dep=b.read(out/'dependencies.json')['Data']
            actual=[b.pin(q) for q in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            q=Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert own[b.key(q)]['sha256']==row['sha256'],str(q)
        if not reused:b.save(out/'actual-dependencies.json',actual)
        objects[unit['name']]=b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],process=process,
            actual_dependencies=b.pin(out/'actual-dependencies.json'),reused_compile=reused))
        for row in frozen:b.exact(row)
    artifacts={}
    for name,base in p['baselines'].items():
        replace={b.key(x['before']['path']):x['after'] for x in p['shared_compute']}
        replace[b.key(B/'compile/append/unit.obj')]=objects['append']
        replace[b.key(B/'compile'/name/'unit.obj')]=objects[name]
        image=E/name/'link'/('append-test.exe' if name=='test' else 'hyle.exe' if name=='formal' else 'host-image-test.exe')
        args,changed=[],0
        for arg in b.read(base['command']['path'])['command']:
            if b.key(arg) in replace:arg=replace[b.key(arg)]['path'];changed+=1
            elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
            args.append(arg)
        assert changed==4
        linked=h.execute(args,env,image.parent,timeout=120)
        inputs=[replace.get(b.key(x['path']),x) for x in b.read(base['inputs']['path'])]
        b.save(E/name/'link-inputs.json',inputs)
        runtime=b.read(base['runtime']['path']);b.exact(runtime['native'])
        alias=image.parent/Path(runtime['native']['path']).name;os.link(runtime['native']['path'],alias)
        runtime['native_hardlink']=b.pin(alias);b.save(E/name/'runtime.json',runtime)
        artifacts[name]=dict(status='LINKED_NOT_RUN',image=b.pin(image),inputs=b.pin(E/name/'link-inputs.json'),
            runtime=b.pin(E/name/'runtime.json'),link=linked)
        b.save(E/name/'ready.json',artifacts[name])
    b.save(E/ready_name,dict(status='BUILT_NOT_RUN',plan=b.pin(E/plan_name),compiled=results,artifacts=artifacts,
        reused_Compute_TUs=2,weights_report_resources_SDK_native_compiles=0))
    print('ENGINE_READY',json.dumps(b.pin(E/ready_name)),flush=True)


if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['build2']:build(second=True)
    else:print(__doc__)
