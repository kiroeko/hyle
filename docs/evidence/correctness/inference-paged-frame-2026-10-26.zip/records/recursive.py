"""Four tiny, untrained recursive MTP controls; no quality or throughput claim."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('frame_functions', W / 'run.py')
f = importlib.util.module_from_spec(spec); spec.loader.exec_module(f)
spec = importlib.util.spec_from_file_location('frame_compare', R / '.scratch/inference-b2-current-window-20261026/run.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b = f.b


def run(resume=False):
    ready_path = W / 'engine/ready2.json'; ready_pin = b.pin(ready_path)
    assert ready_pin['sha256'] == 'd005ee38ec0c970142c791b535c5a919c4db05286814d791e061c521f92f20b9'
    assert b.read(W / 'function-summary.json')['ready'] == ready_pin
    ready = b.read(ready_path)
    control = b.read(R / '.scratch/inference-bulk-append-20261026/formal/ready.json')
    artifacts = {'control': control, 'candidate': ready['artifacts']['formal']}
    output = W / 'recursive-runs'; inputs = W / 'tiny-recursive-input'
    assert not (W / 'recursive-summary.json').exists()
    weights = R / '.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture/weights.tsv'
    assert weights.stat().st_size == 7861
    if resume:
        assert b.read(W / 'recursive-failure.json')['error'] == "KeyError('requested_steps')"
        assert os.path.samefile(weights, inputs / 'weights.tsv')
        assert (inputs / 'prompt.ids').read_text(encoding='ascii') == '1 2 3\n'
    else:
        assert not output.exists() and not inputs.exists()
        inputs.mkdir(); os.link(weights, inputs / 'weights.tsv')
        (inputs / 'prompt.ids').write_text('1 2 3\n', encoding='ascii')
    base = ['--inputs', str(inputs), '--backend', 'cuda', '--replay', 'commands', '--progress', 'direct',
        '--capacity', '16', '--max-sessions', '4', '--active-sequences', '1', '--prefix-cache', 'off',
        '--steps', '8', '--sampling', 'greedy', '--mtp', 'on']
    jobs = [dict(arm=arm, drafts=drafts, command=[artifacts[arm]['image']['path'], *base,
        '--mtp-max-drafts', str(drafts)]) for drafts in (2, 4) for arm in ('control', 'candidate')]
    manifest = dict(ready=ready_pin, jobs=jobs,
        weights=b.pin(weights), hardlinked_manifest=b.pin(inputs / 'weights.tsv'), prompt=b.pin(inputs / 'prompt.ids'),
        reader='read_ids uses classic-locale formatted string extraction: spaces and newline are supported.',
        fixture='untrained tiny GA+NextN, actual private proposal and repair paths; no task quality claim',
        model_payloads_copied=0, downloads=0, performance_claim=False)
    if resume:
        assert b.read(W / 'recursive-manifest.json') == manifest
    else: b.save(W / 'recursive-manifest.json', manifest)
    baselines, results = {}, []
    try:
        for job in jobs:
            arm = job['arm']; artifact = artifacts[arm]
            b.exact(ready_pin); b.exact(artifact['image']); b.exact(artifact['runtime'])
            env = os.environ.copy(); env['PATH'] = b.read(artifact['runtime']['path'])['PATH']
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
            folder = output / ('drafts' + str(job['drafts']) + '-' + arm)
            print('RECURSIVE_BEGIN', job['drafts'], arm, flush=True)
            reused = resume and job == jobs[0]
            if reused:
                assert b.read(folder / 'command.json')['command'] == job['command']
                process = b.read(folder / 'process.json')
                assert process['pid'] == 60576 and process['exit'] == 0
            else:
                assert not folder.exists(), 'No duplicate process or output overwrite'
                process = b.helper().execute(job['command'], env, folder, timeout=60)
            assert process['exit'] == 0
            raw = b.read(folder / 'stdout.log')
            assert raw['source_id'] == '6' * 64 and raw['mtp'] is True
            assert raw['session_count'] == len(raw['sessions']) == 1
            session = raw['sessions'][0]['result']
            assert raw['requested_output_tokens'] == raw['generated_tokens'] == session['requested_steps'] == session['generated_tokens'] == len(session['generated_ids']) == 8
            assert raw['mtp_max_drafts'] == job['drafts']
            assert all(type(x) is int and 0 <= x < 64 for x in session['generated_ids'])
            audit = []; normalized = m.normalize(raw, audit)
            b.save(folder / 'normalization-audit.json', audit)
            b.save(folder / 'complete-nontime-report.json', normalized)
            if arm == 'control': baselines[job['drafts']] = normalized
            else:
                differences = m.differences(baselines[job['drafts']], normalized)
                b.save(folder / 'control-complete-nontime-differences.json', differences)
                assert not differences, 'Recursive complete output/non-time report changed'
            results.append(dict(arm=arm, drafts=job['drafts'], process=process, reused_original_success=reused, generated_ids=session['generated_ids'],
                actual_graph_calls=raw['actual_graph_calls'], draft_rounds=raw['draft_rounds'],
                committed_target_rows=raw['committed_target_rows'], draft_frontier=session['draft_frontier']))
            print('RECURSIVE_END', json.dumps(results[-1]), flush=True)
    except BaseException as error:
        b.save(W / ('recursive-resume-failure.json' if resume else 'recursive-failure.json'), dict(status='STOPPED_FIRST_FAILURE_NO_REFILL',
            job=job, completed=len(results), error=repr(error), processes=results))
        raise
    b.save(W / 'recursive-summary.json', dict(status='FOUR_TINY_RECURSIVE_FUNCTION_PROCESSES_PASS',
        ready=ready_pin, processes=results, process_count=4, cross_arm_complete_nontime_differences=0,
        fixture='untrained tiny component consumer', quality_claim=False, performance_claim=False, downloads=0,
        prior_parser_error_preserved=b.pin(W / 'recursive-failure.json') if resume else None))


if __name__ == '__main__':
    if sys.argv[1:] == ['run']: run()
    elif sys.argv[1:] == ['continue']: run(resume=True)
    else: print(__doc__)
