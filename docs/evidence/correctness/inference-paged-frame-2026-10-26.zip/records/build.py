"""After root freezes Compute/Graph: plan/build two Compute leaves + one GTest TU.

Reuses latest bulk-append CPU/Vulkan closure; never builds SDK/native/Model.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-bulk-append-20261026'
H = R/'.scratch/inference-host-image-20261026/arena'
L = R/'.scratch/inference-layout-storage-validation-20261025/cpu1/compile/compute_batch--batch_layout'
spec = importlib.util.spec_from_file_location('cached_bulk',B/'build.py')
cache = importlib.util.module_from_spec(spec); spec.loader.exec_module(cache)
m,b = cache.m,cache.b
SPECS = [('arena','src/compute_batch/paged_arena.cc',H/'implementation/command.json',H/'implementation/unit.obj'),
    ('layout','src/compute_batch/batch_layout.cc',L/'command.json',L/'unit.obj'),
    ('test','tests/compute_batch/paged_arena_test.cc',H/'paged-test/command.json',None)]


def plan():
    assert not (W/'plan.json').exists()
    jobs = [dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),
        replaces=b.pin(old) if old else None,command=m.command(recipe,R/source,W/'compile'/name))
        for name,source,recipe,old in SPECS]
    frozen = m.c.closure([u['source']['path'] for u in jobs],[recipe for _,_,recipe,_ in SPECS])
    b.save(W/'source-freeze.json',frozen)
    base = B/'cpu-vulkan'; inputs = b.read(base/'link-inputs.json')
    assert len(inputs) == 137 and all(Path(x['path']).is_file() for x in inputs)
    remove = [B/'compile/cpu-vulkan/unit.obj',R/'.scratch/inference-stream-padding-20261026/compile/weights/unit.obj',
        R/'.scratch/inference-review-fixes-20261026/product2/report/unit.obj']
    for old in [*[x[3] for x in SPECS if x[3]],*remove]:
        assert sum(b.key(x['path']) == b.key(old) for x in inputs) == 1,str(old)
    gtest = [b.pin(R/'.scratch/build-compute-v2-dev/lib'/x) for x in ('gtest_main.lib','gtest.lib')]
    assert not any(b.key(x['path']) == b.key(y['path']) for x in inputs for y in gtest)
    b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',units=jobs,source_freeze=b.pin(W/'source-freeze.json'),
        baseline=dict(inputs=b.pin(base/'link-inputs.json'),command=b.pin(base/'link/command.json'),runtime=b.pin(base/'runtime.json')),
        remove=[str(x) for x in remove],gtest=gtest,compiled_TUs=3,images=1,Model_SDK_native_compiles=0))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)


def build(second=False):
    plan_name='plan2.json' if second else 'plan.json'
    ready_name='ready2.json' if second else 'ready.json'
    p = b.read(W/plan_name); frozen = b.read(p['source_freeze']['path'])
    assert not (W/ready_name).exists()
    if not second: assert not (W/'compile').exists()
    for row in frozen: b.exact(row)
    h = b.helper(); cl = p['units'][0]['command'][0]
    env = h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    own = {b.key(x['path']):x for x in frozen}; objects,results = {},[]
    for u in p['units']:
        out=Path(next(x[3:] for x in u['command'] if x.lower().startswith('/fo'))).parent
        reused=second and u['name']!='test'
        if reused:
            process=b.read(out/'process.json'); assert process['exit']==0
            actual=b.read(out/'actual-dependencies.json')
            for row in actual: b.exact(row)
        else:
            process = h.execute(u['command'],env,out,timeout=180)
            dep = b.read(out/'dependencies.json')['Data']
            actual = [b.pin(q) for q in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            q = Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert own[b.key(q)]['sha256'] == row['sha256'],str(q)
        if not reused: b.save(out/'actual-dependencies.json',actual)
        objects[u['name']] = b.pin(out/'unit.obj')
        results.append(dict(name=u['name'],source=u['source'],object=objects[u['name']],process=process,
            actual_dependencies=b.pin(out/'actual-dependencies.json'),reused_compile=reused))
        for row in frozen: b.exact(row)
    remove = {b.key(x) for x in p['remove']}
    replace = {b.key(u['replaces']['path']):objects[u['name']] for u in p['units'] if u['replaces']}
    image = W/('link2' if second else 'link')/'page-frame-test.exe'; args = []; changed=dropped=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in remove: dropped += 1; continue
        if b.key(arg) in replace: arg=replace[b.key(arg)]['path']; changed += 1
        elif arg.upper().startswith('/OUT:'): arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'): arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed == 2 and dropped == 3
    added=[objects['test'],*p['gtest']]; args.extend(x['path'] for x in added)
    linked=h.execute(args,env,image.parent,timeout=120)
    inputs=[replace.get(b.key(x['path']),x) for x in b.read(p['baseline']['inputs']['path']) if b.key(x['path']) not in remove]+added
    assert len(inputs) == 137
    input_name='link2-inputs.json' if second else 'link-inputs.json'; b.save(W/input_name,inputs)
    runtime=b.read(p['baseline']['runtime']['path']); b.exact(runtime['native'])
    alias=image.parent/Path(runtime['native']['path']).name; os.link(runtime['native']['path'],alias)
    runtime_name='runtime2.json' if second else 'runtime.json'
    runtime['native_hardlink']=b.pin(alias); b.save(W/runtime_name,runtime)
    b.save(W/ready_name,dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=linked,
        inputs=b.pin(W/input_name),runtime=b.pin(W/runtime_name),plan=b.pin(W/plan_name),Model_SDK_native_compiles=0))
    print('READY',json.dumps(b.pin(W/ready_name)),flush=True)


def run(second=False):
    ready_name='ready2.json' if second else 'ready.json'
    p=b.read(W/ready_name); b.exact(p['image']); env=os.environ.copy(); env['PATH']=b.read(p['runtime']['path'])['PATH']
    process=b.helper().execute([p['image']['path']],env,W/('run2' if second else 'run1'),timeout=60)
    b.save(W/'run-summary.json',dict(process=process,ready=b.pin(W/ready_name),performance_claim=False))


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    elif sys.argv[1:] == ['run']: run()
    elif sys.argv[1:] == ['build2']: build(second=True)
    elif sys.argv[1:] == ['run2']: run(second=True)
    else: print(__doc__)
