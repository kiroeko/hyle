"""Six new formal B2 A/B timings + two independent memory runs, only after seven function PASS."""
from pathlib import Path
import argparse
import importlib.util
import json
import math
import os
import re
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
P = W / 'performance'
B = R / '.scratch/inference-bulk-append-20261026'
F = R / '.scratch/inference-b2-reusable-state-20261026'
O = R / '.scratch/inference-b2-current-window-20261026'
spec = importlib.util.spec_from_file_location('frame_retained_window', O / 'run.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


def run(ready_path, ready_sha256):
    ready_path = Path(ready_path).resolve(); build = m.identity(ready_path)
    assert build['sha256'] == ready_sha256.lower(), 'Wrong final build ready'
    function_path = W / 'function-summary.json'; function = m.read(function_path)
    assert function['status'] == 'SEVEN_FINITE_FUNCTION_PROCESSES_PASS' and function['ready'] == build
    assert not P.exists(), 'No overwrite, replacement samples or automatic retry'
    ready = m.read(ready_path); assert ready['status'] == 'BUILT_NOT_RUN'
    candidate = ready['artifacts']['formal']; control = m.read(B / 'formal/ready.json')
    images = {'control': control['image'], 'candidate': candidate['image']}
    runtime = {'control': control['runtime'], 'candidate': candidate['runtime']}
    for row in [*images.values(), *runtime.values(), control['inputs'], candidate['inputs'], ready['plan']]: m.verify(row)
    run_env = {arm: m.read(row['path']) for arm, row in runtime.items()}
    assert run_env['control']['PATH'] == run_env['candidate']['PATH']
    assert run_env['control']['native'] == run_env['candidate']['native']
    m.verify(run_env['control']['native'])
    before = m.read(control['inputs']['path']); after = m.read(candidate['inputs']['path'])
    assert len(before) == len(after) == 224
    plan = m.read(ready['plan']['path']); compiled = {x['name']: x['object'] for x in ready['compiled']}
    replacements = {str(Path(x['before']['path']).resolve()).lower(): x['after'] for x in plan['shared_compute']}
    replacements[str((B / 'compile/append/unit.obj').resolve()).lower()] = compiled['append']
    replacements[str((B / 'compile/formal/unit.obj').resolve()).lower()] = compiled['formal']
    assert len(replacements) == 4
    changes = []
    for index, (old, new) in enumerate(zip(before, after)):
        expected = replacements.get(str(Path(old['path']).resolve()).lower(), old)
        assert new == expected, ('Unexpected link input', index, old, new)
        if old != new: changes.append(dict(index=index, before=old, after=new))
    assert len(changes) == 4 and sum(x == y for x, y in zip(before, after)) == 220
    for row in [*before, *after]: m.verify(row)
    expected = m.read(F / 'expected-work.json')
    assert expected['processed_tokens'] == 1728 and expected['generated_tokens'] == 198 and expected['actual_graph_calls'] == 99
    for row in [expected['manifest'], expected['schedule'], *[x['file'] for x in expected['tapes']]]: m.verify(row)
    historical = m.read(F / 'runs/timing-01-hyle/observation.json')['raw']
    native = m.read(F / 'pins.json')['harness']
    for row in native.values(): m.verify(row)
    helper = m.module('frame_finite_ab_runner', native['runner']['path'])
    m.module('frame_finite_ab_observer', native['observer']['path']).install(helper)
    parse_code, parse_binding = m.legacy_phase_parser(native['old_performance_parser']['path'])
    argv = m.read(F / 'plan.json')['commands'][0]['command']
    jobs = []
    for mode, arms in [('timing', ['control', 'candidate', 'candidate', 'control', 'control', 'candidate']),
                       ('memory', ['control', 'candidate'])]:
        for index, arm in enumerate(arms, 1):
            command = list(argv); command[0] = images[arm]['path']
            jobs.append(dict(arm=arm, mode=mode, index=index, folder=str(P / f'{mode}-{index:02}-{arm}'),
                command=command, runtime=runtime[arm]))
    P.mkdir()
    helper.save(P / 'plan.json', dict(images=images, commands=jobs, linked_input_changes=changes,
        unchanged_link_inputs=220, build=build, function_checks=m.identity(function_path),
        fixed_work=m.identity(F / 'expected-work.json'), teacher_forced=True, mtp='off', quality_claim=False,
        same_window_control_rerun=True, prior_samples_pooled=False, process_count=8,
        control='bulk-append formal b3ff candidate', candidate='working Frame formal',
        step_timing_contract=m.read(F / 'plan.json')['step_timing_contract']))
    helper.save(P / 'phase-parser-binding.json', parse_binding)
    helper.gpu_snapshot(P, 'window-before')
    reports, ids_by_arm, runs, memory = {}, {}, [], {}
    try:
        for job in jobs:
            arm, folder = job['arm'], Path(job['folder'])
            print('AB_BEGIN', job['mode'], job['index'], arm, flush=True)
            m.verify(build); m.verify(images[arm]); m.verify(runtime[arm])
            env = os.environ.copy(); env['PATH'] = run_env[arm]['PATH']
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
            process = helper.execute(folder, 'hyle', job['command'], env, job['mode'] == 'memory')
            raw = json.loads((folder / 'stdout.log').read_text(encoding='utf-8'))
            audit = []; normalized = m.normalize(raw, audit)
            helper.save(folder / 'normalization-audit.json', audit)
            helper.save(folder / 'complete-nontime-report.json', normalized)
            differences = m.differences(reports[arm], normalized) if arm in reports else []
            helper.save(folder / 'within-arm-nontime-differences.json', differences)
            assert not differences, 'Within-arm complete non-time report changed; no refill'
            ids = m.check_work(raw, 'hyle', expected, historical)
            if arm not in reports: reports[arm], ids_by_arm[arm] = normalized, ids
            if len(reports) == 2:
                cross = m.differences(reports['control'], reports['candidate'])
                cross_ids = m.differences(ids_by_arm['control'], ids_by_arm['candidate'])
                helper.save(P / 'cross-arm-complete-nontime-differences.json', cross)
                helper.save(P / 'cross-arm-output-differences.json', cross_ids)
                assert not cross_ids, 'Frame changed returned IDs'
                assert not cross, 'Frame changed a complete non-time report field'
            ns = dict(folder=folder, raw=raw, waves=raw['waves'], variant='hyle', ids=ids, re=re)
            exec(parse_code, ns); observation = ns['observation']
            assert all(math.isfinite(v) and v > 0 for v in observation['metrics'].values())
            helper.save(folder / 'observation.json', observation)
            runs.append(dict(arm=arm, mode=job['mode'], index=job['index'], folder=str(folder), process=process,
                metrics=observation['metrics'], within_arm_complete_nontime_differences=0))
            if job['mode'] == 'memory':
                mem = m.read(folder / 'memory-summary.json')
                assert mem['setup_error'] is None and mem['thread_error'] is None
                memory[arm] = mem
            helper.save(P / 'runs.json', runs)
            print('AB_END', job['mode'], job['index'], arm, observation['metrics'], flush=True)
        assert len(runs) == 8 and set(memory) == {'control', 'candidate'}
        metrics = {arm: {key: helper.stats([x['metrics'][key] for x in runs if x['arm'] == arm and x['mode'] == 'timing'])
            for key in runs[0]['metrics']} for arm in images}
        comparisons = {key: dict(candidate_relative_to_control_percent=(metrics['candidate'][key]['median'] / metrics['control'][key]['median'] - 1) * 100,
            ranges_overlap=not (metrics['candidate'][key]['min'] > metrics['control'][key]['max'] or metrics['control'][key]['min'] > metrics['candidate'][key]['max']))
            for key in metrics['control']}
        memory_comparisons = {}
        for key in set(memory['control']['sampled_peaks']) | set(memory['candidate']['sampled_peaks']):
            old, new = memory['control']['sampled_peaks'].get(key), memory['candidate']['sampled_peaks'].get(key)
            memory_comparisons[key] = dict(control_bytes=old, candidate_bytes=new,
                candidate_minus_control_bytes=new-old if old is not None and new is not None else None,
                sampled_lower_bound=True)
        helper.save(P / 'summary.json', dict(status='COMPLETE_8_DIRECT_AB_EXACT_WORK_AND_NONTIME_STABLE',
            runs=runs, metrics=metrics, comparisons=comparisons, memory=memory, memory_comparisons=memory_comparisons,
            delivery_metrics=dict(prefill='prefill_tps', decode='full_decode_tps', vram='independent sampled_peaks and ready_baseline',
                combined_speed='session_output_tps and session_seconds', loading='load_seconds and ready_seconds'),
            cross_arm_complete_nontime_differences=0, cross_arm_returned_ID_differences=0, process_count=8,
            unmonitored_timing_processes=6, independent_memory_processes=2, old_or_peer_samples_pooled=False,
            statistical_significance_claim=False, limitations=[
                'Working Frame collection change versus same-window bulk-append control: arena/layout/append/Model differ, 220 of224 direct link inputs identical.',
                'Fixed teacher-forced ordinary equal-T B2 journey:198 returned IDs,1728 computed rows,99 executions; no MTP speed/quality/general-serving conclusion.',
                'Three timing samples per arm; finite medians/ranges only. Independent RAM/VRAM sampled peaks are lower bounds; unknown ready baselines remain unknown.',
                'OS page cache is retained. Loading endpoints are separate and do not establish cold-disk speed.']))
    except BaseException as error:
        helper.save(P / 'failure.json', dict(status='STOPPED_FIRST_FAILURE_NO_REFILL', completed=len(runs), error=repr(error)))
        raise
    finally:
        helper.gpu_snapshot(P, 'window-after')
    print('AB_COMPLETE_8_GPU_RELEASED', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['run'])
    parser.add_argument('--ready', required=True)
    parser.add_argument('--ready-sha256', required=True)
    args = parser.parse_args(); run(args.ready, args.ready_sha256)
