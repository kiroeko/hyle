"""Seven finite Frame function processes; explicit final ready, first failure stops."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-bulk-append-20261026'
spec = importlib.util.spec_from_file_location('frame_cached_bulk', B / 'build.py')
cached = importlib.util.module_from_spec(spec); spec.loader.exec_module(cached)
b = cached.b


def run(ready_path, ready_sha256):
    ready_path = Path(ready_path).resolve()
    ready_pin = b.pin(ready_path)
    assert ready_pin['sha256'] == ready_sha256.lower(), 'Wrong final build ready'
    ready = b.read(ready_path)
    assert ready['status'] == 'BUILT_NOT_RUN'
    assert set(ready['artifacts']) == {'test', 'cpu-vulkan', 'cuda', 'formal'}
    fixture = R / '.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    output = W / 'function-runs'
    assert not output.exists() and not (W / 'function-summary.json').exists(), 'No overwrite or automatic retry'
    jobs = [('append', 'test', [])]
    for backend, artifact in [('cpu', 'cpu-vulkan'), ('vulkan', 'cpu-vulkan'), ('cuda', 'cuda')]:
        jobs.extend([(backend, artifact, ['--' + backend, str(fixture)]),
                     (backend + '-lag1', artifact, ['--' + backend, str(fixture), '--mtp-lag1'])])
    manifest = [dict(name=name, image=ready['artifacts'][artifact]['image'],
        runtime=ready['artifacts'][artifact]['runtime'],
        command=[ready['artifacts'][artifact]['image']['path'], *tail]) for name, artifact, tail in jobs]
    for job in manifest:
        b.exact(job['image']); b.exact(job['runtime'])
    b.save(W / 'function-manifest.json', dict(ready=ready_pin, processes=manifest,
        fixture=b.pin(fixture / 'weights.tsv'), process_count=7,
        scope='One new Graph standalone; CPU/Vulkan/CUDA normal host-image and lag1. Each normal case includes ordinary and MTP.',
        downloads=0, performance_claim=False))
    results = []
    try:
        for job in manifest:
            b.exact(ready_pin); b.exact(job['image']); b.exact(job['runtime'])
            runtime = b.read(job['runtime']['path'])
            b.exact(runtime['native'])
            env = os.environ.copy(); env['PATH'] = runtime['PATH']
            env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
            print('FUNCTION_BEGIN', job['name'], flush=True)
            process = b.helper().execute(job['command'], env, output / job['name'], timeout=60)
            assert process['exit'] == 0
            if job['name'] != 'append':
                assert b.read(output / job['name'] / 'stdout.log')['status'] == 'PASS'
            else:
                text = (output / job['name'] / 'stdout.log').read_text(encoding='utf-8')
                assert 'working sources/logical-prefix authority/independent partial deltas/legacy ready equivalence PASS' in text
            results.append(dict(name=job['name'], process=process))
            b.save(W / 'function-state.json', dict(status='RUNNING', ready=ready_pin, completed=len(results), planned=7))
            print('FUNCTION_END', json.dumps(results[-1]), flush=True)
    except BaseException as error:
        b.save(W / 'function-failure.json', dict(status='STOPPED_FIRST_FAILURE_NO_REFILL', ready=ready_pin,
            completed=len(results), name=job['name'], error=repr(error), processes=results))
        raise
    b.save(W / 'function-summary.json', dict(status='SEVEN_FINITE_FUNCTION_PROCESSES_PASS',
        ready=ready_pin, processes=results, process_count=7, quality_claim=False, performance_claim=False,
        original335='NOT_RUN', downloads=0))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['run'])
    parser.add_argument('--ready', required=True)
    parser.add_argument('--ready-sha256', required=True)
    args = parser.parse_args(); run(args.ready, args.ready_sha256)
