"""One canonical prefix standalone TU/link/full finite run; no default action."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
P=W/'prefix'
R=W.parents[1]
B=R/'.scratch/inference-reusable-state-20261026/prefix2'
spec=importlib.util.spec_from_file_location('cached_frame',W/'build.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b=m.b


def build():
    assert not (P/'ready.json').exists() and not (P/'compile').exists()
    source=R/'tests/tools/qwen_prefix_cache_test.cc'
    recipe=R/'.scratch/inference-reusable-state-20261026/compile3/prefix/command.json'
    command=m.m.command(recipe,source,P/'compile')
    assert '/DHYLE_PREFIX_CACHE_STANDALONE' in command
    frozen=m.m.c.closure([source],[recipe]);b.save(P/'source-freeze.json',frozen)
    replace={}
    for name,old in [('arena',R/'.scratch/inference-host-image-20261026/arena/implementation/unit.obj'),
        ('layout',R/'.scratch/inference-layout-storage-validation-20261025/cpu1/compile/compute_batch--batch_layout/unit.obj')]:
        for row in b.read(W/'compile'/name/'actual-dependencies.json'):b.exact(row)
        replace[b.key(old)]=b.pin(W/'compile'/name/'unit.obj')
    inputs=b.read(B/'link-inputs.json');assert len(inputs)==135 and all(Path(x['path']).is_file() for x in inputs)
    old_test=R/'.scratch/inference-reusable-state-20261026/compile3/prefix/unit.obj'
    assert all(sum(b.key(x['path'])==key for x in inputs)==1 for key in [*replace,b.key(old_test)])
    b.save(P/'plan.json',dict(source=b.pin(source),recipe=b.pin(recipe),command=command,
        source_freeze=b.pin(P/'source-freeze.json'),baseline_inputs=b.pin(B/'link-inputs.json'),
        baseline_command=b.pin(B/'link/command.json'),baseline_runtime=b.pin(B/'runtime.json'),
        shared_Compute_objects=list(replace.values()),new_TUs=1,Model_Graph_SDK_native_compiles=0))
    h=b.helper();cl=command[0]
    env=h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=h.execute(command,env,P/'compile',timeout=180)
    dep=b.read(P/'compile/dependencies.json')['Data']
    actual=[b.pin(q) for q in dict.fromkeys([dep['Source'],*dep['Includes']])]
    own={b.key(x['path']):x for x in frozen}
    for row in actual:
        q=Path(row['path'])
        if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
            assert own[b.key(q)]['sha256']==row['sha256'],str(q)
    b.save(P/'compile/actual-dependencies.json',actual)
    for row in frozen:b.exact(row)
    replace[b.key(old_test)]=b.pin(P/'compile/unit.obj')
    image=P/'link/prefix-test.exe';args=[];changed=0
    for arg in b.read(B/'link/command.json')['command']:
        if b.key(arg) in replace:arg=replace[b.key(arg)]['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed==3
    linked=h.execute(args,env,image.parent,timeout=120)
    final=[replace.get(b.key(x['path']),x) for x in inputs];b.save(P/'link-inputs.json',final)
    runtime=b.read(B/'runtime.json');b.exact(runtime['native'])
    alias=image.parent/Path(runtime['native']['path']).name;os.link(runtime['native']['path'],alias)
    runtime['native_hardlink']=b.pin(alias);b.save(P/'runtime.json',runtime)
    b.save(P/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compile=compiled,link=linked,
        inputs=b.pin(P/'link-inputs.json'),runtime=b.pin(P/'runtime.json'),plan=b.pin(P/'plan.json'),
        new_TUs=1,Model_Graph_SDK_native_compiles=0))
    print('PREFIX_READY',json.dumps(b.pin(P/'ready.json')),flush=True)


def run():
    ready=b.read(P/'ready.json');b.exact(ready['image'])
    env=os.environ.copy();env['PATH']=b.read(ready['runtime']['path'])['PATH']
    process=b.helper().execute([ready['image']['path']],env,P/'run1',timeout=60)
    b.save(P/'run-summary.json',dict(status='FULL_STANDALONE_EXIT_ZERO',process=process,
        ready=b.pin(P/'ready.json'),performance_claim=False,model_run=False))


if __name__=='__main__':
    if sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
