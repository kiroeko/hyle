from pathlib import Path
import os,subprocess,json,time,sys
route,mode=sys.argv[1:];assert route in ('apple','vulkan') and mode in ('asan','ubsan','tsan')
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';root=base/f'foundation-f5-native-host-{route}-{mode}';parent=root/'parent';build=root/'build';out=base/f'g01-native-ragged-{route}-{mode}-rf';out.mkdir(exist_ok=True)
assert build.is_dir() and parent.is_dir();assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
body=(parent/'CMakeLists.txt').read_text()
if 'g01_native_ragged' not in body:
 if 'GTest::gtest_main' not in body:
  body+='\nset(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\nadd_subdirectory(/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-native-ragged-gtest EXCLUDE_FROM_ALL)\n'
 body+='\nadd_executable(g01_native_ragged "'+str(source/f'tests/compute_route_{route}/native_ragged_test.cc')+'")\ntarget_compile_features(g01_native_ragged PRIVATE cxx_std_23)\ntarget_link_libraries(g01_native_ragged PRIVATE hyle::compute GTest::gtest_main)\nhyle_apply_sanitizer(g01_native_ragged)\nhyle_stage_runtime(g01_native_ragged)\n'
 if route=='vulkan':body+='target_sources(g01_native_ragged PRIVATE "'+str(source/'tests/compute_route_vulkan/native_ragged_cost_test.cc')+'")\n'
 (parent/'CMakeLists.txt').write_text(body)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
record=out/'result.json';records=json.loads(record.read_text())['stages'] if record.exists() else []
def run(stage,args):
 n=1+sum(x['stage']==stage for x in records);log=out/f'{stage}-{n}.log';start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};records.append(row)
 record.write_text(json.dumps({'candidate':'0e9e011b8c8ff4a37e2bebc5ca8e4408be5e9368','route':route,'mode':mode,'scope':'actual Air host instrumented native objects with selected tiny actual GPU math; no driver/shader/LSan claim','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2300));print(f.read(2300).decode(errors='replace'))
  raise SystemExit(r.returncode)
if next((x for x in reversed(records) if x['stage']=='configure'),{}).get('exit_code')!=0:run('configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build)])
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_native_ragged','--parallel','4'])
commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True));flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode];checked=[]
names=[f'src/compute_route_{route}/{route}_batch.cc',f'tests/compute_route_{route}/native_ragged_test.cc']
if route=='vulkan':names.extend(['tests/compute_route_vulkan/native_ragged_cost_test.cc','src/compute_provider_ggml_vulkan/region.cc','src/compute_route_vulkan/vulkan_program.cc'])
for name in names:
 rows=[x for x in commands if x['file'].endswith(name)];assert rows and all(flag in x['command'] for x in rows),name;checked+=rows
(out/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2)+'\n')
exe=build/'g01_native_ragged'
if not exe.exists():exe=build/'bin/g01_native_ragged'
run('run',[str(exe)])
