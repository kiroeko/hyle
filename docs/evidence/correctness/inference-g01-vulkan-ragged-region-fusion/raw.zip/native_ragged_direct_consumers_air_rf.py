from pathlib import Path
import subprocess,os,time,json,sys,hashlib
route=sys.argv[1];assert route in ('apple','vulkan');base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';build=base/f'a-cpu-{route}/selected-graph/source-build';out=base/f'g01-ragged-direct-consumers-{route}-rf';out.mkdir(exist_ok=True)
assert build.is_dir();env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH'];record=out/'result.json';rows=json.loads(record.read_text())['stages'] if record.exists() else []
cache=(build/'CMakeCache.txt').read_text().splitlines()
home=Path(next(line.split('=',1)[1] for line in cache if line.startswith('CMAKE_HOME_DIRECTORY:')))
assert home==base/f'a-cpu-{route}/selected-graph/source-parent' and (home/'CMakeLists.txt').is_file()
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
manifest=json.loads((base/'g01-native-ragged-input-manifest.json').read_text())
for item in manifest['files']:
 assert hashlib.sha256((source/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
hook=out/'project.cmake';body='''if(PROJECT_NAME STREQUAL "hyle")
 function(g01_ragged_consumers)
  add_executable(g01_ragged_direct_consumer "'''+str(source/f'tests/graph/route_symmetry_{route}.cc')+'''")
  target_compile_features(g01_ragged_direct_consumer PRIVATE cxx_std_23)
  target_compile_options(g01_ragged_direct_consumer PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_libraries(g01_ragged_direct_consumer PRIVATE hyle::compute hyle::graph)
  hyle_stage_runtime(g01_ragged_direct_consumer)
'''
if route=='vulkan':body+='  target_compile_definitions(g01_ragged_direct_consumer PRIVATE HYLE_FOUNDATION_A_HYBRID=1)\n'
body+=' endfunction()\n cmake_language(DEFER CALL g01_ragged_consumers)\nendif()\n'
if not hook.exists() or hook.read_text()!=body:hook.write_text(body)
def run(stage,args):
 n=1+sum(x['stage']==stage for x in rows);log=out/f'{stage}-{n}.log';start=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row);record.write_text(json.dumps({'candidate':'0e9e011b8c8ff4a37e2bebc5ca8e4408be5e9368','scope':'selected original CPU/native hybrid finite/control/state and native graph consumers only; no globalmatrix','stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2100));print(f.read(2100).decode(errors='replace'))
  raise SystemExit(r.returncode)
if next((x for x in reversed(rows) if x['stage']=='configure'),{}).get('exit_code')!=0:run('configure',['/opt/homebrew/bin/cmake','-S',str(home),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook),'-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES'])
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_ragged_direct_consumer','--parallel','4'])
executables=[p for p in build.rglob('g01_ragged_direct_consumer') if p.is_file() and os.access(p,os.X_OK)]
assert len(executables)==1,executables
run('run',[str(executables[0])])
