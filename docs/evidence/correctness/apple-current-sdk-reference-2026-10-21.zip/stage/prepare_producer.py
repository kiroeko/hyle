from pathlib import Path
import base64,hashlib,json,re,runpy
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-current-sdk-2026-10-21';remote='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21'
factors=(P/'resolved-factors.txt').read_text().strip().split(',')
vendor=['mimalloc','xxhash','wyhash','fcontext','ported','random123_counter','mlx_cast','ggml_runtime','ggml_cpu_runtime','ggml_metal_iq1','bitsandbytes_apple','awq_apple','compressed_tensors_apple','ggml_q4k_apple','ds4_quantization','deepseek_quantization']
files={R/'CMakeLists.txt',R/'LICENSE',R/'THIRD_PARTY_NOTICES.md'}
for rel in['include','cmake',*[f'src/{x}'for x in factors],*[f'third_party/{x}'for x in vendor]]:
 q=R/rel
 if q.is_dir():files.update(x for x in q.rglob('*')if x.is_file())
search=[R,R/'include',*[x for x in(R/'src').iterdir()if x.is_dir()]];pattern=re.compile(r'^\s*#\s*include\s*"([^"]+)"',re.M);todo=list(files);seen=set()
while todo:
 p=todo.pop()
 if p in seen or p.suffix not in['.h','.hpp','.hh','.inc','.inl','.cc','.mm','.c','.cuh']:continue
 seen.add(p)
 for name in pattern.findall(p.read_text(errors='replace')):
  q=next((b/name for b in[p.parent,*search]if(b/name).is_file()),None)
  if q is not None:
   q=q.resolve()
   if q.is_relative_to(R)and q not in files:files.add(q);todo.append(q)
rows=[]
for p in sorted(files):
 b=p.read_bytes();rows.append(dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
manifest=[{k:v for k,v in x.items()if k!='data'}for x in rows];(P/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
code=r'''from pathlib import Path
import json,sys,base64,hashlib,subprocess
p=json.load(sys.stdin);root=Path(p['remote']);root.mkdir(parents=True,exist_ok=True);assert not root.is_symlink();source=root/'source';source.mkdir(exist_ok=True)
for x in p['files']:
 b=base64.b64decode(x['data']);assert hashlib.sha256(b).hexdigest()==x['sha256'];q=source/x['path'];q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists()or q.read_bytes()!=b:q.write_bytes(b)
(root/'source-manifest.json').write_text(json.dumps([{k:v for k,v in x.items()if k!='data'}for x in p['files']],indent=2)+'\n');(root/'driver.py').write_text(p['driver'])
h={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version'],'cmake':['/opt/homebrew/bin/cmake','--version'],'ninja':['/opt/homebrew/bin/ninja','--version'],'space':['df','-h',str(root)]}.items()};assert h['model']=='Mac16,12';(root/'hardware.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(remote=str(root),source_files=len(p['files']),source_bytes=sum(x['bytes']for x in p['files']),hardware=h)))
'''
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];result=ssh(code,dict(remote=remote,files=rows,driver=(P/'driver.py').read_text()));(P/'sync.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
