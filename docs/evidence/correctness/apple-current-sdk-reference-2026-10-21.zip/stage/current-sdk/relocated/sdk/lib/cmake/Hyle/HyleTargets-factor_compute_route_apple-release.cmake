#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_compute_route_apple" for configuration "Release"
set_property(TARGET hyle::_factor_compute_route_apple APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_route_apple PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX;OBJCXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_route_apple.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_route_apple )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_route_apple "${_IMPORT_PREFIX}/lib/libhyle_compute_route_apple.a" )

# Import target "hyle::_mlx_native" for configuration "Release"
set_property(TARGET hyle::_mlx_native APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_mlx_native PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmlx.a"
  )

list(APPEND _cmake_import_check_targets hyle::_mlx_native )
list(APPEND _cmake_import_check_files_for_hyle::_mlx_native "${_IMPORT_PREFIX}/lib/libmlx.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
