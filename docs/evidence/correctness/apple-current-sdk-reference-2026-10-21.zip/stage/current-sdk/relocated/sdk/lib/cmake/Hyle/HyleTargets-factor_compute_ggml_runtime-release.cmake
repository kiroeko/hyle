#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_compute_ggml_runtime" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ggml_runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ggml_runtime PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libhyle_compute_ggml_runtime.a"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ggml_runtime )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ggml_runtime "${_IMPORT_PREFIX}/lib/libhyle_compute_ggml_runtime.a" )

# Import target "hyle::_ggml_ggml" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libggml.a"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml "${_IMPORT_PREFIX}/lib/libggml.a" )

# Import target "hyle::_ggml_ggml-base" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-base PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libggml-base.a"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-base )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-base "${_IMPORT_PREFIX}/lib/libggml-base.a" )

# Import target "hyle::_ggml_ggml-metal" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-metal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-metal PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM;CXX;OBJC"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libggml-metal.a"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-metal )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-metal "${_IMPORT_PREFIX}/lib/libggml-metal.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
