from pathlib import Path
import hashlib,json,runpy
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-current-sdk-2026-10-21';AF=A/'apple-affine-constant-preparation-2026-10-21';old=json.loads((AF/'apple/mac/final/results/tests--graph_route_apple--affine_metadata_test.cc-identity.json').read_text());drift=[];checked=[]
for x in old['dependencies']:
 s=x['path'].replace('\\','/');rel=None
 if '/include/hyle/'in s:rel='include/hyle/'+s.split('/include/hyle/',1)[1]
 else:
  for marker in ['/apple/tests/','/apple/src/']:
   if marker in s:rel=marker.split('/')[-2]+'/'+s.split(marker,1)[1];break
 if rel:
  f=(R/rel).resolve()
  if f.is_file():
   sha=hashlib.sha256(f.read_bytes()).hexdigest();checked.append(dict(path=f.relative_to(R).as_posix(),actual_sha256=x['sha256'],current_sha256=sha));
   if sha!=x['sha256']:drift.append(checked[-1])
assert not drift,drift
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];root='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21';code='''from pathlib import Path
import hashlib,json,sys
p=json.load(sys.stdin);r=Path(p['root']);f=r/'affine-consumer/CMakeLists.txt';f.parent.mkdir(exist_ok=True);f.write_text(p['cmake']);obj=Path(p['object']['path']);assert hashlib.sha256(obj.read_bytes()).hexdigest()==p['object']['sha256'];print(json.dumps(dict(object=p['object'],cmake_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),canonical_dependencies_checked=len(p['checked']),canonical_dependency_drifts=0)))
'''
x=ssh(code,dict(root=root,object=old['object_identity'],cmake=(P/'affine-consumer-CMakeLists.txt').read_text(encoding='utf-8-sig'),checked=checked));x['project_dependency_audit']=checked;x['native_header_audit']='affine-test-sdk-header-reuse-check.json';(P/'affine-test-object-reuse.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({k:v for k,v in x.items()if k!='project_dependency_audit'},indent=2))
