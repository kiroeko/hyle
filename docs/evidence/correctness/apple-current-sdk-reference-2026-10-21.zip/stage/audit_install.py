from pathlib import Path
import base64,hashlib,json,runpy
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-current-sdk-2026-10-21';root='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21';ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
code=r'''from pathlib import Path
import hashlib,json,sys,base64,re,subprocess
p=json.load(sys.stdin);r=Path(p['root']);sdk=r/'relocated/sdk';assert sdk.is_dir()and not(r/'install').exists();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();identity=lambda f:dict(path=str(f),bytes=f.stat().st_size,sha256=sha(f));rows=[]
for f in sorted(sdk.rglob('*')):
 if f.is_file():rows.append(dict(relative=f.relative_to(sdk).as_posix(),bytes=f.stat().st_size,sha256=sha(f)))
source=json.loads((r/'source-manifest.json').read_text());source_bad=[x['path']for x in source if sha(r/'source'/x['path'])!=x['sha256']];assert not source_bad
for x in p['canonical']:
 assert next(y['sha256']for y in source if y['path']==x['path'])==x['sha256'],x['path']
cmake=list((sdk/'lib/cmake/Hyle').rglob('*.cmake'));bad=[]
for f in cmake:
 s=f.read_text()
 for prefix in [str(r/'source'),str(r/'build'),str(r/'install'),'/g09-air-direct-20261017/']:
  if prefix in s:bad.append(dict(path=str(f),prefix=prefix))
assert not bad,bad
header=sdk/'include/hyle/graph/apple.h';assert sha(header)==p['public_header_sha256'];libs=[x for x in rows if x['relative'].startswith('lib/')and x['relative'].endswith('.a')]
consumers=[];cleanup=[]
for kind,exe in [('compute','hyle_package_compute_cpp'),('graph','hyle_package_graph_cpp'),('affine','hyle_installed_affine_metadata')]:
 b=r/'consumer-build'/kind;f=b/exe;linklog=(r/'results'/(kind+'-build.stdout.log')).read_text();assert '/g09-air-direct-20261017/'not in linklog
 for token in re.findall(r'(/[^\s]+\.a)',linklog):
  if 'gtest'in token:continue
  assert str(sdk)in token,token
 met=b/'mlx.metallib';assert met.is_file();native_runtime=[x for x in rows if x['relative'].endswith('mlx.metallib')];assert len(native_runtime)==1;assert sha(met)==native_runtime[0]['sha256']
 consumers.append(dict(kind=kind,executable=identity(f),staged_metallib=identity(met),otool_L=subprocess.check_output(['/usr/bin/otool','-L',str(f)],text=True),link_source_scope='Current relocated SDK archives only, except original gtest archives and one frozen test object in the affine test consumer.'))
 cleanup.append(identity(f))
 if (b/(exe+'.map')).is_file():cleanup.append(identity(b/(exe+'.map')))
cache=(r/'build/CMakeCache.txt').read_text();selected=[x for x in cache.splitlines()if not x.startswith('//')and re.match(r'(HYLE_(COMPONENTS|COMPUTE_ROUTES|STATIC|INSTALL|BUILD_TESTS|BUILD_BENCH|TEST_INSTRUMENTATION|DEP_SOURCE_CACHE|DEP_BUILD_DIR)|CMAKE_(BUILD_TYPE|OSX_DEPLOYMENT_TARGET)|MLX_(BUILD|METAL|JIT))',x)]
audit=dict(remote_root=str(r),source_manifest_sha256=sha(r/'source-manifest.json'),source_files=len(source),source_drifts=source_bad,canonical_source_rows_confirmed=len(p['canonical']),installed_sdk=dict(prefix=str(sdk),original_prefix_absent=True,files=len(rows),bytes=sum(x['bytes']for x in rows),archives=libs,public_apple_header=identity(header),metadata_files=[identity(f)for f in cmake],forbidden_source_build_old_prefix_references=bad),consumers=consumers,configuration=selected,free_space=subprocess.check_output(['df','-h',str(r)],text=True),native_provenance='Current configured CMake locked materializers and current source/manifest; all native and Hyle producer objects were built by this actual build. No old archive overlays.')
(r/'results/current-sdk-audit.json').write_text(json.dumps(audit,indent=2)+'\n');(r/'results/installed-sdk-inventory.json').write_text(json.dumps(rows,indent=2)+'\n');(r/'results/cleanup-inventory.json').write_text(json.dumps(dict(remote_root=str(r),deletable_files=cleanup,retained_objects='All producer build objects, archives, generated CMake metadata, relocated SDK and source caches retained as the fixed current producer for future incremental use.',retained_build=str(r/'build'),retained_sdk=str(sdk),not_deleted=True),indent=2)+'\n')
files=[r/'build/compile_commands.json',r/'build/CMakeCache.txt',r/'build/install_manifest.txt',r/'build/.ninja_log']
files+=list((sdk/'lib/cmake/Hyle').glob('*.cmake'))
files+=[r/'consumer-build'/x/'compile_commands.json'for x in ['compute','graph']]
files+=[r/'consumer-build/affine/hyle_installed_affine_metadata.map']
files+=[r/'consumer-build'/x/'CTestTestfile.cmake'for x in ['compute','graph','affine']]
files+=[r/'results/current-sdk-audit.json',r/'results/installed-sdk-inventory.json',r/'results/cleanup-inventory.json']
out=[]
for f in files:
 if f.is_file():b=f.read_bytes();out.append(dict(relative=f.relative_to(r).as_posix(),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),data=base64.b64encode(b).decode()))
print(json.dumps(out))
'''
canonical=json.loads((P/'source-manifest.json').read_text());bad=[x['path']for x in canonical if hashlib.sha256((R/x['path']).read_bytes()).hexdigest()!=x['sha256']];assert not bad,bad
rows=ssh(code,dict(root=root,canonical=canonical,public_header_sha256=hashlib.sha256((R/'include/hyle/graph/apple.h').read_bytes()).hexdigest()));dest=P/'current-sdk';dest.mkdir(exist_ok=True)
for x in rows:
 b=base64.b64decode(x.pop('data'));assert hashlib.sha256(b).hexdigest()==x['sha256'];f=dest/x['relative'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
(dest/'files.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(dict(files=len(rows),bytes=sum(x['bytes']for x in rows))))
