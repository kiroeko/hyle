from pathlib import Path
import difflib,hashlib,json,re,zipfile
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-current-sdk-2026-10-21';O=R/'docs/evidence/correctness';stem='apple-current-sdk-reference-2026-10-21';O.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
identity=lambda f:dict(path=f.relative_to(R).as_posix(),bytes=f.stat().st_size,sha256=sha(f.read_bytes()))
validation=json.loads((P/'final-validation.json').read_text());frozen=json.loads((P/'source-freeze.json').read_text())
for x in frozen['source_files']:
 assert sha((R/x['path']).read_bytes())==x['sha256'],x['path']
assert validation['distinct_executed_cases']==4 and validation['failed_cases']==0 and validation['skipped_cases']==0
assert validation['affine_successful_submissions']==9 and validation['affine_expected_compile_budget_rejections']==1
members={}
def add(f,name=None):
 f=Path(f);assert f.is_file(),f;name=name or 'stage/'+f.relative_to(P).as_posix();assert name not in members,name
 assert f.suffix.lower()not in ['.a','.o','.obj','.exe','.dylib','.metallib','.air','.map'],f
 members[name]=f.read_bytes()
for name in ['final-validation.json','source-freeze.json','actual-dependencies-audit.json','consumer-source-manifest.json','affine-test-object-reuse.json','affine-test-sdk-header-reuse-check.json','reused-test-harness-identity.json','producer-plan.json','dryrun-summary.json','relocation.json','actual-link-owner-excerpt.txt','product-dependency-fix.diff','prepare_producer.py','driver.py','prepare_consumers.py','consumer_driver.py','prepare_affine.py','affine-consumer-CMakeLists.txt','audit_install.py','collect.py','sync.json','publish.py']:
 add(P/name)
for attempt,tag in [('configure1','configure'),('install1','install')]:
 for suffix in ['command.json','result.json','stdout.log','stderr.log']:add(P/'attempts'/attempt/'results'/(tag+'.'+suffix))
for f in sorted((P/'attempts/final/results').iterdir()):
 if f.name in ['current-sdk-audit.json','installed-sdk-inventory.json','cleanup-inventory.json','actual-dependencies-audit.json']:continue
 if f.suffix in ['.json','.log','.xml']:add(f)
for name in ['results/current-sdk-audit.json','results/installed-sdk-inventory.json','results/cleanup-inventory.json','build/compile_commands.json','build/CMakeCache.txt','build/install_manifest.txt','build/.ninja_log','consumer-build/compute/compile_commands.json','consumer-build/graph/compile_commands.json']:
 add(P/'current-sdk'/name)
for f in sorted((P/'current-sdk/relocated/sdk/lib/cmake/Hyle').glob('*.cmake')):add(f)
for name in ['before/cmake/HyleComponents.cmake','source/cmake/HyleComponents.cmake']:add(P/name)
for rel in ['include/hyle/graph/apple.h','tests/graph_route_apple/affine_metadata_test.cc','cmake/HyleDependencyLock.json','cmake/HyleAppleDependencies.cmake','src/compute_ggml_runtime/CMakeLists.txt','third_party/mlx_cast/metal-shared-ptr.json','third_party/ggml_runtime/patches.json','third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md','third_party/ggml_runtime/metal-patches.json','third_party/ggml_cpu_runtime/patches.json','third_party/ggml_metal_iq1/patches.json']:
 f=R/rel
 if f.is_file():add(f,'source/'+rel)
for kind,names in [('compute',['CMakeLists.txt','main.cc','apple_ffn.h','apple_recurrent.h','workload.h']),('graph',['CMakeLists.txt','main.cc','apple_ffn.h','apple_recurrent.h'])]:
 for name in names:
  f=R/'samples/package'/kind/'cpp'/name;add(f,'source/'+f.relative_to(R).as_posix())
prior=[]
for stem2,category in [('apple-affine-constant-preparation-reference-2026-10-21','performance'),('apple-affine-metadata-preparation-2026-10-21','performance')]:
 f=R/'docs/evidence'/category/(stem2+'.json');prior.append(identity(f))
summary=dict(schema='hyle.current-installed-sdk-reference.v1',date='2026-10-21',status='PASS',scope='Current Apple-only static Compute+Graph+graph_progress producer, true CMake build/install, relocated installed consumption, and the two affine constant-preparation regressions linked solely to the current SDK.',results=dict(distinct_cases=4,passed=4,failed=0,skipped=0,cases=validation['tests'],affine_successful_submissions=9,affine_expected_compile_budget_rejections=1,sample_submission_count=None,ctest_aggregation='Three CTest entries: two existing samples and one affine test executable containing two GoogleTest cases. The affine CTest wrapper is not counted as an extra fifth case.'),hardware=validation['hardware'],configuration=validation['configuration'],producer=validation['producer'],installed_sdk=validation['installed_sdk'],relocation=dict(original_prefix_absent=True,new_prefix=validation['installed_sdk']['prefix'],method='Renamed the actual cmake --install output to relocated/sdk; configured fresh consumers with only that explicit Hyle_DIR and CMAKE_PREFIX_PATH. No manual archive/member replacement or native override object was used.'),source_identity=dict(producer_inputs=751,source_manifest_sha256=frozen['remote_source_manifest_sha256'],source_freeze=identity(P/'source-freeze.json'),actual_ninja_dependency_audit=identity(P/'actual-dependencies-audit.json'),actual_project_dependencies=420,current_canonical_drift=0),actual_link=dict(archives_scope='Current relocated installed Hyle, MLX and ggml archives. The affine regression additionally uses one frozen current-layout test object and the unchanged original GoogleTest harness archives.',observer_context=False,old_Hyle_loose_overrides=False,owner_excerpt=identity(P/'actual-link-owner-excerpt.txt'),test_object_reuse=identity(P/'affine-test-object-reuse.json'),native_header_reuse=identity(P/'affine-test-sdk-header-reuse-check.json'),harness=identity(P/'reused-test-harness-identity.json')),retained_failures=validation['retained_failures'],product_change=dict(file='cmake/HyleComponents.cmake',component='graph_route_apple',change='Added container to PRIVATE_DEPS because the existing Apple WeightBatch bind adapter directly includes container/small_vector.h.',scope='Apple-only factor dependency edge; no PUBLIC dependency or audit bypass. This edge does not alter the Linux selected closure.',diff=identity(P/'product-dependency-fix.diff')),ABI=dict(description='The installed Apple CompileReport includes prepared_constant_count and prepared_constant_bytes. Every selected product owner was rebuilt by the current producer. The frozen affine test object uses the same current public header and the same 12 native headers; 75 actual canonical project dependencies were rechecked.',public_header=validation['installed_sdk']['public_apple_header']),limitations=validation['limits']+[validation['graph_progress_scope'],validation['sample_submission_count_scope'],'No throughput, physical allocation or full operator/model matrix claim. This is a current default CMake warning-policy build, not a -Werror producer build; five external warnings are retained in the actual build log.'],retention=dict(cleanup_performed=False,instruction='Preserve the fixed producer, relocated SDK, consumer builds and current objects. No deletion or test.ps1 execution is part of this publication.',producer_build=validation['retained_producer_build'],installed_sdk=validation['retained_installed_sdk'],candidate_cleanup_inventory=identity(P/'current-sdk/results/cleanup-inventory.json')),related_evidence=prior)
summary['dependency_lock']=identity(R/'cmake/HyleDependencyLock.json')
members['summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
index=[dict(path=k,bytes=len(b),sha256=sha(b))for k,b in sorted(members.items())];members['inventory.json']=(json.dumps(dict(files=index,excluded='No SDK payload archive, executable, object, full link map, metallib, weights or source/download cache.'),indent=2)+'\n').encode()
z=O/(stem+'.zip')
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
 for name,b in sorted(members.items()):archive.writestr(name,b)
with zipfile.ZipFile(z)as archive:
 assert len(archive.namelist())==len(members)
 for name,b in members.items():assert archive.read(name)==b,name
summary['evidence_zip']=identity(z);summary['evidence_zip']['members']=len(members);summary['evidence_zip']['members_checked']=len(members)
report=O/(stem+'.json');report.write_text(json.dumps(summary,indent=2)+'\n');receipt=dict(report=identity(report),zip=identity(z),members=len(members),source_files_checked=751,no_build_or_test_during_publication=True);(P/'publication.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
