from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path(__file__).resolve().parent;O=R/'results';O.mkdir(exist_ok=True)
env=dict(os.environ,PATH='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
commands={'configure':['/opt/homebrew/bin/cmake','-S',str(R/'source'),'-B',str(R/'build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DHYLE_COMPONENTS=compute;graph;graph_progress','-DHYLE_COMPUTE_ROUTES=apple','-DHYLE_STATIC=ON','-DHYLE_INSTALL=ON','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_SANITIZER=off','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'],
 'plan':['/opt/homebrew/bin/ninja','-C',str(R/'build'),'-t','commands','all'],
 'dryrun':['/opt/homebrew/bin/ninja','-C',str(R/'build'),'-n','-v'],
 'build':['/opt/homebrew/bin/cmake','--build',str(R/'build'),'--parallel','2'],
 'install':['/opt/homebrew/bin/cmake','--install',str(R/'build'),'--prefix',str(R/'install')]}
tag=sys.argv[1];assert tag in commands
manifest=json.loads((R/'source-manifest.json').read_text())
for x in manifest:assert hashlib.sha256((R/'source'/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
record=dict(argv=commands[tag],cwd=str(R),PATH=env['PATH'],started=time.time(),source_manifest_sha256=hashlib.sha256((R/'source-manifest.json').read_bytes()).hexdigest());(O/(tag+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
with (O/(tag+'.stdout.log')).open('w')as out,(O/(tag+'.stderr.log')).open('w')as err:
 p=subprocess.run(commands[tag],cwd=R,env=env,stdout=out,stderr=err)
record.update(exit=p.returncode,seconds=time.time()-record['started']);(O/(tag+'.result.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
raise SystemExit(p.returncode)
