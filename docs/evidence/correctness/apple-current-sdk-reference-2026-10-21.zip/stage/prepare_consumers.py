from pathlib import Path
import base64,hashlib,json,runpy
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-current-sdk-2026-10-21';remote='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21'
rows=[]
for rel in ['samples/package/compute/cpp','samples/package/graph/cpp']:
 for f in sorted((R/rel).iterdir()):
  if not f.is_file():continue
  b=f.read_bytes();rows.append(dict(path=f.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
(P/'consumer-source-manifest.json').write_text(json.dumps([{k:v for k,v in x.items()if k!='data'}for x in rows],indent=2)+'\n')
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
code='''from pathlib import Path
import base64,hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['remote']);prefix=root/'relocated/sdk';original=root/'install';assert not root.is_symlink()
if original.exists():
 assert not prefix.exists();prefix.parent.mkdir(exist_ok=True);original.rename(prefix)
assert prefix.is_dir()and not original.exists()and not prefix.is_symlink()
for x in p['files']:
 b=base64.b64decode(x['data']);assert hashlib.sha256(b).hexdigest()==x['sha256'];f=root/'consumer-source'/x['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
(root/'consumer-source-manifest.json').write_text(json.dumps([{k:v for k,v in x.items()if k!='data'}for x in p['files']],indent=2)+'\\n')
(root/'consumer_driver.py').write_text(p['driver']);print(json.dumps(dict(prefix=str(prefix),original_prefix_absent=not original.exists(),consumer_files=len(p['files']),consumer_bytes=sum(x['bytes']for x in p['files']))))
'''
result=ssh(code,dict(remote=remote,files=rows,driver=(P/'consumer_driver.py').read_text()));(P/'relocation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
