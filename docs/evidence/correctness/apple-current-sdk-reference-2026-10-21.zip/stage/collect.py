from pathlib import Path
import base64,hashlib,json,runpy,sys
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';P=A/'apple-current-sdk-2026-10-21';remote='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21'
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
tag=sys.argv[1];dest=P/'attempts'/tag;dest.mkdir(parents=True,exist_ok=True)
code='''from pathlib import Path
import base64,hashlib,json,sys
p=json.load(sys.stdin);r=Path(p['remote']);rows=[]
for f in sorted((r/'results').glob('*')):
 if f.is_file():
  b=f.read_bytes();rows.append(dict(path='results/'+f.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
for name in ['hardware.json','source-manifest.json']:
 f=r/name
 if f.exists():
  b=f.read_bytes();rows.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
print(json.dumps(rows))
'''
rows=ssh(code,dict(remote=remote))
for x in rows:
 b=base64.b64decode(x.pop('data'));assert hashlib.sha256(b).hexdigest()==x['sha256'];q=dest/x['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(dest/'files.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(dict(destination=str(dest),files=len(rows))))
