"""Root-only bounded cached host/CPU checks; never downloads or profiles."""
from pathlib import Path
import hashlib, json, os, subprocess, sys, time
W=Path(__file__).resolve().parent
R=W.parents[1]
kind=sys.argv[1]
assert kind in ('host','cpu')
ready=json.loads((W/kind/'ready.json').read_text())
runtime=json.loads(Path(ready['runtime']['path']).read_text())
image=ready['image']
assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest()==image['sha256']
command=[image['path']]
if kind=='cpu': command.append(str(R/'.scratch/inference-e4-model-20261025/fixture-preparation/ct-e4-aa'))
env=os.environ.copy(); env.update(runtime.get('configured_flags',{}))
env.update(PATH=str(Path(image['path']).parent)+';'+runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
F=W/kind/'run1';F.mkdir()
start=time.perf_counter()
with (F/'stdout.log').open('xb') as out,(F/'stderr.log').open('xb') as err:
    child=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    print(kind,'native_pid',child.pid,flush=True)
    timeout=False
    try:code=child.wait(timeout=90)
    except subprocess.TimeoutExpired:timeout=True;child.kill();code=child.wait(timeout=10)
result=dict(pid=child.pid,exit=code,timeout=timeout,seconds=time.perf_counter()-start,command=command,image=image)
(F/'process.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result)); print((F/'stdout.log').read_text())
assert code==0 and not timeout,'Retain actual failure; do not overwrite'
