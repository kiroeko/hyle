"""Offline comparison of the four existing runs2 consumers; never launches work.

Usage: python -B .../consumer-cases/compare.py write | check
Trace payloads are hashed, not copied into evidence. No tolerance/refill/seed search.
"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import sys

D = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest)


def non_time(value, removed, path='$'):
    if isinstance(value, list):
        return [non_time(item, removed, f'{path}[{i}]') for i, item in enumerate(value)]
    if not isinstance(value, dict):
        return value
    output = {}
    for key, item in value.items():
        if key == 'seconds' or key.endswith('_seconds') or key.endswith('tokens_per_second'):
            removed.append(path + '.' + key)
        else:
            output[key] = non_time(item, removed, path + '.' + key)
    return output


def differences(a, b, path='$'):
    if type(a) is not type(b):
        return [dict(path=path, baseline=a, candidate=b, reason='JSON type')]
    if isinstance(a, dict):
        output = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                output.append(dict(path=path + '.' + key, baseline_present=key in a, candidate_present=key in b))
            else:
                output.extend(differences(a[key], b[key], path + '.' + key))
        return output
    if isinstance(a, list):
        output = [] if len(a) == len(b) else [dict(path=path, baseline_length=len(a), candidate_length=len(b))]
        for i, (x, y) in enumerate(zip(a, b)):
            output.extend(differences(x, y, f'{path}[{i}]'))
        return output
    return [] if a == b else [dict(path=path, baseline=a, candidate=b)]


def leaf_count(value):
    if isinstance(value, dict):
        return sum(map(leaf_count, value.values()))
    if isinstance(value, list):
        return sum(map(leaf_count, value))
    return 1


def inventory(folder):
    folder = Path(folder)
    return {path.relative_to(folder).as_posix(): pin(path)
            for path in sorted(folder.rglob('*')) if path.is_file()}


def coverage(raw):
    sessions = raw['sessions']
    assert raw['session_count'] == 2 and raw['turn_count'] == 6
    assert raw['restore_count'] == raw['idle_evictions'] == raw['pending_flushed_tokens'] == 4
    assert raw['generated_tokens'] == 18 and raw['max_sessions'] == raw['active_sequences'] == 1
    rows = []
    details = []
    for session in sessions:
        result = session['result']
        assert len(result['turns']) == 3 and len(result['generated_ids']) == 9
        assert result['visible_tokens'] == 25 and session['restore_count'] == 2
        assert [turn['new_user_tokens'] for turn in result['turns']] == [15, 0, 2]
        assert [turn['pending_flushed'] for turn in result['turns']] == [0, 1, 1]
        rows.extend(record for record in session['ledger'] if record['generation'])
        details.append(dict(session_id=session['session_id'], generated_ids=result['generated_ids'],
            turn_count=3, visible_tokens=result['visible_tokens'], restore_count=session['restore_count'],
            sampling_stream=result['sampling_stream'], sampling_draw_cursor=result['sampling_draw_cursor'],
            draft_frontier=result.get('draft_frontier'), draft_lag=result.get('draft_lag'),
            ledger_records=len(session['ledger']), decision_changes=result.get('decision_changes', [])))
    double = [row for row in rows if row['verified_rows'] == 2]
    selected = Counter(row['accepted'] for row in double)
    return dict(sessions=details, turns=6, outputs=18, restores=raw['restore_count'],
        idle_evictions=raw['idle_evictions'], pending_flushed=raw['pending_flushed_tokens'],
        generation_ledger_records=len(rows), double_token_verifications=len(double),
        selected_prefix_rows={str(key): value for key, value in sorted(selected.items())},
        accepted_proposal_rounds=sum(row['consumed_drafts'] > 0 for row in double),
        rejected_proposal_rounds=sum(row['consumed_drafts'] == 0 for row in double),
        draft_rounds=raw.get('draft_rounds', 0), consumed_drafts=raw.get('consumed_drafts', 0),
        normalized_lag_rows=raw.get('normalized_lag_rows', 0),
        recomputed_decision_changes=raw['recomputed_decision_changes'])


def compare():
    manifest = read(D / 'manifest2.json')
    cases = {case['id']: case for case in manifest['cases']}
    pairs, trace_pairs, processes = [], [], []
    for mode in ['ordinary', 'mtp-k1']:
        case_a, case_b = cases[mode + '-baseline'], cases[mode + '-candidate']
        reports = []
        for case in [case_a, case_b]:
            process = read(case['process_record'])
            assert process['exit'] == 0 and not process['timeout']
            assert process['command'] == case['argv'] and process['image'] == case['image']
            assert process['input_source'] == manifest['input_source']
            stdout = Path(case['stdout']).read_text(encoding='utf-8').strip().splitlines()
            assert len(stdout) == 1, 'Require the complete original one-object report'
            reports.append(json.loads(stdout[0]))
            processes.append(dict(id=case['id'], pid=process['pid'], exit=process['exit'], timeout=False,
                seconds=process['seconds'], process=pin(case['process_record']),
                stdout=pin(case['stdout']), stderr=pin(case['stderr']), image=process['image']))
        removed_a, removed_b = [], []
        normalized_a = non_time(reports[0], removed_a)
        normalized_b = non_time(reports[1], removed_b)
        assert removed_a == removed_b, 'Timing field presence is also audited'
        diff = differences(normalized_a, normalized_b)
        a, b = inventory(case_a['trace']), inventory(case_b['trace'])
        names_same = list(a) == list(b)
        trace_diff = [name for name in sorted(set(a) | set(b))
            if name not in a or name not in b or (a[name]['bytes'], a[name]['sha256']) != (b[name]['bytes'], b[name]['sha256'])]
        shared_rows = [[name, a[name]['bytes'], a[name]['sha256']] for name in a]
        facts_a, facts_b = coverage(reports[0]), coverage(reports[1])
        assert facts_a == facts_b
        if mode == 'mtp-k1':
            assert facts_a['double_token_verifications'] == 6
            assert facts_a['accepted_proposal_rounds'] == 4 and facts_a['rejected_proposal_rounds'] == 2
            assert set(facts_a['selected_prefix_rows']) == {'1', '2'}
        trace_pairs.append(dict(mode=mode, all_file_inventories_equal=names_same and not trace_diff,
            baseline_root=case_a['trace'], candidate_root=case_b['trace'],
            inventory_columns=['relative_path', 'bytes', 'sha256_both_arms'],
            inventory=shared_rows, inventory_sha256=hashlib.sha256(canonical(shared_rows)).hexdigest(),
            differences=trace_diff))
        pairs.append(dict(mode=mode, status='PASS' if not diff and names_same and not trace_diff else 'FAIL',
            all_non_time_JSON_equal=not diff, non_time_leaf_values=leaf_count(normalized_a),
            normalized_report_sha256=hashlib.sha256(canonical(normalized_a)).hexdigest(),
            ignored_time_rate_paths=removed_a, ignored_resource_or_path_fields=[],
            non_time_differences=diff, trace_file_count=len(a), trace_bytes_per_arm=sum(row['bytes'] for row in a.values()),
            trace_kind_counts=dict(Counter(Path(name).suffix for name in a)), trace_differences=trace_diff,
            coverage=facts_a))
    failed_path = D / 'runs/ordinary-baseline/process.json'
    failure = read(failed_path)
    failure_stderr = D / 'runs/ordinary-baseline/stderr.log'
    assert failure['exit'] == 1 and not failure['timeout']
    assert 'prepared manifest line length limit exceeded' in failure_stderr.read_text()
    process_summary = dict(status='ALL_FOUR_CORRECTED_NATIVE_PROCESSES_EXIT0_NO_TIMEOUT',
        corrected_processes=processes,
        original_V1_rejection=dict(pid=failure['pid'], exit=failure['exit'], seconds=failure['seconds'],
            process=pin(failed_path), stdout=pin(D / 'runs/ordinary-baseline/stdout.json'), stderr=pin(failure_stderr),
            outcome='INPUT_REJECTED_BEFORE_MODEL_EXECUTION', correction=pin(D / 'input-v2-correction.json')),
        native_attempts_total=5, completed_corrected_model_processes=4,
        additional_model_runs_by_analyzer=0)
    report = dict(status='PASS' if all(pair['status'] == 'PASS' for pair in pairs) else 'FAIL',
        method='Compare every JSON field recursively with exact type/value/presence after enumerated clock/rate exclusions only. No resource/path exclusions, tolerance or token-only projection.',
        manifest=pin(D / 'manifest2.json'), analyzer=pin(__file__), pairs=pairs,
        important_existing_fact='K1 has three historical-vs-recomputed decision changes in alice, identical in baseline and candidate; they are preserved, not changed to zero or excluded.',
        limits=['No ordinary-to-MTP equality assertion or speed ranking; diagnostic process clocks are retained only as receipts.',
            'Decision-level traces cover hidden/logits and routes, not complete KV/carry/draft/GDN/conv bytes or held-old-Snapshot immutability.',
            'Both natural K1 selected-prefix extents1/2, accepted/rejected proposals and lag normalization are actually covered; broader K/MTP modes, platforms and long contexts remain outside this finite check.'])
    trace_hashes = dict(status='ALL_PAIRED_TRACE_FILE_BYTES_HASH_IDENTICAL', pairs=trace_pairs,
        payload_policy='Each shared inventory was computed independently for both arms. Only hashes/lengths are retained here; no hidden/logits buffers are packaged.')
    return {'comparisons.json': report, 'tracehashes.json': trace_hashes, 'process-summary.json': process_summary}


if __name__ == '__main__':
    assert sys.argv[1:] in [['write'], ['check']], __doc__
    output = compare()
    for name, value in output.items():
        if sys.argv[1:] == ['write']:
            with (D / name).open('xb') as stream:
                stream.write((json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n').encode())
        else:
            assert read(D / name) == value, name
    print(json.dumps(dict(status=output['comparisons.json']['status'],
        files=[pin(D / name) for name in output]), indent=2))
