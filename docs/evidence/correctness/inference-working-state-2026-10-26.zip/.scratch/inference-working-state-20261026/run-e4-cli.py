"""Two finite current CLI runs; reuse the already observed 58d70b723 controls."""
from pathlib import Path
import hashlib, json, os, subprocess, time
W=Path(__file__).resolve().parent; R=W.parents[1]
B=R/'.scratch/inference-common-core-20261026'
C=W/'e4-cli'; C.mkdir()
ready=json.loads((W/'cuda/ready.json').read_text())
runtime=json.loads(Path(ready['runtime']['path']).read_text())
image=ready['image']
assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest()==image['sha256']
env=os.environ.copy();env.update(runtime.get('configured_flags',{}))
env.update(PATH=str(Path(image['path']).parent)+';'+runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
commands=json.loads((B/'consumer-cases/commands-cuda.json').read_text())
for case,arms in commands.items():
    old=arms['candidate']; command=[image['path'],*old['argv'][1:]]
    start=time.perf_counter()
    with (C/(case+'.stdout.json')).open('xb') as out,(C/(case+'.stderr.log')).open('xb') as err:
        child=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        print(case,'native_pid',child.pid,flush=True)
        timeout=False
        try:code=child.wait(timeout=90)
        except subprocess.TimeoutExpired:timeout=True;child.kill();code=child.wait(timeout=10)
    result=dict(pid=child.pid,exit=code,timeout=timeout,seconds=time.perf_counter()-start,command=command,
                baseline_stdout=old['stdout'],baseline_commit='58d70b723',image=image)
    (C/(case+'.process.json')).write_text(json.dumps(result,indent=2)+'\n')
    assert code==0 and not timeout,'Retain actual failure; do not overwrite'
    compare=[os.sys.executable,'-B',str(B/'consumer-cases/compare.py'),case,old['stdout'],
             str(C/(case+'.stdout.json')),'--backend','cuda','--out',str(C/(case+'.comparison.json'))]
    check=subprocess.run(compare,cwd=R,capture_output=True,text=True)
    (C/(case+'.comparison.stdout.log')).write_text(check.stdout)
    (C/(case+'.comparison.stderr.log')).write_text(check.stderr)
    print(check.stdout,flush=True)
    assert check.returncode==0,'Retain actual offline comparison failure; no model retry'
