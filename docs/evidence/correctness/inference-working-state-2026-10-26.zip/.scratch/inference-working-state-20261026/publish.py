"""Explicit bounded text evidence; plan is local, publish creates one JSON/ZIP.
No build, analyzer, native consumer, network or directory traversal is launched.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile
import zlib

W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-common-core-20261026'
P = R/'.scratch/inference-review-fixes-20261026'
V = R/'.scratch/inference-version-room-20261026'
C = W/'consumer-cases'
DEST = R/'docs/evidence/correctness/inference-working-state-2026-10-26'
BASELINE = '58d70b723'
SOURCES = ('engine/inference/version_admission.h', 'engine/models/qwen35/main.cc',
 'engine/models/qwen35/session_state.h', 'engine/models/qwen35/prefix_cache.h',
 'engine/models/qwen35/batch_probe.cc', 'engine/models/qwen35/retirement_probe.cc',
 'engine/models/qwen35/retained_budget_probe.cc', 'engine/models/qwen35/mtp_session_probe.cc',
 'include/hyle/compute/providers/cuda.h', 'tests/CMakeLists.txt',
 'tests/tools/inference_version_room_test.cc', 'tests/tools/qwen_prefix_cache_test.cc',
 'tests/tools/qwen_chunked_prefill_case.h', 'tests/tools/qwen_e4_cache_case.h',
 'tests/tools/qwen_midturn_resume_case.h', 'tests/tools/qwen_mtp_prefix_value_probe.cc',
 'tests/tools/qwen_random_mtp_probe.cc', 'tests/tools/qwen_request_ledger_case.h',
 'tests/tools/qwen_sampling_policy_case.h')
PROBES = ('batch_probe', 'retirement_probe', 'retained_budget_probe', 'mtp_session_probe',
          'qwen_random_mtp_probe', 'qwen_mtp_prefix_value_probe')
RUNS = ('ordinary-baseline', 'ordinary-candidate', 'mtp-k1-baseline', 'mtp-k1-candidate')
E4_IDS = ('d1011.ids', 'd1415.ids', 'd34.ids', 'd78.ids', 'd8.ids', 'i12.ids', 'i15.ids',
 'p1112.ids', 'p12.ids', 'p121314.ids', 'p1289.ids', 'p12910.ids', 'p13.ids',
 'p345.ids', 'p5.ids', 'p56.ids', 'p67.ids', 'p91011.ids')


def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def encode(value): return (json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode('utf8')
def pin(p):
    p = Path(p); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def collect():
    files = {}
    def add(p):
        p = Path(p)
        assert p.is_file() and p.is_relative_to(R), str(p)
        assert p.suffix.lower() in {'.h', '.cc', '.py', '.json', '.log', '.txt', '.ids', '.schedule', '.tsv'}
        assert p.stat().st_size < 2_000_000, str(p)
        files[p.relative_to(R).as_posix()] = p
    def stage(base, name):
        for f in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(base/name/f)
    def run(base, name, stdout='stdout.log'):
        for f in ('process.json', stdout, 'stderr.log'): add(base/name/f)
    for f in SOURCES: add(R/f)
    add(P/'e4-consumer.cc'); add(V/'check_host.py')
    for f in ('publish.py', 'build.py', 'build-summary.json', 'comment-only-header.json', 'reused-report-abi.json',
              'run-check.py', 'run-e4-cli.py', 'run-models.py', 'check-probes.py', 'check-probes-attempt1.py',
              'design-review.json', 'diagnostics-migration.json', 'diagnostics-migration-before.json', 'provider-boundary-review.json'): add(W/f)
    for target in ('cuda', 'cpu', 'host'):
        for f in ('plan.json', 'ready.json', 'runtime.json'): add(W/target/f)
        stage(W/target, 'compile'); stage(W/target, 'link')
    stage(V/'host1', 'compile')
    for s in ('compile', 'link', 'run'): stage(V/'host2', s)
    add(V/'host2/summary.json')
    run(W/'host', 'run1'); run(W/'cpu', 'run1')
    for case in ('natural', 'teacher'):
        for suffix in ('process.json', 'stdout.json', 'stderr.log', 'comparison.json', 'comparison.facts.json',
                       'comparison.stdout.log', 'comparison.stderr.log'): add(W/'e4-cli'/(case+'.'+suffix))
        for suffix in ('process.json', 'stdout.json', 'stderr.log'): add(B/'consumer-cases'/case/('candidate.cuda.'+suffix))
        for f in ('sessions.tsv', 'A.schedule', 'B.schedule', 'C.schedule', 'D.schedule'): add(B/'consumer-cases'/case/f)
    for f in E4_IDS: add(B/'consumer-cases/inputs'/f)
    for f in ('compare.py', 'commands-cuda.json'): add(B/'consumer-cases'/f)
    for f in ('manifest.json', 'manifest2.json', 'input-v2-correction.json', 'comparison-scope.json', 'compare.py',
              'comparisons.json', 'tracehashes.json', 'process-summary.json', 'alice.initial.ids', 'alice.suffix.ids',
              'alice.schedule', 'bob.initial.ids', 'bob.suffix.ids', 'bob.schedule', 'empty.ids', 'sessions.tsv'): add(C/f)
    run(C/'runs', 'ordinary-baseline', 'stdout.json')
    for name in RUNS: run(C/'runs2', name, 'stdout.json')
    for attempt,names in [('syntax1', PROBES[:5]), ('syntax2', PROBES[4:])]:
        add(W/attempt/'summary.json')
        for name in names: stage(W/attempt, name)
    builds = read(W/'build-summary.json')
    for target in ('cuda', 'host'):
        expected = read(W/target/'ready.json')['source']; assert pin(expected['path']) == expected
    model = read(C/'comparisons.json'); traces = read(C/'tracehashes.json')
    syntax = {name: read(W/name/'summary.json') for name in ('syntax1', 'syntax2')}
    host_lines = (W/'host/run1/stdout.log').read_text(encoding='utf8').splitlines()
    host_cases = [line for line in host_lines if line.startswith('PASS ')]
    summary = dict(status='BOUNDED_WORKING_STATE_CORRECTNESS_RESULTS', baseline_commit=BASELINE,
        publication_head=subprocess.run(['git','rev-parse','HEAD'],cwd=R,check=True,capture_output=True,text=True).stdout.strip(),
        sources=[pin(R/f) for f in SOURCES], builds=builds,
        version_room=dict(final=read(V/'host2/summary.json'), first_compile_failure=read(V/'host1/compile/process.json'),
                          scope='Five host metadata contracts; no native retirement or physical byte release simulated.'),
        host=dict(process=read(W/'host/run1/process.json'), passed_cases=host_cases, scope='20 existing standalone host cases, including 3 new WorkingState owner/lease contracts.'),
        CPU_E4=dict(process=read(W/'cpu/run1/process.json'), result=read(W/'cpu/run1/stdout.log'),
                    scope='Generated ordinary AA/H64/D64 calibrated E4 finite fixture; not trained-model quality.'),
        CUDA_E4=dict(comparisons={case: read(W/'e4-cli'/(case+'.comparison.json')) for case in ('natural','teacher')},
                    scope='Two current generated E4 CLI schedules against previously observed 58d70b723 controls; exact non-time facts, no speed claim.'),
        original_Qwen35_2B=dict(processes=read(C/'process-summary.json'), comparisons=model,
            tracehashes=pin(C/'tracehashes.json'), paired_trace_counts={p['mode']:len(p['inventory']) for p in traces['pairs']},
            existing_recompute_fact=model['important_existing_fact'],
            scope='Cached original BF16 V2 335-role Qwen3.5-2B ordinary/K1, 2 sessions x 3 turns and 18 outputs. Same baseline/candidate finite token/state/resource/path facts; not quality or performance generalization.'),
        syntax_only=syntax,
        source_review={name:dict(status=read(W/name)['status'],receipt=pin(W/name)) for name in
            ('design-review.json','diagnostics-migration.json','provider-boundary-review.json')},
        retained_failures=[dict(scope='Version-room host1 constant fault-callback C4702 /WX failure',receipt=pin(V/'host1/compile/process.json')),
            dict(scope='Ordinary first V1 prepared input early rejection PID38028',receipt=pin(C/'runs/ordinary-baseline/process.json')),
            dict(scope='Canonical random MTP diagnostic C4456 local shadow; corrected name only',receipt=pin(W/'syntax1/qwen_random_mtp_probe/process.json'))],
        not_implemented=['Native indexed GDN path', 'Eliminating existing KV reframe/export work', 'Execution overlap', 'Planned offload mechanism'],
        limits=['No demonstrated speedup, benchmark result or broader model-quality conclusion.',
                'Six canonical probes have syntax-only receipts (first four syntax1 plus final two syntax2); no objects, links or runtime for these probes. Other migrated diagnostic sources have source-review scope only.',
                'diagnostics-migration original random-probe pin predates the 3-line local rename; syntax2 records the current source hash and explicit delta.',
                'Archive contains only explicit small sources/commands/logs/metadata/schedule/token files. No executables, objects, PDBs, SDK/dependency trees, model weights, original BF16/F32 traces or trace directory walks.'])
    return files, summary


def main():
    assert sys.argv[1:] in (['plan'], ['publish'])
    files, summary = collect()
    manifest = [pin(p)|{'entry':name} for name,p in files.items()]
    estimate = sum(len(zlib.compress(p.read_bytes(),9))+len(name.encode())*2+100 for name,p in files.items())+20000
    plan = dict(files=len(files), raw_bytes=sum(p.stat().st_size for p in files.values()), estimated_zip_bytes=estimate,
                manifest=manifest, excludes=summary['limits'][-1])
    if sys.argv[1:] == ['plan']:
        (W/'publication-plan.json').write_bytes(encode(plan))
        print(json.dumps({k:plan[k] for k in ('files','raw_bytes','estimated_zip_bytes')})); return
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    DEST.parent.mkdir(parents=True,exist_ok=True)
    patch=subprocess.run(['git','diff',BASELINE,'--',*SOURCES],cwd=R,check=True,capture_output=True).stdout
    with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,p in files.items(): archive.write(p,name)
        archive.writestr('manifest.json',encode(manifest)); archive.writestr('changed-sources.txt',patch)
    summary['archive']=pin(DEST.with_suffix('.zip'))
    with DEST.with_suffix('.json').open('xb') as out: out.write(encode(summary))
    print(json.dumps(dict(summary=pin(DEST.with_suffix('.json')),archive=summary['archive'],files=len(files))))


if __name__ == '__main__': main()
