"""Explicit cached builds after root source freeze. Never runs a consumer.

python -B build.py plan
python -B build.py build cuda|cpu|host
One TU per target. Existing baseline objects being replaced need not exist.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-common-core-20261026'
P = R/'.scratch/inference-review-fixes-20261026'
H = R/'.scratch/inference-prefix-directory-20261024/host'
BASELINE_COMMIT = '58d70b723'
spec = importlib.util.spec_from_file_location('retained_review_recipe', P/'build-before-final.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def compile_command(recipe, source, folder):
    old = b.read(recipe)['command']
    old_source = next(x for x in old if x.lower().endswith(('.cc', '.cpp', '.cxx')))
    dep = old[old.index('/sourceDependencies')+1]
    result = [str(source) if x == old_source else str(folder/'dependencies.json') if x == dep
              else '/Fo'+str(folder/'unit.obj') if x.lower().startswith('/fo')
              else '/Fd'+str(folder/'unit.pdb') if x.lower().startswith('/fd') else x for x in old]
    assert all(x in result for x in ['/c', '/O2', '/MD', '/W4', '/WX'])
    for x in result:
        if x.startswith('/I'): assert str(R/'.scratch').casefold() not in x.casefold(), x
    return result


def comment_only_header():
    name = 'include/hyle/compute/providers/cuda.h'
    old = subprocess.run(['git', 'show', BASELINE_COMMIT+':'+name], cwd=R, check=True, capture_output=True).stdout
    current = (R/name).read_bytes()
    code = lambda data: '\n'.join(line for line in data.decode('utf-8-sig').splitlines()
                                  if not line.lstrip().startswith('//'))
    assert code(old) == code(current), 'Only the declared line-comment delta may bypass retained library recompilation'
    return dict(status='LINE_COMMENT_ONLY_NO_CPP_CODE_OR_ABI_CHANGE', path=name,
        baseline_revision=BASELINE_COMMIT, baseline_sha256=hashlib.sha256(old).hexdigest(),
        current=b.pin(R/name), proof='Every line except // comment lines is identical; no provider/SDK TU rebuild for this comment edit.')


def plan():
    assert not (W/'source-freeze.json').exists(), 'Preserve each source-frozen attempt'
    ready_cuda = b.read(B/'ready.json')
    ready_cpu = b.read(P/'probe3-ready.json')
    b.exact(ready_cuda['image'])
    report_dependencies = P/'product2/report/actual-dependencies.json'
    report_rows = [x for x in b.read(report_dependencies) if Path(x['path']).is_relative_to(R)
                   and not Path(x['path']).is_relative_to(R/'.scratch')]
    for row in report_rows: b.exact(row)
    observation = next(x for x in report_rows if b.key(x['path']).endswith('engine\\inference\\execution_observation.h'))
    b.save(W/'reused-report-abi.json', dict(report=ready_cpu['current_report'],
        report_dependency_record=b.pin(report_dependencies), canonical_dependencies_matched=len(report_rows),
        execution_observation=observation, note='WorkingState is engine-private; report TU/StepObservation ABI unchanged.'))
    b.save(W/'comment-only-header.json', comment_only_header())
    model = R/'engine/models/qwen35/main.cc'
    e4 = P/'e4-consumer.cc'  # Existing private wrapper; canonical implementation/test headers.
    host = R/'tests/tools/qwen_prefix_cache_test.cc'
    frozen = b.quoted_project_closure([model, R/'tests/tools/qwen_e4_cache_case.h', host])
    b.save(W/'source-freeze.json', frozen)
    recipes = {
        'cuda': dict(source=model, recipe=B/'compile/command.json', link=B/'link/command.json',
            inputs=b.read(ready_cuda['link_inputs']['path']), old=ready_cuda['object'], image='hyle.exe',
            baseline_ready=B/'ready.json', baseline_image=ready_cuda['image'], runtime=ready_cuda['runtime']),
        'cpu': dict(source=e4, recipe=P/'probe3/compile/command.json', link=P/'probe3/link/command.json',
            inputs=b.read(ready_cpu['link_inputs']['path']),
            old=next(x for x in b.read(ready_cpu['link_inputs']['path']) if b.key(x['path']).endswith('probe3\\compile\\unit.obj')),
            image='e4-consumer.exe', baseline_ready=P/'probe3-ready.json', baseline_image=ready_cpu['image'], runtime=ready_cpu['runtime']),
        'host': dict(source=host, recipe=H/'compile/command.json', link=H/'link/command.json', image='prefix-cache-test.exe')}
    checked = set()
    for name, unit in recipes.items():
        old_link = b.read(unit['link'])['command']
        if name == 'host':
            old_path = next(x for x in old_link if x.lower().endswith('prefix.obj'))
            unit['old'] = dict(path=old_path)
            unit['inputs'] = [dict(path=x) if b.key(x) == b.key(old_path) else b.pin(x) for x in old_link
                if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
        for row in unit['inputs']:
            if b.key(row['path']) != b.key(unit['old']['path']) and b.key(row['path']) not in checked:
                b.exact(row); checked.add(b.key(row['path']))
        folder = W/name
        b.save(folder/'link-inputs-before.json', unit['inputs'])
        b.save(folder/'plan.json', dict(status='SOURCE_FROZEN_NOT_BUILT_OR_RUN', target=name,
            source=b.pin(unit['source']), recipe=b.pin(unit['recipe']), link_recipe=b.pin(unit['link']),
            command=compile_command(unit['recipe'], unit['source'], folder/'compile'),
            image_path=str(folder/'link'/unit['image']), replaced_object=unit['old'],
            inputs=b.pin(folder/'link-inputs-before.json'), source_freeze=b.pin(W/'source-freeze.json'),
            reused_report_abi=b.pin(W/'reused-report-abi.json'), comment_only_header=b.pin(W/'comment-only-header.json'),
            baseline_ready=b.pin(unit['baseline_ready']) if 'baseline_ready' in unit else None,
            baseline_image=unit.get('baseline_image'), runtime=unit.get('runtime'),
            unchanged_inputs=len(unit['inputs'])-1,
            scope='One canonical Model TU' if name == 'cuda' else 'One existing private E4 wrapper TU' if name == 'cpu'
                  else 'One existing standalone qwen_prefix_cache_test TU with cached compute_batch libraries'))
    print('WORKING_STATE_PLANS_FROZEN', len(frozen), 'project source files', flush=True)


def build(name):
    folder = W/name
    assert not (folder/'compile').exists() and not (folder/'ready.json').exists()
    unit = b.read(folder/'plan.json')
    for field in ('source', 'recipe', 'link_recipe', 'inputs', 'source_freeze', 'reused_report_abi', 'comment_only_header'):
        b.exact(unit[field])
    frozen = b.read(unit['source_freeze']['path'])
    for row in frozen: b.exact(row)
    report = b.read(unit['reused_report_abi']['path'])
    b.exact(report['report'])
    for row in b.read(report['report_dependency_record']['path']):
        p = Path(row['path'])
        if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch'): b.exact(row)
    inputs = b.read(unit['inputs']['path'])
    for row in inputs:
        if b.key(row['path']) != b.key(unit['replaced_object']['path']): b.exact(row)
    h = b.helper()
    compiler = unit['command'][0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(unit['command'], env, folder/'compile', timeout=120)
    dep = b.read(folder/'compile/dependencies.json')['Data']
    actual = [b.pin(x) for x in dict.fromkeys([dep['Source'], *dep['Includes']])]
    frozen_by_key = {b.key(x['path']): x for x in [*frozen, unit['source']]}
    for row in actual:
        p = Path(row['path'])
        if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch') or b.key(p) == b.key(unit['source']['path']):
            assert b.key(p) in frozen_by_key and row['sha256'] == frozen_by_key[b.key(p)]['sha256'], str(p)
    for row in frozen: b.exact(row)
    b.save(folder/'actual-dependencies.json', actual)
    obj = b.pin(folder/'compile/unit.obj')
    command = []
    replaced = 0
    for arg in b.read(unit['link_recipe']['path'])['command']:
        if b.key(arg) == b.key(unit['replaced_object']['path']): arg = obj['path']; replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+unit['image_path']
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(folder/'link/consumer.pdb')
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(folder/'link/consumer.lib')
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    assert replaced == 1
    linked = h.execute(command, env, folder/'link', timeout=120)
    final = [obj if b.key(x['path']) == b.key(unit['replaced_object']['path']) else x for x in inputs]
    for row in final: b.exact(row)
    b.save(folder/'link-inputs.json', final)
    runtime = b.read(unit['runtime']['path']) if unit['runtime'] else dict(PATH=env['PATH'], configured_flags={}, scope='Standalone host storage test; no native route')
    if unit['runtime']:
        b.exact(unit['runtime']); b.exact(runtime['native'])
        alias = folder/'link'/Path(runtime['native']['path']).name
        os.link(runtime['native']['path'], alias); runtime['native_hardlink'] = b.pin(alias)
    b.save(folder/'runtime.json', runtime)
    b.save(folder/'ready.json', dict(status='WORKING_STATE_'+name.upper()+'_BUILT_NOT_RUN',
        image=b.pin(unit['image_path']), runtime=b.pin(folder/'runtime.json'), link_inputs=b.pin(folder/'link-inputs.json'),
        source=unit['source'], source_freeze=unit['source_freeze'], actual_dependencies=b.pin(folder/'actual-dependencies.json'),
        plan=b.pin(folder/'plan.json'), baseline=unit['baseline_image'], object=obj, compile=compiled, link=linked,
        compiled_TUs=1, unchanged_inputs=len(final)-1, SDK_native_provider_report_builds=0, model_runs=0, consumer_runs=0,
        limits=['Build/link only; no Model, fixture, host consumer or numerical/performance run.',
                'Engine-private state migration against retained closure; public CUDA header differs only in line comments.']))
    print('WORKING_STATE_READY', json.dumps(b.pin(folder/'ready.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif len(sys.argv) == 3 and sys.argv[1] == 'build' and sys.argv[2] in ('cuda', 'cpu', 'host'): build(sys.argv[2])
    else: raise SystemExit('Root after source freeze: python -B '+str(__file__)+' plan | build cuda|cpu|host')
