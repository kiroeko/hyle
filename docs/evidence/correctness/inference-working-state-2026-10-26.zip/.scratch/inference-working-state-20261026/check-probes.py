"""Exactly six canonical API consumers, MSVC /Zs only; no object/link/run."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained_host_runner', R/'.scratch/inference-synchronous-step-report-20261025/check_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
SOURCES = ('engine/models/qwen35/batch_probe.cc', 'engine/models/qwen35/retirement_probe.cc',
    'engine/models/qwen35/retained_budget_probe.cc', 'engine/models/qwen35/mtp_session_probe.cc',
    'tests/tools/qwen_random_mtp_probe.cc', 'tests/tools/qwen_mtp_prefix_value_probe.cc')


def main():
    remaining = sys.argv[1:] == ['remaining']
    assert not sys.argv[1:] or remaining
    sources = SOURCES[4:] if remaining else SOURCES
    out = W/('syntax2' if remaining else 'syntax1')
    assert not out.exists()
    recipe = json.loads((W/'cuda/compile/command.json').read_text(encoding='utf-8-sig'))['command']
    flags, skip = [], False
    for arg in recipe[1:]:
        if skip: skip = False; continue
        if arg == '/sourceDependencies': skip = True; continue
        if arg in ('/c', '/O2', '/Ob2', '/Oi', '/GL', '/Gy', '/Gw', '/GF'): continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp', '.cxx')): continue
        flags.append(arg)
    assert '/W4' in flags and '/WX' in flags
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': recipe[0],
        'CMAKE_CXX_COMPILER': recipe[0], 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    pins = [h.pin(R/name) for name in sources]
    frozen = json.loads((W/'source-freeze.json').read_text(encoding='utf-8-sig'))
    for row in frozen:
        assert h.pin(Path(row['path'])) == row
    rows = []
    for source in pins:
        folder = out/Path(source['path']).stem
        command = [recipe[0], *flags, '/Zs', source['path']]
        try:
            process = h.execute(command, env, folder, timeout=120)
        except RuntimeError:
            process = json.loads((folder/'process.json').read_text())
            rows.append(dict(source=source, process=process, command=h.pin(folder/'command.json')))
            h.save(out/'summary.json', dict(status='CANONICAL_PROBE_SYNTAX_FAILURE', checked=rows,
                intended_sources=list(sources), objects=0, links=0, consumers=0))
            raise
        rows.append(dict(source=source, process=process, command=h.pin(folder/'command.json')))
    for row in pins+frozen:
        assert h.pin(Path(row['path'])) == row
    delta = None
    if remaining:
        migration = json.loads((W/'diagnostics-migration.json').read_text(encoding='utf-8-sig'))
        original = next(x for x in migration['files'] if x['path'] == 'tests/tools/qwen_random_mtp_probe.cc')
        delta = dict(original_diagnostics_migration_pin=original, current=pins[0],
            reason='Root renamed three inner diagnostic pending uses to waiting_retirement for pre-existing C4456; API/math/owner semantics unchanged. Original migration receipt and syntax1 failed pin are retained.')
    h.save(out/'summary.json', dict(status='REMAINING_TWO_CANONICAL_PROBES_SYNTAX_PASS' if remaining else 'SIX_CANONICAL_PROBES_SYNTAX_PASS', checked=rows,
        recipe=h.pin(W/'cuda/compile/command.json'), scope='MSVC syntax-only current canonical private API consumers; same CUDA Model macros/includes and W4/WX, codegen/output/dependency flags removed.',
        diagnostics_source_delta=delta, objects=0, links=0, consumers=0, limits=['Not linked or run; no native correctness, resource retirement or model output proof.']))
    print('CANONICAL_PROBE_SYNTAX_READY', json.dumps(h.pin(out/'summary.json')), flush=True)


if __name__ == '__main__': main()
