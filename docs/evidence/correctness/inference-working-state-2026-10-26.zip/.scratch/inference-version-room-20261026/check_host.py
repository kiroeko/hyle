"""One finite version-room host TU; no model, SDK, native route or network."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
helper_path = R/'.scratch/inference-synchronous-step-report-20261025/check_host.py'
spec = importlib.util.spec_from_file_location('retained_host_runner', helper_path)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
out = W/(sys.argv[1] if len(sys.argv)>1 else 'host1')
assert not out.exists()
source = R/'tests/tools/inference_version_room_test.cc'
header = R/'engine/inference/version_admission.h'
before = [h.pin(p) for p in [source, header]]
recipe = json.loads((R/'.scratch/inference-current-closure-20261026/engine/report/command.json').read_text())
compiler = recipe['command'][0]
env = h.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
stage = out/'compile'
command = [compiler, '/nologo', '/std:c++latest', '/EHsc', '/Zc:__cplusplus', '/Zc:preprocessor',
    '/utf-8', '/O2', '/Ob2', '/MD', '/permissive-', '/W4', '/WX', '/DNOMINMAX',
    '/I'+str(R/'include'), '/I'+str(R), '/c', str(source),
    '/sourceDependencies', str(stage/'dependencies.json'),
    '/Fo'+str(stage/'unit.obj'), '/Fd'+str(stage/'unit.pdb')]
compiled = h.execute(command, env, stage)
dep = json.loads((stage/'dependencies.json').read_text(encoding='utf-8-sig'))['Data']
actual = [h.pin(Path(p)) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]
h.save(out/'actual-dependencies.json', actual)
assert [h.pin(Path(x['path'])) for x in before] == before
assert not any('cuda' in x['path'].casefold() or 'ggml' in x['path'].casefold() for x in actual)
image = out/'link/inference_version_room_test.exe'
linked = h.execute([str(Path(compiler).with_name('link.exe')), '/NOLOGO', '/INCREMENTAL:NO',
    '/OPT:REF', '/OPT:ICF', str(stage/'unit.obj'), '/OUT:'+str(image), '/PDB:'+str(out/'link/test.pdb')],
    env, out/'link')
ran = h.execute([str(image)], env, out/'run', timeout=30)
assert (out/'run/stdout.log').read_text().strip() == 'inference_version_room: PASS (5 host contracts)'
h.save(out/'summary.json', dict(status='FINITE_VERSION_ROOM_HOST_PASS', source_pins=before,
    actual_dependencies=h.pin(out/'actual-dependencies.json'), compile=compiled, link=linked, run=ran,
    image=h.pin(image), compiled_TUs=1, Model_GPU_SDK_builds=0, model_runs=0,
    limits=['Finite host metadata check only; no native retirement or physical byte release is simulated.',
            'Actual version_admission alias/retainer queries verify rereads. Valid traversal counts C++ new calls; no added allocator or persistent inventory.']))
print('VERSION_ROOM_HOST_READY', json.dumps(h.pin(out/'summary.json')), flush=True)
