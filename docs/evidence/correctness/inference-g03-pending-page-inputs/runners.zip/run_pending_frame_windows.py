from pathlib import Path
import json,os,subprocess,time
root=Path.cwd();out=root/'.scratch/inference-gaps/g03/pending-frame-windows';out.mkdir(exist_ok=True)
parent=Path('C:/h7/inference-g01-native-vulkan/parent');build=parent.parent/'build';p=parent/'CMakeLists.txt';s=p.read_text()
line='target_sources(g03_paged_arena_risks PRIVATE C:/public/project-hyle/hyle/tests/compute_batch/paged_arena_pending_test.cc)\n'
if line not in s:p.write_text(s+'\n'+line)
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
rows=json.loads((out/'result.json').read_text())['stages'] if (out/'result.json').exists() else []
for stage,args in [('build',['cmake','--build',str(build),'--target','g03_paged_arena_risks','g03_dirty_page_public','--parallel','4']),('arena',[str(build/'g03_paged_arena_risks.exe')]),('public',[str(build/'g03_dirty_page_public.exe')])]:
 attempt=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT);print(stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
 if code:print(log.read_text(errors='replace')[-8000:]);raise SystemExit(code)
