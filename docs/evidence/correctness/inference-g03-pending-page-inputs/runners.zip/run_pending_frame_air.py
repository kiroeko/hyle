from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();out=root/'.scratch/inference-gaps/g03/pending-frame-air';out.mkdir(exist_ok=True)
names=subprocess.check_output(['git','diff','--name-only','503a98344'],text=True).splitlines();names+=['tests/compute_batch/paged_arena_pending_test.cc','tests/compute_batch/paged_arena_pending_native_probe.cc'];names=sorted(set(n for n in names if n.startswith(('src/','include/','tests/'))))
attempt=1
while (out/f'input-{attempt}.zip').exists():attempt+=1
archive=out/f'input-{attempt}.zip';inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name in names:
  data=(root/name).read_bytes();inputs.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()));z.writestr(name,data)
 z.writestr('input-manifest.json',json.dumps(inputs,indent=2)+'\n')
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-pending-frame';options=['-o','BatchMode=yes','-o','ConnectTimeout=12']
subprocess.run(['ssh',*options,host,'mkdir -p '+remote],check=True)
subprocess.run(['scp',*options,str(archive),str(root/'.scratch/inference-gaps/g03/pending_frame_air.py'),host+':'+remote+'/'],check=True)
code=subprocess.run(['ssh',*options,host,f'python3 {remote}/pending_frame_air.py {archive.name}']).returncode
subprocess.run(['scp',*options,host+':'+remote+'/result.json',str(out)],check=True)
raise SystemExit(code)
