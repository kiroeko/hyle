from pathlib import Path
import hashlib,json,os,subprocess,time
canonical=Path('/mnt/c/public/project-hyle/hyle');base=Path('/root/hyle-scratch/compute-unified');source=base/'source-7a7b4c3b';parent=base/'l-cpu-cuda/selected-graph/source-parent';build=parent.parent/'source-build';out=canonical/'.scratch/inference-gaps/g03/pending-frame-cuda';out.mkdir(exist_ok=True)
names=json.loads((out/'canonical-input-names.json').read_text())
inputs=[]
for name in names:
 data=(canonical/name).read_bytes();dest=source/name
 if not dest.exists() or dest.read_bytes()!=data:dest.write_bytes(data)
 inputs.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()))
p=parent/'CMakeLists.txt';body=p.read_text();target='g03_pending_frame_cuda'
if f'add_executable({target} ' not in body:
 body+=f'\nadd_executable({target} "{source}/tests/compute_batch/paged_arena_pending_cuda_probe.cc")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE hyle_compute_batch hyle_compute_backend_cuda)\nhyle_stage_runtime({target})\n';p.write_text(body)
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib:'+env.get('LD_LIBRARY_PATH','')
identity=dict(uname=subprocess.check_output(['uname','-a'],text=True).strip(),gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,memory.used,utilization.gpu','--format=csv,noheader'],text=True).strip())
rows=json.loads((out/'result.json').read_text())['stages'] if (out/'result.json').exists() else []
def run(stage,args):
 attempt=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT);print(stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(identity=identity,inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
 if code:print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
run('configure',['cmake','-S',str(parent),'-B',str(build)])
dry=subprocess.check_output(['ninja','-C',str(build),'-n',target],env=env,text=True);(out/'dry-run.txt').write_text(dry);assert '.cu.o' not in dry and 'nvcc' not in dry,'reject unplanned CUDA kernel build'
run('build',['cmake','--build',str(build),'--target',target,'--parallel','4']);run('actual-256-byte',[str(build/target)])
