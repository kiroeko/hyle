from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';out=base/'g03-pending-frame';out.mkdir(exist_ok=True)
identity={k:subprocess.check_output(a,text=True).strip() for k,a in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['clang++','--version'])]};assert identity['model']=='Mac16,12'
with zipfile.ZipFile(out/sys.argv[1]) as z:
 inputs=json.loads(z.read('input-manifest.json'))
 for r in inputs:
  assert r['path'].startswith(('src/','include/','tests/')) and '..' not in Path(r['path']).parts
  data=z.read(r['path']);assert hashlib.sha256(data).hexdigest()==r['sha256'];destination=source/r['path']
  if not destination.exists() or destination.read_bytes()!=data:destination.write_bytes(data)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
rows=json.loads((out/'result.json').read_text())['stages'] if (out/'result.json').exists() else []
def run(route,mode,stage,args):
 attempt=1+sum(r['route']==route and r['mode']==mode and r['stage']==stage for r in rows);log=out/f'{route}-{mode}-{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as f:
  p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT);print('RUN',route,mode,stage,p.pid,flush=True);code=p.wait()
 rows.append(dict(route=route,mode=mode,stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,log=str(log)))
 (out/'result.json').write_text(json.dumps(dict(identity=identity,inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
 if code:print(log.read_text(errors='replace')[-7000:],flush=True);raise SystemExit(code)
cmake='/opt/homebrew/bin/cmake'
gtest='/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6'
for route in ([] if '--san-only' in sys.argv else ['apple','vulkan']):
 producer=base/f'a-cpu-{route}/selected-graph/static-sdk-build';folder=out/f'{route}-source';folder.mkdir(exist_ok=True);prefix=folder/'prefix'
 run(route,'source','producer-build',[cmake,'--build',str(producer),'--target','hyle_compute','hyle_compute_batch',f'hyle_compute_route_{route}','--parallel','4'])
 run(route,'source','install',[cmake,'--install',str(producer),'--prefix',str(prefix)])
 parent=folder/'parent';parent.mkdir(exist_ok=True);body=f'''cmake_minimum_required(VERSION 3.25)
project(pending_native_source LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(native "{source}/tests/compute_batch/paged_arena_pending_native_probe.cc")
target_compile_features(native PRIVATE cxx_std_23)
target_compile_options(native PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_link_libraries(native PRIVATE hyle::compute)
hyle_stage_runtime(native)
'''
 if route=='apple':body+='target_compile_definitions(native PRIVATE HYLE_G01_PAGE_RISK_APPLE=1)\n'
 (parent/'CMakeLists.txt').write_text(body);build=folder/'build'
 run(route,'source','configure',[cmake,'-S',str(parent),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix)])
 run(route,'source','build',[cmake,'--build',str(build),'--target','native','--parallel','4']);run(route,'source','native',[str(build/'native')])
for route in ['apple','vulkan']:
 for mode in ['asan','ubsan','tsan']:
  folder=base/f'foundation-f5-native-host-{route}-{mode}';parent=folder/'parent';build=folder/'build';body=(parent/'CMakeLists.txt').read_text()
  targets=[('g03_pending_frame','tests/compute_batch/paged_arena_test.cc','hyle::compute GTest::gtest_main'),('g03_pending_native','tests/compute_batch/paged_arena_pending_native_probe.cc','hyle::compute'),('g03_pending_copy','tests/compute_backend_cpu/copy_program_test.cc','hyle::compute GTest::gtest_main')]
  for target,name,link in targets:
   if f'add_executable({target} ' not in body:
    body+=f'\nadd_executable({target} "{source/name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE {link})\nhyle_apply_sanitizer({target})\nhyle_stage_runtime({target})\n'
    if target=='g03_pending_frame':body+=f'target_sources({target} PRIVATE "{source}/tests/compute_batch/paged_arena_pending_test.cc")\n'
    if target=='g03_pending_native' and route=='apple':body+=f'target_compile_definitions({target} PRIVATE HYLE_G01_PAGE_RISK_APPLE=1)\n'
    if mode=='tsan':
     body+=f'target_include_directories({target} BEFORE PRIVATE "{base}/g02-refcount-fence-probe/tsan-headers")\n'
     if route=='apple':body+=f'target_include_directories({target} BEFORE PRIVATE "{base}/g01-metal-callback-tsan-probe/tsan-metal-cpp")\n'
  (parent/'CMakeLists.txt').write_text(body);run(route,mode,'configure',[cmake,'-S',str(parent),'-B',str(build)])
  run(route,mode,'build',[cmake,'--build',str(build),'--target',*[t for t,_,_ in targets],'--parallel','4'])
  commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True));flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode]
  checked=[r for r in commands if r['file'].endswith(('src/compute/batch_transfer.cc','src/compute_batch/paged_arena.cc',f'src/compute_route_{route}/{route}_copy_program.cc','tests/compute_batch/paged_arena_pending_test.cc','tests/compute_batch/paged_arena_pending_native_probe.cc'))]
  assert len(checked)==5 and all(flag in r['command'] for r in checked);(out/f'{route}-{mode}-instrumentation.json').write_text(json.dumps(checked,indent=2)+'\n')
  for target,_,_ in targets:run(route,mode,target,[str(build/target)])
for mode in ['static','shared']:
 producer=base/f'a-cpu-vulkan/selected-graph/{mode}-sdk-build';folder=out/mode;folder.mkdir(exist_ok=True);stage=folder/'staging';prefix=folder/'relocated'
 if not prefix.exists():
  run('vulkan',mode,'producer-build',[cmake,'--build',str(producer),'--target','hyle_compute','hyle_compute_batch','hyle_compute_route_vulkan','--parallel','4'])
  run('vulkan',mode,'install',[cmake,'--install',str(producer),'--prefix',str(stage)]);stage.rename(prefix)
 assert not stage.exists();consumer=folder/'consumer';consumer.mkdir(exist_ok=True)
 for name in ['paged_arena_test.cc','paged_arena_pending_test.cc','allocation_fault_fixture.h']:(consumer/name).write_bytes((source/'tests/compute_batch'/name).read_bytes())
 headers=['paged_arena.h','detail/paged_arena_access.h','detail/copy_stream_access.h']
 for i,name in enumerate(headers):
  assert (prefix/'include/hyle/compute'/name).read_bytes()==(source/'include/hyle/compute'/name).read_bytes();(consumer/f'header-{i}.cc').write_text(f'#include <hyle/compute/{name}>\n')
 (consumer/'CMakeLists.txt').write_text(f'''cmake_minimum_required(VERSION 3.25)
project(pending_frame_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory({gtest} gtest EXCLUDE_FROM_ALL)
add_executable(arena paged_arena_test.cc paged_arena_pending_test.cc)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc)
foreach(t arena headers)
 target_compile_features(${{t}} PRIVATE cxx_std_23)
 target_compile_options(${{t}} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${{t}} PRIVATE hyle::compute)
endforeach()
target_link_libraries(arena PRIVATE GTest::gtest_main)
hyle_stage_runtime(arena)
''')
 build=folder/'build';run('vulkan',mode,'configure',[cmake,'-S',str(consumer),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
 run('vulkan',mode,'consumer-build',[cmake,'--build',str(build),'--target','arena','headers','--parallel','4'])
 commands=json.loads((build/'compile_commands.json').read_text());owned=[r for r in commands if str(consumer) in r['file']];assert len(owned)==5 and all(str(source) not in r['command'] and str(prefix/'include') in r['command'] for r in owned)
 (out/f'{mode}-compile-commands.json').write_text(json.dumps(owned,indent=2)+'\n');run('vulkan',mode,'arena',[str(build/'arena')])
