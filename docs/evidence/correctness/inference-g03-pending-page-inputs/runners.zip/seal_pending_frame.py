from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
root=Path.cwd();task=root/'.scratch/inference-gaps/g03';out=root/'evidence/correctness/inference-g03-pending-page-inputs';out.mkdir(exist_ok=True)
shutil.copyfile(task/'pending-frame-air/raw.zip',out/'air-raw.zip')
with zipfile.ZipFile(out/'air-raw.zip') as z:
 air=json.loads(z.read('result.json'))
 for name in ['result.json','artifact-receipts.json','static-compile-commands.json','shared-compile-commands.json']:(out/('air-'+name)).write_bytes(z.read(name))
 for row in air['inputs']:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
 for route in ['apple','vulkan']:
  for mode in ['source','asan','ubsan','tsan']:
   stages=[r for r in air['stages'] if r['route']==route and r['mode']==mode]
   latest={r['stage']:r for r in stages};assert latest and all(r['exit_code']==0 for r in latest.values()),(route,mode)
 for mode in ['static','shared']:
  latest={r['stage']:r for r in air['stages'] if r['mode']==mode};assert latest and all(r['exit_code']==0 for r in latest.values())
 windows=json.loads((task/'pending-frame-windows/result.json').read_bytes());cuda=json.loads((task/'pending-frame-cuda/result.json').read_bytes())
for label,data,folder in [('windows',windows,'pending-frame-windows'),('cuda',cuda,'pending-frame-cuda')]:
 latest={r['stage']:r for r in data['stages']};assert all(r['exit_code']==0 for r in latest.values())
 shutil.copyfile(task/folder/'result.json',out/(label+'-result.json'))
 with zipfile.ZipFile(out/(label+'-raw.zip'),'w',zipfile.ZIP_DEFLATED) as z:
  for p in (task/folder).iterdir():
   if p.is_file():z.write(p,p.name)
 for row in data.get('inputs',[]):assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
assert 'nvcc' not in (task/'pending-frame-cuda/build-1.log').read_text().lower()
names=subprocess.check_output(['git','diff','--name-only','503a98344'],text=True).splitlines()
names+=['tests/compute_batch/paged_arena_pending_test.cc','tests/compute_batch/paged_arena_pending_native_probe.cc','tests/compute_batch/paged_arena_pending_cuda_probe.cc']
names=sorted(set(n for n in names if n.startswith(('include/','src/','tests/'))))
(out/'product-inputs.json').write_text(json.dumps(dict(baseline='503a98344',inputs=[dict(path=n,sha256=hashlib.sha256((root/n).read_bytes()).hexdigest()) for n in names]),indent=2)+'\n',newline='\n')
failures=dict(windows=[r for r in windows['stages'] if r['exit_code']],air=[r for r in air['stages'] if r['exit_code']],preparation=[dict(platform='WSL',kind='Wrong-environment canonical Git scan',observed_seconds_approximately=200,pids=[557,650],result='Only preparer Python terminated after process diagnosis; child Git already gone. No build or CUDA execution had started.',cause='Linux Git scanned Windows NTFS worktree and CRLF evidence while collecting input list',correction='Canonical Windows Git precomputes bounded input names; final configure/build/CUDA PASS')],diagnostics=['Windows test fixture first omitted the 1-byte sentinel; corrected 32769-byte backing','Windows discovered original take_mutable returned a writer while ordered readers retained the block; common/Apple/Vulkan now check original F1 unique view before moving it','Windows attempt3 repeated the same product failure because multi-file patch verification failed and common fix was absent; all attempts retained','Air fixture selected Vulkan-only MemoryKind in Apple branch; corrected original Apple create call','Air ASan diagnosed borrowed-resource teardown before original worker cleanup; explicit fixture Context.close before resource destruction fixes it','Air original worker host/native wait counters could advance autonomously during comparison; existing MLX checkpoint gates the observer-cost measurement','LLDB noninteractive SSH permission prevented debugging; ASan supplied the teardown diagnosis'],prior='All original G01-G03 failures, unknowns, elapsed and budgets remain in prior evidence; no reset')
(out/'retained-failures.json').write_text(json.dumps(failures,indent=2)+'\n',newline='\n')
summary=dict(scope='PF01-PF03 input qualification implementation checkpoint; main owners remain AUDITED',passed=['Windows20 page tests and original public64 steps','Apple/Vulkan actual original updates and ordered-reader qualification with contiguous512-byte coverage and gap rejection','Six host sanitizer configurations: page20, native2 episodes and original CPU copy8 each','Two relocated common static/shared SDK consumers:20 tests and3 headers each','Actual CUDA256-byte original producer/F2/download, CPU byte+sum oracle, original cold source and completion, final-only wait, guard and control recovery'],seconds=dict(windows=windows['cumulative_seconds'],air=air['cumulative_seconds'],cuda=cuda['cumulative_seconds']),limits=['Pending frame is a cold metadata owner; O((refs+inputs)log(refs+inputs)) construction, up to4 allocator calls; not whole-decode zero allocation','Source native proofs use private source headers; relocated SDK tests qualify common installed pending API only','Host sanitizer scope excludes shaders/drivers; original two exact TSan models retained and no LSan claim','CUDA original source tree retains existing HYLE_TESTING event observation hooks; tiny actual execution is not shipping SDK or P1 qualification; no nvcc/model build','Windows final20/public64 receipt predates only a contract-comment change in copy_stream_access.h; final behavior is unchanged, Air and CUDA manifests match final product bytes','Original attention/Graph receivers, late native output and full seven-route journey are not accepted by this checkpoint'],remaining='Actual native/Batch receiver and Graph source aggregation, late producer backing, seven routes64/two requests/two slots/independent reduction; original G01/G02 unresolved gates and G04-G10 unchanged')
(out/'validation-result.json').write_text(json.dumps(summary,indent=2)+'\n',newline='\n')
shutil.copyfile(task/'pending-frame-plan.json',out/'validation-plan.json')
with zipfile.ZipFile(out/'runners.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['run_pending_frame_windows.py','run_pending_frame_air.py','pending_frame_air.py','pending_frame_cuda.py','pack_pending_frame_air.py','seal_pending_frame.py']:z.write(task/name,name)
card=root/'docs/implementation/tasks/compute/inference-g03-pending-page-consumption.md'
s=card.read_text(encoding='utf-8')
s+='''
## PF01–PF03 已验证实施检查点（2026-10-14）

本批产品和三个专用测试已实现；[输入资格验证记录](../../../../evidence/correctness/inference-g03-pending-page-inputs/validation-result.json)
保留原日志、每次 FAIL/累计时间、最终 source hash、native artifact receipt、两原 TSan
模型与 SDK consumer 编译命令。四 owner 仍 AUDITED，未把整个 G03 转入 CANDIDATE/CLOSED。

Windows 20 项与原 public64；Air 两 actual native、六 host sanitizer（每组 page20、
native 两 episode、原 CPU copy8）；两 relocated static/shared 各 page20 与三 standalone
头；CUDA actual256-byte 原 gated producer/F2/download＋byte/sum oracle 均 PASS。
初始化洞、shared/non-tail、root/generation/extent、每冷分配 OOM、两原 copy slot/64步、
旧 guard 与原 controls 回收得到定向验证。Windows 最终 receipt 后只有 common detail
头合同注释变化；Air/CUDA final manifest 匹配产品字节，未伪造 Windows 新编译身份。

真实 withdrawal 反证已修于三个原 take_mutable：先用既有 F1 view 的唯一性和成功检查，
拒绝不移动 binding。冷 frame 最多四分配，payload 不复制；coverage/admission 不观察
producer、不新增队列。原 source native fixture 不算 installed native receiver 交付；
host sanitizer 不签 shader/driver，CUDA 沿原 source HYLE_TESTING 树且无 nvcc/kernel。
所有 fixture FAIL、原 worker teardown ASan、autonomous counter 误判和 WSL 输入扫描
中断均保留。没有重型 run 存活；不重复本批、IP、cold source 与原数学已证明门。

下一步继续本主卡的真实 native/Batch receiver、原 Graph completion 聚合与 late output；
在此固定下一有限 FIX/公开消费形状后实现。完整七路线64步/两请求/两slot/独立 reduction、
原 G01/G02 未决门与 G04–G10 均未代签。整体粗估18%–20%，完整 G 项仍0/10。
'''
card.write_text(s,encoding='utf-8',newline='\n')
p=root/'docs/implementation/module-status.json';d=json.loads(p.read_bytes())
for row in d['modules']:
 if row['module'] in ['compute','compute_batch','compute_route_apple','compute_route_vulkan']:
  assert row['state']=='AUDITED' and row['record'].endswith('inference-g03-pending-page-consumption.md')
  row['summary']='G03 PF01-PF03 implemented and verified checkpoint, still AUDITED: exact pending frames, original accepted coverage and F1 guard/withdrawal gate. Windows20/public64, Air actual two routes/six host sanitizer configurations/two relocated SDKs, actual CUDA256-byte PASS; failures and cumulative retained. Original native/Batch attention and Graph receiver integration, late output and whole seven-route acceptance remain required.'
p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode('utf-8'))
hp=root/'.scratch/inference-gaps/g01/handoff-current.json';h=json.loads(hp.read_bytes())
h['G03_pending_page_inputs']=dict(state='AUDITED_IMPLEMENTED_VERIFIED_CHECKPOINT',baseline='503a98344',evidence=str(out.relative_to(root)).replace('\\','/'),verified=summary['passed'],limits=summary['limits'],remaining=summary['remaining'],live_sessions=[],terminal_sessions=[64015,87229,61591,76644,8926,14616,93609],failures='All raw Windows/Air attempts retained; WSL input preparation interruption diagnosed before heavy work and documented; no budget reset')
h['next_resume']='Main four owners AUDITED. PF01-PF03 implemented+verified, archive and commit then freeze next exact native/Batch/Graph receiver FIX in original main card. No live jobs, no repeated PF/IP/source/math gates. Full all10 goal active, rough18-20%,0/10 complete.'
h['live_jobs']=[];hp.write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary['seconds']))
