from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('paged_cuda_build',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'grouped-fp8-power2-reference/cuda/checks/new-wrapper/attempt3/link-plan.json'
recipepath=basepath.parent/'compile-command.json';base=c.read(basepath);out=P/'cuda/checks'/sys.argv[1]
out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'link.result.json').exists()
source=R/'tests/graph_route_cuda/paged_e4_kv_test.cc';tag='paged-test'
command=b.host_command(c.read(recipepath)['command'],source,tag,out)
# Public compile definition of the newly linked, actually present provider target.
command.insert(1,'/DHYLE_COMPUTE_FLASHINFER=1')
c.save(out/'compile-plan.json',dict(command=command,recipe=b.identity(recipepath),source=b.identity(source)))
env,_=b.environment(command,[],out);c.execute(tag,command,env,out)
deps=c.read(out/(tag+'-deps.json'))['Data'];obj=b.identity(out/(tag+'.obj'))
c.save(out/'test-identity.json',dict(command=command,source=b.identity(source),object=obj,
 dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]))
assert all(b.same(x) for x in base['inputs'])
command=[x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command.insert(1,obj['path']);image=out/'cuda.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[obj,*base['inputs']]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),SDK_builds=0,NVCC=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));print(out/'link-plan.json')
