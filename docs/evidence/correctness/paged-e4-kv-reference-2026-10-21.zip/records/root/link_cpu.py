from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('paged_cpu_link',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=A/'grouped-fp8-power2-reference/cpu/checks/attempt1/link-plan.json';base=c.read(basepath)
summary=c.read(P/'cpu/checks/products/final-summary.json');replacements={}
for row in summary['identity_files']:
 assert b.same(row);rec=c.read(row['path']);assert b.same(rec['source']) and b.same(rec['object'])
 replacements[c.key(rec['replaces']['path'])]=rec['object']
latest=c.read(P/'cpu/checks/products/attempt3/ops/identity.json');assert b.same(latest['source']) and b.same(latest['object'])
replacements[c.key(latest['replaces']['path'])]=latest['object']
assert len(replacements)==3 and all(sum(c.key(r['path'])==k for r in base['inputs'])==1 for k in replacements)
testpath=P/'cpu/checks'/sys.argv[1]/'identity.json';test=c.read(testpath)['object'];assert b.same(test)
neighbor_path=P/'cpu/checks/native-paged-neighbor/attempt1/identity.json';neighbor=c.read(neighbor_path)['object'];assert b.same(neighbor)
out=P/'cpu/checks'/sys.argv[2];out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
command=[replacements.get(c.key(x),{}).get('path',x) for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command[1:1]=[test['path'],neighbor['path']];image=out/'cpu.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[test,neighbor,*[replacements.get(c.key(x['path']),x) for x in base['inputs']]];assert all(b.same(x) for x in inputs)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replaced=3,SDK_builds=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));print(out/'link-plan.json')
