from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
windows=[('cpu','cpu/validation/attempt1/receipt.json'),
 ('cpu','cpu/validation/attempt2/receipt.json'),('cuda','cuda/validation/final1/receipt.json'),
 ('vulkan','vulkan/validation/attempt3/receipt.json'),('vulkan','vulkan/validation/neighbor1/receipt.json')]
cases=set();records=[]
for arm,relative in windows:
 p=P/relative;d=read(p);assert d['passed'] and not d['failed'] and not d['skipped']
 xml=R/d['xml']['path'] if not Path(d['xml']['path']).is_absolute() else Path(d['xml']['path'])
 assert sha(xml)==d['xml']['sha256']
 actual=ET.parse(xml).findall('.//testcase');names=[x.get('classname')+'.'+x.get('name') for x in actual]
 assert names==d['names'] and all(x.find('failure') is None and x.find('skipped') is None for x in actual)
 cases.update((arm,n) for n in names);records.append(dict(backend=arm,receipt=identity(p),green_names=names))
apple_path=P/'apple/final-validation.json';apple=read(apple_path)
assert apple['tests']==6 and apple['failed']==0 and apple['skipped']==0
for key in ('new_gtest','neighbor_gtest'):
 row=apple[key];xml=Path(row['path']);assert sha(xml)==row['sha256']
 actual=ET.parse(xml).findall('.//testcase')
 assert actual and all(x.find('failure') is None and x.find('skipped') is None for x in actual)
 cases.update(('apple',x.get('classname')+'.'+x.get('name')) for x in actual)
new={x for x in cases if 'PagedE4Kv.' in x[1]};assert len(new)==16 and len(cases)==22
sources=set()
for row in read(P/'cpu/final-source-freeze.json')['sources']:
 path=Path(row['path']);sources.add(path.relative_to(R).as_posix())
 if path.name!='HyleDependencyLock.json':assert sha(path)==row['sha256']
for row in read(P/'vulkan/final-source-freeze.json')['files']:
 path=Path(row['source']);sources.add(path.relative_to(R).as_posix());assert sha(path)==row['after']['sha256']
af=read(P/'apple/source-freeze.json')
for key in ('owned','shared'):
 for row in af[key]:
  path=Path(row['path']);sources.add(path.relative_to(R).as_posix());assert sha(path)==row['sha256']
sources.update(['include/hyle/compute/low_precision.h','include/hyle/compute/batch_layout.h',
 'include/hyle/graph/batch.h','src/compute_ops/low_precision.cc','src/compute_batch/batch_layout.cc',
 'src/compute_provider_flashinfer/native_cache_encoder.cu','src/compute_provider_flashinfer/native_cache.cu',
 'tests/compute_models/paged_e4_kv_fixture.h','tests/compute_models/nvfp4_reference_fixture.h',
 'tests/compute_provider_ggml/native_paged_test.cc','tests/compute_batch/encoded_page_native_consumer.cc',
 'docs/implementation/model-quantizations.json'])
for arm in ('cpu','cuda','vulkan','apple'):
 sources.update(f'tests/graph_route_{arm}/{name}' for name in ('paged_e4_kv_test.cc','CMakeLists.txt'))
source_ids=[identity(R/s) for s in sorted(sources)]
entries={'source/'+s:R/s for s in sorted(sources)}
extensions={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cuh','.cpp','.c',
 '.metal','.cmake','.md','.b64','.inc','.glsl','.comp','.spv','.spvasm'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in extensions:
  relative=p.relative_to(P).as_posix()
  if relative in ('root/package-summary.json','root/cleanup-plan.json','root/cleanup-script-identity.json'):continue
  entries['records/'+relative]=p
for name in ('design.json','review-cpu-mla.json'):
 entries['research/'+name]=A/'paged-e4-kv-2026-10-21'/name
archive=R/'docs/evidence/correctness/paged-e4-kv-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='four_backend_bounded_ordinary_paged_E4_reference_passed',
 architecture='Original CacheEncode, CacheStorage, schema/page permissions and ordinary Graph cold native plans/Invocation/Completion; no new public format or executor. CPU boxed, Vulkan FullF32 and Apple Steel read addressed E4 bytes with fixed independent F32 K/V scale; no full-cache floating bank. Original CUDA factorized scales remain.',
 math='Finite F32/F16/BF16 source widened toF32, F32 division by fixed positive finite scale, SATFINITE E4M3FN nearest-even with signedzero. Reader: per-element decoded E4*scale, original F32 attention reductions and final BF16 output. CUDA key scale factors into softmax scale and value scale into output/merge. Exact encode byte tests; no arbitrary-scale bitwise cross-backend attention claim.',
 regression=dict(new_cases=16,neighbors=6,distinct_backend_scoped_cases=22,windows=records,apple=identity(apple_path),
  new_names=[dict(backend=arm,name=n) for arm,n in sorted(new)],neighbor_names=[dict(backend=arm,name=n) for arm,n in sorted(cases-new)],
  counting='Names are backend-scoped: Apple/Vulkan reuse the same two EncodedNativePages names. CPU encoder2 stayed on unchanged provider/math in its first window; final canonical mixed native reader and plain/Q8 neighbors were rerun in the second. AllCUDAnew4 have one final image window. Applenew4 and Q8two use identical product/native object identities.',
  executed_fixture='Each backend:6successful encoder variants+1bad producer+1fresh encoder recovery;4multi-request+5Q1warm/fresh successful attention submissions. 16success/1expected bad producer per backend follows executed passing source, not native dispatch instrumentation.'),
 geometry='BF16 Q/Y, QH4/KVH2,Dk64/Dv128,page16, original5physicalpages, repeated/nonmonotonic0/1/2 references; 1+3query rows/histories17,23->17,31; fixedQ1tail1->15. Inactive tail/pageNaNs, independentK0.5/V2 witnesses, causal window16, two independent slots plus freshQ1 comparison, oldGraphOutput and storage leases survive destruction.',
 product_fixes=['CPU privatePagedRead coldscalars and explicit rawI8E4tag; original bounded boxed row decoder/F32dot; original runtimeQ1 update family.',
  'MixedCPU manifest composer now uses exact(file,before,after) dedup and rejects conflicting anchors, without fixed24edit count. NewE4helper uses an unambiguous original boxed-helper context. Actual canonical generated mixed native source compiled fresh.',
  'Vulkan typed checked encoder reuses shared exact U32div/E4codec, supports real byte origins through crossword load. NewprivateE4 flash variant keeps original managedRegion warmupdate, rawbyte K/V and scale bits in full pipeline identity, no pushoverflow. E4 K/V layout limits use actualbyte capacity rather than hypotheticalF32bank.',
  'Apple typed checked encoder reuses original exactcodec/Completion. Original privateHylePagedAttention SteelF32 loader reads E4 directly; fixedscale bits are function constants and library/pipeline identity. Original plain/Q8 selection unchanged.'],
 failures_retained=['CUDA wrapper initially omitted provider target macro, then used default system metadata workspace instead of original pinned-host resource; corrected actualtarget dependency/setup.',
  'First shared fixture retained only a storageReadLease while asserting a GraphOutput observer gate; it now holds the real GraphOutput and the independent storage lease. Oracle/data/tolerance unchanged.',
  'Vulkan wrapper initially lacked staging domain; later its persistent TransferSlot retained the last downloaded Tensor and correctly blocked reuse. Newtest uses public synchronous one-shot download.',
  'CPU native ownership discovery first selected an old archive recipe missing the original boxed helper; final refresh targets actualexplicit native owner and canonical mixed generator.',
  'Apple generated Metal string TU failed an extra pedantic minimum-length warning; it uses the originalSDK generated-source recipe. Hyleproduct strict warnings retained.',
  'OldAppleQ8 joint fixture allocated next caller output before replacing the previous binding with a one-blockpool; explicit two-buffer testpool fixes setup, all oldmath/publication checks retained.',
  'InitialApple vendored-tree report sorted WindowsPath case-insensitively. RealCMake rejected it; root recomputed sorted relativePOSIX strings, corrected identity and allthree affected entries passed the normal audit.'],
 limits=['Ordinary uniformE4 paged capability only; compactMLA CKV/KPE physical representation/scalar binding and producer mapping remain unresolved. Currentmla dtype/schema guard is unchanged.',
  'NewE4 encoder failure and paged reader are separate journeys; no claim that a paired E4K/V encoder-to-pendingpage failure chain was executed. OldQ8 paired pending failure/recovery paths were retained.',
  'No raggedE4 expansion, allgeometry/type coverage,5/7byte encoder tail canary, wholeartifact/model payload, Linux, largecache, quality, nativeFP8GEMM or throughput acceptance.',
  'Positivefinite cache scalar is a coldschema interpretation. E4 attention reference scales0.5/2 do not prove arbitrary-scale bitwise equality to optimized factorized CUDA reductions.'],
 current_sources=source_ids,dependency_audit=identity(P/'root/lock-audit.json'),
 independent_source_review=identity(P/'root/independent-source-review.json'),
 archive=dict(**identity(archive),members=len(entries)),
 archive_entries=[dict(entry=name,bytes=p.stat().st_size,sha256=sha(p)) for name,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=identity(archive.with_suffix('.json')),archive=identity(archive),members=len(entries),current_sources=len(source_ids),new_cases=16,neighbors=6)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
