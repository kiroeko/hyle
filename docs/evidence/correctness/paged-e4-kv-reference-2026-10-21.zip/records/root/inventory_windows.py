from pathlib import Path
import ctypes,hashlib,json,os,subprocess,time
R=Path.cwd();P=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference';O=P/'root/cleanup-windows-inventory.json';O.parent.mkdir(parents=True,exist_ok=True)
def key(p):return os.path.normcase(os.path.abspath(str(p))).rstrip('\\/')
root_key=key(P)
def within(p):return key(p)==root_key or key(p).startswith(root_key+os.sep)
def identity(p):
 h=hashlib.sha256();n=0
 with open(p,'rb') as f:
  while True:
   block=f.read(1024*1024)
   if not block:break
   n+=len(block);h.update(block)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
reparse=[];unsafe=[];directories=[];files=[];pending=[P]
while pending:
 d=pending.pop();assert within(d),d
 st=os.stat(d,follow_symlinks=False)
 if getattr(st,'st_file_attributes',0)&0x400:
  reparse.append(dict(path=str(d),kind='directory',attributes=st.st_file_attributes));continue
 resolved=d.resolve(strict=True)
 if not within(resolved):unsafe.append(dict(path=str(d),resolved=str(resolved)));continue
 directories.append(str(d))
 with os.scandir(d) as entries:
  for e in entries:
   q=Path(e.path);st=e.stat(follow_symlinks=False)
   if getattr(st,'st_file_attributes',0)&0x400:
    reparse.append(dict(path=str(q),kind='directory' if e.is_dir(follow_symlinks=False) else 'file',attributes=st.st_file_attributes));continue
   if e.is_dir(follow_symlinks=False):pending.append(q)
   elif e.is_file(follow_symlinks=False):files.append(q)
exes=[identity(p) for p in sorted(files) if p.suffix.lower()=='.exe'];maps=[identity(p) for p in sorted(files) if p.suffix.lower()=='.map'];objects=[identity(p) for p in sorted(files) if p.suffix.lower()=='.obj']
cmd=['powershell','-NoProfile','-NonInteractive','-Command','Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3 -Compress'];res=subprocess.run(cmd,capture_output=True,text=True,encoding='utf8',errors='replace');assert res.returncode==0,res.stderr
processes=json.loads(res.stdout);processes=processes if isinstance(processes,list) else [processes];active=[];mentions=[]
# Exact executable location is the criterion for a running image from P.
# Keep non-image consumers separately; the inventory process and its shell
# naturally mention this directory and do not mean an inference/test is active.
for x in processes:
 exe=x.get('ExecutablePath')
 if exe and within(exe):active.append(x)
 c=(x.get('CommandLine') or '').replace('/','\\').lower()
 if str(P).lower() in c and x['ProcessId'] not in [os.getpid(),os.getppid()]:mentions.append(x)
report=dict(status='read_only_inventory_no_deletion',created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),workspace=str(R),root=str(P),root_resolved=str(P.resolve()),scope='Only this batch directory, no SDK or other project traversal.',candidate_delete_exactfiles=[*exes,*maps],candidate_counts=dict(exe=len(exes),map=len(maps),total=len(exes)+len(maps),bytes=sum(x['bytes'] for x in exes+maps)),retain_objects=objects,retain_counts=dict(obj=len(objects),bytes=sum(x['bytes'] for x in objects)),directory_safety=dict(directories_checked=len(directories),reparse_points=reparse,outside_root_resolutions=unsafe,followed_reparse_points=False),process_check=dict(command=cmd,exit_code=res.returncode,active_executables_under_batch=active,other_command_lines_mentioning_batch=mentions,excluded_inventory_process_ids=[os.getpid(),os.getppid()],no_active_batch_image=len(active)==0),rules=['No files were deleted. No root test.ps1 was written.','All .obj files are retained. Only exact .exe/.map files are proposed here.','Root must recheck current file identities/process state and write test.ps1 after packaging before deletion.'])
O.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(report=str(O),candidate_counts=report['candidate_counts'],retain_counts=report['retain_counts'],reparse_count=len(reparse),unsafe_count=len(unsafe),active_batch_images=len(active),other_mentions=len(mentions))))
