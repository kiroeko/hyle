from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('paged_build_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
old=A/'grouped-fp8-power2-reference/cpu/checks/attempt1/power-test-plan.json'
recipe=c.read(old);out=P/'cpu/checks'/sys.argv[1];out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
source=R/'tests/graph_route_cpu/paged_e4_kv_test.cc';tag='paged-test'
command=b.host_command(recipe['command'],source,tag,out)
c.save(out/'plan.json',dict(command=command,recipe=b.identity(old),source=b.identity(source)))
env,_=b.environment(command,[],out);c.execute(tag,command,env,out)
deps=c.read(out/(tag+'-deps.json'))['Data']
c.save(out/'identity.json',dict(command=command,source=b.identity(source),object=b.identity(out/(tag+'.obj')),
  source_dependencies=b.identity(out/(tag+'-deps.json')),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]))
print(out/'identity.json')
