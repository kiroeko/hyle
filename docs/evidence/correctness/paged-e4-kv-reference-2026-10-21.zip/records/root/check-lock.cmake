include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_cpu_runtime_patches ggml_vulkan_runtime_patches mlx_cast_patches)
