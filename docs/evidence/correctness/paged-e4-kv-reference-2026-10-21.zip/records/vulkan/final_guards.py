from pathlib import Path
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/vulkan'
for name in ['src/compute_provider_ggml_vulkan/region.cc','src/compute_route_vulkan/vulkan_tensor.cc']:
 p=S/'revisions/first-compiled'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/name).read_bytes())
def edit(name,a,b):
 p=R/name;raw=p.read_bytes();s=raw.decode().replace('\r\n','\n');assert s.count(a)==1,(name,a[:80]);p.write_bytes(s.replace(a,b).replace('\n','\r\n' if b'\r\n' in raw else '\n').encode())
edit('src/compute_provider_ggml_vulkan/region.cc','bool same_shape(const TensorDesc &a, const TensorDesc &b) noexcept {','''bool e4_cache_domain(const TensorDesc &description) noexcept {
  return description.valid() && description.is_plain() && description.is_dense() &&
      description.rank()==4 && description.data_type()==DataType::kFloat8E4M3FN &&
      description.element_count() && *description.element_count()>0 &&
      *description.element_count()<=INT32_MAX;
}
bool same_shape(const TensorDesc &a, const TensorDesc &b) noexcept {''')
edit('src/compute_provider_ggml_vulkan/region.cc','          inputs[port].is_dense() && inputs[port].data_type()==DataType::kFloat8E4M3FN) &&','          e4_cache_domain(inputs[port])) &&')
edit('src/compute_provider_ggml_vulkan/region.cc','      if(!recipe.values[value].is_dense() || recipe.values[value].data_type()!=DataType::kFloat8E4M3FN)','      if(!e4_cache_domain(recipe.values[value]))')
edit('src/compute_route_vulkan/vulkan_tensor.cc','  if(count>INT32_MAX || count>program.runtime->device->properties.limits.maxStorageBufferRange/4)\n    return Status::OutOfRange("Vulkan cache encoder dirty extent exceeds native limits");','''  const auto maximum=program.runtime->device->properties.limits.maxStorageBufferRange;
  if(count>INT32_MAX || (!e4 && count>maximum/4) ||
      (e4 && (*input.required_bytes()>maximum ||
               *program.values[step.outputs[0]].description.required_bytes()>maximum)))
    return Status::OutOfRange("Vulkan cache encoder dirty extent exceeds native limits");''')
# build helper final mode reuses exactly all other product/shader objects.
p=S/'build.py';s=p.read_text();a="elif sys.argv[1]=='test':compile_one('paged-test'";b="""elif sys.argv[1]=='final-products':
 C=S/'checks/attempt2';C.mkdir(parents=True,exist_ok=True)
 pairs=[('tensor',R/'src/compute_route_vulkan/vulkan_tensor.cc',old('vulkan_tensor.obj')),('region',R/'src/compute_provider_ggml_vulkan/region.cc',old('provider-region.obj'))]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(lambda x:compile_one(*x,extra=['/I'+str(G)]),pairs))
elif sys.argv[1]=='final-test':
 C=S/'checks/attempt2';C.mkdir(parents=True,exist_ok=True)
 compile_one('paged-test',R/'tests/graph_route_vulkan/paged_e4_kv_test.cc',r=A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')
elif sys.argv[1]=='final-link':
 C=S/'checks/attempt2';C.mkdir(parents=True,exist_ok=True);prior=read(S/'checks/attempt1/link-plan.json');repl={str(S/'checks/attempt1'/(k+'.obj')):str(C/(k+'.obj')) for k in ['tensor','region','paged-test']}
 cmd=[repl.get(x,x) for x in prior['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];cmd+=['/OUT:'+str(C/'paged-e4.exe'),'/MAP:'+str(C/'paged-e4.map'),'/IMPLIB:'+str(C/'paged-e4.lib')];run('link',cmd);save(C/'link-plan.json',dict(command=cmd,inputs=[ident(x) for x in cmd[1:] if Path(x).is_file()],baseline=ident(S/'checks/attempt1/link-plan.json'),replacements=repl,executable=ident(C/'paged-e4.exe'),SDK_build=0,GPU=0))
elif sys.argv[1]=='test':compile_one('paged-test'""";assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
