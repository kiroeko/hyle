from pathlib import Path
import json,hashlib
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/vulkan';P=S/'current-patch-source';manifest=R/'third_party/ggml_vulkan_runtime/patches.json';doc=json.loads(manifest.read_bytes())
def patch(name,a,b):
 p=P/name;s=p.read_text().replace('\r\n','\n');assert s.count(a)==1,(name,a[:70],s.count(a));s=s.replace(a,b);p.write_bytes(s.encode())
 row=next(x for x in doc['files'] if x['path']==name);row['edits'].append(dict(before=a,after=b));row['after_sha256']=hashlib.sha256(s.encode()).hexdigest()
c='src/ggml-vulkan/ggml-vulkan.cpp';sh='src/ggml-vulkan/vulkan-shaders/flash_attn.comp';gen='src/ggml-vulkan/vulkan-shaders/vulkan-shaders-gen.cpp'
patch(c,'    bool hyle_full_f32 = false;','''    bool hyle_full_f32 = false;
    uint32_t hyle_key_scale = 0x3f800000u;
    uint32_t hyle_value_scale = 0x3f800000u;''')
patch(c,'k_type, v_type, hyle_full_f32) <','k_type, v_type, hyle_full_f32, hyle_key_scale, hyle_value_scale) <')
patch(c,'b.k_type, b.v_type, b.hyle_full_f32);','b.k_type, b.v_type, b.hyle_full_f32, b.hyle_key_scale, b.hyle_value_scale);')
patch(c,'        /*15 FaBlockBytesV   */ fa_block_bytes(state.v_type),','''        /*15 FaBlockBytesV   */ fa_block_bytes(state.v_type),
        /*16 E4 key scale    */ state.hyle_key_scale,
        /*17 E4 value scale  */ state.hyle_value_scale,''')
patch(c,'        if (fa.first.hyle_full_f32 || bf16_kv) {','''        if (fa.first.hyle_full_f32 && fa.first.k_type == GGML_TYPE_I8) {
            spv_data = hyle_flash_attn_e4_fp32_data;
            spv_size = hyle_flash_attn_e4_fp32_len;
            name = "hyle_flash_attn_e4_full_f32";
        } else if (fa.first.hyle_full_f32 || bf16_kv) {''')
patch(c,'    fa_pipeline_state.hyle_full_f32 = hyle_full_f32;','''    fa_pipeline_state.hyle_full_f32 = hyle_full_f32;
    if (dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionStorageSlot] ==
        hyle::compute::ggml_vulkan::bridge::kFlashAttentionE4M3) {
        memcpy(&fa_pipeline_state.hyle_key_scale,
            &dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionKeyScaleSlot], sizeof(uint32_t));
        memcpy(&fa_pipeline_state.hyle_value_scale,
            &dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionValueScaleSlot], sizeof(uint32_t));
    }''')
a='''                if (hyle_paged) {
                    const auto * table = op->src[5];'''
b='''                const bool hyle_e4 = hyle_paged && hyle_full_f32 &&
                    op->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionStorageSlot] ==
                        hyle::compute::ggml_vulkan::bridge::kFlashAttentionE4M3;
                if (hyle_e4) {
                    float key_scale, value_scale;
                    memcpy(&key_scale, &op->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionKeyScaleSlot], sizeof(float));
                    memcpy(&value_scale, &op->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionValueScaleSlot], sizeof(float));
                    if (op->src[1]->type != GGML_TYPE_I8 || op->src[2]->type != GGML_TYPE_I8 ||
                        !std::isfinite(key_scale) || key_scale <= 0.0f ||
                        !std::isfinite(value_scale) || value_scale <= 0.0f) return false;
                }
                if (hyle_paged) {
                    const auto * table = op->src[5];'''
patch(c,a,b)
patch(c,'                         op->src[1]->type != GGML_TYPE_Q8_0) ||','                         op->src[1]->type != GGML_TYPE_Q8_0 && !hyle_e4) ||')
patch(c,'                         op->src[1]->type != GGML_TYPE_F32 && op->src[1]->type != GGML_TYPE_Q8_0) ||','                         op->src[1]->type != GGML_TYPE_F32 && op->src[1]->type != GGML_TYPE_Q8_0 && !hyle_e4) ||')
patch(c,'                         op->src[2]->type != GGML_TYPE_F32 && op->src[2]->type != GGML_TYPE_Q8_0)) {','                         op->src[2]->type != GGML_TYPE_F32 && op->src[2]->type != GGML_TYPE_Q8_0 && !hyle_e4)) {')
patch(c,'                if (!fa_kv_ok(op->src[1]->type) || !fa_kv_ok(op->src[2]->type)) {','                if ((!fa_kv_ok(op->src[1]->type) || !fa_kv_ok(op->src[2]->type)) && !hyle_e4) {')
patch(sh,'#include "flash_attn_dequant.glsl"','''#include "flash_attn_dequant.glsl"
#ifdef HYLE_E4_CACHE
#include "hyle_e4_cache.glsl"
layout(constant_id = 16) const uint HyleKeyScale = 0x3f800000u;
layout(constant_id = 17) const uint HyleValueScale = 0x3f800000u;
layout(binding = 1) readonly buffer HyleE4K { uint hyle_e4_k[]; };
layout(binding = 2) readonly buffer HyleE4V { uint hyle_e4_v[]; };
// I8 is only an opaque byte carrier. This variant exists solely for the
// private paged E4 tag; ordinary ggml I8 arithmetic remains unsupported.
FLOAT_TYPEV4 hyle_e4_dequantize4(uint ib, uint iqs, uint offset, uint port) {
    uint address = offset + ib;
    uint word = port == BINDING_IDX_K ? hyle_e4_k[address / 4u] : hyle_e4_v[address / 4u];
    uint scale = port == BINDING_IDX_K ? HyleKeyScale : HyleValueScale;
    vec4 result;
    for(uint lane=0u;lane<4u;++lane)
        result[lane] = uintBitsToFloat(hyle_f32_mul(fp8_e4m3_to_f32_bits((word>>(lane*8u))&255u),scale));
    return FLOAT_TYPEV4(result);
}
#define dequantize4 hyle_e4_dequantize4
#endif''')
# Register exactly one new scalar-F32 module, alongside unchanged original variants.
patch(gen,'    for (const bool& fp16 : {false, true}) {\n        std::map<std::string, std::string> base_dict;', '''    string_to_spv("hyle_flash_attn_e4", "flash_attn.comp",
        {{"FLOAT_TYPE", "float"}, {"FLOAT_TYPEV2", "vec2"}, {"FLOAT_TYPEV4", "vec4"},
         {"ACC_TYPE", "float"}, {"ACC_TYPEV2", "vec2"}, {"ACC_TYPEV4", "vec4"},
         {"DATA_A_IQ4_NL", "1"}, {"Q_TYPE", "float"}, {"D_TYPE", "float"}, {"D_TYPEV4", "vec4"},
         {"HYLE_E4_CACHE", "1"}}, false, false, false, false);

    for (const bool& fp16 : {false, true}) {
        std::map<std::string, std::string> base_dict;''')
manifest.write_text(json.dumps(doc,indent=2)+'\n')
# Canonical CMake builds the added include from the exact shared implementation.
p=R/'src/compute_ggml_runtime/CMakeLists.txt';raw=p.read_bytes();s=raw.decode().replace('\r\n','\n');a='  set(_vk_patches "${HYLE_SOURCE_DIR}/third_party/ggml_vulkan_runtime")';b=a+'''
  set(_vk_e4_manifest "${CMAKE_CURRENT_BINARY_DIR}/vulkan-e4-source.json")
  execute_process(COMMAND "${Python3_EXECUTABLE}"
    "${CMAKE_CURRENT_SOURCE_DIR}/prepare_vulkan_e4_manifest.py" --output "${_vk_e4_manifest}"
    RESULT_VARIABLE _vk_e4_result ERROR_VARIABLE _vk_e4_error)
  if(NOT _vk_e4_result EQUAL 0)
    message(FATAL_ERROR "Vulkan E4 numerical source preparation failed: ${_vk_e4_error}")
  endif()
  list(APPEND _manifests "${_vk_e4_manifest}")
  list(APPEND _patch_args --manifest "${_vk_e4_manifest}")
  foreach(_vk_e4_input IN ITEMS
      "${CMAKE_CURRENT_SOURCE_DIR}/prepare_vulkan_e4_manifest.py"
      "${HYLE_SOURCE_DIR}/src/compute_shader_shared/nvfp4_f32.h"
      "${HYLE_SOURCE_DIR}/src/compute_route_vulkan/shaders/fp8_storage.glsl")
    file(SHA256 "${_vk_e4_input}" _vk_e4_sha)
    string(APPEND _source_identity "${_vk_e4_sha}")
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS "${_vk_e4_input}")
  endforeach()''';assert s.count(a)==1;s=s.replace(a,b);p.write_bytes(s.replace('\n','\r\n' if b'\r\n' in raw else '\n').encode())
print('vendor patch ready')
