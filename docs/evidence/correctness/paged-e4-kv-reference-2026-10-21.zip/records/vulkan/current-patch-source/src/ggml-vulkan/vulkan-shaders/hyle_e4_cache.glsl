// Generated from HYLE shared IEEE arithmetic and E4 storage codec.
uint hyle_mul_hi(uint a,uint b) { uint high,low; umulExtended(a,b,high,low); return high; }
uint hyle_clz(uint v) { return v==0u ? 32u : 31u-uint(findMSB(v)); }

uint hyle_shift_jam(uint value, uint distance) {
  if (distance == 0u) return value;
  if (distance >= 32u) return uint(value != 0u);
  return (value >> distance) | uint((value << (32u-distance)) != 0u);
}

uint hyle_f32_pack(uint sign, int exponent, uint significand) {
  if (significand == 0u) return sign;
  if (significand >= 0x08000000u) {
    significand = hyle_shift_jam(significand,1u);
    ++exponent;
  }
  while (significand < 0x04000000u && exponent > 1) {
    significand <<= 1u;
    --exponent;
  }
  if (exponent < 1) {
    significand = hyle_shift_jam(significand,uint(1-exponent));
    exponent = 1;
  }
  uint tail = significand & 7u;
  uint rounded = (significand >> 3u) +
      uint(tail > 4u || (tail == 4u && (significand & 8u) != 0u));
  if (rounded >= 0x01000000u) {
    rounded >>= 1u;
    ++exponent;
  }
  if (exponent >= 255) return sign | 0x7f800000u;
  uint field = exponent == 1 && rounded < 0x00800000u ? 0u : uint(exponent);
  return sign | (field << 23u) | (rounded & 0x007fffffu);
}

struct HyleF32Parts { uint significand; int exponent; };
HyleF32Parts hyle_f32_parts(uint bits) {
  HyleF32Parts value;
  value.significand = bits & 0x007fffffu;
  value.exponent = int((bits >> 23u) & 255u);
  if (value.exponent != 0) value.significand |= 0x00800000u;
  else {
    uint shift = hyle_clz(value.significand)-8u;
    value.significand <<= shift;
    value.exponent = 1-int(shift);
  }
  return value;
}

uint hyle_f32_nan(uint a, uint b) {
  if ((a & 0x7fffffffu) > 0x7f800000u) return a | 0x00400000u;
  if ((b & 0x7fffffffu) > 0x7f800000u) return b | 0x00400000u;
  return 0x7fc00000u;
}

uint hyle_f32_mul(uint a, uint b) {
  uint sign = (a ^ b) & 0x80000000u;
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa >= 0x7f800000u || bb >= 0x7f800000u) {
    if (aa > 0x7f800000u || bb > 0x7f800000u || aa == 0u || bb == 0u)
      return hyle_f32_nan(a,b);
    return sign | 0x7f800000u;
  }
  if (aa == 0u || bb == 0u) return sign;
  HyleF32Parts left = hyle_f32_parts(a), right = hyle_f32_parts(b);
  uint low = left.significand * right.significand;
  uint high = hyle_mul_hi(left.significand,right.significand);
  uint extended = (high << 12u) | (low >> 20u) | uint((low & 0x000fffffu) != 0u);
  return hyle_f32_pack(sign,left.exponent+right.exponent-127,extended);
}

uint hyle_f32_div(uint a, uint b) {
  uint sign = (a ^ b) & 0x80000000u;
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa > 0x7f800000u || bb > 0x7f800000u ||
      (aa == 0x7f800000u && bb == 0x7f800000u) || (aa == 0u && bb == 0u))
    return hyle_f32_nan(a,b);
  if (aa == 0x7f800000u || bb == 0u) return sign | 0x7f800000u;
  if (aa == 0u || bb == 0x7f800000u) return sign;
  HyleF32Parts left = hyle_f32_parts(a), right = hyle_f32_parts(b);
  int exponent = left.exponent-right.exponent+127;
  uint remainder = left.significand, quotient = 0u;
  if (remainder < right.significand) {
    remainder <<= 1u;
    --exponent;
  }
  for (uint bit = 0u; bit < 27u; ++bit) {
    uint next = uint(remainder >= right.significand);
    if (next != 0u) remainder -= right.significand;
    quotient = (quotient << 1u) | next;
    if (bit != 26u) remainder <<= 1u;
  }
  quotient |= uint(remainder != 0u);
  return hyle_f32_pack(sign,exponent,quotient);
}

uint hyle_f32_add(uint a, uint b) {
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa >= 0x7f800000u || bb >= 0x7f800000u) {
    if (aa > 0x7f800000u || bb > 0x7f800000u ||
        (aa == 0x7f800000u && bb == 0x7f800000u && ((a ^ b) & 0x80000000u) != 0u))
      return hyle_f32_nan(a,b);
    return aa == 0x7f800000u ? a : b;
  }
  if (aa == 0u && bb == 0u) return (a & b) & 0x80000000u;
  if (aa == 0u) return b;
  if (bb == 0u) return a;
  // Larger magnitude first keeps subtraction nonnegative, including zeros.
  if (aa < bb) { uint temporary=a; a=b; b=temporary; }
  uint ea = (a >> 23u) & 255u, eb = (b >> 23u) & 255u;
  uint left = (a & 0x007fffffu) | (ea == 0u ? 0u : 0x00800000u);
  uint right = (b & 0x007fffffu) | (eb == 0u ? 0u : 0x00800000u);
  ea = ea == 0u ? 1u : ea;
  eb = eb == 0u ? 1u : eb;
  left <<= 3u;
  right = hyle_shift_jam(right << 3u,ea-eb);
  uint result = ((a ^ b) & 0x80000000u) == 0u ? left+right : left-right;
  // Exact cancellation under round-to-nearest produces positive zero.
  if (result == 0u) return 0u;
  return hyle_f32_pack(a & 0x80000000u,int(ea),result);
}

// Plain storage conversion matches the public SIMD E4M3FN contract. Integer
// fields retain NaN/zero signs and avoid FTZ or arithmetic at rounding ties.
uint fp8_e4m3_to_f32_bits(uint code) {
    uint sign_bit = (code & 128u) << 24u;
    uint magnitude = code & 127u;
    uint exponent = magnitude >> 3u, mantissa = magnitude & 7u;
    if (magnitude == 127u) return sign_bit | 0x7fc00000u;
    if (exponent != 0u)
        return sign_bit | ((exponent + 120u) << 23u) | (mantissa << 20u);
    if (mantissa == 0u) return sign_bit;
    uint leading = uint(findMSB(mantissa));
    return sign_bit | ((leading + 118u) << 23u) |
           ((mantissa << (23u - leading)) & 0x7fffffu);
}
uint f32_to_fp8_e4m3_bits(uint bits) {
    uint sign_bit = (bits >> 24u) & 128u;
    uint magnitude = bits & 0x7fffffffu;
    if (magnitude > 0x7f800000u) return sign_bit | 127u;
    if (magnitude >= 0x43e00000u) return sign_bit | 126u;
    int exponent = int(magnitude >> 23u) - 120;
    uint high, remainder, midpoint;
    if (exponent >= 1) {
        high = (uint(exponent) << 3u) | ((magnitude >> 20u) & 7u);
        remainder = magnitude & 0xfffffu;
        midpoint = 0x80000u;
    } else {
        uint shift = uint(1 - exponent);
        if (shift > 4u) return sign_bit;
        uint significand = (magnitude & 0x7fffffu) | 0x800000u;
        uint drop = 20u + shift;
        high = significand >> drop;
        remainder = significand & ((1u << drop) - 1u);
        midpoint = 1u << (drop - 1u);
    }
    high += uint(remainder > midpoint || (remainder == midpoint && (high & 1u) != 0u));
    return sign_bit | min(high, 126u);
}
