from pathlib import Path
import concurrent.futures,ctypes,hashlib,json,os,struct,subprocess,sys,time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'paged-e4-kv-reference/vulkan';B=A/'grouped-fp8-power2-reference/vulkan/checks/none-rne/link-plan.json';C=S/'checks/attempt1';C.mkdir(parents=True,exist_ok=True);G=S/'generated';G.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_bytes())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def ident(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
base=read(B);env=os.environ.copy();res=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in res.stdout.splitlines():
 if '=' in line and not line.startswith('='):k,v=line.split('=',1);env[k.upper()]=v
(S/'tmp').mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(S/'tmp')
def run(tag,cmd):
 start=time.time();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace');save(C/(tag+'-command.json'),dict(command=cmd,cwd=str(R),exit_code=p.returncode,seconds=time.time()-start));(C/(tag+'-stdout.txt')).write_text(p.stdout);(C/(tag+'-stderr.txt')).write_text(p.stderr);print(tag,p.returncode,flush=True)
 if p.returncode:raise RuntimeError((p.stdout+p.stderr)[-5500:])
def recipe(obj):
 for p in Path(obj).parent.glob('*identity.json'):
  d=read(p)
  if Path(d.get('object',{}).get('path',''))==Path(obj):return p
 raise ValueError(obj)
def old(name):return next(x['path'] for x in base['inputs'] if Path(x['path']).name==name)
def compile_one(tag,src,obj=None,r=None,extra=()):
 r=r or recipe(obj);cmd=[];skip=False
 for arg in read(r)['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  cmd.append(arg)
 # prepend includes before existing /I entries to prefer fresh generated interface
 cmd[1:1]=list(extra);cmd+=['/W4','/WX','/sourceDependencies',str(C/(tag+'-deps.json')),str(src),'/Fo'+str(C/(tag+'.obj')),'/Fd'+str(C/(tag+'.pdb'))];run(tag,cmd)
 d=read(C/(tag+'-deps.json'))['Data'];save(C/(tag+'-identity.json'),dict(source=ident(src),object=ident(C/(tag+'.obj')),command=cmd,recipe=ident(r),replaces=ident(obj) if obj else None,dependencies=[ident(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]))
if sys.argv[1] in ('shaders','cache-refresh'):
 if sys.argv[1]=='cache-refresh':
  C=S/'checks/attempt3';C.mkdir(parents=True,exist_ok=True);G=S/'generated/unaligned-load';G.mkdir(parents=True,exist_ok=True)
 # Build the sole new HYLE shader and append it to the unchanged 24 cached arrays.
 shader=R/'src/compute_route_vulkan/shaders/cache_encode_e4.comp';numeric=(R/'src/compute_shader_shared/nvfp4_f32.h').read_text().split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0];typed=(R/'src/compute_shader_shared/ct_packed.h').read_text().split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0];generated=G/'cache_encode_e4.comp';generated.write_text(shader.read_text().replace('// HYLE_CACHE_E4_F32_SOURCE',numeric+'\n'+typed));out=G/'cache_encode_e4.spv';run('shader-cache',['C:/public/tools/glslang/glslangValidator.exe','-V','--target-env','vulkan1.2','--preamble-text','#extension GL_GOOGLE_include_directive : require\n','-I'+str(R/'src/compute_route_vulkan/shaders'),'-S','comp','-o',str(out),str(generated)])
 words=struct.unpack('<'+'I'*(out.stat().st_size//4),out.read_bytes());assert words[0]==0x07230203
 i=5
 while i<len(words):
  n,op=words[i]>>16,words[i]&65535;assert n>0
  if op==17:assert words[i+1]==1
  i+=n
 oldrec=read(recipe(old('vulkan_shaders.obj')));src=Path(oldrec['source']['path']);h=src.with_name('vulkan_shaders.h').read_text();s=src.read_text();end='} // namespace hyle::compute::vulkan::detail::shaders';assert s.count(end)==1 and h.count(end)==1
 h=h.replace(end,'std::span<const std::uint32_t> cache_encode_e4() noexcept;\n'+end);code='namespace { constexpr std::uint32_t cache_encode_e4_words[] = {\n'+'\n'.join('  '+', '.join(f'0x{x:08x}u' for x in words[i:i+8])+',' for i in range(0,len(words),8))+'\n}; }\nstd::span<const std::uint32_t> cache_encode_e4() noexcept { return cache_encode_e4_words; }\n';s=s.replace(end,code+end);(G/'vulkan_shaders.h').write_text(h);(G/'vulkan_shaders.cc').write_text(s)
 if sys.argv[1]=='cache-refresh':
  save(C/'shader-summary.json',dict(shader_compiles=1,SDK_build=0,GPU=0,new=[ident(out)],old_HYLE_arrays_byte_unchanged=True))
  compile_one('shaders',G/'vulkan_shaders.cc',old('vulkan_shaders.obj'),extra=['/I'+str(G)])
  prior=read(S/'checks/attempt2/link-plan.json');repl={str(S/'checks/attempt1/shaders.obj'):str(C/'shaders.obj')};cmd=[repl.get(x,x) for x in prior['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];cmd+=['/OUT:'+str(C/'paged-e4.exe'),'/MAP:'+str(C/'paged-e4.map'),'/IMPLIB:'+str(C/'paged-e4.lib')];run('link',cmd);save(C/'link-plan.json',dict(command=cmd,inputs=[ident(x) for x in cmd[1:] if Path(x).is_file()],baseline=ident(S/'checks/attempt2/link-plan.json'),replacements=repl,executable=ident(C/'paged-e4.exe'),SDK_build=0,GPU=0));sys.exit(0)
 # One new upstream variant. All includes are original pinned files except
 # the tagged page shader and its generated exact shared numerical include.
 native=S/'current-patch-source/src/ggml-vulkan/vulkan-shaders';m=read(S/'e4-source-manifest.json')['files'][0];(native/'hyle_e4_cache.glsl').write_text(m['content']);original=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/src/ggml-vulkan/vulkan-shaders');spv=G/'hyle_flash_attn_e4_fp32.spv'
 defines={'FLOAT_TYPE':'float','FLOAT_TYPEV2':'vec2','FLOAT_TYPEV4':'vec4','ACC_TYPE':'float','ACC_TYPEV2':'vec2','ACC_TYPEV4':'vec4','DATA_A_IQ4_NL':'1','Q_TYPE':'float','D_TYPE':'float','D_TYPEV4':'vec4','HYLE_E4_CACHE':'1'}
 run('shader-page',['C:/public/tools/hyle-vulkan/1.4.357.0/Bin/glslc.exe','-fshader-stage=compute','--target-env=vulkan1.2','-O','-I'+str(native),'-I'+str(original),*[f'-D{k}={v}' for k,v in defines.items()],str(native/'flash_attn.comp'),'-o',str(spv)])
 # Keep the vendor-generated shader ABI and give the new module a unique name.
 db=read(R/'.scratch/bench-api-runtime/vulkan/build/compile_commands.json');rec=next(x for x in db if Path(x['file']).name=='ggml-vulkan.cpp');inc=Path(rec['directory'])/'ggml-vulkan-shaders.hpp'
 if not inc.exists():inc=R/'.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/vendor/src/ggml-vulkan/ggml-vulkan-shaders.hpp'
 assert inc.exists(),inc
 h=inc.read_text()+'\nextern const uint64_t hyle_flash_attn_e4_fp32_len;\nextern const unsigned char hyle_flash_attn_e4_fp32_data[];\n';(G/'ggml-vulkan-shaders.hpp').write_text(h);b=spv.read_bytes();(G/'page_blob.cc').write_text('#include "ggml-vulkan-shaders.hpp"\nconst uint64_t hyle_flash_attn_e4_fp32_len='+str(len(b))+';\nconst unsigned char hyle_flash_attn_e4_fp32_data[]={\n'+','.join(hex(x) for x in b)+'\n};\n')
 save(C/'shader-summary.json',dict(shader_compiles=2,SDK_build=0,GPU=0,old_HYLE_arrays_byte_unchanged=True,original_shader_count=24,new=[ident(out),ident(spv)],shared_numerical_manifest=ident(S/'e4-source-manifest.json'),old_generated_source=ident(src)))
elif sys.argv[1]=='products':
 pairs=[('batch',R/'src/compute_route_vulkan/vulkan_batch.cc',old('compute_route_vulkan-vulkan_batch.obj')),('program',R/'src/compute_route_vulkan/vulkan_program.cc',old('program.obj')),('tensor',R/'src/compute_route_vulkan/vulkan_tensor.cc',old('vulkan_tensor.obj')),('region',R/'src/compute_provider_ggml_vulkan/region.cc',old('provider-region.obj')),('shaders',G/'vulkan_shaders.cc',old('vulkan_shaders.obj'))]
 def one(x):compile_one(*x,extra=['/I'+str(G)])
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:list(p.map(one,pairs))
 compile_one('page-blob',G/'page_blob.cc',r=recipe(old('vulkan_shaders.obj')),extra=['/I'+str(G)])
 # Use the original vendor C++17 compile command, not HYLE's C++latest flags.
 db=read(R/'.scratch/bench-api-runtime/vulkan/build/compile_commands.json');rec=next(x for x in db if Path(x['file']).name=='ggml-vulkan.cpp');fn=ctypes.windll.shell32.CommandLineToArgvW;fn.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];fn.restype=ctypes.POINTER(ctypes.c_wchar_p);n=ctypes.c_int();v=fn(rec['command'],ctypes.byref(n));cmd=[v[i] for i in range(n.value)];ctypes.windll.kernel32.LocalFree(v);cmd=[x for x in cmd if not x.lower().startswith(('/fo','/fd')) and x.lower()!=str(Path(rec['file'])).lower()];cmd[1:1]=['/I'+str(G),'/I'+str(Path(rec['file']).parent)];src=S/'current-patch-source/src/ggml-vulkan/ggml-vulkan.cpp';cmd+=['/sourceDependencies',str(C/'driver-deps.json'),str(src),'/Fo'+str(C/'driver.obj'),'/Fd'+str(C/'driver.pdb')];run('driver',cmd);d=read(C/'driver-deps.json')['Data'];save(C/'driver-identity.json',dict(source=ident(src),object=ident(C/'driver.obj'),command=cmd,recipe=ident(R/'.scratch/bench-api-runtime/vulkan/build/compile_commands.json'),replaces=ident(old('ggml-vulkan-driver.obj')),dependencies=[ident(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]))
elif sys.argv[1]=='final-products':
 C=S/'checks/attempt2';C.mkdir(parents=True,exist_ok=True)
 pairs=[('tensor',R/'src/compute_route_vulkan/vulkan_tensor.cc',old('vulkan_tensor.obj')),('region',R/'src/compute_provider_ggml_vulkan/region.cc',old('provider-region.obj'))]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:list(p.map(lambda x:compile_one(*x,extra=['/I'+str(G)]),pairs))
elif sys.argv[1]=='final-test':
 C=S/'checks/attempt2';C.mkdir(parents=True,exist_ok=True)
 compile_one('paged-test',R/'tests/graph_route_vulkan/paged_e4_kv_test.cc',r=A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')
elif sys.argv[1]=='final-link':
 C=S/'checks/attempt2';C.mkdir(parents=True,exist_ok=True);prior=read(S/'checks/attempt1/link-plan.json');repl={str(S/'checks/attempt1'/(k+'.obj')):str(C/(k+'.obj')) for k in ['tensor','region','paged-test']}
 cmd=[repl.get(x,x) for x in prior['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];cmd+=['/OUT:'+str(C/'paged-e4.exe'),'/MAP:'+str(C/'paged-e4.map'),'/IMPLIB:'+str(C/'paged-e4.lib')];run('link',cmd);save(C/'link-plan.json',dict(command=cmd,inputs=[ident(x) for x in cmd[1:] if Path(x).is_file()],baseline=ident(S/'checks/attempt1/link-plan.json'),replacements=repl,executable=ident(C/'paged-e4.exe'),SDK_build=0,GPU=0))
elif sys.argv[1]=='staging-fix':
 C=S/'checks/attempt4';C.mkdir(parents=True,exist_ok=True)
 compile_one('paged-test',R/'tests/graph_route_vulkan/paged_e4_kv_test.cc',r=A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')
 prior=read(S/'checks/attempt3/link-plan.json');repl={str(S/'checks/attempt2/paged-test.obj'):str(C/'paged-test.obj')};cmd=[repl.get(x,x) for x in prior['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];cmd+=['/OUT:'+str(C/'paged-e4.exe'),'/MAP:'+str(C/'paged-e4.map'),'/IMPLIB:'+str(C/'paged-e4.lib')];run('link',cmd);save(C/'link-plan.json',dict(command=cmd,inputs=[ident(x) for x in cmd[1:] if Path(x).is_file()],baseline=ident(S/'checks/attempt3/link-plan.json'),replacements=repl,executable=ident(C/'paged-e4.exe'),SDK_build=0,GPU=0))
elif sys.argv[1]=='lifetime-fix':
 C=S/'checks/attempt5';C.mkdir(parents=True,exist_ok=True)
 tasks=[('route-region',R/'src/compute_route_vulkan/vulkan_region.cc',old('route-region.obj'),None),('paged-test',R/'tests/graph_route_vulkan/paged_e4_kv_test.cc',None,A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(lambda x:compile_one(x[0],x[1],x[2],x[3],extra=['/I'+str(G)]),tasks))
 prior=read(S/'checks/attempt4/link-plan.json');repl={old('route-region.obj'):str(C/'route-region.obj'),str(S/'checks/attempt4/paged-test.obj'):str(C/'paged-test.obj')};cmd=[repl.get(x,x) for x in prior['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];cmd+=['/OUT:'+str(C/'paged-e4.exe'),'/MAP:'+str(C/'paged-e4.map'),'/IMPLIB:'+str(C/'paged-e4.lib')];run('link',cmd);save(C/'link-plan.json',dict(command=cmd,inputs=[ident(x) for x in cmd[1:] if Path(x).is_file()],baseline=ident(S/'checks/attempt4/link-plan.json'),replacements=repl,executable=ident(C/'paged-e4.exe'),SDK_build=0,GPU=0))
elif sys.argv[1]=='q8-neighbor':
 C=S/'checks/q8-neighbor';C.mkdir(parents=True,exist_ok=True)
 compile_one('q8-neighbor',R/'tests/compute_batch/encoded_page_native_consumer.cc',r=A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')
 prior=read(S/'checks/attempt5/link-plan.json');cmd=[x for x in prior['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];cmd.insert(1,str(C/'q8-neighbor.obj'));cmd+=['/OUT:'+str(C/'paged-e4.exe'),'/MAP:'+str(C/'paged-e4.map'),'/IMPLIB:'+str(C/'paged-e4.lib')];run('link',cmd);save(C/'link-plan.json',dict(command=cmd,inputs=[ident(x) for x in cmd[1:] if Path(x).is_file()],baseline=ident(S/'checks/attempt5/link-plan.json'),added_test=ident(C/'q8-neighbor.obj'),executable=ident(C/'paged-e4.exe'),SDK_build=0,GPU=0))
elif sys.argv[1]=='test':compile_one('paged-test',R/'tests/graph_route_vulkan/paged_e4_kv_test.cc',r=A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')
elif sys.argv[1]=='audit':
 dump=Path(env['VCTOOLSINSTALLDIR'])/'bin/Hostx64/x64/dumpbin.exe';found=[]
 for x in base['inputs']:
  if Path(x['path']).suffix!='.obj':continue
  p=subprocess.run([str(dump),'/symbols',x['path']],capture_output=True,text=True,encoding='utf8',errors='replace',check=True);lines=[l for l in p.stdout.splitlines() if 'PagedAttentionRead' in l and 'UNDEF' not in l]
  if lines:found.append(dict(object=x,defined_symbols=lines))
 save(S/'descriptor-owner-audit.json',dict(base=ident(B),matches=found));print('defined owners',[(Path(x['object']['path']).name,len(x['defined_symbols'])) for x in found])
elif sys.argv[1]=='link':
 for x in base['inputs']:assert ident(x['path'])==x
 names={'batch':'compute_route_vulkan-vulkan_batch.obj','program':'program.obj','tensor':'vulkan_tensor.obj','region':'provider-region.obj','shaders':'vulkan_shaders.obj','driver':'ggml-vulkan-driver.obj'};repl={old(v):str(C/(k+'.obj')) for k,v in names.items()};cmd=[repl.get(x,x) for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];cmd[1:1]=[str(C/'paged-test.obj'),str(C/'page-blob.obj')];cmd+=['/OUT:'+str(C/'paged-e4.exe'),'/MAP:'+str(C/'paged-e4.map'),'/IMPLIB:'+str(C/'paged-e4.lib')];run('link',cmd);save(C/'link-plan.json',dict(command=cmd,inputs=[ident(x) for x in cmd[1:] if Path(x).is_file()],baseline=ident(B),replacements=repl,executable=ident(C/'paged-e4.exe'),SDK_build=0,GPU=0))
else:raise ValueError(sys.argv[1])
