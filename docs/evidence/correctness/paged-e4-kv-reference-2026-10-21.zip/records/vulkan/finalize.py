from pathlib import Path
import json,hashlib,difflib,subprocess
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/vulkan'
def ident(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
owned=['src/compute_provider_ggml_vulkan/region.h','src/compute_provider_ggml_vulkan/region.cc','src/compute_provider_ggml_vulkan/native_bridge.h','src/compute_route_vulkan/vulkan_batch.cc','src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_tensor.cc','src/compute_route_vulkan/vulkan_region.cc','src/compute_route_vulkan/build_shaders.py','src/compute_route_vulkan/shaders/cache_encode_e4.comp','src/compute_ggml_runtime/CMakeLists.txt','src/compute_ggml_runtime/prepare_vulkan_e4_manifest.py','third_party/ggml_vulkan_runtime/patches.json','third_party/ggml_vulkan_runtime/NOTICE.md']
reused=['src/compute_shader_shared/nvfp4_f32.h','src/compute_shader_shared/ct_packed.h','src/compute_route_vulkan/shaders/fp8_storage.glsl'];rootowned=['tests/graph_route_vulkan/paged_e4_kv_test.cc','tests/graph_route_vulkan/CMakeLists.txt','tests/compute_models/paged_e4_kv_fixture.h','tests/compute_batch/encoded_page_native_consumer.cc'];files=[];diff=[]
for name in owned+reused+rootowned:
 src=R/name;dst=S/'after'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes());before=S/'before'/name;files.append(dict(source=str(src),after=ident(dst),before=ident(before) if before.exists() else None,scope='modified_or_new_Vulkan' if name in owned else 'reused_math' if name in reused else 'root_owned_current_test'))
 if name in owned:
  a=before.read_text().splitlines(True) if before.exists() else [];b=src.read_text().splitlines(True);diff+=list(difflib.unified_diff(a,b,fromfile='before/'+name,tofile=name))
(S/'implementation.diff').write_text(''.join(diff));save(S/'final-source-freeze.json',dict(status='frozen_products_and_current_tests',files=files,private_PagedAttentionRead_revision=2,public_API_ABI_changed=False))
# Check each current link object's newly compiled source dependencies. Reused old
# SDK/object closure is explicitly identified by the baseline link plan.
plan=json.loads((S/'checks/q8-neighbor/link-plan.json').read_bytes());objects={x['path'] for x in plan['inputs'] if Path(x['path']).suffix=='.obj' and S in Path(x['path']).parents};receipts=[];drift=[]
for f in (S/'checks').rglob('*identity.json'):
 d=json.loads(f.read_bytes());o=d.get('object',{}).get('path')
 if o not in objects:continue
 assert ident(o)==d['object'];rows=[]
 for dep in d['dependencies']:
  now=ident(dep['path']);rows.append(now)
  if now!=dep:drift.append(dict(receipt=str(f),compiled=dep,current=now))
 receipts.append(dict(receipt=ident(f),object=d['object'],dependency_count=len(rows),source=d['source']))
assert not drift,drift
save(S/'compiled-current-dependencies.json',dict(actual_current_new_object_count=len(receipts),objects=receipts,source_dependency_drift=drift,reused_baseline='grouped-fp8-power2-reference/vulkan/checks/none-rne/link-plan.json',whole_SDK_current_claim=False))
# Old24 arrays are kept verbatim. No recompilation of old ggml modules occurred.
old=Path(json.loads((S/'checks/attempt1/shaders-identity.json').read_bytes())['replaces']['path']);oldrec=next(json.loads(p.read_bytes()) for p in old.parent.glob('*identity.json') if json.loads(p.read_bytes()).get('object',{}).get('path')==str(old));oldsource=Path(oldrec['source']['path']);newsource=S/'generated/unaligned-load/vulkan_shaders.cc';a=oldsource.read_text();b=newsource.read_text();start=b.index('namespace { constexpr std::uint32_t cache_encode_e4_words[]');end=b.index('} // namespace hyle::compute::vulkan::detail::shaders',start);assert b[:start]+b[end:]==a
save(S/'shader-reuse-proof.json',dict(old_source=ident(oldsource),new_source=ident(newsource),remove_only_new_cache_function_equals_old_source=True,old_HYLE_array_count=24,new_HYLE_array_count=25,new_cache_spv=ident(S/'generated/unaligned-load/cache_encode_e4.spv'),new_page_spv=ident(S/'generated/hyle_flash_attn_e4_fp32.spv'),original_ggml_shader_archive_unchanged=True,old_ggml_shaders_recompiled=0,shared_numerical_created_manifest=ident(S/'e4-source-manifest.json')))
commands=[]
for p in (S/'checks').rglob('*-command.json'):
 d=json.loads(p.read_bytes());assert d['exit_code']==0;cmd=d['command'];typ='link' if Path(cmd[0]).name.lower()=='link.exe' else 'CXX' if Path(cmd[0]).name.lower()=='cl.exe' else 'shader';commands.append(dict(type=typ,receipt=ident(p),exit_code=d['exit_code']))
counts={t:sum(x['type']==t for x in commands) for t in ['CXX','link','shader']};save(S/'build-summary.json',dict(counts=counts,commands=commands,SDK_builds=0,GPU_executions_by_this_agent=0,notes=['HYLE CXX uses /W4 /WX; vendor driver retains its original C++17 flags.','Intermediate successful images and setup/lifetime fixture failures are preserved; only root executed GPU tests.']))
p=subprocess.run(['git','diff','--check','--',*owned,*rootowned],capture_output=True,text=True);save(S/'diff-check.json',dict(command=['git','diff','--check','--',*owned,*rootowned],exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0
print('frozen',len(files),'current-new-objects',len(receipts),'build',counts)
