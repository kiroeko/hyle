from pathlib import Path
import json,hashlib,subprocess
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/vulkan';p=R/'cmake/HyleDependencyLock.json';raw=p.read_bytes();doc=json.loads(raw);rows=doc['dependencies'];row=next(x for x in rows if x['name']=='ggml_vulkan_runtime_patches');before=json.loads(json.dumps(row));manifest=''
for f in sorted((R/'third_party/ggml_vulkan_runtime').rglob('*')):
 if f.is_file():
  rel=f.relative_to(R/'third_party/ggml_vulkan_runtime').as_posix();manifest+=rel+'|'+hashlib.sha256(f.read_bytes().replace(b'\r\n',b'\n')).hexdigest()+'\n'
newtree=hashlib.sha256(manifest.encode()).hexdigest();notice=next(x for x in row['license']['files'] if x['path'].endswith('NOTICE.md'));newnotice=hashlib.sha256((R/notice['path']).read_bytes().replace(b'\r\n',b'\n')).hexdigest();text=raw.decode();assert text.count(row['vendored']['tree_sha256'])==1 and text.count(notice['sha256'])==1;text=text.replace(row['vendored']['tree_sha256'],newtree).replace(notice['sha256'],newnotice);p.write_bytes(text.encode());after=json.loads(p.read_bytes());assert [x for x in rows if x['name']!=row['name']]==[x for x in after['dependencies'] if x['name']!=row['name']];(S/'dependency-entry-update.json').write_text(json.dumps(dict(entry=row['name'],before=before,after=next(x for x in after['dependencies'] if x['name']==row['name']),all_other_entries_field_equal=True),indent=2)+'\n');(S/'check-lock.cmake').write_text('include("'+(R/'cmake/HyleDependencyVersions.cmake').as_posix()+'")\nhyle_audit_in_tree_dependencies(ggml_vulkan_runtime_patches)\n');res=subprocess.run(['cmake','-P',str(S/'check-lock.cmake')],capture_output=True,text=True);(S/'check-lock-result.json').write_text(json.dumps(dict(command=['cmake','-P',str(S/'check-lock.cmake')],exit_code=res.returncode,stdout=res.stdout,stderr=res.stderr),indent=2)+'\n');print('tree',newtree,'audit',res.returncode);assert res.returncode==0,res.stderr
# Check canonical patch replay without materializing a complete dependency copy.
up=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424');proof=[]
for item in json.loads((R/'third_party/ggml_vulkan_runtime/patches.json').read_bytes())['files']:
 b=(up/item['path']).read_bytes().replace(b'\r\n',b'\n');assert hashlib.sha256(b).hexdigest()==item['before_sha256']
 for e in item['edits']:
  a,c=e['before'].encode(),e['after'].encode();assert b.count(a)==1,(item['path'],a[:40]);b=b.replace(a,c,1)
 assert hashlib.sha256(b).hexdigest()==item['after_sha256'];stage=S/'current-patch-source'/item['path'];proof.append(dict(path=item['path'],sha256=item['after_sha256'],compiled_current_source_equal=stage.read_bytes()==b if stage.exists() else None))
(S/'canonical-patch-replay.json').write_text(json.dumps(dict(upstream=str(up),files=proof,whole_dependency_copy=False),indent=2)+'\n');print('replayed',len(proof))
