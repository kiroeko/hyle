from pathlib import Path
import json,hashlib
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/vulkan';S.mkdir(parents=True,exist_ok=True)
files=['src/compute_provider_ggml_vulkan/region.h','src/compute_provider_ggml_vulkan/region.cc','src/compute_provider_ggml_vulkan/native_bridge.h','src/compute_route_vulkan/vulkan_batch.cc','src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_tensor.cc','src/compute_route_vulkan/build_shaders.py','src/compute_ggml_runtime/CMakeLists.txt','third_party/ggml_vulkan_runtime/patches.json']
for p in files:
 d=S/'before'/p;d.parent.mkdir(parents=True,exist_ok=True)
 if not d.exists():d.write_bytes((R/p).read_bytes())

def edit(p,a,b):
 p=R/p;raw=p.read_bytes();s=raw.decode().replace('\r\n','\n');assert s.count(a)==1,(p,a[:80],s.count(a));s=s.replace(a,b);p.write_bytes(s.replace('\n','\r\n' if b'\r\n' in raw else '\n').encode())
edit('src/compute_provider_ggml_vulkan/region.h','  bool compact_mla = false;','  bool compact_mla = false;\n  // Ordinary E4 cache bytes have independent immutable F32 scales.\n  bool float8_cache = false;\n  float key_scale = 1.0F;\n  float value_scale = 1.0F;')
edit('src/compute_provider_ggml_vulkan/region.h','0x5041474544524401ULL','0x5041474544524402ULL')
edit('src/compute_provider_ggml_vulkan/native_bridge.h','inline constexpr std::int32_t kFlashAttentionCache = 0x48594348;', '''inline constexpr std::int32_t kFlashAttentionCache = 0x48594348;
// Slot11 belongs to the managed batch runtime request index.
inline constexpr std::size_t kFlashAttentionStorageSlot = 12;
inline constexpr std::int32_t kFlashAttentionE4M3 = 0x48594534;
inline constexpr std::size_t kFlashAttentionKeyScaleSlot = 13;
inline constexpr std::size_t kFlashAttentionValueScaleSlot = 14;''')
edit('src/compute_route_vulkan/vulkan_batch.cc','  return (plain||q8) &&','  const bool e4=c.key_storage.data_type()==DataType::kFloat8E4M3FN &&\n      c.value_storage.data_type()==DataType::kFloat8E4M3FN;\n  return (plain||q8||e4) &&')
edit('src/compute_route_vulkan/vulkan_batch.cc','    const bool mla=recipe.schema().mla_layout()!=MlaCacheLayout::kNone;','''    const bool mla=recipe.schema().mla_layout()!=MlaCacheLayout::kNone;
    const bool e4=c.key_storage.data_type()==DataType::kFloat8E4M3FN;
    if(mla && e4)return std::unexpected(Status::Unimplemented("Vulkan E4 requires ordinary separate K/V cache"));''')
edit('src/compute_route_vulkan/vulkan_batch.cc','.runtime_request=request.index,.compact_mla=mla});','.runtime_request=request.index,.compact_mla=mla,.float8_cache=e4,\n          .key_scale=c.key_storage.scale(),.value_scale=c.value_storage.scale()});')
edit('src/compute_route_vulkan/vulkan_program.cc','          if (!scale && !storage && !gathered_storage && !static_weight)','''          const auto paged = step.operation.custom_as<ggml_vulkan::detail::PagedAttentionRead>();
          const bool cache = (port == 1 || port == 2) && paged && paged->paged &&
                             !paged->compact_mla && paged->float8_cache;
          if (!scale && !storage && !gathered_storage && !static_weight && !cache)''')
edit('src/compute_route_vulkan/vulkan_program.cc','            step.operation.kind() != OperationKind::kGather)\n          return','''            step.operation.kind() != OperationKind::kGather &&
            !step.operation.custom_as<model_ops::CacheEncode>())
          return''')
# This file already includes region.h through vulkan_internal.
edit('src/compute_provider_ggml_vulkan/region.cc','  if (type == DataType::kUInt8)\n    return GGML_TYPE_I8;','  if (type == DataType::kUInt8 || type == DataType::kFloat8E4M3FN)\n    return GGML_TYPE_I8;')
edit('src/compute_provider_ggml_vulkan/region.cc','  if(compact_mla){','  if(compact_mla){\n    if(float8_cache)return Status::Unimplemented("Vulkan compact MLA has no E4 storage contract");')
edit('src/compute_provider_ggml_vulkan/region.cc','  if (!inputs[0].is_plain() || (query_type != DataType::kFloat16 && !bfloat) ||\n      (!plain && !encoded) ||','''  const auto e4_key=CacheStorage::float8(key_scale),e4_value=CacheStorage::float8(value_scale);
  const bool e4 = paged && float8_cache && e4_key && e4_value &&
      inputs[1].is_plain() && inputs[2].is_plain() &&
      inputs[1].is_dense() && inputs[2].is_dense() &&
      inputs[1].data_type()==DataType::kFloat8E4M3FN &&
      inputs[2].data_type()==DataType::kFloat8E4M3FN;
  if (!inputs[0].is_plain() || (query_type != DataType::kFloat16 && !bfloat) ||
      (!plain && !encoded && !e4) || (float8_cache && !e4) ||''')
edit('src/compute_provider_ggml_vulkan/region.cc','  for (std::size_t port = 0; port < inputs.size(); ++port)\n    if (!tensor_domain(inputs[port]) &&\n        !(grouped && port == 1 && grouped_activation_domain(inputs[port])))','''  const auto paged_read=operation.custom_as<PagedAttentionRead>();
  for (std::size_t port = 0; port < inputs.size(); ++port)
    if (!tensor_domain(inputs[port]) &&
        !(paged_read && paged_read->float8_cache && (port==1 || port==2) &&
          inputs[port].is_dense() && inputs[port].data_type()==DataType::kFloat8E4M3FN) &&
        !(grouped && port == 1 && grouped_activation_domain(inputs[port])))''')
edit('src/compute_provider_ggml_vulkan/region.cc','    std::vector<bool> available(recipe.values.size(), false);','''    // Raw E4 is admitted only when every consuming port is a typed page read.
    const auto cache_input=[&](std::uint32_t value){
      if(!recipe.values[value].is_dense() || recipe.values[value].data_type()!=DataType::kFloat8E4M3FN)
        return false;
      bool read=false;
      for(const auto& node:recipe.nodes)for(std::size_t port=0;port<node.inputs.size();++port)
        if(node.inputs[port]==value){
          const auto page=node.operation.custom_as<PagedAttentionRead>();
          if(!page || !page->paged || page->compact_mla || !page->float8_cache || (port!=1 && port!=2))return false;
          read=true;
        }
      return read;
    };
    std::vector<bool> available(recipe.values.size(), false);''')
edit('src/compute_provider_ggml_vulkan/region.cc','           !grouped_activation_domain(recipe.values[input])))','           !grouped_activation_domain(recipe.values[input]) && !cache_input(input)))')
edit('src/compute_provider_ggml_vulkan/region.cc','        output->op_params[kBatchRuntimeRequestSlot] = paged->runtime_request == UINT32_MAX','''        output->op_params[bridge::kFlashAttentionStorageSlot] = paged->float8_cache ? bridge::kFlashAttentionE4M3 : 0;
        std::memcpy(&output->op_params[bridge::kFlashAttentionKeyScaleSlot], &paged->key_scale, sizeof(float));
        std::memcpy(&output->op_params[bridge::kFlashAttentionValueScaleSlot], &paged->value_scale, sizeof(float));
        output->op_params[kBatchRuntimeRequestSlot] = paged->runtime_request == UINT32_MAX''')
print('source edits ready')
