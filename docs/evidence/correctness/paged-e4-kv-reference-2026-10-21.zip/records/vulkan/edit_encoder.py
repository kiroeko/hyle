from pathlib import Path
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/vulkan'
def edit(p,a,b):
 p=R/p;raw=p.read_bytes();s=raw.decode().replace('\r\n','\n');assert s.count(a)==1,(p,a[:60],s.count(a));p.write_bytes(s.replace(a,b).replace('\n','\r\n' if b'\r\n' in raw else '\n').encode())
edit('src/compute_route_vulkan/vulkan_tensor.cc','  if(!encode || encode->storage!=CacheStorage::q8_0().value())\n    return Status::Unimplemented("Vulkan cache encoder admits Q8_0 storage");','''  if(!encode)return Status::InvalidArgument("Vulkan cache encoder operation");
  const bool e4=encode->storage.data_type()==DataType::kFloat8E4M3FN;
  if(!e4 && encode->storage!=CacheStorage::q8_0().value())
    return Status::Unimplemented("Vulkan cache encoder admits Q8_0 or scalar E4 storage");''')
edit('src/compute_route_vulkan/vulkan_tensor.cc','  HYLE_ASSIGN_OR_RETURN(auto safe_desc,TensorDesc::dense(DataType::kFloat32,input.dimensions()));','''  if(e4){
    if(!input.is_dense() || !tensor_storage_type(input.data_type()) ||
       *tensor_storage_type(input.data_type())>2)
      return Status::Unimplemented("Vulkan E4 cache encoder needs dense F32/F16/BF16");
    if(!program.status_value){HYLE_ASSIGN_OR_RETURN(auto status,TensorDesc::dense(DataType::kInt32,{}));program.status_value=append(status);}
    std::array<SpecializationConstant,42> specialization{};Dispatch dispatch;
    HYLE_RETURN_IF_ERROR(tensor_layout(program,step.inputs,step.outputs[0],specialization,dispatch));
    specialization[7].value=std::bit_cast<std::uint32_t>(encode->storage.scale());
    dispatch.values[2]=*program.status_value;dispatch.checked_status=true;
    return append_tensor_dispatch(program,std::move(dispatch),shaders::cache_encode_e4(),specialization,
        static_cast<std::uint32_t>(((count+3)/4+127)/128));
  }
  HYLE_ASSIGN_OR_RETURN(auto safe_desc,TensorDesc::dense(DataType::kFloat32,input.dimensions()));''')
edit('src/compute_route_vulkan/build_shaders.py',"    variants = [","    variants = [\n        ('cache_encode_e4', str((args.tensor_source / 'cache_encode_e4.comp').resolve()), {}, {1}),")
edit('src/compute_route_vulkan/build_shaders.py',"        if name in ('nvfp4', 'nvfp4_grouped'","        if name in ('cache_encode_e4', 'nvfp4', 'nvfp4_grouped'")
edit('src/compute_route_vulkan/build_shaders.py',"            if name in ('ct_packed', 'ct_packed_grouped'","            if name in ('cache_encode_e4', 'ct_packed', 'ct_packed_grouped'")
edit('src/compute_route_vulkan/build_shaders.py',"            marker = ('// HYLE_BLOCKWISE_W4A8_F32_SOURCE'","            marker = ('// HYLE_CACHE_E4_F32_SOURCE' if name == 'cache_encode_e4' else\n                      '// HYLE_BLOCKWISE_W4A8_F32_SOURCE'")
