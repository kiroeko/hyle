from pathlib import Path
import hashlib,json,difflib,xml.etree.ElementTree as E
ROOT=Path.cwd();S=ROOT/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/apple';R=S/'mac/remote';O=R/'results'
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,o):Path(p).write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
owned=['src/compute_route_apple/apple_batch.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_static_fp8.cc','src/compute_route_apple/apple_static_fp8.h','third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md']
shared=['tests/compute_models/paged_e4_kv_fixture.h','tests/graph_route_apple/paged_e4_kv_test.cc','tests/compute_batch/encoded_page_native_consumer.cc','tests/graph_route_apple/CMakeLists.txt']
for rel in owned+shared:
 p=S/'after'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/rel).read_bytes())
 if(S/'before'/rel).is_file():
  b=(S/'before'/rel).read_text(encoding='utf-8');a=(ROOT/rel).read_text(encoding='utf-8');(S/(rel.replace('/','--')+'.diff')).write_text(''.join(difflib.unified_diff(b.splitlines(keepends=True),a.splitlines(keepends=True),fromfile=rel+' before',tofile=rel+' after')),encoding='utf-8')
freeze=dict(owned=[identity(ROOT/x)for x in owned],shared=[identity(ROOT/x)for x in shared],native_freeze=identity(S/'native-source-freeze.json'),MLX_vendor=identity(S/'mlx-vendored-identity.json'),public_API_changes=False,
  native_owners=['mlx/fast.cpp','mlx/backend/metal/scaled_dot_product_attention.cpp','generated mlx::core::metal::steel_attention() C++ string'],
  reuse='Old plain/Q8 function signatures preserved; private HylePagedAttention cold state has E4 tag and two scales; actual constructor/eval owners refreshed together. Original AttnParams unchanged.',
  numerical_source='Encoder and direct page loaders reuse the existing raw IEEE F32 helper; E4 full Steel uses F32 query/tile/probabilities and one final F16/BF16 conversion. No whole-cache float bank.',
  new_executor=False,full_SDK_build=False,metallib_rebuilt=False,new_performance_claim=False)
save(S/'source-freeze.json',freeze)
manifest=read(S/'mac/source-manifest.json');bad=[]
for row in manifest:
 p=S/'native-after'/row['path'][7:]if row['path'].startswith('native/')else ROOT/row['path']
 if identity(p)['sha256']!=row['sha256']:bad.append(str(p))
assert not bad,bad
compiles=read(O/'compile-summary.json')['compiles'];assert len(compiles)==8 and all(x['exit']==0 and not x['source_drifts']for x in compiles)
for row in compiles:
 p=Path(row['source']['path']);logical=next(x['source']for x in read(S/'mac/plan.json')['compile']if x['object']==row['object']) if False else None
first=R/'first-pass-e4-only';newcases=E.parse(first/'tests.xml').getroot().findall('.//testcase');neighbors=E.parse(O/'tests.xml').getroot().findall('.//testcase')
assert len(newcases)==4 and len(neighbors)==2
assert all(not x.findall('failure')and not x.findall('skipped')for x in newcases+neighbors)
assert read(first/'run.result.json')['exit']==0 and read(O/'run.result.json')['exit']==0
# Product and native objects in the original E4 image and final neighbor image must be identical.
first_inputs={x['path']:x for x in read(first/'link-inputs.json')};last_inputs={x['path']:x for x in read(O/'link-inputs.json')}
for row in compiles:
 if row['source']['path'].endswith('encoded_page_native_consumer.cc'):continue
 assert first_inputs[row['object']]==last_inputs[row['object']]==row['object_identity'],row['object']
validation=dict(status='actual_Mac16_12_Metal_pass',source_freeze=identity(S/'source-freeze.json'),canonical_remote_files=len(manifest),all_source_hashes_current=True,
 new_tests=4,neighbor_tests=2,tests=6,failed=0,skipped=0,successful_new_submissions=16,expected_new_failed_completions=1,
 cases=[dict(name=x.get('classname')+'.'+x.get('name'),classification='new'if x in newcases else'neighbor')for x in newcases+neighbors],
 builds=[dict(source=x['source'],object=x['object_identity'],exit=x['exit'],dependency_count=len(x['dependencies']),source_drifts=x['source_drifts'])for x in compiles],
 new_run=identity(first/'run.result.json'),new_gtest=identity(first/'tests.xml'),neighbor_run=identity(O/'run.result.json'),neighbor_gtest=identity(O/'tests.xml'),final_link=identity(O/'link.result.json'),new_and_neighbor_product_objects_exactly_same=True,
 hardware=identity(R/'hardware.json'),runtime=identity(R/'runtime-identity.json'),commands='mac/remote/results/*command.json; first-pass-e4-only/run.command.json',
 first_failures=[dict(path='mac/remote/attempt1-native-generated-pedantic',reason='Reviewer-added pedantic/Werror rejected original-style >65536-byte generated C++ string; original baseline was already 70593 bytes. Generated TU resumed actual SDK recipe, product and host strict recipes retained.'),dict(path='mac/remote/first-q8-combined-capacity-failure',reason='Shared old combined Q8 fixture allocated its second output before replacing the first with only one pool block. Root fixed explicit two-buffer pool; only this test TU recompiled; original oracle/producer checks unchanged.')],
 costs=['Only dirty source encoder output/status arrays are allocated by the new encoder; status is reduced through the original Completion family.','Active Q/Y converted through original F32 Cast path. Original Steel tile-local E4 decode/scale; no physical cache-sized floating expansion.','Pipeline specialization includes exact two U32 scalar bits. E4 has a distinct native library/base name so old precompiled plain/Q8 kernels cannot be reused accidentally.'],
 scope=['Ordinary paged finite E4 storage, fixed independent K/V scales, original page16 arena permissions and warm original reader update.','Three source floating dtypes, signed-zero/midpoint and positive subnormal/extreme scale exact encoder byte witnesses; nonfinite failure has no result and fresh recovery succeeds.','BF16 Q4/KVH2 D64/V128, two requests histories17/31 and nonidentity/repeated physical pages; independent scalar oracle and wrong-scale witnesses.','Two slots, true Q1 layout growth plus byte-identical fresh invocation, retained output prevents prepare and survives invocation/executable destruction.','Two original Q8 pending producer neighbor cases passed after fixture capacity repair: four success episodes, paired/separate and native/CPU+GPU failure retirement.'],
 limitations=['No compact MLA or whole-model import is claimed.','No throughput measurement or arbitrary-scale attention bitwise equivalence is claimed.','New ordinary attention result uses original F32 Steel reduction tree and existing tolerance; exact scalar encoder bytes are tested independently.'])
save(S/'final-validation.json',validation)
review=dict(scope=['region.h/.cc private E4 port admission and metadata','ggml-vulkan.cpp FullF32 E4 selection and key/spec16/17','flash_attn.comp E4 raw U32 vector load and shared IEEE scale'],result='No concrete source blocker found in finite review.',address_alignment='Peer source-owner proof: Dk/Dv64/128/256 and page16 dense geometry make head/pitch/vector offsets multiples of4; paged MemoryAccess root origin%4 is checked. Reader does not need the encoder generic cross-word byte loader.',warm='Same original flash node receives mutable logical extent/table offset; E4 storage tag/scales remain immutable metadata and pipeline identity.',reviewer_builds=0,reviewer_GPU_runs=0,performance_claim=False)
save(S/'vulkan-independent-source-review.json',review)
print(json.dumps(dict(freeze=identity(S/'source-freeze.json'),validation=identity(S/'final-validation.json'),new=4,neighbors=2,compiles=8,source_drift=bad),indent=2))