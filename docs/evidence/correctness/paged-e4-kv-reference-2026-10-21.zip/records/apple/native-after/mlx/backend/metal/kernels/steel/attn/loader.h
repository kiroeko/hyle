// Copyright © 2024 Apple Inc.

#pragma once

#include "mlx/backend/metal/kernels/steel/defines.h"

///////////////////////////////////////////////////////////////////////////////
// Loading helper
///////////////////////////////////////////////////////////////////////////////

namespace mlx {
namespace steel {

// HYLE fixed-scale page loads share the exact private F32 numerical source.
// Origin: src/compute_shader_shared/nvfp4_f32.h and apple_static_fp8.cc.
inline uint hyle_mul_hi(uint a, uint b) { return uint((ulong(a) * ulong(b)) >> 32); }
inline uint hyle_clz(uint a) { return clz(a); }

uint hyle_shift_jam(uint value, uint distance) {
  if (distance == 0u) return value;
  if (distance >= 32u) return uint(value != 0u);
  return (value >> distance) | uint((value << (32u-distance)) != 0u);
}

uint hyle_f32_pack(uint sign, int exponent, uint significand) {
  if (significand == 0u) return sign;
  if (significand >= 0x08000000u) {
    significand = hyle_shift_jam(significand,1u);
    ++exponent;
  }
  while (significand < 0x04000000u && exponent > 1) {
    significand <<= 1u;
    --exponent;
  }
  if (exponent < 1) {
    significand = hyle_shift_jam(significand,uint(1-exponent));
    exponent = 1;
  }
  uint tail = significand & 7u;
  uint rounded = (significand >> 3u) +
      uint(tail > 4u || (tail == 4u && (significand & 8u) != 0u));
  if (rounded >= 0x01000000u) {
    rounded >>= 1u;
    ++exponent;
  }
  if (exponent >= 255) return sign | 0x7f800000u;
  uint field = exponent == 1 && rounded < 0x00800000u ? 0u : uint(exponent);
  return sign | (field << 23u) | (rounded & 0x007fffffu);
}

struct HyleF32Parts { uint significand; int exponent; };
HyleF32Parts hyle_f32_parts(uint bits) {
  HyleF32Parts value;
  value.significand = bits & 0x007fffffu;
  value.exponent = int((bits >> 23u) & 255u);
  if (value.exponent != 0) value.significand |= 0x00800000u;
  else {
    uint shift = hyle_clz(value.significand)-8u;
    value.significand <<= shift;
    value.exponent = 1-int(shift);
  }
  return value;
}

uint hyle_f32_nan(uint a, uint b) {
  if ((a & 0x7fffffffu) > 0x7f800000u) return a | 0x00400000u;
  if ((b & 0x7fffffffu) > 0x7f800000u) return b | 0x00400000u;
  return 0x7fc00000u;
}

uint hyle_f32_mul(uint a, uint b) {
  uint sign = (a ^ b) & 0x80000000u;
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa >= 0x7f800000u || bb >= 0x7f800000u) {
    if (aa > 0x7f800000u || bb > 0x7f800000u || aa == 0u || bb == 0u)
      return hyle_f32_nan(a,b);
    return sign | 0x7f800000u;
  }
  if (aa == 0u || bb == 0u) return sign;
  HyleF32Parts left = hyle_f32_parts(a), right = hyle_f32_parts(b);
  uint low = left.significand * right.significand;
  uint high = hyle_mul_hi(left.significand,right.significand);
  uint extended = (high << 12u) | (low >> 20u) | uint((low & 0x000fffffu) != 0u);
  return hyle_f32_pack(sign,left.exponent+right.exponent-127,extended);
}

uint hyle_f32_div(uint a, uint b) {
  uint sign = (a ^ b) & 0x80000000u;
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa > 0x7f800000u || bb > 0x7f800000u ||
      (aa == 0x7f800000u && bb == 0x7f800000u) || (aa == 0u && bb == 0u))
    return hyle_f32_nan(a,b);
  if (aa == 0x7f800000u || bb == 0u) return sign | 0x7f800000u;
  if (aa == 0u || bb == 0x7f800000u) return sign;
  HyleF32Parts left = hyle_f32_parts(a), right = hyle_f32_parts(b);
  int exponent = left.exponent-right.exponent+127;
  uint remainder = left.significand, quotient = 0u;
  if (remainder < right.significand) {
    remainder <<= 1u;
    --exponent;
  }
  for (uint bit = 0u; bit < 27u; ++bit) {
    uint next = uint(remainder >= right.significand);
    if (next != 0u) remainder -= right.significand;
    quotient = (quotient << 1u) | next;
    if (bit != 26u) remainder <<= 1u;
  }
  quotient |= uint(remainder != 0u);
  return hyle_f32_pack(sign,exponent,quotient);
}

uint hyle_f32_add(uint a, uint b) {
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa >= 0x7f800000u || bb >= 0x7f800000u) {
    if (aa > 0x7f800000u || bb > 0x7f800000u ||
        (aa == 0x7f800000u && bb == 0x7f800000u && ((a ^ b) & 0x80000000u) != 0u))
      return hyle_f32_nan(a,b);
    return aa == 0x7f800000u ? a : b;
  }
  if (aa == 0u && bb == 0u) return (a & b) & 0x80000000u;
  if (aa == 0u) return b;
  if (bb == 0u) return a;
  // Larger magnitude first keeps subtraction nonnegative, including zeros.
  if (aa < bb) { uint temporary=a; a=b; b=temporary; }
  uint ea = (a >> 23u) & 255u, eb = (b >> 23u) & 255u;
  uint left = (a & 0x007fffffu) | (ea == 0u ? 0u : 0x00800000u);
  uint right = (b & 0x007fffffu) | (eb == 0u ? 0u : 0x00800000u);
  ea = ea == 0u ? 1u : ea;
  eb = eb == 0u ? 1u : eb;
  left <<= 3u;
  right = hyle_shift_jam(right << 3u,ea-eb);
  uint result = ((a ^ b) & 0x80000000u) == 0u ? left+right : left-right;
  // Exact cancellation under round-to-nearest produces positive zero.
  if (result == 0u) return 0u;
  return hyle_f32_pack(a & 0x80000000u,int(ea),result);
}

    inline uint hyle_e4_to_f32(uint code) {
      const uint sign = (code & 128u) << 24u, magnitude = code & 127u;
      const uint exponent = magnitude >> 3u, mantissa = magnitude & 7u;
      if (magnitude == 127u) return sign | 0x7fc00000u;
      if (exponent != 0u)
        return sign | ((exponent + 120u) << 23u) | (mantissa << 20u);
      if (mantissa == 0u) return sign;
      const uint leading = 31u - hyle_clz(mantissa);
      return sign | ((leading + 118u) << 23u) |
          ((mantissa << (23u - leading)) & 0x7fffffu);
    }


template <
    typename T,
    short BROWS,
    short BCOLS,
    short dst_ld,
    short reduction_dim,
    short tgp_size,
    short alignment = 1,
    short n_reads = (BCOLS * BROWS) / (tgp_size),
    short TCOLS = BCOLS / n_reads,
    short TROWS = tgp_size / TCOLS>
struct BlockLoader {
  STEEL_CONST short n_rows = (BROWS + TROWS - 1) / TROWS;
  STEEL_CONST short vec_size = n_reads;

  // Leading dimension for src
  const int src_ld;
  const int tile_stride;

  // Thread location indices
  const short thread_idx;
  const short bi;
  const short bj;

  // threadgroup and device memory
  threadgroup T* dst;
  const device T* src;

  struct alignas(alignment * sizeof(T)) ReadVector {
    uint8_t v[sizeof(T) * vec_size];
  };

  /* Constructor */
  METAL_FUNC BlockLoader(
      const device T* src_,
      const int src_ld_,
      threadgroup T* dst_,
      ushort simd_group_id [[simdgroup_index_in_threadgroup]],
      ushort simd_lane_id [[thread_index_in_simdgroup]]) thread
      : src_ld(src_ld_),
        tile_stride(reduction_dim ? BCOLS : BROWS* src_ld),
        thread_idx(simd_group_id * 32 + simd_lane_id),
        bi(thread_idx / TCOLS),
        bj(vec_size*(thread_idx % TCOLS)),
        dst(dst_ + bi * dst_ld + bj),
        src(src_ + bi * src_ld + bj) {}

  /* Apply operation to threadgroup without bound checking */
  template <typename UnaryOp>
  METAL_FUNC void apply_inplace_op(thread const UnaryOp& op) const thread {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        dst[i * dst_ld + j] = op.apply(dst[i * dst_ld + j]);
      }
    }
  }

  /* Load from device memory into threadgroup memory - without bound checking */
  METAL_FUNC void load_unsafe() const thread {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      *((threadgroup ReadVector*)(&dst[i * dst_ld])) =
          *((const device ReadVector*)(&src[i * src_ld]));
    }
  }

  /* Load from device memory into threadgroup memory - with bound checking */
  METAL_FUNC void load_safe(short2 src_tile_dim) const thread {
    src_tile_dim = src_tile_dim - short2(bj, bi);

    // Skip loading if thread has no valid reads
    if (src_tile_dim.x <= 0 || src_tile_dim.y <= 0) {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j++) {
          dst[i * dst_ld + j] = T(0);
        }
      }
      return;
    }

    // Use fast thread memory for bound checks
    bool tmp_idx[vec_size];
    T tmp_val[vec_size];

    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      // Make sure tmp_idx only contains valid indices
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_idx[j] = (i < src_tile_dim.y) && (j < src_tile_dim.x);
      }

      // Read valid indices into tmp_val
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_val[j] = src[(tmp_idx[j] ? i * src_ld + j : 0)];
      }

      // Zero out unneeded values
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_val[j] = tmp_idx[j] ? tmp_val[j] : T(0);
      }

      // Copy values to threadgroup memory
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        dst[i * dst_ld + j] = tmp_val[j];
      }
    }
  }

  /* Iteration helper */
  METAL_FUNC void next() thread {
    src += tile_stride;
  }
};

template <int R, int C>
struct CShape {
  STEEL_CONST int kRows = R;
  STEEL_CONST int kCols = C;
};

template <
    typename T,
    short BROWS,
    short BCOLS,
    short kDstStrRow,
    short kDstStrCol,
    short reduction_dim,
    short tgp_size,
    short n_reads = (BCOLS * BROWS) / (tgp_size),
    short TCOLS = BCOLS / n_reads,
    short TROWS = tgp_size / TCOLS>
struct BlockLoaderT {
  STEEL_CONST short n_rows = (BROWS + TROWS - 1) / TROWS;
  STEEL_CONST short vec_size = n_reads;

  // Leading dimension for src
  const int src_ld;
  const int tile_stride;

  // Thread location indices
  const short thread_idx;
  const short bi;
  const short bj;

  // threadgroup and device memory
  threadgroup T* dst;
  const device T* src;

  /* Constructor */
  METAL_FUNC BlockLoaderT(
      const device T* src_,
      const int src_ld_,
      threadgroup T* dst_,
      ushort simd_group_id [[simdgroup_index_in_threadgroup]],
      ushort simd_lane_id [[thread_index_in_simdgroup]]) thread
      : src_ld(src_ld_),
        tile_stride(reduction_dim ? BCOLS : BROWS* src_ld),
        thread_idx(simd_group_id * 32 + simd_lane_id),
        bi(thread_idx / TCOLS),
        bj(vec_size*(thread_idx % TCOLS)),
        dst(dst_ + bi * kDstStrRow + bj * kDstStrCol),
        src(src_ + bi * src_ld + bj) {}

  /* Apply operation to threadgroup without bound checking */
  template <typename UnaryOp>
  METAL_FUNC void apply_inplace_op(thread const UnaryOp& op) const thread {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        dst[i * kDstStrRow + j * kDstStrCol] =
            op.apply(dst[i * kDstStrRow + j * kDstStrCol]);
      }
    }
  }

  /* Load from device memory into threadgroup memory - without bound checking */
  METAL_FUNC void load_unsafe() const thread {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        dst[i * kDstStrRow + j * kDstStrCol] = src[i * src_ld + j];
      }
    }
  }

  /* Load from device memory into threadgroup memory - with bound checking */
  METAL_FUNC void load_safe(short2 src_tile_dim) const thread {
    src_tile_dim = src_tile_dim - short2(bj, bi);

    // Skip loading if thread has no valid reads
    if (src_tile_dim.x <= 0 || src_tile_dim.y <= 0) {
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j++) {
          dst[i * kDstStrRow + j * kDstStrCol] = T(0);
        }
      }
      return;
    }

    // Use fast thread memory for bound checks
    bool tmp_idx[vec_size];
    T tmp_val[vec_size];

    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      // Make sure tmp_idx only contains valid indices
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_idx[j] = (i < src_tile_dim.y) && (j < src_tile_dim.x);
      }

      // Read valid indices into tmp_val
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_val[j] = src[(tmp_idx[j] ? i * src_ld + j : 0)];
      }

      // Zero out unneeded values
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        tmp_val[j] = tmp_idx[j] ? tmp_val[j] : T(0);
      }

      // Copy values to threadgroup memory
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        dst[i * kDstStrRow + j * kDstStrCol] = tmp_val[j];
      }
    }
  }

  METAL_FUNC void load_paged(const device T* root, const device int* pages,
      const int offset, const int first, const int valid_rows) const thread {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      const int logical = first + bi + i;
      const bool valid = bi + i < valid_rows;
      const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        dst[i * kDstStrRow + j * kDstStrCol] = valid ? root[physical * src_ld + bj + j] : T(0);
      }
    }
  }

  METAL_FUNC void load_e4(const device uchar* root, const device int* pages,
      const int offset, const int first, const int valid_rows,
      const uint scale_bits) const thread {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      const int logical = first + bi + i;
      const bool valid = bi + i < valid_rows;
      const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        // Guard the actual page load; inactive history never supplies a value.
        dst[i * kDstStrRow + j * kDstStrCol] = valid ?
            T(as_type<float>(hyle_f32_mul(hyle_e4_to_f32(root[physical * src_ld + bj + j]), scale_bits))) : T(0);
      }
    }
  }

  METAL_FUNC void load_q8(const device uchar* root, const device int* pages,
      const int offset, const int first, const int valid_rows) const thread {
    // Each aligned complete or partial 32-element code block shares one scale. Do not reconstruct
    // its address/scale independently for every element in the block.
    if constexpr (BCOLS % 32 == 0 && (vec_size % 32 == 0 || 32 % vec_size == 0)) {
      constexpr short block_reads = vec_size < 32 ? vec_size : 32;
      STEEL_PRAGMA_UNROLL
      for (short i = 0; i < BROWS; i += TROWS) {
        const bool valid = bi + i < valid_rows;
        const int logical = first + bi + i;
        const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
        STEEL_PRAGMA_UNROLL
        for (short j = 0; j < vec_size; j += block_reads) {
          if (valid) {
            const device uchar* block = root + physical * src_ld + ((bj + j) / 32) * 34;
            const ushort bits = ushort(block[0]) | (ushort(block[1]) << 8);
            const float scale = float(as_type<half>(bits));
            STEEL_PRAGMA_UNROLL
            for (short k = 0; k < block_reads; ++k)
              dst[i * kDstStrRow + (j + k) * kDstStrCol] = T(scale * float(as_type<char>(block[2 + (bj + j) % 32 + k])));
          } else {
            STEEL_PRAGMA_UNROLL
            for (short k = 0; k < block_reads; ++k)
              dst[i * kDstStrRow + (j + k) * kDstStrCol] = T(0);
          }
        }
      }
      return;
    }
    for (short i = 0; i < BROWS; i += TROWS) {
      const int logical = first + bi + i;
      const bool valid = bi + i < valid_rows;
      const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
      for (short j = 0; j < vec_size; ++j) {
        const int col = bj + j;
        const device uchar* block = root + physical * src_ld + (col / 32) * 34;
        const ushort bits = ushort(block[0]) | (ushort(block[1]) << 8);
        dst[i * kDstStrRow + j * kDstStrCol] = valid ?
            T(float(as_type<half>(bits)) * float(as_type<char>(block[2 + col % 32]))) : T(0);
      }
    }
  }
  /* Iteration helper */
  METAL_FUNC void next() thread {
    src += tile_stride;
  }
};

} // namespace steel
} // namespace mlx
