from pathlib import Path
import json,hashlib,difflib
root=Path.cwd(); p=root/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/apple'
manifest=root/'third_party/mlx_cast/patches.json'
m=json.loads(manifest.read_text(encoding='utf-8'))
changes={}; edits={}
def edit(path,before,after):
 s=changes.get(path,(p/'native-before'/path).read_text(encoding='utf-8'))
 assert s.count(before)==1,(path,s.count(before),before[:90])
 changes[path]=s.replace(before,after);edits.setdefault(path,[]).append({'before':before,'after':after})
f='mlx/fast.h'
s=(p/'native-before'/f).read_text(encoding='utf-8'); pos=s.index('MLX_API array hyle_paged_attention(');end=s.index(';',pos)+1
old=s[pos:end]
edit(f,old,old+'\n// Ordinary E4 cache bytes with independent fixed scalar interpretations.\nMLX_API array hyle_paged_attention(\n    const array& q, const array& k, const array& v, const array& pages,\n    int logical_rows, int table_offset, float scale, bool causal,\n    Stream stream, int window_left, float key_scale, float value_scale);')
f='mlx/fast_primitives.h'
edit(f,'bool q8, int window, bool query_f16)','bool q8, int window, bool query_f16,\n      bool e4 = false, float key_scale = 1.0f, float value_scale = 1.0f)')
edit(f,'window_(window), query_f16_(query_f16) {}','window_(window), query_f16_(query_f16),\n        e4_(e4), key_scale_(key_scale), value_scale_(value_scale) {}')
edit(f,'window_ == p.window_ && query_f16_ == p.query_f16_;','window_ == p.window_ && query_f16_ == p.query_f16_ &&\n           e4_ == p.e4_ && key_scale_ == p.key_scale_ && value_scale_ == p.value_scale_;')
edit(f,'causal_, q8_, window_, query_f16_); }','causal_, q8_, window_, query_f16_, e4_, key_scale_, value_scale_); }')
edit(f,'  bool query_f16_;\n};','  bool query_f16_;\n  bool e4_;\n  float key_scale_, value_scale_;\n};')
f='mlx/fast.cpp'
edit(f,'Stream stream, bool q8, int window) {\n  const int dk','Stream stream, bool q8, int window, bool e4 = false,\n    float key_scale = 1.0f, float value_scale = 1.0f) {\n  const int dk')
edit(f,'(!q8 && (dk == 512 || dk == 576) && dv == 512)','(!q8 && !e4 && (dk == 512 || dk == 576) && dv == 512)')
edit(f,'      (q8 ? (k.dtype() != uint8','      (e4 && (!pages || q8 || !(key_scale > 0.0f) || !(value_scale > 0.0f) ||\n              !std::isfinite(key_scale) || !std::isfinite(value_scale))) ||\n      (q8 ? (k.dtype() != uint8')
edit(f,'k.shape(-1) != dk / 32 * 34 || v.shape(-1) != dv / 32 * 34) :\n            (k.dtype()','k.shape(-1) != dk / 32 * 34 || v.shape(-1) != dv / 32 * 34) :\n       e4 ? (k.dtype() != uint8 || v.dtype() != uint8 || k.shape(-1) != dk) :\n            (k.dtype()')
edit(f,'auto query = q8 ? astype(q, float32, stream) : q;','auto query = (q8 || e4) ? astype(q, float32, stream) : q;')
edit(f,'scale, causal, q8, window, q.dtype() == float16), std::move(inputs));\n  return q8 ?','scale, causal, q8, window, q.dtype() == float16, e4,\n          key_scale, value_scale), std::move(inputs));\n  return (q8 || e4) ?')
needle='array hyle_ragged_attention(const array& q, const array& k, const array& v,'
edit(f,needle,'array hyle_paged_attention(const array& q, const array& k, const array& v,\n    const array& pages, int rows, int offset, float scale, bool causal,\n    Stream stream, int window, float key_scale, float value_scale) {\n  return hyle_cache_attention(q,k,v,pages,rows,offset,scale,causal,stream,\n      false,window,true,key_scale,value_scale);\n}\n'+needle)
f='mlx/backend/metal/scaled_dot_product_attention.cpp'
edit(f,'#include <sstream>','#include <sstream>\n#include <cstdint>\n#include <cstring>')
edit(f,'  bool query_f16;\n};','  bool query_f16;\n  bool e4;\n  float key_scale, value_scale;\n};')
for before in ['const bool highdim_cache = page && !page->q8 &&\n      (q.dtype()', 'const bool highdim_cache = page && !page->q8 &&\n      (q_pre.dtype()']:
 edit(f,before,before.replace('!page->q8 &&','!page->q8 && !page->e4 &&'))
edit(f,'if ((!page || (!page->q8 && page->window == -1)) && v.shape(-1) == D','if ((!page || (!page->q8 && !page->e4 && page->window == -1)) && v.shape(-1) == D')
edit(f,'if (q_pre.shape(2) <= 8 && !highdim_cache) {','if (q_pre.shape(2) <= 8 && !highdim_cache && !(page && page->e4)) {')
edit(f,'  const bool hyle_q8 = page && page->q8;\n  const bool hyle_window = page && page->window >= 0;','  const bool hyle_q8 = page && page->q8;\n  const bool hyle_window = page && page->window >= 0;\n  const bool hyle_e4 = page && page->e4;\n  uint32_t key_scale_bits = 0x3f800000u, value_scale_bits = 0x3f800000u;\n  if (hyle_e4) {\n    std::memcpy(&key_scale_bits, &page->key_scale, sizeof(key_scale_bits));\n    std::memcpy(&value_scale_bits, &page->value_scale, sizeof(value_scale_bits));\n  }')
edit(f,'{&hyle_window, MTL::DataType::DataTypeBool, 305}};','{&hyle_window, MTL::DataType::DataTypeBool, 305}};\n    if (hyle_e4) {\n      func_consts.push_back({&hyle_e4, MTL::DataType::DataTypeBool, 306});\n      func_consts.push_back({&key_scale_bits, MTL::DataType::DataTypeUInt, 307});\n      func_consts.push_back({&value_scale_bits, MTL::DataType::DataTypeUInt, 308});\n    }')
edit(f,'if (half_query) base_name += "_query_half";','if (half_query) base_name += "_query_half";\n    if (hyle_e4) base_name += "_hyle_e4";')
edit(f,'std::to_string(hyle_q8) + "_" + std::to_string(hyle_window);\n\n    return get_steel_attention_kernel(','std::to_string(hyle_q8) + "_" + std::to_string(hyle_window);\n    if (hyle_e4) hash_name += "_e4_" + std::to_string(key_scale_bits) + "_" +\n        std::to_string(value_scale_bits);\n\n    return get_steel_attention_kernel(')
edit(f,'rows_, offset_, q8_, window_, query_f16_});','rows_, offset_, q8_, window_, query_f16_, e4_, key_scale_, value_scale_});')
f='mlx/backend/metal/kernels/steel/attn/loader.h'
shared=(root/'src/compute_shader_shared/nvfp4_f32.h').read_text(encoding='utf-8').split('R"HYLE_SHADER(',1)[1].split(')HYLE_SHADER"',1)[0]
codec=(root/'src/compute_route_apple/apple_static_fp8.cc').read_text(encoding='utf-8')
codec=codec[codec.index('    inline uint hyle_e4_to_f32'):codec.index('    inline uint hyle_f32_to_e4')]
prefix='''// HYLE fixed-scale page loads share the exact private F32 numerical source.
// Origin: src/compute_shader_shared/nvfp4_f32.h and apple_static_fp8.cc.
inline uint hyle_mul_hi(uint a, uint b) { return uint((ulong(a) * ulong(b)) >> 32); }
inline uint hyle_clz(uint a) { return clz(a); }
'''+shared+'\n'+codec+'\n'
edit(f,'namespace steel {\n','namespace steel {\n\n'+prefix)
edit(f,'  METAL_FUNC void load_q8(const device uchar* root, const device int* pages,','''  METAL_FUNC void load_e4(const device uchar* root, const device int* pages,
      const int offset, const int first, const int valid_rows,
      const uint scale_bits) const thread {
    STEEL_PRAGMA_UNROLL
    for (short i = 0; i < BROWS; i += TROWS) {
      const int logical = first + bi + i;
      const bool valid = bi + i < valid_rows;
      const int physical = valid ? (pages ? ((pages[offset + (logical >> 4)] << 4) + (logical & 15)) : logical) : 0;
      STEEL_PRAGMA_UNROLL
      for (short j = 0; j < vec_size; j++) {
        // Guard the actual page load; inactive history never supplies a value.
        dst[i * kDstStrRow + j * kDstStrCol] = valid ?
            T(as_type<float>(hyle_f32_mul(hyle_e4_to_f32(root[physical * src_ld + bj + j]), scale_bits))) : T(0);
      }
    }
  }

  METAL_FUNC void load_q8(const device uchar* root, const device int* pages,''')
f='mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h'
edit(f,'constant bool hyle_window [[function_constant(305)]];','''constant bool hyle_window [[function_constant(305)]];
// Optional for older plain/Q8 specializations; E4 has a distinct library name.
constant bool hyle_e4_value [[function_constant(306)]];
constant uint hyle_key_scale_value [[function_constant(307)]];
constant uint hyle_value_scale_value [[function_constant(308)]];
constant bool hyle_e4 = is_function_constant_defined(hyle_e4_value) ? hyle_e4_value : false;
constant uint hyle_key_scale = is_function_constant_defined(hyle_key_scale_value) ? hyle_key_scale_value : 0x3f800000u;
constant uint hyle_value_scale = is_function_constant_defined(hyle_value_scale_value) ? hyle_value_scale_value : 0x3f800000u;''')
for axis in ['K','V']:
 edit(f,'if (!hyle_q8) '+axis+' +=','if (!hyle_q8 && !hyle_e4) '+axis+' +=')
 loader=axis.lower()
 old=f'loader_{loader}.load_q8({axis}bytes, hyle_paged ? hyle_pages : nullptr, hyle_paged ? hyle_offset : 0, kb * BK, params->kL - kb * BK);'
 edit(f,old,old+f'\n    }} else if (hyle_e4) {{\n      loader_{loader}.load_e4({axis}bytes, hyle_pages, hyle_offset, kb * BK, params->kL - kb * BK, hyle_{"key" if axis=="K" else "value"}_scale);')
identities=[]
for name,final in changes.items():
 item=next(x for x in m['files'] if x['path']==name)
 before=(p/'native-before'/name).read_bytes()
 assert hashlib.sha256(before).hexdigest()==item['after_sha256']
 item['edits']+=edits[name]; item['after_sha256']=hashlib.sha256(final.encode()).hexdigest()
 dest=p/'native-after'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(final.encode())
 (p/(name.replace('/','--')+'.diff')).write_text(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),final.splitlines(keepends=True),fromfile=name+' before',tofile=name+' after')),encoding='utf-8')
 identities.append({'path':name,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':item['after_sha256'],'bytes':len(final.encode()),'new_edits':len(edits[name])})
manifest.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'native-source-freeze.json').write_text(json.dumps({'files':identities,'shared_ieee_origin':'src/compute_shader_shared/nvfp4_f32.h','origin_sha256':hashlib.sha256((root/'src/compute_shader_shared/nvfp4_f32.h').read_bytes()).hexdigest(),'copied_literal_exact':shared in changes['mlx/backend/metal/kernels/steel/attn/loader.h'],'builds':0},indent=2)+'\n')
print(json.dumps(identities,indent=2))