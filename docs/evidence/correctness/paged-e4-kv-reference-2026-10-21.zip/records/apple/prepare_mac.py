from pathlib import Path
import json,hashlib,base64,re,runpy
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';S=A/'paged-e4-kv-reference/apple';O=S/'mac';O.mkdir(exist_ok=True)
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/paged-e4-kv-reference/apple'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def save(p,o):Path(p).write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
old=A/'grouped-fp8-power2-reference/apple/mac/remote'
plan=read(old/'plan.json');plan['link']=read(old/'results/link.command.json')['argv'];plan['inputs']=read(old/'results/link-inputs.json');plan['compile']=[]
recipes=read(A/'batch-query-extent/delegated/apple/recipes-all.json')
rows=[('src/compute_route_apple/apple_batch.cc',next(x['recipe']['argv']for x in recipes if x['source']=='src/compute_route_apple/apple_batch.cc')),
 ('src/compute_route_apple/apple_static_fp8.cc',read(A/'ct-bf16-block128-reference/apple/activation-edges/mac/remote/results/src--compute_route_apple--apple_static_fp8.cc-compile.command.json')['argv']),
 ('src/compute_route_apple/apple_mature_float.cc',read(old/'results/src--compute_route_apple--apple_mature_float.cc-compile.command.json')['argv']),
 ('tests/graph_route_apple/paged_e4_kv_test.cc',read(old/'results/tests--graph_route_apple--grouped_fp8_power2_test.cc-compile.command.json')['argv'])]
rows.append(('tests/compute_batch/encoded_page_native_consumer.cc', [*rows[-1][1], '-DHYLE_ENCODED_APPLE=1']))
for source,recipe in rows:
 suffix=source.replace('/','--')+'.o';matches=[x for x in plan['link']if x.endswith(suffix) or (source.endswith('apple_batch.cc') and x.endswith('/src--compute_route_apple--apple_batch.o'))]
 assert len(matches)==(0 if source.startswith('tests/')else 1),(source,matches)
 plan['compile'].append(dict(source=source,recipe=recipe,old_object=matches[0]if matches else ''))
inspect=read(S/'mac-native-inspect.json')
for source,key,old_suffix in [('mlx/fast.cpp','compile-fast.command.json','/inference-feature-completion-20261018-apple-highdim/fast.o'),('mlx/backend/metal/scaled_dot_product_attention.cpp','compile-native-host.command.json','/f32-partials/native-host.f32.o')]:
 recipe=inspect['recipes'][key]['argv'].copy();recipe.insert(1,'-I'+REMOTE+'/native')
 match=next(x for x in plan['link']if x.endswith(old_suffix))
 plan['compile'].append(dict(source='native/'+source,recipe=recipe,old_object=match))
genrecipe=read(S/'mac-native-generator.json')['compile-candidate-steel-command.json']['argv'].copy();# Retain the actual SDK generated-string recipe (no ISO minimum string-length diagnostic).
plan['compile'].append(dict(source='native-jit/steel_attention.cpp',recipe=genrecipe,old_object=next(x for x in plan['link']if x.endswith('/candidate/steel_attention.o'))))
plan.update(remote=REMOTE,filter='ApplePagedE4Kv.*:EncodedNativePages.IncrementalProducersAndJointConsumer',image='paged-e4-kv',
 native_base=inspect['source_root'],native_generator=inspect['source_root']+'/mlx/backend/metal/make_compiled_preamble.sh',
 metal_path='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/Users/kiro/.cargo/bin:/usr/bin:/bin:/usr/sbin:/sbin')
plan['include_roots'].insert(0,'native')
sources=[x['source']for x in plan['compile']if not x['source'].startswith('native')]
search=[ROOT,ROOT/'include',*[x for x in(ROOT/'src').iterdir()if x.is_dir()],*[x for x in(ROOT/'third_party').iterdir()if x.is_dir()]]
seen=set();include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M)
def visit(path):
 path=path.resolve()
 if path in seen or not path.is_relative_to(ROOT)or not path.is_file():return
 if path.suffix not in ['.h','.hpp','.hh','.cc','.mm','.inc','.inl','.cuh']:return
 seen.add(path)
 for name in include.findall(path.read_text(encoding='utf-8',errors='replace')):
  target=next((base/name for base in [path.parent,*search]if(base/name).is_file()),None)
  if target:visit(target)
for source in sources:visit(ROOT/source)
files=[]
for path in sorted(seen):
 b=path.read_bytes();files.append(dict(path=path.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
for path in(S/'native-after').rglob('*'):
 if path.is_file():
  b=path.read_bytes();files.append(dict(path='native/'+path.relative_to(S/'native-after').as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
save(O/'source-manifest.json',[{k:v for k,v in row.items()if k!='data'}for row in files]);save(O/'plan.json',plan)
payload=dict(plan=plan,files=files,script=base64.b64encode((S/'build_mac.py').read_bytes()).decode())
code=r'''
from pathlib import Path
import base64,hashlib,json,sys,subprocess,re
p=json.load(sys.stdin);r=Path(p['plan']['remote']);r.mkdir(parents=True,exist_ok=True);assert not r.is_symlink()
for row in p['files']:
 b=base64.b64decode(row['data']);assert hashlib.sha256(b).hexdigest()==row['sha256'];q=r/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/'source-manifest.json').write_text(json.dumps([{k:v for k,v in row.items()if k!='data'}for row in p['files']],indent=2)+'\n')
(r/'plan.json').write_text(json.dumps(p['plan'],indent=2)+'\n');(r/'build_mac.py').write_bytes(base64.b64decode(p['script']))
for row in p['plan']['inputs']:
 q=Path(row['path']);assert q.stat().st_size==row['bytes'];assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256'],row['path']
n=r/'native';base=Path(p['plan']['native_base']);seen=set();links=[]
def visit(name):
 if name in seen:return
 seen.add(name);q=n/name
 if not q.exists():
  original=base/name;assert original.is_file(),str(original);q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(original);links.append({'path':str(q),'target':str(original),'sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'bytes':original.stat().st_size})
 for include in re.findall(r'^\s*#\s*include\s*[<"]([^">]+)[">]',q.read_text(),re.M):
  if include.startswith('mlx/'):visit(include)
visit('mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h')
jit=n/'mlx/backend/metal/kernels/jit'
if not jit.exists() and not jit.is_symlink():jit.symlink_to(base/'mlx/backend/metal/kernels/jit',target_is_directory=True)
(r/'native-symlink-dependencies.json').write_text(json.dumps(links,indent=2)+'\n')
h={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version'],'space':['df','-h',str(r)]}.items()};assert h['model']=='Mac16,12';(r/'hardware.json').write_text(json.dumps(h,indent=2)+'\n')
print(json.dumps({'remote':str(r),'files':len(p['files']),'bytes':sum(x['bytes']for x in p['files']),'compile_owners':len(p['plan']['compile']),'native_links':len(links),'hardware':h}))
'''
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];result=ssh(code,payload);save(O/'sync.result.json',result);print(json.dumps(result,indent=2))