"""Two current Hyle CXX owners plus one actual mixed native ops owner; no run/link."""
from pathlib import Path
import concurrent.futures
import ctypes
import hashlib
import json
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[3]
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
BASE = A / 'grouped-fp8-power2-reference/cpu/checks/attempt1/link-plan.json'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def save(p, j):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(j, indent=2) + '\n', encoding='utf-8')


def ident(p):
    p = Path(p).resolve(); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def windows_argv(command):
    count = ctypes.c_int()
    api = ctypes.windll.shell32.CommandLineToArgvW
    api.argtypes = (ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int))
    api.restype = ctypes.POINTER(ctypes.c_wchar_p)
    pointer = api(command, ctypes.byref(count))
    try:
        return [pointer[i] for i in range(count.value)]
    finally:
        ctypes.windll.kernel32.LocalFree(pointer)


def main():
    host_recipes = {
        'provider': A / 'decode-next-cold/checks/20261019T155819/09-compute_provider_ggml-ggml_cpu_provider-identity.json',
        'batch': A / 'batch-layout-query-reuse/checks/20261019T120652/01-compute_provider_ggml-native_batch-identity.json',
    }
    original_commands = ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed-native-commands-recovered.json'
    native = next(x for x in read(original_commands) if x['label'] == 'mixed-native-baseline')
    recipes = {name: read(path) for name, path in host_recipes.items()}
    recipes['ops'] = {'command': native['argv'],
                      'source': {'path': str((ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/ops.cpp').resolve())}}
    base = read(BASE)
    old_provider = recipes['provider']['object']
    assert any(row['path'].lower() == old_provider['path'].lower() for row in base['inputs'])
    frozen = read(S / 'source-freeze.json')
    assert all(ident(x['path']) == x for x in frozen['sources'])

    def compile_one(name):
        recipe = recipes[name]
        attempt = 'attempt3' if '--attempt3' in sys.argv else 'attempt2' if '--native-only' in sys.argv else 'attempt1'
        out = S / 'checks/products' / attempt / name
        out.mkdir(parents=True, exist_ok=True)
        assert not (out / 'result.json').exists()
        source = S / 'mixed-native-source/src/ggml-cpu/ops.cpp' if name == 'ops' else Path(recipe['source']['path'])
        old_source = recipe['source']['path']
        args, skip = [], False
        for arg in recipe['command']:
            if skip:
                skip = False; continue
            if arg.lower() == '/sourcedependencies':
                skip = True; continue
            if arg.lower().startswith(('/fo', '/fd')) or arg.replace('\\', '/').lower() == old_source.replace('\\', '/').lower():
                continue
            args.append(arg)
        obj, deps = out / (name + '.obj'), out / 'dependencies.json'
        args += [str(source.resolve()), '/sourceDependencies', str(deps.resolve()),
                 '/Fo' + str(obj.resolve()), '/Fd' + str((out / (name + '.pdb')).resolve())]
        sys.path.insert(0, str(ROOT / 'scripts'))
        from hyle_environment import windows_compiler_environment
        env = windows_compiler_environment({'CMAKE_CXX_COMPILER': args[0]})
        env['VSLANG'] = '1033'
        tmp = out / 'tmp'; tmp.mkdir(exist_ok=True)
        env['TMP'] = env['TEMP'] = str(tmp)
        row = dict(command=args, cwd=str(ROOT), source=ident(source),
                   recipe=ident(original_commands if name == 'ops' else host_recipes[name]),
                   started=time.time(), SDK_rebuild=False, GPU_run=False)
        save(out / 'command.json', row)
        with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
            result = subprocess.run(args, cwd=ROOT, env=env, stdout=so, stderr=se,
                                    creationflags=subprocess.CREATE_NO_WINDOW)
        row.update(exit=result.returncode, finished=time.time())
        save(out / 'result.json', row)
        print(name, result.returncode, flush=True)
        if result.returncode:
            print((out / 'stdout.log').read_text(errors='replace')[-6500:], flush=True)
            print((out / 'stderr.log').read_text(errors='replace')[-2500:], flush=True)
            raise RuntimeError(name + ' compiler failed')
        dependency_data = read(deps)['Data']
        paths = [source, *map(Path, dependency_data['Includes'])]
        row.update(object=ident(obj), source_dependencies=ident(deps),
                   dependencies=[ident(p) for p in dict.fromkeys(paths)])
        if name == 'provider':
            row['replaces'] = old_provider
        elif name == 'ops':
            row['replaces'] = ident(ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal/mixed/native-baseline.obj')
            if '--attempt3' in sys.argv:
                row['supersedes_actual_object'] = read(S / 'checks/products/attempt2/ops/identity.json')['object']
                row['canonical_generation'] = ident(S / 'canonical-regeneration.json')
        else:
            row['add_before_archive'] = 'hyle_compute_provider_ggml.lib' if name == 'batch' else 'ggml-cpu.lib'
            row['reason'] = 'Provide the whole actual owner before its archive, retaining unmodified archive members/SDK.'
        save(out / 'identity.json', row)
        return row

    names = ['ops'] if '--native-only' in sys.argv else ['provider', 'batch', 'ops']
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(compile_one, names))
    if '--native-only' in sys.argv:
        rows = [read(S / 'checks/products/attempt1' / name / 'identity.json') for name in ['provider', 'batch']] + rows
    save(S / 'checks/products/final-summary.json', {
        'successful_CXX_owners': len(rows),
        'successful_CXX_attempts': 4 if '--attempt3' in sys.argv else 3,
        'actual_CXX_attempts': 5 if '--attempt3' in sys.argv else 4 if '--native-only' in sys.argv else 3,
        'compiler_failures': 1 if '--native-only' in sys.argv else 0,
        'links': 0, 'runs': 0, 'SDK_rebuilds': 0,
        'base': ident(BASE), 'product_objects': [r['object'] for r in rows],
        'identity_files': [ident(S / 'checks/products' / ('attempt3' if name == 'ops' and '--attempt3' in sys.argv else 'attempt2' if name == 'ops' and '--native-only' in sys.argv else 'attempt1') / name / 'identity.json')
                           for name in ['provider', 'batch', 'ops']],
        'replace': [r for r in rows if 'replaces' in r],
        'add_before_archives': [r for r in rows if 'add_before_archive' in r]})
    print('PRODUCTS_READY', S / 'checks/products/final-summary.json', flush=True)


if __name__ == '__main__':
    main()
