"""Original CPU page reader typed E4 extension. No build or GPU here."""
from pathlib import Path
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[3]
UP = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml_cpu-ffa4e8b80930-ac5706fbc134')
OWNERS = ['src/compute_provider_ggml/native_batch.h', 'src/compute_provider_ggml/native_batch.cc',
          'src/compute_provider_ggml/ggml_cpu_provider.cc', 'third_party/ggml_cpu_runtime/patches.json']


def ident(path):
    p = Path(path).resolve(); b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


manifest_path = ROOT / OWNERS[3]
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
file = next(f for f in manifest['files'] if f['path'] == 'src/ggml-cpu/ops.cpp')
original = (UP / file['path']).read_bytes()
assert hashlib.sha256(original).hexdigest() == file['before_sha256']
text = original.decode('utf-8').replace('\r\n', '\n')
for e in file['edits']:
    assert text.count(e['before']) == 1
    text = text.replace(e['before'], e['after'], 1)
assert hashlib.sha256(text.encode()).hexdigest() == file['after_sha256']
before_native = S / 'before/native/ops.cpp'; before_native.parent.mkdir(parents=True, exist_ok=True)
before_native.write_text(text, encoding='utf-8', newline='\n')

edits = []


def patch(a, b):
    global text
    assert text.count(a) == 1, a
    text = text.replace(a, b, 1)
    edits.append({'before': a, 'after': b})


patch('static void ggml_compute_forward_flash_attn_ext_f16_one_chunk(', '''// Private E4 page interpretation: I8 remains a truthful raw-byte carrier.
// Slots0..4 are upstream flash params;5..9 are page/boxed controls.
static inline bool hyle_flash_e4(const ggml_tensor * dst) {
    return hyle_flash_boxed(dst) && dst->op_params[10] == 0x48594534;
}
static inline float hyle_flash_e4_scale(const ggml_tensor * dst, int slot) {
    float result;
    memcpy(&result, dst->op_params + slot, sizeof(result));
    return result;
}
static inline float hyle_flash_e4_value(uint8_t code, float scale) {
    const uint32_t exponent = (code >> 3) & 15, mantissa = code & 7;
    const float decoded = exponent == 15 && mantissa == 7 ? NAN :
        exponent == 0 ? std::ldexp(float(mantissa), -9) :
        std::ldexp(1.0f + float(mantissa)/8.0f, int(exponent) - 7);
    // This storage boundary precedes QK/PV; do not precombine cache scales.
    volatile float value = std::copysign(decoded, code & 128 ? -1.0f : 1.0f)*scale;
    return value;
}

static void ggml_compute_forward_flash_attn_ext_f16_one_chunk(''')
patch('    ggml_type         const k_vec_dot_type = ggml_get_type_traits_cpu(k->type)->vec_dot_type;',
      '    const bool e4 = hyle_flash_e4(dst);\n'
      '    ggml_type         const k_vec_dot_type = e4 ? GGML_TYPE_F32 : ggml_get_type_traits_cpu(k->type)->vec_dot_type;')
patch('    GGML_ASSERT((                            q_to_vec_dot) && "fattn: unsupported K-type");\n'
      '    GGML_ASSERT((v->type == GGML_TYPE_F32 || v_to_float  ) && "fattn: unsupported V-type");',
      '    GGML_ASSERT((e4 || q_to_vec_dot) && "fattn: unsupported K-type");\n'
      '    GGML_ASSERT((e4 || v->type == GGML_TYPE_F32 || v_to_float) && "fattn: unsupported V-type");\n'
      '    GGML_ASSERT(!e4 || (k->type == GGML_TYPE_I8 && v->type == GGML_TYPE_I8));')
patch('        q_to_vec_dot(pq, Q_q, DK);', '        if (!e4) q_to_vec_dot(pq, Q_q, DK);')
patch('            kq_vec_dot(DK, &s, 0, k_data, 0, Q_q, 0, 1);',
      '            if (e4) {\n'
      '                s = 0.0f;\n'
      '                const float storage_scale = hyle_flash_e4_scale(dst, 11);\n'
      '                for (int64_t d = 0; d < DK; ++d) {\n'
      '                    const float value = hyle_flash_e4_value(uint8_t(k_data[d]), storage_scale);\n'
      '                    s += pq[d]*value;\n'
      '                }\n'
      '            } else {\n'
      '                kq_vec_dot(DK, &s, 0, k_data, 0, Q_q, 0, 1);\n'
      '            }')
patch('                if (v_to_float) {\n                    v_to_float(v_data, V32, DV);',
      '                if (e4) {\n'
      '                    const float storage_scale = hyle_flash_e4_scale(dst, 12);\n'
      '                    for (int64_t d = 0; d < DV; ++d)\n'
      '                        V32[d] = hyle_flash_e4_value(uint8_t(v_data[d]), storage_scale);\n'
      '                    ggml_vec_mad_f32(DV, VKQ32, V32, vs);\n'
      '                } else if (v_to_float) {\n                    v_to_float(v_data, V32, DV);')
file['edits'].extend(edits)
file['after_sha256'] = hashlib.sha256(text.encode()).hexdigest()
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
native = S / 'native-source/src/ggml-cpu/ops.cpp'; native.parent.mkdir(parents=True, exist_ok=True)
native.write_text(text, encoding='utf-8', newline='\n')
diff = []
for name in OWNERS:
    before_path = S / 'before' / name; p = ROOT / name; after = S / 'after' / name
    after.parent.mkdir(parents=True, exist_ok=True); after.write_bytes(p.read_bytes())
    diff.extend(difflib.unified_diff(before_path.read_text().splitlines(True), p.read_text().splitlines(True), fromfile='before/' + name, tofile='after/' + name))
(S / 'implementation.diff').write_text(''.join(diff), encoding='utf-8')
save(S / 'source-freeze.json', {'sources': [ident(ROOT / n) for n in OWNERS],
    'native_source': ident(native), 'upstream': ident(UP / file['path']),
    'public_ABI_changed': False, 'native_op_params': {'E4_tag': 10, 'Kscale': 11, 'Vscale': 12},
    'shared_cache_mutated': False, 'encoder_math_unchanged': True,
    'full_decoded_cache': False, 'MLA_qualification_unchanged': True})
print(json.dumps({'freeze': ident(S / 'source-freeze.json'), 'native': ident(native)}, indent=2))
