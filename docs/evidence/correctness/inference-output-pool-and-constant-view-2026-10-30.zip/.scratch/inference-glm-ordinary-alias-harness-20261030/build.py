"""One cold Graph diagnostic TU; wait for root SHA approval before compile/link/native."""
from pathlib import Path
import importlib.util,json,shutil,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
OLD=R/'.scratch/inference-output-pool-capacity-harness-20261030'
CANDIDATE=R/'.scratch/inference-glm-ordinary-alias-20261030/executable-diagnostic.cc'
spec=importlib.util.spec_from_file_location('ordinary_diag_prior',OLD/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
s=b.s;s.W=s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
def snapshot():
 assert not (W/'baseline-plan.json').exists()
 base_path=OLD/'model-link-base.json';base=read(base_path);assert len(base['retained'])==231
 source=R/'src/graph/executable.cc';assert pin(source)['sha256']=='9f4fb5bcae0d826af44f9f6042253e2d0673cab9532493d45f84a0ddb05024cc'
 graph_receipt=R/'.scratch/inference-graph-alias-repair-harness-20261030/compile/sdk/receipt.json';graph=read(graph_receipt)
 for item in [*base['retained'],base['runtime'],graph['object'],*graph['source_identities']]:exact(item)
 assert sum(key(i['path'])==key(graph['object']['path']) for i in base['retained'])==1
 ordinary_receipt=OLD/'compile/baseline-glm-ordinary/receipt.json';ordinary=read(ordinary_receipt)
 for item in [ordinary['object'],*ordinary['source_identities']]:exact(item)
 assert ordinary['new_capacity_helper_absent']
 original_command=Path(graph['process']['path']).parent/'command.json';raw=read(original_command)
 assert [a for a in raw if a.lower().endswith('.cc')]==[str(source)] and '/c' in raw
 out=W/'baseline-source/src/graph/executable.cc';out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(source.read_bytes())
 folder=W/'compile/graph/diagnosticattempt1';command=[]
 for index,arg in enumerate(raw):
  if index and raw[index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
  elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
  elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
  elif key(arg)==key(source):arg=str(CANDIDATE)
  command.append(arg)
 command.append('/I'+str(R/'src/graph'))
 original_link=read(OLD/'baseline-ordinary-attribution-prepared.json')['link'];link=[];replaced=0
 for arg in original_link:
  if key(arg)==key(graph['object']['path']):arg=str(folder/'unit.obj');replaced+=1
  arg=arg.replace(str(OLD/'bin/baseline-glm-ordinary'),str(W/'bin/ordinary-diagnostic'));link.append(arg)
 assert replaced==1 and sum(key(a)==key(ordinary['object']['path']) for a in link)==1
 case=read(OLD/'run-plan.json')['cases']['glm-ordinary-cuda'];runfolder=W/'runs/ordinary/diagnosticattempt1'
 argv=[str(W/'bin/ordinary-diagnostic.exe')]+[a for a in case['command'][1:] if not a.startswith('--gtest_output=')]
 argv.append('--gtest_output=xml:'+str(runfolder/'results.xml'))
 save(W/'baseline-plan.json',dict(status='PREPARED_ONLY_NO_DIAGNOSTIC_EXECUTION',base=pin(base_path),retained=base['retained'],runtime=base['runtime'],
  original_Graph=graph['object'],original_Graph_receipt=pin(graph_receipt),original_Graph_source=pin(source),original_Graph_snapshot=pin(out),
  original_Graph_source_pins=graph['source_identities'],original_Graph_recipe=pin(original_command),
  ordinary_consumer_receipt=pin(ordinary_receipt),ordinary_consumer=ordinary['object'],ordinary_source_pins=ordinary['source_identities'],
  baseline_body_no_new_capacity_helper=True,compile=command,link=link,native=argv,
  candidate_source=str(CANDIDATE),explicit_local_include=str(R/'src/graph'),expected_Graph_replacements=1,
  planned_CXX=1,planned_links=1,planned_native=1,consumer_CXX=0,NVCC=0,downloads=0,
  scope='Reuse byte-exact pre-output-pool ordinary consumer with same current231; replace onlyGraph object by pure cold-error-context diagnostic. No production edit or limit change. Root SHA approval required.'))
 print('DIAGNOSTIC_RECIPE_READY:Graph1CXX,1link,1native;old231/source9f4/consumer pinned;0executed',flush=True)
def prepare(sha):
 assert not (W/'plan.json').exists()
 baseline=read(W/'baseline-plan.json');actual=pin(CANDIDATE);assert actual['sha256']==sha
 for item in [baseline['original_Graph_source'],*baseline['original_Graph_source_pins'],*baseline['ordinary_source_pins'],*baseline['retained']]:exact(item)
 out=W/'source-frozen/executable-diagnostic.cc';out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(CANDIDATE.read_bytes())
 save(W/'plan.json',dict(**baseline,freeze=actual,freeze_snapshot=pin(out),approval_SHA=sha))
 (W/'bin').mkdir(exist_ok=True);shutil.copyfile(baseline['runtime']['path'],W/'bin'/Path(baseline['runtime']['path']).name)
def compile():
 plan=read(W/'plan.json');exact(plan['freeze']);folder=W/'compile/graph/diagnosticattempt1'
 s.b.execute(plan['compile'],folder,900)
 dep=read(folder/'dependencies.json')['Data'];paths=sorted({Path(p).resolve() for p in [dep['Source'],*dep['Includes']] if Path(p).is_relative_to(R)})
 save(folder/'receipt.json',dict(object=pin(folder/'unit.obj'),dependencies=pin(folder/'dependencies.json'),
  process=pin(folder/'process.json'),source_identities=[pin(p) for p in paths],original_replaced=plan['original_Graph']))
def link():
 plan=read(W/'plan.json');receipt=read(W/'compile/graph/diagnosticattempt1/receipt.json')
 for item in [receipt['object'],*receipt['source_identities'],plan['ordinary_consumer'],*plan['ordinary_source_pins'],*plan['retained']]:exact(item)
 s.b.execute(plan['link'],W/'link/ordinary/diagnosticattempt1',240)
 save(W/'ready-ordinary-diagnostic.json',pin(W/'bin/ordinary-diagnostic.exe'))
if __name__=='__main__':
 if sys.argv[1]=='snapshot':snapshot()
 elif sys.argv[1]=='prepare':prepare(sys.argv[2])
 elif sys.argv[1]=='compile':compile()
 elif sys.argv[1]=='link':link()
 else:raise ValueError(sys.argv[1])
