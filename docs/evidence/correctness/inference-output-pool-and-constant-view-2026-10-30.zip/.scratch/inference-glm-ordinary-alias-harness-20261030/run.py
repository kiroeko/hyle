"""Exactly one root-approved diagnostic native; refusal stays failure, never PASS."""
from pathlib import Path
import importlib.util,json,os,subprocess,time,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('ordinary_diag_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
plan=read(W/'plan.json');image=read(W/'ready-ordinary-diagnostic.json');exact(image);exact(plan['freeze'])
folder=W/'runs/ordinary/diagnosticattempt1';assert not (folder/'process.json').exists()
env=os.environ.copy();env.update(read(b.s.b.OLD/'environment.json'))
old=b.OLD;request_plan=read(old/'run-plan.json')
for name in request_plan['clear_frontier_request_environment']:env.pop(name,None)
env.update(read(old/'runs/candidate/baseline-glm-ordinary-cuda/attempt1/environment.json'))
env['PATH']=str(W/'bin')+';'+env['PATH'];temporary=W/'tmp';temporary.mkdir(exist_ok=True);env['TEMP']=env['TMP']=str(temporary)
assert all(v=='0' for k,v in env.items() if k.startswith('HYLE_') and 'WAIT_FOR_EXPERTS' in k)
folder.mkdir(parents=True,exist_ok=True);save(folder/'image.json',image);save(folder/'command.json',plan['native'])
save(folder/'environment.json',{k:v for k,v in env.items() if k.startswith(('HYLE_','HF_','TRANSFORMERS_'))})
started=time.time()
with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
 p=subprocess.Popen(plan['native'],cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 save(folder/'process.json',dict(state='RUNNING',pid=p.pid,started=started));print('RUNNING',p.pid,'ordinary diagnosticattempt1',flush=True)
 timed_out=False
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:timed_out=True;p.kill();code=p.wait()
save(folder/'process.json',dict(state='TERMINAL',pid=p.pid,started=started,seconds=time.time()-started,exit=code,timed_out=timed_out))
assert not timed_out
x=ET.parse(folder/'results.xml').getroot();tests=list(x.iter('testcase'));assert len(tests)==1 and not list(x.iter('skipped'))
assert tests[0].get('status')=='run' and tests[0].get('result')=='completed'
messages=[v.get('message') for v in x.iter('failure')]
save(W/'diagnostic-result.json',dict(status='DIAGNOSTIC_REFUSAL_RECORDED' if code else 'UNEXPECTED_NATIVE_SUCCESS',native_exit=code,
 tests=1,failures=len(messages),skipped=0,messages=messages,original_Graph=plan['original_Graph'],diagnostic_Graph=read(W/'compile/graph/diagnosticattempt1/receipt.json')['object'],
 original_Graph_source=plan['original_Graph_source'],diagnostic_source=plan['freeze'],unchanged_retained=230,total_retained_after_replacement=231,
 original_consumer=plan['ordinary_consumer'],baseline_body_no_helper=True,
 scope='Pure cold error-context diagnostic, no production change or repair. One reused old-body ordinary case, no other native. See full stdout/stderr/XML.'))
print(json.dumps(dict(status=read(W/'diagnostic-result.json')['status'],exit=code,tests=1,failures=len(messages),skipped=0,
 report=str(W/'diagnostic-result.json'))),flush=True)
