"""Pre-apply snapshots and actual dependency impact; no CXX/link/native."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
OLD=R/'.scratch/inference-output-pool-capacity-harness-20261030'
spec=importlib.util.spec_from_file_location('constant_view_prior',OLD/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
assert not (W/'baseline-plan.json').exists()
base_path=OLD/'model-link-base.json';base=read(base_path);assert len(base['retained'])==231
core_dir=R/'.scratch/inference-glm-ordinary-alias-20261030/m1';test_dir=R/'.scratch/inference-constant-view-alignment-test-20261030'
core=read(core_dir/'plan.json');test=read(test_dir/'plan.json')
expected=[dict(path=str(R/i['relative']),**i['base']) for i in core['source_pins']]
expected+=[dict(path=str(R/test['base']['path']),bytes=test['base']['bytes'],sha256=test['base']['sha256']),
 dict(path=str(R/test['canonical_fixture']['path']),bytes=test['canonical_fixture']['base_bytes'],sha256=test['canonical_fixture']['base_sha256'])]
snapshots=[]
for item in expected:
 exact(item);out=W/'baseline-source'/Path(item['path']).relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(Path(item['path']).read_bytes())
 snapshots.append(dict(original=item,snapshot=pin(out)))
for item in [*base['retained'],base['runtime']]:exact(item)
layout={key(R/'src/graph/constant_artifact.h'),key(R/'src/graph/plan_state.h')};changed={key(i['path']) for i in expected};watched=layout|changed
index=read(base['sdk_engine_dependencies']['path']);affected=[]
for row in index['inspected']:
 exact(row['dependencies']);dep=read(row['dependencies']['path'])['Data']
 overlap=[p for p in [dep['Source'],*dep['Includes']] if key(p) in watched]
 if overlap:affected.append(dict(**row,source=dep['Source'],changed_or_layout_inputs=overlap))
consumers={}
for name in read(OLD/'plan.json')['units']:
 receipt_path=OLD/'compile'/name/'receipt.json';receipt=read(receipt_path)
 for item in [receipt['object'],*receipt['source_identities']]:exact(item)
 consumers[name]=dict(receipt=pin(receipt_path),object=receipt['object'],source_identities=receipt['source_identities'],
  layout_or_changed_inputs=[i['path'] for i in receipt['source_identities'] if key(i['path']) in watched])
other_consumers={}
for name,row in base['current_consumers'].items():
 receipt=read(row['receipt']['path']);overlap=[i['path'] for i in receipt['source_identities'] if key(i['path']) in watched]
 if overlap:other_consumers[name]=dict(**row,layout_or_changed_inputs=overlap)
save(W/'baseline-plan.json',dict(status='PREAPPLY_SOURCE_AND_231_SNAPSHOT_READY_NO_EXECUTION',base=pin(base_path),retained=base['retained'],runtime=base['runtime'],
 core_plan=pin(core_dir/'plan.json'),test_plan=pin(test_dir/'plan.json'),snapshots=snapshots,consumers=consumers,
 affected_retained=affected,other_current_affected_consumers=other_consumers,
 source_layout_warning='CanonicalConstantKey/State layout and private acquire signature change. Every actual transitive private-header consumer must be rebuilt; five-argument wrapper does not preserve layout ABI.',
 available_dependency_rows=len(index['inspected']),unavailable_dependency_metadata=index['unavailable'],
 note='69 historical unavailable dependency entries are native kernels/libraries, not reusable evidence of private Graph CXX layout. Actual CXX source/dependency closure is checked separately; no stale affected Graph object may enter candidate link.',
 CXX=0,links=0,native=0))
print(json.dumps(dict(status='SNAPSHOT_READY',source_files=len(snapshots),retained=231,current_receipts=len(consumers),
 affected_retained=[Path(i['source']).relative_to(R).as_posix() for i in affected],
 affected_12_consumers=[n for n,v in consumers.items() if v['layout_or_changed_inputs']],other_affected=list(other_consumers),CXX=0,native=0)))
