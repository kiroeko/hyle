"""One original ordinary CUDA case on repaired core, oldbody or current helper."""
from pathlib import Path
import importlib.util,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1];OLD=R/'.scratch/inference-output-pool-capacity-harness-20261030'
spec=importlib.util.spec_from_file_location('m1_ordinary_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
arm=sys.argv[1];assert arm in ('ordinary-oldbody','ordinary-helper')
image=read(W/('ready-'+arm+'.json'));exact(image);folder=W/'runs'/arm/'attempt1';assert not (folder/'process.json').exists()
source=read(OLD/'run-plan.json');row=source['cases']['glm-ordinary-cuda']
command=[image['path']]+[a for a in row['command'][1:] if not a.startswith('--gtest_output=')]
command.append('--gtest_output=xml:'+str(folder/'results.xml'))
env=os.environ.copy();env.update(read(b.s.b.OLD/'environment.json'))
for name in source['clear_frontier_request_environment']:env.pop(name,None)
env.update(read(OLD/'runs/candidate/baseline-glm-ordinary-cuda/attempt1/environment.json'))
env['PATH']=str(W/'bin')+';'+env['PATH'];temporary=W/'tmp';temporary.mkdir(exist_ok=True);env['TEMP']=env['TMP']=str(temporary)
assert all(v=='0' for k,v in env.items() if k.startswith('HYLE_') and 'WAIT_FOR_EXPERTS' in k)
save(folder/'image.json',image);save(folder/'command.json',command);save(folder/'environment.json',{k:v for k,v in env.items() if k.startswith(('HYLE_','HF_','TRANSFORMERS_'))})
started=time.time()
with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
 p=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 save(folder/'process.json',dict(state='RUNNING',pid=p.pid,started=started));print('RUNNING',p.pid,arm,flush=True)
 timed_out=False
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:timed_out=True;p.kill();code=p.wait()
save(folder/'process.json',dict(state='TERMINAL',pid=p.pid,started=started,seconds=time.time()-started,exit=code,timed_out=timed_out))
if code or timed_out:
 print((folder/'stdout.log').read_text(encoding='utf-8',errors='replace')[-6000:]);raise SystemExit(code or 1)
x=ET.parse(folder/'results.xml').getroot();tests=list(x.iter('testcase'))
assert len(tests)==int(x.get('tests','-1'))==1 and int(x.get('failures','-1'))==0 and int(x.get('errors','0'))==0
assert not list(x.iter('skipped')) and tests[0].get('status')=='run' and tests[0].get('result')=='completed'
save(folder/'report.json',dict(status='PASS',tests=1,failures=0,skipped=0,arm=arm,xml=pin(folder/'results.xml'),
 original_case='GlmMtpStateConsumer.CudaOriginalTarget43And44AndNextNRandomVerifierContinuesAtomically',
 scope='Original source/capture/random/state assertions on exact repaired9SDK closure; no performance claim.'))
print('PASS',arm,'test1skip0',flush=True)
