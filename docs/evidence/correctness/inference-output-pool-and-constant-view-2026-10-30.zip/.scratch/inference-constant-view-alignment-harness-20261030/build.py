"""M1 private-layout repair: exact9 SDK replacements and2 test TUs, max2 cl."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
import importlib.util,json,shutil,sys
W=Path(__file__).resolve().parent;R=W.parents[1];OLD=R/'.scratch/inference-output-pool-capacity-harness-20261030'
spec=importlib.util.spec_from_file_location('constant_view_build_prior',OLD/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
s=b.s;s.W=s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
def prepare():
 assert not (W/'plan.json').exists()
 recipe=read(W/'recipes-prepared.json');core=read(R/'.scratch/inference-glm-ordinary-alias-20261030/m1/plan.json')
 tests=read(R/'.scratch/inference-constant-view-alignment-test-20261030/plan.json')
 items=[dict(path=str(R/i['relative']),**i['candidate']) for i in core['source_pins']]
 items+=[dict(path=str(R/tests['base']['path']),bytes=tests['candidate']['bytes'],sha256=tests['candidate']['sha256']),
 dict(path=str(R/tests['canonical_fixture']['path']),bytes=tests['canonical_fixture']['candidate_bytes'],sha256=tests['canonical_fixture']['candidate_sha256'])]
 frozen=[]
 for item in items:
  exact(item);target=W/'source-frozen'/Path(item['path']).relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(item['path']).read_bytes())
  frozen.append(dict(source=item,snapshot=pin(target)))
 baseline=read(W/'baseline-plan.json')
 for item in [*baseline['retained'],baseline['runtime']]:exact(item)
 recipe.update(source_freeze=frozen,retained=baseline['retained'],status='APPLIED_FROZEN_ROOT_AUTHORIZED',core_plan=pin(R/'.scratch/inference-glm-ordinary-alias-20261030/m1/plan.json'),test_plan=pin(R/'.scratch/inference-constant-view-alignment-test-20261030/plan.json'))
 save(W/'plan.json',recipe);runtime();print('FROZEN5;9SDK+2tests;231replacement,noABI mixing',flush=True)
def runtime():
 item=read(W/'baseline-plan.json')['runtime'];exact(item);(W/'bin').mkdir(exist_ok=True);target=W/'bin'/Path(item['path']).name
 if target.exists():
  p=pin(target);assert all(p[f]==item[f] for f in ('bytes','sha256'))
 else:shutil.copyfile(item['path'],target)
def compile(attempt,names):
 plan=read(W/'plan.json')
 for row in plan['source_freeze']:exact(row['source'])
 def one(name):
  unit=plan['units'][name];old=Path(unit['object']).parent;folder=W/'compile'/name/attempt
  command=[a.replace(str(old),str(folder)) for a in unit['compile']];s.b.execute(command,folder,900)
  dep=read(folder/'dependencies.json')['Data'];paths=sorted({Path(p).resolve() for p in [dep['Source'],*dep['Includes']] if Path(p).is_relative_to(R)})
  assert R/'src/graph/constant_artifact.h' in paths,(name,'private-layout header absent')
  save(W/'compile'/name/'receipt.json',dict(object=pin(folder/'unit.obj'),dependencies=pin(folder/'dependencies.json'),
   process=pin(folder/'process.json'),source_identities=[pin(p) for p in paths],original_object=unit.get('original_object')))
  print('COMPILED',name,flush=True)
 pending=iter(names)
 with ThreadPoolExecutor(max_workers=2) as pool:
  running={}
  for _ in range(min(2,len(names))):
   name=next(pending);running[pool.submit(one,name)]=name
  while running:
   done,_=wait(running,return_when=FIRST_COMPLETED)
   for future in done:
    name=running.pop(future);future.result()
    next_name=next(pending,None)
    if next_name is not None:running[pool.submit(one,next_name)]=next_name
def sdk_replacements():
 plan=read(W/'plan.json');replace={}
 for name,unit in plan['units'].items():
  if not name.startswith('sdk-'):continue
  receipt=read(W/'compile'/name/'receipt.json')
  for item in [receipt['object'],*receipt['source_identities']]:exact(item)
  replace[key(unit['original_object']['path'])]=receipt['object']['path']
 assert len(replace)==9
 return replace
def link(name,attempt):
 plan=read(W/'plan.json');replace=sdk_replacements();base=read(plan['base']['path']);runtime()
 for item in [*plan['retained'],*plan['gtest_libraries']]:exact(item)
 if name in ('region-test','constant-cache-test'):
  consumer=read(W/'compile'/name/'receipt.json');original=plan['units'][name]['object'];args=plan['links'][name]
 else:
  assert name in ('ordinary-oldbody','ordinary-helper')
  receipt_path=OLD/'compile'/('baseline-glm-ordinary' if name=='ordinary-oldbody' else 'glm-ordinary')/'receipt.json'
  consumer=read(receipt_path);original=base['current_consumers']['cli']['object']['path'];args=base['link']
 for item in [consumer['object'],*consumer['source_identities']]:exact(item)
 command=[];replaced=0
 for arg in args:
  if key(arg)==key(original):arg=consumer['object']['path']
  if key(arg) in replace:arg=replace[key(arg)];replaced+=1
  # Prepared test links already contain the9 new SDK object paths.
  for sdk_name,unit in plan['units'].items():
   if sdk_name.startswith('sdk-') and key(arg)==key(unit['object']):arg=replace[key(unit['original_object']['path'])]
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  command.append(arg)
 if name.startswith('ordinary'):
  for lib in plan['gtest_libraries']:
   if lib['path'] not in command:command.append(lib['path'])
 assert all(old not in {key(a) for a in command} for old in replace)
 assert all(sum(key(a)==key(new) for a in command)==1 for new in replace.values())
 s.b.execute(command,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
def link_existing(name,attempt):
 base=read(W/'model-link-base.json');consumer=read(base['current_consumers'][name]['receipt']['path'])
 for item in [consumer['object'],*consumer['source_identities'],*base['retained'],base['runtime']]:exact(item)
 runtime();old=base['current_consumers']['cli']['object']['path'];command=[];replaced=0
 for arg in base['link']:
  if key(arg)==key(old):arg=consumer['object']['path'];replaced+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  command.append(arg)
 assert replaced==1
 if name not in ('cli','tiny','session'):
  for lib in read(W/'plan.json')['gtest_libraries']:
   if lib['path'] not in command:command.append(lib['path'])
 s.b.execute(command,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
def link_baseline(name,attempt):
 assert name in ('cli','session')
 plan=read(W/'default-plan.json');base=read(plan['old_base']['path']);consumer=base['current_consumers'][name]['object']
 for item in [consumer,*base['retained'],base['runtime']]:exact(item)
 runtime();old=base['current_consumers']['cli']['object']['path'];command=[];count=0
 for arg in base['link']:
  if key(arg)==key(old):arg=consumer['path'];count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/('baseline-'+name)).with_suffix(suffix));break
  command.append(arg)
 assert count==1
 s.b.execute(command,W/'link'/('baseline-'+name)/attempt,240);save(W/('ready-baseline-'+name+'.json'),pin(W/'bin'/('baseline-'+name+'.exe')))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='compile':compile(sys.argv[2],sys.argv[3:])
 elif sys.argv[1]=='link':link(sys.argv[2],sys.argv[3])
 elif sys.argv[1]=='link-existing':link_existing(sys.argv[2],sys.argv[3])
 elif sys.argv[1]=='link-baseline':link_baseline(sys.argv[2],sys.argv[3])
 else:raise ValueError(sys.argv[1])
