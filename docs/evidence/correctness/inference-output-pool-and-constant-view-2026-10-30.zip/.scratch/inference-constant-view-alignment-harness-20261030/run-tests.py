"""First CPU critical tests; exact discovery/execution counts, no skips."""
from pathlib import Path
import importlib.util,json,re,sys,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('m1_tests_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
new=re.findall(r'TEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',(R/'.scratch/inference-constant-view-alignment-test-20261030/addition.cc').read_text())
names=[suite+'.'+name for suite,name in new];assert len(names)==3 and all(x.startswith('GraphConstants.') for x in names)
def check(folder,count,expected_names=None):
 x=ET.parse(folder/'results.xml').getroot();tests=list(x.iter('testcase'))
 assert int(x.get('tests','-1'))==len(tests)==count and int(x.get('failures','-1'))==0 and int(x.get('errors','0'))==0
 assert not list(x.iter('skipped')) and all(t.get('status')=='run' and t.get('result')=='completed' for t in tests)
 actual=[t.get('classname')+'.'+t.get('name') for t in tests]
 if expected_names:assert set(actual)==set(expected_names)
 result=dict(status='PASS',tests=count,failures=0,errors=0,skipped=0,actual_tests=actual,xml=pin(folder/'results.xml'))
 save(folder/'report.json',result);return result
results={}
selected=sys.argv[1] if len(sys.argv)>1 else 'all';attempt=sys.argv[2] if len(sys.argv)>2 else 'attempt1'
for name,unit,count,filter_names in [('new3','region-test',3,names),('cache-all','constant-cache-test',20,None)]:
 if selected!='all' and name!=selected:continue
 folder=W/'runs'/name/attempt;image=read(W/('ready-'+unit+'.json'));exact(image);save(folder/'image.json',image)
 command=[image['path'],'--gtest_color=no','--gtest_fail_fast','--gtest_output=xml:'+str(folder/'results.xml')]
 if filter_names:command.append('--gtest_filter='+':'.join(filter_names))
 b.s.b.execute(command,folder,300);results[name]=check(folder,count,filter_names)
save(W/('critical-tests-summary.json' if selected=='all' else selected+'-summary.json'),dict(status='PASS',native_processes=len(results),total_GTests=sum(r['tests'] for r in results.values()),skipped=0,results=results))
print('CRITICALPASS',selected,'GTests',sum(r['tests'] for r in results.values()),'skip0',flush=True)
