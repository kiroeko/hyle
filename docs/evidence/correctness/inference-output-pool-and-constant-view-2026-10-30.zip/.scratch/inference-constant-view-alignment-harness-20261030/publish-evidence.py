"""Seal only relevant commands, results and source provenance; no native work."""
from pathlib import Path
import hashlib, json, subprocess, zipfile
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
E = R / 'docs/evidence/correctness'
NAME = 'inference-output-pool-and-constant-view-2026-10-30'
HARNESSES = [R / '.scratch' / n for n in (
    'inference-output-pool-capacity-harness-20261030',
    'inference-glm-ordinary-alias-harness-20261030',
    'inference-constant-view-alignment-harness-20261030')]

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def digest(data):
    return hashlib.sha256(data).hexdigest()

def pin(p):
    b = p.read_bytes()
    return dict(path=str(p.relative_to(R)).replace('\\', '/'), bytes=len(b), sha256=digest(b))

def save(p, d):
    p.write_bytes((json.dumps(d, ensure_ascii=False, indent=2) + '\r\n').replace('\n', '\r\n').replace('\r\r\n', '\r\n').encode('utf-8'))

def stable(v):
    if isinstance(v, dict):
        return {k: stable(x) for k, x in v.items() if not k.endswith(('_seconds', '_per_second'))}
    if isinstance(v, list):
        return [stable(x) for x in v]
    return v

pins = read(R / '.scratch/inference-constant-view-alignment-test-20261030/combined-pending/source-pins.json')
assert len(pins['files']) == 16
for row in pins['files']:
    b = (R / row['path']).read_bytes()
    assert len(b) == row['bytes'] and digest(b) == row['sha256'], row['path']

processes = []
totals = {}
for h in HARNESSES:
    counts = {kind: dict(total=0, passed=0, failed=0) for kind in ('CXX', 'link', 'native')}
    for p in sorted(h.rglob('process.json')):
        d = read(p)
        assert d['state'] == 'TERMINAL' and not d.get('timed_out', False), str(p)
        kind = {'compile': 'CXX', 'link': 'link', 'runs': 'native'}[p.relative_to(h).parts[0]]
        counts[kind]['total'] += 1
        counts[kind]['passed' if d['exit'] == 0 else 'failed'] += 1
        processes.append(dict(kind=kind, exit=d['exit'], seconds=d['seconds'], receipt=pin(p)))
    totals[h.name] = counts
assert len(processes) == 102
assert sum(x['exit'] != 0 for x in processes) == 9
assert all(x['exit'] == 0 for x in processes if x['kind'] != 'native')

for rel, count in [('new3/attempt2', 3), ('cache-all/attempt2', 20), ('related19/attempt3', 19)]:
    x = ET.parse(W / 'runs' / rel / 'results.xml').getroot()
    ts = list(x.iter('testcase'))
    assert len(ts) == count and not list(x.iter('failure')) and not list(x.iter('skipped'))
    assert all(t.get('status') == 'run' and t.get('result') == 'completed' for t in ts)

pool = read(W / 'pool-resume-summary.json')
assert pool['status'] == 'PASS' and pool['passed'] == pool['expected'] == 9
ordinary = read(W / 'ordinary-pair-compare.json')
assert ordinary['status'] == 'PASS' and ordinary['all_recorded_properties_exact']
unit = read(HARNESSES[0] / 'runs/candidate/lease-unit/attempt2/report.json')
assert unit['status'] == 'PASS' and unit['actual_lease_pool'] and unit['native_submissions'] == 0
whole = read(W / 'whole-cli-summary.json')
assert len(whole['checks']) == 4
for check in whole['checks']:
    old, new = [read(Path(check['reports'][a]['path'])) for a in ('baseline', 'candidate')]
    assert stable(old) == stable(new), check['case']

session = read(W / 'session-compare.json')
assert session['payload_byte_equal'] and len(session['payloads']) == 378
roots = [W / 'runs' / a / 'session-cuda/attempt1/vectors' for a in ('baseline', 'candidate')]
for row in session['payloads']:
    bs = [(root / row['relative']).read_bytes() for root in roots]
    assert bs[0] == bs[1]
    for arm, data in zip(('baseline', 'candidate'), bs):
        assert len(data) == row['bytes'] and digest(data) == row[arm + '_sha256']
assert sum(row['bytes'] for row in session['payloads']) == 150761472
observations = [read(root / 'observation.json') for root in roots]
def norm(v, root):
    if isinstance(v, dict): return {k: norm(x, root) for k, x in v.items()}
    if isinstance(v, list): return [norm(x, root) for x in v]
    if isinstance(v, str): return v.replace(str(root), '{VECTORS}')
    return v
assert norm(observations[0], roots[0]) == norm(observations[1], roots[1])
assert (R / '.scratch/mtp-download-budget-20261023/PAUSED').is_file()
save(W / 'root-verification.json', dict(status='PASS', current_sources=16,
    graph_tests=42, graph_skipped=0, default_pairs=4,
    direct_session_payload_readback=756, bytes_per_arm=150761472,
    session_observation_normalization='Only absolute output root; exact dict equality including key presence.',
    all_102_processes_terminal=True, historical_native_failures=9, downloads_paused=True))
save(W / 'process-ledger.json', dict(totals=totals, processes=processes))

files = set()
for h in HARNESSES:
    files.update(p for p in h.iterdir() if p.is_file() and p.suffix in ('.json', '.py', '.md'))
    for dirname in ('compile', 'link', 'runs'):
        for p in (h / dirname).rglob('*'):
            if not p.is_file() or p.name == 'environment.json': continue
            if any(part in ('vectors', 'probes') for part in p.relative_to(h).parts): continue
            if p.suffix in ('.json', '.xml', '.log') and p.name != 'dependencies.json': files.add(p)
for root in roots: files.add(root / 'observation.json')
for rel in (
    '.scratch/inference-glm-ordinary-alias-20261030/alias-propagation-diagnostic.patch',
    '.scratch/inference-glm-ordinary-alias-20261030/m1/m1-constant-view.patch',
    '.scratch/inference-glm-ordinary-alias-20261030/m1/plan.json',
    '.scratch/inference-glm-ordinary-alias-20261030/m1-design.md',
    '.scratch/inference-constant-view-alignment-test-20261030/combined-pending/pending-current-source.patch',
    '.scratch/inference-constant-view-alignment-test-20261030/combined-pending/source-pins.json',
    '.scratch/inference-output-pool-capacity-20261030/unit-range-bound-clarification/applied.json',
    '.scratch/inference-constant-view-alignment-test-20261030/borrowed-logical-read/applied.json',
):
    p = R / rel
    assert p.is_file(), rel
    files.add(p)
archive = E / (NAME + '.zip')
assert not archive.exists()
manifest = [pin(p) for p in sorted(files)]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(files): z.write(p, p.relative_to(R).as_posix())
    z.writestr('archive-manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist()) == len(manifest) + 1
    for row in manifest:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        assert data == (R / row['path']).read_bytes()

diagnostic = read(HARNESSES[1] / 'diagnostic-result.json')
summary = dict(schema='hyle-inference-output-pool-and-constant-view-v1',
    status='CURRENT_FINITE_CHECKS_PASS_HISTORICAL_FAILURES_RETAINED',
    base_commit=pins['base'], full_goal_complete=False,
    implementation=dict(
        output_capacity='Pure checked per-output alignment/add/multiply/block-count arithmetic; model copies, storage, budgets, alignment and LeasePool ownership remain at each caller. Arithmetic success does not certify allocator metadata/resource admission.',
        odd_vocabulary='Actual LeasePool unit reproduces V65 F32 two-block old521-byte refusal and aligned1024-byte success. Qwen uses actual prepared output descriptor and retains its +1 tail; no real V65 model run.',
        constant_view='Only a by-value reader of an unaligned static immutable constant View gets an independent cold canonical representation. Original borrow/root/published alias stays intact; cache keys include root/offset/exact description/resource/alignment. Existing CopyBatch ready gate and retained source lifetime are reused, no per-token Copy.',
        qualification='Native-bearing resource/transfer qualification errors retain original code/native/message. Budget refusal/retry and finite variants use original ownership.',
        fixture_repairs='Three old observer/factory reads now explicitly narrow initialized storage to logical description; old baseline independently fails both affected tests. Private cache fixture now fills required roles/alias arrays. Production Tensor/Buffer contracts and assertion values remain unchanged.'),
    build=dict(totals=totals, retained_inputs=231, reused=222, recompiled_SDK=9,
        private_layout='CanonicalConstantKey changes private cache state layout: all9 reachable SDK translation units rebuilt; no mixing of old/new private layouts.',
        dependency_boundary='162 actual SDK dep receipts plus repository include reachability;69 unchanged native/lib inputs have no full source-dependency metadata.',
        NVCC=0, downloads=0),
    current_checks=dict(graph_new=3, graph_cache=20, graph_related=19, graph_skipped=0,
        pool_cases=11, components=8, component_GTest_skipped=0, qwen_tool_cases=2, actual_LeasePool_unit=True,
        ordinary_control_properties_per_arm=24, ordinary_control_all_exact=True,
        default_full_vocabulary_pairs=4, default_non_timing_fields_exact=True,
        session_files_per_arm=378, session_bytes_per_arm=150761472,
        session_all_bytes_exact=True, session_final_live_versions=0,
        observed_cold_summary=read(W / 'existing-plan-summary-comparison.json')),
    diagnostic=dict(original_Graph_source=diagnostic['original_Graph_source'], actual_message=diagnostic['messages'], M2_applied=False),
    history=dict(native_failures=9, failed_processes=[x for x in processes if x['exit'] != 0],
        scratch_errors=['Pre-dispatch Python quoting syntax, corrected before native dispatch.', 'Offline Qwen history JSON schema parser; native exit0 preserved and postprocessed without rerun.'],
        attempts='All102 actual processes preserved;30CXX/36links pass,27native pass/9historical native fail. Current selected logical checks pass; historical skip/fail XML is kept.'),
    default_timing_diagnostic=[dict(case=x['case'], **x['timing_diagnostic']) for x in whole['checks']],
    scope='Finite CPU/single-GPU components and current Qwen full consumer checks. Single fresh timing pair per default case is only a gross-regression observation, no speedup or full performance window claim. No second complete engine model, multi-card, Mac, whole default CMake build, full-model V65 or M2 validation.',
    source_pins=pins['files'], archive=dict(**pin(archive), members=len(manifest)+1, full_readback_verified=True))
save(E / (NAME + '.json'), summary)
print(json.dumps(dict(status=summary['status'], archive=summary['archive'], process_count=102), ensure_ascii=False))
