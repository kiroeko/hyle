"""Only exact cached CXX/link arrays; freeze/execute waits for root authorization."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
OLD=R/'.scratch/inference-output-pool-capacity-harness-20261030'
spec=importlib.util.spec_from_file_location('constant_view_recipes',OLD/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
baseline=read(W/'baseline-plan.json');base=read(baseline['base']['path']);units={};replace={}
def relocated(raw,name,source):
 folder=W/'compile'/name/'attempt1';command=[];sources=0
 for index,arg in enumerate(raw):
  if index and raw[index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
  elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
  elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
  elif key(arg)==key(source):sources+=1
  command.append(arg)
 assert sources==1 and '/c' in [a.lower() for a in command]
 assert len([a for a in command if a.lower().endswith('.cc')])==1
 return command
for row in baseline['affected_retained']:
 source=Path(row['source']);name='sdk-'+source.stem.replace('_','-')
 raw,origin=b.s.command_for(row['object'],row['source'])
 units[name]=dict(source=row['source'],compile=relocated(raw,name,source),origin=origin,
  original_object=next(i for i in base['retained'] if key(i['path'])==key(row['object'])),object=str(W/'compile'/name/'attempt1/unit.obj'))
 replace[key(row['object'])]=units[name]['object']
region_receipt=read(base['current_consumers']['region']['receipt']['path']);region_command=Path(region_receipt['process']['path']).parent/'command.json'
cache_command=R/'.scratch/inference-storage-freeze-20261026/compile/test/command.json'
for name,source,recipe in [('region-test',R/'tests/graph/region_provider_test.cc',region_command),
 ('constant-cache-test',R/'tests/graph/constant_artifact_cache_test.cc',cache_command)]:
 raw=read(recipe);raw=raw if isinstance(raw,list) else raw['command']
 units[name]=dict(source=str(source),compile=relocated(raw,name,source),origin=pin(recipe),object=str(W/'compile'/name/'attempt1/unit.obj'))
assert len(units)==11 and len(replace)==9
libraries=read(OLD/'plan.json')['gtest_libraries'];cli=base['current_consumers']['cli']['object']['path']
links={}
for name in ('region-test','constant-cache-test'):
 args=[];consumer_count=0;replacement_count=0
 for arg in base['link']:
  if key(arg)==key(cli):arg=units[name]['object'];consumer_count+=1
  elif key(arg) in replace:arg=replace[key(arg)];replacement_count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 for library in libraries:
  if library['path'] not in args:args.append(library['path'])
 assert consumer_count==1 and replacement_count==9
 assert all(old not in {key(a) for a in args} for old in replace)
 links[name]=args
save(W/'recipes-prepared.json',dict(status='PREPARED_ONLY_NO_EXECUTION',units=units,links=links,SDK_CXX=9,test_CXX=2,consumer_CXX=0,
 retained_count=231,replacement_count=9,unchanged_count=222,base=baseline['base'],runtime=baseline['runtime'],gtest_libraries=libraries,
 unavailable_dependency_scope='69native/library entries preserved; direct private-header include references confined to the9actual SDK CXX files (plus plan_state.h itself), not public/engine/native kernel headers.',
 max_compilers=2,NVCC=0,downloads=0,CXX_executed=0,links_executed=0,native_executed=0))
print(json.dumps(dict(status='RECIPES_READY',SDK_CXX=9,test_CXX=2,retained_after_replacement=231,unaffected_old_inputs=222,executed=0)))
