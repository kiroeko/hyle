"""Reuse Phase native parser/execute for root-authorized fresh fullV pairs."""
from pathlib import Path
import importlib.util,json,sys
W=Path(__file__).resolve().parent;R=W.parents[1];PHASE=R/'.scratch/inference-phase-preparation-harness-20261030'
spec=importlib.util.spec_from_file_location('phase_default_native',PHASE/'run-native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
n.W=W;n.R=R;n.h.s.b.W=W
read,save,pin=n.read,n.save,n.pin
plan=read(W/'default-plan.json');names=sys.argv[1:] or list(plan['cases'])
for case in names:
 row=plan['cases'][case]
 for arm in ('baseline','candidate'):n.run(case,row,arm)
 if case=='session-cuda':continue
 old=read(W/'runs/baseline'/case/'attempt1/report.json');new=read(W/'runs/candidate'/case/'attempt1/report.json')
 differences=n.delta(n.stable(old),n.stable(new))
 save(W/('compare-'+case+'.json'),dict(status='PASS' if not differences else 'FAIL',differences=differences,
  baseline_or_retained_reference=pin(W/'runs/baseline'/case/'attempt1/report.json'),candidate=pin(W/'runs/candidate'/case/'attempt1/report.json'),
  excluded_fields='Only dict keys ending _seconds or _per_second; every resource/work/unknown field retained.'))
 assert not differences,differences
 print('DEFAULTPAIRPASS',case,flush=True)
