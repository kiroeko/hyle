"""No native rerun: retain and validate both original complete history JSON schemas."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('history_postprocess_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
folder=W/'runs/candidate/qwen-history-cpu/attempt1';process=b.read(folder/'process.json');assert process['exit']==0
text=(folder/'stdout.log').read_text(encoding='utf-8-sig');decoder=json.JSONDecoder();offset=0;values=[]
while offset<len(text):
 while offset<len(text) and text[offset].isspace():offset+=1
 if offset==len(text):break
 value,offset=decoder.raw_decode(text,offset);values.append(value)
assert len(values)==2
math,history=values;assert math['case']=='history-finite-math' and math['result']=='PASS'
assert all(value for value in math.values() if isinstance(value,bool))
assert history['status']=='PASS' and history['case']=='history-logits' and history['final_versions']==0
for key in ('K1_K2_greedy_random','derived_vs_manual_B2','StateOnly_no_counts_or_draw','same_key_HostImage','full_hit_seed_before_frontier'):assert history[key] is True
for row in history['state_checks']:
 for key in ('boundary_equal','payloads_byte_equal','numerically_equivalent'):
  if key in row:assert row[key] is True
 if 'differences' in row:assert not row['differences']
b.save(W/'qwen-history-parser-attempt1-error.json',dict(stage='OFFLINE_POSTPROCESS_SCHEMA',native_exit=0,native_failed=False,
 error='Old reused generic parser required status:PASS on history-finite-math, whose existing schema uses result:PASS.',
 correction='raw_decode both complete JSON values, require result:PASS finite math and status:PASS history, preserve both plus every unknown field. No native rerun.',
 source_stdout=b.pin(folder/'stdout.log')))
b.save(folder/'report.json',dict(status='PASS',reports=values,full_stdout_preserved=True,complete_JSON_values=2))
print('HISTORY_POSTPROCESS_PASS:2fullJSON,0native_rerun',flush=True)
