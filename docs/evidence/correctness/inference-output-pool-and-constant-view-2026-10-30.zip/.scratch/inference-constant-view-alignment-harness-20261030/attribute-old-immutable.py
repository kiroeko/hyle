"""Root-approved zero-CXX oldABI/oldregion one-case attribution."""
from pathlib import Path
import importlib.util,json,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('old_immutable_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
base_path=R/'.scratch/inference-phase-preparation-harness-20261030/model-link-base.json';base=read(base_path)
row=base['current_consumers']['region'];exact(row['receipt']);region=read(row['receipt']['path']);exact(region['object'])
old_source=next(i for i in region['source_identities'] if key(i['path'])==key(R/'tests/graph/region_provider_test.cc'))
assert old_source['sha256']=='6940e11eab659c5eb485aa952029cff610ce2ae324457af4c4332b4f70f86c00'
snapshot=W/'baseline-source/tests/graph/region_provider_test.cc';assert pin(snapshot)['sha256']==old_source['sha256']
old_header=next(i for i in region['source_identities'] if key(i['path'])==key(R/'src/graph/constant_artifact.h'))
header_snapshot=W/'baseline-source/src/graph/constant_artifact.h';assert pin(header_snapshot)['sha256']==old_header['sha256']
for item in [*base['retained'],base['runtime']]:exact(item)
old=base['current_consumers']['cli']['object']['path'];command=[];replaced=0
for arg in base['link']:
 if key(arg)==key(old):arg=region['object']['path'];replaced+=1
 for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
  if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/baseline-region-oldcore').with_suffix(suffix));break
 command.append(arg)
for lib in read(W/'plan.json')['gtest_libraries']:
 if lib['path'] not in command:command.append(lib['path'])
assert replaced==1 and sum(any(key(a)==key(i['path']) for a in command) for i in base['retained'])==231
save(W/'old-immutable-binding.json',dict(base=pin(base_path),retained=base['retained'],old_region_receipt=row['receipt'],old_region=region['object'],
 old_region_source=old_source,old_region_source_snapshot=pin(snapshot),old_private_header=old_header,old_header_snapshot=pin(header_snapshot),CXX=0,
 scope='Old231 and region6940 original private ABI, no M1 SDK object mixed. Current product source not rolled back.'))
b.s.b.execute(command,W/'link/baseline-region-oldcore/attempt1',240)
image=pin(W/'bin/baseline-region-oldcore.exe');folder=W/'runs/baseline-old-immutable/attempt1';save(folder/'image.json',image)
name='GraphRegions.ImmutableConstantViewsPreserveDenseReshapeAndSliceBindings'
try:b.s.b.execute([image['path'],'--gtest_color=no','--gtest_fail_fast','--gtest_filter='+name,'--gtest_output=xml:'+str(folder/'results.xml')],folder,300)
except SystemExit:pass
process=read(folder/'process.json');x=ET.parse(folder/'results.xml').getroot();ts=list(x.iter('testcase'));assert len(ts)==1 and not list(x.iter('skipped'))
messages=[f.get('message') for f in x.iter('failure')]
save(W/'old-immutable-attribution.json',dict(status='OLD_CASE_PASS' if process['exit']==0 else 'OLD_CASE_FAIL',native_exit=process['exit'],tests=1,skipped=0,messages=messages,
 source_body='Frozen region6940 on frozen231 oldCanonicalState ABI',binding=pin(W/'old-immutable-binding.json'),current_M1_error='read size must equal buffer view size',product_unchanged=True))
print(json.dumps(read(W/'old-immutable-attribution.json')),flush=True)
