"""Explicit19 CPU regression selection; no fullGraph matrix."""
from pathlib import Path
import importlib.util,json,re,sys,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('m1_regression_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
all_names=[a+'.'+c for a,c in re.findall(r'TEST(?:_F)?\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',(R/'tests/graph/region_provider_test.cc').read_text())]
new=[a+'.'+c for a,c in re.findall(r'TEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',(R/'.scratch/inference-constant-view-alignment-test-20261030/addition.cc').read_text())]
extra=['GraphRegions.'+n for n in ['ImmutableConstantViewsPreserveDenseReshapeAndSliceBindings','ConstantViewOffsetsSeparateFiniteVariantArtifacts','ConstantViewPreparationKeepsEachPhysicalRootOwner','DomainConstantViewChecksActualPortAlignmentBeforeEnqueue','DynamicAndUnownedViewsDoNotAcquireQueuedArtifacts','UnknownMaterializationObservationRetainsOwnersUntilNativeRetirement','OwnerlessSystemMaterializationRetainsLeaseUntilNativeRetirement','QueuedMaterializationRejectsRawSourceBeforeCopy']]
names=[n for n in all_names if (n.startswith(('GraphConstants.','GraphPacking.')) or n in extra) and n not in new];assert len(names)==19
filter_value=':'.join(names);save(W/'regression-plan.json',dict(filter=filter_value,expected_tests=19,tests=names,excluded_already_passed_new3=new))
attempt=sys.argv[1] if len(sys.argv)>1 else 'attempt1'
folder=W/'runs/related19/attempt;image=read(W/'ready-region-test.json');exact(image);save(folder/'image.json',image)
b.s.b.execute([image['path'],'--gtest_color=no','--gtest_fail_fast','--gtest_filter='+filter_value,'--gtest_output=xml:'+str(folder/'results.xml')],folder,300)
x=ET.parse(folder/'results.xml').getroot();tests=list(x.iter('testcase'));assert len(tests)==int(x.get('tests','-1'))==19
assert int(x.get('failures','-1'))==0 and int(x.get('errors','0'))==0 and not list(x.iter('skipped'))
assert all(t.get('status')=='run' and t.get('result')=='completed' for t in tests)
assert set(t.get('classname')+'.'+t.get('name') for t in tests)==set(names)
save(W/'regression-summary.json',dict(status='PASS',tests=19,failures=0,skipped=0,xml=pin(folder/'results.xml'),filter=filter_value))
print('RELATED19PASSskip0',flush=True)
