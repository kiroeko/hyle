"""Reusable current private-ABI closure; finite results do not attest all engine cases."""
from pathlib import Path
import copy,importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('m1_seal_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
assert read(W/'ordinary-pair-compare.json')['status']=='PASS'
assert read(W/'new3-summary.json')['total_GTests']==3 and read(W/'cache-all-summary.json')['total_GTests']==20
plan=read(W/'plan.json');base=read(plan['base']['path']);replacement={};receipt_by_name={}
for name,unit in plan['units'].items():
 p=W/'compile'/name/'receipt.json';receipt=read(p)
 for item in [receipt['object'],*receipt['source_identities']]:exact(item)
 receipt_by_name[name]=dict(receipt=pin(p),object=receipt['object'])
 if name.startswith('sdk-'):replacement[key(unit['original_object']['path'])]=receipt
assert len(replacement)==9
retained=[replacement[key(i['path'])]['object'] if key(i['path']) in replacement else i for i in base['retained']]
assert len(retained)==len({key(i['path']) for i in retained})==231
for item in retained:exact(item)
sdk=copy.deepcopy(read(base['sdk_engine_dependencies']['path']));replaced=0
for row in sdk['inspected']:
 if key(row['object']) in replacement:
  receipt=replacement[key(row['object'])];row['object']=receipt['object']['path'];row['dependencies']=receipt['dependencies'];replaced+=1
assert replaced==9
sdk['historical_changed_library_objects']=sdk.get('historical_changed_library_objects',[])+[dict(before_M1=sdk.get('changed_library_objects',[]))]
sdk['changed_library_objects']=[dict(module='graph_progress' if n=='sdk-progress' else 'graph',source=plan['units'][n]['source'],**row) for n,row in receipt_by_name.items() if n.startswith('sdk-')]
sdk['scope']='Current M1 privateCanonicalKey/State ABI:9 actual transitive SDK consumers rebuilt,222 native/library/other inputs reused.162 current metadata rows/69 historically unavailable native/library entries.'
save(W/'sdk-engine-dependencies.json',sdk)
current={};old={}
for name,row in base['current_consumers'].items():
 exact(row['receipt']);exact(row['object']);receipt=read(row['receipt']['path'])
 mismatch=[item for item in receipt['source_identities'] if not Path(item['path']).is_file() or pin(item['path'])!=item]
 if mismatch:old[name]=dict(**row,status='HISTORICAL_NOT_CURRENT',mismatched_source_pins=mismatch)
 else:current[name]=row
current['region']=receipt_by_name['region-test'];current['constant-cache-test']=receipt_by_name['constant-cache-test']
historical=copy.deepcopy(base['historical_consumers']);historical['before-M1-private-layout']=old
link=[]
for arg in base['link']:
 if key(arg) in replacement:arg=replacement[key(arg)]['object']['path']
 for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
  if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/cli').with_suffix(suffix));break
 link.append(arg)
save(W/'model-link-base.json',dict(schema='hyle.current-model-link-base.v1',base=plan['base'],compile=base['compile'],link=link,
 consumer_source=base['consumer_source'],previous_consumer=base['current_consumers']['cli']['object']['path'],
 retained=retained,runtime=base['runtime'],sdk_engine_dependencies=pin(W/'sdk-engine-dependencies.json'),current_consumers=current,historical_consumers=historical,
 retained_categories=dict(SDK_and_engine=227,model_cold_objects=4,total_retained=231,old_reused=222,replaced_private_ABI_SDK=9,new_objects=0),
 model_cold_objects=base['model_cold_objects'],current_compile_only=base['current_compile_only'],
 note='Current M1 core and current header-only output-pool consumers, all private-State consumers recompiled. CLI/Session images may be zero-CXX linked; no core-wide default/Session native proof is implied by this base.'))
save(W/'build-closure-proof.json',dict(retained=231,reused=222,recompiled_SDK=9,SDK_receipts={n:r for n,r in receipt_by_name.items() if n.startswith('sdk-')},
 source_layout_header=pin(R/'src/graph/constant_artifact.h'),test_receipts={n:r for n,r in receipt_by_name.items() if not n.startswith('sdk-')},
 public_output_pool_consumers_reused=12,private_region_recompiled=True,private_cache_test_recompiled=True,default_CMake_full_build=False,
 limits='Only current9SDK ABI closure and current finite critical validation; not every model/route/platform. No5arg-wrapper layout ABI mixing.'))
print('CURRENT231_BASE_READY:9SDKreplaced,222reused;no new execution',flush=True)
