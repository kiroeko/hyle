"""Reuse original output-pool parser/runner, current9SDK-relinked images only."""
from pathlib import Path
import importlib.util,json,sys
W=Path(__file__).resolve().parent;R=W.parents[1];OLD=R/'.scratch/inference-output-pool-capacity-harness-20261030'
spec=importlib.util.spec_from_file_location('pool_native_reuse',OLD/'run-native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
n.W=W;n.R=R
read,save,pin=n.read,n.save,n.pin
names=['glm-pro-cuda','glm-carry-cpu','ds-pro-cpu','ds-original-cpu','ds-history-cpu','ds-target-original-cpu','kimi-cuda','qwen-history-cpu','qwen-mtp-logits-cuda']
path=W/'run-plan.json'
if not path.exists():
 plan=read(OLD/'run-plan.json');plan['cases']={name:plan['cases'][name] for name in names}
 for name,row in plan['cases'].items():
  row['command'][0]=str(W/'bin'/(row['unit']+'.exe'))
  row['command']=[a for a in row['command'] if not a.startswith('--gtest_output=')]
  if 'filter' in row:row['command'].append('--gtest_output=xml:'+str(W/'runs/candidate'/name/'attempt1/results.xml'))
 plan['scope']='Root-authorized remaining8 plus GLMPro on newcore. No repeated ordinary/unit, no new CXX.';save(path,plan)
plan=read(path);chosen=sys.argv[1:] or names
assert all(name in names for name in chosen)
for name in chosen:
 n.run(name,plan['cases'][name])
reports={name:pin(W/'runs/candidate'/name/'attempt1/report.json') for name in names if (W/'runs/candidate'/name/'attempt1/report.json').exists()}
save(W/'pool-resume-summary.json',dict(status='PASS' if len(reports)==len(names) else 'PARTIAL_PASS',passed=len(reports),expected=9,reports=reports,
 scope='Current9SDK, each original remaining case once. CPU/GPU original scopes; no whole-model/performance claim.'))
print('POOL_CURRENTCORE_PASS',len(reports),'of9',flush=True)
