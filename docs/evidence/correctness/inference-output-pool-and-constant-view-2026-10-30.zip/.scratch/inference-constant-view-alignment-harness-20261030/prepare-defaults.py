"""Reuse the finite Phase default/Session plan and exact frozen old231; no native."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1];PHASE=R/'.scratch/inference-phase-preparation-harness-20261030'
spec=importlib.util.spec_from_file_location('m1_default_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
old=read(PHASE/'model-link-base.json');source=read(PHASE/'run-plan.json')['cases'];cases={name:source[name] for name in ('ordinary-single','mtp-single','ordinary-two','mtp-two','session-cuda')}
assert len(old['retained'])==231
for item in [*old['retained'],old['runtime']]:exact(item)
for name in ('cli','session'):
 row=old['current_consumers'][name];exact(row['receipt']);exact(row['object'])
 save(W/('old-'+name+'-identity.json'),dict(receipt=row['receipt'],object=row['object'],source_proof='Original Phase sourcepins/frozen HEAD74a. Old main2b227 is snapshotted before pool changes; privateKey4a97 old layout matches old231. Current product source is not mislabeled as baseline.'))
main=R/'.scratch/inference-output-pool-capacity-harness-20261030/baseline-source/engine/models/qwen35/main.cc'
assert pin(main)['sha256']=='2b227de1c0211c64a4a0ce701144a6908bd68be95aa80b4f6235a3f1a1acdca1'
save(W/'default-plan.json',dict(cases=cases,old_base=pin(PHASE/'model-link-base.json'),old_retained=old['retained'],old_consumers={n:old['current_consumers'][n] for n in ('cli','session')},
 old_source_main_snapshot=pin(main),source_plan=pin(PHASE/'run-plan.json'),native_count=10,
 cpu2_candidate=source['cpu-ffn-real-cuda'],cpu2_retained_reference=str(PHASE/'runs/candidate/cpu-ffn-real-cuda/attempt1/report.json'),
 scope='Four fresh default fullV pairs plus completeSession pair; oldPhase/old231 vs currenthelper/currentM1nineSDK. One optional CPU2 candidate against retained report. No performancewindow.'))
print('DEFAULTS_PREPARED:8CLI+2Session,source-pinned old231;0native',flush=True)
