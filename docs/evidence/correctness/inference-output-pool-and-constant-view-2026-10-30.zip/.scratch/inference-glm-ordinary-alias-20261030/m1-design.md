# M1：不可变 View 的冷期对齐表示（scratch候选，未应用/构建）

实际失败：pre_constants，physical57/logical60 是 root5/logical5 的 constant metadata View，偏移4B；reader node23/port1 给该实例256B要求。它通过原 constant-root input 检查，随后统一别名传播拒绝。当前证据尚无 node23 的实际 operation/provider 或 root5 的权重角色；这是某个递归构造的本地图，不能据 ordinal 猜全图权重。

现 `acquire_canonical` 只接受 logical constant slot 的同描述物理根；其缓存 key 不含原切片 offset，不能直接拿 root5 的 slot 存 logical60。应扩展现 canonical 机制，而非降低256或全局跳过 alias 检查。

最小正确改动拟限 `executable.cc`、`constant_artifact.h/.cc`：

1. 在原 `ConstantPreparation` 加 compile-local derived-view origin 表 `{physical_instance, root_slot, checked_root_offset}`，每次 route attempt 清空。不加 Plan/Invocation owner或新payload缓存。
2. 原 by-value input admission 遇 static immutable View、实际累计偏移不满足 reader alignment，且根可追到原 constant slot 时，创建同 logical value/目标storage 的 kConstant、零alias physical replica。原producer/View、external实例、原Borrow binding/owner/lease均不改；reference input仍读原producer；domain动态offset保原路径。
3. `needs_canonical_constant`/retained-owner lookup/`materialize_constants` 消费原表；从原root binding取 checked subview 与实际描述。原 `ConstantCopyBatch`、source ready lease/owner、storage charge、native scratch、失败与退休、ready标记及 `prepared_values` 全复用。Plan没有新kCopy，热 replay不复制。
4. canonical key 表示 `{logical value, original source root, root-relative offset, exact description, resource, alignment}`。原root copy是 root=self/offset0。finite variant同logical value不同offset不能误用。重试按此完整key找ready owner；不按旧physical ordinal复用。
5. region常量准备从新owner key恢复原root+offset，继续给现 `RegionConstantOrigin`；否则派生根被误当普通node输出而漏packing。CompileConstantReport将额外canonical bytes计给原root slot，原root政策仍Borrow。`owned_constant(slot)`仍nullptr，而 `owned_instance_constant(replica)`有值。

不在此修M2 optional inplace；不改search cap。经root授权，现cold transfer三处纯资格分支补native-bearing Status直传，不把它当不支持继续换target；真正纯无能力继续原cold-route decline/error。接受/retire序列不变，不默许每token Copy。保原5参私有导出wrapper，但Key布局仍要求全部实际依赖同头重编。

检查以现 `GraphConstants.BorrowedReplicasKeepViewOffsetsAndNeverCopyAtReplay`、`GraphRegions.ImmutableConstantViewsPreserveDenseReshapeAndSliceBindings`、`ConstantViewOffsetsSeparateFiniteVariantArtifacts`、`ConstantViewPreparationKeepsEachPhysicalRootOwner` 为基准，增加同域4B切片/strict256两读者（原alias与aligned replica）、两slot/reset重放无新coldcopy、原Borrow root handle不变、finite不同offset、预算与copy失败不ready/重试。queued raw source拒绝与unknown observation保原回归。真实GLM case最后验证，不把unit代签实际组件。
