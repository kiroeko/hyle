"""Root-authorized byte-exact old ordinary body/current231 one-process attribution."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('attribution_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
plan=read(W/'baseline-ordinary-attribution-prepared.json')
exact(plan['source']);exact(plan['original_snapshot'])
assert Path(plan['source']['path']).read_bytes()==Path(plan['original_snapshot']['path']).read_bytes()
for item in read(W/'plan.json')['retained']:exact(item)
folder=W/'compile/baseline-glm-ordinary/attempt1';b.s.b.execute(plan['compile'],folder,900)
dep=read(folder/'dependencies.json')['Data'];paths=sorted({Path(p).resolve() for p in [dep['Source'],*dep['Includes']] if Path(p).is_relative_to(R)})
assert not any(p==R/'engine/inference/output_pool_capacity.h' for p in paths),'Unexpected new helper in old-body closure'
save(W/'compile/baseline-glm-ordinary/receipt.json',dict(object=pin(folder/'unit.obj'),dependencies=pin(folder/'dependencies.json'),
 process=pin(folder/'process.json'),source_identities=[pin(p) for p in paths],byte_exact_old_TU=plan['source'],
 original_source_snapshot=plan['original_snapshot'],new_capacity_helper_absent=True))
b.s.b.execute(plan['link'],W/'link/baseline-glm-ordinary/attempt1',240)
save(W/'ready-baseline-glm-ordinary.json',pin(W/'bin/baseline-glm-ordinary.exe'))
spec=importlib.util.spec_from_file_location('attribution_native',W/'run-native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
row=dict(read(W/'run-plan.json')['cases']['glm-ordinary-cuda']);row['unit']='baseline-glm-ordinary'
row['command']=[str(W/'bin/baseline-glm-ordinary.exe')]+[a for a in row['command'][1:] if not a.startswith('--gtest_output=')]
row['command'].append('--gtest_output=xml:'+str(W/'runs/candidate/baseline-glm-ordinary-cuda/attempt1/results.xml'))
try:n.run('baseline-glm-ordinary-cuda',row)
except AssertionError:
 # Preserve native refusal as a real failed process; the receipt below is attribution, not PASS.
 process=read(W/'runs/candidate/baseline-glm-ordinary-cuda/attempt1/process.json')
 if process['exit']==0:raise
candidate=W/'runs/candidate/glm-ordinary-cuda/attempt1';baseline=W/'runs/candidate/baseline-glm-ordinary-cuda/attempt1'
needle='ordinary connected NextN Graph: graph search exhausted after a rejected candidate: graph alias offset cannot satisfy provider port alignment: graph route search state budget is exhausted'
same=all(needle in (p/'stdout.log').read_text(encoding='utf-8') for p in (candidate,baseline))
save(W/'ordinary-attribution-result.json',dict(status='ATTRIBUTION_COMPLETE_NOT_REPAIRED',
 candidate_exit=read(candidate/'process.json')['exit'],baseline_exit=read(baseline/'process.json')['exit'],same_first_error=same,first_error=needle,
 baseline_source=plan['source'],baseline_receipt=pin(W/'compile/baseline-glm-ordinary/receipt.json'),same_retained231=True,
 new_capacity_helper_absent_from_baseline=True,scope='Old body on current repaired Graph/core. Shared failure does not exclude a locally repairable lower-layer defect; remaining native queue still paused.'))
print(json.dumps(read(W/'ordinary-attribution-result.json')),flush=True)
