"""Bounded output-pool validation: original component assertions, no acquisition/wait."""
from pathlib import Path
import importlib.util,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('pool_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
def prepare():
 assert not (W/'run-plan.json').exists()
 plan=read(W/'plan.json');suggested=plan['minimal_native_cases']|plan['optional_native_cases'];cases={}
 for unit in ('glm-pro','glm-ordinary','glm-carry','ds-pro','ds-original','ds-history','ds-target','kimi','tiny','lease-unit'):
  name=plan['changed_consumer_one_case'][unit];row=dict(suggested[name]);row['unit']=unit;cases[name]=row
 ga=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
 cases['qwen-mtp-logits-cuda']=dict(unit='tiny',command=[plan['units']['tiny']['binary'],'--cuda',str(ga),'--mtp-logits'])
 for name,row in cases.items():
  row['command']=[a for a in row['command'] if not a.startswith('--gtest_output=')]
  if 'filter' in row:row['command'].append('--gtest_output=xml:'+str(W/'runs/candidate'/name/'attempt1/results.xml'))
 assert len(cases)==11
 save(W/'run-plan.json',dict(cases=cases,environments=plan['environments'],always_environment=plan['always_environment'],
  clear_frontier_request_environment=plan['clear_frontier_request_environment'],
  scope='Root authorized each changed component one original case, Qwen CPU history and CUDA MTP modifiers, real LeasePool unit. CLI/Session compile only. No Phase/default/Session native rerun.'))
def parse(name,row,folder):
 if 'filter' in row:
  tree=ET.parse(folder/'results.xml').getroot();tests=list(tree.iter('testcase'))
  expected=row['tests'];assert len(tests)==expected,(name,len(tests),expected)
  assert int(tree.get('tests','-1'))==expected and int(tree.get('failures','-1'))==0 and int(tree.get('errors','0'))==0 and int(tree.get('disabled','0'))==0
  assert all(t.get('status')=='run' and t.get('result')=='completed' and not list(t.iter('failure')) and not list(t.iter('skipped')) for t in tests)
  report=dict(status='PASS',tests=len(tests),failures=0,errors=0,skipped=0,
   actual_tests=[t.get('classname')+'.'+t.get('name') for t in tests],xml=pin(folder/'results.xml'))
 else:
  text=(folder/'stdout.log').read_text(encoding='utf-8-sig');decoder=json.JSONDecoder();offset=0;values=[]
  while offset<len(text):
   while offset<len(text) and text[offset].isspace():offset+=1
   if offset==len(text):break
   value,offset=decoder.raw_decode(text,offset);values.append(value)
  assert values and all(v.get('status')=='PASS' for v in values),(name,'PASS report required')
  report=values[0] if len(values)==1 else dict(status='PASS',reports=values)
 save(folder/'report.json',report);return report
def run(name,row):
 folder=W/'runs/candidate'/name/'attempt1'
 if (folder/'process.json').exists():
  assert name=='lease-unit','Preserve prior attempts; never silently rerun.'
  assert read(folder/'process.json')['exit']==0
  return parse(name,row,folder)
 image=read(W/('ready-'+row['unit']+'.json'));exact(image)
 command=row['command'];assert command[0]==image['path'];save(folder/'image.json',image)
 env=os.environ.copy();env.update(read(b.s.b.OLD/'environment.json'))
 for variable in read(W/'run-plan.json')['clear_frontier_request_environment']:env.pop(variable,None)
 env.update(read(W/'run-plan.json')['always_environment'])
 env.update(read(W/'run-plan.json')['environments'].get(row.get('env'),{}))
 env['PATH']=str(W/'bin')+';'+env['PATH'];temporary=W/'tmp';temporary.mkdir(exist_ok=True);env['TEMP']=env['TMP']=str(temporary)
 assert all(value=='0' for variable,value in env.items() if variable.startswith('HYLE_') and 'WAIT_FOR_EXPERTS' in variable)
 folder.mkdir(parents=True,exist_ok=True);save(folder/'command.json',command)
 save(folder/'environment.json',{k:v for k,v in env.items() if k.startswith(('HYLE_','HF_','TRANSFORMERS_'))})
 started=time.time()
 with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
  p=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  save(folder/'process.json',dict(state='RUNNING',pid=p.pid,started=started));print('RUNNING',p.pid,name,flush=True)
  timed_out=False
  try:code=p.wait(timeout=900)
  except subprocess.TimeoutExpired:timed_out=True;p.kill();code=p.wait()
 save(folder/'process.json',dict(state='TERMINAL',pid=p.pid,started=started,seconds=time.time()-started,exit=code,timed_out=timed_out))
 assert code==0 and not timed_out,(name,'Native failed; preserve logs and stop',code)
 report=parse(name,row,folder);print('PASS',name,flush=True);return report
def main():
 if sys.argv[1]=='prepare':prepare();return
 plan=read(W/'plan.json')
 for unit in plan['units']:
  exact(read(W/('ready-'+unit+'.json')))
  assert read(W/'compile'/unit/'attempt1/process.json')['exit']==0
 runplan=read(W/'run-plan.json');results={}
 for name,row in runplan['cases'].items():
  if sys.argv[1]=='run-components' and name=='lease-unit':continue
  if sys.argv[1]=='run-selected' and name not in sys.argv[2:]:continue
  results[name]=run(name,row)
 component_only=sys.argv[1]=='run-components';selected=sys.argv[1]=='run-selected'
 save(W/('native-summary-selected.json' if selected else 'native-summary-components.json' if component_only else 'native-summary.json'),dict(status='PASS',native_processes=len(results),GTest_cases=sum('tests' in report for report in results.values()),GTest_executed=sum(report.get('tests',0) for report in results.values()),GTest_skipped=0,
  cases={name:dict(status=report['status'],report=pin(W/'runs/candidate'/name/'attempt1/report.json')) for name,report in results.items()},
  scope='Existing finite native asserts; cached directory presence does not attest all original payload availability. No performance claim.'))
 print('ALL',len(results),'NATIVEPASS8GTESTskip0',flush=True)
if __name__=='__main__':main()
