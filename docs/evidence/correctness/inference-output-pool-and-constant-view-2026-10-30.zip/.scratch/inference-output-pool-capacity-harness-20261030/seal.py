"""Seal only current exact consumer receipts and reused231; no build/native."""
from pathlib import Path
import copy,importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('pool_seal_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
plan=read(W/'plan.json');base=read(plan['base']['path']);receipts={}
for name in plan['units']:
 p=W/'compile'/name/'receipt.json';receipt=read(p)
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
 receipts[name]=dict(receipt=pin(p),object=receipt['object'])
for item in [*base['retained'],base['runtime'],base['sdk_engine_dependencies']]:exact(item)
assert len(base['retained'])==231
current={};old={};audit=[]
for name,row in base['current_consumers'].items():
 exact(row['receipt']);exact(row['object']);receipt=read(row['receipt']['path'])
 mismatch=[item for item in receipt['source_identities'] if not Path(item['path']).is_file() or pin(item['path'])!=item]
 if mismatch or name in ('cli','tiny','session'):
  old[name]=dict(**row,status='HISTORICAL_NOT_CURRENT',mismatched_source_pins=mismatch)
  audit.append(dict(name=name,status='HISTORICAL',mismatched_source_pins=len(mismatch)))
 else:current[name]=row;audit.append(dict(name=name,status='CURRENT_EXACT',source_pins=len(receipt['source_identities'])))
current.update({name:row for name,row in receipts.items() if name!='lease-unit'})
historical=copy.deepcopy(base['historical_consumers']);historical['before-output-pool-74a6']=old
cli=read(receipts['cli']['receipt']['path'])
result=dict(schema='hyle.current-model-link-base.v1',base=plan['base'],compile=plan['units']['cli']['compile'],link=plan['units']['cli']['link'],
 consumer_source=plan['units']['cli']['source'],previous_consumer=base['current_consumers']['cli']['object']['path'],
 retained=base['retained'],runtime=base['runtime'],sdk_engine_dependencies=base['sdk_engine_dependencies'],
 current_consumers=current,historical_consumers=historical,
 retained_categories=dict(SDK_and_engine=227,model_cold_objects=4,total_retained=231,old_reused=231,new_objects=0),
 model_cold_objects=base['model_cold_objects'],current_compile_only=dict(lease_unit=receipts['lease-unit']),
 note='Header-only checked output pool capacity. All231SDK/cold objects reused exact;11consumers and one actual LeasePool unit rebuilt. No public SDK/API/ABI change. CLI/Session build coverage only in this slice.')
assert sum(key(a)==key(cli['object']['path']) for a in result['link'])==1
assert sum(key(a) in {key(i['path']) for i in base['retained']} for a in result['link'])==231
save(W/'model-link-base.json',result);save(W/'current-consumer-source-audit.json',audit)
save(W/'dependency-proof.json',dict(retained=231,unchanged_retained=231,SDK_CXX=0,model_cold_CXX=0,new_object=0,
 inspected_existing_dependency_rows=162,historical_dependency_metadata_unavailable=69,
 consumer_actual_repo_source_pins={name:len(read(row['receipt']['path'])['source_identities']) for name,row in receipts.items()},
 helper_in_current_receipts={name:any(key(p['path'])==key(R/'engine/inference/output_pool_capacity.h') for p in read(row['receipt']['path'])['source_identities']) for name,row in receipts.items()},
 rows_reused=base['current_consumers']['rows'],full_default_CMake_build=False,
 scope='Actual /sourceDependencies prove each rebuilt consumer. Existing162 metadata scan excludes affected retained inputs;69 cached native/library inputs retain original identities. CMake unit rule reviewed as source, not full default CMake build.'))
print(json.dumps(dict(status='CURRENT_BASE_SEALED',retained=231,SDK_CXX=0,model_cold_CXX=0,current_new_receipts=len(receipts))))
