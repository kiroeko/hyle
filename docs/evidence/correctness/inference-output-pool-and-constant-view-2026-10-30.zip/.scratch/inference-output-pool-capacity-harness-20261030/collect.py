"""Compact final receipt/archive. No binaries, SDK copies, cleanup or native execution."""
from pathlib import Path
import hashlib,importlib.util,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('pool_collect_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
assert not (W/'archive-receipt.json').exists(),'Archive already final; do not overwrite.'
plan=read(W/'plan.json');native=read(W/'native-summary-components.json');assert native['native_processes']==10 and native['status']=='PASS'
processes=[]
for p in sorted(W.rglob('process.json')):
 d=read(p);assert d['state']=='TERMINAL' and d['exit']==0 and not d.get('timed_out'),str(p)
 processes.append(dict(relative=p.relative_to(W).as_posix(),exit=d['exit'],pid=d['pid'],seconds=d['seconds']))
counts={kind:sum(p['relative'].startswith(kind+'/') for p in processes) for kind in ('compile','link','runs')}
assert counts==dict(compile=13,link=13,runs=12),(counts,'Expected initial12 + oneunitrevision;10component+2unit native')
for row in plan['source_freeze']:exact(row['source']);exact(row['snapshot'])
base=read(W/'model-link-base.json');assert len(base['retained'])==231
for item in [*base['retained'],base['runtime']]:exact(item)
for name,row in base['current_consumers'].items():
 exact(row['receipt']);receipt=read(row['receipt']['path'])
 for item in [receipt['object'],*receipt['source_identities']]:exact(item)
unit_folder=W/'runs/candidate/lease-unit/attempt2';unit=read(unit_folder/'report.json');assert unit['status']=='PASS'
report_inventory={}
for p in sorted((W/'runs').rglob('report.json')):report_inventory[p.relative_to(W).as_posix()]=pin(p)
summary=dict(status='PASS',scope='Checked shared output-pool capacity used by Qwen and existing GLM/Kimi/DS consumers; finite native validation, not full architecture/performance completion.',
 baseline_head=read(W/'baseline-plan.json')['head'],base_retained=231,current_retained=231,
 build=dict(unique_TUs=12,CXX_attempts=13,links=13,SDK_CXX=0,model_cold_CXX=0,NVCC=0,downloads=0,
  unit_revision='Initial arithmetic/real-pool unit PASS retained; revision adds actual RangeAllocator metadata-domain refusal without large allocation. Header/algorithm unchanged.'),
 native=dict(processes=12,current_cases=11,component_GTests=8,GTest_failures=0,GTest_skips=0,
  Qwen=['history-logits CPU','mtp-logits CUDA'],unit_attempts=2,old_unit_PASS_preserved=True),
 processes=dict(total=len(processes),counts=counts,failed=0,records=processes),
 reports=report_inventory,current_model_link_base=pin(W/'model-link-base.json'),dependency_proof=pin(W/'dependency-proof.json'),
 hardware_toolchain=pin(W/'hardware-toolchain.json'),source_freeze=pin(W/'source-freeze-v2.json'),
 limits=['CLI/Session build coverage only; no default greedy/Session native rerun in this header-only output/count/probability-pool slice.',
 'Eight components use their existing one-case assertions with actual cached original/generated scopes; cache directory presence alone does not prove every model role available.',
 'Capacity helper checks arithmetic/blocks and explicit alignment. Actual RangeAllocator metadata admission remains a separate contract; largest uint32 arithmetic is not an allocation guarantee.',
 'Current helper can increase backing reservation through alignment padding. This is correctness capacity, not a memory/performance improvement claim.',
 'No full default CMake build; new unit CMake source rule reviewed. No new public SDK object/API, no device-port alignment relaxation.'])
save(W/'summary-draft.json',summary)
external=W/'external';external.mkdir(exist_ok=True)
extract=R/'.scratch/inference-output-pool-capacity-20261030'
for name in ('plan-v3.json','output-pool-capacity-v3.patch','independent-review-v2.json','applied-v3.json'):
 p=extract/name
 if p.exists():(external/name).write_bytes(p.read_bytes())
excluded={'bin','tmp'};binary_suffix={'.obj','.pdb','.exe','.dll','.lib','.exp','.ilk','.map','.pyc'}
members=[]
for p in sorted(W.rglob('*')):
 if not p.is_file() or any(part in excluded or part=='__pycache__' for part in p.relative_to(W).parts):continue
 if p.suffix.lower() in binary_suffix or p.name in ('archive-receipt.json','evidence-draft.zip','cleanup-targets.json'):continue
 members.append((p,p.relative_to(W).as_posix()))
archive=W/'evidence-draft.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,name in members:z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())=={name for _,name in members}
 for p,name in members:assert z.read(name)==p.read_bytes(),name
save(W/'archive-receipt.json',dict(archive=pin(archive),members=len(members),all_members_direct_bytes_equal=True))
cleanup=[]
for p in (W/'bin').glob('*'):
 if p.is_file():cleanup.append(pin(p))
save(W/'cleanup-targets.json',dict(files=cleanup,bytes=sum(p['bytes'] for p in cleanup),scope='Only current generated bin files. Root must independently review and write exact test.ps1 before delete. Keep all objects/recipes/source receipts/current base and original runtime.'))
print(json.dumps(dict(status='FINAL_ARCHIVE_READY',processes=len(processes),counts=counts,archive=pin(archive),members=len(members),cleanup_files=len(cleanup))))
