"""Root-approved unit-only second attempt; call only after component queue terminal."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pool_unit_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
for p in (W/'runs').rglob('process.json'):assert read(p)['state']=='TERMINAL'
b.compile('attempt2',['lease-unit']);b.link('lease-unit','attempt2')
folder=W/'runs/candidate/lease-unit/attempt2';image=read(W/'ready-lease-unit.json');exact(image);save(folder/'image.json',image)
b.s.b.execute([image['path']],folder,60)
unit=json.loads((folder/'stdout.log').read_text());assert unit['status']=='PASS' and unit['native_submissions']==0
assert all(unit[k] for k in ('actual_lease_pool','explicit_alignment','checked_overflow','unaligned_rows','retained_reader_recovery','budget_lifetime'))
save(folder/'report.json',unit)
save(W/'unit-summary-v2.json',dict(status='PASS',current_unit=pin(folder/'report.json'),
 old_unit_PASS_preserved=pin(W/'runs/candidate/lease-unit/attempt1/report.json'),
 note='Second unit source also executes actual RangeAllocator metadata-domain precondition refusal. This does not admit an enormous actual allocation.'))
print('UNIT2PASS;component aggregate remains separate',flush=True)
