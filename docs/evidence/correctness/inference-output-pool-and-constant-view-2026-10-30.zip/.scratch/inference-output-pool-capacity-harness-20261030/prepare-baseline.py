"""Prepare current Phase baseline and cached output-capacity recipes; never compile/run."""
from pathlib import Path
import hashlib,json,re,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
EXTRACT=R/'.scratch/inference-output-pool-capacity-20261030'
BASE=R/'.scratch/inference-phase-preparation-harness-20261030/model-link-base.json'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def key(p):return re.sub('/+','/',str(p).replace('\\','/')).lower()
checked={}
def exact(item):
 p=Path(item['path']);k=key(p)
 if k not in checked:checked[k]=pin(p)
 assert all(checked[k][f]==item[f] for f in ('bytes','sha256')),(str(p),'pin mismatch')
 return checked[k]
def main():
 assert not (W/'baseline-plan.json').exists(),'immutable baseline already exists'
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 assert head=='74a6e8ee6af8a04d1e5238810ac47723f4b84665',head
 assert not subprocess.check_output(['git','diff','--name-only','--','include','src','engine','tests'],cwd=R,text=True).strip()
 base=read(BASE);candidate=read(EXTRACT/'plan-v3.json');recipes=read(EXTRACT/'validation-recipes-draft.json')
 assert len(base['retained'])==231 and recipes['sdk_retained_count']==231
 exact(recipes['template_base']);assert key(recipes['template_base']['path'])==key(BASE)
 for item in [*base['retained'],base['runtime']]:exact(item)
 exact(candidate['patch'])
 changes={key(R/i['relative']) for i in candidate['files']}
 source={}
 for i in [*candidate['source_base'],*candidate['files']]:
  p=R/i['relative']
  if i.get('absent'):assert not p.exists();continue
  expected=dict(path=str(p),bytes=i.get('base_bytes',i.get('bytes')),sha256=i.get('base_sha256',i.get('sha256')))
  source[key(p)]=exact(expected)
 for p in [Path(base['consumer_source']),R/'engine/models/qwen35/mtp_session_probe.cc']:
  source[key(p)]=pin(p)
 snapshots=[]
 for item in source.values():
  p=Path(item['path']);relative=p.relative_to(R)
  out=W/'baseline-source'/relative;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
  snapshots.append(dict(original=item,snapshot=pin(out)))
 dep_index=read(base['sdk_engine_dependencies']['path']);exact(base['sdk_engine_dependencies'])
 affected=[];retained_paths={key(i['path']) for i in base['retained']}
 for row in dep_index['inspected']:
  exact(row['dependencies']);dep=read(row['dependencies']['path'])['Data']
  overlap=[str(p) for p in [dep['Source'],*dep['Includes']] if key(p) in changes]
  if overlap:affected.append(dict(object=row['object'],changed_inputs=overlap))
 assert not affected,affected
 consumers={}
 for name in ('cli','tiny','session','rows'):
  record=base['current_consumers'][name];exact(record['receipt']);receipt=read(record['receipt']['path'])
  for item in [receipt['object'],*receipt['source_identities']]:exact(item)
  consumers[name]=dict(receipt=record['receipt'],object=receipt['object'],source_identities=receipt['source_identities'],
    changed_inputs=[i['path'] for i in receipt['source_identities'] if key(i['path']) in changes])
 assert all(consumers[n]['changed_inputs'] for n in ('cli','tiny','session')) and not consumers['rows']['changed_inputs']
 wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n',encoding='utf-8')
 units={}
 old_out=R/'.scratch/inference-output-pool-validation-20261030'
 for name,row in recipes['units'].items():
  row=dict(row)
  for field in ('compile','link'):
   row[field]=[a.replace(str(old_out),str(W)) for a in row[field]]
  for field in ('object','binary'):row[field]=row[field].replace(str(old_out),str(W))
  if name=='cli':
   old=row['source'];row['source']=str(wrapper);row['compile']=[str(wrapper) if key(a)==key(old) else a for a in row['compile']]
  sources=[a for a in row['compile'] if a.lower().endswith('.cc')]
  assert len(sources)==1 and '/c' in [a.lower() for a in row['compile']],(name,sources)
  assert len([a for a in row['link'] if key(a) in retained_paths])==231,name
  units[name]=row
 assert len(units)==12
 save(W/'plan-prepared.json',dict(status='PREPARED_ONLY_NO_CXX_NATIVE',base=pin(BASE),candidate_plan=pin(EXTRACT/'plan-v3.json'),
   recipe_template=pin(EXTRACT/'validation-recipes-draft.json'),units=units,retained=base['retained'],runtime=base['runtime'],
   gtest_libraries=recipes['gtest_libraries'],minimal_native_cases=recipes['minimal_native_cases'],optional_native_cases=recipes['optional_native_cases'],
   environments=recipes['environments'],always_environment=recipes['always_environment'],cached_inputs=recipes['cached_inputs'],
   max_compilers=2,CXX_executed=0,native_executed=0,downloads=0,NVCC=0,
   note='Native recipes are prepared suggestions only; root selects exact finite cases. Candidate source is still unapplied. Baseline model closure stays231, helper is header-only.'))
 save(W/'baseline-plan.json',dict(status='EXACT_PHASE231_BASELINE_SNAPSHOTTED_NO_CXX_NATIVE',head=head,base=pin(BASE),
   candidate_plan=pin(EXTRACT/'plan-v3.json'),snapshots=snapshots,retained=base['retained'],runtime=base['runtime'],consumers=consumers,
   original_link=base['link'],original_consumer=base['current_consumers']['cli']['object'],
   actual_affected_retained=affected,available_dependency_rows=len(dep_index['inspected']),unavailable_dependency_metadata=dep_index['unavailable'],
   expected_candidate_retained=231,expected_SDK_CXX=0,expected_model_cold_CXX=0,
   expected_consumer_CXX=11,expected_new_unit_CXX=1,baseline_source_proof='Every current cli/tiny/session/rows receipt source pin checked before migration; changed source bytes separately snapshotted.',
   CXX_executed=0,links_executed=0,native_executed=0))
 print(json.dumps(dict(status='BASELINE_AND_RECIPES_READY',head=head,retained=231,snapshots=len(snapshots),affected_retained=0,
   consumer_source_counts={n:len(v['source_identities']) for n,v in consumers.items()},prepared_TUs=len(units),CXX=0,native=0)))
if __name__=='__main__':main()
