"""Cached output-capacity harness. Compile/native require root's separate authorization."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import importlib.util,json,shutil,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
EXTRACT=R/'.scratch/inference-output-pool-capacity-20261030'
spec=importlib.util.spec_from_file_location('output_pool_prior_build',R/'.scratch/inference-phase-preparation-harness-20261030/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
s=b.s;s.W=s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
def refresh():
 target=W/'recipe-template-v2.json';assert not target.exists()
 shutil.copyfile(EXTRACT/'validation-recipes-draft.json',target)
 recipes=read(target);plan=read(W/'plan-prepared.json');old=R/'.scratch/inference-output-pool-validation-20261030'
 for name,row in recipes['units'].items():
  row=dict(row)
  for field in ('compile','link'):row[field]=[a.replace(str(old),str(W)) for a in row[field]]
  for field in ('object','binary'):row[field]=row[field].replace(str(old),str(W))
  if name=='cli':
   original=row['source'];row['source']=str(W/'cli.cc');row['compile']=[row['source'] if key(a)==key(original) else a for a in row['compile']]
  plan['units'][name]=row
 for field in ('minimal_native_cases','optional_native_cases'):
  plan[field]=recipes[field]
  for case in plan[field].values():
   case['command']=[a.replace(str(old),str(W)) for a in case['command']]
 for field in ('environments','always_environment','clear_frontier_request_environment','cached_inputs','changed_consumer_one_case'):
  plan[field]=recipes[field]
 plan['recipe_template']=pin(target)
 plan['supersedes_prepared_plan']=pin(W/'plan-prepared.json')
 save(W/'plan-prepared-v2.json',plan)
 print(json.dumps(dict(status='LATEST_RECIPES_PREPARED',units=len(plan['units']),cache_dirs=len(plan['cached_inputs']),CXX=0,native=0)),flush=True)
def runtime():
 item=read(W/'baseline-plan.json')['runtime'];exact(item)
 (W/'bin').mkdir(exist_ok=True);target=W/'bin'/Path(item['path']).name
 if target.exists():
  actual=pin(target);assert all(actual[f]==item[f] for f in ('bytes','sha256'))
 else:shutil.copyfile(item['path'],target)
def baseline_link(name,attempt):
 baseline=read(W/'baseline-plan.json');consumer=baseline['consumers'][name]
 for item in [consumer['object'],*baseline['retained'],baseline['runtime']]:exact(item)
 runtime();args=[];count=0
 for arg in baseline['original_link']:
  if key(arg)==key(baseline['original_consumer']['path']):arg=consumer['object']['path'];count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/('baseline-'+name)).with_suffix(suffix));break
  args.append(arg)
 assert count==1
 s.b.execute(args,W/'link'/('baseline-'+name)/attempt,240)
 save(W/('ready-baseline-'+name+'.json'),pin(W/'bin'/('baseline-'+name+'.exe')))
def prepare():
 assert not (W/'plan.json').exists()
 candidate=read(EXTRACT/'plan-v3.json');frozen=[]
 for item in candidate['files']:
  p=R/item['relative'];actual=pin(p)
  assert all(actual[f]==item['candidate_'+f] for f in ('bytes','sha256')),str(p)
  out=W/'source-frozen'/item['relative'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
  frozen.append(dict(source=actual,snapshot=pin(out)))
 plan=read(W/'plan-prepared-v2.json');plan['status']='CURRENT_SOURCE_FROZEN';plan['source_freeze']=frozen
 for item in [*plan['retained'],plan['runtime'],*plan['gtest_libraries']]:exact(item)
 runtime();save(W/'plan.json',plan)
 print('FROZEN12singleTUs,old231unchanged,noSDKorModelCXX',flush=True)
def freeze_check(plan):
 for row in plan['source_freeze']:exact(row['source'])
def compile(attempt,names):
 plan=read(W/'plan.json');freeze_check(plan)
 def one(name):
  unit=plan['units'][name];original=Path(unit['object']).parent;folder=W/'compile'/name/attempt
  command=[a.replace(str(original),str(folder)) for a in unit['compile']]
  s.b.execute(command,folder,900)
  dep_path=folder/'dependencies.json';dep=read(dep_path)['Data']
  paths=sorted({Path(p).resolve() for p in [dep['Source'],*dep['Includes']] if Path(p).is_relative_to(R)})
  save(W/'compile'/name/'receipt.json',dict(object=pin(folder/'unit.obj'),dependencies=pin(dep_path),
    process=pin(W/'compile'/name/attempt/'process.json'),source_identities=[pin(p) for p in paths]))
  print('COMPILED',name,flush=True)
 with ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(one,n) for n in names]
  for future in as_completed(futures):future.result()
def link(name,attempt):
 plan=read(W/'plan.json');unit=plan['units'][name];receipt=read(W/'compile'/name/'receipt.json')
 for item in [receipt['object'],*receipt['source_identities'],*plan['retained'],*plan['gtest_libraries']]:exact(item)
 command=[receipt['object']['path'] if key(a)==key(unit['object']) else a for a in unit['link']]
 runtime();s.b.execute(command,W/'link'/name/attempt,240)
 save(W/('ready-'+name+'.json'),pin(unit['binary']))
if __name__=='__main__':
 action=sys.argv[1]
 if action=='refresh':refresh()
 elif action=='baseline-link':baseline_link(sys.argv[2],sys.argv[3])
 elif action=='prepare':prepare()
 elif action=='compile':compile(sys.argv[2],sys.argv[3:])
 elif action=='link':link(sys.argv[2],sys.argv[3])
 else:raise ValueError(action)
