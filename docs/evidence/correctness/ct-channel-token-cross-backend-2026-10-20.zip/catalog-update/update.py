import copy
import difflib
import hashlib
import json
from pathlib import Path

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
TARGET = ROOT / 'docs/implementation/model-quantizations.json'
EVIDENCE = 'docs/evidence/correctness/ct-channel-token-cross-backend-2026-10-20.json'


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


before_raw = TARGET.read_bytes()
before_path = STAGE / 'before/model-quantizations.json'
before_path.parent.mkdir(parents=True, exist_ok=True)
assert not before_path.exists(), 'Keep existing before snapshots; do not rerun this mutation'
before_path.write_bytes(before_raw)
before = json.loads(before_raw)
after = copy.deepcopy(before)
expected = {
    2: 'Freesolo-Co/Qwen3.5-2B-FP8',
    8: 'unsloth/Qwen3.8-27B-NVFP4',
}

execution = {
    'status': 'bounded_ordinary_reference_verified_on_four_backends',
    'evidence': EVIDENCE,
    'contract': 'BF16 rank3 last-K token absmax/448, exact-zero-only BF16 epsilon substitution, BF16 divide/clamp and E4M3 RNE; BF16 activation QDQ and per-channel weight dequant rounding precede ordinary BF16 MatMul with explicit F32 accumulation.',
    'backends': ['WindowsCPU', 'WindowsCUDA', 'WindowsVulkan', 'macOSAppleM4'],
    'package_tests': {'WindowsCPU': 5, 'WindowsCUDA': 5, 'WindowsVulkan': 7, 'macOSAppleM4': 3, 'total': 20, 'skipped': 0},
    'counting': 'Focused package cases include new CT/Bool/Select consumers and retained storage-Cast neighbors; not20 artifacts or models.',
    'new_consumer_submissions_per_backend': {'CT_QDQ': 4, 'three_dtype_Bool_Select': 6},
    'generic_primitive_scope': 'F32/F16/BF16<->Bool: both signed zeros false, every nonzero pattern including subnormal/Inf/NaN true, noncanonical Bool bytes normalize via!=0. Select broadcasts and copies selected storage bits with actual output dtype; Vulkan F16/BF16<->E4M3 storage bridges also exercised. FP8<->Bool remains unadmitted.',
    'dtype_boundary': 'The CT quantization reference is BF16; small F16/F32 generic Bool/Select regressions do not certify complete CT QDQ for those dtypes.',
    'resource_scope': 'Original ordinary Graph/native Program/Invocation and queue/IO owners; two CT slots, content updates, retained-result replay gate, original constant source release and results read after Invocation destruction. Generic storage guards retain updated outputs after Invocation destruction.',
    'native_FP8_dot_verified': False,
    'not_verified': ['Publisher numeric codes/scales and exact role/import binding', 'Whole artifact/model execution and base-model identity', 'Linux execution of this cross-backend package', 'Deployment/native FP8 dot arithmetic', 'Quality, throughput or peak-memory acceptance'],
}
entry = {
    'descriptor': 'Ordinary BF16 CT channel/token QDQ graph; no new custom operation',
    'providers': ['WindowsCPU', 'WindowsCUDA', 'Apple Metal/MLX', 'Vulkan native'],
    'operations': 'Abs/Reduce, typed Cast/Bool, zero-only Select, Binary divide/clamp/multiply, View and ordinary BF16 MatMul/F32 accumulation',
    'evidence': EVIDENCE,
    'scope': 'Bounded synthetic source-reference and resource regressions, not native FP8 code-dot or publisher artifact execution',
}
for index, repository in expected.items():
    row = after['artifacts'][index]
    assert row['repository'] == repository
    c = row['provider_coverage']
    c['artifact_execution_verified'] = False
    c['reachable_entry_points'].append(copy.deepcopy(entry))
    c['cross_backend_reference_execution'] = copy.deepcopy(execution)

c = after['artifacts'][2]['provider_coverage']
c['review'] = 'fixed_source_contract_and_four_backend_ordinary_reference_execution'
c['review_scope'] = 'Fixed186-role header/source research plus synthetic ordinary BF16 CT QDQ and typed storage regressions on Windows CPU/CUDA/Vulkan and Apple M4; no publisher numeric payload/importer, whole artifact, Linux, quality or performance verification'
c['mapping_status'] = 'The fixed BF16 channel-weight/token-activation QDQ reference executes through ordinary Graph on all four backends; exact186-role payload/import binding and deployment/native FP8 dot remain separate unverified work'
c['artifact_unaligned_or_unverified'].append('Four-backend ordinary reference coverage does not establish exact186-role payload/import binding, Linux execution, native FP8 dot, quality or performance; F16/F32 coverage here is generic storage only')
c['missing_capabilities'] = [
    'Exact186-role publisher payload/scale/import binding and whole artifact execution',
    'Deployment/native FP8 channel/token arithmetic must be specified and qualified separately from the implemented BF16 QDQ reference',
    'Linux execution and model-level quality/performance acceptance of this path',
]

c = after['artifacts'][8]['provider_coverage']
c['review'] = 'fixed_checkpoint_contract_and_four_backend_local_nvfp4_and_ct_fp8_references'
c['review_scope'] = 'Retain pinned header/producer and bounded local NVFP4 reference evidence; add ordinary BF16 CT channel/token regressions on Windows CPU/CUDA/Vulkan and Apple M4 only for the FP8 side roles. No publisher numeric payload/importer, whole artifact, Linux, quality or performance verification.'
c['mapping_status'] = 'Both the local NVFP4 subgroup and the surrounding BF16 CT channel/token FP8 reference have executed bounded paths on all four backends; their separate role/import bindings and complete mixed artifact execution remain unverified.'
c['artifact_unaligned_or_unverified'][1] = 'FP8 channel-scale storage is BF16[N,1] in the inspected header. The attention/head and last8 MLP FP8 side roles now have ordinary BF16 QDQ reference coverage on four backends, separate from the168 local NVFP4 roles in layers0-55; actual FP8/NVFP4 codes, scales/globals and exact per-role import binding remain unverified.'
c['missing_capabilities'] = [
    'Exact mixed-role FP8/local-NVFP4 publisher payload/scale/global/import binding and complete artifact execution',
    'Separately specified deployment/native FP8 code-dot contract; generic Bool/Select and BF16 QDQ coverage do not establish it',
    'Linux execution and model-level quality/performance acceptance of the newly completed ordinary CT FP8 side path',
]

assert len(after['artifacts']) == 33
assert all(a['provider_coverage']['artifact_execution_verified'] is False for a in after['artifacts'])
changed = [i for i, (a, b) in enumerate(zip(before['artifacts'], after['artifacts'])) if a != b]
assert changed == [2, 8]
for key in before.keys() - {'artifacts'}:
    assert before[key] == after[key]
for index in expected:
    a = before['artifacts'][index]
    b = after['artifacts'][index]
    assert {k: v for k, v in a.items() if k != 'provider_coverage'} == {k: v for k, v in b.items() if k != 'provider_coverage'}
    old = a['provider_coverage']
    new = b['provider_coverage']
    assert new['reachable_entry_points'][:-1] == old['reachable_entry_points']
    for key in ('metadata_sources', 'required_format_domain', 'typed_reference_execution', 'native_storage_execution', 'nearby_non_equivalent_entry_point', 'ct_local_nvfp4_contract', 'code'):
        assert old.get(key) == new.get(key), (index, key)

# Preserve historical research and correctness files; this task updates only the catalog.
history_paths = [
    'docs/evidence/research/fp8-channel-token-contract-2026-10-20.json',
    'docs/evidence/correctness/fp8-channel-token-qdq-2026-10-20.json',
    'docs/evidence/correctness/cuda-native-storage-cast-2026-10-20.json',
    'docs/evidence/correctness/ct-local-nvfp4-reference-2026-10-20.json',
]
history = [{'path': name, **identity(ROOT / name)} for name in history_paths]
after_raw = (json.dumps(after, ensure_ascii=False, indent=2) + '\n').replace('\n', '\r\n').encode('utf-8')
assert TARGET.read_bytes() == before_raw, 'Concurrent catalog edit; do not overwrite'
TARGET.write_bytes(after_raw)
after_path = STAGE / 'after/model-quantizations.json'
after_path.parent.mkdir(parents=True, exist_ok=True)
after_path.write_bytes(after_raw)
diff = ''.join(difflib.unified_diff(
    before_raw.decode('utf-8').splitlines(keepends=True), after_raw.decode('utf-8').splitlines(keepends=True),
    fromfile='before/model-quantizations.json', tofile='after/model-quantizations.json', n=3,
))
(STAGE / 'model-quantizations.diff').write_text(diff, encoding='utf-8', newline='')
for item in history:
    assert identity(ROOT / item['path']) == {k: item[k] for k in ('bytes', 'sha256')}
validation = {
    'status': 'Only artifacts2/8 provider coverage updated; historical/local-NVFP4 facts retained',
    'changed_zero_based_rows': changed, 'only_provider_coverage_changed': True,
    'all_other31_artifacts_and_root_fields_unchanged': True,
    'existing_entry_points_kept_as_exact_prefix': True,
    'historical_evidence_references_and_local_nvfp4_contract_unchanged': True,
    'artifact_execution_verified_false_count': 33,
    'reported_regressions': execution['package_tests'],
    'reported_submissions_per_backend': execution['new_consumer_submissions_per_backend'],
    'builds_tests_or_GPU_runs_by_this_catalog_task': 0,
    'new_correctness_evidence': EVIDENCE,
    'correctness_file_present_at_catalog_edit': (ROOT / EVIDENCE).is_file(),
    'correctness_publisher': 'root; fixed path per task',
    'preserved_historical_file_identities': history,
    'before': identity(before_path), 'after': identity(after_path), 'diff': identity(STAGE / 'model-quantizations.diff'),
}
(STAGE / 'validation.json').write_bytes(encoded(validation))
print(json.dumps(validation, ensure_ascii=False, indent=2))
