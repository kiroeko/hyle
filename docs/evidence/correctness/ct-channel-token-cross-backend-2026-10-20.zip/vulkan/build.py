from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import re
import struct
import subprocess
import sys
import threading
import time

ROOT = Path.cwd()
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
STAGE = A / 'ct-channel-token-cross-backend/vulkan'
BASE = A / 'quark-mxfp4-reference/vulkan/checks'
CHECKS, SHADERS = STAGE / 'checks', STAGE / 'shaders'
CHECKS.mkdir(exist_ok=True)
SHADERS.mkdir(exist_ok=True)
PHASE = sys.argv[1]
records, lock = [], threading.Lock()
env = os.environ.copy()
setup = subprocess.run(['cmd', '/d', '/c', str(A / 'bf16-nan-cast-contract/compiler-env.bat')],
                       capture_output=True, text=True, check=True)
for line in setup.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key.upper()] = value


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')


def run(label, command):
    started = time.time()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                            text=True, encoding='utf8', errors='replace')
    (CHECKS / (label + '.stdout.log')).write_text(result.stdout, encoding='utf8')
    (CHECKS / (label + '.stderr.log')).write_text(result.stderr, encoding='utf8')
    with lock:
        records.append(dict(label=label, command=command, exit_code=result.returncode,
                            seconds=time.time() - started))
        save(CHECKS / ('commands-' + PHASE + '.json'), records)
    print(label, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(label + ': ' + (result.stdout + result.stderr)[-8000:])


def recipe_for(obj):
    for path in Path(obj).parent.glob('*identity.json'):
        data = load(path)
        if str(Path(data.get('object', {}).get('path', ''))).lower() == str(Path(obj)).lower():
            return path
    raise AssertionError(obj)


def command_for(recipe, source, tag):
    command, skip = [], False
    for arg in load(recipe)['command']:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.startswith(('/Fo', '/Fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        command.append(arg)
    command.insert(1, '-I' + str(SHADERS))
    command += ['/W4', '/WX', '/sourceDependencies', str(CHECKS / (tag + '-deps.json')),
                str(source), '/Fo' + str(CHECKS / (tag + '.obj')),
                '/Fd' + str(CHECKS / (tag + '.pdb'))]
    return command


if PHASE == 'plan':
    linked = load(BASE / 'link-plan.json')
    objects = {Path(row['path']).name: row for row in linked['inputs']}
    items = [('vulkan_tensor', ROOT / 'src/compute_route_vulkan/vulkan_tensor.cc'),
             ('vulkan_shaders', SHADERS / 'vulkan_shaders.cc')]
    compiles = []
    for tag, source in items:
        old = objects[tag + '.obj']
        assert identity(old['path']) == old
        recipe = recipe_for(old['path'])
        compiles.append(dict(tag=tag, source=str(source), object=str(CHECKS / (tag + '.obj')),
            command=command_for(recipe, source, tag), previous_object=old, recipe=identity(recipe)))
    save(CHECKS / 'product-plan.json', dict(baseline=identity(BASE / 'link-plan.json'),
        compile=compiles, scope='2 product CXX +6 actual tensor.comp variants; reuse15 other SPIRV; no SDK/GPU.'))
    print('planned', len(compiles))
elif PHASE == 'shaders':
    old = {row['name']: Path(row['artifact']['path'])
           for row in load(BASE / 'shader-artifacts.json')['artifacts']}
    assert len(old) == 21
    changed = {'tensor': {},'checked_tensor': {'HYLE_TENSOR_CHECKED':'1'},
        'scatter': {'HYLE_TENSOR_SCATTER':'1'},'normalization': {'HYLE_TENSOR_NORMALIZATION':'1'},
        'concat': {'HYLE_TENSOR_CONCAT':'1'},'reduction': {'HYLE_TENSOR_REDUCTION':'1'}}
    source = ROOT / 'src/compute_route_vulkan/shaders/tensor.comp'
    for name, defines in changed.items():
        command = ['C:/public/tools/glslang/glslangValidator.exe','-V','--target-env',
            'vulkan1.2','--preamble-text','#extension GL_GOOGLE_include_directive : require\n',
            '-I' + str(ROOT / 'third_party/ggml_vulkan_shaders/shaders'),
            '-I' + str(source.parent),'-S','comp']
        command += ['-D' + key + '=' + value for key,value in defines.items()]
        command += ['-o',str(SHADERS / (name + '.spv')),str(source)]
        run(name + '-shader',command)
    header = ['#pragma once','#include <cstdint>','#include <span>',
              'namespace hyle::compute::vulkan::detail::shaders {']
    cpp = ['#include "vulkan_shaders.h"','namespace hyle::compute::vulkan::detail::shaders {']
    artifacts=[]
    for name,previous in old.items():
        path=SHADERS/(name+'.spv') if name in changed else previous
        raw=path.read_bytes();assert len(raw)%4==0
        words=struct.unpack('<'+'I'*(len(raw)//4),raw)
        assert words[0]==0x07230203 and words[1]<=0x00010500
        at=5
        while at<len(words):
            size,opcode=words[at]>>16,words[at]&65535
            assert size and at+size<=len(words)
            if opcode==17:assert size==2 and words[at+1]==1
            at+=size
        header.append('std::span<const std::uint32_t> '+name+'() noexcept;')
        cpp.append('namespace { constexpr std::uint32_t '+name+'_words[] = {')
        for offset in range(0,len(words),8):
            cpp.append('  '+', '.join(f'0x{x:08x}u' for x in words[offset:offset+8])+',')
        cpp += ['}; }','std::span<const std::uint32_t> '+name+'() noexcept { return '+name+'_words; }']
        artifacts.append(dict(name=name,artifact=identity(path),previous=identity(previous),reused=name not in changed))
    header.append('} // namespace hyle::compute::vulkan::detail::shaders');cpp.append(header[-1])
    (SHADERS/'vulkan_shaders.h').write_bytes(('\n'.join(header)+'\n').encode())
    (SHADERS/'vulkan_shaders.cc').write_bytes(('\n'.join(cpp)+'\n').encode())
    save(CHECKS/'shader-artifacts.json',dict(artifacts=artifacts,compiled=6,reused=15,
        source=identity(source),include=identity(source.with_name('fp8_storage.glsl')),
        capabilities='Shader only; SPIR-V <=1.5; every instruction length/capability checked'))
elif PHASE == 'product':
    def compile_one(item):
        tag=item['tag'];run(tag+'-compile',item['command'])
        data=load(CHECKS/(tag+'-deps.json'))['Data'];paths=dict.fromkeys([data['Source'],*data['Includes']])
        record=dict(command=item['command'],source=identity(item['source']),object=identity(item['object']),
            recipe=item['recipe'],dependencies=[identity(path) for path in paths])
        save(CHECKS/(tag+'-identity.json'),record)
        return dict(tag=tag,receipt=identity(CHECKS/(tag+'-identity.json')))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        complete=list(pool.map(compile_one,load(CHECKS/'product-plan.json')['compile']))
    save(CHECKS/'product-build-receipt.json',dict(CXX=2,GLSL=6,SDK=0,GPU=0,receipts=complete))
elif PHASE == 'test':
    recipe=BASE/'mxfp4-test-identity.json';source=ROOT/'tests/graph_route_vulkan/fp8_channel_token_qdq_test.cc'
    tag='ct-qdq-test';command=command_for(recipe,source,tag);run(tag+'-compile',command)
    data=load(CHECKS/(tag+'-deps.json'))['Data'];paths=dict.fromkeys([data['Source'],*data['Includes']])
    save(CHECKS/(tag+'-identity.json'),dict(command=command,source=identity(source),
        object=identity(CHECKS/(tag+'.obj')),recipe=identity(recipe),dependencies=[identity(p) for p in paths]))
elif PHASE == 'link':
    linked=load(BASE/'link-plan.json')
    replacements={str(Path(row['previous_object']['path'])).lower():row['object']
        for row in load(CHECKS/'product-plan.json')['compile']}
    assert len(replacements)==2
    for item in linked['inputs']:assert identity(item['path'])==item
    command=[];seen=set()
    for arg in linked['command']:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:')):continue
        key=str(Path(arg)).lower()
        if key in replacements:seen.add(key);command.append(replacements[key])
        else:command.append(arg)
    assert seen==set(replacements)
    command.insert(1,str(CHECKS/'ct-qdq-test.obj'))
    command += ['/OUT:'+str(CHECKS/'ct-qdq-reference-test.exe'),'/MAP:'+str(CHECKS/'ct-qdq-reference-test.map'),
        '/IMPLIB:'+str(CHECKS/'ct-qdq-reference-test.lib')]
    temporary=STAGE/'tmp';temporary.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(temporary)
    run('link',command)
    save(CHECKS/'link-plan.json',dict(command=command,inputs=[identity(a) for a in command[1:] if Path(a).is_file()],
        baseline=identity(BASE/'link-plan.json'),replaced_product_objects=replacements,
        shared_CPU_overlay=linked['shared_CPU_overlay'],executable=identity(CHECKS/'ct-qdq-reference-test.exe')))
else:raise ValueError(PHASE)
