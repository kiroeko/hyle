from pathlib import Path
import importlib.util, sys, xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
C = S.parent
A = C.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('ct_windows_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b, c = h.b, h.c
arm, mode = sys.argv[1:3]
assert arm in ('cpu', 'cuda') and mode in ('build', 'run')
base_path = A/'quark-mxfp4-reference'/('common-cpu/checks/attempt2/link-plan.json' if arm == 'cpu' else 'cuda/tests/link-plan.json')
out = C/arm/'checks'/(sys.argv[3] if len(sys.argv) > 3 else 'attempt1')
out.mkdir(parents=True, exist_ok=True); (out/'tmp').mkdir(exist_ok=True)
base = c.read(base_path)
if mode == 'build':
    meta = h.metadata({arm:base})
    source = ROOT/f'tests/graph_route_{arm}/fp8_channel_token_qdq_test.cc'
    matches = [(x, meta.get(c.key(x['path']))) for x in base['inputs']
        if c.key(meta.get(c.key(x['path']),{}).get('source_path','')) == c.key(source)]
    assert len(matches) == 1, [(x['path'], None if not r else r['source_path']) for x,r in matches]
    old, recipe = matches[0]
    command = b.host_command(recipe['command'], source, 'ct-qdq-test', out)
    assert '/W4' in command and '/WX' in command
    assert not (out/'compile.result.json').exists(), 'Preserve actual attempt'
    frozen = [b.identity(source), b.identity(ROOT/'tests/compute_models/fp8_channel_token_qdq_fixture.h')]
    env, runtime = b.environment(command, [], out)
    c.save(out/'compile-plan.json', dict(command=command, old_object=old, recipe=b.identity(recipe['recipe']), sources=frozen))
    c.execute('compile', command, env, out)
    deps = out/'ct-qdq-test-deps.json'; data = c.read(deps)['Data']
    current = b.identity(out/'ct-qdq-test.obj')
    assert all(b.same(row) for row in frozen)
    c.save(out/'ct-qdq-test-identity.json',dict(source=frozen[0], object=current, command=command,
        source_dependencies=b.identity(deps), dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]))
    inputs = [current if c.key(x['path']) == c.key(old['path']) else x for x in base['inputs']]
    assert all(b.same(row) for row in inputs)
    image = out/(arm+'.exe')
    command = [current['path'] if c.key(x) == c.key(old['path']) else x for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    plan = dict(command=command,inputs=inputs,base=b.identity(base_path),replacements=[dict(before=old,after=current)],SDK_rebuilt=False,product_TUs=0,test_TUs=1)
    c.save(out/'link-plan.json',plan)
    env,runtime = b.environment(command,[r['path'] for r in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out)
    c.save(out/'image.json', b.identity(image))
    print('READY',arm,image,flush=True)
else:
    plan = c.read(out/'link-plan.json'); image = c.read(out/'image.json')
    assert b.same(image) and all(b.same(row) for row in plan['inputs'])
    assert not (out/'tests.result.json').exists(), 'Preserve actual attempt'
    filter = ('CpuFp8ChannelTokenQdqGraph.*:NativeBoolCast.*:NativeCast.*:CpuStaticFp8ReferenceGraph.*' if arm == 'cpu'
        else 'CudaFp8ChannelTokenQdqGraph.*:CudaBoolCast.*:CudaNativeStorageCast.*:CudaStaticFp8ReferenceGraph.*')
    env,_ = b.environment(plan['command'],[r['path'] for r in plan['inputs']],out)
    try:
        c.execute('tests',[image['path'],'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
    finally:
        if (out/'tests.xml').exists():
            cases=ET.parse(out/'tests.xml').findall('.//testcase')
            failed=[x.attrib for x in cases if x.find('failure') is not None]
            skipped=[x.attrib for x in cases if x.find('skipped') is not None]
            receipt=dict(passed=bool(cases) and not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,
                filter=filter,names=[x.get('classname')+'.'+x.get('name') for x in cases],
                properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[p.attrib for p in x.findall('./properties/property')]) for x in cases],
                image=image,link_plan=b.identity(out/'link-plan.json'),xml=b.identity(out/'tests.xml'))
            c.save(out/'receipt.json',receipt)
            print(receipt,flush=True)
