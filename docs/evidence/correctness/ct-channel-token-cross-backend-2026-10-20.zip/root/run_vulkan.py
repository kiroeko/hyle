from pathlib import Path
import importlib.util, sys, xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; C=S.parent; A=C.parent
spec=importlib.util.spec_from_file_location('ct_vulkan_gpu_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
plan_path=C/'vulkan/checks/link-plan.json';plan=c.read(plan_path)
image=next(x[5:] for x in plan['command'] if x.upper().startswith('/OUT:'))
out=C/'vulkan/validation/final1';out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
assert not (out/'tests.result.json').exists()
assert all(b.same(row) for row in plan['inputs'])
env,runtime=b.environment(plan['command'],[row['path'] for row in plan['inputs']],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
filter='VulkanFp8ChannelTokenQdqGraph.*:VulkanFp8ChannelTokenStorage.*:VulkanStaticFp8ReferenceGraph.*:VulkanNvfp4ReferenceGraph.ByteCarrier*'
try:c.execute('tests',[image,'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
finally:
 if (out/'tests.xml').exists():
  cases=ET.parse(out/'tests.xml').findall('.//testcase');failed=[x.attrib for x in cases if x.find('failure') is not None];skipped=[x.attrib for x in cases if x.find('skipped') is not None]
  receipt=dict(passed=bool(cases) and not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,
    filter=filter,names=[x.get('classname')+'.'+x.get('name') for x in cases],
    properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[p.attrib for p in x.findall('./properties/property')]) for x in cases],
    image=b.identity(image),link_plan=b.identity(plan_path),xml=b.identity(out/'tests.xml'))
  c.save(out/'receipt.json',receipt);print(receipt,flush=True)
