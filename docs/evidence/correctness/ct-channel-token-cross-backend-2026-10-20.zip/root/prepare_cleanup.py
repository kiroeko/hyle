from pathlib import Path
import hashlib, json

S=Path(__file__).resolve().parent; C=S.parent; A=C.parent; ROOT=A.parents[1]
def identity(path):
    path=Path(path); raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def encoded(data):return (json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8')

report=ROOT/'docs/evidence/correctness/ct-channel-token-cross-backend-2026-10-20.json'
doc=json.loads(report.read_text(encoding='utf-8'))
archive=doc['archive']['identity']; assert identity(archive['path'])==archive
assert doc['total_final_passed']==20 and doc['final_failed']==0 and doc['final_skipped']==0
targets=[]
for p in sorted(C.rglob('*')):
    if not p.is_file() or p.suffix.lower() not in {'.exe','.map','.lib','.exp'}:continue
    assert p.resolve().is_relative_to(C.resolve()) and not p.is_symlink()
    targets.append(identity(p))
protected=[identity(p) for p in sorted(C.rglob('*.obj'))]
old=json.loads((A/'quark-mxfp4-reference/root/cleanup-plan.json').read_text(encoding='utf-8'))
consumer=[row for row in old['protected'] if Path(row['path']).suffix.lower()=='.exe']
assert len(consumer)==1
assert identity(consumer[0]['path'])==consumer[0]
protected+=consumer
assert not ({x['path'].lower() for x in protected} & {x['path'].lower() for x in targets})
plan=dict(root=str(C.resolve()),artifact=archive,targets=targets,protected=protected,
    reclaim_bytes=sum(row['bytes'] for row in targets),
    scope='Only this completed Windows CT QDQ package executable/map/import files; retain all current increment objects, commands, sources/results and the unchanged Qwen consumer. No recursive removal or Mac operation.')
assert not (S/'cleanup-plan.json').exists()
(S/'cleanup-plan.json').write_bytes(encoded(plan))
print(json.dumps(dict(files=len(targets),bytes=plan['reclaim_bytes'],protected=len(protected),targets=[row['path'] for row in targets]),indent=2))
