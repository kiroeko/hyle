"""Archive this bounded ordinary-Graph bridge package, without binaries or SDKs."""
from pathlib import Path
import hashlib, json, xml.etree.ElementTree as ET, zipfile

S=Path(__file__).resolve().parent; ROOT=S.parents[2]
DEST=ROOT/'docs/evidence/correctness/ct-channel-token-cross-backend-2026-10-20'
def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def encoded(value): return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def identity(path):
    path=Path(path); raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

xml_paths={
    'Windows CPU': ('cpu/checks/attempt2/tests.xml',5),
    'Windows CUDA RTX4070': ('cuda/checks/attempt1/tests.xml',5),
    'Windows Vulkan RTX4070': ('vulkan/validation/final1/tests.xml',7),
    'macOS Apple M4': ('apple/mac/remote/results/tests.xml',3),
}
results=[]
for backend,(relative,count) in xml_paths.items():
    path=S/relative; cases=ET.parse(path).findall('.//testcase')
    assert len(cases)==count and not any(x.find('failure') is not None or x.find('skipped') is not None for x in cases)
    primary=[x for x in cases if 'Fp8ChannelTokenQdqGraph' in x.get('classname','')]
    assert len(primary)==2
    submissions=[p.get('value') for x in primary for p in x.findall('./properties/property') if p.get('name')=='actual_submissions']
    assert sorted(submissions)==['4','6']
    results.append(dict(backend=backend,passed=count,failed=0,skipped=0,xml=relative,identity=identity(path),
        new_CT_and_boolean_storage_cases=2,new_CT_and_boolean_actual_submissions=10,
        names=[x.get('classname')+'.'+x.get('name') for x in cases]))

sources=[
    'src/compute_route_apple/apple_tensor.cc','src/compute_route_apple/apple_static_fp8.cc',
    'src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc',
    'src/compute_route_vulkan/vulkan_tensor.cc','src/compute_route_vulkan/vulkan_program.cc',
    'src/compute_route_vulkan/shaders/tensor.comp','src/compute_route_vulkan/shaders/fp8_storage.glsl',
    'src/compute_route_vulkan/build_shaders.py',
    'src/compute_provider_native/cast.cc','src/compute_provider_cuda/tensor_kernel.cu',
    'src/compute_provider_cuda/tensor_provider.cc',
    'tests/compute_models/fp8_channel_token_qdq_fixture.h',
    'tests/graph_route_apple/nvfp4_reference_test.cc',
]
for arm in ['cpu','cuda','vulkan','apple']:
    sources.extend([f'tests/graph_route_{arm}/fp8_channel_token_qdq_test.cc',f'tests/graph_route_{arm}/CMakeLists.txt'])
frozen=[identity(ROOT/p) for p in sources]
(S/'root/final-source-freeze.json').write_bytes(encoded(dict(files=frozen)))
assert load(S/'review/source-review.json')
catalog=load(ROOT/'docs/implementation/model-quantizations.json')
assert len(catalog['artifacts'])==33 and all(x['provider_coverage']['artifact_execution_verified'] is False for x in catalog['artifacts'])
catalog_update=load(S/'catalog-update/validation.json')
report=dict(
    status='PASS: CT BF16 channel/token QDQ ordinary Graph on four backends',
    source_definition='docs/evidence/research/fp8-channel-token-contract-2026-10-20.json',
    implementation_scope=dict(
        Apple='Ordinary F32/F16/BF16-to-Bool Cast uses IEEE magnitude bits; reverse Bool Cast and Select normalize any nonzero raw byte. Floating Select retains its original integer-bit payload path.',
        Vulkan='Ordinary F32/F16/BF16-to/from-Bool Cast and F16/BF16-to/from-E4M3FN storage bridges. Existing byte-copy Select, BF16 arithmetic and ordinary MatMul retained.',
        unchanged='CPU/CUDA already implement the required leaves; current shared tests were refreshed against retained current product objects.',
        excluded='No FP8-to/from-Bool or integer-to/from-Bool expansion, no new public operator, backend switch, executor or model whitelist.'),
    numerical_contract=dict(
        graph='Original rank3 BF16 A[B,T,K], BF16 last-axis absmax/448; replace exactly zero scale by epsilon1/128, not an epsilon floor. BF16 divide/clamp -> saturated nearest-even E4 -> BF16 reconstruction.',
        weight='Original E4 W[N,K] -> BF16 -> multiply BF16 channel scale[N,1] with BF16 rounding; transpose and ordinary F32-accumulating MatMul -> BF16 output.',
        non_equivalence='No replacement by a raw FP8 code-dot with scales outside the sum; original intermediate BF16 rounding remains observable.',
        primitive_edges='Three floating storage types: +/-zero false; minimum +/-subnormal, +/-Inf and NaN true; arbitrary nonzero Bool bytes restore floating0/1. Broadcast [7,1] mask with [1,3]/[7,1] branches preserves exact selected signedzero/subnormal/NaN payload bits.'),
    architecture='Existing GraphBuilder, cold backend lowering, Program/Invocation, prepare/capture, Completion and output leases. No change to shared scheduling, allocation policy or resource-retirement core.',
    resources='Original two QDQ Invocation slots with stable input updates; materialized constant owners/executable dropped; retained output blocks replay, and output survives Invocation destruction. The primitive guard repeats updates and ownership checks for three dtypes. No peak-memory measurement.',
    catalog_scope=dict(indices=[2,8],
        artifact2='Freesolo-Co Qwen3.5-2B inspected186 language-role weights with BF16[N,1] scales; no vision-role inference.',
        artifact8='Unsloth Qwen3.8-27B NVFP4 artifact FP8 attention/head and last8-layer MLP overrides only; layers0..55 local NVFP4 is a separate completed contract.',
        excluded='Quark per-channel axis/F32 scales, official block128/group128 and static ModelOpt FP8 are not borrowed.',
        evidence_scope='Synthetic original-format numerical and lifetime reference; role headers/source establish applicability, not selected publisher numeric payload or complete importer/model execution.',
        artifact_execution_verified_false_count=33,update=catalog_update),
    results=results,total_final_passed=20,final_failed=0,final_skipped=0,
    actual_primary_submissions=40,
    build_scope='Windows: CPU/CUDA one test TU each, Vulkan two product CXX plus one test CXX and six affected GLSL variants;15 unaffected SPV reused. Apple one product CXX plus wrapper, then wrapper-only mechanical header refresh. No SDK rebuilt or unrelated full build.',
    baseline=dict(Apple='Original graph actually failed compile at the floating-only Bool Cast guard; baseline/results/tests.xml and command logs retained.',
        Vulkan='Missing typed Bool/FP8 bridges established by source inspection; old shader baseline was not executed. Final graph and neighbors were executed on RTX4070.'),
    retained_build_failures=[
        'Shared test max_blocks initialized from size_t triggered MSVC C4267 under /WX. Fixed to the known bound4, no numerical change; first failed receipts and Apple first complete pass retained.',
        'Vulkan wrapper initially omitted explicit Operation construction in two helper calls; corrected test setup only.',
        'Vulkan first link attempted the test object after failed compilation and hit LNK1181; final current linked image and inputs are identified separately.'
    ],
    review_members=['review/scope.json','review/source-review.json','vulkan/compiled-identities.json','apple/final-validation.json'],
    limits=['No publisher numeric weight payload, complete artifact/model, quality or deployment-native FP8-dot equivalence claim.',
        'No Linux execution or installed-consumer qualification by this package.',
        'No throughput, peak-memory or energy result; current BF16 Qwen consumer uses a different path.',
        'No all-code-space qualification of the F16/E4 bridge or arbitrary quantizer/axis/scale combinations.'],
    progress=dict(capability_packages_complete=6,capability_packages_total=8,delivery_packages_complete=0,delivery_packages_total=3,
        next='CT packed grouped/expert space: bounded packed consumption instead of a full decoded expert bank'))

entries={}
allowed={'.py','.json','.cc','.h','.cu','.mm','.metal','.glsl','.comp','.log','.xml','.d','.diff','.txt','.spv','.sh','.ps1'}
for path in sorted(S.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or path.name in ['package-receipt.json','cleanup-plan.json'] or path.suffix.lower() not in allowed:
        continue
    entries[path.relative_to(S).as_posix()]=path.read_bytes()
for relative,row in zip(sources,frozen):
    raw=(ROOT/relative).read_bytes(); assert hashlib.sha256(raw).hexdigest()==row['sha256']
    entries['current-source/'+relative]=raw
entries['report-core.json']=encoded(report)
entries['inventory.json']=encoded(dict(members=[dict(member=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in sorted(entries.items())],
    scope='Inventory excludes itself; no executable, object, map, library or SDK archive'))
DEST.parent.mkdir(parents=True,exist_ok=True)
assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Preserve published evidence'
with zipfile.ZipFile(DEST.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(entries.items()):
        assert not name.startswith('/') and '..' not in Path(name).parts
        archive.writestr(name,raw)
with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))
    for name,raw in entries.items(): assert archive.read(name)==raw
report['archive']=dict(identity=identity(DEST.with_suffix('.zip')),members=len(entries),current_sources=len(frozen))
DEST.with_suffix('.json').write_bytes(encoded(report))
receipt=dict(report=identity(DEST.with_suffix('.json')),archive=report['archive'],all_final_cases=20,failed=0,skipped=0)
(S/'package-receipt.json').write_bytes(encoded(receipt))
print(json.dumps(receipt,indent=2))
