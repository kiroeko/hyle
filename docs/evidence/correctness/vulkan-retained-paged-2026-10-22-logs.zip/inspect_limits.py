"""Read actual driver allocation limits without building another consumer."""
from pathlib import Path
import hashlib,json,re,subprocess,time
S=Path(__file__).resolve().parent
image=Path('C:/Windows/System32/vulkaninfo.exe');out=S/'driver-limits';out.mkdir()
start=time.time();child=subprocess.run([str(image)],capture_output=True,cwd=out)
raw=child.stdout.decode('utf8',errors='replace');err=child.stderr.decode('utf8',errors='replace')
selected=[line for line in raw.splitlines()if re.search(r'deviceName|maxMemoryAllocationCount|heapBudget|heapUsage|memoryHeapCount|VK_LAYER_.*(api_dump|monitor|validation)',line)]
report=dict(command=[str(image)],image=dict(bytes=image.stat().st_size,sha256=hashlib.sha256(image.read_bytes()).hexdigest()),exit=child.returncode,seconds=time.time()-start,selected_properties=selected,stderr=err,full_output_sha256=hashlib.sha256(child.stdout).hexdigest(),scope='Driver query after failed consumer process exit; not in-process usage or proof of its OOM cause')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print(json.dumps(report))
assert child.returncode==0
