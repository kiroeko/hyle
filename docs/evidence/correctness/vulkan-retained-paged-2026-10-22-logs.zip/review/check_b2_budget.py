"""Resolve the already captured budget backtrace; never executes native code."""
from bisect import bisect_right
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[3]
AO = ROOT / ".scratch/vulkan-retained-paged-20261022"


def identity(path):
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    run = AO / "qwen-N2R2-run2"
    result = read_json(run / "result.json")
    assert result["state"] == "terminal" and result["exit"] == 1
    assert result["image"] == read_json(AO / "diagnostic-link1/ready.json")["image"]
    assert read_json(AO / "diagnostic-link1/link.result.json")["exit"] == 0
    stderr = (run / "stderr.log").read_text(encoding="utf-8")
    events = list(re.finditer(r"AO_BUDGET_RESERVE_FAIL bytes=(\d+) category=(\d+) host=(\d+) resource=([0-9A-Fa-f]+) base=([0-9A-Fa-f]+)", stderr))
    assert len(events) == 1
    size, category, host, resource, base = events[0].groups()
    size, category, host, base = int(size), int(category), int(host), int(base, 16)
    assert (size, category, host) == (4, 2, 1)
    map_path = AO / "diagnostic-link1/qwen.map"
    map_text = map_path.read_text(encoding="utf-8")
    preferred = int(re.search(r"Preferred load address is ([0-9A-Fa-f]+)", map_text)[1], 16)
    symbols = []
    for line in map_text.splitlines():
        match = re.match(r"^\s+([0-9A-Fa-f]{4}):([0-9A-Fa-f]{8})\s+(\S+)\s+([0-9A-Fa-f]{16})\s+(.*)", line)
        if match and match[1] == "0001":
            symbols.append((int(match[4], 16), match[3], match[5]))
    symbols.sort()
    addresses = [item[0] for item in symbols]
    frames = []
    for ordinal, pc in re.findall(r"AO_BUDGET_FRAME (\d+) ([0-9A-Fa-f]+)", stderr):
        pc = int(pc, 16)
        virtual = pc - base + preferred
        # A captured return PC belongs to the caller ending just before it.
        selected = bisect_right(addresses, virtual - 1) - 1
        assert selected >= 0
        address, name, owner = symbols[selected]
        assert selected + 1 == len(symbols) or virtual - 1 < symbols[selected + 1][0]
        frames.append({"frame": int(ordinal), "actual_pc": hex(pc), "rva": hex(pc - base),
                       "map_va": hex(virtual), "nearest_code_symbol": name,
                       "return_pc_offset_bytes": virtual - address, "owner": owner})
    assert [frame["frame"] for frame in frames] == list(range(18))
    for frame, name in zip(frames, ("?reserve@ResourceBudget", "?allocate_buffer@", "?allocate_values@", "?create_invocation@Program", "?create_slot@")):
        assert frame["nearest_code_symbol"].startswith(name)
    link = read_json(AO / "diagnostic-link1/link-plan.json")
    expected_receipts = [
        ROOT / ".scratch/vulkan-qwen-assembly-20261022/compile1/main/identity.json",
        AO / "compile1/program/identity.json", AO / "compile1/diag-budget/identity.json"]
    compiled_sources = [
        ROOT / ".scratch/vulkan-qwen-assembly-20261022/compile1/main/source/tools/qwen35_text/main.cc",
        AO / "compile1/program/source/src/compute_route_vulkan/vulkan_program.cc",
        AO / "diagnostic/source/resource_budget.cc"]
    owners = []
    for receipt_path, source_path in zip(expected_receipts, compiled_sources):
        receipt = read_json(receipt_path)
        assert any(item["sha256"] == receipt["object"]["sha256"] and item["path"] == receipt["object"]["path"] for item in link["inputs"])
        frozen = identity(source_path)
        assert frozen["sha256"] == receipt["source"]["sha256"]
        owners.append({"receipt": identity(receipt_path), "compiled_source": frozen,
                       "object": receipt["object"], "compile_command_sha256": hashlib.sha256(
                           json.dumps(receipt["command"], ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()})
    old_main = compiled_sources[0].read_text(encoding="utf-8")
    assert "c::ResourceBudgetLimit{execution.device()}," in old_main
    assert "c::ResourceBudgetLimit{mem::system_resource()}" in old_main
    report = {
        "status": "FROZEN_HOST_ONLY_ACTUAL_B2_BUDGET_CAUSE",
        "scope": "One existing failed diagnostic process, MAP/source/receipt analysis only; no new native execution, build, product change, or post-fix pass claim.",
        "image": result["image"], "terminal": {"exit": result["exit"], "pid": result["pid"]},
        "event": {"bytes": size, "category": category, "category_name": "kWorkspace",
                  "host_accessible": bool(host), "resource_object_address": "0x" + resource,
                  "actual_module_base": hex(base), "preferred_module_base": hex(preferred)},
        "resolved_frames": frames,
        "confirmed_chain": ["ResourceBudget::reserve", "vulkan::detail::allocate_buffer",
                            "vulkan::detail::allocate_values", "vulkan::Program::create_invocation",
                            "graph::vulkan ordinary native Region create_slot", "Graph region/Executable create_invocation",
                            "qwen35::Model::initialize_slot", "qwen35::Model::prepare_evaluations"],
        "source_cause": [
            {"anchor": "tools/qwen35_text/main.cc:959-962 (actual compiled frozen source)",
             "fact": "Native execution budget lists only device and system_resource. Its independent Vulkan staging resource is absent."},
            {"anchor": "tools/qwen35_text/backend.h:140-145; src/graph_route_vulkan/native_region.cc:928-946",
             "fact": "Backend Graph environment does supply actual device and staging domains. Native Region allocation selects the actual host-accessible staging domain for status storage; system_resource is not its identity."},
            {"anchor": "tools/qwen35_text/main.cc:1393-1396; include/hyle/compute/operation.h:363-365",
             "fact": "R1 selects the last hidden row with Slice/Copy; R>1 selects each request's row using ordinary Gather with default checked bounds."},
            {"anchor": "src/compute_route_vulkan/vulkan_region.cc:982-992; vulkan_program_internal.h:77-80",
             "fact": "Checked Gather creates a status_value and index check, requiring staging. Conv/GDN pack/scatter is not needed to explain this failure."},
            {"anchor": "src/compute_route_vulkan/vulkan_program.cc:118-123; vulkan_device.cc:194-209",
             "fact": "The only allocate_values staging allocation is a four-byte status word, charged to run.allocation.staging via the given execution budget. Actual bytes4/category2/host1 and the resolved stack match this branch."}],
        "correct_layer": "Consumer external-resource budget assembly: enumerate/deduplicate actual device, staging and system resources in native execution budget. Keep cache/retained-device budget separate. Do not remove checked Gather, change math, alias staging to system, or weaken resource membership checks.",
        "not_this_cause": "This failure occurs during create_invocation before prefill submit/finish. The captured stack contains no GraphOutput::storage_lease, LeaseAccess::retain_budget or shared retained-backing admission; readonly state nomination is not the failing path here.",
        "limits": ["MAP resolves nearest linked code symbols and offsets, not source-line PC debug info; return PCs are matched using pc-1. Source control flow identifies the four-byte staging branch.",
                   "The numeric resource pointer is process-local; typed staging identity follows from allocate_values' unique host status allocation, not blindcasting the address.",
                   "Current canonical main may already contain root's fix; this report binds the failed image's original compiled source snapshot and receipts instead."],
        "verification": {"one_reserve_failure": True, "all_18_frames_resolved": True,
                         "first_five_expected_callers_match": True, "image_matches_ready": True,
                         "compiled_source_and_object_receipts_match_link_inputs": True},
        "compiled_owners": owners,
        "evidence": [identity(path) for path in (
            run / "command.json", run / "result.json", run / "stderr.log", map_path,
            AO / "diagnostic-link1/link-plan.json", AO / "diagnostic-link1/link.command.json",
            AO / "diagnostic-link1/link.result.json", AO / "diagnostic/budget-recipe.json")],
        "recompute": ".scratch/vulkan-retained-paged-20261022/review/check_b2_budget.py"
    }
    output = AO / "review/b2-budget-cause.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(identity(output)))


if __name__ == "__main__":
    main()
