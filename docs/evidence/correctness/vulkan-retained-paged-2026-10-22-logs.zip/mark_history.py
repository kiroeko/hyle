from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'docs/developer/current-work.md';t=p.read_text(encoding='utf8')
before='同原P15／4、C64／N1／R1及256MiB缓存额度，完整320份权重已加载'
after='上批BF16修复窗口中，以同原P15／4、C64／N1／R1及256MiB缓存额度，完整320份权重已加载'
assert t.count(before)==1;t=t.replace(before,after);p.write_text(t,encoding='utf8')
p=R/'tools/qwen35_text/README.md';t=p.read_text(encoding='utf8')
t=t.replace('，之后，[paged／ragged输出复用修复]','；[paged／ragged输出复用修复]')
p.write_text(t,encoding='utf8')
