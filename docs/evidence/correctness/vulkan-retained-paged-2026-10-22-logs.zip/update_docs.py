"""Publish current functional progress and preserve the new real capacity failure."""
from pathlib import Path
S=Path(__file__).resolve().parent;R=S.parents[1]
p=R/'docs/developer/current-work.md';t=p.read_text(encoding='utf8')
before='此前“约70%（65%～75%）”仅为全后端及已选模型范围的工程粗估，不能解释成K1算法仍缺三成；当前按以下实际余项推进：'
after='Vulkan本批也已实际通过同一普通／K1 R1短流程，覆盖拒绝与接受；当前按实际余项推进：'
assert t.count(before)==1;t=t.replace(before,after)
before='- **跨平台完整执行**：Apple前缀／原生取消组合；Vulkan完整普通版及K1消费者。Vulkan预算身份及device IO已实测，整权重F32展开造成的OOM本批已修；普通版已完成prefill及两次decode，第三次槽复用仍被旧输出引用计数门拒绝，见下。'
after='- **跨平台完整执行**：Apple前缀／原生取消组合；Vulkan多会话、前缀／取消及容量收口。Vulkan普通／K1 R1短流程已通过；N2／R2已实际执行B2、追赶、重建及第二轮，随后原生私有分配OOM，尚需定量修复，见下。'
assert t.count(before)==1;t=t.replace(before,after)
start=t.index('**下一步补分页／ragged reader的旧输出复用接线。**');end=t.index('最新四臂的64token续文',start)
t=t[:start]+'''**[分页／ragged输出复用已补齐并完成本批原生检查](../evidence/correctness/vulkan-retained-paged-2026-10-22.json)。** 冷布局编辑只在真实退休后撤执行资格；同一未发布输出epoch可重复准备／失败重试，完整bind及最终seal才建立新private baseline。两reader复用原整owned block轮换、Run／Program／endpoint；旧readonly storage及提交门不放宽。未完成的存储选择先保rearm guard，不能在重试时误认成功。RTX4070实际通过capacity-paged／owned-paged／ragged三case，各同Invocation三代、whole／offset-slice旧字节／只读、释放首代后第三代复用原spare、销Invocation后仍可读；原ordinary复用／canonical预算／device IO三case也通过。fixture首轮误撤typed KV端口，已按原合同改为核拒绝并只撤普通Q，未放宽产品权限。

**当前Vulkan完整普通／K1的R1短流程已通过。** 同335／320原权重，P15／4、C64／N1／R1、cache256MiB、prefix off、commands；当前镜像两模式4枚greedy ID均为1328／5675／11／9637，与CUDA／Apple既有同输入相同。K1实际先拒绝再接受，3次Graph、19target／17draft行，最终frontier17／lag1；短流程不代表质量或速度验收。

进一步复用既有三会话两轮N2／R2输入，首B2的checked Gather暴露缺失staging预算：实际4B状态字及回溯确认native allocate_values，非readonly lease收费。消费者native执行预算现按实际device／staging／system身份去重注册，cache额度、Gather检查及数学不变；仅补资源装配。修后用例已越过B2 prefill／verify、追赶、淘汰恢复及第二轮输入，但下一次B2／T2载体创建报33,024B原生allocation OOM，完整多会话未通过。

**下一步定量原生私有内存和执行槽成本。** 锁定ggml每nonzero backend buffer独立分配VkDeviceMemory，无跨region池；请求bytes不等于实际mem_req字节。本机vulkaninfo实查maxMemoryAllocationCount＝4,294,967,295，不能套4096上限解释。尚无失败时live heap／NativeWork scratch账，不凭小请求便判数量或字节根因，也不通过缩用例、降精度或绕预算掩盖失败。本批无新完整TPS／显存对照，页末表保持。

''' +t[end:]
for before,after in {
'接下来补paged／ragged reader输出epoch复用':'paged／ragged三代复用及R1普通／K1短流程本批已通过；N2／R2在第二轮B2创建时native私有分配OOM仍待收口',
'权重重复展开OOM已修，完整普通版仍需补paged／ragged输出复用。随后补Apple前缀／原生取消组合与数值质量':'权重展开及输出复用已修，当前普通／K1 R1短流程通过；N2／R2多会话私有内存压力仍待定量修复。随后补Apple前缀／原生取消组合与数值质量'
}.items():
    assert t.count(before)==1,before;t=t.replace(before,after)
p.write_text(t,encoding='utf8')
p=R/'tools/qwen35_text/README.md';t=p.read_text(encoding='utf8')
before='完整普通版实际完成prefill及两次decode，第三次槽复用仍报`Vulkan batch native output retained`。完整普通推理和MTP尚未通过。'
after='之后，[paged／ragged输出复用修复](../../docs/evidence/correctness/vulkan-retained-paged-2026-10-22.json)已接通普通／K1 R1短流程，4枚输出与CUDA／Apple一致。既有N2／R2多会话已越过B2及部分淘汰重建，仍在第二轮B2创建时发生原生私有分配OOM；完整多会话／质量和性能尚未收口。'
assert t.count(before)==1;t=t.replace(before,after);p.write_text(t,encoding='utf8')
print('Current Vulkan state updated; full comparison table unchanged.')
