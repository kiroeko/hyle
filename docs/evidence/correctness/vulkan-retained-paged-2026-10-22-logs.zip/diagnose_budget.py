"""One cold failure backtrace, no product logging or precision change."""
from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('ao_budget_diag',S/'build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c,h=m.b,m.c,m.h
recipe_path=m.n.m.owner('src/compute/resource_budget.cc');recipe=c.read(recipe_path)
original=R/'src/compute/resource_budget.cc';text=original.read_text(encoding='utf8')
needle='''  if (row == nullptr || static_cast<std::size_t>(category) >= kResourceBudgetCategoryCount)
    return std::unexpected(Status::InvalidArgument("resource is absent from budget"));'''
replace='''  if (row == nullptr || static_cast<std::size_t>(category) >= kResourceBudgetCategoryCount) {
    std::fprintf(stderr, "AO_BUDGET_RESERVE_FAIL bytes=%zu category=%zu host=%d resource=%p base=%p\\n",bytes,static_cast<std::size_t>(category),resource.valid() && resource.properties().has(mem::MemoryProperty::kHostAccessible),resource.valid()?static_cast<const void*>(&resource.resource()):nullptr,GetModuleHandleW(nullptr));
    void *frames[18]{}; const auto count=CaptureStackBackTrace(0,18,frames,nullptr);
    for(unsigned i=0;i<count;++i) std::fprintf(stderr,"AO_BUDGET_FRAME %u %p\\n",i,frames[i]);
    return std::unexpected(Status::InvalidArgument("resource is absent from budget"));
  }'''
assert text.count(needle)==1
prefix='#ifndef NOMINMAX\n#define NOMINMAX\n#endif\n#include <windows.h>\n#include <cstdio>\n'
source=S/'diagnostic/source/resource_budget.cc';source.parent.mkdir(parents=True,exist_ok=True);source.write_text(prefix+text.replace(needle,replace),encoding='utf8')
recipe['command']=[{'-MD':'/MD','-O2':'/O2'}.get(x,x)for x in recipe['command']]
path=S/'diagnostic/budget-recipe.json';c.save(path,recipe);h.RECIPES['diag-budget']=path;h.SOURCES['diag-budget']=source;h.compile_one('diag-budget',1)
base=c.read(S/'qwen-link1/link-plan.json');old=recipe['object'];new=c.read(S/'compile1/diag-budget/identity.json')['object']
assert sum(c.key(x['path'])==c.key(old['path'])for x in base['inputs'])==1
out=S/'diagnostic-link1';out.mkdir();(out/'tmp').mkdir();image=out/'qwen.exe'
command=[new['path']if c.key(x)==c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[new if c.key(x['path'])==c.key(old['path'])else x for x in base['inputs']]
for x in inputs:assert b.identity(x['path'])==x
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,diagnostic_only=True,product_source=b.identity(original),SDK_builds=0,NVCC=0))
env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
c.save(out/'runtime-environment.json',c.read(S/'qwen-link1/runtime-environment.json'));c.save(out/'ready.json',dict(image=b.identity(image)))
