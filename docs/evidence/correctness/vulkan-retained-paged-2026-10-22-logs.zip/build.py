"""Reuse AN/AM closures; only three native owner TUs and one test are rebuilt."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
AN=R/'.scratch/vulkan-bf16-linear-20261022';AM=R/'.scratch/vulkan-qwen-assembly-20261022'
spec=importlib.util.spec_from_file_location('ao_cached',AN/'build.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
b,c=n.b,n.c;h=n.h;h.S=S
NAMES={'program':'src/compute_route_vulkan/vulkan_program.cc','page':'src/graph_route_vulkan/native_paged_region.cc','ragged':'src/graph_route_vulkan/native_ragged_region.cc','test':'tests/graph_route_vulkan/retained_attention_consumer.cc','main':'tools/qwen35_text/main.cc'}
ORIGINAL={'program':AN/'compile1/route-program/identity.json','page':n.m.owner(NAMES['page']),'ragged':n.m.owner(NAMES['ragged']),'test':AN/'compile2/test/identity.json','main':AM/'compile1/main/identity.json'}
ROOTS={'qwen':AN/'qwen-link1','test':AN/'test-link2','reuse':AM/'test-link3'}

def compile_one(tag,attempt):
    old=c.read(ORIGINAL[tag]);old['command']=[{'-MD':'/MD','-O2':'/O2'}.get(x,x)for x in old['command']]
    root=S/'recipes';root.mkdir(exist_ok=True);recipe=root/(tag+'.json');c.save(recipe,old)
    h.RECIPES[tag]=recipe;h.SOURCES[tag]=R/NAMES[tag];h.compile_one(tag,attempt)

def latest(tag,attempt):
    for i in range(attempt,0,-1):
        p=S/f'compile{i}/{tag}/identity.json'
        if p.exists():
            v=c.read(p);assert b.identity(v['source']['path'])==v['source'];assert b.identity(v['object']['path'])==v['object'];return p,v
    raise ValueError('No compiled owner '+tag)

def link(kind,attempt):
    root=ROOTS[kind];base=c.read(root/'link-plan.json');tags=['program','page','ragged']+(['test']if kind=='test'else[])
    if kind=='qwen'and any((S/f'compile{i}/main/identity.json').exists()for i in range(1,attempt+1)):tags+=['main']
    replacements={};records=[]
    for tag in tags:
        p,v=latest(tag,attempt);recipe=n.ORIGINAL['route-program']if kind=='reuse'and tag=='program'else ORIGINAL[tag]
        old=c.read(recipe)['object'];replacements[c.key(old['path'])]=v['object'];records.append(b.identity(p))
    for key in replacements:assert sum(c.key(x['path'])==key for x in base['inputs'])==1,key
    for x in base['inputs']:assert b.identity(x['path'])==x
    out=S/(kind+'-link'+str(attempt));out.mkdir();(out/'tmp').mkdir();image=out/(kind+'.exe')
    command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_records=records,SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(root/'runtime-environment.json');c.save(out/'runtime-environment.json',runtime)
    for x in runtime.get('staged_dlls',[]):
        p=Path(x['path'])
        if not(out/p.name).exists():os.link(p,out/p.name)
    c.save(out/'ready.json',dict(image=b.identity(image),plan=b.identity(out/'link-plan.json')));print('LINKED',kind,flush=True)

def run(kind,attempt):
    root=S/(kind+'-link'+str(attempt));out=S/(kind+'-run'+str(attempt));out.mkdir()
    command=[str(root/(kind+'.exe'))];env=dict(os.environ,PATH=c.read(root/'runtime-environment.json')['PATH'])
    c.save(out/'image.json',b.identity(command[0]));c.execute('run',command,env,out);print((out/'run.stdout.log').read_text(errors='replace'))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('actions',nargs='+',choices=[*NAMES,'link-test','link-reuse','link-qwen','run-test','run-reuse']);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
    for action in a.actions:
        if action.startswith('link-'):link(action[5:],a.attempt)
        elif action.startswith('run-'):run(action[4:],a.attempt)
        else:compile_one(action,a.attempt)
