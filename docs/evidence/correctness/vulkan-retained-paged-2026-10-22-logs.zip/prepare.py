"""Freeze only current owners needed for the retained page-reader fix."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1]
names=['src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_composition_access.h','include/hyle/compute/detail/materialized_native_controller.h','src/graph_route_vulkan/native_paged_region.cc','src/graph_route_vulkan/native_ragged_region.cc','tests/graph_route_vulkan/CMakeLists.txt','docs/developer/current-work.md','tools/qwen35_text/README.md','test.ps1']
records=[]
for name in names:
    p=R/name;b=p.read_bytes();q=S/'before'/name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();q.write_bytes(b)
    records.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(S/'before.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8')
print('Frozen',len(records),'small source/document owners.')
