"""Current-source/log evidence plus exact-file cleanup; no native execution."""
from pathlib import Path
import argparse,difflib,hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1];E=R/'docs/evidence/correctness';NAME='vulkan-retained-paged-2026-10-22'
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def read(p):return json.loads(p.read_bytes())
def ident(p):
    p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def prepare():
    assert read(S/'live.json')['state']=='terminal'
    keep={'qwen-link2/qwen.exe','test-link2/test.exe','reuse-link1/reuse.exe'}
    paths=[p for root in S.glob('*-link*')for p in root.iterdir()if p.is_file()and(p.suffix in ['.map','.lib','.exp']or(p.suffix=='.exe'and p.relative_to(S).as_posix()not in keep))]
    old=[R/'.scratch/vulkan-qwen-assembly-20261022/qwen-link3/qwen.exe',R/'.scratch/vulkan-qwen-assembly-20261022/test-link3/test.exe',R/'.scratch/vulkan-bf16-linear-20261022/qwen-link1/qwen.exe',R/'.scratch/vulkan-bf16-linear-20261022/test-link2/test.exe']
    paths += [p for p in old if p.is_file()]
    allowed=[S,R/'.scratch/vulkan-qwen-assembly-20261022',R/'.scratch/vulkan-bf16-linear-20261022']
    for p in paths:assert sum(p.resolve().is_relative_to(q.resolve())for q in allowed)==1
    records=[ident(p)for p in paths]
    rows=['  @{ Path = '+"'"+str(R/x['path'])+"'; Bytes = "+str(x['bytes'])+"; SHA256 = '"+x['sha256']+"' }"for x in records]
    text='''# AO: only superseded executables/linker outputs; all cached source/objects stay.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$allowed = @('vulkan-retained-paged-20261022','vulkan-qwen-assembly-20261022','vulkan-bf16-linear-20261022') | ForEach-Object { Join-Path $workspace ('.scratch\\' + $_) }
$targets = @(
'''+ '\n'.join(rows)+'''
)
foreach ($target in $targets) {
  $leaf = Get-Item -LiteralPath $target.Path -Force
  $inside = @($allowed | Where-Object { $leaf.FullName.StartsWith($_ + '\\', [StringComparison]::OrdinalIgnoreCase) }).Count -eq 1
  if ($leaf.PSIsContainer -or -not $inside -or $leaf.FullName -ne $target.Path) { throw 'Unexpected cleanup target' }
  if ($leaf.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $leaf.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.SHA256) { throw 'Cleanup target changed' }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.Path -Force }
[pscustomobject]@{ removed = $targets; logical_file_bytes = ($targets | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_measured = $false } | ConvertTo-Json -Depth 5
'''
    p=R/'test.ps1';p.write_text(text,encoding='utf8');(S/'cleanup-test.ps1').write_bytes(p.read_bytes())
    save(S/'cleanup-plan.json',dict(executed_from=ident(p),frozen_script=ident(S/'cleanup-test.ps1'),targets=records,logical_file_bytes=sum(x['bytes']for x in records)))
    print(json.dumps(dict(script=ident(p),targets=len(paths),logical_file_bytes=sum(x['bytes']for x in records))))

def publish():
    cleanup=read(S/'cleanup-plan.json');assert all(not(R/x['path']).exists()for x in cleanup['targets'])
    assert read(S/'test-run1/run.result.json')['exit']==1 and read(S/'test-run2/run.result.json')['exit']==0
    assert read(S/'reuse-run1/run.result.json')['exit']==0
    assert 'PASS Vulkan retained attention:'in(S/'test-run2/run.stdout.log').read_text()
    assert 'PASS Vulkan 3 cases:'in(S/'reuse-run1/run.stdout.log').read_text()
    summary=read(S/'summary.json')
    for mode in ['plain','mtp']:
        assert read(S/f'qwen-{mode}-run2/result.json')['exit']==0
    failures=[read(S/f'qwen-N2R2-run{i}/result.json')for i in [1,2,3]]
    assert all(x['state']=='terminal'and x['exit']==1 for x in failures)
    assert 'AO_BUDGET_RESERVE_FAIL bytes=4 category=2 host=1'in(S/'qwen-N2R2-run2/stderr.log').read_text()
    assert 'Device memory allocation of size 33024 failed'in(S/'qwen-N2R2-run3/stderr.log').read_text()
    changes=[];patch=[]
    before={p.relative_to(S/'before').as_posix():p for p in(S/'before').rglob('*')if p.is_file()and p.name!='test.ps1'}
    before['tests/graph_route_vulkan/retained_attention_consumer.cc']=None
    for rel,p in sorted(before.items()):
        q=R/rel;previous=p.read_bytes()if p else b'';current=q.read_bytes()
        if previous==current:continue
        changes.append(dict(before=ident(p)if p else None,current=ident(q)))
        frozen=S/'source'/rel;frozen.parent.mkdir(parents=True,exist_ok=True);frozen.write_bytes(current)
        patch+=list(difflib.unified_diff(previous.decode('utf8').splitlines(True),current.decode('utf8').splitlines(True),fromfile='before/'+rel,tofile='current/'+rel))
    (S/'changes.diff').write_text(''.join(patch),encoding='utf8');save(S/'current-source.json',changes)
    for tag,attempt in [('program',1),('page',1),('ragged',1),('test',2),('main',2)]:
        v=read(S/f'compile{attempt}/{tag}/identity.json')
        assert hashlib.sha256(Path(v['source']['path']).read_bytes()).hexdigest()==v['source']['sha256']
    marker='## 最新完整性能对比'
    assert (S/'before/docs/developer/current-work.md').read_text(encoding='utf8').split(marker)[1]==(R/'docs/developer/current-work.md').read_text(encoding='utf8').split(marker)[1]
    z=E/(NAME+'-logs.zip');count=0
    with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as archive:
        for p in sorted(S.rglob('*')):
            if not p.is_file()or p.suffix.lower()not in ['.py','.json','.log','.cc','.h','.md','.txt','.diff','.ps1','.tsv']:continue
            if 'tmp'in p.relative_to(S).parts or p.stat().st_size>1024*1024:continue
            archive.write(p,p.relative_to(S).as_posix());count+=1
    with zipfile.ZipFile(z)as archive:assert archive.testzip()is None
    report=dict(date='2026-10-22',status='vulkan_R1_plain_K1_passed_multi_session_capacity_incomplete',
      implementation=['Graph-only pure-retired cold binding gate and optional prepare trait; replay/submit strict gates preserved','One unpublished output epoch through initial export, retry and failed selection; no InvocationState fields added','Paged/ragged readers use existing whole-owned-block rotation, atomic Tensor/Buffer projection update, complete bind and final seal','Native consumer execution budget registers actual device/staging/system resources once; cache budget and checked Gather unchanged'],
      changed_files=changes,regressions=dict(attention_cases=['capacity-paged','owned-paged','ragged'],shape='BF16/Q2/H2/KVH1/D64/page16',result=ident(S/'test-run2/run.result.json'),checks=['one Invocation per case, three generations','old whole and offset slice bytes/read permission unchanged','typed KV unbind remains rejected; ordinary input withdrawal revokes submit','no strict submit through partial preparation/binding','released generation1 backing reused as generation3 spare','generation2/3 remain readable after Invocation destruction'],ordinary_reuse_and_canonical_IO_result=ident(S/'reuse-run1/run.result.json')),
      finite_real_model=dict(parameters='Original P15/natural4, C64, N1/R1, cache256MiB, prefix off, commands',current_image=read(S/'qwen-link2/ready.json')['image'],generated_ids=[1328,5675,11,9637],plain_result=ident(S/'qwen-plain-run2/result.json'),mtp_result=ident(S/'qwen-mtp-run2/result.json'),protocol_output_work_comparisons=summary['runs'],quality_pass=False,performance_comparison=False),
      failures=dict(fixture='First attention fixture illegally withdrew source-owned paged KV ports; corrected to require rejection and retain original permissions, no product gate weakened',multi_session_runs=failures,budget_cause=ident(S/'review/b2-budget-cause.json'),budget_repaired='Actual 4B staging status for checked B2 Gather; fixed only native execution resource registration',remaining='N2/R2 existing three-session/two-turn journey reaches B2 prefill/verify, lag catchup, bounded reconstruction and second turn; next B2/T2 carrier creation fails original native allocation request 33024B. No complete multi-session output was produced.'),
      memory_scope=dict(driver_limits=ident(S/'driver-limits/report.json'),maxMemoryAllocationCount=4294967295,allocation_count_4096_cause_rejected=True,remaining_OOM_cause='unknown; failure-time live heap/native work scratch and per-role/slot allocations not measured',locked_source_research=ident(S/'review/native-allocation-research.json'),physical_peak_measured=False),
      limits=['No new complete TPS/memory comparison; current-work final table unchanged','Finite native mechanism and R1 real-model cases only; other profiles/prefix/cancel and complete quality remain','Four incremental product TUs plus small test; one temporary budget-diagnostic TU; cached SDK/shader/NVCC objects reused','CMake test registration changed but no CMake configure/full build run; no new CPU/Apple native run'],
      next_action='Measure failure-time heap/private NativeWork and per-role/slot costs in the actual N2/R2 journey, then fix the responsible native allocation/preparation mechanism without reducing the requested workload or relaxing permissions.',
      cleanup=cleanup,evidence_zip=ident(z),archive_files=count)
    save(E/(NAME+'.json'),report)
    print(json.dumps(dict(report=ident(E/(NAME+'.json')),logs=ident(z),removed_logical_file_bytes=cleanup['logical_file_bytes'])))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','publish']);a=p.parse_args();prepare()if a.action=='prepare'else publish()
