"""Only compare existing successful finite outputs; preserve all failures."""
from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1];AL=R/'.scratch/qwen-retained-budget-20261022'
def read(p):return json.loads(p.read_bytes())
def ident(p):
    b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
results=[]
for mode in ['plain','mtp']:
    current=S/f'qwen-{mode}-run2';result=read(current/'result.json');now=read(current/'stdout.log')
    assert result['state']=='terminal'and result['exit']==0
    keys=['source_id','score_dtype','score_policy','generated_ids','actual_graph_calls','actual_target_rows','actual_draft_rows','committed_target_rows']
    if mode=='mtp':keys+=['draft_frontier','draft_lag','rounds']
    refs=[('CUDA',AL/f'cuda-{mode}/stdout.log'),('Apple',AL/f'apple-{mode}-run1.json')];comparisons=[]
    for label,p in refs:
        before=read(p)if label=='CUDA'else json.loads(read(p)['stdout'])
        equal={key:now.get(key)==before.get(key)for key in keys};assert all(equal.values()),(mode,label,equal)
        comparisons.append(dict(backend=label,reference=ident(p),equal_fields=equal))
    results.append(dict(mode=mode,run=ident(current/'result.json'),output=ident(current/'stdout.log'),comparisons=comparisons,cache={k:v for k,v in now.items()if k.startswith('cache_')}))
report=dict(runs=results,scope='Same original finite P15/4 and score policy; output/work agreement is not full numerical quality, performance or memory peak acceptance.',failures=dict(test1=read(S/'test-run1/run.result.json'),N2R2=[read(S/f'qwen-N2R2-run{i}/result.json')for i in [1,2,3]]))
(S/'summary.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print('Compared current plain/K1 IDs, decisions and actual work with existing CUDA and Apple; all selected fields match. Full multi-session failure retained.')
