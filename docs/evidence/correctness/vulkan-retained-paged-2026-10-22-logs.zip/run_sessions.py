"""One existing three-session/two-turn N2/R2 MTP journey on current Vulkan."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
S=Path(__file__).resolve().parent;R=S.parents[1]
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--attempt',type=int,default=1);p.add_argument('--diagnostic',action='store_true');p.add_argument('--image-attempt',type=int,default=1);args=p.parse_args()
root=S/('diagnostic-link1'if args.diagnostic else'qwen-link'+str(args.image_attempt));image=root/'qwen.exe';out=S/('qwen-N2R2-run'+str(args.attempt));out.mkdir()
fixtures=R/'.scratch/qwen-mtp-batch-20261022/fixtures'
names=['sessions.txt','a-long.txt','b.txt','c.txt','p15.ids','p23.ids','u1.ids','u8.ids','u24.ids']
command=[str(image),'--inputs',str(R/'.scratch/qwen-native-assembly-20261022/inputs/mtp'),'--mtp','on','--capacity','64','--session-schedules',str(fixtures/'sessions.txt'),'--max-sessions','2','--active-sequences','2','--cache-bytes','auto','--prefix-cache','off','--progress','direct','--replay','commands']
env=dict(os.environ,PATH=json.loads((root/'runtime-environment.json').read_bytes())['PATH'])
record=dict(command=command,cwd=str(R),image=ident(image),fixtures=[ident(fixtures/x)for x in names],started=time.time(),performance_comparison=False)
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
    child=subprocess.Popen(command,cwd=R,env=env,stdout=so,stderr=se);record.update(pid=child.pid,state='running');save(out/'command.json',record);save(S/'live.json',record);print('START N2R2 PID',child.pid,flush=True);child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);save(out/'result.json',record);save(S/'live.json',record)
if child.returncode:
    print((out/'stderr.log').read_text(errors='replace')[-6500:]);raise SystemExit(1)
now=json.loads((out/'stdout.log').read_bytes())
reference=R/'.scratch/qwen-retained-budget-20261022/apple-N2R2-run1.json'
before=json.loads(json.loads(reference.read_bytes())['stdout'])
keys=['actual_graph_calls','generated_tokens','restore_count','restored_graph_calls','restored_target_rows','restored_draft_rows','normalized_lag_rows','recomputed_decision_changes','idle_evictions']
equal={k:now[k]==before[k]for k in keys}
equal['all_session_output_ids']=all(a['session_id']==b['session_id']and a['result']['generated_ids']==b['result']['generated_ids']for a,b in zip(now['sessions'],before['sessions']))and len(now['sessions'])==len(before['sessions'])
assert now['backend']=='vulkan'and now['source_id']==before['source_id']and now['session_count']==3 and now['turn_count']==6
assert any(x['requests']==2 for x in now['batches'])and now['restore_count']>0
comparison=dict(reference=ident(reference),fields=equal,work={k:now[k]for k in keys},session_ids=[dict(session_id=x['session_id'],ids=x['result']['generated_ids'])for x in now['sessions']],cache={k:v for k,v in now.items()if k.startswith('cache_')},quality_pass=False,performance_comparison=False)
save(out/'comparison.json',comparison);print(json.dumps(dict(exit=record['exit'],seconds=record['seconds'],**comparison)),flush=True)
