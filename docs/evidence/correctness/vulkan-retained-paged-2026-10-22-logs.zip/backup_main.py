from pathlib import Path
import hashlib,json
S=Path(__file__).resolve().parent;R=S.parents[1];rel='tools/qwen35_text/main.cc';p=R/rel;b=p.read_bytes()
out=S/'before'/rel;out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_bytes(b)
records=json.loads((S/'before.json').read_bytes());records.append(dict(path=rel,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()));(S/'before.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8')
