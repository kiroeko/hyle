from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('store_recipe', W / 'build.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
b = q.b


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    q.check()
    ready = b.read(W / 'ready.json')
    summary = b.read(W / 'summary.json')
    assert summary['status'] == 'PASS' and len(summary['tests']) == 14
    b.exact(ready['image'])
    before = b.read(q.OLD / 'link-inputs.json')
    after = b.read(W / 'link-inputs.json')
    assert len(before) == len(after) == 231
    a = {b.key(x['path']): x for x in before}
    z = {b.key(x['path']): x for x in after}
    retained = [x for key, x in a.items() if key in z]
    assert len(retained) == 227 and all(x == z[b.key(x['path'])] for x in retained)
    for row in before + after:
        b.exact(row)
    link = b.read(W / 'link/command.json')['command']
    output_args = [x for x in link if x.lower().startswith(('/out:', '/pdb:', '/implib:'))]
    assert len(output_args) == 3
    for arg in output_args:
        assert Path(arg.split(':', 1)[1]).is_relative_to(W / 'bin'), arg
    changes = subprocess.run(['git', 'diff', '--', *q.SOURCES], cwd=R,
        check=True, stdout=subprocess.PIPE).stdout
    (W / 'changes.patch').write_bytes(changes)
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=R,
        check=True, stdout=subprocess.PIPE, text=True).stdout.strip()
    files = {}
    for name in ['build-as-run.py', 'build.py', 'publish.py', 'changes.patch',
                 'authorized-source-hashes.json', 'build-failure.json', 'preparation.json',
                 'plan.json', 'ready.json', 'summary.json', 'selection.json', 'source-freeze.json',
                 'closure.json', 'link-inputs.json', 'runtime.json', 'results.xml']:
        files['records/' + name] = W / name
    files['records/baseline/ready.json'] = q.OLD / 'ready.json'
    files['records/baseline/link-inputs.json'] = q.OLD / 'link-inputs.json'
    for row in b.read(W / 'source-freeze.json'):
        relative = Path(row['path']).relative_to(R)
        path = W / 'source' / relative
        assert path.read_bytes() == Path(row['path']).read_bytes()
        files['source/' + relative.as_posix()] = path
    for unit in ready['compiled']:
        for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log', 'actual-dependencies.json']:
            files['records/compile/' + unit['name'] + '/' + name] = W / 'compile' / unit['name'] / name
    for phase in ['link', 'run']:
        for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log']:
            files['records/' + phase + '/' + name] = W / phase / name
    members = []
    for name, path in sorted(files.items()):
        assert path.suffix.lower() not in ['.exe', '.obj', '.pdb', '.dll', '.lib', '.exp']
        data = path.read_bytes()
        members.append(dict(name=name, bytes=len(data), sha256=sha(data)))
    manifest = json.dumps(members, indent=2).encode() + b'\n'
    destination = R / 'docs/evidence/correctness/inference-pending-store-source-2026-10-27'
    archive = destination.with_suffix('.zip')
    assert not archive.exists() and not destination.with_suffix('.json').exists()
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for name, path in sorted(files.items()):
            out.writestr(name, path.read_bytes())
        out.writestr('archive-member-manifest.json', manifest)
    with zipfile.ZipFile(archive) as verified:
        assert verified.testzip() is None
        for member in members:
            data = verified.read(member['name'])
            assert len(data) == member['bytes'] and sha(data) == member['sha256']
        assert verified.read('archive-member-manifest.json') == manifest
    receipt = dict(
        schema='hyle.finite-correctness-receipt.v1', date='2026-10-27', status='PASS',
        title='Pending external Store destinations and I32 token share one original submission',
        source_base=head, sources=b.read(W / 'source-freeze.json'),
        results=dict(total=14, passed=14, failed=0, skipped=0, process=summary['process'],
            new_actual_CUDA_cases=[
                'GraphOutputSourceCuda.StoreAndTokenShareOnePendingSubmissionAcrossTakeAndPublication',
                'GraphOutputSourceCuda.StorePendingReaderPreservesWholeProducerFailure'],
            neighboring_actual_CUDA_cases=7,
            controlled_Completion_cases=dict(new_pending_read_protocol_regressions=3, adjacent_lease_contracts=2),
            assertions=[
                'One original producer Graph writes noncontiguous slots 0 and 2 and produces an I32 token; one common Source retains the exact original proxy/Queue/whole verdict.',
                'A consumer checked Gather reads only those rows using the exact original bounded ready IDs; token and Store capacity/IDs bind as one atomic final bundle. InputSources reports one source, one device dependency and zero host waits.',
                'A same-shape metadata decoy controlling a different Gather is rejected before binding. Successful ordinary execution verifies the unrelated third Gather still reads its original [0,1] IDs.',
                'A second preallocated Store view captures the same sealed writer generation and is destroyed without obstructing the original view; no mutable view is exported by the range proof.',
                'The first producer gate is released while a separate successor gate still holds its native readers pending. Successful Store destinations can be taken and genuinely published through their exact tickets, and the original producer can reset while that successor remains pending.',
                'Whole-producer checked-index failure is preserved by the consumer after real retirement, blocks all outputs and prevents Store publication. A foreign returned writer is rejected without consumption.',
                'After success, exact state rows and token row match the fixed input oracle; unused slots and every alignment-padding byte retain their sentinel values. Ticket/source release eventually permits ordinary unique writer promotion.'],
            cases=[x['classname'] + '.' + x['name'] for x in summary['tests']]),
        build=dict(CXX_TUs=4, links=1, images=1, test_processes=1, NVCC_TUs=0, SDK_builds=0,
            baseline_ready=b.pin(q.OLD / 'ready.json'), baseline_inputs=b.pin(q.OLD / 'link-inputs.json'),
            before_inputs=231, after_inputs=231, retained_unchanged=227, replaced=4, added=0,
            compiled=ready['compiled'], link=ready['link'], image=ready['image'], ready=b.pin(W / 'ready.json'),
            source_scope='resources.cc, slots_region.cc, resource_leases.cc and the Graph CUDA source test are rebuilt. The prior Compute lease test object is retained.',
            reuse='Existing compiler/toolchain, native shader/CUDA objects and runtime aliases are reused; no SDK, model, payload or dependency download/copy/rebuild.',
            input_sources='The unused attach_existing draft was removed. Original input_source.h/input_sources.cc/input_sources.h are unchanged; their original compiled objects and InputSourceBinding ABI are reused.',
            output_arguments=output_args,
            correction='All four first CXX processes and the first link succeeded. Post-link ready metadata initially read nonexistent baseline runtime2.json instead of runtime.json. The initial as-run script and traceback are retained; metadata-only finalize produced ready.json with the existing objects/image. No CXX/link/test repetition occurred.'),
        boundaries=[
            'The new pending Store bridge is an actual CUDA shared-Queue functional slice, not yet a complete engine state/KV pending bridge or rotating ordinary/MTP overlap pipeline.',
            'The typed Store reader is an original checked axis-zero Gather with whole rows and exact original ready IDs; it is not arbitrary raw bank input permission or a whole-pool ReadLease.',
            'The second-view check exports a second view; it is not a multi-consumer scheduling/performance matrix.',
            'Three pending-ticket and two adjacent lease cases use controlled Completion/in-memory protocol fixtures; they are distinct from the new actual CUDA Store-to-Gather cases.',
            'No model inference, server, performance benchmark, speed/memory-benefit claim, native fault injection or Apple/Vulkan execution was performed.',
            'Per-view binding remains one-shot. Common status and true retirement remain separate; no mathematical failure is converted to a ready lease.'],
        archive=dict(**b.pin(archive), member_count=len(members) + 1,
            member_manifest_sha256=sha(manifest), verification='All member bytes/SHA-256 and ZIP CRC readback passed.',
            contents='Ten exact validated source/header/test snapshots, patch, as-run and corrected recipes, original metadata failure, commands/logs/XML, actual dependencies and before/after object identities. No EXE/OBJ/PDB/DLL/SDK/model payload.'))
    b.save(destination.with_suffix('.json'), receipt)
    b.save(W / 'publication.json', dict(receipt=b.pin(destination.with_suffix('.json')),
                                      archive=b.pin(archive), image=ready['image']))
    print(json.dumps(b.read(W / 'publication.json'), indent=2), flush=True)


if __name__ == '__main__':
    main()
