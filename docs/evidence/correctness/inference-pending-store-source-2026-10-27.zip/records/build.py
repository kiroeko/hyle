from pathlib import Path
import importlib.util
import json
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-captured-submission-20261027'
COMMON = R / '.scratch/inference-batched-slot-controls-20261027/compile2/common'
spec = importlib.util.spec_from_file_location('submission_recipe', OLD / 'build.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
b, m, h = q.b, q.m, q.h

SOURCES = [
    'src/graph/resources.cc',
    'src/graph/slots_region.cc',
    'src/graph/slots_region.h',
    'src/compute/resource_leases.cc',
    'include/hyle/compute/detail/lease_access.h',
    'include/hyle/graph/detail/store_source.h',
    'include/hyle/graph/detail/output_source.h',
    'include/hyle/graph/detail/region_access.h',
    'include/hyle/graph/detail/submission_source.h',
    'tests/graph/output_source_cuda_test.cc',
]


def recipes():
    baseline = b.read(OLD / 'ready.json')
    previous = {x['name']: x for x in baseline['compiled']}
    units = []
    for name, source, template, prior in [
        ('resources', 'src/graph/resources.cc', OLD / 'compile/resources/command.json', previous['resources']['object']),
        ('common', 'src/graph/slots_region.cc', COMMON / 'command.json', b.pin(COMMON / 'unit.obj')),
        ('leases', 'src/compute/resource_leases.cc', OLD / 'compile/leases/command.json', previous['leases']['object']),
        ('graph-test', 'tests/graph/output_source_cuda_test.cc', OLD / 'compile/graph-test/command.json', previous['graph-test']['object']),
    ]:
        argv = b.read(template)['command']
        original = next(a for a in argv if a.lower().endswith('.cc'))
        out = W / 'compile' / name
        command = []
        for i, arg in enumerate(argv):
            if i and argv[i - 1].lower() == '/sourcedependencies':
                arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(out / 'unit.pdb')
            elif arg == original:
                arg = str(R / source)
            command.append(arg)
        units.append(dict(name=name, source=source, template=b.pin(template),
                          baseline_object=prior, command=command))
    return units



def inspect():
    before = b.read(OLD / 'link-inputs.json')
    assert len(before) == 231
    units = recipes()
    for unit in units:
        if unit['baseline_object']:
            assert sum(b.key(x['path']) == b.key(unit['baseline_object']['path']) for x in before) == 1
    b.save(W / 'preparation.json', dict(
        status='RECIPE_ONLY_NOT_FROZEN_NOT_BUILT',
        baseline_ready=b.pin(OLD / 'ready.json'),
        baseline_inputs=b.pin(OLD / 'link-inputs.json'),
        baseline_count=231, replacement_count=4, additional_test_objects=0, expected_inputs=231,
        units=units, counts=dict(CXX_TUs=4, links=1, images=1, test_processes=1, NVCC=0, SDK=0),
        note='Source/selection freeze is a separate later action. No compiler or test process started.'))
    assert b.pin(R / 'src/graph/input_sources.cc')['sha256'] == '7a5f76c60e6c1006b5f122b89a888cf4921c3185b1377c3f1f9278983bebbb19'
    print('PREPARED 4 CXX / 4 REPLACE / 231 INPUTS; INPUT_SOURCES REUSED', flush=True)


def freeze():
    assert not (W / 'source-freeze.json').exists()
    selection = b.read(W / 'selection.json')
    assert selection['tests'] and len(selection['tests']) == len(set(selection['tests']))
    units = recipes()
    for unit in units:
        unit['source'] = b.pin(R / unit['source'])
        recipe = W / 'recipes' / (unit['name'] + '.json')
        b.save(recipe, dict(command=unit['command'], cwd=str(R), timeout_seconds=180))
        unit['actual_recipe'] = b.pin(recipe)
    closure = m.c.closure([u['source']['path'] for u in units],
                          [u['actual_recipe']['path'] for u in units])
    b.save(W / 'closure.json', closure)
    pins = [b.pin(R / source) for source in SOURCES]
    b.save(W / 'source-freeze.json', pins)
    for source in SOURCES:
        target = W / 'source' / source
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((R / source).read_bytes())
    b.save(W / 'plan.json', dict(
        units=units, source_freeze=b.pin(W / 'source-freeze.json'), closure=b.pin(W / 'closure.json'),
        baseline_ready=b.pin(OLD / 'ready.json'), baseline_inputs=b.pin(OLD / 'link-inputs.json'),
        selection=b.pin(W / 'selection.json'),
        counts=dict(CXX_TUs=4, links=1, images=1, test_processes=1, test_cases=len(selection['tests']), NVCC=0, SDK=0),
        scope='Real pending Store-to-projected-Gather plus I32 from one SubmissionSource; nine Graph Source cases and five independent Compute/adjacent lease regressions. No engine/KV overlap or performance claim.'))
    print('FROZEN', flush=True)


def check():
    for row in b.read(W / 'source-freeze.json'):
        b.exact(row)


def environment(plan):
    cl = plan['units'][0]['command'][0]
    return h.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': cl, 'CMAKE_CXX_COMPILER': cl, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env


def build():
    plan = b.read(W / 'plan.json')
    check()
    before = b.read(OLD / 'link-inputs.json')
    assert len(before) == 231
    for row in before:
        b.exact(row)
    own = {b.key(x['path']): x for x in b.read(W / 'closure.json')}
    env = environment(plan)
    compiled = []
    for unit in plan['units']:
        out = W / 'compile' / unit['name']
        assert not out.exists()
        process = h.execute(unit['command'], env, out, timeout=180)
        d = b.read(out / 'dependencies.json')['Data']
        actual = [b.pin(x) for x in dict.fromkeys([d['Source'], *d['Includes']])]
        b.save(out / 'actual-dependencies.json', actual)
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                assert own[b.key(path)]['sha256'] == row['sha256'], str(path)
        check()
        compiled.append(dict(name=unit['name'], source=unit['source'], object=b.pin(out / 'unit.obj'),
                             process=process, dependencies=b.pin(out / 'actual-dependencies.json')))
        b.save(W / 'compiled-partial.json', compiled)
    replacements = {b.key(u['baseline_object']['path']): c['object']
                    for u, c in zip(plan['units'], compiled) if u['baseline_object']}
    additions = [c['object'] for u, c in zip(plan['units'], compiled) if not u['baseline_object']]
    assert len(replacements) == 4 and not additions
    inputs = [replacements.get(b.key(x['path']), x) for x in before] + additions
    assert len(inputs) == 231
    b.save(W / 'link-inputs.json', inputs)
    image = W / 'bin/pending-store-source-test.exe'
    image.parent.mkdir(parents=True, exist_ok=True)
    command = []
    for arg in b.read(OLD / 'link/command.json')['command']:
        if b.key(arg) in replacements:
            arg = replacements[b.key(arg)]['path']
        elif arg.lower().startswith('/out:'):
            arg = '/OUT:' + str(image)
        elif arg.lower().startswith('/pdb:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.lower().startswith('/implib:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    command += [x['path'] for x in additions]
    linked = h.execute(command, env, W / 'link', timeout=120)
    runtime = b.read(OLD / 'runtime.json')
    b.exact(runtime['native_cpu'])
    runtime['adaptation'] = 'Reuse existing native aliases and PATH; no SDK or DLL copy.'
    b.save(W / 'runtime.json', runtime)
    b.save(W / 'ready.json', dict(image=b.pin(image), compiled=compiled, link=linked,
        inputs=b.pin(W / 'link-inputs.json'), runtime=b.pin(W / 'runtime.json'),
        plan=b.pin(W / 'plan.json'), source_freeze=b.pin(W / 'source-freeze.json')))
    print('READY', flush=True)


def finalize():
    # Resume only the metadata step after the successful original four CXX
    # processes and link. The first recipe's wrong runtime filename is retained.
    check()
    compiled = b.read(W / 'compiled-partial.json')
    assert len(compiled) == 4 and all(x['process']['exit'] == 0 for x in compiled)
    for unit in compiled:
        b.exact(unit['object'])
    linked = b.read(W / 'link/process.json')
    assert linked['exit'] == 0 and not (W / 'ready.json').exists()
    image = W / 'bin/pending-store-source-test.exe'
    runtime = b.read(OLD / 'runtime.json')
    b.exact(runtime['native_cpu'])
    runtime['adaptation'] = 'Reuse existing native aliases and PATH; no SDK or DLL copy.'
    b.save(W / 'runtime.json', runtime)
    b.save(W / 'ready.json', dict(image=b.pin(image), compiled=compiled, link=linked,
        inputs=b.pin(W / 'link-inputs.json'), runtime=b.pin(W / 'runtime.json'),
        plan=b.pin(W / 'plan.json'), source_freeze=b.pin(W / 'source-freeze.json'),
        recipe_correction='Post-link metadata only: runtime2.json corrected to existing baseline runtime.json; no CXX/link repeated.'))
    print('READY POST-LINK FINALIZE', flush=True)


def run():
    ready = b.read(W / 'ready.json')
    b.exact(ready['image'])
    check()
    plan = b.read(W / 'plan.json')
    selection = b.read(W / 'selection.json')
    b.exact(plan['selection'])
    env = environment(plan)
    env['PATH'] = b.read(W / 'runtime.json')['PATH']
    xml = W / 'results.xml'
    process = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter=' + ':'.join(selection['tests']), '--gtest_output=xml:' + str(xml)],
        env, W / 'run', timeout=90)
    root = ET.parse(xml).getroot()
    cases = root.findall('./testsuite/testcase')
    expected = set(selection['tests'])
    assert len(cases) == len(expected) and int(root.attrib['tests']) == len(expected)
    assert {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases} == expected
    assert all(x.attrib.get('status') == 'run' and not x.findall('failure') and
               not x.findall('error') and not x.findall('skipped') for x in cases)
    b.save(W / 'summary.json', dict(status='PASS', process=process, tests=[x.attrib for x in cases],
        image=ready['image'], ready=b.pin(W / 'ready.json'), source_freeze=ready['source_freeze'],
        scope=plan['scope']))
    print('PASS', len(cases), flush=True)


if __name__ == '__main__':
    try:
        {'inspect': inspect, 'freeze': freeze, 'build': build, 'finalize': finalize, 'run': run}[sys.argv[1]]()
    except Exception:
        b.save(W / (sys.argv[1] + '-failure.json'), dict(error=traceback.format_exc(),
            note='Original process logs, recipes, source snapshots and XML preserved; no automatic retry.'))
        raise
