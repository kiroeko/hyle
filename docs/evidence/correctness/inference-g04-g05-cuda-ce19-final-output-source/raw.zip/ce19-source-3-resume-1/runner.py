from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05';old=base/'ce19-source-3'
original=json.loads((old/'result.json').read_text());assert original['stage']=='prepare-manifest' and len(original['stages'])==2
assert all(s['exit_code']==0 for s in original['stages'])
source=Path(original['source']);build=Path(original['build']);out=base/'ce19-source-3-resume-1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(out/'original-result.json').write_bytes((old/'result.json').read_bytes())
for row in original['inputs']:
 assert sha(source/row['path'])==row['sha256'],row['path']
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
manifest=out/'preview.ninja';manifest.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(manifest),'-n','hyle_compute_provider_flashinfer_test'],env=env,text=True)
(out/'dry-run.log').write_text(dry)
assert 'Re-running CMake' not in dry
cuda=[line for line in dry.splitlines() if 'Building CUDA object' in line]
assert 0<len(cuda)<=4 and all('compute_provider_flashinfer' in line for line in cuda),cuda
compdb=json.loads(subprocess.check_output(['ninja','-C',str(build),'-t','compdb'],env=env,text=True))
native=[row for row in compdb if row['file'].startswith(str(source/'src/compute_provider_flashinfer')) and row['file'].endswith('.cu')]
assert len(native)==4 and all('--split-compile=3' in row['command'] and 'compute_80' not in row['command'] and 'compute_89' in row['command'] for row in native)
(out/'native-compile-commands.json').write_text(json.dumps(native,indent=2)+'\n')
record=dict(state='SETUP',product_commit='82ddbb4535072461a77234e6e2f9ca6a74138dba',original_guard_exit=1,
 original_result_sha256=sha(old/'result.json'),inputs=original['inputs'],source=str(source),build=str(build),
 original_successful_stages=original['stages'],stages=[],native_cuda_edges=cuda,max_ninja_jobs=2,native_compile_pool=1,nvcc_optimizer_threads=3,
 preview_is_byte_identical_build_manifest=sha(manifest)==sha(build/'build.ninja'),original_manifest_sha256=sha(build/'build.ninja'))
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for name,command in [('build',['cmake','--build',str(build),'--target','hyle_compute_provider_flashinfer_test','--parallel','2','--','-k','0']),
 ('tests',[str(build/'bin/hyle_compute_provider_flashinfer_test'),'--gtest_output=xml:'+str(out/'tests.xml')])]:
 started=time.monotonic()
 with (out/(name+'.log')).open('w') as f:
  proc=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);record.update(state='RUNNING',stage=name,pid=proc.pid);save();print(name,proc.pid,flush=True);code=proc.wait()
 record['stages'].append(dict(stage=name,command=command,exit_code=code,elapsed_seconds=time.monotonic()-started));save()
 if code:record.update(state='TERMINAL_FAIL');save();raise SystemExit(code)
record['manifest_unchanged']=sha(build/'build.ninja')==record['original_manifest_sha256'];assert record['manifest_unchanged']
record['artifacts']={str(p):sha(p) for p in (build/'bin/hyle_compute_provider_flashinfer_test',build/'bin/libhyle_compute_provider_flashinfer.so.0.1.0')}
record.update(state='TERMINAL_PASS');record.pop('pid',None);save();print('TERMINAL_PASS',flush=True)
