from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g04-g05';dest=root/'evidence/correctness/inference-g04-g05-cuda-ce19-final-output-source';dest.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((base/'ce19-source-3-resume-1/result.json').read_text());b=json.loads((base/'ce19-single-partial-test-1/result.json').read_text());assert a['state']==b['state']=='TERMINAL_PASS'
x=ET.parse(base/'ce19-single-partial-test-1/tests.xml').getroot();assert x.attrib['tests']=='17' and x.attrib['failures']==x.attrib['errors']=='0'
assert not any(c.find('skipped') is not None or c.attrib.get('status')=='notrun' for c in x.findall('.//testcase'))
for path,expected in b['artifacts'].items():assert subprocess.check_output(['wsl','-e','sha256sum',path],text=True).split()[0]==expected
assert a['manifest_unchanged'] and a['preview_is_byte_identical_build_manifest']
assert a['artifacts'][next(p for p in a['artifacts'] if p.endswith('.so.0.1.0'))]==b['library_sha256']
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ('ce19-source-3','ce19-source-3-resume-1','ce19-single-partial-test-1'):
  for p in sorted((base/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(base).as_posix())
 for name in ('ce19_cuda_compile.cmake','resume_ce19_source3_wsl.py','ce19_single_partial_test_wsl.py','seal_ce19_source.py'):
  z.write(base/name,'runners/'+name)
 with zipfile.ZipFile(base/'ce19-source-3.zip') as source:z.writestr('source3-manifest.json',source.read('source-manifest.json'))
r=dict(kind='G04_G05_CUDA_CE19_FINAL_OUTPUT_SOURCE_MATH',verdict='PASS_SOURCE_17_NO_SDK_RISK_P1_AGGREGATE',
 product_candidate=a['product_commit'],tests=17,failures=0,skips=0,test_names=[c.attrib['name'] for c in x.findall('.//testcase')],
 source_result=a,test_only_followup=b,guard_rejection=dict(observer_exit=1,stage='dry-run preview',product_build_started=False,
 original_stale_running_state_preserved=True,original_result_sha256=a['original_result_sha256']),
 single_partial_expected_outputs=dict(float16=96.0625,bfloat16=96.5,incorrect_prior_narrowing=96),
 limits=['Actual W1-WSL RTX4070 SM89 only; no SM80 run or Formal/platform-wide certificate.',
 'Final17 tests recompile one CXX test TU only; product library SHA remains source3 actual artifact.',
 'Original source3 preview guard exit1 preserved; same configured tree resumed through byte-identical alternate manifest, no product/Ninja source edits.',
 'SDK/host facets/device sanitizer/newP1 and whole G04-G05 remain pending.'],raw_zip_sha256=sha(dest/'raw.zip'))
(dest/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',newline='\n')
print(json.dumps(dict(path=str(dest),tests=17,product=a['product_commit'])))
