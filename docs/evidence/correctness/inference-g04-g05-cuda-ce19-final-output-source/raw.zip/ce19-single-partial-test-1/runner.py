from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/mnt/c/public/project-hyle/hyle');base=root/'.scratch/inference-gaps/g04-g05'
prior_path=base/'ce19-source-3-resume-1/result.json';prior=json.loads(prior_path.read_text());assert prior['state']=='TERMINAL_PASS'
build=Path(prior['build']);source=Path(prior['source']);out=base/'ce19-single-partial-test-1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
library=build/'bin/libhyle_compute_provider_flashinfer.so.0.1.0';assert sha(library)==prior['artifacts'][str(library)]
name='tests/compute_provider_flashinfer/native_cache_test.cc';(out/'previous-test.cc').write_bytes((source/name).read_bytes())
(source/name).write_bytes((root/name).read_bytes());(out/'current-test.cc').write_bytes((root/name).read_bytes())
preview=out/'preview.ninja';preview.write_bytes((build/'build.ninja').read_bytes())
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n','hyle_compute_provider_flashinfer_test'],env=env,text=True);(out/'dry-run.log').write_text(dry)
assert 'Building CUDA object' not in dry and 'Re-running CMake' not in dry
assert len([line for line in dry.splitlines() if 'Building CXX object' in line])==1
r=dict(state='SETUP',product_commit=prior['product_commit'],source_result_sha256=sha(prior_path),build=str(build),test_source_sha256=sha(root/name),library_sha256=sha(library),stages=[])
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
def save():(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
save()
for stage,command in [('build',['cmake','--build',str(build),'--target','hyle_compute_provider_flashinfer_test','--parallel','2']),('tests',[str(build/'bin/hyle_compute_provider_flashinfer_test'),'--gtest_output=xml:'+str(out/'tests.xml')])]:
 start=time.monotonic()
 with (out/(stage+'.log')).open('w') as f:
  proc=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,pid=proc.pid);save();print(stage,proc.pid,flush=True);code=proc.wait()
 r['stages'].append(dict(stage=stage,command=command,exit_code=code,elapsed_seconds=time.monotonic()-start));save()
 if code:r.update(state='TERMINAL_FAIL');save();raise SystemExit(code)
assert sha(library)==r['library_sha256'];r['artifacts']={str(p):sha(p) for p in (library,build/'bin/hyle_compute_provider_flashinfer_test')}
r.update(state='TERMINAL_PASS');r.pop('pid',None);save();print('TERMINAL_PASS',flush=True)
