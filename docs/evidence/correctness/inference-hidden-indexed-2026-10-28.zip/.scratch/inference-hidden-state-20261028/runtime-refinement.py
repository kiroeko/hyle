"""Original CPU DLL alias and explicit same-image run continuation; no build."""
from pathlib import Path
import importlib.util, json, sys, time, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('hidden_state_frozen_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
R, read, save, pin, exact = b.R, b.read, b.save, b.pin, b.exact

def prepare():
    plan = b.validate(); ready = read(W / 'ready.json')
    old = read(b.OLD / 'runtime.json'); native = old['native_cpu_hardlink']; exact(native)
    assert native['sha256'] == '6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f'
    target = W / 'bin/hyle_ggml_cpu_gdn_scale_v3.dll'; assert not target.exists()
    # A runtime alias only: no byte copy, new native build or overwrite.
    ps = r'''$ErrorActionPreference = 'Stop'
$runtimeSource = '__SOURCE__'
$runtimeTarget = '__TARGET__'
$runtimeDirectory = (Resolve-Path -LiteralPath '__BIN__').Path
if (-not $runtimeTarget.StartsWith($runtimeDirectory + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target outside owned runtime directory' }
$runtimeExpected = '6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f'
if ((Get-FileHash -LiteralPath $runtimeSource -Algorithm SHA256).Hash.ToLowerInvariant() -ne $runtimeExpected) { throw 'Original native CPU identity changed' }
if (Test-Path -LiteralPath $runtimeTarget) { throw 'Preserve existing target; do not overwrite' }
New-Item -ItemType HardLink -Path $runtimeTarget -Target $runtimeSource | Out-Null
if ((Get-FileHash -LiteralPath $runtimeTarget -Algorithm SHA256).Hash.ToLowerInvariant() -ne $runtimeExpected) { throw 'Native alias identity mismatch' }
[ordered]@{status='EXISTING_NATIVE_DLL_HARDLINK_READY';source=$runtimeSource;target=$runtimeTarget;sha256=$runtimeExpected;copied_payload_bytes=0;rebuilt_native_objects=0} | ConvertTo-Json | Set-Content -LiteralPath '__RECEIPT__' -Encoding utf8
'''
    ps = ps.replace('__SOURCE__', native['path']).replace('__TARGET__', str(target)).replace('__BIN__', str(target.parent))
    ps = ps.replace('__RECEIPT__', str(W / 'runtime-alias-receipt.json'))
    script = W / 'create-runtime-alias.ps1'
    with script.open('x', encoding='utf-8') as out: out.write(ps)
    actions = read(plan['runs']['path'])['ordered']
    actions[0]['name'] = 'cpu-r2-attempt2'
    save(W / 'run-plan-attempt2.json', dict(ordered=actions, max_additional_processes=5,
        prior_failed_process=pin(W / 'runs/cpu-r2/process.json'),
        first_failure='STOP; no automatic build, retry or remaining process'))
    save(W / 'runtime-attempt2.json', dict(status='PREPARED_ALIAS_NOT_CREATED_NO_MODEL_RUN',
        PATH=read(plan['runtime']['path'])['PATH'], original_runtime=plan['runtime'],
        original_successful_runtime=pin(b.OLD / 'runtime.json'),
        native_cpu=native, application_directory_alias=str(target), alias_script=pin(script),
        expected_alias_sha256=native['sha256'], source_loader=pin(R / 'src/compute_ggml_runtime/cpu_program.cc'),
        loader='LoadLibraryExA(fixed basename, LOAD_LIBRARY_SEARCH_DEFAULT_DIRS); PATH alone does not establish application-directory discovery.',
        linked_cpu_program_recipe=pin(R / '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/host1/records/compute_ggml_runtime--cpu_program/run/command.json'),
        static_imports=['ADVAPI32.dll', 'MSVCP140.dll', 'KERNEL32.dll', 'VCRUNTIME140.dll', 'VCRUNTIME140_1.dll', 'Windows api-ms-win-crt-*'],
        imported_non_system_payload_dependencies=[],
        changed_model_objects=0, new_binary_copy_bytes=0, compiled_native_objects=0))
    save(W / 'runtime-refinement-plan.json', dict(status='PREPARED_ONLY', script=pin(__file__),
        runtime=pin(W / 'runtime-attempt2.json'), runs=pin(W / 'run-plan-attempt2.json'),
        ready=pin(W / 'ready.json'), image=ready['image'], frozen_plan=pin(W / 'plan.json'),
        initial_failure='PID43284 exit1, ggml CPU AVX2 program module not found before state checks; original raw retained.',
        reason='Original successful executable directory held the native CPU alias. The new application directory did not; no missing source/object or new math failure was established.'))
    print('PREPARED: root executes create-runtime-alias.ps1, then explicit same-EXE run cpu-r2-attempt2; no action executed')

def run(name):
    plan = read(W / 'runtime-refinement-plan.json')
    for field in ('script', 'runtime', 'runs', 'ready', 'frozen_plan'): exact(plan[field])
    original = b.validate(); ready = read(W / 'ready.json'); exact(ready['image'])
    runtime = read(plan['runtime']['path']); exact(runtime['native_cpu'])
    alias = pin(runtime['application_directory_alias'])
    assert alias['sha256'] == runtime['expected_alias_sha256']
    actions = read(plan['runs']['path'])['ordered']; selected = next(a for a in actions if a['name'] == name)
    for previous in actions[:actions.index(selected)]:
        assert read(W / 'runs' / previous['name'] / 'summary.json')['status'] == 'PASS'
    environment = b.t.environment
    def actual_environment():
        env = environment(); env['PATH'] = runtime['PATH']; return env
    b.t.environment = actual_environment
    process = b.t.execute(selected['command'], W / 'runs' / name, selected['timeout_seconds'])
    reports = [json.loads(line) for line in (W / 'runs' / name / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports) == 1; report = reports[0]
    assert report['status'] == 'PASS' and report['final_versions'] == 0
    if 'r2' in name:
        assert report['accepted'] == [[1, 3], [3, 1]] and report['same_width_original_candidates']
        assert report['old_snapshots_unchanged'] and report['controlled_rng_unchanged']
    else:
        assert report['all_initialized_bytes_equal'] and report['old_alias_unchanged'] and report['final_images'] == 0
        assert report['same_shape_catchup_round_equal'] if name.endswith('lag1') else report['same_shape_continuation_equal']
    save(W / 'runs' / name / 'report.json', report)
    save(W / 'runs' / name / 'summary.json', dict(status='PASS', process=process, image=ready['image'],
        runtime=plan['runtime'], alias=alias, report=pin(W / 'runs' / name / 'report.json'), performance_claim=False))

if __name__ == '__main__':
    try:
        if sys.argv[1] == 'prepare': prepare()
        elif sys.argv[1] == 'run': run(sys.argv[2])
        else: raise ValueError(sys.argv[1])
    except BaseException:
        (W / ('failure-runtime-refinement-' + '-'.join(sys.argv[1:3]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
