$ErrorActionPreference = 'Stop'
$runtimeSource = 'C:\public\project-hyle\hyle\.scratch\inference-engine-slot-state-20261027\b2-mtp-state\attempt3\link\hyle_ggml_cpu_gdn_scale_v3.dll'
$runtimeTarget = 'C:\public\project-hyle\hyle\.scratch\inference-hidden-state-20261028\bin\hyle_ggml_cpu_gdn_scale_v3.dll'
$runtimeDirectory = (Resolve-Path -LiteralPath 'C:\public\project-hyle\hyle\.scratch\inference-hidden-state-20261028\bin').Path
if (-not $runtimeTarget.StartsWith($runtimeDirectory + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target outside owned runtime directory' }
$runtimeExpected = '6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f'
if ((Get-FileHash -LiteralPath $runtimeSource -Algorithm SHA256).Hash.ToLowerInvariant() -ne $runtimeExpected) { throw 'Original native CPU identity changed' }
if (Test-Path -LiteralPath $runtimeTarget) { throw 'Preserve existing target; do not overwrite' }
New-Item -ItemType HardLink -Path $runtimeTarget -Target $runtimeSource | Out-Null
if ((Get-FileHash -LiteralPath $runtimeTarget -Algorithm SHA256).Hash.ToLowerInvariant() -ne $runtimeExpected) { throw 'Native alias identity mismatch' }
[ordered]@{status='EXISTING_NATIVE_DLL_HARDLINK_READY';source=$runtimeSource;target=$runtimeTarget;sha256=$runtimeExpected;copied_payload_bytes=0;rebuilt_native_objects=0} | ConvertTo-Json | Set-Content -LiteralPath 'C:\public\project-hyle\hyle\.scratch\inference-hidden-state-20261028\runtime-alias-receipt.json' -Encoding utf8
