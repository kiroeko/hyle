"""One current include-Model state consumer. Explicit actions, no automatic retry."""
from pathlib import Path
import importlib.util, json, re, sys, time, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-indexed-store-20261028'
CURRENT = R / '.scratch/inference-hidden-indexed-refinement-20261028'
OLD = R / '.scratch/inference-engine-slot-state-20261027/b2-mtp-state/attempt3'
spec = importlib.util.spec_from_file_location('indexed_store_primitives', BASE / 'build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
read, save, pin, exact, key = t.read, t.save, t.pin, t.exact, t.key
SOURCE = R / 'tests/tools/qwen_host_image_test.cc'
PINS = {
    'engine/models/qwen35/main.cc': '01c1b57631b0c51eb17deab19582c27b62e0923f0cc1fce7838e5bdeb2295ef8',
    'tests/tools/qwen_mtp_batch_state_case.h': 'daa417a7192f7d03734c7ea2c32c12ea6fa9a7e6fa4eca29de95d4d5b5187232',
}

def metadata_for(row):
    result = t.retained_metadata(row)
    if result: return result
    obj = Path(row['path'])
    deps = obj.with_name(obj.stem + '-deps.json')
    if obj.suffix.lower() != '.obj' or not deps.is_file(): return None
    data = read(deps)['Data']
    return dict(object=row, source=str(t.canonical(data['Source'])), dependencies=pin(deps),
                command=None, includes=[str(t.canonical(p)) for p in data.get('Includes', [])])

def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve the previous preparation'
    ready = read(CURRENT / 'ready.json'); rows = read(ready['inputs']['path'])
    assert len(rows) == 226
    model = ready['compiled']['object']; assert rows.count(model) == 1
    metadata = [m for row in rows if (m := metadata_for(row))]
    entry = [m for m in metadata if key(m['source']) == key(R / 'engine/main.cc')]
    assert len(entry) == 1, 'Need the real CLI entry Data.Source'
    removed = [model, entry[0]['object']]
    retained = [row for row in rows if row not in removed]; assert len(retained) == 224
    native = read(BASE / 'ready-cli.json')['compiled']
    for unit in native.values(): assert retained.count(unit['object']) == 1
    old = read(OLD / 'ready.json'); old_rows = read(old['inputs']['path'])
    old_index = [m for row in old_rows if (m := metadata_for(row))]
    current_sources = {key(m['source']) for m in metadata}
    extra = [m for m in old_index if m['object'] != old['object'] and key(m['source']) not in current_sources]
    assert not extra, ('Old consumer has extra helper TU', extra)
    template = read(OLD / 'compile/command.json')['command']; command = []
    for i, arg in enumerate(template):
        if i and template[i-1].lower() == '/sourcedependencies': arg = str(W / 'compile/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/unit.pdb')
        elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = str(SOURCE)
        command.append(arg)
    defines = [a for a in command if a.startswith(('/D', '/U'))]
    assert all('/D' + x + '=1' in defines for x in
               ('HYLE_COMPUTE_CPU', 'HYLE_COMPUTE_GGML_CPU', 'HYLE_COMPUTE_ONEDNN',
                'HYLE_GRAPH_ONEDNN', 'HYLE_COMPUTE_CUDA', 'HYLE_COMPUTE_GGML_CUDA'))
    assert '/MD' in command and '/std:c++latest' in command
    includes = [Path(a[2:]) for a in command if a.startswith('/I')]
    assert not any(p.is_relative_to(R / '.scratch') for p in includes), 'No stale project snapshot include'
    seeds = [SOURCE]
    for receipt in (old['actual_dependencies'], ready['compiled']['actual_dependencies']):
        for dep in read(receipt['path']):
            p = t.canonical(dep['path'])
            if t.project(p): seeds.append(p)
    # Reuse external SDK/compiler identities. Freeze only actual project inputs
    # plus their local quote-include closure; do not snapshot the SDK/tree.
    queue = list(dict.fromkeys(seeds)); frozen = {}
    while queue:
        p = queue.pop()
        if key(p) in frozen: continue
        frozen[key(p)] = pin(p)
        for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"', p.read_text(encoding='utf-8-sig'), re.M):
            candidates = [p.parent / name, *(base / name for base in includes)]
            found = next((q.resolve() for q in candidates if q.is_file()), None)
            if found and t.project(found) and key(found) not in frozen: queue.append(found)
    for relative, digest in PINS.items(): assert frozen[key(R / relative)]['sha256'] == digest, relative
    snapshots = []
    for relative in ('engine/models/qwen35/main.cc', 'tests/tools/qwen_host_image_test.cc',
                     'tests/tools/qwen_host_image_case.h', 'tests/tools/qwen_state_reuse_case.h',
                     'tests/tools/qwen_mtp_batch_state_case.h'):
        p = R / relative; target = W / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(p.read_bytes())
        snapshots.append(dict(original=frozen[key(p)], snapshot=pin(target)))
    save(W / 'source-freeze.json', list(frozen.values()))
    save(W / 'retained-inputs.json', retained)
    save(W / 'source-index.json', dict(current=metadata, old_consumer=old_index,
        removed=removed, extra_helper_TUs=extra, current_native=native))
    fixtures = {}
    for name, path in [('r2', R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'),
                       ('host', R / '.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture')]:
        fixtures[name] = dict(directory=str(path), manifest=pin(path / 'weights.tsv'))
    actions = [('cpu-r2', '--cpu', 'r2', '--mtp-batch-state'), ('cuda-r2', '--cuda', 'r2', '--mtp-batch-state'),
               ('cpu-lag1', '--cpu', 'host', '--mtp-lag1'), ('cuda-lag1', '--cuda', 'host', '--mtp-lag1'),
               ('cpu-hostrestore', '--cpu', 'host', '')]
    image = str(W / 'bin/qwen-hidden-state.exe')
    runs = [dict(name=n, command=[image, backend, fixtures[fixture]['directory'], *([flag] if flag else [])],
                 timeout_seconds=90) for n, backend, fixture, flag in actions]
    save(W / 'compile-command.json', dict(command=command, cwd=str(R), timeout_seconds=240))
    save(W / 'run-plan.json', dict(ordered=runs, max_processes=5, first_failure='STOP_WITH_ORIGINAL_OUTPUTS'))
    save(W / 'plan.json', dict(status='FROZEN_PREPARED_NOT_BUILT', source=pin(SOURCE), snapshots=snapshots,
        script=pin(__file__), baseline=pin(CURRENT / 'ready.json'), current_inputs=ready['inputs'],
        removed=removed, retained=pin(W / 'retained-inputs.json'), source_index=pin(W / 'source-index.json'),
        original_compile=pin(OLD / 'compile/command.json'), original_link=ready['recipe'],
        recipe=pin(W / 'compile-command.json'), project_dependencies=pin(W / 'source-freeze.json'),
        environment=pin(BASE / 'environment.json'), runtime=ready['runtime'], defines=defines,
        fixtures=fixtures, runs=pin(W / 'run-plan.json'),
        counts=dict(CXX=1, links=1, current_inputs=226, removed_inputs=2, retained_inputs=224,
                    final_inputs=225, extra_helpers=0, SDK=0, NVCC=0, downloads=0, max_run_processes=5),
        compile_source_policy='Canonical frozen project source; validate every project dependency before and after CXX; snapshots are immutable byte evidence.',
        scope='Original R2 accepted-prefix bytes/old snapshots/RNG, lag1 catch-up and CPU host restore. No quality, cross-backend bit equality or performance claim.'))
    print('PREPARED/FROZEN: one CXX, one 225-input link, at most five original consumer processes; nothing executed')

def validate():
    p = read(W / 'plan.json')
    for field in ('source', 'script', 'baseline', 'current_inputs', 'retained', 'source_index', 'recipe',
                  'original_compile', 'original_link', 'project_dependencies', 'environment', 'runtime', 'runs'):
        exact(p[field])
    for row in read(p['project_dependencies']['path']): exact(row)
    for fixture in p['fixtures'].values(): exact(fixture['manifest'])
    return p

def compile_probe():
    p = validate(); (W / 'compile').mkdir(exist_ok=False)
    process = t.execute(read(p['recipe']['path'])['command'], W / 'logs/compile', 240)
    data = read(W / 'compile/dependencies.json')['Data']; assert key(data['Source']) == key(SOURCE)
    allowed = {key(row['path']): row for row in read(p['project_dependencies']['path'])}; actual = []
    for path in dict.fromkeys([data['Source'], *data['Includes']]):
        if t.project(path): exact(allowed[key(path)])
        actual.append(pin(path))
    validate(); save(W / 'compile/actual-dependencies.json', actual)
    save(W / 'compile/compiled.json', dict(source=p['source'], object=pin(W / 'compile/unit.obj'),
        process=process, command=pin(W / 'logs/compile/command.json'),
        dependencies=pin(W / 'compile/dependencies.json'), actual_dependencies=pin(W / 'compile/actual-dependencies.json')))

def link():
    p = validate(); compiled = read(W / 'compile/compiled.json'); exact(compiled['object'])
    rows = read(p['retained']['path']) + [compiled['object']]; assert len(rows) == 225
    for row in rows: exact(row)
    image = W / 'bin/qwen-hidden-state.exe'; image.parent.mkdir(exist_ok=True); assert not image.exists()
    args = []; removed = {key(row['path']) for row in p['removed']}; found = []
    for arg in read(p['original_link']['path'])['command']:
        if key(arg) in removed: found.append(key(arg)); continue
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str(image.with_suffix(suffix)); break
        args.append(arg)
    assert set(found) == removed and len(found) == 2
    args.append(compiled['object']['path']); save(W / 'link-inputs.json', rows)
    process = t.execute(args, W / 'link', 180)
    save(W / 'ready.json', dict(status='LINKED_NOT_RUN', image=pin(image), compiled=compiled,
        inputs=pin(W / 'link-inputs.json'), recipe=pin(W / 'link/command.json'), runtime=p['runtime'],
        plan=pin(W / 'plan.json'), process=process, performance_claim=False))

def run(name):
    p = validate(); ready = read(W / 'ready.json'); exact(ready['image'])
    actions = read(p['runs']['path'])['ordered']; selected = next(a for a in actions if a['name'] == name)
    index = actions.index(selected)
    for prior in actions[:index]: assert read(W / 'runs' / prior['name'] / 'summary.json')['status'] == 'PASS'
    process = t.execute(selected['command'], W / 'runs' / name, selected['timeout_seconds'])
    lines = (W / 'runs' / name / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
    reports = [json.loads(line) for line in lines if line.startswith('{')]
    assert len(reports) == 1; report = reports[0]
    assert report['status'] == 'PASS' and report['final_versions'] == 0
    if name.endswith('r2'):
        assert report['accepted'] == [[1, 3], [3, 1]] and report['same_width_original_candidates']
        assert report['old_snapshots_unchanged'] and report['controlled_rng_unchanged']
    else:
        assert report['all_initialized_bytes_equal'] and report['old_alias_unchanged'] and report['final_images'] == 0
        assert report['same_shape_catchup_round_equal'] if name.endswith('lag1') else report['same_shape_continuation_equal']
    save(W / 'runs' / name / 'report.json', report)
    save(W / 'runs' / name / 'summary.json', dict(status='PASS', process=process, image=ready['image'],
         report=pin(W / 'runs' / name / 'report.json'), performance_claim=False))

if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'compile': compile_probe()
        elif action == 'link': link()
        elif action == 'run': run(sys.argv[2])
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(exist_ok=True, parents=True)
        (W / ('failure-' + '-'.join(sys.argv[1:3]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
