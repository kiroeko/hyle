"""Explicit finite checks, no performance window, downloads or automatic retry."""
from pathlib import Path
import importlib.util, json, shutil, sys, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value
b = load('final_recovery_build', W/'check.py')
facts = load('existing_complete_facts', R/'.scratch/inference-current-review-profile-20261027/analyze.py')
prior = R/'.scratch/inference-continuous-wave-20261027'
window = R/'.scratch/inference-continuous-wave-window-20261027/attempt2'

def changed(a, z, path=''):
    if type(a) is not type(z): return [dict(path=path,old=a,new=z)]
    if isinstance(a, dict):
        return [d for key in sorted(set(a)|set(z)) for d in (
            changed(a[key],z[key],path+'/'+key) if key in a and key in z else
            [dict(path=path+'/'+key,old=a.get(key),new=z.get(key))])]
    if isinstance(a, list):
        if len(a)!=len(z):return [dict(path=path+'/length',old=len(a),new=len(z))]
        return [d for j,(x,y) in enumerate(zip(a,z)) for d in changed(x,y,path+'/'+str(j))]
    return [] if a==z else [dict(path=path,old=a,new=z)]

def run(name):
    unit = 'host' if name=='host' else 'probe' if name=='controls' else 'model'
    ready=b.read(W/('ready-'+unit+'.json')); b.exact(ready['image'])
    out=W/'runs'/name; assert not out.exists(),'Preserve every actual attempt'
    reference=None
    if name=='host': command=[ready['image']['path']]
    elif name=='controls':
        original=prior/'inputs/context32'; target=W/'inputs/controls'
        assert not target.exists(); target.mkdir(parents=True)
        for filename in ('weights.tsv','prompt.ids'):
            shutil.copyfile(original/filename,target/filename)
        b.save(target/'source.json',{f:b.pin(original/f) for f in ('weights.tsv','prompt.ids')})
        command=[ready['image']['path'],'--cuda-continuous',str(target)]
    elif name.startswith('cli-'):
        reference=prior/'runs'/name/'stdout.log'
        command=[ready['image']['path'],*b.read(prior/'runs'/name/'command.json')['command'][1:]]
    else:
        assert name in ('two-turn-off','two-turn-default','two-turn-budget')
        old=window/'two-turn-timing'/('02-hyle_auto' if name=='two-turn-default' else '01-hyle_plain')
        reference=old/'stdout.log'
        command=[ready['image']['path'],*b.read(old/'command.json')['command'][1:]]
        if name!='two-turn-off':
            at=command.index('--decode-overlap');del command[at:at+2]
        if name=='two-turn-budget':
            command+=['--cache-bytes',str(b.read(reference)['cache_shared_backing_bytes'])]
    b.save(W/'recipes'/('run-'+name+'.json'),dict(command=command,ready=b.pin(W/('ready-'+unit+'.json'))))
    process=b.b.h.execute(command,b.environment(),out,timeout=180)
    if name=='host':
        assert '16 host contract groups passed' in (out/'stdout.log').read_text()
        summary=dict(status='PASS',process=process,host_groups=16)
    else:
        report=b.read(out/'stdout.log'); b.save(out/'report.json',report)
        if name=='controls':
            assert report['status']=='PASS' and report['control_and_candidate_arms']==16
            summary=dict(status='PASS',process=process,report=b.pin(out/'report.json'))
        else:
            differences=changed(facts.non_time(b.read(reference)),facts.non_time(report))
            b.save(out/'non-time-differences.json',differences)
            allowed={'/decode_overlap_available','/overlap_successor_submissions','/overlap_successor_publications','/overlap_successor_refusals'} if name=='two-turn-default' else set()
            assert all(d['path'] in allowed for d in differences),differences[:8]
            assert report['live_committed_versions']==0
            if name=='two-turn-default':
                assert report['decode_overlap'] and report['decode_overlap_available']
                assert report['overlap_successor_publications']>90
                assert report['overlap_successor_submissions']==report['overlap_successor_publications']
                assert report['overlap_successor_refusals']==1 and not report['overlap_successor_discards']
            elif name.startswith('two-turn'):
                assert not report['decode_overlap'] and not report['overlap_successor_submissions']
            summary=dict(status='PASS',process=process,report=b.pin(out/'report.json'),
                original=b.pin(reference),complete_non_time_differences=differences,
                scope='Finite functional comparison; no throughput or new memory-peak claim')
    b.save(out/'summary.json',summary);print('PASS '+name,flush=True)

if __name__=='__main__':
    try: run(sys.argv[1])
    except BaseException:
        (W/('failure-run-'+sys.argv[1]+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
