"""One Model TU and current226-input closure; explicit finite actions only."""
from pathlib import Path
import difflib, importlib.util, json, sys, time, traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
BASE=R/'.scratch/inference-indexed-store-20261028'
UI=R/'.scratch/inference-stable-attention-20261027/followup-user-cli'
spec=importlib.util.spec_from_file_location('indexed_store_build_primitives',BASE/'build.py')
t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
read,save,pin,exact,key=t.read,t.save,t.pin,t.exact,t.key
ARMS={
 'ordinary-two-turn': BASE/'models/ordinary-two-turn',
 'mtp-single': BASE/'models/mtp-single',
 'mtp-two-turn':R/'.scratch/inference-stable-attention-window-20261027/attempt1/two-turn-timing/03-hyle_mtp',
}

def prepare():
    assert not (W/'plan.json').exists(),'Preserve first preparation'
    base=read(BASE/'ready-cli.json');old=read(UI/'ready-cli.json')['compiled']
    rows=read(base['inputs']['path']);assert len(rows)==226 and rows.count(old['object'])==1
    current=R/'engine/models/qwen35/main.cc'
    snapshot=W/'source/engine/models/qwen35/main.cc';snapshot.parent.mkdir(parents=True,exist_ok=True)
    before=pin(current)
    with snapshot.open('xb') as f:f.write(current.read_bytes())
    assert pin(snapshot)['sha256']==before['sha256'];exact(before)
    headers=[]
    for row in read(UI/'source-freeze.json'):
        if key(row['original']['path'])==key(current):continue
        exact(row['original']);exact(row['snapshot']);headers.append(row)
    save(W/'reused-headers.json',headers)
    expected=[row for row in read(old['actual_dependencies']['path']) if key(row['path'])!=key(old['snapshot']['path'])]
    for row in expected:exact(row)
    expected.append(pin(snapshot));save(W/'expected-dependencies.json',expected)
    command=[];template=read(UI/'logs/model/command.json')['command'];out=W/'compile'
    for i,arg in enumerate(template):
        if i and template[i-1].lower()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.lower().endswith(('.cc','.cpp','.cxx')):arg=str(snapshot)
        command.append(arg)
    original=Path(old['snapshot']['path']).read_text(encoding='utf-8-sig')
    (W/'candidate.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),current.read_text(encoding='utf-8-sig').splitlines(True),fromfile='main4b6c914',tofile='indexed-hidden')),encoding='utf-8')
    save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',source=before,snapshot=pin(snapshot),script=pin(__file__),
        base=pin(BASE/'ready-cli.json'),old_model=old,inputs=base['inputs'],recipe=base['recipe'],runtime=base['runtime'],
        headers=pin(W/'reused-headers.json'),expected=pin(W/'expected-dependencies.json'),command=command,
        counts=dict(CXX=1,links=1,NVCC=0,SDK=0,downloads=0),
        scope='Original hidden_pool fixed indexed Gather/Store, original acceptance/rollback. No automatic retry or throughput claim.'))
    print('FROZEN one Model, original header snapshots and226-input closure; not built/run')

def validate():
    plan=read(W/'plan.json')
    for name in ('source','snapshot','script','base','inputs','recipe','headers','expected'):exact(plan[name])
    for row in read(plan['headers']['path']):exact(row['original']);exact(row['snapshot'])
    return plan

def compile_model():
    plan=validate();out=W/'compile';out.mkdir(parents=True,exist_ok=False)
    process=t.execute(plan['command'],W/'logs/model',240)
    data=read(out/'dependencies.json')['Data'];assert key(data['Source'])==key(plan['snapshot']['path'])
    expected={key(row['path']):row for row in read(plan['expected']['path'])};actual=[]
    for path in dict.fromkeys([data['Source'],*data['Includes']]):
        row=pin(path);assert row==expected[key(path)],('Unexpected/changed dependency',path);actual.append(row)
    validate();save(out/'actual-dependencies.json',actual)
    save(out/'compiled.json',dict(source=plan['source'],snapshot=plan['snapshot'],object=pin(out/'unit.obj'),process=process,
        command=pin(W/'logs/model/command.json'),dependencies=pin(out/'dependencies.json'),actual_dependencies=pin(out/'actual-dependencies.json')))
    print('PASS Model CXX')

def link():
    plan=validate();compiled=read(W/'compile/compiled.json');exact(compiled['object'])
    rows=read(plan['inputs']['path']);assert len(rows)==226 and rows.count(plan['old_model']['object'])==1
    rows=[compiled['object'] if row==plan['old_model']['object'] else row for row in rows]
    for row in rows:exact(row)
    image=W/'bin/hyle-hidden-indexed.exe';image.parent.mkdir(parents=True,exist_ok=True);assert not image.exists()
    args=[];replaced=0
    for arg in read(plan['recipe']['path'])['command']:
        if key(arg)==key(plan['old_model']['object']['path']):arg=compiled['object']['path'];replaced+=1
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(prefix):arg=prefix+str(image.with_suffix(suffix));break
        args.append(arg)
    assert replaced==1;save(W/'link-inputs.json',rows)
    process=t.execute(args,W/'link',180)
    save(W/'ready.json',dict(status='LINKED_NOT_RUN',image=pin(image),compiled=compiled,inputs=pin(W/'link-inputs.json'),
        recipe=pin(W/'link/command.json'),runtime=plan['runtime'],plan=pin(W/'plan.json'),process=process,performance_claim=False))
    print('PASS226-input link, changed Model only')

def parse(name):
    assert name in ARMS;ready=read(W/'ready.json');out=W/'runs'/name
    process=read(out/'process.json');assert process['exit']==0 and not process['timed_out']
    spec=importlib.util.spec_from_file_location('hidden_original_non_time',R/'.scratch/inference-wave-recovery-final-20261027/run.py')
    f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
    actual,expected=read(out/'stdout.log'),read(ARMS[name]/'stdout.log')
    differences=f.changed(f.facts.non_time(expected),f.facts.non_time(actual))
    save(out/('complete-non-time-differences-'+str(time.time_ns())+'.json'),differences)
    # Structural resource differences must be inspected explicitly, never masked
    # together with IDs, accepted prefixes, state, ledger, rounds or RNG.
    assert not differences,differences[:12]
    assert actual['live_committed_versions']==0
    save(out/('summary-'+str(time.time_ns())+'.json'),dict(status='FINITE_FACTS_PASS',process=process,image=ready['image'],
        oracle=pin(ARMS[name]/'stdout.log'),complete_non_time_differences=differences,performance_claim=False))
    print('PASS finite',name,'facts, not a performance window')

def run(name):
    validate();assert name in ARMS;ready=read(W/'ready.json');exact(ready['image'])
    args=[ready['image']['path'],*read(ARMS[name]/'command.json')['command'][1:]]
    out=W/'runs'/name;assert not out.exists(),'Do not rerun a real process'
    t.execute(args,out,180);parse(name)

if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='compile':compile_model()
        elif action=='link':link()
        elif action=='run':run(sys.argv[2])
        elif action=='parse':parse(sys.argv[2])
        else:raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+'-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
