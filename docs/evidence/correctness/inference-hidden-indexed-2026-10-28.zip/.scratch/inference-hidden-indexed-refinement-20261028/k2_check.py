"""Same-interface current control/candidate K2 functional comparison only."""
from pathlib import Path
import importlib.util,sys,time
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('hidden_indexed_model_driver',W/'model.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old=W.parents[1]/'.scratch/mtp-k2-aux-capture-pilot-20261026/behavior/control'

def run(name):
    assert name in ('control','candidate');m.validate()
    ready=m.read(m.BASE/'ready-cli.json') if name=='control' else m.read(W/'ready.json')
    m.exact(ready['image'])
    args=[ready['image']['path'],*m.read(old/'command.json')['command'][1:]]
    assert '--mtp-max-drafts' in args and args[args.index('--mtp-max-drafts')+1]=='2'
    out=W/'k2'/name;assert not out.exists(),'Preserve every real process'
    m.t.execute(args,out,180)
    if name=='candidate':parse()

def parse():
    out=W/'k2';before=m.read(out/'control/stdout.log');after=m.read(out/'candidate/stdout.log')
    for name in ('control','candidate'):assert m.read(out/name/'process.json')['exit']==0
    spec=importlib.util.spec_from_file_location('original_model_facts',m.R/'.scratch/inference-wave-recovery-final-20261027/run.py')
    f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
    diff=f.changed(f.facts.non_time(before),f.facts.non_time(after))
    m.save(out/('differences-'+str(time.time_ns())+'.json'),diff)
    assert not diff,diff[:12]
    assert after['live_committed_versions']==0
    m.save(out/'summary.json',dict(status='CURRENT_CONTROL_AND_CANDIDATE_K2_FINITE_PASS',differences=diff,
        control=m.pin(out/'control/stdout.log'),candidate=m.pin(out/'candidate/stdout.log'),performance_claim=False))
    print('PASS current K2 full non-time facts')
if __name__=='__main__':
    if sys.argv[1]=='parse':parse()
    else:run(sys.argv[1])
