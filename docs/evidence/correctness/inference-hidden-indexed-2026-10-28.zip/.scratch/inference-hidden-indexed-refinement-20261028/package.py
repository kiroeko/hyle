"""Offline correctness package only. Does not compile/link/run any consumer.

Root calls this after the five finite state checks. Original failures, source
versions and complete reports remain intact. Missing checks never become PASS.
"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import re
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
FIRST = R / '.scratch/inference-hidden-indexed-20261028'
STATE = R / '.scratch/inference-hidden-state-20261028'
NATIVE = R / '.scratch/inference-indexed-store-20261028'
OLD_TWO = R / '.scratch/inference-stable-attention-window-20261027/attempt1/two-turn-timing/03-hyle_mtp'
DEST = R / 'docs/evidence/correctness/inference-hidden-indexed-2026-10-28'
CLI = ('mtp-single', 'ordinary-two-turn', 'mtp-two-turn')
TINY = ('cpu-r2-attempt2', 'cuda-r2', 'cpu-lag1', 'cuda-lag1', 'cpu-hostrestore')
SUFFIXES = {'.json', '.log', '.py', '.ps1', '.diff', '.cc', '.cpp', '.h', '.hpp', '.cu', '.cuh', '.txt', '.tsv', '.ids', '.d'}
OMIT = {'source-index.json', 'package-manifest.json', 'package-result.json'}


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1 << 20):
            digest.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    assert pin(row['path']) == row, ('Changed frozen receipt', row['path'])


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def one_json_stdout(folder):
    lines = Path(folder, 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
    values = [json.loads(line) for line in lines if line.startswith('{')]
    assert len(values) == 1, ('Expected one original producer report', str(folder))
    return values[0]


def terminal(folder, successful):
    value = read(Path(folder) / 'process.json')
    assert not value.get('timed_out', False), str(folder)
    assert (value['exit'] == 0) == successful, str(folder)
    return value


def counters(folder):
    text = Path(folder, 'stderr.log').read_text(encoding='utf-8-sig')
    return dict(recorded=sum(map(int, re.findall(r'\bcapture_recorded=(\d+)', text))),
                reused=sum(map(int, re.findall(r'\bcapture_reused=(\d+)', text))),
                stderr=pin(Path(folder) / 'stderr.log'))


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Preserve any existing evidence'
    builds = {name: read(folder / 'ready.json') for name, folder in (('initial', FIRST), ('refined', W), ('state_probe', STATE))}
    assert builds['initial']['compiled']['snapshot']['sha256'] == '989e1fe66978522185d2917fdf15d9c5cf6898fdebd069630a784f53a83a2441'
    assert builds['refined']['compiled']['snapshot']['sha256'] == '01c1b57631b0c51eb17deab19582c27b62e0923f0cc1fce7838e5bdeb2295ef8'
    assert builds['refined']['image']['sha256'] == 'b59fe8525dcb3fee546748879ebc06690c493fdf2c73cf161c59b75a68a3b259'
    assert builds['state_probe']['image']['sha256'] == '6572a02ae2cab25a350fb09075671e58b5836be614f471dc7deb2f9b214724d3'
    assert len(read(builds['refined']['inputs']['path'])) == 226
    assert len(read(builds['state_probe']['inputs']['path'])) == 225
    control_model = read(W / 'plan.json')['old_model']
    historical_ready = read(OLD_TWO.parent.parent / 'ready.json')
    for build in builds.values():
        assert build['compiled']['process']['exit'] == build['process']['exit'] == 0
        for key in ('inputs', 'recipe', 'runtime', 'plan'):
            exact(build[key])
        exact(build['compiled']['actual_dependencies'])

    # Full pre-existing complete-report comparisons, no additional ignored keys.
    clis = []
    for name in CLI:
        folder = W / 'runs' / name
        process = terminal(folder, True)
        summaries = sorted(folder.glob('summary-*.json'))
        assert len(summaries) == 1
        summary = read(summaries[0])
        assert summary['status'] == 'FINITE_FACTS_PASS' and summary['complete_non_time_differences'] == []
        assert summary['process'] == process and summary['image'] == builds['refined']['image']
        exact(summary['oracle'])
        differences = sorted(folder.glob('complete-non-time-differences-*.json'))
        assert len(differences) == 1 and read(differences[0]) == []
        report = one_json_stdout(folder)
        assert report['live_committed_versions'] == 0
        clis.append(dict(name=name, process=process, original_report=pin(folder / 'stdout.log'),
            full_non_time_oracle=summary['oracle'], differences=pin(differences[0]),
            generated_tokens=report['generated_tokens'], actual_graph_calls=report['actual_graph_calls'],
            actual_target_rows=report['actual_target_rows'], final_versions=0))
    k2_summary = read(W / 'k2/summary.json')
    assert k2_summary['status'] == 'CURRENT_CONTROL_AND_CANDIDATE_K2_FINITE_PASS' and k2_summary['differences'] == []
    k2 = []
    for name in ('control', 'candidate'):
        folder = W / 'k2' / name
        process = terminal(folder, True)
        report = one_json_stdout(folder)
        assert report['live_committed_versions'] == 0
        command = read(folder / 'command.json')['command']
        assert command[command.index('--mtp-max-drafts') + 1] == '2'
        exact(k2_summary[name])
        k2.append(dict(name=name, process=process, command=pin(folder / 'command.json'),
            original_report=k2_summary[name], generated_tokens=report['generated_tokens'], final_versions=0))

    # These are within-backend original-candidate/restore byte checks. They
    # never compare CPU floats bit-for-bit against CUDA floats.
    tiny = []
    for name in TINY:
        folder = STATE / 'runs' / name
        assert (folder / 'summary.json').exists(), ('Finite state check remains incomplete', name)
        process = terminal(folder, True)
        summary, report = read(folder / 'summary.json'), read(folder / 'report.json')
        assert summary['status'] == report['status'] == 'PASS'
        assert summary['process'] == process and summary['image'] == builds['state_probe']['image']
        exact(summary['report'])
        assert report == one_json_stdout(folder) and report['final_versions'] == 0
        if 'r2' in name:
            assert report['accepted'] == [[1, 3], [3, 1]]
            assert report['same_width_original_candidates'] and report['old_snapshots_unchanged'] and report['controlled_rng_unchanged']
            assert report['checked_selected_bytes'] > 0 and report['reclaimed_unselected_slots'] > 0
        else:
            assert report['all_initialized_bytes_equal'] and report['old_alias_unchanged'] and report['final_images'] == 0
            assert report['same_shape_catchup_round_equal'] if name.endswith('lag1') else report['same_shape_continuation_equal']
        tiny.append(dict(name=name, process=process, original_report=summary['report'], facts=report))
    first_process = terminal(FIRST / 'runs/mtp-single', False)
    first_text = (FIRST / 'runs/mtp-single/stderr.log').read_text(encoding='utf-8-sig')
    assert first_process['pid'] == 53256 and 'conflicting resource access requires a data/control dependency' in first_text
    assert 'compile full text' not in first_text
    dll_process = terminal(STATE / 'runs/cpu-r2', False)
    assert dll_process['pid'] == 43284
    dll_text = (STATE / 'runs/cpu-r2/stderr.log').read_text(encoding='utf-8-sig')
    assert 'ggml CPU AVX2 program:' in dll_text
    alias = read(STATE / 'runtime-alias-receipt.json')
    assert alias['status'] == 'EXISTING_NATIVE_DLL_HARDLINK_READY' and alias['copied_payload_bytes'] == 0
    assert alias['sha256'] == '6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f'

    old_single = NATIVE / 'models/mtp-single'
    capture_rows = [dict(scenario='single', old_image=read(old_single / 'command.json')['command'][0],
                        old=counters(old_single), current=counters(W / 'runs/mtp-single'),
                        baseline='Indexed-Store backend with old Model4b6c before hidden wiring, from the same prerequisite correctness batch.'),
                    dict(scenario='two-turn', old_image=read(OLD_TWO / 'command.json')['command'][0],
                        old=counters(OLD_TWO), current=counters(W / 'runs/mtp-two-turn'),
                        baseline='Older stable-attention d9 image and Model441ff, before later budget/native-Store/Model wiring. Historical structural comparison only.')]
    assert [row['old']['recorded'] for row in capture_rows] == [11, 15]
    assert [row['current']['recorded'] for row in capture_rows] == [2, 2]

    files = {}
    def add(path, expected=None):
        path = Path(path).resolve()
        assert path.is_relative_to(R), ('Never archive SDK/out-of-repository payload', str(path))
        if path.name in OMIT or path.suffix.lower() not in SUFFIXES:
            return
        assert path.stat().st_size < 2_000_000, ('Unexpected large metadata/source', str(path))
        value = pin(path)
        if expected is not None:
            assert value == expected, ('Frozen source/receipt drift', str(path))
        files[str(path)] = value
    # Only these finite workspaces; never follow binaries, SDKs or the 11MB
    # helper source-index. Compile/link exact dependency manifests remain.
    for folder in (FIRST, W, STATE):
        for path in sorted(folder.rglob('*')):
            if path.is_file() and path.name not in OMIT:
                add(path)
    for model in ('initial', 'refined'):
        snap = builds[model]['compiled']['snapshot']; add(snap['path'], snap)
    add(control_model['snapshot']['path'], control_model['snapshot'])
    add(control_model['actual_dependencies']['path'], control_model['actual_dependencies'])
    add(OLD_TWO.parent.parent / 'ready.json')
    add(historical_ready['canonical_main']['path'], historical_ready['canonical_main'])
    for path in (W / 'reused-headers.json', FIRST / 'reused-headers.json'):
        for row in read(path):
            add(row['snapshot']['path'], row['snapshot'])
    # Tiny's actual canonical includes and its frozen moved probe/main bytes.
    state_plan = read(STATE / 'plan.json')
    snapshots = {str(Path(row['original']['path']).resolve()): row['snapshot'] for row in state_plan['snapshots']}
    for row in read(STATE / 'source-freeze.json'):
        selected = snapshots.get(str(Path(row['path']).resolve()), row)
        add(selected['path'], selected)
    native = read(NATIVE / 'ready-cli.json')
    for row in native['compiled'].values():
        add(row['source']['path'], row['source'])
        for key in ('actual_dependencies', 'dependencies', 'command'):
            if key in row: add(row[key]['path'], row[key])
    for row in read(NATIVE / 'source-freeze.json'):
        original = row['original']['path'].replace('\\', '/').lower()
        if any(name in original for name in ('indexed_copy', 'slots_region.h', 'cuda_internal.h', 'native_context.h', 'device_status')):
            add(row['snapshot']['path'], row['snapshot'])
    prerequisite = R / 'docs/evidence/correctness/inference-indexed-store-2026-10-28.json'
    add(prerequisite)
    add(NATIVE / 'ready-cli.json')
    # Pin only fixture descriptions/IDs. Their original weight bodies are not
    # copied or hashed by this package; the raw consumer commands name them.
    fixture_dirs = set()
    for folder in [W / 'runs' / name for name in CLI] + [STATE / 'runs' / name for name in TINY]:
        command = read(folder / 'command.json')['command']
        for flag in ('--inputs', '--cpu', '--cuda'):
            if flag in command:
                fixture_dirs.add(Path(command[command.index(flag) + 1]))
        if '--schedule' in command: add(command[command.index('--schedule') + 1])
    for fixture in fixture_dirs:
        for name in ('input.json', 'weights.tsv', 'prompt.ids'):
            if (fixture / name).is_file(): add(fixture / name)
    for row in clis:
        add(row['full_non_time_oracle']['path'], row['full_non_time_oracle'])
    for folder in (old_single, OLD_TWO):
        for name in ('stdout.log', 'stderr.log', 'command.json', 'process.json', 'result.json'):
            if (folder / name).exists(): add(folder / name)
    for path in (R / '.scratch/inference-wave-recovery-final-20261027/run.py',
                 R / '.scratch/inference-current-review-profile-20261027/analyze.py'):
        add(path)

    processes = [first_process, dll_process, *[row['process'] for row in clis],
                 *[row['process'] for row in k2], *[row['process'] for row in tiny]]
    started = min(row['started'] for row in processes)
    finished = max(row['started'] + row['seconds'] for row in processes)
    def iso(stamp):
        return datetime.fromtimestamp(stamp, timezone.utc).isoformat()
    evidence = dict(status='PASS_FINITE_HIDDEN_INDEXED_CORRECTNESS_WITH_PRESERVED_INITIAL_FAILURES',
        generated_utc=datetime.now(timezone.utc).isoformat(),
        actual_consumer_window=dict(started_utc=iso(started), finished_utc=iso(finished),
            timezone='UTC; raw process epochs retained',
            started_Asia_Shanghai=datetime.fromtimestamp(started, timezone(timedelta(hours=8))).isoformat()),
        scope='Canonical same original hidden_pool indexed Gather/Store, full pool capacity, explicit bank/Store identity, accepted-prefix single publication and original rollback/retirement. Sampling-frontier and read-only NextN maintenance remain original ready-leaf Commands.',
        builds=builds, reused_control_Model=control_model,
        older_two_turn_capture_reference=historical_ready,
        counts=dict(Model_CXX=2, Model_links=2, combined_state_probe_CXX=1, combined_state_probe_links=1,
            CLI_success_processes=3, current_K2_processes=2, finite_state_success_processes=5,
            preserved_failed_consumer_processes=2, total_actual_consumer_processes=12,
            new_SDK_builds=0, new_downloads=0, weight_payloads_archived=0),
        CLI_complete_non_time=clis, K2=dict(summary=pin(W / 'k2/summary.json'), arms=k2, differences=[]),
        finite_state=tiny,
        preserved_failures=[dict(kind='Initial Model989e missing prefill effect-chain dependency', process=first_process,
                no_inference_started=True, refinement=read(W / 'refinement.json')),
            dict(kind='Initial combined-state CPU runtime DLL discovery failure', process=dll_process,
                completed_state_check=False, same_probe_image_after_environment_repair=True, repair=alias),
            dict(kind='Preparation helper metadata classification failure before its CXX/run',
                raw=[pin(path) for path in sorted(STATE.glob('failure-prepare-*.log'))])],
        capture_structure=capture_rows,
        prerequisite_native_correctness=pin(prerequisite),
        actual_scope_limits=['State byte equality is within each backend against its original same-width candidates and restored continuation. No CPU-versus-CUDA bit-equality claim.',
            'Tiny fixtures are untrained and acceptance is explicitly controlled. They establish state/lease/epoch/RNG/old-snapshot/resource contracts, not natural acceptance quality.',
            'Real CLI and K2 comparisons cover complete non-time producer reports and natural outputs/round facts; no ignored result fields were added to force a pass.',
            'Capture counts 11→2 single and historical15→2 two-turn are observed structural counts. Two-turn baseline is an older different image; neither is a TPS or causal throughput conclusion.',
            'Canonical carry/prior/final-prefix are aliases of once-published accepted original Store writers. No full-pool readable lease, new pool, executor or Completion was introduced.',
            'No binaries/objects/PDB/SDK/model bodies or helper 11MBsource-index are archived; exact dependency/link/source manifests and raw failures/reports remain.',
            'This package performs offline reads/hashes/ZIP only; it never reruns any consumer, compiler, linker or GPU command.'],
        package_script=pin(__file__))
    # Content deduplication keeps repeated immutable project header snapshots
    # compact; every original absolute identity maps to its stored member.
    unique, manifest = {}, []
    for value in sorted(files.values(), key=lambda row: row['path']):
        digest = value['sha256']
        member = unique.setdefault(digest, Path(value['path']).relative_to(R).as_posix())
        manifest.append(dict(**value, archive_member=member))
    evidence['archive_manifest_entries'] = len(manifest)
    evidence['archive_unique_source_and_receipt_files'] = len(unique)
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        written = set()
        for entry in manifest:
            if entry['archive_member'] not in written:
                archive.write(entry['path'], entry['archive_member']); written.add(entry['archive_member'])
        archive.writestr('archive-manifest.json', encode(manifest))
        archive.writestr('evidence-before-archive-pin.json', encode(evidence))
    evidence['archive'] = pin(DEST.with_suffix('.zip'))
    evidence['archive_under_one_MiB'] = evidence['archive']['bytes'] < 1 << 20
    with DEST.with_suffix('.json').open('xb') as stream: stream.write(encode(evidence))
    with (W / 'package-manifest.json').open('xb') as stream: stream.write(encode(manifest))
    result = dict(status=evidence['status'], JSON=pin(DEST.with_suffix('.json')), ZIP=evidence['archive'],
        source_and_receipt_files=len(unique), identities=len(manifest), model_or_compiler_processes_started=0)
    with (W / 'package-result.json').open('xb') as stream: stream.write(encode(result))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
