from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve();s=importlib.util.spec_from_file_location('fixed_runner',P.with_name('diagnose.py'));d=importlib.util.module_from_spec(s);s.loader.exec_module(d)
S=d.S/'fixed1'; descriptor=d.read(S/'ready.json')
assert d.ident(S/'hyle.exe')==descriptor['image']
for item in descriptor['compiled']:
 assert d.ident(item['canonical_source']['path'])==item['canonical_source']
 assert d.ident(item['source']['path'])==item['source']
original=d.read(d.R/'.scratch/mtp-metadata-offline-20261024/q27/runs-current-runtime/mixed-k1/command.json')
assert d.ident(d.R/original['manifest']['path'])['sha256']==original['manifest']['sha256']
command=original['case']['command'];command[0]=str(S/'hyle.exe')
case=sys.argv[1]
if case=='mixed-k2-random':
 command[command.index('--steps')+1]='6'
 command+=['--mtp-max-drafts','2','--sampling','random','--temperature','1','--top-k','8','--top-p','0.9','--seed','123']
else: assert case=='mixed-k1'
runtime=d.read(d.R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/current-image.json')['runtime']
envpath=d.read(d.R/runtime['environment']['path'])['PATH'];env=dict(os.environ,PATH=str(S)+os.pathsep+envpath)
dest=S/case
result=d.q.execute(command,env,dest,600)
if result['exit']: raise SystemExit('Actual failure exit '+str(result['exit'])+'; retained '+str(dest))
reports=[json.loads(line) for line in (dest/'stdout.log').read_text(encoding='utf8').splitlines() if line.startswith('{')]
r=reports[-1]
assert r['source_id']=='de81a441e6cdfdd81a2124594edd50bc15ca95ed504d6ddca7dba651d28815c1'
assert r['backend']=='cuda' and r['mtp'] is True
assert (r['original_host_weight_bytes'],r['original_device_weight_bytes'])==(9863290880,6590152704)
assert r['text_tensors']==851 and r['mtp_tensors']==15
assert 0<len(r['generated_ids'])<=int(command[command.index('--steps')+1])
assert r['cache_peak_requested_bytes']<=2147483648
d.save(dest/'functional-result.json',dict(case=case,native_exit=0,image=descriptor['image'],source_id=r['source_id'],generated_ids=r['generated_ids'],cache_peak_requested_bytes=r['cache_peak_requested_bytes'],HTTP=0,SDK_builds=0,performance_claim=False))
print(json.dumps(d.read(dest/'functional-result.json')),flush=True)
