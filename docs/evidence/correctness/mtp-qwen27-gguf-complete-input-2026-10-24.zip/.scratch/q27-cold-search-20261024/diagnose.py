from pathlib import Path
import hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(json.dumps(v,indent=2)+'\n', encoding='utf8')
def mod(n,p):
    s=importlib.util.spec_from_file_location(n,p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def ident(p):
    p=Path(p); raw=p.read_bytes(); return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
h=mod('q27_cold_build',R/'.scratch/native-paged-effects-20261022/build_windows.py')
q=mod('q27_cold_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
def build():
    dest=S/'diagnostic1'; dest.mkdir(exist_ok=False)
    source=(R/'src/graph/executable.cc').read_text(encoding='utf8')
    source='#include <cstdio>\n'+source
    before='''      if (!attempt->succeeded()) {
        discovery.physical.reject_suffix(preparation_prefix[step.node_begin]);'''
    after='''      if (!attempt->succeeded()) {
        if (plan.search.operation_route_rejections < 4) {
          const auto why = attempt->reason.message();
          std::fprintf(stderr, "Q27DBG operation node=%zu kind=%u target=%u prefix=%zu states=%zu reason=%.*s\\n", static_cast<std::size_t>(step.node_begin), static_cast<unsigned>(graph.nodes[step.node_begin].kind()), step.target.ordinal(), discovery.physical.prefix(), plan.search.route_search_states, static_cast<int>(why.size()), why.data());
        }
        discovery.physical.reject_suffix(preparation_prefix[step.node_begin]);'''
    assert source.count(before)==1; source=source.replace(before,after)
    before='''        discovery.physical.reject_suffix(preparation_prefix[step.node_begin]);
        outcome.rejected_region = candidate.proposal_order;'''
    after='''        if (plan.search.region_route_rejections < 4) {
          const auto why = attempt->reason.message();
          std::fprintf(stderr, "Q27DBG region node=%zu proposal=%zu target=%u prefix=%zu states=%zu reason=%.*s\\n", static_cast<std::size_t>(step.node_begin), static_cast<std::size_t>(candidate.proposal_order), step.target.ordinal(), discovery.physical.prefix(), plan.search.route_search_states, static_cast<int>(why.size()), why.data());
        }
        discovery.physical.reject_suffix(preparation_prefix[step.node_begin]);
        outcome.rejected_region = candidate.proposal_order;'''
    assert source.count(before)==1; source=source.replace(before,after)
    before='''    if (outcome.rejected_plan) {
      if (status.ok() || outcome.rejected_region || outcome.rejected_operation)'''
    after='''    if (!status.ok() && (plan.search.route_plan_rejections + plan.search.operation_route_rejections + plan.search.region_route_rejections < 4 || outcome.search_limit || outcome.prepare_limit)) {
      const auto why = status.message();
      const auto last = discovery.last_rejection.message();
      std::fprintf(stderr, "Q27DBG rejection plan=%u op=%u region=%u states=%zu prepare=%zu plan_reject=%zu op_reject=%zu region_reject=%zu prefix=%zu reason=%.*s last=%.*s\\n", unsigned(outcome.rejected_plan), unsigned(outcome.rejected_operation.has_value()), unsigned(outcome.rejected_region.has_value()), plan.search.route_search_states, plan.search.placement_attempts, plan.search.route_plan_rejections, plan.search.operation_route_rejections, plan.search.region_route_rejections, discovery.physical.prefix(), static_cast<int>(why.size()), why.data(), static_cast<int>(last.size()), last.data());
    }
    if (outcome.rejected_plan) {
      if (status.ok() || outcome.rejected_region || outcome.rejected_operation)'''
    assert source.count(before)==1; source=source.replace(before,after)
    frozen=dest/'executable.cc'; frozen.write_text(source,encoding='utf8')
    command=read(R/'.scratch/graph-system-constant-lease-20261024/executable/command.json')['command']
    for i,a in enumerate(command):
        if a.lower().endswith('src\\graph\\executable.cc'): command[i]=str(frozen)
        elif a.startswith('/Fo'): command[i]='/Fo'+str(dest/'executable.obj')
        elif a.startswith('/Fd'): command[i]='/Fd'+str(dest/'executable.pdb')
        elif a.endswith('dependencies.json'): command[i]=str(dest/'dependencies.json')
    env,_=h.b.environment(command,[],dest)
    result=q.execute(command,env,dest/'compile',timeout=240)
    if result['exit']: raise RuntimeError(result)
    link=read(R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/link-command.json')
    old=R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj'
    assert sum(Path(a)==old for a in link if a.lower().endswith('.obj'))==1
    for i,a in enumerate(link):
        if a==str(old): link[i]=str(dest/'executable.obj')
        elif a.startswith('/OUT:'): link[i]='/OUT:'+str(dest/'hyle.exe')
    result=q.execute(link,env,dest/'link',timeout=240)
    if result['exit']: raise RuntimeError(result)
    native=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/hyle_ggml_cpu_gdn_scale_v3.dll'
    os.link(native,dest/native.name)
    save(dest/'ready.json',dict(source=ident(frozen),image=ident(dest/'hyle.exe'),native=ident(native),SDK_builds=0,HTTP=0,math_changes=False,diagnostics_only=True))
    print(json.dumps(read(dest/'ready.json')),flush=True)
def run():
    dest=S/'diagnostic1'
    original=read(R/'.scratch/mtp-metadata-offline-20261024/q27/runs-current-runtime/mixed-k1/command.json')
    command=original['case']['command']; command[0]=str(dest/'hyle.exe')
    descriptor=read(R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/current-image.json')['runtime']
    envpath=read(R/descriptor['environment']['path'])['PATH']
    env=dict(os.environ,PATH=str(dest)+os.pathsep+envpath)
    result=q.execute(command,env,dest/'run',timeout=600)
    print(json.dumps(result),flush=True)
if __name__=='__main__':
    {'build':build,'run':run}[sys.argv[1]]()
