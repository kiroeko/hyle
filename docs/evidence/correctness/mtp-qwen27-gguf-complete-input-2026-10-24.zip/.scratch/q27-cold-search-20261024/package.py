from pathlib import Path
import hashlib,json,zipfile
R=Path.cwd();S=Path(__file__).resolve().parent
B=R/'.scratch/mtp-metadata-offline-20261024/q27'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p);raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
records=[];files=[]
for case in ['cpu-ordinary','cpu-k1','mixed-ordinary','mixed-k1','mixed-k2-random']:
 folder=(B/'runs-current-runtime'/case) if case in ['cpu-ordinary','cpu-k1','mixed-ordinary'] else S/'fixed1'/case
 result=read(folder/'functional-result.json');assert result['native_exit']==0
 report=[json.loads(line) for line in (folder/'stdout.log').read_text(encoding='utf8').splitlines() if line.startswith('{')][-1]
 record=dict(case=case,result=result,process=read(folder/'process.json'),
   report={k:v for k,v in report.items() if any(s in k for s in ['mtp','source','weight','cache','generated','score','sampling','draft','accepted','proposal'])})
 records.append(record)
 files.extend(folder/name for name in ['command.json','process.json','stdout.log','stderr.log','functional-result.json'])
plan=read(R/'.scratch/qwen-multi-draft-20261024/current-runtime-plans/Q27.json')
manifest=read(B/'complete-v2/input.json')
diagnostic=S/'diagnostic1/run'
assert read(diagnostic/'process.json')['exit']==1
files.extend(diagnostic/name for name in ['command.json','process.json','stderr.log','stdout.log'])
old=B/'runs-current-runtime/mixed-k1';assert read(old/'process.json')['exit']==1
files.extend(old/name for name in ['command.json','process.json','stderr.log','stdout.log'])
for name in ['build-fix.py','diagnose.py','run-fixed.py','package.py','fixed1/ready.json','fixed1/graph/executable.cc','fixed1/region/ggml_cuda_region.cc','fixed1/graph/compile/command.json','fixed1/graph/compile/process.json','fixed1/graph/compile/stdout.log','fixed1/graph/compile/stderr.log','fixed1/region/compile/command.json','fixed1/region/compile/process.json','fixed1/region/compile/stdout.log','fixed1/region/compile/stderr.log','fixed1/link/command.json','fixed1/link/process.json','fixed1/link/stdout.log','fixed1/link/stderr.log']:
 files.append(S/name)
files.extend([B/'payload-role-files.json',B/'complete-v2/input.json',B/'complete-v2/weights.tsv',B/'pieces/payload-acquisition-complete.json',R/'.scratch/qwen-multi-draft-20261024/current-runtime-plans/Q27.json'])
out=R/'docs/evidence/correctness/mtp-qwen27-gguf-complete-input-2026-10-24.json'
archive=out.with_suffix('.zip');assert not archive.exists() and not out.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in dict.fromkeys(files):
  assert p.is_file(),str(p)
  assert p.suffix not in ['.bin','.obj','.exe','.dll','.lib']
  z.write(p,p.relative_to(R).as_posix())
record=dict(status='PASS',date='2026-10-24',scope='Five finite complete original 27B GGUF CPU/mixed functional journeys. Not a whole-task quality or performance comparison.',
 source=manifest['original_gguf_source'],source_id=manifest['source_id'],original_roles=866,original_payload_bytes=16453443584,
 prepared=ident(B/'complete-v2/input.json'),manifest=ident(B/'complete-v2/weights.tsv'),
 geometry=dict(prompt_tokens=1,bos=248044,capacity=32,cache_limit_bytes=2147483648,ordinary_outputs=4,k1_outputs=4,random_k2_outputs=6,full_GPU=False,reason='Original 16.45GB encoded bank exceeds 12GiB VRAM; all64 FFN layers are explicitly host-resident in mixed cases.'),
 runtimes=dict(pure_cpu=plan['runtime']['cpu'],baseline_mixed=plan['runtime']['mixed'],fixed_mixed=read(S/'fixed1/ready.json')),
 results=records,
 corrected_defect=dict(trigger='Checked encoded embedding consumes target IDs produced internally by draft TopK/Concat; CUDA generic fusion incorrectly admitted an internal index while its native guard validates only region inputs.',
  diagnostic=dict(node=84,proposal=257,first_route_search_states=5307,first_placement_attempts=29,repeated_region_declines=40,final_search_states=65536,final_placement_attempts=1160,reason='ggml CUDA dynamic indices require a checked boundary'),
  fix='Reject the ineligible fusion in region qualification, before physical resource search. Ordinary checked Gather remains eligible. Preserve previous prepare rejection when a later search limit terminates compilation.',
  search_limits_unchanged=True,index_checks_preserved=True,arithmetic_unchanged=True,
  original_failure=ident(old/'stderr.log'),instrumented_failure=ident(diagnostic/'stderr.log')),
 archive=ident(archive),HTTP_for_runs=0,SDK_builds=0,
 qualifications=['Original full-file LFS SHA was verified by streaming header plus authenticated contiguous pieces; no second full-file model was reconstructed.',
  'All selected physical codecs remain encoded; mixed weights total9,863,290,880 host +6,590,152,704 device bytes with no original-weight duplication.',
  'BOS-only short journeys establish complete loading/compilation/generation/state/cache/normal destruction. They do not establish natural-language task quality, full context capacity or TPS.',
  'CPU ordinary, CPU K1 and mixed ordinary retain their previously frozen runtimes. Only mixed MTP uses the two-object provider/diagnostic fix; other sources and limits are unchanged.'])
out.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(evidence=ident(out),archive=ident(archive),cases=len(records))))
