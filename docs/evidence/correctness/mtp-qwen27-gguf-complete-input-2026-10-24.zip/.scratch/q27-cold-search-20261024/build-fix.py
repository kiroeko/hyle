from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import importlib.util, json, os, sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve(); s=importlib.util.spec_from_file_location('diag_helper',P.with_name('diagnose.py'));d=importlib.util.module_from_spec(s);s.loader.exec_module(d)
R=d.R;S=d.S/'fixed1';S.mkdir(exist_ok=False);(S/'tmp').mkdir()
jobs=[('graph',R/'src/graph/executable.cc',R/'.scratch/graph-system-constant-lease-20261024/executable/command.json',R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj'),
      ('region',R/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/records/graph_provider_ggml_cuda--ggml_cuda_region/identity.json',R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/graph_provider_ggml_cuda--ggml_cuda_region.obj')]
def compile(job):
 name,src,recipe,old=job;out=S/name;out.mkdir();(out/'tmp').mkdir()
 frozen=out/src.name;frozen.write_bytes(src.read_bytes())
 command=d.read(recipe)['command']
 for i,a in enumerate(command):
  if a.lower()==str(src).lower(): command[i]=str(frozen)
  elif a.startswith('/Fo'):command[i]='/Fo'+str(out/(name+'.obj'))
  elif a.startswith('/Fd'):command[i]='/Fd'+str(out/(name+'.pdb'))
  elif a.endswith(('-deps.json','dependencies.json')):command[i]=str(out/'dependencies.json')
 command.insert(1,'/I'+str(src.parent))
 env,_=d.h.b.environment(command,[],out)
 result=d.q.execute(command,env,out/'compile',240)
 if result['exit']:raise RuntimeError(str(out)+' exit '+str(result['exit']))
 return dict(old=str(old),object=d.ident(out/(name+'.obj')),source=d.ident(frozen),canonical_source=d.ident(src))
with ThreadPoolExecutor(max_workers=2) as pool: compiled=list(pool.map(compile,jobs))
link=d.read(R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/link-command.json')
for job in compiled:
 assert link.count(job['old'])==1
 link[link.index(job['old'])]=job['object']['path']
for i,a in enumerate(link):
 if a.startswith('/OUT:'):link[i]='/OUT:'+str(S/'hyle.exe')
env,_=d.h.b.environment(link,[],S)
r=d.q.execute(link,env,S/'link',240)
if r['exit']:raise RuntimeError('link exit '+str(r['exit']))
native=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(native,S/native.name)
d.save(S/'ready.json',dict(image=d.ident(S/'hyle.exe'),native=d.ident(native),compiled=compiled,HTTP=0,SDK_builds=0,math_changes=False,search_limits_unchanged=True))
print(json.dumps(d.read(S/'ready.json')),flush=True)
