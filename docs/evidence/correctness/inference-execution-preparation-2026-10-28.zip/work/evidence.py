"""Package completed preparation checks offline, with no native execution."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parent.parent
OLD = W.parent / 'inference-execution-episode-20261028'
DEST = R / 'docs/evidence/correctness/inference-execution-preparation-2026-10-28'
UNITS = ['tiny', 'submission-source']


def read(path):
    return json.loads(Path(path).read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def body(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def pin(path):
    path = Path(path); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def exact(path, identity):
    actual = pin(path)
    assert (actual['bytes'], actual['sha256']) == (identity['bytes'], identity['sha256']), str(path)


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Preserve any prior package'
    spec = importlib.util.spec_from_file_location('strict_preparation_parser', W / 'parse.py')
    parser = importlib.util.module_from_spec(spec); spec.loader.exec_module(parser)
    analysis = read(W / 'analysis.json')
    assert analysis['status'] == 'PASS_SEVEN_FINITE_PREPARATION_CASES' and analysis['native_processes'] == 7
    assert analysis['state_comparisons'] == 32 and analysis['byte_exact_state_comparisons'] == 2
    assert analysis['original_gdn_absolute_budget'] == 0.000003
    assert analysis['maximum_gdn_absolute_difference'] <= analysis['original_gdn_absolute_budget']
    members = {}

    def add(path, name=None):
        path = Path(path); name = name or 'work/' + path.relative_to(W).as_posix()
        assert name not in members and not name.lower().endswith(('.exe', '.obj', '.dll', '.lib', '.pdb'))
        members[name] = path.read_bytes()

    for f in ['build.py', 'run.py', 'parse.py', 'evidence.py', 'analysis.json', 'run-plan.json',
              'final-build-plan.json', 'final-source-freeze.json', 'frozen-project-dependencies.json', 'runtime.json']:
        add(W / f)
    exact(analysis['parser']['path'], analysis['parser'])
    exact(analysis['reused_parser']['path'], analysis['reused_parser'])
    add(analysis['reused_parser']['path'], 'helpers/reused-episode-parser.py')
    freeze = read(W / 'final-source-freeze.json'); sources = []
    exact(W / 'build.py', freeze['helper'])
    for item in freeze['snapshots']:
        exact(item['original']['path'], item['original']); exact(item['snapshot']['path'], item['snapshot'])
        relative = Path(item['original']['path']).relative_to(R).as_posix()
        add(item['snapshot']['path'], 'source/after/' + relative)
        sources.append(dict(file=relative, identity=item['original']))
    # The previous completed slice is the exact pre-change source, not a
    # performance control and not another repeated archive in this package.
    for relative in ['engine/models/qwen35/main.cc', 'engine/inference/execution_episode.h']:
        before = OLD / 'source' / relative; after = W / 'source' / relative
        add(before, 'source/before/' + relative)
        members['diff/' + relative + '.diff'] = ''.join(difflib.unified_diff(
            before.read_text(encoding='utf-8').splitlines(keepends=True),
            after.read_text(encoding='utf-8').splitlines(keepends=True),
            fromfile='a/' + relative, tofile='b/' + relative)).encode('utf-8')

    plan = read(W / 'final-build-plan.json'); base = read(plan['inputs']['path'])
    assert len(base) == 228 and base.count(plan['original_object']) == 1
    members['identity/base-link-inputs.json'] = body(base)
    replacement = base.index(plan['original_object']); units = []; dependencies = {}
    for category in ['logs', 'links']:
        assert sorted(path.parent.name for path in (W / category).glob('*/process.json')) == sorted(UNITS)
    for unit in UNITS:
        ready = read(W / f'ready-{unit}.json'); compiled = read(W / f'compile/{unit}/compiled.json')
        cxx = read(W / f'logs/{unit}/process.json'); link = read(W / f'links/{unit}/process.json')
        assert cxx == compiled['process'] and link == ready['process'] and ready['compiled'] == compiled
        assert cxx['exit'] == link['exit'] == 0 and not cxx['timed_out'] and not link['timed_out']
        expected = list(base); expected[replacement] = compiled['object']
        assert read(ready['inputs']['path']) == expected
        exact(ready['inputs']['path'], ready['inputs'])
        units.append(dict(name=unit, compilation=compiled, link=link, image=ready['image'],
                          inputs=ready['inputs'], replacement_index=replacement, replacement_object=compiled['object']))
        for f in [f'recipes/{unit}.json', f'link-recipes/{unit}.json', f'ready-{unit}.json',
                  f'compile/{unit}/compiled.json', f'compile/{unit}/dependencies.json']:
            add(W / f)
        for category in ['logs', 'links']:
            for f in ['command.json', 'process.json', 'stdout.log', 'stderr.log']: add(W / category / unit / f)
        for item in read(W / f'compile/{unit}/actual-dependencies.json'):
            key = item['path'].replace('\\', '/').lower()
            if key in dependencies: assert dependencies[key] == item
            else: dependencies[key] = item
    members['identity/actual-dependency-identities.json'] = body(list(dependencies.values()))

    run_plan = read(W / 'run-plan.json'); native = []; comparisons = []
    assert set(run_plan['cases']) == set(parser.CASES)
    assert sorted(path.parent.name for path in (W / 'runs').glob('*/process.json')) == sorted(parser.CASES)
    assert len(analysis['cases']) == 7
    for row in analysis['cases']:
        name = row['name']; backend, kind, _ = parser.CASES[name]; directory = W / 'runs' / name
        process = read(directory / 'process.json'); command = read(directory / 'command.json')
        reports = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert process == row['process'] and command == row['command']
        assert command['command'] == run_plan['cases'][name]['command']
        assert process['exit'] == 0 and process['state'] == 'TERMINAL' and not process['timed_out']
        assert len(reports) == 1 and reports[0] == row['report']
        parser.check_report(reports[0], backend, kind)
        states = parser.state_rows(reports[0], kind); comparisons.extend(states)
        native.append(dict(name=name, process=process, backend=backend, kind=kind, state_comparisons=len(states)))
        for f in ['command.json', 'process.json', 'stdout.log', 'stderr.log']: add(directory / f)
    assert len({case['process']['pid'] for case in native}) == 7 and len(comparisons) == 32
    assert sum(row['payloads_byte_equal'] for row in comparisons) == 2
    maximum = max((item['maximum_absolute'] for row in comparisons for item in row['differences']), default=0)
    assert maximum == analysis['maximum_gdn_absolute_difference']
    summary = dict(schema='hyle.execution-preparation.finite-correctness.v1', status=analysis['status'],
        scope='The original selected Graph preparation order shared by ordinary, packed, NextN and Source-backed execution; original model equations, resource permissions and retirement remain unchanged.',
        claims=dict(performance_improvement=False, complete_inference_core=False, native_unknown_retirement_tested=False),
        actual_counts=dict(CXX=2, links=2, native_processes=7, SDK_CXX=0, NVCC=0, downloads=0),
        state_comparisons=dict(total=32, byte_exact=2, bounded_new_f32_gdn=30,
            maximum_absolute_difference=maximum, unchanged_absolute_budget=analysis['original_gdn_absolute_budget'],
            nonfinite_differences_allowed=False, other_payloads='byte_exact', old_snapshots='byte_exact', boundaries_and_RNG='exact'),
        source_identities=sources, compilation_and_closures=units, native_cases=native,
        original_driver_identity=plan['original_driver'],
        limits=['Synthetic finite CPU/CUDA component consumers; no throughput, natural acceptance or task-quality conclusion.',
                'Only newly computed F32 GDN payloads use the existing independent component-oracle budget. The 32 comparisons are not all byte-identical.',
                'Illegal-index, cancelled-member, StateOnly, Source and exact metadata gates were not relaxed.',
                'No Vulkan/Apple or unknown-native-retirement fault retest; no provider-naming review claims are part of this numerical evidence.',
                'SDK, model weights, executable/object/runtime payloads and previous archives are excluded; closure/dependency identities are retained once.'])
    members['summary.json'] = body(summary)
    manifest = [dict(name=name, bytes=len(data), sha256=digest(data)) for name, data in sorted(members.items())]
    members['manifest.json'] = body(dict(members=manifest, excludes_itself=True))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()): archive.writestr(name, data)
    archive = pin(DEST.with_suffix('.zip')); archive['members'] = len(members)
    summary['archive'] = archive
    with DEST.with_suffix('.json').open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(dict(status=summary['status'], archive=archive, actual_counts=summary['actual_counts'], state_comparisons=summary['state_comparisons'])))


if __name__ == '__main__':
    main()
