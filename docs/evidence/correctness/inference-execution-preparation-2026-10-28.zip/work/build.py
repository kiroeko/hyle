"""Two preparation consumers, existing228 SDK/weights; root owns execution."""
from pathlib import Path
import importlib.util
import re
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-execution-episode-20261028'
spec = importlib.util.spec_from_file_location('episode_original_windows_driver', BASE / 'build.py')
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
t = prior.t; t.W = W
SOURCES = dict(tiny='tests/tools/qwen_host_image_test.cc',
               **{'submission-source': 'tests/tools/qwen_submission_source_probe.cc'})
EXPECTED = {'engine/models/qwen35/main.cc': '2434c27c9c49f34bcf73269b831b610af9c396ffc8f1c5d9951f04e010742f5b',
            'engine/inference/execution_episode.h': 'd719158be06da504f1f1b9d4e54655a1493c7d771f81e67bccd23c450123f57f'}


def prepare():
    ready = t.read(BASE / 'ready-tiny.json'); rows = t.read(ready['inputs']['path']); assert len(rows) == 228
    old = ready['compiled']['object']; assert old in rows
    stats = []
    for row in rows:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns, retained_sha256=row['sha256']))
    t.save(W / 'retained-input-stats.json', stats)
    before = t.command(ready['compiled']['command']['path'])
    original_source = t.read(ready['compiled']['dependencies']['path'])['Data']['Source']
    for name, source in SOURCES.items():
        args = []
        for i, arg in enumerate(before):
            if t.key(arg) == t.key(original_source): arg = str(R / source)
            elif i and before[i-1].lower() == '/sourcedependencies': arg = str(W / f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
            args.append(arg)
        assert '/DHYLE_COMPUTE_CPU=1' in args and '/DHYLE_COMPUTE_CUDA=1' in args
        t.save(W / f'recipes/{name}.json', dict(command=args, timeout_seconds=300))
        link = []
        for arg in t.command(ready['recipe']['path']):
            if t.key(arg) == t.key(old['path']): arg = str(W / f'compile/{name}/unit.obj')
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
                if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin' / name).with_suffix(suffix)); break
            link.append(arg)
        t.save(W / f'link-recipes/{name}.json', dict(command=link, timeout_seconds=240))
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'runtime.json', dict(PATH=env['PATH'], native=t.read(BASE / 'runtime.json')['native']))
    native=t.read(W/'runtime.json')['native']; (W/'bin').mkdir(exist_ok=True)
    alias=W/'bin'/Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    t.save(W / 'final-build-plan.json', dict(baseline=t.pin(BASE / 'ready-tiny.json'), inputs=ready['inputs'],
        original_object=old, source_dependencies=ready['compiled']['dependencies'],
        sources=SOURCES, original_driver=t.pin(BASE / 'build.py'), environment=t.pin(W / 'environment.json'),
        retained_stats=t.pin(W / 'retained-input-stats.json'), runtime=t.pin(W / 'runtime.json'),
        recipes={n:t.pin(W / f'recipes/{n}.json') for n in SOURCES}, links={n:t.pin(W / f'link-recipes/{n}.json') for n in SOURCES},
        counts=dict(CXX=2, links=2, inputs=228, SDK_CXX=0, NVCC=0, downloads=0)))
    print('PREPARED2 CXX/links; no native process')


def plan():
    value = t.read(W / 'final-build-plan.json')
    for key in ('baseline','inputs','original_driver','environment','retained_stats','runtime'): t.exact(value[key])
    for row in [*value['recipes'].values(), *value['links'].values()]: t.exact(row)
    return value


def freeze():
    value = plan()
    for source, sha in EXPECTED.items(): assert t.pin(R / source)['sha256'] == sha, source
    paths = {t.key(t.canonical(p)):t.canonical(p) for p in t.dep_paths(value['source_dependencies']['path']) if t.project(t.canonical(p))}
    roots = [R / 'include', R] + [Path(a[2:]) for a in t.command(value['recipes']['tiny']['path']) if a.lower().startswith('/i')]
    pending = [R / s for s in [*SOURCES.values(), *EXPECTED]]; seen = set()
    while pending:
        p = pending.pop().resolve()
        if t.key(p) in seen: continue
        seen.add(t.key(p)); paths[t.key(p)] = p
        for kind, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]',p.read_text(encoding='utf-8-sig'),re.M):
            q = next((v.resolve() for root in ([p.parent] if kind=='"' else []) + roots if (v:=root/name).is_file()),None)
            if q is not None and t.project(q): pending.append(q)
    t.save(W / 'frozen-project-dependencies.json',[t.pin(p) for p in paths.values()])
    snapshots = []
    for relative in dict.fromkeys([*EXPECTED,*SOURCES.values()]):
        target = W / 'source' / relative; target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as out: out.write((R/relative).read_bytes())
        snapshots.append(dict(original=t.pin(R/relative),snapshot=t.pin(target)))
    t.save(W / 'final-source-freeze.json',dict(helper=t.pin(__file__),dependencies=t.pin(W/'frozen-project-dependencies.json'),snapshots=snapshots))
    print('SOURCE FROZEN',len(paths),'actual project/preflight includes')


def validate():
    value = plan(); frozen = t.read(W/'final-source-freeze.json')
    t.exact(frozen['helper']); t.exact(frozen['dependencies'])
    for row in t.read(frozen['dependencies']['path']): t.exact(row)
    for row in frozen['snapshots']: t.exact(row['original']);t.exact(row['snapshot'])
    return value,frozen


def parse_compile(name):
    value,frozen=validate();out=W/'compile'/name;process=t.read(W/f'logs/{name}/process.json')
    assert process['exit']==0 and not process['timed_out']
    allowed={t.key(p['path']):p for p in t.read(frozen['dependencies']['path'])};actual=[]
    for p in dict.fromkeys(t.dep_paths(out/'dependencies.json')):
        if t.project(p): assert t.key(p) in allowed,('Metadata error after successful CXX; do not recompile',str(p));t.exact(allowed[t.key(p)])
        actual.append(t.pin(p))
    t.save(out/'actual-dependencies.json',actual)
    t.save(out/'compiled.json',dict(source=t.pin(R/SOURCES[name]),object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/f'logs/{name}/command.json'),dependencies=t.pin(out/'dependencies.json'),actual_dependencies=t.pin(out/'actual-dependencies.json')))
    print('CXX metadata PASS',name)


def compile_unit(name):
    value,_=validate();(W/'compile'/name).mkdir(parents=True,exist_ok=False)
    t.execute(t.command(value['recipes'][name]['path']),W/'logs'/name,300);parse_compile(name)


def link_unit(name):
    value,_=validate();compiled=t.read(W/f'compile/{name}/compiled.json');t.exact(compiled['object'])
    for row in t.read(value['retained_stats']['path']):
        st=Path(row['path']).stat();assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns'])
    rows=[compiled['object'] if row==value['original_object'] else row for row in t.read(value['inputs']['path'])]
    assert len(rows)==228 and sum(a!=b for a,b in zip(rows,t.read(value['inputs']['path'])))==1
    (W/'bin').mkdir(exist_ok=True);native=t.read(value['runtime']['path'])['native'];alias=W/'bin'/Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path']);t.save(W/f'inputs-{name}.json',rows)
    process=t.execute(t.command(value['links'][name]['path']),W/'links'/name,240)
    t.save(W/f'ready-{name}.json',dict(image=t.pin(W/f'bin/{name}.exe'),inputs=t.pin(W/f'inputs-{name}.json'),compiled=compiled,
        process=process,recipe=t.pin(W/f'links/{name}/command.json'),runtime=value['runtime'],source_freeze=t.pin(W/'final-source-freeze.json')))
    print('LINK PASS',name)


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze()
    elif action=='preflight':validate()
    elif action=='compile':compile_unit(sys.argv[2])
    elif action=='parse-compile':parse_compile(sys.argv[2])
    elif action=='link':link_unit(sys.argv[2])
    else:raise ValueError(action)
