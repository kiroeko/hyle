"""Package only this finite CPU source-composition result; never compile/run it."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
PUBLIC = ROOT / 'docs/evidence/correctness/inferact-fused-mxfp4-source-2026-10-25.json'
ZIP = PUBLIC.with_suffix('.zip')

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')

def facts(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

sources = read(WORK / 'product-pins.json')['files']
for entry in sources:
    assert facts((ROOT / entry['path']).read_bytes()) == entry['after']
    assert facts((WORK / 'source' / entry['path']).read_bytes()) == entry['after']
summary = read(WORK / 'cpu1/summary.json')
assert summary['status'] == 'PASS'
assert summary['xml'] == dict(tests=1, failures=0, errors=0, skipped=0)
source = read(WORK / 'source-spans.json')
header = ROOT / source['header']['path']
assert facts(header.read_bytes()) == {k: source['header'][k] for k in ('bytes', 'sha256')}
cached = json.loads(header.read_bytes())
for role in source['roles']:
    tensor = cached[role['name']]
    assert all(tensor[key] == role[key] for key in ('dtype', 'shape', 'data_offsets'))

research = ROOT / 'docs/evidence/research/inferact-micro32-contract-2026-10-21.zip'
with zipfile.ZipFile(research) as archive:
    reader = archive.read('runtime/routed_experts.py')
assert hashlib.sha256(reader).hexdigest() == '31e77226425db7eea658e1f273627dca8fb3d423119c3857f8aa5fc6b0d3bd07'
lines = reader.decode('utf-8').splitlines()
reader_facts = dict(
    version='vLLM 7b569ec8953cf8099638a6d2ee1e915b75867c3a',
    archive=research.relative_to(ROOT).as_posix(), member='runtime/routed_experts.py',
    full_member=facts(reader),
    selected_lines=[dict(line=i, text=lines[i-1]) for i in range(1074, 1079)],
    meaning='The original loaded fused W/SF is split along full dim0 into contiguous halves, before this finite per-half prefix is selected.',
    numerical_reference='Unchanged positive-finite F32 to E8M0 GRS RNE importer, then BF16 weight-only reader; no producer-OAS or native reduction equivalence.')

report = dict(
    status='ORDINARY_FUSED_SOURCE_COMPOSITION_CPU_PASS', date='2026-10-25',
    problem='Original fused gate_up codes and independent F32 scale roles lacked the ordinary selected-bank/map/lease composition beyond the already qualified MTP down tile.',
    change='One model-private cold source adapter validates exact cached role metadata and existing ready leases, selects each original half by its own row stride, converts only selected SF prefixes through the existing importer, and feeds the existing four-plane resident-bank/map supply and BF16 weight-only Graph reader.',
    sources=sources, integration='Both checked source paths are integrated in canonical; no additional build/run during packaging.',
    source_qualification=dict(repository=source['repository'], revision=source['revision'], shard=source['shard'], header=source['header'],
        data_base=source['data_base'], original_file_bytes=source['source_bytes'],
        original_numeric_payload_bytes=0, source_roles='Eight exact cached header W/F32-SF roles for global IDs 0/1/17/511; actual new numerical bodies are explicitly generated full-original-shape fixtures. Source identity metadata does not authenticate fixture bytes.'),
    geometry=dict(full_fused_rows=4096, original_half_rows=2048, prefix_rows_per_half=3, depth=8192,
        original_weight_row_bytes=4096, original_F32_SF_row_bytes=1024,
        up_weight_byte_offset=8388608, up_F32_SF_byte_offset=2097152,
        selected_experts=2, global_domain=512, planes=['gate_W', 'gate_E8_SF', 'up_W', 'up_E8_SF'],
        map='I32 global to local, checked before selected projection', generations=[[0,17],[1,511]],
        resident_logical_bytes_per_generation=54272, converted_E8_SF_bytes_per_generation=3072),
    checks=dict(filter='CpuMxfp4ReferenceGraph.InferactFusedHalvesKeepOriginalScaleImportAndSelectedBankGeneration',
        actual=summary, endpoint_values=48,
        numerical='Non-FP4 BF16 activation values remain unchanged. Signed E2M1 times imported E8 scales is rounded to BF16 W; a two-term F64 sum is rounded to the expected BF16 endpoint. Independent GRS-RNE examples assert 1.25->E8(1) and 1.5->E8(2).',
        cold_rejection=['Wrong original W span', 'Invalid up-SF after gate conversion returns no prepared Source or new generation; no clamp'],
        lifetime='Two bound generations hold 10 bank blocks; a third upload is rejected. Dropping batches preserves 10 Invocation-held blocks, dropping Invocations retires all 10, and independent old result leases remain readable after compiled graph release.',
        strict='One existing CPU test TU with MSVC /W4 /WX and sourceDependencies; cached original CPU core/native closure.',
        first_attempt_pass=True, root_executed=True),
    reader=reader_facts,
    limits=[
        'This is each original half first N3 rows/full K8192, not the full fused bank, complete FFN/down/router, complete Model, or generation.',
        'No ordinary original fused publisher W/SF numeric payload was fetched or executed. Generated bodies carry the exact descriptor/span metadata solely to exercise the real lease boundary; authenticity remains the original supplier responsibility.',
        'The existing importer selected GRS RNE and its strict positive-finite/code0..254 domain remain unchanged. Original exporter OAS and native arithmetic equivalence are not established.',
        'No GPU/native platform run, full-artifact quality, throughput or performance claim. No SDK/core/provider rebuild, HTTP or new executor/registry.',
        'The historical source-only scope/product-pins records are preserved; cpu1 command/process/XML/raw establish the later actual CPU result. Unchanged frozen trees, models, SDK and binaries are omitted.'
    ], related_evidence=['docs/evidence/research/inferact-micro32-contract-2026-10-21.json',
        'docs/evidence/correctness/mtp-original-source-format-tiles-2026-10-24.json'])

members = {}
def add(path, member):
    assert member not in members
    members[member] = path.read_bytes()

for name in ('product.patch', 'product-pins.json', 'patch-check.json', 'source-spans.json', 'scope.json',
             'independent-review-sampling.json', 'check_cpu.py', 'publish.py'):
    add(WORK / name, name)
for entry in sources:
    add(WORK / 'source' / entry['path'], 'source/' + entry['path'])
    if entry['before']:
        add(WORK / 'before' / entry['path'], 'before/' + entry['path'])
for name in ('summary.json', 'tests.xml', 'frozen-project.json', 'actual-dependencies.json', 'link-inputs.json', 'runtime.json'):
    add(WORK / 'cpu1' / name, 'cpu1/' + name)
for phase in ('compile', 'link', 'run'):
    for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'):
        add(WORK / 'cpu1' / phase / name, f'cpu1/{phase}/{name}')
add(WORK / 'cpu1/compile/dependencies.json', 'cpu1/compile/dependencies.json')
add(header, 'original-source/header.json')
members['original-source/reader-facts.json'] = encode(reader_facts)
add(ROOT / 'docs/evidence/research/inferact-micro32-contract-2026-10-21.json', 'original-source/selected-reader-contract.json')
add(ROOT / '.scratch/inference-e4-append-implementation-20261025/check_finite.py', 'runner-dependencies/check_finite.py')
add(ROOT / 'scripts/hyle_environment.py', 'runner-dependencies/hyle_environment.py')
members['report-without-archive.json'] = encode(report)
manifest = [dict(path=name, **facts(data)) for name, data in sorted(members.items())]
members['archive-manifest.json'] = encode(dict(files=manifest, excludes='Manifest does not list itself.'))
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2026,10,25,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data)
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(members)
    for item in manifest:
        assert facts(archive.read(item['path'])) == {key:item[key] for key in ('bytes','sha256')}
report['archive'] = dict(path=ZIP.relative_to(ROOT).as_posix(), **facts(ZIP.read_bytes()),
    members=len(members), logical_bytes=sum(map(len,members.values())), CRC_and_member_SHA256_verified=True)
PUBLIC.write_bytes(encode(report))
(WORK / 'public-manifest.json').write_bytes(encode(dict(public=dict(path=PUBLIC.relative_to(ROOT).as_posix(), **facts(PUBLIC.read_bytes())), archive=report['archive'])))
print(json.dumps(read(WORK / 'public-manifest.json'), indent=2))
