from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def facts(value):
    if isinstance(value,list):return [facts(x) for x in value]
    if isinstance(value,dict):return {k:facts(v) for k,v in value.items()
        if not any(x in k for x in ['seconds','per_second','capture','replay','trace_name'])
        and not k.startswith(('decode_overlap','overlap_'))}
    return value
results=[]
for backend in ['cpu','cuda']:
    for kind in ['ordinary','mtp-k3']:
        name=backend+'-'+kind+'-b2'
        before=R/'.scratch/inference-model-successor-20261027/cli4'/name/'report.json'
        after=W/'runs'/('regression-'+name)/'report.json'
        original,current=facts(read(before)),facts(read(after))
        assert current==original,(name,[k for k in current if current[k]!=original.get(k)])
        results.append(dict(name=name,complete_non_time_report_equal=True,
            prior_sha256=hashlib.sha256(before.read_bytes()).hexdigest(),
            current_sha256=hashlib.sha256(after.read_bytes()).hexdigest()))
(W/'regression-facts.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print('PASS four complete non-time B2 reports')
