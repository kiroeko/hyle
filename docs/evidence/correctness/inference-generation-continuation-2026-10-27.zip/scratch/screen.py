from pathlib import Path
import importlib.util,json,statistics,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('screen_build',W/'build.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
b,h=m.b,m.h
ready=b.read(W/'ready4.json');image=next(a['image'] for a in ready['artifacts'] if a['name']=='cli');b.exact(image)
rows=[]; oracle=None
ignored={'cache_shared_backing_bytes','cache_live_requested_bytes','cache_peak_requested_bytes',
 'cache_requested_byte_limit','cache_metadata_requested_bytes','cache_retained_output_backing_bytes'}
def facts(value):
    if isinstance(value,list):return [facts(x) for x in value]
    if isinstance(value,dict):
        return {k:facts(v) for k,v in value.items() if k not in ignored and
                not any(x in k for x in ['seconds','per_second','capture','replay','trace_name'])}
    return value
for index,mode in enumerate(['off','auto','auto','off','off','auto']):
    name=f'screen{index+1}-{mode}';out=W/'runs'/name
    command=[image['path'],'--inputs',str(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),
      '--backend','cuda','--mtp','off','--capacity','256','--steps','97',
      '--max-sessions','1','--active-sequences','1','--decode-overlap',mode]
    process=h.execute(command,m.env(),out,timeout=180)
    report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'))
    b.save(out/'report.json',report)
    selected=facts(report['sessions'][0]['result'])
    if oracle is None:oracle=selected;b.save(W/'screen-oracle.json',oracle)
    else:
        if selected!=oracle:
            changed=[k for k in selected if selected[k]!=oracle.get(k)]
            raise AssertionError(('complete non-time result changed',name,changed))
    assert report['live_committed_versions']==0 and report['overlap_successor_refusals']==0
    assert report['generated_tokens']==97 and report['generated_decode_tokens']==96
    row=dict(name=name,mode=mode,process=process,
        prefill=report['prefill_tokens_per_second'],decode=report['decode_output_tokens_per_second'],
        total=report['output_tokens_per_second'],ready_seconds=report['startup_to_ready_seconds'],
        shared_backing_bytes=report['cache_shared_backing_bytes'],
        successor_submissions=report['overlap_successor_submissions'],
        successor_publications=report['overlap_successor_publications'],report=b.pin(out/'report.json'))
    rows.append(row);b.save(W/'screen-partial.json',rows)
    print('SCREEN '+json.dumps(row),flush=True)
summary={mode:{key:statistics.median(row[key] for row in rows if row['mode']==mode)
               for key in ['prefill','decode','total','ready_seconds','shared_backing_bytes']}
         for mode in ['off','auto']}
b.save(W/'screen-summary.json',dict(status='PASS',image=image,runs=rows,medians=summary,
    source_result_facts_equal=True,memory_peak_sampled=False,peer_run=False,
    scope='six-process candidate screen; same image ordinary R1 P154 + 96 decode; not a complete peer window'))
print('MEDIANS '+json.dumps(summary),flush=True)
