"""Offline receipts only. Run after root's final7 checks; never builds or runs models."""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
NAME = 'inference-generation-continuation-2026-10-27'
CORRECT = R/'docs/evidence/correctness'/f'{NAME}.json'
ZIP = CORRECT.with_suffix('.zip')
PERF = R/'docs/evidence/performance/inference-generation-continuation-screen-2026-10-27.json'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def pin(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']

def text(name):
    return (W/name).read_text(encoding='utf-8-sig', errors='replace')

def render(value, depth=0):
    # Keep public receipts readable without expanding hundreds of closure rows.
    if depth >= 2 or not isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
    if isinstance(value, dict):
        rows = ['  '*(depth+1)+json.dumps(k)+': '+render(v, depth+1) for k,v in value.items()]
        return '{\n'+',\n'.join(rows)+'\n'+'  '*depth+'}'
    return '[\n'+',\n'.join('  '*(depth+1)+render(v, depth+1) for v in value)+'\n'+'  '*depth+']'

def facts(value):
    ignored = {'cache_shared_backing_bytes','cache_live_requested_bytes','cache_peak_requested_bytes',
               'cache_requested_byte_limit','cache_metadata_requested_bytes','cache_retained_output_backing_bytes'}
    if isinstance(value, list): return [facts(x) for x in value]
    if isinstance(value, dict):
        return {k:facts(v) for k,v in value.items() if k not in ignored and
                not any(x in k for x in ('seconds','per_second','capture','replay','trace_name'))}
    return value

def checked_run(name):
    out = W/'runs'/name
    result = read(out/'result.json')
    process = result.get('process', result)
    assert process['exit'] == 0, (name, process)
    if 'report' in result: exact(result['report'])
    return read(out/'report.json'), {'name':name, 'process':process, 'report':pin(out/'report.json')}

def artifact(ready, name):
    return next(row for row in ready['artifacts'] if row['name'] == name)['image']

def main():
    assert not any(path.exists() for path in (CORRECT, ZIP, PERF)), 'Do not overwrite published receipts'
    ready7, ready4, ready6 = (read(W/f'ready{x}.json') for x in (7,4,6))
    assert [x['name'] for x in ready7['compiled']] == ['model4','probe7','resources2']
    for unit in ready7['compiled']:
        for key in ('source','snapshot','object','dependencies'): exact(unit[key])
        assert unit['source']['sha256'] == unit['snapshot']['sha256'] and unit['process']['exit'] == 0
        for dependency in read(unit['dependencies']['path']): exact(dependency)
    for built in ready7['artifacts']:
        exact(built['image']); exact(built['inputs']); assert built['process']['exit'] == 0
    exact(ready7['runtime'])
    tiny, tiny_run = checked_run('probe7')
    real, real_run = checked_run('probe-real7')
    for report, count, prompt in ((tiny,8,3),(real,10,154)):
        assert report['status']=='PASS' and report['serial_and_relay_arms']==count and report['prompt_tokens']==prompt
        assert report['complete_state_equal'] and report['final_live_versions']==0
        assert all(report[key] for key in ('credit1','credit2','pause_resume','extra_stop','after_submit_cancel'))
        assert not report['model_eos_run'] and not report['unknown_capture_tuple_run']
    assert not tiny['late_extra_stop_run'] and real['late_extra_stop_run']
    late=real['continuations'][-1]
    assert (late['successor_submissions'],late['successor_publications'],late['successor_discards'],late['successor_refusals'])==(1,0,1,0)
    long_report, long_run = checked_run('final-long')
    assert (long_report['generated_tokens'],long_report['generated_decode_tokens'],long_report['logical_prompt_tokens'])==(97,96,154)
    assert long_report['live_committed_versions']==0 and long_report['overlap_successor_submissions']==44
    assert long_report['overlap_successor_publications']==44 and long_report['overlap_successor_discards']==long_report['overlap_successor_refusals']==0
    oracle=read(W/'screen-oracle.json')
    assert facts(long_report['sessions'][0]['result'])==oracle
    regressions=[]
    for backend in ('cpu','cuda'):
        for kind in ('ordinary','mtp-k3'):
            name=f'regression-{backend}-{kind}-b2'; report, record=checked_run(name)
            assert report['backend']==backend and report['session_count']==report['active_sequences']==2
            assert report['mtp']==(kind!='ordinary') and report['live_committed_versions']==0
            if report['mtp']: assert report['mtp_max_drafts']==3
            regressions.append(record)
    component=read(W/'component-written-prefix/summary.json')
    assert component['status']=='PASS' and component['test_count']==7 and component['process']['exit']==0
    exact(component['xml']); cases=ET.parse(component['xml']['path']).getroot().findall('./testsuite/testcase')
    assert len(cases)==7 and sorted(x.attrib['classname']+'.'+x.attrib['name'] for x in cases)==sorted(component['tests'])
    assert all(x.find('failure') is None and x.find('error') is None and x.find('skipped') is None for x in cases)
    skip=read(W/'runs/probe-no-input-final/result.json'); assert skip['exit']==skip['expected_exit']==77
    assert 'SKIP' in text('runs/probe-no-input-final/stderr.log')
    assert 'C4459' in text('logs/probe1/stdout.log')+text('logs/probe1/stderr.log')
    assert 'C4456' in text('logs/resources1/stdout.log')+text('logs/resources1/stderr.log')
    assert 'sampling cursor' in text('runs/probe1/stderr.log')
    assert 'resource append has no original registered prefix owner' in text('runs/real-auto/stderr.log')
    assert read(W/'component-written-prefix/prepare-attempt1.json')['status']=='RECIPE_PRECHECK_FAILED_BEFORE_LINK'
    assert (W/'runs/probe-no-input/attempt1.py').is_file()
    screen=read(W/'screen-summary.json'); assert screen['status']=='PASS' and len(screen['runs'])==6
    assert screen['image']==artifact(ready4,'cli') and screen['source_result_facts_equal']
    for row in screen['runs']:
        exact(row['report']); report=read(row['report']['path']); assert row['process']['exit']==0
        assert facts(report['sessions'][0]['result'])==oracle and report['generated_tokens']==97
        assert row['successor_publications']==(44 if row['mode']=='auto' else 0)
    diag=read(W/'diag/run-summary.json'); analysis=read(W/'diag/analysis-summary.json')
    assert diag['status']=='PASS' and diag['processes']==2
    for row in diag['runs']:
        assert row['process']['exit']==0 and row['complete_97_ids_and_original_screen_facts_equal']
        exact(row['report']); exact(row['diagnostic'])
    failures=[
        'probe1 C4459: initial C++ fixture warning; retained command/source/log; corrected without lowering /WX.',
        'first probe runtime: disabled greedy sampler cursor fixture mismatch; original state/ledger oracle retained after correcting fixture.',
        'resources1 C4456: local extra name shadow; renamed page_binding, no permission gate relaxation.',
        'real-auto P154 first decode: registered extra old-page guards had Projected scope instead of WrittenProjection; exact original tail owner rejected; registration fixed.',
        'component prepare attempt1: reusable scratch module W assertion before linker; script snapshot/error retained; first actual link succeeded.',
        'no-input attempt1: missing runtime PATH caused timeout; root killed PID 57708; incomplete raw attempt retained. Final image6 runtime-correct invocation returned 77.'
    ]
    images={'final_cli':artifact(ready7,'cli'),'final_probe':artifact(ready7,'probe'),
            'screen_and_four_cli_regressions':artifact(ready4,'cli'),
            'no_input_skip':artifact(ready6,'probe'),'component':read(W/'component-written-prefix/ready.json')['image'],
            'diagnostic':read(W/'diag/ready.json')['image']}
    # Old shared bin paths were overwritten. Their historical pins are as-run
    # facts from ready manifests, never rehashed as if they were current files.
    correctness={
        'schema':1,'status':'PASS_FINITE_SCOPE','date':'2026-10-27','base_head':'3b31490b6',
        'scope':'Ordinary CUDA R1 greedy RequestLoop D2 quantum, original token/Store/KV Sources and ordered ledger publication; not complete inference functionality or sustained multi-member pipeline.',
        'implemented':['Cold three physical carriers with D2 candidate budget; actual credit before B; A commit and observation before deferred B ledger bind.',
                       'Ready Source release on credit pause, real cancellation and extra-stop handling; accepted B can retire unpublished without stopping the continuing Session.',
                       'Written projection registers every original page guard with its exact writer scope; removed redundant engine A capture-reuse query, B actual qualification unchanged.'],
        'final_sources':[dict(name=x['name'],source=x['source'],snapshot=x['snapshot'],object=x['object'],dependencies=x['dependencies']) for x in ready7['compiled']],
        'actual_images':images,'final_model_checks':[dict(**tiny_run,arms=8,prompt=3),dict(**real_run,arms=10,prompt=154,late_stop=late),dict(**long_run,outputs=97,pairs=44,non_time_facts_equal=True)],
        'adjacent_checks':{'four_cli_regressions_image4':regressions,'component_7':component,'no_input_skip_image6':skip},
        'preserved_failures':failures,
        'verification_boundaries':['Tiny is an untrained fixture; real model checks use cached Qwen3.5-2B weights; no model or SDK downloads/rebuilds.',
            'Late extra stop is a real request-policy stop, not actual model EOS. No new natural cold-tuple miss, native-fault, Apple/Vulkan, sampling, pending MTP or multi-member continuous-pipeline proof.',
            'Functional final7 removes A query; six throughput screen processes used earlier image4. Diagnostic image is separately instrumented and is not a throughput update.',
            'Historical image pins remain valid as-run records although shared bin paths now contain later images. Full closure/dependency hashes are in ZIP, not expanded here.'],
        'archive':None}
    metrics={}
    for metric in ('prefill','decode','total','ready_seconds','shared_backing_bytes'):
        bymode={mode:[row[metric] for row in screen['runs'] if row['mode']==mode] for mode in ('off','auto')}
        metrics[metric]={mode:{'median':statistics.median(xs),'min':min(xs),'max':max(xs)} for mode,xs in bymode.items()}
        metrics[metric]['auto_vs_off_percent']=(statistics.median(bymode['auto'])/statistics.median(bymode['off'])-1)*100
    performance={'schema':1,'status':'SCREEN_ONLY_NO_SPEEDUP_CLAIM','date':'2026-10-27','base_head':'3b31490b6',
        'scope':'Six interleaved same-image ordinary R1 P154 + 96 decode processes, off/auto/auto/off/off/auto; cached real Qwen3.5-2B. No peer or MTP performance run.',
        'actual_screen_image':screen['image'],'final_functional_image':artifact(ready7,'cli'),
        'screen_runs':screen['runs'],'metrics':metrics,'complete_97_id_and_non_time_result_facts_equal':True,
        'diagnostic':{'image':images['diagnostic'],'processes':diag['runs'],'analysis':analysis,
            'interpretation':'Serialized host-call wall durations; waits are blocking wall, not CPU busy or GPU execution. Nested metrics are excluded from the selected sum. Buckets are observed ordinals, not matched 44-pair cohorts. No TPS refresh.'},
        'limitations':['Three samples per mode, overlapping ranges; no statistical-significance or net speedup claim.',
            'Backing bytes are shared logical pools, not sampled total VRAM peak. No separate memory-peak process.',
            'Model4 removed A query after this screen; no new complete throughput window for that deletion. final-long7 validates functional facts only.',
            'decode-overlap defaults off. No older peer window is merged or refreshed.'],'archive':None}
    allowed={'.json','.py','.ps1','.log','.xml','.cc','.h','.md','.txt','.diff','.patch'}
    files={}
    for path in sorted(W.rglob('*')):
        if path.is_file() and path.suffix.lower() in allowed and path.name not in ('running.json','screen-partial.json'):
            assert not any(part in ('__pycache__','bin') for part in path.relative_to(W).parts)
            files['scratch/'+path.relative_to(W).as_posix()]=path.read_bytes()
    # CMake registration is cold source evidence, not another executed consumer.
    files['source/current-tests-CMakeLists.txt']=(R/'tests/CMakeLists.txt').read_bytes()
    members=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())]
    files['manifest.json']=(render({'members':members,'exclusions':'No EXE/OBJ/PDB/DLL/LIB, SDK files, model payloads or copied caches. Metadata may reference those original identities.'})+'\n').encode('utf-8')
    ZIP.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(files.items()): archive.writestr(name,data)
    with zipfile.ZipFile(ZIP) as archive:
        assert archive.testzip() is None and set(archive.namelist())==set(files)
        archived=read_manifest=json.loads(archive.read('manifest.json'))['members']
        assert archived==members
        for row in archived:
            data=archive.read(row['path']); assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    archive_pin=pin(ZIP); archive_pin['path']=ZIP.relative_to(R).as_posix()
    correctness['archive']=performance['archive']=archive_pin
    for path,receipt in ((CORRECT,correctness),(PERF,performance)):
        path.parent.mkdir(parents=True,exist_ok=True); path.write_text(render(receipt)+'\n',encoding='utf-8')
        assert read(path)==receipt
    print(json.dumps({'correctness':pin(CORRECT),'archive':pin(ZIP),'performance':pin(PERF),'members':len(members)},indent=2))

if __name__=='__main__': main()
