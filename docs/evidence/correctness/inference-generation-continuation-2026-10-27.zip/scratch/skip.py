from pathlib import Path
import subprocess,time,json,importlib.util,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;out=W/'runs/probe-no-input-final'
s=importlib.util.spec_from_file_location('skip_build',W/'build.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
out.mkdir(parents=True,exist_ok=False)
command=[str(W/'bin/qwen-generation-relay-probe.exe')]
start=time.perf_counter()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    child=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=m.env())
    try:code=child.wait(timeout=30)
    except subprocess.TimeoutExpired:
        child.kill();child.wait();raise
result=dict(command=command,pid=child.pid,exit=code,expected_exit=77,
            seconds=time.perf_counter()-start)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert code==77,result
print(json.dumps(result))
