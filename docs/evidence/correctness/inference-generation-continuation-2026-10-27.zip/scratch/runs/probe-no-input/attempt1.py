from pathlib import Path
import subprocess,time,json
W=Path(__file__).resolve().parent;out=W/'runs/probe-no-input'
out.mkdir(parents=True,exist_ok=False)
command=[str(W/'bin/qwen-generation-relay-probe.exe')]
start=time.perf_counter()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    child=subprocess.Popen(command,stdout=stdout,stderr=stderr)
    code=child.wait(timeout=30)
result=dict(command=command,pid=child.pid,exit=code,expected_exit=77,
            seconds=time.perf_counter()-start)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert code==77,result
print(json.dumps(result))
