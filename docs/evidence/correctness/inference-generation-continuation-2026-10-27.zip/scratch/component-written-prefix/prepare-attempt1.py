from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
BASE = R/'.scratch/inference-deferred-source-bind-20261027/attempt-final'
CURRENT = W.parent
spec = importlib.util.spec_from_file_location('component_reuse', R/'.scratch/inference-deferred-source-bind-20261027/build.py')
reuse = importlib.util.module_from_spec(spec); spec.loader.exec_module(reuse)
m, h, exact = reuse.m, reuse.h, reuse.exact

def environment():
    env = dict(os.environ)
    env.update(m.read(BASE/'environment.json'))
    env['PATH'] = str(W/'bin')+os.pathsep+m.read(BASE/'runtime.json')['PATH']
    for key in ('HF_HUB_OFFLINE','HF_DATASETS_OFFLINE','TRANSFORMERS_OFFLINE'): env[key]='1'
    return env

def link():
    assert not (W/'plan.json').exists(), 'Do not overwrite this link attempt'
    rows = m.read(BASE/'test-link-inputs.json'); assert len(rows)==239
    selected = m.index(rows)
    old = selected[m.key(R/'src/graph/resources.cc')]
    compiled = m.read(CURRENT/'compile/resources2/compiled.json')
    assert compiled['source']['sha256']=='703608119f4d863a3f5e5a122daf98fde862a0261731285206541faf3670da26'
    assert compiled['object']['sha256']=='fdc6516749cebb44e617e2acb05b08e372aca7de451720c13dfcf4d98e95e914'
    dep, data = m.dependency(compiled['object'])
    assert m.key(data['Source'])==m.key(R/'src/graph/resources.cc')
    for pin in (compiled['source'],compiled['snapshot'],compiled['object'],compiled['dependencies']): exact(pin)
    for row in rows: exact(row)
    command = m.read(BASE/'link/command.json')['command']
    assert sum(m.key(arg)==m.key(old['object']['path']) for arg in command)==1
    image = W/'bin/written-prefix-component-test.exe'
    replacement = {m.key(old['object']['path']):compiled['object']['path']}
    command = m.link_command(command,replacement,[],image)
    for arg in command:
        if arg.lower().startswith(('/out:','/pdb:','/implib:')):
            assert Path(arg.split(':',1)[1]).resolve().is_relative_to(W)
    inputs = [compiled['object'] if m.key(row['path']) in replacement else row for row in rows]
    tests = m.read(BASE/'plan.json')['tests']; assert len(tests)==len(set(tests))==7
    (W/'bin').mkdir()
    runtime = m.read(BASE/'runtime.json'); exact(runtime['original_native_cpu'])
    alias = W/'bin'/Path(runtime['original_native_cpu']['path']).name
    os.link(runtime['original_native_cpu']['path'],alias)
    env=environment()
    m.save(W/'environment.json',{key:env.get(key,'') for key in ('PATH','INCLUDE','LIB','LIBPATH')})
    m.save(W/'runtime.json',dict(original=m.pin(BASE/'runtime.json'),PATH=env['PATH'],original_native_cpu=runtime['original_native_cpu'],alias=m.pin(alias),action='Existing CPU DLL hardlink only; no SDK copy'))
    m.save(W/'test-link-inputs.json',inputs)
    m.save(W/'plan.json',dict(status='LINK_PLANNED_GPU_NOT_RUN',baseline=m.pin(BASE/'test-link-inputs.json'),baseline_ready=m.pin(BASE/'ready.json'),replacement=dict(old=old['object'],old_dependencies=old['dependencies'],new=compiled,compiler_dependencies=m.pin(dep),command=m.pin(CURRENT/'logs/resources2/command.json')),tests=tests,counts=dict(CXX=0,link=1,inputs=239,SDK=0,NVCC=0,downloads=0),source_abi='Only resources.cc registration scope/writer_step assignment changed; no headers or layout change'))
    run_command=[str(image),'--gtest_color=no','--gtest_filter='+':'.join(tests),'--gtest_output=xml:'+str(W/'run/results.xml')]
    m.save(W/'run-command.json',dict(command=run_command,cwd=str(R),timeout_seconds=180,status='PREPARED_NOT_EXECUTED'))
    process=h.execute(command,env,W/'link',timeout=180)
    for row in inputs: exact(row)
    ready=dict(status='LINKED_GPU_NOT_RUN',image=m.pin(image),link=process,plan=m.pin(W/'plan.json'),inputs=m.pin(W/'test-link-inputs.json'),runtime=m.pin(W/'runtime.json'),run_command=m.pin(W/'run-command.json'))
    m.save(W/'ready.json',ready)
    print(json.dumps(ready,indent=2),flush=True)

def run():
    ready=m.read(W/'ready.json'); exact(ready['image'])
    for row in m.read(W/'test-link-inputs.json'): exact(row)
    command=m.read(W/'run-command.json')
    process=h.execute(command['command'],environment(),W/'run',timeout=180)
    xml=W/'run/results.xml'; root=ET.parse(xml).getroot(); cases=root.findall('./testsuite/testcase')
    tests=m.read(W/'plan.json')['tests']
    actual=[case.attrib['classname']+'.'+case.attrib['name'] for case in cases]
    assert sorted(actual)==sorted(tests) and len(cases)==7
    assert all(case.find('failure') is None and case.find('error') is None and case.find('skipped') is None for case in cases)
    m.save(W/'summary.json',dict(status='PASS',process=process,tests=actual,test_count=7,xml=m.pin(xml),ready=m.pin(W/'ready.json')))
    print(json.dumps(m.read(W/'summary.json'),indent=2),flush=True)

if __name__=='__main__':
    assert len(sys.argv)==2 and sys.argv[1] in ('link','run')
    {'link':link,'run':run}[sys.argv[1]]()
