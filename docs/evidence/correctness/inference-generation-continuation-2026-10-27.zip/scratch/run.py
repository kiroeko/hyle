from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
s=importlib.util.spec_from_file_location('current_build',W/'build.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
b,h=m.b,m.h
def run(name,command,timeout=180):
    out=W/'runs'/name
    record=h.execute(command,m.env(),out,timeout=timeout)
    report=json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'))
    b.save(out/'report.json',report)
    b.save(out/'result.json',dict(process=record,report=b.pin(out/'report.json')))
    print('RESULT '+name+' '+json.dumps(report if 'status' in report else {k:report.get(k) for k in [
        'decode_overlap','decode_overlap_available','overlap_successor_submissions',
        'overlap_successor_publications','overlap_successor_refusals','generated_tokens',
        'decode_tokens_per_second','session_seconds','live_committed_versions']}),flush=True)
    return report
ready=b.read(W/('ready'+(sys.argv[2] if len(sys.argv)>2 else '2')+'.json'))
for artifact in ready['artifacts']:b.exact(artifact['image'])
kind=sys.argv[1]
tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
real=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
cli=str(W/'bin/hyle.exe')
if kind=='probe':
    run('probe'+sys.argv[2],[str(W/'bin/qwen-generation-relay-probe.exe'),'--cuda',str(tiny)])
elif kind=='probe-real':
    run('probe-real'+sys.argv[2],[str(W/'bin/qwen-generation-relay-probe.exe'),'--cuda',str(real)])
elif kind=='tiny':
    for mode in ['off','auto']:
        run('tiny'+sys.argv[2]+'-'+mode,[cli,'--inputs',str(tiny),'--backend','cuda','--mtp','off',
            '--capacity','16','--steps','12','--max-sessions','1','--active-sequences','1',
            '--decode-overlap',mode])
elif kind=='real':
    for mode in ['off','auto']:
        run('real'+sys.argv[2]+'-'+mode,[cli,'--inputs',str(real),'--backend','cuda','--mtp','off',
            '--capacity','256','--steps','14','--max-sessions','1','--active-sequences','1',
            '--decode-overlap',mode])
elif kind=='default':
    report=run('final-default',[cli,'--inputs',str(real),'--backend','cuda','--mtp','off',
        '--capacity','256','--steps','14','--max-sessions','1','--active-sequences','1'])
    assert not report['decode_overlap'] and not report['overlap_successor_submissions']
    assert report['generated_tokens']==14 and report['live_committed_versions']==0
elif kind=='final-long':
    report=run('final-long',[cli,'--inputs',str(real),'--backend','cuda','--mtp','off',
        '--capacity','256','--steps','97','--max-sessions','1','--active-sequences','1',
        '--decode-overlap','auto'])
    ignored={'cache_shared_backing_bytes','cache_live_requested_bytes','cache_peak_requested_bytes',
        'cache_requested_byte_limit','cache_metadata_requested_bytes','cache_retained_output_backing_bytes'}
    def facts(value):
        if isinstance(value,list):return [facts(x) for x in value]
        if isinstance(value,dict):return {k:facts(v) for k,v in value.items() if k not in ignored and
            not any(x in k for x in ['seconds','per_second','capture','replay','trace_name'])}
        return value
    assert facts(report['sessions'][0]['result'])==b.read(W/'screen-oracle.json')
    assert report['generated_tokens']==97 and report['live_committed_versions']==0
    assert report['overlap_successor_submissions']==report['overlap_successor_publications']==44
    assert report['overlap_successor_discards']==report['overlap_successor_refusals']==0
elif kind=='regression':
    rows=b.read(R/'.scratch/inference-metadata-queue-20261027/run-plan.json')['cli']
    for row in rows:
        command=row['command'][:];command[0]=cli
        actual=run('regression-'+row['name'],command,row['timeout_seconds'])
        prior=b.read(R/'.scratch/inference-model-successor-20261027/cli4'/row['name']/'report.json')
        for key in ['backend','mtp','session_count','admitted_requests','retired_requests',
                    'live_committed_versions','generated_tokens','requested_output_tokens']:
            assert actual[key]==prior[key],(row['name'],key)
        assert [(x['session_id'],x['result']['generated_ids']) for x in actual['sessions']]==[
            (x['session_id'],x['result']['generated_ids']) for x in prior['sessions']]
else:raise ValueError(kind)
