from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-model-successor-20261027'
s=importlib.util.spec_from_file_location('previous_build',BASE/'build.py')
p=importlib.util.module_from_spec(s);s.loader.exec_module(p)
b,h=p.b,p.h
def env():
    result=p.p.environment('cli');seen=set();paths=[]
    for value in [str(W/'bin'),*b.read(BASE/'runtime.json')['PATH'].split(';')]:
        if value and value.casefold() not in seen:seen.add(value.casefold());paths.append(value)
    result['PATH']=';'.join(paths)
    return result
def compile_unit(kind,attempt):
    name=kind+attempt;out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
    if kind=='resources':
        previous=R/'.scratch/inference-deferred-source-bind-20261027'
        prior_out=previous/'compile/resources'
        source=old_source=R/'src/graph/resources.cc'
        recipe=previous/'logs/resources/command.json'
    else:
        prior='model4' if kind=='model' else 'probe5'
        prior_out=BASE/'compile'/prior
        source=R/('engine/models/qwen35/main.cc' if kind=='model' else 'tests/tools/qwen_generation_relay_probe.cc')
        old_source=R/('engine/models/qwen35/main.cc' if kind=='model' else 'tests/tools/qwen_submission_source_probe.cc')
        recipe=BASE/'logs'/prior/'command.json'
    command=b.read(recipe)['command']
    command=[x.replace(str(prior_out),str(out)).replace(str(old_source),str(source)) for x in command]
    frozen=b.pin(source);snapshot=W/'source'/name/source.name;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(source.read_bytes())
    process=h.execute(command,env(),W/'logs'/name,timeout=180)
    b.exact(frozen)
    deps=b.read(out/'dependencies.json')['Data']
    inputs=[b.pin(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]
    b.save(out/'actual-dependencies.json',inputs)
    record=dict(name=name,source=frozen,snapshot=b.pin(snapshot),object=b.pin(out/'unit.obj'),process=process,dependencies=b.pin(out/'actual-dependencies.json'))
    b.save(out/'compiled.json',record);print('COMPILED '+name,flush=True)
def link(attempt,model_attempt=None,probe_attempt=None,resources_attempt=None):
    units=[b.read(W/'compile'/(name+version)/'compiled.json') for name,version in
           [('model',model_attempt or attempt),('probe',probe_attempt or attempt)]]
    replacements={b.key(BASE/'compile/model4/unit.obj'):units[0]['object']['path'],
                  b.key(BASE/'compile/probe5/unit.obj'):units[1]['object']['path']}
    if resources_attempt:
        units.append(b.read(W/'compile'/('resources'+resources_attempt)/'compiled.json'))
        replacements[b.key(R/'.scratch/inference-deferred-source-bind-20261027/compile/resources/unit.obj')]=units[-1]['object']['path']
    (W/'bin').mkdir(parents=True,exist_ok=True)
    runtime=b.read(BASE/'runtime.json');dll=Path(runtime['native_cpu']['path']);b.exact(runtime['native_cpu'])
    alias=W/'bin'/dll.name
    if not alias.exists():os.link(dll,alias)
    runtime['PATH']=env()['PATH'];runtime['native_cpu_hardlink']=b.pin(alias);b.save(W/'runtime.json',runtime)
    artifacts=[]
    for name,exe in [('cli','hyle.exe'),('probe','qwen-generation-relay-probe.exe')]:
        for unit in units:b.exact(unit['source']);b.exact(unit['object'])
        inputs=[b.pin(replacements[b.key(x['path'])]) if b.key(x['path']) in replacements else x for x in b.read(BASE/(name+'-link-inputs.json'))]
        for row in inputs:b.exact(row)
        b.save(W/(name+'-link-inputs'+attempt+'.json'),inputs)
        command=b.read(BASE/('link-'+name+'4')/'command.json')['command']
        image=W/'bin'/exe
        command=[replacements.get(b.key(x),'/OUT:'+str(image) if x.upper().startswith('/OUT:') else x) for x in command]
        process=h.execute(command,env(),W/('link-'+name+attempt),timeout=120)
        artifacts.append(dict(name=name,image=b.pin(image),process=process,inputs=b.pin(W/(name+'-link-inputs'+attempt+'.json'))))
    b.save(W/('ready'+attempt+'.json'),dict(compiled=units,artifacts=artifacts,runtime=b.pin(W/'runtime.json')))
    print('READY '+attempt,flush=True)
if __name__=='__main__':
    if sys.argv[1] in ['model','probe','resources']:compile_unit(sys.argv[1],sys.argv[2])
    elif sys.argv[1]=='link':link(sys.argv[2],*sys.argv[3:])
    else:raise ValueError(sys.argv[1])
