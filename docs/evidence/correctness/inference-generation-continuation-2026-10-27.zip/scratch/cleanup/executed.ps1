param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$prefix = $workspace.TrimEnd('\') + '\'
$targets = @(
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\model1\unit.obj'; bytes = 16377345; sha256 = 'f167ab443f7898ed8dece4a63970c341789cfd132c4de9f15c22b47f0d119b2e' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\model2\unit.obj'; bytes = 16397169; sha256 = '4562d5b1e260475c6f7378ec3796f1057e7f2fe7ee52ab362a8f2fbbdef79440' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\probe2\unit.obj'; bytes = 17302991; sha256 = 'a70dc5e3b14f97ce4d80d0cfaa46a11cd7c2ca30e5c84c3b23051bdc6b97ec33' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\probe3\unit.obj'; bytes = 17302975; sha256 = 'e3845f955816a5e9685877c374cedb89e7968af9f42adce065d9e4c12c3e1c74' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\probe4\unit.obj'; bytes = 17323288; sha256 = '443de0c84ca3002a7b6cd179ea5f53433aaf5f22e897d64c4ac78d46118d0a51' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\probe5\unit.obj'; bytes = 17325285; sha256 = '1e180ba888b4c0211c05fe1d2bb6bb49f478262427a6e6b426b391a13c0439d4' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\probe6\unit.obj'; bytes = 17345093; sha256 = '125586c437db2fe9392323f78ed35f0aba216b5c0f57e45f86e8339fbf8af8f2' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\component-written-prefix\bin\written-prefix-component-test.exe'; bytes = 146671616; sha256 = 'cdf553455310c199a06be3642096c0e24834da17a993b9293f60286bdb74d8ff' }
)
$kept = @(
    @{ relative = '.scratch\inference-generation-continuation-20261027\bin\hyle.exe'; bytes = 142405120; sha256 = '418412657e61cd6a1ee1dc370bde8e68bacfd4f9229f9f22308739bcc8f2c04d' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\bin\qwen-generation-relay-probe.exe'; bytes = 142155264; sha256 = 'a875c9ce240e0d74dc06e4710a1857ddb80f976915bdd6b033cde66d07c589f3' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\diag\bin\hyle-relay-diag.exe'; bytes = 142415872; sha256 = '9ed9f369ed2086ef3e832115aceb44edfc471c568d56d6e1a3e4220979910146' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\model3\unit.obj'; bytes = 16397169; sha256 = '4541cd43397668c450e73111d26adc5575a83828dea52b1a7b25854845c908a8' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\model4\unit.obj'; bytes = 16396412; sha256 = '8168de484bfccc17ce286c66728162f4436de9b48af279d132131978cef206e5' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\probe7\unit.obj'; bytes = 17344210; sha256 = '2967667144b9d25a67d5f8b7528702edbcb753f493c9a348423b129884d45c8f' }
    @{ relative = '.scratch\inference-generation-continuation-20261027\compile\resources2\unit.obj'; bytes = 3095610; sha256 = 'fdc6516749cebb44e617e2acb05b08e372aca7de451720c13dfcf4d98e95e914' }
)
$checked = foreach ($item in @($targets) + @($kept)) {
    $path = [IO.Path]::GetFullPath((Join-Path $workspace $item.relative))
    if (-not $path.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped workspace' }
    $file = Get-Item -LiteralPath $path
    if ($file.PSIsContainer -or $file.Length -ne $item.bytes) { throw "File identity changed: $path" }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "Hash changed: $path" }
}
$deleted = @($targets | ForEach-Object { [ordered]@{path = [IO.Path]::GetFullPath((Join-Path $workspace $_.relative)); bytes = $_.bytes; sha256 = $_.sha256} })
$result = [ordered]@{action = 'preview'; targets = $deleted; kept = $kept; bytes = ($targets | Measure-Object -Property bytes -Sum).Sum}
$receipt = Join-Path $workspace '.scratch\inference-generation-continuation-20261027\cleanup'
New-Item -ItemType Directory -Path $receipt -Force | Out-Null
if ($Execute) {
    foreach ($item in $deleted) { Remove-Item -LiteralPath $item.path -Force }
    $result.action = 'deleted'
    Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $receipt 'executed.ps1')
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $receipt ($result.action + '.json')) -Encoding UTF8
$result | ConvertTo-Json -Depth 6
