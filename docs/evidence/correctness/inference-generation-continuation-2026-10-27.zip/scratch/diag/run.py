from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
W = D.parent
spec = importlib.util.spec_from_file_location('original_build', W / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, h = m.b, m.h

# Exactly the original screen.py single-request fact normalization.
ignored = {'cache_shared_backing_bytes', 'cache_live_requested_bytes', 'cache_peak_requested_bytes',
 'cache_requested_byte_limit', 'cache_metadata_requested_bytes', 'cache_retained_output_backing_bytes'}


def facts(value):
    if isinstance(value, list): return [facts(x) for x in value]
    if isinstance(value, dict):
        return {k: facts(v) for k, v in value.items() if k not in ignored and
                not any(x in k for x in ['seconds', 'per_second', 'capture', 'replay', 'trace_name'])}
    return value


ready = b.read(D / 'ready.json')
plan = b.read(D / 'run-plan.json')
oracle = b.read(plan['oracle']['path'])
rows = []
for run in plan['runs']:
    for pin in [ready['image'], ready['object'], ready['source'], ready['header'], plan['oracle']]:
        b.exact(pin)
    out = Path(run['output_directory'])
    assert not out.exists(), out
    process = h.execute(run['command'], m.env(), out, timeout=run['timeout_seconds'])
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
    b.save(out / 'report.json', report)
    actual = facts(report['sessions'][0]['result'])
    if actual != oracle:
        changed = [key for key in actual if actual[key] != oracle.get(key)]
        b.save(out / 'fact-mismatch.json', dict(keys=changed, actual=actual, expected=oracle))
        raise AssertionError(('complete screen facts changed', run['mode'], changed))
    assert len(report['sessions'][0]['result']['generated_ids']) == report['generated_tokens'] == 97
    assert report['generated_decode_tokens'] == 96 and report['live_committed_versions'] == 0
    assert report['overlap_successor_refusals'] == report['overlap_successor_discards'] == 0
    expected = 44 if run['mode'] == 'auto' else 0
    assert report['overlap_successor_submissions'] == report['overlap_successor_publications'] == expected
    lines = [line[len('RELAY_DIAG '):] for line in (out / 'stderr.log').read_text(
        encoding='utf8', errors='replace').splitlines() if line.startswith('RELAY_DIAG ')]
    assert len(lines) == 1, len(lines)
    diagnostic = json.loads(lines[0])
    assert diagnostic['prepared_decode_steps'] == 96
    assert sum(x['episodes'] for x in diagnostic['buckets']) == 96
    assert sum(x['completed'] for x in diagnostic['buckets']) == 96
    b.save(out / 'diagnostic.json', diagnostic)
    row = dict(mode=run['mode'], process=process, image=ready['image'],
        report=b.pin(out / 'report.json'), diagnostic=b.pin(out / 'diagnostic.json'),
        complete_97_ids_and_original_screen_facts_equal=True,
        scope='Diagnostic host-call wall only; nested metrics are not additive, wait is not CPU busy time, no formal TPS update.')
    b.save(out / 'summary.json', row)
    rows.append(row)
    b.save(D / 'runs-partial.json', rows)
    print('PASS diagnostic ' + run['mode'], flush=True)
b.save(D / 'run-summary.json', dict(status='PASS', runs=rows, processes=2,
    scope='One off and one auto, exclusive GPU, original P154+96 decode and complete97-token facts. No extra model/probe/performance processes.'))
