from pathlib import Path
import difflib
import importlib.util
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
W = D.parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('original_build', W / 'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, h = m.b, m.h


def prepare():
    ready = b.read(W / 'ready5.json')
    original = next(unit for unit in ready['compiled'] if unit['name'] == 'model3')
    for row in [original['snapshot'], original['object'], original['dependencies']]:
        b.exact(row)
    baseline = Path(original['snapshot']['path']).read_bytes()
    assert b.pin(R / 'engine/models/qwen35/main.cc')['sha256'] == original['source']['sha256']
    text = baseline.decode('utf8').replace('\r\n', '\n')
    before = text

    def replace(old, new):
        nonlocal text
        assert text.count(old) == 1, (old[:100], text.count(old))
        text = text.replace(old, new)

    replace('using Clock = std::chrono::steady_clock;\n',
            'using Clock = std::chrono::steady_clock;\n#include "relay_diag.h"\n')
    replace('struct StepState final {\n', 'struct StepState final {\n  relay_diag::Episode diagnostic;\n')
    replace('    step.step_start = step_start; step.input_tokens = tokens;\n',
            '    step.step_start = step_start; step.input_tokens = tokens;\n'
            '    step.diagnostic.active = requests.size() == 1 && tokens == 1 &&\n'
            '        role == GraphRole::kText && completion == TextCompletion::kEmitNext &&\n'
            '        candidate->members[0].base->length != 0;\n'
            '    if (step.diagnostic.active) step.diagnostic.ordinal = relay_diag::state.prepared++;\n')
    replace('      ++phase.preparation_uses[slot]; step.prepared = true;\n',
            '      ++phase.preparation_uses[slot]; step.prepared = true;\n'
            '      step.diagnostic.add(relay_diag::Metric::kPrepareTotal, step_start);\n'
            '      step.diagnostic.recorded = step.capture_recorded;\n'
            '      step.diagnostic.reused = step.capture_reused;\n')
    replace('  std::shared_ptr<StepSources> prepare_submission_sources(StepState &step) {\n',
            '  std::shared_ptr<StepSources> prepare_submission_sources(StepState &step) {\n'
            '    relay_diag::Timer diagnostic(step.diagnostic, relay_diag::Metric::kSourceMetadata);\n')
    replace('    step.completion = submit_retained(*step.run, queues, step.phase->retirement[step.state_slot], step.incoming.get());\n',
            '    { relay_diag::Timer diagnostic(step.diagnostic, relay_diag::Metric::kOriginalSubmit);\n'
            '      step.completion = submit_retained(*step.run, queues, step.phase->retirement[step.state_slot], step.incoming.get()); }\n')
    replace('      auto exported = g::detail::SubmissionSource::create(\n'
            '          *step.run, std::move(step.completion), execution.storage_owner());\n',
            '      auto exported = [&] {\n'
            '        relay_diag::Timer diagnostic(step.diagnostic, relay_diag::Metric::kWholeSource);\n'
            '        return g::detail::SubmissionSource::create(\n'
            '            *step.run, std::move(step.completion), execution.storage_owner());\n'
            '      }();\n')
    replace('        sources.token = take(g::detail::OutputSource::create(sources.submission,\n'
            '            step.phase->id_port, execution.storage_owner(), step.phase->io[step.state_slot].next_id.pool()));\n'
            '        for (auto &state : sources.states) check(state.capture(sources.submission));\n'
            '        for (auto &pages : sources.pages) check(pages.capture(sources.submission));\n',
            '        { relay_diag::Timer diagnostic(step.diagnostic, relay_diag::Metric::kTokenCapture);\n'
            '          sources.token = take(g::detail::OutputSource::create(sources.submission,\n'
            '              step.phase->id_port, execution.storage_owner(), step.phase->io[step.state_slot].next_id.pool())); }\n'
            '        { relay_diag::Timer diagnostic(step.diagnostic, relay_diag::Metric::kStoreCapture);\n'
            '          for (auto &state : sources.states) check(state.capture(sources.submission)); }\n'
            '        { relay_diag::Timer diagnostic(step.diagnostic, relay_diag::Metric::kKvCapture);\n'
            '          for (auto &pages : sources.pages) check(pages.capture(sources.submission)); }\n')
    replace('    const auto step_start = step.step_start, start = step.start;\n',
            '    relay_diag::FinishSample diagnostic_sample(step.diagnostic);\n'
            '    relay_diag::Timer diagnostic_finish(diagnostic_sample.episode, relay_diag::Metric::kFinishTotal);\n'
            '    const auto step_start = step.step_start, start = step.start;\n')
    replace('      check(step.wait()); step.completion = {};\n',
            '      { relay_diag::Timer diagnostic(diagnostic_sample.episode, relay_diag::Metric::kOriginalWait);\n'
            '        check(step.wait()); }\n'
            '      diagnostic_sample.post_wait = Clock::now();\n'
            '      step.completion = {};\n')
    replace('      // Export every participant\'s ordinary outputs before taking ANY append:\n',
            '      const auto diagnostic_publish_start = Clock::now();\n'
            '      // Export every participant\'s ordinary outputs before taking ANY append:\n')
    replace('      if (step.incoming) {\n'
            '        check(g::detail::release_outputs(run, step.incoming->bindings));\n'
            '        check(run.unbind(step.incoming->outside_inputs));\n'
            '        step.incoming.reset(); step.predecessor_episode.reset();\n'
            '      } else check(run.unbind(phase.state_resource_ports));\n',
            '      { relay_diag::Timer diagnostic(diagnostic_sample.episode, relay_diag::Metric::kReleaseInputs);\n'
            '        if (step.incoming) {\n'
            '          check(g::detail::release_outputs(run, step.incoming->bindings));\n'
            '          check(run.unbind(step.incoming->outside_inputs));\n'
            '          step.incoming.reset(); step.predecessor_episode.reset();\n'
            '        } else check(run.unbind(phase.state_resource_ports)); }\n')
    replace('      detach_episode(); // Old states/transactions retire inside the host endpoint.\n',
            '      detach_episode(); // Old states/transactions retire inside the host endpoint.\n'
            '      diagnostic_sample.episode.add(relay_diag::Metric::kPublishTakeCommit, diagnostic_publish_start);\n')
    replace('      observe(j, completed);\n    }\n  }\n\n  template<class Select, class Observe>\n',
            '      observe(j, completed);\n    }\n'
            '    diagnostic_sample.completed = true;\n'
            '  }\n\n  template<class Select, class Observe>\n')
    replace('void finish_generation_call(Model &model, PreparedGenerationCall &call) {\n',
            'void finish_generation_call(Model &model, PreparedGenerationCall &call) {\n'
            '  relay_diag::DirectTimer diagnostic(call.generation && call.role == GraphRole::kText,\n'
            '      relay_diag::Metric::kGenerationObserve);\n')
    replace('    auto &a = imported ? model.prepare_relay_evaluations(relay, continuation.ready, slot)\n'
            '        : (model.prepare_evaluations(direct, nullptr, call.role, call.completion), *model.active_step);\n',
            '    const auto diagnostic_prepare_a = Clock::now();\n'
            '    auto &a = imported ? model.prepare_relay_evaluations(relay, continuation.ready, slot)\n'
            '        : (model.prepare_evaluations(direct, nullptr, call.role, call.completion), *model.active_step);\n'
            '    a.diagnostic.add(imported ? relay_diag::Metric::kRelayPrepareCall : relay_diag::Metric::kDirectPrepareCall,\n'
            '        diagnostic_prepare_a);\n')
    replace('    const bool reusable = imported && take(g::detail::ReplayAccess::can_reuse_capture(*a.run, {}));\n',
            '    const auto diagnostic_reuse_query = Clock::now();\n'
            '    const bool reusable = imported && take(g::detail::ReplayAccess::can_reuse_capture(*a.run, {}));\n'
            '    if (imported) a.diagnostic.add(relay_diag::Metric::kHelperReuseQuery, diagnostic_reuse_query);\n')
    replace('      try { b = &model.prepare_relay_evaluations(relay, a_source, next_slot); }\n',
            '      const auto diagnostic_prepare_b = Clock::now();\n'
            '      try { b = &model.prepare_relay_evaluations(relay, a_source, next_slot);\n'
            '        b->diagnostic.add(relay_diag::Metric::kRelayPrepareCall, diagnostic_prepare_b); }\n')
    replace('        model.submit_evaluations(*b); submitted_second = true;\n',
            '        model.submit_evaluations(*b); submitted_second = true;\n'
            '        a.diagnostic.pair_role = 1; b->diagnostic.pair_role = 2;\n')
    replace('  model.prepare_evaluations(std::span(inputs.data(), inputs.size()), nullptr, role, calls[0].completion); model.submit_evaluations();\n',
            '  const auto diagnostic_prepare_direct = Clock::now();\n'
            '  model.prepare_evaluations(std::span(inputs.data(), inputs.size()), nullptr, role, calls[0].completion);\n'
            '  model.active_step->diagnostic.add(relay_diag::Metric::kDirectPrepareCall, diagnostic_prepare_direct);\n'
            '  model.submit_evaluations();\n')
    replace('int qwen35::run(int argc, char **argv) {\n',
            'int qwen35::run(int argc, char **argv) {\n'
            '  qwen35::relay_diag::Report diagnostic_report;\n')

    out = D / 'source/main.cc'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(text.encode('utf8'))
    (D / 'source/main.patch').write_text(''.join(difflib.unified_diff(
        before.splitlines(keepends=True), text.splitlines(keepends=True),
        fromfile='compiled-model3/main.cc', tofile='diag/source/main.cc')), encoding='utf8')
    b.save(D / 'source-identity.json', dict(original=original,
        diagnostic_source=b.pin(out), diagnostic_header=b.pin(D / 'source/relay_diag.h'),
        patch=b.pin(D / 'source/main.patch'), base_newline='CRLF normalized to LF only in scratch diagnostic source'))
    recipe = b.read(W / 'logs/model3/command.json')['command']
    previous = W / 'compile/model3'
    target = D / 'compile/model'
    command = [arg.replace(str(previous), str(target)) for arg in recipe]
    command = [str(out) if b.key(arg) == b.key(original['source']['path']) else arg for arg in command]
    command.insert(1, '/I' + str(R / 'engine/models/qwen35'))
    b.save(D / 'compile-recipe.json', dict(command=command,
        original=b.pin(W / 'logs/model3/command.json'), original_working_directory=str(R)))
    b.save(D / 'plan.json', dict(baseline=b.pin(W / 'ready5.json'),
        source=b.pin(out), header=b.pin(D / 'source/relay_diag.h'),
        original_model_object=original['object'], baseline_inputs=b.pin(W / 'cli-link-inputs5.json'),
        scope='1 scratch Model CXX + 1 CLI link; nonreentrant fixed metadata counters; no product/header/SDK changes or GPU run.'))
    print('PREPARED isolated diagnostic source and exact model3 recipe', flush=True)


def build():
    plan = b.read(D / 'plan.json')
    original = b.read(D / 'source-identity.json')['original']
    for row in [plan['source'], plan['header'], plan['original_model_object']]:
        b.exact(row)
    old_deps = b.read(original['dependencies']['path'])
    for row in old_deps:
        b.exact(row)
    out = D / 'compile/model'
    out.mkdir(parents=True, exist_ok=False)
    process = h.execute(b.read(D / 'compile-recipe.json')['command'], m.env(), D / 'logs/model', timeout=180)
    b.exact(plan['source']); b.exact(plan['header'])
    raw = b.read(out / 'dependencies.json')['Data']
    actual = [b.pin(path) for path in dict.fromkeys([raw['Source'], *raw['Includes']])]
    old = {b.key(row['path']): row for row in old_deps[1:]}
    for row in actual:
        key = b.key(row['path'])
        if key in old: assert row == old[key], row['path']
        else: assert key in {b.key(plan['source']['path']), b.key(plan['header']['path'])}, row['path']
    assert old.keys() <= {b.key(row['path']) for row in actual}
    b.save(out / 'actual-dependencies.json', actual)
    replacement = b.pin(out / 'unit.obj')
    b.save(out / 'compiled.json', dict(source=plan['source'], header=plan['header'], object=replacement,
        process=process, actual_dependencies=b.pin(out / 'actual-dependencies.json')))
    inputs = []
    replacements = 0
    for row in b.read(plan['baseline_inputs']['path']):
        if b.key(row['path']) == b.key(plan['original_model_object']['path']):
            row = replacement; replacements += 1
        b.exact(row); inputs.append(row)
    assert len(inputs) == 224 and replacements == 1
    b.save(D / 'link-inputs.json', inputs)
    image = D / 'bin/hyle-relay-diag.exe'
    image.parent.mkdir(parents=True, exist_ok=True)
    command = b.read(W / 'link-cli5/command.json')['command']
    command = [replacement['path'] if b.key(arg) == b.key(plan['original_model_object']['path'])
        else '/OUT:' + str(image) if arg.upper().startswith('/OUT:') else arg for arg in command]
    link = h.execute(command, m.env(), D / 'link', timeout=120)
    b.save(D / 'ready.json', dict(status='LINKED_NOT_RUN', image=b.pin(image), object=replacement,
        source=plan['source'], header=plan['header'], compiler_process=process, linker_process=link,
        baseline=b.pin(W / 'ready5.json'), original_object=plan['original_model_object'],
        inputs=b.pin(D / 'link-inputs.json'), actual_dependencies=b.pin(out / 'actual-dependencies.json'),
        compiler_attempts=1, links=1, model_or_gpu_runs=0))
    commands = []
    for mode in ['off', 'auto']:
        commands.append(dict(mode=mode, command=[str(image), '--inputs',
            str(R / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),
            '--backend', 'cuda', '--mtp', 'off', '--capacity', '256', '--steps', '97',
            '--max-sessions', '1', '--active-sequences', '1', '--decode-overlap', mode],
            output_directory=str(D / ('run-' + mode)), timeout_seconds=180,
            required_facts='97 exact generated IDs and complete non-time result facts equal original screen-oracle.json; decode96, no refusals/discards, final live versions0.'))
    b.save(D / 'run-plan.json', dict(runs=commands, runtime=b.pin(W / 'runtime.json'),
        environment_helper=str(W / 'build.py') + ':env()', oracle=b.pin(W / 'screen-oracle.json'),
        scope='Prepared commands only; not executed by this task. Diagnostic wall times include ordinary clock overhead; nested fields are not additive.'))
    print('READY: 1 diagnostic CXX + 1 link, 224 inputs, no GPU run', flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'prepare': prepare()
    elif sys.argv[1] == 'build': build()
    else: raise ValueError(sys.argv[1])
