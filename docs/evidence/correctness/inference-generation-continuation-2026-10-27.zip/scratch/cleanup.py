from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
s=importlib.util.spec_from_file_location('cleanup_build',W/'build.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
targets=[W/'compile'/name/'unit.obj' for name in ['model1','model2','probe2','probe3','probe4','probe5','probe6']]
targets.append(W/'component-written-prefix/bin/written-prefix-component-test.exe')
kept=[W/'bin/hyle.exe',W/'bin/qwen-generation-relay-probe.exe',W/'diag/bin/hyle-relay-diag.exe',
      *[W/'compile'/name/'unit.obj' for name in ['model3','model4','probe7','resources2']]]
rows=[m.b.pin(path) for path in targets];keep=[m.b.pin(path) for path in kept]
def table(values):
    return '\n'.join("    @{ relative = '"+str(Path(row['path']).relative_to(R))+"'; bytes = "+str(row['bytes'])+
        "; sha256 = '"+row['sha256']+"' }" for row in values)
template=(R/'test.ps1').read_text(encoding='utf-8-sig')
before,rest=template.split('$targets = @(\n',1)
_,rest=rest.split('\n)\n$kept = @(\n',1)
_,tail=rest.split('\n)\n$checked = ',1)
script=before+'$targets = @(\n'+table(rows)+'\n)\n$kept = @(\n'+table(keep)+'\n)\n$checked = '+tail
script=script.replace('.scratch\\inference-model-successor-20261027\\cleanup',
                      '.scratch\\inference-generation-continuation-20261027\\cleanup')
assert len(rows)==8 and not any(Path(x['path']).is_dir() for x in rows)
for row in rows+keep:assert Path(row['path']).is_relative_to(W)
(R/'test.ps1').write_text(script,encoding='utf-8')
print(json.dumps(dict(targets=rows,kept=keep,total_bytes=sum(x['bytes'] for x in rows)),indent=2))
