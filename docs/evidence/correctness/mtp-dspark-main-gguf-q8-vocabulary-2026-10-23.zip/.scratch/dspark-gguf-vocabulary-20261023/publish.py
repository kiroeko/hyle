"""Publish completed S02 Q8 vocabulary runs and one affected BF16 regression.

Root invocation after all three named runs really terminate successfully:
  python publish.py --q8-runs 10 11 --bfloat-run 12
Only metadata, source, command/log/XML evidence is archived; no weight-body
rehash, model download, compilation or native execution occurs here.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
CA = R / '.scratch/dspark-pro-target-draft-20261023'
spec = importlib.util.spec_from_file_location('_s02_metadata_helpers', CA / 'publish.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
REPO = 'unsloth/DeepSeek-V4-Flash-0731-GGUF'
REV = 'fbbb5b93fb787c21338159b0af3318bb3f4d9768'
Q8_SUFFIX = 'MainGgufQ8VocabularyAndOriginalTargetTailPublishesBlock5Prefix'
Q8_CASES = {('DSparkOriginalState', backend + Q8_SUFFIX) for backend in ('Cpu', 'Cuda')}
BFLOAT_CASE = ('DSparkFlashFormalState', 'CudaOriginalTargetTailAndFormalDraftPublishesBlock5Prefix')
PINS = {'output.weight': 'c82e956167ed86eb531493e0b4fa81083b38737b2fc51dabc1d65ce5d027de98',
        'token_embd.weight': '5eb1e3524b0eee207e3e120fbb89d1bf1dd2dce175f1f969d7bee383400c1d8a'}
MANIFEST_PIN = '7502444e1150da9b5e15e79ec68be087b81c6ad02146d74b9b03a08e465db1e0'
PLAN_PIN = '61938efb91d3080f011f6912f01c51fdead4e6f6198f92d011920d4c24e1940d'


def artifacts():
    folder = S / 'original-vocabulary'
    manifest_path, receipt_path = h.add(folder / 'manifest.json'), h.add(folder / 'acquisition.json')
    manifest, receipt = h.read(manifest_path), h.read(receipt_path)
    assert h.identity(manifest_path)['sha256'] == MANIFEST_PIN
    for record in (manifest, receipt):
        assert (record['repository'], record['revision'], record['variant'], record['original_roles']) == (REPO, REV, 'UD-Q4_K_XL', 2)
        assert record['complete'] is True
    assert manifest['source_bytes'] == receipt['expected_role_payload_bytes'] == 1125253120
    assert receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == 1125253120
    assert receipt['whole_shard_downloaded'] is False
    proposal_path = h.add(h.verify(receipt['source_plan']))
    assert h.identity(proposal_path)['sha256'] == PLAN_PIN
    proposal = h.read(proposal_path)
    header_path = h.add(h.verify(receipt['source_header']))
    header = h.read(header_path)
    assert header['http_status'] == 206 and header['range'] == [0, 26559] and header['tensor_payload_bytes'] == 0
    assert header['url'] == proposal['url'] and header['whole_file_bytes'] == 48935523072
    original_header = h.verify(header['header'])
    assert original_header.name == 'original-header.bin' and original_header.stat().st_size == 26560
    h.files.add(original_header)
    # Reuse the exact downloader's pure GGUF parser; never invoke its header()
    # acquisition routine or main(). Its complete414-tensor equality was also
    # checked by the actual root-owned acquisition against the pinned archive.
    spec = importlib.util.spec_from_file_location('_s02_header_parser', S / 'fetch.py')
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    _, tensors = parser.parse_header(original_header.read_bytes())
    rows = {row['name']: row for row in receipt['roles']}
    observed = {row['name']: row for row in manifest['roles']}
    expected = {row['name']: row for row in proposal['roles']}
    assert set(rows) == set(observed) == set(expected) == set(PINS)
    source = (R / 'tests/compute_models/dspark_gguf_vocabulary_roles.h').read_text()
    roles = []
    for name, pin in PINS.items():
        row, emitted, planned = rows[name], observed[name], expected[name]
        tensor = next(value for value in tensors if value['name'] == name)
        assert tensor['shape'] == [4096, 129280] and tensor['dtype_code'] == 8
        assert planned['absolute_inclusive'][0] == 26560 + tensor['offset']
        assert row['complete'] is True and row['dtype'] == emitted['dtype'] == 'Q8_0'
        assert row['shape'] == emitted['shape'] == [4096, 129280]
        assert row['bytes'] == emitted['bytes'] == planned['bytes'] == 562626560
        assert row['absolute_inclusive'] == planned['absolute_inclusive']
        assert row['etag'] == header['etag'] and row['whole_file_bytes'] == header['whole_file_bytes']
        payload = row['payload']
        assert payload['sha256'] == emitted['sha256'] == pin and pin in source
        assert emitted['file'] == row['filename'] == name + '.q8_0'
        assert h.resolve(payload['path']) == folder / emitted['file']
        assert h.resolve(payload['path']).stat().st_size == payload['bytes'] == row['bytes']
        requests = [request for request in receipt['requests'] if request.get('complete') and request['role'] == name]
        requests.sort(key=lambda request: request['first'])
        cursor = planned['absolute_inclusive'][0]
        for request in requests:
            assert request['http_status'] == 206 and request['first'] == cursor
            assert request['bytes'] == request['requested_bytes'] == request['last'] - request['first'] + 1
            assert request['etag'] == header['etag'] and re.fullmatch('[0-9a-f]{64}', request['sha256'])
            assert request['content_range'] == f"bytes {request['first']}-{request['last']}/{header['whole_file_bytes']}"
            cursor = request['last'] + 1
        assert cursor == planned['absolute_inclusive'][1] + 1
        roles.append(dict(name=name, **payload, body_rehashed=False, body_archived=False))
    return dict(repository=REPO, revision=REV, variant='UD-Q4_K_XL',
        file=proposal['file'], original_roles=2, source_bytes=1125253120,
        roles=roles, manifest=h.identity(manifest_path), acquisition=h.identity(receipt_path),
        header_receipt=h.identity(header_path), original_header=h.identity(original_header),
        source_plan=h.identity(proposal_path), skipped_non_vocabulary_gap_bytes=278592,
        tensor_payload_padding_downloaded=0, whole_shard_downloaded=False,
        storage='Two independent original Q8_0 banks,34bytes/32values. Head canonical[H,V], embedding transposed descriptor[V,H] over its own original bytes.')


def frozen_sources():
    path = h.add(S / 'source/freeze.json')
    frozen = h.read(path)
    assert len(frozen['sources']) == 8
    for row in frozen['sources']:
        h.add(h.verify(row))
    return dict(manifest=h.identity(path), sources=frozen['sources'])


def reused_evidence():
    result = {}
    for label, path in [('original_sidecar_and_target_tail', h.ANCHOR['path']),
                        ('formal_bfloat_flash', 'docs/evidence/correctness/mtp-dspark-formal-flash-2026-10-23.json')]:
        evidence = h.identity(path)
        previous = h.read(h.verify(evidence))
        h.verify(previous['archive'])
        result[label] = dict(evidence=evidence, archive=previous['archive'])
    return result


def completed_run(attempt, q8):
    folder = CA / f'checks{attempt}'
    summary_path = h.add(folder / 'summary.json')
    summary = h.read(summary_path)
    assert summary['process']['exit'] == 0 and not summary['process']['timed_out']
    assert summary['tests'] == len(summary['cases']) == 1
    assert not any(summary[key] for key in ('failures', 'errors', 'disabled', 'skips'))
    assert all(summary.get(key) is False for key in ('throughput_evidence', 'physical_memory_evidence', 'whole_original_model'))
    assert summary['source'] == ('flash-vocab-q8' if q8 else 'flash')
    linked = h.linked_image(summary['image'])
    assert h.resolve(summary['image']['path']).parent == CA / 'tests-link7'
    assert {h.resolve(item['record']['path']).parent.parent.name for item in linked['hosts']} == {'compile7'}
    command = summary['process']['command']
    driver_identity = None
    if q8:
        assert summary['supply_driver'] is None
        assert h.resolve(command[0]) == h.resolve(summary['image']['path'])
        assert h.verify(summary['artifact_manifest']) == S / 'original-vocabulary/manifest.json'
        assert summary['artifact_manifest']['sha256'] == MANIFEST_PIN
    else:
        script = CA / 'formal-flash/run_with_supply.py'
        assert h.resolve(command[1]) == script and h.verify(summary['supply_driver']) == script
        assert h.resolve(command[command.index('--image') + 1]) == h.resolve(summary['image']['path'])
        frontier = h.resolve(command[command.index('--frontier-file') + 1])
        assert frontier.parent == folder
        driver_path = h.add(frontier.with_name(frontier.stem + '.driver.json'))
        driver = h.read(driver_path)
        assert driver['exit'] == driver['native']['exit'] == 0 and driver['driver_pid'] == summary['process']['pid']
        assert not driver['native'].get('stopped_by_driver', False)
        assert h.resolve(driver['native']['command'][0]) == h.resolve(summary['image']['path'])
        assert driver['native']['command'][1:] == command[command.index('--') + 1:]
        assert all(fetch['exit'] == 0 and not fetch.get('stopped_by_driver', False) for fetch in driver['fetches'])
        driver_identity = h.identity(driver_path)
    root = ET.parse(h.add(folder / 'results.xml')).getroot()
    actual = [dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value']
              for p in case.iter('property')}) for case in root.iter('testcase')]
    assert actual == summary['cases']
    case = actual[0]
    a, p = case['attributes'], case['properties']
    key = (a['classname'], a['name'])
    assert key in Q8_CASES if q8 else key == BFLOAT_CASE
    assert a['status'] == 'run' and a['result'] == 'completed'
    assert h.number(p, 'actual_submissions') > 0
    assert h.number(p, 'state_backing_peak') <= h.number(p, 'state_backing_budget')
    if q8:
        expected = dict(original_role_count=83, original_role_bytes=12016057244,
            original_target_roles=4725, original_target_source_bytes=10748569116,
            target_state_resources=21, complete_state_members=30, target_expert_domain=256,
            target_resident_experts=6, natural_block5_trials=1,
            full_vocabulary_lm_values_checked=5*129280, target_full_vocabulary_values_checked=6*129280,
            vocabulary_original_bytes=1125253120)
        for name, value in expected.items():
            assert h.number(p, name) == value, (name, p.get(name))
        assert p['vocabulary_artifact_repository'] == REPO and p['vocabulary_artifact_revision'] == REV
        provider = 'ggml-cuda' if a['name'].startswith('Cuda') else 'ggml-cpu'
        assert p['draft_vocabulary_provider'] == p['target_verifier6_provider'] == p['target_verifier1_provider'] == provider
        assert p['controlled_prefix_publications'] == '0,2,5; explicit StateHead prefix tests, not natural greedy acceptance'
        assert h.number(p, 'actual_pending_embedding_feedback_checks') == h.number(p, 'actual_draft_episodes') >= 2
        assert h.number(p, 'natural_accepted_drafts') <= 5
        for name in ('actual_target_rows', 'actual_target_verifier_submissions', 'whole_state_publications',
                     'actual_main_history_catchup_submissions', 'continued_prefix_branches',
                     'cancelled_unpublished_drafts', 'rejected_stale_publishes'):
            assert h.number(p, name) > 0
    else:
        for name, value in dict(dense_original_roles=216, dense_original_source_bytes=3194218552,
                state_members=30, first_target_fullV_values=6*129280, first_draft_fullV_values=5*129280).items():
            assert h.number(p, name) == value, (name, p.get(name))
    for path in folder.iterdir():
        if path.is_file() and path.suffix.lower() in h.TEXT:
            h.add(path)
    for item in linked['hosts']:
        for path in h.resolve(item['record']['path']).parent.iterdir():
            if path.is_file() and path.suffix.lower() in h.TEXT:
                h.add(path)
    return dict(summary=h.identity(summary_path), source=summary['source'], process=summary['process'],
        supply_driver=driver_identity, linked=linked, cases=actual,
        graph_submissions_by_case={'.'.join(key):h.number(p, 'actual_submissions')})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--q8-runs', nargs=2, type=int, required=True)
    parser.add_argument('--bfloat-run', type=int, required=True)
    args = parser.parse_args()
    assert min(*args.q8_runs, args.bfloat_run) > 0 and len(set([*args.q8_runs, args.bfloat_run])) == 3
    protected = h.protect()
    artifact, sources, reused = artifacts(), frozen_sources(), reused_evidence()
    runs = [completed_run(attempt, True) for attempt in args.q8_runs]
    runs.append(completed_run(args.bfloat_run, False))
    keys = [(case['attributes']['classname'], case['attributes']['name']) for run in runs for case in run['cases']]
    assert len(keys) == 3 and set(keys) == Q8_CASES | {BFLOAT_CASE}
    graphs = {name: count for run in runs for name, count in run['graph_submissions_by_case'].items()}
    for path in [S/'publish.py', S/'fetch.py', CA/'build.py',
                 CA/'review/s02-q8-vocabulary-next.json', CA/'review/s02-q8-vocabulary-ranges.json']:
        h.add(path)
    assert h.protect() == protected
    h.files.discard(h.resolve(h.ANCHOR['path']))
    destination = R / 'docs/evidence/correctness/mtp-dspark-main-gguf-q8-vocabulary-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(h.files):
            zipped.write(path, path.relative_to(R).as_posix())
    record = dict(date='2026-10-23', stage='S02', identity_count_changed=False,
        conclusion='Matching original main-GGUF Q8_0 embedding/head and original Q8_0/MXFP4 DSpark sidecar passed the same target-tail/fullV K5 consumer on CPU/CUDA; one affected formal BF16 CUDA regression passed.',
        artifact=artifact, sources=sources, reused=reused,
        implementation=dict(vocabulary='One independent strong-owned original Q8 pair. Original encoded bytes stay packed; one ordinary Gather and explicit actual BF16 model entry, one ordinary MatMul for M5 draft/M6 target head.',
            numerics='Actual CPU AVX Q8_0 versus CUDA MMVQ Q8_1 activation semantics and the existing derived F32/quantization-ambiguity certificate; exact row decode/BF16 entry. First actual646400 draft and775680 target scores, later bounded candidates and whole-span stable greedy.',
            state='Same30-member StateHead/K5 atomic prefix publication, actual target-ID row lease pending feedback, capture/main-history catchup, continuation, cancellation, stale publication rejection and retained old readers.',
            build='Two existing DSpark host TUs incrementally recompiled; cached native/product/SDK closure. No new executor, public option or provider change.'),
        validation=dict(tests=3, failures=0, errors=0, skips=0, graph_submissions=sum(graphs.values()),
            graph_submissions_by_case=graphs, runs=runs),
        limitations=['Only the two selected main-UD-Q4_K_XL vocabulary tensors are newly integrated. The whole main-GGUF target body is not certified.',
            'The actual formal original target40/41/42 tail remains distinct from the converted Q8_0/MXFP4 draft; no official BF16/E4 or full-model arithmetic equivalence.',
            'Layer39 upstream input and initial valid cacheprefix are explicit finite fixtures. No quality, natural acceptance-rate, TPS or physical-memory-peak claim.',
            'Natural acceptance and controlled0/2/5 prefix policies remain separate. State backing is bounded resource accounting.',
            'This publication does not add a model/artifact identity or alter the existing16-identity count. No weight body is rehashed or archived.'],
        protection=protected, archive=h.identity(archive), archive_items=len(h.files))
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    publication = dict(evidence=h.identity(destination), archive=h.identity(archive))
    (S/'publication.json').write_text(json.dumps(publication, indent=2)+'\n', encoding='utf-8')
    assert h.protect() == protected
    print(json.dumps(dict(**publication, tests=3, graphs=sum(graphs.values()))))


if __name__ == '__main__':
    main()
