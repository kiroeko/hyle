"""Acquire the two exact original Q8_0 vocabulary ranges, using cached HTTP/resume code."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import gzip
import importlib.util
import json
from pathlib import Path
import re
import struct
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
PROPOSAL = R / '.scratch/dspark-pro-target-draft-20261023/review/s02-q8-vocabulary-ranges.json'
HEADER_BYTES = 26560


def common_module():
    spec = importlib.util.spec_from_file_location('qwen_original_range', R / '.scratch/qwen-bfloat-selected-20261023/fetch_roles.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def parse_header(raw):
    offset = 0

    def unpack(fmt):
        nonlocal offset
        size = struct.calcsize('<' + fmt)
        assert offset + size <= len(raw), 'GGUF metadata exceeds the exact header'
        result = struct.unpack_from('<' + fmt, raw, offset)
        offset += size
        return result[0] if len(result) == 1 else result

    def string():
        nonlocal offset
        size = unpack('Q')
        assert size <= len(raw) - offset
        value = raw[offset:offset+size].decode('utf-8')
        offset += size
        return value

    def value(kind):
        formats = {0:'B', 1:'b', 2:'H', 3:'h', 4:'I', 5:'i', 6:'f', 7:'?', 10:'Q', 11:'q', 12:'d'}
        if kind in formats:
            return unpack(formats[kind])
        if kind == 8:
            return string()
        if kind == 9:
            element, count = unpack('I'), unpack('Q')
            assert count <= len(raw)
            return [value(element) for _ in range(count)]
        raise ValueError('Unknown GGUF metadata type ' + str(kind))

    assert raw[:4] == b'GGUF'
    offset = 4
    assert unpack('I') in (2, 3)
    tensor_count, metadata_count = unpack('Q'), unpack('Q')
    assert tensor_count == 414 and metadata_count <= 1000
    metadata = {}
    for _ in range(metadata_count):
        key = string()
        assert key not in metadata
        metadata[key] = value(unpack('I'))
    tensors = []
    for _ in range(tensor_count):
        name, rank = string(), unpack('I')
        assert 0 < rank <= 4
        dimensions = [unpack('Q') for _ in range(rank)]
        tensors.append(dict(name=name, shape=dimensions, dtype_code=unpack('I'), offset=unpack('Q')))
    alignment = metadata.get('general.alignment', 32)
    assert type(alignment) is int and 0 < alignment <= 4096
    assert (offset + alignment - 1) // alignment * alignment == len(raw) == HEADER_BYTES
    return metadata, tensors


def header(common, proposal):
    archive = proposal['cached_header']
    assert common.identity(R / archive['path']) == archive
    cached = json.loads(gzip.decompress((R / archive['path']).read_bytes()))[proposal['cache_record_key']]
    assert all(cached[key] == proposal[key] for key in ('repository','revision','file','url'))
    path, receipt_path = S / 'original-header.bin', S / 'header.json'
    if receipt_path.exists():
        receipt = common.read(receipt_path)
        assert receipt['url'] == proposal['url'] and common.identity(path) == receipt['header']
        raw = path.read_bytes()
    else:
        request = urllib.request.Request(proposal['url'], headers={'Range':f'bytes=0-{HEADER_BYTES-1}',
            'Accept-Encoding':'identity', 'User-Agent':'hyle-original-vocabulary/1'})
        with urllib.request.urlopen(request, timeout=45) as response:
            match = re.fullmatch(r'bytes 0-' + str(HEADER_BYTES-1) + r'/(\d+)', response.headers.get('Content-Range',''))
            assert response.status == 206 and match and response.headers.get('Content-Length') == str(HEADER_BYTES)
            assert response.headers.get('Content-Encoding') in (None, 'identity')
            etag = response.headers.get('ETag','')
            assert etag.startswith('"') and etag.endswith('"')
            raw = response.read(HEADER_BYTES)
            assert len(raw) == HEADER_BYTES and not response.read(1)
            whole = int(match[1])
        path.write_bytes(raw)
        receipt = dict(url=proposal['url'], http_status=206, range=[0,HEADER_BYTES-1],
            whole_file_bytes=whole, etag=etag, header=common.identity(path), tensor_payload_bytes=0)
    metadata, actual = parse_header(raw)
    expected = [dict(name=t['name'], shape=list(map(int,t['shape'])), dtype_code=t['dtype_code'], offset=int(t['offset']))
                for t in cached['tensors']]
    assert actual == expected and metadata == cached['metadata']
    assert len({t['name'] for t in actual}) == 414
    for row in proposal['roles']:
        original = next(t for t in actual if t['name'] == row['name'])
        assert original['shape'] == row['gguf_dimensions'] and original['dtype_code'] == 8
        assert original['offset'] == row['data_relative_offset']
        assert row['bytes'] == 562626560 and row['absolute_inclusive'] == [HEADER_BYTES+original['offset'], HEADER_BYTES+original['offset']+row['bytes']-1]
        assert row['absolute_inclusive'][1] < receipt['whole_file_bytes']
    write_json(receipt_path, receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--headers-only', action='store_true')
    args = parser.parse_args()
    common = common_module()
    proposal = common.read(PROPOSAL)
    assert proposal['payload_bytes'] == 1125253120 and len(proposal['roles']) == 2
    source = header(common, proposal)
    if args.headers_only:
        print(json.dumps(dict(header=common.identity(S/'header.json'), network_body_bytes=0, complete=True)))
        return
    output = S / 'original-vocabulary'
    output.mkdir(exist_ok=True)
    with common.single_writer(output / '.fetch.lock'):
        receipt_path = output / 'acquisition.json'
        expected = dict(repository=proposal['repository'], revision=proposal['revision'], variant=proposal['variant'],
            original_roles=2, expected_role_payload_bytes=1125253120, source_plan=common.identity(PROPOSAL),
            source_header=common.identity(S/'header.json'), downloader=common.identity(common.HELPER))
        rows = [dict(name=row['name'], filename=row['file'], dtype='Q8_0', shape=row['gguf_dimensions'], bytes=row['bytes'],
            absolute_inclusive=row['absolute_inclusive'], url=proposal['url'], etag=source['etag'], whole_file_bytes=source['whole_file_bytes'],
            complete=False, chunks=[], payload=dict(path=(output/row['file']).relative_to(R).as_posix(), bytes=row['bytes'], sha256=None))
            for row in proposal['roles']]
        if receipt_path.exists():
            record = common.read(receipt_path)
            assert all(record[key] == wanted for key,wanted in expected.items())
            for acquired,wanted in zip(record['roles'],rows,strict=True):
                assert all(acquired[key] == val for key,val in wanted.items() if key not in ('complete','chunks','payload'))
                assert acquired['payload']['path'] == wanted['payload']['path'] and acquired['payload']['bytes'] == wanted['payload']['bytes']
        else:
            assert not any((R/row['payload']['path']).exists() for row in rows)
            record = dict(expected, complete=False, whole_shard_downloaded=False, requests=[], roles=rows)
        functions = common.downloader(record,receipt_path)
        record['complete'] = False
        functions['save']()
        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(functions['acquire_role'],row) for row in record['roles']]
            errors = []
            for future in futures:
                try: future.result()
                except Exception as error: errors.append(error)
        if errors:
            raise errors[0]
        assert all(row['complete'] for row in record['roles'])
        size = sum(row['bytes'] for row in record['requests'] if row['complete'])
        assert size == expected['expected_role_payload_bytes']
        record.update(complete=True, role_payload_bytes=size, successful_request_body_bytes=size, finished_utc=functions['now']())
        functions['save']()
        manifest = dict(repository=proposal['repository'],revision=proposal['revision'],variant=proposal['variant'],
            original_roles=2,source_bytes=size,complete=True,roles=[dict(name=row['name'],file=row['filename'],
                dtype=row['dtype'],shape=row['shape'],bytes=row['bytes'],sha256=row['payload']['sha256']) for row in record['roles']])
        write_json(output/'manifest.json',manifest)
        print(json.dumps(dict(complete=True, manifest=common.identity(output/'manifest.json'), receipt=common.identity(receipt_path))))


if __name__ == '__main__':
    main()
