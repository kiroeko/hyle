from pathlib import Path
import hashlib, json, os, subprocess, time

root=Path.cwd()
out=root/'.scratch/inference-gaps/g03/copy-update-windows-cpu'
out.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key,value=line.split('=',1);env[key]=value
build=Path('C:/h7/inference-g01-native-vulkan/build')
parent=Path('C:/h7/inference-g01-native-vulkan/parent/CMakeLists.txt')
target='g03_copy_update_public'
source=root/'tests/compute_batch/copy_update_public_consumer.cc'
body=parent.read_bytes()
if ('add_executable('+target+' ').encode() not in body:
    body+=f'\nadd_executable({target} "{source.as_posix()}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE /W4 /WX /wd4324 /utf-8)\ntarget_link_libraries({target} PRIVATE hyle::compute)\nhyle_stage_runtime({target})\n'.encode()
    parent.write_bytes(body)
record=out/'result.json' 
rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
for stage,args in [('build',['cmake','--build',str(build),'--target',target,'--parallel','4']),
    ('host-cpu-public-probe',[str(build/(target+'.exe'))])]:
    attempt=1+sum(r['stage']==stage for r in rows)
    log=out/f'{stage}-{attempt}.log';start=time.monotonic()
    with log.open('w',encoding='utf-8') as stream:
        process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
        (out/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}))
        print('RUN',stage,'PID',process.pid,flush=True);code=process.wait()
    rows.append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':str(log)})
    record.write_text(json.dumps({'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'AUDITED CopyBatchUpdate Windows CPU public64; native owners compile only; no GPU run',
        'stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n')
    print(log.read_text(errors='replace')[-5000:],flush=True)
    if code:break
(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code}))
raise SystemExit(code)
