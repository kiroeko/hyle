"""After root SOURCE_FROZEN: plan, build. Default does nothing.

Four TUs, three images from the latest CPU/Vulkan closure. No SDK/native,
weights/report, CUDA build, source edits, download, or model run.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-copy-public-retention-20261026'
spec = importlib.util.spec_from_file_location('cached',R/'.scratch/inference-stream-padding-20261026/build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b = m.b
RESOURCE_OLD = R/'.scratch/inference-stream-padding-20261026/compile/graph-resources/unit.obj'
SPECS = [('resources','src/graph/resources.cc',RESOURCE_OLD.parent/'command.json'),
    ('graph-test','tests/graph/invocation_unbind_test.cc',B/'compile2/device-test/command.json'),
    ('prefix','tests/tools/qwen_prefix_cache_test.cc',R/'.scratch/inference-prefix-directory-20261024/host/compile/command.json'),
    ('model','tests/tools/qwen_host_image_test.cc',B/'compile2/model/command.json')]


def plan():
    assert not (W/'plan.json').exists()
    units = [dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),
        command=m.command(recipe,R/source,W/'compile'/name)) for name,source,recipe in SPECS]
    assert any('HYLE_PREFIX_CACHE_STANDALONE' in x for x in units[2]['command'])
    frozen = m.c.closure([x['source']['path'] for x in units],[r for _,_,r in SPECS])
    b.save(W/'source-freeze.json',frozen)
    baselines = {}
    for name in ('test','prefix','case'):
        folder = B/('test' if name == 'test' else 'case')
        inputs = b.read(folder/'link-inputs.json')
        assert len(inputs) == 137 and all(Path(x['path']).is_file() for x in inputs)
        assert sum(b.key(x['path']) == b.key(RESOURCE_OLD) for x in inputs) == 1
        baselines[name] = dict(command=b.pin(folder/'link/command.json'),inputs=b.pin(folder/'link-inputs.json'),
            ready=b.pin(folder/'ready.json'),runtime=b.pin(folder/'runtime.json'))
    b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',units=units,baselines=baselines,
        source_freeze=b.pin(W/'source-freeze.json'),unique_TUs=4,images=3,
        weight_report_SDK_native_compiles=0,CUDA='NOT_BUILT',native_runs=0))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)


def build(resume=False, plan_name=None):
    plan_name = plan_name or ('plan2.json' if resume else 'plan.json')
    data = b.read(W/plan_name)
    ready_name = data.get('ready_name', 'ready.json')
    assert not (W/ready_name).exists()
    if not resume: assert not (W/'compile').exists()
    frozen = b.read(data['source_freeze']['path'])
    for row in frozen: b.exact(row)
    helper = b.helper()
    cl = data['units'][0]['command'][0]
    env = helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    own = {b.key(x['path']):x for x in frozen}
    objects,results = {},[]
    for unit in data['units']:
        out = Path(next(x[3:] for x in unit['command'] if x.lower().startswith('/fo'))).parent
        reused = resume and (out/'process.json').exists()
        if reused:
            process = b.read(out/'process.json')
            assert process['exit'] == 0
            actual = b.read(out/'actual-dependencies.json')
            for row in actual: b.exact(row)
        else:
            process = helper.execute(unit['command'],env,out,timeout=180)
            dep = b.read(out/'dependencies.json')['Data']
            actual = [b.pin(q) for q in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            q = Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert b.key(q) in own and row['sha256'] == own[b.key(q)]['sha256'],str(q)
        if not reused: b.save(out/'actual-dependencies.json',actual)
        objects[unit['name']] = b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],
            process=process,reused_compile=reused,dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen: b.exact(row)
    artifacts = {}
    for name,baseline in data['baselines'].items():
        inputs = b.read(baseline['inputs']['path'])
        replacement = {b.key(RESOURCE_OLD):objects['resources']}
        remove,added = set(),[]
        if name == 'prefix':
            remove = {b.key(x['path']) for x in inputs if any(x['path'].endswith(s) for s in [
                'inference-copy-public-retention-20261026\\compile2\\model\\unit.obj',
                'inference-stream-padding-20261026\\compile\\weights\\unit.obj',
                'inference-review-fixes-20261026\\product2\\report\\unit.obj'])}
            assert len(remove) == 3
            added = [objects['prefix']]
        else:
            old = B/('compile2/device-test/unit.obj' if name == 'test' else 'compile2/model/unit.obj')
            replacement[b.key(old)] = objects['graph-test' if name == 'test' else 'model']
        artifact_dir = W/data.get('artifact_directories', {}).get(name, name)
        image = artifact_dir/'link'/('graph-test.exe' if name == 'test' else 'prefix-test.exe' if name == 'prefix' else 'host-image-test.exe')
        args,replaced,removed = [],0,0
        for arg in b.read(baseline['command']['path'])['command']:
            if b.key(arg) in remove:
                removed += 1
                continue
            if b.key(arg) in replacement:
                arg = replacement[b.key(arg)]['path']
                replaced += 1
            elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
            args.append(arg)
        assert replaced == len(replacement) and removed == len(remove)
        args += [x['path'] for x in added]
        linked = helper.execute(args,env,image.parent,timeout=120)
        final = [replacement.get(b.key(x['path']),x) for x in inputs if b.key(x['path']) not in remove]+added
        assert len(final) == (135 if name == 'prefix' else 137)
        b.save(artifact_dir/'link-inputs.json',final)
        runtime = b.read(baseline['runtime']['path'])
        b.exact(runtime['native'])
        alias = image.parent/Path(runtime['native']['path']).name
        os.link(runtime['native']['path'],alias)
        runtime['native_hardlink'] = b.pin(alias)
        b.save(artifact_dir/'runtime.json',runtime)
        artifact = dict(status='LINKED_NOT_RUN',image=b.pin(image),inputs=b.pin(artifact_dir/'link-inputs.json'),
            runtime=b.pin(artifact_dir/'runtime.json'),link=linked)
        b.save(artifact_dir/'ready.json',artifact)
        artifacts[name] = artifact
    b.save(W/ready_name,dict(status='BUILT_NOT_RUN',plan=b.pin(W/plan_name),compiled=results,
        artifacts=artifacts,weight_report_SDK_native_compiles=0,native_runs=0))
    print('READY',json.dumps(b.pin(W/ready_name)),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    elif sys.argv[1:] == ['resume']: build(resume=True)
    elif sys.argv[1:] == ['resume3']: build(resume=True, plan_name='plan3.json')
    else: print(__doc__)
