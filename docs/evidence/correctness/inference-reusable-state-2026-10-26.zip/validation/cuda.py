"""After Windows eight-process PASS: plan, build, run. Default does nothing.

Exactly current CUDA Model+weights TUs. Share current Graph resources and reuse
the eight already built neutral leaves; unique direct replacements in the last
successful 223-input CUDA closure. Three unchanged-tiny processes only.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
C = W/'cuda'
B = R/'.scratch/inference-native-host-image-20261026/cuda-model-attempt3'
spec = importlib.util.spec_from_file_location('cached',R/'.scratch/inference-stream-padding-20261026/build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b = m.b


def plan():
    assert b.read(W/'run-summary.json')['status'] == 'EIGHT_FINITE_PROCESSES_EXIT_ZERO'
    assert not (C/'plan.json').exists()
    recipes = [B/'compile/model/command.json',B/'compile/weights/command.json']
    sources = [R/'tests/tools/qwen_host_image_test.cc',R/'engine/models/qwen35/weights.cc']
    units = [dict(name=name,source=b.pin(source),recipe=b.pin(recipe),
        command=m.command(recipe,source,C/'compile'/name)) for name,source,recipe in zip(('model','weights'),sources,recipes)]
    for unit in units:
        assert '/DHYLE_COMPUTE_CUDA=1' in unit['command'] and not any(x in unit['command'] for x in ('/DHYLE_COMPUTE_CPU=1','/DHYLE_COMPUTE_VULKAN=1'))
    frozen = m.c.closure(sources,recipes)
    b.save(C/'source-freeze.json',frozen)
    inputs = b.read(B/'link-inputs.json')
    assert len(inputs) == 223 and all(Path(x['path']).is_file() for x in inputs)
    replacements = []
    for item in b.read(W/'cuda-preparation.json')['unique_direct_replacements']:
        after = b.pin(Path(item['after']['path']))
        assert sum(b.key(x['path']) == b.key(item['before']['path']) for x in inputs) == 1
        replacements.append(dict(name=item['name'],before=item['before'],after=after))
    core = W/'compile/resources'
    assert b.read(core/'process.json')['exit'] == 0
    for row in b.read(core/'actual-dependencies.json'): b.exact(row)
    b.save(C/'plan.json',dict(status='FROZEN_NOT_BUILT',units=units,source_freeze=b.pin(C/'source-freeze.json'),
        inputs=b.pin(B/'link-inputs.json'),command=b.pin(B/'link/command.json'),runtime=b.pin(B/'runtime.json'),
        replacements=replacements,shared_resources_dependencies=b.pin(core/'actual-dependencies.json'),
        Windows_run_summary=b.pin(W/'run-summary.json'),compiled_TUs=2,SDK_native_report_compiles=0))
    print('CUDA_PLAN',json.dumps(b.pin(C/'plan.json')),flush=True)


def build():
    p = b.read(C/'plan.json')
    assert not (C/'compile').exists() and not (C/'ready.json').exists()
    frozen = b.read(p['source_freeze']['path'])
    for row in frozen: b.exact(row)
    for row in b.read(p['shared_resources_dependencies']['path']): b.exact(row)
    for pair in p['replacements']: b.exact(pair['after'])
    helper = b.helper()
    cl = p['units'][0]['command'][0]
    env = helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    own = {b.key(x['path']):x for x in frozen}
    objects,results = {},[]
    for unit in p['units']:
        out = C/'compile'/unit['name']
        process = helper.execute(unit['command'],env,out,timeout=180)
        dep = b.read(out/'dependencies.json')['Data']
        actual = [b.pin(q) for q in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            q = Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert b.key(q) in own and row['sha256'] == own[b.key(q)]['sha256'],str(q)
        b.save(out/'actual-dependencies.json',actual)
        objects[unit['name']] = b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],
            process=process,dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen: b.exact(row)
    replacement = {b.key(x['before']['path']):x['after'] for x in p['replacements']}
    for name in ('model','weights'): replacement[b.key(B/'compile'/name/'unit.obj')] = objects[name]
    image = C/'link/host-image-test.exe'
    args,count = [],0
    for arg in b.read(p['command']['path'])['command']:
        if b.key(arg) in replacement:
            arg = replacement[b.key(arg)]['path']
            count += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert count == len(replacement) == 11
    linked = helper.execute(args,env,image.parent,timeout=120)
    final = [replacement.get(b.key(x['path']),x) for x in b.read(p['inputs']['path'])]
    assert len(final) == 223
    b.save(C/'link-inputs.json',final)
    runtime = b.read(p['runtime']['path'])
    b.exact(runtime['native'])
    alias = image.parent/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'],alias)
    runtime['native_hardlink'] = b.pin(alias)
    b.save(C/'runtime.json',runtime)
    b.save(C/'ready.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),plan=b.pin(C/'plan.json'),
        compiled=results,inputs=b.pin(C/'link-inputs.json'),runtime=b.pin(C/'runtime.json'),link=linked,
        SDK_native_report_compiles=0))
    print('CUDA_READY',json.dumps(b.pin(C/'ready.json')),flush=True)


def run():
    ready = b.read(C/'ready.json')
    b.exact(ready['image'])
    fixture = R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    env = os.environ.copy()
    env['PATH'] = b.read(ready['runtime']['path'])['PATH']
    results = []
    for name,tail in [('state-reuse',['--state-reuse']),('ordinary-mtp',[]),('lag1',['--mtp-lag1'])]:
        command = [ready['image']['path'],'--cuda',str(fixture),*tail]
        process = b.helper().execute(command,env,C/'runs'/name,timeout=60)
        results.append(dict(name=name,process=process))
        print('CUDA_PROCESS',json.dumps(results[-1]),flush=True)
    b.save(C/'run-summary.json',dict(status='THREE_FINITE_PROCESSES_EXIT_ZERO',processes=results,
        fixture=b.pin(fixture/'weights.tsv'),quality_claim=False,performance_claim=False,full335=False))


if __name__ == '__main__':
    if sys.argv[1:] in (['plan2'], ['build2'], ['run2']):
        C = W/'cuda2'
        {'plan2':plan, 'build2':build, 'run2':run}[sys.argv[1]]()
    elif sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    elif sys.argv[1:] == ['run']: run()
    else: print(__doc__)
