from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
D = R / 'docs/evidence/correctness'
NAME = 'inference-reusable-state-2026-10-26'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def pin(p):
    return {'path': str(p.relative_to(R)).replace('\\', '/'), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

paths = [
    'engine/inference/reusable_output_storage.h', 'engine/inference/state_transfer.h',
    'engine/models/qwen35/session_state.h', 'engine/models/qwen35/session_transfer.h',
    'engine/models/qwen35/main.cc', 'src/graph/resources.cc',
    'tests/graph/invocation_unbind_test.cc', 'tests/tools/qwen_prefix_cache_test.cc',
    'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_host_image_case.h',
    'tests/tools/qwen_state_reuse_case.h',
]
windows = read(W / 'run-summary.json')
assert windows['status'] == 'EIGHT_FINITE_PROCESSES_EXIT_ZERO'
cuda = read(W / 'cuda2/run-summary.json')
assert cuda['status'] == 'THREE_FINITE_PROCESSES_EXIT_ZERO'
for summary in (windows, cuda):
    assert all(x['process']['exit'] == 0 for x in summary['processes'])

def case(p):
    lines = p.read_text(encoding='utf-8').splitlines()
    result = [json.loads(line) for line in lines if line.startswith('{')]
    assert len(result) == 1 and result[0]['status'] == 'PASS'
    return result[0]

cases = {
    'cpu': case(W / 'runs2/cpu-state-reuse/stdout.log'),
    'vulkan': case(W / 'runs2/vulkan-state-reuse/stdout.log'),
    'cuda': case(W / 'cuda2/runs/state-reuse/stdout.log'),
}
assert cases['cpu']['applicable'] and cases['cuda']['applicable']
assert not cases['vulkan']['applicable']
for name in ('cpu', 'cuda'):
    assert cases[name]['cold_acquire_pressure_roles'] == 2
    assert cases[name]['host_restore_pressure_roles'] == 2
    assert cases[name]['checkpoint_bytes_unchanged'] and cases[name]['final_versions'] == 0

prefix = (W / 'runs2/prefix/stdout.log').read_text(encoding='utf-8')
graph = (W / 'runs2/graph/stdout.log').read_text(encoding='utf-8')
assert '[  PASSED  ] 8 tests.' in graph
assert 'PASS bounded output reuse' in prefix

patch = subprocess.run(['git', 'diff', '--', *paths], cwd=R, check=True,
    stdout=subprocess.PIPE).stdout
(W / 'product-and-tests.diff').write_bytes(patch)
report = {
    'date': '2026-10-26', 'status': 'FINITE_CPU_VULKAN_CUDA_CHECKS_PASS',
    'git_before_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    'changes': [
        'Bounded FIFO reuse of original retired successful output writers; shared active R, no additional payload pool.',
        'Decode, cold Session creation and host restore use the same original state-writer inventory.',
        'Exact physical external-instance lookup for caller-owned Graph output storage, retaining range fallback and original budget checks.',
        'CUDA-only conditional unused parameter annotation in StateTransfer; no runtime behavior change.',
    ],
    'sources': [pin(R / p) for p in paths],
    'windows': windows, 'cuda': cuda,
    'graph_tests': 8,
    'prefix_standalone_pass_lines': sum(s.startswith('PASS ') for s in prefix.splitlines()),
    'actual_reuse_consumers': cases,
    'retained_failures': [
        'Graph test compile: test used nonexistent BufferView.as_const; corrected test conversion.',
        'Graph test run: two mismatched write extents and invalid zero-budget construction; corrected fixtures, unchanged product checks.',
        'Capacity review: cold creation and restore bypassed cached writers; unified acquisition and added pressure checks before final run.',
        'CUDA-only compile: StateTransfer owner used only by Apple/Vulkan branches; added maybe_unused without lowering warnings.',
    ],
    'limits': [
        'Finite local tiny Model fixture and component checks; not full-model task quality or throughput evidence.',
        'Vulkan provider-owned outputs do not exercise caller-owned writer reuse.',
        'Apple not run for this batch; no new SDK or device kernel build, download or profiler.',
        'Windows run predates only the no-behavior maybe_unused parameter annotation; it was not rerun.',
        'Per-step KV frame export, reframe, binding and publication remain; indexed multi-prefix MTP slots and overlap are not implemented by this change.',
    ],
    'performance_claim': False,
}
if (W / 'cleanup-result.json').exists():
    report['cleanup'] = read(W / 'cleanup-result.json')
archive = D / (NAME + '.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(W.rglob('*')):
        if not p.is_file() or p.suffix.lower() not in {'.json', '.log', '.py', '.ps1', '.diff', '.cc'}:
            continue
        if 'b2' in p.relative_to(W).parts:
            continue
        z.write(p, 'validation/' + str(p.relative_to(W)).replace('\\', '/'))
    for source in paths:
        z.write(R / source, 'source/' + source)
report['archive'] = pin(archive)
(D / (NAME + '.json')).write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'status': report['status'], 'archive': report['archive'],
    'report': pin(D / (NAME + '.json'))}, ensure_ascii=False))
