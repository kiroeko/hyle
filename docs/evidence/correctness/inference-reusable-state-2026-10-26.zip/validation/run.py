"""After root authorizes: run.py run. Default does nothing.

Graph TU, standalone prefix checks, same tiny CPU and Vulkan ordinary/MTP+lag1.
Eight bounded processes only, stop on first failure; no implicit retry/TPS/4GB run.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch',W/'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b,R = m.b,m.R


def run(second=False):
    ready_name = 'ready3.json' if second else 'ready.json'
    ready = b.read(W/ready_name)
    fixture = R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    jobs = [('graph','test',[]),('prefix','prefix',[]),
        ('cpu','case',['--cpu',str(fixture)]),('cpu-lag1','case',['--cpu',str(fixture),'--mtp-lag1']),
        ('vulkan','case',['--vulkan',str(fixture)]),('vulkan-lag1','case',['--vulkan',str(fixture),'--mtp-lag1']),
        ('cpu-state-reuse','case',['--cpu',str(fixture),'--state-reuse']),
        ('vulkan-state-reuse','case',['--vulkan',str(fixture),'--state-reuse'])]
    manifest = [dict(name=name,command=[ready['artifacts'][artifact]['image']['path'],*args],
        image=ready['artifacts'][artifact]['image'],runtime=ready['artifacts'][artifact]['runtime']) for name,artifact,args in jobs]
    b.save(W/('run2-manifest.json' if second else 'run-manifest.json'),dict(ready=b.pin(W/ready_name),processes=manifest,
        fixture=b.pin(fixture/'weights.tsv'),performance=False,full335=False))
    results = []
    for item in manifest:
        b.exact(item['image'])
        env = os.environ.copy()
        env['PATH'] = b.read(item['runtime']['path'])['PATH']
        process = b.helper().execute(item['command'],env,W/('runs2' if second else 'runs')/item['name'],timeout=60)
        results.append(dict(name=item['name'],process=process))
        print('PROCESS',json.dumps(results[-1]),flush=True)
    b.save(W/'run-summary.json',dict(status='EIGHT_FINITE_PROCESSES_EXIT_ZERO',processes=results,
        quality_claim=False,performance_claim=False,full335='NOT_RUN'))


if __name__ == '__main__':
    if sys.argv[1:] == ['run']: run()
    elif sys.argv[1:] == ['run2']: run(second=True)
    else: print(__doc__)
