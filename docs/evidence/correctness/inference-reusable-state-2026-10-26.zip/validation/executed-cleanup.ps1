param([switch]$Delete)
$ErrorActionPreference = 'Stop'
$scope = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch/inference-reusable-state-20261026')).TrimEnd('\') + '\'
$targets = @(
  @{ path='.scratch/inference-reusable-state-20261026/test/link/graph-test.exe'; bytes=68322304; sha256='4a30ed2efc5ec8e9ee10c3282a5f709d6c68429b85e443b16eb53cce070c20c2' },
  @{ path='.scratch/inference-reusable-state-20261026/prefix/link/prefix-test.exe'; bytes=67480576; sha256='f6cb7c00845d6fd4997f9bc923472bde92abf96b66727a6fd8f3df04975cd9f8' },
  @{ path='.scratch/inference-reusable-state-20261026/case/link/host-image-test.exe'; bytes=69571584; sha256='e9c4726cec65da59cb8273ac7b616a9abe61afb5ad6805b21dabf0dc5c3c9071' }
)
foreach ($row in $targets) {
  $resolved = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot $row.path)).ProviderPath
  if (-not $resolved.StartsWith($scope,[StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes batch workspace' }
  $item = Get-Item -LiteralPath $resolved
  if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -ne $row.bytes) { throw 'Target identity mismatch' }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ine $row.sha256) { throw 'Target digest changed' }
}
$current = @('test3/link/graph-test.exe','prefix2/link/prefix-test.exe','case2/link/host-image-test.exe','cuda2/link/host-image-test.exe')
foreach ($name in $current) {
  if (-not (Test-Path -LiteralPath (Join-Path $scope $name) -PathType Leaf)) { throw 'Current successful image missing' }
}
if (-not $Delete) {
  $targets | ForEach-Object { [pscustomobject]$_ } | Format-Table path,bytes
  Write-Output 'Read-only check completed. No files deleted.'
  return
}
$scriptHash = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
foreach ($row in $targets) { Remove-Item -LiteralPath (Join-Path $PSScriptRoot $row.path) -Force }
$receipt = [ordered]@{ status='REMOVED_THREE_SUPERSEDED_BATCH_IMAGES'; command='& .\test.ps1 -Delete'; executed_script_sha256=$scriptHash; logical_bytes=($targets | Measure-Object -Property bytes -Sum).Sum; targets=$targets; current_images_present=$true; all_objects_libraries_models_and_logs_retained=$true }
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $scope 'cleanup-result.json') -Encoding UTF8
$receipt | ConvertTo-Json -Depth 5
