"""Read completed traces only. Never executes a consumer or touches old evidence."""
from pathlib import Path
from array import array
import hashlib,json,sys
R=Path.cwd();S=R/'.scratch/paged-retirement-20261021';P=R/'.scratch/qwen-prefix-20261021';O=S/'async-review';O.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(x):a=identity(x['path']);assert a==x,(a,x);return a
def stable(x):
 if isinstance(x,dict):return{k:stable(v)for k,v in x.items()if k != 'seconds' and not k.endswith('_seconds')}
 if isinstance(x,list):return[stable(v)for v in x]
 return x
ready=read(S/'qwen-ready-attempt1.json');verify(ready['image']);verify(ready['source']);assert ready['source']['sha256']=='440220ee2b4c38575765d3617127f275ca932e2a8e25d37d7e5baf4e463bbdd9'
old_ready=read(P/'ready-attempt3.json');verify(old_ready['image'])
assert sys.byteorder=='little'
cases={};total=0;finite={'bf16_elements':0,'f32_elements':0,'nonfinite_elements':0}
for name,previous,expected in [('main-run1','main-run4',22),('pressure-run1','pressure-run3',30)]:
 cur,old=S/name,P/previous
 a,b=read(cur/'result.json'),read(old/'result.json');assert a['exit']==b['exit']==0
 assert a['image']==ready['image']and b['image']==old_ready['image']
 def normalized_argv(c):
  c=list(c);c[0]='EXE';c[c.index('--trace')+1]='TRACE';return c
 assert normalized_argv(a['command'])==normalized_argv(b['command'])
 x,y=read(cur/'observation.json'),read(old/'observation.json');assert stable(x)==stable(y)
 actual={p.relative_to(cur/'trace').as_posix():p for p in(cur/'trace').rglob('*')if p.name in ('hidden.bf16','logits.f32')}
 baseline={p.relative_to(old/'trace').as_posix():p for p in(old/'trace').rglob('*')if p.name in ('hidden.bf16','logits.f32')}
 assert actual.keys()==baseline.keys()and len(actual)==expected
 pairs=[]
 for rel in sorted(actual):
  aa,bb=actual[rel].read_bytes(),baseline[rel].read_bytes();assert aa==bb
  typ='H'if rel.endswith('.bf16')else'I';mask=0x7f80 if typ=='H'else 0x7f800000
  values=array(typ);values.frombytes(aa);nonfinite=sum((v&mask)==mask for v in values)
  finite['bf16_elements'if typ=='H'else'f32_elements']+=len(values);finite['nonfinite_elements']+=nonfinite
  assert nonfinite==0
  pairs.append(dict(relative=rel,actual=identity(actual[rel]),baseline=identity(baseline[rel]),byte_equal=True,elements=len(values),nonfinite=nonfinite))
 total+=len(pairs)
 metadata={}
 for p in(cur/'trace').rglob('cache-hit.json'):
  rel=p.relative_to(cur/'trace');reference=old/'trace'/rel
  assert reference.is_file()and read(p)==read(reference)
  v=read(p);assert v['graph_calls']==0 and v['tensor_payload_available']is False
  assert not(p.parent/'hidden.bf16').exists()and not(p.parent/'logits.f32').exists()
  metadata[rel.as_posix()]=dict(actual=identity(p),baseline=identity(reference),contents=v)
 cases[name]=dict(previous=previous,new_result=identity(cur/'result.json'),old_result=identity(old/'result.json'),new_observation=identity(cur/'observation.json'),old_observation=identity(old/'observation.json'),same_command_except_image_trace_path=True,
  all_non_timing_observation_fields_equal=True,decision_vectors=expected,pairs=pairs,cache_hit_metadata=metadata,
  statistics={k:x[k]for k in ['session_count','processed_tokens','generated_tokens','actual_graph_calls','actual_graph_tokens','prefix_hits','prefix_misses','prefix_full_hits','reused_tokens','cache_shared_backing_bytes','cache_live_snapshot_versions','cache_peak_committed_versions','cache_committed_version_limit','prefix_entries','prefix_evictions','dispatch_session_ids','evicted_session_ids']},
  sessions=[{k:v[k]for k in ['session_id','visible_tokens','generated_ids','actual_graph_calls','actual_graph_tokens','restored_calls','restored_tokens','prefix_hits','prefix_misses','prefix_full_hits','reused_tokens','phases'] if k!='phases'}|{'phase_contexts':[{k:p[k]for k in ['turn','kind','name','input_tokens','calls','context_before','context_after']}for p in v['phases']]}for v in x['sessions']])
assert total==52
report=dict(status='Host-only independent comparison PASS for52actualdecisionvectors; no new inference.',source_review=identity(O/'source-review.json'),ready=identity(S/'qwen-ready-attempt1.json'),image=ready['image'],source=ready['source'],previous_ready=identity(P/'ready-attempt3.json'),previous_image=old_ready['image'],comparison_script=identity(__file__),cases=cases,total_decision_vectors=total,all_byte_equal=True,finite_counts=finite,limits=['Only hidden.bf16 and logits.f32 actual decision tensors are vector evidence; route TSV and cache-hit metadata are not vectors.','Original P main-run4/pressure-run3 files were read only and never altered. No off baseline was rerun.','All non-time observations match, including actual Graph work, hit/miss/full-hit, restore and eviction/phase order. Phase/session timer values are intentionally not compared as numerical correctness.','This preserves the already-established same-partition finite reference. It is not independent checkpoint quality, all-layer full-state bit identity, concurrent throughput, nor proof of the newly gated asynchronous stop journey.','No review-triggered GPU/device query/model process/build/link or source edit.'])
p=O/'runtime-comparison.json';p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(report=identity(p),total_vectors=total,finite=finite,case_counts={k:v['statistics']for k,v in cases.items()}),indent=2))


