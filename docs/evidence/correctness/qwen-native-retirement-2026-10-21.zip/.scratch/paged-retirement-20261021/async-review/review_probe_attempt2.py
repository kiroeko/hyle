from pathlib import Path
import hashlib,json,re
R=Path.cwd();S=R/'.scratch/paged-retirement-20261021';O=S/'async-review'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p);data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def verify(x):a=ident(x['path']);assert a==x,(a,x);return a
ready=read(S/'probe-ready-attempt2.json');compile=read(S/'probe-compile2/identity.json');receipt=read(S/'probe-run2/result.json');obs=read(S/'probe-run2/observation.json')
assert receipt['exit']==0 and not receipt['throughput_evidence'] and not receipt['concurrent_benchmark']
assert ready['source']==compile['source']and ready['image']==receipt['image']
verify(ready['source']);verify(ready['image']);verify(compile['object']);verify(ready['link_plan'])
for x in ready['private_sources']:verify(x)
link=read(ready['link_plan']['path']);assert compile['object']in link['inputs']
source=Path(ready['source']['path']).read_text();assert ready['source']['sha256']=='2e47688e59c52909b2d7ac4786ef1797baf9f48a5908bb3c441c99458ecdcee0'
a=source.index('  auto recovered = model.create_session(resume, old_prefix);');b=source.index('  next_pin.reset();',a);tail=source[a:b]
assert 'std::weak_ptr<const q::cache::Snapshot> retired_prefix = old_prefix;'in tail
assert tail.index('old_prefix.reset();')<tail.index('model.evaluate(*recovered')
assert 'retired_prefix.expired()'in tail and 'model.snapshot_versions.live == 1'in tail
assert '  auto old_prefix = session->head;'in source
raw=json.loads(next(x for x in reversed((S/'probe-run2/stdout.log').read_text().splitlines())if x.startswith('{')));assert raw==obs
assert obs==dict(status='PASS',capacity=256,resident_limit=1,old_prefix_tokens=129,cancelled_candidate_tokens=130,directory_reported_bytes=0,old_prefix_logical_lease_bytes=21307392,managed_bytes_while_native_pending=42418224,managed_backing_bytes=42418224,collector_calls=133987,dropped_live_public_completion=True,cancel_means_native_preemption=False,timing_comparison=False)
steps=[]
for line in(S/'probe-run2/stderr.log').read_text().splitlines():
 if re.match(r'^retirement_(prefill|decode1|recovered) ',line):
  fields=dict(re.findall(r'(\w+)=([^\s]+)',line));steps.append(dict(name=line.split()[0],tokens=int(fields['tokens']),visible=int(fields['visible']),next=int(fields['next'])))
assert [(x['visible'],x['next'])for x in steps]==[(128,958),(129,71163),(130,369)]
report=dict(status='PASS: prior final-resume N1 scope finding is fixed in source and the actual attempt2 execution passed.',
 prior_finding=ident(O/'probe-scope-review.json'),current_runtime_only='probe-run2 / probe-ready-attempt2 / probe-compile2; attempt1 retained as historical, not substituted',
 sources=dict(probe=ready['source'],private_sources=ready['private_sources']),image=ready['image'],object=compile['object'],compile_identity=ident(S/'probe-compile2/identity.json'),ready=ident(S/'probe-ready-attempt2.json'),link_plan=ready['link_plan'],
 receipt=ident(S/'probe-run2/result.json'),observation=ident(S/'probe-run2/observation.json'),stdout=ident(S/'probe-run2/stdout.log'),stderr=ident(S/'probe-run2/stderr.log'),
 n1_fix=dict(line=source[:a].count('\n')+1,sequence=['Construct new Session on the existing complete129prefix without allocating an initial state.','Keep only a weak reference for old identity, reset the external strong alias before resume evaluate.','After actual resumed length130 commit, require oldweak expired and actual snapshot_versions.live==1.'],
 proof='These final assertions precede PASS output and the observed process exit0. Endlive1 is an executed source assertion, not an invented observation JSON field. The prior committed129 payload stability checks remain before adoption; no hidden extra retained Snapshot is used to assert it afterward.'),
 actual_fields=obs,returned_decisions=steps,
 checked_scope=['The real original CUDAQueue hostfunc signals entered before Graph submit and is released before Context drain on every unwind path.','With native work blocked, stopping/retiring cannot collect or readmit same/other ID; dropping the original public Completion still cannot reclaim candidate/native dirty ownership.','After actual gate release the same collector succeeds, candidate weak ref expires, all12dirty K/V bank pages can reacquire pristine state, and directory slot is reused.','The managed backing stays42418224B while pending. Directory0bytes and logical retained lease21307392B are intentionally different counters; neither is physical GPU peak.'],
 limits=['This is one explicit Commands replay cancellation/retirement diagnostic. It does not establish CUDA native preemption or captured-mode cancellation.','The retained payload spot checks are first64bytes of one conv and one GDN lease plus KV page metadata/count; not all24layer state bits. Separate52decisionvectors and full main/pressure observations are covered in runtime-comparison.json.','133987collector invocations are a bounded poll-loop observation, not a throughput metric or claim of an optimal polling policy.','No new build, model execution, device query, source edit or GPU work by this reviewer.'])
p=O/'probe-review.json';p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(ident(p))
