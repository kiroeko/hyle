"""Incremental host owners against the last verified native closure."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / '.scratch/qwen-prefix-20261021'
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

def compile_owner(mode, attempt):
    source = R / ('src/graph/resources.cc' if mode == 'resources' else
                  'tools/qwen35_text/' + ('main.cc' if mode == 'qwen' else 'retirement_probe.cc'))
    recipe = P / ('core-checks/attempt1/graph--resources/identity.json' if mode == 'resources' else
                  'checks/attempt3/identity.json')
    out = S / f'{mode}-compile{attempt}'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    frozen = b.identity(source)
    private = [b.identity(p) for p in sorted(source.parent.glob('*'))
               if p.suffix in ('.cc', '.h')] if mode != 'resources' else [frozen]
    for row in private:
        snap = out / 'source' / Path(row['path']).relative_to(R)
        snap.parent.mkdir(parents=True, exist_ok=True)
        snap.write_bytes(Path(row['path']).read_bytes())
    command = b.host_command(c.read(recipe)['command'], source, mode, out)
    assert all(x in command for x in ('/W4', '/WX', '/O2', '/MD'))
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen,
        private_sources=private, recipe=b.identity(recipe), CXX=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    deps = c.read(out / (mode + '-deps.json'))['Data']
    record = dict(source=frozen, object=b.identity(out / (mode + '.obj')), command=command,
        private_sources=private, replaced_object=c.read(recipe)['object'],
        dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
    assert all(h.same(x) for x in private + record['dependencies'])
    c.save(out / 'identity.json', record)
    return record

def link(mode, attempt, records):
    prior_path = P / ('ready-attempt3.json' if mode in ('qwen', 'probe') else mode + '-ready-attempt1.json')
    prior = c.read(prior_path)
    base = c.read(prior['link_plan']['path'])
    assert all(h.same(x) for x in base['inputs'])
    assert all(h.same(x['object']) and h.same(x['source']) and
               all(h.same(d) for d in x['dependencies']) for x in records)
    replacements = {c.key(x['replaced_object']['path']):x['object'] for x in records}
    assert all(sum(c.key(x['path']) == key for x in base['inputs']) == 1 for key in replacements)
    out = S / f'{mode}-link{attempt}'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / (mode + '.exe')
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x
        for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(prior['link_plan']['path']),
        replaced_inputs=[dict(before=x['replaced_object'], after=x['object']) for x in records],
        links=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    for dll in Path(prior['image']['path']).parent.glob('*.dll'):
        os.link(dll, out / dll.name)
    runtime = c.read(prior['runtime_environment']['path'])
    runtime['PATH'] = env['PATH']
    runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
    if mode == 'cpu' and 'CPU_native_overlay' in runtime:
        runtime['CPU_native_overlay']['destination'] = b.identity(out / 'hyle_ggml_cpu_append_hyca.dll')
    c.save(out / 'runtime-environment.json', runtime)
    owner = next((x for x in records if x['source']['path'].endswith(('main.cc', 'retirement_probe.cc'))), None)
    c.save(S / f'{mode}-ready-attempt{attempt}.json', dict(image=b.identity(image),
        source=owner['source'] if owner else prior['source'],
        private_sources=owner['private_sources'] if owner else [],
        fresh_sources=[x['source'] for x in records], link_plan=b.identity(out / 'link-plan.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        CXX=int(owner is not None), links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    print('READY', mode, str(image), flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('resources', 'qwen', 'probe', 'cpu', 'cuda'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--resources-attempt', type=int, default=1)
    args = parser.parse_args()
    if args.mode == 'resources':
        compile_owner(args.mode, args.attempt)
        return
    records = [c.read(S / f'resources-compile{args.resources_attempt}/identity.json')]
    if args.mode in ('qwen', 'probe'):
        records.append(compile_owner(args.mode, args.attempt))
    link(args.mode, args.attempt, records)

if __name__ == '__main__':
    main()
