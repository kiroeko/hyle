"""The exact meaningful CPU/CUDA fixtures, with only this turn's resources object changed."""
from pathlib import Path
S = Path(__file__).resolve().parent
R = S.parents[1]
source = (R / '.scratch/qwen-prefix-20261021/run_fixtures.py').read_text(encoding='utf-8')
exec(compile(source, str(Path(__file__).resolve()), 'exec'), globals())
