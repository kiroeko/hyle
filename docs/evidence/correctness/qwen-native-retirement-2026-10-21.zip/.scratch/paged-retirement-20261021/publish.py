"""Bounded source/command/result evidence, with no SDK, model or executable payloads."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile
S = Path(__file__).resolve().parent
R = S.parents[1]
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, d): p.write_text(json.dumps(d, indent=2, allow_nan=False) + '\n', encoding='utf-8')
def identity(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
sources = ['tools/qwen35_text/main.cc', 'tools/qwen35_text/session_cache.h',
    'tools/qwen35_text/prefix_cache.h', 'tools/qwen35_text/session_state.h',
    'tools/qwen35_text/schedule.h', 'tools/qwen35_text/session_schedule.h',
    'tools/qwen35_text/retirement_probe.cc', 'tools/qwen35_text/CMakeLists.txt',
    'src/graph/resources.cc']
docs = ['docs/developer/current-work.md', 'docs/developer/performance/decode.md', 'tools/qwen35_text/README.md']
correctness = R / 'docs/evidence/correctness/qwen-native-retirement-2026-10-21.json'
performance = R / 'docs/evidence/performance/qwen-retirement-publication-2026-10-21.json'
archive = correctness.with_suffix('.zip')
assert not any(p.exists() for p in (correctness, performance, archive))
assert read(S/'probe-run2/result.json')['exit'] == 0
assert read(S/'probe-run2/observation.json')['status'] == 'PASS'
assert read(S/'async-review/runtime-comparison.json')['all_byte_equal']
for folder in ('single-run1', 'multi-run1'):
    assert read(S/folder/'summary.json')['passed']
for mode in ('timing', 'memory'):
    runs = read(S/f'performance/{mode}/runs.json')
    assert len(runs) == (12 if mode == 'timing' else 4)
    assert all(x['process']['exit'] == 0 for x in runs)
save(S/'probe/final-root-freeze.json', dict(source=identity(R/sources[6]),
    CMake=identity(R/sources[7]), compile=identity(S/'probe-compile2/identity.json'),
    ready=identity(S/'probe-ready-attempt2.json'), runtime=identity(S/'probe-run2/result.json'),
    independent_review=identity(S/'async-review/probe-review.json'),
    revision='Root changed only final resume aliases: release external old prefix before commit so N1 remains one committed plus one serial candidate. Attempt1 pending-retirement proof was valid; its final resume retained two completed snapshots and is not the final N1 acceptance.'))
save(S/'run-notes.json', dict(
    harness_corrections=[
        'First canonical wrapper used the old default ready filename; failed before process creation. Explicit --ready selected actual qwen-ready-attempt1.json, then all canonical checks passed.',
        'First probe wrapper could not decode agent report JSON written using Windows default encoding; failed before process creation. Original bytes retained in probe/revisions, JSON repaired to explicit UTF8 before actual execution.',
        'Small ad-hoc result inspections first used missing aggregate keys/prompt kind/dict rows; failed host-only. Frozen independent review recomputes from actual phase seconds and uses all processes.'],
    actual_build_failures=0, actual_runtime_nonzero_exits=0,
    probe_attempt1_scope_correction='Pending-retirement assertions passed, but final continuation retained an unnecessary external committed alias. Root corrected probe only and reran attempt2; no main/core/performance rebuild or rerun was needed.',
    no_additional_measurement_for_publication=True))
paths = {}
allowed = {'.json','.py','.ps1','.diff','.patch','.log','.txt','.csv','.tsv','.cc','.h','.md','.original-bytes'}
for p in S.rglob('*'):
    if p.is_file() and p.suffix in allowed and 'tmp' not in p.relative_to(S).parts and '__pycache__' not in p.parts:
        if p.name != 'published.json': paths[p.relative_to(R).as_posix()] = p
for relative in sources + docs:
    paths[relative] = R/relative
inventory = [dict(archive_path=name, **identity(p)) for name,p in sorted(paths.items())]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name,p in sorted(paths.items()): z.write(p,name)
    z.writestr('manifest.json',json.dumps(dict(files=inventory,
        excluded='Executables, objects, import libraries, maps, SDKs, model weight payloads, raw decision vector payloads. Vector bytes remain in retained scratch baselines/actual traces and are identified by independent reports.'),indent=2))
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
ready = read(S/'qwen-ready-attempt1.json')
table = read(S/'performance/public-table.json')
shared = dict(date='2026-10-21', created_utc=datetime.now(timezone.utc).isoformat(),
    archive=identity(archive), archive_file_count=len(inventory),
    source_identities=[identity(R/x) for x in sources],
    build=dict(CXX_compiles=4, links=5, NVCC_compiles=0, SDK_builds=0,
        current_model=ready['image'], current_ready=identity(S/'qwen-ready-attempt1.json'),
        method='Changed host owners only; reused the prior192-input native closure, installed compiler/SDK and hardlinked one existing CPU selector DLL. Probe has a distinct EXCLUDE_FROM_ALL target and is absent from the timed model link.'),
    prior_evidence=['docs/evidence/correctness/qwen-prefix-reuse-2026-10-21.json',
        'docs/evidence/performance/qwen-indexed-preparation-2026-10-21.json'])
save(correctness, dict(**shared,
    scope='Actual Windows RTX4070 Qwen text consumer and original CPU/CUDA page append fixtures; not universal serving or other-backend acceptance.',
    implementation=[
        'Original evaluate is prepare -> submit -> finish; one original StepState retains Completion/IO/base/candidate until actual commit or abort. No duplicate math executor.',
        'Session stop withdraws admission/publication; try_retire polls nonblockingly and retains original typed append/outcome gates. Dropping public Completion or unsupported cancellation does not prove retirement.',
        'Original SessionCache entry becomes invisible/retiring but remains counted/charged; pin release does not restore visibility. Same or replacement ID cannot use its slot until actual owner collection.',
        'Serial model candidate admission preserves N committed +1 candidate; physical shared pool stays reserved/charged after directory eviction.',
        'Invocation result publishes all owned WriteLease records from the fixed caller prefix; appended anonymous records hold reads/writer pointers and need not be rescanned for every output.'],
    actual_native_probe=dict(final_attempt=2, result=identity(S/'probe-run2/result.json'),
        observation=read(S/'probe-run2/observation.json'), review=identity(S/'async-review/probe-review.json'),
        assertions='P128+D1=129 partial tail; actual host callback blocks original CUDA Queue after preparation; submit actual Model Graph; withdraw directory/stop/drop live public Completion; two pending collections retain same candidate, old head, N+1 version count, serial admission and42,418,224 managed bytes. Same/replacement IDs and original dirty page reacquisition reject. Release gate; original typed retirement permits collection; all12 bank pages reacquire uninitialized, candidate expires. Old prefix resumes after releasing external alias; successful commit has exactly one completed version.',
        final_route='Commands, not a captured Graph cancellation experiment. Captured ordinary path has separate normal numerical regression.',
        collector_calls_are_diagnostic_poll_count_not_latency=True),
    numerical_regression=dict(total_actual_decision_vectors=142,
        canonical_single=identity(S/'single-run1/summary.json'), canonical_multi=identity(S/'multi-run1/summary.json'),
        prefix=identity(S/'async-review/runtime-comparison.json'),
        scope='18single +72four-session eviction/rebuild +52prefix/branch/full-hit/pressure vectors, all byte equal to existing matching-partition baselines. These are hidden/logits, not a full dump of12KV and36state pools or independent model quality acceptance.'),
    source_review=identity(S/'async-review/source-review.json'),
    original_append_fixtures={m:dict(result=identity(S/f'{m}-run1/result.json'),stdout=identity(S/f'{m}-run1/stdout.log')) for m in ('cpu','cuda')},
    remaining=['Exclusive suffix append needs real committed-prefix/read and uncommitted-suffix/write authority; current whole-page lease contract does not permit a use_count shortcut.',
        'Full consumers on Linux/macOS/native Apple/Vulkan; native concurrent-throughput scheduling.',
        'Actual MTP, image encoder/mmproj and remaining selected-model/quantization/architecture work.']))
save(performance, dict(**shared,
    scope=table['scope'], results=table,
    independent_review=identity(S/'performance/independent-review.json'),
    public_table=identity(S/'performance/public-table.json'),
    changed_objects='Exactly main and resources among192link inputs; current async consumer/directory and common fixed-prefix output publication changed together. Prefix is off; no cancel/retire journey is timed.',
    conclusion='Current vs before is effectively flat: process-median decode-0.186%, session+0.140%, prefill+1.303%, overlapping ranges. No stable performance improvement or regression established. Current vs llama median decode-4.525%, session-1.739%, aggregate prefill+16.533%. Dedicated observed peak unchanged from before. All four arms have lower absolute rates than the preceding window; cross-window difference is not attributed to this patch.',
    next_action='Quantify current paged versus original dense on a small same-work native trace: tail COW/copies, capture ranges, metadata waits and complete state publication. Change the dominant removable cost; do not rerun windows to select a favorable median.',
    limits=table['limits']))
save(S/'published.json', dict(files=[identity(p) for p in (correctness,performance,archive)],
    archived_bytes=sum(x['bytes'] for x in inventory), archive_files=len(inventory)))
print(json.dumps(read(S/'published.json'),indent=2))
