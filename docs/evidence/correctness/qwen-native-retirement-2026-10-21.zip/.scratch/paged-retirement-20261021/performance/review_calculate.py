"""Independent host-only recomputation. Never launches a consumer or queries a device."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
from collections import Counter
import hashlib
import json
import math
import re
import shlex
import statistics

S = Path(__file__).resolve().parent
assert (S/'timing/summary.json').exists() and (S/'memory/summary.json').exists(), 'root runs not complete'
R = S.parents[2]
D = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21'
F = D / 'first-decode-startup-2026-10-21'
W = F / 'layout-workspace-facts-reuse-2026-10-21'
KEYS = ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
        'gpu_shared_bytes', 'gpu_total_bytes']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def verify(record):
    actual = identity(record['path'])
    assert actual == record, (actual, record)
    return actual


def stats(values, samples=True):
    result = dict(count=len(values), min=min(values) if values else None,
                  median=statistics.median(values) if values else None,
                  max=max(values) if values else None)
    if samples:
        result['samples'] = values
    return result


def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (a, b)


def steps(stderr):
    result = []
    pending = None
    for line in stderr.splitlines():
        if line.startswith('prepared T='):
            pairs = dict(re.findall(r'(\w+)=([^\s]+)', line))
            pending = {k: int(pairs[k]) for k in ['T', 'visible', 'capture_recorded', 'capture_reused']}
            pending['replay'] = pairs['replay']
            pending['cold_batch_seconds'] = float(pairs['cold_batch_seconds'])
        match = re.match(r'^(round(\d+)_(prefill|decode(\d+)))\s+tokens=', line)
        if not match:
            continue
        fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
        row = dict(name=match[1], turn=int(match[2]), kind='prefill' if match[3] == 'prefill' else 'decode',
                   local=int(match[4]) if match[4] else None, tokens=int(fields['tokens']),
                   visible=int(fields['visible']), predicted=int(fields.get('next', fields.get('predicted'))),
                   step_seconds=float(fields['step_seconds']))
        for key in ['seconds','submit_seconds']:
            if key in fields: row[key] = float(fields[key])
        if pending:
            assert row['visible'] == pending['visible'] and row['tokens'] == pending['T']
            row['prepared'] = pending
            pending = None
        result.append(row)
    assert pending is None
    return result


plan = read(S / 'timing/inputs.json')['plan']
assert plan['processed_tokens'] == 864 and plan['generated_tokens'] == 99
assert plan['phase_count'] == 6 and plan['turn_count'] == 3
manifest = verify(plan['manifest'])
manifest_path = Path(manifest['path'])
input_files = []
position = 0
expected_steps = []
for line, phase in zip(manifest_path.read_text().splitlines(), plan['phases'], strict=True):
    kind, relative = shlex.split(line)
    assert kind == ('prompt' if phase['kind'] == 'prefill' else 'decode')
    path = manifest_path.parent / relative
    ids = [int(x) for x in path.read_text().split()]
    assert ids == phase['ids'] and len(ids) == phase['input_tokens']
    assert all(0 <= x < 248320 for x in ids)
    assert phase['visible_before'] == position
    input_files.append(identity(path))
    count = 1 if kind == 'prompt' else len(ids)
    assert count == phase['calls']
    for i in range(count):
        n = len(ids) if kind == 'prompt' else 1
        position += n
        expected_steps.append(dict(name=phase['name'] if kind == 'prompt' else phase['name'] + str(i + 1),
                                   tokens=n, visible=position))
    assert phase['visible_tokens'] == position
assert position == 864 and len(expected_steps) == 99

timing_input = read(S / 'timing/inputs.json')
memory_input = read(S / 'memory/inputs.json')
assert timing_input['plan'] == memory_input['plan']
assert timing_input['order'] == ['current','before','dense','peer','peer','dense','before','current','before','current','peer','dense']
assert memory_input['order'] == ['before','current','dense','peer']
assert timing_input['profiler'] is False and timing_input['memory_monitor'] is False
assert memory_input['profiler'] is False and memory_input['memory_monitor'] is True
images = {k: verify(v) for k, v in timing_input['images'].items()}
assert images == memory_input['images']

processes = []
raw_ids = []
driver_summary = read(S / 'timing/summary.json')
recorded_runs = read(S / 'timing/runs.json')
for index, variant in enumerate(timing_input['order'], 1):
    folder = S / 'timing' / f'{index:02}-{variant}'
    receipt = read(folder / 'result.json')
    assert receipt['exit'] == 0 and not receipt.get('timeout') and not receipt['reader_errors']
    assert receipt['image'] == images[variant]
    assert receipt['command'] == timing_input['commands'][index - 1]['command']
    assert '--trace' not in receipt['command'] and '--preparation-diagnostics' not in receipt['command']
    stderr = (folder / 'stderr.log').read_text()
    raw = read(folder / 'peer-result.json') if variant == 'peer' else json.loads(
        next(x for x in reversed((folder / 'stdout.log').read_text().splitlines()) if x.startswith('{')))
    for key in ['processed_tokens', 'generated_tokens', 'phase_count', 'turn_count']:
        assert raw[key] == plan[key]
    assert not raw.get('diagnostic', False)
    actual_steps = steps(stderr)
    assert len(actual_steps) == 99
    for actual, expected in zip(actual_steps, expected_steps, strict=True):
        for key in ['name', 'tokens', 'visible']:
            assert actual[key] == expected[key]
        assert actual['step_seconds'] > 0
    ids = raw.get('predicted_ids', raw.get('generated_ids'))
    assert ids == [x['predicted'] for x in actual_steps] and len(ids) == 99
    raw_ids.append(ids)
    phases = []
    for p, expected in zip(raw['phases'], plan['phases'], strict=True):
        for key in ['name', 'kind', 'turn', 'input_tokens']:
            assert p[key] == expected[key]
        assert p['context_before'] == expected['visible_before'] and p['context_after'] == expected['visible_tokens']
        selected = [x for x in actual_steps if x['turn'] == p['turn'] and x['kind'] == p['kind']]
        assert len(selected) == expected['calls']
        rounded_step_sum = sum(x['step_seconds'] for x in selected)
        # stderr uses six significant digits; JSON keeps the unrounded double sum.
        precision_bound = sum(5.1 * 10 ** (math.floor(math.log10(x['step_seconds'])) - 6) for x in selected)
        assert abs(rounded_step_sum - p['step_sum_seconds']) <= precision_bound
        phases.append(dict(name=p['name'], kind=p['kind'], turn=p['turn'],
                           context_before=p['context_before'], context_after=p['context_after'],
                           input_tokens=p['input_tokens'], seconds=p['seconds'],
                           step_sum_seconds=p['step_sum_seconds'], tps=p['input_tokens'] / p['seconds'],
                           first_two_step_seconds=sum(x['step_seconds'] for x in selected[:2]) if p['kind'] == 'decode' else None,
                           decode7_to32_tps=26 / sum(x['step_seconds'] for x in selected[6:]) if p['kind'] == 'decode' else None))
    pre = sum(x['seconds'] for x in phases if x['kind'] == 'prefill')
    dec = sum(x['seconds'] for x in phases if x['kind'] == 'decode')
    step_sum = sum(x['step_sum_seconds'] for x in phases)
    totals = dict(session_seconds=raw['session_seconds'], startup_total_seconds=raw['startup_total_seconds'],
                  processed_tokens_per_second=864 / raw['session_seconds'], output_tokens_per_second=99 / raw['session_seconds'],
                  cold_processed_tokens_per_second=864 / raw['startup_total_seconds'], cold_output_tokens_per_second=99 / raw['startup_total_seconds'],
                  compute_step_sum_seconds=step_sum, session_minus_step_sum_seconds=raw['session_seconds'] - step_sum)
    for key, value in totals.items():
        close(value, recorded_runs[index - 1]['observation']['metrics'][key])
    totals.update(aggregate_prefill_tps=768 / pre, aggregate_decode_tps=96 / dec,
                  prefill_seconds=pre, decode_seconds=dec)
    capture_counts = Counter((x['tokens'], x['prepared']['replay'], x['prepared']['capture_recorded'],
                             x['prepared']['capture_reused']) for x in actual_steps if 'prepared' in x)
    loading = dict(raw.get('loading', {}))
    for line in stderr.splitlines():
        if line.startswith('weights_load_seconds='):
            loading['model_load_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('first_token_elapsed_seconds='):
            loading['first_token_elapsed_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('initialized '):
            for key, value in re.findall(r'(\w+)=([^\s]+)', line):
                try:
                    loading[key] = float(value)
                except ValueError:
                    pass
    process = dict(index=index, variant=variant, result=identity(folder / 'result.json'),
                   stdout=identity(folder / 'stdout.log'), stderr=identity(folder / 'stderr.log'),
                   command=receipt['command'], metrics=totals, phases=phases, loading=loading,
                   decision_calls=99, decode_calls=96, input_tokens=864,
                   ids_sha256=hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest(),
                   replay_counts=[dict(tokens=k[0], replay=k[1], recorded=k[2], reused=k[3], calls=v)
                                  for k, v in sorted(capture_counts.items())],
                   recapture_steps=[dict(name=x['name'], visible=x['visible'], recorded=x['prepared']['capture_recorded'], reused=x['prepared']['capture_reused'])
                                    for x in actual_steps if 'prepared' in x and x['prepared']['capture_recorded']])
    process['pure_reuse_cold_by_turn'] = [dict(turn=turn, cold_seconds=stats([row['prepared']['cold_batch_seconds'] for row in actual_steps if row['turn']==turn and row['kind']=='decode' and row.get('prepared',{}).get('capture_recorded')==0])) for turn in range(1,4)] if variant!='peer' else None
    process['cold_by_turn_all_decode'] = [dict(turn=turn, cold_seconds=stats([row['prepared']['cold_batch_seconds'] for row in actual_steps if row['turn']==turn and row['kind']=='decode'])) for turn in range(1,4)] if variant!='peer' else None
    processes.append(process)
assert all(ids == raw_ids[0] for ids in raw_ids)
groups = {}
for variant in images:
    selected = [x for x in processes if x['variant'] == variant]
    groups[variant] = dict(metrics={k: stats([x['metrics'][k] for x in selected]) for k in selected[0]['metrics']},
                           phases={p['name']: stats([x['phases'][j]['tps'] for x in selected])
                                   for j, p in enumerate(selected[0]['phases'])},
                           loading={k:stats([x['loading'][k] for x in selected]) for k,v in selected[0]['loading'].items()
                                    if isinstance(v, (float,int))})
    for key, value in driver_summary['groups'][variant]['metrics'].items():
        assert value == groups[variant]['metrics'][key]
    for name, value in driver_summary['groups'][variant]['phases'].items():
        assert value == groups[variant]['phases'][name]
    assert groups[variant]['loading'] == driver_summary['groups'][variant]['loading']

memory = {}
peak_keys = dict(working_set_bytes='sampled_max_working_set_bytes', private_commit_bytes='sampled_max_private_commit_bytes',
                 gpu_dedicated_bytes='sampled_peak_gpu_dedicated_bytes', gpu_shared_bytes='sampled_peak_gpu_shared_bytes',
                 gpu_total_bytes='sampled_peak_gpu_total_bytes')
for index, variant in enumerate(memory_input['order'], 1):
    folder = S / 'memory' / f'{index:02}-{variant}'
    receipt = read(folder / 'result.json')
    assert receipt['exit'] == 0 and receipt['memory_only'] and not receipt['throughput_evidence']
    assert receipt['image'] == images[variant]
    data, reported = read(folder / 'memory.json'), read(folder / 'memory-summary.json')
    assert not data['gpu_setup_error'] and not data['thread_error']
    samples = data['samples']
    running = [x for x in samples if x['process_running']]
    assert len(samples) == reported['sample_count'] and len(running) == reported['running_sample_count']
    peaks = {key: max((x[key] for x in samples if x.get(key) is not None), default=None) for key in KEYS}
    for key, value in peaks.items():
        assert value == data['peaks'][peak_keys[key]]
    assert peaks['gpu_total_bytes'] == max((x['gpu_dedicated_bytes'] + x['gpu_shared_bytes'] for x in samples
        if x.get('gpu_dedicated_bytes') is not None and x.get('gpu_shared_bytes') is not None), default=None)
    intervals = [(b['timestamp_ns'] - a['timestamp_ns']) / 1e6 for a, b in zip(running, running[1:])]
    costs = [x['sample_duration_ns'] / 1e6 for x in running]
    assert stats(intervals) == reported['actual_sample_gaps_ms'] and stats(costs) == reported['sample_cost_ms']
    assert reported['sampled_peaks'] == data['peaks']
    boundaries = {x['name']: x['timestamp_ns'] for x in receipt['markers']}
    ready_rows = [x for x in running if boundaries.get('ready_before_prefill') is not None and
                  boundaries['ready_before_prefill'] <= x['timestamp_ns'] <= boundaries['round1_prefill_begin']]
    assert reported['ready_baseline']['unknown'] == (not ready_rows)
    assert reported['ready_baseline']['sample'] == (ready_rows[-1] if ready_rows else None)
    windows = {}
    for phase in plan['phases']:
        name = phase['name'];begin, end = boundaries[name + '_begin'], boundaries[name + '_end']
        rows = [x for x in running if begin <= x['timestamp_ns'] <= end]
        original = reported['phase_windows'][name]
        assert original['sample_count'] == len(rows) and not original['missing_boundary']
        vals = {k: stats([x[k] for x in rows if x.get(k) is not None], samples=False) for k in KEYS}
        for k in KEYS:
            for stat in ['count', 'min', 'median', 'max']:
                assert vals[k][stat] == original['values'][k][stat]
            assert sum(x.get(k) is None for x in rows) == original['null_sample_counts'][k]
        before = max((x for x in running if x['timestamp_ns'] <= begin), key=lambda x:x['timestamp_ns'], default=None)
        after = min((x for x in running if x['timestamp_ns'] >= end), key=lambda x:x['timestamp_ns'], default=None)
        ages = dict(before=begin-before['timestamp_ns'] if before else None, after=after['timestamp_ns']-end if after else None)
        delta = {k:after[k]-before[k] if before and after and before.get(k) is not None and after.get(k) is not None else None for k in KEYS}
        assert ages == original['bracket_ages_ns'] and delta == original['bracket_delta_bytes']
        windows[name] = dict(samples=len(rows), values=vals, null_counts=original['null_sample_counts'],
                             bracket_delta_bytes=delta, bracket_ages_ns=ages)
    memory[variant] = dict(result=identity(folder / 'result.json'), raw=identity(folder / 'memory.json'),
                           summary=identity(folder / 'memory-summary.json'), sample_count=len(samples), running_sample_count=len(running),
                           requested_interval_seconds=data['requested_interval_s'], actual_gaps_ms=stats(intervals, False),
                           sample_cost_ms=stats(costs, False), sampled_peaks_bytes=peaks,
                           null_counts={k: sum(x.get(k) is None for x in running) for k in KEYS},
                           ready_baseline_unknown=reported['ready_baseline']['unknown'], phases=windows,
                           setup_error=data['gpu_setup_error'], thread_error=data['thread_error'])


# Exact changed link closure, rather than names inferred from the purpose text.
current_ready = read(S.parent/'qwen-ready-attempt1.json')
before_ready = read(R/'.scratch/qwen-prefix-20261021/ready-attempt3.json')
assert current_ready['image'] == images['current']
assert before_ready['image'] == images['before']
assert images['before']['sha256']=='e155b89db7003dfd9a215438faf44922060b7c4b028e4ef83cc4b86d79f98098'
assert images['current']['sha256']=='2941d9df0192ce2422b1d7b668f029800ce5b59134d11bcebaf3403f2f8f26e0'
current_link=read(verify(current_ready['link_plan'])['path'])
before_link=read(verify(before_ready['link_plan'])['path'])
current_counts=Counter(x['sha256'] for x in current_link['inputs'])
before_counts=Counter(x['sha256'] for x in before_link['inputs'])
changed=[read(S.parent/p/'identity.json') for p in ['resources-compile1','qwen-compile1']]
assert len(current_link['inputs'])==len(before_link['inputs'])==192
assert sum((current_counts-before_counts).values())==sum((before_counts-current_counts).values())==2
assert Counter(x['object']['sha256'] for x in changed)==current_counts-before_counts
assert {Path(x['source']['path']).name for x in changed}=={'main.cc','resources.cc'}
for row in changed:
    verify(row['source']); verify(row['object'])
    assert row['object'] in current_link['inputs'] and row['replaced_object'] in before_link['inputs']
    for dep in row['dependencies']: verify(dep)
assert identity(S.parent/'implementation/before/main.cc')['sha256']==before_ready['source']['sha256']
assert identity(S.parent/'implementation/before/session_cache.h')['sha256']==next(x['sha256'] for x in before_ready['private_sources'] if Path(x['path']).name=='session_cache.h')
environments={arm:read(verify(path)['path']) for arm,path in timing_input['environments'].items()}
staged=lambda env:{Path(x['path']).name:x['sha256'] for x in env.get('staged_dlls',[])}
assert staged(environments['current'])==staged(environments['before'])
for arm,env in environments.items():
    for dll in env.get('staged_dlls',[]): verify(dll)

# Monitored runs are correctness/workload evidence only, never timing samples.
for index,variant in enumerate(memory_input['order'],1):
    folder=S/'memory'/f'{index:02}-{variant}'
    raw=read(folder/'peer-result.json') if variant=='peer' else json.loads(next(x for x in reversed((folder/'stdout.log').read_text().splitlines()) if x.startswith('{')))
    assert [raw[k] for k in ['processed_tokens','generated_tokens','phase_count','turn_count']]==[864,99,6,3]
    ids=raw.get('predicted_ids',raw.get('generated_ids'));assert ids==raw_ids[0]
    actual_steps=steps((folder/'stderr.log').read_text());assert len(actual_steps)==99
    for actual,expected in zip(actual_steps,expected_steps,strict=True):
        assert all(actual[k]==expected[k] for k in ['name','tokens','visible'])
    assert ids==[x['predicted'] for x in actual_steps]
    for actual,expected in zip(raw['phases'],plan['phases'],strict=True):
        assert all(actual[k]==expected[k] for k in ['turn','kind','name','input_tokens'])
        assert actual['context_before']==expected['visible_before'] and actual['context_after']==expected['visible_tokens']
    memory[variant]['workload_and_predictions_match']=True
    memory[variant]['stdout']=identity(folder/'stdout.log');memory[variant]['stderr']=identity(folder/'stderr.log')

rates={}
for arm in images:
    selected=[x for x in processes if x['variant']==arm];assert len(selected)==3
    rates[arm]=dict(prefill_TPS=2304/sum(x['metrics']['prefill_seconds'] for x in selected),
        decode_TPS=288/sum(x['metrics']['decode_seconds'] for x in selected),
        session_output_TPS=297/sum(x['metrics']['session_seconds'] for x in selected),
        session_processed_TPS=2592/sum(x['metrics']['session_seconds'] for x in selected))
    for proc in selected:
        stderr=Path(proc['stderr']['path']).read_text()
        compile_lines=[line for line in stderr.splitlines() if line.startswith('compiled text finite family ')]
        proc['finite_family_cold_seconds']=float(dict(re.findall(r'(\w+)=([^\s]+)',compile_lines[0]))['cold_seconds']) if compile_lines else None
cold={}
for arm in ['current','before','dense']:
    selected=[x for x in processes if x['variant']==arm]
    cold[arm]=[dict(turn=turn,seconds=stats([v for proc in selected for v in proc['pure_reuse_cold_by_turn'][turn-1]['cold_seconds']['samples']])) for turn in range(1,4)]
    for proc in selected:
        assert [x['cold_seconds']['count'] for x in proc['pure_reuse_cold_by_turn']]==[30,30,30]
        hot=[x for x in proc['replay_counts'] if x['tokens']==1 and x['recorded']==0]
        assert sum(x['calls'] for x in hot)==90
        assert all(x['reused']==(1 if arm=='dense' else 7) for x in hot)
comparison={other:{key:(rates['current'][key]/rates[other][key]-1)*100 for key in rates['current']} for other in ['before','dense','peer']}
snapshots={mode:{point:dict(receipt=identity(S/mode/(point+'.json')),gpu_stdout=identity(S/mode/(point+'-gpu.stdout.log')),gpu_values=(S/mode/(point+'-gpu.stdout.log')).read_text().strip()) for point in ['window-before','window-after']} for mode in ['timing','memory']}
MiB=1048576
rows=[]
for arm in ['current','before','dense','peer']:
    g=groups[arm]; m=memory[arm]
    rows.append(dict(arm=arm,image_sha256=images[arm]['sha256'],
        process_count=3,prefill_TPS=g['metrics']['aggregate_prefill_tps'],decode_TPS=g['metrics']['aggregate_decode_tps'],
        session_output_TPS=g['metrics']['output_tokens_per_second'],session_wall_seconds=g['metrics']['session_seconds'],
        pooled_rates=rates[arm],
        turn_phase_TPS=g['phases'],loading=g['loading'],
        finite_family_cold_seconds=stats([p['finite_family_cold_seconds'] for p in processes if p['variant']==arm and p['finite_family_cold_seconds'] is not None]),
        sampled_peak_MiB={k:v/MiB if v is not None else None for k,v in m['sampled_peaks_bytes'].items()},
        memory_process_count=1,ready_baseline_unknown=m['ready_baseline_unknown'],
        memory_actual_gap_ms=m['actual_gaps_ms'],memory_sample_cost_ms=m['sample_cost_ms'],
        phase_delta_MiB={name:{k:v/MiB if v is not None else None for k,v in phase['bracket_delta_bytes'].items()} for name,phase in m['phases'].items()},
        pure_reuse_cold_median_ms_by_turn=[x['seconds']['median']*1000 for x in cold[arm]] if arm in cold else None))
limits=[
 'Three fresh unmonitored timing processes and one separately monitored memory process per arm in one window; no statistical significance, fixed clocks or exclusive-device condition established.',
 'Prompt256 plus32 teacher-forced decode inputs, repeated three times in one retained session (capacity1024);864 input tokens,96 actual decode calls and99 host-visible output IDs including3 prompt decisions. This is not natural free-running text, MTP, or multi-active-user throughput.',
 'Pooled decode is288/sum(the three process decode phase walls), prefill2304/sum(prefill phase walls), session297/sum(session walls). Each process96/sum3decode walls is separately retained; no mean of TPS.',
 'Loading/finite family/context setup have separate implementation scopes and reused OS/filesystem caches; model-load values are not cold-disk bandwidth measurements.',
 'Current vs before changes two objects together: consumer async episode split/directory lifecycle plus common graph fixed-prefix output publication. This window cannot divide benefit/cost between them. Prefix cache is off and no active retirement/cancellation is timed in this single-session workload.',
 'cold_batch_seconds ends before submit; output publication is after native completion. Do not assign publication scanning savings to cold preparation, nor infer per-function shares from aggregate walls.',
 '0record/7reuse covers90/96 actual decode calls per paged process;6 first-used slot calls and all prefill/cold preparations remain included in primary full phase/session walls.',
 'Sampled PSAPI/PDH peaks are lower bounds. Requested10ms differs from actual gap/cost distributions. Short phases can have no interior sample; bracket deltas use adjacent parent-time samples and stderr marker delivery may lag source execution.',
 'GPU total peak uses simultaneously available dedicated+shared values, not separate maxima. CPU working set/private commit/GPU shared may overlap and must not be added. Dedicated process counters are not exact allocation or device-global VRAM peaks.',
 'GPU before/after utilization and clocks are snapshots; after rolling utilization can include the just-finished inference and does not identify external background load. No review-triggered process/build/GPU/device query occurred.'
]
median_comparison={other:{label:(groups['current']['metrics'][key]['median']/groups[other]['metrics'][key]['median']-1)*100 for label,key in [('prefill_TPS','aggregate_prefill_tps'),('decode_TPS','aggregate_decode_tps'),('session_output_TPS','output_tokens_per_second')]}for other in ['before','dense','peer']}
table=dict(scope=dict(input_tokens=864,decode_calls=96,output_IDs=99,turns=3,capacity=1024,timing_per_arm=3,memory_per_arm=1),
 rows=rows,current_vs_other_median_rate_change_percent=median_comparison,current_pooled_rate_change_percent=comparison,limits=limits,
 definitions={'prefill_TPS':'per-process768/sum3prefill phase walls','decode_TPS':'per-process96/sum3decode phase walls','session_output_TPS':'99/session wall including prompt decision tokens','samples':'All3process rates retained; median/min/max are descriptive, not confidence intervals. Progress-table comparisons use the median process rates; pooled rates are separately labelled.'})
public=S/'public-table.json';public.write_text(json.dumps(table,indent=2,allow_nan=False)+'\n')
def summary_stats(value):
    return {k:v for k,v in value.items() if k!='samples'}
slim_processes=[]
for proc in processes:
    slim={k:v for k,v in proc.items() if k not in ['command','pure_reuse_cold_by_turn','cold_by_turn_all_decode']}
    slim['phases']=[{k:v for k,v in phase.items() if k not in ['first_two_step_seconds','decode7_to32_tps']}for phase in proc['phases']]
    slim['pure_reuse_cold_by_turn']=[dict(turn=row['turn'],cold_seconds=summary_stats(row['cold_seconds']))for row in proc['pure_reuse_cold_by_turn']]if proc['pure_reuse_cold_by_turn'] else None
    slim_processes.append(slim)
compact_cold={arm:[dict(turn=x['turn'],seconds=summary_stats(x['seconds']))for x in turns]for arm,turns in cold.items()}
report=dict(status='passed independent raw-file recomputation; all12timing+4memory actual exit0',
 script=identity(__file__),adapted_parser_source=identity(R/'.scratch/paged-prepare-20261021/performance/review_calculate.py'),
 driver=identity(S.parent/'performance.py'),original_runner=identity(F/'multiturn/multiturn_run.py'),
 public_table=identity(public),scope=table['scope'],inputs=dict(manifest=manifest,files=input_files),images=images,
 fairness=dict(identical_actual99predictions_all16=True,all99step_names_tokens_positions_match=True,all6phase_contexts_match=True,
    timing_order=timing_input['order'],memory_order=memory_input['order'],no_timing_monitor_or_profiler=True,
    no_trace_or_diagnostic=True,all_driver_timing_summary_statistics_independently_recomputed=True,snapshots=snapshots),
 closure=dict(current_ready=identity(S.parent/'qwen-ready-attempt1.json'),before_ready=identity(R/'.scratch/qwen-prefix-20261021/ready-attempt3.json'),
    current_link=verify(current_ready['link_plan']),before_link=verify(before_ready['link_plan']),link_inputs_each=192,
    changed_objects=[dict(source=x['source'],object=x['object'],replaced=x['replaced_object']) for x in changed],
    current_only_object_hashes=dict(current_counts-before_counts),before_only_object_hashes=dict(before_counts-current_counts),
    identical_current_before_staged_DLLs=staged(environments['current']),
    validation='The main compile receipt also records retirement_probe.cc as private source in its folder snapshot; no probe object is linked into qwen.exe and no probe process occurs in this timing/memory window. Fresh2object/source/dependency identities and executable/DLL/ready receipts rehashed; retained unchanged closure compared as exact recorded hash multisets, not rebuilt.'),
 aggregate_rates=rates,current_vs_other_median_rate_change_percent=median_comparison,current_pooled_rate_change_percent=comparison,
 timing_processes=slim_processes,pure_reuse_cold_by_turn=compact_cold,
 memory_observations=memory,limits=limits)
out=S/'independent-review.json';out.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(report=identity(out),public_table=identity(public),rates=rates,
 rows=[{k:r[k] for k in ['arm','prefill_TPS','decode_TPS','session_output_TPS','sampled_peak_MiB']}for r in rows],
 current_pooled_change_percent=comparison, current_median_change_percent=median_comparison),indent=2))
