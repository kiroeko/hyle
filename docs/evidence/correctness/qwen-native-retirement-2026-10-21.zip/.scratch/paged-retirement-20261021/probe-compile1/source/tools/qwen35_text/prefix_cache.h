// Process-local consumer policy. Snapshot owns the original state permissions;
// this bounded directory never manufactures a state or starts native work.
#pragma once

#include "schedule.h"
#include "session_state.h"
#include <algorithm>
#include <memory>
#include <span>

namespace qwen35::cache {
struct TokenPlan final {
  std::vector<std::int32_t> ids;
  std::vector<std::uint64_t> hashes;
  std::vector<std::size_t> checkpoints;
};
using TokenPlanRef = std::shared_ptr<const TokenPlan>;
inline TokenPlanRef token_plan(std::span<const benchmark::Phase> phases, std::size_t capacity) {
  auto result = std::make_shared<TokenPlan>();
  std::size_t total = 0;
  for (const auto &phase : phases) total = add(total, phase.ids.size());
  if (!total || total > capacity) throw std::runtime_error("prefix token plan exceeds context capacity");
  result->ids.reserve(total); result->hashes.reserve(add(total, 1));
  result->checkpoints.reserve(phases.size()); result->hashes.push_back(1469598103934665603ULL);
  for (const auto &phase : phases) {
    for (const auto id : phase.ids) {
      result->ids.push_back(id);
      result->hashes.push_back((result->hashes.back() ^ static_cast<std::uint32_t>(id)) * 1099511628211ULL);
    }
    result->checkpoints.push_back(result->ids.size()); // Prompt and complete turn boundaries only.
  }
  return result;
}
inline bool same_prefix(const TokenPlan &a, const TokenPlan &b, std::size_t count) noexcept {
  return count <= a.ids.size() && count <= b.ids.size() && a.hashes[count] == b.hashes[count] &&
      std::equal(a.ids.begin(), a.ids.begin() + static_cast<std::ptrdiff_t>(count), b.ids.begin());
}

// Rebuild recipe, not a cache key. A hit may import a differently partitioned
// legal state; rebuilding must replay the actual source chunks, not a later
// logical prompt that happened to contain those same tokens.
struct ReplayChunk final {
  TokenPlanRef input;
  std::size_t first = 0, count = 0;
  std::int32_t next_id = -1;
};
struct ReplayHistory final {
  std::vector<ReplayChunk> chunks;
  std::size_t length = 0, capacity = 0;
  explicit ReplayHistory(std::size_t limit) : capacity(limit) { chunks.reserve(limit); }
  void append(TokenPlanRef input, std::size_t first, std::size_t count, std::int32_t next) {
    if (!input || !count || length > capacity || first != length || first > input->ids.size() || count > input->ids.size() - first ||
        count > capacity - length || chunks.size() == chunks.capacity() || next < 0)
      throw std::runtime_error("invalid actual prefix rebuild chunk");
    chunks.push_back({std::move(input), first, count, next}); length += count;
  }
};
struct ReplayPrefix final {
  std::shared_ptr<const ReplayHistory> history;
  std::size_t chunks = 0, length = 0;
};
inline std::shared_ptr<ReplayHistory> copy_history(const ReplayPrefix &prefix, std::size_t capacity) {
  if (!prefix.history || prefix.chunks > prefix.history->chunks.size())
    throw std::runtime_error("prefix is missing its actual rebuild history");
  auto result = std::make_shared<ReplayHistory>(capacity);
  for (std::size_t i = 0; i < prefix.chunks; ++i) {
    const auto &part = prefix.history->chunks[i];
    result->append(part.input, part.first, part.count, part.next_id);
  }
  if (result->length != prefix.length) throw std::runtime_error("prefix rebuild length differs from its state");
  return result;
}

class PrefixCache final {
  struct Entry final {
    TokenPlanRef input;
    SnapshotRef snapshot;
    ReplayPrefix replay;
    bool pinned = false;
  };
  std::vector<Entry> entries_;
  std::vector<std::size_t> lru_;
  void touch(std::size_t slot) noexcept {
    const auto it = std::find(lru_.begin(), lru_.end(), slot);
    if (it != lru_.end()) lru_.erase(it);
    lru_.push_back(slot); // Fixed entry capacity was reserved cold.
  }
public:
  class Hit final {
    friend class PrefixCache;
    PrefixCache *owner_ = nullptr;
    std::size_t slot_ = 0;
    Hit(PrefixCache &owner, std::size_t slot) : owner_(&owner), slot_(slot),
        snapshot(owner.entries_[slot].snapshot), replay(owner.entries_[slot].replay) {
      owner.entries_[slot].pinned = true; owner.touch(slot);
    }
  public:
    SnapshotRef snapshot;
    ReplayPrefix replay;
    Hit() noexcept = default;
    Hit(const Hit &) = delete;
    Hit &operator=(const Hit &) = delete;
    Hit(Hit &&other) noexcept : owner_(std::exchange(other.owner_, nullptr)), slot_(other.slot_),
        snapshot(std::move(other.snapshot)), replay(std::move(other.replay)) {}
    Hit &operator=(Hit &&other) noexcept {
      if (this != &other) { reset(); owner_ = std::exchange(other.owner_, nullptr); slot_ = other.slot_;
        snapshot = std::move(other.snapshot); replay = std::move(other.replay); }
      return *this;
    }
    ~Hit() { reset(); }
    explicit operator bool() const noexcept { return bool(snapshot); }
    void reset() noexcept {
      snapshot.reset(); replay = {};
      if (auto *owner = std::exchange(owner_, nullptr)) owner->entries_[slot_].pinned = false;
    }
  };
  std::size_t evictions = 0;
  explicit PrefixCache(std::size_t limit) {
    if (!limit || limit > entries_.max_size() || limit > lru_.max_size())
      throw std::runtime_error("prefix directory requires a finite positive entry limit");
    entries_.resize(limit); lru_.reserve(limit);
  }
  bool retains(const Snapshot *snapshot) const noexcept {
    for (const auto &entry : entries_) if (entry.snapshot.get() == snapshot) return true;
    return false;
  }
  std::size_t size() const noexcept { return lru_.size(); }
  bool evict_one() noexcept {
    for (auto it = lru_.begin(); it != lru_.end(); ++it) {
      auto &entry = entries_[*it]; if (entry.pinned) continue;
      entry = {}; lru_.erase(it); ++evictions; return true;
    }
    return false;
  }
  Hit lookup(const TokenPlan &input, std::size_t target, std::size_t minimum,
             const void *model, const void *math) {
    std::size_t best = entries_.size(), length = 0;
    for (std::size_t i = 0; i < entries_.size(); ++i) {
      const auto &entry = entries_[i]; const auto &head = entry.snapshot;
      if (!head || entry.pinned || head->model != model || head->math != math || head->next_id < 0 ||
          head->length < minimum || head->length > target || head->length <= length) continue;
      if (same_prefix(*entry.input, input, head->length)) { best = i; length = head->length; }
    }
    return best == entries_.size() ? Hit{} : Hit(*this, best);
  }
  bool publish(TokenPlanRef input, const SnapshotRef &snapshot, const ReplayPrefix &replay) {
    if (!input || !snapshot || !snapshot->length || snapshot->next_id < 0 ||
        snapshot->length > input->ids.size() || !replay.history || replay.length != snapshot->length ||
        replay.chunks == 0 || replay.chunks > replay.history->chunks.size() ||
        replay.history->chunks[replay.chunks - 1].next_id != snapshot->next_id)
      throw std::runtime_error("only a complete actual prefix boundary may enter the directory");
    std::size_t covered = 0;
    for (std::size_t i = 0; i < replay.chunks; ++i) {
      const auto &part = replay.history->chunks[i];
      if (!part.input || part.first != covered || part.first > input->ids.size() ||
          part.count > input->ids.size() - part.first || part.first > part.input->ids.size() ||
          part.count > part.input->ids.size() - part.first ||
          !std::equal(part.input->ids.begin() + static_cast<std::ptrdiff_t>(part.first),
              part.input->ids.begin() + static_cast<std::ptrdiff_t>(part.first + part.count),
              input->ids.begin() + static_cast<std::ptrdiff_t>(part.first)))
        throw std::runtime_error("prefix rebuild history differs from its exact token key");
      covered += part.count;
    }
    if (covered != snapshot->length) throw std::runtime_error("prefix rebuild history does not cover its snapshot");
    std::size_t slot = entries_.size();
    for (std::size_t i = 0; i < entries_.size(); ++i) {
      const auto &entry = entries_[i];
      if (entry.snapshot && entry.snapshot->model == snapshot->model && entry.snapshot->math == snapshot->math &&
          entry.snapshot->length == snapshot->length && same_prefix(*entry.input, *input, snapshot->length)) {
        if (entry.pinned) return false; slot = i; break;
      }
    }
    if (slot == entries_.size()) {
      for (std::size_t i = 0; i < entries_.size(); ++i) if (!entries_[i].snapshot) { slot = i; break; }
      if (slot == entries_.size()) {
        if (!evict_one()) return false;
        for (std::size_t i = 0; i < entries_.size(); ++i) if (!entries_[i].snapshot) { slot = i; break; }
      }
    }
    entries_[slot] = {std::move(input), snapshot, replay, false}; touch(slot); return true;
  }
};
} // namespace qwen35::cache
