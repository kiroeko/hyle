from pathlib import Path
import hashlib,json,re,statistics
root=Path.cwd();out=root/'.scratch/paged-retirement-20261021/perf';out.mkdir(parents=True,exist_ok=True)
base=root/'.scratch/qwen-prefix-20261021';ready=json.loads((base/'ready-attempt3.json').read_text());perf=json.loads((base/'performance/independent-review.json').read_text())
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=p.relative_to(root).as_posix()if p.is_relative_to(root)else str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def anchor(p,needle):
 text=(root/p).read_text();at=text.index(needle);return dict(path=p,line=text[:at].count('\n')+1,text=needle)
files=['tools/qwen35_text/main.cc','src/graph/resources.cc','src/graph_batch/paged_append.cc','src/compute_batch/paged_arena.cc','src/compute/resource_leases.cc']
sources=[ident(root/p)for p in files]
assert sources[0]['sha256']==ready['source']['sha256']=='bab6e9fc9325f3006fd34b3249023e158091b665ac5af6727ebc9ffaf554d971'
assert next(x for x in sources if x['path']=='src/graph/resources.cc')['sha256']=='ec935ea2052c482371e7129c2a31fa200ba93e402f4e8a07744bd2982f9e9fbe'
anchors=[anchor('tools/qwen35_text/main.cc','// Export all ordinary outputs first:'),anchor('tools/qwen35_text/main.cc','step.next->state[i].history = take(output.storage_lease());'),anchor('src/graph/resources.cc','Result<GraphOutput> Invocation::result(ValueId value)'),anchor('src/graph/resources.cc','// The external ValueId records form an immutable prefix.'),anchor('src/graph/resources.cc','episode->fixed_binding_count = episode->bindings.size();'),anchor('src/graph/resources.cc','const LeaseBinding *find_binding('),anchor('src/graph/resources.cc','Result<compute::ReadLease> output_storage(InvocationState &state,\n    compute::ConstTensorView tensor)'),anchor('src/graph/resources.cc','Status RegionAccess::withdraw_bindings('),anchor('src/graph_batch/paged_append.cc','Result<c::PagedArenaRead> PagedAppendPages::ready()'),anchor('src/compute_batch/paged_arena.cc','Result<PagedArenaRead> PagedArena::read_impl('),anchor('src/compute/resource_leases.cc','Result<WriteLease> LeasePool::allocate(')]
resources=(root/'src/graph/resources.cc').read_text();extra_constructors=[]
for n,line in enumerate(resources.splitlines(),1):
 if 'bindings.push_back(' in line:
  extra_constructors.append(dict(line=n,text=line.strip(),fixed_caller_record='.value = value' in line))
assert len(extra_constructors)==5
assert sum(not x['fixed_caller_record']for x in extra_constructors)==4
assert all('.write'not in x['text']for x in extra_constructors if not x['fixed_caller_record'])
extra_work={}
for turn in range(1,4):
 vals=[]
 for process in perf['timing_processes']:
  if process['variant']!='current':continue
  stderr=Path(process['stderr']['path']).read_text();pending=None
  for line in stderr.splitlines():
   if line.startswith('prepared T='):pending=dict(re.findall(r'(\w+)=([^\s]+)',line))
   if re.match(rf'^round{turn}_decode\d+ ',line):
    assert pending is not None
    if int(pending['capture_recorded'])==0:
     assert int(pending['T'])==1 and int(pending['capture_reused'])==7
     old_pages=(int(pending['visible'])-1+15)//16
     vals.append(36*12*old_pages)
    pending=None
 assert len(vals)==90
 extra_work[str(turn)]=dict(pure_reuse_calls=len(vals),anonymous_entry_checks_in_36_result_calls_per_step=dict(min=min(vals),median=statistics.median(vals),max=max(vals)),
                           derivation='T1 dirty_count=1. Each of12written projections adds old_pages-1 anonymous ReadLease entries and1writer-pointer entry. All12 remain bound through all36result exports. These anonymous entries never contain binding.write.')
report=dict(
 status='Read-only source mechanism review. One narrow candidate; no measured function self-time or speedup claim.',
 bound_to=dict(ready=ident(base/'ready-attempt3.json'),main_source=ready['source'],image=ready['image'],timing_review=ident(base/'performance/independent-review.json'),sources=sources),
 recommendation=dict(
  title='Stop scanning anonymous projected-page permissions when publishing ordinary caller output writers',
  actual_chain='After native completion, main exports18conv+18GDN=36GraphOutputs before taking any of12append transactions. Each Invocation::result loops the full ResourceEpisode.bindings table and calls publish only when binding.write.valid().',
  proof='prepare_resources builds an immutable fixed prefix of external ValueId records. Every later appended anonymous record is either a ReadLease page guard or projected_writer pointer; none owns WriteLease. Real WriteLease ownership is installed only on an existing fixed record by Invocation::bind. Therefore the suffix cannot contribute to this publication loop, including after earlier result calls have already published all36writers.',
  minimal_change='In Invocation::result only, iterate the existing bindings prefix [0,fixed_binding_count) for the existing publish-all-writes operation. Keep the same order, publication checks/errors and all real writers. No new result API/latch/cache, no change to GraphOutput storage lookup, and no permission/frame readiness elision.',
  complexity='Per output-export publication scan O(F+12P) -> O(F); all36exports avoid36*12P anonymous-record tests in this consumer. F=fixed external bindings, P=old page count. The36fixed-prefix passes remain; do not add a publication latch without separately proving mutation/reset/error semantics.',
  portability='This is a ResourceEpisode ownership-kind invariant, not a Qwen/shape/provider whitelist. Any future anonymous WriteLease record must update the invariant or stay in the scanned prefix.',
  timing_caveat='This operation is after done.wait and outside main cold_batch_seconds. It can only reduce fullstep/session post-retirement host overhead; it cannot by itself explain or erase the .200/.217/.241ms prepare bucket.'),
 anchors=anchors,all_binding_push_back_constructors=extra_constructors,source_derived_eliminable_checks_on_actual_pure_reuse_steps=extra_work,
 existing_measured_facts=dict(
  cold_bucket_current_ms=[x['seconds']['median']*1000 for x in perf['pure_reuse_cold_by_turn']['current']],
  cold_bucket_dense_ms=[x['seconds']['median']*1000 for x in perf['pure_reuse_cold_by_turn']['dense']],
  per_arm_three_processes=True,scope='Raw cold buckets use prepared cold_batch_seconds atT1/record0, not profiler self-time. They include candidate/permissions/layout/batch/replay work before submit.',
  capture='Each current process has90/96decode calls at0record/7reuse. This review does not propose removing a capture or permission gate.'),
 minimal_attribution_if_needed=dict(
  point='Diagnostic-only fixed preallocated record: timestamp immediately before the36output export loop and immediately after it, before the4B next_id read. One export_owned_states_seconds field percall. Retain original full step/session endpoints and all calls.',
  separate_from='The existing layout_seconds/batch_prepare_seconds/replay_prepare_seconds diagnostic split already covers pre-submit cold work; none attributes this post-wait output loop. If the broader remaining CPU budget is the priority, one more post-wait take_ready_unbind bucket could separate retirement without native instrumentation.',
  constraints='No new GPU query, wait, per-step allocation or immediate stderr; defer diagnostics after endpoint. Do not treat profiled data as unprofiled TPS or add warmups/filter tails.',
  current_state='Not implemented or run. This is the minimum measurement needed before predicting a meaningful throughput benefit.'),
 non_selected_operations=[
  dict(area='Twelve take/ready',fact='The first successful take latches the same whole-Graph terminal across append artifacts; later takes use indexed lookup and revoke actual permissions. ready publishes original dirty writers then PagedArena.read revalidates exact ready pages/initialized rows/canonical guards. Removing that validation solely because layout IDs match would be incorrect.'),
  dict(area='Thirty-six state-pool allocations',fact='LeasePool.allocate uses fixed pool/range capacity and lock, with actual generation and returned original writer; no device allocation is visible here. Distinct immutable snapshots/COW require actual original ownership until retirement. No source proof permits bypassing this with a use_count guess.'),
  dict(area='Unbind and head commit',fact='The72-port unbind has real idle/result/source/written-owner gates, native release extension validation and alias/generated-output cleanup. Snapshot next_id/head commit is already one pointer publication after successful unbind. It cannot simply be moved earlier or replaced by clearing metadata.'),
  dict(area='Already completed',fact='Do not redo unconsumed GGML input_lease skip, indexed RegionAccess lookup, sorted append identity checks or immutable layout page-footprint reuse; this report binds the current versions containing them.')],
 validation_if_owner_implements=['Existing paged append CUDA/F16/BF16/COW/failed-prefix/stale-submit journeys, plus owned output/independent ReadLease lifetime and unbind hostcases exercise the same permission/publication path. Do not add implementation-count tests.','Compare actual fullstep/session as well as prefill/decode/memory under root serial same-window procedure; make no performance claim from the source count alone.'],
 limits=['No product/source edit, CXX/build/link, model run, GPU query or sampling by this review.','Source proves redundant ownership-class scans, not their microsecond share or a guaranteed speedup. No new global cache, pool, specialized executor or engine policy is proposed.'])
p=out/'source-review.json';p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(report=ident(p),extra_work=extra_work),indent=2))

