from pathlib import Path
import difflib,hashlib,json
root=Path.cwd();p=root/'src/graph/resources.cc';out=root/'.scratch/paged-retirement-20261021/perf/implementation';out.mkdir(parents=True,exist_ok=True)
before=p.read_bytes();assert hashlib.sha256(before).hexdigest()=='ec935ea2052c482371e7129c2a31fa200ba93e402f4e8a07744bd2982f9e9fbe'
beforepath=out/'before/src/graph/resources.cc';beforepath.parent.mkdir(parents=True,exist_ok=True);beforepath.write_bytes(before)
s=before.decode().replace('\r\n','\n')
a=s.index('Result<GraphOutput> Invocation::result(ValueId value) noexcept {');b=s.index('Status Invocation::close()',a)
body=s[a:b]
old='''  if (state_->resources) {
    for (auto &binding : state_->resources.get()->bindings) {
      if (binding.write.valid()) {'''
new='''  if (state_->resources) {
    auto &episode = *state_->resources.get();
    // Anonymous projected-page records only hold reads or writer pointers;
    // every owned WriteLease remains in the fixed caller-binding prefix.
    for (std::size_t index = 0; index < episode.fixed_binding_count; ++index) {
      auto &binding = episode.bindings[index];
      if (binding.write.valid()) {'''
assert body.count(old)==1
newbody=body.replace(old,new);s=s[:a]+newbody+s[b:];p.write_bytes(s.encode())
after=p.read_bytes();snap=out/'source/src/graph/resources.cc';snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(after)
# The patch changes only the loop domain/local reference/comment. The body and all guards remain exact.
assert newbody.replace(new,old)==body
changes=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='before/src/graph/resources.cc',tofile='src/graph/resources.cc'))
(out/'implementation.diff').write_text(changes)
freeze={'status':'source frozen; not built/run','scope':['src/graph/resources.cc:Invocation::result'],
'before':{'path':'src/graph/resources.cc','bytes':len(before),'sha256':hashlib.sha256(before).hexdigest()},
'after':{'path':'src/graph/resources.cc','bytes':len(after),'sha256':hashlib.sha256(after).hexdigest()},
'changes':['Publication still visits all real writer-owning fixed caller bindings in original order, on every result() call. Only anonymous tail records are excluded.','The original WriteLease.publish() call, HYLE_ASSIGN_OR_RETURN propagation and all successful-retirement/published-output gates are byte-for-byte unchanged.','No latch, field, generation, API, capture, buffer or numerical change.'],
'invariant_review':{'fixed_prefix':'prepare_resources constructs input/caller-output records and assigns fixed_binding_count once at line1319 before storing the episode. Subsequent resets resize exactly to this prefix; no port-owner slot is appended beyond it.','writer_assignment':'Invocation::bind(write lease) resolves an existing fixed record with find_binding() then assigns binding->write; find_binding rejects any slot >=fixed_binding_count. Original publish-all applies to this entire prefix, not just the requested output.','anonymous_tail_constructors':[{'line':602,'kind':'ReadLease page guard'},{'line':670,'kind':'projected_writer pointer'},{'line':821,'kind':'ReadLease page guard'},{'line':915,'kind':'ReadLease page guard'}],'control':'Invocation::result requires idle+outputs_ready. Ordinary mutation is excluded by existing result/control gates; no new alias or ownership inference is introduced.'},
'verification':{'source_patch_body_preserved':True,'product_files_changed':1,'CXX':0,'link':0,'GPU_runs':0,'new_tests':0},
'expected_root_checks':['Existing owned-output/storage-lease and unbind hostcases','Current CPU/CUDA paged append/COW/old snapshots/failure/stale-submit','Qwen multi-output numerical and prefix scenarios'],
'performance_limit':'Source-proven reduction of scans only. No per-function timing or throughput benefit is claimed. This loop is post-wait, outside cold_batch_seconds.'}
(out/'source-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for name in ['source-freeze.json','implementation.diff']:
 x=out/name;print(name,x.stat().st_size,hashlib.sha256(x.read_bytes()).hexdigest())
print('resources',len(after),hashlib.sha256(after).hexdigest())
