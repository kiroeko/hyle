"""Render the one current-work table from frozen independent process statistics."""
from pathlib import Path
import json
S = Path(__file__).resolve().parent
R = S.parents[1]
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
table = read(S / 'performance/public-table.json')
rows = {r['arm']:r for r in table['rows']}
arms = ('current', 'before', 'dense', 'peer')
lines = [
'## 最新完整性能对比', '',
'**2026-10-21，异步回收与输出发布扫描修复后的四臂测试。** RTX 4070 12GB／Windows，Qwen3.5-2B BF16、F32 GDN、无MTP／图片；三轮`256输入＋32 decode`、容量1024、最终上下文864。各3新进程交错测速，显存另各1进程旁采；同固定输入，关闭trace／诊断及单会话前缀目录，四臂都保完整历史，只算新增输入。', '',
'当前`2941d9df…`、本批前paged `e155b89d…`、原dense `ff748694…`、llama.cpp `9b259137…`／`d9e03f1074db…`。192个链接输入只替换main及resources两个host对象，原生库、FI Provider与DLL相同。此窗没有实际取消／淘汰，不把异步接口接通当作吞吐收益，也不代表多人服务。', '',
'| 指标 | 当前分页Hyle | 本批前paged | 原dense Hyle | llama.cpp |',
'| --- | ---: | ---: | ---: | ---: |'
]
def add(label, function, digits=2):
    values = [function(rows[a]) for a in arms]
    lines.append('| ' + label + ' | ' + ' | '.join(f'{v:.{digits}f}' for v in values) + ' |')
for i in range(1, 4):
    add(f'第{i}轮prefill tok/s', lambda r, i=i:r['turn_phase_TPS'][f'round{i}_prefill']['median'])
for i in range(1, 4):
    add(f'第{i}轮完整decode tok/s', lambda r, i=i:r['turn_phase_TPS'][f'round{i}_decode']['median'])
add('合计prefill tok/s（768／三段prefill总wall）', lambda r:r['prefill_TPS']['median'])
add('完整decode tok/s（96／三段decode总wall）', lambda r:r['decode_TPS']['median'])
add('综合输出 tok/s（99／会话wall）', lambda r:r['session_output_TPS']['median'])
add('会话wall s', lambda r:r['session_wall_seconds']['median'], 5)
summary = read(S / 'performance/timing/summary.json')
add('入口至末输出 s（含加载／冷准备）', lambda r:summary['groups'][r['arm']]['metrics']['startup_total_seconds']['median'], 5)
add('启动至ready s', lambda r:r['loading']['startup_to_ready_seconds']['median'], 5)
add('模型权重加载 s（非冷盘带宽）', lambda r:r['loading']['model_load_seconds']['median'], 5)
for label, key in [('GPU dedicated全程观测峰 GiB', 'gpu_dedicated_bytes'),
    ('GPU shared全程观测峰 GiB', 'gpu_shared_bytes'),
    ('进程working set观测峰 GiB', 'working_set_bytes'),
    ('进程private commit观测峰 GiB', 'private_commit_bytes')]:
    add(label, lambda r, k=key:r['sampled_peak_MiB'][k]/1024, 3)
lines += ['',
'表内速率先逐进程求比值，再取3进程中位，未混用pooled比值。当前比before的decode低**0.19%**、综合高**0.14%**、合计prefill高1.30%；范围重叠，**未证明提速或回退**。当前比llama的decode慢**4.53%**、综合慢**1.74%**，合计prefill快16.53%；比原dense的decode慢3.07%。四臂绝对速率均低于上一窗口，不能据此给本批修改归因。', '']
for key, label in [('decode_TPS', 'decode'), ('session_output_TPS', '综合')]:
    ranges = '／'.join(f"{rows[a][key]['min']:.2f}–{rows[a][key]['max']:.2f}" for a in arms)
    lines += [f'current／before／dense／参考的{label}三进程范围：**{ranges} tok/s**。']
lines += ['',
'零重录decode的完整准备桶（每轮汇集3进程90次调用）current中位约0.212／0.224／0.230ms，before约0.216／0.217／0.251ms；不是单函数时间。输出发布在完成后，不能将本批扫描修复归进这个提交前计时桶。', '',
'当前与before的GPU dedicated观测峰同为4213.078MiB，比原dense多30MiB、比参考少约82MiB；未证明本批显存节省。下面是P1→D1→P2→D2→P3→D3阶段内的dedicated观测峰GiB，缺样保持未知：']
memory = read(S / 'performance/memory/summary.json')['groups']
phase_names = [f'round{i}_{k}' for i in range(1,4) for k in ('prefill','decode')]
for a in arms:
    values = []
    for name in phase_names:
        phase = memory[a]['phase_windows'].get(name)
        maximum = phase['values']['gpu_dedicated_bytes']['max'] if phase else None
        values.append(f'{maximum/(1<<30):.3f}' if maximum is not None else '未知')
    lines.append(f"{a}：**{'→'.join(values)}**。")
intervals = '／'.join(f"{rows[a]['memory_actual_gap_ms']['median']:.2f}" for a in arms)
lines += ['',
f'旁采请求10ms，实际间隔中位current／before／dense／参考约{intervals}ms；ready占用均未知，峰是采样下界，CPU与GPU不相加。阶段相邻样本可跨入进程退出，末阶段负delta不能当作推理中显存节省。',
'12个计时与4个内存进程的99个预测ID均相同；不是独立质量验收。未固定时钟或独占GPU，各臂仅3计时样本，不与旧窗合池或签长期胜负。',
'[原始样本、源码与独立复算](../evidence/performance/qwen-retirement-publication-2026-10-21.json)；[真实在途回收、142份向量回归及限制](../evidence/correctness/qwen-native-retirement-2026-10-21.json)；[上一完整窗口](../evidence/performance/qwen-indexed-preparation-2026-10-21.json)。下一步量化paged相对旧dense的实际额外时间，再推进独占续写。', '']
path = R / 'docs/developer/current-work.md'
text = path.read_text(encoding='utf-8')
assert text.count('## 最新完整性能对比') == 1
path.write_text(text.split('## 最新完整性能对比')[0] + '\n'.join(lines), encoding='utf-8')
print('Updated current-work from frozen process medians; no new measurement.')
