"""Run only current canonical and prefix checks; reuse existing independent oracles."""
from pathlib import Path
S = Path(__file__).resolve().parent
R = S.parents[1]
P = R / '.scratch/qwen-prefix-20261021'
source = (P / 'run.py').read_text(encoding='utf-8')
old = "plan = m.read(S / 'inputs/plan.json')"
assert source.count(old) == 1
source = source.replace(old, "plan = m.read(R / '.scratch/qwen-prefix-20261021/inputs/plan.json')")
exec(compile(source, str(Path(__file__).resolve()), 'exec'), globals())
