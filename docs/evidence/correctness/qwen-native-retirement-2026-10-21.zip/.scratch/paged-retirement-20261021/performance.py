"""One finite four-arm full comparison; reuse the established workload/runner."""
from pathlib import Path
S = Path(__file__).resolve().parent
R = S.parents[1]
source = (R / '.scratch/paged-prepare-20261021/performance.py').read_text(encoding='utf-8')
pairs = [
    ("current=S / 'qwen-ready.json'", "current=S / 'qwen-ready-attempt1.json'"),
    ("before=R / '.scratch/paged-recording-20261021/qwen-ready.json'",
     "before=R / '.scratch/qwen-prefix-20261021/ready-attempt3.json'"),
    ('Compare current generic lookup/page-set changes to exact previous paged ff42 closure, dense Hyle and matched llama.cpp;',
     'Compare current async consumer plus fixed-prefix output publication to exact prior e155, old dense Hyle and matched llama.cpp; prefix cache off for single-session;')
]
for old, new in pairs:
    assert source.count(old) == 1
    source = source.replace(old, new)
exec(compile(source, str(Path(__file__).resolve()), 'exec'), globals())
