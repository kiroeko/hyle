from pathlib import Path
import json,os,sys,subprocess,time,hashlib
R=Path.cwd();W=R/'.scratch/dspark-block5-tail-20261024/short-verifier';W.mkdir(exist_ok=True);E=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check'
sys.path.insert(0,str(R/'scripts'));from hyle_environment import discover_environment
base=json.loads((R/'.scratch/dspark-block5-tail-20261024/dspark_pro_mtp_state_consumer_test-syntax-command.json').read_text());cmd=[x for x in base if x!='/Zs']+['/Fo'+str(W/'consumer.obj'),'/Fd'+str(W/'consumer.pdb'),'/sourceDependencies',str(W/'dependencies.json')]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':base[0],'CMAKE_CXX_COMPILER':base[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
old=json.loads((R/'.scratch/engine-product-20261024/cpu-budget-fix1/tests-link-plan.json').read_text())['command'];gtest=[x for x in old if x.lower().endswith(('gtest_main.lib','gtest.lib'))]
link=[x for x in json.loads((E/'link-cuda-dense.json').read_text())['command'] if not x.endswith(('qwen.obj','entry.obj')) and not x.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
link=[str(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj') if x.endswith('graph--executable.obj') else x for x in link]
link += [str(W/'consumer.obj'),*gtest,'/OUT:'+str(W/'checks.exe'),'/IMPLIB:'+str(W/'checks.lib')]
for label,args in [('compile',cmd),('link',link)]:
 (W/(label+'-command.json')).write_text(json.dumps(args,indent=2)+'\n');started=time.time();print('START',label,flush=True)
 with (W/(label+'.log')).open('wb') as out:p=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=240)
 (W/(label+'-process.json')).write_text(json.dumps(dict(exit=p.returncode,seconds=time.time()-started),indent=2)+'\n');print('END',label,p.returncode,(W/(label+'.log')).read_text(errors='replace')[-7000:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
identity=lambda p:dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(W/'source-identity.json').write_text(json.dumps([identity(R/'tests/compute_models'/n)for n in ['dspark_pro_mtp_state_consumer_test.cc','dspark_original_state_consumer.h','dspark_block5_policy.h']],indent=2)+'\n')
(W/'image-identity.json').write_text(json.dumps(identity(W/'checks.exe'),indent=2)+'\n');ready=json.loads((E/'ready-cpu.json').read_text());native=Path(ready['native_runtime']['path']);target=W/native.name
if not target.exists():os.link(native,target)
print('READY',flush=True)
