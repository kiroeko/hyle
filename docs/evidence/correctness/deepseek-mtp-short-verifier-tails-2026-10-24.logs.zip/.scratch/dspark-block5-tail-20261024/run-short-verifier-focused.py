from pathlib import Path
import os,json,subprocess,time,sys,hashlib
R=Path.cwd();W=R/'.scratch/dspark-block5-tail-20261024/short-verifier';S=R/'.scratch/dspark-pro-target-draft-20261023';E=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check';ready=json.loads((E/'ready-cuda.json').read_text());summary=[]
for label,group in [('pro','DSparkProOriginalState'),('flash','DSparkFlashFormalState')]:
 C=W/(label+'-focused');C.mkdir(exist_ok=True);env=dict(os.environ,PATH=str(W)+os.pathsep+ready['PATH'])
 for key in list(env):
  if key.startswith('HYLE_DSPARK_'):env.pop(key,None)
 if label=='pro':env.update(HYLE_DSPARK_PRO_DIR=str(S/'original-dense'),HYLE_DSPARK_PRO_EXPERT_DIR=str(S/'original-experts'),HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS='0',HYLE_DSPARK_PRO_FRONTIER_FILE=str(C/'missing-frontier.json'))
 else:env.update(HYLE_DSPARK_FORMAL_FLASH_DIR=str(S/'formal-flash/original-dense'),HYLE_DSPARK_FLASH_EXPERT_DIR=str(S/'formal-flash/original-experts'),HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS='0',HYLE_DSPARK_FLASH_FRONTIER_FILE=str(C/'missing-frontier.json'),HYLE_DSPARK_ORIGINAL_TARGET_TAIL_DIR=str(R/'.scratch/dspark-original-target-tail-20261023/original-target'),HYLE_DSPARK_SHARED_VOCAB_DIR=str(R/'.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary'))
 args=[str(W/'checks.exe'),'--gtest_color=no','--gtest_filter='+group+'.CudaShortVerifierTailsPreserveActualStateAndContinue','--gtest_output=xml:'+str(C/'results.xml')];(C/'command.json').write_text(json.dumps(args,indent=2)+'\n');(C/'environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith('HYLE_DSPARK_')},indent=2)+'\n');print('START',label,flush=True);started=time.time()
 with(C/'run.log').open('wb')as out:p=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 record=dict(case=label,exit=p.returncode,seconds=time.time()-started,HTTP=0,SDK_builds=0,waiting_for_experts=False);(C/'process.json').write_text(json.dumps(record,indent=2)+'\n');summary.append(record);print('END',label,record,(C/'run.log').read_text(errors='replace')[-4500:],flush=True)
(W/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');raise SystemExit(1 if any(r['exit']for r in summary)else 0)
