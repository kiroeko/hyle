from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('dense_cast_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
out=S/'dense';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
basepath=S/'green/link-plan.json';base=c.read(basepath)
env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
receipt=c.read(S/'green/tensor-kernel-identity.json');command=list(receipt['command'])
for flag,value in [('-o','tensor-kernel.obj'),('-MF','tensor-kernel.d'),('-MT','tensor-kernel.obj')]:command[command.index(flag)+1]=str(out/value)
command=[('-Xcompiler=-Fd'+str(out/'tensor-kernel.pdb')+',-FS') if a.startswith('-Xcompiler=-Fd') else a for a in command]
c.execute('tensor-kernel-compile',command,env,out)
obj=b.identity(out/'tensor-kernel.obj')
c.save(out/'tensor-kernel-identity.json',dict(command=command,source=b.identity(h.ROOT/'src/compute_provider_cuda/tensor_kernel.cu'),
 header=b.identity(h.ROOT/'src/compute_provider_cuda/tensor_kernel.h'),object=obj))
old=receipt['object']['path'];inputs=[obj if c.key(r['path'])==c.key(old) else r for r in base['inputs']]
command=[obj['path'] if c.key(a)==c.key(old) else a for a in base['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'cuda.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
for row in inputs:assert h.h.h.same_identity(row),row['path']
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath)))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
filt=c.read(S/'green/run.command.json')['command'][1]
c.execute('run',[str(image),filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
