from pathlib import Path
import importlib.util,sys,concurrent.futures
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('native_cast_helpers',A/'cuda-bool-cast/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'cuda-bool-cast/consumer-final/link-plan.json';base=c.read(BASE);meta=h.h.metadata({'cuda':base})
def owner(source):
 matches=[(row,meta[c.key(row['path'])]) for row in base['inputs']
  if c.key(row['path']) in meta and c.key(meta[c.key(row['path'])]['source_path'])==c.key(ROOT/source)]
 assert len(matches)==1,(source,len(matches));return matches[0]
def host(source,tag,out,env):
 old,recipe=owner(source);command=b.host_command(recipe['command'],ROOT/source,tag,out)
 c.execute(tag+'-compile',command,env,out)
 deps=c.read(out/(tag+'-deps.json'))['Data'];result=dict(command=command,source=b.identity(ROOT/source),
  object=b.identity(out/(tag+'.obj')),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
 c.save(out/(tag+'-identity.json'),result);return c.key(old['path']),result['object']
def main():
 mode=sys.argv[1];out=S/mode;out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
 env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
 c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime))
 replacements={}
 sources=[('tests/graph_route_cuda/fp8_cast_test.cc','cast-test'),('tests/graph_route_cuda/fp8_channel_token_qdq_test.cc','qdq-test')]
 if mode=='red':
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
   replacements.update(pool.map(lambda p:host(p[0],p[1],out,env),sources))
 elif mode=='green':
  for source,tag in sources:
   old,_=owner(source);receipt=c.read(S/'red'/(tag+'-identity.json'))
   assert h.h.same_identity(receipt['object'])
   for r in receipt['dependencies']:assert h.h.same_identity(r),r['path']
   replacements[c.key(old['path'])]=receipt['object']
  product=[('src/compute_provider_cuda/tensor_provider.cc','tensor-provider'),
   ('src/compute_provider_cuda/row_cache_indexer_provider.cc','row-cache'),
   ('src/compute_provider_torch_cuda/artifact_provider.cc','artifact-provider')]
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
   replacements.update(pool.map(lambda p:host(p[0],p[1],out,env),product))
  old_native=next(r for r in base['inputs'] if Path(r['path']).name=='tensor_kernel.obj')
  recipe=c.read(A/'cuda-bool-cast/green/tensor-kernel-identity.json')['command']
  command=list(recipe)
  for flag,value in [('-o','tensor-kernel.obj'),('-MF','tensor-kernel.d'),('-MT','tensor-kernel.obj')]:
   command[command.index(flag)+1]=str(out/value)
  command=[('-Xcompiler=-Fd'+str(out/'tensor-kernel.pdb')+',-FS') if a.startswith('-Xcompiler=-Fd') else a for a in command]
  c.execute('tensor-kernel-compile',command,env,out)
  receipt=dict(command=command,source=b.identity(ROOT/'src/compute_provider_cuda/tensor_kernel.cu'),
   header=b.identity(ROOT/'src/compute_provider_cuda/tensor_kernel.h'),object=b.identity(out/'tensor-kernel.obj'))
  c.save(out/'tensor-kernel-identity.json',receipt);replacements[c.key(old_native['path'])]=receipt['object']
 else:raise ValueError(mode)
 inputs=[replacements.get(c.key(r['path']),r) for r in base['inputs']]
 command=[replacements.get(c.key(a),{}).get('path',a) for a in base['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 image=out/'cuda.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 for row in inputs:assert h.h.same_identity(row),row['path']
 c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(BASE)))
 c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
 filt='CudaFp8Cast.*:CudaFp8ChannelTokenQdqGraph.*'
 if mode=='green':filt+=':CudaTensor.FloatStorageConversionsMatchIndependentRounding:CudaTensor.BoolConversionsPreserveNonzeroBitsAndNormalizeTruthValues:CudaTensor.SelectCopyFillPreserveBitsWithBroadcastMaskAndOddStride:CudaTensor.ViewUsesRequiredStorageOffsetAndCopyRejectsOverlap'
 c.execute('run',[str(image),'--gtest_filter='+filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
if __name__=='__main__':main()
