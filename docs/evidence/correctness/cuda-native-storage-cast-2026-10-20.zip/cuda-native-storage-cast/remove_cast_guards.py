from pathlib import Path
path=Path(__file__).resolve().parents[3]/'src/compute_provider_torch_cuda/artifact_provider.cc'
text=path.read_text()
assert text.count(' && !program->is_cast')==4
text=text.replace(' && !program->is_cast','')
assert text.count('+fp8-storage-cast')==1
text=text.replace('+fp8-storage-cast','')
assert 'is_cast' not in text and 'get_if<Cast>' not in text and 'storage_cast.h' not in text
path.write_text(text,encoding='utf-8',newline='\n')
