"""Seal the storage contract repair and native CUDA execution, excluding binaries."""
from pathlib import Path
import hashlib,json,zipfile,difflib,xml.etree.ElementTree as ET
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1];C=A/'bf16-nan-cast-contract'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
 p=Path(p);data=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def cases(p,n,failures=0):
 rows=ET.parse(p).findall('.//testcase');assert len(rows)==n
 assert sum(bool(r.findall('failure')) for r in rows)==failures
 assert not any(r.findall('skipped') for r in rows)
 return [dict(name=r.attrib['classname']+'.'+r.attrib['name'],failures=len(r.findall('failure')),
  properties={x.attrib['name']:x.attrib['value'] for x in r.findall('./properties/property')}) for r in rows]
cpu=cases(C/'final/tests.xml',14);cuda=cases(S/'final/tests.xml',14)
red=cases(S/'red/tests.xml',7,7);cpu_red=cases(C/'red/tests.xml',2,1)
for rows in [cpu,cuda]:
 q=[r for r in rows if 'Fp8ChannelTokenQdqGraph.' in r['name']]
 assert len(q)==1 and q[0]['properties']['actual_submissions']=='4'
for plan in [C/'final/link-plan.json',S/'final/link-plan.json']:
 document=read(plan)
 if 'inputs' in document:inputs=document['inputs']
 else:
  known={r['path'].casefold():r for r in read(Path(document['base']['path']))['inputs']}
  for ident in read(C/'summary.json')['compilation_identities']:
   receipt=read(Path(ident['path']));known[receipt['object']['path'].casefold()]=receipt['object']
  inputs=[known[a.casefold()] for a in document['command'] if Path(a).is_absolute() and Path(a).suffix.lower() in {'.obj','.lib'}]
 for row in inputs:
  actual=identity(row['path']);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],row['path']
for name in ['tensor-provider','row-cache','artifact-provider']:
 row=read(S/'green'/(name+'-identity.json'));assert identity(row['source']['path'])==row['source']
 assert identity(row['object']['path'])==row['object']
row=read(S/'dense/tensor-kernel-identity.json')
assert identity(row['source']['path'])==row['source'] and identity(row['header']['path'])==row['header']
old=(S/'before/tests/compute_models/fp8_channel_token_qdq_fixture.h').read_text(encoding='utf-8')
new=(ROOT/'tests/compute_models/fp8_channel_token_qdq_fixture.h').read_text(encoding='utf-8')
def math_part(text):return text[text.index('struct Case final'):text.index('template<class Read>')]
assert math_part(old)==math_part(new)
old=(S/'revisions/before-grid-tail-test/fp8_cast_test.cc').read_text(encoding='utf-8')
new=(ROOT/'tests/graph_route_cuda/fp8_cast_test.cc').read_text(encoding='utf-8')
assert new.startswith(old[:old.rindex('} // namespace')])
paths=['src/compute_provider_cuda/tensor_provider.cc','src/compute_provider_cuda/tensor_kernel.h',
 'src/compute_provider_cuda/tensor_kernel.cu','src/compute_provider_cuda/row_cache_indexer_provider.cc',
 'src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_torch_shared/storage_cast.h',
 'include/hyle/simd/dtype.h','tests/compute_provider_native/aten_cast_reference.h','tests/compute_provider_native/aten_cast_test.cc',
 'tests/graph_route_cuda/fp8_cast_test.cc','tests/compute_models/fp8_channel_token_qdq_fixture.h',
 'tests/graph_route_cpu/fp8_channel_token_qdq_test.cc','tests/graph_route_cuda/fp8_channel_token_qdq_test.cc']
for rel in paths:
 p=S/'frozen'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/rel).read_bytes())
diff=''
for rel in paths:
 p=S/'before'/rel
 if p.is_file():diff+=''.join(difflib.unified_diff(p.read_text(encoding='utf-8').splitlines(True),(ROOT/rel).read_text(encoding='utf-8').splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
(S/'source.diff').write_text(diff,encoding='utf-8')
assert all(word not in (ROOT/'src/compute_provider_torch_cuda/artifact_provider.cc').read_text(encoding='utf-8') for word in ['is_cast','get_if<Cast>','storage_cast.h'])
final=dict(date='2026-10-20',status='passed targeted Windows CPU/CUDA contract and capture regressions; broad goal remains active',
 changes=['CUDA storage Cast uses original PreparedOperation/shared Queue and one native tensor program; managed ATen CUDA Cast path removed',
  'Tensor-only six-type dispatch replaces three-type alias; shared ElementType unchanged; only tensor_provider, row_cache_indexer_provider and tensor_kernel own this private seam',
  'CUDA finite FP8 conversions use installed CUDA13.3 intrinsics with public NaN/Infinity/signed-zero fixups; no new public math operation',
  'ATen CPU BF16 narrowing now preserves upper NaN payload/sign and sets quiet bit, matching existing SIMD/native CPU',
  'Cast/Copy use 64-bit shape/index and bounded grid-stride execution with safe tail arithmetic; arithmetic retains the original INT32 qualified domain',
  'Dense Cast/Copy omit per-element coordinate division and byte-wise source loads; real strides/broadcast use the same program indexing branch'],
 cpu=cpu,cuda=cuda,cpu_red=cpu_red,cuda_red=red,source=[identity(ROOT/p) for p in paths],
 numerical_contract=dict(rounding='RNE; finite FP8 overflow saturates; true E5M2 infinities survive; source NaN sign survives',
  widening='F32 widening preserves declared NaN payload including E5M2 signaling bits',
  narrowing='BF16 preserves upper payload and quiets; F16/FP8 retain their original signed NaN mapping; same dtype raw Copy preserves all bits',
  boolean='Only F32/F16/BF16 <-> Bool; signed zero false, every nonzero floating storage true, nonzero Bool bytes convert to 1'),
 coverage=['All 256 FP8 codes widen/copy/cross-convert; all 65536 F16/BF16 input codes narrow to each FP8 format',
  'F32 adjacent midpoint/tie/overflow/NaN cases; byte strides, broadcast, source immutability and output guards',
  'Empty/scalar, out-of-place alias rejection; 2^33-element descriptor-only cold prepare without giant allocation',
  'Real 2^24+257-element dense and broadcast casts exercise bounded-grid repeated work/tail with small prefix/middle/tail readback and guards',
  'Public clip graph with two owned slots requires capture and retains old results',
  'Fixed CT BF16 QDQ unchanged math/oracle; two slots and four submissions on each backend, final BF16 bits exact; whole CUDA path requires capture',
  'Two row-cache tests exercise shared private tensor metadata including capture and independent slots'],
 proof_order='Original seven updated CUDA regressions fail against the preserved old object closure. The identical red test objects pass before the final append-only grid-tail case. Final same-core run includes all14 cases.',
 current_core='Reused latest custom_kernel17 and StateVersions slot-ownership objects; private tensor header owners all refreshed. Other harmless historic declaration/comment/explicit empty-Queue changes are recorded by qwen stable-bind assembly; not a full clean-tree rebuild.',
 actual_build=dict(cuda_root_host_CXX=6,cuda_root_NVCC=2,cuda_root_links=5,cuda_root_test_processes=5,SDK_builds=0,
  detail='Two red tests plus three product host owners, then one appended grid-tail test; two kernel builds (generic then dense). Red/green/dense/current-core/final each link/run once. CPU separate receipts below.'),
 cpu_receipt=identity(C/'summary.json'),math_and_oracle_unchanged=True,
 sdk=[identity(Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include')/p) for p in ['cuda_fp8.h','cuda_fp8.hpp']],
 vendor_api='https://docs.nvidia.com/cuda/cuda-math-api/cuda_math_api/group__CUDA__MATH__FP8__MISC.html',
 performance='No Cast throughput, fresh kernel trace, memory peak or whole-model gain is claimed. Independent Qwen windows: docs/evidence/performance/qwen-stable-bind-2026-10-20.json',
 not_verified=['Runtime payloads beyond2^32 elements; the2^33 test is cold preparation only','Other CUDA architectures/OS or Apple/Vulkan storage casts',
  'Whole CT artifact loading, native FP8 Tensor Core GEMM or model quality','New fault/retirement permutations beyond existing related regressions'])
save(S/'final-validation.json',final)
payload={}
for prefix,folder in [('cuda-native-storage-cast',S),('bf16-nan-cast-contract',C)]:
 for p in folder.rglob('*'):
  if not p.is_file() or p.suffix.lower() not in {'.json','.log','.xml','.py','.h','.cc','.cu','.diff','.txt','.d'}:continue
  if any(x in {'tmp','cleanup','__pycache__'} for x in p.relative_to(folder).parts):continue
  if p.stat().st_size>8_000_000:continue
  payload[prefix+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(payload.items())}
dest=ROOT/'docs/evidence/correctness/cuda-native-storage-cast-2026-10-20.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in payload.items():z.writestr(name,data)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(n.casefold() for n in z.namelist()))
 for name,row in manifest.items():
  assert not name.startswith('/') and '..' not in Path(name).parts
  data=z.read(name);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
save(dest.with_suffix('.json'),dict(final,archive=identity(dest),payloads=len(payload),manifest='manifest.json',
 members={n:manifest[n] for n in ['cuda-native-storage-cast/final-validation.json','cuda-native-storage-cast/final/tests.xml','bf16-nan-cast-contract/summary.json','bf16-nan-cast-contract/final/tests.xml']}))
print(json.dumps(dict(report=identity(dest.with_suffix('.json')),archive=identity(dest),payloads=len(payload)),indent=2))
