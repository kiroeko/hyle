from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
p=ROOT/'docs/developer/current-work.md';text=p.read_text(encoding='utf-8')
start=text.index('CUDA随后已补dense F32/F16/BF16与E4M3FN/E5M2之间的公开Cast')
end=text.index('跨平台已验证过有限形状',start)
text=text[:start]+'''CUDA浮点Cast现统一到既有原生PreparedOperation/shared queue，支持F32/F16/BF16/E4M3FN/E5M2，
删除旧managed转换分支。连续存储省坐标除模，byte-stride/广播保原布局；无Provider workspace或私有结果，
64位Cast/Copy不缩小原大descriptor域，普通算术仍保原32位域。CPU ATen的BF16 NaN payload丢失也已按SIMD规则修正。
CPU14项、CUDA11项通过、0skip：含全FP8位型、全F16/BF16入FP8、RNE边界、特殊值、护栏、旧输出及双槽；
固定CT rank3 BF16 QDQ两端各四次提交逐bit等于独立oracle，CUDA完整链已RequireCapture。
8B元素仅做descriptor冷准备，未分配或运行巨型payload；未据此声明整FP8制品、原生FP8点积、质量或吞吐。
[原生转换与数值/capture回归](../evidence/correctness/cuda-native-storage-cast-2026-10-20.json)保原拒绝和测试修正；
不同部署端的量化/点积规则见[固定来源研究](../evidence/research/fp8-channel-token-contract-2026-10-20.json)。
ModelOpt NVFP4随后已核186个实际language角色的packed E2M1、E4M3 group16与两级F32标度；
calibrated global不表示activation块scale静态，现仍缺该W4A4入口，不能套group32或block128。
[原header与固定生产者源码](../evidence/research/nvfp4-channel-global-contract-2026-10-20.json)没有权重payload或运行验收。

'''+text[end:]
p.write_text(text,encoding='utf-8',newline='\n')
p=ROOT/'docs/implementation/model-operators.md';lines=p.read_text(encoding='utf-8').splitlines(True)
hits=[i for i,l in enumerate(lines) if l.startswith('| FP8存储转换；')];assert len(hits)==1
lines[hits[0]]='| FP8存储转换；F32/F16/BF16与E4M3FN/E5M2 | CUDA Native已统一五种浮点Cast并删旧managed分支；无Provider workspace/private result，支持dense、byte-stride、广播与外部capture。CPU BF16 NaN payload按SIMD对齐。[CPU14项与CUDA11项](../evidence/correctness/cuda-native-storage-cast-2026-10-20.json)通过；固定CT rank3 BF16 QDQ各双槽四次逐bit等于独立oracle，CUDA完整链RequireCapture | 8B元素只做descriptor冷准备；未签巨型payload、整制品、原生FP8 GEMM、质量或吞吐。CT逐channel BF16 scale不等于block128；[原生code-dot反例](../evidence/correctness/cuda-fp8-codedot-feasibility-2026-10-20.json)仍禁止把普通F32 MatMul静默替换成另一FP8点积 |\n'
hits=[i for i,l in enumerate(lines) if l.startswith('| HF MXFP4/NVFP4 |')];assert len(hits)==1
lines[hits[0]]='| HF MXFP4/NVFP4 | Quark W4A4、ModelOpt calibrated-global与CT local-dynamic分别保留原合同；ModelOpt已核186角色的U8 packed E2M1、E4M3 group16及两个F32 global，activation块absmax仍随输入变化。[固定header/生产者研究](../evidence/research/nvfp4-channel-global-contract-2026-10-20.json)未运行权重payload | 缺原两级标度的group16 W4A4入口；原Wdecode两种乘法树须明确，不能套GGUF FP4、group32或DeepSeek FP4/A8组合；CT local-dynamic另核 |\n'
p.write_text(''.join(lines),encoding='utf-8',newline='\n')
