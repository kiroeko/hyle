from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('grid_tail_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
out=S/'final';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
basepath=S/'current-core/link-plan.json';base=c.read(basepath)
env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
_,obj=h.host('tests/graph_route_cuda/fp8_cast_test.cc','cast-test',out,env)
old=c.read(S/'red/cast-test-identity.json')['object']['path']
assert sum(c.key(r['path'])==c.key(old) for r in base['inputs'])==1
inputs=[obj if c.key(r['path'])==c.key(old) else r for r in base['inputs']]
command=[obj['path'] if c.key(a)==c.key(old) else a for a in base['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'cuda.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
for row in inputs:assert h.h.h.same_identity(row),row['path']
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath)))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
filt=c.read(S/'current-core/run.command.json')['command'][1]
c.execute('run',[str(image),filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
