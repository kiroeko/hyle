from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_storage_helpers',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=S/'dense/link-plan.json';base=c.read(basepath)
assembly=c.read(S.parent/'decode-stable-bind/ab/link-assembly.json')
metadata=h.h.h.metadata({'tests':base})
replacements={};notes=[]
for row in assembly['replacements']:
 if any(c.key(x['path'])==c.key(row['selected']['path']) for x in base['inputs']):continue
 matches=[x for x in base['inputs'] if c.key(x['path'])==c.key(row['old']['path']) or
  (c.key(x['path']) in metadata and c.key(metadata[c.key(x['path'])]['source_path'])==c.key(row['source']))]
 assert len(matches)==1,(row['source'],len(matches))
 replacements[c.key(matches[0]['path'])]=row['selected'];notes.append(dict(source=row['source'],old=matches[0],selected=row['selected']))
out=S/'current-core';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
inputs=[replacements.get(c.key(r['path']),r) for r in base['inputs']]
command=[replacements.get(c.key(a),{}).get('path',a) for a in base['command'] if not a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
image=out/'cuda.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
for row in inputs:assert h.h.h.same_identity(row),row['path']
env,runtime=b.environment(command,[r['path'] for r in inputs],out)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),replacements=notes))
c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
filt=c.read(S/'dense/run.command.json')['command'][1]
filt+=':CudaDenseIndexer.DyadicStagesAndMaskKeepThreeBfloatRoundsAndNonfiniteValues:CudaDenseIndexer.PaddedBatchKeysKeepIndependentSlotsAndRetainedResults'
c.execute('run',[str(image),filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)
c.save(out/'input-recheck.json',dict(inputs=[b.identity(r['path']) for r in inputs]))
print('CURRENT_CORE_REPLACEMENTS',len(notes),flush=True)
