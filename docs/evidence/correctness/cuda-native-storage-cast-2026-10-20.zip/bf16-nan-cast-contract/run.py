from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();a=root/'.scratch/architecture-refactor-2026-10-18';out=a/'bf16-nan-cast-contract';phase=sys.argv[1];folder=out/phase;folder.mkdir(exist_ok=True)
basepath=a/'fp8-channel-token-qdq/fixture-api-correction/final-checks/cpu/link-plan.json';base=json.loads(basepath.read_bytes())
env=os.environ.copy();p=subprocess.run(['cmd','/d','/c',str(out/'compiler-env.bat')],capture_output=True,text=True,check=True)
for line in p.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
libs=[Path(x) for x in base['command'] if x.lower().endswith('.lib') and Path(x).is_absolute()]
torch=[str(x.parent) for x in libs if x.name.lower() in ['torch_cpu.lib','c10.lib']]
prior=json.loads((a/'quant-route-followup/checks/host1/runtime-environment.json').read_bytes())
env['PATH']=';'.join(dict.fromkeys(torch+prior['runtime']+[env.get('PATH','')]))
records=[]
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,cmd):
 start=time.time();r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');(folder/(label+'.stdout.log')).write_bytes(r.stdout.encode());(folder/(label+'.stderr.log')).write_bytes(r.stderr.encode());records.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.time()-start));(folder/'commands.json').write_bytes((json.dumps(records,indent=2)+'\n').encode());print(label,r.returncode,flush=True)
 if r.returncode and label!='run': print((r.stdout+r.stderr)[-5000:]);raise SystemExit(r.returncode)
 return r

def compile_from(recipe,source,tag):
 old=json.loads(recipe.read_bytes())['command'];cmd=[];skip=False
 for arg in old:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  cmd.append(arg)
 obj=folder/(tag+'.obj');cmd+=['/sourceDependencies',str(folder/(tag+'-deps.json')),str(root/source),'/Fo'+str(obj),'/Fd'+str(folder/(tag+'.pdb'))];run(tag+'-compile',cmd);deps=json.loads((folder/(tag+'-deps.json')).read_bytes())['Data'];(folder/(tag+'-identity.json')).write_bytes((json.dumps(dict(source=ident(root/source),object=ident(obj),command=cmd,dependencies=[ident(Path(p))for p in dict.fromkeys([deps['Source'],*deps['Includes']])]),indent=2)+'\n').encode());return str(obj)
oldtest=str(a/'quant-route-followup/checks/host1/cpu-cast-test.obj');newtest=compile_from(a/'quant-route-followup/checks/host1/cpu-cast-test-identity.json','tests/compute_provider_native/aten_cast_test.cc','cast-test')
replace={oldtest.lower():newtest}
if phase!='red':
 oldowner=str(a/'quant-route-followup/checks/host1/aten-cpu.obj');replace[oldowner.lower()]=compile_from(a/'quant-route-followup/checks/host1/aten-cpu-identity.json','src/compute_provider_native/aten_cpu_provider.cc','aten-cpu')
cmd=[replace.get(x.lower(),x)for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];exe=folder/'cpu.exe';cmd+=['/OUT:'+str(exe),'/MAP:'+str(folder/'cpu.map'),'/IMPLIB:'+str(folder/'cpu.lib')]
for path in cmd:
 if Path(path).is_absolute() and Path(path).suffix.lower()in {'.lib','.obj'}:assert Path(path).is_file(),path
(folder/'link-plan.json').write_bytes((json.dumps(dict(command=cmd,base=ident(basepath),replacements=replace),indent=2)+'\n').encode());run('link',cmd)
pattern='AtenCpuCast.BfloatNanPayloadMatchesNativeE5m2StorageContract:NativeCast.BfloatNanPayloadPreservesE5m2UpperPayloadAndQuietBit'if phase=='red'else'AtenCpuCast.*:MatureCast.*:NativeCast.*'
r=run('run',[str(exe),'--gtest_filter='+pattern,'--gtest_output=xml:'+str(folder/'tests.xml')]);(folder/'result.json').write_bytes((json.dumps(dict(phase=phase,exit_code=r.returncode,image=ident(exe),filter=pattern,header=ident(root/'src/compute_torch_shared/storage_cast.h'),reference=ident(root/'tests/compute_provider_native/aten_cast_reference.h')),indent=2)+'\n').encode());print(r.stdout+r.stderr);sys.exit(r.returncode)
