"""Write exact, archived cleanup into root test.ps1; never delete here."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p = Path(p).resolve(); data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def check(row):
    actual = identity(row['path'])
    assert all(actual[k] == row[k] for k in ('bytes', 'sha256'))
    return actual
plan_path = Path(read(S / 'latest-check.json')['plan'])
out = plan_path.parent
evidence = []
for receipt_path in [ROOT / 'docs/evidence/correctness/ga-dense-indexer-cuda-2026-10-20-archive.json',
    ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/binding-port-reuse-archive.json',
    ROOT / 'docs/evidence/performance/qwen35-full-cuda-2026-10-19/cast-stable-silu-archive.json']:
    record = read(receipt_path)
    assert record['crc_verified'] and record['payload_sha256_verified']
    evidence += [check(record), identity(receipt_path)]
retained = [check(read(out / 'qwen-image.json')),
    check(read(A / 'binding-port-reuse/checks/20261019T174851/cpu-image.json')),
    check(read(A / 'cast-stable-silu/checks/20261019T180121/qwen-image.json')),
    check(read(A / 'cuda-explicit-rope/performance-prepared/peer-image.json'))]
references, targets = {}, {}
def target(p):
    p = Path(p).resolve()
    assert p.is_file() and p.is_relative_to(ROOT / '.scratch')
    targets[str(p).casefold()] = identity(p)
images = [p for p in S.rglob('*.exe') if p.resolve() != Path(retained[0]['path'])]
images.append(A / 'binding-port-reuse/checks/20261019T174851/qwen.exe')
assert len(images) == 6
for image in images:
    assert image.is_file()
    for suffix in ('.exe', '.map', '.exp', '.lib', '.pdb'):
        p = image.with_suffix(suffix)
        if p.exists():
            target(p)
for dirname in ('correctness', 'correctness-final'):
    observation = read(S / dirname / 'summary.json')['observation']
    assert observation['equal_vectors'] == len(observation['vectors']) == 64
    for row in observation['vectors']:
        actual, reference = check(row['actual']), check(row['reference'])
        assert row['byte_equal'] and actual['sha256'] == reference['sha256']
        references[str(Path(reference['path'])).casefold()] = reference
        target(actual['path'])
assert len(references) == 64
build = read(plan_path)
inputs = {str(Path(p).resolve()).casefold() for link in build['links'].values() for p in link['inputs']}
assert not set(targets).intersection(inputs)
assert not set(targets).intersection(str(Path(row['path']).resolve()).casefold()
    for row in [*retained, *references.values(), *evidence])
plan = dict(evidence=evidence, retained_images=retained,
    retained_vectors=list(references.values()), current_build_plan=identity(plan_path),
    targets=list(targets.values()), count=len(targets),
    total_bytes=sum(row['bytes'] for row in targets.values()), recursive=False,
    scope='Six intermediate/superseded images plus link side products and128 duplicate vectors. Keep current Qwen, immediate650-kernel performance baseline, current CPU/peer, all sources/objects/SDK/logs/profile and64original vectors.')
path = S / 'cleanup-plan.json'
assert not path.exists()
path.write_text(json.dumps(plan, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
old = (ROOT / 'test.ps1').read_bytes()
(S / 'test-before-reclaim.ps1').write_bytes(old)
script = '\n'.join(line for line in old.decode('utf-8-sig').splitlines() if line.strip()) + '\n'
previous = identity(A / 'cast-stable-silu/cleanup-plan.json')['sha256']
assert previous in script
script = script.replace('cast-stable-silu\\cleanup-plan.json', 'ga-dense-indexer\\cleanup-plan.json')
script = script.replace('cast-stable-silu\\cleanup-result.json', 'ga-dense-indexer\\cleanup-result.json')
script = script.replace(previous, identity(path)['sha256'])
assert 'cast-stable-silu\\cleanup-' not in script
for p in (ROOT / 'test.ps1', S / 'executed-reclaim.ps1'):
    with p.open('w', encoding='utf-8', newline='\n') as stream:
        stream.write(script)
print(json.dumps(dict(plan=identity(path), files=plan['count'], bytes=plan['total_bytes'],
    MiB=plan['total_bytes'] / 1024**2, deletion_executed=False), indent=2))
