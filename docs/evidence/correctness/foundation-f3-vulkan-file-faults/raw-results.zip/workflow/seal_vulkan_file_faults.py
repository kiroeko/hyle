from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

repo = Path.cwd(); raw = repo / '.scratch/foundation-f3/native-windows-vulkan-file-faults'
job = json.loads((raw / 'job.json').read_text())
assert all(row['state'] == 'terminal' and row['exit_code'] == 0 for row in job['stages'])
for row in job['stages']:
    assert hashlib.sha256((raw / row['log']).read_bytes()).hexdigest() == row['sha256']
for row in job['inputs']:
    assert hashlib.sha256((repo / row['path']).read_bytes()).hexdigest() == row['sha256']
tests = ET.parse(raw / 'files.xml').getroot()
assert tests.attrib['tests'] == '5' and tests.attrib['failures'] == '0' and tests.attrib['errors'] == '0'
out = repo / 'evidence/correctness/foundation-f3-vulkan-file-faults'
out.mkdir(parents=True, exist_ok=True); archive = out / 'raw-results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as packed:
    for path in sorted(raw.iterdir()):
        if path.is_file(): packed.writestr(path.name, path.read_bytes())
    for name in ['run_native_windows.py', 'seal_vulkan_file_faults.py']:
        path = repo / '.scratch/foundation-f3' / name
        packed.writestr('workflow/' + name, path.read_bytes())
receipt = {'schema_version': 1, 'product_commit': 'f3d931c47777f7fbfd35dedf1f5e0734fa28ef6c',
    'fixture_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'scope': 'Windows actual native Vulkan F3 file/producer/fault lifetime seams only',
    'tests_passed': 5, 'compiler': job['compiler'], 'actual_gpu': (raw / 'identity.log').read_text().strip(),
    'source_inputs': job['inputs'],
    'risks': ['Original queue submit rejected after first four successful chunks: earlier GPU-ready group preserves bytes, read=320/copied=256, original ResourceExhausted retained.',
        'Original fence poll/wait/drain observation unknown while accepted copy owns guards: no ready, cancellation/abandonment does not free actual uses; restore actual observation, preserve original error, uses and metadata retire.',
        'Original accepted native upload producer plus original LeaseUsePool/RetainedCompletion orders D2H before actual file bytes.'],
    'cost': 'Fixed one slot for faults, existing two-slot replay regression, real use guards and injected F3 allocator balanced; native-private costs remain unknown.',
    'archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'verdict': 'PASS_WINDOWS_VULKAN_F3_NATIVE_FILE_FAULTS_AND_PRODUCER_SEAMS_ONLY',
    'unproven': ['Air same fixtures', 'Apple added producer/late-fault cases', 'New CPU boundaries and WSL/sanitizers', 'Installed deliveries/final closure'],
    'budget': 'Original F3-02/04/06 risk acceptance, no product change/new FIX/budget reset; tests reuse original F2 native fault boundaries.'}
(out / 'receipt.json').write_bytes(json.dumps(receipt, indent=2).encode() + b'\n')
print('Windows actual Vulkan five file tests and precise fixture hashes passed.')
