"""Called only by the reviewed root test.ps1 exact-leaf cleanup."""
from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('aj_delete_helpers',S/'apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
plan=json.loads((S/'cleanup-plan.json').read_bytes())
code=r'''
from pathlib import Path
import hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['root']);assert root.name=='qwen-native-assembly-20261022';assert not root.is_symlink()
def check(item):
 path=Path(item['path']);assert path.resolve().is_relative_to(root.resolve()) and path.is_file() and not path.is_symlink(),str(path)
 raw=path.read_bytes();assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],str(path)
for item in p['items']:
 check(item)
 if 'reuses' in item:check(item['reuses'])
for item in p['items']:Path(item['path']).unlink()
receipt=dict(result='deleted_exact_leaves',deleted=p['items'],bytes=sum(x['bytes'] for x in p['items']),recursive_delete=False)
(root/'cleanup-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
result=h.m.ssh(code,dict(root=plan['apple_root'],items=plan['apple']),timeout=90)
h.m.save(S/'cleanup-apple.json',result)
print(json.dumps(dict(result=result['result'],leaves=len(result['deleted']),bytes=result['bytes'])))
