"""Write exact obsolete leaves to test.ps1 after preserving evidence."""
from pathlib import Path
import hashlib, importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('aj_cleanup_helpers',S/'apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def identity(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
windows=[]
for revision in [1,2]:
    for suffix in ['.exe','.map','.lib','.exp']:
        path=S/('cuda-link'+str(revision))/('qwen'+suffix)
        if path.is_file():windows.append(identity(path))
for mode in ['plain','mtp']:
    for suffix in ['', '3']:
        comparison=json.loads((S/('cuda-'+mode+'-comparison'+suffix+'.json')).read_bytes())
        for vector in comparison['raw_vectors']:
            assert vector['equal']
            current=vector['current']; baseline=vector['before']
            assert identity(Path(current['path']))==current and identity(Path(baseline['path']))==baseline
            windows.append(dict(**current,reuses=baseline))
native=json.loads((S/'apple/native-checks.json').read_bytes());runs={x['name']:x for x in native['runs']}
remote=[]
for old,new in [('plain-run4','plain-run5'),('mtp-run1','mtp-run2')]:
    final={x['relative']:x for x in runs[new]['vectors']}
    for previous in runs[old]['vectors']:
        retained=final[previous['relative']]
        if previous['sha256']==retained['sha256']:
            remote.append(dict(path=previous['path'],bytes=previous['bytes'],sha256=previous['sha256'],reuses=dict(path=retained['path'],bytes=retained['bytes'],sha256=retained['sha256'])))
extra=['native-append','objects/consumer.o','revision2/native-append','revision2/main.o','revision3/native-append']
more=h.m.ssh(r'''
from pathlib import Path
import hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['root']);items=[]
for rel in p['names']:
 path=root/rel;assert path.is_relative_to(root) and not path.is_symlink()
 if path.is_file():
  raw=path.read_bytes();items.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
print(json.dumps(items))
''',dict(root=h.m.REMOTE,names=extra))
remote.extend(more)
plan=dict(windows=windows,apple=remote,apple_root=h.m.REMOTE,
          evidence=h.m.ident(R/'docs/evidence/correctness/qwen-native-assembly-2026-10-22.json'),
          archive=h.m.ident(R/'docs/evidence/correctness/qwen-native-assembly-2026-10-22-logs.zip'),
          retained='Final Windows cuda-link3, Apple revision4 image/main and revision3 Copy archive/object, baseline CUDA raw and final Apple raw, reusable full model and original caches.',
          bytes=sum(x['bytes'] for x in windows+remote))
h.m.save(S/'cleanup-plan.json',plan)
old=R/'test.ps1';before=S/'before/test.ps1';before.parent.mkdir(exist_ok=True)
if not before.exists():before.write_bytes(old.read_bytes())
script=r'''# AJ exact-leaf cleanup; evidence and retained replacements checked first.
$ErrorActionPreference = 'Stop'
$taskRoot = Join-Path $PSScriptRoot '.scratch/qwen-native-assembly-20261022'
$planPath = Join-Path $taskRoot 'cleanup-plan.json'
$plan = Get-Content -Raw -LiteralPath $planPath | ConvertFrom-Json
function Test-Identity($item) {
    $file = Get-Item -LiteralPath $item.path -Force
    if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not a regular leaf: $($item.path)" }
    if ($file.Length -ne $item.bytes -or (Get-FileHash -LiteralPath $item.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "Identity changed: $($item.path)" }
}
Test-Identity $plan.evidence
Test-Identity $plan.archive
$allowedRoot = [IO.Path]::GetFullPath($taskRoot).TrimEnd('\') + '\'
foreach ($item in $plan.windows) {
    $absolute = [IO.Path]::GetFullPath($item.path)
    if (-not $absolute.StartsWith($allowedRoot, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task root: $absolute" }
    Test-Identity $item
    if ($item.reuses) { Test-Identity $item.reuses }
}
$deleted = @()
foreach ($item in $plan.windows) {
    Remove-Item -LiteralPath $item.path -Force
    $deleted += $item
}
$receipt = @{ result = 'deleted_exact_leaves'; deleted = $deleted; bytes = ($deleted | Measure-Object -Property bytes -Sum).Sum }
$receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-windows.json') -Encoding utf8
python (Join-Path $taskRoot 'delete_native_leaves.py')
if ($LASTEXITCODE -ne 0) { throw 'Native cleanup failed; inspect receipts before retrying' }
Write-Output "Removed $($deleted.Count) Windows leaves; native receipt saved. No recursive deletion."
'''
old.write_text(script,encoding='utf8')
print(json.dumps(dict(windows=len(windows),apple=len(remote),bytes=plan['bytes'],script=identity(old))))
