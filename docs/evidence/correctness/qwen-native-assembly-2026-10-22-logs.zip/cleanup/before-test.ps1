$ErrorActionPreference = "Stop"
$repo = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$targets = @(
  @{ Relative = '.scratch/native-paged-effects-20261022/vulkan-link1/native-paged-append.exe'; Bytes = 68268032; SHA256 = '0468d1c60b5550a47842d2508ce6a68f9342089a3a508d31b0dca18dc9716e0c' }
  @{ Relative = '.scratch/native-paged-effects-20261022/vulkan-link1/native-paged-append.map'; Bytes = 31069938; SHA256 = 'ab11a7a6443aaac670e92642d7abab3302be55dc923ba191eb1bc93042bcd59b' }
  @{ Relative = '.scratch/native-paged-effects-20261022/vulkan-link1/native-paged-append.lib'; Bytes = 42790; SHA256 = 'd521e0a4797742cb3ff0be8233137f8802f7ca3860cddf0c9d384b14e2b41f12' }
  @{ Relative = '.scratch/native-paged-effects-20261022/vulkan-link1/native-paged-append.exp'; Bytes = 25009; SHA256 = '8de97fd995e515394afb2a53998cd2dbcb0491557796fac25e66370c17c6839b' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/vulkan-link1/native-paged-capacity.exe'; Bytes = 68304896; SHA256 = 'bef91a26ee026681566eb3d685075efee5cfe1186f4cb66e8f93803e160d5dce' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/vulkan-link1/native-paged-capacity.map'; Bytes = 31082543; SHA256 = '4f78284c45c2db74af5fb9ce596b1c593f20a15f95c9502cc24176b3eff01b15' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/vulkan-link1/native-paged-capacity.lib'; Bytes = 42968; SHA256 = '33603872131ef30be2fd4ff62f45a1d604474ed29232f481a80759975f061478' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/vulkan-link1/native-paged-capacity.exp'; Bytes = 25014; SHA256 = '46c8d371ffb5bccb0c5525614d0ed090a6fd8bf7fcc30b6e49be985762e242af' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/vulkan-link2/native-paged-capacity.map'; Bytes = 31089961; SHA256 = 'f6feeb81ede07ecff26b9e911be25b920dd27f78b3a9d47664422e82e82fe5d2' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/vulkan-link2/native-paged-capacity.lib'; Bytes = 42968; SHA256 = '33603872131ef30be2fd4ff62f45a1d604474ed29232f481a80759975f061478' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/vulkan-link2/native-paged-capacity.exp'; Bytes = 25014; SHA256 = 'ad43283bba908410e71aa2601246d144a9f38d368988ccf8814f631dde9b6867' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/ordered-cast-link1/ordered-cast.exe'; Bytes = 67466752; SHA256 = '1a60499298a21bd5c8a38848e71a75945ec431bb403c0df6a4c2d84e7850e862' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/ordered-cast-link1/ordered-cast.map'; Bytes = 30258275; SHA256 = '5e32b266f8ddc5f7172640a09adcdeef597c3336d732f05fc8158edf5a6d2959' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/ordered-cast-link1/ordered-cast.lib'; Bytes = 42166; SHA256 = '863c4d1eb8479853bce9d9b5a53222f802bff103655b60b620c4dcb7032fdff3' }
  @{ Relative = '.scratch/native-paged-capacity-20261022/ordered-cast-link1/ordered-cast.exp'; Bytes = 25003; SHA256 = '85d34d424293078fc6c45d38158627f6b6e6ea75d8c0817c2c350cd8eb705749' }
)
$scratch = [IO.Path]::GetFullPath((Join-Path $repo '.scratch')) + [IO.Path]::DirectorySeparatorChar
foreach ($target in $targets) {
  $path = [IO.Path]::GetFullPath((Join-Path $repo $target.Relative))
  if (-not $path.StartsWith($scratch, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace: $path" }
  $file = Get-Item -LiteralPath $path
  if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not an original file: $path" }
  if ($file.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $target.SHA256) { throw "Changed target: $path" }
}
$removed = @()
foreach ($target in $targets) {
  $path = [IO.Path]::GetFullPath((Join-Path $repo $target.Relative))
  Remove-Item -LiteralPath $path -Force
  $removed += @{ Path = $path; Bytes = $target.Bytes; SHA256 = $target.SHA256 }
}
$receipt = Join-Path $repo '.scratch/native-paged-capacity-20261022/cleanup-windows.json'
@{ Removed = $removed; Recursive = $false } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $receipt -Encoding utf8
# Exact remote targets, validated by full path, size and SHA before unlink:
# /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-paged-effects-20261022/lowering-fix1/native-append SHA256 593860d1cafd94e1abb6f5cd77358bbf7086ca30542856f7cd06c20043c8ccea
# /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/native-paged-effects-20261022/lowering-fix1/libhyle_graph_route_apple.a SHA256 09e3496862f7a78699c03e3c8d43395bb9bb179500f830482e829ebf906810ad
& python (Join-Path $repo '.scratch/native-paged-capacity-20261022/cleanup.py') remote
if ($LASTEXITCODE -ne 0) { throw "Remote cleanup failed; inspect its receipt" }
Write-Output ("Removed {0} exact Windows leaves; no recursive deletion" -f $removed.Count)
