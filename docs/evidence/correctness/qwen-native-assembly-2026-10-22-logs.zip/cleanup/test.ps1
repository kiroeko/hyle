# AJ exact-leaf cleanup; evidence and retained replacements checked first.
$ErrorActionPreference = 'Stop'
$taskRoot = Join-Path $PSScriptRoot '.scratch/qwen-native-assembly-20261022'
$planPath = Join-Path $taskRoot 'cleanup-plan.json'
$plan = Get-Content -Raw -LiteralPath $planPath | ConvertFrom-Json
function Test-Identity($item) {
    $file = Get-Item -LiteralPath $item.path -Force
    if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not a regular leaf: $($item.path)" }
    if ($file.Length -ne $item.bytes -or (Get-FileHash -LiteralPath $item.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256) { throw "Identity changed: $($item.path)" }
}
Test-Identity $plan.evidence
Test-Identity $plan.archive
$allowedRoot = [IO.Path]::GetFullPath($taskRoot).TrimEnd('\') + '\'
foreach ($item in $plan.windows) {
    $absolute = [IO.Path]::GetFullPath($item.path)
    if (-not $absolute.StartsWith($allowedRoot, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside task root: $absolute" }
    Test-Identity $item
    if ($item.reuses) { Test-Identity $item.reuses }
}
$deleted = @()
foreach ($item in $plan.windows) {
    Remove-Item -LiteralPath $item.path -Force
    $deleted += $item
}
$receipt = @{ result = 'deleted_exact_leaves'; deleted = $deleted; bytes = ($deleted | Measure-Object -Property bytes -Sum).Sum }
$receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-windows.json') -Encoding utf8
python (Join-Path $taskRoot 'delete_native_leaves.py')
if ($LASTEXITCODE -ne 0) { throw 'Native cleanup failed; inspect receipts before retrying' }
Write-Output "Removed $($deleted.Count) Windows leaves; native receipt saved. No recursive deletion."
