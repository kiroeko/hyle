"""Record already-completed cleanup; never deletes or reruns model work."""
from pathlib import Path
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[1];E=R/'docs/evidence/correctness'
def read(p):return json.loads(p.read_bytes())
def ident(p):
    raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
win=read(S/'cleanup-windows.json');mac=read(S/'cleanup-apple.json');plan=read(S/'cleanup-plan.json')
assert len(win['deleted'])==len(plan['windows']) and len(mac['deleted'])==len(plan['apple'])
assert all(not Path(x['path']).exists() for x in win['deleted'])
assert (S/'cuda-link3/qwen.exe').is_file()
archive=E/'qwen-native-assembly-2026-10-22-logs.zip';added=[]
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as z:
    for name,path in [('test.ps1',R/'test.ps1'),('before-test.ps1',S/'before/test.ps1'),
                      *[(x,S/x) for x in ['cleanup-plan.json','cleanup-windows.json','cleanup-apple.json','prepare_cleanup.py','delete_native_leaves.py','finalize_cleanup.py']]]:
        target='cleanup/'+name
        assert target not in z.namelist()
        z.write(path,target);added.append(dict(archive_path=target,**ident(path)))
summary=dict(schema=1,date='2026-10-22',result='EXACT_LEAVES_REMOVED',
 Windows_leaves=len(win['deleted']),Apple_leaves=len(mac['deleted']),
 unlinked_logical_bytes=int(win['bytes'])+int(mac['bytes']),
 note='Sum of unlinked file sizes, not a filesystem free-space measurement. No recursive deletion. Exact identities/replacement payloads and executed script are in the evidence archive.',
 retained=plan['retained'],executed_test_script=ident(R/'test.ps1'),evidence_archive=ident(archive),
 cleanup_records=added)
save(E/'qwen-native-assembly-2026-10-22-cleanup.json',summary)
doc=read(E/'qwen-native-assembly-2026-10-22.json')
doc['evidence_archive']=ident(archive);doc['archive_entries']+=added
doc['cleanup']=dict(receipt=ident(E/'qwen-native-assembly-2026-10-22-cleanup.json'),
                   current_cuda_raw_payloads='Byte-identical raw files reuse their explicitly recorded retained baseline payloads. Superseded Apple raw payloads reuse the final native run files. Removed paths remain historical identities, not claimed to still exist.',
                   executed=True,script_must_not_be_rerun=True)
save(E/'qwen-native-assembly-2026-10-22.json',doc)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))
    for record in doc['archive_entries']:
        data=z.read(record['archive_path']);assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
print(json.dumps(dict(evidence=ident(E/'qwen-native-assembly-2026-10-22.json'),archive=ident(archive),unlinked_logical_bytes=summary['unlinked_logical_bytes'],leaves=summary['Windows_leaves']+summary['Apple_leaves'])))
