"""One frozen Apple copy TU, original archive members and current consumer."""
from pathlib import Path
import base64, importlib.util, json, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
spec = importlib.util.spec_from_file_location('aj_copy_helpers', S/'apple.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
cached = json.loads((R/'.scratch/native-paged-effects-20261022/apple/mac-cached-closure.json').read_bytes())
base = json.loads((R/'.scratch/native-paged-capacity-20261022/apple/mac-plan.json').read_bytes())
plan = json.loads((S/'apple/mac-plan.json').read_bytes())
freeze = json.loads((S/'apple-copy-release/source-freeze.json').read_bytes())
source = freeze['product_files'][0]['path']
assert m.ident(R/source)['sha256'] == freeze['product_files'][0]['sha256']
row = next(x for x in cached['compile'] if x['file'].endswith('/'+source))
archive = next(x for x in base['archives'] if x['module'] == 'graph_route_apple')
root = m.REMOTE
revision = root+'/revision3'
m.REMOTE = revision
obj = revision+'/execution_source.o'
command = m.overlay_command(row, source, obj)
files = []
for path in m.include_closure([source], [command]):
    entry = m.ident(path)
    entry['path'] = path.relative_to(R).as_posix()
    entry['data'] = base64.b64encode(path.read_bytes()).decode()
    files.append(entry)
members = [obj if x.endswith('/execution_source.cc.o') else x for x in archive['objects']]
assert sum(x == obj for x in members) == 1
lib = revision+'/libhyle_graph_route_apple.a'
pack = ['/usr/bin/libtool', '-static', '-o', lib, *members]
link = [root+'/revision2/main.o' if x == plan['consumer_job']['object'] else
        lib if x == archive['path'] else revision+'/native-append' if x == root+'/native-append' else
        x for x in plan['link']]
payload = dict(remote=revision, original_root=root, sdk=m.SDK, source=freeze['product_files'][0],
               files=files, actions=[['compile', command], ['archive', pack], ['link', link]])
m.save(S/'apple/revision3-plan.json', {**payload, 'files': [{k:v for k,v in x.items() if k!='data'} for x in files]})
code = r'''
from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);root.mkdir();source=root/'source';source.mkdir()
for x in p['files']:
 path=source/x['path'];path.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(x['data']);assert len(raw)==x['bytes'] and hashlib.sha256(raw).hexdigest()==x['sha256'];path.write_bytes(raw)
records=[]
for action,argv in p['actions']:
 record=dict(command=argv,cwd=p['sdk']+'/build',started=time.time(),source=p['source'])
 with (root/(action+'.stdout.log')).open('wb') as so,(root/(action+'.stderr.log')).open('wb') as se:
  child=subprocess.Popen(argv,cwd=record['cwd'],env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
 record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(root/(action+'.result.json')).write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 if child.returncode:break
result=dict(records=records,all_exit_zero=len(records)==3 and all(x['exit']==0 for x in records))
if result['all_exit_zero']:
 os.link(Path(p['original_root'])/'mlx.metallib',root/'mlx.metallib');image=root/'native-append';raw=image.read_bytes();result['image']=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());(root/'ready.json').write_text(json.dumps(result,indent=2)+'\n')
else:result['stderr']=(root/(p['actions'][len(records)-1][0]+'.stderr.log')).read_text(errors='replace')
print(json.dumps(result))
'''
result = m.ssh(code, payload, timeout=180)
m.save(S/'apple/revision3.json', result)
print(json.dumps(dict(all_exit_zero=result['all_exit_zero'], records=[{k:v for k,v in x.items() if k!='command'} for x in result['records']], image=result.get('image'), stderr=result.get('stderr'))))
if not result['all_exit_zero']:
    raise SystemExit(1)
