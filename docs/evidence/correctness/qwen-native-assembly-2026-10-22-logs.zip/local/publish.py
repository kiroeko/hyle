"""Preserve the bounded native assembly work, without model/SDK/binary copies."""
from pathlib import Path
import difflib, hashlib, json, subprocess, zipfile
S=Path(__file__).resolve().parent; R=S.parents[1]
E=R/'docs/evidence/correctness'
def read(path):return json.loads(path.read_bytes())
def ident(path):
    raw=path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
products=['tools/qwen35_text/'+x for x in ['main.cc','backend.h','retirement_probe.cc','batch_probe.cc','mtp_session_probe.cc','CMakeLists.txt','README.md']]+['src/graph_route_apple/execution_source.cc','docs/developer/current-work.md']
snapshot=S/'final-source'
diffs=[]
for rel in products:
    current=R/rel
    dest=snapshot/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(current.read_bytes())
    before=S/'before'/rel
    if rel=='src/graph_route_apple/execution_source.cc':before=S/'apple-copy-release/before'/rel
    if before.is_file():
        check=subprocess.run(['git','diff','--no-index','--check',str(before),str(current)],capture_output=True,text=True,encoding='utf8',errors='replace')
        if check.returncode not in (0,1) or check.stdout.strip() or check.stderr.strip():raise RuntimeError(check.stdout+check.stderr)
        diffs.extend(difflib.unified_diff(before.read_text(encoding='utf8').splitlines(keepends=True),current.read_text(encoding='utf8').splitlines(keepends=True),fromfile='before/'+rel,tofile=rel))
(S/'changes.diff').write_text(''.join(diffs),encoding='utf8')
native=read(S/'apple/native-checks.json')
final_runs=[x for x in native['runs'] if x['name'] in ('plain-run5','mtp-run2')]
cuda={mode:read(S/('cuda-'+mode+'-comparison3.json')) for mode in ['plain','mtp']}
assert native['all_exit_zero'] and native['all_finite'] and len(final_runs)==2
assert all(x['all_equal'] for x in cuda.values())
main=ident(R/'tools/qwen35_text/main.cc')
assert read(S/'compile3/main/identity.json')['source']['sha256']==main['sha256']
assert read(S/'apple/revision4.json')['records'][0]['source']['sha256']==main['sha256']
zip_path=E/'qwen-native-assembly-2026-10-22-logs.zip'
entries=[]
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(S.rglob('*')):
        if not path.is_file() or path==zip_path or path.name=='native-logs.zip':continue
        if path.suffix.lower() not in ('.json','.log','.py','.cc','.h','.txt','.tsv','.ids','.diff','.md','.ps1'):continue
        if any(x in path.relative_to(S).parts for x in ('tmp',)):continue
        if path.stat().st_size>8*1024*1024:continue
        name='local/'+path.relative_to(S).as_posix()
        z.write(path,name);entries.append(dict(archive_path=name,**ident(path)))
    with zipfile.ZipFile(S/'apple/native-logs.zip') as remote:
        for item in remote.infolist():
            data=remote.read(item)
            name='apple/'+item.filename
            z.writestr(name,data)
            entries.append(dict(archive_path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    for rel in ['tools/qwen35_text/mtp_graph.h','tools/qwen35_text/session_state.h','tools/qwen35_text/session_schedule.h']:
        path=R/rel
        if path.is_file():
            name='consumer-context/'+rel;z.write(path,name);entries.append(dict(archive_path=name,**ident(path)))
document=dict(schema=1,date='2026-10-22',result='PASS_LIMITED_COMPLETE_CONSUMER',
 scope='Same Qwen3.5-2B mathematical Graph on native Apple R1, ordinary and greedy K1 MTP; CUDA regression. Not complete MTP/backend/model/quality acceptance.',
 progress_estimate=dict(percent=65,range=[60,70],basis='Engineering estimate for the complete cross-backend/selected-model MTP work; not a test-pass percentage.'),
 implementation=[
  'One cold Backend owns original Context, allocation domains, execution source, file pipeline and external I/O. Recipe/mtp_graph and Graph execution remain shared.',
  'CUDA retains original StorageOwner/device/pinned/Queue route. Apple uses actual native shared resources/FIFO and no common Queue shell.',
  'Raw native constants use the supported explicit borrow form, with both common StorageOwner and its ready field absent. Model/Family retain the actual source leases and Backend lifetime.',
  'Immutable caller-output facts come from each selected child. Actual initial/caller state pools are prepared after all finite roles/shapes, without native candidate shadow buffers.',
  'Generated state/carry/ID/diagnostic outputs retain their actual GraphOutput owners before append take and retired input unbind. All 12/14 page transactions still use whole-Graph success/publication.',
  'The real selected Apple Copy regions now expose their original recording retired gate and clear bindings only after retirement. Recordings remain reusable; no permission or lifetime check is bypassed.',
  'State storage preparation uses local pools/counts and publishes only after all allocations and actual budget accounting succeed. Allocation-failure injection was not run.',
  'Opaque native allocations use an unattributed-aware execution budget; known cache pools are separate. Explicit native --cache-bytes is rejected before loading; auto is not a complete native backing hard cap.',
  'Standalone CMake uses exported route facts for Apple/CUDA and excludes CUDA Queue-blocking probes on Apple. CMake configure/package consumption was not run in this batch.'
 ],
 native=dict(hardware='Mac16,12 / Apple M4 / 16 GiB',model_cache=read(S/'model-cache.json'),
  final_image=read(S/'apple/revision4.json')['image'],runs=final_runs,
  final_vector_count=sum(len(x['vectors']) for x in final_runs),all_finite=True,
  first_mtp_decisions=final_runs[1]['result']['rounds'],
  shared_generated_ids=final_runs[0]['result']['generated_ids'],
  ordinary_graph_calls=4,mtp_graph_calls=3,scope='P15, at most 4 outputs, C64, N1/R1, no prefix, commands replay, full trace'),
 cuda=dict(final_image=read(S/'cuda-link3/ready.json')['image'],comparisons=cuda,
  final_vector_count=sum(len(x['raw_vectors']) for x in cuda.values()),all_byte_equal=True,
  baseline='Retained current-numerics cuBLASLt consumer; identical original inputs and math policy.',
  probe_host_compile_records=[ident(S/('compile3/'+x+'/identity.json')) for x in ['retirement','batch','mtp_session']],
  probe_caveat='Probe interfaces compiled before the final local pool-publication change. These 3 diagnostic images were not linked/run; final main.cc itself compiled and ran on CUDA/Apple.'),
 failed_attempts=[
  dict(name='Apple plain-run1',reason='Runner used unsupported --trace-states; no model execution; runner corrected.'),
  dict(name='Apple plain-run2',reason='Cold constant binding supplied only one member of the StorageOwner/ready pair; fixed supported native borrowed form.'),
  dict(name='Apple plain-run3',reason='Completed native prefill reached unbind but selected real Copy lacked binding-release capability; no head committed; fixed original recording release contract.')],
 build=dict(Windows_CXX=6,Apple_CXX=4,SDK_builds=0,NVCC=0,dependency_rebuilds=0,
  note='3 Windows consumer revisions + 3 interface probes; 3 Apple consumer revisions + 1 native Copy TU. Original native runtime lazily compiles its embedded Metal pipelines normally.'),
 remaining=[
  'Account actual native generated-state/shared packed/MLX private backing without fake logical-byte charges or candidate shadow copies; complete strict cache-byte admission.',
  'Native Apple complete multi-session, prefix, reconstruction, catch-up/T1 and retirement combinations beyond this short R1 run.',
  'Vulkan generated-output fixed backing reuse while an old Snapshot retains readers; no weakening existing reuse gates.',
  'Other selected models/quantizations, cross-shape/model quality and full end-to-end MTP performance.',
  'The explicit native cache-byte rejection is source-reviewed, not a separate executed CLI test in this batch.'
 ],
 performance=dict(new_full_window=False,trace_diagnostic=True,latest_window_unchanged='docs/developer/current-work.md#最新完整性能对比'),
 product_sources=[ident(R/x) for x in products],
 evidence_archive=ident(zip_path),archive_entries=entries)
save(E/'qwen-native-assembly-2026-10-22.json',document)
print(json.dumps(dict(evidence=ident(E/'qwen-native-assembly-2026-10-22.json'),archive=ident(zip_path),records=len(entries),native_vectors=document['native']['final_vector_count'],cuda_equal_vectors=document['cuda']['final_vector_count'])))
