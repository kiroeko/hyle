"""Inspect existing native run artifacts; no model execution."""
from pathlib import Path
import base64, importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; R=S.parents[1]
spec=importlib.util.spec_from_file_location('aj_check_helpers',S/'apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
code=r'''
from pathlib import Path
import array,base64,hashlib,io,json,math,sys,zipfile
p=json.load(sys.stdin);root=Path(p['remote']);runs=[];pack=io.BytesIO()
def identity(path):
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
for label in ['plain-run4','mtp-run1','plain-run5','mtp-run2']:
 out=root/label;vectors=[]
 for path in sorted((out/'trace').rglob('*')):
  if not path.is_file() or path.suffix not in ('.bf16','.f32'):continue
  raw=path.read_bytes();values=array.array('H' if path.suffix=='.bf16' else 'f');values.frombytes(raw)
  bad=sum((x&0x7f80)==0x7f80 for x in values) if path.suffix=='.bf16' else sum(not math.isfinite(x) for x in values)
  entry=dict(relative=path.relative_to(out).as_posix(),**identity(path),nonfinite=bad)
  if path.name=='logits.f32':
   assert len(values)%248320==0
   entry['argmax']=[max(range(248320),key=lambda j:values[i+j]) for i in range(0,len(values),248320)]
  vectors.append(entry)
 result=json.loads((out/'stdout.log').read_bytes());record=json.loads((out/'result.json').read_bytes())
 runs.append(dict(name=label,record=record,result=result,vectors=vectors,all_finite=all(x['nonfinite']==0 for x in vectors)))
metadata=dict(runs=runs,all_exit_zero=all(x['record']['exit']==0 for x in runs),all_finite=all(x['all_finite'] for x in runs),performance_comparison=False)
(root/'native-checks.json').write_text(json.dumps(metadata,indent=2)+'\n')
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(root.rglob('*')):
  if not path.is_file() or path.suffix not in ('.json','.log','.tsv','.ids'):continue
  if 'source' in path.relative_to(root).parts:continue
  if path.stat().st_size>8*1024*1024:continue
  z.write(path,path.relative_to(root).as_posix())
print(json.dumps(dict(checks=metadata,log_archive=base64.b64encode(pack.getvalue()).decode())))
'''
result=h.m.ssh(code,dict(remote=h.m.REMOTE),timeout=90)
h.m.save(S/'apple/native-checks.json',result['checks'])
(S/'apple/native-logs.zip').write_bytes(base64.b64decode(result['log_archive']))
print(json.dumps(dict(all_exit_zero=result['checks']['all_exit_zero'],all_finite=result['checks']['all_finite'],runs=[dict(name=x['name'],vectors=len(x['vectors']),ids=x['result']['generated_ids']) for x in result['checks']['runs']]),ensure_ascii=False))
assert result['checks']['all_exit_zero'] and result['checks']['all_finite']
