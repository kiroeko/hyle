"""Compile the one consumer TU and reuse the current CUDA dependency closure."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('aj_cached_host',R/'.scratch/native-paged-effects-20261022/build_windows.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
BASE=R/'.scratch/qwen-cublas-scores-20261022/qwen-link1'
base=c.read(BASE/'link-plan.json')
main_record=Path(base['consumer_compiled_record']['path'])
h.S=S;h.RECIPES={'main':main_record};h.SOURCES={'main':R/'tools/qwen35_text/main.cc'}
def compile_one(attempt):h.compile_one('main',attempt)
def link(attempt):
 rec=c.read(S/f'compile{attempt}/main/identity.json');old=c.read(main_record)
 replacements={c.key(old['object']['path']):rec['object']}
 # Current native capability/controller integration changes no public layout.
 # Retain the original CUDA closure but replace the original common owners.
 for tag,path in [('batch',R/'.scratch/native-paged-capacity-20261022/compile1/batch/identity.json'),
                  ('native-batch',R/'.scratch/native-paged-capacity-20261022/compile1/native-batch/identity.json'),
                  ('append',R/'.scratch/native-paged-effects-20261022/compile2/append/identity.json'),
                  ('resources',R/'.scratch/native-paged-effects-20261022/compile1/resources/identity.json')]:
  # Canonical source owner comes from the retained AH/AD records rather than basename guesses.
  owner=c.read(path)
  old_path=R/'.scratch/qwen-mtp-round-20261022/compile1'/tag/'identity.json' if tag in ('batch','append','resources')else R/'.scratch/paged-recording-20261021/checks/attempt1/graph_batch--native_batch_regions/identity.json'
  previous=c.read(old_path)['object']
  assert sum(c.key(x['path'])==c.key(previous['path'])for x in base['inputs'])==1,(tag,previous)
  replacements[c.key(previous['path'])]=owner['object']
 for item in base['inputs']:assert b.identity(item['path'])==item
 for value in replacements.values():assert b.identity(value['path'])==value
 out=S/f'cuda-link{attempt}';out.mkdir();(out/'tmp').mkdir();image=out/'qwen.exe'
 command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]
 c.save(out/'link-plan.json',dict(command=command,inputs=inputs,consumer=b.identity(S/f'compile{attempt}/main/identity.json'),base=b.identity(BASE/'link-plan.json'),SDK_builds=0,NVCC=0))
 env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
 runtime=c.read(BASE/'runtime-environment.json')
 for item in runtime['staged_dlls']:
  assert b.identity(item['path'])==item;os.link(item['path'],out/Path(item['path']).name)
 runtime['PATH']=env['PATH'];runtime['staged_dlls']=[b.identity(x)for x in out.glob('*.dll')]
 c.save(out/'runtime-environment.json',runtime);c.save(out/'ready.json',dict(image=b.identity(image),consumer=rec['source'],plan=b.identity(out/'link-plan.json')))
 print('LINKED current CUDA consumer',flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=('compile','link'));p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
 if a.action=='compile':compile_one(a.attempt)
 else:link(a.attempt)
