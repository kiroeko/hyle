"""Observe the exact live Mac consumer PID and its existing log; never restart."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('aj_monitor_helpers',S/'apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
result=h.m.ssh(r'''
from pathlib import Path
import json,subprocess,sys
p=json.load(sys.stdin);root=Path(p['remote']);state=json.loads((root/'live.json').read_text());pid=state['pid']
observed=subprocess.run(['/bin/ps','-p',str(pid),'-o','pid=,state=,etime=,rss=,command='],capture_output=True,text=True)
log=root/p['log'];text=log.read_text(errors='replace')if log.exists()else''
print(json.dumps(dict(state=state,process_observation=dict(exit=observed.returncode,stdout=observed.stdout.strip()),log_tail=text[-4000:])))
''',dict(remote=h.m.REMOTE,log=sys.argv[1]if len(sys.argv)>1 else'plain-run3/stderr.log'))
print(json.dumps(result,ensure_ascii=False))
