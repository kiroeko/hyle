"""Mechanical consumer boundary renames; no model mathematics changes."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
path=R/'tools/qwen35_text/main.cc';text=path.read_text(encoding='utf8')
text=text.replace('planning_memory.ref()', 'execution.staging()')
text=text.replace('memory.ref()', 'execution.device()')
text=text.replace('const std::array queues{g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &queue}};',
                  'const auto queues = execution.queue_bindings();')
text=text.replace('live_bytes != selected_cache.backing_bytes', 'live_bytes != model.known_cache_backing_bytes')
path.write_text(text,encoding='utf8')
for name in ('retirement_probe.cc','batch_probe.cc','mtp_session_probe.cc'):
 path=R/'tools/qwen35_text'/name;text=path.read_text(encoding='utf8')
 text=text.replace('model.memory.ref()', 'model.execution.device()')
 text=text.replace('model.context', 'model.execution.common_context()')
 text=text.replace('model.queue', 'model.execution.common_queue()')
 path.write_text(text,encoding='utf8')
