"""Read-only inventory of the retained Mac cache and named model-input locations."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
AH = ROOT / '.scratch/native-paged-effects-20261022/apple'
AI = ROOT / '.scratch/native-paged-capacity-20261022/apple'
spec = importlib.util.spec_from_file_location('aj_readonly_ssh', AH / 'mac.py')
mac = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mac)


def ident(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=path.as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


REMOTE = r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);base=Path(p['base']);out={'observed_unix_seconds':time.time()}
def command(argv):
 r=subprocess.run(argv,capture_output=True,text=True,timeout=15)
 return {'command':argv,'exit':r.returncode,'stdout':r.stdout.strip(),'stderr':r.stderr.strip()}
def stat(path,sha=False):
 f=Path(path)
 if not f.is_file():return {'path':str(f),'exists':False}
 s=f.stat();v={'path':str(f),'exists':True,'bytes':s.st_size,'allocated_bytes':s.st_blocks*512}
 if sha:v['sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
 return v
out['hardware']={
 'model':command(['/usr/sbin/sysctl','-n','hw.model']),
 'cpu':command(['/usr/sbin/sysctl','-n','machdep.cpu.brand_string']),
 'memory':command(['/usr/sbin/sysctl','-n','hw.memsize']),
 'swap':command(['/usr/sbin/sysctl','vm.swapusage']),
 'vm_stat':command(['/usr/bin/vm_stat']),
 'os':command(['/usr/bin/sw_vers']),
 'compiler':command(['/usr/bin/clang++','--version']),
 'cmake':command(['/opt/homebrew/bin/cmake','--version']),
 'ninja':command(['/opt/homebrew/bin/ninja','--version'])}
assert out['hardware']['model']['stdout']=='Mac16,12'
v=os.statvfs(base);out['filesystem']={'path':str(base),'block_bytes':v.f_frsize,'available_bytes':v.f_bavail*v.f_frsize,'free_bytes':v.f_bfree*v.f_frsize,'total_bytes':v.f_blocks*v.f_frsize}
out['AI_objects']=[stat(x)for x in p['AI_objects']]
out['selected_archives']=[stat(x)for x in p['archives']]
out['stream_objects']=[stat(x,True)for x in p['stream_objects']]
out['io_archive']=stat(p['io_archive'])
out['runtime_metallibs']=[stat(x)for x in p['metallibs']]
model=Path('/Users/kiro/hyle-scratch/compute-unified/foundation-f3-qwen-input')
out['qwen_sparse']={'shard':stat(model/'model-ranges.safetensors'),
 'verification':json.loads((model/'transfer-verification.json').read_text()),
 'ranges':(model/'ranges.tsv').read_text()}
out['model_scopes']=[]
for path in ['/Users/kiro/hyle-scratch/d5-qwen35-six-profile-fixture','/Users/kiro/hyle-d5-qwen35-fixture-4068044d',str(model),'/Users/kiro/project-hyle/.scratch','/Users/kiro/.cache/huggingface']:
 f=Path(path);row={'path':path,'exists':f.is_dir()}
 if f.is_dir():
  row['immediate_files']={x.name:x.stat().st_size for x in f.iterdir()if x.is_file()and (x.name in ['weights.tsv','prompt.ids','config.json','tokenizer.json','tokenizer_config.json','chat_template.jinja']or x.suffix=='.safetensors')}
  tensors=f/'tensors'
  if tensors.is_dir():
   files=[x for x in tensors.iterdir()if x.is_file()];row['sliced_tensor_count']=len(files);row['sliced_tensor_bytes']=sum(x.stat().st_size for x in files)
 out['model_scopes'].append(row)
print(json.dumps(out))
'''


def main():
    ah = json.loads((AH / 'mac-plan.json').read_text(encoding='utf-8'))
    ai = json.loads((AI / 'mac-plan.json').read_text(encoding='utf-8'))
    sdk = json.loads((AH / 'mac-cached-closure.json').read_text(encoding='utf-8'))
    old_stream = json.loads((STAGE / 'mac-old-stream-records.json').read_text(encoding='utf-8'))
    stream = [v for k, v in old_stream['identities'].items() if k.startswith('src--compute_stream')]
    io_archive = '/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib/libhyle_io_core.a'
    archives = list(dict.fromkeys(x for x in ai['link'] if x.endswith('.a')))
    remote = mac.ssh(REMOTE, dict(base=mac.BASE,
        AI_objects=[x['object'] for x in ai['jobs']] + [ai['consumer_job']['object']],
        archives=archives, stream_objects=[x['object']['path'] for x in stream],
        io_archive=io_archive,
        metallibs=[mac.SDK+'/relocated/sdk/lib/mlx.metallib',mac.SDK+'/relocated/sdk/lib/ggml-metal.metallib']), timeout=90)
    save(STAGE / 'mac-cache-stat.json', remote)
    overrides = {x['source']: x for x in ah['jobs']}
    overrides.update({x['source']: x for x in ai['jobs']})
    hashes = dict(sdk['source_hashes'])
    for plan in [ah, ai]:
        for row in plan['files']:
            hashes[row['path']] = row
    correction = json.loads((AH / 'lowering-boundary-fix/source-freeze.json').read_text(encoding='utf-8'))['files'][0]
    hashes[correction['path']] = correction
    source_drift = []
    source_owners = set(overrides)
    for row in sdk['compile']:
        if '/source/' not in row['file']:
            continue
        rel = row['file'].split('/source/', 1)[1]
        if not rel.startswith('src/') or not (ROOT / rel).is_file():
            continue
        source_owners.add(rel)
    for rel in sorted(source_owners):
        current = ident(ROOT / rel)
        if current['sha256'] != hashes[rel]['sha256']:
            source_drift.append(current)
    stream_proof = []
    for row in stream:
        rel = row['source']['path'].split(mac.BASE+'/', 1)[1]
        actual = next(x for x in remote['stream_objects'] if x['path']==row['object']['path'])
        stream_proof.append(dict(source=rel,current_source=ident(ROOT/rel),
            cached_source=row['source'],cached_object=actual,
            source_exact=ident(ROOT/rel)['sha256']==row['source']['sha256'],
            object_exact=actual.get('sha256')==row['object']['sha256']))
    win = ROOT / '.scratch/qwen-mtp-window-20261022/inputs'
    manifests = []
    for name, count, byte_count in [('text',320,3763655360),('mtp',335,3885311680)]:
        path = win/name/'weights.tsv'
        lines = path.read_text(encoding='utf-8').splitlines()
        manifests.append(dict(selection=name,manifest=ident(path),signature=lines[0],
            shard_path_line=lines[1],source_id=lines[2],tensor_count=len(lines)-3,
            selected_tensor_bytes=sum(int(x.split('\t')[-1])for x in lines[3:]),
            expected_count=count,expected_bytes=byte_count))
    report = dict(status='FROZEN_READ_ONLY_MAC_QWEN_CACHE_INVENTORY',
        scope=dict(SSH_read_only=True,builds=0,links=0,GPU_runs=0,model_or_SDK_copies=0,product_edits=0),
        hardware=remote['hardware'],filesystem=remote['filesystem'],
        cache=dict(base=mac.BASE,sdk=mac.SDK,producer_source=mac.SDK+'/source',producer_build=mac.SDK+'/build',
            relocated_prefix=mac.SDK+'/relocated/sdk',
            AI=ai['remote'],AH=ah['remote'],AI_objects=remote['AI_objects'],
            selected_archives=remote['selected_archives'],runtime_metallibs=remote['runtime_metallibs'],
            existing_product_source_owners_checked=len(source_owners),current_source_drifts=source_drift,
            corrected_lowering=dict(source=correction,object=ah['remote']+'/lowering-fix1/apple_lowering.o',archive=ah['remote']+'/lowering-fix1/libhyle_graph_route_apple.a'),
            source_comparison_limit='Existing selected product source owners only; this is not a full repository or every dependency ABI recertification.',
            ggml_runtime_note='The original selected SDK supplies its GGML runtime artifacts; this inventory does not require a separately named ggml-metal.metallib.'),
        file_pipeline=dict(stream_owners=stream_proof,io_archive=remote['io_archive'],
            original_map=mac.BASE+'/stream-sample-map-objects.txt',
            io_pulled_owners=['src/io_core/proactor.cc','src/io_core/operation.cc','src/io_core/io_context.cc','src/io_core/file.cc'],
            compatibility=[
              'Three stream source files and cached objects match their actual original identities.',
              'Relevant stream public/private headers are identical except additive AppendLease/detach/preflight declarations; no old fields or old inline paths changed.',
              'Old IO archive source.zip: file/operation/io_context source bytes match current. All 31 proactor changed regions are in HYLE_OS_LINUX, outside the Mac branch.',
              'File/IoContext/Operation/Proactor public header drift is centralized visibility macros (empty under HYLE_STATIC) plus comments. Unrelated TCP changes are outside this file-loading closure.'
            ],mandatory_fresh_product_owners=[],new_consumer_TUs=1,
            build_boundary='Reuse AI/AH selected archives, the three retained stream objects and original IO archive. Compile the actual forthcoming Apple consumer source once and link; do not infer that the still-CUDA main is already an Apple consumer.'),
        inputs=dict(current_loader=dict(source=ident(ROOT/'tools/qwen35_text/main.cc'),
            anchors=['tools/qwen35_text/main.cc:704','tools/qwen35_text/main.cc:3495'],
            format='--inputs DIR; DIR/weights.tsv is signature, absolute shard path, source identity, then tab-separated tensor name/dtype/rank/dimensions/offset/count. DIR/prompt.ids is whitespace-separated token IDs; optional prompt.txt only prints text.',
            manifests=manifests,prompt=ident(win/'prompt.ids'),tokenizer_required_at_runtime=False,
            tokenizer_note='prepare.py uses the original local tokenizer offline. The C++ consumer consumes IDs and tensor offsets, not tokenizer files.'),
            original_inventory=ident(ROOT/'docs/implementation/tasks/compute/qwen35-2b-local-input.json'),
            known_remote_qwen=remote['qwen_sparse'],searched_named_scopes=remote['model_scopes'],
            complete_ready_input_found=False,
            conclusion='No complete 320/335-tensor input or tokenizer was found in the named retained Hyle/Qwen/cache locations examined. The 4-range sparse file is not a complete checkpoint and must not be reused as one. This is scoped absence, not a global filesystem search.',
            required_before_actual_model_run='Root must select an already complete verified checkpoint if elsewhere, or separately authorize a bounded necessary model-input transfer. This task copied none; TSV shard path must name the real Mac shard, not the Windows path.'),
        evidence=[ident(STAGE/x)for x in ['mac-cache-stat.json','mac-stream-header-differences.json','mac-io-archive-source-identities.json','mac-io-compatibility.json']],
        limitations=['No configure/build/link/model execution performed. Runtime memory fit and Qwen numerical/route support are untested.',
            '16 GiB is physical unified memory; VM free/inactive/purgeable/swap readings are a timestamped host observation, not a usable-model-memory guarantee.'])
    save(STAGE / 'mac-inventory.json', report)
    print(json.dumps(dict(report=ident(STAGE/'mac-inventory.json'),AI_objects=len(remote['AI_objects']),missing_AI_objects=sum(not x['exists']for x in remote['AI_objects']),archives=len(archives),missing_archives=sum(not x['exists']for x in remote['selected_archives']),source_drifts=source_drift,stream_exact=all(x['source_exact']and x['object_exact']for x in stream_proof),available_bytes=remote['filesystem']['available_bytes']),indent=2))


if __name__ == '__main__':
    main()
