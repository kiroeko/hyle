"""Rebuild one changed consumer TU without overwriting previous attempts."""
from pathlib import Path
import argparse,base64,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('aj_revise_helpers',S/'apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
p=argparse.ArgumentParser(description=__doc__);p.add_argument('revision',type=int);a=p.parse_args()
plan=json.loads((S/'apple/mac-plan.json').read_bytes());source=R/'tools/qwen35_text/main.cc'
code=r'''
from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);out=root/('revision'+str(p['revision']));out.mkdir();src=out/'main.cc';raw=base64.b64decode(p['source_data']);assert hashlib.sha256(raw).hexdigest()==p['source']['sha256'];src.write_bytes(raw)
obj=out/'main.o';command=list(p['plan']['consumer_job']['argv']);command[1:1]=['-I'+str(root/'source/tools/qwen35_text')];command[command.index('-c')+1]=str(src);command[command.index('-o')+1]=str(obj);command[command.index('-MF')+1]=str(obj)+'.d'
link=[str(obj)if x in (p['plan']['consumer_job']['object'],str(root/'revision2/main.o'))else x for x in p['base_link']]
link[link.index('-o')+1]=str(out/'native-append')
records=[]
for action,argv in [('compile',command),('link',link)]:
 record=dict(command=argv,cwd=p['sdk']+'/build',started=time.time(),source=p['source'])
 with(out/(action+'.stdout.log')).open('wb')as so,(out/(action+'.stderr.log')).open('wb')as se:
  child=subprocess.Popen(argv,cwd=p['sdk']+'/build',env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(out/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
 record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(out/(action+'.result.json')).write_text(json.dumps(record,indent=2)+'\n');(out/'live.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 if child.returncode:break
result=dict(records=records,all_exit_zero=len(records)==2 and all(x['exit']==0 for x in records))
if result['all_exit_zero']:
 os.link(root/'mlx.metallib',out/'mlx.metallib');image=out/'native-append';raw=image.read_bytes();result['image']=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());(out/'ready.json').write_text(json.dumps(result,indent=2)+'\n')
else:result['stderr']=(out/(records[-1]['state']+'.stderr.log')).read_text(errors='replace')if False else(out/('compile'if len(records)==1 else'link')+'.stderr.log').read_text(errors='replace')
print(json.dumps(result))
'''
base_link=json.loads((S/'apple/revision3-plan.json').read_bytes())['actions'][-1][1]
result=h.m.ssh(code,dict(remote=h.m.REMOTE,sdk=h.m.SDK,revision=a.revision,plan=plan,base_link=base_link,source=h.m.ident(source),source_data=base64.b64encode(source.read_bytes()).decode()),timeout=180)
h.m.save(S/'apple'/('revision'+str(a.revision)+'.json'),result)
print(json.dumps(dict(all_exit_zero=result['all_exit_zero'],records=[{k:v for k,v in x.items() if k!='command'} for x in result['records']],image=result.get('image'),stderr=result.get('stderr'))))
if not result['all_exit_zero']:raise SystemExit(1)
