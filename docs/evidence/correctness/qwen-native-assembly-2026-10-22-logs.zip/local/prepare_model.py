"""Transfer the one original full shard into the fixed reusable Mac model cache."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys, time
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('aj_model_mac',R/'.scratch/native-paged-capacity-20261022/apple/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
source=Path('C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors')
cache='/Users/kiro/hyle-scratch/compute-unified/models/qwen35-2b'
def sha(path):
 digest=hashlib.sha256()
 with path.open('rb')as stream:
  for block in iter(lambda:stream.read(8*1024*1024),b''):digest.update(block)
 return digest.hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
identity=dict(path=str(source),bytes=source.stat().st_size,sha256=sha(source))
with source.open('rb')as stream:
 header_bytes=int.from_bytes(stream.read(8),'little');header=json.loads(stream.read(header_bytes))
manifest=R/'.scratch/qwen-mtp-window-20261022/inputs/text/weights.tsv'
lines=manifest.read_text(encoding='utf8').splitlines()
assert lines[2]=='4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155'
assert Path(lines[1]).resolve()==source.resolve()and len(lines[3:])==320
for row in lines[3:]:
 words=row.split();name,dtype=words[:2];rank=int(words[2]);shape=list(map(int,words[3:3+rank]));offset,count=map(int,words[3+rank:])
 raw=header[name];assert raw['dtype']==dtype and raw['shape']==shape
 assert offset==8+header_bytes+raw['data_offsets'][0]and count==raw['data_offsets'][1]-raw['data_offsets'][0]
identity['manifest_identity']=lines[2];identity['manifest_tensors_checked']=320
save(S/'model-source.json',identity)
prepare=h.m.ssh(r'''
from pathlib import Path
import json,sys
p=json.load(sys.stdin);root=Path(p['root']);allowed=Path('/Users/kiro/hyle-scratch/compute-unified');assert root.is_relative_to(allowed)and not root.is_symlink()
root.mkdir(parents=True,exist_ok=True);target=root/'model.safetensors';partial=root/'model.safetensors.partial'
assert not partial.exists(),'preserve existing partial transfer for explicit inspection'
print(json.dumps(dict(target=str(target),partial=str(partial),reused=target.exists())))
''',dict(root=cache))
if not prepare['reused']:
 command=['scp','-q',source.name,h.m.HOST+':'+prepare['partial']]
 record=dict(command=command,cwd=str(source.parent),source=identity,started=time.time())
 with(S/'model-copy.stdout.log').open('wb')as so,(S/'model-copy.stderr.log').open('wb')as se:
  child=subprocess.Popen(command,cwd=source.parent,stdout=so,stderr=se);record.update(pid=child.pid,state='running');save(S/'model-copy.json',record);child.wait()
 record.update(exit=child.returncode,state='terminal',finished=time.time());save(S/'model-copy.json',record)
 assert child.returncode==0
result=h.m.ssh(r'''
from pathlib import Path
import hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['root']).resolve();target=root/'model.safetensors';source=target if p['reused']else root/'model.safetensors.partial'
assert source.is_file()and not source.is_symlink()and source.resolve().parent==root
digest=hashlib.sha256()
with source.open('rb')as stream:
 for block in iter(lambda:stream.read(8*1024*1024),b''):digest.update(block)
assert source.stat().st_size==p['source']['bytes']and digest.hexdigest()==p['source']['sha256']
if not p['reused']:
 assert not target.exists();source.rename(target)
print(json.dumps(dict(path=str(target),bytes=target.stat().st_size,sha256=digest.hexdigest(),reused=p['reused'],whole_model_transferred=True)))
''',dict(root=cache,source=identity,reused=prepare['reused']),timeout=180)
save(S/'model-cache.json',result);print(json.dumps(result))
