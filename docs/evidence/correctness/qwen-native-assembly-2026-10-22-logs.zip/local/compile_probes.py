"""Compile the three CUDA diagnostics affected by Backend member access."""
from pathlib import Path
import importlib.util, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; R=S.parents[1]
spec=importlib.util.spec_from_file_location('aj_probe_helpers',S/'build_windows.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
for tag in ['retirement','batch','mtp_session']:
    h.h.RECIPES[tag]=h.main_record
    h.h.SOURCES[tag]=R/('tools/qwen35_text/'+('mtp_session' if tag=='mtp_session' else tag)+'_probe.cc')
    h.h.compile_one(tag,3)
