"""Bounded P15/S4 before/current CUDA check; no speed claims."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, time
S=Path(__file__).resolve().parent
R=S.parents[1]
def save(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf8')
def ident(path):
    raw=path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--current-attempt',type=int,default=2);a=p.parse_args()
suffix='' if a.current_attempt==2 else str(a.current_attempt)
roots=dict(before=R/'.scratch/qwen-cublas-scores-20261022/qwen-link1', current=S/('cuda-link'+str(a.current_attempt)))
inputs=S/'inputs'
inputs.mkdir(exist_ok=True)
for mode,folder in [('plain','text'),('mtp','mtp')]:
    target=inputs/folder
    target.mkdir(exist_ok=True)
    original=R/'.scratch/qwen-mtp-window-20261022/inputs'/folder
    for name in ['weights.tsv','prompt.ids']:
        data=(original/name).read_bytes()
        if name=='prompt.ids':data=('\n'.join(data.decode().split()[:15])+'\n').encode()
        path=target/name
        if path.exists():assert path.read_bytes()==data
        else:path.write_bytes(data)
    for label,root in roots.items():
        out=S/('cuda-'+mode+'-'+label+(suffix if label=='current' else ''))
        if label=='before' and out.exists():
            record=json.loads((out/'result.json').read_bytes())
            assert record['exit']==0 and record['image']==ident(root/'qwen.exe')
            print(json.dumps(dict(mode=mode,label=label,reuse_prior_process=True)),flush=True)
            continue
        out.mkdir()
        image=root/'qwen.exe'
        command=[str(image),'--inputs',str(target),'--steps','4','--capacity','64',
                 '--max-sessions','1','--active-sequences','1','--prefix-cache','off',
                 '--progress','direct','--replay','commands','--mtp','on' if mode=='mtp' else 'off',
                 '--trace',str(out/'trace'),'--trace-level','full']
        env=dict(os.environ, PATH=json.loads((root/'runtime-environment.json').read_bytes())['PATH'])
        record=dict(command=command,cwd=str(R),started=time.time(),image=ident(image))
        with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
            child=subprocess.Popen(command,cwd=R,env=env,stdout=so,stderr=se)
            record.update(pid=child.pid,state='running')
            save(out/'command.json',record)
            save(S/'cuda-live.json',record)
            child.wait(timeout=240)
        record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started'])
        save(out/'result.json',record)
        save(S/'cuda-live.json',record)
        print(json.dumps(dict(mode=mode,label=label,exit=child.returncode,seconds=record['seconds'])),flush=True)
        if child.returncode:
            print((out/'stderr.log').read_text(errors='replace')[-4000:])
            raise SystemExit(1)
    old=S/('cuda-'+mode+'-before')
    new=S/('cuda-'+mode+'-current'+suffix)
    a=json.loads((old/'stdout.log').read_bytes())
    b=json.loads((new/'stdout.log').read_bytes())
    fields=['source_id','score_dtype','score_policy','mtp','generated_ids','actual_graph_calls',
            'actual_target_rows','committed_target_rows','actual_draft_rows','draft_rows','draft_rounds','accepted_drafts']
    if mode=='mtp':fields+=['draft_frontier','draft_lag','rounds']
    checks={key:a[key]==b[key] for key in fields}
    files=[]
    for path in sorted((old/'trace').rglob('*')):
        if not path.is_file() or path.suffix not in ('.bf16','.f32','.bin'):continue
        rel=path.relative_to(old/'trace')
        other=new/'trace'/rel
        first=ident(path)
        second=ident(other)
        files.append(dict(relative=str(rel),before=first,current=second,equal=first['sha256']==second['sha256']))
    result=dict(fields=checks,raw_vectors=files,all_equal=all(checks.values()) and bool(files) and all(x['equal'] for x in files),performance_comparison=False)
    save(S/('cuda-'+mode+'-comparison'+suffix+'.json'),result)
    print(json.dumps(dict(mode=mode,fields=checks,raw_vectors=len(files),all_equal=result['all_equal'])),flush=True)
    if not result['all_equal']:raise SystemExit(1)
