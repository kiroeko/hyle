"""One current consumer TU, original native SDK/objects, no dependency rebuild."""
from pathlib import Path
import argparse, base64, importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('aj_mac_helpers',R/'.scratch/native-paged-effects-20261022/apple/mac.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
AI=R/'.scratch/native-paged-capacity-20261022/apple'
OLD=m.REMOTE
m.REMOTE=m.BASE+'/qwen-native-assembly-20261022';m.HERE=S/'apple';m.HERE.mkdir(exist_ok=True)
def plan():
 base=json.loads((AI/'mac-plan.json').read_bytes())
 original=json.loads((R/'.scratch/native-paged-effects-20261022/apple/mac-plan.json').read_bytes())
 template=next(x for x in original['jobs']if x['source']=='src/graph_route_apple/native_paged_region.cc')['original']
 source='tools/qwen35_text/main.cc';obj=m.REMOTE+'/objects/consumer.o'
 command=m.overlay_command(template,source,obj)
 consumer=dict(tag='consumer',source=source,module='consumer',object=obj,argv=command)
 files=m.include_closure([source],[command]);entries=[]
 for path in files:
  entry=m.ident(path);entry['path']=path.relative_to(R).as_posix();entries.append(entry)
 link=[obj if x==base['consumer_job']['object']else m.REMOTE+'/native-append'if x==base['remote']+'/native-append'else x for x in base['link']]
 inventory=json.loads((S/'mac-inventory.json').read_bytes());pipeline=inventory['file_pipeline']
 objects=[x['cached_object']['path']for x in pipeline['stream_owners']]
 io='/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/lib/libhyle_io_core.a'
 link[link.index(obj)+1:link.index(obj)+1]=[*objects,io]
 p=dict(remote=m.REMOTE,sdk=m.SDK,hardware='Mac16,12',jobs=[],consumer_job=consumer,archives=[],link=link,files=entries,blockers=[],
  base=m.ident(AI/'mac-plan.json'),new_CXX=1,SDK_builds=0,shaders=0,
  extra_original_objects=objects,extra_original_archive=io,cache_review=m.ident(S/'mac-inventory.json'))
 m.save(m.HERE/'mac-plan.json',p);print(json.dumps(dict(CXX=1,overlay_files=len(entries),overlay_bytes=sum(x['bytes']for x in entries))))
def inputs():
 model=json.loads((S/'model-cache.json').read_bytes());assert model['whole_model_transferred']
 files=[]
 for label,folder in [('text','text'),('mtp','mtp')]:
  root=R/'.scratch/qwen-mtp-window-20261022/inputs'/folder
  if not root.is_dir():continue
  lines=(root/'weights.tsv').read_text(encoding='utf8').splitlines();lines[1]=model['path']
  files.append(dict(path=label+'/weights.tsv',data=base64.b64encode(('\n'.join(lines)+'\n').encode()).decode()))
  ids=(root/'prompt.ids').read_text(encoding='utf8').split()
  # A short original prompt is enough for the first complete state journey.
  files.append(dict(path=label+'/prompt.ids',data=base64.b64encode(('\n'.join(ids[:15])+'\n').encode()).decode()))
 result=m.ssh(r'''
from pathlib import Path
import base64,json,sys
p=json.load(sys.stdin);root=Path(p['remote'])/'inputs';root.mkdir()
for item in p['files']:
 path=root/item['path'];assert path.is_relative_to(root);path.parent.mkdir(exist_ok=True);assert not path.exists();path.write_bytes(base64.b64decode(item['data']))
print(json.dumps(dict(files=len(p['files']),root=str(root))))
''',dict(remote=m.REMOTE,files=files));m.save(m.HERE/'input-prepare.json',result);print(json.dumps(result))
def run(mode, attempt, revision):
 code=r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);out=root/(p['mode']+'-run'+str(p['attempt']));out.mkdir()
image=root/('revision'+str(p['revision']))/'native-append'if p['revision']else root/'native-append';raw=image.read_bytes();command=[str(image),'--inputs',str(root/'inputs'/p['inputs']),'--steps','4','--capacity','64','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','commands','--mtp',p['mtp'],'--trace',str(out/'trace'),'--trace-level','full']
record=dict(command=command,cwd=str(root),started=time.time(),image=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
 child=subprocess.Popen(command,cwd=root,env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_LIBRARY_PATH=p['sdk']+'/relocated/sdk/lib'),stdout=so,stderr=se)
 record.update(pid=child.pid,state='running');(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(record=record,stdout=(out/'stdout.log').read_text(errors='replace'),stderr=(out/'stderr.log').read_text(errors='replace'))))
'''
 result=m.ssh(code,dict(remote=m.REMOTE,sdk=m.SDK,mode=mode,attempt=attempt,revision=revision,inputs='text'if mode=='plain'else 'mtp',mtp='off'if mode=='plain'else 'on'),timeout=1800)
 m.save(m.HERE/(mode+'-run'+str(attempt)+'.json'),result)
 print(json.dumps(dict(record=result['record'],stdout=result['stdout'],stderr_tail=result['stderr'][-3500:]),ensure_ascii=False))
 if result['record']['exit']:raise SystemExit(1)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=('plan','prepare','inputs','compile','link','plain','mtp'));p.add_argument('--limit',type=int,default=1);p.add_argument('--job');p.add_argument('--run-attempt',type=int,default=1);p.add_argument('--revision',type=int,default=0);a=p.parse_args()
 if a.action=='plan':plan()
 elif a.action=='prepare':m.prepare(a)
 elif a.action=='inputs':inputs()
 elif a.action in ('plain','mtp'):run(a.action,a.run_attempt,a.revision)
 else:m.build(a)
