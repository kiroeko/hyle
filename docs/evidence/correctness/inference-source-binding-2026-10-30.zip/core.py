"""Exact mechanical namespace migration plus once-bound Source operations."""
from pathlib import Path
import hashlib

W = Path(__file__).resolve().parent
R = W.parents[1]
P = R / 'src/graph/resources.cc'
raw = P.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'a13e62fa1b097cfe7b30eb01d88bbff00ad34fc3449618b1ff1e6d08609dd2dd'
t = raw.decode('utf-8').replace('\r\n', '\n')

def replace(old, new, count=1):
    global t
    assert t.count(old) == count, (old[:100], t.count(old), count)
    t = t.replace(old, new)

replace('#include "hyle/graph/detail/output_source.h"\n#include "hyle/graph/detail/store_source.h"',
        '#include "hyle/graph/source.h"\n#include "hyle/graph/detail/source_binding_access.h"')
begin = t.index('bool same_reader(ProjectedReader a, ProjectedReader b) noexcept {')
end = t.index('bool same_ready_guard(', begin)
t = t[:begin] + t[end:]
begin = t.index('bool same_required_input(const ResourceReadyInput &a, const ResourceReadyInput &b) noexcept {')
end = t.index('} // namespace\n\nResult<StoreProjectionInputs>', begin)
t = t[:begin] + '''Result<InputSource> bound_output_bundle(Invocation &invocation) noexcept {
  const auto *state = InvocationAccess::state(invocation);
  if (!state)
    return std::unexpected(Status::FailedPrecondition("output bundle has no original consumer"));
  HYLE_ASSIGN_OR_RETURN(auto owner, bound_input_source(*state, &output_source_table));
  const auto *bundle = static_cast<const OutputBindingBundle *>(owner.state());
  if (bundle->consumer != state || owner.identity() != bundle->submission.get())
    return std::unexpected(Status::FailedPrecondition("output bundle was not bound to this original consumer"));
  return owner;
}
''' + t[end:]

# Only the public typed owners/operations leave detail. ResourceSource and
# RegionAccess remain actual internal adapters and retain the same helpers.
replace('SubmissionSource::SubmissionSource(SubmissionSource &&other) noexcept',
        '} // namespace detail\n\nusing namespace detail;\n\nSubmissionSource::SubmissionSource(SubmissionSource &&other) noexcept')
replace('Status RegionAccess::visit_pinned(InvocationState *original, NodeId node,',
        'namespace detail {\nStatus RegionAccess::visit_pinned(InvocationState *original, NodeId node,')
replace('OutputSource::OutputSource(OutputSource &&other) noexcept',
        '} // namespace detail\n\nOutputSource::OutputSource(OutputSource &&other) noexcept')
replace('namespace {\nbool source_retains_allocator(const compute::StorageOwner &storage, mem::AllocatorRef selected) noexcept {',
        'namespace detail {\nnamespace {\nbool source_retains_allocator(const compute::StorageOwner &storage, mem::AllocatorRef selected) noexcept {')
replace('} // namespace\nStoreSource::StoreSource(StoreSource &&other) noexcept',
        '} // namespace\n} // namespace detail\n\nStoreSource::StoreSource(StoreSource &&other) noexcept')
replace('} // namespace detail\n\nGraphOutput::GraphOutput(detail::InvocationState *state,',
        '\nGraphOutput::GraphOutput(detail::InvocationState *state,')
replace('Result<OutputBinding> StoreSource::reader_binding(', 'Result<SourceBinding> StoreSource::reader_binding(')
replace('  return OutputBinding{.store = this, .projection = projection, .graph = &graph, .store_ready = ready};',
        '  return SourceBindingAccess::make({.store = this, .projection = projection, .graph = &graph, .store_ready = ready});')
replace('Status bind_outputs(Invocation &invocation, std::span<const OutputBinding> bindings) noexcept {',
'''SourceBinding OutputSource::reader_binding(ValueId input) const noexcept {
  return SourceBindingAccess::make({.input = input, .output = this});
}
Result<SourceBinding> StoreSource::reader_binding(Invocation &invocation, const Graph &graph,
    std::span<const NodeId> readers, std::span<const compute::ReadLease> ready) const noexcept {
  if (!valid()) return std::unexpected(Status::FailedPrecondition("Store reader needs its captured original source"));
  if (readers.size() != 1)
    return std::unexpected(Status::InvalidArgument("Store source needs one original checked Gather reader"));
  auto *state = InvocationAccess::state(invocation);
  if (!state || !state->plan)
    return std::unexpected(Status::FailedPrecondition("Store reader has no original consumer"));
  HYLE_ASSIGN_OR_RETURN(auto capacity, graph.node_input(readers.front(), 0));
  HYLE_ASSIGN_OR_RETURN(auto metadata, graph.node_input(readers.front(), 1));
  const ResourceProjection projection{capacity, metadata, readers.front(), readers,
      compute::detail::kProjectedInputReadExtensionId};
  HYLE_RETURN_IF_ERROR(validate_store_reader(&graph, projection, *state_, *state));
  HYLE_RETURN_IF_ERROR(validate_store_ready(*state_, ready));
  return SourceBindingAccess::make({.store = this, .projection = projection, .graph = &graph, .store_ready = ready});
}
Status bind_sources(Invocation &invocation, std::span<const SourceBinding> bindings) noexcept {''')
replace('  auto *first_token = OutputSourceAccess::state(bindings.front().output);\n  auto *first_store = OutputSourceAccess::state(bindings.front().store);\n  auto *first_resource = OutputSourceAccess::state(bindings.front().resource);',
        '  const auto &first = SourceBindingAccess::get(bindings.front());\n  auto *first_token = OutputSourceAccess::state(first.output);\n  auto *first_store = OutputSourceAccess::state(first.store);\n  auto *first_resource = OutputSourceAccess::state(first.resource);')
replace('for (const auto &binding : bindings) {',
        'for (const auto &descriptor : bindings) {\n    const auto &binding = SourceBindingAccess::get(descriptor);', 2)
# Correct nesting indentation of the original metadata-copy loop.
replace('    for (const auto &descriptor : bindings) {\n    const auto &binding = SourceBindingAccess::get(descriptor);',
        '    for (const auto &descriptor : bindings) {\n      const auto &binding = SourceBindingAccess::get(descriptor);')
replace('Status release_outputs(Invocation &invocation, std::span<const OutputBinding> bindings) noexcept {\n  HYLE_ASSIGN_OR_RETURN(auto *bundle, bound_output_bundle(invocation, bindings));',
        'Status release_sources(Invocation &invocation) noexcept {\n  HYLE_ASSIGN_OR_RETURN(auto owner, bound_output_bundle(invocation));\n  auto *bundle = static_cast<OutputBindingBundle *>(owner.state());')
replace('  HYLE_ASSIGN_OR_RETURN(auto owner, output_input_source(bundle));\n  const auto &episode = *state->resources.get();',
        '  const auto &episode = *state->resources.get();')
replace('Status prepare_outputs(Invocation &invocation, std::span<const OutputBinding> bindings,\n    std::span<const QueueBinding> queues) noexcept {\n  HYLE_ASSIGN_OR_RETURN(auto bundle, bound_output_bundle(invocation, bindings));',
        'Status prepare_sources(Invocation &invocation, std::span<const QueueBinding> queues) noexcept {\n  HYLE_ASSIGN_OR_RETURN(auto owner, bound_output_bundle(invocation));\n  auto *bundle = static_cast<OutputBindingBundle *>(owner.state());')
replace('Result<compute::Completion> submit_outputs(Invocation &invocation,\n    std::span<const OutputBinding> bindings, std::span<const QueueBinding> queues) noexcept {\n  HYLE_ASSIGN_OR_RETURN(auto bundle, bound_output_bundle(invocation, bindings));',
        'Result<compute::Completion> submit_sources(Invocation &invocation,\n    std::span<const QueueBinding> queues) noexcept {\n  HYLE_ASSIGN_OR_RETURN(auto owner, bound_output_bundle(invocation));\n  auto *bundle = static_cast<OutputBindingBundle *>(owner.state());')
assert 'std::span<const OutputBinding>' not in t
P.write_bytes(t.encode('utf-8'))
print('Migrated public typed owners and once-bound Source operations; retained all actual consumer/admission/retirement checks.')
