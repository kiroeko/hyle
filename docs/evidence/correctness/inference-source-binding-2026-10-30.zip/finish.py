"""Small delivery index; keep actual commands and earlier failures in one archive."""
from pathlib import Path
import difflib
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
s = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(s)
s.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare_retention():
    p = read(W / 'plan.json')
    base = read(p['base']['path'])
    replacements = {key(a['path']): c['path'] for a, c in zip(p['retained'], p['candidate_retained'])}
    for item in p['candidate_retained']:
        exact(item)
    consumers = {}
    for name in p['consumers']:
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        consumers[name] = dict(receipt=pin(path), object=receipt['object'])
    base.update(schema='hyle.source-binding.current-link-base.v1', base=p['base'],
        retained=p['candidate_retained'], sdk_engine_dependencies=p['candidate_sdk'],
        current_consumers=consumers, previous_consumer=consumers['cli']['receipt'],
        consumer_source=pin(p['consumers']['cli']['source']), compile=p['consumers']['cli']['compile'])
    base['link'] = [consumers['cli']['object']['path'] if key(arg) == key(p['original_consumer'])
                    else replacements.get(key(arg), arg) for arg in p['original_link']]
    assert len(base['retained']) == 227
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe', '.dll', '.lib', '.exp')
        targets.append(pin(path))
    assert len(targets) == 22, len(targets)
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    print('Retained current227 SDK inputs/10 consumer receipts;22 exact reconstructable files listed for test.ps1.')


def finish():
    a = read(W / 'delivery-analysis.json')
    p = read(W / 'plan.json')
    changed = subprocess.check_output(['git', 'diff', '--name-only', '--', 'include', 'src', 'engine', 'tests', 'cmake'], cwd=R, text=True).splitlines()
    added = ['include/hyle/graph/source.h', 'include/hyle/graph/paged_append_source.h',
             'include/hyle/graph/detail/source_binding_access.h']
    sources = sorted(set(changed + added))
    patch = subprocess.check_output(['git', 'diff', '--', 'include', 'src', 'engine', 'tests', 'cmake'], cwd=R)
    for name in added:
        content = (R / name).read_text(encoding='utf-8').splitlines(keepends=True)
        patch += ('diff --git a/' + name + ' b/' + name + '\nnew file mode 100644\n' +
            ''.join(difflib.unified_diff([], content, fromfile='/dev/null', tofile='b/' + name))).encode('utf-8')
    (W / 'product.diff').write_bytes(patch)
    tests = []
    for name, attempt, count in [('source-tests', 'attempt3', 29), ('kimi', 'attempt1', 7)]:
        path = W / 'runs' / name / attempt / 'report.json'
        report = read(path)
        assert report['status'] == 'PASS' and report['tests'] == count and report['skipped'] == 0
        tests.append(dict(name=name, tests=count, status='PASS', skipped=0, report=pin(path)))
    finite = []
    for name, attempt in [('natural', 'attempt1'), ('ordinary', 'attempt2'), ('relay', 'attempt2')]:
        path = W / 'runs' / name / attempt / 'report.json'
        assert read(path)['status'] == 'PASS'
        finite.append(dict(name=name, report=pin(path), process=pin(path.parent / 'process.json')))
    value = dict(schema='hyle.correctness.source-binding.v1', date='2026-10-30',
        status='PUBLIC_TYPED_ONCE_BOUND_SOURCE_IMPLEMENTED_AND_FINITE_CHECKED', base_commit=p['base_commit'],
        contract=dict(public_headers=added[:2], binding='Typed borrowed SourceBinding values are accepted once by bind_sources; prepare_sources/submit_sources/release_sources retrieve the exact currently attached Invocation-owned bundle.',
            owners='Existing InputSource/OutputBindingBundle, original SubmissionSource, Queue and native retirement remain sole authorities. No new executor, owner, allocation domain or observer.',
            current_attachments='Lookup includes tensor and effect-only sites, rejects conflicting adapter state even with the same producer identity, and never searches stale prepared sources.',
            actual_checks='Current input/effect attachments, selected math, live guards, full physical capture tuple, original producer Status and actual retirement are still checked.',
            descriptor_lifetime='Descriptor spans and public source wrappers can leave scope after successful bind; the same bundle retains source states and copies original required metadata.',
            store_gather='Both imported-Store and standalone checked-Gather readers have typed factories. No engine raw Provider/projection/ready-proof construction.',
            removed_compatibility_headers=['include/hyle/graph/detail/' + x + '_source.h' for x in ('submission', 'output', 'store', 'paged_append')]),
        implementation=dict(sources=[pin(R / x) if (R / x).exists() else dict(path=x, deleted=True) for x in sources],
            diff=pin(W / 'product.diff'), sdk_CXX_compiles=22, unchanged_SDK_objects=205,
            consumer_and_test_TUs=10, NVCC_compiles=0, downloads=0,
            current_link_base=pin(W / 'model-link-base.json'), current_dependency_inventory=p['candidate_sdk']),
        checks=dict(gtests=tests, finite_consumers=finite, independent_offline_analysis=pin(W / 'delivery-analysis.json'),
            core_review=pin(W / 'core-review.json'), mixed_fixture_review=pin(W / 'mixed-fixture-review.json')),
        performance=dict(scope='ABBA four current CLI processes; two samples per version, no profiler, new peer or independent memory window.',
            control_decode_TPS=[read(W / 'runs/control' / x / 'report.json')['decode_output_tokens_per_second'] for x in ('abba-1', 'abba-4')],
            candidate_decode_TPS=[read(W / 'runs/cli' / x / 'report.json')['decode_output_tokens_per_second'] for x in ('abba-2', 'abba-3')],
            approximate_median_change_percent=0.2829118944401632, speedup_established=False,
            comparison='All complete recursive non-time fields equal the prior warm/cold-facts anchor; unchanged64 IDs,34rounds,35ledger,37graphs,226reported target rows and216reported draft rows. The last draft counter excludes discarded work, recorded separately below.'),
        discovered_followup=dict(research=pin(W / 'mtp-discard-research.json'),
            finding='Two rejected-A full-successor assumptions cause two retired/discarded B bodies. They cannot be identified from pre-submit quota/cohort alone.',
            measurement_defect='Published-ledger draft counters omit4 actual discarded draft rows;216/434 reported rows imply220/438 with this work included. These are source-derived totals, not an observed fixed counter.',
            device_condition='CUDA SDK offers native conditional graphs, but current Graph capture and skipped-output/retirement contracts need design and actual hardware proof. No condition mechanism or speedup is delivered here.'),
        earlier_attempts='Preserved in archive: one implicit Kimi initializer compile miss, readback compile/SEH from CUDA-only temporary recipe mismatching the retained CPU+CUDA Backend layout, old Mixed Hybrid expectation, old relay descriptor-count expectation, and reused ordinary fixture directory. Final code/recipe checks pass; do not classify validation setup faults as product GPU failures.',
        cleanup=dict(script=pin(R / 'test.ps1'), manifest=pin(W / 'cleanup-targets.json'), result=read(W / 'cleanup-report.json')),
        limits=['Finite CPU/CUDA/shared-source checks, not exhaustive platforms/models or a whole execution-architecture completion claim.',
            'No new peer/full four-metric window. The progress table remains the06:13-06:18 preceding window; tiny ABBA drift is not a speedup claim.',
            'The Source interface is simplified, but complete multi-model stage assembly, steady preparation and broader device-successor coverage remain unfinished.',
            'No model, library or upstream checkout was downloaded.'],
        evidence_archive='inference-source-binding-2026-10-30.zip')
    out = R / 'docs/evidence/correctness/inference-source-binding-2026-10-30.json'
    save(out, value)
    with zipfile.ZipFile(out.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or any(x in ('bin', '__pycache__', 'ordinary-input') for x in path.relative_to(W).parts):
                continue
            if path.suffix in ('.json', '.py', '.diff', '.log', '.xml'):
                z.write(path, path.relative_to(W).as_posix())
        for name in added:
            z.write(R / name, 'public-source/' + name)
        z.write(R / 'test.ps1', 'cleanup-script.ps1')
        z.write(out, 'delivery.json')
    print('Saved compact index', out.stat().st_size, 'bytes; archive', out.with_suffix('.zip').stat().st_size, 'bytes')


if __name__ == '__main__':
    {'prepare-retention': prepare_retention, 'finish': finish}[sys.argv[1]]()
