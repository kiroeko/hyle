"""Rebuild actual affected cached SDK consumers, not the whole project."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('runner', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key
PREV = R / '.scratch/inference-plan-cold-facts-20261030'


def command_for(obj, source):
    obj = Path(obj)
    candidates = [obj.parent / 'command.json', obj.parents[2] / 'logs' / obj.parent.name / 'command.json',
                  obj.parent.parent / 'logs' / obj.parent.name / 'command.json',
                  *sorted(obj.parent.glob('*/command.json'))]
    for path in candidates:
        if not path.is_file():
            continue
        value = read(path)
        args = value if isinstance(value, list) else value.get('command', [])
        if sum(key(x) == key(source) for x in args) == 1:
            return args, pin(path)
    raise RuntimeError(('Missing exact cached compile command', str(obj), source))


def relocated(args, name, source=None):
    folder = W / 'compile' / name
    folder.mkdir(parents=True, exist_ok=True)
    result = []
    for i, arg in enumerate(args):
        if i and args[i - 1].lower() == '/sourcedependencies':
            arg = str(folder / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(folder / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(folder / 'unit.pdb')
        elif source is not None and arg.lower().endswith('.cc'):
            arg = str(source)
        result.append(arg)
    return result


def prepare():
    base = read(PREV / 'model-link-base.json')
    sdk = read(base['sdk_engine_dependencies']['path'])
    changed = {key(R / x) for x in subprocess.check_output(
        ['git', 'diff', '--name-only', '--', 'include', 'src', 'engine'], cwd=R, text=True).splitlines()}
    retained = {key(x['path']): x for x in base['retained']}
    units = {}
    rows = {key(row['object']): row for row in sdk['inspected']}
    rows.update({key(row['object']): row for row in sdk['engine_consumers'] if 'dependencies' in row})
    actual_rows, unavailable = [], []
    for item in base['retained']:
        adjacent = Path(item['path']).parent / 'dependencies.json'
        row = rows.get(key(item['path']))
        if adjacent.is_file() and 'Data' in read(adjacent):
            row = dict(object=item['path'], dependencies=pin(adjacent))
        if row is None:
            unavailable.append(item['path'])
            continue
        actual_rows.append(row)
        d = read(row['dependencies']['path'])['Data']
        if not any(key(x) in changed for x in [d['Source'], *d['Includes']]):
            continue
        original = retained[key(row['object'])]
        args, recipe = command_for(original['path'], d['Source'])
        name = 'sdk-' + str(Path(d['Source']).relative_to(R)).replace('\\', '__').replace('.', '_')
        units[name] = dict(source=d['Source'], original=original, recipe=recipe,
            compile=relocated(args, name), old_dependencies=row['dependencies'], kind='sdk')
    print('Affected cached CXX units:', len(units), flush=True)
    prior = read(PREV / 'plan.json')
    consumers = {}
    for name, receipt in prior['consumers'].items():
        old = read(receipt['receipt']['path'])
        args, recipe = command_for(old['object']['path'], read(old['dependencies']['path'])['Data']['Source'])
        consumers[name] = dict(source=read(old['dependencies']['path'])['Data']['Source'],
            compile=relocated(args, name), recipe=recipe, kind='consumer')
    # The relay driver includes private Graph facts, so it must be freshly built.
    args = consumers['cli']['compile']
    consumers['relay'] = dict(source=str(R / 'tests/tools/qwen_submission_source_probe.cc'),
        compile=relocated(args, 'relay', R / 'tests/tools/qwen_submission_source_probe.cc'), kind='consumer')
    kimi = read(R / '.scratch/inference-kimi-source-lifecycle-20261030/plan.json')
    consumers['kimi'] = dict(source=kimi['units']['kimi']['source'],
        compile=relocated(kimi['units']['kimi']['compile'], 'kimi'), kind='gtest')
    recipe = read(R / '.scratch/inference-source-spans-20261028/refinement/recipes/output-source-test.json')['command']
    for name, source in [('source-test', 'tests/graph/output_source_cuda_test.cc'),
        ('paged-test', 'tests/graph_batch/paged_append_source_test.cc'),
        ('mixed-test', 'tests/graph_provider_ggml_cuda/mixed_ready_source_test.cc'),
        ('indexed-test', 'tests/graph_provider_ggml_cuda/pending_indexed_state_test.cc'),
        ('readback-test', 'tests/tools/qwen_backend_cpu_cuda_test.cc')]:
        consumers[name] = dict(source=str(R / source), compile=relocated(recipe, name, R / source), kind='gtest')
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    for item in base['retained']:
        exact(item)
    save(W / 'plan.json', dict(base=pin(PREV / 'model-link-base.json'), base_commit='3f892885b',
        units=units, consumers=consumers, retained=base['retained'], runtime=base['runtime'],
        original_link=base['link'], original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        sdk=base['sdk_engine_dependencies'], actual_dependency_rows=actual_rows, unavailable_dependencies=unavailable,
        args=prior['args'], two_turn_args=prior['two_turn_args'],
        cases=prior['cases'], kimi_environment=kimi['environment'], kimi_case=kimi['cases']['kimi-cuda'],
        old_cli=prior['consumers']['cli']['object'], sdk_compiles=len(units), retained_unchanged=227-len(units),
        nvcc_compiles=0, downloads=0))
    print('Prepared affected SDK CXX units and9 current consumer/test TUs; no NVCC or download.', flush=True)


def compile_one(name, attempt):
    p = read(W / 'plan.json')
    unit = (p['units'] | p['consumers'])[name]
    folder = W / 'compile' / name
    b.execute(unit['compile'], folder / attempt, 600)
    d = read(folder / 'dependencies.json')['Data']
    files = sorted({Path(x).resolve() for x in [d['Source'], *d['Includes']] if Path(x).is_relative_to(R)})
    save(folder / 'receipt.json', dict(object=pin(folder / 'unit.obj'),
        source_identities=[pin(x) for x in files], dependencies=pin(folder / 'dependencies.json'),
        process=pin(folder / attempt / 'process.json')))
    print('COMPILED', name, flush=True)


def compile_group(group, attempt):
    p = read(W / 'plan.json')
    names = list(p['units'] if group == 'sdk' else p['consumers'])
    done = []
    for name in names:
        receipt = W / 'compile' / name / 'receipt.json'
        if receipt.is_file():
            value = read(receipt)
            exact(value['object'])
            for item in value['source_identities']:
                exact(item)
            done.append(name)
    names = [name for name in names if name not in done]
    errors = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs = {pool.submit(compile_one, name, attempt): name for name in names}
        for future in as_completed(jobs):
            try:
                future.result()
            except BaseException as error:
                errors.append(dict(unit=jobs[future], error=str(error)))
    save(W / ('compile-' + group + '-' + attempt + '.json'), dict(units=len(names), already_current=done, max_concurrency=2, errors=errors))
    if errors:
        raise RuntimeError(errors)


def seal():
    p = read(W / 'plan.json')
    replacements = {}
    for name, unit in p['units'].items():
        receipt = read(W / 'compile' / name / 'receipt.json')
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        replacements[key(unit['original']['path'])] = receipt['object']
    p['candidate_retained'] = [replacements.get(key(x['path']), x) for x in p['retained']]
    sdk = read(p['sdk']['path'])
    sdk['inspected'] = p['actual_dependency_rows']
    sdk['unavailable'] = p['unavailable_dependencies']
    for row in sdk['inspected']:
        if key(row['object']) in replacements:
            row['object'] = replacements[key(row['object'])]['path']
            row['dependencies'] = pin(Path(row['object']).parent / 'dependencies.json')
    for row in sdk['engine_consumers']:
        if key(row['object']) in replacements:
            row['object'] = replacements[key(row['object'])]['path']
            receipt = Path(row['object']).parent / 'receipt.json'
            facts = read(receipt)
            row['dependencies'] = facts['dependencies']
            row['source_identities'] = facts['source_identities']
            row['engine_dependencies'] = [x['path'] for x in facts['source_identities']
                if Path(x['path']).is_relative_to(R / 'engine')]
            row['original_receipt'] = pin(receipt)
    save(W / 'sdk-engine-dependencies.json', sdk)
    p['candidate_sdk'] = pin(W / 'sdk-engine-dependencies.json')
    save(W / 'plan.json', p)
    print('Sealed current227 SDK/engine inputs.', flush=True)


def link(name, attempt):
    p = read(W / 'plan.json')
    retained = p['retained'] if name == 'control' else p['candidate_retained']
    members = ['source-test', 'paged-test', 'mixed-test', 'indexed-test', 'readback-test'] if name == 'source-tests' else [name]
    objects = [p['old_cli']] if name == 'control' else [read(W / 'compile' / member / 'receipt.json')['object'] for member in members]
    for item in [*retained, *objects]:
        exact(item)
    replacements = {key(a['path']): c['path'] for a, c in zip(p['retained'], retained)}
    args = []
    for arg in p['original_link']:
        if key(arg) == key(p['original_consumer']):
            args.extend(x['path'] for x in objects)
            continue
        arg = replacements.get(key(arg), arg)
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                break
        args.append(arg)
    if name in ('source-tests', 'kimi'):
        args.extend(str(R / '.scratch/build-compute-v2-dev/lib' / x) for x in ('gtest_main.lib', 'gtest.lib'))
    b.execute(args, W / 'link' / name / attempt, 240)
    save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))


def run(name, attempt):
    p = read(W / 'plan.json')
    image = read(W / ('ready-' + name + '.json'))
    exact(image)
    folder = W / 'runs' / name / attempt
    if name in ('source-tests', 'kimi'):
        if name == 'kimi':
            import os
            os.environ.update(p['kimi_environment'])
        filt, count = ('GraphOutputSourceCuda.*:GraphPagedAppendSourceCuda.*:GgmlCudaMixedReadySource.*:GgmlCudaPendingIndexedState.*:QwenBackendCpuCuda.ReadbackI32WriterSupportsTheOriginalSubmissionSource', 29) if name == 'source-tests' else (p['kimi_case']['filter'], 7)
        b.execute([image['path'], '--gtest_color=no', '--gtest_fail_fast', '--gtest_filter=' + filt,
            '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 300)
        xml = ET.parse(folder / 'results.xml').getroot()
        assert int(xml.get('tests')) == count and xml.get('failures') == '0' and xml.get('errors', '0') == '0'
        assert not xml.findall('.//skipped')
        save(folder / 'report.json', dict(status='PASS', tests=count, skipped=0,
            cases=[dict(name=t.get('classname') + '.' + t.get('name'), seconds=t.get('time')) for t in xml.findall('.//testcase')]))
    else:
        args = p['cases'][name] if name in ('natural', 'ordinary') else (
            ['--relay', '--cuda', p['cases']['natural'][-1]] if name == 'relay' else p['args'])
        b.execute([image['path'], *args], folder, 300)
        report = read(folder / 'stdout.log')
        if name in ('natural', 'ordinary', 'relay'):
            assert report['status'] == 'PASS'
        else:
            assert report['generated_tokens'] == 64 and report['draft_rounds'] == 34
        save(folder / 'report.json', report)
    print('PASS', name, attempt, flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare', 'seal'):
        {'prepare': prepare, 'seal': seal}[action]()
    else:
        {'compile': compile_one, 'compile-group': compile_group, 'link': link, 'run': run}[action](*sys.argv[2:])
