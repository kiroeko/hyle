from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
tag=sys.argv[1];assert tag in ['wsl-cuda','air-vulkan','metal']
base=Path('/root/hyle-scratch/compute-unified') if tag=='wsl-cuda' else Path('/Users/kiro/hyle-scratch/compute-unified')
name='g09-metal-timeline-check-1' if tag=='metal' else 'g09-'+tag+'-implementation-check-1'
out=base/name;r=json.loads((out/'result.json').read_text())
assert r['state'] in ['SOURCE_PUBLIC_CONSUMERS_PASS','METAL_REAL_MATH_TIMELINE_AND_ORDINARY_CONSUMERS_PASS','FAIL']
profile={'wsl-cuda':'l-cpu-cuda','air-vulkan':'a-cpu-vulkan','metal':'a-cpu-apple'}[tag]
build=base/profile/'selected-graph/source-build'
targets=[i['target'] for i in r.get('binaries',[])]
ninja='/usr/bin/ninja' if tag=='wsl-cuda' else '/opt/homebrew/bin/ninja'
for target in targets:
    args=[ninja,'-C',str(build),'-t','commands',target]
    (out/('commands-'+target+'.txt')).write_bytes(subprocess.check_output(args))
archive=out/'collected.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,6) as z:
    for p in sorted(out.iterdir()):
        if p.is_file() and p.suffix in ['.json','.log','.txt','.py','.ninja']:
            z.write(p,'run/'+p.name)
    src=Path(r.get('source','/Users/kiro/hyle-scratch/compute-unified/source-c8874688'))
    for relative in ['tests/graph/native_joint_pipeline.cc','tests/graph/cpu_cuda_pipeline.cc','tests/graph/cpu_apple_pipeline_trace.mm',
                     'tests/graph/cpu_apple_contracts/CMakeLists.txt','src/graph/joint_pipeline.h','src/graph/executable.cc',
                     'src/graph_route_cpu_cuda/invocation.cc','src/graph_route_cpu_apple/invocation.cc','src/graph_route_cpu_vulkan/invocation.cc']:
        p=src/relative
        if p.is_file():z.write(p,'source/'+relative)
    for target in targets:
        p=build/target
        expected=next(i['sha256'] for i in r['binaries'] if i['target']==target)
        assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,target
        # Retain exact consumer executables; native leaf libraries remain in
        # the already qualified original delivery profile, bound by receipt.
        z.write(p,'binary/'+target)
assert zipfile.ZipFile(archive).testzip() is None
print(json.dumps({'state':r['state'],'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
if tag=='wsl-cuda':
    local=Path('/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps')/name
    local.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(archive,local/'raw.zip')
    shutil.copyfile(out/'result.json',local/'result.json')
