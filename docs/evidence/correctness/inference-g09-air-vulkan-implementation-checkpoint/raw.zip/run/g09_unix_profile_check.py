from pathlib import Path
import hashlib,json,os,platform,re,subprocess,sys,time,zipfile

tag=sys.argv[1]
reuse='--reuse-unchanged-leaves' in sys.argv
assert tag in ['wsl-cuda','air-vulkan']
base=Path('/root/hyle-scratch/compute-unified') if tag=='wsl-cuda' else Path('/Users/kiro/hyle-scratch/compute-unified')
profile='l-cpu-cuda' if tag=='wsl-cuda' else 'a-cpu-vulkan'
out=base/('g09-'+tag+'-implementation-check-1')
build=base/profile/'selected-graph/source-build';parent=base/profile/'selected-graph/source-parent'
cmake=parent/'CMakeLists.txt';text=cmake.read_text();match=re.search(r'add_subdirectory\("([^"]+)" hyle\)',text)
assert match
source=Path(match[1]);assert source.resolve().is_relative_to(base.resolve())
manifest=json.loads((out/'inputs.json').read_text())
retained=None
if reuse:
    retained=json.loads((out/'result.json').read_text())
    retained['state']='PREFLIGHT_REFUSED_UNNECESSARY_CUDA_REBUILD'
    assert not (out/'result-preflight.json').exists()
    (out/'result-preflight.json').write_text(json.dumps(retained,indent=2)+'\n')
else:assert not (out/'result.json').exists()
os.nice(10)
if tag=='wsl-cuda':os.sched_setaffinity(0,sorted(os.sched_getaffinity(0))[:4])
else:assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
env=dict(os.environ,PATH='/opt/homebrew/bin:'+os.environ.get('PATH',''),OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
if tag=='wsl-cuda':env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:'+env.get('LD_LIBRARY_PATH','')
r={'state':'SETUP','tag':tag,'stages':[],'source':str(source),'canonical_commit':manifest['commit'],'source_archive_sha256':manifest['archive_sha256'],
   'source_files':len(manifest['files']),'max_jobs':2 if tag=='wsl-cuda' else 4,'nice':os.nice(0),'pid':os.getpid(),
   'logical_cpus':sorted(os.sched_getaffinity(0)) if tag=='wsl-cuda' else 'macOS has no supported hard affinity; four build jobs',
   'scope':'G09 exact immutable full canonical build/source snapshot, original incremental source integration and actual public consumers. Not aggregate risk/SDK delivery/P1 acceptance.'}
r['identity']={k:subprocess.check_output(v,text=True,env=env).strip() for k,v in
    ({'system':['uname','-a'],'compiler':['/usr/bin/g++-14','--version'],'gpu':['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader']} if tag=='wsl-cuda' else
     {'model':['sysctl','-n','hw.model'],'chip':['sysctl','-n','machdep.cpu.brand_string'],'system':['sw_vers'],'compiler':['xcrun','clang++','--version']}).items()}
if reuse:
    current=r
    r=retained
    r.update(scope='Partial CXX changed-owner/direct-consumer compile and actual runtime with original qualified unchanged leaf archives. Scratch Ninja reuse projection is not a new complete source/static/shared delivery verdict.',retained_initial_record='result-preflight.json')
started=time.monotonic()-(retained['elapsed_seconds'] if reuse else 0)
def save():
    r['elapsed_seconds']=time.monotonic()-started
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
with zipfile.ZipFile(out/'source.zip') as archive,zipfile.ZipFile(out/'changed-previous-sources.zip','w',zipfile.ZIP_DEFLATED,6) as previous:
    changed=[]
    for item in manifest['files']:
        relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
        path=source/relative;assert path.resolve().is_relative_to(source.resolve())
        data=archive.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        if not path.is_file() or path.read_bytes()!=data:
            if path.is_file():previous.write(path,item['path'])
            changed.append(item['path']);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    r['updated_files']=changed
(out/'original-parent-CMakeLists.txt').write_text(text)
targets=[]
for target,unit in ([('hyle_cpu_cuda_pipeline','cpu_cuda_pipeline.cc'),('hyle_cpu_cuda_contracts','cpu_cuda_contracts.cc')] if tag=='wsl-cuda' else
                   [('hyle_cpu_vulkan_pipeline','native_joint_pipeline.cc'),('hyle_cpu_vulkan_contracts','cpu_vulkan_contracts.cc')]):
    if f'add_executable({target}' in text:
        targets.append(target);continue
    text+=f'\nadd_executable({target} "{source/"tests/graph"/unit}")\n'
    text+=f'target_compile_features({target} PRIVATE cxx_std_23)\ntarget_link_libraries({target} PRIVATE hyle::graph)\nhyle_stage_runtime({target})\n'
    targets.append(target)
if tag=='wsl-cuda':
    if not reuse:text+='find_package(CUDAToolkit REQUIRED)\nif(TARGET CUDA::cupti)\n'
    if not reuse:text+='target_compile_definitions(hyle_cpu_cuda_pipeline PRIVATE HYLE_G09_HAS_CUPTI=1)\n'
    if not reuse:text+='target_link_libraries(hyle_cpu_cuda_pipeline PRIVATE CUDA::cupti)\nendif()\n'
    for name,units,includes in [
        ('hyle_graph_test',['graph_test.cc','lease_submission_test.cc','native_variants_test.cc','effect_preflight_test.cc','joint_pipeline_test.cc'],'src/graph'),
        ('hyle_graph_executable_test',['executable_test.cc','custom_kernel_test.cc','region_provider_test.cc','cuda_graph_test.cc'],'src/compute'),
        ('hyle_graph_native_retirement_test',['aggregate_native_retirement_test.cc'],'src/graph')]:
        if f'add_executable({name}' in text:
            targets.append(name);continue
        text+=f'add_executable({name}\n'+''.join(f'  "{source/"tests/graph"/unit}"\n' for unit in units)+')\n'
        text+=f'target_compile_features({name} PRIVATE cxx_std_23)\ntarget_link_libraries({name} PRIVATE hyle::graph GTest::gtest_main)\n'
        text+=f'target_include_directories({name} PRIVATE "{source/includes}")\nhyle_stage_runtime({name})\n'
        targets.append(name)
targets.append('joint');cmake.write_text(text)
ninja='/usr/bin/ninja' if tag=='wsl-cuda' else '/opt/homebrew/bin/ninja'
def run(stage,args,timeout=1800):
    stage=('reuse-'+stage) if reuse else stage
    stamp=time.monotonic();log=out/(stage+'.log');r.update(state='RUNNING',stage=stage);save();print(stage,flush=True)
    with log.open('wb') as stream:
        process=subprocess.Popen([str(a) for a in args],cwd=source,env=env,stdout=stream,stderr=subprocess.STDOUT)
        r['child_pid']=process.pid;save()
        while True:
            try:code=process.wait(timeout=timeout);break
            except subprocess.TimeoutExpired:
                if stage in ['manifest','build','reuse-manifest','reuse-build'] and process.poll() is None:
                    r.setdefault('time_extensions',[]).append({'stage':stage,'pid':process.pid,'seconds':timeout});save();print('extend',stage,process.pid,flush=True)
                    continue
                process.kill();process.wait();code=124;break
    r.pop('child_pid',None)
    r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp});save()
    if code:
        r['state']='FAIL';save();print(log.read_text(errors='replace')[-15000:],flush=True);raise SystemExit(code)
if not reuse:run('manifest',[ninja,'-C',build,'build.ninja'])
preview=out/('unchanged-leaf-reuse.ninja' if reuse else 'preview.ninja')
if reuse:
    lines=[];borrowed=[]
    keep=('hyle/src/graph/libhyle_graph.a','hyle/src/graph_route_cpu_cuda/libhyle_graph_route_cpu_cuda.a')
    for line in (build/'build.ninja').read_text().splitlines(keepends=True):
        match=re.match(r'^build ([^:]+): (?:CXX|CUDA)_STATIC_LIBRARY_LINKER',line)
        if match and match[1] not in keep:
            path=build/match[1]
            if path.is_file():
                borrowed.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
                line='build '+match[1]+': phony\n'
        lines.append(line)
    preview.write_text(''.join(lines));r['borrowed_archives']=borrowed
else:preview.write_bytes((build/'build.ninja').read_bytes())
dry=subprocess.check_output([ninja,'-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True)
(out/('dry-run-reuse.log' if reuse else 'dry-run.log')).write_text(dry);r['dry_run_edges']=len(dry.splitlines());save()
assert len(dry.splitlines())<100 and 'Re-running CMake' not in dry and 'Building CUDA object' not in dry,dry
run('build',[ninja,'-C',build,'-f',preview,'-j',str(r['max_jobs']),*targets])
for name in targets:
    args=[build/name]
    if name.startswith('hyle_graph'):args.append('--gtest_output=json:'+str(out/(name+'.json')))
    run(name,args,600)
if tag=='wsl-cuda':run('cuda-real-kernel-trace',[build/'hyle_cpu_cuda_pipeline','--trace'],600)
for item in manifest['files']:
    assert hashlib.sha256((source/item['path']).read_bytes()).hexdigest()==item['sha256'],item
for item in r.get('borrowed_archives',[]):
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],item
r['binaries']=[{'target':name,'sha256':hashlib.sha256((build/name).read_bytes()).hexdigest()} for name in targets]
r['state']='SOURCE_PUBLIC_CONSUMERS_PASS';save();print(json.dumps({'tag':tag,'state':r['state'],'seconds':r['elapsed_seconds']}),flush=True)
