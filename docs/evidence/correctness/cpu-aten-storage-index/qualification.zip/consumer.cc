#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/compute/providers/native.h"
#include "hyle/compute/providers/onednn.h"
#include "hyle/graph/cpu.h"
#include <array>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> r) {
  if (!r) {
    std::fprintf(stderr, "%.*s\n", int(r.error().message().size()),
                 r.error().message().data());
    std::exit(2);
  }
  return std::move(*r);
}
void require(hyle::Status s) {
  if (!s.ok()) {
    std::fprintf(stderr, "%.*s\n", int(s.message().size()), s.message().data());
    std::exit(2);
  }
}
using Bytes = std::vector<std::byte>;
m::Buffer buffer(const c::TensorDesc &d) {
  return take(
      m::Buffer::create(m::system_resource(), take(d.required_bytes()), 64));
}
template <class Fill, class Check>
void journey(c::Operation op, std::vector<c::TensorDesc> ds, Fill fill,
             Check check) {
  const auto od = take(c::infer_single_output(op, ds));
  auto ctx = take(c::cpu::create_context());
  auto q = take(ctx.create_queue());
  std::vector<m::Buffer> inputs;
  std::vector<c::ConstTensorView> views;
  for (const auto &d : ds) {
    inputs.push_back(buffer(d));
    views.push_back(take(c::ConstTensorView::create(d, inputs.back().view())));
  }
  auto output = buffer(od);
  const auto dest = take(c::TensorView::create(od, output.view()));
  auto p =
      take(c::prepare(ctx, op, ds, std::span(&od, 1), m::system_resource()));
  const auto mature = [](c::ProviderId id) {
    return id == c::aten_cpu::kProviderId || id == c::ggml_cpu::kProviderId ||
           id == c::onednn::kProviderId;
  };
  const bool needs_aten =
      op.get_if<c::Gather>() || op.get_if<c::Scatter>() || op.get_if<c::Fill>();
  std::printf("Direct op=%d provider=%.*s\n", int(op.kind()),
              int(p.provider().name.size()), p.provider().name.data());
  if (!mature(p.provider().id) ||
      (needs_aten && p.provider().id != c::aten_cpu::kProviderId))
    std::exit(3);
  auto inv = take(p.create_invocation());
  auto builder = take(g::GraphBuilder::create());
  std::vector<g::ValueId> ids;
  for (const auto &d : ds)
    ids.push_back(take(builder.input(d)));
  auto node = take(builder.add_node(op, ids));
  auto value = take(builder.result(node));
  auto y = take(builder.add(c::Copy{}, value));
  require(builder.publish(y));
  auto graph = take(std::move(builder).finish());
  auto gc = take(g::cpu::create_context());
  auto compiled = take(g::compile(graph, gc));
  if (compiled.report.step_count() < 1 ||
      !mature(compiled.report.step(0)->provider.id) ||
      (needs_aten &&
       compiled.report.step(0)->provider.id != c::aten_cpu::kProviderId))
    std::exit(4);
  auto gq = take(gc.create_queue());
  auto lane = take(compiled.executable.create_invocation());
  for (std::size_t i = 0; i < ids.size(); ++i)
    require(lane.bind(ids[i], views[i]));
  require(lane.bind(y, dest));
  const std::array queues{
      g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &gq}};
  require(lane.prepare_replay(queues));
  for (int seed : {1, 7}) {
    fill(inputs, seed);
    auto done = take(inv.submit(q, views, std::span(&dest, 1)));
    require(done.wait());
    check(output, seed);
    auto whole = take(lane.submit(gq));
    require(whole.wait());
    check(output, seed);
  }
  require(ctx.close());
  require(gc.close());
}
c::TensorDesc d(std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(c::DataType::kUInt64,
                                   std::span(shape.begin(), shape.size())));
}
void expect(const m::Buffer &b, const std::vector<std::uint64_t> &v) {
  Bytes actual(b.size());
  require(b.view().read(actual));
  if (actual.size() != v.size() * 8 ||
      std::memcmp(actual.data(), v.data(), actual.size()) != 0)
    std::exit(5);
}
void write(m::Buffer &b, const std::vector<std::uint64_t> &v) {
  require(b.view().write(std::as_bytes(std::span(v))));
}
int main() {
  const auto table = take(c::TensorDesc::strided_bytes(
      c::DataType::kUInt64, std::array<std::int64_t, 2>{3, 2},
      std::array<std::int64_t, 2>{19, 9}));
  const auto index = take(c::TensorDesc::strided_bytes(
      c::DataType::kInt64, std::array<std::int64_t, 2>{1, 3},
      std::array<std::int64_t, 2>{33, 9}));
  const auto fill_table = [&](auto &b, int seed) {
    Bytes bytes(table.required_bytes().value());
    for (std::size_t row = 0; row < 3; ++row)
      for (std::size_t col = 0; col < 2; ++col) {
        auto value =
            std::uint64_t(0xfedcba9876000000ULL + row * 17 + col + seed);
        std::memcpy(bytes.data() + row * 19 + col * 9, &value, 8);
      }
    require(b[0].view().write(bytes));
  };
  const auto fill_ids = [&](auto &b) {
    Bytes bytes(index.required_bytes().value());
    const std::array<std::int64_t, 3> ids{2, 0, 2};
    for (std::size_t i = 0; i < 3; ++i)
      std::memcpy(bytes.data() + i * 9, &ids[i], 8);
    require(b[1].view().write(bytes));
  };
  journey(
      c::Operation(c::Gather{}), {table, index},
      [&](auto &b, int seed) {
        fill_table(b, seed);
        fill_ids(b);
      },
      [](const auto &b, int seed) {
        std::vector<std::uint64_t> v;
        for (int row : {2, 0, 2})
          for (int col : {0, 1})
            v.push_back(0xfedcba9876000000ULL + row * 17 + col + seed);
        expect(b, v);
      });
  journey(
      c::Operation(c::Scatter{}), {table, index, d({1, 3, 2})},
      [&](auto &b, int seed) {
        fill_table(b, seed);
        fill_ids(b);
        write(b[2], {1ULL + seed, 2ULL + seed, 3ULL + seed, 4ULL + seed,
                     5ULL + seed, 6ULL + seed});
      },
      [](const auto &b, int seed) {
        expect(b, {3ULL + seed, 4ULL + seed, 0xfedcba9876000011ULL + seed,
                   0xfedcba9876000012ULL + seed, 5ULL + seed, 6ULL + seed});
      });
  const auto cond = take(c::TensorDesc::dense(
      c::DataType::kBool, std::array<std::int64_t, 2>{1, 2}));
  journey(
      c::Operation(c::Select{}), {cond, table, table},
      [&](auto &b, int seed) {
        require(b[0].view().write(Bytes{std::byte{0}, std::byte{0xff}}));
        Bytes a(table.required_bytes().value()), z(a.size());
        for (std::size_t row = 0; row < 3; ++row)
          for (std::size_t col = 0; col < 2; ++col) {
            auto x = std::uint64_t(seed + row * 2 + col),
                 y = std::uint64_t(100 + seed + row * 2 + col);
            std::memcpy(a.data() + row * 19 + col * 9, &x, 8);
            std::memcpy(z.data() + row * 19 + col * 9, &y, 8);
          }
        require(b[1].view().write(a));
        require(b[2].view().write(z));
      },
      [](const auto &b, int seed) {
        std::vector<std::uint64_t> v;
        for (int row = 0; row < 3; ++row) {
          v.push_back(100 + seed + row * 2);
          v.push_back(seed + row * 2 + 1);
        }
        expect(b, v);
      });
  journey(c::Operation(c::Copy{}), {table}, fill_table,
          [](const auto &b, int seed) {
            std::vector<std::uint64_t> v;
            for (int row = 0; row < 3; ++row)
              for (int col = 0; col < 2; ++col)
                v.push_back(0xfedcba9876000000ULL + row * 17 + col + seed);
            expect(b, v);
          });
  journey(
      c::Operation(c::Concat{.axis = 1}), {table, table},
      [&](auto &b, int seed) {
        fill_table(b, seed);
        Bytes bytes(table.required_bytes().value());
        require(b[0].view().read(bytes));
        require(b[1].view().write(bytes));
      },
      [](const auto &b, int seed) {
        std::vector<std::uint64_t> v;
        for (int row = 0; row < 3; ++row)
          for (int repeat = 0; repeat < 2; ++repeat)
            for (int col = 0; col < 2; ++col)
              v.push_back(0xfedcba9876000000ULL + row * 17 + col + seed);
        expect(b, v);
      });
  journey(
      c::Operation(c::Fill{
          .output_shape =
              take(c::TensorShape::create(std::array<std::int64_t, 2>{3, 2})),
          .output_type = c::DataType::kUInt64,
          .value = c::ScalarValue(std::uint64_t{0xfedcba9876543210ULL})}),
      {}, [](auto &, int) {},
      [](const auto &b, int) {
        expect(b, std::vector<std::uint64_t>(6, 0xfedcba9876543210ULL));
      });
  std::puts("ordinary CPU ATen storage/index Direct and Graph downstream "
            "changed-input replay PASS");
}
