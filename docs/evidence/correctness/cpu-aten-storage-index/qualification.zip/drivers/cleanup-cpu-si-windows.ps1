$ErrorActionPreference = 'Stop'
$cleanupRoot = (Resolve-Path -LiteralPath 'C:\hv').Path
$cleanupEvidence = Join-Path (Get-Location).Path '.scratch\validation\cpu-aten-storage-index\windows\cleanup.json'
$cleanupRows = @()
foreach ($cleanupName in @('cpu-si-shared-consumer', 'cpu-si-static-consumer', 'cpu-si-disabled-stub')) {
    $cleanupTarget = (Resolve-Path -LiteralPath (Join-Path $cleanupRoot $cleanupName)).Path
    if ([IO.Path]::GetDirectoryName($cleanupTarget) -ne $cleanupRoot -or [IO.Path]::GetFileName($cleanupTarget) -ne $cleanupName) { throw 'Cleanup escaped its exact target' }
    if ((Get-Item -LiteralPath $cleanupTarget).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected reparse target' }
    if (-not (Test-Path -LiteralPath (Join-Path $cleanupTarget 'CMakeCache.txt'))) { throw 'Missing own consumer identity' }
    $cleanupFiles = @(Get-ChildItem -LiteralPath $cleanupTarget -Recurse -File)
    $cleanupDlls = @($cleanupFiles | Where-Object { $_.Extension -eq '.dll' } | ForEach-Object { @{name=$_.Name;bytes=$_.Length} })
    $cleanupBytes = ($cleanupFiles | Measure-Object -Property Length -Sum).Sum
    Remove-Item -LiteralPath $cleanupTarget -Recurse -Force
    $cleanupRows += @{path=$cleanupTarget;files=$cleanupFiles.Count;logical_bytes=$cleanupBytes;removed=(-not (Test-Path -LiteralPath $cleanupTarget));adjacent_runtime_dlls=$cleanupDlls}
}
$cleanupRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $cleanupEvidence -Encoding utf8
$cleanupRows | Select-Object path,files,logical_bytes,removed | ConvertTo-Json
