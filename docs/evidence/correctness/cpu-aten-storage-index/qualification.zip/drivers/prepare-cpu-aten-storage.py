import hashlib, json
from pathlib import Path
repo = Path.cwd()
fixture = repo / '.scratch/validation/cpu-aten-storage-index'
fixture.mkdir(parents=True, exist_ok=True)
def changed(path, text):
    data = text.encode('utf-8')
    if not path.exists() or path.read_bytes() != data:
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)
for platform, source in [('windows', str(fixture / 'consumer.cc').replace('\\', '/')),
                         ('linux', '/root/hyle-scratch/active-cpu-z/source/.scratch/validation/cpu-aten-storage-index/consumer.cc')]:
    changed(fixture / (platform + '-overlay.cmake'), '''function(cpu_mature_consumer)
  add_executable(cpu_mature_consumer "'''+source+'''")
  target_compile_features(cpu_mature_consumer PRIVATE cxx_std_23)
  target_link_libraries(cpu_mature_consumer PRIVATE hyle::compute hyle::graph)
  hyle_stage_runtime_dependencies(cpu_mature_consumer)
endfunction()
if(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)
  cmake_language(DEFER CALL cpu_mature_consumer)
endif()
''')
changed(fixture / 'consumer/CMakeLists.txt', '''cmake_minimum_required(VERSION 3.28)
project(cpu_mature_consumer LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
add_executable(cpu_mature_consumer "${CMAKE_CURRENT_LIST_DIR}/../consumer.cc")
target_compile_features(cpu_mature_consumer PRIVATE cxx_std_23)
target_link_libraries(cpu_mature_consumer PRIVATE hyle::compute hyle::graph)
hyle_stage_runtime_dependencies(cpu_mature_consumer)
''')
for platform in ('windows', 'linux'):
    src = (repo / ('.scratch/cpu-lb-' + platform + '.py')).read_text(encoding='utf-8')
    src = src.replace('cpu-ggml-layout-broadcast', 'cpu-aten-storage-index')
    src = src.replace('cpu-lb-', 'cpu-si-')
    src = src.replace("records=json.loads((out/'receipt.json').read_text())", "records=json.loads((out/'receipt.json').read_text(encoding='utf-8'))")
    src = src.replace("'hyle_compute_provider_ggml_tests'", "'hyle_compute_provider_native_tests'")
    src = src.replace('hyle_compute_provider_ggml_test', 'hyle_compute_provider_native_test')
    src = src.replace("'--gtest_output=xml:'+str(out/'provider.xml')", "'--gtest_filter=AtenCpuStorage.*','--gtest_output=xml:'+str(out/'provider.xml')")
    # Retain the unchanged original lowp tests as a separate affected consumer.
    changed(repo / ('.scratch/cpu-si-' + platform + '.py'), src)
changed(repo / '.scratch/refresh-cpu-si-manifest.py', '''import hashlib,json,subprocess
from pathlib import Path
repo=Path.cwd(); fixture=repo/'.scratch/validation/cpu-aten-storage-index'
files=subprocess.check_output(['git','ls-files'],text=True).splitlines()
files=[name for name in files if (name.startswith(('cmake/','include/','src/','tests/','scripts/')) or name in ('CMakeLists.txt','hyle-config.cmake.in')) and (repo/name).is_file()]
files+=['.scratch/validation/cpu-aten-storage-index/'+name for name in ('consumer.cc','windows-overlay.cmake','linux-overlay.cmake','consumer/CMakeLists.txt')]
manifest=dict(candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files})
(fixture/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\\n',encoding='utf-8')
print(dict(candidate=manifest['candidate'],files=len(files)))
''')
