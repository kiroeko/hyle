import hashlib,json,os,subprocess,sys,time
from pathlib import Path
repo=Path('/mnt/c/public/project-hyle/hyle')
fixture=repo/'.scratch/validation/cpu-aten-storage-index'
out=fixture/'linux';out.mkdir(parents=True,exist_ok=True)
manifest=json.loads((fixture/'manifest.json').read_text());candidate=manifest['candidate']
source=Path('/root/hyle-scratch/active-cpu-z/source').resolve()
assert source.is_relative_to(Path('/root/hyle-scratch/active-cpu-z').resolve()) and source.is_dir()
changed=[]
for name,sha in manifest['files'].items():
 data=(repo/name).read_bytes();assert hashlib.sha256(data).hexdigest()==sha,name
 dest=(source/name).resolve();assert dest.is_relative_to(source)
 if not dest.exists() or dest.read_bytes()!=data:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(name)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==sha,name
(out/'source-identity.json').write_text(json.dumps(dict(candidate=candidate,checked=len(manifest['files']),forward_updated=changed),indent=2)+'\n')
os.environ['OMP_NUM_THREADS']='2';os.environ['MKL_NUM_THREADS']='2';os.environ.pop('LD_LIBRARY_PATH',None)
build=source.parent/'build'
records=json.loads((out/'receipt.json').read_text(encoding='utf-8')) if (out/'receipt.json').exists() else []
def run(name,args):
 start=time.monotonic();path=out/(str(len(records)+1)+'-'+name+'.log')
 with path.open('wb') as log:r=subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(name=name,args=list(map(str,args)),candidate=candidate,log=path.name,returncode=r.returncode,seconds=round(time.monotonic()-start,3)))
 (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
 if r.returncode:print(path.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(r.returncode)
if '--delivery-only' not in sys.argv:
 if '--resume-build' not in sys.argv:
  run('configure',['cmake','-S',source,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(fixture/'linux-overlay.cmake')])
 run('batch-build',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests','cpu_mature_consumer','--parallel','2'])
 run('provider-tests',[build/'bin/hyle_compute_provider_native_test','--gtest_output=xml:'+str(out/'provider.xml')])
 run('native-public-header',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error','-R','^hyle_compute_provider_native_header_self_contained_test$','--output-junit',out/'header.xml'])
 for factor,pattern in [('compute_route_cpu','CpuDefaultContext.*'),('graph_route_cpu','CpuDefaultGraph.StableGateBoundaryFeedsMatureMatMulWithinWholeRegion:CpuDefaultGraph.NonModelGraphReplaysAndReclaimsItsOwners:CpuDefaultGraph.SelectedGroupMeansBroadcastWithinOneMatureRegion:CpuDefaultContext.*')]:
  run(factor+'-affected-tests',[build/('bin/hyle_'+factor+'_test'),'--gtest_filter='+pattern,'--gtest_output=xml:'+str(out/(factor+'.xml'))])
 run('static-source-ordinary',[build/'bin/cpu_mature_consumer'])
if '--tests-only' in sys.argv:raise SystemExit(0)
for stage in ('shared','static'):
 prefix=Path('/root/hyle-scratch/cpu-ggml-isa-delivery')/stage
 run(stage+'-producer-configure',['cmake','-S',source,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DHYLE_STATIC='+('ON' if stage=='static' else 'OFF'),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(fixture/'linux-overlay.cmake')])
 run(stage+'-producer-build',['cmake','--build',build,'--parallel','2'])
 run(stage+'-source-ordinary',[build/'bin/cpu_mature_consumer'])
 run(stage+'-install',['cmake','--install',build,'--prefix',prefix])
 consumer=prefix.parent/(stage+'-lb-consumer')
 run(stage+'-consumer-configure',['cmake','-S',fixture/'consumer','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=g++-14','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(stage+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
 run(stage+'-installed-ordinary',[consumer/'cpu_mature_consumer'])
