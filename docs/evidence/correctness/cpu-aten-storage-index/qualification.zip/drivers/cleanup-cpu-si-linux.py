import json, shutil
from pathlib import Path
root=Path('/root/hyle-scratch/cpu-ggml-isa-delivery').resolve(strict=True)
rows=[]
for name in ('shared-lb-consumer','static-lb-consumer'):
    target=(root/name).resolve(strict=True)
    assert target.parent==root and target.name==name
    cache=(target/'CMakeCache.txt').read_text()
    assert 'cpu-aten-storage-index/consumer' in cache
    files=[p for p in target.rglob('*') if p.is_file()]
    rows.append(dict(path=str(target),files=len(files),logical_bytes=sum(p.stat().st_size for p in files)))
    shutil.rmtree(target)
    rows[-1]['removed']=not target.exists()
Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-aten-storage-index/linux/cleanup.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
