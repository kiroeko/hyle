exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out = repo/'.scratch/validation/cpu-aten-storage-index/windows'
records = json.loads((out/'receipt.json').read_text(encoding='utf-8'))
fixture = out.parent
manifest = json.loads((fixture/'manifest.json').read_text(encoding='utf-8'))
candidate = manifest['candidate']
run('native-public-header',['ctest','--test-dir',build,'--output-on-failure','--no-tests=error',
    '-R','^hyle_compute_provider_native_header_self_contained_test$',
    '--output-junit',out/'header.xml'])
stub = Path('C:/hv/cpu-si-disabled-stub')
run('stub-configure',['cmake','-S',fixture/'stub','-B',stub,'-G','Ninja',
    '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH=C:/hv/cpu-ggml-isa-shared-sdk',
    '-DHYLE_PRODUCT_SOURCE='+str(repo),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('stub-build',['cmake','--build',stub,'--parallel','2'])
run('sdk-disabled-adapter-and-assembly',[stub/'cpu_aten_disabled_stub.exe'])
