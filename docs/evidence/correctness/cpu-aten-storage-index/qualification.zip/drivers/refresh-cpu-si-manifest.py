import hashlib,json,subprocess
from pathlib import Path
repo=Path.cwd(); fixture=repo/'.scratch/validation/cpu-aten-storage-index'
files=subprocess.check_output(['git','ls-files'],text=True).splitlines()
files=[name for name in files if (name.startswith(('cmake/','include/','src/','tests/','scripts/')) or name in ('CMakeLists.txt','hyle-config.cmake.in')) and (repo/name).is_file()]
files+=['.scratch/validation/cpu-aten-storage-index/'+name for name in ('consumer.cc','windows-overlay.cmake','linux-overlay.cmake','consumer/CMakeLists.txt')]
manifest=dict(candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in files})
(fixture/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(dict(candidate=manifest['candidate'],files=len(files)))
