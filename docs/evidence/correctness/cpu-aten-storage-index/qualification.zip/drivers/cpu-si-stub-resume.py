exec(open('.scratch/cpu-si-windows-extra.py',encoding='utf-8').read().split("run('native-public-header'")[0])
stub=Path('C:/hv/cpu-si-disabled-stub')
run('stub-build-corrected-consumer',['cmake','--build',stub,'--parallel','2'])
run('sdk-disabled-adapter-and-assembly',[stub/'cpu_aten_disabled_stub.exe'])
