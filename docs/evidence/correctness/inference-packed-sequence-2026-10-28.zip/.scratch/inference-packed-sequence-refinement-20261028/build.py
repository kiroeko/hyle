"""Recompile two tests only; retain the original failed run and its two passes."""
from pathlib import Path
import importlib.util
import re
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-packed-sequence-20261028'
spec = importlib.util.spec_from_file_location('packed_original_build',B/'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read,save,pin,exact,key,t = b.read,b.save,b.pin,b.exact,b.key,b.t
UNITS = {'cpu-test':'tests/compute_route_cpu/sequence_test.cc',
         'cuda-test':'tests/compute_route_cuda/sequence_test.cc'}
HEADERS = ['tests/compute_models/packed_sequence_case.h']
APPEND = ['GraphPagedAppend.ActiveRowsUseOnlyTheInitializedCarrierPrefix',
          'CudaPagedAppend.ActiveRowsUseOnlyTheInitializedCarrierPrefix']


def test_names():
    names = []
    for source in UNITS.values():
        names += [suite+'.'+name for suite,name in re.findall(
            r'\bTEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',(R/source).read_text(encoding='utf-8-sig'))]
    return sorted(names+APPEND)


def cases(path):
    root = ET.parse(path).getroot()
    return {node.attrib['classname']+'.'+node.attrib['name']:
        ('failed' if node.find('failure') is not None else 'skipped' if node.find('skipped') is not None
         else 'passed' if node.attrib.get('result')=='completed' else 'not_completed')
        for node in root.findall('.//testcase')}


def prepare():
    ready = read(B/'ready.json'); rows = read(ready['inputs']['path']); assert len(rows)==236
    original = cases(B/'run/results.xml'); process = read(B/'run/process.json')
    assert process['exit']==1 and not process['timed_out']
    passed = sorted(n for n,s in original.items() if s=='passed')
    assert len(passed)==2 and sum(s=='failed' for s in original.values())==1
    assert sum(s=='skipped' for s in original.values())==12
    names = test_names(); assert len(names)==15 and set(passed)<=set(names)
    selected = sorted(set(names)-set(passed)); assert len(selected)==13
    units = {}
    for name,source in UNITS.items():
        out = W/'compile'/name
        template = B/'recipes'/(name+'.json'); old = t.command(template); args = []
        for i,arg in enumerate(old):
            if i and old[i-1].casefold()=='/sourcedependencies':arg=str(out/'dependencies.json')
            elif arg.casefold().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
            elif arg.casefold().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
            elif arg.casefold().endswith(('.cc','.cpp','.cxx')):arg=str(R/source)
            args.append(arg)
        target = W/'recipes'/(name+'.json')
        save(target,dict(command=args,cwd=str(R),timeout_seconds=300))
        units[name] = dict(source=str(R/source),recipe=pin(target),template=pin(template),
                          old_object=read(B/'compile'/name/'compiled.json')['object'])
    save(W/'plan.json',dict(helper=pin(__file__),base_ready=pin(B/'ready.json'),base=ready,units=units,
        original_xml=pin(B/'run/results.xml'),original_process=pin(B/'run/process.json'),
        original_results=original,retained_passes=passed,expected_all=names,selected=selected,
        filter=':'.join(selected),headers=[str(R/p) for p in HEADERS],
        original_build=pin(B/'build.py'),executor=pin(t.__file__),environment=ready['environment'],
        counts=dict(CXX=2,NVCC=0,link=1,selected_tests=13,retained_prior_passes=2),
        scope='Test-only terminal Invocation correction. Products and initial raw failure remain unchanged; two prior successes are not rerun or claimed on the second image.'))
    print('PREPARED 2 CXX / 1 link / 13 selected tests; no source freeze or execution')


def freeze():
    plan = read(W/'plan.json'); exact(plan['helper']); assert test_names()==plan['expected_all']
    records=[]
    for source in [u['source'] for u in plan['units'].values()]+plan['headers']:
        src=Path(source); target=W/'source'/src.relative_to(R)
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as out:out.write(src.read_bytes())
        records.append(dict(original=pin(src),snapshot=pin(target)))
    save(W/'source-freeze.json',records)
    save(W/'frozen.json',dict(plan=pin(W/'plan.json'),sources=pin(W/'source-freeze.json'),helper=pin(__file__)))
    print('FROZEN test-only refinement')


def validate():
    frozen=read(W/'frozen.json')
    for row in frozen.values():exact(row)
    plan=read(frozen['plan']['path'])
    for field in ('helper','original_build','executor','environment','base_ready','original_xml','original_process'):exact(plan[field])
    for row in read(frozen['sources']['path']):exact(row['original']);exact(row['snapshot'])
    return plan


def compile_one(name):
    plan=validate();unit=plan['units'][name];exact(unit['recipe'])
    out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
    process=t.execute(read(unit['recipe']['path'])['command'],W/'logs'/name,300)
    paths=list(dict.fromkeys(t.dep_paths(out/'dependencies.json')))
    assert any(key(p)==key(unit['source']) for p in paths)
    for path in paths:
        canonical=t.canonical(path)
        assert not (t.project(canonical) and key(path)!=key(canonical)),('stale project overlay',str(path))
    validate();save(out/'actual-dependencies.json',[pin(p) for p in paths])
    save(out/'compiled.json',dict(source=pin(unit['source']),object=pin(out/'unit.obj'),process=process,
        command=pin(W/'logs'/name/'command.json'),dependencies=pin(out/'dependencies.json'),
        actual_dependencies=pin(out/'actual-dependencies.json')))
    print('COMPILE_PASS',name)


def link():
    plan=validate();base=plan['base'];exact(base['inputs']);exact(base['recipe'])
    replacements={key(u['old_object']['path']):read(W/'compile'/n/'compiled.json')['object']
                  for n,u in plan['units'].items()}
    for obj in replacements.values():exact(obj)
    old=read(base['inputs']['path']);assert len(old)==236
    assert all(sum(key(row['path'])==k for row in old)==1 for k in replacements)
    rows=[replacements.get(key(row['path']),row) for row in old];assert len(rows)==236
    image=W/'bin/packed-sequence-test.exe';image.parent.mkdir(parents=True,exist_ok=True);assert not image.exists()
    args=[];seen=set()
    for original in t.command(base['recipe']['path']):
        arg=original
        if key(arg) in replacements:arg=replacements[key(arg)]['path'];seen.add(key(original))
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
            if arg.upper().startswith(prefix):arg=prefix+str(image.with_suffix(suffix));break
        args.append(arg)
    assert seen==set(replacements)
    save(W/'inputs.json',rows);process=t.execute(args,W/'link',240)
    save(W/'ready.json',dict(image=pin(image),inputs=pin(W/'inputs.json'),recipe=pin(W/'link/command.json'),
        process=process,frozen=pin(W/'frozen.json'),filter=plan['filter'],selected=plan['selected']))
    print('LINK_PASS 236; exactly two test objects replaced')


def parse():
    plan=validate();ready=read(W/'ready.json');process=read(W/'run/process.json')
    results=cases(W/'run/results.xml')
    assert sorted(results)==plan['selected'] and set(results.values())=={'passed'},results
    assert process['exit']==0 and not process['timed_out']
    combined={n:'passed_on_original_image' for n in plan['retained_passes']}
    combined.update({n:'passed_on_refined_image' for n in results})
    assert sorted(combined)==plan['expected_all'] and len(combined)==15
    save(W/('summary-'+str(time.time_ns())+'.json'),dict(status='PASS_ACROSS_RECORDED_IMAGES',
        results=combined,selected_count=13,retained_pass_count=2,unique_final_passes=15,
        initial=dict(image=plan['base']['image'],process=read(plan['original_process']['path']),
                     xml=plan['original_xml'],results=plan['original_results']),
        refined=dict(image=ready['image'],process=process,xml=pin(W/'run/results.xml'),results=results),
        original_failure_retained=True,product_recompiled=False,performance_claim=False))
    print('PASS 13 new results + 2 retained prior passes; initial failure is preserved')


def run():
    plan=validate();ready=read(W/'ready.json');exact(ready['image'])
    out=W/'run';assert not out.exists(),'Never rerun a completed or failed process; parse separately'
    t.execute([ready['image']['path'],'--gtest_filter='+plan['filter'],'--gtest_fail_fast',
               '--gtest_output=xml:'+str(out/'results.xml')],out,180)
    parse()


if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='freeze':freeze()
        elif action=='compileOne':compile_one(sys.argv[2])
        elif action=='link':link()
        elif action=='run':run()
        elif action=='parse':parse()
        else:raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+'-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
