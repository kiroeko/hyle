"""One test-TU repair; run only the previous failure and two unrun append tests."""
from pathlib import Path
import importlib.util
import sys
import time
import traceback

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
B=R/'.scratch/inference-packed-sequence-refinement-20261028'
INITIAL=R/'.scratch/inference-packed-sequence-20261028'
spec=importlib.util.spec_from_file_location('previous_test_build',B/'build.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
read,save,pin,exact,key,t=m.read,m.save,m.pin,m.exact,m.key,m.t
m.W=W
SOURCE=R/'tests/compute_route_cuda/sequence_test.cc'


def prepare():
    base=read(B/'ready.json');assert len(read(base['inputs']['path']))==236
    first=m.cases(INITIAL/'run/results.xml');second=m.cases(B/'run/results.xml')
    passes1=sorted(n for n,s in first.items() if s=='passed')
    passes2=sorted(n for n,s in second.items() if s=='passed')
    assert len(passes1)==2 and len(passes2)==10 and not set(passes1)&set(passes2)
    assert sum(s=='failed' for s in second.values())==1 and sum(s=='skipped' for s in second.values())==2
    selected=sorted(n for n,s in second.items() if s in ('failed','skipped'))
    current=m.test_names();assert sorted(passes1+passes2+selected)==current
    template=B/'recipes/cuda-test.json';args=[];old=t.command(template)
    out=W/'compile/cuda-test'
    for i,arg in enumerate(old):
        if i and old[i-1].casefold()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.casefold().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.casefold().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.casefold().endswith(('.cc','.cpp','.cxx')):arg=str(SOURCE)
        args.append(arg)
    target=W/'recipes/cuda-test.json';value=dict(command=args,cwd=str(R),timeout_seconds=300)
    if target.exists():assert read(target)==value, 'Retained preparation recipe differs'
    else:save(target,value)
    save(W/'plan.json',dict(helper=pin(__file__),base_ready=pin(B/'ready.json'),base=base,
        units={'cuda-test':dict(source=str(SOURCE),recipe=pin(W/'recipes/cuda-test.json'),
            template=pin(template),old_object=read(B/'compile/cuda-test/compiled.json')['object'])},
        headers=[],original_xml=pin(B/'run/results.xml'),original_process=pin(B/'run/process.json'),
        initial_ready=pin(INITIAL/'ready.json'),initial_xml=pin(INITIAL/'run/results.xml'),
        initial_process=pin(INITIAL/'run/process.json'),first_results=first,second_results=second,
        retained_first_passes=passes1,retained_second_passes=passes2,selected=selected,
        expected_all=current,filter=':'.join(selected),original_build=pin(m.__file__),
        executor=pin(t.__file__),environment=read(B/'plan.json')['environment'],
        preparation_failure_script=pin(W/'build-prepare1.py'),
        counts=dict(CXX=1,NVCC=0,link=1,tests=3),
        scope='Test-only invalid Result dereference correction. Original poisoned writer contract is retained; original SEH/failure/skip and all successful records remain unchanged.'))
    print('PREPARED one CUDA test CXX / one link / three tests; no products or model')


def freeze():
    plan=read(W/'plan.json');exact(plan['helper']);assert m.test_names()==plan['expected_all']
    target=W/'source'/SOURCE.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as out:out.write(SOURCE.read_bytes())
    save(W/'source-freeze.json',[dict(original=pin(SOURCE),snapshot=pin(target))])
    save(W/'frozen.json',dict(plan=pin(W/'plan.json'),sources=pin(W/'source-freeze.json'),helper=pin(__file__)))
    print('FROZEN unique CUDA test source')


def link():
    plan=m.validate();base=plan['base'];exact(base['inputs']);exact(base['recipe'])
    old=plan['units']['cuda-test']['old_object'];new=read(W/'compile/cuda-test/compiled.json')['object'];exact(new)
    rows=read(base['inputs']['path']);assert len(rows)==236
    assert sum(key(x['path'])==key(old['path']) for x in rows)==1
    rows=[new if key(x['path'])==key(old['path']) else x for x in rows]
    image=W/'bin/packed-sequence-test.exe';image.parent.mkdir(parents=True,exist_ok=True);assert not image.exists()
    args=[];replaced=0
    for original in t.command(base['recipe']['path']):
        arg=original
        if key(arg)==key(old['path']):arg=new['path'];replaced+=1
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
            if arg.upper().startswith(prefix):arg=prefix+str(image.with_suffix(suffix));break
        args.append(arg)
    assert replaced==1
    save(W/'inputs.json',rows);process=t.execute(args,W/'link',240)
    save(W/'ready.json',dict(image=pin(image),inputs=pin(W/'inputs.json'),recipe=pin(W/'link/command.json'),
        process=process,frozen=pin(W/'frozen.json'),filter=plan['filter'],selected=plan['selected']))
    print('LINK_PASS 236; exactly one CUDA test object replaced')


def parse():
    plan=m.validate();ready=read(W/'ready.json');process=read(W/'run/process.json')
    results=m.cases(W/'run/results.xml')
    assert sorted(results)==plan['selected'] and set(results.values())=={'passed'},results
    assert process['exit']==0 and not process['timed_out']
    combined={n:'passed_on_initial_image' for n in plan['retained_first_passes']}
    combined.update({n:'passed_on_refined_image' for n in plan['retained_second_passes']})
    combined.update({n:'passed_on_final_image' for n in results})
    assert sorted(combined)==plan['expected_all'] and len(combined)==15
    for name in ('initial_ready','initial_xml','initial_process'):exact(plan[name])
    save(W/('summary-'+str(time.time_ns())+'.json'),dict(status='PASS_ACROSS_THREE_RECORDED_IMAGES',
        unique_final_passes=15,results=combined,initial=dict(ready=plan['initial_ready'],xml=plan['initial_xml'],
        process=plan['initial_process'],results=plan['first_results']),
        refinement=dict(ready=plan['base_ready'],xml=plan['original_xml'],process=plan['original_process'],
        results=plan['second_results']),final=dict(image=ready['image'],process=process,
        xml=pin(W/'run/results.xml'),results=results),original_failures_preserved=True,
        successful_cases_rerun=False,product_recompiled=False,performance_claim=False))
    print('PASS 2 + 10 + 3 across three images; both original failures preserved')


def run():
    plan=m.validate();ready=read(W/'ready.json');exact(ready['image']);out=W/'run'
    assert not out.exists(),'No process rerun; parser-only recovery uses parse'
    t.execute([ready['image']['path'],'--gtest_filter='+plan['filter'],'--gtest_fail_fast',
        '--gtest_output=xml:'+str(out/'results.xml')],out,180)
    parse()


if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='freeze':freeze()
        elif action=='compileOne':
            assert sys.argv[2]=='cuda-test';m.compile_one('cuda-test')
        elif action=='link':link()
        elif action=='run':run()
        elif action=='parse':parse()
        else:raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+'-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
