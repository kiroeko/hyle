"""One CPU append test compile; keep all three earlier processes unchanged."""
from pathlib import Path
import importlib.util
import sys
import time
import traceback

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
B=R/'.scratch/inference-packed-sequence-final-20261028'
FIRST=R/'.scratch/inference-packed-sequence-20261028'
spec=importlib.util.spec_from_file_location('retained_final_builder',B/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
v=old.m;v.W=W
read,save,pin,exact,key,t=v.read,v.save,v.pin,v.exact,v.key,v.t
SOURCE=R/'tests/graph_batch/paged_append_graph_test.cc'
NAME='append-cpu-test'


def prepare():
    base=read(B/'ready.json');assert len(read(base['inputs']['path']))==236
    prior=[];passed={}
    for directory,expected in ((FIRST,2),(R/'.scratch/inference-packed-sequence-refinement-20261028',10),(B,1)):
        results=v.cases(directory/'run/results.xml');success=[n for n,s in results.items() if s=='passed']
        assert len(success)==expected and not set(success)&set(passed)
        passed.update({n:str(directory.name) for n in success})
        prior.append(dict(ready=pin(directory/'ready.json'),xml=pin(directory/'run/results.xml'),
                          process=pin(directory/'run/process.json'),results=results))
    selected=sorted(n for n,s in prior[-1]['results'].items() if s in ('failed','skipped'))
    assert selected==sorted(v.APPEND) and len(passed)==13
    template=FIRST/'recipes/append-cpu-test.json';args=[];raw=t.command(template);out=W/'compile'/NAME
    for i,arg in enumerate(raw):
        if i and raw[i-1].casefold()=='/sourcedependencies':arg=str(out/'dependencies.json')
        elif arg.casefold().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.casefold().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        elif arg.casefold().endswith(('.cc','.cpp','.cxx')):arg=str(SOURCE)
        args.append(arg)
    save(W/'recipes/append-cpu-test.json',dict(command=args,cwd=str(R),timeout_seconds=300))
    save(W/'plan.json',dict(helper=pin(__file__),base_ready=pin(B/'ready.json'),base=base,
        units={NAME:dict(source=str(SOURCE),recipe=pin(W/'recipes/append-cpu-test.json'),
            template=pin(template),old_object=read(FIRST/'compile/append-cpu-test/compiled.json')['object'])},
        headers=[],original_xml=prior[-1]['xml'],original_process=prior[-1]['process'],prior=prior,
        retained_passes=passed,selected=selected,filter=':'.join(selected),expected_all=sorted([*passed,*selected]),
        original_build=pin(v.__file__),executor=pin(t.__file__),environment=read(B/'plan.json')['environment'],
        counts=dict(CXX=1,NVCC=0,link=1,tests=2),
        scope='Test fixture passes the valid system host resource. No product changes or prior successful-case reruns; all initial failure/skip/source records remain preserved.'))
    print('PREPARED one CPU append test CXX / one link / two remaining tests')


def freeze():
    p=read(W/'plan.json');exact(p['helper']);target=W/'source'/SOURCE.relative_to(R)
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as out:out.write(SOURCE.read_bytes())
    save(W/'source-freeze.json',[dict(original=pin(SOURCE),snapshot=pin(target))])
    save(W/'frozen.json',dict(plan=pin(W/'plan.json'),sources=pin(W/'source-freeze.json'),helper=pin(__file__)))
    print('FROZEN one CPU append test')


def link():
    p=v.validate();base=p['base'];exact(base['inputs']);exact(base['recipe'])
    oldobj=p['units'][NAME]['old_object'];new=read(W/'compile'/NAME/'compiled.json')['object'];exact(new)
    rows=read(base['inputs']['path']);assert len(rows)==236
    assert sum(key(x['path'])==key(oldobj['path']) for x in rows)==1
    rows=[new if key(x['path'])==key(oldobj['path']) else x for x in rows]
    image=W/'bin/packed-sequence-test.exe';image.parent.mkdir(parents=True,exist_ok=True);assert not image.exists()
    args=[];replaced=0
    for original in t.command(base['recipe']['path']):
        arg=original
        if key(arg)==key(oldobj['path']):arg=new['path'];replaced+=1
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
            if arg.upper().startswith(prefix):arg=prefix+str(image.with_suffix(suffix));break
        args.append(arg)
    assert replaced==1
    save(W/'inputs.json',rows);process=t.execute(args,W/'link',240)
    save(W/'ready.json',dict(image=pin(image),inputs=pin(W/'inputs.json'),recipe=pin(W/'link/command.json'),
        process=process,frozen=pin(W/'frozen.json'),environment=p['environment'],filter=p['filter']))
    print('LINK_PASS 236; only CPU append test object replaced')


def parse():
    p=v.validate();ready=read(W/'ready.json');process=read(W/'run/process.json');results=v.cases(W/'run/results.xml')
    assert sorted(results)==p['selected'] and set(results.values())=={'passed'},results
    assert process['exit']==0 and not process['timed_out']
    for run in p['prior']:
        for field in ('ready','xml','process'):exact(run[field])
    combined=dict(p['retained_passes']);combined.update({n:str(W.name) for n in results})
    assert sorted(combined)==p['expected_all'] and len(combined)==15
    save(W/('summary-'+str(time.time_ns())+'.json'),dict(status='PASS_ACROSS_FOUR_RECORDED_IMAGES',
        unique_final_passes=15,results=combined,prior=p['prior'],
        final=dict(image=ready['image'],process=process,xml=pin(W/'run/results.xml'),results=results),
        original_failures_preserved=True,successful_cases_rerun=False,product_recompiled=False,performance_claim=False))
    print('PASS 2 + 10 + 1 + 2; all original failures/skips remain recorded')


def run():
    p=v.validate();ready=read(W/'ready.json');exact(ready['image']);out=W/'run'
    assert not out.exists(),'Do not rerun a process; parse is independent'
    t.execute([ready['image']['path'],'--gtest_filter='+p['filter'],'--gtest_fail_fast',
        '--gtest_output=xml:'+str(out/'results.xml')],out,180)
    parse()


if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='freeze':freeze()
        elif action=='compileOne':
            assert sys.argv[2]==NAME;v.compile_one(NAME)
        elif action=='link':link()
        elif action=='run':run()
        elif action=='parse':parse()
        else:raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+'-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
