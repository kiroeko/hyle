"""Offline only: retain every attempt; combine finite passes across actual images."""
from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-packed-sequence-2026-10-28'
BINARY = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.cubin',
          '.ptx', '.so', '.a', '.gguf', '.safetensors', '.metallib'}
TEXT = {'.py', '.json', '.log', '.xml', '.txt', '.cc', '.cpp', '.cu', '.h',
        '.hpp', '.d', '.patch', '.ps1', '.cmake'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def exact(receipt):
    actual = pin(receipt['path'])
    assert (actual['bytes'], actual['sha256']) == (receipt['bytes'], receipt['sha256']), receipt['path']


def key(path):
    return str(Path(path).resolve()).casefold()


def test_results(path):
    root = ET.parse(path).getroot()
    result = {}
    for node in root.findall('.//testcase'):
        name = node.attrib['classname'] + '.' + node.attrib['name']
        assert name not in result, name
        result[name] = ('failed' if node.find('failure') is not None else
                        'skipped' if node.find('skipped') is not None else
                        'passed' if node.attrib.get('result') == 'completed' else 'not_completed')
    return result


def phase(directory):
    plan = read(directory / 'plan.json')
    ready = read(directory / 'ready.json')
    exact(ready['inputs']); exact(ready['recipe'])
    inputs = read(ready['inputs']['path'])
    assert len(inputs) == 236 and len({key(row['path']) for row in inputs}) == 236
    process = read(directory / 'run/process.json')
    assert not process['timed_out'], directory
    results = test_results(directory / 'run/results.xml')
    counts = {s: sum(v == s for v in results.values()) for s in ('passed', 'failed', 'skipped', 'not_completed')}
    assert counts['not_completed'] == 0
    assert process['exit'] == (0 if counts['failed'] == counts['skipped'] == 0 else 1)
    compiled = []
    for name, unit in plan['units'].items():
        record = read(directory / 'compile' / name / 'compiled.json')
        assert record['process']['exit'] == 0 and not record['process']['timed_out']
        compiled.append(dict(name=name, kind=unit.get('kind', 'CXX'), source=record['source'],
                             object=record['object'], process=record['process']))
    assert ready['process']['exit'] == 0 and not ready['process']['timed_out']
    return dict(directory=directory, plan=plan, ready=ready, inputs=inputs,
                process=process, results=results, counts=counts, compiled=compiled)


def main():
    # Only these small local attempt directories are discovered. No global
    # scratch/SDK/model traversal and no old-image/binary rehash is performed.
    directories = {p.resolve() for p in R.joinpath('.scratch').glob('inference-packed-sequence*-20261028')
                   if (p / 'ready.json').is_file() and (p / 'run/results.xml').is_file()}
    directories.update(Path(arg).resolve() for arg in sys.argv[1:])
    phases = sorted((phase(p) for p in directories), key=lambda p: p['process']['started'])
    assert len(phases) >= 3 and phases[0]['directory'] == W
    assert phases[0]['counts'] == dict(passed=2, failed=1, skipped=12, not_completed=0)
    assert phases[1]['counts'] == dict(passed=10, failed=1, skipped=2, not_completed=0)
    assert phases[-1]['process']['exit'] == 0, 'Wait for the last finite append check; do not hide a failure'
    expected = set(phases[-1]['plan'].get('expected_all', read(W / 'frozen.json')['expected_tests']))
    assert len(expected) == 15
    attribution = {}
    for p in phases:
        for name, state in p['results'].items():
            if state == 'passed':
                assert name not in attribution, ('successful case rerun', name)
                attribution[name] = dict(phase=p['directory'].name,
                                         image_sha256=p['ready']['image']['sha256'],
                                         pid=p['process']['pid'])
    assert set(attribution) == expected, dict(missing=sorted(expected-set(attribution)), extra=sorted(set(attribution)-expected))
    summaries = sorted(phases[-1]['directory'].glob('summary-*.json'))
    assert summaries, 'Wait for the final append-fix combined summary'
    final_summary = read(summaries[-1])
    assert final_summary['status'] == 'PASS_ACROSS_FOUR_RECORDED_IMAGES'
    assert final_summary['unique_final_passes'] == 15 and set(final_summary['results']) == expected
    assert len(phases) == 4 and [p['counts']['passed'] for p in phases] == [2, 10, 1, 2]

    # Refinements change only test objects. Keep the original product authority
    # and actual dependency receipts, rather than qualifying an old SDK anew.
    products = [u for u in phases[0]['compiled'] if '/src/' in u['source']['path'].replace('\\', '/').casefold()]
    assert len(products) == 7
    for p in phases[1:]:
        assert all('/tests/' in u['source']['path'].replace('\\', '/').casefold() for u in p['compiled'])
        by_path = {key(row['path']): row for row in p['inputs']}
        for u in products:
            assert by_path[key(u['object']['path'])] == u['object'], ('product replacement during test-only correction', u['name'])
    latest = {}
    for p in phases:
        for row in read(p['directory'] / 'source-freeze.json'):
            exact(row['snapshot'])
            latest[key(row['original']['path'])] = row
    for row in latest.values():
        exact(row['original'])

    files = {}
    def add(path):
        path = Path(path)
        assert path.is_file()
        if path.suffix.casefold() in BINARY or path.suffix.casefold() not in TEXT:
            return
        assert 'source-index' not in path.name.casefold()
        name = path.resolve().relative_to(R).as_posix()
        files[name] = path

    for p in phases:
        directory = p['directory']
        for path in directory.iterdir():
            if path.is_file() and path.name not in {'package-result.json', 'package-manifest.json'}:
                add(path)
        for child in ('source', 'recipes', 'logs', 'run', 'compile', 'link'):
            if (directory / child).is_dir():
                for path in (directory / child).rglob('*'):
                    if path.is_file(): add(path)
    add(__file__)
    # Small original closure/environment/executor receipts, not their payloads.
    first = phases[0]['plan']
    for receipt in (first['base_ready'], first['base']['inputs'], first['base']['recipe'],
                    first['environment'], first['retained_executor']):
        exact(receipt); add(receipt['path'])
    coverage = dict(status='PASS_ACROSS_RECORDED_IMAGES_WITH_FAILURES_PRESERVED',
                    expected=sorted(expected), successful_attribution=attribution,
                    attempts=[dict(directory=str(p['directory']), image=p['ready']['image'],
                                   process=p['process'], results=p['results'], counts=p['counts']) for p in phases])
    coverage_path = W / 'package-coverage.json'
    coverage_path.write_text(json.dumps(coverage, indent=2)+'\n', encoding='utf-8'); add(coverage_path)
    manifest = []
    for name, path in sorted(files.items()):
        receipt = pin(path)
        manifest.append(dict(member=name, bytes=receipt['bytes'], sha256=receipt['sha256']))
    manifest_bytes = (json.dumps(dict(files=manifest, payload_count=len(manifest)), indent=2)+'\n').encode()
    DEST.parent.mkdir(parents=True, exist_ok=True)
    archive = DEST.with_suffix('.zip')
    assert not archive.exists() and not DEST.with_suffix('.json').exists(), 'Preserve any existing archive'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out:
        for name, path in sorted(files.items()): out.write(path, name)
        out.writestr('manifest.json', manifest_bytes)
    with zipfile.ZipFile(archive) as source:
        assert source.testzip() is None and len(source.namelist()) == len(manifest)+1
        for row in manifest:
            data = source.read(row['member'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    counts = dict(CXX=sum(u['kind']=='CXX' for p in phases for u in p['compiled']),
                  NVCC=sum(u['kind']=='NVCC' for p in phases for u in p['compiled']),
                  links=len(phases), component_processes=len(phases), model_processes=0,
                  SDK_builds=0, downloads=0)
    # Keep the human summary compact; per-case mappings and full closure lists
    # are in the ZIP, with every original stdout/stderr/XML and failed attempt.
    report = dict(schema='hyle.correctness.v1', date='2026-10-28',
        status=coverage['status'], scope='Finite public packed GDN/causal-conv and active-prefix PagedAppend on Windows CPU/CUDA',
        outcome=dict(successful_unique_cases=15, across_distinct_actual_images=True,
                     single_image_all_fifteen=False, exact_attribution_member=coverage_path.relative_to(R).as_posix()),
        builds=dict(actual=counts, initial=dict(CXX=10,NVCC=1,link=1), product_TUs=7,
                    test_only_followup_TUs=sum(len(p['compiled']) for p in phases[1:]),
                    product_changes_during_test_corrections=0, inputs=dict(baseline=229, actual_each_image=236)),
        final_combined_summary=pin(summaries[-1]),
        attempts=[dict(name=p['directory'].name, image_sha256=p['ready']['image']['sha256'],
                       pid=p['process']['pid'], exit=p['process']['exit'], counts=p['counts']) for p in phases],
        corrections=[
            'Initial CPU snapshot fixture incorrectly reused a terminal failed OperationInvocation; recreate from the same prepared operation after actual retirement.',
            'Refinement Graph fixtures retain terminal failure and recreate Invocation; Conv Graph test then unsafely dereferenced failed writer.view() Result (SEH 0xc0000005).',
            'Conv test borrows exactly 8B before submission, reads only after true retirement with original writer retained, checks failed view/publish keep original Status, then allocates fresh writers/refills and uses a new Invocation.',
            'A subsequent CPU append fixture passed invalid empty host_workspace; the one-line wrapper correction uses system_resource. Original failure and skipped CUDA case are retained.'
        ],
        helper_failures='Pure preparation metadata KeyError/failure logs are retained separately; they are not compiler, product or model failures.',
        verified=[
            'Public fixed physical carriers with real I32 packed offsets; finite F32/F16/BF16 GDN and convolution CPU/CUDA reference checks, empty sequences, zero physical rows, exact histories/snapshots and initialized padding.',
            'CUDA captured offset updates reuse the original native route; invalid whole offsets prevent either math output and guarded external Store writes; post-failure recovery uses fresh execution/writer authority.',
            'PagedAppend C16/R8 with A1/A3/A8 and B2 actual A4: full row encoding, active source bounds/sum, genuine COW/new-row bytes, padding and original snapshot preservation; CUDA uses real capture.'
        ],
        source_identity=dict(final_product_snapshots=[dict(path=str(Path(u['source']['path']).relative_to(R)),sha256=u['source']['sha256']) for u in products],
                             all_snapshots_and_actual_dependencies='ZIP source-freeze.json and compile/*/{compiled,actual-dependencies,dependencies}.json/.d; no SDK payload copy'),
        limits=['Apple/Vulkan configure changes are included as source only: not compiled or device-run.',
                'No engine varlen wiring, full-model inference, MTP consumer, throughput claim, cross-platform proof, native fault or unknown-retirement injection.',
                'Finite operator/dtype/geometry coverage only; no claim that every Graph route supports every floating type or arbitrary packed encoding.'],
        archive=dict(**pin(archive), payload_files=len(manifest), zip_members=len(manifest)+1,
                     readback='Every archived member CRC, byte count and SHA256 verified',
                     exclusions='EXE/OBJ/PDB/DLL/LIB/EXP, models, SDK trees and large source indexes'))
    target = DEST.with_suffix('.json')
    target.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    result = dict(evidence=pin(target), archive=pin(archive), payload_files=len(manifest),
                  successful_unique_cases=15, actual=counts)
    (W/'package-result.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__': main()
