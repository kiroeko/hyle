"""Explicit, finite packed-sequence/active-append component builds.

prepare writes recipes only; freeze records the small changed source set. No
action implicitly compiles, links, runs, downloads or copies a dependency SDK.
"""
from pathlib import Path
import importlib.util
import json
import re
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('retained_build', R/'.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
read, save, pin, exact, key = t.read, t.save, t.pin, t.exact, t.key
BASE = R/'.scratch/inference-slot-cohort-refinement-20261028/ready-test.json'
FILTER = ('ComputeSequenceSchema.*:CpuPackedSequence.*:CudaPackedSequence.*:'
          'GraphPagedAppend.ActiveRowsUseOnlyTheInitializedCarrierPrefix:'
          'CudaPagedAppend.ActiveRowsUseOnlyTheInitializedCarrierPrefix')
NATIVE = '.scratch/inference-cpu-storage-gather-20261027/compile/native_provider/command.json'
CUDA = '.scratch/inference-native-capture-bindings-20261027/recipes/registration.json'
TEST = '.scratch/inference-slot-cohort-refinement-20261028/recipes/test.json'
# name: (canonical source, retained compiler recipe, replaced object or None)
UNITS = {
 'native-provider': ('src/compute_provider_native/native_provider.cc', NATIVE,
     '.scratch/inference-cpu-storage-gather-20261027/compile/native_provider/unit.obj'),
 'native-sequence': ('src/compute_provider_native/sequence.cc', NATIVE, None),
 'cuda-provider': ('src/compute_provider_cuda/cuda_provider.cc', CUDA,
     '.scratch/inference-native-capture-bindings-20261027/compile/registration/unit.obj'),
 'cuda-sequence': ('src/compute_provider_cuda/sequence_provider.cc', CUDA, None),
 'cuda-status': ('src/compute_backend_cuda/cuda_device_status.cc',
     '.scratch/inference-indexed-store-20261028/recipes/cuda-status.json',
     '.scratch/inference-indexed-store-20261028/compile/cuda-status/unit.obj'),
 'sequence-kernel': ('src/compute_provider_cuda/sequence_kernel.cu',
     '.scratch/inference-indexed-store-20261028/recipes/indexed-kernel.json', None),
 'append': ('src/graph_batch/paged_append.cc',
     '.scratch/inference-successor-kv-20261027/logs/append/command.json',
     '.scratch/inference-successor-kv-20261027/compile/append/unit.obj'),
 'cpu-test': ('tests/compute_route_cpu/sequence_test.cc', TEST, None),
 'cuda-test': ('tests/compute_route_cuda/sequence_test.cc', TEST, None),
 'append-cpu-test': ('tests/graph_batch/paged_append_graph_test.cc',
     '.scratch/inference-continuous-wave-20261027/recipes/paged.json', None),
 'append-cuda-test': ('tests/graph_batch/paged_append_cuda_consumer.cc',
     '.scratch/paged-append-20261021/cuda-check1/compile.command.json', None),
}
HEADERS = ('include/hyle/compute/sequence_ops.h',
           'src/compute_provider_native/native_plan.h',
           'src/compute_provider_cuda/sequence_provider.h',
           'src/compute_provider_cuda/sequence_kernel.h',
           'src/compute_backend_cuda/device_status_kernel.h',
           'tests/compute_models/packed_sequence_case.h',
           'tests/graph_batch/paged_append_active_rows_case.h')
RELATED_UNCOMPILED = ('src/graph_route_apple/native_paged_append_region.cc',
                      'src/graph_route_vulkan/native_paged_append.cc')


def canonical_include(arg):
    for prefix in ('/external:I', '/I', '-I'):
        if arg.casefold().startswith(prefix.casefold()):
            path = Path(arg[len(prefix):])
            if path.is_relative_to(R/'.scratch'):
                parts = path.parts
                for i, part in reversed(list(enumerate(parts))):
                    if part not in ('include', 'src', 'engine', 'tests'): continue
                    candidate = R.joinpath(*parts[i:])
                    if not candidate.is_dir(): continue
                    # A project overlay, not a third-party SDK's include root.
                    if part == 'include' and not (path/'hyle').is_dir(): continue
                    if not any(p == 'source' or p.startswith('source-') or p == 'native-source'
                               for p in parts[:i]): continue
                    return prefix + str(candidate)
    return arg


def recipe(name, source, template):
    old = t.command(template); out = W/'compile'/name
    nvcc = source.suffix == '.cu'
    prefix = '-I' if nvcc else '/I'
    includes = [R/'include', R, source.parent, R/'src/compute',
                R/'src/compute_backend_cuda', R/'src/compute_provider_cuda']
    args = [old[0], *(prefix+str(p) for p in includes)]
    replaced = False
    for index, original in enumerate(old[1:], 1):
        arg = original
        previous = old[index-1].casefold()
        if 'HYLE_APPEND_STANDALONE' in arg: continue
        if previous in ('/sourcedependencies', '-mf'):
            arg = str(out/('dependencies.d' if nvcc else 'dependencies.json'))
        elif previous in ('-o', '-mt'):
            arg = str(out/'unit.obj')
        elif arg.casefold().startswith('/fo'):
            arg = '/Fo'+str(out/'unit.obj')
        elif arg.casefold().startswith('/fd'):
            arg = '/Fd'+str(out/'unit.pdb')
        elif arg.casefold().startswith('-xcompiler=/fd'):
            arg = '-Xcompiler=/Fd'+str(out/'unit.pdb')+',/FS'
        elif arg.casefold().endswith(('.cc', '.cpp', '.cxx', '.cu')):
            arg = str(source); replaced = True
        else:
            arg = canonical_include(arg)
        args.append(arg)
    assert replaced, name
    if not nvcc and '/sourcedependencies' not in [a.casefold() for a in args]:
        args += ['/sourceDependencies', str(out/'dependencies.json')]
    return dict(command=args, cwd=str(R), timeout_seconds=300)


def prepare():
    base = read(BASE); rows = read(base['inputs']['path'])
    assert len(rows) == 229
    objects = {key(row['path']):row for row in rows}
    units = {}
    for name, (source, template, old_object) in UNITS.items():
        src, original = R/source, R/template
        assert src.is_file() and original.is_file(), (name, src, original)
        old = objects[key(R/old_object)] if old_object else None
        target = W/'recipes'/(name+'.json')
        save(target, recipe(name, src, original))
        units[name] = dict(source=str(src), template=pin(original), recipe=pin(target),
                           old_object=old, kind='NVCC' if src.suffix=='.cu' else 'CXX')
    save(W/'plan.json', dict(status='PREPARED_NOT_FROZEN_NOT_BUILT',
        base_ready=pin(BASE), base=base, units=units, headers=[str(R/p) for p in HEADERS],
        related_uncompiled=[str(R/p) for p in RELATED_UNCOMPILED],
        helper=pin(__file__), retained_executor=pin(t.__file__),
        environment=pin(t.W/'environment.json'), filter=FILTER,
        expected_inputs=236, counts=dict(CXX=10, NVCC=1, links=1, model=0, SDK_builds=0),
        policy='Canonical sources; original compiler flags/SM89; only actual compiler dependencies are recorded. No SDK copy, Model build, timing or download.'))
    print('PREPARED 10 CXX + 1 NVCC + 1 link; sources remain unfrozen')


def freeze():
    plan = read(W/'plan.json'); exact(plan['helper'])
    paths = list(dict.fromkeys([u['source'] for u in plan['units'].values()]+
                              plan['headers']+plan['related_uncompiled']))
    records = []
    for name in paths:
        src = Path(name); out = W/'source'/src.relative_to(R)
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open('xb') as stream: stream.write(src.read_bytes())
        records.append(dict(original=pin(src), snapshot=pin(out)))
    save(W/'source-freeze.json', records)
    tests = []
    for name in ('cpu-test', 'cuda-test'):
        text = Path(plan['units'][name]['source']).read_text(encoding='utf-8-sig')
        tests += [suite+'.'+case for suite,case in
                  re.findall(r'\bTEST\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)', text)]
    tests += ['GraphPagedAppend.ActiveRowsUseOnlyTheInitializedCarrierPrefix',
              'CudaPagedAppend.ActiveRowsUseOnlyTheInitializedCarrierPrefix']
    assert len(tests)==len(set(tests)) and tests
    save(W/'frozen.json', dict(plan=pin(W/'plan.json'), sources=pin(W/'source-freeze.json'),
        helper=pin(__file__), source_mode='canonical', expected_tests=sorted(tests),
        uncompiled_related_sources=plan['related_uncompiled']))
    print('FROZEN small changed source set; no compiler invoked')


def validate():
    frozen = read(W/'frozen.json')
    for item in frozen.values():
        if isinstance(item, dict) and 'sha256' in item: exact(item)
    plan = read(frozen['plan']['path'])
    exact(plan['helper']); exact(plan['retained_executor']); exact(plan['environment'])
    for row in read(frozen['sources']['path']): exact(row['original']); exact(row['snapshot'])
    return plan


def compile_one(name):
    plan = validate(); unit = plan['units'][name]; exact(unit['recipe'])
    out = W/'compile'/name; out.mkdir(parents=True, exist_ok=False)
    process = t.execute(read(unit['recipe']['path'])['command'], W/'logs'/name, 300)
    deps = out/('dependencies.d' if unit['kind']=='NVCC' else 'dependencies.json')
    observed = list(dict.fromkeys(t.dep_paths(deps)))
    assert any(key(p)==key(unit['source']) for p in observed), unit['source']
    for path in observed:
        canonical = t.canonical(path)
        assert not (t.project(canonical) and key(path)!=key(canonical)), ('stale project overlay', str(path))
    validate()
    save(out/'actual-dependencies.json', [pin(p) for p in observed])
    save(out/'compiled.json', dict(source=pin(unit['source']), object=pin(out/'unit.obj'),
        process=process, dependencies=pin(deps), actual_dependencies=pin(out/'actual-dependencies.json'),
        command=pin(W/'logs'/name/'command.json')))
    print('COMPILE_PASS', name)


def link():
    plan = validate(); base = plan['base']; exact(base['inputs']); exact(base['recipe'])
    rows = read(base['inputs']['path']); replacements = {}; additions = []
    for name, unit in plan['units'].items():
        obj = read(W/'compile'/name/'compiled.json')['object']; exact(obj)
        if unit['old_object']: replacements[key(unit['old_object']['path'])] = obj
        else: additions.append(obj)
    assert len(replacements)==4 and len(additions)==7
    assert all(sum(key(row['path'])==old for row in rows)==1 for old in replacements)
    rows = [replacements.get(key(row['path']),row) for row in rows]+additions
    assert len(rows)==plan['expected_inputs'] and len({key(x['path']) for x in rows})==len(rows)
    image = W/'bin/packed-sequence-test.exe'; image.parent.mkdir(parents=True,exist_ok=True)
    assert not image.exists()
    args = []; seen = set()
    for old in t.command(base['recipe']['path']):
        arg = old
        if key(old) in replacements: arg = replacements[key(old)]['path']; seen.add(key(old))
        for option,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
            if arg.upper().startswith(option): arg = option+str(image.with_suffix(suffix)); break
        args.append(arg)
    assert seen==set(replacements)
    args += [x['path'] for x in additions]
    save(W/'inputs.json',rows)
    process = t.execute(args,W/'link',240)
    save(W/'ready.json',dict(image=pin(image),inputs=pin(W/'inputs.json'),recipe=pin(W/'link/command.json'),
        process=process,frozen=pin(W/'frozen.json'),environment=plan['environment'],filter=plan['filter']))
    print('LINK_PASS',len(rows))


def parse():
    ready = read(W/'ready.json'); run = W/'run'; process = read(run/'process.json')
    root = ET.parse(run/'results.xml').getroot()
    counts = dict(tests=int(root.attrib['tests']),failures=int(root.attrib['failures']),
                  errors=int(root.attrib.get('errors',0)),skipped=len(root.findall('.//testcase/skipped')))
    observed = [node.attrib['classname']+'.'+node.attrib['name'] for node in root.findall('.//testcase')]
    expected = read(W/'frozen.json')['expected_tests']
    assert sorted(observed)==expected, dict(expected=expected,actual=sorted(observed))
    assert process['exit']==0 and not process['timed_out'] and counts['tests']>0
    assert counts['failures']==counts['errors']==counts['skipped']==0, counts
    save(W/('summary-'+str(time.time_ns())+'.json'),dict(status='PASS',counts=counts,
        process=process,image=ready['image'],filter=ready['filter'],tests=observed,xml=pin(run/'results.xml'),
        scope='Finite CPU/CUDA packed operators and initialized-prefix append; no Model, timing or other-platform execution.'))
    print('TEST_PASS',counts)


def run():
    validate(); ready = read(W/'ready.json'); exact(ready['image'])
    out = W/'run'; assert not out.exists(), 'Preserve original process; parse-only recovery never reruns it'
    t.execute([ready['image']['path'],'--gtest_filter='+ready['filter'],'--gtest_fail_fast',
               '--gtest_output=xml:'+str(out/'results.xml')],out,180)
    parse()


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action=='prepare': prepare()
        elif action=='freeze': freeze()
        elif action=='compileOne': compile_one(sys.argv[2])
        elif action=='link': link()
        elif action=='run': run()
        elif action=='parse': parse()
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+'-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
