from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('process', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def prepare():
    base_path = R / '.scratch/inference-append-tail-return-20261029/model-link-base.json'
    base = read(base_path)
    assert len(base['retained']) == 227
    for item in base['retained']:
        exact(item)
    exact(base['runtime'])
    exact(base['sdk_engine_dependencies'])
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']:
            exact(item)
    old_source = Path(base['consumer_source']['path'])
    old_object = read(base['previous_consumer']['path'])['object']['path']
    units = {}
    for name, file, definitions in [
        ('ds', 'dspark_pro_mtp_state_consumer_test.cc', ['/DHYLE_TEST_DSPARK_STATE_CPU=1', '/DHYLE_TEST_DSPARK_STATE_CUDA=1']),
        ('runner', 'model_graph_run_test.cc', []),
        ('glm', 'glm_pro_mtp_state_consumer_test.cc', ['/DHYLE_TEST_GLM_STATE_CPU=1', '/DHYLE_TEST_GLM_STATE_CUDA=1',
            '/I' + str(R / '.scratch/glm-gguf-selected-20261023/B09/generated')])]:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        source = R / 'tests/compute_models' / file
        compile_args = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index - 1].lower() == '/sourcedependencies':
                arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(old_source):
                arg = str(source)
            compile_args.append(arg)
        compile_args += ['/external:I' + str(R / '.scratch/validation/cpu-final-f1/mixed-iq1/source/src'), *definitions]
        link_args = []
        for arg in base['link']:
            if key(arg) == key(old_object):
                arg = str(folder / 'unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            link_args.append(arg)
        for library in ['gtest_main.lib', 'gtest.lib']:
            path = R / '.scratch/build-compute-v2-dev/lib' / library
            assert path.is_file()
            if not any(key(arg) == key(path) for arg in link_args):
                link_args.append(str(path))
        assert sum(key(arg) == key(source) for arg in compile_args) == 1
        assert sum(key(arg) == key(folder / 'unit.obj') for arg in link_args) == 1
        units[name] = dict(source=str(source), compile=compile_args, link=link_args)
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    ds_environment = {k: v for k, v in read(R / '.scratch/dspark-random-mtp-20261024/pro-natural/runtime.json').items()
        if k.startswith('HYLE_DSPARK_') and not k.endswith('FRONTIER_FILE')}
    assert ds_environment['HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS'] == '0'
    assert ds_environment['HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS'] == '0'
    for name, value in ds_environment.items():
        if name.endswith('_DIR'):
            assert Path(value).is_dir(), name
    glm_environment = read(R / '.scratch/inference-commit-observation-20261029/plan.json')['glm_environment']
    save(W / 'plan.json', dict(base=pin(base_path),
        worktree_base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        units=units, retained=base['retained'], runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'], ds_environment=ds_environment, glm_environment=glm_environment,
        cases={
            'runner-cpu': dict(unit='runner', filter='ModelGraphRun.*', tests=3),
            'ds-pro-cpu': dict(unit='ds', filter='DSparkProOriginalState.CpuNaturalRandomMarkovPrefixAndPendingContinue', tests=1),
            'ds-flash-cpu': dict(unit='ds', filter='DSparkFlashFormalState.CpuRandomMarkovPrefixCommitsActualStateAndCursor', tests=1),
            'glm-cuda': dict(unit='glm', filter='GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNRandomVerifierContinuesAtomically', tests=1)}))
    print('Prepared three consumer TUs, four finite native processes, 227 retained SDK inputs; no SDK build/download.')

def receipt(name):
    result = read(W / 'compile' / name / 'receipt.json')
    exact(result['object'])
    for item in result['source_identities']:
        exact(item)
    return result

def main():
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
        return
    name = sys.argv[2]
    attempt = sys.argv[3] if len(sys.argv) > 3 else 'attempt1'
    plan = read(W / 'plan.json')
    if action == 'compile':
        folder = W / 'compile' / name
        (folder / attempt).mkdir(parents=True, exist_ok=True)
        shutil.copyfile(plan['units'][name]['source'], folder / attempt / 'consumer.cc')
        shutil.copyfile(R / 'tests/compute_models/model_graph_run.h', folder / attempt / 'model_graph_run.h')
        shutil.copyfile(R / 'tests/compute_models/dspark_native_consumer.h', folder / attempt / 'dspark_native_consumer.h')
        b.execute(plan['units'][name]['compile'], folder / attempt, 240)
        deps = read(folder / 'dependencies.json')['Data']
        paths = sorted({Path(p).resolve() for p in [deps['Source'], *deps['Includes']] if Path(p).is_relative_to(R)})
        result = dict(object=pin(folder / 'unit.obj'), process=pin(folder / attempt / 'process.json'),
            source_identities=[pin(p) for p in paths])
        save(folder / 'receipt.json', result)
        save(folder / attempt / 'receipt.json', result)
    elif action == 'link':
        receipt(name)
        for item in plan['retained']:
            exact(item)
        exact(plan['runtime'])
        exact(plan['sdk'])
        b.execute(plan['units'][name]['link'], W / 'link' / name / attempt, 180)
        image = pin(W / 'bin' / (name + '.exe'))
        save(W / ('ready-' + name + '.json'), image)
        save(W / 'link' / name / attempt / 'image.json', image)
    elif action == 'run':
        case = plan['cases'][name]
        receipt(case['unit'])
        image = read(W / ('ready-' + case['unit'] + '.json'))
        exact(image)
        os.environ.update(plan['ds_environment'] if case['unit'] == 'ds' else plan['glm_environment'] if case['unit'] == 'glm' else {})
        folder = W / 'runs' / name / attempt
        os.environ.update(HYLE_DSPARK_PRO_FRONTIER_FILE=str(folder / 'missing-pro-frontier.json'),
            HYLE_DSPARK_FLASH_FRONTIER_FILE=str(folder / 'missing-flash-frontier.json'),
            HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
        save(folder / 'image.json', image)
        b.execute([image['path'], '--gtest_color=no', '--gtest_filter=' + case['filter'],
            '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 600)
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('failures') == '0' and result.get('errors', '0') == '0'
        assert not result.findall('.//skipped')
        save(folder / 'report.json', dict(status='PASS', tests=case['tests'], failures=0, skipped=0,
            properties={p.get('name'): p.get('value') for p in result.findall('.//property')}))
        print('PASS', name)
    else:
        raise ValueError(action)

if __name__ == '__main__':
    main()
