from pathlib import Path
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('shared_build', R / '.scratch/inference-multimodel-observation-20261029/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
b.W = W; b.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def prepare():
    base_path = R / '.scratch/inference-sidecar-pages-20261029/model-link-base.json'
    base = read(base_path)
    old_plan = read(base_path.parent / 'plan.json')
    for item in base['retained']: exact(item)
    exact(base['runtime']); exact(base['sdk_engine_dependencies'])
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']: exact(item)
    units = {}
    for name, relative, old_name in [
        ('layout', 'tests/tools/inference_batch_layout_test.cc', 'append'),
        ('qwen', 'tests/tools/qwen_host_image_test.cc', 'qwen'),
        ('ordinary', 'tests/tools/qwen_generation_batch_relay_probe.cc', 'ordinary')]:
        recipe = old_plan['units'][old_name]
        old_object = read(base_path.parent / 'compile' / old_name / 'receipt.json')['object']['path']
        source = R / relative; assert source.is_file()
        folder = W / 'compile' / name; folder.mkdir(parents=True, exist_ok=True)
        args = []
        for index, arg in enumerate(recipe['compile']):
            if index and recipe['compile'][index-1].lower() == '/sourcedependencies': arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(recipe['source']): arg = str(source)
            args.append(arg)
        link = []
        for arg in recipe['link']:
            if key(arg) == key(old_object): arg = str(folder / 'unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin' / name).with_suffix(suffix)); break
            link.append(arg)
        assert sum(key(arg) == key(source) for arg in args) == 1
        assert sum(key(arg) == key(folder / 'unit.obj') for arg in link) == 1
        units[name] = dict(source=str(source), compile=args, link=link)
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    cases = {'layout-cpu': dict(unit='layout', filter='InferencePagedLayout.*', tests=4)}
    for name in ['history-cpu', 'mixed-lag-cuda', 'mtp-cuda']: cases[name] = old_plan['cases'][name]
    conditional = old_plan['fixtures']['conditional']['directory']
    for name, backend, option in [('ragged-cpu','--cpu','--ragged-prefill'),
        ('mtp-ragged-cuda','--cuda','--mtp-ragged-prefill'), ('varlen-cuda','--cuda','--mtp-varlen-verify')]:
        cases[name] = dict(unit='qwen', args=[backend, conditional, option])
    ordinary = W / 'ordinary-input'; ordinary.mkdir(exist_ok=False)
    original = Path(old_plan['ordinary_fixture']['directory'])
    for name in ['weights.tsv', 'prompt.ids']: shutil.copyfile(original / name, ordinary / name)
    cases['ordinary-cuda'] = dict(unit='ordinary', args=['--cuda-continuous', str(ordinary)])
    save(W / 'plan.json', dict(base=pin(base_path), worktree_base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        units=units, cases=cases, retained=base['retained'], runtime=base['runtime'], sdk=base['sdk_engine_dependencies'],
        fixtures=old_plan['fixtures'], ordinary_fixture=dict(source=str(original), directory=str(ordinary),
            files=[pin(ordinary / n) for n in ['weights.tsv','prompt.ids']])))
    print('Prepared 3 current consumers, 8 bounded cases, original227 SDK inputs; no build or download.')

def main():
    action = sys.argv[1]
    if action == 'prepare': prepare(); return
    if action in ['compile','link']:
        if action == 'compile':
            folder = W / 'compile' / sys.argv[2] / (sys.argv[3] if len(sys.argv)>3 else 'attempt1')
            folder.mkdir(parents=True,exist_ok=True)
            for relative in ['engine/inference/paged_layout_scratch.h','engine/models/qwen35/main.cc']:
                shutil.copyfile(R / relative, folder / Path(relative).name)
        b.main(); return
    assert action in ['run', 'collect']
    name = sys.argv[2]; attempt = sys.argv[3] if len(sys.argv)>3 else 'attempt1'
    plan = read(W / 'plan.json'); case = plan['cases'][name]
    b.receipt(case['unit']); image = read(W / ('ready-'+case['unit']+'.json')); exact(image)
    folder = W / 'runs' / name / attempt; save(folder / 'image.json',image)
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    args = ['--gtest_color=no','--gtest_filter='+case['filter'],'--gtest_output=xml:'+str(folder / 'results.xml')] if 'filter' in case else case['args']
    if action == 'run': b.b.execute([image['path'],*args],folder,600)
    else:
        process = read(folder / 'process.json')
        assert process['state'] == 'TERMINAL' and process['exit'] == 0
    if 'filter' in case:
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == str(case['tests']) and result.get('failures') == '0' and result.get('errors','0') == '0'
        assert not result.findall('.//skipped')
        report = dict(status='PASS',tests=case['tests'],failures=0,skipped=0)
    else:
        decoder = json.JSONDecoder(); remaining = (folder / 'stdout.log').read_text(encoding='utf-8-sig').strip(); reports=[]
        while remaining:
            item, end = decoder.raw_decode(remaining); reports.append(item); remaining=remaining[end:].lstrip()
        assert reports and all(item['status']=='PASS' for item in reports)
        report=reports[-1]
        if len(reports)>1: report['preliminary_reports']=reports[:-1]
    save(folder / 'report.json', report); print('PASS',name)

if __name__ == '__main__': main()
