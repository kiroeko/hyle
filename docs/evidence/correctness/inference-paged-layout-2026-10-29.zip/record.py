from pathlib import Path
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('build',W/'build.py'); b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
E=R/'docs/evidence/correctness/inference-paged-layout-2026-10-29.json'
SOURCES=['engine/inference/paged_layout_scratch.h','engine/models/qwen35/main.cc',
    'tests/tools/inference_batch_layout_test.cc','tests/compute_batch/CMakeLists.txt']

def prepare():
    p=read(W/'plan.json')
    for unit in p['units']: b.b.receipt(unit)
    for item in p['retained']:exact(item)
    exact(p['runtime']);exact(p['sdk'])
    for unit in read(p['sdk']['path'])['engine_consumers']:
        for item in unit['source_identities']:exact(item)
    for case in p['cases']:
        f=W/'runs'/case/'attempt1'; process=read(f/'process.json');report=read(f/'report.json')
        assert process['state']=='TERMINAL' and process['exit']==0 and report['status']=='PASS'
    save(W/'source-freeze.json',dict(base_commit=p['worktree_base_commit'],sources=[pin(R/s) for s in SOURCES]))
    save(W/'model-link-base.json',dict(schema='hyle.paged-layout.current-link-base.v1',base=p['base'],
        compile=p['units']['qwen']['compile'],link=p['units']['qwen']['link'],consumer_source=pin(p['units']['qwen']['source']),
        previous_consumer=pin(W/'compile/qwen/receipt.json'),retained=p['retained'],runtime=p['runtime'],
        sdk_engine_dependencies=p['sdk'],source_freeze=pin(W/'source-freeze.json')))
    save(W/'reuse.json',dict(model_link_base=pin(W/'model-link-base.json'),
        consumers={name:dict(**unit,receipt=pin(W/'compile'/name/'receipt.json')) for name,unit in p['units'].items()}))
    old=R/'.scratch/inference-sidecar-pages-20261029/compile'
    roots=[W/'bin',old/'qwen',old/'ordinary']
    targets=[f for f in (W/'bin').iterdir() if f.is_file()]+[old/n/'unit.obj' for n in ['qwen','ordinary']]
    assert not {b.key(f) for f in targets}&{b.key(i['path']) for i in p['retained']}
    save(W/'cleanup-plan.json',dict(allowed_roots=[str(f.resolve()) for f in roots],targets=[pin(f) for f in targets]))
    print('PASS 8 finite current processes; prepared original227 SDK reuse and checked cleanup plan.')

def archive():
    p=read(W/'plan.json');freeze=read(W/'source-freeze.json')
    for item in freeze['sources']:exact(item)
    builds={n:dict(object=b.b.receipt(n)['object'],compile=read(W/'compile'/n/'attempt1/process.json'),
        link=read(W/'link'/n/'attempt1/process.json')) for n in p['units']}
    cases={n:dict(process=read(W/'runs'/n/'attempt1/process.json'),report=read(W/'runs'/n/'attempt1/report.json')) for n in p['cases']}
    result=dict(schema='hyle.correctness.paged-layout.v1',date='2026-10-29',status='PASS',base_commit=p['worktree_base_commit'],
        changes=['PagedLayoutScratch cold-reserves only host integer ranges; prepares page IDs/query and KV indptr/tail lengths, preserving repeated shared pages and actual visible rows.',
            'Target, batched draft, private NextN and partial-accept layout use the original BatchSchema::version and original number/order of versions. R1 does not mint an extra aggregate.',
            'Original target early cohort capacity check, packed row offsets, decode-ahead direct spans and all source/page permissions remain separate. Scratch is reused only after version synchronously copies it.',
            'Private NextN positions are cold-reserved. Schema active snapshots/generation/allocation and source footprint vectors remain original; no second executor or new permission owner.'],
        counts=dict(CXX_attempts=3,links=3,consumer_TUs=3,retained_SDK_inputs=227,SDK_CXX=0,NVCC=0,full_builds=0,downloads=0,
            native_processes=8,passed_processes=8,GTests=4,ordinary_control_and_candidate_arms=16),
        sources=freeze['sources'],builds=builds,cases=cases,cleanup=read(W/'cleanup-result.json'),
        postprocess=read(W/'runs/varlen-cuda/attempt1/postprocess-recovery.json'),
        boundaries=['No new throughput or whole-engine memory measurement; unchanged schema version allocation is not claimed eliminated.',
            'Varlen original oracle is numerically equivalent, not byte-identical; original numeric gates were retained.',
            'CPU/ragged/mixed/ordinary fixtures are finite untrained geometry. Natural MTP is trained Qwen3.5-2B P154/O40 and compares original Hyle paths, not llama.cpp.',
            'This shared layout preparation is part of full architecture convergence; the complete model-independent engine and future multi-device execution are not complete.'],
        archive=E.with_suffix('.zip').name)
    save(E,result)
    with zipfile.ZipFile(E.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.write(E,E.name)
        for relative in SOURCES:
            z.write(R/relative,'current/'+relative)
            old=subprocess.run(['git','show',p['worktree_base_commit']+':'+relative],cwd=R,capture_output=True)
            if old.returncode==0:z.writestr('parent/'+relative,old.stdout)
        for relative in ['build.py','record.py','plan.json','source-freeze.json','model-link-base.json','reuse.json','cleanup-plan.json','cleanup-result.json']:
            z.write(W/relative,relative)
        for section in ['compile','link','runs']:
            for f in sorted((W/section).rglob('*')):
                if f.is_file() and f.name in ['receipt.json','process.json','stdout.log','stderr.log','command.json','image.json','report.json','results.xml','consumer.cc','paged_layout_scratch.h','main.cc','postprocess-recovery.json']:
                    z.write(f,str(f.relative_to(W)))
        z.write(R/'test.ps1','cleanup.ps1')
        for relative in ['.scratch/inference-multimodel-observation-20261029/build.py','.scratch/inference-program-identity-20261029/build.py']:
            z.write(R/relative,'support/'+Path(relative).parent.name+'/build.py')
        z.write(Path(p['sdk']['path']),'support/sdk-engine-dependencies.json')
    print('PASS evidence',E.name,E.with_suffix('.zip').stat().st_size,'bytes archive')

if sys.argv[1]=='prepare':prepare()
elif sys.argv[1]=='archive':archive()
else:raise ValueError(sys.argv[1])
