from pathlib import Path
import sys,json,importlib.util
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('ct_block_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASES={
 'cpu':A/'fixed-role-binding-2026-10-21/blockwise-w4a8/cpu/attempt4/link-plan.json',
 'cuda':A/'fixed-role-binding-2026-10-21/blockwise-w4a8/cuda/checks/link-attempt2/link-plan.json',
 'vulkan':A/'fixed-role-binding-2026-10-21/blockwise-w4a8/vulkan/checks/attempt2/link-plan.json'}
arm,attempt=sys.argv[1:3];base=c.read(BASES[arm]);recipes=h.metadata({arm:base})
out=P/arm/'checks'/attempt;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
test_name='ct_block128_activation_edges_test.cc' if len(sys.argv)>3 and sys.argv[3]=='edges' else 'ct_block128_qdq_test.cc'
source=R/f'tests/graph_route_{arm}'/test_name
previous=R/f'tests/graph_route_{arm}/fp8_channel_token_qdq_test.cc'
matches=[(row,recipes.get(c.key(row['path']))) for row in base['inputs'] if c.key(recipes.get(c.key(row['path']),{}).get('source_path',''))==c.key(previous)]
assert len(matches)==1,(arm,len(matches));old,recipe=matches[0]
command=b.host_command(recipe['command'],source,'test',out);env,_=b.environment(command,[],out)
assert not (out/'compile.result.json').exists()
c.save(out/'test-plan.json',dict(command=command,source=b.identity(source),recipe=b.identity(recipe['recipe'])))
c.execute('compile',command,env,out);depfile=out/'test-deps.json';deps=c.read(depfile)['Data'];obj=b.identity(out/'test.obj')
record=dict(command=command,source=b.identity(source),object=obj,source_dependencies=b.identity(depfile),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
c.save(out/'test-identity.json',record)
image=out/(arm+'.exe');command=[x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command.insert(1,obj['path']);command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[obj,*base['inputs']];assert all(b.same(x) for x in inputs)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(BASES[arm]),new_test=b.identity(out/'test-identity.json'),SDK_builds=0,GPU_runs=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('link',command,env,out)
c.save(out/'image.json',b.identity(image));print(out/'link-plan.json',flush=True)
