from pathlib import Path
import json
P=Path(__file__).resolve().parents[1];R=P.parents[2]
p=R/'docs/implementation/model-quantizations.json'
before=P/'root/model-quantizations-before.json'
assert not before.exists();before.write_bytes(p.read_bytes())
d=json.loads(p.read_text(encoding='utf-8-sig'))
a=d['artifacts'][21];assert a['repository']=='RedHatAI/Kimi-K3-FP8-BLOCK'
c=a['provider_coverage'];e='docs/evidence/correctness/ct-bf16-block128-reference-2026-10-21.json'
mapping=('Physical sampled E4 W and BF16 block128 scales follow root CT FP8_BLOCK, not nested legacy MXFP4. '
 'Fixed CT BF16 dynamic group128 activation and block128 weight dequantization now execute as an ordinary '
 'typed graph on CPU/CUDA/Vulkan/Apple: exactly-zero SA substitutes BF16 eps1/128, all BF16 QDQ boundaries '
 'and F32-accumulation/BF16-output MatMul remain. Selected experts Gather original E4 W/BF16 SF before '
 'decoding, with shared A once per token; no full ENK floating bank. Bounded finite-source software '
 'reference with N/K multiples128, not equivalence to F32-scale code-dot or whole-artifact execution.')
remaining=['Independent expert working-set binding and whole-artifact execution remain unverified.']
c['review_scope']='2026-10-21 fixed-source roles plus exact four-backend CT BF16 block128/group128 ordinary graph reference; no publisher numeric payload or whole-artifact execution.'
c['mapping_status']=mapping
c['role_domains'][0]['observed']=mapping
c['role_domains'][0]['evidence']=e
c['role_domains'][0]['unresolved']=remaining
c['artifact_unaligned_or_unverified']=remaining
c['missing_capabilities']=remaining
c['reachable_entry_points'].insert(0,dict(operation='Ordinary Gather/View/Reduce/Binary/Cast/Select/MatMul',
 execution='BF16 A[T,K], E4 W[N,K] and BF16 SF[N/128,K/128]; dense or selected experts from original E4/BF16 banks, retaining all BF16 rounds. Full checked IDs precede selection. Finite-source, N/K multiples128 bounded reference.',
 providers=['CPU native ordinary graph','CUDA original native Gather + typed ggml Binary + cuBLASLt batched MatMul',
            'Vulkan original checked Gather + typed graph/native MatMul','Apple original checked MLX Gather + typed graph'],
 evidence=e,qualification='18 new plus18 related cases across actual windows; no full artifact/model, Linux, hardware FP8 GEMM, quality or throughput claim.'))
c['operator_regression_evidence']=e
c['fusion_coverage']='Exact ordinary BF16 QDQ graph qualified; no physical FP8 GEMM/full expert fusion or whole-artifact fusion claim.'
c['fixed_source_role_binding']['facts']['mapping']=mapping
c['exact_consumer_reference']=dict(observed_on='2026-10-21',evidence=e,artifact_execution_verified=False,
  limits=['Finite-source activation witnesses; NaN/Inf reduction-source policy unqualified.',
          'N/K multiples128 only; omitted producer block inference does not qualify arbitrary tails.',
          'Bounded E3 selected bank; independent expert working sets remain delivery3.'])
d['followup_reviews'].append(dict(observed_on='2026-10-21',evidence=e,artifact_indices=[21],
 scope='Fixed CT BF16 block128 weight and dynamic group128 activation ordinary graph, four backends, bounded math/lifetimes; no numeric publisher payload or whole-artifact execution.'))
assert len(d['artifacts'])==33 and all(not x['provider_coverage']['artifact_execution_verified'] for x in d['artifacts'])
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('Updated catalog21; all33 whole-artifact execution flags remain false.')
