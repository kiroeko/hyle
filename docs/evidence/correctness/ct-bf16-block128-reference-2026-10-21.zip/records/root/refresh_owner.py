from pathlib import Path
import json,sys,importlib.util
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('ct_block_refresh',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
basepath=Path(sys.argv[1]).resolve();source=R/sys.argv[2];out=P/sys.argv[3]
base=c.read(basepath);recipes=h.metadata({'base':base});out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
matches=[(r,recipes.get(c.key(r['path']))) for r in base['inputs'] if c.key(recipes.get(c.key(r['path']),{}).get('source_path',''))==c.key(source)]
assert len(matches)==1,(source,len(matches));old,recipe=matches[0]
command=b.host_command(recipe['command'],source,'owner',out);env,_=b.environment(command,[],out)
assert not (out/'compile.result.json').exists();c.save(out/'compile-plan.json',dict(command=command,source=b.identity(source),old_object=old,recipe=b.identity(recipe['recipe'])))
c.execute('compile',command,env,out);depsfile=out/'owner-deps.json';deps=c.read(depsfile)['Data']
obj=b.identity(out/'owner.obj');record=dict(command=command,source=b.identity(source),object=obj,old_object=old,source_dependencies=b.identity(depsfile),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
c.save(out/'identity.json',record)
image=out/'updated.exe';command=[obj['path'] if c.key(x)==c.key(old['path']) else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs=[obj if c.key(x['path'])==c.key(old['path']) else x for x in base['inputs']];assert all(b.same(x) for x in inputs)
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(basepath),owner=b.identity(out/'identity.json'),SDK_builds=0,GPU_runs=0))
env,runtime=b.environment(command,[x['path'] for x in inputs],out);c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image));print(out/'link-plan.json',flush=True)
