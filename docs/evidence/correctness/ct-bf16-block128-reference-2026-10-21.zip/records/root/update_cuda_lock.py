from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parents[1];R=P.parents[2]
out=P/'cuda-bfloat-binary';lock=R/'cmake/HyleDependencyLock.json'
before=out/'dependency-lock-before.json'
assert not before.exists()
before.write_bytes(lock.read_bytes())
d=json.loads(lock.read_text(encoding='utf-8-sig'))
row=next(x for x in d['dependencies'] if x['name']=='ggml_cuda_runtime_patches')
old=json.loads(json.dumps(row));assert row['version'].endswith('-v33')
base=R/row['vendored']['path'];files=[]
def normalized(p):return p.read_bytes().replace(b'\r\n',b'\n').replace(b'\r',b'\n')
for p in sorted(base.rglob('*'), key=lambda x:x.relative_to(base).as_posix()):
    assert not p.is_symlink()
    if p.is_file():files.append((p.relative_to(base).as_posix(),hashlib.sha256(normalized(p)).hexdigest()))
manifest=''.join(f'{name}|{digest}\n' for name,digest in files)
row['version']=row['version'][:-3]+'v34'
row['vendored']['tree_sha256']=hashlib.sha256(manifest.encode()).hexdigest()
for item in row['license']['files']:
    item['sha256']=hashlib.sha256(normalized(R/item['path'])).hexdigest()
lock.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(out/'dependency-lock-update.json').write_text(json.dumps(dict(before=old,after=row,tree_files=files,
    changed_files=['third_party/ggml_cuda_runtime/patches.json','third_party/ggml_cuda_runtime/NOTICE.md'],
    SDK_rebuilt=False),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(out/'check-lock.cmake').write_text('include("'+(R/'cmake/HyleDependencyVersions.cmake').as_posix()+'")\nhyle_audit_in_tree_dependencies(ggml_cuda_runtime_patches)\n',encoding='utf8')
print(row['version'],row['vendored']['tree_sha256'])
