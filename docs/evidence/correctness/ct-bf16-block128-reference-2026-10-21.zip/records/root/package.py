from pathlib import Path
import hashlib, json, zipfile

P = Path(__file__).resolve().parents[1]
R = P.parents[2]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size, sha256=sha(p))
def save(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf8')

# Earlier partial windows retain their actual failures. Only named green
# neighbors are counted; a new image is never credited with an earlier run.
windows = [
    ('CPU core', 'cpu/validation/attempt3/receipt.json', None),
    ('CPU edges', 'cpu/validation/edges1/receipt.json', None),
    ('CUDA original neighbors', 'cuda/validation/matmul2/receipt.json',
     ['CublasProvider.Float32LayoutsAndChangedInputsMatchDoubleOracle',
      'CublasProvider.HalfDecodeAndPrefillUseIndependentLanes',
      'CublasProvider.Bfloat16DecodeAndPrefillUseIndependentLanes',
      'CublasProvider.ColdMetadataFailuresRollBackAndReservedReplayDoesNotAllocate',
      'CudaCcclGather.EveryStorageTypeAndIndexWidthPreserveBitsAcrossAxesAndStrides',
      'CudaCcclGather.CheckedFailurePreservesAllOutputAndFreshSlotRecovers',
      'CudaCcclGather.CheckedSubmitStaysPendingBehindProducerAndReportsDeviceError',
      'CudaCcclGather.EmptyUncheckedAndAliasesUseThePublicContract']),
    ('CUDA final typed arithmetic and fusion', 'cuda/validation/matmul3/receipt.json', None),
    ('CUDA final channel/token neighbors', 'cuda/validation/matmul4/receipt.json', None),
    ('Vulkan core and storage', 'vulkan/validation/matmul2/receipt.json',
     ['VulkanCtBlock128QdqGraph.OrdinaryDenseAndSelectedExpertsKeepBfloatBoundaries',
      'VulkanCtBlock128QdqGraph.PublishedActivationAndSelectedWeightKeepExactStorage',
      'VulkanCtBlock128QdqGraph.CheckedExpertIdsFailAndFreshInvocationRecovers',
      'VulkanFp8ChannelTokenStorage.BfloatFp8BridgeKeepsRneAndRejectsFp8Arithmetic']),
    ('Vulkan generic broadcast and edges', 'vulkan/validation/matmul3/receipt.json', None)]
records = []; names = set()
for label, relative, selected in windows:
    path = P/relative; d = read(path)
    failed = {x['classname']+'.'+x['name'] for x in d['failed']}
    assert not d['skipped']
    if selected is None:
        assert d['passed']; selected = d['names']
    assert set(selected) <= set(d['names']) and not set(selected)&failed
    names.update(selected)
    records.append(dict(label=label, receipt=identity(path), green_names=selected,
                        original_failed_names=sorted(failed)))
apple_path = P/'apple/activation-edges/final-validation.json'; apple = read(apple_path)
assert apple['total_tests'] == 6 and apple['failed'] == 0 and apple['skipped'] == 0
names.update(c['name'] for run in apple['runs'] for c in run['cases'])
new = {n for n in names if 'CtBlock128' in n or 'Batched' in n}
assert len(new) == 18 and len(names) == 36, (len(new), len(names), sorted(names))

sources = [
    'src/compute_provider_cuda/collectives_provider.cc',
    'src/compute_provider_cuda/collectives.cu',
    'src/compute_provider_cublas/cublas_provider.cc',
    'include/hyle/compute/providers/cublas.h',
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'third_party/ggml_cuda_runtime/patches.json',
    'third_party/ggml_cuda_runtime/NOTICE.md', 'cmake/HyleDependencyLock.json',
    'src/compute_route_vulkan/vulkan_program.cc',
    'src/compute_provider_ggml_vulkan/region.cc',
    'src/compute_route_vulkan/vulkan_region.cc',
    'src/compute_route_apple/apple_operations.cc',
    'src/compute_route_apple/apple_mature_float.cc',
    'src/compute_route_apple/apple_static_fp8.cc',
    'src/compute_route_apple/apple_static_fp8.h',
    'tests/compute_models/ct_block128_qdq_fixture.h',
    'tests/compute_models/ct_block128_activation_edges.h',
    'tests/compute_models/nvfp4_reference_fixture.h',
    'tests/compute_provider_cublas/cublas_provider_test.cc',
    'tests/graph_route_vulkan/batched_matmul_test.cc']
for arm in ('cpu', 'cuda', 'vulkan', 'apple'):
    sources.extend(f'tests/graph_route_{arm}/{name}' for name in
                   ('ct_block128_qdq_test.cc', 'ct_block128_activation_edges_test.cc', 'CMakeLists.txt'))
assert sha(R/'tests/compute_models/ct_block128_qdq_fixture.h') == 'fbd56d391645b630f8dd8a9037d8395ab2cfef349d98e31b5ddebfa20170d518'
source_ids = [identity(R/s) for s in sources]
entries = {'source/'+s: R/s for s in sources}
extensions = {'.json','.py','.log','.xml','.txt','.diff','.cc','.cu','.cuh','.h','.d','.cmake','.ptx'}
for p in P.rglob('*'):
    if p.is_file() and p.suffix.lower() in extensions:
        relative = p.relative_to(P).as_posix()
        if relative in ('root/package-summary.json',): continue
        entries['records/'+relative] = p

archive = R/'docs/evidence/correctness/ct-bf16-block128-reference-2026-10-21.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=8) as z:
    for n, p in sorted(entries.items()): z.write(p, n)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(entries)
    for n,p in entries.items(): assert hashlib.sha256(z.read(n)).hexdigest() == sha(p), n
report = dict(observed_on='2026-10-21', status='bounded_ordinary_graph_four_backend_reference_passed',
    scope='Fixed CT 1f3b63299961bec13861825d0823a502e875091d, catalog21 E4/BF16 block128 W and BF16 dynamic group128 A; no new public operator.',
    source_contract=read(P/'review/contract-review.json'),
    architecture='Ordinary typed Gather/View/Reduce/Binary/Cast/Select/MatMul. Select original E4 W and BF16 SF before decoding; share A QDQ once per token. Existing cold plans/Invocation/Completion and backend executors; no full ENK floating bank.',
    math='SA=BF16(absmax(A)/448), exactly zero only becomes BF16 eps1/128. Preserve BF16 division, symmetric +0/-0 and E4 SATFINITE RNE, then BF16 dequantization. W: E4->BF16, BF16 product with original BF16 block128 scale. MatMul BF16 inputs/F32 accumulation/BF16 output.',
    implementation=['CUDA checked Gather supports prepared external capture using original functors and cold-materialized native kernels.',
       'CUDA cuBLASLt cold affine batch runs preserve stride-zero broadcasts and per-run actual alignment; no expanded A or hot metadata allocation.',
       'CUDA original typed BF16 Binary native kernels preserve subnormal arithmetic; original fusion/domain and F32/F16 math retained.',
       'Vulkan E4 Gather retains original checked storage path. Original native MatMul handles CT M1 broadcast; other nonaffine batches use cold native DAG runs plus result concat (result copy is not zero). No A/W expansion.',
       'Apple E4 Gather uses original checked MLX path; ordinary BF16 Mul/Div retain raw subnormal bits with existing IEEE helpers and stride-zero broadcast metadata.'],
    tests=dict(distinct_total=len(names), new_cases=len(new), neighbors=len(names-new),
       new_names=sorted(new), neighbor_names=sorted(names-new), windows=records,
       apple=identity(apple_path), new_graph_successful_submissions=116,
       new_graph_expected_failed_completions=8, generic_cublas_submissions=24,
       counting='Four backends each core23 successful+2 expected failed, edges6 successful. Additional generic CUDA24 Direct submissions; Vulkan general MatMul covers F32/F16/BF16. Cases deduplicated across actual windows; partial failures remain in original receipts.'),
    failures_retained=['Initial fixture compile/oracle witnesses corrected before accepting results.',
       'CUDA capture gate and CUDA/Vulkan batched MatMul initially rejected valid ordinary CT graph.',
       'Tiny BF16 +/-0x0304 produced zero instead of +/-0x02fc on CUDA/Apple; first wrong Apple SA 0x0009->0 retained.',
       'Temporary CUDA BF16 Binary rejection broke existing SiLU region/explicit-provider paths; final native fix restores both without changing tests.',
       'Vulkan expanded view constructor asserted dense span before zero strides; general GEMM then rejected outer-batch broadcast. Source audit found affine flat-batch addressing; final cold runs use original native matrix operations.'],
    limits=['Finite-source activation witnesses only; source NaN/Inf reduction policy not qualified.',
       'Bounded N/K multiples128; producer omitted-args block inference is not assumed correct for arbitrary tails.',
       'No publisher numeric tensor payload, full artifact, full model, quality, throughput, or new Linux execution.',
       'Independent expert working-set binding remains delivery3; bounded selected E3 bank does not qualify huge artifact banks.',
       'Capability package8 remains open: grouped power2, ordinary paged E4 KV/compact MLA and unresolved Inferact producer contract remain.'],
    current_sources=source_ids, archive=dict(**identity(archive), members=len(entries)),
    archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'), report)
save(P/'root/package-summary.json', dict(evidence=identity(archive.with_suffix('.json')),
     archive=identity(archive), new_cases=len(new), neighbors=len(names-new), members=len(entries)))
print(json.dumps(read(P/'root/package-summary.json'), ensure_ascii=False))
