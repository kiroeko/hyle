"""Record exact native dependencies and source-only capture/lifetime audit."""
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = S.parents[3]


def ident(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    out = S / 'checks/attempt1'
    depfile = out / 'native.d'
    raw = depfile.read_text()
    raw = raw.split(' : ', 1)[1]
    paths = []
    for line in raw.splitlines():
        token = line.strip().removesuffix('\\').strip().replace('\\ ', ' ')
        if token:
            path = Path(token).resolve()
            assert path.is_file(), token
            paths.append(path)
    paths = sorted(set(paths), key=lambda p: str(p).lower())
    inventory = {'dependency_file': ident(depfile), 'count': len(paths), 'files': [ident(p) for p in paths]}
    save(out / 'native-dependency-inventory.json', inventory)
    sdk = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include/cccl')
    save(S / 'source-audit.json', {
        'status': 'source_review_complete_actual_GPU_pending_root',
        'before': ident(S / 'before.json'), 'freeze': ident(S / 'source-freeze.json'),
        'diff': ident(S / 'implementation.diff'),
        'thrust_audit': {'source': [ident(sdk / p) for p in ['thrust/system/cuda/detail/for_each.h', 'thrust/system/cuda/detail/parallel_for.h', 'cub/device/device_for.cuh']],
            'before': 'Thrust for_each_n calls cub::DeviceFor::ForEachN and synchronize_optional(policy). par_nosync avoids optional stream synchronization; no demonstrated temporary allocation defect is claimed. Existing runtime nonetheless rejected every external capture and did not resolve Gather kernel materialization cold.',
            'after': 'Gather bypasses Thrust entirely. Explicit check/output kernels use only original functors, program-by-value, original stream and caller output. Selected kernels materialized with cudaFuncGetAttributes during configure called by propose/prepare. Zero Gather workspace remains unchanged.'},
        'checked_ID_order': 'Same stream: acquire_device_status reset (original queued accepted-prefix), check every index_count element, then output kernel. Output checks status before computing mapping or reading source; invalid ID leaves all output unchanged. Existing status shared/captured ownership is retained by QueueSequence, not this provider.',
        'empty_output': {'contract': 'provider::submit returns no_op before stream lookup, pointer lookup and IDs when count==0. Preserved; there is no zero-grid launch on the admitted public path. Index_count==0 necessarily yields outputcount==0 by Gather infer.',
                         'permanent_test': 'CudaCcclGather.EmptyUncheckedAndAliasesUseThePublicContract checks source[4,0] with nonempty illegal IDs still succeeds; do not introduce validation for empty output.',
                         'private_submit_caller': 'The only caller of collectives::submit is collectives_provider.cc after that count guard. A redundant private guard was not added, avoiding unrelated semantics or another compile.'},
        'strides_and_bytes': 'Original GatherIndex uses I32/I64 memcpy with plain index byte strides. Original Layout uses source byte strides and memcpy; output widths1/2/4/8 remain exact storage-bit copies, including E4 and BF16. Dense output alignment is original data_type_size. No dtype arithmetic added.',
        'bounds': 'Admission caps output and index counts at INT32_MAX, so fixed256 grid counts fit unsigned and CUDA x-grid limits. Program/header layout unchanged; positive count has positive index_count and selected width. No new buffer.',
        'other_families_unchanged': 'Scan/TopK retain old managed replay, runtime capture false, explicit cudaStreamIsCapturing rejection, CUB/Thrust algorithms and error synchronization. Only Gather changed.',
        'compile': {'CXX': 2, 'NVCC': 1, 'links': 1, 'failed_attempts': 0, 'SDK_rebuilds': 0, 'GPU_runs_by_this_agent': 0,
                    'products': ident(out / 'product-objects.json'), 'test_link_summary': ident(S / 'checks/test-and-link/summary.json'), 'native_dependency_inventory': ident(out / 'native-dependency-inventory.json')},
        'independent_review': 'Peer vulkan_paged_runtime_fix reviewed count0 concern, rechecked provider early no_op and permanent test, withdrew the zero-launch blocker; no remaining blocker reported.'})
    print(json.dumps({'native_dependency_count': len(paths), 'audit': ident(S / 'source-audit.json')}))


if __name__ == '__main__':
    main()
