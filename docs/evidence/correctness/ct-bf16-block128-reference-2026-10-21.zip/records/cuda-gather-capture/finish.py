"""Compile current CT wrapper once and link Gather capture owners; no GPU run."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[3]
P = S.parent
A = P.parent
OUT = S / 'checks/test-and-link'
OUT.mkdir(parents=True, exist_ok=True)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def identity(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    baseline = P / 'cuda/checks/attempt2/link-plan.json'
    old_test_path = P / 'cuda/checks/attempt2/test-identity.json'
    old_test = read(old_test_path)
    base = read(baseline)
    fixture = ROOT / 'tests/compute_models/ct_block128_qdq_fixture.h'
    assert identity(fixture)['sha256'] == 'fbd56d391645b630f8dd8a9037d8395ab2cfef349d98e31b5ddebfa20170d518'
    source = ROOT / 'tests/graph_route_cuda/ct_block128_qdq_test.cc'
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': old_test['command'][0]})
    env['VSLANG'] = '1033'
    temp = OUT / 'tmp'
    temp.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(temp)
    frozen = [identity(source), identity(fixture)]
    for p in [source, fixture]:
        dest = S / 'after' / p.relative_to(ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(p.read_bytes())
    save(OUT / 'test-source-freeze.json', frozen)

    def run(name, command):
        record = {'command': command, 'cwd': str(ROOT), 'started': time.time(), 'GPU_run': False}
        save(OUT / (name + '-command.json'), record)
        with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
            p = subprocess.run(command, cwd=ROOT, env=env, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(exit=p.returncode, finished=time.time())
        save(OUT / (name + '-result.json'), record)
        if p.returncode:
            print((OUT / (name + '.stdout.log')).read_text(errors='replace')[-6000:])
            print((OUT / (name + '.stderr.log')).read_text(errors='replace')[-4000:])
            raise SystemExit(p.returncode)

    args, skip = [], False
    for arg in old_test['command']:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith('/fo'):
            continue
        args.append(arg)
    obj, deps = OUT / 'test.obj', OUT / 'test-deps.json'
    args += ['/sourceDependencies', str(deps), '/Fo' + str(obj)]
    run('compile', args)
    test = {'command': args, 'source': identity(source), 'fixture': identity(fixture), 'object': identity(obj), 'dependencies': [identity(p) for p in dict.fromkeys(read(deps)['Data']['Includes'])], 'recipe': identity(old_test_path)}
    save(OUT / 'test-identity.json', test)
    products = read(S / 'checks/attempt1/product-objects.json')
    replacements = {old_test['object']['path'].lower(): str(obj)}
    for product in products:
        old = read(product['recipe']['path'])
        replacements[old['object']['path'].lower()] = product['object']['path']
    expected = {r['path'].lower(): r for r in base['inputs']}
    args, inputs = [], []
    for arg in base['command']:
        lower = arg.lower()
        if lower.startswith(('/out:', '/pdb:', '/map:', '/implib:')):
            continue
        replacement = replacements.get(lower, arg)
        args.append(replacement)
        if lower in expected:
            actual = identity(replacement)
            if lower not in replacements:
                assert actual == expected[lower], arg
            inputs.append(actual)
    image = OUT / 'cuda.exe'
    args += ['/OUT:' + str(image), '/PDB:' + str(OUT / 'cuda.pdb'), '/MAP:' + str(OUT / 'cuda.map')]
    save(OUT / 'link-plan.json', {'command': args, 'inputs': inputs, 'baseline': identity(baseline), 'replacements': replacements, 'SDK_rebuild': False, 'GPU_run': False})
    run('link', args)
    assert frozen == [identity(source), identity(fixture)]
    save(OUT / 'image.json', identity(image))
    save(OUT / 'summary.json', {'CXX': 1, 'links': 1, 'compile_exit': 0, 'link_exit': 0, 'GPU_runs': 0, 'image': identity(image), 'test_identity': identity(OUT / 'test-identity.json'), 'link_plan': identity(OUT / 'link-plan.json'), 'filter': 'CudaCtBlock128QdqGraph.*'})
    print('IMAGE_READY', image, flush=True)


if __name__ == '__main__':
    main()
