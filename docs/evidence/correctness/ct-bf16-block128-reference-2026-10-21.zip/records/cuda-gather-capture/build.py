"""Incremental two-owner Gather capture build; never executes an image/GPU."""
import concurrent.futures
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[3]
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
OUT = S / 'checks/attempt1'
OUT.mkdir(parents=True, exist_ok=True)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def identity(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    host_old = A / 'cuda-coarse-capture-tests/compute_provider_cuda--collectives_provider-identity.json'
    native_old = A / 'cccl-single-row-topk/checks/20261019T185353/native-identity.json'
    recipes = {'provider': read(host_old), 'native': read(native_old)}
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': recipes['provider']['command'][0]})
    env['VSLANG'] = '1033'
    temp = OUT / 'tmp'
    temp.mkdir(exist_ok=True)
    env['TMP'] = str(temp)
    env['TEMP'] = str(temp)
    frozen = []
    diff = []
    for row in read(S / 'before.json'):
        p = ROOT / row['path']
        before = S / 'before' / row['path']
        after = S / 'after' / row['path']
        after.parent.mkdir(parents=True, exist_ok=True)
        after.write_bytes(p.read_bytes())
        frozen.append(identity(p))
        diff += list(difflib.unified_diff(before.read_text().splitlines(True), p.read_text().splitlines(True), fromfile='before/' + row['path'], tofile='after/' + row['path']))
    (S / 'implementation.diff').write_text(''.join(diff), encoding='utf-8')
    save(S / 'source-freeze.json', {'sources': frozen, 'header_unchanged': identity(ROOT / 'src/compute_provider_cuda/collectives.h'), 'ABI_change': False})
    save(S / 'design.json', {
        'changed_owners': [r['path'] for r in frozen],
        'gather_only': 'Prepared/capture-compatible; original checked-ID and raw-byte gather functors run in two fixed native kernels. Plain strides/I32-I64 indices/all1,2,4,8-byte types unchanged.',
        'cold': 'cudaFuncGetAttributes for checked-ID kernel and selected output-width kernel, maxThreadsPerBlock>=256. No temporary storage; original queue status buffer.',
        'hot': 'Status reset via original acquire_device_status, check all IDs, then guarded raw byte output; native launches and cudaGetLastError only. No Thrust allocator/materialization/synchronization on Gather hot path.',
        'other_families': 'Scan and TopK remain Managed, capture-incompatible, original CUB/Thrust algorithms and explicit external-capture rejection.',
        'scope': 'No public header/Program/Plan ABI change; no executor/provider/routing change. Only these two actual owners rebuilt.'})

    def build(name):
        old = recipes[name]
        args, skip = [], False
        for arg in old['command']:
            if skip:
                skip = False
                continue
            low = arg.lower()
            if low == '/sourcedependencies' or arg in ['-MT', '-MF', '-o']:
                skip = True
                continue
            if low.startswith('/fo'):
                continue
            args.append(arg)
        obj = OUT / (name + '.obj')
        deps = OUT / (name + ('-deps.json' if name == 'provider' else '.d'))
        if name == 'provider':
            args += ['/sourceDependencies', str(deps), '/Fo' + str(obj)]
        else:
            args += ['-MT', str(obj), '-MF', str(deps), '-o', str(obj)]
        record = {'command': args, 'cwd': str(ROOT), 'source': identity(old['source']['path']), 'recipe': identity(host_old if name == 'provider' else native_old), 'started': time.time(), 'SDK_rebuild': False, 'GPU_run': False}
        save(OUT / (name + '-plan.json'), record)
        with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
            result = subprocess.run(args, cwd=ROOT, env=env, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
        record.update(exit=result.returncode, finished=time.time())
        save(OUT / (name + '-result.json'), record)
        if result.returncode:
            print((OUT / (name + '.stdout.log')).read_text(errors='replace')[-5000:])
            print((OUT / (name + '.stderr.log')).read_text(errors='replace')[-5000:])
            raise RuntimeError(name + ' compile failed')
        if name == 'provider':
            dep_paths = [Path(p) for p in read(deps)['Data']['Includes']]
        else:
            raw = deps.read_text().replace('\\\n', ' ').split(': ', 1)[1]
            import shlex
            # NVCC escapes spaces in Makefile dependencies; shlex posix parsing
            # would consume Windows backslashes, so retain its full exact file
            # and inventory the source/private headers separately.
            dep_paths = [Path(old['source']['path']), ROOT / 'src/compute_provider_cuda/collectives.h', ROOT / 'src/compute_backend_cuda/device_status_kernel.h']
        record.update(object=identity(obj), dependency_file=identity(deps), dependencies=[identity(p) for p in dict.fromkeys(dep_paths) if p.is_file()])
        save(OUT / (name + '-identity.json'), record)
        print(name, 'compile exit0', flush=True)
        return record

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        result = list(pool.map(build, ['provider', 'native']))
    assert all(identity(r['path']) == r for r in frozen)
    save(OUT / 'product-objects.json', result)
    print('PRODUCTS_READY', OUT, flush=True)


if __name__ == '__main__':
    main()
