"""One native binbcast owner plus restored tensor host owner; no GPU run."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
ROOT = S.parents[3]
A = P.parent
CACHE = Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
OUT = S / 'checks/attempt1'
OUT.mkdir(parents=True, exist_ok=True)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    manifest_path = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
    manifest = read(manifest_path)
    source = S / 'native-source/src/ggml-cuda/binbcast.cu'
    native_old_path = A / 'cuda-bf16-chain-fusion/binbcast-identity.json'
    native_old = read(native_old_path)
    host_old_path = P / 'cuda-numeric/attempt1/identity.json'
    host_old = read(host_old_path)
    baseline = P / 'cuda-batched-matmul/checks/general-broadcast/link-plan.json'
    base = read(baseline)
    # Only the ten actual pinned GGML headers needed by this native owner are
    # overlaid. Apply current canonical edits (not the obsolete old SDK copy)
    # and leave the shared pinned cache unmodified.
    closure = []
    headers = ['src/ggml-cuda/binbcast.cuh', 'src/ggml-cuda/common.cuh',
               'include/ggml.h', 'src/ggml-impl.h', 'include/gguf.h',
               'include/ggml-cuda.h', 'include/ggml-backend.h',
               'include/ggml-alloc.h', 'src/ggml-common.h',
               'src/ggml-cuda/vendors/cuda.h']
    patches = {r['path']: r for r in manifest['files']}
    for name in headers:
        origin = CACHE / name
        text = origin.read_text(encoding='utf-8')
        if name in patches:
            patch = patches[name]
            assert ident(origin)['sha256'] == patch['before_sha256'], name
            for edit in patch['edits']:
                assert text.count(edit['before']) == 1, (name, edit['before'][:60])
                text = text.replace(edit['before'], edit['after'])
            assert hashlib.sha256(text.encode()).hexdigest() == patch['after_sha256'], name
        target = S / 'native-source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(text.encode())
        closure.append({'origin': ident(origin), 'actual': ident(target), 'canonical_patch_applied': name in patches})
    save(S / 'native-source-closure.json', {'manifest': ident(manifest_path), 'headers': closure, 'shared_cache_mutated': False, 'source': ident(source)})
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': host_old['command'][0]})
    env['VSLANG'] = '1033'
    tmp = OUT / 'tmp'
    tmp.mkdir(exist_ok=True)
    env['TEMP'] = env['TMP'] = str(tmp)

    def execute(name, args):
        row = {'command': args, 'cwd': str(ROOT), 'started': time.time(), 'GPU_run': False}
        save(OUT / (name + '-command.json'), row)
        with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
            process = subprocess.Popen(args, cwd=ROOT, env=env, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
            save(OUT / (name + '-live.json'), {**row, 'pid': process.pid})
            result = process.wait()
        row.update(exit=result, finished=time.time())
        save(OUT / (name + '-result.json'), row)
        print(name, 'exit', result, flush=True)
        if result:
            print((OUT / (name + '.stdout.log')).read_text(errors='replace')[-8000:])
            print((OUT / (name + '.stderr.log')).read_text(errors='replace')[-5000:])
            raise RuntimeError(name + ' failed')

    def host_build():
        args, skip = [], False
        for arg in host_old['command']:
            if skip:
                skip = False
                continue
            if arg.lower() == '/sourcedependencies':
                skip = True
                continue
            if arg.lower().startswith('/fo'):
                continue
            args.append(arg)
        obj, deps = OUT / 'host.obj', OUT / 'host-deps.json'
        args += ['/sourceDependencies', str(deps), '/Fo' + str(obj)]
        execute('host', args)
        record = {'command': args, 'source': ident(host_old['source']['path']), 'object': ident(obj), 'dependencies': [ident(p) for p in dict.fromkeys(read(deps)['Data']['Includes'])], 'recipe': ident(host_old_path)}
        save(OUT / 'host-identity.json', record)
        return record

    def native_build():
        args, skip = [], False
        for arg in native_old['command']:
            if skip:
                skip = False
                continue
            if arg in ['-MT', '-MF', '-c', '-o']:
                skip = True
                continue
            if arg.startswith('-Xcompiler=-Fd'):
                continue
            args.append(arg)
        # Prepend the narrowly reconstructed canonical header closure, while
        # retaining every original arithmetic flag, including -use_fast_math.
        args[1:1] = ['-I' + str(S / 'native-source/src/ggml-cuda'), '-I' + str(S / 'native-source/src'), '-I' + str(S / 'native-source/include')]
        obj, deps = OUT / 'binbcast.obj', OUT / 'binbcast.d'
        keep = OUT / 'native-tmp'
        keep.mkdir(exist_ok=True)
        args += ['--keep', '--keep-dir', str(keep), '-MT', str(obj), '-MF', str(deps), '-c', str(source), '-o', str(obj)]
        execute('native', args)
        paths = []
        for line in deps.read_text().split(' : ', 1)[1].splitlines():
            token = line.strip().removesuffix('\\').strip().replace('\\ ', ' ')
            if token:
                paths.append(Path(token).resolve())
        record = {'command': args, 'source': ident(source), 'object': ident(obj), 'dependencies': [ident(p) for p in sorted(set(paths), key=lambda p: str(p).lower())], 'recipe': ident(native_old_path), 'original_fast_math_flag_preserved': '-use_fast_math' in args}
        save(OUT / 'native-identity.json', record)
        return record

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        h, n = pool.submit(host_build), pool.submit(native_build)
        host, native = h.result(), n.result()
    replacements = {host_old['object']['path'].lower(): host['object'], native_old['object']['path'].lower(): native['object']}
    expected = {r['path'].lower(): r for r in base['inputs']}
    assert all(k in expected for k in replacements)
    args, inputs = [], []
    for arg in base['command']:
        low = arg.lower()
        if low.startswith(('/out:', '/pdb:', '/map:', '/implib:')):
            continue
        value = replacements[low]['path'] if low in replacements else arg
        args.append(value)
        if low in expected:
            actual = ident(value)
            assert actual == (replacements[low] if low in replacements else expected[low]), arg
            inputs.append(actual)
    image = OUT / 'cuda.exe'
    args += ['/OUT:' + str(image), '/PDB:' + str(OUT / 'cuda.pdb'), '/MAP:' + str(OUT / 'cuda.map')]
    save(OUT / 'link-plan.json', {'command': args, 'inputs': inputs, 'base': ident(baseline), 'replacements': replacements, 'test_objects_exactly_reused': True, 'GPU_run': False, 'SDK_rebuild': False})
    execute('link', args)
    save(OUT / 'summary.json', {'CXX': 1, 'NVCC': 1, 'links': 1, 'SDK_rebuilds': 0, 'GPU_runs_by_this_agent': 0, 'image': ident(image), 'link_plan': ident(OUT / 'link-plan.json'), 'native_identity': ident(OUT / 'native-identity.json'), 'host_identity': ident(OUT / 'host-identity.json')})
    print('IMAGE_READY', image, flush=True)


if __name__ == '__main__':
    main()
