"""Summarize retained actual receipts; no compilation, GPU, or deletion."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[4]
P = ROOT / '.scratch/architecture-refactor-2026-10-18/ct-bf16-block128-reference'
N = P / 'cuda-bfloat-binary'
G = P / 'cuda-gather-capture'
B = P / 'cuda-batched-matmul'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    path = path.resolve()
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def window(name):
    directory = P / 'cuda/validation' / name
    receipt = read(directory / 'receipt.json')
    xml = ET.parse(directory / 'tests.xml').getroot()
    cases = list(xml.iter('testcase'))
    names = [x.attrib['classname'] + '.' + x.attrib['name'] for x in cases]
    failed = [x.attrib['classname'] + '.' + x.attrib['name'] for x in cases
              if x.find('failure') is not None]
    skipped = [x.attrib['classname'] + '.' + x.attrib['name'] for x in cases
               if x.find('skipped') is not None or x.attrib.get('status') == 'notrun']
    assert len(cases) == receipt['cases']
    assert set(names) == set(receipt['names'])
    assert bool(failed) == bool(receipt['failed'])
    assert bool(skipped) == bool(receipt['skipped'])
    return {'receipt': identity(directory / 'receipt.json'),
            'xml': identity(directory / 'tests.xml'), 'cases': len(cases),
            'failed': failed, 'skipped': skipped, 'names': names,
            'image': receipt['image']}


windows = {name: window(name) for name in ('matmul1', 'matmul2', 'matmul3', 'matmul4')}
assert windows['matmul3']['cases'] == 10 and not windows['matmul3']['failed']
assert windows['matmul4']['cases'] == 2 and not windows['matmul4']['failed']
assert len(windows['matmul2']['failed']) == 2
assert all(not w['skipped'] for w in windows.values())
final_names = set(windows['matmul3']['names'] + windows['matmul4']['names'])
inherited_names = {name for name in windows['matmul2']['names']
                   if name.startswith('CudaCcclGather.') or
                   (name.startswith('CublasProvider.') and
                    not name.endswith('BatchedBroadcastUsesBothOperandsAndRealSubalignment'))}
assert len(inherited_names) == 8
assert len(final_names | inherited_names) == 20

source_paths = [
    'src/compute_provider_cuda/collectives_provider.cc',
    'src/compute_provider_cuda/collectives.cu',
    'src/compute_provider_cublas/cublas_provider.cc',
    'include/hyle/compute/providers/cublas.h',
    'tests/compute_provider_cublas/cublas_provider_test.cc',
    'third_party/ggml_cuda_runtime/patches.json',
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'third_party/ggml_cuda_runtime/NOTICE.md',
    'cmake/HyleDependencyLock.json',
]
source_ids = [identity(ROOT / path) for path in source_paths]
frozen = read(N / 'source-freeze.json')
for item in frozen['product_sources']:
    assert identity(Path(item['path']))['sha256'] == item['sha256']
assert identity(Path(frozen['native_source']['path']))['sha256'] == frozen['native_expected_after_sha256']
lt_frozen = read(B / 'final-source-freeze.json')
for item in lt_frozen['sources']:
    assert identity(Path(item['path']))['sha256'] == item['sha256']

plan_path = N / 'checks/attempt1/link-plan.json'
plan = read(plan_path)
ptx = read(N / 'ptx-review.json')
assert ptx['BF16_kernel_count'] == 38
assert all(x['ftz_instruction_count'] == 0 for x in ptx['BF16_kernels'])
lock_update = read(N / 'dependency-lock-update.json')
assert lock_update['after']['version'].endswith('-v34')
assert lock_update['after']['vendored']['tree_sha256'] == 'f6a792055293aef612ff06fabfd47f195dabc35525a36e23fa67f61618e3e2a3'

audit = {
    'status': 'closed_for_this_cuda_scope',
    'scope': 'Ordinary CT BF16 block128/group128 graph CUDA seams; no custom CT replacement op.',
    'source_identities': source_ids,
    'mechanisms': [
        'Gather: full checked-ID kernel precedes bit-preserving output kernel on the original QueueSequence; cold kernel materialization and prepared replay; Scan/TopK unchanged. Empty output keeps the existing public no-op/no-ID-read contract.',
        'cuBLAS Lt: cold immutable strided-batch runs implement right-aligned broadcast with row/column-major input matrices, zero stride, real subalignment and reset boundaries; original rank2 single-run/per-Invocation handle/caller workspace retained.',
        'GGML CUDA BF16 binary: inline PTX add/sub/mul/div.rn.f32 without .ftz for single and fused BF16 lanes, BF16 RNE after every node. Original F32/F16 fast-math branches retained; temporary BF16 routing rejection removed.'
    ],
    'actual_builds_by_this_agent': {
        'gather': {'CXX': 2, 'NVCC': 1, 'links': 1},
        'cublas': {'CXX': 4, 'NVCC': 0, 'links': 3},
        'bfloat_binary': {'CXX': 1, 'NVCC': 1, 'links': 1},
        'total': {'CXX': 7, 'NVCC': 2, 'links': 5},
        'actual_compiler_failures': 0, 'SDK_rebuilds': 0, 'GPU_runs': 0,
        'boundary': 'Counts cover these three owned stages only. Root-owned shared wrapper/numeric diagnostics, GPU processes and other backends are not counted as this agent builds.'
    },
    'build_receipts': [identity(path) for path in (
        G / 'checks/attempt1/product-objects.json',
        G / 'checks/test-and-link/summary.json',
        B / 'checks/attempt1/summary.json',
        B / 'checks/cublas-neighbor/summary.json',
        B / 'checks/general-broadcast/summary.json',
        N / 'checks/attempt1/summary.json')],
    'actual_gpu_windows_owned_by_root': windows,
    'final_scope': {
        'cases_on_final_image': len(final_names),
        'final_image_names': sorted(final_names),
        'neighbor_cases_in_prior_actual_green_windows': sorted(inherited_names),
        'distinct_green_cases_across_relevant_windows': len(final_names | inherited_names),
        'skips': 0,
        'not_one_final_image_claim': 'Gather4 and original Lt4 inherit their actual matmul1/matmul2 green windows. The final native change affects ggml BF16 binary, not Gather bit copies or Lt.',
        'ct_fixture': {'successful_submissions': 23, 'expected_failed_completions': 2},
        'tiny_edge_successful_submissions': 6,
        'generic_broadcast': {'domains': 6, 'successful_submissions': 24},
        'channel_token_successful_submissions': 10,
        'routing': 'Final tiny edge report retains ggml BF16 Div/Add nodes and a multi-node region; no blanket native fallback used to sign the fix.',
        'unmatched_requested_filter_not_claimed': 'CudaDefaultGraph.TensorChainCapturesViewsConversionsMasksAndIndependentResults'
    },
    'retained_failures': {
        'capture_red': [identity(P / 'cuda/validation' / name / 'receipt.json')
                        for name in ('attempt1', 'attempt2')],
        'temporary_bf16_rejection_regression': windows['matmul2']['failed'],
        'planning_failures_not_compiler_failures': [identity(path) for path in (
            N / 'revisions/planner-attempt1.json',
            N / 'revisions/build-plan-attempt1.json')],
        'lock_sorting_first_rejection': identity(N / 'dependency-lock-update.json')
    },
    'final_link': {'plan': identity(plan_path), 'actual_input_count': len(plan['inputs']),
                   'test_objects_exactly_reused': plan['test_objects_exactly_reused'],
                   'final_image': windows['matmul3']['image']},
    'native_proof': {
        'source_freeze': identity(N / 'source-freeze.json'),
        'actual_header_closure': identity(N / 'native-source-closure.json'),
        'actual_PTX_review': identity(N / 'ptx-review.json'),
        'actual_PTX': identity(N / 'checks/attempt1/native-tmp/binbcast.ptx'),
        'BF16_kernels': 38, 'BF16_FTZ_instructions': 0,
        'independent_primary_review': identity(P / 'review-cuda-bfloat/primary-and-design.json'),
        'independent_source_review': identity(P / 'review-cuda-bfloat/final-source-review.json'),
        'shared_cache_mutated': False,
        'public_ABI_changed': False
    },
    'dependency_lock': {
        'receipt': identity(N / 'dependency-lock-update.json'),
        'version': lock_update['after']['version'],
        'vendored_normalized_tree': lock_update['after']['vendored']['tree_sha256'],
        'audit': 'Root executed cmake -P cuda-bfloat-binary/check-lock.cmake with exit0; not rerun by this summarizer.',
        'raw_manifest_hash_vs_normalized_tree': 'Raw source SHA and normalized vendored file/tree SHA use different hash definitions; keep their respective receipts.'
    },
    'limits': [
        'No performance claim or new timing/profile run.',
        'No full artifact payload, complete model inference, quality or full supported geometry claim.',
        'No Linux execution claim from these Windows CUDA tests.',
        'GPU outcomes are root actual XML/receipt evidence; this agent ran no GPU.'
    ]
}
write(N / 'final-audit.json', audit)

candidate_paths = []
for directory in (G / 'checks/test-and-link', B / 'checks/attempt1',
                  B / 'checks/cublas-neighbor', B / 'checks/general-broadcast'):
    for extension in ('exe', 'map', 'pdb', 'exp', 'lib'):
        path = directory / ('cuda.' + extension)
        if path.is_file():
            candidate_paths.append((path, 'Superseded linked image or linker sidecar; commands/inputs/results remain.'))
for extension in ('map', 'pdb', 'exp', 'lib'):
    path = N / 'checks/attempt1' / ('cuda.' + extension)
    if path.is_file():
        candidate_paths.append((path, 'Final linker sidecar only; archive needed identity/diagnostic before root cleanup.'))
for path in sorted((N / 'checks/attempt1/native-tmp').iterdir()):
    if path.is_file() and path.suffix != '.ptx':
        candidate_paths.append((path, 'NVCC --keep intermediate; actual PTX and native object remain.'))
cleanup = {'status': 'read_only_candidates_not_deleted',
           'execution_owner': 'Root must place exact deletion operations in repository test.ps1 and inspect targets before any cleanup.',
           'workspace_boundary': str(P.resolve()),
           'candidates': [],
           'protected': [str((N / 'checks/attempt1/cuda.exe').resolve()),
                         str((N / 'checks/attempt1/native-tmp/binbcast.ptx').resolve()),
                         'All .obj files, dependency/SDK caches, source snapshots, commands, inventories, logs, XML and receipt JSON.'],
           'performed_deletions': 0}
for path, reason in candidate_paths:
    resolved = path.resolve()
    assert resolved.is_relative_to(P.resolve())
    assert resolved.suffix not in ('.obj', '.ptx')
    cleanup['candidates'].append({'path': str(resolved),
                                  'bytes': resolved.stat().st_size,
                                  'reason': reason})
cleanup['candidate_count'] = len(cleanup['candidates'])
cleanup['candidate_bytes'] = sum(x['bytes'] for x in cleanup['candidates'])
write(N / 'cleanup-candidates.json', cleanup)
print(json.dumps({'audit': identity(N / 'final-audit.json'),
                  'cleanup': identity(N / 'cleanup-candidates.json'),
                  'cleanup_count': cleanup['candidate_count'],
                  'cleanup_bytes': cleanup['candidate_bytes'],
                  'distinct_green_cases': len(final_names | inherited_names)}, indent=2))
