"""BF16-only no-FTZ binbcast manifest patch and restore ordinary admission."""
import difflib
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = S.parents[3]
CACHE = Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
MANIFEST = ROOT / 'third_party/ggml_cuda_runtime/patches.json'
HOST = ROOT / 'src/compute_provider_ggml_cuda/tensor_program.cc'


def ident(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


def main():
    before_rows = []
    for p in [MANIFEST, HOST]:
        dest = S / 'before' / p.relative_to(ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            assert dest.read_bytes() == p.read_bytes(), 'Before must remain unchanged'
        else:
            dest.write_bytes(p.read_bytes())
        before_rows.append(ident(p))
    save(S / 'before.json', before_rows)
    manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
    entry = next(r for r in manifest['files'] if r['path'] == 'src/ggml-cuda/binbcast.cu')
    original = CACHE / entry['path']
    assert ident(original)['sha256'] == entry['before_sha256']
    before = original.read_text()
    for edit in entry['edits']:
        assert before.count(edit['before']) == 1
        before = before.replace(edit['before'], edit['after'])
    assert hashlib.sha256(before.encode()).hexdigest() == entry['after_sha256']
    old_edits = entry['edits']
    helper = '''// BF16 arithmetic uses IEEE RN instructions without .ftz, independently of
// this translation unit's fast-math setting for original F32/F16 kernels.
// Every public BF16 store/reload boundary remains explicit in fused chains.
template <float (*bin_op)(const float, const float)>
static __device__ __forceinline__ float bin_bcast_bf16_step(const float a, const float b) {
    float result;
#if !defined(GGML_USE_HIP) && !defined(GGML_USE_MUSA)
    if constexpr (bin_op == op_add) {
        asm volatile("add.rn.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    } else if constexpr (bin_op == op_sub) {
        asm volatile("sub.rn.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    } else if constexpr (bin_op == op_mul) {
        asm volatile("mul.rn.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    } else if constexpr (bin_op == op_div) {
        asm volatile("div.rn.f32 %0, %1, %2;" : "=f"(result) : "f"(a), "f"(b));
    } else {
        result = bin_op(a, b); // REPEAT retains its original value operation.
    }
#else
    result = bin_op(a, b);
#endif
    return __bfloat162float(__float2bfloat16_rn(result));
}

'''
    # The helper must appear after op_add/sub/mul/div declarations. Remove the
    # earlier helper insertion, which could only round already-flushed math.
    edits = [dict(e) for e in old_edits if e['before'] != 'template<typename T, size_t>\n']
    anchor = '''static __device__ __forceinline__ float op_div(const float a, const float b) {
    return a / b;
}
'''
    edits.insert(2, {'before': anchor, 'after': anchor + '\n' + helper})
    for edit in edits:
        if 'sizeof...(src1_ptrs) > 1' in edit['after']:
            edit['after'] = edit['after'].replace(' && sizeof...(src1_ptrs) > 1', '')
    for indent in ['            ', '        ']:
        old = indent + 'result = bin_op(result, (float)src1[i_src1 + size_t(i10)*s10]);\n'
        new = indent + '''if constexpr (std::is_same<dst_t, nv_bfloat16>::value) {
''' + indent + '''    result = bin_bcast_bf16_step<bin_op>(result, (float)src1[i_src1 + size_t(i10)*s10]);
''' + indent + '''} else {
''' + old.replace(indent, indent + '    ', 1) + indent + '}\n'
        edits.append({'before': '\n' + old, 'after': '\n' + new})
    after = original.read_text()
    for edit in edits:
        assert after.count(edit['before']) == 1, edit['before']
        after = after.replace(edit['before'], edit['after'])
    entry['edits'] = edits
    entry['after_sha256'] = hashlib.sha256(after.encode()).hexdigest()
    MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    overlay = S / 'native-source/src/ggml-cuda/binbcast.cu'
    overlay.parent.mkdir(parents=True, exist_ok=True)
    overlay.write_bytes(after.encode())
    old_native = S / 'before/native/binbcast.cu'
    old_native.parent.mkdir(parents=True, exist_ok=True)
    old_native.write_bytes(before.encode())
    raw = HOST.read_bytes()
    newline = '\r\n' if b'\r\n' in raw else '\n'
    text = raw.decode().replace('\r\n', '\n')
    rejected = '''  // The native ggml pointwise kernels use an F32 carrier with FTZ. A BF16
  // product/division can legitimately produce or consume an F32 subnormal
  // (e.g. a stored BF16 quantization scale). That carrier is not the declared
  // typed operation over its full domain; use the existing typed CUDA leaf.
  // Original F32 math and separate explicit fused operations keep their own
  // contracts. This applies to both leaf and region qualification.
  if (operation.get_if<Binary>() && output.data_type() == DataType::kBFloat16)
    return false;
'''
    assert text.count(rejected) == 1
    text = text.replace(rejected, '')
    HOST.write_bytes(text.replace('\n', newline).encode())
    diff = list(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='before/native/binbcast.cu', tofile='after/native/binbcast.cu'))
    for p in [MANIFEST, HOST]:
        before_path = S / 'before' / p.relative_to(ROOT)
        dest = S / 'after' / p.relative_to(ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(p.read_bytes())
        diff += list(difflib.unified_diff(before_path.read_text().splitlines(True), p.read_text().splitlines(True), fromfile='before/' + p.relative_to(ROOT).as_posix(), tofile='after/' + p.relative_to(ROOT).as_posix()))
    (S / 'implementation.diff').write_text(''.join(diff), encoding='utf-8')
    save(S / 'source-freeze.json', {'product_sources': [ident(MANIFEST), ident(HOST)], 'native_source': ident(overlay), 'upstream_original': ident(original), 'native_expected_after_sha256': entry['after_sha256'], 'shared_cache_mutated': False, 'public_ABI_changed': False})
    print(json.dumps({'native_after_sha256': entry['after_sha256'], 'manifest': ident(MANIFEST), 'host': ident(HOST)}))


if __name__ == '__main__':
    main()
