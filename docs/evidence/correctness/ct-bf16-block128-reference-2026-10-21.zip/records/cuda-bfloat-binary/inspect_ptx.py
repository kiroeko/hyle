"""Inspect PTX saved by the actual successful native compilation, no rerun."""
import hashlib
import json
from pathlib import Path
import re

S = Path(__file__).resolve().parent
OUT = S / 'checks/attempt1'


def ident(path):
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    path = OUT / 'native-tmp/binbcast.ptx'
    text = path.read_text(encoding='utf-8')
    entries = list(re.finditer(r'^\.entry\s+([^\s(]+)', text, re.M))
    bf16 = []
    other_ftz = 0
    for i, match in enumerate(entries):
        body = text[match.start():entries[i + 1].start() if i + 1 < len(entries) else len(text)]
        if '__nv_bfloat16' not in match[1]:
            other_ftz += len(re.findall(r'\b(?:add|sub|mul|div)\.[^\s]*ftz[^\s]*\.f32\b', body))
            continue
        op = next(name for name in ['repeat', 'add', 'sub', 'mul', 'div'] if 'op_' + name in match[1])
        strict = re.findall(r'\b(?:add|sub|mul|div)\.rn\.f32\b', body)
        assert '.ftz' not in body, match[1]
        if op != 'repeat':
            assert strict and all(instruction == op + '.rn.f32' for instruction in strict)
            assert 'cvt.rn.bf16.f32' in body
        bf16.append({'kernel': match[1], 'operation': op, 'strict_RN_instructions': len(strict), 'RNE_BF16_narrow_count': body.count('cvt.rn.bf16.f32'), 'ftz_instruction_count': 0})
    assert bf16 and other_ftz
    result = {'status': 'actual_compilation_PTX_inspected', 'ptx': ident(path), 'native_identity': ident(OUT / 'native-identity.json'), 'kernel_count': len(entries), 'BF16_kernel_count': len(bf16), 'BF16_kernels': bf16, 'BF16_ftz_instructions': 0, 'other_types_FTZ_arithmetic_instruction_count': other_ftz, 'no_extra_NVCC_or_GPU': True, 'scope': 'The original -use_fast_math remains enabled for this object; its F32/F16 arithmetic still emits FTZ. All emitted BF16 kernels use no-FTZ explicit RN arithmetic and BF16 RNE narrowing, including single-source/fused and normal/unravel forms. PTX inspection is not an additional numerical GPU test.'}
    (S / 'ptx-review.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'BF16_kernel_count': len(bf16), 'BF16_ftz_instructions': 0, 'other_types_FTZ_arithmetic_instruction_count': other_ftz, 'review': ident(S / 'ptx-review.json')}))


if __name__ == '__main__':
    main()
