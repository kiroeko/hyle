from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,shutil,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
A=S.parents[1]
F=A/'fixed-role-binding-2026-10-21/kimi/21'
spec=importlib.util.spec_from_file_location('ct_block_fixed_fetch',F.parent/'fetch.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
tree=json.loads((F/'ct-producer-tree.json').read_bytes())
commit=tree['sha'];assert commit=='1f3b63299961bec13861825d0823a502e875091d'
old=['src/compressed_tensors/quantization/lifecycle/forward_helpers.py',
     'src/compressed_tensors/quantization/utils/helpers.py',
     'src/compressed_tensors/compressors/naive_quantized/base.py']
new=['src/compressed_tensors/quantization/lifecycle/forward.py',
     'src/compressed_tensors/quantization/quant_args.py']
def one(name):
    dest=S/'producer'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    if not dest.exists():
        cached=F/'producer'/name
        if cached.exists():shutil.copyfile(cached,dest)
        else:h.fetch(f'https://raw.githubusercontent.com/vllm-project/compressed-tensors/{commit}/{name}',dest,256*1024)
    raw=dest.read_bytes();expected=next(x['sha'] for x in tree['tree'] if x['path']==name)
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==expected
    return dict(source=h.ident(dest),commit=commit,git_blob=expected,
        URL=f'https://github.com/vllm-project/compressed-tensors/blob/{commit}/{name}',
        cached=name in old)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(one,old+new))
h.save(S/'primary-source-identities.json',rows)
print(json.dumps(rows,indent=2))
