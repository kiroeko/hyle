"""Freeze a bounded source-only contract review; does not edit product files."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
FIXED = ROOT / '.scratch/architecture-refactor-2026-10-18/fixed-role-binding-2026-10-21/kimi/21'


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    producer = json.loads((HERE / 'primary-source-identities.json').read_text(encoding='utf-8'))
    for item in producer:
        item['source'] = identity(item['source']['path'])
    config = json.loads((FIXED / 'config.json').read_text(encoding='utf-8'))
    roles = []
    header_ids = []
    for shard in ['model-00001-of-000096.safetensors', 'model-00002-of-000096.safetensors']:
        hp = FIXED / 'headers' / shard / 'header.json'
        header_ids.append(identity(hp))
        h = json.loads(hp.read_text(encoding='utf-8'))
        keys = [k for k in h if ('.layers.0.mlp.' in k or '.layers.1.block_sparse_moe.experts.0.' in k) and k.endswith('.weight')]
        for key in keys:
            scale = key + '_scale'
            roles.append({'weight_name': key, 'weight': {k: h[key][k] for k in ['dtype', 'shape']}, 'scale_name': scale, 'scale': {k: h[scale][k] for k in ['dtype', 'shape']}, 'N_and_K_are_multiples_of_128': all(d % 128 == 0 for d in h[key]['shape'])})
    report = {
        'status': 'bounded_fixed_producer_contract_and_independent_scalar_review_complete',
        'scope': 'CT BF16 activation group128 QDQ plus E4M3 weight block128x128 BF16 dequantization; ordinary dense and selected-expert composition',
        'product_changed': False, 'build_or_GPU_run': False, 'model_tensor_payload_bytes_downloaded': 0,
        'artifact_execution_verified': False,
        'artifact': {'catalog_index': 21, 'repository': 'RedHatAI/Kimi-K3-FP8-BLOCK', 'revision': '6409c37cf440abeb76f0b44ab4fb7db8c8bccb4b', 'config': identity(FIXED / 'config.json'), 'root_quantization_config': config['quantization_config'], 'headers': header_ids, 'observed_roles': roles, 'role_limit': 'Two sampled shard headers, including layer0 dense and all 896 layer1 experts. Not a full 96-shard payload or full-artifact execution. Nested legacy MXFP4 config does not describe sampled physical CT weights.'},
        'producer': {'repository': 'vllm-project/compressed-tensors', 'commit': '1f3b63299961bec13861825d0823a502e875091d', 'version_in_artifact': '0.17.2.dev32+g1f3b632.d20260723', 'sources': producer, 'source_verification': 'All five snapshots match Git blob SHA1 from the fixed official repository tree; three copied from existing fixed-role evidence, only forward.py and quant_args.py newly fetched as small text.', 'torch_runtime_limit': 'Producer source is fixed. Original producer Torch build/device and deployed FP8 GEMM algorithm were not recovered; scalar witnesses describe the explicit typed operation tree, not bitwise proof of all deployment reducers.'},
        'activation_contract': {
            'ports': 'A BF16[...,K], K positive and divisible by128 for this package; contiguous logical groups along last dimension. No activation payload/global scale in checkpoint.',
            'reduction': 'Reshape [...,K/128,128]; independent BF16 amin/amax per group, include zero; max(abs(min),abs(max)). This equals absmax for finite data and propagates NaN under producer Torch reduction semantics.',
            'scale_tree': 'rawSA=RBF16(amax/448); SA=Select(rawSA==0, BF16(2^-7), rawSA). scale_dtype=null preserves BF16. Epsilon is a zero-only replacement, never max(rawSA,eps).',
            'zero_point': 'Dynamic symmetric calculate_qparams returns zero_point, not None. Default zp_dtype is E4M3FN, then +0 is converted back to BF16 for QDQ. Include explicit BF16 +0 after division and BF16 -0 after widening. A=-0 becomes +0 through the +0 boundary; a negative nonzero that quantizes to -0 can keep -0 after subtraction.',
            'QDQ_tree': 'd=RBF16(A/SA); shifted=RBF16(d+BF16(+0)); q=E4M3FN_RNE(clamp(shifted,-448,448)); u=RBF16(BF16(q)-BF16(+0)); AQDQ=RBF16(u*SA). Every low-dtype output boundary is part of this reference.',
            'range': 'E4M3FN finite +/-448, RNE ties-even. Clamp preserves NaN class. No F32-first quotient substitution. No code-dot or scaledFP8 native arithmetic claim.',
            'anchors': ['quantization/utils/helpers.py:50-137', 'quantization/utils/helpers.py:140-196', 'quantization/lifecycle/forward.py:292-330', 'quantization/lifecycle/forward_helpers.py:176-211', 'quantization/quant_args.py:403-412', 'quantization/quant_args.py:462-503']
        },
        'weight_contract': {
            'ports': 'W raw E4M3FN[N,K], SF BF16[N/128,K/128] for observed exact-multiple roles; symmetric checkpoint has no stored weight_zero_point or g_idx/global.',
            'formula': 'WDQ[n,k]=RBF16(BF16(E4decode(W[n,k])) * SF[n//128,k//128]). SF is two-dimensional block scale, not per-channel [N,1].',
            'ordinary_broadcast': 'W -> Cast BF16 -> View[NB,128,KB,128]; SF -> View[NB,1,KB,1]; BF16 Multiply; restore[N,K]. Equivalently producer transposes blocks to[NB,KB,128,128] and broadcasts SF[NB,KB,1,1].',
            'matmul': 'Original ordinary BF16 operand MatMul with F32 accumulation, BF16 final result. WDQ BF16 product must be rounded before dot. F32 accumulation reduction order is not pinned by exporter QDQ source, so sparse exact dots can isolate the storage arithmetic without declaring all GEMM trees identical.',
            'anchors': ['compressors/naive_quantized/base.py:35-44', 'compressors/naive_quantized/base.py:102-125', 'quantization/lifecycle/forward.py:77-146', 'quantization/lifecycle/forward_helpers.py:57-110', 'quantization/lifecycle/forward_helpers.py:246-268']
        },
        'domain_and_tails': {
            'finite_extremes': 'BF16 subnormals are legitimate source values. rawSA underflow-to-zero triggers eps; nonzero subnormal SA stays nonzero. Largest finite BF16 A may produce Inf at final BF16 dequant multiply. Do not reject or clamp that legal intermediate.',
            'nonfinite': 'No finite guard in producer QDQ/dequant. A NaN poisons its group SA; A Inf gives SA Inf; Inf/Inf and 0*Inf produce NaN. NaN payload/sign not specified. SF0/negative/Inf/NaN are not artificially rejected by naive W dequantizer. These are source semantics, not actual GPU verification in this review.',
            'activation_tail': 'compute_dynamic_scales_and_zp unflatten requires full groups. _process_group rejects K>=128 nonmultiple; K<128 also cannot unflatten ceil(K/128)*128. Empty forward returns before QDQ. Do not silently pad A or sign off short/tail groups.',
            'weight_explicit_args': 'With explicit block_structure=[128,128], _process_block pads both axes to ceil blocks and crops original shape after arithmetic.',
            'weight_default_decompress_caveat': 'Actual naive decompressor calls dequantize(args=None), which infers block_height=N//SFrows and block_width=K//SFcols. For N130,SFrows2 it infers65 instead of128; therefore nonmultiples cannot be claimed equivalent to explicit block128 from these sources. Actual sampled target roles are exact multiples.',
            'first_package_geometry': 'Dense N256/K256; selected grouped N128/K256, positive dimensions. No tail-N or short-K promise.',
            'anchors': ['quantization/lifecycle/forward.py:104-125', 'quantization/lifecycle/forward.py:304-305', 'quantization/lifecycle/forward_helpers.py:69-110', 'quantization/lifecycle/forward_helpers.py:129-151', 'quantization/utils/helpers.py:375-429']
        },
        'ordinary_graph_plan': {
            'dense': 'A BF16[M,K] -> grouped128 BF16 QDQ once/M; W rawE4[N,K] and SF BF16[NB,KB] -> exact 2D BF16 WDQ -> transpose view -> ordinary BF16 MatMul/F32 accumulate -> BF16 Y[M,N].',
            'selected_experts': 'CheckedGather raw W E4[E,N,K] and SF BF16[E,NB,KB] by IDs[T,S] first; cast/dequantize only selected[T,S,N,K], not the complete E*N*K float bank. SF row-block gather/view -> [...,N,KB,1], W view[...,N,KB,128] -> BF16 multiply. A QDQ once/T -> metadata[T,1,1,K] broadcast -> batched ordinary MatMul -> BF16[T,S,N]. Duplicate IDs must remain duplicates; all ID checks precede index-derived reads by the public checked Gather contract.',
            'memory': 'Raw code/SF bank stays immutable original storage. Selected temporary size depends T*S*N*K, not all E*N*K; A QDQ not duplicated per selected expert because no expert-specific IG in this artifact. Catalog/WeightSlots sub-bank resource bridge remains a separate task.',
            'minimum_validation': ['Independent BF16 quotient tie, zero-only eps, explicit +/-0 boundaries and 2D row/column128 scale boundary.', 'Publish AQDQ/WDQ pointwise probes to avoid final BF16 dot masking an incorrect intermediate.', 'Final-output-only dense and selected consumers with sparse exact F32 dots, repeated IDs, updates, two Invocation slots, retained old result.', 'Invalid IDs must fail without unsafe bank addressing; original code dtype Gather admission should be fixed naturally if missing, not replaced by full-bank Cast.'],
            'not_substitutes': ['Existing channel/token QDQ fixture', 'BlockQuantizationRoundtrip', 'Flash8/code-dot feasibility', 'ModelOpt static activation scale or native scaled_mm']
        },
        'existing_fixture_and_primitive_seams': {
            'channel_token_fixture': identity(ROOT / 'tests/compute_models/fp8_channel_token_qdq_fixture.h'),
            'reuse': 'Reuse ordinary BF16 arithmetic, Cast Bool zero-select, Select bit preservation, resource/slot lifetime helpers. Existing fixture reduces whole token last axis and uses weight SF[N,1], so it does not cover group128 or 2D weight blocks.',
            'zero_sign_limit': 'Existing channel fixture omits dynamic symmetric zero-point +0/-0 operations; its finite outputs do not sign off producer negative-zero bit identity.',
            'NaN_clamp_seam': {'status': 'confirmed_source_semantics_difference_if_BinaryMinMax_used_as_Torch_clamp', 'producer': 'torch.clamp NaN passes through; quant_args.py:483.', 'Hyle': ['src/compute_provider_cuda/tensor_kernel.cu:155-159 fminf/fmaxf', 'src/compute_route_apple/apple_tensor.cc:192-204 explicitly documents one-NaN fmin/fmax semantics'], 'minimal_plan': 'For finite reference domain min/max clamp is equivalent. To preserve NaN class use existing SATFINITE Cast E4 directly after BF16 +0 (same finite clamp/RNE plus NaN-preserving cast), or add an explicit ordinary NaN-preserving composition; do not change public Min/Max semantics or widen finite test claim to all IEEE.'}
        },
        'scalar_witnesses': identity(HERE / 'scalar-witnesses.json'),
        'scalar_witness_source': identity(HERE / 'scalar_witnesses.py'),
        'conclusions': ['A standard ordinary graph can represent the selected actual reference contract without a new custom model operation, executor, provider whitelist, or full floating expert bank.', 'The critical differences from channel/token are activation group128, BF16 division and +0/-0 boundaries, and weight 2D BF16 product before dot.', 'Kernel/whole artifact/quality/performance and arbitrary tails remain unverified; this research is not a backend execution claim.']
    }
    path = HERE / 'contract-review.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    freeze = {'status': 'source_only_review_frozen', 'report': identity(path), 'files': [identity(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name not in ['source-freeze.json'] and '__pycache__' not in p.parts]}
    (HERE / 'source-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'report': identity(path), 'freeze_files': len(freeze['files'])}))


if __name__ == '__main__':
    main()
