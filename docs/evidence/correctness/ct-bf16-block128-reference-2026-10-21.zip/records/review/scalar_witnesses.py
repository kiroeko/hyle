"""Independent exact-rational BF16/E4 scalar witnesses; no Hyle/Torch/GPU.

This checks the fixed producer's typed operation tree, not a deployment GEMM.
"""
import bisect
import hashlib
import json
import math
import struct
from fractions import Fraction as F
from pathlib import Path

HERE = Path(__file__).resolve().parent


def power2(e):
    return F(2 ** e) if e >= 0 else F(1, 2 ** -e)


def bf_value(b):
    sign, e, m = b >> 15, (b >> 7) & 255, b & 127
    if e == 255:
        return math.nan if m else (-math.inf if sign else math.inf)
    v = F(m) * power2(-133) if e == 0 else F(128 + m) * power2(e - 134)
    return -v if sign else v


BF = [bf_value(b) for b in range(0x7f80)]


def bf_round(v, negative_zero=False):
    if isinstance(v, float) and not math.isfinite(v):
        return 0x7fc0 if math.isnan(v) else (0xff80 if v < 0 else 0x7f80)
    v = F(v)
    sign = 0x8000 if v < 0 or (v == 0 and negative_zero) else 0
    v = abs(v)
    if v >= F(511) * power2(119):
        return sign | 0x7f80
    i = bisect.bisect_left(BF, v)
    if i >= len(BF):
        i -= 1
    elif i and BF[i] != v:
        lo, hi = v - BF[i - 1], BF[i] - v
        if lo < hi or (lo == hi and (i - 1) % 2 == 0):
            i -= 1
    return sign | i


def operation(a, b, kind):
    av, bv = bf_value(a), bf_value(b)
    if kind == "sub":
        return operation(a, b ^ 0x8000, "add")
    negative_zero = False
    if isinstance(av, F) and isinstance(bv, F):
        if kind == "add":
            v = av + bv
            negative_zero = a == 0x8000 and b == 0x8000
        elif kind == "mul":
            v = av * bv
            negative_zero = bool((a ^ b) & 0x8000)
        elif bv:
            v = av / bv
            negative_zero = bool((a ^ b) & 0x8000)
        else:
            v = math.nan if av == 0 else (-math.inf if ((a ^ b) & 0x8000) else math.inf)
    else:
        av, bv = float(av), float(bv)
        if kind == "add":
            v = av + bv
        elif kind == "mul":
            v = av * bv
        elif bv == 0:
            v = math.nan if av == 0 else math.copysign(math.inf, av * math.copysign(1, bv))
        else:
            v = av / bv
    return bf_round(v, negative_zero)


def e4_value(code):
    mag, sign = code & 127, bool(code & 128)
    if mag == 127:
        return math.nan
    e, m = mag >> 3, mag & 7
    v = F(m, 512) if e == 0 else F(8 + m, 8) * power2(e - 7)
    return -v if sign else v


E4 = [e4_value(b) for b in range(127)]


def e4_round(v, negative_zero=False):
    if isinstance(v, float) and math.isnan(v):
        return 0x7f
    sign = 128 if v < 0 or (v == 0 and negative_zero) else 0
    v = min(abs(v), F(448))
    i = bisect.bisect_left(E4, v)
    if i and E4[i] != v:
        lo, hi = v - E4[i - 1], E4[i] - v
        if lo < hi or (lo == hi and (i - 1) % 2 == 0):
            i -= 1
    return sign | i


def qdq(group):
    values = [bf_value(b) for b in group]
    amax = math.nan if any(isinstance(v, float) and math.isnan(v) for v in values) else max(abs(v) for v in values)
    raw_scale = bf_round(amax / 448)
    scale = bf_round(F(1, 128)) if (raw_scale & 0x7fff) == 0 else raw_scale
    result, codes = [], []
    for a in group:
        normalized = operation(a, scale, "div")
        shifted = operation(normalized, 0, "add")  # producer dynamic symmetric zp
        code = e4_round(bf_value(shifted), shifted == 0x8000)
        widened = bf_round(e4_value(code), code == 0x80)
        unshifted = operation(widened, 0, "sub")
        result.append(operation(unshifted, scale, "mul"))
        codes.append(code)
    return raw_scale, scale, codes, result


def hx(b):
    return f"0x{b:04x}"


def main():
    out = {"status": "independent_scalar_witnesses_passed", "method": "Python stdlib Fraction exact rational finite BF16/E4 RNE, explicit IEEE special classes; no Hyle, Torch, or GPU", "deployment_or_payload_verified": False, "witnesses": {}}
    w = out["witnesses"]
    raw, scale, codes, result = qdq([0, 0x8000] * 64)
    assert raw == 0 and scale == 0x3c00 and set(codes) == {0} and set(result) == {0}
    w["zero_and_negative_zero"] = {"raw_scale": hx(raw), "scale": hx(scale), "A_minus_zero_QDQ": hx(result[1]), "without_zp_add_input_minus_zero_would_remain": "0x8000"}
    tiny = bf_round(power2(-20))
    raw, scale, codes, result = qdq([tiny] + [0] * 127)
    assert 0 < bf_value(scale) < F(1, 128) and result[0] != 0
    w["zero_only_epsilon_not_floor"] = {"amax": hx(tiny), "SA": hx(scale), "AQDQ": hx(result[0]), "SA_less_than_epsilon": True}
    _, large_scale, _, _ = qdq([0x3f80] + [0] * 127)
    normalized_wrong = operation(tiny, large_scale, "div")
    wrong_code = e4_round(bf_value(normalized_wrong))
    assert wrong_code == 0 and codes[0] != 0
    w["group128_not_whole_token"] = {"group0_amax": "0x3f80", "group1_amax": hx(tiny), "group1_local_code": f"0x{codes[0]:02x}", "wrong_token_code": "0x00"}
    found = None
    for max_b in range(0x3f00, 0x4001):
        s = bf_round(bf_value(max_b) / 448)
        for a in range(0x3b80, max_b + 1):
            exact = bf_value(a) / bf_value(s)
            proper = e4_round(bf_value(bf_round(exact)))
            wrong = e4_round(exact)
            if proper != wrong:
                found = {"A": hx(a), "amax": hx(max_b), "SA": hx(s), "BF16_division": hx(bf_round(exact)), "proper_code": f"0x{proper:02x}", "wrong_F32_first_code": f"0x{wrong:02x}"}
                break
        if found:
            break
    assert found
    w["BF16_division_before_E4_rounding"] = found
    code, sf = 0x3a, 0x3f81
    exact = e4_value(code) * bf_value(sf)
    product = bf_round(exact)
    assert bf_value(product) != exact
    w["weight_product_BF16_boundary"] = {"E4_code": "0x3a", "SF": hx(sf), "exact_product": str(exact), "BF16_product": hx(product), "omitting_product_round_changes_operand": True}
    scales = [[0x3f80, 0x4000], [0x4080, 0x4100]]
    coordinates = [(0, 0), (127, 127), (127, 128), (128, 127), (128, 128), (255, 255)]
    probes = [{"n": n, "k": k, "SF": hx(scales[n // 128][k // 128])} for n, k in coordinates]
    assert [p["SF"] for p in probes] == ["0x3f80", "0x3f80", "0x4000", "0x4080", "0x4100", "0x4100"]
    w["two_dimensional_block_scale"] = probes
    w["nonmultiple_tail_counterexample"] = {"N": 130, "SF_rows": 2, "explicit_block_rows": 128, "inferred_block_rows": 65, "n65_explicit_scale_row": 0, "n65_inferred_scale_row": 1, "not_claimed_by_first_fixture": True}
    for label, bits in [("smallest_subnormal", 0x0001), ("nonzero_subnormal_scale", 0x0304), ("largest_finite", 0x7f7f), ("positive_inf", 0x7f80), ("nan", 0x7fc0)]:
        raw, s, c, r = qdq([bits] + [0] * 127)
        w[label] = {"input": hx(bits), "raw_SA": hx(raw), "SA": hx(s), "code0": f"0x{c[0]:02x}", "QDQ0": hx(r[0]), "QDQ_zero_lane": hx(r[1])}
    assert w["smallest_subnormal"]["raw_SA"] == "0x0000"
    assert w["positive_inf"]["QDQ0"] == "0x7fc0" and w["positive_inf"]["QDQ_zero_lane"] == "0x7fc0"
    out["source"] = {"path": Path(__file__).name, "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE / "scalar-witnesses.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": out["status"], "witness_count": len(w), "output": str(HERE / "scalar-witnesses.json")}))


if __name__ == "__main__":
    main()
