"""Current direct cuBLAS test owner, one CXX/link; no product/test edits/GPU."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[3]
A = S.parents[1]
OUT = S / 'checks/cublas-neighbor'
OUT.mkdir(parents=True, exist_ok=True)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    product = read(S / 'checks/attempt1/cublas-identity.json')
    baseline = S / 'checks/attempt1/link-plan.json'
    base = read(baseline)
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': product['command'][0]})
    env['VSLANG'] = '1033'
    tmp = OUT / 'tmp'
    tmp.mkdir(exist_ok=True)
    env['TEMP'] = env['TMP'] = str(tmp)
    source = ROOT / 'tests/compute_provider_cublas/cublas_provider_test.cc'
    target = ROOT / 'tests/compute_provider_cublas/CMakeLists.txt'
    snapshot = S / 'after/tests/compute_provider_cublas/cublas_provider_test.cc'
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(source.read_bytes())
    args, skip = [], False
    for arg in product['command']:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith('/fo') or arg.endswith('cublas_provider.cc') or arg == '/DHYLE_COMPUTE_PROVIDER_CUBLAS_BUILD':
            continue
        args.append(arg)
    gather = read(S / 'checks/attempt1/gather-test-identity.json')
    gtest = next(arg for arg in gather['command'] if arg.startswith('/external:I') and 'googletest' in arg)
    args += [gtest, '/external:W0', str(source), '/sourceDependencies', str(OUT / 'test-deps.json'), '/Fo' + str(OUT / 'test.obj')]
    save(OUT / 'owner-command-origin.json', {'status': 'new_current_owner_command', 'retained_compiler_flags_from_product': ident(S / 'checks/attempt1/cublas-identity.json'), 'current_target': ident(target), 'gtest_include_from': ident(S / 'checks/attempt1/gather-test-identity.json'), 'note': 'No retained historical direct-test command was located; this exact current MSVC command uses the existing compiler/flags and actual current CMake test dependencies. Not claimed to be a historical receipt.'})

    def run(name, command):
        row = {'command': command, 'cwd': str(ROOT), 'started': time.time(), 'GPU_run': False}
        save(OUT / (name + '-command.json'), row)
        with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
            p = subprocess.run(command, cwd=ROOT, env=env, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
        row.update(exit=p.returncode, finished=time.time())
        save(OUT / (name + '-result.json'), row)
        print(name, p.returncode, flush=True)
        if p.returncode:
            print((OUT / (name + '.stdout.log')).read_text(errors='replace')[-7000:])
            print((OUT / (name + '.stderr.log')).read_text(errors='replace')[-4000:])
            raise SystemExit(p.returncode)

    run('compile', args)
    obj = ident(OUT / 'test.obj')
    save(OUT / 'test-identity.json', {'command': args, 'source': ident(source), 'object': obj, 'dependencies': [ident(p) for p in dict.fromkeys(read(OUT / 'test-deps.json')['Data']['Includes'])]})
    args = [x for x in base['command'] if not x.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:'))]
    args.insert(1, obj['path'])
    inputs = [obj]
    for row in base['inputs']:
        assert ident(row['path']) == row
        inputs.append(row)
    image = OUT / 'cuda.exe'
    args += ['/OUT:' + str(image), '/PDB:' + str(OUT / 'cuda.pdb'), '/MAP:' + str(OUT / 'cuda.map')]
    save(OUT / 'link-plan.json', {'command': args, 'inputs': inputs, 'base': ident(baseline), 'new_test': obj, 'SDK_rebuild': False, 'GPU_run': False})
    run('link', args)
    save(OUT / 'summary.json', {'CXX': 1, 'links': 1, 'GPU_runs': 0, 'SDK_rebuilds': 0, 'image': ident(image), 'link_plan': ident(OUT / 'link-plan.json'), 'filters': ['CudaCtBlock128QdqGraph.*', 'CudaCcclGather.*', 'CublasProvider.Float32LayoutsAndChangedInputsMatchDoubleOracle:CublasProvider.HalfDecodeAndPrefillUseIndependentLanes:CublasProvider.Bfloat16DecodeAndPrefillUseIndependentLanes:CublasProvider.ColdMetadataFailuresRollBackAndReservedReplayDoesNotAllocate']})
    print('IMAGE_READY', image, flush=True)


if __name__ == '__main__':
    main()
