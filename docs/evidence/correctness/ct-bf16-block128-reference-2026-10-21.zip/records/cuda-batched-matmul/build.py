"""Build one cuBLAS product owner and current existing Gather tests, then link."""
import concurrent.futures
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
ROOT = S.parents[3]
A = S.parents[1]
OUT = S / 'checks/attempt1'
OUT.mkdir(parents=True, exist_ok=True)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    product_recipe = A / 'cuda-coarse-capture-tests/compute_provider_cublas--cublas_provider-identity.json'
    gather_recipe = A / 'admitted-queue-sequence/cuda/commands.json'
    old_product = read(product_recipe)
    gather = next(r['command'] for r in read(gather_recipe) if r['tag'] == 'checked-gather-tests-compile')
    baseline = S.parent / 'cuda-gather-capture/checks/test-and-link/link-plan.json'
    base = read(baseline)
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': old_product['command'][0]})
    env['VSLANG'] = '1033'
    tmp = OUT / 'tmp'
    tmp.mkdir(exist_ok=True)
    env['TEMP'] = env['TMP'] = str(tmp)
    source = ROOT / 'src/compute_provider_cublas/cublas_provider.cc'
    test_source = ROOT / 'tests/compute_provider_cuda/gather_collectives_test.cc'
    frozen = [ident(source), ident(test_source)]
    for p in [source, test_source]:
        dest = S / 'after' / p.relative_to(ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(p.read_bytes())
    before = S / 'before/src/compute_provider_cublas/cublas_provider.cc'
    (S / 'implementation.diff').write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True), source.read_text().splitlines(True), fromfile='before/src/compute_provider_cublas/cublas_provider.cc', tofile='after/src/compute_provider_cublas/cublas_provider.cc')), encoding='utf-8')
    save(S / 'source-freeze.json', {'sources': frozen, 'private_only': True, 'public_or_cross_TU_ABI_change': False})

    def run(name, args):
        row = {'command': args, 'cwd': str(ROOT), 'started': time.time(), 'GPU_run': False}
        save(OUT / (name + '-command.json'), row)
        with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
            p = subprocess.run(args, cwd=ROOT, env=env, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
        row.update(exit=p.returncode, finished=time.time())
        save(OUT / (name + '-result.json'), row)
        print(name, 'exit', p.returncode, flush=True)
        if p.returncode:
            print((OUT / (name + '.stdout.log')).read_text(errors='replace')[-6500:])
            print((OUT / (name + '.stderr.log')).read_text(errors='replace')[-4000:])
            raise RuntimeError(name + ' failed')

    def build(name, recipe, src, receipt):
        args, skip = [], False
        for arg in recipe:
            if skip:
                skip = False
                continue
            if arg.lower() == '/sourcedependencies':
                skip = True
                continue
            if arg.lower().startswith('/fo'):
                continue
            args.append(arg)
        obj, deps = OUT / (name + '.obj'), OUT / (name + '-deps.json')
        args += ['/sourceDependencies', str(deps), '/Fo' + str(obj)]
        run(name, args)
        record = {'command': args, 'source': ident(src), 'object': ident(obj), 'dependencies': [ident(p) for p in dict.fromkeys(read(deps)['Data']['Includes'])], 'recipe': ident(receipt)}
        save(OUT / (name + '-identity.json'), record)
        return record

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        p = pool.submit(build, 'cublas', old_product['command'], source, product_recipe)
        g = pool.submit(build, 'gather-test', gather, test_source, gather_recipe)
        product, test = p.result(), g.result()
    expected = {r['path'].lower(): r for r in base['inputs']}
    old = old_product['object']['path'].lower()
    args, inputs = [], []
    for arg in base['command']:
        low = arg.lower()
        if low.startswith(('/out:', '/pdb:', '/map:', '/implib:')):
            continue
        value = product['object']['path'] if low == old else arg
        args.append(value)
        if low in expected:
            actual = ident(value)
            if low != old:
                assert actual == expected[low], arg
            inputs.append(actual)
    args.insert(1, test['object']['path'])
    inputs.insert(0, test['object'])
    image = OUT / 'cuda.exe'
    args += ['/OUT:' + str(image), '/PDB:' + str(OUT / 'cuda.pdb'), '/MAP:' + str(OUT / 'cuda.map')]
    save(OUT / 'link-plan.json', {'command': args, 'inputs': inputs, 'baseline': ident(baseline), 'replaced': old_product['object'], 'new_gather_test': test['object'], 'SDK_rebuild': False, 'GPU_run': False})
    run('link', args)
    assert frozen == [ident(source), ident(test_source)]
    save(OUT / 'summary.json', {'CXX': 2, 'links': 1, 'failed_compile_attempts': 0, 'GPU_runs': 0, 'SDK_rebuilds': 0, 'image': ident(image), 'link_plan': ident(OUT / 'link-plan.json'), 'new_filter': 'CudaCtBlock128QdqGraph.*', 'gather_filter': 'CudaCcclGather.*'})
    print('IMAGE_READY', image, flush=True)


if __name__ == '__main__':
    main()
