"""Apply the owned, single-TU cuBLAS batch extension to its saved before."""
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = S.parents[3]
P = ROOT / 'src/compute_provider_cublas/cublas_provider.cc'
raw = (S / 'before/src/compute_provider_cublas/cublas_provider.cc').read_bytes()
newline = '\r\n' if b'\r\n' in raw else '\n'
text = raw.decode().replace('\r\n', '\n')
text = text.replace('#include <array>', '#include <algorithm>\n#include <array>')
text = text.replace('#include <new>', '#include <new>\n#include <numeric>')
text = text.replace('#include "provider_internal.h"', '#include "provider_internal.h"\n#include "hyle/container/small_vector.h"')
start, end = text.index('struct CublasPrepared final'), text.index('struct CublasInvocation final')
text = text[:start] + '''struct CublasRun final {
  std::array<cublasLtMatrixLayout_t, 3> layouts{};
  cublasLtMatmulAlgo_t algorithm{};
  std::array<std::size_t, 3> offsets{};
  std::array<std::size_t, 3> byte_strides{};
  std::int32_t batch_count = 1;
};

struct CublasPrepared final {
  CUcontext primary = nullptr;
  cublasLtMatmulDesc_t operation = nullptr;
  container::SmallVector<CublasRun, 1, mem::AllocatorRef> runs;
  std::size_t workspace_bytes = 0;
  CublasPrepared(CUcontext context, mem::AllocatorRef allocator) noexcept
      : primary(context), runs(allocator) {}
};

''' + text[end:]
text = text.replace('description.rank() != 2 ||', 'description.rank() < 2 ||')
text = text.replace('cuBLAS requires plain rank-2 FP16/BF16/FP32', 'cuBLAS requires plain matrix FP16/BF16/FP32')
text = text.replace('const auto dimensions = description.dimensions();', 'const auto dimensions = description.dimensions().last(2);')
text = text.replace('const auto strides = description.byte_strides();', 'const auto strides = description.byte_strides().last(2);')
start, end = text.index('Status select_layouts('), text.index('constexpr ProviderRuntimeProperties')
text = text[:start] + '''struct BatchGeometry final {
  std::array<MatrixLayout, 3> matrices{};
  std::array<std::size_t, kMaxTensorRank - 2> dimensions{};
  std::array<std::array<std::size_t, kMaxTensorRank - 2>, 3> strides{};
  std::size_t rank = 0;
  std::size_t count = 1;
  std::size_t element_bytes = 0;
};

Status select_layouts(Operation operation, std::span<const TensorDesc> inputs,
                      std::span<const TensorDesc> outputs,
                      BatchGeometry &geometry) noexcept {
  if (operation.kind() != OperationKind::kMatMul || inputs.size() != 2 ||
      outputs.size() != 1)
    return Status::Unimplemented("cuBLAS provider implements MatMul only");
  if (operation.get_if<MatMul>()->accumulation_type != DataType::kFloat32)
    return Status::Unimplemented("cuBLAS requires FP32 accumulation");
  auto &layouts = geometry.matrices;
  HYLE_RETURN_IF_ERROR(matrix_layout(inputs[0], layouts[0]));
  HYLE_RETURN_IF_ERROR(matrix_layout(inputs[1], layouts[1]));
  HYLE_RETURN_IF_ERROR(matrix_layout(outputs[0], layouts[2]));
  if (inputs[0].data_type() != inputs[1].data_type() ||
      inputs[0].data_type() != outputs[0].data_type())
    return Status::Unimplemented("cuBLAS requires matching matrix data types");
  if (layouts[0].columns != layouts[1].rows ||
      layouts[2].rows != layouts[0].rows ||
      layouts[2].columns != layouts[1].columns)
    return Status::InvalidArgument("cuBLAS MatMul shapes do not agree");
  std::array<TensorDesc, 1> inferred;
  HYLE_RETURN_IF_ERROR(infer_output_descriptions(operation, inputs, inferred));
  if (!std::ranges::equal(inferred[0].dimensions(), outputs[0].dimensions()))
    return Status::InvalidArgument("cuBLAS MatMul batch shapes do not agree");
  geometry.rank = outputs[0].rank() - 2;
  geometry.element_bytes = data_type_size(inputs[0].data_type());
  const std::array descriptions{inputs[0], inputs[1], outputs[0]};
  for (std::size_t axis = 0; axis < geometry.rank; ++axis) {
    const auto extent = outputs[0].dimensions()[axis];
    if (extent <= 0)
      return Status::Unimplemented("cuBLAS requires positive batch extents");
    const auto size = static_cast<std::size_t>(extent);
    if (geometry.count > SIZE_MAX / size)
      return Status::OutOfRange("cuBLAS batch count overflows");
    geometry.dimensions[axis] = size;
    geometry.count *= size;
    for (std::size_t port = 0; port < descriptions.size(); ++port) {
      const auto &description = descriptions[port];
      const auto batch_rank = description.rank() - 2;
      if (axis + batch_rank < geometry.rank)
        continue;
      const auto source_axis = axis + batch_rank - geometry.rank;
      if (description.dimensions()[source_axis] == 1)
        continue;
      const auto signed_stride = description.byte_strides()[source_axis];
      if (signed_stride < 0)
        return Status::Unimplemented("cuBLAS requires nonnegative batch strides");
      const auto stride = static_cast<std::size_t>(signed_stride);
      if (stride % geometry.element_bytes != 0)
        return Status::Unimplemented(
            "cuBLAS batch strides require whole storage elements");
      geometry.strides[port][axis] = stride;
    }
  }
  for (std::size_t port = 0; port < descriptions.size(); ++port) {
    const auto &layout = layouts[port];
    const auto major = layout.order == CUBLASLT_ORDER_ROW ? layout.rows
                                                         : layout.columns;
    const auto minor = layout.order == CUBLASLT_ORDER_ROW ? layout.columns
                                                         : layout.rows;
    const auto leading = static_cast<std::size_t>(layout.leading);
    if (major - 1 > (SIZE_MAX / geometry.element_bytes - minor) / leading)
      return Status::OutOfRange("cuBLAS matrix storage span overflows");
    const auto matrix_bytes =
        ((major - 1) * leading + minor) * geometry.element_bytes;
    std::size_t last = matrix_bytes;
    for (std::size_t axis = 0; axis < geometry.rank; ++axis) {
      const auto repeats = geometry.dimensions[axis] - 1;
      const auto stride = geometry.strides[port][axis];
      if (repeats != 0 && stride > (SIZE_MAX - last) / repeats)
        return Status::OutOfRange("cuBLAS batch storage span overflows");
      last += repeats * stride;
    }
    const auto available = descriptions[port].required_bytes();
    if (!available || last > *available)
      return Status::InvalidArgument("cuBLAS batch storage exceeds its tensor");
    if (port != 2)
      continue;
    // Output matrices must not overlap. Sorting physical batch strides admits
    // an outer permutation without assuming logical order is physical order.
    std::array<std::size_t, kMaxTensorRank - 2> axes{};
    for (std::size_t axis = 0; axis < geometry.rank; ++axis)
      axes[axis] = axis;
    std::sort(axes.begin(), axes.begin() + geometry.rank,
              [&](std::size_t a, std::size_t b) {
                return geometry.strides[port][a] < geometry.strides[port][b];
              });
    auto occupied = matrix_bytes;
    for (std::size_t i = 0; i < geometry.rank; ++i) {
      const auto axis = axes[i];
      if (geometry.dimensions[axis] == 1)
        continue;
      const auto stride = geometry.strides[port][axis];
      if (stride < occupied)
        return Status::Unimplemented("cuBLAS output batches must not overlap");
      occupied += (geometry.dimensions[axis] - 1) * stride;
    }
  }
  return Status::Ok();
}

Status create_runs(CublasPrepared &prepared,
                    const BatchGeometry &geometry) noexcept {
  // Merge the maximal common affine suffix. Broadcast is exactly stride0;
  // an outer-axis reset is a cold run boundary, never a hot pointer upload.
  std::size_t first = geometry.rank, inner_count = 1;
  std::array<std::size_t, 3> steps{};
  bool active = false;
  for (auto axis = geometry.rank; axis-- > 0;) {
    const auto extent = geometry.dimensions[axis];
    if (extent == 1) {
      first = axis;
      continue;
    }
    if (active) {
      bool continuous = true;
      for (std::size_t port = 0; port < steps.size(); ++port)
        if (steps[port] > SIZE_MAX / inner_count ||
            geometry.strides[port][axis] != steps[port] * inner_count)
          continuous = false;
      if (!continuous)
        break;
    } else {
      for (std::size_t port = 0; port < steps.size(); ++port)
        steps[port] = geometry.strides[port][axis];
      active = true;
    }
    inner_count *= extent;
    first = axis;
  }
  const auto outer_count = geometry.count / inner_count;
  for (std::size_t outer = 0; outer < outer_count; ++outer) {
    std::array<std::size_t, 3> offsets{};
    auto coordinate = outer;
    for (auto axis = first; axis-- > 0;) {
      const auto digit = coordinate % geometry.dimensions[axis];
      coordinate /= geometry.dimensions[axis];
      for (std::size_t port = 0; port < offsets.size(); ++port)
        offsets[port] += digit * geometry.strides[port][axis];
    }
    for (std::size_t begin = 0; begin < inner_count;) {
      const auto count = std::min(inner_count - begin,
                                  static_cast<std::size_t>(INT32_MAX));
      if (!prepared.runs.try_emplace_back())
        return Status::ResourceExhausted("cuBLAS batch run allocation failed");
      auto &run = prepared.runs.back();
      run.batch_count = static_cast<std::int32_t>(count);
      run.byte_strides = steps;
      for (std::size_t port = 0; port < offsets.size(); ++port)
        run.offsets[port] = offsets[port] + begin * steps[port];
      begin += count;
    }
  }
  return Status::Ok();
}

''' + text[end:]
text = text.replace('std::array<MatrixLayout, 3> layouts{};', 'BatchGeometry geometry;')
text = text.replace('request.outputs, layouts)', 'request.outputs, geometry)')
text = text.replace('''  for (auto layout : prepared->layouts) {
    if (layout != nullptr)
      (void)cublasLtMatrixLayoutDestroy(layout);
  }''', '''  for (const auto &run : prepared->runs)
    for (auto layout : run.layouts)
      if (layout != nullptr)
        (void)cublasLtMatrixLayoutDestroy(layout);''')
start, end = text.index('Status configure(CublasPrepared'), text.index('Status create_invocation(')
text = text[:start] + '''Status configure_run(CublasPrepared &prepared, CublasRun &run,
                      const BatchGeometry &geometry, cudaDataType_t data_type,
                      ColdHandle &cold) noexcept {
  const auto &layouts = geometry.matrices;
  for (std::size_t index = 0; index < layouts.size(); ++index) {
    const auto &layout = layouts[index];
    HYLE_RETURN_IF_ERROR(translate(
        cublasLtMatrixLayoutCreate(&run.layouts[index], data_type,
                                   layout.rows, layout.columns, layout.leading),
        "cublasLtMatrixLayoutCreate"));
    HYLE_RETURN_IF_ERROR(translate(
        cublasLtMatrixLayoutSetAttribute(run.layouts[index],
                                         CUBLASLT_MATRIX_LAYOUT_ORDER,
                                         &layout.order, sizeof(layout.order)),
        "cublasLtMatrixLayoutSetAttribute(order)"));
    if (run.batch_count > 1) {
      const auto stride = static_cast<std::int64_t>(
          run.byte_strides[index] / geometry.element_bytes);
      HYLE_RETURN_IF_ERROR(translate(
          cublasLtMatrixLayoutSetAttribute(run.layouts[index],
              CUBLASLT_MATRIX_LAYOUT_BATCH_COUNT, &run.batch_count,
              sizeof(run.batch_count)),
          "cublasLtMatrixLayoutSetAttribute(batch_count)"));
      HYLE_RETURN_IF_ERROR(translate(
          cublasLtMatrixLayoutSetAttribute(run.layouts[index],
              CUBLASLT_MATRIX_LAYOUT_STRIDED_BATCH_OFFSET, &stride,
              sizeof(stride)),
          "cublasLtMatrixLayoutSetAttribute(batch_stride)"));
    }
  }
  const std::array attributes{CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_A_BYTES,
                             CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_B_BYTES,
                             CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_C_BYTES,
                             CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_D_BYTES};
  for (std::size_t index = 0; index < attributes.size(); ++index) {
    const auto port = std::min(index, std::size_t{2});
    auto alignment = std::gcd(kTensorAlignment, run.offsets[port]);
    if (run.batch_count > 1)
      alignment = std::gcd(alignment, run.byte_strides[port]);
    const auto qualified_alignment = static_cast<std::uint32_t>(alignment);
    HYLE_RETURN_IF_ERROR(translate(
        cublasLtMatmulPreferenceSetAttribute(cold.preference, attributes[index],
            &qualified_alignment, sizeof(qualified_alignment)),
        "cublasLtMatmulPreferenceSetAttribute(alignment)"));
  }
  cublasLtMatmulHeuristicResult_t result{};
  int count = 0;
  HYLE_RETURN_IF_ERROR(translate(
      cublasLtMatmulAlgoGetHeuristic(cold.handle, prepared.operation,
                                     run.layouts[0], run.layouts[1],
                                     run.layouts[2], run.layouts[2],
                                     cold.preference, 1, &result, &count),
      "cublasLtMatmulAlgoGetHeuristic"));
  if (count != 1)
    return Status::Unimplemented("cuBLAS found no algorithm for these layouts");
  HYLE_RETURN_IF_ERROR(translate(result.state, "cuBLAS selected algorithm"));
  run.algorithm = result.algo;
  prepared.workspace_bytes =
      std::max(prepared.workspace_bytes, result.workspaceSize);
  return Status::Ok();
}

Status configure(CublasPrepared &prepared, DataType type,
                 const BatchGeometry &geometry) noexcept {
  cuda::detail::ScopedPrimaryContext scope(prepared.primary);
  HYLE_RETURN_IF_ERROR(scope.status());
  ColdHandle cold;
  HYLE_RETURN_IF_ERROR(
      translate(cublasLtCreate(&cold.handle), "cublasLtCreate"));
  const cudaDataType_t data_type =
      type == DataType::kFloat16
          ? CUDA_R_16F
          : (type == DataType::kBFloat16 ? CUDA_R_16BF : CUDA_R_32F);
  const cublasComputeType_t compute_type = type == DataType::kFloat32
                                               ? CUBLAS_COMPUTE_32F_PEDANTIC
                                               : CUBLAS_COMPUTE_32F;
  HYLE_RETURN_IF_ERROR(translate(
      cublasLtMatmulDescCreate(&prepared.operation, compute_type, CUDA_R_32F),
      "cublasLtMatmulDescCreate"));
  HYLE_RETURN_IF_ERROR(create_runs(prepared, geometry));
  HYLE_RETURN_IF_ERROR(
      translate(cublasLtMatmulPreferenceCreate(&cold.preference),
                "cublasLtMatmulPreferenceCreate"));
  HYLE_RETURN_IF_ERROR(translate(
      cublasLtMatmulPreferenceSetAttribute(
          cold.preference, CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,
          &kMaximumWorkspaceBytes, sizeof(kMaximumWorkspaceBytes)),
      "cublasLtMatmulPreferenceSetAttribute(workspace)"));
  if (type != DataType::kFloat32) {
    // Split-K retains F32 partial sums, as in the original rank-2 path.
    const std::uint32_t reduction = CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE;
    HYLE_RETURN_IF_ERROR(translate(
        cublasLtMatmulPreferenceSetAttribute(
            cold.preference, CUBLASLT_MATMUL_PREF_REDUCTION_SCHEME_MASK,
            &reduction, sizeof(reduction)),
        "cublasLtMatmulPreferenceSetAttribute(reduction)"));
  }
  for (auto &run : prepared.runs)
    HYLE_RETURN_IF_ERROR(configure_run(prepared, run, geometry, data_type, cold));
  return Status::Ok();
}

''' + text[end:]
start, end = text.index('  const cublasStatus_t result = cublasLtMatmul('), text.index('\nAliasSupport alias_support(')
text = text[:start] + '''  for (const auto &run : prepared.runs) {
    const auto *a = static_cast<const char *>(*left) + run.offsets[0];
    const auto *b = static_cast<const char *>(*right) + run.offsets[1];
    auto *c = static_cast<char *>(*output) + run.offsets[2];
    const auto result = cublasLtMatmul(
        invocation.handle, prepared.operation, &alpha, a, run.layouts[0],
        b, run.layouts[1], &beta, c, run.layouts[2], c, run.layouts[2],
        &run.algorithm, invocation.workspace, prepared.workspace_bytes, *stream);
    // Even a first vendor error may have enqueued work: preserve the real
    // accepted prefix and the original Invocation handle/workspace lifetime.
    if (result != CUBLAS_STATUS_SUCCESS)
      return detail::EnqueueResult::accepted_command(
          translate(result, "cublasLtMatmul"));
  }
  return detail::EnqueueResult::accepted_command(Status::Ok());
}
''' + text[end:]
text = text.replace('''  auto *prepared = ::new (storage) CublasPrepared{
      .primary = static_cast<CublasContext *>(context_value)->primary};
  status = configure(*prepared, request.inputs[0].data_type(), layouts);''', '''  auto *prepared = ::new (storage) CublasPrepared(
      static_cast<CublasContext *>(context_value)->primary, allocator);
  status = configure(*prepared, request.inputs[0].data_type(), geometry);''')
assert 'prepared.layouts' not in text and 'prepared->layouts' not in text
P.write_bytes(text.replace('\n', newline).encode())
print(P)
