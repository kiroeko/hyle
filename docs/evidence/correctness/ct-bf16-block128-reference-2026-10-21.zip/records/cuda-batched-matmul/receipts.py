"""Summarize source/compile facts; execution remains owned by root."""
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = S.parents[3]


def ident(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    record = {
        'status': 'source_implemented_and_incremental_compile_link_passed_actual_GPU_owned_by_root',
        'product_source': ident(ROOT / 'src/compute_provider_cublas/cublas_provider.cc'),
        'source_freeze': ident(S / 'source-freeze.json'),
        'diff': ident(S / 'implementation.diff'),
        'geometry': {'domain': 'Matching plain F16/BF16/F32, positive M/N/K and batch extents, exact ordinary MatMul broadcast shape, F32 accumulation. Last two axes keep the existing row/column-major and leading-dimension bounds.',
                     'batch_strides': 'Right-aligned broadcast axes have effective byte stride0. Non-singleton batch byte strides must be whole datatype elements, as required by Lt strided-batch offsets. Inputs may overlap read-only. Output matrix spans and physically sorted outer strides must be nonoverlapping.',
                     'bounds': 'Checked batch-count multiplication and matrix span+all batch-offset additions, then <=TensorDesc.required_bytes. INT32_MAX per-run count is the SDK field limit, split cold, with no model/shape/provider whitelist.',
                     'runs': 'Maximal suffix with common affine offset steps for all three ports becomes one Lt strided-batch run; broadcasting resets split cold. Prefix coordinates are decoded only cold. No O(all_batches) offset array for the common affine case, no device pointer array, no hot upload/copy.',
                     'exact_CT_shape': '[T,1,1,K]@[T,S,K,N] -> [T,S,1,N]: T fixed runs with batch_count S; A stride0 within each run, A advances by a row between runs.'},
        'rank2_preserved': 'Inline SmallVector capacity1; one run count1, offsets0, same row/column layouts, no batch attributes, original compute type/reduction preference/maxworkspace/alignment16/heuristic count1. Same per-Invocation handle and caller workspace. No new routing or mathematical operation.',
        'alignment': 'Base port requirement remains16. Per-run algorithm minimum A/B/C/D alignment is gcd(16,start_offset,step_if_count>1), so offsets/strides not divisible by16 cannot silently retain the old alignment promise.',
        'lifetime_and_failures': 'Prepared owns all nullable per-run layouts and immutable algorithms; partial configure or metadata failure destroys every created layout and operation. Invocation still owns one vendor handle and caller workspace. Sequential runs share max required workspace. First vendor failure returns accepted_command to preserve any true queued prefix.',
        'capture_and_hot_path': 'Original capture-compatible runtime unchanged. Hot path only validates original native pointers/context/stream, traverses immutable runs and calls Lt; no metadata/payload allocation, mutable descriptor, dynamic provider choice, pointer upload or host wait.',
        'cost_scope': 'dispatch_count remains unknown because one Lt call need not mean one GPU dispatch. Vendor-private persistent bytes remain unknown as before. Cold metadata and heuristic work grow with true broadcast-reset run count; no arbitrary admission cap added.',
        'public_header_comment': ident(S / 'public-comment-only-reuse.json'),
        'final_source_freeze': ident(S / 'final-source-freeze.json'),
        'new_general_test': {'source': ident(ROOT / 'tests/compute_provider_cublas/cublas_provider_test.cc'), 'case': 'CublasProvider.BatchedBroadcastUsesBothOperandsAndRealSubalignment', 'domains': 6, 'submissions_expected': 24, 'math': 'Two complementary right-aligned broadcast shapes, both input row/column storage orientations, real non16-byte batch offsets/strides. Small quarter/half operands and three-term dots admit exact scalar comparisons without tolerance. Ordinary inferred dense outputs; explicit column output is not exposed by the current public output-inference contract.'},
        'builds': {'CXX': 4, 'links': 3, 'NVCC': 0, 'failed_compile_attempts': 0, 'SDK_rebuilds': 0, 'GPU_runs_by_this_agent': 0,
                   'owners': ['src/compute_provider_cublas/cublas_provider.cc', 'tests/compute_provider_cuda/gather_collectives_test.cc', 'tests/compute_provider_cublas/cublas_provider_test.cc'],
                   'first_summary': ident(S / 'checks/attempt1/summary.json'), 'final_summary': ident(S / 'checks/general-broadcast/summary.json'),
                   'current_image_link': ident(S / 'checks/general-broadcast/link-plan.json'), 'direct_test_command_origin': ident(S / 'checks/cublas-neighbor/owner-command-origin.json')},
        'root_observations_before_new_general_test': {'CT3_Gather4_rank2_4': ident(S.parent / 'cuda/validation/matmul1/receipt.json'), 'numeric_edge': ident(S.parent / 'cuda/validation/edges3/receipt.json')},
        'verification_limits': 'No GPU execution by this agent. Root prior window actually passed CT3+Gather4+oldrank2_4=11 cases, then fixed BF16 numeric edge1. New general F16/F32/BF16 batched six domains remain unverified until root executes current final image. No performance or full artifact claim.'
    }
    peer = S / 'independent-review.json'
    if peer.exists():
        record['independent_review'] = ident(peer)
    path = S / 'source-audit.json'
    path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(ident(path)))


if __name__ == '__main__':
    main()
