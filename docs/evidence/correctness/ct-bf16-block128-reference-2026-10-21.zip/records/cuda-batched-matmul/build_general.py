"""Final one-test-owner refresh + one link, adding root's numeric/edge objects."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
ROOT = S.parents[3]
OUT = S / 'checks/general-broadcast'
OUT.mkdir(parents=True, exist_ok=True)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def ident(path):
    p = Path(path).resolve()
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    old_test_path = S / 'checks/cublas-neighbor/test-identity.json'
    old_test = read(old_test_path)
    baseline = S / 'checks/cublas-neighbor/link-plan.json'
    base = read(baseline)
    numeric_path = P / 'cuda-numeric/attempt1/identity.json'
    edge_path = P / 'cuda/checks/edges2/test-identity.json'
    numeric, edge = read(numeric_path), read(edge_path)
    for record in [numeric, edge]:
        assert ident(record['source']['path']) == record['source']
        assert ident(record['object']['path']) == record['object']
    source = ROOT / 'tests/compute_provider_cublas/cublas_provider_test.cc'
    public = ROOT / 'include/hyle/compute/providers/cublas.h'
    before_public = S / 'before/include/hyle/compute/providers/cublas.h'
    strip = lambda t: re.sub(r'\s+', '', re.sub(r'//[^\n]*', '', t))
    assert strip(public.read_text()) == strip(before_public.read_text())
    product = read(S / 'checks/attempt1/cublas-identity.json')
    original_header_dep = next(r for r in product['dependencies'] if r['path'].lower() == str(public).lower())
    assert original_header_dep['sha256'] == ident(before_public)['sha256']
    save(S / 'public-comment-only-reuse.json', {'before': ident(before_public), 'after': ident(public), 'token_text_equal_after_line_comments_and_whitespace_removed': True, 'original_product_dependency': original_header_dep, 'product_object': product['object'], 'product_recompiled_for_comment': False})
    diff = []
    for p in [source, public]:
        after = S / 'after' / p.relative_to(ROOT)
        after.parent.mkdir(parents=True, exist_ok=True)
        after.write_bytes(p.read_bytes())
        before = S / 'before' / p.relative_to(ROOT)
        diff.extend(difflib.unified_diff(before.read_text().splitlines(True), p.read_text().splitlines(True), fromfile='before/' + p.relative_to(ROOT).as_posix(), tofile='after/' + p.relative_to(ROOT).as_posix()))
    (S / 'test-and-comment.diff').write_text(''.join(diff), encoding='utf-8')
    frozen = [ident(ROOT / 'src/compute_provider_cublas/cublas_provider.cc'), ident(source), ident(public)]
    save(S / 'final-source-freeze.json', {'sources': frozen, 'product_ABI_changed': False, 'public_header_comment_only': True})
    sys.path.insert(0, str(ROOT / 'scripts'))
    from hyle_environment import windows_compiler_environment
    env = windows_compiler_environment({'CMAKE_CXX_COMPILER': old_test['command'][0]})
    env['VSLANG'] = '1033'
    tmp = OUT / 'tmp'
    tmp.mkdir(exist_ok=True)
    env['TEMP'] = env['TMP'] = str(tmp)

    def run(name, args):
        row = {'command': args, 'cwd': str(ROOT), 'started': time.time(), 'GPU_run': False}
        save(OUT / (name + '-command.json'), row)
        with (OUT / (name + '.stdout.log')).open('wb') as so, (OUT / (name + '.stderr.log')).open('wb') as se:
            p = subprocess.run(args, cwd=ROOT, env=env, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
        row.update(exit=p.returncode, finished=time.time())
        save(OUT / (name + '-result.json'), row)
        print(name, p.returncode, flush=True)
        if p.returncode:
            print((OUT / (name + '.stdout.log')).read_text(errors='replace')[-8000:])
            print((OUT / (name + '.stderr.log')).read_text(errors='replace')[-4000:])
            raise SystemExit(p.returncode)

    args, skip = [], False
    for arg in old_test['command']:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith('/fo'):
            continue
        args.append(arg)
    obj = OUT / 'test.obj'
    deps = OUT / 'test-deps.json'
    args += ['/sourceDependencies', str(deps), '/Fo' + str(obj)]
    run('compile', args)
    test = {'command': args, 'source': ident(source), 'object': ident(obj), 'dependencies': [ident(p) for p in dict.fromkeys(read(deps)['Data']['Includes'])], 'base_recipe': ident(old_test_path)}
    save(OUT / 'test-identity.json', test)
    replacements = {old_test['object']['path'].lower(): test['object'], numeric['old_object']['path'].lower(): numeric['object']}
    args, inputs = [], []
    expected = {r['path'].lower(): r for r in base['inputs']}
    for arg in base['command']:
        low = arg.lower()
        if low.startswith(('/out:', '/pdb:', '/map:', '/implib:')):
            continue
        value = replacements[low]['path'] if low in replacements else arg
        args.append(value)
        if low in expected:
            actual = ident(value)
            assert actual == (replacements[low] if low in replacements else expected[low]), arg
            inputs.append(actual)
    assert all(k in expected for k in replacements)
    assert edge['object']['path'].lower() not in expected
    args.insert(1, edge['object']['path'])
    inputs.insert(0, edge['object'])
    image = OUT / 'cuda.exe'
    args += ['/OUT:' + str(image), '/PDB:' + str(OUT / 'cuda.pdb'), '/MAP:' + str(OUT / 'cuda.map')]
    save(OUT / 'link-plan.json', {'command': args, 'inputs': inputs, 'base': ident(baseline), 'numeric_identity': ident(numeric_path), 'edge_identity': ident(edge_path), 'replacements': replacements, 'new_edge_object': edge['object'], 'GPU_run': False, 'SDK_rebuild': False})
    run('link', args)
    assert frozen == [ident(Path(r['path'])) for r in frozen]
    filters = ['CublasProvider.BatchedBroadcastUsesBothOperandsAndRealSubalignment', 'CudaCtBlock128QdqGraph.*', 'CudaCtBlock128QdqEdges.*', 'CudaCcclGather.*', 'CudaFp8ChannelTokenQdqGraph.*', 'CudaDefaultGraph.TensorChainCapturesViewsConversionsMasksAndIndependentResults', 'CudaStableSilu.*', 'CublasProvider.Float32LayoutsAndChangedInputsMatchDoubleOracle:CublasProvider.HalfDecodeAndPrefillUseIndependentLanes:CublasProvider.Bfloat16DecodeAndPrefillUseIndependentLanes:CublasProvider.ColdMetadataFailuresRollBackAndReservedReplayDoesNotAllocate']
    save(OUT / 'summary.json', {'CXX': 1, 'links': 1, 'failed_compile_attempts': 0, 'GPU_runs': 0, 'SDK_rebuilds': 0, 'image': ident(image), 'link_plan': ident(OUT / 'link-plan.json'), 'filters_requested_by_root': filters})
    print('IMAGE_READY', image, flush=True)


if __name__ == '__main__':
    main()
