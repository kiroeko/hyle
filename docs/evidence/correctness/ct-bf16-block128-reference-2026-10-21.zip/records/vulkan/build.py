from pathlib import Path
import difflib,hashlib,json,os,subprocess,sys,time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'ct-bf16-block128-reference/vulkan';C=S/'checks'/os.environ.get('CT128_ATTEMPT','attempt1');C.mkdir(parents=True,exist_ok=True)
B=A/'fixed-role-binding-2026-10-21/blockwise-w4a8/vulkan/checks/attempt2/link-plan.json'
env=os.environ.copy();setup=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in setup.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
tmp=S/'tmp';tmp.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(tmp)
def load(p):return json.loads(Path(p).read_bytes())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(tag,cmd):
 started=time.time();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace')
 (C/(tag+'.stdout.txt')).write_text(p.stdout,encoding='utf8');(C/(tag+'.stderr.txt')).write_text(p.stderr,encoding='utf8');save(C/(tag+'.command.json'),dict(command=cmd,cwd=str(R),exit_code=p.returncode,seconds=time.time()-started))
 print(tag,p.returncode,flush=True)
 if p.returncode:raise RuntimeError((p.stdout+p.stderr)[-7000:])
phase=sys.argv[1]
if phase in ('compile','product'):
 if phase=='compile':
  recipe=A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json';source=R/'tests/graph_route_vulkan/ct_block128_qdq_test.cc';tag='test';obj='block128-test.obj'
 else:
  old_object=next(x for x in load(B)['inputs'] if Path(x['path']).name=='vulkan_program.obj')
  recipe=next(p for p in Path(old_object['path']).parent.glob('*identity.json') if Path(load(p).get('object',{}).get('path',''))==Path(old_object['path']))
  source=R/'src/compute_route_vulkan/vulkan_program.cc';tag='vulkan-program';obj='vulkan_program.obj'
 old=load(recipe);command=[];skip=False
 for arg in old['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  command.append(arg)
 command+=['/W4','/WX','/sourceDependencies',str(C/(tag+'-deps.json')),str(source),'/Fo'+str(C/obj),'/Fd'+str(C/(tag+'.pdb'))]
 run(tag+'-compile',command);deps=load(C/(tag+'-deps.json'))['Data'];paths=dict.fromkeys([deps['Source'],*deps['Includes']]);save(C/(tag+'-identity.json'),dict(command=command,source=identity(source),object=identity(C/obj),recipe=identity(recipe),dependencies=[identity(p) for p in paths]))
elif phase=='link':
 base=load(B);assert len(base['inputs'])==177
 for row in base['inputs']:assert identity(row['path'])==row
 command=[arg for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 replaced=[]
 if (C/'vulkan_program.obj').exists():
  old=next(x for x in base['inputs'] if Path(x['path']).name=='vulkan_program.obj');command=[str(C/'vulkan_program.obj') if arg==old['path'] else arg for arg in command];replaced=[old]
 command.insert(1,str(C/'block128-test.obj'))
 exe=C/'ct-block128-test.exe';command+=['/OUT:'+str(exe),'/MAP:'+str(C/'ct-block128-test.map'),'/IMPLIB:'+str(C/'ct-block128-test.lib')]
 save(C/'proposed-link-plan.json',dict(command=command,inputs=[identity(p) for p in command[1:] if Path(p).is_file()],baseline=identity(B),unchanged_baseline_inputs=177-len(replaced),replaced_product_inputs=replaced,new_test_owner=identity(C/'block128-test.obj'),products_recompiled=len(replaced)))
 run('link',command);plan=load(C/'proposed-link-plan.json');plan['executable']=identity(exe);save(C/'link-plan.json',plan)
elif phase=='freeze':
 rows=[];diff=[]
 names=['tests/graph_route_vulkan/ct_block128_qdq_test.cc','tests/graph_route_vulkan/CMakeLists.txt']
 if (S/'before/src/compute_route_vulkan/vulkan_program.cc').exists():names+=['src/compute_route_vulkan/vulkan_program.cc']
 for name in names:
  source=R/name;dest=S/'after'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.read_bytes());rows.append(dict(source=identity(source),snapshot=identity(dest)))
  before=S/'before'/name;old=before.read_text().splitlines(True) if before.exists() else [];diff+=difflib.unified_diff(old,source.read_text().splitlines(True),fromfile='before/'+name,tofile='after/'+name)
 (S/'implementation.diff').write_text(''.join(diff));save(S/'source-freeze.json',dict(sources=rows,shared_fixture=identity(R/'tests/compute_models/ct_block128_qdq_fixture.h'),product_edits=int(len(names)>2),SDK_builds=0,GPU_runs_by_this_agent=0))
else:raise ValueError(phase)
