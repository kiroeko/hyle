from pathlib import Path
import concurrent.futures,difflib,hashlib,json,os,subprocess,sys,time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'ct-bf16-block128-reference/vulkan-batched-matmul';B=A/'ct-bf16-block128-reference/vulkan/checks/attempt2/link-plan.json'
phase=sys.argv[1];C=S/'checks'/('cold-runs' if phase.startswith('runs') else 'span-repair' if phase.startswith('repair') else 'edge' if phase.startswith('edge') else 'matmul');C.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();setup=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in setup.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
tmp=S/'tmp';tmp.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(tmp)
def load(p):return json.loads(Path(p).read_bytes())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(tag,command):
 t=time.time();p=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace')
 (C/(tag+'.stdout.txt')).write_text(p.stdout,encoding='utf8');(C/(tag+'.stderr.txt')).write_text(p.stderr,encoding='utf8');save(C/(tag+'.command.json'),dict(command=command,cwd=str(R),exit_code=p.returncode,seconds=time.time()-t));print(tag,p.returncode,flush=True)
 if p.returncode:raise RuntimeError((p.stdout+p.stderr)[-7000:])
base=load(B)
def recipe_for(obj):
 for p in Path(obj).parent.glob('*identity.json'):
  d=load(p)
  if Path(d.get('object',{}).get('path',''))==Path(obj):return p
 raise AssertionError(obj)
def compile_one(tag,source,recipe):
 command=[];skip=False
 for arg in load(recipe)['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  command.append(arg)
 command+=['/W4','/WX','/sourceDependencies',str(C/(tag+'-deps.json')),str(source),'/Fo'+str(C/(tag+'.obj')),'/Fd'+str(C/(tag+'.pdb'))]
 run(tag+'-compile',command);data=load(C/(tag+'-deps.json'))['Data'];paths=dict.fromkeys([data['Source'],*data['Includes']]);save(C/(tag+'-identity.json'),dict(command=command,source=identity(source),object=identity(C/(tag+'.obj')),recipe=identity(recipe),dependencies=[identity(p) for p in paths]))
if phase in ('repair-compile','runs-compile'):
 old=next(x for x in base['inputs'] if Path(x['path']).name=='compute_provider_ggml_vulkan-region.obj');compile_one('provider-region',R/'src/compute_provider_ggml_vulkan/region.cc',recipe_for(old['path']))
elif phase in ('repair-link','runs-link'):
 previous_dir=S/('checks/span-repair' if phase=='runs-link' else 'checks/matmul');previous=load(previous_dir/'link-plan.json')
 for x in previous['inputs']:assert identity(x['path'])==x
 old=str(previous_dir/'provider-region.obj');new=str(C/'provider-region.obj');assert any(x['path']==old for x in previous['inputs'])
 command=[new if arg==old else arg for arg in previous['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:'))]
 exe=C/'batched-matmul.exe';command+=['/OUT:'+str(exe),'/MAP:'+str(C/'batched-matmul.map'),'/IMPLIB:'+str(C/'batched-matmul.lib')]
 plan=dict(command=command,inputs=[identity(x) for x in command[1:] if Path(x).is_file()],baseline=identity(previous_dir/'link-plan.json'),replacements={old:new},unchanged_previous_inputs=len(previous['inputs'])-1,SDK=0,SPIRV=0,GPU_by_this_agent=0)
 save(C/'proposed-link-plan.json',plan);run('link',command);plan['executable']=identity(exe);save(C/'link-plan.json',plan)
elif phase=='edge-compile':
 compile_one('edge-test',R/'tests/graph_route_vulkan/ct_block128_activation_edges_test.cc',A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')
elif phase=='products':
 pairs=[('route-region','src/compute_route_vulkan/vulkan_region.cc','compute_route_vulkan-vulkan_region.obj'),('provider-region','src/compute_provider_ggml_vulkan/region.cc','compute_provider_ggml_vulkan-region.obj')]
 def one(item):
  tag,source,obj=item;old=next(x for x in base['inputs'] if Path(x['path']).name==obj);compile_one(tag,R/source,recipe_for(old['path']))
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(one,pairs))
elif phase=='tests':
 compile_one('matmul-test',R/'tests/graph_route_vulkan/batched_matmul_test.cc',A/'ct-channel-token-cross-backend/vulkan/checks/ct-qdq-test-identity.json')
elif phase in ('edge-link','link'):
 for x in base['inputs']:assert identity(x['path'])==x
 replacements={}
 if phase=='link':
  for tag,obj in [('route-region','compute_route_vulkan-vulkan_region.obj'),('provider-region','compute_provider_ggml_vulkan-region.obj')]:
   old=next(x for x in base['inputs'] if Path(x['path']).name==obj);replacements[old['path']]=str(C/(tag+'.obj'))
 command=[]
 for arg in base['command']:
  if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:')):command.append(replacements.get(arg,arg))
 command.insert(1,str(S/'checks/edge/edge-test.obj'))
 if phase=='link':command.insert(1,str(C/'matmul-test.obj'))
 name='ct-activation-edges' if phase=='edge-link' else 'batched-matmul';exe=C/(name+'.exe')
 command+=['/OUT:'+str(exe),'/MAP:'+str(C/(name+'.map')),'/IMPLIB:'+str(C/(name+'.lib'))]
 plan=dict(command=command,inputs=[identity(x) for x in command[1:] if Path(x).is_file()],baseline=identity(B),replacements=replacements,unchanged_baseline_inputs=len(base['inputs'])-len(replacements),SDK=0,SPIRV=0,GPU_by_this_agent=0)
 save(C/'proposed-link-plan.json',plan);run('link',command);plan['executable']=identity(exe);save(C/'link-plan.json',plan)
elif phase=='freeze':
 names=['src/compute_provider_ggml_vulkan/region.cc','src/compute_route_vulkan/vulkan_region.cc','tests/graph_route_vulkan/batched_matmul_test.cc','tests/graph_route_vulkan/ct_block128_activation_edges_test.cc','tests/graph_route_vulkan/CMakeLists.txt'];rows=[];diff=[]
 for n in names:
  p=R/n;q=S/'after'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());rows.append(dict(source=identity(p),snapshot=identity(q)));old=S/'before'/n
  diff+=difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],p.read_text().splitlines(True),fromfile='before/'+n,tofile='after/'+n)
 (S/'implementation.diff').write_text(''.join(diff));save(S/'source-freeze.json',dict(sources=rows,ct_fixture=identity(R/'tests/compute_models/ct_block128_qdq_fixture.h'),edge_fixture=identity(R/'tests/compute_models/ct_block128_activation_edges.h')))
else:raise ValueError(phase)
