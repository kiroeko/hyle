from pathlib import Path
import base64,hashlib,json,runpy,xml.etree.ElementTree as E,difflib
S=Path(__file__).resolve().parent;ROOT=S.parents[4]
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
products=['src/compute_route_apple/apple_static_fp8.h','src/compute_route_apple/apple_static_fp8.cc',
          'src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc']
changed=products+['tests/graph_route_apple/ct_block128_activation_edges_test.cc','tests/graph_route_apple/CMakeLists.txt']
for rel in changed:
 q=S/'after'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((ROOT/rel).read_bytes())
for rel in products:
 old=(S/'before'/rel).read_text();new=(ROOT/rel).read_text()
 (S/(Path(rel).name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='before/'+rel,tofile=rel)),newline='\n')
freeze=dict(sources=[identity(ROOT/p)for p in changed],shared_fixture=identity(ROOT/'tests/compute_models/ct_block128_activation_edges.h'),core_fixture=identity(ROOT/'tests/compute_models/ct_block128_qdq_fixture.h'),
 public_API_ABI_change=False,private_symbol_owners_refreshed=['apple_static_fp8.cc','apple_mature_float.cc','apple_operations.cc'],
 numerical_implementation='Original exact binary family extends BF16 Mul/Div. Integer raw storage and existing IEEE helper preserve subnormal and special values; Safe native normal multiplication/division retained away from BF16 division midpoint. Metadata-only broadcast walks actual strides; no scale/A payload expansion.',
 original_F32_scalar_kernel='Original source body retained, family function renamed privately; actual F32 subnormal scalar neighbor passed.')
save(S/'source-freeze.json',freeze)
out=S/'mac/remote/results';compiles=json.loads((out/'compile-summary.json').read_text())['compiles']
runs=[]
for xml,result in [('tests.xml','run.result.json'),('neighbors.xml','neighbors.result.json'),('related.xml','related.result.json')]:
 root=E.parse(out/xml).getroot();cases=root.findall('.//testcase')
 runs.append(dict(result=identity(out/result),xml=identity(out/xml),exit=json.loads((out/result).read_text())['exit'],tests=len(cases),failed=sum(bool(x.findall('failure'))for x in cases),skipped=sum(bool(x.findall('skipped'))for x in cases),cases=[dict(name=x.get('classname')+'.'+x.get('name'),properties={p.get('name'):p.get('value')for p in x.findall('./properties/property')})for x in cases]))
assert len(compiles)==4 and all(x['exit']==0 and not x['source_drifts']for x in compiles)
assert sum(x['tests']for x in runs)==6 and all(not(x['exit']or x['failed']or x['skipped'])for x in runs)
manifest=json.loads((S/'mac/source-manifest.json').read_text());assert all(identity(ROOT/x['path'])['sha256']==x['sha256']for x in manifest)
validation=dict(source_freeze=identity(S/'source-freeze.json'),source_manifest=identity(S/'mac/source-manifest.json'),canonical_remote_source_count=len(manifest),all_canonical_source_hashes_match=True,
 compiles=[dict(source=x['source'],object=x['object_identity'],result_exit=x['exit'],dependency_count=len(x['dependencies']),source_drifts=x['source_drifts'])for x in compiles],
 actual_compile_and_link_commands='mac/remote/results/*command.json',link=identity(out/'link.result.json'),runs=runs,total_tests=6,failed=0,skipped=0,successful_submissions=34,expected_failed_completions=2,
 first_failure='attempt1-mlx-bfloat-ftz/results/tests.xml',first_wrong_node=dict(proof='diagnostic/tests.xml',input='BF16 0x0304',amax_actual_expected='0x0304',raw_scale_expected='0x0009',raw_scale_actual='0x0000',selected_scale_actual='0x3c00',AQ_expected='0x02fc',AQ_actual='0x0000'),
 hardware=identity(S/'mac/remote/hardware.json'),runtime=identity(S/'mac/remote/runtime-identity.json'),SDK_rebuilt=False,performance_claim=False,
 limits=['Fixed finite-source activation witnesses and related ordinary graphs; no claim about NaN/Inf reduction-source policy.','No new user-facing operator, policy, model whitelist or domain limit.','No GPU performance benchmark was performed.'])
save(S/'final-validation.json',validation)
ssh=runpy.run_path(str(ROOT/'.scratch/architecture-refactor-2026-10-18/batch-query-extent/delegated/apple/validate.py'))['ssh']
remote=json.loads((S/'mac/plan.json').read_text())['remote']
code=r'''
from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['remote'])
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
deletable=[r/'ct-activation-edges',r/'ct-activation-edges.map',r/'diagnostic/probe',r/'diagnostic/probe.map']
objects=sorted((r/'objects').glob('*.o'))+sorted((r/'diagnostic').glob('*.o'))
ps=subprocess.run(['ps','-axo','pid=,command='],capture_output=True,text=True)
live=[x for x in ps.stdout.splitlines()if str(r)in x and 'python3 -c' not in x and '/bin/sh -c' not in x]
checks=[]
for f in deletable:
 if f.is_file():
  q=subprocess.run(['lsof',str(f)],capture_output=True,text=True)
  checks.append(dict(path=str(f),exit=q.returncode,stdout=q.stdout,stderr=q.stderr))
print(json.dumps(dict(remote=str(r),remote_root_is_symlink=r.is_symlink(),deletable_files=[identity(x)for x in deletable if x.is_file()and not x.is_symlink()],retain_small_objects=[identity(x)for x in objects],dSYM=[str(x)for x in r.glob('*.dSYM')]+[str(x)for x in (r/'diagnostic').glob('*.dSYM')],process_matches=live,lsof=checks,metallib=dict(path=str(r/'mlx.metallib'),is_symlink=(r/'mlx.metallib').is_symlink(),target=str((r/'mlx.metallib').resolve())),action='read-only inventory; root owns test.ps1; no deletion performed')))
'''
cleanup=ssh(code,dict(remote=remote));save(S/'cleanup-readonly-inventory.json',cleanup)
print(json.dumps(dict(freeze=identity(S/'source-freeze.json'),validation=identity(S/'final-validation.json'),cleanup=identity(S/'cleanup-readonly-inventory.json'),tests=6,deletable_bytes=sum(x['bytes']for x in cleanup['deletable_files']),retained_object_bytes=sum(x['bytes']for x in cleanup['retain_small_objects']),process_matches=cleanup['process_matches'])))
