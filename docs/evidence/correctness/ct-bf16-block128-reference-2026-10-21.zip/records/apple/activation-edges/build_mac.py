"""Run only the exact retained-cache incremental Apple closure."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import shlex
import subprocess
import sys
import time
import xml.etree.ElementTree as E
R = Path(__file__).resolve().parent
O = R / "results"
O.mkdir(exist_ok=True)
(R / "objects").mkdir(exist_ok=True)
plan = json.loads((R / "plan.json").read_text())
manifest = json.loads((R / "source-manifest.json").read_text())
expected = {x["path"]: x for x in manifest}


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def save(name, value):
    (O / name).write_text(json.dumps(value, indent=2) + "\n")


def execute(tag, command):
    record = dict(argv=command, started=time.time())
    save(tag + ".command.json", record)
    p = subprocess.run(command, cwd=R, capture_output=True, text=True)
    (O / (tag + ".stdout.log")).write_text(p.stdout)
    (O / (tag + ".stderr.log")).write_text(p.stderr)
    record.update(exit=p.returncode, seconds=time.time() - record["started"])
    save(tag + ".result.json", record)
    print(tag, p.returncode, round(record["seconds"], 2), flush=True)
    return record


for row in manifest:
    assert identity(R / row["path"])["sha256"] == row["sha256"], row["path"]
for row in plan["inputs"]:
    assert identity(row["path"]) == row, row["path"]
headers = {str((R / row["path"]).parent) for row in manifest
           if row["path"].endswith((".h", ".hpp", ".hh", ".inc", ".inl"))
           and not row["path"].startswith("include/")}
first = ["-I" + str(R / "include"), "-I" + str(R),
         *["-I" + path for path in sorted(headers)]]


def compile_one(row):
    rel = row["source"]
    tag = rel.replace("/", "--")
    obj = R / "objects" / (tag + ".o")
    dep = Path(str(obj) + ".d")
    command = row["recipe"].copy()
    for flag in ["-MF", "-MT", "-MQ"]:
        while flag in command:
            i = command.index(flag)
            del command[i:i + 2]
    command = [x for x in command if x not in ["-MD", "-MMD"]]
    command[command.index("-c") + 1] = str(R / rel)
    command[command.index("-o") + 1] = str(obj)
    command[1:1] = first
    command += ["-MD", "-MF", str(dep)]
    prior = O / (tag + "-identity.json")
    if prior.exists():
        cached = json.loads(prior.read_text())
        if cached.get("exit") == 0 and cached["argv"] == command and all(
            Path(x["path"]).exists() and identity(x["path"]) == x
            for x in cached.get("dependencies", [])):
            print(tag, "reused current exact command/source/dependency hashes", flush=True)
            return cached
    result = execute(tag + "-compile", command)
    record = dict(result, source=identity(R / rel), old_object=row["old_object"],
                  object=str(obj), dependency=str(dep))
    if result["exit"]:
        save(tag + "-identity.json", record)
        return record
    paths = list(dict.fromkeys(shlex.split(
        dep.read_text().split(": ", 1)[1].replace("\\\n", " "))))
    deps = [identity(path) for path in paths]
    drift = []
    for item in deps:
        path = Path(item["path"])
        if path.is_relative_to(R):
            key = path.relative_to(R).as_posix()
            if key in expected and expected[key]["sha256"] != item["sha256"]:
                drift.append(item)
    record.update(object_identity=identity(obj), dependencies=deps, source_drifts=drift)
    save(tag + "-identity.json", record)
    assert not drift
    return record


if "--compile" in sys.argv:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = list(pool.map(compile_one, [r for r in plan["compile"] if "--products" not in sys.argv or not r["source"].startswith("tests/")]))
    save("compile-summary.json", dict(compiles=records,
         passed=all(x["exit"] == 0 for x in records), SDK=False, NVCC=False))
    raise SystemExit(int(any(x["exit"] for x in records)))
records = json.loads((O / "compile-summary.json").read_text())["compiles"]
assert all(x["exit"] == 0 for x in records)
command = plan["link"].copy()
for row in records:
    if row["old_object"]:
        assert command.count(row["old_object"]) == 1
        command[command.index(row["old_object"])] = row["object"]
    else:
        command.insert(1, row["object"])
image = R / "ct-activation-edges"
command[command.index("-o") + 1] = str(image)
command = [("-Wl,-map," + str(image) + ".map")
           if x.startswith("-Wl,-map,") else x for x in command]
save("link-inputs.json", [identity(x) for x in command
     if Path(x).is_file() and Path(x).suffix in [".o", ".a", ".dylib"]])
result = execute("link", command)
if result["exit"]:
    raise SystemExit(2)
metallib = R / "mlx.metallib"
if not metallib.exists():
    metallib.symlink_to(Path(plan["metallib"]).resolve())
result = execute("run", [str(image), "--gtest_filter=" + plan["filter"],
                        "--gtest_output=xml:" + str(O / "tests.xml")])
cases = E.parse(O / "tests.xml").findall(".//testcase")
failed = [x.attrib for x in cases if x.findall("failure")]
skipped = [x.attrib for x in cases if x.findall("skipped")]
save("validation.json", dict(image=identity(image), tests=len(cases),
     failed=failed, skipped=skipped, exit=result["exit"],
     names=[x.get("classname") + "." + x.get("name") for x in cases],
     source_manifest=identity(R / "source-manifest.json")))
print("VALIDATION", len(cases), "failed", len(failed), "skipped", len(skipped), flush=True)
raise SystemExit(result["exit"])
