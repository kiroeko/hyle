from pathlib import Path
import hashlib,json,runpy,base64
S=Path(__file__).resolve().parent
ROOT=S.parents[4]
wrapper=(ROOT/'tests/graph_route_apple/ct_block128_activation_edges_test.cc').read_text()
prefix=wrapper.split('TEST(')[0].replace('../compute_models/ct_block128_activation_edges.h','tests/compute_models/ct_block128_activation_edges.h')
source=prefix+r'''
TEST(AppleCtBlock128Diagnostic, PublishedBfloatIntermediates) {
  run_apple([](auto resource,auto queues,auto compile,auto write,auto read,auto prepare) {
    namespace c=f::c;namespace g=f::g;namespace m=f::m;
    auto b=f::take(g::GraphBuilder::create(),"diagnostic builder");
    const auto ad=f::dense(c::DataType::kBFloat16,{2,2,128});
    const auto sd=f::dense(c::DataType::kBFloat16,{});
    const auto a=f::take(b.input(ad),"A");
    std::array<g::ValueId,3> ids;
    for(auto &id:ids)id=f::take(b.constant(sd),"scalar");
    const auto abs=f::take(b.add(c::Unary{c::UnaryKind::kAbs},a),"abs");
    const auto maximum=f::take(b.add(c::Reduce{.kind=c::ReductionKind::kMaximum,
      .axes=f::take(c::Axes::from(std::array<std::int32_t,1>{2}),"axis"),
      .keep_dimensions=true,.accumulation_type=c::DataType::kFloat32},abs),"maximum");
    const auto raw=f::take(b.add(c::Binary{c::BinaryKind::kDivide},maximum,ids[0]),"raw scale");
    const auto nz=f::take(b.add(c::Cast{c::DataType::kBool},raw),"nonzero");
    const auto scale=f::take(b.add(c::Select{},nz,raw,ids[1]),"selected scale");
    const auto normalized=f::take(b.add(c::Binary{c::BinaryKind::kDivide},a,scale),"normalized");
    const auto shifted=f::take(b.add(c::Binary{c::BinaryKind::kAdd},normalized,ids[2]),"shifted");
    const auto encoded=f::take(b.add(c::Cast{c::DataType::kFloat8E4M3FN},shifted),"E4");
    const auto widened=f::take(b.add(c::Cast{c::DataType::kBFloat16},encoded),"BF16");
    const auto centered=f::take(b.add(c::Binary{c::BinaryKind::kSubtract},widened,ids[2]),"centered");
    const auto aq=f::take(b.add(c::Binary{c::BinaryKind::kMultiply},centered,scale),"AQ");
    const std::array outputs{maximum,raw,scale,normalized,centered,aq};
    for(auto id:outputs)f::check(b.publish(id),"publish");
    const auto graph=f::take(std::move(b).finish(),"graph");
    std::array<c::ReadLease,3> leases;std::array<g::ConstantBinding,3> constants;
    constexpr std::array<std::uint16_t,3> values{0x43e0,0x3c00,0};
    for(std::size_t i=0;i<values.size();++i){
      auto buffer=f::take(m::Buffer::create(resource,2,256),"scalar buffer");
      f::check(write(buffer.view(),std::as_bytes(std::span(&values[i],1))),"scalar write");
      leases[i]=f::take(c::ReadLease::adopt(std::move(buffer)),"scalar lease");
      constants[i]={ids[i],f::take(leases[i].tensor(sd),"scalar tensor"),g::ConstantPolicy::kMaterialize,{}, {}};
    }
    auto compiled=compile(graph,g::CompileOptions{.constants=constants});ASSERT_TRUE(compiled)<<compiled.error().message();
    EXPECT_EQ(f::take(compiled->executable.output_ownership(),"ownership"),g::OutputOwnership::kInvocation);
    auto run=f::take(compiled->executable.create_invocation({.resources=g::ResourceOptions{}}),"invocation");
    auto input=f::take(m::Buffer::create(resource,1024,256),"input");
    std::vector<std::uint16_t> data(512,0);for(unsigned i=0;i<4;++i)data[i*128]=0x0304;
    f::check(write(input.view(),std::as_bytes(std::span(data))),"A write");
    f::check(run.bind(a,f::take(c::ConstTensorView::create(ad,input.view()),"A tensor")),"bind");
    f::check(prepare(run,queues),"prepare");
    auto done=f::take(run.submit(queues),"submit");f::check(done.wait(),"wait");
    constexpr std::array expected{0x0304u,0x0009u,0x0009u,0x43ebu,0x43e0u,0x02fcu};
    constexpr std::array names{"maximum","raw_scale","selected_scale","normalized","centered","AQ"};
    for(std::size_t i=0;i<outputs.size();++i){
      auto result=f::take(run.result(outputs[i]),"result");
      auto tensor=f::take(result.tensor(),"result tensor");
      std::vector<std::uint16_t> actual(i<3?4:512);
      f::check(read(tensor.storage(),std::as_writable_bytes(std::span(actual))),"read result");
      ::testing::Test::RecordProperty(names[i],unsigned(actual[0]));
      EXPECT_EQ(unsigned(actual[0]),expected[i])<<names[i];
    }
  });
}
'''
(S/'diagnostic').mkdir(exist_ok=True)
(S/'diagnostic/probe.cc').write_text(source,newline='\n')
remote=json.loads((S/'mac/plan.json').read_text())['remote']
recipe=json.loads((S/'mac/remote/results/tests--graph_route_apple--ct_block128_activation_edges_test.cc-compile.command.json').read_text())['argv']
link=json.loads((S/'mac/remote/results/link.command.json').read_text())['argv']
code=r'''
from pathlib import Path
import json,sys,base64,hashlib,subprocess,time,shlex
p=json.load(sys.stdin);r=Path(p['remote']);d=r/'diagnostic';d.mkdir(exist_ok=True)
src=d/'probe.cc';src.write_bytes(base64.b64decode(p['source']))
def ident(f):
 b=Path(f).read_bytes();return dict(path=str(f),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def execute(tag,c):
 t=time.time();q=subprocess.run(c,cwd=r,capture_output=True,text=True)
 (d/(tag+'.stdout.log')).write_text(q.stdout);(d/(tag+'.stderr.log')).write_text(q.stderr)
 v=dict(argv=c,exit=q.returncode,seconds=time.time()-t);(d/(tag+'.json')).write_text(json.dumps(v,indent=2)+'\n');return v
c=p['recipe'];c[c.index('-c')+1]=str(src);c[c.index('-o')+1]=str(d/'probe.o');c[c.index('-MF')+1]=str(d/'probe.d')
v=execute('compile',c);assert v['exit']==0,v
deps=list(dict.fromkeys(shlex.split((d/'probe.d').read_text().split(': ',1)[1].replace('\\\n',' '))))
(d/'dependencies.json').write_text(json.dumps([ident(x)for x in deps],indent=2)+'\n')
c=p['link'];c.insert(1,str(d/'probe.o'));c[c.index('-o')+1]=str(d/'probe')
c=[('-Wl,-map,'+str(d/'probe.map'))if x.startswith('-Wl,-map,')else x for x in c]
v=execute('link',c);assert v['exit']==0,v
if not (d/'mlx.metallib').exists():(d/'mlx.metallib').symlink_to((r/'mlx.metallib').resolve())
v=execute('run',[str(d/'probe'),'--gtest_filter=AppleCtBlock128Diagnostic.*','--gtest_output=xml:'+str(d/'tests.xml')])
print(json.dumps(dict(result=v,source=ident(src),files=[dict(name=x.name,data=base64.b64encode(x.read_bytes()).decode())for x in d.iterdir()if x.is_file()and x.suffix not in ['.o','.map']and x.name!='probe'])))
'''
ssh=runpy.run_path(str(ROOT/'.scratch/architecture-refactor-2026-10-18/batch-query-extent/delegated/apple/validate.py'))['ssh']
result=ssh(code,dict(remote=remote,source=base64.b64encode(source.encode()).decode(),recipe=recipe,link=link))
for row in result.pop('files'):(S/'diagnostic'/row['name']).write_bytes(base64.b64decode(row['data']))
(S/'diagnostic/result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
