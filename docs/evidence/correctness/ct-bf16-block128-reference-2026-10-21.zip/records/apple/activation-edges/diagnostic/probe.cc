#include "tests/compute_models/ct_block128_activation_edges.h"
#include "hyle/compute/apple_memory.h"
#include "hyle/graph/apple.h"

namespace {
namespace f = ct_block128_qdq_test;
namespace a = hyle::compute::apple;
template<class Run> void run_apple(Run run) {
  auto context = f::take(a::Context::create(), "Apple context");
  ::testing::Test::RecordProperty("device", context.environment()->device_name);
  auto memory = f::take(a::MemoryResource::create(context), "Apple shared memory");
  const std::array domains{f::g::StorageDomain{memory.ref()}};
  const std::array targets{f::g::ExecutionTarget{
      f::take(f::g::apple::execution_source(context), "Apple execution source"),
      f::g::StorageDomainId{0}}};
  run(memory.ref(), std::span<const f::g::QueueBinding>{},
      [&](const f::g::Graph &graph, f::g::CompileOptions options) {
        return f::g::compile(graph, {domains,targets}, options);
      },
      [](f::m::BufferView destination, std::span<const std::byte> source) {
        return destination.write(source);
      },
      [](f::m::ConstBufferView source, std::span<std::byte> destination) {
        return source.read(destination);
      },
      [](f::g::Invocation &invocation,
         std::span<const f::g::QueueBinding> bindings) {
        return invocation.prepare_replay(bindings);
      });
}
} // namespace


TEST(AppleCtBlock128Diagnostic, PublishedBfloatIntermediates) {
  run_apple([](auto resource,auto queues,auto compile,auto write,auto read,auto prepare) {
    namespace c=f::c;namespace g=f::g;namespace m=f::m;
    auto b=f::take(g::GraphBuilder::create(),"diagnostic builder");
    const auto ad=f::dense(c::DataType::kBFloat16,{2,2,128});
    const auto sd=f::dense(c::DataType::kBFloat16,{});
    const auto a=f::take(b.input(ad),"A");
    std::array<g::ValueId,3> ids;
    for(auto &id:ids)id=f::take(b.constant(sd),"scalar");
    const auto abs=f::take(b.add(c::Unary{c::UnaryKind::kAbs},a),"abs");
    const auto maximum=f::take(b.add(c::Reduce{.kind=c::ReductionKind::kMaximum,
      .axes=f::take(c::Axes::from(std::array<std::int32_t,1>{2}),"axis"),
      .keep_dimensions=true,.accumulation_type=c::DataType::kFloat32},abs),"maximum");
    const auto raw=f::take(b.add(c::Binary{c::BinaryKind::kDivide},maximum,ids[0]),"raw scale");
    const auto nz=f::take(b.add(c::Cast{c::DataType::kBool},raw),"nonzero");
    const auto scale=f::take(b.add(c::Select{},nz,raw,ids[1]),"selected scale");
    const auto normalized=f::take(b.add(c::Binary{c::BinaryKind::kDivide},a,scale),"normalized");
    const auto shifted=f::take(b.add(c::Binary{c::BinaryKind::kAdd},normalized,ids[2]),"shifted");
    const auto encoded=f::take(b.add(c::Cast{c::DataType::kFloat8E4M3FN},shifted),"E4");
    const auto widened=f::take(b.add(c::Cast{c::DataType::kBFloat16},encoded),"BF16");
    const auto centered=f::take(b.add(c::Binary{c::BinaryKind::kSubtract},widened,ids[2]),"centered");
    const auto aq=f::take(b.add(c::Binary{c::BinaryKind::kMultiply},centered,scale),"AQ");
    const std::array outputs{maximum,raw,scale,normalized,centered,aq};
    for(auto id:outputs)f::check(b.publish(id),"publish");
    const auto graph=f::take(std::move(b).finish(),"graph");
    std::array<c::ReadLease,3> leases;std::array<g::ConstantBinding,3> constants;
    constexpr std::array<std::uint16_t,3> values{0x43e0,0x3c00,0};
    for(std::size_t i=0;i<values.size();++i){
      auto buffer=f::take(m::Buffer::create(resource,2,256),"scalar buffer");
      f::check(write(buffer.view(),std::as_bytes(std::span(&values[i],1))),"scalar write");
      leases[i]=f::take(c::ReadLease::adopt(std::move(buffer)),"scalar lease");
      constants[i]={ids[i],f::take(leases[i].tensor(sd),"scalar tensor"),g::ConstantPolicy::kMaterialize,{}, {}};
    }
    auto compiled=compile(graph,g::CompileOptions{.constants=constants});ASSERT_TRUE(compiled)<<compiled.error().message();
    EXPECT_EQ(f::take(compiled->executable.output_ownership(),"ownership"),g::OutputOwnership::kInvocation);
    auto run=f::take(compiled->executable.create_invocation({.resources=g::ResourceOptions{}}),"invocation");
    auto input=f::take(m::Buffer::create(resource,1024,256),"input");
    std::vector<std::uint16_t> data(512,0);for(unsigned i=0;i<4;++i)data[i*128]=0x0304;
    f::check(write(input.view(),std::as_bytes(std::span(data))),"A write");
    f::check(run.bind(a,f::take(c::ConstTensorView::create(ad,input.view()),"A tensor")),"bind");
    f::check(prepare(run,queues),"prepare");
    auto done=f::take(run.submit(queues),"submit");f::check(done.wait(),"wait");
    constexpr std::array expected{0x0304u,0x0009u,0x0009u,0x43ebu,0x43e0u,0x02fcu};
    constexpr std::array names{"maximum","raw_scale","selected_scale","normalized","centered","AQ"};
    for(std::size_t i=0;i<outputs.size();++i){
      auto result=f::take(run.result(outputs[i]),"result");
      auto tensor=f::take(result.tensor(),"result tensor");
      std::vector<std::uint16_t> actual(i<3?4:512);
      f::check(read(tensor.storage(),std::as_writable_bytes(std::span(actual))),"read result");
      ::testing::Test::RecordProperty(names[i],unsigned(actual[0]));
      EXPECT_EQ(unsigned(actual[0]),expected[i])<<names[i];
    }
  });
}
