from pathlib import Path
import base64
import hashlib
import json
import re
import subprocess

S = Path(__file__).resolve().parent
A = S.parents[2]
ROOT = A.parents[1]
O = S / "mac"
O.mkdir(exist_ok=True)
REMOTE = "/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/ct-bf16-block128-reference/apple/activation-edges"


def read(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def identity(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def main():
    base = A / "ct-bf16-block128-reference/apple/mac/remote"
    old = read(base / "plan.json")
    plan = dict(old)
    plan["link"] = read(base / "results/link.command.json")["argv"]
    plan["inputs"] = read(base / "results/link-inputs.json")
    plan["compile"] = []
    owners = [
        ("src/compute_route_apple/apple_static_fp8.cc", "static-fp8-reference/apple/mac/remote/ieee-binary-v2/results/src--compute_route_apple--apple_static_fp8.cc-compile.command.json", "/src--compute_route_apple--apple_static_fp8.cc.o"),
        ("src/compute_route_apple/apple_mature_float.cc", "blockwise-w4a8/apple/mac/remote/results/src--compute_route_apple--apple_mature_float.cc-compile.command.json", "/src--compute_route_apple--apple_mature_float.cc.o"),
        ("src/compute_route_apple/apple_operations.cc", "ct-bf16-block128-reference/apple/mac/remote/results/src--compute_route_apple--apple_operations.cc-compile.command.json", "/src--compute_route_apple--apple_operations.cc.o"),
        ("tests/graph_route_apple/ct_block128_activation_edges_test.cc", "ct-bf16-block128-reference/apple/mac/remote/results/tests--graph_route_apple--ct_block128_qdq_test.cc-compile.command.json", ""),
    ]
    for source, recipe_path, suffix in owners:
        recipe = read(A / recipe_path)["argv"]
        obj = next(x for x in plan["link"] if x.endswith(suffix)) if suffix else ""
        plan["compile"].append(dict(source=source, recipe=recipe, old_object=obj))
    plan.update(remote=REMOTE,
        metallib="/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib",
        filter="AppleCtBlock128QdqEdges.*:AppleCtBlock128Qdq.*",
        source_basis={name: identity(ROOT / name) for name in [
            "include/hyle/compute/model_ops.h", "tests/compute_models/ct_block128_qdq_fixture.h",
            "tests/compute_models/ct_block128_activation_edges.h"]})
    sources = [x["source"] for x in plan["compile"]]
    search = [ROOT, ROOT / "include", *(p for p in (ROOT / "src").iterdir() if p.is_dir()),
              *(p for p in (ROOT / "third_party").iterdir() if p.is_dir())]
    seen = set()
    include = re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]', re.M)

    def visit(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or not path.is_file():
            return
        if path.suffix not in [".h", ".hpp", ".hh", ".cc", ".mm", ".inc", ".inl", ".cuh"]:
            return
        seen.add(path)
        for name in include.findall(path.read_text(encoding="utf-8", errors="replace")):
            target = next((base / name for base in [path.parent, *search]
                           if (base / name).is_file()), None)
            if target:
                visit(target)
    for source in sources:
        visit(ROOT / source)
    files = []
    for path in sorted(seen):
        row = identity(path)
        row["path"] = path.relative_to(ROOT).as_posix()
        row["data"] = base64.b64encode(path.read_bytes()).decode()
        files.append(row)
    save(O / "source-manifest.json", [{k: v for k, v in row.items() if k != "data"} for row in files])
    save(O / "plan.json", plan)
    payload = dict(plan=plan, files=files,
                   script=base64.b64encode((S / "build_mac.py").read_bytes()).decode())
    code = r'''
from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p["plan"]["remote"]);r.mkdir(parents=True,exist_ok=True)
assert r.is_dir() and not r.is_symlink()
for row in p["files"]:
 b=base64.b64decode(row["data"]);assert hashlib.sha256(b).hexdigest()==row["sha256"]
 q=r/row["path"];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/"source-manifest.json").write_text(json.dumps([{k:v for k,v in x.items() if k!="data"}for x in p["files"]],indent=2)+"\n")
(r/"plan.json").write_text(json.dumps(p["plan"],indent=2)+"\n")
(r/"build_mac.py").write_bytes(base64.b64decode(p["script"]))
for row in p["plan"]["inputs"]:
 q=Path(row["path"]);assert q.stat().st_size==row["bytes"]
 assert hashlib.sha256(q.read_bytes()).hexdigest()==row["sha256"],row["path"]
h={k:subprocess.check_output(v,text=True).strip()for k,v in{
 "model":["sysctl","-n","hw.model"],"cpu":["sysctl","-n","machdep.cpu.brand_string"],
 "memory":["sysctl","-n","hw.memsize"],"os":["sw_vers"],"compiler":["clang++","--version"],
 "space":["df","-h",str(r)]}.items()}
assert h["model"]=="Mac16,12"
(r/"hardware.json").write_text(json.dumps(h,indent=2)+"\n")
print(json.dumps(dict(remote=str(r),files=len(p["files"]),bytes=sum(x["bytes"]for x in p["files"]),
 retained_inputs=len(p["plan"]["inputs"]),compile_owners=len(p["plan"]["compile"]),hardware=h)))
'''
    encoded = base64.b64encode(code.encode()).decode()
    command = ["ssh", "-o", "BatchMode=yes", "kiro@172.22.10.198",
               'python3 -c "import base64;exec(base64.b64decode(\'' + encoded + '\'))"']
    save(O / "sync.command.json", command)
    result = subprocess.run(command, input=json.dumps(payload).encode(), capture_output=True)
    (O / "sync.stdout.log").write_bytes(result.stdout)
    (O / "sync.stderr.log").write_bytes(result.stderr)
    save(O / "sync.result.json", dict(exit=result.returncode))
    print(result.stdout.decode(), result.stderr.decode())
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
