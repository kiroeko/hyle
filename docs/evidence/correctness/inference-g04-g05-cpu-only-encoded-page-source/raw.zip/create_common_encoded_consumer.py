from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[3]
s=(ROOT/'tests/compute_batch/encoded_page_native_consumer.cc').read_text()
start=s.index('using hyle::Status;')
s='''#include <hyle/compute/cpu.h>
#include <hyle/compute/providers/ggml_cpu.h>
#include <hyle/compute/batch_execution.h>
#include <hyle/compute/paged_arena.h>
#include <hyle/compute/model_ops.h>
#include <hyle/graph/batch.h>
#include <hyle/graph/cpu_cuda.h>
#if defined(HYLE_ENCODED_CUDA)
#include <hyle/compute/backends/cuda.h>
#include <hyle/compute/providers/flashinfer.h>
#endif
#include "../compute_provider_native/half_test_support.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <limits>
#include <vector>
namespace {
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace gb=g::batch;
#if defined(HYLE_ENCODED_CUDA)
constexpr auto route="CUDA";
#else
constexpr auto route="CPU";
#endif
''' + s[start:]
a=s.index('Result<NativeTensor> upload(');b=s.index('Status episode(',a)
s=s[:a]+'''Status read_bytes([[maybe_unused]] c::Context &context, [[maybe_unused]] hyle::mem::MemoryResourceRef resource,
                  const c::ReadLease &source,std::span<std::uint8_t> bytes){
  return source.view()->read(std::as_writable_bytes(bytes));
}
struct Encoder final {
  g::CompiledGraph compiled;
  g::Invocation invocation;
  std::vector<g::ValueId> inputs,outputs;
};
Result<Encoder> encoder(c::Context &context,hyle::mem::MemoryResourceRef resource,
    std::span<const c::TensorDesc> descriptions,std::span<const c::CacheStorage> storage){
  Encoder result;
  HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
  for(std::size_t i=0;i<descriptions.size();++i){
    HYLE_ASSIGN_OR_RETURN(auto input,builder.input(descriptions[i]));result.inputs.push_back(input);
    HYLE_ASSIGN_OR_RETURN(auto output,builder.add(c::Operation::custom(c::model_ops::CacheEncode{storage[i]}),input));
    result.outputs.push_back(output);HYLE_RETURN_IF_ERROR(builder.publish(output));
  }
  HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
  const std::array domains{g::StorageDomain{resource}};
  const std::array targets{g::ExecutionTarget{&context,g::StorageDomainId{0}}};
  HYLE_ASSIGN_OR_RETURN(result.compiled,g::compile(graph,{.storage_domains=domains,.targets=targets},
      {.operation_fallback=g::OperationFallbackPolicy::kReject}));
  HYLE_ASSIGN_OR_RETURN(result.invocation,result.compiled.executable.create_invocation());return result;
}
''' +s[b:]
a=s.index('Status episode(');b=s.index('  const unsigned requests=',a)
s=s[:a]+'''Status episode(unsigned dk,unsigned dv,unsigned mode,bool invalid=false,bool paired_failure=false,bool single=false){
  const bool combined=mode!=0;
#if defined(HYLE_ENCODED_CUDA)
  const bool cpu_graph=mode==2;
#else
  const bool cpu_graph=combined;
#endif
''' +s[b:]
s=s.replace('  const auto q8 = c::CacheStorage::q8_0().value();','''#if defined(HYLE_ENCODED_CUDA)
  const auto key_storage=c::CacheStorage::float8(.5F).value(),value_storage=c::CacheStorage::float8(2.F).value();
  const auto base=c::flashinfer::provider();
  HYLE_ASSIGN_OR_RETURN(auto device_id,c::cuda::device(0));
#else
  const auto key_storage=c::CacheStorage::q8_0().value(),value_storage=key_storage;
  const auto base=c::ggml_cpu::provider({.native_threads=2});
  const auto device_id=c::cpu::device();
#endif''')
s=s.replace('.key_storage=q8, .value_storage=q8,','.key_storage=key_storage, .value_storage=value_storage,')
a=s.index('  HYLE_ASSIGN_OR_RETURN(auto schema,');b=s.index('  HYLE_ASSIGN_OR_RETURN(auto recipe,',a)
s=s[:b]+'''  c::BatchProgramOptions options{.resource={},.host_workspace=hyle::mem::system_resource(),
      .max_float_workspace_bytes=16u<<20,.max_int_workspace_bytes=1u<<20,.max_invocations=4,
      .scale=.125F,.causal=true,.window_left=16};
  HYLE_ASSIGN_OR_RETURN(auto wrapped,gb::provider(base,schema,options));
  const std::array providers{c::ProviderBinding{base,10},c::ProviderBinding{wrapped,0}};
  HYLE_ASSIGN_OR_RETURN(auto context,c::Context::create(device_id,c::ContextOptions{.providers=providers}));
  HYLE_ASSIGN_OR_RETURN(auto queue,context.create_queue());
  struct Close final {c::Context &context;~Close(){context.drain().IgnoreError();}}close{context};
#if defined(HYLE_ENCODED_CUDA)
  HYLE_ASSIGN_OR_RETURN(auto device,c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto staging,c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
  const auto resource=device.ref(),host_resource=staging.ref();
#else
  const auto resource=hyle::mem::system_resource(),host_resource=resource;
#endif
  options.resource=resource;options.host_workspace=host_resource;
''' +s[b:]
s=re.sub(r'\bn::','c::',s).replace('device.ref()','resource').replace('staging.ref()','host_resource')
# Restore the two resource declarations after the generic call substitutions.
s=s.replace('const auto resource=resource,host_resource=host_resource;','const auto resource=device.ref(),host_resource=staging.ref();')
s=s.replace('HYLE_RETURN_IF_ERROR(require(krb==2*dk/32*34 && vrb==2*dv/32*34,"encoded K/V byte geometry differs"));','''#if defined(HYLE_ENCODED_CUDA)
  HYLE_RETURN_IF_ERROR(require(krb==2*dk && vrb==2*dv,"FP8 byte geometry differs"));
#else
  HYLE_RETURN_IF_ERROR(require(krb==2*dk/32*34 && vrb==2*dv/32*34,"Q8 byte geometry differs"));
#endif''')
s=s.replace('c::CopyBatchInvocation::create(init_program)','c::CopyBatchInvocation::create(init_program,queue)')
s=s.replace('auto bytes=constant_q8(value,16*2*depth);','auto bytes=constant_q8(value,16*2*depth,&arena==&values);')
a=s.index('#if defined(HYLE_ENCODED_APPLE)',s.index('std::vector<std::uint16_t> query_words'));b=s.index('  HYLE_ASSIGN_OR_RETURN(auto kd,',a)
s=s[:a]+'''  HYLE_ASSIGN_OR_RETURN(auto query_pool,c::LeasePool::create(resource,query_words.size()*2+64));
  HYLE_ASSIGN_OR_RETURN(auto query_writer,query_pool.allocate(query_words.size()*2,64));
  HYLE_RETURN_IF_ERROR(query_writer.view()->write(std::as_bytes(std::span(query_words))));
  HYLE_ASSIGN_OR_RETURN(auto query,query_writer.publish());
  HYLE_ASSIGN_OR_RETURN(auto batch_program,c::BatchProgram::prepare(context,schema,options));
  HYLE_ASSIGN_OR_RETURN(auto old_slot,c::BatchInvocation::create(batch_program,queue));
  HYLE_ASSIGN_OR_RETURN(auto old_prepared,old_slot.prepare_batch(old_layout));
''' +s[b:]
a=s.index('  const auto op=c::Operation::custom(');b=s.index('  const std::array specs{',a)
s=s[:a]+'''  HYLE_ASSIGN_OR_RETURN(auto kc,c::infer_single_output(c::Operation::custom(c::model_ops::CacheEncode{key_storage}),std::array{kd}));
  HYLE_ASSIGN_OR_RETURN(auto vc,c::infer_single_output(c::Operation::custom(c::model_ops::CacheEncode{value_storage}),std::array{vd}));
  HYLE_ASSIGN_OR_RETURN(auto ke,encoder(context,resource,std::array{kd},std::array{key_storage}));
  HYLE_ASSIGN_OR_RETURN(auto ve,encoder(context,resource,std::array{vd},std::array{value_storage}));
  HYLE_ASSIGN_OR_RETURN(auto pe,encoder(context,resource,std::array{kd,vd},std::array{key_storage,value_storage}));
  const auto kbytes=*kc.required_bytes(),vbytes=*vc.required_bytes();
  HYLE_ASSIGN_OR_RETURN(auto source_pool,c::LeasePool::create(resource,kbytes+vbytes+128,{.max_blocks=2}));
  HYLE_ASSIGN_OR_RETURN(auto uses,c::LeaseUsePool::create());
''' +s[b:]
s=s.replace('c::CopyResourceSpec{resource,2*krb},c::CopyResourceSpec{resource,2*vrb}','c::CopyResourceSpec{resource,kbytes+vbytes},c::CopyResourceSpec{resource,vbytes}')
a=s.index('  HYLE_ASSIGN_OR_RETURN(auto copy_program,');b=s.index('  const auto failed_result=',a)
s=s[:a]+'''  HYLE_ASSIGN_OR_RETURN(auto copy_program,c::CopyBatchProgram::prepare(context,specs));
  HYLE_ASSIGN_OR_RETURN(auto copy,c::CopyBatchInvocation::create(copy_program,queue));
  HYLE_ASSIGN_OR_RETURN(auto native_slot,c::BatchInvocation::create(batch_program,queue));
  HYLE_ASSIGN_OR_RETURN(auto receiver,c::PagedBatchReceiver::create(std::move(native_slot),4));
  HYLE_ASSIGN_OR_RETURN(auto cpu,c::cpu::create_context({.native_threads=2}));
  HYLE_ASSIGN_OR_RETURN(auto cpu_queue,cpu.create_queue());
  const auto graph_resource=cpu_graph?hyle::mem::system_resource():resource;
  HYLE_ASSIGN_OR_RETURN(auto host_desc,c::TensorDesc::dense(cpu_graph?c::DataType::kFloat32:c::DataType::kFloat16,query_desc.dimensions()));
  HYLE_ASSIGN_OR_RETURN(auto host_pool,c::LeasePool::create(graph_resource,query_words.size()*4+64));
  HYLE_ASSIGN_OR_RETURN(auto host_writer,host_pool.allocate(*host_desc.required_bytes(),64));
  if(cpu_graph){std::vector<float> host_query(query_words.size(),-.125F);HYLE_RETURN_IF_ERROR(host_writer.view()->write(std::as_bytes(std::span(host_query))));}
  else HYLE_RETURN_IF_ERROR(host_writer.view()->write(std::as_bytes(std::span(query_words))));
  HYLE_ASSIGN_OR_RETURN(auto host_read,host_writer.publish());
  HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto qi,builder.input(host_desc));
  HYLE_ASSIGN_OR_RETURN(auto ki,builder.input(recipe.descriptions()[1]));
  HYLE_ASSIGN_OR_RETURN(auto vi,builder.input(recipe.descriptions()[2]));
  HYLE_ASSIGN_OR_RETURN(auto md,schema.metadata_description());
  HYLE_ASSIGN_OR_RETURN(auto mi,builder.input(md));
  std::vector<g::NodePlacement> placements;
  const auto cpu_node=[&](c::Operation operation,g::ValueId input)->Result<g::ValueId>{
    HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(operation,std::array{input}));
    placements.push_back({node,g::cpu_cuda::kCpuTarget,g::PlacementStrength::kRequired});return builder.result(node);
  };
  auto qhalf=qi;
  if(cpu_graph){HYLE_ASSIGN_OR_RETURN(qhalf,cpu_node(c::Operation(c::Unary{c::UnaryKind::kAbs}),qi));
    HYLE_ASSIGN_OR_RETURN(qhalf,cpu_node(c::Operation(c::Cast{c::DataType::kFloat16}),qhalf));}
  HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(c::Operation::custom(c::PagedAttention{capacity,.125F,true,16}),std::array{qhalf,ki,vi,mi}));
  HYLE_ASSIGN_OR_RETURN(auto output,builder.result(node));
  if(cpu_graph){HYLE_ASSIGN_OR_RETURN(output,cpu_node(c::Operation(c::Cast{c::DataType::kFloat32}),output));
    HYLE_ASSIGN_OR_RETURN(output,cpu_node(c::Operation(c::Unary{c::UnaryKind::kNeg}),output));}
  HYLE_RETURN_IF_ERROR(builder.publish(output));HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
  g::CompiledGraph compiled;
#if defined(HYLE_ENCODED_CUDA)
  if(cpu_graph){placements.push_back({node,g::cpu_cuda::kCudaTarget,g::PlacementStrength::kRequired});
    const std::array external{g::ExternalResourceContract{qi,g::cpu_cuda::kHostStorage},g::ExternalResourceContract{output,g::cpu_cuda::kHostStorage}};
    HYLE_ASSIGN_OR_RETURN(compiled,g::cpu_cuda::compile(graph,{&cpu,&context,hyle::mem::system_resource(),&staging,&device},
        {.node_placements=placements,.external_resources=external}));
  }else
#endif
  {const std::array domains{g::StorageDomain{resource}};const std::array targets{g::ExecutionTarget{&context,g::StorageDomainId{0}}};
    HYLE_ASSIGN_OR_RETURN(compiled,g::compile(graph,{.storage_domains=domains,.targets=targets},{.operation_fallback=g::OperationFallbackPolicy::kReject}));}
  std::vector<gb::LaneBinding> lanes{{g::ExecutionLaneId{0},&context,&queue,host_resource}};
#if defined(HYLE_ENCODED_CUDA)
  if(cpu_graph)lanes.push_back({g::ExecutionLaneId{1},&cpu,&cpu_queue,hyle::mem::system_resource()});
#endif
  HYLE_ASSIGN_OR_RETURN(auto graph_native,gb::Invocation::create(compiled.executable,lanes));
  HYLE_ASSIGN_OR_RETURN(auto joint_slot,gb::PendingInvocation::create(std::move(graph_native),4));
  const std::array versions{gb::NodeLayout{node,layout}};
  HYLE_ASSIGN_OR_RETURN(auto out_desc,c::TensorDesc::dense(cpu_graph?c::DataType::kFloat32:c::DataType::kFloat16,
      std::array<std::int64_t,3>{query_rows,8,dv}));
  HYLE_ASSIGN_OR_RETURN(auto output_pool,c::LeasePool::create(graph_resource,*out_desc.required_bytes()+64));
  c::ReadLease previous_output;

''' +s[b:]
a=s.index('  const auto failed_result=');b=s.index('  for(unsigned step=',a)
s=s[:a]+'''  const auto failed_result=[&](c::Completion &done,auto &slot,c::CopyBatchUpdate &update)->Status{
    HYLE_RETURN_IF_ERROR(require(done.wait().IsInvalidArgument(),"encoded source completion lost numeric error"));
    done={};HYLE_ASSIGN_OR_RETURN(update,slot.take_update());
    for(unsigned port=2;port<2+2*requests;++port)HYLE_RETURN_IF_ERROR(require(!update.take_mutable({port}),"failed encoder source published a page writer"));
    std::vector<std::uint8_t> bytes(vb);HYLE_RETURN_IF_ERROR(read_bytes(context,resource,vr[1],bytes));
    return require(bytes==constant_q8(.125F,16*2*dv,true),"failed new-page update changed old reader bytes");
  };
''' +s[b:]
s=s.replace('if(combined)HYLE_RETURN_IF_ERROR(joint_slot.prepare_batch(versions));','if(combined)HYLE_RETURN_IF_ERROR(joint_slot.prepare_batch(versions));')
s=s.replace('    HYLE_RETURN_IF_ERROR(copy.reset());\n    std::array','    HYLE_RETURN_IF_ERROR(copy.reset());previous_output={};\n    std::array')
s=s.replace('      ranges.push_back({{1},{3+2*request},{1},request*vrb,vrb,vrb});','      const bool paired=invalid?paired_failure:step%2==0;\n      ranges.push_back({{paired?0u:1u},{3+2*request},{1},(paired?kbytes:0)+request*vrb,vrb,vrb});')
a=s.index('    HYLE_ASSIGN_OR_RETURN(auto kt,upload');b=s.index('    const std::array<c::CopyPhase,2> phases',a)
s=s[:a]+'''    HYLE_ASSIGN_OR_RETURN(auto kinput,hyle::mem::Buffer::create(resource,kin.size()*4,64));
    HYLE_ASSIGN_OR_RETURN(auto vinput,hyle::mem::Buffer::create(resource,vin.size()*4,64));
    HYLE_RETURN_IF_ERROR(kinput.view().write(std::as_bytes(std::span(kin))));HYLE_RETURN_IF_ERROR(vinput.view().write(std::as_bytes(std::span(vin))));
    HYLE_ASSIGN_OR_RETURN(auto kt,c::ConstTensorView::create(kd,kinput.view()));HYLE_ASSIGN_OR_RETURN(auto vt,c::ConstTensorView::create(vd,vinput.view()));
    const auto submit_encoder=[&](Encoder &encoder,std::span<const c::ConstTensorView> inputs,
                                  std::span<const c::TensorDesc> outputs,c::WriteLease &writer)->Result<c::Completion>{
      HYLE_RETURN_IF_ERROR(encoder.invocation.reset());
      for(std::size_t i=0;i<inputs.size();++i)HYLE_RETURN_IF_ERROR(encoder.invocation.bind(encoder.inputs[i],inputs[i]));
      HYLE_ASSIGN_OR_RETURN(auto storage,writer.view());std::size_t offset=0;
      for(std::size_t i=0;i<outputs.size();++i){HYLE_ASSIGN_OR_RETURN(auto bytes,outputs[i].required_bytes());
        HYLE_ASSIGN_OR_RETURN(auto view,storage.subview(offset,bytes));HYLE_ASSIGN_OR_RETURN(auto tensor,c::TensorView::create(outputs[i],view));
        HYLE_RETURN_IF_ERROR(encoder.invocation.bind(encoder.outputs[i],tensor));offset+=bytes;}
      HYLE_ASSIGN_OR_RETURN(auto writing,uses.begin());HYLE_RETURN_IF_ERROR(writing.write(writer));
      HYLE_ASSIGN_OR_RETURN(auto done,encoder.invocation.submit(queue));HYLE_RETURN_IF_ERROR(writing.attach(done));return done;
    };
    if(invalid?paired_failure:step%2==0){
      HYLE_ASSIGN_OR_RETURN(auto writer,source_pool.allocate(kbytes+vbytes,64));
      HYLE_ASSIGN_OR_RETURN(auto done,submit_encoder(pe,std::array{kt,vt},std::array{kc,vc},writer));
      HYLE_RETURN_IF_ERROR(copy.bind_mutable({0},std::move(writer)));HYLE_RETURN_IF_ERROR(copy.bind_producer({0},std::move(done)));
      HYLE_RETURN_IF_ERROR(require(!writer.valid() && !done.valid(),"paired encoder storage/completion was not retained"));
    }else{
      HYLE_ASSIGN_OR_RETURN(auto kwriter,source_pool.allocate(kbytes,64));HYLE_ASSIGN_OR_RETURN(auto vwriter,source_pool.allocate(vbytes,64));
      HYLE_ASSIGN_OR_RETURN(auto kdone,submit_encoder(ke,std::array{kt},std::array{kc},kwriter));
      HYLE_ASSIGN_OR_RETURN(auto vdone,submit_encoder(ve,std::array{vt},std::array{vc},vwriter));
      HYLE_RETURN_IF_ERROR(copy.bind_mutable({0},std::move(kwriter)));HYLE_RETURN_IF_ERROR(copy.bind_mutable({1},std::move(vwriter)));
      HYLE_RETURN_IF_ERROR(copy.bind_producer({0},std::move(kdone)));HYLE_RETURN_IF_ERROR(copy.bind_producer({1},std::move(vdone)));
      HYLE_RETURN_IF_ERROR(require(!kdone.valid() && !vdone.valid(),"independent original completions were not retained"));
    }
''' +s[b:]
s=s.replace('read_bytes(context,device,','read_bytes(context,resource,')
s=s.replace('decoded_constant(key_incoming[request])','decoded_constant(key_incoming[request],false)')
s=s.replace('decoded_constant(j<16?.0625F:j==16?(request?.25F:.125F):incoming[request])','decoded_constant(j<16?.0625F:j==16?(request?.25F:.125F):incoming[request],true)')
s=s.replace('(combined?-1:1)*sum/denominator','(cpu_graph?-1:1)*sum/denominator')
a=s.index('    if(combined){\n      HYLE_RETURN_IF_ERROR(joint_slot.bind');b=s.index('    const auto expected_bytes=',a)
s=s[:a]+'''    if(combined){
      HYLE_RETURN_IF_ERROR(joint_slot.bind(qi,host_desc,host_read));HYLE_RETURN_IF_ERROR(joint_slot.bind(ki,kframe));HYLE_RETURN_IF_ERROR(joint_slot.bind(vi,vframe));
      HYLE_ASSIGN_OR_RETURN(auto writer,output_pool.allocate(*out_desc.required_bytes(),64));
      HYLE_RETURN_IF_ERROR(joint_slot.bind(output,out_desc,std::move(writer)));
      HYLE_ASSIGN_OR_RETURN(auto done,joint_slot.submit(std::move(update)));
      if(invalid){HYLE_RETURN_IF_ERROR(require(!joint_slot.output(output),"failed source exposed Graph output"));
        HYLE_RETURN_IF_ERROR(failed_result(done,joint_slot,update));return Status::Ok();}
      HYLE_RETURN_IF_ERROR(done.wait());
      {HYLE_ASSIGN_OR_RETURN(auto result,joint_slot.output(output));HYLE_ASSIGN_OR_RETURN(previous_output,result.storage_lease());
        if(cpu_graph)HYLE_RETURN_IF_ERROR(previous_output.view()->read(std::as_writable_bytes(std::span(actual))));
        else {std::vector<std::uint16_t> words(actual.size());HYLE_RETURN_IF_ERROR(previous_output.view()->read(std::as_writable_bytes(std::span(words))));
          for(std::size_t i=0;i<words.size();++i)actual[i]=float(half_test::decode(F16::from_bits(words[i])));}
        HYLE_RETURN_IF_ERROR(check(actual));HYLE_RETURN_IF_ERROR(require(!joint_slot.take_update(),"retained Graph output released update"));}
      done={};HYLE_ASSIGN_OR_RETURN(update,joint_slot.take_update());
    }else{
      HYLE_ASSIGN_OR_RETURN(auto done,receiver.submit(query,kframe,vframe,std::move(update)));
      if(invalid){HYLE_RETURN_IF_ERROR(require(!receiver.output(),"failed source exposed Direct output"));
        HYLE_RETURN_IF_ERROR(failed_result(done,receiver,update));return Status::Ok();}
      HYLE_RETURN_IF_ERROR(done.wait());
      {HYLE_ASSIGN_OR_RETURN(auto result,receiver.output());std::vector<std::uint16_t> words(actual.size());
        HYLE_RETURN_IF_ERROR(result.view()->read(std::as_writable_bytes(std::span(words))));
        for(std::size_t i=0;i<words.size();++i)actual[i]=float(half_test::decode(F16::from_bits(words[i])));
        HYLE_RETURN_IF_ERROR(check(actual));HYLE_RETURN_IF_ERROR(require(!receiver.take_update(),"retained Direct output released update"));}
      done={};HYLE_ASSIGN_OR_RETURN(update,receiver.take_update());
    }
''' +s[b:]
s=s.replace('constant_q8(request?.25F:.125F,16*2*dv),dirty=constant_q8(incoming[request],2*dv)','constant_q8(request?.25F:.125F,16*2*dv,true),dirty=constant_q8(incoming[request],2*dv,true)')
a=s.index('  HYLE_ASSIGN_OR_RETURN(auto old_done,old_slot.submit());');b=s.index('    for(unsigned request=',a)
s=s[:a]+'''  HYLE_ASSIGN_OR_RETURN(auto old_done,old_prepared.run(query,old_key,old_value));HYLE_RETURN_IF_ERROR(old_done.wait());
  {HYLE_ASSIGN_OR_RETURN(auto result,old_slot.output());std::vector<std::uint16_t> words(query_rows*8*dv);
    HYLE_RETURN_IF_ERROR(result.view()->read(std::as_writable_bytes(std::span(words))));
''' +s[b:]
s=s.replace('old_done.completion().wait()','old_done.wait()')
s=s.replace('decoded_constant(.0625F)','decoded_constant(.0625F,true)').replace('decoded_constant(request?.25F:.125F)','decoded_constant(request?.25F:.125F,true)')
s=s.replace('constant_q8(.0625F,16*2*dv)','constant_q8(.0625F,16*2*dv,true)').replace('constant_q8(.125F,16*2*dv)','constant_q8(.125F,16*2*dv,true)')
s=s.replace('combined?"CPU+GPU":"native"','mode==2?"CPU+CUDA":combined?"Graph":"Direct"')
s=s.replace(' Q8 delta D',' encoded delta D')
a=s.index('TEST(EncodedNativePages,')
s=s[:a]+'''TEST(EncodedCommonPages, IncrementalProducersDirectGraphAndJoint){
#if defined(HYLE_ENCODED_CUDA)
  constexpr unsigned modes=3;
#else
  constexpr unsigned modes=2;
#endif
  for(unsigned mode=0;mode<modes;++mode)for(bool single:{false,true})
    for(auto dims:{std::array{64u,128u},std::array{256u,256u}}){
      SCOPED_TRACE(::testing::Message()<<"mode="<<mode<<" single="<<single<<" D="<<dims[0]<<"/"<<dims[1]);
      const auto status=episode(dims[0],dims[1],mode,false,false,single);ASSERT_TRUE(status.ok())<<status.message();
    }
}
TEST(EncodedCommonPages, FailedEncoderRetainsOriginalFailureAndWriters){
#if defined(HYLE_ENCODED_CUDA)
  constexpr unsigned modes=3;
#else
  constexpr unsigned modes=2;
#endif
  for(unsigned mode=0;mode<modes;++mode)for(bool paired:{false,true}){
    SCOPED_TRACE(::testing::Message()<<"mode="<<mode<<" paired="<<paired);
    const auto status=episode(64,128,mode,true,paired);ASSERT_TRUE(status.ok())<<status.message();
  }
}
'''
s=s.replace('std::vector<std::uint8_t> constant_q8(float value, std::size_t elements) {','''std::vector<std::uint8_t> constant_q8(float value, std::size_t elements,[[maybe_unused]] bool is_value=false) {
#if defined(HYLE_ENCODED_CUDA)
  const float target=value/(is_value?2.F:.5F);
  unsigned selected=0;double error=std::numeric_limits<double>::infinity();
  for(unsigned code=0;code<=126;++code){const auto e=code>>3,m=code&7;
    const double decoded=e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6);
    const auto delta=std::abs(std::abs(target)-decoded);
    if(delta<error||(delta==error&&!(code&1))){error=delta;selected=code;}}
  return std::vector<std::uint8_t>(elements,std::uint8_t(selected|(std::signbit(target)?128:0)));
#else''')
s=s.replace('  return bytes;\n}\ndouble decoded_constant(float value) {','''  return bytes;
#endif
}
double decoded_constant(float value,[[maybe_unused]] bool is_value=false) {
#if defined(HYLE_ENCODED_CUDA)
  const auto code=constant_q8(value,1,is_value)[0];const auto e=(code&127)>>3,m=code&7;
  return (code&128?-1:1)*(e?std::ldexp(1.+double(m)/8.,int(e)-7):std::ldexp(double(m)/8.,-6))*(is_value?2:.5);
#else''')
s=s.replace('  return half_test::decode(half_test::encode<F16>(scale)) * code;\n}','  return half_test::decode(half_test::encode<F16>(scale)) * code;\n#endif\n}')
s=s.replace('struct Drain final {\n  hyle::sched::Scheduler &scheduler;\n  ~Drain() { scheduler.drain(); }\n};\n','')
# CPU-only users must not pull CUDA headers through the test fixture.
s=s.replace('#include <hyle/graph/cpu_cuda.h>\n#if defined(HYLE_ENCODED_CUDA)','#if defined(HYLE_ENCODED_CUDA)\n#include <hyle/graph/cpu_cuda.h>')
s=s.replace('placements.push_back({node,g::cpu_cuda::kCpuTarget,g::PlacementStrength::kRequired});return builder.result(node);','''#if defined(HYLE_ENCODED_CUDA)
    placements.push_back({node,g::cpu_cuda::kCpuTarget,g::PlacementStrength::kRequired});
#endif
    return builder.result(node);''')
(ROOT/'tests/compute_batch/encoded_page_common_consumer.cc').write_text(s,encoding='utf-8',newline='\n')
print('wrote',len(s.splitlines()),'lines')
