from pathlib import Path
import hashlib,json,re,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3]
RUN=ROOT/'.scratch/inference-gaps/g04-g05/common-encoded'
OUT=ROOT/'evidence/correctness/inference-g04-g05-cpu-only-encoded-page-source'
records=[json.loads((RUN/f'cpu-{i}/result.json').read_text()) for i in range(1,6)]
assert all(record['state'].startswith('TERMINAL_') for record in records)
assert records[-1]['state']=='TERMINAL_PASS'
common=ET.parse(RUN/'cpu-5/tests.xml').getroot()
assert int(common.attrib['tests'])==2 and int(common.attrib['failures'])==0
native=ET.parse(RUN/'cpu-2/tests.xml').getroot()
selected=[case for suite in native for case in suite if suite.attrib['name']!='EncodedCommonPages']
assert len(selected)==15 and all(case.find('failure') is None and case.attrib.get('status')=='run' for case in selected)
# The native product bytes were not changed while fixing the new consumer.
for name,digest in records[1]['inputs'].items():
 if name.startswith(('src/','include/','third_party/','cmake/')):
  assert records[-1]['inputs'][name]==digest,name
fixture='tests/compute_batch/encoded_page_common_consumer.cc'
assert hashlib.sha256((ROOT/fixture).read_bytes()).hexdigest()==records[-1]['inputs'][fixture]
configure=(RUN/'cpu-2/configure.log').read_text(encoding='utf-8',errors='replace')
pin=re.search(r'-- ggml commit:\s*(\S+)',configure).group(1)
assert pin.startswith('ffa4e8b80930029a35991f94e7c8a93cd67730ab')
assert 'linkage=static' in configure and 'HYLE_TESTING = OFF' in configure
OUT.mkdir(parents=True,exist_ok=False)
result={
 'kind':'G04_G05_CPU_ONLY_ENCODER_F2_DIRECT_GRAPH_SOURCE_STAGE',
 'verdict':'PASS_FINITE_WINDOWS_CPU_ONLY_SOURCE',
 'owners_remain':'AUDITED; whole G04/G05 not accepted',
 'identity':{'host':records[-1]['identity'],'cpu':'13th Gen Intel Core i9-13900K,24cores/32logical',
   'os':'Windows11 Pro for Workstations 10.0.26200 build26200','ggml':pin,'delivery':'ordinary static source, HYLE_TESTING OFF'},
 'fixture_sha256':records[-1]['inputs'][fixture],
 'qualified':[
  'CPU-only ffa original native encoder/math15 test cases all PASS in attempt2, whose aggregate run remains FAIL due new fixture',
  'Final new two consumer tests PASS:8successful Direct/Graph episodes x6updates plus4 synchronous source failure episodes',
  'Single/multi request, activeQ1/18, Q8 K/V, F16 Q/output, independent D64/128 and main D256/256, window16',
  'Paired Graph publishes two disjoint encoded outputs in one caller-owned WriteLease, one original Completion/F1 ticket/F2 producer0',
  'Independent K/V Graphs publish separate original Completion and writer0/1; original F2 Update feeds page receiver or Graph',
  'Nonzero K with independently weighted softmax and explicit CPU Abs/Cast and Cast/Neg Graph journey',
  'Exact dirty byte report, complete K/V byte oracles, shared clean page unchanged, old reader permission and math across new versions',
  'CPU failed encoder remains original synchronous failure: no producer/F2 submission, no result, retired original guards, all target writers returned uninitialized, old page unchanged',
  'Original inline completion may permit Update recovery; retained output still prevents preparation/overwrite'],
 'bounded_readonly_review':'Original post-final-error output check added for asynchronous branch; CPU refusal branch is separately labelled, no fabricated failed Completion or suffix',
 'P0':'Original shared Queue, Graph/one-op prepared routes, F1 ticket, F2 controllers and native batch reused. '
      'Caller supplies dirty-only storage and actual Completion. No new runtime/API/controller, no full-history decode. '
      'Normal Graph fallback policy may wrap native one-op kernels; this is not an algorithmic CPU fallback.',
 'not_proven':['CUDA/CPU+CUDA new consumer stage','BF16 encoded F2/Graph qualification','complete new-domain risks/installed SDK/P1',
               'tiny-scale subnormal/FTZ/reciprocal-overflow input matrix','whole G04/G05 and remaining goal items'],
 'native_math_cases':[case.attrib for case in selected],
 'runs':[{**{k:v for k,v in record.items() if k!='inputs'},'attempt':i} for i,record in enumerate(records,1)],
 'cumulative_seconds':sum(record['cumulative_seconds'] for record in records)}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for i in range(1,6):
  for file in sorted((RUN/f'cpu-{i}').iterdir()):
   if file.is_file():archive.write(file,f'cpu-{i}/{file.name}')
 for name in ['run_common_encoded_cpu.py','create_common_encoded_consumer.py','seal_common_cpu.py']:
  archive.write(RUN.parent/name,name)
print(json.dumps({'native_math_pass_cases':15,'new_consumer_pass_tests':2,'cumulative_seconds':result['cumulative_seconds']}))
