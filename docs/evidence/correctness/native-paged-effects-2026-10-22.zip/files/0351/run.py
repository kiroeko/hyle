"""Run the actual native Vulkan consumer with its recorded cached runtime."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ah_host_helpers',S/'build_windows.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
image_dir=S/'vulkan-link1'
ready=h.c.read(image_dir/'ready.json')
assert h.b.identity(ready['image']['path'])['sha256']==ready['image']['sha256']
runtime=h.c.read(image_dir/'runtime-environment.json')
out=S/'vulkan-run1'
out.mkdir(exist_ok=False)
env=os.environ.copy()
env['PATH']=runtime['PATH']
h.c.execute('run',[ready['image']['path']],env,out)
print('native Vulkan append actual run PASS',flush=True)
