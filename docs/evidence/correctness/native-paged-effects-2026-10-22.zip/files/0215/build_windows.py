"""Focused cached host-owner rebuilds; no SDK, shader or NVCC rebuild."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
A = R / '.scratch/architecture-refactor-2026-10-18'
spec = importlib.util.spec_from_file_location('ah_cached_helpers', R / '.scratch/qwen-cublas-scores-20261022/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
RECIPES = {
 'resources': R/'.scratch/qwen-mtp-round-20261022/compile1/resources/identity.json',
 'batch': R/'.scratch/qwen-mtp-round-20261022/compile1/batch/identity.json',
 'append': R/'.scratch/qwen-mtp-round-20261022/compile1/append/identity.json',
 'native-batch': R/'.scratch/paged-recording-20261021/checks/attempt1/graph_batch--native_batch_regions/identity.json',
 'cpu-test': R/'.scratch/paged-exclusive-20261021/compile1/cpu-test/identity.json',
 'vk-region': A/'quark-fp8-side-2026-10-21/windows/checks/attempt1/vulkan-native-region/identity.json',
 'vk-ragged': A/'compact-mla-e4-reference/vulkan/checks/attempt2/native-ragged-identity.json',
 'vk-paged': A/'compact-mla-e4-reference/common/checks/attempt1/graph_route_vulkan--native_paged_region-9d2919/identity.json',
 'vk-append': A/'quark-fp8-side-2026-10-21/windows/checks/attempt1/vulkan-native-region/identity.json',
 'vk-copy': A/'quark-fp8-side-2026-10-21/windows/checks/attempt1/vulkan-native-region/identity.json',
 'vk-test': A/'quark-fp8-side-2026-10-21/windows/checks/attempt1/vulkan-native-region/identity.json',
}
SOURCES = {
 'native-batch': R/'src/graph_batch/native_batch_regions.cc',
 'cpu-test': R/'tests/graph_batch/paged_append_graph_test.cc',
 'vk-append': R/'src/graph_route_vulkan/native_paged_append.cc',
 'vk-copy': R/'src/compute_route_vulkan/vulkan_copy_recording.cc',
 'vk-test': R/'tests/graph_batch/native_paged_append_consumer.cc',
}

def compile_one(tag, attempt):
    recipe = RECIPES[tag]
    old = c.read(recipe)
    source = SOURCES.get(tag, Path(old['source']['path']))
    out = S/f'compile{attempt}'/tag
    out.mkdir(parents=True, exist_ok=False)
    (out/'tmp').mkdir()
    command = b.host_command(old['command'], source, tag, out)
    assert all(x in command for x in ('/W4', '/WX', '/O2', '/MD'))
    frozen = b.identity(source)
    snap = out/'source'/source.relative_to(R)
    snap.parent.mkdir(parents=True)
    snap.write_bytes(source.read_bytes())
    c.save(out/'plan.json', dict(source=frozen, command=command, recipe=b.identity(recipe), SDK_builds=0, NVCC=0, shaders=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out/f'{tag}-deps.json')['Data']
    deps = list(dict.fromkeys([data['Source'], *data['Includes']]))
    assert b.identity(source) == frozen
    c.save(out/'identity.json', dict(source=frozen, object=b.identity(out/f'{tag}.obj'), command=command,
           recipe=b.identity(recipe), dependencies=[b.identity(x) for x in deps]))
    print('COMPILED', tag, flush=True)

def link_cpu(attempt, link_attempt):
    base_dir=R/'.scratch/qwen-cublas-scores-20261022/qwen-link1'
    base_path=base_dir/'link-plan.json'
    base=c.read(base_path)
    replacements={}
    records=[]
    for tag in ('resources','batch','append','native-batch','cpu-test'):
        path=S/f'compile{attempt}'/tag/'identity.json'
        rec=c.read(path)
        assert all(b.identity(x['path'])==x for x in (rec['source'],rec['object'],*rec['dependencies']))
        old=(c.read(base['consumer_compiled_record']['path']) if tag=='cpu-test' else c.read(RECIPES[tag]))
        replacements[c.key(old['object']['path'])]=rec['object']
        records.append(b.identity(path))
    assert all(b.identity(x['path'])==x for x in base['inputs'])
    for key in replacements:
        assert sum(c.key(x['path'])==key for x in base['inputs'])==1,key
    # Qwen's CUDA closure does not exercise CPU paged attention. Reuse the
    # explicit current HYCA selector/native baseline already proven by the
    # CPU append closure, rather than selecting its older general CPU DLL.
    cpu_dir=R/'.scratch/paged-host-prepare-20261021/cpu-link1'
    cpu_runtime=c.read(cpu_dir/'runtime-environment.json')
    cpu_additions=[b.identity(R/'.scratch/paged-append-20261021/checks/attempt7/compute_ggml_runtime--cpu_program/compute_ggml_runtime--cpu_program.obj'),
                   b.identity(R/'.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/native-baseline.obj')]
    inputs=cpu_additions+[replacements.get(c.key(x['path']),x) for x in base['inputs']]
    command=[replacements.get(c.key(x),{}).get('path',x) for x in base['command']
             if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command[1:1]=[x['path'] for x in cpu_additions]
    out=S/f'cpu-link{link_attempt}'
    out.mkdir(exist_ok=False)
    (out/'tmp').mkdir()
    image=out/'cpu-append.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),compiled_records=records,reused_inputs=len(inputs)-5,SDK_builds=0,NVCC=0))
    env,_=b.environment(command,[x['path'] for x in inputs],out)
    c.execute('link',command,env,out)
    runtime=cpu_runtime
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path'])==dll
        os.link(dll['path'],out/Path(dll['path']).name)
    runtime['PATH']=env['PATH']
    runtime['staged_dlls']=[b.identity(x) for x in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime)
    c.save(out/'ready.json',dict(image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json')))
    print('LINKED cpu',flush=True)

def run_cpu(link_attempt):
    out=S/f'cpu-run{link_attempt}'
    out.mkdir(exist_ok=False)
    image_dir=S/f'cpu-link{link_attempt}'
    runtime=c.read(image_dir/'runtime-environment.json')
    env=os.environ.copy()
    env['PATH']=runtime['PATH']
    c.execute('run',[str(image_dir/'cpu-append.exe')],env,out)
    print('RAN cpu',flush=True)

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('tags', nargs='+', choices=(*RECIPES,'link-cpu','run-cpu'))
    p.add_argument('--attempt', type=int, default=1)
    p.add_argument('--link-attempt', type=int)
    args=p.parse_args()
    for tag in args.tags:
        if tag=='link-cpu': link_cpu(args.attempt,args.link_attempt or args.attempt)
        elif tag=='run-cpu': run_cpu(args.link_attempt or args.attempt)
        else: compile_one(tag, args.attempt)
