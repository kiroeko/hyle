"""Rebuild the single lowering owner exposed by the first native run."""
from pathlib import Path
import base64, json, sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
import mac

source=mac.ROOT/'src/graph_route_apple/apple_lowering.cc'
plan=json.loads((mac.HERE/'mac-plan.json').read_text())
job=next(x for x in plan['jobs'] if x['source']=='src/graph_route_apple/apple_lowering.cc')
archive=next(x for x in plan['archives'] if x['module']=='graph_route_apple')
code=r'''
from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);out=root/'lowering-fix1';out.mkdir()
src=out/'source/src/graph_route_apple/apple_lowering.cc';src.parent.mkdir(parents=True)
raw=base64.b64decode(p['data']);assert hashlib.sha256(raw).hexdigest()==p['source']['sha256'];src.write_bytes(raw)
obj=out/'apple_lowering.o';command=list(p['job']['argv'])
command[command.index('-c')+1]=str(src);command[command.index('-o')+1]=str(obj)
command[command.index('-MF')+1]=str(obj)+'.d'
members=[str(obj) if x==p['job']['object'] else x for x in p['archive']['objects']]
assert sum(x==str(obj)for x in members)==1
lib=out/'libhyle_graph_route_apple.a';link=[str(out/'native-append')if x==str(root/'native-append')else str(lib)if x==p['archive']['path']else x for x in p['link']]
actions=[('compile',command),('archive',['/usr/bin/libtool','-static','-o',str(lib),*members]),('link',link)]
records=[]
for name,argv in actions:
 record=dict(command=argv,cwd=p['sdk']+'/build',started=time.time(),name=name)
 with(out/(name+'.stdout.log')).open('wb')as so,(out/(name+'.stderr.log')).open('wb')as se:
  proc=subprocess.Popen(argv,cwd=p['sdk']+'/build',env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'),stdout=so,stderr=se)
  record.update(pid=proc.pid,terminal=False);(out/'live.json').write_text(json.dumps(record,indent=2)+'\n');rc=proc.wait(timeout=180)
 record.update(exit=rc,terminal=True,finished=time.time());(out/(name+'.result.json')).write_text(json.dumps(record,indent=2)+'\n');(out/'live.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 if rc:break
result=dict(records=records,source=p['source'],all_exit_zero=len(records)==3 and all(x['exit']==0 for x in records))
if result['all_exit_zero']:
 os.link(root/'mlx.metallib',out/'mlx.metallib');image=out/'native-append';raw=image.read_bytes()
 ready=dict(image=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());(out/'ready.json').write_text(json.dumps(ready,indent=2)+'\n');result['ready']=ready
else:result['stderr']=(out/(records[-1]['name']+'.stderr.log')).read_text(errors='replace')
print(json.dumps(result))
'''
result=mac.ssh(code,dict(remote=mac.REMOTE,sdk=mac.SDK,source=mac.ident(source),data=base64.b64encode(source.read_bytes()).decode(),job=job,archive=archive,link=plan['link']),timeout=600)
mac.save(mac.HERE/'mac-lowering-fix1.json',result)
print(json.dumps(dict(all_exit_zero=result['all_exit_zero'],commands=len(result['records']),ready=result.get('ready'),stderr=result.get('stderr'))))
raise SystemExit(0 if result['all_exit_zero']else 1)
