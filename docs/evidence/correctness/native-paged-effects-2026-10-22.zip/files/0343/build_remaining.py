"""Plan/link the exact native Vulkan append consumer; never run it or rebuild SDKs."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[3]
S = R / '.scratch/native-paged-effects-20261022'
V = S / 'vulkan'
BASE = R / '.scratch/architecture-refactor-2026-10-18/quark-block128-scale-2026-10-21/vulkan/checks/link1'
INVENTORY = V / 'link-inventory.json'
AH_RECORDS = {
    'resources': S/'compile1/resources/identity.json',
    'batch': S/'compile2/batch/identity.json',
    'append': S/'compile2/append/identity.json',
    'native-batch': S/'compile2/native-batch/identity.json',
    'vk-region': S/'compile1/vk-region/identity.json',
    'vk-copy': S/'compile1/vk-copy/identity.json',
    'vk-append': S/'compile2/vk-append/identity.json',
    'vk-paged': S/'compile2/vk-paged/identity.json',
    'vk-ragged': S/'compile2/vk-ragged/identity.json',
    'vk-test': S/'compile2/vk-test/identity.json',
}


def read(p):
    return json.loads(Path(p).read_bytes())


def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf8')


def key(p):
    return str(Path(p).resolve()).replace('\\', '/').lower()


def identity(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return dict(path=p.as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def same(record):
    actual = identity(record['path'])
    return (actual['bytes'], actual['sha256']) == (record['bytes'], record['sha256'])


def prepare(link_attempt):
    inv = read(INVENTORY)
    base = read(BASE/'link-plan.json')
    assert len(base['inputs']) == 167
    assert same(inv['plans']['vulkan_skeleton']['identity'])
    assert same(inv['plans']['AD_current']['identity'])
    ah = {tag: read(p) for tag, p in AH_RECORDS.items()}
    for tag, record in ah.items():
        assert same(record['object']), (tag, 'object drift')
        assert same(record['source']), (tag, 'source drift')
    # This mapping is strictly canonical source-owner based. No CUDA object or
    # SDK library is selected by a similarly named basename.
    by_owner = {key(x['source']['path']): (x, AH_RECORDS[tag]) for tag, x in ah.items()}
    replacements = {}
    evidence = []
    for item in inv['replacement_evidence']:
        target = item['to']
        if key(target['source']['path']) in by_owner:
            record, receipt = by_owner[key(target['source']['path'])]
            target_object = record['object']
            source = record['source']
        else:
            receipt = Path(target['record']['path'])
            record = read(receipt)
            target_object, source = record['object'], record['source']
            assert same(source), ('retained owner source drift', source)
        assert same(target_object)
        replacements[key(item['from_object']['path'])] = target_object
        evidence.append(dict(owner=item['owner'], old_object=item['from_object'],
                             object=target_object, compiled_record=identity(receipt)))
    for pending in inv['needs_fresh_compile']:
        record, receipt = by_owner[key(R/pending['owner'])]
        replacements[key(pending['old_object']['path'])] = record['object']
        evidence.append(dict(owner=pending['owner'], old_object=pending['old_object'],
                             object=record['object'], compiled_record=identity(receipt)))
    assert len(inv['remove_old_consumer']) == 1
    old_test = inv['remove_old_consumer'][0]
    replacements[key(old_test['path'])] = ah['vk-test']['object']
    additions = []
    for item in inv['add_objects']:
        if key(item['source']['path']) in by_owner:
            record, receipt = by_owner[key(item['source']['path'])]
            obj = record['object']
        else:
            receipt = Path(item['record']['path'])
            record = read(receipt)
            obj = record['object']
            assert same(record['source'])
        assert same(obj)
        additions.append(obj)
        evidence.append(dict(owner=item['owner'], old_object=None, object=obj,
                             compiled_record=identity(receipt)))
    assert len(additions) == 4
    old_keys = [key(x['path']) for x in base['inputs']]
    assert all(old_keys.count(k) == 1 for k in replacements)
    assert all(same(x) for x in base['inputs'])
    inputs = [replacements.get(key(x['path']), x) for x in base['inputs']] + additions
    assert len(inputs) == 171
    assert len({key(x['path']) for x in inputs}) == len(inputs)
    out = S/f'vulkan-link{link_attempt}'
    image = out/'native-paged-append.exe'
    command = [replacements.get(key(x), {}).get('path', x) for x in base['command']
               if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [x['path'] for x in additions]
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')),
                '/IMPLIB:'+str(image.with_suffix('.lib'))]
    return dict(command=command, inputs=inputs, image=str(image), output=str(out),
                base=identity(BASE/'link-plan.json'), inventory=identity(INVENTORY),
                compiled_records=[identity(p) for p in AH_RECORDS.values()],
                replacements=evidence, consumer_compiled_record=identity(AH_RECORDS['vk-test']),
                product_CXX_jobs=[], additional_CXX=0, links_planned=1,
                SDK_builds=0, GLSL_builds=0, NVCC_builds=0, GPU_runs=0,
                retained_private_ABI_review=dict(
                    ProgramSpecV4='Three recorded older definitions have identical fields to current; only enum tails/inline classifiers changed. Dispatch/ProgramState/Run headers are byte-identical.',
                    Region='Recorded RegionNode/RegionRecipe/RegionBinding fields match current. Region remains one shared_ptr<State>; two nonvirtual detach methods are provided by retained current region.cc.',
                    ResultSlot='Original ResultSlot/ResultStorageOwner fields and old method bodies unchanged. Added detach functions are supplied by the current compute/result.cc addition.',
                    current_private_implementations='Vulkan program.cc and GGML region.cc retained from unbind-native/checks/attempt1 and paired with their current exact private headers.',
                    public_lowering='No change: public Vulkan compile_impl rejects zero-output whole Graph. Native producer constructs its boundary Plan directly in native_region.cc.'),
                limitations=[
                    'No numerical/native pass is implied by this link plan. Root executes the actual consumer.',
                    'Unused quantized/model-specific old objects are retained. Their header hashes alone are not claimed current; no quantized path is under validation.',
                    'Opaque third-party/generated blobs and seven historical identity gaps retain their exact skeleton paths and object SHA. No AD CUDA/native SDK library is substituted.',
                    'Retained AD/common objects are the already-used current closure; source identities are checked, while historic harmless header drift is not presented as fresh compilation.'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'link'))
    parser.add_argument('--link-attempt', type=int, default=1)
    args = parser.parse_args()
    plan = prepare(args.link_attempt)
    if args.action == 'plan':
        save(V/'remaining-jobs.json', plan)
        print(json.dumps(dict(additional_CXX=0, planned_links=1, inputs=len(plan['inputs']),
                              jobs=str(V/'remaining-jobs.json')), indent=2))
        return
    # Only the root invokes this action. There is deliberately no run action.
    spec = importlib.util.spec_from_file_location('ah_link_helpers', R/'.scratch/qwen-cublas-scores-20261022/build.py')
    h = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(h)
    out = Path(plan['output'])
    out.mkdir(parents=True, exist_ok=False)
    (out/'tmp').mkdir()
    save(out/'link-plan.json', plan)
    env, _ = h.b.environment(plan['command'], [x['path'] for x in plan['inputs']], out)
    h.c.execute('link', plan['command'], env, out)
    runtime = read(BASE/'runtime-environment.json')
    runtime['PATH'] = os.pathsep.join([*runtime['runtime'], env['PATH']])
    runtime['base_runtime_environment'] = identity(BASE/'runtime-environment.json')
    save(out/'runtime-environment.json', runtime)
    save(out/'ready.json', dict(image=identity(plan['image']), link_plan=identity(out/'link-plan.json'),
                                consumer_compiled_record=identity(AH_RECORDS['vk-test']),
                                runtime_environment=identity(out/'runtime-environment.json'),
                                CXX=0, SDK_builds=0, shaders=0, GPU_runs=0))
    print('LINKED native Vulkan append; GPU not run', flush=True)


if __name__ == '__main__':
    main()
