"""Explicit Mac cache plan/prepare/compile/link. Import starts no subprocess."""
from pathlib import Path
import argparse, base64, difflib, hashlib, json, re, shlex, subprocess, sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
HOST = 'kiro@172.22.10.198'
BASE = '/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation'
SDK = BASE + '/apple-current-sdk-2026-10-21'
REMOTE = BASE + '/native-paged-effects-20261022'
CONSUMER = 'tests/graph_batch/native_paged_append_consumer.cc'

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def ident(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def ssh(code, payload=None, timeout=90):
    encoded = base64.b64encode(code.encode()).decode()
    command = 'python3 -c "import base64;exec(base64.b64decode(\'' + encoded + '\'))"'
    result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', HOST, command],
        input=json.dumps(payload).encode() if payload is not None else None,
        capture_output=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace') + result.stdout.decode(errors='replace'))
    return json.loads(result.stdout)

COLLECT = r'''
from pathlib import Path
import hashlib,json,re,shlex,subprocess,sys
p=json.load(sys.stdin); root=Path(p['sdk']); build=root/'build'; source=root/'source'
model=subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()
assert model=='Mac16,12',model
rows=json.loads((build/'compile_commands.json').read_text())
compiled=[]
for row in rows:
 a=row.get('arguments')or shlex.split(row['command'])
 if '-o' not in a:continue
 obj=Path(a[a.index('-o')+1]);obj=obj if obj.is_absolute()else Path(row['directory'])/obj
 m=re.search(r'/src/([^/]+)/CMakeFiles/hyle_([^/.]+)\.dir/',str(obj))
 if not m:continue
 compiled.append(dict(file=row['file'],directory=row['directory'],argv=a,object=str(obj),target=str(obj.relative_to(build)),module=m.group(2)))
text=(build/'build.ninja').read_text().replace('$\n','')
archives={}
for line in text.splitlines():
 m=re.match(r'build ([^:]+): \S*STATIC_LIBRARY_LINKER\S* (.*)',line)
 if not m:continue
 output=m.group(1);name=Path(output).name
 if not name.startswith('libhyle_')or not name.endswith('.a'):continue
 objects=[str(build/v)if not Path(v).is_absolute()else v for v in m.group(2).split('|',1)[0].split()if v.endswith('.o')]
 archives[name]=dict(target=output,objects=objects,object_exists=[Path(x).is_file()for x in objects])
dep_process=subprocess.run(['/opt/homebrew/bin/ninja','-C',str(build),'-t','deps'],capture_output=True,text=True,timeout=35)
assert dep_process.returncode==0,dep_process.stderr
deps={};current=None
for line in dep_process.stdout.splitlines():
 if ': #deps 'in line:current=line.split(': #deps ',1)[0];deps[current]=[]
 elif current and line.startswith('    '):deps[current].append(line.strip())
 elif line and not line[0].isspace():current=None
paths=set()
for row in compiled:
 row['deps']=deps.get(row['target']); row['object_exists']=Path(row['object']).is_file()
 for value in [row['file'],*(row['deps']or[])]:
  q=Path(value);q=q if q.is_absolute()else build/q
  if q.is_relative_to(source) and q.is_file():paths.add(q)
hashes={}
for q in sorted(paths):
 raw=q.read_bytes();hashes[q.relative_to(source).as_posix()]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
print(json.dumps(dict(model=model,sdk=str(root),build=str(build),source=str(source),compile=compiled,
 archives=archives,source_hashes=hashes,deps_extraction=dict(argv=['/opt/homebrew/bin/ninja','-C',str(build),'-t','deps'],exit=dep_process.returncode,executes_build=False))))
'''

def current_module_sources(module):
    path = ROOT/'src'/module/'CMakeLists.txt'
    if not path.is_file(): return None, []
    text = re.sub(r'(?m)#.*$', '', path.read_text(encoding='utf-8-sig'))
    match = re.search(r'hyle_add_module\(\s*'+re.escape(module)+r'\s+([^)]*)\)', text, re.S)
    if not match or 'SOURCES' not in match.group(1): return None, []
    words = match.group(1).split('SOURCES', 1)[1].split()
    complete = all(re.fullmatch(r'[A-Za-z0-9_./-]+\.(?:cc|cpp|mm|c|S)', w) for w in words)
    return complete, ['src/'+module+'/'+w for w in words if re.fullmatch(r'[A-Za-z0-9_./-]+\.(?:cc|cpp|mm|c|S)', w)]

def relative_source(path):
    prefix = SDK+'/source/'
    return path[len(prefix):] if path.startswith(prefix) else None

def overlay_command(row, source, obj):
    args = row['argv']; result = [args[0]]; i = 1
    while i < len(args):
        word = args[i]
        if word in ('-o', '-c', '-MF', '-MT', '-MQ'):
            i += 2; continue
        if word in ('-MD', '-MMD'):
            i += 1; continue
        if word == '-I' and i+1 < len(args):
            value = args[i+1]; result += ['-I', value.replace(SDK+'/source', REMOTE+'/source')]; i += 2; continue
        if word.startswith('-I'+SDK+'/source'):
            result.append(word.replace(SDK+'/source', REMOTE+'/source')); i += 1; continue
        result.append(word); i += 1
    result[1:1] = ['-I'+REMOTE+'/source/include', '-I'+REMOTE+'/source']
    result += ['-c', REMOTE+'/source/'+source, '-o', obj, '-MMD', '-MF', obj+'.d']
    return result

def include_closure(sources, commands):
    search = [ROOT/'include', ROOT]
    for command in commands:
        for i, word in enumerate(command):
            value = command[i+1] if word in ('-I','-isystem') and i+1<len(command) else word[2:] if word.startswith('-I') else ''
            if value.startswith(REMOTE+'/source'):
                local = ROOT/value[len(REMOTE+'/source/'):];
                if local.is_dir() and local not in search: search.append(local)
    search += [p for p in (ROOT/'src').iterdir() if p.is_dir()]
    search += [p for p in (ROOT/'third_party').iterdir() if p.is_dir()]
    seen = set()
    def visit(path):
        path = path.resolve()
        if path in seen or not path.is_file() or not path.is_relative_to(ROOT): return
        if '.scratch' in path.relative_to(ROOT).parts: return
        seen.add(path)
        for name in re.findall(r'^\s*#\s*include\s*[<"]([^>"\n]+)[>"]', path.read_text(encoding='utf-8-sig', errors='replace'), re.M):
            for parent in [path.parent, *search]:
                candidate = (parent/name).resolve()
                if candidate.is_file() and candidate.is_relative_to(ROOT): visit(candidate); break
    for source in sources: visit(ROOT/source)
    return sorted(seen)

def plan(args):
    if args.refresh_cache or not (HERE/'mac-cached-closure.json').exists():
        data = ssh(COLLECT, dict(sdk=SDK), timeout=75)
        save(HERE/'mac-cached-closure.json', data)
    else:
        data = json.loads((HERE/'mac-cached-closure.json').read_text())
    inventory = json.loads((HERE/'mac-readonly-recipes.stdout.json').read_text())
    graph_link = inventory['consumer_link_recipes']['graph']['links'][0]['command']
    tokens = shlex.split(graph_link); wanted = {Path(v).name for v in tokens if v.endswith('.a') and Path(v).name.startswith('libhyle_')}
    # This fixture explicitly assembles Graph progress with Scheduler/BlockingPool.
    # mem_vm's public closure also needs platform_fs; timer/container factors
    # used by sched are header-only or already present in the retained closure.
    extra_archives = ['libhyle_graph_progress.a', 'libhyle_sched.a', 'libhyle_mem_vm.a', 'libhyle_platform_fs.a']
    wanted.update(extra_archives)
    cached = {r['object']:r for r in data['compile']}
    jobs = []; archives = []; reused = []; removals = []; blockers = []
    hash_cache = {}
    def changed(rel):
        if rel not in hash_cache:
            path = ROOT/rel; old = data['source_hashes'].get(rel)
            hash_cache[rel] = not path.is_file() or old is None or ident(path)['sha256'] != old['sha256']
        return hash_cache[rel]
    for name in sorted(wanted):
        old_archive = data['archives'].get(name)
        if old_archive is None:
            blockers.append('No original archive object list: '+name); continue
        module = name[len('libhyle_'):-2]; complete, module_sources = current_module_sources(module)
        objects = []; old_sources = set(); dirty = False
        candidates = [r for r in data['compile'] if r['module']==module]
        for obj in old_archive['objects']:
            row = cached.get(obj); rel = relative_source(row['file']) if row else None
            if rel: old_sources.add(rel)
            if rel and complete and rel not in module_sources:
                removals.append(dict(module=module,source=rel,object=obj)); dirty=True; continue
            if not row:
                if not Path(obj).suffix=='.o': blockers.append('Unknown archive object: '+obj)
                objects.append(obj); continue
            reasons=[]
            if not row['object_exists']: reasons.append('cached object absent')
            if row['deps'] is None: reasons.append('no cached dependency evidence')
            if rel and changed(rel): reasons.append(rel)
            for dependency in row['deps'] or []:
                dep = relative_source(dependency)
                if dep and changed(dep): reasons.append(dep)
            if reasons:
                if rel is None:
                    blockers.append('Changed generated TU requires explicit source handling: '+row['file']); objects.append(obj); continue
                target = REMOTE+'/objects/'+module+'/'+Path(row['file']).name+'.o'
                jobs.append(dict(tag=module+'--'+Path(rel).name,source=rel,module=module,original=row,
                    reasons=list(dict.fromkeys(reasons)),object=target,argv=overlay_command(row,rel,target)))
                objects.append(target);dirty=True
            else: objects.append(obj);reused.append(obj)
        for rel in module_sources:
            if rel in old_sources: continue
            if not (ROOT/rel).is_file(): blockers.append('Current CMake source absent: '+rel);continue
            language = Path(rel).suffix
            template = next((x for x in candidates if Path(x['file']).suffix==language), None)
            if template is None: blockers.append('No native language recipe for new source '+rel);continue
            target=REMOTE+'/objects/'+module+'/'+Path(rel).name+'.o'
            jobs.append(dict(tag=module+'--'+Path(rel).name,source=rel,module=module,original=template,
                reasons=['new source in current module CMake'],object=target,argv=overlay_command(template,rel,target)))
            objects.append(target);dirty=True
        archives.append(dict(module=module,old=old_archive,name=name,changed=dirty,
            path=REMOTE+'/lib/'+name if dirty else SDK+'/relocated/sdk/lib/'+name,objects=objects,
            argv=['/usr/bin/libtool','-static','-o',REMOTE+'/lib/'+name,*objects] if dirty else None))
    consumer=ROOT/args.consumer
    consumer_job=None
    if consumer.is_file():
        template=next(r for r in data['compile'] if r['module']=='graph_route_apple' and r['file'].endswith('/native_paged_region.cc'))
        obj=REMOTE+'/objects/consumer.o';argv=overlay_command(template,args.consumer,obj)
        argv[1:1]=['-DHYLE_JOINT_PAGE_APPLE=1']
        consumer_job=dict(tag='consumer',source=args.consumer,module='consumer',object=obj,argv=argv)
    else: blockers.append('Consumer not present yet: '+args.consumer)
    all_jobs=[*jobs,*([consumer_job] if consumer_job else [])]
    files=include_closure([j['source'] for j in all_jobs], [j['argv']for j in all_jobs])
    entries=[]
    for p in files:
        x=ident(p);x['path']=p.relative_to(ROOT).as_posix();entries.append(x)
    link=[];start=tokens.index('/usr/bin/c++');i=start
    replacements={x['name']:x['path']for x in archives}
    while i<len(tokens):
        value=tokens[i]
        if value in ('&&',':'):break
        if value=='-o':link+=['-o',REMOTE+'/native-append'];i+=2;continue
        if value.endswith('/main.cc.o') or value=='CMakeFiles/hyle_package_graph_cpp.dir/main.cc.o':
            link.append(REMOTE+'/objects/consumer.o')
            link.extend(replacements[name] for name in extra_archives)
            i+=1;continue
        if Path(value).name in replacements:value=replacements[Path(value).name]
        link.append(value);i+=1
    result=dict(status='READY_FOR_EXPLICIT_PREPARE' if not blockers else 'PLAN_HAS_BLOCKERS',remote=REMOTE,sdk=SDK,
        consumer=args.consumer,hardware='Mac16,12',jobs=jobs,consumer_job=consumer_job,archives=archives,
        link=link,files=entries,reused_Hyle_objects=reused,removed_sources=removals,blockers=blockers,
        counts=dict(Hyle_CXX_or_ObjCXX=len(jobs),consumer_TU=int(consumer_job is not None),
            reused_Hyle_objects=len(reused),repacked_archives=sum(x['changed']for x in archives),
            overlay_files=len(entries),overlay_bytes=sum(x['bytes']for x in entries)),
        dependency_policy='Original native MLX/ggml archives and native include/generated roots retained; current Hyle source/header owner comparison determines every new TU. No current-core claim from old SDK filenames.',
        fixture_extra_archive_closure=extra_archives,
        caveats=['Static module source lists are exact only for literal SOURCES lists; unresolved platform variable lists retain original objects.','This is an incremental host build plan, not a compilation, link or native validation result.'])
    save(HERE/'mac-plan.json',result);print(json.dumps(dict(status=result['status'],counts=result['counts'],blockers=blockers)))

REMOTE_PREPARE=r'''
from pathlib import Path
import base64,hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['plan']['remote']);allowed=Path(p['base']);assert root.parent==allowed and not root.is_symlink()
assert not root.exists(), 'fresh fixed destination already exists; preserve evidence and choose explicit next attempt'
root.mkdir();(root/'source').mkdir();(root/'objects').mkdir();(root/'lib').mkdir();(root/'receipts').mkdir()
for x in p['files']:
 target=root/'source'/x['path'];target.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(x['data'])
 assert len(raw)==x['bytes']and hashlib.sha256(raw).hexdigest()==x['sha256'];target.write_bytes(raw)
(root/'plan.json').write_text(json.dumps(p['plan'],indent=2)+'\n')
print(json.dumps(dict(status='PREPARED_ONLY',files=len(p['files']),bytes=sum(x['bytes']for x in p['files']),remote=str(root))))
'''

def prepared_plan():
    p=json.loads((HERE/'mac-plan.json').read_text())
    if p['blockers']:raise RuntimeError('Resolve plan blockers before remote mutation: '+str(p['blockers']))
    for x in p['files']:
        current=ident(ROOT/x['path'])
        if current['sha256']!=x['sha256']:raise RuntimeError('Source freeze drift: '+x['path'])
    return p

def prepare(args):
    plan=prepared_plan();files=[]
    for x in plan['files']:files.append(dict(x,data=base64.b64encode((ROOT/x['path']).read_bytes()).decode()))
    value=ssh(REMOTE_PREPARE,dict(plan=plan,files=files,base=BASE),timeout=90)
    save(HERE/'mac-prepare-receipt.json',value);print(json.dumps(value))

REMOTE_BUILD=r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);plan=json.loads((root/'plan.json').read_text());assert plan==p['plan'],'prepared plan differs'
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
for x in plan['files']:
 q=root/'source'/x['path'];assert q.stat().st_size==x['bytes']and hashlib.sha256(q.read_bytes()).hexdigest()==x['sha256'],str(q)
actions=plan['jobs']+([plan['consumer_job']]if plan['consumer_job']else[])if p['action']=='compile'else[x for x in plan['archives']if x['changed']]+[dict(tag='link',argv=plan['link'])]
if p['action']=='compile':
 for job in actions:
  prior=root/'receipts'/(job['tag']+'.compile.result.json')
  if prior.is_file():assert json.loads(prior.read_text())['exit']==0,'retained failed compile receipt: '+str(prior)
 if p.get('job'):actions=[x for x in actions if x['tag']==p['job']];assert len(actions)==1,'unknown single job'
 else:
  actions=[x for x in actions if not(root/'receipts'/(x['tag']+'.compile.result.json')).is_file()]
  actions=actions[:p['limit']]
 if not actions:print(json.dumps(dict(action='compile',records=[],all_exit_zero=True,remaining=0)));sys.exit(0)
else:
 for job in plan['jobs']+[plan['consumer_job']]:
  receipt=root/'receipts'/(job['tag']+'.compile.result.json');assert receipt.is_file(),'compile receipt missing: '+job['tag']
  old=json.loads(receipt.read_text());assert old['exit']==0 and Path(job['object']).is_file(),'compile did not succeed: '+job['tag']
records=[]
for job in actions:
 tag=job.get('tag',job.get('module'));command=job['argv'];out=root/'receipts'/(tag+'.'+p['action']);assert not out.with_suffix(out.suffix+'.result.json').exists(),'preserve prior attempt receipt'
 if p['action']=='compile':Path(job['object']).parent.mkdir(parents=True,exist_ok=True)
 start=time.time();env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin')
 record=dict(tag=tag,argv=command,cwd=p['sdk']+'/build',started=start,action=p['action'],native_runs=0,SDK_or_shader_builds=0)
 out.with_suffix(out.suffix+'.command.json').write_text(json.dumps(record,indent=2)+'\n')
 with out.with_suffix(out.suffix+'.stdout.log').open('wb')as so,out.with_suffix(out.suffix+'.stderr.log').open('wb')as se:
  child=subprocess.Popen(command,cwd=p['sdk']+'/build',env=env,stdout=so,stderr=se)
  record.update(pid=child.pid,state='running')
  out.with_suffix(out.suffix+'.command.json').write_text(json.dumps(record,indent=2)+'\n')
  (root/'live.json').write_text(json.dumps(record,indent=2)+'\n')
  child.wait()
 record.update(exit=child.returncode,seconds=time.time()-start,state='terminal')
 output=Path(job.get('object',job.get('path',str(root/'native-append'))))
 if child.returncode==0 and output.is_file():
  raw=output.read_bytes();record['output']=dict(path=str(output),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 out.with_suffix(out.suffix+'.result.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 if child.returncode:break
if p['action']=='link'and records and all(x['exit']==0 for x in records):
 target=root/'mlx.metallib';source=Path(p['sdk'])/'relocated/sdk/lib/mlx.metallib';os.link(source,target)
 result=dict(status='LINKED_NOT_RUN',image=str(root/'native-append'),metallib=str(target),records=records)
 (root/'ready.json').write_text(json.dumps(result,indent=2)+'\n')
remaining=sum(not(root/'receipts'/(j['tag']+'.compile.result.json')).is_file()for j in plan['jobs']+[plan['consumer_job']])
print(json.dumps(dict(action=p['action'],records=records,all_exit_zero=bool(records)and all(x['exit']==0 for x in records),remaining=remaining)))
'''

def build(args):
    p=prepared_plan();value=ssh(REMOTE_BUILD,dict(action=args.action,remote=REMOTE,sdk=SDK,plan=p,job=args.job,limit=args.limit),timeout=2400)
    receipts=HERE/'mac-build-receipts';receipts.mkdir(exist_ok=True)
    target=receipts/(args.action+'-'+str(len(list(receipts.glob(args.action+'-*.json')))+1)+'.json')
    save(target,value);print(json.dumps(dict(action=args.action,count=len(value['records']),all_exit_zero=value['all_exit_zero'],remaining=value.get('remaining'))))
    if not value['all_exit_zero']:raise SystemExit(1)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=['plan','prepare','compile','link']);parser.add_argument('--consumer',default=CONSUMER)
    parser.add_argument('--refresh-cache',action='store_true',help='Re-read original SDK metadata; default reuses the retained read-only inventory')
    parser.add_argument('--job',help='Compile exactly one listed tag')
    parser.add_argument('--limit',type=int,default=4,help='Maximum serial compile jobs in one explicit invocation (default 4)')
    args=parser.parse_args()
    if args.limit<1:parser.error('--limit must be positive')
    if args.action=='plan':plan(args)
    elif args.action=='prepare':prepare(args)
    else:build(args)

if __name__=='__main__':main()
