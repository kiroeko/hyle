"""Run the one linked native consumer, keeping real process/terminal receipts."""
from pathlib import Path
import argparse, json, sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
import mac

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--directory',choices=['lowering-fix1'],default=None)
args=parser.parse_args()
run_root=mac.REMOTE+('/'+args.directory if args.directory else '')

code=r'''
from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(REMOTE)
ready=json.loads((root/'ready.json').read_text())
assert ready['image']==str(root/'native-append')
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
out=root/'native-run1';out.mkdir()
image=root/'native-append';raw=image.read_bytes()
command=[str(image)]
record=dict(command=command,cwd=str(root),started=time.time(),image=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
 child=subprocess.Popen(command,cwd=root,env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'),stdout=so,stderr=se)
 record.update(pid=child.pid,terminal=False)
 (out/'live.json').write_text(json.dumps(record,indent=2)+'\n')
 rc=child.wait(timeout=180)
record.update(exit=rc,terminal=True,finished=time.time())
(out/'live.json').write_text(json.dumps(record,indent=2)+'\n')
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(record=record,stdout=(out/'stdout.log').read_text(errors='replace'),stderr=(out/'stderr.log').read_text(errors='replace'))))
'''.replace('REMOTE',repr(run_root))
result=mac.ssh(code,timeout=210)
mac.save(Path(__file__).resolve().parent/('mac-native-'+(args.directory or 'initial')+'-run1.json'),result)
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(result['record']['exit'])
