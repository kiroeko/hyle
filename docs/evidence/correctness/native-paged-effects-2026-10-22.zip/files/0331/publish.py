"""Preserve this finite native-effect implementation and actual run evidence."""
from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile

S=Path(__file__).resolve().parent
R=S.parents[1]
OUT=R/'docs/evidence/correctness'
NAME='native-paged-effects-2026-10-22'

def read(path): return json.loads(Path(path).read_bytes())
def save(path,value): Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def ident(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

paths=[
 'include/hyle/graph/detail/region_access.h','src/graph/resources.cc',
 'src/graph_batch/batch.cc','src/graph_batch/paged_append.h','src/graph_batch/paged_append.cc',
 'src/graph_batch/native_append_regions.h','src/graph_batch/native_batch_regions.h',
 'src/compute_route_apple/apple_carrier.h','src/compute_route_apple/apple_context.cc',
 'src/compute_route_apple/apple_copy_internal.h','src/compute_route_apple/apple_copy_recording.mm',
 'src/graph_route_apple/native_paged_append_region.h','src/graph_route_apple/native_paged_append_region.cc',
 'src/graph_route_apple/native_region.cc','src/graph_route_apple/native_paged_region.cc',
 'src/graph_route_apple/apple_lowering.cc','src/graph_route_apple/CMakeLists.txt',
 'src/compute_route_vulkan/vulkan_copy_internal.h','src/compute_route_vulkan/vulkan_copy_recording.cc',
 'src/graph_route_vulkan/native_paged_append.h','src/graph_route_vulkan/native_paged_append.cc',
 'src/graph_route_vulkan/native_region.cc','src/graph_route_vulkan/native_paged_region.cc',
 'src/graph_route_vulkan/CMakeLists.txt','tests/graph_batch/native_paged_append_consumer.cc',
 'tests/graph_batch/paged_append_graph_test.cc','tests/graph_batch/CMakeLists.txt',
 'docs/developer/current-work.md','docs/architecture/compute-design.md',
 'docs/architecture/graph-design.md','docs/user/batch-attention.md']
sources=[dict(relative=p,**ident(R/p)) for p in paths]
cpu=read(S/'cpu-run2/run.result.json')
vk=read(S/'vulkan-run1/run.result.json')
metal=read(S/'apple/mac-native-lowering-fix1-run1.json')
assert cpu['exit']==vk['exit']==metal['record']['exit']==0
cpu_out=(S/'cpu-run2/run.stdout.log').read_text()
vk_out=(S/'vulkan-run1/run.stdout.log').read_text()
assert cpu_out.count('PASS')==13
assert vk_out.count('PASS')==metal['stdout'].count('PASS')==3
assert not metal['stderr'] and not (S/'vulkan-run1/run.stderr.log').read_bytes()
mac_compile=read(S/'apple/mac-build-receipts/compile-1.json')
assert len(mac_compile['records'])==49 and mac_compile['all_exit_zero']
assert all(x['exit']==0 for x in mac_compile['records'])
mac_fix=read(S/'apple/mac-lowering-fix1.json')
assert mac_fix['all_exit_zero'] and len(mac_fix['records'])==3
assert mac_fix['ready']['sha256']==metal['record']['image']['sha256']
download=read(S/'apple/mac-log-download-receipt.json')
assert download['status']=='COMPLETE' and download['actual_count']==download['expected_count']==253
gpu=subprocess.run(['nvidia-smi','--query-gpu=name,uuid,driver_version,memory.total','--format=csv,noheader'],capture_output=True,text=True,check=True)
save(S/'hardware-windows.json',dict(command=gpu.args,exit=gpu.returncode,stdout=gpu.stdout,stderr=gpu.stderr))
win_records=sorted(S.glob('compile*/**/identity.json'))
assert len(win_records)==17
summary=dict(
 title='普通Graph的Apple/Metal与Vulkan原生分页写入effect接线',date='2026-10-22',
 status='IMPLEMENTED_WITH_THE_BOUNDED_CPU_METAL_VULKAN_RUNS_LISTED_BELOW',
 scope='普通Graph的原生producer、无tensor输出PagedAppend、COW及同图分页reader。不是完整Qwen跨平台/MTP/量化/质量或性能验收。',
 implementation=[
  '按实际选定native artifact的独立有序写能力准入；保留原共享Queue校验、Graph身份、明确控制依赖及精确页/尾权。',
  '原生slot持有原PagedAppendPages；冷配置复制精确prefix/new-row范围，不入队，不制造ready帧或外部CopyBatchUpdate。',
  'Apple沿原Runtime FIFO、CopyRecording/Metal blit及原native生成输出epoch/pin；reader FIFO预检真实写结果。',
  'Vulkan沿原compute VkQueue/CopyRecording、真实buffer owners及visibility barrier；已知写失败/取消拒绝reader，晚错误汇入整图原Completion。',
  '所有子工作真实退休后才能回收；首次take在撤销准备前锁存所有共享/native事务的整图成功结果。',
  'Apple冷配置先检查原Runtime开放/失败状态；native writer及reader配置改变先使原录制和准备失效。',
  'Apple pure区域按boundary输出检查，允许producer服务合法零公开输出effect图；公开wholeGraph无输出仍拒。',
  'Vulkan CMake补列既有native_ragged_region.cc，两端加入同一原生追加消费者测试。'],
 validation=dict(
  CPU=dict(exit=0,checks=13,receipt='stage/cpu-run2/run.result.json',stdout=cpu_out,
      coverage='既有F16/BF16因果oracle、COW/页边界、原帧合成/非顺序页ID/共享旧前缀、符号有限T1/T2、独占尾权rollback、writer-only及wholeGraph失败后不发布/恢复。'),
  Metal=dict(exit=0,model='Mac16,12 / Apple M4 / 16GiB',image=metal['record']['image'],stdout=metal['stdout'],receipt='stage/apple/mac-native-lowering-fix1-run1.json'),
  Vulkan=dict(exit=0,hardware=gpu.stdout.strip(),image=read(S/'vulkan-link1/ready.json')['image'],stdout=vk_out,receipt='stage/vulkan-run1/run.result.json'),
  native_case_geometry=dict(dtype='F16',page_rows=16,qk_and_value_depth=64,query_heads=2,kv_heads=1,
      previous_rows=3,new_rows=2,previous_physical_page=0,cow_page=1,
      old_values=[1,2,3],new_values=[4,5],query_and_keys=0,expected_causal_means=[2.5,3.0],unused_old_tail='NaN bits preserved exactly'),
  native_cases=['缺直接reader依赖，拒绝且不消耗调用方Pages。','原生F32→F16 Cast产出K/V，双writer-only effect，无公开tensor输出。','相同producer及写页直接接同Graph原生因果attention，核独立均值。'],
  native_lifetime_checks=['原旧frame与整页字节/NaN尾不变。','原Pages确实转移；未take时reset拒绝。','双take后两事务均可ready，验证首次take锁存兄弟事务成功结果。','take后未经重绑的旧提交拒绝，ready帧继续持真实旧/新页guard。'],
  builds=dict(Windows_host_CXX=17,Mac_initial_Hyle_CXX_or_ObjCXX=48,Mac_consumer_CXX=1,Mac_corrective_lowering_CXX=1,
      reused_Mac_Hyle_objects=89,Windows_Vulkan_link_inputs=171,SDK_builds=0,NVCC_builds=0,shader_builds=0,
      note='Windows第二批6个owner随共享私有header的准确队列合同注释/冷拒修正刷新；CPU已通过后未为注释重复跑。Mac按缓存源码/依赖差异刷新相关Hyle owner，不重造MLX/ggml。')),
 actual_failures_and_corrections=[
  dict(kind='验证缓存选择',evidence='stage/cpu-run1/run.stderr.log',result='首CPU测试误用CUDA消费者闭包的旧CPU原生DLL，独立ready对照同样非因果。沿已有CPU追加闭包选择既有HYCA selector/baseline及匹配DLL后13项通过；无算术/预期放宽或新SDK构建。'),
  dict(kind='产品实现接缝',evidence='stage/apple/mac-native-run1.json',result='首Metal运行缺edge用例通过，writer-only被Apple lowering的整图公开输出数量门拒绝。只修区域boundary输出门并重编1个TU/重包1库/重链，3例通过，fixture未加假输出。')],
 limitations=[
  '本批原生数值仅F16/page16/D64/单请求2新行及一页COW；BF16行复制已有实现，但其完整native attention/MTP组合未由本批证明。',
  '本批未新增原生在途阻塞取消、故障注入、设备丢失、encoded页写、所有shape/模型或量化测试。CPU失败回归不是原生设备故障验收。',
  'Vulkan保本地固定SDK及其原生ABI；已有旧私有声明字段比对及新detach实现接线，不把未运行的量化叶或七个历史对象身份缺口签为全平台通过。',
  '当前真实Qwen使用compute::PagedAttention(capacity)+显式metadata四输入；本批原生reader是owned-layout的graph::batch::PagedAttention。前者的原生接线是下一明确实现缺口，不能把本批测试算完整Qwen跨平台。',
  '没有Qwen调用或新增TPS/显存性能窗口；current-work页末已有四臂表不改写。'],
 next_action='沿原native页reader冷准备承载Qwen的capacity+metadata合同，先做同一有限Graph的T1/T2及所需精度/状态组合，再换消费者冷装配/加载/I/O；维持原完整head提交协议，不在各层新增平台分支。',
 sources=sources,
 reproduction=dict(Windows_CPU='python .scratch/native-paged-effects-20261022/build_windows.py resources batch append native-batch cpu-test; link-cpu/run-cpu使用已有正确CPU原生闭包（原实际命令在记录中）。',
   Windows_Vulkan='build_windows.py相关owner编译；vulkan/build_remaining.py link；vulkan/run.py。精确原命令见各compile/link/run receipt。',
   Mac='apple/mac.py prepare; compile --limit 49; link; 首运行保留；apple/correct_lowering.py; apple/run_mac.py --directory lowering-fix1。使用旧SDK缓存原址，固定Mac16,12。',
   evidence='ZIP按SHA去重保存当前源码、可用before/diff、命令、构建身份及实际日志；不归档SDK、对象、DLL、可执行文件、metallib或大link maps。'))
save(S/'evidence-summary.json',summary)

# Deduplicate exact source/log copies while preserving every logical name.
items={}
def add(path,logical):
 raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest()
 if sha in items:items[sha]['aliases'].append(logical)
 else:items[sha]=dict(source=path,bytes=len(raw),sha256=sha,aliases=[logical])
for source in sources:add(Path(source['path']),'source/'+source['relative'])
for path in sorted(S.rglob('*')):
 if path.is_file() and path.suffix.lower() in {'.json','.py','.ps1','.cc','.h','.mm','.diff','.log','.txt'}:
  if '__pycache__' not in path.parts:add(path,'stage/'+path.relative_to(S).as_posix())
archive=OUT/(NAME+'.zip');OUT.mkdir(parents=True,exist_ok=True)
index=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,item in enumerate(items.values()):
  member=f'files/{n:04d}/'+Path(item['aliases'][0]).name
  z.write(item['source'],member)
  index.append(dict(member=member,bytes=item['bytes'],sha256=item['sha256'],aliases=item['aliases']))
 z.writestr('archive-index.json',json.dumps(index,indent=2,ensure_ascii=False)+'\n')
with zipfile.ZipFile(archive) as z:
 for item in index:
  raw=z.read(item['member']);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
summary['archive']=dict(**ident(archive),unique_files=len(index),logical_files=sum(len(x['aliases'])for x in index),uncompressed_unique_bytes=sum(x['bytes']for x in index),all_archived_SHA_verified=True)
save(OUT/(NAME+'.json'),summary)
save(S/'published.json',dict(manifest=ident(OUT/(NAME+'.json')),archive=summary['archive']))
print(json.dumps(dict(manifest=ident(OUT/(NAME+'.json')),archive_bytes=summary['archive']['bytes'],unique_files=len(index)),ensure_ascii=False))
