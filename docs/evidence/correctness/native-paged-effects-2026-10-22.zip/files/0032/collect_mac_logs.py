"""Download only this round's exact receipts/logs. Root invokes download explicitly."""
from pathlib import Path
import argparse, base64, hashlib, importlib.util, json, sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent

def expected_files(plan):
    files=[]
    for job in [*plan['jobs'], plan['consumer_job']]:
        for suffix in ['command.json','result.json','stdout.log','stderr.log']:
            files.append('receipts/'+job['tag']+'.compile.'+suffix)
    for job in [x for x in plan['archives'] if x['changed']]:
        for suffix in ['command.json','result.json','stdout.log','stderr.log']:
            files.append('receipts/'+job['module']+'.link.'+suffix)
    for suffix in ['command.json','result.json','stdout.log','stderr.log']:
        files.append('receipts/link.link.'+suffix)
    files += ['ready.json','live.json']
    for action in ['compile','archive','link']:
        files += ['lowering-fix1/'+action+'.'+suffix for suffix in ['result.json','stdout.log','stderr.log']]
    files += ['lowering-fix1/ready.json','lowering-fix1/live.json']
    for prefix in ['native-run1','lowering-fix1/native-run1']:
        files += [prefix+'/'+name for name in ['result.json','live.json','stdout.log','stderr.log']]
    assert len(files)==len(set(files))
    return files

REMOTE_READ = r'''
from pathlib import Path
import base64,hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['root']).resolve();assert root.name=='native-paged-effects-20261022'
rows=[];missing=[];total=0
for relative in p['files']:
 q=(root/relative).resolve();assert q.is_relative_to(root)
 if not q.is_file():missing.append(relative);continue
 assert q.suffix in {'.json','.log'} and not q.is_symlink(),str(q)
 raw=q.read_bytes();total+=len(raw);assert total<=16*1024*1024,'unexpected log volume'
 rows.append(dict(path=relative,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data=base64.b64encode(raw).decode()))
print(json.dumps(dict(status='COMPLETE' if not missing else 'MISSING_FILES',root=str(root),files=rows,missing=missing,total_bytes=total)))
'''

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=['plan','download']);args=parser.parse_args()
    plan=json.loads((HERE/'mac-plan.json').read_text());files=expected_files(plan)
    output=dict(remote=plan['remote'],files=files,expected_count=len(files),excluded=['objects','archives','images','metallib','SDK','source tree'],native_runs=0)
    (HERE/'mac-log-download-plan.json').write_text(json.dumps(output,indent=2)+'\n')
    if args.action=='plan':print(json.dumps(dict(files=len(files),native_runs=0)));return
    spec=importlib.util.spec_from_file_location('ah_mac_read_only',HERE/'mac.py');mac=importlib.util.module_from_spec(spec);spec.loader.exec_module(mac)
    result=mac.ssh(REMOTE_READ,dict(root=plan['remote'],files=files),timeout=60)
    destination=HERE/'downloaded-logs';destination.mkdir(exist_ok=True)
    manifest=[]
    for row in result['files']:
        raw=base64.b64decode(row['data']);assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
        target=destination/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert target.read_bytes()==raw,'existing downloaded evidence differs'
        else:target.write_bytes(raw)
        manifest.append({k:v for k,v in row.items() if k!='data'})
    receipt=dict(status=result['status'],remote=result['root'],files=manifest,missing=result['missing'],total_bytes=result['total_bytes'],actual_count=len(manifest),expected_count=len(files),native_runs=0)
    (HERE/'mac-log-download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
    if result['missing']:raise SystemExit(1)

if __name__=='__main__':main()
