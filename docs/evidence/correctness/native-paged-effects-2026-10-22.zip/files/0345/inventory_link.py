"""Read only the two declared closures and adjacent object identities; no build/run."""
from pathlib import Path
import difflib
import hashlib
import json

R = Path(__file__).resolve().parents[3]
S = R / '.scratch/native-paged-effects-20261022'
V = S / 'vulkan'
PLANS = {
    'vulkan_skeleton': R / '.scratch/architecture-refactor-2026-10-18/quark-block128-scale-2026-10-21/vulkan/checks/link1/link-plan.json',
    'AD_current': R / '.scratch/qwen-cublas-scores-20261022/qwen-link1/link-plan.json',
}


def key(p):
    return str(Path(p).resolve()).replace('\\', '/').lower()


def read(p):
    return json.loads(Path(p).read_bytes())


def ident(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return dict(path=p.as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def product(p):
    p = Path(p).resolve()
    try:
        rel = p.relative_to(R).as_posix()
    except ValueError:
        return None
    return rel if rel.startswith(('src/', 'include/', 'tools/', 'tests/')) else None


loaded = {}
records = {}
metadata_read = []


def visit(data, receipt):
    if isinstance(data, dict):
        source, obj = data.get('source'), data.get('object')
        if isinstance(source, dict) and isinstance(obj, dict) and source.get('path') and obj.get('path'):
            records.setdefault(key(obj['path']), []).append((data, receipt))
        for value in data.values():
            if isinstance(value, (dict, list)):
                visit(value, receipt)
    elif isinstance(data, list):
        for value in data:
            visit(value, receipt)


def load(p):
    p = Path(p).resolve()
    k = key(p)
    if k not in loaded:
        data = read(p)
        loaded[k] = data
        metadata_read.append(p.as_posix())
        visit(data, p)
    return loaded[k]


def load_plan(p):
    d = load(p)
    for name in ('compiled_records', 'consumer_compiled_record'):
        refs = d.get(name, [])
        if isinstance(refs, dict):
            refs = [refs]
        for ref in refs:
            q = Path(ref['path'])
            if q.is_file():
                load(q)
    return d


plans = {name: load_plan(p) for name, p in PLANS.items()}


def find_record(obj):
    p = Path(obj['path'])
    if p.suffix.lower() != '.obj':
        return None
    # The source receipt must be adjacent to the object, or explicitly named by
    # the closure. No recursive .scratch/SDK inventory is used.
    preferred = [p.parent / 'identity.json', p.with_name(p.stem + '-identity.json')]
    for q in preferred:
        if q.is_file():
            load(q)
    matches = records.get(key(p), [])
    if not matches:
        for q in sorted(p.parent.glob('*identity*.json')):
            load(q)
        matches = records.get(key(p), [])
    exact = [(d, q) for d, q in matches if d['object'].get('sha256') == obj.get('sha256')]
    if not exact:
        return None
    owners = {key(d['source']['path']) for d, _ in exact}
    if len(owners) != 1:
        raise RuntimeError('ambiguous source owner: ' + str(p))
    # Prefer the direct compile identity over an inline replacement entry.
    exact.sort(key=lambda item: ('dependencies' not in item[0], str(item[1])))
    return exact[0]


current_hashes = {}


def current(p):
    k = key(p)
    if k not in current_hashes:
        current_hashes[k] = ident(p) if Path(p).is_file() else None
    return current_hashes[k]


def summarize(obj, index):
    item = dict(index=index, object=obj, exists=Path(obj['path']).is_file())
    found = find_record(obj)
    if not found:
        item['owner_status'] = 'opaque_library' if Path(obj['path']).suffix.lower() == '.lib' else 'missing_adjacent_source_identity'
        return item
    d, receipt = found
    src = d['source']
    rel = product(src['path'])
    item.update(owner_status='exact_object_identity', owner=rel or src['path'], source=src,
                record=ident(receipt), record_has_dependencies='dependencies' in d)
    now = current(src['path']) if rel else None
    item['source_current'] = now
    item['source_matches_current'] = bool(now and now['sha256'] == src.get('sha256'))
    drift = []
    for dep in d.get('dependencies', []):
        if isinstance(dep, dict) and dep.get('path') and product(dep['path']):
            actual = current(dep['path'])
            if not actual or actual['sha256'] != dep.get('sha256'):
                drift.append(dict(recorded=dep, current=actual))
    item['canonical_dependency_drift'] = drift
    item['compile_definitions'] = [x for x in d.get('command', []) if x.startswith(('/D', '-D'))]
    if d.get('replaces'):
        item['replaces'] = d['replaces']
    return item


closures = {name: [summarize(obj, i) for i, obj in enumerate(d['inputs'])] for name, d in plans.items()}
ad_by_owner = {}
for item in closures['AD_current']:
    if item.get('owner', '').startswith('src/'):
        ad_by_owner.setdefault(item['owner'], []).append(item)
ah_by_owner = {}
for p in sorted((S / 'compile1').glob('*/identity.json')):
    d = load(p)
    rel = product(d['source']['path'])
    ah_by_owner[rel] = summarize(d['object'], None)

# Only exact same canonical source owner may be replaced. CUDA-only sources
# are never brought into Vulkan by basename or by similar operation names.
plain_modules = {'graph', 'graph_batch', 'compute', 'compute_batch', 'compute_state',
                 'compute_ops', 'compute_model', 'model', 'container', 'util_core',
                 'simd', 'memory', 'base', 'io'}
decisions = []
for old in closures['vulkan_skeleton']:
    owner = old.get('owner')
    d = dict(vulkan_index=old['index'], owner=owner, old_object=old['object'])
    if owner in ah_by_owner:
        candidate = ah_by_owner[owner]
        d.update(action='replace_with_AH_compile1', candidate=candidate)
    elif owner and owner.startswith(('tests/', 'tools/')):
        d['action'] = 'remove_old_consumer_and_add_new_native_append_consumer'
    elif owner and owner.startswith('src/'):
        matches = ad_by_owner.get(owner, [])
        module = owner.split('/')[1]
        if len(matches) > 1:
            d.update(action='manual_duplicate_AD_owner', candidates=matches)
        elif not matches:
            d['action'] = ('retain_route_specific_or_prepare_fresh_if_needed' if
                           not old['source_matches_current'] or old['canonical_dependency_drift'] else
                           'retain_exact_source_no_AD_equivalent')
        else:
            candidate = matches[0]
            if key(candidate['object']['path']) == key(old['object']['path']):
                d['action'] = 'already_same_object'
            elif module in plain_modules:
                d.update(action='replace_same_owner_with_AD_common', candidate=candidate)
            else:
                d.update(action='manual_route_or_GGML_SDK_ABI_review', candidate=candidate)
    else:
        d['action'] = 'retain_opaque_library_no_cross_SDK_substitution' if old['owner_status'] == 'opaque_library' else 'resolve_missing_source_identity'
    decisions.append(d)

old_owners = {x.get('owner') for x in closures['vulkan_skeleton']}
new_common = [x for x in closures['AD_current'] if x.get('owner', '').startswith('src/')
              and x['owner'].split('/')[1] in plain_modules and x['owner'] not in old_owners]
ah_additions = [x for owner, x in ah_by_owner.items() if owner not in old_owners and owner.startswith('src/')]
freeze_path = V / 'source-freeze.json'
freeze = read(freeze_path)
cmake = R / 'src/graph_route_vulkan/CMakeLists.txt'
cmake_old = next(x['frozen'] for x in freeze['files'] if x['current']['path'].endswith('src/graph_route_vulkan/CMakeLists.txt'))
cmake_diff = ''.join(difflib.unified_diff(Path(cmake_old['path']).read_text(encoding='utf8').splitlines(True),
                                       cmake.read_text(encoding='utf8').splitlines(True),
                                       fromfile='vulkan/source frozen CMakeLists.txt', tofile='root later canonical CMakeLists.txt'))
counts = {action: sum(x['action'] == action for x in decisions) for action in sorted({x['action'] for x in decisions})}

def brief(item):
    return dict(owner=item.get('owner'), object=item['object'], record=item.get('record'),
                source=item.get('source'), source_matches_current=item.get('source_matches_current'),
                drift_paths=[x['recorded']['path'] for x in item.get('canonical_dependency_drift', [])])


replace_objects, evidence, needs_fresh = {}, [], []
for decision in decisions:
    if decision['action'] not in ('replace_with_AH_compile1', 'replace_same_owner_with_AD_common'):
        continue
    candidate = decision['candidate']
    if not candidate['source_matches_current']:
        needs_fresh.append(dict(owner=decision['owner'], old_object=decision['old_object'],
                                previous_candidate=brief(candidate), current_source=current(candidate['source']['path']),
                                reason='Source changed after this cached compile; do not use its object as current.'))
        continue
    replace_objects[decision['old_object']['path']] = candidate['object']['path']
    evidence.append(dict(owner=decision['owner'], from_object=decision['old_object'],
                         to=brief(candidate), origin=decision['action']))

# The already-frozen native import cleanup has two Vulkan-specific owners.
# They may replace Vulkan skeleton owners, but never come from AD's CUDA SDK.
for tag in ('program', 'provider-region'):
    p = R / f'.scratch/paged-append-20261021/unbind-native/checks/attempt1/{tag}/identity.json'
    rec = load(p)
    candidate = summarize(rec['object'], None)
    old = next((x for x in closures['vulkan_skeleton'] if x.get('owner') == candidate['owner']), None)
    if old and candidate['source_matches_current']:
        replace_objects[old['object']['path']] = candidate['object']['path']
        evidence.append(dict(owner=candidate['owner'], from_object=old['object'], to=brief(candidate),
                             origin='retained_exact_Vulkan_private_import_cleanup_owner'))

add_objects = []
for candidate in new_common:
    candidate = ah_by_owner.get(candidate['owner'], candidate)
    add_objects.append(brief(candidate))
for candidate in ah_additions:
    if candidate['owner'] not in {x['owner'] for x in add_objects}:
        add_objects.append(brief(candidate))

unresolved = [dict(object=x['object'], same_exact_object_in_AD=any(
                  key(x['object']['path']) == key(y['object']['path']) and x['object'].get('sha256') == y['object'].get('sha256')
                  for y in closures['AD_current'])) for x in closures['vulkan_skeleton']
              if x['owner_status'] == 'missing_adjacent_source_identity']
manual = [dict(owner=x.get('owner'), old_object=x['old_object'], candidate=brief(x['candidate']))
          for x in decisions if x['action'] == 'manual_route_or_GGML_SDK_ABI_review']
vk_private_drift = [dict(owner=x['owner'], object=x['object'], source_matches_current=x['source_matches_current'],
                        drift_paths=[z['recorded']['path'] for z in x['canonical_dependency_drift']])
                    for x in closures['vulkan_skeleton'] if x.get('owner', '').startswith(
                        ('src/graph_route_vulkan/', 'src/compute_route_vulkan/', 'src/compute_provider_ggml_vulkan/'))
                    and (not x['source_matches_current'] or x['canonical_dependency_drift'])
                    and x['object']['path'] not in replace_objects]

out = dict(status='HOST_ONLY_SOURCE_OWNER_LINK_INVENTORY_NOT_LINKED_OR_RUN',
           plans={name: dict(identity=ident(p), inputs=len(closures[name]),
                            missing_inputs=sum(not x['exists'] for x in closures[name])) for name, p in PLANS.items()},
           method='Exact object SHA/path -> adjacent identity or explicitly referenced compile/replacement receipt. No recursive SDK/source scan and no basename owner substitution.',
           replacement_map=replace_objects, replacement_evidence=evidence,
           add_objects=add_objects, needs_fresh_compile=needs_fresh,
           remove_old_consumer=[x['old_object'] for x in decisions if x['action']=='remove_old_consumer_and_add_new_native_append_consumer'],
           manual_route_or_GGML_ABI_review=manual, missing_adjacent_source_identity=unresolved,
           other_Vulkan_private_header_drift_for_owner_review=vk_private_drift,
           summary=dict(input_classification=counts, replace_map_entries=len(replace_objects), add_objects=len(add_objects),
                        fresh_compile_needed=len(needs_fresh), exact_object_already_in_AD=counts.get('already_same_object',0),
                        opaque_libraries_retained=counts.get('retain_opaque_library_no_cross_SDK_substitution',0),
                        source_mapped={k:sum(x['owner_status']=='exact_object_identity' for x in v) for k,v in closures.items()}),
           root_post_freeze_change=dict(original_freeze=ident(freeze_path), frozen_CMake=cmake_old,
                                       current_CMake=ident(cmake), diff=cmake_diff,
                                       reason='Root added the pre-existing native_ragged_region.cc to CMake SOURCES; original before/freeze remains unchanged.'),
           limits=['This is an owner inventory, not a final link plan or ABI/runtime pass.',
                   'AD common candidates with remaining canonical dependency drift need explicit review; AH compile1 takes precedence.',
                   'Keep Vulkan GGML/IREE libraries and their exact native ABI owners. Do not substitute AD CUDA GGML runtime/provider objects or CUDA libraries.',
                   'A new consumer, current result.cc helper, graph shared-effects support and any extra unresolved external owners must be included by exact owner; opaque static archive members are not enumerated here.',
                   'Public header drift is evidence for owner review, not proof that every dependent TU requires recompilation.'],
           metadata_files_read=len(metadata_read), activity=dict(compiles=0, links=0, GPU_runs=0, SDK_builds=0))
(V / 'link-inventory.json').write_text(json.dumps(out, indent=2, ensure_ascii=False) + '\n', encoding='utf8')
print(json.dumps(dict(output=ident(V/'link-inventory.json'), summary=out['summary'],
                      missing=[x['object']['path'] for x in unresolved],
                      fresh=[x['owner'] for x in needs_fresh], add=[x['owner'] for x in add_objects]), indent=2))
