"""Independent filesystem-only prefix evidence checker. Never starts a consumer."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shlex
import sys
import traceback

ROOT = Path(__file__).resolve().parents[3]
S = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
HASHES = {}
BASELINE_IMAGE = 'aa4868c5e781626d9ccf0edc709336d06d87ab50b066ffa111208d37e5e67d70'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path).resolve()
    stat = path.stat()
    key = (str(path), stat.st_size, stat.st_mtime_ns)
    if key not in HASHES:
        h = hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(8 << 20), b''):
                h.update(block)
        HASHES[key] = dict(path=str(path), bytes=stat.st_size, sha256=h.hexdigest())
    return HASHES[key]

def verify(record):
    actual = identity(record['path'])
    assert actual == record, (actual, record)
    return actual

def option(command, key):
    return command[command.index(key)+1]

def actual_schedule(path):
    path = Path(path)
    phases = []
    evidence = [identity(path)]
    for line in path.read_text().splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        kind, filename = shlex.split(line)
        token_file = path.parent/filename
        ids = [int(x) for x in token_file.read_text().split()]
        assert ids and all(0 <= x < 248320 for x in ids)
        phases.append(dict(kind=kind, ids=ids))
        evidence.append(identity(token_file))
    return phases, evidence

def expected_calls(phases):
    result, visible, turn = [], 0, 0
    for phase in phases:
        before = visible
        if phase['kind'] == 'prompt':
            turn += 1
            visible += len(phase['ids'])
            result.append(dict(name=f'round{turn}_prefill', tokens=len(phase['ids']), visible=visible))
        else:
            assert phase['kind'] == 'decode'
            for i in range(len(phase['ids'])):
                visible += 1
                result.append(dict(name=f'round{turn}_decode{i+1}', tokens=1, visible=visible))
        phase.update(turn=turn, before=before, after=visible)
    return result

def parse_steps(stderr):
    sessions = {}
    sid, prepared, hit = '__single__', None, None
    for line in stderr.splitlines():
        if line.startswith('session_steps id='):
            assert prepared is None and hit is None
            sid = line.split('=', 1)[1]
        elif line.startswith('prefix_hit name='):
            hit = dict(re.findall(r'(\w+)=([^\s]+)', line))
        elif line.startswith('prepared T='):
            assert prepared is None
            prepared = dict(re.findall(r'(\w+)=([^\s]+)', line))
        elif re.match(r'^round\d+_(?:prefill|decode\d+) tokens=', line):
            fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
            step = dict(name=line.split()[0], tokens=int(fields['tokens']), visible=int(fields['visible']),
                next_id=int(fields['next']), graph=prepared is not None,
                graph_tokens=int(prepared['T']) if prepared else 0,
                reused=int(hit['reused_tokens']) if hit else 0, hit=bool(hit))
            if prepared:
                assert int(prepared['visible']) == step['visible']
                step['prepared'] = prepared
            else:
                assert hit and hit['graph_calls']=='0'
            if hit:
                assert hit['name']==step['name'] and int(hit['visible'])==step['visible']
                assert int(hit['graph_calls'])==int(step['graph'])
            sessions.setdefault(sid, []).append(step)
            prepared, hit = None, None
    assert prepared is None and hit is None
    return sessions

def load_process(folder, expected_ready=None, baseline=False):
    folder = Path(folder)
    receipt = read(folder/'result.json')
    assert receipt['exit']==0 and not receipt.get('timeout'), (folder,receipt)
    assert receipt['throughput_evidence'] is False
    verify(receipt['image']);verify(receipt['ready']);verify(receipt['runtime_environment'])
    ready = read(receipt['ready']['path'])
    assert ready['image']==receipt['image'] and ready['runtime_environment']==receipt['runtime_environment']
    if expected_ready:
        assert receipt['ready']==identity(expected_ready)
    if baseline:
        assert receipt['image']['sha256']==BASELINE_IMAGE
    raw = json.loads(next(line for line in reversed((folder/'stdout.log').read_text().splitlines()) if line.startswith('{')))
    assert raw == read(folder/'observation.json')
    assert raw['text_tensors']==320
    steps = parse_steps((folder/'stderr.log').read_text())
    command = receipt['command']
    if '--session-schedules' in command:
        manifest = Path(option(command,'--session-schedules'))
        configured = []
        inputs = [identity(manifest)]
        for line in manifest.read_text().splitlines():
            if not line.strip() or line.lstrip().startswith('#'):continue
            sid, filename = shlex.split(line)
            phases, files = actual_schedule(manifest.parent/filename)
            configured.append((sid, phases));inputs += files
        assert [x['session_id'] for x in raw['sessions']]==[x[0] for x in configured]
        records = {x['session_id']:x for x in raw['sessions']}
    else:
        phases, inputs = actual_schedule(option(command,'--schedule'))
        configured = [('__single__', phases)]
        records = {'__single__':raw}
    calls = {}
    for sid, phases in configured:
        expected = expected_calls(phases)
        actual, data = steps[sid], records[sid]
        assert len(actual)==len(expected)==data['generated_tokens']==len(data['generated_ids'])
        for a,e in zip(actual,expected,strict=True):
            assert all(a[key]==e[key] for key in ['name','tokens','visible']), (folder,sid,a,e)
        assert data['generated_ids']==[x['next_id'] for x in actual]
        assert data['visible_tokens']==data['processed_tokens']==expected[-1]['visible']
        assert data['decode_input_ids']==[i for phase in phases if phase['kind']=='decode' for i in phase['ids']]
        assert len(data['phases'])==len(phases)
        for a,e in zip(data['phases'],phases,strict=True):
            assert a['kind']==('prefill' if e['kind']=='prompt' else 'decode')
            assert a['input_tokens']==len(e['ids']) and a['context_before']==e['before'] and a['context_after']==e['after']
        if 'actual_graph_calls' in data:
            assert data['actual_graph_calls']==sum(x['graph'] for x in actual)+data['restored_calls']
            assert data['actual_graph_tokens']==sum(x['graph_tokens'] for x in actual)+data['restored_tokens']
            assert data['reused_tokens']==sum(x['reused'] for x in actual)
            assert data['prefix_hits']==sum(x['hit'] for x in actual)
            assert data['prefix_full_hits']==sum(not x['graph'] for x in actual)
            assert data['processed_tokens']==data['actual_graph_tokens']-data['restored_tokens']+data['reused_tokens']
        calls[sid] = {x['name']:x for x in actual}
    return dict(folder=folder,receipt=receipt,raw=raw,sessions=records,calls=calls,
        evidence=dict(result=identity(folder/'result.json'),stdout=identity(folder/'stdout.log'),stderr=identity(folder/'stderr.log'),
            observation=identity(folder/'observation.json'),ready=receipt['ready'],image=receipt['image'],inputs=inputs))

def trace_directory(process, sid, call):
    data = process['sessions'][sid]
    path = process['folder']/'trace'
    return path/data['trace_subdirectory']/call if 'trace_subdirectory' in data else path/call

def compare_call(actual, sid, call, baseline, basecall):
    assert actual['calls'][sid][call]['graph']
    assert actual['calls'][sid][call]['next_id']==baseline['calls']['__single__'][basecall]['next_id']
    left,right = trace_directory(actual,sid,call),trace_directory(baseline,'__single__',basecall)
    names = {x.name for x in left.iterdir() if x.is_file()}
    assert names=={'hidden.bf16','logits.f32'}, (left,names)
    assert {x.name for x in right.iterdir() if x.is_file()}==names
    pairs=[]
    for name in sorted(names):
        a,b=identity(left/name),identity(right/name)
        assert a['bytes']==b['bytes'] and a['sha256']==b['sha256'], (a,b)
        pairs.append(dict(actual=a,baseline=b,byte_equal=True))
    return pairs

def compare_maps(process, sid, baseline, mapping):
    return [pair for call,basecall in mapping for pair in compare_call(process,sid,call,baseline,basecall)]

def budget(process,N):
    raw=process['raw'];cap=int(option(process['receipt']['command'],'--capacity'))
    pages=N*((cap+15)//16)+1
    backing=12*(pages*16*1024+1)+19537920*(N+1)+36
    assert raw['effective_cache_sessions']==raw['cache_committed_version_limit']==N
    assert raw['cache_live_snapshot_versions']<=N and raw['cache_peak_committed_versions']<=N
    assert raw['cache_retained_sessions']<=N and raw['prefix_entries']<=raw['prefix_entry_capacity']==N
    assert raw['cache_max_physical_pages']==pages and raw['cache_page_rows']==16
    for key in ['cache_shared_backing_bytes','cache_requested_byte_limit','cache_live_requested_bytes','cache_peak_requested_bytes']:
        assert raw[key]==backing,(key,raw[key],backing)
    for key in ['processed_tokens','generated_tokens','actual_graph_calls','actual_graph_tokens','prefix_hits','prefix_misses','prefix_full_hits','reused_tokens']:
        assert raw[key]==sum(s[key] for s in raw['sessions'])
    return dict(N=N,global_backing_bytes=backing,max_physical_pages=pages,
        live_committed=raw['cache_live_snapshot_versions'],peak_committed=raw['cache_peak_committed_versions'],
        actual_graph_calls=raw['actual_graph_calls'],actual_graph_tokens=raw['actual_graph_tokens'],
        logical_tokens=raw['processed_tokens'],logical_outputs=raw['generated_tokens'],reused_tokens=raw['reused_tokens'],
        prefix_hits=raw['prefix_hits'],prefix_full_hits=raw['prefix_full_hits'],prefix_evictions=raw['prefix_evictions'],
        evicted_session_ids=raw['evicted_session_ids'])

def main(args,report):
    ready=S/args.ready
    plan=read(S/'inputs/plan.json')
    for record in plan['input_files']:verify(record)
    report['input_plan']=identity(S/'inputs/plan.json')
    old={name:load_process(S/'baselines'/name,baseline=True) for name in ['baseline_a','baseline_b','baseline_seed','baseline_a_pressure','baseline_b_monolithic']}
    report['old_partition_oracles']={key:value['evidence'] for key,value in old.items()}
    current=load_process(S/args.main,ready)
    pressure=load_process(S/args.pressure,ready)
    assert current['receipt']['image']==pressure['receipt']['image']
    report['actual_processes']={args.main:current['evidence'],args.pressure:pressure['evidence']}
    pairs=[]
    seedmap=[(name,name)for name in old['baseline_seed']['calls']['__single__']]
    suffixmap=[('round1_prefill','round2_prefill'),('round1_decode1','round2_decode1'),('round1_decode2','round2_decode2')]
    pairs+=compare_maps(current,'seed',old['baseline_seed'],seedmap)
    pairs+=compare_maps(current,'branch_a',old['baseline_a'],suffixmap)
    pairs+=compare_maps(current,'branch_b',old['baseline_b'],suffixmap)
    for sid,T in [('branch_a',1),('branch_b',16)]:
        data=current['sessions'][sid];step=current['calls'][sid]['round1_prefill']
        assert data['reused_tokens']==129 and data['prefix_hits']==1 and step['graph_tokens']==T
    full=current['sessions']['full_hit'];fullstep=current['calls']['full_hit']['round1_prefill']
    assert full['actual_graph_calls']==full['actual_graph_tokens']==0
    assert full['reused_tokens']==129 and full['prefix_full_hits']==1
    assert full['generated_ids']==[current['calls']['seed']['round1_decode1']['next_id']]
    assert not fullstep['graph']
    hitdir=trace_directory(current,'full_hit','round1_prefill')
    assert {x.name for x in hitdir.rglob('*') if x.is_file()}=={'cache-hit.json'}
    hit=read(hitdir/'cache-hit.json')
    assert hit==dict(prefix_hit=True,graph_calls=0,tensor_payload_available=False,visible_tokens=129,next_id=full['generated_ids'][0])
    assert len(pairs)==22
    main_budget=budget(current,4)
    assert (main_budget['logical_tokens'],main_budget['actual_graph_tokens'],main_budget['reused_tokens'],main_budget['actual_graph_calls'],main_budget['logical_outputs'])==(555,168,387,11,12)
    report['main']=dict(status='passed',budget=main_budget,byte_equal_vectors=len(pairs),pairs=pairs,
        full_hit_metadata=identity(hitdir/'cache-hit.json'),full_hit_directory_files=['cache-hit.json'],
        seed_continuation_after_branches_equal_to_independent_same_chunk_oracle=True)

    pp=[]
    pp+=compare_maps(pressure,'seed',old['baseline_seed'],seedmap)
    amap=suffixmap+[('round2_prefill','round3_prefill'),('round2_decode1','round3_decode1')]
    pp+=compare_maps(pressure,'branch_a',old['baseline_a_pressure'],amap)
    a=pressure['sessions']['branch_a']
    assert a['reused_tokens']==129 and a['prefix_hits']==1 and a['cache_misses']>=2
    assert (a['restored_calls'],a['restored_tokens'],a['actual_graph_calls'],a['actual_graph_tokens'])==(5,132,10,140)
    assert 'branch_a' in pressure['raw']['evicted_session_ids']
    b=pressure['sessions']['branch_b'];bfirst=pressure['calls']['branch_b']['round1_prefill']
    if b['reused_tokens']==0 and bfirst['graph_tokens']==145:
        b_oracle='baseline_b_monolithic';bmap=[(name,name)for name in old[b_oracle]['calls']['__single__']]
    elif b['reused_tokens']==129 and bfirst['graph_tokens']==16:
        b_oracle='baseline_b';bmap=suffixmap
    else:
        raise AssertionError(('No same-partition oracle for observed branchB',b,bfirst))
    pp+=compare_maps(pressure,'branch_b',old[b_oracle],bmap)
    pressure_budget=budget(pressure,2)
    assert (pressure_budget['actual_graph_calls'],pressure_budget['actual_graph_tokens'],pressure_budget['reused_tokens'])==(20,692,129)
    report['pressure']=dict(status='pending_terminal_off_oracles',budget=pressure_budget,pairs=pp,
        byte_equal_vectors=len(pp),branch_b_oracle=b_oracle,
        hit_child_evicted_then_actual_chunk_restore=dict(session='branch_a',restored_calls=5,restored_tokens=132,
            original_partition=[128,1,1,1,1],late_suffix_and_decision_byte_equal=True))
    # No substituted seed-derived vectors for a cache-miss monolithic129.
    for sid,folder in [('changed',args.changed_baseline),('full_hit',args.full_baseline)]:
        oracle=load_process(S/folder,ready)
        assert option(oracle['receipt']['command'],'--prefix-cache')=='off'
        assert oracle['receipt']['image']==pressure['receipt']['image']
        target=pressure['sessions'][sid];step=pressure['calls'][sid]['round1_prefill']
        assert target['prefix_hits']==target['prefix_full_hits']==target['reused_tokens']==0
        assert step['graph_tokens']==129 and not step['hit']
        pp+=compare_maps(pressure,sid,oracle,[('round1_prefill','round1_prefill')])
        report.setdefault('terminal_off_oracles',{})[sid]=oracle['evidence']
    assert len(pp)==30
    report['pressure'].update(status='passed',byte_equal_vectors=len(pp),pairs=pp,
        changed_first_token_exact_miss_and_off_byte_equal=True)
    seed_ids=plan['cases']['seed']['phases'][0]['ids']+plan['cases']['seed']['phases'][1]['ids']
    changed_ids=plan['cases']['changed']['phases'][0]['ids']
    assert len(seed_ids)==len(changed_ids)==129 and changed_ids[0]!=seed_ids[0] and changed_ids[1:]==seed_ids[1:]
    report['total_compared_vectors']=len(pairs)+len(pp)
    report['historical_failed_attempts']=[dict(folder=p.name,result=identity(p/'result.json'),exit=read(p/'result.json')['exit'])
        for p in sorted(S.glob('main-run*'))if p.name!=args.main and(p/'result.json').exists()and read(p/'result.json')['exit']!=0]
    report['status']='passed'

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--main',default='main-run4')
    parser.add_argument('--pressure',default='pressure-run3')
    parser.add_argument('--ready',default='ready-attempt3.json')
    parser.add_argument('--changed-baseline',default='baselines/off_changed')
    parser.add_argument('--full-baseline',default='baselines/off_full_hit')
    args=parser.parse_args()
    report=dict(status='not-completed',scope='Independent filesystem-only evidence check; no process/device/build/product operation.',
        checker=identity(__file__),arguments=vars(args),actions=dict(consumer_runs=0,GPU_queries=0,builds=0,product_edits=0),
        limits=['Compared vectors are actual hidden.bf16/logits.f32 from decisions traces, not a direct byte dump of all12KV+36RNN state blocks.',
            'Exit0 restore executes source-level exact chunk/next_id guards; five restored calls/132tokens plus late same-partition bytes substantiate this case, not all possible histories.',
            'Committed version counters and real globally budgeted backing bytes are checked; no physical VRAM profiler or concurrent-serving acceptance is inferred.',
            'Canonical18/72 regressions are owned by root and separate; they are not silently counted into these52 vectors.',
            'Old failed attempts remain failures; only the explicitly selected fresh ready/image observations can satisfy current checks.'])
    try:
        main(args,report)
        code=0
    except FileNotFoundError as exc:
        report.update(status='pending-missing-evidence',missing=str(exc),error_traceback=traceback.format_exc())
        code=2
    except Exception as exc:
        report.update(status='failed',failure=repr(exc),error_traceback=traceback.format_exc())
        code=1
    target=OUT/'check_actual.json'
    target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=report['status'],report=identity(target),total_compared_vectors=report.get('total_compared_vectors'),
        failure=report.get('failure'),missing=report.get('missing')),indent=2))
    raise SystemExit(code)
