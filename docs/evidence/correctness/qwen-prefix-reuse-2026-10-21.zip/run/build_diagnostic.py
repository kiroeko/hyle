"""One cold-error diagnostic owner; same failed consumer and native closure."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S / 'core-checks/diagnostic2'
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
source = R / 'src/graph/executable.cc'
recipe = R / '.scratch/paged-prepare-20261021/checks/attempt1/graph--executable/identity.json'
frozen = b.identity(source)
command = b.host_command(c.read(recipe)['command'], source, 'graph--executable', out)
c.save(out / 'compile-plan.json', dict(command=command, source=frozen, CXX=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
deps = c.read(out / 'graph--executable-deps.json')['Data']
record = dict(source=frozen, object=b.identity(out / 'graph--executable.obj'), command=command,
    replaced_object=c.read(recipe)['object'],
    dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
assert all(h.same(x) for x in record['dependencies'])
c.save(out / 'identity.json', record)
core = c.read(S / 'compiled-core-attempt1.json')['records'] + [record]
c.save(S / 'compiled-core-attempt2.json', dict(records=core, new_CXX=1, reused_CXX=4, NVCC=0, SDK_builds=0))
prior = c.read(S / 'ready-attempt1.json')
base = c.read(prior['link_plan']['path'])
assert all(h.same(x) for x in base['inputs'])
old = c.key(record['replaced_object']['path'])
assert sum(c.key(x['path']) == old for x in base['inputs']) == 1
image = out / 'qwen.exe'
inputs = [record['object'] if c.key(x['path']) == old else x for x in base['inputs']]
link = [record['object']['path'] if c.key(x) == old else x for x in base['command']
    if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
c.save(out / 'link-plan.json', dict(command=link, inputs=inputs, base=b.identity(prior['link_plan']['path']),
    replaced_inputs=[dict(before=record['replaced_object'], after=record['object'])], CXX=1, links=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(link, [x['path'] for x in inputs], out)
c.execute('link', link, env, out)
for dll in Path(prior['image']['path']).parent.glob('*.dll'):
    os.link(dll, out / dll.name)
runtime = c.read(prior['runtime_environment']['path'])
runtime['PATH'] = env['PATH']
runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
c.save(out / 'runtime-environment.json', runtime)
c.save(S / 'diagnostic-ready.json', dict(image=b.identity(image), source=prior['source'],
    link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'),
    CXX=1, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
print('Cold-error diagnostic linked with otherwise identical failed-model closure.', flush=True)
