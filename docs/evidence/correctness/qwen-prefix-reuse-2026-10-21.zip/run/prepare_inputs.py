"""Finite ordinary schedules and independent same-partition branch oracles."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
old = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21/inputs/plan.json'
p = json.loads(old.read_text(encoding='utf-8'))
seed_prompt = p['cases']['alice']['calls'][0]['ids']
seed_decode = p['cases']['alice']['calls'][1]['ids']
assert len(seed_prompt) == 128 and len(seed_decode) == 1
seed = seed_prompt + seed_decode
data = S / 'inputs'
data.mkdir(exist_ok=False)


def schedule(name, phases):
    folder = data / name
    folder.mkdir()
    records = []
    lines = []
    for i, (kind, ids) in enumerate(phases):
        file = folder / f'{i + 1}-{kind}.ids'
        file.write_text(' '.join(map(str, ids)) + '\n', encoding='utf-8')
        lines.append(f'{kind} {file.name}')
        records.append(dict(kind=kind, ids=ids, path=str(file)))
    file = folder / 'schedule.txt'
    file.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return dict(schedule=str(file), phases=records)


a = [101]
b = list(range(201, 217))
c = list(range(301, 317))
ad = [401, 402]
bd = [501, 502]
cd = [601, 602]
cases = {
    'seed': schedule('seed', [('prompt', seed_prompt), ('decode', seed_decode), ('prompt', c), ('decode', cd)]),
    'branch_a': schedule('branch_a', [('prompt', seed + a), ('decode', ad)]),
    'branch_b': schedule('branch_b', [('prompt', seed + b), ('decode', bd)]),
    'full_hit': schedule('full_hit', [('prompt', seed)]),
    'baseline_a': schedule('baseline_a', [('prompt', seed_prompt), ('decode', seed_decode), ('prompt', a), ('decode', ad)]),
    'baseline_b': schedule('baseline_b', [('prompt', seed_prompt), ('decode', seed_decode), ('prompt', b), ('decode', bd)]),
    'baseline_seed': schedule('baseline_seed', [('prompt', seed_prompt), ('decode', seed_decode), ('prompt', c), ('decode', cd)]),
}
changed = seed.copy()
changed[0] += 1
cases['changed'] = schedule('changed', [('prompt', changed)])
names = ['seed', 'branch_a', 'branch_b', 'full_hit']
manifest = data / 'branches.txt'
manifest.write_text(''.join(f'{n} {n}/schedule.txt\n' for n in names), encoding='utf-8')
pressure = data / 'pressure.txt'
pressure.write_text(''.join(f'{n} {n}/schedule.txt\n' for n in [*names, 'changed']), encoding='utf-8')


def identity(path):
    blob = path.read_bytes()
    return dict(path=str(path), bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest())


plan = dict(source=identity(old), policy='Same complete seed state, independent original P128+D1 then T1/T16 suffix baselines; no monolithic130/145 oracle substitution.',
            cases=cases, manifest=str(manifest), pressure_manifest=str(pressure),
            intended_main_slots=4, intended_main_active_sequences=1,
            expected_main_hits={'branch_a': 129, 'branch_b': 129, 'full_hit': 129},
            expected_suffix_rows={'branch_a': 1, 'branch_b': 16, 'full_hit': 0},
            seed_continues_after_both_branches=True,
            throughput_evidence=False)
plan['input_files'] = [identity(f) for f in sorted(data.rglob('*')) if f.is_file()]
(data / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
print('Prepared finite schedules; no model launched.')
