from pathlib import Path
import shutil,hashlib,json,difflib
root=Path.cwd();p=root/'tools/qwen35_text/main.cc';out=root/'.scratch/qwen-prefix-20261021/implementation/budget-fix'
out.mkdir(parents=True,exist_ok=True);old=p.read_bytes();before=out/'before/tools/qwen35_text/main.cc';before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(old)
s=old.decode().replace('\r\n','\n')
a='''    std::cerr << "compile full text finite family variants=" << variants.size()
              << " max_query_rows=" << max_query_rows << " nodes=" << definition.graph.node_count() << '\\n';
    definition.compiled = take(g::cuda::compile(definition.graph, context, memory,
        {.shape_policy = g::CompileShapePolicy::kFiniteExact,
         .exact_variants = variants, .constants = r.constants}));'''
b='''    g::CompileOptions compile_options{.shape_policy = g::CompileShapePolicy::kFiniteExact,
        .exact_variants = variants, .constants = r.constants};
    // The library's cold operation admission cap covers the whole family.
    // Budget the requested finite children explicitly at the per-graph default;
    // this is host search/storage policy, not device or execution capacity.
    const auto per_graph_operations = g::CompileOptions{}.max_operation_proposals;
    if (variants.size() > (std::numeric_limits<std::size_t>::max)() / per_graph_operations)
      throw std::runtime_error("finite text operation proposal budget overflows");
    compile_options.max_operation_proposals = per_graph_operations * variants.size();
    std::cerr << "compile full text finite family variants=" << variants.size()
              << " max_query_rows=" << max_query_rows << " nodes=" << definition.graph.node_count()
              << " max_operation_proposals=" << compile_options.max_operation_proposals << '\\n';
    definition.compiled = take(g::cuda::compile(definition.graph, context, memory, compile_options));'''
assert s.count(a)==1;s=s.replace(a,b)
a='''              << " compiled_unknown_providers=" << storage.unknown_provider_count
              << " cold_seconds="'''
b='''              << " compiled_unknown_providers=" << storage.unknown_provider_count
              << " max_operation_proposals=" << compile_options.max_operation_proposals
              << " operation_proposals=" << definition.compiled.report.total_search().operation_proposals
              << " cold_seconds="'''
assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
new=p.read_bytes();snap=out/'source/tools/qwen35_text/main.cc';snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(new)
patch=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='before/tools/qwen35_text/main.cc',tofile='tools/qwen35_text/main.cc'))
(out/'implementation.diff').write_text(patch)
report={'scope':'only consumer finite-family max_operation_proposals; no other compile caps, shapes, math or hot path changed','trigger':'.scratch/qwen-prefix-20261021/main-run2/stderr.log: exact variant index 6 operation_proposal_limit under default cumulative 16384','before':{'path':'tools/qwen35_text/main.cc','sha256':hashlib.sha256(old).hexdigest(),'bytes':len(old)},'after':{'path':'tools/qwen35_text/main.cc','sha256':hashlib.sha256(new).hexdigest(),'bytes':len(new)},'formula':'checked size_t multiplication: CompileOptions{}.max_operation_proposals * variants.size(); original per-graph default for each explicitly requested exact child','example_8_children':16384*8,'logging':['precompile max_operation_proposals','postcompile same cap and report.total_search().operation_proposals'],'unchanged':['library cumulative cap enforcement','all valid requested variants','provider and region caps','route/placement caps','workspace/hardware budgets','execution/capture/math'],'verification':'source-only; no build/GPU run by this owner; root recompiles main1TU'}
(out/'source-freeze.json').write_text(json.dumps(report,indent=2)+'\n')
print('main',len(new),hashlib.sha256(new).hexdigest());bb=(out/'source-freeze.json').read_bytes();print('freeze',hashlib.sha256(bb).hexdigest())

