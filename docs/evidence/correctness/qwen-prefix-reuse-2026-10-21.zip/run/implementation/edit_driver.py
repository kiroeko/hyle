from pathlib import Path
p=Path('tools/qwen35_text/main.cc')
s=p.read_text()
s=s.replace('if (planned_chunks.empty()) throw std::runtime_error("session requires a nonempty ordered call plan");','if (planned_chunks.empty() && !prefix) throw std::runtime_error("session requires an ordered call plan or a complete prefix");')
s=s.replace('bool single_schedule = false, multiple_schedules = false;','bool single_schedule = false, multiple_schedules = false;\n    std::string prefix_policy;')
s=s.replace('else if (option == "--cache-bytes") cache_bytes = value == "auto" ? 0 : positive_size(option, value);','''else if (option == "--cache-bytes") cache_bytes = value == "auto" ? 0 : positive_size(option, value);
      else if (option == "--prefix-cache") {
        if (value != "off" && value != "auto") throw std::runtime_error("--prefix-cache requires off or auto");
        prefix_policy = value;
      }''')
s=s.replace('const bool scheduled = single_schedule || multiple_schedules;','''const bool scheduled = single_schedule || multiple_schedules;
    const bool prefix_enabled = prefix_policy == "auto" || (prefix_policy.empty() && multiple_schedules);
    if (prefix_enabled && !scheduled) throw std::runtime_error("--prefix-cache auto requires a schedule");''')
s=s.replace('qwen35::benchmark::read_schedule(schedule_file, qwen35::vocabulary, capacity)', 'qwen35::benchmark::read_schedule(schedule_file, qwen35::vocabulary, capacity, true)')
s=s.replace('std::vector<qwen35::benchmark::SessionSchedule>{}.max_size());','std::vector<qwen35::benchmark::SessionSchedule>{}.max_size(), true);')
s=s.replace('[--cache-bytes auto|N] [--progress','[--cache-bytes auto|N] [--prefix-cache off|auto] [--progress')
s=s.replace('    const auto max_query_rows = *std::max_element(planned_chunks.begin(), planned_chunks.end());','''    // Immutable host token owners are bounded by the validated input batch.
    // Only suffixes at real prompt/turn boundaries enter the cold shape union.
    std::vector<qwen35::cache::TokenPlanRef> token_plans;
    if (prefix_enabled) {
      token_plans.reserve(schedules.size());
      for (const auto &request : schedules) token_plans.push_back(qwen35::cache::token_plan(request.phases, capacity));
      for (std::size_t s = 0; s < schedules.size(); ++s) {
        std::size_t before = 0;
        for (const auto &phase : schedules[s].phases) {
          const auto target = before + phase.ids.size();
          if (phase.kind == qwen35::benchmark::PhaseKind::kPrompt) {
            for (const auto &candidate : token_plans) for (const auto boundary : candidate->checkpoints) {
              if (boundary < before || boundary >= target ||
                  !qwen35::cache::same_prefix(*candidate, *token_plans[s], boundary)) continue;
              const auto suffix = target - boundary;
              if (std::find(planned_chunks.begin(), planned_chunks.end(), suffix) == planned_chunks.end())
                planned_chunks.push_back(suffix);
            }
          }
          before = target;
        }
      }
    }
    const auto max_query_rows = *std::max_element(planned_chunks.begin(), planned_chunks.end());''')
s=s.replace('    struct SessionRun {','''    // Destroy runs (and their real slots) before this directory and Model.
    auto prefix_cache = prefix_enabled ? std::make_unique<qwen35::cache::PrefixCache>(cache_slots) : nullptr;
    struct SessionRun {''')
s=s.replace('      std::vector<std::size_t> chunks;\n      std::vector<PhaseSummary>', '''      std::vector<std::size_t> chunks;
      std::shared_ptr<qwen35::cache::ReplayHistory> history;
      std::map<std::size_t, std::array<std::size_t, 2>> preparation_uses;
      std::vector<PhaseSummary>''')
s=s.replace('      std::size_t restored_calls = 0, restored_tokens = 0;','''      std::size_t restored_calls = 0, restored_tokens = 0;
      std::size_t actual_graph_calls = 0, actual_graph_tokens = 0;
      std::size_t prefix_hits = 0, prefix_misses = 0, prefix_full_hits = 0, reused_tokens = 0;''')
s=s.replace('      run.summaries.resize(request.phases.size());','''      run.summaries.resize(request.phases.size());
      if (prefix_enabled) run.history = std::make_shared<qwen35::cache::ReplayHistory>(capacity);
      if (preparation_diagnostics) for (const auto tokens : planned_chunks) run.preparation_uses.emplace(tokens, std::array<std::size_t, 2>{});''')
a=s.index('    const auto ensure_resident = [&](std::size_t s) {')
b=s.index('    auto session = scheduled ?',a)
s=s[:a]+'''    const auto make_initial_room = [&] {
      if (!prefix_cache) return;
      while (model.snapshot_versions.live >= cache_slots) {
        if (!prefix_cache->evict_one())
          throw std::runtime_error("prefix/session heads retain the committed version budget before initial admission");
      }
    };
    const auto make_advance_room = [&](qwen35::Session &owner) {
      if (!prefix_cache) return;
      if (owner.pending || owner.failed || model.snapshot_versions.live > cache_slots)
        throw std::runtime_error("prefix advance requires a retired session and the committed version budget");
      const auto base_is_retained = [&] {
        if (prefix_cache->retains(owner.head.get())) return true;
        for (const auto &other : runs)
          if (other.session && other.session.get() != &owner && other.session->head.get() == owner.head.get()) return true;
        return false;
      };
      // Count distinct real VersionRefs, not directory aliases or shared_ptr
      // counts. N+1 is the one original in-flight candidate, never a checkpoint.
      while (model.snapshot_versions.live == cache_slots && base_is_retained()) {
        if (!prefix_cache->evict_one())
          throw std::runtime_error("prefix advance is retained by another session; no unpinned checkpoint can make room");
      }
    };
    const auto reset_preparation_uses = [&](SessionRun &run) {
      if (preparation_diagnostics) for (auto &[tokens, uses] : run.preparation_uses) { (void)tokens; uses = {}; }
    };
    const auto note_preparation = [&](SessionRun &run, std::size_t tokens, qwen35::PreparationObservation *record) {
      if (!preparation_diagnostics) return;
      const auto slot = run.session->parity;
      auto &uses = run.preparation_uses.at(tokens);
      if (record) { record->slot = slot; record->phase_slot_prior_uses = uses[slot]; }
      ++uses[slot];
    };
    const auto ensure_resident = [&](std::size_t s, bool defer_restore) {
      auto &run = runs[s];
      if (run.pin) return;
      const auto begin = qwen35::Clock::now();
      const auto admission = resident_cache.admit(s, 0, [&](std::size_t victim) {
        auto &old = runs[victim];
        if (old.pin || (old.session && !old.session->drain().ok())) return false;
        old.session.reset(); // Actual slots and buffers die before quota returns.
        evicted_sessions.push_back(victim);
        return true;
      });
      if (!admission.accepted())
        throw std::runtime_error(admission.status == qwen35::benchmark::CacheAdmissionStatus::kRetirementUnproven
            ? "session cache cannot prove retirement; the original owner remains charged"
            : "session cache admission exhausted; reduce --active-sequences or increase --max-sessions/--cache-bytes");
      run.pin = resident_cache.pin(s);
      if (!run.pin) throw std::runtime_error("session cache could not pin the admitted owner");
      if (run.session) ++run.cache_hits;
      else {
        ++run.cache_misses;
        if (!defer_restore) {
          make_initial_room();
          run.session = model.create_session(run.chunks);
          reset_preparation_uses(run);
          // Off mode preserves the original logical chunk replay contract.
          for (std::size_t i = 0; i < run.generated.size(); ++i) {
            const auto call = run.calls[i];
            const auto &phase = schedules[s].phases[call.phase];
            const auto ids = phase.kind == qwen35::benchmark::PhaseKind::kPrompt
                ? std::span<const std::int32_t>(phase.ids)
                : std::span<const std::int32_t>(&phase.ids[call.local], 1);
            qwen35::StepObservation restored;
            const auto name = "restore" + std::to_string(run.cache_misses) + "_call" + std::to_string(i);
            note_preparation(run, ids.size(), nullptr);
            const auto next = model.evaluate(*run.session, ids, name, {}, false, nullptr, nullptr,
                &restored, nullptr, multiple_schedules ? std::string_view(run.trace_subdirectory) : std::string_view{});
            if (next != run.generated[i]) throw std::runtime_error("restored cache output differs from the original session history");
            ++run.restored_calls; run.restored_tokens += ids.size();
            ++run.actual_graph_calls; run.actual_graph_tokens += ids.size();
          }
          if (run.session->length() != run.visible_tokens)
            throw std::runtime_error("restored cache context differs from retained consumer history");
        }
      }
      if (qwen35::take(model.cache_budget.usage(model.memory.ref())).live_bytes != selected_cache.backing_bytes)
        throw std::runtime_error("actual cache backing reservations differ from the shared physical plan");
      run.cache_prepare_seconds += std::chrono::duration<double>(qwen35::Clock::now() - begin).count();
    };
    // Prefix mode admits at the timed request boundary, before any initial
    // state allocation. A full hit must not create or evaluate an empty state.
    if (!prefix_enabled) for (std::size_t s = 0; s < (std::min)(active_slots, runs.size()); ++s) ensure_resident(s, false);
''' +s[b:]
p.write_text(s)
