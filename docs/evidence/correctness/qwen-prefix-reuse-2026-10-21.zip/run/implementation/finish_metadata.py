from pathlib import Path
p=Path('tools/qwen35_text/prefix_cache.h');s=p.read_text()
s=s.replace('if (!input || !count || first > input->ids.size() || count > input->ids.size() - first ||\n        count > capacity - length', 'if (!input || !count || length > capacity || first != length || first > input->ids.size() || count > input->ids.size() - first ||\n        count > capacity - length')
s=s.replace('''      throw std::runtime_error("only a complete actual prefix boundary may enter the directory");
    std::size_t slot''','''      throw std::runtime_error("only a complete actual prefix boundary may enter the directory");
    std::size_t covered = 0;
    for (std::size_t i = 0; i < replay.chunks; ++i) {
      const auto &part = replay.history->chunks[i];
      if (!part.input || part.first != covered || part.first > input->ids.size() ||
          part.count > input->ids.size() - part.first || part.first > part.input->ids.size() ||
          part.count > part.input->ids.size() - part.first ||
          !std::equal(part.input->ids.begin() + static_cast<std::ptrdiff_t>(part.first),
              part.input->ids.begin() + static_cast<std::ptrdiff_t>(part.first + part.count),
              input->ids.begin() + static_cast<std::ptrdiff_t>(part.first)))
        throw std::runtime_error("prefix rebuild history differs from its exact token key");
      covered += part.count;
    }
    if (covered != snapshot->length) throw std::runtime_error("prefix rebuild history does not cover its snapshot");
    std::size_t slot''')
p.write_text(s)
p=Path('tools/qwen35_text/main.cc');s=p.read_text()
s=s.replace('''    if (prefix && (prefix->model != this || prefix->math != math_identity() || prefix->length > capacity))''','''    if (prefix && (prefix->model != this || prefix->math != math_identity() || prefix->length > capacity ||
        (planned_chunks.empty() && (!prefix->length || prefix->next_id < 0))))''')
s=s.replace('''    std::vector<SessionRun> runs(schedules.size());
    std::size_t all_calls = 0;''','''    std::vector<SessionRun> runs(schedules.size());
    std::size_t peak_committed_versions = 0;
    const auto note_committed_versions = [&] {
      peak_committed_versions = (std::max)(peak_committed_versions, std::size_t(model.snapshot_versions.live));
    };
    std::size_t all_calls = 0;''')
s=s.replace('''          run.session = model.create_session(run.chunks);
          reset_preparation_uses(run);''','''          run.session = model.create_session(run.chunks);
          note_committed_versions();
          reset_preparation_uses(run);''')
s=s.replace('''            ++run.actual_graph_calls; run.actual_graph_tokens += ids.size();
          }
          if (run.session->length() != run.visible_tokens)''','''            ++run.actual_graph_calls; run.actual_graph_tokens += ids.size();
            note_committed_versions();
          }
          if (run.session->length() != run.visible_tokens)''')
s=s.replace('''          run.session = model.create_session(remaining);
          reset_preparation_uses(run);''','''          run.session = model.create_session(remaining);
          note_committed_versions();
          reset_preparation_uses(run);''')
s=s.replace('''        endpoint = run.endpoint;
        run.visible_tokens''','''        note_committed_versions();
        endpoint = run.endpoint;
        run.visible_tokens''')
s=s.replace('''                  << ",\\\"actual_graph_calls\\\":" << run.actual_graph_calls << ",\\\"actual_graph_tokens\\\":" << run.actual_graph_tokens
''','''                  << ",\\\"actual_graph_calls\\\":" << run.actual_graph_calls << ",\\\"actual_graph_tokens\\\":" << run.actual_graph_tokens
                  << ",\\\"cache_shared_backing_bytes\\\":" << selected_cache.backing_bytes
                  << ",\\\"cache_committed_version_limit\\\":" << cache_slots
                  << ",\\\"cache_live_snapshot_versions\\\":" << model.snapshot_versions.live
                  << ",\\\"cache_peak_committed_versions\\\":" << peak_committed_versions
''')
s=s.replace('''        std::size_t processed = 0;
        double step_sum = 0;
        for (const auto &run : runs) { processed += run.visible_tokens; step_sum += run.step_sum_seconds; }''','''        std::size_t processed = 0, actual_graph_calls = 0, actual_graph_tokens = 0;
        std::size_t prefix_hits = 0, prefix_misses = 0, prefix_full_hits = 0, reused_tokens = 0;
        double step_sum = 0;
        for (const auto &run : runs) {
          processed += run.visible_tokens; step_sum += run.step_sum_seconds;
          actual_graph_calls += run.actual_graph_calls; actual_graph_tokens += run.actual_graph_tokens;
          prefix_hits += run.prefix_hits; prefix_misses += run.prefix_misses;
          prefix_full_hits += run.prefix_full_hits; reused_tokens += run.reused_tokens;
        }''')
s=s.replace('''                  << ",\\\"generated_tokens\\\":" << all_calls
''','''                  << ",\\\"generated_tokens\\\":" << all_calls
                  << ",\\\"actual_graph_calls\\\":" << actual_graph_calls << ",\\\"actual_graph_tokens\\\":" << actual_graph_tokens
                  << ",\\\"prefix_hits\\\":" << prefix_hits << ",\\\"prefix_misses\\\":" << prefix_misses
                  << ",\\\"prefix_full_hits\\\":" << prefix_full_hits << ",\\\"reused_tokens\\\":" << reused_tokens
''')
s=s.replace('''                  << ",\\\"cache_live_snapshot_versions\\\":" << model.snapshot_versions.live
                  << ",\\\"cache_live_requested_bytes''','''                  << ",\\\"cache_live_snapshot_versions\\\":" << model.snapshot_versions.live
                  << ",\\\"cache_peak_committed_versions\\\":" << peak_committed_versions
                  << ",\\\"cache_committed_version_limit\\\":" << cache_slots
                  << ",\\\"cache_live_requested_bytes''')
p.write_text(s)
