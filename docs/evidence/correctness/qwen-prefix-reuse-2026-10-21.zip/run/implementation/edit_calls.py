from pathlib import Path
p=Path('tools/qwen35_text/main.cc')
s=p.read_text()
a=s.index('        if (is_prompt) ensure_resident(s); // Request boundary only; decode uses the direct Session.')
b=s.index('        endpoint = run.endpoint;',a)
s=s[:a]+'''        const auto call_start = qwen35::Clock::now();
        if (is_prompt) ensure_resident(s, prefix_enabled); // Decode never consults either directory.
        const auto logical_ids = is_prompt ? std::span<const std::int32_t>(phase.ids)
            : std::span<const std::int32_t>(&phase.ids[call.local], 1);
        auto ids = logical_ids;
        const auto before = run.visible_tokens;
        const auto target = before + logical_ids.size();
        auto &observation = run.observations[index];
        std::size_t reused = 0;
        bool used_prefix = false;
        if (prefix_enabled && is_prompt) {
          // An equal-length checkpoint is useful after eviction, but must not
          // replace a resident same-boundary Session and lose its recordings.
          auto hit = prefix_cache->lookup(*token_plans[s], target,
              before + (run.session ? std::size_t{1} : std::size_t{0}), &model, model.math_identity());
          if (hit) {
            if (hit.snapshot->next_id >= qwen35::vocabulary)
              throw std::runtime_error("prefix next_id is outside the model vocabulary");
            reused = hit.snapshot->length - before;
            const auto suffix = target - hit.snapshot->length;
            std::vector<std::size_t> remaining;
            remaining.reserve(run.chunks.size() - index);
            if (suffix) remaining.push_back(suffix);
            remaining.insert(remaining.end(), run.chunks.begin() + static_cast<std::ptrdiff_t>(index + 1), run.chunks.end());
            // All fallible host/IO preparation precedes withdrawal of the old
            // Session. These are real original Model slots, not shadow state.
            auto history = qwen35::cache::copy_history(hit.replay, capacity);
            auto adopted = model.create_session(remaining, hit.snapshot);
            if (run.session && !run.session->drain().ok())
              throw std::runtime_error("prefix adoption cannot retire the original session");
            run.session = std::move(adopted);
            run.history = std::move(history);
            reset_preparation_uses(run);
            ids = logical_ids.subspan(reused);
            hit.reset(); // No temporary Snapshot owner may hide from advance admission.
            used_prefix = true; ++run.prefix_hits; run.reused_tokens += reused;
            if (ids.empty()) ++run.prefix_full_hits;
          } else ++run.prefix_misses;
        }
        if (prefix_enabled && !run.session) {
          make_initial_room();
          std::vector<std::size_t> remaining;
          remaining.reserve(run.history->chunks.size() + run.chunks.size() - index);
          for (const auto &part : run.history->chunks) remaining.push_back(part.count);
          remaining.insert(remaining.end(), run.chunks.begin() + static_cast<std::ptrdiff_t>(index), run.chunks.end());
          run.session = model.create_session(remaining);
          reset_preparation_uses(run);
          // Replay actual evaluated chunks (including imported prefix chunks),
          // with their original immutable token owners and original next IDs.
          // No directory lookup or synthetic full-prompt replay occurs here.
          for (std::size_t i = 0; i < run.history->chunks.size(); ++i) {
            const auto &part = run.history->chunks[i];
            const auto restored_ids = std::span<const std::int32_t>(part.input->ids).subspan(part.first, part.count);
            qwen35::StepObservation restored;
            const auto name = "restore" + std::to_string(run.cache_misses) + "_chunk" + std::to_string(i);
            make_advance_room(*run.session);
            note_preparation(run, restored_ids.size(), nullptr);
            const auto next = model.evaluate(*run.session, restored_ids, name, {}, false, nullptr, nullptr,
                &restored, nullptr, multiple_schedules ? std::string_view(run.trace_subdirectory) : std::string_view{});
            if (next != part.next_id)
              throw std::runtime_error("actual-chunk restore differs from its original committed next_id");
            ++run.restored_calls; run.restored_tokens += restored_ids.size();
            ++run.actual_graph_calls; run.actual_graph_tokens += restored_ids.size();
          }
          if (run.session->length() != before || (!run.generated.empty() && run.session->head->next_id != run.generated.back()))
            throw std::runtime_error("actual-chunk restore differs from the retained logical boundary");
        }
        double complete_seconds = 0;
        std::int32_t next = -1;
        if (!ids.empty()) {
          make_advance_room(*run.session);
          note_preparation(run, ids.size(), preparation_diagnostics ? &run.preparation[index] : nullptr);
          next = model.evaluate(*run.session, ids, observation.name, run.trace, trace_states,
              &complete_seconds, &run.endpoint, &observation,
              preparation_diagnostics ? &run.preparation[index] : nullptr,
              multiple_schedules ? std::string_view(run.trace_subdirectory) : std::string_view{});
          ++run.actual_graph_calls; run.actual_graph_tokens += ids.size();
          if (prefix_enabled) run.history->append(token_plans[s], before + reused, ids.size(), next);
        } else {
          // A complete hit returns only the committed host-visible decision.
          // It does not execute Graph, toggle parity, or fabricate trace tensors.
          next = run.session->head->next_id;
          run.endpoint = qwen35::Clock::now();
          observation.graph_executed = false; observation.graph_input_tokens = 0;
          observation.visible = run.session->length(); observation.next = next;
          observation.scheduled_progress = progress;
        }
        if (prefix_enabled) {
          complete_seconds = std::chrono::duration<double>(run.endpoint - call_start).count();
          observation.step_seconds = complete_seconds;
          observation.input_tokens = logical_ids.size();
          observation.prefix_hit = used_prefix; observation.reused_tokens = reused;
          if (model.snapshot_versions.live > cache_slots)
            throw std::runtime_error("committed prefix/session versions exceed the finite cache budget");
          if (!observation.graph_executed) {
            observation.seconds = complete_seconds;
            const auto write_hit_trace = [&](const std::filesystem::path &base) {
              if (base.empty()) return;
              const auto directory = base / observation.name;
              std::filesystem::create_directories(directory);
              std::ofstream output(directory / "cache-hit.json");
              output << "{\\\"prefix_hit\\\":true,\\\"graph_calls\\\":0,\\\"tensor_payload_available\\\":false,\\\"visible_tokens\\\":"
                     << run.session->length() << ",\\\"next_id\\\":" << next << "}\\n";
              if (!output) throw std::runtime_error("cannot write prefix-hit metadata trace");
            };
            write_hit_trace(run.trace);
            if (!layer0_probe.empty()) write_hit_trace(multiple_schedules ? layer0_probe / run.trace_subdirectory : layer0_probe);
          }
        }
''' +s[b:]
s=s.replace('''          if (!is_prompt) run.pin.reset(); // Complete native call, then idle-cache eligibility.''','''          if (prefix_enabled) {
            const qwen35::cache::ReplayPrefix history{run.history, run.history->chunks.size(), run.history->length};
            (void)prefix_cache->publish(token_plans[s], run.session->head, history);
          }
          // Terminal prompts are real completed requests too.
          if (!is_prompt || call.phase + 1 == schedules[s].phases.size()) run.pin.reset();''')
s=s.replace('''        if (preparation_diagnostics) for (std::size_t i = 0; i < run.observations.size(); ++i)
          qwen35::print_preparation_observation(run.observations[i], run.preparation[i]);''','''        if (preparation_diagnostics) for (std::size_t i = 0; i < run.observations.size(); ++i)
          if (run.observations[i].graph_executed)
            qwen35::print_preparation_observation(run.observations[i], run.preparation[i]);''')
s=s.replace('''                  << ",\\\"cache_prepare_seconds\\\":" << run.cache_prepare_seconds
''','''                  << ",\\\"cache_prepare_seconds\\\":" << run.cache_prepare_seconds
                  << ",\\\"prefix_cache\\\":\\\"" << (prefix_enabled ? "auto" : "off") << '\"'
                  << ",\\\"prefix_hits\\\":" << run.prefix_hits << ",\\\"prefix_misses\\\":" << run.prefix_misses
                  << ",\\\"prefix_full_hits\\\":" << run.prefix_full_hits << ",\\\"reused_tokens\\\":" << run.reused_tokens
                  << ",\\\"actual_graph_calls\\\":" << run.actual_graph_calls << ",\\\"actual_graph_tokens\\\":" << run.actual_graph_tokens
''')
s=s.replace('''                  << ",\\\"cache_retained_sessions\\\":" << resident_cache.retained_sessions()
''','''                  << ",\\\"cache_retained_sessions\\\":" << resident_cache.retained_sessions()
                  << ",\\\"prefix_cache\\\":\\\"" << (prefix_enabled ? "auto" : "off") << '\"'
                  << ",\\\"prefix_entry_capacity\\\":" << (prefix_enabled ? cache_slots : 0)
                  << ",\\\"prefix_entries\\\":" << (prefix_cache ? prefix_cache->size() : 0)
                  << ",\\\"prefix_evictions\\\":" << (prefix_cache ? prefix_cache->evictions : 0)
''')
p.write_text(s)
