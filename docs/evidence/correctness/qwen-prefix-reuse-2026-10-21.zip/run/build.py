"""One consumer host TU plus retained native/library closure; no SDK/NVCC."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
parser = argparse.ArgumentParser()
parser.add_argument('--attempt', type=int, default=1)
args = parser.parse_args()
out = S / f'checks/attempt{args.attempt}'
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
recipe = R / '.scratch/paged-append-20261021/qwen-snapshot/checks/attempt3/identity.json'
source = R / 'tools/qwen35_text/main.cc'
frozen = b.identity(source)
private_sources = [b.identity(p) for p in sorted(source.parent.glob('*')) if p.suffix in ('.cc', '.h')]
for row in private_sources:
    snap = out / 'source' / Path(row['path']).relative_to(R)
    snap.parent.mkdir(parents=True, exist_ok=True)
    snap.write_bytes(Path(row['path']).read_bytes())
command = b.host_command(c.read(recipe)['command'], source, 'main', out)
assert all(x in command for x in ('/W4', '/WX', '/O2', '/MD'))
c.save(out / 'compile-plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe),
    private_sources=private_sources, CXX=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
deps = c.read(out / 'main-deps.json')['Data']
record = dict(source=frozen, object=b.identity(out / 'main.obj'), command=command,
    dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
assert all(h.same(x) for x in private_sources + record['dependencies'])
c.save(out / 'identity.json', record)
base_ready = R / '.scratch/paged-prepare-20261021/qwen-ready.json'
prior = c.read(base_ready)
base = c.read(prior['link_plan']['path'])
assert len(base['inputs']) == 192 and all(h.same(x) for x in base['inputs'])
old_object = c.read(recipe)['object']
old_key = c.key(old_object['path'])
assert sum(c.key(x['path']) == old_key for x in base['inputs']) == 1
core = c.read(S / f'compiled-core-attempt{args.attempt}.json')['records']
assert all(h.same(x['source']) and h.same(x['object']) and all(h.same(d) for d in x['dependencies']) for x in core)
replacements = {c.key(x['replaced_object']['path']): x['object'] for x in core}
replacements[old_key] = record['object']
assert all(sum(c.key(x['path']) == key for x in base['inputs']) == 1 for key in replacements)
image = out / 'qwen.exe'
inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
link = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
c.save(out / 'link-plan.json', dict(command=link, inputs=inputs, base=b.identity(prior['link_plan']['path']),
    replaced_inputs=[dict(before=old_object, after=record['object'])] + [dict(before=x['replaced_object'], after=x['object']) for x in core],
    CXX=1, links=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(link, [x['path'] for x in inputs], out)
c.execute('link', link, env, out)
for dll in Path(prior['image']['path']).parent.glob('*.dll'):
    os.link(dll, out / dll.name)
runtime = c.read(prior['runtime_environment']['path'])
runtime['PATH'] = env['PATH']
runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
runtime['scope'] = 'Ordinary scheduled Qwen exact full-state prefix reuse, root correctness checks; no concurrency/native Apple/Vulkan claim.'
c.save(out / 'runtime-environment.json', runtime)
assert all(h.same(x) for x in private_sources + record['dependencies'] + inputs)
c.save(S / f'ready-attempt{args.attempt}.json', dict(image=b.identity(image), source=frozen,
    private_sources=private_sources, fresh_core_sources=[x['source'] for x in core], link_plan=b.identity(out / 'link-plan.json'),
    runtime_environment=b.identity(out / 'runtime-environment.json'),
    CXX=1, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
print('Fresh consumer host TU linked with retained current native closure.', flush=True)
