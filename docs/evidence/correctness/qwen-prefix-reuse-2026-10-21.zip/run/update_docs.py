"""Update the single progress entry with the completed current four-arm table."""
from pathlib import Path
import json
S = Path(__file__).resolve().parent
R = S.parents[1]
data = json.loads((S / 'performance/public-table.json').read_text(encoding='utf-8'))
rows = data['rows']
arms = ('current', 'before', 'dense', 'peer')
ready = json.loads((S / 'ready-attempt3.json').read_text(encoding='utf-8'))
lines = [
    '## 最新完整性能对比', '',
    '**2026-10-21，前缀接通、定点访问及共享layout页集合后的四臂测试。** RTX 4070 12GB／Windows，Qwen3.5-2B BF16、F32 GDN、无MTP／图片；单会话三轮`256输入＋32 decode`，同固定ID、容量1024、最终上下文864。',
    f'当前`{ready["image"]["sha256"][:8]}…`、本批前paged `aa4868c5…`、原dense `ff748694…`、llama.cpp `9b259137…`／`d9e03f1074db…`；各3进程交错测速，显存另各1进程旁采，trace／诊断关闭。当前与本批前192个链接输入中只替换main及5个相关core对象，权重、FI Provider和原生库相同。本窗单会话**前缀目录关闭**，四臂都保完整历史，只算新增输入；不代表缓存命中、多用户吞吐或Spark测试。', '',
    '| 指标 | 当前分页Hyle | 本批前paged | 原dense Hyle | llama.cpp |',
    '| --- | ---: | ---: | ---: | ---: |',
]


def row(label, values, digits=2):
    lines.append('| ' + label + ' | ' + ' | '.join(f'{x:.{digits}f}' for x in values) + ' |')


for i in range(3):
    row(f'第{i+1}轮prefill tok/s', [rows[a]['prefill_256_TPS_by_turn'][i]['median'] for a in arms])
for i in range(3):
    row(f'第{i+1}轮完整decode tok/s', [rows[a]['decode_32_TPS_by_turn'][i]['median'] for a in arms])
for key, label, digits in (
    ('aggregate_decode_96_over_sumD_TPS', '完整decode合计 tok/s（96／三段decode总wall）', 2),
    ('session_outputs_99_over_session_TPS', '综合输出 tok/s（99／会话wall）', 2),
    ('session_seconds', '会话wall s', 5),
    ('startup_total_seconds', '消费者入口至末输出 s（含加载／冷准备）', 5),
    ('startup_to_ready_seconds', '启动至ready s', 5),
):
    row(label, [rows[a][key]['median'] for a in arms], digits)
for key, label in (
    ('gpu_dedicated_bytes', 'GPU dedicated全程观测峰 GiB'),
    ('gpu_shared_bytes', 'GPU shared全程观测峰 GiB'),
    ('working_set_bytes', '进程working set观测峰 GiB'),
    ('private_commit_bytes', '进程private commit观测峰 GiB'),
):
    row(label, [rows[a]['memory_sampled_peaks_GiB'][key] for a in arms], 3)
lines += [
    '',
    '本窗current比before的完整decode／综合中位分别高**0.81%／0.59%**，合计prefill低1.13%；样本范围重叠，不能认定稳定提速或把差异归单个修复。比llama完整decode慢**3.77%**、综合慢**1.01%**；比原dense decode慢3.17%。完整decode是先逐进程求96／sumD再取三进程中位，表中不混用pooled速率。',
]
for key, label in (('aggregate_decode_96_over_sumD_TPS', 'decode'), ('session_outputs_99_over_session_TPS', '综合')):
    ranges = '／'.join(f'{rows[a][key]["min"]:.2f}–{rows[a][key]["max"]:.2f}' for a in arms)
    lines.append(f'current／before／dense／参考的{label}三进程范围为 **{ranges} tok/s**。')
current_cold = [x['raw_call_stats']['median'] for x in rows['current']['pure_reuse_cold_by_turn_ms']]
before_cold = [x['raw_call_stats']['median'] for x in rows['before']['pure_reuse_cold_by_turn_ms']]
lines += ['', '零重录decode的完整准备桶：各轮汇集3进程共90次实际调用，current中位约' +
          '／'.join(f'{x:.3f}' for x in current_cold) + 'ms，before约' +
          '／'.join(f'{x:.3f}' for x in before_cold) + 'ms；不是纯函数自耗时，也不是进程速率的平均。首用与真实边界仍允许重录。']
for arm, label in zip(arms, ('current', 'before', 'dense', '参考')):
    phases = '→'.join('未知' if x is None else f'{x:.3f}' for x in rows[arm]['memory_phase_dedicated_max_GiB_in_phase_order'])
    lines.append(f'{label}的P1→D1→P2→D2→P3→D3专用GPU观测峰GiB为 **{phases}**。')
gaps = '／'.join(f'{rows[a]["actual_sample_interval_ms"]["median"]:.2f}' for a in arms)
lines += [
    f'current／before专用GPU峰相同，仍比dense高30MiB、比参考低约82MiB；差值不能全部归状态载荷。实际旁采间隔中位current／before／dense／参考约{gaps}ms，四臂ready边界占用均未知，GPU峰是采样下界；CPU与GPU不相加。',
    '12个计时与4个内存进程的99个预测ID均相同；不代表独立质量验收。未固定时钟或独占GPU，各臂仅3计时样本，不与旧窗口合算或签长期胜负。nvidia-smi窗口快照是滚动观察，不能由末次高利用率断言外部背景负载。',
    '[原始样本、源码与独立复算](../evidence/performance/qwen-indexed-preparation-2026-10-21.json)；[前缀／分支52向量及原18／72回归](../evidence/correctness/qwen-prefix-reuse-2026-10-21.json)；[前一完整窗口](../evidence/performance/qwen-paged-prepare-2026-10-21.json)。剩余COW／分散复制、准备／发布及多capture范围成本继续调查。', '',
]
path = R / 'docs/developer/current-work.md'
old = path.read_text(encoding='utf-8')
start = old.index('## 最新完整性能对比')
path.write_text(old[:start] + '\n'.join(lines), encoding='utf-8')
print('Updated authoritative current-work table from actual process medians.')
