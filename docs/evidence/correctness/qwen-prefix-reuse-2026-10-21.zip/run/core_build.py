"""Only changed host owners. Preserve old native and meaningful test objects."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
T = R / '.scratch/paged-prepare-20261021'
V = R / '.scratch/paged-recording-20261021'
A = R / '.scratch/architecture-refactor-2026-10-18'
W = A / 'd4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_host', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('compile', 'cpu', 'cuda'))
parser.add_argument('--attempt', type=int, default=1)
args = parser.parse_args()
if args.mode == 'compile':
    jobs = [
        ('src/graph/region_access.cc', A / 'projected-bind-cold-index/checks/host1/08-graph-region_access-identity.json'),
        ('src/graph/resources.cc', V / 'checks/attempt1/graph--resources/identity.json'),
        ('src/graph_batch/batch.cc', V / 'checks/attempt1/graph_batch--batch/identity.json'),
        ('src/graph_batch/paged_append.cc', T / 'checks/attempt1/graph_batch--paged_append/identity.json'),
    ]

    def one(job):
        path, recipe = job
        source = R / path
        tag = source.parent.name + '--' + source.stem
        out = S / f'core-checks/attempt{args.attempt}' / tag
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        frozen = b.identity(source)
        snap = out / 'source' / source.relative_to(R)
        snap.parent.mkdir(parents=True, exist_ok=True)
        snap.write_bytes(source.read_bytes())
        command = b.host_command(c.read(recipe)['command'], source, tag, out)
        c.save(out / 'compile-plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe), CXX=1, NVCC=0, SDK_builds=0))
        env, _ = b.environment(command, [], out)
        c.execute('compile', command, env, out)
        deps = c.read(out / (tag + '-deps.json'))['Data']
        record = dict(source=frozen, object=b.identity(out / (tag + '.obj')), command=command,
            replaced_object=c.read(recipe)['object'],
            dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
        assert h.same(frozen) and all(h.same(x) for x in record['dependencies'])
        c.save(out / 'identity.json', record)
        return record

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = list(pool.map(one, jobs))
    c.save(S / f'compiled-core-attempt{args.attempt}.json', dict(records=records, CXX=len(records), NVCC=0, SDK_builds=0, GPU_runs=0))
    print('Only four related core host owners compiled.', flush=True)
else:
    mode = args.mode
    prior_path = T / (mode + '-ready.json')
    prior = c.read(prior_path)
    base = c.read(prior['link_plan']['path'])
    assert all(h.same(x) for x in base['inputs'])
    records = c.read(S / f'compiled-core-attempt{args.attempt}.json')['records']
    replacements = {c.key(x['replaced_object']['path']):x['object'] for x in records}
    assert all(sum(c.key(x['path']) == key for x in base['inputs']) == 1 for key in replacements)
    assert all(h.same(x['source']) and h.same(x['object']) and all(h.same(d) for d in x['dependencies']) for x in records)
    out = S / f'{mode}-link{args.attempt}'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / (mode + '.exe')
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(prior['link_plan']['path']),
        replaced_inputs=[dict(before=x['replaced_object'], after=x['object']) for x in records], links=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    for dll in Path(prior['image']['path']).parent.glob('*.dll'):
        os.link(dll, out / dll.name)
    runtime = c.read(prior['runtime_environment']['path'])
    runtime['PATH'] = env['PATH']
    runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
    if mode == 'cpu' and 'CPU_native_overlay' in runtime:
        runtime['CPU_native_overlay']['destination'] = b.identity(out / 'hyle_ggml_cpu_append_hyca.dll')
    c.save(out / 'runtime-environment.json', runtime)
    c.save(S / f'{mode}-ready-attempt{args.attempt}.json', dict(image=b.identity(image), source=prior['source'],
        fresh_sources=[x['source'] for x in records],
        link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'),
        CXX=0, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    print('Linked original meaningful fixture with changed current core:', mode, flush=True)
