"""Add a resume of the previously prefix-hit child after real eviction."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
data = S / 'inputs'
path = data / 'plan.json'
plan = json.loads(path.read_text(encoding='utf-8'))
(data / 'plan-before-pressure-resume.json').write_bytes(path.read_bytes())


def schedule(name, phases):
    folder = data / name
    folder.mkdir(exist_ok=False)
    records, lines = [], []
    for i, (kind, ids) in enumerate(phases):
        file = folder / f'{i + 1}-{kind}.ids'
        file.write_text(' '.join(map(str, ids)) + '\n', encoding='utf-8')
        lines.append(f'{kind} {file.name}')
        records.append(dict(kind=kind, ids=ids, path=str(file)))
    file = folder / 'schedule.txt'
    file.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return dict(schedule=str(file), phases=records)


def phases(case):
    return [(x['kind'], x['ids']) for x in plan['cases'][case]['phases']]


continuation = [('prompt', [701, 702, 703, 704]), ('decode', [705])]
plan['cases']['branch_a_pressure'] = schedule('branch_a_pressure', phases('branch_a') + continuation)
plan['cases']['baseline_a_pressure'] = schedule('baseline_a_pressure', phases('baseline_a') + continuation)
plan['cases']['baseline_b_monolithic'] = schedule('baseline_b_monolithic', phases('branch_b'))
manifest = Path(plan['pressure_manifest'])
manifest.write_text('seed seed/schedule.txt\nbranch_a branch_a_pressure/schedule.txt\nbranch_b branch_b/schedule.txt\nfull_hit full_hit/schedule.txt\nchanged changed/schedule.txt\n', encoding='utf-8')
plan['pressure_requires_prefix_hit_branch_a_then_actual_chunk_restore'] = True


def identity(file):
    blob = file.read_bytes()
    return dict(path=str(file), bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest())


plan['input_files'] = [identity(f) for f in sorted(data.rglob('*')) if f.is_file() and f != path]
path.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
print('Added same-chunk pressure resume and independent monolithic-miss oracle; no original baseline input modified.')
