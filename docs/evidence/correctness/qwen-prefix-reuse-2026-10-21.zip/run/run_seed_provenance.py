"""Independent old-image P129 -> T16 -> D1/D1 oracle for imported state."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
F = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21'
spec = importlib.util.spec_from_file_location('original_checker', F / 'multi-session-isolation-2026-10-21/run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
plan = m.read(S / 'inputs/plan.json')
ready_path = R / '.scratch/paged-prepare-20261021/qwen-ready.json'
ready = m.read(ready_path)
image = m.ready_image(ready_path)
original, _ = m.original_commands()
original_inputs = Path(original[original.index('--inputs') + 1])
folder = S / 'baselines/baseline_seed_monolithic'
folder.mkdir(exist_ok=False)
inputs = folder / 'inputs'
inputs.mkdir()
os.link(original_inputs / 'weights.tsv', inputs / 'weights.tsv')
seed = plan['cases']['full_hit']['phases'][0]['ids']
(inputs / 'prompt.ids').write_text(' '.join(map(str, seed)) + '\n', encoding='utf-8')
phases = plan['cases']['seed']['phases']
assert phases[2]['kind'] == 'prompt' and len(phases[2]['ids']) == 16
assert len(phases[3]['ids']) == 2
command = [image['path'], '--inputs', str(inputs), '--continuation', phases[2]['path'],
    '--decode-ids', phases[3]['path'], '--steps', '3', '--capacity', '256',
    '--progress', 'direct', '--replay', 'auto', '--trace', str(folder / 'trace'), '--trace-level', 'decisions']
env = os.environ.copy()
env['PATH'] = m.read(ready['runtime_environment']['path'])['PATH']
record = dict(command=command, cwd=str(R), image=image, ready=m.identity(ready_path),
    runtime_environment=ready['runtime_environment'], started_unix_ns=time.time_ns(),
    purpose='Actual pressure source was monolithic129 checkpoint imported after eviction; independent same-actual-partition oracle, original pre-prefix image.',
    weights_copied=0, manifest_hardlinked=True, input_plan=m.identity(S / 'inputs/plan.json'),
    input_files=[m.identity(x) for x in (inputs / 'weights.tsv', inputs / 'prompt.ids', Path(phases[2]['path']), Path(phases[3]['path']))],
    throughput_evidence=False, gpu_concurrent_execution=False)
m.save(folder / 'command.json', record)
process = None
with (folder / 'stdout.log').open('wb') as so, (folder / 'stderr.log').open('wb') as se:
    try:
        process = subprocess.Popen(command, cwd=R, env=env, stdout=so, stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
        record['pid'] = process.pid
        try:
            record['exit'] = process.wait(timeout=180)
        except subprocess.TimeoutExpired:
            record['timeout'] = True
            process.kill()
            record['exit'] = process.wait()
    finally:
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()
        record['finished_unix_ns'] = time.time_ns()
        m.save(folder / 'result.json', record)
assert record['exit'] == 0 and not record.get('timeout')
observation = json.loads((folder / 'stdout.log').read_text(encoding='utf-8').splitlines()[-1])
# Legacy JSON reports the continuation decision plus two decode decisions;
# its original prefill decision is present in stderr and the real trace.
assert observation['visible_tokens'] == 147 and len(observation['generated_ids']) == 3
m.save(folder / 'observation.json', observation)
print('Independent old-image P129 -> T16 -> D1/D1 actual-provenance oracle exit0.', flush=True)
