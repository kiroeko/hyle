"""Publish bounded source/command/result evidence, without SDKs or vectors."""
from pathlib import Path
import hashlib
import json
import zipfile
S = Path(__file__).resolve().parent
R = S.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    blob = path.read_bytes()
    return dict(path=str(path), bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


ready = read(S / 'ready-attempt3.json')
assert identity(Path(ready['image']['path'])) == ready['image']
checker = read(S / 'review/check_actual-provenance.json')
assert checker['status'] == 'passed'
for folder in ('single-run3', 'multi-run3'):
    assert read(S / folder / 'summary.json')['passed']
for folder in ('cpu-run1', 'cuda-run1', 'main-run4', 'pressure-run3'):
    assert read(S / folder / 'result.json')['exit'] == 0
table = read(S / 'performance/public-table.json')
assert len(read(S / 'performance/timing/runs.json')) == 12
assert len(read(S / 'performance/memory/runs.json')) == 4
product_paths = [
    'tools/qwen35_text/main.cc', 'tools/qwen35_text/session_state.h',
    'tools/qwen35_text/prefix_cache.h', 'tools/qwen35_text/schedule.h',
    'tools/qwen35_text/session_schedule.h', 'include/hyle/graph/detail/region_access.h',
    'src/graph/region_access.cc', 'src/graph/resources.cc',
    'src/graph_batch/batch.cc', 'src/graph_batch/paged_append.cc', 'src/graph/executable.cc',
]
sources = [identity(R / p) for p in product_paths]
vectors = [identity(p) for p in sorted(S.rglob('*')) if p.is_file() and p.suffix in ('.bf16', '.f32')]
save(S / 'vector-identities.json', dict(vectors=vectors, payloads_in_archive=False,
    canonical_oracle_retained_at='.scratch/multi-session-20261021/attempt2/baseline',
    rule='Actual compared byte identities are preserved; do not duplicate model decision vectors in the source/results archive.'))
core = read(S / 'compiled-core-attempt3.json')['records']
main = read(S / 'checks/attempt3/identity.json')
assert all(identity(Path(x['source']['path'])) == x['source'] for x in [*core, main])
docs = ['docs/developer/current-work.md', 'docs/developer/performance/decode.md', 'tools/qwen35_text/README.md']
extensions = {'.py', '.json', '.jsonl', '.md', '.txt', '.cc', '.h', '.diff', '.log', '.csv', '.ps1', '.tsv'}
files = [p for p in sorted(S.rglob('*')) if p.is_file() and p.suffix.lower() in extensions and p.name != 'cleanup-plan.json']
archive_path = R / 'docs/evidence/correctness/qwen-prefix-reuse-2026-10-21.zip'
assert not archive_path.exists(), 'Never overwrite already published evidence.'
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in files:
        z.write(path, 'run/' + path.relative_to(S).as_posix())
    for path in product_paths + docs:
        z.write(R / path, 'source/' + path)
    manifest = dict(files=[dict(archive_path='run/' + p.relative_to(S).as_posix(), **identity(p)) for p in files],
        current_sources=sources, docs=[identity(R / p) for p in docs],
        omitted=['model weights', 'SDKs', 'native libraries', 'objects', 'images', 'maps', 'duplicate vector payloads'])
    z.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive_path) as z:
    assert z.testzip() is None
archive = identity(archive_path)
main_observation = read(S / 'main-run4/observation.json')
pressure = read(S / 'pressure-run3/observation.json')
common = dict(date='2026-10-21', archive=archive, source_files=sources,
    current_ready=identity(S / 'ready-attempt3.json'), current_image=ready['image'],
    link_plan=identity(Path(ready['link_plan']['path'])), runtime=ready['runtime_environment'],
    source_and_runtime_scope='Windows RTX4070 shared CUDA, process-local same Model/math. Other platforms and native providers not executed for this feature.',
    SDK_builds=0, NVCC=0)
correctness = dict(**common,
    result='passed within the explicitly executed serial scope; goal not complete',
    behavior=[
        'Exact longest completed full-state prefix lookup at prompt boundaries only; decode uses direct Session.',
        '12KV frames +36conv/GDN leases +positions +committed next_id hand off through original Snapshot; same original Graph execution.',
        'N committed real versions plus1 serial candidate; globally reserved backing charged once, directory aliases never count as release.',
        'Successful prompt/turn checkpoints; immutable token owners and actual evaluated chunk/next_id history for eviction reconstruction.',
        'Full hit returns saved decision with0 Graph, head-only Session, and unavailable tensor payload trace metadata.',
    ],
    main=dict(observation=main_observation, new_vectors=22, actual_input_tokens=168, logical_input_tokens=555, reused_tokens=387,
              full_hit_graph_calls=0, branch_suffix_rows=[1,16], committed_limit=4, shared_backing_bytes=110469168),
    pressure=dict(observation=pressure, new_vectors=30, actual_graph_calls=20, actual_graph_tokens=692,
        logical_input_tokens=689, logical_outputs=15, restored_calls=5, restored_tokens=132,
        committed_limit=2, shared_backing_bytes=65101872),
    independent_vector_check=dict(status='passed', report=identity(S / 'review/check_actual-provenance.json'),
        checker=identity(S / 'review/check_actual.py'), vectors=52, comparison='exact complete bytes; no tolerance relaxation'),
    canonical_regression=dict(single_vectors=18, four_session_vectors=72,
        reports=[identity(S / x / 'summary.json') for x in ('single-run3','multi-run3')]),
    actual_fixtures={x:dict(result=read(S / x / 'result.json'), source='original real fixture; no new mirror tests') for x in ('cpu-run1','cuda-run1')},
    cold_failure_and_fix=dict(
        original_failures=[dict(folder=x, result=identity(S / x / 'result.json'), stderr=identity(S / x / 'stderr.log')) for x in ('main-run1','main-run2','main-run3')],
        diagnosed='Family-wide operation proposal16384 and artifact preparation4096 caps exhausted at exact variant index6. No hardware/VRAM limit.',
        policy='Consumer computes only these two family caps from per-graph defaults times actual requested variants, with overflow checks. Library cumulative hard caps and all other limits unchanged.',
        actual8=dict(operation_proposals=21552, placement_attempts=4694, operation_cap=131072, placement_cap=32768),
        actual9=dict(operation_proposals=24246, placement_attempts=5289, operation_cap=147456, placement_cap=36864)),
    oracle_correction=dict(
        retained_failed_comparison=identity(S / 'review/check_actual-first-failure.json'),
        reason='Pressure seed restored equal-length state produced by another request monolithic129; initial P128+D1 baseline was a different partition. Cache key intentionally does not impose chunk provenance.',
        corrected_method='Independent original aa486 image ran actual P129 -> continuationT16 -> D1/D1. Pressure producer129 itself and late continuation/decode bytes matched exactly. No product, input, byte precision or candidate run changed.',
        independent_original_image=identity(S / 'baselines/baseline_seed_monolithic/command.json'),
        wrapper_correction='Original legacy JSON intentionally contains continuation+two decode IDs, excluding its overwritten prefill decision; initial wrapper length4 assertion corrected to3 using same exit0 output, without GPU rerun.'),
    limitations=['No exclusive in-place tail append or asynchronous recycle acceptance.',
        'No GPU concurrency, user-serving throughput, prefix-hit speed comparison or persistent cross-Model cache.',
        'No actual MTP/image/mmproj run; no new model or Apple/Vulkan complete consumer acceptance.',
        'Vector equality is numerical/state regression, not independent model-quality acceptance.'])
correct_path = R / 'docs/evidence/correctness/qwen-prefix-reuse-2026-10-21.json'
assert not correct_path.exists()
save(correct_path, correctness)
performance = dict(**common,
    correctness_evidence=identity(correct_path),
    method=dict(timing_processes=12, separate_memory_processes=4, processes_per_arm=3,
        workload=table['workload'], prefix_policy='off in single-session Hyle arms',
        trace=False, profiler=False, preparation_diagnostics=False, concurrent_GPU=False,
        rates='median across3 process rates; pooled statistics separately named, not used as table values'),
    public_table=table, independent_review=identity(S / 'performance/independent-review.json'),
    raw_timing=identity(S / 'performance/timing/runs.json'), raw_memory=identity(S / 'performance/memory/runs.json'),
    conclusion='Current decode101.58 vsbefore100.77 vsllama105.56; output90.90 vs90.37 vs91.83. Overlapping ranges do not establish a stable speedup. Dedicated sampled peak unchanged vsbefore.',
    changes='Append-known-node/proof chain38 full visits ->2full+36indexed; reuse original immutable layout page footprint. Prefix consumer and cold budget/error improvements included; six changed object inputs, no single-function isolation.',
    limits=['No fixed clocks or exclusive GPU. Finite3timing samples/arm only.',
        'Ready memory baseline unknown in all arms; sampled peaks are lower bounds; CPU/GPU counters overlap.',
        'Single-session prefix cache off; this does not measure prefix hit speed or multi-user throughput.',
        'No background-load causal claim from rolling nvidia-smi end snapshots.'])
perf_path = R / 'docs/evidence/performance/qwen-indexed-preparation-2026-10-21.json'
assert not perf_path.exists()
save(perf_path, performance)
save(S / 'published.json', dict(correctness=identity(correct_path), performance=identity(perf_path), archive=archive))
print(json.dumps(dict(correctness=identity(correct_path), performance=identity(perf_path), archive=archive), indent=2))
