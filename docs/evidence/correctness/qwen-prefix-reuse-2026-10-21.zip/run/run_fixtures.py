"""Original actual CPU/CUDA fixtures, root serial; no speed claims."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
S = Path(__file__).resolve().parent
R = S.parents[1]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')


for mode in ('cpu', 'cuda'):
    ready_path = S / f'{mode}-ready-attempt1.json'
    ready = read(ready_path)
    image = ready['image']
    assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest() == image['sha256']
    folder = S / f'{mode}-run1'
    folder.mkdir(exist_ok=False)
    env = os.environ.copy()
    env['PATH'] = read(Path(ready['runtime_environment']['path']))['PATH']
    record = dict(command=[image['path']], cwd=str(R), image=image, source=ready['source'],
                  runtime_environment=ready['runtime_environment'], throughput_evidence=False,
                  started_unix_ns=time.time_ns(), gpu_concurrent_execution=False)
    save(folder / 'command.json', record)
    process = None
    with (folder / 'stdout.log').open('wb') as so, (folder / 'stderr.log').open('wb') as se:
        try:
            process = subprocess.Popen(record['command'], cwd=R, env=env, stdout=so,
                stderr=se, creationflags=subprocess.CREATE_NO_WINDOW)
            record['pid'] = process.pid
            try:
                record['exit'] = process.wait(timeout=180)
            except subprocess.TimeoutExpired:
                record['timeout'] = True
                process.kill()
                record['exit'] = process.wait()
        finally:
            if process is not None and process.poll() is None:
                process.kill()
                process.wait()
            record['finished_unix_ns'] = time.time_ns()
            save(folder / 'result.json', record)
    assert record['exit'] == 0 and not record.get('timeout'), folder
    print('Actual original', mode, 'fixture passed:', folder, flush=True)
