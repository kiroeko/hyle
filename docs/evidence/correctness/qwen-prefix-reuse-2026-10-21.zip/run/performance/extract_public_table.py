"""Host-only public table extraction from an already frozen independent review."""
from pathlib import Path
import hashlib,json,statistics
S=Path(__file__).resolve().parent
src=S/'independent-review.json'; data=src.read_bytes()
expected='54501caf011521b68d875edf99383297e94eae6424c03e2be97cdbe57601c3f7'
assert hashlib.sha256(data).hexdigest()==expected
r=json.loads(data)
def brief(x): return {k:x[k] for k in ('count','min','median','max')}
def st(v): return dict(count=len(v),min=min(v),median=statistics.median(v),max=max(v))
phase_names=[f'round{i}_{kind}' for i in range(1,4)for kind in ('prefill','decode')]
rows={}
for arm,g in r['groups'].items():
    memory=r['memory_observations'][arm]
    rows[arm]={
        'prefill_256_TPS_by_turn':[brief(g['phases'][f'round{i}_prefill'])for i in range(1,4)],
        'decode_32_TPS_by_turn':[brief(g['phases'][f'round{i}_decode'])for i in range(1,4)],
        'aggregate_prefill_768_over_sumP_TPS':brief(g['metrics']['aggregate_prefill_tps']),
        'aggregate_decode_96_over_sumD_TPS':brief(g['metrics']['aggregate_decode_tps']),
        'session_outputs_99_over_session_TPS':brief(g['metrics']['output_tokens_per_second']),
        'session_inputs_864_over_session_TPS':brief(g['metrics']['processed_tokens_per_second']),
        'session_seconds':brief(g['metrics']['session_seconds']),
        'startup_total_seconds':brief(g['metrics']['startup_total_seconds']),
        'startup_to_ready_seconds':brief(g['loading']['startup_to_ready_seconds']),
        'first_token_elapsed_seconds':brief(g['loading']['first_token_elapsed_seconds']),
        'memory_sampled_peaks_GiB':{k:(v/(1<<30)if v is not None else None)for k,v in memory['sampled_peaks_bytes'].items()},
        'memory_phase_dedicated_max_GiB_in_phase_order':[(memory['phases'][name]['values']['gpu_dedicated_bytes']['max']/(1<<30)
            if memory['phases'][name]['values']['gpu_dedicated_bytes']['max']is not None else None)for name in phase_names],
        'memory_phase_samples_in_phase_order':[memory['phases'][name]['samples']for name in phase_names],
        'actual_sample_interval_ms':memory['actual_gaps_ms'],
        'memory_sample_count':memory['sample_count'],
        'ready_memory_baseline_unknown':memory['ready_baseline_unknown'],
    }
    if arm!='peer':
        selected=[p for p in r['timing_processes']if p['variant']==arm]
        rows[arm]['pure_reuse_cold_by_turn_ms']=[]
        for turn,group in enumerate(r['pure_reuse_cold_by_turn'][arm]):
            per_process=[p['pure_reuse_cold_by_turn'][turn]['cold_seconds']['median']*1000 for p in selected]
            rawstats=group['seconds']
            rows[arm]['pure_reuse_cold_by_turn_ms'].append(dict(turn=turn+1,
                raw_call_stats={k:rawstats[k]*1000 for k in ('min','median','max')},
                raw_call_count=rawstats['count'],per_process_medians=per_process,
                median_of_process_medians=statistics.median(per_process),
                source_field='prepared cold_batch_seconds, T=1 and capture_recorded=0; no time-based trimming'))
    else: rows[arm]['pure_reuse_cold_by_turn_ms']=None
keys=('aggregate_prefill_768_over_sumP_TPS','aggregate_decode_96_over_sumD_TPS','session_outputs_99_over_session_TPS','session_inputs_864_over_session_TPS')
comparisons={other:{key:(rows['current'][key]['median']/rows[other][key]['median']-1)*100 for key in keys}for other in ('before','dense','peer')}
report=dict(
    scope='All table speed values in rows are median/min/max across three fresh unmonitored processes per arm; pooled ratios are separately named and must not replace median cells.',
    source=dict(path=str(src.resolve()),bytes=len(data),sha256=expected),
    workload=dict(capacity=1024,turns=3,prefill_input_tokens_per_turn=256,decode_calls_per_turn=32,total_input_tokens=864,total_decode_calls=96,total_outputs=99,
                  total_outputs_definition='One host-visible decision per prompt plus one per teacher-forced decode call.'),
    phase_order=phase_names,
    rows=rows,current_vs_other_median_rate_change_percent=comparisons,
    pooled_ratios_for_separate_reference_only=r['aggregate_rates'],
    notes=[
        'Session rate is99 divided by one complete session wall, never an arithmetic average of phase TPS. Overall input rate is864/session.',
        'Per-process aggregate prefill/decode rates use768/sumP and96/sumD first, then median/min/max across processes.',
        'Pure-reuse cold raw-call median pools90 recorded=0 calls per turn across3processes. Per-process medians are also given so this cannot be mistaken for a process-rate median.',
        'Memory is one separate sampled process per arm. GiB=2^30 bytes; maxima are sampled lower bounds. Unknown ready baseline and zero-interior-sample phases remain unknown/null.',
        'GPU total is peak simultaneous dedicated+shared, not the sum of independent peaks. CPU working set/private commit/GPU shared are overlapping counters, not additive physical memory.',
        'Current vs before changes main plus5core objects; both use the same FI provider7f7d. This single-session benchmark has prefix cache off and does not measure hit speed or isolate a single patch.',
        'No new model process, GPU query, build, source change or memory sampling was performed for this extraction.'
    ])
p=S/'public-table.json';p.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),medians={a:dict(P=[x['median']for x in v['prefill_256_TPS_by_turn']],D=[x['median']for x in v['decode_32_TPS_by_turn']],Dtotal=v['aggregate_decode_96_over_sumD_TPS']['median'],total=v['session_outputs_99_over_session_TPS']['median'],session=v['session_seconds']['median'],startup=v['startup_total_seconds']['median'],ready=v['startup_to_ready_seconds']['median'],dedicated_GiB=v['memory_sampled_peaks_GiB']['gpu_dedicated_bytes'],phase_max_GiB=v['memory_phase_dedicated_max_GiB_in_phase_order'],interval_ms=v['actual_sample_interval_ms']['median'])for a,v in rows.items()},median_change_percent=comparisons),indent=2))
