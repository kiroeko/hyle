"""Independent host-only recomputation. Never launches a consumer or queries a device."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re
import shlex
import statistics

S = Path(__file__).resolve().parent
R = S.parents[2]
D = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21'
F = D / 'first-decode-startup-2026-10-21'
W = F / 'layout-workspace-facts-reuse-2026-10-21'
KEYS = ['working_set_bytes', 'private_commit_bytes', 'gpu_dedicated_bytes',
        'gpu_shared_bytes', 'gpu_total_bytes']


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8 << 20), b''):
            h.update(b)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def verify(record):
    actual = identity(record['path'])
    assert actual == record, (actual, record)
    return actual


def stats(values, samples=True):
    result = dict(count=len(values), min=min(values) if values else None,
                  median=statistics.median(values) if values else None,
                  max=max(values) if values else None)
    if samples:
        result['samples'] = values
    return result


def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), (a, b)


def steps(stderr):
    result = []
    pending = None
    for line in stderr.splitlines():
        if line.startswith('prepared T='):
            pairs = dict(re.findall(r'(\w+)=([^\s]+)', line))
            pending = {k: int(pairs[k]) for k in ['T', 'visible', 'capture_recorded', 'capture_reused']}
            pending['replay'] = pairs['replay']
            pending['cold_batch_seconds'] = float(pairs['cold_batch_seconds'])
        match = re.match(r'^(round(\d+)_(prefill|decode(\d+)))\s+tokens=', line)
        if not match:
            continue
        fields = dict(re.findall(r'(\w+)=([^\s]+)', line))
        row = dict(name=match[1], turn=int(match[2]), kind='prefill' if match[3] == 'prefill' else 'decode',
                   local=int(match[4]) if match[4] else None, tokens=int(fields['tokens']),
                   visible=int(fields['visible']), predicted=int(fields.get('next', fields.get('predicted'))),
                   step_seconds=float(fields['step_seconds']))
        for key in ['seconds','submit_seconds']:
            if key in fields: row[key] = float(fields[key])
        if pending:
            assert row['visible'] == pending['visible'] and row['tokens'] == pending['T']
            row['prepared'] = pending
            pending = None
        result.append(row)
    assert pending is None
    return result


plan = read(S / 'timing/inputs.json')['plan']
assert plan['processed_tokens'] == 864 and plan['generated_tokens'] == 99
assert plan['phase_count'] == 6 and plan['turn_count'] == 3
manifest = verify(plan['manifest'])
manifest_path = Path(manifest['path'])
input_files = []
position = 0
expected_steps = []
for line, phase in zip(manifest_path.read_text().splitlines(), plan['phases'], strict=True):
    kind, relative = shlex.split(line)
    assert kind == ('prompt' if phase['kind'] == 'prefill' else 'decode')
    path = manifest_path.parent / relative
    ids = [int(x) for x in path.read_text().split()]
    assert ids == phase['ids'] and len(ids) == phase['input_tokens']
    assert all(0 <= x < 248320 for x in ids)
    assert phase['visible_before'] == position
    input_files.append(identity(path))
    count = 1 if kind == 'prompt' else len(ids)
    assert count == phase['calls']
    for i in range(count):
        n = len(ids) if kind == 'prompt' else 1
        position += n
        expected_steps.append(dict(name=phase['name'] if kind == 'prompt' else phase['name'] + str(i + 1),
                                   tokens=n, visible=position))
    assert phase['visible_tokens'] == position
assert position == 864 and len(expected_steps) == 99

timing_input = read(S / 'timing/inputs.json')
memory_input = read(S / 'memory/inputs.json')
assert timing_input['plan'] == memory_input['plan']
assert timing_input['order'] == ['current','before','dense','peer','peer','dense','before','current','before','current','peer','dense']
assert memory_input['order'] == ['before','current','dense','peer']
assert timing_input['profiler'] is False and timing_input['memory_monitor'] is False
assert memory_input['profiler'] is False and memory_input['memory_monitor'] is True
images = {k: verify(v) for k, v in timing_input['images'].items()}
assert images == memory_input['images']

processes = []
raw_ids = []
driver_summary = read(S / 'timing/summary.json')
recorded_runs = read(S / 'timing/runs.json')
for index, variant in enumerate(timing_input['order'], 1):
    folder = S / 'timing' / f'{index:02}-{variant}'
    receipt = read(folder / 'result.json')
    assert receipt['exit'] == 0 and not receipt.get('timeout') and not receipt['reader_errors']
    assert receipt['image'] == images[variant]
    assert receipt['command'] == timing_input['commands'][index - 1]['command']
    assert '--trace' not in receipt['command'] and '--preparation-diagnostics' not in receipt['command']
    stderr = (folder / 'stderr.log').read_text()
    raw = read(folder / 'peer-result.json') if variant == 'peer' else json.loads(
        next(x for x in reversed((folder / 'stdout.log').read_text().splitlines()) if x.startswith('{')))
    for key in ['processed_tokens', 'generated_tokens', 'phase_count', 'turn_count']:
        assert raw[key] == plan[key]
    assert not raw.get('diagnostic', False)
    actual_steps = steps(stderr)
    assert len(actual_steps) == 99
    for actual, expected in zip(actual_steps, expected_steps, strict=True):
        for key in ['name', 'tokens', 'visible']:
            assert actual[key] == expected[key]
        assert actual['step_seconds'] > 0
    ids = raw.get('predicted_ids', raw.get('generated_ids'))
    assert ids == [x['predicted'] for x in actual_steps] and len(ids) == 99
    raw_ids.append(ids)
    phases = []
    for p, expected in zip(raw['phases'], plan['phases'], strict=True):
        for key in ['name', 'kind', 'turn', 'input_tokens']:
            assert p[key] == expected[key]
        assert p['context_before'] == expected['visible_before'] and p['context_after'] == expected['visible_tokens']
        selected = [x for x in actual_steps if x['turn'] == p['turn'] and x['kind'] == p['kind']]
        assert len(selected) == expected['calls']
        rounded_step_sum = sum(x['step_seconds'] for x in selected)
        # stderr uses six significant digits; JSON keeps the unrounded double sum.
        precision_bound = sum(5.1 * 10 ** (math.floor(math.log10(x['step_seconds'])) - 6) for x in selected)
        assert abs(rounded_step_sum - p['step_sum_seconds']) <= precision_bound
        phases.append(dict(name=p['name'], kind=p['kind'], turn=p['turn'],
                           context_before=p['context_before'], context_after=p['context_after'],
                           input_tokens=p['input_tokens'], seconds=p['seconds'],
                           step_sum_seconds=p['step_sum_seconds'], tps=p['input_tokens'] / p['seconds'],
                           first_two_step_seconds=sum(x['step_seconds'] for x in selected[:2]) if p['kind'] == 'decode' else None,
                           decode7_to32_tps=26 / sum(x['step_seconds'] for x in selected[6:]) if p['kind'] == 'decode' else None))
    pre = sum(x['seconds'] for x in phases if x['kind'] == 'prefill')
    dec = sum(x['seconds'] for x in phases if x['kind'] == 'decode')
    step_sum = sum(x['step_sum_seconds'] for x in phases)
    totals = dict(session_seconds=raw['session_seconds'], startup_total_seconds=raw['startup_total_seconds'],
                  processed_tokens_per_second=864 / raw['session_seconds'], output_tokens_per_second=99 / raw['session_seconds'],
                  cold_processed_tokens_per_second=864 / raw['startup_total_seconds'], cold_output_tokens_per_second=99 / raw['startup_total_seconds'],
                  compute_step_sum_seconds=step_sum, session_minus_step_sum_seconds=raw['session_seconds'] - step_sum)
    for key, value in totals.items():
        close(value, recorded_runs[index - 1]['observation']['metrics'][key])
    totals.update(aggregate_prefill_tps=768 / pre, aggregate_decode_tps=96 / dec,
                  prefill_seconds=pre, decode_seconds=dec)
    capture_counts = Counter((x['tokens'], x['prepared']['replay'], x['prepared']['capture_recorded'],
                             x['prepared']['capture_reused']) for x in actual_steps if 'prepared' in x)
    loading = dict(raw.get('loading', {}))
    for line in stderr.splitlines():
        if line.startswith('weights_load_seconds='):
            loading['model_load_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('first_token_elapsed_seconds='):
            loading['first_token_elapsed_seconds'] = float(line.split('=', 1)[1])
        elif line.startswith('initialized '):
            for key, value in re.findall(r'(\w+)=([^\s]+)', line):
                try:
                    loading[key] = float(value)
                except ValueError:
                    pass
    process = dict(index=index, variant=variant, result=identity(folder / 'result.json'),
                   stdout=identity(folder / 'stdout.log'), stderr=identity(folder / 'stderr.log'),
                   command=receipt['command'], metrics=totals, phases=phases, loading=loading,
                   decision_calls=99, decode_calls=96, input_tokens=864,
                   ids_sha256=hashlib.sha256(json.dumps(ids, separators=(',', ':')).encode()).hexdigest(),
                   replay_counts=[dict(tokens=k[0], replay=k[1], recorded=k[2], reused=k[3], calls=v)
                                  for k, v in sorted(capture_counts.items())],
                   recapture_steps=[dict(name=x['name'], visible=x['visible'], recorded=x['prepared']['capture_recorded'], reused=x['prepared']['capture_reused'])
                                    for x in actual_steps if 'prepared' in x and x['prepared']['capture_recorded']])
    process['pure_reuse_cold_by_turn'] = [dict(turn=turn, cold_seconds=stats([row['prepared']['cold_batch_seconds'] for row in actual_steps if row['turn']==turn and row['kind']=='decode' and row.get('prepared',{}).get('capture_recorded')==0])) for turn in range(1,4)] if variant!='peer' else None
    process['cold_by_turn_all_decode'] = [dict(turn=turn, cold_seconds=stats([row['prepared']['cold_batch_seconds'] for row in actual_steps if row['turn']==turn and row['kind']=='decode'])) for turn in range(1,4)] if variant!='peer' else None
    if variant != 'peer':
        assert raw.get('prefix_cache', 'off') == 'off'
        assert raw.get('restored_calls', 0) == 0 and raw.get('restored_tokens', 0) == 0
        if variant == 'current':
            assert raw['actual_graph_calls'] == 99 and raw['actual_graph_tokens'] == 864
            assert raw['prefix_hits'] == raw['prefix_misses'] == raw['reused_tokens'] == 0
        process['cache_metadata'] = {k:v for k,v in raw.items() if k.startswith('cache_') or k.startswith('prefix_') or k in ('actual_graph_calls','actual_graph_tokens','reused_tokens')}
        process['cold_family_logs'] = [line for line in stderr.splitlines() if line.startswith(('compile full text finite family','compiled text finite family'))]
    processes.append(process)
assert all(ids == raw_ids[0] for ids in raw_ids)
groups = {}
for variant in images:
    selected = [x for x in processes if x['variant'] == variant]
    groups[variant] = dict(metrics={k: stats([x['metrics'][k] for x in selected]) for k in selected[0]['metrics']},
                           phases={p['name']: stats([x['phases'][j]['tps'] for x in selected])
                                   for j, p in enumerate(selected[0]['phases'])},
                           loading={k:stats([x['loading'][k] for x in selected]) for k,v in selected[0]['loading'].items()
                                    if isinstance(v, (float,int))})
    for key, value in driver_summary['groups'][variant]['metrics'].items():
        assert value == groups[variant]['metrics'][key]
    for name, value in driver_summary['groups'][variant]['phases'].items():
        assert value == groups[variant]['phases'][name]
    assert groups[variant]['loading'] == driver_summary['groups'][variant]['loading']

memory = {}
peak_keys = dict(working_set_bytes='sampled_max_working_set_bytes', private_commit_bytes='sampled_max_private_commit_bytes',
                 gpu_dedicated_bytes='sampled_peak_gpu_dedicated_bytes', gpu_shared_bytes='sampled_peak_gpu_shared_bytes',
                 gpu_total_bytes='sampled_peak_gpu_total_bytes')
for index, variant in enumerate(memory_input['order'], 1):
    folder = S / 'memory' / f'{index:02}-{variant}'
    receipt = read(folder / 'result.json')
    assert receipt['exit'] == 0 and receipt['memory_only'] and not receipt['throughput_evidence']
    assert receipt['image'] == images[variant]
    data, reported = read(folder / 'memory.json'), read(folder / 'memory-summary.json')
    assert not data['gpu_setup_error'] and not data['thread_error']
    samples = data['samples']
    running = [x for x in samples if x['process_running']]
    assert len(samples) == reported['sample_count'] and len(running) == reported['running_sample_count']
    peaks = {key: max((x[key] for x in samples if x.get(key) is not None), default=None) for key in KEYS}
    for key, value in peaks.items():
        assert value == data['peaks'][peak_keys[key]]
    assert peaks['gpu_total_bytes'] == max((x['gpu_dedicated_bytes'] + x['gpu_shared_bytes'] for x in samples
        if x.get('gpu_dedicated_bytes') is not None and x.get('gpu_shared_bytes') is not None), default=None)
    intervals = [(b['timestamp_ns'] - a['timestamp_ns']) / 1e6 for a, b in zip(running, running[1:])]
    costs = [x['sample_duration_ns'] / 1e6 for x in running]
    assert stats(intervals) == reported['actual_sample_gaps_ms'] and stats(costs) == reported['sample_cost_ms']
    assert reported['sampled_peaks'] == data['peaks']
    boundaries = {x['name']: x['timestamp_ns'] for x in receipt['markers']}
    ready_rows = [x for x in running if boundaries.get('ready_before_prefill') is not None and
                  boundaries['ready_before_prefill'] <= x['timestamp_ns'] <= boundaries['round1_prefill_begin']]
    assert reported['ready_baseline']['unknown'] == (not ready_rows)
    assert reported['ready_baseline']['sample'] == (ready_rows[-1] if ready_rows else None)
    windows = {}
    for phase in plan['phases']:
        name = phase['name'];begin, end = boundaries[name + '_begin'], boundaries[name + '_end']
        rows = [x for x in running if begin <= x['timestamp_ns'] <= end]
        original = reported['phase_windows'][name]
        assert original['sample_count'] == len(rows) and not original['missing_boundary']
        vals = {k: stats([x[k] for x in rows if x.get(k) is not None], samples=False) for k in KEYS}
        for k in KEYS:
            for stat in ['count', 'min', 'median', 'max']:
                assert vals[k][stat] == original['values'][k][stat]
            assert sum(x.get(k) is None for x in rows) == original['null_sample_counts'][k]
        before = max((x for x in running if x['timestamp_ns'] <= begin), key=lambda x:x['timestamp_ns'], default=None)
        after = min((x for x in running if x['timestamp_ns'] >= end), key=lambda x:x['timestamp_ns'], default=None)
        ages = dict(before=begin-before['timestamp_ns'] if before else None, after=after['timestamp_ns']-end if after else None)
        delta = {k:after[k]-before[k] if before and after and before.get(k) is not None and after.get(k) is not None else None for k in KEYS}
        assert ages == original['bracket_ages_ns'] and delta == original['bracket_delta_bytes']
        windows[name] = dict(samples=len(rows), values=vals, null_counts=original['null_sample_counts'],
                             bracket_delta_bytes=delta, bracket_ages_ns=ages)
    memory[variant] = dict(result=identity(folder / 'result.json'), raw=identity(folder / 'memory.json'),
                           summary=identity(folder / 'memory-summary.json'), sample_count=len(samples), running_sample_count=len(running),
                           requested_interval_seconds=data['requested_interval_s'], actual_gaps_ms=stats(intervals, False),
                           sample_cost_ms=stats(costs, False), sampled_peaks_bytes=peaks,
                           null_counts={k: sum(x.get(k) is None for x in running) for k in KEYS},
                           ready_baseline_unknown=reported['ready_baseline']['unknown'], phases=windows,
                           setup_error=data['gpu_setup_error'], thread_error=data['thread_error'])

diagnostics = {}
for name in ['single-run3', 'multi-run3']:
    folder = S.parent / name
    summary, receipt = read(folder / 'summary.json'), read(folder / 'result.json')
    assert summary['passed'] and receipt['exit'] == 0 and receipt['image'] == images['current']
    pairs = summary['pairs'] if name == 'single-run3' else [x for v in summary['sessions'].values() for x in v]
    for pair in pairs:
        actual, baseline = verify(pair['actual']), verify(pair['baseline'])
        assert pair['byte_equal'] and actual['sha256'] == baseline['sha256'] and actual['bytes'] == baseline['bytes']
    assert len(pairs) == summary['vector_count']
    diagnostics[name] = dict(result=identity(folder / 'result.json'), summary=identity(folder / 'summary.json'),
                             verified_byte_equal_vectors=len(pairs), throughput_evidence=False)
cuda = read(S.parent / 'cuda-run1/result.json')
assert cuda['exit'] == 0
verify(cuda['image']);verify(cuda['source'])
diagnostics['append_cuda'] = dict(result=identity(S.parent / 'cuda-run1/result.json'),
    stdout=identity(S.parent / 'cuda-run1/stdout.log'), stderr=identity(S.parent / 'cuda-run1/stderr.log'),
    scope='Existing causal means/COW/retained snapshot checks and both take_append followed by submit FailedPrecondition; source and actual image bound by receipt.')

# Closure comparison is independent of the driver's throughput summaries.
current_ready = read(S.parent / 'ready-attempt3.json')
before_ready = read(R / '.scratch/paged-prepare-20261021/qwen-ready.json')
dense_ready = read(W / 'ready-for-root.json')
current_link = read(current_ready['link_plan']['path'])
before_link = read(before_ready['link_plan']['path'])
current_counts = Counter(x['sha256'] for x in current_link['inputs'])
before_counts = Counter(x['sha256'] for x in before_link['inputs'])
changed_product = read(S.parent / 'compiled-core-attempt3.json')['records']
changed_main = read(S.parent / 'checks/attempt3/identity.json')
changed = changed_product + [changed_main]
assert len(changed_product) == 5 and len(current_link['inputs']) == len(before_link['inputs']) == 192
assert sum((current_counts-before_counts).values()) == sum((before_counts-current_counts).values()) == 6
assert Counter(x['object']['sha256'] for x in changed) == current_counts-before_counts
seen_dependencies = {}
for row in changed:
    verify(row['source']); verify(row['object'])
    assert row['object'] in current_link['inputs']
    for dep in row['dependencies']:
        key = dep['path'].lower()
        if key not in seen_dependencies:
            verify(dep); seen_dependencies[key] = dep
        else: assert seen_dependencies[key]['sha256'] == dep['sha256']
assert current_ready['source'] == changed_main['source']
verify(current_ready['source'])
before_snapshot = identity(S.parent / 'implementation/before/tools/qwen35_text/main.cc')
assert before_snapshot['sha256'] == before_ready['source']['sha256'] and before_snapshot['bytes'] == before_ready['source']['bytes']
provider = read(R / '.scratch/paged-recording-20261021/checks/provider/identity.json')
assert provider['object'] in current_link['inputs'] and provider['object'] in before_link['inputs']
assert provider['source']['sha256'] == dense_ready['provider_source']['sha256'] == '7f7d4d036c187fd206955a61f9e9f7a7873d2ab56f4eb8ee6e5476f44f9674e7'
verify(provider['object'])
environments = {arm:read(path['path']) for arm,path in timing_input['environments'].items()}
staged = lambda env: {Path(x['path']).name:x['sha256'] for x in env.get('staged_dlls', [])}
assert staged(environments['current']) == staged(environments['before'])

# Check all four monitored observations against the same 99-step schedule too.
for index, variant in enumerate(memory_input['order'], 1):
    folder = S / 'memory' / f'{index:02}-{variant}'
    raw = read(folder/'peer-result.json') if variant=='peer' else json.loads(
        next(x for x in reversed((folder/'stdout.log').read_text().splitlines()) if x.startswith('{')))
    assert raw['processed_tokens']==864 and raw['generated_tokens']==99
    assert len(raw['phases']) == 6
    for actual, expected in zip(raw['phases'],plan['phases'],strict=True):
        assert all(actual[k]==expected[k] for k in ['turn','kind','name','input_tokens'])
        assert actual['context_before']==expected['visible_before'] and actual['context_after']==expected['visible_tokens']
    ids = raw.get('predicted_ids',raw.get('generated_ids'))
    assert ids == raw_ids[0]
    actual_steps = steps((folder/'stderr.log').read_text())
    assert len(actual_steps)==99
    for actual, expected in zip(actual_steps,expected_steps,strict=True):
        assert all(actual[k]==expected[k] for k in ['name','tokens','visible'])
    assert ids==[x['predicted'] for x in actual_steps]
    memory[variant]['predictions_equal_to_timing'] = True
    memory[variant]['stdout'] = identity(folder/'stdout.log')
    memory[variant]['stderr'] = identity(folder/'stderr.log')

aggregate_rates = {}
for arm in images:
    selected = [x for x in processes if x['variant']==arm]
    assert len(selected)==3
    aggregate_rates[arm] = dict(
        prefill_TPS=2304/sum(x['metrics']['prefill_seconds'] for x in selected),
        decode_TPS=288/sum(x['metrics']['decode_seconds'] for x in selected),
        session_output_TPS=297/sum(x['metrics']['session_seconds'] for x in selected),
        session_processed_TPS=2592/sum(x['metrics']['session_seconds'] for x in selected),
        median_process_prefill_TPS=groups[arm]['metrics']['aggregate_prefill_tps']['median'],
        median_process_decode_TPS=groups[arm]['metrics']['aggregate_decode_tps']['median'],
        median_process_session_output_TPS=groups[arm]['metrics']['output_tokens_per_second']['median'])

cold = {}
for arm in ['current','before','dense']:
    selected = [x for x in processes if x['variant']==arm]
    cold[arm] = [dict(turn=turn, seconds=stats([
        value for process in selected for value in process['pure_reuse_cold_by_turn'][turn-1]['cold_seconds']['samples']]))
        for turn in range(1,4)]
    for process in selected:
        assert [x['cold_seconds']['count'] for x in process['pure_reuse_cold_by_turn']] == [30,30,30]
    for process in selected:
        hot = [x for x in process['replay_counts'] if x['tokens']==1 and x['recorded']==0]
        assert sum(x['calls'] for x in hot)==90
        assert all(x['reused']==(1 if arm=='dense' else 7) for x in hot)

comparisons = {other:{key:(aggregate_rates['current'][key]/aggregate_rates[other][key]-1)*100
    for key in ['prefill_TPS','decode_TPS','session_output_TPS','session_processed_TPS']}
    for other in ['before','dense','peer']}
memory_delta = {other:{key:memory['current']['sampled_peaks_bytes'][key]-memory[other]['sampled_peaks_bytes'][key]
    if memory['current']['sampled_peaks_bytes'][key] is not None and memory[other]['sampled_peaks_bytes'][key] is not None else None
    for key in KEYS} for other in ['before','dense','peer']}

snapshots = {}
for mode in ['timing','memory']:
    snapshots[mode] = {point:dict(
        receipt=identity(S/mode/(point+'.json')),
        gpu_stdout=identity(S/mode/(point+'-gpu.stdout.log')),
        gpu_values=(S/mode/(point+'-gpu.stdout.log')).read_text().strip())
        for point in ['window-before','window-after']}

cpu = read(S.parent/'cpu-run1/result.json')
assert cpu['exit']==0
verify(cpu['source']);verify(cpu['image'])
diagnostics['append_cpu'] = dict(result=identity(S.parent/'cpu-run1/result.json'),
    stdout=identity(S.parent/'cpu-run1/stdout.log'),
    scope='Actual original CPU append fixture and new two-request nonmonotonic physical IDs/shared untouched prefix/unsorted dirty controls; no GPU timing claim.')

for name in ('main-run4','pressure-run3'):
    result = read(S.parent/name/'result.json')
    assert result['exit'] == 0 and result['image'] == images['current']

report = dict(
    status='Final independent recomputation from all twelve completed unmonitored timing processes and four separate monitored memory processes.',
    script=identity(__file__), adapted_algorithm_source=identity(R/'.scratch/paged-prepare-20261021/performance/review_calculate.py'),
    driver=identity(S.parent/'performance.py'), original_driver=identity(F/'multiturn/multiturn_run.py'),
    scope=dict(timing_processes=12, timing_processes_per_arm=3, separate_memory_processes=4,
        processed_tokens_per_process=864, predictions_per_process=99, decode_calls_per_process=96,
        prompt_calls_per_process=3, capacity=1024,
        generated_token_definition='Three last-row returned prompt tokens plus96 teacher-forced decode results; not free-running generation.',
        phases=[{k:p[k] for k in ['turn','name','input_tokens','calls','visible_before','visible_tokens']} for p in plan['phases']]),
    input_identities=dict(manifest=manifest, files=input_files), images=images,
    closure=dict(current_link_plan=verify(current_ready['link_plan']), before_link_plan=verify(before_ready['link_plan']),
        current_vs_before_link_inputs_each=192,
        current_only_object_hashes=dict(current_counts-before_counts), before_only_object_hashes=dict(before_counts-current_counts),
        changed_products=[dict(source=x['source'],object=x['object']) for x in changed_product],
        changed_consumer=dict(source=changed_main['source'],object=changed_main['object'],before_source=before_ready['source'],before_snapshot=before_snapshot),
        verified_unique_fresh_dependencies=len(seen_dependencies), identical_current_before_staged_DLLs=staged(environments['current']),
        unchanged_current_before_provider_object=provider['object'], current_before_dense_provider_source=provider['source'],
        distinction='Current vs before replaces main plus five host core objects together: exact-prefix consumer and explicit finite-family cold budgets; indexed RegionAccess visit/retired; cached selected batch reader proof lookup; layout-owned canonical page-footprint reuse; and exact candidate-limit diagnostics. Single schedule leaves prefix policy off, so these timings do not measure prefix hit speed. Both retain the earlier unused-lease skip, sorted append algorithm, paged capture retention and FI workspace-sizing provider. Dense and peer comparisons are whole implementations, not isolated patch estimates.',
        verification='Fresh changed source/object/dependency bytes were rehashed, all ready executable images were rehashed, actual process image/commands matched receipts, and link input multiset/DLL identities were compared. The six changed objects and their unique actual compile dependencies were rehashed. Retained unchanged192-input closure is not newly rebuilt or rehashed wholesale.'),
    fairness=dict(same_manifest_inputs_capacity=True, same_teacherforced_864_inputs_and99_decisions=True,
        all_99_predictions_equal_across_twelve_timing_and_four_memory_processes=True,
        all_99_step_positions_and_six_phase_contexts_match=True,
        timing_order=timing_input['order'], memory_order=memory_input['order'],
        no_timing_profiler=True, no_timing_memory_monitor=True, no_hidden_warmup=True,
        no_concurrent_benchmark_process=True, no_diagnostic_or_trace=True,
        timing_boundaries='Complete host-visible evaluate/phase/session includes layout/snapshot/permission/batch/replay preparation, enqueue/retirement, result transfer and publication. Cold loading/model/finite-family preparation is separately retained.',
        primary_rates='Pooled prefill2304/sum(all9 prefill phase walls per arm), decode288/sum(all9 decode phase walls per arm); session297/sum(three session walls). No mean of TPS. Median process rates and all per-process samples are separately retained.',
        memory_separate=True, snapshot_receipts=snapshots,
        environment='No fixed GPU clocks or exclusive device was established. Raw before/after device observations are retained below; utilization is rolling and can include immediately completed inference. It is not proof of external background interference. Memory window is separate. All twelve timing samples are retained without selecting a favorable window.'),
    all_driver_timing_statistics_recomputed_match=True,
    aggregate_rates=aggregate_rates, current_rate_change_percent=comparisons,
    groups=groups, timing_processes=processes,
    pure_reuse_cold_by_turn=cold,
    cold_bucket_scope='Pure reuse means recorded_capture_range_count=0, not arbitrary time trimming. Each paged arm has90/96decode calls per process at0record/7reuse; first two slots at each changed turn remain included in primary full phase/session clocks. Cold includes snapshot/page lists, bindings, typed batch and replay preparation, so no function-level timing share is inferred.',
    memory_observations=memory, current_sampled_peak_delta_bytes=memory_delta,
    memory_limits=[
        'One separately monitored memory process per arm. Its throughput is never mixed into the twelve unmonitored timing samples.',
        'Sampled PSAPI/PDH peaks are lower bounds, not exact allocation peaks. Requested10ms cadence differs from actual intervals; interval/cost distribution, null counts, every phase and bracket ages are retained.',
        'GPU total peak is max of simultaneously available dedicated+shared values, never sum of separate maxima. Process counters do not fully express physical VRAM allocation.',
        'CPU private commit, working set and GPU shared can overlap and must not be summed as disjoint physical memory. Missing ready baseline remains unknown.',
        'Phase brackets are parent-time adjacent samples, not exact allocation endpoints; stderr marker delivery can lag source execution. Short phases can have zero interior samples.',
        'A small difference from one sampled process is an observation, not proof of a patch-specific allocation saving or leak.'],
    actual_correctness_receipts=diagnostics, prefix_runtime_scope=dict(full_prefix_result=identity(S.parent/'main-run4/result.json'),full_prefix_observation=identity(S.parent/'main-run4/observation.json'),pressure_result=identity(S.parent/'pressure-run3/result.json'),pressure_observation=identity(S.parent/'pressure-run3/observation.json'),scope='The performance review verifies identities and terminal exit0 for these actual prefix diagnostics; detailed exact-prefix/branch/pressure vectors remain in the separate source/runtime review.'),
    limits=[
        'This is one synthetic teacher-forced long-context schedule with three fresh processes per timing arm. It is not natural dialogue, free-running quality, MTP, four-active-session throughput or all internal full-state validation.',
        'Current and before differ by six objects together (consumer plus five core host owners), including the same-request finite compile budget and diagnostics. The benchmark cannot assign a share to an individual change. Prefix is off for this single-session comparison; actual prefix hit correctness/zero-Graph evidence is a separate diagnostic journey.',
        'Current/before/dense and llama.cpp use matched BF16 text model/input scope, but not guaranteed identical intermediate arithmetic, graph partitioning or logits/argmax transfer implementation. Existing precision/host-visible-token boundaries remain.',
        'Loading metrics include each implementation model setup/resource preparation and reused OS/filesystem caches; they are not cold disk bandwidth measurements.',
        'Only three fresh timing processes per arm and one monitored memory process per arm. No statistical significance, fixed-clock ceiling or stable cross-window/cross-device speedup is claimed.',
        'No review-triggered model process, device query, sampling, build, link or product edit. All observations came from existing root receipts/raw logs.'])

target=S/'independent-review.json'
target.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(report=identity(target), rates=aggregate_rates,
    pure_reuse_cold_medians_ms={arm:[1000*x['seconds']['median'] for x in turns] for arm,turns in cold.items()},
    memory_peaks_MiB={arm:{key:value/1048576 if value is not None else None for key,value in data['sampled_peaks_bytes'].items()}for arm,data in memory.items()}),indent=2))

