"""Same established finite four-arm procedure, updated exact images only."""
from pathlib import Path
S = Path(__file__).resolve().parent
R = S.parents[1]
original = R / '.scratch/paged-prepare-20261021/performance.py'
source = original.read_text(encoding='utf-8')
assert source.count("current=S / 'qwen-ready.json'") == 1
assert source.count("before=R / '.scratch/paged-recording-20261021/qwen-ready.json'") == 1
source = source.replace("current=S / 'qwen-ready.json'", "current=S / 'ready-attempt3.json'")
source = source.replace("before=R / '.scratch/paged-recording-20261021/qwen-ready.json'", "before=R / '.scratch/paged-prepare-20261021/qwen-ready.json'")
source = source.replace('Compare current generic lookup/page-set changes to exact previous paged ff42 closure, dense Hyle and matched llama.cpp;',
    'Compare current full-state prefix implementation and indexed preparation/shared-footprint changes to paged aa486, dense Hyle and matched llama.cpp; single-session prefix policy is off in both Hyle arms;')
exec(compile(source, str(Path(__file__).resolve()), 'exec'), globals())
