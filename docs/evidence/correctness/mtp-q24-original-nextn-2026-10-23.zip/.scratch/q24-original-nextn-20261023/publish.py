"""Publish completed actual Q24 original NextN checks; never archive weight bodies."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def identity(path):
    path = Path(path)
    with path.open('rb') as stream: digest = hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path), bytes=path.stat().st_size, sha256=digest)
def verify(row):
    actual = identity(R / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']

run = read(S/'checks1/summary.json')
image = read(S/'tests-link3/ready.json')['image']
verify(image)
assert run['image'] == image and run['process']['exit'] == 0 and not run['process']['timed_out']
assert run['tests'] == 8 and not any(run[k] for k in ('failures','errors','disabled','skips'))
new = [case for case in run['cases'] if 'Q24OriginalNextNAndVocabulary' in case['attributes']['name']]
q27 = [case for case in run['cases'] if 'Q27OriginalNextNAndVocabulary' in case['attributes']['name']]
old = [case for case in run['cases'] if 'WholeNextN' in case['attributes']['name']]
assert len(new) == len(q27) == 2 and len(old) == 4
for case in new:
    p = case['properties']
    for key, expected in dict(original_role_count='22', original_role_bytes='17268803584',
        actual_submissions='10', complete_draft_resources='6',
        original_first_full_projection_values='435201', original_first_full_head_values='248320',
        original_prediction_embedding_observations='5', original_native_reference_submissions='0',
        resident_expert_capacity='10', expert_domain='512', resident_slots='2',
        resident_slot_bytes='283117568').items():
        assert p[key] == expected, (case['attributes']['name'],key,p.get(key),expected)
for case in q27:
    assert case['properties']['original_role_count'] == '17'
    assert case['properties']['actual_submissions'] == '5'
    assert case['properties']['original_first_full_projection_values'] == '312832'
graphs = sum(int(case['properties']['actual_submissions']) for case in run['cases'])
assert graphs == 50
native_refs = sum(int(case['properties'].get('original_native_reference_submissions','0')) for case in run['cases'])
assert native_refs == 225
freeze_path = S/'source-final/freeze.json'
freeze = read(freeze_path)
for row in freeze['source']: verify(row)
link_path = S/'tests-link3/link-plan.json'
link = read(link_path)
for row in link['inputs']: verify(row)
for row in link['compiled_records']:
    verify(row)
    if Path(row['path']).is_relative_to(S):
        compiled = read(row['path'])
        for item in (compiled['source'],compiled['object'],*compiled['dependencies']): verify(item)
acquisition_path = S/'original-q24-nextn/acquisition.json'
acquisition = read(acquisition_path)
assert acquisition['complete'] and acquisition['original_roles'] == 19
assert acquisition['role_payload_bytes'] == acquisition['successful_request_body_bytes'] == 17257268224
for role in acquisition['roles']:
    assert role['complete'] and (R/role['payload']['path']).stat().st_size == role['bytes']
    assert len(role['payload']['sha256']) == 64
# The actual native Data::load authenticated all bodies against compiled pins.
# Do not add another17GB hash pass solely to publish this receipt.
before = read(S/'before.json')
verify(before['protected_qwen_image']['image'])
work = R/'docs/developer/current-work.md'
text = work.read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash == before['protected_performance_tail_sha256']
sources = [R/row['path'] for row in freeze['source']]
docs = [work,R/'docs/implementation/model-operators.md']
metadata = [R/'.scratch/qwen24-original-mtp-20261022/original-q24'/name for name in
    ('acquisition.json','first-header.json','last-header.json')]
files = set(sources+docs+metadata)
files.update(p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in
    ('.h','.cc','.py','.mjs','.json','.txt','.log','.xml','.ps1','.diff'))
files.update(S/'header2'/name for name in ('format.bin','header-prefix.bin'))
files.discard(S/'publication.json')
archive = D/'mtp-q24-original-nextn-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
    for path in sorted(files):
        assert path.suffix.lower() not in ('.q4_k','.q5_k','.q6_k','.q8_0','.f32')
        assert path.stat().st_size < 10_000_000, path
        zipped.write(path,path.relative_to(R).as_posix())
record = dict(date='2026-10-23', stage='BR', goal_complete=False,
    conclusion='All20 embedded MAIN Q24 NextN roles and two independent original full-vocabulary banks feed the ordinary complete-state CPU/CUDA journey, retaining real512-domain Top10 and bounded original compressed expert supply.',
    artifact=dict(repository=acquisition['repository'], revision=acquisition['revision'], variant='UD-IQ4_XS',
        original_roles=22, original_role_bytes=17268803584, new_roles=19, new_payload_bytes=17257268224,
        reused_roles=3, reused_bytes=11535360, acquisition=acquisition, weight_bodies_archived=False),
    implementation=dict(
        math='Original F32 full512 router -> softmax -> stableTop10 -> selectedsum clamped2^-14 -> normalize; missing rawscale override means effective1. Q4_K gate/up -> SwiGLU -> Q4_K down -> routerweight -> selectedsum. Independent Q5_K sharedgate/up and Q6_K down multiply original F32 shared-router sigmoid before merge. GGUF F32 storage boundaries, no invented BF16 rounding or extra gamma+1.',
        vocabulary='Two independent original Q4_K full248320 banks prepared once, no generated placeholder vocabulary. Complete original head remains one full-bank MatMul. Actual greedy pending lease feeds original embedding with complete six-resource state.',
        supply='Three complete512-expert compressed source files remain readonly mapped. Actual selectedIDs alone drive a sortedunique E10 union and I32[512]map; unused globalIDs=-1. Three E10 Q4_K banks andmap share one real generation. No modulo8, full512 device bank or F32 weight shadow.',
        capacity=dict(bank_bytes=94371840, map_bytes=2048, slot_bytes=283117568, slots=2,
            each_cpu_or_device_or_pinned_two_slot_capacity=566235136,
            note='Declared encoded supply capacity/API upload accounting, not measured physical memory/VRAM peak or bus traffic.'),
        execution='One semantic Fragment cold-split at actual router frontier into two ordinary Graph/Invocation phases. Same actual resource/owner, direct predecessor leases; both phases finish/reset before one complete StateHead publication. No new public operator/API or executor.',
        reference='Original-byte Q4/Q5 two-component minimum arithmetic; actual F32 activation through fixed CPU AQ8_K or CUDA M1 MMVQ AQ8_1. This grouped shape has one token and ten selected slots, not ten-token MMQ. First episode all selected projections/fullhead; later fixed7 perprojection and actualTop4. Independent router/reduction/nonlinear local checks begin at actual predecessors.',
        maintenance='Q27 text frequencies now use a common pure formula with each pinned model theta, removing the cross-model call into Q24. Existing six cases retain their entry behavior.'),
    validation=dict(tests=8, failures=0, errors=0, skips=0, graph_submissions=graphs,
        new_graph_submissions=20, related_graph_submissions=30, new_cases=new,
        related_q27_original=q27, related_generated_parameter_cases=old,
        new_first_full_projection_values=870402, new_first_full_head_values=496640,
        new_native_reference_submissions=0, unchanged_related_native_reference_submissions=native_refs,
        results=identity(S/'checks1/summary.json'), source_freeze=identity(freeze_path), linked_inputs=identity(link_path),
        host_translation_units=1, host_compile_attempts=len(list(S.glob('compile*/*/plan.json'))),
        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0),
    scope_review=dict(
        confirmed_artifact_inventory=read(S/'review/mtp-confirmed-remaining.json'),
        next_target_integration=read(S/'review/next-target-integration.json'),
        pro_geometry=read(S/'review/pro-geometry-next.json'),
        source_only_note='The inventory and target/Pro reviews identify concrete next work; native BR checks validate only the listed original Q24 and related Qwen cases, not Pro or an original GLM target.'),
    limitations=[
        'Finite Windows CPU/CUDA M1/cap6/Top10 integration; not every expert evaluated or all shapes/systems/codecs.',
        'Initial target hidden/KV history and acceptance lengths remain explicit external fixtures; no full92-layer target or natural speculative acceptance.',
        'Local packed-codec/math checks and feedback do not establish complete-task quality or official BF16 equivalence.',
        'CUDA strict/fast division interval is conditioned on recorded source/math premises, not a universal every-input theorem.',
        'Other real target/tap/verifier adapters, applicable Pro geometry and confirmed quantization combinations remain unfinished.',
        'No new TPS/loading or physical memory/VRAM peak; protected AV benchmark and Qwen executable remain unchanged.',
        'MTP, image projection and the broader goal remain incomplete.'],
    remaining='Real target producer/taps/verifier and complete state adapters, Pro actual geometry, confirmed applicable quantization, final necessary regressions and ordinary/MTP performance before images.',
    final_image=image, sources=[identity(p) for p in sources+docs], source_metadata=[identity(p) for p in metadata],
    performance_tail_sha256=tail_hash, archive=identity(archive), archive_items=len(files))
destination = D/'mtp-q24-original-nextn-2026-10-23.json'
assert not destination.exists()
destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
publication = dict(evidence=identity(destination),archive=identity(archive))
(S/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(**publication,tests=8,graphs=graphs)))
