import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import {gguf, GGMLQuantizationType} from '../hf-gguf-tools/node_modules/@huggingface/gguf/dist/index.mjs';

const folder = '.scratch/q24-original-nextn-20261023/header2';
const source = JSON.parse(await fs.readFile(`${folder}/acquisition.json`, 'utf8'));
const raw = await fs.readFile(`${folder}/header-prefix.bin`);
const expected = source['header-prefix.bin'];
if (raw.length !== expected.bytes || crypto.createHash('sha256').update(raw).digest('hex') !== expected.sha256) throw new Error('Prefix identity differs');
const parsed = await gguf(source.url, {fetch: async (_url, options = {}) => {
  const range = new Headers(options.headers).get('range');
  const match = /^bytes=(\d+)-(\d+)$/.exec(range || '');
  if (!match) throw new Error(`Unbounded parser request: ${range}`);
  const first = Number(match[1]), last = Number(match[2]);
  if (first > last || first >= raw.length) throw new Error(`Parser exceeds authenticated prefix: ${range}`);
  // The cached parser asks for 2MB chunks. Supply only acquired bytes, then
  // require its complete sequential header to end inside that real prefix.
  const end = Math.min(last, raw.length - 1);
  return new Response(raw.subarray(first, end + 1), {status: 206, headers: {
    'content-range': `bytes ${first}-${end}/${source.file_bytes}`, 'content-length': String(end-first+1)
  }});
}});
if (BigInt(parsed.tensorDataOffset) > BigInt(raw.length)) throw new Error('Header exceeds prefix');
const tensors = parsed.tensorInfos.map(t => ({name:t.name, shape:t.shape, dtype:GGMLQuantizationType[t.dtype], dtype_code:t.dtype, offset:t.offset}));
const value = {repository:source.repository, revision:source.revision, file:source.file,
  tensor_count:tensors.length, tensor_data_offset:parsed.tensorDataOffset,
  metadata:Object.fromEntries(Object.entries(parsed.metadata).filter(([key]) => !key.startsWith('tokenizer.'))), tensors,
  parser:'Existing cached @huggingface/gguf, authenticated local prefix only; no parser network'};
await fs.writeFile(`${folder}/header.json`, JSON.stringify(value, (_key,v) => typeof v === 'bigint' ? String(v) : v, 2) + '\n');
console.log('TENSORS', tensors.length, 'DATA_OFFSET', String(parsed.tensorDataOffset));
console.log(tensors.filter(t => ['token_embd.weight', 'output.weight'].includes(t.name)));
