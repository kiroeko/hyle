"""Fill compile pins only from the completed, authenticated original acquisition."""
from pathlib import Path
import hashlib
import json
import re

S = Path(__file__).resolve().parent
R = S.parents[1]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p): return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
receipt_path = S / 'original-q24-nextn/acquisition.json'
record = read(receipt_path)
plan_path = S / 'roles-plan.json'
assert record['source_plan_sha256'] == identity(plan_path)['sha256']
assert record['complete'] and record['original_roles'] == 19 and len(record['roles']) == 19
assert record['role_payload_bytes'] == record['successful_request_body_bytes'] == 17257268224
source_path = R / 'tests/compute_models/qwen24_original_nextn_roles.h'
before = identity(source_path)
text = source_path.read_text(encoding='utf-8')
for row in record['roles']:
    assert row['complete'] and row['payload']['bytes'] == row['bytes']
    path = R / row['payload']['path']
    assert path.stat().st_size == row['bytes']
    digest = row['payload']['sha256']
    assert re.fullmatch('[0-9a-f]{64}', digest)
    prefix = f'Spec{{"{row["name"]}", "{row["file"]}", '
    pattern = re.escape(prefix) + r'"([0-9a-f]*)"'
    found = re.findall(pattern,text)
    assert len(found) == 1 and found[0] in ('',digest), (row['name'],found)
    text,count = re.subn(pattern, lambda _match: prefix + '"' + digest + '"', text)
    assert count == 1
assert 'role is not pinned' in text
source_path.write_text(text,encoding='utf-8')
result = dict(scope='Pins are completed root exact-range role hashes, not generated or metadata hashes.',
    acquisition=identity(receipt_path), plan=identity(plan_path), before=before, after=identity(source_path), pinned_roles=19)
(S/'pins.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('PINNED',result['after'])
