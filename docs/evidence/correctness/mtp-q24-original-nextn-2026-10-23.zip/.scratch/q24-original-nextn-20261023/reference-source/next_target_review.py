from pathlib import Path
import json,hashlib
base=Path('.scratch/q24-original-nextn-20261023/review')
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
f=Path('.scratch/official-weight-audit.json').open('rb');f.seek(284040911);s=f.read();d,e=json.JSONDecoder().raw_decode(s[s.index(b'{'):].decode('utf-8'))
summary={}
for layer in [43,44]:
 ts=[t for t in d['tensors'] if '.layers.'+str(layer)+'.' in t['name']]
 ex=[t for t in ts if '.mlp.experts.' in t['name']]
 other=[t for t in ts if '.mlp.experts.' not in t['name']]
 summary[str(layer)]={'physical_roles':len(ts),'source_bytes':sum(t['data_offsets'][1]-t['data_offsets'][0] for t in ts),'expert_physical_roles':len(ex),'expert_bytes':sum(t['data_offsets'][1]-t['data_offsets'][0] for t in ex),'nonexpert_physical_roles':len(other),'nonexpert_bytes':sum(t['data_offsets'][1]-t['data_offsets'][0] for t in other),'shards':sorted({t['shard'] for t in ts})}
print(summary)
report={
 'scope':'Read-only actionable delta after BQ target-taps-verifier review. No source edits/native/build/download/newengine. Known GLM cachedrecordoffset284040911 was decoded as26,159,849B only; the310MB fullaudit was not parsed. Metadata is not authenticated downloaded targetpayload.',
 'basis':ident('.scratch/mtp-next-original-20261023/review/target-taps-verifier.json'),
 'decision':'The existing34-resource43->44->NextN journey is reusable, but the current generated target is primaryGGUF/F32 while completed originalNextN is officialHF/BF16/E4. A truthful originaltail needs distinct43/44parameter roles, actualsource store boundaries and actualtargetTop1 policy; it does not require layers0..42 or a new executor. Externalperposition layer42output remains a legal modelconsumer boundary.',
 'must_replace':[
  {'where':'glm_mtp_state_consumer_test.cc::run_target43','change':'Build first/partial/full/skip/catchup with the existing complete original45supplier; current build(true,2054...) calls omit it. Replace target_residual_values(token) with an explicitly identified currenttoken upstream[1,4,4096]lease, not prior temporalmHC orrecreated observed values.'},
  {'where':'glm_mtp_target43_component.h::prepare/finish','change':'Replace generatedQ8HC projections313/337, fabricatedscale/base andnormalized-before-mix surrogate with actualtwoHCparameter triples andsourceBF16stores/outnorm. Replace primarygeneratedMoE with thislayer43 original288router/bias/shared/selectedE4expert path.'},
  {'where':'glm_mtp_state_consumer_test.cc::build_target43/append_sparse_attention','change':'Replace offset1021 generated q_a/q_b/kv_a/absorbedK/value/O,7indexer parameters andnorms with layer43-owned supplier. Existing r.original branch explicitly rejects role_offset!=0 and expects NextNprefix qr; use one plain model-local attention/indexer parameter view for original43 and original45, leaving EH outside43. Do not rename45roles as43.'},
  {'where':'glm_mtp_target_component.h::build and d5_kda_full_fragments.h::complete','change':'Replace all generated44KDAprojection/conv/A/dt/oNorm,HC/scales/norms andMoE roles. CurrentGGUF path retainsF32whole-chain surrogate, so realBF16projection/convolution/stores must become explicit while recurrentmatrix staysF32. Lastlayer must contract currentfourstreams then originaltargetmodel.norm, distinctfrom45shared_head.norm.'},
  {'where':'glm_mtp_state_consumer_test.cc::run_target43 policy/accepted_rows','change':'Current2/4proposalIDs, explicittoken3 correction and callerloop accepted_rows do not compute verification. Apply existinguntiedBF16fullVhead to the actualtargetnormalizedtap, stableTop1, compare actualdraftIDs for contiguousacceptedprefix, andbind actualcorrection/bonusI32lease before one StateHead publication. Logits need not become persistentstate.'}
 ],
 'concrete_original_inventory':summary,
 'minimum_parameter_geometry':{
  'both_layers_HC':'RawBF16 hc_attn_fn/hc_ffn_fn[24,16384], originalsource loadsF32parameter: exactcoldwiden once; F32bases[24],F32scales[3] perbranch. BF16input/postnorm[4096],eps1e-5; HC4/Sinkhorn20/eps1e-6/postmult2. Do not mistake rawBF16HCstorage for generatedQ8orstoredF32.',
  'layer43_MLA':'q_a E4[1536,4096]+F32SF[12,32],qaNormBF16[1536];q_b E4[16384,1536]+SF[128,12];kv_a E4[512,4096]+SF[4,32],kvNormBF16[512];kv_bBF16[32768,512];O E4[4096,16384]+SF[32,128]. Same64heads/NoPE256/latent512/value256/scale1/16 asexistingoriginal45attention; coldK/Vsplit mechanism reusable, weights distinct.',
  'layer43_indexer':'SevenBF16stored roles: APE[4,128],compressgate[128,4096],kNormweight/bias[128],weightsProj[32,4096],wk[128,4096],wq_b[4096,1536]. Existing exactloadwiden/cachecodec/13resources reusable with43identity, index32heads/D128/Top2048/K4 independentfromMLAgeometry.',
  'layer44_KDA':'NineBF16dense roles q/k/v[8192,4096],f_a/g_a[128,4096],f_b/g_b[8192,128],b[64,4096],o[4096,8192];3BF16conv[8192,1,4];F32A_log[64],F32dt_bias[8192],BF16oNorm[128]. The originalcheckpoint has separateQ/K/V+convroles; sourceMergedQKV is a loaderform, not a missingtensor toinvent.',
  'each_layer_MoE':'BF16router[288,4096]+F32bias[288];288experts eachgate/up E4[2048,4096]+F32SF[16,32],downE4[4096,2048]+SF[32,16];sharedsame3pairs. ExistingE8ordinarycut/WeightSlots and original45 localreference reuse applicableperdistinctlayer. Wholebank sourceexpertbytes7,249,526,784 perlayer; onlyactual8readyexperts3banks201,375,744B are needed simultaneously.',
  'verifier':'One additional original model.language_model.norm.weight BF16[4096] (8192B), metadata shard62; existingoriginalNextNsharednorm is another role. Reuse alreadyauthenticated fullV154880BF16head[154880,4096], no secondhead upload. Targetcontract[1,4096]->targetnormBF16[1,4096]->BFloatLinearF32logits[1,154880]->actualTop1I32[1].'
 },
 'legal_external_boundaries':[
 'Per-token actuallayer42fourstreamBF16[1,4,4096] with modelrevision/session/branch/position/tokenalignment can be supplied by anotherengine orupstreamGraph. Lower0..42implementation is not needed to testoriginal43/44tail. Syntheticvectors are legal numericalcomponentinputs but remain labelledsynthetic; they do not establish trainedtargetpromptquality.',
 'Initial43sparse13leases and44convhistory[3,24576]/F32KDAmatrix[1,64,128,128], normalizedprevioustargettap andfrontier may be imported as a self-consistentexplicitprefix orzerostart. Finitefixtureprefix2053 may remain numericalboundary, never claimedoriginalprompt-prefill.',
 'Real externalfinaltargethidden can go directly through originaltargetnorm/fullhead andexistinghidden_input seam if an upstreamproducer owns43/44state. The library must not fabricate unseenupstreamstate; present34-resource test is for theinlibrary43/44composition, soexternalwhole-target mode hasitsown explicitstateboundary.'
 ],
 'reuse_and_alignment':'Keep one StateStore/Head: NextN17 + target43sparse13 + target44history/matrix/tap/cursor4. Target43outputmhc feeds44directlease; target44tap feeds freshNextNseed at the existing correctprevious-target/currentpending offset; same-epochskip retainsdraftactualhidden. Actualtargetverification advances this-token43/44state whilecomparing nexttokenIDs. Publish allacceptedtarget+draftresources atomically; rejectedtail/oldhead/epoch/catchup rules alreadyexist.',
 'smallest_next_action':'First add the actualtarget-head/tap adapter (targetnorm8192B plus existingsharedhead), removing constanttoken3 as the onlyverifier. It can consume an explicitactualnormalizedtargetlease withoutbuilding45layers. Iforiginal34resource tail is desired next, acquirelayer44static/selectedexperts+targetnorm andaccept actual43output as boundary, thenaddoriginal43; retain truthfulpartial-target labeling. A reusable all288domain tail needsdistinctoriginalexpert sourcebanks; finiteroute acquisition mayfetchonlyactuallyselectedtrueexperts onceknown, withno substitute/fallbackweights.',
 'metadata':ident(base/'glm-target43-44-cached-roles.json'),
 'limits':'No payload pins/absoluteRangeheaderbase fabricated. Cachedrawmetadata only gives shard+datarelativeoffset; rootmustauthenticate actualtargetheaders/receipt before acquisition. No claimthatoriginal45state test alreadyexecutesoriginal43/44 or derivesnaturalacceptance. No newpubliccompute primitive was shownnecessary.'}
p=base/'next-target-integration.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(ident(p))
