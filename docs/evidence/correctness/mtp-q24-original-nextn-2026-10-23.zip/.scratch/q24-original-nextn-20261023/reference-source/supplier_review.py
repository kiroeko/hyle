from pathlib import Path
import hashlib,json
base=Path('.scratch/q24-original-nextn-20261023/review')
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
r={'scope':'Narrow independent source-only supplier/residency body review whileroot stillacquirespayloads. No native/build/download orpayloadSHAvalidation. Emptyproductionpins rejectloading; they are pendingacquisition, notpassedchecks.',
 'sources':[ident('tests/compute_models/qwen24_original_nextn_roles.h'),ident('tests/compute_models/qwen24_original_resident_weights.h')],
 'geometry_basis':ident('.scratch/q24-original-nextn-20261023/roles-plan.json'),'confirmed_body_blockers':[],
 'checks':{'source_storage':'19newroles contain16staticnativebanks2761753600B plus3complete512Q4sourceexpertbanks onlymapped. OldK/V/knorm11,535,360B reused. Dataownsmappingsstrongly; role/spansrefclosures preserveData. SmallF32normarrays only; noF32expertshadow. Packedembeddingtransposesdescriptiononly; separateoriginalhead singlefullbank.',
 'selection':'TrueactualglobalIDs0..511 sortedunique forresidentunion<=10, map512initial-1. Expertbyte/view offsetglobal*9437184 checkedbounded. Allthreelegslocalrow useexactsameoriginalglobalID. Unusedcapacitycopiesvalidsource rows butgetsnomapentry; noarbitrarymodulo/prototype.',
 'cpu':'Twoactualreadygenerations566235136B with8blocks. Each3bank94371840B+map2048 fullyinitialized beforepublish. Partialuploadfailure releaseswriters; returnedbatchowner/readonlyleases preserveactualresource. Onlycompletebatch boundbyconsumer.',
 'cuda':'SameactualtypeddeviceResource passedwithStorageOwner ref equality anddevicekindguard. 31slices=3*10originalcompressedexperts+I32map, logical283117568B peroneoftwoslots. RawU8physicalsource descriptors preserveoriginalQ4canonicaldestination. upload_slices synchronousstaging stopsborrowingmmap/map onreturn; WeightBatchretainsrealpendingupload. StateheapstabilizeshostResource identity; customdestructor closesdrains beforefieldsdestroy; device_owner outliveshost/slots.',
 'consumer_seam':'Existingtwoordinaryphases onlybind3expertbanks+map afteractualrouter. OnlyIDs crosshost; activation/state directleases. Invocationwait/reset beforeargument/batchrelease andslotreuse; outerStatepublicationafterfullsuccess. ActualuploadAPIcounter notclaimVRAMpeak orbusbandwidth.'},
 'pending':'Rootmustfillall19pinsfromactualcompletedreceipt andexecuteauthentication/native tests. Finalpins may changeheaderhash; reviewcoversgeometry/layout/ownershipbody andmustbere-stampedagainstfinalpinsonly withoutrepeatingmathaudit.'}
p=base/'q24-supplier-independent.json';p.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(ident(p))
