from pathlib import Path
import hashlib,json,shutil
base=Path('.scratch/q24-original-nextn-20261023/reference-source')
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files=[Path('tests/compute_models/qwen24_original_nextn_reference.h'),Path('tests/compute_models/qwen27_original_nextn_reference.h'),Path('tests/compute_models/dspark_original_shared_reference.h')]
for p in files:
 q=base/'frozen'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
report={'scope':'Source-only BR independent actual original Q24 numeric reference. No native/build/download. OnlynewQ24headeredited; BQdependenciesunchanged.','source':ident(files[0]),'dependencies':[ident(p) for p in files[1:]],'snapshots':[ident(base/'frozen'/p) for p in files],'math_review':ident(base.parent/'review/q24-reference-source-math.json'),'source_status':'Frozen; root owns actual compilation/numeric/state checks. No source changes while native work proceeds.'}
p=base/'freeze.json';p.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(ident(p));print(ident(files[0]))
