"""Snapshot final authenticated Q24 sources and unchanged shared math inputs."""
from pathlib import Path
import hashlib
import json

S=Path(__file__).resolve().parent
R=S.parents[1]
assert json.loads((S/'original-q24-nextn/acquisition.json').read_text(encoding='utf-8'))['complete']
pins=json.loads((S/'pins.json').read_text(encoding='utf-8'))
def identity(p):
    return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
folder=S/'source-final'
folder.mkdir(exist_ok=False)
rows=[]
names=('qwen_mtp_state_consumer.h','qwen_mtp_state_consumer_test.cc',
    'qwen24_original_moe_fragment.h','qwen24_original_nextn_roles.h',
    'qwen24_original_resident_weights.h','qwen24_original_nextn_reference.h',
    'model_resident_fragment.h','qwen27_original_nextn_roles.h',
    'qwen27_original_nextn_reference.h','dspark_original_shared_reference.h',
    'original_role_input.h','qwen_original_mtp_roles.h')
for name in names:
    path=R/'tests/compute_models'/name
    row=identity(path)
    target=folder/'frozen'/row['path']
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(path.read_bytes())
    row['snapshot']=target.relative_to(R).as_posix()
    rows.append(row)
assert next(row for row in rows if row['path']==pins['after']['path'])['sha256']==pins['after']['sha256']
record=dict(scope='Final BR source snapshot after actual19 original role pins. No claim of native execution from this snapshot.',source=rows,pins=pins)
(folder/'freeze.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('FROZEN',len(rows),'sources')
