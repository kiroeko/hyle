"""Acquire only the pinned Q24 part2 format and bounded header prefix."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import struct
import urllib.request

S = Path(__file__).resolve().parent
plan = json.loads((S / 'roles-plan.json').read_text(encoding='utf-8-sig'))
source = plan['sources']['2']
folder = S / 'header2'
folder.mkdir(exist_ok=True)
receipt = folder / 'acquisition.json'
if receipt.exists():
    record = json.loads(receipt.read_text(encoding='utf-8'))
    assert record['repository'] == plan['repository']
    assert record['revision'] == plan['revision'] and record['file'] == source['file']
else:
    record = dict(repository=plan['repository'], revision=plan['revision'],
                  file=source['file'], url=source['url'], requests=[],
                  whole_weight_file_download_allowed=False)

def save():
    temporary = receipt.with_suffix('.json.next')
    temporary.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    os.replace(temporary, receipt)

def fetch(name, count):
    path = folder / name
    if name in record:
        data = path.read_bytes()
        assert len(data) == record[name]['bytes'] == count
        assert hashlib.sha256(data).hexdigest() == record[name]['sha256']
        return data
    assert not path.exists(), 'Unrecorded prefix must be inspected before replacement'
    item = dict(first=0, last=count-1, bytes=count, complete=False)
    record['requests'].append(item)
    save()
    headers = {'Range': f'bytes=0-{count-1}', 'Accept-Encoding': 'identity',
               'User-Agent': 'hyle-original-nextn-header/1'}
    if 'etag' in record:
        headers['If-Range'] = record['etag']
    request = urllib.request.Request(record['url'], headers=headers)
    with urllib.request.urlopen(request, timeout=45) as response:
        value = response.headers.get('Content-Range', '')
        match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', value)
        assert response.status == 206 and match and (int(match[1]), int(match[2])) == (0, count-1), (response.status, value)
        total, etag = int(match[3]), response.headers.get('ETag')
        assert etag and count < total, 'Never acquire a whole weight shard'
        if 'file_bytes' in record:
            assert (total, etag) == (record['file_bytes'], record['etag'])
        assert response.headers.get('Content-Length') in (None, str(count))
        assert response.headers.get('Content-Encoding') in (None, 'identity')
        record.update(file_bytes=total, etag=etag)
        data = response.read(count)
        assert len(data) == count and not response.read(1), 'Exact range body required'
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    identity = dict(path=path.relative_to(S.parents[1]).as_posix(), bytes=count,
                    sha256=hashlib.sha256(data).hexdigest())
    record[name] = identity
    item.update(complete=True, http_status=206, content_range=value, etag=etag,
                sha256=identity['sha256'])
    save()
    print('VERIFIED', name, count, total, etag, flush=True)
    return data

save()
magic, version, tensors, metadata = struct.unpack('<4sIQQ', fetch('format.bin', 24))
assert magic == b'GGUF' and version == 3 and tensors > 0
record.update(format_version=version, tensor_count=tensors, metadata_count=metadata)
save()
fetch('header-prefix.bin', 65536)
record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
