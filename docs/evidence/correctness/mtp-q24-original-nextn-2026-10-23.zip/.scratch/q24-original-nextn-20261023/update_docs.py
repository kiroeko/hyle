"""Reconcile current facts after actual eight-case original Q24 run."""
from pathlib import Path
import hashlib
import json

S=Path(__file__).resolve().parent
R=S.parents[1]
run=json.loads((S/'checks1/summary.json').read_text(encoding='utf-8'))
assert run['tests']==8 and not any(run[k] for k in ('failures','errors','disabled','skips'))
work=R/'docs/developer/current-work.md'
text=work.read_text(encoding='utf-8')
tail=text[text.index('## 最新完整性能对比'):]
before=json.loads((S/'before.json').read_text(encoding='utf-8'))
assert hashlib.sha256(tail.encode()).hexdigest()==before['protected_performance_tail_sha256']
old='Q27主UD-Q4_K_M的全部15份NextN原角色与独立原embedding／head已接，Q24原K／V／K norm也在完整NextN中。Q24其余原角色、真实target taps、Pro实际几何及已确认量化供给继续按精确制品身份接入'
new='Q27主UD-Q4_K_M全部15份NextN＋两份词表、Q24主UD-IQ4_XS全部20份NextN＋两份独立词表已接；Q24保持真实512域Top10及有界原Q4_K供给。真实target taps／verifier、Pro实际几何及其它已确认量化仍按精确身份接入'
assert text.count(old)==1
text=text.replace(old,new)
start=text.index('Q27主UD-Q4_K_M完整原NextN与共享全词表、GLM Flash完整原NextN与共享全词表')
end=text.index('前批[GLM原MoE／FFN]',start)
replacement='''Q27主UD-Q4_K_M、Q24主UD-IQ4_XS、GLM Flash的完整原NextN与共享全词表，以及DSpark全部81份sidecar原角色已有列明检查。下一步接真实target taps／verifier，适配Pro实际几何与其它已确认适用量化；最后做必要回归及普通／MTP完整性能对照，再进入图片。状态、页权限、只读租约和原子发布继续复用，不另造多套引擎，范围见[总表](../implementation/model-operators.md)。

**最近已验证进展：** [Q24完整原NextN／词表](../evidence/correctness/mtp-q24-original-nextn-2026-10-23.json)补齐主UD-IQ4_XS全部20份blk92参数及两份独立Q4_K词表，共22份、17,268,803,584B。真实512域Top10按实际ID供给三份E10压缩专家bank＋map，每槽283,117,568B；两个槽的声明容量不是物理显存峰。原Q／K／V／O、router、shared FFN及全部norm均进入普通Graph，没有生成词表或整份F32专家副本。

CPU／CUDA各5个逻辑NextN步骤、10次实际Graph，保六项完整状态、接受0／1／2、旧结果和实际ID反馈。首轮每端独立核435,201个投影值（含全V248320分数）；后续固定行／实际Top4并继续核全部实际logits的greedy。原Q4_K／Q5_K按CPU AQ8_K及CUDA单token MMVQ AQ8_1的真实minimum算术核对，Q6_K／Q8_0复用既有参考；新用例没有额外native参考提交。相关Q27／Q24共8项、50次Graph，0失败／0跳过。初始target hidden／历史及接受长度仍为明确外部夹具；没有自然接受率、任务质量、TPS或物理内存峰结论，页末AV表不变。

本轮亦把已锁MTP身份、真实target接缝及Pro几何整理进同份证据：既有原全词表head可消费明确的最终归一化tap；GLM原43／44层仍需各自参数和BF16边界。Pro的CKV512＋RoPE64须作为完整576维状态发布，已有typed MLA承载576／512，不能直接沿Flash缓存接线。源码核对不是Pro运行结果，也不把33条发现记录全部新增为任务。

前批[Q27完整原NextN／词表](../evidence/correctness/mtp-q27-original-nextn-2026-10-23.json)的原17角色、首次全量packed参考与完整六状态检查保留；其真实target主干和其它制品仍按上表推进。

'''
text=text[:start]+replacement+text[end:]
start=text.index('- **Q24**:') if '- **Q24**:' in text else text.index('- **Q24**：')
end=text.index('\n- **GLM-Flash**',start)
text=text[:start]+'''- **Q24**：[主UD-IQ4_XS原22角色](../evidence/correctness/mtp-q24-original-nextn-2026-10-23.json)覆盖完整NextN与两份独立全V248320词表；原512域Top10及真实Q4_K专家供给CPU／CUDA通过。两阶段普通Graph成功后，完整KV、normalized hidden、pending、cursor／position六资源按接受0／1／2同Head发布并续算。初始target／历史、其它量化和自然接受率仍未核；旧C5两profile依据保留。'''+text[end:]
old='当前优先；Q27原17角色／全词表与完整草拟六资源、GLM编码状态、Q24部分原角色／完整草拟六资源、DSpark真实全词表＋编码main历史／完整draft已有CPU／CUDA检查。CUDA大head已改为单次；GLM完整原NextN＋共享词表1762角色与DSpark83角色已接，下一步Q24原512域供给／真实target taps／Pro几何与已确认量化组合，最后完整性能对照'
new='当前优先；Q27原17、Q24原22、GLM Flash原1762、DSpark原83角色的列明完整draft／状态已有CPU／CUDA检查。下一步真实target taps／verifier、Pro几何及其它已确认量化组合，最后完整性能对照；原角色数不是整模型MTP完成比例'
assert text.count(old)==1
text=text.replace(old,new)
assert text[text.index('## 最新完整性能对比'):]==tail
work.write_text(text,encoding='utf-8',newline='\n')

path=R/'docs/implementation/model-operators.md'
text=path.read_text(encoding='utf-8')
start=text.index('Q24已运行范围仍是[')
end=text.index('\n\n',start)
text=text[:start]+'''[Q24完整原NextN与独立词表](../evidence/correctness/mtp-q24-original-nextn-2026-10-23.json)已接全部20份blk92原参数及原embedding／head，共22份、17,268,803,584B。原K／V／K norm三份复用，其余19份只按实际第2／29分片header范围获取，未下载完整模型。两份词表虽同Q4_K也保持独立字节与owner；原Q5_K attention、Q8_0 EH、Q4_K专家、Q5_K shared gate／up、Q6_K shared down和F32 norms均保原合同，不额外加gamma1。

完整512域softmax Top10沿实际ID供给E10原压缩bank与I32 map，每槽283,117,568B，双槽；只有10个调度ID读回host，激活和状态保实际producer租约。一次冷图切分生成两份普通Graph，成功后六项状态原子发布。CPU／CUDA新用例各10次Graph，首轮各核435,201个投影值（含全V248320 head）；Q4／Q5参考区分实际M1 MMVQ与未用MMQ的minimum算术，不增加native参考提交。相关8项50次Graph无失败／跳过，实际反馈均为3,321,3,321,328；这是夹具输入的数值／状态结果，不是自然文本质量。声明槽容量不是物理峰；真实target／初始历史、其它量化、自然接受率及TPS未据此完成。旧C5两profile及[单次完整head](../evidence/correctness/mtp-full-packed-head-2026-10-23.json)依据保留。'''+text[end:]
old='Q27 primary完整原NextN／词表17角色、Q24部分原角色的完整NextN六资源与实际ID／hidden反馈、接受0／1／2及各Head续算已CPU／CUDA核'
new='Q27 primary原17角色、Q24 primary原22角色的完整NextN／词表、六资源与实际ID／hidden反馈、接受0／1／2及各Head续算已CPU／CUDA核'
assert text.count(old)==1
text=text.replace(old,new)
path.write_text(text,encoding='utf-8',newline='\n')

path=S/'review/mtp-confirmed-remaining.json'
record=json.loads(path.read_text(encoding='utf-8'))
counts=record['counting']
counts['baseline_original_nextn_payload_complete_finite_runs']=4
counts['baseline_original_nextn_payload_in_progress_BR']=0
counts['note']='Twenty locked identity rows (15baseline,3explicit optional sidecars,2header-confirmed derivatives). After BR,5 have listed complete original NextN payload finite evidence (4baseline+1sidecar);15 remain payload-supply boundaries. These are not engine counts or MTP completion percentages. Two partial rows remain evidence questions.'
for row in record['confirmed_identity_rows']:
    if row['model']=='qwen38_24t' and row['profile']=='primary_gguf':
        row.update(presence='CONFIRMED_ORIGINAL_PAYLOAD',
            original_payload='ALL20_BLK92_PLUS2_UNTIED_VOCAB_BOUND_AND_CPU_CUDA_FINITE_STATE_RUN',
            next='No remaining primary NextN payload roles; real target taps/history/verifier remain external, and other artifacts retain distinct identity/codec obligations.')
record['post_BR_update']=dict(evidence='docs/evidence/correctness/mtp-q24-original-nextn-2026-10-23.json',
    tests=8,graphs=50,failures=0,skips=0,note='Updated only after actual completed checks1; original source identities above name the earlier inspection snapshot.')
record['next_finite_actions'][0]='BR primary Q24 original22-role journey is now CPU/CUDA verified; do not re-fill those same roles.'
path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('UPDATED current work/model map/finite remaining identities; AV tail unchanged')
