"""Specialize the exact BQ cached host/link/run closure for the Q24 consumer TU."""
from pathlib import Path
import ast

S = Path(__file__).resolve().parent
R = S.parents[1]
text = (R / '.scratch/mtp-next-original-20261023/build.py').read_text(encoding='utf-8')
replacements = [
    ('Incremental original Q27 NextN/shared-vocabulary and related quantization-reference consumers.',
     'Incremental original Q24 NextN/full512 Top10 consumer and related Qwen state regressions.'),
    ("BH = R / '.scratch/glm-original-moe-20261023'", "BH = R / '.scratch/mtp-next-original-20261023'"),
    ("'qwen-state': R / '.scratch/qwen-mtp-state-20261023/compile5/qwen-state/identity.json'",
     "'qwen-state': R / '.scratch/mtp-next-original-20261023/compile1/qwen-state/identity.json'"),
    ("    'dspark-state': R / '.scratch/glm-original-moe-20261023/compile1/dspark-state/identity.json',\n", ''),
    ("    'dspark-state': R / 'tests/compute_models/dspark_original_state_consumer_test.cc',\n", ''),
    ('qwen27-original-nextn-checks.exe', 'qwen24-original-nextn-checks.exe'),
    ('original Q27 and related state consumers', 'original Q24 and related Qwen state consumers'),
    ("env['HYLE_QWEN27_ORIGINAL_NEXTN_DIR'] = str(S / 'original-q27-nextn')",
     "env['HYLE_QWEN27_ORIGINAL_NEXTN_DIR'] = str(R / '.scratch/mtp-next-original-20261023/original-q27-nextn')\n    env['HYLE_QWEN24_ORIGINAL_NEXTN_DIR'] = str(S / 'original-q24-nextn')"),
]
for old, new in replacements:
    assert old in text, old
    text = text.replace(old, new)
ast.parse(text)
output = S / 'build.py'
assert not output.exists()
output.write_text(text, encoding='utf-8')
print('PREPARED', output)
