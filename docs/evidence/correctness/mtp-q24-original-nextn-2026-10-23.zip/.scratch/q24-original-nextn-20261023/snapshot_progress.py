"""Record current source/compile/acquisition facts without claiming native success."""
from pathlib import Path
import datetime
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
    with p.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p), bytes=p.stat().st_size, sha256=digest)
receipt = read(S/'original-q24-nextn/acquisition.json')
before = read(S/'before.json')
work = R/'docs/developer/current-work.md'
text = work.read_text(encoding='utf-8')
tail = text[text.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash == before['protected_performance_tail_sha256']
protected = before['protected_qwen_image']['image']
assert identity(Path(protected['path']))['sha256'] == protected['sha256']
sources = [R/'tests/compute_models'/name for name in (
    'qwen_mtp_state_consumer.h','qwen_mtp_state_consumer_test.cc',
    'qwen24_original_moe_fragment.h','qwen24_original_nextn_roles.h',
    'qwen24_original_resident_weights.h','qwen24_original_nextn_reference.h')]
result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn_classification='no progress toward implementation: answered operator-count/MTP status only; this turn revalidated and implemented/acquired/compiled BR instead of repeating status',
    this_turn='progress: actual part2 header/ranges, six Q24 consumer/reference/supplier sources, incremental compile, current-work/model table updated; actual original payload acquisition remains live',
    source=[identity(p) for p in sources],
    compile=identity(S/'compile2/qwen-state/identity.json'),
    first_compile_failure='Unqualified expect_projection found both Q24 and BQ by ADL via reused ActivationCodec; one-line namespace qualification fixed; original compile1 log retained.',
    original_payload=dict(expected=receipt['expected_role_payload_bytes'],
        verified_bytes=sum(c['bytes'] for role in receipt['roles'] for c in role['chunks']),
        complete_roles=sum(role['complete'] for role in receipt['roles']), complete=receipt['complete']),
    active_download=dict(exec_session_id=5795,process_id=36392,
        command='python .scratch/q24-original-nextn-20261023/fetch_q24.py',
        note='Only a live tool poll/process observation proves running; a saved handle alone does not.'),
    native_checks_run=False, linked_image=False, new_TPS=False, physical_memory_peak=False,
    next_commands=[
        'python .scratch/q24-original-nextn-20261023/pin_roles.py',
        'python .scratch/q24-original-nextn-20261023/build.py qwen-state link --attempt 3 --only qwen-state',
        'python .scratch/q24-original-nextn-20261023/build.py run --link-attempt 3 --attempt 1 --filter QwenMtpStateConsumer.* --expected-tests 8'],
    next_note='Run these only after the existing acquisition process completes successfully; final pin update requires recompiling the changed dependency. Do not restart a live acquisition on observation timeout.',
    protected_performance_tail_sha256=tail_hash, protected_qwen_image=protected)
(S/'progress.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verified_payload_bytes=result['original_payload']['verified_bytes'], expected=receipt['expected_role_payload_bytes'], compile_passed=True, native_checks_run=False, tail_unchanged=True)))
