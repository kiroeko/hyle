"""Resolve part2 roles from authenticated actual header; never infer offsets."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p): return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
path = S / 'roles-plan.json'
plan = read(path)
raw = read(S / 'header2/acquisition.json')
header_path = S / 'header2/header.json'
header = read(header_path)
assert (raw['repository'],raw['revision'],raw['file']) == (plan['repository'],plan['revision'],plan['sources']['2']['file'])
assert header['metadata']['split.no'] == 1 and header['metadata']['split.count'] == 29
assert int(header['metadata']['split.tensors.count']) == 1702
source = plan['sources']['2']
source.update(file_bytes=raw['file_bytes'], etag=raw['etag'], prefix=raw['header-prefix.bin'],
    header=dict(**identity(header_path), tensor_data_offset=int(header['tensor_data_offset']), tensor_count=header['tensor_count']),
    status='Actual fixedpart2 format and bounded64KiB prefix acquired; cachedparser header end4352 lies inside authenticatedprefix; exact untiedvocabulary ranges resolved.')
source.pop('whole_file_bytes', None)
for role in plan['roles']:
    if role['source_shard'] != 2: continue
    tensor = next(t for t in header['tensors'] if t['name'] == role['name'])
    assert list(map(int,tensor['shape'])) == role['gguf_shape_K_N_E']
    assert (tensor['dtype'],tensor['dtype_code']) == (role['dtype'],role['dtype_code'])
    first = int(tensor['offset']); base = int(header['tensor_data_offset'])
    role['data_relative_half_open'] = [first,first+role['bytes']]
    role['absolute_inclusive'] = [base+first,base+first+role['bytes']-1]
plan['scope'] = 'Exact originalQ24 acquisition plan:19 newroles have authenticated actualpart2/29 header ranges; old3 reused; no full weightshard or guessedoffset.'
plan['header_request'] = dict(acquisition=identity(S/'header2/acquisition.json'), format=raw['format.bin'], prefix=raw['header-prefix.bin'], header=identity(header_path))
path.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print('PLAN',identity(path))
print('NEW_ROLES',len(plan['roles']),'BYTES',sum(r['bytes'] for r in plan['roles']))
