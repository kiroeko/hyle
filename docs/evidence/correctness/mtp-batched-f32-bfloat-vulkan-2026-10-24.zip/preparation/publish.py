"""Archive this one-TU batched boundary check; reuse the parent Vulkan proof."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
BASE = S.parent
R = BASE.parents[1]
def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    p = Path(p).resolve()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p, value): Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

summary = read(S / 'checks1/summary.json')
assert summary['passed'] and (summary['cases'], summary['failures'], summary['skips']) == (2, 0, 0)
assert summary['process']['exit'] == 0 and not summary['process']['timed_out']
ready = read(S / 'link1/ready.json')
record = read(S / 'compile1/identity.json')
assert read(record['process']['path'])['exit'] == 0
actual_link = read(ready['plan']['path'])
assert read(ready['process']['path'])['exit'] == 0
assert len(actual_link['retained_records']) == 75  # 40 product/native plus35 neutral current objects.
assert str(Path(record['object']['path'])) in actual_link['command']
old_test = read(BASE / 'link1/link-plan.json')['test_object']['path']
assert old_test not in actual_link['command']
parent = R / 'docs/evidence/correctness/mtp-gdn-output-scale-vulkan-2026-10-24.json'
assert identity(parent)['sha256'] == 'ede2eac025864e3b63f2aa4c1ad453fb0c307b91536d97c3f2aa51889a6c4ae1'
target = R / 'docs/evidence/correctness/mtp-batched-f32-bfloat-vulkan-2026-10-24.json'
archive = target.with_suffix('.zip')
assert not target.exists() and not archive.exists()
files = {}
for name in ['build.py', 'publish.py', 'CMakeLists-before.txt', 'source.patch', 'applied.json']:
    files['preparation/' + name] = S / name
for folder in ['compile1', 'checks1']:
    for p in sorted((S / folder).rglob('*')):
        if p.is_file() and p.suffix.lower() in ('.json', '.cc', '.log', '.xml'):
            files['preparation/' + p.relative_to(S).as_posix()] = p
for p in sorted((S / 'link1').glob('*.json')):
    files['preparation/' + p.relative_to(S).as_posix()] = p
for p in sorted((S / 'link1/run').rglob('*')):
    if p.is_file() and p.suffix in ('.log', '.json'):
        files['preparation/' + p.relative_to(S).as_posix()] = p
for name in ['tests/compute_route_vulkan/batched_bfloat_linear_test.cc',
             'tests/compute_route_vulkan/CMakeLists.txt']:
    files['current-source/' + name] = R / name
files['parent-proof.json'] = parent
files['parent-ready.json'] = BASE / 'link1/ready.json'
files['parent-link-plan.json'] = BASE / 'link1/link-plan.json'
manifest = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        z.writestr(name, data)
        manifest.append(dict(name=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        data = z.read(row['name'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
proof = dict(date='2026-10-24', scope='Finite direct Vulkan exact-batch F32 activation / original BF16 weight boundary.',
    validation=summary, build=dict(test_translation_units=1, product_translation_units=0,
        native_translation_units=0, SDK_builds=0, shader_builds=0, NVCC=0,
        compile_record=identity(S / 'compile1/identity.json'), actual_link=ready,
        retained_current_objects=75, owning_native_family='Vulkan9ac7; identical to parent GDN focused closure'),
    parent_current_closure=identity(parent), source_changes=read(S / 'applied.json'),
    covered=dict(actual_projection=dict(activation=[3, 2, 66], weight=[3, 4, 66], output=[3, 2, 4],
        activation_dtype='F32', weight_dtype='BF16', output_dtype='F32',
        checks=['Exact dyadic F32 cancellation values below BF16/TF32 input resolution.',
            'Distinct original BF16 coefficients per batch and output column.',
            'Dense output shape/order and unchanged original activation and BF16 payload.']),
        cold_descriptor_only=[dict(activation=[64, 1, 256], weight=[64, 512, 256], output=[64, 1, 512]),
            dict(activation=[64, 1, 512], weight=[64, 256, 512], output=[64, 1, 256])],
        rejected=['BF16 rank3 A is permitted by public inference and returns Unimplemented during Vulkan prepare.',
            'Unequal explicit batch identities fail public inference; no implicit broadcast.']),
    boundaries=['Only the two named canonical cases; no extra shape matrix or model data.',
        '64-head checks build descriptors/programs only: no original 16MiB fixture weight payload is materialized, uploaded or submitted.',
        'No Graph, full-model, throughput, memory peak or other-device claim.',
        'Parent SDK, generated programs, shaders, product/native objects and all binaries stay in their existing caches.'],
    archive=identity(archive), archive_entries=len(manifest)+1,
    network_bytes=0, automatic_downloads=False, model_scope_changed=False)
save(target, proof)
save(S / 'publication.json', dict(proof=identity(target), archive=identity(archive),
    cases=2, failures=0, skips=0, archive_entries=len(manifest)+1))
print(json.dumps(read(S / 'publication.json'), ensure_ascii=False))
