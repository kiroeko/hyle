"""One batched-BF16 test TU on the completed direct Vulkan GDN closure."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
BASE = S.parent
R = BASE.parents[1]
spec = importlib.util.spec_from_file_location('_batched_vulkan_completed_closure', BASE / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
SOURCE = R / 'tests/compute_route_vulkan/batched_bfloat_linear_test.cc'
FILTER = 'BatchedBfloatVulkan.*'


def compile_one():
    prior_path = BASE / 'compile1/test/identity.json'
    prior = b.read(prior_path)
    out = S / 'compile1'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    command = []
    for arg in prior['command']:
        if arg == prior['source']['path']:
            arg = str(SOURCE)
        elif arg.startswith('/Fo'):
            arg = '/Fo' + str(out / 'batched-test.obj')
        elif arg.startswith('/Fd'):
            arg = '/Fd' + str(out / 'batched-test.pdb')
        elif arg.startswith('/DHYLE_GDN_SCALE_'):
            continue
        command.append(arg)
    command[command.index('/sourceDependencies') + 1] = str(out / 'source-deps.json')
    source = b.identity(SOURCE)
    (out / SOURCE.name).write_bytes(SOURCE.read_bytes())
    b.save(out / 'plan.json', dict(entry=b.identity(Path(__file__)), source=source,
        recipe=b.identity(prior_path), command=command, test_TUs=1,
        product_TUs=0, native_TUs=0, SDK=0, NVCC=0, shaders=0))
    env, _ = b.b.environment(command, [], out)
    process = b.q.execute(command, env, out / 'run', timeout=1800)
    if process['exit'] != 0 or process['timed_out']:
        print((out / 'run/stdout.log').read_text(errors='replace'), flush=True)
        raise SystemExit(process['exit'] or 1)
    b.require(source)
    dep = b.read(out / 'source-deps.json')['Data']
    b.save(out / 'identity.json', dict(source=source, object=b.identity(out / 'batched-test.obj'),
        command=command, recipe=b.identity(prior_path), process=b.identity(out / 'run/process.json'),
        dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]))
    print('COMPILED batched test1; host/native0', flush=True)


def link():
    ready = b.read(BASE / 'link1/ready.json')
    for key in ('image', 'link_plan', 'link_result', 'runtime'):
        b.require(ready[key])
    prior = b.read(ready['link_plan']['path'])
    retained_records = []
    checked = set()
    for row in [*prior['compiled_records'], *prior['current_public_records']]:
        record = b.read(row['path'])
        if record['object']['path'] == prior['test_object']['path']:
            continue
        for item in [row, record['source'], record['object'], *record['dependencies']]:
            key = str(Path(item['path']).resolve()).lower()
            if key not in checked:
                b.require(item)
                checked.add(key)
        retained_records.append(row)
    fresh_path = S / 'compile1/identity.json'
    fresh = b.read(fresh_path)
    for row in [fresh['source'], fresh['object'], *fresh['dependencies']]:
        b.require(row)
    for row in prior['libraries']:
        b.require(row)
    b.require(prior['native_owning_object'])
    out = S / 'link1'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'batched-bfloat-vulkan.exe'
    command = []
    count = 0
    for arg in prior['command']:
        if arg == prior['test_object']['path']:
            arg = fresh['object']['path']; count += 1
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        command.append(arg)
    assert count == 1
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    b.save(out / 'plan.json', dict(entry=b.identity(Path(__file__)), command=command,
        base_ready=b.identity(BASE / 'link1/ready.json'), base_plan=ready['link_plan'],
        test_record=b.identity(fresh_path), retained_records=retained_records,
        retained_libraries=prior['libraries'], native_owning_object=prior['native_owning_object'],
        test_TUs=1, product_TUs=0, native_TUs=0, SDK=0, NVCC=0, shaders=0))
    env, _ = b.b.environment(command, [x['path'] for x in prior['libraries']], out)
    process = b.q.execute(command, env, out / 'run', timeout=1800)
    if process['exit'] != 0 or process['timed_out']:
        print((out / 'run/stdout.log').read_text(errors='replace'), flush=True)
        raise SystemExit(process['exit'] or 1)
    b.save(out / 'runtime.json', dict(PATH=env['PATH'], staged_dlls=[]))
    b.save(out / 'ready.json', dict(image=b.identity(image), plan=b.identity(out / 'plan.json'),
        process=b.identity(out / 'run/process.json'), runtime=b.identity(out / 'runtime.json'),
        filter=FILTER, expected_cases=2, native_executed=False))
    print('LINKED ' + str(image), flush=True)


def run():
    ready = b.read(S / 'link1/ready.json')
    for key in ('image', 'plan', 'process', 'runtime'):
        b.require(ready[key])
    out = S / 'checks1'
    out.mkdir(exist_ok=False)
    command = [ready['image']['path'], '--gtest_filter=' + FILTER,
        '--gtest_throw_on_failure=1', '--gtest_output=xml:' + str(out / 'results.xml')]
    env = dict(os.environ, PATH=b.read(ready['runtime']['path'])['PATH'])
    env.pop('HYLE_VULKAN_VALIDATION', None)
    b.save(out / 'plan.json', dict(command=command, image=ready['image'],
        entry=b.identity(Path(__file__)), base_ready=b.identity(S / 'link1/ready.json'),
        HTTP=0, model_data=0, automatic_downloads=False))
    process = b.q.execute(command, env, out / 'run', timeout=600)
    xml = ET.parse(out / 'results.xml').getroot() if (out / 'results.xml').is_file() else None
    cases = [] if xml is None else xml.findall('.//testcase')
    failures = sum(len(x.findall('failure')) for x in cases)
    skips = sum(len(x.findall('skipped')) for x in cases)
    passed = process['exit'] == 0 and not process['timed_out'] and len(cases) == 2 and failures == 0 and skips == 0
    b.save(out / 'summary.json', dict(passed=passed, process=process,
        cases=len(cases), failures=failures, skips=skips,
        xml=b.identity(out / 'results.xml') if xml is not None else None,
        case_names=[x.attrib['classname'] + '.' + x.attrib['name'] for x in cases],
        HTTP=0, model_data=0, throughput_evidence=False))
    print(b.read(out / 'summary.json'), flush=True)
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['compile', 'link', 'run'])
    action = p.parse_args().action
    {'compile': compile_one, 'link': link, 'run': run}[action]()
