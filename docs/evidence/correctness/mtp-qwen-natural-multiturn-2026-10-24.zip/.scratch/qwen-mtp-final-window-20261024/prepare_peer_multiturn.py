"""Source-only extension of the frozen native peer; no model/build execution."""
from pathlib import Path
import difflib
import hashlib
import json

R = Path(__file__).resolve().parents[2]
S = Path(__file__).resolve().parent
ORIGINAL = R / '.scratch/qwen-mtp-quality-20261022/source/peer_mtp.cc'
DESTINATION = S / 'source/peer_multiturn.cc'


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    raw = ORIGINAL.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '03099c5c8698d1ce4a079737c69b1f8366aef9941406dcc72b505dfbc7a7224f'
    before = raw.decode('utf-8')
    text = before

    def replace(old, new):
        nonlocal text
        assert text.count(old) == 1, old[:100]
        text = text.replace(old, new)

    replace('#include "nlohmann/json.hpp"', '#include "nlohmann/json.hpp"\n#include "../../../tools/qwen35_text/mtp_schedule.h"')
    replace('std::filesystem::path model, inputs, output;', 'std::filesystem::path model, inputs, output, schedule;')
    replace('bool mtp = false, memory_snapshots = false;', 'bool mtp = false, memory_snapshots = false, explicit_steps = false;')
    replace('else if (k == "--output") o.output = v;', 'else if (k == "--output") o.output = v;\n        else if (k == "--schedule") o.schedule = v;')
    replace('else if (k == "--steps") o.steps = integer(v);', 'else if (k == "--steps") { o.steps = integer(v); o.explicit_steps = true; }')
    replace('    require(!o.model.empty() && !o.inputs.empty(), "--model GGUF and --inputs DIR are required");', '''    if (o.schedule.empty())
        require(!o.model.empty() && !o.inputs.empty(), "--model GGUF and --inputs DIR are required");
    else {
        require(!o.model.empty(), "--model GGUF is required");
        require(!o.prompt_rows && !o.max_rounds && !o.explicit_steps,
                "--schedule is exclusive with --prompt-rows, --max-rounds and explicit --steps");
    }''')
    replace('o.capacity && o.capacity <= 4096 && o.steps && o.steps <= o.capacity,',
            'o.capacity && o.capacity <= 4096 && o.steps && (!o.schedule.empty() || o.steps <= o.capacity),')
    begin = text.index('    std::ifstream input(o.inputs / "prompt.ids");')
    end = text.index('    Backend backend;', begin)
    old_prompt = text[begin:end]
    assert old_prompt.startswith('    std::ifstream')
    new_prompt = '''    Tokens prompt;
    std::vector<qwen35::benchmark::MtpTurn> turn_definitions;
    if (o.schedule.empty()) {
        std::ifstream input(o.inputs / "prompt.ids"); require(static_cast<bool>(input), "cannot open prompt.ids");
        int64_t token = 0;
        while (input >> token) {
            require(token >= 0 && token < (std::numeric_limits<llama_token>::max)(), "invalid prompt ID");
            prompt.push_back(static_cast<llama_token>(token));
        }
        require(input.eof() && !prompt.empty(), "invalid or empty prompt.ids");
        if (o.prompt_rows) { require(o.prompt_rows <= prompt.size(), "prompt rows exceed source IDs"); prompt.resize(o.prompt_rows); }
        require(prompt.size() <= o.capacity && o.steps - 1 <= o.capacity - prompt.size(), "prompt plus requested output inputs exceed context");
        turn_definitions.push_back({prompt, o.steps});
    } else {
        // Same consumer-only natural grammar as Hyle; all capacities and IDs
        // are checked before loading. The actual vocabulary is checked below.
        turn_definitions = qwen35::benchmark::read_mtp_schedule(o.schedule,
            (std::numeric_limits<llama_token>::max)(), o.capacity, o.steps, false);
        prompt = turn_definitions.front().prompt;
    }
    std::size_t requested_steps = 0, maximum_batch = prompt.size();
    for (std::size_t i = 0; i < turn_definitions.size(); ++i) {
        const auto & turn = turn_definitions[i];
        require(turn.steps <= (std::numeric_limits<std::size_t>::max)() - requested_steps,
                "total output quota overflow");
        requested_steps += turn.steps;
        // Warm target adds pending, and a lag1 draft adds its catchup row.
        maximum_batch = (std::max)(maximum_batch, turn.prompt.size() + (i ? 2u : 0u));
    }
'''
    text = text[:begin] + new_prompt + text[end:]
    replace('    Sampler target_sampler(', '''    for (const auto & turn : turn_definitions)
        require(std::all_of(turn.prompt.begin(), turn.prompt.end(),
            [&](llama_token id) { return id < vocabulary; }), "schedule/model vocabulary mismatch");
    Sampler target_sampler(''')
    replace('cp.n_batch = static_cast<uint32_t>((std::max)(prompt.size(), o.mtp ? std::size_t{2} : std::size_t{1}));',
            'cp.n_batch = static_cast<uint32_t>((std::max)(maximum_batch, o.mtp ? std::size_t{2} : std::size_t{1}));')
    while_begin = text.index('    while (generated.size() < o.steps')
    while_end = text.index('    const auto endpoint = Clock::now(); marker("generation_decode_end", endpoint);', while_begin)
    loop = text[while_begin:while_end]
    loop = loop.replace('generated.size() < o.steps', 'generated.size() < turn_output_limit')
    loop = loop.replace('const auto quota = o.steps - generated.size();', 'const auto quota = turn_output_limit - generated.size();')
    loop = loop.replace('rounds.push_back({{"index", rounds.size()},',
        'rounds.push_back({{"index", rounds.size()}, {"turn", turn_index + 1}, {"turn_round", rounds.size() - round_begin},')
    assert 'o.steps' not in loop
    loop = ''.join('    ' + line if line.strip() else line for line in loop.splitlines(True))
    start = text.index('    marker("generation_prefill_begin", Clock::now());')
    finish = text.index('    if (o.memory_snapshots) snapshots.push_back(memory("after_journey", startup, device));', start)
    middle = '''    Json rounds = Json::array(), turn_reports = Json::array();
    Json target_prefill = nullptr, draft_prefill = nullptr;
    Tokens generated;
    std::vector<float> carry, prior;
    std::size_t length = 0, frontier = 0, lag = 0;
    llama_token catchup = LLAMA_TOKEN_NULL, pending = LLAMA_TOKEN_NULL, first = LLAMA_TOKEN_NULL;
    std::size_t target_rows = 0, draft_rows = 0, target_calls = 0, draft_calls = 0;
    std::size_t prefill_target_rows = 0, prefill_draft_rows = 0;
    std::size_t proposals = 0, agreements = 0, accepts = 0;
    double prefill_seconds = 0.0, decode_seconds = 0.0;
    Point journey_begin{}, endpoint{}, first_prefill_end{};
    for (std::size_t turn_index = 0; turn_index < turn_definitions.size(); ++turn_index) {
        const auto & turn = turn_definitions[turn_index];
        const auto context_before = length, draft_before = frontier, lag_before = lag;
        const auto output_begin = generated.size(), round_begin = rounds.size();
        const auto target_calls_before = target_calls, draft_calls_before = draft_calls;
        const auto target_rows_before = target_rows, draft_rows_before = draft_rows;
        const auto accepted_before = accepts, proposals_before = proposals;
        Tokens input_ids = turn.prompt;
        if (turn_index) {
            // The final emitted token is pending, including EOS. Consume it
            // exactly once before the next explicit raw user-token segment.
            require(pending >= 0 && pending < vocabulary, "missing previous-turn pending ID");
            input_ids.insert(input_ids.begin(), pending);
            position(target.get(), length);
            if (o.mtp) position(draft.get(), frontier);
        }
        require(input_ids.size() <= o.capacity - length, "warm input exceeds context");
        const auto label = [&](const char * phase) {
            return o.schedule.empty() ? std::string("generation_") + phase
                : std::string("round") + std::to_string(turn_index + 1) + "_" + phase;
        };
        marker(label("prefill_begin").c_str(), Clock::now());
        // Inter-turn host construction belongs to the next prefill. P/D
        // intervals remain disjoint and sum to the whole journey endpoint.
        const auto prefill_begin = turn_index ? endpoint : Clock::now();
        if (!turn_index) journey_begin = prefill_begin;
        target_batch.fill(input_ids, length, nullptr, false, true);
        auto turn_target_prefill = decode(target.get(), target_batch);
        std::vector<float> target_hidden;
        if (o.mtp) target_hidden = hidden(target.get(), input_ids.size(), width);
        const auto turn_first = sampled(target.get(), target_sampler.get(), input_ids.size() - 1, 1, vocabulary).front();
        Json turn_draft_prefill = nullptr;
        std::size_t actual_draft_prefill_rows = 0;
        if (o.mtp) {
            Tokens draft_input = input_ids;
            std::vector<float> shifted;
            if (!turn_index) {
                shifted.assign(input_ids.size() * width, 0.0f);
                if (input_ids.size() > 1)
                    std::copy(target_hidden.begin(), target_hidden.end() - static_cast<std::ptrdiff_t>(width),
                              shifted.begin() + static_cast<std::ptrdiff_t>(width));
            } else {
                require(frontier + lag == length && lag <= 1 && carry.size() == width &&
                    (lag == 0 || (prior.size() == width && catchup >= 0)), "inconsistent warm MTP frontier");
                shifted.reserve((input_ids.size() + lag) * width);
                if (lag) {
                    draft_input.insert(draft_input.begin(), catchup);
                    shifted.insert(shifted.end(), prior.begin(), prior.end());
                }
                shifted.insert(shifted.end(), carry.begin(), carry.end());
                shifted.insert(shifted.end(), target_hidden.begin(), target_hidden.end() - static_cast<std::ptrdiff_t>(width));
            }
            draft_batch->fill(draft_input, frontier, &shifted, false, false);
            turn_draft_prefill = decode(draft.get(), *draft_batch);
            actual_draft_prefill_rows = draft_input.size();
            frontier += draft_input.size();
            require(frontier == length + input_ids.size(), "warm draft did not catch target frontier");
            trim(draft.get(), frontier);
            carry.assign(target_hidden.end() - static_cast<std::ptrdiff_t>(width), target_hidden.end());
            prior.clear(); catchup = LLAMA_TOKEN_NULL; lag = 0;
        }
        length += input_ids.size();
        position(target.get(), length);
        if (o.mtp) position(draft.get(), length);
        pending = turn_first;
        generated.push_back(turn_first);
        if (!turn_index) { first = turn_first; target_prefill = turn_target_prefill; draft_prefill = turn_draft_prefill; }
        prefill_target_rows += input_ids.size(); prefill_draft_rows += actual_draft_prefill_rows;
        const auto prefill_end = Clock::now(), decode_begin = prefill_end;
        if (!turn_index) first_prefill_end = prefill_end;
        marker(label("prefill_end").c_str(), prefill_end); marker(label("decode_begin").c_str(), decode_begin);
        const auto turn_output_limit = output_begin + turn.steps;
''' + loop + '''        endpoint = Clock::now(); marker(label("decode_end").c_str(), endpoint);
        const auto turn_prefill_seconds = seconds(prefill_end, prefill_begin);
        const auto turn_decode_seconds = seconds(endpoint, decode_begin);
        prefill_seconds += turn_prefill_seconds; decode_seconds += turn_decode_seconds;
        turn_reports.push_back({{"turn", turn_index + 1}, {"user_ids", turn.prompt}, {"new_user_rows", turn.prompt.size()},
            {"input_ids", input_ids}, {"pending_flushed", turn_index != 0},
            {"context_before", context_before}, {"context_after", length},
            {"draft_before", o.mtp ? Json(draft_before) : Json(nullptr)}, {"draft_after", o.mtp ? Json(frontier) : Json(nullptr)},
            {"lag_before", o.mtp ? Json(lag_before) : Json(nullptr)}, {"lag_after", o.mtp ? Json(lag) : Json(nullptr)},
            {"output_begin", output_begin}, {"output_end", generated.size()}, {"requested_steps", turn.steps},
            {"generated_ids", Tokens(generated.begin() + static_cast<std::ptrdiff_t>(output_begin), generated.end())},
            {"stopped_on_EOS", eos(pending)}, {"prefill_first_id", turn_first},
            {"prefill_target_rows", input_ids.size()}, {"prefill_draft_rows", actual_draft_prefill_rows},
            {"target_decode_rows", target_rows - target_rows_before}, {"draft_decode_rows", draft_rows - draft_rows_before},
            {"target_compute_calls", target_calls - target_calls_before + 1},
            {"draft_compute_calls", o.mtp ? draft_calls - draft_calls_before + 1 : 0},
            {"proposals", proposals - proposals_before}, {"accepted_drafts", accepts - accepted_before},
            {"prefill_target_compute", turn_target_prefill}, {"prefill_draft_compute", turn_draft_prefill},
            {"prefill_seconds", turn_prefill_seconds}, {"decode_seconds", turn_decode_seconds},
            {"session_seconds", seconds(endpoint, prefill_begin)},
            {"native_target_pos_max", llama_memory_seq_pos_max(llama_get_memory(target.get()), 0)},
            {"native_draft_pos_max", o.mtp ? Json(llama_memory_seq_pos_max(llama_get_memory(draft.get()), 0)) : Json(nullptr)}});
    }
'''
    text = text[:start] + middle + text[finish:]
    replace('    const auto prefill_seconds = seconds(prefill_end, prefill_begin), decode_seconds = seconds(endpoint, decode_begin);\n    const auto journey_seconds = seconds(endpoint, prefill_begin);',
            '    const auto journey_seconds = seconds(endpoint, journey_begin);')
    replace('{"prompt_ids", prompt}, {"requested_steps", o.steps},', '{"prompt_ids", prompt}, {"requested_steps", requested_steps},\n        {"schedule", o.schedule.empty() ? Json(nullptr) : Json(o.schedule.string())}, {"turns", turn_reports},')
    replace('{"schedule", o.schedule.empty() ? Json(nullptr) : Json(o.schedule.string())}, {"turns", turn_reports},',
            '{"schedule", o.schedule.empty() ? Json(nullptr) : Json(o.schedule.string())}, {"turns", turn_reports},\n        {"turn_count", turn_definitions.size()}, {"session_count", 1},\n        {"pending_flushed_tokens", turn_definitions.size() - 1}, {"committed_target_rows", length},\n        {"weights_loaded_once", true}, {"contexts_created_once", true},\n        {"first_token_elapsed_seconds", seconds(first_prefill_end, startup)},')
    replace('{"prefill_tokens_per_second", prompt.size() / prefill_seconds}', '{"prefill_tokens_per_second", prefill_target_rows / prefill_seconds}')
    replace('{"decode_output_tokens_per_second", generated.size() > 1 ? (generated.size() - 1) / decode_seconds : 0.0}',
            '{"decode_output_tokens_per_second", generated.size() > turn_definitions.size() ? (generated.size() - turn_definitions.size()) / decode_seconds : 0.0}')
    replace('{"prefill_target_rows", prompt.size()}, {"prefill_draft_rows", o.mtp ? prompt.size() : 0}',
            '{"prefill_target_rows", prefill_target_rows}, {"prefill_draft_rows", prefill_draft_rows}')
    replace('{"committed_target_decode_rows", length - prompt.size()}', '{"committed_target_decode_rows", length - prefill_target_rows}')
    replace('{"generated_decode_tokens", generated.size() - 1}', '{"generated_decode_tokens", generated.size() - turn_definitions.size()}')
    replace('{"actual_target_rows", prompt.size() + target_rows}, {"actual_draft_rows", o.mtp ? prompt.size() + draft_rows : 0}',
            '{"actual_target_rows", prefill_target_rows + target_rows}, {"actual_draft_rows", prefill_draft_rows + draft_rows}')
    replace('{"target_compute_calls", target_calls + 1}, {"draft_compute_calls", o.mtp ? draft_calls + 1 : 0}',
            '{"target_compute_calls", target_calls + turn_definitions.size()}, {"draft_compute_calls", o.mtp ? draft_calls + turn_definitions.size() : 0}')
    DESTINATION.parent.mkdir(exist_ok=True)
    DESTINATION.write_text(text, encoding='utf-8', newline='\n')
    diff = ''.join(difflib.unified_diff(before.splitlines(True), text.splitlines(True),
        fromfile='peer-original/peer_mtp.cc', tofile='source/peer_multiturn.cc'))
    patch = S / 'natural-turns-proposal/peer-source.diff'
    patch.parent.mkdir(exist_ok=True)
    patch.write_text(diff, encoding='utf-8', newline='\n')
    assert ORIGINAL.read_bytes() == raw
    result = dict(status='Source-only peer proposal; not compiled or run', original=identity(ORIGINAL),
        source=identity(DESTINATION), diff=identity(patch), parser=identity(R / 'tools/qwen35_text/mtp_schedule.h'),
        changes=['One existing run/context/model lifetime with a serial turn loop; no second executor.',
            'Explicit raw prompt/generate schedule; pending appended once, natural EOS ends only that turn.',
            'Warm target/draft hidden alignment preserves prior/carry and catches native draft frontier before generation.',
            'Original K1 generation body changes only quota and turn metadata; original math/accept/trim are unchanged.',
            'Same model, target context and optional draft context survive every turn without cache clear or history prefill.',
            'Single-prompt defaults remain; schedule rejects explicit steps/prompt truncation/max-rounds.'],
        builds=0, native_runs=0, HTTP=0, canonical_edits=0)
    (S / 'natural-turns-proposal/peer-ready.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
