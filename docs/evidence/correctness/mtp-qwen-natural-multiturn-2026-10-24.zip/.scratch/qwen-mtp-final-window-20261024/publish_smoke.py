"""Publish the actual four-arm/two-turn natural continuation smoke only."""
from pathlib import Path
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


archive_tool = module('_natural_turns_small_archive', R / '.scratch/glm-quark-selected-20261024/Q30/publish.py')
archive_tool.SMALL_SUFFIXES.update({'.diff', '.ids'})
read, identity, require, resolve = archive_tool.read, archive_tool.identity, archive_tool.require, archive_tool.resolve
smoke = module('_actual_natural_turns_reader', S / 'smoke.py')


def main():
    name = 'mtp-qwen-natural-multiturn-2026-10-24'
    proof, zip_path = D / (name + '.json'), D / (name + '.zip')
    if proof.exists() or zip_path.exists():
        raise ValueError('New finite evidence must not overwrite old quality/performance records')
    folder = S / 'smoke1'
    plan, summary = read(folder / 'plan.json'), read(folder / 'summary.json')
    if summary['status'] != 'All selected arms passed' or summary['cases'] != 4 or summary['failures'] != 0:
        raise ValueError('Require all four actual completed arms')
    if plan['quota'] != 4 or plan['capacity'] != 1024 or len(plan['user_ids']) != 154:
        raise ValueError('Keep the executed finite workload')
    require(plan['input']); require(plan['schedule']); require(plan['driver'])
    build = read(S / 'current-build-result.json')
    archive = archive_tool.Archive([])
    archive.add(Path(__file__))
    archive.add(S / 'smoke.py'); archive.add(S / 'build_turns.py')
    archive.add(S / 'current-build-result.json')
    archive.add(S / 'prepare_peer_multiturn.py')
    archive.add(plan['input']['path']); archive.add(plan['schedule']['path'])
    inputs = read(plan['input']['path'])
    archive.add(inputs['prompt']['path']); archive.add(inputs['source_input']['path'])
    for source in build['sources'].values():
        require(source); archive.add(source['path'])
    for path in (R / 'tools/qwen35_text/session_schedule.h', R / 'tools/qwen35_text/schedule.h',
                 S / 'natural-turns-proposal/source.patch', S / 'natural-turns-proposal/peer-source.diff',
                 S / 'natural-turns-proposal/before.json', S / 'natural-turns-proposal/after.json'):
        archive.add(path)
    for path in (S / 'natural-turns-proposal/before').rglob('*'):
        if path.is_file() and path.suffix in ('.cc', '.h'):
            archive.add(path)
    for key in ('hyle_build', 'hyle_compile', 'hyle_link', 'peer_compile', 'peer_link'):
        require(build[key]); archive.add(build[key]['path'])
    runs, seen = [], set()
    for entry in plan['commands']:
        arm = entry['arm']
        if arm in seen or arm not in smoke.ARMS:
            raise ValueError('Exactly four distinct original arms are required')
        seen.add(arm)
        run_folder = resolve(entry['folder'])
        process = read(run_folder / 'process.json')
        if process['exit'] != 0 or process['timed_out'] or process['command'] != entry['command']:
            raise ValueError('Actual arm failed or command changed: ' + arm)
        raw = smoke.parse(run_folder)
        checked = smoke.check(raw, arm, plan)
        if checked != read(run_folder / 'observation.json'):
            raise ValueError('Archived observation differs from actual raw output')
        if checked['generated_tokens'] != 8 or checked['context'] != 315:
            raise ValueError('Keep the actual two four-output turns and committed length')
        require(entry['ready']); require(entry['environment'])
        ready = read(entry['ready']['path'])
        if ready['image'] != entry['image'] or resolve(entry['command'][0]).stat().st_size != entry['image']['bytes']:
            raise ValueError('Actual executed image identity differs')
        compiled_key = 'compiled_identity' if arm.startswith('peer') else 'compiled_record'
        require(ready[compiled_key]); require(ready['link_plan'])
        compiled = read(ready[compiled_key]['path'])
        require(compiled['source'])
        archive.add(ready[compiled_key]['path'])
        archive.add(entry['ready']['path']); archive.add(entry['environment']['path'])
        archive.add(ready['link_plan']['path'])
        compile_folder = resolve(ready[compiled_key]['path']).parent
        image_folder = resolve(entry['ready']['path']).parent
        for directory, prefix in ((compile_folder, 'compile'), (image_folder, 'link')):
            for filename in ('plan.json', prefix + '.command.json', prefix + '.result.json',
                             prefix + '.stdout.log', prefix + '.stderr.log'):
                path = directory / filename
                if path.is_file(): archive.add(path)
        archive.metadata_tree(run_folder)
        turns = []
        for turn in checked['turns_observed']:
            observed = {key: turn[key] for key in ('turn', 'requested_steps', 'pending_flushed',
                'context_before', 'context_after', 'output_begin', 'output_end')}
            observed['last_output_is_EOS'] = checked['generated_ids'][turn['output_end'] - 1] in smoke.EOS
            if 'stopped_on_EOS' in turn:
                observed['stopped_on_EOS'] = turn['stopped_on_EOS']
            turns.append(observed)
        runs.append(dict(arm=arm, passed=True, generated_ids=checked['generated_ids'], generated_tokens=8,
            turns=turns, actual_target_rows=checked['actual_target_rows'], actual_draft_rows=checked['actual_draft_rows'],
            prefill_target_rows=checked['prefill_target_rows'], accepted_drafts=checked['accepted_drafts'],
            observation=identity(run_folder / 'observation.json'), process=identity(run_folder / 'process.json'),
            stdout=identity(run_folder / 'stdout.log'), stderr=identity(run_folder / 'stderr.log'),
            image=entry['image'], ready=entry['ready'], compiled_record=ready[compiled_key], runtime=entry['environment']))
    if seen != set(smoke.ARMS):
        raise ValueError('Missing original arm')
    archive.add(folder / 'plan.json'); archive.add(folder / 'summary.json')
    if any(path.stat().st_size > 1_000_000 for path in archive.files.values()):
        raise ValueError('Only necessary small source and metadata files belong in this archive')
    with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for name_in_zip, path in sorted(archive.files.items()):
            target.write(path, name_in_zip)
    result = dict(schema='hyle-finite-consumer-correctness-v1', date='2026-10-24', status='passed',
        scope='Four actual Hyle/llama ordinary/K1 arms, one resident session with two consecutive natural turns; four generated outputs per turn. Finite cache/pending continuation smoke only.',
        counts=dict(arms=4, passed=4, failed=0, turns_per_arm=2, output_quota_per_turn=4, actual_outputs_per_arm=8),
        input=dict(preparation=plan['input'], schedule=plan['schedule'], prompt=inputs['prompt'],
            user_rows=[154,154], target_prefill_rows=309, pending_flushed_once_before_second_turn=1,
            final_committed_target_rows=315, capacity=1024, raw_token_append=True, chat_template_claim=False),
        behavior=dict(natural_greedy=True, teacher_forced_generation=False,
            model_loaded_once_per_arm=True, contexts_or_session_retained_across_turns=True,
            history_clear_or_reprefill=False, same_token_cross_arm_claim=False,
            source_math='Existing K1 arithmetic/selection/trim operations remain; source adds serial turn boundaries and actual observations.'),
        runs=runs, plan=identity(folder / 'plan.json'), summary=identity(folder / 'summary.json'),
        source_changes=build['sources'], build=dict(result=identity(S / 'current-build-result.json'),
            fresh_Hyle_main_TUs=1, fresh_peer_consumer_TUs=1, native_kernel_TUs=0, SDK_builds=0, NVCC=0),
        reused_evidence=[identity(D / 'mtp-packed-mmq-workspace-2026-10-24.json'),
                         identity(D / 'qwen-mtp-quality-prefix-2026-10-22.json')],
        limitations=['This short smoke does not assess generated task correctness or complete model quality; the earlier four-arm coding-task result remains unchanged.',
            'No new speed, throughput, memory/VRAM peak or multi-session/concurrent serving result is claimed.',
            'Both turns reached their four-output quota here; EOS-ended turn continuation was not exercised.',
            'MTP ran natural acceptance and within-turn lag catchup; this smoke does not exercise a lag1 boundary between turns or all cancellation/failure paths.',
            'The explicit original154-token raw segment is appended twice; this is not a new rendered chat-template contract.',
            'Native F32 peer carry and Hyle BF16 intermediate policies remain distinct; no cross-engine numerical equivalence follows from this smoke.'],
        throughput_evidence=False, memory_peak_evidence=False, full_model_quality_pass=False,
        source_check_only_activity_after_run=True, new_native_runs_by_publisher=0, HTTP=0,
        files=[dict(archive_path=name_in_zip, **identity(path)) for name_in_zip,path in sorted(archive.files.items())],
        archive=identity(zip_path))
    proof.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
    finished = dict(proof=identity(proof), archive=identity(zip_path), arms=4, turns_per_arm=2, actual_outputs_per_arm=8)
    (S / 'smoke-published.json').write_text(json.dumps(finished, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(finished, indent=2), flush=True)


if __name__ == '__main__':
    main()
