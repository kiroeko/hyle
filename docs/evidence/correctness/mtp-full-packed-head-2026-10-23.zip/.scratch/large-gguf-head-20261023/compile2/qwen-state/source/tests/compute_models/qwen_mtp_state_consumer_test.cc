#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>
#include <span>
#include <string>
#include <vector>

#include "hyle/compute/resource_leases.h"
#include "hyle/compute/state_versions.h"
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/ggml_cuda.h"
#include "hyle/graph/cuda.h"
#include "cuda_sidecar_quant_reference.h"
// This TU contains both backends. Runtime reference selection below must not
// change the legacy Bank::dots definition or turn CPU checks into CUDA work.
#undef HYLE_C4_QUANTIZED_REFERENCE
#undef HYLE_C4_GROUPED_REFERENCE
#undef HYLE_C5_GGUF_DOT_REFERENCE
#endif
#if defined(HYLE_TEST_QWEN_STATE_CPU)
#include "hyle/graph/cpu.h"
#endif
#include "qwen_mtp_state_consumer.h"

namespace {
using namespace qwen_mtp_state_consumer;
namespace numeric=d5_qwen35_gguf_fragment;

Bytes read(const c::ReadLease &lease) {
  Bytes bytes(lease.size());check(take(lease.view(),"actual readonly result").read(bytes),"retained result bytes");return bytes;
}
template<class T> std::vector<T> typed(const c::ReadLease &lease) {
  if(lease.size()%sizeof(T))throw std::runtime_error("actual typed lease extent");
  std::vector<T> values(lease.size()/sizeof(T));
  check(take(lease.view(),"actual typed permission").read(std::as_writable_bytes(std::span(values))),"actual typed result");return values;
}
std::string directory(const char *name) {
#if defined(_WIN32)
  char *value=nullptr;std::size_t bytes=0;
  if(_dupenv_s(&value,&bytes,name))throw std::runtime_error("cannot read original-role directory");
  const std::unique_ptr<char,decltype(&std::free)> owner(value,&std::free);return value?value:"";
#else
  const auto *value=std::getenv(name);return value?value:"";
#endif
}
struct State final {
  c::StateSchema schema;
  c::StateStore store;
  std::array<c::StateEntryId,kResources> entries;
  static State create(const Model &model,const c::StorageOwner &owner,std::size_t output_root_bytes) {
    std::array<c::StateEntrySpec,kResources> specs;
    const auto desc=descriptions(model);std::size_t bytes=0;
    for(std::size_t i=0;i<specs.size();++i) {
      specs[i]={.description=desc[i],.resource=owner.ref()};
      bytes+=(take(desc[i].required_bytes(),"complete draft state bytes")+255u)/256u*256u;
    }
    State s;s.schema=take(c::StateSchema::create(specs),"complete NextN state schema");
    // A state member retains the WHOLE output-pool root, including diagnostic
    // generations. Count it once, plus the six separate initial roots; logical
    // member extents do not measure retained physical backing.
    s.store=take(c::StateStore::create(s.schema,{.max_versions=16,.max_drafts=2,
        .max_retained_blocks=96,.max_backing_bytes=output_root_bytes+bytes}),"bounded ordinary state store");
    for(std::size_t i=0;i<s.entries.size();++i)s.entries[i]=take(s.schema.entry(i),"actual complete state member");
    return s;
  }
  c::ReadLease member(const c::StateVersion &version,std::size_t entry) const {
    return take(version.member(entries.at(entry)),"actual immutable complete-state member");
  }
  std::array<c::ReadLease,kResources> inputs(const c::StateVersion &version) const {
    std::array<c::ReadLease,kResources> values;
    for(std::size_t i=0;i<values.size();++i)values[i]=member(version,i);return values;
  }
  c::StateVersion import(std::span<const c::ReadLease> values) {
    if(values.size()!=kResources)throw std::runtime_error("complete imported NextN member count");
    std::array<c::StateMember,kResources> members;
    for(std::size_t i=0;i<members.size();++i)members[i]={entries[i],values[i]};
    return take(store.import(members),"explicit complete initial boundary");
  }
  c::StateVersion candidate(const c::StateVersion &from,const Recipe &recipe,std::span<const c::ReadLease> result) {
    auto draft=take(store.begin(from),"single complete NextN prefix draft");
    for(std::size_t i=0;i<entries.size();++i)
      check(draft.replace(entries[i],result[recipe.state_ports[i]]),"stage actual matching complete prefix member");
    return take(draft.finalize(),"one complete hidden/KV/pending/position candidate");
  }
};
using Image=std::array<Bytes,kResources>;
Image image(const State &state,const c::StateVersion &version) {
  Image result;for(std::size_t i=0;i<result.size();++i)result[i]=read(state.member(version,i));return result;
}
struct NativeReferenceCount final {
  std::uint32_t submissions=0;
  ~NativeReferenceCount() {
    // Also report work if a numerical ASSERT exits the journey early.
    ::testing::Test::RecordProperty("original_native_reference_submissions",int(submissions));
  }
};
struct Program final {
  Recipe recipe;
  sem::GraphCase logical;
  std::vector<c::ReadLease> parameters;
  g::CompiledGraph compiled;
  g::Invocation invocation;
  c::LeasePool outputs;
  std::size_t output_root_bytes=0;
  std::uint32_t submissions=0;
  static Program create(Recipe recipe,c::Context &context,const c::StorageOwner &owner,bool cuda) {
    Program p;p.recipe=std::move(recipe);p.logical=sem::make_graph(p.recipe.fragment);
    std::vector<g::ConstantBinding> constants;
    for(std::size_t i=0;i<p.logical.constants.size();++i) {
      const auto binding=std::find_if(p.recipe.external.begin(),p.recipe.external.end(),[&](const auto &item){return item.constant==i;});
      if(binding!=p.recipe.external.end()) {
        if(binding->role.description!=p.recipe.fragment.description(p.recipe.fragment.constants[i]))throw std::runtime_error("external role descriptor changed");
        constants.push_back(take(binding->role.binding(p.logical.constants[i]),"original/shared vocabulary owner binding"));
      } else {
        const auto &desc=p.recipe.fragment.description(p.recipe.fragment.constants[i]);
        if(p.recipe.fragment.constant_bytes[i].size()!=take(desc.required_bytes(),"generated constant bytes"))throw std::runtime_error("missing generated constant payload");
        p.parameters.push_back(upload(owner,p.recipe.fragment.constant_bytes[i]));
        constants.push_back({.value=p.logical.constants[i],.tensor=take(p.parameters.back().tensor(desc),"generated immutable parameter"),.owner=owner,.lease=p.parameters.back()});
      }
    }
    const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(*p.recipe.model.profile),"exact selected MAIN artifact"),
        c::WorkloadPhase::kDecode,{0x48594c454d4f444cULL,p.recipe.fragment.region,1}};
    const g::CompileOptions options{.constants=constants,.workload=workload};
    const auto compile=[&]() -> hyle::Result<g::CompiledGraph> {
#if defined(HYLE_TEST_QWEN_STATE_CPU)
      if(!cuda)return g::cpu::compile(p.logical.graph,context,options);
#endif
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
      if(cuda)return g::cuda::compile(p.logical.graph,context,owner,options);
#endif
      throw std::runtime_error("requested NextN backend is not enabled");
    };
    p.compiled=take(compile(),"one ordinary complete NextN Graph");
    // This existing four-case consumer is also the full packed-RHS route
    // regression. Inspect the actual MatMul behind its independent Copy;
    // smaller internal shards cannot satisfy this descriptor or report gate.
    const auto copied_logits=take(p.logical.graph.producer(p.logical.outputs[p.recipe.logits]),"full logits observer");
    if(take(p.logical.graph.operation_kind(copied_logits),"full logits observer kind")!=c::OperationKind::kCopy)
      throw std::runtime_error("full logits observer must own an independent Copy");
    const auto full_logits=take(p.logical.graph.node_input(copied_logits,0),"actual full logits value");
    const auto full_head=take(p.logical.graph.producer(full_logits),"actual full head MatMul");
    const auto full_weight=take(p.logical.graph.node_input(full_head,1),"actual complete packed head");
    const auto wanted_weight=take(c::gguf_weight_description(p.recipe.model.head.quant,c::DataType::kFloat32,
        p.recipe.model.hidden,kVocabulary),"required complete packed head geometry");
    if(take(p.logical.graph.operation_kind(full_head),"full head kind")!=c::OperationKind::kMatMul ||
        take(p.logical.graph.value_description(full_weight),"full head actual weight geometry")!=wanted_weight ||
        take(p.logical.graph.value_description(full_logits),"full head actual logits geometry")!=sem::dense({1,kVocabulary}))
      throw std::runtime_error("complete vocabulary head must be one full-bank MatMul");
    std::size_t selected_head_steps=0;
    for(std::size_t step_index=0;step_index<p.compiled.report.step_count();++step_index) {
      const auto selected=take(p.compiled.report.step(step_index),"full head selected plan step");
      for(std::size_t node_index=0;node_index<selected.node_count;++node_index)
        if(take(p.compiled.report.step_node(step_index,node_index),"full head selected logical node")==full_head) {
          ++selected_head_steps;
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
          if(cuda && selected.provider.id!=c::ggml_cuda::kProviderId)
            throw std::runtime_error("full packed CUDA head must retain the native ggml CUDA route");
#endif
          ::testing::Test::RecordProperty("full_head_provider",std::string(selected.provider.name));
        }
    }
    if(selected_head_steps!=1)throw std::runtime_error("full head must belong to exactly one selected plan step");
    ::testing::Test::RecordProperty("full_head_encoded_bytes",int(take(wanted_weight.required_bytes(),"full head span")));
    p.invocation=take(p.compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"one ordinary NextN Invocation");
    std::size_t bytes=0;
    for(std::size_t i=0;i<p.logical.outputs.size();++i) {
      if(take(p.compiled.executable.output_ownership(i),"actual NextN output ownership")!=g::OutputOwnership::kCaller)throw std::runtime_error("NextN fixture requires independent caller outputs");
      const auto extent=take(p.recipe.fragment.description(p.recipe.fragment.outputs[i]).required_bytes(),"actual NextN output span");
      bytes+=(extent+255u)/256u*256u;
    }
    constexpr std::uint32_t generations=6;
    p.output_root_bytes=bytes*generations;
    p.outputs=take(c::LeasePool::create(owner.ref(),p.output_root_bytes,
        {.max_blocks=std::uint32_t(p.logical.outputs.size()*generations),.backing_alignment=256}),"bounded retained NextN generations");
    // Cold generated bytes have native immutable owners now; references retain
    // only the eight decoded prototype rows, not a second full matrix bank.
    for(auto &payload:p.recipe.fragment.constant_bytes) {Bytes empty;payload.swap(empty);}
    return p;
  }
  std::vector<c::ReadLease> execute(c::Queue &queue,const State &state,const c::StateVersion &from) {
    const auto inputs=state.inputs(from);
    const auto cursor=typed<std::int32_t>(inputs[kCursor]).at(0),position=typed<std::int32_t>(inputs[kPosition]).at(0);
    const auto pending=typed<std::int32_t>(inputs[kPending]).at(0);
    if(cursor<0 || cursor>=kCapacity || position<0 || position==std::numeric_limits<std::int32_t>::max() || pending<0 || pending>=kVocabulary)
      throw std::runtime_error("complete NextN boundary exceeds prepared capacity/position/vocabulary");
    for(std::size_t i=0;i<inputs.size();++i)
      check(invocation.bind(logical.inputs[i],recipe.fragment.description(recipe.fragment.inputs[i]),inputs[i]),"bind actual state lease without host reconstruction");
    for(std::size_t i=0;i<logical.outputs.size();++i) {
      const auto &desc=recipe.fragment.description(recipe.fragment.outputs[i]);
      check(invocation.bind(logical.outputs[i],desc,take(outputs.allocate(take(desc.required_bytes(),"NextN output extent")),"new result generation writer")),"bind actual NextN output");
    }
    const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
    check(invocation.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}),"prepare connected NextN replay");
    {auto done=take(invocation.submit(queues),"complete NextN Graph submit");++submissions;check(done.wait(),"actual NextN retirement");}
    std::vector<c::ReadLease> values;
    for(const auto output:logical.outputs)values.push_back(take(take(invocation.result(output),"successful NextN Graph result").storage_lease(),"independent actual result backing"));
    check(invocation.reset(),"withdraw completed invocation permissions");
    if(invocation.submit(queues))throw std::runtime_error("reset NextN invocation still prepared");
    return values;
  }
};

void quantized(std::span<const float> actual,std::span<const float> expected,const char *label) {
  SCOPED_TRACE(label);ASSERT_EQ(actual.size(),expected.size());
  float peak=0;for(const auto value:expected){ASSERT_TRUE(std::isfinite(value));peak=std::max(peak,std::abs(value));}
  for(const auto value:actual)ASSERT_TRUE(std::isfinite(value));
  if(peak==0){for(const auto value:actual)EXPECT_EQ(value,0.F);return;}
  std::vector<float> a(actual.size()),e(expected.size());
  for(std::size_t i=0;i<a.size();++i){a[i]=actual[i]/peak;e[i]=expected[i]/peak;}
  // Same peak-normalized quantized-chain contract as the original Q27/Q24
  // components and C5 consumers. Strict local F32 operations stay separate.
  d5_gguf_test::expect_quantized_chain_matmul_close(a,e);
}
std::vector<float> attention_reference(const Model &model,std::span<const float> query,
    std::span<const float> key,std::span<const float> value,std::span<const float> gate,int rows) {
  std::vector<float> result(std::size_t(model.heads*kDepth));
  for(std::int64_t head=0;head<model.heads;++head) {
    const auto kv=head/(model.heads/kKvHeads);std::vector<double> logits(std::size_t(rows),0);
    for(int row=0;row<rows;++row)for(std::int64_t d=0;d<kDepth;++d)
      logits[std::size_t(row)]+=double(query[std::size_t(head*kDepth+d)])*key[std::size_t((row*kKvHeads+kv)*kDepth+d)]/16.;
    const auto maximum=*std::max_element(logits.begin(),logits.end());double sum=0;
    for(auto &score:logits)sum+=score=std::exp(score-maximum);
    for(std::int64_t d=0;d<kDepth;++d) {
      double total=0;for(int row=0;row<rows;++row)total+=logits[std::size_t(row)]/sum*value[std::size_t((row*kKvHeads+kv)*kDepth+d)];
      const auto i=std::size_t(head*kDepth+d);result[i]=float(total/(1+std::exp(-double(gate[i]))));
    }
  }
  return result;
}
void observe(const Program &program,const State &state,const c::StateVersion &from,
             std::span<const c::ReadLease> output) {
  const auto &r=program.recipe;const auto &model=r.model;
  const auto get=[&](std::size_t port){return typed<float>(output[port]);};
  const auto cursor=typed<std::int32_t>(state.member(from,kCursor)).at(0),position=typed<std::int32_t>(state.member(from,kPosition)).at(0);
  const auto token=typed<std::int32_t>(state.member(from,kPending)).at(0);
  const auto old_hidden=typed<float>(state.member(from,kHidden)),embedding=get(r.embedding);
  const auto embedding_first=r.embedding_bank->decoded.begin()+std::ptrdiff_t((token%fixture::prototypes)*model.hidden);
  EXPECT_EQ(embedding,std::vector<float>(embedding_first,embedding_first+model.hidden));
  numeric::expect_close(get(r.hn),sem::oracle::rms_norm_rows(old_hidden,r.hidden_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  numeric::expect_close(get(r.en),sem::oracle::rms_norm_rows(embedding,r.embedding_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  auto joined=get(r.en);const auto hn=get(r.hn);joined.insert(joined.end(),hn.begin(),hn.end());EXPECT_EQ(get(r.joined),joined);
  quantized(get(r.eh),r.eh_reference(joined),"actual input boundary -> original/generated EH");
  numeric::expect_close(get(r.nx),sem::oracle::rms_norm_rows(get(r.eh),r.attention_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  const auto nx=get(r.nx);
  quantized(get(r.qg),r.qg_reference(nx),"query/gate projection");
  quantized(get(r.key),r.key_reference(nx),"original/generated K projection");
  quantized(get(r.value),r.value_reference(nx),"original/generated V projection");
  const auto qg=get(r.qg);std::vector<float> query(std::size_t(model.heads*kDepth)),gate(query.size());
  for(std::int64_t head=0;head<model.heads;++head)for(std::int64_t d=0;d<kDepth;++d) {
    const auto out=std::size_t(head*kDepth+d),in=std::size_t(head*2*kDepth+d);query[out]=qg[in];gate[out]=qg[in+std::size_t(kDepth)];
  }
  EXPECT_EQ(get(r.gate),gate);
  query=sem::oracle::rms_norm_rows(query,r.query_scale,kDepth,1e-6F);
  numeric::expect_close(get(r.query),cpu_c5_qwen_attention::rotate(query,position),8e-5F,4e-5F);
  const auto normalized_key=sem::oracle::rms_norm_rows(get(r.key),r.key_scale,kDepth,1e-6F);
  numeric::expect_close(get(r.rotated_key),cpu_c5_qwen_attention::rotate(normalized_key,position),8e-5F,4e-5F);
  for(std::size_t entry=0;entry<2;++entry) {
    auto expected=read(state.member(from,entry));
    const auto fresh=read(output[entry==kKey?r.rotated_key:r.value]);
    const auto row_bytes=std::size_t(kKvHeads*kDepth)*sizeof(float);
    std::copy(fresh.begin(),fresh.end(),expected.begin()+std::ptrdiff_t(std::size_t(cursor)*row_bytes));
    EXPECT_EQ(read(output[r.state_ports[entry]]),expected)<<"complete KV, exact prior rows and NaN tail";
  }
  const auto keys=get(r.state_ports[kKey]),values=get(r.state_ports[kValue]);
  quantized(get(r.attended),attention_reference(model,get(r.query),keys,values,gate,cursor+1),"finite valid-only full-history GQA and q gate");
  quantized(get(r.oproj),r.output_reference(get(r.attended)),"attention output projection");
  auto residual=get(r.eh);const auto out=get(r.oproj);
  for(std::size_t i=0;i<residual.size();++i)residual[i]+=out[i];
  numeric::expect_close(get(r.residual),residual,1e-6F,1e-6F);
  numeric::expect_close(get(r.ffn_input),sem::oracle::rms_norm_rows(get(r.residual),r.ffn_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  quantized(get(r.ffn_output),r.ffn_reference(get(r.ffn_input)),model.moe?"top10 routed plus gated shared MoE":"Q27 dense SwiGLU");
  auto post=get(r.residual);const auto ffn=get(r.ffn_output);for(std::size_t i=0;i<post.size();++i)post[i]+=ffn[i];
  numeric::expect_close(get(r.post_ffn),post,1e-6F,1e-6F);
  const auto hidden=get(r.state_ports[kHidden]);
  numeric::expect_close(hidden,sem::oracle::rms_norm_rows(get(r.post_ffn),r.head_scale,model.hidden,1e-6F),3e-5F,2e-5F);
  EXPECT_EQ(typed<std::int32_t>(output[r.state_ports[kCursor]]),std::vector<std::int32_t>{cursor+1});
  EXPECT_EQ(typed<std::int32_t>(output[r.state_ports[kPosition]]),std::vector<std::int32_t>{position+1});
  // Check every full-bank logit against the same matching-carrier reference,
  // and the actual TopK against the actual full vector. These observations
  // never replace the pending-ID lease consumed by the next Graph.
  float best=-std::numeric_limits<float>::infinity();std::int32_t best_id=-1;
  const auto reference=r.dot_reference?r.dot_reference(*r.head_bank,hidden):r.head_bank->dots(hidden);
  const auto peak=*std::max_element(reference.begin(),reference.end());
  const auto logits=get(r.logits),scores=get(r.head_score);
  ASSERT_EQ(logits.size(),std::size_t(kVocabulary));ASSERT_EQ(scores.size(),1u);
  std::vector<float> expected_logits(logits.size(),0.F);
  for(std::size_t vocabulary_token=0;vocabulary_token<logits.size();++vocabulary_token) {
    ASSERT_TRUE(std::isfinite(logits[vocabulary_token]));
    expected_logits[vocabulary_token]=reference[vocabulary_token%fixture::prototypes];
    if(logits[vocabulary_token]>best) {best=logits[vocabulary_token];best_id=std::int32_t(vocabulary_token);}
  }
  quantized(logits,expected_logits,"matching-carrier full-V generated head logits");
  const std::array<float,1> wanted{peak};
  quantized(scores,wanted,"matching-carrier full-V generated head maximum");
  EXPECT_EQ(scores[0],best);
  EXPECT_EQ(typed<std::int32_t>(output[r.state_ports[kPending]]),std::vector<std::int32_t>{best_id});
  EXPECT_GE(best_id,0);EXPECT_LT(best_id,kVocabulary);
}

c::StateVersion initial(State &state,const Model &model,const c::StorageOwner &owner) {
  std::array<c::ReadLease,kResources> values;
  for(std::size_t entry=0;entry<2;++entry) {
    std::vector<float> cache(std::size_t(kCapacity*kKvHeads*kDepth));
    for(std::size_t i=0;i<cache.size();++i)cache[i]=i<2*std::size_t(kKvHeads*kDepth)
        ?float(int((i*7+entry*13)%31)-15)/32.F:std::bit_cast<float>(std::uint32_t(0x7fc00001u+entry));
    values[entry]=upload(owner,sem::bytes(cache));
  }
  values[kHidden]=upload(owner,sem::bytes(d5_gguf_test::activation(model.hidden,3)));
  values[kPending]=upload(owner,sem::bytes(std::vector<std::int32_t>{3}));
  values[kCursor]=upload(owner,sem::bytes(std::vector<std::int32_t>{2}));
  values[kPosition]=upload(owner,sem::bytes(std::vector<std::int32_t>{37}));
  return state.import(values);
}
void run(const Model &model,std::span<const orig::ReadonlyRole> originals,
    const orig::q27::Data *q27_data,const orig::q24::Data *q24_data,
    c::Context &context,const c::StorageOwner &owner,bool cuda) {
  if(model.moe) {
    ASSERT_EQ(model.profile->artifact_repository,orig::q24::kIdentity.repository);
    ASSERT_EQ(model.profile->artifact_revision,orig::q24::kIdentity.revision);ASSERT_EQ(model.profile->variant,orig::q24::kIdentity.variant);
  } else {
    ASSERT_EQ(model.profile->artifact_repository,orig::q27::kIdentity.repository);
    ASSERT_EQ(model.profile->artifact_revision,orig::q27::kIdentity.revision);ASSERT_EQ(model.profile->variant,orig::q27::kIdentity.variant);
  }
  const auto native_reference_submissions=std::make_shared<NativeReferenceCount>();
  DotReference dot_reference;
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
  if(cuda)dot_reference=[native_reference_submissions](const fixture::Bank &bank,std::span<const float> input) {
    const auto values=cuda_sidecar_quant_reference::catalogue_dots(
        bank.type,bank.k,bank.packed,bank.decoded,input,false);
    if(ggml_is_quantized(bank.type))++native_reference_submissions->submissions;
    return values;
  };
#endif
  auto program=Program::create(build(model,owner,originals,q27_data,q24_data,std::move(dot_reference)),context,owner,cuda);
  auto state=State::create(model,owner,program.output_root_bytes);auto queue=take(context.create_queue(),"one original complete NextN queue");
  {
    const auto base=initial(state,model,owner);
    const auto base_image=image(state,base);
    const auto first_outputs=program.execute(queue,state,base);observe(program,state,base,first_outputs);ASSERT_FALSE(::testing::Test::HasFailure());
    const auto first=state.candidate(base,program.recipe,first_outputs);
    const auto first_image=image(state,first);
    // Real pending ID, normalized hidden, entire KV and absolute position all
    // come from the first Graph. No observer vector is uploaded for step two.
    const auto second_outputs=program.execute(queue,state,first);observe(program,state,first,second_outputs);ASSERT_FALSE(::testing::Test::HasFailure());
    const auto second=state.candidate(first,program.recipe,second_outputs);
    const auto second_image=image(state,second);
    std::array<c::StateHead,3> heads;
    for(auto &head:heads)head=take(c::StateHead::create(state.store,base),"independent actual acceptance head");
    const std::array<c::StateVersion,3> prefixes{base,first,second};
    // Failure after staging a genuine K result cannot publish a mismatched V,
    // hidden, pending token or cursor. Every head still names complete base.
    {
      auto failed=take(state.store.begin(base),"failed whole-prefix draft");
      check(failed.replace(state.entries[kKey],first_outputs[program.recipe.state_ports[kKey]]),"stage genuine K candidate");
      const auto bad=take(first_outputs[program.recipe.state_ports[kValue]].subview(0,sizeof(float)),"genuine wrong-extent V reader");
      EXPECT_TRUE(failed.replace(state.entries[kValue],bad).IsInvalidArgument());
      check(failed.cancel(),"cancel unpublishable complete prefix");
      for(const auto &head:heads)EXPECT_TRUE(take(head.current(),"unchanged complete head").identity()==base.identity());
    }
    // accept0 preserves base exactly, accept1 excludes the second complete
    // generation, accept2 publishes both consumed inputs. This finite selector
    // is explicit; it does not claim original target/natural acceptance.
    for(std::size_t accepted=1;accepted<heads.size();++accepted)
      check(heads[accepted].publish(base.identity(),prefixes[accepted]),"one atomic complete accepted-prefix publication");
    EXPECT_TRUE(heads[1].publish(base.identity(),second).IsUnavailable());
    EXPECT_TRUE(image(state,take(heads[0].current(),"rejected-all head"))==base_image);
    EXPECT_TRUE(image(state,take(heads[1].current(),"accepted1 head"))==first_image);
    EXPECT_TRUE(image(state,take(heads[2].current(),"accepted2 head"))==second_image);
    std::array<c::StateVersion,3> continued;
    std::array<Image,3> continued_images;
    for(std::size_t accepted=0;accepted<heads.size();++accepted) {
      SCOPED_TRACE(accepted);
      const auto from=take(heads[accepted].current(),"ACTUAL accepted head for next step");
      const auto values=program.execute(queue,state,from);observe(program,state,from,values);ASSERT_FALSE(::testing::Test::HasFailure());
      continued[accepted]=state.candidate(from,program.recipe,values);
      check(heads[accepted].publish(from.identity(),continued[accepted]),"publish actual branch continuation");
      continued_images[accepted]=image(state,continued[accepted]);
      EXPECT_TRUE(image(state,base)==base_image);EXPECT_TRUE(image(state,first)==first_image);EXPECT_TRUE(image(state,second)==second_image);
      for(std::size_t i=0;i<=accepted;++i)EXPECT_TRUE(image(state,continued[i])==continued_images[i]);
    }
    // Same immutable plans and actual old heads replay exactly, while the
    // accepted2 branch alone advances its complete cursor/position to5/40.
    EXPECT_TRUE(continued_images[0]==first_image);EXPECT_TRUE(continued_images[1]==second_image);
    EXPECT_EQ(typed<std::int32_t>(state.member(continued[2],kCursor)),std::vector<std::int32_t>{5});
    EXPECT_EQ(typed<std::int32_t>(state.member(continued[2],kPosition)),std::vector<std::int32_t>{40});
    for(const auto &version:{base,first,second,continued[0],continued[1],continued[2]})
      for(std::size_t i=0;i<kResources;++i)EXPECT_FALSE(state.member(version,i).try_write());
  }
  check(state.store.collect(),"retire all complete NextN versions");
  EXPECT_EQ(state.store.stats().versions,0u);EXPECT_EQ(state.store.stats().drafts,0u);
  EXPECT_EQ(program.outputs.stats().live_blocks,0u);EXPECT_EQ(program.outputs.stats().active_uses,0u);
  EXPECT_EQ(program.submissions,5u);
  for(const auto &binding:program.recipe.external) {
    auto reader=binding.role.lease;EXPECT_FALSE(reader.try_write());
  }
  ::testing::Test::RecordProperty("backend",cuda?"ordinary CUDA Graph":"ordinary CPU Graph");
  ::testing::Test::RecordProperty("actual_submissions",int(program.submissions));
  ::testing::Test::RecordProperty("quantized_reference",cuda?
      "existing original-native CUDA integration oracle with matching activation codec; independent original-role F64/decoded and strict F32 local gates retained":
      "unchanged CPU C5 native-codec dots; independent original-role F64/decoded and strict F32 local gates retained");
  ::testing::Test::RecordProperty("complete_draft_resources",6);
  ::testing::Test::RecordProperty("full_vocabulary",int(kVocabulary));
  ::testing::Test::RecordProperty("head_matmuls",1);
  ::testing::Test::RecordProperty("original_role_bytes",model.moe?11535360:43048960);
  ::testing::Test::RecordProperty("scope",model.moe?
      "Q24 MAIN UD-IQ4_XS original blk92 K/V/knorm inside complete generated-parameter MoE NextN; generated8-resident expert mapping,shared embedding/head; actual pending/hidden/fullKV/cursor/position prefix0/1/2 and eachhead continuation; no original512-expert target or natural acceptance claim":
      "Q27 MAIN UD-Q4_K_M original blk64 EH/enorm/hnorm inside complete generated-parameter dense NextN; generated embedding and distinct-codec fullVhead; actual pending/hidden/fullKV/cursor/position prefix0/1/2 and eachhead continuation; no complete64-layer target or natural acceptance claim");
}

class QwenMtpStateConsumer:public ::testing::Test {
protected:
  static inline std::unique_ptr<const orig::q27::Data> data27;
  static inline std::unique_ptr<const orig::q24::Data> data24;
  static void SetUpTestSuite() {
    const auto path27=directory("HYLE_QWEN27_MTP_INPUT_DIR"),path24=directory("HYLE_QWEN24_MTP_KV_DIR");
    if(!path27.empty())data27=std::make_unique<const orig::q27::Data>(orig::q27::Data::load(path27));
    if(!path24.empty())data24=std::make_unique<const orig::q24::Data>(orig::q24::Data::load(path24));
  }
  static void TearDownTestSuite(){data27.reset();data24.reset();}
};
#if defined(HYLE_TEST_QWEN_STATE_CPU)
struct SystemResource final {m::MemoryResourceRef ref() noexcept{return m::system_resource();}};
TEST_F(QwenMtpStateConsumer,CpuQ27WholeNextNPrefixPublishesAndContinues) {
  if(!data27)GTEST_SKIP()<<"Set HYLE_QWEN27_MTP_INPUT_DIR to authenticated MAIN Q27 roles";
  auto context=take(g::cpu::create_context(),"ordinary CPU context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"ordinary CPU storage owner");
  const auto roles=orig::q27::bind(*data27,owner);run(q27,roles,data27.get(),nullptr,context,owner,false);
}
TEST_F(QwenMtpStateConsumer,CpuQ24WholeNextNPrefixPublishesAndContinues) {
  if(!data24)GTEST_SKIP()<<"Set HYLE_QWEN24_MTP_KV_DIR to authenticated MAIN Q24 roles";
  auto context=take(g::cpu::create_context(),"ordinary CPU context");
  const auto owner=take(c::StorageOwner::adopt(context,SystemResource{}),"ordinary CPU storage owner");
  const auto roles=orig::q24::bind(*data24,owner);run(q24,roles,nullptr,data24.get(),context,owner,false);
}
#endif
#if defined(HYLE_TEST_QWEN_STATE_CUDA)
TEST_F(QwenMtpStateConsumer,CudaQ27WholeNextNPrefixPublishesAndContinues) {
  if(!data27)GTEST_SKIP()<<"Set HYLE_QWEN27_MTP_INPUT_DIR to authenticated MAIN Q27 roles";
  auto context=take(g::cuda::create_context(),"ordinary CUDA context");
  const auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"actual CUDA memory")),"ordinary CUDA storage owner");
  const auto roles=orig::q27::bind(*data27,owner);run(q27,roles,data27.get(),nullptr,context,owner,true);
}
TEST_F(QwenMtpStateConsumer,CudaQ24WholeNextNPrefixPublishesAndContinues) {
  if(!data24)GTEST_SKIP()<<"Set HYLE_QWEN24_MTP_KV_DIR to authenticated MAIN Q24 roles";
  auto context=take(g::cuda::create_context(),"ordinary CUDA context");
  const auto owner=take(c::StorageOwner::adopt(context,take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"actual CUDA memory")),"ordinary CUDA storage owner");
  const auto roles=orig::q24::bind(*data24,owner);run(q24,roles,nullptr,data24.get(),context,owner,true);
}
#endif
} // namespace
