"""Focused packed single-row CUDA MatMul and full-vocabulary MTP consumers."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BG = R / '.scratch/qwen-mtp-state-20261023'
spec = importlib.util.spec_from_file_location('bh_cached', BG / 'build.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
b, c, h = g.b, g.c, g.h
g.S = h.S = S
BASE = BG / 'tests-link5'
RECIPES = {
    'tensor-program': R / '.scratch/glm-mtp-seed-cache-20261022/compile7/tensor-program/identity.json',
    'qwen-state': BG / 'compile5/qwen-state/identity.json',
    'bounds': BG / 'compile5/qwen-state/identity.json',
}
SOURCES = {
    'tensor-program': R / 'src/compute_provider_ggml_cuda/tensor_program.cc',
    'qwen-state': R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc',
    'bounds': R / 'tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc',
}


def host(tag, attempt):
    h.RECIPES[tag] = RECIPES[tag]
    h.SOURCES[tag] = SOURCES[tag]
    h.compile_one(tag, attempt)


def link(attempt):
    base_path = BASE / 'link-plan.json'
    base = c.read(base_path)
    remove, records, replacement = set(), [], {}
    for row in base['compiled_records']:
        rec = c.read(row['path'])
        if '/tests/' in rec['source']['path'].replace('\\', '/'):
            remove.add(c.key(rec['object']['path']))
        elif c.key(rec['source']['path']) == c.key(str(SOURCES['tensor-program'])):
            replacement[c.key(rec['object']['path'])] = g.latest('tensor-program')[1]['object']
        else:
            records.append(row)
    assert len(replacement) == 1
    product = g.latest('tensor-program')
    added = [g.latest(tag) for tag in ('qwen-state', 'bounds')]
    for key in replacement:
        assert sum(c.key(x['path']) == key for x in base['inputs']) == 1
    inputs = [rec['object'] for _, rec in added] + [
        replacement.get(c.key(x['path']), x) for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [replacement.get(c.key(x), {}).get('path', x) for x in base['command']
        if c.key(x) not in remove and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [rec['object']['path'] for _, rec in added]
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'packed-head-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(p) for p, _ in (*added, product)] + records,
        base=b.identity(base_path), SDK_builds=0, native_CPU_builds=0,
        NVCC_builds=0, shaders=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path']) == dll
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image)))
    print('LINKED full packed-head checks', flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('actions', nargs='+', choices=[*SOURCES, 'link', 'run'])
    p.add_argument('--attempt', type=int, default=1)
    p.add_argument('--link-attempt', type=int, default=1)
    p.add_argument('--filter', default='*')
    p.add_argument('--expected-tests', type=int, default=1)
    args = p.parse_args()
    for action in args.actions:
        if action == 'link': link(args.attempt)
        elif action == 'run': g.run(args.link_attempt, args.attempt, args.filter, args.expected_tests)
        else: host(action, args.attempt)
