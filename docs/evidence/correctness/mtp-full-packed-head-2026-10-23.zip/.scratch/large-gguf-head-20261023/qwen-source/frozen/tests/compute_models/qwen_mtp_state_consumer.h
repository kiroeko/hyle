#pragma once

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <numeric>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "cpu_c5_qwen_nextn.h"
#include "qwen_original_mtp_roles.h"

// Test-only ordinary-Graph construction. The target trunk remains an explicit
// external boundary; this is the complete one-block draft continuation state.
namespace qwen_mtp_state_consumer {
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace core=d5_moe_semantic_fragments;
namespace ds=d5_deepseek_official_attention;
namespace nextn=cpu_c5_qwen_nextn;
namespace orig=qwen_original_mtp_roles;
namespace fixture=cpu_c5_gguf_fixture;
using Value=sem::ValueId;
using Bytes=std::vector<std::byte>;
using Reference=std::function<std::vector<float>(std::span<const float>)>;
using DotReference=std::function<std::array<float,fixture::prototypes>(
    const fixture::Bank &,std::span<const float>)>;
inline constexpr std::int64_t kCapacity=6,kDepth=256,kKvHeads=4,kVocabulary=248320,kUploadRows=4096;
enum Entry:std::size_t {kKey,kValue,kHidden,kPending,kCursor,kPosition,kResources};

template<class T> T take(hyle::Result<T> result,std::string_view where) {
  if(!result) throw std::runtime_error(std::string(where)+": "+std::string(result.error().message()));
  return std::move(*result);
}
inline void check(hyle::Status status,std::string_view where) {
  if(!status.ok()) throw std::runtime_error(std::string(where)+": "+std::string(status.message()));
}
inline c::ReadLease upload(const c::StorageOwner &owner,std::span<const std::byte> bytes) {
  auto storage=take(m::Buffer::create(owner.ref(),bytes.size(),256),"explicit initial/constant storage");
  check(storage.view().write(bytes),"explicit initial/constant upload");
  return take(owner.adopt_buffer(std::move(storage)),"actual readonly storage permission");
}
struct Model final {
  const c::ModelArtifactProfileDescription *profile;
  std::int64_t hidden,heads,intermediate;
  bool moe;
  nextn::Codec embedding,head,attention,kv,eh,ffn;
};
inline const Model q27{&d5_qwen38_gdn_fixture::kPrimaryGgufProfile,5120,24,17408,false,
    {c::GgufQuantizedType::kQ4K,GGML_TYPE_Q4_K},
    {c::GgufQuantizedType::kQ6K,GGML_TYPE_Q6_K},
    {c::GgufQuantizedType::kQ6K,GGML_TYPE_Q6_K},
    {c::GgufQuantizedType::kQ8_0,GGML_TYPE_Q8_0},
    {c::GgufQuantizedType::kQ6K,GGML_TYPE_Q6_K},
    {c::GgufQuantizedType::kQ6K,GGML_TYPE_Q6_K}};
inline const Model q24{&d5_qwen_gguf_vocabulary_cases::k24TPrimaryProfile,8192,64,2048,true,
    nextn::profiles[0].vocabulary,nextn::profiles[0].vocabulary,
    nextn::profiles[0].attention,nextn::profiles[0].attention,
    {c::GgufQuantizedType::kQ8_0,GGML_TYPE_Q8_0},nextn::profiles[0].routed_experts};
inline std::array<c::TensorDesc,kResources> descriptions(const Model &model) {
  const auto scalar=sem::dense({1},c::DataType::kInt32);
  return {sem::dense({kCapacity,kKvHeads,kDepth}),sem::dense({kCapacity,kKvHeads,kDepth}),
      sem::dense({1,model.hidden}),scalar,scalar,scalar};
}
inline Value increment(sem::Fragment &f,Value old) {
  const auto one=f.constant(sem::dense({1},c::DataType::kInt32),sem::bytes(std::vector<std::int32_t>{1}));
  const auto pair=f.one(c::Operation(c::Concat{.axis=0}),{old,one});
  const auto sums=f.one(c::Operation(c::Scan{.axis=0}),{pair});
  return f.one(c::Operation(c::Gather{}),{sums,one});
}
// Exactly the existing generated C5 row bank, uploaded once in bounded chunks.
// One full MatMul borrows that bank; Gather uses the same bank when
// the generated embedding/head codecs and bytes coincide. Original roles are
// separately authenticated and never acquire this generated provenance.
struct Vocabulary final {
  std::shared_ptr<const fixture::Bank> bank;
  nextn::Codec codec;
  c::ReadLease lease;
  c::StorageOwner owner;
};
inline Vocabulary vocabulary(const Model &model,nextn::Codec codec,const c::StorageOwner &owner) {
  const cpu_c5_inputs::Case spec{"NextNVocabulary",cpu_c5_inputs::Kind::kEmbedding,
      codec.native,codec.quant,true,model.hidden,kVocabulary,1,0,0};
  auto bank=std::make_shared<const fixture::Bank>(spec);
  const auto desc=take(c::gguf_weight_description(codec.quant,c::DataType::kFloat32,
      model.hidden,kVocabulary),"complete generated vocabulary extent");
  auto storage=take(m::Buffer::create(owner.ref(),take(desc.required_bytes(),"vocabulary bytes"),256),"one cold vocabulary backing");
  for(std::int64_t first=0;first<kVocabulary;first+=kUploadRows) {
    const auto rows=std::min(kUploadRows,kVocabulary-first);
    const auto payload=bank->rows(rows,first);
    check(storage.write(std::size_t(first)*bank->stride,payload),"bounded cold vocabulary shard");
  }
  return {std::move(bank),codec,take(owner.adopt_buffer(std::move(storage)),"shared immutable vocabulary"),owner};
}
struct External final {std::size_t constant;orig::ReadonlyRole role;};
struct Recipe final {
  Model model;
  sem::Fragment fragment;
  std::array<std::size_t,kResources> state_ports{};
  std::vector<External> external;
  std::size_t embedding,hn,en,joined,eh,nx,qg,key,value,query,gate,rotated_key,attended,oproj,residual,ffn_input,ffn_output,post_ffn;
  std::size_t logits,head_score;
  std::vector<float> hidden_scale,embedding_scale,attention_scale,ffn_scale,head_scale,query_scale,key_scale;
  Reference eh_reference,qg_reference,key_reference,value_reference,output_reference,ffn_reference;
  DotReference dot_reference;
  std::shared_ptr<const fixture::Bank> embedding_bank,head_bank;
};
inline std::size_t expose(Recipe &r,Value value) {
  // Diagnostics can be slices/aliases; retained generations need their own
  // caller backing, not an attempted external binding of a required View.
  value=r.fragment.one(c::Operation(c::Copy{}),{value});
  const auto port=r.fragment.outputs.size();r.fragment.outputs.push_back(value);return port;
}
inline Value external(Recipe &r,const orig::ReadonlyRole &role) {
  const auto slot=r.fragment.constants.size();
  const auto value=r.fragment.constant(role.description,{});
  r.external.push_back({slot,role});return value;
}
inline Value parameter(Recipe &r,std::span<const float> values) {
  return r.fragment.constant(sem::dense({std::int64_t(values.size())}),sem::bytes<float>(values));
}
inline std::pair<Value,Reference> projection(Recipe &r,Value input,std::int64_t n,
    std::int64_t k,nextn::Codec codec,bool packed=true) {
  auto p=std::make_shared<const nextn::Linear>(r.fragment,input,n,k,codec.quant,codec.native,packed);
  return {p->output,[p,dots=r.dot_reference](auto values) {
    if(!dots)return p->reference(values);
    const auto dot=dots(p->bank,values);std::vector<float> result(std::size_t(p->spec.n));
    for(std::int64_t row=0;row<p->spec.n;++row)result[std::size_t(row)]=dot[std::size_t(row%fixture::prototypes)];
    return result;
  }};
}
inline std::vector<float> grouped_reference(const nextn::Grouped &p,
    std::span<const float> input,std::span<const std::int32_t> ids,const DotReference &dots) {
  if(!dots)return p.reference(input,ids);
  std::vector<float> result(std::size_t(std::int64_t(ids.size())*p.spec.n));
  for(std::size_t slot=0;slot<ids.size();++slot) {
    const auto dot=dots(p.bank,input.subspan(slot*std::size_t(p.spec.k),std::size_t(p.spec.k)));
    for(std::int64_t row=0;row<p.spec.n;++row)
      result[slot*std::size_t(p.spec.n)+std::size_t(row)]=dot[std::size_t((row+ids[slot])%fixture::prototypes)];
  }
  return result;
}
inline Value norm(Recipe &r,Value input,std::span<const float> scale) {
  return r.fragment.one(c::Operation(c::RmsNorm{.epsilon=1e-6F}),{input,parameter(r,scale)});
}
inline std::pair<Value,Reference> dense_ffn(Recipe &r,Value input) {
  auto [gate,gr]=projection(r,input,r.model.intermediate,r.model.hidden,r.model.ffn);
  auto [up,ur]=projection(r,input,r.model.intermediate,r.model.hidden,r.model.ffn);
  const auto activation=r.fragment.one(c::Operation(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate}),{gate,up});
  auto [down,dr]=projection(r,activation,r.model.hidden,r.model.intermediate,r.model.ffn);
  return {down,[gr=std::move(gr),ur=std::move(ur),dr=std::move(dr)](auto x){return dr(nextn::gated(gr(x),ur(x)));}};
}
inline std::pair<Value,Reference> moe_ffn(Recipe &r,Value input) {
  auto &f=r.fragment;
  auto [router,rr]=projection(r,input,nextn::experts,r.model.hidden,
      {c::GgufQuantizedType::kQ8_0,GGML_TYPE_F32},false);
  const auto probability=f.one(c::Operation(c::Softmax{}),{router});
  const auto top=f.append(c::Operation(c::TopK{.count=std::size_t(nextn::selected)}),{probability},2);
  const auto total=d5_moe_execution_fragments::sum(f,top[0],-1);
  const auto weights=core::binary(f,c::BinaryKind::kDivide,top[0],total);
  std::vector<std::int32_t> mapping(nextn::experts);
  for(std::int64_t i=0;i<nextn::experts;++i) mapping[std::size_t(i)]=std::int32_t(i%nextn::resident);
  const auto ids=f.one(c::Operation(c::Gather{}),{f.constant(sem::dense({nextn::experts},c::DataType::kInt32),sem::bytes(mapping)),top[1]});
  const auto repeated=f.constant(sem::dense({nextn::selected},c::DataType::kInt32),sem::bytes(std::vector<std::int32_t>(nextn::selected)));
  const auto slots=core::reshape(f,f.one(c::Operation(c::Gather{}),{input,repeated}),{1,nextn::selected,r.model.hidden});
  const auto make=[&](Value x,std::int64_t n,std::int64_t k) {
    return std::make_shared<const nextn::Grouped>(f,x,ids,n,k,r.model.ffn.quant,r.model.ffn.native);
  };
  const auto eg=make(slots,r.model.intermediate,r.model.hidden),eu=make(slots,r.model.intermediate,r.model.hidden);
  const auto activation=f.one(c::Operation(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate}),{eg->output,eu->output});
  const auto ed=make(activation,r.model.hidden,r.model.intermediate);
  const auto weighted=core::binary(f,c::BinaryKind::kMultiply,ed->output,core::reshape(f,weights,{1,nextn::selected,1}));
  const auto combined=core::reshape(f,d5_moe_execution_fragments::sum(f,weighted,1),{1,r.model.hidden});
  auto [sg,sgr]=projection(r,input,r.model.intermediate,r.model.hidden,r.model.attention);
  auto [su,sur]=projection(r,input,r.model.intermediate,r.model.hidden,r.model.attention);
  const auto shared_activation=f.one(c::Operation(c::GatedActivation{.inputs=c::GatedInputKind::kSeparate}),{sg,su});
  auto [sd,sdr]=projection(r,shared_activation,r.model.hidden,r.model.intermediate,nextn::profiles[0].shared_down);
  auto [shared_gate,gate_ref]=projection(r,input,1,r.model.hidden,{c::GgufQuantizedType::kQ8_0,GGML_TYPE_F32},false);
  const auto shared=core::binary(f,c::BinaryKind::kMultiply,sd,core::unary(f,c::UnaryKind::kSigmoid,shared_gate));
  const auto output=core::binary(f,c::BinaryKind::kAdd,combined,shared);
  const auto hidden=r.model.hidden;
  return {output,[rr=std::move(rr),eg,eu,ed,sgr=std::move(sgr),sur=std::move(sur),sdr=std::move(sdr),gate_ref=std::move(gate_ref),hidden,dots=r.dot_reference](auto x) {
    const auto ref_logits=rr(x);std::vector<std::int32_t> order(nextn::experts);std::iota(order.begin(),order.end(),0);
    std::stable_sort(order.begin(),order.end(),[&](auto a,auto b){return ref_logits[std::size_t(a)]>ref_logits[std::size_t(b)];});
    std::vector<std::int32_t> local_experts(nextn::selected);std::vector<double> selected_probability(nextn::selected);double normalizer=0;
    for(std::int64_t s=0;s<nextn::selected;++s) {local_experts[std::size_t(s)]=order[std::size_t(s)]%nextn::resident;normalizer+=selected_probability[std::size_t(s)]=std::exp(double(ref_logits[std::size_t(order[std::size_t(s)])])-ref_logits[std::size_t(order[0])]);}
    std::vector<float> replicated;for(std::int64_t s=0;s<nextn::selected;++s)replicated.insert(replicated.end(),x.begin(),x.end());
    const auto routed=grouped_reference(*ed,nextn::gated(
        grouped_reference(*eg,replicated,local_experts,dots),
        grouped_reference(*eu,replicated,local_experts,dots)),local_experts,dots);
    const auto shared_values=sdr(nextn::gated(sgr(x),sur(x)));const auto shared_coefficient=1.0/(1+std::exp(-double(gate_ref(x)[0])));
    std::vector<float> result(std::size_t(hidden),0);
    for(std::int64_t d=0;d<hidden;++d) {double routed_total=0;for(std::int64_t s=0;s<nextn::selected;++s)routed_total+=routed[std::size_t(s*hidden+d)]*selected_probability[std::size_t(s)]/normalizer;result[std::size_t(d)]=float(routed_total+shared_values[std::size_t(d)]*shared_coefficient);}
    return result;
  }};
}
inline Value append_head(Recipe &r,Value hidden,const Vocabulary &vocabulary) {
  auto &f=r.fragment;
  const auto desc=take(c::gguf_weight_description(vocabulary.codec.quant,c::DataType::kFloat32,
      r.model.hidden,kVocabulary),"one complete packed vocabulary head");
  const auto weight=external(r,{"generated full-V head",desc,vocabulary.owner,vocabulary.lease});
  const auto logits=f.one(c::Operation(c::MatMul{}),{hidden,weight});
  r.logits=expose(r,logits);
  const auto winner=f.append(c::Operation(c::TopK{.count=1,.stable=true}),{logits},2);
  r.head_score=expose(r,winner[0]);
  // The index already names the full logical vocabulary. Keep the actual
  // TopK result as pending[1], without shard tables or another selection.
  return core::reshape(f,winner[1],{1});
}
inline Recipe build(const Model &model,const c::StorageOwner &owner,
    std::span<const orig::ReadonlyRole> originals,const orig::q27::Data *q27_data,
    const orig::q24::Data *q24_data,DotReference dot_reference={}) {
  if((model.moe && (!q24_data || originals.size()!=4)) ||
     (!model.moe && (!q27_data || originals.size()!=3)))throw std::runtime_error("exact model original-role supply");
  Recipe r{.model=model,.fragment={.profile=model.profile,.region=model.moe?0x5132345354415445ULL:0x5132375354415445ULL,.quantized=true}};
  r.dot_reference=std::move(dot_reference);
  auto &f=r.fragment;
  std::array<Value,kResources> state;
  const auto desc=descriptions(model);for(std::size_t i=0;i<state.size();++i)state[i]=f.input(desc[i]);
  auto embedding_vocabulary=vocabulary(model,model.embedding,owner);
  auto head_vocabulary=model.head.quant==model.embedding.quant?embedding_vocabulary:vocabulary(model,model.head,owner);
  r.embedding_bank=embedding_vocabulary.bank;r.head_bank=head_vocabulary.bank;
  auto embedding_desc=take(c::gguf_weight_description(model.embedding.quant,c::DataType::kFloat32,model.hidden,kVocabulary),"complete embedding bank");
  embedding_desc=take(embedding_desc.transposed(),"Gather physical vocabulary orientation");
  const auto embedding_table=external(r,{"generated shared embedding",embedding_desc,owner,embedding_vocabulary.lease});
  const auto embedding=f.one(c::Operation(c::Gather{}),{embedding_table,state[kPending]});r.embedding=expose(r,embedding);
  r.hidden_scale=sem::oracle::scale(model.hidden);r.embedding_scale=r.hidden_scale;std::reverse(r.embedding_scale.begin(),r.embedding_scale.end());
  r.attention_scale=r.hidden_scale;std::rotate(r.attention_scale.begin(),r.attention_scale.begin()+3,r.attention_scale.end());
  r.ffn_scale=r.hidden_scale;std::rotate(r.ffn_scale.begin(),r.ffn_scale.begin()+5,r.ffn_scale.end());
  r.head_scale=r.hidden_scale;std::rotate(r.head_scale.begin(),r.head_scale.begin()+7,r.head_scale.end());
  Value hs,es;
  if(model.moe) {hs=parameter(r,r.hidden_scale);es=parameter(r,r.embedding_scale);}
  else {r.hidden_scale=q27_data->hidden_norm;r.embedding_scale=q27_data->embedding_norm;hs=external(r,originals[orig::q27::kHiddenNorm]);es=external(r,originals[orig::q27::kEmbeddingNorm]);}
  const auto input=nextn::append_input(f,state[kHidden],embedding,hs,es);
  r.hn=expose(r,input.hidden);r.en=expose(r,input.embedding);r.joined=expose(r,input.joined);
  Value eh;
  if(model.moe) {auto p=projection(r,input.joined,model.hidden,2*model.hidden,model.eh);eh=p.first;r.eh_reference=std::move(p.second);}
  else {eh=f.one(c::Operation(c::MatMul{}),{input.joined,external(r,originals[orig::q27::kProjection])});r.eh_reference=[q27_data](auto x){return orig::q27::project(q27_data->projection,x,x).local;};}
  r.eh=expose(r,eh);const auto nx=norm(r,eh,r.attention_scale);r.nx=expose(r,nx);
  auto qg=projection(r,nx,2*model.heads*kDepth,model.hidden,model.attention);r.qg=expose(r,qg.first);r.qg_reference=std::move(qg.second);
  Value key,value,ks,frequency;
  r.query_scale=sem::oracle::scale(kDepth);r.key_scale=r.query_scale;std::reverse(r.key_scale.begin(),r.key_scale.end());
  if(model.moe) {
    key=f.one(c::Operation(c::MatMul{}),{nx,external(r,originals[orig::q24::kKey])});
    value=f.one(c::Operation(c::MatMul{}),{nx,external(r,originals[orig::q24::kValue])});
    ks=external(r,originals[orig::q24::kNorm]);frequency=external(r,originals[orig::q24::kFrequency]);r.key_scale=q24_data->norm;
    r.key_reference=[q24_data](auto x){return orig::q24::project(q24_data->key,x,1);};
    r.value_reference=[q24_data](auto x){return orig::q24::project(q24_data->value,x,1);};
  } else {
    auto k=projection(r,nx,kKvHeads*kDepth,model.hidden,model.kv),v=projection(r,nx,kKvHeads*kDepth,model.hidden,model.kv);
    key=k.first;value=v.first;r.key_reference=std::move(k.second);r.value_reference=std::move(v.second);
    ks=parameter(r,r.key_scale);frequency=parameter(r,orig::q24::frequencies());
  }
  r.key=expose(r,key);r.value=expose(r,value);
  const auto projected=nextn::append_qkv(f,qg.first,key,value,parameter(r,r.query_scale),ks,state[kPosition],frequency,model.heads,kKvHeads);
  r.query=expose(r,projected.query);r.gate=expose(r,projected.gate);r.rotated_key=expose(r,projected.key);
  const auto new_key=f.one(c::Operation(c::Scatter{}),{state[kKey],state[kCursor],core::reshape(f,projected.key,{1,kKvHeads,kDepth})});
  const auto new_value=f.one(c::Operation(c::Scatter{}),{state[kValue],state[kCursor],core::reshape(f,projected.value,{1,kKvHeads,kDepth})});
  r.state_ports[kKey]=expose(r,new_key);r.state_ports[kValue]=expose(r,new_value);
  std::vector<std::int32_t> mapping(std::size_t(kCapacity*kCapacity));
  std::vector<float> masks(mapping.size());
  for(std::int64_t cursor=0;cursor<kCapacity;++cursor)for(std::int64_t row=0;row<kCapacity;++row) {
    const auto i=std::size_t(cursor*kCapacity+row);mapping[i]=std::int32_t(row<=cursor?row:0);
    masks[i]=row<=cursor?0.F:-std::numeric_limits<float>::infinity();
  }
  const auto row_table=f.constant(sem::dense({kCapacity,kCapacity},c::DataType::kInt32),sem::bytes(mapping));
  const auto mask_table=f.constant(sem::dense({kCapacity,kCapacity}),sem::bytes(masks));
  const auto rows=f.one(c::Operation(c::Gather{}),{row_table,state[kCursor]});
  const auto mask=core::reshape(f,f.one(c::Operation(c::Gather{}),{mask_table,state[kCursor]}),{1,1,1,kCapacity});
  // NaN tails are never operands: first gather only real valid rows, then mask
  // repeated row0 padding. Merely multiplying a NaN value by zero is invalid.
  const auto keys=f.one(c::Operation(c::Gather{}),{new_key,rows});
  const auto values=f.one(c::Operation(c::Gather{}),{new_value,rows});
  const auto attended=nextn::append_attention(f,projected,keys,values,mask);r.attended=expose(r,attended);
  auto out=projection(r,core::reshape(f,attended,{1,model.heads*kDepth}),model.hidden,model.heads*kDepth,model.attention);
  r.oproj=expose(r,out.first);r.output_reference=std::move(out.second);
  const auto residual=core::binary(f,c::BinaryKind::kAdd,eh,out.first);r.residual=expose(r,residual);
  const auto ffn_input=norm(r,residual,r.ffn_scale);r.ffn_input=expose(r,ffn_input);
  auto tail=model.moe?moe_ffn(r,ffn_input):dense_ffn(r,ffn_input);
  r.ffn_output=expose(r,tail.first);r.ffn_reference=std::move(tail.second);
  const auto post_ffn=core::binary(f,c::BinaryKind::kAdd,residual,tail.first);r.post_ffn=expose(r,post_ffn);
  const auto hidden=norm(r,post_ffn,r.head_scale);r.state_ports[kHidden]=expose(r,hidden);
  const auto pending=append_head(r,hidden,head_vocabulary);r.state_ports[kPending]=expose(r,pending);
  r.state_ports[kCursor]=expose(r,increment(f,state[kCursor]));r.state_ports[kPosition]=expose(r,increment(f,state[kPosition]));
  return r;
}
} // namespace qwen_mtp_state_consumer
