"""Publish the scoped BH implementation and actual native observations."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    path = Path(path)
    return dict(path=str(path.relative_to(R)), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


summary = read(S / 'checks1/summary.json')
tree = ET.parse(S / 'checks1/results.xml').getroot()
assert summary['process']['exit'] == 0 and not summary['process']['timed_out']
assert int(tree.attrib['tests']) == 7 and int(tree.attrib['failures']) == 0
assert int(tree.attrib['errors']) == 0 and summary['skips'] == summary['disabled'] == 0
cases = summary['cases']
assert len(cases) == len({(x['attributes']['classname'], x['attributes']['name']) for x in cases}) == 7
graphs = references = 0
for case in cases:
    props = case['properties']
    if case['attributes']['classname'] == 'QwenMtpStateConsumer':
        assert props['full_vocabulary'] == '248320'
        assert props['head_matmuls'] == '1' and props['complete_draft_resources'] == '6'
        assert props['actual_submissions'] == '5'
        wanted_provider = 'ggml-cuda' if case['attributes']['name'].startswith('Cuda') else 'ggml-cpu'
        assert props['full_head_provider'] == wanted_provider
        graphs += int(props['actual_submissions'])
        references += int(props['original_native_reference_submissions'])
assert graphs == 20 and references == 225

sources = [R / p for p in (
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'tests/compute_provider_ggml_cuda/packed_matmul_bounds_test.cc',
    'tests/compute_provider_ggml_cuda/CMakeLists.txt',
    'tests/compute_models/qwen_mtp_state_consumer.h',
    'tests/compute_models/qwen_mtp_state_consumer_test.cc',
    'docs/developer/current-work.md',
    'docs/implementation/model-operators.md')]
for tag in ('bounds', 'qwen-state', 'tensor-program'):
    candidates = sorted(S.glob(f'compile*/{tag}/identity.json'),
                        key=lambda p: int(p.parents[1].name[7:]))
    record = read(candidates[-1])
    path = Path(record['source']['path'])
    assert identity(path)['sha256'] == record['source']['sha256']
    assert identity(Path(record['object']['path']))['sha256'] == record['object']['sha256']

work = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
tail = work[work.index('## 最新完整性能对比'):]
tail_hash = hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash == read(S / 'start.json')['performance_tail_utf8_sha256']
start = read(S / 'start.json')
start.pop('previous_goal_turn', None)
(S / 'start.json').write_text(json.dumps(start, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

paths = set(sources)
paths.update(p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in (
    '.h', '.cc', '.cu', '.py', '.json', '.txt', '.diff', '.log', '.xml', '.ps1'))
paths.discard(S / 'publication.json')
archive = D / 'mtp-full-packed-head-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for path in sorted(paths):
        z.write(path, path.relative_to(R).as_posix())

record = dict(
    date='2026-10-23', stage='BH', goal_complete=False,
    conclusion='Canonical packed one-row CUDA MatMul no longer inherits the full-F32 weight scratch cap; Q27/Q24 use one complete head instead of61 subheads through the ordinary Graph/Provider route.',
    implementation=dict(
        product='One private input1 admission predicate in tensor_program.cc. Canonical native GGUF logicalF32 rank2/blockaxis0 RHS, F32 dense M1 activation/output, F32 accumulation, K%512==0, logical and block product<=INT32_MAX-1024, encoded bytes/strides<=INT32_MAX. Generic representable(), ordinary activation/output checks, inference, lowering and final original-native supports checks stay unchanged.',
        no_full_weight_decode='The locked native M1 quantized path selects MMVQ. K%512 avoids extra native padding/clear; F32 activation/output avoids dtype cuBLAS fallback. The existing readonly packed allocation remains external; no full F32 weight shadow, bank copy, new executor, public option or ABI is introduced.',
        consumers='Same full248320-row Vocabulary owner/ReadLease -> one MatMul -> stable TopK1 -> actual global pendingID. Full logits/score diagnostics have independent caller outputs; every row is checked against the same matching-carrier prototype oracle, actual TopK is additionally compared exactly to the actual full vector and smallest tied ID. Six-state protocol and five submits remain unchanged.'),
    exact_geometry=[dict(model='Q27 MAIN UD-Q4_K_M generated head', codec='Q6_K', K=5120, V=248320,
                         logical_elements=1271398400, encoded_bytes=1042944000, logits_F32_bytes=993280),
                    dict(model='Q24 MAIN UD-IQ4_XS generated head', codec='Q4_K', K=8192, V=248320,
                         logical_elements=2034237440, encoded_bytes=1144258560, logits_F32_bytes=993280)],
    validation=dict(unique_tests=7, failures=0, errors=0, skips=0,
        model_graph_submissions=graphs, extra_original_native_CUDA_reference_submissions=references,
        reference_scope='The225 raw original-native CUDA calls validate generated quantized carrier integration, not independent numerical kernels and not extra consumer Graph submissions. Independent original-role decoded/F64 and local F32 checks are unchanged.',
        selected_cases=cases,
        descriptor_checks='3 public prepare cases cover actual fullQ27/Q24 without payload allocation; reject large M2, BF16, K padding, noncanonical row strides, logical overflow, encoded byte overflow, oversized activation and plainF32 bank; retain ordinary small packed M2.',
        execution_checks='Four CPU/CUDA complete NextN journeys: all fullV scores, stable actual Top1, prefix0/1/2 whole-state publication/continuation, old results, readonly bank/state leases, NaN-safe futureKV and retirement. Actual compile report verifies full head geometry and original ggml CUDA provider on CUDA.',
        native_run=identity(S / 'checks1/summary.json'), results=identity(S / 'checks1/results.xml'),
        new_translation_units_compiled=3, SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0),
    retained_initial_compile_failures=[dict(path='compile1/bounds', reason='Missing backend include, explicit Operation construction and duplicate same-line SCOPED_TRACE names; test-source fixes only.'),
                                      dict(path='compile1/qwen-state', reason='MSVC /WX C4456 token loop variable shadow; renamed vocabulary_token, no math or checks changed.')],
    source_reviews=[identity(S / p) for p in (
        'admission-source/freeze.json', 'qwen-source/freeze2.json',
        'review/cuda-packed-m1-independent.json', 'review/bounds-and-single-head-independent.json',
        'review/qwen-single-head-independent.json')],
    next_original_supplier_map=identity(S / 'review/next-original-suppliers.json'),
    next='GLM Flash seven original BF16 indexer roles14943744B into the existing complete NextN fresh/catchup chain, reusing already acquired original input roles. Follow exact BF16 store/norm boundaries and separate target43 roles. DSpark remaining norms/HC then router/expert readiness, shared LM, realtarget taps, Progeometry and confirmedquant combinations remain.',
    limitations=['WindowsCPU/CUDA only; no Linux/Apple/Vulkan model execution this batch.',
                 'Q27/Q24 full head weights/vocabulary and remaining NextN coefficients are generated; original EH/norm or K/V roles stay injected. No complete original target trunk, full original expert bank, natural acceptance or full generation quality claim.',
                 'The generic large-bank allowance is deliberately tied to the actual no-full-weight-decode path. Other shapes, types, layouts and native fallbacks retain prior limits.',
                 'Full-logit Copy observations and six-generation pool are test diagnostics, not a production performance configuration.',
                 'No new loading/TPS or physical memory/VRAM observation; AV four-arm table unchanged.',
                 'This closes one real library limitation; the full MTP and broad architecture/performance goal remain incomplete.'],
    performance_tail_sha256=tail_hash,
    final_image=read(S / 'tests-link1/ready.json')['image'],
    sources=[identity(p) for p in sources],
    cleanup='One current new executable/map retained for replay; no redundant BH image was produced. Failed compile logs and small objects/recipes retained. No cleanup deletion performed.',
    archive=identity(archive), archive_items=len(paths))
out = D / 'mtp-full-packed-head-2026-10-23.json'
assert not out.exists()
out.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=identity(out), archive=identity(archive)),
    ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(evidence=identity(out), archive=identity(archive), tests=7, model_graphs=graphs), ensure_ascii=False))
