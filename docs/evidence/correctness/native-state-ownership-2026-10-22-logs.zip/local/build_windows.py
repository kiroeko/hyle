"""Focused core rebuild and the six retained-backing tests; no SDK rebuild."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('ak_host_helpers',R/'.scratch/native-paged-effects-20261022/build_windows.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c;h.S=S
recipes={
 'budget':R/'.scratch/architecture-refactor-2026-10-18/cold-copy-retirement/checks/20261019T053001-df70e294/src--compute--resource_budget-identity.json',
 'leases':R/'.scratch/paged-exclusive-20261021/compile1/leases/identity.json',
 'resources':R/'.scratch/native-paged-effects-20261022/compile1/resources/identity.json',
 'token-test':R/'.scratch/native-paged-capacity-20261022/compile1/native-batch/identity.json',
 'lease-test':R/'.scratch/native-paged-capacity-20261022/compile1/native-batch/identity.json'}
sources={'budget':'src/compute/resource_budget.cc','leases':'src/compute/resource_leases.cc','resources':'src/graph/resources.cc',
         'token-test':'tests/compute/shared_backing_budget_test.cc','lease-test':'tests/compute/retained_lease_budget_test.cc'}
h.RECIPES=recipes;h.SOURCES={k:R/v for k,v in sources.items()}
BASE=R/'.scratch/qwen-native-assembly-20261022/cuda-link3'
def link(attempt):
    base=c.read(BASE/'link-plan.json')
    paths={k:(S/f'compile{attempt}/{k}/identity.json' if (S/f'compile{attempt}/{k}/identity.json').is_file() else S/f'compile1/{k}/identity.json') for k in recipes}
    records={k:c.read(v) for k,v in paths.items()}
    replacements={c.key(c.read(recipes[k])['object']['path']):records[k]['object'] for k in ['budget','leases','resources']}
    consumer=next(x for x in base['inputs'] if c.key(x['path'])==c.key(str(R/'.scratch/qwen-native-assembly-20261022/compile3/main/main.obj')))
    remove=c.key(consumer['path'])
    addons=[records[x]['object'] for x in ['token-test','lease-test']]+[b.identity(R/'.scratch/build-compute-v2-dev/lib'/x) for x in ['gtest_main.lib','gtest.lib']]
    for value in base['inputs']:assert b.identity(value['path'])==value
    for key in replacements:assert sum(c.key(x['path'])==key for x in base['inputs'])==1,key
    command=[replacements.get(c.key(x),{}).get('path',x) for x in base['command'] if c.key(x)!=remove and not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command[1:1]=[x['path'] for x in addons]
    out=S/('cpu-link'+str(attempt));out.mkdir();(out/'tmp').mkdir();image=out/'retained-budget.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=addons+[replacements.get(c.key(x['path']),x) for x in base['inputs'] if c.key(x['path'])!=remove]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(BASE/'link-plan.json'),compiled_records=[b.identity(x) for x in paths.values()],SDK_builds=0,NVCC=0))
    env,_=b.environment(command,[x['path'] for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(BASE/'runtime-environment.json')
    for item in runtime['staged_dlls']:assert b.identity(item['path'])==item;os.link(item['path'],out/Path(item['path']).name)
    runtime['staged_dlls']=[b.identity(x) for x in out.glob('*.dll')];c.save(out/'runtime-environment.json',runtime)
    c.save(out/'ready.json',dict(image=b.identity(image),plan=b.identity(out/'link-plan.json')))
    print('LINKED six core budget tests',flush=True)
def run(attempt):
    root=S/('cpu-link'+str(attempt));out=S/('cpu-run'+str(attempt));out.mkdir()
    env=dict(os.environ,PATH=c.read(root/'runtime-environment.json')['PATH'])
    c.save(out/'image.json',b.identity(root/'retained-budget.exe'))
    c.execute('run',[str(root/'retained-budget.exe'),'--gtest_filter=SharedBackingBudget.*:RetainedLeaseBudget.*'],env,out)
    print((out/'run.stdout.log').read_text(errors='replace'))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('actions',nargs='+',choices=[*recipes,'link','run']);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
    for action in a.actions:
        if action=='link':link(a.attempt)
        elif action=='run':run(a.attempt)
        else:h.compile_one(action,a.attempt)
