"""Offline text inspection of existing exact-ID windows; no model execution."""
from pathlib import Path
import hashlib, json
from tokenizers import Tokenizer
S=Path(__file__).resolve().parent;R=S.parents[1]
T=Path('C:/Users/kiro/Downloads/Qwen3.5-2B/tokenizer.json')
tokenizer=Tokenizer.from_file(str(T))
W=R/'.scratch/qwen-mtp-steady-profile-20261022/current-window/timing'
runs=json.loads((W/'runs.json').read_bytes());arms=[]
for arm in ['hyle_plain','hyle_mtp','peer_plain','peer_mtp']:
    selected=next(x for x in runs if x['arm']==arm)
    path=Path(selected['folder'])/'stdout.log';raw=path.read_bytes();out=json.loads(raw)
    ids=out['generated_ids']
    arms.append(dict(arm=arm,model_image=selected['process']['image'],
         output_source=dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),
         generated_ids=ids,text=tokenizer.decode(ids,skip_special_tokens=False),
         clean_text=tokenizer.decode(ids,skip_special_tokens=True)))
prompt_ids=[int(x) for x in (R/'.scratch/qwen-mtp-window-20261022/inputs/text/prompt.ids').read_text().split()]
report=dict(date='2026-10-22',action='offline_decode_existing_recorded_IDs',new_model_processes=0,
            tokenizer=dict(path=str(T),bytes=T.stat().st_size,sha256=hashlib.sha256(T.read_bytes()).hexdigest()),
            decoded_prompt=tokenizer.decode(prompt_ids,skip_special_tokens=False),arms=arms,
            limitations=['One existing coding prompt, capped at 64 generated tokens; these are incomplete code prefixes.',
                         'Coherent-looking text is not a full quality result or proof that shape-dependent numerical differences are acceptable.'])
path=R/'docs/evidence/correctness/qwen-existing-output-text-2026-10-22.json'
path.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
for row in arms:
    print(row['arm']+':\n'+row['text']+'\n')
print('Saved '+str(path))
