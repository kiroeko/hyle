"""Run the one prepared native retained-budget consumer, once."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('ak_native_run_helpers',S/'apple_build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
ready=json.loads((S/'apple-test1.json').read_bytes())
code=r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['root']);out=root/'budget-run1';out.mkdir();image=Path(p['image']['path']);raw=image.read_bytes();assert len(raw)==p['image']['bytes'] and hashlib.sha256(raw).hexdigest()==p['image']['sha256']
record=dict(command=[str(image)],cwd=str(root),image=p['image'],started=time.time())
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
 child=subprocess.Popen(record['command'],cwd=root,env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_LIBRARY_PATH=p['sdk']+'/relocated/sdk/lib'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(record=record,stdout=(out/'stdout.log').read_text(errors='replace'),stderr=(out/'stderr.log').read_text(errors='replace'))))
'''
result=h.m.ssh(code,dict(root=h.BASE,image=ready['image'],sdk=h.m.SDK),timeout=90)
h.m.save(S/'apple-budget-run1.json',result);print(json.dumps(result))
if result['record']['exit']:raise SystemExit(1)
