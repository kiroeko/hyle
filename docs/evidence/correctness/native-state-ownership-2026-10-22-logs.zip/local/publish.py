"""Publish the actual bounded cache journeys and retained-backing mechanism."""
from pathlib import Path
import difflib,hashlib,importlib.util,json,subprocess,sys,zipfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];E=R/'docs/evidence/correctness'
def read(p):return json.loads(p.read_bytes())
def ident(p):
 raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
names=['N3R1-run1','N1R1-run1','N2R2-run1'];journeys=[];reference=None
for name in names:
 data=read(S/(name+'.json'));assert data['record']['exit']==0
 result=json.loads(data['stdout']);ids={x['session_id']:x['result']['generated_ids'] for x in result['sessions']}
 if reference is None:reference=ids
 assert ids==reference
 for session in result['sessions']:
  for record in session['ledger']:
   assert record['after_length']==record['before_length']+record['accepted']
   assert record['after_frontier']==record['before_frontier']+record['draft_rows']
   assert record['after_lag']==record['after_length']-record['after_frontier'] and record['after_lag'] in (0,1)
 journeys.append(dict(name=name,record=data['record'],result=result))
native=read(S/'apple-budget-run1.json');assert native['record']['exit']==0 and native['stdout'].count('PASS ')==2
cpu=(S/'cpu-run2/run.stdout.log').read_text();assert '[  PASSED  ] 6 tests.' in cpu
products=['src/compute/resource_budget.cc','src/compute/resource_leases.cc','include/hyle/compute/detail/resource_budget_access.h','include/hyle/compute/detail/lease_access.h','src/graph/resources.cc','include/hyle/graph/result.h','tests/compute/shared_backing_budget_test.cc','tests/compute/retained_lease_budget_test.cc','tests/compute/CMakeLists.txt','tests/graph_route_apple/retained_output_budget_consumer.cc','tests/graph_route_apple/CMakeLists.txt','docs/user/graph.md','docs/architecture/graph-design.md','docs/developer/current-work.md']
snapshot=S/'source';diff=[]
for rel in products:
 p=R/rel;dest=snapshot/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
 candidates=[S/'before'/rel,S/'common-budget/before'/rel,S/'permanent-budget-tests/before'/rel,S/'retained-output-test/before'/rel]
 old=next((x for x in candidates if x.is_file()),None)
 if old:
  process=subprocess.run(['git','diff','--no-index','--check',str(old),str(p)],capture_output=True,text=True,encoding='utf8',errors='replace')
  assert process.returncode in (0,1) and not process.stdout.strip() and not process.stderr.strip(),process.stdout+process.stderr
  diff.extend(difflib.unified_diff(old.read_text(encoding='utf8').splitlines(keepends=True),p.read_text(encoding='utf8').splitlines(keepends=True),fromfile='before/'+rel,tofile=rel))
(S/'implementation.diff').write_text(''.join(diff),encoding='utf8')
spec=importlib.util.spec_from_file_location('ak_publish_mac_helpers',S/'apple_build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
closure=h.m.include_closure(products[:2]+['src/graph/resources.cc','tests/graph_route_apple/retained_output_budget_consumer.cc'],[])
archive=E/'native-state-ownership-2026-10-22-logs.zip';entries=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(S.rglob('*')):
  if not p.is_file() or p.suffix.lower() not in ('.json','.log','.py','.cc','.h','.md','.txt','.diff'):continue
  if 'tmp' in p.relative_to(S).parts or p.stat().st_size>8*1024*1024:continue
  name='local/'+p.relative_to(S).as_posix();z.write(p,name);entries.append(dict(archive_path=name,**ident(p)))
 for p in closure:
  name='current-closure/'+p.relative_to(R).as_posix();z.write(p,name);entries.append(dict(archive_path=name,**ident(p)))
document=dict(schema=1,date='2026-10-22',result='PASS_LIMITED_LIBRARY_AND_NATIVE_JOURNEY_SCOPE',
 scope='Common retained-result admission plus actual Apple R1/R2 Qwen MTP multi-session journeys. No native CLI cache-byte completion, Vulkan backing rotation or full quality acceptance.',
 implementation=[
  'GraphOutput::storage_lease(retention_budget) explicitly admits only the completed retained result. The original no-budget projection has unchanged ownership semantics.',
  'A retained charge stays on the original LeaseDomain; native uses and prior aliases keep it. No new payload copy, result domain, executor, Provider vtable or MLX deleter modification.',
  'Scope-owned live-record list is non-owning. Tokens retain one actual reservation; last token unlinks under lookup lock, then destroys quota/metadata outside that lock. No strong ownership cycle or global cache.',
  'Keys include exact nominated resource and identity authority/value. Cross-domain canonical host addresses are used only when the actual resource explicitly promises HostAddressIdentity; opaque native handles are never guessed to be canonical.',
  'Already-charged exact-resource pool reservation moves into the shared fact without a temporary second payload charge. Failure leaves prior reservation/lease intact. Whole backing is charged, not one logical subview.',
  'Graph retains its existing source-family/resource validation. Different scopes/resources do not bypass each other. Metadata is charged to its actual allocator scope.'
 ],
 cpu=dict(tests=6,source=[ident(R/x) for x in products if x.startswith('tests/compute/')],run=ident(S/'cpu-run2/run.result.json'),stdout=cpu,
          checks=['alias token lifetime','quota/identity namespace separation','adopt failure/success','concurrent two-holder lookup','original pool/subview actual F1 retirement','rejection preserves bytes/generation/readonly and retry']),
 apple_budget=native,
 native_journeys=dict(hardware=read(S/'apple-prepare.json')['hardware'],input_receipt=ident(S/'apple-prepare.json'),runs=journeys,
  all_session_generated_ids_equal=True,ledger_length_frontier_lag_checks=True,
  caveat='Protocol/output controls without full hidden/state dumps, prefix reuse or cancellation injection. Cross-shape quality is not inferred from greedy-ID equality.'),
 build=dict(Windows_CXX=6,Apple_CXX=5,SDK_builds=0,NVCC=0,shader_builds=0,
  note='Three common Windows owners, two test TUs, one resource-scoped idempotence refinement; three common Apple owners, that same one-TU refinement, and one real consumer. Original archived dependencies retained.'),
 remaining=[
  'Connect selected Qwen state/carry exports to this budget and provide actual retained usage/admission reporting. Native explicit --cache-bytes is still rejected; old CUDA state formula is not a native exact bound.',
  'Native allocation-before-completion peak and MLX private/allocator cache memory remain separate/unknown. Retention admission is not a full physical memory cap.',
  'Vulkan storage_block backing rotation, static descriptor/managed child rebind, and a non-bypassable output-epoch rearm gate; preserve original Run and actual retirement.',
  'Vulkan trusted canonical allocation annotation is not implemented; opaque wrappers remain independently accounted rather than claiming cross-domain physical deduplication.',
  'Native Apple prefix and cancellation combinations, selected-model/quantization coverage, cross-shape numerical quality, and full speed/memory window.'
 ],
 existing_output_text=ident(E/'qwen-existing-output-text-2026-10-22.json'),
 performance=dict(new_full_window=False,latest_window_unchanged=True),
 product_sources=[ident(R/x) for x in products],evidence_archive=ident(archive),archive_entries=entries)
save(E/'native-state-ownership-2026-10-22.json',document)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))
 for x in entries:
  raw=z.read(x['archive_path']);assert len(raw)==x['bytes'] and hashlib.sha256(raw).hexdigest()==x['sha256']
print(json.dumps(dict(manifest=ident(E/'native-state-ownership-2026-10-22.json'),archive=ident(archive),CPU_tests=6,native_budget_cases=2,Qwen_journeys=3)))
