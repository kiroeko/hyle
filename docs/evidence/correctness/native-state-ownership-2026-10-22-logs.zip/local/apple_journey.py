"""Run the retained native consumer on existing bounded MTP schedules."""
from pathlib import Path
import argparse, base64, importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('ak_apple_helpers',R/'.scratch/qwen-native-assembly-20261022/apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
REMOTE=h.m.BASE+'/native-state-ownership-20261022'
IMAGE=h.m.REMOTE+'/revision4/native-append'
def prepare():
    old=R/'.scratch/qwen-mtp-batch-20261022/fixtures'
    names=['sessions.txt','a-long.txt','b.txt','c.txt','p15.ids','p23.ids','u1.ids','u8.ids','u24.ids']
    files=[dict(path=name,data=base64.b64encode((old/name).read_bytes()).decode()) for name in names]
    result=h.m.ssh(r'''
from pathlib import Path
import base64,hashlib,json,subprocess,sys
p=json.load(sys.stdin);root=Path(p['root']);root.mkdir();fixtures=root/'fixtures';fixtures.mkdir();files=[]
for x in p['files']:
 path=fixtures/x['path'];raw=base64.b64decode(x['data']);path.write_bytes(raw);files.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
hardware={x:subprocess.check_output(['/usr/sbin/sysctl','-n',x],text=True).strip() for x in ['hw.model','hw.memsize','machdep.cpu.brand_string']}
assert hardware['hw.model']=='Mac16,12'
image=Path(p['image']);raw=image.read_bytes()
print(json.dumps(dict(root=str(root),files=files,hardware=hardware,image=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))))
''',dict(root=REMOTE,files=files,image=IMAGE))
    h.m.save(S/'apple-prepare.json',result);print(json.dumps(result))
def run(residents,width,attempt):
    code=r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['root']);out=root/('N'+str(p['residents'])+'R'+str(p['width'])+'-run'+str(p['attempt']));out.mkdir()
image=Path(p['image']);raw=image.read_bytes();assert hashlib.sha256(raw).hexdigest()==p['expected_image']['sha256']
command=[str(image),'--inputs',p['inputs'],'--mtp','on','--capacity','64','--session-schedules',str(root/'fixtures/sessions.txt'),'--max-sessions',str(p['residents']),'--active-sequences',str(p['width']),'--prefix-cache','off','--progress','direct','--replay','commands']
record=dict(command=command,cwd=str(root),image=p['expected_image'],started=time.time(),performance_comparison=False)
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
 child=subprocess.Popen(command,cwd=root,env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_LIBRARY_PATH=p['sdk']+'/relocated/sdk/lib'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(record=record,stdout=(out/'stdout.log').read_text(errors='replace'),stderr=(out/'stderr.log').read_text(errors='replace'))))
'''
    prepared=json.loads((S/'apple-prepare.json').read_bytes())
    result=h.m.ssh(code,dict(root=REMOTE,image=IMAGE,expected_image=prepared['image'],sdk=h.m.SDK,
                  inputs=h.m.REMOTE+'/inputs/mtp',residents=residents,width=width,attempt=attempt),timeout=1800)
    name='N'+str(residents)+'R'+str(width)+'-run'+str(attempt)
    h.m.save(S/(name+'.json'),result)
    parsed=json.loads(result['stdout']) if result['record']['exit']==0 else {}
    keys=['session_count','turn_count','actual_graph_calls','generated_tokens','restore_count','restored_graph_calls','restored_target_rows','restored_draft_rows','normalized_lag_rows','recomputed_decision_changes','idle_evictions','peak_resident_requests','native_generated_backing_unknown']
    print(json.dumps(dict(record=result['record'],summary={k:parsed.get(k) for k in keys},sessions=[dict(id=x['session_id'],ids=x['result']['generated_ids']) for x in parsed.get('sessions',[])],stderr_tail=result['stderr'][-800:] if result['record']['exit'] else ''),ensure_ascii=False))
    if result['record']['exit']:raise SystemExit(1)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','run']);p.add_argument('--residents',type=int,default=3);p.add_argument('--width',type=int,default=1);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
    if a.action=='prepare':prepare()
    else:run(a.residents,a.width,a.attempt)
