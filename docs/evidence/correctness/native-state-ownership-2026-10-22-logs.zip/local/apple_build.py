"""Repack only the three changed common owners in the retained native SDK."""
from pathlib import Path
import argparse,base64,importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('ak_mac_build_helpers',R/'.scratch/qwen-native-assembly-20261022/apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
m=h.m;BASE=m.BASE+'/native-state-ownership-20261022';AJ=m.REMOTE
cached=json.loads((R/'.scratch/native-paged-effects-20261022/apple/mac-cached-closure.json').read_bytes())
original=json.loads((R/'.scratch/native-paged-effects-20261022/apple/mac-plan.json').read_bytes())
def build(action,revision):
    remote=BASE+'/core'+str(revision) if action=='core' else BASE+'/test1';m.REMOTE=remote
    sources=(['src/compute/resource_budget.cc','src/compute/resource_leases.cc','src/graph/resources.cc'] if revision==1 else ['src/compute/resource_leases.cc']) if action=='core' else ['tests/graph_route_apple/retained_output_budget_consumer.cc']
    jobs=[]
    for source in sources:
        row=next(x for x in cached['compile'] if x['file'].endswith('/'+source)) if action=='core' else next(x for x in cached['compile'] if x['file'].endswith('/src/graph_route_apple/native_region.cc'))
        obj=remote+'/'+Path(source).name+'.o'
        jobs.append(dict(source=m.ident(R/source),object=obj,argv=m.overlay_command(row,source,obj)))
    files=[]
    for path in m.include_closure(sources,[x['argv'] for x in jobs]):
        entry=m.ident(path);entry['path']=path.relative_to(R).as_posix();entry['data']=base64.b64encode(path.read_bytes()).decode();files.append(entry)
    actions=[['compile'+str(i),x['argv']] for i,x in enumerate(jobs)];libs=[]
    if action=='core':
        prior=original['archives'] if revision==1 else json.loads((S/'apple-core1-plan.json').read_bytes())['libraries']
        if revision!=1:libs=[x for x in prior if x['module']!='compute']
        for module in (['compute','graph'] if revision==1 else ['compute']):
            old=next(x for x in prior if x['module']==module)
            replacements={Path(x['source']['path']).name:x['object'] for x in jobs if ('/src/'+module+'/') in Path(x['source']['path']).as_posix()}
            objects=[replacements.get(Path(x).name.removesuffix('.o'),x) for x in old['objects']]
            for value in replacements.values():assert objects.count(value)==1,value
            path=remote+'/libhyle_'+module+'.a';actions.append(['archive-'+module,['/usr/bin/libtool','-static','-o',path,*objects]])
            libs.append(dict(module=module,path=path,old=old.get('old',old['path']),objects=objects))
    else:
        core=json.loads((S/('apple-core'+str(revision)+'-plan.json')).read_bytes());libs=core['libraries']
        link=json.loads((R/'.scratch/qwen-native-assembly-20261022/apple/revision4.json').read_bytes())['records'][1]['command']
        link=[jobs[0]['object'] if x==AJ+'/revision4/main.o' else next((l['path'] for l in libs if x==l['old']),x) for x in link]
        link[link.index('-o')+1]=remote+'/native-retained-budget';actions.append(['link',link])
    payload=dict(remote=remote,sdk=m.SDK,files=files,jobs=jobs,actions=actions,libraries=libs,
                 original_metallib=AJ+'/mlx.metallib',action=action)
    label='core'+str(revision) if action=='core' else 'test1'
    m.save(S/('apple-'+label+'-plan.json'),{**payload,'files':[{k:v for k,v in x.items() if k!='data'} for x in files]})
    code=r'''
from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);root.mkdir();source=root/'source';source.mkdir()
for x in p['files']:
 target=source/x['path'];target.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(x['data']);assert len(raw)==x['bytes'] and hashlib.sha256(raw).hexdigest()==x['sha256'];target.write_bytes(raw)
records=[]
for action,argv in p['actions']:
 record=dict(command=argv,cwd=p['sdk']+'/build',started=time.time())
 with (root/(action+'.stdout.log')).open('wb') as so,(root/(action+'.stderr.log')).open('wb') as se:
  child=subprocess.Popen(argv,cwd=record['cwd'],env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
 record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(root/(action+'.result.json')).write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 if child.returncode:break
result=dict(records=records,all_exit_zero=len(records)==len(p['actions']) and all(x['exit']==0 for x in records))
if result['all_exit_zero'] and p['action']=='consumer':
 os.link(p['original_metallib'],root/'mlx.metallib');image=root/'native-retained-budget';raw=image.read_bytes();result['image']=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
if not result['all_exit_zero']:result['stderr']=(root/(p['actions'][len(records)-1][0]+'.stderr.log')).read_text(errors='replace')
(root/'ready.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
'''
    result=m.ssh(code,payload,timeout=180);m.save(S/('apple-'+label+'.json'),result)
    print(json.dumps(dict(all_exit_zero=result['all_exit_zero'],records=[dict(exit=x['exit'],pid=x['pid'],seconds=x['seconds']) for x in result['records']],image=result.get('image'),stderr=result.get('stderr'))))
    if not result['all_exit_zero']:raise SystemExit(1)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['core','consumer']);p.add_argument('--revision',type=int,default=1);a=p.parse_args();build(a.action,a.revision)
