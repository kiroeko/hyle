from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/inference-frontier-retirement-20261025';P=R/'.scratch/inference-prefix-admission-20261025';A=W/'attempt1';S=W/'source'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
base=b.args(P/'attempt3/compile/command.json');command=[base[0],'/I'+str(S)];skip=False
for arg in base[1:]:
    if skip:skip=False;continue
    if arg=='/sourceDependencies':skip=True;continue
    low=arg.lower().replace('\\','/')
    if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
    if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
    command.append(arg)
command+=['/sourceDependencies',str(A/'compile/dependencies.json'),str(S/'component.cc'),'/Fo'+str(A/'compile/unit.obj'),'/Fd'+str(A/'compile/unit.pdb')]
env=b.environment(base[0]);b.execute(command,A/'compile',env,150)
includes=b.read(A/'compile/dependencies.json')['Data']['Includes']
assert not [p for p in includes if Path(p).resolve().is_relative_to(R/'engine')]
b.save(A/'compile/source-pins.json',[b.pin(p)for p in S.rglob('*')if p.is_file()])
link=[];found=0
for arg in b.args(P/'attempt3/link/command.json'):
    if arg.lower().startswith(('/out:','/pdb:','/implib:')):continue
    if arg==str(P/'attempt3/compile/unit.obj'):arg=str(A/'compile/unit.obj');found+=1
    link.append(arg)
assert found==1
link+=['/OUT:'+str(A/'link/component.exe'),'/PDB:'+str(A/'link/component.pdb'),'/IMPLIB:'+str(A/'link/component.lib')]
b.execute(link,A/'link',env,90)
native=R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,A/'link'/native.name)
env['PATH']=str(A/'link')+';'+b.read(R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')['PATH']
fixture=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture/weights.tsv'
b.save(A/'pre-run-pins.json',dict(image=b.pin(A/'link/component.exe'),native=b.pin(native),fixture=b.pin(fixture),
    fixture_body=b.pin(fixture.parent/'untrained-bf16.bin'),source=[b.pin(p)for p in S.rglob('*')if p.is_file()],
    closure=[b.pin(Path(p))for p in link[1:]if Path(p).is_absolute()and Path(p).suffix.lower()in{'.obj','.lib'}],
    closure_delta='Only consumer OBJ replaced from prior successful CPU closure; existing resources/core/report/SDK reused'))
b.execute([str(A/'link/component.exe'),str(fixture)],A/'run',env,60)
print((A/'run/stdout.log').read_text(encoding='utf8'))
