from pathlib import Path
import difflib,hashlib,json,shutil
R=Path.cwd();W=R/'.scratch/inference-frontier-retirement-20261025';P=R/'.scratch/inference-prefix-admission-20261025'
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert pin(R/'engine/models/qwen35/main.cc')['sha256']=='eb156fd61abe34acae23d466f30ca6d8d5dfcb45ee03e5242347282affdb90d4'
files=[R/'engine/models/qwen35/main.cc',*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h'),R/'engine/reporting/execution_report.h',R/'engine/reporting/execution_report.cc']
B=W/'before';S=W/'source';assert not B.exists()and not S.exists()
for p in files:
    for dst in [B,S]:
        q=dst/p.relative_to(R);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
save(W/'before-pins.json',[pin(p)for p in files])
p=S/'engine/models/qwen35/main.cc';t=p.read_text()
old='''    auto &frontier = *selected.frontier;
    // This is the same Graph execution API/runtime as target/draft. It reads'''
new='''    auto &frontier = *selected.frontier;
    if (frontier.retirement.pending())
      throw std::runtime_error("original sampling frontier resource scope is still retained");
    // This is the same Graph execution API/runtime as target/draft. It reads'''
assert t.count(old)==1;t=t.replace(old,new);p.write_text(t,encoding='utf-8',newline='\n')
save(W/'after-pins.json',[pin(p)])
(W/'source.patch').write_text(''.join(difflib.unified_diff((B/'engine/models/qwen35/main.cc').read_text().splitlines(True),t.splitlines(True),fromfile='a/engine/models/qwen35/main.cc',tofile='b/engine/models/qwen35/main.cc')),encoding='utf-8')
component=(P/'component.cc').read_text()
old='''    // Same stream/control: a fresh full hit succeeds without any prior refusal.
'''
new='''    // A legitimate, deliberately unsubmitted retention reservation models
    // only the pending guard. It is not an injected native failure/retirement.
    auto &frontier = *model.sampling_configuration().frontier;
    const std::array<std::uint32_t, 4> identity_sentinel{0x12345678U, 0x90abcdefU, 0x11223344U, 0x55667788U};
    const q::cache::SamplingCursor guard_cursor{123, 77, 0};
    require(identity_sentinel != guard_cursor.identity(), "guard identity does not discriminate the overwritten value");
    frontier.identity.write<std::uint32_t>(identity_sentinel);
    const auto guard_boundary = q::generation_boundary(*original);
    const auto guard_calls = model.frontier_sampling_graph_calls;
    q::check(frontier.retirement.reserve(model.resources_));
    std::string pending_refusal;
    try { (void)model.sample_prefix(original, guard_cursor); }
    catch (const std::runtime_error &error) { pending_refusal = error.what(); }
    std::array<std::uint32_t, 4> identity_after{};
    q::check(frontier.identity.storage().read(std::as_writable_bytes(std::span(identity_after))));
    const bool still_retained = frontier.retirement.pending();
    // Only this known-unsubmitted test reservation may be rejected. Accepted
    // native work must retain its original actual-retirement continuation.
    frontier.retirement.reject();
    require(pending_refusal == "original sampling frontier resource scope is still retained" && still_retained &&
        identity_after == identity_sentinel && q::generation_boundary(*original) == guard_boundary &&
        hidden_digest(model, *original) == original_digest && model.frontier_sampling_graph_calls == guard_calls &&
        !model.active_step && !model.carrier_borrowed && !frontier.retirement.pending(),
        "pending frontier gate wrote its fixed identity, advanced state/RNG or released the original retention");
    std::cerr << "expected_pending_frontier_gate=" << pending_refusal << '\\n';

    // Same stream/control: a fresh full hit succeeds without any prior refusal.
'''
assert component.count(old)==1;component=component.replace(old,new)
old='''        "\\\"real_resource_refusals\\\":1,\\\"frontier_graph_calls\\\":" << model.frontier_sampling_graph_calls'''
new='''        "\\\"pending_guard_fixture\\\":\\\"legal_unsubmitted_retention_reservation\\\",\\\"pending_guard_checks\\\":1,"
        "\\\"identity_sentinel_preserved\\\":true,\\\"native_unknown_fault_injected\\\":false,"
        "\\\"real_resource_refusals\\\":1,\\\"frontier_graph_calls\\\":" << model.frontier_sampling_graph_calls'''
assert component.count(old)==1;component=component.replace(old,new)
(W/'component.cc').write_text(component,encoding='utf-8',newline='\n');(S/'component.cc').write_text(component,encoding='utf-8',newline='\n')
save(W/'component-source.json',dict(before=pin(P/'component.cc'),after=pin(W/'component.cc'),math_unchanged=True,extension='Unsubmitted original RetainedResources reserve / pending refusal / identity-byte check / reject; then original actual CPU control and budget retry journey'))
save(W/'execution-plan.json',dict(scope='one strict consumer TU/relink and one CPU-only process, no SDK/core rebuild/GPU/HTTP',
    product_change=pin(p),source=[pin(p)for p in S.rglob('*')if p.is_file()],
    actual_guard='Reserve original frontier.retirement before sample_prefix; reject only this unsubmitted test reservation afterward',
    limitations='This tests the pending gate only; accepted-but-unknown native reachability is source-reviewed, not injected or executed. Earlier prefix resource-retry proof remains separate.'))
print(json.dumps(dict(after=pin(p),frozen_files=len(files),component=pin(W/'component.cc'))))
