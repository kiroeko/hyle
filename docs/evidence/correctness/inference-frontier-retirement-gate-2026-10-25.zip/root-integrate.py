from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[2]
batch = Path(__file__).resolve().parent
output = batch / 'root-integration.json'
assert not output.exists()
read = lambda p: json.loads(p.read_bytes())

def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

for row in read(batch / 'before-pins.json'):
    assert pin(Path(row['path'])) == {k: row[k] for k in ('bytes', 'sha256')}
after = read(batch / 'after-pins.json')
assert len(after) == 1
compiled = {row['path'].lower(): row for row in read(batch / 'attempt1/compile/source-pins.json')}
for row in after:
    assert compiled[row['path'].lower()] == row
    assert pin(Path(row['path'])) == {k: row[k] for k in ('bytes', 'sha256')}
for phase in ('compile', 'link', 'run'):
    result = read(batch / 'attempt1' / phase / 'process.json')
    assert result['exit'] == 0 and not result['timeout']
actual = read(batch / 'attempt1/run/stdout.log')
assert actual['status'] == 'PASS' and actual['pending_guard_checks'] == 1
assert actual['identity_sentinel_preserved'] and not actual['native_unknown_fault_injected']
assert actual['same_request_retry'] and actual['fresh_direct_control'] and actual['single_new_draw']
assert actual['frontier_graph_calls'] == 2 and actual['final_versions'] == 0
assert not actual['GPU'] and not actual['HTTP']
row = after[0]
source = Path(row['path'])
target = root / source.relative_to(batch / 'source')
target.write_bytes(source.read_bytes())
assert pin(target) == {k: row[k] for k in ('bytes', 'sha256')}
output.write_bytes((json.dumps({
    'status': 'INTEGRATED_AFTER_FINITE_HOST_PENDING_GUARD_CHECK',
    'source': {'path': str(target.relative_to(root)).replace('\\', '/'), **pin(target)},
    'actual': actual,
    'scope': 'A legal unsubmitted retention reservation tests the early guard; accepted native unknown retirement is source-reviewed, not fault-injected.',
    'extra_build_or_process': False,
}, indent=2) + '\n').encode('utf-8'))
print('Integrated the early frontier-retirement guard; no new build or run.')
