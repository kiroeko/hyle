from pathlib import Path
import hashlib,json,zipfile
R=Path.cwd();W=R/'.scratch/inference-frontier-retirement-20261025'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
actual=read(W/'attempt1/run/stdout.log');assert actual['status']=='PASS'and actual['pending_guard_checks']==1 and actual['identity_sentinel_preserved']
assert not actual['native_unknown_fault_injected']and actual['output']==45 and actual['final_versions']==0
cleanup=[pin(p)for p in (W/'attempt1').rglob('*')if p.is_file()and p.suffix.lower()in{'.obj','.exe','.lib','.exp','.dll','.pdb'}]
save(W/'cleanup-candidates.json',dict(performed=False,files=cleanup,logical_bytes=sum(p['bytes']for p in cleanup),
    retained='All source/command/raw, original CPU DLL, cached fixture, shared Graph/resources/core/report/SDK objects',eligible='Only after root final proof/source review; no deletion performed'))
summary=dict(status='PASS_PRIVATE_FRONTIER_PENDING_GATE',date='2026-10-25',
    change='Check selected frontier.retirement.pending before creating another Invocation or writing fixed identity storage. No collect/drain/reject/reset is added to production.',
    scope='Selected sampling frontier only; analogous auxiliary programs remain a distinct pending source review, not silently certified.',
    source=read(W/'after-pins.json'),source_delta='One two-line main.cc gate; existing math/route/normal sequence/actual retirement and all budgets unchanged.',
    actual=actual,process=read(W/'attempt1/run/process.json'),compile=read(W/'attempt1/compile/process.json'),link=read(W/'attempt1/link/process.json'),
    guard_fixture=dict(method='Original RetainedResources::reserve(resources_) on a known unsubmitted frontier',
        operation='sample_prefix called with another real cursor; 16B fixed identity sentinel differs from requested identity; early refusal leaves sentinel/Snapshot/cursor/hidden byte digest/call count unchanged',
        resolution='Only the deliberately unsubmitted test reservation is released using original reject(); production accepted or unknown native work is never reset.',
        native_unknown_fault_injected=False,accepted_native_unknown_retirement='Source-reachable argument only; not simulated or hardware-tested.',
        successful_invocation_creation_before_refusal='Not instrumented; gate precedes create_invocation in exact compiled source.'),
    additional_actual_checks='Original tiny pure-CPU random direct full hit/control, real shared requested-byte resource refusal, same-request retry, complete ledger/boundary/pending/RNG equality, old hidden byte digest/KV ready-reader validity and final explicit retirement remain passed.',
    previous_proof='docs/evidence/correctness/inference-prefix-admission-retry-2026-10-25.json (separate historical CPU pre-submit refusal proof; not overwritten)',
    counts=dict(consumer_TU_compiles=1,links=1,actual_processes=1,SDK_builds=0,core_builds=0,GPU_processes=0,HTTP=0),
    failures=[],limits=['No native device error injected; no unknown-retirement hardware experiment.',
        'CPU A-only untrained cached fixture, not full model, MTP runtime/backend matrix, quality or performance evidence.',
        'Identity mutation prevention is directly checked; id/valid ports had only been rebound before the old late gate, not proven overwritten by another kernel.',
        'No whole-function rollback of original begin_turn/input markers/timing/cache LRU is promised.'],
    cleanup=read(W/'cleanup-candidates.json'))
if (W/'root-integration.json').exists():summary['integration']=read(W/'root-integration.json');summary['status']='PASS_FRONTIER_PENDING_GATE_CANONICAL_INTEGRATED'
save(W/'summary.json',summary)
entries={}
def add(p,name=None):
    name=name or p.relative_to(W).as_posix();assert name not in entries;entries[name]=p
for folder in ['before','source']:
    for p in (W/folder).rglob('*'):
        if p.is_file():add(p)
for name in ['prepare.py','check.py','pack-proof.py','component.cc','before-pins.json','after-pins.json','source.patch','component-source.json','execution-plan.json','summary.json','cleanup-candidates.json','root-integrate.py','root-integration.json']:
    p=W/name
    if p.exists():add(p)
for p in (W/'attempt1').rglob('*'):
    if p.is_file()and p.suffix.lower()in{'.json','.log'}:add(p)
add(R/'.scratch/inference-prefix-admission-20261025/frontier-retirement-review.md','reviews/frontier-retirement-review.md')
archive=W/'proof.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))
save(W/'proof-summary.json',dict(summary,archive={**pin(archive),'entries':len(entries),'crc_verified':True,'binary_and_weight_payloads':False}))
print(json.dumps(dict(archive=pin(archive),entries=len(entries),cleanup_files=len(cleanup),cleanup_bytes=sum(p['bytes']for p in cleanup))))
