# Frontier retry / original retirement boundary

Read-only source review, 2026-10-25. No build, run, device-fault injection, HTTP or product edits. Canonical main SHA256 `eb156fd61abe34acae23d466f30ca6d8d5dfcb45ee03e5242347282affdb90d4`.

**Concrete reachable gap:** a selected sampling frontier with accepted but not provably retired native work is checked too late to protect its fixed identity input from a retry.

- `engine/models/qwen35/main.cc:3549–3562`: `sample_prefix` checks target `active_step` / `carrier_borrowed` and hidden validity, creates another Invocation, then writes the selected frontier's fixed UInt32 identity. It does not first check that frontier's `retirement.pending()`.
- `main.cc:3563–3568`: it binds the hidden/identity and caller readback buffers and prepares replay before calling `submit_retained`. Only `main.cc:2373` invokes `retention.reserve(resources_)`, which returns Unavailable if a previous original carrier is still retained.
- `main.cc:142,154–158`: `Tensor::storage()/write()` reaches the mutable BufferView directly. The normal no-shared-allocation-budget path stores this identity in a raw caller Buffer. The input is bound as a borrowed `ConstTensorView`, not transferred as a ready lease that universally forbids all future raw writes.
- `include/hyle/graph/executable.h:1000–1009` explicitly makes raw external TensorViews borrowed through their actual consumers. A new Invocation does not manufacture cross-invocation exclusive ownership of that caller memory.

Minimal sequence:

1. A random full-prefix hit submits the real frontier and attaches `frontier.retirement` to its original Completion.
2. Completion observation fails while native retirement is still unknown. The request gets no sampled pending/cursor/Session publication, and the native attachment remains active.
3. Exception unwinding destroys local `done` and `run`. This is not a blocking retirement guarantee: `Completion::settle` (`src/compute/completion.cc:208–211`) explicitly hands observation failure to the original runtime; `Invocation::~Invocation` (`src/graph/executable.cc:9262–9268`) only drops observation/root references. `RetainedCompletion` forwards the attachment while `retired==false` (`src/compute/retained_completion.cc:171–205`) and documents that unknown observation need not fire the actual-retirement latch (`:282–286`).
4. The same request retries after the new admission-publication fix. Its target active-step/carrier flags are still idle; `create_session` (`main.cc:3653–3654`) calls `sample_prefix` without an earlier selected-frontier retirement gate. If ordinary new-Invocation allocation succeeds, the new identity is written **before** `submit_retained` finally sees the old pending carrier and refuses submission.

This does not assert that any tested hardware actually exhibited such an observation failure. Nor does it claim the new attempt already overwrites id/valid through a kernel: those buffers are rebound before the gate, but submission is rejected. The definite unprotected operation is the fixed identity **write**; CUDA's synchronous copy behavior is not a cross-platform ownership/retirement proof and cannot replace the original latch.

**Smallest correction:** after resolving `auto &frontier = *selected.frontier`, before creating the new Invocation or touching any shared port, require `!frontier.retirement.pending()`. Return the existing Unavailable/carrier-retained error if still pending. An optional call to the original Backend's `collect_retired()` may make progress, followed by the same check; an error alone must never clear the latch. Do not call `reject()`, reset the accepted retention, drop old owners or infer retirement from the old exception. Existing externally serialized Model control makes this selected-carrier gate sufficient for the write boundary without another owner/manager or eager whole-model drain.

Once the original callback has actually retired that frontier, its gate may clear and the normal retry proceeds. A post-wait readback/validation error after proven successful retirement is different and need not be permanently blocked. This review is limited to the frontier; analogous auxiliary-program paths were not broadened into another audit here.

The already-passed CPU admission proof covers a **pre-submit requested-byte rejection**, with no accepted work and no pending retirement; its result remains valid and is not evidence for this distinct unknown-native-retirement case.
