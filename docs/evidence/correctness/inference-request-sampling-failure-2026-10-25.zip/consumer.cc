#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_participant_failure_case.h"

int main(int argc, char **argv) {
  try {
    if (argc == 1) return 77;
    if (argc != 3) throw std::runtime_error("participant-failure CACHED_TINY_INPUT_DIRECTORY PRIVATE_FIXTURE_DIRECTORY");
    return qwen_participant_failure_case::run(argv[1], argv[2]);
  } catch (const std::exception &error) {
    std::cerr << "participant_failure=" << error.what() << '\n';
    return 1;
  }
}
