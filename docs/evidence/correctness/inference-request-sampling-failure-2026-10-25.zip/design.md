# Ordinary participant-local sampling failure — private source draft

Status: PRIVATE_CPU_HELPER_PASS. One CPU app TU and one actual CPU process; no GPU, network or canonical edits.
Base: commit 2c4a250123be23b944e5d97a844372a35771ed31; main SHA a59100a79778cc0d59cb9cc0fc51962fcc9e8e760f615e6b62edd017460b3c39.

- `EvaluationFailure` owns only original Status, optional original batch-member index and the original abort's RetirementObservation. No Session, lease, view, mask or new cleanup owner.
- Existing `check/take` preserve native Status code/domain/number/message instead of throwing only the message. Existing std::exception/runtime_error callers still fail closed.
- A qualified index exists only for ordinary Text/EmitNext, after successful Completion wait and successful predicate codec, if exactly one member is 0 and every other member is 1. All errors are before selection/state exports/Head and ledger publication.
- Multiple 0s/other values remain batch-level failures with no qualified index. MTP invalid-predicate behavior is unchanged. Native/read/codec errors have no participant.
- The original finish/prepare catch drives original abort and attaches actual retirement facts; it never writes this logical error into StepState.terminal or Session.failed.
- Owner maps the index through the original calls, not Window.slot. Only actual retired=true AND clean cleanup permit withdrawal of bad A and same-key requeue of B. Pending/error cleanup preserves all occupied keys/charges and propagates both failures.
- Default CLI owner remains fail-closed; this slice exposes facts and proves a finite owner composition, not an online service or universal failure policy.

One proposed CPU process / same original tiny fixture:

1. Copy only the 13 existing ordinary BF16 roles (98,944B); preserve original finite embedding as independent lm_head (8,192B); alter only embedding row63 to BF16 NaN. Total derived data107,136B, with explicit untied synthetic geometry/identity. No full model, math replacement or native-fault injection.
2. N2/R2/C16, random sampling seed123/streams10,11, two quota1 turns. Both first P2 inputs [1,2] commit healthy Head/ledger/draw1. Gate that neither actual pending is63; failure means fixture qualification failed, not product failure.
3. Real R2 secondturn: calls[0]=A in Window slot1, input[pending,63]; calls[1]=B in Window slot0, input[pending,3]. Read actual invalid predicate. Assert both original Head pointers/full boundaries, committed ledger/progress, outputs and RNG unchanged; actual carrier/episode retired.
4. Original stop/retire drops only A; delivery already ACKed its first output. Requeue B's original key, without begin_turn/reset/ACK mutation. Real R1 T2 continuation publishes exactly one next output/draw, then final delivery drain and true Session retirement release the key. EOF versions/active/carrier all zero.
5. Same process synthetic Status transport checks exercise check/take with a native-tagged status; no member index is allowed. This proves the carrier boundary, NOT actual failed backend-read injection.

Recipe to prepare only after source review:

- Reuse `.scratch/inference-midturn-resume-20261025/implementation/attempt1/{compile,link}/command.json`, exactly one replacement app TU `consumer.cc`, 129 retained link inputs /130 including app, same native ffa4 DLL/runtime.
- Freeze only actual self-written engine header dependencies from current canonical, plus these private changed sources; never copy old sampling_graph.h or SDK. Main here remains the exact reviewed2c4a base plus this patch even if canonical advances.
- One CPU process: `component.exe <original tiny fixture dir> <attempt1/fixture>`, 120s watchdog. Actual result is in `summary.json`; compile18.094s/link1.203s/run0.265s, all exit0. B IDs[2,6]/draw2/2 committed records, final versions0/active_step/carrier empty. No failed build or run.
- Formal lifecycle dispatch gains `--participant-failure`; pureCPU verification can use thin driver because other lifecycle modes reference CUDA symbols.

Unverified: native/read failure injection, multiple-invalid runtime journey, MTP, GPU/backend faults, whole lifecycle TU build and default CLI request-isolation policy. NaN propagation/single-invalid readback and both healthy seed qualifications passed in this CPU process.
