from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.scratch/inference-gaps/g04-g05';RUN=BASE/'cpu-sdk'
OUT=ROOT/'evidence/correctness/inference-g04-g05-cpu-only-encoded-sdk'
records=[]
for file in sorted(RUN.glob('result-*.json')):
    data=json.loads(file.read_text());assert data['state'].startswith('TERMINAL_'),file
    records.append((file.stem.removeprefix('result-'),data))
latest={}
for tag,r in records:
    if r['mode'] not in latest or r['attempt']>latest[r['mode']][1]['attempt']:latest[r['mode']]=(tag,r)
assert set(latest)=={'static','shared'}
matrix=[]
for mode,(tag,r) in sorted(latest.items()):
    assert r['state']=='TERMINAL_PASS'
    assert 'ggml_cpu-ffa4e8b80930-' in r['identity']['ggml_source']
    commands=json.loads((RUN/f'consumer-commands-{tag}.json').read_text());assert len(commands)==14
    assert all(str(ROOT).replace('\\','/') not in row['command'].replace('\\','/') for row in commands)
    shipping=json.loads((RUN/f'shipping-{tag}.json').read_text());assert shipping and all('HYLE_TESTING' not in row['command'] for row in shipping)
    for stage,count in [('cpu_math',13),('cpu',3)]:
        xml=ET.parse(RUN/f'{stage}-{tag}.xml').getroot()
        assert int(xml.attrib['tests'])==count and xml.attrib['failures']=='0' and xml.attrib.get('disabled','0')=='0'
        assert all(case.find('skipped') is None for suite in xml.findall('testsuite') for case in suite.findall('testcase'))
    artifacts=json.loads((RUN/f'artifacts-{tag}.json').read_text())
    assert artifacts and any(Path(a['path']).name=='hyle_graph_batch.lib' for a in artifacts)
    if mode=='shared':assert any(Path(a['path']).suffix=='.dll' for a in artifacts)
    matrix.append({'mode':mode,'tag':tag,'math_tests':13,'public_encoder_consumers':3,'independent_headers':12,'consumer_tus':14,'verdict':'PASS'})
product={r['product_commit'] for _,r in latest.values()};assert len(product)==1
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() in product
dirty=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).splitlines()
# The six-route report is generated immediately before this independent CPU
# report. Its two new evidence files do not change any compiled product input.
assert all(line.startswith('?? evidence/correctness/inference-g04-g05-encoded-sdk/') for line in dirty),dirty
if dirty:
    mixed=json.loads((ROOT/'evidence/correctness/inference-g04-g05-encoded-sdk/result.json').read_text(encoding='utf-8'))
    assert mixed['verdict']=='PASS_SIX_CONFIGURATIONS' and mixed['product_commit'] in product
manifest=records[0][1]['inputs']
for _,r in records:assert r['inputs']==manifest
for row in manifest:assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256']
result={'kind':'G04_G05_WINDOWS_CPU_ONLY_FFA_RELOCATED_STATIC_SHARED_SDK','verdict':'PASS_TWO_CONFIGURATIONS',
    'product_commit':next(iter(product)),'matrix':matrix,
    'qualified':['Actual Windows/MSVC CPU-only original ffa ggml profile, shipping HYLE_TESTING OFF; same existing producer tree switched static/shared explicitly, separate new installed and relocated prefixes',
        'Each installed configuration twelve changed HYLE public headers independently compile; actual thirteen new CPU encoder/finite attention tests and three independent Direct/Graph Q8 incremental F2 consumer tests PASS',
        'F16/BF16 query/output, independent D64/128 and main D256/256; byte/scale oracles, window/noncausal, direct compressed pages, single/multi, six delta updates, two actual Graph producer shapes, accepted failure/no publication, original reader/shared/history permissions',
        'External consumer compile commands use installed HYLE headers only; all selected shipping product compile commands have no HYLE_TESTING. Actual installed library hashes retained'],
    'limits':['No two-independent-producer-trees claim','No new P1, native private-pool upper bound or whole G04/G05/G01-G10 acceptance'],
    'runs':[dict(tag=tag,**{k:v for k,v in r.items() if k!='inputs'}) for tag,r in records],
    'input_manifest_sha256':hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest(),
    'cumulative_seconds':sum(r['cumulative_seconds'] for _,r in records)}
OUT.mkdir(parents=True,exist_ok=False)
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as raw:
    for file in sorted(RUN.iterdir()):
        if file.is_file():raw.write(file,file.name)
    for name in ('encoded_cpu_sdk.py','seal_cpu_sdk.py'):raw.write(BASE/name,'runners/'+name)
    for name in ('tests/compute_batch/encoded_page_common_consumer.cc','tests/compute_provider_ggml/native_paged_test.cc','tests/compute_provider_native/half_test_support.h'):
        raw.write(ROOT/name,'public-fixtures/'+name)
print(json.dumps({'verdict':result['verdict'],'cumulative_seconds':result['cumulative_seconds'],'raw_bytes':(OUT/'raw.zip').stat().st_size}))
