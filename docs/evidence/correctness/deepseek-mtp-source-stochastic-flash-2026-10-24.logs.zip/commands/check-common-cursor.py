from pathlib import Path
import json,subprocess,sys,time,hashlib
R=Path.cwd();O=R/'.scratch/dspark-random-mtp-20261024/cursor';O.mkdir(exist_ok=True)
s=Path('tests/tools/qwen_prefix_cache_test.cc').read_text(encoding='utf-8');a=s.index('void sampling_cursor_addresses_are_transactional()');b=s.index('\nvoid sampling_wrappers_share_one_state_version()',a);body=s[a:b]
(O/'check.cc').write_text('#include "engine/inference/sampling_cursor.h"\n#include <iostream>\nnamespace p=hyle::inference;\nint checks=0;\nvoid require(bool v,const char *m){if(!v)throw std::runtime_error(m);++checks;}\n'+body+'\nint main(){sampling_cursor_addresses_are_transactional();std::cout<<checks<<" cursor checks PASS\\n";}\n',encoding='utf-8')
sys.path.insert(0,str(R/'scripts'));from hyle_environment import discover_environment
cc=json.loads((O.parent/'compile-command.json').read_text(encoding='utf-8'))[0];env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[cc,'/nologo','/std:c++latest','/EHsc','/O2','/MD','/W4','/WX','/utf-8','/I'+str(R),str(O/'check.cc'),'/Fo'+str(O/'check.obj'),'/Fe'+str(O/'check.exe')]
(O/'command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8')
p=subprocess.run(cmd,env=env,capture_output=True);(O/'compile.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr)
p=subprocess.run([str(O/'check.exe')],env=env,capture_output=True);(O/'run.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0
(O/'result.json').write_text(json.dumps(dict(exit=p.returncode,source_function_sha256=hashlib.sha256(body.encode()).hexdigest(),header_sha256=hashlib.sha256((R/'engine/inference/sampling_cursor.h').read_bytes()).hexdigest(),checks=6,SDK_builds=0,model_runs=0,HTTP=0)),encoding='utf-8');print(p.stdout.decode())
