#include "engine/inference/sampling_cursor.h"
#include <iostream>
namespace p=hyle::inference;
int checks=0;
void require(bool v,const char *m){if(!v)throw std::runtime_error(m);++checks;}
void sampling_cursor_addresses_are_transactional() {
  const p::SamplingCursor base{0x1111111122222222ULL, 0x3333333344444444ULL, 0xffffffffULL};
  require(base.identity() == std::array<std::uint32_t,4>{0x66666666u,0x22222222u,0xffffffffu,0u},
      "sampling key and draw words must preserve the explicit 64-bit address");
  require(base.identity(1) == std::array<std::uint32_t,4>{0x66666666u,0x22222222u,0u,1u},
      "draw offsets must carry into the high address word");
  const auto candidate = base.advanced(3);
  require(candidate.seed == base.seed && candidate.stream == base.stream && candidate.draw == 0x100000002ULL,
      "advancing a candidate must preserve its seed/stream");
  require(base.draw == 0xffffffffULL && base.identity() != candidate.identity(),
      "preparing or abandoning a candidate must not publish its cursor");
  const auto maximum = (std::numeric_limits<std::uint64_t>::max)();
  const p::SamplingCursor exhausted{7,13,maximum};
  require(exhausted.advanced(0) == exhausted && exhausted.identity()[2] == UINT32_MAX &&
      exhausted.identity()[3] == UINT32_MAX, "the final exact draw address remains representable");
  bool identity_rejected = false, advance_rejected = false;
  try { (void)exhausted.identity(1); } catch (const std::runtime_error &) { identity_rejected = true; }
  try { (void)exhausted.advanced(1); } catch (const std::runtime_error &) { advance_rejected = true; }
  require(identity_rejected && advance_rejected && exhausted.draw == maximum,
      "address/commit overflow must reject without mutating the original cursor");
}

int main(){sampling_cursor_addresses_are_transactional();std::cout<<checks<<" cursor checks PASS\n";}
