from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
helper_path = R/'.scratch/inference-synchronous-step-report-20261025/check_host.py'
spec = importlib.util.spec_from_file_location('retained_host_runner', helper_path)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
out = W/(sys.argv[1] if len(sys.argv)>1 else 'host1')
assert not out.exists()
recipe = json.loads((R/'.scratch/inference-current-closure-20261026/engine/report/command.json').read_text())
compiler = recipe['command'][0]
env = h.discover_environment(compiler='msvc', cache={
    'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
source = R/'tests/tools/inference_batch_dispatch_test.cc'
header = R/'engine/inference/batch_dispatch.h'
before = [h.pin(p) for p in [source, header, R/'engine/inference/batch_indices.h']]
native = R/'.scratch/build-compute-v2-dev/bin/mimalloc_static.lib'
native_pin = h.pin(native)
compile_dir = out/'compile'
command = [compiler, '/nologo', '/std:c++latest', '/EHsc', '/Zc:__cplusplus', '/Zc:preprocessor',
    '/utf-8', '/O2', '/Ob2', '/MD', '/permissive-', '/W4', '/WX', '/DHYLE_STATIC', '/DNOMINMAX',
    '/wd4324', '/I'+str(R/'include'), '/I'+str(R), '/c', str(source),
    '/sourceDependencies', str(compile_dir/'dependencies.json'),
    '/Fo'+str(compile_dir/'unit.obj'), '/Fd'+str(compile_dir/'unit.pdb')]
compiled = h.execute(command, env, compile_dir)
dep = json.loads((compile_dir/'dependencies.json').read_text(encoding='utf-8-sig'))['Data']
actual = [h.pin(Path(p)) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]
h.save(out/'actual-dependencies.json', actual)
assert not any('cuda' in x['path'].casefold() or 'ggml' in x['path'].casefold() for x in actual)
assert [h.pin(Path(x['path'])) for x in before] == before
link = Path(compiler).with_name('link.exe')
image = out/'link/inference_batch_dispatch_test.exe'
linked = h.execute([str(link), '/NOLOGO', '/INCREMENTAL:NO', '/OPT:REF', '/OPT:ICF',
    str(compile_dir/'unit.obj'), str(native), 'bcrypt.lib', 'psapi.lib', 'advapi32.lib',
    '/OUT:'+str(image), '/PDB:'+str(out/'link/test.pdb')], env, out/'link')
assert h.pin(native) == native_pin
ran = h.execute([str(image)], env, out/'run', timeout=30)
assert (out/'run/stdout.log').read_text().strip() == 'inference_batch_dispatch: PASS (5 host contracts)'
h.save(out/'summary.json', dict(status='FINITE_BATCH_CORE_HOST_PASS', source_pins=before,
    dependencies=h.pin(out/'actual-dependencies.json'), compile=compiled, link=linked, run=ran,
    image=h.pin(image), reused_native_allocator=native_pin, compiled_TUs=1,
    Model_GPU_SDK_builds=0, model_runs=0,
    limits=['Five finite host contracts, not a Model/GPU/numerical or TPS result.',
            'Repeated waves check stable pre-reserved selection storage and zero C++ operator-new calls. The hook does not count mimalloc backend calls; source bounds and unchanged selected storage establish index reuse.']))
print('HOST_READY', json.dumps(h.pin(out/'summary.json')), flush=True)
