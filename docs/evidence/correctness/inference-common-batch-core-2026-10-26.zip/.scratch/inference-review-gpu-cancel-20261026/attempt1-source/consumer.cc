#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_e4_cache_case.h"
#include "engine/models/qwen35/native_gate.cc"
#include "gpu-case.h"
int main(int argc,char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("usage: e4-gpu-cancel INPUTS");
    return e4_gpu_cancel::run(argv[1]);
  } catch (const std::exception &error) {
    std::cerr << "gpu_cancel_failure=" << error.what() << '\n'; return 1;
  }
}
