"""Root launches one bounded original native subprocess; no profiling/download."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

W=Path(__file__).resolve().parent
R=W.parents[1]
ready=json.loads((W/'ready.json').read_text())
runtime=json.loads(Path(ready['runtime']['path']).read_text())
for field in ['image','native','fixture']:
    pin=ready[field]
    with Path(pin['path']).open('rb') as stream:
        assert hashlib.file_digest(stream,'sha256').hexdigest()==pin['sha256']
env=os.environ.copy()
env.update(runtime.get('configured_flags',{}))
env.update(PATH=str(Path(ready['image']['path']).parent)+';'+runtime['PATH'],
    HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
F=W/'run1';F.mkdir()
started=time.perf_counter()
with (F/'stdout.log').open('xb') as out,(F/'stderr.log').open('xb') as err:
    child=subprocess.Popen(ready['run'],cwd=R,env=env,stdout=out,stderr=err,
        creationflags=subprocess.CREATE_NO_WINDOW)
    print('GPU_CANCEL_NATIVE_PID',child.pid,flush=True)
    timed_out=False
    try: code=child.wait(timeout=90)
    except subprocess.TimeoutExpired:
        timed_out=True; child.kill(); code=child.wait(timeout=10)
record=dict(pid=child.pid,exit=code,timeout=timed_out,seconds=time.perf_counter()-started,
    command=ready['run'],image=ready['image'],native=ready['native'],fixture=ready['fixture'],
    scope='Generated ordinary AA/E4 CUDA physical-pending single-member and whole-batch cancellation; no full-model/performance claim.')
(F/'process.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(json.dumps(record,indent=2)); print((F/'stdout.log').read_text())
assert code==0 and not timed_out,'Actual native failure retained; inspect without overwriting'
