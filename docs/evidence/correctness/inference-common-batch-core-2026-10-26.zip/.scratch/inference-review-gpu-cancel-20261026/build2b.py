"""Second finite CUDA wrapper: exact same-shape actual warmup + flushed phase/route facts.

Prepare only after root freezes canonical source: build.py plan; build.py build.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-review-fixes-20261026'
B = R / '.scratch/inference-result-publication-screen-20261026/candidate'
FIXTURE = R / '.scratch/inference-e4-model-20261025/fixture-preparation/ct-e4-aa'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes((json.dumps(value, indent=2) + '\n').encode('utf-8'))


def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest)


def exact(row):
    assert pin(row['path']) == row, row['path']


def key(path):
    return str(path).replace('/', '\\').casefold()


def reused():
    path = OLD / 'build.py'
    spec = importlib.util.spec_from_file_location('prior_review_builder', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def plan():
    assert not (W / 'plan2b.json').exists(), 'Freeze each source plan once'
    prior = reused()
    baseline = read(B / 'ready.json')
    inputs = read(baseline['link_inputs']['path'])
    replaced_model = next(x for x in inputs if key(x['path']).endswith('inference-sampling-three-arm-20261026\\batch\\compile\\unit.obj'))
    removed_entry = next(x for x in inputs if key(x['path']).endswith('inference-current-closure-20261026\\engine\\entry\\unit.obj'))
    replaced_report = next(x for x in inputs if key(x['path']).endswith('inference-current-closure-20261026\\engine\\report\\unit.obj'))
    report = read(OLD / 'product2/report/result.json')['object']
    exact(report)
    recipe = R / '.scratch/inference-current-closure-20261026/engine/model/command.json'
    command = prior.compile_command(recipe, W / 'source2b/consumer.cc', W / 'compile2b')
    assert '/DHYLE_COMPUTE_CUDA=1' in command
    assert not any('NVTX' in arg for arg in command)
    closure = prior.quoted_project_closure([
        R / 'engine/models/qwen35/main.cc',
        R / 'tests/tools/qwen_e4_cache_case.h',
        R / 'engine/models/qwen35/native_gate.cc',
    ])
    closure.extend([pin(W / 'source2b/consumer.cc'), pin(W / 'source2b/gpu-case.h')])
    save(W / 'source2b-freeze.json', closure)
    link_command = []
    for arg in read(B / 'link/command.json')['command']:
        if key(arg) == key(replaced_model['path']): arg = str(W / 'compile2b/unit.obj')
        elif key(arg) == key(removed_entry['path']): continue
        elif key(arg) == key(replaced_report['path']): arg = report['path']
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:' + str(W / 'link2b/e4-gpu-cancel.exe')
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:' + str(W / 'link2b/e4-gpu-cancel.pdb')
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:' + str(W / 'link2b/e4-gpu-cancel.lib')
        elif arg.upper().startswith('/MAP:'): continue
        link_command.append(arg)
    removed = {key(replaced_model['path']), key(removed_entry['path']), key(replaced_report['path'])}
    for row in inputs:
        if key(row['path']) not in removed: exact(row)
    save(W / 'plan2b.json', dict(status='SOURCE_FROZEN_NOT_BUILT',
        source=pin(W / 'source2b/consumer.cc'), private_case=pin(W / 'source2b/gpu-case.h'),
        script=pin(__file__), helper=pin(OLD / 'build.py'), recipe=pin(recipe),
        command=command, link_command=link_command, source_freeze=pin(W / 'source2b-freeze.json'),
        baseline=pin(B / 'ready.json'), baseline_link_inputs=baseline['link_inputs'],
        baseline_link_command=pin(B / 'link/command.json'), baseline_runtime=baseline['runtime'],
        replaced_model=replaced_model, removed_entry=removed_entry, replaced_report=replaced_report, report=report,
        fixture_manifest=pin(FIXTURE / 'weights.tsv'),
        run=[str(W / 'link2b/e4-gpu-cancel.exe'), str(FIXTURE)],
        scope='Second finite generated AA/E4 CUDA R2/T2 attempt: one original full warmup and retirement before the unchanged real same-queue callback gate/native event pending proofs. Greedy and no full-model/performance ranking.',
        prior_failure=pin(W / 'run1/process.json'), diagnosis=pin(W / 'failure1-diagnosis.json'),
        warmup='One same R2/T2 original Model prepare/submit/finish, both publications and normal Session retirement; planned R2 uses6. No Completion or native permission bypass.',
        logging='Flushed elapsed phase markers and actual replay/input-source dependency routes; canonical gate watchdog remains30s and subprocess90s.',
        limits=['Exactly one host consumer TU including canonical Model and existing native_gate.cc; retained CUDA closure/native libraries reused.',
                'No SDK, CUDA device/provider/Graph rebuild, model fetch or inference run during build.']))
    print('GPU_CANCEL_PLAN', json.dumps(pin(W / 'plan2b.json')), flush=True)


def build():
    assert not (W / 'compile2b').exists() and not (W / 'ready2.json').exists()
    plan = read(W / 'plan2b.json')
    for field in ['source', 'private_case', 'helper', 'recipe', 'source_freeze',
                  'baseline', 'baseline_link_inputs', 'baseline_link_command', 'baseline_runtime', 'report', 'fixture_manifest']:
        exact(plan[field])
    frozen = {key(row['path']): row for row in read(W / 'source2b-freeze.json')}
    for row in frozen.values(): exact(row)
    inputs = read(plan['baseline_link_inputs']['path'])
    removed = {key(plan[name]['path']) for name in ['replaced_model', 'removed_entry', 'replaced_report']}
    for row in inputs:
        if key(row['path']) not in removed: exact(row)
    runner = reused().helper()
    compiler = plan['command'][0]
    env = runner.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'}, backends=()).env
    compiled = runner.execute(plan['command'], env, W / 'compile2b', timeout=120)
    dependencies = read(W / 'compile2b/dependencies.json')['Data']
    actual = [pin(path) for path in dict.fromkeys([dependencies['Source'], *dependencies['Includes']])]
    for row in actual:
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch') or path in [W/'source2b/consumer.cc',W/'source2b/gpu-case.h']:
            assert key(path) in frozen and row['sha256'] == frozen[key(path)]['sha256'], row
    save(W / 'compile2b/actual-dependencies.json', actual)
    for row in frozen.values(): exact(row)
    obj = pin(W / 'compile2b/unit.obj')
    final_inputs = [obj if key(row['path']) == key(plan['replaced_model']['path']) else plan['report']
        if key(row['path']) == key(plan['replaced_report']['path']) else row
        for row in inputs if key(row['path']) != key(plan['removed_entry']['path'])]
    linked = runner.execute(plan['link_command'], env, W / 'link2b', timeout=120)
    for row in final_inputs: exact(row)
    save(W / 'link2b-inputs.json', final_inputs)
    runtime = read(plan['baseline_runtime']['path'])
    exact(runtime['native'])
    alias = W / 'link2b' / Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = pin(alias)
    save(W / 'runtime2b.json', runtime)
    save(W / 'ready2.json', dict(status='FINITE_CUDA_GPU_CANCEL_BUILT_NOT_RUN',
        image=pin(W / 'link2b/e4-gpu-cancel.exe'), compile=compiled, link=linked,
        runtime=pin(W / 'runtime2b.json'), source_freeze=plan['source_freeze'],
        plan=pin(W / 'plan2b.json'), link_inputs=pin(W / 'link2b-inputs.json'), native=pin(alias),
        fixture=plan['fixture_manifest'], run=plan['run'], compiled_host_TUs=1,
        reused_report=plan['report'], SDK_device_Graph_provider_builds=0, model_runs=0))
    print('GPU_CANCEL_READY', json.dumps(pin(W / 'ready2.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']: plan()
    elif sys.argv[1:] == ['build']: build()
    else: raise SystemExit(__doc__)
