#pragma once

// Finite physical-pending check of the canonical ordinary Model path. The
// fixture is generated AA/E4, not a trained model or a throughput workload.
namespace e4_gpu_cancel {
namespace q = qwen35;
namespace c = q::c;
using qwen_e4_cache_case::require;

inline void phase(std::string_view name) {
  static const auto origin = std::chrono::steady_clock::now();
  std::cerr << "gpu_cancel_phase=" << name << " elapsed_seconds="
      << std::chrono::duration<double>(std::chrono::steady_clock::now()-origin).count() << std::endl;
}
inline void routes(q::Model &model, const char *name) {
  const auto report=q::take(model.active_step->run->replay_report());
  const auto inputs=q::take(model.active_step->run->input_source_report());
  std::cerr << "gpu_cancel_routes=" << name << " route=" << static_cast<unsigned>(report.route)
      << " ordered=" << report.ordered_dependency_count
      << " synchronous_source=" << report.synchronous_source_dependency_count
      << " device_wait=" << report.device_wait_dependency_count
      << " host_wait=" << report.host_wait_dependency_count
      << " immediate_transfers=" << report.immediate_transfer_count
      << " queued_transfers=" << report.queued_transfer_count
      << " input_sources=" << inputs.source_count << " input_host_wait=" << inputs.host_wait_count
      << " input_device_wait=" << inputs.device_wait_count << std::endl;
}

inline void native(cudaError_t code) {
  if (code != cudaSuccess) throw std::runtime_error(cudaGetErrorString(code));
}

struct PendingProof final {
  q::probe::NativeGate gate;
  c::Context &context;
  cudaEvent_t event = nullptr;
  explicit PendingProof(q::Model &model)
      : gate(model.execution), context(*q::take(model.execution.common_context())) {
    native(cudaEventCreateWithFlags(&event, cudaEventDisableTiming));
  }
  ~PendingProof() {
    gate.release();
    // Retire actual work before destroying the borrowed native event. The
    // subprocess watchdog is the last resort if the original device fails.
    const auto retired = context.drain();
    if (retired.ok()) (void)cudaEventDestroy(event);
    else std::cerr << "gpu_cancel_native_owner_retained=" << retired.message() << '\n';
  }
  void arm() {
    phase("gate.before_arm"); q::check(gate.arm()); phase("gate.armed");
    q::check(gate.wait_until_entered()); phase("gate.callback_entered");
  }
  c::Completion marker(q::Model &model) {
    phase("marker.before_submit");
    auto result=q::take(c::cuda::submit(*q::take(model.execution.common_queue()),
        [&](cudaStream_t stream) noexcept { return cudaEventRecord(event, stream); }));
    phase("marker.after_submit"); return result;
  }
  void require_pending(const c::Completion &completion) {
    require(!gate.timed_out(), "native gate watchdog released before assertion");
    require(cudaEventQuery(event) == cudaErrorNotReady,
        "same original CUDA queue post-submission event was not physically pending");
    require(q::take(completion.poll()) == c::CompletionPoll::kPending,
        "original Model completion was not pending behind its native queue gate");
  }
  void release(c::Completion &marker) {
    require(!gate.timed_out(), "native gate watchdog, rather than this test, released the queue");
    phase("gate.before_explicit_release"); gate.release();
    q::check(marker.wait()); marker = {}; phase("marker.retired");
    q::check(gate.wait()); phase("gate.retired");
    require(!gate.timed_out(), "native gate timed out");
  }
};

inline int run(const std::filesystem::path &input) {
  auto source = q::prepare_weight_source(input / "weights.tsv", false);
  const auto geometry = source.roles.geometry;
  require(geometry.layers == "AA" && geometry.hidden == 64 && geometry.key_depth == 64 &&
      geometry.value_depth == 64 && geometry.kv_heads == 1 && geometry.mtp_layers == 0 &&
      source.cache_row_bytes == q::cache::KvRowBytes{64,64} && source.roles.cache_calibration.size() == 4,
      "requires cached generated ordinary AA/H64/D64 E4 fixture with four original scales");
  const auto plan = q::cache::plan(geometry, source.cache_row_bytes, 16, 4, 8,
      q::recurrent_bytes(q::state_schema_for(geometry, 16), geometry), 2);
  q::Model model(std::move(source), geometry, 16, plan, {}, false,
      q::ReplayPolicy::kCommands, 16u << 20, {false, {}, 0}, 0,
      {.primary=q::BackendKind::kCuda});
  const std::array rows{std::size_t{1}, std::size_t{2}};
  model.prepare_family(rows); model.prepare_family(rows, false, 2);
  for (const auto n : rows) { model.plan_replay_uses(n, 1, 4); model.plan_replay_uses(n, 2, 6); }
  model.prepare_execution(rows); model.prepare_execution(rows, 2);
  const std::array<std::int32_t,2> prompt{1,2};
  phase("warmup.begin");
  {
    // Actual math on the exact same original R2/T2 carrier comes before any
    // blocker. Cold prepare alone does not instantiate every native handle,
    // module or temporary-pool demand triggered by the first real submit.
    auto a=model.create_session(rows),b=model.create_session(rows);
    const std::array inputs{q::EvaluationRequest{a,prompt},q::EvaluationRequest{b,prompt}};
    model.prepare_evaluations(inputs); routes(model,"warmup_R2_T2");
    phase("warmup.before_model_submit"); model.submit_evaluations(); phase("warmup.after_model_submit");
    std::array disposition{q::EvaluationDisposition::kNotPublished,q::EvaluationDisposition::kNotPublished};
    const std::array outputs{q::EvaluationOutput{.session=a,.disposition=&disposition[0]},
        q::EvaluationOutput{.session=b,.disposition=&disposition[1]}};
    std::array<std::int32_t,2> next{}; std::size_t observers=0;
    model.finish_evaluations(outputs,next,[&](std::size_t member,const q::CompletedEvaluationView &view) {
      require(member<2 && view.member_index==member && view.requests==2,"warmup observer lost its original two-member batch"); ++observers;
    });
    require(observers==2 && disposition[0]==q::EvaluationDisposition::kPublished && disposition[1]==q::EvaluationDisposition::kPublished &&
        a->length()==2 && b->length()==2 && !model.active_step,"actual R2/T2 warmup did not normally publish both members");
    phase("warmup.finished"); qwen_e4_cache_case::retire(a); qwen_e4_cache_case::retire(b);
  }
  q::check(q::take(model.execution.common_context())->drain());
  require(!model.snapshot_versions.live && !model.active_step && !model.carrier_borrowed,
      "actual R2/T2 warmup did not normally retire all Session/Invocation owners");
  phase("warmup.retired");
  {
    auto a = model.create_session(rows), b = model.create_session(rows);
    const auto old_a = a->head, old_b = b->head;
    const auto boundary_a = q::generation_boundary(*old_a);
    q::GenerationLedger ledger_a(2,1), ledger_b(2,1);
    q::prepare_generation_record(ledger_a,*a,q::GraphRole::kText,prompt,false,0,0);
    q::prepare_generation_record(ledger_b,*b,q::GraphRole::kText,prompt,false,0,0);
    const std::array inputs{q::EvaluationRequest{a,prompt},q::EvaluationRequest{b,prompt}};
    phase("partial.before_prepare"); model.prepare_evaluations(inputs); routes(model,"partial_R2_T2");
    const auto *episode = model.active_step.get();
    const auto candidate_b = episode->members[1].next.get();
    const auto charged = model.snapshot_versions.live;
    PendingProof proof(model); proof.arm(); phase("partial.before_model_submit");
    model.submit_evaluations(); phase("partial.after_model_submit");
    auto marker = proof.marker(model); proof.require_pending(episode->completion);
    phase("partial.pending_proven"); q::check(a->stop());
    const auto try_a = a->try_retire(), drain_a = a->drain(), drain_b = b->drain();
    q::check(try_a.status); q::check(drain_a.status); q::check(drain_b.status);
    require(!try_a.retired && !drain_a.retired && !drain_b.retired &&
        model.active_step.get() == episode && !episode->cancelled && episode->discard_stopped_members &&
        a->pending == episode && b->pending == episode && a->head == old_a && b->head == old_b &&
        episode->members[1].next.get() == candidate_b && model.snapshot_versions.live == charged && model.carrier_borrowed,
        "stopped member retired or aborted/published its physically pending survivor");
    proof.require_pending(episode->completion); phase("partial.stopped_still_native_pending");
    proof.release(marker);
    std::array disposition{q::EvaluationDisposition::kNotPublished,q::EvaluationDisposition::kNotPublished};
    const std::array outputs{
      q::EvaluationOutput{.session=a,.generation_ledger=&ledger_a,.disposition=&disposition[0]},
      q::EvaluationOutput{.session=b,.generation_ledger=&ledger_b,.disposition=&disposition[1]}};
    std::array<std::int32_t,2> next{}; std::size_t observers=0;
    phase("partial.before_finish"); model.finish_evaluations(outputs,next,[&](std::size_t member,const q::CompletedEvaluationView &view) {
      require(member==1 && view.member_index==1 && view.requests==2,"cancelled member reached publication observer"); ++observers;
    });
    require(disposition[0]==q::EvaluationDisposition::kCancelled && disposition[1]==q::EvaluationDisposition::kPublished && observers==1 &&
        a->head==old_a && q::generation_boundary(*a->head)==boundary_a && !ledger_a.committed_count &&
        !ledger_a.records[0].committed && ledger_a.records[0].ids().empty() && b->head.get()==candidate_b &&
        b->length()==2 && b->head->next_id==next[1] && ledger_b.committed_count==1 &&
        !model.active_step && !a->pending && !b->pending,"partial cancellation lost original survivor or published cancelled state");
    phase("partial.finished_original_survivor"); const auto retired=a->try_retire(); q::check(retired.status); require(retired.retired && !a->head,"stopped A did not actually retire"); a.reset();
    const std::array token{next[1]}; (void)q::evaluate(model,*b,token,"gpu-survivor-next",{},false);
    require(b->length()==3,"original survivor could not continue"); qwen_e4_cache_case::retire(b);
  }
  {
    auto a=model.create_session(rows),b=model.create_session(rows);
    const auto old_a=a->head,old_b=b->head;
    const std::array inputs{q::EvaluationRequest{a,prompt},q::EvaluationRequest{b,prompt}};
    phase("all_cancel.before_prepare"); model.prepare_evaluations(inputs); routes(model,"all_cancel_R2_T2");
    PendingProof proof(model); proof.arm(); phase("all_cancel.before_model_submit");
    model.submit_evaluations(); phase("all_cancel.after_model_submit");
    auto marker=proof.marker(model); proof.require_pending(model.active_step->completion);
    phase("all_cancel.pending_proven"); (void)a->stop(); (void)b->stop();
    require(model.active_step && model.active_step->cancelled && a->head==old_a && b->head==old_b,
        "all-member cancellation did not keep whole-episode cancellation before native retirement");
    require(cudaEventQuery(proof.event)==cudaErrorNotReady && !proof.gate.timed_out(),
        "all-cancel was not physically pending");
    proof.release(marker);
    phase("all_cancel.before_abort"); const auto retired=model.abort_episode(); if (!retired.status.IsCancelled()) q::check(retired.status);
    require(retired.retired && !model.active_step && a->head==old_a && b->head==old_b && !a->pending && !b->pending,
        "all-cancel published or failed actual native retirement");
    for (auto *owner : {&a,&b}) { const auto done=(*owner)->try_retire(); if (!done.status.IsCancelled()) q::check(done.status);
      require(done.retired,"cancelled Session did not retire"); owner->reset(); }
  }
  require(!model.snapshot_versions.live && !model.active_step && !model.carrier_borrowed,
      "controlled GPU cancellation retained versions or carrier");
  phase("complete");
  std::cout << "{\"status\":\"PASS\",\"backend\":\"cuda\",\"generated_AA_E4_fixture\":true,"
    "\"actual_R2_T2_warmup_finished_retired\":true,\"native_callback_entered\":true,\"native_event_not_ready_before_and_after_stop\":true,"
    "\"original_completion_pending\":true,\"single_member_discard\":true,\"same_survivor_candidate\":true,"
    "\"cancelled_head_rng_ledger_unchanged\":true,\"survivor_continues\":true,\"all_cancel_abort\":true,"
    "\"final_versions\":0,\"greedy_only\":true,\"model_quality\":false,\"performance_claim\":false,\"HTTP\":0}\n";
  return 0;
}
} // namespace e4_gpu_cancel
