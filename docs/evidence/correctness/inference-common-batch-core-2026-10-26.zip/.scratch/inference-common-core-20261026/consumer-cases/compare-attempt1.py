"""Offline full stdout JSON comparison only; does not launch any program."""
import argparse, hashlib, json, math
from pathlib import Path

def no_duplicates(pairs):
    out={}
    for key,value in pairs:
        if key in out: raise ValueError('duplicate JSON key: '+key)
        out[key]=value
    return out

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'),object_pairs_hook=no_duplicates,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON: '+value)))

def time_paths(doc,case):
    paths=set()
    def add(prefix,names):
        for name in names.split(): paths.add(prefix+(name,))
    if case=='natural':
        add((), 'restore_step_seconds restore_seconds prefill_seconds decode_seconds session_seconds step_sum_seconds participation_step_sum_seconds post_endpoint_seconds startup_total_seconds startup_to_endpoint_seconds startup_to_ready_seconds first_token_elapsed_seconds prefill_tokens_per_second decode_output_tokens_per_second output_tokens_per_second')
        for i,session in enumerate(doc['sessions']):
            p=('sessions',i,'result')
            add(p,'prefill_seconds decode_seconds session_seconds startup_total_seconds startup_to_endpoint_seconds startup_to_ready_seconds first_token_elapsed_seconds prefill_step_seconds decode_step_sum_seconds step_sum_seconds prefill_tokens_per_second decode_output_tokens_per_second output_tokens_per_second between_turn_seconds')
            for j,_ in enumerate(session['result']['turns']): add(p+('turns',j),'prefill_seconds decode_seconds')
    else:
        add((),'interleaved_seconds startup_total_seconds step_sum_seconds')
        for i,session in enumerate(doc['sessions']):
            p=('sessions',i)
            add(p,'session_seconds startup_total_seconds step_sum_seconds cache_prepare_seconds')
            for j,_ in enumerate(session['phases']): add(p+('phases',j),'seconds step_sum_seconds')
        for key in ('batches','waves'):
            for i,_ in enumerate(doc[key]): add((key,i),'seconds')
    for path in paths:
        value=doc
        for part in path: value=value[part]
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0:
            raise ValueError('invalid time value at '+repr(path))
    return paths

def normalize(node,excluded,path=()):
    if isinstance(node,dict):return {key:normalize(value,excluded,path+(key,)) for key,value in node.items() if path+(key,) not in excluded}
    if isinstance(node,list):return [normalize(value,excluded,path+(i,)) for i,value in enumerate(node)]
    return node

def same(a,b,path='$'):
    if type(a) is not type(b): raise AssertionError(f'{path}: JSON type differs ({type(a).__name__}/{type(b).__name__})')
    if isinstance(a,dict):
        if a.keys()!=b.keys():raise AssertionError(f'{path}: keys differ ({set(a)^set(b)})')
        for key in a:same(a[key],b[key],path+'/'+key)
    elif isinstance(a,list):
        if len(a)!=len(b):raise AssertionError(f'{path}: array lengths differ {len(a)}/{len(b)}')
        for i,(x,y) in enumerate(zip(a,b)):same(x,y,path+'/'+str(i))
    elif a!=b:raise AssertionError(f'{path}: {a!r} != {b!r}')

def coverage(doc,case,backend):
    assert doc['session_count']==4 and doc['active_sequences']==3
    assert doc['backend']==backend and doc['sampling']=='greedy' and doc['kv_cache_dtype']=='E4M3FN'
    assert doc['ct_channel_token_groups']==1
    assert [row['session_id'] for row in doc['sessions']]==['A','B','C','D']
    assert doc['prefix_hits']>=1 and doc['reused_tokens']>=2, 'expected cross-cohort partial prefix reuse absent; retain failure, do not weaken comparison'
    if case=='natural':
        assert doc['mtp'] is False and doc['turn_count']==7
        assert doc['requested_output_tokens']==14 and doc['generated_tokens']==14
        assert doc['generated_decode_tokens']==7 and doc['logical_user_prompt_tokens']==16 and doc['pending_flushed_tokens']==3
        assert [len(row['result']['turns']) for row in doc['sessions']]==[2,2,1,2]
        assert [row['result']['generated_tokens'] for row in doc['sessions']]==[5,4,1,4]
        assert [row['result']['visible_tokens'] for row in doc['sessions']]==[7,8,2,9]
        assert {1,2}<={row['requests'] for row in doc['batches']}
        assert {1,2,3}<={row['tokens'] for row in doc['batches']}
        for row in doc['sessions']:
            assert all(0<=token<64 for token in row['result']['generated_ids'])
            assert row['ledger'] and all(item['input_rows']>0 for item in row['ledger'])
    else:
        assert doc['execution']=='equal_T_batched' and doc['generated_tokens']==18 and doc['processed_tokens']==28
        assert [row['turn_count'] for row in doc['sessions']]==[2,2,1,2]
        assert [row['visible_tokens'] for row in doc['sessions']]==[8,7,3,10]
        assert doc['max_batch_requests']==3
        assert {1,2,3}<={row['requests'] for row in doc['batches']}
        assert {1,2,3}<={row['query_rows'] for row in doc['batches']}
        for row in doc['sessions']:
            assert row['fixed_decode'] is True and all(0<=token<64 for token in row['generated_ids'])
    return {'session_ids':['A','B','C','D'],'seven_turns':True,'mixed_T':True,'R1_R2':True,'partial_prefix_reuse_rows':doc['reused_tokens'],'all_reported_token_state_cache_batch_facts_compared':True}

def main():
    p=argparse.ArgumentParser();p.add_argument('--backend',choices=['cpu','cuda'],required=True);p.add_argument('case',choices=['natural','teacher']);p.add_argument('baseline',type=Path);p.add_argument('candidate',type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args()
    baseline=load(a.baseline);candidate=load(a.candidate)
    paths_a=time_paths(baseline,a.case);paths_b=time_paths(candidate,a.case)
    assert paths_a==paths_b,'time path shape changed'
    left=normalize(baseline,paths_a);right=normalize(candidate,paths_b);same(left,right)
    facts=coverage(baseline,a.case,a.backend);same(facts,coverage(candidate,a.case,a.backend))
    canonical=json.dumps(left,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n'
    excluded=['/'+('/'.join(map(str,path))) for path in sorted(paths_a,key=lambda path:tuple(map(str,path)))]
    receipt={'status':'PASS','case':a.case,'backend':a.backend,'method':'Exact JSON types, all remaining keys/values, full arrays and order; no tolerance and no token grep. Only these exact paths excluded. Raw stdout and stderr remain untouched.','excluded_time_paths':excluded,'coverage':facts,'non_time_facts_sha256':hashlib.sha256(canonical.encode()).hexdigest(),'baseline':{'path':str(a.baseline),'sha256':hashlib.sha256(a.baseline.read_bytes()).hexdigest()},'candidate':{'path':str(a.candidate),'sha256':hashlib.sha256(a.candidate.read_bytes()).hexdigest()}}
    a.out.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    a.out.with_suffix('.facts.json').write_text(json.dumps(left,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','case':a.case,'backend':a.backend,'excluded_time_fields':len(excluded),'coverage':facts}))
if __name__=='__main__':main()
