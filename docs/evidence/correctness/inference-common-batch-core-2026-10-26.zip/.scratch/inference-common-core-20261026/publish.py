"""Explicit small evidence capsule; root runs `publish` only after final results.

No builds, consumers, directory walks, dependency trees or binary/model payloads.
Update only the explicit final comparison/extra filenames if root uses others.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
H = R/'.scratch/inference-batch-core-20261026'
G = R/'.scratch/inference-review-gpu-cancel-20261026'
A = R/'.scratch/inference-architecture-audit-20261026'
C = W/'consumer-cases'
DEST = R/'docs/evidence/correctness/inference-common-batch-core-2026-10-26'
BASELINE = '6505c25f80ec7a3df7903919f248cc13e8953815'
SOURCES = ('engine/inference/batch_dispatch.h', 'engine/models/qwen35/main.cc',
           'tests/tools/inference_batch_dispatch_test.cc', 'tests/CMakeLists.txt')
COMPARISONS = ('natural/comparison.cuda.json', 'teacher/comparison.cuda.json')
EXTRA_FILES = ()  # Root may name additional retained failures here; never glob.
TOKEN_FILES = ('d1011.ids', 'd1415.ids', 'd34.ids', 'd78.ids', 'd8.ids', 'i12.ids', 'i15.ids',
               'p1112.ids', 'p12.ids', 'p121314.ids', 'p1289.ids', 'p12910.ids', 'p13.ids',
               'p345.ids', 'p5.ids', 'p56.ids', 'p67.ids', 'p91011.ids')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode('utf8')


def pin(path):
    data = Path(path).read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def publish():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    files = {}
    def add(path, required=True):
        path = Path(path)
        if not path.exists():
            if required: raise FileNotFoundError(path)
            return
        assert path.is_file() and path.is_relative_to(R)
        assert path.suffix.lower() in {'.json', '.txt', '.log', '.py', '.h', '.cc', '.tsv', '.schedule', '.ids'}
        assert path.stat().st_size < 2_000_000, path
        files[path.relative_to(R).as_posix()] = path
    for name in SOURCES: add(R/name)
    for name in ('publish.py', 'build.py', 'build-plan.json', 'ready.json', 'runtime.json', 'reused-report-abi.json'):
        add(W/name)
    for stage in ('compile', 'link'):
        for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(W/stage/name)
    add(H/'check_host.py'); add(H/'host1/summary.json')
    for stage in ('compile', 'link', 'run'):
        for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(H/'host1'/stage/name)
    for name in ('case-plan.json', 'commands.json', 'commands-cuda.json', 'cuda-setup-correction.json',
                 'compare.py', 'compare-attempt1.py', 'natural/comparison-attempt1.json', 'coverage-correction.json'): add(C/name)
    for name in TOKEN_FILES: add(C/'inputs'/name)
    for case in ('natural', 'teacher'):
        for name in ('sessions.tsv', 'A.schedule', 'B.schedule', 'C.schedule', 'D.schedule'): add(C/case/name)
    for name in ('batch-core-independent-review.json', 'steady-state-design.json'): add(A/name)
    process_records = []
    for case in ('natural', 'teacher'):
        for arm in ('baseline', 'candidate'):
            for attempt in (arm, arm+'.cuda'):
                required = attempt.endswith('.cuda')
                for ext in ('process.json', 'stdout.json', 'stderr.log'): add(C/case/(attempt+'.'+ext), required)
                p = C/case/(attempt+'.process.json')
                if p.exists(): process_records.append((f'CLI {case}/{attempt}', p, read(p)))
    comparisons = {}
    for name in COMPARISONS:
        p = C/name; add(p); add(p.with_suffix('.facts.json'), False); comparisons[name] = read(p)
    for name in ('build.py', 'build2.py', 'build2b.py', 'consumer.cc', 'gpu-case.h', 'run.py', 'run2.py',
                 'plan2b.json', 'ready.json', 'ready2.json', 'runtime2b.json', 'build-scope.json', 'build2-scope.json',
                 'source-review.json', 'failure1-diagnosis.json', 'compile2-failure.json', 'final-summary.json', 'reproduction-files.json',
                 'attempt1-source/build.py', 'attempt1-source/consumer.cc', 'attempt1-source/gpu-case.h',
                 'attempt1-source/run.py', 'source2/consumer.cc', 'source2/gpu-case.h',
                 'source2b/consumer.cc', 'source2b/gpu-case.h'):
        add(G/name)
    for stage in ('compile', 'link', 'compile2', 'compile2b', 'link2b'):
        for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(G/stage/name)
        p = G/stage/'process.json'; process_records.append(('GPU '+stage, p, read(p)))
    gpu = {}
    for attempt in ('run1', 'run2'):
        p = G/attempt/'process.json'
        for name in ('process.json', 'stdout.log', 'stderr.log'): add(G/attempt/name, attempt == 'run1' or p.exists())
        gpu[attempt] = read(p) if p.exists() else {'status': 'NOT_RUN', 'scope': 'No process receipt at publication.'}
        if p.exists(): process_records.append(('GPU '+attempt, p, gpu[attempt]))
    for name in EXTRA_FILES: add(R/name)
    ready = read(W/'ready.json'); host = read(H/'host1/summary.json')
    for source in [ready['source'], *host['source_pins']]:
        actual = pin(source['path']); assert actual['sha256'] == source['sha256'] and actual['bytes'] == source['bytes'], source['path']
    failures = [dict(scope=scope, process=pin(p), result=result) for scope,p,result in process_records
                if result.get('exit', 0) or result.get('timeout', False)]
    failures.append(dict(scope='Natural comparison first coverage assumption',
                         receipt=pin(C/'natural/comparison-attempt1.json'), result=read(C/'natural/comparison-attempt1.json')))
    summary = dict(status='BOUNDED_COMMON_BATCH_CORE_RESULTS', baseline_commit=BASELINE,
        publication_head=subprocess.run(['git','rev-parse','HEAD'], cwd=R, check=True, capture_output=True, text=True).stdout.strip(),
        sources=[pin(R/name) for name in SOURCES], baseline=ready['baseline'], candidate=ready['image'],
        host=host, CLI_comparisons=comparisons, GPU_attempts=gpu, GPU_final=read(G/'final-summary.json'), retained_failures=failures,
        architecture_review=read(A/'batch-core-independent-review.json'),
        steady_state_design=dict(status=read(A/'steady-state-design.json')['status'], implemented=False, benchmarked=False,
                                 receipt=pin(A/'steady-state-design.json')),
        scope='Static compatible-index traversal extraction. Five host contracts and exact finite CLI non-time report comparisons use generated AA/E4 weights; GPU pending/cancel checks have their own raw attempts.',
        limits=['No full-model quality, throughput or performance gain claim. CUDA-only product rejected the initial CPU CLI configuration; retain that failure.',
                'Each process/comparison reports its actual outcome. GPU run1 failed; its diagnosis is a hypothesis, not a successful pending/cancellation proof.',
                'Other model families, MTP runtime, Metal/Vulkan, CPU product build, overlap and server ingress are not established by this batch.',
                'Archive excludes executables, objects, PDBs, complete dependency manifests/trees, SDKs and model weights. Local paths/pins remain in receipts.'])
    patch = subprocess.run(['git','diff',BASELINE,'--',*SOURCES], cwd=R, check=True, capture_output=True).stdout
    manifest = [pin(p) | {'entry': name} for name,p in files.items()]
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name,p in files.items(): archive.write(p, name)
        archive.writestr('changed-sources.txt', patch)
        archive.writestr('manifest.json', encode(manifest))
    summary['archive'] = pin(DEST.with_suffix('.zip'))
    with DEST.with_suffix('.json').open('xb') as stream: stream.write(encode(summary))
    print(json.dumps(dict(summary=pin(DEST.with_suffix('.json')), archive=summary['archive'], files=len(files)), ensure_ascii=False))


if __name__ == '__main__':
    if sys.argv[1:] != ['publish']: raise SystemExit('Root only after complete results: python -B '+str(__file__)+' publish')
    publish()
