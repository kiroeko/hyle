"""One current canonical Model TU against retained product2 closure; never run a model."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
P = R/'.scratch/inference-review-fixes-20261026'
recipe_helper = P/'build-before-final.py'
spec = importlib.util.spec_from_file_location('existing_review_recipe', recipe_helper)
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def main():
    assert not (W/'compile').exists() and not (W/'ready.json').exists()
    baseline = b.read(P/'ready2.json')
    b.exact(baseline['image'])
    b.exact(baseline['runtime'])
    b.exact(baseline['link_inputs'])
    inputs = b.read(baseline['link_inputs']['path'])
    for row in inputs:
        b.exact(row)
    model_old = next(x for x in baseline['units'] if b.key(x['source']['path']).endswith('engine\\models\\qwen35\\main.cc'))['object']
    report = next(x for x in baseline['units'] if b.key(x['source']['path']).endswith('engine\\reporting\\execution_report.cc'))
    report_dependencies = P/'product2/report/actual-dependencies.json'
    report_deps = b.read(report_dependencies)
    canonical_report = [x for x in report_deps if Path(x['path']).is_relative_to(R) and not Path(x['path']).is_relative_to(R/'.scratch')]
    for row in canonical_report:
        b.exact(row)
    observation = next(x for x in canonical_report if b.key(x['path']).endswith('engine\\inference\\execution_observation.h'))
    b.save(W/'reused-report-abi.json', dict(status='UNCHANGED_REPORT_PROJECT_DEPENDENCIES_AND_STEP_OBSERVATION_ABI_MATCH',
        report=report, dependencies=b.pin(report_dependencies), canonical_dependency_count=len(canonical_report),
        execution_observation=observation, current=b.pin(observation['path']),
        scope='Exact byte/hash match to product2 report compilation. No report/SDK/native source rebuild.'))

    source = R/'engine/models/qwen35/main.cc'
    recipe = P/'product2/model/command.json'
    frozen = b.quoted_project_closure([source])
    assert any(b.key(x['path']).endswith('engine\\inference\\batch_dispatch.h') for x in frozen)
    b.save(W/'source-freeze.json', frozen)
    command = b.compile_command(recipe, source, W/'compile')
    b.save(W/'build-plan.json', dict(status='SOURCE_FROZEN_ONE_MODEL_TU_NOT_RUN',
        source=b.pin(source), recipe=b.pin(recipe), recipe_helper=b.pin(recipe_helper),
        source_freeze=b.pin(W/'source-freeze.json'), baseline_ready=b.pin(P/'ready2.json'),
        baseline_image=baseline['image'], baseline_link_inputs=baseline['link_inputs'],
        baseline_runtime=baseline['runtime'], baseline_link_command=b.pin(P/'product2/link/command.json'),
        replaced_object=model_old, reused_report_abi=b.pin(W/'reused-report-abi.json'),
        unchanged_link_inputs=len(inputs)-1, command=command,
        reason='Actual CLI with common static batch traversal integrated into current frozen Model. One canonical optimized TU; all other product2 report/provider/SDK/native inputs retained.'))
    h = b.helper()
    compiler = command[0]
    env = h.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER': compiler,
        'CMAKE_CXX_COMPILER': compiler, 'CMAKE_GENERATOR': 'Ninja'}, backends=()).env
    compiled = h.execute(command, env, W/'compile', timeout=120)
    dep = b.read(W/'compile/dependencies.json')['Data']
    actual = [b.pin(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])]
    frozen_by_key = {b.key(x['path']): x for x in frozen}
    for row in actual:
        p = Path(row['path'])
        if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch'):
            assert b.key(p) in frozen_by_key and row['sha256'] == frozen_by_key[b.key(p)]['sha256'], str(p)
    for row in frozen:
        b.exact(row)
    for row in canonical_report:
        b.exact(row)
    b.save(W/'actual-dependencies.json', actual)
    new_object = b.pin(W/'compile/unit.obj')
    link = []
    for arg in b.read(P/'product2/link/command.json')['command']:
        if b.key(arg) == b.key(model_old['path']): arg = new_object['path']
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(W/'link/hyle.exe')
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(W/'link/hyle.pdb')
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(W/'link/hyle.lib')
        link.append(arg)
    linked = h.execute(link, env, W/'link', timeout=120)
    final_inputs = [new_object if b.key(x['path']) == b.key(model_old['path']) else x for x in inputs]
    assert sum(x == new_object for x in final_inputs) == 1
    for row in final_inputs:
        b.exact(row)
    b.save(W/'link-inputs.json', final_inputs)
    runtime = b.read(baseline['runtime']['path'])
    b.exact(runtime['native'])
    alias = W/'link'/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = b.pin(alias)
    b.save(W/'runtime.json', runtime)
    b.save(W/'ready.json', dict(status='COMMON_BATCH_CORE_CLI_BUILT_NOT_RUN',
        image=b.pin(W/'link/hyle.exe'), baseline=baseline['image'],
        runtime=b.pin(W/'runtime.json'), link_inputs=b.pin(W/'link-inputs.json'),
        source=b.pin(source), source_freeze=b.pin(W/'source-freeze.json'),
        actual_dependencies=b.pin(W/'actual-dependencies.json'), build_plan=b.pin(W/'build-plan.json'),
        reused_report_abi=b.pin(W/'reused-report-abi.json'), object=new_object,
        compile=compiled, link=linked, compiled_host_TUs=1, unchanged_inputs=len(inputs)-1,
        SDK_device_Graph_provider_report_builds=0, model_runs=0,
        limits=['Actual CLI compiled only; no inference, numerical equivalence or speed result.',
                'Incremental against product2 retained closure, not a claim unrelated retained sources are current.']))
    print('COMMON_CORE_READY', json.dumps(b.pin(W/'ready.json')), flush=True)


if __name__ == '__main__':
    main()
