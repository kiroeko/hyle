"""Two CXX actions and one focused CPU GTest link; root executes all actions."""
from pathlib import Path
import importlib.util
import os
import re
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
R = Path(r'C:\public\project-hyle\hyle')
W = Path(__file__).resolve().parent
BASE = R / '.scratch/inference-physical-spans-20261028/validation/refinement'
DRIVER = R / '.scratch/inference-indexed-store-20261028/build.py'
spec = importlib.util.spec_from_file_location('append_membership_executor', DRIVER)
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
t.W = W; t.R = R
UNITS = {
    'append': ('src/graph_batch/paged_append.cc',
        '.scratch/inference-packed-sequence-20261028/compile/append/compiled.json'),
    'test': ('tests/graph_batch/paged_append_graph_test.cc',
        '.scratch/inference-prefill-integration-20261028/compile/cpu-test/compiled.json'),
}
EXPECTED = {
    'src/graph_batch/paged_append.cc': '628e37b9d93e557e3e7ccc67889285e6263ae3f14fd01ce95d88d84a6b0a1490',
    'tests/graph_batch/paged_append_graph_test.cc': 'ea1eb373f9530cd51859376f0d5070682b7b0d4968ea16264c63907c5eb7de7c',
}
CASES = [
    'GraphPagedAppend.OriginalPagesAndSameGraphProof',
    'GraphPagedAppend.ExclusiveTailRollbackAndBoundedSnapshots',
    'GraphPagedAppend.ActiveRowsUseOnlyTheInitializedCarrierPrefix',
]


def prepare():
    ready = t.read(BASE / 'ready-tiny.json')
    t.exact(ready['inputs']); t.exact(ready['recipe'])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 228
    units = {}
    for name, (source, receipt_path) in UNITS.items():
        prior = t.read(R / receipt_path); assert prior['process']['exit'] == 0
        t.exact(prior['command'])
        original = t.command(prior['command']['path'])
        args = []
        for i, arg in enumerate(original):
            if t.key(arg) == t.key(prior['source']['path']): arg = str(R / source)
            elif i and original[i-1].lower() == '/sourcedependencies': arg = str(W / f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
            args.append(arg)
        assert all(flag in args for flag in ('/c', '/MD', '/O2', '/WX'))
        assert sum(t.key(arg) == t.key(R / source) for arg in args) == 1
        t.save(W / f'recipes/{name}.json', dict(command=args, timeout_seconds=300))
        units[name] = dict(source=source, prior_receipt=t.pin(R / receipt_path),
            original=prior, recipe=t.pin(W / f'recipes/{name}.json'))
    removed = [units['append']['original']['object'], ready['retained_tiny']['object']]
    remove = {t.key(row['path']) for row in removed}
    assert all(sum(t.key(row['path']) == key for row in rows) == 1 for key in remove)
    retained = [row for row in rows if t.key(row['path']) not in remove]
    gtest = [t.pin(R / '.scratch/build-compute-v2-dev/lib' / name)
             for name in ('gtest_main.lib', 'gtest.lib')]
    assert not any(t.key(row['path']) in {t.key(g['path']) for g in gtest} for row in retained)
    retained += gtest
    stats = []
    for row in retained:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes'], row['path']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                          retained_sha256=row['sha256']))
    args = []
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg) == t.key(removed[0]['path']): arg = str(W / 'compile/append/unit.obj')
        elif t.key(arg) == t.key(removed[1]['path']): arg = str(W / 'compile/test/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/append-test').with_suffix(suffix)); break
        args.append(arg)
    args += [row['path'] for row in gtest]
    t.save(W / 'recipe-link.json', dict(command=args, timeout_seconds=240))
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    runtime = t.read(BASE / 'runtime.json')
    t.save(W / 'runtime.json', dict(native=runtime['native'], method='same-file hardlink beside new consumer'))
    t.save(W / 'retained-input-stats.json', stats)
    t.save(W / 'plan.json', dict(base_ready=t.pin(BASE / 'ready-tiny.json'),
        base_inputs=ready['inputs'], base_recipe=ready['recipe'], executor=t.pin(DRIVER),
        units=units, removed=removed, retained=retained,
        retained_stats=t.pin(W / 'retained-input-stats.json'),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        link=t.pin(W / 'recipe-link.json'), cases=CASES,
        counts=dict(CXX=2, SDK_CXX=1, test_CXX=1, links=1, inputs=230, native_processes=1, NVCC=0),
        boundary='Current 228 SDK/weights closure, replace append and remove Tiny consumer; fresh existing CPU test plus two gtest libs. No old image is required. Old test objects are not reused because project test dependencies changed. CUDA old-tail split is not rerun. No header or ABI changes in this slice.'))
    print('PREPARED 2CXX / 1link / 3 focused CPU tests; no source freeze or execution')


def plan():
    p = t.read(W / 'plan.json')
    for key in ('base_ready', 'base_inputs', 'base_recipe', 'executor', 'retained_stats', 'environment', 'runtime', 'link'):
        t.exact(p[key])
    for unit in p['units'].values(): t.exact(unit['prior_receipt']); t.exact(unit['recipe'])
    return p


def freeze():
    p = plan(); paths = {}
    roots = [R / 'include', R]
    for unit in p['units'].values():
        old = unit['original']
        for row in t.read(old['actual_dependencies']['path']):
            path = t.canonical(row['path'])
            if t.project(path): paths[t.key(path)] = path
        roots += [Path(arg[2:]) for arg in t.command(unit['recipe']['path']) if arg.lower().startswith('/i')]
    pending = [R / source for source in EXPECTED]; seen = set()
    while pending:
        path = pending.pop().resolve()
        if t.key(path) in seen: continue
        seen.add(t.key(path)); paths[t.key(path)] = path
        for kind, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((candidate.resolve() for root in ([path.parent] if kind == '"' else []) + roots
                          if (candidate := root / name).is_file()), None)
            if found is not None and t.project(found): pending.append(found)
    snapshots = []
    for relative, sha in EXPECTED.items():
        original = t.pin(R / relative); assert original['sha256'] == sha, relative
        dest = W / 'source' / relative; dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open('xb') as out: out.write((R / relative).read_bytes())
        snapshots.append(dict(original=original, snapshot=t.pin(dest)))
    t.save(W / 'project-dependencies.json', [t.pin(path) for path in paths.values()])
    t.save(W / 'source-freeze.json', dict(helper=t.pin(__file__), plan=t.pin(W / 'plan.json'),
        dependencies=t.pin(W / 'project-dependencies.json'), sources=snapshots))
    print('FROZEN current 2 sources and bounded project dependency metadata; no CXX')


def validate():
    p = plan(); f = t.read(W / 'source-freeze.json')
    for key in ('helper', 'plan', 'dependencies'): t.exact(f[key])
    for row in t.read(f['dependencies']['path']): t.exact(row)
    for row in f['sources']: t.exact(row['original']); t.exact(row['snapshot'])
    return p, f


def parse_compile(name):
    p, f = validate(); assert name in UNITS
    out = W / 'compile' / name; proc = t.read(W / f'logs/{name}/process.json')
    assert proc['exit'] == 0 and not proc['timed_out'], proc
    allowed = {t.key(row['path']): row for row in t.read(f['dependencies']['path'])}
    actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('Successful CXX: parse-only repair, no rerun', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / p['units'][name]['source']),
        object=t.pin(out / 'unit.obj'), process=proc, command=t.pin(W / f'logs/{name}/command.json'),
        dependencies=t.pin(out / 'dependencies.json'), actual_dependencies=t.pin(out / 'actual-dependencies.json')))
    print('CXX PASS', name, proc['pid'])


def compile_one(name):
    p, _ = validate(); assert name in UNITS
    (W / 'compile' / name).mkdir(parents=True, exist_ok=False)
    t.execute(t.command(p['units'][name]['recipe']['path']), W / 'logs' / name, 300)
    parse_compile(name)


def link():
    p, _ = validate()
    for row in t.read(p['retained_stats']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    compiled = {name: t.read(W / f'compile/{name}/compiled.json') for name in UNITS}
    for info in compiled.values():
        assert info['process']['exit'] == 0; t.exact(info['object'])
    inputs = p['retained'] + [info['object'] for info in compiled.values()]
    assert len(inputs) == 230 == len({t.key(row['path']) for row in inputs})
    t.save(W / 'inputs.json', inputs); (W / 'bin').mkdir(exist_ok=True)
    proc = t.execute(t.command(p['link']['path']), W / 'link', 240)
    native = t.read(p['runtime']['path'])['native']; t.exact(native)
    target = W / 'bin' / Path(native['path']).name
    if target.exists(): assert os.path.samefile(target, native['path'])
    else: os.link(native['path'], target)
    t.save(W / 'ready.json', dict(image=t.pin(W / 'bin/append-test.exe'), inputs=t.pin(W / 'inputs.json'),
        recipe=t.pin(W / 'link/command.json'), process=proc, compiled=compiled,
        frozen=t.pin(W / 'source-freeze.json'), native=t.pin(target), environment=p['environment'], cases=CASES))
    print('LINK PASS 230 inputs', proc['pid'])


def parse():
    ready = t.read(W / 'ready.json'); proc = t.read(W / 'run/process.json')
    assert proc['exit'] == 0 and not proc['timed_out'], proc
    results = []
    for case in ET.parse(W / 'run/results.xml').getroot().iter('testcase'):
        name = case.attrib['classname'] + '.' + case.attrib['name']
        assert case.find('failure') is None and case.find('skipped') is None, name
        results.append(name)
    assert sorted(results) == sorted(CASES), results
    t.save(W / ('summary-' + str(time.time_ns()) + '.json'), dict(status='PASS', process=proc,
        tests=results, passed=len(results), skipped=0, image=ready['image'],
        xml=t.pin(W / 'run/results.xml'), scope='CPU common create path only; no CUDA run or performance claim.'))
    print('PASS 3 focused CPU GTests', proc['pid'])


def run():
    ready = t.read(W / 'ready.json'); t.exact(ready['image']); t.exact(ready['native'])
    t.execute([ready['image']['path'], '--gtest_filter=' + ':'.join(CASES), '--gtest_fail_fast',
        '--gtest_output=xml:' + str(W / 'run/results.xml')], W / 'run', 180)
    parse()


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'freeze': freeze()
        elif action == 'compile': compile_one(sys.argv[2])
        elif action == 'parse-compile': parse_compile(sys.argv[2])
        elif action == 'link': link()
        elif action == 'run': run()
        elif action == 'parse': parse()
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True, exist_ok=True)
        (W / ('failure-' + '-'.join(sys.argv[1:3]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
