"""One existing CUDA Source test CXX/link refinement; only root executes native actions."""
from pathlib import Path
import importlib.util
import os
import sys
import time
import traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
R = Path(r'C:\public\project-hyle\hyle')
W = Path(__file__).resolve().parent
P = W.parent
TEMPLATE = R / '.scratch/inference-append-membership-20261028/build.py'
spec = importlib.util.spec_from_file_location('source_spans_refinement_tools', TEMPLATE)
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
b.W = W; b.__file__ = __file__; t = b.t; t.W = W
NAME = 'output-source-test'
SOURCE = 'tests/graph/output_source_cuda_test.cc'
b.UNITS = {NAME: (SOURCE, str(P / 'compile/output-source-test/compiled.json'))}
b.EXPECTED = {SOURCE: '09d6340b4b3715d9e4da3795dc9de305b0332659d0299e5b0cb4ca142599e4a2'}
CASES = ['GraphOutputSourceCuda.HybridPendingTokenAndStoreReuseOnlyExistingRanges']
b.CASES = CASES

def prepare():
    ready = t.read(P / 'ready.json')
    assert ready['process']['exit'] == 0
    for key in ('inputs', 'recipe', 'frozen'): t.exact(ready[key])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 232
    prior = ready['compiled'][NAME]; assert prior['process']['exit'] == 0
    prior_path = P / f'compile/{NAME}/compiled.json'
    assert t.read(prior_path) == prior
    t.exact(prior['command']); t.exact(prior['object']); t.exact(prior['actual_dependencies'])
    old_key = t.key(prior['object']['path'])
    assert sum(t.key(row['path']) == old_key for row in rows) == 1
    retained = [row for row in rows if t.key(row['path']) != old_key]
    assert len(retained) == 231
    args = []; original = t.command(prior['command']['path'])
    for i, arg in enumerate(original):
        if i and original[i-1].lower() == '/sourcedependencies': arg = str(W / f'compile/{NAME}/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{NAME}/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{NAME}/unit.pdb')
        args.append(arg)
    assert all(flag in args for flag in ('/c', '/MD', '/O2', '/WX'))
    assert sum(t.key(arg) == t.key(R / SOURCE) for arg in args) == 1
    t.save(W / f'recipes/{NAME}.json', dict(command=args, timeout_seconds=300))
    link_args = []
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg) == old_key: arg = str(W / f'compile/{NAME}/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/source-spans-hybrid-test').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(arg) == t.key(W / f'compile/{NAME}/unit.obj') for arg in link_args) == 1
    t.save(W / 'recipe-link.json', dict(command=link_args, timeout_seconds=240))
    stats = []
    for row in retained:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes'], row['path']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns, retained_sha256=row['sha256']))
    t.save(W / 'retained-input-stats.json', stats)
    env = t.read(P / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env); t.save(W / 'runtime.json', t.read(P / 'runtime.json'))
    t.save(W / 'plan.json', dict(base_ready=t.pin(P / 'ready.json'), base_inputs=ready['inputs'], base_recipe=ready['recipe'],
        executor=t.pin(b.DRIVER), adapter_template=t.pin(TEMPLATE),
        units={NAME:dict(source=SOURCE, prior_receipt=t.pin(prior_path), original=prior, recipe=t.pin(W / f'recipes/{NAME}.json'))},
        removed=[prior['object']], retained=retained, retained_stats=t.pin(W / 'retained-input-stats.json'),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'), link=t.pin(W / 'recipe-link.json'),
        cases=CASES, counts=dict(CXX=1,SDK_CXX=0,test_CXX=1,links=1,inputs=232,native_processes=1,tests=1,NVCC=0),
        boundary='Test-only fixture refinement. Preserve all 231 other successful link inputs including current resources/append. Do not validate the old test source as current. Freeze current recursive includes including new region_adapter; actual /sourceDependencies checked after successful CXX. No rerun of 11 passed tests.'))
    print('PREPARED 1 test CXX / 1 link / only Hybrid; no compiler/native run')

def link():
    p, _ = b.validate()
    for row in t.read(p['retained_stats']['path']):
        st=Path(row['path']).stat(); assert (st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns']),row['path']
    compiled=t.read(W / f'compile/{NAME}/compiled.json'); assert compiled['process']['exit']==0
    t.exact(compiled['object'])
    inputs=p['retained']+[compiled['object']]
    assert len(inputs)==232==len({t.key(row['path']) for row in inputs})
    t.save(W / 'inputs.json', inputs); (W / 'bin').mkdir(exist_ok=True)
    proc=t.execute(t.command(p['link']['path']),W / 'link',240)
    native=t.read(p['runtime']['path'])['native'];t.exact(native)
    target=W / 'bin' / Path(native['path']).name
    if target.exists():assert os.path.samefile(target,native['path'])
    else:os.link(native['path'],target)
    t.save(W / 'ready.json',dict(image=t.pin(W / 'bin/source-spans-hybrid-test.exe'),inputs=t.pin(W / 'inputs.json'),
        recipe=t.pin(W / 'link/command.json'),process=proc,compiled={NAME:compiled},retained_ready=p['base_ready'],
        frozen=t.pin(W / 'source-freeze.json'),native=t.pin(target),environment=p['environment'],cases=CASES))
    print('LINK PASS: 232 inputs, exactly one replacement',proc['pid'])

def parse():
    ready=t.read(W / 'ready.json');proc=t.read(W / 'run/process.json')
    assert proc['exit']==0 and not proc['timed_out'],proc
    cases=list(ET.parse(W / 'run/results.xml').getroot().iter('testcase'))
    assert len(cases)==1 and cases[0].attrib['classname']+'.'+cases[0].attrib['name']==CASES[0]
    assert cases[0].find('failure') is None and cases[0].find('skipped') is None
    t.save(W / ('summary-'+str(time.time_ns())+'.json'),dict(status='PASS',process=proc,tests=CASES,passed=1,skipped=0,
        image=ready['image'],xml=t.pin(W / 'run/results.xml'),scope='Only failed Hybrid fixture refinement; original 11 successful cases not rerun. No product or performance change.'))
    print('PASS sole Hybrid test',proc['pid'])
b.parse=parse

if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare':prepare()
        elif action=='freeze':b.freeze()
        elif action=='compile':b.compile_one(NAME)
        elif action=='parse-compile':b.parse_compile(NAME)
        elif action=='link':link()
        elif action=='run':b.run()
        elif action=='parse':parse()
        else:raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W / ('failure-'+sys.argv[1]+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
