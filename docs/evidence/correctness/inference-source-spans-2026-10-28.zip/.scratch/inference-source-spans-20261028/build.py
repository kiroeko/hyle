"""Thin 4CXX / 1link / 12-case adapter; only root executes build/native actions."""
from pathlib import Path
import importlib.util
import os
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
R = Path(r'C:\public\project-hyle\hyle')
W = Path(__file__).resolve().parent
TEMPLATE = R / '.scratch/inference-append-membership-20261028/build.py'
spec = importlib.util.spec_from_file_location('source_spans_original_helpers', TEMPLATE)
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
b.W = W; b.__file__ = __file__; t = b.t; t.W = W
BASE = b.BASE
APPEND = R / '.scratch/inference-append-membership-20261028/compile/append/compiled.json'
CONFIG = '.scratch/inference-physical-spans-20261028/validation/refinement/compile/configuration-test/compiled.json'
b.UNITS = {
    'resources': ('src/graph/resources.cc',
        '.scratch/inference-physical-spans-20261028/validation/compile/resources/compiled.json'),
    'configuration-test': ('tests/graph/configuration_input_test.cc', CONFIG),
    'input-source-test': ('tests/graph/input_source_frontier_test.cc', CONFIG),
    'output-source-test': ('tests/graph/output_source_cuda_test.cc',
        '.scratch/inference-store-source-range-20261027/compile/output-test/compiled.json'),
}
b.EXPECTED = {
    'src/graph/resources.cc': '58a0fa1525d3ab7e67c267bc3c53c85d454db98338f820aea5a1a71c8ba4b6eb',
    'tests/graph/configuration_input_test.cc': '765d83fd925f60ac133ec8c48cf7e82ac50253978d2b2e5216c9fc18ac6edda1',
    'tests/graph/input_source_frontier_test.cc': 'e18f35df32111c92cafaee57c8963f2bfb026e7f0f3fe4c5e93db77375376609',
    'tests/graph/output_source_cuda_test.cc': '40d8b80da3417601fe17a1fb2dbd90d07ba8e5a67456d990c1f12b943bb53ba7',
}
CASES = ['ConfigurationInput.' + name for name in (
    'OrdinaryBindingsCannotReplacePreparedMetadata',
    'FailedColdReplacementPreservesReplayAndResetUnlocksInput',
    'RefreshedConfigurationUsesCurrentLeaseAndReplacementStorage',
    'IncompleteConfigurationCannotKeepThePhysicalShortcut',
    'SamePhysicalSourceReplacementRequalifiesItsCurrentProducer',
    'CarrierQueryUsesOnlyThisPlansPrivateInput',
    'LayoutResetPreservesCallerLeasesAndSourceButExpiresMetadata',
)] + [
    'InputSourceBundle.InvalidLastTensorPreservesOriginalPreparedBindings',
    'InputSourceBundle.SameProducerReplacesBothInputsAndDeduplicatesReadiness',
    'GraphOutputSourceCuda.PendingI32ReusesRealNativeRegionCaptureWithoutRecording',
    'GraphOutputSourceCuda.HybridPendingTokenAndStoreReuseOnlyExistingRanges',
    'GraphOutputSourceCuda.ProducerCheckedFailureRejectsConsumerPublicationAfterRetirement',
]
b.CASES = CASES


def prepare():
    ready = t.read(BASE / 'ready-tiny.json')
    t.exact(ready['inputs']); t.exact(ready['recipe'])
    rows = t.read(ready['inputs']['path']); assert len(rows) == 228
    append = t.read(APPEND); assert append['process']['exit'] == 0
    t.exact(append['source']); t.exact(append['object'])
    old_append = t.read(R / '.scratch/inference-packed-sequence-20261028/compile/append/compiled.json')['object']
    units = {}
    for name, (source, receipt) in b.UNITS.items():
        prior = t.read(R / receipt); assert prior['process']['exit'] == 0
        t.exact(prior['command']); original = t.command(prior['command']['path']); args = []
        for i, arg in enumerate(original):
            if t.key(arg) == t.key(prior['source']['path']): arg = str(R / source)
            elif i and original[i-1].lower() == '/sourcedependencies': arg = str(W / f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
            args.append(arg)
        assert all(flag in args for flag in ('/c', '/MD', '/O2', '/WX'))
        assert sum(t.key(arg) == t.key(R / source) for arg in args) == 1
        t.save(W / f'recipes/{name}.json', dict(command=args, timeout_seconds=300))
        units[name] = dict(source=source, prior_receipt=t.pin(R / receipt), original=prior,
            recipe=t.pin(W / f'recipes/{name}.json'),
            template_note='Existing CPU configuration-test flags adapted to the adjacent CPU Source TU; not an earlier compile of that Source TU.' if name == 'input-source-test' else 'Original same-TU CXX recipe; current canonical source and private quote lookup.')
    remove = {t.key(unit['original']['object']['path']) for name, unit in units.items() if name == 'resources'}
    remove |= {t.key(ready['retained_tiny']['object']['path']), t.key(old_append['path'])}
    assert len(remove) == 3
    assert all(sum(t.key(row['path']) == key for row in rows) == 1 for key in remove)
    retained = [row for row in rows if t.key(row['path']) not in remove] + [append['object']]
    gtest = [t.pin(R / '.scratch/build-compute-v2-dev/lib' / name) for name in ('gtest_main.lib', 'gtest.lib')]
    retained += gtest
    assert len(retained) == 228 == len({t.key(row['path']) for row in retained})
    stats = []
    for row in retained:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes'], row['path']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns, retained_sha256=row['sha256']))
    old_resources = t.key(units['resources']['original']['object']['path'])
    old_tiny = t.key(ready['retained_tiny']['object']['path']); args = []
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg) == old_resources: arg = str(W / 'compile/resources/unit.obj')
        elif t.key(arg) == old_tiny: continue
        elif t.key(arg) == t.key(old_append['path']): arg = append['object']['path']
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/source-spans-test').with_suffix(suffix)); break
        args.append(arg)
    args += [str(W / f'compile/{name}/unit.obj') for name in b.UNITS if name != 'resources']
    args += [row['path'] for row in gtest]
    t.save(W / 'recipe-link.json', dict(command=args, timeout_seconds=240))
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'runtime.json', dict(native=t.read(BASE / 'runtime.json')['native'], method='same-file hardlink beside consumer'))
    t.save(W / 'retained-input-stats.json', stats)
    t.save(W / 'plan.json', dict(base_ready=t.pin(BASE / 'ready-tiny.json'), base_inputs=ready['inputs'],
        base_recipe=ready['recipe'], executor=t.pin(b.DRIVER), adapter_template=t.pin(TEMPLATE),
        units=units, append_receipt=t.pin(APPEND), append=append, retained=retained,
        removed=dict(resources=units['resources']['original']['object'], tiny=ready['retained_tiny']['object'], append=old_append),
        retained_stats=t.pin(W / 'retained-input-stats.json'), environment=t.pin(W / 'environment.json'),
        runtime=t.pin(W / 'runtime.json'), link=t.pin(W / 'recipe-link.json'), cases=CASES,
        counts=dict(CXX=4, SDK_CXX=1, test_CXX=3, links=1, inputs=232, native_processes=1, tests=12, NVCC=0),
        boundary='Only resources is newly compiled SDK code; reuse successful append membership OBJ and current 228 closure. Three separate original tests, no merged include consumer, SDK/payload copy or Model CXX. Current-source/configuration identity plus original Source routes, failure retirement and device-capture subset.'))
    print('PREPARED 4CXX / 1link / 12 focused tests; no freeze or execution')


original_plan = b.plan
def plan():
    p = original_plan(); t.exact(p['adapter_template']); t.exact(p['append_receipt'])
    t.exact(p['append']['source']); t.exact(p['append']['object'])
    return p
b.plan = plan


def link():
    p, _ = b.validate()
    for row in t.read(p['retained_stats']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    compiled = {name: t.read(W / f'compile/{name}/compiled.json') for name in b.UNITS}
    for info in compiled.values():
        assert info['process']['exit'] == 0; t.exact(info['object'])
    inputs = p['retained'] + [info['object'] for info in compiled.values()]
    assert len(inputs) == 232 == len({t.key(row['path']) for row in inputs})
    t.save(W / 'inputs.json', inputs); (W / 'bin').mkdir(exist_ok=True)
    proc = t.execute(t.command(p['link']['path']), W / 'link', 240)
    native = t.read(p['runtime']['path'])['native']; t.exact(native)
    target = W / 'bin' / Path(native['path']).name
    if target.exists(): assert os.path.samefile(target, native['path'])
    else: os.link(native['path'], target)
    t.save(W / 'ready.json', dict(image=t.pin(W / 'bin/source-spans-test.exe'), inputs=t.pin(W / 'inputs.json'),
        recipe=t.pin(W / 'link/command.json'), process=proc, compiled=compiled, append=p['append']['object'],
        frozen=t.pin(W / 'source-freeze.json'), native=t.pin(target), environment=p['environment'], cases=CASES))
    print('LINK PASS 232 inputs', proc['pid'])


def parse():
    ready = t.read(W / 'ready.json'); proc = t.read(W / 'run/process.json')
    assert proc['exit'] == 0 and not proc['timed_out'], proc
    results = []
    for case in ET.parse(W / 'run/results.xml').getroot().iter('testcase'):
        name = case.attrib['classname'] + '.' + case.attrib['name']
        assert case.find('failure') is None and case.find('skipped') is None, name
        results.append(name)
    assert sorted(results) == sorted(CASES), results
    t.save(W / ('summary-' + str(time.time_ns()) + '.json'), dict(status='PASS', process=proc,
        tests=results, passed=len(results), skipped=0, image=ready['image'], xml=t.pin(W / 'run/results.xml'),
        scope='7 configuration + 2 Source bundle + 3 CUDA Source capture/failure cases; no Model or performance claim.'))
    print('PASS 12 focused tests', proc['pid'])
b.parse = parse


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'freeze': b.freeze()
        elif action == 'compile': b.compile_one(sys.argv[2])
        elif action == 'parse-compile': b.parse_compile(sys.argv[2])
        elif action == 'link': link()
        elif action == 'run': b.run()
        elif action == 'parse': parse()
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True, exist_ok=True)
        (W / ('failure-' + '-'.join(sys.argv[1:3]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
