"""Offline compact reports and one shared raw ZIP. Root invokes after actual runs.

No compiler, linker, native consumer, subprocess, network, or git is invoked.
Historical identities come from frozen snapshots/receipts, never current source.
"""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import time
import xml.etree.ElementTree as ET
import zipfile
import zlib

R = Path(r'C:\public\project-hyle\hyle')
W = Path(__file__).resolve().parent
F = W / 'refinement'
P = R / '.scratch/inference-physical-spans-20261028/performance'
A = R / '.scratch/inference-append-membership-20261028'
OLD_DIAG = P / 'reachability'
NEW_DIAG = W / 'performance/diagnostic'
NAME = 'inference-source-spans-2026-10-28'
CORRECT = R / 'docs/evidence/correctness' / (NAME + '.json')
ARCHIVE = CORRECT.with_suffix('.zip')
PERF = R / 'docs/evidence/performance/inference-physical-spans-screen-2026-10-28.json'
HYBRID = 'GraphOutputSourceCuda.HybridPendingTokenAndStoreReuseOnlyExistingRanges'
ALLOWED = {'.py', '.json', '.log', '.xml', '.cc', '.h', '.patch', '.md'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def process(path, expected=0):
    value = read(path)
    assert value['exit'] == expected and not value.get('timed_out', False), (str(path), value)
    return dict(pid=value['pid'], exit=value['exit'],
        seconds=value.get('seconds', value.get('process_wall_seconds')), receipt=pin(path))


def xml_results(path):
    result = {}
    for case in ET.parse(path).getroot().iter('testcase'):
        name = case.attrib['classname'] + '.' + case.attrib['name']
        assert name not in result
        result[name] = ('failed' if case.find('failure') is not None else
                        'skipped' if case.find('skipped') is not None else 'passed')
    return result


def unique_summary(base):
    rows = list(base.glob('summary-*.json')); assert len(rows) == 1, (str(base), rows)
    return rows[0], read(rows[0])


def diagnostic(base):
    result = []
    for role in ('ordinary', 'mtp'):
        directory = base / 'runs' / role; analysis = read(directory / 'analysis.json')
        assert analysis['status'] == 'PASS_DIAGNOSTIC_FACTS'
        assert analysis['full_non_time_differences'] == []
        assert analysis['performance_claim'] is False
        assert not any(analysis['counts']['overflow'].values()), analysis['counts']
        exact(analysis['process']); actual = process(analysis['process']['path'])
        result.append(dict(role=role, process=actual, totals=analysis['counts']['totals'],
            overflow=analysis['counts']['overflow'], complete_non_time_equal=True,
            analysis=pin(directory / 'analysis.json'), performance_claim=False))
    assert [(v['totals']['decisions'], v['totals']['reused']) for v in result] == [(64, 0), (35, 32)]
    return result


def main(additions):
    notes = read(W / 'evidence-notes.json')
    expected = read(W / 'plan.json')['cases']; assert len(expected) == 12
    first = xml_results(W / 'run/results.xml'); final = xml_results(F / 'run/results.xml')
    assert sorted(first) == sorted(expected)
    assert [key for key, value in first.items() if value == 'failed'] == [HYBRID]
    assert list(first.values()).count('passed') == 11 and 'skipped' not in first.values()
    assert final == {HYBRID: 'passed'}, final
    final_path, final_summary = unique_summary(F)
    assert final_summary['status'] == 'PASS' and final_summary['passed'] == 1
    assert final_summary['tests'] == [HYBRID]
    first_process = process(W / 'run/process.json', 1)
    final_process = process(F / 'run/process.json')
    assert final_summary['process']['pid'] == final_process['pid']
    compile_records = [process(p) for base in (W, F) for p in sorted((base / 'logs').glob('*/process.json'))]
    links = [process(W / 'link/process.json'), process(F / 'link/process.json')]
    links += [process(W / 'performance/links' / name / 'process.json') for name in ('normal', 'diagnostic')]
    assert len(compile_records) == 5 and len(links) == 4
    old_diag, new_diag = diagnostic(OLD_DIAG), diagnostic(NEW_DIAG)
    append_path, append = unique_summary(A)
    assert append['status'] == 'PASS' and append['passed'] == 3 and append['skipped'] == 0
    assert set(xml_results(A / 'run/results.xml').values()) == {'passed'}
    append_process = process(A / 'run/process.json')
    screen = read(P / 'summary.json')
    assert screen['status'] == 'COMPLETE16_TWO_GRAPH_OBJECT_SCREEN'
    assert (screen['timing_processes'], screen['memory_processes'], screen['sample_count_each']) == (16, 0, 2)
    metrics, screen_processes = [], []
    for group in screen['groups']:
        assert group['status'] == 'COMPLETE_STABLE'
        assert group['complete_non_time_equal'] and group['cross_variant_differences'] == []
        variants = {}
        for name, value in group['groups'].items():
            assert value['within_variant_differences'] == []
            variants[name] = value['metrics']
            assert all(metric['count'] == 2 for metric in value['metrics'].values())
        metrics.append(dict(scenario=group['scenario'], role=group['role'], variants=variants,
            descriptive_median_delta_percent=group['descriptive_median_delta_percent'], complete_non_time_equal=True))
        for row in group['actual_processes']:
            exact(row['result']); actual = process(row['result']['path'])
            assert actual['pid'] == row['pid']
            screen_processes.append(dict(scenario=group['scenario'], role=group['role'],
                variant=row['variant'], ordinal=row['ordinal'], **actual))
    assert len(metrics) == 4 and len(screen_processes) == 16

    files = {}; virtual = {}
    def add(path, required=True):
        path = Path(path).resolve()
        if not path.is_file():
            assert not required, str(path)
            return
        assert path.is_relative_to(R) and path.suffix.lower() in ALLOWED, str(path)
        assert path.stat().st_size <= 16 << 20, ('Unexpected large evidence text', str(path))
        files[path.relative_to(R).as_posix()] = path
    def tree(base):
        if base.is_dir():
            for path in sorted(base.rglob('*')):
                if path.is_file() and path.suffix.lower() in ALLOWED: add(path)
    def collect(base, directories, top):
        for name in top: add(base / name)
        for pattern in ('summary-*.json', 'failure-*.log', '*.patch'):
            for path in base.glob(pattern): add(path)
        for name in directories: tree(base / name)
    def snapshots(base, filename='source-freeze.json'):
        frozen = read(base / filename)
        for key in ('helper', 'plan', 'dependencies'): exact(frozen[key])
        source_by_path = {row['original']['path'].casefold(): row['original'] for row in frozen['sources']}
        for row in frozen['sources']:
            exact(row['snapshot'])
            assert (row['snapshot']['bytes'], row['snapshot']['sha256']) == (row['original']['bytes'], row['original']['sha256'])
            add(row['snapshot']['path'])
        for path in (base / 'compile').glob('*/compiled.json'):
            receipt = read(path); source = receipt['source']
            expected_source = source_by_path[source['path'].casefold()]
            assert (source['bytes'], source['sha256']) == (expected_source['bytes'], expected_source['sha256'])
            assert receipt['process']['exit'] == 0
            for key in ('command', 'dependencies', 'actual_dependencies'): exact(receipt[key])
        ready = read(base / 'ready.json')
        for key in ('inputs', 'recipe'): exact(ready[key])
        return [row['original'] for row in frozen['sources']]

    common = ['build.py', 'plan.json', 'source-freeze.json', 'inputs.json', 'ready.json',
              'environment.json', 'runtime.json', 'recipe-link.json']
    for base in (W, F, A):
        collect(base, ('recipes', 'logs', 'compile', 'link', 'run'), common + ['project-dependencies.json'])
    source_pins = snapshots(W) + snapshots(F) + snapshots(A)
    add(W / 'evidence-notes.json'); add(W / 'evidence-notes.md'); add(__file__)
    perf_top = ['build.py', 'build-plan.json', 'source-freeze.json', 'binding.json', 'window-plan.json',
        'summary.json', 'inputs-candidate.json', 'ready-control.json', 'ready-candidate.json', 'link-recipe.json',
        'runtime.json', 'environment.json', 'single-ordinary-plan.json', 'single-mtp-plan.json',
        'two-turn-ordinary-plan.json', 'two-turn-mtp-plan.json']
    collect(P, ('link', 'runs'), perf_top)
    collect(OLD_DIAG, ('logs', 'compile', 'link', 'runs'), ['build.py', 'plan.json', 'source-freeze.json',
        'diagnostic-source.json', 'diagnostic.patch', 'executable-reachability.cc', 'compile-recipe.json',
        'link-recipe.json', 'project-dependencies.json', 'inputs.json', 'ready.json', 'runtime.json',
        'environment.json', 'run-plan.json', 'ordinary-plan.json', 'mtp-plan.json'])
    collect(W / 'performance', ('links',), ['build.py', 'plan.json', 'source-freeze.json',
        'inputs-normal.json', 'inputs-diagnostic.json', 'ready-normal.json', 'ready-diagnostic.json',
        'link-normal.json', 'link-diagnostic.json', 'runtime.json', 'environment.json'])
    collect(NEW_DIAG, ('runs',), ['run-plan.json', 'ordinary-plan.json', 'mtp-plan.json'])
    # Persist only necessary frozen source bodies, not complete header/SDK trees.
    screen_freeze = read(P / 'source-freeze.json')
    exact(screen_freeze['control']['compiled']['snapshot']); add(screen_freeze['control']['compiled']['snapshot']['path'])
    validation = P.parent / 'validation'
    for name, path in (
        ('resources', validation / 'source/src/graph/resources.cc'),
        ('executable', validation / 'refinement/source/src/graph/executable.cc')):
        source = screen_freeze['sdk'][name]['compiled']['source']
        actual = pin(path); assert (actual['bytes'], actual['sha256']) == (source['bytes'], source['sha256'])
        add(path)
    for path in [P.parent / 'product.patch', R / '.scratch/inference-fixed-projection-spans-20261028/product/changes.patch',
                 R / '.scratch/inference-fixed-projection-spans-20261028/product/command-mode-span-refinement.patch']:
        add(path)
    patch_pairs = [
        ('src/graph/resources.cc', validation / 'source/src/graph/resources.cc', W / 'source/src/graph/resources.cc'),
        ('tests/graph/configuration_input_test.cc', validation / 'generation-fix/source/configuration_input_test.cc', W / 'source/tests/graph/configuration_input_test.cc'),
        ('src/graph_batch/paged_append.cc', R / '.scratch/inference-packed-sequence-20261028/source/src/graph_batch/paged_append.cc', A / 'source/src/graph_batch/paged_append.cc'),
        ('tests/graph/output_source_cuda_test.cc', W / 'source/tests/graph/output_source_cuda_test.cc', F / 'source/tests/graph/output_source_cuda_test.cc'),
    ]
    patch = ''; pairs = []
    for label, before, after in patch_pairs:
        add(before); add(after)
        patch += ''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),
            after.read_text(encoding='utf-8-sig').splitlines(True), fromfile='a/' + label, tofile='b/' + label))
        pairs.append(dict(source=label, before=pin(before), after=pin(after)))
    virtual['source-changes.patch'] = patch.encode('utf-8')
    virtual['source-patch-pins.json'] = (json.dumps(pairs, indent=2) + '\n').encode()
    followup = dict(status='NOT_INCLUDED', reason='Alias diagnosis is a separate follow-up; no planned run is counted.')
    if additions is not None:
        extra = read(additions); add(additions)
        for row in extra.get('references', []): exact(row); add(row['path'])
        followup = extra

    correctness = dict(schema='hyle.source-spans.correctness.v1', status='FINITE_PASS_ACROSS_RECORDED_IMAGES',
        source_notes=pin(W / 'evidence-notes.json'), product_sources=source_pins,
        changes=dict(source='Separate immutable physical spans from fresh Source identity/dependency preparation; all original admission, alias, native, seal and retirement gates remain.',
            append='Remove only redundant untouched membership lookup; bank permissions and changed COW/tail lookups remain.'),
        source_validation=dict(CXX=compile_records, links=links, CXX_count=5, link_count=4,
            first=dict(process=first_process, passed=11, failed=1, skipped=0, results=first),
            refinement=dict(process=final_process, passed=1, failed=0, skipped=0, results=final, summary=pin(final_path)),
            unique_final_passes=12, successful_first_cases_rerun=False,
            failure='Hybrid fixture expected a non-capturable Store before Source binding; default Store now has a capturable indexed-copy path. Refinement explicitly selects its original Queue-copy fallback. Product/math unchanged for this fixture repair.'),
        current_model_diagnostics=dict(runs=new_diag, count=2, performance_claim=False,
            conclusion='Ordinary remains 0/64 reused (62 full with Source); MTP remains 32/35. Source-owner veto was not the only remaining blocker; no speed or hit-rate improvement established.'),
        current_slice_counts=dict(CXX=5, links=4, native_processes=4, native_successes=3, native_failures=1),
        separate_append_validation=dict(process=append_process, passed=3, skipped=0, tests=append['tests'],
            summary=pin(append_path), CXX=2, links=1, scope='CPU only, separate earlier image.'),
        earlier_diagnostics=old_diag,
        future_timing=dict(planned=8, actual=0, status='NOT_RUN', memory_processes=0),
        followup=followup,
        limits=['12 Source tests pass across the original 11 and one fixture-refined image, not 12 rerun on one image.',
            'Screen and all four reachability diagnostics retain old 4ca9 consumer / Model object ff22; not latest Model.',
            'No new B2 reachability, Apple/Vulkan, quality, universal equivalence or throughput claim.',
            'Counters observe one existing decision site, not all seals/preparations; instrumented TPS is excluded.'])
    performance = dict(schema='hyle.physical-spans.screen.v1', status=screen['status'],
        scope=screen['scope'], timing_processes=16, memory_processes=0, samples_per_arm=2,
        processes=screen_processes, metrics=metrics, complete_non_time_equal=True,
        time_beijing=notes['prior_screen']['time_beijing'],
        image_identity=dict(control=read(P / 'ready-control.json')['image'], candidate=read(P / 'ready-candidate.json')['image'],
            model_source_sha256=screen_freeze['control']['compiled']['source']['sha256'],
            model_object_sha256=screen_freeze['control']['compiled']['object']['sha256']),
        memory=dict(status='NOT_MEASURED', ready_RAM=None, ready_VRAM=None, peak_RAM=None, peak_VRAM=None),
        reachability=dict(before=old_diag, after_source_change=new_diag),
        source_change_timing=dict(planned=8, actual=0, status='NOT_RUN'),
        conclusion='Two samples per arm are a descriptive screen, not significant improvement or a complete performance milestone. Source change has no timing evidence here.',
        limitations=['No memory processes; unknown baselines are not zero.',
            'No diagnostic timing or elapsed process duration is used as TPS.',
            'No causal performance attribution to Source or private View alias without separate evidence.'])
    assert not any(path.exists() for path in (CORRECT, PERF, ARCHIVE)), 'Preserve existing artifacts; do not overwrite.'
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True); PERF.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, path in sorted(files.items()):
            data = path.read_bytes(); archive.writestr(name, data)
            rows.append(dict(name=name, bytes=len(data), sha256=digest(data), crc32=f'{zlib.crc32(data) & 0xffffffff:08x}'))
        for name, data in sorted(virtual.items()):
            archive.writestr(name, data)
            rows.append(dict(name=name, bytes=len(data), sha256=digest(data), crc32=f'{zlib.crc32(data) & 0xffffffff:08x}'))
        manifest = (json.dumps(dict(schema='hyle.compact-evidence.members.v1', files=rows), indent=2) + '\n').encode()
        archive.writestr('manifest.json', manifest)
    with zipfile.ZipFile(ARCHIVE) as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(rows) + 1
        for row in rows:
            data = archive.read(row['name']); info = archive.getinfo(row['name'])
            assert len(data) == row['bytes'] and digest(data) == row['sha256']
            assert f'{info.CRC:08x}' == row['crc32']
        assert archive.read('manifest.json') == manifest
    archive_identity = dict(**pin(ARCHIVE), members=len(rows) + 1, manifest_sha256=digest(manifest), CRC_and_member_SHA_readback='PASS')
    for path, value in ((CORRECT, correctness), (PERF, performance)):
        value['archive'] = archive_identity
        with path.open('x', encoding='utf-8') as out: out.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(dict(correctness=pin(CORRECT), performance=pin(PERF), archive=archive_identity), indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--additions', type=Path, help='Optional root-authored follow-up notes and exact file references; not inferred from pending directories.')
    args = parser.parse_args()
    main(args.additions)
