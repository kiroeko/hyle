# Source 物理 span：证据草稿

**状态：Source 新改动已冻源，4 CXX／12 项有限 Source 检查／2 个模型诊断仍待 root 实际结果。** 本草稿只整理现有离线材料，不生成公开证据或 ZIP。

三处修正只把 Source 身份／依赖与物理几何分开。每次绑定仍核完整 tuple；effect-only 更新仍撤销旧准备；每次 replay 仍 seal 并重新准备当前 producer、Queue、ready 与依赖；提交／退休仍沿原权限和完整 producer Status。native／opaque、alias／replica、Queue 和失败回退门不动。

新正例使用原 Copy 无别名 Fixture：同一物理 tensor 更换 Source，旧 replay 必须失效；新 Source 必须实际 route／ready，旧 Source 不再观察，第二次 payload 数学结果保持原断言。旧 LayoutResetSource 的 false 候选断言保留，改为明确证明原 configuration alias 原因。

## 已有 16 进程 screen

北京时间 2026-10-28T20:42:19+08:00 至 2026-10-28T20:44:37+08:00。每版本／场景／角色仅 2 timing 样本；16 native 全 exit 0，完整 non-time 全相等，0 memory 样本。复用 retained 4ca9 Model ff22，不冒充最新 Model 或四指标正式性能里程碑。

| 场景 | 角色 | decode control → candidate（tokens/s） | 中位变化 |
|---|---|---:|---:|
| single | ordinary | 99.20988 → 98.15698 | -1.06% |
| single | mtp | 127.78667 → 129.86217 | +1.62% |
| two-turn | ordinary | 99.42745 → 100.08539 | +0.66% |
| two-turn | mtp | 130.97495 → 133.12403 | +1.64% |

完整四指标的中位数／范围保存在 JSON；小幅混合变化不能证明缓存命中，也不能推断本次 Source 修正的收益。

## 实际命中诊断与 append

- ordinary PID 52652：64 判定，reuse 0／full 64，其中 62 个 full 有 Source。
- MTP PID 41800：35 判定，reuse 32／full 3。两次完整 non-time 与各自 screen 样本 0 diff；64 plan 桶未溢出。
- 诊断只统计完整输入／输出检查后的 reuse_spans 判定，不包含早返回 seal 或缺绑定失败；计数器改变时间，诊断 TPS 禁用于结论。
- 这组结果才支持调查 Source 的全局保守否决，而非从 screen TPS 推断。原 Source 依赖与验权独立刷新，源码窄核未见“Source 本身要求重建不变 View”的反例；新分支仍需实际检查。
- append PID 52880：3 个既有 CPU case 全 PASS／0 skip，XML 原始记录已核。只删 untouched 分支的弃用成员查询；immutable refs 的 footprint 与原 bank 前缀已先证明，COW／tail 查找、真实权限及 caller ordinal 不变。没有该改动 CUDA 或性能宣称。

公开 JSON／ZIP 建议及必要原始文件清单见同目录 evidence-notes.json；最后打包以 root 的真实 Source 新检查补齐，保留原始身份、PID／exit、raw 与配方，排除 OBJ／EXE／SDK／权重和重复快照。未覆盖 B2 命中、Apple／Vulkan、新质量或普适性能。
