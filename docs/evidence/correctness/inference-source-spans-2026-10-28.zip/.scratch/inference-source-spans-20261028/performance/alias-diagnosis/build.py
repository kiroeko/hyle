"""One explicit alias diagnostic, using the already successful thin driver."""
from pathlib import Path
import copy
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = W.parent
PREVIOUS = R / '.scratch/inference-physical-spans-20261028/performance/reachability'
spec = importlib.util.spec_from_file_location('single_alias_diagnostic_driver', PREVIOUS / 'build.py')
d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
t, s = d.t, d.s
t.W = W
d.W = W
d.PARENT = W / 'baseline'
d.ORIGINAL = PREVIOUS / 'executable-reachability.cc'
d.SOURCE = W / 'executable-reachability.cc'
d.SDK_RECEIPT = PREVIOUS / 'compile/compiled.json'


def prepare():
    ready = t.read(BASE / 'ready-diagnostic.json')
    assert ready['process']['exit'] == 0
    s.keep(d.PARENT / 'ready-candidate.json', ready)
    s.keep(d.PARENT / 'environment.json', t.read(BASE / 'environment.json'))
    screen_helper = d.PARENT / 'build.py'
    if not screen_helper.exists(): screen_helper.hardlink_to(s.__file__)
    assert screen_helper.samefile(s.__file__)
    original_save = t.save
    def resume_metadata(path, value):
        if Path(path).exists():
            assert t.read(path) == value, ('Preserve partial preparation', str(path))
        else:
            original_save(path, value)
    t.save = resume_metadata
    try: d.prepare()
    finally: t.save = original_save


def prepare_run():
    plan, _ = d.validate(); ready = t.read(W / 'ready.json'); t.exact(ready['image'])
    original = t.read(BASE / 'diagnostic/ordinary-plan.json')
    cfg = copy.deepcopy(original); entry = dict(original['commands'][0])
    entry.update(folder=str(W / 'runs/ordinary'), command=[ready['image']['path'], *entry['command'][1:]],
        image=ready['image'], environment=plan['runtime'], ready=t.pin(W / 'ready.json'))
    cfg.update(commands=[entry], script=t.pin(__file__), binding=t.pin(W / 'source-freeze.json'), performance_claim=False)
    path = W / 'ordinary-plan.json'; t.save(path, cfg)
    expected = t.read(BASE / 'diagnostic/run-plan.json')['groups']
    expected = next(row['expected_full_report'] for row in expected if row['role'] == 'ordinary')
    t.exact(expected)
    t.save(W / 'run-plan.json', dict(helper=t.pin(d.__file__), adapter=t.pin(__file__),
        groups=[dict(role='ordinary', plan=t.pin(path), expected_full_report=expected)],
        diagnostic_processes=1, performance_claim=False))
    print('ONE ORDINARY ALIAS DIAGNOSTIC PREPARED; no native started')


def reasons():
    folder = W / 'runs/ordinary'
    lines = (folder / 'stderr.log').read_text(encoding='utf-8', errors='strict').splitlines()
    totals = [json.loads(line.removeprefix('HYLE_SPAN_BIND_REASONS ')) for line in lines
              if line.startswith('HYLE_SPAN_BIND_REASONS ')]
    samples = [json.loads(line.removeprefix('HYLE_SPAN_BIND_SAMPLE ')) for line in lines
               if line.startswith('HYLE_SPAN_BIND_SAMPLE ')]
    assert len(totals) == 1
    assert totals[0]['sample_limit'] == 48 and totals[0]['samples'] == len(samples) <= 48
    assert all(isinstance(value, int) and value >= 0 for value in totals[0]['counts'].values())
    assert t.read(folder / 'analysis.json')['status'] == 'PASS_DIAGNOSTIC_FACTS'
    value = dict(status='PASS_FINITE_ALIAS_DIAGNOSIS', reason_totals=totals[0], samples=samples,
        original_fact_analysis=t.pin(folder / 'analysis.json'), performance_claim=False,
        scope='Counts are diagnostic observations, not an optimization result. Existing full-view proof includes actual prepared storage identity as well as topology.')
    s.b.save(folder / 'reason-analysis.json', value)
    print(json.dumps(value, indent=2))


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': d.compile_unit()
    elif action == 'parse-compile': d.parse_compile()
    elif action == 'link': d.link()
    elif action == 'parse-link': d.parse_link()
    elif action == 'prepare-run': prepare_run()
    elif action == 'run': d.run('ordinary'); reasons()
    elif action == 'analyze': d.analyze('ordinary'); reasons()
    else: raise SystemExit('prepare | compile | parse-compile | link | parse-link | prepare-run | run | analyze')
