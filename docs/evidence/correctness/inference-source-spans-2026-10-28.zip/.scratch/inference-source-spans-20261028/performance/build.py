"""Root-only Source-span/append links, two diagnostics, then ordinary screen.

prepare requires the actual successful resources receipt; no path discovery or
default. Zero CXX/NVCC/download/memory paths. Historical timing is never pooled.
"""
from pathlib import Path
import copy
import importlib.util
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
BASE = R / '.scratch/inference-physical-spans-20261028/performance'
spec = importlib.util.spec_from_file_location('source_span_existing_diagnostic', BASE / 'reachability/build.py')
d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
s, t = d.s, d.t
t.W = W
d.W = W / 'diagnostic'
s.W = W / 'screen'
s.STAGES = (('single', 'ordinary'), ('two-turn', 'ordinary'))
APPEND = R / '.scratch/inference-append-membership-20261028/compile/append/compiled.json'
DIAGNOSTIC = BASE / 'reachability/compile/compiled.json'
ORDER = ('control', 'candidate', 'candidate', 'control')


def prepare(resources_receipt):
    assert not (W / 'plan.json').exists(), 'Preserve original metadata and native attempts'
    path = Path(resources_receipt).resolve()
    ready_path = BASE / 'ready-candidate.json'; ready = t.read(ready_path)
    assert ready['process']['exit'] == 0
    assert ready['image']['sha256'] == 'fa7aa9c950e913249217a7d4371acbb47d3bc318c15a9549a6b3c467c3f7e9eb'
    assert ready['compiled']['object']['sha256'] == 'ff22d11a294a5aa507034b09efeb475b1aedd514f473b974c970436f24f51e52'
    for name in ('image', 'inputs', 'recipe', 'runtime'): t.exact(ready[name])
    original = t.read(ready['inputs']['path']); assert len(original) == 229
    receipts = {'resources': path, 'append': APPEND, 'diagnostic-executable': DIAGNOSTIC}
    units = {}
    for name, receipt in receipts.items():
        unit = t.read(receipt)
        assert unit['process']['exit'] == 0 and not unit['process']['timed_out']
        t.exact(unit['object'])
        for key in ('command', 'dependencies', 'actual_dependencies'):
            if key in unit: t.exact(unit[key])
        units[name] = dict(receipt=t.pin(receipt), compiled=unit)
    assert t.key(units['resources']['compiled']['source']['path']) == t.key(R / 'src/graph/resources.cc')
    assert units['append']['compiled']['source']['sha256'] == '628e37b9d93e557e3e7ccc67889285e6263ae3f14fd01ce95d88d84a6b0a1490'
    assert units['diagnostic-executable']['compiled']['object']['sha256'] == '128ee9531302f79e4c0a62017c6475a6a1fc5e7e83631f24717bbdc60f37913f'
    old_append = t.read(R / '.scratch/inference-packed-sequence-20261028/compile/append/compiled.json')
    assert original[63] == old_append['object']
    assert original[52] == ready['sdk']['resources']['compiled']['object']
    assert original[47] == ready['sdk']['executable']['compiled']['object']
    normal = list(original)
    normal[52] = units['resources']['compiled']['object']; normal[63] = units['append']['compiled']['object']
    diagnostic = list(normal); diagnostic[47] = units['diagnostic-executable']['compiled']['object']
    assert sum(a != c for a, c in zip(original, normal)) == 2
    assert sum(a != c for a, c in zip(normal, diagnostic)) == 1
    stats = []
    for row in original:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        stats.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns,
                          retained_sha256=row['sha256']))
    original_recipe = t.command(ready['recipe']['path']); links = {}; input_pins = {}
    for variant, rows in (('normal', normal), ('diagnostic', diagnostic)):
        replacements = {t.key(a['path']): c['path'] for a, c in zip(original, rows) if a != c}
        command = []
        for arg in original_recipe:
            arg = replacements.get(t.key(arg), arg)
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / ('bin/hyle-source-spans-' + variant)).with_suffix(suffix)); break
            command.append(arg)
        assert len({t.key(row['path']) for row in rows}) == 229
        for row in rows:
            assert sum(t.key(arg) == t.key(row['path']) for arg in command) == 1
        t.save(W / ('inputs-' + variant + '.json'), rows)
        input_pins[variant] = t.pin(W / ('inputs-' + variant + '.json'))
        t.save(W / ('link-' + variant + '.json'), dict(command=command, timeout_seconds=240))
        links[variant] = t.pin(W / ('link-' + variant + '.json'))
    env = t.read(BASE / 'environment.json'); runtime = t.read(ready['runtime']['path'])
    runtime['PATH'] = str(W / 'bin') + ';' + runtime['PATH']; t.exact(runtime['native'])
    t.save(W / 'environment.json', env); t.save(W / 'runtime.json', runtime)
    t.save(W / 'retained-input-stats.json', stats)
    frozen = dict(helper=t.pin(__file__), diagnostic_helper=t.pin(d.__file__), screen_helper=t.pin(s.__file__),
        baseline=t.pin(ready_path), baseline_ready=ready, units=units,
        old_append_receipt=t.pin(R / '.scratch/inference-packed-sequence-20261028/compile/append/compiled.json'),
        scope='Same retained 4ca9 Model ff22/229-input consumer. Normal changes only Source-span resources + passed append; diagnostic also reuses the already compiled reachability executable. Not the current complete engine.')
    t.save(W / 'source-freeze.json', frozen)
    t.save(W / 'plan.json', dict(status='PREPARED_LINKS_NOT_RUN', frozen=t.pin(W / 'source-freeze.json'),
        original_inputs=ready['inputs'], inputs=input_pins, links=links,
        retained=t.pin(W / 'retained-input-stats.json'), environment=t.pin(W / 'environment.json'),
        runtime=t.pin(W / 'runtime.json'), counts=dict(CXX=0, NVCC=0, links=2, inputs_each=229,
        diagnostic_model_runs=2, optional_ordinary_timing_processes=8, memory_processes=0)))
    print('PREPARED only; root executes normal and diagnostic links separately')


def validate():
    plan = t.read(W / 'plan.json')
    for key in ('frozen', 'original_inputs', 'retained', 'environment', 'runtime'): t.exact(plan[key])
    for row in (*plan['inputs'].values(), *plan['links'].values()): t.exact(row)
    frozen = t.read(plan['frozen']['path'])
    for key in ('helper', 'diagnostic_helper', 'screen_helper', 'baseline', 'old_append_receipt'): t.exact(frozen[key])
    for unit in frozen['units'].values():
        t.exact(unit['receipt']); t.exact(unit['compiled']['object'])
    for row in t.read(plan['retained']['path']):
        st = Path(row['path']).stat()
        assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    return plan, frozen


def parse_link(variant):
    assert variant in ('normal', 'diagnostic'); plan, frozen = validate()
    folder = W / 'links' / variant; process = t.read(folder / 'process.json')
    assert process['exit'] == 0 and not process['timed_out']
    assert t.command(folder / 'command.json') == t.command(plan['links'][variant]['path'])
    ready = dict(image=t.pin(W / ('bin/hyle-source-spans-' + variant + '.exe')),
        inputs=plan['inputs'][variant], process=process, recipe=t.pin(folder / 'command.json'),
        runtime=plan['runtime'], source_freeze=plan['frozen'], compiled=frozen['baseline_ready']['compiled'],
        units=frozen['units'], diagnostic=variant == 'diagnostic', scope=frozen['scope'])
    s.keep(W / ('ready-' + variant + '.json'), ready)
    print('LINK READY', variant)


def link(variant):
    assert variant in ('normal', 'diagnostic'); plan, _ = validate()
    (W / 'bin').mkdir(exist_ok=True)
    native = t.read(plan['runtime']['path'])['native']; alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path'])
    t.execute(t.command(plan['links'][variant]['path']), W / 'links' / variant, 240); parse_link(variant)


def prepare_runs():
    plan, _ = validate(); ready = t.read(W / 'ready-diagnostic.json'); t.exact(ready['image'])
    groups = []
    for ordinal, role in enumerate(('ordinary', 'mtp'), 1):
        cfg = copy.deepcopy(t.read(BASE / ('single-' + role + '-plan.json')))
        original = next(row for row in cfg['commands'] if row['variant'] == 'candidate')
        expected = Path(original['folder']) / 'consumer-result.json'
        assert t.read(Path(original['folder']) / 'result.json')['exit'] == 0
        entry = dict(original, ordinal=1, window_ordinal=ordinal, variant='diagnostic',
            folder=str(d.W / 'runs' / role), command=[ready['image']['path'], *original['command'][1:]],
            image=ready['image'], environment=plan['runtime'], ready=t.pin(W / 'ready-diagnostic.json'))
        cfg.update(commands=[entry], arm_order=['diagnostic'], timing_processes=0, memory_processes=0,
            diagnostic_processes=1, performance_claim=False, binding=t.pin(W / 'source-freeze.json'))
        path = d.W / (role + '-plan.json'); t.save(path, cfg)
        groups.append(dict(role=role, plan=t.pin(path), expected_full_report=t.pin(expected)))
    t.save(d.W / 'run-plan.json', dict(helper=t.pin(d.__file__), adapter=t.pin(__file__), groups=groups,
        diagnostic_processes=2, performance_claim=False, original_screen_summary=t.pin(BASE / 'summary.json')))
    print('PREPARED two diagnostic runs; no assumed hit-count improvement')


def screen_prepare():
    plan, frozen = validate()
    for role in ('ordinary', 'mtp'):
        assert t.read(d.W / 'runs' / role / 'analysis.json')['status'] == 'PASS_DIAGNOSTIC_FACTS'
    normal_path = W / 'ready-normal.json'; normal = t.read(normal_path)
    control = dict(frozen['baseline_ready'], runtime=plan['runtime'])
    versions = {'control': control, 'candidate': normal}
    for ready in versions.values(): t.exact(ready['image']); t.exact(ready['inputs'])
    assert not normal['diagnostic']
    t.save(s.W / 'ready-control.json', control); t.save(s.W / 'ready-candidate.json', normal)
    original_binding = t.read(BASE / 'binding.json')
    work = original_binding['work']
    for row in work.values(): t.exact(row)
    binding = dict(versions={v: dict(ready=t.pin(s.W / ('ready-' + v + '.json')), **versions[v]) for v in versions},
        work=work, runtime=plan['runtime'], adapter=t.pin(__file__), source_freeze=plan['frozen'],
        scope='Eight fresh ordinary-only timings: baseline physical-span CLI vs Source-span plus append changes, same Model ff22. No MTP timing or memory measurement.')
    t.save(s.W / 'binding.json', binding); groups = []; ordinal = 0
    for scenario, role in s.STAGES:
        cfg = copy.deepcopy(t.read(BASE / (scenario + '-ordinary-plan.json')))
        template = next(row for row in cfg['commands'] if row['variant'] == 'candidate')
        commands = []
        for local, variant in enumerate(ORDER, 1):
            ordinal += 1; ready = binding['versions'][variant]
            commands.append(dict(ordinal=local, window_ordinal=ordinal, variant=variant, scenario=scenario, role=role,
                arm='hyle_auto', folder=str(s.W / 'runs' / (scenario + '-' + role) / (f'{local:02d}-' + variant)),
                command=[ready['image']['path'], *template['command'][1:]], image=ready['image'],
                environment=plan['runtime'], ready=ready['ready']))
        cfg.update(commands=commands, arm_order=list(ORDER), binding=t.pin(s.W / 'binding.json'), script=t.pin(__file__),
            timing_processes=4, memory_processes=0, independent_memory_processes=0, processes=4,
            historical_samples_pooled=False, causal_architecture_benefit_claim=False)
        path = s.W / (scenario + '-' + role + '-plan.json'); t.save(path, cfg)
        groups.append(dict(scenario=scenario, role=role, plan=t.pin(path)))
    assert ordinal == 8
    t.save(s.W / 'window-plan.json', dict(helper=t.pin(__file__), binding=t.pin(s.W / 'binding.json'), groups=groups,
        timing_processes=8, memory_processes=0, samples_each=2, order=list(ORDER), automatic_retries=0,
        contract='All complete producer non-time facts stable/equal, same original endpoint/args; two fresh samples per image and workload, no pooled historical timings.'))
    print('PREPARED8 ordinary-only timing screen; no native started')


def screen_summary():
    rows = [t.read(s.W / 'runs' / (scenario + '-' + role) / 'summary.json') for scenario, role in s.STAGES]
    assert all(row['status'] == 'COMPLETE_STABLE' for row in rows)
    actual = [p for row in rows for p in row['actual_processes']]
    assert len(actual) == len({(p['pid'], p['started_unix_ns']) for p in actual}) == 8
    s.b.save(s.W / 'summary.json', dict(status='COMPLETE8_SOURCE_SPAN_APPEND_SCREEN', groups=rows,
        binding=t.pin(s.W / 'binding.json'), timing_processes=8, memory_processes=0,
        scope='Same 4ca9 Model ff22, Source span reuse + append changes together; ordinary single/two only. Descriptive screening, not the current complete-engine benchmark.'))
    print('COMPLETE8_SOURCE_SPAN_APPEND_SCREEN')


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare(sys.argv[2])
    elif action == 'link': link(sys.argv[2])
    elif action == 'parse-link': parse_link(sys.argv[2])
    elif action == 'prepare-runs': prepare_runs()
    elif action == 'diagnostic': validate(); d.run(sys.argv[2])
    elif action == 'analyze-diagnostic': validate(); d.analyze(sys.argv[2])
    elif action == 'screen-prepare': screen_prepare()
    elif action == 'screen': s.run(sys.argv[2], 'ordinary')
    elif action == 'analyze-screen': s.analyze(sys.argv[2], 'ordinary')
    elif action == 'screen-summary': screen_summary()
    else: raise SystemExit('prepare ACTUAL_RESOURCES_RECEIPT | link/parse-link normal|diagnostic | prepare-runs | diagnostic/analyze-diagnostic ordinary|mtp | screen-prepare | screen/analyze-screen single|two-turn | screen-summary')
