# M2 单测试准备（尚未授权执行）

当前只完成 `python .scratch/inference-optional-alias-alignment-harness-20261030/build.py prepare`：保存前置region/core三文件快照，逐一核对当前231个M1对象、runtime、GTest库与原region93个仓库依赖，生成实际command arrays。没有apply、CXX、link或native进程。

前置region为 `8d8992f4…`、Graph `b8e23a2d…`；待root提交pool+M1并应用已审核的M2测试窄补丁后，region必须精确匹配 `ed515976…` 才能执行。全部SDK/engine231对象直接使用当前M1基线，其中9个私有布局依赖已重编、222个原对象复用；不重编SDK，不复制SDK树。

以下命令仅为后续获root明确授权时的recipe：

```powershell
python .scratch/inference-optional-alias-alignment-harness-20261030/build.py compile attempt1
python .scratch/inference-optional-alias-alignment-harness-20261030/build.py link attempt1
python .scratch/inference-optional-alias-alignment-harness-20261030/build.py run attempt1
```

唯一filter：`GraphRegions.LateOptionalAliasPreservesDownstreamAlignment`，只CPU；一个GTest内保留原三个控制和native Unary。只计划1region CXX、1link、1CPU进程，0SDK CXX/0GPU。每次attempt保独立命令、进程、stdout/stderr、依赖或XML；实际失败写 `OBSERVED_TEST_FAILURE`，不按预测记PASS。当前代码预测最后128B可选alias case被拒绝，尚无该项实际运行证据。
