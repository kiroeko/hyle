# 当前接续（bc655之后）

完整goal持续active；前一turn为实质progress：pool+M1实现、真实验证、公开证据与提交完成，未完成整个goal。
main/origin/main已推送bc6556f8b1d4248df0dc0b47b11719b9b7341748；16源码与3文档及证据已提交，无需重apply旧补丁。
公开evidence inference-output-pool-and-constant-view-2026-10-30.{json,zip}；102进程终态/9历史native失败；当前42 Graph/cache、11pool用例、4默认fullV pairs、完整Session通过。root与bridge全661zip成员回读，root另重读756raw核byte/SHA。root test.ps1精确清理790文件/4719355392B，source/objects/commands/receipts/runtime原件仍在；旧bin/raw已无，不重跑旧collectors。

## 当前工作树仅两文件，保留

- region_provider_test.cc新增M2 CPU机制测试（86行），SHA ed51597659822be59a0024efedf67075346b1e337949c06811ac4a7caddc6506。core仍bc655的b8e23a2d…，没有M2生产fix。
- inference-progress同步开始与真实失败。完整两文件patch为本目录pending-test-and-progress.patch，勿自动apply覆盖当前工作树。

M2 actual attempt1：1region CXX/1link成功，1CPU filter失败/skip0。首个offset128/nonalias control完成两replay；第二offset256/native optional control在node2无法找到implementation，最后offset128/native目标场景尚未执行。不能声称复现M2 Graph缺陷。
GLM agent在.scratch/inference-optional-alias-native-probe-20261030准备/执行同231对象的直接native API probe；第一次诊断TU CXX因两处Status/ResultError ternary歧义失败，已授权显式if/else修正及attempt2，原最多1link/1CPU；保留全部attempt。核实际process/handle，不能据本记录推测live/terminal；agent owns handles。

## 后续仍未应用

- warm同次Phase事实复用：same-call-phase-v2.patch，原完整preflight/计时/冷接纳后resolve保持；不要用v1。
- 三辅助冷程序private factory：.scratch/inference-auxiliary-cold-program-extract-20261030，5source候选patch SHA61323c70…/74114B；main base仍d76e2b00…当前bc655 bytes。Episode原布局为内嵌guard单独私有头；Model保政策/guard/init/publish/retire。只有scratch、无产品apply/build。架构agent修了外层facts shadow，11真实runtime全文51443B精确不变；旧proof范围错误保留，bridge独立审与compile recipe准备仍在继续。以各agent最新结果为准。
- concrete admission伪缺项已撤销：现ProgramIo已支持concrete，ColdProgram是薄持有包装，不造新API/Family/owner。依据.scratch/inference-concrete-program-admission-20261030。

仍先共同架构后默认性能，不重开已完成驱动/MTP功能，不下载模型。完整goal见roadmap，当前scope不能缩成M2或private工厂。

最新M2诊断：直接native API probe已完成（第1次诊断CXX语法失败保留，第2次CXX/link/CPU全部成功）。F32 Neg原生明确Unimplemented，elementwise.cc379的Neg分支仅BF16，实际elementwise源码身份匹配；原fixture能力假设错，尚未复现Graph缺陷。已授权GLM agent仅改新增M2体，native臂用真实支持的F32 Exp与有界数值回放，非alias Probe仍保合法Neg；保原零Copy/256B/固定provider/别名断言，重编region attempt2后重跑单CPU filter，不改SDK。区域新SHA和新patch以agent最新sourceproof/实际git diff为准，旧ed515与旧pending patch只是上一个未过fixture的历史快照。
