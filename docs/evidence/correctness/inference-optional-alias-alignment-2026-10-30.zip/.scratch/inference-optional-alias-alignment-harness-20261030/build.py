"""Prepared M2 CPU-only recipe. No action other than prepare is currently authorized."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
M1 = R / '.scratch/inference-constant-view-alignment-harness-20261030'
EXTRACT = R / '.scratch/inference-optional-alias-alignment-20261030/rebase-current-m1'
EXECUTOR = R / '.scratch/inference-program-identity-20261029/build.py'
ENVIRONMENT = R / '.scratch/inference-natural-logits-control-20261029/environment.json'
FILTER = 'GraphRegions.LateOptionalAliasPreservesDownstreamAlignment'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def pin(path):
    path = Path(path).resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}

def key(path):
    return os.path.normcase(os.path.abspath(path))

def exact(item):
    actual = pin(item['path'])
    assert all(actual[field] == item[field] for field in ('bytes', 'sha256')), item['path']

def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve the prepared recipe.'
    extract = read(EXTRACT / 'plan.json')
    base_path = M1 / 'model-link-base.json'
    base = read(base_path)
    assert len(base['retained']) == 231
    assert base['retained_categories']['replaced_private_ABI_SDK'] == 9
    assert base['retained_categories']['old_reused'] == 222
    source = R / extract['precondition']['path']
    precondition = dict(extract['precondition'], path=str(source))
    exact(precondition)
    exact(extract['core'])
    candidate = dict(extract['candidate'], path=str(source))
    prior_receipt_path = Path(base['current_consumers']['region']['receipt']['path'])
    exact(base['current_consumers']['region']['receipt'])
    prior = read(prior_receipt_path)
    for item in [prior['object'], *prior['source_identities'], *base['retained'], base['runtime']]:
        exact(item)
    old_folder = Path(prior['object']['path']).parent
    command_path = old_folder / 'command.json'
    original_compile = read(command_path)
    compile_folder = W / 'compile/region/attempt1'
    compile_command = [arg.replace(str(old_folder), str(compile_folder)) for arg in original_compile]
    assert sum(key(arg) == key(source) for arg in compile_command) == 1
    assert any(arg == '/DHYLE_COMPUTE_CPU=1' for arg in compile_command)
    assert not any(arg.startswith('/DHYLE_COMPUTE_CUDA') for arg in compile_command)
    cli_object = base['current_consumers']['cli']['object']['path']
    object_path = compile_folder / 'unit.obj'
    binary = W / 'bin/region-test.exe'
    link_command = []
    replaced = 0
    for arg in base['link']:
        if key(arg) == key(cli_object):
            arg = str(object_path)
            replaced += 1
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str(binary.with_suffix(suffix))
                break
        link_command.append(arg)
    assert replaced == 1
    gtest = read(M1 / 'plan.json')['gtest_libraries']
    for item in gtest:
        exact(item)
        if not any(key(arg) == key(item['path']) for arg in link_command):
            link_command.append(item['path'])
    assert all(sum(key(arg) == key(item['path']) for arg in link_command) == 1 for item in base['retained'])
    runtime_command = [str(binary), '--gtest_color=no', '--gtest_filter=' + FILTER,
        '--gtest_fail_fast', '--gtest_output=xml:' + str(W / 'runs/cpu/attempt1/results.xml')]
    for path in [source, R / 'src/graph/executable.cc', R / 'src/graph/constant_artifact.h', R / 'src/graph/constant_artifact.cc']:
        destination = W / 'source-before' / path.relative_to(R)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(path.read_bytes())
    inputs = [pin(base_path), pin(EXTRACT / 'plan.json'), pin(EXTRACT / 'source-proof.json'),
        pin(command_path), pin(prior_receipt_path), base['sdk_engine_dependencies'], pin(EXECUTOR), pin(ENVIRONMENT)]
    plan = {'status': 'PREPARED_ONLY_WAITING_FOR_ROOT_AFTER_POOL_AND_M1_COMMIT',
        'observed_HEAD': subprocess.check_output(['git', '-C', str(R), 'rev-parse', 'HEAD'], text=True).strip(),
        'inputs': inputs, 'precondition': precondition, 'candidate_source': candidate,
        'core': extract['core'], 'retained': base['retained'], 'gtest_libraries': gtest,
        'runtime': base['runtime'], 'prior_region_receipt': base['current_consumers']['region']['receipt'],
        'unchanged_region_dependencies': [item for item in prior['source_identities'] if key(item['path']) != key(source)],
        'compile': compile_command, 'compile_default_folder': str(compile_folder), 'object': str(object_path),
        'link': link_command, 'binary': str(binary), 'run': runtime_command,
        'filter': FILTER, 'expected_GTests': 1, 'expected_skipped': 0,
        'planned_processes': {'CXX': 1, 'link': 1, 'CPU_native': 1, 'SDK_CXX': 0, 'GPU_native': 0},
        'retained_scope': '231 actual current M1 inputs:9 private-layout replacements and222 retained; no SDK rebuild or binary copy',
        'limits': 'No patch application or process execution during prepare. M2 third subcase rejection is only a source prediction. Preserve actual native failure/skip/timeout.',
    }
    save(W / 'plan.json', plan)
    save(W / 'commands-prepared.json', {'compile': compile_command, 'link': link_command, 'CPU': runtime_command})
    print('PREPARED:1regionCXX+1link+1CPUfilter;231current inputs,0SDK/GPU;no execution')

def frozen(plan):
    for item in [plan['candidate_source'], plan['core'], *plan['unchanged_region_dependencies'],
                 *plan['retained'], *plan['gtest_libraries'], plan['runtime']]:
        exact(item)
    for item in plan['inputs']:
        exact(item)

def execute(command, folder, timeout):
    spec = importlib.util.spec_from_file_location('m2_existing_process_executor', EXECUTOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.W = W
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
    module.execute(command, folder, timeout)

def compile_one(attempt):
    plan = read(W / 'plan.json')
    frozen(plan)
    folder = W / 'compile/region' / attempt
    command = [arg.replace(plan['compile_default_folder'], str(folder)) for arg in plan['compile']]
    execute(command, folder, 900)
    dependencies = read(folder / 'dependencies.json')['Data']
    paths = sorted({Path(path).resolve() for path in [dependencies['Source'], *dependencies['Includes']]
                    if Path(path).is_relative_to(R)})
    assert R / 'src/graph/constant_artifact.h' in paths
    receipt = {'object': pin(folder / 'unit.obj'), 'dependencies': pin(folder / 'dependencies.json'),
        'process': pin(folder / 'process.json'), 'source_identities': [pin(path) for path in paths]}
    save(folder / 'receipt.json', receipt)
    save(W / 'compile/region/receipt.json', receipt)

def link_one(attempt):
    plan = read(W / 'plan.json')
    frozen(plan)
    receipt = read(W / 'compile/region/receipt.json')
    for item in [receipt['object'], *receipt['source_identities']]:
        exact(item)
    (W / 'bin').mkdir(exist_ok=True)
    target = W / 'bin' / Path(plan['runtime']['path']).name
    if target.exists():
        actual = pin(target)
        assert all(actual[field] == plan['runtime'][field] for field in ('bytes', 'sha256'))
    else:
        shutil.copyfile(plan['runtime']['path'], target)
    command = [receipt['object']['path'] if key(arg) == key(plan['object']) else arg for arg in plan['link']]
    execute(command, W / 'link/region' / attempt, 240)
    save(W / 'ready-region.json', pin(plan['binary']))

def run_one(attempt):
    plan = read(W / 'plan.json')
    frozen(plan)
    image = read(W / 'ready-region.json')
    exact(image)
    folder = W / 'runs/cpu' / attempt
    command = [arg.replace(str(W / 'runs/cpu/attempt1'), str(folder)) for arg in plan['run']]
    save(folder / 'image.json', image)
    try:
        execute(command, folder, 300)
    except SystemExit:
        pass  # Preserve and parse a genuine test failure; never turn it into PASS.
    process = read(folder / 'process.json')
    assert not process['timed_out']
    xml = ET.parse(folder / 'results.xml').getroot()
    cases = list(xml.iter('testcase'))
    actual = [case.get('classname') + '.' + case.get('name') for case in cases]
    assert actual == [FILTER] and int(xml.get('tests', '-1')) == 1
    assert not list(xml.iter('skipped')) and all(case.get('status') == 'run' for case in cases)
    messages = [failure.get('message', '')[:6000] for failure in xml.iter('failure')]
    passed = process['exit'] == 0 and not messages and int(xml.get('errors', '0')) == 0
    result = {'status': 'PASS' if passed else 'OBSERVED_TEST_FAILURE', 'native_exit': process['exit'],
        'filter': FILTER, 'tests': 1, 'failures': int(xml.get('failures', '-1')), 'skipped': 0,
        'messages': messages, 'xml': pin(folder / 'results.xml'), 'process': pin(folder / 'process.json'),
        'scope': 'M2 one CPU mechanism test, three original native controls. No GPU or default performance result.'}
    save(folder / 'report.json', result)
    print(json.dumps(result))
    if not passed:
        raise SystemExit(1)

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
    elif action == 'compile':
        compile_one(sys.argv[2])
    elif action == 'link':
        link_one(sys.argv[2])
    elif action == 'run':
        run_one(sys.argv[2])
    else:
        raise ValueError(action)
