"""One baseline red2(no failfast), then one finite combinedCPU pass, no skips."""
from pathlib import Path
import importlib.util,json,re,sys,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('m2_cpu_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
m2=['GraphRegions.LateOptionalAliasPreservesDownstreamAlignment','GraphRegions.LateOptionalAliasChainKeepsWeakIntermediateAndStrictFinalAlignment']
def names(source):return [a+'.'+c for a,c in re.findall(r'TEST(?:_F)?\s*\(\s*(\w+)\s*,\s*(\w+)\s*\)',Path(source).read_text())]
if not (W/'cpu-plan.json').exists():
 related=read(R/'.scratch/inference-constant-view-alignment-harness-20261030/regression-plan.json')['tests']
 first=read(R/'.scratch/inference-graph-alias-repair-20261030/test-filters.json')
 existing=first['first_filter'].split(':')+first['related_filter'].split(':')
 constants=[n for n in names(R/'tests/graph/region_provider_test.cc') if n.startswith('GraphConstants.') and n not in related]
 lanes=['GraphRules.RequiredProviderKeepsItsOwnLaneAndWorkspaceMetadata','GraphRules.ConcurrencyAndRequiredProviderRemainHardConstraints','GraphResources.WorkspaceBudgetSelectsFeasibleStorageAndLane','GraphResources.LaneSearchSharesStateAndPrepareLimitsWithNodeCover','GraphResources.MatureIntermediateMovesToFeasibleStorageAndPreservesAliasRules','GraphRegions.MissingLaneSelectsAnotherTargetWithoutWaivingPlacement','GraphRegions.ColdRegionAccessUsesActualLaneAndExactContextQueue']
 cache=names(R/'tests/graph/constant_artifact_cache_test.cc');alias=names(R/'tests/graph/alias_liveness_test.cc')
 selected=list(dict.fromkeys(m2+related+constants+existing+lanes+cache+alias))
 actual=names(R/'tests/graph/region_provider_test.cc')+cache+alias
 assert len(actual)==len(set(actual)) and all(n in actual for n in selected)
 assert len(cache)==20 and len(alias)==4
 save(W/'cpu-plan.json',dict(baseline=m2,combined=selected,combined_count=len(selected),scope='2new+priorconstant42+selected alias/error/budget/lane+4dedicatedliveness;onecombined CPU,not fullGraph.'))
p=read(W/'cpu-plan.json');arm=sys.argv[1];assert arm in ('baseline','candidate');selected=p['baseline' if arm=='baseline' else 'combined']
folder=W/'runs'/('baseline-red2' if arm=='baseline' else 'candidate-combined')/'attempt1';image=read(W/('ready-'+('baseline-cpu' if arm=='baseline' else 'candidate-cpu')+'.json'));exact(image)
save(folder/'image.json',image);command=[image['path'],'--gtest_color=no','--gtest_filter='+':'.join(selected),'--gtest_output=xml:'+str(folder/'results.xml')]
try:b.s.b.execute(command,folder,300)
except SystemExit:
 if arm!='baseline':raise
x=ET.parse(folder/'results.xml').getroot();tests=list(x.iter('testcase'));assert len(tests)==len(selected) and not list(x.iter('skipped'))
assert all(t.get('status')=='run' and t.get('result')=='completed' for t in tests)
assert set(t.get('classname')+'.'+t.get('name') for t in tests)==set(selected)
failures=sum(bool(t.findall('failure')) for t in tests);process=read(folder/'process.json')
if arm=='baseline':assert process['exit']==1 and failures==2,'Both originalb8 cases must actually be red, no failfast.'
else:assert process['exit']==0 and failures==0
save(W/(arm+'-cpu-summary.json'),dict(status='EXPECTED_RED2' if arm=='baseline' else 'PASS',tests=len(tests),failures=failures,skipped=0,xml=pin(folder/'results.xml'),actual_names=selected))
print(arm,'CPU',len(tests),'failures',failures,'skip0',flush=True)
