"""Offline compact default-pair summary from current exact reports only."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('factory_summary_helpers',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
checks=[]
for case in ('ordinary-single','mtp-single','ordinary-two','mtp-two'):
 compared=b.read(W/('compare-'+case+'.json'));assert compared['status']=='PASS' and not compared['differences']
 old=b.read(W/'runs/baseline'/case/'attempt1/report.json');new=b.read(W/'runs/candidate'/case/'attempt1/report.json')
 checks.append(dict(case=case,all_non_timing_fields_equal=True,differences=[],reports=dict(baseline=compared['baseline_or_retained_reference'],candidate=compared['candidate']),
  timing_diagnostic={key:dict(baseline=old[key],candidate=new[key]) for key in ('prefill_seconds','decode_seconds','session_seconds','startup_to_ready_seconds')},
  scope='Fresh same args bc655 b8 versus M2oneGraph replacement, same app objects/privateABI. Only time suffixes excluded; every unknown/resource/work field retained. Aggregate only.'))
b.save(W/'whole-cli-summary.json',dict(status='PASS_ALL_FOUR_DEFAULT_CASES',checks=checks))
print(json.dumps([(row['case'],row['timing_diagnostic']['decode_seconds']) for row in checks]))
