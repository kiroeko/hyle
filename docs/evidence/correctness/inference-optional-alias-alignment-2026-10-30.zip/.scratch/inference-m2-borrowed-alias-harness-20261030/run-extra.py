"""Reuse existing finitePro77 runner/parser and one CPU tiny-state case."""
from pathlib import Path
import importlib.util,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('m2_extra_native',R/'.scratch/inference-output-pool-capacity-harness-20261030/run-native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
n.W=W;n.R=R
source=n.read(R/'.scratch/inference-constant-view-alignment-harness-20261030/run-plan.json')
row=dict(source['cases']['glm-pro-cuda']);row['command'][0]=str(W/'bin/glm-pro.exe');row['command']=[a for a in row['command'] if not a.startswith('--gtest_output=')];row['command'].append('--gtest_output=xml:'+str(W/'runs/candidate/glm-pro-cuda/attempt1/results.xml'))
tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
source['cases']={'glm-pro-cuda':row,'tiny-batch-state-cpu':dict(unit='tiny',command=[str(W/'bin/tiny.exe'),'--cpu',str(tiny),'--mtp-batch-state'])}
if not (W/'run-plan.json').exists():n.save(W/'run-plan.json',source)
for case in sys.argv[1:] or ['glm-pro-cuda','tiny-batch-state-cpu']:n.run(case,source['cases'][case])
