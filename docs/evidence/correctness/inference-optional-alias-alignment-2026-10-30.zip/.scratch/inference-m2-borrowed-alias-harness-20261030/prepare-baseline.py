"""M2 baseline and exact cached recipes only. No compiler/linker/native is invoked."""
from pathlib import Path
import importlib.util,json,hashlib,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-constant-view-alignment-harness-20261030/model-link-base.json'
spec=importlib.util.spec_from_file_location('m2_baseline_prior',BASE.parent/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
assert not (W/'baseline-plan.json').exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='bc6556f8b1d4248df0dc0b47b11719b9b7341748'
base=read(BASE);assert len(base['retained'])==231
for item in [*base['retained'],base['runtime']]:exact(item)
copies=[]
for relative,expected in [('src/graph/executable.cc','b8e23a2d8219a787ce6338cb602b4a1543c3cc73ef5f0ec17c62884accdd51ac'),('tests/graph/region_provider_test.cc','8d8992f4685a7fbcaad41f4b8595beb5af9ba485683ca84b13bb526b5cefcb14')]:
 data=subprocess.check_output(['git','show',head+':'+relative],cwd=R);assert hashlib.sha256(data).hexdigest()==expected
 out=W/'baseline-source'/relative;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 copies.append(dict(relative=relative,commit=head,snapshot=pin(out)))
 if relative.startswith('src/'):assert (R/relative).read_bytes()==data
pending_region=pin(R/'tests/graph/region_provider_test.cc')
assert pending_region['sha256']!=copies[1]['snapshot']['sha256'],'Expected separately pending M2 fixture'
pending=W/'observed-pending-region/region_provider_test.cc';pending.parent.mkdir(parents=True,exist_ok=True);pending.write_bytes(Path(pending_region['path']).read_bytes())
index=read(base['sdk_engine_dependencies']['path']);affected=[]
for row in index['inspected']:
 exact(row['dependencies']);dep=read(row['dependencies']['path'])['Data']
 if any(key(p)==key(R/'src/graph/executable.cc') for p in [dep['Source'],*dep['Includes']]):affected.append(dict(**row,source=dep['Source']))
assert len(affected)==1
graph_receipt=read(BASE.parent/'compile/sdk-executable/receipt.json');assert key(graph_receipt['object']['path'])==key(affected[0]['object'])
for item in [graph_receipt['object'],*graph_receipt['source_identities']]:exact(item)
consumers={}
for name in ('cli','tiny','session','glm-pro','constant-cache-test'):
 row=base['current_consumers'][name];exact(row['receipt']);receipt=read(row['receipt']['path'])
 for item in [receipt['object'],*receipt['source_identities']]:exact(item)
 assert not any(key(i['path'])==key(R/'src/graph/executable.cc') for i in receipt['source_identities'])
 consumers[name]=dict(**row,source_identities=receipt['source_identities'])
region_record=base['current_consumers']['region'];region=read(region_record['receipt']['path']);exact(region['object'])
assert next(i['sha256'] for i in region['source_identities'] if key(i['path'])==key(R/'tests/graph/region_provider_test.cc'))==copies[1]['snapshot']['sha256']
def relocate(raw,name,old_source,new_source):
 folder=W/'compile'/name/'attempt1';args=[];count=0
 for index,arg in enumerate(raw):
  if index and raw[index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
  elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
  elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
  elif key(arg)==key(old_source):arg=str(new_source);count+=1
  args.append(arg)
 assert count==1 and '/c' in args and len([a for a in args if a.lower().endswith('.cc')])==1
 return args
units={}
for name,source,receipt in [('graph',R/'src/graph/executable.cc',graph_receipt),('region',R/'tests/graph/region_provider_test.cc',region)]:
 recipe=Path(receipt['process']['path']).parent/'command.json';raw=read(recipe)
 units[name]=dict(source=str(source),compile=relocate(raw,name,source,source),recipe=pin(recipe),object=str(W/'compile'/name/'attempt1/unit.obj'))
# Optional current compile for true last-reader/cross-lane tests: legacy object has no dependency receipt.
alias_source=R/'tests/graph/alias_liveness_test.cc';alias=read(R/'.scratch/architecture-refactor-2026-10-18/graph-lifecycle-review/alias-liveness/alias-test.obj.json')
region_command=read(Path(region['process']['path']).parent/'command.json')
optional=dict(source=pin(alias_source),legacy_identity=pin(R/'.scratch/architecture-refactor-2026-10-18/graph-lifecycle-review/alias-liveness/alias-test.obj.json'),
 legacy_object=alias['object'],legacy_not_qualified_for_reuse='Source matches, but no header dependencies; do not assert current inline/public-header ABI compatibility.',
 compile=relocate(region_command,'alias-liveness',R/'tests/graph/region_provider_test.cc',alias_source),object=str(W/'compile/alias-liveness/attempt1/unit.obj'))
test_plan=R/'.scratch/inference-optional-alias-alignment-20261030/chain-fixture/plan.json'
save(W/'baseline-plan.json',dict(status='BASELINE_AND_RECIPES_ONLY_NO_EXECUTION',head=head,base=pin(BASE),retained=base['retained'],runtime=base['runtime'],snapshots=copies,
 original_graph=graph_receipt['object'],original_graph_receipt=pin(BASE.parent/'compile/sdk-executable/receipt.json'),graph_source_pins=graph_receipt['source_identities'],
 old_region=region_record,old_region_source_snapshot=copies[1]['snapshot'],observed_pending_region=pending_region,observed_pending_region_snapshot=pin(pending),
 consumers=consumers,affected_retained=affected,source_dependency_rows=len(index['inspected']),unavailable_metadata=index['unavailable'],
 final_M2_tests_plan=pin(test_plan),scope='Baseline uses committed8d region and b8Graph/M1 private ABI. Pendingda7 fixture is not baseline or finald9e test candidate. Aux remains unapplied.',CXX=0,links=0,native=0))
save(W/'recipes-prepared.json',dict(status='PREPARED_ONLY',units=units,optional_alias_liveness=optional,retained=base['retained'],runtime=base['runtime'],
 original_graph=graph_receipt['object'],original_link=base['link'],original_cli=base['current_consumers']['cli']['object'],consumers=consumers,
 old_region=region_record,gtest_libraries=read(BASE.parent/'plan.json')['gtest_libraries'],SDK_CXX=1,region_CXX=1,optional_liveness_CXX=1,
 expected_retained=231,reused_retained=230,private_header_or_Plan_layout_change=False,max_cl=2,NVCC=0,downloads=0,
 combined_CPU_link='Newregion + cachedcurrentprivate-cache test object; optional freshly compiled liveness object. Onegtest_main, no repeatedGraph source/SDKappend.',
 application_CXX=0,execution=0))
print(json.dumps(dict(status='M2_BASELINE_RECIPES_READY',baseline_graph='b8e23a2d',baseline_region='8d8992f4',retained=231,reuse=230,SDK_CXX=1,region_CXX=1,optional_true_liveness_CXX=1,application_CXX=0,executed=0)))
