"""M2 three-TU finite harness; one Graph replacement, no other SDK compile."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import importlib.util,json,shutil,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-constant-view-alignment-harness-20261030/model-link-base.json'
spec=importlib.util.spec_from_file_location('m2_build_prior',BASE.parent/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
s=b.s;s.W=s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
def prepare():
 assert not (W/'plan.json').exists()
 p=read(W/'recipes-prepared.json');alias=p['optional_alias_liveness'];p['units']['alias-liveness']=dict(source=alias['source']['path'],compile=alias['compile'],object=alias['object'])
 expected={'graph':'8387c86edd64fcc2c5257664ce028d344a5133d8c6a1c2b8628adbdf375aec40','region':'d9e49d1d518e5851205795e3a94ea02b6bae16e298e2dfca52133f7b4d2a70dd','alias-liveness':'b44beeb76ed4b6ea2eeb53451890f10a484066c2a9f54ae89241d17a31ea0da7'}
 frozen=[]
 for name,u in p['units'].items():
  source=Path(u['source']);actual=pin(source);assert actual['sha256']==expected[name]
  out=W/'source-frozen'/source.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(source.read_bytes());frozen.append(dict(source=actual,snapshot=pin(out)))
 p['source_freeze']=frozen;p['base']=pin(BASE);p['status']='ROOT_AUTHORIZED_CURRENT_SOURCE_FROZEN';save(W/'plan.json',p)
 (W/'bin').mkdir(exist_ok=True);shutil.copyfile(p['runtime']['path'],W/'bin'/Path(p['runtime']['path']).name)
 print('FROZEN3;Graph1+region+liveness;230reused',flush=True)
def compile(attempt,names):
 p=read(W/'plan.json')
 for row in p['source_freeze']:exact(row['source'])
 def one(name):
  u=p['units'][name];old=Path(u['object']).parent;folder=W/'compile'/name/attempt;command=[a.replace(str(old),str(folder)) for a in u['compile']]
  s.b.execute(command,folder,900);d=read(folder/'dependencies.json')['Data'];paths=sorted({Path(x).resolve() for x in [d['Source'],*d['Includes']] if Path(x).is_relative_to(R)})
  save(W/'compile'/name/'receipt.json',dict(object=pin(folder/'unit.obj'),dependencies=pin(folder/'dependencies.json'),process=pin(folder/'process.json'),source_identities=[pin(x) for x in paths]))
  print('COMPILED',name,flush=True)
 with ThreadPoolExecutor(max_workers=2) as pool:
  fs=[pool.submit(one,n) for n in names]
  for f in as_completed(fs):f.result()
def link(name,attempt):
 p=read(W/'plan.json');base=read(p['base']['path']);logical_name=name.removeprefix('baseline-');is_baseline=name in ('baseline-cpu','baseline-cli','baseline-session')
 consumer=read(W/'compile/region/receipt.json') if name.endswith('cpu') else read(base['current_consumers'][logical_name]['receipt']['path'])
 for item in [consumer['object'],*consumer['source_identities'],*p['retained'],p['runtime']]:exact(item)
 new_graph=None
 if not is_baseline:
  new_graph=read(W/'compile/graph/receipt.json')
  for item in [new_graph['object'],*new_graph['source_identities']]:exact(item)
 command=[];consumer_count=0;graph_count=0
 for arg in base['link']:
  if key(arg)==key(p['original_cli']['path']):arg=consumer['object']['path'];consumer_count+=1
  if new_graph and key(arg)==key(p['original_graph']['path']):arg=new_graph['object']['path'];graph_count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  command.append(arg)
 assert consumer_count==1 and graph_count==(0 if is_baseline else 1)
 if name=='candidate-cpu':
  cache=read(p['consumers']['constant-cache-test']['receipt']['path']);alias=read(W/'compile/alias-liveness/receipt.json')
  for row in [cache,alias]:
   for item in [row['object'],*row['source_identities']]:exact(item)
   command.append(row['object']['path'])
 if name.endswith('cpu') or name=='glm-pro':
  for lib in p['gtest_libraries']:
   if lib['path'] not in command:command.append(lib['path'])
 s.b.execute(command,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='compile':compile(sys.argv[2],sys.argv[3:])
 elif sys.argv[1]=='link':link(sys.argv[2],sys.argv[3])
 else:raise ValueError(sys.argv[1])
