"""Publish finite optional-alias evidence after all accepted work terminates."""
from pathlib import Path
import hashlib, json, zipfile
import xml.etree.ElementTree as ET
W = Path(__file__).resolve().parent
R = W.parents[1]
NAME = 'inference-optional-alias-alignment-2026-10-30'
H = [R/'.scratch'/n for n in ('inference-optional-alias-alignment-harness-20261030',
    'inference-optional-alias-native-probe-20261030', 'inference-m2-borrowed-alias-harness-20261030')]
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
    b=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=sha(b))
def save(p,d): p.write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode())
def stable(v):
    if isinstance(v,dict):return {k:stable(x) for k,x in v.items() if not k.endswith(('_seconds','_per_second'))}
    if isinstance(v,list):return [stable(x) for x in v]
    return v
sources=[pin(R/n) for n in ('src/graph/executable.cc','tests/graph/region_provider_test.cc')]
assert [x['sha256'] for x in sources]==['8387c86edd64fcc2c5257664ce028d344a5133d8c6a1c2b8628adbdf375aec40','d9e49d1d518e5851205795e3a94ea02b6bae16e298e2dfca52133f7b4d2a70dd']
cpu=read(W/'candidate-cpu-summary.json');red=read(W/'baseline-cpu-summary.json')
for summary,count,failures in ((cpu,78,0),(red,2,2)):
    x=ET.parse(summary['xml']['path']).getroot();cases=list(x.iter('testcase'))
    assert len(cases)==count and len(list(x.iter('failure')))==failures and not list(x.iter('skipped'))
    assert all(t.get('status')=='run' and t.get('result')=='completed' for t in cases)
whole=read(W/'whole-cli-summary.json');assert len(whole['checks'])==4
for row in whole['checks']:
    reports=[read(row['reports'][a]['path']) for a in ('baseline','candidate')]
    assert stable(reports[0])==stable(reports[1])
session=read(W/'session-compare.json');assert session['payload_byte_equal'] and len(session['payloads'])==378
roots=[W/'runs'/a/'session-cuda/attempt1/vectors' for a in ('baseline','candidate')]
for row in session['payloads']:
    bs=[(root/row['relative']).read_bytes() for root in roots];assert bs[0]==bs[1]
    for arm,b in zip(('baseline','candidate'),bs):assert len(b)==row['bytes'] and sha(b)==row[arm+'_sha256']
assert sum(x['bytes'] for x in session['payloads'])==150761472
def norm(v,root):
    if isinstance(v,dict):return {k:norm(x,root) for k,x in v.items()}
    if isinstance(v,list):return [norm(x,root) for x in v]
    return v.replace(str(root),'{VECTORS}') if isinstance(v,str) else v
assert norm(read(roots[0]/'observation.json'),roots[0])==norm(read(roots[1]/'observation.json'),roots[1])
ledger=[];totals={}
for h in H:
    counts={k:dict(passed=0,failed=0) for k in ('CXX','link','native')}
    for p in sorted(h.rglob('process.json')):
        d=read(p);assert d['state']=='TERMINAL' and not d.get('timed_out',False),str(p)
        kind={'compile':'CXX','link':'link','runs':'native'}[p.relative_to(h).parts[0]]
        if h==W and 'baseline-red2' not in p.parts:assert d['exit']==0,str(p)
        counts[kind]['passed' if d['exit']==0 else 'failed']+=1
        ledger.append(dict(kind=kind,exit=d['exit'],receipt=pin(p)))
    totals[h.name]=counts
assert (R/'.scratch/mtp-download-budget-20261023/PAUSED').is_file()
save(W/'root-verification.json',dict(status='PASS',source_pins=sources,candidate_CPU=78,skipped=0,
    old_same_test_TU_red=2,default_pairs=4,direct_session_files_read=756,bytes_per_arm=150761472,
    process_count=len(ledger),totals=totals,processes=ledger))
files=set()
for h in H:
    files.update(p for p in h.iterdir() if p.is_file() and p.suffix in ('.json','.py','.md','.patch'))
    for d in ('compile','link','runs'):
        for p in (h/d).rglob('*'):
            if not p.is_file() or p.name in ('environment.json','dependencies.json'):continue
            if any(x in ('vectors','probes') for x in p.relative_to(h).parts):continue
            if p.suffix in ('.json','.xml','.log'):files.add(p)
for root in roots:files.add(root/'observation.json')
for directory in ('inference-optional-alias-repair-20261030',):
    for p in (R/'.scratch'/directory).iterdir():
        if p.is_file() and p.suffix in ('.json','.py','.md','.patch'):files.add(p)
for directory in ('rebase-current-m1','exp-fixture','chain-fixture'):
    for p in (R/'.scratch/inference-optional-alias-alignment-20261030'/directory).iterdir():
        if p.is_file() and p.suffix in ('.json','.md','.patch'):files.add(p)
archive=R/'docs/evidence/correctness'/(NAME+'.zip');assert not archive.exists()
manifest=[pin(p) for p in sorted(files)]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
    z.writestr('archive-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.infolist())==len(manifest)+1
    for row in manifest:
        b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256'] and b==(R/row['path']).read_bytes()
summary=dict(schema='hyle-optional-alias-alignment-v1',status='CURRENT_FINITE_CHECKS_PASS_HISTORICAL_FAILURES_RETAINED',
    base_commit='bc6556f8b1d4248df0dc0b47b11719b9b7341748',full_goal_complete=False,source_pins=sources,
    implementation='Cold required-group power-of-two congruences preserve intrinsic per-instance requirements. A static internal optional donation must satisfy the whole output group at its complete input-root offset; otherwise the original independent output remains. Original final propagation, liveness/DAG/effect checks, errors, resource ownership and Invocation code remain; no Copy, new owner/API or hot dispatch.',
    observed=dict(old_core_red=red,current_CPU=cpu,retained_inputs=231,reused=230,new_SDK_CXX=1,new_test_TUs=2,
        default_pairs=4,default_non_timing_equal=True,Session_files_per_arm=378,Session_bytes_per_arm=150761472,Session_bytes_exact=True,
        actual_native_controls='Direct128 fresh and256 alias; chain128 weak intermediate alias/final fresh and256 two aliases. Each runs twice with zero Copy. CPU Exp-only mechanism tolerances1e-6/3e-6 are explicit; original model/Session comparisons remain exact.'),
    history='Original F32 NativeNeg fixture was unsupported by the actual retained capability. The direct API probe preserves one diagnostic CXX syntax failure and its corrected diagnostic. Retained F32 NativeExp reproduces the real late-alias refusal; old b8 with the exact final test TU fails both tests. All commands/process/XML and failures are archived.',
    process_totals=totals,failed_processes=[x for x in ledger if x['exit']!=0],
    default_timing_diagnostic=[dict(case=x['case'],**x['timing_diagnostic']) for x in whole['checks']],
    scope='Finite CPU/single-GPU consumers. Domain/external/generated/native address contracts retain prior behavior; pre-constant propagation is unchanged. Required-View compensation is mathematical support, without a claimed newly reachable consumer. No stable performance gain, complete performance window, full default CMake build, second complete model, Mac or multi-card proof.',
    archive=dict(**pin(archive),members=len(manifest)+1,full_member_readback=True))
save(archive.with_suffix('.json'),summary)
print(json.dumps(dict(processes=len(ledger),archive=summary['archive'],totals=totals)))
