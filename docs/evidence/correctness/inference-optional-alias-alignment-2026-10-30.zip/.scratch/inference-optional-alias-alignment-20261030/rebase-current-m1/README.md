# M2 测试窄重基（未应用、构建或运行）

前置：当前 `region_provider_test.cc` 精确 `8d8992f4…`；Graph 当前 `b8e23a2d…`，不包含M2修复。补丁只加入原封不动的一个TEST，逆删除新增段后当前706123B全文件逐字节相同，包含M1三用例、UnknownAllow范围及三处旧fixture logical-span修正。具体 SHA/字节数见 `plan.json`。

这不是fake executor：节点0与3硬锁原RegionProbe的两个不同provider instance，前者4B、后者256B输入要求；节点2硬锁原native Unary（或控制组原RegionProbe）。`compute_ops/operation.cc:959–965` 声明Unary可选alias，`compute_provider_native/elementwise.cc:598–646` 对同形dense输入设置原alias mask，`native_provider.cc:386–396` 真正报告支持。RegionProbe `region_alias_support:973` 返回空；没有新增执行器、alias回调或owner。

三个控制顺序保留：128B切片+非inplace Y必须fresh；256B切片+native Y可alias；128B切片+native Y必须保持fresh以满足下游256B。全图都是原Unary/View，预期三次Neg=-输入切片；现helper在两个真实replay后检查输出和原caller输入字节。三个关键节点均硬锁，不可改provider绕过目标路径。

Graph optional-inplace选择块当前与9f原体逐字节相同，仍不检查“所捐输入的完整root offset与输出alignment”；随后统一传播检查。因此源码预测最后case在当前core拒绝，但这尚不是实测结果，不代签M2缺陷已复现或修复。M1不可变constant冷表示不参与此图（输入为普通mutable caller graph input，经独立producer输出）。
