from pathlib import Path
import importlib.util
import json
import shutil
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('m2_original_api_probe_harness', R / '.scratch/inference-optional-alias-alignment-harness-20261030/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
plan = b.read(b.W / 'plan.json')
b.frozen(plan)
for item in plan['retained']:
    b.exact(item)
source = W / 'probe.cc'
old_source = plan['candidate_source']['path']
folder = W / 'compile/attempt1'
assert not (folder / 'process.json').exists()
compile_command = [str(source) if b.key(arg) == b.key(old_source)
    else arg.replace(plan['compile_default_folder'], str(folder)) for arg in plan['compile']]
link_command = []
for arg in plan['link']:
    if b.key(arg) == b.key(plan['object']):
        arg = str(folder / 'unit.obj')
    for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
        if arg.upper().startswith(prefix):
            arg = prefix + str((W / 'bin/probe').with_suffix(suffix))
            break
    link_command.append(arg)
assert all(sum(b.key(arg) == b.key(item['path']) for arg in link_command) == 1 for item in plan['retained'])
run_folder = W / 'runs/cpu/attempt1'
command = [str(W / 'bin/probe.exe'), '--gtest_color=no',
    '--gtest_filter=M2NativeApi.OriginalUnaryAdmissionAndExecution',
    '--gtest_output=xml:' + str(run_folder / 'results.xml')]
b.save(W / 'plan.json', {'status': 'ROOT_AUTHORIZED_ONE_API_PROBE', 'source': b.pin(source),
    'parent_plan': b.pin(b.W / 'plan.json'), 'retained': plan['retained'],
    'compile': compile_command, 'link': link_command, 'run': command,
    'scope': 'Original RegionProbe definitions included only to construct the exact three-provider Context. One CXX/link/CPU; zero SDK rebuild/GPU.'})
spec = importlib.util.spec_from_file_location('m2_api_original_executor', b.EXECUTOR)
execute = importlib.util.module_from_spec(spec)
spec.loader.exec_module(execute)
execute.W = W
execute.execute(compile_command, folder, 900)
dependencies = b.read(folder / 'dependencies.json')['Data']
paths = sorted({Path(path).resolve() for path in [dependencies['Source'], *dependencies['Includes']]
    if Path(path).is_relative_to(R)})
b.save(folder / 'receipt.json', {'object': b.pin(folder / 'unit.obj'),
    'source_identities': [b.pin(path) for path in paths]})
(W / 'bin').mkdir(exist_ok=True)
shutil.copyfile(plan['runtime']['path'], W / 'bin' / Path(plan['runtime']['path']).name)
execute.execute(link_command, W / 'link/attempt1', 240)
execute.execute(command, run_folder, 300)
xml = ET.parse(run_folder / 'results.xml').getroot()
assert int(xml.get('tests', '-1')) == 1 and int(xml.get('failures', '-1')) == 0 and not list(xml.iter('skipped'))
properties = {node.get('name'): node.get('value') for node in xml.iter('property')}
b.save(W / 'result.json', {'status': 'API_DIAGNOSTIC_COMPLETED', 'tests': 1,
    'properties': properties, 'xml': b.pin(run_folder / 'results.xml'),
    'scope': 'Status recording is diagnostic; GTest PASS does not assert M2 route/alias defect reproduced.'})
print(json.dumps(properties, indent=2))
