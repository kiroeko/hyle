# M2：optional alias 的完整对齐约束（候选）

仅scratch，未应用、CXX或native；不增加测试/执行器/owner/API/Copy或搜索预算。
单源base `b8e23a2d…`，候选 `8387c86e…`；补丁 `optional-alias-repair.patch`
5812B，SHA `3b79e924b21340727f6ad4fc3c50eaf356ab1ab9fcd0f33ea68c167387e18d6f`。
6段明确增改逆恢复原源码，git apply check exit0，实际scratch reverse恢复原raw bytes。
独立审后仅补显式标准头bit；去此行即恢复已审3eb候选全bytes，旧集合另存pre-explicit-bit-3eb。

**不能预先调用当前propagate，也不能只取组max。** 例如Y本身req4，required View
Z=Y+128要求256：把Y optional alias到input(root+128)后，Y在+128、Z在+256都合法。
先检查required组offset会拒绝；即使关offset检查，把256写进Y也会错误地限制Y origin。

本片只加一份cold scratch vector。在现required producer-first组遍历中同时算每个成员
相对required root的checked offset。每成员给根约束 `base ≡ -offset (mod alignment)`；
alignment为原instance_alignments的pow2要求。相容的嵌套pow2同余用最强的
`(alignment,residue,consistent)`精确表示，不修改任何instance_alignments。

只有已通过原desc、liveness、effects/DAG、provider alias0和内部所有权检查的static internal
候选再做检查：input组必须consistent且residue0，完整当前alias_sources链offset必须匹配
output组residue。失败只放弃这一可选alias，保原fresh输出/后续input候选；不拒绝provider，
不加Copy。成功merge仅更新input组scratch max/residue0。原最终propagate仍是唯一写入
allocation-root alignment的步骤。source chain坏/overflow与scratch分配失败均为真实Status，
不转换成capability false、不改outcome flags。

**根固定前提：** `reset_workspace_decisions`清非constant旧父边；required阶段只给
MustAlias/View输出设父边。optional仅处理非MustAlias的Operation，写当前step自身SSA output。
当前output在其producer首次处理时仍是required组根（required后代只向它指父边）。内部input
根来自已处理的前序producer，后续optional只能写新的输出，不能再平移这个旧根。因此它的
Graph-owned分配origin固定0；原has_external_storage_root也排除了外部、constant、generated。
当前实现不引入持久weighted root/permission缓存。

Domain和external pair沿原选择路径；不能用domain占位offset冷证明实际offset，原Invocation
校验保留。constants不可破坏、generated/native identity、已有required aliases、source权限、
多lane reader/DAG、workspace请求与最终检查均不改。scratch只按physical instance数有界
分配，不为每candidate扫全图；仍用原式checked父链walk。

原pre_constants对有constant的计划仍保原传播。本片不宣称全组合已解决；128＋128补偿是
保留数学合法性的约束例，目前没有已建立的实际可达消费者，不能自动列为已复现功能缺项。

实际red来自F32 NativeExp用例：128B无alias与256B合法alias控制均2次真实重放，128B
optional在末尾alias alignment拒绝。最初NativeNeg路未获当前固定规则接纳，不能算M2复现；
相关失败由root/GLM/harness保留。此候选尚无修复后实测，不代签这些结果或完整goal。
