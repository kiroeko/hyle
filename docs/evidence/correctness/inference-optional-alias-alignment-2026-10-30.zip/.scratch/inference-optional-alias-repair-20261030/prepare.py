from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
REL='src/graph/executable.cc'
base=(ROOT/REL).read_bytes()
assert hashlib.sha256(base).hexdigest()=='b8e23a2d8219a787ce6338cb602b4a1543c3cc73ef5f0ec17c62884accdd51ac'
text=base.decode().replace('\r\n','\n')
edits=[]

old='#include <array>\n'
new=old+'#include <bit>\n'
assert text.count(old)==1;text=text.replace(old,new,1);edits.append((old,new))

old='''  detail::ValueOrdinals alias_groups(plan.allocator);
  if (!alias_groups.try_resize(plan.instance_values.size()))
    return plan_allocation_failure();
'''
new='''  detail::ValueOrdinals alias_groups(plan.allocator);
  // Keep requirements relative to each group's origin without promoting a
  // descendant's requirement onto an intermediate value. A group can require
  // a nonzero origin: Y needs4, while a View at Y+128 needs256. Moving Y to an
  // input at root+128 satisfies both; pre-propagating256 onto Y would reject it.
  struct AliasAlignment final {
    std::size_t alignment = 1, residue = 0, root_offset = 0;
    bool consistent = true;
  };
  container::SmallVector<AliasAlignment, 0, mem::AllocatorRef> alias_alignments(plan.allocator);
  if (!alias_groups.try_resize(plan.instance_values.size()) ||
      !alias_alignments.try_resize(plan.instance_values.size()))
    return plan_allocation_failure();
'''
assert text.count(old)==1;text=text.replace(old,new,1);edits.append((old,new))

old='''    alias_groups[instance] = root;
    // A published value is read after commands finish, including when only a
'''
new='''    alias_groups[instance] = root;
    auto &entry = alias_alignments[instance];
    if (source != detail::kNoInPlaceSource) {
      const auto parent_offset = alias_alignments[source].root_offset;
      if (plan.alias_offsets[instance] > SIZE_MAX - parent_offset)
        return Status::Internal("graph physical alias chain is invalid");
      entry.root_offset = parent_offset + plan.alias_offsets[instance];
    }
    const auto alignment = plan.instance_alignments[instance];
    if (!std::has_single_bit(alignment))
      return Status::Internal("graph physical alias alignment is invalid");
    const auto mask = alignment - 1;
    const auto residue = (alignment - (entry.root_offset & mask)) & mask;
    auto &group_alignment = alias_alignments[root];
    if (alignment > group_alignment.alignment) {
      group_alignment.consistent &=
          (residue & (group_alignment.alignment - 1)) == group_alignment.residue;
      group_alignment.alignment = alignment;
      group_alignment.residue = residue;
    } else {
      group_alignment.consistent &= (group_alignment.residue & mask) == residue;
    }
    // A published value is read after commands finish, including when only a
'''
assert text.count(old)==1;text=text.replace(old,new,1);edits.append((old,new))

old='''  // A scalar last use is sufficient on one ordered lane. With several
'''
new='''  // Producer-first optional selection never moves an already consumed
  // internal input root again: only the current step's new SSA outputs can
  // acquire a parent. Required descendants retain their offsets as a group.
  const auto accepts_optional_alignment = [&](std::uint32_t input,
      std::uint32_t input_root, std::uint32_t output_root) noexcept -> Result<bool> {
    const auto &source_group = alias_alignments[input_root];
    const auto &output_group = alias_alignments[output_root];
    if (!source_group.consistent || source_group.residue != 0 || !output_group.consistent)
      return false;
    std::size_t offset = 0;
    auto root = input;
    for (;;) {
      if (root >= plan.alias_sources.size())
        return std::unexpected(Status::Internal("graph optional alias input is invalid"));
      const auto parent = plan.alias_sources[root];
      if (parent == detail::kNoInPlaceSource)
        break;
      if (parent >= root || plan.alias_offsets[root] > SIZE_MAX - offset)
        return std::unexpected(Status::Internal("graph optional alias chain is invalid"));
      offset += plan.alias_offsets[root];
      root = parent;
    }
    if (root != input_root)
      return std::unexpected(Status::Internal("graph optional alias group differs from its physical root"));
    return (offset & (output_group.alignment - 1)) == output_group.residue;
  };

  // A scalar last use is sufficient on one ordered lane. With several
'''
assert text.count(old)==1;text=text.replace(old,new,1);edits.append((old,new))

old='''            readers_before_write(input_root, step_index)) {
          plan.alias_sources[output] = input;
'''
new='''            readers_before_write(input_root, step_index)) {
          // Symbolic offsets and external address contracts keep their original
          // Invocation checks. Only a static Graph-owned allocation has a cold
          // zero origin which can prove this whole output group's translation.
          const bool static_internal = internal_pair && !plan.domain_graph.valid();
          if (static_internal) {
            HYLE_ASSIGN_OR_RETURN(const bool aligned,
                accepts_optional_alignment(input, input_root, output_root));
            if (!aligned)
              continue;
          }
          plan.alias_sources[output] = input;
'''
assert text.count(old)==1;text=text.replace(old,new,1);edits.append((old,new))

old='''          alias_groups[output_root] = input_root;
          last_uses[input_root] = (std::max)(last_uses[input_root], last_uses[output_root]);
'''
new='''          alias_groups[output_root] = input_root;
          if (static_internal) {
            auto &source_group = alias_alignments[input_root];
            source_group.alignment = (std::max)(source_group.alignment, alias_alignments[output_root].alignment);
            source_group.residue = 0;
            source_group.consistent = true;
          }
          last_uses[input_root] = (std::max)(last_uses[input_root], last_uses[output_root]);
'''
assert text.count(old)==1;text=text.replace(old,new,1);edits.append((old,new))

data=text.replace('\n','\r\n' if b'\r\n' in base else '\n').encode()
restored=text
for old,new in reversed(edits):
 assert restored.count(new)==1
 restored=restored.replace(new,old,1)
assert restored.encode()==base.replace(b'\r\n',b'\n')
p=HERE/'candidate'/REL;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
(HERE/'base-executable.cc').write_bytes(base)
patch=''.join(difflib.unified_diff(base.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+REL,tofile='b/'+REL,n=3)).encode()
(HERE/'optional-alias-repair.patch').write_bytes(patch)
check=subprocess.run(['git','apply','--check',str(HERE/'optional-alias-repair.patch')],cwd=ROOT,capture_output=True,text=True)
assert check.returncode==0,check.stderr
report={'status':'SCRATCH_CANDIDATE_NOT_APPLIED_BUILT_OR_RUN',
 'observed_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'base':{'relative':REL,'bytes':len(base),'sha256':hashlib.sha256(base).hexdigest()},
 'candidate':{'relative':REL,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},
 'patch':{'path':'optional-alias-repair.patch','bytes':len(patch),'sha256':hashlib.sha256(patch).hexdigest()},
 'inverse_edits_source_bytes_exact_after_newline_normalization':True,'git_apply_check_exit':0,
 'scope':['One cold scratch vector; initial required-root offsets computed producer-first',
  'Power-of-two congruence aggregation without modifying instance_alignments',
  'Static internal optional aliases check complete actual input chain plus whole output-group residue',
  'Compatible merge updates scratch group max only; final existing propagate remains sole allocation alignment propagation',
  'Domain, external/generated/constant ownership exclusions, effects/DAG/liveness, Copy, search budgets and Invocation code unchanged'],
 'root_precondition':'Current SSA optional outputs have no prior alias; required aliases only point later descendants toward them. An internal input root producer precedes its consumer and cannot be assigned again by a later optional output.',
 'not_claimed':['CXX/native pass','New tests or source edits beyond the one scratch Graph candidate','Performance gain or complete architecture goal',
  'Pre-constants still invokes its original propagation when constants exist; this workspace-only change does not claim to fix a compensating required View rejected earlier by that legacy phase']}
(HERE/'plan.json').write_text(json.dumps(report,indent=2)+'\n')
(HERE/'edit-projections.json').write_text(json.dumps(edits,indent=2)+'\n')
print(json.dumps({'status':report['status'],'candidate':report['candidate'],'patch':report['patch'],'applycheck':check.returncode}))
