"""Finite arithmetic proof only; not a Graph simulator, provider or native test."""
from pathlib import Path
import json

def aggregate(members):
    modulus,residue,consistent=1,0,True
    for alignment,offset in members:
        candidate=(alignment-(offset&(alignment-1)))&(alignment-1)
        if alignment>modulus:
            consistent &= candidate&(modulus-1)==residue
            modulus,residue=alignment,candidate
        else:
            consistent &= residue&(alignment-1)==candidate
    return modulus,residue,consistent

cases=[[(4,0),(256,128)],[(256,0),(4,128)],[(4,0),(256,0)],
       [(4,0),(256,4)],[(4,0),(8,4)],[(256,0),(256,128)],
       [(4,0),(16,16),(256,256)],[(4,0),(64,64),(256,128)]]
for a in [1,2,4,8,16,64,256]:
    for b in [1,2,4,8,16,64,256]:
        for offset in [0,1,4,64,128,256,260]:
            cases.append([(a,0),(b,offset)])
checked=0
for members in cases:
    modulus,residue,consistent=aggregate(members)
    for origin in range(512):
        exact=all((origin+offset)%alignment==0 for alignment,offset in members)
        represented=consistent and origin&(modulus-1)==residue
        assert represented==exact,(members,origin)
        checked+=1
# Source origin0 and an accepted output translation imply a merged residue0;
# the merged modulus is exactly the maximum, with no change to per-value facts.
merges=0
for source in cases:
    sa,sr,sc=aggregate(source)
    if not sc or sr!=0:continue
    for output in cases:
        oa,orr,oc=aggregate(output)
        for shift in [0,1,4,64,128,256,260]:
            if not oc or shift&(oa-1)!=orr:continue
            translated=source+[(a,o+shift) for a,o in output]
            ma,mr,mc=aggregate(translated)
            assert mc and mr==0 and ma==max(sa,oa)
            merges+=1
assert aggregate([(4,0),(256,128)])==(256,128,True)
result={'status':'FINITE_ARITHMETIC_CHECK_PASS_NOT_GRAPH_NATIVE',
        'member_sets':len(cases),'origin_checks':checked,'accepted_merge_checks':merges,
        'compensating_offset_preserved':True,'no_product_edits':True}
(Path(__file__).resolve().parent/'congruence-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
