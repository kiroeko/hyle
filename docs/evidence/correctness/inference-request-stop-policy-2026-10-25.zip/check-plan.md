# Finite checks proposed after root source review — not run

1. Reuse the existing std-only `tests/tools/inference_request_progress_test.cc` strict host recipe, one TU/one process. Its added function exercises normalized owned copies, source-buffer independence, default EOS / extras / ignored model EOS, invalid IDs/vocabulary, original quota/duplicate rules, and the existing allocation counter around prepared validate/lookup/progress. It does not mirror ledger logic or claim Model coverage.

2. One thin pure-CPU app TU using private real main plus a formal `qwen_request_stop_case.h` helper, one process/120s, the original cached untrained A/H64/FFN128/V64 fixture. Reuse `.scratch/inference-participant-failure-20261025/implementation/recipe.json`: replacement application OBJ plus the original129 absolute common inputs, original ffa4 native DLL. Do not depend on the cleaned static-FP8 application OBJs. No core/provider/SDK rebuild, GPU or download.

Keep one bounded owner journey rather than a backend/config matrix:

- Actual R2 Text calls with identical prompt/cursor and different stop policy: a valid extra token stops A before quota; B's equal generated token remains pending and B continues. Check original heads, commit ordinals/draws, no change of sampler/graph role/shape caused by policy.
- Preserve a nondefault policy through one actual pause/retire/rebuild or full-checkpoint recovery, with the same request key, progress, input offset and delivery cursor. The remaining quota stays original; only a newly emitted matching ID ends the turn.
- Reuse a complete prefix under a new request whose stop policy differs from the source publisher: new policy controls the new pending output, no historical output is emitted and no old stop decision is copied. Check this in the original ledger path and a no-ledger legacy request, using the same tiny model/fixtures.
- Direct misuse: prepare original Model with a nondefault `EvaluationRequest` and a fresh ledger that was not cold-bound. Finish must reject before head/record publication; original abort must actually retire, with old head/pending/RNG and uncommitted ledger preserved. Then perform a valid cold bind and retry, not a new executor or cleanup owner.
- An out-of-vocabulary stop ID must be rejected in both the high-level new-request admission and raw Model preflight, before session/admission/episode mutation. MTP nondefault rejection is source/host-boundary coverage only; no new MTP model matrix.

Expected output IDs used to choose matching valid stops must come from the same fixed cached tiny fixture/cursor or an explicit control in that one process. The old midturn evidence [2,10,47] and participant [2,6] are from different exact input partitions; do not combine them as one journey or assume a pending-only second ID.

Actual helper source and exact commands are to be finalized from this source review; neither builds nor runtime work has started. First failures and any unexercised full-hit/direct paths must remain explicit.
