from pathlib import Path
import importlib.util
import json
import os
import re
import sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/inference-request-stop-policy-20261025';S=W/'source';B=W/'before'
OLD=R/'.scratch/inference-participant-failure-20261025/implementation'
spec=importlib.util.spec_from_file_location('cached',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
def prepare():
    # Current self-written dependencies only. No SDK/weight copies.
    for item in b.read(OLD/'attempt1/compile/repository-inputs.json'):
        p=Path(item['path'])
        if p.is_relative_to(OLD/'source'):
            rel=p.relative_to(OLD/'source')
            if rel.parts[0]=='engine' and not(S/rel).exists():
                for base in [B,S]:
                    target=base/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/rel).read_bytes())
    seen=set()
    def quoted(p):
        if p in seen:return
        seen.add(p)
        for rel in re.findall(r'^\s*#\s*include\s*"([^"]+)"',p.read_text(encoding='utf8'),re.M):
            target=(p.parent/rel).resolve()
            if not target.exists():
                original=(R/p.relative_to(S)).parent/rel
                if original.exists() and original.resolve().is_relative_to(R):
                    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original.read_bytes())
                    baseline=B/target.relative_to(S);baseline.parent.mkdir(parents=True,exist_ok=True)
                    if not baseline.exists():baseline.write_bytes(target.read_bytes())
            if target.exists() and target.suffix in {'.cc','.h','.inc'}:quoted(target)
    quoted(S/'engine/models/qwen35/main.cc');quoted(S/'tests/tools/inference_request_progress_test.cc')
    (W/'consumer.cc').write_text('#include "source/engine/models/qwen35/main.cc"\n#include "source/tests/tools/qwen_request_stop_case.h"\nint main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("stop-case PREPARED_INPUTS");return qwen_request_stop_case::run(argv[1]);}catch(const std::exception &e){std::cerr<<"stop_policy_failure="<<e.what()<<"\\n";return 1;}}\n',encoding='utf8')
    prior=b.read(OLD/'recipe.json');command=[];skip=False
    for arg in prior['compile']:
        if skip:skip=False;continue
        if arg=='/sourceDependencies':skip=True;continue
        if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
        if str(OLD).lower() in arg.lower():continue
        command.append(arg)
    command.insert(1,'/I'+str(S));command += [str(W/'consumer.cc'),'/sourceDependencies',str(W/'app1/compile/dependencies.json'),'/Fo'+str(W/'app1/compile/unit.obj'),'/Fd'+str(W/'app1/compile/unit.pdb')]
    link=[];replacements=0
    for arg in prior['link']:
        if arg.lower().startswith(('/out:','/pdb:','/implib:')):continue
        if Path(arg)==OLD/'attempt1/compile/unit.obj':arg=str(W/'app1/compile/unit.obj');replacements+=1
        link.append(arg)
    assert replacements==1
    link += ['/OUT:'+str(W/'app1/link/component.exe'),'/PDB:'+str(W/'app1/link/component.pdb'),'/IMPLIB:'+str(W/'app1/link/component.lib')]
    host=[command[0],'/nologo','/std:c++latest','/EHsc','/W4','/WX','/utf-8','/permissive-',
        '/Zc:__cplusplus','/O2','/MD','/sourceDependencies',str(W/'host1/compile/dependencies.json'),
        str(S/'tests/tools/inference_request_progress_test.cc'),'/Fo'+str(W/'host1/compile/unit.obj'),
        '/Fe'+str(W/'host1/compile/checks.exe')]
    plan=dict(status='AUTHORIZED_ONE_HOST_TU_AND_ONE_CPU_APP_TU',compile=command,link=link,host_compile=host,
        common_inputs=prior['common_inputs'],native=prior['native'],runtime=prior['runtime'],
        fixture=prior['fixture'],fixture_body=prior['fixture_body'],
        process_argv=[str(W/'app1/link/component.exe'),str(Path(prior['fixture']['path']).parent)],
        total_link_inputs=130,retained_common_inputs=129,watchdog_seconds=120,SDK_TUs=0,core_TUs=0,provider_TUs=0,GPU=False,HTTP=0)
    save(W/'recipe.json',plan);print('Prepared exact one host/one CPU app; original129 common inputs, no SDK builds.')
def host():
    plan=b.read(W/'recipe.json');env=b.environment(plan['compile'][0])
    b.execute(plan['host_compile'],W/'host1/compile',env,120)
    b.execute([str(W/'host1/compile/checks.exe')],W/'host1/run',env,120)
def build():
    plan=b.read(W/'recipe.json')
    for item in [*plan['common_inputs'],plan['native'],plan['runtime'],plan['fixture'],plan['fixture_body']]:assert b.pin(Path(item['path']))==item
    sources=[b.pin(p)for p in sorted(S.rglob('*'))if p.is_file()]+[b.pin(W/'consumer.cc')]
    save(W/'app1/source-pins.json',sources)
    env=b.environment(plan['compile'][0]);b.execute(plan['compile'],W/'app1/compile',env,150)
    data=b.read(W/'app1/compile/dependencies.json')['Data'];inputs=[]
    for name in [data['Source'],*data['Includes']]:
        p=Path(name)
        if p.is_relative_to(R):inputs.append(b.pin(p))
        assert not p.is_relative_to(R/'engine') and not p.is_relative_to(R/'tests'),p
    for rel in ['engine/models/qwen35/main.cc','engine/inference/request_stop_policy.h',
        'tests/tools/qwen_request_stop_case.h','engine/inference/sampling_graph.h','engine/inference/request_progress.h']:
        assert any(Path(x['path'])==S/rel for x in inputs),rel
    save(W/'app1/compile/repository-inputs.json',inputs)
    b.execute(plan['link'],W/'app1/link',env,90)
    native=Path(plan['native']['path']);os.link(native,W/'app1/link'/native.name)
    save(W/'app1/link/ready.json',dict(image=b.pin(W/'app1/link/component.exe'),app=b.pin(W/'app1/compile/unit.obj'),native=b.pin(native)))
    for item in sources:assert b.pin(Path(item['path']))==item
def run():
    plan=b.read(W/'recipe.json')
    for item in [*b.read(W/'app1/link/ready.json').values(),*plan['common_inputs'],plan['fixture'],plan['fixture_body']]:assert b.pin(Path(item['path']))==item
    env=b.environment(plan['compile'][0]);env['PATH']=str(W/'app1/link')+';'+b.read(Path(plan['runtime']['path']))['PATH']
    env['HF_HUB_OFFLINE']=env['TRANSFORMERS_OFFLINE']='1'
    b.execute(plan['process_argv'],W/'app1/run',env,120)
    result=json.loads((W/'app1/run/stdout.log').read_text().strip().splitlines()[-1]);assert result['status']=='PASS'
    save(W/'app1/run/result.json',result);print(json.dumps(result))
if __name__=='__main__':{'prepare':prepare,'host':host,'build':build,'run':run}[sys.argv[1]]()
