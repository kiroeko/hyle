# Ordinary request stop policy — private source draft

Baseline: canonical HEAD `8a1668d07eb5b707b270259431437d8e76fe63c7`, main SHA `0626e50feee31408e97d2459738bbc11288d6499021979c65e778b94189abaa1`. No canonical changes, GPU or HTTP. Finite host and thin CPU checks were subsequently authorized and passed.

The missing capability is the actual ordinary owner/ledger adapter, not `RequestProgress`: the latter already accepts a stopped fact. Qwen previously reconstructed that fact from two fixed EOS IDs at commit, import, full hit, legacy completion and observation. A caller could neither add a valid ordinary stop ID nor ignore default EOS while retaining the original journal/recovery path.

`RequestStopPolicy` is immutable output configuration: normalized value-owned extra IDs and ignore-model-EOS. Default means exactly the old model EOS behavior; explicit extras still stop when model EOS is ignored. Negative IDs fail at construction; the cached maximum validates against actual vocabulary in O(1) at every real admission before family/resource preparation. There is no tokenization, string stop matcher, cursor or second state owner.

The request owns a const value. Its original ledger owns a separate once-bound cold value, compared semantically; relocating a request/vector cannot leave the ledger pointing at an old request. The existing `StepMember` only borrows a policy through one synchronous episode, under the same stable owner/input lifetime contract. No native callback consumes it, and no allocation occurs in stop lookup or finish.

`EvaluationRequest` supplies the ordinary policy before submit; Model preflight validates all members and rejects nondefault MTP policies. The policy does not enter FamilyKey, sampling, provider choice, KV, Snapshot, prefix key, or model mathematical identity. Different stop policies can share one real equal-shape ordinary batch.

Cold `bind_stop_policy` can install a value only before its ledger has committed. Finish is a stricter agreement check: an unbound/default ledger cannot accept a nondefault active member merely because committed_count is zero. It rejects before wait/export/head publication and never first-copies a vector there; original abort/retirement still owns cleanup.

Ordinary commit writes `record.stopped` from that episode's immutable policy. Observation consumes that original fact, including after a postcommit diagnostic exception; it does not reinterpret the ID using fixed EOS. State-only chunks still have no user output/stopped fact. MTP selector and observation defaults remain as before.

Initial full-prefix import uses the new request's bound policy, not any prior request's output decision; the shared replay stores consumed IDs/next IDs, not request policy. A full hit computes the new pending's stopping fact using the new policy. The no-ledger legacy `GenerationRequest` path supplies the same member policy and applies it to its ordinary result/full hit; the direct `evaluate` wrapper also has a trailing optional policy input for actual pre-submit validation. No new CLI option is required.

Pause/evict/restore validates the request against its original ledger policy before looking up/installing a Session. Committed-token rebuild cold-copies that policy into the temporary actual ledger and supplies it to the original Text preparation; it still replays all already committed input and restores historical pending/RNG. It does not restart a turn, re-emit tokens, or put policy into the shared checkpoint.

Changed source: shared engine header, model main, existing std-only request-progress test TU, a formal helper and a mechanical existing lifecycle-mode bridge. The exact helper/main/header compiled in one thin CPU TU and passed; the heavy lifecycle dispatcher itself is source-only. No CMake/SDK changes. See summary.json for actual command/dependency/EOF facts.
