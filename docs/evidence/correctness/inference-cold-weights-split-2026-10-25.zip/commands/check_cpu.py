"""Two current CPU TUs and the original logits helper, using CPU7's closure."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import re
import shutil
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
BASE = ROOT / '.scratch/inference-logits-modifiers-20261025/cpu7'
spec = importlib.util.spec_from_file_location('existing_cpu_helpers', ROOT / '.scratch/inference-duplicate-session-20261025/check_cpu.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
read, save, pin, execute = helper.read, helper.save, helper.pin, helper.cached.execute
MAIN = 'engine/models/qwen35/main.cc'
WEIGHTS = 'engine/models/qwen35/weights.cc'
CASE = 'tests/tools/qwen_logits_modifier_case.h'

def verify(items):
    for item in items:
        actual = pin(Path(item['path']))
        assert all(actual[key] == item[key] for key in ('bytes', 'sha256')), item['path']

def folder(name):
    assert re.fullmatch(r'cpu[0-9]+', name)
    return WORK / name

def prepare(args):
    out = folder(args.attempt)
    assert not out.exists(), 'Preserve every actual attempt'
    pins = read(WORK / 'source-pins.json')
    for item in pins['files']:
        actual = pin(ROOT / item['path'])
        assert all(actual[k] == item['after'][k] for k in ('bytes', 'sha256')), item['path']
    old = read(BASE / 'recipe.json')
    assert read(BASE / 'summary.json')['status'] == 'FINITE_CPU_LOGITS_MODIFIERS_PASS'
    assert pin(ROOT / CASE)['sha256'] == old['case_source']['sha256']
    tree = out / 'source'
    search = [ROOT / 'include', ROOT, ROOT / 'engine', ROOT / 'tests/tools', ROOT / 'engine/models/qwen35']
    queue, seen, frozen = [MAIN, WEIGHTS, CASE], set(), []
    while queue:
        relative = queue.pop()
        if relative in seen:
            continue
        seen.add(relative)
        src = ROOT / relative
        raw = src.read_bytes()
        dst = tree / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(raw)
        frozen.append({'relative': relative, 'original': pin(src), 'frozen': pin(dst)})
        for include in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]', raw.decode('utf-8-sig'), re.M):
            for directory in [src.parent, *search]:
                child = (directory / include).resolve()
                if child.is_file() and child.is_relative_to(ROOT):
                    queue.append(child.relative_to(ROOT).as_posix())
                    break
    save(out / 'frozen-source.json', frozen)
    save(out / 'source-pins.json', pins)
    consumer = out / 'consumer.cc'
    consumer.write_bytes((BASE / 'consumer.cc').read_bytes())
    original = read(BASE / 'compile/command.json')['command']
    flags, skip = [], False
    for arg in original[1:]:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        flags.append(arg.replace(str(BASE / 'source'), str(tree)))
    assert '/W4' in flags and '/WX' in flags
    assert any('HYLE_COMPUTE_CPU=1' in arg for arg in flags)
    assert not any('HYLE_COMPUTE_CUDA=1' in arg for arg in flags)
    commands, objects = {}, {}
    for stage, source in [('compile-weights', tree / WEIGHTS), ('compile-consumer', consumer)]:
        obj = out / stage / 'unit.obj'
        objects[stage] = str(obj)
        commands[stage] = [original[0], *flags, str(source), '/sourceDependencies', str(out / stage / 'dependencies.json'),
                           '/Fo' + str(obj), '/Fd' + str(out / stage / 'unit.pdb')]
    link = read(BASE / 'link/command.json')['command']
    assert link.count(str(BASE / 'compile/unit.obj')) == 1
    args_link = [objects['compile-consumer'] if arg == str(BASE / 'compile/unit.obj') else arg
                 for arg in link if not arg.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:'))]
    common = [pin(Path(arg)) for arg in args_link if Path(arg).is_absolute()
              and Path(arg).suffix.lower() in ('.obj', '.lib') and arg != objects['compile-consumer']]
    assert common == old['common_inputs'] and len(common) == 129
    image = out / 'link/component.exe'
    args_link += [objects['compile-weights'], '/OUT:' + str(image), '/PDB:' + str(out / 'link/component.pdb')]
    save(out / 'recipe.json', {'status': 'PREPARED_NOT_COMPILED_OR_RUN', 'compile': commands, 'link': args_link,
         'common_inputs': common, 'native': old['native'], 'runtime': old['runtime'],
         'fixture': old['fixture'], 'fixture_bodies': old['fixture_bodies'], 'fixture_generator_sources': old['fixture_generator_sources'],
         'consumer': pin(consumer), 'argv': [str(image), str(Path(old['fixture']['path']).parent)],
         'base_compile': pin(BASE / 'compile/command.json'), 'base_link': pin(BASE / 'link/command.json'),
         'objects': objects, 'image': str(image), 'watchdog_seconds': 120, 'new_CPP_TUs': 2,
         'core_provider_SDK_TUs': 0, 'formal_lifecycle_TUs': 0, 'GPU': False, 'HTTP': 0})
    print('PREPARED', out.name, len(frozen), 'frozen files; same129 common inputs; two TUs; no compile/run')

def build(args):
    out = folder(args.attempt)
    plan = read(out / 'recipe.json')
    verify([x['frozen'] for x in read(out / 'frozen-source.json')])
    verify(plan['common_inputs'])
    env = helper.environment(plan['compile']['compile-weights'][0])
    results = {}
    for stage, command in plan['compile'].items():
        results[stage] = execute(command, env, out / stage, 120)
        dependencies = read(out / stage / 'dependencies.json')['Data']
        actual = [Path(p) for p in dict.fromkeys([dependencies['Source'], *dependencies['Includes']])]
        assert not any(p.is_relative_to(ROOT / category) for p in actual for category in ('engine', 'tests', 'include'))
        assert out / 'source/engine/models/qwen35/weights.h' in actual
        if stage == 'compile-weights':
            assert out / 'source' / MAIN not in actual
            assert out / 'source' / CASE not in actual
        save(out / stage / 'actual-dependencies.json', [pin(p) for p in actual])
    linked = execute(plan['link'], env, out / 'link', 120)
    verify([plan['native']])
    native = Path(plan['native']['path'])
    os.link(native, out / 'link' / native.name)
    save(out / 'ready.json', {'compile': results, 'link': linked, 'image': pin(Path(plan['image'])),
                            'objects': [pin(Path(p)) for p in plan['objects'].values()], 'native': plan['native']})

def run(args):
    out = folder(args.attempt)
    plan, ready = read(out / 'recipe.json'), read(out / 'ready.json')
    verify([ready['image'], ready['native'], *ready['objects'], *plan['common_inputs'], plan['fixture'], *plan['fixture_bodies']])
    env = helper.environment(plan['compile']['compile-weights'][0])
    env['PATH'] = str(out / 'link') + ';' + read(Path(plan['runtime']['path']))['PATH']
    env['HF_HUB_OFFLINE'] = env['TRANSFORMERS_OFFLINE'] = '1'
    if (out / 'run/process.json').is_file():
        ran = read(out / 'run/process.json')
        assert ran['exit'] == 0
        print('REUSE original successful Model process; no repeated inference', flush=True)
    else:
        ran = execute(plan['argv'], env, out / 'run', 120)
    records = [json.loads(line) for line in (out / 'run/stdout.log').read_text().splitlines() if line.startswith('{')]
    assert len(records) == 1
    record = records[0]
    assert record['status'] == 'PASS' and record['dynamic_inputs'] and record['allmasked_survivor'] and record['same_key_restore']
    assert record['state_only_without_inputs'] and record['greedy_draws'] == 0 and record['fullhit_random_draws'] == 1 and record['final_versions'] == 0
    cmake = shutil.which('cmake')
    assert cmake, 'Existing CMake is required; never install a new toolchain here'
    config_env = dict(env, PATH=str(Path(cmake).parent) + ';' + os.environ.get('PATH', ''))
    component_stage = 'engine-components2' if (out / 'engine-components').exists() else 'engine-components'
    components = execute([sys.executable, str(ROOT / 'tests/tooling/engine_components_test.py')], config_env, out / component_stage, 120)
    verify([x['original'] for x in read(out / 'frozen-source.json')])
    save(out / 'summary.json', {'status': 'COLD_WEIGHTS_SPLIT_FINITE_CPU_PASS', 'compile': ready['compile'],
         'link': ready['link'], 'run': ran, 'result': record, 'engine_components': components,
         'frozen_files': len(read(out / 'frozen-source.json')), 'new_CPP_TUs': 2, 'reused_common_inputs': len(plan['common_inputs']),
         'formal_lifecycle_TUs': 0, 'core_provider_SDK_TUs': 0, 'GPU': False, 'HTTP': 0,
         'source_pins': read(out / 'source-pins.json'), 'native': plan['native'], 'fixture': plan['fixture'],
         'engine_components_stage': component_stage, 'existing_cmake': pin(Path(cmake)),
         'first_components_environment_failure_preserved': component_stage == 'engine-components2'})
    print('COLD_WEIGHTS_SPLIT_FINITE_CPU_PASS')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest='action', required=True)
    for name in ('prepare', 'build', 'run'):
        command = actions.add_parser(name)
        command.add_argument('--attempt', required=True)
    args = parser.parse_args()
    {'prepare': prepare, 'build': build, 'run': run}[args.action](args)
