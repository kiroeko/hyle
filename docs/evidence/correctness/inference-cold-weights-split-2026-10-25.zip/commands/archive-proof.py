"""Archive the completed cold split check; never rebuilds or reruns it."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/correctness'
STEM = 'inference-cold-weights-split-2026-10-25'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def pin(path):
    return {'path': path.relative_to(ROOT).as_posix(), **digest(path.read_bytes())}

summary = read(WORK / 'cpu1/summary.json')
pins = read(WORK / 'source-pins.json')
review_path = WORK / 'independent-review-performance.json'
review = read(review_path)
assert summary['status'] == 'COLD_WEIGHTS_SPLIT_FINITE_CPU_PASS'
assert all(x['exit'] == 0 for x in summary['compile'].values())
assert all(summary[x]['exit'] == 0 for x in ('link', 'run', 'engine_components'))
assert summary['new_CPP_TUs'] == 2 and summary['reused_common_inputs'] == 129
assert summary['result']['status'] == 'PASS' and summary['result']['final_versions'] == 0
assert summary['source_pins'] == pins
assert review['status'] == 'SOURCE_ONLY_FROZEN_FIVE_PATHS_NO_BLOCKER_FOUND'
assert pin(review_path)['sha256'] == '3355f112090df92c59b0f2b79876229e5e031704502f3d8f7aee8f03a2fb7eb1'
assert review['reviewed_pins'] == digest((WORK / 'source-pins.json').read_bytes())
assert review['reviewed_patch'] == digest((WORK / 'source.patch').read_bytes())
components_raw = (WORK / 'cpu1/engine-components2/stderr.log').read_bytes()
assert b'Ran 8 tests' in components_raw and b'\nOK' in components_raw
assert b'FileNotFoundError: [WinError 2]' in (WORK / 'cpu1/engine-components/stderr.log').read_bytes()
base = subprocess.check_output(['git', 'rev-parse', '0ca1ef09a'], cwd=ROOT, text=True).strip()
for item in pins['files']:
    assert digest((ROOT / item['path']).read_bytes()) == item['after'], item['path']
    if item['before']['exists']:
        raw = subprocess.check_output(['git', 'show', base + ':' + item['path']], cwd=ROOT)
        assert digest(raw) == {key: item['before'][key] for key in ('bytes', 'sha256')}
    else:
        assert subprocess.run(['git', 'cat-file', '-e', base + ':' + item['path']], cwd=ROOT, capture_output=True).returncode != 0

members, origins = {}, {}
def add(name, path):
    assert name not in members and path.is_file()
    assert path.suffix.lower() not in {'.obj', '.lib', '.exe', '.dll', '.pdb', '.bin', '.gguf', '.safetensors', '.tar', '.gz'}
    raw = path.read_bytes()
    assert not re.search(rb'(?i)(authorization\s*[:=]\s*bearer|x-amz-(?:signature|credential)=|[?&](?:signature|access_token)=|hf_[A-Za-z0-9]{24,})', raw), name
    members[name] = raw
    origins[name] = path.relative_to(ROOT).as_posix()

for name in ('source.patch', 'source-pins.json', 'source-checks.json', 'independent-review-performance.json'):
    add('source/' + name, WORK / name)
add('commands/check_cpu.py', WORK / 'check_cpu.py')
add('commands/archive-proof.py', Path(__file__).resolve())
add('commands/consumer.cc', WORK / 'cpu1/consumer.cc')
for path in sorted((WORK / 'cpu1').rglob('*')):
    if not path.is_file() or 'source' in path.relative_to(WORK / 'cpu1').parts:
        continue
    if path.suffix.lower() in ('.json', '.log'):
        add('actual/cpu1/' + path.relative_to(WORK / 'cpu1').as_posix(), path)
manifest = (json.dumps({'members': [{'member': name, 'original_path': origins[name], **digest(raw)}
                                  for name, raw in sorted(members.items())],
                       'excluded': 'No full before/after/frozen source trees, SDK, binaries or model bodies.'}, indent=2) + '\n').encode()
archive = DEST / (STEM + '.zip')
report_path = DEST / (STEM + '.json')
assert not archive.exists() and not report_path.exists(), 'Do not silently replace an existing public proof'
DEST.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, raw in sorted({**members, 'member-sha256.json': manifest}.items()):
        info = zipfile.ZipInfo(name)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        output.writestr(info, raw, compresslevel=9)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None and len(output.namelist()) == len(members) + 1
    assert output.read('member-sha256.json') == manifest
    for name, raw in members.items():
        assert digest(output.read(name)) == digest(raw), name
assert archive.stat().st_size < 1024 * 1024

report = {
    'status': 'QWEN_COLD_WEIGHTS_SPLIT_FINITE_CPU_PASS', 'date': '2026-10-25', 'base_commit': base,
    'problem': 'Cold weight source parsing, codec binding and imports were compiled inside the same Qwen main TU as request/model execution. Existing ProjectionBinding declarations did not isolate their implementation.',
    'change': 'Qwen-private weights.h/weights.cc hold original Tensor/LoadedWeight and cold projection/source APIs. Recipe keeps the same typed ProjectionBinding and original stable map nodes. Model, Session, request/CLI and numerical Graph paths are unchanged. No new owner, IR, registry, virtual layer or loader policy.',
    'sources': pins['files'],
    'source_equivalence': {'pin': pin(WORK / 'source-checks.json'),
                           'facts': 'GraphAssembly/Recipe/sampling/ledger middle and the complete Model/Session/request/CLI suffix are byte-identical. Projection and loader bodies retain original semantics. Tensor storage/move/read/write/view/dump remain inline; only cold Backend-dependent freeze moves out of line.'},
    'build_boundary': 'The same weights.cc is compiled by each actual engine/probe/lifecycle/Vulkan-retirement consumer under its own existing HYLE_COMPUTE_* capability definitions. No cross-capability Backend object/static library is shared and no public CMake option is added.',
    'actual_CPU': {'compile_weights': summary['compile']['compile-weights'],
                   'compile_thin_consumer': summary['compile']['compile-consumer'], 'link': summary['link'],
                   'run': summary['run'], 'result': summary['result'], 'new_CPP_TUs': 2, 'strict': '/W4 /WX',
                   'cached_common_OBJ_LIB_inputs': 129, 'frozen_project_files': summary['frozen_files'],
                   'fixture': 'Original cached untrained A/H64/FFN128/V64 fixture; actual Model/Session logits helper, not a trained Qwen2B model or quality run.',
                   'dependency_separation': 'Actual weights dependencies contain no main.cc/helper. Actual thin consumer no longer parses fp8_weight_import.h or nf4_weight_import.h.',
                   'core_provider_SDK_TUs': 0, 'formal_lifecycle_TUs': 0, 'GPU': False, 'HTTP': 0},
    'engineering': {'test': 'tests/tooling/engine_components_test.py', 'tests': 8, 'failures': 0,
                    'process': summary['engine_components'], 'raw': 'actual/cpu1/engine-components2/stderr.log',
                    'limits': 'Existing no-SDK component/target CMake checks; not a complete native build matrix.'},
    'first_environment_failure': 'The first engineering-test process inherited the narrow native runtime PATH and could not locate cmake.exe (WinError2). Original command/stdout/stderr/process are retained under engine-components. Adding existing CMake to that test PATH made its eight tests pass under engine-components2. No C++ compile, link or Model inference was repeated for this correction.',
    'independent_review': {'pin': pin(review_path), 'status': review['status'],
                           'scope': 'Independent source/ownership/numerical/CMake review by mtp_performance_audit; its source-only finding is separate from the actual CPU check.'},
    'limits': ['No GPU, new backend/codec numerical matrix, original publisher payload or trained-model quality qualification.',
               'Compile durations are recorded process facts, not a performance benchmark or TPS/speedup claim.',
               'Existing manual non-CMake probes/future thin drivers must link weights.cc using their own original capability macros; historical frozen recipes are retained as historical evidence.'],
    'archive': {**pin(archive), 'members': len(members) + 1, 'CRC_and_member_SHA256_verified': True,
                'index': 'member-sha256.json', 'no_SDK_binary_model_or_full_source_tree_payloads': True}}
report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'report': pin(report_path), 'archive': pin(archive), 'members': len(members) + 1}, indent=2))
