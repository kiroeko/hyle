from pathlib import Path
import subprocess, json, time, os, shutil, hashlib, sys
mode=sys.argv[1];assert mode in ('static','shared')
base=Path('/Users/kiro/hyle-scratch/compute-unified');canonical=base/'source-c8874688'
producer=base/'a-vulkan/selected-graph'/f'{mode}-sdk-build'
workspace=base/f'g01-rr-{mode}-sdk';workspace.mkdir(exist_ok=True)
source=workspace/'consumer-source';source.mkdir(exist_ok=True)
build=workspace/'consumer-build';stage=workspace/'staging';prefix=workspace/'relocated'
result_file=workspace/'result.json';records=json.loads(result_file.read_text())['stages'] if result_file.exists() else []
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def done(name):return next((x for x in reversed(records) if x['stage']==name),{}).get('exit_code')==0
def run(name,args):
 attempt=1+sum(x['stage']==name for x in records);log=workspace/f'{name}-{attempt}.log';started=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':name,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)};records.append(row)
 result_file.write_text(json.dumps({'candidate':'a40003f7edb54a3da3113d0cd401b46211e0b0f0','mode':mode,'scope':'actual Air relocated public SDK; three finite resident/rebind/padding tests; no private HYLE API','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1800));print(f.read(1800).decode(errors='replace'))
  raise SystemExit(r.returncode)
if not done('producer-build'):
 run('producer-build',['/opt/homebrew/bin/cmake','--build',str(producer),'--target','hyle_graph_route_vulkan','hyle_graph_batch','hyle_compute_state','--parallel','4'])
if not done('install'):
 assert not prefix.exists(),'prior relocated artifacts cannot be overwritten'
 run('install',['/opt/homebrew/bin/cmake','--install',str(producer),'--prefix',str(stage)])
if stage.exists():
 assert not prefix.exists();stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
inputs=['tests/graph_route_vulkan/mature_tensor_test.cc','tests/compute_route_vulkan/concat_test_support.h','tests/compute_route_vulkan/gate_norm_test_support.h','tests/compute_route_vulkan/reduction_test_support.h','tests/compute_route_vulkan/tensor_test_support.h','tests/compute_route_vulkan/fixture.h','tests/compute_provider_native/half_test_support.h']
manifest=[]
for name in inputs:
 blob=(canonical/name).read_bytes();target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(blob);manifest.append({'path':name,'sha256':hashlib.sha256(blob).hexdigest()})
carrier=(canonical/'include/hyle/simd/types.h').read_bytes()
(source/'tests/compute_provider_native/oracle_storage.h').write_bytes(carrier)
helper=source/'tests/compute_provider_native/half_test_support.h';helper.write_bytes(helper.read_bytes().replace(b'#include "hyle/simd/dtype.h"',b'#include "oracle_storage.h"'))
manifest.append({'path':'tests/compute_provider_native/oracle_storage.h','source':'candidate SIMD test-only bit carriers','sha256':hashlib.sha256(carrier).hexdigest()})
(workspace/'consumer-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g01_rr_installed_resident LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS graph compute)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory(/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 gtest EXCLUDE_FROM_ALL)
add_executable(resident tests/graph_route_vulkan/mature_tensor_test.cc)
target_compile_features(resident PRIVATE cxx_std_23)
target_compile_options(resident PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_link_libraries(resident PRIVATE hyle::graph GTest::gtest_main)
hyle_stage_runtime(resident)
''')
if not done('consumer-configure'):run('consumer-configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_PREFIX_PATH='+str(prefix)])
if not done('consumer-build'):run('consumer-build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','resident','--parallel','4'])
if not done('run'):run('run',[str(build/'resident'),'--gtest_filter=VulkanGraph.ResidentAttentionViewsPreserveEffectiveLengthsAndOldResults:VulkanGraph.RecordedResidentAttentionRebindsOriginsAndOwnersWithoutStaleCommands:VulkanGraph.ResidentAttentionDepthPaddedRowsUseExactStrides'])
print(mode+' relocated SDK PASS',flush=True)
