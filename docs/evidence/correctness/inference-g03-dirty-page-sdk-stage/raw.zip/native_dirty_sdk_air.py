from pathlib import Path
import hashlib,json,os,subprocess,sys,time
route,mode=sys.argv[1:];assert route in ['apple','vulkan'] and mode in ['static','shared']
candidate='b42832de3ddda21bdc3e98ad4cc87e73622cbba4'
base=Path('/Users/kiro/hyle-scratch/compute-unified');canonical=base/'source-c8874688'
producer=base/f'a-cpu-{route}/selected-graph/{mode}-sdk-build';assert producer.is_dir()
out=base/f'g03-dirty-page-{route}-{mode}-sdk';out.mkdir(exist_ok=True)
source=out/'consumer-source';source.mkdir(exist_ok=True);build=out/'consumer-build'
stage=out/'staging';prefix=out/'relocated';record=out/'result.json'
rows=json.loads(record.read_bytes())['stages'] if record.exists() else []
identity={n:subprocess.check_output(a,text=True).strip() for n,a in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
def run(name,args):
    number=1+sum(r['stage']==name for r in rows);log=out/f'{name}-{number}.log';start=time.monotonic()
    with log.open('w') as stream:
        process=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
        (out/'job.json').write_text(json.dumps({'state':'RUNNING','route':route,'mode':mode,'stage':name,'pid':process.pid,'log':str(log)}))
        print('RUN',route,mode,name,'PID',process.pid,flush=True)
        result=subprocess.CompletedProcess(args,process.wait())
    row={'stage':name,'command':args,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
    record.write_text(json.dumps({'candidate':candidate,'route':route,'mode':mode,'identity':identity,
        'scope':'relocated public hyle::compute only, CPU64 dirty numerical/permission proof and native64 GQA mixed prefill/decode growth F16/BF16/F16, four public headers; no internal products/hooks or oracle substitution',
        'stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n');print(json.dumps(row),flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-5000:],flush=True);(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':result.returncode}));raise SystemExit(result.returncode)
def done(name):return next((r for r in reversed(rows) if r['stage']==name),{}).get('exit_code')==0
if not done('producer-build'):
    run('producer-build',['/opt/homebrew/bin/cmake','--build',str(producer),'--target',
        'hyle_compute','hyle_compute_batch',f'hyle_compute_route_{route}','--parallel','4'])
if not done('install'):
    assert not prefix.exists();run('install',['/opt/homebrew/bin/cmake','--install',str(producer),'--prefix',str(stage)])
if stage.exists():assert not prefix.exists();stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
files=['tests/compute_batch/dirty_page_native_consumer.cc','tests/compute_batch/dirty_page_public_consumer.cc']
inputs=[]
for name in files:
 data=(canonical/name).read_bytes();dest=source/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'unmodified':True})
(out/'consumer-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
headers=['batch_transfer.h','paged_arena.h',route+'_memory.h',route+'_batch.h']
for index,header in enumerate(headers):(source/f'header-{index}.cc').write_text(f'#include <hyle/compute/{header}>\n')
definitions='target_compile_definitions(native PRIVATE HYLE_DIRTY_PAGE_APPLE=1)' if route=='apple' else ''
(source/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.25)
project(g03_dirty_page_public_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute)
add_executable(native tests/compute_batch/dirty_page_native_consumer.cc)
add_executable(cpu tests/compute_batch/dirty_page_public_consumer.cc)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc header-3.cc)
foreach(t native cpu headers)
 target_compile_features(${t} PRIVATE cxx_std_23)
 target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${t} PRIVATE hyle::compute)
endforeach()
'''+definitions+'''
hyle_stage_runtime(native)
hyle_stage_runtime(cpu)
''')
run('consumer-configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
run('consumer-build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','native','cpu','headers','--parallel','4'])
commands=json.loads((build/'compile_commands.json').read_bytes())
for item in commands:assert str(canonical) not in item['command'] and str(prefix/'include') in item['command'],item['command']
(out/'public-compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
run('native',[str(build/'native')]);run('cpu',[str(build/'cpu')])
(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':0,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)}))
print('TERMINAL PASS',route,mode,'public relocated compute',flush=True)
