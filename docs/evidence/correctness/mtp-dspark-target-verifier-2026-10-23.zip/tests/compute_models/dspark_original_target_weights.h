#pragma once

#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>

#include "dspark_original_target_roles.h"
#include "hyle/compute/resource_leases.h"
#include "hyle/compute/storage_owner.h"
#if defined(HYLE_TEST_DSPARK_STATE_CUDA)
#include "hyle/compute/cuda_weights.h"
#endif

// Formal-source FP4 and GGUF MXFP4 are different physical formats. This
// consumer adapter only assembles the former's selected codes and losslessly
// widened scales. Execution, upload retirement and results use ordinary Hyle
// leases/WeightSlots; no model math or device dispatch belongs here.
namespace dspark_original_target_weights {
namespace original=dspark_original_target_roles;
namespace c=hyle::compute;
namespace m=hyle::mem;
using hyle::Result;
using hyle::Status;
inline constexpr std::size_t kCapacity=6,kDomain=256;
inline constexpr std::array<original::Leg,3> kLegs{
    original::Leg::kGate,original::Leg::kUp,original::Leg::kDown};
inline constexpr std::array<std::uint64_t,4> kBankIds{10,20,30,40};

// The descriptor, not a logical F32 stride, determines each encoded plane.
struct Layout final {
  std::array<c::TensorDesc,3> banks;
  std::array<std::size_t,3> code_bytes{},scale_bytes{},bank_bytes{};
  c::TensorDesc map;
  std::size_t slot_bytes=0;
  static Result<Layout> create() {
    Layout result;
    for(std::size_t leg=0;leg<3;++leg) {
      result.banks[leg]=original::resident_description(kLegs[leg],kCapacity);
      const auto dims=result.banks[leg].dimensions();
      if(dims.size()!=3||dims[0]!=std::int64_t(kCapacity)||dims[1]<=0||dims[2]<=0||dims[2]%32!=0)
        return std::unexpected(Status::InvalidArgument("formal FP4 resident geometry"));
      result.code_bytes[leg]=std::size_t(dims[1]*dims[2]/2);
      result.scale_bytes[leg]=std::size_t(dims[1]*(dims[2]/32))*sizeof(float);
      HYLE_ASSIGN_OR_RETURN(result.bank_bytes[leg],result.banks[leg].required_bytes());
      if(result.bank_bytes[leg]!=kCapacity*(result.code_bytes[leg]+result.scale_bytes[leg]))
        return std::unexpected(Status::InvalidArgument("formal FP4 resident plane extent"));
      result.slot_bytes+=(result.bank_bytes[leg]+255)&~std::size_t{255};
    }
    HYLE_ASSIGN_OR_RETURN(result.map,c::TensorDesc::dense(c::DataType::kInt32,
        std::array<std::int64_t,1>{kDomain}));
    HYLE_ASSIGN_OR_RETURN(auto map_bytes,result.map.required_bytes());
    result.slot_bytes+=(map_bytes+255)&~std::size_t{255};
    return result;
  }
  std::size_t scale_offset(std::size_t leg,std::size_t local) const {
    return kCapacity*code_bytes[leg]+local*scale_bytes[leg];
  }
};

template<class Selection> Status validate(const Selection &selected) {
  if(selected.globals.empty()||selected.globals.size()>kCapacity)
    return Status::InvalidArgument("formal target selection must contain1..6 experts");
  std::array<std::int32_t,kDomain> expected;expected.fill(-1);
  std::int32_t previous=-1;
  for(std::size_t local=0;local<selected.globals.size();++local) {
    const auto id=selected.globals[local];
    if(id<0||id>=std::int32_t(kDomain)||id<=previous)
      return Status::InvalidArgument("formal target expert IDs must be sorted, unique and in range");
    expected[std::size_t(id)]=std::int32_t(local);previous=id;
  }
  if(selected.map!=expected)return Status::InvalidArgument("formal target map differs from its exact selection");
  return Status::Ok();
}
template<class Selection> std::int32_t original_at(const Selection &selected,std::size_t local) {
  // Fully initialize capacity without giving padding an addressable map entry.
  return local<selected.globals.size()?selected.globals[local]:selected.globals.front();
}
inline Status widen(std::span<const std::byte> source,std::span<float> destination) {
  if(source.size()!=destination.size())return Status::InvalidArgument("formal UE8M0 scale extent");
  for(std::size_t i=0;i<source.size();++i) {
    const auto exponent=std::to_integer<unsigned>(source[i]);
    if(exponent==255)return Status::InvalidArgument("nonfinite formal UE8M0 scale");
    destination[i]=std::ldexp(1.F,int(exponent)-127);
  }
  return Status::Ok();
}

struct CpuBatch final {
  c::StorageOwner owner;
  std::array<c::ReadLease,4> banks;
};
class CpuSupply final {
 public:
  using Batch=CpuBatch;
  CpuSupply()=default;
  CpuSupply(CpuSupply&&)=default;
  // Replacing the owner before destroying its borrowed pool is unsafe.
  CpuSupply &operator=(CpuSupply&&)=delete;
  static Result<CpuSupply> create(const c::StorageOwner &owner) {
    if(!owner)return std::unexpected(Status::InvalidArgument("formal target CPU supply needs its owner"));
    CpuSupply result;result.owner_=owner;
    HYLE_ASSIGN_OR_RETURN(result.layout_,Layout::create());
    HYLE_ASSIGN_OR_RETURN(result.pool_,c::LeasePool::create(owner.ref(),2*result.layout_.slot_bytes,
        {.max_blocks=8,.backing_alignment=256}));
    HYLE_ASSIGN_OR_RETURN(result.scales_,m::Buffer::create(m::system_resource(),result.layout_.scale_bytes[0],256));
    return result;
  }
  template<class Selection,class Source>
  Result<CpuBatch> upload(std::size_t stage,const Selection &selected,const Source &source) {
    HYLE_RETURN_IF_ERROR(validate(selected));
    if(stage>=3)return std::unexpected(Status::InvalidArgument("formal target stage outside tail"));
    CpuBatch result{.owner=owner_};
    std::array<c::WriteLease,4> writers;
    for(std::size_t leg=0;leg<3;++leg) {
      HYLE_ASSIGN_OR_RETURN(writers[leg],pool_.allocate(layout_.bank_bytes[leg]));
      HYLE_ASSIGN_OR_RETURN(auto destination,writers[leg].view());
      HYLE_ASSIGN_OR_RETURN(auto scratch,scales_.view().subview(0,layout_.scale_bytes[leg]));
      HYLE_ASSIGN_OR_RETURN(auto mapped,scratch.map_host());
      HYLE_ASSIGN_OR_RETURN(auto bytes,mapped.writable_bytes());
      auto expanded=std::span(reinterpret_cast<float*>(bytes.data()),layout_.scale_bytes[leg]/sizeof(float));
      for(std::size_t local=0;local<kCapacity;++local) {
        const auto id=original_at(selected,local);
        const auto codes=source.expert_codes(stage,kLegs[leg],id);
        if(codes.size()!=layout_.code_bytes[leg])
          return std::unexpected(Status::InvalidArgument("formal target FP4 code extent"));
        HYLE_RETURN_IF_ERROR(widen(source.expert_scales(stage,kLegs[leg],id),expanded));
        HYLE_ASSIGN_OR_RETURN(auto code_target,destination.subview(local*layout_.code_bytes[leg],codes.size()));
        HYLE_RETURN_IF_ERROR(code_target.write(codes));
        HYLE_ASSIGN_OR_RETURN(auto scale_target,destination.subview(layout_.scale_offset(leg,local),layout_.scale_bytes[leg]));
        HYLE_RETURN_IF_ERROR(scale_target.write(std::as_bytes(expanded)));
      }
      HYLE_RETURN_IF_ERROR(mapped.close());
    }
    HYLE_ASSIGN_OR_RETURN(writers[3],pool_.allocate(sizeof(selected.map)));
    HYLE_ASSIGN_OR_RETURN(auto map,writers[3].view());
    HYLE_RETURN_IF_ERROR(map.write(std::as_bytes(std::span(selected.map))));
    for(std::size_t bank=0;bank<4;++bank) {
      HYLE_ASSIGN_OR_RETURN(result.banks[bank],writers[bank].publish());
    }
    return result;
  }
  const Layout &layout() const noexcept{return layout_;}
  c::LeasePoolStats stats() const noexcept{return pool_.stats();}
 private:
  c::StorageOwner owner_;
  Layout layout_;
  c::LeasePool pool_;
  m::Buffer scales_;
};

#if defined(HYLE_TEST_DSPARK_STATE_CUDA)
class CudaSupply final {
 public:
  using Batch=c::cuda::WeightBatch;
  static Result<CudaSupply> create(const c::Context &context,const c::StorageOwner &owner,
      const c::cuda::MemoryResource &device) {
    if(!owner||owner.ref()!=device.ref()||device.kind()!=c::cuda::MemoryKind::kDevice)
      return std::unexpected(Status::InvalidArgument("formal target CUDA supply needs the actual Graph device owner"));
    CudaSupply result;result.state_=std::make_unique<State>();
    auto &state=*result.state_;state.device_owner=owner;
    HYLE_ASSIGN_OR_RETURN(state.layout,Layout::create());
    HYLE_ASSIGN_OR_RETURN(state.host,c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost));
    std::array<c::cuda::WeightSpec,4> catalog;
    for(std::size_t leg=0;leg<3;++leg)catalog[leg]={kBankIds[leg],state.layout.banks[leg]};
    catalog[3]={kBankIds[3],state.layout.map};
    HYLE_ASSIGN_OR_RETURN(state.slots,c::cuda::WeightSlots::create(context,state.host,device,catalog,
        state.layout.slot_bytes,{.max_fragments=3*kCapacity*2+1}));
    // Only the selected E6 scale planes are widened, never the full E256 bank.
    HYLE_ASSIGN_OR_RETURN(state.scales,m::Buffer::create(m::system_resource(),
        kCapacity*(state.layout.scale_bytes[0]+state.layout.scale_bytes[1]+state.layout.scale_bytes[2]),256));
    HYLE_ASSIGN_OR_RETURN(state.map,m::Buffer::create(m::system_resource(),kDomain*sizeof(std::int32_t),256));
    return result;
  }
  template<class Selection,class Source>
  Result<c::cuda::WeightBatch> upload(std::size_t slot,std::size_t stage,
      const Selection &selected,const Source &source,c::Queue &queue) {
    HYLE_RETURN_IF_ERROR(validate(selected));
    if(!state_)return std::unexpected(Status::FailedPrecondition("empty formal target CUDA supply"));
    if(stage>=3)return std::unexpected(Status::InvalidArgument("formal target stage outside tail"));
    auto &state=*state_;
    HYLE_RETURN_IF_ERROR(state.map.view().write(std::as_bytes(std::span(selected.map))));
    std::array<c::WeightSlice,3*kCapacity*2+1> slices;
    std::size_t count=0,scratch_offset=0;
    HYLE_ASSIGN_OR_RETURN(auto mapped,state.scales.view().map_host());
    HYLE_ASSIGN_OR_RETURN(auto bytes,mapped.writable_bytes());
    for(std::size_t leg=0;leg<3;++leg) {
      HYLE_ASSIGN_OR_RETURN(auto code_desc,c::TensorDesc::dense(c::DataType::kUInt8,
          std::array<std::int64_t,1>{std::int64_t(state.layout.code_bytes[leg])}));
      HYLE_ASSIGN_OR_RETURN(auto scale_desc,c::TensorDesc::dense(c::DataType::kUInt8,
          std::array<std::int64_t,1>{std::int64_t(state.layout.scale_bytes[leg])}));
      for(std::size_t local=0;local<kCapacity;++local) {
        const auto id=original_at(selected,local);
        const auto codes=source.expert_view(stage,kLegs[leg],id,false);
        if(codes.size()!=state.layout.code_bytes[leg])
          return std::unexpected(Status::InvalidArgument("formal target FP4 view extent"));
        HYLE_ASSIGN_OR_RETURN(auto code_tensor,c::ConstTensorView::create(code_desc,codes));
        slices[count++]={kBankIds[leg],code_tensor,local*state.layout.code_bytes[leg]};
        HYLE_ASSIGN_OR_RETURN(auto scratch,state.scales.view().subview(scratch_offset,state.layout.scale_bytes[leg]));
        auto expanded=std::span(reinterpret_cast<float*>(bytes.data()+scratch_offset),state.layout.scale_bytes[leg]/sizeof(float));
        HYLE_RETURN_IF_ERROR(widen(source.expert_scales(stage,kLegs[leg],id),expanded));
        HYLE_ASSIGN_OR_RETURN(auto scale_tensor,c::ConstTensorView::create(scale_desc,scratch));
        slices[count++]={kBankIds[leg],scale_tensor,state.layout.scale_offset(leg,local)};
        scratch_offset+=state.layout.scale_bytes[leg];
      }
    }
    HYLE_RETURN_IF_ERROR(mapped.flush());
    HYLE_RETURN_IF_ERROR(mapped.close());
    HYLE_ASSIGN_OR_RETURN(auto map,c::ConstTensorView::create(state.layout.map,state.map.view()));
    slices[count++]={kBankIds[3],map,0};
    // upload_slices synchronously consumes these immutable borrowed ranges.
    // Graph retains the actual pending batch through its last native reader.
    return state.slots.upload_slices(slot,std::span(slices).first(count),queue);
  }
  const Layout &layout() const{return state_->layout;}
  Result<c::WeightUploadReport> report(std::size_t slot) const {
    if(!state_)return std::unexpected(Status::FailedPrecondition("empty formal target CUDA supply"));
    return state_->slots.report(slot);
  }
  Status close(){return state_?state_->slots.close():Status::Ok();}
 private:
  struct State final {
    c::StorageOwner device_owner;
    Layout layout;
    c::cuda::MemoryResource host;
    c::cuda::WeightSlots slots;
    m::Buffer scales,map;
    ~State(){slots.close().IgnoreError();}
  };
  std::unique_ptr<State> state_;
};
#endif
} // namespace dspark_original_target_weights
