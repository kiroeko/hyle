"""Pin the completed typed catalogue, never a partial acquisition."""
from pathlib import Path
import hashlib
import json

S=Path(__file__).resolve().parent
R=S.parents[1]

def identity(path):
    raw=path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def main():
    receipt=json.loads((S/'original-target/acquisition.json').read_text(encoding='utf-8-sig'))
    assert receipt['complete'] and receipt['original_roles']==4725
    assert receipt['role_payload_bytes']==receipt['successful_request_body_bytes']==10748569116
    catalog=S/'original-target/catalog.bin'
    pin=identity(catalog)
    assert pin==receipt['typed_catalog'] and pin['bytes']==75664
    header=R/'tests/compute_models/dspark_original_target_roles.h'
    original=identity(header)
    text=header.read_bytes()
    empty=b'inline constexpr std::string_view kIndexSha256 = "";'
    assert text.count(empty)==1
    text=text.replace(empty,b'inline constexpr std::string_view kIndexSha256 = "'+pin['sha256'].encode()+b'";')
    header.write_bytes(text)
    result=dict(before=original,after=identity(header),typed_catalog=pin,
                acquisition=identity(S/'original-target/acquisition.json'),
                extra_payload_hash_pass=False,native_pass=False)
    (S/'pins.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()
