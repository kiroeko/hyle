"""Keep the actual finite BZ result and the small sources/logs needed to reproduce it."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

S=Path(__file__).resolve().parent
R=S.parents[1]
TEXT={'.py','.json','.cc','.cu','.h','.cuh','.md','.log','.xml','.rsp','.cmd','.ps1','.txt'}

def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def resolve(path):
    value=Path(path)
    return (value if value.is_absolute() else R/value).resolve()
def identity(path):
    path=resolve(path)
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(),bytes=path.stat().st_size,sha256=digest)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--link',type=int,required=True)
    parser.add_argument('--run',type=int,required=True)
    args=parser.parse_args()
    before=read(S/'before.json')
    tail=(R/'docs/developer/current-work.md').read_text(encoding='utf-8-sig').split('## 最新完整性能对比',1)[1]
    protected=hashlib.sha256(('## 最新完整性能对比'+tail).encode()).hexdigest()
    assert protected==before['protected_performance_tail_sha256']
    assert identity(before['protected_qwen_image']['path'])==before['protected_qwen_image']
    # checks1 remains a four-test failed process. Retain only its three XML-proven
    # passes; the failed CUDA target case and its full logs are preserved below.
    baseline_path=S/'checks1/summary.json'
    baseline=read(baseline_path)
    assert baseline['tests']==4 and baseline['failures']==1
    assert baseline['process']['exit']==1 and not baseline['process']['timed_out']
    assert not any(baseline[key] for key in ('errors','disabled','skips'))
    baseline_xml={case.attrib['name']:case for case in ET.parse(S/'checks1/results.xml').getroot().iter('testcase')}
    retained_names={
        'CpuOriginalExpertsFeedFullDraftAndAtomicAcceptedState',
        'CpuOriginalTargetTailAndFullVocabularyVerifierPublishesBlock5Prefix',
        'CudaOriginalExpertsFeedFullDraftAndAtomicAcceptedState'}
    failed_name='CudaOriginalTargetTailAndFullVocabularyVerifierPublishesBlock5Prefix'
    assert baseline_xml[failed_name].find('failure') is not None
    retained=[case for case in baseline['cases'] if case['attributes']['name'] in retained_names]
    assert len(retained)==3
    assert all(not any(baseline_xml[case['attributes']['name']].find(tag) is not None
                       for tag in ('failure','error','skipped')) for case in retained)
    result_path=S/f'checks{args.run}/summary.json'
    result=read(result_path)
    assert result['process']['exit']==0 and not result['process']['timed_out']
    assert result['tests']==len(result['cases'])==4
    assert not any(result[key] for key in ('failures','errors','disabled','skips'))
    target=[case for case in result['cases'] if case['attributes']['classname']=='DSparkOriginalState']
    direct=[case for case in result['cases'] if case['attributes']['classname']=='DeepSeekFp4']
    assert len(target)==1 and target[0]['attributes']['name']==failed_name and len(direct)==3
    assert {case['attributes']['name'] for case in direct}=={
        'WorkspaceOomConcurrencyCompletionAndInvalidIds','ColdShapeDomainAndHostMemory',
        'ActualDownProjectionCancellationRetainsF32Precision'}
    assert all('actual_submissions' not in case.get('properties',{}) for case in direct)
    passed=retained+result['cases']
    counts={case['attributes']['name']:int(case['properties']['actual_submissions']) for case in retained+target}
    assert len(passed)==7 and len(counts)==4 and sum(counts.values())==248
    # The two genuine images/runs have separate identities; no single-run pass claim.
    link_dir=S/f'tests-link{args.link}'
    for directory,run in ((S/'tests-link1',baseline),(link_dir,result)):
        assert read(directory/'ready.json')['image']==run['image']
        assert read(directory/'link.result.json')['exit']==0
        assert resolve(run['process']['command'][0])==resolve(run['image']['path'])
        assert identity(run['image']['path'])==dict(run['image'],path=resolve(run['image']['path']).relative_to(R).as_posix())
    needed={R/'tests/compute_models/dspark_original_state_consumer_test.cc',
            R/'tests/compute_provider_cuda/cuda_provider_test.cc',
            R/'src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc',
            R/'src/compute_provider_cuda/grouped_fp4_f32_kernel.cu'}
    records=[]
    for row in read(link_dir/'link-plan.json')['compiled_records']:
        record=read(resolve(row['path']))
        if resolve(record['source']['path']) in needed:
            records.append((resolve(row['path']),record))
    assert {resolve(record['source']['path']) for _,record in records}==needed
    assert len(records)==4
    sources={resolve(row['path']):row for _,record in records for row in [record['source'],*record['dependencies']]
             if resolve(row['path']).is_relative_to(R)}
    for path,row in sources.items():
        now=identity(path)
        assert (now['bytes'],now['sha256'])==(row['bytes'],row['sha256']),path
    diagnostic=S/'diagnostic-fp4'
    original=read(diagnostic/'reproduction/receipt.json')
    debug=read(diagnostic/'debug-reproduction/receipt.json')
    candidate=read(diagnostic/'candidate-reproduction/receipt.json')
    assert all(run['complete'] for run in (original,debug,candidate))
    assert original['dot']['actual_bf16']==47808 and debug['dot']['actual_bf16']==47808
    assert debug['internals']['partial_mismatches']==27
    assert debug['internals']['scale_a_mismatches']==debug['internals']['scale_b_mismatches']==0
    assert candidate['quantization']['code_mismatches']==candidate['quantization']['scale_mismatches']==0
    assert candidate['dot']['actual_bf16']==candidate['dot']['gpu_quant_scalar_bf16']==47815
    assert candidate['candidate']['within_original_interval'] and candidate['candidate']['same_quantization']
    assert candidate['dot']['native_status']==0 and candidate['dot']['output_guard'] and candidate['dot']['other_rows_are_zero']
    debug_compile=read(diagnostic/'compile-debug.result.json')
    candidate_compile=read(diagnostic/'compile-candidate.result.json')
    assert debug_compile['exit']==candidate_compile['exit']==0
    assert debug_compile['NVCC_translation_units']==candidate_compile['NVCC_translation_units']==1
    product_nvcc=sum(record.get('NVCC_translation_units',0) for _,record in records)
    assert product_nvcc==1
    product_kernel=next(record['source'] for _,record in records if record.get('NVCC_translation_units')==1)
    assert all(product_kernel[key]==candidate_compile['source'][key] for key in ('bytes','sha256'))
    acquisition=read(S/'original-target/acquisition.json')
    assert acquisition['complete'] and acquisition['role_payload_bytes']==10748569116
    pins=read(S/'pins.json')
    assert identity(pins['after']['path'])==pins['after']
    files=set(sources)
    files.update(path for path,_ in records)
    # Small retained actual operands and exact original/debug/candidate cubins
    # make the independent component replay possible without the 10GB bundle.
    files.update(diagnostic/'actual'/name for name in ('input.bf16','weight-row.e2m1','weight-row.ue8'))
    files.update(diagnostic/name for name in ('kDeepSeekFp8Encoded.cubin','kDeepSeekFp4_4096_2048.cubin',
                                            'down-debug.cubin','candidate.cubin'))
    files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in TEXT
                 and path.stat().st_size<10_000_000 and path.name!='publication.json')
    files.update(R/path for path in ('docs/developer/current-work.md','docs/implementation/model-operators.md',
                                    'docs/architecture/compute-design.md','CMakeLists.txt',
                                    'src/compute_provider_cuda/CMakeLists.txt',
                                    'tests/compute_provider_cuda/CMakeLists.txt','cmake/HyleDependencyLock.json',
                                    'tests/compute_provider_cuda/fixtures/fp4_f32_cancellation.json',
                                    'third_party/deepseek_quantization/LICENSE',
                                    'third_party/deepseek_quantization/TILELANG-LICENSE',
                                    'third_party/deepseek_quantization/CUTLASS-LICENSE'))
    destination=R/'docs/evidence/correctness/mtp-dspark-target-verifier-2026-10-23.json'
    archive=destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
        for path in sorted(files):output.write(path,path.relative_to(R).as_posix())
    record=dict(date='2026-10-23',stage='BZ',goal_complete=False,
        conclusion='Seven listed passing cases combine three retained baseline passes and four corrected-image passes. The original four-case run failed its CUDA target check; that failure and its numerical diagnosis remain preserved. The formal Flash0731 target40->41->42, finalHC/norm and full-vocabulary K5 finite checks now pass on Windows CPU/CUDA.',
        artifact=dict(repository=acquisition['repository'],revision=acquisition['revision'],
            original_target_roles=4725,original_target_bytes=acquisition['role_payload_bytes'],
            typed_catalog=acquisition['typed_catalog'],bundle=acquisition['bundle'],
            acquisition=identity(S/'original-target/acquisition.json'),
            obsolete_adapter_removal=identity(S/'obsolete-adapter-removal.json'),
            reuse='Existing original83-role Q8/MXFP4 DSpark draft and formal BF16 embedding/head. No duplicate vocabulary or SDK acquisition.',full_role_bundle_archived=False,retained_micro_operands_archived=True),
        implementation=dict(
            math='Actual three final target layers retain4/128/4 compression, MLA/sparse indexer/window/cache QAT, original E4/UE8 block128 and FP4 group32, all HC and the independent final head parameters.',
            state='Actual current+five draft IDs drive six target rows. Natural greedy acceptance is separate from controlled0/2/5 StateHead prefix publications. Always consume current; publish all21 target states, real captured main-history/carry, protocol and actual pending lease in one30-member version. Proposal KV remains episode-local.',
            architecture='Typed resident phase execution is shared by target and draft. Assembly supplies the actual artifact and selector. HC graph construction only needs typed Values; independent source coefficients stay with references. Explicit code/scale associations and owned HostMappings remove format/lifetime coupling.',
            supply='E6 packed FP4 codes stay unchanged; only selected UE8 scales widen exactly to F32. All code planes precede scale planes. Two finite94372864-byte slots use37 slices with exact global/local map. Prepared BF16 output-A is shared once, with no full-expert F32 weight shadow.',
            fp4_correction='The exact original A128 quantizer is unchanged. Original FP8 QMMA produced inaccurate inner code-dot partials despite F32 containers. The owned CUDA kernel losslessly widens only tiny E4/E2M1 code tiles to BF16, uses F32 WMMA accumulation perK32, then the original separate F32 scale multiplies/outer accumulation and finalBF16 store. The original numerical certificate is retained.'),
        validation=dict(passing_cases=7,combined_runs=2,single_run_all_pass=False,
            graph_submissions=sum(counts.values()),graph_submissions_by_case=counts,
            direct_provider_cases=3,direct_provider_cases_counted_as_graphs=False,
            runs=[dict(summary=identity(baseline_path),image=baseline['image'],process=baseline['process'],
                       tests=4,failures=1,retained_passing_cases=retained,failed_case=failed_name),
                  dict(summary=identity(result_path),image=result['image'],process=result['process'],
                       tests=4,failures=0,errors=0,skips=0,passing_cases=result['cases'])],
            diagnostics=dict(original=identity(diagnostic/'reproduction/receipt.json'),
                debug=identity(diagnostic/'debug-reproduction/receipt.json'),
                candidate=identity(diagnostic/'candidate-reproduction/receipt.json')),
            current_translation_units=dict(host=3,CUDA=1),SDK_builds=0,NVCC_builds=3,
            NVCC_commands=dict(debug_original=identity(diagnostic/'compile-debug.result.json'),
                candidate_cubin=identity(diagnostic/'compile-candidate.result.json'),
                product_TU=[identity(path) for path,record in records if record.get('NVCC_translation_units')==1]),
            shaders=0,compiled_records=[identity(path) for path,_ in records],
            source_inputs=[identity(path) for path in sorted(sources)]),
        limitations=['Layer39 four-stream inputs and finite imported initial histories remain explicit fixtures; these are not full43-layer prompt-to-output execution or task-quality checks.',
            'One finite natural trial per backend and controlled prefixes do not establish workload acceptance rate. No new TPS, loading-time or physical RAM/VRAM peak is measured.',
            'Formal target FP8/FP4 and selected GGUF Q8/MXFP4 draft arithmetic remain distinct. Pro, other confirmed quantizations and necessary other-backend checks remain.'],
        remaining='Finish Pro and other confirmed original MTP artifact combinations, then final ordinary/MTP performance comparison; images follow.',
        latest_full_performance_unchanged=protected,protected_qwen_image=before['protected_qwen_image'],archive=identity(archive),archive_items=len(files))
    destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    publication=dict(evidence=identity(destination),archive=identity(archive))
    (S/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(**publication,passing_cases=7,combined_runs=2,graphs=sum(counts.values()))))

if __name__=='__main__':main()
