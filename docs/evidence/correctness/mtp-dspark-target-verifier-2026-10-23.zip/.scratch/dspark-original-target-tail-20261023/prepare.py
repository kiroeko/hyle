"""Record BZ source/cache inputs before connecting the genuine target tail."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
S=Path(__file__).resolve().parent
R=S.parents[1]
BY=R/'.scratch/q24-target-verifier-20261023'
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def identity(path):
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix(),bytes=path.stat().st_size,sha256=digest)
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert not (S/'before.json').exists()
source=[]
for name in ('dspark_original_state_consumer.h','dspark_original_state_consumer_test.cc',
    'dspark_main_history.h','dspark_complete_graph_fixture.h','dspark_shared_target_roles.h',
    'dspark_original_resident_weights.h','dspark_resident_draft.h',
    'd5_deepseek_official_attention.h','d5_deepseek_official_fragments.h',
    'd5_deepseek_remaining_fragments.h','cpu_c4_model_branches.h'):
    path=R/'tests/compute_models'/name
    row=identity(path);snapshot=S/'before'/row['path']
    snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(path.read_bytes())
    row['snapshot']=snapshot.relative_to(R).as_posix();source.append(row)
assert read(BY/'progress.json')['stage_complete'] is True
previous=read(BY/'publication.json')
assert all(identity(R/row['path'])==row for row in previous.values())
protected=read(BY/'before.json')
text=(R/'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
tail=text[text.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest()==protected['protected_performance_tail_sha256']
save(S/'before.json',dict(stage='BZ',utc=datetime.now(timezone.utc).isoformat(),
    previous_goal_turn_classification='progress: BY genuine Q24 target91, IQ4_XS/Q4_K distinct descriptor-derived supply and shared K1 passed6cases156Graphs; source/evidence/docs published.',
    source=source,previous_publication=previous,
    protected_performance_tail_sha256=protected['protected_performance_tail_sha256'],
    protected_qwen_image=protected['protected_qwen_image']))
save(S/'progress.json',dict(stage='BZ',stage_complete=False,goal_complete=False,
    state='Connect genuine formal Flash40->41->42 captures and finalHC/norm/fullV verifier to existing complete DSpark draft and full-state lifecycle.',
    scope='Actual three final trained target layers with4/128/4 compression. Layer39 BF16 four-stream input and initial target/draft histories remain explicit external boundaries.',
    new_TPS=False,native_checks_run=False,
    next='Obtain exact fixed-source headers and missing roles, reuse existing Flash vocabulary/draft weights, connect complete target caches and actual verifier/accepted-state continuation.'))
print('Prepared BZ; previous goal turn is verified progress.')
