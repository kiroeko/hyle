"""Incremental genuine DSpark Flash target tail and original draft consumers."""
from pathlib import Path
import argparse
import importlib.util
import os
import re
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BH = R / '.scratch/mtp-packed-head-m2-20261023'
spec = importlib.util.spec_from_file_location('bl_cached', BH / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BY = R / '.scratch/q24-target-verifier-20261023'
BASE = BY / 'tests-link3'
RECIPES = {
    'dspark-state': R / '.scratch/dspark-original-experts-20261023/compile4/dspark-state/identity.json',
    'fp4-provider': R / '.scratch/architecture-refactor-2026-10-18/fp8-shared-prologue/checks/host1/compute_provider_cuda--deepseek_grouped_fp4_provider-identity.json',
    'fp4-kernel': R / '.scratch/glm-encoded-state-20261023/compile4/tensor-kernel/identity.json',
    'fp4-test': R / '.scratch/dspark-original-experts-20261023/compile4/dspark-state/identity.json',
}
SOURCES = {
    'dspark-state': R / 'tests/compute_models/dspark_original_state_consumer_test.cc',
    'fp4-provider': R / 'src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc',
    'fp4-kernel': R / 'src/compute_provider_cuda/grouped_fp4_f32_kernel.cu',
    'fp4-test': R / 'tests/compute_provider_cuda/cuda_provider_test.cc',
}


def host(tag, attempt):
    recipe_path = RECIPES[tag]
    if tag == 'fp4-test':
        recipe = c.read(recipe_path)
        recipe['command'] = [x for x in recipe['command'] if not x.startswith('/DHYLE_TEST_DSPARK_STATE_')]
        recipe_path = S / 'recipes/fp4-test.json'
        recipe_path.parent.mkdir(exist_ok=True)
        c.save(recipe_path, recipe)
    h.RECIPES[tag] = recipe_path
    h.SOURCES[tag] = SOURCES[tag]
    h.compile_one(tag, attempt)


def kernel(attempt):
    tag = 'fp4-kernel'
    recipe = c.read(RECIPES[tag])
    host_recipe = c.read(RECIPES['fp4-provider'])
    out = S / f'compile{attempt}' / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    command, skip = [], False
    for arg in recipe['command']:
        if skip:
            skip = False
            continue
        if arg in ('-c', '-o', '-MT', '-MF', '-ccbin', '--compiler-bindir'):
            skip = True
        elif not arg.startswith(('-Xcompiler=-Fd', '-ccbin=', '--compiler-bindir=')):
            command.append(arg)
    command += ['-ccbin', str(Path(host_recipe['command'][0]).parent),
        '-MT', str(out / (tag + '.obj')), '-MF', str(out / (tag + '.d')),
        '-c', str(SOURCES[tag]), '-o', str(out / (tag + '.obj')),
        '-Xcompiler=-Fd' + str(out / (tag + '.pdb')) + ',-FS']
    assert command.count('-ccbin') == 1
    assert '-std=c++20' in command
    assert '--generate-code=arch=compute_89,code=[sm_89]' in command
    frozen = b.identity(SOURCES[tag])
    snapshot = out / 'source' / SOURCES[tag].relative_to(R)
    snapshot.parent.mkdir(parents=True)
    snapshot.write_bytes(SOURCES[tag].read_bytes())
    c.save(out / 'plan.json', dict(source=frozen, command=command,
        recipe=b.identity(RECIPES[tag]), host_recipe=b.identity(RECIPES['fp4-provider']),
        SDK_builds=0, native_CPU_builds=0, NVCC_translation_units=1, shaders=0))
    env, _ = b.environment(host_recipe['command'], [], out)
    c.execute('compile', command, env, out)
    assert b.identity(SOURCES[tag]) == frozen
    depfile = out / (tag + '.d')
    text = depfile.read_text(encoding='utf-8-sig').replace('\\\n', ' ')
    payload = text.split(' : ', 1)[1]
    dependencies, seen = [], set()
    for token in re.findall(r'(?:\\[ \t]|[^\s])+', payload):
        path = Path(token.replace('\\ ', ' ').replace('\\\t', '\t'))
        key = c.key(str(path))
        if key not in seen:
            dependencies.append(b.identity(path))
            seen.add(key)
    assert c.key(str(SOURCES[tag])) in seen
    c.save(out / 'identity.json', dict(source=frozen,
        object=b.identity(out / (tag + '.obj')), command=command,
        dependencies=dependencies, dependency_file=b.identity(depfile), compiler=b.identity(command[0]),
        SDK_builds=0, NVCC_translation_units=1))
    print('COMPILED grouped FP4 code-widen/F32 MMA kernel', flush=True)


def latest(tag):
    paths = sorted(S.glob(f'compile*/{tag}/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    assert paths, tag
    path = paths[-1]
    record = c.read(path)
    assert all(b.identity(x['path']) == x for x in (record['source'], record['object'], *record['dependencies']))
    return path, record


def link(attempt, tags):
    base_path = BASE / 'link-plan.json'
    base = c.read(base_path)
    assert len(tags) == len(set(tags))
    if ('fp4-provider' in tags) != ('fp4-kernel' in tags):
        raise ValueError('The replacement FP4 provider and its new CUDA kernel must be linked together')
    replaced = {c.key(str(SOURCES[tag])) for tag in tags}
    remove, records = set(), []
    for row in base['compiled_records']:
        rec = c.read(row['path'])
        if '/tests/' in rec['source']['path'].replace('\\', '/') or c.key(rec['source']['path']) in replaced:
            remove.add(c.key(rec['object']['path']))
        else:
            records.append(row)
    if 'fp4-provider' in tags:
        old_provider = c.key(c.read(RECIPES['fp4-provider'])['object']['path'])
        assert sum(c.key(x['path']) == old_provider for x in base['inputs']) == 1
        remove.add(old_provider)
    added = [latest(tag) for tag in tags]
    inputs = [rec['object'] for _, rec in added] + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [rec['object']['path'] for _, rec in added]
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'dspark-target-verifier-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(p) for p, _ in added] + records,
        base=b.identity(base_path), SDK_builds=0, native_CPU_builds=0,
        NVCC_builds=int('fp4-kernel' in tags), shaders=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path']) == dll
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image)))
    print('LINKED genuine DSpark target and original consumers', flush=True)


def run(link_attempt, attempt, test_filter, expected):
    spec_run = importlib.util.spec_from_file_location('bi_run', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    q = importlib.util.module_from_spec(spec_run)
    spec_run.loader.exec_module(q)
    folder = S / f'tests-link{link_attempt}'
    image = c.read(folder / 'ready.json')['image']
    assert b.identity(image['path']) == image
    env = os.environ.copy()
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    env['HYLE_DSPARK_ORIGINAL_TARGET_TAIL_DIR'] = str(S / 'original-target')
    env['HYLE_QWEN27_MTP_INPUT_DIR'] = str(R / '.scratch/qwen-original-mtp-20261022/original-q27')
    env['HYLE_QWEN24_MTP_KV_DIR'] = str(R / '.scratch/qwen24-original-mtp-20261022/original-q24')
    env['HYLE_QWEN27_ORIGINAL_NEXTN_DIR'] = str(R / '.scratch/mtp-next-original-20261023/original-q27-nextn')
    env['HYLE_QWEN24_ORIGINAL_NEXTN_DIR'] = str(R / '.scratch/q24-original-nextn-20261023/original-q24-nextn')
    env['HYLE_DSPARK_TARGET_ROLES_DIR'] = str(R / '.scratch/glm-mtp-catchup-20261022/original-dspark-target')
    env['HYLE_DSPARK_HISTORY_ROLES_DIR'] = str(R / '.scratch/glm-mtp-seed-cache-20261022/original-dspark-history')
    env['HYLE_DSPARK_MARKOV_DIR'] = str(R / '.scratch/dspark-mtp-integration-20261022/original-markov')
    env['HYLE_DSPARK_CONFIDENCE_BF16'] = str(R / '.scratch/qwen-mtp-next-20261022/original-confidence/conf_proj.weight.bf16')
    env['HYLE_DSPARK_SHARED_VOCAB_DIR'] = str(R / '.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary')
    env['HYLE_DSPARK_PARAMETER_ROLES_DIR'] = str(R / '.scratch/dspark-original-hc-20261023/original-parameters')
    env['HYLE_DSPARK_SHARED_FFN_DIR'] = str(R / '.scratch/dspark-original-shared-20261023/original-shared')
    env['HYLE_DSPARK_ATTENTION_ROLES_DIR'] = str(R / '.scratch/dspark-original-attention-20261023/original-attention')
    env['HYLE_DSPARK_EXPERT_ROLES_DIR'] = str(R / '.scratch/dspark-original-experts-20261023/original-experts')
    temporary = S / 'runtime-tmp'
    temporary.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(temporary)
    out = S / f'checks{attempt}'
    xml = out / 'results.xml'
    process = q.execute([image['path'], '--gtest_filter=' + test_filter, '--gtest_output=xml:' + str(xml)],
        env, out, timeout=1800)
    result = dict(process=process, image=image, throughput_evidence=False,
                  physical_memory_evidence=False, whole_original_model=False)
    if xml.is_file():
        tree = ET.parse(xml).getroot()
        result.update(tests=int(tree.attrib['tests']), failures=int(tree.attrib['failures']),
            errors=int(tree.attrib['errors']), disabled=int(tree.attrib['disabled']),
            skips=sum(case.find('skipped') is not None for case in tree.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']:p.attrib['value']
                for p in case.iter('property')}) for case in tree.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert process['exit'] == 0 and not process['timed_out'], process
    assert result.get('tests') == expected and not any(result[k] for k in ('failures','errors','disabled','skips')), result
    print('PASS genuine DSpark target/verifier and original consumers', expected, flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('actions', nargs='+', choices=[*SOURCES, 'link', 'run'])
    p.add_argument('--attempt', type=int, default=1)
    p.add_argument('--link-attempt', type=int, default=1)
    p.add_argument('--only', nargs='+', choices=list(SOURCES), default=['dspark-state'])
    p.add_argument('--filter', default='*')
    p.add_argument('--expected-tests', type=int, default=1)
    args = p.parse_args()
    for action in args.actions:
        if action == 'link': link(args.attempt, args.only)
        elif action == 'run': run(args.link_attempt, args.attempt, args.filter, args.expected_tests)
        elif action == 'fp4-kernel': kernel(args.attempt)
        else: host(action, args.attempt)
