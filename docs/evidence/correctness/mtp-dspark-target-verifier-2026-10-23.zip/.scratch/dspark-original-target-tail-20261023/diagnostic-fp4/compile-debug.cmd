@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\nvcc.exe" --cubin -arch=sm_89 -std=c++17 -Xcompiler=/Zc:preprocessor,/utf-8 -DENABLE_BF16 -I"C:\public\project-hyle\hyle\.scratch\tools\d5-tilelang\tilelang\src" -I"C:\public\project-hyle\hyle\.scratch\tools\d5-tilelang\tilelang\3rdparty\cutlass\include" "C:\public\project-hyle\hyle\.scratch\dspark-original-target-tail-20261023\diagnostic-fp4\down-debug.cu" -o "C:\public\project-hyle\hyle\.scratch\dspark-original-target-tail-20261023\diagnostic-fp4\down-debug.cubin"
exit /b %errorlevel%
