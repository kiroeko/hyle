@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\Common7\Tools\VsDevCmd.bat" -no_logo -arch=x64 >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.3\bin\nvcc.exe" --cubin -arch=sm_89 -std=c++20 -Xcompiler=/Zc:preprocessor,/utf-8 -I"C:\public\project-hyle\hyle\src\compute_provider_cuda" -I"C:\public\project-hyle\hyle\src\compute_backend_cuda" "C:\public\project-hyle\hyle\src\compute_provider_cuda\grouped_fp4_f32_kernel.cu" -o "C:\public\project-hyle\hyle\.scratch\dspark-original-target-tail-20261023\diagnostic-fp4\candidate.cubin"
exit /b %errorlevel%
