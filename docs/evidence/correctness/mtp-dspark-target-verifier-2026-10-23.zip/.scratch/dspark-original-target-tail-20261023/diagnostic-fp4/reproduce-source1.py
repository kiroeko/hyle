"""Root-only exact-cubin replay of one retained real FP4 failure row; no compilation."""
from pathlib import Path
import argparse
import ctypes as ct
import hashlib
import json
import math
import numpy as np

S = Path(__file__).resolve().parent
N, K = 4096, 2048
QUANT_SHA = '10a0ef155e7b8ee8955431a8bf152d11a167b7676c5ea363d424bb14670ec2da'
DOWN_SHA = '5c3cc50ea441918a3db7ca9da657ffb37208b79918dd95d4d155d4d52c45d144'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def decode_e4(codes):
    positive = np.array([math.ldexp(float(c), -9) if c < 8 else
                         math.ldexp(1. + (c & 7) / 8., (c >> 3) - 7)
                         for c in range(127)], dtype=np.float32)
    assert np.all((codes & 127) < 127)
    return positive[codes & 127] * np.where(codes & 128, -1., 1.)


def scalar_quant(input_bits):
    values = (input_bits.astype(np.uint32) << 16).view(np.float32).reshape(-1, 128)
    assert np.all(np.isfinite(values))
    maximum = np.maximum(np.abs(values).max(axis=1), np.float32(1.e-4))
    raw = maximum * np.float32(1. / 448.)
    raw_bits = raw.view(np.uint32)
    assert np.all((raw_bits >> 23) > 0) and np.all((raw_bits >> 23) < 255)
    exponent = ((raw_bits >> 23).astype(np.int32) - 127 + ((raw_bits & 0x7fffff) != 0))
    scales = np.ldexp(np.ones(raw.size, dtype=np.float32), exponent).astype(np.float32)
    divided = values / scales[:, None]
    positive = np.array([math.ldexp(float(c), -9) if c < 8 else
                         math.ldexp(1. + (c & 7) / 8., (c >> 3) - 7)
                         for c in range(127)], dtype=np.float32)
    magnitude = np.minimum(np.abs(divided), np.float32(448.))
    high = np.searchsorted(positive, magnitude).clip(0, 126)
    low = np.maximum(high - 1, 0)
    dl, dh = magnitude - positive[low], positive[high] - magnitude
    chosen = np.where((dl < dh) | ((dl == dh) & ((low & 1) == 0)), low, high)
    codes = chosen.astype(np.uint8) | (np.signbit(divided).astype(np.uint8) * 128)
    return codes.reshape(-1), scales


def scalar_dot(codes, scales, packed, ue8, zero_e4_subnormals=False):
    activation = decode_e4(codes)
    if zero_e4_subnormals:
        activation[(codes & 127) < 8] = 0.
    nibble = np.empty(K, dtype=np.uint8)
    nibble[0::2], nibble[1::2] = packed & 15, packed >> 4
    table = np.array([0., .5, 1., 1.5, 2., 3., 4., 6.], dtype=np.float64)
    coefficient = table[nibble & 7] * np.where(nibble & 8, -1., 1.)
    assert np.all(ue8 != 255)
    block_scales = np.ldexp(np.ones(K // 32), ue8.astype(np.int32) - 127)
    blocks = []
    for block in range(K // 32):
        start = block * 32
        inner = math.fsum(float(activation[start + j]) * float(coefficient[start + j]) for j in range(32))
        blocks.append(inner * float(scales[block // 4]) * float(block_scales[block]))
    return math.fsum(blocks)


def bfloat(value):
    bits = np.array([value], dtype=np.float32).view(np.uint32)
    return int(((bits + np.uint32(0x7fff) + ((bits >> 16) & 1)) >> 16)[0])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--operands', type=Path, default=S / 'actual')
    parser.add_argument('--output', type=Path, default=S / 'reproduction')
    args = parser.parse_args()
    manifest_path = args.operands / 'first-failure.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    assert manifest['N'] == N and manifest['K'] == K and 0 <= manifest['row'] < N
    row = manifest['row']
    operand_paths = [args.operands / name for name in ('input.bf16', 'weight-row.e2m1', 'weight-row.ue8')]
    operand_identities = [identity(path) for path in operand_paths]
    assert [item['bytes'] for item in operand_identities] == [2 * K, K // 2, K // 32]
    input_bits = np.frombuffer(operand_paths[0].read_bytes(), dtype='<u2').copy()
    packed = np.frombuffer(operand_paths[1].read_bytes(), dtype=np.uint8)
    ue8 = np.frombuffer(operand_paths[2].read_bytes(), dtype=np.uint8)
    expected_codes, expected_scales = scalar_quant(input_bits)
    reference = scalar_dot(expected_codes, expected_scales, packed, ue8)

    # Same Windows CUDA Driver declarations as the existing d5-f43/f44 probes;
    # no exec/import of their top-level context or native fixture actions.
    ct.windll.kernel32.SetErrorMode(0x0001 | 0x0002 | 0x8000)
    driver = ct.WinDLL('nvcuda.dll')
    ptr, u64, i32, u32 = ct.c_void_p, ct.c_uint64, ct.c_int32, ct.c_uint32

    def bind(name, types):
        function = getattr(driver, name)
        function.argtypes, function.restype = types, i32

        def call(*values):
            status = function(*values)
            if status:
                raise RuntimeError(f'{name}: CUDA driver error {status}')
        return call

    init = bind('cuInit', [u32])
    device_get = bind('cuDeviceGet', [ct.POINTER(i32), i32])
    device_name = bind('cuDeviceGetName', [ptr, i32, i32])
    attribute = bind('cuDeviceGetAttribute', [ct.POINTER(i32), i32, i32])
    driver_version = bind('cuDriverGetVersion', [ct.POINTER(i32)])
    retain = bind('cuDevicePrimaryCtxRetain', [ct.POINTER(ptr), i32])
    release = bind('cuDevicePrimaryCtxRelease_v2', [i32])
    current = bind('cuCtxSetCurrent', [ptr])
    sync = bind('cuCtxSynchronize', [])
    load = bind('cuModuleLoadData', [ct.POINTER(ptr), ptr])
    unload = bind('cuModuleUnload', [ptr])
    function = bind('cuModuleGetFunction', [ct.POINTER(ptr), ptr, ct.c_char_p])
    alloc = bind('cuMemAlloc_v2', [ct.POINTER(u64), ct.c_size_t])
    free = bind('cuMemFree_v2', [u64])
    upload = bind('cuMemcpyHtoD_v2', [u64, ptr, ct.c_size_t])
    download = bind('cuMemcpyDtoH_v2', [ptr, u64, ct.c_size_t])
    launch = bind('cuLaunchKernel', [ptr, u32, u32, u32, u32, u32, u32, u32, ptr, ct.POINTER(ptr), ptr])

    args.output.mkdir(parents=True, exist_ok=True)
    receipt = dict(scope='one actual retained failure row, exact current quant/down cubins; independent native component reproduction, not an Hyle model or performance measurement',
                   complete=False, operands=operand_identities, original_failure=manifest, n=N, k=K,
                   experts=1, slots=1, activation_slots=1, restored_weight_row=row)

    def save():
        (args.output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

    modules, images, buffers = [], [], []
    context, dev, retained = ptr(), i32(), False
    try:
        init(0)
        device_get(ct.byref(dev), 0)
        major, minor, version = i32(), i32(), i32()
        attribute(ct.byref(major), 75, dev)
        attribute(ct.byref(minor), 76, dev)
        driver_version(ct.byref(version))
        name = ct.create_string_buffer(256)
        device_name(name, len(name), dev)
        assert major.value * 10 + minor.value == 89, 'Only the exact SM89 artifact is being reproduced'
        receipt['device'] = dict(name=name.value.decode(), sm=89, driver_version=version.value)
        retain(ct.byref(context), dev)
        retained = True
        current(context)
        kernels = []
        receipt['programs'] = []
        for file, symbol, sha in [('kDeepSeekFp8Encoded.cubin', b'act_quant_kernel__kernel', QUANT_SHA),
                                  ('kDeepSeekFp4_4096_2048.cubin', b'deepseek_indexed_fp4', DOWN_SHA)]:
            path = S / file
            description = identity(path)
            assert description['sha256'] == sha
            image = ct.create_string_buffer(path.read_bytes())
            images.append(image)
            module, kernel = ptr(), ptr()
            load(ct.byref(module), image)
            modules.append(module)
            function(ct.byref(kernel), module, symbol)
            kernels.append(kernel)
            receipt['programs'].append(dict(**description, entry=symbol.decode()))

        weight = np.zeros((N, K // 2), dtype=np.uint8)
        scales_b = np.ones((N, K // 32), dtype=np.float32)
        weight[row], scales_b[row] = packed, np.ldexp(np.ones(K // 32, dtype=np.float32), ue8.astype(np.int32) - 127)
        arrays = [input_bits, np.full(K + 32, 0x5a, np.uint8),
                  np.full(K // 128 + 16, -9876., np.float32), weight, scales_b,
                  np.array([0], np.int32), np.full(N + 32, 0x5a5a, np.uint16), np.array([0], np.uint32)]
        for array in arrays:
            pointer = u64()
            alloc(ct.byref(pointer), array.nbytes)
            buffers.append(pointer)
            upload(pointer, array.ctypes.data, array.nbytes)

        quant_args = [buffers[2], buffers[0], buffers[1], i32(K // 128)]
        parameters = (ptr * len(quant_args))(*(ct.cast(ct.byref(value), ptr) for value in quant_args))
        launch(kernels[0], 1, 1, 1, 128, 1, 1, 8192, None, parameters, None)
        sync()
        for index in (1, 2):
            download(arrays[index].ctypes.data, buffers[index], arrays[index].nbytes)
        actual_codes, actual_scales = arrays[1][:K], arrays[2][:K // 128]
        code_positions = np.flatnonzero(actual_codes != expected_codes)
        scale_positions = np.flatnonzero(actual_scales.view(np.uint32) != expected_scales.view(np.uint32))
        receipt['quantization'] = dict(code_mismatches=int(code_positions.size), scale_mismatches=int(scale_positions.size),
            guard_codes=bool(np.all(arrays[1][K:] == 0x5a)), guard_scales=bool(np.all(arrays[2][K // 128:] == -9876.)),
            code_examples=[dict(i=int(i), input_bf16=int(input_bits[i]), actual=int(actual_codes[i]), expected=int(expected_codes[i])) for i in code_positions[:32]],
            scale_examples=[dict(group=int(i), actual=float(actual_scales[i]), expected=float(expected_scales[i])) for i in scale_positions[:32]])
        (args.output / 'quant-codes.e4m3').write_bytes(actual_codes.tobytes())
        (args.output / 'quant-scales.f32').write_bytes(actual_scales.tobytes())
        save()
        dot_args = [buffers[1], buffers[3], buffers[6], buffers[2], buffers[4], buffers[5], buffers[7], i32(1), i32(1), i32(1)]
        parameters = (ptr * len(dot_args))(*(ct.cast(ct.byref(value), ptr) for value in dot_args))
        launch(kernels[1], N // 128, 1, 1, 128, 1, 1, 10240, None, parameters, None)
        sync()
        for index in (6, 7):
            download(arrays[index].ctypes.data, buffers[index], arrays[index].nbytes)
        actual_bits = int(arrays[6][row])
        actual_value = float(np.array([actual_bits << 16], dtype=np.uint32).view(np.float32)[0])
        actual_quant_center = scalar_dot(actual_codes, actual_scales, packed, ue8)
        all_other = np.delete(arrays[6][:N], row)
        receipt['dot'] = dict(actual_bf16=actual_bits, actual=actual_value,
            original_scalar_center=reference, original_scalar_bf16=bfloat(reference),
            gpu_quant_scalar_center=actual_quant_center, gpu_quant_scalar_bf16=bfloat(actual_quant_center),
            zero_e4_subnormal_center=scalar_dot(actual_codes, actual_scales, packed, ue8, True),
            native_status=int(arrays[7][0]), other_rows_are_zero=bool(np.all((all_other & 0x7fff) == 0)),
            output_guard=bool(np.all(arrays[6][N:] == 0x5a5a)), matches_retained_failure=(actual_bits == manifest['actual_bf16']))
        receipt.update(complete=True, verdict='OBSERVED_EXACT_NATIVE_COMPONENT',
                       logical_submissions=dict(quantization=1, grouped_fp4_down=1), compiled_sources=0)
        save()
        print(json.dumps(dict(quantization=receipt['quantization'], dot=receipt['dot']), indent=2), flush=True)
        assert receipt['quantization']['guard_codes'] and receipt['quantization']['guard_scales']
        assert receipt['dot']['native_status'] == 0 and receipt['dot']['other_rows_are_zero'] and receipt['dot']['output_guard']
    except BaseException as error:
        receipt.update(complete=False, error_type=type(error).__name__, error=str(error))
        save()
        raise
    finally:
        for pointer in reversed(buffers):
            free(pointer)
        for module in reversed(modules):
            unload(module)
        if retained:
            current(None)
            release(dev)


if __name__ == '__main__':
    main()
