"""Write one instrumented original down body; no compiler or CUDA invocation."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[2]
ORIGINAL = R / '.scratch/validation/d5-f44-original-fp4/fp4_4096_2048.cu'


def main():
    metadata = json.loads((S / 'actual/first-failure.json').read_text(encoding='utf-8-sig'))
    assert metadata['N'] == 4096 and metadata['K'] == 2048
    row = metadata['row']
    tile, column = divmod(row, 128)
    # Exact inverse of the generated final shared-store coordinate map for
    # Mrow0. i is the float2 fragment index; component is its x/y lane.
    thread = (column // 64) * 64 + ((column % 8) // 2)
    pair = ((column % 64) // 8) * 2
    component = column % 2
    fragment = pair * 2 + component
    scale_a, scale_b = pair & 1, (pair >> 1) * 2 + component
    shared = (((thread & 63) >> 5) * 2048 + (pair & 1) * 1024 +
              ((thread & 31) >> 2) * 128 + (thread >> 6) * 64 +
              (pair >> 1) * 8 + (thread & 3) * 2 + component)
    assert shared == column and 0 <= fragment < 32
    original = ORIGINAL.read_text(encoding='utf-8')
    assert original.count('int M)') == 2
    source = original.replace('int M)', 'int M, float* debug)')
    assert source.count('int activation_slots) {') == 1
    source = source.replace('int activation_slots) {', 'int activation_slots, float* debug) {')
    old_call = 'scales_a + row * 16, scales_b + selected * 262144ULL, 1);'
    assert source.count(old_call) == 1
    source = source.replace(old_call, old_call.removesuffix('1);') + '1, debug);')
    source = source.replace('deepseek_indexed_fp4(', 'deepseek_indexed_fp4_debug(')

    def observation(block, indent):
        return (f'{indent}// Diagnostic-only observation; original MMA/scaling/accumulation is unchanged.\n'
                f'{indent}if ((int)blockIdx.x == {tile} && (int)threadIdx.x == {thread}) {{\n'
                f'{indent}  debug[({block}) * 4 + 0] = C_local[{fragment}];\n'
                f'{indent}  debug[({block}) * 4 + 1] = scale_a_frag[{scale_a}];\n'
                f'{indent}  debug[({block}) * 4 + 2] = scale_b_frag[{scale_b}];\n'
                f'{indent}  debug[({block}) * 4 + 3] = C_local_accum[{fragment}];\n'
                f'{indent}}}\n')

    for variable, block, indent in [('i_7', 'k', '    '), ('i_13', '62', '  '), ('i_19', '63', '  ')]:
        anchor = f'{indent}#pragma unroll\n{indent}for (int {variable} = 0;'
        assert source.count(anchor) == 1
        source = source.replace(anchor, observation(block, indent) + anchor)
    output = S / 'down-debug.cu'
    output.write_text(source, encoding='utf-8', newline='\n')
    toolkit = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/bin/nvcc.exe')
    tilelang = R / '.scratch/tools/d5-tilelang/tilelang'
    cmd = ('@echo off\n'
           'call "C:\\Program Files\\Microsoft Visual Studio\\18\\Enterprise\\Common7\\Tools\\VsDevCmd.bat" -no_logo -arch=x64 >nul\n'
           'if errorlevel 1 exit /b %errorlevel%\n'
           f'"{toolkit}" --cubin -arch=sm_89 -std=c++17 -Xcompiler=/Zc:preprocessor,/utf-8 -DENABLE_BF16 '
           f'-I"{tilelang / "src"}" -I"{tilelang / "3rdparty/cutlass/include"}" '
           f'"{output}" -o "{S / "down-debug.cubin"}"\n'
           'exit /b %errorlevel%\n')
    (S / 'compile-debug.cmd').write_text(cmd, encoding='utf-8')
    receipt = dict(scope='source generation only; no compilation/native execution',
        original=dict(path=str(ORIGINAL), bytes=ORIGINAL.stat().st_size,
                      sha256=hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()),
        output=dict(path=str(output), bytes=output.stat().st_size, sha256=hashlib.sha256(output.read_bytes()).hexdigest()),
        row=row, tile=tile, thread=thread, float_fragment=fragment, scale_a_fragment=scale_a,
        scale_b_fragment=scale_b, blocks=64, output_floats=256,
        fields=['actual original MMA C_local', 'actual SFa', 'actual SFb', 'actual accumulated F32 after this block'],
        entry='deepseek_indexed_fp4_debug', extra_abi='float* debug appended after int activation_slots',
        condition='Only trust internal comparisons after checking debug native BF16 output equals retained original failure bits.')
    (S / 'debug-source.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
