#include "C:/public/project-hyle/hyle/tests/compute_models/dspark_original_target_weights.h"
namespace t=dspark_original_target_weights;
void instantiate(t::CpuSupply &cpu,t::CudaSupply &gpu,const t::original::Selection &selection,const t::original::Data &source,hyle::compute::Queue &queue){(void)cpu.upload(0,selection,source);(void)gpu.upload(0,0,selection,source,queue);}
