from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
s=Path('.scratch/dspark-original-target-tail-20261023').resolve()
probe=s/'supply-preflight.cc'
probe.write_text('#include "'+(Path.cwd()/'tests/compute_models/dspark_original_target_weights.h').as_posix()+'"\n#include "'+(Path.cwd()/'tests/compute_models/dspark_original_target_program.h').as_posix()+'"\n#include "'+(Path.cwd()/'tests/compute_models/dspark_original_target_reference.h').as_posix()+'"\nnamespace t=dspark_original_target_weights;\nvoid instantiate(t::CpuSupply &cpu,t::CudaSupply &gpu,const t::original::Selection &selection,const t::original::Data &source,hyle::compute::Queue &queue){(void)cpu.upload(0,selection,source);(void)gpu.upload(0,0,selection,source,queue);}\n',encoding='utf-8')
spec=importlib.util.spec_from_file_location('bz_build',s/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.h.S=s
b.h.RECIPES['supply-preflight']=b.RECIPES['dspark-state']
b.h.SOURCES['supply-preflight']=probe
b.h.compile_one('supply-preflight',3)
print('Supply CPU/CUDA template preflight only; no link or native inference.')
