"""Build exact formal Flash tail ranges from authenticated header-only receipts."""
from pathlib import Path
import hashlib
import json
import math

S = Path(__file__).resolve().parent
R = S.parents[1]
REPOSITORY = 'deepseek-ai/DeepSeek-V4-Flash-0731'
REVISION = '7872f01b1d1fe23eabc4c98b48bffcef5a386062'
COUNT, BODY_BYTES = 4725, 10748569116


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main():
    summary = read(S / 'headers/summary.json')
    assert summary['complete'] and summary['repository'] == REPOSITORY and summary['revision'] == REVISION
    assert not summary['whole_shards_downloaded']
    schema = read(S / 'role-schema.json')
    shards, headers = [], []
    for ordinal, record in enumerate(summary['shards']):
        assert record['file'] == f'model-{ordinal + 42:05d}-of-00048.safetensors'
        raw = (R / record['header']['path']).read_bytes()
        assert len(raw) == record['header']['bytes']
        assert hashlib.sha256(raw).hexdigest() == record['header']['sha256']
        headers.append(json.loads(raw))
        shards.append({key: record[key] for key in
                       ('file', 'url', 'whole_file_bytes', 'etag', 'data_base', 'header')})
    roles = []

    def add(shard, name, kind, **metadata):
        value = headers[shard][name]
        width = {'I8': 1, 'F8_E4M3': 1, 'F8_E8M0': 1, 'BF16': 2, 'F32': 4}[value['dtype']]
        start, end = value['data_offsets']
        extent = math.prod(value['shape']) * width
        assert end - start == extent and extent > 0
        first = shards[shard]['data_base'] + start
        assert first + extent <= shards[shard]['whole_file_bytes']
        roles.append(dict(index=len(roles), name=name, kind=kind, **metadata,
                          dtype=value['dtype'], shape=value['shape'], bytes=extent,
                          source_shard=shard, data_relative_half_open=[start, end],
                          absolute_inclusive=[first, first + extent - 1]))

    layer_summaries = []
    for stage in range(3):
        layer = stage + 40
        prefix = f'layers.{layer}.'
        before = len(roles)
        for raw_role, suffix in enumerate(schema['static_suffixes']):
            name = prefix + suffix
            if name not in headers[stage]:
                assert stage == 1 and '.indexer.' in name
                continue
            add(stage, name, 'static', stage=stage, raw_role=raw_role)
        static_count = len(roles) - before
        for expert in range(256):
            for leg, weight in enumerate(schema['expert_legs']):
                for part, suffix in enumerate(('weight', 'scale')):
                    add(stage, f'{prefix}ffn.experts.{expert}.{weight}.{suffix}', 'expert',
                        stage=stage, expert=expert, leg=leg, part=part)
        assert len(roles) - before == (1576, 1569, 1576)[stage]
        assert {row['name'] for row in roles[before:]} == set(headers[stage]) - {'__metadata__'}
        layer_summaries.append(dict(stage=stage, layer=layer, compression_ratio=(4, 128, 4)[stage],
                                    static_roles=static_count, original_roles=len(roles)-before,
                                    bytes=sum(row['bytes'] for row in roles[before:])))
    for role, name in enumerate(schema['final_names']):
        add(3, name, 'final', final_role=role)
    assert len(roles) == COUNT and sum(row['bytes'] for row in roles) == BODY_BYTES
    groups, offset = [], 0
    for shard in range(4):
        selected = sorted((row for row in roles if row['source_shard'] == shard),
                          key=lambda row: row['absolute_inclusive'][0])
        previous = None
        for row in selected:
            first, last = row['absolute_inclusive']
            if previous is None or first != previous['last'] + 1:
                previous = dict(index=len(groups), source_shard=shard, first=first, last=last,
                                bundle_offset=offset, bytes=row['bytes'])
                groups.append(previous)
            else:
                previous['last'] = last
                previous['bytes'] += row['bytes']
            row['bundle_offset'] = offset
            offset += row['bytes']
    assert offset == BODY_BYTES and sum(group['bytes'] for group in groups) == BODY_BYTES
    # Selected roles are exact-cover ranges; never fill holes with other model tensors.
    ordered = sorted(roles, key=lambda row: row['bundle_offset'])
    cursor = 0
    for row in ordered:
        assert row['bundle_offset'] == cursor
        cursor += row['bytes']
    plan = dict(repository=REPOSITORY, revision=REVISION, original_roles=COUNT,
                bundle_bytes=BODY_BYTES, whole_shards_downloaded=False,
                typed_order='each stage: present static RawRoles then expert0..255 gate/up/down code+SF; final4',
                role_schema_sha256=hashlib.sha256((S/'role-schema.json').read_bytes()).hexdigest(),
                layers=layer_summaries, shards=shards, roles=roles, groups=groups)
    (S/'roles-plan.json').write_text(json.dumps(plan, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(original_roles=COUNT, bytes=BODY_BYTES, merged_groups=len(groups), layers=layer_summaries)), flush=True)


if __name__ == '__main__':
    main()
