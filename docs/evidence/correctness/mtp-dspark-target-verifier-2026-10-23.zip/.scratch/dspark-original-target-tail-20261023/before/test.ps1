$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$scope = (Resolve-Path -LiteralPath (Join-Path $repoRoot '.scratch/glm-shared-lm-20261023')).Path.TrimEnd('\') + '\'
if (-not (Test-Path -LiteralPath (Join-Path $scope 'tests-link2/glm-shared-lm-checks.exe') -PathType Leaf)) {
  throw 'Retain the passing current executable before cleanup'
}
$relativeTargets = @(
  'tests-link1/glm-shared-lm-checks.exe',
  'tests-link1/glm-shared-lm-checks.map'
)
# Superseded executable/map only. Keep link2, all source/object/runtime
# caches, original compressed weights and every command/result/failed attempt.
$entries = @(
  foreach ($relative in $relativeTargets) {
    $target = [IO.Path]::GetFullPath((Join-Path $scope $relative))
    if (-not $target.StartsWith($scope, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside batch directory: $target" }
    if (Test-Path -LiteralPath $target) {
      $resolved = (Resolve-Path -LiteralPath $target).Path
      if (-not $resolved.StartsWith($scope, [StringComparison]::OrdinalIgnoreCase)) { throw "Resolved outside batch: $resolved" }
      $item = Get-Item -LiteralPath $resolved
      if ($item.PSIsContainer) { throw "Expected a file: $resolved" }
      [pscustomobject]@{ path = $resolved; bytes = $item.Length }
    }
  }
)
foreach ($entry in $entries) { Remove-Item -LiteralPath $entry.path -Force }
$record = [ordered]@{
  complete = $true
  removed_files = $entries.Count
  logical_removed_bytes = ($entries | Measure-Object -Property bytes -Sum).Sum
  targets = $entries
  retained = 'Current link2 executable/map, all objects/runtime/SDK/source/data and all failure/command/result records'
}
$record | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $scope 'cleanup/result.json') -Encoding utf8
$record | ConvertTo-Json -Depth 5
