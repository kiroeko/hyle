// Actual Vulkan Graph Invocation reuse while independent output leases live.
// Downloads are oracle observations only; no shadow output preserves a version.
#include <hyle/compute/vulkan_memory.h>
#include <hyle/graph/executable.h>
#include <hyle/graph/result.h>
#include <hyle/graph/vulkan.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <span>
#include <utility>
#include <vector>

namespace {
namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
using hyle::Result;
using hyle::Status;
using Bytes = std::vector<std::byte>;
constexpr std::size_t elements = 32, slice_first = 8, slice_elements = 16;

Status require(bool value, const char *message) {
  return value ? Status::Ok() : Status::Internal(message);
}
struct NativeRange final {
  VkBuffer buffer = VK_NULL_HANDLE;
  VkDeviceSize offset = 0;
};
struct Generation final {
  c::ReadLease whole, slice;
  NativeRange range;
  std::uint64_t whole_generation = 0, slice_generation = 0;
};
struct Ports final { g::ValueId input, whole, slice; };

Result<NativeRange> native_range(const v::MemoryResource &device,
                               const c::ReadLease &lease,
                               const c::TensorDesc &description) {
  HYLE_ASSIGN_OR_RETURN(auto tensor, device.binding(lease, description));
  HYLE_ASSIGN_OR_RETURN(auto storage, device.storage_info(tensor));
  return NativeRange{storage.buffer, storage.offset_bytes};
}
Result<Bytes> read(const v::Context &context, const v::MemoryResource &device,
                   const c::ReadLease &lease, const c::TensorDesc &description) {
  HYLE_ASSIGN_OR_RETURN(auto size, description.required_bytes());
  HYLE_ASSIGN_OR_RETURN(auto storage, lease.view());
  HYLE_RETURN_IF_ERROR(require(lease.size() == size && storage.size() == size &&
      storage.resource() == device.ref(), "output lease lost its exact native resource or byte extent"));
  HYLE_ASSIGN_OR_RETURN(auto tensor, device.binding(lease, description));
  Bytes bytes(size);
  HYLE_RETURN_IF_ERROR(context.download(tensor, bytes));
  return bytes;
}
Status readonly(c::ReadLease &lease, std::uint64_t generation) {
  auto writer = lease.try_write();
  HYLE_RETURN_IF_ERROR(require(!writer && lease.valid() && lease.generation() == generation,
      "retained native output gained writer permission or changed generation"));
  return Status::Ok();
}
Status observe(const v::Context &context, const v::MemoryResource &device,
               Generation &generation, const c::TensorDesc &whole,
               const c::TensorDesc &slice, const Bytes &expected,
               std::size_t scalar_bytes) {
  HYLE_RETURN_IF_ERROR(readonly(generation.whole, generation.whole_generation));
  HYLE_RETURN_IF_ERROR(readonly(generation.slice, generation.slice_generation));
  HYLE_ASSIGN_OR_RETURN(auto actual, read(context, device, generation.whole, whole));
  HYLE_ASSIGN_OR_RETURN(auto actual_slice, read(context, device, generation.slice, slice));
  const auto subspan = std::span(expected).subspan(slice_first * scalar_bytes, slice_elements * scalar_bytes);
  HYLE_RETURN_IF_ERROR(require(actual == expected &&
      actual_slice.size() == subspan.size() &&
      std::equal(actual_slice.begin(), actual_slice.end(), subspan.begin()),
      "native retained whole output or its published offset alias changed bytes"));
  HYLE_ASSIGN_OR_RETURN(auto whole_range, native_range(device, generation.whole, whole));
  HYLE_ASSIGN_OR_RETURN(auto slice_range, native_range(device, generation.slice, slice));
  HYLE_RETURN_IF_ERROR(require(whole_range.buffer == generation.range.buffer &&
      whole_range.offset == generation.range.offset &&
      slice_range.buffer == whole_range.buffer &&
      slice_range.offset == whole_range.offset + slice_first * scalar_bytes,
      "retained output/offset alias lost its original native backing relationship"));
  return Status::Ok();
}

Status stale_submit_rejected(g::Invocation &invocation) {
  // The no-argument convenience overload prepares commands itself. Exercise
  // the strict prepared submission contract, which must not rearm implicitly.
  auto stale = invocation.submit(std::span<const g::QueueBinding>{});
  if (stale) {
    stale->wait().IgnoreError();
    return Status::Internal("unbound or rebound-but-unprepared Invocation admitted stale submission");
  }
  return require(stale.error().IsFailedPrecondition(), "stale submission returned an unexpected error category");
}
Result<Generation> execute(g::Invocation &invocation, const Ports &ports,
                           const c::TensorDesc &input_description,
                           const c::TensorDesc &whole_description,
                           const c::TensorDesc &slice_description,
                           const c::ReadLease &input, const v::MemoryResource &device) {
  HYLE_RETURN_IF_ERROR(invocation.bind(ports.input, input_description, input));
  HYLE_RETURN_IF_ERROR(stale_submit_rejected(invocation));
  HYLE_RETURN_IF_ERROR(invocation.prepare_replay({}));
  Generation result;
  {
    HYLE_ASSIGN_OR_RETURN(auto completion, invocation.submit(std::span<const g::QueueBinding>{}));
    HYLE_RETURN_IF_ERROR(completion.wait());
    {
      HYLE_ASSIGN_OR_RETURN(auto whole, invocation.result(ports.whole));
      HYLE_ASSIGN_OR_RETURN(auto slice, invocation.result(ports.slice));
      HYLE_ASSIGN_OR_RETURN(auto whole_desc, whole.description());
      HYLE_ASSIGN_OR_RETURN(auto slice_desc, slice.description());
      HYLE_RETURN_IF_ERROR(require(whole_desc == whole_description && slice_desc == slice_description,
          "generated output descriptions changed across native replay"));
      HYLE_ASSIGN_OR_RETURN(result.whole, whole.storage_lease());
      HYLE_ASSIGN_OR_RETURN(result.slice, slice.storage_lease());
      // Public result handles still pin their original Invocation. Independent
      // leases become the only escaped observations when this scope ends.
      HYLE_RETURN_IF_ERROR(require(!invocation.unbind(ports.input).ok(),
          "live GraphOutput observation allowed its original input to be withdrawn"));
    }
  }
  HYLE_RETURN_IF_ERROR(require(!invocation.in_flight(), "successful original Completion did not retire native work"));
  HYLE_ASSIGN_OR_RETURN(result.range, native_range(device, result.whole, whole_description));
  result.whole_generation = result.whole.generation(); result.slice_generation = result.slice.generation();
  return result;
}

Bytes expected(const std::array<float, elements> &input, bool bfloat) {
  Bytes bytes(input.size() * (bfloat ? sizeof(std::uint16_t) : sizeof(float)));
  for (std::size_t i = 0; i < input.size(); ++i) {
    if (bfloat) {
      // Every fixture value is exactly representable as BF16. This oracle
      // therefore does not introduce a conversion-tolerance policy.
      const auto bits = std::bit_cast<std::uint32_t>(input[i]);
      const auto word = static_cast<std::uint16_t>(bits >> 16);
      const auto source = std::as_bytes(std::span(&word, 1));
      std::copy(source.begin(), source.end(), bytes.begin() + static_cast<std::ptrdiff_t>(i * sizeof(word)));
    } else {
      const float value = -input[i];
      const auto source = std::as_bytes(std::span(&value, 1));
      std::copy(source.begin(), source.end(), bytes.begin() + static_cast<std::ptrdiff_t>(i * sizeof(value)));
    }
  }
  return bytes;
}

Status exercise(const v::Context &context, const v::MemoryResource &device,
                const g::ExecutionSource &source, bool bfloat) {
  const auto dtype = bfloat ? c::DataType::kBFloat16 : c::DataType::kFloat32;
  const auto scalar_bytes = bfloat ? sizeof(std::uint16_t) : sizeof(float);
  HYLE_ASSIGN_OR_RETURN(auto input_description, c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 1>{elements}));
  HYLE_ASSIGN_OR_RETURN(auto whole_description, c::TensorDesc::dense(dtype,
      std::array<std::int64_t, 1>{elements}));
  HYLE_ASSIGN_OR_RETURN(auto slice_description, c::TensorDesc::dense(dtype,
      std::array<std::int64_t, 1>{slice_elements}));
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  Ports ports;
  HYLE_ASSIGN_OR_RETURN(ports.input, builder.input(input_description));
  if (bfloat) {
    // The original native route selects its actual BF16 conversion/managed
    // implementation. The test does not replace it with a host conversion.
    HYLE_ASSIGN_OR_RETURN(ports.whole, builder.add(c::Cast{dtype}, ports.input));
  } else {
    HYLE_ASSIGN_OR_RETURN(ports.whole, builder.add(c::Unary{c::UnaryKind::kNeg}, ports.input));
  }
  HYLE_ASSIGN_OR_RETURN(auto slice_op, c::View::slice(0, slice_first, slice_elements));
  HYLE_ASSIGN_OR_RETURN(ports.slice, builder.add(slice_op, ports.whole));
  HYLE_RETURN_IF_ERROR(builder.publish(ports.whole));
  HYLE_RETURN_IF_ERROR(builder.publish(ports.slice));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  HYLE_ASSIGN_OR_RETURN(auto calculation, graph.producer(ports.whole));
  const std::array domains{g::StorageDomain{device.ref()}};
  const std::array targets{g::ExecutionTarget{source, g::StorageDomainId{0}}};
  HYLE_ASSIGN_OR_RETURN(auto compiled, g::compile(graph, {domains, targets}));
  bool native_calculation = false;
  for (std::size_t index = 0; index < compiled.report.step_count(); ++index) {
    HYLE_ASSIGN_OR_RETURN(auto step, compiled.report.step(index));
    for (std::size_t node = 0; node < step.node_count; ++node) {
      HYLE_ASSIGN_OR_RETURN(auto logical, compiled.report.step_node(index, node));
      if (logical != calculation) continue;
      HYLE_RETURN_IF_ERROR(require(step.target == g::ExecutionTargetId{0} &&
          step.kind == g::CompileStepKind::kProviderRegion &&
          step.runtime.mode == c::ProviderRuntimeMode::kDelegated,
          "calculation escaped the original delegated Vulkan source"));
      native_calculation = true;
    }
  }
  HYLE_RETURN_IF_ERROR(require(native_calculation && compiled.executable.required_queue_count() == 0,
      "actual Vulkan calculation or its original no-caller-Queue route is missing"));
  HYLE_ASSIGN_OR_RETURN(auto invocation,
      compiled.executable.create_invocation({.resources = g::ResourceOptions{}}));
  std::array<c::ReadLease, 3> inputs;
  std::array<Bytes, 3> wanted;
  for (std::size_t generation = 0; generation < inputs.size(); ++generation) {
    std::array<float, elements> values;
    for (std::size_t i = 0; i < values.size(); ++i) {
      const float magnitude = float(i % 16) * .5F + .25F + float(generation) * 2.F;
      values[i] = i % 2 ? -magnitude : magnitude;
    }
    HYLE_ASSIGN_OR_RETURN(auto native, context.upload(input_description, std::as_bytes(std::span(values))));
    HYLE_ASSIGN_OR_RETURN(inputs[generation], device.import_readonly(native));
    wanted[generation] = expected(values, bfloat);
  }
  // One Invocation, one compiled Graph/source and the original input resource
  // serve every generation. No second execution slot or payload copy is used.
  HYLE_ASSIGN_OR_RETURN(auto first, execute(invocation, ports, input_description,
      whole_description, slice_description, inputs[0], device));
  HYLE_RETURN_IF_ERROR(observe(context, device, first, whole_description, slice_description, wanted[0], scalar_bytes));
  HYLE_RETURN_IF_ERROR(invocation.unbind(ports.input));
  HYLE_RETURN_IF_ERROR(stale_submit_rejected(invocation));
  HYLE_ASSIGN_OR_RETURN(auto second, execute(invocation, ports, input_description,
      whole_description, slice_description, inputs[1], device));
  HYLE_RETURN_IF_ERROR(require(first.range.buffer != second.range.buffer || first.range.offset != second.range.offset,
      "two simultaneously retained distinct generations use the same output range"));
  HYLE_RETURN_IF_ERROR(observe(context, device, first, whole_description, slice_description, wanted[0], scalar_bytes));
  HYLE_RETURN_IF_ERROR(observe(context, device, second, whole_description, slice_description, wanted[1], scalar_bytes));
  first.whole.reset(); first.slice.reset();
  HYLE_RETURN_IF_ERROR(invocation.unbind(ports.input));
  HYLE_RETURN_IF_ERROR(stale_submit_rejected(invocation));
  HYLE_ASSIGN_OR_RETURN(auto third, execute(invocation, ports, input_description,
      whole_description, slice_description, inputs[2], device));
  HYLE_RETURN_IF_ERROR(require(second.range.buffer != third.range.buffer || second.range.offset != third.range.offset,
      "third generation overwrote the still-retained second generation"));
  HYLE_RETURN_IF_ERROR(require(third.range.buffer == first.range.buffer && third.range.offset == first.range.offset,
      "released first generation was not reused as the original block's bounded spare"));
  HYLE_RETURN_IF_ERROR(observe(context, device, second, whole_description, slice_description, wanted[1], scalar_bytes));
  HYLE_RETURN_IF_ERROR(observe(context, device, third, whole_description, slice_description, wanted[2], scalar_bytes));
  invocation = {}; compiled.executable = {}; graph = {};
  HYLE_RETURN_IF_ERROR(observe(context, device, second, whole_description, slice_description, wanted[1], scalar_bytes));
  HYLE_RETURN_IF_ERROR(observe(context, device, third, whole_description, slice_description, wanted[2], scalar_bytes));
  std::printf("PASS Vulkan %s same Invocation three generations; independent readonly full/offset-view leases; old bytes and exact resource preserved\n",
      bfloat ? "F32-to-BF16 Cast" : "F32 Neg static descriptor");
  return Status::Ok();
}
Status run() {
  HYLE_ASSIGN_OR_RETURN(auto context, v::Context::create());
  HYLE_RETURN_IF_ERROR(require(!context.environment().software_device, "retained-output consumer requires an actual Vulkan device"));
  std::printf("Vulkan device: %s; driver: %s\n", context.environment().device_name.c_str(), context.environment().driver_info.c_str());
  HYLE_ASSIGN_OR_RETURN(auto device, v::MemoryResource::create(context, v::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto source, g::vulkan::execution_source(context));
  HYLE_RETURN_IF_ERROR(exercise(context, device, source, false));
  return exercise(context, device, source, true);
}
} // namespace

int main() {
  const auto status = run();
  if (status.ok()) return 0;
  std::fprintf(stderr, "Vulkan retained-output reuse: %.*s\n", int(status.message().size()), status.message().data());
  return 1;
}
