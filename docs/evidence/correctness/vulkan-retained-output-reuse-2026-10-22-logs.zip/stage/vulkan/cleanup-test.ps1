# AL Vulkan: superseded test images/linker outputs only; latest executable stays.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$allowed = @('link1','link2','link3') | ForEach-Object { Join-Path $workspace ('.scratch\qwen-retained-budget-20261022\vulkan-build\' + $_) }
$targets = @(
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link1\retained-output.exe'; Bytes = 67911168; SHA256 = 'c173ddd541f540317160d097067dedcca53cb633dfd3c52484892d03ffb333f8' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link1\retained-output.map'; Bytes = 30453248; SHA256 = 'ea3d0af8c2c9f1c839e8d2fd338f0b912d5b4280de5e9e5721b034c73b86d549' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link1\retained-output.lib'; Bytes = 42434; SHA256 = '70756e32f21a2145234c2ed02aa202e722e5076db3d8e73eae3ffac233bebc79' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link1\retained-output.exp'; Bytes = 25007; SHA256 = '347a389aefbcc75312d7a61c98e1aaea1185d13d75545d1920acd5b466661f6d' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link2\retained-output.exe'; Bytes = 67911168; SHA256 = 'f205fb68a700c3928aa1c599aef0ce167325ac4f0f10788c0428020802cc985b' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link2\retained-output.map'; Bytes = 30452825; SHA256 = '3af668d1b4e6b35392963f1c46ec4c7e5f323f9112d0b082752aa9dc5cc35812' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link2\retained-output.lib'; Bytes = 42434; SHA256 = '70756e32f21a2145234c2ed02aa202e722e5076db3d8e73eae3ffac233bebc79' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link2\retained-output.exp'; Bytes = 25007; SHA256 = '29cfc6f159868c0993147e8c0705c33f5a7760b65595a44120b73bdbf81d0ec6' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link3\retained-output.map'; Bytes = 30452753; SHA256 = 'd634a7adeb5f508baa64db460bfcda66d3195870d35b6710df782c5297e84ae4' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link3\retained-output.lib'; Bytes = 42434; SHA256 = '70756e32f21a2145234c2ed02aa202e722e5076db3d8e73eae3ffac233bebc79' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-retained-budget-20261022\vulkan-build\link3\retained-output.exp'; Bytes = 25007; SHA256 = '8c3050af38efd3711b5bb2ec5faa658837e3cbcc006d33b78a6d751f6d5b0bfe' }
)
foreach ($target in $targets) {
  $leaf = Get-Item -LiteralPath $target.Path -Force
  if ($leaf.PSIsContainer -or $leaf.DirectoryName -notin $allowed -or $leaf.FullName -ne $target.Path) { throw 'Unexpected cleanup target' }
  if ($leaf.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $leaf.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.SHA256) { throw 'Cleanup target changed' }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.Path -Force }
[pscustomobject]@{ removed = $targets; logical_file_bytes = ($targets | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_measured = $false } | ConvertTo-Json -Depth 5
