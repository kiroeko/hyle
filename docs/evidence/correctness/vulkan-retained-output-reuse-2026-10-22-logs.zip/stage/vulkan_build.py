"""Incremental Vulkan output-epoch owners and one actual native consumer."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];V=S/'vulkan-build'
spec=importlib.util.spec_from_file_location('al_vk',R/'.scratch/native-paged-effects-20261022/build_windows.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c;h.S=V
BASE=R/'.scratch/native-paged-capacity-20261022/vulkan-link2';base=c.read(BASE/'link-plan.json')
h.RECIPES={
 'program':R/'.scratch/native-paged-capacity-20261022/compile2/vk-program/identity.json',
 'pipeline':R/'.scratch/architecture-refactor-2026-10-18/mlx-moe-typed-inputs/vulkan/checks/compute_route_vulkan-vulkan_pipeline-identity.json',
 'region':R/'.scratch/architecture-refactor-2026-10-18/ga-bf16-indexer-state-2026-10-21/common/checks/attempt1/vulkan-region/identity.json',
 'leaf':R/'.scratch/native-paged-effects-20261022/compile1/vk-region/identity.json',
 'test':R/'.scratch/native-paged-capacity-20261022/compile1/vk-test/identity.json'}
h.SOURCES={tag:R/name for tag,name in {
 'program':'src/compute_route_vulkan/vulkan_program.cc','pipeline':'src/compute_route_vulkan/vulkan_pipeline.cc',
 'region':'src/compute_route_vulkan/vulkan_region.cc','leaf':'src/graph_route_vulkan/native_region.cc',
 'test':'tests/graph_route_vulkan/retained_output_reuse_consumer.cc'}.items()}
def link(attempt):
    replacements={};records=[]
    for tag,old in h.RECIPES.items():
        rec=V/f'compile{attempt}/{tag}/identity.json'
        if not rec.is_file():rec=V/f'compile1/{tag}/identity.json'
        row=c.read(rec);assert b.identity(row['source']['path'])==row['source'];records.append(b.identity(rec));replacements[c.key(c.read(old)['object']['path'])]=row['object']
    for old,new in [
      (R/'.scratch/architecture-refactor-2026-10-18/cold-copy-retirement/checks/20261019T053001-df70e294/src--compute--resource_budget-identity.json',R/'.scratch/native-state-ownership-20261022/compile1/budget/identity.json'),
      (R/'.scratch/paged-exclusive-20261021/compile1/leases/identity.json',R/'.scratch/native-state-ownership-20261022/compile2/leases/identity.json'),
      (R/'.scratch/native-paged-effects-20261022/compile1/resources/identity.json',R/'.scratch/native-state-ownership-20261022/compile1/resources/identity.json')]:
        replacements[c.key(c.read(old)['object']['path'])]=c.read(new)['object']
    for key in replacements:assert sum(c.key(x['path'])==key for x in base['inputs'])==1,key
    for x in base['inputs']:assert b.identity(x['path'])==x
    for x in replacements.values():assert b.identity(x['path'])==x
    out=V/f'link{attempt}';out.mkdir();(out/'tmp').mkdir();image=out/'retained-output.exe'
    command=[replacements.get(c.key(x),{}).get('path',x)for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[replacements.get(c.key(x['path']),x)for x in base['inputs']]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_records=records,SDK_builds=0,NVCC=0,shader_builds=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(BASE/'runtime-environment.json');c.save(out/'runtime-environment.json',runtime);c.save(out/'ready.json',dict(image=b.identity(image),plan=b.identity(out/'link-plan.json')))
    print('LINKED Vulkan retained outputs',flush=True)
def run(attempt):
    root=V/f'link{attempt}';out=V/f'run{attempt}';out.mkdir();env=dict(os.environ,PATH=c.read(root/'runtime-environment.json')['PATH'])
    c.save(out/'image.json',b.identity(root/'retained-output.exe'));c.execute('run',[str(root/'retained-output.exe')],env,out)
    print((out/'run.stdout.log').read_text(errors='replace'))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('actions',nargs='+',choices=[*h.RECIPES,'link','run']);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
    for tag in a.actions:
        if tag=='link':link(a.attempt)
        elif tag=='run':run(a.attempt)
        else:h.compile_one(tag,a.attempt)
