"""Publish the finite real Vulkan readonly-output epoch check."""
from pathlib import Path
import difflib,hashlib,json,zipfile
R=Path.cwd();S=Path(__file__).resolve().parent;V=S/'vulkan';B=S/'vulkan-build';O=R/'docs/evidence/correctness'
def read(p):return json.loads(p.read_bytes())
def ident(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
freeze=read(V/'source-freeze.json')
for x in freeze['files']:assert ident(R/x['path'])['sha256']==x['current']['sha256']
records=[]
for tag in ['program','pipeline','region','leaf']:
    x=read(B/f'compile1/{tag}/identity.json');assert ident(Path(x['source']['path']))==x['source'];records.append(x)
test=read(B/'compile3/test/identity.json');assert ident(Path(test['source']['path']))==test['source'];records.append(test)
for attempt in [1,2,3]:
    assert read(B/f'run{attempt}/run.result.json')['exit']==(1 if attempt==1 else 0)
text=(B/'run3/run.stdout.log').read_text(encoding='utf8');assert text.count('PASS Vulkan')==2
cleanup=json.loads((V/'cleanup-receipt.json').read_text(encoding='utf-8-sig'));assert all(not Path(x['Path']).exists()for x in cleanup['removed'])
assert ident(R/'test.ps1')['sha256']==ident(V/'cleanup-test.ps1')['sha256']
new_files=['tests/graph_route_vulkan/retained_output_reuse_consumer.cc','tests/graph_route_vulkan/CMakeLists.txt','docs/developer/current-work.md']
for name in ['tests/graph_route_vulkan/CMakeLists.txt']:
    before=V/'before'/name;after=R/name;diff=''.join(difflib.unified_diff(before.read_text(encoding='utf8').splitlines(keepends=True),after.read_text(encoding='utf8').splitlines(keepends=True),fromfile='before/'+name,tofile=name))
    (V/'test-registration.diff').write_text(diff,encoding='utf8')
entries={}
for root,label in [(V,'stage/vulkan'),(B,'stage/vulkan-build'),(S/'vulkan-review','stage/vulkan-review')]:
    for p in root.rglob('*'):
        if p.is_file()and p.suffix in ['.json','.log','.cc','.h','.diff','.ps1','.py']:
            entries[label+'/'+p.relative_to(root).as_posix()]=p
for name in [x['path']for x in freeze['files']]+new_files:entries['source/'+name]=R/name
entries['stage/vulkan_build.py']=S/'vulkan_build.py';entries['stage/publish_vulkan.py']=Path(__file__)
archive=O/'vulkan-retained-output-reuse-2026-10-22-logs.zip';inventory=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,p in sorted(entries.items()):
        raw=p.read_bytes();z.writestr(name,raw);inventory.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
with zipfile.ZipFile(archive)as z:
    assert len(set(z.namelist()))==len(inventory)
    for x in inventory:
        raw=z.read(x['path']);assert len(raw)==x['bytes']and hashlib.sha256(raw).hexdigest()==x['sha256']
manifest=dict(schema='hyle.vulkan-retained-output-reuse.v1',date='2026-10-22',status='PASS_LIMITED_NATIVE_OUTPUT_EPOCH_REUSE',
    source_freeze=freeze,new_sources=[ident(R/x)for x in new_files],
    mechanism=['Original Program/Run/observed endpoint retained; no executor per decode/session',
               'Complete owned storage blocks rotate, all affected alias Buffer objects are new; old readonly backings never rebound in place',
               'Original native static descriptors and child native sets cold rebound; managed/IREE continue original bind contract',
               'Retired reverse unbind does not absorb old readers into baseline; mandatory cold rearm and full bind/seal before strict submit',
               'At most one retained spare per storage block; only original unique root after native retirement is reusable'],
    actual_checks=['RTX4070 real Vulkan, F32 Neg and F32-to-BF16 Cast, 32 elements, whole and offset view outputs',
                   'Same Graph Invocation runs three distinct input generations; independent readonly leases survive public GraphOutput/Completion and Invocation destruction',
                   'Retained old whole/slice payload and native resource/range/generation unchanged; try_write rejected',
                   'Second/third generations use distinct ranges while second remains retained; dropping first permits third to reuse its exact original native range',
                   'Live GraphOutput prevents unbind; strict submit without prepare/unbound rejects'],
    build=dict(product_CXX=4,test_CXX=3,SDK_builds=0,NVCC=0,shader_builds=0,CMake_configure_run=False,
               records=records,final_link=read(B/'link3/ready.json'),dependency_plan=ident(B/'link3/link-plan.json')),
    runs=[dict(attempt=i,process=read(B/f'run{i}/run.result.json'),image=read(B/f'run{i}/image.json'),stdout=(B/f'run{i}/run.stdout.log').read_text(encoding='utf8'),stderr=(B/f'run{i}/run.stderr.log').read_text(encoding='utf8'))for i in [1,2,3]],
    initial_failure=dict(cause='Test incorrectly expected no-argument convenience submit to stay unprepared; src/graph/submission.cc:439 explicitly prepares it',
                         correction='Only fixture changed to strict submit(span<const QueueBinding>{}); no product gate relaxed',
                         last_repeat_reason='Add actual reuse of released first-generation spare assertion, not seek a favorable repeated timing'),
    review=read(S/'vulkan-review/common-source-review.json'),
    limitations=['Finite primitive native/comversion paths; not a complete Qwen Vulkan/MTP consumer',
                 'Opaque Vk AllocationToken is not canonical backing identity; cross-domain retained-budget deduplication still requires an explicit private backing annotation',
                 'No new TPS, physical memory peak measurement or native in-flight failure/cancel injection',
                 'No claim all dtype/shape/operator/backend combinations passed; input-alias output detachment stays unsupported with explicit rejection'],
    cleanup=dict(receipt=cleanup,script=ident(V/'cleanup-test.ps1'),execution_original_path=str(R/'test.ps1'),executed=True,do_not_rerun=True),
    archive=ident(archive),archive_entries=inventory)
path=O/'vulkan-retained-output-reuse-2026-10-22.json';path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(manifest=ident(path),archive=ident(archive),entries=len(inventory),final_native_cases=2,removed_bytes=cleanup['logical_file_bytes'])))
