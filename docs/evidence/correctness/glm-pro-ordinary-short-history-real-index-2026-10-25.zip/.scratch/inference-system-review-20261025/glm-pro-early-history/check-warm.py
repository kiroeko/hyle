from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent/'warm-syntax'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
original=b.args(R/'.scratch/glm-pro-target77-20261023/compile2/glm-pro/compile.command.json')
flags=[];skip=False
for word in original[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    if word.lower().startswith(('/fo','/fd')) or word.lower().endswith(('.cc','.cpp')):continue
    flags.append(word)
source=R/'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
pins=[b.pin(p) for p in [source,R/'tests/compute_models/glm_pro_target_fragment.h',R/'tests/compute_models/glm_pro_target_reference.h']]
env=b.environment(original[0]);b.execute([original[0],*flags,'/Zs',str(source)],D,env,120)
assert pins==[b.pin(Path(p['path'])) for p in pins]
b.save(D/'source-pins.json',pins)
b.save(D/'summary.json',dict(status='PASS',kind='strict syntax only',MTP_execution=False,SDK_builds=0,HTTP=0))
