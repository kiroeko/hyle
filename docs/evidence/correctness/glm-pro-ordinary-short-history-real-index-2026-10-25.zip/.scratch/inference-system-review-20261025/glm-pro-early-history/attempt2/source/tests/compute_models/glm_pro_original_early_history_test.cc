// Ordinary original target77 and its genuine layer74 shared-index boundary.
// These cold description checks require neither weights nor a native device.
#include <gtest/gtest.h>
#include <array>
#include <cstdint>
#include <optional>

#include "glm_pro_target_fragment.h"

namespace {
namespace target=glm_pro_target_fragment;
namespace model=glm_pro_mtp_fragment;
namespace sem=d5_qwen38_24t_semantic_fragments;
namespace c=hyle::compute;
using Value=sem::ValueId;

struct DescriptionFixture final {
  sem::Fragment fragment{.profile=&d5_moe_semantic_fragments::profiles::glm53_official,
      .region=0x474c4d373453484fULL,.quantized=true};
  target::Parameters parameters;
  model::moe::Parameters experts;
  Value hidden,residual,main,cursor;
  DescriptionFixture() {
    const auto input=[&](std::initializer_list<std::int64_t> shape,c::DataType type=c::DataType::kFloat32) {
      return fragment.input(sem::dense(shape,type));
    };
    const auto fp8=[&](std::int64_t n,std::int64_t k) {
      return fragment.input(glm_shared_vocabulary::take(c::float8_weight_description(k,n,
          c::Float8ScaleMode::kFloat32Block128),"ordinary target description"));
    };
    hidden=input({1,6144},c::DataType::kBFloat16);residual=input({1,6144},c::DataType::kBFloat16);
    main=input({2054,576});cursor=input({1},c::DataType::kInt32);
    parameters.input_norm=input({6144},c::DataType::kBFloat16);
    parameters.query_a=fp8(2048,6144);parameters.query_norm=input({2048},c::DataType::kBFloat16);
    parameters.target_norm=input({6144},c::DataType::kBFloat16);
    parameters.attention={input({512},c::DataType::kBFloat16),fp8(576,6144),fp8(6144,16384),
        input({6144},c::DataType::kBFloat16),fp8(16384,2048),
        input({64,512,192},c::DataType::kBFloat16),input({64,256,512},c::DataType::kBFloat16)};
    constexpr auto geometry=glm_moe_geometry::kPro;
    experts.router=input({geometry.experts,geometry.hidden},c::DataType::kBFloat16);
    experts.bias=input({geometry.experts});experts.map=input({geometry.experts},c::DataType::kInt32);
    for(std::size_t leg=0;leg<3;++leg) {
      const auto n=leg==2?geometry.hidden:geometry.intermediate,k=leg==2?geometry.intermediate:geometry.hidden;
      experts.shared[leg]=fragment.input(glm_moe_storage::packed_description(n,k,1,
          glm_moe_storage::Kind::kFloat8Block128,false));
      experts.banks[leg]=fragment.input(glm_moe_storage::packed_description(n,k,geometry.slots,
          glm_moe_storage::Kind::kFloat8Block128,true));
    }
  }
  target::Result append(Value selection) {
    return target::append(fragment,hidden,residual,main,selection,cursor,parameters,experts);
  }
};

TEST(GlmProOrdinaryEarlyHistoryPlan,UsesRealPositiveSelectionWidthsWithoutPadding) {
  std::optional<std::size_t> nodes;
  for(const auto width:std::array<std::int64_t,4>{1,2,4,2048}) {
    DescriptionFixture fixture;auto &f=fixture.fragment;
    const auto ids=f.input(sem::dense({width},c::DataType::kInt32));
    const auto result=fixture.append(ids);
    EXPECT_EQ(result.ports.selection.ordinal(),ids.ordinal());
    EXPECT_EQ(f.description(result.ports.attention.selected_full),sem::dense({width,576}));
    EXPECT_EQ(f.description(result.ports.attention.selected_value),sem::dense({width,512}));
    EXPECT_EQ(f.description(result.main),sem::dense({2054,576}));
    EXPECT_EQ(f.description(result.cursor),sem::dense({1},c::DataType::kInt32));
    if(nodes)EXPECT_EQ(f.nodes.size(),*nodes);else nodes=f.nodes.size();
    f.outputs={result.main,result.cursor,result.normalized_tap};
    const auto graph=sem::make_graph(f);
    EXPECT_EQ(graph.outputs.size(),3u);
  }
}

TEST(GlmProOrdinaryEarlyHistoryPlan,RejectsInvalidSelectionBeforeAddingModelNodes) {
  const std::array descriptions{sem::dense({2049},c::DataType::kInt32),
      sem::dense({1,1},c::DataType::kInt32),sem::dense({1},c::DataType::kFloat32)};
  for(const auto &description:descriptions) {
    DescriptionFixture fixture;const auto ids=fixture.fragment.input(description);
    const auto nodes=fixture.fragment.nodes.size();
    EXPECT_THROW(fixture.append(ids),std::runtime_error);
    EXPECT_EQ(fixture.fragment.nodes.size(),nodes);
  }
}
} // namespace
