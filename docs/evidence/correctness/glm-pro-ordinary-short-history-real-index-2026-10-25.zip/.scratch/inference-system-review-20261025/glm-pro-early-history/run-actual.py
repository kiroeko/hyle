from pathlib import Path
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent/(sys.argv[1] if len(sys.argv)>1 else 'attempt5')
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(D/'ready.json');assert b.pin(D/'checks.exe')==ready['image']
for pin in ready['sources']:assert b.pin(Path(pin['path']))==pin
env=os.environ.copy();env['PATH']=str(D)+';'+b.read(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')['PATH']
env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
    HYLE_GLM_PRO_INDEX74_BUNDLE=str(D.parent/'index74-source/payload/roles.bin'),
    HYLE_GLM_PRO_TARGET_DIR=str(R/'.scratch/glm-pro-target77-20261023/original-static'),
    HYLE_GLM_PRO_TARGET_MOE_DIR=str(R/'.scratch/glm-pro-target77-20261023/original-moe'),
    HYLE_GLM_PRO_VOCAB_DIR=str(R/'.scratch/glm-pro-nextn-20261023/original-static'))
temporary=D/'runtime-tmp';temporary.mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(temporary)
b.save(D/'actual-inputs.json',{k:v for k,v in env.items() if k.startswith(('HYLE_GLM_PRO_','HF_','TRANSFORMERS_'))})
out=D/'actual'
b.execute([str(D/'checks.exe'),'--gtest_color=no','--gtest_filter=GlmProOrdinaryEarlyHistory.*',
    '--gtest_output=xml:'+str(out/'results.xml')],out,env,600)
tree=ET.parse(out/'results.xml').getroot()
assert int(tree.get('tests'))==1 and int(tree.get('failures'))==0 and not list(tree.iter('skipped'))
b.save(out/'summary.json',dict(status='PASS',tests=1,skips=0,model_processes=1,
    actual_positions=[0,1,2,3],actual_selected_widths=[1,2,3,4],SDK_builds=0,HTTP=0,
    claims='Original74 index+original77 target component with complete ordinary state; explicit omitted upstream inputs, no full model/quality/TPS/MTP claim'))
