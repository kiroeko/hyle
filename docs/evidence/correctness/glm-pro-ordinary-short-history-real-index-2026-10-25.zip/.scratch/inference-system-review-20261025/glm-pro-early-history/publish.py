"""Offline compact publication; excludes all weights, executables and objects."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

R=Path.cwd();D=Path(__file__).resolve().parent
REL='tests/compute_models/glm_pro_original_early_history_test.cc'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def dump(p,x):p.write_bytes((json.dumps(x,indent=2)+'\n').encode())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

# Keep the exact failed compile sources as well as their original raw output.
# Reconstruction is accepted only on equality with the before-compile SHA.
for attempt,base,replacements in [
    (1,2,[('EXPECT_EQ(result.ports.selection.ordinal(),ids.ordinal());','EXPECT_EQ(result.ports.selection,ids);')]),
    (3,5,[('const auto pending=values<std::int32_t>(prediction[0]);\n      const auto all_logits=values<float>(prediction[1]),maxima=values<float>(prediction[2]);',
           'const auto pending=values<std::int32_t>(prediction[0]),all_logits=values<float>(prediction[1]),maxima=values<float>(prediction[2]);'),
          ('EXPECT_FALSE(head.publish(before.identity(),candidate).ok());','EXPECT_FALSE(head.publish(before.identity(),candidate));')]),
    (4,5,[('EXPECT_FALSE(head.publish(before.identity(),candidate).ok());','EXPECT_FALSE(head.publish(before.identity(),candidate));')])]:
    source=(D/f'attempt{base}/source'/REL).read_bytes().decode('utf8')
    for old,new in replacements:
        assert source.count(old)==1,(attempt,old)
        source=source.replace(old,new)
    raw=source.encode();expected=load(D/f'attempt{attempt}/before-pins.json')[0]
    assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],attempt
    out=D/f'attempt{attempt}/source-reconstructed'/REL;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)

paths=[R/'tests/compute_models/glm_pro_target_fragment.h',R/'tests/compute_models/glm_pro_target_reference.h',R/REL]
dump(D/'after-pins.json',[pin(p) for p in paths])
patch=''
for p in paths:
    old=D/'before'/p.name
    a=old.read_text(encoding='utf8').splitlines(True) if old.exists() else []
    b=p.read_text(encoding='utf8').splitlines(True)
    patch+=''.join(difflib.unified_diff(a,b,fromfile='a/'+p.relative_to(R).as_posix() if old.exists() else '/dev/null',tofile='b/'+p.relative_to(R).as_posix()))
(D/'changes.patch').write_bytes(patch.encode())

ready=load(D/'attempt7/ready.json')
for p in ready['sources']:
    actual=R/Path(p['path']).relative_to(R)
    assert hashlib.sha256(actual.read_bytes()).hexdigest()==p['sha256']
latest={p['path'].replace('\\','/').lower():p for p in ready['sources']}
reuse=[]
for attempt in [2,5,6]:
    for p in load(D/f'attempt{attempt}/actual-source-pins.json'):
        if p['path'].replace('\\','/').lower().endswith('/'+REL.lower()):continue
        final=latest[p['path'].replace('\\','/').lower()]
        assert p['sha256']==final['sha256'] and p['bytes']==final['bytes']
    reuse.append(dict(attempt=attempt,non_consumer_project_headers='Exact SHA/bytes match final attempt7 source copy; no duplicate archived trees'))
dump(D/'source-reuse.json',reuse)
actual=load(D/'attempt7/actual/process.json');assert actual['exit']==0
tree=ET.parse(D/'attempt7/actual/results.xml').getroot();assert tree.get('tests')=='1' and tree.get('failures')=='0'
properties={p.get('name'):p.get('value') for p in tree.iter('property')}
stdout=(D/'attempt7/actual/stdout.log').read_text(encoding='utf8')
rows=[dict(position=int(p),selected=int(s),epoch=int(e),next_id=int(n),index_cursor=int(i),target_cursor=int(t))
      for p,s,e,n,i,t in re.findall(r'GLM Pro ordinary p=(\d+) selected=(\d+) epoch=(\d+) next=(\d+) indexCursor=(\d+) targetCursor=(\d+)',stdout)]
assert [x['position'] for x in rows]==[0,1,2,3]
assert [x['next_id'] for x in rows]==[27289,14619,17259,53245]
assert properties['stale_publish_rejections']=='4' and properties['invalid_shared_index_rejections']=='11'
source=load(D/'index74-source/payload/complete.json')
bundle=D/'index74-source/payload/roles.bin'
assert pin(bundle)['sha256']==source['bundle_sha256']
with bundle.open('rb') as stream:
    for role in source['roles']:
        stream.seek(role['offset']);raw=stream.read(role['bytes']);assert hashlib.sha256(raw).hexdigest()==role['sha256']
dump(D/'actual-facts.json',dict(status='PASS',actual_rows=rows,properties=properties,process=actual,
    source_bundle=pin(bundle),final_state=dict(versions=0,drafts=0,backing_bytes=0,after_explicit_collect=True),
    first_runtime_failure=load(D/'attempt5/actual/process.json'),second_runtime_failure=load(D/'attempt6/actual/process.json')))

files=set()
def add(p):
    assert p.is_file(),p
    assert p.suffix.lower() not in {'.exe','.obj','.dll','.lib','.exp','.pdb'},p
    assert p.name!='roles.bin',p
    files.add(p)
for p in D.iterdir():
    if p.is_file() and p.name!='publication.json' and p.suffix in {'.json','.py','.ps1','.patch'}:add(p)
for p in (D/'before').rglob('*'):
    if p.is_file():add(p)
for attempt in range(1,8):
    folder=D/f'attempt{attempt}'
    for p in folder.rglob('*'):
        if not p.is_file():continue
        relative=p.relative_to(folder)
        if 'runtime-tmp' in relative.parts:continue
        if 'source' in relative.parts and attempt!=7 and p.name!=Path(REL).name:continue
        if p.suffix in {'.json','.log','.xml'} or 'source' in relative.parts or 'source-reconstructed' in relative.parts:add(p)
for folder in [D/'warm-syntax',D/'index74-source']:
    for p in folder.rglob('*'):
        if p.is_file() and p.name!='roles.bin' and p.suffix in {'.json','.bin','.log','.xml'}:add(p)
for p in paths:add(p)
for rel in ['.scratch/glm-pro-target77-20261023/plan-summary.json',
            '.scratch/glm-pro-target77-20261023/static-pins.json']:
    add(R/rel)

public=R/'docs/evidence/correctness/glm-pro-ordinary-short-history-real-index-2026-10-25'
archive=public.with_suffix('.zip');manifest=[pin(p) for p in sorted(files)]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
    z.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in manifest:
        data=z.read(p['path']);assert len(data)==p['bytes'] and hashlib.sha256(data).hexdigest()==p['sha256']

result=dict(schema=1,status='PASS_FINITE_ORIGINAL_COMPONENT',date='2026-10-25',
    scope='Ordinary original GLM-5.3 layer74 indexer supplies short-context target77, with complete actual ordinary StateHead and real untied full-vocabulary pending; explicit omitted upstream boundaries.',
    product_changes=[dict(path=paths[0].relative_to(R).as_posix(),change='Use actual positive I32 selection width1..2048; same warm2048 node/math/ports.'),
                     dict(path=paths[1].relative_to(R).as_posix(),change='Reference actual selected width/visible rows and same K576/V512 lease values.'),
                     dict(path=REL,change='Two cold host cases and one ordinary original-index/target state consumer; no MTP algorithm change.')],
    validation=dict(host=load(D/'attempt7/host/summary.json'),actual=load(D/'actual-facts.json'),
                    old_warm_consumer=dict(process=load(D/'warm-syntax/process.json'),kind='Strict syntax only; no old MTP/warm execution'),
                    compiler='MSVC14.50 /W4 /WX; one consumer TU per recorded attempt; existing native closure reused',
                    final_compile=load(D/'attempt7/compile/process.json'),final_link=load(D/'attempt7/link/process.json'),
                    image=ready['image'],native=ready['native'],SDK_rebuilds=0,backend_TU_rebuilds=0),
    retained_failures=[
        dict(attempt=1,stage='compile',issue='New test compared semantic ValueId without operator==; use ordinal; exact source reconstructed against precompile SHA.'),
        dict(attempt=3,stage='compile',issue='New consumer mixed I32/F32 vector auto declarations; split declarations; exact failed source SHA verified.'),
        dict(attempt=4,stage='compile',issue='New test used GTest bool assertion on Status; use .ok(); exact failed source SHA verified.'),
        dict(attempt=5,stage='actual',exit=1,issue='Missing observation Copy for actual late-bound resident map. Original74 and target77 p0 local gates reached; no Head published. Expose actual map, keep real supply/graph math.'),
        dict(attempt=6,stage='actual',exit=1,issue='All4 actual steps/state/pending passed; final zero-backing assertion preceded required StateStore.collect. Add existing explicit collection; no StateStore/product change.')],
    source_identity=dict(repository=source['repository'],revision=source['revision'],index74=source['source'],
                         original_header=dict(bytes=106200,sha256='fbb268804254c406cebf497247b0f599fbcb2eae1d019c2a0f19be0a58f284a3',data_base=106208),
                         raw_roles=source['roles'],bundle_sha256=source['bundle_sha256'],bundle_bytes=9571008,
                         acquisition=dict(owner='Root explicit budgeted batch; consumer is offline',HTTP_requests=9,
                                          total_received_bytes=9794258,body_bytes=9571008,all_initial_and_final_hosts='hf-mirror.net',
                                          PAUSED_restored_by_root=True,full_shard_body_LFS_verified=False,
                                          identity_basis='Fixed revision tree/expanded API size+LFS/Xet identity, strong ETag, matching exact206 ranges and per-role SHA. Not a full5.36GB shard hash.'),
                         existing_target77=dict(static_roles=15,MoE_roles=1544,catalogue_sha256='37cb5928d417784b49ce6c5765c3859dbc7f3a7e56a2a347bb5041d98c03d0e7',
                                                source='Existing cached original77 static+all256-domain experts; loader revalidates them; no new expert transfer.'),
                         untied_head=dict(type='BF16[154880,6144]',sha256='864f488a0074d236062a4f24800940df7ba611dba76238d4f9f847d9659e11cd',source='Existing original Pro head mmap, once-only device upload; no new source copy.')),
    contracts=dict(ordinary_persistent_state=properties['ordinary_persistent_schema'],
                   transient_shared_selection='Actual I32 lease at real width1/2/3/4, guarded by position/epoch/visible count, forwarded unchanged across explicit75/76 sharing boundary and retained through observer/publication. Not padded, not inserted into fixed cross-token schema.',
                   initialization='No valid prefix atp0. Inactive index codes/scales/main rows carry nonfinite poison. Actual visible rows only feed score/MLA; exact untouched-byte checks and old Head leases remain valid.',
                   numerical='Existing independent original-byte local FP64 dot bounds and nonlinear/store references; full original74 key/query/weights every row; first target/selected expert and full154880 head checks, later existing sampled projection certificates plus whole-logit greedy checks. No blanket bitwise vendor claim.',
                   publication='StateDraft assembles actual7 resources and Frontier24, expected-base Head publish; stale/invalid index checks preserve prior Head; old readonly bytes survive; explicit final collect then zero versions/drafts/backing.'),
    limits=['Not complete78-layer generation; layer74 normalized input/query-rank and layer76 hidden/residual remain finite BF16 upstream fixtures conditioned on the actual prior pending ID.',
            'No layer75/76 mathematical body is executed; only its real shared-index carry contract is represented.',
            'Actual short contexts0..3 only; width2048 cold construction and existing warm consumer strict syntax, not a fresh2048-step execution.',
            'No whole-shard LFS body verification; only the explicitly acquired exact original ranges are present.',
            'No MTP rerun/acceptance change, new backend matrix, task-quality, throughput or measured physical-memory claim.'],
    prior_source_evidence=['docs/evidence/correctness/mtp-glm-pro-target-verifier-2026-10-23.json','docs/evidence/correctness/mtp-glm-pro-nextn-2026-10-23.json'],
    source_pins=load(D/'after-pins.json'),archive=dict(**pin(archive),members=len(manifest)+1,payload_manifest_members=len(manifest),
                                                   CRC_and_all_payload_SHA256_verified=True,excludes='All weights/bundle, EXE/OBJ/DLL/LIB and SDK copies'))
dump(public.with_suffix('.json'),result)
dump(D/'publication.json',dict(summary=pin(public.with_suffix('.json')),archive=pin(archive),members=len(manifest)+1,checks='CRC and every member SHA256 PASS'))
print(json.dumps(load(D/'publication.json'),indent=2))
