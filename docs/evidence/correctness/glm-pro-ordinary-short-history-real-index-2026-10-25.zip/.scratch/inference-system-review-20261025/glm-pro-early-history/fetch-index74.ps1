param([Parameter(Mandatory)][ValidateSet('metadata','payload')][string]$Stage)
$ErrorActionPreference = 'Stop'
$glmRoot = 'C:\public\project-hyle\hyle'
$glmMarker = Join-Path $glmRoot '.scratch/mtp-download-budget-20261023/PAUSED'
$glmHeld = Join-Path $PSScriptRoot ('download-paused-before-index74-'+$Stage)
if ((Resolve-Path -LiteralPath $PSScriptRoot).Path -ne (Join-Path $glmRoot '.scratch/inference-system-review-20261025/glm-pro-early-history')) { throw 'Unexpected GLM download task directory' }
if (!(Test-Path -LiteralPath $glmMarker -PathType Leaf) -or (Test-Path -LiteralPath $glmHeld)) { throw 'Expected one unchanged download pause marker' }
Move-Item -LiteralPath $glmMarker -Destination $glmHeld
try {
  & python (Join-Path $glmRoot '.scratch/mtp-download-budget-20261023/budget.py') run (Join-Path $PSScriptRoot 'fetch-index74.py') -- $Stage
  if ($LASTEXITCODE -ne 0) { throw "GLM index74 $Stage failed, exit $LASTEXITCODE; attempt preserved" }
} finally {
  if ((Test-Path -LiteralPath $glmMarker) -or !(Test-Path -LiteralPath $glmHeld -PathType Leaf)) { throw 'Download pause marker changed during GLM acquisition' }
  Move-Item -LiteralPath $glmHeld -Destination $glmMarker
}
