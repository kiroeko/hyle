"""Offline extraction only: no acquisition, downloader or budget mutation."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
AUDIT = ROOT / '.scratch/official-weight-audit.json'
OFFSET, LENGTH = 245119019, 38921892
with AUDIT.open('rb') as stream:
    stream.seek(OFFSET)
    raw = stream.read(LENGTH)
text = raw.decode('utf-8')
model, _ = json.JSONDecoder().raw_decode(text, text.index(':') + 2)
repository = 'zai-org/GLM-5.3'
revision = 'aca966e4e02791568aa6a4ced368624b3d897f42'
assert model['repository'] == repository and model['revision'] == revision
roles = [entry for entry in model['tensors']
         if entry['name'].startswith('model.layers.74.self_attn.indexer.')]
assert len(roles) == 7
file = 'model-00130-of-00141.safetensors'
assert all(entry['shard'] == file for entry in roles)
intervals = sorted(entry['data_offsets'] for entry in roles)
unions = []
for first, last in intervals:
    if unions and unions[-1][1] == first:
        unions[-1][1] = last
    else:
        unions.append([first, last])
total = sum(last - first for first, last in intervals)
assert total == 9571008 and len(unions) == 3
plan = dict(
    schema=1, repository=repository, revision=revision, file=file,
    source=dict(path=AUDIT.relative_to(ROOT).as_posix(), record_offset=OFFSET,
                record_bytes=LENGTH, record_sha256=hashlib.sha256(raw).hexdigest()),
    acquired_here=False, network_requests_here=0,
    metadata_status='Offline audit only; not an authenticated shard130 header/body receipt',
    roles=roles, selected_body_bytes=total,
    data_relative_half_open_unions=unions,
    missing=['fixed-revision file size and LFS identity',
             'original shard130 8-byte safetensors prefix and exact header',
             'matching 206 Range/ETag/whole size receipts and header data_base',
             'original seven role bytes and their per-role SHA256'],
    root_request_sequence=[
        dict(kind='metadata only', method='GET',
             url=f'https://hf-mirror.net/api/models/{repository}/revision/{revision}?blobs=true',
             verify='response sha equals fixed revision; retain only shard130 file size/LFS identity and receipt'),
        dict(kind='length prefix', method='GET',
             url=f'https://hf-mirror.net/{repository}/resolve/{revision}/{file}',
             absolute_inclusive_range=[0, 7],
             verify='206, exact8 bytes, Content-Range, fixed file size, original ETag/LFS identity'),
        dict(kind='exact header', method='GET',
             absolute_inclusive_range='[8, 7 + parsed_u64_header_length]',
             verify='same ETag/whole size, bounded header, exact seven names/types/shapes/relative offsets'),
        dict(kind='selected body only after header authentication', method='GET',
             absolute_half_open_ranges='add authenticated data_base to each data-relative union',
             bytes=total, verify='same fixed identity/Range; hash exact selected roles')],
    transport='Root budget.py/PAUSED ownership; HTTPS hf-mirror.net initial and redirects only; no HF/CAS fallback',
    boundary='NextN78 and Flash original-indexer weights must not substitute for original layer74')
(OUT / 'source-request-plan.json').write_bytes((json.dumps(plan, indent=2) + '\n').encode('utf-8'))
print(json.dumps(dict(roles=len(roles), bytes=total, unions=unions)))
