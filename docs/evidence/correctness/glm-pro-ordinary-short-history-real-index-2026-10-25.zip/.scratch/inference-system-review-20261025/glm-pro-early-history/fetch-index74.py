"""Exact fixed GLM74 index subset; invoke via retained budget.py run only."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import inspect
import json
import os
import sys
import urllib.request

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PLAN = HERE/'source-request-plan.json'
BUDGET = ROOT/'.scratch/mtp-download-budget-20261023/budget.py'
TRANSPORT = ROOT/'.scratch/mtp-metadata-offline-20261024/fetch-small-headers.py'
SCRIPT = Path(__file__).resolve().relative_to(ROOT).as_posix()
OUT = HERE/'index74-source'
REPOSITORY = 'zai-org/GLM-5.3'
REVISION = 'aca966e4e02791568aa6a4ced368624b3d897f42'
FILE = 'model-00130-of-00141.safetensors'
PINS = {
    PLAN: '0fc49f4efe09c3240b657f10d2b60e7aa4810e1b5cc7edc045a78a28f1127d3a',
    BUDGET: '24b008fb7a91f0eba34739cd4817fbf97b42ca7f435032d76cfb6e97ea398a17',
    TRANSPORT: '3dc89fb1efc369615d7a3132bd08b3aabcf125259498b5f8581cec83d559a7da'
}
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def run(stage):
    for path,digest in PINS.items():
        assert sha(path.read_bytes()) == digest, path.name
    spec = importlib.util.spec_from_file_location('retained_glm_range_transport',TRANSPORT)
    transport = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(transport)
    transport.SCRIPT = SCRIPT
    budget = transport.module()
    budget.require_enabled()
    guard = urllib.request.urlopen
    assert Path(guard.__code__.co_filename).resolve() == BUDGET.resolve()
    assert inspect.getclosurevars(guard).nonlocals.get('script') == SCRIPT
    plan = transport.parse_json(PLAN.read_bytes())
    assert (plan['repository'],plan['revision'],plan['file']) == (REPOSITORY,REVISION,FILE)
    assert len(plan['roles']) == 7 and plan['selected_body_bytes'] == 9571008
    row = dict(repository=REPOSITORY,revision=REVISION,file=FILE,
        metadata_url=f'https://hf-mirror.net/api/models/{REPOSITORY}/revision/{REVISION}?blobs=true',
        tree_metadata_url=f'https://hf-mirror.net/api/models/{REPOSITORY}/tree/{REVISION}?recursive=false&expand=false&limit=1000',
        uri=f'https://hf-mirror.net/{REPOSITORY}/resolve/{REVISION}/{FILE}')
    folder = OUT/stage
    folder.mkdir(parents=True,exist_ok=False)
    fetch = transport.Fetch(budget,row,timeout=45,receipt_dir=folder)
    try:
        if stage == 'metadata':
            expanded,receipt = fetch.get(0,transport.API_LIMIT-1)
            (folder/'expanded-api.json').write_bytes(expanded)
            tree,receipt = fetch.get(0,transport.API_LIMIT-1,metadata_kind='tree')
            (folder/'tree-api.json').write_bytes(tree)
            source = transport.crosscheck_tree_identity(row,expanded,tree)
            preamble,receipt = fetch.get(0,7,source=source)
            (folder/'prefix.bin').write_bytes(preamble)
            length = transport.header_length(preamble,source['size'])
            raw,receipt = fetch.get(8,7+length,source=source)
            (folder/'header.json').write_bytes(raw)
            facts = transport.parse_header(raw,source['size'])
            for role in plan['roles']:
                entry = facts['all_physical_tensors'][role['name']]
                assert all(entry[key] == role[key] for key in ('dtype','shape','data_offsets')),role['name']
            complete = dict(status='AUTHENTICATED_METADATA_ONLY',source=source,data_base=8+length,
                header_bytes=length,header_sha256=sha(raw),roles=plan['roles'],
                body_bytes_acquired=0,body_bytes_planned=9571008,HTTP_requests=4,
                full_source_LFS_verified=False,original_file_uri=row['uri'])
        else:
            meta = transport.parse_json((OUT/'metadata/complete.json').read_bytes())
            source = transport.crosscheck_tree_identity(row,(OUT/'metadata/expanded-api.json').read_bytes(),(OUT/'metadata/tree-api.json').read_bytes())
            assert source == meta['source']
            header = (OUT/'metadata/header.json').read_bytes()
            assert sha(header) == meta['header_sha256']
            facts = transport.parse_header(header,source['size'])
            assert meta['data_base'] == 8+len(header)
            for role in plan['roles']:
                assert all(facts['all_physical_tensors'][role['name']][key] == role[key] for key in ('dtype','shape','data_offsets'))
            parts = [];bundles = [];written = 0
            body = folder/'roles.bin'
            with body.open('xb') as output:
                for begin,end in plan['data_relative_half_open_unions']:
                    bundle_offset = written
                    for first in range(begin,end,transport.HEADER_LIMIT):
                        last = min(first+transport.HEADER_LIMIT,end)
                        absolute = meta['data_base']+first
                        raw,receipt = fetch.get(absolute,meta['data_base']+last-1,source=source)
                        assert len(raw) == last-first
                        output.write(raw);output.flush();os.fsync(output.fileno())
                        parts.append(dict(data_relative_range=[first,last],bundle_offset=written,bytes=len(raw),sha256=sha(raw),response=receipt))
                        written += len(raw)
                        transport.save(folder/'verified-parts.json',dict(complete=False,bytes=written,parts=parts))
                    bundles.append(dict(data_relative_range=[begin,end],bundle_offset=bundle_offset))
            assert written == 9571008
            roles = []
            with body.open('rb') as source_file:
                for original in plan['roles']:
                    begin,end = original['data_offsets']
                    union = next(item for item in bundles if item['data_relative_range'][0] <= begin and end <= item['data_relative_range'][1])
                    offset = union['bundle_offset']+begin-union['data_relative_range'][0]
                    source_file.seek(offset);raw = source_file.read(end-begin)
                    assert len(raw) == end-begin
                    roles.append(dict(original,source_path=body.relative_to(ROOT).as_posix(),offset=offset,bytes=len(raw),sha256=sha(raw)))
            complete = dict(status='ACQUIRED_EXACT_ORIGINAL_SEVEN_INDEX74_ROLES',repository=REPOSITORY,revision=REVISION,
                source=source,data_base=meta['data_base'],original_file_uri=row['uri'],roles=roles,
                payload_bytes=written,HTTP_requests=len(parts),parts=parts,
                bundle_sha256=sha(body.read_bytes()),full_source_LFS_verified=False,
                encoding_changed=False,whole_layer_or_expert_bank_downloaded=False)
        transport.save(folder/'complete.json',complete)
        print(json.dumps(dict(status=complete['status'],receipt=(folder/'complete.json').relative_to(ROOT).as_posix(),
                             body_bytes=complete.get('payload_bytes',0),HTTP_requests=complete['HTTP_requests']),indent=2))
    except BaseException as error:
        transport.save(folder/'failed.json',dict(status='FAILED_PRESERVED',error_type=type(error).__name__,error=str(error),automatic_retries=0))
        raise
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['metadata','payload'])
    run(parser.parse_args().stage)
