"""One finite CUDA leaf test and original previously failing tiny consumer.

No build, download, server, retry, or performance measurement.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

W = Path(__file__).resolve().parent
R = W.parents[1]
mode = sys.argv[1]
assert mode in ('test', 'tiny')
folder = W/('test' if mode == 'test' else 'case')
ready_path = folder/'ready.json'
ready = json.loads(ready_path.read_text())
runtime = json.loads(Path(ready['runtime']['path']).read_text())

def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=sha)

for field in ('image', 'runtime'):
    assert pin(ready[field]['path']) == ready[field]
out = folder/('run1' if mode == 'test' else 'tiny1')
assert not out.exists(), 'Keep each real attempt; no implicit retry'
out.mkdir()
command = [ready['image']['path']]
fixture = None
if mode == 'test':
    command += ['--gtest_filter=CudaCausalConv.*', '--gtest_output=xml:'+str(out/'result.xml')]
else:
    assert json.loads((W/'test/run1/process.json').read_text())['exit'] == 0
    fixture = R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    command.append(str(fixture))
environment = os.environ.copy()
environment.update(runtime.get('configured_flags', {}))
environment.update(PATH=str(folder/'link')+';'+runtime['PATH'],
    HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
record = dict(command=command, image=ready['image'], ready=pin(ready_path),
    runtime=ready['runtime'], fixture_manifest=pin(fixture/'weights.tsv') if fixture else None,
    cwd=str(R), timeout_seconds=90)
(out/'command.json').write_text(json.dumps(record, indent=2)+'\n')
start = time.perf_counter()
with (out/'stdout.log').open('xb') as stdout, (out/'stderr.log').open('xb') as stderr:
    process = subprocess.Popen(command, env=environment, cwd=R, stdout=stdout,
        stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    (out/'running.json').write_text(json.dumps(dict(pid=process.pid, command=command), indent=2)+'\n')
    print('CUDA_CONV_NATIVE_PID', process.pid, mode, flush=True)
    timed_out = False
    try:
        code = process.wait(timeout=90)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        code = process.wait(timeout=10)
record.update(pid=process.pid, exit=code, timeout=timed_out,
    seconds=time.perf_counter()-start, performance_claim=False)
(out/'process.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record), flush=True)
assert code == 0 and not timed_out, 'Preserve actual failure'
if mode == 'tiny':
    result = json.loads((out/'stdout.log').read_text(encoding='utf8'))
    assert result['status'] == 'PASS' and result['backend'] == 'cuda'
    (out/'summary.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
