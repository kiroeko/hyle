from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
scratch = (R/'.scratch').resolve()
paths = [R/'.scratch/inference-host-image-20261026/product2/link/hyle.exe',
    R/'.scratch/inference-host-image-20261026/cuda4/link/host-image-consumer.exe',
    W/'test/link/causal-conv-test.exe']
kept = [W/'cli/link/hyle.exe', W/'case/link/host-image-consumer.exe',
    R/'.scratch/inference-host-image-20261026/cpu3/link/host-image-consumer.exe',
    R/'.scratch/inference-host-image-20261026/product2/compile/unit.obj',
    R/'.scratch/inference-host-image-20261026/cuda4/compile/unit.obj']
assert all(path.is_file() for path in kept)
targets = []
for path in paths:
    path = path.resolve()
    assert path.is_relative_to(scratch) and path not in kept and path.is_file()
    with path.open('rb') as stream: sha = hashlib.file_digest(stream,'sha256').hexdigest()
    targets.append(dict(path=str(path), bytes=path.stat().st_size, sha256=sha))
report = dict(root=str(scratch), targets=targets, keep=[str(path) for path in kept],
    total_logical_bytes=sum(row['bytes'] for row in targets))
(W/'cleanup-targets.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(files=len(targets),bytes=report['total_logical_bytes'])))
