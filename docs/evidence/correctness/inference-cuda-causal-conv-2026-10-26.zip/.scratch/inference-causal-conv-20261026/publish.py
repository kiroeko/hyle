from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
D = R/'docs/evidence/correctness'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def pin(path):
    path = Path(path)
    with path.open('rb') as stream: digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path.relative_to(R)).replace('\\','/'), bytes=path.stat().st_size, sha256=digest)

build = read(W/'ready.json')
test = read(W/'test/run1/process.json')
tiny = read(W/'case/tiny1/process.json')
result = read(W/'case/tiny1/summary.json')
xml = ET.parse(W/'test/run1/result.xml').getroot()
assert xml.attrib['tests'] == '3' and xml.attrib['failures'] == '0' and xml.attrib['disabled'] == '0'
assert test['exit'] == tiny['exit'] == 0 and not test['timeout'] and not tiny['timeout']
sources = [
    'src/compute_provider_cuda/causal_conv_kernel.h', 'src/compute_provider_cuda/causal_conv_kernel.cu',
    'src/compute_provider_cuda/causal_conv_provider.h', 'src/compute_provider_cuda/causal_conv_provider.cc',
    'src/compute_provider_cuda/cuda_provider.cc', 'src/compute_provider_cuda/CMakeLists.txt',
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'tests/compute_route_cuda/causal_conv_test.cc', 'tests/compute_route_cuda/CMakeLists.txt']
records = [W/name for name in ('build.py', 'run.py', 'publish.py', 'plan.json', 'ready.json', 'source-freeze.json', 'preparation.json',
    'prepare-cleanup.py', 'cleanup-targets.json', 'cleanup-result.json')]
for folder in ('compile/kernel','compile/provider','compile/registration','compile/ggml-supports','compile/test',
        'cli/link','case/link','test/link','test/run1','case/tiny1'):
    records.extend(path for path in (W/folder).iterdir() if path.suffix in ('.json','.log','.xml'))
records.extend(W/name for name in ('cli/ready.json','case/ready.json','test/ready.json','case/runtime.json'))
archive = D/'inference-cuda-causal-conv-2026-10-26.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(set([R/source for source in sources]+records)):
        output.write(path, path.relative_to(R).as_posix())
report = dict(date='2026-10-26', status='BOUNDED_CUDA_CORRECTNESS_PASSED', baseline_commit='b83710410',
    hardware=dict(gpu='NVIDIA GeForce RTX 4070', reported_memory_MiB=12282, driver='617.14',
        query='nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader'),
    changes=[
        'Add dense F32 causal conv to existing native CUDA provider, one kernel, shared queue and original Completion retirement.',
        'ggml proposal declines channels not divisible by 128 and K outside 3/4/5/9/15; keep existing default preference and admitted ggml shapes.',
        'No model/public API/new executor/route policy or F16/BF16 support changes.'],
    sources=[pin(R/source) for source in sources], archive=pin(archive),
    cleanup=dict(record=pin(W/'cleanup-result.json'), files=3, logical_bytes=422015488,
        scope='Removed superseded CUDA CLI/HostImage images and the finished standalone leaf-test image; retained current CLI/case, reusable objects and all SDK/model caches.'),
    build=dict(product_TUs=4, test_TUs=1, first_attempts_passed=True,
        reused_Model_weights_report_SDK=True, archive_rewrites=0,
        record=pin(W/'ready.json'), images={name:row['image'] for name,row in build['artifacts'].items()},
        note='Current CLI linked only. HostImage CUDA Model OBJ and exact CUDA feature closure reused.'),
    tests=dict(record=pin(W/'test/run1/process.json'), xml=pin(W/'test/run1/result.xml'),
        passed=3, failed=0, skipped=0,
        numerical_shapes_B_W_C_K=[[2,6,192,4],[2,7,7,2],[2,1,1,1]],
        numerical_scope='Each shape uses one Prepared/Invocation with two distinct complete input/weight/output allocations; exact bits against ordered host std::fma.',
        default_routes=['C128 K4 ggml','C192 K4 native','C7 K2 native','C128 K2 native'],
        precision_boundary='Native F16/BF16 requests remain unsupported.',
        runtime_facts='Prepared replay, zero workspace/private bytes, capture-compatible and concurrent; metadata check only for capture/concurrency, no concurrent stress or CUDA Graph capture test.'),
    model_consumer=dict(record=pin(W/'case/tiny1/process.json'), result=result,
        scope='The unchanged previously failing C192 GA+MTP fixture executes through original Compute/Graph and HostImage consumer; ordinary and MTP sequential.',
        manifest=tiny['fixture_manifest'],
        checks='Complete initialized bytes and metadata, same-shape continuation, historical pending/RNG, old alias, image budgets, real allocation-failure cleanup/retry, model-independent image lifetime.'),
    limitations=[
        'Tiny fixture is untrained component geometry; no full task quality claim.',
        'This consumer covers lag0, without prior_hidden; lag1/prior remains separate work.',
        'Default route test proves selected prepared provider; no instrumentation claim about discovery timing.',
        'No throughput, end-to-end speedup, Apple/Vulkan or F16/BF16 CUDA qualification. Existing formal speed tables unchanged.',
        'Build records rely on retained cache closure; archive contains source/commands/results, not SDK binaries or weights.'])
(D/'inference-cuda-causal-conv-2026-10-26.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n', encoding='utf8')
print(json.dumps(dict(evidence=pin(D/'inference-cuda-causal-conv-2026-10-26.json'),archive=pin(archive))))
