$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath($PSScriptRoot)
$batch = [IO.Path]::GetFullPath((Join-Path $workspace '.scratch/inference-stage-handoff-20261030'))
$boundary = [IO.Path]::GetFullPath((Join-Path $batch 'bin'))
$manifest = Get-Content -LiteralPath (Join-Path $batch 'cleanup-targets.json') -Raw | ConvertFrom-Json
if ($manifest.boundary -cne $boundary -or -not $batch.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected cleanup boundary' }
$targets = @($manifest.targets)
if ($targets.Count -ne 13) { throw 'Unexpected target count' }
$totalBytes = [long]0
foreach ($pin in $targets) {
  $target = [IO.Path]::GetFullPath($pin.path)
  if ([IO.Path]::GetDirectoryName($target) -cne $boundary) { throw ('Target escaped flat batch image boundary: ' + $target) }
  if ([IO.Path]::GetExtension($target).ToLowerInvariant() -notin @('.exe', '.dll', '.lib', '.exp')) { throw ('Unexpected image extension: ' + $target) }
  $item = Get-Item -LiteralPath $target
  if ($item.PSIsContainer -or $item.Length -ne $pin.bytes -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $pin.sha256) { throw ('Changed target: ' + $target) }
  $totalBytes += $item.Length
}
foreach ($pin in $targets) { Remove-Item -LiteralPath $pin.path -Force }
$report = @{ status='REMOVED_EXACT_FLAT_BATCH_IMAGES'; files=$targets.Count; bytes=$totalBytes; boundary=$boundary; retained='Original SDK objects, current consumer objects, source inputs, commands and reports' }
$report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $batch 'cleanup-report.json') -Encoding utf8
$report | Format-List
