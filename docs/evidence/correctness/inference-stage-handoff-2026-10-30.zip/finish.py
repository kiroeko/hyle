"""Record complete original-stage handoff checks without performance runs."""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items()
                if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list):
        return [stable(v) for v in value]
    return value


def original_qwen_actions():
    old = (W / 'baseline/engine/models/qwen35/main.cc').read_text(encoding='utf-8')
    current = (R / 'engine/models/qwen35/main.cc').read_text(encoding='utf-8')
    origin = old.index('  void finish_selected_evaluations(')
    before = old.index('      check(step.execution.wait_success());', origin)
    old_observe = old.index('      // Trace storage must be pinned', before)
    old_middle = old.index('      // Attest the original append success', old_observe)
    old_complete = old.index('      for (std::size_t bank_index = 0;', old_middle)
    old_end = old.index('      check(step.execution.release_consumers(phase.state_resource_ports));', old_complete)
    old_after = old_end + len('      check(step.execution.release_consumers(phase.state_resource_ports));\n')
    start = current.index('      const auto append_banks = draft_bank +', current.index('  void finish_selected_evaluations('))
    observe = current.index('            // Trace storage must be pinned', start)
    observe_end = current.index('            return hyle::Status::Ok();\n          },', observe)
    complete = current.index('            for (std::size_t bank_index = 0;', observe_end)
    complete_end = current.index('            return hyle::Status::Ok();\n          }));', complete)
    after = complete_end + len('            return hyle::Status::Ok();\n          }));\n')
    def dedent(text):
        return ''.join(line[6:] if line.strip() else line for line in text.splitlines(keepends=True))
    assert dedent(current[observe:observe_end]) == old[old_observe:old_middle]
    assert dedent(current[complete:complete_end]) == old[old_complete:old_end]
    assert current[:start] == old[:before] and current[after:] == old[old_after:]
    return dict(observe_original_lines=len(old[old_observe:old_middle].splitlines()),
        complete_original_lines=len(old[old_complete:old_end].splitlines()),
        model_actions_exact=True, remainder_of_main_exact=True,
        baseline=pin(W / 'baseline/engine/models/qwen35/main.cc'))


def prepare():
    p = read(W / 'plan.json')
    reports = {name: read(W / 'runs' / name / 'attempt1/report.json') for name in p['cases']}
    assert len([x for x in reports.values() if 'tests' not in x]) == 12
    assert reports['kimi-cuda']['tests'] == 7 and reports['kimi-cuda']['failures'] == reports['kimi-cuda']['skipped'] == 0
    comparisons = []
    for name in ('single-auto', 'recursive', 'threshold', 'restore', 'natural', 'ordinary',
                 'batch', 'carrier_cpu', 'carrier_cuda', 'packet_cpu', 'packet_cuda'):
        anchor = b.OLD / 'runs' / name / 'attempt1/report.json'
        before, after = stable(read(anchor)), stable(reports[name])
        additions = {}
        if name.startswith('carrier_'):
            assert before['native_submissions'] == 2
            additions = {k: v for k, v in after.items() if k not in before}
            if name == 'carrier_cuda':
                assert after['native_submissions'] == after['carriers'] == 5
                before['native_submissions'] = 5
                before['carriers'] = 5
            equal = before == {k: after[k] for k in before}
        else:
            equal = before == after
        assert equal, name
        comparisons.append(dict(case=name, anchor=pin(anchor), original_non_timing_fields_equal=equal,
            expected_additional_native_submissions=3 if name == 'carrier_cuda' else 0,
            additional_facts=additions))
    consumers = {}
    for name in p['consumers']:
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        consumers[name] = dict(receipt=pin(path), object=receipt['object'])
    for item in p['retained']:
        exact(item)
    assert len(p['retained']) == 227 and not p['sdk_dependency_audit']['matches']
    save(W / 'analysis.json', dict(status='PASS_FINITE_COMPLETE_STAGE_HANDOFF_CHECKS',
        gtests=7, finite_consumer_processes=12, failures=0, skipped=0,
        cases={name: pin(W / 'runs' / name / 'attempt1/report.json') for name in reports},
        original_non_timing_comparisons=comparisons, mechanical_qwen_audit=original_qwen_actions(),
        successful_consumer_CXX_TUs=4, retained_SDK_engine_objects=227,
        orchestration_note='A link and run receipt lookup was attempted before the natural compile handle completed; both rejected before launching linker or native consumer. The same live compiler handle was polled to exit0, without restart, then linking/runs succeeded.',
        SDK_CXX=0, NVCC=0, downloads=0, performance_experiments=0, performance_claim=False,
        SDK_dependency_records=len(p['sdk_dependency_audit']['inspected']),
        unavailable_dependency_records=len(p['sdk_dependency_audit']['unavailable']),
        limits=[
            'Only a complete successful Graph-stage handoff is shared, not complete model generation or all model adaptation.',
            'Qwen ordinary/MTP state math, acceptance, private repair, Head/RNG/ledger and failure retirement stay model-owned.',
            'Kimi original numerical component cases pass; not a full Kimi engine or full large-model run.',
            'No GLM full-step adapter, Apple/Vulkan execution, full throughput/peer/memory window or native fault injection this batch.',
            'An original Completion/Source must come from the original episode submit; nonempty metadata alone is not success authority.'
        ]))
    base = read(p['base']['path'])
    base.update(schema='hyle.stage-handoff.current-link-base.v1', base=p['base'],
        current_consumers=consumers, previous_consumer=consumers['cli']['receipt'],
        consumer_source=pin(p['consumers']['cli']['source']), compile=p['consumers']['cli']['compile'],
        link=[consumers['cli']['object']['path'] if key(arg) == key(p['original_consumer']) else arg
              for arg in p['original_link']])
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe', '.dll', '.lib', '.exp')
        targets.append(pin(path))
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    (W / 'product.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', 'engine', 'tests'], cwd=R))
    print('PASS7 tests+12 processes; model actions exact; image cleanup targets', len(targets))


def finish():
    p, a = read(W / 'plan.json'), read(W / 'analysis.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'REMOVED_EXACT_FLAT_BATCH_IMAGES'
    shutil.copyfile(R / 'test.ps1', W / 'cleanup.ps1')
    changed = subprocess.check_output(['git', 'diff', '--name-only', '--', 'engine', 'tests'], cwd=R, text=True).splitlines()
    out = R / 'docs/evidence/correctness/inference-stage-handoff-2026-10-30.json'
    save(out, dict(schema='hyle.correctness.stage-handoff.v1', date='2026-10-30',
        status='ORIGINAL_COMPLETE_STAGE_HANDOFF_SHARED_AND_FINITE_CHECKED', base_commit=p['base_commit'],
        contract=dict(
            protocol='Original whole-Graph wait; nonthrowing native-success observation; actual carrier/run check; OutputSource detach; synchronous model output observation; own SubmissionSource detach; original selected Append and Store takes; model interpretation/repair; original consumer withdrawal.',
            authority='No new owner, executor, callback table, queue, permission or transaction. Model callbacks are synchronous static calls; original fallible model work still allocates or throws as before.',
            failure='Partial completion is not retried. Remaining transactions and original Source/predecessor owners stay for the same original recover. Head/RNG/ledger publication and original reset policy remain outside.',
            intermediate_source='A stage with both incoming and outgoing Sources closes its own producer export before releasing its predecessor binding; otherwise the original Graph result pin can reject withdrawal.',
            accounting='Kimi native success count remains directly after successful original wait, before any output detach can fail.'),
        sources=[pin(R / x) for x in changed], diff=pin(W / 'product.diff'), results=a,
        current_link_base=pin(W / 'model-link-base.json'),
        cleanup=dict(script=pin(R / 'test.ps1'), archived_script=pin(W / 'cleanup.ps1'),
                     manifest=pin(W / 'cleanup-targets.json'), result=cleanup),
        evidence_archive=out.with_suffix('.zip').name))
    with zipfile.ZipFile(out.with_suffix('.zip'), 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or any(x in ('bin', '__pycache__', 'ordinary-input') for x in path.relative_to(W).parts):
                continue
            if path.suffix.lower() in ('.json', '.py', '.ps1', '.cc', '.h', '.diff', '.log', '.xml'):
                z.write(path, path.relative_to(W).as_posix())
    with zipfile.ZipFile(out.with_suffix('.zip')) as z:
        assert z.testzip() is None
    print('Evidence written; archive checked', pin(out.with_suffix('.zip'))['bytes'])


if __name__ == '__main__':
    {'prepare': prepare, 'finish': finish}[sys.argv[1]]()
