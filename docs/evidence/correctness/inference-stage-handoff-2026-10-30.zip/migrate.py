"""Place actual Qwen stage actions inside the existing episode protocol."""
from pathlib import Path

root = Path(__file__).resolve().parents[2]
path = root / 'engine/models/qwen35/main.cc'
source = path.read_text(encoding='utf-8')
start = source.index('      check(step.execution.wait_success());', source.index('  void finish_selected_evaluations('))
observation_start = source.index('      // Trace storage must be pinned', start)
middle = source.index('      // Attest the original append success', observation_start)
resource_start = source.index('      for (std::size_t bank_index = 0; bank_index < phase.state_banks.size();', middle)
end = source.index('      check(step.execution.release_consumers(phase.state_resource_ports));', resource_start)
after = end + len('      check(step.execution.release_consumers(phase.state_resource_ports));\n')
observation = source[observation_start:middle]
resources = source[resource_start:end]
replacement = '''      const auto append_banks = draft_bank + (has_mtp(phase.family->role) ? 2u : 0u);
      auto &transactions = phase.slots[step.state_slot].transactions;
      check(step.execution.finish_success(0, append_banks, phase.state_resource_ports,
          []() noexcept {},
          [&]() -> hyle::Status {
'''
replacement += ''.join('      ' + line if line.strip() else line for line in observation.splitlines(keepends=True))
replacement += '''            return hyle::Status::Ok();
          },
          [&]() -> hyle::Status {
'''
replacement += ''.join('      ' + line if line.strip() else line for line in resources.splitlines(keepends=True))
replacement += '''            return hyle::Status::Ok();
          }));
'''
source = source[:start] + replacement + source[after:]
path.write_text(source, encoding='utf-8', newline='\n')
print('Moved original output observation and returned-resource interpretation; publication/catches untouched.')
