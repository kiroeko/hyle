"""Offline compact evidence. No build, native run, environment dump or cleanup."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import math
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
A = W / 'attempt2'
DEST = R / 'docs/evidence/correctness/inference-conditional-verify-2026-10-29'
spec = importlib.util.spec_from_file_location('conditional_verify_evidence_build', A / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
CASES = ('verify-cpu', 'verify-cuda', 'conditional-cpu', 'conditional-cuda', 'natural-cuda')
FORBIDDEN_NAMES = {'environment.json', 'env.json'}
FORBIDDEN_SUFFIXES = {'.obj', '.lib', '.dll', '.exe', '.pdb', '.bin', '.safetensors', '.gguf', '.map', '.exp'}


def terminal(directory):
    process = t.read(directory / 'process.json')
    assert process['state'] == 'TERMINAL', (directory, process)
    return process


def successful(process):
    return process['exit'] == 0 and not process['timed_out']


def check_states(rows):
    assert isinstance(rows, list) and rows
    for row in rows:
        assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
        assert row['payloads_byte_equal'] == (not row['differences'])
        for diff in row['differences']:
            assert diff['role'] == 3 and diff['nonfinite_differences'] == 0
            assert math.isfinite(diff['maximum_absolute']) and 0 <= diff['maximum_absolute'] <= 3e-6


def report_facts(name, report):
    backend = name.rsplit('-', 1)[1]
    assert report['status'] == 'PASS' and report['backend'] == backend and report['models'] == 1
    assert report['quality_claim'] is False and report['performance_claim'] is False and report['final_versions'] == 0
    if name.startswith('verify-'):
        b.parse_verify(report, backend)  # Pure report checks, no run or filesystem writes.
        return {key: report[key] for key in ('conditional_rows', 'target_submissions', 'actual_target_F32_oracles',
            'actual_private_q_rows', 'accepted_target_rows', 'RNG_reserved_draws', 'numeric_failure_participant',
            'complete_target_draft_state', 'same_q_retry', 'metadata_and_role_key_zero_target',
            'numeric_failure_retired', 'immutable_owner_survives_caller', 'old_checkpoints_unchanged',
            'host_owner_move_prefix', 'natural_conditional_supplier', 'final_versions')}
    if name.startswith('conditional-'):
        assert report['case'] == 'conditional-logits' and report['conditional_rows'] == report['configurations'] == 3
        assert report['actual_private_q_rows'] == 2 and report['conditional_metadata_failures'] == 4
        assert report['synthetic_untrained'] is True
        for key in ('finite_accept_reject_residual_bonus', 'EOS_quota', 'zero_proposal_bonus', 'same_q_leases',
                    'head_rng_checkpoint_unchanged', 'nonfirst_descriptor_zero_native', 'nonfirst_numeric_retired',
                    'same_terminal_retry', 'conditional_history_counts', 'readonly_C0_unchanged', 'greedy_conditional',
                    'actual_conditional_proposer', 'proposal_preflight_preserves_q', 'EOS_shortened_prefix'):
            assert report[key] is True, key
        assert report['full_target_publication'] is False and report['natural_conditional_supplier'] is False
        return {key: report[key] for key in ('configurations', 'conditional_rows', 'actual_private_q_rows',
            'conditional_metadata_failures', 'conditional_history_counts', 'greedy_conditional',
            'full_target_publication', 'natural_conditional_supplier', 'final_versions')}
    assert name == 'natural-cuda' and report['case'] == 'mtp-natural-relay'
    assert report['natural_RequestLoop'] is True and report['controlled_acceptance'] is False
    assert (report['resident_capacity'], report['state_slots'], report['hidden_slots']) == (1, 5, 6)
    assert report['outputs'] == report['output_limit'] == len(report['ids']) == 40
    for key in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
        assert report[key] is True, key
    for key in ('successor_submissions', 'successor_publications', 'pending_pairs_before_A_publish',
                'deferred_waves', 'reserved_two_grants'):
        assert report[key] > 0, key
    assert len(report['state_checks']) == 1
    check_states(report['state_checks'])
    return {key: report[key] for key in ('outputs', 'ledger_records', 'resident_capacity', 'state_slots', 'hidden_slots',
        'successor_submissions', 'successor_publications', 'successor_discards', 'successor_refusals',
        'accepted_drafts', 'rejected_drafts', 'natural_RequestLoop', 'controlled_acceptance', 'final_versions')}


def main():
    plan = b.validate()
    frozen_path = A / 'source-freeze.json'; frozen = t.read(frozen_path)
    compiled = t.read(A / 'compile/tiny/compiled.json'); ready = t.read(A / 'ready-tiny.json')
    cxx = terminal(A / 'logs/compile-tiny'); link = terminal(A / 'logs/link-tiny')
    assert successful(cxx) and successful(link), 'Archive only this actual linked image; retain failed attempts separately.'
    assert compiled['process'] == cxx and ready['process'] == link and ready['compiled'] == compiled
    assert t.command(A / 'logs/compile-tiny/command.json') == plan['units']['tiny']['compile']
    assert t.command(A / 'logs/link-tiny/command.json') == plan['units']['tiny']['link']
    assert ready['source_freeze'] == t.pin(frozen_path)
    t.exact(ready['image']); t.exact(compiled['object'])
    sdk = {t.key(row['path']): row for row in plan['retained']}
    assert len(sdk) == 227
    assert collections.Counter(Path(row['path']).suffix.lower() for row in sdk.values()) == {'.obj': 202, '.lib': 25}
    assert ready['inputs'] == plan['retained'] + [compiled['object']]
    assert len({t.key(row['path']) for row in ready['inputs']}) == 228
    source_index = {t.key(row['path']): row for row in frozen}; assert len(source_index) == len(frozen)
    for row in compiled['project_dependencies']: assert source_index[t.key(row['path'])] == row
    assert [row for row in compiled['actual_dependencies'] if t.project(row['path'])] == compiled['project_dependencies']
    first_plan = t.read(W / 'plan.json')
    first_frozen = t.read(W / 'source-freeze.json')
    first_cxx = terminal(W / 'logs/compile-tiny')
    assert first_cxx['exit'] == 2 and not first_cxx['timed_out']
    assert t.command(W / 'logs/compile-tiny/command.json') == first_plan['units']['tiny']['compile']
    first_index = {t.key(row['path']): row for row in first_frozen}
    changed_after_failure = [row for row in first_frozen if source_index[t.key(row['path'])] != row]
    assert len(changed_after_failure) == 1
    failed_header = W / 'attempt1-sources/engine/inference/logits_inputs.h'
    assert changed_after_failure[0] == first_index[t.key(R / 'engine/inference/logits_inputs.h')]
    assert (t.pin(failed_header)['bytes'], t.pin(failed_header)['sha256']) == (changed_after_failure[0]['bytes'], changed_after_failure[0]['sha256'])
    for row in first_frozen:
        if row != changed_after_failure[0]: t.exact(row)
    for row in first_plan['helpers']: t.exact(row)
    sdk_review = t.read(plan['sdk_engine_dependencies']['path'])
    assert len(sdk_review['inspected']) + len(sdk_review['unavailable']) == 202
    for consumer in sdk_review['engine_consumers']:
        t.exact(consumer['original_receipt'])
        for identity in consumer['source_identities']: t.exact(identity)
    runs = {}; issues = []; states = []
    for name in CASES:
        out = A / 'runs' / name; process = terminal(out)
        _, backend, flag = b.b.CASES[name]
        entry = plan['fixtures']['natural' if name == 'natural-cuda' else 'conditional']
        assert t.command(out / 'command.json') == [ready['image']['path'], '--' + backend, entry['directory'], flag]
        raw = []
        for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines():
            if line.startswith('{'):
                try: raw.append(json.loads(line))
                except json.JSONDecodeError: pass
        report_path = out / 'report.json'; report = t.read(report_path) if report_path.is_file() else None
        problems = []; facts = None
        if not successful(process): problems.append('Native process did not exit successfully.')
        if report is None: problems.append('No parsed report; original stdout/stderr remain authoritative.')
        else:
            if raw != [report]: problems.append('Parsed report differs from the original one-record JSON stdout.')
            try: facts = report_facts(name, report)
            except (AssertionError, KeyError, TypeError, ValueError) as error:
                problems.append('Report check failed: ' + repr(error))
        passed = not problems
        if passed and report.get('state_checks'): states.extend(report['state_checks'])
        issues.extend(name + ': ' + problem for problem in problems)
        runs[name] = dict(process=process, verified_finite_pass=passed, problems=problems, facts=facts,
            report=(dict(member='records/attempt2/runs/' + name + '/report.json', **t.pin(report_path)) if report is not None else None),
            logs_prefix='records/attempt2/runs/' + name + '/')
    members = {}
    def add(path, name, expected=None):
        path = Path(path)
        assert path.name.lower() not in FORBIDDEN_NAMES and path.suffix.lower() not in FORBIDDEN_SUFFIXES
        body = path.read_bytes()
        if expected: assert (len(body), hashlib.sha256(body).hexdigest()) == (expected['bytes'], expected['sha256'])
        assert name not in members or members[name] == body
        members[name] = body
    for row in frozen:
        path = Path(row['path']); assert t.project(path) and path.is_relative_to(R)
        add(path, 'source/' + path.relative_to(R).as_posix(), row)
    for path in sorted((W / 'before').rglob('*')):
        if path.is_file():
            assert path.suffix.lower() in ('.h', '.cc', '.md')
            add(path, 'before/' + path.relative_to(W / 'before').as_posix())
    for rel in ('plan.json', 'source-freeze.json', 'ready-tiny.json', 'compile/tiny/compiled.json',
                'compile/tiny/dependencies.json', 'sdk-engine-dependencies.json'):
        add(A / rel, 'records/attempt2/' + rel)
    for rel in ('plan.json', 'source-freeze.json', 'sdk-engine-dependencies.json', 'compile/tiny/dependencies.json'):
        add(W / rel, 'records/attempt1/' + rel)
    for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log'):
        add(W / 'logs/compile-tiny' / filename, 'records/attempt1/logs/compile-tiny/' + filename)
    add(failed_header, 'historical-source/attempt1/engine/inference/logits_inputs.h')
    for row in first_plan['helpers']:
        add(row['path'], 'helpers/' + row['sha256'] + '/' + Path(row['path']).name, row)
    for directory in (A / 'logs/compile-tiny', A / 'logs/link-tiny', *(A / 'runs' / name for name in CASES)):
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'report.json', 'host-report.json', 'checks.json'):
            path = directory / filename
            if path.is_file(): add(path, 'records/' + path.relative_to(W).as_posix())
    for name, entry in plan['fixtures'].items():
        for field in ('manifest', 'prompt'):
            row = entry[field]; add(row['path'], 'fixtures/' + name + '/' + Path(row['path']).name, row)
    for row in plan['helpers']:
        add(row['path'], 'helpers/' + row['sha256'] + '/' + Path(row['path']).name, row)
    add(__file__, 'helpers/package.py')
    add(W / 'next-base.py', 'helpers/next-base.py')
    for field in ('base', 'previous_consumer'):
        row = plan[field]; add(row['path'], 'referenced/' + row['sha256'] + '/' + Path(row['path']).name, row)
    for consumer in sdk_review['engine_consumers']:
        row = consumer['original_receipt']
        add(row['path'], 'referenced/sdk-engine/' + row['sha256'] + '/' + Path(row['path']).name, row)
    manifest = dict(schema='hyle.inference-conditional-verify.archive.v1', source_freeze=t.pin(frozen_path),
        frozen_project_files=len(frozen), actual_compiled_project_files=len(compiled['project_dependencies']),
        members={name: dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest()) for name, body in sorted(members.items())})
    members['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    archive = DEST.with_suffix('.zip'); DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, body in sorted(members.items()): output.writestr(name, body)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist()) == set(members)
        parsed_manifest = json.loads(check.read('manifest.json'))
        assert parsed_manifest == manifest
        for name, body in members.items(): assert check.read(name) == body, name
    changed = ('engine/inference/logits_inputs.h', 'engine/models/qwen35/main.cc',
               'tests/tools/qwen_conditional_verify_case.h', 'tests/tools/qwen_host_image_test.cc')
    status = 'PASS_FINITE_CONDITIONAL_VERIFY' if not issues else 'INCOMPLETE_WITH_RETAINED_FAILURES'
    t.save(DEST.with_suffix('.json'), dict(schema='hyle.inference-conditional-verify.v1', status=status,
        product_sources=[source_index[t.key(R / name)] for name in changed],
        source_freeze=t.pin(frozen_path), frozen_project_files=len(frozen),
        actual_compiled_project_files=len(compiled['project_dependencies']), image=ready['image'], object=compiled['object'],
        CXX=cxx, link=link, prior_failed_CXX=dict(process=first_cxx,
            command='records/attempt1/logs/compile-tiny/command.json',
            logs_prefix='records/attempt1/logs/compile-tiny/',
            source_freeze='records/attempt1/source-freeze.json',
            historical_source='historical-source/attempt1/engine/inference/logits_inputs.h',
            reason='Status was returned without explicit std::unexpected into Result; one header line corrected before a distinct second CXX.'),
        actual_process_counts=dict(CXX=2, failed_CXX=1, link=1, native=5,
            failed_native=sum(not successful(row['process']) for row in runs.values())),
        SDK=dict(retained_inputs=227, objects=202, libraries=25, SDK_CXX=0, NVCC=0, downloads=0,
            existing_object_receipts_inspected=len(sdk_review['inspected']), unavailable_object_receipts=len(sdk_review['unavailable']),
            existing_engine_consumers=len(sdk_review['engine_consumers']), source_identities_checked_unchanged=True),
        native_processes=runs, unresolved_evidence_issues=issues,
        complete_state_comparisons=dict(total=len(states), numerically_equivalent=len(states),
            byte_identical=sum(row['payloads_byte_equal'] for row in states), F32_GDN_absolute_budget=3e-6),
        scope=dict(raw_EvaluationRequest=True, real_target_Verify=True, real_F32_math_oracle=True,
            conditional_target_and_draft_state_publication=True, finite_R1_CPU_CUDA_untrained_model=True,
            natural_conditional_supplier=False, request_scheduler_supplier=False, trained_quality_claim=False,
            throughput_claim=False, full_goal_completion=False, verified_for_all_requested_cases=not issues),
        records=dict(plan='records/attempt2/plan.json', compile='records/attempt2/compile/tiny/compiled.json', ready='records/attempt2/ready-tiny.json',
            SDK_review='records/attempt2/sdk-engine-dependencies.json', fixtures='fixtures/',
            note='Complete reports/state rows and all335 weight identities/extents live only in ZIP records/attempt2/plan.json and original reports; summary retains counts and key facts.'),
        limits=['Raw immutable conditional inputs enter the original EvaluationRequest -> bounded Verify -> submit -> recursive finish path; no natural grammar/scheduler supplier is implemented by this slice.',
            'Finite R1 checks use cached untrained GA/H64/V64/C16 weights. Actual acceptance row counts are reported as observed, without forced acceptance or all-prefix coverage claim.',
            'Successful Verify observers read real F32 target logits and compare actual original-q acceptance/residual/bonus equations, alongside complete target/draft state publication and failure/same-q retry.',
            'Preflight metadata/role rejection has no target candidate and no observed retirement; submitted numeric failure requires actual target/private retirement before retry.',
            'Separate existing conditional terminal mathematics and natural greedy CUDA K1 RequestLoop remain regressions, without expanded pipeline applicability.',
            'Complete-state comparisons retain the existing F32 GDN absolute budget3e-6; old immutable checkpoints stay byte-exact.',
            'Initial CXX PID34960 exited2; its source/header, command, logs, helper, plan and freeze remain distinct from the successful second attempt.',
            'SDK reuse checks available adjacent receipts and unchanged engine dependencies. Missing SDK object receipts remain explicit; no full SDK rebuild is claimed.',
            'Archive excludes environment values, tensor payloads and binaries; failures retain their original process/log/report facts and are never relabeled PASS.'],
        archive=t.pin(archive), archive_members=len(members), crc_and_member_sha256_readback=True))
    print('ARCHIVE WRITTEN', archive.name, t.pin(archive)['bytes'], t.pin(archive)['sha256'], status)


if __name__ == '__main__': main()
