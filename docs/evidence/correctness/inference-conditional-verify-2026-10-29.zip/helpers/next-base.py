"""Prepare reuse metadata and an exact cleanup proposal; never delete or run native code."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
A = W / 'attempt2'
spec = importlib.util.spec_from_file_location('conditional_verify_next_build', A / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t


def main():
    plan = b.validate()
    compiled_path = A / 'compile/tiny/compiled.json'
    compiled = t.read(compiled_path); ready_path = A / 'ready-tiny.json'; ready = t.read(ready_path)
    frozen_path = A / 'source-freeze.json'; frozen = t.read(frozen_path)
    assert ready['compiled'] == compiled and ready['inputs'] == plan['retained'] + [compiled['object']]
    assert len(plan['retained']) == 227
    assert compiled['process']['state'] == ready['process']['state'] == 'TERMINAL'
    assert compiled['process']['exit'] == ready['process']['exit'] == 0
    assert not compiled['process']['timed_out'] and not ready['process']['timed_out']
    t.exact(compiled['object']); t.exact(ready['image'])
    evidence_path = R / 'docs/evidence/correctness/inference-conditional-verify-2026-10-29.json'
    evidence = t.read(evidence_path)
    assert evidence['status'] == 'PASS_FINITE_CONDITIONAL_VERIFY'
    assert evidence['image'] == ready['image'] and evidence['object'] == compiled['object']
    assert evidence['source_freeze'] == t.pin(frozen_path)
    assert evidence['crc_and_member_sha256_readback'] is True
    t.exact(evidence['archive'])
    old = t.read(plan['base']['path'])
    identities = {t.key(row['path']): row for row in frozen}
    natural = plan['fixtures']['natural']
    destination = W / 'model-link-base.json'
    assert not destination.exists()
    model_base = dict(schema='hyle.conditional-verify.current-link-base.v1',
        base=t.pin(A / 'plan.json'), previous_consumer=t.pin(compiled_path), baseline_ready=t.pin(ready_path),
        compile=plan['units']['tiny']['compile'], link=plan['units']['tiny']['link'],
        retained=plan['retained'], runtime=plan['runtime'], source_freeze=t.pin(frozen_path),
        fixture=natural['manifest'], prompt=natural['prompt'], local_weight_sources=natural['local_weight_sources'],
        compiled_project_dependency_count=len(compiled['project_dependencies']), frozen_source_inventory_count=len(frozen),
        linked_facts=dict(image=ready['image'], link_process=ready['process'], compile_process=compiled['process'],
            consumer_object=compiled['object'], consumer_source=compiled['source'],
            model_source=identities[t.key(R / 'engine/models/qwen35/main.cc')],
            input_count=len(ready['inputs']), retained_count=227,
            inputs_equal_retained_plus_consumer=True, image_required_for_relink=False),
        sdk_objects_updated_in_this_batch=[],
        inherited_sdk_updates=old.get('inherited_sdk_updates', []) + old.get('sdk_objects_updated_in_this_batch', []),
        sdk_engine_dependencies=plan['sdk_engine_dependencies'],
        reuse_note='Current Tiny consumer and actual dependency receipts; retain this consumer object and all227 SDK inputs. '
                   'Rebuildable executable/import artifacts may be removed after archived evidence readback. '
                   'No exact(image) is required to relink. Environment remains local in this batch attempt2/environment.json; '
                   'no SDK CXX/NVCC/download was performed.')
    t.save(destination, model_base)
    previous = t.read(plan['previous_consumer']['path'])['object']
    image = Path(ready['image']['path'])
    paths = [image, image.with_suffix('.exp'), image.with_suffix('.lib'), Path(previous['path'])]
    scratch = (R / '.scratch').resolve()
    guards = [*plan['retained'], compiled['object'], plan['runtime']]
    guard_keys = {t.key(row['path']) for row in guards}
    deletions = []
    assert len({t.key(path) for path in paths}) == 4
    for path in paths:
        path = path.resolve()
        assert path.is_relative_to(scratch) and t.key(path) not in guard_keys and path.is_file()
        deletions.append(t.pin(path))
    assert deletions[0] == ready['image'] and deletions[-1] == previous
    proposal = W / 'cleanup-proposal.json'
    assert not proposal.exists()
    t.save(proposal, dict(schema='hyle.conditional-verify.cleanup-proposal.v1',
        action='PROPOSAL_ONLY_NO_DELETE', requires_root_test_ps1=True,
        evidence=t.pin(evidence_path), archive=evidence['archive'], next_link_base=t.pin(destination),
        targets=deletions, logical_bytes=sum(row['bytes'] for row in deletions),
        retained=guards, retained_runtime_alias=t.pin(A / 'bin' / Path(plan['runtime']['path']).name),
        retained_logs_sources_receipts_manifests=True,
        policy='Only the four exact files listed: current EXE/EXP/import LIB plus previous consumer OBJ. '
               'No recursive deletion, SDK deletion, runtime DLL deletion or weight/cache deletion. '
               'Root must first write and inspect repository test.ps1; this helper never writes or executes that script.'))
    print('NEXT BASE AND FOUR-FILE CLEANUP PROPOSAL WRITTEN', len(compiled['project_dependencies']), len(frozen))


if __name__ == '__main__': main()
