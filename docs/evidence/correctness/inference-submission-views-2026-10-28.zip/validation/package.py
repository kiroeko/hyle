"""Root-invoked, offline-only package of the three completed Source consumers."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-submission-views-2026-10-28'
CASES = {'relay': ('--cuda', 'plain'),
         'continuous': ('--cuda-continuous', 'context32'),
         'partial-capture': ('--cuda-source-failure', 'plain')}


def read(path): return json.loads(Path(path).read_bytes())
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def key(path): return str(path).replace('/', '\\').casefold()


def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def terminal(process):
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and process['timed_out'] is False, process


def require_true(report, fields):
    for field in fields: assert report[field] is True, field


def check_report(name, report):
    assert report['status'] == 'PASS' and report['backend'] == 'cuda' and report['performance_claim'] is False
    if name == 'relay':
        assert report['sampling'] == 'greedy'
        assert (report['requests'], report['resident_sessions'], report['active_sequences'],
                report['in_flight_batches'], report['state_slots'], report['serial_and_relay_arms'],
                report['outputs_per_live_member'], report['final_versions']) == (2, 2, 2, 2, 6, 6, 14, 0)
        require_true(report, ('distinct_prompt_payloads', 'complete_initialized_state_equal', 'ledger_and_rng_equal',
            'actual_batch_keys_checked', 'real_member_credit1_blocks_b', 'accepted_b_whole_discard',
            'survivor_r1_continues', 'peer_not_permanently_stopped'))
        assert report['model_eos_run'] is False and report['native_fault_injection'] is False
        arms = report['relay']; assert len(arms) == 3
        assert arms[0]['successor_submissions'] > 0 and arms[2]['successor_submissions'] > 0
        assert arms[2]['successor_discards'] > 0 and arms[2]['survivor_r1'] > 0
        for arm in arms:
            assert arm['successor_refusals'] == 0
            assert arm['successor_publications'] + arm['successor_discards'] == arm['successor_submissions']
            assert arm['actual_batches'] == len(arm['batch_facts'])
        return dict(serial_and_relay_arms=report['serial_and_relay_arms'],
            outputs_per_live_member=report['outputs_per_live_member'],
            relay_counters=[{k: v for k, v in arm.items() if k != 'batch_facts'} for arm in arms],
            credit_scope='Credit1 blocks B at the tested boundary; that arm need not submit B elsewhere.')
    if name == 'continuous':
        assert report['control_and_candidate_arms'] == 16 and len(report['candidates']) == 8
        require_true(report, ('same_original_executor', 'complete_prefix_state_epoch_rng_equal', 'actual_owner_credit_checked',
            'all_source_session_page_owners_retired', 'synthetic_v64_extra_stop_shares_eos_contract', 'accepted_work_control_exception'))
        assert report['gpu_native_fault_injected'] is False and report['model_quality_claim'] is False
        assert report['model_eos_run'] is False
        assert {entry['mode'] for entry in report['candidates']} == {
            'normal', 'credit_exhaustion', 'member_cancel', 'yield_resume', 'extra_stop', 'cancel_then_control_exception'}
        return dict(control_and_candidate_arms=report['control_and_candidate_arms'], candidates=len(report['candidates']),
            outputs_per_live_member=report['outputs_per_live_member'], candidate_counters=report['candidates'],
            synthetic_role_payload_bytes=report['synthetic_role_payload_bytes'])
    assert name == 'partial-capture' and report['case'] == 'source-post-submit-capture-failure'
    assert (report['native_submissions'], report['control_submissions'], report['failure_and_retry_submissions'],
            report['captured_original_stores'], report['prepared_uncaptured_pages'], report['final_live_versions']) == (5, 2, 3, 2, 2, 0)
    assert report['complete_state_bytes_compared'] > 0
    require_true(report, ('unprepared_trailing_store_rejected', 'optional_export_did_not_downgrade',
        'original_completion_transferred', 'external_source_owner_blocks_recovery', 'source_release_recovers_store_append',
        'committed_head_checkpoint_epoch_rng_ledger_unchanged', 'same_session_retry_matches_serial',
        'all_source_session_page_owners_retired', 'metadata_capture_failure'))
    assert report['native_fault_injection'] is False and report['model_quality_claim'] is False
    return {field: report[field] for field in ('case', 'native_submissions', 'control_submissions',
        'failure_and_retry_submissions', 'captured_original_stores', 'prepared_uncaptured_pages',
        'complete_state_bytes_compared', 'final_live_versions')}


def main():
    outjson, outzip = DEST.with_suffix('.json'), DEST.with_suffix('.zip')
    assert not outjson.exists() and not outzip.exists(), 'Preserve existing evidence'
    plan, frozen, compiled, ready = map(read, (W / 'plan.json', W / 'source-freeze.json',
                                              W / 'compile/compiled.json', W / 'ready.json'))
    assert plan['counts'] == dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, inputs=228,
                                 retained_inputs=227, native_processes=3, downloads=0)
    cxx, link = read(W / 'logs/compile/process.json'), read(W / 'logs/link/process.json')
    terminal(cxx); terminal(link)
    assert compiled['process'] == cxx and ready['compiled'] == compiled and ready['process'] == link
    assert read(W / 'logs/compile/command.json')['command'] == plan['compile']
    assert read(W / 'logs/link/command.json')['command'] == plan['link']
    assert ready['inputs'] == plan['retained'] + [compiled['object']] and len(ready['inputs']) == 228
    assert len({key(row['path']) for row in ready['inputs']}) == 228 and len(plan['retained']) == 227
    assert ready['runtime'] == plan['runtime']
    exact(plan['base']); exact(ready['source_freeze']); exact(plan['plain']); exact(plan['context32'])
    assert len(frozen) == 6 and len({key(row['path']) for row in frozen}) == 6
    dependencies = {key(row['path']): row for row in compiled['project_dependencies']}
    for row in frozen:
        exact(row)
        assert dependencies[key(row['path'])] == row
    assert compiled['source'] in frozen
    archive = {}

    def add(path, name=None):
        path = Path(path); name = name or 'validation/' + path.relative_to(W).as_posix()
        assert name not in archive
        assert path.suffix.lower() not in ('.exe', '.obj', '.dll', '.lib', '.pdb', '.bin', '.bf16', '.f32', '.safetensors', '.gguf')
        assert 'environment' not in path.name.casefold(), 'Do not archive environment variables'
        archive[name] = path.read_bytes()

    for relative in ('package.py', 'run.py', 'plan.json', 'source-freeze.json',
                     'compile/compiled.json', 'compile/dependencies.json', 'ready.json'):
        add(W / relative)
    for category in ('compile', 'link'):
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log'):
            add(W / 'logs' / category / filename)
    for row in frozen:
        relative = Path(row['path']).relative_to(R).as_posix()
        add(row['path'], 'source/' + relative)
    add(R / '.scratch/inference-indexed-store-20261028/build.py', 'helpers/original-process-recorder.py')
    add(R / '.scratch/inference-phase-carrier-20261028/run.py', 'helpers/original-relay-parser.py')

    fixtures = {}
    for name in ('plain', 'context32'):
        manifest = plan[name]; directory = Path(manifest['path']).parent
        add(manifest['path'], 'fixtures/' + name + '/weights.tsv')
        add(directory / 'prompt.ids', 'fixtures/' + name + '/prompt.ids')
        fixtures[name] = dict(manifest=manifest, prompt=pin(directory / 'prompt.ids'))
    extra = Path(plan['context32']['path']).parent / 'continuous-extra-stop-v64'
    for filename in ('weights.tsv', 'prompt.ids'): add(extra / filename, 'fixtures/continuous-extra-stop-v64/' + filename)
    fixtures['continuous_extra_stop'] = dict(manifest=pin(extra / 'weights.tsv'), prompt=pin(extra / 'prompt.ids'),
        scope='Small synthetic greedy-chain fixture generated by the frozen consumer; payload body excluded.')
    archive['identity/fixtures.json'] = encoded(dict(fixtures=fixtures, inherited_payloads_copied=False,
        model_payloads_included=False, context_change=plan['fixture_change']))

    cases = []
    assert {p.name for p in (W / 'runs').iterdir() if p.is_dir()} == set(CASES)
    for name, (flag, fixture) in CASES.items():
        directory = W / 'runs' / name; process = read(directory / 'process.json'); terminal(process)
        assert read(directory / 'command.json')['command'] == [
            ready['image']['path'], flag, str(Path(plan[fixture]['path']).parent)]
        reports = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
                   if line.startswith('{')]
        report = read(directory / 'report.json'); assert reports == [report]
        cases.append(dict(name=name, process=process, report=pin(directory / 'report.json'), facts=check_report(name, report)))
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'report.json'): add(directory / filename)
    assert len({(case['process']['pid'], case['process']['started']) for case in cases}) == len(CASES)

    manifest = encoded(dict(members=[dict(name=name, bytes=len(raw), sha256=sha(raw))
                                    for name, raw in sorted(archive.items())],
                            self_hash='External JSON archive.manifest_sha256'))
    archive['MANIFEST.json'] = manifest
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(archive.items()): z.writestr(name, raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, raw in archive.items(): assert sha(z.read(name)) == sha(raw), name
    result = dict(schema='hyle.correctness.submission-views.v1', date='2026-10-28',
        status='PASS_THREE_FINITE_CUDA_SOURCE_COHORT_CASES',
        change='Move original producer Store/Append metadata preparation and success-only SubmissionSource '
               'export/token/Store/Append capture into nonvirtual SubmissionViews; keep the original episode owner and recovery.',
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, inputs=len(ready['inputs']),
                    retained_inputs=len(plan['retained']), native_processes=len(cases), downloads=0),
        build=dict(compile_process=cxx, link_process=link, source=compiled['source'], image=ready['image'],
                   source_freeze=pin(W / 'source-freeze.json'), receipt=pin(W / 'compile/compiled.json'),
                   project_dependency_records=len(compiled['project_dependencies']), retained_base=plan['base']),
        sources=frozen, cases=cases, fixtures=fixtures,
        failure_contract='The trailing unprepared Store is a post-submit metadata capture failure, not a GPU fault. '
                         'The original Completion has transferred; optional export cannot downgrade. An external Source '
                         'owner blocks recovery until released, then the original Store/Append recover and same-Session retry succeeds.',
        limitations=['Ordinary CUDA only, synthetic untrained GA/H64/V64 fixtures with context16/context32; no MTP, Apple or Vulkan run.',
            'Continuous uses sixteen control/candidate arms; relay uses six serial/relay arms. The partial-capture process '
            'contains five native submissions (two control plus three failure/retry), not five OS processes.',
            'Frozen consumer state/checkpoint/epoch/RNG/ledger checks are retained. No trained model EOS, GPU-fault injection, '
            'unknown native retirement, model quality, performance or complete orchestration conclusion.',
            'SDK and weights are inherited in the 227-input closure. Dependency records identify the current consumer '
            'compilation; this does not claim every retained SDK object was recompiled.',
            'No executable/object/DLL/archive, model payload or process environment values are included.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', all_member_SHA256='PASS'))
    with outjson.open('xb') as out: out.write(encoded(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', all_member_SHA256='PASS')
    with (W / 'package-readback.json').open('xb') as out: out.write(encoded(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
