"""Current ordinary Source cohort: one include-Model TU, one link, three runs."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
OLD = R / '.scratch/inference-program-installation-20261028'
SOURCE = R / 'tests/tools/qwen_generation_batch_relay_probe.cc'
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
CONTEXT32 = W / 'context32'
SOURCES = ('engine/inference/submission_views.h', 'engine/inference/execution_episode.h',
           'engine/models/qwen35/main.cc', 'tests/tools/qwen_generation_batch_relay_probe.cc',
           'tests/tools/qwen_continuous_generation_case.h', 'tests/tools/qwen_generation_state_case.h')

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result

t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'submission_views_executor')
t.W = W

def prepare():
    prior = t.read(OLD / 'plan.json')
    template = prior['compile']; compile_args = []
    for n, arg in enumerate(template):
        if t.key(arg) == t.key(R / 'tests/tools/qwen_host_image_test.cc'): arg = str(SOURCE)
        elif n and template[n - 1].casefold() == '/sourcedependencies': arg = str(W / 'compile/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/unit.pdb')
        compile_args.append(arg)
    assert str(SOURCE) in compile_args and not any('qwen_host_image_test.cc' in a for a in compile_args)
    link_args = []
    for arg in prior['link']:
        if t.key(arg) == t.key(OLD / 'compile/unit.obj'): arg = str(W / 'compile/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/submission-views').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(a) == t.key(W / 'compile/unit.obj') for a in link_args) == 1
    for row in prior['retained']: t.exact(row)
    env = t.read(OLD / 'environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    manifest = (PLAIN / 'weights.tsv').read_bytes()
    lines = manifest.decode('utf-8-sig').splitlines(); geometry = lines[2].split()
    assert geometry[0] == 'geometry' and geometry[14] == '16'
    geometry[14] = '32'; lines[2] = ' '.join(geometry)
    import hashlib
    lines[1] = hashlib.sha256(manifest + b' explicit-untrained-GA-context32').hexdigest()
    CONTEXT32.mkdir()
    (CONTEXT32 / 'weights.tsv').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    (CONTEXT32 / 'prompt.ids').write_bytes((PLAIN / 'prompt.ids').read_bytes())
    t.save(W / 'plan.json', dict(base=t.pin(OLD / 'plan.json'), retained=prior['retained'], compile=compile_args,
        link=link_args, runtime=prior['runtime'], plain=t.pin(PLAIN / 'weights.tsv'),
        context32=t.pin(CONTEXT32 / 'weights.tsv'), fixture_change='Only synthetic context16 to32 manifest/identity; reuse all original absolute weight ranges; no weight copy/download',
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, inputs=228, retained_inputs=227, native_processes=3, downloads=0)))
    print('PREPARED one current relay CXX/link; three CUDA consumers; manifest-only context32')

def freeze():
    t.save(W / 'source-freeze.json', [t.pin(R / path) for path in SOURCES])
    print('SOURCE FROZEN', len(SOURCES))

def validate():
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    return t.read(W / 'plan.json')

def compile():
    p = validate(); (W / 'compile').mkdir()
    process = t.execute(p['compile'], W / 'logs/compile', 300)
    validate()
    dependencies = [t.pin(path) for path in t.dep_paths(W / 'compile/dependencies.json') if t.project(path)]
    t.save(W / 'compile/compiled.json', dict(source=t.pin(SOURCE), object=t.pin(W / 'compile/unit.obj'),
        process=process, project_dependencies=dependencies))
    print('CXX PASS', process['pid'])

def link():
    p = validate(); compiled = t.read(W / 'compile/compiled.json'); t.exact(compiled['object'])
    for row in p['retained']: t.exact(row)
    (W / 'bin').mkdir()
    alias = W / 'bin' / Path(p['runtime']['path']).name
    alias.hardlink_to(p['runtime']['path']); assert alias.samefile(p['runtime']['path'])
    process = t.execute(p['link'], W / 'logs/link', 240)
    t.save(W / 'ready.json', dict(image=t.pin(W / 'bin/submission-views.exe'), inputs=p['retained'] + [compiled['object']],
        compiled=compiled, process=process, runtime=p['runtime'], source_freeze=t.pin(W / 'source-freeze.json')))
    print('LINK PASS', process['pid'])

def parse(name):
    out = W / 'runs' / name; process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports) == 1; report = reports[0]
    assert report['status'] == 'PASS' and report['backend'] == 'cuda' and report['performance_claim'] is False
    if name == 'relay':
        parser = module(R / '.scratch/inference-phase-carrier-20261028/run.py', 'submission_views_relay_parser')
        parser.relay_report(reports)
    elif name == 'continuous':
        assert report['control_and_candidate_arms'] == 16 and len(report['candidates']) == 8
        for field in ('same_original_executor', 'complete_prefix_state_epoch_rng_equal', 'actual_owner_credit_checked',
                      'all_source_session_page_owners_retired', 'synthetic_v64_extra_stop_shares_eos_contract', 'accepted_work_control_exception'):
            assert report[field] is True, field
        assert report['gpu_native_fault_injected'] is False and report['model_quality_claim'] is False
        assert {entry['mode'] for entry in report['candidates']} == {'normal', 'credit_exhaustion', 'member_cancel', 'yield_resume', 'extra_stop', 'cancel_then_control_exception'}
    else:
        assert name == 'partial-capture'
        assert report['case'] == 'source-post-submit-capture-failure'
        assert report['native_submissions'] == 5 and report['control_submissions'] == 2
        assert report['failure_and_retry_submissions'] == 3
        assert report['captured_original_stores'] == 2 and report['prepared_uncaptured_pages'] == 2
        assert report['complete_state_bytes_compared'] > 0 and report['final_live_versions'] == 0
        for field in ('unprepared_trailing_store_rejected', 'optional_export_did_not_downgrade',
                      'original_completion_transferred', 'external_source_owner_blocks_recovery',
                      'source_release_recovers_store_append', 'committed_head_checkpoint_epoch_rng_ledger_unchanged',
                      'same_session_retry_matches_serial', 'all_source_session_page_owners_retired', 'metadata_capture_failure'):
            assert report[field] is True, field
        assert report['native_fault_injection'] is False and report['model_quality_claim'] is False
    t.save(out / 'report.json', report)
    print('PASS', name, 'PID', process['pid'])

def run(name):
    p = validate(); ready = t.read(W / 'ready.json'); t.exact(ready['image'])
    flag, fixture = {'relay': ('--cuda', PLAIN), 'continuous': ('--cuda-continuous', CONTEXT32),
                     'partial-capture': ('--cuda-source-failure', PLAIN)}[name]
    t.exact(p['context32'] if name == 'continuous' else p['plain'])
    t.execute([ready['image']['path'], flag, str(fixture)], W / 'runs' / name, 300)
    parse(name)

if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare', 'freeze', 'compile', 'link'): globals()[action]()
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
