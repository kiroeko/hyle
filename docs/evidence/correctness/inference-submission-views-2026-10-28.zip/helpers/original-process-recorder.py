"""Bounded indexed-Store build helper. Every action is explicit and single-use.

prepare only reads retained recipes/dependency metadata; it never freezes active
sources, invokes a compiler/linker, copies an SDK, or starts a consumer.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-stable-attention-20261027'
CLI = BASE / 'followup-user-cli/ready-cli.json'
COMPONENT = BASE / 'followup-budget/ready-component.json'
SOURCES = {
    'resources': 'src/graph/resources.cc',
    'slots-region': 'src/graph/slots_region.cc',
    'batch': 'src/graph_batch/batch.cc',
    'ggml-region': 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
    'cuda-backend': 'src/compute_backend_cuda/cuda_backend.cc',
    'cuda-status': 'src/compute_backend_cuda/cuda_device_status.cc',
    'indexed-host': 'src/compute_backend_cuda/cuda_indexed_copy.cc',
    'indexed-kernel': 'src/compute_backend_cuda/cuda_indexed_copy.cu',
    'slots-test': 'tests/graph/slots_cuda_execution_test.cc',
}
CHANGED_HEADERS = ('src/graph/slots_region.h', 'src/compute_backend_cuda/cuda_internal.h',
                   'src/compute_backend_cuda/cuda_indexed_copy.h',
                   'include/hyle/compute/detail/indexed_copy_backend.h')
FILTER = ('GraphSlotsCudaExecution.*:'
          'GraphBatchCapture.UniformDecodePlansKeepCaptureAcrossGrowingPagedPrefixes')
MODEL_ARMS = {'ordinary-two-turn': 'two-turn-auto', 'mtp-single': 'single-mtp'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as out:
        out.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def key(path):
    return str(path).replace('/', '\\').casefold()


def pin(path):
    path = Path(path).resolve(); digest = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(1 << 20): digest.update(data)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    now = pin(row['path'])
    assert (now['bytes'], now['sha256']) == (row['bytes'], row['sha256']), row['path']


def project(path):
    p = Path(path).resolve()
    return (p.is_relative_to(R) and bool(p.relative_to(R).parts)
            and p.relative_to(R).parts[0] in ('include', 'src', 'engine', 'tests'))


def canonical(path):
    p = Path(path).resolve()
    if project(p): return p
    # Retained source snapshots are mapped only to an actually existing repo
    # path, never to another checkout or an invented source filename.
    if p.is_relative_to(R / '.scratch'):
        parts = p.parts
        for i, part in reversed(list(enumerate(parts))):
            if part in ('include', 'src', 'engine', 'tests'):
                q = R.joinpath(*parts[i:])
                if q.is_file(): return q
    return p


def command(path):
    value = read(path)
    return value['command'] if isinstance(value, dict) else value


def dep_paths(path):
    p = Path(path)
    if p.suffix == '.json':
        data = read(p)['Data']
        return [Path(data['Source']), *map(Path, data.get('Includes', []))]
    # NVCC -MF emits escaped spaces, line continuations, and forward-slash
    # dependency paths. Split after the target separator, not the drive colon.
    text = p.read_text(encoding='utf-8-sig').replace('\\\n', ' ')
    text = text.split(' : ', 1)[1]
    return [Path(s.replace('\\ ', ' ')) for s in re.findall(r'(?:\\ |\S)+', text)]


def retained_metadata(row):
    """Inspect only this manifest object's local receipt/dependency directory."""
    p = Path(row['path']); parent = p.parent
    if p.suffix.casefold() != '.obj': return None
    deps = parent / 'dependencies.json'
    if not deps.is_file(): return None
    value = read(deps)
    if 'Data' not in value or 'Source' not in value['Data']: return None
    receipt = parent / 'compiled.json'
    cmd = parent / 'command.json'
    if receipt.is_file():
        info = read(receipt)
        if isinstance(info.get('command'), dict): cmd = Path(info['command']['path'])
    return dict(object=row, source=str(canonical(value['Data']['Source'])),
                dependencies=pin(deps), command=pin(cmd) if cmd.is_file() else None,
                includes=[str(canonical(q)) for q in value['Data'].get('Includes', [])])


def environment():
    env = os.environ.copy(); env.update(read(W / 'environment.json'))
    env.update(HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    return env


def prepare():
    baselines = {}
    all_rows = {}
    for name, path, count in (('cli', CLI, 224), ('component', COMPONENT, 225)):
        ready = read(path); rows = read(ready['inputs']['path'])
        assert len(rows) == count
        baselines[name] = dict(ready=pin(path), image=ready['image'], inputs=ready['inputs'],
                               recipe=ready['recipe'], runtime=ready['runtime'], count=count)
        for row in rows: all_rows[key(row['path'])] = row
    assert baselines['cli']['image']['sha256'].startswith('91ebdde8')
    index = [v for row in all_rows.values() if (v := retained_metadata(row))]
    by_source = {key(v['source']): v for v in index}
    units = {}
    for name in list(SOURCES)[:6]:
        original = by_source[key(R / SOURCES[name])]
        assert original['command'], name
        units[name] = dict(source=str(R / SOURCES[name]), old_object=original['object'],
                           recipe=original['command'], dependencies=original['dependencies'], kind='CXX')
    host = by_source[key(R / 'src/compute_backend_cuda/cuda_paged_append.cc')]
    units['indexed-host'] = dict(source=str(R / SOURCES['indexed-host']), old_object=None,
        recipe=host['command'], dependencies=host['dependencies'], kind='CXX',
        template_source=host['source'], template_object=host['object'])
    kernel = R / '.scratch/paged-capture-20261021/cuda/checks1/kernel'
    recipe = kernel / 'compile.command.json'; native = command(recipe)
    assert native[0].endswith('nvcc.exe') and '-std=c++20' in native
    assert any('compute_89' in arg and 'sm_89' in arg for arg in native)
    assert any(key(arg) == key(R / 'src/compute_backend_cuda/cuda_paged_append.cu') for arg in native)
    units['indexed-kernel'] = dict(source=str(R / SOURCES['indexed-kernel']), old_object=None,
        recipe=pin(recipe), dependencies=pin(kernel / 'kernel.obj.d'), kind='NVCC',
        template_source=str(R / 'src/compute_backend_cuda/cuda_paged_append.cu'))
    test = R / '.scratch/inference-slot-store-20261027/attempt2/compile/cuda-test'
    assert key(read(test / 'dependencies.json')['Data']['Source']) == key(R / SOURCES['slots-test'])
    # No matching slots test exists in this 225-input component closure.
    assert key(R / SOURCES['slots-test']) not in by_source
    units['slots-test'] = dict(source=str(R / SOURCES['slots-test']), old_object=None,
        recipe=pin(test / 'command.json'), dependencies=pin(test / 'dependencies.json'), kind='CXX')
    consumers = {}
    for relative in CHANGED_HEADERS:
        consumers[relative] = [dict(source=v['source'], object=v['object'],
            will_recompile=any(key(u['source']) == key(v['source']) for u in units.values()))
            for v in index if key(R / relative) in map(key, v['includes'])]
    save(W / 'retained-source-index.json', dict(index=index,
        metadata_unavailable=[row for row in all_rows.values() if row['path'].endswith('.obj')
                              and key(row['path']) not in {key(v['object']['path']) for v in index}],
        scope='Local actual MSVC dependency metadata only; unavailable receipts are explicit.'))
    save(W / 'header-consumers.json', consumers)
    save(W / 'plan.json', dict(status='PREPARED_METADATA_ONLY_NOT_FROZEN', units=units, baselines=baselines,
        source_index=pin(W / 'retained-source-index.json'), header_consumers=pin(W / 'header-consumers.json'),
        counts=dict(CXX=8, NVCC=1, component_links=1, optional_cli_links=1,
                    component_inputs=228, cli_inputs=226, actual_builds=0, actual_runs=0, SDK=0, downloads=0),
        replacements=[dict(unit=n, original=u['old_object']) for n,u in units.items() if u['old_object']],
        additions=['indexed-host', 'indexed-kernel', 'slots-test'],
        actions=['prepare', 'freeze', 'compile NAME', 'link component|cli',
                 'run-component', 'parse-component', 'run-ordinary', 'run-mtp', 'parse-model NAME'],
        policy='No automatic build, retry or consumer run. Separate all output/PDB/IMPLIB paths. '
               'Retain baseline batch test; append slots test once, never duplicate entry objects. '
               'freeze requires an explicit ABI-review.json for any changed retained header.'))
    env = read(BASE / 'followup-budget/environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    save(W / 'environment.json', env)
    save(W / 'runtime-plan.json', dict(PATH=env['PATH'], original=baselines['component']['runtime'],
        ownership='Reuse original runtime PATH/aliases in place; no DLL, SDK, model or payload copy.'))
    print('PREPARED 8CXX+1NVCC; component225->228, optional CLI224->226; zero source freeze/build/run')


def freeze():
    plan = read(W / 'plan.json')
    assert not (W / 'source-freeze.json').exists()
    # A reviewed, concrete declaration-impact record is mandatory: additive
    # function declarations are not permission to ignore changed struct ABI.
    review = read(W / 'abi-review.json')
    assert review['approved_source_scope'] == list(SOURCES.values())
    assert review['all_changed_header_consumers_accounted_for'] is True
    for base in plan['baselines'].values():
        for field in ('ready', 'inputs', 'recipe', 'runtime'): exact(base[field])
    files = {R / s for s in SOURCES.values()} | {R / h for h in CHANGED_HEADERS}
    for unit in plan['units'].values():
        exact(unit['recipe']); exact(unit['dependencies'])
        files.update(canonical(p) for p in dep_paths(unit['dependencies']['path']) if project(canonical(p)))
    todo = list(files)
    while todo:
        p = todo.pop()
        for inc in re.findall(r'^\s*#\s*include\s*"([^\"]+)"', p.read_text(encoding='utf-8-sig'), re.M):
            found = next((q.resolve() for root in (p.parent, R / 'include', R)
                          if (q := root / inc).is_file()), None)
            if found is not None and project(found) and found not in files:
                files.add(found); todo.append(found)
    rows = []
    for p in sorted(files):
        target = W / 'source' / p.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as out: out.write(p.read_bytes())
        original, snapshot = pin(p), pin(target)
        assert (original['bytes'], original['sha256']) == (snapshot['bytes'], snapshot['sha256'])
        rows.append(dict(original=original, snapshot=snapshot))
    save(W / 'source-freeze.json', rows)
    recipes = {}
    for name, unit in plan['units'].items():
        old = command(unit['recipe']['path']); out = W / 'compile' / name
        new = [old[0]]
        if unit['kind'] == 'CXX':
            new += ['/I' + str(W / 'source' / p) for p in ('include', '', str(Path(SOURCES[name]).parent))]
        else:
            new += ['-I' + str(W / 'source' / p) for p in ('include', 'src/compute_backend_cuda', 'src/compute')]
        for i, arg in enumerate(old[1:], 1):
            previous = old[i - 1]
            if unit['kind'] == 'CXX':
                if previous.casefold() == '/sourcedependencies': arg = str(out / 'dependencies.json')
                elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
                elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
                elif arg.casefold().endswith(('.cc', '.cpp', '.cxx')): arg = str(W / 'source' / SOURCES[name])
                elif arg.casefold().startswith(('/i', '/external:i')):
                    lead = '/external:I' if arg.casefold().startswith('/external:i') else '/I'
                    p = canonical(arg[len(lead):])
                    if project(p) or p == R: arg = lead + str(W / 'source' / p.relative_to(R))
            else:
                if previous in ('-o', '-MT'): arg = str(out / 'unit.obj')
                elif previous == '-MF': arg = str(out / 'dependencies.d')
                elif arg.casefold().endswith('.cu'): arg = str(W / 'source' / SOURCES[name])
                elif '/Fd' in arg: arg = '-Xcompiler=/Fd' + str(out / 'unit.pdb') + ',/FS'
            new.append(arg)
        recipes[name] = dict(command=new, cwd=str(R), timeout_seconds=240)
        save(W / 'recipes' / (name + '.json'), recipes[name])
    save(W / 'frozen.json', dict(plan=pin(W / 'plan.json'), helper=pin(__file__), sources=pin(W / 'source-freeze.json'),
        ABI_review=pin(W / 'abi-review.json'), recipes={n:pin(W/'recipes'/(n+'.json')) for n in recipes}))
    print('FROZEN only; no build/run')


def validate():
    frozen = read(W / 'frozen.json')
    for name in ('plan', 'helper', 'sources', 'ABI_review'): exact(frozen[name])
    for row in read(W / 'source-freeze.json'): exact(row['snapshot'])
    return read(W / 'plan.json'), frozen


def execute(args, output, timeout):
    output.mkdir(parents=True, exist_ok=False)
    save(output / 'command.json', dict(command=args, cwd=str(R), timeout_seconds=timeout))
    start = time.time()
    with (output/'stdout.log').open('xb') as stdout, (output/'stderr.log').open('xb') as stderr:
        proc = subprocess.Popen(args, cwd=R, env=environment(), stdout=stdout, stderr=stderr,
                                creationflags=subprocess.CREATE_NO_WINDOW)
        save(output / 'running.json', dict(pid=proc.pid, started=start))
        timed_out = False
        try: code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True; proc.terminate()
            try: code = proc.wait(timeout=10)
            except subprocess.TimeoutExpired: proc.kill(); code = proc.wait(timeout=10)
    result = dict(pid=proc.pid, exit=code, started=start, seconds=time.time()-start,
                  state='TERMINAL', timed_out=timed_out)
    save(output / 'process.json', result)
    assert code == 0 and not timed_out, result
    return result


def compile_unit(name):
    plan, frozen = validate(); unit = plan['units'][name]
    exact(frozen['recipes'][name]); recipe = read(frozen['recipes'][name]['path'])
    out = W / 'compile' / name; out.mkdir(parents=True, exist_ok=False)
    process = execute(recipe['command'], W/'logs'/name, recipe['timeout_seconds'])
    dep = out / ('dependencies.d' if unit['kind']=='NVCC' else 'dependencies.json')
    allowed = {key(row['snapshot']['path']):row['snapshot'] for row in read(W/'source-freeze.json')}
    dependencies = []
    for p in dict.fromkeys(dep_paths(dep)):
        if project(canonical(p)):
            assert key(p) in allowed, ('unfrozen project dependency', str(p))
            exact(allowed[key(p)])
        dependencies.append(pin(p))
    save(out/'actual-dependencies.json', dependencies)
    save(out/'compiled.json', dict(source=pin(W/'source'/SOURCES[name]),
        object=pin(out/'unit.obj'), process=process, dependencies=pin(dep),
        actual_dependencies=pin(out/'actual-dependencies.json'), command=pin(W/'logs'/name/'command.json')))
    print('COMPILE_PASS', name)


def link(kind):
    plan, frozen = validate(); assert kind in ('component', 'cli')
    baseline = plan['baselines'][kind]; exact(baseline['inputs']); exact(baseline['recipe'])
    replacements = {}; additions = []; compiled = {}
    for name, unit in plan['units'].items():
        if name == 'slots-test' and kind == 'cli': continue
        item = read(W/'compile'/name/'compiled.json'); exact(item['object']); compiled[name]=item
        if unit['old_object']: replacements[key(unit['old_object']['path'])] = item['object']
        else: additions.append(item['object'])
    rows = read(baseline['inputs']['path'])
    assert all(sum(key(r['path']) == p for r in rows)==1 for p in replacements)
    rows = [replacements.get(key(row['path']), row) for row in rows] + additions
    assert len(rows) == (228 if kind=='component' else 226)
    assert len({key(row['path']) for row in rows}) == len(rows)
    for row in rows: exact(row)
    image = W/'bin'/('indexed-store-test.exe' if kind=='component' else 'hyle-indexed-store.exe')
    image.parent.mkdir(parents=True, exist_ok=True); assert not image.exists()
    args = []
    for arg in command(baseline['recipe']['path']):
        if key(arg) in replacements: arg = replacements[key(arg)]['path']
        for option, suffix in (('/OUT:', '.exe'),('/PDB:', '.pdb'),('/IMPLIB:', '.lib'),('/MAP:', '.map')):
            if arg.upper().startswith(option): arg = option + str(image.with_suffix(suffix)); break
        args.append(arg)
    args += [row['path'] for row in additions]
    for option,suffix in (('/PDB:', '.pdb'),('/IMPLIB:', '.lib')):
        if not any(x.upper().startswith(option) for x in args): args.append(option+str(image.with_suffix(suffix)))
    save(W/(kind+'-link-inputs.json'), rows)
    process = execute(args, W/('link-'+kind), 240)
    save(W/('ready-'+kind+'.json'), dict(status='LINKED_NOT_RUN', image=pin(image), compiled=compiled,
        process=process, inputs=pin(W/(kind+'-link-inputs.json')),
        recipe=pin(W/('link-'+kind)/'command.json'), runtime=pin(W/'runtime-plan.json'), frozen=pin(W/'frozen.json')))
    print('LINK_PASS', kind)


def parse_component():
    ready = read(W/'ready-component.json'); run = W/'run-component'
    process = read(run/'process.json'); assert process['exit']==0 and not process['timed_out']
    root = ET.parse(run/'results.xml').getroot()
    tests = int(root.attrib['tests']); failures = int(root.attrib['failures'])
    skipped = len(root.findall('.//testcase/skipped'))
    assert tests == 9 and failures == 0 and skipped == 0
    text = (run/'stdout.log').read_text(encoding='utf-8-sig')
    executions = len(re.findall(r'^stable_attention slot=', text, re.M))
    assert executions == 100, executions
    result = dict(status='PASS', process=process, image=ready['image'], tests=tests,
                  failures=failures, batch_executions=executions,
                  xml=pin(run/'results.xml'), filter=FILTER)
    # Parser-only recovery never touches the immutable process/stdout/XML.
    save(W/('summary-'+str(time.time_ns())+'.json'), result)
    print('PASS', tests, 'selected component tests')


def run_component():
    validate(); ready = read(W/'ready-component.json'); exact(ready['image'])
    run = W/'run-component'; assert not run.exists(), 'Do not rerun a completed or failed process'
    execute([ready['image']['path'], '--gtest_filter='+FILTER, '--gtest_fail_fast',
             '--gtest_output=xml:'+str(run/'results.xml')], run, 180)
    parse_component()


def parse_model(name):
    assert name in MODEL_ARMS
    ready = read(W/'ready-cli.json'); out = W/'models'/name
    process = read(out/'process.json'); assert process['exit']==0 and not process['timed_out']
    original = BASE/'model-checks'/MODEL_ARMS[name]
    spec = importlib.util.spec_from_file_location('indexed_store_original_model_facts', BASE/'model_check.py')
    tools = importlib.util.module_from_spec(spec); spec.loader.exec_module(tools)
    actual, expected = read(out/'stdout.log'), read(original/'stdout.log')
    differences = tools.prior.changed(tools.prior.facts.non_time(expected), tools.prior.facts.non_time(actual))
    save(out/('complete-non-time-differences-'+str(time.time_ns())+'.json'), differences)
    assert not differences, differences[:8]
    assert actual['live_committed_versions']==0
    if name=='ordinary-two-turn':
        assert actual['overlap_successor_refusals']==0
        assert actual['overlap_successor_publications']>0
    save(out/('summary-'+str(time.time_ns())+'.json'), dict(status='FINITE_FUNCTIONAL_FACTS_PASS',
        process=process, image=ready['image'], original=pin(original/'stdout.log'),
        complete_non_time_differences=differences, performance_claim=False,
        scope='One original natural consumer journey; no new timing/window claim.'))
    print('MODEL_FUNCTIONAL_PASS', name)


def run_model(name):
    validate(); assert name in MODEL_ARMS
    ready = read(W/'ready-cli.json'); exact(ready['image'])
    original = BASE/'model-checks'/MODEL_ARMS[name]
    args = [ready['image']['path'], *command(original/'command.json')[1:]]
    execute(args, W/'models'/name, 180)
    parse_model(name)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action=='prepare': prepare()
        elif action=='freeze': freeze()
        elif action=='compile': compile_unit(sys.argv[2])
        elif action=='link': link(sys.argv[2])
        elif action=='run-component': run_component()
        elif action=='parse-component': parse_component()
        elif action=='run-ordinary': run_model('ordinary-two-turn')
        elif action=='run-mtp': run_model('mtp-single')
        elif action=='parse-model': parse_model(sys.argv[2])
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True, exist_ok=True)
        (W/('failure-'+'-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
