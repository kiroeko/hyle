from pathlib import Path
import hashlib,json,subprocess,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified')
out=base/'g01-native-page-vulkan-draft'
source=base/'source-c8874688'
build=base/'a-cpu-vulkan/selected-graph/source-build'
result=json.loads((out/'result.json').read_text())
commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],text=True))
required=['src/compute_route_vulkan/vulkan_batch.cc','src/compute_route_vulkan/vulkan_materialized_invocation.cc',
          'src/compute_provider_ggml_vulkan/region.cc','tests/compute_batch/native_paged_vulkan_consumer.cc']
selected=[]
for name in required:
    matches=[c for c in commands if c['file'].endswith(name)];assert matches,name;selected.extend(matches)
(out/'compiled-inputs.json').write_text(json.dumps(selected,indent=2)+'\n')
host=next(c for c in commands if c['file'].endswith('/ggml-vulkan.cpp'))
vendor_root=Path(host['file']).parents[2]
manifest=json.loads((source/'third_party/ggml_vulkan_runtime/patches.json').read_text())
checked=[]
for item in manifest['files']:
    if item['path'].endswith('ggml-vulkan.cpp') or item['path'].endswith('flash_attn.comp'):
        path=vendor_root/item['path'];digest=hashlib.sha256(path.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
        assert digest==item['after_sha256'],(path,digest,item['after_sha256'])
        checked.append({'path':str(path),'after_sha256':digest})
(out/'native-patch-identities.json').write_text(json.dumps({'compiled_host':host,'verified':checked},indent=2)+'\n')
assert result['stages'][-3]['exit_code']==0 and result['stages'][-2]['exit_code']==0 and result['stages'][-1]['exit_code']==0
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in out.iterdir():
        if path.is_file() and path.suffix in ['.json','.log','.py']:
            archive.write(path,path.name)
print('collected actual compiled inputs/native patch identities and all raw stages')
