from pathlib import Path
import hashlib, json

root = Path('C:/public/project-hyle/hyle')
upstream = Path('C:/public/tools/hyle-dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424')
manifest_path = root / 'third_party/ggml_vulkan_runtime/patches.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
host = next(p for p in manifest['files'] if p['path'].endswith('ggml-vulkan.cpp'))

def edit(patch, before, after):
    patch['edits'].append({'before': before, 'after': after})

edit(host, '    const uint32_t KV = nek1;', '''    const bool hyle_paged = dst->src[5] != nullptr &&
        dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionPagedSlot] ==
        hyle::compute::ggml_vulkan::bridge::kFlashAttentionPaged;
    const uint32_t KV = hyle_paged ? uint32_t(dst->op_params[
        hyle::compute::ggml_vulkan::bridge::kFlashAttentionLogicalRowsSlot]) : uint32_t(nek1);''')
edit(host, '    fa_pipeline_state.hyle_full_f32 = hyle_full_f32;', '''    fa_pipeline_state.hyle_full_f32 = hyle_full_f32;
    if (hyle_paged) {
        GGML_ASSERT(hyle_full_f32 && !mask && !sinks && !use_mask_opt);
        fa_pipeline_state.flags |= 16u;
        if (dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionCausalSlot]) {
            fa_pipeline_state.flags |= 32u;
        }
    }''')
edit(host, '    vk_subbuffer mask_opt_buf = use_mask_opt ? ggml_vk_subbuffer(ctx, ctx->prealloc_y, 0) : q_buf;', '''    // Paged-only identity reuses the unused mask-opt binding. Keep all normal
    // descriptors, push size and coopmat pipelines unchanged.
    vk_subbuffer mask_opt_buf = hyle_paged ? ggml_vk_tensor_subbuffer(ctx, dst->src[5]) :
        (use_mask_opt ? ggml_vk_subbuffer(ctx, ctx->prealloc_y, 0) : q_buf);''')
edit(host, '                                              nem1, nem2, nem3,', '''                                              hyle_paged ? uint32_t(neq1) : nem1,
                                              hyle_paged ? uint32_t(dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionTableOffsetSlot]) : nem2,
                                              hyle_paged ? 1u : nem3,''')
# Reject an unqualified private op before the upstream support verdict can
# dispatch it. Table origin is the full root, never an unaligned per-request
# descriptor slice; only the integer table offset moves between requests.
edit(host, '                if (hyle_full_f32) {\n                    if (HSK != HSV', '''                const bool hyle_paged = op->src[5] != nullptr &&
                    op->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionPagedSlot] ==
                    hyle::compute::ggml_vulkan::bridge::kFlashAttentionPaged;
                if (hyle_paged) {
                    const auto * table = op->src[5];
                    const int32_t rows = op->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionLogicalRowsSlot];
                    const int32_t offset = op->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionTableOffsetSlot];
                    if (!hyle_full_f32 || op->src[3] || op->src[4] || rows <= 0 || offset < 0 ||
                        table->type != GGML_TYPE_I32 || !ggml_is_contiguous(table) ||
                        int64_t(offset) + (int64_t(rows) + 15) / 16 > ggml_nelements(table) ||
                        op->src[1]->type != GGML_TYPE_F16 || op->src[2]->type != GGML_TYPE_F16 ||
                        op->src[1]->ne[1] % 16 != 0 ||
                        (op->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionCausalSlot] && rows < op->src[0]->ne[1])) {
                        return false;
                    }
                }
                if (hyle_full_f32) {
                    if (HSK != HSV''')

shader_path = 'src/ggml-vulkan/vulkan-shaders/flash_attn.comp'
shader = {'path': shader_path, 'before_sha256': hashlib.sha256((upstream / shader_path).read_bytes()).hexdigest(), 'edits': []}
edit(shader, 'layout (binding = 3) readonly buffer M {float16_t data_m[];};', '''layout (binding = 3) readonly buffer M {float16_t data_m[];};

// Private HYLE page16 mode preserves the original scalar flash arithmetic.
// The unused mask-opt port is the owned whole table; nem2 is its row offset,
// nem1 is the original query count. These fields are unused without a mask.
const bool HYLE_PAGED = (Flags & 16u) != 0;
const bool HYLE_CAUSAL = (Flags & 32u) != 0;
uint32_t hyle_kv_row(uint32_t logical_row) {
    if (!HYLE_PAGED) return logical_row;
    return (data_mask_opt[p.nem2 + (logical_row >> 4)] << 4) + (logical_row & 15u);
}''')
edit(shader, '    if (p.nem2 != 1 || p.nem3 != 1) {', '    if (MASK_ENABLE && (p.nem2 != 1 || p.nem3 != 1)) {')
original = (upstream / shader_path).read_text(encoding='utf-8')
current = original
for item in shader['edits']:
    assert current.count(item['before']) == 1
    current = current.replace(item['before'], item['after'], 1)
# Cover all row-address sites, including both duplicate register branches.
# Contexts are selected against the evolving bytes in exact manifest order.
for line in original.splitlines():
    if ('k_stride' not in line and 'v_stride' not in line) or 'j * Bc +' not in line:
        continue
    mapped = line.replace('(j * Bc + c * cols_per_iter + col_tid)', 'hyle_kv_row(j * Bc + c * cols_per_iter + col_tid)')
    mapped = mapped.replace('(j * Bc + c)', 'hyle_kv_row(j * Bc + c)')
    assert mapped != line
    while line + '\n' in current:
        pos = current.index(line + '\n')
        length = len(line) + 1
        while current.count(current[pos:pos + length]) != 1:
            length = current.index('\n', pos + length) + 1 - pos
        before = current[pos:pos + length]
        after = mapped + '\n' + before[len(line) + 1:]
        edit(shader, before, after)
        current = current.replace(before, after, 1)
edit(shader, '        float eMf[rows_per_thread];', '''        if (HYLE_CAUSAL) {
            [[unroll]] for (uint32_t r = 0; r < rows_per_thread; ++r) {
                uint32_t query_row = p.gqa_ratio > 1 ? gqa_iq1 : i * Br + tile_row(r);
                [[unroll]] for (uint32_t c = 0; c < cols_per_thread; ++c) {
                    if (j * Bc + c * cols_per_iter + col_tid > KV - p.nem1 + query_row) {
                        Sf[r][c] = ACC_TYPE(-1.0 / 0.0);
                    }
                }
            }
        }

        float eMf[rows_per_thread];''')
manifest['files'].append(shader)

for patch in manifest['files']:
    data = (upstream / patch['path']).read_bytes().replace(b'\r\n', b'\n')
    assert hashlib.sha256(data).hexdigest() == patch['before_sha256'], patch['path']
    for item in patch['edits']:
        before,after=item['before'].encode(),item['after'].encode()
        assert data.count(before)==1, (patch['path'],item['before'][:160],data.count(before))
        data=data.replace(before,after,1)
    patch['after_sha256']=hashlib.sha256(data).hexdigest()
    if patch in [host,shader]:
        path=root/'.scratch/inference-gaps/g01/native-paged/patched-preview'/patch['path']
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
manifest_path.write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
print('verified all exact patch identities; page host/scalar preview written')
