from pathlib import Path
import subprocess,json,time,os,hashlib
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';build=base/'a-vulkan/selected-graph/static-sdk-build';out=base/'g01-p1-adapter';out.mkdir(exist_ok=True)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
result_file=out/'result.json';rows=json.loads(result_file.read_text())['stages'] if result_file.exists() else []
def run(stage,args,extra=None):
    attempt=1+sum(x['stage']==stage for x in rows);log=out/f'{stage}-{attempt}.log';start=time.monotonic()
    child=env.copy();child.update(extra or {})
    with log.open('w') as f:r=subprocess.run(args,env=child,stdout=f,stderr=subprocess.STDOUT)
    row={'stage':stage,'command':args,'extra_env':extra,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
    result_file.write_text(json.dumps({'product_candidate':'d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f','scope':'adapter compile and oracle verification only; not P1 qualified timing','source_inputs':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source/'bench/inference_resident_sdpa').glob('*') if p.is_file()},'stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
    if r.returncode:
        with log.open('rb') as f:f.seek(max(0,log.stat().st_size-1800));print(f.read(1800).decode('utf-8',errors='replace'))
        raise SystemExit(r.returncode)
if next((x for x in reversed(rows) if x['stage']=='configure'),{}).get('exit_code') != 0:
    run('configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(base/'g01-p1-project.cmake')])
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_resident_bench','--parallel','4'])
binary=build/'bin/g01_resident_bench'
if not binary.exists():binary=build/'g01_resident_bench'
run('oracle',[str(binary)],{'HYLE_BENCH_VERIFY_ONLY':'1','HYLE_PERF_APPLE_QOS':'interactive'})
