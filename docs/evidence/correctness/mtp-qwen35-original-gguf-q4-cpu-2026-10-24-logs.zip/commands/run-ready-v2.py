"""Prepare only authenticated ready inputs; run one explicit bounded CPU case."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
root = Path.cwd()
sys.path.insert(0, str(root))
from engine.models.qwen35 import prepare, gguf_roles

base = root / '.scratch/qwen35-unsloth-mtp-20261024'
sources = {
    'Q4': base / 'Qwen3.5-2B-UD-Q4_K_XL/payload-role-files.json',
    'Q8': base / 'Qwen3.5-2B-UD-Q8_K_XL/payload-role-files.json',
    'CT': root / '.scratch/mtp-metadata-offline-20261024/cat00/full-text-payload/payload-role-files.json',
}

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def identity(path):
    return dict(path=path.relative_to(root).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('profile', choices=sources)
parser.add_argument('action', choices=['check', 'prepare', 'cpu-ordinary', 'cpu-k1', 'cpu-k4-random'])
parser.add_argument('--image-folder', type=Path, default=root / '.scratch/qwen-multi-draft-20261024/geometry-cpu-check2')
parser.add_argument('--run-tag', choices=['initial', 'checked-embedding'], default='initial')
args = parser.parse_args()
source = sources[args.profile]
if not source.is_file():
    print(json.dumps(dict(ready=False, reason='Authenticated complete original role binding is not published yet', source=str(source), HTTP=0)))
    sys.exit(0 if args.action == 'check' else 2)
assert load(source)['complete'] is True
if args.action == 'check':
    print(json.dumps(dict(ready=True, source=str(source), HTTP=0)))
    sys.exit(0)
folder = base / 'complete-v2' / args.profile
if args.action == 'prepare':
    if folder.exists():
        raise ValueError('Prepared output must be new; never overwrite an earlier case')
    if args.profile == 'CT':
        config = load(Path('C:/Users/kiro/Downloads/Qwen3.5-2B/config.json'))
        lines, receipt = prepare.prepare_role_files(source, True, config)
    else:
        lines, receipt = gguf_roles.prepare_role_files(source, True)
    prompt = base / 'geometry-v2-check/original/prompt.ids'
    receipt.update(preparation='Original current product V2 preparer; fixed existing token IDs reused without retokenization or copying weights.',
                   source_record=identity(source), prompt_source=identity(prompt),
                   product_scripts=[identity(root / 'engine/models/qwen35' / name)
                                    for name in ['prepare.py', 'gguf_roles.py', 'geometry.py']])
    folder.mkdir(parents=True)
    with (folder / 'weights.tsv').open('w', encoding='utf-8', newline='\n') as output:
        output.write('\n'.join(lines)+'\n')
    (folder / 'prompt.ids').write_bytes(prompt.read_bytes())
    (folder / 'input.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(prepared=True, profile=args.profile, roles=receipt['physical_roles'], weight_bytes=receipt['selected_weight_bytes'], HTTP=0)))
    sys.exit(0)
if not (folder / 'weights.tsv').is_file():
    raise ValueError('Run explicit prepare after original role acquisition completes')
run_folder = folder / (args.action if args.run_tag == 'initial' else args.action + '-' + args.run_tag)
run_folder.mkdir(exist_ok=False)
image_folder = args.image_folder.resolve()
image = image_folder / 'recursive-probe.exe'
image_identity = identity(image)
assert image_identity['sha256'] == load(image_folder / 'identity.json')['image_sha256']
ready = load(base / 'engine-check/ready-cpu.json')
env = dict(os.environ, PATH=str(image_folder)+os.pathsep+ready['PATH'])
command = [str(image), '--inputs', str(folder), '--capacity', '256', '--steps', '6' if args.action == 'cpu-k4-random' else '4',
           '--cache-bytes', str(256 << 20), '--prefix-cache', 'off', '--replay', 'commands']
command += ['--mtp', 'off' if args.action == 'cpu-ordinary' else 'on']
if args.action == 'cpu-k4-random':
    command += ['--mtp-max-drafts', '4', '--sampling', 'random', '--top-k', '8', '--top-p', '.9', '--seed', '123']
record = dict(command=command, image=image_identity, source_snapshot=identity(image_folder / 'sources.json'),
              manifest=identity(folder / 'weights.tsv'), prompt=identity(folder / 'prompt.ids'),
              scope='Bounded original complete-model functional execution using the exact retained GeometryV2 CPU image; not latest-source certification, task-quality or performance comparison.',
              SDK_builds=0, HTTP=0, started=time.time())
(run_folder / 'command.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
start = time.perf_counter()
with (run_folder / 'stdout.log').open('wb') as out, (run_folder / 'stderr.log').open('wb') as err:
    result = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err, timeout=300,
                            creationflags=subprocess.CREATE_NO_WINDOW)
record.update(exit=result.returncode, seconds=time.perf_counter()-start)
(run_folder / 'process.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(profile=args.profile, case=args.action, exit=result.returncode)))
sys.exit(result.returncode)
