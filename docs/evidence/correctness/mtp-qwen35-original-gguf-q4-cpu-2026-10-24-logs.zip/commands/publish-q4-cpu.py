from pathlib import Path
import hashlib, json, zipfile

R = Path.cwd()
B = R / '.scratch/qwen35-unsloth-mtp-20261024'
I = B / 'complete-v2/Q4'
C = R / '.scratch/qwen-multi-draft-20261024/geometry-cpu-check3'
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
source = load(B / 'Qwen3.5-2B-UD-Q4_K_XL/payload-role-files.json')
assert source['complete'] and source['source']['full_file_sha256_verified'] and len(source['roles']) == 335
cases = []
for action in ['cpu-ordinary', 'cpu-k1', 'cpu-k4-random']:
    run = I / (action + '-checked-embedding')
    p = load(run / 'process.json')
    report = load(run / 'stdout.log')
    assert p['exit'] == 0 and report['backend'] == 'cpu'
    assert report['original_device_weight_bytes'] == 0
    assert report['cache_peak_requested_bytes'] <= report['cache_requested_byte_limit']
    assert all(x['known_peak_bytes'] <= x['limit_bytes'] for x in report['workspace_domains'])
    cases.append(dict(name=action, exit=0, generated_ids=report['generated_ids'],
        generated_tokens=report['generated_tokens'], mtp=report['mtp'], sampling=report['sampling'],
        original_host_weight_bytes=report['original_host_weight_bytes'], original_device_weight_bytes=0,
        cache_peak_requested_bytes=report['cache_peak_requested_bytes'],
        cache_requested_byte_limit=report['cache_requested_byte_limit'],
        workspace_domains=report['workspace_domains'],
        proposals=[x['proposals'] for x in report.get('rounds', [])],
        consumed_drafts=report.get('consumed_drafts'), sampling_draw_cursor=report['sampling_draw_cursor']))
assert cases[0]['generated_ids'] == cases[1]['generated_ids'] == [71093,12305,198,464]
assert cases[2]['proposals'] == [4] and cases[2]['consumed_drafts'] == 4
before = I / 'cpu-ordinary'
assert load(before / 'process.json')['exit'] == 1
assert 'graph node 0: gather: no available' in (before / 'stderr.log').read_text()

files = {}
for p in I.rglob('*'):
    if p.is_file() and p.suffix in ('.json', '.log', '.tsv', '.ids'):
        files['cases/' + p.relative_to(I).as_posix()] = p
for p in (C / 'source').rglob('*'):
    if p.is_file() and p.suffix in ('.h', '.cc'):
        files['consumer-source/' + p.relative_to(C / 'source').as_posix()] = p
for name in ['identity.json', 'sources.json', 'compile-command.json', 'link-command.json',
             'compile-process.json', 'link-process.json', 'compile.log', 'link.log', 'shared-object-dependencies.json']:
    files['consumer/' + name] = C / name
for name in ['run-ready-v2.py', 'publish-q4-cpu.py']:
    files['commands/' + name] = B / name
for name in ['payload-role-files.json', 'payload-acquisition.json']:
    files['original-source/' + name] = B / 'Qwen3.5-2B-UD-Q4_K_XL' / name
dest = R / 'docs/evidence/correctness'
name = 'mtp-qwen35-original-gguf-q4-cpu-2026-10-24'
archive, record = dest / (name + '-logs.zip'), dest / (name + '.json')
assert not archive.exists() and not record.exists()
manifest = [dict(archive_path=k, **ident(p)) for k,p in sorted(files.items())]
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for k,p in sorted(files.items()): z.write(p,k)
    z.writestr('manifest.json', json.dumps(manifest, indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for x in manifest: assert hashlib.sha256(z.read(x['archive_path'])).hexdigest() == x['sha256']
result = dict(date='2026-10-24', status='PASS finite original complete-model CPU paths',
    scope='Original Qwen3.5-2B Unsloth MTP GGUF Q4 CPU ordinary/K1/K4 random; not task quality or performance comparison.',
    source=source['source'], source_id=load(I / 'input.json')['source_id'],
    original_roles=335, original_payload_bytes=1373938944, prompt_tokens=154, capacity=256,
    representation='Borrow original encoded role ranges without whole-bank floating dequantization or copied weights.',
    discovered_gap=dict(before_exit=1, diagnostic='graph node 0: gather: no available operation or region implementation covers this node',
        cause='Recipe::embedding requested unchecked IDs while original GGUF encoded row providers require checked IDs.',
        fix='Select checked Gather for encoded GGUF storage; preserve the existing unchecked dense path.',
        comparison_limit='Before and after use different retained consumer snapshots; this is functional route evidence, not an isolated timing comparison.'),
    cases=cases, consumer=ident(C / 'recursive-probe.exe'), fresh_consumer_TUs=1, SDK_builds=0,
    execution_HTTP=0, weight_copies=0,
    limits=['CPU endpoint of the retained mixed CPU/CUDA SDK; these processes use no CUDA execution.',
        'Finite generated token and state journeys do not establish full model task quality.',
        'Native-private execution allocations remain unknown; reported known workspace is not physical peak RAM.',
        'Frozen report predates the separate GGUF score-policy label correction; logits math already uses F32 activation values and encoded MatMul/F32 output.',
        'No CUDA, Apple or Vulkan complete-model GGUF claim from these CPU runs.',
        'Latest in-progress native lifetime changes are not certified by this frozen consumer.'],
    archive=ident(archive), archive_members=len(manifest)+1)
record.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(record=ident(record), archive=ident(archive), cases=len(cases))))
