#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <vector>

namespace qwen35 {
// Native generated outputs can be borrowed subranges. Their device IO need
// not support reading a single byte or widening that range into adjacent bytes.
// Publish predicates as exact F32 0/1 at that host boundary; keep internal Bool
// mathematics and the ordinary CPU/CUDA caller-owned Bool output unchanged.
template<bool NativeGenerated, class Read>
void read_host_predicates(std::span<std::uint8_t> output, Read &&read) {
  if (output.empty()) return;
  if constexpr (NativeGenerated) {
    const auto decode = [](float value) -> std::uint8_t {
      if (value != 0.0f && value != 1.0f)
        throw std::runtime_error("host predicate is not exact F32 zero or one");
      return static_cast<std::uint8_t>(value == 1.0f);
    };
    std::array<float, 16> inline_values{};
    std::vector<float> overflow;
    std::span<float> values;
    if (output.size() <= inline_values.size()) values = std::span(inline_values).first(output.size());
    else { overflow.resize(output.size()); values = overflow; }
    read(std::as_writable_bytes(values));
    for (std::size_t i = 0; i < output.size(); ++i) output[i] = decode(values[i]);
  } else {
    read(std::as_writable_bytes(output));
    for (auto value : output)
      if (value > 1) throw std::runtime_error("host predicate is not exact Bool zero or one");
  }
}
} // namespace qwen35
