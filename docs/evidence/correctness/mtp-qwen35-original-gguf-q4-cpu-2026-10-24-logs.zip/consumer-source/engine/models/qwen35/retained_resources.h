#pragma once

#include <atomic>
#include <memory>
#include <utility>

#include "hyle/compute/detail/completion_access.h"

namespace qwen35 {

// One cold node per serial execution carrier. Only an accepted original
// Completion owns the temporary scope reference. It inherits Graph's actual
// retirement attachment, so observation failure/abandonment cannot release it.
template<class Scope> struct RetainedResources final {
  std::atomic<bool> active{false};
  std::shared_ptr<Scope> owner;
  hyle::compute::detail::CompletionRetention retention;

  bool pending() const noexcept { return active.load(std::memory_order_acquire); }
  hyle::Status reserve(const std::shared_ptr<Scope> &scope) noexcept {
    if (!scope || pending())
      return hyle::Status::Unavailable("original carrier resource scope is still retained");
    owner = scope;
    active.store(true, std::memory_order_release);
    return hyle::Status::Ok();
  }
  void reject() noexcept {
    auto held = std::move(owner);
    active.store(false, std::memory_order_release);
  }
  hyle::Status attach(hyle::compute::Completion &completion) noexcept {
    if (!pending() || !owner || retention.own.valid())
      return hyle::Status::FailedPrecondition("carrier resource scope was not reserved once");
    retention.own = {this, +[](void *, const hyle::Status &) noexcept {},
        +[](void *opaque) noexcept {
          auto &node = *static_cast<RetainedResources *>(opaque);
          // Move before publication: a host may reuse an idle serial carrier.
          // The local can destroy this node's whole scope; no access follows.
          auto held = std::move(node.owner);
          node.active.store(false, std::memory_order_release);
        }};
    const auto result = hyle::compute::detail::CompletionAccess::attach_retention(completion, retention);
    if (!result.ok()) { retention = {}; reject(); }
    return result;
  }
};
} // namespace qwen35
