from pathlib import Path
import ast,hashlib,json,math,struct
import torch
torch.set_num_threads(1)
R=Path.cwd();W=R/'.scratch/nf4-typed-profile-20261025';O=W/'oracle';O.mkdir()
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
tail=read(W/'payload/kproj-tails-ready.json');old=R/'.scratch/inference-system-review-20261025/nf4-component-values';receipt=read(old/'complete.json')
prefix=[]
for part in receipt['parts']:
 p=old/part['path'];assert pin(p)['sha256']==part['sha256'];prefix.append(p.read_bytes())
tails=[]
for part in tail['parts']:
 p=R/part['path'];assert pin(p)['sha256']==part['sha256'];assert part['response']['status']==206 and part['response']['etag']==receipt['source']['etag'] and part['response']['final_url'].startswith('https://hf-mirror.net/');tails.append(p.read_bytes())
state_path=old.parent/'nf4-quant-state/quant-state.bin';raw=state_path.read_bytes();assert hashlib.sha256(raw).hexdigest()=='9210c25c0ca8632c7166cc3a92dc0cc43ffe528a45a11e3b8dde08941ed9d6c1';state=json.loads(raw)
source=R/'.scratch/validation/cpu-quant-mtp-c1/non-gguf/bnb-default-ops.py';text=source.read_text();assert pin(source)['sha256']=='e39afd16dca6e6f34a14305ade0ba4acbb49dc2c7a9baf937341d7e33b682819'
functions=[ast.get_source_segment(text,n)for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)and n.name in ('_dequantize_blockwise_compute','_dequantize_4bit_compute')];assert len(functions)==2
extracted='\n\n'.join(functions)+'\n';(O/'original-reader-functions.py').write_text(extracted);scope=dict(torch=torch,prod=math.prod,Sequence=__import__('typing').Sequence);exec(compile(extracted,str(source),'exec'),scope)
def tensor(data,dtype):return torch.frombuffer(bytearray(data),dtype=dtype)
codes=prefix[0]+tails[0];indices=prefix[1]+tails[1];nested=prefix[2]+tails[2];books=prefix[3]
assert [len(x)for x in(codes,indices,nested,books)]==[2621440,81920,1280,1088]
scales=scope['_dequantize_blockwise_compute'](tensor(indices,torch.uint8),tensor(nested,torch.float32),tensor(books[:1024],torch.float32),256,torch.float32)+torch.tensor(state['nested_offset'],dtype=torch.float32)
decoded=scope['_dequantize_4bit_compute'](tensor(codes,torch.uint8),scales,tensor(books[1024:],torch.float32),64,(1024,5120),torch.float16);assert torch.isfinite(decoded).all()
a=torch.zeros((2,5120),dtype=torch.float16);a[0,0],a[0,1],a[0,-1]=.25,-.125,.5;a[1,0],a[1,1],a[1,-1]=-.5,.125,.25
y=(a.float()@decoded.float().T).to(torch.float16);y64=(a.double()@decoded.double().T).to(torch.float16);assert torch.equal(y,y64),'F32/F64 final F16 oracle differs'
wrong=decoded.to(torch.bfloat16).to(torch.float16);wrong_y=(a.float()@wrong.float().T).to(torch.float16)
def save(name,t):
 path=O/name;path.write_bytes(t.contiguous().view(torch.uint8).numpy().tobytes());return pin(path)
result=dict(status='PASS_INDEPENDENT_FIXED_BNB_READER',source=pin(source),extracted=pin(O/'original-reader-functions.py'),shape=[1024,5120],decode_dtype='F16',decoded_values=decoded.numel(),wrong_bf16_decoded_values=int(torch.count_nonzero(decoded!=wrong)),projection_values=y.numel(),wrong_bf16_projection_values=int(torch.count_nonzero(y!=wrong_y)),F32_F64_final_F16_equal=True,outputs=[save('expected-f16.bin',decoded),save('activation-f16.bin',a),save('projection-f16.bin',y)],input_receipts=[pin(W/'payload/kproj-tails-ready.json'),pin(old/'complete.json'),pin(state_path)],new_HTTP=0)
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
