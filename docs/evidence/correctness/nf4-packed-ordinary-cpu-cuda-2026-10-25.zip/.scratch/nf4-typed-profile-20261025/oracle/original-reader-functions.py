def _dequantize_blockwise_compute(
    A_flat: torch.Tensor, absmax: torch.Tensor, code: torch.Tensor, blocksize: int, dtype: torch.dtype
):
    n = A_flat.numel()
    out = code[A_flat.to(torch.int64)]
    rem = n % blocksize
    if rem == 0:
        out = (out.reshape(-1, blocksize) * absmax.view(-1, 1)).reshape(n)
    else:
        full = n - rem
        blocks = full // blocksize
        out = torch.cat(
            [
                (out[:full].reshape(blocks, blocksize) * absmax[:blocks].view(-1, 1)).reshape(full),
                out[full:] * absmax[blocks],
            ]
        )
    return out.to(dtype)

def _dequantize_4bit_compute(
    A_flat: torch.Tensor,
    absmax: torch.Tensor,
    code: torch.Tensor,
    blocksize: int,
    shape: Sequence[int],
    dtype: torch.dtype,
):
    n = prod(shape)
    out_dq = torch.empty(A_flat.size(0) * 2, dtype=torch.int32, device=A_flat.device)
    out_dq[1::2] = A_flat & 0xF
    out_dq[::2] = A_flat >> 4
    out_dq = code[out_dq][:n]  # stays fp32, matches C++ / CUDA behavior
    rem = n % blocksize
    if rem:
        full = n - rem
        blocks = full // blocksize
        out = torch.empty(n, dtype=torch.float32, device=A_flat.device)
        out[:full] = (out_dq[:full].view(-1, blocksize) * absmax[:blocks].view(-1, 1)).reshape(full)
        out[full:] = out_dq[full:] * absmax[blocks]
    else:
        out = (out_dq.view(-1, blocksize) * absmax.view(-1, 1)).reshape(n)
    return out.reshape(-1, *shape[1:]).to(dtype)
