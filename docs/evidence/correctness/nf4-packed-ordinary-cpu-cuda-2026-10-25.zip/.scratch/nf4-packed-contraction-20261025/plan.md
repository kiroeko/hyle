NF4 packed contraction, ordinary non-grouped

- Extend existing ArtifactPackedLinear/Pattern to NF4DoubleQuant with 7 logical inputs; preserve public Decode[/Cast]/transpose/MatMul graph and decoder shape validation.
- Preserve high-first U8 codes, F32 nested lookup multiply then offset add then NF4 lookup multiply (each distinct F32 boundary), actual decoded/operand casts, F32 accumulation and output rounding.
- Increase existing bounded Graph/CPU/CUDA arrays to actual 7-port maximum; no public operation, new route policy, executor, IR or engine provider-name branching.
- CPU uses existing native mapped rows; CUDA uses existing packed_rows reduction with a typed NF4 loader. Existing CPU M>1 cost/default remains.
- Reuse full original cached 1024x5120 k_proj plus fixed BNB independent oracle. One consumer TU can test actual packed M1 and constrained packed M2, report no Graph dense-W intermediate and actual workspace; original full F16 oracle remains source authority.
- Engine raw6role residency/fallback selection is a later actual Graph materialization/space design; no engine/main/projection change in this batch. No HTTP, SDK rebuild or full model.
