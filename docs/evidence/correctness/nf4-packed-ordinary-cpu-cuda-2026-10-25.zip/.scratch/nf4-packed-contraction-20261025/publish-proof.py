from pathlib import Path
import json,hashlib,zipfile
R=Path.cwd();W=R/'.scratch/nf4-packed-contraction-20261025';old=R/'.scratch/nf4-typed-profile-20261025';pub=R/'docs/evidence/correctness'
def pin(p):p=Path(p);return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def load(p):return json.loads(Path(p).read_text())
def save(p,j):Path(p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
# Keep the five incremental product leaves live for the next engine-consumer check.
retained=[W/f'host1/{n}/unit.obj' for n in ['compute_provider_native--ct_packed','graph_route_cpu--ct_packed_linear_region','graph_route_cuda--ct_packed_linear_region','compute_provider_torch_cuda--artifact_provider']]+[W/'cuda1/unit.obj']
cleanup=[p for p in W.rglob('*')if p.is_file()and p.suffix.lower()in{'.obj','.exe','.lib','.exp','.pdb','.dll'}and p not in retained]
plan=dict(performed=False,files=[pin(p)for p in sorted(cleanup)],logical_bytes=sum(p.stat().st_size for p in cleanup),
 retained_for_next_consumer=[pin(p)for p in retained],scope='Consumer/test reproducible images and entry objects only. Five incremental Hyle leaves remain for the next source-retaining engine integration; original SDK/baseline/Graph objects excluded.')
save(W/'cleanup-candidates.json',plan)
processes=[dict(path=p.relative_to(R).as_posix(),**load(p))for p in sorted(W.rglob('process.json'))]
source_input=load(old/'fetch-plan.json')
summary=dict(status='PASS_LOW_LEVEL_NF4_PACKED_ORDINARY_CPU_CUDA',
 scope='Existing private ArtifactPackedLinear/ArtifactPackedPattern extension for the ordinary non-grouped six-input NF4DoubleQuant Decode[/Cast]/View/MatMul recipe. No public operation, new executor/IR/route policy, engine wiring or full-model completion claim.',
 source=dict(repository=source_input['repository'],revision=source_input['revision'],original_file=source_input['source'],logical_role='model.language_model.layers.3.self_attn.k_proj.weight',logical_shape=[1024,5120],original_group_bytes=2705899,HTTP_this_batch=0,full_LFS_hash_verified=False),
 actual_original_CPU=json.loads((W/'component2/run/stdout.log').read_text().strip()),
 actual_original_CUDA=json.loads((W/'component3/run-cuda/stdout.log').read_text().strip()),
 numerical_contract=dict(high_first_U8_nibbles=True,group_size=64,nested_group_size=256,
 rounding=['F32(nested_map[original_absmax_code] * original_nested_scale)','F32(previous + original_F32_offset)','F32(original_NF4_codebook[code] * previous)','actual Decode output F16','actual MatMul operand F16','F32 accumulation with backend reduction tree','output F16'],
 CPU_separate_F32_rounding='volatile pointwise products and nested sum prevent FMA contraction; original local compile flags unchanged',CUDA_separate_F32_rounding='__fmul_rn then __fadd_rn then __fmul_rn followed by existing typed RNE',
 original_3072_output_values_per_backend='bit-exact to fixed extracted original BNB reader + F16 A/F32 dot/F16 output oracle from previous evidence; no claim of full 5242880 packed-weight point outputs',
 previous_full_decoded_weight_oracle=pin(old/'oracle/result.json')),
 actual_plan=dict(original_public_nodes=3,logical_inputs=7,physical_values=8,Graph_complete_decoded_weight_values=0,Graph_workspace_bytes=0,
 CPU_M1_M2_selection='Existing RequirePrepared opt-in excludes managed decoder fallback; CPU M>1 preference1001/default cost was preserved and this is not default M2 packed selection evidence.',
 CUDA_M1_M2_selection='Existing default kAllowAny; actual original-artifacts-cuda packed region. kManaged runtime declaration unchanged.',
 opaque_provider_memory='No provider-private allocation measurement in this batch; report Graph-visible materialization/workspace separately.'),
 permanent_regression=dict(shared_fixture='tests/compute_models/nf4_packed_graph_fixture.h',
 CPU='CpuCtPackedLinear.Nf4SourceHalfRoundsAndMutableNestedOffset',CUDA='CudaCtPackedLinear.Nf4SourceHalfRoundsAndMutableNestedOffset',
 CPU_process=load(W/'permanent-test1/cpu/run/process.json'),CUDA_process=load(W/'permanent-test1/cuda/run/process.json'),
 scope='Existing CT Graph Backend fixtures; seven actual inputs, nested256 boundary crossed, F16-vs-BF16 witness, two real offset payloads through one bound Invocation, closed three-node packed plan without dense-weight physical values. Source scalar arithmetic and independent test-only RNE encoder; no model/cache/network fixture.'),
 unsupported_backends=dict(Apple='Source-level discovery/admission rejects NF4 packed recipe; independent lowerer format guard prevents treating it as CT. Original public Decode fallback unchanged.',
 Vulkan='Source-level discovery rejects NF4 packed; lowerer rejects unknown format and validates5-port capacity before writes. Original public Decode fallback unchanged.',actual_Apple_or_Vulkan_build_or_run=False),
 failures_preserved=[dict(path='component1/compile',kind='Private consumer omitted direct model_ops.h include',corrected='Explicit header included, component2 compile passed'),dict(path='component2/run-cuda',kind='Private consumer erroneously required CPU-only kPrepared on the existing CUDA kManaged packed implementation; cold compile rejected before inference',corrected='Only private CUDA test requested original allowed replay class; actual packed policy/three nodes/physical values still checked; component3 passed. Product runtime not relaxed.')],
 execution_accounting=dict(actual_original_component_processes=3,original_CPU_passes=1,CUDA_cold_contract_declines=1,CUDA_passes=1,permanent_actual_processes=2,permanent_tests_passed=2,compiler_processes=10,linker_processes=4,SDK_rebuilds=0,new_HTTP_requests=0,process_records=processes),
 product_files=load(W/'after-pins.json'),patch=pin(W/'core-changes.patch'),
 engine_status='NOT_WIRED_THIS_LOW_LEVEL_BATCH: engine still uses the separately proven cold F16 fallback; six-role resident consumer migration is a following slice. Do not claim compressed-resident full engine completion from these components.',
 limits=['No grouped NF4 support introduced.','No whole original27B inference, quality, throughput or all-backend claim.','Public Decode escapes and reader closure still follow existing ClosedRegionPattern algorithm; this batch adds no permission or retirement mechanism.','Successful numerical and lifecycle outputs do not certify zero allocation across every provider or arbitrary context.'],
 related_evidence=[dict(path='docs/evidence/correctness/nf4-f16-profile-and-cold-import-2026-10-25.zip',sha256='a000f80c35b0185bc67ab69331e3129a6afdc4fb9f38bf46c723b6ab7b93b913')],cleanup=plan)
save(W/'proof-summary.json',summary)
files=set()
blocked={'.obj','.exe','.lib','.exp','.pdb','.dll','.zip'}
for p in W.rglob('*'):
 if p.is_file()and p.suffix.lower()not in blocked and p.name!='payload-manifest.json':files.add(p)
# Reuse original receipts/source identities, independent oracle program and tiny expected projection;
# don't duplicate numeric input banks, the10MiB expected decoded matrix, SDK or previous archives.
for n in ['reference.py','oracle/original-reader-functions.py','oracle/result.json','oracle/activation-f16.bin','oracle/projection-f16.bin','fetch-plan.json','payload/source.json','payload/kproj-tails-ready.json']:
 files.add(old/n)
files.add(R/'.scratch/mtp-extraction-regression-20261024/check.py')
source_store={};payloads={};entries=[]
for p in sorted(files):
 row=pin(p);source=('source'in p.parts or 'product-final'in p.parts)and p.suffix in{'.h','.cc'}
 if source and row['sha256']in source_store:target=source_store[row['sha256']]
 else:
  target=row['path'];payloads[target]=p
  if source:source_store[row['sha256']]=target
 row['archive_payload']=target;entries.append(row)
save(W/'payload-manifest.json',dict(entries=entries,excluded='Binaries/SDK/original numeric weight bodies and complete expected dense matrix intentionally excluded; original range and whole-oracle SHA remain pinned through previous public proof and the referenced cached artifacts. Five new Hyle leaves retained only in private cache for following consumer integration.'))
payloads[(W/'payload-manifest.json').relative_to(R).as_posix()]=W/'payload-manifest.json'
archive=pub/'nf4-packed-ordinary-cpu-cuda-2026-10-25.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(payloads.items()):z.write(p,name)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for row in entries:
  b=z.read(row['archive_payload']);assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
public=dict(summary);public['archive']={**pin(archive),'CRC_verified':True,'payloads':len(payloads),'path_mapping':(W/'payload-manifest.json').relative_to(R).as_posix()}
save(pub/'nf4-packed-ordinary-cpu-cuda-2026-10-25.json',public)
print(json.dumps(dict(archive=public['archive'],products=len(summary['product_files']),cleanup_files=len(cleanup),cleanup_bytes=plan['logical_bytes'],retained_new_leaves=5,all_runs_terminal=True,GPU_released=True),indent=2))
