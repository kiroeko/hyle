#include "engine/inference/backend.h"
#include "engine/inference/prepared_output.h"
#include "engine/inference/execution_resources.h"
#include "hyle/compute/resource_leases.h"
#include "hyle/compute/model_ops.h"
#include "hyle/graph/graph.h"
#include "engine/models/qwen35/precision_profile.h"
#include "tests/compute_models/original_role_input.h"
#include "hyle/compute/prepared_operation.h"
#include <filesystem>
#include <iostream>

namespace c=hyle::compute;
namespace m=hyle::mem;
namespace q=qwen35;
namespace fs=std::filesystem;
using T=c::DataType;
template<class V> V take(hyle::Result<V> result){if(!result)throw std::runtime_error(std::string(result.error().message()));return std::move(*result);}
void check(hyle::Status status){if(!status.ok())throw std::runtime_error(std::string(status.message()));}
void require(bool yes,const char*text){if(!yes)throw std::runtime_error(text);}
using Bytes=std::vector<std::byte>;
Bytes read(const fs::path&p,std::size_t bytes,std::string_view sha){return original_role_input::read_bytes(p,bytes,sha);}
Bytes join(Bytes a,Bytes b){a.insert(a.end(),b.begin(),b.end());return a;}
c::TensorDesc dense(T type,std::initializer_list<std::int64_t> shape){return take(c::TensorDesc::dense(type,{shape.begin(),shape.size()}));}
c::ReadLease upload(const hyle::inference::Backend&backend,std::span<const std::byte> bytes){auto storage=take(m::Buffer::create(backend.device(),bytes.size(),256));check(backend.write(storage.view(),bytes));return take(backend.adopt_buffer(std::move(storage)));}
int main(int argc,char**argv){try{
 require(argc==2||argc==3,"component requires repository root [cuda]");const fs::path root=argv[1];const auto old=root/".scratch/inference-system-review-20261025/nf4-component-values";const auto work=root/".scratch/nf4-typed-profile-20261025";
 auto codes=join(read(old/"weight.bin",7680,"cbe6e709c20b76eef516b2e8bf2893c319e2621d7b5dc0f3ddf4f8d0bb00fa0a"),read(work/"payload/range-000.bin",2613760,"49d54617b7ef6288c7988ffdd8f706728caaee1a880c8eec507838a7ac325b54"));
 auto indices=join(read(old/"absmax.bin",240,"214115a8d7b2f306d036502a1bece2440c314d6e024a47099124670e71646a3f"),read(work/"payload/range-001.bin",81680,"4bb908ff3528484fba1ddd68139ba3acacf7f901069b2cb489b42a32e8fba51e"));
 auto nested=join(read(old/"nested_absmax.bin",4,"5399407b8dc0c00401a5b15f2bf8f6bc0f60b93ef32c1e81e907344525c02d12"),read(work/"payload/range-002.bin",1276,"d2b2e8d33f7d1b3f8dbb31080836b4576d4bc2d5724e641b90cb04053660c399"));
 const auto books=read(old/"codebooks.bin",1088,"9bec262dd7ad4b9a4a3a8ffb16eb4769b7f69ec89c45eae4383ffee97b888385");
 const auto raw=read(old.parent_path()/"nf4-quant-state/quant-state.bin",171,"9210c25c0ca8632c7166cc3a92dc0cc43ffe528a45a11e3b8dde08941ed9d6c1");
 const auto activation=read(work/"oracle/activation-f16.bin",20480,"bdf17bc0f53a4e44fe2f79241cfb2bf15c1e75206de4a4a750efe64298455c0e");
 const auto projection=read(work/"oracle/projection-f16.bin",4096,"9c219f6a7ce214419e941eda38f16015cbced17366d489a6119c63115745a482");
 auto state=q::prepared::parse_nf4_state({reinterpret_cast<const char*>(raw.data()),raw.size()});state.original_json_sha256="9210c25c0ca8632c7166cc3a92dc0cc43ffe528a45a11e3b8dde08941ed9d6c1";

 check(c::cpu::configure_runtime_threads(1));
 const bool cuda=argc==3&&std::string_view(argv[2])=="cuda";
 auto backend=take(hyle::inference::Backend::create({.primary=cuda?hyle::inference::BackendKind::kCuda:hyle::inference::BackendKind::kCpu}));
 const auto offset=std::bit_cast<float>(state.offset_f32_bits);
 const std::array<std::span<const std::byte>,6> payloads{codes,indices,nested,std::span(books).first(1024),std::as_bytes(std::span(&offset,1)),std::span(books).subspan(1024)};
 const std::array descriptions{dense(T::kUInt8,{1024,2560}),dense(T::kUInt8,{81920}),dense(T::kFloat32,{320}),dense(T::kFloat32,{256}),dense(T::kFloat32,{}),dense(T::kFloat32,{16})};
 std::array<c::ReadLease,6> originals;
 for(std::size_t i=0;i<6;++i)originals[i]=upload(backend,payloads[i]);
 std::array<std::string,2> providers;std::array<std::size_t,2> workspace,physical;
 for(std::size_t rows=1;rows<=2;++rows){
  namespace g=hyle::graph;namespace inf=hyle::inference;
  auto builder=take(g::GraphBuilder::create());std::array<g::ValueId,7> ports;
  const auto ad=dense(T::kFloat16,{std::int64_t(rows),5120});ports[0]=take(builder.input(ad));
  for(std::size_t i=0;i<6;++i)ports[i+1]=take(builder.input(descriptions[i]));
  const auto decode=take(builder.add_node(c::model_ops::artifact_weight_decode(c::model_ops::WeightArtifactFormat::kNf4DoubleQuant,64,T::kFloat16),std::span(ports).subspan(1)));
  const auto decoded=take(builder.result(decode));constexpr std::array<std::int32_t,2> axes{1,0};
  const auto view=take(builder.add_node(c::Operation(take(c::View::permute(axes))),std::span(&decoded,1)));const auto rhs=take(builder.result(view));
  const std::array mm_in{ports[0],rhs};const auto matrix=take(builder.add_node(c::Operation(c::MatMul{.accumulation_type=T::kFloat32}),mm_in));const auto output=take(builder.result(matrix));check(builder.publish(output));
  auto graph=take(std::move(builder).finish());
  std::array<g::ExternalResourceContract,8> contracts;for(std::size_t i=0;i<7;++i)contracts[i]={ports[i],g::StorageDomainId{0}};contracts.back()={output,g::StorageDomainId{0}};
  auto compiled=take(backend.compile(graph,{}, {.external_resources=contracts,.provider_replay=cuda?g::ProviderReplayPolicy::kAllowAny:g::ProviderReplayPolicy::kRequirePrepared}));
  require(compiled.report.step_count()==1,"NF4 graph did not contract into one prepared region");const auto step=take(compiled.report.step(0));
  require(step.policy==g::kArtifactPackedProjectionPolicy&&step.node_count==3,"NF4 typed public3-node chain is not the packed artifact policy");providers[rows-1]=std::string(step.provider.name);
  std::size_t floating_weights=0;
  for(std::size_t i=0;i<compiled.report.physical_value_count();++i){const auto v=take(compiled.report.physical_value(i));const auto&d=v.description;if(d.rank()==2&&d.data_type()==T::kFloat16&&take(d.element_count())==5242880)++floating_weights;}
  require(floating_weights==0,"NF4 packed graph materialized a full F16 weight bank");
  auto facts=take(inf::prepare_output(compiled,output));auto a=upload(backend,std::span(activation).first(rows*5120*2));
  c::LeasePool pool; c::WriteLease writer;
  if(facts.caller_owned()){pool=take(c::LeasePool::create(backend.device(),rows*1024*2,{.max_blocks=1}));writer=take(pool.allocate(rows*1024*2));}
  auto run=take(compiled.executable.create_invocation());check(run.prepare_resources());check(run.bind(ports[0],ad,a));for(std::size_t i=0;i<6;++i)check(run.bind(ports[i+1],descriptions[i],originals[i]));
  if(facts.caller_owned())check(run.bind(output,facts.description,std::move(writer)));
  auto q=take(inf::prepare_queue_bindings(backend.queue_bindings(),compiled.report));const auto queues=inf::queue_span(q);
  check(run.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}));auto done=take(run.submit(queues));check(done.wait());auto ready=take(inf::retain_output(run,facts));
  Bytes got(rows*1024*2);check(backend.read(take(ready.view()),got));require(std::equal(got.begin(),got.end(),projection.begin()),"original NF4 packed F16 projection differs from fixed independent BNB reader");
  workspace[rows-1]=compiled.executable.workspace_bytes();physical[rows-1]=compiled.report.physical_value_count();
  ready={};check(run.close());check(backend.drain_retired(run));
 }
 std::cout<<"{\"status\":\"PASS\",\"backend\":\""<<(cuda?"CUDA":"CPU")<<"\",\"original_shape\":[1024,5120],\"original_numeric_inputs\":6,\"logical_input_ports\":7,\"decoded_operand_output\":\"F16\",\"scale_boundaries\":\"F32_mul_add_mul\",\"ordinary_rows\":[1,2],\"output_values\":3072,\"packed_public_nodes\":[3,3],\"providers\":[\""<<providers[0]<<"\",\""<<providers[1]<<"\"],\"Graph_full_F16_weight_values\":0,\"Graph_workspace_bytes\":["<<workspace[0]<<','<<workspace[1]<<"],\"physical_values\":["<<physical[0]<<','<<physical[1]<<"],\"selection\":\""<<(cuda?"default_managed_capability_actual_packed":"existing_CPU_RequirePrepared_contract")<<"\",\"private_dequantization_unknown\":true,\"full_model\":false}\n";
 return 0;
}catch(const std::exception&e){std::cerr<<"original NF4 packed: "<<e.what()<<'\n';return 1;}}
