from pathlib import Path
import importlib.util,sys,re,shutil,hashlib,json
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/nf4-packed-contraction-20261025';A=W/'permanent-test1';A.mkdir();S=A/'source';S.mkdir()
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
todo=[R/'tests/graph_route_cpu/ct_packed_linear_test.cc',R/'tests/graph_route_cuda/ct_packed_linear_test.cc'];seen=set()
while todo:
 p=todo.pop().resolve()
 if p in seen:continue
 seen.add(p);d=S/p.relative_to(R);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
 for q in re.findall(r'^\s*#\s*include\s*"([^"]+)"',p.read_text(),re.M):
  n=(p.parent/q).resolve()
  if n.is_file()and n.is_relative_to(R/'tests'):todo.append(n)
b.save(A/'source-pins.json',[b.pin(p)for p in S.rglob('*')if p.is_file()])
old=R/'.scratch/architecture-refactor-2026-10-18/ct-packed-linear/checks/attempt1/tests--graph_route_cuda--ct_packed_linear_test-compile.command.json';base=b.args(old);env=b.environment(base[0])
for kind in ['cpu','cuda']:
 folder=A/kind/'compile';cmd=[base[0],'/I'+str(S)];skip=False
 for arg in base[1:]:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.lower().startswith(('/fo','/fd'))or arg.lower().endswith(('.cc','.cpp')):continue
  cmd.append(arg)
 cmd+=['/sourceDependencies',str(folder/'dependencies.json'),str(S/f'tests/graph_route_{kind}/ct_packed_linear_test.cc'),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
 b.execute(cmd,folder,env,120)
 # Reuse the exact new low-level closure, replacing entry only; no new SDK or application.
 link=[]
 for arg in b.args(W/'component3/link/command.json'):
  if arg.lower().startswith(('/out:','/map:','/pdb:','/implib:')):continue
  if arg==str(W/'component3/compile/component.obj'):arg=str(folder/'unit.obj')
  link.append(arg)
 for name in ['gtest.lib','gtest_main.lib']:
  p=R/'.scratch/build-compute-v2-dev/lib'/name;assert p.is_file();link.append(str(p))
 link+=['/OUT:'+str(A/kind/'link/checks.exe'),'/PDB:'+str(A/kind/'link/checks.pdb'),'/IMPLIB:'+str(A/kind/'link/checks.lib')]
 b.execute(link,A/kind/'link',env,60)
print('permanent CPU/CUDA fixtures compiled and linked; GPU not run')
