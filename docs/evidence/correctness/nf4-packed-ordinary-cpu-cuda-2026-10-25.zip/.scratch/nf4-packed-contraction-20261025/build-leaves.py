from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/nf4-packed-contraction-20261025';S=W/'source'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
H=R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1'
compiler=b.args(H/'records/compute_provider_native--ct_packed/run/command.json')[0];env=b.environment(compiler)
if sys.argv[1]=='host':
 for name,src in [('compute_provider_native--ct_packed','src/compute_provider_native/ct_packed.cc'),('graph_route_cpu--ct_packed_linear_region','src/graph_route_cpu/ct_packed_linear_region.cc'),('graph_route_cuda--ct_packed_linear_region','src/graph_route_cuda/ct_packed_linear_region.cc'),('compute_provider_torch_cuda--artifact_provider','src/compute_provider_torch_cuda/artifact_provider.cc')]:
  cmd=b.args(H/f'records/{name}/run/command.json');new=[cmd[0],'/I'+str(S)];skip=False;folder=W/'host1'/name
  for arg in cmd[1:]:
   if skip:skip=False;continue
   if arg=='/sourceDependencies':skip=True;continue
   if arg.lower().startswith(('/fo','/fd'))or arg.lower().endswith(('.cc','.cpp')):continue
   new.append(arg)
  new +=['/sourceDependencies',str(folder/'dependencies.json'),str(S/src),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
  b.execute(new,folder,env,180)
else:
 old=R/'.scratch/architecture-refactor-2026-10-18/quark-fp8-side-2026-10-21/windows/checks/attempt1/cuda-mlx-packed-kernel/compile.command.json';cmd=b.args(old);new=[cmd[0],'-I'+str(S)];skip=False;folder=W/'cuda1'
 for arg in cmd[1:]:
  if skip:skip=False;continue
  if arg in ['-MT','-MF','-o']:skip=True;continue
  if arg.lower().endswith('.cu')or arg.lower().startswith('-xcompiler=-fd'):continue
  new.append(arg)
 new+=['-MT',str(folder/'unit.obj'),'-MF',str(folder/'dependencies.d'),str(S/'src/compute_provider_torch_cuda/mlx_packed_kernel.cu'),'-o',str(folder/'unit.obj'),'-Xcompiler=-Fd'+str(folder/'unit.pdb')+',-FS']
 b.execute(new,folder,env,180)
