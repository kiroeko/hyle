"""Update current facts after two original-attention and two shared-LM checks."""
from pathlib import Path
import argparse
import hashlib
import json

R=Path(__file__).resolve().parents[2]
S=Path(__file__).resolve().parent
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
p=argparse.ArgumentParser();p.add_argument('--runs',type=int,nargs='+',required=True);args=p.parse_args()
runs=[read(S/f'checks{i}/summary.json') for i in args.runs]
assert sum(r['tests'] for r in runs)==4
assert all(r['process']['exit']==0 and not r['process']['timed_out'] and
    not any(r[k] for k in ('failures','errors','disabled','skips')) for r in runs)
cases=[case for run in runs for case in run['cases']]
assert sum(int(case['properties']['actual_submissions']) for case in cases)==114
p=R/'docs/developer/current-work.md';t=p.read_text(encoding='utf-8-sig')
def change(old,new):
    global t
    assert t.count(old)==1,old
    t=t.replace(old,new)
change('GLM官方17原角色已进入完整NextN输入／query／indexer及共享全词表embedding／head／norm，真实预测ID反馈和接受后追赶CPU／CUDA通过；',
       'GLM官方26原角色已进入完整NextN输入／query／indexer、原attention／postnorm及共享全词表embedding／head／norm，真实预测ID反馈和接受后追赶CPU／CUDA通过；')
change('GLM Flash原17参数与全词表预测反馈','GLM Flash原26参数、attention及全词表预测反馈')
change('下一步继续GLM等其余原角色、真实target taps、Pro实际几何与已确认适用量化组合。',
       '下一步继续GLM原MoE／FFN等剩余角色、真实target taps、Pro实际几何与已确认适用量化组合。')
start=t.index('**最近已验证进展**：');end=t.index('前批[DSpark原专家]',start)
t=t[:start]+'''**最近已验证进展**：[GLM原attention接线](../evidence/correctness/mtp-glm-original-attention-2026-10-23.json)新增9原角色（127,958,528B），将q_b／kv_a／o三份原E4＋F32 block128 scale、原BF16 kv_b、kvnorm及post-attention norm接入已有完整状态／词表反馈。原kv_b只做一次冷Graph布局准备，得到两份共享BF16吸收bank，共33,554,432B；原device临时bank随后释放，无逐token重排或整份F32权重副本。主MLA保持64头、NoPE256、latent512、value256及scale1/16。

CPU／CUDA新旅程各29次Graph（28状态旅程＋1冷布局），旧17原角色共享LM回归各28次，共4项、114次Graph，通过且无跳过。三新FP8投影和两BF16 BMM首轮全量、后续固定行参考与各步原BF16边界检查保留；postnorm用实际F32残差和算RMS，另存BF16残差供后续相加。26原角色共2,753,893,888B。target hidden／verifier及MoE／FFN仍生成，F32 cache载体只写入实际BF16 latent的精确扩宽；没有新质量、TPS或物理内存／显存峰值结论，页末AV对比保持原样。[前批共享LM](../evidence/correctness/mtp-glm-shared-lm-2026-10-23.json)的完整词表预测、接受0／1／2与跨轮状态机制继续复用。

'''+t[end:]
start=t.index('- **GLM-Flash**：');end=t.index('- **DSpark**：',start)
t=t[:start]+'''- **GLM-Flash**：[26原角色](../evidence/correctness/mtp-glm-original-attention-2026-10-23.json)包含7 input／query、7 indexer、3 shared LM和9 attention／postnorm原角色。三份E4投影保动态A128 Divide／floor1e-10，kv_b原BF16按头派生两吸收bank、冷准备一次；原indexer仍保BF16 rings／E4 pools＋F32 scales和PowerOfTwo／floor1e-4。主cache的F32载体写实际BF16 latent扩宽，attention／BMM返回、原postnorm及残差返回的BF16边界已接；原全V embedding／head／norm、真实ID反馈、17项状态＋epoch接受0／1／2、skip、catchup和epoch8 seed已有CPU／CUDA检查。生成参数的[43→44→NextN](../evidence/correctness/mtp-encoded-state-2026-10-23.json)34资源＋epoch组合旧证据保留。target hidden／verifier与MoE／FFN仍生成，原45层模型、Pro几何、其它量化与自然接受率未完成，不把F32载体等同vendor页ABI。
'''+t[end:]
change('原GLM17角色与共享LM反馈、DSpark83角色已接，下一步其余角色／真实target taps／Pro几何与已确认量化组合，最后完整性能对照',
       '原GLM26角色与attention／共享LM反馈、DSpark83角色已接，下一步MoE／FFN等剩余角色／真实target taps／Pro几何与已确认量化组合，最后完整性能对照')
tail=t[t.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest()==read(S/'before.json')['protected_performance_tail_sha256']
p.write_text(t,encoding='utf-8',newline='\n')

p=R/'docs/implementation/model-operators.md';t=p.read_text(encoding='utf-8-sig')
change('共17原角色。其余MLA／MoE与target边界仍生成，原45层及Pro几何未完成',
       '[原attention／postnorm9角色](../evidence/correctness/mtp-glm-original-attention-2026-10-23.json)又接原三E4投影、同源BF16 kv_b吸收、kvnorm与postnorm，共26原角色；MoE／FFN与target边界仍生成，原45层及Pro几何未完成')
needle='前述34资源与DSpark组合保留[编码状态证据]'
assert t.count(needle)==1
t=t.replace(needle,'原attention又补9角色127,958,528B，共26角色2,753,893,888B；一次冷Graph从单原kv_b派生共享K／V的BF16布局并退掉原device临时bank，热路径普通BF16 batchMatMul及compact CKV attention保64头／NoPE256／latent512／value256、scale1/16。F32 cache载体保实际BF16latent值；postnorm以F32残差和计算，另存BF16残差返回。CPU／CUDA各29Graph与旧17角色回归各28通过，无新TPS或物理峰值。'+needle)
p.write_text(t,encoding='utf-8',newline='\n')
print('UPDATED current facts; AV performance tail unchanged')
