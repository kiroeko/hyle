"""Publish original GLM NextN attention/shared-LM/state results, without weights."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p)
    with p.open('rb') as stream: sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix() if p.is_relative_to(R) else str(p),bytes=p.stat().st_size,sha256=sha)
def verify(row):
    current=identity(R/row['path'])
    assert current['bytes']==row['bytes'] and current['sha256']==row['sha256'],row['path']

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--new-runs',type=int,nargs='+',required=True)
p.add_argument('--regression-runs',type=int,nargs='+',required=True)
p.add_argument('--link-attempt',type=int,required=True)
p.add_argument('--freeze',default='source')
args=p.parse_args()
indices=[*args.new_runs,*args.regression_runs]
runs=[read(S/f'checks{i}/summary.json') for i in indices]
image=read(S/f'tests-link{args.link_attempt}/ready.json')['image'];verify(image)
for run in runs:
    assert run['image']==image and run['process']['exit']==0 and not run['process']['timed_out']
    assert not any(run[k] for k in ('failures','errors','disabled','skips'))
new=[case for run in runs[:len(args.new_runs)] for case in run['cases']]
related=[case for run in runs[len(args.new_runs):] for case in run['cases']]
assert len(new)==len(related)==2
for case in new:
    props=case['properties']
    assert props['original_roles']=='26' and props['original_role_bytes']=='2753893888'
    assert props['actual_submissions']=='29' and props['shared_lm_full_f64_scores_checked']=='154880'
    assert props['attention_cold_layout_submissions']=='1'
    assert props['attention_raw_kv_device_bank_retained']=='0'
    assert props['attention_prepared_kv_bf16_capacity_bytes']=='33554432'
    assert props['attention_full_local_projection_values_checked']=='70144'
    assert props['attention_calls_checked']=='20'
for case in related:
    assert case['properties']['original_roles']=='17' and case['properties']['actual_submissions']=='28'
freeze_path=S/args.freeze/'freeze.json';freeze=read(freeze_path)
frozen=[*freeze.get('source',[]),*freeze.get('dependencies',[]),*freeze.get('files',[])]
assert len(frozen)>=3
for row in frozen: verify(row)
link_path=S/f'tests-link{args.link_attempt}/link-plan.json';link=read(link_path)
for row in link['inputs']: verify(row)
for row in link['compiled_records']:
    verify(row)
    if Path(row['path']).is_relative_to(S):
        rec=read(row['path'])
        for item in (rec['source'],rec['object'],*rec['dependencies']): verify(item)
acquisition=read(S/'original-attention/acquisition.json')
assert acquisition['complete'] and acquisition['original_roles']==9
assert acquisition['role_payload_bytes']==acquisition['successful_request_body_bytes']==127958528
for role in acquisition['roles']:
    assert role['complete'];verify(role['payload'])
before=read(S/'before.json');protected=before['protected_qwen_image'];verify(protected.get('image',protected))
t=(R/'docs/developer/current-work.md').read_text(encoding='utf-8-sig');tail=t[t.index('## 最新完整性能对比'):]
tail_hash=hashlib.sha256(tail.encode()).hexdigest()
assert tail_hash==before['protected_performance_tail_sha256']
sources=[R/rel for rel in ('tests/compute_models/glm_original_attention_roles.h',
    'tests/compute_models/glm_original_attention_reference.h',
    'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'docs/developer/current-work.md','docs/implementation/model-operators.md')]
metadata=[R/rel for rel in ('.scratch/glm-mtp-carry-20261022/original-glm-q-a/header.json',
    '.scratch/glm-mtp-carry-20261022/original-glm-q-a/acquisition.json',
    '.scratch/glm-encoded-state-20261023/review/fixed-source/models/deepseek_nextn.py',
    '.scratch/glm-encoded-state-20261023/review/fixed-source/models/glm5_next.py')]
assert all(path.is_file() for path in [*sources,*metadata])
files=set(sources+metadata)
files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in
    ('.h','.cc','.py','.json','.txt','.log','.xml','.ps1','.diff'))
files.discard(S/'publication.json')
archive=D/'mtp-glm-original-attention-2026-10-23.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as zipped:
    for path in sorted(files): zipped.write(path,path.relative_to(R).as_posix())
prior=[]
for folder in sorted(S.glob('checks*')):
    if (folder/'summary.json').is_file() and int(folder.name[6:]) not in indices:
        prior.append(read(folder/'summary.json'))
record=dict(date='2026-10-23',stage='BO',goal_complete=False,
    conclusion='Nine original GLM-5.3-Flash attention/postnorm roles now feed the complete NextN indexer, shared vocabulary and accepted-state journey on CPU/CUDA, including original BF16 storage boundaries.',
    artifact=dict(repository=acquisition['repository'],revision=acquisition['revision'],original_roles=26,
        original_role_bytes=2753893888,additional_original_roles=9,additional_original_payload_bytes=127958528,
        acquisition=acquisition,weight_bodies_archived=False),
    implementation=dict(
        projection='Original q_b/kv_a/o E4 codes plus F32 block128 scales enter the existing canonical importer and dynamic A128 Divide/floor1e-10 projection. Actual BF16 input and output boundaries remain explicit.',
        absorption='One original BF16 kv_b[32768,512] supplies both per-head key/value matrices. One ordinary cold Graph prepares dense BF16 layouts, shared by all hot recipes. The original device kv_b source retires after preparation; no whole F32 weight shadow or hot per-head repacking.',
        attention='64 heads, NoPE256, latent512, value256, no RoPE; scale remains1/16. Existing selected IDs and compact CKV Gather/SDPA stay shared. The F32 cache carrier stores exact widening of actual BF16 latent rows, not unrounded F32 values; actual attention return stores BF16 before value absorption.',
        residual='Post-attention norm uses the actual F32 EH+O sum and original BF16 gamma. The separate residual return stores BF16 for subsequent FFN addition; the norm does not consume a prematurely rounded residual.',
        state='The same complete state store, one atomic Head, accepted prefixes0/1/2, target bonus policy, epoch seed, indexer skip, journal/direct catchup, full-vocabulary greedy feedback and old readonly results remain.'),
    validation=dict(tests=4,failures=0,errors=0,skips=0,
        graph_submissions=sum(int(case['properties']['actual_submissions']) for case in [*new,*related]),
        new_graph_submissions=58,new_cold_weight_layout_graphs=2,related_graph_submissions=56,
        new_full_local_projection_outputs=140288,new_full_f64_head_scores=309760,
        new_attention_and_prediction_episodes=40,
        new_cases=new,related_cases=related,
        results=[identity(S/f'checks{i}/summary.json') for i in indices],
        source_freeze=identity(freeze_path),linked_inputs=identity(link_path),
        host_translation_units=1,host_compile_attempts=len(list(S.glob('compile*/*/plan.json'))),
        prior_attempts=prior,SDK_builds=0,native_CPU_builds=0,NVCC_builds=0,shaders=0),
    limitations=['Finite Windows CPU/CUDA journey, not all systems/shapes/codecs.',
        'Target hidden/taps/verifier and MoE/FFN remain explicit generated boundaries; not the full trained45-layer model.',
        'F32 cache carrier and generated initial history are not a vendor FP8 page ABI or original target capture.',
        'Pro6144 geometry, other original roles and confirmed quantization combinations remain unfinished.',
        'No new quality, natural acceptance, TPS/loading or physical memory/VRAM peak claim; latestAV comparison is unchanged.',
        'MTP and the broader goal remain incomplete.'],
    remaining='Original MoE/FFN roles, real target taps, actual Pro geometry and confirmed applicable quantization combinations; final necessary regressions and complete ordinary/MTP performance comparison before images.',
    final_image=image,sources=[identity(path) for path in sources],source_metadata=[identity(path) for path in metadata],
    performance_tail_sha256=tail_hash,archive=identity(archive),archive_items=len(files))
destination=D/'mtp-glm-original-attention-2026-10-23.json';assert not destination.exists()
destination.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
publication=dict(evidence=identity(destination),archive=identity(archive))
(S/'publication.json').write_text(json.dumps(publication,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(**publication,tests=4,graphs=record['validation']['graph_submissions'])))
