from pathlib import Path
import json

W=Path(__file__).resolve().parent
R=W.parents[1]
source=(R/'tests/compute_models/kimi_heterogeneous_state_consumer_test.cc').read_text()
helper=r'''
void capture_diagnostic(g::Invocation &run,const char *stage,const g::CompileReport &report,const g::Graph &graph) {
  const auto reusable=g::detail::ReplayAccess::can_reuse_capture(run,{});
  std::fprintf(stderr,"DIAG stage=%s canReuse=%d\n",stage,reusable?int(*reusable):-1);
  const auto *state=g::detail::InvocationAccess::state(run);
  const auto &plan=*state->plan;
  for(std::size_t at=0;at<plan.steps.size();++at) {
    const auto &step=plan.steps[at];if(!step.emits_command())continue;
    bool captured=false;
    for(const auto &range:plan.capture_ranges)
      if(at>=range.step_begin&&at-range.step_begin<range.step_count)captured=true;
    const auto runtime=step.runtime_properties();
    const auto identity=step.provider();
    std::fprintf(stderr,"DIAG provider step=%zu name=%.*s\n",at,int(identity.name.size()),identity.name.data());
    const auto info=report.step(at).value();
    for(std::size_t j=0;j<info.node_count;++j) {
      const auto node=report.step_node(at,j).value();
      std::fprintf(stderr,"DIAG operation step=%zu node=%u kind=%u\n",at,node.ordinal(),unsigned(graph.operation(node).value().kind()));
    }
    std::fprintf(stderr,"DIAG step=%zu captured=%u mode=%u class=%u blocks=%u compatible=%u stable=%u nativeInputs=%u region=%u\n",
        at,unsigned(captured),unsigned(runtime.mode),unsigned(runtime.replay_class),unsigned(runtime.blocks_host),
        unsigned(runtime.capture_compatible),unsigned(state->step_bindings[at].stable_binding_identity),
        unsigned(state->step_bindings[at].native_inputs),unsigned(step.region.valid()));
    if(captured&&step.region.valid())
      std::fprintf(stderr,"DIAG step=%zu viewsOnly=%u preserveBindings=%u\n",at,
          unsigned(g::detail::RegionAccess::borrows_tensor_views_only(step.region)),
          unsigned(g::detail::RegionAccess::preserves_capture_bindings(state->invocations[at].region)));
  }
  for(const auto &saved:state->capture_rebuilds)
    std::fprintf(stderr,"DIAG range=%u+%u qualified=%u privateStable=%u active=%u key0=%u key1=%u\n",
        saved.step_begin,saved.step_count,unsigned(saved.qualification_valid),unsigned(saved.preserves_private_arguments),
        unsigned(saved.active_variant),unsigned(saved.variants[0].key_valid),unsigned(saved.variants[1].key_valid));
}
'''
source='#include "src/graph/plan_state.h"\n#include "hyle/graph/detail/replay_access.h"\n'+source
anchor='struct Literal final {'
assert source.count(anchor)==1
source=source.replace(anchor,helper+'\n'+anchor)
anchor='      const auto report=replay_report(episode,"consumer-cold-prepare");'
assert source.count(anchor)==1
source=source.replace(anchor,anchor+'\n      capture_diagnostic(*episode.run,"ready-before-handoff",cold_program->compiled.report,logical.graph);')
anchor='      check(episode.bind_consumers(logical.graph),"Kimi original consumer bundle");'
assert source.count(anchor)==1
source=source.replace(anchor,anchor+'\n      if(previous)capture_diagnostic(run,"source-bound-before-reuse",cold_program->compiled.report,logical.graph);')
copy=W/'diagnostic.cc';copy.write_text(source)
p=W/'plan.json';plan=json.loads(p.read_text());prior=plan['units']['kimi'];folder=W/'compile/diagnostic';folder.mkdir(exist_ok=True)
args=[]
for index,arg in enumerate(prior['compile']):
    if index and prior['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
    elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
    elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
    elif Path(arg)==Path(prior['source']):arg=str(copy)
    args.append(arg)
link=[]
for arg in prior['link']:
    if arg==str(W/'compile/kimi/unit.obj'):arg=str(folder/'unit.obj')
    for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
        if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/diagnostic').with_suffix(suffix));break
    link.append(arg)
plan['units']['diagnostic']=dict(source=str(copy),compile=args,link=link)
plan['cases']['kimi-diagnostic']=dict(unit='diagnostic',tests=1,filter='KimiHeterogeneousState.CudaOriginalGeometrySyntheticKdaMlaPublishesWholeStateAndRestoresForks')
p.write_text(json.dumps(plan,indent=2)+'\n')
print('Prepared metadata-only diagnostic consumer; original SDK reused, one synthetic case, no behavior gate changed.')
