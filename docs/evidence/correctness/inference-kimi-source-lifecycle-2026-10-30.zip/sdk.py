from pathlib import Path
import importlib.util
import json
import shutil
import sys

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('batch',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,key=b.read,b.save,b.pin,b.key

def command(path):
    data=read(path);return data['command'] if isinstance(data,dict) else data

def prepare():
    plan=read(W/'plan.json')
    prior=read(R/'.scratch/inference-packed-gdn-prefixes-20261029/plan.json')['units']['cuda-provider']
    entries=[('registration',R/'src/compute_provider_cuda/cuda_provider.cc',command(prior['recipe']['path']),
              R/'.scratch/inference-packed-gdn-prefixes-20261029/compile/cuda-provider/unit.obj'),
        ('scatter-provider',R/'src/compute_provider_cuda/scatter_provider.cc',command(R/'.scratch/inference-current-closure-20261026/headers79/compute_provider_cuda--scatter_provider_cc/command.json'),
              R/'.scratch/inference-current-closure-20261026/headers79/compute_provider_cuda--scatter_provider_cc/unit.obj'),
        ('collectives-provider',R/'src/compute_provider_cuda/collectives_provider.cc',command(R/'.scratch/inference-slot-source-fallback-20261027/compile5/cccl/command.json'),
              R/'.scratch/inference-slot-source-fallback-20261027/compile5/cccl/unit.obj')]
    replacements=[]
    for name,source,recipe,old in entries:
        folder=W/'compile'/name;folder.mkdir(exist_ok=True)
        args=[]
        for index,arg in enumerate(recipe):
            if index and recipe[index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            args.append(arg)
        assert sum(key(a)==key(source) for a in args)==1
        assert any(a.lower()=='/sourcedependencies' for a in args)
        plan['units'][name]=dict(source=str(source),compile=args)
        replacements.append(dict(unit=name,old=str(old),object=str(folder/'unit.obj')))
    native=command(R/'.scratch/inference-model-submission-source-20261027/logs/topk_kernel-retry2/command.json')
    folder=W/'compile/collectives-kernel';folder.mkdir(exist_ok=True)
    for index in range(len(native)):
        if index and native[index-1] in ('-MT','-o'):native[index]=str(folder/'unit.obj')
        elif index and native[index-1]=='-MF':native[index]=str(folder/'unit.d')
    plan['native']=dict(source=str(R/'src/compute_provider_cuda/collectives.cu'),compile=native)
    replacements.append(dict(unit='collectives-kernel',old=str(R/'.scratch/inference-model-submission-source-20261027/compile/topk_kernel/unit.obj'),object=str(folder/'unit.obj')))
    template=plan['units']['kimi']
    for name,file in [('scan-test','tests/graph_route_cuda/scan_test.cc'),
                      ('collectives-test','tests/compute_provider_cuda/collectives_test.cc'),
                      ('scatter-test','tests/compute_provider_cuda/scatter_test.cc')]:
        folder=W/'compile'/name;folder.mkdir(exist_ok=True);source=R/file
        args=[]
        for index,arg in enumerate(template['compile']):
            if index and template['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            elif key(arg)==key(template['source']):arg=str(source)
            args.append(arg)
        links=[]
        for arg in template['link']:
            if key(arg)==key(W/'compile/kimi/unit.obj'):arg=str(folder/'unit.obj')
            for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
                if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
            links.append(arg)
        plan['units'][name]=dict(source=str(source),compile=args,link=links)
    plan['sdk_replacements']=replacements
    plan['cases'].update({
        'scan-cuda':dict(unit='scan-test',tests=2,filter='CudaDefaultGraph.IntegerScanOverflowPreservesOutputAndRecovers:CudaDefaultGraph.CapturedIntegerScanOverflowPreservesOutputAndRecovers'),
        'scatter-cuda':dict(unit='scatter-test',tests=4,filter='CudaScatter.*'),
        'collectives-cuda':dict(unit='collectives-test',tests=4,filter='CudaCccl.ScanAxesByteStridesBroadcastAndHighRanks:CudaCccl.OverflowChecksEveryPrefixAndPreservesEntireOutput:CudaCccl.WorkspaceAliasesAndExternalCaptureRejectBeforeWriting:CudaCccl.SingleRowTopOneDenseAndGenericLayoutsKeepStableOriginalBits')})
    save(W/'plan.json',plan)
    print('Prepared three affected provider CXX units, one original CUDA TU and three bounded correctness consumers; no tools started.')

def native(attempt):
    plan=read(W/'plan.json');folder=W/'compile/collectives-kernel'
    b.b.b.execute(plan['native']['compile'],folder/attempt,300)
    result=dict(object=pin(folder/'unit.obj'),dependencies=pin(folder/'unit.d'),
        process=pin(folder/attempt/'process.json'),source_identities=[pin(R/p) for p in
            ('src/compute_provider_cuda/collectives.cu','src/compute_provider_cuda/collectives.h','src/compute_backend_cuda/device_status_kernel.h')])
    save(folder/'receipt.json',result);save(folder/attempt/'receipt.json',result)

def seal():
    plan=read(W/'plan.json');sdk=read(plan['sdk']['path'])
    for replacement in plan['sdk_replacements']:
        receipt=read(W/'compile'/replacement['unit']/'receipt.json')
        b.exact(receipt['object'])
        for identity in receipt['source_identities']:b.exact(identity)
        old=replacement['old'];replacement['new']=receipt['object']
        assert sum(key(x['path'])==key(old) for x in plan['retained'])==1
        plan['retained']=[receipt['object'] if key(x['path'])==key(old) else x for x in plan['retained']]
        for unit in plan['units'].values():
            if 'link' in unit:unit['link']=[receipt['object']['path'] if key(x)==key(old) else x for x in unit['link']]
        for item in sdk['inspected']:
            if key(item['object'])==key(old):
                item.update(object=receipt['object']['path'],dependencies=pin(W/'compile'/replacement['unit']/'dependencies.json'))
        if replacement['unit']=='collectives-kernel':
            sdk['unavailable']=[x for x in sdk['unavailable'] if key(x)!=key(old)]
            sdk.setdefault('native_consumers',[]).append(dict(object=receipt['object']['path'],receipt=pin(W/'compile/collectives-kernel/receipt.json')))
    assert len(plan['retained'])==227
    save(W/'sdk-engine-dependencies.json',sdk);plan['sdk']=pin(W/'sdk-engine-dependencies.json')
    save(W/'plan.json',plan)
    print('Sealed four refreshed original SDK inputs; 223 unchanged inputs retained, no duplicate legacy kernels.')

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='native':native(sys.argv[2])
    elif sys.argv[1]=='seal':seal()
