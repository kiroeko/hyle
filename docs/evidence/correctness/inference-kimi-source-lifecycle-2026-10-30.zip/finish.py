from pathlib import Path
import importlib.util
import json
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('batch', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin = b.read, b.save, b.pin


def fixture():
    plan = read(W / 'plan.json')
    directory = W / 'continuous-input-sdk4'
    directory.mkdir(exist_ok=False)
    original = R / '.scratch/inference-continuous-wave-20261027/inputs/context32'
    for name in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(original / name, directory / name)
    plan['cases']['continuous-cuda']['args'] = ['--cuda-continuous', str(directory)]
    save(W / 'plan.json', plan)
    print('Prepared only two original metadata files; absolute payload paths reused, no download.')


def prepare_report():
    plan = read(W / 'plan.json')
    base = read(plan['base']['path'])
    for unit in ('kimi', 'model', 'ordinary', 'scan-test', 'collectives-test', 'scatter-test'):
        b.b.receipt(unit)
    for item in plan['retained']:
        b.exact(item)
    save(W / 'model-link-base.json', dict(schema='hyle.kimi-source-lifecycle.current-link-base.v1',
        base=plan['base'], compile=plan['units']['model']['compile'], link=plan['units']['model']['link'],
        consumer_source=pin(plan['units']['model']['source']), previous_consumer=pin(W / 'compile/model/receipt.json'),
        retained=plan['retained'], runtime=plan['runtime'], sdk_engine_dependencies=plan['sdk']))
    final_attempts = {'scan-cuda': 'attempt1', 'collectives-cuda': 'attempt2', 'scatter-cuda': 'attempt1',
        'kimi-cuda': 'attempt4', 'natural-cuda': 'attempt2', 'continuous-cuda': 'attempt2'}
    runs = []
    for name, attempt in final_attempts.items():
        folder = W / 'runs' / name / attempt
        report = read(folder / 'report.json')
        assert report['status'] == 'PASS'
        runs.append(dict(case=name, attempt=attempt, process=read(folder / 'process.json'),
            report=pin(folder / 'report.json'), tests=report.get('tests')))
    comparisons = []
    for name in ('natural-cuda', 'continuous-cuda'):
        prior = R / '.scratch/inference-paired-publication-20261030/runs' / name / 'attempt1/report.json'
        current = W / 'runs' / name / 'attempt2/report.json'
        equal = read(prior) == read(current)
        assert equal
        comparisons.append(dict(case=name, previous=pin(prior), current=pin(current), full_report_equal=True))
    processes = list(W.rglob('process.json'))
    assert all(read(path)['state'] == 'TERMINAL' for path in processes)
    counts = {kind: len([p for p in processes if p.is_relative_to(W / directory)])
        for kind, directory in [('compile_attempts', 'compile'), ('link_attempts', 'link'), ('native_attempts', 'runs')]}
    files = [pin(path) for path in sorted((W / 'bin').iterdir()) if path.is_file()]
    save(W / 'cleanup-plan.json', dict(root=str(W / 'bin'), files=files, bytes=sum(p['bytes'] for p in files)))
    paths = subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).splitlines()
    sources = [R / path for path in paths if path.startswith(('src/', 'engine/', 'tests/'))]
    (W / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *[str(p.relative_to(R)) for p in sources]], cwd=R))
    kimi = read(W / 'runs/kimi-cuda/attempt4/report.json')
    kda_mla = [c for c in kimi['cases'] if 'CudaOriginalGeometrySynthetic' in c['name'] or 'CudaOriginalParameters' in c['name']]
    evidence = dict(schema='hyle.correctness.kimi-source-lifecycle.v1', date='2026-10-30',
        status='PASS_WITH_PRESERVED_INTEGRATION_AND_STALE_TEST_FAILURES', base_commit=plan['worktree_base_commit'],
        change='Real Kimi KDA->MLA consumes the original ProgramCarrier/ExecutionEpisode/SubmissionViews; asynchronous checked I32 Scan and exact no-sort Scatter qualification close observed native capture gaps.',
        sources=[pin(path) for path in sources],
        counts=dict(**counts, final_passed_processes=6, final_gtest_cases=17,
            additional_Qwen_finite_processes=2, refreshed_SDK_CXX=3, refreshed_SDK_CUDA=1,
            unchanged_SDK_engine_inputs=223, downloads=0, whole_builds=0, throughput_windows=0),
        hardware=dict(gpu='NVIDIA GeForce RTX 4070', driver='617.14', memory_MiB=12282,
            CXX='MSVC 14.50.35717', CUDA='13.3', target='sm_89', system='Windows x64'),
        invariants=[
            'One original Backend Queue, compiled Graph, Invocation and output pool per real component; no second executor or dummy Scope.',
            'The actual Run Scope retains Backend, cold program, constants, output pool and stable carrier retention node until original retirement.',
            'Cold MLA capture borrows the exact initialized future KDA hidden writer, old cache/cursor and future outputs before producer acceptance; no extra Graph submit.',
            'Only hidden input0 is withdrawn and reclaimed with identical generation/resource/handle/offset/size. Actual pending OutputSource then replaces it.',
            'Consumer submits before producer host observation; original Source report requires one device dependency, zero host waits, no new capture recording and positive capture reuse.',
            'Consumer source withdrawal precedes producer detach; successful reuse resets the original Invocation. Original whole Head publication and five-resource state checks remain model-owned.',
            'I32 Scan retains original CUB widened prefix/min/max/workspace, validates entirely on device and conditionally writes no output on any overflow; original Queue Completion carries OutOfRange.',
            'I32 Scan remains Managed; only its demonstrated nonblocking capture path qualifies. Non-I32 managed Scan and sorted Scatter retain old restrictions.',
            'No relaxed permission, imported error, result retention or actual retirement gate.'],
        current_runs=runs, Kimi_chain_reports=kda_mla, comparisons=comparisons,
        preserved_findings=[
            dict(run='kimi-cuda/attempt1', finding='Commands producer contains managed command gaps; original output Source capability gate rejects it.'),
            dict(run='kimi-cuda/attempt2', finding='Captured producer needs complete existing consumer capture; initial Source preparation correctly rejects.'),
            dict(run='kimi-cuda/attempt3', finding='Correct exact-writer cold handoff still rejects: actual MLA contains uncaptured host-blocking I32 Scan and unqualified Scatter capture binding.'),
            dict(run='kimi-diagnostic/attempt1 and attempt2', finding='Metadata-only scratch diagnostic using unchanged SDK: step39/node46 is CCCL I32 Scan; first capture range has privateStable=false immediately after cold capture, before any handoff. No Graph gate changed.'),
            dict(run='collectives-cuda/attempt1', finding='Only old blocks_host=true I32 runtime expectations fail; all Scan numeric and overflow comparisons plus other three cases pass. Runtime assertions updated to new real contract.'),
            dict(run='compile/collectives-test/attempt2', finding='New EXPECT_EQ template comma lacked outer parentheses; fixed test expression only and recompiled successfully.')],
        limits=[
            'Original payload covers fixed Kimi KDA0 14 roles and MLA3 9 roles only; KDA output is explicit upstream fixture for MLA3, not intervening layers or complete generation.',
            'Synthetic case uses generated sparse BF16/F32 weights at original Kimi7168/96x128 geometry; distinct from original artifact checks.',
            'No GPU preemption, simultaneous GPU overlap, full Kimi engine, token quality, full MTP/model support or throughput improvement claim.',
            'No new CPU, Apple, Vulkan, multi-device, long-context, sorted-Scatter or persistent native fault campaign; complete common engine orchestration and performance remain unfinished.',
            'Only the two refreshed Qwen regression processes are compared to the prior full reports; the other renamed probe sources were mechanically updated but not separately compiled.'],
        cleanup_plan=read(W / 'cleanup-plan.json'))
    save(W / 'evidence.json', evidence)
    print(json.dumps(dict(counts=evidence['counts'], complete_report_comparisons=comparisons,
        cleanup_files=len(files), cleanup_bytes=evidence['cleanup_plan']['bytes']), ensure_ascii=False))


def pack():
    evidence = read(W / 'evidence.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'COMPLETE'
    evidence['cleanup'] = cleanup
    stem = R / 'docs/evidence/correctness/inference-kimi-source-lifecycle-2026-10-30'
    save(stem.with_suffix('.json'), evidence)
    with zipfile.ZipFile(stem.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or path.is_relative_to(W / 'bin') or path.suffix.lower() in ('.obj', '.pdb', '.exe', '.dll', '.lib', '.exp', '.map'):
                continue
            archive.write(path, path.relative_to(W).as_posix())
    print(json.dumps(dict(evidence=pin(stem.with_suffix('.json')), archive=pin(stem.with_suffix('.zip')))))


if __name__ == '__main__':
    {'fixture': fixture, 'report': prepare_report, 'pack': pack}[sys.argv[1]]()
