#pragma once

#include <cstdint>
#include <cuda_runtime_api.h>

namespace hyle::compute::cuda_native::nvfp4 {
struct Program final {
  std::uint64_t rows = 0, columns = 0, depth = 0;
};
cudaError_t prepare_kernel() noexcept;
cudaError_t launch(const Program &, const void *const *inputs, void *activation,
                   void *output, unsigned *status, cudaStream_t) noexcept;
} // namespace hyle::compute::cuda_native::nvfp4
