#include "nvfp4_kernel.h"

#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include "device_status_kernel.h"
#include "packed_rows.cuh"

namespace hyle::compute::cuda_native::nvfp4 {
namespace {
using Index=unsigned long long;
enum class Scalar { kFloat16, kBFloat16, kFloat32 };
constexpr unsigned kThreads=256;
__device__ void invalid(unsigned *status) {
  atomicCAS(status,0U,unsigned(cuda::detail::DeviceStatusCode::kInvalidNumericInput));
}
__device__ float fp8(unsigned char code) {
  return __half2float(__half(__nv_cvt_fp8_to_halfraw(code,__NV_E4M3)));
}
__device__ float e2m1(float x) {
  if (x<=.25F) return 0.F;
  if (x<.75F) return .5F;
  if (x<=1.25F) return 1.F;
  if (x<1.75F) return 1.5F;
  if (x<=2.5F) return 2.F;
  if (x<3.5F) return 3.F;
  return x<=5.F ? 4.F : 6.F;
}
__global__ void quantize(Program p, const __nv_bfloat16 *input,
    const float *weight_global, const float *input_global,
    __nv_bfloat16 *activation, unsigned *status) {
  const float g=*input_global,wg=*weight_global;
  if (!(g>0.F) || !isfinite(g) || !(wg>0.F) || !isfinite(wg)) {
    invalid(status);return;
  }
  const Index groups=p.rows*(p.depth/16);
  for (Index group=Index(blockIdx.x)*blockDim.x+threadIdx.x;group<groups;
       group+=Index(gridDim.x)*blockDim.x) {
    float values[16],maximum=0.F;
    bool valid=true;
    #pragma unroll
    for (unsigned j=0;j<16;++j) {
      values[j]=__bfloat162float(input[group*16+j]);
      valid &= isfinite(values[j]);
      maximum=fmaxf(maximum,fabsf(values[j]));
    }
    if (!valid) {invalid(status);continue;}
    const float ratio=fminf(__fdiv_rn(maximum,__fmul_rn(6.F,g)),448.F);
    const auto code=__nv_cvt_float_to_fp8(ratio,__NV_SATFINITE,__NV_E4M3);
    float scale=__fmul_rn(fp8(code),g);
    if (!(scale>=1.e-5F)) scale=1.F;
    #pragma unroll
    for (unsigned j=0;j<16;++j) {
      const float rounded=e2m1(__fdiv_rn(fabsf(values[j]),scale));
      const float value=__fmul_rn(rounded,scale);
      activation[group*16+j]=__float2bfloat16_rn(values[j]>=0.F?value:-value);
    }
  }
}
struct Group final {
  const unsigned char *weights;
  Index row,depth;
  float scale;
  __device__ __forceinline__ float value(Index k) const {
    const auto byte=weights[row*(depth/2)+k/2];
    const unsigned code=(byte>>(4*unsigned(k%2)))&15;
    // The producer table gives both zero codes +0, unlike native signed FP4.
    const float values[16]{0.F,.5F,1.F,1.5F,2.F,3.F,4.F,6.F,
                          0.F,-.5F,-1.F,-1.5F,-2.F,-3.F,-4.F,-6.F};
    return __bfloat162float(__float2bfloat16_rn(__fmul_rn(values[code],scale)));
  }
  __device__ __forceinline__ float finish(float dot) const {return dot;}
};
struct Rows final {
  using GroupIndex=Index;
  Program p;
  const unsigned char *weights,*scales;
  const float *global;
  unsigned *status;
  __device__ __forceinline__ Index activation_offset(Index row) const {return row*p.depth;}
  __device__ __forceinline__ Index weight_row(Index,Index column) const {return column;}
  __device__ __forceinline__ Group group(Index row,Index group) const {
    const auto code=scales[row*(p.depth/16)+group];
    const float scale=fp8(code);
    if (!(scale>=0.F) || !isfinite(scale)) invalid(status);
    return {weights,row,p.depth,__fmul_rn(scale,*global)};
  }
};
template<unsigned Count>
__global__ void linear(Program p, const __nv_bfloat16 *activation,
    const unsigned char *weights,const unsigned char *scales,const float *global,
    __nv_bfloat16 *output,unsigned *status) {
  if (*status) return;
  packed::packed_rows<__nv_bfloat16,Count>(p.rows,p.columns,p.depth,16,
      Scalar::kBFloat16,activation,output,Rows{p,weights,scales,global,status});
}
unsigned blocks(Index items, unsigned per_block) {
  const auto count=items/per_block+(items%per_block!=0);
  return unsigned(count<65535?count:65535);
}
} // namespace
cudaError_t prepare_kernel() noexcept {
  // Resolve all kernels during cold preparation, including both row regimes.
  cudaFuncAttributes attributes;
  auto status=cudaFuncGetAttributes(&attributes,quantize);
  if (status==cudaSuccess) status=cudaFuncGetAttributes(&attributes,linear<1>);
  if (status==cudaSuccess) status=cudaFuncGetAttributes(&attributes,linear<4>);
  return status;
}
cudaError_t launch(const Program &p,const void *const *inputs,void *activation,
    void *output,unsigned *status,cudaStream_t stream) noexcept {
  Program spec=p;
  const auto *input=static_cast<const __nv_bfloat16 *>(inputs[0]);
  const auto *wg=static_cast<const float *>(inputs[3]);
  const auto *ag=static_cast<const float *>(inputs[4]);
  auto *a=static_cast<__nv_bfloat16 *>(activation);
  void *quant_args[]{&spec,&input,&wg,&ag,&a,&status};
  auto result=cudaLaunchKernel(reinterpret_cast<const void *>(quantize),
      dim3(blocks(p.rows*(p.depth/16),kThreads)),dim3(kThreads),quant_args,0,stream);
  if (result!=cudaSuccess) return result;
  const auto *w=static_cast<const unsigned char *>(inputs[1]);
  const auto *s=static_cast<const unsigned char *>(inputs[2]);
  auto *y=static_cast<__nv_bfloat16 *>(output);
  void *args[]{&spec,&a,&w,&s,&wg,&y,&status};
  const auto rows=p.rows>1?p.rows/4+(p.rows%4!=0):p.rows;
  const void *kernel=p.rows>1?reinterpret_cast<const void *>(linear<4>)
                              :reinterpret_cast<const void *>(linear<1>);
  return cudaLaunchKernel(kernel,dim3(blocks(rows*p.columns,8)),dim3(kThreads),args,0,stream);
}
} // namespace hyle::compute::cuda_native::nvfp4
