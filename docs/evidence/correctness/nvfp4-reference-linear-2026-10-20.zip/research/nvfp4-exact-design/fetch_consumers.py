"""Read only small fixed primary-source consumer/exporter files."""
import hashlib,json,pathlib,urllib.request
HERE=pathlib.Path(__file__).resolve().parent
HERE.mkdir(exist_ok=True)
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
records=[]
def fetch(url,name,limit=200000):
 row={'url':url,'maximum_bytes_read':limit}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'hyle-nvfp4-contract-review/1'})
  with urllib.request.urlopen(req,timeout=30) as r:
   row.update(status=r.status,headers={k:v for k,v in r.headers.items() if k.lower() in ['content-type','content-length','etag']})
   data=r.read(limit+1);assert len(data)<=limit
  p=HERE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  row.update(file=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 except Exception as e:row['error']=str(e);data=None
 records.append(row);save(HERE/'http-receipt.json',records)
 return data
pin='82f1d216d1a9022e60b8e1143a77f36c00b885a4'
listing=fetch(f'https://api.github.com/repos/NVIDIA/Model-Optimizer/contents/modelopt/torch/export?ref={pin}','modelopt/export-directory.json')
if listing:
 print('EXPORT FILES', [r['name'] for r in json.loads(listing)],flush=True)
 for r in json.loads(listing):
  if r['name'] in ['unified_export_hf.py','layer_utils.py','model_config.py']:
   fetch(r['download_url'],'modelopt/'+r['name'])
fetch('https://raw.githubusercontent.com/sgl-project/sglang/06992c92ad4494fe9f9636e75be3e35040512447/python/sglang/srt/layers/quantization/modelopt_quant.py','sglang/modelopt_quant.py')
fetch('https://raw.githubusercontent.com/huggingface/transformers/v5.2.0/src/transformers/integrations/modelopt.py','transformers/modelopt.py')
print(json.dumps({'requests':len(records),'bytes':sum(r.get('bytes',0) for r in records),'errors':[r['error'] for r in records if 'error' in r]},indent=2))
