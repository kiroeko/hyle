from pathlib import Path
import json,hashlib,subprocess,os,time
root=Path.cwd();a=root/'.scratch/architecture-refactor-2026-10-18';out=a/'nvfp4-reference-linear/cpu';recipe=a/'quant-route-followup/checks/host1/cpu-cast-test-identity.json'
env=os.environ.copy();r=subprocess.run(['cmd','/d','/c',str(a/'bf16-nan-cast-contract/compiler-env.bat')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
old=json.loads(recipe.read_bytes())['command'];cmd=[];skip=False
for arg in old:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
 cmd.append(arg)
source=root/'tests/compute_provider_native/nvfp4_test.cc';obj=out/'workspace-alias-test.obj';cmd+=['/sourceDependencies',str(out/'workspace-alias-test-deps.json'),str(source),'/Fo'+str(obj),'/Fd'+str(out/'workspace-alias-test.pdb')]
start=time.time();r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');(out/'workspace-alias-test.stdout.log').write_bytes(r.stdout.encode());(out/'workspace-alias-test.stderr.log').write_bytes(r.stderr.encode());print(r.stdout+r.stderr);print('compile',r.returncode)
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
receipt={'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start,'recipe':ident(recipe),'source':ident(source)}
if r.returncode==0:
 deps=json.loads((out/'workspace-alias-test-deps.json').read_bytes())['Data'];receipt.update(object=ident(obj),dependencies=[ident(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
(out/'workspace-alias-test-identity.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());raise SystemExit(r.returncode)
