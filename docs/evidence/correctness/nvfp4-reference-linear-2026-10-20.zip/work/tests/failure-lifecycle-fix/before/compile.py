from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time

R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=Path(__file__).resolve().parent
def identity(path):
 p=Path(path);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy()
r=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 if '='in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
def compile_one(arm):
 out=S/arm;out.mkdir(exist_ok=True)
 recipe=A/f'fp8-channel-token-qdq/checks/{arm}/test-identity.json'
 old=json.loads(recipe.read_text(encoding='utf-8'))['command'];base=[];skip=False
 for arg in old:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd'))or arg.lower().endswith(('.cc','.cpp')):continue
  base.append(arg)
 source=R/f'tests/graph_route_{arm}/nvfp4_reference_test.cc';obj=out/'test.obj';dep=out/'test-deps.json'
 command=base+['/sourceDependencies',str(dep),str(source),'/Fo'+str(obj),'/Fd'+str(out/'test.pdb')]
 save(out/'command.json',dict(command=command,recipe=identity(recipe),source=identity(source),fixture=identity(R/'tests/compute_models/nvfp4_reference_fixture.h')))
 start=time.time();result=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
 (out/'stdout.log').write_text(result.stdout,encoding='utf-8');(out/'stderr.log').write_text(result.stderr,encoding='utf-8')
 save(out/'result.json',dict(exit_code=result.returncode,seconds=time.time()-start,command=identity(out/'command.json')))
 print(arm,result.returncode,flush=True)
 if result.returncode:print(result.stdout+result.stderr,flush=True);return result.returncode
 d=json.loads(dep.read_text(encoding='utf-8'))['Data']
 save(out/'test-identity.json',dict(command=command,source=identity(source),object=identity(obj),recipe=identity(recipe),source_dependencies=identity(dep),dependencies=[identity(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]))
 return 0
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(compile_one,['cpu','cuda']))
raise SystemExit(max(results))
