from pathlib import Path
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True
S=Path(__file__).resolve().parent; A=S.parent; ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('nvf_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'cuda-native-storage-cast/final/link-plan.json'
base=c.read(BASE);meta=h.metadata({'cuda':base})

def owner(source):
    rows=[(row,meta[c.key(row['path'])]) for row in base['inputs']
          if c.key(row['path']) in meta and c.key(meta[c.key(row['path'])]['source_path'])==c.key(ROOT/source)]
    assert len(rows)==1,(source,len(rows));return rows[0]

def host(source,recipe_source,tag,out,env):
    old,recipe=owner(recipe_source)
    command=b.host_command(recipe['command'],ROOT/source,tag,out)
    receipt_path=out/(tag+'-identity.json')
    if receipt_path.exists():
        receipt=c.read(receipt_path)
        if receipt['command']==command and all(h.same_identity(row) for row in [receipt['source'],receipt['object'],*receipt['dependencies']]):
            print('REUSE',tag,flush=True)
            return c.key(old['path']) if source==recipe_source else None,receipt['object']
    c.execute(tag+'-compile',command,env,out)
    deps=c.read(out/(tag+'-deps.json'))['Data']
    result=dict(command=command,source=b.identity(ROOT/source),object=b.identity(out/(tag+'.obj')),
                dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])])
    c.save(out/(tag+'-identity.json'),result)
    return c.key(old['path']) if source==recipe_source else None,result['object']

def native(source,recipe,tag,out,env):
    command=list(recipe)
    sources=[i for i,arg in enumerate(command) if Path(arg).suffix.lower()=='.cu']
    assert len(sources)==1,sources
    command[sources[0]]=str(ROOT/source)
    for flag,value in [('-o',tag+'.obj'),('-MF',tag+'.d'),('-MT',tag+'.obj')]:
        if flag in command: command[command.index(flag)+1]=str(out/value)
    command=[('-Xcompiler=-Fd'+str(out/(tag+'.pdb'))+',-FS') if arg.startswith('-Xcompiler=-Fd') else arg for arg in command]
    command.append('-I'+str(ROOT/'third_party/mlx_cuda_quant'))
    c.execute(tag+'-compile',command,env,out)
    result=dict(command=command,source=b.identity(ROOT/source),object=b.identity(out/(tag+'.obj')),
                local_shared_headers=[b.identity(ROOT/'src/compute_provider_cuda/packed_rows.cuh'),b.identity(ROOT/'third_party/mlx_cuda_quant/mlx_cuda_quant.h')])
    c.save(out/(tag+'-identity.json'),result);return result['object']

def main():
    out=S/'cuda';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
    c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime))
    replacements={};new=[]
    jobs=[('src/compute_ops/weight_decode.cc','src/compute_ops/weight_decode.cc','weight-decode'),
          ('src/compute_provider_cuda/cuda_provider.cc','src/compute_provider_cuda/cuda_provider.cc','cuda-provider'),
          ('src/compute_provider_cuda/nvfp4_provider.cc','src/compute_provider_cuda/tensor_provider.cc','nvfp4-provider')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for old,obj in pool.map(lambda args:host(*args,out,env),jobs):
            if old: replacements[old]=obj
            else:new.append(obj)
    recipe=c.read(A/'cuda-native-storage-cast/dense/tensor-kernel-identity.json')['command']
    new.append(native('src/compute_provider_cuda/nvfp4_kernel.cu',recipe,'nvfp4-kernel',out,env))
    old,recipe=owner('src/compute_provider_torch_cuda/mlx_packed_kernel.cu')
    replacements[c.key(old['path'])]=native('src/compute_provider_torch_cuda/mlx_packed_kernel.cu',recipe['command'],'mlx-kernel',out,env)
    c.save(out/'assembly.json',dict(base=b.identity(BASE),replacements=replacements,new_inputs=new))
    print('CUDA owners ready',flush=True)

if __name__=='__main__':main()
