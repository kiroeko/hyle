from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('nvf_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'bf16-nan-cast-contract/final/link-plan.json';base=c.read(BASE)
inputs=[b.identity(Path(arg)) for arg in base['command'] if Path(arg).is_absolute() and Path(arg).suffix.lower() in {'.obj','.lib'}]
meta=h.metadata({'cpu':{'inputs':inputs}})
def source_owner(source):
    matches=[row for row in inputs if c.key(row['path']) in meta and c.key(meta[c.key(row['path'])]['source_path'])==c.key(ROOT/source)]
    assert len(matches)==1,(source,len(matches));return matches[0]

def main():
    mode=sys.argv[1] if len(sys.argv)>1 else 'direct'
    out=S/('cpu-'+mode);out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    env,runtime=b.environment(base['command'],[r['path'] for r in inputs],out)
    c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime))
    repl={}
    for source,receipt in [('src/compute_ops/weight_decode.cc',S/'cuda/weight-decode-identity.json'),('src/compute_provider_native/native_provider.cc',S/'cpu/native_provider-identity.json')]:
        old=source_owner(source);obj=c.read(receipt)['object'];assert h.same_identity(obj)
        repl[c.key(old['path'])]=obj
    new=[c.read(S/'cpu/nvfp4-identity.json')['object'],c.read(S/'cpu/workspace-alias-test-identity.json')['object']]
    if mode in {'graph','final'}:
        new.append(c.read(S/('tests/failure-lifecycle-fix/cpu/test-identity.json' if mode=='final' else 'tests/cpu/test-identity.json'))['object'])
    command=[repl.get(c.key(arg),{}).get('path',arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    current=[repl.get(c.key(r['path']),r) for r in inputs]+new
    for row in current:assert h.same_identity(row),row['path']
    command.extend(r['path'] for r in new)
    image=out/'cpu.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=current,base=b.identity(BASE),replacements=repl))
    c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
    filt='NativeNvfp4.*'
    if mode=='graph':filt+=':CpuNvfp4ReferenceGraph.*:AtenCast.*:CpuFp8ChannelTokenQdqGraph.*'
    if mode=='final':filt+=':CpuNvfp4ReferenceGraph.*:NativeCast.BfloatNanPayloadPreservesE5m2UpperPayloadAndQuietBit:CpuFp8ChannelTokenQdqGraph.*'
    c.execute('run',[str(image),'--gtest_filter='+filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)

if __name__=='__main__':main()
