from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('nvf_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'cuda-native-storage-cast/final/link-plan.json';base=c.read(BASE)

def main():
    mode=sys.argv[1] if len(sys.argv)>1 else 'green'
    final=mode=='final'
    out=S/('cuda-'+mode);out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
    c.save(out/'environment.json',dict(PATH=env['PATH'],runtime=runtime))
    assembly=c.read(S/'cuda/assembly.json')
    replacements=assembly['replacements']
    new=assembly['new_inputs']
    if mode=='red':
        new=[]
        common=c.read(S/'cuda/weight-decode-identity.json')['object']
        replacements={old:row for old,row in replacements.items() if row==common}
    test_path=S/('tests/failure-lifecycle-fix/cuda/test-identity.json' if final else 'tests/cuda/test-identity.json')
    new=[*new,c.read(test_path)['object']]
    if final:
        mlx=c.read(A/'mlx-moe-typed-inputs/checks/cuda-test-identity.json')
        assert h.same_identity(mlx['source']) and h.same_identity(mlx['object'])
        if c.key(mlx['object']['path']) not in {c.key(r['path']) for r in base['inputs']}:
            new.append(mlx['object'])
    command=[replacements.get(c.key(arg),{}).get('path',arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    inputs=[replacements.get(c.key(row['path']),row) for row in base['inputs']]+new
    for row in inputs:assert h.same_identity(row),row['path']
    command.extend(row['path'] for row in new)
    image=out/'cuda.exe';command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(BASE),replacements=replacements))
    c.execute('link',command,env,out);c.save(out/'image.json',b.identity(image))
    filt='CudaNvfp4ReferenceGraph.*'
    if mode=='green':filt+=':CudaFp8Cast.*:CudaFp8ChannelTokenQdqGraph.*'
    if final:filt+=':CudaCtPackedLinear.*:CudaMlxSharedActivation.*:CudaMlxMoeGraph.*:*CudaMlxPrecision.SourceF32EquationAndGroupScaleArePreservedUnderForeignTf32Policy*'
    c.execute('run',[str(image),'--gtest_filter='+filt,'--gtest_output=xml:'+str(out/'tests.xml')],env,out)

if __name__=='__main__':main()
