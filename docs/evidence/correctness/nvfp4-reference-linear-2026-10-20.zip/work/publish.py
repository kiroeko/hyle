from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

S=Path(__file__).resolve().parent; A=S.parent; ROOT=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
    p=p.resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def check(row):
    actual=identity(Path(row['path']));assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],row['path']

plans={arm:read(S/(arm+'-final/link-plan.json')) for arm in ['cpu','cuda']}
for plan in plans.values():
    for row in plan['inputs']:check(row)
owners=[S/'cuda'/name for name in ['weight-decode-identity.json','cuda-provider-identity.json','nvfp4-provider-identity.json','nvfp4-kernel-identity.json','mlx-kernel-identity.json']]
owners += [S/'cpu'/name for name in ['native_provider-identity.json','nvfp4-identity.json','workspace-alias-test-identity.json']]
owners += [S/'tests/failure-lifecycle-fix'/arm/'test-identity.json' for arm in ['cpu','cuda']]
for p in owners:
    d=read(p)
    for row in [d['source'],d['object'],*d.get('dependencies',[]),*d.get('local_shared_headers',[])]:check(row)

tests={}
for arm,count in [('cpu',5),('cuda',26)]:
    path=S/(arm+'-final/tests.xml');root=ET.parse(path).getroot()
    assert int(root.get('tests'))==count and int(root.get('failures'))==0 and int(root.get('errors'))==0
    assert not any(int(s.get('skipped','0')) for s in root.findall('testsuite'))
    tests[arm]=dict(tests=count,failures=0,skipped=0,xml=identity(path))
    for suite in root.findall('testsuite'):
        if suite.get('name')==arm.capitalize()+'Nvfp4ReferenceGraph':
            tests[arm]['new_operation_cases']=[dict(name=case.get('name'),properties={p.get('name'):p.get('value') for p in case.findall('properties/property')}) for case in suite.findall('testcase')]

sources=['include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc',
    'src/compute_provider_native/native_provider.cc','src/compute_provider_native/native_plan.h','src/compute_provider_native/nvfp4.cc','src/compute_provider_native/CMakeLists.txt',
    'src/compute_provider_cuda/cuda_provider.cc','src/compute_provider_cuda/CMakeLists.txt','src/compute_provider_cuda/nvfp4_provider.cc','src/compute_provider_cuda/nvfp4_provider.h','src/compute_provider_cuda/nvfp4_kernel.cu','src/compute_provider_cuda/nvfp4_kernel.h','src/compute_provider_cuda/packed_rows.cuh',
    'src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
    'tests/compute_provider_native/nvfp4_test.cc','tests/compute_provider_native/CMakeLists.txt','tests/compute_models/nvfp4_reference_fixture.h',
    'tests/graph_route_cpu/nvfp4_reference_test.cc','tests/graph_route_cpu/CMakeLists.txt','tests/graph_route_cuda/nvfp4_reference_test.cc','tests/graph_route_cuda/CMakeLists.txt',
    'docs/user/compute.md','docs/architecture/compute-design.md','docs/developer/current-work.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json',
    'third_party/mlx_cuda_quant/mlx_cuda_quant.h','third_party/mlx_cuda_quant/LICENSE','third_party/mlx_cuda_quant/NOTICE.md','third_party/mlx_cuda_quant/SOURCE.json']
freeze=[identity(ROOT/p) for p in sources]
report=dict(status='implemented_and_focused_execution_passed',
    scope='New five-input ModelOpt group16 BF16 software-reference linear; not hardware-native FP4 GEMM, whole artifact, quality or throughput acceptance.',
    public_contract=dict(operation='model_ops::Nvfp4Linear / nvfp4_linear()',name='nvfp4-reference-linear',
        inputs=['BF16[M,K] activation','U8[N,K/2] adjacent low-first E2M1 codes','E4M3FN[N,K/16] group scales','F32 scalar weight global','F32 scalar calibrated input global'],output='BF16[M,N]',
        geometry='Positive M/N/K, complete16 groups, plain dense ports; globals scalar[] or [1].',
        arithmetic='Pinned ModelOpt Hopper runtime A16 QDQ with E4M3 scale and tiny guard -> BF16; nonfast W=BF16(q*F32(groupScale*weightGlobal)); F32 backend reduction, final BF16. Both producer weight zero codes are +0. A uses x>=0 sign comparison.',
        domain='Finite BF16 A, finite nonnegative E4M3 group scales including both zero signs, strictly positive finite F32 globals including subnormal. Finite input may produce IEEE NaN/Inf after chosen scaling/rounding.',
        failure='Completion failure; failed output unusable, no rollback guarantee. Failed Graph Invocation is terminal; recreate from same Executable, bind and prepare to recover.'),
    architecture=dict(core_changes=False,old_duplicate_executor_added=False,
        integration='Ordinary custom operation inference -> existing native providers -> PreparedOperation/Invocation/QueueSequence/Completion/Graph result ownership.',
        cpu='Original NativePlan layout unchanged; existing caller workspace and parallel executor; A quantized once into2*M*K BF16 bytes, W stack tile16 BF16 values, existing SIMD dot.',
        cuda='Prepared/shared Queue, caller device workspace2*M*K bytes, no provider-private invocation/result allocation or host wait. A quantized once; original packed W read in bounded rows/groups. RequireCapture executed.',
        row_reuse='Moved existing MLX/CT packed_rows body to shared private header, only Scalar template deduction and namespace qualification changed. Existing MLX and CT codecs, rounding and launch geometries preserved;26 related CUDA cases executed.',
        resource_fix='Explicit workspace device requirement on CUDA; both backends reject workspace aliasing inputs/outputs. CPU Direct tests A/W alias with sufficiently large/aligned physical backing and verifies every input byte unchanged, followed by normal output20.625.'),
    validation=tests,
    per_backend_new_op=dict(lifetime_successes=8,runtime_successes=24,failed_completions=18,geometries=['M2/N3/K32','M2/N16/K2048'],
        boundaries='Independent table/bit-RNE oracle isolates pointwise BF16 boundaries with sparse exact dot witnesses; tiny guard, subnormal globals, scale zero signs and scale-first0*Inf NaN tested. Not universal bitwise reduction or independent visibility of every internal signed zero.'),
    observed_failures=dict(cuda_old_products='Two actual missing-route red cases; new common inference only, old CUDA provider products. First reference test objects were later corrected for terminal failure lifecycle; math/payload unchanged.',
        initial_lifecycle='CPU3pass/1fail and CUDA9pass/1fail: fixture wrongly retried a failed Graph Invocation. Fixed test to assert terminal state and recreate, not by changing product failure policy.',
        compile='Initial new CUDA provider CXX rejected designated initialization of optional workspace; corrected to explicit WorkspaceRequirement. Original command/error retained.',
        ptx='Real-SM89 object has no PTX. Empty dump-ptx is not arithmetic evidence; actual SASS was separately inspected and support-code FTZ instructions are retained without claiming global no-FTZ.'),
    build_scope='Only focused CXX/NVCC owners and test TUs plus relinks, with retained dependencies and actual link inputs. Native CUDA includes an unchanged mathematical kernel recompilation during line-ending normalization; no SDK, full build or CI run. CMake source/license wiring updated, not a new CMake configure/install acceptance.',
    source_freeze=freeze,owner_receipts=[identity(p) for p in owners],
    final_images={arm:identity(S/(arm+'-final')/(arm+'.exe')) for arm in ['cpu','cuda']},
    final_link_plans={arm:identity(S/(arm+'-final/link-plan.json')) for arm in ['cpu','cuda']},
    final_actual_link_inputs_checked={arm:len(plan['inputs']) for arm,plan in plans.items()},
    research=identity(S/'tests/research-summary.json'),
    SASS=identity(S/'cuda/sass-review.json'),
    execution_limits=['Windows CPU/CUDA SM89 only this batch; no Linux/macOS run or Apple/Vulkan lowering.',
        'No original artifact tensor/global values or full186-role loading; complete artifact_execution_verified remains false.',
        'No hardware-native FP4 GEMM equivalence, model quality, throughput, physical kernel trace or peak-memory acceptance.',
        'Qwen first-prepare diagnostics are an independent report and establish no new stable decode improvement.'])
(S/'final-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

payload={}
def add(path,name):
    data=path.read_bytes();assert name not in payload or payload[name]==data
    payload[name]=data
for p in sources:add(ROOT/p,'source/'+p)
for path in S.rglob('*'):
    if not path.is_file() or path.suffix.lower() not in {'.json','.xml','.log','.py','.ps1','.cc','.h','.cu','.cuh','.diff','.txt'}:continue
    if path.stat().st_size>3_000_000 or 'tmp' in path.relative_to(S).parts or path.name=='nvfp4.ptx.txt':continue
    add(path,'work/'+path.relative_to(S).as_posix())
for row in read(S/'tests/research-summary.json')['include_in_correctness_archive']:
    check(row);path=Path(row['path']);add(path,'research/'+path.relative_to(A).as_posix())
for p in ['modelopt/nvfp4_tensor.py','modelopt/fp4_kernel_hopper.py','modelopt/tensor_quantizer.py','header-role-facts.json','full-quantized-role-census.json']:
    path=A/'next-quant-functional-review'/p;add(path,'prior-contract/'+p)
manifest=[dict(member=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(payload.items())]
payload['payload-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
dest=ROOT/'docs/evidence/correctness';dest.mkdir(exist_ok=True)
archive=dest/'nvfp4-reference-linear-2026-10-20.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payload.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    for row in manifest:
        data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
public=dict(report,archive=dict(**identity(archive),payloads=len(manifest),CRC_checked=True,all_payload_SHA256_checked=True,
    excluded='No SDK, binary, object, full linker maps, weight payload or duplicated full dependency cache.'))
out=dest/'nvfp4-reference-linear-2026-10-20.json';out.write_text(json.dumps(public,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(report=identity(out),archive=identity(archive),payloads=len(manifest),tests=tests),indent=2))
