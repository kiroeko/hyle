from pathlib import Path
import json,hashlib,subprocess,os,time
root=Path.cwd();a=root/'.scratch/architecture-refactor-2026-10-18';out=a/'nvfp4-reference-linear/cpu';out.mkdir(parents=True,exist_ok=True)
recipe=a/'decode-next-cold/checks/20261019T155819/05-compute_provider_native-native_provider-identity.json'
env=os.environ.copy();r=subprocess.run(['cmd','/d','/c',str(a/'bf16-nan-cast-contract/compiler-env.bat')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
old=json.loads(recipe.read_bytes())['command'];base=[];skip=False
for arg in old:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
 base.append(arg)
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
records=[]
for name in ['native_provider','nvfp4']:
 source=root/f'src/compute_provider_native/{name}.cc';obj=out/(name+'.obj');cmd=base+['/sourceDependencies',str(out/(name+'-deps.json')),str(source),'/Fo'+str(obj),'/Fd'+str(out/(name+'.pdb'))]
 start=time.time();r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');(out/(name+'.stdout.log')).write_bytes(r.stdout.encode());(out/(name+'.stderr.log')).write_bytes(r.stderr.encode());records.append({'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start});(out/'commands.json').write_bytes((json.dumps(records,indent=2)+'\n').encode());print(name,r.returncode,flush=True)
 if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
 deps=json.loads((out/(name+'-deps.json')).read_bytes())['Data'];(out/(name+'-identity.json')).write_bytes((json.dumps({'command':cmd,'source':ident(source),'object':ident(obj),'recipe':ident(recipe),'dependencies':[ident(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])]},indent=2)+'\n').encode())
print('Both strict compilations passed')
