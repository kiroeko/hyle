"""Freeze this Vulkan validation and archive only reproducible source/recipe/result evidence."""
from pathlib import Path
import base64
import difflib
import hashlib
import json
import re
import subprocess
import zipfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
CHECK = STAGE / 'checks-20261019T141537'
REFRESH = STAGE / 'refresh-20261019T140912'
ARCHIVE = ROOT / 'docs/evidence/correctness/mlx-affine-widths-vulkan-2026-10-19.zip'
OWNED = [
    'src/compute_route_vulkan/vulkan_mlx.cc',
    'src/compute_provider_iree_vulkan/native_program.h',
    'src/compute_provider_iree_vulkan/native_program.cc',
    'third_party/iree_vulkan_runtime/programs/generate_mlx.py',
    'third_party/iree_vulkan_runtime/programs/compile_mlx.py',
    'third_party/iree_vulkan_runtime/programs/mlx.mlir',
    'third_party/iree_vulkan_runtime/programs/mlx.vmfb.b64',
    'tests/compute_route_vulkan/mlx_test_support.h',
    'tests/compute_route_vulkan/iree_test.cc',
    'tests/graph_route_vulkan/iree_test.cc',
]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def copy(relative):
    data = (ROOT / relative).read_bytes()
    path = STAGE / 'source' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return dict(product=relative, snapshot=str(path.relative_to(STAGE)), **identity(ROOT / relative))


def baseline(relative):
    if relative == 'src/compute_provider_iree_vulkan/native_program.cc':
        source = ROOT / '.scratch/architecture-refactor-2026-10-18/native-ready-pages/windows/candidate' / relative
        return source.read_bytes(), dict(kind='prior_frozen_source', source=identity(source),
            receipt='.scratch/architecture-refactor-2026-10-18/native-ready-pages/windows/final-source-identities.json')
    if relative == 'src/compute_provider_iree_vulkan/native_program.h':
        source = ROOT / '.scratch/inference-foundation-review-2026-10-18/vulkan-official-word-bank/source' / relative
        return source.read_bytes(), dict(kind='prior_frozen_source', source=identity(source),
            receipt='.scratch/inference-foundation-review-2026-10-18/vulkan-official-word-bank/source-identities.json')
    if relative in ('tests/compute_route_vulkan/iree_test.cc', 'tests/graph_route_vulkan/iree_test.cc'):
        data = (ROOT / relative).read_bytes()
        suite = 'VulkanIree' if 'compute_route' in relative else 'VulkanGraph'
        names = ['OriginalMlxAffineWidthsUseContinuousBitstreamsAndCheckedRebinding']
        if suite == 'VulkanIree':
            names.append('OriginalMlxAffineWidthsKeepDecodedWeightsInF32BeforeDot')
        for name in names:
            pattern = (r'TEST\(' + suite + ', ' + name + r'\) \{.*?\r?\n\}\r?\n\r?\n').encode()
            data, count = re.subn(pattern, b'', data, flags=re.S)
            if count != 1:
                raise ValueError('Expected one new named test: ' + name)
        data = data.replace(b'Format::kAffine, Kind::kEmbedding', b'Format::kAffine4, Kind::kEmbedding')
        return data, dict(kind='reconstructed_before', method='Remove only this batch named tests and reverse its single direct-test enum migration; preserve all unrelated preexisting test changes.',
            contemporaneous_before_snapshot=False)
    data = subprocess.check_output(['git', 'show', 'HEAD:' + relative], cwd=ROOT)
    return data, dict(kind='git_original_blob', revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        note='Original committed width4 source; not represented as a contemporaneous whole-tree snapshot.')


def main():
    check = read(CHECK / 'summary.json')
    if check.get('runtime') != 'passed' or check['tests']['tests'] != 18 or check['skipped'] != 0:
        raise ValueError('Expected the completed 18-test actual Vulkan validation')
    plan = read(REFRESH / 'plan.json')
    snapshots = {}
    for name in OWNED:
        snapshots[name] = copy(name)
    # Preserve exact source owners but regenerate the embedded byte array from
    # current authenticated program inputs rather than duplicate all modules.
    for row in plan['compile']:
        if row['tag'] == 'embedded-programs':
            continue
        name = str(Path(row['source']['path']).relative_to(ROOT)).replace('\\', '/')
        if identity(ROOT / name) != row['source']:
            raise ValueError('Validated owner drifted: ' + name)
        snapshots.setdefault(name, copy(name))
    for name in ('include/hyle/compute/model_ops.h', 'tests/compute_models/mlx_affine_bitstream.h',
                 'src/compute_route_vulkan/vulkan_program_internal.h'):
        snapshots.setdefault(name, copy(name))
    provenance, diffs = [], []
    for name in OWNED:
        data, origin = baseline(name)
        target = STAGE / 'before' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        provenance.append(dict(product=name, snapshot=str(target.relative_to(STAGE)), origin=origin,
                               before=identity(target), after=snapshots[name]))
        diffs.extend(difflib.unified_diff(data.decode().splitlines(True),
            (ROOT / name).read_text(encoding='utf-8').splitlines(True),
            fromfile='before/' + name, tofile='source/' + name))
    (STAGE / 'changes.diff').write_text(''.join(diffs), encoding='utf-8')
    save(STAGE / 'before-source-provenance.json', dict(files=provenance,
        limitation='No contemporaneous copy was taken for every file before edits. Recovered original files and narrowly reconstructed test baselines are explicitly identified. Actual after sources and compile/run identities are frozen independently.'))
    manifest = read(ROOT / 'third_party/iree_vulkan_runtime/programs/manifest.json')
    modules = []
    for row in manifest['programs']:
        raw = base64.b64decode((ROOT / 'third_party/iree_vulkan_runtime/programs' / row['file']).read_bytes())
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Current authenticated module changed')
        modules.append({key: row[key] for key in ('name', 'file', 'bytes', 'sha256', 'recipe', 'recipe_sha256')})
    save(STAGE / 'final-module-manifest-identities.json', dict(modules=modules,
        manifest_at_validation=identity(ROOT / 'third_party/iree_vulkan_runtime/programs/manifest.json'),
        cached_baseline_provenance=read(CHECK / 'neighbor-module-identities.json')))
    freeze = dict(owned_files=OWNED, source_snapshots=list(snapshots.values()),
        public_header=plan['public_header'], graph_dependencies=read(STAGE / 'validated-graph-dependencies.json'),
        validation=identity(CHECK / 'summary.json'),
        private_ABI='One ProgramSpecV2 concrete type and ProgramSpec semantic alias; all 43 Vulkan host owners refreshed, no old runtime entry or compatibility executor.',
        no_later_Graph_ABI_claim=True)
    save(STAGE / 'source-freeze.json', freeze)
    paths = [CHECK / ('mlx-vulkan' + ext) for ext in ('.exe', '.map', '.lib', '.exp')]
    save(STAGE / 'cleanup-plan.json', dict(execute=False, test_ps1_modified=False,
        note='Exact disposable private image outputs only; objects, source, recipes, offline records and evidence remain. Follow root test.ps1 workflow before any deletion.',
        candidates=[dict(absolute=str(path.resolve()), exists=path.exists(), bytes=path.stat().st_size if path.exists() else None) for path in paths]))
    summary = dict(check, source_freeze='source-freeze.json', validation='checks-20261019T141537',
        actual_tests=dict(Direct=8, Graph=3, private_IREE_neighbors=7),
        new_tests=3, new_width_cross_cases_per_entry=12, precise_F32_decode_witnesses=8,
        supported_affine_bits=[4,5,6,8], supported_affine_groups=[32,64,128],
        offline=dict(exports=21, runtime_affine_bits_exports=9, schedules=32, IEEE32_checked=True,
                     record='offline-final/compilation.json'),
        semantics='Continuous low-bit-first U32 stream; affine F32 decoded K-group before F32 dot; typed embedding product barrier then add; checked-copy publication; duplicate/changed/invalid IDs and recovery.',
        numerical_scope='Vulkan already decoded affine weights to F32. This batch extends packing/width/ABI, and adds regression protection; it does not claim an old Vulkan decode math correction.',
        old_cache_note='The cached SDK generated official module predates current product inputs. Fresh generated seven-module object matches current authenticated manifest; only MLX program product input files are changed by this batch.',
        archive=str(ARCHIVE.relative_to(ROOT)).replace('\\', '/'),
        sources_contain_preexisting_unrelated_changes=True,
        later_graph_perf_batch_is_separate=True)
    save(STAGE / 'summary.json', summary)
    allowed = {'.json','.log','.xml','.txt','.py','.mlir'}
    selected = []
    for path in STAGE.rglob('*'):
        if not path.is_file() or path.name in ('archive-receipt.json', 'archive-payload.json'):
            continue
        relative = path.relative_to(STAGE)
        first = relative.parts[0]
        if first in ('source', 'before', 'validated-deps'):
            selected.append(path)
        elif len(relative.parts) == 1 and path.suffix in allowed | {'.diff'}:
            selected.append(path)
        elif first.startswith(('host', 'refresh-', 'checks-')) and path.suffix in allowed:
            selected.append(path)
        elif first == 'offline-final' and path.suffix in allowed:
            selected.append(path)
        elif first == 'offline' and path.name in ('compilation.json','compiler-version.txt','compile.log','configure.log'):
            selected.append(path)
    payload = [dict(member=str(path.relative_to(STAGE)).replace('\\','/'), bytes=path.stat().st_size,
                    sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in sorted(selected)]
    save(STAGE / 'archive-payload.json', dict(entries=payload, excluded='SDKs, native/host objects, PDBs, maps, images, import libraries, decoded duplicate VMFB and duplicate other-backend archives.'))
    selected.append(STAGE / 'archive-payload.json')
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    if ARCHIVE.exists():
        raise ValueError('Do not silently replace an existing evidence archive')
    with zipfile.ZipFile(ARCHIVE,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(selected):
            archive.write(path,str(path.relative_to(STAGE)).replace('\\','/'))
    with zipfile.ZipFile(ARCHIVE) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive CRC failure')
        for row in payload:
            raw = archive.read(row['member'])
            if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
                raise ValueError('Archive payload identity failure: ' + row['member'])
        members = len(archive.infolist())
    receipt = dict(archive=identity(ARCHIVE), entries=members, CRC_verified=True,
                   payload_SHA256_verified=len(payload), summary=identity(STAGE / 'summary.json'),
                   source_freeze=identity(STAGE / 'source-freeze.json'), cleanup_executed=False)
    save(STAGE / 'archive-receipt.json', receipt)
    save(ARCHIVE.with_suffix('.zip.receipt.json'), receipt)
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()
