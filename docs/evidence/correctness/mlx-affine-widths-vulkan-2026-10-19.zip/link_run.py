"""Link the frozen current common closure with fresh Vulkan owners; optional narrow tests."""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import importlib.util
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
REFRESH = STAGE / 'refresh-20261019T140912'
spec = importlib.util.spec_from_file_location('mlx_vk_link_helpers', ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-grouped-fusion/build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, c = prior.b, prior.c
FILTER = 'VulkanIree.OriginalMlx*:VulkanGraph.OriginalMlx*:IreeNative.*'


def verified(row):
    if not b.same(row):
        raise ValueError('Frozen input differs: ' + row['path'])


def module_comparison():
    cached = ROOT / '.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_provider_iree_vulkan/generated/programs.cc'
    def read_arrays(path):
        text = path.read_text(encoding='utf-8-sig')
        return {name: bytes(int(x, 16) for x in re.findall(r'0x([0-9a-fA-F]{2})', body))
                for name, body in re.findall(r'unsigned char (\w+)_bytes\[\] = \{(.*?)\};', text, re.S)}
    arrays, old_arrays = read_arrays(REFRESH / 'programs.cc'), read_arrays(cached)
    manifest = c.read(ROOT / 'third_party/iree_vulkan_runtime/programs/manifest.json')
    rows, baseline = [], []
    for row in manifest['programs']:
        if row['name'] == 'mlx':
            continue
        binary = arrays[row['name']]
        identity = dict(name=row['name'], bytes=len(binary), sha256=hashlib.sha256(binary).hexdigest())
        if (identity['bytes'], identity['sha256']) != (row['bytes'], row['sha256']):
            raise ValueError('Fresh embedded module differs from current manifest: ' + row['name'])
        rows.append(identity)
        old = old_arrays[row['name']]
        baseline.append(dict(name=row['name'], bytes=len(old), sha256=hashlib.sha256(old).hexdigest(),
                             matches_current_manifest=old == binary))
    if len(rows) != 6:
        raise ValueError('Expected six unchanged neighboring embedded modules')
    return dict(fresh_generated=b.identity(REFRESH / 'programs.cc'),
                current_six_neighbor_modules=rows, cached_generated=b.identity(cached),
                cached_baseline_modules=baseline,
                note='Cached generated source predates some current product inputs. This task edits only MLX source/blob; all seven fresh embedded modules match the current authenticated product manifest.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', required=True, type=Path,
                        help='Final common link plan released by its owner; never read a mutable base early')
    parser.add_argument('--base-sha', required=True)
    parser.add_argument('--link', action='store_true')
    parser.add_argument('--run', action='store_true', help='Requires an explicitly released GPU window')
    args = parser.parse_args()
    if args.run and not args.link:
        parser.error('--run requires --link')
    base_identity = b.identity(args.base)
    if base_identity['sha256'] != args.base_sha:
        raise ValueError('Released final common plan identity differs')
    base = c.read(args.base)
    refresh = c.read(REFRESH / 'plan.json')
    verified(refresh['public_header'])
    fresh, frozen = [], [base_identity, b.identity(REFRESH / 'plan.json'), b.identity(Path(__file__))]
    for row in refresh['compile']:
        identity_path = REFRESH / (row['tag'] + '-identity.json')
        receipt = c.read(identity_path)
        if receipt['source'] != row['source'] or c.key(receipt['object']['path']) != c.key(row['object']):
            raise ValueError('Fresh owner recipe disagrees: ' + row['tag'])
        verified(receipt['source'])
        verified(receipt['object'])
        fresh.append(receipt['object'])
        frozen.extend((receipt['source'], b.identity(identity_path)))
    if len(fresh) != 43:
        raise ValueError('Expected all 43 freshly compiled current owners')
    for row in c.read(STAGE / 'owner-refresh-plan.json')['private_headers']:
        actual = b.identity(ROOT / row['path'])
        if actual['sha256'] != row['sha256']:
            raise ValueError('Private protocol changed after owner refresh')
        frozen.append(actual)
    removals = {'ops-test.obj', 'mlx-direct-test.obj', 'mlx-graph-test.obj'}
    removed = [row for row in base['inputs'] if Path(row['path']).name in removals]
    if {Path(row['path']).name for row in removed} != removals or len(removed) != 3:
        raise ValueError('Expected exactly the three common CPU test owners')
    removed_keys = {c.key(row['path']) for row in removed}
    retained = [row for row in base['inputs'] if c.key(row['path']) not in removed_keys]
    for row in retained:
        verified(row)
    shader_paths = [
        ROOT / '.scratch/inference-foundation-review-2026-10-18/native-row-cache-padded/shaders.obj',
        ROOT / '.scratch/architecture-refactor-2026-10-18/paged-row-scorer/validation/windows-current/row-cache-paged-shader.obj',
    ]
    shaders = [b.identity(path) for path in shader_paths]
    out = STAGE / ('checks-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'))
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    all_inputs = [*fresh, *shaders, *retained]
    keys = [c.key(row['path']) for row in all_inputs]
    if len(set(keys)) != len(keys):
        raise ValueError('Nonunique final link input')
    command = [value for value in base['command'] if c.key(value) not in removed_keys
               and not value.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [row['path'] for row in [*fresh, *shaders]]
    image = out / 'mlx-vulkan.exe'
    command.extend(['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))])
    actual_inputs = [value for value in command if Path(value).is_absolute()
                     and Path(value).suffix.lower() in ('.obj', '.lib')]
    if sorted(map(c.key, actual_inputs)) != sorted(keys):
        raise ValueError('Literal link arguments differ from retained/fresh input set')
    compare = module_comparison()
    c.save(out / 'neighbor-module-identities.json', compare)
    c.save(out / 'base-link-plan.json', base)
    c.save(out / 'fresh-owner-plan.json', refresh)
    plan = dict(command=command, inputs=all_inputs, base=base_identity, removed_common_tests=removed,
                fresh_Vulkan_owners=43, reused_shader_objects=shaders,
                input_count=len(all_inputs), SDK_rebuilt=False, GPU_run=False,
                private_protocol='ProgramSpecV2 with one semantic ProgramSpec alias', test_filter=FILTER,
                frozen=list({c.key(row['path']): row for row in frozen}.values()))
    c.save(out / 'vulkan-link-plan.json', plan)
    print('PLAN', out, len(all_inputs), 'inputs', flush=True)
    if not args.link:
        return
    env, runtime = b.environment(command, actual_inputs, out)
    c.save(out / 'runtime-paths.json', runtime)
    c.execute('vulkan-link', command, env, out)
    map_text = image.with_suffix('.map').read_text(encoding='utf-8', errors='replace')
    spec_lines = [line for line in map_text.splitlines() if 'ProgramSpecV2' in line]
    if not spec_lines or not any('native_program' in line for line in spec_lines):
        raise ValueError('Linked map did not prove current versioned private ProgramSpec owner')
    c.save(out / 'private-ABI-map.json', dict(program_spec_v2_symbols=spec_lines,
        embedded_owner_lines=[line for line in map_text.splitlines() if 'embedded-programs.obj' in line]))
    c.save(out / 'vulkan-image.json', b.identity(image))
    for row in plan['frozen']:
        verified(row)
    summary = dict(linked=True, input_count=len(all_inputs), fresh_host_owners=43,
                   neighbor_modules_match_current_manifest=6, SDK_rebuilt=False, GPU_run=False, runtime='pending')
    c.save(out / 'summary.json', summary)
    if not args.run:
        return
    xml = out / 'mlx-vulkan.xml'
    run = [str(image), '--gtest_filter=' + FILTER, '--gtest_output=xml:' + str(xml)]
    c.execute('mlx-vulkan-tests', run, env, out)
    results = ET.parse(xml).getroot()
    counts = {key: int(results.attrib.get(key, '0')) for key in ('tests', 'failures', 'errors', 'disabled')}
    skipped = sum(int(suite.attrib.get('skipped', '0')) for suite in results.findall('testsuite'))
    if counts['tests'] != 18 or counts['failures'] or counts['errors'] or skipped:
        raise ValueError('Expected 18 passing MLX/private-neighbor tests without skips: ' + str((counts, skipped)))
    summary.update(GPU_run=True, runtime='passed', tests=counts, skipped=skipped,
                   artifact_execution_verified=False, xml=b.identity(xml))
    c.save(out / 'summary.json', summary)
    print('COMPLETE', out / 'summary.json', flush=True)


if __name__ == '__main__':
    main()
