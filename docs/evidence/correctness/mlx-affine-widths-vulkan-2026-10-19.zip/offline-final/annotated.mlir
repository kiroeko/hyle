module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #hal.device.target<"vulkan", [#hal.executable.target<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>]> : !hal.device
  hal.executable private @affine_linear_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:2 = util.assume.int 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 9007199254740991>
            : index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %14, 0 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#0, 3 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 4 : index
          %39 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%37, %38}
          %40 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          %41 = iree_tensor_ext.dispatch.workload.ordinal %19, 1 : index
          %42 = iree_tensor_ext.dispatch.workload.ordinal %24, 2 : index
          %43 = iree_tensor_ext.dispatch.tensor.load %39, offsets = [0, 0], sizes = [%37, %38], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%37, %38} -> tensor<?x?xf32>
          %44 = tensor.empty(%36) : tensor<?xf32>
          %45 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%44 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %46 = linalg.index 0 : index
            %47 = arith.remsi %46, %41 : index
            %48 = arith.divsi %46, %41 : index
            %49 = arith.addi %42, %47 : index
            %extracted = tensor.extract %43[%48, %49] : tensor<?x?xf32>
            linalg.yield %extracted : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %45, %40, offsets = [0], sizes = [%36], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          return
        }
        iree_codegen.dispatch_config @affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_linear_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_f32_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_f32_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(20) : i32
          %21 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(21) : i32
          %22 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(22) : i32
          %23 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(23) : i32
          %24 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(24) : i32
          %25 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(25) : i32
          %26 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(26) : i32
          %27 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(27) : i32
          %28 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(28) : i32
          %29 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(29) : i32
          %30 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(30) : i32
          %31 = arith.extui %1 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %0 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 {stream.alignment = 64 : index} : i64 to index
          %36 = arith.extui %3 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %2 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %5 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %4 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %7 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %6 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %9 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %8 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56 = arith.extui %12 : i32 to i64
          %57 = arith.shli %56, %c32_i64 : i64
          %58 = arith.extui %11 : i32 to i64
          %59 = arith.ori %58, %57 : i64
          %60 = arith.index_castui %59 : i64 to index
          %61 = arith.extui %14 : i32 to i64
          %62 = arith.shli %61, %c32_i64 : i64
          %63 = arith.extui %13 : i32 to i64
          %64 = arith.ori %63, %62 : i64
          %65 = arith.index_castui %64 : i64 to index
          %66 = arith.extui %16 : i32 to i64
          %67 = arith.shli %66, %c32_i64 : i64
          %68 = arith.extui %15 : i32 to i64
          %69 = arith.ori %68, %67 : i64
          %70 = arith.index_castui %69 : i64 to index
          %71 = arith.extui %18 : i32 to i64
          %72 = arith.shli %71, %c32_i64 : i64
          %73 = arith.extui %17 : i32 to i64
          %74 = arith.ori %73, %72 : i64
          %75 = arith.index_castui %74 : i64 to index
          %76 = arith.extui %20 : i32 to i64
          %77 = arith.shli %76, %c32_i64 : i64
          %78 = arith.extui %19 : i32 to i64
          %79 = arith.ori %78, %77 : i64
          %80 = arith.index_castui %79 : i64 to index
          %81 = arith.extui %22 : i32 to i64
          %82 = arith.shli %81, %c32_i64 : i64
          %83 = arith.extui %21 : i32 to i64
          %84 = arith.ori %83, %82 : i64
          %85 = arith.index_castui %84 : i64 to index
          %86 = arith.extui %24 : i32 to i64
          %87 = arith.shli %86, %c32_i64 : i64
          %88 = arith.extui %23 : i32 to i64
          %89 = arith.ori %88, %87 : i64
          %90 = arith.index_castui %89 : i64 to index
          %91 = arith.extui %26 : i32 to i64
          %92 = arith.shli %91, %c32_i64 : i64
          %93 = arith.extui %25 : i32 to i64
          %94 = arith.ori %93, %92 : i64
          %95 = arith.index_castui %94 : i64 to index
          %96 = arith.extui %28 : i32 to i64
          %97 = arith.shli %96, %c32_i64 : i64
          %98 = arith.extui %27 : i32 to i64
          %99 = arith.ori %98, %97 : i64
          %100 = arith.index_castui %99 : i64 to index
          %101 = arith.extui %30 : i32 to i64
          %102 = arith.shli %101, %c32_i64 : i64
          %103 = arith.extui %29 : i32 to i64
          %104 = arith.ori %103, %102 : i64
          %105 = arith.index_castui %104 : i64 to index
          %106:9 = util.assume.int 
              %65<umin = 0, umax = 9007199254740991>, 
              %70<umin = 0, umax = 9007199254740991>, 
              %75<umin = 0, umax = 9007199254740991>, 
              %80<umin = 0, umax = 9007199254740991>, 
              %85<umin = 0, umax = 9007199254740991>, 
              %90<umin = 0, umax = 9007199254740991>, 
              %95<umin = 0, umax = 9007199254740991>, 
              %100<umin = 0, umax = 9007199254740991>, 
              %105<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index, index
          %107 = iree_tensor_ext.dispatch.workload.ordinal %40, 0 : index
          %108 = iree_tensor_ext.dispatch.workload.ordinal %106#0, 5 : index
          %109 = iree_tensor_ext.dispatch.workload.ordinal %106#1, 6 : index
          %110 = iree_tensor_ext.dispatch.workload.ordinal %106#2, 7 : index
          %111 = iree_tensor_ext.dispatch.workload.ordinal %106#3, 8 : index
          %112 = iree_tensor_ext.dispatch.workload.ordinal %106#4, 9 : index
          %113 = iree_tensor_ext.dispatch.workload.ordinal %106#5, 10 : index
          %114 = iree_tensor_ext.dispatch.workload.ordinal %106#6, 11 : index
          %115 = iree_tensor_ext.dispatch.workload.ordinal %106#7, 12 : index
          %116 = iree_tensor_ext.dispatch.workload.ordinal %106#8, 13 : index
          %117 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%108, %109, %110}
          %118 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%111, %112, %113}
          %119 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%114, %115, %116}
          %120 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%35) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%107}
          %121 = iree_tensor_ext.dispatch.workload.ordinal %45, 1 : index
          %122 = iree_tensor_ext.dispatch.workload.ordinal %50, 2 : index
          %123 = iree_tensor_ext.dispatch.workload.ordinal %55, 3 : index
          %124 = iree_tensor_ext.dispatch.workload.ordinal %60, 4 : index
          %125 = iree_tensor_ext.dispatch.tensor.load %117, offsets = [0, 0, 0], sizes = [%108, %109, %110], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%108, %109, %110} -> tensor<?x?x?xi32>
          %126 = iree_tensor_ext.dispatch.tensor.load %118, offsets = [0, 0, 0], sizes = [%111, %112, %113], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%111, %112, %113} -> tensor<?x?x?xf32>
          %127 = iree_tensor_ext.dispatch.tensor.load %119, offsets = [0, 0, 0], sizes = [%114, %115, %116], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%114, %115, %116} -> tensor<?x?x?xf32>
          %128 = tensor.empty(%107) : tensor<?xf32>
          %129 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%128 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %130 = linalg.index 0 : index
            %131 = arith.remsi %130, %121 : index
            %132 = arith.divsi %130, %121 : index
            %133 = arith.remsi %132, %109 : index
            %134 = arith.addi %122, %131 : index
            %135 = arith.divui %134, %c32 : index
            %136 = arith.remui %134, %c32 : index
            %137 = arith.muli %135, %123 : index
            %138 = arith.muli %136, %123 : index
            %139 = arith.divui %138, %c32 : index
            %140 = arith.addi %137, %139 : index
            %141 = arith.remui %138, %c32 : index
            %142 = arith.addi %141, %123 : index
            %143 = arith.cmpi ugt, %142, %c32 : index
            %144 = arith.addi %140, %c1 : index
            %145 = arith.select %143, %144, %140 : index
            %extracted = tensor.extract %125[%c0, %133, %140] : tensor<?x?x?xi32>
            %extracted_0 = tensor.extract %125[%c0, %133, %145] : tensor<?x?x?xi32>
            %146 = arith.index_castui %141 : index to i32
            %147 = arith.shrui %extracted, %146 : i32
            %148 = arith.subi %c32, %141 : index
            %149 = arith.index_castui %148 : index to i32
            %150 = arith.andi %149, %c31_i32 : i32
            %151 = arith.shli %extracted_0, %150 : i32
            %152 = arith.select %143, %151, %c0_i32 : i32
            %153 = arith.ori %147, %152 : i32
            %154 = arith.andi %153, %10 : i32
            %155 = arith.uitofp %154 : i32 to f32
            %extracted_1 = tensor.extract %126[%c0, %133, %124] : tensor<?x?x?xf32>
            %extracted_2 = tensor.extract %127[%c0, %133, %124] : tensor<?x?x?xf32>
            %156 = arith.mulf %155, %extracted_1 : f32
            %157 = arith.addf %156, %extracted_2 : f32
            linalg.yield %157 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %129, %120, offsets = [0], sizes = [%107], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%107}
          return
        }
        iree_codegen.dispatch_config @affine_linear_f32_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_linear_f32_dispatch_2 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %cst = arith.constant 0.000000e+00 : f32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = arith.extui %1 : i32 to i64
          %7 = arith.shli %6, %c32_i64 : i64
          %8 = arith.extui %0 : i32 to i64
          %9 = arith.ori %8, %7 : i64
          %10 = arith.index_castui %9 : i64 to index
          %11 = arith.extui %3 : i32 to i64
          %12 = arith.shli %11, %c32_i64 : i64
          %13 = arith.extui %2 : i32 to i64
          %14 = arith.ori %13, %12 : i64
          %15 = arith.index_castui %14 : i64 to index
          %16 = arith.extui %5 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %4 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21:2 = util.assume.int 
              %10<umin = 0, umax = 9007199254740991>, 
              %20<umin = 0, umax = 9007199254740991>
            : index, index
          %22 = iree_tensor_ext.dispatch.workload.ordinal %21#0, 0 : index
          %23 = iree_tensor_ext.dispatch.workload.ordinal %15, 1 : index
          %24 = iree_tensor_ext.dispatch.workload.ordinal %21#1, 2 : index
          %25 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x1x?xf32>>{%22, %23}
          %26 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%22, %24, %23}
          %27 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?x1x?xf32>>{%22, %24}
          %28 = iree_tensor_ext.dispatch.tensor.load %25, offsets = [0, 0, 0], sizes = [%22, 1, %23], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x1x?xf32>>{%22, %23} -> tensor<?x1x?xf32>
          %29 = iree_tensor_ext.dispatch.tensor.load %26, offsets = [0, 0, 0], sizes = [%22, %24, %23], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%22, %24, %23} -> tensor<?x?x?xf32>
          %30 = tensor.empty(%22, %24) : tensor<?x1x?xf32>
          %31 = linalg.fill ins(%cst : f32) outs(%30 : tensor<?x1x?xf32>) -> tensor<?x1x?xf32>
          %32 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2)>], iterator_types = ["parallel", "parallel", "parallel", "reduction"]} ins(%28, %29 : tensor<?x1x?xf32>, tensor<?x?x?xf32>) outs(%31 : tensor<?x1x?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[1, 0, 64], [1, 0, 1]]>} {
          ^bb0(%in: f32, %in_0: f32, %out: f32):
            %33 = arith.mulf %in, %in_0 : f32
            %34 = arith.addf %out, %33 : f32
            linalg.yield %34 : f32
          } -> tensor<?x1x?xf32>
          iree_tensor_ext.dispatch.tensor.store %32, %27, offsets = [0, 0, 0], sizes = [%22, 1, %24], strides = [1, 1, 1] : tensor<?x1x?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?x1x?xf32>>{%22, %24}
          return
        }
        iree_codegen.dispatch_config @affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_linear_f32_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = arith.extui %1 : i32 to i64
          %9 = arith.shli %8, %c32_i64 : i64
          %10 = arith.extui %0 : i32 to i64
          %11 = arith.ori %10, %9 : i64
          %12 = arith.index_castui %11 {stream.alignment = 64 : index} : i64 to index
          %13 = arith.extui %3 : i32 to i64
          %14 = arith.shli %13, %c32_i64 : i64
          %15 = arith.extui %2 : i32 to i64
          %16 = arith.ori %15, %14 : i64
          %17 = arith.index_castui %16 : i64 to index
          %18 = arith.extui %5 : i32 to i64
          %19 = arith.shli %18, %c32_i64 : i64
          %20 = arith.extui %4 : i32 to i64
          %21 = arith.ori %20, %19 : i64
          %22 = arith.index_castui %21 : i64 to index
          %23 = arith.extui %7 : i32 to i64
          %24 = arith.shli %23, %c32_i64 : i64
          %25 = arith.extui %6 : i32 to i64
          %26 = arith.ori %25, %24 : i64
          %27 = arith.index_castui %26 : i64 to index
          %28:2 = util.assume.int 
              %22<umin = 0, umax = 9007199254740991>, 
              %27<umin = 0, umax = 9007199254740991>
            : index, index
          %29 = iree_tensor_ext.dispatch.workload.ordinal %17, 0 : index
          %30 = iree_tensor_ext.dispatch.workload.ordinal %28#0, 1 : index
          %31 = iree_tensor_ext.dispatch.workload.ordinal %28#1, 2 : index
          %32 = hal.interface.binding.subspan layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%31, %30}
          %33 = hal.interface.binding.subspan layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%12) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%31, %30}
          %34 = hal.interface.binding.subspan layout(<constants = 8, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%29}
          %35 = iree_tensor_ext.dispatch.tensor.load %32, offsets = [0, 0], sizes = [%31, %30], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%31, %30} -> tensor<?x?xf32>
          %36 = iree_tensor_ext.dispatch.tensor.load %33, offsets = [0, 0], sizes = [%31, %30], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%31, %30} -> tensor<?x?xf32>
          %37 = tensor.empty(%29) : tensor<?xf32>
          %38 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%37 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %39 = linalg.index 0 : index
            %40 = arith.remsi %39, %30 : index
            %41 = arith.divsi %39, %30 : index
            %extracted = tensor.extract %35[%41, %40] : tensor<?x?xf32>
            %extracted_0 = tensor.extract %36[%41, %40] : tensor<?x?xf32>
            %42 = arith.addf %extracted_0, %extracted : f32
            linalg.yield %42 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %38, %34, offsets = [0], sizes = [%29], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%29}
          return
        }
        iree_codegen.dispatch_config @affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_linear_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: !hal.fence, %arg7: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_linear_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xf32>, %input3: tensor<?x?x?xf32>, %input4: i32, %input5: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c0_i8 = arith.constant 0 : i8
    %c1_i32 = arith.constant 1 : i32
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg6 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_f32) encoding(%dense_row_major)
    %16 = arith.muli %13, %c4 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    %21 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[1] : index
    %22 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20, %21, %22]) type(%element_type_f32) encoding(%dense_row_major)
    %23 = arith.muli %20, %c4 : index
    %24 = arith.muli %23, %21 : index
    %25 = arith.muli %24, %22 : index
    %26 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?x?x?xf32>{%20, %21, %22} in !stream.resource<external>{%25}
    %27 = arith.index_cast %arg4 : i32 to index
    %28 = arith.divui %1, %27 : index
    %29 = arith.muli %2, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%29} => !stream.timepoint
    %30 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg8: !stream.resource<external>{%29}) {
      stream.cmd.fill %c0_i8, %arg8[%c0 for %29] : i8 -> !stream.resource<external>{%29}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %29, %30 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb1(%31: index, %32: !stream.resource<external>, %33: index, %34: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %35 = arith.cmpi slt, %31, %28 : index
    cf.cond_br %35, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %36 = arith.muli %31, %27 : index
    %37 = arith.muli %0, %27 overflow<nsw> : index
    %38 = arith.muli %37, %c4 : index
    %39 = arith.muli %0, %7 overflow<nsw> : index
    %40 = arith.muli %39, %27 overflow<nsw> : index
    %41 = arith.shli %c1_i32, %arg5 : i32
    %42 = arith.index_cast %arg5 : i32 to index
    %43 = arith.subi %41, %c1_i32 : i32
    %44 = arith.muli %40, %c4 : index
    %45 = util.align %38, %c64 : index
    %46 = util.align %44, %c64 : index
    %47 = arith.addi %45, %46 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%47} => !stream.timepoint
    %48 = arith.index_castui %37 : index to i64
    %49 = arith.index_castui %37 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %27 : index to i64
    %53 = arith.index_castui %27 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = arith.index_castui %36 : index to i64
    %57 = arith.index_castui %36 : index to i32
    %58 = arith.shrui %56, %c32_i64 : i64
    %59 = arith.trunci %58 : i64 to i32
    %60 = arith.index_castui %0 : index to i64
    %61 = arith.index_castui %0 : index to i32
    %62 = arith.shrui %60, %c32_i64 : i64
    %63 = arith.trunci %62 : i64 to i32
    %64 = arith.index_castui %1 : index to i64
    %65 = arith.index_castui %1 : index to i32
    %66 = arith.shrui %64, %c32_i64 : i64
    %67 = arith.trunci %66 : i64 to i32
    %68 = arith.index_castui %45 : index to i64
    %69 = arith.index_castui %45 : index to i32
    %70 = arith.shrui %68, %c32_i64 : i64
    %71 = arith.trunci %70 : i64 to i32
    %72 = arith.index_castui %40 : index to i64
    %73 = arith.index_castui %40 : index to i32
    %74 = arith.shrui %72, %c32_i64 : i64
    %75 = arith.trunci %74 : i64 to i32
    %76 = arith.index_castui %42 : index to i64
    %77 = arith.index_castui %42 : index to i32
    %78 = arith.shrui %76, %c32_i64 : i64
    %79 = arith.trunci %78 : i64 to i32
    %80 = arith.index_castui %31 : index to i64
    %81 = arith.index_castui %31 : index to i32
    %82 = arith.shrui %80, %c32_i64 : i64
    %83 = arith.trunci %82 : i64 to i32
    %84 = arith.index_castui %6 : index to i64
    %85 = arith.index_castui %6 : index to i32
    %86 = arith.shrui %84, %c32_i64 : i64
    %87 = arith.trunci %86 : i64 to i32
    %88 = arith.index_castui %7 : index to i64
    %89 = arith.index_castui %7 : index to i32
    %90 = arith.shrui %88, %c32_i64 : i64
    %91 = arith.trunci %90 : i64 to i32
    %92 = arith.index_castui %8 : index to i64
    %93 = arith.index_castui %8 : index to i32
    %94 = arith.shrui %92, %c32_i64 : i64
    %95 = arith.trunci %94 : i64 to i32
    %96 = arith.index_castui %13 : index to i64
    %97 = arith.index_castui %13 : index to i32
    %98 = arith.shrui %96, %c32_i64 : i64
    %99 = arith.trunci %98 : i64 to i32
    %100 = arith.index_castui %14 : index to i64
    %101 = arith.index_castui %14 : index to i32
    %102 = arith.shrui %100, %c32_i64 : i64
    %103 = arith.trunci %102 : i64 to i32
    %104 = arith.index_castui %15 : index to i64
    %105 = arith.index_castui %15 : index to i32
    %106 = arith.shrui %104, %c32_i64 : i64
    %107 = arith.trunci %106 : i64 to i32
    %108 = arith.index_castui %20 : index to i64
    %109 = arith.index_castui %20 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %21 : index to i64
    %113 = arith.index_castui %21 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %22 : index to i64
    %117 = arith.index_castui %22 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg8: !stream.resource<external>{%3}, %12 as %arg9: !stream.resource<external>{%11}, %19 as %arg10: !stream.resource<external>{%18}, %26 as %arg11: !stream.resource<external>{%25}, %result_0 as %arg12: !stream.resource<transient>{%47}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_0::@vulkan_spirv_fb::@affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32[%37, %27, %36, %0, %1](%49, %51, %53, %55, %57, %59, %61, %63, %65, %67 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg12[%c0 for %47] : !stream.resource<transient>{%47}
      }
      stream.cmd.dispatch @affine_linear_f32_dispatch_1::@vulkan_spirv_fb::@affine_linear_f32_dispatch_1_elementwise_broadcast_D_f32[%40, %27, %36, %42, %31, %6, %7, %8, %13, %14, %15, %20, %21, %22](%69, %71, %73, %75, %53, %55, %57, %59, %77, %79, %43, %81, %83, %85, %87, %89, %91, %93, %95, %97, %99, %101, %103, %105, %107, %109, %111, %113, %115, %117, %119 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg10[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg11[%c0 for %25] : !stream.resource<external>{%25},
        wo %arg12[%c0 for %47] : !stream.resource<transient>{%47}
      }
    } => !stream.timepoint
    %121 = arith.muli %29, %27 : index
    %122 = stream.timepoint.await %120 => %result_0 : !stream.resource<transient>{%47}
    %123 = stream.resource.subview %122[%c0] : !stream.resource<transient>{%47} -> !stream.resource<transient>{%38}
    %124 = stream.resource.subview %122[%45] : !stream.resource<transient>{%47} -> !stream.resource<transient>{%44}
    %125 = util.optimization_barrier %123 : !stream.resource<transient>
    %126 = util.optimization_barrier %124 : !stream.resource<transient>
    %127 = arith.muli %2, %27 : index
    %128 = arith.muli %39, %c4 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%34) => !stream.resource<external>{%128} => !stream.timepoint
    %129 = util.align %29, %c64 : index
    %130 = arith.addi %129, %129 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%34) => !stream.resource<transient>{%130} => !stream.timepoint
    %131 = stream.timepoint.join max(%result_timepoint_3, %result_timepoint_5) => !stream.timepoint
    %132 = arith.index_castui %129 : index to i64
    %133 = arith.index_castui %129 : index to i32
    %134 = arith.shrui %132, %c32_i64 : i64
    %135 = arith.trunci %134 : i64 to i32
    %136 = arith.index_castui %39 : index to i64
    %137 = arith.index_castui %39 : index to i32
    %138 = arith.shrui %136, %c32_i64 : i64
    %139 = arith.trunci %138 : i64 to i32
    %140 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%131) => with(%125 as %arg8: !stream.resource<transient>{%127}, %126 as %arg9: !stream.resource<transient>{%121}, %32 as %arg10: !stream.resource<external>{%33}, %result_2 as %arg11: !stream.resource<external>{%128}, %result_4 as %arg12: !stream.resource<transient>{%130}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %27, %7](%61, %63, %53, %55, %89, %91 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %127] : !stream.resource<transient>{%127},
        ro %arg9[%c0 for %121] : !stream.resource<transient>{%121},
        wo %arg12[%c0 for %130] : !stream.resource<transient>{%130}
      }
      stream.cmd.copy %arg10[%c0], %arg12[%129], %29 : !stream.resource<external>{%29} -> !stream.resource<transient>{%130}
      stream.cmd.dispatch @affine_linear_f32_dispatch_3::@vulkan_spirv_fb::@affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32[%39, %7, %0](%133, %135, %137, %139, %89, %91, %61, %63 : i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg12[%c0 for %130] : !stream.resource<transient>{%130},
        wo %arg11[%c0 for %128] : !stream.resource<external>{%128}
      }
    } => !stream.timepoint
    %141 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%140) => %result_4 : !stream.resource<transient>{%130} => !stream.timepoint
    %142 = arith.addi %31, %c1 : index
    cf.br ^bb1(%142, %result_2, %128, %141 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %34 => (%arg7 : !hal.fence)
    %143 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %32 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%29} -> !hal.buffer_view
    util.return %143 : !hal.buffer_view
  }
  hal.executable private @affine_grouped_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_grouped_f32_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index, %arg15: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14, %arg15)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_grouped_f32_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(20) : i32
          %21 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(21) : i32
          %22 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(22) : i32
          %23 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(23) : i32
          %24 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(24) : i32
          %25 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(25) : i32
          %26 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(26) : i32
          %27 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(27) : i32
          %28 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(28) : i32
          %29 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(29) : i32
          %30 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(30) : i32
          %31 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(31) : i32
          %32 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(32) : i32
          %33 = arith.extui %1 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %0 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 {stream.alignment = 64 : index} : i64 to index
          %38 = arith.extui %3 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %2 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %5 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %4 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %7 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %6 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %9 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %8 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %12 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %11 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63 = arith.extui %14 : i32 to i64
          %64 = arith.shli %63, %c32_i64 : i64
          %65 = arith.extui %13 : i32 to i64
          %66 = arith.ori %65, %64 : i64
          %67 = arith.index_castui %66 : i64 to index
          %68 = arith.extui %16 : i32 to i64
          %69 = arith.shli %68, %c32_i64 : i64
          %70 = arith.extui %15 : i32 to i64
          %71 = arith.ori %70, %69 : i64
          %72 = arith.index_castui %71 : i64 to index
          %73 = arith.extui %18 : i32 to i64
          %74 = arith.shli %73, %c32_i64 : i64
          %75 = arith.extui %17 : i32 to i64
          %76 = arith.ori %75, %74 : i64
          %77 = arith.index_castui %76 : i64 to index
          %78 = arith.extui %20 : i32 to i64
          %79 = arith.shli %78, %c32_i64 : i64
          %80 = arith.extui %19 : i32 to i64
          %81 = arith.ori %80, %79 : i64
          %82 = arith.index_castui %81 : i64 to index
          %83 = arith.extui %22 : i32 to i64
          %84 = arith.shli %83, %c32_i64 : i64
          %85 = arith.extui %21 : i32 to i64
          %86 = arith.ori %85, %84 : i64
          %87 = arith.index_castui %86 : i64 to index
          %88 = arith.extui %24 : i32 to i64
          %89 = arith.shli %88, %c32_i64 : i64
          %90 = arith.extui %23 : i32 to i64
          %91 = arith.ori %90, %89 : i64
          %92 = arith.index_castui %91 : i64 to index
          %93 = arith.extui %26 : i32 to i64
          %94 = arith.shli %93, %c32_i64 : i64
          %95 = arith.extui %25 : i32 to i64
          %96 = arith.ori %95, %94 : i64
          %97 = arith.index_castui %96 : i64 to index
          %98 = arith.extui %28 : i32 to i64
          %99 = arith.shli %98, %c32_i64 : i64
          %100 = arith.extui %27 : i32 to i64
          %101 = arith.ori %100, %99 : i64
          %102 = arith.index_castui %101 : i64 to index
          %103 = arith.extui %30 : i32 to i64
          %104 = arith.shli %103, %c32_i64 : i64
          %105 = arith.extui %29 : i32 to i64
          %106 = arith.ori %105, %104 : i64
          %107 = arith.index_castui %106 : i64 to index
          %108 = arith.extui %32 : i32 to i64
          %109 = arith.shli %108, %c32_i64 : i64
          %110 = arith.extui %31 : i32 to i64
          %111 = arith.ori %110, %109 : i64
          %112 = arith.index_castui %111 : i64 to index
          %113:10 = util.assume.int 
              %67<umin = 0, umax = 9007199254740991>, 
              %72<umin = 0, umax = 9007199254740991>, 
              %77<umin = 0, umax = 9007199254740991>, 
              %82<umin = 0, umax = 9007199254740991>, 
              %87<umin = 0, umax = 9007199254740991>, 
              %92<umin = 0, umax = 9007199254740991>, 
              %97<umin = 0, umax = 9007199254740991>, 
              %102<umin = 0, umax = 9007199254740991>, 
              %107<umin = 0, umax = 9007199254740991>, 
              %112<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index, index, index
          %114 = iree_tensor_ext.dispatch.workload.ordinal %42, 0 : index
          %115 = iree_tensor_ext.dispatch.workload.ordinal %113#0, 5 : index
          %116 = iree_tensor_ext.dispatch.workload.ordinal %113#1, 6 : index
          %117 = iree_tensor_ext.dispatch.workload.ordinal %113#2, 7 : index
          %118 = iree_tensor_ext.dispatch.workload.ordinal %113#3, 8 : index
          %119 = iree_tensor_ext.dispatch.workload.ordinal %113#4, 9 : index
          %120 = iree_tensor_ext.dispatch.workload.ordinal %113#5, 10 : index
          %121 = iree_tensor_ext.dispatch.workload.ordinal %113#6, 11 : index
          %122 = iree_tensor_ext.dispatch.workload.ordinal %113#7, 12 : index
          %123 = iree_tensor_ext.dispatch.workload.ordinal %113#8, 13 : index
          %124 = iree_tensor_ext.dispatch.workload.ordinal %113#9, 14 : index
          %125 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%115}
          %126 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%116, %117, %118}
          %127 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%119, %120, %121}
          %128 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%122, %123, %124}
          %129 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(4) alignment(64) offset(%37) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%114}
          %130 = iree_tensor_ext.dispatch.workload.ordinal %47, 1 : index
          %131 = iree_tensor_ext.dispatch.workload.ordinal %52, 2 : index
          %132 = iree_tensor_ext.dispatch.workload.ordinal %57, 3 : index
          %133 = iree_tensor_ext.dispatch.workload.ordinal %62, 4 : index
          %134 = iree_tensor_ext.dispatch.tensor.load %125, offsets = [0], sizes = [%115], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%115} -> tensor<?xi32>
          %135 = iree_tensor_ext.dispatch.tensor.load %126, offsets = [0, 0, 0], sizes = [%116, %117, %118], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%116, %117, %118} -> tensor<?x?x?xi32>
          %136 = iree_tensor_ext.dispatch.tensor.load %127, offsets = [0, 0, 0], sizes = [%119, %120, %121], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%119, %120, %121} -> tensor<?x?x?xf32>
          %137 = iree_tensor_ext.dispatch.tensor.load %128, offsets = [0, 0, 0], sizes = [%122, %123, %124], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf32>>{%122, %123, %124} -> tensor<?x?x?xf32>
          %138 = tensor.empty(%114) : tensor<?xf32>
          %139 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%138 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %140 = linalg.index 0 : index
            %141 = arith.remsi %140, %130 : index
            %142 = arith.divsi %140, %130 : index
            %143 = arith.remsi %142, %117 : index
            %144 = arith.divsi %142, %117 : index
            %extracted = tensor.extract %134[%144] : tensor<?xi32>
            %145 = arith.index_cast %extracted : i32 to index
            %146 = arith.addi %131, %141 : index
            %147 = arith.divui %146, %c32 : index
            %148 = arith.remui %146, %c32 : index
            %149 = arith.muli %147, %132 : index
            %150 = arith.muli %148, %132 : index
            %151 = arith.divui %150, %c32 : index
            %152 = arith.addi %149, %151 : index
            %153 = arith.remui %150, %c32 : index
            %154 = arith.addi %153, %132 : index
            %155 = arith.cmpi ugt, %154, %c32 : index
            %156 = arith.addi %152, %c1 : index
            %157 = arith.select %155, %156, %152 : index
            %extracted_0 = tensor.extract %135[%145, %143, %152] : tensor<?x?x?xi32>
            %extracted_1 = tensor.extract %135[%145, %143, %157] : tensor<?x?x?xi32>
            %158 = arith.index_castui %153 : index to i32
            %159 = arith.shrui %extracted_0, %158 : i32
            %160 = arith.subi %c32, %153 : index
            %161 = arith.index_castui %160 : index to i32
            %162 = arith.andi %161, %c31_i32 : i32
            %163 = arith.shli %extracted_1, %162 : i32
            %164 = arith.select %155, %163, %c0_i32 : i32
            %165 = arith.ori %159, %164 : i32
            %166 = arith.andi %165, %10 : i32
            %167 = arith.uitofp %166 : i32 to f32
            %extracted_2 = tensor.extract %136[%145, %143, %133] : tensor<?x?x?xf32>
            %extracted_3 = tensor.extract %137[%145, %143, %133] : tensor<?x?x?xf32>
            %168 = arith.mulf %167, %extracted_2 : f32
            %169 = arith.addf %168, %extracted_3 : f32
            linalg.yield %169 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %139, %129, offsets = [0], sizes = [%114], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%114}
          return
        }
        iree_codegen.dispatch_config @affine_grouped_f32_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index, %arg15: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14, %arg15)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_grouped_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: !hal.buffer_view, %arg5: i32, %arg6: i32, %arg7: !hal.fence, %arg8: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_grouped_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xf32>, %input3: tensor<?x?x?xf32>, %input4: tensor<?xi32>, %input5: i32, %input6: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c0_i8 = arith.constant 0 : i8
    %c1_i32 = arith.constant 1 : i32
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_f32) encoding(%dense_row_major)
    %16 = arith.muli %13, %c4 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf32>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    %21 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[1] : index
    %22 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20, %21, %22]) type(%element_type_f32) encoding(%dense_row_major)
    %23 = arith.muli %20, %c4 : index
    %24 = arith.muli %23, %21 : index
    %25 = arith.muli %24, %22 : index
    %26 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?x?x?xf32>{%20, %21, %22} in !stream.resource<external>{%25}
    %27 = hal.buffer_view.dim<%arg4 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg4 : !hal.buffer_view> message("input4") shape([%27]) type(%element_type_i32) encoding(%dense_row_major)
    %28 = arith.muli %27, %c4 : index
    %29 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg4 : !hal.buffer_view -> tensor<?xi32>{%27} in !stream.resource<external>{%28}
    %30 = arith.index_cast %arg5 : i32 to index
    %31 = arith.divui %1, %30 : index
    %32 = arith.muli %2, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%32} => !stream.timepoint
    %33 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg9: !stream.resource<external>{%32}) {
      stream.cmd.fill %c0_i8, %arg9[%c0 for %32] : i8 -> !stream.resource<external>{%32}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %32, %33 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb1(%34: index, %35: !stream.resource<external>, %36: index, %37: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %38 = arith.cmpi slt, %34, %31 : index
    cf.cond_br %38, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %39 = arith.muli %34, %30 : index
    %40 = arith.muli %0, %30 overflow<nsw> : index
    %41 = arith.muli %40, %c4 : index
    %42 = arith.muli %0, %7 overflow<nsw> : index
    %43 = arith.muli %42, %30 overflow<nsw> : index
    %44 = arith.shli %c1_i32, %arg6 : i32
    %45 = arith.index_cast %arg6 : i32 to index
    %46 = arith.subi %44, %c1_i32 : i32
    %47 = arith.muli %43, %c4 : index
    %48 = util.align %41, %c64 : index
    %49 = util.align %47, %c64 : index
    %50 = arith.addi %48, %49 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%50} => !stream.timepoint
    %51 = arith.index_castui %40 : index to i64
    %52 = arith.index_castui %40 : index to i32
    %53 = arith.shrui %51, %c32_i64 : i64
    %54 = arith.trunci %53 : i64 to i32
    %55 = arith.index_castui %30 : index to i64
    %56 = arith.index_castui %30 : index to i32
    %57 = arith.shrui %55, %c32_i64 : i64
    %58 = arith.trunci %57 : i64 to i32
    %59 = arith.index_castui %39 : index to i64
    %60 = arith.index_castui %39 : index to i32
    %61 = arith.shrui %59, %c32_i64 : i64
    %62 = arith.trunci %61 : i64 to i32
    %63 = arith.index_castui %0 : index to i64
    %64 = arith.index_castui %0 : index to i32
    %65 = arith.shrui %63, %c32_i64 : i64
    %66 = arith.trunci %65 : i64 to i32
    %67 = arith.index_castui %1 : index to i64
    %68 = arith.index_castui %1 : index to i32
    %69 = arith.shrui %67, %c32_i64 : i64
    %70 = arith.trunci %69 : i64 to i32
    %71 = arith.index_castui %48 : index to i64
    %72 = arith.index_castui %48 : index to i32
    %73 = arith.shrui %71, %c32_i64 : i64
    %74 = arith.trunci %73 : i64 to i32
    %75 = arith.index_castui %43 : index to i64
    %76 = arith.index_castui %43 : index to i32
    %77 = arith.shrui %75, %c32_i64 : i64
    %78 = arith.trunci %77 : i64 to i32
    %79 = arith.index_castui %45 : index to i64
    %80 = arith.index_castui %45 : index to i32
    %81 = arith.shrui %79, %c32_i64 : i64
    %82 = arith.trunci %81 : i64 to i32
    %83 = arith.index_castui %34 : index to i64
    %84 = arith.index_castui %34 : index to i32
    %85 = arith.shrui %83, %c32_i64 : i64
    %86 = arith.trunci %85 : i64 to i32
    %87 = arith.index_castui %27 : index to i64
    %88 = arith.index_castui %27 : index to i32
    %89 = arith.shrui %87, %c32_i64 : i64
    %90 = arith.trunci %89 : i64 to i32
    %91 = arith.index_castui %6 : index to i64
    %92 = arith.index_castui %6 : index to i32
    %93 = arith.shrui %91, %c32_i64 : i64
    %94 = arith.trunci %93 : i64 to i32
    %95 = arith.index_castui %7 : index to i64
    %96 = arith.index_castui %7 : index to i32
    %97 = arith.shrui %95, %c32_i64 : i64
    %98 = arith.trunci %97 : i64 to i32
    %99 = arith.index_castui %8 : index to i64
    %100 = arith.index_castui %8 : index to i32
    %101 = arith.shrui %99, %c32_i64 : i64
    %102 = arith.trunci %101 : i64 to i32
    %103 = arith.index_castui %13 : index to i64
    %104 = arith.index_castui %13 : index to i32
    %105 = arith.shrui %103, %c32_i64 : i64
    %106 = arith.trunci %105 : i64 to i32
    %107 = arith.index_castui %14 : index to i64
    %108 = arith.index_castui %14 : index to i32
    %109 = arith.shrui %107, %c32_i64 : i64
    %110 = arith.trunci %109 : i64 to i32
    %111 = arith.index_castui %15 : index to i64
    %112 = arith.index_castui %15 : index to i32
    %113 = arith.shrui %111, %c32_i64 : i64
    %114 = arith.trunci %113 : i64 to i32
    %115 = arith.index_castui %20 : index to i64
    %116 = arith.index_castui %20 : index to i32
    %117 = arith.shrui %115, %c32_i64 : i64
    %118 = arith.trunci %117 : i64 to i32
    %119 = arith.index_castui %21 : index to i64
    %120 = arith.index_castui %21 : index to i32
    %121 = arith.shrui %119, %c32_i64 : i64
    %122 = arith.trunci %121 : i64 to i32
    %123 = arith.index_castui %22 : index to i64
    %124 = arith.index_castui %22 : index to i32
    %125 = arith.shrui %123, %c32_i64 : i64
    %126 = arith.trunci %125 : i64 to i32
    %127 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg9: !stream.resource<external>{%3}, %29 as %arg10: !stream.resource<external>{%28}, %12 as %arg11: !stream.resource<external>{%11}, %19 as %arg12: !stream.resource<external>{%18}, %26 as %arg13: !stream.resource<external>{%25}, %result_0 as %arg14: !stream.resource<transient>{%50}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_0::@vulkan_spirv_fb::@affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32[%40, %30, %39, %0, %1](%52, %54, %56, %58, %60, %62, %64, %66, %68, %70 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg14[%c0 for %50] : !stream.resource<transient>{%50}
      }
      stream.cmd.dispatch @affine_grouped_f32_dispatch_1::@vulkan_spirv_fb::@affine_grouped_f32_dispatch_1_elementwise_broadcast_D_f32[%43, %30, %39, %45, %34, %27, %6, %7, %8, %13, %14, %15, %20, %21, %22](%72, %74, %76, %78, %56, %58, %60, %62, %80, %82, %46, %84, %86, %88, %90, %92, %94, %96, %98, %100, %102, %104, %106, %108, %110, %112, %114, %116, %118, %120, %122, %124, %126 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg10[%c0 for %28] : !stream.resource<external>{%28},
        ro %arg11[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg12[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg13[%c0 for %25] : !stream.resource<external>{%25},
        wo %arg14[%c0 for %50] : !stream.resource<transient>{%50}
      }
    } => !stream.timepoint
    %128 = arith.muli %32, %30 : index
    %129 = stream.timepoint.await %127 => %result_0 : !stream.resource<transient>{%50}
    %130 = stream.resource.subview %129[%c0] : !stream.resource<transient>{%50} -> !stream.resource<transient>{%41}
    %131 = stream.resource.subview %129[%48] : !stream.resource<transient>{%50} -> !stream.resource<transient>{%47}
    %132 = util.optimization_barrier %130 : !stream.resource<transient>
    %133 = util.optimization_barrier %131 : !stream.resource<transient>
    %134 = arith.muli %2, %30 : index
    %135 = arith.muli %42, %c4 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%37) => !stream.resource<external>{%135} => !stream.timepoint
    %136 = util.align %32, %c64 : index
    %137 = arith.addi %136, %136 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%37) => !stream.resource<transient>{%137} => !stream.timepoint
    %138 = stream.timepoint.join max(%result_timepoint_3, %result_timepoint_5) => !stream.timepoint
    %139 = arith.index_castui %136 : index to i64
    %140 = arith.index_castui %136 : index to i32
    %141 = arith.shrui %139, %c32_i64 : i64
    %142 = arith.trunci %141 : i64 to i32
    %143 = arith.index_castui %42 : index to i64
    %144 = arith.index_castui %42 : index to i32
    %145 = arith.shrui %143, %c32_i64 : i64
    %146 = arith.trunci %145 : i64 to i32
    %147 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%138) => with(%132 as %arg9: !stream.resource<transient>{%134}, %133 as %arg10: !stream.resource<transient>{%128}, %35 as %arg11: !stream.resource<external>{%36}, %result_2 as %arg12: !stream.resource<external>{%135}, %result_4 as %arg13: !stream.resource<transient>{%137}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %30, %7](%64, %66, %56, %58, %96, %98 : i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %134] : !stream.resource<transient>{%134},
        ro %arg10[%c0 for %128] : !stream.resource<transient>{%128},
        wo %arg13[%c0 for %137] : !stream.resource<transient>{%137}
      }
      stream.cmd.copy %arg11[%c0], %arg13[%136], %32 : !stream.resource<external>{%32} -> !stream.resource<transient>{%137}
      stream.cmd.dispatch @affine_linear_f32_dispatch_3::@vulkan_spirv_fb::@affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32[%42, %7, %0](%140, %142, %144, %146, %96, %98, %64, %66 : i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg13[%c0 for %137] : !stream.resource<transient>{%137},
        wo %arg12[%c0 for %135] : !stream.resource<external>{%135}
      }
    } => !stream.timepoint
    %148 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%147) => %result_4 : !stream.resource<transient>{%137} => !stream.timepoint
    %149 = arith.addi %34, %c1 : index
    cf.br ^bb1(%149, %result_2, %135, %148 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %37 => (%arg8 : !hal.fence)
    %150 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %35 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%32} -> !hal.buffer_view
    util.return %150 : !hal.buffer_view
  }
  hal.executable private @affine_linear_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:2 = util.assume.int 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 9007199254740991>
            : index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %14, 0 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#0, 3 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 4 : index
          %39 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%37, %38}
          %40 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          %41 = iree_tensor_ext.dispatch.workload.ordinal %19, 1 : index
          %42 = iree_tensor_ext.dispatch.workload.ordinal %24, 2 : index
          %43 = iree_tensor_ext.dispatch.tensor.load %39, offsets = [0, 0], sizes = [%37, %38], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%37, %38} -> tensor<?x?xf16>
          %44 = tensor.empty(%36) : tensor<?xf32>
          %45 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%44 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %46 = linalg.index 0 : index
            %47 = arith.remsi %46, %41 : index
            %48 = arith.divsi %46, %41 : index
            %49 = arith.addi %42, %47 : index
            %extracted = tensor.extract %43[%48, %49] : tensor<?x?xf16>
            %50 = arith.extf %extracted : f16 to f32
            linalg.yield %50 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %45, %40, offsets = [0], sizes = [%36], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          return
        }
        iree_codegen.dispatch_config @affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_linear_f16_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_f16_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_f16_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(20) : i32
          %21 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(21) : i32
          %22 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(22) : i32
          %23 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(23) : i32
          %24 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(24) : i32
          %25 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(25) : i32
          %26 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(26) : i32
          %27 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(27) : i32
          %28 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(28) : i32
          %29 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(29) : i32
          %30 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(30) : i32
          %31 = arith.extui %1 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %0 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 {stream.alignment = 64 : index} : i64 to index
          %36 = arith.extui %3 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %2 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %5 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %4 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %7 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %6 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %9 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %8 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56 = arith.extui %12 : i32 to i64
          %57 = arith.shli %56, %c32_i64 : i64
          %58 = arith.extui %11 : i32 to i64
          %59 = arith.ori %58, %57 : i64
          %60 = arith.index_castui %59 : i64 to index
          %61 = arith.extui %14 : i32 to i64
          %62 = arith.shli %61, %c32_i64 : i64
          %63 = arith.extui %13 : i32 to i64
          %64 = arith.ori %63, %62 : i64
          %65 = arith.index_castui %64 : i64 to index
          %66 = arith.extui %16 : i32 to i64
          %67 = arith.shli %66, %c32_i64 : i64
          %68 = arith.extui %15 : i32 to i64
          %69 = arith.ori %68, %67 : i64
          %70 = arith.index_castui %69 : i64 to index
          %71 = arith.extui %18 : i32 to i64
          %72 = arith.shli %71, %c32_i64 : i64
          %73 = arith.extui %17 : i32 to i64
          %74 = arith.ori %73, %72 : i64
          %75 = arith.index_castui %74 : i64 to index
          %76 = arith.extui %20 : i32 to i64
          %77 = arith.shli %76, %c32_i64 : i64
          %78 = arith.extui %19 : i32 to i64
          %79 = arith.ori %78, %77 : i64
          %80 = arith.index_castui %79 : i64 to index
          %81 = arith.extui %22 : i32 to i64
          %82 = arith.shli %81, %c32_i64 : i64
          %83 = arith.extui %21 : i32 to i64
          %84 = arith.ori %83, %82 : i64
          %85 = arith.index_castui %84 : i64 to index
          %86 = arith.extui %24 : i32 to i64
          %87 = arith.shli %86, %c32_i64 : i64
          %88 = arith.extui %23 : i32 to i64
          %89 = arith.ori %88, %87 : i64
          %90 = arith.index_castui %89 : i64 to index
          %91 = arith.extui %26 : i32 to i64
          %92 = arith.shli %91, %c32_i64 : i64
          %93 = arith.extui %25 : i32 to i64
          %94 = arith.ori %93, %92 : i64
          %95 = arith.index_castui %94 : i64 to index
          %96 = arith.extui %28 : i32 to i64
          %97 = arith.shli %96, %c32_i64 : i64
          %98 = arith.extui %27 : i32 to i64
          %99 = arith.ori %98, %97 : i64
          %100 = arith.index_castui %99 : i64 to index
          %101 = arith.extui %30 : i32 to i64
          %102 = arith.shli %101, %c32_i64 : i64
          %103 = arith.extui %29 : i32 to i64
          %104 = arith.ori %103, %102 : i64
          %105 = arith.index_castui %104 : i64 to index
          %106:9 = util.assume.int 
              %65<umin = 0, umax = 9007199254740991>, 
              %70<umin = 0, umax = 9007199254740991>, 
              %75<umin = 0, umax = 9007199254740991>, 
              %80<umin = 0, umax = 9007199254740991>, 
              %85<umin = 0, umax = 9007199254740991>, 
              %90<umin = 0, umax = 9007199254740991>, 
              %95<umin = 0, umax = 9007199254740991>, 
              %100<umin = 0, umax = 9007199254740991>, 
              %105<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index, index
          %107 = iree_tensor_ext.dispatch.workload.ordinal %40, 0 : index
          %108 = iree_tensor_ext.dispatch.workload.ordinal %106#0, 5 : index
          %109 = iree_tensor_ext.dispatch.workload.ordinal %106#1, 6 : index
          %110 = iree_tensor_ext.dispatch.workload.ordinal %106#2, 7 : index
          %111 = iree_tensor_ext.dispatch.workload.ordinal %106#3, 8 : index
          %112 = iree_tensor_ext.dispatch.workload.ordinal %106#4, 9 : index
          %113 = iree_tensor_ext.dispatch.workload.ordinal %106#5, 10 : index
          %114 = iree_tensor_ext.dispatch.workload.ordinal %106#6, 11 : index
          %115 = iree_tensor_ext.dispatch.workload.ordinal %106#7, 12 : index
          %116 = iree_tensor_ext.dispatch.workload.ordinal %106#8, 13 : index
          %117 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%108, %109, %110}
          %118 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf16>>{%111, %112, %113}
          %119 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf16>>{%114, %115, %116}
          %120 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%35) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%107}
          %121 = iree_tensor_ext.dispatch.workload.ordinal %45, 1 : index
          %122 = iree_tensor_ext.dispatch.workload.ordinal %50, 2 : index
          %123 = iree_tensor_ext.dispatch.workload.ordinal %55, 3 : index
          %124 = iree_tensor_ext.dispatch.workload.ordinal %60, 4 : index
          %125 = iree_tensor_ext.dispatch.tensor.load %117, offsets = [0, 0, 0], sizes = [%108, %109, %110], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%108, %109, %110} -> tensor<?x?x?xi32>
          %126 = iree_tensor_ext.dispatch.tensor.load %118, offsets = [0, 0, 0], sizes = [%111, %112, %113], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf16>>{%111, %112, %113} -> tensor<?x?x?xf16>
          %127 = iree_tensor_ext.dispatch.tensor.load %119, offsets = [0, 0, 0], sizes = [%114, %115, %116], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf16>>{%114, %115, %116} -> tensor<?x?x?xf16>
          %128 = tensor.empty(%107) : tensor<?xf32>
          %129 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%128 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %130 = linalg.index 0 : index
            %131 = arith.remsi %130, %121 : index
            %132 = arith.divsi %130, %121 : index
            %133 = arith.remsi %132, %109 : index
            %134 = arith.addi %122, %131 : index
            %135 = arith.divui %134, %c32 : index
            %136 = arith.remui %134, %c32 : index
            %137 = arith.muli %135, %123 : index
            %138 = arith.muli %136, %123 : index
            %139 = arith.divui %138, %c32 : index
            %140 = arith.addi %137, %139 : index
            %141 = arith.remui %138, %c32 : index
            %142 = arith.addi %141, %123 : index
            %143 = arith.cmpi ugt, %142, %c32 : index
            %144 = arith.addi %140, %c1 : index
            %145 = arith.select %143, %144, %140 : index
            %extracted = tensor.extract %125[%c0, %133, %140] : tensor<?x?x?xi32>
            %extracted_0 = tensor.extract %125[%c0, %133, %145] : tensor<?x?x?xi32>
            %146 = arith.index_castui %141 : index to i32
            %147 = arith.shrui %extracted, %146 : i32
            %148 = arith.subi %c32, %141 : index
            %149 = arith.index_castui %148 : index to i32
            %150 = arith.andi %149, %c31_i32 : i32
            %151 = arith.shli %extracted_0, %150 : i32
            %152 = arith.select %143, %151, %c0_i32 : i32
            %153 = arith.ori %147, %152 : i32
            %154 = arith.andi %153, %10 : i32
            %155 = arith.uitofp %154 : i32 to f32
            %extracted_1 = tensor.extract %126[%c0, %133, %124] : tensor<?x?x?xf16>
            %extracted_2 = tensor.extract %127[%c0, %133, %124] : tensor<?x?x?xf16>
            %156 = arith.extf %extracted_1 : f16 to f32
            %157 = arith.extf %extracted_2 : f16 to f32
            %158 = arith.mulf %155, %156 : f32
            %159 = arith.addf %158, %157 : f32
            linalg.yield %159 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %129, %120, offsets = [0], sizes = [%107], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%107}
          return
        }
        iree_codegen.dispatch_config @affine_linear_f16_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_linear_f16_dispatch_4 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_f16_dispatch_4_elementwise_D_f32xf16 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg1)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_f16_dispatch_4_elementwise_D_f32xf16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = arith.extui %1 : i32 to i64
          %8 = arith.shli %7, %c32_i64 : i64
          %9 = arith.extui %0 : i32 to i64
          %10 = arith.ori %9, %8 : i64
          %11 = arith.index_castui %10 : i64 to index
          %12 = iree_tensor_ext.dispatch.workload.ordinal %6, 0 : index
          %13 = iree_tensor_ext.dispatch.workload.ordinal %11, 0 : index
          %14 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%13}
          %15 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%12}
          %16 = iree_tensor_ext.dispatch.tensor.load %14, offsets = [0], sizes = [%13], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%13} -> tensor<?xf32>
          %17 = tensor.empty(%12) : tensor<?xf16>
          %18 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%16 : tensor<?xf32>) outs(%17 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f32, %out: f16):
            %19 = arith.truncf %in : f32 to f16
            linalg.yield %19 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %18, %15, offsets = [0], sizes = [%12], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%12}
          return
        }
        iree_codegen.dispatch_config @affine_linear_f16_dispatch_4_elementwise_D_f32xf16 {
        ^bb0(%arg0: !hal.device, %arg1: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg1)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_linear_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: !hal.fence, %arg7: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_linear_f16(%input0: tensor<?x?xf16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xf16>, %input3: tensor<?x?x?xf16>, %input4: i32, %input5: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1_i32 = arith.constant 1 : i32
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg6 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_f16) encoding(%dense_row_major)
    %16 = arith.muli %13, %c2 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf16>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    %21 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[1] : index
    %22 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20, %21, %22]) type(%element_type_f16) encoding(%dense_row_major)
    %23 = arith.muli %20, %c2 : index
    %24 = arith.muli %23, %21 : index
    %25 = arith.muli %24, %22 : index
    %26 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?x?x?xf16>{%20, %21, %22} in !stream.resource<external>{%25}
    %27 = arith.index_cast %arg4 : i32 to index
    %28 = arith.divui %1, %27 : index
    %29 = arith.muli %0, %c4 : index
    %30 = arith.muli %29, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%30} => !stream.timepoint
    %31 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg8: !stream.resource<transient>{%30}) {
      stream.cmd.fill %c0_i8, %arg8[%c0 for %30] : i8 -> !stream.resource<transient>{%30}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %30, %31 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%32: index, %33: !stream.resource<transient>, %34: index, %35: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %36 = arith.cmpi slt, %32, %28 : index
    cf.cond_br %36, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %37 = arith.muli %32, %27 : index
    %38 = arith.muli %0, %27 overflow<nsw> : index
    %39 = arith.muli %38, %c4 : index
    %40 = arith.muli %0, %7 overflow<nsw> : index
    %41 = arith.muli %40, %27 overflow<nsw> : index
    %42 = arith.shli %c1_i32, %arg5 : i32
    %43 = arith.index_cast %arg5 : i32 to index
    %44 = arith.subi %42, %c1_i32 : i32
    %45 = arith.muli %41, %c4 : index
    %46 = util.align %39, %c64 : index
    %47 = util.align %45, %c64 : index
    %48 = arith.addi %46, %47 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%48} => !stream.timepoint
    %49 = arith.index_castui %38 : index to i64
    %50 = arith.index_castui %38 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %27 : index to i64
    %54 = arith.index_castui %27 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %37 : index to i64
    %58 = arith.index_castui %37 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = arith.index_castui %0 : index to i64
    %62 = arith.index_castui %0 : index to i32
    %63 = arith.shrui %61, %c32_i64 : i64
    %64 = arith.trunci %63 : i64 to i32
    %65 = arith.index_castui %1 : index to i64
    %66 = arith.index_castui %1 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %46 : index to i64
    %70 = arith.index_castui %46 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = arith.index_castui %41 : index to i64
    %74 = arith.index_castui %41 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = arith.index_castui %43 : index to i64
    %78 = arith.index_castui %43 : index to i32
    %79 = arith.shrui %77, %c32_i64 : i64
    %80 = arith.trunci %79 : i64 to i32
    %81 = arith.index_castui %32 : index to i64
    %82 = arith.index_castui %32 : index to i32
    %83 = arith.shrui %81, %c32_i64 : i64
    %84 = arith.trunci %83 : i64 to i32
    %85 = arith.index_castui %6 : index to i64
    %86 = arith.index_castui %6 : index to i32
    %87 = arith.shrui %85, %c32_i64 : i64
    %88 = arith.trunci %87 : i64 to i32
    %89 = arith.index_castui %7 : index to i64
    %90 = arith.index_castui %7 : index to i32
    %91 = arith.shrui %89, %c32_i64 : i64
    %92 = arith.trunci %91 : i64 to i32
    %93 = arith.index_castui %8 : index to i64
    %94 = arith.index_castui %8 : index to i32
    %95 = arith.shrui %93, %c32_i64 : i64
    %96 = arith.trunci %95 : i64 to i32
    %97 = arith.index_castui %13 : index to i64
    %98 = arith.index_castui %13 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %14 : index to i64
    %102 = arith.index_castui %14 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %15 : index to i64
    %106 = arith.index_castui %15 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %20 : index to i64
    %110 = arith.index_castui %20 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %21 : index to i64
    %114 = arith.index_castui %21 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %22 : index to i64
    %118 = arith.index_castui %22 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg8: !stream.resource<external>{%3}, %12 as %arg9: !stream.resource<external>{%11}, %19 as %arg10: !stream.resource<external>{%18}, %26 as %arg11: !stream.resource<external>{%25}, %result_0 as %arg12: !stream.resource<transient>{%48}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_0::@vulkan_spirv_fb::@affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32[%38, %27, %37, %0, %1](%50, %52, %54, %56, %58, %60, %62, %64, %66, %68 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg12[%c0 for %48] : !stream.resource<transient>{%48}
      }
      stream.cmd.dispatch @affine_linear_f16_dispatch_1::@vulkan_spirv_fb::@affine_linear_f16_dispatch_1_elementwise_broadcast_D_f32[%41, %27, %37, %43, %32, %6, %7, %8, %13, %14, %15, %20, %21, %22](%70, %72, %74, %76, %54, %56, %58, %60, %78, %80, %44, %82, %84, %86, %88, %90, %92, %94, %96, %98, %100, %102, %104, %106, %108, %110, %112, %114, %116, %118, %120 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg10[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg11[%c0 for %25] : !stream.resource<external>{%25},
        wo %arg12[%c0 for %48] : !stream.resource<transient>{%48}
      }
    } => !stream.timepoint
    %122 = arith.muli %30, %27 : index
    %123 = stream.timepoint.await %121 => %result_0 : !stream.resource<transient>{%48}
    %124 = stream.resource.subview %123[%c0] : !stream.resource<transient>{%48} -> !stream.resource<transient>{%39}
    %125 = stream.resource.subview %123[%46] : !stream.resource<transient>{%48} -> !stream.resource<transient>{%45}
    %126 = util.optimization_barrier %124 : !stream.resource<transient>
    %127 = util.optimization_barrier %125 : !stream.resource<transient>
    %128 = arith.muli %29, %27 : index
    %129 = arith.muli %40, %c4 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%35) => !stream.resource<transient>{%129} => !stream.timepoint
    %130 = util.align %30, %c64 : index
    %131 = arith.addi %130, %130 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%35) => !stream.resource<transient>{%131} => !stream.timepoint
    %132 = stream.timepoint.join max(%result_timepoint_3, %result_timepoint_5) => !stream.timepoint
    %133 = arith.index_castui %130 : index to i64
    %134 = arith.index_castui %130 : index to i32
    %135 = arith.shrui %133, %c32_i64 : i64
    %136 = arith.trunci %135 : i64 to i32
    %137 = arith.index_castui %40 : index to i64
    %138 = arith.index_castui %40 : index to i32
    %139 = arith.shrui %137, %c32_i64 : i64
    %140 = arith.trunci %139 : i64 to i32
    %141 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%132) => with(%126 as %arg8: !stream.resource<transient>{%128}, %127 as %arg9: !stream.resource<transient>{%122}, %33 as %arg10: !stream.resource<transient>{%34}, %result_2 as %arg11: !stream.resource<transient>{%129}, %result_4 as %arg12: !stream.resource<transient>{%131}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %27, %7](%62, %64, %54, %56, %90, %92 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %128] : !stream.resource<transient>{%128},
        ro %arg9[%c0 for %122] : !stream.resource<transient>{%122},
        wo %arg12[%c0 for %131] : !stream.resource<transient>{%131}
      }
      stream.cmd.copy %arg10[%c0], %arg12[%130], %30 : !stream.resource<transient>{%30} -> !stream.resource<transient>{%131}
      stream.cmd.dispatch @affine_linear_f32_dispatch_3::@vulkan_spirv_fb::@affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32[%40, %7, %0](%134, %136, %138, %140, %90, %92, %62, %64 : i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg12[%c0 for %131] : !stream.resource<transient>{%131},
        wo %arg11[%c0 for %129] : !stream.resource<transient>{%129}
      }
    } => !stream.timepoint
    %142 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%141) => %result_4 : !stream.resource<transient>{%131} => !stream.timepoint
    %143 = arith.addi %32, %c1 : index
    cf.br ^bb1(%143, %result_2, %129, %142 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %144 = arith.muli %0, %7 overflow<nsw> : index
    %145 = arith.muli %144, %c2 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%35) => !stream.resource<external>{%145} => !stream.timepoint
    %146 = arith.index_castui %144 : index to i64
    %147 = arith.index_castui %144 : index to i32
    %148 = arith.shrui %146, %c32_i64 : i64
    %149 = arith.trunci %148 : i64 to i32
    %150 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_7) => with(%33 as %arg8: !stream.resource<transient>{%34}, %result_6 as %arg9: !stream.resource<external>{%145}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_4::@vulkan_spirv_fb::@affine_linear_f16_dispatch_4_elementwise_D_f32xf16[%144](%147, %149 : i32, i32) {
        ro %arg8[%c0 for %34] : !stream.resource<transient>{%34},
        wo %arg9[%c0 for %145] : !stream.resource<external>{%145}
      }
    } => !stream.timepoint
    %151 = stream.resource.dealloca origin await(%150) => %33 : !stream.resource<transient>{%34} => !stream.timepoint
    %152 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %151 => (%arg7 : !hal.fence)
    %153 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_6 : tensor<?x?xf16>{%0, %7} in !stream.resource<external>{%152} -> !hal.buffer_view
    util.return %153 : !hal.buffer_view
  }
  hal.executable private @affine_grouped_f16_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_grouped_f16_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index, %arg15: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14, %arg15)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_grouped_f16_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(20) : i32
          %21 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(21) : i32
          %22 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(22) : i32
          %23 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(23) : i32
          %24 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(24) : i32
          %25 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(25) : i32
          %26 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(26) : i32
          %27 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(27) : i32
          %28 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(28) : i32
          %29 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(29) : i32
          %30 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(30) : i32
          %31 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(31) : i32
          %32 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(32) : i32
          %33 = arith.extui %1 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %0 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 {stream.alignment = 64 : index} : i64 to index
          %38 = arith.extui %3 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %2 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %5 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %4 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %7 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %6 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %9 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %8 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %12 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %11 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63 = arith.extui %14 : i32 to i64
          %64 = arith.shli %63, %c32_i64 : i64
          %65 = arith.extui %13 : i32 to i64
          %66 = arith.ori %65, %64 : i64
          %67 = arith.index_castui %66 : i64 to index
          %68 = arith.extui %16 : i32 to i64
          %69 = arith.shli %68, %c32_i64 : i64
          %70 = arith.extui %15 : i32 to i64
          %71 = arith.ori %70, %69 : i64
          %72 = arith.index_castui %71 : i64 to index
          %73 = arith.extui %18 : i32 to i64
          %74 = arith.shli %73, %c32_i64 : i64
          %75 = arith.extui %17 : i32 to i64
          %76 = arith.ori %75, %74 : i64
          %77 = arith.index_castui %76 : i64 to index
          %78 = arith.extui %20 : i32 to i64
          %79 = arith.shli %78, %c32_i64 : i64
          %80 = arith.extui %19 : i32 to i64
          %81 = arith.ori %80, %79 : i64
          %82 = arith.index_castui %81 : i64 to index
          %83 = arith.extui %22 : i32 to i64
          %84 = arith.shli %83, %c32_i64 : i64
          %85 = arith.extui %21 : i32 to i64
          %86 = arith.ori %85, %84 : i64
          %87 = arith.index_castui %86 : i64 to index
          %88 = arith.extui %24 : i32 to i64
          %89 = arith.shli %88, %c32_i64 : i64
          %90 = arith.extui %23 : i32 to i64
          %91 = arith.ori %90, %89 : i64
          %92 = arith.index_castui %91 : i64 to index
          %93 = arith.extui %26 : i32 to i64
          %94 = arith.shli %93, %c32_i64 : i64
          %95 = arith.extui %25 : i32 to i64
          %96 = arith.ori %95, %94 : i64
          %97 = arith.index_castui %96 : i64 to index
          %98 = arith.extui %28 : i32 to i64
          %99 = arith.shli %98, %c32_i64 : i64
          %100 = arith.extui %27 : i32 to i64
          %101 = arith.ori %100, %99 : i64
          %102 = arith.index_castui %101 : i64 to index
          %103 = arith.extui %30 : i32 to i64
          %104 = arith.shli %103, %c32_i64 : i64
          %105 = arith.extui %29 : i32 to i64
          %106 = arith.ori %105, %104 : i64
          %107 = arith.index_castui %106 : i64 to index
          %108 = arith.extui %32 : i32 to i64
          %109 = arith.shli %108, %c32_i64 : i64
          %110 = arith.extui %31 : i32 to i64
          %111 = arith.ori %110, %109 : i64
          %112 = arith.index_castui %111 : i64 to index
          %113:10 = util.assume.int 
              %67<umin = 0, umax = 9007199254740991>, 
              %72<umin = 0, umax = 9007199254740991>, 
              %77<umin = 0, umax = 9007199254740991>, 
              %82<umin = 0, umax = 9007199254740991>, 
              %87<umin = 0, umax = 9007199254740991>, 
              %92<umin = 0, umax = 9007199254740991>, 
              %97<umin = 0, umax = 9007199254740991>, 
              %102<umin = 0, umax = 9007199254740991>, 
              %107<umin = 0, umax = 9007199254740991>, 
              %112<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index, index, index
          %114 = iree_tensor_ext.dispatch.workload.ordinal %42, 0 : index
          %115 = iree_tensor_ext.dispatch.workload.ordinal %113#0, 5 : index
          %116 = iree_tensor_ext.dispatch.workload.ordinal %113#1, 6 : index
          %117 = iree_tensor_ext.dispatch.workload.ordinal %113#2, 7 : index
          %118 = iree_tensor_ext.dispatch.workload.ordinal %113#3, 8 : index
          %119 = iree_tensor_ext.dispatch.workload.ordinal %113#4, 9 : index
          %120 = iree_tensor_ext.dispatch.workload.ordinal %113#5, 10 : index
          %121 = iree_tensor_ext.dispatch.workload.ordinal %113#6, 11 : index
          %122 = iree_tensor_ext.dispatch.workload.ordinal %113#7, 12 : index
          %123 = iree_tensor_ext.dispatch.workload.ordinal %113#8, 13 : index
          %124 = iree_tensor_ext.dispatch.workload.ordinal %113#9, 14 : index
          %125 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%115}
          %126 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%116, %117, %118}
          %127 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf16>>{%119, %120, %121}
          %128 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf16>>{%122, %123, %124}
          %129 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(4) alignment(64) offset(%37) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%114}
          %130 = iree_tensor_ext.dispatch.workload.ordinal %47, 1 : index
          %131 = iree_tensor_ext.dispatch.workload.ordinal %52, 2 : index
          %132 = iree_tensor_ext.dispatch.workload.ordinal %57, 3 : index
          %133 = iree_tensor_ext.dispatch.workload.ordinal %62, 4 : index
          %134 = iree_tensor_ext.dispatch.tensor.load %125, offsets = [0], sizes = [%115], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%115} -> tensor<?xi32>
          %135 = iree_tensor_ext.dispatch.tensor.load %126, offsets = [0, 0, 0], sizes = [%116, %117, %118], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%116, %117, %118} -> tensor<?x?x?xi32>
          %136 = iree_tensor_ext.dispatch.tensor.load %127, offsets = [0, 0, 0], sizes = [%119, %120, %121], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf16>>{%119, %120, %121} -> tensor<?x?x?xf16>
          %137 = iree_tensor_ext.dispatch.tensor.load %128, offsets = [0, 0, 0], sizes = [%122, %123, %124], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xf16>>{%122, %123, %124} -> tensor<?x?x?xf16>
          %138 = tensor.empty(%114) : tensor<?xf32>
          %139 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%138 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %140 = linalg.index 0 : index
            %141 = arith.remsi %140, %130 : index
            %142 = arith.divsi %140, %130 : index
            %143 = arith.remsi %142, %117 : index
            %144 = arith.divsi %142, %117 : index
            %extracted = tensor.extract %134[%144] : tensor<?xi32>
            %145 = arith.index_cast %extracted : i32 to index
            %146 = arith.addi %131, %141 : index
            %147 = arith.divui %146, %c32 : index
            %148 = arith.remui %146, %c32 : index
            %149 = arith.muli %147, %132 : index
            %150 = arith.muli %148, %132 : index
            %151 = arith.divui %150, %c32 : index
            %152 = arith.addi %149, %151 : index
            %153 = arith.remui %150, %c32 : index
            %154 = arith.addi %153, %132 : index
            %155 = arith.cmpi ugt, %154, %c32 : index
            %156 = arith.addi %152, %c1 : index
            %157 = arith.select %155, %156, %152 : index
            %extracted_0 = tensor.extract %135[%145, %143, %152] : tensor<?x?x?xi32>
            %extracted_1 = tensor.extract %135[%145, %143, %157] : tensor<?x?x?xi32>
            %158 = arith.index_castui %153 : index to i32
            %159 = arith.shrui %extracted_0, %158 : i32
            %160 = arith.subi %c32, %153 : index
            %161 = arith.index_castui %160 : index to i32
            %162 = arith.andi %161, %c31_i32 : i32
            %163 = arith.shli %extracted_1, %162 : i32
            %164 = arith.select %155, %163, %c0_i32 : i32
            %165 = arith.ori %159, %164 : i32
            %166 = arith.andi %165, %10 : i32
            %167 = arith.uitofp %166 : i32 to f32
            %extracted_2 = tensor.extract %136[%145, %143, %133] : tensor<?x?x?xf16>
            %extracted_3 = tensor.extract %137[%145, %143, %133] : tensor<?x?x?xf16>
            %168 = arith.extf %extracted_2 : f16 to f32
            %169 = arith.extf %extracted_3 : f16 to f32
            %170 = arith.mulf %167, %168 : f32
            %171 = arith.addf %170, %169 : f32
            linalg.yield %171 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %139, %129, offsets = [0], sizes = [%114], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%114}
          return
        }
        iree_codegen.dispatch_config @affine_grouped_f16_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index, %arg15: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14, %arg15)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_grouped_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: !hal.buffer_view, %arg5: i32, %arg6: i32, %arg7: !hal.fence, %arg8: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_grouped_f16(%input0: tensor<?x?xf16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xf16>, %input3: tensor<?x?x?xf16>, %input4: tensor<?xi32>, %input5: i32, %input6: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1_i32 = arith.constant 1 : i32
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_f16) encoding(%dense_row_major)
    %16 = arith.muli %13, %c2 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xf16>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    %21 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[1] : index
    %22 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20, %21, %22]) type(%element_type_f16) encoding(%dense_row_major)
    %23 = arith.muli %20, %c2 : index
    %24 = arith.muli %23, %21 : index
    %25 = arith.muli %24, %22 : index
    %26 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?x?x?xf16>{%20, %21, %22} in !stream.resource<external>{%25}
    %27 = hal.buffer_view.dim<%arg4 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg4 : !hal.buffer_view> message("input4") shape([%27]) type(%element_type_i32) encoding(%dense_row_major)
    %28 = arith.muli %27, %c4 : index
    %29 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg4 : !hal.buffer_view -> tensor<?xi32>{%27} in !stream.resource<external>{%28}
    %30 = arith.index_cast %arg5 : i32 to index
    %31 = arith.divui %1, %30 : index
    %32 = arith.muli %0, %c4 : index
    %33 = arith.muli %32, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%33} => !stream.timepoint
    %34 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg9: !stream.resource<transient>{%33}) {
      stream.cmd.fill %c0_i8, %arg9[%c0 for %33] : i8 -> !stream.resource<transient>{%33}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %33, %34 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%35: index, %36: !stream.resource<transient>, %37: index, %38: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %39 = arith.cmpi slt, %35, %31 : index
    cf.cond_br %39, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %40 = arith.muli %35, %30 : index
    %41 = arith.muli %0, %30 overflow<nsw> : index
    %42 = arith.muli %41, %c4 : index
    %43 = arith.muli %0, %7 overflow<nsw> : index
    %44 = arith.muli %43, %30 overflow<nsw> : index
    %45 = arith.shli %c1_i32, %arg6 : i32
    %46 = arith.index_cast %arg6 : i32 to index
    %47 = arith.subi %45, %c1_i32 : i32
    %48 = arith.muli %44, %c4 : index
    %49 = util.align %42, %c64 : index
    %50 = util.align %48, %c64 : index
    %51 = arith.addi %49, %50 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%51} => !stream.timepoint
    %52 = arith.index_castui %41 : index to i64
    %53 = arith.index_castui %41 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = arith.index_castui %30 : index to i64
    %57 = arith.index_castui %30 : index to i32
    %58 = arith.shrui %56, %c32_i64 : i64
    %59 = arith.trunci %58 : i64 to i32
    %60 = arith.index_castui %40 : index to i64
    %61 = arith.index_castui %40 : index to i32
    %62 = arith.shrui %60, %c32_i64 : i64
    %63 = arith.trunci %62 : i64 to i32
    %64 = arith.index_castui %0 : index to i64
    %65 = arith.index_castui %0 : index to i32
    %66 = arith.shrui %64, %c32_i64 : i64
    %67 = arith.trunci %66 : i64 to i32
    %68 = arith.index_castui %1 : index to i64
    %69 = arith.index_castui %1 : index to i32
    %70 = arith.shrui %68, %c32_i64 : i64
    %71 = arith.trunci %70 : i64 to i32
    %72 = arith.index_castui %49 : index to i64
    %73 = arith.index_castui %49 : index to i32
    %74 = arith.shrui %72, %c32_i64 : i64
    %75 = arith.trunci %74 : i64 to i32
    %76 = arith.index_castui %44 : index to i64
    %77 = arith.index_castui %44 : index to i32
    %78 = arith.shrui %76, %c32_i64 : i64
    %79 = arith.trunci %78 : i64 to i32
    %80 = arith.index_castui %46 : index to i64
    %81 = arith.index_castui %46 : index to i32
    %82 = arith.shrui %80, %c32_i64 : i64
    %83 = arith.trunci %82 : i64 to i32
    %84 = arith.index_castui %35 : index to i64
    %85 = arith.index_castui %35 : index to i32
    %86 = arith.shrui %84, %c32_i64 : i64
    %87 = arith.trunci %86 : i64 to i32
    %88 = arith.index_castui %27 : index to i64
    %89 = arith.index_castui %27 : index to i32
    %90 = arith.shrui %88, %c32_i64 : i64
    %91 = arith.trunci %90 : i64 to i32
    %92 = arith.index_castui %6 : index to i64
    %93 = arith.index_castui %6 : index to i32
    %94 = arith.shrui %92, %c32_i64 : i64
    %95 = arith.trunci %94 : i64 to i32
    %96 = arith.index_castui %7 : index to i64
    %97 = arith.index_castui %7 : index to i32
    %98 = arith.shrui %96, %c32_i64 : i64
    %99 = arith.trunci %98 : i64 to i32
    %100 = arith.index_castui %8 : index to i64
    %101 = arith.index_castui %8 : index to i32
    %102 = arith.shrui %100, %c32_i64 : i64
    %103 = arith.trunci %102 : i64 to i32
    %104 = arith.index_castui %13 : index to i64
    %105 = arith.index_castui %13 : index to i32
    %106 = arith.shrui %104, %c32_i64 : i64
    %107 = arith.trunci %106 : i64 to i32
    %108 = arith.index_castui %14 : index to i64
    %109 = arith.index_castui %14 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %15 : index to i64
    %113 = arith.index_castui %15 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %20 : index to i64
    %117 = arith.index_castui %20 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = arith.index_castui %21 : index to i64
    %121 = arith.index_castui %21 : index to i32
    %122 = arith.shrui %120, %c32_i64 : i64
    %123 = arith.trunci %122 : i64 to i32
    %124 = arith.index_castui %22 : index to i64
    %125 = arith.index_castui %22 : index to i32
    %126 = arith.shrui %124, %c32_i64 : i64
    %127 = arith.trunci %126 : i64 to i32
    %128 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg9: !stream.resource<external>{%3}, %29 as %arg10: !stream.resource<external>{%28}, %12 as %arg11: !stream.resource<external>{%11}, %19 as %arg12: !stream.resource<external>{%18}, %26 as %arg13: !stream.resource<external>{%25}, %result_0 as %arg14: !stream.resource<transient>{%51}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_0::@vulkan_spirv_fb::@affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32[%41, %30, %40, %0, %1](%53, %55, %57, %59, %61, %63, %65, %67, %69, %71 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg14[%c0 for %51] : !stream.resource<transient>{%51}
      }
      stream.cmd.dispatch @affine_grouped_f16_dispatch_1::@vulkan_spirv_fb::@affine_grouped_f16_dispatch_1_elementwise_broadcast_D_f32[%44, %30, %40, %46, %35, %27, %6, %7, %8, %13, %14, %15, %20, %21, %22](%73, %75, %77, %79, %57, %59, %61, %63, %81, %83, %47, %85, %87, %89, %91, %93, %95, %97, %99, %101, %103, %105, %107, %109, %111, %113, %115, %117, %119, %121, %123, %125, %127 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg10[%c0 for %28] : !stream.resource<external>{%28},
        ro %arg11[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg12[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg13[%c0 for %25] : !stream.resource<external>{%25},
        wo %arg14[%c0 for %51] : !stream.resource<transient>{%51}
      }
    } => !stream.timepoint
    %129 = arith.muli %33, %30 : index
    %130 = stream.timepoint.await %128 => %result_0 : !stream.resource<transient>{%51}
    %131 = stream.resource.subview %130[%c0] : !stream.resource<transient>{%51} -> !stream.resource<transient>{%42}
    %132 = stream.resource.subview %130[%49] : !stream.resource<transient>{%51} -> !stream.resource<transient>{%48}
    %133 = util.optimization_barrier %131 : !stream.resource<transient>
    %134 = util.optimization_barrier %132 : !stream.resource<transient>
    %135 = arith.muli %32, %30 : index
    %136 = arith.muli %43, %c4 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%38) => !stream.resource<transient>{%136} => !stream.timepoint
    %137 = util.align %33, %c64 : index
    %138 = arith.addi %137, %137 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%38) => !stream.resource<transient>{%138} => !stream.timepoint
    %139 = stream.timepoint.join max(%result_timepoint_3, %result_timepoint_5) => !stream.timepoint
    %140 = arith.index_castui %137 : index to i64
    %141 = arith.index_castui %137 : index to i32
    %142 = arith.shrui %140, %c32_i64 : i64
    %143 = arith.trunci %142 : i64 to i32
    %144 = arith.index_castui %43 : index to i64
    %145 = arith.index_castui %43 : index to i32
    %146 = arith.shrui %144, %c32_i64 : i64
    %147 = arith.trunci %146 : i64 to i32
    %148 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%139) => with(%133 as %arg9: !stream.resource<transient>{%135}, %134 as %arg10: !stream.resource<transient>{%129}, %36 as %arg11: !stream.resource<transient>{%37}, %result_2 as %arg12: !stream.resource<transient>{%136}, %result_4 as %arg13: !stream.resource<transient>{%138}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %30, %7](%65, %67, %57, %59, %97, %99 : i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %135] : !stream.resource<transient>{%135},
        ro %arg10[%c0 for %129] : !stream.resource<transient>{%129},
        wo %arg13[%c0 for %138] : !stream.resource<transient>{%138}
      }
      stream.cmd.copy %arg11[%c0], %arg13[%137], %33 : !stream.resource<transient>{%33} -> !stream.resource<transient>{%138}
      stream.cmd.dispatch @affine_linear_f32_dispatch_3::@vulkan_spirv_fb::@affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32[%43, %7, %0](%141, %143, %145, %147, %97, %99, %65, %67 : i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg13[%c0 for %138] : !stream.resource<transient>{%138},
        wo %arg12[%c0 for %136] : !stream.resource<transient>{%136}
      }
    } => !stream.timepoint
    %149 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%148) => %result_4 : !stream.resource<transient>{%138} => !stream.timepoint
    %150 = arith.addi %35, %c1 : index
    cf.br ^bb1(%150, %result_2, %136, %149 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %151 = arith.muli %0, %7 overflow<nsw> : index
    %152 = arith.muli %151, %c2 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%38) => !stream.resource<external>{%152} => !stream.timepoint
    %153 = arith.index_castui %151 : index to i64
    %154 = arith.index_castui %151 : index to i32
    %155 = arith.shrui %153, %c32_i64 : i64
    %156 = arith.trunci %155 : i64 to i32
    %157 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_7) => with(%36 as %arg9: !stream.resource<transient>{%37}, %result_6 as %arg10: !stream.resource<external>{%152}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_4::@vulkan_spirv_fb::@affine_linear_f16_dispatch_4_elementwise_D_f32xf16[%151](%154, %156 : i32, i32) {
        ro %arg9[%c0 for %37] : !stream.resource<transient>{%37},
        wo %arg10[%c0 for %152] : !stream.resource<external>{%152}
      }
    } => !stream.timepoint
    %158 = stream.resource.dealloca origin await(%157) => %36 : !stream.resource<transient>{%37} => !stream.timepoint
    %159 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %158 => (%arg8 : !hal.fence)
    %160 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_6 : tensor<?x?xf16>{%0, %7} in !stream.resource<external>{%159} -> !hal.buffer_view
    util.return %160 : !hal.buffer_view
  }
  hal.executable private @affine_linear_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = arith.extui %1 : i32 to i64
          %11 = arith.shli %10, %c32_i64 : i64
          %12 = arith.extui %0 : i32 to i64
          %13 = arith.ori %12, %11 : i64
          %14 = arith.index_castui %13 : i64 to index
          %15 = arith.extui %3 : i32 to i64
          %16 = arith.shli %15, %c32_i64 : i64
          %17 = arith.extui %2 : i32 to i64
          %18 = arith.ori %17, %16 : i64
          %19 = arith.index_castui %18 : i64 to index
          %20 = arith.extui %5 : i32 to i64
          %21 = arith.shli %20, %c32_i64 : i64
          %22 = arith.extui %4 : i32 to i64
          %23 = arith.ori %22, %21 : i64
          %24 = arith.index_castui %23 : i64 to index
          %25 = arith.extui %7 : i32 to i64
          %26 = arith.shli %25, %c32_i64 : i64
          %27 = arith.extui %6 : i32 to i64
          %28 = arith.ori %27, %26 : i64
          %29 = arith.index_castui %28 : i64 to index
          %30 = arith.extui %9 : i32 to i64
          %31 = arith.shli %30, %c32_i64 : i64
          %32 = arith.extui %8 : i32 to i64
          %33 = arith.ori %32, %31 : i64
          %34 = arith.index_castui %33 : i64 to index
          %35:2 = util.assume.int 
              %29<umin = 0, umax = 9007199254740991>, 
              %34<umin = 0, umax = 9007199254740991>
            : index, index
          %36 = iree_tensor_ext.dispatch.workload.ordinal %14, 0 : index
          %37 = iree_tensor_ext.dispatch.workload.ordinal %35#0, 3 : index
          %38 = iree_tensor_ext.dispatch.workload.ordinal %35#1, 4 : index
          %39 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%37, %38}
          %40 = hal.interface.binding.subspan layout(<constants = 10, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          %41 = iree_tensor_ext.dispatch.workload.ordinal %19, 1 : index
          %42 = iree_tensor_ext.dispatch.workload.ordinal %24, 2 : index
          %43 = iree_tensor_ext.dispatch.tensor.load %39, offsets = [0, 0], sizes = [%37, %38], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%37, %38} -> tensor<?x?xi16>
          %44 = tensor.empty(%36) : tensor<?xf32>
          %45 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%44 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %46 = linalg.index 0 : index
            %47 = arith.remsi %46, %41 : index
            %48 = arith.divsi %46, %41 : index
            %49 = arith.addi %42, %47 : index
            %extracted = tensor.extract %43[%48, %49] : tensor<?x?xi16>
            %50 = arith.bitcast %extracted : i16 to bf16
            %51 = arith.extf %50 : bf16 to f32
            linalg.yield %51 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %45, %40, offsets = [0], sizes = [%36], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%36}
          return
        }
        iree_codegen.dispatch_config @affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_linear_bf16_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_bf16_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_bf16_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(20) : i32
          %21 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(21) : i32
          %22 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(22) : i32
          %23 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(23) : i32
          %24 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(24) : i32
          %25 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(25) : i32
          %26 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(26) : i32
          %27 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(27) : i32
          %28 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(28) : i32
          %29 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(29) : i32
          %30 = hal.interface.constant.load layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(30) : i32
          %31 = arith.extui %1 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %0 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 {stream.alignment = 64 : index} : i64 to index
          %36 = arith.extui %3 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %2 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %5 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %4 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %7 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %6 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %9 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %8 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56 = arith.extui %12 : i32 to i64
          %57 = arith.shli %56, %c32_i64 : i64
          %58 = arith.extui %11 : i32 to i64
          %59 = arith.ori %58, %57 : i64
          %60 = arith.index_castui %59 : i64 to index
          %61 = arith.extui %14 : i32 to i64
          %62 = arith.shli %61, %c32_i64 : i64
          %63 = arith.extui %13 : i32 to i64
          %64 = arith.ori %63, %62 : i64
          %65 = arith.index_castui %64 : i64 to index
          %66 = arith.extui %16 : i32 to i64
          %67 = arith.shli %66, %c32_i64 : i64
          %68 = arith.extui %15 : i32 to i64
          %69 = arith.ori %68, %67 : i64
          %70 = arith.index_castui %69 : i64 to index
          %71 = arith.extui %18 : i32 to i64
          %72 = arith.shli %71, %c32_i64 : i64
          %73 = arith.extui %17 : i32 to i64
          %74 = arith.ori %73, %72 : i64
          %75 = arith.index_castui %74 : i64 to index
          %76 = arith.extui %20 : i32 to i64
          %77 = arith.shli %76, %c32_i64 : i64
          %78 = arith.extui %19 : i32 to i64
          %79 = arith.ori %78, %77 : i64
          %80 = arith.index_castui %79 : i64 to index
          %81 = arith.extui %22 : i32 to i64
          %82 = arith.shli %81, %c32_i64 : i64
          %83 = arith.extui %21 : i32 to i64
          %84 = arith.ori %83, %82 : i64
          %85 = arith.index_castui %84 : i64 to index
          %86 = arith.extui %24 : i32 to i64
          %87 = arith.shli %86, %c32_i64 : i64
          %88 = arith.extui %23 : i32 to i64
          %89 = arith.ori %88, %87 : i64
          %90 = arith.index_castui %89 : i64 to index
          %91 = arith.extui %26 : i32 to i64
          %92 = arith.shli %91, %c32_i64 : i64
          %93 = arith.extui %25 : i32 to i64
          %94 = arith.ori %93, %92 : i64
          %95 = arith.index_castui %94 : i64 to index
          %96 = arith.extui %28 : i32 to i64
          %97 = arith.shli %96, %c32_i64 : i64
          %98 = arith.extui %27 : i32 to i64
          %99 = arith.ori %98, %97 : i64
          %100 = arith.index_castui %99 : i64 to index
          %101 = arith.extui %30 : i32 to i64
          %102 = arith.shli %101, %c32_i64 : i64
          %103 = arith.extui %29 : i32 to i64
          %104 = arith.ori %103, %102 : i64
          %105 = arith.index_castui %104 : i64 to index
          %106:9 = util.assume.int 
              %65<umin = 0, umax = 9007199254740991>, 
              %70<umin = 0, umax = 9007199254740991>, 
              %75<umin = 0, umax = 9007199254740991>, 
              %80<umin = 0, umax = 9007199254740991>, 
              %85<umin = 0, umax = 9007199254740991>, 
              %90<umin = 0, umax = 9007199254740991>, 
              %95<umin = 0, umax = 9007199254740991>, 
              %100<umin = 0, umax = 9007199254740991>, 
              %105<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index, index
          %107 = iree_tensor_ext.dispatch.workload.ordinal %40, 0 : index
          %108 = iree_tensor_ext.dispatch.workload.ordinal %106#0, 5 : index
          %109 = iree_tensor_ext.dispatch.workload.ordinal %106#1, 6 : index
          %110 = iree_tensor_ext.dispatch.workload.ordinal %106#2, 7 : index
          %111 = iree_tensor_ext.dispatch.workload.ordinal %106#3, 8 : index
          %112 = iree_tensor_ext.dispatch.workload.ordinal %106#4, 9 : index
          %113 = iree_tensor_ext.dispatch.workload.ordinal %106#5, 10 : index
          %114 = iree_tensor_ext.dispatch.workload.ordinal %106#6, 11 : index
          %115 = iree_tensor_ext.dispatch.workload.ordinal %106#7, 12 : index
          %116 = iree_tensor_ext.dispatch.workload.ordinal %106#8, 13 : index
          %117 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%108, %109, %110}
          %118 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi16>>{%111, %112, %113}
          %119 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi16>>{%114, %115, %116}
          %120 = hal.interface.binding.subspan layout(<constants = 31, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%35) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%107}
          %121 = iree_tensor_ext.dispatch.workload.ordinal %45, 1 : index
          %122 = iree_tensor_ext.dispatch.workload.ordinal %50, 2 : index
          %123 = iree_tensor_ext.dispatch.workload.ordinal %55, 3 : index
          %124 = iree_tensor_ext.dispatch.workload.ordinal %60, 4 : index
          %125 = iree_tensor_ext.dispatch.tensor.load %117, offsets = [0, 0, 0], sizes = [%108, %109, %110], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%108, %109, %110} -> tensor<?x?x?xi32>
          %126 = iree_tensor_ext.dispatch.tensor.load %118, offsets = [0, 0, 0], sizes = [%111, %112, %113], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi16>>{%111, %112, %113} -> tensor<?x?x?xi16>
          %127 = iree_tensor_ext.dispatch.tensor.load %119, offsets = [0, 0, 0], sizes = [%114, %115, %116], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi16>>{%114, %115, %116} -> tensor<?x?x?xi16>
          %128 = tensor.empty(%107) : tensor<?xf32>
          %129 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%128 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %130 = linalg.index 0 : index
            %131 = arith.remsi %130, %121 : index
            %132 = arith.divsi %130, %121 : index
            %133 = arith.remsi %132, %109 : index
            %134 = arith.addi %122, %131 : index
            %135 = arith.divui %134, %c32 : index
            %136 = arith.remui %134, %c32 : index
            %137 = arith.muli %135, %123 : index
            %138 = arith.muli %136, %123 : index
            %139 = arith.divui %138, %c32 : index
            %140 = arith.addi %137, %139 : index
            %141 = arith.remui %138, %c32 : index
            %142 = arith.addi %141, %123 : index
            %143 = arith.cmpi ugt, %142, %c32 : index
            %144 = arith.addi %140, %c1 : index
            %145 = arith.select %143, %144, %140 : index
            %extracted = tensor.extract %125[%c0, %133, %140] : tensor<?x?x?xi32>
            %extracted_0 = tensor.extract %125[%c0, %133, %145] : tensor<?x?x?xi32>
            %146 = arith.index_castui %141 : index to i32
            %147 = arith.shrui %extracted, %146 : i32
            %148 = arith.subi %c32, %141 : index
            %149 = arith.index_castui %148 : index to i32
            %150 = arith.andi %149, %c31_i32 : i32
            %151 = arith.shli %extracted_0, %150 : i32
            %152 = arith.select %143, %151, %c0_i32 : i32
            %153 = arith.ori %147, %152 : i32
            %154 = arith.andi %153, %10 : i32
            %155 = arith.uitofp %154 : i32 to f32
            %extracted_1 = tensor.extract %126[%c0, %133, %124] : tensor<?x?x?xi16>
            %extracted_2 = tensor.extract %127[%c0, %133, %124] : tensor<?x?x?xi16>
            %156 = arith.bitcast %extracted_1 : i16 to bf16
            %157 = arith.extf %156 : bf16 to f32
            %158 = arith.bitcast %extracted_2 : i16 to bf16
            %159 = arith.extf %158 : bf16 to f32
            %160 = arith.mulf %155, %157 : f32
            %161 = arith.addf %160, %159 : f32
            linalg.yield %161 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %129, %120, offsets = [0], sizes = [%107], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%107}
          return
        }
        iree_codegen.dispatch_config @affine_linear_bf16_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_linear_bf16_dispatch_4 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_linear_bf16_dispatch_4_elementwise_D_f32xi16 ordinal(0) layout(#hal.pipeline.layout<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg1)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_linear_bf16_dispatch_4_elementwise_D_f32xi16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = arith.extui %1 : i32 to i64
          %3 = arith.shli %2, %c32_i64 : i64
          %4 = arith.extui %0 : i32 to i64
          %5 = arith.ori %4, %3 : i64
          %6 = arith.index_castui %5 : i64 to index
          %7 = arith.extui %1 : i32 to i64
          %8 = arith.shli %7, %c32_i64 : i64
          %9 = arith.extui %0 : i32 to i64
          %10 = arith.ori %9, %8 : i64
          %11 = arith.index_castui %10 : i64 to index
          %12 = iree_tensor_ext.dispatch.workload.ordinal %6, 0 : index
          %13 = iree_tensor_ext.dispatch.workload.ordinal %11, 0 : index
          %14 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%13}
          %15 = hal.interface.binding.subspan layout(<constants = 2, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%12}
          %16 = iree_tensor_ext.dispatch.tensor.load %14, offsets = [0], sizes = [%13], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%13} -> tensor<?xf32>
          %17 = tensor.empty(%12) : tensor<?xi16>
          %18 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%16 : tensor<?xf32>) outs(%17 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f32, %out: i16):
            %19 = arith.truncf %in : f32 to bf16
            %20 = arith.bitcast %19 : bf16 to i16
            linalg.yield %20 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %18, %15, offsets = [0], sizes = [%12], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%12}
          return
        }
        iree_codegen.dispatch_config @affine_linear_bf16_dispatch_4_elementwise_D_f32xi16 {
        ^bb0(%arg0: !hal.device, %arg1: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg1)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_linear_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: !hal.fence, %arg7: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_linear_bf16(%input0: tensor<?x?xi16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi16>, %input3: tensor<?x?x?xi16>, %input4: i32, %input5: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1_i32 = arith.constant 1 : i32
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg6 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i16) encoding(%dense_row_major)
    %16 = arith.muli %13, %c2 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi16>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    %21 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[1] : index
    %22 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20, %21, %22]) type(%element_type_i16) encoding(%dense_row_major)
    %23 = arith.muli %20, %c2 : index
    %24 = arith.muli %23, %21 : index
    %25 = arith.muli %24, %22 : index
    %26 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?x?x?xi16>{%20, %21, %22} in !stream.resource<external>{%25}
    %27 = arith.index_cast %arg4 : i32 to index
    %28 = arith.divui %1, %27 : index
    %29 = arith.muli %0, %c4 : index
    %30 = arith.muli %29, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%30} => !stream.timepoint
    %31 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg8: !stream.resource<transient>{%30}) {
      stream.cmd.fill %c0_i8, %arg8[%c0 for %30] : i8 -> !stream.resource<transient>{%30}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %30, %31 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%32: index, %33: !stream.resource<transient>, %34: index, %35: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %36 = arith.cmpi slt, %32, %28 : index
    cf.cond_br %36, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %37 = arith.muli %32, %27 : index
    %38 = arith.muli %0, %27 overflow<nsw> : index
    %39 = arith.muli %38, %c4 : index
    %40 = arith.muli %0, %7 overflow<nsw> : index
    %41 = arith.muli %40, %27 overflow<nsw> : index
    %42 = arith.shli %c1_i32, %arg5 : i32
    %43 = arith.index_cast %arg5 : i32 to index
    %44 = arith.subi %42, %c1_i32 : i32
    %45 = arith.muli %41, %c4 : index
    %46 = util.align %39, %c64 : index
    %47 = util.align %45, %c64 : index
    %48 = arith.addi %46, %47 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%48} => !stream.timepoint
    %49 = arith.index_castui %38 : index to i64
    %50 = arith.index_castui %38 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %27 : index to i64
    %54 = arith.index_castui %27 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %37 : index to i64
    %58 = arith.index_castui %37 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = arith.index_castui %0 : index to i64
    %62 = arith.index_castui %0 : index to i32
    %63 = arith.shrui %61, %c32_i64 : i64
    %64 = arith.trunci %63 : i64 to i32
    %65 = arith.index_castui %1 : index to i64
    %66 = arith.index_castui %1 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %46 : index to i64
    %70 = arith.index_castui %46 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = arith.index_castui %41 : index to i64
    %74 = arith.index_castui %41 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = arith.index_castui %43 : index to i64
    %78 = arith.index_castui %43 : index to i32
    %79 = arith.shrui %77, %c32_i64 : i64
    %80 = arith.trunci %79 : i64 to i32
    %81 = arith.index_castui %32 : index to i64
    %82 = arith.index_castui %32 : index to i32
    %83 = arith.shrui %81, %c32_i64 : i64
    %84 = arith.trunci %83 : i64 to i32
    %85 = arith.index_castui %6 : index to i64
    %86 = arith.index_castui %6 : index to i32
    %87 = arith.shrui %85, %c32_i64 : i64
    %88 = arith.trunci %87 : i64 to i32
    %89 = arith.index_castui %7 : index to i64
    %90 = arith.index_castui %7 : index to i32
    %91 = arith.shrui %89, %c32_i64 : i64
    %92 = arith.trunci %91 : i64 to i32
    %93 = arith.index_castui %8 : index to i64
    %94 = arith.index_castui %8 : index to i32
    %95 = arith.shrui %93, %c32_i64 : i64
    %96 = arith.trunci %95 : i64 to i32
    %97 = arith.index_castui %13 : index to i64
    %98 = arith.index_castui %13 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %14 : index to i64
    %102 = arith.index_castui %14 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %15 : index to i64
    %106 = arith.index_castui %15 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %20 : index to i64
    %110 = arith.index_castui %20 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %21 : index to i64
    %114 = arith.index_castui %21 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %22 : index to i64
    %118 = arith.index_castui %22 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg8: !stream.resource<external>{%3}, %12 as %arg9: !stream.resource<external>{%11}, %19 as %arg10: !stream.resource<external>{%18}, %26 as %arg11: !stream.resource<external>{%25}, %result_0 as %arg12: !stream.resource<transient>{%48}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_0::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32[%38, %27, %37, %0, %1](%50, %52, %54, %56, %58, %60, %62, %64, %66, %68 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg12[%c0 for %48] : !stream.resource<transient>{%48}
      }
      stream.cmd.dispatch @affine_linear_bf16_dispatch_1::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_1_elementwise_broadcast_D_f32[%41, %27, %37, %43, %32, %6, %7, %8, %13, %14, %15, %20, %21, %22](%70, %72, %74, %76, %54, %56, %58, %60, %78, %80, %44, %82, %84, %86, %88, %90, %92, %94, %96, %98, %100, %102, %104, %106, %108, %110, %112, %114, %116, %118, %120 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg10[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg11[%c0 for %25] : !stream.resource<external>{%25},
        wo %arg12[%c0 for %48] : !stream.resource<transient>{%48}
      }
    } => !stream.timepoint
    %122 = arith.muli %30, %27 : index
    %123 = stream.timepoint.await %121 => %result_0 : !stream.resource<transient>{%48}
    %124 = stream.resource.subview %123[%c0] : !stream.resource<transient>{%48} -> !stream.resource<transient>{%39}
    %125 = stream.resource.subview %123[%46] : !stream.resource<transient>{%48} -> !stream.resource<transient>{%45}
    %126 = util.optimization_barrier %124 : !stream.resource<transient>
    %127 = util.optimization_barrier %125 : !stream.resource<transient>
    %128 = arith.muli %29, %27 : index
    %129 = arith.muli %40, %c4 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%35) => !stream.resource<transient>{%129} => !stream.timepoint
    %130 = util.align %30, %c64 : index
    %131 = arith.addi %130, %130 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%35) => !stream.resource<transient>{%131} => !stream.timepoint
    %132 = stream.timepoint.join max(%result_timepoint_3, %result_timepoint_5) => !stream.timepoint
    %133 = arith.index_castui %130 : index to i64
    %134 = arith.index_castui %130 : index to i32
    %135 = arith.shrui %133, %c32_i64 : i64
    %136 = arith.trunci %135 : i64 to i32
    %137 = arith.index_castui %40 : index to i64
    %138 = arith.index_castui %40 : index to i32
    %139 = arith.shrui %137, %c32_i64 : i64
    %140 = arith.trunci %139 : i64 to i32
    %141 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%132) => with(%126 as %arg8: !stream.resource<transient>{%128}, %127 as %arg9: !stream.resource<transient>{%122}, %33 as %arg10: !stream.resource<transient>{%34}, %result_2 as %arg11: !stream.resource<transient>{%129}, %result_4 as %arg12: !stream.resource<transient>{%131}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %27, %7](%62, %64, %54, %56, %90, %92 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %128] : !stream.resource<transient>{%128},
        ro %arg9[%c0 for %122] : !stream.resource<transient>{%122},
        wo %arg12[%c0 for %131] : !stream.resource<transient>{%131}
      }
      stream.cmd.copy %arg10[%c0], %arg12[%130], %30 : !stream.resource<transient>{%30} -> !stream.resource<transient>{%131}
      stream.cmd.dispatch @affine_linear_f32_dispatch_3::@vulkan_spirv_fb::@affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32[%40, %7, %0](%134, %136, %138, %140, %90, %92, %62, %64 : i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg12[%c0 for %131] : !stream.resource<transient>{%131},
        wo %arg11[%c0 for %129] : !stream.resource<transient>{%129}
      }
    } => !stream.timepoint
    %142 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%141) => %result_4 : !stream.resource<transient>{%131} => !stream.timepoint
    %143 = arith.addi %32, %c1 : index
    cf.br ^bb1(%143, %result_2, %129, %142 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %144 = arith.muli %0, %7 overflow<nsw> : index
    %145 = arith.muli %144, %c2 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%35) => !stream.resource<external>{%145} => !stream.timepoint
    %146 = arith.index_castui %144 : index to i64
    %147 = arith.index_castui %144 : index to i32
    %148 = arith.shrui %146, %c32_i64 : i64
    %149 = arith.trunci %148 : i64 to i32
    %150 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_7) => with(%33 as %arg8: !stream.resource<transient>{%34}, %result_6 as %arg9: !stream.resource<external>{%145}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_4::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_4_elementwise_D_f32xi16[%144](%147, %149 : i32, i32) {
        ro %arg8[%c0 for %34] : !stream.resource<transient>{%34},
        wo %arg9[%c0 for %145] : !stream.resource<external>{%145}
      }
    } => !stream.timepoint
    %151 = stream.resource.dealloca origin await(%150) => %33 : !stream.resource<transient>{%34} => !stream.timepoint
    %152 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %151 => (%arg7 : !hal.fence)
    %153 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_6 : tensor<?x?xi16>{%0, %7} in !stream.resource<external>{%152} -> !hal.buffer_view
    util.return %153 : !hal.buffer_view
  }
  hal.executable private @affine_grouped_bf16_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_grouped_bf16_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index, %arg15: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14, %arg15)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_grouped_bf16_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(19) : i32
          %20 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(20) : i32
          %21 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(21) : i32
          %22 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(22) : i32
          %23 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(23) : i32
          %24 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(24) : i32
          %25 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(25) : i32
          %26 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(26) : i32
          %27 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(27) : i32
          %28 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(28) : i32
          %29 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(29) : i32
          %30 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(30) : i32
          %31 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(31) : i32
          %32 = hal.interface.constant.load layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(32) : i32
          %33 = arith.extui %1 : i32 to i64
          %34 = arith.shli %33, %c32_i64 : i64
          %35 = arith.extui %0 : i32 to i64
          %36 = arith.ori %35, %34 : i64
          %37 = arith.index_castui %36 {stream.alignment = 64 : index} : i64 to index
          %38 = arith.extui %3 : i32 to i64
          %39 = arith.shli %38, %c32_i64 : i64
          %40 = arith.extui %2 : i32 to i64
          %41 = arith.ori %40, %39 : i64
          %42 = arith.index_castui %41 : i64 to index
          %43 = arith.extui %5 : i32 to i64
          %44 = arith.shli %43, %c32_i64 : i64
          %45 = arith.extui %4 : i32 to i64
          %46 = arith.ori %45, %44 : i64
          %47 = arith.index_castui %46 : i64 to index
          %48 = arith.extui %7 : i32 to i64
          %49 = arith.shli %48, %c32_i64 : i64
          %50 = arith.extui %6 : i32 to i64
          %51 = arith.ori %50, %49 : i64
          %52 = arith.index_castui %51 : i64 to index
          %53 = arith.extui %9 : i32 to i64
          %54 = arith.shli %53, %c32_i64 : i64
          %55 = arith.extui %8 : i32 to i64
          %56 = arith.ori %55, %54 : i64
          %57 = arith.index_castui %56 : i64 to index
          %58 = arith.extui %12 : i32 to i64
          %59 = arith.shli %58, %c32_i64 : i64
          %60 = arith.extui %11 : i32 to i64
          %61 = arith.ori %60, %59 : i64
          %62 = arith.index_castui %61 : i64 to index
          %63 = arith.extui %14 : i32 to i64
          %64 = arith.shli %63, %c32_i64 : i64
          %65 = arith.extui %13 : i32 to i64
          %66 = arith.ori %65, %64 : i64
          %67 = arith.index_castui %66 : i64 to index
          %68 = arith.extui %16 : i32 to i64
          %69 = arith.shli %68, %c32_i64 : i64
          %70 = arith.extui %15 : i32 to i64
          %71 = arith.ori %70, %69 : i64
          %72 = arith.index_castui %71 : i64 to index
          %73 = arith.extui %18 : i32 to i64
          %74 = arith.shli %73, %c32_i64 : i64
          %75 = arith.extui %17 : i32 to i64
          %76 = arith.ori %75, %74 : i64
          %77 = arith.index_castui %76 : i64 to index
          %78 = arith.extui %20 : i32 to i64
          %79 = arith.shli %78, %c32_i64 : i64
          %80 = arith.extui %19 : i32 to i64
          %81 = arith.ori %80, %79 : i64
          %82 = arith.index_castui %81 : i64 to index
          %83 = arith.extui %22 : i32 to i64
          %84 = arith.shli %83, %c32_i64 : i64
          %85 = arith.extui %21 : i32 to i64
          %86 = arith.ori %85, %84 : i64
          %87 = arith.index_castui %86 : i64 to index
          %88 = arith.extui %24 : i32 to i64
          %89 = arith.shli %88, %c32_i64 : i64
          %90 = arith.extui %23 : i32 to i64
          %91 = arith.ori %90, %89 : i64
          %92 = arith.index_castui %91 : i64 to index
          %93 = arith.extui %26 : i32 to i64
          %94 = arith.shli %93, %c32_i64 : i64
          %95 = arith.extui %25 : i32 to i64
          %96 = arith.ori %95, %94 : i64
          %97 = arith.index_castui %96 : i64 to index
          %98 = arith.extui %28 : i32 to i64
          %99 = arith.shli %98, %c32_i64 : i64
          %100 = arith.extui %27 : i32 to i64
          %101 = arith.ori %100, %99 : i64
          %102 = arith.index_castui %101 : i64 to index
          %103 = arith.extui %30 : i32 to i64
          %104 = arith.shli %103, %c32_i64 : i64
          %105 = arith.extui %29 : i32 to i64
          %106 = arith.ori %105, %104 : i64
          %107 = arith.index_castui %106 : i64 to index
          %108 = arith.extui %32 : i32 to i64
          %109 = arith.shli %108, %c32_i64 : i64
          %110 = arith.extui %31 : i32 to i64
          %111 = arith.ori %110, %109 : i64
          %112 = arith.index_castui %111 : i64 to index
          %113:10 = util.assume.int 
              %67<umin = 0, umax = 9007199254740991>, 
              %72<umin = 0, umax = 9007199254740991>, 
              %77<umin = 0, umax = 9007199254740991>, 
              %82<umin = 0, umax = 9007199254740991>, 
              %87<umin = 0, umax = 9007199254740991>, 
              %92<umin = 0, umax = 9007199254740991>, 
              %97<umin = 0, umax = 9007199254740991>, 
              %102<umin = 0, umax = 9007199254740991>, 
              %107<umin = 0, umax = 9007199254740991>, 
              %112<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index, index, index, index, index, index
          %114 = iree_tensor_ext.dispatch.workload.ordinal %42, 0 : index
          %115 = iree_tensor_ext.dispatch.workload.ordinal %113#0, 5 : index
          %116 = iree_tensor_ext.dispatch.workload.ordinal %113#1, 6 : index
          %117 = iree_tensor_ext.dispatch.workload.ordinal %113#2, 7 : index
          %118 = iree_tensor_ext.dispatch.workload.ordinal %113#3, 8 : index
          %119 = iree_tensor_ext.dispatch.workload.ordinal %113#4, 9 : index
          %120 = iree_tensor_ext.dispatch.workload.ordinal %113#5, 10 : index
          %121 = iree_tensor_ext.dispatch.workload.ordinal %113#6, 11 : index
          %122 = iree_tensor_ext.dispatch.workload.ordinal %113#7, 12 : index
          %123 = iree_tensor_ext.dispatch.workload.ordinal %113#8, 13 : index
          %124 = iree_tensor_ext.dispatch.workload.ordinal %113#9, 14 : index
          %125 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%115}
          %126 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%116, %117, %118}
          %127 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi16>>{%119, %120, %121}
          %128 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi16>>{%122, %123, %124}
          %129 = hal.interface.binding.subspan layout(<constants = 33, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(4) alignment(64) offset(%37) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%114}
          %130 = iree_tensor_ext.dispatch.workload.ordinal %47, 1 : index
          %131 = iree_tensor_ext.dispatch.workload.ordinal %52, 2 : index
          %132 = iree_tensor_ext.dispatch.workload.ordinal %57, 3 : index
          %133 = iree_tensor_ext.dispatch.workload.ordinal %62, 4 : index
          %134 = iree_tensor_ext.dispatch.tensor.load %125, offsets = [0], sizes = [%115], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%115} -> tensor<?xi32>
          %135 = iree_tensor_ext.dispatch.tensor.load %126, offsets = [0, 0, 0], sizes = [%116, %117, %118], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%116, %117, %118} -> tensor<?x?x?xi32>
          %136 = iree_tensor_ext.dispatch.tensor.load %127, offsets = [0, 0, 0], sizes = [%119, %120, %121], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi16>>{%119, %120, %121} -> tensor<?x?x?xi16>
          %137 = iree_tensor_ext.dispatch.tensor.load %128, offsets = [0, 0, 0], sizes = [%122, %123, %124], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi16>>{%122, %123, %124} -> tensor<?x?x?xi16>
          %138 = tensor.empty(%114) : tensor<?xf32>
          %139 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%138 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %140 = linalg.index 0 : index
            %141 = arith.remsi %140, %130 : index
            %142 = arith.divsi %140, %130 : index
            %143 = arith.remsi %142, %117 : index
            %144 = arith.divsi %142, %117 : index
            %extracted = tensor.extract %134[%144] : tensor<?xi32>
            %145 = arith.index_cast %extracted : i32 to index
            %146 = arith.addi %131, %141 : index
            %147 = arith.divui %146, %c32 : index
            %148 = arith.remui %146, %c32 : index
            %149 = arith.muli %147, %132 : index
            %150 = arith.muli %148, %132 : index
            %151 = arith.divui %150, %c32 : index
            %152 = arith.addi %149, %151 : index
            %153 = arith.remui %150, %c32 : index
            %154 = arith.addi %153, %132 : index
            %155 = arith.cmpi ugt, %154, %c32 : index
            %156 = arith.addi %152, %c1 : index
            %157 = arith.select %155, %156, %152 : index
            %extracted_0 = tensor.extract %135[%145, %143, %152] : tensor<?x?x?xi32>
            %extracted_1 = tensor.extract %135[%145, %143, %157] : tensor<?x?x?xi32>
            %158 = arith.index_castui %153 : index to i32
            %159 = arith.shrui %extracted_0, %158 : i32
            %160 = arith.subi %c32, %153 : index
            %161 = arith.index_castui %160 : index to i32
            %162 = arith.andi %161, %c31_i32 : i32
            %163 = arith.shli %extracted_1, %162 : i32
            %164 = arith.select %155, %163, %c0_i32 : i32
            %165 = arith.ori %159, %164 : i32
            %166 = arith.andi %165, %10 : i32
            %167 = arith.uitofp %166 : i32 to f32
            %extracted_2 = tensor.extract %136[%145, %143, %133] : tensor<?x?x?xi16>
            %extracted_3 = tensor.extract %137[%145, %143, %133] : tensor<?x?x?xi16>
            %168 = arith.bitcast %extracted_2 : i16 to bf16
            %169 = arith.extf %168 : bf16 to f32
            %170 = arith.bitcast %extracted_3 : i16 to bf16
            %171 = arith.extf %170 : bf16 to f32
            %172 = arith.mulf %167, %169 : f32
            %173 = arith.addf %172, %171 : f32
            linalg.yield %173 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %139, %129, offsets = [0], sizes = [%114], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%114}
          return
        }
        iree_codegen.dispatch_config @affine_grouped_bf16_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index, %arg10: index, %arg11: index, %arg12: index, %arg13: index, %arg14: index, %arg15: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9, %arg10, %arg11, %arg12, %arg13, %arg14, %arg15)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_grouped_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: !hal.buffer_view, %arg5: i32, %arg6: i32, %arg7: !hal.fence, %arg8: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_grouped_bf16(%input0: tensor<?x?xi16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi16>, %input3: tensor<?x?x?xi16>, %input4: tensor<?xi32>, %input5: i32, %input6: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1_i32 = arith.constant 1 : i32
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg7 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i16) encoding(%dense_row_major)
    %16 = arith.muli %13, %c2 : index
    %17 = arith.muli %16, %14 : index
    %18 = arith.muli %17, %15 : index
    %19 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi16>{%13, %14, %15} in !stream.resource<external>{%18}
    %20 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    %21 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[1] : index
    %22 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[2] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%20, %21, %22]) type(%element_type_i16) encoding(%dense_row_major)
    %23 = arith.muli %20, %c2 : index
    %24 = arith.muli %23, %21 : index
    %25 = arith.muli %24, %22 : index
    %26 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?x?x?xi16>{%20, %21, %22} in !stream.resource<external>{%25}
    %27 = hal.buffer_view.dim<%arg4 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg4 : !hal.buffer_view> message("input4") shape([%27]) type(%element_type_i32) encoding(%dense_row_major)
    %28 = arith.muli %27, %c4 : index
    %29 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg4 : !hal.buffer_view -> tensor<?xi32>{%27} in !stream.resource<external>{%28}
    %30 = arith.index_cast %arg5 : i32 to index
    %31 = arith.divui %1, %30 : index
    %32 = arith.muli %0, %c4 : index
    %33 = arith.muli %32, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%33} => !stream.timepoint
    %34 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg9: !stream.resource<transient>{%33}) {
      stream.cmd.fill %c0_i8, %arg9[%c0 for %33] : i8 -> !stream.resource<transient>{%33}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %33, %34 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%35: index, %36: !stream.resource<transient>, %37: index, %38: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %39 = arith.cmpi slt, %35, %31 : index
    cf.cond_br %39, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %40 = arith.muli %35, %30 : index
    %41 = arith.muli %0, %30 overflow<nsw> : index
    %42 = arith.muli %41, %c4 : index
    %43 = arith.muli %0, %7 overflow<nsw> : index
    %44 = arith.muli %43, %30 overflow<nsw> : index
    %45 = arith.shli %c1_i32, %arg6 : i32
    %46 = arith.index_cast %arg6 : i32 to index
    %47 = arith.subi %45, %c1_i32 : i32
    %48 = arith.muli %44, %c4 : index
    %49 = util.align %42, %c64 : index
    %50 = util.align %48, %c64 : index
    %51 = arith.addi %49, %50 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%51} => !stream.timepoint
    %52 = arith.index_castui %41 : index to i64
    %53 = arith.index_castui %41 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = arith.index_castui %30 : index to i64
    %57 = arith.index_castui %30 : index to i32
    %58 = arith.shrui %56, %c32_i64 : i64
    %59 = arith.trunci %58 : i64 to i32
    %60 = arith.index_castui %40 : index to i64
    %61 = arith.index_castui %40 : index to i32
    %62 = arith.shrui %60, %c32_i64 : i64
    %63 = arith.trunci %62 : i64 to i32
    %64 = arith.index_castui %0 : index to i64
    %65 = arith.index_castui %0 : index to i32
    %66 = arith.shrui %64, %c32_i64 : i64
    %67 = arith.trunci %66 : i64 to i32
    %68 = arith.index_castui %1 : index to i64
    %69 = arith.index_castui %1 : index to i32
    %70 = arith.shrui %68, %c32_i64 : i64
    %71 = arith.trunci %70 : i64 to i32
    %72 = arith.index_castui %49 : index to i64
    %73 = arith.index_castui %49 : index to i32
    %74 = arith.shrui %72, %c32_i64 : i64
    %75 = arith.trunci %74 : i64 to i32
    %76 = arith.index_castui %44 : index to i64
    %77 = arith.index_castui %44 : index to i32
    %78 = arith.shrui %76, %c32_i64 : i64
    %79 = arith.trunci %78 : i64 to i32
    %80 = arith.index_castui %46 : index to i64
    %81 = arith.index_castui %46 : index to i32
    %82 = arith.shrui %80, %c32_i64 : i64
    %83 = arith.trunci %82 : i64 to i32
    %84 = arith.index_castui %35 : index to i64
    %85 = arith.index_castui %35 : index to i32
    %86 = arith.shrui %84, %c32_i64 : i64
    %87 = arith.trunci %86 : i64 to i32
    %88 = arith.index_castui %27 : index to i64
    %89 = arith.index_castui %27 : index to i32
    %90 = arith.shrui %88, %c32_i64 : i64
    %91 = arith.trunci %90 : i64 to i32
    %92 = arith.index_castui %6 : index to i64
    %93 = arith.index_castui %6 : index to i32
    %94 = arith.shrui %92, %c32_i64 : i64
    %95 = arith.trunci %94 : i64 to i32
    %96 = arith.index_castui %7 : index to i64
    %97 = arith.index_castui %7 : index to i32
    %98 = arith.shrui %96, %c32_i64 : i64
    %99 = arith.trunci %98 : i64 to i32
    %100 = arith.index_castui %8 : index to i64
    %101 = arith.index_castui %8 : index to i32
    %102 = arith.shrui %100, %c32_i64 : i64
    %103 = arith.trunci %102 : i64 to i32
    %104 = arith.index_castui %13 : index to i64
    %105 = arith.index_castui %13 : index to i32
    %106 = arith.shrui %104, %c32_i64 : i64
    %107 = arith.trunci %106 : i64 to i32
    %108 = arith.index_castui %14 : index to i64
    %109 = arith.index_castui %14 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %15 : index to i64
    %113 = arith.index_castui %15 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %20 : index to i64
    %117 = arith.index_castui %20 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = arith.index_castui %21 : index to i64
    %121 = arith.index_castui %21 : index to i32
    %122 = arith.shrui %120, %c32_i64 : i64
    %123 = arith.trunci %122 : i64 to i32
    %124 = arith.index_castui %22 : index to i64
    %125 = arith.index_castui %22 : index to i32
    %126 = arith.shrui %124, %c32_i64 : i64
    %127 = arith.trunci %126 : i64 to i32
    %128 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg9: !stream.resource<external>{%3}, %29 as %arg10: !stream.resource<external>{%28}, %12 as %arg11: !stream.resource<external>{%11}, %19 as %arg12: !stream.resource<external>{%18}, %26 as %arg13: !stream.resource<external>{%25}, %result_0 as %arg14: !stream.resource<transient>{%51}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_0::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32[%41, %30, %40, %0, %1](%53, %55, %57, %59, %61, %63, %65, %67, %69, %71 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg14[%c0 for %51] : !stream.resource<transient>{%51}
      }
      stream.cmd.dispatch @affine_grouped_bf16_dispatch_1::@vulkan_spirv_fb::@affine_grouped_bf16_dispatch_1_elementwise_broadcast_D_f32[%44, %30, %40, %46, %35, %27, %6, %7, %8, %13, %14, %15, %20, %21, %22](%73, %75, %77, %79, %57, %59, %61, %63, %81, %83, %47, %85, %87, %89, %91, %93, %95, %97, %99, %101, %103, %105, %107, %109, %111, %113, %115, %117, %119, %121, %123, %125, %127 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg10[%c0 for %28] : !stream.resource<external>{%28},
        ro %arg11[%c0 for %11] : !stream.resource<external>{%11},
        ro %arg12[%c0 for %18] : !stream.resource<external>{%18},
        ro %arg13[%c0 for %25] : !stream.resource<external>{%25},
        wo %arg14[%c0 for %51] : !stream.resource<transient>{%51}
      }
    } => !stream.timepoint
    %129 = arith.muli %33, %30 : index
    %130 = stream.timepoint.await %128 => %result_0 : !stream.resource<transient>{%51}
    %131 = stream.resource.subview %130[%c0] : !stream.resource<transient>{%51} -> !stream.resource<transient>{%42}
    %132 = stream.resource.subview %130[%49] : !stream.resource<transient>{%51} -> !stream.resource<transient>{%48}
    %133 = util.optimization_barrier %131 : !stream.resource<transient>
    %134 = util.optimization_barrier %132 : !stream.resource<transient>
    %135 = arith.muli %32, %30 : index
    %136 = arith.muli %43, %c4 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%38) => !stream.resource<transient>{%136} => !stream.timepoint
    %137 = util.align %33, %c64 : index
    %138 = arith.addi %137, %137 : index
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%38) => !stream.resource<transient>{%138} => !stream.timepoint
    %139 = stream.timepoint.join max(%result_timepoint_3, %result_timepoint_5) => !stream.timepoint
    %140 = arith.index_castui %137 : index to i64
    %141 = arith.index_castui %137 : index to i32
    %142 = arith.shrui %140, %c32_i64 : i64
    %143 = arith.trunci %142 : i64 to i32
    %144 = arith.index_castui %43 : index to i64
    %145 = arith.index_castui %43 : index to i32
    %146 = arith.shrui %144, %c32_i64 : i64
    %147 = arith.trunci %146 : i64 to i32
    %148 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%139) => with(%133 as %arg9: !stream.resource<transient>{%135}, %134 as %arg10: !stream.resource<transient>{%129}, %36 as %arg11: !stream.resource<transient>{%37}, %result_2 as %arg12: !stream.resource<transient>{%136}, %result_4 as %arg13: !stream.resource<transient>{%138}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %30, %7](%65, %67, %57, %59, %97, %99 : i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %135] : !stream.resource<transient>{%135},
        ro %arg10[%c0 for %129] : !stream.resource<transient>{%129},
        wo %arg13[%c0 for %138] : !stream.resource<transient>{%138}
      }
      stream.cmd.copy %arg11[%c0], %arg13[%137], %33 : !stream.resource<transient>{%33} -> !stream.resource<transient>{%138}
      stream.cmd.dispatch @affine_linear_f32_dispatch_3::@vulkan_spirv_fb::@affine_linear_f32_dispatch_3_elementwise_broadcast_D_f32[%43, %7, %0](%141, %143, %145, %147, %97, %99, %65, %67 : i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg13[%c0 for %138] : !stream.resource<transient>{%138},
        wo %arg12[%c0 for %136] : !stream.resource<transient>{%136}
      }
    } => !stream.timepoint
    %149 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%148) => %result_4 : !stream.resource<transient>{%138} => !stream.timepoint
    %150 = arith.addi %35, %c1 : index
    cf.br ^bb1(%150, %result_2, %136, %149 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %151 = arith.muli %0, %7 overflow<nsw> : index
    %152 = arith.muli %151, %c2 : index
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%38) => !stream.resource<external>{%152} => !stream.timepoint
    %153 = arith.index_castui %151 : index to i64
    %154 = arith.index_castui %151 : index to i32
    %155 = arith.shrui %153, %c32_i64 : i64
    %156 = arith.trunci %155 : i64 to i32
    %157 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_7) => with(%36 as %arg9: !stream.resource<transient>{%37}, %result_6 as %arg10: !stream.resource<external>{%152}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_4::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_4_elementwise_D_f32xi16[%151](%154, %156 : i32, i32) {
        ro %arg9[%c0 for %37] : !stream.resource<transient>{%37},
        wo %arg10[%c0 for %152] : !stream.resource<external>{%152}
      }
    } => !stream.timepoint
    %158 = stream.resource.dealloca origin await(%157) => %36 : !stream.resource<transient>{%37} => !stream.timepoint
    %159 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %158 => (%arg8 : !hal.fence)
    %160 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_6 : tensor<?x?xi16>{%0, %7} in !stream.resource<external>{%159} -> !hal.buffer_view
    util.return %160 : !hal.buffer_view
  }
  hal.executable private @mx4_linear_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_linear_f32_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_linear_f32_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %cst = arith.constant dense<[0.000000e+00, 5.000000e-01, 1.000000e+00, 1.500000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 6.000000e+00, -0.000000e+00, -5.000000e-01, -1.000000e+00, -1.500000e+00, -2.000000e+00, -3.000000e+00, -4.000000e+00, -6.000000e+00]> : tensor<16xf32>
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 {stream.alignment = 64 : index} : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:3 = util.assume.int 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 5 : index
          %54 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%51, %52, %53}
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%18) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          %56 = iree_tensor_ext.dispatch.workload.ordinal %28, 1 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %58 = iree_tensor_ext.dispatch.tensor.load %54, offsets = [0, 0, 0], sizes = [%51, %52, %53], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%51, %52, %53} -> tensor<?x?x?xi32>
          %59 = tensor.empty(%50) : tensor<?xf32>
          %60 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%59 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %61 = linalg.index 0 : index
            %62 = arith.remsi %61, %56 : index
            %63 = arith.divsi %61, %56 : index
            %64 = arith.remsi %63, %52 : index
            %65 = arith.addi %57, %62 : index
            %66 = arith.divui %65, %c8 : index
            %67 = arith.remui %65, %c8 : index
            %68 = arith.muli %67, %c4 : index
            %69 = arith.index_castui %68 : index to i32
            %extracted = tensor.extract %58[%c0, %64, %66] : tensor<?x?x?xi32>
            %70 = arith.shrui %extracted, %69 : i32
            %71 = arith.andi %70, %c15_i32 : i32
            %72 = arith.index_castui %71 : i32 to index
            %extracted_0 = tensor.extract %cst[%72] : tensor<16xf32>
            linalg.yield %extracted_0 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %60, %55, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          return
        }
        iree_codegen.dispatch_config @mx4_linear_f32_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @mx4_linear_f32_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_linear_f32_dispatch_3_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_linear_f32_dispatch_3_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c23_i32 = arith.constant 23 : i32
          %c4194304_i32 = arith.constant 4194304 : i32
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 {stream.alignment = 64 : index} : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:4 = util.assume.int 
              %28<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 5 : index
          %54 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%51, %52, %53}
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%18) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          %56 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 1 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %58 = iree_tensor_ext.dispatch.tensor.load %54, offsets = [0, 0, 0], sizes = [%51, %52, %53], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%51, %52, %53} -> tensor<?x?x?xi8>
          %59 = tensor.empty(%50) : tensor<?xf32>
          %60 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%59 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %61 = linalg.index 0 : index
            %62 = arith.remsi %61, %56 : index
            %extracted = tensor.extract %58[%c0, %62, %57] : tensor<?x?x?xi8>
            %63 = arith.extui %extracted : i8 to i32
            %64 = arith.shli %63, %c23_i32 : i32
            %65 = arith.cmpi eq, %63, %c0_i32 : i32
            %66 = arith.select %65, %c4194304_i32, %64 : i32
            %67 = arith.bitcast %66 : i32 to f32
            linalg.yield %67 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %60, %55, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          return
        }
        iree_codegen.dispatch_config @mx4_linear_f32_dispatch_3_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @mx4_linear_f32_dispatch_4 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_linear_f32_dispatch_4_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_linear_f32_dispatch_4_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = arith.extui %1 : i32 to i64
          %7 = arith.shli %6, %c32_i64 : i64
          %8 = arith.extui %0 : i32 to i64
          %9 = arith.ori %8, %7 : i64
          %10 = arith.index_castui %9 : i64 to index
          %11 = arith.extui %3 : i32 to i64
          %12 = arith.shli %11, %c32_i64 : i64
          %13 = arith.extui %2 : i32 to i64
          %14 = arith.ori %13, %12 : i64
          %15 = arith.index_castui %14 : i64 to index
          %16 = arith.extui %5 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %4 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21:2 = util.assume.int 
              %15<umin = 0, umax = 9007199254740991>, 
              %20<umin = 0, umax = 9007199254740991>
            : index, index
          %22 = iree_tensor_ext.dispatch.workload.ordinal %10, 0 : index
          %23 = iree_tensor_ext.dispatch.workload.ordinal %21#0, 1 : index
          %24 = iree_tensor_ext.dispatch.workload.ordinal %21#1, 2 : index
          %25 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24}
          %26 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24}
          %27 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24}
          %28 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%22}
          %29 = iree_tensor_ext.dispatch.tensor.load %25, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24} -> tensor<?x?xf32>
          %30 = iree_tensor_ext.dispatch.tensor.load %26, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24} -> tensor<?x?xf32>
          %31 = iree_tensor_ext.dispatch.tensor.load %27, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24} -> tensor<?x?xf32>
          %32 = tensor.empty(%22) : tensor<?xf32>
          %33 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%32 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %34 = linalg.index 0 : index
            %35 = arith.remsi %34, %24 : index
            %36 = arith.divsi %34, %24 : index
            %extracted = tensor.extract %29[%36, %35] : tensor<?x?xf32>
            %extracted_0 = tensor.extract %30[%36, %35] : tensor<?x?xf32>
            %extracted_1 = tensor.extract %31[%36, %35] : tensor<?x?xf32>
            %37 = arith.mulf %extracted, %extracted_1 : f32
            %38 = arith.addf %extracted_0, %37 : f32
            linalg.yield %38 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %33, %28, offsets = [0], sizes = [%22], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%22}
          return
        }
        iree_codegen.dispatch_config @mx4_linear_f32_dispatch_4_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @mx4_linear_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx4_linear_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg3 : i32 to index
    %20 = arith.divui %1, %19 : index
    %21 = arith.muli %2, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%21} => !stream.timepoint
    %22 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg6: !stream.resource<external>{%21}) {
      stream.cmd.fill %c0_i8, %arg6[%c0 for %21] : i8 -> !stream.resource<external>{%21}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %21, %22 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb1(%23: index, %24: !stream.resource<external>, %25: index, %26: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %27 = arith.cmpi slt, %23, %20 : index
    cf.cond_br %27, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %28 = arith.muli %23, %19 : index
    %29 = arith.muli %0, %19 overflow<nsw> : index
    %30 = arith.muli %29, %c4 : index
    %31 = arith.muli %0, %7 overflow<nsw> : index
    %32 = arith.muli %31, %19 overflow<nsw> : index
    %33 = arith.muli %32, %c4 : index
    %34 = util.align %30, %c64 : index
    %35 = util.align %33, %c64 : index
    %36 = arith.addi %34, %35 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%36} => !stream.timepoint
    %37 = arith.index_castui %29 : index to i64
    %38 = arith.index_castui %29 : index to i32
    %39 = arith.shrui %37, %c32_i64 : i64
    %40 = arith.trunci %39 : i64 to i32
    %41 = arith.index_castui %19 : index to i64
    %42 = arith.index_castui %19 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = arith.index_castui %28 : index to i64
    %46 = arith.index_castui %28 : index to i32
    %47 = arith.shrui %45, %c32_i64 : i64
    %48 = arith.trunci %47 : i64 to i32
    %49 = arith.index_castui %0 : index to i64
    %50 = arith.index_castui %0 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %1 : index to i64
    %54 = arith.index_castui %1 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %34 : index to i64
    %58 = arith.index_castui %34 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = arith.index_castui %32 : index to i64
    %62 = arith.index_castui %32 : index to i32
    %63 = arith.shrui %61, %c32_i64 : i64
    %64 = arith.trunci %63 : i64 to i32
    %65 = arith.index_castui %6 : index to i64
    %66 = arith.index_castui %6 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %7 : index to i64
    %70 = arith.index_castui %7 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = arith.index_castui %8 : index to i64
    %74 = arith.index_castui %8 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg6: !stream.resource<external>{%3}, %12 as %arg7: !stream.resource<external>{%11}, %result_0 as %arg8: !stream.resource<transient>{%36}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_0::@vulkan_spirv_fb::@affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32[%29, %19, %28, %0, %1](%38, %40, %42, %44, %46, %48, %50, %52, %54, %56 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg8[%c0 for %36] : !stream.resource<transient>{%36}
      }
      stream.cmd.dispatch @mx4_linear_f32_dispatch_1::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_1_elementwise_broadcast_D_f32[%32, %19, %28, %6, %7, %8](%58, %60, %62, %64, %42, %44, %46, %48, %66, %68, %70, %72, %74, %76 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg8[%c0 for %36] : !stream.resource<transient>{%36}
      }
    } => !stream.timepoint
    %78 = arith.muli %21, %19 : index
    %79 = stream.timepoint.await %77 => %result_0 : !stream.resource<transient>{%36}
    %80 = stream.resource.subview %79[%c0] : !stream.resource<transient>{%36} -> !stream.resource<transient>{%30}
    %81 = stream.resource.subview %79[%34] : !stream.resource<transient>{%36} -> !stream.resource<transient>{%33}
    %82 = util.optimization_barrier %80 : !stream.resource<transient>
    %83 = util.optimization_barrier %81 : !stream.resource<transient>
    %84 = arith.muli %2, %19 : index
    %85 = arith.muli %31, %c4 : index
    %86 = util.align %21, %c64 : index
    %87 = util.align %85, %c64 : index
    %88 = arith.addi %86, %87 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%88} => !stream.timepoint
    %89 = arith.index_castui %86 : index to i64
    %90 = arith.index_castui %86 : index to i32
    %91 = arith.shrui %89, %c32_i64 : i64
    %92 = arith.trunci %91 : i64 to i32
    %93 = arith.index_castui %31 : index to i64
    %94 = arith.index_castui %31 : index to i32
    %95 = arith.shrui %93, %c32_i64 : i64
    %96 = arith.trunci %95 : i64 to i32
    %97 = arith.index_castui %23 : index to i64
    %98 = arith.index_castui %23 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %13 : index to i64
    %102 = arith.index_castui %13 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %14 : index to i64
    %106 = arith.index_castui %14 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %15 : index to i64
    %110 = arith.index_castui %15 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%82 as %arg6: !stream.resource<transient>{%84}, %83 as %arg7: !stream.resource<transient>{%78}, %18 as %arg8: !stream.resource<external>{%17}, %result_2 as %arg9: !stream.resource<transient>{%88}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %19, %7](%50, %52, %42, %44, %70, %72 : i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %84] : !stream.resource<transient>{%84},
        ro %arg7[%c0 for %78] : !stream.resource<transient>{%78},
        wo %arg9[%c0 for %88] : !stream.resource<transient>{%88}
      }
      stream.cmd.dispatch @mx4_linear_f32_dispatch_3::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_3_elementwise_broadcast_D_f32[%31, %7, %23, %13, %14, %15](%90, %92, %94, %96, %70, %72, %98, %100, %102, %104, %106, %108, %110, %112 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg9[%c0 for %88] : !stream.resource<transient>{%88}
      }
    } => !stream.timepoint
    %114 = stream.timepoint.await %113 => %result_2 : !stream.resource<transient>{%88}
    %115 = stream.resource.subview %114[%86] : !stream.resource<transient>{%88} -> !stream.resource<transient>{%85}
    %116 = util.optimization_barrier %115 : !stream.resource<transient>
    %117 = stream.timepoint.join max(%113, %26) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%117) => !stream.resource<external>{%85} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%117) => !stream.resource<transient>{%86} => !stream.timepoint
    %118 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %119 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%118) => with(%24 as %arg6: !stream.resource<external>{%25}, %result_2 as %arg7: !stream.resource<transient>{%88}, %116 as %arg8: !stream.resource<transient>{%21}, %result_4 as %arg9: !stream.resource<external>{%85}, %result_6 as %arg10: !stream.resource<transient>{%86}) {
      stream.cmd.copy %arg6[%c0], %arg10[%c0], %21 : !stream.resource<external>{%21} -> !stream.resource<transient>{%86}
      stream.cmd.dispatch @mx4_linear_f32_dispatch_4::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_4_elementwise_broadcast_D_f32[%31, %0, %7](%94, %96, %50, %52, %70, %72 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %88] : !stream.resource<transient>{%88},
        ro %arg10[%c0 for %86] : !stream.resource<transient>{%86},
        ro %arg8[%c0 for %21] : !stream.resource<transient>{%21},
        wo %arg9[%c0 for %85] : !stream.resource<external>{%85}
      }
    } => !stream.timepoint
    %120 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%119) => %result_6 : !stream.resource<transient>{%86} => !stream.timepoint
    %121 = arith.addi %23, %c1 : index
    cf.br ^bb1(%121, %result_4, %85, %120 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %26 => (%arg5 : !hal.fence)
    %122 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %24 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%21} -> !hal.buffer_view
    util.return %122 : !hal.buffer_view
  }
  hal.executable private @mx4_grouped_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_grouped_f32_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_grouped_f32_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %cst = arith.constant dense<[0.000000e+00, 5.000000e-01, 1.000000e+00, 1.500000e+00, 2.000000e+00, 3.000000e+00, 4.000000e+00, 6.000000e+00, -0.000000e+00, -5.000000e-01, -1.000000e+00, -1.500000e+00, -2.000000e+00, -3.000000e+00, -4.000000e+00, -6.000000e+00]> : tensor<16xf32>
          %c8 = arith.constant 8 : index
          %c4 = arith.constant 4 : index
          %c15_i32 = arith.constant 15 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 {stream.alignment = 64 : index} : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:4 = util.assume.int 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %25, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 3 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 4 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 5 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 6 : index
          %62 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58}
          %63 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%59, %60, %61}
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%20) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%57}
          %65 = iree_tensor_ext.dispatch.workload.ordinal %30, 1 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %35, 2 : index
          %67 = iree_tensor_ext.dispatch.tensor.load %62, offsets = [0], sizes = [%58], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58} -> tensor<?xi32>
          %68 = iree_tensor_ext.dispatch.tensor.load %63, offsets = [0, 0, 0], sizes = [%59, %60, %61], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%59, %60, %61} -> tensor<?x?x?xi32>
          %69 = tensor.empty(%57) : tensor<?xf32>
          %70 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%69 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %71 = linalg.index 0 : index
            %72 = arith.remsi %71, %65 : index
            %73 = arith.divsi %71, %65 : index
            %74 = arith.remsi %73, %60 : index
            %75 = arith.divsi %73, %60 : index
            %extracted = tensor.extract %67[%75] : tensor<?xi32>
            %76 = arith.index_cast %extracted : i32 to index
            %77 = arith.addi %66, %72 : index
            %78 = arith.divui %77, %c8 : index
            %79 = arith.remui %77, %c8 : index
            %80 = arith.muli %79, %c4 : index
            %81 = arith.index_castui %80 : index to i32
            %extracted_0 = tensor.extract %68[%76, %74, %78] : tensor<?x?x?xi32>
            %82 = arith.shrui %extracted_0, %81 : i32
            %83 = arith.andi %82, %c15_i32 : i32
            %84 = arith.index_castui %83 : i32 to index
            %extracted_1 = tensor.extract %cst[%84] : tensor<16xf32>
            linalg.yield %extracted_1 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %70, %64, offsets = [0], sizes = [%57], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%57}
          return
        }
        iree_codegen.dispatch_config @mx4_grouped_f32_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @mx4_grouped_f32_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_grouped_f32_dispatch_3_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_grouped_f32_dispatch_3_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c23_i32 = arith.constant 23 : i32
          %c4194304_i32 = arith.constant 4194304 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 {stream.alignment = 64 : index} : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:5 = util.assume.int 
              %30<umin = 0, umax = 9007199254740991>, 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %25, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 3 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 4 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 5 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#4, 6 : index
          %62 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58}
          %63 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%59, %60, %61}
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%20) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%57}
          %65 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 1 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %35, 2 : index
          %67 = iree_tensor_ext.dispatch.tensor.load %62, offsets = [0], sizes = [%58], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58} -> tensor<?xi32>
          %68 = iree_tensor_ext.dispatch.tensor.load %63, offsets = [0, 0, 0], sizes = [%59, %60, %61], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%59, %60, %61} -> tensor<?x?x?xi8>
          %69 = tensor.empty(%57) : tensor<?xf32>
          %70 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%69 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %71 = linalg.index 0 : index
            %72 = arith.remsi %71, %65 : index
            %73 = arith.divsi %71, %65 : index
            %extracted = tensor.extract %67[%73] : tensor<?xi32>
            %74 = arith.index_cast %extracted : i32 to index
            %extracted_0 = tensor.extract %68[%74, %72, %66] : tensor<?x?x?xi8>
            %75 = arith.extui %extracted_0 : i8 to i32
            %76 = arith.shli %75, %c23_i32 : i32
            %77 = arith.cmpi eq, %75, %c0_i32 : i32
            %78 = arith.select %77, %c4194304_i32, %76 : i32
            %79 = arith.bitcast %78 : i32 to f32
            linalg.yield %79 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %70, %64, offsets = [0], sizes = [%57], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%57}
          return
        }
        iree_codegen.dispatch_config @mx4_grouped_f32_dispatch_3_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @mx4_grouped_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: !hal.fence, %arg6: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx4_grouped_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: tensor<?xi32>, %input4: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg5 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%19]) type(%element_type_i32) encoding(%dense_row_major)
    %20 = arith.muli %19, %c4 : index
    %21 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%19} in !stream.resource<external>{%20}
    %22 = arith.index_cast %arg4 : i32 to index
    %23 = arith.divui %1, %22 : index
    %24 = arith.muli %2, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%24} => !stream.timepoint
    %25 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg7: !stream.resource<external>{%24}) {
      stream.cmd.fill %c0_i8, %arg7[%c0 for %24] : i8 -> !stream.resource<external>{%24}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %24, %25 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb1(%26: index, %27: !stream.resource<external>, %28: index, %29: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %30 = arith.cmpi slt, %26, %23 : index
    cf.cond_br %30, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %31 = arith.muli %26, %22 : index
    %32 = arith.muli %0, %22 overflow<nsw> : index
    %33 = arith.muli %32, %c4 : index
    %34 = arith.muli %0, %7 overflow<nsw> : index
    %35 = arith.muli %34, %22 overflow<nsw> : index
    %36 = arith.muli %35, %c4 : index
    %37 = util.align %33, %c64 : index
    %38 = util.align %36, %c64 : index
    %39 = arith.addi %37, %38 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%39} => !stream.timepoint
    %40 = arith.index_castui %32 : index to i64
    %41 = arith.index_castui %32 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %22 : index to i64
    %45 = arith.index_castui %22 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %31 : index to i64
    %49 = arith.index_castui %31 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %0 : index to i64
    %53 = arith.index_castui %0 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = arith.index_castui %1 : index to i64
    %57 = arith.index_castui %1 : index to i32
    %58 = arith.shrui %56, %c32_i64 : i64
    %59 = arith.trunci %58 : i64 to i32
    %60 = arith.index_castui %37 : index to i64
    %61 = arith.index_castui %37 : index to i32
    %62 = arith.shrui %60, %c32_i64 : i64
    %63 = arith.trunci %62 : i64 to i32
    %64 = arith.index_castui %35 : index to i64
    %65 = arith.index_castui %35 : index to i32
    %66 = arith.shrui %64, %c32_i64 : i64
    %67 = arith.trunci %66 : i64 to i32
    %68 = arith.index_castui %19 : index to i64
    %69 = arith.index_castui %19 : index to i32
    %70 = arith.shrui %68, %c32_i64 : i64
    %71 = arith.trunci %70 : i64 to i32
    %72 = arith.index_castui %6 : index to i64
    %73 = arith.index_castui %6 : index to i32
    %74 = arith.shrui %72, %c32_i64 : i64
    %75 = arith.trunci %74 : i64 to i32
    %76 = arith.index_castui %7 : index to i64
    %77 = arith.index_castui %7 : index to i32
    %78 = arith.shrui %76, %c32_i64 : i64
    %79 = arith.trunci %78 : i64 to i32
    %80 = arith.index_castui %8 : index to i64
    %81 = arith.index_castui %8 : index to i32
    %82 = arith.shrui %80, %c32_i64 : i64
    %83 = arith.trunci %82 : i64 to i32
    %84 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg7: !stream.resource<external>{%3}, %21 as %arg8: !stream.resource<external>{%20}, %12 as %arg9: !stream.resource<external>{%11}, %result_0 as %arg10: !stream.resource<transient>{%39}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_0::@vulkan_spirv_fb::@affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32[%32, %22, %31, %0, %1](%41, %43, %45, %47, %49, %51, %53, %55, %57, %59 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg10[%c0 for %39] : !stream.resource<transient>{%39}
      }
      stream.cmd.dispatch @mx4_grouped_f32_dispatch_1::@vulkan_spirv_fb::@mx4_grouped_f32_dispatch_1_elementwise_broadcast_D_f32[%35, %22, %31, %19, %6, %7, %8](%61, %63, %65, %67, %45, %47, %49, %51, %69, %71, %73, %75, %77, %79, %81, %83 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg10[%c0 for %39] : !stream.resource<transient>{%39}
      }
    } => !stream.timepoint
    %85 = arith.muli %24, %22 : index
    %86 = stream.timepoint.await %84 => %result_0 : !stream.resource<transient>{%39}
    %87 = stream.resource.subview %86[%c0] : !stream.resource<transient>{%39} -> !stream.resource<transient>{%33}
    %88 = stream.resource.subview %86[%37] : !stream.resource<transient>{%39} -> !stream.resource<transient>{%36}
    %89 = util.optimization_barrier %87 : !stream.resource<transient>
    %90 = util.optimization_barrier %88 : !stream.resource<transient>
    %91 = arith.muli %2, %22 : index
    %92 = arith.muli %34, %c4 : index
    %93 = util.align %24, %c64 : index
    %94 = util.align %92, %c64 : index
    %95 = arith.addi %93, %94 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%95} => !stream.timepoint
    %96 = arith.index_castui %93 : index to i64
    %97 = arith.index_castui %93 : index to i32
    %98 = arith.shrui %96, %c32_i64 : i64
    %99 = arith.trunci %98 : i64 to i32
    %100 = arith.index_castui %34 : index to i64
    %101 = arith.index_castui %34 : index to i32
    %102 = arith.shrui %100, %c32_i64 : i64
    %103 = arith.trunci %102 : i64 to i32
    %104 = arith.index_castui %26 : index to i64
    %105 = arith.index_castui %26 : index to i32
    %106 = arith.shrui %104, %c32_i64 : i64
    %107 = arith.trunci %106 : i64 to i32
    %108 = arith.index_castui %13 : index to i64
    %109 = arith.index_castui %13 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %14 : index to i64
    %113 = arith.index_castui %14 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %15 : index to i64
    %117 = arith.index_castui %15 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%89 as %arg7: !stream.resource<transient>{%91}, %90 as %arg8: !stream.resource<transient>{%85}, %21 as %arg9: !stream.resource<external>{%20}, %18 as %arg10: !stream.resource<external>{%17}, %result_2 as %arg11: !stream.resource<transient>{%95}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %22, %7](%53, %55, %45, %47, %77, %79 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %91] : !stream.resource<transient>{%91},
        ro %arg8[%c0 for %85] : !stream.resource<transient>{%85},
        wo %arg11[%c0 for %95] : !stream.resource<transient>{%95}
      }
      stream.cmd.dispatch @mx4_grouped_f32_dispatch_3::@vulkan_spirv_fb::@mx4_grouped_f32_dispatch_3_elementwise_broadcast_D_f32[%34, %7, %26, %19, %13, %14, %15](%97, %99, %101, %103, %77, %79, %105, %107, %69, %71, %109, %111, %113, %115, %117, %119 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg11[%c0 for %95] : !stream.resource<transient>{%95}
      }
    } => !stream.timepoint
    %121 = stream.timepoint.await %120 => %result_2 : !stream.resource<transient>{%95}
    %122 = stream.resource.subview %121[%93] : !stream.resource<transient>{%95} -> !stream.resource<transient>{%92}
    %123 = util.optimization_barrier %122 : !stream.resource<transient>
    %124 = stream.timepoint.join max(%120, %29) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%124) => !stream.resource<external>{%92} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%124) => !stream.resource<transient>{%93} => !stream.timepoint
    %125 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %126 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%125) => with(%27 as %arg7: !stream.resource<external>{%28}, %result_2 as %arg8: !stream.resource<transient>{%95}, %123 as %arg9: !stream.resource<transient>{%24}, %result_4 as %arg10: !stream.resource<external>{%92}, %result_6 as %arg11: !stream.resource<transient>{%93}) {
      stream.cmd.copy %arg7[%c0], %arg11[%c0], %24 : !stream.resource<external>{%24} -> !stream.resource<transient>{%93}
      stream.cmd.dispatch @mx4_linear_f32_dispatch_4::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_4_elementwise_broadcast_D_f32[%34, %0, %7](%101, %103, %53, %55, %77, %79 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %95] : !stream.resource<transient>{%95},
        ro %arg11[%c0 for %93] : !stream.resource<transient>{%93},
        ro %arg9[%c0 for %24] : !stream.resource<transient>{%24},
        wo %arg10[%c0 for %92] : !stream.resource<external>{%92}
      }
    } => !stream.timepoint
    %127 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%126) => %result_6 : !stream.resource<transient>{%93} => !stream.timepoint
    %128 = arith.addi %26, %c1 : index
    cf.br ^bb1(%128, %result_4, %92, %127 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %29 => (%arg6 : !hal.fence)
    %129 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %27 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%24} -> !hal.buffer_view
    util.return %129 : !hal.buffer_view
  }
  hal.executable private @mx4_linear_f16_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_linear_f16_dispatch_3_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_linear_f16_dispatch_3_elementwise_broadcast_D_f16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c23_i32 = arith.constant 23 : i32
          %c4194304_i32 = arith.constant 4194304 : i32
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 {stream.alignment = 64 : index} : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:4 = util.assume.int 
              %28<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 5 : index
          %54 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%51, %52, %53}
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%18) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%50}
          %56 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 1 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %58 = iree_tensor_ext.dispatch.tensor.load %54, offsets = [0, 0, 0], sizes = [%51, %52, %53], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%51, %52, %53} -> tensor<?x?x?xi8>
          %59 = tensor.empty(%50) : tensor<?xf16>
          %60 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%59 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %61 = linalg.index 0 : index
            %62 = arith.remsi %61, %56 : index
            %extracted = tensor.extract %58[%c0, %62, %57] : tensor<?x?x?xi8>
            %63 = arith.extui %extracted : i8 to i32
            %64 = arith.shli %63, %c23_i32 : i32
            %65 = arith.cmpi eq, %63, %c0_i32 : i32
            %66 = arith.select %65, %c4194304_i32, %64 : i32
            %67 = arith.bitcast %66 : i32 to f32
            %68 = arith.truncf %67 : f32 to f16
            linalg.yield %68 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %60, %55, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%50}
          return
        }
        iree_codegen.dispatch_config @mx4_linear_f16_dispatch_3_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @mx4_linear_f16_dispatch_4 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_linear_f16_dispatch_4_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_linear_f16_dispatch_4_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = arith.extui %1 : i32 to i64
          %7 = arith.shli %6, %c32_i64 : i64
          %8 = arith.extui %0 : i32 to i64
          %9 = arith.ori %8, %7 : i64
          %10 = arith.index_castui %9 : i64 to index
          %11 = arith.extui %3 : i32 to i64
          %12 = arith.shli %11, %c32_i64 : i64
          %13 = arith.extui %2 : i32 to i64
          %14 = arith.ori %13, %12 : i64
          %15 = arith.index_castui %14 : i64 to index
          %16 = arith.extui %5 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %4 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21:2 = util.assume.int 
              %15<umin = 0, umax = 9007199254740991>, 
              %20<umin = 0, umax = 9007199254740991>
            : index, index
          %22 = iree_tensor_ext.dispatch.workload.ordinal %10, 0 : index
          %23 = iree_tensor_ext.dispatch.workload.ordinal %21#0, 1 : index
          %24 = iree_tensor_ext.dispatch.workload.ordinal %21#1, 2 : index
          %25 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24}
          %26 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24}
          %27 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%23, %24}
          %28 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%22}
          %29 = iree_tensor_ext.dispatch.tensor.load %25, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24} -> tensor<?x?xf32>
          %30 = iree_tensor_ext.dispatch.tensor.load %26, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24} -> tensor<?x?xf32>
          %31 = iree_tensor_ext.dispatch.tensor.load %27, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%23, %24} -> tensor<?x?xf16>
          %32 = tensor.empty(%22) : tensor<?xf32>
          %33 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%32 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %34 = linalg.index 0 : index
            %35 = arith.remsi %34, %24 : index
            %36 = arith.divsi %34, %24 : index
            %extracted = tensor.extract %29[%36, %35] : tensor<?x?xf32>
            %extracted_0 = tensor.extract %30[%36, %35] : tensor<?x?xf32>
            %extracted_1 = tensor.extract %31[%36, %35] : tensor<?x?xf16>
            %37 = arith.extf %extracted_1 : f16 to f32
            %38 = arith.mulf %extracted, %37 : f32
            %39 = arith.addf %extracted_0, %38 : f32
            linalg.yield %39 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %33, %28, offsets = [0], sizes = [%22], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%22}
          return
        }
        iree_codegen.dispatch_config @mx4_linear_f16_dispatch_4_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @mx4_linear_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx4_linear_f16(%input0: tensor<?x?xf16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg3 : i32 to index
    %20 = arith.divui %1, %19 : index
    %21 = arith.muli %0, %c4 : index
    %22 = arith.muli %21, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%22} => !stream.timepoint
    %23 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg6: !stream.resource<transient>{%22}) {
      stream.cmd.fill %c0_i8, %arg6[%c0 for %22] : i8 -> !stream.resource<transient>{%22}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %22, %23 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%24: index, %25: !stream.resource<transient>, %26: index, %27: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %28 = arith.cmpi slt, %24, %20 : index
    cf.cond_br %28, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %29 = arith.muli %24, %19 : index
    %30 = arith.muli %0, %19 overflow<nsw> : index
    %31 = arith.muli %30, %c4 : index
    %32 = arith.muli %0, %7 overflow<nsw> : index
    %33 = arith.muli %32, %19 overflow<nsw> : index
    %34 = arith.muli %33, %c4 : index
    %35 = util.align %31, %c64 : index
    %36 = util.align %34, %c64 : index
    %37 = arith.addi %35, %36 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%37} => !stream.timepoint
    %38 = arith.index_castui %30 : index to i64
    %39 = arith.index_castui %30 : index to i32
    %40 = arith.shrui %38, %c32_i64 : i64
    %41 = arith.trunci %40 : i64 to i32
    %42 = arith.index_castui %19 : index to i64
    %43 = arith.index_castui %19 : index to i32
    %44 = arith.shrui %42, %c32_i64 : i64
    %45 = arith.trunci %44 : i64 to i32
    %46 = arith.index_castui %29 : index to i64
    %47 = arith.index_castui %29 : index to i32
    %48 = arith.shrui %46, %c32_i64 : i64
    %49 = arith.trunci %48 : i64 to i32
    %50 = arith.index_castui %0 : index to i64
    %51 = arith.index_castui %0 : index to i32
    %52 = arith.shrui %50, %c32_i64 : i64
    %53 = arith.trunci %52 : i64 to i32
    %54 = arith.index_castui %1 : index to i64
    %55 = arith.index_castui %1 : index to i32
    %56 = arith.shrui %54, %c32_i64 : i64
    %57 = arith.trunci %56 : i64 to i32
    %58 = arith.index_castui %35 : index to i64
    %59 = arith.index_castui %35 : index to i32
    %60 = arith.shrui %58, %c32_i64 : i64
    %61 = arith.trunci %60 : i64 to i32
    %62 = arith.index_castui %33 : index to i64
    %63 = arith.index_castui %33 : index to i32
    %64 = arith.shrui %62, %c32_i64 : i64
    %65 = arith.trunci %64 : i64 to i32
    %66 = arith.index_castui %6 : index to i64
    %67 = arith.index_castui %6 : index to i32
    %68 = arith.shrui %66, %c32_i64 : i64
    %69 = arith.trunci %68 : i64 to i32
    %70 = arith.index_castui %7 : index to i64
    %71 = arith.index_castui %7 : index to i32
    %72 = arith.shrui %70, %c32_i64 : i64
    %73 = arith.trunci %72 : i64 to i32
    %74 = arith.index_castui %8 : index to i64
    %75 = arith.index_castui %8 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg6: !stream.resource<external>{%3}, %12 as %arg7: !stream.resource<external>{%11}, %result_0 as %arg8: !stream.resource<transient>{%37}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_0::@vulkan_spirv_fb::@affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32[%30, %19, %29, %0, %1](%39, %41, %43, %45, %47, %49, %51, %53, %55, %57 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
      stream.cmd.dispatch @mx4_linear_f32_dispatch_1::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_1_elementwise_broadcast_D_f32[%33, %19, %29, %6, %7, %8](%59, %61, %63, %65, %43, %45, %47, %49, %67, %69, %71, %73, %75, %77 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
    } => !stream.timepoint
    %79 = arith.muli %22, %19 : index
    %80 = stream.timepoint.await %78 => %result_0 : !stream.resource<transient>{%37}
    %81 = stream.resource.subview %80[%c0] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%31}
    %82 = stream.resource.subview %80[%35] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%34}
    %83 = util.optimization_barrier %81 : !stream.resource<transient>
    %84 = util.optimization_barrier %82 : !stream.resource<transient>
    %85 = arith.muli %21, %19 : index
    %86 = arith.muli %32, %c2 : index
    %87 = util.align %22, %c64 : index
    %88 = util.align %86, %c64 : index
    %89 = arith.addi %87, %88 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%89} => !stream.timepoint
    %90 = arith.index_castui %87 : index to i64
    %91 = arith.index_castui %87 : index to i32
    %92 = arith.shrui %90, %c32_i64 : i64
    %93 = arith.trunci %92 : i64 to i32
    %94 = arith.index_castui %32 : index to i64
    %95 = arith.index_castui %32 : index to i32
    %96 = arith.shrui %94, %c32_i64 : i64
    %97 = arith.trunci %96 : i64 to i32
    %98 = arith.index_castui %24 : index to i64
    %99 = arith.index_castui %24 : index to i32
    %100 = arith.shrui %98, %c32_i64 : i64
    %101 = arith.trunci %100 : i64 to i32
    %102 = arith.index_castui %13 : index to i64
    %103 = arith.index_castui %13 : index to i32
    %104 = arith.shrui %102, %c32_i64 : i64
    %105 = arith.trunci %104 : i64 to i32
    %106 = arith.index_castui %14 : index to i64
    %107 = arith.index_castui %14 : index to i32
    %108 = arith.shrui %106, %c32_i64 : i64
    %109 = arith.trunci %108 : i64 to i32
    %110 = arith.index_castui %15 : index to i64
    %111 = arith.index_castui %15 : index to i32
    %112 = arith.shrui %110, %c32_i64 : i64
    %113 = arith.trunci %112 : i64 to i32
    %114 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%83 as %arg6: !stream.resource<transient>{%85}, %84 as %arg7: !stream.resource<transient>{%79}, %18 as %arg8: !stream.resource<external>{%17}, %result_2 as %arg9: !stream.resource<transient>{%89}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %19, %7](%51, %53, %43, %45, %71, %73 : i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %85] : !stream.resource<transient>{%85},
        ro %arg7[%c0 for %79] : !stream.resource<transient>{%79},
        wo %arg9[%c0 for %89] : !stream.resource<transient>{%89}
      }
      stream.cmd.dispatch @mx4_linear_f16_dispatch_3::@vulkan_spirv_fb::@mx4_linear_f16_dispatch_3_elementwise_broadcast_D_f16[%32, %7, %24, %13, %14, %15](%91, %93, %95, %97, %71, %73, %99, %101, %103, %105, %107, %109, %111, %113 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg9[%c0 for %89] : !stream.resource<transient>{%89}
      }
    } => !stream.timepoint
    %115 = arith.muli %2, %7 : index
    %116 = stream.timepoint.await %114 => %result_2 : !stream.resource<transient>{%89}
    %117 = stream.resource.subview %116[%87] : !stream.resource<transient>{%89} -> !stream.resource<transient>{%86}
    %118 = util.optimization_barrier %117 : !stream.resource<transient>
    %119 = arith.muli %32, %c4 : index
    %120 = stream.timepoint.join max(%114, %27) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%120) => !stream.resource<transient>{%119} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%120) => !stream.resource<transient>{%87} => !stream.timepoint
    %121 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %122 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%121) => with(%25 as %arg6: !stream.resource<transient>{%26}, %result_2 as %arg7: !stream.resource<transient>{%89}, %118 as %arg8: !stream.resource<transient>{%115}, %result_4 as %arg9: !stream.resource<transient>{%119}, %result_6 as %arg10: !stream.resource<transient>{%87}) {
      stream.cmd.copy %arg6[%c0], %arg10[%c0], %22 : !stream.resource<transient>{%22} -> !stream.resource<transient>{%87}
      stream.cmd.dispatch @mx4_linear_f16_dispatch_4::@vulkan_spirv_fb::@mx4_linear_f16_dispatch_4_elementwise_broadcast_D_f32[%32, %0, %7](%95, %97, %51, %53, %71, %73 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %89] : !stream.resource<transient>{%89},
        ro %arg10[%c0 for %87] : !stream.resource<transient>{%87},
        ro %arg8[%c0 for %115] : !stream.resource<transient>{%115},
        wo %arg9[%c0 for %119] : !stream.resource<transient>{%119}
      }
    } => !stream.timepoint
    %123 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%122) => %result_6 : !stream.resource<transient>{%87} => !stream.timepoint
    %124 = arith.addi %24, %c1 : index
    cf.br ^bb1(%124, %result_4, %119, %123 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %125 = arith.muli %0, %7 overflow<nsw> : index
    %126 = arith.muli %125, %c2 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%27) => !stream.resource<external>{%126} => !stream.timepoint
    %127 = arith.index_castui %125 : index to i64
    %128 = arith.index_castui %125 : index to i32
    %129 = arith.shrui %127, %c32_i64 : i64
    %130 = arith.trunci %129 : i64 to i32
    %131 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_9) => with(%25 as %arg6: !stream.resource<transient>{%26}, %result_8 as %arg7: !stream.resource<external>{%126}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_4::@vulkan_spirv_fb::@affine_linear_f16_dispatch_4_elementwise_D_f32xf16[%125](%128, %130 : i32, i32) {
        ro %arg6[%c0 for %26] : !stream.resource<transient>{%26},
        wo %arg7[%c0 for %126] : !stream.resource<external>{%126}
      }
    } => !stream.timepoint
    %132 = stream.resource.dealloca origin await(%131) => %25 : !stream.resource<transient>{%26} => !stream.timepoint
    %133 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %132 => (%arg5 : !hal.fence)
    %134 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_8 : tensor<?x?xf16>{%0, %7} in !stream.resource<external>{%133} -> !hal.buffer_view
    util.return %134 : !hal.buffer_view
  }
  hal.executable private @mx4_grouped_f16_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_grouped_f16_dispatch_3_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_grouped_f16_dispatch_3_elementwise_broadcast_D_f16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c23_i32 = arith.constant 23 : i32
          %c4194304_i32 = arith.constant 4194304 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 {stream.alignment = 64 : index} : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:5 = util.assume.int 
              %30<umin = 0, umax = 9007199254740991>, 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %25, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 3 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 4 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 5 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#4, 6 : index
          %62 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58}
          %63 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%59, %60, %61}
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%20) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%57}
          %65 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 1 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %35, 2 : index
          %67 = iree_tensor_ext.dispatch.tensor.load %62, offsets = [0], sizes = [%58], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58} -> tensor<?xi32>
          %68 = iree_tensor_ext.dispatch.tensor.load %63, offsets = [0, 0, 0], sizes = [%59, %60, %61], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%59, %60, %61} -> tensor<?x?x?xi8>
          %69 = tensor.empty(%57) : tensor<?xf16>
          %70 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%69 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %71 = linalg.index 0 : index
            %72 = arith.remsi %71, %65 : index
            %73 = arith.divsi %71, %65 : index
            %extracted = tensor.extract %67[%73] : tensor<?xi32>
            %74 = arith.index_cast %extracted : i32 to index
            %extracted_0 = tensor.extract %68[%74, %72, %66] : tensor<?x?x?xi8>
            %75 = arith.extui %extracted_0 : i8 to i32
            %76 = arith.shli %75, %c23_i32 : i32
            %77 = arith.cmpi eq, %75, %c0_i32 : i32
            %78 = arith.select %77, %c4194304_i32, %76 : i32
            %79 = arith.bitcast %78 : i32 to f32
            %80 = arith.truncf %79 : f32 to f16
            linalg.yield %80 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %70, %64, offsets = [0], sizes = [%57], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%57}
          return
        }
        iree_codegen.dispatch_config @mx4_grouped_f16_dispatch_3_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @mx4_grouped_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: !hal.fence, %arg6: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx4_grouped_f16(%input0: tensor<?x?xf16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: tensor<?xi32>, %input4: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg5 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%19]) type(%element_type_i32) encoding(%dense_row_major)
    %20 = arith.muli %19, %c4 : index
    %21 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%19} in !stream.resource<external>{%20}
    %22 = arith.index_cast %arg4 : i32 to index
    %23 = arith.divui %1, %22 : index
    %24 = arith.muli %0, %c4 : index
    %25 = arith.muli %24, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%25} => !stream.timepoint
    %26 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg7: !stream.resource<transient>{%25}) {
      stream.cmd.fill %c0_i8, %arg7[%c0 for %25] : i8 -> !stream.resource<transient>{%25}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %26 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%27: index, %28: !stream.resource<transient>, %29: index, %30: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %31 = arith.cmpi slt, %27, %23 : index
    cf.cond_br %31, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %32 = arith.muli %27, %22 : index
    %33 = arith.muli %0, %22 overflow<nsw> : index
    %34 = arith.muli %33, %c4 : index
    %35 = arith.muli %0, %7 overflow<nsw> : index
    %36 = arith.muli %35, %22 overflow<nsw> : index
    %37 = arith.muli %36, %c4 : index
    %38 = util.align %34, %c64 : index
    %39 = util.align %37, %c64 : index
    %40 = arith.addi %38, %39 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%40} => !stream.timepoint
    %41 = arith.index_castui %33 : index to i64
    %42 = arith.index_castui %33 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = arith.index_castui %22 : index to i64
    %46 = arith.index_castui %22 : index to i32
    %47 = arith.shrui %45, %c32_i64 : i64
    %48 = arith.trunci %47 : i64 to i32
    %49 = arith.index_castui %32 : index to i64
    %50 = arith.index_castui %32 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %0 : index to i64
    %54 = arith.index_castui %0 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %1 : index to i64
    %58 = arith.index_castui %1 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = arith.index_castui %38 : index to i64
    %62 = arith.index_castui %38 : index to i32
    %63 = arith.shrui %61, %c32_i64 : i64
    %64 = arith.trunci %63 : i64 to i32
    %65 = arith.index_castui %36 : index to i64
    %66 = arith.index_castui %36 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %19 : index to i64
    %70 = arith.index_castui %19 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = arith.index_castui %6 : index to i64
    %74 = arith.index_castui %6 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = arith.index_castui %7 : index to i64
    %78 = arith.index_castui %7 : index to i32
    %79 = arith.shrui %77, %c32_i64 : i64
    %80 = arith.trunci %79 : i64 to i32
    %81 = arith.index_castui %8 : index to i64
    %82 = arith.index_castui %8 : index to i32
    %83 = arith.shrui %81, %c32_i64 : i64
    %84 = arith.trunci %83 : i64 to i32
    %85 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg7: !stream.resource<external>{%3}, %21 as %arg8: !stream.resource<external>{%20}, %12 as %arg9: !stream.resource<external>{%11}, %result_0 as %arg10: !stream.resource<transient>{%40}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_0::@vulkan_spirv_fb::@affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32[%33, %22, %32, %0, %1](%42, %44, %46, %48, %50, %52, %54, %56, %58, %60 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg10[%c0 for %40] : !stream.resource<transient>{%40}
      }
      stream.cmd.dispatch @mx4_grouped_f32_dispatch_1::@vulkan_spirv_fb::@mx4_grouped_f32_dispatch_1_elementwise_broadcast_D_f32[%36, %22, %32, %19, %6, %7, %8](%62, %64, %66, %68, %46, %48, %50, %52, %70, %72, %74, %76, %78, %80, %82, %84 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg10[%c0 for %40] : !stream.resource<transient>{%40}
      }
    } => !stream.timepoint
    %86 = arith.muli %25, %22 : index
    %87 = stream.timepoint.await %85 => %result_0 : !stream.resource<transient>{%40}
    %88 = stream.resource.subview %87[%c0] : !stream.resource<transient>{%40} -> !stream.resource<transient>{%34}
    %89 = stream.resource.subview %87[%38] : !stream.resource<transient>{%40} -> !stream.resource<transient>{%37}
    %90 = util.optimization_barrier %88 : !stream.resource<transient>
    %91 = util.optimization_barrier %89 : !stream.resource<transient>
    %92 = arith.muli %24, %22 : index
    %93 = arith.muli %35, %c2 : index
    %94 = util.align %25, %c64 : index
    %95 = util.align %93, %c64 : index
    %96 = arith.addi %94, %95 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%96} => !stream.timepoint
    %97 = arith.index_castui %94 : index to i64
    %98 = arith.index_castui %94 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %35 : index to i64
    %102 = arith.index_castui %35 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %27 : index to i64
    %106 = arith.index_castui %27 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %13 : index to i64
    %110 = arith.index_castui %13 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %14 : index to i64
    %114 = arith.index_castui %14 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %15 : index to i64
    %118 = arith.index_castui %15 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%90 as %arg7: !stream.resource<transient>{%92}, %91 as %arg8: !stream.resource<transient>{%86}, %21 as %arg9: !stream.resource<external>{%20}, %18 as %arg10: !stream.resource<external>{%17}, %result_2 as %arg11: !stream.resource<transient>{%96}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %22, %7](%54, %56, %46, %48, %78, %80 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %92] : !stream.resource<transient>{%92},
        ro %arg8[%c0 for %86] : !stream.resource<transient>{%86},
        wo %arg11[%c0 for %96] : !stream.resource<transient>{%96}
      }
      stream.cmd.dispatch @mx4_grouped_f16_dispatch_3::@vulkan_spirv_fb::@mx4_grouped_f16_dispatch_3_elementwise_broadcast_D_f16[%35, %7, %27, %19, %13, %14, %15](%98, %100, %102, %104, %78, %80, %106, %108, %70, %72, %110, %112, %114, %116, %118, %120 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg11[%c0 for %96] : !stream.resource<transient>{%96}
      }
    } => !stream.timepoint
    %122 = arith.muli %2, %7 : index
    %123 = stream.timepoint.await %121 => %result_2 : !stream.resource<transient>{%96}
    %124 = stream.resource.subview %123[%94] : !stream.resource<transient>{%96} -> !stream.resource<transient>{%93}
    %125 = util.optimization_barrier %124 : !stream.resource<transient>
    %126 = arith.muli %35, %c4 : index
    %127 = stream.timepoint.join max(%121, %30) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%127) => !stream.resource<transient>{%126} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%127) => !stream.resource<transient>{%94} => !stream.timepoint
    %128 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %129 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%128) => with(%28 as %arg7: !stream.resource<transient>{%29}, %result_2 as %arg8: !stream.resource<transient>{%96}, %125 as %arg9: !stream.resource<transient>{%122}, %result_4 as %arg10: !stream.resource<transient>{%126}, %result_6 as %arg11: !stream.resource<transient>{%94}) {
      stream.cmd.copy %arg7[%c0], %arg11[%c0], %25 : !stream.resource<transient>{%25} -> !stream.resource<transient>{%94}
      stream.cmd.dispatch @mx4_linear_f16_dispatch_4::@vulkan_spirv_fb::@mx4_linear_f16_dispatch_4_elementwise_broadcast_D_f32[%35, %0, %7](%102, %104, %54, %56, %78, %80 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %96] : !stream.resource<transient>{%96},
        ro %arg11[%c0 for %94] : !stream.resource<transient>{%94},
        ro %arg9[%c0 for %122] : !stream.resource<transient>{%122},
        wo %arg10[%c0 for %126] : !stream.resource<transient>{%126}
      }
    } => !stream.timepoint
    %130 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%129) => %result_6 : !stream.resource<transient>{%94} => !stream.timepoint
    %131 = arith.addi %27, %c1 : index
    cf.br ^bb1(%131, %result_4, %126, %130 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %132 = arith.muli %0, %7 overflow<nsw> : index
    %133 = arith.muli %132, %c2 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%30) => !stream.resource<external>{%133} => !stream.timepoint
    %134 = arith.index_castui %132 : index to i64
    %135 = arith.index_castui %132 : index to i32
    %136 = arith.shrui %134, %c32_i64 : i64
    %137 = arith.trunci %136 : i64 to i32
    %138 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_9) => with(%28 as %arg7: !stream.resource<transient>{%29}, %result_8 as %arg8: !stream.resource<external>{%133}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_4::@vulkan_spirv_fb::@affine_linear_f16_dispatch_4_elementwise_D_f32xf16[%132](%135, %137 : i32, i32) {
        ro %arg7[%c0 for %29] : !stream.resource<transient>{%29},
        wo %arg8[%c0 for %133] : !stream.resource<external>{%133}
      }
    } => !stream.timepoint
    %139 = stream.resource.dealloca origin await(%138) => %28 : !stream.resource<transient>{%29} => !stream.timepoint
    %140 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %139 => (%arg6 : !hal.fence)
    %141 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_8 : tensor<?x?xf16>{%0, %7} in !stream.resource<external>{%140} -> !hal.buffer_view
    util.return %141 : !hal.buffer_view
  }
  hal.executable private @mx4_linear_bf16_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_linear_bf16_dispatch_3_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_linear_bf16_dispatch_3_elementwise_broadcast_D_i16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %c23_i32 = arith.constant 23 : i32
          %c4194304_i32 = arith.constant 4194304 : i32
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 {stream.alignment = 64 : index} : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:4 = util.assume.int 
              %28<umin = 0, umax = 9007199254740991>, 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#3, 5 : index
          %54 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%51, %52, %53}
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%18) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%50}
          %56 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 1 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %58 = iree_tensor_ext.dispatch.tensor.load %54, offsets = [0, 0, 0], sizes = [%51, %52, %53], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%51, %52, %53} -> tensor<?x?x?xi8>
          %59 = tensor.empty(%50) : tensor<?xi16>
          %60 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%59 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %61 = linalg.index 0 : index
            %62 = arith.remsi %61, %56 : index
            %extracted = tensor.extract %58[%c0, %62, %57] : tensor<?x?x?xi8>
            %63 = arith.extui %extracted : i8 to i32
            %64 = arith.shli %63, %c23_i32 : i32
            %65 = arith.cmpi eq, %63, %c0_i32 : i32
            %66 = arith.select %65, %c4194304_i32, %64 : i32
            %67 = arith.bitcast %66 : i32 to f32
            %68 = arith.truncf %67 : f32 to bf16
            %69 = arith.bitcast %68 : bf16 to i16
            linalg.yield %69 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %60, %55, offsets = [0], sizes = [%50], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%50}
          return
        }
        iree_codegen.dispatch_config @mx4_linear_bf16_dispatch_3_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @mx4_linear_bf16_dispatch_4 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_linear_bf16_dispatch_4_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_linear_bf16_dispatch_4_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = arith.extui %1 : i32 to i64
          %7 = arith.shli %6, %c32_i64 : i64
          %8 = arith.extui %0 : i32 to i64
          %9 = arith.ori %8, %7 : i64
          %10 = arith.index_castui %9 : i64 to index
          %11 = arith.extui %3 : i32 to i64
          %12 = arith.shli %11, %c32_i64 : i64
          %13 = arith.extui %2 : i32 to i64
          %14 = arith.ori %13, %12 : i64
          %15 = arith.index_castui %14 : i64 to index
          %16 = arith.extui %5 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %4 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 : i64 to index
          %21:2 = util.assume.int 
              %15<umin = 0, umax = 9007199254740991>, 
              %20<umin = 0, umax = 9007199254740991>
            : index, index
          %22 = iree_tensor_ext.dispatch.workload.ordinal %10, 0 : index
          %23 = iree_tensor_ext.dispatch.workload.ordinal %21#0, 1 : index
          %24 = iree_tensor_ext.dispatch.workload.ordinal %21#1, 2 : index
          %25 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24}
          %26 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24}
          %27 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%23, %24}
          %28 = hal.interface.binding.subspan layout(<constants = 6, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%22}
          %29 = iree_tensor_ext.dispatch.tensor.load %25, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24} -> tensor<?x?xf32>
          %30 = iree_tensor_ext.dispatch.tensor.load %26, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%23, %24} -> tensor<?x?xf32>
          %31 = iree_tensor_ext.dispatch.tensor.load %27, offsets = [0, 0], sizes = [%23, %24], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%23, %24} -> tensor<?x?xi16>
          %32 = tensor.empty(%22) : tensor<?xf32>
          %33 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%32 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %34 = linalg.index 0 : index
            %35 = arith.remsi %34, %24 : index
            %36 = arith.divsi %34, %24 : index
            %extracted = tensor.extract %29[%36, %35] : tensor<?x?xf32>
            %extracted_0 = tensor.extract %30[%36, %35] : tensor<?x?xf32>
            %extracted_1 = tensor.extract %31[%36, %35] : tensor<?x?xi16>
            %37 = arith.bitcast %extracted_1 : i16 to bf16
            %38 = arith.extf %37 : bf16 to f32
            %39 = arith.mulf %extracted, %38 : f32
            %40 = arith.addf %extracted_0, %39 : f32
            linalg.yield %40 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %33, %28, offsets = [0], sizes = [%22], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%22}
          return
        }
        iree_codegen.dispatch_config @mx4_linear_bf16_dispatch_4_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @mx4_linear_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx4_linear_bf16(%input0: tensor<?x?xi16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg3 : i32 to index
    %20 = arith.divui %1, %19 : index
    %21 = arith.muli %0, %c4 : index
    %22 = arith.muli %21, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%22} => !stream.timepoint
    %23 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg6: !stream.resource<transient>{%22}) {
      stream.cmd.fill %c0_i8, %arg6[%c0 for %22] : i8 -> !stream.resource<transient>{%22}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %22, %23 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%24: index, %25: !stream.resource<transient>, %26: index, %27: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %28 = arith.cmpi slt, %24, %20 : index
    cf.cond_br %28, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %29 = arith.muli %24, %19 : index
    %30 = arith.muli %0, %19 overflow<nsw> : index
    %31 = arith.muli %30, %c4 : index
    %32 = arith.muli %0, %7 overflow<nsw> : index
    %33 = arith.muli %32, %19 overflow<nsw> : index
    %34 = arith.muli %33, %c4 : index
    %35 = util.align %31, %c64 : index
    %36 = util.align %34, %c64 : index
    %37 = arith.addi %35, %36 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%37} => !stream.timepoint
    %38 = arith.index_castui %30 : index to i64
    %39 = arith.index_castui %30 : index to i32
    %40 = arith.shrui %38, %c32_i64 : i64
    %41 = arith.trunci %40 : i64 to i32
    %42 = arith.index_castui %19 : index to i64
    %43 = arith.index_castui %19 : index to i32
    %44 = arith.shrui %42, %c32_i64 : i64
    %45 = arith.trunci %44 : i64 to i32
    %46 = arith.index_castui %29 : index to i64
    %47 = arith.index_castui %29 : index to i32
    %48 = arith.shrui %46, %c32_i64 : i64
    %49 = arith.trunci %48 : i64 to i32
    %50 = arith.index_castui %0 : index to i64
    %51 = arith.index_castui %0 : index to i32
    %52 = arith.shrui %50, %c32_i64 : i64
    %53 = arith.trunci %52 : i64 to i32
    %54 = arith.index_castui %1 : index to i64
    %55 = arith.index_castui %1 : index to i32
    %56 = arith.shrui %54, %c32_i64 : i64
    %57 = arith.trunci %56 : i64 to i32
    %58 = arith.index_castui %35 : index to i64
    %59 = arith.index_castui %35 : index to i32
    %60 = arith.shrui %58, %c32_i64 : i64
    %61 = arith.trunci %60 : i64 to i32
    %62 = arith.index_castui %33 : index to i64
    %63 = arith.index_castui %33 : index to i32
    %64 = arith.shrui %62, %c32_i64 : i64
    %65 = arith.trunci %64 : i64 to i32
    %66 = arith.index_castui %6 : index to i64
    %67 = arith.index_castui %6 : index to i32
    %68 = arith.shrui %66, %c32_i64 : i64
    %69 = arith.trunci %68 : i64 to i32
    %70 = arith.index_castui %7 : index to i64
    %71 = arith.index_castui %7 : index to i32
    %72 = arith.shrui %70, %c32_i64 : i64
    %73 = arith.trunci %72 : i64 to i32
    %74 = arith.index_castui %8 : index to i64
    %75 = arith.index_castui %8 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg6: !stream.resource<external>{%3}, %12 as %arg7: !stream.resource<external>{%11}, %result_0 as %arg8: !stream.resource<transient>{%37}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_0::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32[%30, %19, %29, %0, %1](%39, %41, %43, %45, %47, %49, %51, %53, %55, %57 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
      stream.cmd.dispatch @mx4_linear_f32_dispatch_1::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_1_elementwise_broadcast_D_f32[%33, %19, %29, %6, %7, %8](%59, %61, %63, %65, %43, %45, %47, %49, %67, %69, %71, %73, %75, %77 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
    } => !stream.timepoint
    %79 = arith.muli %22, %19 : index
    %80 = stream.timepoint.await %78 => %result_0 : !stream.resource<transient>{%37}
    %81 = stream.resource.subview %80[%c0] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%31}
    %82 = stream.resource.subview %80[%35] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%34}
    %83 = util.optimization_barrier %81 : !stream.resource<transient>
    %84 = util.optimization_barrier %82 : !stream.resource<transient>
    %85 = arith.muli %21, %19 : index
    %86 = arith.muli %32, %c2 : index
    %87 = util.align %22, %c64 : index
    %88 = util.align %86, %c64 : index
    %89 = arith.addi %87, %88 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%89} => !stream.timepoint
    %90 = arith.index_castui %87 : index to i64
    %91 = arith.index_castui %87 : index to i32
    %92 = arith.shrui %90, %c32_i64 : i64
    %93 = arith.trunci %92 : i64 to i32
    %94 = arith.index_castui %32 : index to i64
    %95 = arith.index_castui %32 : index to i32
    %96 = arith.shrui %94, %c32_i64 : i64
    %97 = arith.trunci %96 : i64 to i32
    %98 = arith.index_castui %24 : index to i64
    %99 = arith.index_castui %24 : index to i32
    %100 = arith.shrui %98, %c32_i64 : i64
    %101 = arith.trunci %100 : i64 to i32
    %102 = arith.index_castui %13 : index to i64
    %103 = arith.index_castui %13 : index to i32
    %104 = arith.shrui %102, %c32_i64 : i64
    %105 = arith.trunci %104 : i64 to i32
    %106 = arith.index_castui %14 : index to i64
    %107 = arith.index_castui %14 : index to i32
    %108 = arith.shrui %106, %c32_i64 : i64
    %109 = arith.trunci %108 : i64 to i32
    %110 = arith.index_castui %15 : index to i64
    %111 = arith.index_castui %15 : index to i32
    %112 = arith.shrui %110, %c32_i64 : i64
    %113 = arith.trunci %112 : i64 to i32
    %114 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%83 as %arg6: !stream.resource<transient>{%85}, %84 as %arg7: !stream.resource<transient>{%79}, %18 as %arg8: !stream.resource<external>{%17}, %result_2 as %arg9: !stream.resource<transient>{%89}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %19, %7](%51, %53, %43, %45, %71, %73 : i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %85] : !stream.resource<transient>{%85},
        ro %arg7[%c0 for %79] : !stream.resource<transient>{%79},
        wo %arg9[%c0 for %89] : !stream.resource<transient>{%89}
      }
      stream.cmd.dispatch @mx4_linear_bf16_dispatch_3::@vulkan_spirv_fb::@mx4_linear_bf16_dispatch_3_elementwise_broadcast_D_i16[%32, %7, %24, %13, %14, %15](%91, %93, %95, %97, %71, %73, %99, %101, %103, %105, %107, %109, %111, %113 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg9[%c0 for %89] : !stream.resource<transient>{%89}
      }
    } => !stream.timepoint
    %115 = arith.muli %2, %7 : index
    %116 = stream.timepoint.await %114 => %result_2 : !stream.resource<transient>{%89}
    %117 = stream.resource.subview %116[%87] : !stream.resource<transient>{%89} -> !stream.resource<transient>{%86}
    %118 = util.optimization_barrier %117 : !stream.resource<transient>
    %119 = arith.muli %32, %c4 : index
    %120 = stream.timepoint.join max(%114, %27) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%120) => !stream.resource<transient>{%119} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%120) => !stream.resource<transient>{%87} => !stream.timepoint
    %121 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %122 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%121) => with(%25 as %arg6: !stream.resource<transient>{%26}, %result_2 as %arg7: !stream.resource<transient>{%89}, %118 as %arg8: !stream.resource<transient>{%115}, %result_4 as %arg9: !stream.resource<transient>{%119}, %result_6 as %arg10: !stream.resource<transient>{%87}) {
      stream.cmd.copy %arg6[%c0], %arg10[%c0], %22 : !stream.resource<transient>{%22} -> !stream.resource<transient>{%87}
      stream.cmd.dispatch @mx4_linear_bf16_dispatch_4::@vulkan_spirv_fb::@mx4_linear_bf16_dispatch_4_elementwise_broadcast_D_f32[%32, %0, %7](%95, %97, %51, %53, %71, %73 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %89] : !stream.resource<transient>{%89},
        ro %arg10[%c0 for %87] : !stream.resource<transient>{%87},
        ro %arg8[%c0 for %115] : !stream.resource<transient>{%115},
        wo %arg9[%c0 for %119] : !stream.resource<transient>{%119}
      }
    } => !stream.timepoint
    %123 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%122) => %result_6 : !stream.resource<transient>{%87} => !stream.timepoint
    %124 = arith.addi %24, %c1 : index
    cf.br ^bb1(%124, %result_4, %119, %123 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %125 = arith.muli %0, %7 overflow<nsw> : index
    %126 = arith.muli %125, %c2 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%27) => !stream.resource<external>{%126} => !stream.timepoint
    %127 = arith.index_castui %125 : index to i64
    %128 = arith.index_castui %125 : index to i32
    %129 = arith.shrui %127, %c32_i64 : i64
    %130 = arith.trunci %129 : i64 to i32
    %131 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_9) => with(%25 as %arg6: !stream.resource<transient>{%26}, %result_8 as %arg7: !stream.resource<external>{%126}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_4::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_4_elementwise_D_f32xi16[%125](%128, %130 : i32, i32) {
        ro %arg6[%c0 for %26] : !stream.resource<transient>{%26},
        wo %arg7[%c0 for %126] : !stream.resource<external>{%126}
      }
    } => !stream.timepoint
    %132 = stream.resource.dealloca origin await(%131) => %25 : !stream.resource<transient>{%26} => !stream.timepoint
    %133 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %132 => (%arg5 : !hal.fence)
    %134 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_8 : tensor<?x?xi16>{%0, %7} in !stream.resource<external>{%133} -> !hal.buffer_view
    util.return %134 : !hal.buffer_view
  }
  hal.executable private @mx4_grouped_bf16_dispatch_3 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c23_i32 = arith.constant 23 : i32
          %c4194304_i32 = arith.constant 4194304 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 {stream.alignment = 64 : index} : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:5 = util.assume.int 
              %30<umin = 0, umax = 9007199254740991>, 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %25, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 3 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 4 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 5 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#4, 6 : index
          %62 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58}
          %63 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%59, %60, %61}
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%20) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%57}
          %65 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 1 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %35, 2 : index
          %67 = iree_tensor_ext.dispatch.tensor.load %62, offsets = [0], sizes = [%58], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58} -> tensor<?xi32>
          %68 = iree_tensor_ext.dispatch.tensor.load %63, offsets = [0, 0, 0], sizes = [%59, %60, %61], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi8>>{%59, %60, %61} -> tensor<?x?x?xi8>
          %69 = tensor.empty(%57) : tensor<?xi16>
          %70 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%69 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %71 = linalg.index 0 : index
            %72 = arith.remsi %71, %65 : index
            %73 = arith.divsi %71, %65 : index
            %extracted = tensor.extract %67[%73] : tensor<?xi32>
            %74 = arith.index_cast %extracted : i32 to index
            %extracted_0 = tensor.extract %68[%74, %72, %66] : tensor<?x?x?xi8>
            %75 = arith.extui %extracted_0 : i8 to i32
            %76 = arith.shli %75, %c23_i32 : i32
            %77 = arith.cmpi eq, %75, %c0_i32 : i32
            %78 = arith.select %77, %c4194304_i32, %76 : i32
            %79 = arith.bitcast %78 : i32 to f32
            %80 = arith.truncf %79 : f32 to bf16
            %81 = arith.bitcast %80 : bf16 to i16
            linalg.yield %81 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %70, %64, offsets = [0], sizes = [%57], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%57}
          return
        }
        iree_codegen.dispatch_config @mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @mx4_grouped_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: !hal.fence, %arg6: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx4_grouped_bf16(%input0: tensor<?x?xi16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: tensor<?xi32>, %input4: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg5 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%19]) type(%element_type_i32) encoding(%dense_row_major)
    %20 = arith.muli %19, %c4 : index
    %21 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%19} in !stream.resource<external>{%20}
    %22 = arith.index_cast %arg4 : i32 to index
    %23 = arith.divui %1, %22 : index
    %24 = arith.muli %0, %c4 : index
    %25 = arith.muli %24, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%25} => !stream.timepoint
    %26 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg7: !stream.resource<transient>{%25}) {
      stream.cmd.fill %c0_i8, %arg7[%c0 for %25] : i8 -> !stream.resource<transient>{%25}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %26 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%27: index, %28: !stream.resource<transient>, %29: index, %30: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %31 = arith.cmpi slt, %27, %23 : index
    cf.cond_br %31, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %32 = arith.muli %27, %22 : index
    %33 = arith.muli %0, %22 overflow<nsw> : index
    %34 = arith.muli %33, %c4 : index
    %35 = arith.muli %0, %7 overflow<nsw> : index
    %36 = arith.muli %35, %22 overflow<nsw> : index
    %37 = arith.muli %36, %c4 : index
    %38 = util.align %34, %c64 : index
    %39 = util.align %37, %c64 : index
    %40 = arith.addi %38, %39 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%40} => !stream.timepoint
    %41 = arith.index_castui %33 : index to i64
    %42 = arith.index_castui %33 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = arith.index_castui %22 : index to i64
    %46 = arith.index_castui %22 : index to i32
    %47 = arith.shrui %45, %c32_i64 : i64
    %48 = arith.trunci %47 : i64 to i32
    %49 = arith.index_castui %32 : index to i64
    %50 = arith.index_castui %32 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %0 : index to i64
    %54 = arith.index_castui %0 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %1 : index to i64
    %58 = arith.index_castui %1 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = arith.index_castui %38 : index to i64
    %62 = arith.index_castui %38 : index to i32
    %63 = arith.shrui %61, %c32_i64 : i64
    %64 = arith.trunci %63 : i64 to i32
    %65 = arith.index_castui %36 : index to i64
    %66 = arith.index_castui %36 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %19 : index to i64
    %70 = arith.index_castui %19 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = arith.index_castui %6 : index to i64
    %74 = arith.index_castui %6 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = arith.index_castui %7 : index to i64
    %78 = arith.index_castui %7 : index to i32
    %79 = arith.shrui %77, %c32_i64 : i64
    %80 = arith.trunci %79 : i64 to i32
    %81 = arith.index_castui %8 : index to i64
    %82 = arith.index_castui %8 : index to i32
    %83 = arith.shrui %81, %c32_i64 : i64
    %84 = arith.trunci %83 : i64 to i32
    %85 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg7: !stream.resource<external>{%3}, %21 as %arg8: !stream.resource<external>{%20}, %12 as %arg9: !stream.resource<external>{%11}, %result_0 as %arg10: !stream.resource<transient>{%40}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_0::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32[%33, %22, %32, %0, %1](%42, %44, %46, %48, %50, %52, %54, %56, %58, %60 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg10[%c0 for %40] : !stream.resource<transient>{%40}
      }
      stream.cmd.dispatch @mx4_grouped_f32_dispatch_1::@vulkan_spirv_fb::@mx4_grouped_f32_dispatch_1_elementwise_broadcast_D_f32[%36, %22, %32, %19, %6, %7, %8](%62, %64, %66, %68, %46, %48, %50, %52, %70, %72, %74, %76, %78, %80, %82, %84 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg10[%c0 for %40] : !stream.resource<transient>{%40}
      }
    } => !stream.timepoint
    %86 = arith.muli %25, %22 : index
    %87 = stream.timepoint.await %85 => %result_0 : !stream.resource<transient>{%40}
    %88 = stream.resource.subview %87[%c0] : !stream.resource<transient>{%40} -> !stream.resource<transient>{%34}
    %89 = stream.resource.subview %87[%38] : !stream.resource<transient>{%40} -> !stream.resource<transient>{%37}
    %90 = util.optimization_barrier %88 : !stream.resource<transient>
    %91 = util.optimization_barrier %89 : !stream.resource<transient>
    %92 = arith.muli %24, %22 : index
    %93 = arith.muli %35, %c2 : index
    %94 = util.align %25, %c64 : index
    %95 = util.align %93, %c64 : index
    %96 = arith.addi %94, %95 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%96} => !stream.timepoint
    %97 = arith.index_castui %94 : index to i64
    %98 = arith.index_castui %94 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %35 : index to i64
    %102 = arith.index_castui %35 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %27 : index to i64
    %106 = arith.index_castui %27 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %13 : index to i64
    %110 = arith.index_castui %13 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %14 : index to i64
    %114 = arith.index_castui %14 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %15 : index to i64
    %118 = arith.index_castui %15 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%90 as %arg7: !stream.resource<transient>{%92}, %91 as %arg8: !stream.resource<transient>{%86}, %21 as %arg9: !stream.resource<external>{%20}, %18 as %arg10: !stream.resource<external>{%17}, %result_2 as %arg11: !stream.resource<transient>{%96}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %22, %7](%54, %56, %46, %48, %78, %80 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %92] : !stream.resource<transient>{%92},
        ro %arg8[%c0 for %86] : !stream.resource<transient>{%86},
        wo %arg11[%c0 for %96] : !stream.resource<transient>{%96}
      }
      stream.cmd.dispatch @mx4_grouped_bf16_dispatch_3::@vulkan_spirv_fb::@mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16[%35, %7, %27, %19, %13, %14, %15](%98, %100, %102, %104, %78, %80, %106, %108, %70, %72, %110, %112, %114, %116, %118, %120 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg11[%c0 for %96] : !stream.resource<transient>{%96}
      }
    } => !stream.timepoint
    %122 = arith.muli %2, %7 : index
    %123 = stream.timepoint.await %121 => %result_2 : !stream.resource<transient>{%96}
    %124 = stream.resource.subview %123[%94] : !stream.resource<transient>{%96} -> !stream.resource<transient>{%93}
    %125 = util.optimization_barrier %124 : !stream.resource<transient>
    %126 = arith.muli %35, %c4 : index
    %127 = stream.timepoint.join max(%121, %30) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%127) => !stream.resource<transient>{%126} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%127) => !stream.resource<transient>{%94} => !stream.timepoint
    %128 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %129 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%128) => with(%28 as %arg7: !stream.resource<transient>{%29}, %result_2 as %arg8: !stream.resource<transient>{%96}, %125 as %arg9: !stream.resource<transient>{%122}, %result_4 as %arg10: !stream.resource<transient>{%126}, %result_6 as %arg11: !stream.resource<transient>{%94}) {
      stream.cmd.copy %arg7[%c0], %arg11[%c0], %25 : !stream.resource<transient>{%25} -> !stream.resource<transient>{%94}
      stream.cmd.dispatch @mx4_linear_bf16_dispatch_4::@vulkan_spirv_fb::@mx4_linear_bf16_dispatch_4_elementwise_broadcast_D_f32[%35, %0, %7](%102, %104, %54, %56, %78, %80 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %96] : !stream.resource<transient>{%96},
        ro %arg11[%c0 for %94] : !stream.resource<transient>{%94},
        ro %arg9[%c0 for %122] : !stream.resource<transient>{%122},
        wo %arg10[%c0 for %126] : !stream.resource<transient>{%126}
      }
    } => !stream.timepoint
    %130 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%129) => %result_6 : !stream.resource<transient>{%94} => !stream.timepoint
    %131 = arith.addi %27, %c1 : index
    cf.br ^bb1(%131, %result_4, %126, %130 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %132 = arith.muli %0, %7 overflow<nsw> : index
    %133 = arith.muli %132, %c2 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%30) => !stream.resource<external>{%133} => !stream.timepoint
    %134 = arith.index_castui %132 : index to i64
    %135 = arith.index_castui %132 : index to i32
    %136 = arith.shrui %134, %c32_i64 : i64
    %137 = arith.trunci %136 : i64 to i32
    %138 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_9) => with(%28 as %arg7: !stream.resource<transient>{%29}, %result_8 as %arg8: !stream.resource<external>{%133}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_4::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_4_elementwise_D_f32xi16[%132](%135, %137 : i32, i32) {
        ro %arg7[%c0 for %29] : !stream.resource<transient>{%29},
        wo %arg8[%c0 for %133] : !stream.resource<external>{%133}
      }
    } => !stream.timepoint
    %139 = stream.resource.dealloca origin await(%138) => %28 : !stream.resource<transient>{%29} => !stream.timepoint
    %140 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %139 => (%arg6 : !hal.fence)
    %141 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_8 : tensor<?x?xi16>{%0, %7} in !stream.resource<external>{%140} -> !hal.buffer_view
    util.return %141 : !hal.buffer_view
  }
  hal.executable private @mx8_linear_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %cst = arith.constant 0x7FC00000 : f32
          %c4 = arith.constant 4 : index
          %c8 = arith.constant 8 : index
          %c255_i32 = arith.constant 255 : i32
          %c127_i32 = arith.constant 127 : i32
          %0 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = arith.extui %1 : i32 to i64
          %15 = arith.shli %14, %c32_i64 : i64
          %16 = arith.extui %0 : i32 to i64
          %17 = arith.ori %16, %15 : i64
          %18 = arith.index_castui %17 {stream.alignment = 64 : index} : i64 to index
          %19 = arith.extui %3 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %2 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %5 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %4 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %7 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %6 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %9 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %8 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %11 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %10 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %13 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %12 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49:3 = util.assume.int 
              %38<umin = 0, umax = 9007199254740991>, 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>
            : index, index, index
          %50 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %51 = iree_tensor_ext.dispatch.workload.ordinal %49#0, 3 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %49#1, 4 : index
          %53 = iree_tensor_ext.dispatch.workload.ordinal %49#2, 5 : index
          %54 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%51, %52, %53}
          %55 = hal.interface.binding.subspan layout(<constants = 14, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%18) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          %56 = iree_tensor_ext.dispatch.workload.ordinal %28, 1 : index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %58 = iree_tensor_ext.dispatch.tensor.load %54, offsets = [0, 0, 0], sizes = [%51, %52, %53], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%51, %52, %53} -> tensor<?x?x?xi32>
          %59 = tensor.empty(%50) : tensor<?xf32>
          %60 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%59 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %61 = linalg.index 0 : index
            %62 = arith.remsi %61, %56 : index
            %63 = arith.divsi %61, %56 : index
            %64 = arith.remsi %63, %52 : index
            %65 = arith.addi %57, %62 : index
            %66 = arith.divui %65, %c4 : index
            %67 = arith.remui %65, %c4 : index
            %68 = arith.muli %67, %c8 : index
            %69 = arith.index_castui %68 : index to i32
            %extracted = tensor.extract %58[%c0, %64, %66] : tensor<?x?x?xi32>
            %70 = arith.shrui %extracted, %69 : i32
            %71 = arith.andi %70, %c255_i32 : i32
            %72 = arith.trunci %71 : i32 to i8
            %73 = arith.bitcast %72 : i8 to f8E4M3FN
            %74 = arith.extf %73 : f8E4M3FN to f32
            %75 = arith.andi %70, %c127_i32 : i32
            %76 = arith.cmpi eq, %75, %c127_i32 : i32
            %77 = arith.select %76, %cst, %74 : f32
            linalg.yield %77 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %60, %55, offsets = [0], sizes = [%50], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%50}
          return
        }
        iree_codegen.dispatch_config @mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @mx8_linear_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx8_linear_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg3 : i32 to index
    %20 = arith.divui %1, %19 : index
    %21 = arith.muli %2, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%21} => !stream.timepoint
    %22 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg6: !stream.resource<external>{%21}) {
      stream.cmd.fill %c0_i8, %arg6[%c0 for %21] : i8 -> !stream.resource<external>{%21}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %21, %22 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb1(%23: index, %24: !stream.resource<external>, %25: index, %26: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %27 = arith.cmpi slt, %23, %20 : index
    cf.cond_br %27, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %28 = arith.muli %23, %19 : index
    %29 = arith.muli %0, %19 overflow<nsw> : index
    %30 = arith.muli %29, %c4 : index
    %31 = arith.muli %0, %7 overflow<nsw> : index
    %32 = arith.muli %31, %19 overflow<nsw> : index
    %33 = arith.muli %32, %c4 : index
    %34 = util.align %30, %c64 : index
    %35 = util.align %33, %c64 : index
    %36 = arith.addi %34, %35 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%36} => !stream.timepoint
    %37 = arith.index_castui %29 : index to i64
    %38 = arith.index_castui %29 : index to i32
    %39 = arith.shrui %37, %c32_i64 : i64
    %40 = arith.trunci %39 : i64 to i32
    %41 = arith.index_castui %19 : index to i64
    %42 = arith.index_castui %19 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = arith.index_castui %28 : index to i64
    %46 = arith.index_castui %28 : index to i32
    %47 = arith.shrui %45, %c32_i64 : i64
    %48 = arith.trunci %47 : i64 to i32
    %49 = arith.index_castui %0 : index to i64
    %50 = arith.index_castui %0 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %1 : index to i64
    %54 = arith.index_castui %1 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %34 : index to i64
    %58 = arith.index_castui %34 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = arith.index_castui %32 : index to i64
    %62 = arith.index_castui %32 : index to i32
    %63 = arith.shrui %61, %c32_i64 : i64
    %64 = arith.trunci %63 : i64 to i32
    %65 = arith.index_castui %6 : index to i64
    %66 = arith.index_castui %6 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %7 : index to i64
    %70 = arith.index_castui %7 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = arith.index_castui %8 : index to i64
    %74 = arith.index_castui %8 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg6: !stream.resource<external>{%3}, %12 as %arg7: !stream.resource<external>{%11}, %result_0 as %arg8: !stream.resource<transient>{%36}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_0::@vulkan_spirv_fb::@affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32[%29, %19, %28, %0, %1](%38, %40, %42, %44, %46, %48, %50, %52, %54, %56 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg8[%c0 for %36] : !stream.resource<transient>{%36}
      }
      stream.cmd.dispatch @mx8_linear_f32_dispatch_1::@vulkan_spirv_fb::@mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32[%32, %19, %28, %6, %7, %8](%58, %60, %62, %64, %42, %44, %46, %48, %66, %68, %70, %72, %74, %76 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg8[%c0 for %36] : !stream.resource<transient>{%36}
      }
    } => !stream.timepoint
    %78 = arith.muli %21, %19 : index
    %79 = stream.timepoint.await %77 => %result_0 : !stream.resource<transient>{%36}
    %80 = stream.resource.subview %79[%c0] : !stream.resource<transient>{%36} -> !stream.resource<transient>{%30}
    %81 = stream.resource.subview %79[%34] : !stream.resource<transient>{%36} -> !stream.resource<transient>{%33}
    %82 = util.optimization_barrier %80 : !stream.resource<transient>
    %83 = util.optimization_barrier %81 : !stream.resource<transient>
    %84 = arith.muli %2, %19 : index
    %85 = arith.muli %31, %c4 : index
    %86 = util.align %21, %c64 : index
    %87 = util.align %85, %c64 : index
    %88 = arith.addi %86, %87 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%88} => !stream.timepoint
    %89 = arith.index_castui %86 : index to i64
    %90 = arith.index_castui %86 : index to i32
    %91 = arith.shrui %89, %c32_i64 : i64
    %92 = arith.trunci %91 : i64 to i32
    %93 = arith.index_castui %31 : index to i64
    %94 = arith.index_castui %31 : index to i32
    %95 = arith.shrui %93, %c32_i64 : i64
    %96 = arith.trunci %95 : i64 to i32
    %97 = arith.index_castui %23 : index to i64
    %98 = arith.index_castui %23 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %13 : index to i64
    %102 = arith.index_castui %13 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %14 : index to i64
    %106 = arith.index_castui %14 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %15 : index to i64
    %110 = arith.index_castui %15 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%82 as %arg6: !stream.resource<transient>{%84}, %83 as %arg7: !stream.resource<transient>{%78}, %18 as %arg8: !stream.resource<external>{%17}, %result_2 as %arg9: !stream.resource<transient>{%88}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %19, %7](%50, %52, %42, %44, %70, %72 : i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %84] : !stream.resource<transient>{%84},
        ro %arg7[%c0 for %78] : !stream.resource<transient>{%78},
        wo %arg9[%c0 for %88] : !stream.resource<transient>{%88}
      }
      stream.cmd.dispatch @mx4_linear_f32_dispatch_3::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_3_elementwise_broadcast_D_f32[%31, %7, %23, %13, %14, %15](%90, %92, %94, %96, %70, %72, %98, %100, %102, %104, %106, %108, %110, %112 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg9[%c0 for %88] : !stream.resource<transient>{%88}
      }
    } => !stream.timepoint
    %114 = stream.timepoint.await %113 => %result_2 : !stream.resource<transient>{%88}
    %115 = stream.resource.subview %114[%86] : !stream.resource<transient>{%88} -> !stream.resource<transient>{%85}
    %116 = util.optimization_barrier %115 : !stream.resource<transient>
    %117 = stream.timepoint.join max(%113, %26) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%117) => !stream.resource<external>{%85} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%117) => !stream.resource<transient>{%86} => !stream.timepoint
    %118 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %119 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%118) => with(%24 as %arg6: !stream.resource<external>{%25}, %result_2 as %arg7: !stream.resource<transient>{%88}, %116 as %arg8: !stream.resource<transient>{%21}, %result_4 as %arg9: !stream.resource<external>{%85}, %result_6 as %arg10: !stream.resource<transient>{%86}) {
      stream.cmd.copy %arg6[%c0], %arg10[%c0], %21 : !stream.resource<external>{%21} -> !stream.resource<transient>{%86}
      stream.cmd.dispatch @mx4_linear_f32_dispatch_4::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_4_elementwise_broadcast_D_f32[%31, %0, %7](%94, %96, %50, %52, %70, %72 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %88] : !stream.resource<transient>{%88},
        ro %arg10[%c0 for %86] : !stream.resource<transient>{%86},
        ro %arg8[%c0 for %21] : !stream.resource<transient>{%21},
        wo %arg9[%c0 for %85] : !stream.resource<external>{%85}
      }
    } => !stream.timepoint
    %120 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%119) => %result_6 : !stream.resource<transient>{%86} => !stream.timepoint
    %121 = arith.addi %23, %c1 : index
    cf.br ^bb1(%121, %result_4, %85, %120 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %26 => (%arg5 : !hal.fence)
    %122 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %24 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%21} -> !hal.buffer_view
    util.return %122 : !hal.buffer_view
  }
  hal.executable private @mx8_grouped_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @mx8_grouped_f32_dispatch_1_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @mx8_grouped_f32_dispatch_1_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %cst = arith.constant 0x7FC00000 : f32
          %c4 = arith.constant 4 : index
          %c8 = arith.constant 8 : index
          %c255_i32 = arith.constant 255 : i32
          %c127_i32 = arith.constant 127 : i32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = arith.extui %1 : i32 to i64
          %17 = arith.shli %16, %c32_i64 : i64
          %18 = arith.extui %0 : i32 to i64
          %19 = arith.ori %18, %17 : i64
          %20 = arith.index_castui %19 {stream.alignment = 64 : index} : i64 to index
          %21 = arith.extui %3 : i32 to i64
          %22 = arith.shli %21, %c32_i64 : i64
          %23 = arith.extui %2 : i32 to i64
          %24 = arith.ori %23, %22 : i64
          %25 = arith.index_castui %24 : i64 to index
          %26 = arith.extui %5 : i32 to i64
          %27 = arith.shli %26, %c32_i64 : i64
          %28 = arith.extui %4 : i32 to i64
          %29 = arith.ori %28, %27 : i64
          %30 = arith.index_castui %29 : i64 to index
          %31 = arith.extui %7 : i32 to i64
          %32 = arith.shli %31, %c32_i64 : i64
          %33 = arith.extui %6 : i32 to i64
          %34 = arith.ori %33, %32 : i64
          %35 = arith.index_castui %34 : i64 to index
          %36 = arith.extui %9 : i32 to i64
          %37 = arith.shli %36, %c32_i64 : i64
          %38 = arith.extui %8 : i32 to i64
          %39 = arith.ori %38, %37 : i64
          %40 = arith.index_castui %39 : i64 to index
          %41 = arith.extui %11 : i32 to i64
          %42 = arith.shli %41, %c32_i64 : i64
          %43 = arith.extui %10 : i32 to i64
          %44 = arith.ori %43, %42 : i64
          %45 = arith.index_castui %44 : i64 to index
          %46 = arith.extui %13 : i32 to i64
          %47 = arith.shli %46, %c32_i64 : i64
          %48 = arith.extui %12 : i32 to i64
          %49 = arith.ori %48, %47 : i64
          %50 = arith.index_castui %49 : i64 to index
          %51 = arith.extui %15 : i32 to i64
          %52 = arith.shli %51, %c32_i64 : i64
          %53 = arith.extui %14 : i32 to i64
          %54 = arith.ori %53, %52 : i64
          %55 = arith.index_castui %54 : i64 to index
          %56:4 = util.assume.int 
              %40<umin = 0, umax = 9007199254740991>, 
              %45<umin = 0, umax = 9007199254740991>, 
              %50<umin = 0, umax = 9007199254740991>, 
              %55<umin = 0, umax = 9007199254740991>
            : index, index, index, index
          %57 = iree_tensor_ext.dispatch.workload.ordinal %25, 0 : index
          %58 = iree_tensor_ext.dispatch.workload.ordinal %56#0, 3 : index
          %59 = iree_tensor_ext.dispatch.workload.ordinal %56#1, 4 : index
          %60 = iree_tensor_ext.dispatch.workload.ordinal %56#2, 5 : index
          %61 = iree_tensor_ext.dispatch.workload.ordinal %56#3, 6 : index
          %62 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58}
          %63 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%59, %60, %61}
          %64 = hal.interface.binding.subspan layout(<constants = 16, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%20) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%57}
          %65 = iree_tensor_ext.dispatch.workload.ordinal %30, 1 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %35, 2 : index
          %67 = iree_tensor_ext.dispatch.tensor.load %62, offsets = [0], sizes = [%58], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%58} -> tensor<?xi32>
          %68 = iree_tensor_ext.dispatch.tensor.load %63, offsets = [0, 0, 0], sizes = [%59, %60, %61], strides = [1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?x?xi32>>{%59, %60, %61} -> tensor<?x?x?xi32>
          %69 = tensor.empty(%57) : tensor<?xf32>
          %70 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%69 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %71 = linalg.index 0 : index
            %72 = arith.remsi %71, %65 : index
            %73 = arith.divsi %71, %65 : index
            %74 = arith.remsi %73, %60 : index
            %75 = arith.divsi %73, %60 : index
            %extracted = tensor.extract %67[%75] : tensor<?xi32>
            %76 = arith.index_cast %extracted : i32 to index
            %77 = arith.addi %66, %72 : index
            %78 = arith.divui %77, %c4 : index
            %79 = arith.remui %77, %c4 : index
            %80 = arith.muli %79, %c8 : index
            %81 = arith.index_castui %80 : index to i32
            %extracted_0 = tensor.extract %68[%76, %74, %78] : tensor<?x?x?xi32>
            %82 = arith.shrui %extracted_0, %81 : i32
            %83 = arith.andi %82, %c255_i32 : i32
            %84 = arith.trunci %83 : i32 to i8
            %85 = arith.bitcast %84 : i8 to f8E4M3FN
            %86 = arith.extf %85 : f8E4M3FN to f32
            %87 = arith.andi %82, %c127_i32 : i32
            %88 = arith.cmpi eq, %87, %c127_i32 : i32
            %89 = arith.select %88, %cst, %86 : f32
            linalg.yield %89 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %70, %64, offsets = [0], sizes = [%57], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%57}
          return
        }
        iree_codegen.dispatch_config @mx8_grouped_f32_dispatch_1_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @mx8_grouped_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: !hal.fence, %arg6: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx8_grouped_f32(%input0: tensor<?x?xf32>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: tensor<?xi32>, %input4: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg5 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%19]) type(%element_type_i32) encoding(%dense_row_major)
    %20 = arith.muli %19, %c4 : index
    %21 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%19} in !stream.resource<external>{%20}
    %22 = arith.index_cast %arg4 : i32 to index
    %23 = arith.divui %1, %22 : index
    %24 = arith.muli %2, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%24} => !stream.timepoint
    %25 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg7: !stream.resource<external>{%24}) {
      stream.cmd.fill %c0_i8, %arg7[%c0 for %24] : i8 -> !stream.resource<external>{%24}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %24, %25 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb1(%26: index, %27: !stream.resource<external>, %28: index, %29: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %30 = arith.cmpi slt, %26, %23 : index
    cf.cond_br %30, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %31 = arith.muli %26, %22 : index
    %32 = arith.muli %0, %22 overflow<nsw> : index
    %33 = arith.muli %32, %c4 : index
    %34 = arith.muli %0, %7 overflow<nsw> : index
    %35 = arith.muli %34, %22 overflow<nsw> : index
    %36 = arith.muli %35, %c4 : index
    %37 = util.align %33, %c64 : index
    %38 = util.align %36, %c64 : index
    %39 = arith.addi %37, %38 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%39} => !stream.timepoint
    %40 = arith.index_castui %32 : index to i64
    %41 = arith.index_castui %32 : index to i32
    %42 = arith.shrui %40, %c32_i64 : i64
    %43 = arith.trunci %42 : i64 to i32
    %44 = arith.index_castui %22 : index to i64
    %45 = arith.index_castui %22 : index to i32
    %46 = arith.shrui %44, %c32_i64 : i64
    %47 = arith.trunci %46 : i64 to i32
    %48 = arith.index_castui %31 : index to i64
    %49 = arith.index_castui %31 : index to i32
    %50 = arith.shrui %48, %c32_i64 : i64
    %51 = arith.trunci %50 : i64 to i32
    %52 = arith.index_castui %0 : index to i64
    %53 = arith.index_castui %0 : index to i32
    %54 = arith.shrui %52, %c32_i64 : i64
    %55 = arith.trunci %54 : i64 to i32
    %56 = arith.index_castui %1 : index to i64
    %57 = arith.index_castui %1 : index to i32
    %58 = arith.shrui %56, %c32_i64 : i64
    %59 = arith.trunci %58 : i64 to i32
    %60 = arith.index_castui %37 : index to i64
    %61 = arith.index_castui %37 : index to i32
    %62 = arith.shrui %60, %c32_i64 : i64
    %63 = arith.trunci %62 : i64 to i32
    %64 = arith.index_castui %35 : index to i64
    %65 = arith.index_castui %35 : index to i32
    %66 = arith.shrui %64, %c32_i64 : i64
    %67 = arith.trunci %66 : i64 to i32
    %68 = arith.index_castui %19 : index to i64
    %69 = arith.index_castui %19 : index to i32
    %70 = arith.shrui %68, %c32_i64 : i64
    %71 = arith.trunci %70 : i64 to i32
    %72 = arith.index_castui %6 : index to i64
    %73 = arith.index_castui %6 : index to i32
    %74 = arith.shrui %72, %c32_i64 : i64
    %75 = arith.trunci %74 : i64 to i32
    %76 = arith.index_castui %7 : index to i64
    %77 = arith.index_castui %7 : index to i32
    %78 = arith.shrui %76, %c32_i64 : i64
    %79 = arith.trunci %78 : i64 to i32
    %80 = arith.index_castui %8 : index to i64
    %81 = arith.index_castui %8 : index to i32
    %82 = arith.shrui %80, %c32_i64 : i64
    %83 = arith.trunci %82 : i64 to i32
    %84 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg7: !stream.resource<external>{%3}, %21 as %arg8: !stream.resource<external>{%20}, %12 as %arg9: !stream.resource<external>{%11}, %result_0 as %arg10: !stream.resource<transient>{%39}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_0::@vulkan_spirv_fb::@affine_linear_f32_dispatch_0_elementwise_broadcast_D_f32[%32, %22, %31, %0, %1](%41, %43, %45, %47, %49, %51, %53, %55, %57, %59 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg10[%c0 for %39] : !stream.resource<transient>{%39}
      }
      stream.cmd.dispatch @mx8_grouped_f32_dispatch_1::@vulkan_spirv_fb::@mx8_grouped_f32_dispatch_1_elementwise_broadcast_D_f32[%35, %22, %31, %19, %6, %7, %8](%61, %63, %65, %67, %45, %47, %49, %51, %69, %71, %73, %75, %77, %79, %81, %83 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg10[%c0 for %39] : !stream.resource<transient>{%39}
      }
    } => !stream.timepoint
    %85 = arith.muli %24, %22 : index
    %86 = stream.timepoint.await %84 => %result_0 : !stream.resource<transient>{%39}
    %87 = stream.resource.subview %86[%c0] : !stream.resource<transient>{%39} -> !stream.resource<transient>{%33}
    %88 = stream.resource.subview %86[%37] : !stream.resource<transient>{%39} -> !stream.resource<transient>{%36}
    %89 = util.optimization_barrier %87 : !stream.resource<transient>
    %90 = util.optimization_barrier %88 : !stream.resource<transient>
    %91 = arith.muli %2, %22 : index
    %92 = arith.muli %34, %c4 : index
    %93 = util.align %24, %c64 : index
    %94 = util.align %92, %c64 : index
    %95 = arith.addi %93, %94 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%95} => !stream.timepoint
    %96 = arith.index_castui %93 : index to i64
    %97 = arith.index_castui %93 : index to i32
    %98 = arith.shrui %96, %c32_i64 : i64
    %99 = arith.trunci %98 : i64 to i32
    %100 = arith.index_castui %34 : index to i64
    %101 = arith.index_castui %34 : index to i32
    %102 = arith.shrui %100, %c32_i64 : i64
    %103 = arith.trunci %102 : i64 to i32
    %104 = arith.index_castui %26 : index to i64
    %105 = arith.index_castui %26 : index to i32
    %106 = arith.shrui %104, %c32_i64 : i64
    %107 = arith.trunci %106 : i64 to i32
    %108 = arith.index_castui %13 : index to i64
    %109 = arith.index_castui %13 : index to i32
    %110 = arith.shrui %108, %c32_i64 : i64
    %111 = arith.trunci %110 : i64 to i32
    %112 = arith.index_castui %14 : index to i64
    %113 = arith.index_castui %14 : index to i32
    %114 = arith.shrui %112, %c32_i64 : i64
    %115 = arith.trunci %114 : i64 to i32
    %116 = arith.index_castui %15 : index to i64
    %117 = arith.index_castui %15 : index to i32
    %118 = arith.shrui %116, %c32_i64 : i64
    %119 = arith.trunci %118 : i64 to i32
    %120 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%89 as %arg7: !stream.resource<transient>{%91}, %90 as %arg8: !stream.resource<transient>{%85}, %21 as %arg9: !stream.resource<external>{%20}, %18 as %arg10: !stream.resource<external>{%17}, %result_2 as %arg11: !stream.resource<transient>{%95}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %22, %7](%53, %55, %45, %47, %77, %79 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %91] : !stream.resource<transient>{%91},
        ro %arg8[%c0 for %85] : !stream.resource<transient>{%85},
        wo %arg11[%c0 for %95] : !stream.resource<transient>{%95}
      }
      stream.cmd.dispatch @mx4_grouped_f32_dispatch_3::@vulkan_spirv_fb::@mx4_grouped_f32_dispatch_3_elementwise_broadcast_D_f32[%34, %7, %26, %19, %13, %14, %15](%97, %99, %101, %103, %77, %79, %105, %107, %69, %71, %109, %111, %113, %115, %117, %119 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg11[%c0 for %95] : !stream.resource<transient>{%95}
      }
    } => !stream.timepoint
    %121 = stream.timepoint.await %120 => %result_2 : !stream.resource<transient>{%95}
    %122 = stream.resource.subview %121[%93] : !stream.resource<transient>{%95} -> !stream.resource<transient>{%92}
    %123 = util.optimization_barrier %122 : !stream.resource<transient>
    %124 = stream.timepoint.join max(%120, %29) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%124) => !stream.resource<external>{%92} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%124) => !stream.resource<transient>{%93} => !stream.timepoint
    %125 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %126 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%125) => with(%27 as %arg7: !stream.resource<external>{%28}, %result_2 as %arg8: !stream.resource<transient>{%95}, %123 as %arg9: !stream.resource<transient>{%24}, %result_4 as %arg10: !stream.resource<external>{%92}, %result_6 as %arg11: !stream.resource<transient>{%93}) {
      stream.cmd.copy %arg7[%c0], %arg11[%c0], %24 : !stream.resource<external>{%24} -> !stream.resource<transient>{%93}
      stream.cmd.dispatch @mx4_linear_f32_dispatch_4::@vulkan_spirv_fb::@mx4_linear_f32_dispatch_4_elementwise_broadcast_D_f32[%34, %0, %7](%101, %103, %53, %55, %77, %79 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %95] : !stream.resource<transient>{%95},
        ro %arg11[%c0 for %93] : !stream.resource<transient>{%93},
        ro %arg9[%c0 for %24] : !stream.resource<transient>{%24},
        wo %arg10[%c0 for %92] : !stream.resource<external>{%92}
      }
    } => !stream.timepoint
    %127 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%126) => %result_6 : !stream.resource<transient>{%93} => !stream.timepoint
    %128 = arith.addi %26, %c1 : index
    cf.br ^bb1(%128, %result_4, %92, %127 : index, !stream.resource<external>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %29 => (%arg6 : !hal.fence)
    %129 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %27 : tensor<?x?xf32>{%0, %7} in !stream.resource<external>{%24} -> !hal.buffer_view
    util.return %129 : !hal.buffer_view
  }
  util.func public @mx8_linear_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx8_linear_f16(%input0: tensor<?x?xf16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg3 : i32 to index
    %20 = arith.divui %1, %19 : index
    %21 = arith.muli %0, %c4 : index
    %22 = arith.muli %21, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%22} => !stream.timepoint
    %23 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg6: !stream.resource<transient>{%22}) {
      stream.cmd.fill %c0_i8, %arg6[%c0 for %22] : i8 -> !stream.resource<transient>{%22}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %22, %23 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%24: index, %25: !stream.resource<transient>, %26: index, %27: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %28 = arith.cmpi slt, %24, %20 : index
    cf.cond_br %28, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %29 = arith.muli %24, %19 : index
    %30 = arith.muli %0, %19 overflow<nsw> : index
    %31 = arith.muli %30, %c4 : index
    %32 = arith.muli %0, %7 overflow<nsw> : index
    %33 = arith.muli %32, %19 overflow<nsw> : index
    %34 = arith.muli %33, %c4 : index
    %35 = util.align %31, %c64 : index
    %36 = util.align %34, %c64 : index
    %37 = arith.addi %35, %36 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%37} => !stream.timepoint
    %38 = arith.index_castui %30 : index to i64
    %39 = arith.index_castui %30 : index to i32
    %40 = arith.shrui %38, %c32_i64 : i64
    %41 = arith.trunci %40 : i64 to i32
    %42 = arith.index_castui %19 : index to i64
    %43 = arith.index_castui %19 : index to i32
    %44 = arith.shrui %42, %c32_i64 : i64
    %45 = arith.trunci %44 : i64 to i32
    %46 = arith.index_castui %29 : index to i64
    %47 = arith.index_castui %29 : index to i32
    %48 = arith.shrui %46, %c32_i64 : i64
    %49 = arith.trunci %48 : i64 to i32
    %50 = arith.index_castui %0 : index to i64
    %51 = arith.index_castui %0 : index to i32
    %52 = arith.shrui %50, %c32_i64 : i64
    %53 = arith.trunci %52 : i64 to i32
    %54 = arith.index_castui %1 : index to i64
    %55 = arith.index_castui %1 : index to i32
    %56 = arith.shrui %54, %c32_i64 : i64
    %57 = arith.trunci %56 : i64 to i32
    %58 = arith.index_castui %35 : index to i64
    %59 = arith.index_castui %35 : index to i32
    %60 = arith.shrui %58, %c32_i64 : i64
    %61 = arith.trunci %60 : i64 to i32
    %62 = arith.index_castui %33 : index to i64
    %63 = arith.index_castui %33 : index to i32
    %64 = arith.shrui %62, %c32_i64 : i64
    %65 = arith.trunci %64 : i64 to i32
    %66 = arith.index_castui %6 : index to i64
    %67 = arith.index_castui %6 : index to i32
    %68 = arith.shrui %66, %c32_i64 : i64
    %69 = arith.trunci %68 : i64 to i32
    %70 = arith.index_castui %7 : index to i64
    %71 = arith.index_castui %7 : index to i32
    %72 = arith.shrui %70, %c32_i64 : i64
    %73 = arith.trunci %72 : i64 to i32
    %74 = arith.index_castui %8 : index to i64
    %75 = arith.index_castui %8 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg6: !stream.resource<external>{%3}, %12 as %arg7: !stream.resource<external>{%11}, %result_0 as %arg8: !stream.resource<transient>{%37}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_0::@vulkan_spirv_fb::@affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32[%30, %19, %29, %0, %1](%39, %41, %43, %45, %47, %49, %51, %53, %55, %57 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
      stream.cmd.dispatch @mx8_linear_f32_dispatch_1::@vulkan_spirv_fb::@mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32[%33, %19, %29, %6, %7, %8](%59, %61, %63, %65, %43, %45, %47, %49, %67, %69, %71, %73, %75, %77 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
    } => !stream.timepoint
    %79 = arith.muli %22, %19 : index
    %80 = stream.timepoint.await %78 => %result_0 : !stream.resource<transient>{%37}
    %81 = stream.resource.subview %80[%c0] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%31}
    %82 = stream.resource.subview %80[%35] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%34}
    %83 = util.optimization_barrier %81 : !stream.resource<transient>
    %84 = util.optimization_barrier %82 : !stream.resource<transient>
    %85 = arith.muli %21, %19 : index
    %86 = arith.muli %32, %c2 : index
    %87 = util.align %22, %c64 : index
    %88 = util.align %86, %c64 : index
    %89 = arith.addi %87, %88 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%89} => !stream.timepoint
    %90 = arith.index_castui %87 : index to i64
    %91 = arith.index_castui %87 : index to i32
    %92 = arith.shrui %90, %c32_i64 : i64
    %93 = arith.trunci %92 : i64 to i32
    %94 = arith.index_castui %32 : index to i64
    %95 = arith.index_castui %32 : index to i32
    %96 = arith.shrui %94, %c32_i64 : i64
    %97 = arith.trunci %96 : i64 to i32
    %98 = arith.index_castui %24 : index to i64
    %99 = arith.index_castui %24 : index to i32
    %100 = arith.shrui %98, %c32_i64 : i64
    %101 = arith.trunci %100 : i64 to i32
    %102 = arith.index_castui %13 : index to i64
    %103 = arith.index_castui %13 : index to i32
    %104 = arith.shrui %102, %c32_i64 : i64
    %105 = arith.trunci %104 : i64 to i32
    %106 = arith.index_castui %14 : index to i64
    %107 = arith.index_castui %14 : index to i32
    %108 = arith.shrui %106, %c32_i64 : i64
    %109 = arith.trunci %108 : i64 to i32
    %110 = arith.index_castui %15 : index to i64
    %111 = arith.index_castui %15 : index to i32
    %112 = arith.shrui %110, %c32_i64 : i64
    %113 = arith.trunci %112 : i64 to i32
    %114 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%83 as %arg6: !stream.resource<transient>{%85}, %84 as %arg7: !stream.resource<transient>{%79}, %18 as %arg8: !stream.resource<external>{%17}, %result_2 as %arg9: !stream.resource<transient>{%89}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %19, %7](%51, %53, %43, %45, %71, %73 : i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %85] : !stream.resource<transient>{%85},
        ro %arg7[%c0 for %79] : !stream.resource<transient>{%79},
        wo %arg9[%c0 for %89] : !stream.resource<transient>{%89}
      }
      stream.cmd.dispatch @mx4_linear_f16_dispatch_3::@vulkan_spirv_fb::@mx4_linear_f16_dispatch_3_elementwise_broadcast_D_f16[%32, %7, %24, %13, %14, %15](%91, %93, %95, %97, %71, %73, %99, %101, %103, %105, %107, %109, %111, %113 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg9[%c0 for %89] : !stream.resource<transient>{%89}
      }
    } => !stream.timepoint
    %115 = arith.muli %2, %7 : index
    %116 = stream.timepoint.await %114 => %result_2 : !stream.resource<transient>{%89}
    %117 = stream.resource.subview %116[%87] : !stream.resource<transient>{%89} -> !stream.resource<transient>{%86}
    %118 = util.optimization_barrier %117 : !stream.resource<transient>
    %119 = arith.muli %32, %c4 : index
    %120 = stream.timepoint.join max(%114, %27) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%120) => !stream.resource<transient>{%119} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%120) => !stream.resource<transient>{%87} => !stream.timepoint
    %121 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %122 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%121) => with(%25 as %arg6: !stream.resource<transient>{%26}, %result_2 as %arg7: !stream.resource<transient>{%89}, %118 as %arg8: !stream.resource<transient>{%115}, %result_4 as %arg9: !stream.resource<transient>{%119}, %result_6 as %arg10: !stream.resource<transient>{%87}) {
      stream.cmd.copy %arg6[%c0], %arg10[%c0], %22 : !stream.resource<transient>{%22} -> !stream.resource<transient>{%87}
      stream.cmd.dispatch @mx4_linear_f16_dispatch_4::@vulkan_spirv_fb::@mx4_linear_f16_dispatch_4_elementwise_broadcast_D_f32[%32, %0, %7](%95, %97, %51, %53, %71, %73 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %89] : !stream.resource<transient>{%89},
        ro %arg10[%c0 for %87] : !stream.resource<transient>{%87},
        ro %arg8[%c0 for %115] : !stream.resource<transient>{%115},
        wo %arg9[%c0 for %119] : !stream.resource<transient>{%119}
      }
    } => !stream.timepoint
    %123 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%122) => %result_6 : !stream.resource<transient>{%87} => !stream.timepoint
    %124 = arith.addi %24, %c1 : index
    cf.br ^bb1(%124, %result_4, %119, %123 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %125 = arith.muli %0, %7 overflow<nsw> : index
    %126 = arith.muli %125, %c2 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%27) => !stream.resource<external>{%126} => !stream.timepoint
    %127 = arith.index_castui %125 : index to i64
    %128 = arith.index_castui %125 : index to i32
    %129 = arith.shrui %127, %c32_i64 : i64
    %130 = arith.trunci %129 : i64 to i32
    %131 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_9) => with(%25 as %arg6: !stream.resource<transient>{%26}, %result_8 as %arg7: !stream.resource<external>{%126}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_4::@vulkan_spirv_fb::@affine_linear_f16_dispatch_4_elementwise_D_f32xf16[%125](%128, %130 : i32, i32) {
        ro %arg6[%c0 for %26] : !stream.resource<transient>{%26},
        wo %arg7[%c0 for %126] : !stream.resource<external>{%126}
      }
    } => !stream.timepoint
    %132 = stream.resource.dealloca origin await(%131) => %25 : !stream.resource<transient>{%26} => !stream.timepoint
    %133 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %132 => (%arg5 : !hal.fence)
    %134 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_8 : tensor<?x?xf16>{%0, %7} in !stream.resource<external>{%133} -> !hal.buffer_view
    util.return %134 : !hal.buffer_view
  }
  util.func public @mx8_grouped_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: !hal.fence, %arg6: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx8_grouped_f16(%input0: tensor<?x?xf16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: tensor<?xi32>, %input4: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_f16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xf16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg5 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%19]) type(%element_type_i32) encoding(%dense_row_major)
    %20 = arith.muli %19, %c4 : index
    %21 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%19} in !stream.resource<external>{%20}
    %22 = arith.index_cast %arg4 : i32 to index
    %23 = arith.divui %1, %22 : index
    %24 = arith.muli %0, %c4 : index
    %25 = arith.muli %24, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%25} => !stream.timepoint
    %26 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg7: !stream.resource<transient>{%25}) {
      stream.cmd.fill %c0_i8, %arg7[%c0 for %25] : i8 -> !stream.resource<transient>{%25}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %26 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%27: index, %28: !stream.resource<transient>, %29: index, %30: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %31 = arith.cmpi slt, %27, %23 : index
    cf.cond_br %31, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %32 = arith.muli %27, %22 : index
    %33 = arith.muli %0, %22 overflow<nsw> : index
    %34 = arith.muli %33, %c4 : index
    %35 = arith.muli %0, %7 overflow<nsw> : index
    %36 = arith.muli %35, %22 overflow<nsw> : index
    %37 = arith.muli %36, %c4 : index
    %38 = util.align %34, %c64 : index
    %39 = util.align %37, %c64 : index
    %40 = arith.addi %38, %39 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%40} => !stream.timepoint
    %41 = arith.index_castui %33 : index to i64
    %42 = arith.index_castui %33 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = arith.index_castui %22 : index to i64
    %46 = arith.index_castui %22 : index to i32
    %47 = arith.shrui %45, %c32_i64 : i64
    %48 = arith.trunci %47 : i64 to i32
    %49 = arith.index_castui %32 : index to i64
    %50 = arith.index_castui %32 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %0 : index to i64
    %54 = arith.index_castui %0 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %1 : index to i64
    %58 = arith.index_castui %1 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = arith.index_castui %38 : index to i64
    %62 = arith.index_castui %38 : index to i32
    %63 = arith.shrui %61, %c32_i64 : i64
    %64 = arith.trunci %63 : i64 to i32
    %65 = arith.index_castui %36 : index to i64
    %66 = arith.index_castui %36 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %19 : index to i64
    %70 = arith.index_castui %19 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = arith.index_castui %6 : index to i64
    %74 = arith.index_castui %6 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = arith.index_castui %7 : index to i64
    %78 = arith.index_castui %7 : index to i32
    %79 = arith.shrui %77, %c32_i64 : i64
    %80 = arith.trunci %79 : i64 to i32
    %81 = arith.index_castui %8 : index to i64
    %82 = arith.index_castui %8 : index to i32
    %83 = arith.shrui %81, %c32_i64 : i64
    %84 = arith.trunci %83 : i64 to i32
    %85 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg7: !stream.resource<external>{%3}, %21 as %arg8: !stream.resource<external>{%20}, %12 as %arg9: !stream.resource<external>{%11}, %result_0 as %arg10: !stream.resource<transient>{%40}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_0::@vulkan_spirv_fb::@affine_linear_f16_dispatch_0_elementwise_broadcast_D_f32[%33, %22, %32, %0, %1](%42, %44, %46, %48, %50, %52, %54, %56, %58, %60 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg10[%c0 for %40] : !stream.resource<transient>{%40}
      }
      stream.cmd.dispatch @mx8_grouped_f32_dispatch_1::@vulkan_spirv_fb::@mx8_grouped_f32_dispatch_1_elementwise_broadcast_D_f32[%36, %22, %32, %19, %6, %7, %8](%62, %64, %66, %68, %46, %48, %50, %52, %70, %72, %74, %76, %78, %80, %82, %84 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg10[%c0 for %40] : !stream.resource<transient>{%40}
      }
    } => !stream.timepoint
    %86 = arith.muli %25, %22 : index
    %87 = stream.timepoint.await %85 => %result_0 : !stream.resource<transient>{%40}
    %88 = stream.resource.subview %87[%c0] : !stream.resource<transient>{%40} -> !stream.resource<transient>{%34}
    %89 = stream.resource.subview %87[%38] : !stream.resource<transient>{%40} -> !stream.resource<transient>{%37}
    %90 = util.optimization_barrier %88 : !stream.resource<transient>
    %91 = util.optimization_barrier %89 : !stream.resource<transient>
    %92 = arith.muli %24, %22 : index
    %93 = arith.muli %35, %c2 : index
    %94 = util.align %25, %c64 : index
    %95 = util.align %93, %c64 : index
    %96 = arith.addi %94, %95 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%96} => !stream.timepoint
    %97 = arith.index_castui %94 : index to i64
    %98 = arith.index_castui %94 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %35 : index to i64
    %102 = arith.index_castui %35 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %27 : index to i64
    %106 = arith.index_castui %27 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %13 : index to i64
    %110 = arith.index_castui %13 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %14 : index to i64
    %114 = arith.index_castui %14 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %15 : index to i64
    %118 = arith.index_castui %15 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%90 as %arg7: !stream.resource<transient>{%92}, %91 as %arg8: !stream.resource<transient>{%86}, %21 as %arg9: !stream.resource<external>{%20}, %18 as %arg10: !stream.resource<external>{%17}, %result_2 as %arg11: !stream.resource<transient>{%96}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %22, %7](%54, %56, %46, %48, %78, %80 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %92] : !stream.resource<transient>{%92},
        ro %arg8[%c0 for %86] : !stream.resource<transient>{%86},
        wo %arg11[%c0 for %96] : !stream.resource<transient>{%96}
      }
      stream.cmd.dispatch @mx4_grouped_f16_dispatch_3::@vulkan_spirv_fb::@mx4_grouped_f16_dispatch_3_elementwise_broadcast_D_f16[%35, %7, %27, %19, %13, %14, %15](%98, %100, %102, %104, %78, %80, %106, %108, %70, %72, %110, %112, %114, %116, %118, %120 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg11[%c0 for %96] : !stream.resource<transient>{%96}
      }
    } => !stream.timepoint
    %122 = arith.muli %2, %7 : index
    %123 = stream.timepoint.await %121 => %result_2 : !stream.resource<transient>{%96}
    %124 = stream.resource.subview %123[%94] : !stream.resource<transient>{%96} -> !stream.resource<transient>{%93}
    %125 = util.optimization_barrier %124 : !stream.resource<transient>
    %126 = arith.muli %35, %c4 : index
    %127 = stream.timepoint.join max(%121, %30) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%127) => !stream.resource<transient>{%126} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%127) => !stream.resource<transient>{%94} => !stream.timepoint
    %128 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %129 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%128) => with(%28 as %arg7: !stream.resource<transient>{%29}, %result_2 as %arg8: !stream.resource<transient>{%96}, %125 as %arg9: !stream.resource<transient>{%122}, %result_4 as %arg10: !stream.resource<transient>{%126}, %result_6 as %arg11: !stream.resource<transient>{%94}) {
      stream.cmd.copy %arg7[%c0], %arg11[%c0], %25 : !stream.resource<transient>{%25} -> !stream.resource<transient>{%94}
      stream.cmd.dispatch @mx4_linear_f16_dispatch_4::@vulkan_spirv_fb::@mx4_linear_f16_dispatch_4_elementwise_broadcast_D_f32[%35, %0, %7](%102, %104, %54, %56, %78, %80 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %96] : !stream.resource<transient>{%96},
        ro %arg11[%c0 for %94] : !stream.resource<transient>{%94},
        ro %arg9[%c0 for %122] : !stream.resource<transient>{%122},
        wo %arg10[%c0 for %126] : !stream.resource<transient>{%126}
      }
    } => !stream.timepoint
    %130 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%129) => %result_6 : !stream.resource<transient>{%94} => !stream.timepoint
    %131 = arith.addi %27, %c1 : index
    cf.br ^bb1(%131, %result_4, %126, %130 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %132 = arith.muli %0, %7 overflow<nsw> : index
    %133 = arith.muli %132, %c2 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%30) => !stream.resource<external>{%133} => !stream.timepoint
    %134 = arith.index_castui %132 : index to i64
    %135 = arith.index_castui %132 : index to i32
    %136 = arith.shrui %134, %c32_i64 : i64
    %137 = arith.trunci %136 : i64 to i32
    %138 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_9) => with(%28 as %arg7: !stream.resource<transient>{%29}, %result_8 as %arg8: !stream.resource<external>{%133}) {
      stream.cmd.dispatch @affine_linear_f16_dispatch_4::@vulkan_spirv_fb::@affine_linear_f16_dispatch_4_elementwise_D_f32xf16[%132](%135, %137 : i32, i32) {
        ro %arg7[%c0 for %29] : !stream.resource<transient>{%29},
        wo %arg8[%c0 for %133] : !stream.resource<external>{%133}
      }
    } => !stream.timepoint
    %139 = stream.resource.dealloca origin await(%138) => %28 : !stream.resource<transient>{%29} => !stream.timepoint
    %140 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %139 => (%arg6 : !hal.fence)
    %141 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_8 : tensor<?x?xf16>{%0, %7} in !stream.resource<external>{%140} -> !hal.buffer_view
    util.return %141 : !hal.buffer_view
  }
  util.func public @mx8_linear_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: i32, %arg4: !hal.fence, %arg5: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx8_linear_bf16(%input0: tensor<?x?xi16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg4 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg3 : i32 to index
    %20 = arith.divui %1, %19 : index
    %21 = arith.muli %0, %c4 : index
    %22 = arith.muli %21, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%22} => !stream.timepoint
    %23 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg6: !stream.resource<transient>{%22}) {
      stream.cmd.fill %c0_i8, %arg6[%c0 for %22] : i8 -> !stream.resource<transient>{%22}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %22, %23 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%24: index, %25: !stream.resource<transient>, %26: index, %27: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %28 = arith.cmpi slt, %24, %20 : index
    cf.cond_br %28, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %29 = arith.muli %24, %19 : index
    %30 = arith.muli %0, %19 overflow<nsw> : index
    %31 = arith.muli %30, %c4 : index
    %32 = arith.muli %0, %7 overflow<nsw> : index
    %33 = arith.muli %32, %19 overflow<nsw> : index
    %34 = arith.muli %33, %c4 : index
    %35 = util.align %31, %c64 : index
    %36 = util.align %34, %c64 : index
    %37 = arith.addi %35, %36 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%37} => !stream.timepoint
    %38 = arith.index_castui %30 : index to i64
    %39 = arith.index_castui %30 : index to i32
    %40 = arith.shrui %38, %c32_i64 : i64
    %41 = arith.trunci %40 : i64 to i32
    %42 = arith.index_castui %19 : index to i64
    %43 = arith.index_castui %19 : index to i32
    %44 = arith.shrui %42, %c32_i64 : i64
    %45 = arith.trunci %44 : i64 to i32
    %46 = arith.index_castui %29 : index to i64
    %47 = arith.index_castui %29 : index to i32
    %48 = arith.shrui %46, %c32_i64 : i64
    %49 = arith.trunci %48 : i64 to i32
    %50 = arith.index_castui %0 : index to i64
    %51 = arith.index_castui %0 : index to i32
    %52 = arith.shrui %50, %c32_i64 : i64
    %53 = arith.trunci %52 : i64 to i32
    %54 = arith.index_castui %1 : index to i64
    %55 = arith.index_castui %1 : index to i32
    %56 = arith.shrui %54, %c32_i64 : i64
    %57 = arith.trunci %56 : i64 to i32
    %58 = arith.index_castui %35 : index to i64
    %59 = arith.index_castui %35 : index to i32
    %60 = arith.shrui %58, %c32_i64 : i64
    %61 = arith.trunci %60 : i64 to i32
    %62 = arith.index_castui %33 : index to i64
    %63 = arith.index_castui %33 : index to i32
    %64 = arith.shrui %62, %c32_i64 : i64
    %65 = arith.trunci %64 : i64 to i32
    %66 = arith.index_castui %6 : index to i64
    %67 = arith.index_castui %6 : index to i32
    %68 = arith.shrui %66, %c32_i64 : i64
    %69 = arith.trunci %68 : i64 to i32
    %70 = arith.index_castui %7 : index to i64
    %71 = arith.index_castui %7 : index to i32
    %72 = arith.shrui %70, %c32_i64 : i64
    %73 = arith.trunci %72 : i64 to i32
    %74 = arith.index_castui %8 : index to i64
    %75 = arith.index_castui %8 : index to i32
    %76 = arith.shrui %74, %c32_i64 : i64
    %77 = arith.trunci %76 : i64 to i32
    %78 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg6: !stream.resource<external>{%3}, %12 as %arg7: !stream.resource<external>{%11}, %result_0 as %arg8: !stream.resource<transient>{%37}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_0::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32[%30, %19, %29, %0, %1](%39, %41, %43, %45, %47, %49, %51, %53, %55, %57 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
      stream.cmd.dispatch @mx8_linear_f32_dispatch_1::@vulkan_spirv_fb::@mx8_linear_f32_dispatch_1_elementwise_broadcast_D_f32[%33, %19, %29, %6, %7, %8](%59, %61, %63, %65, %43, %45, %47, %49, %67, %69, %71, %73, %75, %77 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg8[%c0 for %37] : !stream.resource<transient>{%37}
      }
    } => !stream.timepoint
    %79 = arith.muli %22, %19 : index
    %80 = stream.timepoint.await %78 => %result_0 : !stream.resource<transient>{%37}
    %81 = stream.resource.subview %80[%c0] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%31}
    %82 = stream.resource.subview %80[%35] : !stream.resource<transient>{%37} -> !stream.resource<transient>{%34}
    %83 = util.optimization_barrier %81 : !stream.resource<transient>
    %84 = util.optimization_barrier %82 : !stream.resource<transient>
    %85 = arith.muli %21, %19 : index
    %86 = arith.muli %32, %c2 : index
    %87 = util.align %22, %c64 : index
    %88 = util.align %86, %c64 : index
    %89 = arith.addi %87, %88 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%89} => !stream.timepoint
    %90 = arith.index_castui %87 : index to i64
    %91 = arith.index_castui %87 : index to i32
    %92 = arith.shrui %90, %c32_i64 : i64
    %93 = arith.trunci %92 : i64 to i32
    %94 = arith.index_castui %32 : index to i64
    %95 = arith.index_castui %32 : index to i32
    %96 = arith.shrui %94, %c32_i64 : i64
    %97 = arith.trunci %96 : i64 to i32
    %98 = arith.index_castui %24 : index to i64
    %99 = arith.index_castui %24 : index to i32
    %100 = arith.shrui %98, %c32_i64 : i64
    %101 = arith.trunci %100 : i64 to i32
    %102 = arith.index_castui %13 : index to i64
    %103 = arith.index_castui %13 : index to i32
    %104 = arith.shrui %102, %c32_i64 : i64
    %105 = arith.trunci %104 : i64 to i32
    %106 = arith.index_castui %14 : index to i64
    %107 = arith.index_castui %14 : index to i32
    %108 = arith.shrui %106, %c32_i64 : i64
    %109 = arith.trunci %108 : i64 to i32
    %110 = arith.index_castui %15 : index to i64
    %111 = arith.index_castui %15 : index to i32
    %112 = arith.shrui %110, %c32_i64 : i64
    %113 = arith.trunci %112 : i64 to i32
    %114 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%83 as %arg6: !stream.resource<transient>{%85}, %84 as %arg7: !stream.resource<transient>{%79}, %18 as %arg8: !stream.resource<external>{%17}, %result_2 as %arg9: !stream.resource<transient>{%89}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %19, %7](%51, %53, %43, %45, %71, %73 : i32, i32, i32, i32, i32, i32) {
        ro %arg6[%c0 for %85] : !stream.resource<transient>{%85},
        ro %arg7[%c0 for %79] : !stream.resource<transient>{%79},
        wo %arg9[%c0 for %89] : !stream.resource<transient>{%89}
      }
      stream.cmd.dispatch @mx4_linear_bf16_dispatch_3::@vulkan_spirv_fb::@mx4_linear_bf16_dispatch_3_elementwise_broadcast_D_i16[%32, %7, %24, %13, %14, %15](%91, %93, %95, %97, %71, %73, %99, %101, %103, %105, %107, %109, %111, %113 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg9[%c0 for %89] : !stream.resource<transient>{%89}
      }
    } => !stream.timepoint
    %115 = arith.muli %2, %7 : index
    %116 = stream.timepoint.await %114 => %result_2 : !stream.resource<transient>{%89}
    %117 = stream.resource.subview %116[%87] : !stream.resource<transient>{%89} -> !stream.resource<transient>{%86}
    %118 = util.optimization_barrier %117 : !stream.resource<transient>
    %119 = arith.muli %32, %c4 : index
    %120 = stream.timepoint.join max(%114, %27) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%120) => !stream.resource<transient>{%119} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%120) => !stream.resource<transient>{%87} => !stream.timepoint
    %121 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %122 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%121) => with(%25 as %arg6: !stream.resource<transient>{%26}, %result_2 as %arg7: !stream.resource<transient>{%89}, %118 as %arg8: !stream.resource<transient>{%115}, %result_4 as %arg9: !stream.resource<transient>{%119}, %result_6 as %arg10: !stream.resource<transient>{%87}) {
      stream.cmd.copy %arg6[%c0], %arg10[%c0], %22 : !stream.resource<transient>{%22} -> !stream.resource<transient>{%87}
      stream.cmd.dispatch @mx4_linear_bf16_dispatch_4::@vulkan_spirv_fb::@mx4_linear_bf16_dispatch_4_elementwise_broadcast_D_f32[%32, %0, %7](%95, %97, %51, %53, %71, %73 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %89] : !stream.resource<transient>{%89},
        ro %arg10[%c0 for %87] : !stream.resource<transient>{%87},
        ro %arg8[%c0 for %115] : !stream.resource<transient>{%115},
        wo %arg9[%c0 for %119] : !stream.resource<transient>{%119}
      }
    } => !stream.timepoint
    %123 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%122) => %result_6 : !stream.resource<transient>{%87} => !stream.timepoint
    %124 = arith.addi %24, %c1 : index
    cf.br ^bb1(%124, %result_4, %119, %123 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %125 = arith.muli %0, %7 overflow<nsw> : index
    %126 = arith.muli %125, %c2 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%27) => !stream.resource<external>{%126} => !stream.timepoint
    %127 = arith.index_castui %125 : index to i64
    %128 = arith.index_castui %125 : index to i32
    %129 = arith.shrui %127, %c32_i64 : i64
    %130 = arith.trunci %129 : i64 to i32
    %131 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_9) => with(%25 as %arg6: !stream.resource<transient>{%26}, %result_8 as %arg7: !stream.resource<external>{%126}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_4::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_4_elementwise_D_f32xi16[%125](%128, %130 : i32, i32) {
        ro %arg6[%c0 for %26] : !stream.resource<transient>{%26},
        wo %arg7[%c0 for %126] : !stream.resource<external>{%126}
      }
    } => !stream.timepoint
    %132 = stream.resource.dealloca origin await(%131) => %25 : !stream.resource<transient>{%26} => !stream.timepoint
    %133 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %132 => (%arg5 : !hal.fence)
    %134 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_8 : tensor<?x?xi16>{%0, %7} in !stream.resource<external>{%133} -> !hal.buffer_view
    util.return %134 : !hal.buffer_view
  }
  util.func public @mx8_grouped_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: !hal.fence, %arg6: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @mx8_grouped_bf16(%input0: tensor<?x?xi16>, %input1: tensor<?x?x?xi32>, %input2: tensor<?x?x?xi8>, %input3: tensor<?xi32>, %input4: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c4 = arith.constant 4 : index
    %c2 = arith.constant 2 : index
    %c0_i8 = arith.constant 0 : i8
    %c1 = arith.constant 1 : index
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i16) encoding(%dense_row_major)
    %2 = arith.muli %0, %c2 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi16>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg5 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %8 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[2] : index
    %element_type_i32 = hal.element_type<i32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7, %8]) type(%element_type_i32) encoding(%dense_row_major)
    %9 = arith.muli %6, %c4 : index
    %10 = arith.muli %9, %7 : index
    %11 = arith.muli %10, %8 : index
    %12 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?x?xi32>{%6, %7, %8} in !stream.resource<external>{%11}
    %13 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %14 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    %15 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[2] : index
    %element_type_i8 = hal.element_type<i8> : i32
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%13, %14, %15]) type(%element_type_i8) encoding(%dense_row_major)
    %16 = arith.muli %13, %14 : index
    %17 = arith.muli %16, %15 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?x?xi8>{%13, %14, %15} in !stream.resource<external>{%17}
    %19 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%19]) type(%element_type_i32) encoding(%dense_row_major)
    %20 = arith.muli %19, %c4 : index
    %21 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%19} in !stream.resource<external>{%20}
    %22 = arith.index_cast %arg4 : i32 to index
    %23 = arith.divui %1, %22 : index
    %24 = arith.muli %0, %c4 : index
    %25 = arith.muli %24, %7 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%25} => !stream.timepoint
    %26 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%result as %arg7: !stream.resource<transient>{%25}) {
      stream.cmd.fill %c0_i8, %arg7[%c0 for %25] : i8 -> !stream.resource<transient>{%25}
    } => !stream.timepoint
    cf.br ^bb1(%c0, %result, %25, %26 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb1(%27: index, %28: !stream.resource<transient>, %29: index, %30: !stream.timepoint):  // 2 preds: ^bb0, ^bb2
    %31 = arith.cmpi slt, %27, %23 : index
    cf.cond_br %31, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %32 = arith.muli %27, %22 : index
    %33 = arith.muli %0, %22 overflow<nsw> : index
    %34 = arith.muli %33, %c4 : index
    %35 = arith.muli %0, %7 overflow<nsw> : index
    %36 = arith.muli %35, %22 overflow<nsw> : index
    %37 = arith.muli %36, %c4 : index
    %38 = util.align %34, %c64 : index
    %39 = util.align %37, %c64 : index
    %40 = arith.addi %38, %39 : index
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%40} => !stream.timepoint
    %41 = arith.index_castui %33 : index to i64
    %42 = arith.index_castui %33 : index to i32
    %43 = arith.shrui %41, %c32_i64 : i64
    %44 = arith.trunci %43 : i64 to i32
    %45 = arith.index_castui %22 : index to i64
    %46 = arith.index_castui %22 : index to i32
    %47 = arith.shrui %45, %c32_i64 : i64
    %48 = arith.trunci %47 : i64 to i32
    %49 = arith.index_castui %32 : index to i64
    %50 = arith.index_castui %32 : index to i32
    %51 = arith.shrui %49, %c32_i64 : i64
    %52 = arith.trunci %51 : i64 to i32
    %53 = arith.index_castui %0 : index to i64
    %54 = arith.index_castui %0 : index to i32
    %55 = arith.shrui %53, %c32_i64 : i64
    %56 = arith.trunci %55 : i64 to i32
    %57 = arith.index_castui %1 : index to i64
    %58 = arith.index_castui %1 : index to i32
    %59 = arith.shrui %57, %c32_i64 : i64
    %60 = arith.trunci %59 : i64 to i32
    %61 = arith.index_castui %38 : index to i64
    %62 = arith.index_castui %38 : index to i32
    %63 = arith.shrui %61, %c32_i64 : i64
    %64 = arith.trunci %63 : i64 to i32
    %65 = arith.index_castui %36 : index to i64
    %66 = arith.index_castui %36 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %19 : index to i64
    %70 = arith.index_castui %19 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = arith.index_castui %6 : index to i64
    %74 = arith.index_castui %6 : index to i32
    %75 = arith.shrui %73, %c32_i64 : i64
    %76 = arith.trunci %75 : i64 to i32
    %77 = arith.index_castui %7 : index to i64
    %78 = arith.index_castui %7 : index to i32
    %79 = arith.shrui %77, %c32_i64 : i64
    %80 = arith.trunci %79 : i64 to i32
    %81 = arith.index_castui %8 : index to i64
    %82 = arith.index_castui %8 : index to i32
    %83 = arith.shrui %81, %c32_i64 : i64
    %84 = arith.trunci %83 : i64 to i32
    %85 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%4 as %arg7: !stream.resource<external>{%3}, %21 as %arg8: !stream.resource<external>{%20}, %12 as %arg9: !stream.resource<external>{%11}, %result_0 as %arg10: !stream.resource<transient>{%40}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_0::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_0_elementwise_broadcast_D_f32[%33, %22, %32, %0, %1](%42, %44, %46, %48, %50, %52, %54, %56, %58, %60 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %3] : !stream.resource<external>{%3},
        wo %arg10[%c0 for %40] : !stream.resource<transient>{%40}
      }
      stream.cmd.dispatch @mx8_grouped_f32_dispatch_1::@vulkan_spirv_fb::@mx8_grouped_f32_dispatch_1_elementwise_broadcast_D_f32[%36, %22, %32, %19, %6, %7, %8](%62, %64, %66, %68, %46, %48, %50, %52, %70, %72, %74, %76, %78, %80, %82, %84 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg9[%c0 for %11] : !stream.resource<external>{%11},
        wo %arg10[%c0 for %40] : !stream.resource<transient>{%40}
      }
    } => !stream.timepoint
    %86 = arith.muli %25, %22 : index
    %87 = stream.timepoint.await %85 => %result_0 : !stream.resource<transient>{%40}
    %88 = stream.resource.subview %87[%c0] : !stream.resource<transient>{%40} -> !stream.resource<transient>{%34}
    %89 = stream.resource.subview %87[%38] : !stream.resource<transient>{%40} -> !stream.resource<transient>{%37}
    %90 = util.optimization_barrier %88 : !stream.resource<transient>
    %91 = util.optimization_barrier %89 : !stream.resource<transient>
    %92 = arith.muli %24, %22 : index
    %93 = arith.muli %35, %c2 : index
    %94 = util.align %25, %c64 : index
    %95 = util.align %93, %c64 : index
    %96 = arith.addi %94, %95 : index
    %result_2, %result_timepoint_3 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%96} => !stream.timepoint
    %97 = arith.index_castui %94 : index to i64
    %98 = arith.index_castui %94 : index to i32
    %99 = arith.shrui %97, %c32_i64 : i64
    %100 = arith.trunci %99 : i64 to i32
    %101 = arith.index_castui %35 : index to i64
    %102 = arith.index_castui %35 : index to i32
    %103 = arith.shrui %101, %c32_i64 : i64
    %104 = arith.trunci %103 : i64 to i32
    %105 = arith.index_castui %27 : index to i64
    %106 = arith.index_castui %27 : index to i32
    %107 = arith.shrui %105, %c32_i64 : i64
    %108 = arith.trunci %107 : i64 to i32
    %109 = arith.index_castui %13 : index to i64
    %110 = arith.index_castui %13 : index to i32
    %111 = arith.shrui %109, %c32_i64 : i64
    %112 = arith.trunci %111 : i64 to i32
    %113 = arith.index_castui %14 : index to i64
    %114 = arith.index_castui %14 : index to i32
    %115 = arith.shrui %113, %c32_i64 : i64
    %116 = arith.trunci %115 : i64 to i32
    %117 = arith.index_castui %15 : index to i64
    %118 = arith.index_castui %15 : index to i32
    %119 = arith.shrui %117, %c32_i64 : i64
    %120 = arith.trunci %119 : i64 to i32
    %121 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_3) => with(%90 as %arg7: !stream.resource<transient>{%92}, %91 as %arg8: !stream.resource<transient>{%86}, %21 as %arg9: !stream.resource<external>{%20}, %18 as %arg10: !stream.resource<external>{%17}, %result_2 as %arg11: !stream.resource<transient>{%96}) {
      stream.cmd.dispatch @affine_linear_f32_dispatch_2::@vulkan_spirv_fb::@affine_linear_f32_dispatch_2_batch_matmul_Dx1xDxD_f32[%0, %22, %7](%54, %56, %46, %48, %78, %80 : i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0 for %92] : !stream.resource<transient>{%92},
        ro %arg8[%c0 for %86] : !stream.resource<transient>{%86},
        wo %arg11[%c0 for %96] : !stream.resource<transient>{%96}
      }
      stream.cmd.dispatch @mx4_grouped_bf16_dispatch_3::@vulkan_spirv_fb::@mx4_grouped_bf16_dispatch_3_elementwise_broadcast_D_i16[%35, %7, %27, %19, %13, %14, %15](%98, %100, %102, %104, %78, %80, %106, %108, %70, %72, %110, %112, %114, %116, %118, %120 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg9[%c0 for %20] : !stream.resource<external>{%20},
        ro %arg10[%c0 for %17] : !stream.resource<external>{%17},
        wo %arg11[%c0 for %96] : !stream.resource<transient>{%96}
      }
    } => !stream.timepoint
    %122 = arith.muli %2, %7 : index
    %123 = stream.timepoint.await %121 => %result_2 : !stream.resource<transient>{%96}
    %124 = stream.resource.subview %123[%94] : !stream.resource<transient>{%96} -> !stream.resource<transient>{%93}
    %125 = util.optimization_barrier %124 : !stream.resource<transient>
    %126 = arith.muli %35, %c4 : index
    %127 = stream.timepoint.join max(%121, %30) => !stream.timepoint
    %result_4, %result_timepoint_5 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%127) => !stream.resource<transient>{%126} => !stream.timepoint
    %result_6, %result_timepoint_7 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%127) => !stream.resource<transient>{%94} => !stream.timepoint
    %128 = stream.timepoint.join max(%result_timepoint_5, %result_timepoint_7) => !stream.timepoint
    %129 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%128) => with(%28 as %arg7: !stream.resource<transient>{%29}, %result_2 as %arg8: !stream.resource<transient>{%96}, %125 as %arg9: !stream.resource<transient>{%122}, %result_4 as %arg10: !stream.resource<transient>{%126}, %result_6 as %arg11: !stream.resource<transient>{%94}) {
      stream.cmd.copy %arg7[%c0], %arg11[%c0], %25 : !stream.resource<transient>{%25} -> !stream.resource<transient>{%94}
      stream.cmd.dispatch @mx4_linear_bf16_dispatch_4::@vulkan_spirv_fb::@mx4_linear_bf16_dispatch_4_elementwise_broadcast_D_f32[%35, %0, %7](%102, %104, %54, %56, %78, %80 : i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %96] : !stream.resource<transient>{%96},
        ro %arg11[%c0 for %94] : !stream.resource<transient>{%94},
        ro %arg9[%c0 for %122] : !stream.resource<transient>{%122},
        wo %arg10[%c0 for %126] : !stream.resource<transient>{%126}
      }
    } => !stream.timepoint
    %130 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%129) => %result_6 : !stream.resource<transient>{%94} => !stream.timepoint
    %131 = arith.addi %27, %c1 : index
    cf.br ^bb1(%131, %result_4, %126, %130 : index, !stream.resource<transient>, index, !stream.timepoint)
  ^bb3:  // pred: ^bb1
    %132 = arith.muli %0, %7 overflow<nsw> : index
    %133 = arith.muli %132, %c2 : index
    %result_8, %result_timepoint_9 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%30) => !stream.resource<external>{%133} => !stream.timepoint
    %134 = arith.index_castui %132 : index to i64
    %135 = arith.index_castui %132 : index to i32
    %136 = arith.shrui %134, %c32_i64 : i64
    %137 = arith.trunci %136 : i64 to i32
    %138 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_9) => with(%28 as %arg7: !stream.resource<transient>{%29}, %result_8 as %arg8: !stream.resource<external>{%133}) {
      stream.cmd.dispatch @affine_linear_bf16_dispatch_4::@vulkan_spirv_fb::@affine_linear_bf16_dispatch_4_elementwise_D_f32xi16[%132](%135, %137 : i32, i32) {
        ro %arg7[%c0 for %29] : !stream.resource<transient>{%29},
        wo %arg8[%c0 for %133] : !stream.resource<external>{%133}
      }
    } => !stream.timepoint
    %139 = stream.resource.dealloca origin await(%138) => %28 : !stream.resource<transient>{%29} => !stream.timepoint
    %140 = arith.muli %2, %7 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %139 => (%arg6 : !hal.fence)
    %141 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_8 : tensor<?x?xi16>{%0, %7} in !stream.resource<external>{%140} -> !hal.buffer_view
    util.return %141 : !hal.buffer_view
  }
  hal.executable private @affine_embedding_f32_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_embedding_f32_dispatch_0_elementwise_broadcast_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_embedding_f32_dispatch_0_elementwise_broadcast_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = arith.extui %1 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %0 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %3 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %2 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %5 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %4 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %7 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %9 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %12 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %11 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49 = arith.extui %14 : i32 to i64
          %50 = arith.shli %49, %c32_i64 : i64
          %51 = arith.extui %13 : i32 to i64
          %52 = arith.ori %51, %50 : i64
          %53 = arith.index_castui %52 : i64 to index
          %54 = arith.extui %16 : i32 to i64
          %55 = arith.shli %54, %c32_i64 : i64
          %56 = arith.extui %15 : i32 to i64
          %57 = arith.ori %56, %55 : i64
          %58 = arith.index_castui %57 : i64 to index
          %59 = arith.extui %18 : i32 to i64
          %60 = arith.shli %59, %c32_i64 : i64
          %61 = arith.extui %17 : i32 to i64
          %62 = arith.ori %61, %60 : i64
          %63 = arith.index_castui %62 : i64 to index
          %64:5 = util.assume.int 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>, 
              %53<umin = 0, umax = 9007199254740991>, 
              %58<umin = 0, umax = 9007199254740991>, 
              %63<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %64#0, 4 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %64#1, 5 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %64#2, 6 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %64#3, 7 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %64#4, 8 : index
          %71 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%66}
          %72 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68}
          %73 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%69, %70}
          %74 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%65}
          %75 = iree_tensor_ext.dispatch.workload.ordinal %28, 1 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %77 = iree_tensor_ext.dispatch.workload.ordinal %38, 3 : index
          %78 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0], sizes = [%66], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%66} -> tensor<?xi32>
          %79 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0], sizes = [%67, %68], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68} -> tensor<?x?xi32>
          %80 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%69, %70], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%69, %70} -> tensor<?x?xf32>
          %81 = tensor.empty(%65) : tensor<?xf32>
          %82 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%81 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f32):
            %83 = linalg.index 0 : index
            %84 = arith.remsi %83, %75 : index
            %85 = arith.divsi %83, %75 : index
            %extracted = tensor.extract %78[%85] : tensor<?xi32>
            %86 = arith.index_cast %extracted : i32 to index
            %87 = arith.divui %84, %c32 : index
            %88 = arith.remui %84, %c32 : index
            %89 = arith.muli %87, %76 : index
            %90 = arith.muli %88, %76 : index
            %91 = arith.divui %90, %c32 : index
            %92 = arith.addi %89, %91 : index
            %93 = arith.remui %90, %c32 : index
            %94 = arith.addi %93, %76 : index
            %95 = arith.cmpi ugt, %94, %c32 : index
            %96 = arith.addi %92, %c1 : index
            %97 = arith.select %95, %96, %92 : index
            %extracted_0 = tensor.extract %79[%86, %92] : tensor<?x?xi32>
            %extracted_1 = tensor.extract %79[%86, %97] : tensor<?x?xi32>
            %98 = arith.index_castui %93 : index to i32
            %99 = arith.shrui %extracted_0, %98 : i32
            %100 = arith.subi %c32, %93 : index
            %101 = arith.index_castui %100 : index to i32
            %102 = arith.andi %101, %c31_i32 : i32
            %103 = arith.shli %extracted_1, %102 : i32
            %104 = arith.select %95, %103, %c0_i32 : i32
            %105 = arith.ori %99, %104 : i32
            %106 = arith.andi %105, %6 : i32
            %107 = arith.uitofp %106 : i32 to f32
            %108 = arith.divui %84, %77 : index
            %extracted_2 = tensor.extract %80[%86, %108] : tensor<?x?xf32>
            %109 = arith.mulf %107, %extracted_2 : f32
            linalg.yield %109 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %82, %74, offsets = [0], sizes = [%65], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%65}
          return
        }
        iree_codegen.dispatch_config @affine_embedding_f32_dispatch_0_elementwise_broadcast_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_embedding_f32_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_embedding_f32_dispatch_1_elementwise_D_f32 ordinal(0) layout(#hal.pipeline.layout<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_embedding_f32_dispatch_1_elementwise_D_f32() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = arith.extui %1 : i32 to i64
          %13 = arith.shli %12, %c32_i64 : i64
          %14 = arith.extui %0 : i32 to i64
          %15 = arith.ori %14, %13 : i64
          %16 = arith.index_castui %15 : i64 to index
          %17 = arith.extui %3 : i32 to i64
          %18 = arith.shli %17, %c32_i64 : i64
          %19 = arith.extui %2 : i32 to i64
          %20 = arith.ori %19, %18 : i64
          %21 = arith.index_castui %20 : i64 to index
          %22 = arith.extui %5 : i32 to i64
          %23 = arith.shli %22, %c32_i64 : i64
          %24 = arith.extui %4 : i32 to i64
          %25 = arith.ori %24, %23 : i64
          %26 = arith.index_castui %25 : i64 to index
          %27 = arith.extui %7 : i32 to i64
          %28 = arith.shli %27, %c32_i64 : i64
          %29 = arith.extui %6 : i32 to i64
          %30 = arith.ori %29, %28 : i64
          %31 = arith.index_castui %30 : i64 to index
          %32 = arith.extui %9 : i32 to i64
          %33 = arith.shli %32, %c32_i64 : i64
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.ori %34, %33 : i64
          %36 = arith.index_castui %35 : i64 to index
          %37 = arith.extui %11 : i32 to i64
          %38 = arith.shli %37, %c32_i64 : i64
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.ori %39, %38 : i64
          %41 = arith.index_castui %40 : i64 to index
          %42:3 = util.assume.int 
              %31<umin = 0, umax = 9007199254740991>, 
              %36<umin = 0, umax = 9007199254740991>, 
              %41<umin = 0, umax = 9007199254740991>
            : index, index, index
          %43 = iree_tensor_ext.dispatch.workload.ordinal %16, 0 : index
          %44 = iree_tensor_ext.dispatch.workload.ordinal %42#0, 3 : index
          %45 = iree_tensor_ext.dispatch.workload.ordinal %42#1, 4 : index
          %46 = iree_tensor_ext.dispatch.workload.ordinal %42#2, 5 : index
          %47 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%44}
          %48 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%45, %46}
          %49 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%43}
          %50 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%43}
          %51 = iree_tensor_ext.dispatch.workload.ordinal %21, 1 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %26, 2 : index
          %53 = iree_tensor_ext.dispatch.tensor.load %47, offsets = [0], sizes = [%44], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%44} -> tensor<?xi32>
          %54 = iree_tensor_ext.dispatch.tensor.load %48, offsets = [0, 0], sizes = [%45, %46], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf32>>{%45, %46} -> tensor<?x?xf32>
          %55 = iree_tensor_ext.dispatch.tensor.load %49, offsets = [0], sizes = [%43], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf32>>{%43} -> tensor<?xf32>
          %56 = tensor.empty(%43) : tensor<?xf32>
          %57 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%55 : tensor<?xf32>) outs(%56 : tensor<?xf32>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f32, %out: f32):
            %58 = linalg.index 0 : index
            %59 = arith.remsi %58, %52 : index
            %60 = arith.divsi %58, %52 : index
            %extracted = tensor.extract %53[%60] : tensor<?xi32>
            %61 = arith.index_cast %extracted : i32 to index
            %62 = arith.divui %59, %51 : index
            %extracted_0 = tensor.extract %54[%61, %62] : tensor<?x?xf32>
            %63 = arith.addf %in, %extracted_0 : f32
            linalg.yield %63 : f32
          } -> tensor<?xf32>
          iree_tensor_ext.dispatch.tensor.store %57, %50, offsets = [0], sizes = [%43], strides = [1] : tensor<?xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf32>>{%43}
          return
        }
        iree_codegen.dispatch_config @affine_embedding_f32_dispatch_1_elementwise_D_f32 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_embedding_f32(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: !hal.fence, %arg7: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_embedding_f32(%input0: tensor<?x?xi32>, %input1: tensor<?x?xf32>, %input2: tensor<?x?xf32>, %input3: tensor<?xi32>, %input4: i32, %input5: i32) -> (%output0: tensor<?x?xf32>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c4 = arith.constant 4 : index
    %c1_i32 = arith.constant 1 : i32
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg6 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f32 = hal.element_type<f32> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_f32) encoding(%dense_row_major)
    %8 = arith.muli %6, %c4 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf32>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f32) encoding(%dense_row_major)
    %13 = arith.muli %11, %c4 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf32>{%11, %12} in !stream.resource<external>{%14}
    %16 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%16]) type(%element_type_i32) encoding(%dense_row_major)
    %17 = arith.muli %16, %c4 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%16} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg4 : i32 to index
    %20 = arith.muli %7, %19 : index
    %21 = arith.muli %16, %20 overflow<nsw> : index
    %22 = arith.shli %c1_i32, %arg5 : i32
    %23 = arith.index_cast %arg5 : i32 to index
    %24 = arith.subi %22, %c1_i32 : i32
    %25 = arith.muli %21, %c4 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%25} => !stream.timepoint
    %26 = arith.index_castui %21 : index to i64
    %27 = arith.index_castui %21 : index to i32
    %28 = arith.shrui %26, %c32_i64 : i64
    %29 = arith.trunci %28 : i64 to i32
    %30 = arith.index_castui %20 : index to i64
    %31 = arith.index_castui %20 : index to i32
    %32 = arith.shrui %30, %c32_i64 : i64
    %33 = arith.trunci %32 : i64 to i32
    %34 = arith.index_castui %23 : index to i64
    %35 = arith.index_castui %23 : index to i32
    %36 = arith.shrui %34, %c32_i64 : i64
    %37 = arith.trunci %36 : i64 to i32
    %38 = arith.index_castui %19 : index to i64
    %39 = arith.index_castui %19 : index to i32
    %40 = arith.shrui %38, %c32_i64 : i64
    %41 = arith.trunci %40 : i64 to i32
    %42 = arith.index_castui %16 : index to i64
    %43 = arith.index_castui %16 : index to i32
    %44 = arith.shrui %42, %c32_i64 : i64
    %45 = arith.trunci %44 : i64 to i32
    %46 = arith.index_castui %0 : index to i64
    %47 = arith.index_castui %0 : index to i32
    %48 = arith.shrui %46, %c32_i64 : i64
    %49 = arith.trunci %48 : i64 to i32
    %50 = arith.index_castui %1 : index to i64
    %51 = arith.index_castui %1 : index to i32
    %52 = arith.shrui %50, %c32_i64 : i64
    %53 = arith.trunci %52 : i64 to i32
    %54 = arith.index_castui %6 : index to i64
    %55 = arith.index_castui %6 : index to i32
    %56 = arith.shrui %54, %c32_i64 : i64
    %57 = arith.trunci %56 : i64 to i32
    %58 = arith.index_castui %7 : index to i64
    %59 = arith.index_castui %7 : index to i32
    %60 = arith.shrui %58, %c32_i64 : i64
    %61 = arith.trunci %60 : i64 to i32
    %62 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%18 as %arg8: !stream.resource<external>{%17}, %4 as %arg9: !stream.resource<external>{%3}, %10 as %arg10: !stream.resource<external>{%9}, %result as %arg11: !stream.resource<transient>{%25}) {
      stream.cmd.dispatch @affine_embedding_f32_dispatch_0::@vulkan_spirv_fb::@affine_embedding_f32_dispatch_0_elementwise_broadcast_D_f32[%21, %20, %23, %19, %16, %0, %1, %6, %7](%27, %29, %31, %33, %35, %37, %24, %39, %41, %43, %45, %47, %49, %51, %53, %55, %57, %59, %61 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg10[%c0 for %9] : !stream.resource<external>{%9},
        wo %arg11[%c0 for %25] : !stream.resource<transient>{%25}
      }
    } => !stream.timepoint
    %63 = stream.timepoint.await %62 => %result : !stream.resource<transient>{%25}
    %64 = util.optimization_barrier %63 : !stream.resource<transient>
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%25} => !stream.timepoint
    %65 = arith.index_castui %11 : index to i64
    %66 = arith.index_castui %11 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %12 : index to i64
    %70 = arith.index_castui %12 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%18 as %arg8: !stream.resource<external>{%17}, %15 as %arg9: !stream.resource<external>{%14}, %64 as %arg10: !stream.resource<transient>{%25}, %result_0 as %arg11: !stream.resource<external>{%25}) {
      stream.cmd.dispatch @affine_embedding_f32_dispatch_1::@vulkan_spirv_fb::@affine_embedding_f32_dispatch_1_elementwise_D_f32[%21, %19, %20, %16, %11, %12](%27, %29, %39, %41, %31, %33, %43, %45, %66, %68, %70, %72 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg9[%c0 for %14] : !stream.resource<external>{%14},
        ro %arg10[%c0 for %25] : !stream.resource<transient>{%25},
        wo %arg11[%c0 for %25] : !stream.resource<external>{%25}
      }
    } => !stream.timepoint
    %74 = arith.muli %17, %20 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %73 => (%arg7 : !hal.fence)
    %75 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_0 : tensor<?x?xf32>{%16, %20} in !stream.resource<external>{%74} -> !hal.buffer_view
    util.return %75 : !hal.buffer_view
  }
  hal.executable private @affine_embedding_f16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_embedding_f16_dispatch_0_elementwise_broadcast_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_embedding_f16_dispatch_0_elementwise_broadcast_D_f16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = arith.extui %1 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %0 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %3 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %2 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %5 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %4 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %7 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %9 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %12 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %11 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49 = arith.extui %14 : i32 to i64
          %50 = arith.shli %49, %c32_i64 : i64
          %51 = arith.extui %13 : i32 to i64
          %52 = arith.ori %51, %50 : i64
          %53 = arith.index_castui %52 : i64 to index
          %54 = arith.extui %16 : i32 to i64
          %55 = arith.shli %54, %c32_i64 : i64
          %56 = arith.extui %15 : i32 to i64
          %57 = arith.ori %56, %55 : i64
          %58 = arith.index_castui %57 : i64 to index
          %59 = arith.extui %18 : i32 to i64
          %60 = arith.shli %59, %c32_i64 : i64
          %61 = arith.extui %17 : i32 to i64
          %62 = arith.ori %61, %60 : i64
          %63 = arith.index_castui %62 : i64 to index
          %64:5 = util.assume.int 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>, 
              %53<umin = 0, umax = 9007199254740991>, 
              %58<umin = 0, umax = 9007199254740991>, 
              %63<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %64#0, 4 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %64#1, 5 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %64#2, 6 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %64#3, 7 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %64#4, 8 : index
          %71 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%66}
          %72 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68}
          %73 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%69, %70}
          %74 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%65}
          %75 = iree_tensor_ext.dispatch.workload.ordinal %28, 1 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %77 = iree_tensor_ext.dispatch.workload.ordinal %38, 3 : index
          %78 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0], sizes = [%66], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%66} -> tensor<?xi32>
          %79 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0], sizes = [%67, %68], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68} -> tensor<?x?xi32>
          %80 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%69, %70], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%69, %70} -> tensor<?x?xf16>
          %81 = tensor.empty(%65) : tensor<?xf16>
          %82 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%81 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: f16):
            %83 = linalg.index 0 : index
            %84 = arith.remsi %83, %75 : index
            %85 = arith.divsi %83, %75 : index
            %extracted = tensor.extract %78[%85] : tensor<?xi32>
            %86 = arith.index_cast %extracted : i32 to index
            %87 = arith.divui %84, %c32 : index
            %88 = arith.remui %84, %c32 : index
            %89 = arith.muli %87, %76 : index
            %90 = arith.muli %88, %76 : index
            %91 = arith.divui %90, %c32 : index
            %92 = arith.addi %89, %91 : index
            %93 = arith.remui %90, %c32 : index
            %94 = arith.addi %93, %76 : index
            %95 = arith.cmpi ugt, %94, %c32 : index
            %96 = arith.addi %92, %c1 : index
            %97 = arith.select %95, %96, %92 : index
            %extracted_0 = tensor.extract %79[%86, %92] : tensor<?x?xi32>
            %extracted_1 = tensor.extract %79[%86, %97] : tensor<?x?xi32>
            %98 = arith.index_castui %93 : index to i32
            %99 = arith.shrui %extracted_0, %98 : i32
            %100 = arith.subi %c32, %93 : index
            %101 = arith.index_castui %100 : index to i32
            %102 = arith.andi %101, %c31_i32 : i32
            %103 = arith.shli %extracted_1, %102 : i32
            %104 = arith.select %95, %103, %c0_i32 : i32
            %105 = arith.ori %99, %104 : i32
            %106 = arith.andi %105, %6 : i32
            %107 = arith.uitofp %106 : i32 to f32
            %108 = arith.divui %84, %77 : index
            %extracted_2 = tensor.extract %80[%86, %108] : tensor<?x?xf16>
            %109 = arith.extf %extracted_2 : f16 to f32
            %110 = arith.mulf %107, %109 : f32
            %111 = arith.truncf %110 : f32 to f16
            linalg.yield %111 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %82, %74, offsets = [0], sizes = [%65], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%65}
          return
        }
        iree_codegen.dispatch_config @affine_embedding_f16_dispatch_0_elementwise_broadcast_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_embedding_f16_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_embedding_f16_dispatch_1_elementwise_D_f16 ordinal(0) layout(#hal.pipeline.layout<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_embedding_f16_dispatch_1_elementwise_D_f16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = arith.extui %1 : i32 to i64
          %13 = arith.shli %12, %c32_i64 : i64
          %14 = arith.extui %0 : i32 to i64
          %15 = arith.ori %14, %13 : i64
          %16 = arith.index_castui %15 : i64 to index
          %17 = arith.extui %3 : i32 to i64
          %18 = arith.shli %17, %c32_i64 : i64
          %19 = arith.extui %2 : i32 to i64
          %20 = arith.ori %19, %18 : i64
          %21 = arith.index_castui %20 : i64 to index
          %22 = arith.extui %5 : i32 to i64
          %23 = arith.shli %22, %c32_i64 : i64
          %24 = arith.extui %4 : i32 to i64
          %25 = arith.ori %24, %23 : i64
          %26 = arith.index_castui %25 : i64 to index
          %27 = arith.extui %7 : i32 to i64
          %28 = arith.shli %27, %c32_i64 : i64
          %29 = arith.extui %6 : i32 to i64
          %30 = arith.ori %29, %28 : i64
          %31 = arith.index_castui %30 : i64 to index
          %32 = arith.extui %9 : i32 to i64
          %33 = arith.shli %32, %c32_i64 : i64
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.ori %34, %33 : i64
          %36 = arith.index_castui %35 : i64 to index
          %37 = arith.extui %11 : i32 to i64
          %38 = arith.shli %37, %c32_i64 : i64
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.ori %39, %38 : i64
          %41 = arith.index_castui %40 : i64 to index
          %42:3 = util.assume.int 
              %31<umin = 0, umax = 9007199254740991>, 
              %36<umin = 0, umax = 9007199254740991>, 
              %41<umin = 0, umax = 9007199254740991>
            : index, index, index
          %43 = iree_tensor_ext.dispatch.workload.ordinal %16, 0 : index
          %44 = iree_tensor_ext.dispatch.workload.ordinal %42#0, 3 : index
          %45 = iree_tensor_ext.dispatch.workload.ordinal %42#1, 4 : index
          %46 = iree_tensor_ext.dispatch.workload.ordinal %42#2, 5 : index
          %47 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%44}
          %48 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%45, %46}
          %49 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf16>>{%43}
          %50 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%43}
          %51 = iree_tensor_ext.dispatch.workload.ordinal %21, 1 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %26, 2 : index
          %53 = iree_tensor_ext.dispatch.tensor.load %47, offsets = [0], sizes = [%44], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%44} -> tensor<?xi32>
          %54 = iree_tensor_ext.dispatch.tensor.load %48, offsets = [0, 0], sizes = [%45, %46], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xf16>>{%45, %46} -> tensor<?x?xf16>
          %55 = iree_tensor_ext.dispatch.tensor.load %49, offsets = [0], sizes = [%43], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xf16>>{%43} -> tensor<?xf16>
          %56 = tensor.empty(%43) : tensor<?xf16>
          %57 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%55 : tensor<?xf16>) outs(%56 : tensor<?xf16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: f16, %out: f16):
            %58 = linalg.index 0 : index
            %59 = arith.remsi %58, %52 : index
            %60 = arith.divsi %58, %52 : index
            %extracted = tensor.extract %53[%60] : tensor<?xi32>
            %61 = arith.index_cast %extracted : i32 to index
            %62 = arith.divui %59, %51 : index
            %extracted_0 = tensor.extract %54[%61, %62] : tensor<?x?xf16>
            %63 = arith.extf %in : f16 to f32
            %64 = arith.extf %extracted_0 : f16 to f32
            %65 = arith.addf %63, %64 : f32
            %66 = arith.truncf %65 : f32 to f16
            linalg.yield %66 : f16
          } -> tensor<?xf16>
          iree_tensor_ext.dispatch.tensor.store %57, %50, offsets = [0], sizes = [%43], strides = [1] : tensor<?xf16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xf16>>{%43}
          return
        }
        iree_codegen.dispatch_config @affine_embedding_f16_dispatch_1_elementwise_D_f16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_embedding_f16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: !hal.fence, %arg7: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_embedding_f16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xf16>, %input2: tensor<?x?xf16>, %input3: tensor<?xi32>, %input4: i32, %input5: i32) -> (%output0: tensor<?x?xf16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c1_i32 = arith.constant 1 : i32
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg6 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_f16 = hal.element_type<f16> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_f16) encoding(%dense_row_major)
    %8 = arith.muli %6, %c2 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xf16>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_f16) encoding(%dense_row_major)
    %13 = arith.muli %11, %c2 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xf16>{%11, %12} in !stream.resource<external>{%14}
    %16 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%16]) type(%element_type_i32) encoding(%dense_row_major)
    %17 = arith.muli %16, %c4 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%16} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg4 : i32 to index
    %20 = arith.muli %7, %19 : index
    %21 = arith.muli %16, %20 overflow<nsw> : index
    %22 = arith.shli %c1_i32, %arg5 : i32
    %23 = arith.index_cast %arg5 : i32 to index
    %24 = arith.subi %22, %c1_i32 : i32
    %25 = arith.muli %21, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%25} => !stream.timepoint
    %26 = arith.index_castui %21 : index to i64
    %27 = arith.index_castui %21 : index to i32
    %28 = arith.shrui %26, %c32_i64 : i64
    %29 = arith.trunci %28 : i64 to i32
    %30 = arith.index_castui %20 : index to i64
    %31 = arith.index_castui %20 : index to i32
    %32 = arith.shrui %30, %c32_i64 : i64
    %33 = arith.trunci %32 : i64 to i32
    %34 = arith.index_castui %23 : index to i64
    %35 = arith.index_castui %23 : index to i32
    %36 = arith.shrui %34, %c32_i64 : i64
    %37 = arith.trunci %36 : i64 to i32
    %38 = arith.index_castui %19 : index to i64
    %39 = arith.index_castui %19 : index to i32
    %40 = arith.shrui %38, %c32_i64 : i64
    %41 = arith.trunci %40 : i64 to i32
    %42 = arith.index_castui %16 : index to i64
    %43 = arith.index_castui %16 : index to i32
    %44 = arith.shrui %42, %c32_i64 : i64
    %45 = arith.trunci %44 : i64 to i32
    %46 = arith.index_castui %0 : index to i64
    %47 = arith.index_castui %0 : index to i32
    %48 = arith.shrui %46, %c32_i64 : i64
    %49 = arith.trunci %48 : i64 to i32
    %50 = arith.index_castui %1 : index to i64
    %51 = arith.index_castui %1 : index to i32
    %52 = arith.shrui %50, %c32_i64 : i64
    %53 = arith.trunci %52 : i64 to i32
    %54 = arith.index_castui %6 : index to i64
    %55 = arith.index_castui %6 : index to i32
    %56 = arith.shrui %54, %c32_i64 : i64
    %57 = arith.trunci %56 : i64 to i32
    %58 = arith.index_castui %7 : index to i64
    %59 = arith.index_castui %7 : index to i32
    %60 = arith.shrui %58, %c32_i64 : i64
    %61 = arith.trunci %60 : i64 to i32
    %62 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%18 as %arg8: !stream.resource<external>{%17}, %4 as %arg9: !stream.resource<external>{%3}, %10 as %arg10: !stream.resource<external>{%9}, %result as %arg11: !stream.resource<transient>{%25}) {
      stream.cmd.dispatch @affine_embedding_f16_dispatch_0::@vulkan_spirv_fb::@affine_embedding_f16_dispatch_0_elementwise_broadcast_D_f16[%21, %20, %23, %19, %16, %0, %1, %6, %7](%27, %29, %31, %33, %35, %37, %24, %39, %41, %43, %45, %47, %49, %51, %53, %55, %57, %59, %61 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg10[%c0 for %9] : !stream.resource<external>{%9},
        wo %arg11[%c0 for %25] : !stream.resource<transient>{%25}
      }
    } => !stream.timepoint
    %63 = stream.timepoint.await %62 => %result : !stream.resource<transient>{%25}
    %64 = util.optimization_barrier %63 : !stream.resource<transient>
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%25} => !stream.timepoint
    %65 = arith.index_castui %11 : index to i64
    %66 = arith.index_castui %11 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %12 : index to i64
    %70 = arith.index_castui %12 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%18 as %arg8: !stream.resource<external>{%17}, %15 as %arg9: !stream.resource<external>{%14}, %64 as %arg10: !stream.resource<transient>{%25}, %result_0 as %arg11: !stream.resource<external>{%25}) {
      stream.cmd.dispatch @affine_embedding_f16_dispatch_1::@vulkan_spirv_fb::@affine_embedding_f16_dispatch_1_elementwise_D_f16[%21, %19, %20, %16, %11, %12](%27, %29, %39, %41, %31, %33, %43, %45, %66, %68, %70, %72 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg9[%c0 for %14] : !stream.resource<external>{%14},
        ro %arg10[%c0 for %25] : !stream.resource<transient>{%25},
        wo %arg11[%c0 for %25] : !stream.resource<external>{%25}
      }
    } => !stream.timepoint
    %74 = arith.muli %16, %c2 : index
    %75 = arith.muli %74, %20 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %73 => (%arg7 : !hal.fence)
    %76 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_0 : tensor<?x?xf16>{%16, %20} in !stream.resource<external>{%75} -> !hal.buffer_view
    util.return %76 : !hal.buffer_view
  }
  hal.executable private @affine_embedding_bf16_dispatch_0 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_embedding_bf16_dispatch_0_elementwise_broadcast_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_embedding_bf16_dispatch_0_elementwise_broadcast_D_i16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c32 = arith.constant 32 : index
          %c1 = arith.constant 1 : index
          %c31_i32 = arith.constant 31 : i32
          %c0 = arith.constant 0 : index
          %c0_i32 = arith.constant 0 : i32
          %0 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(12) : i32
          %13 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(13) : i32
          %14 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(14) : i32
          %15 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(15) : i32
          %16 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(16) : i32
          %17 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(17) : i32
          %18 = hal.interface.constant.load layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(18) : i32
          %19 = arith.extui %1 : i32 to i64
          %20 = arith.shli %19, %c32_i64 : i64
          %21 = arith.extui %0 : i32 to i64
          %22 = arith.ori %21, %20 : i64
          %23 = arith.index_castui %22 : i64 to index
          %24 = arith.extui %3 : i32 to i64
          %25 = arith.shli %24, %c32_i64 : i64
          %26 = arith.extui %2 : i32 to i64
          %27 = arith.ori %26, %25 : i64
          %28 = arith.index_castui %27 : i64 to index
          %29 = arith.extui %5 : i32 to i64
          %30 = arith.shli %29, %c32_i64 : i64
          %31 = arith.extui %4 : i32 to i64
          %32 = arith.ori %31, %30 : i64
          %33 = arith.index_castui %32 : i64 to index
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.shli %34, %c32_i64 : i64
          %36 = arith.extui %7 : i32 to i64
          %37 = arith.ori %36, %35 : i64
          %38 = arith.index_castui %37 : i64 to index
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.shli %39, %c32_i64 : i64
          %41 = arith.extui %9 : i32 to i64
          %42 = arith.ori %41, %40 : i64
          %43 = arith.index_castui %42 : i64 to index
          %44 = arith.extui %12 : i32 to i64
          %45 = arith.shli %44, %c32_i64 : i64
          %46 = arith.extui %11 : i32 to i64
          %47 = arith.ori %46, %45 : i64
          %48 = arith.index_castui %47 : i64 to index
          %49 = arith.extui %14 : i32 to i64
          %50 = arith.shli %49, %c32_i64 : i64
          %51 = arith.extui %13 : i32 to i64
          %52 = arith.ori %51, %50 : i64
          %53 = arith.index_castui %52 : i64 to index
          %54 = arith.extui %16 : i32 to i64
          %55 = arith.shli %54, %c32_i64 : i64
          %56 = arith.extui %15 : i32 to i64
          %57 = arith.ori %56, %55 : i64
          %58 = arith.index_castui %57 : i64 to index
          %59 = arith.extui %18 : i32 to i64
          %60 = arith.shli %59, %c32_i64 : i64
          %61 = arith.extui %17 : i32 to i64
          %62 = arith.ori %61, %60 : i64
          %63 = arith.index_castui %62 : i64 to index
          %64:5 = util.assume.int 
              %43<umin = 0, umax = 9007199254740991>, 
              %48<umin = 0, umax = 9007199254740991>, 
              %53<umin = 0, umax = 9007199254740991>, 
              %58<umin = 0, umax = 9007199254740991>, 
              %63<umin = 0, umax = 9007199254740991>
            : index, index, index, index, index
          %65 = iree_tensor_ext.dispatch.workload.ordinal %23, 0 : index
          %66 = iree_tensor_ext.dispatch.workload.ordinal %64#0, 4 : index
          %67 = iree_tensor_ext.dispatch.workload.ordinal %64#1, 5 : index
          %68 = iree_tensor_ext.dispatch.workload.ordinal %64#2, 6 : index
          %69 = iree_tensor_ext.dispatch.workload.ordinal %64#3, 7 : index
          %70 = iree_tensor_ext.dispatch.workload.ordinal %64#4, 8 : index
          %71 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%66}
          %72 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68}
          %73 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%69, %70}
          %74 = hal.interface.binding.subspan layout(<constants = 19, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%65}
          %75 = iree_tensor_ext.dispatch.workload.ordinal %28, 1 : index
          %76 = iree_tensor_ext.dispatch.workload.ordinal %33, 2 : index
          %77 = iree_tensor_ext.dispatch.workload.ordinal %38, 3 : index
          %78 = iree_tensor_ext.dispatch.tensor.load %71, offsets = [0], sizes = [%66], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%66} -> tensor<?xi32>
          %79 = iree_tensor_ext.dispatch.tensor.load %72, offsets = [0, 0], sizes = [%67, %68], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi32>>{%67, %68} -> tensor<?x?xi32>
          %80 = iree_tensor_ext.dispatch.tensor.load %73, offsets = [0, 0], sizes = [%69, %70], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%69, %70} -> tensor<?x?xi16>
          %81 = tensor.empty(%65) : tensor<?xi16>
          %82 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} outs(%81 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%out: i16):
            %83 = linalg.index 0 : index
            %84 = arith.remsi %83, %75 : index
            %85 = arith.divsi %83, %75 : index
            %extracted = tensor.extract %78[%85] : tensor<?xi32>
            %86 = arith.index_cast %extracted : i32 to index
            %87 = arith.divui %84, %c32 : index
            %88 = arith.remui %84, %c32 : index
            %89 = arith.muli %87, %76 : index
            %90 = arith.muli %88, %76 : index
            %91 = arith.divui %90, %c32 : index
            %92 = arith.addi %89, %91 : index
            %93 = arith.remui %90, %c32 : index
            %94 = arith.addi %93, %76 : index
            %95 = arith.cmpi ugt, %94, %c32 : index
            %96 = arith.addi %92, %c1 : index
            %97 = arith.select %95, %96, %92 : index
            %extracted_0 = tensor.extract %79[%86, %92] : tensor<?x?xi32>
            %extracted_1 = tensor.extract %79[%86, %97] : tensor<?x?xi32>
            %98 = arith.index_castui %93 : index to i32
            %99 = arith.shrui %extracted_0, %98 : i32
            %100 = arith.subi %c32, %93 : index
            %101 = arith.index_castui %100 : index to i32
            %102 = arith.andi %101, %c31_i32 : i32
            %103 = arith.shli %extracted_1, %102 : i32
            %104 = arith.select %95, %103, %c0_i32 : i32
            %105 = arith.ori %99, %104 : i32
            %106 = arith.andi %105, %6 : i32
            %107 = arith.uitofp %106 : i32 to f32
            %108 = arith.divui %84, %77 : index
            %extracted_2 = tensor.extract %80[%86, %108] : tensor<?x?xi16>
            %109 = arith.bitcast %extracted_2 : i16 to bf16
            %110 = arith.extf %109 : bf16 to f32
            %111 = arith.mulf %107, %110 : f32
            %112 = arith.truncf %111 : f32 to bf16
            %113 = arith.bitcast %112 : bf16 to i16
            linalg.yield %113 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %82, %74, offsets = [0], sizes = [%65], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%65}
          return
        }
        iree_codegen.dispatch_config @affine_embedding_bf16_dispatch_0_elementwise_broadcast_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: index, %arg9: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6, %arg7, %arg8, %arg9)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @affine_embedding_bf16_dispatch_1 {
    hal.executable.variant public @vulkan_spirv_fb target(<"vulkan-spirv", "vulkan-spirv-fb", {iree_codegen.target_info = #iree_gpu.target<arch = "vp_android_baseline_2022", features = "spirv:v1.3,cap:Shader,cap:Int16,cap:Float16,cap:StorageBuffer16BitAccess,cap:SignedZeroInfNanPreserve,ext:SPV_KHR_16bit_storage,ext:SPV_KHR_float_controls", wgp = <compute = fp32|int32, storage = b32, subgroup = none, subgroup_size_choices = [64], max_workgroup_sizes = [128, 128, 64], max_thread_count_per_workgroup = 128, max_workgroup_memory_bytes = 16384, max_workgroup_counts = [65535, 65535, 65535]>>}>) {
      hal.executable.export public @affine_embedding_bf16_dispatch_1_elementwise_D_i16 ordinal(0) layout(#hal.pipeline.layout<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @affine_embedding_bf16_dispatch_1_elementwise_D_i16() attributes {spirv.entry_point_abi = #spirv.entry_point_abi<workgroup_size = [64, 1, 1], target_width = 32>, translation_info = #iree_codegen.translation_info<pipeline = #iree_gpu.spirv_pipeline<BaseDistribute> workgroup_size = [64, 1, 1]>} {
          %c32_i64 = arith.constant 32 : i64
          %c0 = arith.constant 0 : index
          %0 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(0) : i32
          %1 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(1) : i32
          %2 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(2) : i32
          %3 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(3) : i32
          %4 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(4) : i32
          %5 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(5) : i32
          %6 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(6) : i32
          %7 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(7) : i32
          %8 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(8) : i32
          %9 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(9) : i32
          %10 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(10) : i32
          %11 = hal.interface.constant.load layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) ordinal(11) : i32
          %12 = arith.extui %1 : i32 to i64
          %13 = arith.shli %12, %c32_i64 : i64
          %14 = arith.extui %0 : i32 to i64
          %15 = arith.ori %14, %13 : i64
          %16 = arith.index_castui %15 : i64 to index
          %17 = arith.extui %3 : i32 to i64
          %18 = arith.shli %17, %c32_i64 : i64
          %19 = arith.extui %2 : i32 to i64
          %20 = arith.ori %19, %18 : i64
          %21 = arith.index_castui %20 : i64 to index
          %22 = arith.extui %5 : i32 to i64
          %23 = arith.shli %22, %c32_i64 : i64
          %24 = arith.extui %4 : i32 to i64
          %25 = arith.ori %24, %23 : i64
          %26 = arith.index_castui %25 : i64 to index
          %27 = arith.extui %7 : i32 to i64
          %28 = arith.shli %27, %c32_i64 : i64
          %29 = arith.extui %6 : i32 to i64
          %30 = arith.ori %29, %28 : i64
          %31 = arith.index_castui %30 : i64 to index
          %32 = arith.extui %9 : i32 to i64
          %33 = arith.shli %32, %c32_i64 : i64
          %34 = arith.extui %8 : i32 to i64
          %35 = arith.ori %34, %33 : i64
          %36 = arith.index_castui %35 : i64 to index
          %37 = arith.extui %11 : i32 to i64
          %38 = arith.shli %37, %c32_i64 : i64
          %39 = arith.extui %10 : i32 to i64
          %40 = arith.ori %39, %38 : i64
          %41 = arith.index_castui %40 : i64 to index
          %42:3 = util.assume.int 
              %31<umin = 0, umax = 9007199254740991>, 
              %36<umin = 0, umax = 9007199254740991>, 
              %41<umin = 0, umax = 9007199254740991>
            : index, index, index
          %43 = iree_tensor_ext.dispatch.workload.ordinal %16, 0 : index
          %44 = iree_tensor_ext.dispatch.workload.ordinal %42#0, 3 : index
          %45 = iree_tensor_ext.dispatch.workload.ordinal %42#1, 4 : index
          %46 = iree_tensor_ext.dispatch.workload.ordinal %42#2, 5 : index
          %47 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%44}
          %48 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%45, %46}
          %49 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(2) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi16>>{%43}
          %50 = hal.interface.binding.subspan layout(<constants = 12, bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(3) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%43}
          %51 = iree_tensor_ext.dispatch.workload.ordinal %21, 1 : index
          %52 = iree_tensor_ext.dispatch.workload.ordinal %26, 2 : index
          %53 = iree_tensor_ext.dispatch.tensor.load %47, offsets = [0], sizes = [%44], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi32>>{%44} -> tensor<?xi32>
          %54 = iree_tensor_ext.dispatch.tensor.load %48, offsets = [0, 0], sizes = [%45, %46], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?x?xi16>>{%45, %46} -> tensor<?x?xi16>
          %55 = iree_tensor_ext.dispatch.tensor.load %49, offsets = [0], sizes = [%43], strides = [1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<?xi16>>{%43} -> tensor<?xi16>
          %56 = tensor.empty(%43) : tensor<?xi16>
          %57 = linalg.generic {indexing_maps = [affine_map<(d0) -> (d0)>, affine_map<(d0) -> (d0)>], iterator_types = ["parallel"]} ins(%55 : tensor<?xi16>) outs(%56 : tensor<?xi16>) attrs =  {lowering_config = #iree_codegen.lowering_config<tile_sizes = [[64], [1]]>} {
          ^bb0(%in: i16, %out: i16):
            %58 = linalg.index 0 : index
            %59 = arith.remsi %58, %52 : index
            %60 = arith.divsi %58, %52 : index
            %extracted = tensor.extract %53[%60] : tensor<?xi32>
            %61 = arith.index_cast %extracted : i32 to index
            %62 = arith.divui %59, %51 : index
            %extracted_0 = tensor.extract %54[%61, %62] : tensor<?x?xi16>
            %63 = arith.bitcast %in : i16 to bf16
            %64 = arith.extf %63 : bf16 to f32
            %65 = arith.bitcast %extracted_0 : i16 to bf16
            %66 = arith.extf %65 : bf16 to f32
            %67 = arith.addf %64, %66 : f32
            %68 = arith.truncf %67 : f32 to bf16
            %69 = arith.bitcast %68 : bf16 to i16
            linalg.yield %69 : i16
          } -> tensor<?xi16>
          iree_tensor_ext.dispatch.tensor.store %57, %50, offsets = [0], sizes = [%43], strides = [1] : tensor<?xi16> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<?xi16>>{%43}
          return
        }
        iree_codegen.dispatch_config @affine_embedding_bf16_dispatch_1_elementwise_D_i16 {
        ^bb0(%arg0: !hal.device, %arg1: index, %arg2: index, %arg3: index, %arg4: index, %arg5: index, %arg6: index):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice(%arg1, %arg2, %arg3, %arg4, %arg5, %arg6)
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @affine_embedding_bf16(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view, %arg3: !hal.buffer_view, %arg4: i32, %arg5: i32, %arg6: !hal.fence, %arg7: !hal.fence) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "async func @affine_embedding_bf16(%input0: tensor<?x?xi32>, %input1: tensor<?x?xi16>, %input2: tensor<?x?xi16>, %input3: tensor<?xi32>, %input4: i32, %input5: i32) -> (%output0: tensor<?x?xi16>)", iree.abi.model = "coarse-fences"}} {
    %c32_i64 = arith.constant 32 : i64
    %c0 = arith.constant 0 : index
    %c2 = arith.constant 2 : index
    %c4 = arith.constant 4 : index
    %c1_i32 = arith.constant 1 : i32
    %0 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[0] : index
    %1 = hal.buffer_view.dim<%arg0 : !hal.buffer_view>[1] : index
    %element_type_i32 = hal.element_type<i32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%0, %1]) type(%element_type_i32) encoding(%dense_row_major)
    %2 = arith.muli %0, %c4 : index
    %3 = arith.muli %2, %1 : index
    %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<?x?xi32>{%0, %1} in !stream.resource<external>{%3}
    %5 = stream.timepoint.import on(#hal.device.affinity<@__device_0>) %arg6 : (!hal.fence) => !stream.timepoint
    %6 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[0] : index
    %7 = hal.buffer_view.dim<%arg1 : !hal.buffer_view>[1] : index
    %element_type_i16 = hal.element_type<i16> : i32
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%6, %7]) type(%element_type_i16) encoding(%dense_row_major)
    %8 = arith.muli %6, %c2 : index
    %9 = arith.muli %8, %7 : index
    %10 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<?x?xi16>{%6, %7} in !stream.resource<external>{%9}
    %11 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[0] : index
    %12 = hal.buffer_view.dim<%arg2 : !hal.buffer_view>[1] : index
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%11, %12]) type(%element_type_i16) encoding(%dense_row_major)
    %13 = arith.muli %11, %c2 : index
    %14 = arith.muli %13, %12 : index
    %15 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<?x?xi16>{%11, %12} in !stream.resource<external>{%14}
    %16 = hal.buffer_view.dim<%arg3 : !hal.buffer_view>[0] : index
    hal.buffer_view.assert<%arg3 : !hal.buffer_view> message("input3") shape([%16]) type(%element_type_i32) encoding(%dense_row_major)
    %17 = arith.muli %16, %c4 : index
    %18 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg3 : !hal.buffer_view -> tensor<?xi32>{%16} in !stream.resource<external>{%17}
    %19 = arith.index_cast %arg4 : i32 to index
    %20 = arith.muli %7, %19 : index
    %21 = arith.muli %16, %20 overflow<nsw> : index
    %22 = arith.shli %c1_i32, %arg5 : i32
    %23 = arith.index_cast %arg5 : i32 to index
    %24 = arith.subi %22, %c1_i32 : i32
    %25 = arith.muli %21, %c2 : index
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<transient>{%25} => !stream.timepoint
    %26 = arith.index_castui %21 : index to i64
    %27 = arith.index_castui %21 : index to i32
    %28 = arith.shrui %26, %c32_i64 : i64
    %29 = arith.trunci %28 : i64 to i32
    %30 = arith.index_castui %20 : index to i64
    %31 = arith.index_castui %20 : index to i32
    %32 = arith.shrui %30, %c32_i64 : i64
    %33 = arith.trunci %32 : i64 to i32
    %34 = arith.index_castui %23 : index to i64
    %35 = arith.index_castui %23 : index to i32
    %36 = arith.shrui %34, %c32_i64 : i64
    %37 = arith.trunci %36 : i64 to i32
    %38 = arith.index_castui %19 : index to i64
    %39 = arith.index_castui %19 : index to i32
    %40 = arith.shrui %38, %c32_i64 : i64
    %41 = arith.trunci %40 : i64 to i32
    %42 = arith.index_castui %16 : index to i64
    %43 = arith.index_castui %16 : index to i32
    %44 = arith.shrui %42, %c32_i64 : i64
    %45 = arith.trunci %44 : i64 to i32
    %46 = arith.index_castui %0 : index to i64
    %47 = arith.index_castui %0 : index to i32
    %48 = arith.shrui %46, %c32_i64 : i64
    %49 = arith.trunci %48 : i64 to i32
    %50 = arith.index_castui %1 : index to i64
    %51 = arith.index_castui %1 : index to i32
    %52 = arith.shrui %50, %c32_i64 : i64
    %53 = arith.trunci %52 : i64 to i32
    %54 = arith.index_castui %6 : index to i64
    %55 = arith.index_castui %6 : index to i32
    %56 = arith.shrui %54, %c32_i64 : i64
    %57 = arith.trunci %56 : i64 to i32
    %58 = arith.index_castui %7 : index to i64
    %59 = arith.index_castui %7 : index to i32
    %60 = arith.shrui %58, %c32_i64 : i64
    %61 = arith.trunci %60 : i64 to i32
    %62 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint) => with(%18 as %arg8: !stream.resource<external>{%17}, %4 as %arg9: !stream.resource<external>{%3}, %10 as %arg10: !stream.resource<external>{%9}, %result as %arg11: !stream.resource<transient>{%25}) {
      stream.cmd.dispatch @affine_embedding_bf16_dispatch_0::@vulkan_spirv_fb::@affine_embedding_bf16_dispatch_0_elementwise_broadcast_D_i16[%21, %20, %23, %19, %16, %0, %1, %6, %7](%27, %29, %31, %33, %35, %37, %24, %39, %41, %43, %45, %47, %49, %51, %53, %55, %57, %59, %61 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg9[%c0 for %3] : !stream.resource<external>{%3},
        ro %arg10[%c0 for %9] : !stream.resource<external>{%9},
        wo %arg11[%c0 for %25] : !stream.resource<transient>{%25}
      }
    } => !stream.timepoint
    %63 = stream.timepoint.await %62 => %result : !stream.resource<transient>{%25}
    %64 = util.optimization_barrier %63 : !stream.resource<transient>
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) await(%5) => !stream.resource<external>{%25} => !stream.timepoint
    %65 = arith.index_castui %11 : index to i64
    %66 = arith.index_castui %11 : index to i32
    %67 = arith.shrui %65, %c32_i64 : i64
    %68 = arith.trunci %67 : i64 to i32
    %69 = arith.index_castui %12 : index to i64
    %70 = arith.index_castui %12 : index to i32
    %71 = arith.shrui %69, %c32_i64 : i64
    %72 = arith.trunci %71 : i64 to i32
    %73 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%result_timepoint_1) => with(%18 as %arg8: !stream.resource<external>{%17}, %15 as %arg9: !stream.resource<external>{%14}, %64 as %arg10: !stream.resource<transient>{%25}, %result_0 as %arg11: !stream.resource<external>{%25}) {
      stream.cmd.dispatch @affine_embedding_bf16_dispatch_1::@vulkan_spirv_fb::@affine_embedding_bf16_dispatch_1_elementwise_D_i16[%21, %19, %20, %16, %11, %12](%27, %29, %39, %41, %31, %33, %43, %45, %66, %68, %70, %72 : i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg8[%c0 for %17] : !stream.resource<external>{%17},
        ro %arg9[%c0 for %14] : !stream.resource<external>{%14},
        ro %arg10[%c0 for %25] : !stream.resource<transient>{%25},
        wo %arg11[%c0 for %25] : !stream.resource<external>{%25}
      }
    } => !stream.timepoint
    %74 = arith.muli %16, %c2 : index
    %75 = arith.muli %74, %20 : index
    stream.timepoint.chain_external on(#hal.device.affinity<@__device_0>) %73 => (%arg7 : !hal.fence)
    %76 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %result_0 : tensor<?x?xi16>{%16, %20} in !stream.resource<external>{%75} -> !hal.buffer_view
    util.return %76 : !hal.buffer_view
  }
}