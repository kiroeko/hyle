"""Refresh every current Vulkan private-program owner, without IREE SDK/GPU work."""
from pathlib import Path
import argparse
import base64
import datetime as dt
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[3]
spec = importlib.util.spec_from_file_location('mlx_vk_refresh_cached', ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-grouped-fusion/build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, c = prior.b, prior.c


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--reuse-from', type=Path,
                        help='Reuse matching objects freshly compiled earlier in this same batch')
    args = parser.parse_args()
    out = STAGE / ('refresh-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'))
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    if b.identity(ROOT / 'include/hyle/compute/model_ops.h')['sha256'] != 'aa848af3f5507ede6f14286b717cfa8615be7e3c87cc35d41e4195037a643072':
        raise ValueError('Root public header freeze differs')
    records = c.read(ROOT / '.scratch/inference-foundation-review-2026-10-18/vulkan-official-bank/commands.json')
    related = c.read(ROOT / '.scratch/architecture-refactor-2026-10-18/native-inputs/vulkan-consumers/compile-recipes.json')
    templates = {
        'native': next(x['command'] for x in reversed(records) if x['tag'] == 'native-program-compile'),
        'route': next(x['command'] for x in reversed(records) if x['tag'] == 'iree-compile'),
        'graph': next(x['command'] for x in reversed(related) if x['tag'] == 'vulkan-source-compile'),
        'test': next(x['command'] for x in reversed(related) if x['tag'] == 'native-budget-test-compile'),
    }
    # The old standalone IREE recipe did not need the module's generated
    # vulkan_build.h/shader headers; the complete module refresh does.
    device_template = next(x['command'] for x in reversed(related)
                           if x['tag'] == 'native-device-compile')
    include_flags = [x for x in device_template if x.lower().startswith(('/i', '-i', '/external:i', '-external:i'))]
    for kind in ('route', 'graph', 'test'):
        existing = {x.lower() for x in templates[kind]}
        templates[kind][1:1] = [x for x in include_flags if x.lower() not in existing]
        templates[kind].insert(1, '/I' + str(ROOT / '.scratch/architecture-refactor-2026-10-18/paged-row-scorer/validation/windows-current/shaders'))
    templates['test'].insert(1, '/I' + str(ROOT / 'src/compute_provider_iree_vulkan'))
    owners = c.read(STAGE / 'owner-refresh-plan.json')['owners']
    generated = out / 'programs.cc'
    vendor = ROOT / 'third_party/iree_vulkan_runtime/programs'
    manifest = c.read(vendor / 'manifest.json')
    lines = ['// Embedded qualified upstream programs; generated, do not edit.',
             '#include "programs.h"', 'namespace hyle::compute::iree_vulkan::detail {']
    blobs = []
    for program in manifest['programs']:
        binary = base64.b64decode((vendor / program['file']).read_bytes())
        recipe = (vendor / program['recipe']).read_bytes().replace(b'\r\n', b'\n')
        if hashlib.sha256(binary).hexdigest() != program['sha256'] or len(binary) != program['bytes'] or hashlib.sha256(recipe).hexdigest() != program['recipe_sha256']:
            raise ValueError('Root must merge final MLX manifest fields before refresh')
        name = program['name']
        blobs.append(dict(name=name, bytes=len(binary), sha256=program['sha256']))
        lines.append(f'alignas(64) static constexpr unsigned char {name}_bytes[] = {{')
        lines.extend(','.join(f'0x{x:02x}' for x in binary[i:i+24]) + ',' for i in range(0, len(binary), 24))
        lines.extend(['};', f'std::span<const unsigned char> {name}_program() noexcept {{ return {name}_bytes; }}'])
    lines.append('}')
    generated.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    c.save(out / 'embedded-module-identities.json', dict(modules=blobs, other_six_modules_unchanged=True))
    rows = []
    for name in [*owners, 'tests/compute_route_vulkan/iree_test.cc',
                 'tests/graph_route_vulkan/iree_test.cc', 'tests/compute_provider_iree_vulkan/native_test.cc']:
        source = ROOT / name
        kind = 'native' if name.startswith('src/compute_provider_iree_vulkan/') else (
            'route' if name.startswith('src/compute_route_vulkan/') else
            'graph' if name.startswith('src/graph_route_vulkan/') else 'test')
        tag = name.replace('/', '--').removesuffix('.cc')
        command = b.host_command(templates[kind], source, tag, out)
        rows.append(dict(tag=tag, source=b.identity(source), command=command,
                         object=str(out / (tag + '.obj'))))
    rows.append(dict(tag='embedded-programs', source=b.identity(generated),
        command=b.host_command(templates['native'], generated, 'embedded-programs', out),
        object=str(out / 'embedded-programs.obj')))
    if args.reuse_from:
        previous_plan = c.read(args.reuse_from / 'plan.json')
        if previous_plan['public_header'] != b.identity(ROOT / 'include/hyle/compute/model_ops.h'):
            raise ValueError('Previous same-batch public header differs')
        for header in c.read(STAGE / 'owner-refresh-plan.json')['private_headers']:
            if b.identity(ROOT / header['path'])['sha256'] != header['sha256']:
                raise ValueError('Current same-batch private protocol differs')
        for row in rows:
            old_path = args.reuse_from / (row['tag'] + '-identity.json')
            if not old_path.exists():
                continue
            old = c.read(old_path)
            if old['source'] != row['source'] or not b.same(old['object']):
                raise ValueError('Earlier same-batch object/source differs')
            row.update(command=old['command'], object=old['object']['path'],
                       reused_same_batch=str(old_path))
    plan = dict(compile=rows, host_TUs=len(rows), native_runtime_SDK_rebuilt=False,
                GPU_run=False, linked=False, public_header=b.identity(ROOT / 'include/hyle/compute/model_ops.h'))
    c.save(out / 'plan.json', plan)
    print('PLAN', out / 'plan.json', flush=True)
    if not args.build:
        return
    env, _ = b.environment(rows[0]['command'], [], out)
    for row in rows:
        if row.get('reused_same_batch'):
            c.save(out / (row['tag'] + '-identity.json'), c.read(row['reused_same_batch']))
            continue
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        c.save(out / (row['tag'] + '-identity.json'), dict(command=row['command'],
            source=row['source'], object=b.identity(row['object'])))
    c.save(out / 'summary.json', dict(compiled=len(rows), passed=True, SDK_build=False, GPU_run=False, linked=False))


if __name__ == '__main__':
    main()
