"""Compile changed Vulkan MLX adapter/VM owner/tests only; never submit GPU work."""
from pathlib import Path
import importlib.util
import datetime as dt
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[4]
STAGE = Path(__file__).resolve().parent
OUT = STAGE / ('host-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'))
OUT.mkdir(exist_ok=False)
(OUT / 'tmp').mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('mlx_vk_cached_helpers', ROOT / '.scratch/architecture-refactor-2026-10-18/cuda-grouped-fusion/build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, c = prior.b, prior.c
history = c.read(ROOT / '.scratch/inference-foundation-review-2026-10-18/vulkan-official-bank/commands.json')
test_history = c.read(ROOT / '.scratch/architecture-refactor-2026-10-18/native-inputs/vulkan-consumers/compile-recipes.json')
rows = []
for tag, source, recipe_tag, entries in (
    ('native-program', 'src/compute_provider_iree_vulkan/native_program.cc', 'native-program-compile', history),
    ('vulkan-mlx', 'src/compute_route_vulkan/vulkan_mlx.cc', 'iree-compile', history),
    ('mlx-test', 'tests/compute_route_vulkan/iree_test.cc', 'native-budget-test-compile', test_history),
):
    template = next(x['command'] for x in reversed(entries) if x['tag'] == recipe_tag)
    command = b.host_command(template, ROOT / source, tag, OUT)
    rows.append(dict(tag=tag, source=b.identity(ROOT / source), command=command,
                     object=str(OUT / (tag + '.obj'))))
c.save(OUT / 'compile-plan.json', dict(compile=rows, GPU_run=False, linked=False,
    public_header=b.identity(ROOT / 'include/hyle/compute/model_ops.h'),
    private_ABI='ProgramSpecV2, no old compatibility type or executor'))
env, _ = b.environment(rows[0]['command'], [], OUT)
for row in rows:
    c.execute(row['tag'] + '-compile', row['command'], env, OUT)
    c.save(OUT / (row['tag'] + '-identity.json'), dict(source=row['source'],
        object=b.identity(row['object']), command=row['command']))
c.save(OUT / 'summary.json', dict(compiled=3, passed=True, linked=False, GPU_run=False))
