"""Root-only offline packaging; never builds or starts a native consumer."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-resource-graphs-2026-10-28'
CASES = ('carrier-cpu', 'ragged-cpu', 'mtp-packed-cuda', 'mtp-sampling-cuda', 'relay-cuda')
SOURCES = ('engine/inference/prepared_program_family.h', 'engine/models/qwen35/main.cc',
           'tests/tools/inference_program_carrier_case.h', 'tests/tools/qwen_host_image_test.cc',
           'tests/tools/qwen_generation_batch_relay_probe.cc')


def read(path): return json.loads(Path(path).read_bytes())
def encode(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))
def key(path): return str(path).replace('/', '\\').casefold()
def terminal(row): assert row['state'] == 'TERMINAL' and row['exit'] == 0 and row['timed_out'] is False, row


def main():
    outjson, outzip = DEST.with_suffix('.json'), DEST.with_suffix('.zip')
    assert not outjson.exists() and not outzip.exists(), 'Preserve existing evidence'
    plan, frozen = read(W / 'plan.json'), read(W / 'source-freeze.json')
    archive, builds, cases = {}, [], []
    def add(path, name=None):
        path = Path(path); name = name or 'validation/' + path.relative_to(W).as_posix()
        assert name not in archive and 'environment' not in path.name.casefold()
        assert path.suffix.lower() not in ('.exe', '.obj', '.dll', '.lib', '.pdb', '.bin', '.safetensors', '.gguf')
        archive[name] = path.read_bytes()
    for rel in ('package.py', 'run.py', 'plan.json', 'source-freeze.json'): add(W / rel)
    dependencies = {}
    for unit in ('tiny', 'relay'):
        compiled, ready = read(W / f'compile/{unit}/compiled.json'), read(W / f'ready-{unit}.json')
        cxx, link = read(W / f'logs/compile-{unit}/process.json'), read(W / f'logs/link-{unit}/process.json')
        terminal(cxx); terminal(link)
        assert compiled['process'] == cxx and ready['compiled'] == compiled and ready['process'] == link
        assert len(ready['inputs']) == len({key(row['path']) for row in ready['inputs']}) == 228
        assert ready['inputs'][-1] == compiled['object']
        dependencies.update({key(row['path']): row for row in compiled['project_dependencies']})
        builds.append(dict(unit=unit, compile_process=cxx, link_process=link, image=ready['image'], inputs=len(ready['inputs'])))
        for rel in (f'compile/{unit}/compiled.json', f'compile/{unit}/dependencies.json', f'ready-{unit}.json'): add(W / rel)
        for stage in ('compile', 'link'):
            for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(W / f'logs/{stage}-{unit}' / filename)
    frozen_index = {key(row['path']): row for row in frozen}
    sources = [frozen_index[key(R / rel)] for rel in SOURCES]
    for row in sources:
        assert pin(row['path']) == row and dependencies[key(row['path'])] == row
        add(row['path'], 'source/' + Path(row['path']).relative_to(R).as_posix())
    fixture = plan['fixture']; assert pin(fixture['path']) == fixture
    add(fixture['path'], 'fixture/weights.tsv'); add(Path(fixture['path']).parent / 'prompt.ids', 'fixture/prompt.ids')
    for name in CASES:
        directory = W / 'runs' / name; process = read(directory / 'process.json'); terminal(process)
        report = read(directory / 'report.json')
        raw = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        statuses = [row['status'] for row in raw if 'status' in row]; assert statuses and all(status == 'PASS' for status in statuses)
        if name == 'carrier-cpu':
            assert report['exact_resource_rejection_atomic'] is True and report['exact_resource_original_graph_borrowed'] is True
        facts = [{k: v for k, v in row.items() if not isinstance(v, (dict, list))} |
                 ({'state_check_records': len(row['state_checks'])} if isinstance(row.get('state_checks'), list) else {}) for row in raw]
        cases.append(dict(name=name, process=process, facts=facts, report=pin(directory / 'report.json')))
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'report.json'): add(directory / filename)
    assert len({(row['process']['pid'], row['process']['started']) for row in cases}) == len(CASES)
    manifest = encode([dict(name=name, bytes=len(body), sha256=sha(body)) for name, body in sorted(archive.items())])
    archive['MANIFEST.json'] = manifest
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, body in sorted(archive.items()): z.writestr(name, body)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, body in archive.items(): assert sha(z.read(name)) == sha(body), name
    result = dict(schema='hyle.correctness.resource-graphs.v1', date='2026-10-28', status='PASS_FIVE_FINITE_CASES',
        change='Prepare each exact child resource-binding graph with its compiled/report/output facts before publishing the family; '
               'borrow the original concrete graph and own a specialization only when selected resource descriptions require it.',
        counts=dict(CXX=len(builds), links=len(builds), SDK_CXX=0, NVCC=0, retained_inputs=227, native_processes=len(cases)),
        source_freeze=pin(W / 'source-freeze.json'), sources=sources, builds=builds, cases=cases, fixture=fixture,
        limits=['Synthetic GA CPU/CUDA finite consumers only; no Apple/Vulkan, trained quality or performance conclusion.',
                'Exact rejection cases compile a cold finite Add family without additional native submission. Logical graph identity remains a caller contract.',
                'Original per-case state/numerical oracles and run.py parsers apply; report counts are read from actual output, not assumed.',
                '227 SDK/weights inputs per executable are inherited; pins/dependencies are included without SDK binaries, payloads or environment values.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', member_SHA256='PASS'))
    with outjson.open('xb') as out: out.write(encode(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', member_SHA256='PASS')
    with (W / 'package-readback.json').open('xb') as out: out.write(encode(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
