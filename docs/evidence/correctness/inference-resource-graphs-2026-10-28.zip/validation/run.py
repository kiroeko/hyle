"""Two current include-Model TUs, two links, five explicit finite cases."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
OLD = R / '.scratch/inference-program-installation-20261028'
SOURCE_BATCH = R / '.scratch/inference-submission-views-20261028'
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
UNITS = {'tiny': R/'tests/tools/qwen_host_image_test.cc',
         'relay': R/'tests/tools/qwen_generation_batch_relay_probe.cc'}
SOURCES = ('engine/inference/prepared_program_family.h', 'engine/models/qwen35/main.cc',
           'tests/tools/inference_program_carrier_case.h', 'tests/tools/qwen_host_image_test.cc',
           'tests/tools/qwen_generation_batch_relay_probe.cc', 'tests/tools/qwen_generation_state_case.h',
           'tests/tools/qwen_geometry_fixture.h', 'tests/tools/qwen_packed_prefill_case.h',
           'tests/tools/qwen_ragged_prefill_case.h', 'tests/tools/qwen_mtp_packed_prefill_case.h',
           'tests/tools/qwen_mtp_batch_state_case.h', 'tests/tools/qwen_mtp_sampling_case.h')
CASES = {'carrier-cpu': ('tiny','cpu','--program-carrier'),
         'ragged-cpu': ('tiny','cpu','--ragged-prefill'),
         'mtp-packed-cuda': ('tiny','cuda','--mtp-packed-prefill'),
         'mtp-sampling-cuda': ('tiny','cuda','--mtp-sampling'),
         'relay-cuda': ('relay','cuda','--cuda')}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R/'.scratch/inference-indexed-store-20261028/build.py', 'resource_graph_executor')
t.W = W


def prepare():
    prior = t.read(OLD/'plan.json'); assert len(prior['retained']) == 227
    for row in prior['retained']: t.exact(row)
    units = {}
    for name, source in UNITS.items():
        compile_args = []
        for index, arg in enumerate(prior['compile']):
            if t.key(arg) == t.key(UNITS['tiny']): arg = str(source)
            elif index and prior['compile'][index-1].casefold() == '/sourcedependencies':
                arg = str(W/'compile'/name/'dependencies.json')
            elif arg.casefold().startswith('/fo'): arg = '/Fo'+str(W/'compile'/name/'unit.obj')
            elif arg.casefold().startswith('/fd'): arg = '/Fd'+str(W/'compile'/name/'unit.pdb')
            compile_args.append(arg)
        assert sum(t.key(arg)==t.key(source) for arg in compile_args) == 1
        link_args = []
        for arg in prior['link']:
            if t.key(arg) == t.key(OLD/'compile/unit.obj'): arg = str(W/'compile'/name/'unit.obj')
            for prefix, suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
                if arg.upper().startswith(prefix): arg = prefix+str((W/'bin'/name).with_suffix(suffix)); break
            link_args.append(arg)
        assert sum(t.key(arg)==t.key(W/'compile'/name/'unit.obj') for arg in link_args) == 1
        assert not any(t.key(arg)==t.key(OLD/'compile/unit.obj') for arg in link_args)
        units[name] = dict(source=str(source), compile=compile_args, link=link_args)
    paths = {t.key(R/path):str(R/path) for path in SOURCES}
    for old in (OLD, SOURCE_BATCH):
        for row in t.read(old/'compile/compiled.json')['project_dependencies']:
            path = t.canonical(row['path'])
            if t.project(path): paths[t.key(path)] = str(path)
    env = t.read(OLD/'environment.json'); env['PATH'] = str(W/'bin')+';'+env['PATH']
    t.save(W/'environment.json', env)
    t.save(W/'plan.json', dict(base=t.pin(OLD/'plan.json'), retained=prior['retained'], units=units,
        runtime=prior['runtime'], fixture=t.pin(PLAIN/'weights.tsv'), prompt=t.pin(PLAIN/'prompt.ids'),
        sources=list(paths.values()), counts=dict(CXX=2,links=2,SDK_CXX=0,NVCC=0,inputs_each=228,
            retained_inputs=227,native_processes=5,downloads=0)))
    print('PREPARED: two current TUs and links; retained 227; no compiler/native started')


def freeze():
    plan = t.read(W/'plan.json')
    t.save(W/'source-freeze.json', [t.pin(path) for path in plan['sources']])
    print('SOURCE FROZEN', len(plan['sources']))


def validate():
    for row in t.read(W/'source-freeze.json'): t.exact(row)
    return t.read(W/'plan.json')


def parse_compile(name):
    plan = validate(); directory = W/'compile'/name
    process = t.read(W/'logs'/('compile-'+name)/'process.json'); assert process['exit']==0
    deps = [t.pin(path) for path in t.dep_paths(directory/'dependencies.json') if t.project(path)]
    t.save(directory/'compiled.json', dict(source=t.pin(plan['units'][name]['source']),
        object=t.pin(directory/'unit.obj'), process=process, project_dependencies=deps))
    print('CXX METADATA PASS', name, process['pid'])


def compile(name):
    plan = validate(); (W/'compile'/name).mkdir(parents=True)
    t.execute(plan['units'][name]['compile'], W/'logs'/('compile-'+name), 300)
    parse_compile(name)


def link(name):
    plan = validate(); compiled = t.read(W/'compile'/name/'compiled.json'); t.exact(compiled['object'])
    for row in plan['retained']: t.exact(row)
    (W/'bin').mkdir(exist_ok=True)
    native = plan['runtime']; alias = W/'bin'/Path(native['path']).name
    if not alias.exists():
        try: alias.hardlink_to(native['path'])
        except FileExistsError: pass  # Independent links can create this same real DLL alias.
    assert alias.samefile(native['path'])
    process = t.execute(plan['units'][name]['link'], W/'logs'/('link-'+name), 240)
    t.save(W/f'ready-{name}.json', dict(image=t.pin(W/'bin'/f'{name}.exe'),
        inputs=plan['retained']+[compiled['object']], compiled=compiled, process=process,
        runtime=native, source_freeze=t.pin(W/'source-freeze.json')))
    print('LINK PASS', name, process['pid'])


def parse(name):
    unit, backend, flag = CASES[name]; out = W/'runs'/name
    process = t.read(out/'process.json'); assert process['exit']==0 and not process['timed_out']
    reports = [json.loads(line) for line in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if name == 'carrier-cpu':
        parser = module(R/'.scratch/inference-program-carrier-20261028/run.py', 'resource_graph_carrier_parser')
        report = parser.carrier_report(reports, backend)
        for field in ('typed_io_installation','unsealed_io_rejected','foreign_io_rejected',
                      'standalone_exact_rejected','partial_installation_failed','valid_io_retry_output_checked',
                      'exact_resource_rejection_atomic','exact_resource_original_graph_borrowed'):
            assert report[field] is True, field
        assert type(report['partial_caller_writer_tested']) is bool
        assert report['partial_caller_writer_recovered'] is (True if report['partial_caller_writer_tested'] else None)
    elif name == 'mtp-sampling-cuda':
        parser = module(R/'.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py', 'resource_graph_sampler_parser')
        report = parser.sampler_reports(reports, backend)
    elif name == 'relay-cuda':
        parser = module(R/'.scratch/inference-phase-carrier-20261028/run.py', 'resource_graph_relay_parser')
        report = parser.relay_report(reports)
    else:
        assert len(reports)==1; report = reports[0]
        parser = module(R/'.scratch/inference-execution-preparation-20261028/parse.py', 'resource_graph_packed_parser')
        parser.check_report(report, backend, 'ragged' if name=='ragged-cpu' else 'mtp-packed')
    t.save(out/'report.json', report)
    print('PASS', name, 'PID', process['pid'])


def run(name):
    plan = validate(); unit, backend, flag = CASES[name]
    ready = t.read(W/f'ready-{unit}.json'); t.exact(ready['image']); t.exact(plan['fixture']); t.exact(plan['prompt'])
    args = [ready['image']['path'], '--'+backend]
    if name!='carrier-cpu': args.append(str(PLAIN))
    if unit=='tiny': args.append(flag)
    t.execute(args, W/'runs'/name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare','freeze'): globals()[action]()
    elif action in ('compile','parse_compile','link','run','parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
