"""Two related host TUs for selective caller-binding withdrawal, no SDK/NVCC."""
from pathlib import Path
import concurrent.futures
import importlib.util
import argparse
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = next(p for p in S.parents if (p / 'AGENTS.md').is_file())
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('existing', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
parser = argparse.ArgumentParser()
parser.add_argument('--attempt', default='attempt1')
parser.add_argument('--summary', default='compile.json')
args = parser.parse_args()
jobs = (
    ('src/graph/resources.cc', '.scratch/paged-append-20261021/checks/attempt2/graph--resources/identity.json'),
    ('src/graph_provider_ggml_cuda/ggml_cuda_region.cc', '.scratch/architecture-refactor-2026-10-18/paired-projection-route/checks/native1/ggml_cuda_region-identity.json'),
    ('src/graph/executable.cc', '.scratch/paged-append-20261021/checks/attempt2/graph--executable/identity.json'),
)
def one(job):
    path, recipe = job
    source, recipe = R / path, R / recipe
    tag = source.parent.name + '--' + source.stem
    out = S / 'checks' / args.attempt / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    command = b.host_command(c.read(recipe)['command'], source, tag, out)
    frozen = b.identity(source)
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe), CXX=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    deps = c.read(out / (tag + '-deps.json'))['Data']
    record = dict(source=frozen, object=b.identity(out / (tag + '.obj')), command=command,
        dependencies=[b.identity(x) for x in dict.fromkeys([deps['Source'], *deps['Includes']])])
    assert h.same(frozen) and all(h.same(x) for x in record['dependencies'])
    c.save(out / 'identity.json', record)
    return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(one, jobs))
c.save(S / args.summary, dict(records=records, CXX=len(records), NVCC=0, SDK_builds=0, GPU_runs=0))
print('Selective unbind: ' + str(len(records)) + ' host TUs compiled.', flush=True)
