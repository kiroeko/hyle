"""One actual original Alice journey after changing the full state route."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
Q = Path(__file__).resolve().parent
R = Q.parents[2]
S = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_checker', S / 'run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
plan = m.read(S / 'inputs/plan.json')
case = plan['cases']['alice']
out = Q / 'first-run1'
observed = h.run(out, Q / 'linked-ready.json', ['--schedule', case['schedule']['path']])
summary = dict(passed=False, throughput_evidence=False, ready=m.identity(Q / 'linked-ready.json'),
    case='alice', runner=m.identity(__file__), purpose='First actual paged consumer route; no speed claim')
m.save(out / 'summary.json', summary)
# The single-session stdout has its own shape; retain complete raw data before
# checking against the same canonical decision trace and IDs as before.
baseline = R / '.scratch/multi-session-20261021/attempt2/baseline/alice'
prior = m.read(baseline / 'observation.json')
pairs = h.check_vectors(baseline / 'trace', out / 'trace', case['calls'])
summary['vectors'] = pairs
summary['vector_count'] = len(pairs)
summary['generated_ids_equal'] = observed['generated_ids'] == prior['generated_ids']
summary['visible_tokens_equal'] = observed['visible_tokens'] == prior['visible_tokens']
summary['passed'] = all(p['byte_equal'] for p in pairs) and summary['generated_ids_equal'] and summary['visible_tokens_equal']
m.save(out / 'summary.json', summary)
assert summary['passed'], 'Actual paged route changed endpoint bytes/IDs; raw data retained for diagnosis'
print('Real paged Qwen: original two-turn Alice journey; 18 decision vectors byte-identical.', flush=True)
