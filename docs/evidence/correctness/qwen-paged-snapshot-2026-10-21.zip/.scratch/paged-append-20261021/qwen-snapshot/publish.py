"""Freeze this executed correctness batch; no build, device work or deletion."""
from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET
import zipfile

R = Path(__file__).resolve().parents[3]
P = R / '.scratch/paged-append-20261021'
Q = P / 'qwen-snapshot'
N = P / 'unbind-native'
E = R / 'docs/evidence/correctness'
STEM = 'qwen-paged-snapshot-2026-10-21'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    try:
        name = path.relative_to(R).as_posix()
    except ValueError:
        name = str(path)
    return dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def verify(record):
    path = Path(record['path'])
    if not path.is_absolute():
        path = R / path
    actual = identity(path)
    assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], str(path)
    return actual

ready = read(Q / 'linked-ready.json')
for record in [ready['image'], ready['source'], ready['private_header'], ready['added_result'], *ready['core']]:
    verify(record)
link = read(Q / 'link1/link-plan.json')
for item in link['inputs']:
    verify(item)
assert len(link['inputs']) == 192

first = read(Q / 'first-run1/summary.json')
multi = read(Q / 'multi-run1/summary.json')
pairs = [*first['vectors'], *(p for s in multi['sessions'].values() for p in s['vectors'])]
assert first['passed'] and multi['passed'] and len(pairs) == 90
for pair in pairs:
    verify(pair['baseline'])
    verify(pair['actual'])
    assert pair['byte_equal'] and pair['baseline']['sha256'] == pair['actual']['sha256']
for name in ('first-run1', 'multi-run1'):
    execution = read(Q / name / 'result.json')
    assert execution['exit'] == 0 and not execution['throughput_evidence']
    assert execution['image']['sha256'] == ready['image']['sha256']
suite = ET.parse(Q / 'unbind-tests/validation/attempt3/tests.xml').getroot()
assert suite.attrib['tests'] == '4' and suite.attrib['failures'] == '0'
assert suite.attrib['errors'] == '0'
assert all(t.attrib.get('skipped', '0') == '0' for t in suite.findall('testsuite'))

native = read(N / 'source-freeze-final.json')
for item in native['changed_files']:
    verify(item)
native_compile = read(N / 'host-compile-report.json')
assert native_compile['CXX_passed'] == 5 and native_compile['GPU_runs'] == 0

product_paths = {
    'tools/qwen35_text/main.cc', 'tools/qwen35_text/session_state.h',
    'tools/qwen35_text/session_cache.h', 'tools/qwen35_text/CMakeLists.txt',
    'include/hyle/graph/executable.h', 'include/hyle/graph/detail/region_access.h',
    'src/graph/resources.cc', 'src/graph/executable.cc',
    'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
    'include/hyle/compute/detail/generated_result.h', 'src/compute/result.cc',
    'tests/graph/invocation_unbind_test.cc', 'tests/graph/CMakeLists.txt',
}
product_paths.update(item['path'] for item in native['changed_files'])
product = [identity(R / name) for name in sorted(product_paths)]

audit = P / 'symbolic-rows/model-state-integration-review.json'
audit_published = R / 'docs/evidence/research/model-state-integration-2026-10-21.json'
shutil.copyfile(audit, audit_published)

allowed = {'.py', '.json', '.log', '.xml', '.tsv', '.diff', '.cc', '.h', '.txt'}
files = {}
for base in (Q, N):
    for path in base.rglob('*'):
        if path.is_file() and path.suffix in allowed:
            # Apple validation may be added only after its own final receipt.
            if 'apple-host' in path.parts and not (N / 'apple-host/report.json').is_file():
                continue
            files[path.relative_to(R).as_posix()] = path
for name in product_paths:
    files['product/' + name] = R / name
for name in ('docs/developer/current-work.md', 'docs/architecture/compute-design.md',
             'docs/implementation/model-operators.md', 'tools/qwen35_text/README.md'):
    files['documentation/' + name] = R / name

# Original checker, scheduling/ID inputs and cached independent observations
# are included, while tensor payloads, binaries, SDKs and weights stay outside.
S = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21'
files[S.joinpath('run.py').relative_to(R).as_posix()] = S / 'run.py'
for path in (S / 'inputs').rglob('*'):
    if path.is_file():
        files[path.relative_to(R).as_posix()] = path
for sid in ('alice', 'bob', 'carol', 'dave'):
    base = R / '.scratch/multi-session-20261021/attempt2/baseline' / sid
    for name in ('observation.json', 'command.json', 'result.json'):
        path = base / name
        if path.is_file():
            files[path.relative_to(R).as_posix()] = path
files['research/model-state-integration-2026-10-21.json'] = audit

zpath = E / (STEM + '.zip')
manifest = []
with zipfile.ZipFile(zpath, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as archive:
    for member, path in sorted(files.items()):
        data = path.read_bytes()
        archive.writestr(member, data)
        manifest.append(dict(member=member, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(zpath) as archive:
    assert archive.testzip() is None

observation = read(Q / 'multi-run1/observation.json')
report = dict(
    schema='hyle.qwen-paged-snapshot.v1', date='2026-10-21',
    status='Executed CUDA paged complete-state consumer and final CPU ownership tests passed; prefix lookup/fork not yet executed',
    scope=dict(model='qwen35_2b official BF16; F32 GDN', device='Windows RTX 4070 12GB',
               one_original_queue=True, concurrent_gpu_execution=False, throughput_evidence=False),
    image=ready['image'], link_inputs=192, all_link_input_SHA_match=True,
    product=product,
    actual=dict(
        single=dict(vector_count=18, byte_identical=True, result=read(Q / 'first-run1/result.json')),
        multi=dict(session_count=4, retained_sessions=2, vector_count=72, byte_identical=True,
                   evictions=observation['evicted_session_ids'],
                   restored_calls=sum(s['restored_calls'] for s in observation['sessions']),
                   restored_tokens=sum(s['restored_tokens'] for s in observation['sessions']),
                   result=read(Q / 'multi-run1/result.json')),
        vector_proofs=pairs,
        final_CPU=dict(tests=4, passed=4, failures=0, skipped=0,
                       review=identity(Q / 'unbind-tests/final-core-review.json')),
        native_Vulkan_host=dict(TUs_passed=5, links=0, GPU_runs=0,
                               report=identity(N / 'host-compile-report.json'))),
    accounting={k:v for k,v in observation.items() if k.startswith('cache_') or k.startswith('effective_')},
    design=[
        'One symbolic finite-family replaces the old dense Scatter/Ragged path with 12 ordinary Graph append nodes and six paged readers; no second executor.',
        'All 12 ready KV frames, 36 conv/GDN leases, next ID and position are collected before one immutable head replacement. Original writes retire/recover before reuse.',
        'Selective caller unbind validates all affected slots before mutation, withdraws actual imports in reverse dependency order, and preserves unrelated caller ports.',
        'Shared actual arena/pool backing is charged once. N+1 distinct versions includes the serial candidate; retained old checkpoints still consume capacity.',
    ],
    reviews=dict(consumer=identity(Q / 'review/paged-snapshot-source-review.json'),
                 replay=identity(Q / 'replay-review/review.json'),
                 model_families=identity(audit_published)),
    known_limits=[
        'create_session(prefix) is source-integrated only at a complete evaluated boundary; no actual prefix lookup or fork journey yet. Arbitrary cuts/rollback are not supported by this proof.',
        'The successful consumer was executed; complete-consumer failure/cancel injection was not. Primitive accepted-write cleanup and common unbind failure gates have separate finite evidence.',
        'Diagnostic T1 after first uses still records six reader ranges and reuses one. take_append release unconditionally invalidates reader recordings; not a measured throughput conclusion.',
        'The actual linked FlashInfer provider is the retained ac20 source/object, preceding the later workspace-sizing facts reuse. Current provider source improvements are not claimed executed by this image.',
        'Fresh/COW append only on existing shared CPU/CUDA plain path; no native Apple/Vulkan append, encoded writer or exclusive in-place append claim.',
        'Native imported-owner cleanup has Vulkan host-only compilation. Apple host results, if available, are explicitly separate. No native runtime result from these compiles.',
        'Vulkan fixed outputs aliasing imported inputs cannot safely detach and explicitly return Unimplemented; escaped independent result owners must remain valid.',
        'Graph IO/workspace/capture, weights, vendor-private memory and driver allocations are outside the cache backing quota.',
        'Earlier dense capacity tests and eight-model source-family audit are historical evidence; other seven models are not promoted to complete consumers.',
        'This correctness window does not replace the latest full prefill/decode/memory/whole-session comparison in current-work.',
    ],
    regression_history='The first host-test run had three pass/one failing test expectation: successful Completion.wait already settles its observation. Corrected the test, retained original source/log/XML, and final same four cases passed with final three core objects; no product gate weakened.',
    parents=[
        'docs/evidence/correctness/paged-append-graph-2026-10-21.json',
        'docs/evidence/correctness/paged-append-symbolic-2026-10-21.json',
        'docs/evidence/correctness/qwen-session-capacity-2026-10-21.json',
    ],
    archive=identity(zpath), members=manifest,
)
if (N / 'apple-host/report.json').is_file():
    report['actual']['native_Apple_host'] = dict(report=identity(N / 'apple-host/report.json'),
        scope='Actual host TU compilation only; no linking, GPU or full model execution')
out = E / (STEM + '.json')
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(report=identity(out), archive=identity(zpath), members=len(manifest),
                      actual_model_vectors=90, builds=0, device_runs=0), ensure_ascii=False))
