"""Current real paged Qwen consumer + related core objects, zero SDK/NVCC."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
R = P.parents[1]
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
ready = c.read(S / 'ready-for-root.json')
main = c.read(ready['compile_receipt']['path'])
core = c.read(S / 'unbind/compile-final.json')['records']
result_path = S / 'result-detach/checks/attempt1/identity.json'
result = c.read(result_path)
for row in [main, *core, result]:
    assert h.same(row['source']) and h.same(row['object'])
    assert all(h.same(x) for x in row['dependencies'])
base_folder = P / 'symbolic-rows/qwen-link1'
base = c.read(base_folder / 'link-plan.json')
assert all(h.same(x) for x in base['inputs'])
replacements = {}
patterns = [('main.cc', lambda x: Path(x['path']).name == 'main.obj'),
    ('resources.cc', lambda x: Path(x['path']).stem == 'graph--resources'),
    ('executable.cc', lambda x: Path(x['path']).stem == 'graph--executable'),
    ('ggml_cuda_region.cc', lambda x: Path(x['path']).stem == 'ggml_cuda_region')]
fresh = {Path(x['source']['path']).name:x for x in [main, *core]}
for name, predicate in patterns:
    old = [x for x in base['inputs'] if predicate(x)]
    assert len(old) == 1, (name, old)
    replacements[c.key(old[0]['path'])] = fresh[name]['object']
out = S / 'link1'
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
image = out / 'qwen.exe'
inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']] + [result['object']]
command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command']
           if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
command += [result['object']['path'], '/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_folder / 'link-plan.json'),
    changed_inputs=list(replacements.values()), added_result=result['object'], CXX=0, links=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(command, [x['path'] for x in inputs], out)
c.execute('link', command, env, out)
for dll in base_folder.glob('*.dll'): os.link(dll, out / dll.name)
runtime = c.read(base_folder / 'runtime-environment.json')
runtime['PATH'] = env['PATH']
runtime['staged_dlls'] = [b.identity(x) for x in out.glob('*.dll')]
runtime['scope'] = 'Actual shared CUDA Qwen paged state consumer. No native Apple/Vulkan numerical claim.'
c.save(out / 'runtime-environment.json', runtime)
c.save(S / 'linked-ready.json', dict(image=b.identity(image), source=ready['source'], private_header=ready['private_header'],
    link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'),
    core=[x['source'] for x in core], added_result=result['source'], GPU_runs=0, CXX=0, NVCC=0, SDK_builds=0))
print('REAL_PAGED_QWEN_READY', image, flush=True)
