"""Final three core objects only; keep test/result objects and execute CPU suite."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('existing_unbind_helpers', S / 'build_unbind_test.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def main():
    out = S / 'unbind-tests/link3'
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    base_path = S / 'unbind-tests/link2/link-plan.json'
    base = c.read(base_path)
    records_path = S / 'unbind/compile-final.json'
    records = c.read(records_path)['records']
    replacements = {}
    for record in records:
        source_name = Path(record['source']['path']).name
        for old in base['inputs']:
            name = Path(old['path']).name
            if ((source_name == 'resources.cc' and name == 'graph--resources.obj') or
                (source_name == 'executable.cc' and name == 'graph--executable.obj') or
                (source_name == 'ggml_cuda_region.cc' and name in
                    ('ggml_cuda_region.obj', 'graph_provider_ggml_cuda--ggml_cuda_region.obj'))):
                replacements[c.key(old['path'])] = record['object']
    assert len(records) == len(replacements) == 3
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    assert len(inputs) == 196
    for x in inputs:
        actual = b.identity(x['path'])
        assert all(actual[k] == x[k] for k in ('bytes', 'sha256'))
    image = out / 'unbind-host.exe'
    command = [replacements.get(c.key(x), {}).get('path', x)
        for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(base_path), final_core_record=b.identity(records_path),
        replacements=replacements, CXX=0, links=1, SDK_builds=0, GPU_runs=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime,
        scope='Pure custom_test CPU only; no native GGML or CUDA Context created.'))
    run = S / 'unbind-tests/validation/attempt3'
    run.mkdir(parents=True, exist_ok=False)
    args = [str(image), '--gtest_filter=InvocationUnbind.*',
            '--gtest_output=xml:' + str(run / 'tests.xml')]
    c.save(run / 'image.json', b.identity(image))
    c.execute('tests', args, env, run)
    c.save(S / 'unbind-tests/ready-final.json', dict(image=b.identity(image),
        link_plan=b.identity(out / 'link-plan.json'),
        final_core_record=b.identity(records_path), command=args,
        test_identity=b.identity(S / 'unbind-tests/attempt3/identity.json'),
        result_identity=b.identity(S / 'result-detach/checks/attempt1/identity.json'),
        CXX=0, links=1, CPU_runs=1, GPU_runs=0, SDK_builds=0))
    print('FINAL_UNBIND_HOST_PASS', run, flush=True)


if __name__ == '__main__':
    main()
