from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;P=S.parent;R=P.parents[1]
W=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec=importlib.util.spec_from_file_location('snapshot_helpers',W/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
attempt=sys.argv[1] if len(sys.argv)>1 else 'attempt1'
out=S/'checks'/attempt;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
source=R/'tools/qwen35_text/main.cc';recipe_path=R/'.scratch/multi-session-capacity-20261021/checks/attempt1/identity.json';recipe=c.read(recipe_path)
command=b.host_command(recipe['command'],source,'main',out);frozen=b.identity(source)
c.save(out/'compile-plan.json',dict(command=command,source=frozen,private_header=b.identity(R/'tools/qwen35_text/session_state.h'),recipe=b.identity(recipe_path),CXX=1,NVCC=0,SDK_builds=0,GPU_runs=0))
env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
deps=c.read(out/'main-deps.json')['Data'];record=dict(source=frozen,object=b.identity(out/'main.obj'),command=command,dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])],CXX=1,NVCC=0,SDK_builds=0,GPU_runs=0)
assert h.same(frozen) and all(h.same(d) for d in record['dependencies'])
c.save(out/'identity.json',record);c.save(S/'compiled.json',record)
print('QWEN_SNAPSHOT_MAIN_COMPILED',out/'main.obj',flush=True)
