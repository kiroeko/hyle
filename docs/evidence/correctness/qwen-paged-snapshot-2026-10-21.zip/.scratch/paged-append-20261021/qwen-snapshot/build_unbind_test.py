"""One strict CPU host test TU; original recorded recipe, no link/device run."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = next(p for p in S.parents if (p / 'AGENTS.md').is_file())
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('existing_cpu_test_helpers', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def main():
    attempt = sys.argv[1] if len(sys.argv) > 1 else 'attempt1'
    kind = sys.argv[2] if len(sys.argv) > 2 else 'test'
    assert kind in ('test', 'result')
    out = S / ('result-detach/checks' if kind == 'result' else 'unbind-tests') / attempt
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    recipe_path = S.parent / 'checks/attempt9/graph_batch--paged_append_graph_test/identity.json'
    recipe = c.read(recipe_path)
    source = R / ('src/compute/result.cc' if kind == 'result' else
                  'tests/graph/invocation_unbind_test.cc')
    command = b.host_command(recipe['command'], source, kind, out)
    command = [x for x in command if 'HYLE_APPEND_STANDALONE' not in x]
    assert all(x in command for x in ['/W4', '/WX', '/O2', '/MD'])
    frozen = b.identity(source)
    c.save(out / 'compile-plan.json', dict(command=command,
        recipe=b.identity(recipe_path), source=frozen, CXX=1,
        SDK_builds=0, GPU_runs=0, links=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    deps = c.read(out / (kind + '-deps.json'))['Data']
    dependencies = [b.identity(x) for x in dict.fromkeys([deps['Source'], *deps['Includes']])]
    c.save(out / 'identity.json', dict(source=frozen,
        object=b.identity(out / (kind + '.obj')), command=command,
        dependencies=dependencies, recipe=b.identity(recipe_path),
        CXX=1, links=0, SDK_builds=0, GPU_runs=0))
    print('UNBIND_TEST_OBJECT_READY', out / 'identity.json', flush=True)


if __name__ == '__main__':
    main()
