"""Actual paged full-state isolation and count-bound eviction on one queue."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
Q = Path(__file__).resolve().parent
R = Q.parents[2]
S = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_checker', S / 'run.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
m = h.m
plan = m.read(S / 'inputs/plan.json')
out = Q / 'multi-run1'
observed = h.run(out, Q / 'linked-ready.json', [
    '--session-schedules', plan['manifests']['4']['manifest']['path'],
    '--max-sessions', '2', '--active-sequences', '2', '--cache-bytes', '168886272'])
summary = dict(passed=False, throughput_evidence=False, ready=m.identity(Q / 'linked-ready.json'),
    runner=m.identity(__file__), sessions={}, purpose='Real paged cache with complete immutable snapshots; no speed claim')
m.save(out / 'summary.json', summary)
assert observed['session_count'] == 4 and observed['processed_tokens'] == 239 and observed['generated_tokens'] == 36
assert observed['evicted_session_ids'] == ['bob', 'alice', 'carol', 'dave', 'alice', 'bob']
assert sum(s['restored_calls'] for s in observed['sessions']) == 18
assert sum(s['restored_tokens'] for s in observed['sessions']) == 185
for session in observed['sessions']:
    sid = session['session_id']
    case = plan['cases'][sid]
    h.check_session(session, case)
    baseline = R / '.scratch/multi-session-20261021/attempt2/baseline' / sid
    assert session['generated_ids'] == m.read(baseline / 'observation.json')['generated_ids']
    pairs = h.check_vectors(baseline / 'trace', out / 'trace' / session['trace_subdirectory'], case['calls'])
    summary['sessions'][sid] = dict(vectors=pairs, passed=all(p['byte_equal'] for p in pairs))
summary['vector_count'] = sum(len(s['vectors']) for s in summary['sessions'].values())
summary['observed_cache'] = {key:value for key,value in observed.items() if key.startswith('cache_') or key.startswith('effective_')}
summary['passed'] = summary['vector_count'] == 72 and all(s['passed'] for s in summary['sessions'].values())
m.save(out / 'summary.json', summary)
assert summary['passed'], 'Actual paged four-session endpoint differs; original bytes retained'
print('Real paged Qwen: four sessions with count-bound eviction/rebuild;72 vectors byte-identical.', flush=True)
