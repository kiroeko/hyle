// Independent text consumer. All candidate tensor mathematics uses public
// Compute/Graph operations; no native API, provider choice or oracle feedback.
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <initializer_list>
#include <limits>
#include <map>
#include <memory>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "schedule.h"
#include "session_schedule.h"
#include "session_cache.h"

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/cuda_file_stream.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/resource_budget.h"
#include "hyle/graph/batch.h"
#include "hyle/graph/cuda.h"
#include "hyle/graph/progress.h"
#include "hyle/mem/buffer.h"
#include "hyle/io/file.h"
#include "hyle/io/io_context.h"
#include "hyle/sched/join.h"
#include "hyle/sched/blocking.h"
#include "hyle/sched/scheduler.h"

namespace qwen35 {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace mem = hyle::mem;
using V = g::ValueId;
using D = g::Dimension;
constexpr D f(std::int64_t value) noexcept { return D::fixed(value); }
using Type = c::DataType;
constexpr std::int64_t hidden = 2048, intermediate = 6144, vocabulary = 248320;
constexpr char source_id[] = "4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155";
using Clock = std::chrono::steady_clock;
enum class ReplayPolicy { kAuto, kCommands, kPreferCapture };
struct StepObservation {
  std::string name;
  std::size_t input_tokens = 0, visible = 0, capture_recorded = 0, capture_reused = 0;
  std::int32_t next = 0;
  double seconds = 0, submit_seconds = 0, step_seconds = 0, cold_batch_seconds = 0;
  g::ReplayRoute replay_route = g::ReplayRoute::kUnprepared;
  bool scheduled_progress = false;
};
struct PreparationObservation {
  std::size_t slot = 0, phase_slot_prior_uses = 0;
  double layout_seconds = 0, batch_prepare_seconds = 0, replay_prepare_seconds = 0;
  double report_snapshot_seconds = 0;
  std::array<std::uint32_t, 6> nodes{};
  std::array<c::BatchPlanReport, 6> reports{};
};
void print_step_observation(const StepObservation &step) {
  std::cerr << "prepared T=" << step.input_tokens << " visible=" << step.visible
            << " replay=" << (step.replay_route == g::ReplayRoute::kCaptured ? "captured"
                : step.replay_route == g::ReplayRoute::kHybrid ? "hybrid" : "commands")
            << " cold_batch_seconds=" << step.cold_batch_seconds
            << " capture_recorded=" << step.capture_recorded
            << " capture_reused=" << step.capture_reused << '\n';
  std::cerr << step.name << " tokens=" << step.input_tokens << " visible=" << step.visible
            << " seconds=" << step.seconds << " submit_seconds=" << step.submit_seconds
            << " step_seconds=" << step.step_seconds
            << " progress=" << (step.scheduled_progress ? "scheduler" : "direct")
            << " next=" << step.next << '\n';
}
void print_preparation_observation(const StepObservation &step,
                                   const PreparationObservation &preparation) {
  const auto precision = std::cerr.precision();
  std::cerr << std::setprecision(17)
            << "preparation name=" << step.name << " tokens=" << step.input_tokens
            << " visible=" << step.visible << " slot=" << preparation.slot
            << " phase_slot_prior_uses=" << preparation.phase_slot_prior_uses
            << " native_plan_first_use=" << (preparation.phase_slot_prior_uses == 0)
            << " layout_seconds=" << preparation.layout_seconds
            << " batch_prepare_seconds=" << preparation.batch_prepare_seconds
            << " replay_prepare_seconds=" << preparation.replay_prepare_seconds
            << " report_snapshot_seconds=" << preparation.report_snapshot_seconds
            << " snapshot_after_host_endpoint=1\n";
  for (std::size_t i = 0; i < preparation.reports.size(); ++i) {
    const auto &report = preparation.reports[i];
    const auto &upload = report.metadata_upload;
    std::cerr << "batch_plan name=" << step.name << " attention_index=" << i
              << " node=" << preparation.nodes[i] << " slot=" << preparation.slot
              << " layout_generation=" << report.layout_generation
              << " metadata_staging_bytes=" << report.metadata_staging_bytes
              << " float_workspace_bytes=" << report.float_workspace_bytes
              << " int_workspace_bytes=" << report.int_workspace_bytes
              << " cta_tile_q=" << report.cta_tile_q
              << " padded_batch_size=" << report.padded_batch_size
              << " split_kv=" << report.split_kv
              << " native_metadata_unknown=" << report.native_metadata_unknown
              << " capture_compatible=" << report.capture_compatible
              << " bf16_partials=" << report.bf16_partials
              << " reused_native_plan=" << report.reused_native_plan
              << " host_waits=" << report.host_waits
              << " upload_resources=" << upload.resources << " upload_copies=" << upload.copies
              << " upload_active_copies=" << upload.active_copies << " upload_phases=" << upload.phases
              << " upload_no_op_copies=" << upload.no_op_copies
              << " upload_logical_bytes=" << upload.logical_bytes
              << " upload_physical_bytes=" << upload.physical_bytes
              << " upload_staging_bytes=" << upload.staging_bytes
              << " upload_metadata_bytes=" << upload.metadata_bytes
              << " upload_native_calls=" << upload.native_calls
              << " upload_native_waits=" << upload.native_waits
              << " upload_phase_completions=" << upload.phase_completions
              << " upload_host_waits=" << upload.host_waits
              << " upload_native_metadata_unknown=" << upload.native_metadata_unknown << '\n';
  }
  std::cerr.precision(precision);
}
constexpr bool is_end_of_generation(std::int32_t token) noexcept {
  return token == 248044 || token == 248046; // Original endoftext and tokenizer im_end.
}
constexpr std::array<const char *, 9> layer0_probe_names{
    "01-gdn-output", "02-out-proj-input", "03-out-proj-output",
    "04-down-proj-input", "05-layer-output", "06-post-attn-residual",
    "07-post-attn-norm", "08-gate-proj-output", "09-up-proj-output"};

void check(hyle::Status status) {
  if (!status.ok()) throw std::runtime_error(std::string(status.message()));
}
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
c::TensorDesc dense(Type type, std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(type, std::span(shape.begin(), shape.size())));
}
struct Tensor final {
  c::TensorDesc description;
  mem::Buffer buffer;
  c::ReadLease ready;
  Tensor() = default;
  Tensor(mem::MemoryResourceRef resource, c::TensorDesc desc)
      : description(desc), buffer(take(mem::Buffer::create(resource,
            take(desc.required_bytes()), 256))) {}
  c::TensorView view() { return take(c::TensorView::create(description, buffer.view())); }
  c::ConstTensorView read() {
    return ready ? take(ready.tensor(description)) : view().as_const();
  }
  void freeze(const c::StorageOwner &owner) {
    if (!ready) ready = take(owner.adopt_buffer(std::move(buffer)));
  }
  void zero() { check(buffer.view().fill(std::byte{})); }
  template<class T> void write(std::span<const T> values) {
    check(buffer.view().write(std::as_bytes(values)));
  }
  void dump(const std::filesystem::path &path) {
    std::vector<std::byte> bytes(buffer.size());
    check(buffer.view().read(bytes));
    std::ofstream output(path, std::ios::binary);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    if (!output) throw std::runtime_error("cannot write trace: " + path.string());
  }
};
struct State final {
  std::array<Tensor, 2> history, recurrent;
  Tensor key, value;
};
struct StateSchema final {
  c::TensorDesc history, recurrent, key, value;
};
std::array<StateSchema, 24> state_schema_for(std::size_t capacity) {
  if (capacity == 0 || capacity > 262144) throw std::runtime_error("capacity outside model context limit");
  std::array<StateSchema, 24> result;
  for (std::size_t i = 0; i < result.size(); ++i) {
    auto &layer = result[i];
    if (i % 4 == 3) {
      layer.key = dense(Type::kBFloat16, {static_cast<std::int64_t>(capacity), 512});
      layer.value = layer.key;
    } else {
      layer.history = dense(Type::kBFloat16, {1, 3, 6144});
      layer.recurrent = dense(Type::kFloat32, {1, 16, 128, 128});
    }
  }
  return result;
}
std::size_t state_bytes(const std::array<StateSchema, 24> &schema) {
  std::size_t bytes = 0;
  const auto add = [&](const c::TensorDesc &description, std::size_t copies) {
    const auto size = take(description.required_bytes());
    if (size > ((std::numeric_limits<std::size_t>::max)() - bytes) / copies)
      throw std::runtime_error("session cache byte count overflows");
    bytes += size * copies;
  };
  for (std::size_t i = 0; i < schema.size(); ++i) {
    if (i % 4 == 3) { add(schema[i].key, 1); add(schema[i].value, 1); }
    else { add(schema[i].history, 2); add(schema[i].recurrent, 2); }
  }
  return bytes;
}
struct Recipe final {
  g::GraphBuilder builder = take(g::GraphBuilder::create());
  std::vector<g::TensorSpec> specs;
  std::vector<g::ConstantBinding> constants;
  std::map<std::string, V> weights;
  std::map<std::string, Tensor> &bank;
  std::vector<Tensor> literals;
  mem::MemoryResourceRef resource;
  c::StorageOwner owner;
  g::DimensionId last_row;
  D token_rows, sample_rows;
  Recipe(std::map<std::string, Tensor> &selected, c::StorageOwner r,
         std::size_t max_query_rows)
      : bank(selected), resource(r.ref()), owner(std::move(r)) {
    // L is a zero-based last-token position, independently bound at startup.
    // T=L+1 avoids subtraction or a second independent (possibly inconsistent)
    // shape binding. All other numeric axes remain fixed model dimensions.
    last_row = take(builder.dimension({0, static_cast<std::int64_t>(max_query_rows - 1), 1}));
    token_rows = D(take(builder.dimension_sum(D(last_row), f(1))));
    sample_rows = D(take(builder.dimension_sum(token_rows, f(3))));
  }
  static g::TensorSpec dense_spec(Type type, std::span<const D> dimensions) {
    return take(g::TensorSpec::dense(type, dimensions));
  }
  static g::TensorSpec dense_spec(Type type, std::initializer_list<D> dimensions) {
    return dense_spec(type, std::span(dimensions.begin(), dimensions.size()));
  }
  const g::TensorSpec &spec(V value) const { return specs.at(value.ordinal()); }
  V remember(V value, g::TensorSpec description) {
    if (specs.size() <= value.ordinal()) specs.resize(value.ordinal() + 1);
    specs[value.ordinal()] = description;
    return value;
  }
  V input(g::TensorSpec description) { return remember(take(builder.input(description)), description); }
  V input(c::TensorDesc description) { return input(take(g::TensorSpec::concrete(description))); }
  V constant(Tensor &tensor) {
    const auto value = remember(take(builder.constant(tensor.description)),
                                take(g::TensorSpec::concrete(tensor.description)));
    tensor.freeze(owner);
    constants.push_back({value, tensor.read(), g::ConstantPolicy::kBorrow,
                         owner, tensor.ready});
    return value;
  }
  V weight(const std::string &name) {
    auto found = weights.find(name);
    if (found != weights.end()) return found->second;
    const auto value = constant(bank.at("model.language_model." + name));
    weights.emplace(name, value);
    return value;
  }
  V scalar(float value, Type type = Type::kFloat32) {
    literals.emplace_back(resource, dense(type, {1}));
    if (type == Type::kFloat32) literals.back().write<float>(std::span(&value, 1));
    else {
      auto bits = std::bit_cast<std::uint32_t>(value);
      bits += 0x7fffU + ((bits >> 16) & 1U);
      const auto bf16 = static_cast<std::uint16_t>(bits >> 16);
      literals.back().write<std::uint16_t>(std::span(&bf16, 1));
    }
    return constant(literals.back());
  }
  std::vector<V> op(c::Operation operation, std::initializer_list<V> arguments,
                    std::initializer_list<g::TensorSpec> outputs,
                    g::NodeId *node_id = nullptr) {
    const auto node = take(builder.add_node(operation,
        std::span(arguments.begin(), arguments.size()),
        std::span(outputs.begin(), outputs.size())));
    if (node_id) *node_id = node;
    std::vector<V> result;
    std::size_t index = 0;
    for (const auto &output : outputs)
      result.push_back(remember(take(builder.result(node, index++)), output));
    return result;
  }
  // Only concrete constant transforms use the Compute-only inference shortcut.
  // Symbolic operations declare their real logical outputs; each exact child
  // still runs the authoritative Compute inference during Graph compilation.
  std::vector<V> op(c::Operation operation, std::initializer_list<V> arguments) {
    std::vector<c::TensorDesc> in;
    for (auto value : arguments) in.push_back(take(spec(value).concrete_description()));
    std::vector<c::TensorDesc> out(c::operation_traits(operation).outputs);
    check(c::infer_output_descriptions(operation, in, out));
    const auto node = take(builder.add_node(operation, std::span(arguments.begin(), arguments.size())));
    std::vector<V> result;
    for (std::size_t i = 0; i < out.size(); ++i)
      result.push_back(remember(take(builder.result(node, i)), take(g::TensorSpec::concrete(out[i]))));
    return result;
  }
  template<class O> V one(O operation, std::initializer_list<V> arguments) {
    return op(c::Operation(operation), arguments).at(0);
  }
  template<class O> V one(O operation, std::initializer_list<V> arguments,
                          g::TensorSpec output, g::NodeId *node_id = nullptr) {
    return op(c::Operation(operation), arguments, {output}, node_id).at(0);
  }
  template<class O> V same(O operation, std::initializer_list<V> arguments, V source) {
    return one(operation, arguments, dense_spec(spec(source).data_type(), spec(source).dimensions()));
  }
  V cast(V x, Type type) {
    return spec(x).data_type() == type ? x :
        one(c::Cast{type}, {x}, dense_spec(type, spec(x).dimensions()));
  }
  V unary(c::UnaryKind kind, V x) { return same(c::Unary{kind}, {x}, x); }
  V binary(c::BinaryKind kind, V x, V y) {
    const auto left = spec(x), right = spec(y);
    if (left.data_type() != right.data_type()) throw std::runtime_error("binary dtype mismatch");
    const auto rank = std::max(left.rank(), right.rank());
    std::vector<D> dimensions(rank, f(1));
    for (std::size_t axis = 0; axis < rank; ++axis) {
      const auto a = axis + left.rank() < rank ? f(1) : left.dimensions()[axis + left.rank() - rank];
      const auto b = axis + right.rank() < rank ? f(1) : right.dimensions()[axis + right.rank() - rank];
      if (a == b || b == f(1)) dimensions[axis] = a;
      else if (a == f(1)) dimensions[axis] = b;
      else dimensions[axis] = D(take(builder.dimension_broadcast(a, b)));
    }
    return one(c::Binary{kind}, {x, y}, dense_spec(left.data_type(), dimensions));
  }
  V reshape(V x, std::initializer_list<D> dimensions) {
    // A fixed constant may still need the original stride-chunk Copy. Dynamic
    // views preserve inference and receive explicit Copy only where the actual
    // model layout requires it (the self-attention interleaved gate below).
    bool fixed = true;
    std::vector<std::int64_t> concrete;
    for (auto dimension : dimensions) {
      fixed = fixed && dimension.is_fixed();
      concrete.push_back(dimension.fixed_value());
    }
    if (auto input = spec(x).concrete_description(); input && fixed) {
      auto view = take(c::View::reshape(take(c::TensorShape::create(concrete))));
      auto inferred = c::infer_single_output(c::Operation(view), std::array{*input});
      if (!inferred && inferred.error().IsUnimplemented()) x = copy(x);
    }
    const auto view = take(g::ViewSpec::reshape(std::span(dimensions.begin(), dimensions.size())));
    const auto output = take(builder.add(view, x));
    return remember(output, take(g::TensorSpec::inferred(spec(x).data_type(),
        std::span(dimensions.begin(), dimensions.size()), spec(x).storage_format())));
  }
  V copy(V x) { return same(c::Copy{}, {x}, x); }
  V slice(V x, int axis, D first, D count) {
    const auto source = spec(x);
    std::vector<D> dimensions(source.dimensions().begin(), source.dimensions().end());
    dimensions.at(static_cast<std::size_t>(axis)) = count;
    const auto output = take(builder.add(take(g::ViewSpec::slice(axis, first, count)), x));
    return remember(output, take(g::TensorSpec::inferred(source.data_type(), dimensions,
                                                       source.storage_format())));
  }
  V linear(V x, const std::string &name) {
    constexpr std::array<std::int32_t, 2> axes{1, 0};
    const auto original = weight(name);
    auto dimensions = std::vector<D>(spec(x).dimensions().begin(), spec(x).dimensions().end());
    dimensions.back() = spec(original).dimensions()[0];
    auto w = one(take(c::View::permute(axes)), {original});
    return one(c::MatMul{}, {x, w}, dense_spec(spec(x).data_type(), dimensions));
  }
  V norm(V x, const std::string &name) {
    const auto type = spec(x).data_type();
    auto scale = binary(c::BinaryKind::kAdd, cast(weight(name), Type::kFloat32), scalar(1));
    const auto converted = cast(x, Type::kFloat32);
    return cast(same(c::RmsNorm{.epsilon = 1.e-6F}, {converted, scale}, converted), type);
  }
  // Literal BF16 boundaries from the independent local reference, including
  // BF16 square/sum/epsilon/rsqrt. GDN applies its own 1/sqrt(128) exactly once.
  V l2(V x) {
    const auto square = binary(c::BinaryKind::kMultiply, x, x);
    const std::array<std::int32_t, 1> axes{-1};
    auto dimensions = std::vector<D>(spec(square).dimensions().begin(), spec(square).dimensions().end());
    dimensions.back() = f(1);
    auto sum = one(c::Reduce{.kind = c::ReductionKind::kSum,
        .axes = take(c::Axes::from(axes)), .keep_dimensions = true,
        .accumulation_type = Type::kFloat32}, {square}, dense_spec(spec(square).data_type(), dimensions));
    sum = binary(c::BinaryKind::kAdd, sum, scalar(1.e-6F, Type::kBFloat16));
    return binary(c::BinaryKind::kMultiply, x, unary(c::UnaryKind::kRsqrt, sum));
  }
  V ffn(V x, const std::string &prefix, std::span<V> probes = {}) {
    auto normalized = norm(x, prefix + "post_attention_layernorm.weight");
    auto projected_gate = linear(normalized, prefix + "mlp.gate_proj.weight");
    auto gate = unary(c::UnaryKind::kSilu, projected_gate);
    auto up = linear(normalized, prefix + "mlp.up_proj.weight");
    auto product = binary(c::BinaryKind::kMultiply, gate, up);
    if (!probes.empty()) {
      probes[3] = product; probes[5] = x; probes[6] = normalized;
      probes[7] = projected_gate; probes[8] = up;
    }
    auto result = linear(product, prefix + "mlp.down_proj.weight");
    return binary(c::BinaryKind::kAdd, x, result);
  }
  void publish(V value) { check(builder.publish(value)); }
};

struct Ports final {
  V history, recurrent, next_history, next_recurrent, key, value, next_key, next_value;
};
struct FamilyPorts {
  V token_port, position_port, metadata_port, logits_port, id_port, hidden_port;
  std::array<g::NodeId, 6> attention_nodes;
  std::array<V, 9> probe_ports;
  std::array<Ports, 24> layers;
};
struct FamilyChild final {
  g::CompiledGraph compiled; // One immutable selected child shared by every session.
};
struct Family final : FamilyPorts {
  std::vector<Tensor> literals; // Backing survives every child and its slots.
  std::vector<g::TensorSpec> specs;
  c::BatchSchema attention_schema;
  g::Graph graph;
  g::CompiledGraph compiled;
  g::DimensionId last_row;
  std::vector<std::size_t> chunks;
  std::vector<std::unique_ptr<FamilyChild>> children;
};
struct Phase final : FamilyPorts {
  c::BatchSchema attention_schema;
  c::BatchLayoutVersion attention_layout;
  // The selected child is shared immutable model data, not copied per session.
  const FamilyChild *child = nullptr;
  std::array<g::Invocation, 2> slots;
  std::array<std::size_t, 2> planned_slot_uses{};
  std::array<g::ReplayMode, 2> replay_modes{};
  Tensor tokens, positions, logits, next_id, final_hidden;
  std::array<Tensor, 9> probe_outputs;
  std::array<bool, 9> probe_caller{};
};

// Each original device allocation becomes one retained lease pool;
// bounded pinned staging is the only extra payload storage.
struct WeightSourceFile final {
  hyle::io::File file;
  std::uint64_t capacity = 0;
};
hyle::sched::Task<hyle::Result<WeightSourceFile>> open_weight_source(
    mem::AllocatorRef, hyle::io::IoContext *io, std::string path) {
  auto opened = co_await hyle::io::open_file(*io, 0, path,
      {.access = hyle::io::FileAccess::kRead});
  if (!opened) co_return std::unexpected(std::move(opened).error());
  auto file = std::move(*opened);
  auto information = co_await file.info();
  if (!information) co_return std::unexpected(std::move(information).error());
  if (!information->is_regular())
    co_return std::unexpected(hyle::Status::InvalidArgument("checkpoint is not a regular file"));
  co_return WeightSourceFile{std::move(file), information->size};
}
hyle::sched::Task<hyle::Status> close_weight_source(
    mem::AllocatorRef, hyle::io::File *file) {
  co_return co_await file->close();
}
struct WeightLoadReport final {
  std::size_t bytes = 0;
  c::FileStreamReport stream;
};
WeightLoadReport load_weight_bank(const std::filesystem::path &manifest,
    const c::StorageOwner &memory, mem::MemoryResourceRef staging, c::Queue &queue,
    const c::Context &context, std::map<std::string, Tensor> &weights,
    std::vector<c::LeasePool> &weight_pools) {
  std::ifstream input(manifest);
  std::string signature, shard, identity;
  std::getline(input, signature); std::getline(input, shard); std::getline(input, identity);
  if (signature != "HYLE_QWEN35_TEXT_V1" || identity != source_id)
    throw std::runtime_error("unidentified local weight manifest");

  auto scheduler_status = hyle::Status::Ok();
  hyle::sched::Scheduler loader_scheduler(2, mem::system_allocator(), 256,
                                        &scheduler_status);
  check(scheduler_status);
  hyle::io::IoContext io(loader_scheduler, {.max_blocking_threads = 2});
  struct Shutdown final {
    hyle::sched::Scheduler &scheduler;
    ~Shutdown() { scheduler.shutdown(); }
  } shutdown{loader_scheduler}; // IO's hooks outlive the stopped workers.
  check(io.status());
  auto open_task = open_weight_source(mem::system_allocator(), &io, shard);
  if (!open_task.valid()) throw std::runtime_error("cannot allocate weight open task");
  auto source_file = take(take(hyle::sched::spawn_task_on(loader_scheduler, 0,
      mem::system_allocator(), std::move(open_task)).join()));
  // Borrow this stable File so the actual async close can be observed explicitly
  // after pipeline retirement, before any loader runtime leaves this function.
  auto source = take(c::StreamFile::borrow(source_file.file, source_file.capacity));
  std::vector<c::StreamReadRange> ranges;
  std::vector<std::string> names;
  ranges.reserve(320); names.reserve(320); weight_pools.reserve(320);
  std::size_t bytes = 0, largest = 0;
  std::string line;
  while (std::getline(input, line)) {
    std::istringstream fields(line);
    std::string name, type; std::size_t rank = 0, offset = 0, count = 0;
    fields >> name >> type >> rank;
    if (rank == 0 || rank > c::kMaxTensorRank || (type != "BF16" && type != "F32"))
      throw std::runtime_error("invalid manifest tensor");
    std::vector<std::int64_t> dimensions(rank);
    for (auto &dimension : dimensions) fields >> dimension;
    fields >> offset >> count;
    auto desc = take(c::TensorDesc::dense(type == "BF16" ? Type::kBFloat16 : Type::kFloat32, dimensions));
    if (!fields || take(desc.required_bytes()) != count)
      throw std::runtime_error("manifest tensor extent differs");
    if (offset > source_file.capacity || count > source_file.capacity - offset)
      throw std::runtime_error("short checkpoint tensor: " + name);
    if (count > (std::numeric_limits<std::size_t>::max)() - bytes)
      throw std::runtime_error("text weight byte inventory overflows");
    Tensor tensor(memory.ref(), desc); // Same320 original device allocations.
    auto pool = take(c::LeasePool::adopt(std::move(tensor.buffer), {.max_blocks = 1}));
    auto writer = take(pool.allocate(count));
    ranges.push_back({.file_offset = offset, .destination = std::move(writer),
        .bytes = count, .description = desc});
    weight_pools.push_back(std::move(pool)); // Admission stays open for Graph reads.
    if (!weights.emplace(name, std::move(tensor)).second)
      throw std::runtime_error("duplicate weight");
    names.push_back(std::move(name)); bytes += count; largest = (std::max)(largest, count);
  }
  if (weights.size() != 320 || bytes != 3763655360ULL)
    throw std::runtime_error("text weight inventory differs");
  std::vector<c::StreamReadGroup> groups;
  groups.reserve(ranges.size());
  for (std::size_t i = 0; i < ranges.size(); ++i)
    groups.push_back({i, std::span(ranges).subspan(i, 1)});
  constexpr std::size_t staging_per_slot = 8u * 1024u * 1024u;
  constexpr std::uint32_t slots = 2;
  if (bytes > (std::numeric_limits<std::size_t>::max)() - slots * staging_per_slot)
    throw std::runtime_error("weight loader backing capacity overflows");
  const std::array targets{c::CopyResourceSpec{memory.ref(), largest}};
  auto pipeline = take(c::cuda::create_file_pipeline(io, context, queue, staging, targets,
      {.max_requests = 1, .max_groups_per_request = 320, .max_ranges_per_group = 1,
       .in_flight_slots = slots, .staging_bytes_per_slot = staging_per_slot,
       .max_active_backing_bytes = bytes + slots * staging_per_slot}));
  struct Drain final {
    c::FileResourcePipeline &pipeline;
    ~Drain() { pipeline.drain().IgnoreError(); }
  } drain{pipeline};
  auto ticket = take(pipeline.read(c::StreamSource::file(source), groups));
  std::vector<bool> delivered(groups.size(), false);
  for (std::size_t count = 0; count < groups.size(); ++count) {
    auto group = take(ticket.wait_next_ready());
    if (group.tag() >= names.size() || group.range_count() != 1)
      throw std::runtime_error("weight stream returned an unexpected group");
    const auto index = static_cast<std::size_t>(group.tag());
    if (delivered[index]) throw std::runtime_error("weight stream returned a duplicate group");
    auto ready = take(group.output(0));
    if (ready.size() != ranges[index].bytes)
      throw std::runtime_error("weight stream returned an incomplete tensor");
    weights.at(names[index]).ready = std::move(ready);
    delivered[index] = true;
  }
  const auto result = ticket.wait();
  check(result.status);
  if (!result.complete || !result.retirement_proven || result.read_bytes != bytes ||
      result.copied_bytes != bytes || result.ready_groups != groups.size())
    throw std::runtime_error("weight stream byte inventory or retirement differs");
  ticket = {};
  check(pipeline.drain());
  const auto report = pipeline.report();
  pipeline = {}; // Drop fixed staging, native slots and internal source owners now.
  source.reset();
  auto close_task = close_weight_source(mem::system_allocator(), &source_file.file);
  if (!close_task.valid()) throw std::runtime_error("cannot allocate weight close task");
  check(take(hyle::sched::spawn_task_on(loader_scheduler, 0,
      mem::system_allocator(), std::move(close_task)).join()));
  input.close();
  // Returning destroys the temporary Scheduler/IoContext and joins their actual
  // workers. The constructor's original weight/TTFT timers still surround all of it.
  return {bytes, report};
}

class Model;
// A Session borrows its Model. Destroy all sessions (and retire their slots)
// before the shared model's Context, weights, families and progress runtimes.
class Session final {
  friend class Model;
  Model *model_;
  explicit Session(Model &model) noexcept : model_(&model) {}
public:
  // Declared before the actual buffers; released only after slots/state die.
  c::ResourceBudget::Reservation cache_reservation;
  std::array<State, 24> state;
  // Slots/IO die before the state buffers to which they are actually bound.
  std::map<std::size_t, std::unique_ptr<Phase>> phases, probe_phases;
  std::map<std::size_t, std::array<std::size_t, 2>> planned_slot_uses;
  std::size_t length = 0, parity = 0;
  bool failed = false;
  Session(const Session &) = delete;
  Session &operator=(const Session &) = delete;
  hyle::Status drain() noexcept {
    hyle::Status result;
    for (auto *cache : {&phases, &probe_phases})
      for (auto &[tokens, phase] : *cache) {
        (void)tokens;
        for (auto &run : phase->slots) result.Update(run.drain());
      }
    return result;
  }
  ~Session() { drain().IgnoreError(); }
};

class Model final {
public:
  c::Context context = take(g::cuda::create_context());
  c::StorageOwner memory = take(c::StorageOwner::adopt(context,
      take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice))));
  c::cuda::MemoryResource planning_memory = take(c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost));
  c::Queue queue = take(context.create_queue());
  // These original runtimes outlive every phase/slot and its native retirement.
  std::unique_ptr<hyle::sched::Scheduler> scheduler;
  std::unique_ptr<hyle::sched::BlockingPool> workers;
  std::vector<c::LeasePool> weight_pools; // Retain original allocations through all Graph uses.
  std::map<std::string, Tensor> weights;
  std::array<StateSchema, 24> state_schema;
  c::ResourceBudget cache_budget;
  // Family/child owners are shared by sessions; no session addresses enter compile.
  std::unique_ptr<Family> family, probe_family;
  std::size_t capacity;
  ReplayPolicy replay_policy = ReplayPolicy::kAuto;
  std::filesystem::path layer0_probe, trace_routes;
  explicit Model(const std::filesystem::path &manifest, std::size_t selected_capacity,
                 std::filesystem::path probe = {}, bool progress = false,
                  ReplayPolicy replay = ReplayPolicy::kAuto,
                  std::size_t max_cache_bytes = (std::numeric_limits<std::size_t>::max)())
       : state_schema(state_schema_for(selected_capacity)), capacity(selected_capacity),
         replay_policy(replay), layer0_probe(std::move(probe)) {
    const std::array limits{c::ResourceBudgetLimit{memory.ref(), max_cache_bytes},
        c::ResourceBudgetLimit{mem::system_resource(), (std::numeric_limits<std::size_t>::max)()}};
    cache_budget = take(c::ResourceBudget::create({.limits = limits}));
    if (progress) {
      auto status = hyle::Status::Ok();
      scheduler = std::make_unique<hyle::sched::Scheduler>(1, mem::system_allocator(), 64, &status);
      check(status);
      workers = std::make_unique<hyle::sched::BlockingPool>(mem::system_allocator(), 1,
                                                          std::chrono::seconds(10), &status);
      check(status);
    }
    const auto weight_load_start = Clock::now();
    const auto loading = load_weight_bank(manifest, memory, planning_memory.ref(), queue,
                                         context, weights, weight_pools);
    const auto weight_load_seconds = std::chrono::duration<double>(Clock::now() - weight_load_start).count();
    std::cerr << "resident text weights: " << weights.size() << " tensors, " << loading.bytes << " bytes\n";
    std::cerr << "weights_load_seconds=" << weight_load_seconds << '\n';
    std::cerr << "pinned_weight_loader staging_bytes=" << loading.stream.staging_bytes
              << " io_calls=" << loading.stream.io_calls
              << " native_calls=" << loading.stream.native_calls
              << " native_waits=" << loading.stream.native_waits
              << " host_waits=" << loading.stream.host_waits
              << " phase_completions=" << loading.stream.phase_completions
              << " copied_physical_bytes=" << loading.stream.copied_physical_bytes
              << " peak_backing_bytes=" << loading.stream.peak_backing_bytes << '\n';
  }

  ~Model() {
    // Sessions drain their original slots before this shared owner is destroyed.
    // Scheduler idleness alone does not prove native/completion retirement.
    if (workers) workers->shutdown();
    if (scheduler) scheduler->drain();
  }

  static c::TensorDesc output_description(const g::CompileReport &report, V value) {
    c::TensorDesc description;
    bool found = false;
    for (std::size_t index = 0; index < report.physical_value_count(); ++index) {
      const auto physical = take(report.physical_value(index));
      if (physical.value != value || !physical.external_output) continue;
      if (found && description != physical.description)
        throw std::runtime_error("output has incompatible physical domain descriptions");
      description = physical.description;
      found = true;
    }
    if (!found) throw std::runtime_error("compiled child has no physical output description");
    return description;
  }

  void prepare_family(std::span<const std::size_t> planned_chunks, bool diagnostic = false) {
    auto &selected = diagnostic ? probe_family : family;
    if (selected) throw std::runtime_error("text finite family was already prepared");
    if (planned_chunks.empty()) throw std::runtime_error("text finite family requires known nonempty chunks");
    auto result = std::make_unique<Family>();
    auto &definition = *result;
    for (const auto tokens : planned_chunks) {
      if (tokens == 0 || tokens > capacity)
        throw std::runtime_error("finite text chunk outside nonempty context capacity");
      if (std::find(definition.chunks.begin(), definition.chunks.end(), tokens) == definition.chunks.end())
        definition.chunks.push_back(tokens);
    }
    const auto start = Clock::now();
    const auto max_query_rows = *std::max_element(definition.chunks.begin(), definition.chunks.end());
    const auto cap = static_cast<std::int64_t>(capacity);
    Recipe r(weights, memory, max_query_rows);
    const auto t = r.token_rows;
    definition.last_row = r.last_row;
    const auto cache_storage = take(c::CacheStorage::plain(Type::kBFloat16));
    definition.attention_schema = take(c::BatchSchema::create({
        .storage = c::BatchStorage::kRagged, .query_type = Type::kBFloat16,
        .output_type = Type::kBFloat16, .key_storage = cache_storage, .value_storage = cache_storage,
        .max_requests = 1, .max_query_rows = static_cast<std::uint32_t>(max_query_rows),
        .max_kv_rows = static_cast<std::uint32_t>(capacity), .max_pages = 0, .max_page_refs = 0,
        .query_heads = 8, .kv_heads = 2, .qk_head_dim = 256, .value_head_dim = 256, .page_size = 1}));
    definition.token_port = r.input(r.dense_spec(Type::kInt32, {t}));
    definition.position_port = r.input(r.dense_spec(Type::kInt32, {t}));
    definition.metadata_port = r.input(take(definition.attention_schema.metadata_description()));
    auto x = r.one(c::Gather{.bounds = c::IndexBoundsPolicy::kUnchecked},
        {r.weight("embed_tokens.weight"), definition.token_port}, r.dense_spec(Type::kBFloat16, {t, f(hidden)}));
    std::array<float, 32> frequency{};
    for (std::size_t i = 0; i < frequency.size(); ++i) frequency[i] = 1.F / std::pow(10000000.F, float(i) / 32.F);
    r.literals.emplace_back(memory.ref(), dense(Type::kFloat32, {32}));
    r.literals.back().write<float>(frequency);
    const auto frequencies = r.constant(r.literals.back());
    for (std::size_t i = 0; i < state_schema.size(); ++i) {
      const auto prefix = "layers." + std::to_string(i) + ".";
      auto normalized = r.norm(x, prefix + "input_layernorm.weight");
      auto &ports = definition.layers[i];
      V mixed;
      if (i % 4 != 3) {
        ports.history = r.input(state_schema[i].history);
        ports.recurrent = r.input(state_schema[i].recurrent);
        auto qkv = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_qkv.weight"), {f(1), t, f(6144)});
        auto samples = r.one(c::Concat{.axis = 1}, {ports.history, qkv},
            r.dense_spec(Type::kBFloat16, {f(1), r.sample_rows, f(6144)}));
        // Published state uses caller-owned ping-pong storage.
        ports.next_history = r.copy(r.slice(samples, 1, t, f(3)));
        auto convolution = r.one(c::model_ops::causal_conv1d(), {r.cast(samples, Type::kFloat32),
            r.cast(r.reshape(r.weight(prefix + "linear_attn.conv1d.weight"), {f(6144), f(4)}), Type::kFloat32)},
            r.dense_spec(Type::kFloat32, {f(1), t, f(6144)}));
        auto activated = r.unary(c::UnaryKind::kSilu, r.cast(convolution, Type::kBFloat16));
        auto q = r.reshape(r.slice(activated, 2, f(0), f(2048)), {f(1), t, f(16), f(128)});
        auto k = r.reshape(r.slice(activated, 2, f(2048), f(2048)), {f(1), t, f(16), f(128)});
        auto v = r.reshape(r.slice(activated, 2, f(4096), f(2048)), {f(1), t, f(16), f(128)});
        auto a = r.reshape(r.cast(r.linear(normalized, prefix + "linear_attn.in_proj_a.weight"), Type::kFloat32), {f(1), t, f(16), f(1)});
        auto b = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_b.weight"), {f(1), t, f(16), f(1)});
        auto dt = r.reshape(r.cast(r.weight(prefix + "linear_attn.dt_bias"), Type::kFloat32), {f(1), f(1), f(16), f(1)});
        auto decay = r.reshape(r.unary(c::UnaryKind::kNeg,
            r.unary(c::UnaryKind::kExp, r.weight(prefix + "linear_attn.A_log"))), {f(1), f(1), f(16), f(1)});
        auto g = r.binary(c::BinaryKind::kMultiply, decay,
            r.unary(c::UnaryKind::kSoftplus, r.binary(c::BinaryKind::kAdd, a, dt)));
        auto beta = r.cast(r.unary(c::UnaryKind::kSigmoid, b), Type::kFloat32);
        auto recurrent = r.op(c::Operation(c::GatedDeltaNet{}),
            {r.cast(r.l2(q), Type::kFloat32), r.cast(r.l2(k), Type::kFloat32),
             r.cast(v, Type::kFloat32), g, beta, ports.recurrent},
            {r.dense_spec(Type::kFloat32, {f(1), t, f(16), f(128)}),
             r.spec(ports.recurrent)});
        ports.next_recurrent = recurrent[1];
        auto y = r.cast(recurrent[0], Type::kBFloat16);
        if (i == 0) definition.probe_ports[0] = y;
        const auto y_f32 = r.cast(y, Type::kFloat32);
        y = r.cast(r.same(c::RmsNorm{.epsilon = 1.e-6F}, {y_f32}, y_f32), Type::kBFloat16);
        // The original checkpoint keeps this scale F32. Torch promotes the
        // rounded BF16 normalized value before multiplying it by that scale.
        y = r.binary(c::BinaryKind::kMultiply, r.cast(y, Type::kFloat32), r.weight(prefix + "linear_attn.norm.weight"));
        auto z = r.reshape(r.linear(normalized, prefix + "linear_attn.in_proj_z.weight"), {f(1), t, f(16), f(128)});
        y = r.cast(r.binary(c::BinaryKind::kMultiply, r.cast(y, Type::kFloat32),
            r.unary(c::UnaryKind::kSilu, r.cast(z, Type::kFloat32))), Type::kBFloat16);
        auto projection_input = r.reshape(y, {t, f(hidden)});
        if (i == 0) definition.probe_ports[1] = y; // Same BF16 payload before its metadata-only out_proj reshape.
        mixed = r.linear(projection_input, prefix + "linear_attn.out_proj.weight");
        if (i == 0) definition.probe_ports[2] = mixed;
        r.publish(ports.next_history); r.publish(ports.next_recurrent);
      } else {
        ports.key = r.input(state_schema[i].key);
        ports.value = r.input(state_schema[i].value);
        auto projected = r.reshape(r.linear(normalized, prefix + "self_attn.q_proj.weight"), {f(1), t, f(8), f(512)});
        auto q = r.norm(r.slice(projected, 3, f(0), f(256)), prefix + "self_attn.q_norm.weight");
        auto gate = r.reshape(r.copy(r.slice(projected, 3, f(256), f(256))), {t, f(hidden)});
        auto k = r.norm(r.reshape(r.linear(normalized, prefix + "self_attn.k_proj.weight"), {f(1), t, f(2), f(256)}), prefix + "self_attn.k_norm.weight");
        auto v = r.linear(normalized, prefix + "self_attn.v_proj.weight");
        const c::RoPE rope{.rotary_dimensions = 64, .sequence_axis = 1, .layout = c::RopeLayout::kHalfSplit};
        q = r.same(rope, {q, definition.position_port, frequencies}, q);
        k = r.same(rope, {k, definition.position_port, frequencies}, k);
        ports.next_key = r.one(c::Scatter{.axis = 0, .bounds = c::IndexBoundsPolicy::kUnchecked},
            {ports.key, definition.position_port, r.reshape(k, {t, f(512)})},
            take(g::TensorSpec::concrete(state_schema[i].key)));
        ports.next_value = r.one(c::Scatter{.axis = 0, .bounds = c::IndexBoundsPolicy::kUnchecked},
            {ports.value, definition.position_port, v},
            take(g::TensorSpec::concrete(state_schema[i].value)));
        auto attention = r.one(c::Operation::custom(c::RaggedAttention{
            .capacity = definition.attention_schema.capacity(), .scale = 0.0625F, .causal = true}),
            {r.reshape(q, {t, f(8), f(256)}), r.reshape(ports.next_key, {f(cap), f(2), f(256)}),
             r.reshape(ports.next_value, {f(cap), f(2), f(256)}), definition.metadata_port},
            r.dense_spec(Type::kBFloat16, {t, f(8), f(256)}), &definition.attention_nodes[i / 4]);
        auto gated = r.binary(c::BinaryKind::kMultiply, r.reshape(attention, {t, f(hidden)}), r.unary(c::UnaryKind::kSigmoid, gate));
        mixed = r.linear(gated, prefix + "self_attn.o_proj.weight");
        r.publish(ports.next_key); r.publish(ports.next_value);
      }
      x = r.ffn(r.binary(c::BinaryKind::kAdd, x, mixed), prefix,
                i == 0 ? std::span<V>(definition.probe_ports) : std::span<V>{});
      if (i == 0) definition.probe_ports[4] = x;
    }
    if (diagnostic) for (std::size_t i = 0; i < definition.probe_ports.size(); ++i) {
      r.publish(definition.probe_ports[i]);
      auto description = r.spec(definition.probe_ports[i]);
      if (description.data_type() != Type::kBFloat16) throw std::runtime_error("layer0 diagnostic boundary is not BF16");
    }
    // This published result is bound to the caller's fixed final_hidden buffer.
    auto last = r.copy(r.slice(r.norm(x, "norm.weight"), 0, D(r.last_row), f(1)));
    definition.hidden_port = last;
    definition.logits_port = r.cast(r.linear(last, "embed_tokens.weight"), Type::kFloat32);
    definition.id_port = r.op(c::Operation(c::TopK{.count = 1}), {definition.logits_port},
        {r.dense_spec(Type::kFloat32, {f(1), f(1)}), r.dense_spec(Type::kInt32, {f(1), f(1)})})[1];
    for (auto value : {definition.hidden_port, definition.logits_port, definition.id_port}) r.publish(value);
    definition.graph = take(std::move(r.builder).finish());
    definition.literals = std::move(r.literals);
    definition.specs = std::move(r.specs);
    std::vector<std::array<g::ShapeBinding, 1>> bindings;
    bindings.reserve(definition.chunks.size());
    for (const auto tokens : definition.chunks)
      bindings.push_back({g::ShapeBinding{definition.last_row, static_cast<std::int64_t>(tokens - 1)}});
    std::vector<g::ExactShapeVariant> variants;
    variants.reserve(bindings.size());
    for (const auto &point : bindings) variants.push_back({point});
    std::cerr << "compile full text finite family variants=" << variants.size()
              << " max_query_rows=" << max_query_rows << " nodes=" << definition.graph.node_count() << '\n';
    definition.compiled = take(g::cuda::compile(definition.graph, context, memory,
        {.shape_policy = g::CompileShapePolicy::kFiniteExact,
         .exact_variants = variants, .constants = r.constants}));
    const auto storage = definition.compiled.report.total_compiled_storage();
    std::cerr << "compiled text finite family variants=" << definition.compiled.report.exact_variant_count()
              << " compiled_known_bytes=" << storage.known_bytes()
              << " compiled_unknown_providers=" << storage.unknown_provider_count
              << " cold_seconds=" << std::chrono::duration<double>(Clock::now() - start).count() << '\n';
    definition.children.reserve(definition.chunks.size());
    for (std::size_t index = 0; index < definition.chunks.size(); ++index) {
      auto child = std::make_unique<FamilyChild>();
      child->compiled.executable = take(definition.compiled.executable.exact_variant(index));
      child->compiled.report = take(definition.compiled.report.exact_variant(index));
      definition.children.push_back(std::move(child));
    }
    selected = std::move(result);
  }

  std::unique_ptr<Session> create_session(std::span<const std::size_t> planned_chunks) {
    if (!family || (!layer0_probe.empty() && !probe_family))
      throw std::runtime_error("session requires the shared text families first");
    if (planned_chunks.empty()) throw std::runtime_error("session requires a nonempty ordered call plan");
    auto session = std::unique_ptr<Session>(new Session(*this));
    session->cache_reservation = take(cache_budget.reserve(memory.ref(), state_bytes(state_schema)));
    std::vector<std::size_t> chunks;
    std::size_t slot = 0, total = 0;
    for (const auto tokens : planned_chunks) {
      if (tokens == 0 || tokens > capacity - total)
        throw std::runtime_error("session plan exceeds nonempty context capacity");
      for (const auto *selected : {family.get(), layer0_probe.empty() ? nullptr : probe_family.get()}) {
        if (selected && std::find(selected->chunks.begin(), selected->chunks.end(), tokens) == selected->chunks.end())
          throw std::runtime_error("session chunk is outside the shared finite family");
      }
      total += tokens;
      if (!session->planned_slot_uses.contains(tokens)) chunks.push_back(tokens);
      ++session->planned_slot_uses[tokens][slot];
      slot = 1 - slot;
    }
    for (std::size_t i = 0; i < state_schema.size(); ++i) {
      auto &layer = session->state[i];
      const auto &schema = state_schema[i];
      if (i % 4 == 3) {
        layer.key = Tensor(memory.ref(), schema.key); layer.value = Tensor(memory.ref(), schema.value);
        layer.key.zero(); layer.value.zero();
      } else {
        for (std::size_t generation = 0; generation < 2; ++generation) {
          layer.history[generation] = Tensor(memory.ref(), schema.history);
          layer.recurrent[generation] = Tensor(memory.ref(), schema.recurrent);
          layer.history[generation].zero(); layer.recurrent[generation].zero();
        }
      }
    }
    // Every mutable slot and its IO are cold-created for this session only.
    for (const auto tokens : chunks) prepare_child(*session, tokens, false);
    if (!layer0_probe.empty()) for (const auto tokens : chunks) prepare_child(*session, tokens, true);
    return session;
  }

  Phase &prepare_child(Session &session, std::size_t tokens, bool diagnostic) {
    if (session.model_ != this) throw std::runtime_error("session belongs to another model");
    auto &state = session.state;
    auto &cache = diagnostic ? session.probe_phases : session.phases;
    const auto found = cache.find(tokens);
    if (found != cache.end()) return *found->second;
    auto &selected = diagnostic ? probe_family : family;
    if (!selected) throw std::runtime_error("text finite family has not been prepared");
    auto &definition = *selected;
    const auto point = std::find(definition.chunks.begin(), definition.chunks.end(), tokens);
    if (point == definition.chunks.end()) throw std::runtime_error("unlisted text chunk has no prepared exact child");
    const auto start = Clock::now();
    const auto index = static_cast<std::size_t>(point - definition.chunks.begin());
    auto result = std::make_unique<Phase>();
    auto &phase = *result;
    static_cast<FamilyPorts &>(phase) = static_cast<const FamilyPorts &>(definition);
    phase.planned_slot_uses = session.planned_slot_uses.at(tokens);
    for (std::size_t slot = 0; slot < phase.replay_modes.size(); ++slot) {
      phase.replay_modes[slot] = replay_policy == ReplayPolicy::kCommands
          || (replay_policy == ReplayPolicy::kAuto && phase.planned_slot_uses[slot] <= 1)
          ? g::ReplayMode::kCommands : g::ReplayMode::kPreferCapture;
    }
    phase.attention_schema = definition.attention_schema;
    phase.child = definition.children.at(index).get();
    const auto t = static_cast<std::int64_t>(tokens);
    phase.tokens = Tensor(memory.ref(), dense(Type::kInt32, {t}));
    phase.positions = Tensor(memory.ref(), phase.tokens.description);
    phase.logits = Tensor(memory.ref(), output_description(phase.child->compiled.report, phase.logits_port));
    phase.next_id = Tensor(memory.ref(), output_description(phase.child->compiled.report, phase.id_port));
    phase.final_hidden = Tensor(memory.ref(), output_description(phase.child->compiled.report, phase.hidden_port));
    if (diagnostic) for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
      for (std::size_t output = 0; output < phase.child->compiled.executable.output_count(); ++output) {
        if (take(phase.child->compiled.executable.output_id(output)) != phase.probe_ports[i]) continue;
        phase.probe_caller[i] = take(phase.child->compiled.executable.output_ownership(output)) == g::OutputOwnership::kCaller;
        if (phase.probe_caller[i]) phase.probe_outputs[i] =
            Tensor(memory.ref(), output_description(phase.child->compiled.report, phase.probe_ports[i]));
      }
    }
    const auto &route_directory = layer0_probe.empty() ? trace_routes : layer0_probe;
    if (!route_directory.empty()) {
      std::filesystem::create_directories(route_directory);
      const auto label = diagnostic ? "published" : "default";
      std::ofstream route(route_directory / (std::string(label) + "-T" + std::to_string(tokens) + ".route.tsv"));
      route << "step\tkind\tprovider\timplementation\tnodes\n";
      for (std::size_t step = 0; step < phase.child->compiled.report.step_count(); ++step) {
        const auto detail = take(phase.child->compiled.report.step(step));
        route << step << '\t' << static_cast<unsigned>(detail.kind) << '\t' << detail.provider.name
              << '\t' << detail.implementation.value() << '\t';
        for (std::size_t n = 0; n < detail.node_count; ++n) {
          const auto node = take(phase.child->compiled.report.step_node(step, n));
          const auto kind = take(definition.graph.operation_kind(node));
          route << (n ? "," : "") << node.ordinal() << ':'
                << (kind == c::OperationKind::kView ? c::operation_name(kind)
                    : c::operation_name(take(definition.graph.operation(node))));
        }
        route << '\n';
      }
      std::ofstream boundaries(route_directory / (std::string(label) + "-T" + std::to_string(tokens) + ".boundaries.tsv"));
      boundaries << "point\tvalue\tproducer\tshape\n";
      const auto signature = phase.child->compiled.executable.specialization();
      for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
        const auto value = phase.probe_ports[i];
        boundaries << layer0_probe_names[i] << '\t' << value.ordinal() << '\t'
                   << take(definition.graph.producer(value)).ordinal() << '\t';
        for (const auto dimension : definition.specs.at(value.ordinal()).dimensions()) {
          if (dimension.is_fixed()) { boundaries << dimension.fixed_value() << ','; continue; }
          bool resolved = false;
          for (std::size_t binding = 0; binding < signature.binding_count(); ++binding) {
            const auto entry = take(signature.binding(binding));
            if (entry.dimension != dimension.symbol()) continue;
            boundaries << entry.value << ',';
            resolved = true;
            break;
          }
          if (!resolved) throw std::runtime_error("exact child diagnostic dimension is unresolved");
        }
        boundaries << '\n';
      }
      if (!route || !boundaries) throw std::runtime_error("cannot write layer0 route diagnostics");
    }
    if (layer0_probe.empty() || diagnostic) for (std::size_t slot = 0; slot < 2; ++slot) {
      // Bind through the family to retain the actual public finite-selection
      // path. The returned slot's executable/report is the exact child above.
      const std::array shape{g::ShapeBinding{definition.last_row, static_cast<std::int64_t>(tokens - 1)}};
      phase.slots[slot] = take(definition.compiled.executable.create_invocation({.shape = shape}));
      if (phase.slots[slot].exact_variant_index() != index)
        throw std::runtime_error("finite family selected an unexpected exact child");
      if (scheduler) check(g::prepare_progress(phase.slots[slot], *scheduler, *workers));
      // This exact child slot keeps its caller bindings across layout preparation.
      // Only tensor contents and configuration metadata change during inference.
      auto &run = phase.slots[slot];
      check(run.bind(phase.token_port, phase.tokens.read()));
      check(run.bind(phase.position_port, phase.positions.read()));
      check(run.bind(phase.logits_port, phase.logits.view()));
      check(run.bind(phase.id_port, phase.next_id.view()));
      check(run.bind(phase.hidden_port, phase.final_hidden.view()));
      if (!layer0_probe.empty()) for (std::size_t i = 0; i < phase.probe_ports.size(); ++i)
        if (phase.probe_caller[i]) check(run.bind(phase.probe_ports[i], phase.probe_outputs[i].view()));
      for (std::size_t i = 0; i < state.size(); ++i) {
        auto &p = phase.layers[i]; auto &s = state[i];
        if (i % 4 == 3) {
          check(run.bind(p.key, s.key.read())); check(run.bind(p.value, s.value.read()));
          check(run.bind(p.next_key, s.key.view())); check(run.bind(p.next_value, s.value.view()));
        } else {
          check(run.bind(p.history, s.history[slot].read()));
          check(run.bind(p.recurrent, s.recurrent[slot].read()));
          check(run.bind(p.next_history, s.history[1 - slot].view()));
          check(run.bind(p.next_recurrent, s.recurrent[1 - slot].view()));
        }
      }
    }
    const auto storage = phase.child->compiled.report.compiled_storage();
    std::cerr << "planned_replay T=" << tokens
              << " slot0_uses=" << phase.planned_slot_uses[0]
              << " slot1_uses=" << phase.planned_slot_uses[1]
              << " slot0=" << (phase.replay_modes[0] == g::ReplayMode::kCommands ? "commands" : "prefer-capture")
              << " slot1=" << (phase.replay_modes[1] == g::ReplayMode::kCommands ? "commands" : "prefer-capture") << '\n';
    std::cerr << "compiled T=" << tokens << " steps=" << phase.child->compiled.report.step_count()
              << " workspace/slot=" << phase.child->compiled.executable.workspace_bytes()
              << " compiled_known_bytes=" << storage.known_bytes()
              << " compiled_unknown_providers=" << storage.unknown_provider_count
              << " child_prepare_seconds=" << std::chrono::duration<double>(Clock::now() - start).count() << '\n';
    auto *address = result.get(); cache.emplace(tokens, std::move(result)); return *address;
  }

  Phase &prepare(Session &session, std::size_t tokens, bool diagnostic = false) {
    // Inference only selects precompiled, eagerly prepared finite children.
    // No provider search, graph rebuilding, padding or lazy slot/JIT cache.
    if (session.model_ != this) throw std::runtime_error("session belongs to another model");
    auto &cache = diagnostic ? session.probe_phases : session.phases;
    const auto found = cache.find(tokens);
    if (found == cache.end()) throw std::runtime_error("unlisted text chunk has no prepared exact child");
    return *found->second;
  }

  std::int32_t evaluate(Session &session, std::span<const std::int32_t> ids, const std::string &name,
                        const std::filesystem::path &trace = {}, bool trace_states = true,
                        double *complete_seconds = nullptr,
                        Clock::time_point *host_endpoint = nullptr,
                        StepObservation *observation = nullptr,
                        PreparationObservation *preparation = nullptr,
                        std::string_view probe_subdirectory = {}) {
    if (session.model_ != this) throw std::runtime_error("session belongs to another model");
    auto &state = session.state;
    auto &length = session.length;
    auto &parity = session.parity;
    auto &failed = session.failed;
    if (failed) throw std::runtime_error("request state was invalidated by a previous failure");
    if (ids.empty() || ids.size() > capacity - length) throw std::runtime_error("nonempty block exceeds remaining context capacity");
    for (auto id : ids) if (id < 0 || id >= vocabulary) throw std::runtime_error("token ID outside vocabulary");
    if (!layer0_probe.empty()) prepare(session, ids.size()); // Compile-only route comparison; never execute the default graph here.
    auto &phase = prepare(session, ids.size(), !layer0_probe.empty());
    const auto replay_mode = phase.replay_modes[parity];
    const auto step_start = Clock::now();
    std::vector<std::int32_t> positions(ids.size());
    for (std::size_t row = 0; row < ids.size(); ++row) {
      positions[row] = static_cast<std::int32_t>(length + row);
    }
    phase.tokens.write<std::int32_t>(ids); phase.positions.write<std::int32_t>(positions);
    const auto cold_start = Clock::now();
    Clock::time_point start;
    double submit_seconds = 0;
    double cold_batch_seconds = 0;
    g::ReplayRoute replay_route = g::ReplayRoute::kUnprepared;
    std::size_t capture_recorded = 0, capture_reused = 0;
    try {
      const std::array<std::int32_t, 2> query_indptr{0, static_cast<std::int32_t>(ids.size())};
      const std::array<std::int32_t, 2> kv_indptr{0, static_cast<std::int32_t>(length + ids.size())};
      phase.attention_layout = take(phase.attention_schema.version({query_indptr, kv_indptr, {}, {}}));
      std::array<g::batch::NodeLayout, 6> layouts;
      for (std::size_t i = 0; i < layouts.size(); ++i) layouts[i] = {phase.attention_nodes[i], phase.attention_layout};
      const std::array queues{g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &queue}};
      auto &run = phase.slots[parity];
      if (preparation) {
        if (preparation->slot != parity) throw std::runtime_error("diagnostic planned slot differs from actual parity");
        const auto batch_start = Clock::now();
        check(g::batch::prepare(run, queues, layouts, {.host_workspace = planning_memory.ref()}));
        const auto batch_end = Clock::now();
        check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));
        const auto replay_end = Clock::now();
        preparation->layout_seconds = std::chrono::duration<double>(batch_start - cold_start).count();
        preparation->batch_prepare_seconds = std::chrono::duration<double>(batch_end - batch_start).count();
        preparation->replay_prepare_seconds = std::chrono::duration<double>(replay_end - batch_end).count();
      } else {
        check(g::batch::prepare(run, queues, layouts, {.host_workspace = planning_memory.ref()}));
        check(run.prepare_replay(queues, {.mode = replay_mode, .host_wait = g::HostWaitPolicy::kAllow}));
      }
      replay_route = run.replay_route();
      const auto replay_report = take(run.replay_report());
      capture_recorded = replay_report.recorded_capture_range_count;
      capture_reused = replay_report.reused_capture_range_count;
      cold_batch_seconds = std::chrono::duration<double>(Clock::now() - cold_start).count();
      start = Clock::now();
      auto done = take(run.submit(queues));
      submit_seconds = std::chrono::duration<double>(Clock::now() - start).count();
      check(done.wait());
    } catch (...) { failed = true; throw; }
    length += ids.size(); parity = 1 - parity;
    std::int32_t next = 0;
    check(phase.next_id.buffer.view().read(std::as_writable_bytes(std::span(&next, 1))));
    const auto finished = Clock::now();
    if (complete_seconds) *complete_seconds = std::chrono::duration<double>(finished - step_start).count();
    if (host_endpoint) *host_endpoint = finished;
    if (preparation) {
      // Public reports inspect existing host metadata only. Snapshot after the
      // original host-token endpoint so the query is outside the step timers.
      const auto report_start = Clock::now();
      auto &run = phase.slots[1 - parity];
      for (std::size_t i = 0; i < preparation->reports.size(); ++i) {
        preparation->nodes[i] = phase.attention_nodes[i].ordinal();
        preparation->reports[i] = take(g::batch::report(run, phase.attention_nodes[i]));
      }
      preparation->report_snapshot_seconds = std::chrono::duration<double>(Clock::now() - report_start).count();
    }
    if (observation) {
      observation->input_tokens = ids.size(); observation->visible = length; observation->next = next;
      observation->seconds = std::chrono::duration<double>(finished - start).count();
      observation->submit_seconds = submit_seconds;
      observation->step_seconds = std::chrono::duration<double>(finished - step_start).count();
      observation->cold_batch_seconds = cold_batch_seconds; observation->replay_route = replay_route;
      observation->capture_recorded = capture_recorded; observation->capture_reused = capture_reused;
      observation->scheduled_progress = static_cast<bool>(scheduler);
    } else {
      std::cerr << "prepared T=" << ids.size() << " visible=" << length
                << " replay=" << (replay_route == g::ReplayRoute::kCaptured ? "captured"
                    : replay_route == g::ReplayRoute::kHybrid ? "hybrid" : "commands")
                << " cold_batch_seconds=" << cold_batch_seconds
                << " capture_recorded=" << capture_recorded
                << " capture_reused=" << capture_reused << '\n';
      std::cerr << name << " tokens=" << ids.size() << " visible=" << length
                << " seconds=" << std::chrono::duration<double>(finished - start).count()
                << " submit_seconds=" << submit_seconds
                << " step_seconds=" << std::chrono::duration<double>(finished - step_start).count()
                << " progress=" << (scheduler ? "scheduler" : "direct")
                << " next=" << next << '\n';
    }
    if (!trace.empty()) {
      std::filesystem::create_directories(trace / name);
      phase.logits.dump(trace / name / "logits.f32"); phase.final_hidden.dump(trace / name / "hidden.bf16");
      if (trace_states) for (std::size_t layer = 0; layer < state.size(); ++layer) {
        auto &s = state[layer]; const auto prefix = "layer" + std::to_string(layer);
        if (layer % 4 == 3) {
          s.key.dump(trace / name / (prefix + ".key.bf16")); s.value.dump(trace / name / (prefix + ".value.bf16"));
        } else {
          s.history[parity].dump(trace / name / (prefix + ".conv.bf16"));
          s.recurrent[parity].dump(trace / name / (prefix + ".gdn.f32"));
        }
      }
    }
    if (!layer0_probe.empty()) {
      const auto probe_directory = probe_subdirectory.empty() ? layer0_probe / name
          : layer0_probe / std::filesystem::path(probe_subdirectory) / name;
      std::filesystem::create_directories(probe_directory);
      for (std::size_t i = 0; i < phase.probe_ports.size(); ++i) {
        auto output = take(phase.slots[1 - parity].output(phase.probe_ports[i]));
        std::vector<std::byte> bytes(take(output.description().required_bytes()));
        check(output.storage().read(bytes));
        std::ofstream stream(probe_directory / (std::string(layer0_probe_names[i]) + ".bf16"), std::ios::binary);
        stream.write(reinterpret_cast<const char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        if (!stream) throw std::runtime_error("cannot write layer0 probe output");
      }
    }
    return next;
  }
};

std::vector<std::int32_t> read_ids(const std::filesystem::path &path) {
  std::ifstream stream(path); if (!stream) throw std::runtime_error("cannot open token IDs");
  std::vector<std::int32_t> ids; std::int64_t value = 0;
  while (stream >> value) {
    if (value < 0 || value >= vocabulary) throw std::runtime_error("input token outside vocabulary");
    ids.push_back(static_cast<std::int32_t>(value));
  }
  if (!stream.eof()) throw std::runtime_error("malformed input IDs");
  return ids;
}
} // namespace qwen35

int main(int argc, char **argv) {
  const auto startup = qwen35::Clock::now();
  try {
    std::filesystem::path input, continuation, trace, layer0_probe, decode_ids, schedule_file, session_file;
    std::size_t steps = 4, capacity = 128, max_sessions = 0, active_sequences = 0, cache_bytes = 0;
    bool progress = false, trace_states = true, explicit_steps = false;
    bool single_schedule = false, multiple_schedules = false;
    bool explicit_continuation = false, explicit_decode_ids = false, preparation_diagnostics = false;
    auto replay = qwen35::ReplayPolicy::kAuto;
    const auto positive_size = [](const std::string &option, const std::string &value) {
      std::size_t result = 0;
      const auto converted = std::from_chars(value.data(), value.data() + value.size(), result);
      if (converted.ec != std::errc{} || converted.ptr != value.data() + value.size() || result == 0)
        throw std::runtime_error(option + " requires a positive integer");
      return result;
    };
    for (int i = 1; i < argc; ++i) {
      const std::string option = argv[i];
      if (i + 1 >= argc) throw std::runtime_error("option needs a value");
      const std::string value = argv[++i];
      if (option == "--inputs") input = value;
      else if (option == "--continuation") { continuation = value; explicit_continuation = true; }
      else if (option == "--schedule") { schedule_file = value; single_schedule = true; }
      else if (option == "--session-schedules") { session_file = value; multiple_schedules = true; }
      else if (option == "--max-sessions") max_sessions = value == "auto" ? 0 : positive_size(option, value);
      else if (option == "--active-sequences") active_sequences = value == "auto" ? 0 : positive_size(option, value);
      else if (option == "--cache-bytes") cache_bytes = value == "auto" ? 0 : positive_size(option, value);
      else if (option == "--trace") trace = value;
      else if (option == "--preparation-diagnostics") {
        if (value != "0" && value != "1") throw std::runtime_error("--preparation-diagnostics requires 0 or 1");
        preparation_diagnostics = value == "1";
      }
      else if (option == "--trace-level") {
        if (value != "full" && value != "decisions")
          throw std::runtime_error("--trace-level requires full or decisions");
        trace_states = value == "full";
      }
      else if (option == "--decode-ids") { decode_ids = value; explicit_decode_ids = true; }
      else if (option == "--layer0-probe") layer0_probe = value;
      else if (option == "--steps") { steps = positive_size(option, value); explicit_steps = true; }
      else if (option == "--capacity") capacity = positive_size(option, value);
      else if (option == "--progress") {
        if (value != "direct" && value != "scheduler")
          throw std::runtime_error("--progress requires direct or scheduler");
        progress = value == "scheduler";
      }
      else if (option == "--replay") {
        if (value != "auto" && value != "commands" && value != "prefer-capture")
          throw std::runtime_error("--replay requires auto, commands or prefer-capture");
        replay = value == "auto" ? qwen35::ReplayPolicy::kAuto
            : value == "prefer-capture" ? qwen35::ReplayPolicy::kPreferCapture
                                         : qwen35::ReplayPolicy::kCommands;
      }
      else throw std::runtime_error("unknown option: " + option);
    }
    const bool scheduled = single_schedule || multiple_schedules;
    if (single_schedule && multiple_schedules)
      throw std::runtime_error("--schedule and --session-schedules are exclusive");
    if (scheduled && (explicit_continuation || explicit_decode_ids || explicit_steps))
      throw std::runtime_error("schedule inputs are exclusive with --continuation, --decode-ids and explicit --steps");
    if ((single_schedule && schedule_file.empty()) || (multiple_schedules && session_file.empty()))
      throw std::runtime_error("schedule requires a nonempty manifest path");
    if (preparation_diagnostics && !scheduled)
      throw std::runtime_error("--preparation-diagnostics requires a schedule");
    std::vector<qwen35::benchmark::SessionSchedule> schedules;
    if (single_schedule)
      schedules.push_back({"default", qwen35::benchmark::read_schedule(schedule_file, qwen35::vocabulary, capacity)});
    else if (multiple_schedules)
      schedules = qwen35::benchmark::read_session_schedules(session_file, qwen35::vocabulary, capacity,
          std::vector<qwen35::benchmark::SessionSchedule>{}.max_size());
    const auto bytes_per_session = qwen35::state_bytes(qwen35::state_schema_for(capacity));
    if (max_sessions == 0) max_sessions = scheduled ? schedules.size() : std::size_t{1};
    const auto cached_slots = (std::min)(max_sessions, scheduled ? schedules.size() : std::size_t{1});
    if (cache_bytes == 0) {
      if (bytes_per_session > (std::numeric_limits<std::size_t>::max)() / cached_slots)
        throw std::runtime_error("auto cache byte budget overflows; reduce --capacity or --max-sessions");
      cache_bytes = bytes_per_session * cached_slots;
    }
    if (cache_bytes < bytes_per_session)
      throw std::runtime_error("--cache-bytes cannot hold one session: requires " + std::to_string(bytes_per_session) + " requested state bytes");
    if (active_sequences > max_sessions)
      throw std::runtime_error("--active-sequences cannot exceed --max-sessions");
    const auto active_slots = active_sequences == 0 ? (std::min)(cached_slots, cache_bytes / bytes_per_session)
        : (std::min)(active_sequences, scheduled ? schedules.size() : std::size_t{1});
    if (active_slots > cache_bytes / bytes_per_session)
      throw std::runtime_error("--cache-bytes cannot hold all configured active sequences");
    const auto forced = decode_ids.empty() ? std::vector<std::int32_t>{} : qwen35::read_ids(decode_ids);
    if (!decode_ids.empty()) {
      if (forced.empty()) throw std::runtime_error("--decode-ids requires a nonempty token tape");
      if (explicit_steps && steps != forced.size() + 1)
        throw std::runtime_error("--steps must equal decode input count plus one");
      steps = forced.size() + 1;
    }
    if (input.empty() || (!scheduled && (steps == 0 || steps > 128)))
      throw std::runtime_error("usage: hyle_qwen35_text --inputs DIR [--schedule FILE | --session-schedules FILE | [--continuation IDS] [--steps 4 | --decode-ids IDS]] [--capacity 128] [--max-sessions auto|N] [--active-sequences auto|N] [--cache-bytes auto|N] [--progress direct|scheduler] [--replay auto|commands|prefer-capture] [--trace DIR] [--trace-level full|decisions] [--preparation-diagnostics 0|1] [--layer0-probe DIR]");
    const auto prompt = scheduled ? std::vector<std::int32_t>{} : qwen35::read_ids(input / "prompt.ids");
    const auto extra = continuation.empty() ? std::vector<std::int32_t>{} : qwen35::read_ids(continuation);
    if (!scheduled && prompt.size() + extra.size() + steps - 1 > capacity)
      throw std::runtime_error("capacity is smaller than requested complete journey");
    std::vector<std::size_t> planned_chunks;
    if (scheduled) {
      for (const auto &request : schedules) for (const auto &phase : request.phases) {
        const auto tokens = phase.kind == qwen35::benchmark::PhaseKind::kPrompt ? phase.ids.size() : std::size_t{1};
        if (std::find(planned_chunks.begin(), planned_chunks.end(), tokens) == planned_chunks.end())
          planned_chunks.push_back(tokens);
      }
    } else {
      planned_chunks.push_back(prompt.size());
      if (!extra.empty()) planned_chunks.push_back(extra.size());
      planned_chunks.insert(planned_chunks.end(), steps - 1, 1);
    }
    const auto model_start = qwen35::Clock::now();
    qwen35::Model model(input / "weights.tsv", capacity, layer0_probe, progress, replay, cache_bytes);
    const auto constructed = qwen35::Clock::now();
    if (!trace.empty()) model.trace_routes = trace / "routes";
    model.prepare_family(planned_chunks);
    if (!layer0_probe.empty()) model.prepare_family(planned_chunks, true);

    // These owners are declared after Model, including on exception paths.
    // The schedule is consumer policy; every call uses the same Model/Graph chain.
    struct PhaseSummary {
      std::size_t context_before = 0, context_after = 0;
      double seconds = 0, step_sum_seconds = 0;
      std::string name, memory_name;
      qwen35::Clock::time_point start{};
    };
    struct Call { std::size_t phase, local; };
    qwen35::benchmark::SessionCache resident_cache({cached_slots, cache_bytes});
    struct SessionRun {
      std::unique_ptr<qwen35::Session> session;
      qwen35::benchmark::SessionCache::Pin pin;
      std::vector<std::size_t> chunks;
      std::vector<PhaseSummary> summaries;
      std::vector<Call> calls;
      std::vector<std::int32_t> generated, consumed;
      std::vector<qwen35::StepObservation> observations;
      std::vector<qwen35::PreparationObservation> preparation;
      std::filesystem::path trace;
      std::string trace_subdirectory;
      qwen35::Clock::time_point start{}, endpoint{};
      std::size_t visible_tokens = 0, cache_hits = 0, cache_misses = 0;
      std::size_t restored_calls = 0, restored_tokens = 0;
      double step_sum_seconds = 0, first_token_elapsed_seconds = 0, cache_prepare_seconds = 0;
    };
    std::vector<SessionRun> runs(schedules.size());
    std::size_t all_calls = 0;
    for (std::size_t s = 0; s < schedules.size(); ++s) {
      const auto &request = schedules[s];
      auto &run = runs[s];
      run.summaries.resize(request.phases.size());
      run.trace_subdirectory = "session" + std::to_string(s) + "_" + request.id;
      run.trace = trace.empty() || !multiple_schedules ? trace : trace / run.trace_subdirectory;
      for (std::size_t i = 0; i < request.phases.size(); ++i) {
        const auto &phase = request.phases[i];
        auto &summary = run.summaries[i];
        summary.name = "round" + std::to_string(phase.turn) +
            (phase.kind == qwen35::benchmark::PhaseKind::kPrompt ? "_prefill" : "_decode");
        summary.memory_name = multiple_schedules ? request.id + "_" + summary.name : summary.name;
        const bool is_prompt = phase.kind == qwen35::benchmark::PhaseKind::kPrompt;
        const auto count = is_prompt ? std::size_t{1} : phase.ids.size();
        for (std::size_t local = 0; local < count; ++local) {
          run.calls.push_back({i, local});
          run.chunks.push_back(is_prompt ? phase.ids.size() : std::size_t{1});
        }
      }
      if (run.calls.size() > (std::numeric_limits<std::size_t>::max)() - all_calls)
        throw std::runtime_error("total schedule call count overflows");
      all_calls += run.calls.size();
      run.generated.reserve(run.calls.size()); run.consumed.reserve(run.calls.size());
      run.observations.resize(run.calls.size());
      if (preparation_diagnostics) run.preparation.resize(run.calls.size());
      std::map<std::size_t, std::array<std::size_t, 2>> prior_uses;
      std::size_t parity = 0;
      for (std::size_t i = 0; i < run.calls.size(); ++i) {
        const auto call = run.calls[i];
        run.observations[i].name = qwen35::benchmark::phase_name(request.phases[call.phase], call.local);
        if (preparation_diagnostics) {
          auto &record = run.preparation[i];
          record.slot = parity;
          record.phase_slot_prior_uses = prior_uses[run.chunks[i]][parity]++;
        }
        parity = 1 - parity;
      }
    }
    std::vector<std::pair<std::size_t, std::size_t>> dispatch;
    dispatch.reserve(all_calls);
    std::vector<std::size_t> cursors(runs.size());
    // Each complete prompt/decode turn is an active request. Only its cohort
    // is pinned; completed turns become idle and may be evicted before reuse.
    for (std::size_t turn = 1;; ++turn) {
      std::vector<std::size_t> eligible;
      for (std::size_t s = 0; s < runs.size(); ++s)
        if (turn <= schedules[s].phases.back().turn) eligible.push_back(s);
      if (eligible.empty()) break;
      for (std::size_t first = 0; first < eligible.size(); first += active_slots) {
        const auto end = first + (std::min)(active_slots, eligible.size() - first);
        for (;;) {
          bool found = false;
          for (auto at = first; at < end; ++at) {
            const auto s = eligible[at];
            auto &cursor = cursors[s];
            if (cursor < runs[s].calls.size() && schedules[s].phases[runs[s].calls[cursor].phase].turn == turn) {
              dispatch.emplace_back(s, cursor++); found = true;
            }
          }
          if (!found) break;
        }
      }
    }
    std::vector<std::size_t> evicted_sessions;
    evicted_sessions.reserve(all_calls);
    const auto ensure_resident = [&](std::size_t s) {
      auto &run = runs[s];
      if (run.pin) return;
      const auto begin = qwen35::Clock::now();
      const auto admission = resident_cache.admit(s, bytes_per_session, [&](std::size_t victim) {
        auto &old = runs[victim];
        if (old.pin || !old.session || !old.session->drain().ok()) return false;
        old.session.reset(); // Actual slots and buffers die before quota returns.
        evicted_sessions.push_back(victim);
        return true;
      });
      if (!admission.accepted())
        throw std::runtime_error(admission.status == qwen35::benchmark::CacheAdmissionStatus::kRetirementUnproven
            ? "session cache cannot prove retirement; the original owner remains charged"
            : "session cache admission exhausted; reduce --active-sequences or increase --max-sessions/--cache-bytes");
      run.pin = resident_cache.pin(s);
      if (!run.pin) throw std::runtime_error("session cache could not pin the admitted owner");
      if (run.session) ++run.cache_hits;
      else {
        ++run.cache_misses;
        run.session = model.create_session(run.chunks);
        // Device cache eviction never deletes consumer history. Rebuild along
        // the original chunk sequence, not an oracle state or altered prefill.
        for (std::size_t i = 0; i < run.generated.size(); ++i) {
          const auto call = run.calls[i];
          const auto &phase = schedules[s].phases[call.phase];
          const auto ids = phase.kind == qwen35::benchmark::PhaseKind::kPrompt
              ? std::span<const std::int32_t>(phase.ids)
              : std::span<const std::int32_t>(&phase.ids[call.local], 1);
          qwen35::StepObservation restored;
          const auto name = "restore" + std::to_string(run.cache_misses) + "_call" + std::to_string(i);
          const auto next = model.evaluate(*run.session, ids, name, {}, false, nullptr, nullptr,
              &restored, nullptr, multiple_schedules ? std::string_view(run.trace_subdirectory) : std::string_view{});
          if (next != run.generated[i]) throw std::runtime_error("restored cache output differs from the original session history");
          ++run.restored_calls; run.restored_tokens += ids.size();
        }
        if (run.session->length != run.visible_tokens)
          throw std::runtime_error("restored cache context differs from retained consumer history");
      }
      if (qwen35::take(model.cache_budget.usage(model.memory.ref())).live_bytes != resident_cache.retained_bytes())
        throw std::runtime_error("cache directory bytes differ from the original state reservations");
      run.cache_prepare_seconds += std::chrono::duration<double>(qwen35::Clock::now() - begin).count();
    };
    for (std::size_t s = 0; s < (std::min)(active_slots, runs.size()); ++s) ensure_resident(s);
    auto session = scheduled ? std::unique_ptr<qwen35::Session>{} : model.create_session(planned_chunks);
    const auto ready = qwen35::Clock::now();
    std::cerr << "initialized model_seconds=" << std::chrono::duration<double>(constructed - model_start).count()
              << " shape_prepare_seconds=" << std::chrono::duration<double>(ready - constructed).count()
              << " startup_to_ready_seconds=" << std::chrono::duration<double>(ready - startup).count() << '\n';
    std::cerr << "cache_limits context=" << capacity << " max_sessions=" << max_sessions
              << " active_sequences=" << active_slots << " state_bytes_per_session=" << bytes_per_session
              << " cache_requested_byte_limit=" << cache_bytes
              << " physical_vram_limit_known=false\n";
    if (scheduled) {
      qwen35::Clock::time_point journey_start{}, endpoint{};
      for (std::size_t d = 0; d < dispatch.size(); ++d) {
        const auto [s, index] = dispatch[d];
        auto &run = runs[s];
        const auto call = run.calls[index];
        const auto &phase = schedules[s].phases[call.phase];
        auto &summary = run.summaries[call.phase];
        if (call.local == 0) {
          summary.context_before = run.visible_tokens;
          std::cerr << "memory_phase=" << summary.memory_name << "_begin\n";
          summary.start = qwen35::Clock::now();
          if (index == 0) run.start = summary.start;
          if (d == 0) journey_start = summary.start;
        }
        const bool is_prompt = phase.kind == qwen35::benchmark::PhaseKind::kPrompt;
        if (is_prompt) ensure_resident(s); // Request boundary only; decode uses the direct Session.
        const auto ids = is_prompt ? std::span<const std::int32_t>(phase.ids)
            : std::span<const std::int32_t>(&phase.ids[call.local], 1);
        auto &observation = run.observations[index];
        double complete_seconds = 0;
        const auto next = model.evaluate(*run.session, ids, observation.name, run.trace, trace_states,
            &complete_seconds, &run.endpoint, &observation,
            preparation_diagnostics ? &run.preparation[index] : nullptr,
            multiple_schedules ? std::string_view(run.trace_subdirectory) : std::string_view{});
        endpoint = run.endpoint;
        run.visible_tokens = run.session->length;
        summary.step_sum_seconds += complete_seconds; run.step_sum_seconds += complete_seconds;
        run.generated.push_back(next);
        if (!is_prompt) run.consumed.push_back(phase.ids[call.local]);
        if (index == 0) run.first_token_elapsed_seconds = std::chrono::duration<double>(endpoint - startup).count();
        const auto count = is_prompt ? std::size_t{1} : phase.ids.size();
        if (call.local + 1 == count) {
          summary.context_after = run.visible_tokens;
          summary.seconds = std::chrono::duration<double>(endpoint - summary.start).count();
          std::cerr << "memory_phase=" << summary.memory_name << "_end\n";
          if (!is_prompt) run.pin.reset(); // Complete native call, then idle-cache eligibility.
        }
      }
      for (std::size_t s = 0; s < runs.size(); ++s) {
        const auto &run = runs[s];
        if (multiple_schedules) std::cerr << "session_steps id=" << schedules[s].id << '\n';
        for (const auto &observation : run.observations) qwen35::print_step_observation(observation);
        if (preparation_diagnostics) for (std::size_t i = 0; i < run.observations.size(); ++i)
          qwen35::print_preparation_observation(run.observations[i], run.preparation[i]);
      }
      const auto print_result = [&](std::size_t s) {
        const auto &run = runs[s];
        const auto &phases = schedules[s].phases;
        std::cout << "{\"source_id\":\"" << qwen35::source_id << "\",\"text_tensors\":320,\"visible_tokens\":"
                  << run.visible_tokens << ",\"generated_ids\":[";
        for (std::size_t i = 0; i < run.generated.size(); ++i) std::cout << (i ? "," : "") << run.generated[i];
        std::cout << "],\"fixed_decode\":true,\"decode_input_ids\":[";
        for (std::size_t i = 0; i < run.consumed.size(); ++i) std::cout << (i ? "," : "") << run.consumed[i];
        std::cout << "],\"schedule\":true,\"phase_count\":" << phases.size()
                  << ",\"turn_count\":" << phases.back().turn
                  << ",\"processed_tokens\":" << run.visible_tokens
                  << ",\"generated_tokens\":" << run.generated.size()
                  << ",\"session_seconds\":" << std::chrono::duration<double>(run.endpoint - run.start).count()
                  << ",\"startup_total_seconds\":" << std::chrono::duration<double>(run.endpoint - startup).count()
                  << ",\"step_sum_seconds\":" << run.step_sum_seconds
                  << ",\"cache_hits\":" << run.cache_hits << ",\"cache_misses\":" << run.cache_misses
                  << ",\"restored_calls\":" << run.restored_calls << ",\"restored_tokens\":" << run.restored_tokens
                  << ",\"cache_prepare_seconds\":" << run.cache_prepare_seconds
                  << ",\"diagnostic\":" << (preparation_diagnostics || !trace.empty() || !layer0_probe.empty() ? "true" : "false");
        if (multiple_schedules) std::cout << ",\"session_id\":\"" << schedules[s].id
            << "\",\"trace_subdirectory\":\"" << run.trace_subdirectory << '"';
        std::cout << ",\"phases\":[";
        for (std::size_t i = 0; i < phases.size(); ++i) {
          const auto &phase = phases[i]; const auto &summary = run.summaries[i];
          const bool is_prompt = phase.kind == qwen35::benchmark::PhaseKind::kPrompt;
          const auto count = is_prompt ? std::size_t{1} : phase.ids.size();
          std::cout << (i ? "," : "") << "{\"turn\":" << phase.turn
                    << ",\"kind\":\"" << (is_prompt ? "prefill" : "decode") << "\",\"name\":\"" << summary.name
                    << "\",\"input_tokens\":" << phase.ids.size() << ",\"calls\":" << count << ",\"generated_tokens\":" << count
                    << ",\"context_before\":" << summary.context_before << ",\"context_after\":" << summary.context_after
                    << ",\"seconds\":" << summary.seconds << ",\"step_sum_seconds\":" << summary.step_sum_seconds << '}';
        }
        std::cout << "]}";
      };
      std::cerr << "first_token_elapsed_seconds=" << runs.front().first_token_elapsed_seconds << '\n';
      std::cout << std::setprecision(17);
      if (!multiple_schedules) print_result(0);
      else {
        std::size_t processed = 0;
        double step_sum = 0;
        for (const auto &run : runs) { processed += run.visible_tokens; step_sum += run.step_sum_seconds; }
        const auto usage = qwen35::take(model.cache_budget.usage(model.memory.ref()));
        std::cout << "{\"source_id\":\"" << qwen35::source_id << "\",\"text_tensors\":320,\"session_count\":" << runs.size()
                  << ",\"execution\":\"turn_round_robin_serial\",\"processed_tokens\":" << processed
                  << ",\"generated_tokens\":" << all_calls
                  << ",\"interleaved_seconds\":" << std::chrono::duration<double>(endpoint - journey_start).count()
                  << ",\"startup_total_seconds\":" << std::chrono::duration<double>(endpoint - startup).count()
                  << ",\"step_sum_seconds\":" << step_sum
                  << ",\"max_cached_sessions\":" << max_sessions << ",\"active_sequences\":" << active_slots
                  << ",\"cache_requested_byte_limit\":" << cache_bytes
                  << ",\"cache_state_bytes_per_session\":" << bytes_per_session
                  << ",\"cache_live_requested_bytes\":" << usage.live_bytes
                  << ",\"cache_peak_requested_bytes\":" << usage.peak_bytes
                  << ",\"cache_retained_sessions\":" << resident_cache.retained_sessions()
                  << ",\"diagnostic\":" << (preparation_diagnostics || !trace.empty() || !layer0_probe.empty() ? "true" : "false")
                  << ",\"dispatch_session_ids\":[";
        for (std::size_t i = 0; i < dispatch.size(); ++i)
          std::cout << (i ? "," : "") << '"' << schedules[dispatch[i].first].id << '"';
        std::cout << "],\"evicted_session_ids\":[";
        for (std::size_t i = 0; i < evicted_sessions.size(); ++i)
          std::cout << (i ? "," : "") << '"' << schedules[evicted_sessions[i]].id << '"';
        std::cout << "],\"sessions\":[";
        for (std::size_t s = 0; s < runs.size(); ++s) { if (s) std::cout << ','; print_result(s); }
        std::cout << "]}";
      }
      std::cout << '\n';
      return 0;
    }
    auto next = model.evaluate(*session, prompt, "prefill", trace, trace_states);
    std::cerr << "first_token_elapsed_seconds=" << std::chrono::duration<double>(qwen35::Clock::now() - startup).count() << '\n';
    if (!extra.empty()) next = model.evaluate(*session, extra, "continuation", trace, trace_states);
    std::vector<std::int32_t> generated{next};
    std::vector<std::int32_t> consumed;
    for (std::size_t step = 1; step < steps && (!forced.empty() || !qwen35::is_end_of_generation(next)); ++step) {
      const auto previous = forced.empty() ? next : forced[step - 1];
      next = model.evaluate(*session, std::span(&previous, 1), "decode" + std::to_string(step), trace, trace_states);
      consumed.push_back(previous); generated.push_back(next);
    }
    std::cout << "{\"source_id\":\"" << qwen35::source_id << "\",\"text_tensors\":320,\"visible_tokens\":"
              << session->length << ",\"generated_ids\":[";
    for (std::size_t i = 0; i < generated.size(); ++i) std::cout << (i ? "," : "") << generated[i];
    std::cout << "],\"fixed_decode\":" << (forced.empty() ? "false" : "true") << ",\"decode_input_ids\":[";
    for (std::size_t i = 0; i < consumed.size(); ++i) std::cout << (i ? "," : "") << consumed[i];
    std::cout << "]}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "Qwen3.5 text consumer: " << error.what() << '\n'; return 1;
  }
}
