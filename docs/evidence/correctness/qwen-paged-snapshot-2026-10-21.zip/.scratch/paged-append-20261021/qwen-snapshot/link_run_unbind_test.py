"""Focused host-only gtest image, retained193 closure plus current overrides."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('unbind_test_build', S / 'build_unbind_test.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R = h.b, h.c, h.R


def main():
    test_attempt = sys.argv[1] if len(sys.argv) > 1 else 'attempt2'
    link_attempt = sys.argv[2] if len(sys.argv) > 2 else 'link1'
    run_attempt = sys.argv[3] if len(sys.argv) > 3 else 'attempt1'
    out = S / 'unbind-tests' / link_attempt
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    base_path = S.parent / 'viewspec-cpu1/link-plan.json'
    base = c.read(base_path)
    fresh = c.read(S / 'unbind/compile.json')['records']
    test = c.read(S / 'unbind-tests' / test_attempt / 'identity.json')
    result = c.read(S / 'result-detach/checks/attempt1/identity.json')
    replacements = {}
    for old in base['inputs']:
        normalized = old['path'].replace('\\', '/').lower()
        if normalized.endswith('/graph_batch--paged_append_graph_test.obj'):
            replacements[c.key(old['path'])] = test['object']
        elif normalized.endswith('/graph--resources.obj'):
            replacements[c.key(old['path'])] = fresh[0]['object']
        elif normalized.endswith('/ggml_cuda_region.obj'):
            replacements[c.key(old['path'])] = fresh[1]['object']
    assert len(replacements) == 3
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    extra = [result['object'],
        b.identity(R / '.scratch/build-compute-v2-dev/lib/gtest_main.lib'),
        b.identity(R / '.scratch/build-compute-v2-dev/lib/gtest.lib')]
    inputs += extra
    for x in inputs:
        actual = b.identity(x['path'])
        assert all(actual[k] == x[k] for k in ('bytes', 'sha256'))
    image = out / 'unbind-host.exe'
    command = [replacements.get(c.key(x), {}).get('path', x)
        for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += [x['path'] for x in extra]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(base_path), replacements=replacements,
        CXX=0, links=1, SDK_builds=0, GPU_runs=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime,
        scope='Pure custom_test CPU provider only; no native GGML/CUDA Context created.'))
    run = S / 'unbind-tests/validation' / run_attempt
    run.mkdir(parents=True, exist_ok=False)
    args = [str(image), '--gtest_filter=InvocationUnbind.*',
            '--gtest_output=xml:' + str(run / 'tests.xml')]
    c.save(run / 'image.json', b.identity(image))
    c.execute('tests', args, env, run)
    c.save(S / 'unbind-tests/ready-and-result.json', dict(image=b.identity(image),
        link_plan=b.identity(out / 'link-plan.json'),
        test_identity=b.identity(S / 'unbind-tests' / test_attempt / 'identity.json'),
        result_identity=b.identity(S / 'result-detach/checks/attempt1/identity.json'),
        command=args, CPU_runs=1, GPU_runs=0, SDK_builds=0))
    print('UNBIND_HOST_RESULT_READY', run, flush=True)


if __name__ == '__main__':
    main()
