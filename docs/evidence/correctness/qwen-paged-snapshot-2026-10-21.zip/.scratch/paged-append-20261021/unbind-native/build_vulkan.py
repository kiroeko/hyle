"""Five frozen Vulkan native-binding cleanup CXX owners; no link/device work."""
from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time
R=Path.cwd(); A=R/'.scratch/architecture-refactor-2026-10-18'; S=R/'.scratch/paged-append-20261021/unbind-native'; C=S/'checks/attempt1'
C.mkdir(parents=True,exist_ok=False); (C/'tmp').mkdir()
def read(p): return json.loads(Path(p).read_bytes())
def save(p,d): Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def ident(p):
 p=Path(p).resolve(); d=p.read_bytes(); return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
recipes=[
 ('program','src/compute_route_vulkan/vulkan_program.cc',A/'quark-block128-scale-2026-10-21/vulkan/windows/checks/attempt1/program/identity.json'),
 ('provider-region','src/compute_provider_ggml_vulkan/region.cc',A/'ga-ratio4-producer-2026-10-21/vulkan/checks/rowpitch-fix1/identity.json'),
 ('native-region','src/graph_route_vulkan/native_region.cc',A/'quark-fp8-side-2026-10-21/windows/checks/attempt1/vulkan-native-region/identity.json'),
 ('native-ragged','src/graph_route_vulkan/native_ragged_region.cc',A/'compact-mla-e4-reference/vulkan/checks/attempt2/native-ragged-identity.json'),
 ('native-paged','src/graph_route_vulkan/native_paged_region.cc',A/'compact-mla-e4-reference/common/checks/attempt1/graph_route_vulkan--native_paged_region-9d2919/identity.json')]
freeze=read(S/'source-freeze-final.json'); frozen={x['path']:x for x in freeze['changed_files']}
for _,src,_ in recipes: assert ident(R/src)['sha256']==frozen[src]['sha256'],src
bat=A/'bf16-nan-cast-contract/compiler-env.bat'; p=subprocess.run(['cmd','/d','/c',str(bat)],capture_output=True,text=True,check=True)
env=os.environ.copy()
for line in p.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1); env[k.upper()]=v
env['TMP']=env['TEMP']=str(C/'tmp')
plan=dict(frozen_sources=ident(S/'source-freeze-final.json'),environment_recipe=ident(bat),CXX=5,NVCC=0,shaders=0,links=0,SDK_builds=0,GPU_runs=0,
 common_headers=[ident(R/'include/hyle/graph/detail/region_access.h'),ident(R/'include/hyle/compute/detail/generated_result.h')],jobs=[])
def make_job(job):
 name,src,recipe=job; out=C/name;out.mkdir();old=read(recipe); command=[];skip=False
 assert Path(old['source']['path']).resolve()==(R/src).resolve(),recipe
 for arg in old['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  command.append(arg)
 assert '/WX' in command and '/W4' in command,(name,'missing strict flags')
 command+=['/sourceDependencies',str(out/'source-deps.json'),str(R/src),'/Fo'+str(out/(name+'.obj')),'/Fd'+str(out/(name+'.pdb'))]
 data=dict(name=name,source=ident(R/src),recipe=ident(recipe),replaces=old['object'],command=command,cwd=str(R));save(out/'compile-plan.json',data);return data
jobs=[make_job(x) for x in recipes];plan['jobs']=jobs;save(C/'compile-plan.json',plan)
def compile_one(job):
 name=job['name'];out=C/name; start=time.perf_counter(); p=subprocess.run(job['command'],cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace');elapsed=time.perf_counter()-start
 (out/'stdout.log').write_text(p.stdout,encoding='utf8');(out/'stderr.log').write_text(p.stderr,encoding='utf8');receipt=dict(exit_code=p.returncode,seconds=elapsed,command=job['command'],cwd=str(R));save(out/'receipt.json',receipt)
 record=dict(name=name,source=job['source'],recipe=job['recipe'],replaces=job['replaces'],exit_code=p.returncode,seconds=elapsed,command=job['command'],receipt=ident(out/'receipt.json'))
 if p.returncode==0:
  deps=read(out/'source-deps.json')['Data'];record.update(object=ident(out/(name+'.obj')),source_dependencies=ident(out/'source-deps.json'),dependencies=[ident(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])]);record['current_source_and_deps_match']=all(ident(x['path'])==x for x in [record['source'],*record['dependencies']]);assert record['current_source_and_deps_match'];save(out/'identity.json',record)
 print(name+' exit='+str(p.returncode)+' seconds='+str(round(elapsed,3)),flush=True)
 if p.returncode:print((p.stdout+p.stderr)[-3000:],flush=True)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: records=list(pool.map(compile_one,jobs))
summary=dict(status='all_five_strict_CXX_passed' if all(x['exit_code']==0 for x in records) else 'actual_compile_failure_preserved',CXX_attempted=len(records),CXX_passed=sum(x['exit_code']==0 for x in records),NVCC=0,shaders=0,links=0,SDK_builds=0,GPU_runs=0,records=records)
save(C/'objects-ready.json',summary)
raise SystemExit(0 if summary['CXX_passed']==5 else 1)
