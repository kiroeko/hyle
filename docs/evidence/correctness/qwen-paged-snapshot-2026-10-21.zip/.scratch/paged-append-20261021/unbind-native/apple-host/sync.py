from pathlib import Path
import base64,hashlib,importlib.util,json,subprocess,sys
R=Path.cwd();O=Path(__file__).resolve().parent;plan=json.loads((O/'plan.json').read_text());payload=dict(plan=plan,script=base64.b64encode((O/'build_remote.py').read_bytes()).decode(),files=[])
for x in plan['delta']:
 b=(R/x['path']).read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'];payload['files'].append(dict(x,data=base64.b64encode(b).decode()))
code=r"""from pathlib import Path
import base64,hashlib,json,sys
p=json.load(sys.stdin);root=Path(p['plan']['remote']);base=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation');assert root.is_relative_to(base)and not root.is_symlink();root.mkdir(parents=True,exist_ok=False)
for x in p['plan']['reused']:
 target=Path(x['remote_path']);b=target.read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'];dest=root/x['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(target)
for x in p['files']:
 b=base64.b64decode(x['data']);assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'];dest=root/x['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
(root/'plan.json').write_text(json.dumps(p['plan'],indent=2)+'\n');(root/'build_remote.py').write_bytes(base64.b64decode(p['script']))
assert all(hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256']for x in p['plan']['canonical'])
print(json.dumps(dict(root=str(root),symlinks=len(p['plan']['reused']),copied=len(p['files']),copied_bytes=sum(x['bytes']for x in p['files']),all_canonical_sha_match=True)))
"""
encoded=base64.b64encode(code.encode()).decode();cmd="python3 -c \"import base64;exec(base64.b64decode('"+encoded+"'))\"";x=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198',cmd],input=json.dumps(payload).encode(),capture_output=True)
(O/'sync.stdout.log').write_bytes(x.stdout);(O/'sync.stderr.log').write_bytes(x.stderr);assert x.returncode==0,(x.stderr.decode(),x.stdout.decode());result=json.loads(x.stdout);(O/'sync.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
