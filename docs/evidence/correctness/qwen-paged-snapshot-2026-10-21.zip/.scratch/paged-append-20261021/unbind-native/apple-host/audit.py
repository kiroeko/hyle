from pathlib import Path
from collections import Counter
import hashlib
import json
import posixpath

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent

def ident(path):
    path = Path(path)
    value = path.read_bytes()
    return {"path": str(path), "bytes": len(value), "sha256": hashlib.sha256(value).hexdigest()}

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

plan = read(HERE / "plan.json")
canonical = {entry["path"]: entry for entry in plan["canonical"]}
remote_root = plan["remote"]
records = [read(path) for path in sorted((HERE / "results2").glob("*.result.json"))]
first = [read(path) for path in sorted((HERE / "results").glob("*.result.json"))]
assert len(records) == 9 and all(record["exit"] == 0 for record in records)

dependencies = {}
for record in records:
    for entry in record["dependencies"]:
        previous = dependencies.setdefault(entry["path"], entry)
        assert previous == entry, entry["path"]

sdk_roots = (
    "/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/hyle/_deps/mlx-490c5876b63c15e8/source/",
    "/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-0bae7e9e90b384d8/",
    "/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk/",
)
categories = Counter()
errors = []
used_project = set()
external_sdk = []
for path, entry in sorted(dependencies.items()):
    if path.startswith(remote_root + "/"):
        relative = posixpath.normpath(path[len(remote_root) + 1:])
        expected = canonical.get(relative)
        if expected is None or expected["sha256"] != entry["sha256"]:
            errors.append({"dependency": entry, "expected": expected})
        used_project.add(relative)
        categories["canonical_project"] += 1
    elif path.startswith(sdk_roots):
        categories["retained_third_party_sdk"] += 1
        external_sdk.append(entry)
    elif path.startswith(("/Library/Developer/CommandLineTools/", "/Applications/Xcode.app/")):
        categories["system_toolchain"] += 1
    else:
        errors.append({"unexpected_dependency": entry})

current_drift = []
for relative, expected in canonical.items():
    actual = ident(ROOT / relative)
    if actual["sha256"] != expected["sha256"]:
        current_drift.append({"canonical": expected, "current": actual})
assert not errors, errors
assert not current_drift, current_drift

source_batch = ident(HERE.parent / "source-freeze-final.json")
audit = {
    "status": "pass",
    "independent_check": "Fetched actual clang dependency receipts checked against the canonical Windows closure and explicit retained SDK roots; current Windows files still match all 155 staged identities.",
    "source_batch": source_batch,
    "unique_dependencies": len(dependencies),
    "categories": dict(categories),
    "canonical_staged_files": len(canonical),
    "canonical_project_files_used": len(used_project),
    "current_windows_drift": current_drift,
    "unexpected_or_mismatched_dependencies": errors,
    "third_party_sdk_dependencies": external_sdk,
    "final_result_receipts": [ident(path) for path in sorted((HERE / "results2").glob("*.result.json"))],
}
save(HERE / "dependency-audit.json", audit)

report = {
    "status": "pass",
    "scope": "Apple unbind native cleanup host compilation only",
    "hardware": plan["hardware"],
    "remote_workspace": remote_root,
    "source_batch": source_batch,
    "source_plan": ident(HERE / "plan.json"),
    "canonical_manifest": ident(HERE / "canonical-manifest.json"),
    "dependency_audit": ident(HERE / "dependency-audit.json"),
    "sparse_sync": read(HERE / "sync.result.json"),
    "actual_final": {
        "CXX_attempts": len(records),
        "CXX_passed": sum(record["exit"] == 0 for record in records),
        "links": 0,
        "GPU_runs": 0,
        "SDK_builds": 0,
        "SDK_downloads": 0,
        "canonical_staged_files": len(canonical),
        "compiled_objects": [
            {key: record[key] for key in ("source", "object", "exit", "seconds")}
            for record in records
        ],
    },
    "first_attempt": {
        "CXX_attempts": len(first),
        "CXX_passed": sum(record["exit"] == 0 for record in first),
        "CXX_failed": sum(record["exit"] != 0 for record in first),
        "cause": "Validation recipe normalization added public header subdirectories. SDK <assert.h> resolved Hyle's include/hyle/core/assert.h, leaving libc assert undeclared. Product files were not changed.",
        "correction": "Use only the public include root plus required src/third_party private header directories. Compiler, SDK, arch and non-overlay flags retained from actual cached per-TU recipes.",
        "retained": "results/ and plan-attempt1.json; final run is results2/ with plan.json",
    },
    "product_files_modified": [],
    "limits": [
        "Compilation proves current host C++ contracts under the recorded Apple SDK dependency families; no full link or native ABI closure was checked.",
        "No Metal/MLX device execution, kernel execution, unbind failure/runtime behavior, performance or model numerical check was run.",
        "Per-TU retained recipe SDK roots differ and are captured verbatim in actual dependencies; this is not a newly unified Apple SDK build.",
        "Root's current CUDA/Qwen checks remain separate evidence.",
    ],
    "retention": "Keep source plan, manifests, actual commands/results/dependencies and nine final host objects in the fixed existing Hyle workspace. No large cleanup was performed.",
}
save(HERE / "report.json", report)
ready = {
    "status": "ready-for-root",
    "Apple_host_compile": "pass",
    "six_Apple_leaf_TUs": 6,
    "common_leaf_TUs": 3,
    "final_CXX_exit0": 9,
    "link_checked": False,
    "GPU_or_runtime_checked": False,
    "source_batch": source_batch,
    "report": ident(HERE / "report.json"),
    "dependency_audit": ident(HERE / "dependency-audit.json"),
    "final_summary": ident(HERE / "results2" / "summary.json"),
    "remote_final_objects": remote_root + "/objects2",
    "remote_actual_receipts": remote_root + "/results2",
    "next_action": "No additional compile requested. Root may incorporate this host-only result with its runtime evidence, retaining the recorded untested limits.",
}
save(HERE / "ready-for-root.json", ready)
print(json.dumps({"status": ready["status"], "final_CXX_exit0": 9,
                  "dependency_categories": dict(categories),
                  "ready": ident(HERE / "ready-for-root.json")}, indent=2))
