from pathlib import Path
import concurrent.futures,hashlib,json,os,shlex,subprocess,time
R=Path(__file__).resolve().parent;P=json.loads((R/'plan.json').read_text());O=R/'results';O.mkdir(exist_ok=True);(R/'objects').mkdir(exist_ok=True)
def ident(path):
 p=Path(path);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
expected={str(R/x['path']):x for x in P['canonical']}
for path,x in expected.items():
 assert ident(path)['sha256']==x['sha256'],path
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
def one(job):
 tag=job['source'].replace('/','--');command=job['argv'];record=dict(source=ident(R/job['source']),recipe=job['recipe'],argv=command,started=time.time(),GPU_runs=0,SDK_builds=0,links=0)
 save(O/(tag+'.command.json'),record);print('START',tag,flush=True)
 try:
  run=subprocess.run(command,cwd=R,capture_output=True,text=True,timeout=180)
  record['exit']=run.returncode;stdout=run.stdout;stderr=run.stderr
 except subprocess.TimeoutExpired as e:
  record['exit']='timeout';stdout=(e.stdout or b'').decode(errors='replace')if isinstance(e.stdout,bytes)else(e.stdout or '');stderr=(e.stderr or b'').decode(errors='replace')if isinstance(e.stderr,bytes)else(e.stderr or '')
 (O/(tag+'.stdout.log')).write_text(stdout);(O/(tag+'.stderr.log')).write_text(stderr);record['seconds']=time.time()-record['started']
 if record['exit']==0:
  record['object']=ident(job['object']);dep=Path(job['dependency']).read_text().replace('\\\n',' ');values=shlex.split(dep.split(':',1)[1]);deps=[ident(x)for x in dict.fromkeys(values)if Path(x).is_file()];record['dependencies']=deps
  record['canonical_drift']=[x['path']for x in deps if x['path']in expected and x['sha256']!=expected[x['path']]['sha256']]
 save(O/(tag+'.result.json'),record);print('END',tag,record['exit'],round(record['seconds'],2),flush=True);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool: records=list(pool.map(one,P['jobs']))
summary=dict(status='pass'if all(x['exit']==0 and not x.get('canonical_drift')for x in records)else'failed',CXX=len(records),links=0,GPU_runs=0,SDK_builds=0,objects=[{k:x[k]for k in('source','object','exit','seconds')if k in x}for x in records],canonical_identity_preserved=all(ident(path)['sha256']==x['sha256']for path,x in expected.items()),hardware=P['hardware'],scope='Host compile only; no native device/kernel/runtime/ABI link result.')
save(O/'summary.json',summary);print('SUMMARY',summary['status'],flush=True)
raise SystemExit(0 if summary['status']=='pass'else 1)
