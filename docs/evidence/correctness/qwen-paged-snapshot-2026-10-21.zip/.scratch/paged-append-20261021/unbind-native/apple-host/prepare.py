from pathlib import Path
import base64,hashlib,json,re,subprocess,sys
sys.dont_write_bytecode=True
R=Path.cwd();O=Path(__file__).resolve().parent;A=R/'.scratch/architecture-refactor-2026-10-18'
REMOTE='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/unbind-native-2026-10-21/apple-host'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def ssh(code,payload):
 encoded=base64.b64encode(code.encode()).decode();cmd="python3 -c \"import base64;exec(base64.b64decode('"+encoded+"'))\""
 x=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198',cmd],input=json.dumps(payload).encode(),capture_output=True)
 if x.returncode:raise RuntimeError(x.stderr.decode(errors='replace')+x.stdout.decode(errors='replace'))
 return json.loads(x.stdout)
recipes={
'src/compute_route_apple/apple_context.cc':'apple-immutable-materialization-2026-10-21/apple/mac/final/results/src--compute_route_apple--apple_context.cc-compile.command.json',
'src/compute_route_apple/apple_recurrent.cc':'grouped-shared-activation/apple/validation/checks-carrier/compile-src--compute_route_apple--apple_recurrent.cc.command.json',
'src/compute_provider_ggml_metal/native_program.cc':'apple-nvfp4/validation/checks-final/compile-src--compute_provider_ggml_metal--native_program.cc.command.json',
'src/graph_route_apple/native_region.cc':'apple-affine-constant-preparation-2026-10-21/apple/mac/final/results/src--graph_route_apple--native_region.cc-compile.command.json',
'src/graph_route_apple/native_ragged_region.cc':'compact-mla-e4-reference/apple/mac/remote/results/src--graph_route_apple--native_ragged_region.cc-compile.command.json',
'src/graph_route_apple/native_paged_region.cc':'compact-mla-e4-reference/apple/mac/remote/results/src--graph_route_apple--native_paged_region.cc-compile.command.json',
'src/compute/result.cc':'ga-ratio4-producer-2026-10-21/apple/mac/final/results/src--graph--resources.cc-compile.command.json',
'src/graph/resources.cc':'ga-ratio4-producer-2026-10-21/apple/mac/final/results/src--graph--resources.cc-compile.command.json',
'src/graph/executable.cc':'expert-working-set-2026-10-21/apple/mac/remote/results/src--graph--executable.cc-compile.command.json'}
freeze=read(O.parent/'source-freeze-final.json')
for x in freeze['changed_files']:
 if 'apple' in x['path'] or 'metal' in x['path']:
  assert ident(R/x['path'])['sha256']==x['sha256'],x['path']
search=[R,R/'include',*[p for p in(R/'src').iterdir()if p.is_dir()],*[p for p in(R/'third_party').iterdir()if p.is_dir()]]
include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M);seen=set()
def visit(p):
 p=p.resolve()
 if p in seen or not p.is_file()or not p.is_relative_to(R):return
 if p.suffix not in ('.h','.hpp','.hh','.cc','.mm','.inc','.inl','.cuh'):return
 seen.add(p)
 for n in include.findall(p.read_text(encoding='utf-8',errors='replace')):
  target=next((b/n for b in[p.parent,*search]if(b/n).is_file()),None)
  if target:visit(target)
for source in recipes:visit(R/source)
# Existing manifests locate exact cache files. Every chosen target is rehashed
# on the Mac; no old checkout or manifest hash is trusted without that check.
candidates={}
manifest_paths=sorted([*A.glob('*/apple/mac/**/source-manifest.json'),*A.glob('*/apple/mac/**/reused-source-manifest.json')],key=lambda p:p.stat().st_mtime,reverse=True)[:30]
for manifest in manifest_paths:
 rows=read(manifest)
 remote=None
 for folder in (manifest.parent,manifest.parent.parent,manifest.parent.parent.parent):
  q=folder/'plan.json'
  if q.exists():remote=read(q).get('remote');break
 for row in rows:
  rel=row.get('path','');target=row.get('remote_path')
  if not target and remote and not Path(rel).is_absolute():target=remote+'/'+rel
  if target and rel and not Path(rel).is_absolute():
   bucket=candidates.setdefault(rel,[])
   if target not in bucket:bucket.append(target)
files=[]
base='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation'
for p in sorted(seen):
 rel=p.relative_to(R).as_posix();x=ident(p);x['path']=rel;x['candidates']=list(dict.fromkeys([*candidates.get(rel,[])[:8],base+'/'+rel,'/Users/kiro/hyle/'+rel]));files.append(x)
save(O/'canonical-manifest.json',[{k:v for k,v in x.items()if k!='candidates'}for x in files])
probe=ssh(r"""from pathlib import Path
import hashlib,json,sys,subprocess
p=json.load(sys.stdin);reused=[];delta=[]
for x in p['files']:
 found=None
 for value in x['candidates']:
  q=Path(value)
  if not q.is_file():continue
  b=q.read_bytes()
  if len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256']:found=value;break
 row={k:v for k,v in x.items()if k!='candidates'}
 if found:row['remote_path']=found;reused.append(row)
 else:delta.append(row)
h={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version'],'space':['df','-h',p['base']]}.items()};assert h['model']=='Mac16,12'
print(json.dumps(dict(reuse=reused,delta=delta,hardware=h)))
""",dict(files=files,base=base))
save(O/'cache-probe.json',probe)
# Normalize only repository include overlays; retain exact compiler/macros,
# target/sysroot/optimization flags and the actual installed SDK include roots.
include_dirs=list(dict.fromkeys(['include','.',*[p.relative_to(R).as_posix()for p in sorted({p.parent for p in seen})]]))
jobs=[]
for source,relrecipe in recipes.items():
 q=A/relrecipe;argv=read(q)['argv'];result=[argv[0]];i=1
 while i<len(argv):
  v=argv[i]
  if v in ('-MF','-MT','-MQ','-c','-o'):i+=2;continue
  if v in ('-MD','-MMD'):i+=1;continue
  if v=='-I':
   value=argv[i+1];i+=2
   if '/_deps/' in value or '/source-' in value:result.extend(['-I',value])
   continue
  if v.startswith('-I'):
   if '/_deps/' in v or '/source-' in v:result.append(v)
   i+=1;continue
  if v=='-isystem':result.extend(argv[i:i+2]);i+=2;continue
  result.append(v);i+=1
 result[1:1]=['-I'+REMOTE+'/'+x for x in include_dirs]
 if '-Werror'not in result:result.append('-Werror')
 tag=source.replace('/','--');obj=REMOTE+'/objects/'+tag+'.o';dep=obj+'.d';result+=['-c',REMOTE+'/'+source,'-o',obj,'-MD','-MF',dep]
 jobs.append(dict(source=source,source_identity=ident(R/source),recipe=ident(q),argv=result,object=obj,dependency=dep))
plan=dict(remote=REMOTE,jobs=jobs,canonical=files,reused=probe['reuse'],delta=probe['delta'],hardware=probe['hardware'],compiler_scope='Nine host CXX TUs only, no link, no Metal/shader/native runtime/SDK build or execution.',flags_policy='Only repository overlay -I paths normalized. SDK includes and non-include flags retain actual recipe semantics.')
save(O/'plan.json',plan)
print(json.dumps(dict(remote=REMOTE,files=len(files),reuse=len(probe['reuse']),delta_files=len(probe['delta']),delta_bytes=sum(x['bytes']for x in probe['delta']),delta_names=[x['path']for x in probe['delta']],jobs=len(jobs),arg_counts=[len(x['argv'])for x in jobs],hardware=probe['hardware']),indent=2))
