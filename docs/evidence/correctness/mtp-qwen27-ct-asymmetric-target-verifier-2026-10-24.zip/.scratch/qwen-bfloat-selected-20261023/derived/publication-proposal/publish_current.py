"""Small Q09/Q10 publisher for records from native_build_current.py only.

No acquisition/build/run action is provided. Root invokes this after both
actual backend runs finish. Weight bodies and native binaries never enter zip.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[3]
D = R/'docs/evidence/correctness'
HELPER = S.parent/'native_build_current.py'
HELPER_SHA = 'fc0bea30eabdf82286447fe29549bcf430204958c886007fb0963237ce764eb8'
CONFIG = {
    'Q09': dict(repository='cyankiwi/Qwen3.8-27B-AWQ-INT4', revision='6e134bae811fb5adac50ee042ae5f029ac6779aa',
        variant='compressed-tensors-asymmetric4-group32', original_bytes=6150228080, nodes=3, group=32,
        suffix='Q09OriginalCtAsymmetricTargetAndBFloatNextNFullVocabularyVerifierPublishesRepairedPrefix',
        name='mtp-qwen27-ct-asymmetric-target-verifier-2026-10-24',
        precision='Original CT asymmetric I32 codes/zeros, BF16 scales and authenticated I64(N,K); no zero+1, F16 scale store, g_idx or AWQ-GEMM4 substitution. BF16 A/F32 accumulation/BF16 output.'),
    'Q10': dict(repository='Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ', revision='1b9d56b428e9f841d7ad566f87660b5f47553c97',
        variant='GPTQ-v1-int4-group64', original_bytes=6135883776, nodes=4, group=64,
        suffix='Q10OriginalGptqTargetAndBFloatNextNFullVocabularyVerifierPublishesRepairedPrefix',
        name='mtp-qwen27-gptq-target-verifier-2026-10-24',
        precision='Original GPTQ-v1 I32 Q/Z/g_idx and F16 scales; zero nibble+1, F16 scale product then BF16 W; BF16 A/F32 accumulation/BF16 output.')}
TEXT = {'.json', '.log', '.xml', '.py', '.h', '.cc', '.c', '.cu', '.cuh', '.patch', '.txt'}


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    p = Path(path)
    return p.resolve() if p.is_absolute() else (R/p).resolve()


def identity(path):
    p = resolve(path); h = hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''): h.update(block)
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size, sha256=h.hexdigest())


def require(row):
    actual = identity(row['path'])
    if any(actual[k] != row[k] for k in ('bytes', 'sha256')):
        raise ValueError('Recorded immutable file changed: '+actual['path'])
    return resolve(row['path'])


def passed_result(path):
    p = read(path)
    if p.get('exit') != 0 or p.get('timed_out', False) or p.get('terminal', True) is not True:
        raise ValueError('Expected actual terminal exit0: '+str(path))
    return p


def pin_inputs(tag, rows):
    cfg = CONFIG[tag]; a = S.parent/tag; header = a/f'generated/qwen_{tag.lower()}_original_pins.h'
    pins = read(header.with_suffix('.json')); plan_path = require(pins['source_plan']); plan = read(plan_path)
    for key in ('header', 'source_receipt', 'manifest'): require(pins[key])
    if (pins['original_roles'], pins['original_bytes'], pins['packed_contractions_required']) != (50, cfg['original_bytes'], 7):
        raise ValueError('Actual pin count/bytes/packed contract differs')
    if pins['body_rehashed'] is not False or pins['artifact_executed'] is not False:
        raise ValueError('Generator metadata is not the original acquisition-only record')
    if tag == 'Q09' and (pins['packed_recipe_nodes'], pins['shape_metadata_roles']) != (3, 7):
        raise ValueError('Q09 requires seven actual I64 shapes and three-node recipes')
    if (plan['repository'], plan['revision'], plan['original_roles'], plan['source_bytes']) != (cfg['repository'], cfg['revision'], 50, cfg['original_bytes']):
        raise ValueError('Actual source plan identity differs')
    if plan['vocabulary'] != dict(embedding='model.language_model.embed_tokens.weight', head='lm_head.weight', unique_banks=2):
        raise ValueError('Two independent original vocabulary banks are required')
    manifest = read(a/'original-roles/manifest.json'); acq = read(a/'original-roles/acquisition.json')
    if not acq['complete'] or acq['whole_shard_downloaded'] or acq['original_roles'] != 50 or acq['role_payload_bytes'] != cfg['original_bytes']:
        raise ValueError('Actual selected original-role acquisition is not complete')
    for p in (manifest, acq):
        if (p['repository'], p['revision']) != (cfg['repository'], cfg['revision']): raise ValueError('Acquisition/source identity differs')
    if (manifest['original_roles'], manifest['source_bytes']) != (50, cfg['original_bytes']): raise ValueError('Manifest extent differs')
    physical = {x['name']: x for x in plan['roles']}; actual = {x['name']: x for x in manifest['roles']}; bodies = {x['name']: x for x in acq['roles']}
    if len(physical) != 50 or physical.keys() != actual.keys() or actual.keys() != bodies.keys(): raise ValueError('Unique actual role set differs')
    for name, source in physical.items():
        body, role = bodies[name], actual[name]
        if not body['complete'] or not re.fullmatch('[0-9a-f]{64}', role['sha256']): raise ValueError('Original role has no complete actual SHA')
        for k in ('dtype', 'shape', 'bytes', 'source_file', 'absolute_inclusive'):
            if body[k] != source[k] or role[k] != source[k]: raise ValueError('Original role range/schema differs: '+name)
        if role['file'] != source['filename'] or body['payload']['sha256'] != role['sha256'] or body['payload']['bytes'] != source['bytes']:
            raise ValueError('Actual plane manifest/receipt pin differs: '+name)
        # Metadata/stat only: the acquiring process already streamed SHA256;
        # native Data::load authenticated the actual bytes before this run.
        if (a/'original-roles'/role['file']).stat().st_size != source['bytes']: raise ValueError('Original role length changed')
        offset = 0
        for chunk in body['chunks']:
            if chunk['offset'] != offset or chunk['bytes'] <= 0 or not re.fullmatch('[0-9a-f]{64}', chunk['sha256']):
                raise ValueError('Incomplete authenticated prefix metadata')
            if chunk['absolute_range_inclusive'] != [source['absolute_inclusive'][0]+offset, source['absolute_inclusive'][0]+offset+chunk['bytes']-1]:
                raise ValueError('Authenticated chunk range differs')
            offset += chunk['bytes']
        if offset != source['bytes']: raise ValueError('Role chunks do not cover its exact extent')
    expected = {str(resolve(x['path'])).lower(): x for x in rows}
    for p in (header, header.with_suffix('.json'), plan_path, a/'original-roles/acquisition.json', a/'original-roles/manifest.json'):
        row = expected.get(str(p.resolve()).lower())
        if not row: raise ValueError('Current helper did not record actual pin input: '+str(p))
        require(row)
    return a, pins, plan


def collect(tag, args):
    cfg = CONFIG[tag]; a = S.parent/tag; native = a/'native-integration'
    if identity(HELPER)['sha256'] != HELPER_SHA: raise ValueError('Expected the frozen current ABI18 helper')
    link = native/f'tests-link{args.link_attempt}'; ready = read(link/'ready.json'); lp = read(link/'link-plan.json')
    if ready['artifact'] != tag or lp['shared_helper']['sha256'] != HELPER_SHA: raise ValueError('Wrong current-helper image/artifact')
    for k in ('image', 'link_plan', 'runtime_environment', 'consumer_record'): require(ready[k])
    passed_result(link/'link.result.json'); record_path = require(ready['consumer_record']); compiled = read(record_path)
    passed_result(record_path.parent/'compile.result.json')
    if compiled['artifact'] != tag or compiled['shared_helper']['sha256'] != HELPER_SHA or lp['consumer_record'] != ready['consumer_record']:
        raise ValueError('Use the current ABI18 compiled consumer record, not a historical lifecycle')
    macros = [x for x in compiled['command'] if x.startswith('/DHYLE_TEST_QWEN_') and 'ARTIFACTS_HEADER=' in x]
    if len(macros) != 1 or not macros[0].startswith('/DHYLE_TEST_QWEN_'+tag+'_ARTIFACTS_HEADER=') or any('/DHYLE_TEST_QWEN_STATE_'+x+'=1' not in compiled['command'] for x in ('CPU','CUDA')):
        raise ValueError('Actual compile must enable only this artifact and both backend entries')
    if len(lp['retained_current_records']) != 131: raise ValueError('Require the actual current131 retained host records')
    native_inputs = read(require(lp['native_inputs']))
    if [x['name'] for x in native_inputs['objects']] != ['cpu-baseline', 'cuda-gated-delta']: raise ValueError('Require the current two native inputs')
    runtime = read(link/'runtime-environment.json')
    if runtime['matched_HC_PRE_worker']['sha256'] != 'a020c6c3bd0d51bd50319fbe6924826979fec0b11cdd0e9db8457c132c136092':
        raise ValueError('Require the actual mixed-owning HC worker, not the old ffa4 family')
    for k, value in dict(consumer_translation_units=1, product_recompiles=0, SDK_builds=0, NVCC_builds=0).items():
        if compiled[k] != value or lp[k] != value: raise ValueError('Unexpected build extent: '+k)
    inputs = compiled['artifact_inputs']
    if ready['actual_artifact_inputs'] != inputs or lp['artifact_inputs'] != inputs: raise ValueError('Linked actual original pins differ')
    a, pins, original_plan = pin_inputs(tag, inputs)
    files = {Path(__file__).resolve(), resolve(args.entry), HELPER, record_path}
    files.update(require(row) for row in inputs)
    for row in lp['retained_current_records']: require(row)  # Record identities only; no SDK/body tree scan.
    files.add(require(lp['native_inputs'])); files.add(require(lp['shared_helper'])); files.add(require(lp['entry']))
    # Only this newly compiled consumer and its local model helpers are source
    # archive inputs. Product/native dependency identities remain in the recipe.
    for row in [compiled['source'], *compiled['dependencies']]:
        p = resolve(row['path'])
        if p.is_relative_to(R/'tests/compute_models'):
            choices = [record_path.parent/'source'/p.relative_to(R), p]
            choices += [resolve(root)/p.relative_to(R) for root in args.source_root]
            selected = next((x for x in choices if x.is_file() and all(identity(x)[k] == row[k] for k in ('bytes', 'sha256'))), None)
            if selected is None: raise ValueError('No exact compiled source snapshot: '+str(p))
            files.add(selected)
    for folder in (record_path.parent, link):
        files.update(p for p in folder.iterdir() if p.is_file() and p.suffix in {'.json', '.log'})
    executions = []
    for backend, attempt in [('cpu', args.cpu_attempt), ('cuda', args.cuda_attempt)]:
        out = native/f'checks{attempt}'; summary = read(out/'summary.json'); plan = read(out/'plan.json'); process = passed_result(out/'run/process.json')
        case = 'QwenMtpStateConsumer.'+('Cpu' if backend == 'cpu' else 'Cuda')+cfg['suffix']
        if not summary['passed'] or summary.get('listing_only', False) or (summary['tests'], summary['failures'], summary['skips']) != (1, 0, 0): raise ValueError('Need one actual passing case')
        if summary['case'] != case or plan['case'] != case or '--gtest_filter='+case not in process['command']: raise ValueError('Exact backend case differs')
        if summary['process'] != process or summary['image'] != ready['image'] or plan['image'] != ready['image'] or summary['consumer_record'] != ready['consumer_record']: raise ValueError('Run image/process/compiler identity differs')
        if summary['artifact_inputs'] != inputs or plan['actual_artifact_inputs'] != inputs or plan['shared_helper']['sha256'] != HELPER_SHA: raise ValueError('Run original pin/helper identity differs')
        if not summary['cached_only'] or summary['automatic_downloads'] or summary['driver'] is not None or plan['driver'] is not None: raise ValueError('These runs have no supplier/download driver')
        tree = ET.parse(out/'results.xml').getroot(); cases = list(tree.iter('testcase'))
        if len(cases) != 1 or any(int(tree.get(x, '0')) for x in ('failures', 'errors', 'disabled')) or list(tree.iter('skipped')) or list(tree.iter('failure')): raise ValueError('XML not one pass with zero skips')
        node = cases[0]
        if node.get('classname')+'.'+node.get('name') != case: raise ValueError('Wrong actual XML case')
        props = {x.get('name'): x.get('value') for x in node.iter('property')}
        if props != summary['properties']: raise ValueError('Summary/XML properties differ')
        required = dict(artifact_repository=cfg['repository'], artifact_revision=cfg['revision'], artifact_variant=cfg['variant'], target_layer='63', target_group_size=str(cfg['group']), original_role_count='50', original_role_bytes=str(cfg['original_bytes']),
            actual_submissions='23', complete_target_draft_resources='12', target_packed_contractions='7', target_packed_recipe_nodes=str(cfg['nodes']),
            target_dense_weight_materializations='0', target_verifier_rows='2', target_verifier_full_vocabulary='248320', target_verifier_matmuls='1',
            first_full_target_projection_values='59392', first_full_target_verifier_values='496640', first_full_nextn_head_values='248320',
            original_manifest_sha256=pins['manifest']['sha256'], original_acquisition_sha256=pins['source_receipt']['sha256'])
        if tag == 'Q09': required['target_shape_metadata_roles'] = '7'
        if any(props.get(k) != v for k, v in required.items()) or summary['actual_graph_submissions'] != 23: raise ValueError('Actual numerical/state/packed contract differs')
        if sum(int(props[k]) for k in ('target_submissions', 'nextn_submissions', 'target_verifier_submissions')) != 23: raise ValueError('Actual Graph accounting differs')
        if int(props['actual_accepted_kv_repair_submissions']) <= 0 or int(props['actual_pending_embedding_feedback_checks']) <= 0: raise ValueError('No actual repair/pending continuation')
        executions.append(dict(backend=backend, case=case, tests=1, failures=0, skips=0, graphs=int(props['actual_submissions']), properties=props,
            summary=identity(out/'summary.json'), xml=identity(out/'results.xml'), process=identity(out/'run/process.json'),
            cleanup=dict(process_terminal_exit=0, timed_out=False, driver=None, external_supplier=False, resource_peak_measurement=False)))
        files.update(out/p for p in ['summary.json', 'results.xml', 'plan.json', 'run/command.json', 'run/process.json', 'run/stdout.log', 'run/stderr.log'])
    # Explicit caller-provided batch summaries retain network failures/retries;
    # they are transport history, not native failures or measured wire totals.
    files.update(resolve(p) for p in args.transport_metadata)
    if len(executions) != 2 or sum(x['graphs'] for x in executions) != 46: raise ValueError('Both actual backends are required')
    return cfg, a, pins, original_plan, ready, lp, compiled, record_path, files, executions


def main(tag, entry):
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--cpu-attempt', type=int, required=True); p.add_argument('--cuda-attempt', type=int, required=True)
    p.add_argument('--link-attempt', type=int, default=1); p.add_argument('--source-root', action='append', default=[]); p.add_argument('--transport-metadata', action='append', default=[])
    args = p.parse_args(); args.entry = entry
    if min(args.cpu_attempt, args.cuda_attempt, args.link_attempt) <= 0 or args.cpu_attempt == args.cuda_attempt: raise ValueError('Distinct positive backend attempts required')
    cfg, a, pins, original_plan, ready, lp, compiled, record_path, files, executions = collect(tag, args)
    output = D/(cfg['name']+'.json'); archive = D/(cfg['name']+'.zip')
    if output.exists() or archive.exists(): raise ValueError('Preserve an existing publication')
    members = []
    for path in sorted(files):
        path = path.resolve()
        prefix = tag == 'Q10' and path == a/'header2-identity/prefix8.bin' and path.stat().st_size == 8
        if not path.is_relative_to(R) or (path.suffix.lower() not in TEXT and not prefix) or path.stat().st_size > 12*1024*1024:
            raise ValueError('Archive only explicit small metadata/source/log: '+str(path))
        members.append((path, path.relative_to(R).as_posix()))
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path, name in members: z.write(path, name)
    record = dict(created_at=datetime.now(timezone.utc).isoformat(), identity=dict(id=tag, repository=cfg['repository'], revision=cfg['revision'], variant=cfg['variant']),
        scope='Original target63/global norm, BF16 NextN64 and own untied original full vocabulary; same K1/12-resource StateHead and actual accepted-prefix repair/pending continuation.',
        original_roles=50, original_bytes=cfg['original_bytes'], executions=executions, cases=2, graphs=sum(x['graphs'] for x in executions), failures=0, skips=0,
        target_precision=cfg['precision'], target_packed_contractions_each=7, target_packed_recipe_nodes=cfg['nodes'], dense_weight_materializations=0,
        source_plan=identity(require(pins['source_plan'])), acquisition=identity(a/'original-roles/acquisition.json'), manifest=identity(a/'original-roles/manifest.json'), actual_pins=identity(a/f'generated/qwen_{tag.lower()}_original_pins.json'),
        source_partition=original_plan['partition'], original_vocabulary=original_plan['vocabulary'], original_weight_bodies_rehashed=False,
        build=dict(consumer_translation_units=1, SDK_builds=0, NVCC_builds=0, product_recompiles=0, compiled=identity(record_path),
            linked=identity(require(ready['link_plan'])), image=ready['image'], current_helper=identity(HELPER), retained_host_records=len(lp['retained_current_records']),
            native_inputs=identity(require(lp['native_inputs'])), source_family='Current ABI18 Graph/default-provider closure and correct mixed-owning CPU worker; no old13-host lifecycle'),
        transport_metadata=[identity(x) for x in args.transport_metadata],
        transport_note='Actual selected Range/SHA receipts are retained; ETag identifies the remote object and is not asserted as whole-file content SHA. No body/shard rehash, no new transfer or SDK copy by publisher.',
        limits=['Upstream layer62 inputs and finite initial histories remain fixtures; not full trained trunk/model task quality.',
            'Natural K1 trial and controlled match/rejection trials are separate; not an acceptance-rate estimate.',
            'No new TPS, physical memory peak, all-device, Linux or Apple conclusion.'],
        archive=identity(archive), archived_files=len(members), whole_original_model=False, throughput_evidence=False, memory_evidence=False)
    output.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps(dict(evidence=identity(output), archive=identity(archive), cases=2, graphs=record['graphs'])))
