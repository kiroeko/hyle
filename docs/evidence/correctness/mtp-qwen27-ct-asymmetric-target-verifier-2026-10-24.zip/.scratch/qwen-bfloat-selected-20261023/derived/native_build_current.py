"""One Qwen consumer TU on the current already-built Graph/provider closure.

Q09/Q10 supply only their existing strict artifact adapter. No downloader,
model controller or executor is implemented here. Only root invokes actions.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[3]
SHARED=R/'.scratch/glm-gguf-selected-20261023/B10/native-integration/build.py'
SHARED_SHA='96f154b81677aeeccf2cfb499818e5b0ab3bb24ff6ef8740cc1207e152a4b2d2'
SOURCE=R/'tests/compute_models/qwen_mtp_state_consumer_test.cc'
RECIPE=Path(__file__).parent/'integration/compile7/qwen-state/identity.json'


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result


def closure():
    import hashlib
    if hashlib.sha256(SHARED.read_bytes()).hexdigest()!=SHARED_SHA:raise ValueError('Pinned current closure utility changed')
    c=module('_qwen_derived_current_closure',SHARED)
    return c,c.closure()


def artifacts(adapter):return adapter.artifacts(adapter.HEADER)


def proposed_recipe(c,adapter):
    recipe=c.read(RECIPE)
    recipe['command']=[x for x in recipe['command']if not(x.startswith('/DHYLE_TEST_QWEN_')and'ARTIFACTS_HEADER='in x)]
    recipe['command'].insert(1,adapter.MACRO+'"'+adapter.HEADER.as_posix()+'"')
    if len([x for x in recipe['command']if x.startswith('/DHYLE_TEST_QWEN_')and'ARTIFACTS_HEADER='in x])!=1:
        raise ValueError('Only this original artifact guard may be enabled')
    return recipe


def plan(adapter,entry,attempt):
    c,base=closure();generator=adapter.generator();plan_path,metadata=generator.fetch.checked_plan()
    if(metadata['repository'],metadata['revision'],metadata['original_roles'],metadata['source_bytes'])!=(
        adapter.REPOSITORY,adapter.REVISION,adapter.ORIGINAL_ROLES,adapter.ORIGINAL_BYTES):raise ValueError('Actual source identity/count differs')
    if metadata['vocabulary']!=adapter.EXPECTED_VOCABULARY:raise ValueError('Physical original vocabulary differs')
    recipe=proposed_recipe(c,adapter)
    actual=artifacts(adapter)if adapter.HEADER.is_file()else None
    result=dict(prepared_only=True,entry=c.identity(entry),shared_helper=c.identity(Path(__file__)),
        source=c.identity(SOURCE),recipe=c.identity(RECIPE),current_link=c.identity(c.BASE/'link-plan.json'),
        current_runtime=c.identity(c.BASE_IMAGE/'runtime-environment.json'),native_inputs=c.identity(c.S/'native-inputs.json'),
        original_range_plan=c.identity(plan_path),roles=metadata['original_roles'],source_bytes=metadata['source_bytes'],
        vocabulary=metadata['vocabulary'],partition=metadata['partition'],expected_cases=adapter.CASES,
        environment={adapter.ENVIRONMENT:str(adapter.Q01/'original-roles')},
        proposed_compile_command=recipe['command'],actual_artifact_inputs=actual,blocked_pending_actual_pins=actual is None,
        new_consumer_translation_units=1,product_recompiles=0,retained_current_host_records=len(base[-1]),
        SDK_builds=0,NVCC_builds=0,network_requests=0,build_executed=False,native_executed=False)
    path=adapter.S/f'plan{attempt}.json'
    if path.exists():raise ValueError('Preserve immutable attempt plan')
    c.save(path,result);print(json.dumps(dict(plan=c.identity(path),blocked_pending_actual_pins=actual is None)))


def compile_one(adapter,entry,attempt):
    actual=artifacts(adapter);c,_=closure();h=c.helpers();recipe=proposed_recipe(c,adapter)
    path=adapter.S/f'prepared-recipe{attempt}.json'
    if path.exists():raise ValueError('Preserve immutable prepared recipe')
    c.save(path,recipe)
    h.S=adapter.S;h.RECIPES={'qwen-state':path};h.SOURCES={'qwen-state':SOURCE}
    h.compile_one('qwen-state',attempt)
    record_path=adapter.S/f'compile{attempt}/qwen-state/identity.json';record=c.check_record(record_path)
    if not any(c.resolve(x['path'])==adapter.HEADER.resolve()for x in record['dependencies']):raise ValueError('Actual artifact pin header missing from compiler dependencies')
    record.update(artifact_inputs=actual,artifact=adapter.ARTIFACT_TAG,entry=c.identity(entry),
        shared_helper=c.identity(Path(__file__)),consumer_translation_units=1,product_recompiles=0,SDK_builds=0,NVCC_builds=0)
    c.save(record_path,record)


def link(adapter,entry,attempt,compile_attempt):
    actual=artifacts(adapter);c,base=closure();plan,_,runtime_path,old_consumer,paths=base
    fresh_path=adapter.S/f'compile{compile_attempt}/qwen-state/identity.json';fresh=c.check_record(fresh_path)
    if fresh['artifact_inputs']!=actual or fresh['artifact']!=adapter.ARTIFACT_TAG:raise ValueError('Actual compiled artifact inputs changed')
    old_object=c.resolve(old_consumer['object']['path']);command=[];replaced=0
    for argument in plan['command']:
        if argument.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
        if argument.lower().endswith('.obj')and c.resolve(argument)==old_object:
            argument=fresh['object']['path'];replaced+=1
        command.append(argument)
    if replaced!=1:raise ValueError('Replace exactly the old Flash test TU')
    objects={str(c.resolve(x)).lower()for x in command if x.lower().endswith('.obj')}
    known={str(c.resolve(fresh['object']['path'])).lower()};records=[]
    for row in c.native_inputs():known.add(str(c.resolve(row['object']['path'])).lower())
    for row in plan['retained_inputs']:c.require(row);known.add(str(c.resolve(row['path'])).lower())
    for path in paths:
        record=c.read(path)
        if str(c.resolve(record['object']['path'])).lower()in objects:
            c.check_record(path);records.append(c.identity(path));known.add(str(c.resolve(record['object']['path'])).lower())
    if not objects<=known:raise ValueError('Unaccounted current object '+repr(objects-known))
    out=adapter.S/f'tests-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    image=out/'qwen-derived-checks.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,base=c.identity(c.BASE/'link-plan.json'),
        consumer_record=c.identity(fresh_path),retained_current_records=records,retained_inputs=plan['retained_inputs'],
        native_inputs=c.identity(c.S/'native-inputs.json'),artifact_inputs=actual,
        entry=c.identity(entry),shared_helper=c.identity(Path(__file__)),consumer_translation_units=1,product_recompiles=0,SDK_builds=0,NVCC_builds=0))
    h=c.helpers();env,_=h.b.environment(command,[],out);h.c.execute('link',command,env,out)
    runtime=c.read(runtime_path)
    for row in runtime['staged_dlls']:
        c.require(row);source=c.resolve(row['path']);os.link(source,out/source.name)
    runtime['PATH']=str(out)+os.pathsep+runtime['PATH'].replace(str(c.BASE_IMAGE),str(out))
    runtime.update(previous=c.identity(runtime_path),staged_dlls=[c.identity(p)for p in out.glob('*.dll')])
    runtime['matched_HC_PRE_worker']=runtime['staged_dlls'][0]
    c.save(out/'runtime-environment.json',runtime)
    c.save(out/'ready.json',dict(image=c.identity(image),link_plan=c.identity(out/'link-plan.json'),
        runtime_environment=c.identity(out/'runtime-environment.json'),consumer_record=c.identity(fresh_path),
        artifact=adapter.ARTIFACT_TAG,actual_artifact_inputs=actual))


def run(adapter,entry,args,listing=False):
    actual=artifacts(adapter);c,_=closure();image_dir=adapter.S/f'tests-link{args.link_attempt}';ready=c.read(image_dir/'ready.json')
    if ready['artifact']!=adapter.ARTIFACT_TAG or ready['actual_artifact_inputs']!=actual:raise ValueError('Image pins/source artifact differ')
    for key in('image','link_plan','runtime_environment','consumer_record'):c.require(ready[key])
    record=c.check_record(c.resolve(ready['consumer_record']['path']))
    if record['artifact_inputs']!=actual:raise ValueError('Compiled artifact pins changed')
    runtime=c.read(image_dir/'runtime-environment.json')
    for row in runtime['staged_dlls']:c.require(row)
    out=adapter.S/f'{"listing"if listing else"checks"}{args.attempt}';out.mkdir(exist_ok=False)
    case=adapter.CASES[args.case]
    command=[ready['image']['path'],'--gtest_filter='+case,'--gtest_throw_on_failure=1']
    command+=['--gtest_list_tests']if listing else['--gtest_output=xml:'+str(out/'results.xml')]
    env={key:value for key,value in os.environ.items()if not key.startswith('HYLE_QWEN')}
    env.update(PATH=runtime['PATH'],**{adapter.ENVIRONMENT:str(adapter.Q01/'original-roles')})
    c.save(out/'plan.json',dict(command=command,case=case,image=ready['image'],entry=c.identity(entry),
        shared_helper=c.identity(Path(__file__)),actual_artifact_inputs=actual,
        environment={key:value for key,value in env.items()if key=='PATH'or key.startswith('HYLE_QWEN')},
        cached_only=True,automatic_downloads=False,driver=None))
    q=module('_qwen_derived_run_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
    process=q.execute(command,env,out/'run',timeout=args.timeout)
    result=dict(process=process,image=ready['image'],consumer_record=ready['consumer_record'],
        artifact_inputs=actual,source=adapter.RUN_SOURCE,scope=adapter.RUN_SCOPE,
        placement='ordinary CUDA Context/device owner'if args.case=='cuda'else'ordinary CPU Context/system owner',
        cached_only=True,automatic_downloads=False,driver=None,throughput_evidence=False,memory_evidence=False)
    if process['exit']!=0 or process['timed_out']:
        result.update(passed=False);c.save(out/'summary.json',result);raise SystemExit(process['exit']or 1)
    try:
        if listing:
            lines=(out/'run/stdout.log').read_text('utf-8')
            if case.split('.',1)[1]not in lines:raise ValueError('Exact actual artifact case is not registered')
            result.update(passed=True,listing_only=True,native_model_executed=False)
        else:
            tree=ET.parse(out/'results.xml').getroot();cases=list(tree.iter('testcase'))
            if len(cases)!=1 or any(int(tree.get(key,'0'))for key in('failures','errors','disabled'))or list(tree.iter('skipped')):
                raise ValueError('Require one actual passing case, no skip/failure')
            node=cases[0]
            if node.get('classname')+'.'+node.get('name')!=case:raise ValueError('Wrong actual native case')
            properties={node.get('name'):node.get('value')for node in node.iter('property')}
            submissions=int(properties['actual_submissions'])
            if submissions<=0:raise ValueError('No actual Graph submissions')
            expected=dict(artifact_repository=adapter.REPOSITORY,artifact_revision=adapter.REVISION,
                original_role_count=str(adapter.ORIGINAL_ROLES),original_role_bytes=str(adapter.ORIGINAL_BYTES),
                target_packed_contractions='7',target_packed_recipe_nodes=str(adapter.REQUIRED_NODES),
                target_dense_weight_materializations='0')
            if adapter.SHAPE_METADATA_ROLES:expected['target_shape_metadata_roles']=str(adapter.SHAPE_METADATA_ROLES)
            if any(properties.get(key)!=value for key,value in expected.items()):raise ValueError('Actual native artifact/packed leaf properties differ')
            result.update(passed=True,tests=1,failures=0,skips=0,case=case,properties=properties,actual_graph_submissions=submissions)
    except Exception as error:
        result.update(passed=False,error=dict(type=type(error).__name__,message=str(error)))
        c.save(out/'summary.json',result)
        raise
    c.check_record(c.resolve(ready['consumer_record']['path']));c.save(out/'summary.json',result)
    print(json.dumps(dict(summary=c.identity(out/'summary.json'),passed=True)))


def main(adapter,entry_script):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=('plan','compile','link','run','list'))
    p.add_argument('--attempt',type=int,required=True);p.add_argument('--compile-attempt',type=int,default=1)
    p.add_argument('--link-attempt',type=int,default=1);p.add_argument('--case',choices=('cpu','cuda'),default='cpu')
    p.add_argument('--timeout',type=int,default=1800);args=p.parse_args()
    if min(args.attempt,args.compile_attempt,args.link_attempt,args.timeout)<=0:raise ValueError('Positive attempts/timeout required')
    if args.action=='plan':plan(adapter,entry_script,args.attempt)
    elif args.action=='compile':compile_one(adapter,entry_script,args.attempt)
    elif args.action=='link':link(adapter,entry_script,args.attempt,args.compile_attempt)
    else:run(adapter,entry_script,args,args.action=='list')
