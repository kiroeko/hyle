"""Root-only Q09 one-TU entry on the current ABI18 Graph/native closure.

The historical adapter supplies only its authenticated actual artifact/schema.
Compilation, link and exact CPU/CUDA execution reuse the shared current helper.
No action, downloader or native process runs on import.
"""
from pathlib import Path
import hashlib
import importlib.util
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
ENTRY=Path(__file__).resolve()
LEGACY=S/'build.py'
LEGACY_SHA='b5f8adc67e233b76bac7856007aed4c3c36eb4ba42bb9ed76f78cf86ff46ac72'
HELPER=S.parents[1]/'native_build_current.py'
HELPER_SHA='fc0bea30eabdf82286447fe29549bcf430204958c886007fb0963237ce764eb8'


def module(name,path,expected):
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise ValueError('Frozen Q09 metadata/current native helper changed: '+str(path))
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def configured():
    # Load the unchanged historical file IN PLACE so its __file__-relative
    # Q09 source paths remain exact. Do not call its old 13-host lifecycle.
    old=module('_q09_original_artifact_metadata_only',LEGACY,LEGACY_SHA)
    adapter=old.configured();adapter.ENTRY_SCRIPT=ENTRY
    helper=module('_q09_current_abi18_one_tu',HELPER,HELPER_SHA)
    return adapter,helper


if __name__=='__main__':
    actual,current=configured()
    current.main(actual,ENTRY)
