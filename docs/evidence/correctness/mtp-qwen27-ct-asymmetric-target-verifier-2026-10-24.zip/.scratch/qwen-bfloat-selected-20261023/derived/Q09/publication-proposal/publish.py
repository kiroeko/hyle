from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
SCRIPT=Path(__file__).resolve()
SHARED=SCRIPT.parents[2]/'publication-proposal/publish_current.py'
if __name__=='__main__':
    spec=importlib.util.spec_from_file_location('q09_actual_current_publisher',SHARED)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.main('Q09',SCRIPT)
