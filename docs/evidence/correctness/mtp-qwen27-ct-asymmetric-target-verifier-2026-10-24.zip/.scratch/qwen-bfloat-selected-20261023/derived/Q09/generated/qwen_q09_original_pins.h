#pragma once
#include <array>
#include <algorithm>
#include <span>
#include <vector>
#include "qwen_bfloat_original_roles.h"
#include "qwen_ct_asymmetric_projection_fragment.h"

// Actual acquisition pins; the shared Data/Bound and K1 controller are reused.
// Original CT triples remain packed; seven I64 shapes are authenticated metadata, not decode inputs.
namespace qwen_bfloat_original_artifacts::q09 {
namespace roles=qwen_bfloat_original_roles;
inline constexpr qwen_original_mtp_roles::Identity kIdentity{"cyankiwi/Qwen3.8-27B-AWQ-INT4","6e134bae811fb5adac50ee042ae5f029ac6779aa","compressed-tensors-asymmetric4-group32","model-00001-of-00005.safetensors+model-00002-of-00005.safetensors+model-00005-of-00005.safetensors"};
inline constexpr qwen_full_attention_fragment::Geometry kGeometry{5120,24,4,256,64,1.e-6F,0.F,hyle::compute::DataType::kBFloat16};
inline constexpr std::int64_t kIntermediate=17408,kVocabulary=248320;
inline constexpr float kRopeTheta=10'000'000.F;
inline constexpr std::uint64_t kOriginalBytes=6150228080ULL;
inline constexpr std::string_view kPlanSha256="de024cbff3441dcf45babf8e6a0c088edfbf88a6d63fa6700a61f2fe61651db3",kReceiptSha256="60d72be81d2598cf5f1f660627d457f303b803269ff5f1acbcfd4941b8f4d7e4",kManifestSha256="91a0458cd7a7242bcb515cdbffe85edbc85c06704109cf1f76326dcab697d3e5";
inline constexpr std::string_view kTargetLayer="model.language_model.layers.63",kTargetNorm="model.language_model.norm.weight";
inline constexpr roles::VocabularyNames kVocabularyNames{"model.language_model.embed_tokens.weight","lm_head.weight"};
// Both identities name this exact publisher artifact; no unpinned official base revision is inferred.
inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{
    .model_publisher="cyankiwi",.model_repository=kIdentity.repository,.model_family="qwen3.8",
    .model_name="Qwen3.8-27B-AWQ-INT4",.model_revision=kIdentity.revision,
    .configuration_digest="8a4c7cc94e338329a92ec9a1bb78cbd86f936de1c26aa82af90361ed5d3ef6a7",
    .artifact_repository=kIdentity.repository,.artifact_revision=kIdentity.revision,.variant=kIdentity.variant,
    .manifest_digest="82b1bf79f5b61333e83da17ec3bf89c9f178e29395a14c6b3ce3bbc474e1ead8",.format_family="safetensors"};
static_assert(kProfile.complete());
inline constexpr roles::DenseNormConventions kNormConventions{
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne};
inline constexpr std::array<roles::PinnedFile,17> kNextnFiles{{
    {"mtp.pre_fc_norm_hidden.weight.bf16","f2e1aa414ce84d89d016f2260923f7d47eb9827be043d1823dc6e783e4205efe"},
    {"mtp.pre_fc_norm_embedding.weight.bf16","9b03e3af7824cd765abdcfc21da960c25f3c7ee1294ce25c226f0ebc5ff39998"},
    {"mtp.fc.weight.bf16","4eee377b67ec2122cf214dbe6946d16261873441f1851d64409d9c7566bb20cc"},
    {"mtp.layers.0.input_layernorm.weight.bf16","bf04147cf2ecff83cd7b4f8b8611df55955041bc7749c95f6c9eb741e2ce7ec0"},
    {"mtp.layers.0.self_attn.q_proj.weight.bf16","8b27ef96b91e0b0564f82f11d9010efee6aa40a0eaa1900336bf597f767e7c98"},
    {"mtp.layers.0.self_attn.k_proj.weight.bf16","0ab4e67930451a2f1140e865d2e3e7e23cd752a3bb25042c36e7e546361073d0"},
    {"mtp.layers.0.self_attn.v_proj.weight.bf16","9606be457a48d7d9a78d72f255246f4e346845d752c1e82e41e14728255c5e13"},
    {"mtp.layers.0.self_attn.o_proj.weight.bf16","9165a161837a5d4489a838279805b15dd5b5827f1d3ac2f3f4067a71131a5fd7"},
    {"mtp.layers.0.self_attn.q_norm.weight.bf16","76aae220c35e2dea96f0985239b719fdcab93e208add6c32ca399b1166ec444e"},
    {"mtp.layers.0.self_attn.k_norm.weight.bf16","73723b12e89816afcc8faab883f88079f0eccf6c3208b2d7d851adc2597b3c63"},
    {"mtp.layers.0.post_attention_layernorm.weight.bf16","248f158f48a4b9b1d140e6728b77b19f132ae19de5cb60dac292742f7a695bbf"},
    {"mtp.layers.0.mlp.gate_proj.weight.bf16","e2fa26989b3103cc595990f53c13a295f95507d0a480276e642a084e6b1f62cc"},
    {"mtp.layers.0.mlp.up_proj.weight.bf16","8c6a44250d5976dc707703ea09e994eaeabef309c3faac8599e2e282eb4933ba"},
    {"mtp.layers.0.mlp.down_proj.weight.bf16","2fdda9751e3b7c1444632878283116550a1824dcad691aa8366793ba21faf935"},
    {"mtp.norm.weight.bf16","414fb74a971b168fb9a073c3486cbc61c46e992757179e724a345bbf56896fb1"},
    {"model.language_model.embed_tokens.weight.bf16","a158f24c6ad72736067768b4255e70a384e2e931f601b12f853e98ce83ec6bbe"},
    {"lm_head.weight.bf16","d922b751f014ee1139488cb94c0e164a1eb3da5c14048070ed1b784e00f92723"},
}};
struct Pin final {std::string_view name,file,sha256,dtype;std::array<std::int64_t,2> shape;std::size_t rank;std::uint64_t bytes;};
inline constexpr std::array<Pin,50> kPins{{
    {"lm_head.weight","lm_head.weight.bf16","d922b751f014ee1139488cb94c0e164a1eb3da5c14048070ed1b784e00f92723","BF16",{248320,5120},2,2542796800ULL},
    {"model.language_model.embed_tokens.weight","model.language_model.embed_tokens.weight.bf16","a158f24c6ad72736067768b4255e70a384e2e931f601b12f853e98ce83ec6bbe","BF16",{248320,5120},2,2542796800ULL},
    {"model.language_model.layers.63.mlp.down_proj.weight_shape","model.language_model.layers.63.mlp.down_proj.weight_shape.i64","7acd10fb9be3d798c256e4ff71b817cf7b0cf62082198552282304cc9e4b6b45","I64",{2,0},1,16ULL},
    {"model.language_model.layers.63.mlp.gate_proj.weight_shape","model.language_model.layers.63.mlp.gate_proj.weight_shape.i64","ed359d6e41d9162272e39902b72d0bf31ad123818df2f342f4bf9c46ebb042ec","I64",{2,0},1,16ULL},
    {"model.language_model.layers.63.mlp.up_proj.weight_shape","model.language_model.layers.63.mlp.up_proj.weight_shape.i64","ed359d6e41d9162272e39902b72d0bf31ad123818df2f342f4bf9c46ebb042ec","I64",{2,0},1,16ULL},
    {"model.language_model.layers.63.self_attn.k_proj.weight_shape","model.language_model.layers.63.self_attn.k_proj.weight_shape.i64","ab4883bc1598cd629f2bc82c74e40aa4bde410d948f89569dec2d5ccfa5d1885","I64",{2,0},1,16ULL},
    {"model.language_model.layers.63.self_attn.o_proj.weight_shape","model.language_model.layers.63.self_attn.o_proj.weight_shape.i64","e3c58b0403fe1948b42966e7b979908a292b37e7a0ffdfb096567624f7e5d6eb","I64",{2,0},1,16ULL},
    {"model.language_model.layers.63.self_attn.q_proj.weight_shape","model.language_model.layers.63.self_attn.q_proj.weight_shape.i64","a095b60cc6af063fe6c9866c2c90d94845ec5285c56e6ae4c91536d1297bb19b","I64",{2,0},1,16ULL},
    {"model.language_model.layers.63.self_attn.v_proj.weight_shape","model.language_model.layers.63.self_attn.v_proj.weight_shape.i64","ab4883bc1598cd629f2bc82c74e40aa4bde410d948f89569dec2d5ccfa5d1885","I64",{2,0},1,16ULL},
    {"model.language_model.layers.63.mlp.down_proj.weight_packed","model.language_model.layers.63.mlp.down_proj.weight_packed.i32","099dd01fc7eadb83a264d83e9f29c47ee9322d19d1a3f2a7a79324c693b6aa60","I32",{5120,2176},2,44564480ULL},
    {"model.language_model.layers.63.mlp.down_proj.weight_zero_point","model.language_model.layers.63.mlp.down_proj.weight_zero_point.i32","063e3b4206fe08ffdd8b3ff77cc3a4cd1b1ef77afa20018a60933950c4a55901","I32",{640,544},2,1392640ULL},
    {"model.language_model.layers.63.mlp.gate_proj.weight_packed","model.language_model.layers.63.mlp.gate_proj.weight_packed.i32","27d503aa52354a80a18f402de70f24148da9505c7a99384eca4b23d3a1ad8291","I32",{17408,640},2,44564480ULL},
    {"model.language_model.layers.63.mlp.gate_proj.weight_zero_point","model.language_model.layers.63.mlp.gate_proj.weight_zero_point.i32","5f3b3f404cbc7907be9b091009637c62ce60b89960720389b28f6ac968d0619c","I32",{2176,160},2,1392640ULL},
    {"model.language_model.layers.63.mlp.up_proj.weight_packed","model.language_model.layers.63.mlp.up_proj.weight_packed.i32","13983cbb143da30e6e209eb962acb79027ad25f85dcc890e7c6e90be347ecb86","I32",{17408,640},2,44564480ULL},
    {"model.language_model.layers.63.mlp.up_proj.weight_zero_point","model.language_model.layers.63.mlp.up_proj.weight_zero_point.i32","74777288c8da5c48c2ed0c26f749b21075a04e61aded21824302a52fa58d401c","I32",{2176,160},2,1392640ULL},
    {"model.language_model.layers.63.self_attn.k_proj.weight_packed","model.language_model.layers.63.self_attn.k_proj.weight_packed.i32","33e05091a66cc3df67760ca46777a35724cff9b372aba77dfdc9318b12191cd7","I32",{1024,640},2,2621440ULL},
    {"model.language_model.layers.63.self_attn.k_proj.weight_zero_point","model.language_model.layers.63.self_attn.k_proj.weight_zero_point.i32","314730516af42ba6f92a86ad9bcf7b377481826a4ea9cd07418f5eefeaab0a8f","I32",{128,160},2,81920ULL},
    {"model.language_model.layers.63.self_attn.o_proj.weight_packed","model.language_model.layers.63.self_attn.o_proj.weight_packed.i32","4116617ab9fd135e63aa5b8f85fea690b1767d37e2410a5c772a215dc1a3a0e9","I32",{5120,768},2,15728640ULL},
    {"model.language_model.layers.63.self_attn.o_proj.weight_zero_point","model.language_model.layers.63.self_attn.o_proj.weight_zero_point.i32","fc09fdc638a69dfceec657db0e2192f100c95204f2c910a365bd5f1186597389","I32",{640,192},2,491520ULL},
    {"model.language_model.layers.63.self_attn.q_proj.weight_packed","model.language_model.layers.63.self_attn.q_proj.weight_packed.i32","22f646c58aa08dda9a6e1e2828c02abbcceedf2753e6accbe7a55b8c25dd04a6","I32",{12288,640},2,31457280ULL},
    {"model.language_model.layers.63.self_attn.q_proj.weight_zero_point","model.language_model.layers.63.self_attn.q_proj.weight_zero_point.i32","7df58f333792f989914f7c2d72ec6a6efae86b0de9a1321c1544df12d2f5f195","I32",{1536,160},2,983040ULL},
    {"model.language_model.layers.63.self_attn.v_proj.weight_packed","model.language_model.layers.63.self_attn.v_proj.weight_packed.i32","94a1d64f5053cc61dd0ad6b6dbcc3a5835d8baff940871526913fe058021d51a","I32",{1024,640},2,2621440ULL},
    {"model.language_model.layers.63.self_attn.v_proj.weight_zero_point","model.language_model.layers.63.self_attn.v_proj.weight_zero_point.i32","6a5ab6cfd0e9a25c065c0844f9a5dcdf1cd4d66d19998c58d9c0be4419944f7f","I32",{128,160},2,81920ULL},
    {"model.language_model.layers.63.input_layernorm.weight","model.language_model.layers.63.input_layernorm.weight.bf16","6063271dfd6ef11bca97bcd64583736b79c1426f501f42e1dc2ab697ee1f1821","BF16",{5120,0},1,10240ULL},
    {"model.language_model.layers.63.mlp.down_proj.weight_scale","model.language_model.layers.63.mlp.down_proj.weight_scale.bf16","a0baf78929d934784dfa70a9caef0df309b5e76979d8cbd9f1a6b8697be174a5","BF16",{5120,544},2,5570560ULL},
    {"model.language_model.layers.63.mlp.gate_proj.weight_scale","model.language_model.layers.63.mlp.gate_proj.weight_scale.bf16","303d037d0d26c90ac71fb3447af54bc4837d6630ce09fdfdcbca079fc6eaf575","BF16",{17408,160},2,5570560ULL},
    {"model.language_model.layers.63.mlp.up_proj.weight_scale","model.language_model.layers.63.mlp.up_proj.weight_scale.bf16","724e1adcb5ec00af3979960614e9f279a5141442664145024bc59ddae772b2c9","BF16",{17408,160},2,5570560ULL},
    {"model.language_model.layers.63.post_attention_layernorm.weight","model.language_model.layers.63.post_attention_layernorm.weight.bf16","4c30659f6d5bab82d46e36f23c9dbf95914f89a9bdae974a484ccd5bf63ec886","BF16",{5120,0},1,10240ULL},
    {"model.language_model.layers.63.self_attn.k_norm.weight","model.language_model.layers.63.self_attn.k_norm.weight.bf16","58ae73cc19dff3cc4cae72aaefaa510fd271d933696da3b1be8299db8a7ec5e3","BF16",{256,0},1,512ULL},
    {"model.language_model.layers.63.self_attn.k_proj.weight_scale","model.language_model.layers.63.self_attn.k_proj.weight_scale.bf16","7ba762d168f1837ab5695418a7d831f51362953f623faf5439a87e43bf8fd7a1","BF16",{1024,160},2,327680ULL},
    {"model.language_model.layers.63.self_attn.o_proj.weight_scale","model.language_model.layers.63.self_attn.o_proj.weight_scale.bf16","ef2070551d2ddd7ef43120441df3241c06fb44687edaf7b0c58e98ac8ec4950a","BF16",{5120,192},2,1966080ULL},
    {"model.language_model.layers.63.self_attn.q_norm.weight","model.language_model.layers.63.self_attn.q_norm.weight.bf16","035d97478264d1f88d495c92e7334d4949de15f0cb0b3f14edda5301e3e6f346","BF16",{256,0},1,512ULL},
    {"model.language_model.layers.63.self_attn.q_proj.weight_scale","model.language_model.layers.63.self_attn.q_proj.weight_scale.bf16","e2c63a7708baa512ee1cfa9ccfe9bc9aa4255587dd4d6b11b91fa337d03ddd37","BF16",{12288,160},2,3932160ULL},
    {"model.language_model.layers.63.self_attn.v_proj.weight_scale","model.language_model.layers.63.self_attn.v_proj.weight_scale.bf16","49450f0675b1ad04dade998460444f952b2a4cfa420c5cdcf029d65c8a3db06d","BF16",{1024,160},2,327680ULL},
    {"model.language_model.norm.weight","model.language_model.norm.weight.bf16","34176df74e0bcfe0283dac5ecf5de6832935d2c4e959de7c56bf0eaac29f041c","BF16",{5120,0},1,10240ULL},
    {"mtp.fc.weight","mtp.fc.weight.bf16","4eee377b67ec2122cf214dbe6946d16261873441f1851d64409d9c7566bb20cc","BF16",{5120,10240},2,104857600ULL},
    {"mtp.layers.0.input_layernorm.weight","mtp.layers.0.input_layernorm.weight.bf16","bf04147cf2ecff83cd7b4f8b8611df55955041bc7749c95f6c9eb741e2ce7ec0","BF16",{5120,0},1,10240ULL},
    {"mtp.layers.0.mlp.down_proj.weight","mtp.layers.0.mlp.down_proj.weight.bf16","2fdda9751e3b7c1444632878283116550a1824dcad691aa8366793ba21faf935","BF16",{5120,17408},2,178257920ULL},
    {"mtp.layers.0.mlp.gate_proj.weight","mtp.layers.0.mlp.gate_proj.weight.bf16","e2fa26989b3103cc595990f53c13a295f95507d0a480276e642a084e6b1f62cc","BF16",{17408,5120},2,178257920ULL},
    {"mtp.layers.0.mlp.up_proj.weight","mtp.layers.0.mlp.up_proj.weight.bf16","8c6a44250d5976dc707703ea09e994eaeabef309c3faac8599e2e282eb4933ba","BF16",{17408,5120},2,178257920ULL},
    {"mtp.layers.0.post_attention_layernorm.weight","mtp.layers.0.post_attention_layernorm.weight.bf16","248f158f48a4b9b1d140e6728b77b19f132ae19de5cb60dac292742f7a695bbf","BF16",{5120,0},1,10240ULL},
    {"mtp.layers.0.self_attn.k_norm.weight","mtp.layers.0.self_attn.k_norm.weight.bf16","73723b12e89816afcc8faab883f88079f0eccf6c3208b2d7d851adc2597b3c63","BF16",{256,0},1,512ULL},
    {"mtp.layers.0.self_attn.k_proj.weight","mtp.layers.0.self_attn.k_proj.weight.bf16","0ab4e67930451a2f1140e865d2e3e7e23cd752a3bb25042c36e7e546361073d0","BF16",{1024,5120},2,10485760ULL},
    {"mtp.layers.0.self_attn.o_proj.weight","mtp.layers.0.self_attn.o_proj.weight.bf16","9165a161837a5d4489a838279805b15dd5b5827f1d3ac2f3f4067a71131a5fd7","BF16",{5120,6144},2,62914560ULL},
    {"mtp.layers.0.self_attn.q_norm.weight","mtp.layers.0.self_attn.q_norm.weight.bf16","76aae220c35e2dea96f0985239b719fdcab93e208add6c32ca399b1166ec444e","BF16",{256,0},1,512ULL},
    {"mtp.layers.0.self_attn.q_proj.weight","mtp.layers.0.self_attn.q_proj.weight.bf16","8b27ef96b91e0b0564f82f11d9010efee6aa40a0eaa1900336bf597f767e7c98","BF16",{12288,5120},2,125829120ULL},
    {"mtp.layers.0.self_attn.v_proj.weight","mtp.layers.0.self_attn.v_proj.weight.bf16","9606be457a48d7d9a78d72f255246f4e346845d752c1e82e41e14728255c5e13","BF16",{1024,5120},2,10485760ULL},
    {"mtp.norm.weight","mtp.norm.weight.bf16","414fb74a971b168fb9a073c3486cbc61c46e992757179e724a345bbf56896fb1","BF16",{5120,0},1,10240ULL},
    {"mtp.pre_fc_norm_embedding.weight","mtp.pre_fc_norm_embedding.weight.bf16","9b03e3af7824cd765abdcfc21da960c25f3c7ee1294ce25c226f0ebc5ff39998","BF16",{5120,0},1,10240ULL},
    {"mtp.pre_fc_norm_hidden.weight","mtp.pre_fc_norm_hidden.weight.bf16","f2e1aa414ce84d89d016f2260923f7d47eb9827be043d1823dc6e783e4205efe","BF16",{5120,0},1,10240ULL},
}};
inline const Pin &pin(std::string_view name) {
  const auto found=std::find_if(kPins.begin(),kPins.end(),[&](const auto &x){return x.name==name;});
  if(found==kPins.end())throw std::runtime_error("Q09 role absent from actual authenticated header");return *found;
}
inline std::array<qwen_ct_asymmetric_projection_fragment::Names,7> target_projection_names() {
  return {{
    {"model.language_model.layers.63.self_attn.q_proj.weight_packed","model.language_model.layers.63.self_attn.q_proj.weight_zero_point","model.language_model.layers.63.self_attn.q_proj.weight_scale","model.language_model.layers.63.self_attn.q_proj.weight_shape",32},
    {"model.language_model.layers.63.self_attn.k_proj.weight_packed","model.language_model.layers.63.self_attn.k_proj.weight_zero_point","model.language_model.layers.63.self_attn.k_proj.weight_scale","model.language_model.layers.63.self_attn.k_proj.weight_shape",32},
    {"model.language_model.layers.63.self_attn.v_proj.weight_packed","model.language_model.layers.63.self_attn.v_proj.weight_zero_point","model.language_model.layers.63.self_attn.v_proj.weight_scale","model.language_model.layers.63.self_attn.v_proj.weight_shape",32},
    {"model.language_model.layers.63.self_attn.o_proj.weight_packed","model.language_model.layers.63.self_attn.o_proj.weight_zero_point","model.language_model.layers.63.self_attn.o_proj.weight_scale","model.language_model.layers.63.self_attn.o_proj.weight_shape",32},
    {"model.language_model.layers.63.mlp.gate_proj.weight_packed","model.language_model.layers.63.mlp.gate_proj.weight_zero_point","model.language_model.layers.63.mlp.gate_proj.weight_scale","model.language_model.layers.63.mlp.gate_proj.weight_shape",32},
    {"model.language_model.layers.63.mlp.up_proj.weight_packed","model.language_model.layers.63.mlp.up_proj.weight_zero_point","model.language_model.layers.63.mlp.up_proj.weight_scale","model.language_model.layers.63.mlp.up_proj.weight_shape",32},
    {"model.language_model.layers.63.mlp.down_proj.weight_packed","model.language_model.layers.63.mlp.down_proj.weight_zero_point","model.language_model.layers.63.mlp.down_proj.weight_scale","model.language_model.layers.63.mlp.down_proj.weight_shape",32},
  }};
}
inline std::vector<roles::Spec> specs() {
  auto result=roles::dense_specs(kGeometry,kIntermediate,kVocabulary,kNextnFiles,kVocabularyNames);result.reserve(kPins.size());
  const auto names=target_projection_names();
  constexpr std::array<std::int64_t,7> outputs{12288,1024,1024,5120,17408,17408,5120},widths{5120,5120,5120,6144,5120,5120,17408};
  for(std::size_t slot=0;slot<names.size();++slot) {
    const auto &p=names[slot];const std::array ids{p.codes,p.zeros,p.scales,p.shape};std::array<roles::PinnedFile,4> files;
    for(std::size_t n=0;n<4;++n){const auto &x=pin(ids[n]);files[n]={x.file,x.sha256};}
    const auto quartet=roles::ct_asymmetric_projection_specs(outputs[slot],widths[slot],p.group_size,ids,files);
    result.insert(result.end(),quartet.begin(),quartet.end());
  }
  {const auto &x=pin("model.language_model.layers.63.input_layernorm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({5120},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.63.self_attn.q_norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({256},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.63.self_attn.k_norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({256},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.63.post_attention_layernorm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({5120},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({5120},hyle::compute::DataType::kBFloat16)});}
  if(result.size()!=kPins.size())throw std::runtime_error("original CT source requires its unique physical roles");std::uint64_t bytes=0;
  for(std::size_t slot=0;slot<result.size();++slot) {
    const auto &s=result[slot];const auto &p=pin(s.name);const auto &d=s.description;
    const auto type=d.data_type()==hyle::compute::DataType::kBFloat16?"BF16":d.data_type()==hyle::compute::DataType::kFloat16?"F16":d.data_type()==hyle::compute::DataType::kInt32?"I32":d.data_type()==hyle::compute::DataType::kInt64?"I64":"unsupported";
    if(s.file!=p.file||s.sha256!=p.sha256||p.dtype!=type||d.rank()!=p.rank||
        !std::equal(d.dimensions().begin(),d.dimensions().end(),p.shape.begin())||
        qwen_original_mtp_roles::detail::take(d.required_bytes(),"Q09 actual role extent")!=p.bytes)
      throw std::runtime_error("Q09 typed role differs from actual name/dtype/shape/bytes/SHA");
    for(std::size_t previous=0;previous<slot;++previous)if(result[previous].name==s.name)throw std::runtime_error("Q09 physical role cannot be duplicated");
    bytes+=p.bytes;
  }
  if(bytes!=kOriginalBytes)throw std::runtime_error("Q09 original source total differs");return result;
}
inline void validate_shapes(const roles::Data &source) {
  roles::require_ct_shape(source.bytes("model.language_model.layers.63.self_attn.q_proj.weight_shape"),12288,5120);
  roles::require_ct_shape(source.bytes("model.language_model.layers.63.self_attn.k_proj.weight_shape"),1024,5120);
  roles::require_ct_shape(source.bytes("model.language_model.layers.63.self_attn.v_proj.weight_shape"),1024,5120);
  roles::require_ct_shape(source.bytes("model.language_model.layers.63.self_attn.o_proj.weight_shape"),5120,6144);
  roles::require_ct_shape(source.bytes("model.language_model.layers.63.mlp.gate_proj.weight_shape"),17408,5120);
  roles::require_ct_shape(source.bytes("model.language_model.layers.63.mlp.up_proj.weight_shape"),17408,5120);
  roles::require_ct_shape(source.bytes("model.language_model.layers.63.mlp.down_proj.weight_shape"),5120,17408);
}
} // namespace qwen_bfloat_original_artifacts::q09
