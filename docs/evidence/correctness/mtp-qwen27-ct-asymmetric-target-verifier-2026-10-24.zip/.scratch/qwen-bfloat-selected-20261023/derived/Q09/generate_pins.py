"""Q09 actual50 pins on the shared immutable artifact generator.

No header before all original files/receipts complete. Original I64 N/K values
are read/authenticated and compared; no metadata-only or fake pins are emitted.
"""
import hashlib
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[3]
TEMPLATE=S.parent/'Q01/generate_pins.py'
TEMPLATE_SHA='310955e079d976dac5568316eae46ccf1ed521bcf3b89ca7bd796a0df8e34e54'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


assert hashlib.sha256(TEMPLATE.read_bytes()).hexdigest()==TEMPLATE_SHA
shared=load('q09_shared_actual_pin_template',TEMPLATE)
fetch=load('q09_original_ct_source_metadata',S/'fetch_roles.py')
PROFILE=dict(family='qwen3.8',model_name='Qwen3.8-27B-AWQ-INT4',publisher='cyankiwi',weight_format='ct-asymmetric4',
    config_sha='8a4c7cc94e338329a92ec9a1bb78cbd86f936de1c26aa82af90361ed5d3ef6a7',
    header_sha='82b1bf79f5b61333e83da17ec3bf89c9f178e29395a14c6b3ce3bbc474e1ead8')


def checked_metadata():return shared.checked_metadata(fetch,weight_format='ct-asymmetric4')


def header(plan,rows,receipt_sha,manifest_sha):
    return shared.header(plan,rows,receipt_sha,manifest_sha,source=fetch,tag='q09',**PROFILE)


def main():shared.main_for(fetch,tag='q09',**PROFILE)


if __name__=='__main__':main()
