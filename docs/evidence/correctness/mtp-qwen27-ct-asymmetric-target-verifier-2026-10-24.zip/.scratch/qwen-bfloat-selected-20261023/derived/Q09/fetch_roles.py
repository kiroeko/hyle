"""Root-only Q09 selected50-role wrapper on the existing loose-role transport.

Fixed CT-asymmetric source identity and original I32/BF16/I64 shapes, not AWQ
GEMM packing. Definitions do no HTTP. No main runs on import; no whole shards.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[3]
REPO,REV='cyankiwi/Qwen3.8-27B-AWQ-INT4','6e134bae811fb5adac50ee042ae5f029ac6779aa'
COUNT,BODY=50,6150228080
CHUNK,REQUEST_CHUNK,IO,WORKERS=128*1024*1024,8*1024*1024,1024*1024,3
PLAN_FILE=S/'roles-plan.json'
PLAN_SHA='de024cbff3441dcf45babf8e6a0c088edfbf88a6d63fa6700a61f2fe61651db3'
Q01=S.parent/'Q01/fetch_roles.py'
Q01_SHA='b583d84e47d6d252b170194fa00720f1f091545c377666f87485d43978f1f577'


def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))


def identity(p):
    b=p.read_bytes()  # Only explicit small metadata,never full role bodies.
    return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def checked_plan():
    assert identity(PLAN_FILE)['sha256']==PLAN_SHA
    plan=read(PLAN_FILE)
    assert (plan['repository'],plan['revision'],plan['original_roles'],plan['source_bytes'])==(REPO,REV,COUNT,BODY)
    assert plan['metadata_only'] and plan['complete_absolute_ranges'] and plan['strict_download_metadata_complete']
    assert plan['geometry']==dict(hidden=5120,heads=24,kv_heads=4,depth=256,rotary=64,
        intermediate=17408,vocabulary=248320,target_layer=63,target_type='full_attention',group=32)
    config=S/'source/config.json'
    assert identity(config)['sha256']=='8a4c7cc94e338329a92ec9a1bb78cbd86f936de1c26aa82af90361ed5d3ef6a7'
    cfg=read(config);qc=cfg['quantization_config'];group=qc['config_groups']['group_0'];tc=cfg['text_config']
    assert qc['quant_method']=='compressed-tensors' and group['format']=='pack-quantized'
    assert group['input_activations'] is None and group['output_activations'] is None
    assert group['weights']['num_bits']==4 and group['weights']['group_size']==32 and group['weights']['symmetric'] is False
    assert group['weights']['actorder'] is None and tc['dtype']=='bfloat16' and tc['tie_word_embeddings'] is False
    assert (tc['hidden_size'],tc['num_attention_heads'],tc['num_key_value_heads'],tc['head_dim'],tc['intermediate_size'],tc['vocab_size'])==(5120,24,4,256,17408,248320)
    assert plan['vocabulary']==dict(embedding='model.language_model.embed_tokens.weight',head='lm_head.weight',unique_banks=2)
    assert len(plan['roles'])==len({x['name'] for x in plan['roles']})==len({x['filename'] for x in plan['roles']})==COUNT
    for item in plan['source_entries']:
        x=item.get('extracted',item.get('cached'));assert identity(R/x['path'])==x
    index=read(S/'source/model.safetensors.index.json')['weight_map']
    assert not any('weight_g_idx' in name for name in index),'This CT source declares natural groups,not an ignored permutation'
    headers=[]
    for shard in plan['shards']:
        assert identity(R/shard['header']['path'])==shard['header']
        h=read(R/shard['header']['path']);headers.append(h)
        assert shard['data_base']==shard['header']['bytes']+8
        assert shard['data_base']+max(x['data_offsets'][1] for k,x in h.items() if k!='__metadata__')==shard['whole_file_bytes']
        assert shard['url']==f'https://huggingface.co/{REPO}/resolve/{REV}/'+shard['file']
        assert shard['etag'].startswith('"') and shard['etag'].endswith('"')
    total=0
    for row in plan['roles']:
        shard=plan['shards'][row['source_shard']];h=headers[row['source_shard']][row['name']]
        assert index[row['name']]==row['source_file']==shard['file'] and row['dtype']==h['dtype'] and row['shape']==h['shape']
        assert row['data_relative_half_open']==h['data_offsets'] and Path(row['filename']).name==row['filename']
        first,end=h['data_offsets'];assert end-first==row['bytes']==math.prod(row['shape'])*{'BF16':2,'I32':4,'I64':8}[row['dtype']]>0
        assert row['absolute_inclusive']==[shard['data_base']+first,shard['data_base']+end-1]
        assert row['absolute_inclusive'][1]<shard['whole_file_bytes'];total+=row['bytes']
    assert total==BODY
    return PLAN_FILE,plan


def configured():
    path,plan=checked_plan()
    assert identity(Q01)['sha256']==Q01_SHA
    spec=importlib.util.spec_from_file_location('q09_existing_loose_role_transport',Q01)
    job=importlib.util.module_from_spec(spec);spec.loader.exec_module(job)
    job.S,job.REPO,job.REV,job.COUNT,job.BODY=S,REPO,REV,COUNT,BODY
    job.PLAN_FILE,job.PLAN_SHA=path,PLAN_SHA
    job.FILE_DESCRIPTION='+'.join(x['file'] for x in plan['shards'])
    job.VARIANT='compressed-tensors-asymmetric4-group32'
    job.checked_plan=lambda:(path,plan)
    common_manifest=job.manifest
    def manifest(out,record,actual_plan):
        common_manifest(out,record,actual_plan)
        target=out/'manifest.json'
        value=read(target)
        value['scope']=('Unchanged selected Q09 ranges only. Two independent original BF16 vocabulary banks; '
            'original CT asymmetric4/group32 target I32 codes/zeros, BF16 scales and authenticated I64 shape. '
            'No GPTQ zero+1, F16 scale store, g_idx or AWQ-GEMM4 layout. '
            'ETag is object identity, not an asserted whole-file content SHA.')
        target.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    job.manifest=manifest
    return job


def main():
    job=configured();job.__doc__=__doc__;job.main()


if __name__=='__main__':main()
