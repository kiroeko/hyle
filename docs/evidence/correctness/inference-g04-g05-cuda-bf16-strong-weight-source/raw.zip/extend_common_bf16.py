from pathlib import Path
p=Path('tests/compute_batch/encoded_page_common_consumer.cc')
s=p.read_text(encoding='utf-8')
assert 'BFloat16IncrementalAndFailureConsumers' not in s
s=s.replace('bool paired_failure=false,bool single=false){','bool paired_failure=false,bool single=false,bool bf16=false){')
s=s.replace('  const c::BatchCapacity capacity{.query_type=c::DataType::kFloat16, .output_type=c::DataType::kFloat16,','''  const auto qtype=bf16?c::DataType::kBFloat16:c::DataType::kFloat16;
  const auto decode_word=[bf16](std::uint16_t word)->double {
    return bf16?half_test::decode(hyle::simd::bfloat16_t::from_bits(word)):
                half_test::decode(F16::from_bits(word));
  };
  const double tolerance=bf16?.008:.002;
  const c::BatchCapacity capacity{.query_type=qtype, .output_type=qtype,''')
s=s.replace('query_words(*query_desc.element_count(),0x3000)','query_words(*query_desc.element_count(),bf16?0x3e00:0x3000)')
s=s.replace('cpu_graph?c::DataType::kFloat32:c::DataType::kFloat16','cpu_graph?c::DataType::kFloat32:qtype')
s=s.replace('c::Cast{c::DataType::kFloat16}','c::Cast{qtype}')
s=s.replace('>.002','>tolerance').replace('<.002','<tolerance')
s=s.replace('half_test::decode(F16::from_bits(words[i]))','decode_word(words[i])')
s=s.replace('half_test::decode(F16::from_bits(words[(qp[request]+row)*8*dv+i]))','decode_word(words[(qp[request]+row)*8*dv+i])')
s+='''
TEST(EncodedCommonPages, BFloat16IncrementalAndFailureConsumers){
#if defined(HYLE_ENCODED_CUDA)
  constexpr unsigned modes=3;
#else
  constexpr unsigned modes=2;
#endif
  for(unsigned mode=0;mode<modes;++mode)for(bool single:{false,true})
    for(auto dims:{std::array{64u,128u},std::array{256u,256u}}){
      SCOPED_TRACE(::testing::Message()<<"BF16 mode="<<mode<<" single="<<single<<" D="<<dims[0]<<"/"<<dims[1]);
      const auto status=episode(dims[0],dims[1],mode,false,false,single,true);
      ASSERT_TRUE(status.ok())<<status.message();
    }
  for(unsigned mode=0;mode<modes;++mode)for(bool paired:{false,true}){
    SCOPED_TRACE(::testing::Message()<<"BF16 mode="<<mode<<" paired="<<paired);
    const auto status=episode(64,128,mode,true,paired,false,true);
    ASSERT_TRUE(status.ok())<<status.message();
  }
}
'''
p.write_text(s,encoding='utf-8',newline='\n')
