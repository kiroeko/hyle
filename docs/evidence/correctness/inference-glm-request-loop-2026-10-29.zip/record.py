from pathlib import Path
import importlib.util
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('current_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin = b.read, b.save, b.pin
attempt = sys.argv[1] if len(sys.argv) > 1 else 'attempt1'
folder = W / 'runs/glm-cuda' / attempt
process = read(folder / 'process.json')
assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
root = ET.parse(folder / 'results.xml').getroot()
assert root.get('tests') == '1' and root.get('failures') == '0' and not root.findall('.//skipped')
properties = {p.get('name'): p.get('value') for p in root.findall('.//property')}
previous_xml = R / '.scratch/inference-commit-observation-20261029/runs/glm-cuda/owner-fix/results.xml'
previous = {p.get('name'): p.get('value') for p in ET.parse(previous_xml).getroot().findall('.//property')}
preserved = ['request_directory_r0_pending', 'request_directory_r0_committed_draws',
    'request_progress_output_counts', 'request_progress_committed_observations',
    'request_progress_duplicate_commit_noops', 'request_progress_full_hit_outputs',
    'request_progress_pending_only_turn_inputs', 'request_record_committed_prefixes',
    'request_record_head_publications', 'request_record_late_catchup_refusals',
    'request_record_observer_refusals', 'request_record_observer_retry_graphs',
    'request_record_observer_retry_head_publications', 'request_record_observer_retry_rng_draws',
    'request_directory_requests', 'request_directory_turns', 'request_directory_fifo',
    'request_directory_full_hits', 'request_directory_same_request_restore_graphs',
    'request_directory_new_request_draws', 'request_directory_cancelled_forks',
    'request_directory_stale_forks', 'original_target_roles', 'original_target_source_bytes',
    'actual_target_calls', 'actual_target_submissions', 'actual_target_policy_submissions',
    'accepted_target_conditioned_repairs', 'actual_accepted_kv_repair_submissions',
    'random_accepted', 'random_rejected', 'random_actual_proposal', 'random_committed_draws',
    'actual_nextn_steps', 'actual_catchups', 'actual_target_conditioned_repairs', 'state_budget_bytes']
for name in preserved:
    assert properties[name] == previous[name], (name, previous[name], properties.get(name))
receipt = b.receipt()
plan = read(W / 'plan.json')
for item in plan['retained']:
    b.exact(item)
compiles = [read(p) for p in sorted((W / 'compile').rglob('process.json'))]
links = [read(p) for p in sorted((W / 'link').rglob('process.json'))]
runs = {str(p.parent.relative_to(W)): read(p) for p in sorted((W / 'runs').rglob('process.json'))}
source_names = [
    'tests/compute_models/glm_pro_mtp_state_consumer_test.cc',
    'engine/inference/request_loop.h', 'engine/inference/request_wave_execution.h',
    'engine/inference/commit_observation.h', 'engine/inference/request_progress.h']
save(W / 'reuse.json', dict(schema='hyle.glm-request-loop.reuse.v1',
    current_qwen_link_base=plan['base'], glm_compile=plan['compile'], glm_link=plan['link'],
    current_glm_receipt=pin(W / 'compile/glm/receipt.json'),
    note='No SDK source was changed. Reuse the original 227 SDK inputs. Keep current GLM object and original independent early-history consumer object.'))
archive = R / 'docs/evidence/correctness/inference-glm-request-loop-2026-10-29.zip'
files = set()
for pattern in ['*.py', 'plan.json', 'references.json', 'reuse.json',
    'compile/**/*.json', 'compile/**/*.log', 'compile/**/consumer.cc',
    'link/**/*.json', 'link/**/*.log', 'runs/**/*.json', 'runs/**/*.log', 'runs/**/*.xml',
    'cleanup-*.json', 'cleanup.ps1']:
    files.update(W.glob(pattern))
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(files):
        z.write(path, str(path.relative_to(W)).replace('\\', '/'))
    for name in source_names:
        z.write(R / name, 'source/' + name)
report = dict(schema='hyle.correctness.glm-request-loop.v1', date='2026-10-29', status='PASS',
    base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    changes=[
        'Original finite GLM target77/NextN78 journey executes real work inside RequestLoop waves; FIFO, admission, turn changes and original-owner retirement use existing common contracts.',
        'A natural K1 committed result with late host observer refusal is observed by a later pump without a new Graph, Head publication or RNG draw.',
        'Full-prefix new-request sampling preserves its independent cursor and does not invent a Graph commit; same-request restoration consumes its historical pending.',
        'Shared scheduling does not require Qwen GDN, paged Frame or hidden-state geometry. Family StateStore/StateHead and original programs remain authoritative.'],
    counts=dict(CXX_attempts=len(compiles), links=len(links), retained_SDK_inputs=227,
        SDK_CXX=0, NVCC=0, full_builds=0, native_processes=len(runs),
        passed_native_processes=sum(p['exit'] == 0 and not p['timed_out'] for p in runs.values()), downloads=0),
    build=dict(compiles=compiles, links=links, object=receipt['object']),
    result=dict(process=process, properties=properties, preserved_previous_fields=preserved,
        previous_result=pin(previous_xml)), attempts=runs,
    references=read(W / 'references.json'),
    sources=[pin(R / name) for name in source_names], archive=pin(archive),
    boundaries=[
        'One finite CUDA GLM component case using cached original target77 and NextN78 weights, actual global-expert supply and full-vocabulary projection; upstream activations and initial history remain explicit fixtures.',
        'N1 limits current resident logical Heads; immutable states retained by readers and PrefixDirectory do not become extra active requests.',
        'Existing complete-state immutability, cancel/stale refusal, original native counts, cold host capacities and final version/draft collection assertions remain meaningful checks.',
        'Actual original Invocation completion/drain determines retirement; StateStore collection is not native retirement. No native fault injection or unknown-device recovery claim.',
        'No arbitrary GLM prompt prefill, complete78-layer generation, full second CLI model, serving API, multiple-GPU implementation, task quality or throughput measurement claim.',
        'The separate non-request GLM K1/K2 cases were compiled in the same consumer translation unit, not rerun in this slice.',
        'No original SDK or provider mathematics changed; no need to rebuild or rerun unrelated Qwen consumers for this test-consumer-only change.'])
if any(p['exit'] != 0 or p['timed_out'] for p in runs.values()) or any(p['exit'] != 0 or p['timed_out'] for p in compiles + links):
    report['status'] = 'PASS_WITH_PRESERVED_ATTEMPTS'
if (W / 'cleanup-result.json').exists():
    report['cleanup'] = read(W / 'cleanup-result.json')
save(R / 'docs/evidence/correctness/inference-glm-request-loop-2026-10-29.json', report)
print('Recorded one finite original GLM request journey and', len(preserved), 'unchanged prior output/counter facts; archive bytes', archive.stat().st_size)
