﻿$ErrorActionPreference = 'Stop'
$TaskRoot = 'C:\public\project-hyle\hyle\.scratch\inference-glm-request-loop-20261029'
$Plan = Get-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$AllowedRoot = [IO.Path]::GetFullPath($Plan.allowed_root).TrimEnd('\') + '\'
if ($AllowedRoot -ne ([IO.Path]::GetFullPath((Join-Path $TaskRoot 'bin')).TrimEnd('\') + '\')) { throw 'Unexpected cleanup root' }
foreach ($Receipt in Get-ChildItem -LiteralPath (Join-Path $TaskRoot 'runs') -Filter 'process.json' -File -Recurse) {
    $ProcessFact = Get-Content -LiteralPath $Receipt.FullName -Raw | ConvertFrom-Json
    if ($ProcessFact.state -ne 'TERMINAL') { throw "Original native process is not terminal: $($Receipt.FullName)" }
}
foreach ($Target in $Plan.targets) {
    $Resolved = [IO.Path]::GetFullPath($Target.path)
    if (-not $Resolved.StartsWith($AllowedRoot, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside intended bin directory: $Resolved" }
    if ([IO.Path]::GetDirectoryName($Resolved) -ne $AllowedRoot.TrimEnd('\')) { throw "Unexpected nested cleanup target: $Resolved" }
    $Item = Get-Item -LiteralPath $Resolved
    if ($Item.PSIsContainer -or $Item.Length -ne $Target.bytes) { throw "Changed cleanup target: $Resolved" }
    if ((Get-FileHash -LiteralPath $Resolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Target.sha256) { throw "Changed cleanup hash: $Resolved" }
}
$Removed = @()
foreach ($Target in $Plan.targets) {
    Remove-Item -LiteralPath $Target.path -Force
    $Removed += [pscustomobject]@{ path=$Target.path; bytes=$Target.bytes; removed=(-not (Test-Path -LiteralPath $Target.path)) }
}
if (@($Removed | Where-Object { -not $_.removed }).Count) { throw 'Cleanup did not finish' }
[pscustomobject]@{ status='PASS'; files=$Removed.Count; bytes=($Removed | Measure-Object bytes -Sum).Sum; removed=$Removed } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-result.json') -Encoding utf8
Write-Output "Removed $($Removed.Count) checked reconstructible binary files."
