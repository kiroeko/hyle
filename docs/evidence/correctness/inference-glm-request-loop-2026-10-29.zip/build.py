from pathlib import Path
import importlib.util
import os
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('process', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def prepare():
    base_path = R / '.scratch/inference-append-tail-return-20261029/model-link-base.json'
    base = read(base_path)
    assert len(base['retained']) == 227
    for item in base['retained']:
        exact(item)
    exact(base['runtime'])
    exact(base['sdk_engine_dependencies'])
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']:
            exact(item)
    folder = W / 'compile/glm'
    folder.mkdir(parents=True, exist_ok=True)
    source = R / 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
    old_source = Path(base['consumer_source']['path'])
    old_object = read(base['previous_consumer']['path'])['object']['path']
    compile_args = []
    for index, arg in enumerate(base['compile']):
        if index and base['compile'][index - 1].lower() == '/sourcedependencies':
            arg = str(folder / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(folder / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(folder / 'unit.pdb')
        elif key(arg) == key(old_source):
            arg = str(source)
        compile_args.append(arg)
    compile_args += [
        '/external:I' + str(R / '.scratch/validation/cpu-final-f1/mixed-iq1/source/src'),
        '/DHYLE_TEST_GLM_STATE_CPU=1', '/DHYLE_TEST_GLM_STATE_CUDA=1',
        '/I' + str(R / '.scratch/glm-gguf-selected-20261023/B09/generated')]
    link_args = []
    for arg in base['link']:
        if key(arg) == key(old_object):
            arg = str(folder / 'unit.obj')
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/glm').with_suffix(suffix))
                break
        link_args.append(arg)
    for library in ['gtest_main.lib', 'gtest.lib']:
        path = R / '.scratch/build-compute-v2-dev/lib' / library
        assert path.is_file()
        if not any(key(arg) == key(path) for arg in link_args):
            link_args.append(str(path))
    assert sum(key(arg) == key(source) for arg in compile_args) == 1
    assert sum(key(arg) == key(folder / 'unit.obj') for arg in link_args) == 1
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    glm_environment = read(R / '.scratch/inference-commit-observation-20261029/plan.json')['glm_environment']
    for name in ['HYLE_GLM_PRO_DIR', 'HYLE_GLM_PRO_MOE_DIR', 'HYLE_GLM_PRO_TARGET_DIR', 'HYLE_GLM_PRO_TARGET_MOE_DIR']:
        assert Path(glm_environment[name]).is_dir()
    save(W / 'plan.json', dict(base=pin(base_path), source=str(source), compile=compile_args,
        link=link_args, retained=base['retained'], runtime=base['runtime'],
        sdk=base['sdk_engine_dependencies'], glm_environment=glm_environment,
        case='GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNRandomVerifierContinuesAtomically'))
    print('Prepared one GLM consumer, 227 retained SDK inputs; no SDK build or downloads.')

def receipt():
    result = read(W / 'compile/glm/receipt.json')
    exact(result['object'])
    for item in result['source_identities']:
        exact(item)
    return result

def main():
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
        return
    attempt = sys.argv[2] if len(sys.argv) > 2 else 'attempt1'
    plan = read(W / 'plan.json')
    if action == 'compile':
        folder = W / 'compile/glm'
        (folder / attempt).mkdir(parents=True, exist_ok=True)
        shutil.copyfile(plan['source'], folder / attempt / 'consumer.cc')
        b.execute(plan['compile'], folder / attempt, 240)
        deps = read(folder / 'dependencies.json')['Data']
        paths = sorted({Path(p).resolve() for p in [deps['Source'], *deps['Includes']] if Path(p).is_relative_to(R)})
        result = dict(object=pin(folder / 'unit.obj'), process=pin(folder / attempt / 'process.json'),
            source_identities=[pin(p) for p in paths])
        save(folder / 'receipt.json', result)
        save(folder / attempt / 'receipt.json', result)
    elif action == 'link':
        receipt()
        for item in plan['retained']:
            exact(item)
        exact(plan['runtime'])
        exact(plan['sdk'])
        for unit in read(plan['sdk']['path'])['engine_consumers']:
            for item in unit['source_identities']:
                exact(item)
        b.execute(plan['link'], W / 'link/glm' / attempt, 180)
        image = pin(W / 'bin/glm.exe')
        save(W / 'ready-glm.json', image)
        save(W / 'link/glm' / attempt / 'image.json', image)
    elif action == 'run':
        receipt()
        image = read(W / 'ready-glm.json')
        exact(image)
        os.environ.update(plan['glm_environment'])
        folder = W / 'runs/glm-cuda' / attempt
        save(folder / 'image.json', image)
        b.execute([image['path'], '--gtest_color=no', '--gtest_filter=' + plan['case'],
                   '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 600)
        result = ET.parse(folder / 'results.xml').getroot()
        assert result.get('tests') == '1' and result.get('failures') == '0' and result.get('errors', '0') == '0'
        assert not result.findall('.//skipped')
        save(folder / 'report.json', dict(status='PASS', tests=1, failures=0, skipped=0))
        print('PASS real cached GLM target77 + NextN request journey')
    else:
        raise ValueError(action)

if __name__ == '__main__':
    main()
