from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('current_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
targets = [b.pin(p) for p in sorted((W / 'bin').iterdir()) if p.is_file()]
assert targets and all(Path(p['path']).parent == W / 'bin' for p in targets)
assert all(Path(p['path']).suffix.lower() in ['.exe', '.dll', '.pdb', '.lib', '.exp', '.map'] for p in targets)
b.save(W / 'cleanup-plan.json', dict(allowed_root=str(W / 'bin'), targets=targets,
    kept='227 exact SDK inputs, original DLL, current GLM object/receipt and other still useful consumer objects; only this batch binary copies and reconstructible linker outputs are removed.'))
script = r'''$ErrorActionPreference = 'Stop'
$TaskRoot = 'C:\public\project-hyle\hyle\.scratch\inference-glm-request-loop-20261029'
$Plan = Get-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$AllowedRoot = [IO.Path]::GetFullPath($Plan.allowed_root).TrimEnd('\') + '\'
if ($AllowedRoot -ne ([IO.Path]::GetFullPath((Join-Path $TaskRoot 'bin')).TrimEnd('\') + '\')) { throw 'Unexpected cleanup root' }
foreach ($Receipt in Get-ChildItem -LiteralPath (Join-Path $TaskRoot 'runs') -Filter 'process.json' -File -Recurse) {
    $ProcessFact = Get-Content -LiteralPath $Receipt.FullName -Raw | ConvertFrom-Json
    if ($ProcessFact.state -ne 'TERMINAL') { throw "Original native process is not terminal: $($Receipt.FullName)" }
}
foreach ($Target in $Plan.targets) {
    $Resolved = [IO.Path]::GetFullPath($Target.path)
    if (-not $Resolved.StartsWith($AllowedRoot, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside intended bin directory: $Resolved" }
    if ([IO.Path]::GetDirectoryName($Resolved) -ne $AllowedRoot.TrimEnd('\')) { throw "Unexpected nested cleanup target: $Resolved" }
    $Item = Get-Item -LiteralPath $Resolved
    if ($Item.PSIsContainer -or $Item.Length -ne $Target.bytes) { throw "Changed cleanup target: $Resolved" }
    if ((Get-FileHash -LiteralPath $Resolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Target.sha256) { throw "Changed cleanup hash: $Resolved" }
}
$Removed = @()
foreach ($Target in $Plan.targets) {
    Remove-Item -LiteralPath $Target.path -Force
    $Removed += [pscustomobject]@{ path=$Target.path; bytes=$Target.bytes; removed=(-not (Test-Path -LiteralPath $Target.path)) }
}
if (@($Removed | Where-Object { -not $_.removed }).Count) { throw 'Cleanup did not finish' }
[pscustomobject]@{ status='PASS'; files=$Removed.Count; bytes=($Removed | Measure-Object bytes -Sum).Sum; removed=$Removed } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-result.json') -Encoding utf8
Write-Output "Removed $($Removed.Count) checked reconstructible binary files."
'''
(R / 'test.ps1').write_text(script, encoding='utf-8-sig')
(W / 'cleanup.ps1').write_text(script, encoding='utf-8-sig')
print('Prepared exact cleanup targets:', len(targets), 'files,', sum(p['bytes'] for p in targets), 'bytes')
for item in targets:
    print(item['path'], item['bytes'])
