from pathlib import Path
import hashlib
import json
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[1]
specifications = {
    'vllm': ('276fbcff2717bd934cfa37c8a2e4c391f3e7237b', [
        'vllm/model_executor/models/qwen3_5.py',
        'vllm/v1/worker/gpu_model_runner.py',
        'vllm/v1/core/sched/scheduler.py',
        'vllm/model_executor/models/qwen3_5_mtp.py',
        'vllm/model_executor/models/deepseek_mtp.py']),
    'sglang': ('234ccba7f625e12639e621044496bcc6197c3758', [
        'python/sglang/srt/models/qwen3_5.py',
        'python/sglang/srt/managers/schedule_batch.py',
        'python/sglang/srt/models/qwen3_5_mtp.py',
        'python/sglang/srt/models/deepseek_nextn.py']),
    'TensorRT-LLM': ('46d9966b54d9d11998b712e732fb20f64d4d35c0', [
        'tensorrt_llm/_torch/pyexecutor/engine/runners/decoder/runner.py',
        'tensorrt_llm/_torch/pyexecutor/engine/runners/decoder/inputs.py',
        'tensorrt_llm/_torch/speculative/mtp.py'])}
result = {}
for name, (expected, files) in specifications.items():
    directory = R.parent / name
    commit = subprocess.check_output(['git', '-C', str(directory), 'rev-parse', 'HEAD'], text=True).strip()
    assert commit == expected
    modified = subprocess.check_output(['git', '-C', str(directory), 'diff', '--name-only', 'HEAD', '--', *files], text=True).splitlines()
    different = []
    pins = []
    for file in files:
        path = directory / file
        actual_hash = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
        original = subprocess.check_output(['git', '-C', str(directory), 'show', 'HEAD:' + file])
        original_hash = hashlib.sha256(original).hexdigest()
        if actual_hash != original_hash:
            different.append(file)
        pins.append(dict(file=file, bytes=path.stat().st_size, sha256=actual_hash,
            HEAD_blob_sha256=original_hash))
    result[name] = dict(local_commit=commit, selected_paths_git_diff_against_HEAD=modified,
        selected_content_different_from_HEAD=different, files=pins)
report = dict(scope='Read local source only. Selected paths checked against local HEAD; no upstream freshness, execution, performance or complete feature coverage claim.',
    repositories=result, decisions=[
        'The family describes actual layer and complete state schema; shared scheduling consumes request work, resource classes and capacity.',
        'Original execution owner retains persistent input buffers and cold preparation; actual lease permissions and completion are not cached facts.',
        'Share actual emitted prefixes, acceptance length, ordinals and member exits; retain family-specific MTP hidden/carry/normalization and restoration.'])
(W / 'references.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({name: dict(local_commit=item['local_commit'], git_diff_paths=item['selected_paths_git_diff_against_HEAD'], content_differences=item['selected_content_different_from_HEAD']) for name, item in result.items()}))
