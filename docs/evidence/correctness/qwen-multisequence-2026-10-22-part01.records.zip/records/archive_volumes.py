"""Keep the same evidence bytes in ordinary ZIP volumes below 100 MiB."""
from pathlib import Path
import hashlib,json,zipfile
Q=Path(__file__).resolve().parent;R=Q.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p=Path(p).resolve()
    with p.open('rb')as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=str(p),bytes=p.stat().st_size,sha256=digest)
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
published_path=Q/'published.json';published=read(published_path)
manifest_path=Path(published['manifest']['path']);report=read(manifest_path)
old=published['archive'];assert identity(old['path'])==old
backup=Q/'archive-volumes';backup.mkdir(exist_ok=False)
save(backup/'manifest-before.json',report);save(backup/'published-before.json',published)
volumes=[]
with zipfile.ZipFile(old['path'])as source:
    groups=[[]];size=0
    for entry in source.infolist():
        if groups[-1]and size+entry.compress_size>90*1024**2:groups.append([]);size=0
        groups[-1].append(entry);size+=entry.compress_size
    names=[manifest_path.with_name(manifest_path.stem+f'.part{i+1:02}.zip')for i in range(len(groups))]
    for i,(path,group)in enumerate(zip(names,groups)):
        with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as output:
            for entry in group:output.writestr(entry.filename,source.read(entry))
            output.writestr('volume-index.json',json.dumps(dict(part=i+1,parts=[p.name for p in names],source_archive=old,
                entries=[e.filename for e in group],reproduction='Extract all ordinary ZIP parts into the same directory. Payload paths are disjoint; volume-index.json is descriptive only.'),indent=2))
            if i==0:
                output.writestr('publication-before-volumes.json',json.dumps(report,indent=2))
                output.writestr('archive_volumes.py',Path(__file__).read_bytes())
        assert path.stat().st_size<100*1024**2
        with zipfile.ZipFile(path)as check:assert check.testzip()is None
        volumes.append(identity(path))
report['archive']=volumes[0];report['archives']=volumes
report['archive_layout']='Extract every part ZIP into the same directory. Original evidence entries and all raw bytes are retained; only physical archive layout changed.'
report['superseded_single_archive']=old
save(manifest_path,report)
published.update(manifest=identity(manifest_path),archive=volumes[0],archives=volumes,superseded_single_archive=old)
save(published_path,published)
plan=read(Q/'cleanup-plan.json');plan['publication']=published
plan['targets'].append(dict(**old,kind='superseded-evidence-archive'))
plan['allowed_superseded_archive']=old
plan['target_count']=len(plan['targets']);plan['total_bytes']=sum(x['bytes']for x in plan['targets']);plan['total_GiB']=plan['total_bytes']/1024**3
plan['counts']['zip']=1
save(Q/'cleanup-plan-final.json',plan)
save(backup/'layout.json',dict(published=published,cleanup_plan=identity(Q/'cleanup-plan-final.json'),original_bytes_retained=True))
print(json.dumps(dict(manifest=published['manifest'],archives=volumes,cleanup_bytes=plan['total_bytes']),indent=2))
