"""Explicit 6 CXX + 1 NVCC, one 231-input GTest link, one bounded run."""
from pathlib import Path
import fnmatch
import importlib.util
import json
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
BASE = R / '.scratch/inference-mixed-lag-20261029'
PACKED = R / '.scratch/inference-packed-sequence-20261028'
SOURCES = {
    'native-provider': 'src/compute_provider_native/native_provider.cc',
    'cuda-provider': 'src/compute_provider_cuda/cuda_provider.cc',
    'native-sequence': 'src/compute_provider_native/sequence.cc',
    'cuda-sequence': 'src/compute_provider_cuda/sequence_provider.cc',
    'sequence-kernel': 'src/compute_provider_cuda/sequence_kernel.cu',
    'cpu-test': 'tests/compute_route_cpu/sequence_test.cc',
    'cuda-test': 'tests/compute_route_cuda/sequence_test.cc',
}
EXPLICIT = tuple(SOURCES.values()) + (
    'include/hyle/compute/sequence_ops.h',
    'src/compute_provider_cuda/sequence_kernel.h',
    'tests/compute_models/packed_gdn_prefix_case.h')
OLD = {
    'native-provider': R / '.scratch/inference-cpu-routing-20261028/validation/compile/native/unit.obj',
    'cuda-provider': R / '.scratch/inference-optional-aten-20261028/validation/compile/cuda-provider/unit.obj',
    **{n: PACKED / 'compile' / n / 'unit.obj' for n in ('native-sequence','cuda-sequence','sequence-kernel')},
}
FILTER = ('ComputeSequenceSchema.*:'
          'CpuPackedSequence.Gdn*:CpuPackedSequence.Empty*:CpuPackedSequence.WholeOffset*:CpuPackedSequence.Prefix*:'
          'CudaPackedSequence.Gdn*:CudaPackedSequence.Empty*:CudaPackedSequence.WholeOffset*:CudaPackedSequence.Prefix*')
spec = importlib.util.spec_from_file_location('prefix_recorder', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W


def successful(path):
    process = t.read(path)
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out'], process
    return process


def adapted(name, old):
    out = W / 'compile' / name
    nvcc = name == 'sequence-kernel'
    args = [old[0], ('-I' if nvcc else '/I') + str(R / 'include'), ('-I' if nvcc else '/I') + str(R)]
    sources = 0
    for i, arg in enumerate(old[1:], 1):
        previous = old[i - 1]
        if nvcc:
            if previous in ('-o', '-MT'): arg = str(out / 'unit.obj')
            elif previous == '-MF': arg = str(out / 'dependencies.d')
            elif arg.startswith('-Xcompiler=/Fd'): arg = '-Xcompiler=/Fd' + str(out / 'unit.pdb') + ',/FS'
        else:
            if previous.casefold() == '/sourcedependencies': arg = str(out / 'dependencies.json')
            elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
            elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
        if arg.casefold().endswith(('.cc','.cpp','.cxx','.cu')):
            assert t.key(arg) == t.key(R / SOURCES[name]), (name, arg)
            arg = str(R / SOURCES[name]); sources += 1
        args.append(arg)
    assert sources == 1
    if nvcc:
        assert '-MF' in args and '-MD' in args and '-o' in args and '-MT' in args
        assert any('compute_89' in a and 'sm_89' in a for a in args)
    else: assert '/sourceDependencies' in args and '/WX' in args
    return args


def prepare():
    prior = t.read(BASE / 'plan.json'); assert len(prior['retained']) == 227
    retained = {t.key(row['path']): row for row in prior['retained']}; assert len(retained) == 227
    for row in retained.values(): t.exact(row)
    units = {}
    for name, source in SOURCES.items():
        obj = OLD.get(name, PACKED / 'compile' / name / 'unit.obj')
        receipt_path = obj.parent / 'compiled.json'; receipt = t.read(receipt_path)
        assert t.key(t.canonical(receipt['source']['path'])) == t.key(R / source)
        if name in OLD:
            assert t.key(obj) in retained and prior['link'].count(str(obj)) == 1
            assert receipt['object'] == retained[t.key(obj)]
        recipe = obj.parent / 'command.json'
        if not recipe.is_file():
            recipe = Path(receipt['command']['path']) if name in ('native-provider','cuda-provider') else PACKED / 'recipes' / (name + '.json')
        t.exact(receipt['dependencies'])
        old = t.command(recipe); args = adapted(name, old)
        target = W / 'recipes' / (name + '.json')
        recipe_value = dict(command=args, cwd=str(R), timeout_seconds=300)
        if target.exists(): assert t.read(target) == recipe_value, 'Existing recipe differs'
        else: t.save(target, recipe_value)
        units[name] = dict(source=str(R / source), kind='NVCC' if name == 'sequence-kernel' else 'CXX',
            old_object=retained.get(t.key(obj)), prior_compiled=t.pin(receipt_path),
            original_recipe=t.pin(recipe), dependencies=receipt['dependencies'], recipe=t.pin(target))
    old_keys = {t.key(p) for p in OLD.values()}
    remaining = [row for row in prior['retained'] if t.key(row['path']) not in old_keys]
    assert len(remaining) == 222
    input_args = [a for a in prior['link'] if a.casefold().endswith(('.obj','.lib')) and Path(a).is_absolute() and not a.startswith('/')]
    tiny = [a for a in input_args if t.key(a) not in retained]
    assert len(input_args) == 228 and len(tiny) == 1 and tiny[0].casefold().endswith('unit.obj')
    gtests = [t.pin(R / '.scratch/build-compute-v2-dev/lib' / name) for name in ('gtest_main.lib','gtest.lib')]
    replacements = {t.key(path): str(W / 'compile' / name / 'unit.obj') for name,path in OLD.items()}
    args = []
    for arg in prior['link']:
        if t.key(arg) == t.key(tiny[0]):
            args += [str(W / 'compile' / name / 'unit.obj') for name in ('cpu-test','cuda-test')]
            continue
        arg = replacements.get(t.key(arg), arg)
        for prefix, suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/packed-gdn-prefixes').with_suffix(suffix)); break
        args.append(arg)
    args += [row['path'] for row in gtests]
    paths = [a for a in args if a.casefold().endswith(('.obj','.lib')) and Path(a).is_absolute() and not a.startswith('/')]
    assert len(paths) == len(set(map(t.key,paths))) == 231
    t.save(W / 'recipe-link.json', dict(command=args,cwd=str(R),timeout_seconds=300))
    env = t.read(BASE / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json',env)
    t.save(W / 'plan.json',dict(base=t.pin(BASE / 'plan.json'),units=units,retained=remaining,gtests=gtests,
        runtime=prior['runtime'],link_recipe=t.pin(W / 'recipe-link.json'),removed_consumer=tiny[0],filter=FILTER,
        counts=dict(CXX=6,NVCC=1,links=1,inputs=231,retained_inputs=222,replaced_SDK=5,native_processes=1,
                    models=0,downloads=0,actual_builds=0,actual_runs=0)))
    print('PREPARED 6CXX+1NVCC / 231 inputs / one GTest; no compilation or run')


def freeze():
    plan = t.read(W / 'plan.json'); paths = {R / rel for rel in EXPLICIT}
    for unit in plan['units'].values():
        t.exact(unit['recipe']); t.exact(unit['original_recipe']); t.exact(unit['dependencies'])
        paths.update(t.canonical(p) for p in t.dep_paths(unit['dependencies']['path']) if t.project(t.canonical(p)))
    todo = list(paths)
    while todo:
        path = todo.pop()
        for inc in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',path.read_text(encoding='utf-8-sig'),re.M):
            found = next((q.resolve() for root in (path.parent,R/'include',R) if (q:=root/inc).is_file()),None)
            if found is not None and t.project(found) and found not in paths: paths.add(found); todo.append(found)
    rows = [t.pin(p) for p in sorted(paths)]
    snapshots = []
    for rel in EXPLICIT:
        source = R / rel; target = W / 'source' / rel; target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as out: out.write(source.read_bytes())
        snapshots.append(dict(original=t.pin(source),snapshot=t.pin(target)))
    expected = []
    for name in ('cpu-test','cuda-test'):
        body = (R / SOURCES[name]).read_text()
        for suite, case in re.findall(r'\bTEST\(\s*(\w+)\s*,\s*(\w+)\s*\)',body):
            full = suite + '.' + case
            if any(fnmatch.fnmatchcase(full,p) for p in FILTER.split(':')): expected.append(full)
    assert len(expected) == len(set(expected)) and sum('.Prefix' in n for n in expected) == 5
    assert not any('Conv' in n or 'Append' in n for n in expected)
    t.save(W / 'run-plan.json',dict(filter=FILTER,expected=expected,native_processes=1,allow_skips=False))
    t.save(W / 'source-freeze.json',dict(sources=rows,snapshots=snapshots,helper=t.pin(__file__),
        run_plan=t.pin(W / 'run-plan.json'),scope='Current canonical files; prior dependencies supply inventory, not prior header identity.'))
    print('SOURCE FROZEN',len(rows),'project files;',len(expected),'expected GTests; no native execution')


def validate():
    freeze = t.read(W / 'source-freeze.json')
    for row in freeze['sources']: t.exact(row)
    t.exact(freeze['helper']); t.exact(freeze['run_plan'])
    return t.read(W / 'plan.json')


def parse_compile(name):
    plan = validate(); unit = plan['units'][name]; out = W / 'compile' / name
    process = successful(W / 'logs' / ('compile-' + name) / 'process.json')
    dep = out / ('dependencies.d' if unit['kind']=='NVCC' else 'dependencies.json')
    paths = t.dep_paths(dep); project = {t.key(p):p for p in paths if t.project(p)}
    assert t.key(R / SOURCES[name]) in project
    header = R / 'include/hyle/compute/sequence_ops.h'
    if name != 'sequence-kernel':
        assert any(Path(p).resolve() == header for p in paths), 'canonical public sequence header must be selected'
    frozen = {t.key(row['path']):row for row in t.read(W/'source-freeze.json')['sources']}
    actual = [t.pin(p) for p in project.values()]
    for row in actual:
        assert t.key(row['path']) in frozen, 'new project dependency: '+row['path']
        assert row == frozen[t.key(row['path'])]
    t.save(out/'actual-dependencies.json',actual)
    t.save(out/'compiled.json',dict(source=t.pin(R/SOURCES[name]),object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/'logs'/('compile-'+name)/'command.json'),dependencies=t.pin(dep),
        actual_dependencies=t.pin(out/'actual-dependencies.json')))
    print('COMPILE METADATA PASS',name,process['pid'])


def compile_one(name):
    plan = validate(); unit = plan['units'][name]; t.exact(unit['recipe'])
    (W/'compile'/name).mkdir(parents=True,exist_ok=False)
    t.execute(t.command(unit['recipe']['path']),W/'logs'/('compile-'+name),300)
    parse_compile(name)


def link():
    plan = validate(); inputs = plan['retained'] + plan['gtests']
    for name in SOURCES:
        compiled = t.read(W/'compile'/name/'compiled.json')
        assert compiled['process']==successful(W/'logs'/('compile-'+name)/'process.json')
        inputs.append(compiled['object'])
    assert len(inputs)==231
    for row in inputs: t.exact(row)
    t.exact(plan['runtime']); t.exact(plan['link_recipe'])
    command = t.command(plan['link_recipe']['path'])
    by_path = {t.key(row['path']):row for row in inputs}
    ordered = [a for a in command if a.casefold().endswith(('.obj','.lib')) and Path(a).is_absolute() and not a.startswith('/')]
    assert len(by_path)==len(ordered)==231 and set(map(t.key,ordered))==set(by_path)
    inputs = [by_path[t.key(path)] for path in ordered]
    (W/'bin').mkdir(exist_ok=False)
    alias = W/'bin'/Path(plan['runtime']['path']).name; alias.hardlink_to(plan['runtime']['path'])
    assert alias.samefile(plan['runtime']['path'])
    process = t.execute(command,W/'logs/link',300)
    t.save(W/'inputs.json',inputs)
    t.save(W/'ready.json',dict(image=t.pin(W/'bin/packed-gdn-prefixes.exe'),inputs=t.pin(W/'inputs.json'),
        recipe=plan['link_recipe'],process=process,runtime=plan['runtime'],source_freeze=t.pin(W/'source-freeze.json')))
    print('LINK PASS',process['pid'],'231 inputs')


def parse():
    validate(); process = successful(W/'runs/gtest/process.json'); run_plan = t.read(W/'run-plan.json')
    root = ET.parse(W/'runs/gtest/result.xml').getroot(); cases = root.findall('.//testcase')
    actual = [row.attrib['classname']+'.'+row.attrib['name'] for row in cases]
    assert len(actual)==len(set(actual)) and sorted(actual)==sorted(run_plan['expected']), actual
    failures = [n for n in cases if n.find('failure') is not None or n.find('skipped') is not None or n.get('status')=='notrun']
    assert not failures and all(n.get('result')=='completed' for n in cases)
    t.save(W/'runs/gtest/summary.json',dict(status='PASS',process=process,tests=len(cases),passed=len(cases),
        skipped=0,failures=0,cases=[dict(name=n,time=float(row.get('time','0'))) for n,row in zip(actual,cases)],
        scope='CPU/CUDA native packed prefix and unchanged last-K finite contracts; no model/performance claim.'))
    print('GTEST PASS',len(cases),process['pid'])


def run():
    validate(); ready=t.read(W/'ready.json'); t.exact(ready['image']); t.exact(ready['inputs']); t.exact(ready['runtime'])
    run_plan=t.read(W/'run-plan.json')
    t.execute([ready['image']['path'],'--gtest_filter='+run_plan['filter'],
        '--gtest_output=xml:'+str(W/'runs/gtest/result.xml')],W/'runs/gtest',300)
    parse()


if __name__ == '__main__':
    action=sys.argv[1]
    if action=='prepare': prepare()
    elif action=='freeze': freeze()
    elif action=='compileOne': compile_one(sys.argv[2])
    elif action=='parse-compile': parse_compile(sys.argv[2])
    elif action=='link': link()
    elif action=='run': run()
    elif action=='parse': parse()
    else: raise SystemExit('prepare | freeze | compileOne UNIT | parse-compile UNIT | link | run | parse')
