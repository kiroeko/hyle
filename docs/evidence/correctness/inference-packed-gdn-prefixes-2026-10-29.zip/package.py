"""Offline evidence only; invoke after the two real executions are complete."""
from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
REF=W/'refinement'
DEST=R/'docs/evidence/correctness/inference-packed-gdn-prefixes-2026-10-29'
BASE_COMMIT='09bf7dc6a68c831b569eb8b6e0ee10d93a39694d'
PRODUCTS=('include/hyle/compute/sequence_ops.h','src/compute_provider_native/sequence.cc',
    'src/compute_provider_native/native_provider.cc','src/compute_provider_cuda/sequence_provider.cc',
    'src/compute_provider_cuda/cuda_provider.cc','src/compute_provider_cuda/sequence_kernel.h',
    'src/compute_provider_cuda/sequence_kernel.cu')
TESTS=('tests/compute_route_cpu/sequence_test.cc','tests/compute_route_cuda/sequence_test.cc',
    'tests/compute_models/packed_gdn_prefix_case.h')
UNITS=('native-provider','cuda-provider','native-sequence','cuda-sequence','sequence-kernel','cpu-test','cuda-test')


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(data):return hashlib.sha256(data).hexdigest()
def pin(path):
    p=Path(path).resolve();data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=digest(data))
def exact(row):assert pin(row['path'])==row,row['path']
def save(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as out:out.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def terminal(path,exit=0):
    value=read(path);assert value['state']=='TERMINAL' and value['exit']==exit and not value['timed_out'],value
    return value

def cases(path):
    rows=[]
    for node in ET.parse(path).getroot().findall('.//testcase'):
        rows.append(dict(name=node.attrib['classname']+'.'+node.attrib['name'],
            passed=node.find('failure') is None and node.find('skipped') is None
                and node.get('status')=='run' and node.get('result')=='completed',
            assertions_failed=len(node.findall('failure')),seconds=float(node.get('time','0'))))
    assert len(rows)==len({row['name'] for row in rows})
    return rows


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    original=read(W/'source-freeze.json');final=read(REF/'source-freeze.json')
    assert len(original['sources'])==len(final['sources'])==116
    final_pins={row['path']:row for row in final['sources']}
    source_pins=[pin(R/rel) for rel in PRODUCTS+TESTS]
    assert len(source_pins)==10
    for row in source_pins:assert row==final_pins[row['path']]
    shared=str(R/TESTS[-1]);old_shared=next(row for row in original['snapshots'] if row['original']['path']==shared)
    exact(old_shared['snapshot']);before=Path(old_shared['snapshot']['path']).read_bytes()
    needle=b'packed_gated_delta_net_prefixes(3),fixture.descriptions,fixture.data()'
    replacement=b'packed_gated_delta_net_prefixes(3,fixture.scale),fixture.descriptions,fixture.data()'
    assert before.count(needle)==1 and (R/TESTS[-1]).read_bytes()==before.replace(needle,replacement,1)
    old={row['path']:row for row in original['sources']}
    assert [path for path,row in final_pins.items() if row!=old[path]]==[shared]
    first_process=terminal(W/'runs/gtest/process.json',1);second_process=terminal(REF/'runs/gtest/process.json')
    first=cases(W/'runs/gtest/result.xml');second=cases(REF/'runs/gtest/result.xml')
    assert len(first)==15 and sum(row['passed'] for row in first)==13
    failed=[row['name'] for row in first if not row['passed']]
    assert sorted(failed)==sorted(row['name'] for row in second) and len(second)==2 and all(row['passed'] for row in second)
    merged=[dict(row,execution='original') for row in first if row['passed']]+[dict(row,execution='fixture-scale-refinement') for row in second]
    assert len({row['name'] for row in merged})==15
    summary=read(REF/'runs/gtest/summary.json')
    assert summary['status']=='PASS' and summary['combined_unique_tests']==summary['combined_passed']==15
    assert summary['previous_successful_tests_not_rerun']==13
    files={};compiles=[];links=[]
    def add(path,name):
        path=Path(path);assert path.is_file(),path
        assert name not in files,name
        files[name]=path.read_bytes()
    def endpoint(base,relative,label,expected_exit=0):
        folder=base/relative;value=terminal(folder/'process.json',expected_exit)
        for name in ('command.json','process.json','running.json','stdout.log','stderr.log'):
            add(folder/name,label+'/'+relative+'/'+name)
        return value
    for base,label,units in ((W,'initial',UNITS),(REF,'refinement',('cpu-test','cuda-test'))):
        for name in ('build.py','plan.json','source-freeze.json','run-plan.json','ready.json','inputs.json','recipe-link.json'):
            add(base/name,label+'/'+name)
        plan=read(base/'plan.json');ready=read(base/'ready.json')
        exact(ready['inputs']);exact(ready['source_freeze']);exact(ready['recipe'])
        assert len(read(ready['inputs']['path']))==231
        for name in units:
            receipt=read(base/'compile'/name/'compiled.json')
            proc=endpoint(base,'logs/compile-'+name,label);assert receipt['process']==proc
            assert receipt['source']==next(row for row in source_pins if row['path']==receipt['source']['path'])
            for field in ('command','dependencies','actual_dependencies'):exact(receipt[field])
            dep='dependencies.d' if name=='sequence-kernel' else 'dependencies.json'
            for item in ('compiled.json','actual-dependencies.json',dep):add(base/'compile'/name/item,label+'/compile/'+name+'/'+item)
            add(base/'recipes'/(name+'.json'),label+'/recipes/'+name+'.json')
            compiles.append(dict(unit=name,attempt=label,kind='NVCC' if name=='sequence-kernel' else 'CXX',process=proc,
                source=receipt['source'],object_identity=receipt['object']))
        link=endpoint(base,'logs/link',label);assert ready['process']==link
        links.append(dict(attempt=label,process=link,image_identity=ready['image'],inputs=ready['inputs']))
        endpoint(base,'runs/gtest',label,1 if base==W else 0)
        add(base/'runs/gtest/result.xml',label+'/runs/gtest/result.xml')
    assert sum(row['kind']=='CXX' for row in compiles)==8 and sum(row['kind']=='NVCC' for row in compiles)==1
    add(REF/'runs/gtest/summary.json','refinement/runs/gtest/summary.json')
    add(W/'prepare-offline-failure.json','initial/prepare-offline-failure.json')
    for rel in PRODUCTS+TESTS:add(R/rel,'source/final/'+rel)
    add(old_shared['snapshot']['path'],'source/initial-fixture/'+TESTS[-1])
    add(__file__,'package.py')
    result=dict(schema='hyle.inference.packed-gdn-prefixes.evidence.v1',status='PASS_FINITE_CPU_CUDA_PRIMITIVE',
        source_base_commit=BASE_COMMIT,sources=source_pins,
        contract=dict(operation='PackedGatedDeltaNetPrefixes',inputs=7,outputs=2,
            states='[B,K,Hv,Dv,Dk], including K=1; valid slots S1..SLi, all remaining bits zero',
            validity='offsets alone; 0<=Li<=K; all metadata checked before either output write',
            empty_members='no valid prefix; zero state slots; initial state remains at its input',
            old_packed_gdn='separate unchanged last-K contract and operation identity'),
        counts=dict(SDK_CXX=4,SDK_NVCC=1,test_CXX=4,total_CXX=8,total_NVCC=1,links=2,native_processes=2,
            native_test_attempts=17,unique_tests_passed=15,initial_passed=13,initial_failed=2,
            refinement_passed=2,previous_successes_rerun=0,downloads=0),
        executions=dict(compiles=compiles,links=links,initial=dict(process=first_process,cases=first),
            refinement=dict(process=second_process,cases=second),combined=merged),
        failure=dict(kind='test-fixture scale argument omitted',
            explanation='Fixture reference used scale=1, while the operation defaulted to 1/sqrt(3); only the factory call gained fixture.scale.',
            original_shared_header=old_shared['original'],original_execution_preserved=True,product_recompiled_for_fix=False),
        preparation_failure=read(W/'prepare-offline-failure.json'),
        implementation_facts=dict(additional_recurrence_state_workspace=False,existing_structure_layouts_changed=False,
            note='These are source-level facts; prefix output storage and execution costs are not zero and were not benchmarked.'),
        coverage=['CPU/CUDA F32/F16/BF16 finite prefix recurrence against FP64 reference',
            'whole-offset and capacity rejection before output writes, empty members and positive-zero unused slots',
            'continued recurrence from a selected real device prefix state',
            'CUDA capture reuse, invalid last member retirement, and unchanged last-K regression'],
        limits=['Qwen fixed-width Verify integration, MTP device acceptance and successor wiring are not covered.',
            'No Apple/Vulkan validation, model quality or speed claim.'])
    files['summary.json']=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
    rows=[dict(name=name,bytes=len(data),sha256=digest(data)) for name,data in sorted(files.items())]
    manifest=(json.dumps(dict(members=rows),indent=2)+'\n').encode();files['manifest.json']=manifest
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(files.items()):archive.writestr(name,data)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None and sorted(archive.namelist())==sorted(files)
        for name,data in files.items():
            got=archive.read(name);assert len(got)==len(data) and digest(got)==digest(data),name
    result['archive']=dict(**pin(DEST.with_suffix('.zip')),members=len(files),manifest_sha256=digest(manifest),
        crc_readback=True,every_member_sha256_readback=True)
    save(DEST.with_suffix('.json'),result)
    print(json.dumps(dict(json=pin(DEST.with_suffix('.json')),zip=result['archive']),indent=2))


if __name__=='__main__':main()
