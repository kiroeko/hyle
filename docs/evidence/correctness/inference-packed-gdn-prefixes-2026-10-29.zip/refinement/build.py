"""Test-scale refinement: two test TUs/link, rerun only the two failed cases."""
from pathlib import Path
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
BASE=W.parent
R=BASE.parents[1]
spec=importlib.util.spec_from_file_location('prefix_parent',BASE/'build.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.W=W;m.t.W=W
t=m.t
NAMES=('cpu-test','cuda-test')
SHARED=R/'tests/compute_models/packed_gdn_prefix_case.h'


def xml_cases(path):
    rows=[]
    for row in ET.parse(path).getroot().findall('.//testcase'):
        rows.append(dict(name=row.attrib['classname']+'.'+row.attrib['name'],
            passed=row.find('failure') is None and row.find('skipped') is None
                and row.get('status')=='run' and row.get('result')=='completed',
            time=float(row.get('time','0'))))
    assert len(rows)==len({row['name'] for row in rows})
    return rows


def current_sources():
    original=t.read(BASE/'source-freeze.json'); assert len(original['sources'])==116
    rows=[];changed=[]
    for old in original['sources']:
        row=t.pin(old['path']);rows.append(row)
        if row!=old: changed.append(row['path'])
    assert changed==[str(SHARED)],changed
    old=next(row for row in original['snapshots'] if t.key(row['original']['path'])==t.key(SHARED))
    t.exact(old['snapshot']); before=Path(old['snapshot']['path']).read_bytes()
    needle=b'packed_gated_delta_net_prefixes(3),fixture.descriptions,fixture.data()'
    replacement=b'packed_gated_delta_net_prefixes(3,fixture.scale),fixture.descriptions,fixture.data()'
    assert before.count(needle)==1
    assert SHARED.read_bytes()==before.replace(needle,replacement,1),'Only the fixture scale argument may differ'
    return rows


def prepare():
    ready=t.read(BASE/'ready.json');t.exact(ready['inputs']);t.exact(ready['recipe']);t.exact(ready['source_freeze'])
    inputs=t.read(ready['inputs']['path']);assert len(inputs)==231
    previous_process=t.read(BASE/'runs/gtest/process.json')
    assert previous_process['state']=='TERMINAL' and previous_process['exit']==1 and not previous_process['timed_out']
    cases=xml_cases(BASE/'runs/gtest/result.xml');expected=t.read(BASE/'run-plan.json')['expected']
    assert len(cases)==15 and sorted(row['name'] for row in cases)==sorted(expected)
    failed=[row['name'] for row in cases if not row['passed']]
    assert sorted(failed)==[suite+'.PrefixCapacityEmptyMembersAndFailureRemainAtomic' for suite in ('CpuPackedSequence','CudaPackedSequence')]
    assert sum(row['passed'] for row in cases)==13
    rows=current_sources();units={};replacements={}
    parent_plan=t.read(BASE/'plan.json')
    for name in NAMES:
        compiled=t.read(BASE/'compile'/name/'compiled.json');old=compiled['object'];t.exact(old)
        assert sum(t.key(row['path'])==t.key(old['path']) for row in inputs)==1
        recipe=parent_plan['units'][name]['recipe'];t.exact(recipe);old_args=t.command(recipe['path']);args=[]
        for i,arg in enumerate(old_args):
            if i and old_args[i-1].casefold()=='/sourcedependencies':arg=str(W/'compile'/name/'dependencies.json')
            elif arg.casefold().startswith('/fo'):arg='/Fo'+str(W/'compile'/name/'unit.obj')
            elif arg.casefold().startswith('/fd'):arg='/Fd'+str(W/'compile'/name/'unit.pdb')
            args.append(arg)
        target=W/'recipes'/(name+'.json');t.save(target,dict(command=args,cwd=str(R),timeout_seconds=300))
        units[name]=dict(source=str(R/m.SOURCES[name]),kind='CXX',old_object=old,recipe=t.pin(target),
            original_recipe=recipe,dependencies=compiled['dependencies'],prior_compiled=t.pin(BASE/'compile'/name/'compiled.json'))
        replacements[t.key(old['path'])]=str(W/'compile'/name/'unit.obj')
    retained=[row for row in inputs if t.key(row['path']) not in replacements];assert len(retained)==229
    for row in retained:t.exact(row)
    args=[]
    for arg in t.command(ready['recipe']['path']):
        arg=replacements.get(t.key(arg),arg)
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/packed-gdn-prefixes').with_suffix(suffix));break
        args.append(arg)
    physical=[a for a in args if Path(a).is_absolute() and not a.startswith('/') and a.casefold().endswith(('.obj','.lib'))]
    assert len(physical)==len(set(map(t.key,physical)))==231
    t.save(W/'recipe-link.json',dict(command=args,cwd=str(R),timeout_seconds=300))
    env=t.read(BASE/'environment.json');env['PATH']=str(W/'bin')+';'+env['PATH'];t.save(W/'environment.json',env)
    t.save(W/'plan.json',dict(base=t.pin(BASE/'ready.json'),units=units,retained=retained,runtime=ready['runtime'],
        link_recipe=t.pin(W/'recipe-link.json'),previous=dict(xml=t.pin(BASE/'runs/gtest/result.xml'),
            process=t.pin(BASE/'runs/gtest/process.json'),source_freeze=ready['source_freeze'],run_plan=t.pin(BASE/'run-plan.json')),
        counts=dict(CXX=2,NVCC=0,links=1,inputs=231,retained_inputs=229,native_processes=1,tests_to_rerun=2,
                    previous_passed_not_rerun=13,SDK_CXX=0,downloads=0),
        amendment='Test fixture passes its existing scale=1 to the operation; products and the original numerical oracle are unchanged.'))
    t.save(W/'run-plan.json',dict(filter=':'.join(failed),expected=failed,all_expected=expected,native_processes=1,allow_skips=False))
    print('PREPARED test-only refinement; 2CXX/1link/2 previously failed GTests; no native execution')


def freeze():
    rows=current_sources();plan=t.read(W/'plan.json')
    for unit in plan['units'].values():t.exact(unit['recipe'])
    snapshots=[]
    for path in (SHARED,*(R/m.SOURCES[n] for n in NAMES)):
        target=W/'source'/path.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as out:out.write(path.read_bytes())
        snapshots.append(dict(original=t.pin(path),snapshot=t.pin(target)))
    t.save(W/'source-freeze.json',dict(sources=rows,snapshots=snapshots,helper=t.pin(BASE/'build.py'),
        refinement_helper=t.pin(__file__),run_plan=t.pin(W/'run-plan.json'),
        scope='Current canonical 116-file inventory; only the shared fixture scale argument changed from the original candidate.'))
    print('SOURCE FROZEN 116 current files; unchanged product/legacy oracle; no native execution')


def validate():
    plan=m.validate();t.exact(t.read(W/'source-freeze.json')['refinement_helper'])
    for row in plan['previous'].values():t.exact(row)
    return plan


def link():
    plan=validate();inputs=list(plan['retained'])
    for name in NAMES:
        compiled=t.read(W/'compile'/name/'compiled.json')
        assert compiled['process']==m.successful(W/'logs'/('compile-'+name)/'process.json')
        inputs.append(compiled['object'])
    for row in inputs:t.exact(row)
    t.exact(plan['link_recipe']);t.exact(plan['runtime']);args=t.command(plan['link_recipe']['path'])
    physical=[a for a in args if Path(a).is_absolute() and not a.startswith('/') and a.casefold().endswith(('.obj','.lib'))]
    pins={t.key(row['path']):row for row in inputs};assert len(pins)==len(physical)==231 and set(map(t.key,physical))==set(pins)
    (W/'bin').mkdir(exist_ok=False);alias=W/'bin'/Path(plan['runtime']['path']).name
    alias.hardlink_to(plan['runtime']['path']);assert alias.samefile(plan['runtime']['path'])
    process=t.execute(args,W/'logs/link',300);t.save(W/'inputs.json',[pins[t.key(path)] for path in physical])
    t.save(W/'ready.json',dict(image=t.pin(W/'bin/packed-gdn-prefixes.exe'),inputs=t.pin(W/'inputs.json'),
        recipe=plan['link_recipe'],process=process,runtime=plan['runtime'],source_freeze=t.pin(W/'source-freeze.json')))
    print('LINK PASS',process['pid'])


def parse():
    plan=validate();process=m.successful(W/'runs/gtest/process.json');run_plan=t.read(W/'run-plan.json')
    fresh=xml_cases(W/'runs/gtest/result.xml');assert sorted(row['name'] for row in fresh)==sorted(run_plan['expected'])
    assert len(fresh)==2 and all(row['passed'] for row in fresh)
    prior=xml_cases(plan['previous']['xml']['path']);passed=[row for row in prior if row['passed']]
    assert len(prior)==15 and len(passed)==13
    merged=[dict(row,source='original-first-run') for row in passed]+[dict(row,source='test-scale-refinement') for row in fresh]
    assert len({row['name'] for row in merged})==15 and sorted(row['name'] for row in merged)==sorted(run_plan['all_expected'])
    t.save(W/'runs/gtest/summary.json',dict(status='PASS',process=process,tests=2,passed=2,skipped=0,failures=0,
        combined_unique_tests=15,combined_passed=15,original_process=t.read(plan['previous']['process']['path']),
        original_results=dict(passed=13,failed=2),previous_successful_tests_not_rerun=13,cases=merged,
        scope='Two fixture-scale failures corrected; original failed execution is preserved, not relabeled.'))
    print('PASS 2 refinement tests + 13 unchanged original successes; 15 unique cases')


def run():
    validate();ready=t.read(W/'ready.json')
    for field in ('image','inputs','runtime'):t.exact(ready[field])
    run_plan=t.read(W/'run-plan.json')
    t.execute([ready['image']['path'],'--gtest_filter='+run_plan['filter'],
        '--gtest_output=xml:'+str(W/'runs/gtest/result.xml')],W/'runs/gtest',300)
    parse()


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze()
    elif action=='compileOne':
        assert sys.argv[2] in NAMES;m.compile_one(sys.argv[2])
    elif action=='parse-compile':
        assert sys.argv[2] in NAMES;m.parse_compile(sys.argv[2])
    elif action=='link':link()
    elif action=='run':run()
    elif action=='parse':parse()
    else:raise SystemExit('prepare | freeze | compileOne cpu-test|cuda-test | parse-compile UNIT | link | run | parse')
