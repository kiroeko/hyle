"""Bounded source/log evidence and exact-file cleanup; no native work."""
from pathlib import Path
import argparse,difflib,hashlib,json,zipfile

S=Path(__file__).resolve().parent
R=S.parents[1]
E=R/'docs/evidence/correctness'
NAME='qwen-vulkan-assembly-2026-10-22'

def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def read(p):return json.loads(p.read_bytes())
def ident(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def prepare():
    assert read(S/'live.json')['state']=='terminal'
    paths=[]
    for root in ['cpu-link1','test-link2','test-link3','qwen-link2','qwen-link3','diagnostic-link1']:
        for p in (S/root).iterdir():
            if p.suffix in ['.map','.lib','.exp'] or(p.suffix=='.exe'and root not in ['test-link3','qwen-link3']):paths.append(p)
    records=[ident(p)for p in paths]
    for p in paths:assert p.resolve().is_relative_to(S.resolve())and p.is_file()
    rows=['  @{ Path = '+"'"+str(R/x['path'])+"'; Bytes = "+str(x['bytes'])+"; SHA256 = '"+x['sha256']+"' }"for x in records]
    text='''# AM: only superseded executables and linker outputs; current native images/objects stay.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$allowed = Join-Path $workspace '.scratch\\vulkan-qwen-assembly-20261022'
$targets = @(
'''+ '\n'.join(rows)+'''
)
foreach ($target in $targets) {
  $leaf = Get-Item -LiteralPath $target.Path -Force
  if ($leaf.PSIsContainer -or -not $leaf.FullName.StartsWith($allowed + '\\', [StringComparison]::OrdinalIgnoreCase) -or $leaf.FullName -ne $target.Path) { throw 'Unexpected cleanup target' }
  if ($leaf.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $leaf.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.SHA256) { throw 'Cleanup target changed' }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.Path -Force }
[pscustomobject]@{ removed = $targets; logical_file_bytes = ($targets | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_measured = $false } | ConvertTo-Json -Depth 5
'''
    script=R/'test.ps1';script.write_text(text,encoding='utf8')
    (S/'cleanup-test.ps1').write_bytes(script.read_bytes())
    save(S/'cleanup-plan.json',dict(script=ident(script),immutable_script=ident(S/'cleanup-test.ps1'),targets=records,logical_file_bytes=sum(x['bytes']for x in records)))
    print(json.dumps(dict(script=ident(script),targets=len(records),logical_file_bytes=sum(x['bytes']for x in records))))

def publish():
    cleanup=read(S/'cleanup-plan.json')
    assert all(not(R/x['path']).exists()for x in cleanup['targets'])
    before={}
    for folder in [S/'before',S/'vulkan/before']:
        for p in folder.rglob('*'):
            if p.is_file()and p.name!='test.ps1':before[p.relative_to(folder).as_posix()]=p
    changes=[];patch=[]
    for rel,p in sorted(before.items()):
        now=R/rel
        if p.read_bytes()==now.read_bytes():continue
        changes.append(dict(before=ident(p),current=ident(now)))
        patch+=list(difflib.unified_diff(p.read_text(encoding='utf8').splitlines(True),now.read_text(encoding='utf8').splitlines(True),fromfile='before/'+rel,tofile='current/'+rel))
    (S/'changes.diff').write_text(''.join(patch),encoding='utf8')
    save(S/'current-source.json',changes)
    checks={'cpu':read(S/'cpu-run1/run-receipt.json')if(S/'cpu-run1/run-receipt.json').exists()else read(S/'cpu-run1/run.receipt.json')if(S/'cpu-run1/run.receipt.json').exists()else None}
    assert '[  PASSED  ] 8 tests.'in(S/'cpu-run1/run.stdout.log').read_text()
    assert 'PASS Vulkan 3 cases:'in(S/'test-run3/run.stdout.log').read_text()
    runs=[read(S/f'qwen-plain-run{i}/result.json')for i in range(1,4)]
    assert all(x['state']=='terminal'and x['exit']==1 for x in runs)
    assert 'AM_REGION_FAIL id=574'in(S/'qwen-plain-run3/stderr.log').read_text()
    assert read(S/'live.json')['state']=='terminal'
    z=E/(NAME+'-logs.zip')
    selected=[]
    with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as archive:
        for p in sorted(S.rglob('*')):
            if not p.is_file()or p.suffix.lower()not in ['.py','.json','.log','.cc','.h','.md','.txt','.diff','.ps1','.tsv']:continue
            if 'tmp'in p.relative_to(S).parts or p.stat().st_size>1024*1024:continue
            archive.write(p,p.relative_to(S).as_posix());selected.append(ident(p))
    with zipfile.ZipFile(z)as archive:assert archive.testzip()is None
    data=dict(date='2026-10-22',status='mechanisms_passed_full_vulkan_qwen_blocked',
      summary='Vulkan canonical retained backing budget and bounded native Buffer IO passed; same Qwen consumer loads all text weights and compiles finite graph, but first execution preparation exhausts native private memory through full-weight F32 CPY/CONT.',
      changes=changes,checks=dict(common_tests=8,vulkan_native_cases=3,device='NVIDIA GeForce RTX 4070',driver='617.14',cpu_log=ident(S/'cpu-run1/run.stdout.log'),vulkan_log=ident(S/'test-run3/run.stdout.log')),
      native_io=dict(staging_bytes=1048576,cached_original_copy_recording=True,whole_owning_private_padding=True,arbitrary_unaligned_partial_ranges='Unimplemented; destination unchanged in actual regression',retirement_failure='sticky local failure; original Runtime new admission disabled if clear cannot prove retirement; original pending drain retained'),
      qwen_runs=runs,diagnostic=dict(product_logging_changed=False,successful_regions=573,successful_private_storage_bytes=7760350944,large_weight_cast_cont_regions=97,large_weight_cast_cont_private_bytes=7616856064,failed_region=574,failed_private_request_bytes=100663296,failed_large_nodes=[dict(op='CPY',type='F32',bytes=50331648),dict(op='CONT',type='F32',bytes=50331648)],loaded_text_tensors=320,loaded_requested_bytes=3763655360,physical_vram_peak_measured=False),
      mtp_remaining=dict(qwen_greedy_k1_algorithm='implemented in existing listed CUDA/Apple cases',required_closure=['Vulkan full plain and K1 execution; fix native memory expansion first','Apple prefix/native cancellation combinations','cross-shape/batch numeric differences and full task quality'],separate_work=['other selected applicable MTP model/quantization profiles','performance optimization and complete four-arm comparison']),
      scope=dict(full_qwen_vulkan_pass=False,vulkan_mtp_run=False,new_performance_comparison=False,cmake_configure_run=False,SDK_rebuilds=0,shader_rebuilds=0,NVCC=0,apple_current_common_change_run=False),
      next_action='Remove unnecessary whole-weight widening/materialization in the original Vulkan cold lowering under the existing precision/ownership contract; no smaller model or relaxed budget/permission substitute.',
      cleanup=cleanup,evidence_zip=ident(z),archive_files=len(selected))
    save(E/(NAME+'.json'),data)
    print(json.dumps(dict(report=ident(E/(NAME+'.json')),logs=ident(z),removed_logical_file_bytes=cleanup['logical_file_bytes'])))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','publish']);a=p.parse_args()
    prepare()if a.action=='prepare'else publish()
