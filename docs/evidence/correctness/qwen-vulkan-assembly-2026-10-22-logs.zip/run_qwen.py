"""One actual original Vulkan Qwen consumer; no throughput claim."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
S=Path(__file__).resolve().parent;R=S.parents[1]
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(mode,attempt,image_attempt,diagnostic=False):
    root=S/('diagnostic-link1'if diagnostic else'qwen-link'+str(image_attempt));image=root/'qwen.exe';out=S/('qwen-'+mode+'-run'+str(attempt));out.mkdir()
    command=[str(image),'--inputs',str(R/'.scratch/qwen-native-assembly-20261022/inputs'/('text'if mode=='plain'else'mtp')),'--steps','4','--capacity','64','--max-sessions','1','--active-sequences','1','--cache-bytes',str(256*1024*1024),'--prefix-cache','off','--progress','direct','--replay','commands','--mtp','off'if mode=='plain'else'on']
    env=dict(os.environ,PATH=json.loads((root/'runtime-environment.json').read_bytes())['PATH'])
    record=dict(command=command,cwd=str(R),image=ident(image),started=time.time(),performance_comparison=False)
    with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
        child=subprocess.Popen(command,cwd=R,env=env,stdout=so,stderr=se);record.update(pid=child.pid,state='running');save(out/'command.json',record);save(S/'live.json',record);print('START',mode,'PID',child.pid,flush=True);child.wait()
    record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);save(out/'result.json',record);save(S/'live.json',record)
    print(json.dumps(record),flush=True)
    if child.returncode:print((out/'stderr.log').read_text(errors='replace')[-5500:]);raise SystemExit(1)
    output=json.loads((out/'stdout.log').read_bytes());keys=['backend','generated_ids','actual_graph_calls','actual_target_rows','actual_draft_rows','committed_target_rows','draft_frontier','draft_lag','rounds','cache_shared_backing_bytes','cache_retained_output_backing_bytes','cache_live_requested_bytes','cache_peak_requested_bytes','cache_requested_byte_limit']
    print(json.dumps({k:output.get(k)for k in keys}),flush=True)
    assert output['backend']=='vulkan'and output['cache_live_requested_bytes']>output['cache_shared_backing_bytes']and output['cache_peak_requested_bytes']<=output['cache_requested_byte_limit']
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['plain','mtp']);p.add_argument('--attempt',type=int,default=1);p.add_argument('--image-attempt',type=int,default=1);p.add_argument('--diagnostic',action='store_true');a=p.parse_args();run(a.mode,a.attempt,a.image_attempt,a.diagnostic)
