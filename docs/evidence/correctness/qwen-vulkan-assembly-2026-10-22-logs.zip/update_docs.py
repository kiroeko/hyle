"""Replace current status, preserving the previous document in before/."""
from pathlib import Path

S=Path(__file__).resolve().parent
R=S.parents[1]
p=R/'docs/developer/current-work.md'
t=p.read_text(encoding='utf8')
start=t.index('**MTP整体工程估测约70%')
end=t.index('**[Apple多会话与保留结果预算机制',start)
t=t[:start]+'''**Qwen3.5-2B greedy K1的MTP主链已实现，跨平台和质量仍需收口。** CUDA已有draft→verify→接受／拒绝→追赶、完整状态恢复、多请求／多轮／前缀／有界重建及取消退休；Apple真实普通／K1短流程和三会话两轮／B2／重建已有列明结果。此前“约70%（65%～75%）”仅为全后端及已选模型范围的工程粗估，不能解释成K1算法仍缺三成；当前按以下实际余项推进：

- **跨平台完整执行**：Apple前缀／原生取消组合；Vulkan完整普通版及K1消费者。Vulkan保留预算身份和device Buffer IO本批已实现并实测，完整普通推理当前因权重重复展开的私有存储耗尽而失败，见下。
- **数值及质量**：继续定位跨T／批宽及prefill来源的实际差异，检查完整任务质量；当前续文可读、有限控制通过，尚不能直接判定差异可接受。
- **其它模型／量化接线**：依已选总表及真实MTP制品补适用的算子／布局／状态；不带MTP或明确不承诺MTP的格式不凭空列缺，也不把所有profile混称为Qwen K1算法未实现。
- **性能**：在原数学／寿命下优化实际热点，再做普通／MTP四臂完整对照。最新MTP decode为112.27对126.18tok/s；这属于性能工作，当前没有新测速。更深draft及非greedy不属于本轮已承诺范围。

''' +t[end:]
start=t.index('**[Vulkan保留只读结果时的整block复用')
end=t.index('最新四臂的64token续文',start)
t=t[:start]+'''**[Vulkan完整消费者装配与本批实际结果](../evidence/correctness/qwen-vulkan-assembly-2026-10-22.json)。** 沿原Context／ExecutionSource／文件管线接同一Qwen消费者，模型数学不变。完整owned native backing新增明确canonical身份，在同scope／resource内对独立whole／slice／repeat导出租约只计一次；计费token先于payload释放，不改变F1身份／可读范围／只读权限。device Buffer IO复用一个有界staging及原CopyRecording，完整owning allocation的2字节BF16标量可用私有padding；普通未对齐子范围仍明确拒绝。8项common检查及RTX4070三项原生检查通过，含原[整block三代复用](../evidence/correctness/vulkan-retained-output-reuse-2026-10-22.json)、预算超额保旧租约／释放后重试、跨1MiB块的2MiB＋2字节IO及2字节标量。

**Vulkan完整普通推理尚未跑通。** 320份文本权重3,763,655,360字节已加载，P15／4、C64／N1／R1、显式256MiB缓存额度的有限冷图已编译。首次原生执行准备在ggml私有分配100,663,296字节时失败；临时单TU诊断实际确认成功的573个region保有7,760,350,944字节私有gallocr，其中97个大权重F32 cast＋cont区域占7,616,856,064字节（98.15%），失败区域另需两份48MiB。该账不是物理显存精确峰，缓存额度也不约束原生执行私有成本。下一步消除不必要的整权重展开／物化，沿原精度合同和冷规划接实际计算；没有因此降精度、缩模型或放宽权限。当前未进入完整prefill／decode，更未运行Vulkan MTP；本批没有新TPS或显存对照。

''' +t[end:]
replacements={
'前缀／原生取消组合、Vulkan完整消费者及共享保留预算身份仍需实现／检查；Vulkan只读结果三代复用已完成有限原生检查':'Apple前缀／原生取消组合仍待检查；Vulkan三代复用、canonical预算及device IO已实测，完整消费者首次准备因权重F32展开／cont私有内存耗尽而失败，需修底座',
'**整体估测约70%；CUDA已有列明范围，Apple真实多会话／多轮／重建及B2本批通过**。Qwen保留状态预算及统一报告已接入，实际超额保旧快照／原槽重试通过。Vulkan整block轮换／冷重绑已实现并通过两原生三代检查；下一步接Vulkan共享保留预算身份及完整消费者、Apple前缀／原生取消组合；其它模型／量化与跨批宽质量仍有工作。性能沿小行数投影的有限冷算法候选推进，已拒绝候选不反复测':'**Qwen greedy K1主链已实现；跨平台与质量未收口**。CUDA及Apple已有列明范围、预算／多会话／重建实际结果；Vulkan预算身份及device IO已实测，完整普通版先修权重重复展开导致的OOM。随后补Apple前缀／原生取消组合与数值质量；其它模型／量化适配、性能分别推进，不把它们合称K1算法尚缺三成'
}
for before,after in replacements.items():
    assert t.count(before)==1,before
    t=t.replace(before,after)
p.write_text(t,encoding='utf8')

p=R/'tools/qwen35_text/README.md';t=p.read_text(encoding='utf8')
before='P15／4输出覆盖一次拒绝和一次接受；两模式及CUDA的4个greedy ID相同，不代表完整模型质量、Apple多会话组合或性能验收。'
after='P15／4输出覆盖一次拒绝和一次接受；两模式及CUDA的4个greedy ID相同。[后续三会话／多轮／重建](../../docs/evidence/correctness/native-state-ownership-2026-10-22.json)已有实际结果，仍不代表完整模型质量或性能验收。Vulkan也已沿同一Backend接原生Context／device与staging资源／ExecutionSource／文件管线；[本批实际运行](../../docs/evidence/correctness/qwen-vulkan-assembly-2026-10-22.json)加载全部文本权重并编译冷图，但首次执行准备因大权重重复F32转换／物化耗尽私有存储而失败，尚未完成普通推理或MTP。'
assert t.count(before)==1;t=t.replace(before,after)
before='构建消费者的已安装SDK须包含`compute;graph;graph_progress;compute_stream;mem`产品及CUDA路由，或macOS上的Apple路由。平台与SDK导出的能力决定Backend：CUDA保留原Context／StorageOwner／设备内存／pinned暂存／Queue；Apple使用原生Context／共享内存／ExecutionSource，不制造通用Queue。'
after='构建消费者的已安装SDK须包含`compute;graph;graph_progress;compute_stream;mem`产品及CUDA、Vulkan或macOS上的Apple路由。平台与SDK导出的能力决定Backend：macOS优先Apple，其后CUDA，再用Vulkan。CUDA保留原Context／StorageOwner／设备内存／pinned暂存／Queue；Apple使用原生Context／共享内存／ExecutionSource，Vulkan使用原生Context／device与staging资源／ExecutionSource；原生路线不制造通用Queue。'
assert t.count(before)==1;t=t.replace(before,after)
t=t.replace('Apple的auto不设字节额度','Apple／Vulkan的auto不设字节额度')
p.write_text(t,encoding='utf8')
print('Updated current status and consumer guide; no performance table changed.')
