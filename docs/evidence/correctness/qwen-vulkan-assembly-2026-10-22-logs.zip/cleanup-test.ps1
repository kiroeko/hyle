# AM: only superseded executables and linker outputs; current native images/objects stay.
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$allowed = Join-Path $workspace '.scratch\vulkan-qwen-assembly-20261022'
$targets = @(
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\cpu-link1\cpu.exe'; Bytes = 138909696; SHA256 = '5b0243bda4647a1882570d927d2c2fb386dcd2e95d4f791cecd5db27e8fef867' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\cpu-link1\cpu.exp'; Bytes = 24974; SHA256 = '57c84758dafabd7a51767b7df66ce5204691bea1a99f03a3e70188b97761516d' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\cpu-link1\cpu.lib'; Bytes = 41298; SHA256 = '1a72c22d3a6dec39cca5118fd99aa738ff5f4202c029fc8a48afb6c3d20e909d' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\cpu-link1\cpu.map'; Bytes = 56776430; SHA256 = 'd3b1be3e7d41bf2b9d6d7ffe3152d19e3f2a72abe81979518db3e7e2b6711874' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\test-link2\test.exe'; Bytes = 67943936; SHA256 = 'ed935e1beec22f98aae271f1d6ea5dd629f8d281031a62d7b4dd66f7533ec56e' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\test-link2\test.exp'; Bytes = 24978; SHA256 = 'dd8822ec0570f58527b669141a25cdf0d725a5b63f3ce3aaf2917bc6bd7d472f' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\test-link2\test.lib'; Bytes = 41384; SHA256 = 'e8b2f56b280c09b2f7a259f184ba9923439c597a6227843d256c824b87a691fa' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\test-link2\test.map'; Bytes = 30505298; SHA256 = 'ad8f7423da7e93bc5ec97732ec72d7937b8c77e77cfc763da5388e6148ad8704' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\test-link3\test.exp'; Bytes = 24978; SHA256 = '42f0dc08e8cc8383602394d49f9d79bdbd85f6c7c6557604c3f706295795399e' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\test-link3\test.lib'; Bytes = 41384; SHA256 = 'e8b2f56b280c09b2f7a259f184ba9923439c597a6227843d256c824b87a691fa' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\test-link3\test.map'; Bytes = 30511900; SHA256 = '20f21fba10f20fce24b643d01cf759f9e8e08f40f496b581bc0623e703a51c58' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\qwen-link2\qwen.exe'; Bytes = 68976640; SHA256 = '17648c9ad2d96f0cbead38a1adaf4749bb7f85f8c2ce53ad8c2de9bf264dc828' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\qwen-link2\qwen.exp'; Bytes = 24978; SHA256 = 'd675764a588801cbda3b10121073b5f5e20b9f6701823983aef8fea41a6e122e' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\qwen-link2\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\qwen-link2\qwen.map'; Bytes = 32542520; SHA256 = '528cfd038c48a49ef45b4beeef9ce9760a3e280d96b8c4a9c184fe84acb1970b' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\qwen-link3\qwen.exp'; Bytes = 24978; SHA256 = 'e3c3e757efed6fb7d1b3d18bd670674ba5d4dc684cb53d8caaec1e6856802685' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\qwen-link3\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\qwen-link3\qwen.map'; Bytes = 32544300; SHA256 = 'f6320eb871952857e17f53e8ea248290a65884ec3763b933f6d7f80408c4852c' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\diagnostic-link1\qwen.exe'; Bytes = 68979712; SHA256 = '3c252dde84f026d489c0dd7594a19b8caa7d026c8ecb2257431218f437bfc802' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\diagnostic-link1\qwen.exp'; Bytes = 24984; SHA256 = 'cffba8f3ae14ad20f3d494fd9edfbdd14f45f6ee7377bceb05f2749df2865dff' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\diagnostic-link1\qwen.lib'; Bytes = 41384; SHA256 = '339d3ce297534ebac8825c27a011f2f4f9dfe366c657ebfc45dbbfdc8412a2cb' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\vulkan-qwen-assembly-20261022\diagnostic-link1\qwen.map'; Bytes = 32543435; SHA256 = 'c80f08406e4d3e45c51890f41ce598f6aa2ce387825f893a3034dbac552f7710' }
)
foreach ($target in $targets) {
  $leaf = Get-Item -LiteralPath $target.Path -Force
  if ($leaf.PSIsContainer -or -not $leaf.FullName.StartsWith($allowed + '\', [StringComparison]::OrdinalIgnoreCase) -or $leaf.FullName -ne $target.Path) { throw 'Unexpected cleanup target' }
  if ($leaf.Length -ne $target.Bytes -or (Get-FileHash -LiteralPath $leaf.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $target.SHA256) { throw 'Cleanup target changed' }
}
foreach ($target in $targets) { Remove-Item -LiteralPath $target.Path -Force }
[pscustomobject]@{ removed = $targets; logical_file_bytes = ($targets | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_measured = $false } | ConvertTo-Json -Depth 5
