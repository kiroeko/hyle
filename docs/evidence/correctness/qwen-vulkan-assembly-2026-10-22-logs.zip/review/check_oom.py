"""Offline counters only. No native imports, tensor payload reads, or model work."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[3]
STAGE = ROOT / ".scratch/vulkan-qwen-assembly-20261022"


def identity(path):
    path = ROOT / path
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def main():
    relative_log = ".scratch/vulkan-qwen-assembly-20261022/qwen-plain-run3/stderr.log"
    text = (ROOT / relative_log).read_text(encoding="utf-8")
    begins = {}
    for match in re.finditer(r"AM_REGION_BEGIN id=(\d+) nodes=(\d+) input=(\d+) output=(\d+) internal_gross=(\d+)", text):
        record = dict(zip(("id", "nodes", "input_bytes", "output_bytes", "internal_gross_bytes"), map(int, match.groups())))
        assert record["id"] not in begins
        begins[record["id"]] = record
    allocated = {}
    for region, size in re.findall(r"AM_REGION_ALLOCATED id=(\d+) private=(\d+)", text):
        region, size = int(region), int(size)
        assert region not in allocated
        allocated[region] = size
    failures = list(map(int, re.findall(r"AM_REGION_FAIL id=(\d+)", text)))
    large = []
    for region, node, operation, dtype, size, shape in re.findall(
            r"AM_REGION_LARGE id=(\d+) node=(\d+) op=(\S+) type=(\S+) bytes=(\d+) shape=(\S+)", text):
        large.append({"region": int(region), "node": int(node), "operation": operation,
                      "dtype": dtype, "bytes": int(size), "ggml_ne": list(map(int, shape.split(",")))})
    assert set(begins) == set(allocated) | set(failures)
    assert set(allocated).isdisjoint(failures)
    assert list(begins) == list(range(1, max(begins) + 1))
    assert failures == [574] and len(allocated) == 573
    assert all(item["region"] in begins and item["bytes"] >= 16 * 1024**2 for item in large)
    large_regions = {item["region"] for item in large if item["region"] in allocated}
    successful_private = sum(allocated.values())
    large_private = sum(allocated[region] for region in large_regions)
    operation_counts = {}
    for operation in sorted({item["operation"] for item in large}):
        selected = [item for item in large if item["operation"] == operation]
        successful = [item for item in selected if item["region"] in allocated]
        operation_counts[operation] = {
            "attempted_nodes": len(selected), "attempted_node_bytes": sum(item["bytes"] for item in selected),
            "successful_region_nodes": len(successful), "successful_region_node_bytes": sum(item["bytes"] for item in successful),
            "failed_region_nodes": len(selected) - len(successful),
            "failed_region_node_bytes": sum(item["bytes"] for item in selected) - sum(item["bytes"] for item in successful)}
    for region in large_regions:
        assert sum(item["bytes"] for item in large if item["region"] == region) == allocated[region]
    manifest_relative = ".scratch/qwen-native-assembly-20261022/inputs/text/weights.tsv"
    manifest = (ROOT / manifest_relative).read_text(encoding="utf-8").splitlines()
    weights = []
    for line in manifest[3:]:
        if not line:
            continue
        fields = line.split("\t")
        rank = int(fields[2])
        weights.append({"name": fields[0], "dtype": fields[1], "shape": list(map(int, fields[3:3 + rank])), "bytes": int(fields[-1])})
    weight_bytes = sum(item["bytes"] for item in weights)
    assert len(weights) == 320 and weight_bytes == 3763655360
    mlp = [item for item in weights if ".mlp." in item["name"] and len(item["shape"]) == 2]
    assert len(mlp) == 72
    failure = begins[failures[0]] | {"large_nodes": [item for item in large if item["region"] == failures[0]], "failed_request_bytes": 100663296}
    run = json.loads((STAGE / "qwen-plain-run3/result.json").read_text(encoding="utf-8"))
    original_run = json.loads((STAGE / "qwen-plain-run2/result.json").read_text(encoding="utf-8"))
    assert run["state"] == "terminal" and run["exit"] == 1
    assert original_run["state"] == "terminal" and original_run["exit"] == 1
    histogram = Counter(allocated.values())
    shape_counts = Counter((item["operation"], item["dtype"], tuple(item["ggml_ne"]), item["bytes"], item["region"] in allocated) for item in large)
    paths = [relative_log, manifest_relative,
             ".scratch/vulkan-qwen-assembly-20261022/qwen-plain-run2/result.json",
             ".scratch/vulkan-qwen-assembly-20261022/qwen-plain-run3/result.json",
             ".scratch/vulkan-qwen-assembly-20261022/diagnostic/source/region.cc",
             ".scratch/vulkan-qwen-assembly-20261022/diagnostic/recipe.json",
             "src/compute_provider_ggml_vulkan/native_storage_impl.h",
             "src/compute_provider_ggml_vulkan/native_work_impl.h",
             "src/compute_provider_ggml_vulkan/native_runtime_impl.h",
             "src/compute_provider_ggml_vulkan/native_graph.cc",
             "src/compute_provider_ggml_vulkan/region.cc",
             "src/compute_route_vulkan/vulkan_program.cc",
             "src/compute_route_vulkan/vulkan_region.cc", "tools/qwen35_text/main.cc"]
    report = {
        "status": "FROZEN_HOST_ONLY_SOURCE_AND_ACTUAL_OOM_COUNTER_REVIEW",
        "scope": "Vulkan plain Qwen P15, four requested outputs, C64/N1/R1; failure during first T15 Invocation creation, before inference. Original run2 and diagnostic run3 both exit1. No build, native execution, source edits, or payload reads by this reviewer.",
        "images": {"original_run2": original_run["image"], "diagnostic_run3": run["image"]},
        "verification": {"terminal_failures_preserved": True, "all_region_ids_accounted_once": True,
                         "large_pair_bytes_equal_each_successful_region_private_pool": True,
                         "manifest_weight_count_and_bytes_match_stderr": True},
        "actual_counters": {
            "region_creation_attempts": len(begins), "successful_regions": len(allocated),
            "successful_nonzero_private_regions": sum(size > 0 for size in allocated.values()),
            "successful_zero_private_regions": sum(size == 0 for size in allocated.values()),
            "sum_successful_private_requested_bytes": successful_private,
            "successful_regions_with_logged_large_CPY_CONT": len(large_regions),
            "their_private_requested_bytes": large_private,
            "their_fraction_of_successful_private_bytes": large_private / successful_private,
            "other_successful_private_requested_bytes": successful_private - large_private,
            "large_node_log_threshold_bytes": 16 * 1024**2,
            "large_nodes_by_operation": operation_counts,
            "private_size_histogram": [{"bytes_per_region": size, "regions": count, "sum_bytes": size * count} for size, count in sorted(histogram.items())],
            "large_node_shape_counts": [{"operation": op, "dtype": dtype, "ggml_ne": shape, "node_bytes": size, "region_allocation_succeeded": success, "nodes": count} for (op, dtype, shape, size, success), count in sorted(shape_counts.items())],
            "failure": failure},
        "weights": {"manifest_tensors": len(weights), "resident_original_bytes": weight_bytes,
                    "mlp_matrices": len(mlp), "original_mlp_bf16_bytes": sum(item["bytes"] for item in mlp),
                    "original_weights_plus_successful_private_requested_bytes": weight_bytes + successful_private,
                    "sum_is_not_a_physical_VRAM_peak": True},
        "source_chain": [
            {"anchor": "tools/qwen35_text/main.cc:375-381", "fact": "Ordinary linear retains original BF16 stored [O,K] weights, makes a permuted [K,O] View, then ordinary MatMul with BF16 output."},
            {"anchor": "src/compute_route_vulkan/vulkan_region.cc:467-506", "fact": "lower_bfloat_region creates dense F32 Cast nodes for every non-F32/non-I32 input, including the BF16 matrix weight, before native MatMul; final public BF16 rounding remains a separate native Cast."},
            {"anchor": "src/compute_provider_ggml_vulkan/region.cc:1238-1279", "fact": "Ordinary MatMul transposes right and ggml_cont materializes a non-contiguous transpose; native multiply uses explicit F32 accumulation. Its separate existing BF16 small-matvec handling already widens only activation where required."},
            {"anchor": "src/compute_provider_ggml_vulkan/region.cc:1924-1940", "fact": "NativeGraph gallocr allocation occurs before the failed region's NativeWork/backend creation. Port binding buffers are borrowed wrappers, not another payload allocation (native_runtime_impl.h:184-204)."},
            {"anchor": "src/compute_provider_ggml_vulkan/native_storage_impl.h:14-21,62-109", "fact": "Storage owns one gallocr per NativeGraph; allocation callback forwards requested bytes to original Vulkan allocator. Hyle has no fixed 96MiB reservation here; recorded successful private sizes vary from zero through 96MiB."},
            {"anchor": "src/compute_provider_ggml_vulkan/native_graph.cc:7-18,21-45; src/compute_route_vulkan/vulkan_region.cc:1478-1547", "fact": "Successful graph storage is retained by its Region/Run stage until original owner teardown. Each successfully constructed stage has separate native graph storage; sharing original weights does not share these per-graph Cast/CONT pools."},
            {"anchor": "src/compute_route_vulkan/vulkan_program.cc:177-248,466-470,561-576", "fact": "Existing constant-cast/pack passes run before general View constant propagation. Packing requires an already-present dense constant; a transposed derived weight View can miss it. No model-wide cache is required to expose this ordering/layout seam."}],
        "interpretation": [
            "The counter proves the immediate failed 96MiB pool contains one 50,331,648B F32 CPY and one equal F32 CONT, shapes [2048,6144,1,1] and [6144,2048,1,1]. This is the BF16 weight widening plus native physical transpose mechanism, not a generic 96MiB-per-region minimum.",
            "Across 97 successful large-pair regions, logged CPY+CONT bytes exactly equal their private pools (7,616,856,064B); these account for about 98.1509% of all successful private requested bytes. The large-node logger omits nodes smaller than 16MiB, so the CPY/CONT totals are explicitly thresholded, not all graph CPY/CONT counts.",
            "Original resident weights plus successful private requested buffers total 11,524,006,304B before the failed extra 100,663,296B request. This explains severe capacity pressure without invoking an extra parity slot, changed model dtype, or physical-residency estimates from post-process memory.",
            "The 573 successes are nested native Regions, not 573 public Graph steps. Public compilation reports 37 steps, 19 unknown providers for T15, slot0 uses1 and slot1 uses0; finite variants2 does not mean both physical execution slots were materialized.",
            "NativeWork creates its own original backend/fence and may acquire backend work scratch on actual execution. The failed Region has not reached create_work, so its Work reservation cannot be the immediate 96MiB allocation. Earlier backend/import/driver costs are not fully measured by these counters."],
        "minimal_fix_direction": {
            "priority": "Keep ordinary BF16 MatMul operand semantics in the existing Vulkan lowering/native Region path: preserve an immutable BF16 weight and its real strided View/original stored orientation instead of blanket F32 widening followed by physical transpose; widen only activation if the actual native kernel requires it. Retain explicit F32 accumulation and original BF16 output boundary, with normal supports-op qualification. No consumer dtype change, global cache, new executor, or per-session weight copy.",
            "files_to_evaluate": ["src/compute_route_vulkan/vulkan_region.cc", "src/compute_provider_ggml_vulkan/region.cc", "src/compute_route_vulkan/vulkan_program.cc"],
            "secondary_existing_mechanism": "Correct immutable View/constant propagation before cold packing, retaining exact stride/orientation. Existing Program-level constant ownership/replacements can avoid per-slot conversion only where a conversion is genuinely required; merely hoisting full F32 copies into every finite Program is not a proven memory fix.",
            "not_yet_proven": "Native kernel legality and numerical behavior for the full ordinary BF16 T15/T1 matrix family after this lowering change, actual reduced memory peak, and full Vulkan Qwen inference. No fix is implemented or signed passed here."},
        "diagnostic": {
            "actual_insertion": "Scratch diagnostic Region::create immediately before/after NativeGraph::allocate; root executed once, original product source unchanged.",
            "sufficient_current_result": "Per-region CPY/CONT shape/type/bytes and graph private requested bytes directly identify the dominant amplification. No additional diagnostic or model run is requested by this report.",
            "measurement_limits": ["internal_gross sums tensor descriptors, not liveness or VRAM; input/output totals count references and must not be summed as new allocations.", "Successful pool bytes are requested allocator capacities, not a process/device physical peak. Counter lacks free/driver-residency events; allocations are owned by original Run stages until failure teardown.", "Post-exit 2.2GB used/9.7GB free is not runtime peak. Unknown provider bytes and workspace/slot=0 cannot be read as zero private memory."]},
        "sources": [identity(path) for path in paths],
        "recompute": ".scratch/vulkan-qwen-assembly-20261022/review/check_oom.py"
    }
    output = STAGE / "review/oom-report.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"report": identity(output.relative_to(ROOT)), "successful_private_bytes": successful_private,
                      "large_pair_private_bytes": large_private, "failed_region": failures[0]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
