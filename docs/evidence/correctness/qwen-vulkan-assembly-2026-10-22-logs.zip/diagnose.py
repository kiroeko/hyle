"""One bounded cold region-storage diagnostic, no product logging change."""
from pathlib import Path
import argparse,importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('am_diag',S/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
def compile_one():
    original=h.owner('src/compute_provider_ggml_vulkan/region.cc');recipe=c.read(original)
    old=(R/'src/compute_provider_ggml_vulkan/region.cc').read_text(encoding='utf8')
    before='''    HYLE_ASSIGN_OR_RETURN(state.graph,
                          NativeGraph::allocate(state.device, std::move(arena),
                                                graph, state.imports));'''
    after='''    static std::size_t diagnostic_region = 0;
    const auto diagnostic_index = ++diagnostic_region;
    std::size_t diagnostic_inputs=0, diagnostic_outputs=0, diagnostic_internal=0;
    for(std::size_t i=0;i<state.ports.size();++i) {
      if(i<recipe.inputs.size()) diagnostic_inputs += ggml_nbytes(state.ports[i]);
      else diagnostic_outputs += ggml_nbytes(state.ports[i]);
    }
    for(int i=0;i<ggml_graph_n_nodes(graph);++i) {
      const auto *node=ggml_graph_node(graph,i);
      if(!node->buffer && !node->view_src) {
        diagnostic_internal += ggml_nbytes(node);
        if(ggml_nbytes(node)>=16u*1024u*1024u)
          std::fprintf(stderr,"AM_REGION_LARGE id=%zu node=%d op=%s type=%s bytes=%zu shape=%lld,%lld,%lld,%lld\\n",diagnostic_index,i,ggml_op_name(node->op),ggml_type_name(node->type),ggml_nbytes(node),static_cast<long long>(node->ne[0]),static_cast<long long>(node->ne[1]),static_cast<long long>(node->ne[2]),static_cast<long long>(node->ne[3]));
      }
    }
    std::fprintf(stderr,"AM_REGION_BEGIN id=%zu nodes=%d input=%zu output=%zu internal_gross=%zu\\n",diagnostic_index,ggml_graph_n_nodes(graph),diagnostic_inputs,diagnostic_outputs,diagnostic_internal);
    auto diagnostic_allocation=NativeGraph::allocate(state.device,std::move(arena),graph,state.imports);
    if(!diagnostic_allocation) { std::fprintf(stderr,"AM_REGION_FAIL id=%zu\\n",diagnostic_index); return std::unexpected(diagnostic_allocation.error()); }
    state.graph=std::move(*diagnostic_allocation);
    std::fprintf(stderr,"AM_REGION_ALLOCATED id=%zu private=%zu\\n",diagnostic_index,state.graph.storage_bytes());'''
    assert old.count(before)==1
    source=S/'diagnostic/source/region.cc';source.parent.mkdir(parents=True,exist_ok=True);source.write_text('#include <cstdio>\n'+old.replace(before,after),encoding='utf8')
    recipe['command']=['/MD'if x=='-MD'else x for x in recipe['command']]
    recipe['command'].append('/I'+str(R/'src/compute_provider_ggml_vulkan'));path=S/'diagnostic/recipe.json';c.save(path,recipe)
    h.h.RECIPES['diag-region']=path;h.h.SOURCES['diag-region']=source;h.h.compile_one('diag-region',2)
def link():
    root=S/'qwen-link3';base=c.read(root/'link-plan.json');old=c.read(h.owner('src/compute_provider_ggml_vulkan/region.cc'))['object'];new=c.read(S/'compile2/diag-region/identity.json')['object']
    assert sum(c.key(x['path'])==c.key(old['path'])for x in base['inputs'])==1
    out=S/'diagnostic-link1';out.mkdir();(out/'tmp').mkdir();image=out/'qwen.exe'
    command=[new['path']if c.key(x)==c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=[new if c.key(x['path'])==c.key(old['path'])else x for x in base['inputs']]
    for x in inputs:assert b.identity(x['path'])==x
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,diagnostic_only=True,SDK_builds=0,NVCC=0));env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    c.save(out/'runtime-environment.json',c.read(root/'runtime-environment.json'));c.save(out/'ready.json',dict(image=b.identity(image)))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('actions',nargs='+',choices=['compile','link']);a=p.parse_args()
    for action in a.actions:compile_one()if action=='compile'else link()
