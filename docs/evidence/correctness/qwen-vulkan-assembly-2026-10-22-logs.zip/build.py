"""Current Vulkan Qwen/retention owners, cached native closure, no SDK rebuild."""
from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('am_host',R/'.scratch/native-paged-effects-20261022/build_windows.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c;h.S=S
BASE=R/'.scratch/qwen-retained-budget-20261022/vulkan-build/link3';base=c.read(BASE/'link-plan.json')
def owner(source):
    found=[]
    for x in base['inputs']:
        p=Path(x['path'])
        for candidate in [p.parent/'identity.json',p.with_name(p.stem+'-identity.json')]:
            if candidate.is_file():
                v=c.read(candidate)
                if c.key(v.get('object',{}).get('path',''))==c.key(p)and v.get('source',{}).get('path','').replace('\\','/').endswith('/'+source):found.append(candidate)
    assert len(found)==1,(source,found)
    return found[0]
h.RECIPES={
 'leases':R/'.scratch/native-state-ownership-20261022/compile2/leases/identity.json',
 'leaf':R/'.scratch/qwen-retained-budget-20261022/vulkan-build/compile1/leaf/identity.json',
 'memory':owner('src/compute_route_vulkan/vulkan_memory.cc'),
 'test':R/'.scratch/qwen-retained-budget-20261022/vulkan-build/compile3/test/identity.json',
 'main':R/'.scratch/qwen-retained-budget-20261022/vulkan-build/compile1/leaf/identity.json',
 'file-stream':R/'.scratch/qwen-retained-budget-20261022/vulkan-build/compile1/leaf/identity.json',
 'cpu-test':R/'.scratch/native-state-ownership-20261022/compile1/lease-test/identity.json'}
h.SOURCES={tag:R/name for tag,name in {
 'leases':'src/compute/resource_leases.cc','leaf':'src/graph_route_vulkan/native_region.cc',
 'memory':'src/compute_route_vulkan/vulkan_memory.cc','test':'tests/graph_route_vulkan/retained_output_reuse_consumer.cc',
 'main':'tools/qwen35_text/main.cc','file-stream':'src/compute_stream_vulkan/file_stream.cc',
 'cpu-test':'tests/compute/retained_lease_budget_test.cc'}.items()}
def latest(tag,attempt):
    paths=[S/f'compile{i}/{tag}/identity.json'for i in range(attempt,0,-1)]
    p=next(x for x in paths if x.is_file());v=c.read(p);assert b.identity(v['source']['path'])==v['source'];assert b.identity(v['object']['path'])==v['object'];return p,v
def link(kind,attempt):
    original=base if kind!='cpu'else c.read(R/'.scratch/native-state-ownership-20261022/cpu-link2/link-plan.json')
    tags=['leases','leaf','memory']if kind!='cpu'else['leases','cpu-test']
    if kind=='test':tags+=['test']
    replacements={};records=[];addons=[]
    for tag in tags:
        p,v=latest(tag,attempt);replacements[c.key(c.read(h.RECIPES[tag])['object']['path'])]=v['object'];records.append(b.identity(p))
    if kind=='qwen':
        p,v=latest('main',attempt);records.append(b.identity(p));replacements[c.key(c.read(h.RECIPES['test'])['object']['path'])]=v['object']
        p,v=latest('file-stream',attempt);records.append(b.identity(p));addons.append(v['object'])
        cu=c.read(R/'.scratch/qwen-retained-budget-20261022/cuda-link1/link-plan.json')
        extra_prefix=R/'.scratch/architecture-refactor-2026-10-18/qwen-pinned-weight-load/checks'
        addons.extend(x for x in cu['inputs']if Path(x['path']).parent==extra_prefix and Path(x['path']).name.startswith(('io-','stream-')))
        assert len(addons)==15,len(addons)
    if kind=='cpu':
        # The previously linked CPU image already used this newer leases owner.
        old=c.read(R/'.scratch/native-state-ownership-20261022/compile2/leases/identity.json')['object'];assert c.key(old['path'])in replacements
    for key in replacements:assert sum(c.key(x['path'])==key for x in original['inputs'])==1,key
    for x in original['inputs']:assert b.identity(x['path'])==x
    for x in addons:assert b.identity(x['path'])==x
    out=S/(kind+'-link'+str(attempt));out.mkdir();(out/'tmp').mkdir();image=out/(kind+'.exe')
    command=[replacements.get(c.key(x),{}).get('path',x)for x in original['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command[1:1]=[x['path']for x in addons]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    inputs=addons+[replacements.get(c.key(x['path']),x)for x in original['inputs']]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_records=records,SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read((BASE if kind!='cpu'else R/'.scratch/native-state-ownership-20261022/cpu-link2')/'runtime-environment.json');c.save(out/'runtime-environment.json',runtime)
    for x in runtime.get('staged_dlls',[]):
        p=Path(x['path'])
        if not(out/p.name).exists():os.link(p,out/p.name)
    c.save(out/'ready.json',dict(image=b.identity(image),plan=b.identity(out/'link-plan.json')));print('LINKED',kind,flush=True)
def run(kind,attempt):
    root=S/(kind+'-link'+str(attempt));out=S/(kind+'-run'+str(attempt));out.mkdir();command=[str(root/(kind+'.exe'))]
    if kind=='cpu':command+=['--gtest_filter=SharedBackingBudget.*:RetainedLeaseBudget.*']
    env=dict(os.environ,PATH=c.read(root/'runtime-environment.json')['PATH']);c.save(out/'image.json',b.identity(command[0]));c.execute('run',command,env,out);print((out/'run.stdout.log').read_text(errors='replace'))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('actions',nargs='+',choices=[*h.RECIPES,'link-test','link-qwen','link-cpu','run-test','run-cpu']);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
    for tag in a.actions:
        if tag.startswith('link-'):link(tag[5:],a.attempt)
        elif tag.startswith('run-'):run(tag[4:],a.attempt)
        else:h.compile_one(tag,a.attempt)
