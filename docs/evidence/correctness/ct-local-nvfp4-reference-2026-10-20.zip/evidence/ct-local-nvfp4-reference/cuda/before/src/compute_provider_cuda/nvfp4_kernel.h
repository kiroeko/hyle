#pragma once

#include <cstdint>
#include <cuda_runtime_api.h>

namespace hyle::compute::cuda_native::nvfp4 {
struct Program final {
  std::uint64_t rows = 0, columns = 0, depth = 0;
  std::uint64_t slots = 1, experts = 1, activation_slots = 1;
  // BF16 element strides of the original grouped activation, not an expanded A.
  std::uint64_t activation_token_stride = 0, activation_slot_stride = 0;
  bool grouped = false;
};
cudaError_t prepare_kernel() noexcept;
cudaError_t launch(const Program &, const void *const *inputs, void *activation,
                   void *output, unsigned *status, cudaStream_t) noexcept;
} // namespace hyle::compute::cuda_native::nvfp4
