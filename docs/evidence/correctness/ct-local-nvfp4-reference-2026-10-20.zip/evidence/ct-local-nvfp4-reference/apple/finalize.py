from pathlib import Path
import difflib
import hashlib
import json
import xml.etree.ElementTree as E

S = Path(__file__).resolve().parent
ROOT = S.parents[3]
assert (ROOT / "include/hyle/compute/model_ops.h").is_file()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def identity(path):
    p = Path(path)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


original_freeze = S / "source-freeze-first-build.json"
if not original_freeze.exists():
    original_freeze.write_bytes((S / "source-freeze.json").read_bytes())
owned = [x["path"] for x in read(S / "before.json")]
owned += ["tests/graph_route_apple/local_nvfp4_reference_test.cc",
          "tests/graph_route_apple/nvfp4_reference_test.cc"]
changes = []
rows = []
for rel in owned:
    current = ROOT / rel
    before = S / "before" / rel
    after = S / "after" / rel
    after.parent.mkdir(parents=True, exist_ok=True)
    after.write_bytes(current.read_bytes())
    row = identity(current)
    row["path"] = rel
    rows.append(row)
    changes += list(difflib.unified_diff(
        before.read_text(encoding="utf-8").splitlines(keepends=True) if before.exists() else [],
        current.read_text(encoding="utf-8").splitlines(keepends=True),
        fromfile="before/" + rel, tofile="after/" + rel))
(S / "product.diff").write_text("".join(changes), encoding="utf-8")
dependencies = ["src/compute_shader_shared/nvfp4_f32.h", "include/hyle/compute/model_ops.h",
                "src/compute_ops/weight_decode.cc", "tests/compute_models/local_nvfp4_reference_fixture.h"]
save(S / "source-freeze.json", dict(files=rows, dependencies=[identity(ROOT / rel) for rel in dependencies]))
assert identity(ROOT / dependencies[-1])["sha256"] == "6a44e8635da2e8b269a06e3fa472cfa91f24a417cc10845dd8dcfdf5ee4e6015"
first = S / "mac/remote/results"
final = S / "mac/remote/guard-update/results"
old_inputs = read(first / "link-inputs.json")
new_inputs = read(final / "link-inputs.json")
local_obj = next(x for x in old_inputs if x["path"].endswith("tests--graph_route_apple--local_nvfp4_reference_test.cc.o"))
assert local_obj in new_inputs
products = [x for x in read(first / "compile-summary.json")["compiles"] if x["source"]["path"].endswith(".cc") and "/src/" in x["source"]["path"]]
assert len(products) == 4 and all(x["exit"] == 0 for x in products)
for row in products:
    assert row["object_identity"] in new_inputs
cases = E.parse(final / "tests.xml").findall(".//testcase")
assert len(cases) == 7 and not any(x.findall("failure") or x.findall("skipped") for x in cases)
cases_json = []
for case in cases:
    cases_json.append(dict(name=case.get("classname") + "." + case.get("name"),
        properties={x.get("name"): x.get("value") for x in case.findall("./properties/property")}))
save(S / "final-validation.json", {
    "status": "passed bounded Apple LocalNvfp4 dense/grouped reference and original ModelOpt regressions",
    "source_freeze": identity(S / "source-freeze.json"),
    "first_build_source_freeze": identity(original_freeze),
    "product_diff": identity(S / "product.diff"),
    "hardware": read(S / "mac/remote/hardware.json"),
    "first": {"validation": identity(first / "validation.json"), "xml": identity(first / "tests.xml"),
        "stdout": identity(first / "run.stdout.log"), "counts": {"tests": 7, "passed": 6, "failed": 1, "skipped": 0},
        "failure": "Existing ByteCarrier test still expected FP8->F32 Cast to be rejected, superseded by the preceding static-FP8 package. All new Local arithmetic/lifetimes and original ModelOpt arithmetic/lifetimes passed.",
        "not_a_product_fix": "The obsolete guard was updated to execute numerical E4 Casts (signed zero, finite/subnormal/max, NaN class, midpoint RNE) and still reject ordinary FP8 Binary. No product or shared oracle changed after first run."},
    "final": {"validation": identity(final / "validation.json"), "xml": identity(final / "tests.xml"),
        "stdout": identity(final / "run.stdout.log"), "stderr": identity(final / "run.stderr.log"),
        "link_command": identity(final / "link.command.json"), "link_inputs": identity(final / "link-inputs.json"),
        "image": read(final / "validation.json")["image"], "cases": cases_json,
        "tests": 7, "passed": 7, "failed": 0, "skipped": 0,
        "same_new_local_test_object_as_first_run": local_obj,
        "same_four_product_objects_as_first_run": [x["object_identity"] for x in products]},
    "actual_counts": {"CXX": 6, "product_CXX": 4, "test_CXX": 2, "links": 2,
        "test_processes": 2, "SDK_builds": 0, "NVCC": 0, "Windows_GPU": 0},
    "compile_receipts": [identity(first / "compile-summary.json"), identity(final / "compile-summary.json")],
    "overlay": {"manifest": identity(S / "mac/source-manifest.json"), "files": 73,
        "initial_bytes": 676771, "note": "Only small source/header overlay plus the separate updated guard source; original SDK, libraries and objects reused in place. Common helper const syntax correction arrived before Mac compilation and was synced alone; no Mac compiler failure was incurred."},
    "capability": ["Dense and selected grouped Local NVFP4, direct and BF16 FP4 pre-rounding, original raw global divisors",
        "Group16 BF16 scale-generation boundary, exact-zero .125, direct F32 SF/global divisions and explicit BF16 operands",
        "Complete ID validation before any expert metadata access; selected-only domains; shared/per-slot/zero-slot padded-token A",
        "Original Program/Stream/status and independent Invocation result lifetimes; no new executor or full W decode",
        "New life32 submit, runtime44 successful submit plus24 expected failing Completions; original dense and grouped math retained"],
    "limits": ["No checkpoint payload or complete selected-model execution, quality, or throughput benchmark",
        "No hardware W4A4/scaled-GEMM equivalence claim; this is the declared portable BF16 operand reference",
        "Dot reduction follows the existing software integer-F32 SIMD tree; sparse oracle cases isolate operand-rounding witnesses",
        "Only Mac16,12/Apple M4 verified; no claim for other Apple devices or maximum expert-bank/device carrier capacities",
        "Scratch is BF16 M*K or T*S*K plus native checks, not zero scratch; source/fixture dimensions do not prove all full-model bank capacities",
        "No SDK rebuild, source-tree checkout duplication, cleanup or deployment performed"]
})
print(json.dumps(identity(S / "final-validation.json")))
print(json.dumps(identity(S / "source-freeze.json")))
