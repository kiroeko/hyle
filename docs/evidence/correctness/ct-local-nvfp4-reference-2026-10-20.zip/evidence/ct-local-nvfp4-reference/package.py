from pathlib import Path,PurePosixPath
import hashlib,json,sys,xml.etree.ElementTree as ET,zipfile
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';S=A/'ct-local-nvfp4-reference'
DEST=ROOT/'docs/evidence/correctness/ct-local-nvfp4-reference-2026-10-20'
RESEARCH=ROOT/'docs/evidence/research/ct-local-nvfp4-contract-2026-10-20'
PUBLISH='--publish' in sys.argv
FINAL_FREEZE=S/'root/final-source-freeze.json'
entries={};provenance={};projections=[];dependency_members={}
def load(p):return json.loads(Path(p).read_bytes())
def encode(v):return (json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes()
 try:name=p.relative_to(ROOT).as_posix()
 except ValueError:name=str(p)
 return dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def member_ok(name):
 p=PurePosixPath(name);assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name,name
 assert p.suffix.lower() not in ['.exe','.obj','.o','.lib','.a','.dll','.pdb','.map','.zip','.tar','.metallib','.spv','.exp'],name
 assert not any('cleanup' in x.lower() for x in p.parts),name
 return name
def add_data(name,data,origin=None):
 member_ok(name);assert name not in entries or entries[name]==data,name;entries[name]=data
 if origin is not None:provenance[name]=origin
 return name
def add(p,name=None):
 p=Path(p);return add_data(name or 'evidence/'+p.relative_to(A).as_posix(),p.read_bytes(),identity(p))
def compact(v):
 if isinstance(v,dict):
  result={}
  for k,x in v.items():
   if k=='dependencies' and isinstance(x,list):
    b=encode(x);sha=hashlib.sha256(b).hexdigest();name='dependency-inventories/'+sha+'.json'
    add_data(name,b);dependency_members[sha]=name
    result['dependency_inventory']=dict(member=name,count=len(x),bytes=len(b),sha256=sha)
   else:result[k]=compact(x)
  return result
 if isinstance(v,list):return [compact(x) for x in v]
 return v
def add_json(p):
 raw=p.read_bytes();v=load(p);projected=compact(v);data=encode(projected)
 if projected!=v:
  name='receipts/'+p.relative_to(A).as_posix();add_data(name,data,identity(p));projections.append(dict(original=identity(p),compact_member=name,note='Dependency arrays moved losslessly to content-addressed shared inventories. All other fields retained.'))
 else:add(p)
def verify_record(row):
 p=Path(row['path']);p=p if p.is_absolute() else ROOT/p;actual=identity(p);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],str(p);return p
allowed={'.json','.py','.diff','.xml','.txt','.log','.h','.cc','.cuh','.cu','.comp','.glsl','.before','.d'}
for p in sorted(S.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(S)
 if '__pycache__' in rel.parts or 'before-docs' in rel.parts or p.suffix.lower() not in allowed:continue
 if p.name in ['package-plan.json','package-receipt.json','live.json','vulkan_shaders.cc'] or p.name.endswith('-deps.json'):continue
 if any(x in p.name.lower() for x in ['cleanup','payload','sync-bundle']):continue
 if p.suffix.lower()=='.json':add_json(p)
 else:add(p)
research=dict(report=identity(RESEARCH.with_suffix('.json')),archive=identity(RESEARCH.with_suffix('.zip')),scope='Independently published fixed headers/source research; no primary-source or header archive duplicated here.')
add(RESEARCH.with_suffix('.json'),'research/'+RESEARCH.with_suffix('.json').name)
def source_rows(value):
 if isinstance(value,dict):
  if all(k in value for k in ['path','bytes','sha256']):
   p=Path(value['path']);p=p if p.is_absolute() else ROOT/p
   if p.is_file() and p.is_relative_to(ROOT) and p.relative_to(ROOT).parts[0] in ['include','src','tests']:yield p,value
  for child in value.values():yield from source_rows(child)
 elif isinstance(value,list):
  for child in value:yield from source_rows(child)
source_paths={ROOT/p for p in ['src/compute_shader_shared/nvfp4_f32.h','src/compute_shader_shared/ct_packed.h','src/compute_provider_native/native_plan.h','src/compute_provider_native/numeric.h','tests/compute_models/nvfp4_reference_fixture.h','tests/compute_models/grouped_nvfp4_reference_fixture.h']}
for p in [S/'common-cpu/source-freeze.json',S/'common-cpu/fixture-source-freeze.json',S/'apple/source-freeze.json',S/'vulkan/final-source-freeze.json',FINAL_FREEZE]:
 if p.is_file():
  for candidate,row in source_rows(load(p)):
   if p==FINAL_FREEZE:verify_record(row)
   source_paths.add(candidate)
for p in sorted(source_paths):add(p,'source/'+p.relative_to(ROOT).as_posix())
add_data('recipe-provenance.json',encode(projections))
def xml_info(path):
 d=ET.parse(path).getroot();cases=[]
 for c in d.findall('.//testcase'):
  assert not any(c.findall(x) for x in ['failure','error','skipped']),str(path)
  assert c.get('status')=='run' and c.get('result')=='completed',str(path)
  cases.append(dict(suite=c.get('classname'),name=c.get('name'),properties={p.get('name'):p.get('value') for p in c.findall('./properties/property')}))
 assert int(d.get('tests'))==len(cases) and int(d.get('failures'))==0 and int(d.get('errors'))==0
 return dict(tests=len(cases),failures=0,errors=0,skipped=0,cases=cases,xml=identity(path))
required=[FINAL_FREEZE]+[S/name/'final-validation.json' for name in ['common-cpu','cuda','vulkan','apple']]
missing=[str(p) for p in required if not p.is_file()]
xmls={'windows_cpu':S/'common-cpu/checks/attempt2/tests.xml','windows_cuda_local':S/'cuda/validation/static-and-runtime/tests.xml','windows_cuda_neighbors':S/'cuda/validation/neighbors/tests.xml','windows_vulkan_local':S/'vulkan/validation/static-and-runtime/tests.xml','windows_vulkan_neighbors':S/'vulkan/validation/neighbors/tests.xml'}
apple=load(S/'apple/final-validation.json') if (S/'apple/final-validation.json').is_file() else None
if apple:xmls['macos_apple']=verify_record(apple['final']['xml'])
missing += [str(p) for p in xmls.values() if not p.is_file()]
validation={name:xml_info(path) for name,path in xmls.items() if path.is_file()}
plan=dict(status='prepared_not_published',missing_final_evidence=missing,green_tests_from_actual_XML=sum(x['tests'] for x in validation.values()),members=len(entries),uncompressed_bytes=sum(map(len,entries.values())),source_count=len(source_paths),dependency_inventories=len(dependency_members),receipt_projections=len(projections),target=identity(RESEARCH.with_suffix('.json'))['path'].replace('research/ct-local-nvfp4-contract','correctness/ct-local-nvfp4-reference'),public_files_written=False)
if not PUBLISH:
 (S/'package-plan.json').write_bytes(encode(plan));print(json.dumps(plan,indent=2));raise SystemExit(0)
assert not missing,missing
assert {n:v['tests'] for n,v in validation.items()}==dict(windows_cpu=8,windows_cuda_local=2,windows_cuda_neighbors=4,windows_vulkan_local=2,windows_vulkan_neighbors=4,macos_apple=7)
assert sum(x['tests'] for x in validation.values())==27
for p in [S/'common-cpu/checks/attempt2/tests.result.json',S/'cuda/validation/static-and-runtime/result.json',S/'cuda/validation/neighbors/result.json',S/'vulkan/validation/static-and-runtime/result.json',S/'vulkan/validation/neighbors/result.json',verify_record(apple['final']['validation'])]:
 d=load(p);assert d.get('returncode',d.get('exit',d.get('exit_code')))==0,str(p)
 if 'skipped' in d:assert d['skipped'] in (0,[]),str(p)
finalfreeze=load(FINAL_FREEZE);finalrows=list(source_rows(finalfreeze));assert len({str(p).lower() for p,_ in finalrows})==32
report=dict(
 status='bounded_CT_local_dynamic_NVFP4_software_reference_verified',
 scope='Single-machine WindowsCPU/CUDA/Vulkan and macOSApple dense/grouped reference math, resource lifetime and selected-domain regressions. No checkpoint payload execution.',
 contract=dict(inputs='BF16A; original adjacent-low-first U8 packedE2M1W, logicalE4M3FN group16SF, independent positivefinite F32 rawWG/IG divisors; grouped adds IDs and perexpert metadata.',
  activation='BF16(absmax/6) then F32IGmultiply, SATFINITE nearest-evenE4 blockscale, exactzero->0.125; effective=F32(SF/IG); F32A/effective clamped[-6,6], explicit Float32 or BF16 input pre-round before E2M1 nearest-even, portableTorch sign then F32scale multiply andBF16 operand.',
  weight='F32(E4SF/rawWG), separate signedE2M1code multiply thenBF16 operand; code8 source arithmetic retains negativezero. BF16 operands precede backendF32 reduction/finalBF16.',
  resources='Existing execution paths and per-slot activation workspace, boundedWtiles, completeIDs before selectedmetadata addressing; mutablecurrentports reread, unselected invalidmetadata untouched. No newexecutor or NK/ENKfloatingbank.'),
 validation=validation,total_passed=27,final_source_freeze=identity(FINAL_FREEZE),
 backend_receipts={name:identity(S/name/'final-validation.json') for name in ['common-cpu','cuda','vulkan','apple']},
 source_counts=dict(root_final_unique=32,current_source_members=len(source_paths)),research=research,
 new_reference_case_counts=dict(per_backend_lifetime_submissions=32,per_backend_runtime_successes=44,per_backend_expected_failed_completions=24,cpu_additional_direct_alias_rejections=2),
 corrections=[
  'First CPU sharedweight_decode CXX failed C2270 because extracted free inferencehelpers retained memberconst. Root removed only those2const qualifiers; original failedsource, command/result/log and successfulfreshowner retained. No product numerical failure was observed.',
  'Apple firstprocess passed6/7: old ByteCarrier guard expected FP8Cast rejection despite the preceding package adding that numerical bridge. Test-only update now executes actualE4 Cast numeric witnesses and retains FP8Binary rejection. SameLocal math/oracle/product sources passed final7/7; do not call the staleguard a Local numerical failure.',
  'CUDA/Vulkan first link-helper metadata/path planning errors stopped before launching linker/GPU; scripts/errorreceipts retained separately. They are not compiler/linker/GPU failures.'
 ],
 limits=[
  'No originalcheckpoint tensorpayload, fullartifact/model importer, quality, throughput, nativehardwareW4A4 GEMM or deploymentaccumulator equivalence claim.',
  'Input pre-rounding is explicit arithmetic, not a model/producer whitelist. Finite inputs/scales may still generate legalInf/NaN intermediates; finalNaNs compared by class.',
  'Independent sparsewitnesses and finalBF16 checks do not certify everyinternalzero sign or identical arbitraryF32 reduction trees acrossbackends.',
  'Actual integer/grid/storage-buffer limits remain. Large4GiB completeexpertbanks, multi-span/catalogWeightSlots and allshard loading were not covered; opaque private allocations are unknown and OOM does not promise automatic re-selection.',
  'No Linux/build-all or separate validation-layer run claim. Originalsame-shader byte checks and source review supplement actualGPUtests.'
 ])
add_data('report-core.json',encode(report))
inventory=dict(schema='ct-local-nvfp4-reference-members-v1',members=[dict(member=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),original=provenance.get(n)) for n,b in sorted(entries.items())],note='All members except thisinventory; dependencyarrays preserved losslessly once per contenthash and referenced by compact receipts.')
add_data('inventory.json',encode(inventory));DEST.parent.mkdir(parents=True,exist_ok=True)
assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(),'Do not silently overwrite a publication.'
with zipfile.ZipFile(DEST.with_suffix('.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):
  info=zipfile.ZipInfo(name,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data,compresslevel=9)
with zipfile.ZipFile(DEST.with_suffix('.zip')) as z:
 assert z.testzip() is None;names=z.namelist();assert len(names)==len(set(names))==len(entries) and set(names)==set(entries)
 for name,data in entries.items():
  member_ok(name);actual=z.read(name);assert actual==data and hashlib.sha256(actual).hexdigest()==hashlib.sha256(data).hexdigest()
 for row in inventory['members']:
  b=z.read(row['member']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
report['archive']=dict(identity=identity(DEST.with_suffix('.zip')),members=len(entries),uncompressed_bytes=sum(map(len,entries.values())),inventory=dict(member='inventory.json',bytes=len(entries['inventory.json']),sha256=hashlib.sha256(entries['inventory.json']).hexdigest()),verification='CRC+everymember exact bytes/SHA; safe unique relative memberpaths; publicJSON archive/inventory identities verified.')
DEST.with_suffix('.json').write_bytes(encode(report));receipt=dict(report=identity(DEST.with_suffix('.json')),archive=identity(DEST.with_suffix('.zip')),tests=27,members=len(entries),source_counts=report['source_counts'],dependency_inventories=len(dependency_members),receipt_projections=len(projections))
(S/'package-receipt.json').write_bytes(encode(receipt));assert load(DEST.with_suffix('.json'))['archive']['identity']['sha256']==identity(DEST.with_suffix('.zip'))['sha256'];print(json.dumps(receipt,indent=2))
