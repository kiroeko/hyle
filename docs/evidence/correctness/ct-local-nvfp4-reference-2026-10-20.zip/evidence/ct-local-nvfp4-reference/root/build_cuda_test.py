from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';S=A/'ct-local-nvfp4-reference';out=S/'cuda/checks/test';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
spec=importlib.util.spec_from_file_location('local_cuda_test_build',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
recipe=A/'static-fp8-reference/cuda/checks/selection/static-test-identity.json';source=ROOT/'tests/graph_route_cuda/local_nvfp4_reference_test.cc';frozen=[b.identity(ROOT/p) for p in ['include/hyle/compute/model_ops.h','tests/compute_models/local_nvfp4_reference_fixture.h']]
command=b.host_command(c.read(recipe)['command'],source,'local-test',out);env,runtime=b.environment(command,[],out)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.save(out/'plan.json',dict(source=b.identity(source),recipe=b.identity(recipe),command=command,frozen=frozen,SDK=0,GPU=0))
c.execute('local-test-compile',command,env,out)
dep=out/'local-test-deps.json';data=c.read(dep)['Data'];paths=list(dict.fromkeys([data['Source'],*data['Includes']]))
assert all(b.same(x) for x in frozen)
c.save(out/'local-test-identity.json',dict(source=b.identity(source),object=b.identity(out/'local-test.obj'),recipe=b.identity(recipe),command=command,source_dependencies=b.identity(dep),dependencies=[b.identity(p) for p in paths]))
print('CUDA_LOCAL_TEST_READY',flush=True)
