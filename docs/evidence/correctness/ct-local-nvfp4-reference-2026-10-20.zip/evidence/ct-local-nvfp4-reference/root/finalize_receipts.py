from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';S=A/'ct-local-nvfp4-reference';R=S/'root'
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
rows=[S/'cuda/checks/attempt1'/n for n in ['cuda-provider-identity.json','nvfp4-provider-identity.json','nvfp4-kernel-identity.json']]+[S/'cuda/checks/test/local-test-identity.json',S/'common-cpu/checks/attempt2/weight-decode-identity.json']
verified=[]
for p in rows:
 v=load(p)
 for key in ['source','object']:
  actual=ident(Path(v[key]['path']));assert actual==v[key],(p,key)
 for old in v.get('dependencies',[]):
  path=Path(old['path'])
  if path.is_file() and path.is_relative_to(ROOT) and not path.is_relative_to(ROOT/'.scratch'):
   assert ident(path)['sha256']==old['sha256'],(p,path)
   verified.append(str(path))
processes=[]
for tag in ['static-and-runtime','neighbors']:
 p=S/'cuda/validation'/tag;result=load(p/'result.json');x=E.parse(p/'tests.xml').getroot();assert result['returncode']==0 and x.get('failures')=='0' and not x.findall('.//skipped')
 processes.append(dict(tag=tag,command=ident(p/'run-plan.json'),result=ident(p/'result.json'),xml=ident(p/'tests.xml'),tests=int(x.get('tests')),skipped=0))
base=load(S/'cuda/tests/link-plan.json')
for row in base['inputs']:assert ident(Path(row['path']))==row
save(S/'cuda/final-validation.json',dict(status='bounded_local_NVFP4_dense_and_selected_grouped_reference_verified',processes=processes,total_passed=6,skipped=0,image=ident(S/'cuda/tests/local-nvfp4.exe'),link_plan=ident(S/'cuda/tests/link-plan.json'),actual_inputs=len(base['inputs']),compiled_owners=[ident(p) for p in rows],workspace_dependency_entries_checked=len(verified),unique_workspace_dependencies=len(set(verified)),build=dict(CXX=3,NVCC=1,links=1,SDK=0,actual_GPU_processes=2,all_compiler_linker_processes_exit0=True,shared_schema_compiled_once_by_CPU=True),selection='Math contract and dense/grouped row regimes resolve the actual quantize/linear function pointers in cold prepare; cudaFuncGetAttributes materializes precisely those functions before capture. Submit uses the immutable pointers and original status/queue/packed-row mechanism.',math='Original ModelOpt constexpr branches retained. Local activation uses BF16(max/6), F32 IGmultiply, E4 SATFINITE exactzero->.125, direct F32 SF/IG, clamped ratio and explicit FP4 pre-rounding; signed Torch zero convention. W SF/WG direct division and signed code8 precede BF16 operand. F32 native reduction and BF16 result.',history=[dict(classification='Link helper setup path typo returned FileNotFound before creating link directory or starting linker/GPU; corrected baseline to existing static package. Compiler and numerical runs were unaffected.',before_script=ident(R/'revisions/link-setup-before-path-fix.py'))],limits=['No checkpoint tensor payload/full artifact/model execution or measured throughput/quality/peak memory.','No native FP4 GEMM equivalence, Linux, installed-consumer or whole bank guarantee.','Original W stays packed; caller workspace is2*selected_rows*K, not a dense expert bank. Catalog/working-set segmented expert bridge remains delivery3.']))
paths=[
'include/hyle/compute/model_ops.h','src/compute_ops/weight_decode.cc',
'src/compute_provider_native/native_provider.cc','src/compute_provider_native/nvfp4.cc','tests/compute_models/local_nvfp4_reference_fixture.h','tests/graph_route_cpu/local_nvfp4_reference_test.cc','tests/graph_route_cpu/CMakeLists.txt',
'src/compute_provider_cuda/cuda_provider.cc','src/compute_provider_cuda/nvfp4_provider.cc','src/compute_provider_cuda/nvfp4_kernel.cu','src/compute_provider_cuda/nvfp4_kernel.h','tests/graph_route_cuda/local_nvfp4_reference_test.cc','tests/graph_route_cuda/CMakeLists.txt',
'src/compute_route_vulkan/vulkan_nvfp4.cc','src/compute_route_vulkan/vulkan_operations.cc','src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/build_shaders.py','src/compute_route_vulkan/shaders/nvfp4.comp','tests/graph_route_vulkan/local_nvfp4_reference_test.cc','tests/graph_route_vulkan/CMakeLists.txt',
'src/compute_route_apple/apple_nvfp4.h','src/compute_route_apple/apple_nvfp4.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_operations.cc','tests/graph_route_apple/local_nvfp4_reference_test.cc','tests/graph_route_apple/nvfp4_reference_test.cc','tests/graph_route_apple/CMakeLists.txt',
'src/compute_shader_shared/nvfp4_f32.h','src/compute_provider_cuda/packed_rows.cuh','include/hyle/simd/dtype.h','tests/compute_models/nvfp4_reference_fixture.h','tests/compute_models/grouped_nvfp4_reference_fixture.h']
assert len(paths)==len(set(paths))
# Final Apple source is already corrected; actual frozen source equality is
# separately proven by its final receipt before package publication.
save(R/'final-source-freeze.json',dict(status='current_product_and_test_sources',files=[ident(ROOT/p) for p in paths],unique_files=len(paths),schema_layout='Existing Operation and NativePlan layout unchanged; new local custom descriptor classes are distinct. Private CUDA Program is recompiled in its two actual owners.'))
print('CUDA6green;actualinputs',len(base['inputs']),'deps',len(verified),len(set(verified)),'frozen',len(paths))
