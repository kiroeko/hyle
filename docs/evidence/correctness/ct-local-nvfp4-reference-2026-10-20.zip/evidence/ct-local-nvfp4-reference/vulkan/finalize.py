from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
S = ROOT / '.scratch/architecture-refactor-2026-10-18/ct-local-nvfp4-reference/vulkan'


def load(path):
    return json.loads(Path(path).read_bytes())


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def verify(record):
    actual = identity(record['path'])
    assert actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256'], record['path']
    return actual


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf8')


initial = load(S / 'source-freeze.json')
for record in initial['files']:
    verify(record)
    snapshot = verify(record['snapshot'])
    assert snapshot['sha256'] == record['sha256']
common = [initial[name] for name in ('public_contract', 'shared_F32_math', 'fixture')]
for record in common:
    verify(record)
compiled = load(S / 'compiled-identities.json')
dependencies = {}
for receipt in compiled['receipts']:
    verify(receipt)
    data = load(receipt['path'])
    for record in (data['source'], data['object'], *data['dependencies']):
        key = str(Path(record['path'])).lower()
        if key in dependencies:
            assert (dependencies[key]['bytes'], dependencies[key]['sha256']) == (record['bytes'], record['sha256'])
        dependencies[key] = record
for record in dependencies.values():
    verify(record)
shaders = load(S / 'checks/shader-artifacts.json')
for record in shaders['artifacts']:
    verify(record['artifact'])
assert len(shaders['artifacts']) == 19 and shaders['new'] == 2 and shaders['reused'] == 17
for proof in shaders['old_ModelOpt_byte_equal']:
    verify(proof['previous'])
    verify(proof['rebuilt'])
    assert Path(proof['previous']['path']).read_bytes() == Path(proof['rebuilt']['path']).read_bytes()
assert len(shaders['old_ModelOpt_byte_equal']) == 2
processes = []
for tag, expected in (('static-and-runtime', 2), ('neighbors', 4)):
    directory = S / 'validation' / tag
    result = load(directory / 'result.json')
    assert result['returncode'] == 0 and result['skipped'] == 0
    plan = load(directory / 'run-plan.json')
    assert Path(plan['command'][0]) == Path(compiled['image']['path'])
    document = ET.parse(directory / 'tests.xml').getroot()
    cases = []
    for case in document.findall('.//testcase'):
        assert not any(case.findall(kind) for kind in ('failure', 'error', 'skipped'))
        assert case.attrib.get('status') == 'run' and case.attrib.get('result') == 'completed'
        cases.append(dict(suite=case.attrib['classname'], name=case.attrib['name'],
            properties={p.attrib['name']: p.attrib['value']
                        for p in case.findall('./properties/property')}))
    assert int(document.attrib['tests']) == expected == len(cases)
    assert int(document.attrib['failures']) == 0 and int(document.attrib['errors']) == 0
    processes.append(dict(tag=tag, tests=expected, failures=0, skipped=0, cases=cases,
        elapsed_seconds=result['elapsed_seconds'],
        evidence={name: identity(directory / name) for name in (
            'run-plan.json', 'result.json', 'tests.xml', 'stdout.txt', 'stderr.txt')}))
verify(compiled['image'])
freeze = dict(status='Windows_Vulkan_local_NVFP4_actual6pass0skip', files=initial['files'],
    common_headers=common, compiled_identity_receipt=identity(S / 'compiled-identities.json'),
    actual_source_object_dependency_entries_checked=len(dependencies), mismatches=0,
    shader_artifacts=identity(S / 'checks/shader-artifacts.json'),
    integration=initial['integration'], resources=initial['resources'],
    no_product_or_fixture_correction_after_initial_successful_compiles=True)
save(S / 'final-source-freeze.json', freeze)
report = dict(status='Vulkan_local_NVFP4_dense_grouped_and_original_ModelOpt_neighbors_passed',
    execution=dict(actual_GPU=True, executed_by='root agent', GPU_processes=2,
                   tests=6, failures=0, skipped=0, this_owner_GPU_processes=0),
    source_freeze=identity(S / 'final-source-freeze.json'),
    image=compiled['image'], compiled_identities=identity(S / 'compiled-identities.json'),
    actual_link_inputs=len(load(S / 'checks/link-plan.json')['inputs']),
    build=dict(product_CXX=4, wrapper_CXX=1, new_GLSL=2, old_GLSL_byte_equal_checks=2,
               linker_processes=1, compile_shader_link_failures=0, SDK=0,
               helper_prelink_metadata_lookup_failure=identity(S / 'checks/link-plan-first-error.json')),
    processes=processes, shader_artifacts=identity(S / 'checks/shader-artifacts.json'),
    shader_scope='Two new local dense/grouped variants; the two original ModelOpt variants were rebuilt and proved byte-identical. All17 old actual SPIRV inputs are reused with checked identities.',
    arithmetic='BF16_RNE(F32(absmax/6)), F32 IG multiply, E4 SATFINITE RNE with only-zero0.125, direct F32 SF/IG; clamp A/scale then optional BF16 before E2M1 ties/sign(v), BF16 operand. W code8=-0 and direct F32 SF/WG before code multiply and BF16. Old ModelOpt math remains independent.',
    resources='Existing native Program/status/dense-grouped phases and actual aliases/retirement. A only2*R*K BF16 temporary; packed original W/SF/globals, no dense W bank or new executor. Every ID is checked in a preceding dispatch before selected expert addressing.',
    limits=['Bounded synthetic primitive carriers only; no checkpoint tensor payload, full model/importer/quality/performance, Linux or hardware FP4 GEMM equivalence claim.',
            'Dense and selected-grouped A1/AS/real zero-slot-stride journeys are covered, but no512 independent-fragment working-set or single4GiB packed bank has been validated.',
            'Per-descriptor device maxStorageBufferRange, private U32 byte origins and generic INT32 planner admission remain distinct real constraints. Small-E tests do not close delivery3 segmented/selected-bank resource integration.',
            'Native private opaque allocations remain unknown; runtime OOM does not automatically reselect. No validation-layer run or measured memory/performance improvement is claimed.',
            'F32 dot reduction is backend-specific; sparse independent witnesses avoid asserting identical arbitrary reduction sums. Failed Completion outputs remain unusable without rollback.'])
save(S / 'final-validation.json', report)
print(json.dumps(dict(final_validation=identity(S / 'final-validation.json'),
    final_source_freeze=identity(S / 'final-source-freeze.json'), tests=6,
    checked=len(dependencies)), indent=2))
