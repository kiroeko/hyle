from pathlib import Path
import hashlib,json
R=Path.cwd();S=Path(__file__).resolve().parent;C=S/'checks/attempt2'
def identity(p):
 p=Path(p);b=p.read_bytes()
 try:name=p.relative_to(R).as_posix()
 except ValueError:name=str(p)
 return dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def same(row):
 p=Path(row['path']);p=p if p.is_absolute() else R/p;a=identity(p);assert a['sha256']==row['sha256'] and a['bytes']==row['bytes'],str(p)
freeze=json.loads((S/'source-freeze.json').read_text());[same(x) for x in freeze['files']+freeze['root_shared']]
link=json.loads((C/'link-plan.json').read_text());[same(x) for x in link['inputs']]
records=[json.loads((C/(x+'-identity.json')).read_text()) for x in ['weight-decode','native-provider','nvfp4','test']]
for rec in records:
 for x in [rec['source'],rec['object'],*rec['dependencies']]:same(x)
summary=json.loads((C/'summary.json').read_text());assert summary['passed'] and summary['cases']==8
j={
 'status':'WindowsCPU targeted correctness passed; no GPU/build claims for sibling backends.',
 'source_freeze':identity(S/'source-freeze.json'),'fixture_freeze':identity(S/'fixture-source-freeze.json'),
 'source_scope':[x['path'] for x in freeze['files']],'root_shared_owners':[x['path'] for x in freeze['root_shared']],
 'math_and_resources':[
  'Cold function-template submit pointer selects originalModelOpt/localFloat32/localBFloat16. NativePlan layout/executor unchanged; originalModelOpt expressions retained in their constexpr branch.',
  'CT local uses volatileF32 divide by runtime6 thenBF16RNE, F32 IGmultiply, SATFINITE E4, exactzero->0.125, directF32 global division, explicit FP4 input pre-round, portableTorch sign, BF16operands/F32dot/BF16result.',
  'W is directF32 SF/rawWG then signedE2M1code multiply andBF16. Source code8 retains-0. Tests compare finite finalBF16 andNaNclass, not everyinternalzero or allreduction trees.',
  'Original mappings, allIDs-before-addressing, selected-only metadata validation and write-overlap checks retained. Caller workspace2*R*K; bounded16decodedWtile; no NK/ENKfloatbank or hotallocation.'
 ],
 'results':{'cases':8,'passed':8,'failed':0,'skipped':0,'new_lifetimes_submits':32,'new_runtime_successes':44,'new_expected_failed_completions':24,'new_direct_alias_rejections':2,'old_ModelOpt_neighbor_cases':5,'summary':identity(C/'summary.json'),'xml':identity(C/'tests.xml'),'run_command':identity(C/'tests.command.json'),'run_result':identity(C/'tests.result.json')},
 'counts_actual_this_agent':{'CXX_attempted':5,'CXX_succeeded':4,'CXX_failed':1,'successful_product_CXX':3,'successful_test_CXX':1,'links':1,'CPU_processes':1,'NVCC':0,'SDK_rebuilds':0,'GPU_processes':0},
 'initial_failure':{'kind':'Root-extracted free inference helpers retained memberconst: C2270 before otherowners/test compiled; root removed only2const qualifiers.','command':identity(S/'checks/attempt1/weight-decode-compile.command.json'),'result':identity(S/'checks/attempt1/weight-decode-compile.result.json'),'stdout':identity(S/'checks/attempt1/weight-decode-compile.stdout.log'),'failed_source_verified_against_original_freeze_SHA':identity(S/'revisions/before-free-helper-fix/src/compute_ops/weight_decode.cc'),'before_freeze':identity(S/'revisions/before-free-helper-fix/source-freeze.json')},
 'link_closure':{'link_plan':identity(C/'link-plan.json'),'actual_input_count':len(link['inputs']),'all_input_bytes_and_SHA_match':True,'base':link['base'],'replacement_count':len(link['replacements']),'new_owner_count':len(link['new_owners']),'image':identity(C/'cpu.exe')},
 'objects':[{'identity':identity(C/(name+'-identity.json')),'source':rec['source'],'object':rec['object'],'dependencies_count':len(rec['dependencies'])} for name,rec in zip(['weight-decode','native-provider','nvfp4','test'],records)],
 'coverage':[
  'DenseM2N3K2048 bounded traversal; smallM2N3K32 dynamicruntime; groupedshared/perSlot/realzeroSlotStride+tokenpadding/E17; bothFP4input modes; repeatedIDs and twoA/IDbyteupdates; twoindependent slots.',
  'Release original bank/constant handles, Graph/Executable before executing preparedslots. Oldresults gate same-slot submission, survive other-slot update and Invocation destruction.',
  'Dynamic invalidA/SF/WG/IG and lastIDs; invalidunselectedexpert metadata is ignored. FailedInvocation terminal, sameExecutable creates fresh recoveryInvocation.',
  'Direct workspace aliasesA for bothmodes: failedCompletion and allinput/poisonoutput bytes unchanged.',
  'Independent enumerated oracle locksFP4pre-round difference and directrawglobal divisionBF16visible3a01 witness. No threshold relaxed.'
 ],
 'limitations':['No checkpointpayload/fullmodel/4GiBexpertbank/throughput/quality tested.','No hardwareW4A4 GEMM equivalence.','No wholeIEEE/accumulator tree/internalzero-sign certification.','Only WindowsCPU8cases; otherplatform actuals recorded by their owners.']
}
(S/'final-validation.json').write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(identity(S/'final-validation.json')))
