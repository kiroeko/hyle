from pathlib import Path
import importlib.util,json,sys,argparse,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
G=Path(__file__).resolve().parent;A=G.parents[1];ROOT=A.parents[1];S=G/'checks/attempt2'
spec=importlib.util.spec_from_file_location('local_cpu_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'static-fp8-reference/common-cpu/checks/forced-native-provider/link-plan.json';READY=G/'source-freeze.json'
FILTER='CpuLocalNvfp4Reference*.*:CpuNvfp4ReferenceGraph.*:CpuGroupedNvfp4ReferenceGraph.*:NativeNvfp4.*'
def same(row):
 p=Path(row['path']);p=p if p.is_absolute() else ROOT/p;a=b.identity(p);assert a['sha256']==row['sha256'] and a['bytes']==row['bytes'],str(p)
def frozen():
 d=c.read(READY)
 for row in d['files']+d['root_shared']:same(row)
def proposal():
 base=c.read(BASE);meta=h.metadata({'cpu':base});rows=[]
 for tag,source in [('weight-decode','src/compute_ops/weight_decode.cc'),('native-provider','src/compute_provider_native/native_provider.cc'),('nvfp4','src/compute_provider_native/nvfp4.cc')]:
  matches=[(x,meta.get(c.key(x['path']))) for x in base['inputs'] if c.key(meta.get(c.key(x['path']),{}).get('source_path',''))==c.key(ROOT/source)];assert len(matches)==1,(source,len(matches));old,rec=matches[0];cmd=b.host_command(rec['command'],ROOT/source,tag,S);rows.append(dict(tag=tag,source_path=str(ROOT/source),old_object=old,recipe=b.identity(rec['recipe']),command=cmd,object_path=str(S/(tag+'.obj'))))
 recipe=A/'static-fp8-reference/common-cpu/checks/forced-native-provider/test-identity.json';rec=c.read(recipe);tag='test';source='tests/graph_route_cpu/local_nvfp4_reference_test.cc';cmd=b.host_command(rec['command'],ROOT/source,tag,S);rows.append(dict(tag=tag,source_path=str(ROOT/source),old_object=None,recipe=b.identity(recipe),command=cmd,object_path=str(S/(tag+'.obj'))))
 return dict(base=b.identity(BASE),source_freeze=b.identity(READY),compile=rows,counts=dict(product_CXX=3,test_CXX=1,links=1,NVCC=0,SDK=0,GPU=0),filter=FILTER)
def compileall():
 frozen();plan=proposal();c.save(S/'plan.json',plan)
 for row in plan['compile']:
  path=S/(row['tag']+'-identity.json')
  if path.exists():
   rec=c.read(path);same(rec['source']);same(rec['object']);continue
  assert not (S/(row['tag']+'-compile.result.json')).exists(),'preserve first failure'
  frozen();env,_=b.environment(row['command'],[],S);c.execute(row['tag']+'-compile',row['command'],env,S)
  dep=S/(row['tag']+'-deps.json');d=c.read(dep)['Data'];c.save(path,dict(source=b.identity(row['source_path']),object=b.identity(row['object_path']),command=row['command'],recipe=row['recipe'],old_object=row['old_object'],source_dependencies=b.identity(dep),dependencies=[b.identity(x) for x in dict.fromkeys([d['Source'],*d['Includes']])]))
  print('COMPILED',row['tag'],flush=True)
def link():
 assert not (S/'link.result.json').exists();frozen();base=c.read(BASE);records=[c.read(S/(r['tag']+'-identity.json')) for r in c.read(S/'plan.json')['compile']];swaps={c.key(r['old_object']['path']):r['object'] for r in records if r['old_object']};extra=[r['object'] for r in records if not r['old_object']];inputs=[swaps.get(c.key(r['path']),r) for r in base['inputs']]+extra
 for row in inputs:same(row)
 image=S/'cpu.exe';command=[swaps[c.key(x)]['path'] if c.key(x) in swaps else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))];command += [r['path'] for r in extra]+['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.save(S/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(BASE),replacements=[dict(before=r['old_object'],after=r['object']) for r in records if r['old_object']],new_owners=extra));env,runtime=b.environment(command,[r['path'] for r in inputs],S);c.save(S/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('link',command,env,S);c.save(S/'image.json',b.identity(image))
def run():
 assert not (S/'tests.result.json').exists();lp=c.read(S/'link-plan.json');image=c.read(S/'image.json');same(image);env,_=b.environment(lp['command'],[r['path'] for r in lp['inputs']],S)
 try:c.execute('tests',[image['path'],'--gtest_filter='+FILTER,'--gtest_output=xml:'+str(S/'tests.xml')],env,S)
 finally:
  if (S/'tests.xml').exists():
   cases=ET.parse(S/'tests.xml').findall('.//testcase');failed=[x.attrib for x in cases if x.find('failure') is not None];skipped=[x.attrib for x in cases if x.find('skipped') is not None];c.save(S/'summary.json',dict(passed=not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,names=[x.get('classname')+'.'+x.get('name') for x in cases],properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[p.attrib for p in x.findall('./properties/property')]) for x in cases],counts=c.read(S/'plan.json')['counts'],image=image,link_plan=b.identity(S/'link-plan.json')))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['compile','link','run']);args=p.parse_args();S.mkdir(parents=True,exist_ok=True);(S/'tmp').mkdir(exist_ok=True);{'compile':compileall,'link':link,'run':run}[args.mode]()
