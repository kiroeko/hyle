"""Actual existing Qwen directory/capacity test TU, retained static closure."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
base=R/'.scratch/qwen35-unsloth-mtp-20261024/prefix-check1'
source=R/'tests/tools/qwen_prefix_cache_test.cc'
inputs=[source,R/'engine/models/qwen35/prefix_cache.h',R/'engine/inference/prefix_directory.h',
    R/'engine/inference/token_prefix.h']
before=[b.pin(p)for p in inputs]
original=b.args(base/'compile/command.json');command=[];skip=False
for word in original:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    if word.lower().startswith(('/fo','/fd'))or word.lower().endswith('.cc'):continue
    command.append(word)
folder=D/'compile'
command+=['/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/'prefix.obj')]
env=b.environment(command[0]);b.execute(command,folder,env,60)
deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
assert not any(p.is_relative_to(R/'.scratch')for p in deps),'Unexpected private header in canonical host check'
b.save(D/'actual-dependencies.json',[b.pin(p)for p in deps if p.is_relative_to(R)])
link=[]
old=str(base/'compile/prefix.obj')
original_link=b.args(base/'link2/command.json');assert original_link.count(old)==1
for word in original_link:
    if word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:')):continue
    link.append(str(folder/'prefix.obj')if word==old else word)
link+=['/SUBSYSTEM:CONSOLE','/OUT:'+str(D/'link/checks.exe')]
b.execute(link,D/'link',env,60)
b.execute([str(D/'link/checks.exe')],D/'run',env,30)
assert before==[b.pin(p)for p in inputs],'Canonical directory inputs changed during check'
lines=(D/'run/stdout.log').read_text().splitlines();assert len(lines)==17 and all(x.startswith('PASS ')for x in lines)
b.save(D/'summary.json',dict(state='passed',scope='Existing actual Qwen host capacity/prefix directory test source',
    source_pins=before,checks=lines,compile=b.read(folder/'process.json'),
    link=b.read(D/'link/process.json'),run=b.read(D/'run/process.json'),
    SDK_builds=0,GPU_runs=0,HTTP=0,models=0))
files=[dict(path=str(p),bytes=p.stat().st_size)for p in D.rglob('*')
    if p.is_file()and p.suffix.lower()in{'.obj','.exe','.lib','.exp','.pdb','.dll'}]
b.save(D/'cleanup-candidates.json',dict(files=files,count=len(files),
    logical_bytes=sum(p['bytes']for p in files),performed=False))
print('Existing host contracts plus one typed payload case passed (17); original static caches retained.')
