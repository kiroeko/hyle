"""One current typed-directory consumer using retained reports and native cache."""
from pathlib import Path
import importlib.util,shutil,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
PREVIOUS=R/'.scratch/inference-request-window-20261024/regression'
spec=importlib.util.spec_from_file_location('finite_regression',
    R/'.scratch/inference-batch-indices-20261024/regression/check.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.D,r.PREVIOUS=D,PREVIOUS;b=r.b
def prepare():
    r.require(b.pin(PREVIOUS/'summary.json')['sha256']==
        '1657afb7058330711946358b806710232d9db62bcd608a888dfb270082840707',
        'Previous actual finite regression changed')
    target=D/'reference';target.mkdir(parents=True,exist_ok=False)
    b.save(target/'reports.json',b.read(PREVIOUS/'summary.json')['reports'])
    for source,name in [(PREVIOUS/'summary.json','previous-summary.json'),
            (PREVIOUS/'run/stderr.log','stderr.log'),
            (r.BASE/'current4/link/command.json','link-command.json'),
            (r.BASE/'current4/link/pins.json','link-pins.json')]:shutil.copyfile(source,target/name)
    shutil.copyfile(PREVIOUS/'probe.cc',D/'probe.cc')
    b.save(D/'baseline-pins.json',dict(previous=b.pin(PREVIOUS/'summary.json'),
        probe=b.pin(D/'probe.cc'),reports=b.pin(target/'reports.json'),
        stderr=b.pin(target/'stderr.log'),
        fixture=[b.pin(p)for p in r.FIXTURE.glob('*')if p.is_file()],
        closure=dict(route=b.pin(r.BASE/'native-program-fixed/archive/route.lib'),
            native_region=b.pin(r.BASE/'native-region-fixed2/compile/unit.obj')),
        scope='One unchanged A-only actual consumer. Shared typed directory with original Qwen payload/validation; no old/GLM/full-model rerun.',
        SDK_builds=0,HTTP=0))
if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':r.freeze(sys.argv[2],sys.argv[3])
    else:{'build':r.build,'run':r.run,'finalize':r.finalize}[action]()
