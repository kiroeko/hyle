from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf8'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,
    sha256=hashlib.sha256(p.read_bytes()).hexdigest())
host=read(D/'host/summary.json');qwen=read(D/'qwen-regression/proof-summary.json')
glm=read(D/'verification/proof-summary.json')
assert host['state']=='passed' and len(host['checks'])==17
assert qwen['state']=='passed' and not qwen['differences']
assert glm['passed'] and glm['functional_result']['tests']==1 and not glm['functional_result']['skips']
sources=read(D/'after-pins.json')['files']
for p in sources:
    current=pin(R/p['path']);assert all(current[k]==p[k]for k in ['path','bytes','sha256'])
out=R/'docs/evidence/correctness/inference-typed-prefix-directory-2026-10-24.json'
archive=out.with_suffix('.zip');assert not out.exists() and not archive.exists()
names=['before-pins.json','after-pins.json','source-only.json','changes.patch','independent-review.md',
    'publish.py','host/check.py','host/summary.json','host/actual-dependencies.json','host/cleanup-candidates.json',
    'qwen-regression/check.py','qwen-regression/proof-summary.json','qwen-regression/proof.zip',
    'qwen-regression/cleanup-candidates.json','verification/proof-summary.json','verification/proof.zip',
    'verification/publication.json','verification/cleanup-candidates.json',
    'glm-implementation/changes.patch','glm-implementation/implementation-review.md','glm-implementation/pins.json']
files=[D/n for n in names]
files += [p for p in (D/'host').rglob('*')if p.is_file()and p.suffix in {'.json','.log'}and p not in files]
files += [R/p['path']for p in sources if p['path']!='engine/models/qwen35/main.cc']
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in files:z.write(p,p.relative_to(D).as_posix()if p.is_relative_to(D)else'source/'+p.relative_to(R).as_posix())
result=dict(state='passed',date='2026-10-24',
    scope='Shared typed radix/LRU/pin directory and request-window adaptation with original Qwen Snapshot/replay and a real GLM Pro StateVersion suffix component.',
    changes=['One typed payload per directory entry; no model state container, owner inventory or second radix implementation.',
        'Original finite E+1 entries/2E+2 nodes and post-insert victim pruning; nothrow payload operations; failed publication does not consume rvalue payload.',
        'Qwen keeps complete Snapshot/replay validation and canonical version identity; callers consume payload directly.',
        'GLM uses actual complete StateVersion, independent new-request pending/RNG and historical same-request restore; original pools and budget unchanged.'],
    sources=sources,GLM_source=pin(R/'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'),
    source_checks=read(D/'source-only.json'),independent_review=pin(D/'independent-review.md'),
    host=dict(checks=host['checks'],compile=host['compile'],link=host['link'],run=host['run']),
    qwen=dict(report_count=qwen['report_count'],differences=qwen['differences'],
        added_fields=qwen['added_report_fields'],grouping=qwen['request_groups']['counts'],
        late_IO_failures=qwen['late_IO_failures_observed'],
        process={k:qwen[k]for k in ['compile','reporting_compile','link','run']},
        proof=pin(D/'qwen-regression/proof-summary.json')),
    GLM=glm,
    limits=['Qwen actual integration uses retained tiny A-only Vulkan reports; no new full-model/GDN/mixed/platform-matrix coverage.',
        'GLM cache domain fixes the exact original-role initial StateVersion/upstream fixture. Key covers its consumed suffix only; no arbitrary GLM prompt prefill or whole-model claim.',
        'N1 is the request window admission bound. Actual retained StateStore versions, candidate metadata and old readers remain separately budgeted.',
        'The 24-byte added backing peak is an accounted functional-state change, not a physical GPU/RSS or throughput benchmark. No quality/TPS claim.'],
    cleanup=dict(exact_files=13,logical_bytes=264922344,private_DLL_hardlinks=2,
        original_cache_and_native_closures_retained=True,performed=False),
    archive=pin(archive))
out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps(dict(evidence=pin(out),archive=pin(archive))))
