# Independent typed-prefix review

Result: no concrete defect found in this bounded source pass. No product changes, build, execution or HTTP performed by this reviewer. This is not a claim that the whole inference engine is complete.

Reviewed frozen sources:
- `engine/inference/prefix_directory.h` SHA256 `5161c250059bf9a02dffbcdfcfba2b1c4292d11f741d3decf59568644fae1e9c`.
- `engine/inference/token_prefix.h` SHA256 `fdc43b99c1fb398cd968e1047a26269f89deb6e0e5e4b45161161f20b531f7ba`.
- `engine/models/qwen35/prefix_cache.h` SHA256 `01ae750cd254085f9a59f32ad6a3b3ba6ecbb8ead9afe059a1049f2156860b29`.
- Actual Qwen Snapshot/VersionRef contracts, version-admission consumers and existing prefix test source were read for integration context. The review excludes this reviewer's new GLM adapter.

Ownership and hits:
- Only an occupied Entry owns a typed payload. Nodes own token plans, not another state owner table. A Hit copies that same payload's real ownership and pins its Entry; a default-valued payload remains a valid occupied hit.
- Replacement and eviction reject a pinned Entry before payload assignment. Therefore `complete_length()` reads a stable node depth for the Hit's lifetime.
- Hit move transfers one pin; move assignment first releases its old pin, then takes the source. Empty/moved/reset Hits have no owner and length0. Reset clears the copied payload and releases exactly one original pin.
- Directory destruction before outstanding Hits is explicitly unsupported; the API remains single-owner and synchronous. These are existing finite lifecycle prerequisites, not a new parallel server contract.

Publication and finite storage:
- Payload default/copy/move/assignment/destruction are statically required nothrow. Domain comparison and node/LRU mutations use finite trivial/index/refcount operations.
- Invalid input, pinned replacement and no-evictable-victim decisions precede forwarding the payload. The const-reference source stays intact; an rvalue source is consumed only once the actual replacement/insertion commits.
- Stable E payloads need at most2E radix nodes including domain roots. Inserting a same-domain split adds at most2 nodes; a new domain adds root+leaf. E+1 Entry slots and2E+2 nodes therefore cover the transient insertion before pruning the victim.
- Domains reserve E+1 capacity; entry/node freelists reserve their full cold arrays. Insert, replacement, split, domain creation and eviction cannot require a hot vector growth on valid operations.
- Victim selection precedes insertion, but unlink/prune use current links after touch. An ancestor victim with one surviving child merges that child's original TokenPlan edge; a node with a payload or multiple children remains. No synthetic split state becomes a hit.

Token and Qwen contracts:
- Factory-created TokenPlans own IDs, exact prefix hashes and original chunk checkpoints. Lookup compares actual IDs, so hash collisions cannot manufacture a directory hit. Published plans must stay immutable; changing an escaped mutable alias violates the established prerequisite.
- The Qwen wrapper preserves complete nonempty Snapshot checks and exact replay chunk coverage before publication. Lookup rechecks actual model/math, pending and complete length, and fails closed if its immutable Snapshot prerequisite is broken.
- There is no compatibility scan for a mutated Snapshot. Legitimate immutable callers retain the original exact token/domain semantics.
- `retains` compares canonical `state_identity()`, preserving sampling-only wrappers as one evaluated state version. Admission still counts actual VersionRefs and external request owners; directory aliases/Hit copies neither create a version nor authorize exclusive writes.
- Qwen imports the actual replay prefix and moves the hit Snapshot into the normal session API; it drops the Hit before later version-admission gates. Existing leases, native retirement, pending/RNG restore and new-request sampling remain model responsibilities.
- Shared token/directory headers have no Qwen/model include or Compute/provider dependency. Typed payload validity belongs to each model adapter.

Finite completion boundary:
- Root reports the existing17host checks and eight actual tiny Qwen reports passed; this review read their relevant test contracts without rerunning them or creating a matrix.
- The generic directory/Qwen extraction has no remaining concrete blocker found here. The separately assigned real GLM StateHead adapter case must reach its actual terminal result before that demonstration can be called verified.
