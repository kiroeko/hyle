from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('process', R / '.scratch/inference-program-identity-20261029/build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); b.W = W
read, save, pin, exact = b.read, b.save, b.pin, b.exact

def receipt(name):
    result = read(W / 'compile' / name / 'receipt.json')
    exact(result['object'])
    for item in result['source_identities']: exact(item)
    return result

def main():
    plan = read(W / 'plan.json')
    action, name = sys.argv[1:3]
    attempt = sys.argv[3] if len(sys.argv) > 3 else 'attempt1'
    if action == 'compile':
        folder = W / 'compile' / name
        b.execute(plan['units'][name]['compile'], folder / attempt, 240)
        deps = read(folder / 'dependencies.json')['Data']
        paths = sorted({Path(p).resolve() for p in [deps['Source'], *deps['Includes']] if Path(p).is_relative_to(R)})
        save(folder / 'receipt.json', dict(object=pin(folder / 'unit.obj'), process=pin(folder / attempt / 'process.json'), source_identities=[pin(p) for p in paths]))
    elif action == 'link':
        receipt(name)
        for item in plan['retained']: exact(item)
        exact(plan['runtime']); exact(plan['sdk'])
        for unit in read(plan['sdk']['path'])['engine_consumers']:
            for item in unit['source_identities']: exact(item)
        b.execute(plan['units'][name]['link'], W / 'link' / name / attempt, 180)
        save(W / ('ready-' + name + '.json'), pin(W / 'bin' / (name + '.exe')))
        save(W / 'link' / name / attempt / 'image.json', pin(W / 'bin' / (name + '.exe')))
    elif action == 'run':
        unit, *args = plan['cases'][name]
        receipt(unit)
        image = read(W / ('ready-' + unit + '.json')); exact(image)
        folder = W / 'runs' / name / attempt
        save(folder / 'image.json', image)
        b.execute([image['path'], *args], folder, 300)
        result = read(folder / 'stdout.log'); assert result['status'] == 'PASS'
        save(folder / 'report.json', result)
        print('PASS', name)
    else: raise ValueError(action)

if __name__ == '__main__': main()
