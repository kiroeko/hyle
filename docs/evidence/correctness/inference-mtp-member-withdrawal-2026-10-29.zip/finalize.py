from pathlib import Path
import importlib.util
import json
import shutil
import subprocess
import sys
import zipfile
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read, save, pin, exact = b.read, b.save, b.pin, b.exact
plan = read(W / 'plan.json')
for item in plan['retained']: exact(item)
sources = [R / 'engine/models/qwen35/main.cc', *[R / 'tests/tools' / (name + '.h') for name in (
    'qwen_generation_wave_case', 'qwen_history_control_case', 'qwen_mtp_e4_case',
    'qwen_mtp_mixed_lag_case', 'qwen_natural_logits_control_case')]]
for name in ('qwen', 'ordinary'): b.receipt(name)
source_freeze = [pin(path) for path in sources]
save(W / 'source-freeze.json', source_freeze)
current_base = dict(schema='hyle.mtp-member-withdrawal.current-link-base.v1',
    base=plan['base'], compile=plan['units']['qwen']['compile'], link=plan['units']['qwen']['link'],
    consumer_source=pin(R / 'tests/tools/qwen_host_image_test.cc'),
    previous_consumer=pin(W / 'compile/qwen/receipt.json'), retained=plan['retained'],
    runtime=plan['runtime'], sdk_engine_dependencies=plan['sdk'], source_freeze=pin(W / 'source-freeze.json'))
save(W / 'model-link-base.json', current_base)

selected = {name: 'attempt4' if name == 'history-cpu' else 'attempt1' for name in plan['cases']}
results = {}
for name, attempt in selected.items():
    folder = W / 'runs' / name / attempt
    process, report = read(folder / 'process.json'), read(folder / 'report.json')
    assert process['exit'] == 0 and not process['timed_out'] and report['status'] == 'PASS'
    results[name] = dict(process=process, report=report)
failures = []
for n, reason in [(1, 'B cold reserved slot was incorrectly checked as a discarded cancellation slot.'),
                  (2, 'Generic ordinary preflight helper imported an MTP checkpoint with Text role.'),
                  (3, 'New next R1 round omitted ACK of the outputs now published by original B2.')]:
    folder = W / 'runs/history-cpu' / ('attempt' + str(n))
    process = read(folder / 'process.json'); assert process['exit'] != 0
    failures.append(dict(attempt=n, process=process, reason=reason,
        product_change_needed=False, preserved_source='failed-history-source' + (str(n) if n > 1 else '')))

builds = {}
for name in ('qwen', 'ordinary'):
    receipt = read(W / 'compile' / name / 'receipt.json')
    builds[name] = dict(compiles=[read(p) for p in sorted((W / 'compile' / name).glob('attempt*/process.json'))],
        links=[read(p) for p in sorted((W / 'link' / name).glob('attempt*/process.json'))],
        final_object=receipt['object'], source_inputs=len(receipt['source_identities']))
archive_sources = W / 'archive-sources'
for source in sources:
    destination = archive_sources / source.relative_to(R)
    destination.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, destination)
diff = subprocess.run(['git', 'diff', '--binary', '--', *[str(p.relative_to(R)) for p in sources]], cwd=R,
    check=True, capture_output=True).stdout
(W / 'implementation.patch').write_bytes(diff)
payload = [p for p in W.rglob('*') if p.is_file() and p.suffix.lower() in ('.py', '.json', '.log', '.h', '.cc', '.patch', '.tsv', '.ids')
    and 'tmp' not in p.relative_to(W).parts and p.name not in ('cleanup-plan.json', 'cleanup-result.json')]
save(W / 'archive-manifest.json', [dict(name=p.relative_to(W).as_posix(), **pin(p)) for p in sorted(payload)])
archive = R / 'docs/evidence/correctness/inference-mtp-member-withdrawal-2026-10-29.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(payload): z.write(p, p.relative_to(W).as_posix())
    z.write(W / 'archive-manifest.json', 'archive-manifest.json')
evidence = dict(schema='hyle.correctness.mtp-member-withdrawal.v1', date='2026-10-29',
    status='PASS_WITH_PRESERVED_TEST_INTEGRATION_FAILURES',
    base_commit='b1704817d9ba8c9e04b1957153ee3122caae11b4',
    change='Submitted ordinary/MTP cohorts share per-member withdrawal eligibility. Keep original member indices and whole native take/retirement; skip withdrawn acceptance, repair, state/head/RNG/ledger publication and successful observation. Survivors publish original submitted results.',
    counts=dict(CXX_attempts=5, links=5, current_SDK_inputs=227, SDK_CXX=0, NVCC=0, full_builds=0,
        native_consumer_processes=10, passed_finite_cases=7, preserved_test_integration_failures=3, downloads=0),
    builds=builds, results=results, preserved_failures=failures, source_freeze=source_freeze,
    reference_sources=read(W / 'reference-source-identities.json'),
    reference_conclusions=[
        'Local vLLM separates common batch/request identity from Qwen/DeepSeek MTP math and recurrent state layouts.',
        'Finished/withdrawn host publication is separate from whole submitted execution and delayed block retirement.',
        'SGLang keep_indices jointly filters request, sampler and speculative metadata for the next batch; do not rewrite submitted row positions.'],
    boundaries=[
        'This is a finite member-withdrawal slice, not completion of model-independent execution orchestration.',
        'MTP cancellation cases use real CPU/CUDA consumers with synthetic finite GA/H64/V64 weights; trained Qwen2B CUDA is an unchanged natural MTP/pipeline regression.',
        'Cancelled rows may already have executed inside the original shared Graph; only post-verify host selection/auxiliary repair/publication is skipped.',
        'Single/all-member, pre-submit and explicit whole-episode abort retain original native retirement; E4 explicitly checks whole-episode abort.',
        'No GPU physical-inflight assertion, device fault injection, model-quality, throughput, other-platform or arbitrary-model claim.',
        'Earlier successful cases were not rerun after history-helper-only fixes; product source remained identical. Original dependency receipts and failed-helper snapshots are preserved.',
        'No extra Source, executor, completion owner, model download, pool expansion or output-credit bypass.'],
    archive=dict(path=str(archive.relative_to(R)), bytes=archive.stat().st_size, sha256=pin(archive)['sha256']))
save(R / 'docs/evidence/correctness/inference-mtp-member-withdrawal-2026-10-29.json', evidence)
print('Archived 7 passed finite cases, 3 preserved test-integration failures; 5 CXX/links, 227 retained SDK inputs. Archive bytes:', archive.stat().st_size)
