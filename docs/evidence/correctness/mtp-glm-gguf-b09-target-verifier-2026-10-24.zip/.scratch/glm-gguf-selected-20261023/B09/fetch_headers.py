"""B09 shards1/2/11 metadata only. Root executes through budget/run_batch.

Reuse the extracted bounded structural reader/parser; retain all model arrays.
No body mode, guessed offset, fabricated padding, unbounded GET or HF fallback.
--plan-only performs local metadata checks and makes zero HTTP requests.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import struct
import sys
import urllib.request

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
NEED, SCHEMA = S / 'headers-needed.json', S / 'roles-schema.json'
PINNED = {
    'metadata': ('.scratch/mtp-artifact-schema-20261023/gguf_metadata.py', 'e3204073182c535c03570ad3b13e6ac51dfc8b5f6998f2cc5e6c38a55daf3f8f'),
    'http': ('.scratch/mtp-artifact-schema-20261023/fetch_headers.py', 'bab682186d8be2318669b1e70d5b9cd7365b589751d16b15094f30706a40685a'),
    'budget': ('.scratch/mtp-download-budget-20261023/budget.py', '24b008fb7a91f0eba34739cd4817fbf97b42ca7f435032d76cfb6e97ea398a17'),
}
TYPES = {0: ('F32', 1, 4), 8: ('Q8_0', 32, 34), 12: ('Q4_K', 256, 144),
         13: ('Q5_K', 256, 176), 14: ('Q6_K', 256, 210)}
LIMIT, REQUEST = 18 * 1024 * 1024, 256 * 1024


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = Path(path).read_bytes()  # Named small metadata/source files only.
    return dict(path=Path(path).relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.next')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def module(name, key):
    path, expected = PINNED[key]
    path = R / path
    assert identity(path)['sha256'] == expected, 'Pinned metadata helper changed: ' + key
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def checked():
    need, schema = read(NEED), read(SCHEMA)
    assert (need['id'], schema['id']) == ('B09', 'B09')
    assert (need['repository'], need['revision']) == (schema['repository'], schema['revision'])
    assert need['maximum_request_bytes'] == REQUEST and need['metadata_upper_bound_bytes'] == LIMIT
    assert [x['shard'] for x in need['files']] == [1, 2, 11]
    assert [x['metadata_limit_bytes'] for x in need['files']] == [16 * 1024 * 1024, 1024 * 1024, 1024 * 1024]
    assert sum(x['metadata_limit_bytes'] for x in need['files']) == LIMIT
    for key, (path, expected) in PINNED.items():
        assert identity(R / path)['sha256'] == expected, 'Pinned helper changed: ' + key
    census_path = R / need['evidence']['path']
    assert identity(census_path) == need['evidence'] == schema['evidence']
    census = read(census_path)[schema['audit_key']]
    assert census['complete'] and len(census['tensors']) == census['tensor_count'] == 1809
    assert (census['repo'], census['revision']) == (need['repository'], need['revision'])
    for source in need['files']:
        assert source['url'] == f"https://huggingface.co/{need['repository']}/resolve/{need['revision']}/{source['file']}"
        rows = [x for x in census['tensors'] if x['shard'] == source['shard']]
        assert len(rows) == source['expected_tensor_count']
    assert len(schema['roles']) == 53 and schema['static_roles'] == 47
    assert schema['static_bytes'] == 2567086080
    names = {x['name']: x for x in census['tensors']}
    assert len(names) == len(census['tensors'])
    for role in schema['roles']:
        original = names[role['name']]
        assert (original['shard'], original['dtype'], list(map(int, original['shape']))) == (
            role['source_shard'], role['dtype'], role['gguf_dimensions'])
    return need, schema, census


def require_transport():
    # No direct canonical-HF network mode. The reviewed budget guard owns its
    # exclusive-net opener/redirect handler and preserves the existing ledger.
    opener = urllib.request.urlopen
    assert (hasattr(opener, '__code__') and opener.__code__.co_name == 'open_range'
            and Path(opener.__code__.co_filename).resolve() == (R / PINNED['budget'][0]).resolve()
            and opener.__globals__.get('MIRROR_HOST') == 'hf-mirror.net'), \
        'Execute actual acquisition through the pinned budget.py/run_batch.py net-only transport'


class HeaderSource:
    """One contiguous authenticated metadata prefix; persist before parsing."""
    def __init__(self, file, http):
        self.file, self.http = file, http
        self.folder = S / 'headers' / f"shard{file['shard']:02d}"
        self.folder.mkdir(parents=True, exist_ok=True)
        self.path, self.receipt = self.folder / 'original-header.bin', self.folder / 'acquired.json'
        self.raw, self.parts, self.total, self.etag = bytearray(), [], None, None
        if self.receipt.exists():
            old = read(self.receipt)
            assert old['file'] == file and old['transport_guard_sha256'] == PINNED['budget'][1]
            assert identity(self.path) == old['prefix']
            self.raw = bytearray(self.path.read_bytes())
            self.parts, self.total, self.etag = old['ranges'], old['whole_file_bytes'], old['etag']
            cursor = 0
            for part in self.parts:
                first, last = part['absolute_inclusive']
                assert first == cursor and last - first + 1 <= REQUEST
                assert part['complete'] and part['url'] == file['url'] and part['status'] == 206
                headers = {k.lower(): v for k, v in part['headers'].items()}
                assert headers['content-range'] == f'bytes {first}-{last}/{self.total}'
                assert headers['etag'] == self.etag and headers['content-length'] == str(last - first + 1)
                assert sha(self.raw[first:last + 1]) == part['sha256']
                cursor = last + 1
            assert cursor == len(self.raw) <= file['metadata_limit_bytes']
        else:
            assert not self.path.exists(), 'Unreceipted metadata prefix; preserve it for explicit investigation'

    def exact(self, url, first, last, *, total=None, etag=None):
        assert url == self.file['url'] and 0 <= first <= last < self.file['metadata_limit_bytes']
        assert last - first + 1 <= REQUEST
        if total is not None:
            assert total == self.total
        if etag is not None:
            assert etag == self.etag
        assert first <= len(self.raw), 'Do not skip any structural metadata byte'
        if last >= len(self.raw):
            start = len(self.raw)
            part, actual_total, actual_etag = self.http.exact(url, start, last, total=self.total, etag=self.etag)
            self.total, self.etag = actual_total, actual_etag
            self.raw.extend(part)
            self.parts.append(dict(self.http.requests[-1]))
            # A complete HTTP prefix survives any later scan/schema failure.
            self.path.write_bytes(self.raw)
            save(self.receipt, dict(complete=False, acquired=True, schema_validated=False,
                file=self.file, prefix=identity(self.path), ranges=self.parts,
                whole_file_bytes=self.total, etag=self.etag, tensor_payload_bytes=0,
                transport_guard_sha256=PINNED['budget'][1]))
        return bytes(self.raw[first:last + 1]), self.total, self.etag


def one(source, need, census, http):
    data = HeaderSource(source, http)
    prefix, total, etag = data.exact(source['url'], 0, 23)
    magic, version, count, kv_count = struct.unpack('<4sIQQ', prefix)
    assert magic == b'GGUF' and version in (2, 3) and 0 < kv_count <= 1000
    assert count == source['expected_tensor_count'], 'Actual split tensor count differs from the fixed full census'
    metadata_reader = module(f"b09_structural_metadata_{source['shard']}", 'metadata')
    raw, scalars, tensors, metadata_count, actual_total, actual_etag = metadata_reader.scan(
        data.exact, url=source['url'], tensor_count=count,
        maximum_header_bytes=source['metadata_limit_bytes'], chunk_bytes=REQUEST)
    assert (actual_total, actual_etag) == (total, etag) and raw == data.raw
    retain = set(scalars) | set(need['required_retained_metadata']) | {
        'glm-dsa.rope.dimension_sections', 'glm-dsa.rope.dimension_count',
        'glm-dsa.rope.scaling.type', 'glm-dsa.rope.scaling.factor',
        'glm-dsa.rope.scaling.original_context_length', 'glm-dsa.rope.scaling.attn_factor'}
    metadata, parsed, parsed_count = metadata_reader.parse_header(
        raw, count, len(raw), retain, whole_file_bytes=total)
    assert parsed == tensors and parsed_count == metadata_count
    assert all(metadata[key] == value for key, value in scalars.items())
    expected = {x['name']: (list(map(int, x['shape'])), x['dtype'])
                for x in census['tensors'] if x['shard'] == source['shard']}
    actual = {}
    for item in tensors:
        name, shape, code, offset = item['name'], item['shape'], item['dtype_code'], item['offset']
        dtype, block, physical = TYPES[code]
        assert expected[name] == (shape, dtype) and name not in actual and shape[0] % block == 0
        size = math.prod(shape) // block * physical
        assert offset % metadata.get('general.alignment', 32) == 0
        assert len(raw) + offset + size <= total
        actual[name] = dict(item, dtype=dtype, bytes=size)
    assert set(actual) == set(expected)
    ordered = sorted(actual.values(), key=lambda x: x['offset'])
    assert all(a['offset'] + a['bytes'] <= b['offset'] for a, b in zip(ordered, ordered[1:]))
    save(data.folder / 'physical-table.json', dict(metadata=metadata, tensors=list(actual.values())))
    receipt = dict(complete=True, schema_validated=True, repository=need['repository'], revision=need['revision'],
        file=source['file'], url=source['url'], shard=source['shard'],
        data_base=len(raw) if count else None, metadata_bytes=len(raw), tensor_data_present=bool(count),
        whole_file_bytes=total, etag=etag, actual_tensor_count=count, metadata_count=metadata_count,
        header=identity(data.path), physical_table=identity(data.folder / 'physical-table.json'),
        acquired_receipt=identity(data.receipt), http_status=206, tensor_payload_bytes=0,
        maximum_metadata_bytes=source['metadata_limit_bytes'], metadata_limit_is_hard_upper_bound=True)
    save(data.folder / 'header.json', receipt)
    return receipt, actual, metadata


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan-only', action='store_true')
    args = p.parse_args()
    need, schema, census = checked()
    if args.plan_only:
        print(json.dumps(dict(network_requests=0, repository=need['repository'], revision=need['revision'],
            shards=[dict(shard=x['shard'], actual_tensor_count=None, cached_expected_tensor_count=x['expected_tensor_count'],
                maximum_metadata_bytes=x['metadata_limit_bytes'], is_hard_upper_bound=True) for x in need['files']],
            maximum_metadata_bytes=LIMIT, is_hard_upper_bound=True, maximum_request_bytes=REQUEST,
            actual_offsets_available=False, tensor_payload_bytes=0, helper_pins=PINNED)))
        return
    require_transport()
    http = module('b09_strict_metadata_http', 'http')
    http.MAX_TOTAL = LIMIT
    attempt = 1
    while (S / f'http-requests-attempt{attempt}.json').exists():
        attempt += 1
    try:
        receipts, actual, config = [], {}, {}
        for source in need['files']:
            receipt, rows, metadata = one(source, need, census, http)
            receipts.append(receipt)
            assert not (set(actual) & set(rows))
            actual.update(rows)
            config[str(source['shard'])] = metadata
        by_shard = {x['shard']: x for x in receipts}
        roles = []
        for original in schema['roles']:
            row, shard = actual[original['name']], by_shard[original['source_shard']]
            assert row['bytes'] == original['bytes'] and row['shape'] == original['gguf_dimensions']
            first = shard['data_base'] + row['offset']
            roles.append(dict(original, filename=original['name'] + '.bin',
                data_relative_half_open=[row['offset'], row['offset'] + row['bytes']],
                absolute_inclusive=[first, first + row['bytes'] - 1]))
        common = dict(repository=need['repository'], revision=need['revision'], variant=schema['variant'],
            source_schema=identity(SCHEMA), shards=receipts, complete_absolute_ranges=True,
            http_identity_authenticated=True, payload_acquired=False, generated_pins=False,
            metadata_only=True, tensor_payload_bytes=0, whole_shards_downloaded=False)
        save(S / 'roles-plan.json', dict(common, roles=roles, original_roles=53,
            full_expert_banks_acquire=False, actual_metadata=config))
        static = [x for x in roles if not x['selected_source']]
        save(S / 'static-plan.json', dict(common, roles=static, original_roles=len(static),
            source_bytes=sum(x['bytes'] for x in static), actual_metadata=config))
        save(S / 'summary.json', dict(complete=True, metadata_only=True, tensor_payload_bytes=0,
            maximum_metadata_bytes=LIMIT, metadata_limit_is_hard_upper_bound=True,
            actual_header_bytes=sum(x['header']['bytes'] for x in receipts), new_requested_bytes=http.reserved,
            headers=receipts, roles_plan=identity(S / 'roles-plan.json'), static_plan=identity(S / 'static-plan.json')))
        print(json.dumps(dict(complete=True, actual_header_bytes=sum(x['header']['bytes'] for x in receipts),
            new_requested_bytes=http.reserved, tensor_payload_bytes=0, roles=53, static_roles=47)))
    finally:
        save(S / f'http-requests-attempt{attempt}.json', dict(requests=http.requests,
            reserved_request_bytes=http.reserved, maximum_metadata_bytes=LIMIT,
            metadata_limit_is_hard_upper_bound=True, helpers={k: identity(R / path) for k, (path, _) in PINNED.items()}))


if __name__ == '__main__':
    main()
