from pathlib import Path
import ast,difflib,hashlib,json,subprocess
r=Path.cwd();s=r/'.scratch/glm-gguf-selected-20261023/B09/native-integration/driver-proposal';live=s/'run_with_supply.py'
before=live.read_bytes();(s/'retry-before.py').write_bytes(before);t=before.decode()
# Preserve exact line endings in the final scratch successor.
t=t.replace('\r\n','\n')
anchor='\ndef main():\n'
helper=r'''

def transport_failure(batch_dir,request):
    """Classify only this immutable batch's explicit structured failure event.

    Do not consult mutable per-ID error history: a later successful resume can
    retain older errors. Unknown/HTTP/integrity/semantic exceptions never retry.
    """
    path=batch_dir/'run'/'stdout.log'
    if not path.is_file() or path.stat().st_size>2097152:
        return dict(retryable=False,reason='Missing or oversized actual batch stdout')
    events=[]
    for line in path.read_text('utf-8-sig',errors='replace').splitlines():
        try:event=json.loads(line)
        except json.JSONDecodeError:continue
        if isinstance(event,dict) and event.get('event')=='frontier_failed':events.append(event)
    if len(events)!=1:return dict(retryable=False,reason='Expected exactly one actual frontier_failed event',log=identity(path))
    event=events[0];errors=event.get('errors')
    if event.get('complete') is not False or event.get('section')!=request['section'] or event.get('stage')!=0 or event.get('global_ids')!=request['missing_ids'] or not isinstance(errors,list) or not errors:
        return dict(retryable=False,reason='Actual failed frontier identity/errors differ',log=identity(path))
    ids=[];classified=[]
    for error in errors:
        kind,message=error.get('type'),error.get('error')
        global_id=error.get('global_id')
        if type(global_id)is not int or global_id not in request['missing_ids'] or global_id in ids or not isinstance(message,str):
            return dict(retryable=False,reason='Actual failed global IDs or error schema differ',log=identity(path))
        # These names/messages describe a failed transport read, not a bad
        # authenticated response, SHA/range/length mismatch or native failure.
        allowed=(kind=='EOFError' and message=='Early EOF in authenticated source range')
        allowed=allowed or (kind=='IncompleteRead' and re.fullmatch(r'IncompleteRead\([0-9]+ bytes read(?:, [0-9]+ more expected)?\)',message) is not None)
        allowed=allowed or (kind in ('TimeoutError','timeout') and message.lower() in ('timed out','the read operation timed out','read timed out'))
        allowed=allowed or kind in ('ConnectionResetError','ConnectionAbortedError')
        allowed=allowed or (kind=='URLError' and re.fullmatch(r'<urlopen error (?:\[(?:Errno|WinError) (?:54|104|110|10053|10054|10060)\] )?(?:timed out|The read operation timed out|Connection (?:reset|aborted)(?: by peer)?|Connection timed out)>',message,re.IGNORECASE) is not None)
        classified.append(dict(global_id=global_id,type=kind,error=message,retryable=allowed))
        if not allowed:return dict(retryable=False,reason='Non-transport or unrecognized failure; no retry',errors=classified,log=identity(path))
        ids.append(global_id)
    return dict(retryable=True,reason='Only explicit transport failures',missing_ids=sorted(ids),errors=classified,log=identity(path))
'''
assert t.count(anchor)==1;t=t.replace(anchor,helper+anchor)
t=t.replace('    def run_child(cmd,log_path,item):','    def run_child(cmd,log_path,item,allow_nonzero=False):')
old="            if child.returncode:raise RuntimeError('B09 supply command failed; see '+str(log_path))\n            child=None"
new="            code=child.returncode;child=None\n            if code and not allow_nonzero:raise RuntimeError('B09 supply command failed; see '+str(log_path))\n            return code"
assert t.count(old)==1;t=t.replace(old,new)
old='''                        index=len(record['batches'])+1;batch_dir=out/f'supply{index:03}';batch_dir.mkdir()
                        frozen=batch_dir/'frontier.json';save(frozen,request)
                        previous=[int(m.group(1)) for p in (S/'batches').glob('*-attempt*') if (m:=re.search(r'-attempt([0-9]+)$',p.name))]
                        attempt=max([args.attempt,*[n+1 for n in previous]])
                        plan=batch_dir/'batch-plan.json';item=dict(request=request,frontier=identity(frozen),attempt=attempt)
                        record['batches'].append(item)
                        run_child([sys.executable,str(ACQUIRE),'experts','--frontier-file',str(frozen),'--write-batch-plan',str(plan),'--attempt',str(attempt)],batch_dir/'plan.stdout.txt',item.setdefault('plan',{}))
                        item['batch_plan']=identity(plan)
                        run_child([sys.executable,str(BUDGET),str(plan)],batch_dir/'batch.stdout.txt',item.setdefault('acquire',{}))
                        planned=json.loads(plan.read_text('utf-8-sig'));summary=R/planned['out']/'summary.json'
                        item['batch_summary']=identity(summary);actual=json.loads(summary.read_text('utf-8-sig'))
                        if actual['process']['exit']!=0 or actual['paused_after'] is not True:raise ValueError('Actual B09 batch did not complete and restore pause')
                        seen.add(key);note('actual_frontier_supplied')'''
new='''                        retry_ids=missing
                        for transport_attempt in range(1,4):
                            # One native process remains waiting. Each retry
                            # gets a fresh immutable plan and reuses the same
                            # authenticated per-ID files/chunks. Completed IDs
                            # are absent from the refined missing-ID request.
                            index=len(record['batches'])+1;batch_dir=out/f'supply{index:03}';batch_dir.mkdir()
                            current_request=dict(request,missing_ids=retry_ids)
                            frozen=batch_dir/'frontier.json';save(frozen,current_request)
                            previous=[int(m.group(1)) for p in (S/'batches').glob('*-attempt*') if (m:=re.search(r'-attempt([0-9]+)$',p.name))]
                            attempt=max([args.attempt,*[n+1 for n in previous]])
                            plan=batch_dir/'batch-plan.json';item=dict(request=current_request,frontier=identity(frozen),attempt=attempt,
                                original_frontier=request,transport_attempt=transport_attempt,maximum_transport_attempts=3)
                            record['batches'].append(item)
                            run_child([sys.executable,str(ACQUIRE),'experts','--frontier-file',str(frozen),'--write-batch-plan',str(plan),'--attempt',str(attempt)],batch_dir/'plan.stdout.txt',item.setdefault('plan',{}))
                            item['batch_plan']=identity(plan)
                            code=run_child([sys.executable,str(BUDGET),str(plan)],batch_dir/'batch.stdout.txt',item.setdefault('acquire',{}),allow_nonzero=True)
                            planned=json.loads(plan.read_text('utf-8-sig'));actual_batch=R/planned['out'];summary=actual_batch/'summary.json'
                            item['batch_summary']=identity(summary);actual=json.loads(summary.read_text('utf-8-sig'))
                            if actual['paused_after'] is not True or not (R/'.scratch/mtp-download-budget-20261023/PAUSED').is_file() or actual['process']['exit']!=code:
                                raise ValueError('Actual B09 batch exit/pause bookkeeping differs; no transport retry')
                            if code==0:
                                seen.add(key);note('actual_frontier_supplied');break
                            classification=transport_failure(actual_batch,current_request)
                            item['failure_classification']=classification;note('supply_batch_failed')
                            if not classification['retryable'] or actual['process'].get('timed_out') is not False or transport_attempt==3 or native.poll() is not None:
                                raise RuntimeError('B09 batch failed outside bounded transport retry domain; original logs retained')
                            retry_ids=classification['missing_ids'];note('retrying_transport_only')'''
assert t.count(old)==1;t=t.replace(old,new)
ast.parse(t)
after=t.replace('\n','\r\n').encode();(s/'retry-next.py').write_bytes(after)
rel=live.relative_to(r).as_posix();diff='diff --git a/'+rel+' b/'+rel+'\n'+''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
patch=s/'transport-retry.patch';patch.write_bytes(diff.encode())
check=subprocess.run(['git','apply','--check',str(patch)],capture_output=True,text=True,cwd=r)
assert check.returncode==0,check.stderr
info=lambda p:dict(path=p.relative_to(r).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
print(json.dumps(dict(before=info(s/'retry-before.py'),after=info(s/'retry-next.py'),patch=info(patch),AST=True,apply_check=check.returncode,live_unchanged=live.read_bytes()==before)))
