"""Root-only B09 exact-case run and serial actual-frontier supply.

Preparation only until root explicitly invokes this script. Native execution
uses the existing image/runtime; acquisition is the frozen B09 adapter under
its existing bounded budget runner. No HTTP implementation lives here.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import re
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parents[2]
R=S.parents[2]
ACQUIRE=S/'acquire.py'
ACQUIRE_SHA='6c79213014eebd58436e50ce44dc821408431838851ee5c8407d1a36d87761fb'
OWNER=R/'.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'
OWNER_SHA='295012b6decc3b3c473252aa1afd35f8daee49f9fab352870bab15fe9baf2c4d'
BUDGET=R/'.scratch/mtp-download-budget-20261023/run_batch.py'


def identity(path):
    path=Path(path).resolve();digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest.hexdigest())


def require(info,path=None):
    actual=identity(info['path'] if path is None else path)
    if path is not None and Path(info['path']).resolve()!=Path(path).resolve():
        raise ValueError('Recorded path differs: '+str(path))
    if any(actual[k]!=info[k] for k in ('bytes','sha256')):raise ValueError('Actual identity differs: '+actual['path'])
    return actual


def save(path,value):
    temporary=path.with_suffix(path.suffix+'.next')
    temporary.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8');os.replace(temporary,path)


def terminate_tree(child,out,label):
    if child is None:return
    if child.poll() is None:
        # Same existing JobObject also owns grandchildren if this driver is
        # forcibly stopped. Explicit cleanup reaps this child and its batch.
        with (out/(label+'-stop.txt')).open('wb') as log:
            subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT,
                           creationflags=subprocess.CREATE_NO_WINDOW,timeout=30,check=False)
        try:child.wait(timeout=10)
        except subprocess.TimeoutExpired:child.kill();child.wait(timeout=10)
    else:child.wait()


def case_result(xml_path,case):
    root=ET.parse(xml_path).getroot();cases=list(root.iter('testcase'))
    if len(cases)!=1:raise ValueError('B09 native must execute exactly one registered case')
    item=cases[0];actual=item.get('classname','')+'.'+item.get('name','')
    if actual!=case or item.get('status')!='run' or item.get('result')!='completed' or list(item.iter('skipped')) or list(item.iter('failure')):
        raise ValueError('B09 exact native case failed/skipped/differed: '+actual)
    for key in ('failures','disabled','errors'):
        if int(root.get(key,'0')):raise ValueError('B09 XML has nonzero '+key)
    return dict(name=actual,seconds=item.get('time'),properties={p.get('name'):p.get('value') for p in item.iter('property')})



def transport_failure(batch_dir,request):
    """Classify only this immutable batch's explicit structured failure event.

    Do not consult mutable per-ID error history: a later successful resume can
    retain older errors. Unknown/HTTP/integrity/semantic exceptions never retry.
    """
    path=batch_dir/'run'/'stdout.log'
    if not path.is_file() or path.stat().st_size>2097152:
        return dict(retryable=False,reason='Missing or oversized actual batch stdout')
    events=[]
    for line in path.read_text('utf-8-sig',errors='replace').splitlines():
        try:event=json.loads(line)
        except json.JSONDecodeError:continue
        if isinstance(event,dict) and event.get('event')=='frontier_failed':events.append(event)
    if len(events)!=1:return dict(retryable=False,reason='Expected exactly one actual frontier_failed event',log=identity(path))
    event=events[0];errors=event.get('errors')
    if event.get('complete') is not False or event.get('section')!=request['section'] or event.get('stage')!=0 or event.get('global_ids')!=request['missing_ids'] or not isinstance(errors,list) or not errors:
        return dict(retryable=False,reason='Actual failed frontier identity/errors differ',log=identity(path))
    ids=[];classified=[]
    for error in errors:
        kind,message=error.get('type'),error.get('error')
        global_id=error.get('global_id')
        if type(global_id)is not int or global_id not in request['missing_ids'] or global_id in ids or not isinstance(message,str):
            return dict(retryable=False,reason='Actual failed global IDs or error schema differ',log=identity(path))
        # These names/messages describe a failed transport read, not a bad
        # authenticated response, SHA/range/length mismatch or native failure.
        allowed=(kind=='EOFError' and message=='Early EOF in authenticated source range')
        allowed=allowed or (kind=='IncompleteRead' and re.fullmatch(r'IncompleteRead\([0-9]+ bytes read(?:, [0-9]+ more expected)?\)',message) is not None)
        allowed=allowed or (kind in ('TimeoutError','timeout') and message.lower() in ('timed out','the read operation timed out','read timed out'))
        allowed=allowed or kind in ('ConnectionResetError','ConnectionAbortedError')
        allowed=allowed or (kind=='URLError' and re.fullmatch(r'<urlopen error (?:\[(?:Errno|WinError) (?:54|104|110|10053|10054|10060)\] )?(?:timed out|The read operation timed out|Connection (?:reset|aborted)(?: by peer)?|Connection timed out)>',message,re.IGNORECASE) is not None)
        classified.append(dict(global_id=global_id,type=kind,error=message,retryable=allowed))
        if not allowed:return dict(retryable=False,reason='Non-transport or unrecognized failure; no retry',errors=classified,log=identity(path))
        ids.append(global_id)
    return dict(retryable=True,reason='Only explicit transport failures',missing_ids=sorted(ids),errors=classified,log=identity(path))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image-dir',type=Path,required=True)
    parser.add_argument('--backend',choices=('cpu','cuda'),required=True)
    parser.add_argument('--attempt',type=int,required=True)
    parser.add_argument('--timeout',type=float,default=14400)
    parser.add_argument('--wait-for-batch-summary',type=Path)
    args=parser.parse_args()
    if os.name!='nt' or args.attempt<=0 or args.timeout<=0:raise ValueError('Windows and positive attempt/timeout required')
    if identity(ACQUIRE)['sha256']!=ACQUIRE_SHA or identity(OWNER)['sha256']!=OWNER_SHA:
        raise ValueError('Frozen acquisition/process-owner source differs')
    spec=importlib.util.spec_from_file_location('_b09_existing_owned_job',OWNER)
    owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
    image_dir=args.image_dir.resolve();ready=json.loads((image_dir/'ready.json').read_text('utf-8-sig'))
    image=Path(ready['image']['path']).resolve()
    if image.parent!=image_dir or image.suffix.lower()!='.exe':raise ValueError('Image must belong to requested linked directory')
    require(ready['image'],image)
    runtime_path=image_dir/'runtime-environment.json';require(ready['runtime_environment'],runtime_path)
    runtime=json.loads(runtime_path.read_text('utf-8-sig'))
    for dll in runtime['staged_dlls']:require(dll)
    require(ready['link_plan'],image_dir/'link-plan.json')
    static=S/'original-static';experts=S/'original-experts'
    manifest=json.loads((static/'manifest.json').read_text('utf-8-sig'))
    if not manifest['complete'] or manifest['original_roles']!=47:raise ValueError('Actual static47 acquisition is incomplete')
    out=S/'native-integration'/'driver-runs'/f'checks{args.attempt}-{args.backend}'
    out.mkdir(parents=True,exist_ok=False)
    frontier=out/'frontier.json';save(frontier,{})
    case='GlmProMtpStateConsumer.'+args.backend.title()+'ConvertedB09TargetAndNextNFullVocabularyVerifier'
    command=[str(image),'--gtest_filter='+case,'--gtest_output=xml:'+str(out/'results.xml')]
    env={k:v for k,v in os.environ.items() if not k.startswith('HYLE_GLM_')}
    env.update(PATH=runtime['PATH'],HYLE_GLM_GGUF_B09_DIR=str(static),HYLE_GLM_GGUF_B09_EXPERT_DIR=str(experts),
               HYLE_GLM_GGUF_WAIT_FOR_EXPERTS='1',HYLE_GLM_GGUF_FRONTIER_FILE=str(frontier))
    env['OMP_NUM_THREADS']='4';env['MKL_NUM_THREADS']='4';env['OPENBLAS_NUM_THREADS']='4'
    record=dict(driver=identity(Path(__file__)),image=require(ready['image']),runtime=identity(runtime_path),
                link_plan=identity(image_dir/'link-plan.json'),source=identity(ACQUIRE),process_owner=identity(OWNER),
                static_manifest=identity(static/'manifest.json'),command=command,environment={k:v for k,v in env.items() if k=='PATH' or k.startswith(('HYLE_GLM_','OMP_','MKL_','OPENBLAS_'))},
                backend=args.backend,attempt=args.attempt,started=time.time(),batches=[],timing_scope='Wall clock progress only,not TPS',passed=False)
    status=out/'driver.json';started=time.monotonic();last_tick=started
    native=child=job=None;result=1;seen=set()
    def note(event):
        record['elapsed_seconds']=time.monotonic()-started;save(status,record)
        print(json.dumps(dict(event=event,elapsed_seconds=record['elapsed_seconds'],native_pid=native.pid if native else None,
                              active_child_pid=child.pid if child and child.poll() is None else None,batches=len(record['batches']),record=str(status))),flush=True)
    def job_processes():
        # Includes this driver. A descendant unexpectedly surviving a failed
        # batch keeps kill-on-close enabled instead of escaping ownership.
        class Accounting(owner.ct.Structure):
            _fields_=[('times',owner.ct.c_int64*4),('faults',owner.wt.DWORD),('total',owner.wt.DWORD),
                      ('active',owner.wt.DWORD),('terminated',owner.wt.DWORD)]
        query=job.api.QueryInformationJobObject
        query.argtypes=[owner.wt.HANDLE,owner.ct.c_int,owner.ct.c_void_p,owner.wt.DWORD,owner.ct.c_void_p]
        query.restype=owner.wt.BOOL
        info=Accounting()
        if not query(job.handle,1,owner.ct.byref(info),owner.ct.sizeof(info),None):
            raise owner.ct.WinError(owner.ct.get_last_error())
        return info.active
    def interrupted(signum,frame):raise KeyboardInterrupt('Signal '+str(signum))
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
    def poll_tick():
        nonlocal last_tick
        now=time.monotonic()
        if now-started>args.timeout:raise TimeoutError('B09 driver total timeout')
        if now-last_tick>=45:note('progress');last_tick=now
    def run_child(cmd,log_path,item,allow_nonzero=False):
        nonlocal child
        with log_path.open('wb') as log:
            child=subprocess.Popen(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            item.update(command=cmd,pid=child.pid,started=time.time());note('supply_child_started')
            while child.poll() is None:
                poll_tick()
                native_exit=native.poll()
                # The final atomic ready can unblock a successful native
                # before the downloader finishes its receipt/PAUSED cleanup.
                # Reap that normal tail instead of declaring a false failure.
                if native_exit is not None and native_exit!=0:
                    raise RuntimeError('Native failed while supply child was active')
                time.sleep(.2)
            item.update(exit=child.wait(),finished=time.time());note('supply_child_finished')
            code=child.returncode;child=None
            if code and not allow_nonzero:raise RuntimeError('B09 supply command failed; see '+str(log_path))
            return code
    def await_prior_batch():
        if args.wait_for_batch_summary is None or record.get('prior_batch') is not None:return
        path=args.wait_for_batch_summary.resolve()
        if not path.is_relative_to(R) or path.name!='summary.json':
            raise ValueError('Prior batch summary must be an explicit repository summary.json')
        note('waiting_for_existing_batch')
        while not path.is_file():
            poll_tick()
            if native.poll() is not None:raise RuntimeError('Native ended before external supply was available')
            time.sleep(.2)
        summary=json.loads(path.read_text('utf-8-sig'))
        if summary['process']['exit']!=0 or summary['paused_after'] is not True:
            raise ValueError('Prior batch failed or did not restore pause')
        record['prior_batch']=identity(path);note('existing_batch_terminal')
    try:
        job=owner.OwnedJob()
        with (out/'stdout.txt').open('wb') as stdout:
            native=subprocess.Popen(command,cwd=R,env=env,stdout=stdout,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            record['native']=dict(pid=native.pid,started=time.time());note('native_started')
            while native.poll() is None:
                poll_tick()
                try:request=json.loads(frontier.read_text('utf-8-sig'))
                except (FileNotFoundError,json.JSONDecodeError):time.sleep(.2);continue
                missing=request.get('missing_ids',[])
                if missing:
                    section,stage,globals_=request['section'],request['stage'],request['global_ids']
                    if section not in ('target','draft') or type(stage)is not int or stage!=0 or not isinstance(missing,list) or not isinstance(globals_,list) or not 1<=len(missing)<=8 or not len(globals_)<=8 or any(type(n)is not int or not 0<=n<256 for n in missing+globals_) or missing!=sorted(set(missing)) or globals_!=sorted(set(globals_)) or not set(missing)<=set(globals_):
                        raise ValueError('Actual B09 frontier section/stage/global IDs differ')
                    key=(section,stage,tuple(missing))
                    if key not in seen:
                        await_prior_batch()
                        retry_ids=missing
                        for transport_attempt in range(1,4):
                            # One native process remains waiting. Each retry
                            # gets a fresh immutable plan and reuses the same
                            # authenticated per-ID files/chunks. Completed IDs
                            # are absent from the refined missing-ID request.
                            index=len(record['batches'])+1;batch_dir=out/f'supply{index:03}';batch_dir.mkdir()
                            current_request=dict(request,missing_ids=retry_ids)
                            frozen=batch_dir/'frontier.json';save(frozen,current_request)
                            previous=[int(m.group(1)) for p in (S/'batches').glob('*-attempt*') if (m:=re.search(r'-attempt([0-9]+)$',p.name))]
                            attempt=max([args.attempt,*[n+1 for n in previous]])
                            plan=batch_dir/'batch-plan.json';item=dict(request=current_request,frontier=identity(frozen),attempt=attempt,
                                original_frontier=request,transport_attempt=transport_attempt,maximum_transport_attempts=3)
                            record['batches'].append(item)
                            run_child([sys.executable,str(ACQUIRE),'experts','--frontier-file',str(frozen),'--write-batch-plan',str(plan),'--attempt',str(attempt)],batch_dir/'plan.stdout.txt',item.setdefault('plan',{}))
                            item['batch_plan']=identity(plan)
                            code=run_child([sys.executable,str(BUDGET),str(plan)],batch_dir/'batch.stdout.txt',item.setdefault('acquire',{}),allow_nonzero=True)
                            planned=json.loads(plan.read_text('utf-8-sig'));actual_batch=R/planned['out'];summary=actual_batch/'summary.json'
                            item['batch_summary']=identity(summary);actual=json.loads(summary.read_text('utf-8-sig'))
                            if actual['paused_after'] is not True or not (R/'.scratch/mtp-download-budget-20261023/PAUSED').is_file() or actual['process']['exit']!=code:
                                raise ValueError('Actual B09 batch exit/pause bookkeeping differs; no transport retry')
                            if code==0:
                                seen.add(key);note('actual_frontier_supplied');break
                            classification=transport_failure(actual_batch,current_request)
                            item['failure_classification']=classification;note('supply_batch_failed')
                            if not classification['retryable'] or actual['process'].get('timed_out') is not False or transport_attempt==3 or native.poll() is not None:
                                raise RuntimeError('B09 batch failed outside bounded transport retry domain; original logs retained')
                            retry_ids=classification['missing_ids'];note('retrying_transport_only')
                time.sleep(.2)
            result=native.wait();record['native'].update(exit=result,finished=time.time())
        if result:raise RuntimeError('B09 native failed; original stdout/XML retained')
        record['case']=case_result(out/'results.xml',case);record['passed']=True
    except KeyboardInterrupt as error:record['error']=dict(type=type(error).__name__,message=str(error));result=130
    except Exception as error:record['error']=dict(type=type(error).__name__,message=str(error));result=1
    finally:
        try:
            for proc,label in ((child,'supply'),(native,'native')):
                if proc is not None:
                    was_active=proc.poll() is None
                    try:terminate_tree(proc,out,label)
                    except Exception as error:record.setdefault('cleanup_errors',[]).append(str(error));result=1
                    record[label+'_terminal']=dict(pid=proc.pid,exit=proc.returncode,stopped_by_driver=was_active)
            if job is not None:
                try:
                    record['owned_job_active_processes']=job_processes()
                    if record['owned_job_active_processes']!=1:
                        record.setdefault('cleanup_errors',[]).append('Owned descendant survives tracked-child wait; preserve kill-on-close')
                        result=1
                except Exception as error:
                    record.setdefault('cleanup_errors',[]).append(str(error));result=1
            record.update(exit=result,finished=time.time(),budget_paused=(R/'.scratch/mtp-download-budget-20261023/PAUSED').is_file())
            if result:record['passed']=False
            note('terminal')
            if result:
                text=(out/'stdout.txt').read_text('utf-8',errors='replace') if (out/'stdout.txt').exists() else ''
                print(text[-12000:],flush=True)
        finally:
            if job is not None:job.close(record.get('owned_job_active_processes')==1 and all(proc is None or proc.poll() is not None for proc in (native,child)))
    return result


if __name__=='__main__':
    sys.exit(main())
