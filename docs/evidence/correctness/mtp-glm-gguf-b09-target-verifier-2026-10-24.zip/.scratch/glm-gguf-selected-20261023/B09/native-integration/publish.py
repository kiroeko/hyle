"""Publish only the completed original B09 finite CPU/CUDA executions."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
A = S.parent
R = S.parents[3]
D = R / 'docs/evidence/correctness'
NAME = 'mtp-glm-gguf-b09-target-verifier-2026-10-24'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


executions = []
for backend, name in (('CPU', 'checks4-cpu'), ('CUDA', 'checks5-cuda')):
    folder = S / 'driver-runs' / name
    result = read(folder / 'driver.json')
    assert result['passed'] and result['exit'] == result['native']['exit'] == 0
    assert result['owned_job_active_processes'] == 1 and not result.get('cleanup_errors')
    assert result['native_terminal']['stopped_by_driver'] is False
    p = result['case']['properties']
    for key, value in dict(actual_submissions=44, actual_nextn_steps=11, actual_target_calls=8,
                           actual_pending_embedding_feedback_checks=11,
                           actual_index_catchup_steps=1, actual_skip_steps=7,
                           accepted_zero_draft_checkpoints=2, accepted_one_draft_checkpoints=1,
                           accepted_target_conditioned_repairs=1,
                           actual_accepted_kv_repair_submissions=2,
                           cancelled_unpublished_drafts=3, rejected_stale_publishes=3,
                           target_first_full_reference_values=309760,
                           first_full_nextn_head_reference_values=154880,
                           ready_non_moe_bank_capacity_bytes=2567086080).items():
        assert int(p[key]) == value, (backend, key)
    assert int(p['peak_state_backing_bytes']) <= int(p['state_budget_bytes'])
    executions.append(dict(backend=backend, case=result['case']['name'], tests=1,
                           failures=0, skips=0, graphs=44, properties=p,
                           driver=identity(folder / 'driver.json'),
                           XML=identity(folder / 'results.xml')))

paths = set()
for directory in (S, A / 'batches', A / 'generated', A / 'original-static', A / 'original-experts'):
    for path in directory.rglob('*'):
        if path.is_file() and (path.suffix in ('.json', '.xml', '.log', '.txt', '.py', '.h', '.patch')
                               or path.name in ('catalog.bin', 'ready.tsv')):
            # Product maps, objects, executables, native libraries, and role payloads are excluded.
            if path.name not in ('CMakeCache.txt',):
                paths.add(path)
for path in A.glob('*.json'):
    paths.add(path)
for path in A.glob('*.py'):
    paths.add(path)

compiled = read(S / 'compile2/glm-pro/identity.json')
for item in (compiled['source'], *compiled['dependencies']):
    path = Path(item['path']).resolve()
    if path.is_relative_to(R) and path.parts[len(R.parts)] in ('tests', 'include', 'src'):
        assert identity(path)['sha256'] == item['sha256'], str(path)
        paths.add(path)

experts = []
for path in sorted((A / 'original-experts').glob('*/stage0/expert*/ready.json')):
    data = read(path)
    acquisition = read(path.parent / 'acquisition.json')
    assert acquisition['complete'] and acquisition['original_roles'] == 3
    assert len(acquisition['global_ids']) == 1
    experts.append(dict(section=acquisition['section'], global_id=acquisition['global_ids'][0],
                        bytes=acquisition['bundle_bytes'],
                        ready=identity(path), acquisition=identity(path.parent / 'acquisition.json')))

batches = []
for path in sorted((A / 'batches').glob('*/summary.json')):
    data = read(path)
    assert data['hf_reserved_request_bytes'] == 0
    batches.append(dict(summary=identity(path), exit=data['process']['exit'],
                        reserved_request_bytes=data['reserved_request_bytes'],
                        HF_reserved_request_bytes=data['hf_reserved_request_bytes']))

archive = D / (NAME + '.zip')
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(paths):
        output.write(path, path.relative_to(R).as_posix())

record = dict(
    created_at=datetime.now(timezone.utc).isoformat(),
    identity=dict(id='B09', repository='unsloth/GLM-5.3-GGUF',
                  revision='346b3591c7f28d1a23716f97a065ecf12ec14771', variant='UD-Q4_K_XL'),
    scope='Own converted target77 and NextN78 packed roles, original Q8_0 full vocabulary and shared Pro K1 runtime.',
    static_roles=47, static_bytes=2567086080, executions=executions,
    state='13 resources plus Epoch24. Plain F32 main/index/hidden/journal, distinct target main/cursor/tap. No invented index-scale member.',
    behavior='Fresh and skip-index execution, accepted-prefix repair, lagged catchup, original embedding pending feedback, cancellation and stale publication.',
    selected_experts=experts,
    selected_expert_unique_payload_bytes=sum(item['bytes'] for item in experts),
    expert_supply='Only actual frontier IDs, three own original packed legs per ID, capacity8. No whole bank or F32 weight shadow.',
    original_static_acquisition=identity(A / 'original-static/acquisition.json'),
    original_static_manifest=identity(A / 'original-static/manifest.json'),
    actual_pins=identity(A / 'generated/glm_gguf_b09_artifacts.json'),
    build=dict(compiled=identity(S / 'compile2/glm-pro/identity.json'),
               link=identity(S / 'tests-link3/link-plan.json'),
               fresh_consumer_translation_units=1, SDK_builds=0, NVCC_builds=0,
               closure='Current Pro TU and current mixed BF16 CPU/CUDA/cuBLAS host objects; unused old Qwen/infer emitters removed.'),
    corrected_reference=dict(
        reason='Independent RoPE oracle previously multiplied I32 position and F32 frequency in double, omitting the actual F32 phase store before sin/cos.',
        fix='Keep the F32 position*frequency boundary before independent double trig; tolerances unchanged.',
        previous_failure='driver-runs/checks3-cpu, retained in archive',
        previous_source=identity(S / 'rope-reference-fix/before.h')),
    transport=dict(endpoint='https://hf-mirror.net', cross_origin_redirects='rejected before send',
                   batches=batches, HF_reserved_bytes=0,
                   reserved_request_bytes=sum(item['reserved_request_bytes'] for item in batches),
                   reservations_are_exact_wire_bytes=False,
                   retry='At most three attempts per explicit frontier, transport read failures only; completed original chunks reused.'),
    limits=[
        'Upstream layer76 input/residual, layer74 shared-index IDs and finite initial histories remain fixtures, not a complete trained GLM target engine or task quality.',
        'One natural K1 trial and separate controlled match/rejection trials do not measure natural acceptance rate.',
        'State backing and role capacity properties are logical allocation bounds, not measured physical CPU/GPU peaks.',
        'No TPS, load speed, full-model quality, Linux/macOS execution, or all-model/backend claim.'
    ],
    whole_original_model=False, throughput_evidence=False, memory_evidence=False,
    archive=identity(archive), archived_files=len(paths))
destination = D / (NAME + '.json')
assert not destination.exists()
destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(evidence=identity(destination), archive=identity(archive), graphs=88,
                      selected_experts=len(experts))))
