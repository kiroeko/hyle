"""Real B09 pins with cached current providers; only rebuild the affected Pro TU."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[3]
spec=importlib.util.spec_from_file_location('b09_current_build',R/'.scratch/native-paged-effects-20261022/build_windows.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
BASE=S.parent/'integration/tests-link1'

def compile_one(attempt):
    pins=S.parent/'generated/glm_gguf_b09_artifacts.h'
    proof=c.read(pins.with_suffix('.json'))
    assert proof['complete'] and proof['original_roles']==47
    assert b.identity(pins)['sha256']==proof['generated_header']['sha256']
    previous=S.parent/'integration/compile2/glm-pro/identity.json'
    recipe=c.read(previous)
    recipe['command'].insert(1,'/I'+str(pins.parent))
    recipe['prepared_only']=True
    recipe['actual_pins']=b.identity(pins)
    recipe['actual_pin_receipt']=b.identity(pins.with_suffix('.json'))
    prepared=S/('prepared-recipe.json' if attempt==1 else f'prepared-recipe{attempt}.json')
    assert not prepared.exists()
    c.save(prepared,recipe)
    h.S=S;h.RECIPES={'glm-pro':prepared};h.SOURCES={'glm-pro':R/'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'}
    h.compile_one('glm-pro',attempt)

def link(attempt,compile_attempt):
    base=c.read(BASE/'link-plan.json');new_path=S/f'compile{compile_attempt}/glm-pro/identity.json'
    new=c.read(new_path)
    assert all(b.identity(x['path'])==x for x in (new['source'],new['object'],*new['dependencies']))
    old_pro=old_qwen=None
    for item in base['new_consumer_records']:
        old=c.read(item['path'])
        name=Path(old['source']['path']).name
        if name=='glm_pro_mtp_state_consumer_test.cc':old_pro=old['object']['path']
        elif name=='qwen_mtp_state_consumer_test.cc':old_qwen=old['object']['path']
        else:raise AssertionError(name)
    assert old_pro and old_qwen
    provider_replacements={};provider_records=[]
    current=R/'.scratch/glm-mlx-flash-original-20261024/batched-bfloat-linear-validation'
    for item in base['retained_current_providers']:
        assert b.identity(item['path'])==item
        old=c.read(item['path']);tag=Path(item['path']).parent.name
        path=current/'compile1'/tag/'identity.json';new_provider=c.read(path)
        assert all(b.identity(x['path'])==x for x in (new_provider['source'],new_provider['object'],*new_provider['dependencies']))
        provider_replacements[old['object']['path'].lower()]=new_provider['object']['path']
        provider_records.append(b.identity(path))
    old_mixed=R/'.scratch/glm-mlx-flash-original-20261024/f32-bfloat-linear-validation'
    unused_tests=[c.read(old_mixed/'compile1'/tag/'identity.json')['object']['path'] for tag in ('cpu-test','cuda-test')]
    unused_tests=[p for p in unused_tests if p.lower() in [arg.lower() for arg in base['command']]]
    removed_tests=[]
    out=S/f'tests-link{attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    image=out/'b09-checks.exe';command=[];removed=replaced=0
    for arg in base['command']:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
        if arg.lower()==old_qwen.lower():removed+=1;continue
        if arg.lower() in [p.lower() for p in unused_tests]:removed_tests.append(arg);continue
        if arg.lower()==old_pro.lower():replaced+=1;arg=new['object']['path']
        arg=provider_replacements.get(arg.lower(),arg)
        command.append(arg)
    assert removed==replaced==1
    assert len(removed_tests)==len(unused_tests)
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,base=b.identity(BASE/'link-plan.json'),
        consumer_record=b.identity(new_path),retained_current_providers=provider_records,
        retained_product_records=base['retained_product_records'],removed_unused_consumers=[old_qwen,*removed_tests],
        note='Fresh actual-pinned Pro TU; unused Qwen TU removed, no stale header COMDAT.',SDK_builds=0,NVCC_builds=0))
    env,_=b.environment(command,[],out);c.execute('link',command,env,out)
    runtime=c.read(BASE/'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path'])==dll
        os.link(dll['path'],out/Path(dll['path']).name)
    runtime['previous']=b.identity(BASE/'runtime-environment.json')
    runtime['PATH']=runtime['PATH'].replace(str(BASE),str(out))
    runtime['staged_dlls']=[b.identity(x) for x in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime)
    c.save(out/'ready.json',dict(image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json')))
    print('LINKED actual B09; native pending',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=('compile','link'))
    parser.add_argument('--link-attempt',type=int,default=1)
    parser.add_argument('--compile-attempt',type=int,default=1)
    args=parser.parse_args();compile_one(args.compile_attempt) if args.action=='compile' else link(args.link_attempt,args.compile_attempt)
