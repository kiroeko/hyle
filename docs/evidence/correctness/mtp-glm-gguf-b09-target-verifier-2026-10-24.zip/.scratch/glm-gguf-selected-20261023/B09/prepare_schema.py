"""Offline B09 role schema and necessary-header plan; no network/body mode."""
import collections
import hashlib
import json
import math
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[2]
AUDIT = R / '.scratch/gguf-weight-audit.json'
AUDIT_SHA = 'cc69c6fbb4e41f10d7d0135bb1fcb7748776e0b491b5f66009fcb0b6f17b8555'
REPO = 'unsloth/GLM-5.3-GGUF'
REV = '346b3591c7f28d1a23716f97a065ecf12ec14771'
FIRST = 'UD-Q4_K_XL/GLM-5.3-UD-Q4_K_XL-00001-of-00011.gguf'
TYPES = {'F32': (0, 1, 4), 'Q8_0': (8, 32, 34),
         'Q4_K': (12, 256, 144), 'Q5_K': (13, 256, 176), 'Q6_K': (14, 256, 210)}


def identity(path):
    raw = path.read_bytes()  # Only named small source/metadata, never weight bodies.
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    text = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path.exists():
        assert path.read_text(encoding='utf-8') == text, 'Do not replace a different prepared schema'
    else:
        path.write_text(text, encoding='utf-8')


def main():
    assert identity(AUDIT)['sha256'] == AUDIT_SHA
    audit = json.loads(AUDIT.read_text())['glm53_ud_q4_k_xl']
    assert (audit['repo'], audit['revision'], audit['first_file']) == (REPO, REV, FIRST)
    assert audit['complete'] and len(audit['tensors']) == audit['tensor_count'] == 1809
    counts = collections.Counter(row['shard'] for row in audit['tensors'])
    roles = []
    for row in audit['tensors']:
        name = row['name']
        if name.startswith('blk.78.'):
            section = 'nextn'
        elif name.startswith('blk.77.'):
            section = 'target77'
        elif name in ('token_embd.weight', 'output.weight'):
            section = 'vocabulary'
        elif name == 'output_norm.weight':
            section = 'target_norm'
        else:
            continue
        code, block, physical = TYPES[row['dtype']]
        shape = list(map(int, row['shape']))
        assert shape[0] % block == 0
        size = math.prod(shape) // block * physical
        expert = '_exps.' in name
        roles.append(dict(name=name, section=section, dtype=row['dtype'], dtype_code=code,
            gguf_dimensions=shape, bytes=size, source_shard=row['shard'],
            source_file=FIRST.replace('00001-of-00011', f"{row['shard']:05d}-of-00011"),
            selected_source=expert, expert_bytes=size // 256 if expert else None,
            data_relative_half_open=None, absolute_inclusive=None, payload_sha256=None))
    assert len(roles) == 53 and len({row['name'] for row in roles}) == 53
    static = [row for row in roles if not row['selected_source']]
    assert len(static) == 47
    files = []
    for shard in (1, 2, 11):
        file = FIRST.replace('00001-of-00011', f'{shard:05d}-of-00011')
        files.append(dict(shard=shard, file=file, url=f'https://huggingface.co/{REPO}/resolve/{REV}/{file}',
            expected_tensor_count=counts[shard],
            purpose='Actual architecture/indexer/RoPE/route/norm metadata' if shard == 1 else
                ('Two own vocab banks and distinct target norm' if shard == 2 else 'Original target77 and NextN78 banks'),
            data_base=None, etag=None, whole_file_bytes=None, original_header_sha256=None,
            metadata_limit_bytes=16 * 1024 * 1024 if shard == 1 else 1024 * 1024))
    save(S / 'roles-schema.json', dict(id='B09', repository=REPO, revision=REV, variant='UD-Q4_K_XL',
        evidence=identity(AUDIT), audit_key='glm53_ud_q4_k_xl', roles=roles,
        physical_role_count=53, static_roles=47, static_bytes=sum(x['bytes'] for x in static),
        full_expert_source_roles=6, acquire_full_expert_bank=False,
        nextn_expert_bytes_per_id=sum(x['expert_bytes'] for x in roles if x['selected_source'] and x['section'] == 'nextn'),
        target_expert_bytes_per_id=sum(x['expert_bytes'] for x in roles if x['selected_source'] and x['section'] == 'target77'),
        payload_requested=False, complete_absolute_ranges=False, generated_pins=False,
        note='Target indexer five-role acquisition is conditional on the actual shared-index metadata/contract; schema retains all original names without claiming every role executes.'))
    save(S / 'headers-needed.json', dict(id='B09', repository=REPO, revision=REV, files=files,
        evidence=identity(AUDIT), maximum_request_bytes=256 * 1024,
        metadata_upper_bound_bytes=sum(x['metadata_limit_bytes'] for x in files),
        tensor_payload_bytes=0, complete_absolute_ranges=False, network_executed=False,
        method='Reuse the pinned structural GGUF metadata reader and strict206/ETag helper under net-only budget transport. Preserve the original raw metadata; reparse retained indexer_types/RoPE arrays from raw bytes. Never infer offsets from other variants.',
        required_retained_metadata=['general.architecture', 'glm-dsa.embedding_length',
            'glm-dsa.attention.key_length', 'glm-dsa.attention.value_length',
            'glm-dsa.attention.q_lora_rank', 'glm-dsa.attention.kv_lora_rank',
            'glm-dsa.attention.key_length_mla', 'glm-dsa.attention.value_length_mla',
            'glm-dsa.attention.indexer.types', 'glm-dsa.attention.indexer.top_k',
            'glm-dsa.nextn_predict_layers', 'glm-dsa.rope.freq_base']))
    print(json.dumps(dict(schema=identity(S / 'roles-schema.json'), headers=identity(S / 'headers-needed.json'),
        network_requests=0, generated_pins=False)))


if __name__ == '__main__':
    main()
