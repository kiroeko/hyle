#pragma once
#include <array>
#include <string_view>
#include "original_named_role_source.h"
// Actual completed original packed/F32 files. No full expert-bank payload pins.
namespace glm_gguf_b09_artifacts {
inline constexpr std::string_view kRepository="unsloth/GLM-5.3-GGUF";
inline constexpr std::string_view kRevision="346b3591c7f28d1a23716f97a065ecf12ec14771";
inline constexpr std::string_view kVariant="UD-Q4_K_XL";
inline constexpr std::string_view kStaticPlanSha256="e7aa49e97ce1981f1f9f4a1617b5f6bc2809377ea89e10699fe39bd8665007d7";
inline constexpr std::string_view kExpertSourcePlanSha256="6db8092339681f868047e800f95d6076d64a301c13c0da5679a2696cd5582d84";
inline constexpr std::string_view kStaticAcquisitionSha256="aa4da34b0d3c9d2ebd2f1149d9e5d197feacb3bf02fa45bf003d4c21d017e5d5";
inline constexpr std::string_view kStaticManifestSha256="c3d486a865f34f2a8b4c6443a38b578765935f3c162a9ecb21a5526c6efd53b6";
inline const std::array<original_named_role_source::PinnedFile,47> kStaticPins47{{
    {"output.weight.bin","ad411388a9b89d5481de4fbb8c62602bf7cc7bf439632a349e788781715dcf84"},
    {"output_norm.weight.bin","9d4827759803436c0b369a326f0f97406a1446d58c0420514b1fa50091c19a6f"},
    {"token_embd.weight.bin","bf3324349244d42ddf91012b333f7163461a303dfe98c3a2995c9d34b354ead9"},
    {"blk.77.attn_k_b.weight.bin","1d6609c52ec97e2879a31e2849d77ac5c4f8103708562d22da57889910876415"},
    {"blk.77.attn_kv_a_mqa.weight.bin","f1f361b3f5ada27844c2b9de90ba45c5be06c103a1d230b77605cdf4ab203e24"},
    {"blk.77.attn_kv_a_norm.weight.bin","385e04bde2bf99cdf40300b9b0fe2b7a8537428313792c0d1ed2c43349efebf9"},
    {"blk.77.attn_norm.weight.bin","9c7b43d8caaaa43ef371db5e960c3d91fe831fc505cc6aaaf6610c564aa8889f"},
    {"blk.77.attn_output.weight.bin","29cc7948f239fee5128fef34512615396e24ab4829a20203ec5e67a86bf304be"},
    {"blk.77.attn_q_a.weight.bin","4845ed45e9d2f661d15b91a42dc23985f44b0c77cfa69e4d0750cdd0dea76709"},
    {"blk.77.attn_q_a_norm.weight.bin","32ac15253d2d5c947f048b8c4f5fa16d982547728fd243d581593f7c4edc77f2"},
    {"blk.77.attn_q_b.weight.bin","44f2492a2361e3788baec332555a8785ba825bc3136fc4dc34070d04aaae395b"},
    {"blk.77.attn_v_b.weight.bin","41426af46e95d7c505c78518cfd3c211e6c1e1334067615ab96a948a51e3019b"},
    {"blk.77.exp_probs_b.bias.bin","bf96e8aeb9a603280b39e35e522811e07451966b05f21f335b769552e587d351"},
    {"blk.77.ffn_down_shexp.weight.bin","fec7c3406c1ec704133ffd5a553a947164c4b6d6698e6109412226f8fedc09b0"},
    {"blk.77.ffn_gate_inp.weight.bin","45cc532fe1651dfdef91543f54d0ebcbab74fa7007e48d20ab9d7bfb731b1818"},
    {"blk.77.ffn_gate_shexp.weight.bin","24d26c664f0e678a247dcade098024131e538c8ab500b3e04e1a9333785d2c01"},
    {"blk.77.ffn_norm.weight.bin","5a41130630213223fae599baa3656ab18ad51b955a35b1e053d73a7e83b8feb3"},
    {"blk.77.ffn_up_shexp.weight.bin","d453e487066f11e3dc90c4a5b6535a3dbe71da9d4952771b0f6a505250f0a373"},
    {"blk.77.indexer.attn_k.weight.bin","390e00ef5c94fa854fbc59b0d769fbfe6662bf0e3a021fc757348e48d85d1fce"},
    {"blk.77.indexer.attn_q_b.weight.bin","b883cb90a89d467390ffe529457c9c4c593ea3cb5601ab3f4f5d759ee6c9aef6"},
    {"blk.77.indexer.k_norm.bias.bin","8fd6848338805d83a94359cb8d45f91ecd5236885bedd704716575c4385257fa"},
    {"blk.77.indexer.k_norm.weight.bin","7fb50640dcdc306c7595012f4d32b5e2d38c4f9b61bfe131253416d5e3666d9d"},
    {"blk.77.indexer.proj.weight.bin","03bafabfe65fd6d284a7c6668b27f9af37a66e9b987670b6a4ab3e8bbbf9ed01"},
    {"blk.78.attn_k_b.weight.bin","e9817c53975fe1f8abea76ee0b880b197f85573f642fe4f2674b11a04e081b75"},
    {"blk.78.attn_kv_a_mqa.weight.bin","b1cf2790f08f36ee2e83638e9f2e01130e326267020e40d460f1dda9b4c4a33c"},
    {"blk.78.attn_kv_a_norm.weight.bin","e21b7631c8bd4629fcb6cc7c40a3b56b6c0724ee0123ddaf69e4806406b1228e"},
    {"blk.78.attn_norm.weight.bin","917ba53f9e10445e0ef854daffe4c7d7ad81fdee6842134238061478ea4b86f7"},
    {"blk.78.attn_output.weight.bin","6fa790511a40e8cc1df88d779e0b8abca5782392e465b8327af12f87755f5a99"},
    {"blk.78.attn_q_a.weight.bin","9469cfcedc6c35af74adb34a8e9710a04629b3d6091f92c0f7c339f88f0f542c"},
    {"blk.78.attn_q_a_norm.weight.bin","8f5c308c2870728d8302923fe72c89a9e04f16e1039be6451695b361aabf41e7"},
    {"blk.78.attn_q_b.weight.bin","5efd1b7a612a81ae505ad526d40ab2f4eac4ae725315fff1cbfa124411fa36af"},
    {"blk.78.attn_v_b.weight.bin","1217cebb94b3cc6b88192c28666e5cbac762fa47af4fb09757e8c0d93620b613"},
    {"blk.78.exp_probs_b.bias.bin","ef9c892ebbf350e5e120c4f252e07ae6ec18e11c7e0e9d25cb8a213241483795"},
    {"blk.78.ffn_down_shexp.weight.bin","2419bb8af4f9b7e8e66859d38fd8d380c04f18de6f9d8fa85f2bce1de4f2aa0a"},
    {"blk.78.ffn_gate_inp.weight.bin","cb451a3bd6feb855051875887bba58286437f18f305692707075a67b3a6de387"},
    {"blk.78.ffn_gate_shexp.weight.bin","9dc1fcf9917df80007beb056b662f218958d7346857392d154de3e23fbc36b75"},
    {"blk.78.ffn_norm.weight.bin","f34dd1a27eb420fcf7212b575c47500674fa4406e9e83b095e65df04c507218d"},
    {"blk.78.ffn_up_shexp.weight.bin","dc83c19aefcb1f8786d00b46aaafbb3c1d7a86ef54dc1208d57d53f0f7f13819"},
    {"blk.78.indexer.attn_k.weight.bin","a00540f544f42d72730a439bb9e554a5f70f86d38de043a9abbb63acbcd1276e"},
    {"blk.78.indexer.attn_q_b.weight.bin","d8561a38fc86eef8b07f167e7b7c4b2dd3e8d84f310bc40922e0e245ad912dda"},
    {"blk.78.indexer.k_norm.bias.bin","a7f237d78b20533897a9b578fbb59f01e89f875df8ab61c36e97c377fbfeb9a3"},
    {"blk.78.indexer.k_norm.weight.bin","d00ef9d3eb0f69c4c11db75728b14ee5c52ffdc1868f547ba64432402f03d853"},
    {"blk.78.indexer.proj.weight.bin","9e0896a3d0f688125257bf4689a2327039d2ca8c37ba3fdd4ad6185f6471ca10"},
    {"blk.78.nextn.eh_proj.weight.bin","1c6d31a788bf0d11f7b3f550c4d52525c9f35534b785a2364d661d2346901673"},
    {"blk.78.nextn.enorm.weight.bin","3ffe08e248ff7728fa80508955b6d06f08df15547eb5a393ff0b8f0acc82e094"},
    {"blk.78.nextn.hnorm.weight.bin","04739e49fc29ff84609204306dc01c1fcd86a88b5a327a85f6b4579f3ddb2f44"},
    {"blk.78.nextn.shared_head_norm.weight.bin","3911a7fc3b257acb8df6784075eccfd6f1c9a7894cc0daebc6ed48ecf4d696c4"},
}};
inline const auto &kStaticPins=kStaticPins47;
} // namespace glm_gguf_b09_artifacts
