"""Root-only S01 incremental Qwen TU on the published B05 cached ABI.
Compile requires the completed real pin header. No SDK/NVCC/full rebuild.
"""
from pathlib import Path
import argparse
import ast
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
QB = R / '.scratch/qwen-bfloat-selected-20261023'
CA = R / '.scratch/dspark-pro-target-draft-20261023'
BASE = QB / 'tests-link8'
RECIPE = CA / 'compile10/qwen-state-bfloat/identity.json'
SOURCE = R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc'
TAG = 'qwen-state'
MACRO = '/DHYLE_TEST_QWEN_GGUF_ARTIFACTS_HEADER='


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


cached = load('w02_cached_abi', CA / 'build.py')
b, c = cached.b, cached.c


def current(row):
    assert b.identity(row['path']) == row, row['path']


def artifacts(header):
    header = Path(header).resolve()
    assert header.is_relative_to(R) and header.is_file()
    paths = [header, S / 'S01/roles-plan.json', S / 'S01/original-roles/acquisition.json',
             S / 'S01/original-roles/manifest.json', S / 'S01/original-roles/sidecar-files.json']
    receipt, manifest = c.read(paths[2]), c.read(paths[3])
    assert receipt['complete'] is True and manifest['complete'] is True
    assert receipt['original_roles'] == manifest['original_roles'] == 18
    assert receipt['role_payload_bytes'] == manifest['source_bytes'] == 1358645248
    assert receipt['source_plan']['sha256'] == b.identity(paths[1])['sha256']
    assert manifest['source_receipt'] == b.identity(paths[2]) or (
        manifest['source_receipt']['sha256'] == b.identity(paths[2])['sha256'] and
        (R / manifest['source_receipt']['path']).resolve() == paths[2].resolve())
    text = header.read_text(encoding='utf-8-sig')
    assert 'namespace qwen_gguf_original_artifacts::s01' in text
    assert b.identity(paths[2])['sha256'] in text and receipt['source_plan']['sha256'] in text
    for row in receipt['roles']:
        assert row['complete'] and row['payload']['sha256'] in text
        path = R / row['payload']['path']
        assert path.is_file() and path.stat().st_size == row['payload']['bytes']
    return [b.identity(path) for path in paths]


def host(attempt, header):
    pin_inputs = artifacts(header)
    recipe = c.read(RECIPE)
    assert c.read(RECIPE.with_name('compile.result.json'))['exit'] == 0
    out = S / f'compile{attempt}' / TAG
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    command = b.host_command(recipe['command'], SOURCE, TAG, out)
    assert all(flag in command for flag in ('/W4', '/WX', '/O2', '/MD',
        '/DHYLE_TEST_QWEN_STATE_CPU=1', '/DHYLE_TEST_QWEN_STATE_CUDA=1'))
    assert not any(arg.startswith(MACRO) for arg in command)
    # Passing an argument list preserves literal quote characters for the /D
    # string macro. Forward slashes avoid C string escape sequences in #include.
    command.insert(1, MACRO + '"' + Path(header).resolve().as_posix() + '"')
    frozen = b.identity(SOURCE)
    snapshot = out / 'source' / SOURCE.relative_to(R)
    snapshot.parent.mkdir(parents=True)
    snapshot.write_bytes(SOURCE.read_bytes())
    (out / 'artifacts-header.h').write_bytes(Path(header).read_bytes())
    c.save(out / 'plan.json', dict(source=frozen, command=command, recipe=b.identity(RECIPE),
        artifact_inputs=pin_inputs, script=b.identity(__file__), host_translation_units=1,
        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / (TAG + '-deps.json'))['Data']
    paths = list(dict.fromkeys([data['Source'], *data['Includes']]))
    assert c.key(header) in {c.key(path) for path in paths}, 'Actual generated pin header missing from compiler dependencies'
    current(frozen)
    for row in pin_inputs:
        current(row)
    c.save(out / 'identity.json', dict(source=frozen, object=b.identity(out / (TAG + '.obj')),
        command=command, recipe=b.identity(RECIPE), dependencies=[b.identity(path) for path in paths],
        artifact_inputs=pin_inputs, script=b.identity(__file__)))
    print('COMPILED one Qwen TU with real S01 pin dependency and unchanged CPU/CUDA ABI', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['compile'])
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--artifacts-header', type=Path, required=True)
    args = parser.parse_args()
    assert args.attempt > 0
    host(args.attempt, args.artifacts_header)
