"""Generate S01 immutable pins only from a completed fixed-range acquisition.
No network, body hashing, build or runtime. This script is not run by preparation.
"""
from pathlib import Path
import argparse, hashlib, json, re

ROOT=Path(__file__).resolve().parents[4]
STAGE=ROOT/'.scratch/qwen-gguf-selected-20261023'
PLAN=STAGE/'S01/roles-plan.json'
PLAN_SHA='135700f6cf253e6e3384a21dfd4baa40b11b6fb9571cbb07d03dc1218c47fe61'
NAMES=[
 'blk.64.attn_k.weight','blk.64.attn_k_norm.weight','blk.64.attn_norm.weight',
 'blk.64.attn_output.weight','blk.64.attn_q.weight','blk.64.attn_q_norm.weight','blk.64.attn_v.weight',
 'blk.64.ffn_down.weight','blk.64.ffn_gate.weight','blk.64.ffn_up.weight',
 'blk.64.nextn.shared_head_norm.weight','blk.64.post_attention_norm.weight',
 'token_embd.weight','output.weight','blk.64.nextn.enorm.weight','blk.64.nextn.hnorm.weight',
 'blk.64.nextn.eh_proj.weight','output_norm.weight']

def pin(text):
 return isinstance(text,str) and re.fullmatch('[0-9a-f]{64}',text) is not None

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--directory',type=Path,required=True,help='actual completed S01 loose-role directory')
 parser.add_argument('--receipt',type=Path,required=True)
 parser.add_argument('--output',type=Path,required=True,help='qwen_gguf_original_artifacts.h, explicitly supplied to the compile')
 args=parser.parse_args()
 assert hashlib.sha256(PLAN.read_bytes()).hexdigest()==PLAN_SHA,'fixed actual S01 plan changed'
 plan=json.loads(PLAN.read_text());receipt_bytes=args.receipt.read_bytes();receipt=json.loads(receipt_bytes)
 assert receipt.get('complete') is True,'no pins are generated before actual complete acquisition'
 for key in ('repository','revision'):
  assert receipt[key]==plan[key],key
 assert receipt['source_plan']['sha256']==PLAN_SHA
 assert receipt['original_roles']==18 and receipt['role_payload_bytes']==plan['source_bytes']==1358645248
 assert receipt['whole_shard_request'] is False and receipt['original_file_reconstructed_on_disk'] is False
 assert pin(receipt['original_file_sha256'])
 by_name={row['name']:row for row in receipt['roles']}
 expected={row['name']:row for row in plan['roles']}
 assert len(by_name)==len(receipt['roles'])==18 and set(by_name)==set(expected)==set(NAMES)
 files=[]
 for name in NAMES:
  row=by_name[name];spec=expected[name]
  assert row['complete'] is True and row['dtype']==spec['dtype'] and row['bytes']==spec['bytes'],name
  assert row['dtype_code']==spec['dtype_code'] and row['shape']==spec['shape'],name
  assert row['absolute_inclusive']==spec['absolute_inclusive']
  assert row['data_relative_half_open']==spec['data_relative_half_open']
  shard=plan['shards'][spec['source_shard']]
  assert row['url']==shard['url'] and row['etag']==shard['etag'] and row['whole_file_bytes']==shard['whole_file_bytes']
  payload=row['payload'];path=(ROOT/payload['path']).resolve()
  actual=(args.directory/spec['filename']).resolve()
  assert path==actual and path.is_file() and path.stat().st_size==payload['bytes']==spec['bytes'],name
  assert pin(payload['sha256']),name
  assert row['filename']==spec['filename']
  # Completed per-role chunk certificates must cover the exact physical payload.
  at=0
  for chunk in row['chunks']:
   assert chunk['offset']==at and chunk['bytes']>0 and pin(chunk['sha256']),name
   first=spec['absolute_inclusive'][0]+at
   assert chunk['absolute_range_inclusive']==[first,first+chunk['bytes']-1],name
   at+=chunk['bytes']
  assert at==spec['bytes'],name
  files.append((spec['filename'],payload['sha256']))
 # The downloader's small constructor table is authenticated transitively by
 # its completed manifest and source receipt; map by NAME, never physical ordinal.
 files_path=args.directory/'sidecar-files.json';manifest_path=args.directory/'manifest.json'
 files_bytes=files_path.read_bytes();files_metadata=json.loads(files_bytes)
 manifest_bytes=manifest_path.read_bytes();manifest=json.loads(manifest_bytes)
 def same_identity(record,path,raw):
  assert (ROOT/record['path']).resolve()==path.resolve()
  assert record['bytes']==len(raw) and record['sha256']==hashlib.sha256(raw).hexdigest()
 same_identity(files_metadata['manifest'],manifest_path,manifest_bytes)
 same_identity(manifest['source_receipt'],args.receipt,receipt_bytes)
 assert files_metadata['complete'] is True and manifest['complete'] is True
 assert files_metadata['constructor']=='qwen27_original_nextn_roles::sidecar_manifest'
 for metadata in (files_metadata,manifest):
  assert metadata['repository']==plan['repository'] and metadata['revision']==plan['revision'] and metadata['file']==plan['file']
 assert manifest['source_plan']['sha256']==PLAN_SHA and manifest['original_file_sha256']==receipt['original_file_sha256']
 assert len(files_metadata['roles'])==18 and [row['name'] for row in files_metadata['roles']]==NAMES
 for row,(filename,digest) in zip(files_metadata['roles'],files,strict=True):
  assert row['file']==filename and row['sha256']==digest
  spec=expected[row['name']]
  assert row['shape']==spec['shape'] and row['dtype']==spec['dtype'] and row['dtype_code']==spec['dtype_code']
  assert row['bytes']==spec['bytes'] and row['absolute_inclusive']==spec['absolute_inclusive']
 quote=lambda s:json.dumps(s,ensure_ascii=True)
 lines=['#pragma once','#include "qwen27_original_nextn_roles.h"',
        '#include "d5_qwen38_gdn_fixture.h"','namespace qwen_gguf_original_artifacts::s01 {',
        'inline constexpr auto kReceiptSha256='+quote(hashlib.sha256(receipt_bytes).hexdigest())+';',
        'inline constexpr auto kPlanSha256='+quote(PLAN_SHA)+';',
        'inline constexpr auto kOriginalFileSha256='+quote(receipt['original_file_sha256'])+';',
        'inline constexpr auto kProfile=[] {',
        '  auto p=d5_qwen38_gdn_fixture::kPrimaryGgufProfile;',
        '  p.variant="sidecar:MTP/mtp-Qwen3.8-27B-Q4_0.gguf";',
        '  p.manifest_digest="e94135836ef1ea7fcb4dd77420060378d200f70d55ed2fbc73030661e9d531c8";',
        '  return p;', ' }();',
        'inline std::array<qwen27_original_nextn_roles::PinnedFile,18> files() {',
        '  return {{']
 lines += ['    {'+quote(file)+','+quote(sha)+'},' for file,sha in files]
 lines += ['  }};','}',
           'inline auto manifest(){return qwen27_original_nextn_roles::sidecar_manifest(files());}',
           '} // namespace qwen_gguf_original_artifacts::s01','']
 args.output.parent.mkdir(parents=True,exist_ok=True)
 args.output.write_text('\n'.join(lines),encoding='utf-8',newline='\n')
 print(json.dumps({'output':str(args.output),'bytes':args.output.stat().st_size,
                   'sha256':hashlib.sha256(args.output.read_bytes()).hexdigest(),
                   'roles':18,'payload_bytes':1358645248,'body_hashed':False}))

if __name__=='__main__':main()
