"""Root-only W02/S01 publication, after four exact passes (optional B05 CPU fifth).

Example: python publisher.py --link 1 --runs 1 2 3 4 5
Reads existing results/metadata; no builds, downloads or weight-body hash pass.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
CA = R / '.scratch/dspark-pro-target-draft-20261023'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


shared = load('s01_existing_metadata_publisher', CA / 'publish.py')
build = load('s01_current_build_metadata', S / 'build.py')
shared.TEXT.update({'.patch', '.cuh'})
read, identity, verify, add = shared.read, shared.identity, shared.verify, shared.add
resolve, number, successful = shared.resolve, shared.number, shared.successful
REQUIRED = {build.CASES[key] for key in ('s01cpu', 's01cuda', 'primarycpu', 'primarycuda')}
OPTIONAL = build.CASES['b05cpu']
REPO = 'unsloth/Qwen3.8-27B-GGUF'
REV = '4ca720788d1e01f1bff70c033e0d0028fd02e502'
VARIANT = 'MTP/mtp-Qwen3.8-27B-Q4_0.gguf'
WHOLE_SHA = '50d9ce5a6da381bbcfb31061cf73df94a90e6faf8efeddee379a9cb8f1501c6e'


def retain(folder):
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix.lower() in shared.TEXT:
            add(path)


def artifacts():
    base = S / 'S01'
    receipt_path = add(base / 'original-roles/acquisition.json')
    manifest_path = add(base / 'original-roles/manifest.json')
    receipt, manifest = read(receipt_path), read(manifest_path)
    plan_path = add(verify(receipt['source_plan']))
    plan = read(plan_path)
    for item in (receipt, manifest, plan):
        assert (item['repository'], item['revision'], item['file'], item['original_roles']) == (REPO, REV, VARIANT, 18)
    assert receipt['complete'] is manifest['complete'] is True
    assert receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == manifest['source_bytes'] == plan['source_bytes'] == 1358645248
    assert receipt['whole_shard_request'] is False and receipt['original_file_reconstructed_on_disk'] is False
    assert receipt['original_file_sha256'] == manifest['original_file_sha256'] == WHOLE_SHA
    assert manifest['source_hash_basis']['etag_proven_as_lfs_sha256'] is False
    assert manifest['source_hash_basis']['expected_lfs_sha256'] is None
    assert verify(manifest['source_receipt']) == receipt_path and verify(manifest['source_plan']) == plan_path
    header_path = add(base / 'header.json')
    header = read(header_path)
    assert header['complete'] and header['http_status'] == 206 and header['tensor_payload_bytes'] == 0
    assert header['range'] == [0, 10945407] and header['data_base'] == plan['data_base'] == 10945408
    assert header['whole_file_bytes'] == receipt['whole_file_bytes'] == 1369590656
    assert header['etag'] == receipt['etag'] == manifest['etag'] == plan['shards'][0]['etag']
    raw = verify(header['header'])
    assert header['header'] == plan['shards'][0]['header']
    assert raw.stat().st_size == 10945408
    # Explicit raw-header metadata exception to the shared <10MB text rule.
    shared.files.add(raw)
    actual = {row['name']: row for row in receipt['roles']}
    pinned = {row['name']: row for row in manifest['roles']}
    assert len(actual) == len(pinned) == len(plan['roles']) == 18
    spans = []
    for expected in plan['roles']:
        row, pin = actual[expected['name']], pinned[expected['name']]
        for key in ('name', 'filename', 'dtype', 'dtype_code', 'shape', 'bytes', 'source_shard',
                    'data_relative_half_open', 'absolute_inclusive'):
            assert row[key] == expected[key], (row['name'], key)
        assert row['complete'] and row['bytes'] == row['payload']['bytes'] > 0
        assert (pin['file'], pin['sha256'], pin['bytes'], pin['dtype_code'], pin['shape']) == (
            row['filename'], row['payload']['sha256'], row['bytes'], row['dtype_code'], row['shape'])
        assert re.fullmatch('[0-9a-f]{64}', row['payload']['sha256'])
        body = resolve(row['payload']['path'])
        assert body == receipt_path.parent / row['filename'] and body.stat().st_size == row['bytes']
        first, end = row['data_relative_half_open']
        assert end - first == row['bytes'] and row['absolute_inclusive'] == [10945408 + first, 10945408 + end - 1]
        offset = 0
        for chunk in row['chunks']:
            assert chunk['offset'] == offset and 0 < chunk['bytes'] <= 134217728
            assert chunk['absolute_range_inclusive'] == [10945408 + first + offset, 10945408 + first + offset + chunk['bytes'] - 1]
            assert re.fullmatch('[0-9a-f]{64}', chunk['sha256'])
            offset += chunk['bytes']
        assert offset == row['bytes']
        spans.append((first, end))
    spans.sort()
    assert spans[0][0] == 0 and spans[-1][1] == 1358645248
    assert all(a[1] == b[0] for a, b in zip(spans, spans[1:]))
    sidecar_path = add(base / 'original-roles/sidecar-files.json')
    sidecar = read(sidecar_path)
    assert verify(sidecar['manifest']) == manifest_path and sidecar['complete']
    assert {row['name'] for row in sidecar['roles']} == set(actual)
    for row in sidecar['roles']:
        assert row['sha256'] == actual[row['name']]['payload']['sha256']
    header_pin = base / 'generated/qwen_gguf_original_artifacts.h'
    build.artifacts(header_pin)  # Exact generated pins/constructor inputs, body stat only.
    add(header_pin)
    for name in ('http-requests.json',):
        add(base / name)
    return dict(repository=REPO, revision=REV, file=VARIANT, roles=18, payload_bytes=1358645248,
        manifest=identity(manifest_path), acquisition=identity(receipt_path), range_plan=identity(plan_path),
        constructor_inputs=identity(sidecar_path), generated_header=identity(header_pin),
        raw_header=identity(raw), header_receipt=identity(header_path),
        etag=receipt['etag'], etag_usage='HTTP object/range identity only; not proof of an LFS/content SHA256.',
        original_file_sha256=WHOLE_SHA, original_file_bytes=1369590656,
        original_file_sha256_method=receipt['original_file_sha256_method'],
        external_whole_file_sha_pin_established=False, body_rehashed=False, body_archived=False)


def sources():
    before_path = add(S / 'integration/source-before.json')
    applied_path = add(S / 'integration/applied.json')
    before, applied = read(before_path), read(applied_path)
    assert len(before) == len(applied['actual_sources']) == 4
    snapshots = []
    for row in before:
        path = add(S / 'integration/source-before' / row['path'])
        snap = identity(path)
        assert (snap['bytes'], snap['sha256']) == (row['bytes'], row['sha256'])
        snapshots.append(dict(original=row, snapshot=snap))
    for row in applied['actual_sources']:
        add(verify(row))
    patch = add(S / 'offline/consumer-proposal/combined.patch')
    assert identity(patch)['sha256'] == applied['patch']['sha256']
    proof_id, pairs = build.retained_proof()
    add(verify(proof_id))
    for pair in pairs:
        add(verify(pair['cached_snapshot']))
        add(verify(pair['current_header']))
    mathematics = S / 'S01/reference-proposal/source-math.json'
    math = read(add(mathematics))
    for row in math['source_files']:
        add(verify(row['identity']))
    add(verify(math['route_scope']['small_batch_domain_proof']))
    for name in ('offline-proof.json', 'reference.patch'):
        add(mathematics.parent / name)
    add(S / 'offline/consumer-proposal/generate_s01_artifacts.py')
    add(S / 'offline/consumer-proposal/notes.json')
    return dict(before=snapshots, final=applied['actual_sources'], patch=identity(patch),
        retained_header_equivalence=proof_id, source_math=identity(mathematics),
        source_math_note='Archived proposal records are historical. Final reference requires an explicit actual embedding codec; it has no implicit Q4_K default.')


def linked(attempt):
    folder = S / f'tests-link{attempt}'
    ready = read(add(folder / 'ready.json'))
    verify(ready['image'])
    successful(folder / 'link.result.json')
    plan = read(add(verify(ready['link_plan'])))
    assert all(plan[key] == 0 for key in ('SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'product_host_translation_units'))
    assert plan['host_translation_units'] == 1
    proof_id, _ = build.retained_proof()
    assert plan['retained_header_equivalence'] == proof_id
    inputs = {verify(row) for row in plan['inputs']}
    current_host = verify(ready['source_record'])
    archived_dependencies = []
    for row in plan['compiled_records']:
        path = add(verify(row))
        record = read(path)
        assert verify(record['object']) in inputs
        verify(record['source'])
        for dependency in record['dependencies']:
            if path == current_host:
                value = verify(dependency)
                if value.is_relative_to(R) and value.relative_to(R).parts[0] in ('include', 'src', 'tests'):
                    add(value)
                    archived_dependencies.append(dependency)
            else:
                build.retained_current(dependency)
        if path == current_host:
            successful(path.with_name('compile.result.json'))
            retain(path.parent)
            assert any(resolve(item['path']) == S / 'S01/generated/qwen_gguf_original_artifacts.h' for item in record['dependencies'])
    assert any(resolve(item['path']) == current_host for item in plan['compiled_records'])
    for row in ready['artifact_inputs']:
        add(verify(row))
    runtime = read(add(folder / 'runtime-environment.json'))
    for row in runtime['staged_dlls']:
        verify(row)  # Identity only. DLLs, executables, objects and SDKs are not archived.
    retain(folder)
    return dict(image=ready['image'], source_record=ready['source_record'], link_plan=ready['link_plan'],
        artifact_inputs=ready['artifact_inputs'],
        runtime=identity(folder / 'runtime-environment.json'), current_dependencies=archived_dependencies,
        retained_header_equivalence=proof_id, host_translation_units=1, product_host_translation_units=0,
        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0)


def case(attempt, linked_image):
    folder = S / f'checks{attempt}'
    summary = read(add(folder / 'summary.json'))
    process = summary['process']
    image = linked_image['image']
    assert summary['terminal'] and process['exit'] == 0 and not process['timed_out']
    assert summary['image'] == image and resolve(process['command'][0]) == resolve(image['path'])
    for key in ('source_record', 'link_plan', 'artifact_inputs', 'retained_header_equivalence'):
        assert summary[key] == linked_image[key], (attempt, key)
    assert summary['tests'] == len(summary['cases']) == 1
    assert not any(summary[key] for key in ('failures', 'errors', 'disabled', 'skips'))
    assert summary['throughput_evidence'] is summary['whole_original_model'] is False
    root = ET.parse(add(folder / 'results.xml')).getroot()
    assert int(root.attrib['tests']) == 1 and all(int(root.attrib.get(key, 0)) == 0 for key in ('failures', 'errors', 'disabled'))
    actual = [dict(attributes=item.attrib, properties={p.attrib['name']: p.attrib['value'] for p in item.iter('property')}) for item in root.iter('testcase')]
    assert actual == summary['cases'] and not any(item.find('skipped') is not None or item.find('failure') is not None for item in root.iter('testcase'))
    a, p = actual[0]['attributes'], actual[0]['properties']
    name = a['classname'] + '.' + a['name']
    assert name in REQUIRED | {OPTIONAL} and summary['selected_cases'] == [name]
    assert a['status'] == 'run' and a['result'] == 'completed'
    assert process['command'].count('--gtest_filter=' + name) == 1
    assert number(p, 'actual_submissions') == sum(number(p, key) for key in ('target_submissions', 'nextn_submissions', 'target_verifier_submissions')) > 0
    assert number(p, 'complete_target_draft_resources') == 12
    assert number(p, 'target_verifier_rows') == 2 and number(p, 'target_verifier_matmuls') == 1
    assert number(p, 'target_verifier_full_vocabulary') == 248320 and number(p, 'first_full_target_verifier_values') == 496640
    assert number(p, 'original_native_reference_submissions') == 0
    assert number(p, 'accepted_zero_drafts') > 0 and number(p, 'accepted_one_draft') > 0
    assert number(p, 'accepted_target_conditioned_repairs') == number(p, 'accepted_one_draft')
    assert number(p, 'actual_accepted_kv_repair_submissions') >= number(p, 'accepted_target_conditioned_repairs')
    assert number(p, 'peak_state_backing_bytes') <= number(p, 'state_budget_bytes')
    if name != OPTIONAL:
        assert p['target_verifier_provider'] == ('ggml-cuda' if a['name'].startswith('Cuda') else 'ggml-cpu')
        if 'Sidecar' in name:
            assert number(p, 'draft_head_codec') == 11 and number(p, 'target_head_codec') == 14
            assert number(p, 'original_draft_roles') == 18 and number(p, 'original_draft_source_bytes') == 1358645248
            assert p['draft_artifact'] == VARIANT
            assert p['draft_manifest_receipt_sha256'] == identity(S / 'S01/original-roles/acquisition.json')['sha256']
    env = summary['environment']
    if name == OPTIONAL:
        assert {key for key in env if key.startswith('HYLE_QWEN')} == set(build.b05_environment())
    retain(folder)
    add(S / f'run-plans/checks{attempt}.json')
    return dict(attempt=attempt, summary=identity(folder / 'summary.json'), process=process,
        case=actual[0], graph_submissions=number(p, 'actual_submissions'), scope=summary['scope'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--link', type=int, required=True)
    parser.add_argument('--runs', type=int, nargs='+', required=True)
    parser.add_argument('--destination', type=Path, default=R / 'docs/evidence/correctness/mtp-qwen27-sidecar-target-verifier-2026-10-23.json')
    args = parser.parse_args()
    assert args.link > 0 and args.runs == sorted(set(args.runs)) and min(args.runs) > 0
    protected = shared.protect()
    artifact, source, image = artifacts(), sources(), linked(args.link)
    runs = [case(attempt, image) for attempt in args.runs]
    names = [run['case']['attributes']['classname'] + '.' + run['case']['attributes']['name'] for run in runs]
    assert len(names) == len(set(names)) and set(names) in (REQUIRED, REQUIRED | {OPTIONAL})
    for path in S.glob('*.py'):
        add(path)
    retain(S / 'integration')
    add(CA / 'publish.py')
    prior = [add(R / 'docs/evidence/correctness' / name) for name in (
        'mtp-qwen27-target-verifier-2026-10-23.json', 'mtp-packed-head-m2-2026-10-23.json',
        'mtp-qwen24-bfloat-target-verifier-2026-10-23.json')]
    for name in ('docs/developer/current-work.md', 'docs/implementation/model-operators.md', 'docs/architecture/compute-design.md'):
        add(R / name)
    graphs = {name: run['graph_submissions'] for name, run in zip(names, runs)}
    destination = args.destination.resolve()
    assert destination.parent == (R / 'docs/evidence/correctness').resolve() and destination.suffix == '.json'
    archive = destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists() and shared.protect() == protected
    assert not any(path.suffix.lower() in ('.exe', '.obj', '.dll', '.lib', '.gguf') or path.name == 'roles.bin' for path in shared.files)
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(shared.files):
            zipped.write(path, path.relative_to(R).as_posix())
    result = dict(date='2026-10-23', stage='W02-S01', goal_complete=False,
        conclusion='Original S01 sidecar draft and independently paired MAIN target63/full-V verifier passed CPU/CUDA; affected primary Q27 paths passed. Optional B05 CPU regression is included only when supplied among the actual passing runs.',
        artifact=artifact, implementation=dict(source_changes=source,
            loader='One immutable manifest-driven original-role source, once-bound readonly banks and strong mapping owners. Actual codec/shape/names/SHA are explicit; no identity fallback, generated replacement vocabulary or new executor.',
            vocabulary='Draft uses its own Q3_K embedding/head. Target uses the explicitly supplied MAIN Q6_K head and distinct target63/global norm. Independent sidecar output_norm is authenticated but the fixed source prefers shared_head_norm when present.',
            numerics='Q3_K code/scales and native AQ8_K or qualified CUDA AQ8_1 reference use actual F32 predecessors and original packed bytes. All Gather calls require an explicit actual codec; old Q4_K/Q6_K/Q8_0 rules remain checked.',
            state='Same K1 controller and twelve-resource StateHead: accept0 chooses after-current; accept1 repairs target-conditioned recursive draft KV before publication. Actual I32 target row leases become pending and drive the next original embedding Gather.'),
        validation=dict(tests=len(runs), failures=0, errors=0, skips=0,
            graph_submissions=sum(graphs.values()), graph_submissions_by_case=graphs,
            runs=runs, linked=image, SDK_builds=0, native_CPU_builds=0, NVCC_builds=0),
        limitations=['Layer62 upstream input, target embedding boundary and finite initial histories remain fixtures; no complete-model/task-quality/TPS or measured-VRAM claim.',
            'Natural K1 and separately controlled matching/rejection trials are not an acceptance-rate estimate.',
            'The exact retained header comment-equivalence proof permits reuse of old objects, not a claim that product/provider code was rebuilt.',
            'Original ETag is only HTTP object identity. The recorded whole-file SHA was streamed from authenticated bytes; no independent external full-file SHA pin is established.',
            'The archived pre-native run-plan-directory failure started no native process and counts as no passing test. Historical proposal records are not later execution claims.'],
        prior_evidence=[identity(path) for path in prior], protection=protected,
        archive=identity(archive), archive_items=len(shared.files))
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=identity(destination), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert shared.protect() == protected
    print(json.dumps(dict(**publication, tests=len(runs), graphs=sum(graphs.values()))))


if __name__ == '__main__':
    main()
