param([ValidateSet('Build','Test')][string]$Action)
$ErrorActionPreference = 'Stop'
$projectRoot = 'C:\public\project-hyle\hyle'
$buildRoot = 'C:\hv\m2b1-cpu'
$logRoot = Join-Path $projectRoot '.scratch\validation\m2-b1-apple'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleScatterErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[void][HyleScatterErrorMode]::SetErrorMode(0x8003)
if ((Get-Content -LiteralPath (Join-Path $buildRoot '.hyle-owner') -Raw) -notlike 'M2-B1 CPU development;*') {
    throw 'The reused build directory belongs to another task.'
}
$wrapper = Join-Path $projectRoot 'scripts\hyle-windows.ps1'
if ($Action -eq 'Build') {
    & $wrapper -Action Build -BinaryDir $buildRoot -ExtraArgs @('--parallel','2','--target','hyle_compute_ops_tests') *>&1 |
        Tee-Object -FilePath (Join-Path $logRoot 'scatter-semantics-windows-build.log')
} else {
    $dlls = @(Get-ChildItem -LiteralPath $buildRoot -Filter '*.dll' -File -Recurse)
    $executables = @(Get-ChildItem -LiteralPath $buildRoot -Filter 'hyle_compute_ops*_test.exe' -File -Recurse)
    if ($executables.Count -eq 0) { throw 'No built compute_ops executables found.' }
    foreach ($directory in @($executables.DirectoryName | Sort-Object -Unique)) {
        foreach ($dll in $dlls) {
            $destination = Join-Path $directory $dll.Name
            if ($dll.FullName -ne $destination) { Copy-Item -LiteralPath $dll.FullName -Destination $destination -Force }
        }
    }
    & $wrapper -Action Test -BinaryDir $buildRoot -ExtraArgs @('-R','^hyle_compute_ops.*_test$','--output-on-failure','--parallel','1') *>&1 |
        Tee-Object -FilePath (Join-Path $logRoot 'scatter-semantics-windows-test.log')
    $testExit = $LASTEXITCODE
    Copy-Item -LiteralPath (Join-Path $buildRoot 'Testing\Temporary\LastTest.log') -Destination (Join-Path $logRoot 'scatter-semantics-windows-full-tests.log') -Force
    exit $testExit
}
exit $LASTEXITCODE
