from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

W=Path(__file__).resolve().parent
R=W.parents[1]
ready=json.loads((W/'probe3-ready.json').read_text())
plan=json.loads(Path(ready['plan']['path']).read_text())
runtime=json.loads(Path(ready['runtime']['path']).read_text())
with Path(ready['image']['path']).open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest()==ready['image']['sha256']
env=os.environ.copy()
env.update(runtime.get('configured_flags',{}))
env.update(PATH=str(Path(ready['image']['path']).parent)+';'+runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
F=W/'run3'; F.mkdir()
started=time.perf_counter()
with (F/'stdout.log').open('xb') as out, (F/'stderr.log').open('xb') as err:
    p=subprocess.Popen(plan['run'],cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    print('REVIEW_CPU_PID',p.pid,flush=True)
    timed_out=False
    try: code=p.wait(timeout=90)
    except subprocess.TimeoutExpired:
        timed_out=True; p.kill(); code=p.wait(timeout=10)
record=dict(pid=p.pid,exit=code,timeout=timed_out,seconds=time.perf_counter()-started,command=plan['run'],
    image=ready['image'],native=ready['native'],fixture=ready['fixture_manifest'],
    scope='One cached generated AA/E4 ordinary CPU fixture, greedy; no trained-model quality, GPU pending or performance claim.')
(F/'process.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print((F/'stdout.log').read_text())
assert code==0 and not timed_out,'Actual native failure retained; inspect before correction'
