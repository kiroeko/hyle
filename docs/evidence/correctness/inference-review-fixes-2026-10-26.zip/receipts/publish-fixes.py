"""Publish this bounded review-fix result; never builds or runs a consumer.

Usage: python -B .scratch/inference-review-fixes-20261026/publish-fixes.py publish
The final run3, product2 and probe3 receipts are mandatory. Existing public
evidence is never overwritten. Binary/SDK/model payloads are not packaged.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
A = R / '.scratch/inference-architecture-audit-20261026'
DEST = R / 'docs/evidence/correctness/inference-review-fixes-2026-10-26'
SOURCE = [
    'engine/inference/execution_observation.h',
    'engine/models/qwen35/main.cc',
    'engine/models/qwen35/generation_tokens.h',
    'engine/models/qwen35/batch_probe.cc',
    'engine/models/qwen35/mtp_session_probe.cc',
    'engine/models/qwen35/retained_budget_probe.cc',
    'engine/reporting/execution_report.cc',
    'tests/tools/qwen_e4_cache_case.h',
    'tests/tools/qwen_mtp_prefix_value_probe.cc',
    'tests/tools/qwen_random_mtp_probe.cc',
    'src/compute_provider_native/default_rules.cc',
    'include/hyle/container/small_vector.h',
]
BASIS = [
    'boundaries.json', 'policies.json', 'execution-performance.json',
    'cancel-warmup-independent-review.json', 'cold-timing-eos-review.json',
]
FINAL_PINS = {
    'engine/models/qwen35/main.cc':
        '6ac6884e3beb956cace06f1b623f4451d3ef3c9d2e49c3bb6ed1f5066066beb5',
    'tests/tools/qwen_e4_cache_case.h':
        '484f0e04a2657a9e0bba2628edbcb21e142f4dc2ff5a0049ebc6e9082dc3b6d1',
    'engine/reporting/execution_report.cc':
        'dd5d706f2c02d53ac2baed06e8023344ac20a54ee506bc615fa3e85fd47491a3',
    'engine/inference/execution_observation.h':
        '79d974007f00939bb27890a24adc54bf4beb1132d8a60075fbddc461e8747f0f',
    'engine/models/qwen35/generation_tokens.h':
        'c6278e5f9a07525ed0e5b436cb2dce042b9c413b7f9ad4fb048e69f17570014b',
}


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fact(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def verify_pin(pin):
    actual = fact(pin['path'])
    assert actual['bytes'] == pin['bytes'] and actual['sha256'] == pin['sha256'], actual


def git(*args):
    return subprocess.run(['git', *args], cwd=R, check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout


def prepare():
    product = read(W / 'ready2.json')
    probe = read(W / 'probe3-ready.json')
    assert product['compiled_host_TUs'] == 2 and product['link']['exit'] == 0
    assert all(unit['process']['exit'] == 0 for unit in product['units'])
    assert probe['compiled_probe_TUs'] == 1 and probe['compile']['exit'] == probe['link']['exit'] == 0
    for pin in [product['runtime'], product['link_inputs'], product['source_freeze'],
                probe['runtime'], probe['plan'], probe['link_inputs'], probe['fixture_manifest']]:
        verify_pin(pin)
    # Verify canonical source/dependency receipts without packaging dependency
    # source trees or requiring generated object/binary files to be retained.
    for name in ['source2-freeze.json', 'probe3-source-freeze.json']:
        for pin in read(W / name):
            verify_pin(pin)
    for unit in product['units']:
        verify_pin(unit['source'])
    for rel, expected in FINAL_PINS.items():
        assert sha((R / rel).read_bytes()) == expected, rel
    runs = {name: read(W / name / 'process.json') for name in ['run1', 'run2', 'run3']}
    assert runs['run1']['exit'] == 1 and not runs['run1']['timeout']
    assert b'execution use plans must precede carrier preparation' in (W / 'run1/stderr.log').read_bytes()
    results = {}
    required = ['generated_AA_fixture', 'fork_equal', 'old_readers_unchanged',
                'single_member_discard', 'all_cancel_abort', 'idle_shape_warmup', 'admission_in_step']
    for name in ['run2', 'run3']:
        assert runs[name]['exit'] == 0 and not runs[name]['timeout']
        lines = (W / name / 'stdout.log').read_text(encoding='utf-8').strip().splitlines()
        assert len(lines) == 1
        result = json.loads(lines[0])
        assert result['status'] == 'PASS' and result['backend'] == 'cpu'
        assert all(result[key] is True for key in required)
        assert result['final_versions'] == result['HTTP'] == 0 and result['model_quality'] is False
        results[name] = result
    assert runs['run3']['image'] == probe['image']
    assert runs['run3']['native'] == probe['native']
    assert runs['run3']['fixture'] == probe['fixture_manifest']

    members = {}
    def add(name, data):
        assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
        members[name] = data
    # Bounded receipt files only: no archives, binaries, objects, maps, SDKs,
    # source snapshots of superseded candidates, model weights or trace payloads.
    for path in sorted(W.rglob('*')):
        if not path.is_file() or path.name.startswith('publication-'):
            continue
        if path.suffix.lower() not in {'.py', '.json', '.log', '.cc'}:
            continue
        if path.name == 'running.json':
            continue
        assert path.stat().st_size <= 200_000, str(path)
        add('receipts/' + path.relative_to(W).as_posix(), path.read_bytes())
    source_pins = []
    for rel in SOURCE:
        data = (R / rel).read_bytes()
        add('source/' + rel, data)
        source_pins.append(dict(path=rel, bytes=len(data), sha256=sha(data)))
    assert sum(pin['bytes'] for pin in source_pins) < 2_000_000
    for name in BASIS:
        add('basis/' + name, (A / name).read_bytes())
    add('git/current-worktree.diff', git('diff', '--binary', '--no-ext-diff', 'HEAD', '--', '.'))
    add('git/current-status.txt', git('status', '--short'))
    add('git/head.txt', git('rev-parse', 'HEAD'))
    add('source-pins.json', encode(source_pins))

    main = (R / SOURCE[1]).read_text(encoding='utf-8')
    needles = [
        'hyle::container::SmallVector<std::uint8_t, 2> published_members;',
        'if (step.discard_stopped_members &&\n          !published_members.try_resize(outputs.size(), std::uint8_t{1}))',
        'if (!published_members.empty() && !published_members[j]) continue;',
        'if ((published_members.empty() || published_members[j]) && outputs[j].generation_ledger)',
    ]
    points = []
    for needle in needles:
        assert main.count(needle) == 1, needle
        points.append(dict(line=main[:main.index(needle)].count('\n') + 1, text=needle))
    delta = dict(
        status='FINAL_DELTA_SOURCE_CHECK_AND_RUN3_REPLAY_NOT_ALLOCATION_MEASUREMENT',
        main=next(pin for pin in source_pins if pin['path'] == SOURCE[1]),
        points=points,
        statement='The local SmallVector stays empty on normal publication, including R>2; try_resize is guarded by actual partial withdrawal. The mask remains stack-owned after detach and throughout observers. This introduces no normal-path mask heap allocation; it does not claim the entire step has zero allocations.',
        verification='Final source matches product2/probe3 and run3 receipts. The independent cancellation review predates this final allocation delta; its old source hash is retained honestly as historical basis.',
    )
    add('final-delta-check.json', encode(delta))
    report = dict(
        status='BOUNDED_REVIEW_FIXES_CPU_FIXTURE_PASS',
        scope='Cold exact-shape accounting and idle preparation, ordinary shared-batch member cancellation, and model-local EOS policy consolidation.',
        fixes=[
            'Synchronous unseen-shape admission is included in step_seconds and separately reported as shape_admission_seconds; CUDA Graph recording is a different event.',
            'Idle prepare_execution may admit a bounded ordinary/MTP-prefill exact family using the existing admission mechanism.',
            'Submitted ordinary Text R>1 without a draft cache may withdraw one member publication while surviving members finish their original candidate. Cancelled member head/RNG and uncommitted ledger remain unpublished; typed disposition and observer suppression distinguish the outcome.',
            'All-cancel, pre-submit, R1 and MTP retain whole-episode cancellation. Native completion/export errors still use the whole-episode failure path.',
            'Qwen EOS identifiers live in one model-local header, with consumer/probe call sites updated.',
        ],
        final_product_build=product,
        final_probe_build=probe,
        runs=runs,
        fixture_results=results,
        first_failure=dict(kind='FIXTURE_SETUP_ORDER_ERROR',
            explanation='run1 attempted replay-use planning after carrier preparation and failed before the new arithmetic checks. Only fixture ordering was corrected before run2. Original failure logs are retained.',
            correction='The final normal-path mask allocation change was subsequently rebuilt and run3 passed.'),
        final_delta=delta,
        source_pins=source_pins,
        basis=[dict(file=name, **fact(A / name)) for name in BASIS],
        basis_interpretation='The three architecture audits describe the pre-fix source. In particular policies.json whole-episode cancellation and missing admission timing statements are historical baseline, superseded by the final source and bounded run3. The two reviews state their own older source hashes and are source reviews, not runtime passes.',
        unverified=[
            'Physically pending GPU member cancellation; the CPU completion may already be ready before publication.',
            'Stochastic RNG draw advancement, native fault injection, trained-model quality and full-model correctness.',
            'MTP cancellation semantics are unchanged; no MTP functionality or performance rerun.',
            'Full CUDA batch_probe build/run: batch_probe.cc was migrated after the final build and is included as source-only change.',
            'Other migrated EOS probe translation units were not independently rebuilt or run in this bounded batch.',
            'No prefill/decode/TPS, GPU-memory, overlap benefit or general performance conclusion follows from these CPU fixture runs.',
            'Retained build closure is incremental; 182/195 selected object dependencies are evidenced, with 13 native/third-party inputs outside full per-object header proof. No SDK/device/Graph/provider rebuild.',
        ],
        archive_policy='Metadata/logs, exact final selected sources (<2MB), source pins, current tracked diff and baseline audit/review JSON only. No executables, libraries, objects, PDBs, maps, SDKs, weights, full traces or superseded source candidates.',
    )
    add('report.json', encode(report))
    inventory = [dict(name=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(members.items())]
    add('manifest.json', encode(dict(members=inventory, source_bytes=sum(pin['bytes'] for pin in source_pins))))
    assert sum(map(len, members.values())) < 8_000_000
    return report, members


def publish():
    out_json = DEST.with_suffix('.json')
    out_zip = DEST.with_suffix('.zip')
    assert not out_json.exists() and not out_zip.exists(), 'Never overwrite existing public evidence'
    report, members = prepare()
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_zip, mode='x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            archive.writestr(name, data)
    with zipfile.ZipFile(out_zip) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == sorted(members)
        for name, data in members.items():
            assert archive.read(name) == data
    report['archive'] = dict(**fact(out_zip), members=len(members))
    with out_json.open('xb') as stream:
        stream.write(encode(report))
    receipt = dict(status='PUBLISHED_AND_MEMBER_BYTES_VERIFIED',
                   report=fact(out_json), archive=report['archive'], publisher=fact(__file__))
    (W / 'publication-receipt.json').write_bytes(encode(receipt))
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    assert sys.argv[1:] == ['publish'], __doc__
    publish()
