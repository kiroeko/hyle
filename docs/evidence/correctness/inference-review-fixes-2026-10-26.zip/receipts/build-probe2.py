"""Explicit incremental review-fix build. Root freezes source before execution.

Two canonical engine TUs; one optional private existing-E4 consumer wrapper.
No SDK, Graph, provider, CUDA or full model build. No implicit consumer run.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-result-publication-screen-20261026/candidate'
CPU = R / '.scratch/inference-cpu-region-views-20261026/validation/candidate1'
CLOSURE = R / '.scratch/inference-current-closure-20261026'
FIXTURE = R / '.scratch/inference-e4-model-20261025/fixture-preparation/ct-e4-aa'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n',encoding='utf8')


def pin(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=str(path),bytes=path.stat().st_size,sha256=digest)


def exact(row):
    assert pin(row['path']) == row, row['path']


def key(path):
    return str(path).replace('/','\\').casefold()


def helper():
    path = R / '.scratch/inference-synchronous-step-report-20261025/check_host.py'
    spec = importlib.util.spec_from_file_location('retained_runner',path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compile_command(recipe, source, folder):
    original = read(recipe)['command']
    sources = [x for x in original if x.lower().endswith(('.cc','.cpp','.cxx'))]
    assert len(sources) == 1
    result = []
    for arg in original:
        if arg == sources[0]: arg = str(source)
        elif arg == original[original.index('/sourceDependencies')+1]: arg = str(folder/'dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo'+str(folder/'unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd'+str(folder/'unit.pdb')
        result.append(arg)
    for flag in ('/c','/O2','/Ob2','/MD','/W4','/WX'):
        assert flag in result
    # Canonical recipes have no project source/header shadow or NVTX include.
    for arg in result:
        if arg.startswith('/I'):
            assert not (str(R/'.scratch').casefold() in arg.casefold()), arg
    return result


def quoted_project_closure(seeds):
    todo,found = list(seeds),{}
    dirs = [R, R/'include', R/'engine/models/qwen35', R/'tests/tools', R/'tests/compute_models',
        R/'src/compute', R/'src/compute_ggml_runtime', R/'src/compute_provider_ggml_cuda',
        R/'src/compute_backend_cuda', R/'src/graph', R/'tests/compute_state']
    while todo:
        p = Path(todo.pop()).resolve()
        if key(p) in found: continue
        assert p.is_relative_to(R) and not p.is_relative_to(R/'.scratch')
        found[key(p)] = pin(p)
        for include in re.findall(r'^\s*#\s*include\s*"([^"\r\n]+)"',p.read_text(encoding='utf-8-sig'),re.M):
            for base in [p.parent,*dirs]:
                child = (base/include).resolve()
                if child.is_file():
                    if child.is_relative_to(R) and not child.is_relative_to(R/'.scratch'):
                        todo.append(child)
                    break
    return list(found.values())


def plan():
    assert not (W/'build-plan.json').exists(), 'Preserve the source-frozen plan'
    baseline = read(B/'ready.json')
    inputs = read(baseline['link_inputs']['path'])
    model_old = next(x for x in inputs if key(x['path']).endswith('inference-sampling-three-arm-20261026\\batch\\compile\\unit.obj'))
    report_old = next(x for x in inputs if key(x['path']).endswith('inference-current-closure-20261026\\engine\\report\\unit.obj'))
    units = []
    for name,source,old in [('model',R/'engine/models/qwen35/main.cc',model_old),
                            ('report',R/'engine/reporting/execution_report.cc',report_old)]:
        recipe = CLOSURE/'engine'/name/'command.json'
        units.append(dict(name=name,source=pin(source),recipe=pin(recipe),old=old,
            command=compile_command(recipe,source,W/'product'/name)))
    closure = quoted_project_closure([x['source']['path'] for x in units])
    assert any(key(x['path']).endswith('engine\\inference\\execution_observation.h') for x in closure)
    assert any(key(x['path']).endswith('engine\\models\\qwen35\\generation_tokens.h') for x in closure)
    save(W/'source-freeze.json',closure)
    for row in inputs: exact(row)
    save(W/'build-plan.json',dict(status='SOURCE_FROZEN_NOT_COMPILED',units=units,
        baseline_ready=pin(B/'ready.json'),baseline_link_inputs=baseline['link_inputs'],
        baseline_runtime=baseline['runtime'],baseline_link_command=pin(B/'link/command.json'),
        source_freeze=pin(W/'source-freeze.json'),selected_dependency_scan=pin(W/'selected-dependency-scan.json'),
        unchanged_input_count=len(inputs)-len(units),changed_engine_TUs=2,
        limits=['Incremental build of these review changes against retained f36 CUDA closure; no claim every retained native/provider implementation is current for unrelated changes.',
            'StepObservation direct include and selected per-object dependency scan identify Model/report readers. Existing entry/weights do not include this header. 182/195 selected objects have matched dependency evidence; 13 retained native/third-party objects remain explicitly outside its complete per-object header proof.',
            'default_rules.cc current diff is a comment only; no selected provider rebuild for that edit.',
            'No full model, SDK, native/device, Graph or provider build. Build commands never execute consumers.']))
    print('REVIEW_BUILD_PLAN',json.dumps(pin(W/'build-plan.json')),flush=True)


def execute_product():
    assert not (W/'product').exists() and not (W/'ready.json').exists()
    plan = read(W/'build-plan.json')
    for field in ('baseline_ready','baseline_link_inputs','baseline_runtime','baseline_link_command','source_freeze','selected_dependency_scan'):
        exact(plan[field])
    frozen = read(plan['source_freeze']['path'])
    for row in frozen: exact(row)
    inputs = read(plan['baseline_link_inputs']['path'])
    for row in inputs: exact(row)
    h = helper()
    compiler = plan['units'][0]['command'][0]
    env = h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    objects = {}
    frozen_by_key = {key(x['path']):x for x in frozen}
    for unit in plan['units']:
        exact(unit['source']);exact(unit['recipe'])
        folder = W/'product'/unit['name']
        process = h.execute(unit['command'],env,folder,timeout=120)
        dep = read(folder/'dependencies.json')['Data']
        actual = [pin(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            p = Path(row['path'])
            if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch'):
                assert key(p) in frozen_by_key and row['sha256']==frozen_by_key[key(p)]['sha256'],str(p)
        save(folder/'actual-dependencies.json',actual)
        objects[key(unit['old']['path'])] = pin(folder/'unit.obj')
        save(folder/'result.json',dict(source=unit['source'],object=objects[key(unit['old']['path'])],process=process))
    for row in frozen:exact(row)
    link = []
    for arg in read(plan['baseline_link_command']['path'])['command']:
        if key(arg) in objects: arg=objects[key(arg)]['path']
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(W/'product/link/hyle.exe')
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(W/'product/link/hyle.pdb')
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(W/'product/link/hyle.lib')
        link.append(arg)
    linked = h.execute(link,env,W/'product/link',timeout=120)
    final_inputs = [objects.get(key(x['path']),x) for x in inputs]
    for row in final_inputs:exact(row)
    save(W/'link-inputs.json',final_inputs)
    runtime = read(plan['baseline_runtime']['path'])
    exact(runtime['native'])
    alias = W/'product/link'/Path(runtime['native']['path']).name
    os.link(runtime['native']['path'],alias);runtime['native_hardlink']=pin(alias)
    save(W/'runtime.json',runtime)
    save(W/'ready.json',dict(status='REVIEW_PRODUCT_BUILT_NOT_RUN',image=pin(W/'product/link/hyle.exe'),
        runtime=pin(W/'runtime.json'),link_inputs=pin(W/'link-inputs.json'),source_freeze=plan['source_freeze'],
        units=[read(W/'product'/u['name']/'result.json') for u in plan['units']],link=linked,
        compiled_host_TUs=2,unchanged_inputs=len(inputs)-2,model_runs=0,SDK_device_Graph_provider_builds=0,limits=plan['limits']))
    print('REVIEW_READY',json.dumps(pin(W/'ready.json')),flush=True)


def probe_source():
    source = W/'e4-consumer.cc'
    text = '#include "engine/models/qwen35/main.cc"\n#include "tests/tools/qwen_e4_cache_case.h"\n' \
        'int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("usage: e4-consumer INPUTS");'
    text += 'return qwen_e4_cache_case::run(argv[1]);}catch(const std::exception&e){std::cerr<<"e4_consumer_failure="<<e.what()<<"\\n";return 1;}}\n'
    if source.exists(): assert source.read_text(encoding='utf8')==text
    else: source.write_text(text,encoding='utf8')
    return source


def plan_probe():
    assert not (W/'probe2-plan.json').exists()
    source = probe_source()
    recipe = R/'.scratch/inference-cpu-representative-20261026/compile/model/command.json'
    cpu_ready = read(CPU/'ready.json')
    inputs = read(cpu_ready['model']['link_inputs']['path'])
    old_model = next(x for x in inputs if key(x['path']).endswith('inference-cpu-representative-20261026\\compile\\model\\unit.obj'))
    old_entry = next(x for x in inputs if key(x['path']).endswith('inline-executor1\\compile\\unit.obj'))
    old_report = next(x for x in inputs if key(x['path']).endswith('inference-current-closure-20261026\\engine\\report\\unit.obj'))
    command = []
    for arg in read(CPU/'link-model/command.json')['command']:
        if key(arg) == key(old_model['path']): arg = str(W/'probe2/compile/unit.obj')
        elif key(arg) == key(old_entry['path']): continue
        elif key(arg) == key(old_report['path']): arg = str(W/'product/report/unit.obj')
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(W/'probe2/link/e4-consumer.exe')
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(W/'probe2/link/e4-consumer.pdb')
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(W/'probe2/link/e4-consumer.lib')
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    # Quote closure excludes only this scratch wrapper; all original implementation/test headers remain canonical.
    save(W/'probe2-source-freeze.json',quoted_project_closure([R/'engine/models/qwen35/main.cc',R/'tests/tools/qwen_e4_cache_case.h']))
    save(W/'probe2-plan.json',dict(status='CPU_PROBE_SOURCE_FROZEN_NOT_BUILT',source=pin(source),recipe=pin(recipe),
        command=compile_command(recipe,source,W/'probe2/compile'),source_freeze=pin(W/'probe2-source-freeze.json'),
        cpu_ready=pin(CPU/'ready.json'),cpu_link_inputs=cpu_ready['model']['link_inputs'],
        cpu_link_command=pin(CPU/'link-model/command.json'),cpu_runtime=cpu_ready['runtime'],native=cpu_ready['model']['native_alias'],
        link_command=command,
        replaced_model=old_model,removed_entry=old_entry,replaced_report=old_report,
        fixture_manifest=pin(FIXTURE/'weights.tsv'),run=[str(W/'probe2/link/e4-consumer.exe'),str(FIXTURE)],
        scope='Existing actual E4 AA/H64/D64 CPU fixture/test consumer, including Root shape-admission checks; no new model data or generic product probe. Build never runs this argv.'))
    print('CPU_PROBE_PLAN',json.dumps(pin(W/'probe2-plan.json')),flush=True)


def build_probe():
    assert not (W/'probe2').exists() and not (W/'probe2-ready.json').exists()
    plan = read(W/'probe2-plan.json')
    ready = read(W/'ready.json')
    for field in ('source','recipe','source_freeze','cpu_ready','cpu_link_inputs','cpu_link_command','cpu_runtime','native','fixture_manifest'):
        exact(plan[field])
    for row in read(plan['source_freeze']['path']):exact(row)
    report = read(W/'product/report/result.json')['object'];exact(report)
    removed = {key(plan[name]['path']) for name in ('replaced_model','removed_entry','replaced_report')}
    inputs = read(plan['cpu_link_inputs']['path'])
    for row in inputs:
        if key(row['path']) not in removed:exact(row)
    h = helper();compiler = plan['command'][0]
    env = h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled = h.execute(plan['command'],env,W/'probe2/compile',timeout=120)
    dep = read(W/'probe2/compile/dependencies.json')['Data']
    actual = [pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    frozen = {key(x['path']):x for x in read(plan['source_freeze']['path'])}
    frozen[key(plan['source']['path'])] = plan['source']
    for row in actual:
        p = Path(row['path'])
        if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch') or key(p)==key(plan['source']['path']):
            assert key(p) in frozen and row['sha256']==frozen[key(p)]['sha256'],str(p)
    save(W/'probe2/compile/actual-dependencies.json',actual)
    for row in frozen.values():exact(row)
    obj = pin(W/'probe2/compile/unit.obj')
    final = [obj if key(x['path'])==key(plan['replaced_model']['path']) else report
        if key(x['path'])==key(plan['replaced_report']['path']) else x for x in inputs if key(x['path'])!=key(plan['removed_entry']['path'])]
    linked = h.execute(plan['link_command'],env,W/'probe2/link',timeout=120)
    for row in final:exact(row)
    save(W/'probe2/link-inputs.json',final)
    alias = W/'probe2/link'/Path(plan['native']['path']).name
    os.link(plan['native']['path'],alias)
    runtime = read(plan['cpu_runtime']['path']);runtime['native_hardlink']=pin(alias)
    save(W/'probe2/runtime.json',runtime)
    save(W/'probe2-ready.json',dict(status='FINITE_E4_CPU_PROBE_BUILT_NOT_RUN',image=pin(W/'probe2/link/e4-consumer.exe'),
        runtime=pin(W/'probe2/runtime.json'),plan=pin(W/'probe2-plan.json'),link_inputs=pin(W/'probe2/link-inputs.json'),
        compile=compiled,link=linked,run=plan['run'],native=pin(alias),fixture_manifest=plan['fixture_manifest'],
        current_report=report,compiled_probe_TUs=1,SDK_device_builds=0,model_runs=0))
    print('CPU_PROBE_READY',json.dumps(pin(W/'probe2-ready.json')),flush=True)


if __name__ == '__main__':
    action = sys.argv[1:]
    if action == ['plan']: plan()
    elif action == ['build']: execute_product()
    elif action == ['plan-probe']: plan_probe()
    elif action == ['build-probe']: build_probe()
    else: raise SystemExit('Usage: python -B '+str(__file__)+' plan | build | plan-probe | build-probe')
