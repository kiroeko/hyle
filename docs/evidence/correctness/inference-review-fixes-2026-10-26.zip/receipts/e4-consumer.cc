#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_e4_cache_case.h"
int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("usage: e4-consumer INPUTS");return qwen_e4_cache_case::run(argv[1]);}catch(const std::exception&e){std::cerr<<"e4_consumer_failure="<<e.what()<<"\n";return 1;}}
