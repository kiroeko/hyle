"""Finite dependency impact audit of retained f36 selected objects. No build/run."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def pin(p):
    p = Path(p)
    with p.open('rb') as f:
        sha = hashlib.file_digest(f, 'sha256').hexdigest()
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha)


old = read(W/'selected-dependency-scan-provisional.json')
ready = read(R/'.scratch/inference-result-publication-screen-20261026/candidate/ready.json')
inputs = read(ready['link_inputs']['path'])
by_path = {x['path'].casefold(): x for x in inputs}
added, remaining, identity_only = [], [], []
for name in old['missing_per_object_manifest']:
    p = Path(name)
    obj = by_path[name.casefold()]
    assert pin(p) == obj
    matches = []
    for meta in p.parent.glob('*identity*.json'):
        try:
            value = read(meta)
        except (ValueError, UnicodeError):
            continue
        if not isinstance(value, dict) or value.get('object') != obj:
            continue
        deps = value.get('dependencies')
        source = value.get('source')
        if isinstance(deps, list) and deps:
            assert all(isinstance(x, dict) and 'path' in x for x in deps)
            names = [x['path'] for x in deps]
            assert not any(x.replace('\\','/').casefold().endswith('/engine/inference/execution_observation.h') for x in names)
            matches.append(dict(object=obj, manifest=pin(meta), source=source,
                                dependency_count=len(deps), dependency_storage='pinned inline dependency list'))
            continue
        dfile = value.get('source_dependencies', value.get('dependencies_file'))
        if isinstance(dfile, dict) and 'path' in dfile:
            assert pin(dfile['path']) == dfile
            text = Path(dfile['path']).read_text(encoding='utf-8-sig')
            assert 'execution_observation.h' not in text.casefold()
            matches.append(dict(object=obj, manifest=pin(meta), source=source,
                                dependency_file=dfile, dependency_storage='pinned NVCC dependency file'))
            continue
        identity_only.append(dict(object=obj, manifest=pin(meta), source=source,
                                  limitation='Object/source identity matched, but no pinned dependency list in this identity.'))
    if matches:
        added.append(matches[0])
    else:
        candidates = [x for x in identity_only if x['object'] == obj]
        remaining.append(dict(object=obj, matched_identity=candidates,
                              limitation='Not included in complete per-object dependency evidence. Retained native/third-party ownership only; no silent ABI certification.'))

assert len(old['covered'])+len(added)+len(remaining) == old['selected_objects']
result = dict(status='FINITE_SELECTED_DEPENDENCY_IMPACT_SCAN_NO_BUILD',
    baseline_ready=pin(R/'.scratch/inference-result-publication-screen-20261026/candidate/ready.json'),
    baseline_link_inputs=ready['link_inputs'], initial_scan=pin(W/'selected-dependency-scan-provisional.json'),
    baseline_absolute_inputs=len(inputs), selected_objects=old['selected_objects'],
    existing_host_dependency_objects=len(old['covered']),
    added_native_dependency_objects=len(added),
    covered_dependency_objects=len(old['covered'])+len(added),
    uncovered_dependency_objects=len(remaining),
    added_native_dependencies=added, remaining=remaining,
    StepObservation_readers=old['StepObservation_readers'],
    conclusion='Only the selected Model/report TUs read execution_observation.h in the matched dependency evidence. Both will be rebuilt. Source direct-include cross-check also finds only these two canonical readers. The explicit native evidence limitation does not certify arbitrary changes to unrelated retained provider sources.',
    source_include_crosscheck=old['source_include_crosscheck'],
    limits=['No compiler, linker, model, profile or network invoked.',
            'Native dependency identity matching uses exact selected object path/byte count/SHA; identity metadata and any external dependency file are pinned. Dependencies are inspected for this header, not rehashed or claimed current.',
            '27 retained library inputs are SDK/third-party link dependencies, not project engine TUs; this is a targeted review change build against retained f36 closure.'])
(W/'selected-dependency-scan.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:result[k] for k in ['selected_objects','existing_host_dependency_objects','added_native_dependency_objects','covered_dependency_objects','uncovered_dependency_objects']}))
print(json.dumps(pin(W/'selected-dependency-scan.json')))
