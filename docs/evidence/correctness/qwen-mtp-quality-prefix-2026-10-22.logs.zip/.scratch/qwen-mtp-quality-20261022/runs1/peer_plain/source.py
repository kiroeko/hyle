```python
import unittest
from typing import Any, Callable, Iterable, List, Optional, TypeVar

T = TypeVar('T')
K = TypeVar('K')

def stable_merge_sort(items: Iterable[T], *, key: Optional[Callable[[T], K]] = None, reverse: bool = False) -> List[T]:
    """
    Perform a stable, bottom-up iterative merge sort on an iterable.
    
    Parameters:
        items: Input iterable containing elements of type T.
        key: Optional callable that takes an element and returns a comparable value.
        reverse: If True, sort in descending order based on the key.
    
    Returns:
        A new list containing the sorted elements. The original list is not mutated.
        Stability is preserved: items with equal keys maintain their relative order.
    """
    if not items:
        return []
    
    # Convert to list to support indexing and slicing
    data = list(items)
    
    # Helper function to merge two sorted lists
    def merge(left: List[T], right: List[T]) -> List[T]:
        result = []
        i = j = 0
        
        # Iterate while both lists have elements
        while i < len(left) and j < len(right):
            # For stability: if keys are equal, pick from left (maintaining original order)
            if (key is None or key(left[i]) == key(right[j])) and not reverse:
                result.append(left[i])
                i += 1
            elif (key is None or key(left[i]) == key(right[j])) and reverse:
                result.append(right[j])
                j += 1
            else:
                # Pick the element with the larger key (or first one if keys are equal)
                if (key is None or key(left[i]) > key(right[j])) and not reverse:
                    result.append(left[i])
                    i += 1
                elif (key is None or key(left[i]) > key(right[j])) and reverse:
                    result.append(left[i])
                    i += 1
                else:
                    result.append(right[j])
                    j += 1
        
        # Append remaining elements
        result.extend(left[i:])
        result.extend(right[j:])
        
        return result

    # Bottom-up merge sort
    n = len(data)
    while n > 1:
        mid = n // 2
        left = data[:mid]
        right = data[mid:]
        
        data = merge(left, right)
        n = len(data)
    
    return data


class TestStableMergeSort(unittest.TestCase):
    def test_empty_input(self):
        self.assertEqual(stable_merge_sort([]), [])

    def test_singleton_input(self):
        self.assertEqual(stable_merge_sort([5]), [5])
        self.assertEqual(stable_merge_sort([5], key=lambda x: x), [5])
        self.assertEqual(stable_merge_sort([5], key=lambda x: x, reverse=True), [5])

    def test_repeated_keys(self):
        data = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = stable_merge_sort(data)
        self.assertEqual(result, [1, 1, 2, 3, 3, 4, 5, 5, 5, 6, 9])
        
        # Verify stability: first 1 comes before second 1, etc.
        self.assertEqual(result[0], 1)
        self.assertEqual(result[1], 1)
        self.assertEqual(result[2], 2)
        self.assertEqual(result[3], 3)
        self.assertEqual(result[4], 3)
        self.assertEqual(result[5], 4)
        self.assertEqual(result[6], 5)
        self.assertEqual(result[7], 5)
        self.assertEqual(result[8], 5)

    def test_reverse_stability(self):
        data = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = stable_merge_sort(data, reverse=True)
        # Expected descending order with stability
        expected = [9, 6, 5, 5, 5, 4, 3, 3, 2, 1, 1]
        self.assertEqual(result, expected)
        
        # Verify stability in descending order: first 5 comes before second 5
        self.assertEqual(result[0], 9)
        self.assertEqual(result[1], 6)
        self.assertEqual(result[2], 5)
        self.assertEqual(result[3], 5)
        self.assertEqual(result[4], 5)
        self.assertEqual(result[5], 4)
        self.assertEqual(result[6], 3)
        self.assertEqual(result[7], 3)
        self.assertEqual(result[8], 2)
        self.assertEqual(result[9], 1)
        self.assertEqual(result[10], 1)

    def test_generator_input(self):
        def gen():
            yield 1
            yield 2
            yield 3
            yield 4
            yield 5
        
        result = stable_merge_sort(gen())
        self.assertEqual(result, [1, 2, 3, 4, 5])
        
        # Verify stability with generator
        self.assertEqual(result[0], 1)
        self.assertEqual(result[1], 2)
        self.assertEqual(result[2], 3)
        self.assertEqual(result[3], 4)
        self.assertEqual(result[4], 5)

    def test_key_function(self):
        data = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = stable_merge_sort(data, key=lambda x: x * 2)
        # Sorted by doubled value: 6, 4, 3, 3, 2, 1, 1, 5, 5, 5, 9
        expected = [6, 4, 3, 3, 2, 1, 1, 5, 5, 5, 9]
        self.assertEqual(result, expected)
        
        # Verify stability with key
        self.assertEqual(result[0], 6)
        self.assertEqual(result[1], 4)
        self.assertEqual(result[2], 3)
        self.assertEqual(result[3], 3)
        self.assertEqual(result[4], 2)
        self.assertEqual(result[5], 1)
        self.assertEqual(result[6], 1)
        self.assertEqual(result[7], 5)
        self.assertEqual(result[8], 5)
        self.assertEqual(result[9], 5)
        self.assertEqual(result[10], 9)

    def test_key_with_reverse(self):
        data = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = stable_merge_sort(data, key=lambda x: x * 2, reverse=True)
        # Sorted by doubled value descending: 9, 6, 5, 5, 5, 4, 3, 3, 2, 1, 1
        expected = [9, 6, 5, 5, 5, 4, 3, 3, 2, 1, 1]
        self.assertEqual(result, expected)
        
        # Verify stability in descending order
        self.assertEqual(result[0], 9)
        self.assertEqual(result[1], 6)
        self.assertEqual(result[2], 5)
        self.assertEqual(result[3], 5)
        self.assertEqual(result[4], 5)
        self.assertEqual(result[5], 4)
        self.assertEqual(result[6], 3)
        self.assertEqual(result[7], 3)
        self.assertEqual(result[8], 2)
        self.assertEqual(result[9], 1)
        self.assertEqual(result[10], 1)


if __name__ == '__main__':
    unittest.main()
```