```python
import unittest
from typing import Any, Callable, Iterable, List, Optional, TypeVar

T = TypeVar('T')
K = TypeVar('K')

def stable_merge_sort(items: Iterable[T], *, key: Optional[Callable[[T], K]] = None, reverse: bool = False) -> List[T]:
    """
    Perform a stable, bottom-up iterative merge sort on an iterable.
    
    Parameters:
    items (Iterable[T]): The input iterable to sort.
    key (Callable[[T], K]): Optional function to extract a comparison key from each item.
    reverse (bool): If True, sort in descending order.
    
    Returns:
    List[T]: A new list containing the sorted items.
    
    The sort is stable, meaning items with equal keys maintain their relative order.
    The original input list is never mutated.
    """
    if not items:
        return []
    
    # Convert to list to support indexing and slicing
    data = list(items)
    
    # Create a copy of the data to avoid mutating the original
    result = []
    n = len(data)
    
    # Create a copy of the data for the merge step
    temp = data[:]
    
    # Helper function to merge two sorted lists
    def _merge(left: List[T], right: List[T]) -> List[T]:
        i = j = 0
        merged = []
        while i < len(left) and j < len(right):
            if (key(left[i]) < key(right[j]) or 
                (key(left[i]) == key(right[j]) and not reverse)):
                merged.append(left[i])
                i += 1
            else:
                merged.append(right[j])
                j += 1
        merged.extend(left[i:])
        merged.extend(right[j:])
        return merged
    
    # Bottom-up merge sort
    while n > 1:
        n = n // 2
        for i in range(0, n, 2):
            left = temp[i:i + n]
            right = temp[i + n:i + 2 * n]
            temp[i:i + n] = _merge(left, right)
        temp = temp[:]
    
    return result

class TestStableMergeSort(unittest.TestCase):
    def test_empty_input(self):
        self.assertEqual(stable_merge_sort([]), [])
    
    def test_singleton_input(self):
        self.assertEqual(stable_merge_sort([5]), [5])
        self.assertEqual(stable_merge_sort([5], key=lambda x: x), [5])
        self.assertEqual(stable_merge_sort([5], key=lambda x: x, reverse=True), [5])
    
    def test_repeated_keys(self):
        data = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = stable_merge_sort(data)
        self.assertEqual(result, [1, 1, 2, 3, 3, 4, 5, 5, 5, 6, 9])
    
    def test_reverse_stability(self):
        data = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = stable_merge_sort(data, reverse=True)
        # Expected: [5, 5, 5, 9, 6, 2, 4, 1, 1, 3, 3]
        self.assertEqual(result, [5, 5, 5, 9, 6, 2, 4, 1, 1, 3, 3])
    
    def test_generator_input(self):
        def gen():
            yield 1
            yield 2
            yield 3
            yield 4
            yield 5
        
        result = stable_merge_sort(gen())
        self.assertEqual(result, [1, 2, 3, 4, 5])
    
    def test_key_function(self):
        data = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = stable_merge_sort(data, key=lambda x: x * 2)
        # Expected: [2, 2, 4, 4, 10, 18, 4, 12, 10, 6, 10]
        self.assertEqual(result, [2, 2, 4, 4, 10, 18, 4, 12, 10, 6, 10])
    
    def test_key_with_reverse(self):
        data = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
        result = stable_merge_sort(data, key=lambda x: x * 2, reverse=True)
        # Expected: [18, 10, 12, 6, 4, 4, 2, 2, 10, 10, 10]
        self.assertEqual(result, [18, 10, 12, 6, 4, 4, 2, 2, 10, 10, 10])

if __name__ == '__main__':
    unittest.main()
```