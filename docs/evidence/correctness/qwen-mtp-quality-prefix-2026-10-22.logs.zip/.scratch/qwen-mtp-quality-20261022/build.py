"""Root-only cached host rebuilds for long-form quality, without math changes."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
AQ = R/'.scratch/qwen-native-protocol-20261022'
AP = R/'.scratch/vulkan-native-memory-20261022'
PEER = R/'.scratch/qwen-mtp-window-20261022/peer'
spec = importlib.util.spec_from_file_location('ar_cached', AQ/'build.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b, c, h = m.b, m.c, m.h
h.S = S

def build(tag, attempt):
    (S/'recipes').mkdir(exist_ok=True)
    if tag in ['hyle', 'prefix']:
        recipe = AP/'compile1/cuda-main/identity.json'
        source = R/'tools/qwen35_text/main.cc' if tag == 'hyle' else S/'source/prefix_probe.cc'
        base_dir = AQ/'cuda-retirement-link1'
        base = c.read(base_dir/'link-plan.json')
        removed = [c.read(AQ/f'compile1/{x}/identity.json')['object']['path']
                   for x in ['cuda-gate', 'cuda-retirement']]
    elif tag == 'peer-prefix':
        source = S/'peer/peer_prefix.cc'
        original = c.read(S/'compile3/peer/identity.json')
        original['command'] = ['/std:c++20' if x == '/std:c++17' else x for x in original['command']]
        recipe = S/'recipes/peer-prefix.json'; c.save(recipe, original)
        base_dir = S/'peer-link1'; base = c.read(base_dir/'link-plan.json')
        removed = [original['object']['path']]
    else:
        source = S/'source/peer_mtp.cc'; source.parent.mkdir(exist_ok=True)
        original = (PEER/'peer_mtp.cc').read_text(encoding='utf-8')
        before = 'o.capacity && o.capacity <= 4096 && o.steps && o.steps <= 1024'
        after = 'o.capacity && o.capacity <= 4096 && o.steps && o.steps <= o.capacity'
        assert original.count(before) == 1
        updated = original.replace(before, after).replace(
            'bounded positive context<=4096 and output budget<=1024 required',
            'positive context<=4096 and output budget<=context required')
        old_guard = 'prompt.size() + o.steps - 1 <= o.capacity'
        assert updated.count(old_guard) == 1
        updated = updated.replace(old_guard,
            'prompt.size() <= o.capacity && o.steps - 1 <= o.capacity - prompt.size()')
        source.write_text(updated, encoding='utf-8', newline='\n')
        base_dir = PEER/'checks/attempt1'
        base = c.read(base_dir/'link-plan.json')
        command = c.read(base_dir/'compile.command.json')['command']
        command = ['/external:I'+x[2:] if x.startswith('/I') and
            ('llama-matched-consumer' in x or 'ggml-native-static' in x) else x for x in command]
        command += ['/W4', '/WX', '/external:W0', '/external:I'+str(R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/source/vendor')]
        recipe = S/'recipes/peer-original.json'
        c.save(recipe, dict(source=b.identity(PEER/'peer_mtp.cc'), command=command))
        removed = [base['inputs'][0]['path']]
        c.save(S/'source/peer-only-changes.json', dict(
            original=b.identity(PEER/'peer_mtp.cc'), actual=b.identity(source),
            changes=['output guard bounded by original context<=4096',
                     'overflow-safe equivalent prompt plus output-input capacity check'],
            model_math_changes=False, original_llama_core_changes=False))
    h.RECIPES[tag] = recipe; h.SOURCES[tag] = source
    h.compile_one(tag, attempt)
    record = c.read(S/f'compile{attempt}/{tag}/identity.json')
    assert all(b.identity(x['path']) == x for x in [record['source'], record['object'], *record['dependencies']])
    removed_keys = {c.key(x) for x in removed}
    assert len([x for x in base['inputs'] if c.key(x['path']) in removed_keys]) == len(removed)
    inputs = [record['object'], *[x for x in base['inputs'] if c.key(x['path']) not in removed_keys]]
    assert all(b.identity(x['path']) == x for x in inputs)
    out = S/f'{tag}-link1'; out.mkdir(); (out/'tmp').mkdir()
    image = out/({'hyle':'qwen.exe','peer':'peer.exe','prefix':'probe.exe','peer-prefix':'probe.exe'}[tag])
    command = [x for x in base['command'] if c.key(x) not in removed_keys
               and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command.insert(1, record['object']['path'])
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json', dict(command=command, inputs=inputs,
        compiled_record=b.identity(S/f'compile{attempt}/{tag}/identity.json'),
        retained_inputs=len(inputs)-1, SDK_builds=0, NVCC_builds=0, shaders=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(base_dir/'runtime-environment.json')
    c.save(out/'runtime-environment.json', runtime)
    for x in runtime.get('staged_dlls', []):
        path = Path(x['path'])
        if not (out/path.name).exists(): os.link(path, out/path.name)
    c.save(out/'ready.json', dict(image=b.identity(image)))
    print('LINKED', tag, flush=True)

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('tags', nargs='+', choices=['hyle', 'peer', 'prefix', 'peer-prefix'])
    p.add_argument('--attempt', type=int, default=1)
    args=p.parse_args()
    for tag in args.tags: build(tag, args.attempt)
