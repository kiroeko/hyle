"""Root-only two-shape prefix diagnostic plus offline arithmetic inspection."""
from pathlib import Path
import importlib.util, os, subprocess, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ar_run_helpers', S/'run_quality.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
ready=h.read(S/'prefix-link1/ready.json');image=ready['image']
assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(S/'prefix-link1/runtime-environment.json')['PATH']
folder=S/'prefix1'
command=[image['path'],'--inputs',str(h.V/'inputs/mtp'),'--output',str(folder/'vectors')]
result=h.execute(command,env,folder,timeout=120)
assert result['exit']==0 and not result['timed_out'], result
h.save(folder/'image.json',ready)
print('PREFIX_NATIVE_COMPLETE',flush=True)
command=[sys.executable,str(S/'review/check_prefix.py'),'--data',str(folder/'vectors'),
         '--output',str(S/'review/prefix1-analysis.json')]
process=h.execute(command,os.environ.copy(),S/'prefix1-offline',timeout=120)
assert process['exit']==0 and not process['timed_out'], process
print((S/'prefix1-offline/stdout.log').read_text(),flush=True)
