"""Root-only original GGML two-shape/two-repeat prefix and offline inspection."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ar_peer_run_helpers',S/'run_quality.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
ready=h.read(S/'peer-prefix-link1/ready.json');image=ready['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(S/'peer-prefix-link1/runtime-environment.json')['PATH']
model=h.R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/Qwen3.5-2B-text-MTP-BF16.gguf'
folder=S/'peer-prefix1'
command=[image['path'],'--model',str(model),'--output',str(folder/'vectors')]
result=h.execute(command,env,folder,timeout=120)
assert result['exit']==0 and not result['timed_out'],result
h.save(folder/'image.json',ready)
print('PEER_PREFIX_NATIVE_COMPLETE',flush=True)
command=[sys.executable,str(S/'peer/check_actual.py'),'--data',str(folder/'vectors'),
         '--output',str(S/'review/peer-prefix1-analysis.json')]
result=h.execute(command,os.environ.copy(),S/'peer-prefix1-offline',timeout=120)
assert result['exit']==0 and not result['timed_out'],result
print((S/'peer-prefix1-offline/stdout.log').read_text(),flush=True)
