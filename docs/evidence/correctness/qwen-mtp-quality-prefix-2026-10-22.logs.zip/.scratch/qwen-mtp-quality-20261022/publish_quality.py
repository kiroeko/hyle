"""Publish this finite quality/prefix batch; never invoke model/build tooling."""
from pathlib import Path
import hashlib, json, zipfile
S=Path(__file__).resolve().parent;R=S.parents[1]
OUT=R/'docs/evidence/correctness/qwen-mtp-quality-prefix-2026-10-22.json'
ZIP=OUT.with_suffix('.logs.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
    p=Path(p).resolve();raw=p.read_bytes()
    return dict(path=str(p.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
assert not OUT.exists() and not ZIP.exists()
quality=read(S/'review/task-quality-actual.json')
prefix=read(S/'review/prefix1-analysis.json')
rounding=read(S/'review/prefix1-rounding-detail.json')
repeatability=read(S/'review/prefix-repeatability.json')
existing_contract=read(S/'review/prefix-existing-numeric-contract.json')
peer_prefix=read(S/'review/peer-prefix1-analysis.json')
assert quality['status']=='FAIL_STRICT_FORMAT_ALL_FOUR_ARMS_AND_STATIC_ALGORITHM_COUNTEREXAMPLES'
assert prefix['full_model_qkv_row0_reproduced'] and prefix['route_compatible']
assert prefix['native_row0_comparison']['embedding']['byte_equal']
assert prefix['native_row0_comparison']['normalized']['byte_equal']
assert prefix['native_row0_comparison']['qkv']['changed_elements']==8
files=[]
with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in sorted(S.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts or 'current-window' in p.parts:continue
        if p.suffix.lower() not in {'.json','.py','.cc','.h','.tsv','.log','.bf16','.txt','.md'}:continue
        entry=str(p.relative_to(R)).replace('\\','/')
        archive.write(p,entry);files.append(dict(**ident(p),entry=entry))
    for relative in ['tools/qwen35_text/main.cc','tools/qwen35_text/README.md','docs/developer/current-work.md']:
        p=R/relative;archive.write(p,relative);files.append(dict(**ident(p),entry=relative))
report=dict(date='2026-10-22',status='FINITE_LONG_GENERATION_AND_FAITHFUL_PREFIX_DIAGNOSTIC_COMPLETE',
    full_goal_complete=False,full_MTP_model_scope_complete=False,universal_quality_pass=False,
    summary=[
        'Removed artificial128-output consumer cap; existing model context/resource admission remains, with overflow-safe complete-journey validation.',
        'All four original P154/C4096/2048 coding-task runs ended naturally at EOS. All fail strict format and have static algorithm counterexamples; generated code was neither repaired nor executed.',
        'User clarified small-model task limitations: this common failure is auxiliary evidence, never a requirement to improve2B intelligence or add more tasks until one passes.',
        'Two local native graphs faithfully reproduce the original P154 T1/T2 QKV row0 and necessary provider routes. Embedding and normalized row0 match;6144 QKV elements contain8 differences.',
        'The same fixed prefix image was executed in three independent processes. All embedding/norm/QKV bytes repeat within each shape; six Graph calls execute no MTP calculation or Model/Session/Snapshot state machinery.',
        'The observed first difference is in ordinary BF16 cuBLASLt projection, before recurrent updates. This does not prove that these8 values explain cross-engine free-generation divergence.',
        'Independent exact/FP64 analysis separates accumulated arithmetic error from ideal-sum FP32/BF16 double rounding. The actual native accumulator/heuristic/reduction tree was not observed; no illegal arithmetic verdict is made.'
        ,'Both Hyle6144-element rows pass the existing unchanged BF16 regression criterion. BF16 cells are compatible with the standard F32 accumulation necessary bound; this does not prove a particular internal implementation.'
        ,'The original GGML local prefix repeats within shape, but all6144 F32 QKV row0 values differ between T1/T2. Source and own-input FP64 controls are consistent with vector F32 inputs versus matrix internal BF16 input conversion. This is not full peer model/scheduler/Snapshot faithfulness.'
        ,'The measured8 Hyle differences are classified as stable shape-related floating-point variation without an observed existing-criterion violation, not an MTP-only wiring bug. Bit equality is not made a new completion requirement.'
    ],product_changes=dict(
        main=ident(R/'tools/qwen35_text/main.cc'),documentation=ident(R/'tools/qwen35_text/README.md'),
        changes=['remove arbitrary output128 gates for plain and MTP','checked forced input-count addition',
                 'nonempty prompt and overflow-safe prompt/continuation/output-input capacity admission'],
        math_changes=False,precision_policy_changes=False,provider_route_changes=False),
    diagnostic_peer_only_changes=read(S/'source/peer-only-changes.json'),
    validation=dict(early_rejections=[read(S/f'cli-negative1/{x}/observation.json') for x in ['zero','overflow','mtp-over-context']],
        task_quality=quality,prefix=prefix,rounding=rounding,repeatability=repeatability,
        existing_numerical_criterion=existing_contract,original_GGML_prefix=peer_prefix,
        native_processes=8,full_task_processes=4,Hyle_prefix_processes=3,peer_prefix_processes=1,
        Hyle_prefix_graph_calls=6,peer_prefix_graph_calls=4,
        generated_code_executions=0,external_candidate_functional_checks_run=0,
        SDK_builds=0,NVCC_builds=0,shader_builds=0,
        host_compile_processes=5,successful_host_compiles=4,failed_host_compiles=1,host_links=4,
        build_limitations=['Peer attempt1 failed before any compiler process because its old recipe omitted strict warning flags.',
          'Peer attempt2 failed on warnings in unmodified third-party headers after enabling strict warnings; attempt3 marks those existing include directories external, leaving diagnostic source warnings strict.',
          'No claim that standalone project CMake configure/build was run. Reused cached host compiler/link closures.']),
    current_images={x:read(S/f'{x}-link1/ready.json') for x in ['hyle','peer','prefix','peer-prefix']},
    official_compute_type_reference=dict(
        url='https://docs.nvidia.com/cuda/cublas/index.html#cublascomputetype-t',
        scope='CUBLAS_COMPUTE_32F specifies compute and intermediate storage precision of at least32 bits; this is not cross-shape bit-equality or internal-algorithm evidence.'),
    throughput_evidence=False,memory_peak_evidence=False,
    next_scope=['Finish mathematical/state correctness using existing contracts; no task-solving ability requirement.',
                'Current ordinary/MTP four-arm timing and separate memory window is published independently.',
                'Other applicable committed selected MTP artifacts still require actual integration; no promise that one Qwen consumer covers them.'],
    archive=ident(ZIP),archive_files=files)
OUT.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps(dict(manifest=ident(OUT),archive=ident(ZIP)),ensure_ascii=False))
