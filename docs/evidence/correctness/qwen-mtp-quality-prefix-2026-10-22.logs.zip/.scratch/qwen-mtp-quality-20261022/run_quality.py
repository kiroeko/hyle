"""One complete original coding task, four serial arms; no throughput claim."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, time
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent; R = S.parents[1]
V = R/'.scratch/qwen-mtp-window-20261022'
EOS = {248044, 248046}
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, x):
    p=Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, indent=2, ensure_ascii=False, allow_nan=False)+'\n', encoding='utf-8')
def ident(p):
    p=Path(p).resolve(); raw=p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def execute(command, env, folder, timeout=600):
    folder.mkdir(parents=True, exist_ok=False)
    result=dict(command=command, cwd=str(R), started=time.time(), timeout_seconds=timeout,
                throughput_evidence=False, memory_evidence=False, trace=False, profiler=False)
    save(folder/'command.json', result)
    start=time.perf_counter()
    with (folder/'stdout.log').open('wb') as out, (folder/'stderr.log').open('wb') as err:
        process=subprocess.Popen(command, cwd=R, env=env, stdout=out, stderr=err,
                                 creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
        result['pid']=process.pid; save(folder/'live.json',result)
        try: result['exit']=process.wait(timeout=timeout); result['timed_out']=False
        except subprocess.TimeoutExpired:
            process.kill(); result['exit']=process.wait(); result['timed_out']=True
    result.update(finished=time.time(), process_wall_seconds=time.perf_counter()-start)
    save(folder/'process.json', result)
    return result

def run(arms):
    records=[]
    for arm in arms:
        peer=arm.startswith('peer'); mtp=arm.endswith('mtp'); tag='peer' if peer else 'hyle'
        image=read(S/f'{tag}-link1/ready.json')['image']
        assert ident(image['path'])==image
        inputs=V/'inputs'/('mtp' if mtp else 'text')
        prompt=inputs/'prompt.ids'
        assert prompt.read_bytes()==(V/'inputs/prompt.ids').read_bytes()
        ids=[int(x) for x in prompt.read_text(encoding='ascii').split()]
        assert len(ids)==154 and len(ids)+2048-1<=4096
        folder=S/'runs1'/arm
        if peer:
            model=R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'/(
                'Qwen3.5-2B-text-MTP-BF16.gguf' if mtp else 'Qwen3.5-2B-text-BF16.gguf')
            command=[image['path'],'--model',str(model),'--inputs',str(inputs),'--steps','2048',
                     '--capacity','4096','--mtp','on' if mtp else 'off','--memory-snapshots','off',
                     '--output',str(folder/'consumer-result.json')]
        else:
            command=[image['path'],'--inputs',str(inputs),'--steps','2048','--capacity','4096',
                     '--max-sessions','1','--active-sequences','1','--cache-bytes','auto',
                     '--prefix-cache','off','--progress','direct','--replay','auto','--mtp','on' if mtp else 'off']
        env=os.environ.copy(); env['PATH']=read(S/f'{tag}-link1/runtime-environment.json')['PATH']
        print('START',arm,flush=True)
        receipt=execute(command,env,folder)
        record=dict(arm=arm,image=image,prompt=ident(prompt),requested_output_tokens=2048,
            capacity=4096,process=receipt,quality_result='UNASSESSED',throughput_evidence=False)
        if receipt['exit']==0:
            raw=read(folder/'consumer-result.json') if peer else json.loads(
                (folder/'stdout.log').read_text(encoding='utf-8').strip().splitlines()[-1])
            save(folder/'parsed.json',raw)
            generated=raw['generated_ids']; assert 0<len(generated)<=2048
            assert all(isinstance(x,int) and 0<=x<248320 for x in generated)
            assert not any(x in EOS for x in generated[:-1])
            stopped=generated[-1] in EOS
            record.update(actual_output_tokens=len(generated),honored_EOS=stopped,
                quality_result='AWAIT_FULL_SOURCE_REVIEW' if stopped else 'INCOMPLETE_AT_QUOTA')
            from tokenizers import Tokenizer
            tokenizer=Tokenizer.from_file('C:/Users/kiro/Downloads/Qwen3.5-2B/tokenizer.json')
            source=tokenizer.decode(generated[:-1] if stopped else generated,skip_special_tokens=False)
            (folder/'source.py').write_text(source,encoding='utf-8',newline='\n')
            record['source']=ident(folder/'source.py')
        else: record['quality_result']='PROCESS_TIMEOUT' if receipt['timed_out'] else 'PROCESS_FAILED'
        save(folder/'observation.json',record); records.append(record)
        print('DONE',arm,record['quality_result'],record.get('actual_output_tokens'),flush=True)
    save(S/'runs1/summary.json',dict(scope='Original full P154 coding task; finite assessment, no universal quality or TPS claim',
        runs=records,product_math_changes=False,precision_policy_changes=False))

def negatives():
    image=read(S/'hyle-link1/ready.json')['image']; assert ident(image['path'])==image
    env=os.environ.copy();env['PATH']=read(S/'hyle-link1/runtime-environment.json')['PATH']
    for name,options,expected in [
        ('zero',['--steps','0'],'requires a positive integer'),
        ('overflow',['--steps','18446744073709551615','--capacity','4096'],'requested generation exceed --capacity'),
        ('mtp-over-context',['--mtp','on','--steps','2048','--capacity','128'],'requested generation exceed --capacity')]:
        folder=S/'cli-negative1'/name
        command=[image['path'],'--inputs',str(V/'inputs/mtp'),*options]
        result=execute(command,env,folder,timeout=30)
        err=(folder/'stderr.log').read_text(encoding='utf-8')
        assert result['exit']!=0 and not result['timed_out'] and expected in err
        assert 'loaded ' not in err
        save(folder/'observation.json',dict(status='PASS_EARLY_REJECTION',expected_error=expected,
            process=result,weights_loaded=False))
        print('NEGATIVE_PASS',name,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('arms',nargs='+',choices=['hyle_plain','hyle_mtp','peer_plain','peer_mtp','negatives'])
    args=p.parse_args()
    if args.arms==['negatives']: negatives()
    else: run(args.arms)
