# Trusted external checker template. Run only as a separate timed process.
import argparse, ast, copy, hashlib, inspect, io, json, types, unittest
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--source',required=True)
p.add_argument('--audit',required=True)
p.add_argument('--task',choices=['stable_merge_sort','run_lengths'],required=True)
a=p.parse_args()
raw=Path(a.source).read_bytes()
assert len(raw)<=131072, 'source-size limit'
receipt=json.loads(Path(a.audit).read_text(encoding='utf-8'))
assert receipt.get('reviewed_sha256')==hashlib.sha256(raw).hexdigest(), 'exact source was not reviewed'
assert receipt.get('complete_source') is True and receipt.get('safe_to_execute') is True, 'source review required'
source=raw.decode('utf-8')
tree=ast.parse(source,filename=a.source)
assert sum(1 for _ in ast.walk(tree))<=12000, 'AST-size limit'
allowed_imports={'unittest','typing','__future__'}
blocked={'open','eval','exec','compile','__import__','input','print','breakpoint','getattr','setattr','delattr','globals','locals','vars'}
for node in ast.walk(tree):
    if isinstance(node,ast.Import):
        assert all(x.name in allowed_imports for x in node.names), 'unreviewed import'
    if isinstance(node,ast.ImportFrom):
        assert node.level==0 and node.module in allowed_imports, 'unreviewed import'
        assert all(x.name!='*' for x in node.names), 'star import'
    if isinstance(node,(ast.Global,ast.Nonlocal,ast.AsyncFunctionDef,ast.Await)):
        raise AssertionError('unsupported executable feature')
    if isinstance(node,ast.Name):
        assert node.id not in blocked, 'blocked capability'
    if isinstance(node,ast.Attribute):
        assert not node.attr.startswith('__'), 'introspection capability'
    if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
        assert not node.decorator_list, 'decorator requires separate review'
    if isinstance(node,ast.Call):
        assert not (isinstance(node.func,ast.Name) and node.func.id=='sorted'), 'sorted forbidden'
        assert not (isinstance(node.func,ast.Attribute) and node.func.attr=='sort'), 'sort forbidden'
# Manual source review additionally covers module-level effects, aliases,
# the bottom-up algorithm and the candidate unittest coverage. This static
# gate is defense in depth, not a claim that Python is a sandbox.
module=types.ModuleType('reviewed_quality_candidate')
exec(compile(tree,a.source,'exec'),module.__dict__)
checks=0
if a.task=='stable_merge_sort':
    fn=module.stable_merge_sort
    sig=inspect.signature(fn)
    assert list(sig.parameters)==['items','key','reverse']
    assert sig.parameters['key'].kind==inspect.Parameter.KEYWORD_ONLY
    assert sig.parameters['reverse'].kind==inspect.Parameter.KEYWORD_ONLY
    assert sig.parameters['key'].default is None and sig.parameters['reverse'].default is False
    assert inspect.getdoc(fn), 'clear function docstring required'
    # A trusted built-in oracle is permitted here; it is forbidden in candidate.
    for n in [0,1,2,3,7,8,9,15,16,17,31,32,33,65]:
        values=[((i*17+7)%11)-5 for i in range(n)]
        for reverse in [False,True]:
            before=values.copy()
            result=fn(values,reverse=reverse)
            assert type(result) is list and result is not values
            assert values==before and result==sorted(before,reverse=reverse)
            checks+=1
    records=[{'k':k,'tag':i} for i,k in enumerate([2,1,2,0,1,2,0,2,1])]
    for reverse in [False,True]:
        expected=sorted(records,key=lambda x:x['k'],reverse=reverse)
        for kind in ['list','tuple','generator']:
            values=copy.deepcopy(records)
            original=copy.deepcopy(values)
            calls={row['tag']:0 for row in values}
            def key(row):
                calls[row['tag']]+=1
                return row['k']
            items=values if kind=='list' else tuple(values) if kind=='tuple' else (x for x in values)
            result=fn(items,key=key,reverse=reverse)
            assert type(result) is list and result==expected
            assert values==original and all(v==1 for v in calls.values())
            if kind=='list': assert result is not items
            checks+=1
    for values in [[],[7],[4,1,4,-2,0]]:
        result=fn((x for x in values))
        assert type(result) is list and result==sorted(values)
        checks+=1
    assert fn([('b',1),('a',2),('b',3)],key=lambda x:x[0],reverse=True)==[('b',1),('b',3),('a',2)]
    checks+=1
    suite=unittest.defaultTestLoader.loadTestsFromModule(module)
    assert suite.countTestCases()>0, 'requested unittest.TestCase missing'
    report=io.StringIO()
    own=unittest.TextTestRunner(stream=report,verbosity=2).run(suite)
    assert own.wasSuccessful(), report.getvalue()
    print(json.dumps({'status':'PASS_EXTERNAL_FUNCTIONAL_CHECKS','external_checks':checks,'candidate_tests_run':own.testsRun}))
else:
    fn=module.run_lengths
    cases=[([],[]),([1],[(1,1)]),([1,1,2,1,1,1],[(1,2),(2,1),(1,3)]),
           (['a','a','b','b','a'],[('a',2),('b',2),('a',1)]),
           ([[1],[1],[2],[1]],[([1],2),([2],1),([1],1)]),
           ([None,None,0,0,None],[(None,2),(0,2),(None,1)])]
    for values,expected in cases:
        for generator in [False,True]:
            items=copy.deepcopy(values);before=copy.deepcopy(items)
            result=fn((x for x in items) if generator else items)
            assert type(result) is list and result==expected and items==before
            checks+=1
    print(json.dumps({'status':'PASS_EXTERNAL_FUNCTIONAL_CHECKS','external_checks':checks}))
