// Local original-GGML prefix control, not a full llama-model execution.
#include "ggml.h"
#include "ggml-alloc.h"
#include "ggml-backend.h"
#include "ggml-cuda.h"
#include "gguf.h"

#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}
struct Context final {
  ggml_context *value = nullptr;
  ~Context() { if (value) ggml_free(value); }
};
struct Buffer final {
  ggml_backend_buffer_t value = nullptr;
  ~Buffer() { if (value) ggml_backend_buffer_free(value); }
};
struct Backend final {
  ggml_backend_t value = nullptr;
  ~Backend() {
    if (value) { ggml_backend_synchronize(value); ggml_backend_free(value); }
  }
};
struct Metadata final {
  gguf_context *value = nullptr;
  ~Metadata() { if (value) gguf_free(value); }
};

std::vector<std::uint8_t> read_range(std::ifstream &file, std::uint64_t offset,
                                    std::size_t bytes, std::uint64_t capacity) {
  require(offset <= capacity && bytes <= capacity-offset, "GGUF tensor range outside file");
  require(offset <= static_cast<std::uint64_t>((std::numeric_limits<std::streamoff>::max)()),
          "GGUF offset exceeds stream domain");
  std::vector<std::uint8_t> result(bytes);
  file.seekg(static_cast<std::streamoff>(offset));
  file.read(reinterpret_cast<char *>(result.data()), static_cast<std::streamsize>(bytes));
  require(static_cast<bool>(file), "GGUF tensor range read failed");
  return result;
}

void save(const std::filesystem::path &path, const ggml_tensor *tensor) {
  require(tensor->type == GGML_TYPE_F32, "peer output must retain original F32 dtype");
  std::vector<float> raw(static_cast<std::size_t>(ggml_nelements(tensor)));
  ggml_backend_tensor_get(tensor, raw.data(), 0, ggml_nbytes(tensor));
  for (const auto value : raw) require(std::isfinite(value), "nonfinite peer prefix value");
  std::ofstream file(path, std::ios::binary);
  file.write(reinterpret_cast<const char *>(raw.data()),
             static_cast<std::streamsize>(raw.size()*sizeof(float)));
  require(static_cast<bool>(file), "cannot write peer prefix raw output");
}

void run(const std::filesystem::path &model, const std::filesystem::path &output) {
  require(!std::filesystem::exists(output), "peer prefix output must be fresh");
  std::filesystem::create_directories(output);
  Context metadata_context;
  Metadata metadata;
  metadata.value = gguf_init_from_file(model.string().c_str(),
                                      {true, &metadata_context.value});
  require(metadata.value && metadata_context.value, "cannot read GGUF metadata");
  auto *embedding_info = ggml_get_tensor(metadata_context.value, "token_embd.weight");
  auto *norm_info = ggml_get_tensor(metadata_context.value, "blk.0.attn_norm.weight");
  auto *qkv_info = ggml_get_tensor(metadata_context.value, "blk.0.attn_qkv.weight");
  require(embedding_info && norm_info && qkv_info, "missing original layer0 tensors");
  require(embedding_info->type == GGML_TYPE_BF16 && embedding_info->ne[0] == 2048 &&
          embedding_info->ne[1] == 248320, "original embedding contract differs");
  require(norm_info->type == GGML_TYPE_F32 && norm_info->ne[0] == 2048 &&
          ggml_nelements(norm_info) == 2048, "GGUF norm must be original converted F32 scale");
  require(qkv_info->type == GGML_TYPE_BF16 && qkv_info->ne[0] == 2048 &&
          qkv_info->ne[1] == 6144 && qkv_info->ne[2] == 1 && qkv_info->ne[3] == 1,
          "original BF16 QKV contract differs");
  const auto data_offset = gguf_get_data_offset(metadata.value);
  const auto tensor_offset = [&](const char *name) {
    const auto index = gguf_find_tensor(metadata.value, name);
    require(index >= 0, "missing GGUF tensor offset");
    return static_cast<std::uint64_t>(data_offset) + gguf_get_tensor_offset(metadata.value, index);
  };
  const auto capacity = std::filesystem::file_size(model);
  const auto qkv_offset = tensor_offset("blk.0.attn_qkv.weight");
  const auto norm_offset = tensor_offset("blk.0.attn_norm.weight");
  const auto embedding_offset = tensor_offset("token_embd.weight");
  std::ifstream file(model, std::ios::binary);
  require(static_cast<bool>(file), "cannot open GGUF payload");
  auto qkv_raw = read_range(file, qkv_offset, ggml_nbytes(qkv_info), capacity);
  auto norm_raw = read_range(file, norm_offset, ggml_nbytes(norm_info), capacity);
  std::array<std::vector<float>, 2> embedding_rows;
  const std::array<std::int32_t, 2> ids{71093, 12305};
  for (std::size_t row = 0; row < ids.size(); ++row) {
    const auto raw = read_range(file, embedding_offset +
        static_cast<std::uint64_t>(ids[row])*4096, 4096, capacity);
    embedding_rows[row].resize(2048);
    for (std::size_t column = 0; column < 2048; ++column) {
      const auto bits = static_cast<std::uint32_t>(raw[column*2]) |
                        (static_cast<std::uint32_t>(raw[column*2+1]) << 8);
      const std::uint32_t wide = bits << 16;
      std::memcpy(&embedding_rows[row][column], &wide, sizeof(wide));
    }
  }
  const auto epsilon_index = gguf_find_key(metadata.value, "qwen35.attention.layer_norm_rms_epsilon");
  require(epsilon_index >= 0, "GGUF RMS epsilon missing");
  const float epsilon = gguf_get_val_f32(metadata.value, epsilon_index);
  require(epsilon == 1.e-6F, "GGUF RMS epsilon differs from original control");

  // Same fixed peer CUDA backend, no new kernels, precision hints or fallback.
  Backend backend;
  backend.value = ggml_backend_cuda_init(0);
  require(backend.value != nullptr, "cannot create original GGML CUDA backend");
  Context weight_context;
  weight_context.value = ggml_init({4*ggml_tensor_overhead(), nullptr, true});
  require(weight_context.value != nullptr, "cannot create weight metadata");
  auto *weight = ggml_new_tensor_2d(weight_context.value, GGML_TYPE_BF16, 2048, 6144);
  auto *scale = ggml_new_tensor_1d(weight_context.value, GGML_TYPE_F32, 2048);
  Buffer weight_buffer;
  weight_buffer.value = ggml_backend_alloc_ctx_tensors(weight_context.value, backend.value);
  require(weight_buffer.value != nullptr, "cannot allocate original weight tensors");
  ggml_backend_buffer_set_usage(weight_buffer.value, GGML_BACKEND_BUFFER_USAGE_WEIGHTS);
  ggml_backend_tensor_set(weight, qkv_raw.data(), 0, qkv_raw.size());
  ggml_backend_tensor_set(scale, norm_raw.data(), 0, norm_raw.size());
  for (const std::int64_t rows : {1, 2}) {
    Context context;
    context.value = ggml_init({16*ggml_tensor_overhead() +
                                  ggml_graph_overhead_custom(16, false), nullptr, true});
    require(context.value != nullptr, "cannot create graph metadata");
    auto *input = ggml_new_tensor_2d(context.value, GGML_TYPE_F32, 2048, rows);
    auto *normalized = ggml_mul(context.value, ggml_rms_norm(context.value, input, epsilon), scale);
    auto *qkv = ggml_mul_mat(context.value, weight, normalized);
    require(normalized->type == GGML_TYPE_F32 && qkv->type == GGML_TYPE_F32,
            "GGML changed actual peer intermediate dtype");
    ggml_set_name(input, "token_embd-0");
    ggml_set_name(normalized, "attn_norm-0");
    ggml_set_name(qkv, "linear_attn_qkv_mixed-0");
    ggml_set_input(input);
    ggml_set_output(normalized);
    ggml_set_output(qkv);
    auto *graph = ggml_new_graph_custom(context.value, 16, false);
    ggml_build_forward_expand(graph, qkv);
    Buffer buffer;
    buffer.value = ggml_backend_alloc_ctx_tensors(context.value, backend.value);
    require(buffer.value != nullptr, "cannot allocate original graph tensors");
    for (std::int64_t row = 0; row < rows; ++row)
      ggml_backend_tensor_set(input, embedding_rows[static_cast<std::size_t>(row)].data(),
                              static_cast<std::size_t>(row)*8192, 8192);
    for (int repeat = 1; repeat <= 2; ++repeat) {
      const auto status = ggml_backend_graph_compute(backend.value, graph);
      ggml_backend_synchronize(backend.value);
      require(status == GGML_STATUS_SUCCESS, "original CUDA graph compute failed");
      const auto folder = output/('T'+std::to_string(rows))/('r'+std::to_string(repeat));
      std::filesystem::create_directories(folder);
      save(folder/"embedding.f32", input);
      save(folder/"normalized.f32", normalized);
      save(folder/"qkv.f32", qkv);
    }
  }
  std::ofstream observation(output/"observation.json");
  observation << "{\"status\":\"ORIGINAL_GGML_PREFIX_TERMINAL\",\"graph_calls\":4,"
      "\"shapes\":[1,2],\"repeats_per_shape\":2,\"tokens\":[71093,12305],"
      "\"model\":" << std::quoted(std::filesystem::absolute(model).string())
      << ",\"weight_type\":\"BF16\",\"norm_scale_type\":\"F32\","
      "\"GGUF_ranges\":{\"qkv\":{\"offset\":" << qkv_offset
      << ",\"bytes\":" << qkv_raw.size() << "},\"norm\":{\"offset\":" << norm_offset
      << ",\"bytes\":" << norm_raw.size() << "},\"embedding\":{\"offset\":" << embedding_offset
      << ",\"row_bytes\":4096,\"selected_row_offsets\":[" << embedding_offset+71093ULL*4096
      << ',' << embedding_offset+12305ULL*4096 << "]}},"
      "\"embedding_type\":\"F32\",\"normalized_type\":\"F32\",\"qkv_type\":\"F32\","
      "\"embedding_materialization\":\"Exact host F32 widening of two original GGUF BF16 embedding rows; no native get_rows or full llama graph executed\","
      "\"scope\":\"Original GGML RMSNorm+scale+BF16-weight MatMul local prefix only; no complete Snapshot or MTP protocol\","
      "\"precision_override\":false,\"quality_pass\":false,\"performance_comparison\":false}\n";
  require(static_cast<bool>(observation), "cannot write peer prefix observation");
  std::cout << "{\"status\":\"ORIGINAL_GGML_PREFIX_TERMINAL\",\"graph_calls\":4}\n";
}
} // namespace

int main(int argc, char **argv) {
  try {
    std::filesystem::path model, output;
    for (int index = 1; index < argc; index += 2) {
      require(index+1 < argc, "missing option value");
      const std::string option(argv[index]);
      if (option == "--model") model = argv[index+1];
      else if (option == "--output") output = argv[index+1];
      else throw std::runtime_error("unknown peer prefix option");
    }
    require(!model.empty() && !output.empty(), "usage: peer_prefix --model GGUF --output FRESH_DIR");
    run(model, output);
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "Peer prefix diagnostic: " << error.what() << '\n';
    return 1;
  }
}
