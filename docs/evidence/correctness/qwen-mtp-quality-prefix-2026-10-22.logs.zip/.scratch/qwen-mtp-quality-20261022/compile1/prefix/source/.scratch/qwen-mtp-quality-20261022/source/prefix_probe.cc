// Scratch arithmetic diagnostic. Not a model-quality or throughput consumer.
#define main retained_qwen35_main
#include "../../../tools/qwen35_text/main.cc"
#undef main

namespace {
namespace q = qwen35;
namespace g = hyle::graph;
namespace c = hyle::compute;

void require_prefix(bool condition, const char *message) {
  if (!condition) throw std::runtime_error(message);
}

void save_bytes(const std::filesystem::path &path,
                std::span<const std::byte> bytes) {
  std::ofstream file(path, std::ios::binary);
  file.write(reinterpret_cast<const char *>(bytes.data()),
             static_cast<std::streamsize>(bytes.size()));
  require_prefix(static_cast<bool>(file), "cannot write prefix raw output");
}

void save_route(const std::filesystem::path &path, const g::Graph &graph,
                const g::CompileReport &report) {
  std::ofstream file(path);
  file << "step\tkind\tprovider\timplementation\tnodes\n";
  for (std::size_t index = 0; index < report.step_count(); ++index) {
    const auto step = q::take(report.step(index));
    file << index << '\t' << static_cast<unsigned>(step.kind) << '\t'
         << step.provider.name << '\t' << step.implementation.value() << '\t';
    for (std::size_t n = 0; n < step.node_count; ++n) {
      const auto node = q::take(report.step_node(index, n));
      const auto kind = q::take(graph.operation_kind(node));
      file << (n ? "," : "") << node.ordinal() << ':'
           << (kind == c::OperationKind::kView ? c::operation_name(kind)
               : c::operation_name(q::take(graph.operation(node))));
    }
    file << '\n';
  }
  require_prefix(static_cast<bool>(file), "cannot write prefix route");
}

void run_prefix(const std::filesystem::path &inputs,
                const std::filesystem::path &output) {
  require_prefix(std::string_view(q::Backend::name()) == "cuda",
                 "this fixed AG numerical diagnostic requires its CUDA closure");
  require_prefix(!std::filesystem::exists(output), "prefix output must be fresh");
  std::filesystem::create_directories(output);
  auto backend = q::take(q::Backend::create());
  std::map<std::string, q::Tensor> weights;
  std::vector<c::LeasePool> weight_pools;
  const auto manifest = std::filesystem::absolute(inputs / "weights.tsv");
  const auto loaded = q::load_weight_bank(manifest, backend, weights, weight_pools,
                                         q::WeightSelection::kTextAndMtp);
  require_prefix(weights.size() == 335, "expected original 335 weight inventory");

  // Use the production constructor, symbolic dimensions, norm and projection.
  // Do not expose the internal F32 cast/RMSNorm values: preserve that fusion.
  q::Recipe recipe(weights, backend, 2);
  const auto token_port = recipe.input(q::Recipe::dense_spec(
      q::Type::kInt32, {recipe.packed_rows}));
  const auto embedding = recipe.one(c::Gather{.bounds = c::IndexBoundsPolicy::kUnchecked},
      {recipe.weight("embed_tokens.weight"), token_port},
      q::Recipe::dense_spec(q::Type::kBFloat16, {recipe.packed_rows, q::f(2048)}));
  const auto normalized = recipe.norm(embedding, "layers.0.input_layernorm.weight");
  const auto qkv = recipe.linear(normalized, "layers.0.linear_attn.in_proj_qkv.weight");
  const std::array values{embedding, normalized, qkv};
  const std::array<const char *, 3> names{"embedding", "normalized", "qkv"};
  for (const auto value : values) recipe.publish(value);
  const auto graph = q::take(std::move(recipe.builder).finish());
  const std::array shapes{
      std::array{g::ShapeBinding{recipe.last_row, 0}},
      std::array{g::ShapeBinding{recipe.last_row, 1}}};
  const std::array variants{
      g::ExactShapeVariant{shapes[0]}, g::ExactShapeVariant{shapes[1]}};
  g::CompileOptions options{.shape_policy = g::CompileShapePolicy::kFiniteExact,
                           .exact_variants = variants, .constants = recipe.constants};
  const auto compiled = q::take(backend.compile(graph, recipe.constants, options));
  require_prefix(compiled.executable.exact_variant_count() == 2,
                 "prefix family must have exactly two finite children");
  const std::array<std::int32_t, 2> fixed_ids{71093, 12305};
  for (std::size_t variant = 0; variant < 2; ++variant) {
    const auto rows = variant + 1;
    const auto child = q::take(compiled.executable.exact_variant(variant));
    const auto report = q::take(compiled.report.exact_variant(variant));
    const auto folder = output / ("T" + std::to_string(rows));
    std::filesystem::create_directories(folder);
    q::Tensor input(backend.device(), q::dense(q::Type::kInt32,
                                              {static_cast<std::int64_t>(rows)}));
    input.write<std::int32_t>(std::span(fixed_ids).first(rows));
    std::array<q::Tensor, 3> caller;
    std::array<c::TensorDesc, 3> descriptions;
    auto run = q::take(compiled.executable.create_invocation({.shape = shapes[variant]}));
    q::check(run.prepare_resources());
    q::check(run.bind(token_port, input.read()));
    for (std::size_t port = 0; port < values.size(); ++port) {
      descriptions[port] = q::Model::output_description(report, values[port]);
      require_prefix(descriptions[port].data_type() == q::Type::kBFloat16,
                     "prefix diagnostic boundary is not BF16");
      for (std::size_t index = 0; index < child.output_count(); ++index) {
        if (q::take(child.output_id(index)) != values[port]) continue;
        if (q::take(child.output_ownership(index)) == g::OutputOwnership::kCaller) {
          caller[port] = q::Tensor(backend.device(), descriptions[port]);
          q::check(run.bind(values[port], caller[port].view()));
        }
      }
    }
    const auto queues = backend.queue_bindings();
    q::check(run.prepare_replay(queues, {.mode = g::ReplayMode::kCommands,
                                        .host_wait = g::HostWaitPolicy::kAllow}));
    auto completion = q::take(run.submit(queues));
    q::check(completion.wait());
    for (std::size_t port = 0; port < values.size(); ++port) {
      const auto bytes = q::take(descriptions[port].required_bytes());
      std::vector<std::byte> raw(bytes);
      if (caller[port].buffer) q::check(backend.read(caller[port].buffer.view(), raw));
      else {
        auto result = q::take(run.result(values[port]));
        auto lease = q::take(result.storage_lease());
        q::check(backend.read(q::take(lease.view()), raw));
      }
      save_bytes(folder / (std::string(names[port]) + ".bf16"), raw);
    }
    save_route(folder / "route.tsv", graph, report);
  }
  std::ofstream observation(output / "observation.json");
  observation << "{\"status\":\"PREFIX_DIAGNOSTIC_TERMINAL\",\"graph_calls\":2,"
      "\"snapshots_used\":0,\"weight_tensors\":335,\"weight_bytes\":" << loaded.bytes
      << ",\"manifest\":" << std::quoted(manifest.string())
      << ",\"tokens\":[[71093],[71093,12305]],\"boundaries\":["
      "{\"name\":\"embedding\",\"dtype\":\"BF16\",\"columns\":2048},"
      "{\"name\":\"normalized\",\"dtype\":\"BF16\",\"columns\":2048},"
      "{\"name\":\"qkv\",\"dtype\":\"BF16\",\"columns\":6144}],"
      "\"faithfulness\":\"OFFLINE_CHECK_REQUIRED\",\"quality_pass\":false,"
      "\"performance_comparison\":false}\n";
  require_prefix(static_cast<bool>(observation), "cannot write prefix observation");
  std::cout << "{\"status\":\"PREFIX_DIAGNOSTIC_TERMINAL\",\"graph_calls\":2,"
               "\"faithfulness\":\"OFFLINE_CHECK_REQUIRED\"}\n";
}
} // namespace

int main(int argc, char **argv) {
  try {
    std::filesystem::path inputs, output;
    for (int index = 1; index < argc; index += 2) {
      if (index + 1 == argc) throw std::runtime_error("prefix option lacks value");
      const std::string_view option(argv[index]);
      if (option == "--inputs") inputs = argv[index + 1];
      else if (option == "--output") output = argv[index + 1];
      else throw std::runtime_error("unknown prefix probe option");
    }
    require_prefix(!inputs.empty() && !output.empty(),
                   "usage: prefix_probe --inputs DIR --output FRESH_DIR");
    run_prefix(inputs, output);
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "Prefix diagnostic: " << error.what() << '\n';
    return 1;
  }
}
