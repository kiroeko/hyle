"""Two repeat processes of the fixed no-MTP prefix; no compiler or policy edits."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ar_repeat_helpers',S/'run_quality.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
image=h.read(S/'prefix-link1/ready.json')['image'];assert h.ident(image['path'])==image
env=os.environ.copy();env['PATH']=h.read(S/'prefix-link1/runtime-environment.json')['PATH']
comparisons=[];runs=[]
for index in [2,3]:
    folder=S/f'prefix-repeat{index}'
    command=[image['path'],'--inputs',str(h.V/'inputs/mtp'),'--output',str(folder/'vectors')]
    process=h.execute(command,env,folder,timeout=120)
    assert process['exit']==0 and not process['timed_out'],process
    observation=h.read(folder/'vectors/observation.json')
    assert observation['graph_calls']==2 and observation['snapshots_used']==0
    runs.append(dict(repetition=index,process=process,observation=observation,image=image))
    for rows in [1,2]:
        for boundary in ['embedding','normalized','qkv']:
            original=S/f'prefix1/vectors/T{rows}/{boundary}.bf16'
            actual=folder/f'vectors/T{rows}/{boundary}.bf16'
            equal=original.read_bytes()==actual.read_bytes()
            comparisons.append(dict(repetition=index,rows=rows,boundary=boundary,
                original=h.ident(original),actual=h.ident(actual),byte_equal=equal))
    print('REPEAT_COMPLETE',index,flush=True)
same=all(row['byte_equal']for row in comparisons)
h.save(S/'review/prefix-repeatability.json',dict(
    status='REPEATABLE_IN_THIS_BOUNDED_CONTROL'if same else'WITHIN_SHAPE_VARIABILITY_OBSERVED',
    reference_process=h.read(S/'prefix1/process.json'),repeated_processes=runs,
    total_independent_processes=3,total_native_graph_calls=6,
    MTP_compute_calls=0,Model_Session_Snapshot_instances=0,
    same_image=True,same_fixed_tokens=True,same_original_weights=True,same_dtype=True,
    all_embedding_norm_QKV_bytes_repeat=same,comparisons=comparisons,
    limits=['Finite repeatability on the current GPU/toolchain only; no universal determinism claim.',
            'Shape difference exists in ordinary Gather/Norm/MatMul with no draft, verifier, acceptance or cache-state operations.',
            'This does not by itself establish numerical acceptability or explain cross-engine continuation divergence.']))
print('ALL_REPEAT_BYTES_EQUAL',same,flush=True)
