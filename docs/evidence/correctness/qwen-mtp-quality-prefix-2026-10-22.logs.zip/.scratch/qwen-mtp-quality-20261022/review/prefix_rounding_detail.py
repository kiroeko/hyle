"""Pure-host detail for the already-run prefix1; never starts native work."""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import math
import struct

ROOT = Path(__file__).resolve().parents[3]
STAGE = ROOT/'.scratch/qwen-mtp-quality-20261022'


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def f32(bits):
    return struct.unpack('<f', struct.pack('<I', bits))[0]


def bfloat(bits):
    return f32(bits << 16)


def bf16_values(raw):
    return [bfloat(bits[0]) for bits in struct.iter_unpack('<H', raw)]


def rounded_integer(numerator, denominator):
    quotient, remainder = divmod(numerator, denominator)
    return quotient + (2*remainder > denominator or
                       (2*remainder == denominator and quotient % 2 != 0))


def round_binary(value, fraction_bits):
    """Correct RNE of the exact rational to BF16/F32, finite values only."""
    sign = int(value < 0)
    value = abs(value)
    if not value:
        return sign << (fraction_bits+8)
    n, d = value.numerator, value.denominator
    exponent = n.bit_length()-d.bit_length()
    if (n < d*(1 << exponent) if exponent >= 0 else (n << -exponent) < d):
        exponent -= 1
    normal = exponent >= -126
    shift = fraction_bits - (exponent if normal else -126)
    scaled_n, scaled_d = (n << shift, d) if shift >= 0 else (n, d << -shift)
    significand = rounded_integer(scaled_n, scaled_d)
    if normal:
        if significand == 1 << (fraction_bits+1):
            significand >>= 1
            exponent += 1
        assert exponent <= 127
        body = ((exponent+127) << fraction_bits) | (significand-(1 << fraction_bits))
    else:
        body = significand
    return (sign << (fraction_bits+8)) | body


def cell(bits, exact):
    # The eight observed channels are nonzero finite values, far from overflow.
    assert bits not in [0, 0x8000] and bits & 0x7f80 != 0x7f80
    previous = bits+1 if bits & 0x8000 else bits-1
    following = bits-1 if bits & 0x8000 else bits+1
    center = Fraction(bfloat(bits))
    lower = (Fraction(bfloat(previous))+center)/2
    upper = (center+Fraction(bfloat(following)))/2
    nearest = lower if abs(exact-lower) <= abs(exact-upper) else upper
    nearest_f32_bits = round_binary(nearest, 23)
    next_up = nearest_f32_bits-1 if nearest_f32_bits & 0x80000000 else nearest_f32_bits+1
    ulp = abs(Fraction(f32(next_up))-nearest)
    assert ulp > 0
    bf16_step = (center-Fraction(bfloat(previous)) if nearest == lower
                 else Fraction(bfloat(following))-center)
    return dict(previous_bits=f'0x{previous:04x}', previous=bfloat(previous),
                center_bits=f'0x{bits:04x}', center=bfloat(bits),
                following_bits=f'0x{following:04x}', following=bfloat(following),
                lower_midpoint=float(lower), upper_midpoint=float(upper),
                exact_dot_minus_lower_midpoint=float(exact-lower),
                exact_dot_minus_upper_midpoint=float(exact-upper),
                nearest_midpoint=float(nearest),
                distance_to_nearest_midpoint=float(abs(exact-nearest)),
                adjacent_BF16_step=float(bf16_step),
                distance_to_nearest_midpoint_in_BF16_steps=float(abs(exact-nearest)/bf16_step),
                local_F32_ULP=float(ulp),
                distance_to_nearest_midpoint_in_F32_ULPs=float(abs(exact-nearest)/ulp),
                lower_tie_rounds_to_center=(bits % 2 == 0),
                upper_tie_rounds_to_center=(bits % 2 == 0))


def main():
    output = STAGE/'review/prefix1-rounding-detail.json'
    analysis_path = STAGE/'review/prefix1-analysis.json'
    original_analysis_identity = identity(analysis_path)
    analysis = json.loads(analysis_path.read_text())
    assert analysis['full_model_qkv_row0_reproduced'] and analysis['route_compatible']
    assert analysis['native_row0_comparison']['embedding']['byte_equal']
    assert analysis['native_row0_comparison']['normalized']['byte_equal']
    data = STAGE/'prefix1/vectors'
    first = (data/'T1/qkv.bf16').read_bytes()[:12288]
    second = (data/'T2/qkv.bf16').read_bytes()[:12288]
    norm = (data/'T1/normalized.bf16').read_bytes()[:4096]
    assert norm == (data/'T2/normalized.bf16').read_bytes()[:4096]
    actual1 = [v[0] for v in struct.iter_unpack('<H', first)]
    actual2 = [v[0] for v in struct.iter_unpack('<H', second)]
    changed = [i for i in range(6144) if actual1[i] != actual2[i]]
    assert len(changed) == 8
    inputs = [Fraction(v) for v in bf16_values(norm)]
    source = analysis['source_weight_ranges']
    payload = Path(source['payload_path'])
    weight = source['ranges']['model.language_model.layers.0.linear_attn.in_proj_qkv.weight']
    rows = []
    with payload.open('rb') as stream:
        for index in changed:
            offset = weight['offset']+index*4096
            stream.seek(offset)
            raw = stream.read(4096)
            assert len(raw) == 4096
            weights = [Fraction(v) for v in bf16_values(raw)]
            products = [a*b for a, b in zip(inputs, weights)]
            exact = sum(products, Fraction())
            fp64_dot = math.fsum(float(value) for value in products)
            assert fp64_dot == float(exact)
            sum_abs = sum(map(abs, products), Fraction())
            exact_bf16 = round_binary(exact, 7)
            exact_f32_bits = round_binary(exact, 23)
            fp32_dot = f32(exact_f32_bits)
            fp32_then_bf16 = round_binary(Fraction(fp32_dot), 7)
            actuals = []
            for tokens, bits in [(1, actual1[index]), (2, actual2[index])]:
                value = Fraction(bfloat(bits))
                actuals.append(dict(rows=tokens, bits=f'0x{bits:04x}', value=float(value),
                    value_minus_exact_dot=float(value-exact),
                    same_as_exact_dot_BF16_RNE=(bits == exact_bf16),
                    same_as_FP32_dot_then_BF16_RNE=(bits == fp32_then_bf16),
                    rounding_cell=cell(bits, exact)))
            lo, hi = sorted((actual1[index], actual2[index]), key=bfloat)
            adjacent = abs(lo-hi) == 1
            shared = (Fraction(bfloat(lo))+Fraction(bfloat(hi)))/2 if adjacent else None
            rows.append(dict(channel=index,
                weight_range=dict(file=str(payload), offset=offset, bytes=4096,
                                  sha256=hashlib.sha256(raw).hexdigest()),
                exact_dot=dict(numerator=str(exact.numerator), denominator=str(exact.denominator)),
                FP64_math_fsum_dot=fp64_dot, FP64_hex=fp64_dot.hex(),
                FP64_rounding_error=float(Fraction(fp64_dot)-exact),
                sum_absolute_products=float(sum_abs),
                cancellation_condition_sum_abs_over_abs_dot=float(sum_abs/abs(exact)),
                all_BF16_products_exactly_representable_in_F32=all(
                    Fraction(f32(round_binary(value,23))) == value for value in products),
                exact_dot_BF16_RNE=dict(bits=f'0x{exact_bf16:04x}', value=bfloat(exact_bf16),
                                       rounding_cell=cell(exact_bf16, exact)),
                exact_dot_FP32_RNE=dict(bits=f'0x{exact_f32_bits:08x}', value=fp32_dot,
                                       error=float(Fraction(fp32_dot)-exact)),
                FP32_dot_then_BF16_RNE=dict(bits=f'0x{fp32_then_bf16:04x}',
                                          value=bfloat(fp32_then_bf16)),
                native_outputs=actuals, native_outputs_adjacent_BF16=adjacent,
                native_pair_shared_midpoint=float(shared) if shared is not None else None,
                exact_dot_minus_native_pair_midpoint=float(exact-shared) if shared is not None else None))
    distances = [r['exact_dot_BF16_RNE']['rounding_cell']['distance_to_nearest_midpoint_in_F32_ULPs']
                 for r in rows]
    counts = {str(bound): sum(value <= bound for value in distances)
              for bound in [0.5, 1, 2, 4, 16]}
    report = dict(status='FROZEN_PURE_HOST_EIGHT_CHANNEL_ROUNDING_DETAIL',
        quality_pass=False, numerical_tolerance_policy=None,
        parent_analysis=identity(analysis_path), parent_analysis_unchanged=True,
        raw_sources=[identity(data/path) for path in ['T1/qkv.bf16','T2/qkv.bf16',
                                                    'T1/normalized.bf16','T2/normalized.bf16']],
        manifest=source['manifest'], normalized_row0_sha256=hashlib.sha256(norm).hexdigest(),
        changed_channels=changed,
        summary=dict(T1_vs_exact_dot_BF16_RNE_different=[r['channel'] for r in rows
                     if not r['native_outputs'][0]['same_as_exact_dot_BF16_RNE']],
                     T2_vs_exact_dot_BF16_RNE_different=[r['channel'] for r in rows
                     if not r['native_outputs'][1]['same_as_exact_dot_BF16_RNE']],
                     exact_FP32_then_BF16_differs_from_direct_exact_BF16=[r['channel'] for r in rows
                     if r['exact_dot_BF16_RNE']['bits'] != r['FP32_dot_then_BF16_RNE']['bits']],
                     distances_to_nearest_BF16_midpoint_in_F32_ULPs=dict(zip(map(str,changed),distances)),
                     distances_to_nearest_BF16_midpoint_in_BF16_steps={str(r['channel']):
                         r['exact_dot_BF16_RNE']['rounding_cell']['distance_to_nearest_midpoint_in_BF16_steps']
                         for r in rows},
                     counts_within_F32_ULPs=counts,
                     note='Distance bins describe the eight observed channels, not an acceptance tolerance.'),
        channels=rows,
        actual_provider_contract=dict(path='src/compute_provider_cublas/cublas_provider.cc',
            source=identity(ROOT/'src/compute_provider_cublas/cublas_provider.cc'),
            lines=[180,219,417,480,491,515],
            facts=['T1 A[1,2048]/C[1,6144], T2 A[2,2048]/C[2,6144]; same BF16 stored weight is described as COL[2048,6144], not repacked.',
                   'Ordinary BF16 A/B/C use CUBLAS_COMPUTE_32F; F32 inputs alone use PEDANTIC.',
                   'Each exact layout independently asks cuBLASLt for one heuristic and retains that algorithm. No M1/M2 algorithm identity or reduction-tree equivalence is guaranteed by this wrapper.',
                   'REDUCTION_SCHEME_COMPUTE_TYPE requests F32 split-K partial reduction. It does not make the sum an exact mathematical dot or fix its order.',
                   'The rejected scratch two-row-as-batch optimization was never promoted; current source has no special M2 rewrite.']),
        interpretation=[
            'Faithful original QKV bytes plus identical embedding/norm locate this measured first difference inside the ordinary BF16 projection. This is a causal localization, not a numerical bug verdict.',
            'For channels extremely close to a BF16 midpoint, a small unobserved F32 accumulation change can select neighboring BF16 values. The exact-dot FP32-then-BF16 reference distinguishes double rounding of the ideal sum from arithmetic error accumulated before the final conversion.',
            'The native kernel exposes only BF16 C. Its actual F32 accumulator, selected heuristic ID and partial reduction tree were not captured. Therefore this report cannot certify that either output was produced by a particular legal F32 order or prove an illegal cuBLAS computation.',
            'The two small cancellation-sensitive outputs require special care: relative/BF16-ULP differences can be large while absolute dot error is small; neither small absolute error nor ill-conditioning is a model-quality acceptance test.',
            'No precision/provider/sampler policy, threshold, product source or native experiment is changed here. The separately observed four-arm complex-sort failures are auxiliary model-task observations, not a new MTP completion gate or proof that MTP introduced the task failure.'],
        activity=dict(native_runs=0,builds=0,GPU_runs=0,product_edits=0,
                      weight_payload_read_bytes=8*4096,
                      independent_exact_rational_dot_channels=8))
    assert identity(analysis_path) == original_analysis_identity
    output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(summary=report['summary'],output=identity(output)),indent=2))


if __name__ == '__main__':
    main()
