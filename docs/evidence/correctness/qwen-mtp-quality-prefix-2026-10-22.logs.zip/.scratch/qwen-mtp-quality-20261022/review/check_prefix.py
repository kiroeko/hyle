"""Offline only. Run after the scratch prefix consumer; no inference on import."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import re
import struct
import zipfile

ROOT = Path(__file__).resolve().parents[3]


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def normalized_path(value):
    return re.sub('/+', '/', str(value).replace('\\', '/'))


def bf16(raw):
    assert len(raw) % 2 == 0
    values = [struct.unpack('<f', struct.pack('<I', v[0] << 16))[0]
              for v in struct.iter_unpack('<H', raw)]
    assert all(math.isfinite(v) for v in values), 'nonfinite BF16 diagnostic data'
    return values


def rne_bf16(value):
    # Round the independent FP64 result directly, not via an extra FP32 round.
    assert math.isfinite(value)
    if value == 0.0:
        return struct.pack('<H', 0x8000 if math.copysign(1.0, value) < 0 else 0)
    sign = 0x8000 if value < 0 else 0
    magnitude = abs(value)
    mantissa, exponent = math.frexp(magnitude)
    if exponent < -125:
        code = round(math.ldexp(magnitude, 133))
    else:
        significand = round(math.ldexp(mantissa, 8))
        if significand == 256:
            significand = 128
            exponent += 1
        code = ((exponent + 126) << 7) | (significand - 128)
    assert 0 <= code < 0x7f80, 'independent result outside finite BF16 domain'
    return struct.pack('<H', sign | code)


def metrics(reference, actual):
    assert len(reference) == len(actual)
    a, b = bf16(reference), bf16(actual)
    squared = math.fsum((x-y)*(x-y) for x, y in zip(a, b))
    norm = math.fsum(x*x for x in a)
    changed = [i for i, (x, y) in enumerate(zip(
        struct.iter_unpack('<H', reference), struct.iter_unpack('<H', actual))) if x != y]
    return dict(bytes=len(actual), elements=len(a), byte_equal=reference == actual,
                changed_elements=len(changed), changed_indices=changed,
                max_abs=max((abs(x-y) for x, y in zip(a, b)), default=0.0),
                squared_error=squared, reference_squared=norm,
                relative_L2=math.sqrt(squared/norm) if norm else None)


def archived_history(manifest, archive, suffix):
    records = [r for r in manifest['archive_files']
               if normalized_path(r['path']).endswith(suffix)]
    assert len(records) == 1, (suffix, len(records))
    record = records[0]
    raw = archive.read(record['entry'])  # ZIP CRC is also checked here.
    assert len(raw) == record['bytes']
    assert hashlib.sha256(raw).hexdigest() == record['sha256']
    assert len(raw) == 3*6144*2
    return raw[-6144*2:], record


def read_weight_ranges(manifest_path):
    with manifest_path.open(encoding='utf-8-sig') as stream:
        signature, payload, source_id = [stream.readline().strip() for _ in range(3)]
        assert signature == 'HYLE_QWEN35_TEXT_MTP_V1'
        assert source_id == '4068044d8571635d8a86f1e96a43dad104efc7089169065f735601e350008155'
        records = {}
        for line in stream:
            fields = line.split()
            if not fields:
                continue
            rank = int(fields[2])
            records[fields[0]] = dict(dtype=fields[1], shape=list(map(int, fields[3:3+rank])),
                                     offset=int(fields[3+rank]), bytes=int(fields[4+rank]))
    payload = Path(payload)
    if not payload.is_absolute():
        payload = manifest_path.parent / payload
    names = ['model.language_model.' + value for value in
             ['embed_tokens.weight', 'layers.0.input_layernorm.weight',
              'layers.0.linear_attn.in_proj_qkv.weight']]
    embedding, norm, weight = [records[name] for name in names]
    assert (embedding['dtype'], embedding['shape']) == ('BF16', [248320, 2048])
    assert (norm['dtype'], norm['shape']) == ('BF16', [2048])
    assert (weight['dtype'], weight['shape']) == ('BF16', [6144, 2048])
    with payload.open('rb') as stream:
        rows = []
        for token in [71093, 12305]:
            stream.seek(embedding['offset'] + token*4096)
            rows.append(stream.read(4096))
        stream.seek(norm['offset'])
        norm_raw = stream.read(norm['bytes'])
        stream.seek(weight['offset'])
        weight_raw = stream.read(weight['bytes'])
    assert all(len(row) == 4096 for row in rows)
    assert len(norm_raw) == 4096 and len(weight_raw) == 25165824
    return rows, norm_raw, weight_raw, dict(
        manifest=identity(manifest_path), payload_path=str(payload),
        ranges={name: records[name] for name in names},
        qkv_range_sha256=hashlib.sha256(weight_raw).hexdigest(),
        norm_range_sha256=hashlib.sha256(norm_raw).hexdigest(),
        embedding_row_sha256=[hashlib.sha256(row).hexdigest() for row in rows])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--weights-manifest', type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), 'offline report must not overwrite evidence'
    observation = json.loads((args.data/'observation.json').read_text())
    assert observation['status'] == 'PREFIX_DIAGNOSTIC_TERMINAL'
    assert observation['graph_calls'] == 2 and observation['snapshots_used'] == 0
    assert observation['tokens'] == [[71093], [71093, 12305]]
    manifest_path = args.weights_manifest or Path(observation['manifest'])
    token_rows, norm_raw, weight_raw, ranges = read_weight_ranges(manifest_path)
    raw = {}
    for rows in [1, 2]:
        raw[rows] = {}
        for name, columns in [('embedding', 2048), ('normalized', 2048), ('qkv', 6144)]:
            path = args.data/f'T{rows}'/(name+'.bf16')
            data = path.read_bytes()
            assert len(data) == rows*columns*2, (path, len(data))
            bf16(data)
            raw[rows][name] = data
        assert raw[rows]['embedding'] == b''.join(token_rows[:rows]), 'Gather differs from original token rows'
    public_path = ROOT/'docs/evidence/correctness/qwen-mtp-current-numerics-2026-10-22.json'
    public = json.loads(public_path.read_text())
    archive_path = ROOT/'docs/evidence/correctness/qwen-mtp-current-numerics-2026-10-22.data.zip'
    faithfulness = []
    with zipfile.ZipFile(archive_path) as archive:
        for rows in [1, 2]:
            original, record = archived_history(public, archive,
                f'/probe1/vectors/P154_T{rows}/layer0.conv.bf16')
            actual = raw[rows]['qkv'][:6144*2]
            faithfulness.append(dict(rows=rows, original=record,
                                      comparison=metrics(original, actual)))
    faithful = all(row['comparison']['byte_equal'] for row in faithfulness)
    x, delta = bf16(token_rows[0]), bf16(norm_raw)
    epsilon = struct.unpack('<f', struct.pack('<f', 1e-6))[0]
    reciprocal = 1/math.sqrt(math.fsum(value*value for value in x)/2048 + epsilon)
    exact_norm = [value*(scale+1.0)*reciprocal for value, scale in zip(x, delta)]
    norm_reference = b''.join(rne_bf16(value) for value in exact_norm)
    projection = []
    for rows in [1, 2]:
        native_norm_raw = raw[rows]['normalized'][:4096]
        native_norm = bf16(native_norm_raw)
        reference = bytearray()
        max_unrounded_error = 0.0
        actual = bf16(raw[rows]['qkv'][:6144*2])
        for channel in range(6144):
            values = bf16(weight_raw[channel*4096:(channel+1)*4096])
            dot = math.fsum(a*b for a, b in zip(native_norm, values))
            reference += rne_bf16(dot)
            max_unrounded_error = max(max_unrounded_error, abs(actual[channel]-dot))
        projection.append(dict(rows=rows,
            own_native_normalized_input_vs_FP64_dot=metrics(bytes(reference), raw[rows]['qkv'][:12288]),
            own_native_normalized_input_max_abs_vs_unrounded_FP64_dot=max_unrounded_error,
            native_norm_vs_independent_FP64_norm=metrics(norm_reference, native_norm_raw)))
    norm_equal = raw[1]['normalized'][:4096] == raw[2]['normalized'][:4096]
    qkv_equal = raw[1]['qkv'][:12288] == raw[2]['qkv'][:12288]
    cause = ('NOT_REPRODUCED_NO_ATTRIBUTION' if not faithful else
             'NORM_PREFIX_FIRST_DIFFERENCE' if not norm_equal else
             'ORDINARY_BF16_QKV_PROJECTION_FIRST_DIFFERENCE' if not qkv_equal else
             'NO_LOCAL_T1_T2_DIFFERENCE')
    routes = []
    for rows in [1, 2]:
        path = args.data/f'T{rows}'/'route.tsv'
        text = path.read_text()
        # Necessary route facts, not a claim of identical native algorithm/address.
        rms_fused = any('ggml-cuda' in line and ':rms-norm' in line and line.count(':cast') == 2
                        for line in text.splitlines())
        qkv_direct = any('cublasLt' in line and ':matmul' in line and ',' not in line
                         for line in text.splitlines())
        routes.append(dict(rows=rows, source=identity(path),
                           original_norm_fusion_present=rms_fused,
                           original_cublas_projection_present=qkv_direct))
    route_compatible = all(r['original_norm_fusion_present'] and
                           r['original_cublas_projection_present'] for r in routes)
    if not route_compatible:
        cause = 'ROUTE_NOT_REPRODUCED_NO_ATTRIBUTION'
    report = dict(status='OFFLINE_PREFIX_DIAGNOSTIC_COMPLETE',
        cause_scope=cause, quality_pass=False, numerical_tolerance_policy=None,
        performance_comparison=False, actual_native_runs_started_by_checker=0,
        observation=identity(args.data/'observation.json'), source_weight_ranges=ranges,
        old_public_manifest=identity(public_path), faithfulness=faithfulness,
        full_model_qkv_row0_reproduced=faithful, route_compatible=route_compatible, routes=routes,
        native_row0_comparison={name: metrics(raw[1][name][:columns*2], raw[2][name][:columns*2])
            for name, columns in [('embedding',2048),('normalized',2048),('qkv',6144)]},
        independent_references=projection,
        limitations=['FP64 reference quantifies native FP32 reduction/BF16 rounding errors; bit differences alone are not an invented numerical tolerance failure.',
                    'No attribution to archived model discrepancy unless both row0 byte faithfulness and necessary route facts hold.',
                    'This prefix has no recurrent/KV/position dependence and does not establish full model quality or downstream error amplification.'])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(cause_scope=cause, full_model_qkv_row0_reproduced=faithful,
                         route_compatible=route_compatible)))


if __name__ == '__main__':
    main()
