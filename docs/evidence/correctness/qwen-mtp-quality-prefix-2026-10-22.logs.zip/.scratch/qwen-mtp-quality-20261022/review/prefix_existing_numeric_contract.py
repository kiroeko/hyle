"""Pure CPU recheck of the already exported prefix1 BF16 projection row0.

Reads only the identified original weight ranges and saved diagnostic vectors.
No Torch, native backend, GPU query, model inference or build is imported/run.
"""
from pathlib import Path
from fractions import Fraction
import argparse
import hashlib
import importlib.util
import json
import math
import struct
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
STAGE = ROOT / '.scratch/qwen-mtp-quality-20261022'
K, N = 2048, 6144
GAMMA = Fraction(K, 2**24 - K)


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def value(bits):
    return struct.unpack('<f', struct.pack('<I', bits << 16))[0]


def dyadic(bits):
    exponent, fraction = (bits >> 7) & 255, bits & 127
    assert exponent != 255
    sign = -1 if bits & 0x8000 else 1
    return (sign * (128 + fraction), exponent - 134) if exponent else (sign * fraction, -133)


def as_fraction(integer, exponent):
    return Fraction(integer << exponent) if exponent >= 0 else Fraction(integer, 1 << -exponent)


def exact_sums(left, right):
    terms = [(a * b, ae + be) for (a, ae), (b, be) in zip(left, right) if a and b]
    if not terms:
        return Fraction(), Fraction(), None
    exponent = min(e for _, e in terms)
    signed = sum(n << (e - exponent) for n, e in terms)
    absolute = sum(abs(n) << (e - exponent) for n, e in terms)
    return as_fraction(signed, exponent), as_fraction(absolute, exponent), exponent


def rounding_cell(bits):
    assert bits & 0x7f80 != 0x7f80
    center = Fraction(value(bits))
    if bits in (0, 0x8000):
        # Numerical zero cell; signed-zero provenance is not decided here.
        return -Fraction(1, 2**134), Fraction(1, 2**134), True
    previous = bits + 1 if bits & 0x8000 else bits - 1
    following = bits - 1 if bits & 0x8000 else bits + 1
    if previous & 0x7f80 == 0x7f80:
        upper_neighbor = Fraction(value(following))
        lower = center - (upper_neighbor - center) / 2
    else:
        lower = (Fraction(value(previous)) + center) / 2
    if following & 0x7f80 == 0x7f80:
        lower_neighbor = Fraction(value(previous))
        upper = center + (center - lower_neighbor) / 2
    else:
        upper = (center + Fraction(value(following))) / 2
    return lower, upper, bits % 2 == 0


def update_max(stats, key, number, witness):
    if stats.get(key) is None or number > stats[key]['value']:
        stats[key] = dict(value=number, **witness)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=STAGE / 'prefix1/vectors')
    parser.add_argument('--weights-manifest', type=Path)
    parser.add_argument('--output', type=Path,
                        default=STAGE / 'review/prefix-existing-numeric-contract.json')
    args = parser.parse_args()
    assert not args.output.exists(), 'choose a new output path to preserve prior evidence'
    helper_path = STAGE / 'review/check_prefix.py'
    spec = importlib.util.spec_from_file_location('ar_original_prefix_readers', helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    observation = json.loads((args.data / 'observation.json').read_text())
    assert observation['status'] == 'PREFIX_DIAGNOSTIC_TERMINAL'
    assert observation['tokens'] == [[71093], [71093, 12305]]
    manifest = args.weights_manifest or Path(observation['manifest'])
    _, original_norm, weights_raw, ranges = helper.read_weight_ranges(manifest)
    assert len(original_norm) == 4096 and len(weights_raw) == 25165824
    normalized_raw, normalized, actual_bits, sources = {}, {}, {}, []
    for rows in (1, 2):
        norm_path = args.data / f'T{rows}/normalized.bf16'
        output_path = args.data / f'T{rows}/qkv.bf16'
        norm_raw, output_raw = norm_path.read_bytes(), output_path.read_bytes()
        assert len(norm_raw) == rows * K * 2 and len(output_raw) == rows * N * 2
        normalized_raw[rows] = norm_raw[:K * 2]
        normalized[rows] = helper.bf16(normalized_raw[rows])
        actual_bits[rows] = [x[0] for x in struct.iter_unpack('<H', output_raw[:N * 2])]
        assert all(math.isfinite(value(x)) for x in actual_bits[rows])
        sources.extend([identity(norm_path), identity(output_path)])
    assert normalized_raw[1] == normalized_raw[2], 'this exact common-input diagnostic requires equal row0'
    input_dyadic = [dyadic(x[0]) for x in struct.iter_unpack('<H', normalized_raw[1])]
    test_path = ROOT / 'tests/compute_provider_cublas/cublas_provider_test.cc'
    test_text = test_path.read_text()
    formula = '0.008 * std::abs(expected) + 0.0001'
    formula_lines = [i for i, line in enumerate(test_text.splitlines(), 1) if formula in line]
    assert len(formula_lines) == 1
    stats = {rows: dict(elements=N, existing_regression_failures=[],
                        f32_bound_cell_incompatibilities=[], exact_zero_dots=0,
                        nonzero_output_for_exact_zero=0, fsum_vs_exact_float_differences=0)
             for rows in (1, 2)}
    products_tested = 0
    products_f32_exact = True
    smallest_product_unit_exponent = None
    largest_sum_abs = 0.0
    for channel in range(N):
        raw = weights_raw[channel * K * 2:(channel + 1) * K * 2]
        bits = [x[0] for x in struct.iter_unpack('<H', raw)]
        weights = [value(x) for x in bits]
        exact, exact_sum_abs, unit_exponent = exact_sums(input_dyadic, [dyadic(x) for x in bits])
        if unit_exponent is not None:
            smallest_product_unit_exponent = (unit_exponent if smallest_product_unit_exponent is None
                                             else min(smallest_product_unit_exponent, unit_exponent))
        bound = GAMMA * exact_sum_abs
        largest_sum_abs = max(largest_sum_abs, float(exact_sum_abs))
        for rows in (1, 2):
            # Separate fsum calls for each shape's actual BF16 input row.
            products = [a * b for a, b in zip(normalized[rows], weights)]
            dot = math.fsum(products)
            sum_abs = math.fsum(abs(x) for x in products)
            if rows == 1:
                products_tested += len(products)
                products_f32_exact = products_f32_exact and all(
                    struct.unpack('<f', struct.pack('<f', x))[0] == x for x in products)
            output_bits = actual_bits[rows][channel]
            actual = value(output_bits)
            error = abs(actual - dot)
            tolerance = 0.008 * abs(dot) + 0.0001
            ratio = error / tolerance
            lower, upper, ties_closed = rounding_cell(output_bits)
            compatible = not (exact + bound < lower or exact - bound > upper)
            if not ties_closed and (exact + bound == lower or exact - bound == upper):
                compatible = False
            shift = max(lower - exact, exact - upper, Fraction())
            witness = dict(channel=channel, actual_bits=f'0x{output_bits:04x}', actual=actual,
                           FP64_fsum_dot=dot, sum_absolute_products=sum_abs,
                           absolute_error=error, existing_tolerance=tolerance,
                           existing_error_ratio=ratio, f32_gamma_sumabs=float(bound),
                           BF16_cell_lower=float(lower), BF16_cell_upper=float(upper),
                           BF16_cell_ties_included=ties_closed)
            own = stats[rows]
            if error > tolerance:
                own['existing_regression_failures'].append(witness)
            if not compatible:
                own['f32_bound_cell_incompatibilities'].append(witness)
            if dot != float(exact):
                own['fsum_vs_exact_float_differences'] += 1
            if exact == 0:
                own['exact_zero_dots'] += 1
                own['nonzero_output_for_exact_zero'] += actual != 0
            update_max(own, 'max_absolute_error', error, witness)
            update_max(own, 'max_existing_error_ratio', ratio, witness)
            if dot:
                update_max(own, 'max_relative_error_nonzero_dot', error / abs(dot), witness)
                update_max(own, 'max_cancellation_condition', sum_abs / abs(dot), witness)
            update_max(own, 'max_sum_absolute_products', sum_abs, witness)
            if bound:
                update_max(own, 'max_required_cell_shift_over_f32_bound', float(shift / bound), witness)
    for own in stats.values():
        own['existing_regression_failure_count'] = len(own['existing_regression_failures'])
        own['f32_bound_cell_incompatibility_count'] = len(own['f32_bound_cell_incompatibilities'])
    report = dict(
        status='FINITE_CPU_EXISTING_NUMERICAL_CONTRACT_RECHECK_COMPLETE',
        quality_pass=False, vendor_algorithm_legality_proven=False, performance_comparison=False,
        scope='prefix1 T1/T2 row0, all6144 QKV channels each, K2048; actual BF16 normalized input and original BF16 weight rows',
        script=identity(Path(__file__)), reused_readers=identity(helper_path),
        observation=identity(args.data / 'observation.json'), saved_vectors=sources,
        source_weight_ranges=ranges, normalized_row0_equal_between_shapes=True,
        normalized_row0_sha256=hashlib.sha256(normalized_raw[1]).hexdigest(),
        existing_regression_contract=dict(source=identity(test_path), formula_line=formula_lines[0],
            formula='abs(actual_BF16_float - FP64_fsum_dot) <= 0.008*abs(FP64_fsum_dot)+0.0001',
            unchanged_coefficients=True,
            reference_note='Reuse the existing test tolerance formula exactly. The original test accumulates a sequential double expected; this audit independently uses the requested math.fsum dot, without first rounding expected to BF16.'),
        f32_necessary_bound=dict(unit_roundoff='2^-24', terms=K,
            gamma_exact=f'{GAMMA.numerator}/{GAMMA.denominator}', gamma=float(GAMMA),
            formula='BF16_RNE_cell(actual) intersects [exact_dyadic_dot - gamma2048*exact_sumabs, exact_dyadic_dot + gamma2048*exact_sumabs]',
            exact_reference='Original BF16 significands and powers of two are accumulated as exact integers/rationals for dot and sumabs; each shape also has an independent FP64 math.fsum dot.',
            products_checked=products_tested, all_BF16_products_exactly_representable_F32=products_f32_exact,
            smallest_nonzero_product_unit_exponent=smallest_product_unit_exponent,
            all_possible_nonzero_exact_partial_sums_normal_under_common_unit=(smallest_product_unit_exponent is not None and smallest_product_unit_exponent >= -126),
            common_product_unit_at_least_F32_min_subnormal=(smallest_product_unit_exponent is not None and smallest_product_unit_exponent >= -149),
            addition_model='Ideal round-to-nearest F32 with gradual underflow and no overflow. The common product quantum is at least2^-149, so any subnormal intermediate sum on that lattice is exactly representable; this does not establish vendor FTZ/DAZ or internal precision behavior.',
            max_exact_sumabs=largest_sum_abs, max_exact_sumabs_below_F32_max=largest_sum_abs < struct.unpack('<f', struct.pack('<I', 0x7f7fffff))[0],
            interpretation='A necessary compatibility condition for the stated idealized F32 summation bound plus BF16 RNE, not evidence that a vendor implements a particular legal reduction algorithm. Comparing the rounded BF16 center directly to a pure F32 bound would omit final rounding. Numerical zero cells combine signed zeros.'),
        shapes={f'T{rows}': own for rows, own in stats.items()},
        operations=dict(original_QKV_range_read_bytes=25165824, original_norm_weight_read_bytes=4096,
            original_embedding_rows_read_bytes=8192, independent_FP64_fsum_dots=2*N,
            native_runs=0, builds=0, GPU_queries=0, network=0),
        limits=['Only the already exported first projection row0 is assessed. No model/task quality, downstream error amplification, all-shape tolerance or cross-backend equality is signed.',
                'No threshold was selected or changed from observed data. Error ratios use the existing test formula with its absolute floor.',
                'The standard F32 forward bound here is conditional on ideal F32 rounding, gradual underflow and no overflow. Some exact products/possible sums are subnormal; the common lattice permits exact subnormal addition under that ideal model. These checks do not identify or prove vendor FTZ/DAZ, intermediate precision or a particular reduction.'])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(output=str(args.output), shapes={name: dict(
        failures=own['existing_regression_failure_count'], max_error=own['max_absolute_error']['value'],
        max_ratio=own['max_existing_error_ratio']['value'],
        max_relative=own['max_relative_error_nonzero_dot']['value'],
        cell_incompatible=own['f32_bound_cell_incompatibility_count']) for name, own in report['shapes'].items()})))


if __name__ == '__main__':
    main()
