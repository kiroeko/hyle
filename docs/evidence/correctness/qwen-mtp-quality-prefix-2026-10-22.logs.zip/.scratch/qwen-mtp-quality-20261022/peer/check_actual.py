"""Offline original-GGML local control. Does not execute a model or GPU API."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import struct


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def f32s(raw):
    assert len(raw) % 4 == 0
    result = [v[0] for v in struct.iter_unpack('<f', raw)]
    assert all(math.isfinite(v) for v in result)
    return result


def bf16s(raw):
    return [struct.unpack('<f', struct.pack('<I', bits[0] << 16))[0]
            for bits in struct.iter_unpack('<H', raw)]


def narrow(value):
    bits = struct.unpack('<I', struct.pack('<f', value))[0]
    bits += 0x7fff + ((bits >> 16) & 1)
    return struct.unpack('<f', struct.pack('<I', (bits >> 16) << 16))[0]


def errors(reference, actual):
    assert len(reference) == len(actual)
    sq = math.fsum((a-b)*(a-b) for a,b in zip(reference,actual))
    den = math.fsum(a*a for a in reference)
    return dict(elements=len(actual), max_abs=max(abs(a-b) for a,b in zip(reference,actual)),
                squared_error=sq, reference_squared=den,
                relative_L2=math.sqrt(sq/den) if den else None)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--model', type=Path)
    args = parser.parse_args()
    assert not args.output.exists()
    observation_path = args.data/'observation.json'
    observation = json.loads(observation_path.read_text())
    assert observation['status'] == 'ORIGINAL_GGML_PREFIX_TERMINAL'
    assert observation['graph_calls'] == 4 and observation['repeats_per_shape'] == 2
    assert observation['tokens'] == [71093,12305]
    assert observation['qkv_type'] == observation['normalized_type'] == 'F32'
    raw, sources, repeats = {}, [], []
    for rows in [1,2]:
        raw[rows] = {}
        for name,columns in [('embedding',2048),('normalized',2048),('qkv',6144)]:
            a = args.data/f'T{rows}'/'r1'/(name+'.f32')
            b = args.data/f'T{rows}'/'r2'/(name+'.f32')
            first,second = a.read_bytes(),b.read_bytes()
            assert len(first) == len(second) == rows*columns*4
            f32s(first);f32s(second)
            repeats.append(dict(rows=rows,boundary=name,byte_equal=first==second))
            raw[rows][name] = first
            sources.extend([identity(a),identity(b)])
    model = args.model or Path(observation['model'])
    ranges = observation['GGUF_ranges']
    with model.open('rb') as file:
        def read(offset,count):
            file.seek(offset);result=file.read(count);assert len(result)==count;return result
        assert ranges['qkv']['bytes'] == 25165824 and ranges['norm']['bytes'] == 8192
        weight = read(ranges['qkv']['offset'],ranges['qkv']['bytes'])
        scale_raw = read(ranges['norm']['offset'],ranges['norm']['bytes'])
        embedding = [read(offset,4096) for offset in ranges['embedding']['selected_row_offsets']]
    original_rows = [bf16s(row) for row in embedding]
    scale = f32s(scale_raw)
    root = Path(__file__).resolve().parents[3]
    hyle_analysis_path = root/'.scratch/qwen-mtp-quality-20261022/review/prefix1-analysis.json'
    hyle_analysis = json.loads(hyle_analysis_path.read_text())
    original_source = hyle_analysis['source_weight_ranges']
    original_norm = original_source['ranges']['model.language_model.layers.0.input_layernorm.weight']
    with Path(original_source['payload_path']).open('rb') as file:
        file.seek(original_norm['offset'])
        original_delta = file.read(4096)
    assert len(original_delta) == 4096
    expected_scale = b''.join(struct.pack('<f',v+1.0) for v in bf16s(original_delta))
    shared_weight_facts = dict(
        Hyle_original_qkv_range_sha256=original_source['qkv_range_sha256'],
        GGUF_qkv_equals_Hyle_original_QKV_bytes=(hashlib.sha256(weight).hexdigest() ==
                                                 original_source['qkv_range_sha256']),
        GGUF_norm_equals_original_BF16_delta_plus_one_F32=(scale_raw == expected_scale),
        note='Cross-engine channel comparison requires actual byte identity; converter row rearrangement is not assumed absent.')
    assert f32s(raw[1]['embedding']) == original_rows[0]
    assert f32s(raw[2]['embedding']) == original_rows[0]+original_rows[1]
    cross = {}
    for name,columns in [('embedding',2048),('normalized',2048),('qkv',6144)]:
        a,b = raw[1][name][:columns*4],raw[2][name][:columns*4]
        aa,bb = f32s(a),f32s(b)
        cross[name] = dict(byte_equal=a==b, changed_elements=sum(x!=y for x,y in zip(
            struct.iter_unpack('<I',a),struct.iter_unpack('<I',b))), **errors(aa,bb))
    epsilon = struct.unpack('<f',struct.pack('<f',1e-6))[0]
    inverse = 1/math.sqrt(math.fsum(v*v for v in original_rows[0])/2048+epsilon)
    norm_reference = [a*b*inverse for a,b in zip(original_rows[0],scale)]
    oracle = []
    selected = [2507,2899,2918,3090,4012,4744,5376,5642]
    for rows in [1,2]:
        normalized = f32s(raw[rows]['normalized'][:8192])
        rounded = [narrow(v) for v in normalized]
        output = f32s(raw[rows]['qkv'][:24576])
        exact,rounded_input = [],[]
        for channel in range(6144):
            row = bf16s(weight[channel*4096:(channel+1)*4096])
            exact.append(math.fsum(a*b for a,b in zip(normalized,row)))
            rounded_input.append(math.fsum(a*b for a,b in zip(rounded,row)))
        oracle.append(dict(rows=rows,
            normalized_vs_FP64_norm=errors(norm_reference,normalized),
            qkv_vs_own_F32_normalized_FP64_dot=errors(exact,output),
            qkv_vs_BF16_rounded_normalized_FP64_dot=errors(rounded_input,output),
            selected_channels=[dict(channel=i,output=output[i],
                output_bits=f'0x{struct.unpack("<I",raw[rows]["qkv"][i*4:(i+1)*4])[0]:08x}',
                own_F32_input_FP64_dot=exact[i], BF16_rounded_input_FP64_dot=rounded_input[i]) for i in selected]))
    report=dict(status='OFFLINE_ORIGINAL_GGML_PREFIX_CONTROL_COMPLETE',
        observation=identity(observation_path),raw_sources=sources, repeat_comparisons=repeats,
        cross_shape_row0=cross, own_input_references=oracle,
        original_GGUF_ranges=dict(model_path=str(model),ranges=ranges,
            qkv_sha256=hashlib.sha256(weight).hexdigest(),norm_sha256=hashlib.sha256(scale_raw).hexdigest()),
        shared_weight_identity=shared_weight_facts,
        quality_pass=False,numerical_tolerance_policy=None,performance_comparison=False,
        limits=['Local source-consistent GGML prefix only. Host exact widening replaces get_rows; normalized boundary is explicitly retained, so full llama scheduler/fusion/address faithfulness is not proved.',
                'Actual peer retains F32 normalized/QKV outputs. Do not compare these directly as if they were Hyle BF16 boundaries or force a BF16 cast into the native peer graph.',
                'The BF16-rounded-input oracle is offline diagnostic data for a possible internal MMA conversion; it is not a changed input/precision policy.',
                'M1 vector versus M2 matrix selection is source-predicted for the fixed cache/device. No kernel trace or full-model same-Snapshot equality is claimed.'],
        activity=dict(native_runs=0,builds=0,GPU_runs=0,product_edits=0))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(repeat_all_byte_equal=all(r['byte_equal'] for r in repeats),
                         cross_shape_row0=cross)))


if __name__ == '__main__':
    main()
