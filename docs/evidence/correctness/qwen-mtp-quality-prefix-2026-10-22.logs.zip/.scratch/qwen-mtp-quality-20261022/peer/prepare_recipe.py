"""Prepare the one-TU peer-prefix recipe only; never build or run anything."""
from pathlib import Path
import argparse
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    assert args.attempt > 0
    old_path = ROOT/'.scratch/qwen-mtp-window-20261022/peer/build-plan.json'
    old = json.loads(old_path.read_text())
    compile_record = ROOT/'.scratch/qwen-mtp-quality-20261022/compile3/peer/identity.json'
    current_compile = json.loads(compile_record.read_text())
    previous_compile = Path(current_compile['object']['path']).parent
    link_record = ROOT/'.scratch/qwen-mtp-quality-20261022/peer-link1/link-plan.json'
    current_link = json.loads(link_record.read_text())
    previous_link = link_record.parent
    output = HERE/'checks'/f'attempt{args.attempt}'
    source = HERE/'peer_prefix.cc'
    command = [str(source) if Path(x) == Path(current_compile['source']['path'])
               else x.replace(str(previous_compile), str(output)) for x in current_compile['command']]
    # The fixed peer command is C++17; this TU deliberately uses the same mode.
    assert str(source) in command and '/std:c++17' in command
    link = [str(output/'peer.obj') if Path(x) == Path(current_compile['object']['path'])
            else x.replace(str(previous_link), str(output)) for x in current_link['command']]
    ggml = ROOT/'.scratch/legacy-root/hyle-scratch/ggml-native-static/src/compute_ggml_runtime/source-4e1a7b2f39afe15d'
    model = ROOT/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer/Qwen3.5-2B-text-MTP-BF16.gguf'
    plan = dict(status='PREPARED_NOT_BUILT_LINKED_OR_RUN', cwd=str(ROOT),
        output_directory=str(output), source=identity(source), compile=command, link=link,
        retained_native_input_records_not_rehashed=current_link['inputs'][1:],
        retained_link_reference=str(link_record), compile_recipe_reference=str(compile_record),
        runtime_environment_reference=old['runtime_environment_reference'],
        header_identities=[identity(ggml/'include'/name) for name in
                           ['ggml.h','ggml-alloc.h','ggml-backend.h','ggml-cuda.h','gguf.h']],
        source_API_commit=old['source_API_commit'], new_CXX_TUs=1, new_links=1,
        SDK_builds=0, NVCC=0,
        run=dict(command=[str(output/'peer.exe'), '--model', str(model),
                          '--output', str(HERE/'run1/vectors')],
                 graph_calls=4, shapes=[1,2], repeats_per_shape=2,
                 no_warmup=True, performance_comparison=False,
                 scope='Local original-GGML F32 prefix; no full-model MTP or same-Snapshot proof'))
    target = HERE/('build-plan.json' if args.attempt == 1 else f'build-plan-attempt{args.attempt}.json')
    assert not target.exists(), 'do not overwrite a frozen recipe'
    target.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(plan=identity(target),source=plan['source'])))


if __name__ == '__main__':
    main()
