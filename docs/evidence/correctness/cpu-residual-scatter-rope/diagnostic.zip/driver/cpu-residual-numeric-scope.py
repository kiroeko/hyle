import hashlib,json,subprocess,zipfile
from pathlib import Path

repo=Path.cwd(); fixture=repo/'.scratch/validation/cpu-native-residual-numeric'
evidence=repo/'evidence/correctness/cpu-residual-scatter-rope'; evidence.mkdir(parents=True,exist_ok=True)
manifest=json.loads((repo/'.scratch/validation/cpu-native-numeric-retirement/manifest.json').read_text())
for name,digest in manifest['files'].items():
 assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
records=json.loads((fixture/'receipt.json').read_text())
assert records[-1]['candidate']==manifest['candidate'] and records[-1]['returncode']==3
log=(fixture/records[-1]['log']).read_text()
assert 'SUMMARY rows=330 rejected=32 bad_rows=6 mature_bad_rows=3' in log
inputs={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in (
 'include/hyle/compute/operation.h','src/compute_provider_native/indexing.cc',
 'src/compute_provider_native/transformer.cc','src/compute_provider_native/aten_cpu_provider.cc',
 'src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_ggml_runtime/explicit_rope.h')}
files=[(p,'witness/'+p.name) for p in fixture.iterdir() if p.is_file() and p.suffix!='.obj']
files += [(repo/name,'source/'+name) for name in inputs]
files += [(repo/'.scratch'/name,'driver/'+name) for name in ('cpu-native-residual-numeric.py','cpu-native-residual-numeric-run.py','cpu-residual-numeric-scope.py')]
archive=evidence/'diagnostic.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for path,name in sorted(files,key=lambda row:row[1]):z.write(path,name)
receipt=dict(baseline=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 product_candidate=manifest['candidate'],forward_input_hashes_matched=len(manifest['files']),
 diagnostic='Expected failure; no P1 or product completion',records=330,native_mismatch_rows=3,
 mature_mismatch_rows=3,declines=32,source_sha256=inputs,
 artifact=dict(entries=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
(evidence/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
registry_path=repo/'docs/implementation/module-status.json'
registry=json.loads(registry_path.read_text(encoding='utf-8'))
for row in registry['modules']:
 if row['module'] in ('compute_provider_native','compute_provider_ggml'):
  row['state']='AUDITED' if row['module']=='compute_provider_native' else 'SCOPED'
  row['record']='docs/implementation/tasks/compute/cpu-native-final-domain-verdict.md' if row['module']=='compute_provider_native' else 'docs/implementation/tasks/compute/cpu-residual-scatter-rope-numeric-retirement.md'
  row['summary']='RN定界：性能前置实际发现Native half ScatterAdd逐更新舍入，以及Native/ggml generic I32 RoPE先转F32丢整数位置；Native保持父卡AUDITED旧有限FIX，ggml重开SCOPED，RN产品FIX尚未固定，不优化/不计时。'
  row.pop('candidate',None);row.pop('performance',None)
registry_path.write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt))
