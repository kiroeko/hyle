from pathlib import Path
import json
import subprocess

repo = Path.cwd()
out = repo / '.scratch/validation/cpu-native-residual-numeric'
out.mkdir(parents=True, exist_ok=True)
source = (repo / '.scratch/validation/cpu-native-final/semantic_probe.cc').read_text()
source = source.replace('long_positions?c::DataType::kInt64:c::DataType::kInt32', 'c::DataType::kInt32')
source = source.replace('2147483651', '1073741827')
source = source.replace('RopeLongI64', 'RopeLongI32')
source = source.replace('if(long_positions)b.push_back(data(pos,positions));else', 'if(false)b.push_back(data(pos,positions));else')
extra = r'''
template<class T>void duplicate_add(){
 const auto type=half_test::data_type<T>();
 const float increment=std::is_same_v<T,hyle::simd::float16_t>?1.F/2048:1.F/512;
 auto base=desc(type,1),indices=desc(c::DataType::kInt64,32),updates=desc(type,32);
 std::vector<m::Buffer>b;
 b.push_back(data(base,std::vector<T>{half_test::encode<T>(1.F)}));
 b.push_back(data(indices,std::vector<std::int64_t>(32,0)));
 b.push_back(data(updates,std::vector<T>(32,half_test::encode<T>(increment))));
 check("DuplicateScatterStorageRounding",c::Operation(c::Scatter{.kind=c::ScatterKind::kAdd}),
       {base,indices,updates},b,std::vector<T>{half_test::encode<T>(1.F+32*increment)},false);
}
template<class T>void lowp_long_rope(){
 const auto tensor=take(c::TensorDesc::dense(half_test::data_type<T>(),std::array<std::int64_t,4>{1,2,1,4}));
 const auto pos=desc(c::DataType::kInt32,2),frequency=desc(c::DataType::kFloat32,2);
 const std::vector<std::int32_t> positions{1073741827,-1073741827};
 std::vector<T> values,expected;for(int i=1;i<=8;++i)values.push_back(half_test::encode<T>(float(i)));
 for(int row=0;row<2;++row)for(int pair=0;pair<2;++pair){
  const double angle=double(positions[row])*(pair?.25:.125),a=1+row*4+pair*2,z=a+1;
  expected.push_back(half_test::encode<T>(float(a*std::cos(angle)-z*std::sin(angle))));
  expected.push_back(half_test::encode<T>(float(a*std::sin(angle)+z*std::cos(angle))));
 }
 std::vector<m::Buffer>b;b.push_back(data(tensor,values));b.push_back(data(pos,positions));
 b.push_back(data(frequency,std::vector<float>{.125F,.25F}));
 check("RopeLongI32",c::Operation(c::RoPE{.rotary_dimensions=4,.sequence_axis=1}),{tensor,pos,frequency},b,expected,false);
}
'''
assert 'int main()' in source
source = source.replace('int main()', extra + '\nint main()')
source = source.replace('int main(){', 'int main(){duplicate_add<hyle::simd::float16_t>();duplicate_add<hyle::simd::bfloat16_t>();lowp_long_rope<hyle::simd::float16_t>();lowp_long_rope<hyle::simd::bfloat16_t>();')
(out / 'semantic_probe.cc').write_text(source, encoding='utf-8', newline='\n')
driver = (repo / '.scratch/cpu-native-semantic-probe.py').read_text().replace(
    "out=repo/'.scratch/validation/cpu-native-final'", "out=repo/'.scratch/validation/cpu-native-residual-numeric'")
(repo / '.scratch/cpu-native-residual-numeric-run.py').write_text(driver, encoding='utf-8', newline='\n')
r=subprocess.run(['python','-X','utf8',str(repo/'.scratch/cpu-native-residual-numeric-run.py')])
assert r.returncode in (0,3), r.returncode
