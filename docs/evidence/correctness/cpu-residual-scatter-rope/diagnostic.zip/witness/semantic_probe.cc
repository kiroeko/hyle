#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <numbers>
#include <span>
#include <vector>
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "semantic_reference.h"
namespace c=hyle::compute;
namespace m=hyle::mem;
template<class T>T take(hyle::Result<T> r){if(!r){std::fprintf(stderr,"FIXTURE_ERROR %.*s\n",int(r.error().message().size()),r.error().message().data());std::exit(2);}return std::move(*r);}
void require(hyle::Status s){if(!s.ok()){std::fprintf(stderr,"FIXTURE_ERROR %.*s\n",int(s.message().size()),s.message().data());std::exit(2);}}
c::TensorDesc desc(c::DataType type,std::int64_t n,bool strided=false){
 const std::array shape{n};if(!strided)return take(c::TensorDesc::dense(type,shape));
 const std::array stride{std::int64_t(c::data_type_size(type)*2)};return take(c::TensorDesc::strided_bytes(type,shape,stride));
}
template<class T>m::Buffer data(const c::TensorDesc &d,const std::vector<T>&v){
 auto b=take(m::Buffer::create(m::system_resource(),take(d.required_bytes()),64));
 std::vector<std::byte> bytes(b.size(),std::byte{0xa5});
 for(std::size_t i=0;i<v.size();++i){
  auto remaining=i;std::size_t offset=0;
  for(std::size_t axis=d.rank();axis-->0;){offset+=remaining%std::size_t(d.dimensions()[axis])*std::size_t(d.byte_strides()[axis]);remaining/=std::size_t(d.dimensions()[axis]);}
  std::memcpy(bytes.data()+offset,&v[i],sizeof(T));
 }
 require(b.view().write(bytes));return b;
}
double sigmoid(double x){const auto e=std::exp(-std::abs(x));return x<0?e/(1+e):1/(1+e);}
double activation(double x,int kind){
 if(x==-(std::numeric_limits<double>::infinity)())return 0;
 if(kind==1)return .5*x*std::erfc(-x/std::numbers::sqrt2);
 if(kind==2)return x*sigmoid(2*std::sqrt(2/std::numbers::pi)*(x+.044715*x*x*x));
 return x*sigmoid(x);
}
double unary(double x,int kind){switch(kind){
 case 0:return std::abs(x);case 1:return -x;case 2:return std::exp(x);case 3:return std::log(x);
 case 4:return std::sqrt(x);case 5:return 1/std::sqrt(x);case 6:return std::tanh(x);case 7:return sigmoid(x);
 case 8:return std::isnan(x)?x:(x>0?x:0);case 9:return activation(x,1);case 10:return activation(x,2);
 case 11:return activation(x,0);default:return (std::max)(x,0.)+std::log1p(std::exp(-std::abs(x)));}}
template<class T>bool equal(T actual,T expected){
 const auto a=half_test::decode(actual),e=half_test::decode(expected);
 if(std::isnan(e))return std::isnan(a);
 if(std::isinf(e)||e==0)return a==e && std::signbit(a)==std::signbit(e);
 if constexpr(std::is_same_v<T,float>)return std::abs(a-e)<=3e-6*std::abs(e)+4*(std::numeric_limits<float>::denorm_min)();
 return std::abs(a-e)<=std::abs(e)*(std::is_same_v<T,hyle::simd::float16_t>? .001:.008);
}
std::size_t rows=0,bad_rows=0,mature_bad=0,unsupported=0;
template<class T>void check(const char*name,c::Operation op,const std::vector<c::TensorDesc>&ds,
                          std::vector<m::Buffer>&buffers,const std::vector<T>&expected,bool strided){
 const auto out=take(c::infer_single_output(op,ds));
 for(int route=0;route<2;++route){
  auto ctx=take(route?c::cpu::create_context():c::Context::create(c::cpu::device(),c::native::provider()));
  auto p=c::prepare(ctx,op,ds,std::span(&out,1),m::system_resource());
  ++rows;
  if(!p){++unsupported;std::printf("DECLINED\t%s\tdtype=%d\tstrided=%d\t%s\t%.*s\n",name,int(out.data_type()),strided,route?"mature":"Native",int(p.error().message().size()),p.error().message().data());continue;}
  if(route&&p->provider().id==c::native::kProviderId){std::fprintf(stderr,"MATURE_PEER_MISSING %s\n",name);std::exit(4);}
  auto q=take(ctx.create_queue());
  auto ws=take(m::Buffer::create(m::system_resource(),p->workspace_requirement().size,p->workspace_requirement().alignment));
  auto inv=take(p->create_invocation(p->runtime_properties().workspace_owner==c::ProviderWorkspaceOwner::kCaller?ws.view():m::BufferView{}));
  auto output=take(m::Buffer::create(m::system_resource(),take(out.required_bytes()),64));
  std::vector<c::ConstTensorView> in;
  for(std::size_t i=0;i<ds.size();++i)in.push_back(take(c::ConstTensorView::create(ds[i],buffers[i].view())));
  const std::array dest{take(c::TensorView::create(out,output.view()))};
  require(take(inv.submit(q,in,dest)).wait());
  std::vector<T> actual(expected.size());require(output.view().read(std::as_writable_bytes(std::span(actual))));
  std::size_t bad=0;
  for(std::size_t i=0;i<actual.size();++i)if(!equal(actual[i],expected[i])){
   ++bad;std::printf("MISMATCH\t%s\tdtype=%d\tstrided=%d\t%s\ti=%zu\tactual=%.17g\texpected=%.17g\n",name,int(out.data_type()),strided,route?"mature":"Native",i,half_test::decode(actual[i]),half_test::decode(expected[i]));
  }
  if(bad){++bad_rows;if(route)++mature_bad;}
  std::printf("ROW\t%s\tdtype=%d\tstrided=%d\t%s\tprovider=%.*s\tmismatches=%zu\n",name,int(out.data_type()),strided,route?"mature":"Native",int(p->provider().name.size()),p->provider().name.data(),bad);
 }
}
template<class T>void run(){
 const float inf=(std::numeric_limits<float>::infinity)(),nan=(std::numeric_limits<float>::quiet_NaN)();
 const std::array<float,22> source{-inf,-100,-90,-40,-20,-12,-8.3625F,-6,-5,-2,-0.F,0.F,.125F,1,2,5,12,20,40,100,inf,nan};
 std::vector<T> values;for(auto x:source)values.push_back(half_test::encode<T>(x));
 const auto type=half_test::data_type<T>();
 const char* names[]{"Abs","Neg","Exp","Log","Sqrt","Rsqrt","Tanh","Sigmoid","Relu","Gelu","GeluTanh","Silu","Softplus"};
 for(bool strided:{false,true}){
  const auto d=desc(type,values.size(),strided);
  for(int kind=0;kind<13;++kind){
   std::vector<T> expected;for(auto x:values)expected.push_back(half_test::encode<T>(float(unary(half_test::decode(x),kind))));
   std::vector<m::Buffer> b;b.push_back(data(d,values));check(names[kind],c::Operation(c::Unary{c::UnaryKind(kind)}),{d},b,expected,strided);
  }
 }
 for(int kind=0;kind<3;++kind)for(bool packed:{false,true}){
  const auto n=std::int64_t(values.size());
  std::vector<T> weights(values.size(),half_test::encode<T>(std::is_same_v<T,float>?1e38F:16000.F));
  std::vector<T> expected;for(std::size_t i=0;i<values.size();++i){
   const float a=float(activation(half_test::decode(values[i]),kind));
   expected.push_back(half_test::encode<T>(a*float(half_test::decode(weights[i]))));
  }
  std::vector<c::TensorDesc> ds;std::vector<m::Buffer>b;
  if(packed){auto both=values;both.insert(both.end(),weights.begin(),weights.end());ds.push_back(desc(type,2*n));b.push_back(data(ds[0],both));}
  else {ds={desc(type,n),desc(type,n)};b.push_back(data(ds[0],values));b.push_back(data(ds[1],weights));}
  const char *gates[]{"GateSilu","GateGelu","GateGeluTanh"};
  check(gates[kind],c::Operation(c::GatedActivation{.activation=c::GatedActivationKind(kind),.inputs=packed?c::GatedInputKind::kPackedHalves:c::GatedInputKind::kSeparate}),ds,b,expected,false);
 }
 const char* binary_names[]{"Add","Sub","Mul","Div","Min","Max"};
 auto right=values;std::reverse(right.begin(),right.end());
 for(int kind=0;kind<6;++kind){
  std::vector<T> expected;
  for(std::size_t i=0;i<values.size();++i){
   const float a=float(half_test::decode(values[i])),z=float(half_test::decode(right[i]));float r;
   switch(kind){case 0:r=a+z;break;case 1:r=a-z;break;case 2:r=a*z;break;case 3:r=a/z;break;
   default:r=kind==4?std::fmin(a,z):std::fmax(a,z);if(a==0&&z==0)r=(kind==4?(std::signbit(a)||std::signbit(z)):(std::signbit(a)&&std::signbit(z)))?-0.F:0.F;}
   expected.push_back(half_test::encode<T>(r));
  }
  auto d=desc(type,values.size());std::vector<m::Buffer>b;b.push_back(data(d,values));b.push_back(data(d,right));
  check(binary_names[kind],c::Operation(c::Binary{c::BinaryKind(kind)}),{d,d},b,expected,false);
 }
 for(int kind=0;kind<4;++kind){
  auto d=desc(type,values.size());std::vector<m::Buffer>b;b.push_back(data(d,values));
  check("ReduceSpecial",c::Operation(c::Reduce{.kind=c::ReductionKind(kind),.accumulation_type=c::DataType::kFloat32}),{d},b,std::vector<T>{half_test::encode<T>(nan)},false);
  std::vector<T> zero{half_test::encode<T>(0.F),half_test::encode<T>(-0.F)};
  auto zd=desc(type,2);std::vector<m::Buffer>zb;zb.push_back(data(zd,zero));
  const float expected=kind==2?-0.F:0.F;
  check("ReduceZero",c::Operation(c::Reduce{.kind=c::ReductionKind(kind),.accumulation_type=c::DataType::kFloat32}),{zd},zb,std::vector<T>{half_test::encode<T>(expected)},false);
 }
 std::vector<T> norm;for(float x:{-2.F,-1.F,1.F,3.F})norm.push_back(half_test::encode<T>(x));
 for(bool rms:{true,false}){
  std::vector<T> expected;const auto mean=rms?0.:.25;
  const auto variance=rms?3.75:3.6875;
  for(auto x:norm)expected.push_back(half_test::encode<T>(float((half_test::decode(x)-mean)/std::sqrt(variance+1e-5))));
  auto d=desc(type,4);std::vector<m::Buffer>b;b.push_back(data(d,norm));
  check(rms?"RmsNorm":"LayerNorm",rms?c::Operation(c::RmsNorm{}):c::Operation(c::LayerNorm{}),{d},b,expected,false);
 }
}
void matrix_cases(){
 const auto f=c::DataType::kFloat32;
 const auto a=take(c::TensorDesc::dense(f,std::array<std::int64_t,2>{2,3}));
 const auto row=take(c::TensorDesc::dense(f,std::array<std::int64_t,2>{3,2}));
 const auto transposed=take(take(c::TensorDesc::dense(f,std::array<std::int64_t,2>{2,3})).transposed());
 for(auto rhs:{row,transposed}){
  std::vector<m::Buffer>b;b.push_back(data(a,std::vector<float>{1,-2,3,4,.5,-1}));b.push_back(data(rhs,std::vector<float>{.25,2,-.5,-3,1,-2}));
  check("MatMulF32",c::Operation(c::MatMul{.accumulation_type=f}),{a,rhs},b,std::vector<float>{4.25,2,-.25,8.5},!rhs.is_dense());
 }
}
void remaining_cases(){
 const auto f=c::DataType::kFloat32;
 const auto d=desc(f,4);
 for(auto kind:{c::SoftmaxKind::kSoftmax,c::SoftmaxKind::kLogSoftmax}){
  const std::vector<float> source{0,1,-1,2};const double sum=std::exp(0.)+std::exp(1.)+std::exp(-1.)+std::exp(2.);
  std::vector<float> expected;for(auto x:source)expected.push_back(float(kind==c::SoftmaxKind::kSoftmax?std::exp(double(x))/sum:double(x)-std::log(sum)));
  std::vector<m::Buffer>b;b.push_back(data(d,source));
  check("SoftmaxFinite",c::Operation(c::Softmax{.kind=kind}),{d},b,expected,false);
  std::vector<float> invalid(4,-(std::numeric_limits<float>::infinity)());std::vector<m::Buffer>ib;ib.push_back(data(d,invalid));
  check("SoftmaxInvalid",c::Operation(c::Softmax{.kind=kind}),{d},ib,std::vector<float>(4,(std::numeric_limits<float>::quiet_NaN)()),false);
 }
 const auto mask=desc(c::DataType::kBool,4);std::vector<m::Buffer>sb;
 sb.push_back(data(mask,std::vector<std::uint8_t>{0,2,255,0}));sb.push_back(data(d,std::vector<float>{1,2,3,4}));sb.push_back(data(d,std::vector<float>{5,6,7,8}));
 check("SelectBool",c::Operation(c::Select{}),{mask,d,d},sb,std::vector<float>{5,2,3,8},false);
 const auto indices=desc(c::DataType::kInt64,3),updates=desc(f,3);
 for(int kind=0;kind<3;++kind){
  std::vector<c::TensorDesc> ds{d,indices};std::vector<m::Buffer>b;b.push_back(data(d,std::vector<float>{1,2,3,4}));b.push_back(data(indices,std::vector<std::int64_t>{2,0,2}));
  c::Operation op(c::Gather{});std::vector<float> expected{3,1,3};
  if(kind){ds.push_back(updates);b.push_back(data(updates,std::vector<float>{10,20,30}));op=c::Operation(c::Scatter{.kind=kind==1?c::ScatterKind::kAssign:c::ScatterKind::kAdd});expected=kind==1?std::vector<float>{20,2,30,4}:std::vector<float>{21,2,43,4};}
  check(kind==0?"GatherI64":kind==1?"ScatterAssignI64":"ScatterAddI64",op,ds,b,expected,false);
 }
 std::vector<m::Buffer>cb;cb.push_back(data(d,std::vector<float>{1,2,3,4}));
 check("Copy",c::Operation(c::Copy{}),{d},cb,std::vector<float>{1,2,3,4},false);
 std::vector<m::Buffer>concat;concat.push_back(data(desc(f,2),std::vector<float>{1,2}));concat.push_back(data(desc(f,2),std::vector<float>{3,4}));
 check("Concat",c::Operation(c::Concat{}),{desc(f,2),desc(f,2)},concat,std::vector<float>{1,2,3,4},false);
 std::vector<m::Buffer>empty;
 check("Fill",c::Operation(c::Fill{.output_shape=take(c::TensorShape::create(std::array<std::int64_t,1>{4})),.output_type=f,.value=c::ScalarValue(2.F)}),{},empty,std::vector<float>(4,2.F),false);
 for(bool long_positions:{false,true}){
  const auto tensor=take(c::TensorDesc::dense(f,std::array<std::int64_t,4>{1,2,1,4}));
  const auto pos=desc(c::DataType::kInt32,2),frequency=desc(f,2);
  std::vector<m::Buffer>b;b.push_back(data(tensor,std::vector<float>{1,2,3,4,5,6,7,8}));
  const std::array<std::int64_t,2> positions{long_positions?1073741827LL:3LL,long_positions?-1073741827LL:7LL};
  if(long_positions)b.push_back(data(pos,std::vector<std::int64_t>(positions.begin(),positions.end())));
  else b.push_back(data(pos,std::vector<std::int32_t>{3,7}));
  b.push_back(data(frequency,std::vector<float>{.125,.25}));std::vector<float> expected;
  for(int row=0;row<2;++row)for(int pair=0;pair<2;++pair){const double angle=double(positions[row])*(pair?.25:.125),a=1+row*4+pair*2,z=a+1;expected.push_back(float(a*std::cos(angle)-z*std::sin(angle)));expected.push_back(float(a*std::sin(angle)+z*std::cos(angle)));}
  check(long_positions?"RopeLongI32":"RopeI32",c::Operation(c::RoPE{.rotary_dimensions=4,.sequence_axis=1}),{tensor,pos,frequency},b,expected,false);
 }
 const auto ad=take(c::TensorDesc::dense(f,std::array<std::int64_t,4>{1,2,1,2}));
 std::vector<m::Buffer>ab;ab.push_back(data(ad,std::vector<float>{1,0,0,1}));ab.push_back(data(ad,std::vector<float>{1,0,0,1}));ab.push_back(data(ad,std::vector<float>{2,4,6,8}));
 const double p=std::exp(1/std::sqrt(2.))/(1+std::exp(1/std::sqrt(2.)));
 check("SdpaEqualHeads",c::Operation(c::ScaledDotProductAttention{.scale=float(1/std::sqrt(2.))}),{ad,ad,ad},ab,std::vector<float>{float(2*p+6*(1-p)),float(4*p+8*(1-p)),float(2*(1-p)+6*p),float(4*(1-p)+8*p)},false);
 std::vector<m::Buffer>casts;casts.push_back(data(d,std::vector<float>{1,-2,.5,-0.F}));
 check("CastF32Half",c::Operation(c::Cast{.output_type=c::DataType::kFloat16}),{d},casts,std::vector<hyle::simd::float16_t>{half_test::encode<hyle::simd::float16_t>(1),half_test::encode<hyle::simd::float16_t>(-2),half_test::encode<hyle::simd::float16_t>(.5),half_test::encode<hyle::simd::float16_t>(-0.)},false);
}

template<class T>void duplicate_add(){
 const auto type=half_test::data_type<T>();
 const float increment=std::is_same_v<T,hyle::simd::float16_t>?1.F/2048:1.F/512;
 auto base=desc(type,1),indices=desc(c::DataType::kInt64,32),updates=desc(type,32);
 std::vector<m::Buffer>b;
 b.push_back(data(base,std::vector<T>{half_test::encode<T>(1.F)}));
 b.push_back(data(indices,std::vector<std::int64_t>(32,0)));
 b.push_back(data(updates,std::vector<T>(32,half_test::encode<T>(increment))));
 check("DuplicateScatterStorageRounding",c::Operation(c::Scatter{.kind=c::ScatterKind::kAdd}),
       {base,indices,updates},b,std::vector<T>{half_test::encode<T>(1.F+32*increment)},false);
}
template<class T>void lowp_long_rope(){
 const auto tensor=take(c::TensorDesc::dense(half_test::data_type<T>(),std::array<std::int64_t,4>{1,2,1,4}));
 const auto pos=desc(c::DataType::kInt32,2),frequency=desc(c::DataType::kFloat32,2);
 const std::vector<std::int32_t> positions{1073741827,-1073741827};
 std::vector<T> values,expected;for(int i=1;i<=8;++i)values.push_back(half_test::encode<T>(float(i)));
 for(int row=0;row<2;++row)for(int pair=0;pair<2;++pair){
  const double angle=double(positions[row])*(pair?.25:.125),a=1+row*4+pair*2,z=a+1;
  expected.push_back(half_test::encode<T>(float(a*std::cos(angle)-z*std::sin(angle))));
  expected.push_back(half_test::encode<T>(float(a*std::sin(angle)+z*std::cos(angle))));
 }
 std::vector<m::Buffer>b;b.push_back(data(tensor,values));b.push_back(data(pos,positions));
 b.push_back(data(frequency,std::vector<float>{.125F,.25F}));
 check("RopeLongI32",c::Operation(c::RoPE{.rotary_dimensions=4,.sequence_axis=1}),{tensor,pos,frequency},b,expected,false);
}

int main(){duplicate_add<hyle::simd::float16_t>();duplicate_add<hyle::simd::bfloat16_t>();lowp_long_rope<hyle::simd::float16_t>();lowp_long_rope<hyle::simd::bfloat16_t>();run<float>();run<hyle::simd::float16_t>();run<hyle::simd::bfloat16_t>();
 matrix_cases();
 remaining_cases();
 std::printf("SUMMARY rows=%zu rejected=%zu bad_rows=%zu mature_bad_rows=%zu\n",rows,unsupported,bad_rows,mature_bad);
 return mature_bad?3:0;}
