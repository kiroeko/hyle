"""Offline conditional-input evidence only; never builds, runs, downloads or cleans."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import math
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-conditional-logits-2026-10-29'
spec = importlib.util.spec_from_file_location('conditional_evidence_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
CASES = ('conditional-cpu', 'conditional-cuda', 'mtp-logits-cpu', 'mtp-logits-cuda', 'natural-cuda')
FORBIDDEN_NAMES = {'environment.json', 'env.json'}
FORBIDDEN_SUFFIXES = {'.obj', '.lib', '.dll', '.exe', '.pdb', '.bin', '.safetensors', '.gguf', '.map', '.exp'}


def terminal(directory):
    value = t.read(directory / 'process.json')
    assert value['state'] == 'TERMINAL', (directory, value)
    return value


def successful(value):
    return value['exit'] == 0 and not value['timed_out']


def check_states(rows):
    assert isinstance(rows, list) and rows
    for row in rows:
        assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
        assert row['payloads_byte_equal'] == (not row['differences'])
        for diff in row['differences']:
            assert diff['role'] == 3 and diff['nonfinite_differences'] == 0
            assert math.isfinite(diff['maximum_absolute']) and 0 <= diff['maximum_absolute'] <= 3e-6


def check_report(name, report):
    backend = name.rsplit('-', 1)[1]
    assert report['status'] == 'PASS' and report['backend'] == backend and report['models'] == 1
    assert report['quality_claim'] is False and report['performance_claim'] is False and report['final_versions'] == 0
    if name.startswith('conditional-'):
        assert report['case'] == 'conditional-logits' and report['conditional_rows'] == report['configurations'] == 3
        assert report['actual_private_q_rows'] == 2 and report['conditional_metadata_failures'] == 4
        assert report['synthetic_untrained'] is True
        for key in ('finite_accept_reject_residual_bonus', 'EOS_quota', 'zero_proposal_bonus', 'same_q_leases',
                    'head_rng_checkpoint_unchanged', 'nonfirst_descriptor_zero_native', 'nonfirst_numeric_retired',
                    'same_terminal_retry', 'conditional_history_counts', 'readonly_C0_unchanged', 'greedy_conditional',
                    'actual_conditional_proposer', 'proposal_preflight_preserves_q', 'EOS_shortened_prefix'):
            assert report[key] is True, key
        assert report['full_target_publication'] is False and report['natural_conditional_supplier'] is False
        return
    if name.startswith('mtp-logits-'):
        assert report['case'] == 'mtp-logits-modifiers' and report['configurations'] == 2
        assert report['finite_math_branches'] == 2 and report['numeric_q_failures'] == 2
        assert report['synthetic_untrained'] is True
        for key in ('K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
                    'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage',
                    'prefix_frontier_numeric_failure', 'new_prefix_policy_payload', 'strict_modifier_replay_rejected',
                    'historical_StateOnly_rebuild', 'known_key_metadata_zero_native', 'target_terminal_numeric_failure',
                    'target_terminal_retired_without_publish', 'target_terminal_resources_returned', 'same_key_retry'):
            assert report[key] is True, key
        check_states(report['state_checks']); return
    assert name == 'natural-cuda' and report['case'] == 'mtp-natural-relay'
    assert report['natural_RequestLoop'] is True and report['controlled_acceptance'] is False
    assert (report['resident_capacity'], report['state_slots'], report['hidden_slots']) == (1, 5, 6)
    assert report['outputs'] == report['output_limit'] == len(report['ids']) == 40
    for key in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
        assert report[key] is True, key
    for key in ('successor_submissions', 'successor_publications', 'pending_pairs_before_A_publish',
                'deferred_waves', 'reserved_two_grants'):
        assert report[key] > 0, key
    assert len(report['state_checks']) == 1
    check_states(report['state_checks'])


def main():
    # These are current identity checks and local stat/extent checks only.
    # No environment values or tensor payloads are printed/read into the ZIP.
    plan = b.validate()
    frozen = t.read(W / 'source-freeze.json')
    compiled = t.read(W / 'compile/tiny/compiled.json')
    ready = t.read(W / 'ready-tiny.json')
    cxx = terminal(W / 'logs/compile-tiny'); link = terminal(W / 'logs/link-tiny')
    assert successful(cxx) and successful(link), 'Package only the actual linked consumer; retain failed attempts separately.'
    assert compiled['process'] == cxx and ready['process'] == link and ready['compiled'] == compiled
    assert t.command(W / 'logs/compile-tiny/command.json') == plan['units']['tiny']['compile']
    assert t.command(W / 'logs/link-tiny/command.json') == plan['units']['tiny']['link']
    assert ready['source_freeze'] == t.pin(W / 'source-freeze.json')
    t.exact(ready['image']); t.exact(compiled['object'])
    sdk = {t.key(row['path']): row for row in plan['retained']}
    assert len(sdk) == 227
    kinds = collections.Counter(Path(row['path']).suffix.lower() for row in sdk.values())
    assert kinds == {'.obj': 202, '.lib': 25}
    assert ready['inputs'] == plan['retained'] + [compiled['object']]
    assert len({t.key(row['path']) for row in ready['inputs']}) == 228
    source_index = {t.key(row['path']): row for row in frozen}
    assert len(source_index) == len(frozen)
    for row in compiled['project_dependencies']:
        assert source_index[t.key(row['path'])] == row
    assert [row for row in compiled['actual_dependencies'] if t.project(row['path'])] == compiled['project_dependencies']
    sdk_review = t.read(plan['sdk_engine_dependencies']['path'])
    assert len(sdk_review['inspected']) + len(sdk_review['unavailable']) == 202
    for consumer in sdk_review['engine_consumers']:
        t.exact(consumer['original_receipt'])
        for identity in consumer['source_identities']: t.exact(identity)
    initial_error = t.read(W / 'prepare-initial-error.json')
    runs = {}; issues = []; state_rows = []
    for name in CASES:
        out = W / 'runs' / name
        process = terminal(out)
        command = t.command(out / 'command.json')
        _, backend, flag = b.b.CASES[name]
        entry = plan['fixtures']['natural' if name == 'natural-cuda' else 'conditional']
        assert command == [ready['image']['path'], '--' + backend, entry['directory'], flag]
        raw_json = []
        for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines():
            if line.startswith('{'):
                try: raw_json.append(json.loads(line))
                except json.JSONDecodeError: pass
        report_path = out / 'report.json'
        report = t.read(report_path) if report_path.is_file() else None
        problems = []
        if not successful(process): problems.append('Native process did not exit successfully.')
        if report is None: problems.append('No parsed report was produced; original stdout/stderr remain authoritative.')
        else:
            if raw_json != [report]: problems.append('Parsed report does not equal the one original JSON stdout record.')
            try: check_report(name, report)
            except (AssertionError, KeyError, TypeError, ValueError) as failure:
                problems.append('Finite report validation failed: ' + repr(failure))
        passed = not problems
        if passed and report.get('state_checks'): state_rows.extend(report['state_checks'])
        issues.extend(name + ': ' + detail for detail in problems)
        runs[name] = dict(process=process, verified_finite_pass=passed,
            problems=problems, facts=report,
            report_member=('records/runs/' + name + '/report.json') if report is not None else None,
            stdout_member='records/runs/' + name + '/stdout.log',
            stderr_member='records/runs/' + name + '/stderr.log')
    members = {}
    def add(path, name, expected=None):
        path = Path(path)
        assert path.name.lower() not in FORBIDDEN_NAMES
        assert path.suffix.lower() not in FORBIDDEN_SUFFIXES
        body = path.read_bytes()
        if expected:
            assert (len(body), hashlib.sha256(body).hexdigest()) == (expected['bytes'], expected['sha256'])
        assert name not in members or members[name] == body
        members[name] = body
    for row in frozen:
        path = Path(row['path']); assert t.project(path) and path.is_relative_to(R)
        add(path, 'source/' + path.relative_to(R).as_posix(), row)
    for dirname, label in (('before', 'before'), ('test-initial', 'uncompiled-initial-test')):
        directory = W / dirname
        if not directory.is_dir(): continue
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                assert path.suffix.lower() in ('.cc', '.h', '.md')
                add(path, label + '/' + path.relative_to(directory).as_posix())
    for rel in ('plan.json', 'source-freeze.json', 'ready-tiny.json', 'compile/tiny/compiled.json',
                'compile/tiny/dependencies.json', 'sdk-engine-dependencies.json', 'prepare-initial-error.json'):
        add(W / rel, 'records/' + rel)
    for directory in (W / 'logs/compile-tiny', W / 'logs/link-tiny', *(W / 'runs' / name for name in CASES)):
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'report.json',
                         'host-report.json', 'checks.json'):
            path = directory / filename
            if path.is_file(): add(path, 'records/' + path.relative_to(W).as_posix())
    for name, entry in plan['fixtures'].items():
        for field in ('manifest', 'prompt'):
            row = entry[field]
            add(row['path'], 'fixtures/' + name + '/' + Path(row['path']).name, row)
    for row in plan['helpers']:
        add(row['path'], 'helpers/' + row['sha256'] + '/' + Path(row['path']).name, row)
    add(W / 'build-before-sdk-dependency-review.py', 'historical-helper/build-before-sdk-dependency-review.py')
    add(__file__, 'helpers/package.py')
    for field in ('base', 'previous_consumer'):
        row = plan[field]
        add(row['path'], 'referenced/' + row['sha256'] + '/' + Path(row['path']).name, row)
    for consumer in sdk_review['engine_consumers']:
        row = consumer['original_receipt']
        add(row['path'], 'referenced/sdk-engine/' + row['sha256'] + '/' + Path(row['path']).name, row)
    manifest = dict(schema='hyle.inference-conditional-logits.archive.v1',
        source_freeze=t.pin(W / 'source-freeze.json'), frozen_project_files=len(frozen),
        actual_compiled_project_files=len(compiled['project_dependencies']),
        members={name: dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
                 for name, body in sorted(members.items())})
    members['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    archive = DEST.with_suffix('.zip'); DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, body in sorted(members.items()): output.writestr(name, body)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist()) == set(members)
        for name, body in members.items(): assert check.read(name) == body, name
    changed = ('engine/inference/logits_inputs.h', 'engine/inference/sampling_graph.h',
               'engine/models/qwen35/main.cc', 'tests/tools/qwen_conditional_logits_case.h',
               'tests/tools/qwen_host_image_test.cc')
    failed_native = sum(not successful(value['process']) for value in runs.values())
    status = 'PASS_FINITE_CONDITIONAL_LOGITS' if not issues else 'INCOMPLETE_WITH_RETAINED_FAILURES'
    t.save(DEST.with_suffix('.json'), dict(schema='hyle.inference-conditional-logits.v1', status=status,
        product_sources=[source_index[t.key(R / path)] for path in changed],
        source_freeze=t.pin(W / 'source-freeze.json'), frozen_project_files=len(frozen),
        actual_compiled_project_files=len(compiled['project_dependencies']),
        image=ready['image'], object=compiled['object'], CXX=cxx, link=link,
        actual_process_counts=dict(CXX=1, link=1, native=5, failed_native=failed_native),
        prior_offline_plan_error=dict(facts=initial_error, counts_as_native=False, counts_as_CXX=False,
            archived_helper=t.pin(W / 'build-before-sdk-dependency-review.py')),
        SDK=dict(retained_inputs=227, objects=202, libraries=25, SDK_CXX=0, NVCC=0, downloads=0,
            existing_object_receipts_inspected=len(sdk_review['inspected']),
            unavailable_object_receipts=len(sdk_review['unavailable']),
            existing_engine_consumers=len(sdk_review['engine_consumers']),
            existing_engine_source_identities_checked_unchanged=True),
        native_processes=runs, unresolved_evidence_issues=issues,
        explicit_state_comparisons=dict(total=len(state_rows), numerically_equivalent=len(state_rows),
            F32_GDN_absolute_budget=3e-6),
        finite_component_scope=dict(conditional_bias_mask_rows=3, proposals=2, sampling_configurations=3,
            actual_recursive_proposer=True, original_q_leases=True, history_C0_and_derived_counts=True,
            greedy=True, EOS_and_quota=True, EOS_shortened_actual_width=True,
            typed_metadata_preflight=True, nonfirst_numeric_failure_retirement=True,
            authoritative_head_rng_checkpoint_preserved=True, natural_conditional_supplier=False,
            full_conditional_target_state_publication=False),
        fixtures=plan['fixtures'],
        limits=['Finite conditional CPU/CUDA components use cached untrained GA/H64/V64 weights; no model-quality claim.',
            'Conditional target-terminal numerical inputs are finite synthetic logits; actual NextN q comes from the unchanged private proposer and retains its original lease identity.',
            'History-positive and greedy cases check finite terminal mathematics; they do not establish natural grammar/history supplier or full conditional target-state publication.',
            'EOS-shortened proposer preflights maximum+1 rows; its terminal borrows only actual_m+1 rows. Every supplied target including bonus must be valid.',
            'Existing episode-shared modifier and actual natural CUDA K1 RequestLoop cases remain separate regressions, not expanded pipeline applicability.',
            'Full-state numerical comparisons retain the existing F32 GDN absolute budget 3e-6; byte identity is not required.',
            'The initial strict SDK prepare assertion was an offline planning failure, not a CXX or native process. Two retained engine consumers have unchanged header identities; missing adjacent receipts remain explicit.',
            'Source-freeze and actual consumer dependency counts describe different scopes.',
            'No new throughput comparison, downloads, full SDK rebuild or full-goal completion claim.',
            'Archive excludes environment values, tensor payloads and binaries. Original failed terminal/log/report facts are retained without being relabeled PASS.'],
        archive=t.pin(archive), archive_members=len(members), crc_and_member_sha256_readback=True))
    print('ARCHIVE WRITTEN', archive.name, t.pin(archive)['bytes'], t.pin(archive)['sha256'], status)


if __name__ == '__main__': main()
