from pathlib import Path
p=Path('.scratch/architecture-refactor-2026-10-18/grouped-shared-activation/preserve_historical_helper.py');s=p.read_text(encoding='utf-8-sig')
s=s.replace("  raw=bom+t.replace('\\r\\n','\\n').replace('\\n',ending).encode()\n  if hashlib.sha256(raw).hexdigest()==row['sha256']:found=raw", "  for terminal in ['\\n','\\r\\n','\\n\\n','\\n\\r\\n']:\n   raw=bom+(t.replace('\\r\\n','\\n').rstrip('\\n').replace('\\n',ending)+terminal).encode()\n   if hashlib.sha256(raw).hexdigest()==row['sha256']:found=raw")
s=s.replace("print('CANDIDATE',len(t.encode()),row['bytes'],repr(t[-50:])); ",'');p.write_text(s)
