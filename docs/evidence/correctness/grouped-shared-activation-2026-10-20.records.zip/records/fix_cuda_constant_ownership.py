from pathlib import Path
p=Path('tests/graph_route_cuda/grouped_shared_activation_test.cc');s=p.read_bytes().decode()
s=s.replace('#include <array>','#include <array>\n#include <bit>\n#include <limits>')
s=s.replace('#include "hyle/compute/prepared_operation.h"','#include "hyle/compute/prepared_operation.h"\n#include "hyle/compute/storage_owner.h"')
a=s.index('void exercise(');z=s.index('TEST(CudaGroupedShared, DenseAndBroadcast',a)
head,body,tail=s[:a],s[a:z],s[z:]
body=body.replace('  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();','  auto memory = c::StorageOwner::adopt(context,\n      c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value()).value();')
body=body.replace('  const auto weight_view = c::ConstTensorView::create(wd, weights.view()).value();','  auto ready_weight = memory.adopt_buffer(std::move(weights)).value();\n  const auto weight_view = ready_weight.tensor(wd).value();')
body=body.replace('  const std::array constants{g::ConstantBinding{w, weight_view}};','  const std::array constants{g::ConstantBinding{w, weight_view, g::ConstantPolicy::kBorrow,\n      memory, ready_weight}};')
s=head+body+tail
s=s.replace('''          for (std::size_t i = 0; i < actual.size(); ++i)
            if (std::isnan(expected_values[i])) EXPECT_TRUE(std::isnan(actual[i]));
            else EXPECT_EQ(actual[i], expected_values[i]);''','''          double max_relative = 0;
          std::uint32_t max_ulp = 0;
          for (std::size_t i = 0; i < actual.size(); ++i) {
            const double gate_value = gate_values[i], up_value = up_values[i];
            const double mathematical = gate_value / (1.0 + std::exp(-gate_value)) * up_value;
            const auto staged_exp = std::exp(-gate_values[i]);
            if (!std::isfinite(staged_exp) || mathematical == 0) {
              // Existing unmarked GLU uses expf: overflow retains its original
              // staged zero boundary, unlike ordinary stable SiLU.
              EXPECT_EQ(std::bit_cast<std::uint32_t>(actual[i]),
                  std::bit_cast<std::uint32_t>(expected_values[i]));
            } else {
              // Existing F32 CUDA nonlinear budget (stable_silu_test.cc):
              // strict standalone unary and the fast MMVQ epilogue need not
              // share exp/div bits. Both check the independent FP64 formula.
              const double budget = std::abs(mathematical) * 3e-6 +
                  256.0 * std::numeric_limits<float>::denorm_min();
              EXPECT_NEAR(expected_values[i], mathematical, budget);
              EXPECT_NEAR(actual[i], mathematical, budget);
              max_relative = std::max(max_relative, std::abs(actual[i] - mathematical) / std::abs(mathematical));
            }
            const auto a = std::bit_cast<std::uint32_t>(actual[i]);
            const auto e = std::bit_cast<std::uint32_t>(expected_values[i]);
            if ((a >> 31) == (e >> 31)) max_ulp = std::max(max_ulp, a > e ? a - e : e - a);
          }
          ::testing::Test::RecordProperty("max_glu_relative", std::to_string(max_relative));
          ::testing::Test::RecordProperty("max_glu_ulp_vs_standalone", std::to_string(max_ulp));''')
p.write_bytes(s.encode())
