"""Keep current facts and next work in the task page; retain its prior history in this batch."""
from pathlib import Path
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
assert json.loads((S / 'tests/vulkan-final-layout/summary.json').read_text())['passed']
path = ROOT / 'docs/developer/current-work.md'
old = path.read_text(encoding='utf-8')
(S / 'current-work-before-compact.md').write_text(old, encoding='utf-8')
start, end = old.index('## 当前重构主线'), old.index('## 已确认范围')
current = '''## 当前重构主线

当前目标是完成 Compute/Graph 推理执行体系的重构及余项，范围为 Windows/Linux/macOS 的单机
CPU、单 GPU、CPU＋一张 GPU，覆盖选定正式文本模型及主流量化。**主干已落地，整体尚未完成。**
设计与完成条件集中在[Compute 设计](../architecture/compute-design.md#推理执行体系的重构形状)，
模型、制品、角色、算子与融合以[现行总表](../implementation/model-operators.md)为准。
此前“约75%”只是旧功能审查的粗估，不作为当前完成比例。

当前调用链保持模型语义图→冷编译→不可变计划→独立 Invocation→prepare/bind/layout→严格 submit
→Completion／结果／状态发布。普通引擎中间层不判断平台、Provider 或原生算子。
Direct/Graph 共用实际实现事实；共同核心处理依赖、权限、alias、预算与寿命，各后端处理自己的数学、布局及原生资源。
CPU＋CUDA、CPU＋Apple/Vulkan 的旧专属运行时、Plan、Invocation 和 driver 已删除，不保兼容入口；
CUDA 仅保留冷环境 helper。普通图不强制 CPU 数学 Context、IO 或调度服务，后两项分别显式选用
`compute_stream`、`graph_progress`。可选进度驱动仍推进同一 SubmissionCursor，不另造执行器。

接下来交叉推进前四项，不能用单个模型成功或局部回归替代底座完成：

1. 查清当前 Qwen 的实际投影、准备／绑定／提交开销，继续公平比较加载、prefill、decode、显存和内存。
2. 按总表补非多模态功能、各种量化和融合接线；区分角色 header、算子运行与整制品执行。
3. 收敛三平台 CPU/GPU/混合调用链，补变长、有限 shape、KV/recurrent/conv 状态、分页、并发槽、
   旧结果与取消／失败／重试／关闭／退休的实际遗漏。
4. 清除重复路径，统一接口、构建和文档；新增普通算子或融合应集中于实际实现，不牵动共同调度和资源核心。
5. 完成 MTP 真实消费者闭环，复用已有状态、分支与接受前缀底座。
6. 补图像 encoder/projector（mmproj）和图像输入到文本推理的链路。

前四项是当前重构收工范围，后两项随后分别推进。测试引擎不扩张为正式产品；模型格式、tokenizer、
生成／接受策略与请求政策仍归引擎，可复用计算、存储、执行、搬运与状态能力归底座。

当前真实 CUDA 消费者已执行完整24层、23-token prefill→4-token cached continuation→decode，
也有128-token prefill及31步固定输入decode的持续回归。Direct与可选进度驱动的相关旅程已有逐字节对照；
固定32阶段的64份hidden/logits用于后续回归，并不构成独立质量验收。
与早期Torch参考仍有BF16舍入、归约与attention实现差异；固定序列的top1曾相同31/32，
唯一差异步最高两token并列，logits相对L2均值1.166%、KL均值6.462e-4。
源序列来自既有参考，不能由此签收模型准确率。数学诊断、失败和边界见
[底座审查证据](../evidence/correctness/inference-foundation-review-2026-10-18/README.md)。

当前Qwen已将常量表达式、卷积权重转换及静态索引移入冷准备，接通typed RMS、36组GDN L2、
24组保BF16舍入的decode FFN、显式频率RoPE、typed Conv及Cast/稳定SiLU融合；普通投影保留cuBLAS叶偏好。
这些改动不复制gate/up整份权重，不改变公开舍入边界。最近一次实际trace为每步650个kernel、1次GraphLaunch，
其中独立BF16/F32转换91个、Repeat为0；后续正确性批次未重采整模型trace。
双方均有163次投影，但Hyle激活/输出主要为BF16、参考decode为F32，不能据kernel数推导同数学工作或提速。

最近接受的同窗测量仍是2026-10-20北京时间03:19:06–03:19:32，旧Hyle／新Hyle／llama各3进程交错：

| 指标 | 新Hyle | 同窗llama.cpp | 边界 |
| --- | --- | --- | --- |
| 完整31步decode tokens/s | 99.83 | 103.84 | 中位低3.86% |
| warm第7–31步 tokens/s | 103.10 | 105.68 | 中位低2.43% |
| 首token秒 | 1.981 | 1.775 | 加载／准备仍须继续归因 |

旧→新warm为102.51→103.10，未证明稳定提速。prefill中位2039.71→1989.22，回退2.48%，样本也重叠；
已观察差别主要在首次冷准备43.74→45.46ms，submit至token中位均约18.85ms，准备内部仍待归因。
转换核在既有trace合计约73.5μs，投影核合计约8.74ms，仅作调查方向。
当前没有新的整模型质量、吞吐或总显存／内存峰值验收；保留原BF16合同，未启用scratch里的F32消费者草稿。
逐批源码、时钟、物理trace和负结果见[实测记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)
及[最近测量](../evidence/performance/view-projection-reuse-2026-10-20.json)。

最近功能批次已沿原执行路径补CT非对称INT4冷decode、GGUF NVFP4独立block64/36身份，
并修正CUDA MMQ重复expert slot映射。它们各有实际算子与寿命回归，未执行所选27B整制品。
Apple NVFP4 kernel仍缺，HF W4A4、packed CT INT4 GEMM等域仍须按精确packing与数值合同处理；
现有冷decode能实现的功能与packed执行的空间／性能缺口须分开说明。
见[CT INT4](../evidence/correctness/ct-asymmetric-int4-2026-10-20.json)、
[GGUF NVFP4](../evidence/correctness/gguf-nvfp4-2026-10-20.json)及现行总表。

随后GroupedMatMul已补共享激活A=1及实际零slot步幅View，保原F32激活与累加、真实span和行距；
修复CPU BF16权重提前窄化激活、常量冷准备漏接，以及CUDA/Metal/Vulkan重复expert slot承载。
Apple同时修正原生输出实际分配量；Vulkan边界保原共享backing，原生矩阵按全部occurrence覆盖执行块。
本批Windows18项、Air16个公共数值域及8个native域通过，完整Qwen64份向量保持。
CUDA plain原分组回退仍有T×S×K临时量和IDs读回，不宣称所有共享路径零临时复制。
[本批证据](../evidence/correctness/grouped-shared-activation-2026-10-20.json)保留原失败及最终边界；未重测吞吐或Linux。

跨平台已验证过有限形状、变长／分页attention、ready/pending来源、双槽、旧结果和取消／退休的多条实际旅程，
但不能推广为全部模型、dtype、布局和平台组合均完成。Vulkan固定backing的旧结果阻止复用，
Apple独立生成Array可保活至后续准备；close停止接纳，drain等待该实例实际退休，Scheduler空闲不代表GPU退休。
队列、共享KV/state和同Model推进仍受实际顺序与所有权约束。
Scheduler task/stack、原生metadata上传、Apple变KV的eager数组图等费用尚在，不能宣传零热分配。
Linux已有当前CPU＋CUDA finite-family增量运行证据，其余Linux旅程未代签。
当前paged scorer→TopK→压缩行decoder→Sink已接普通Graph及真实页权限，完整scores仍为O(T×C)。
各域正确性、失败恢复与资源限制集中在底座审查证据和对应用户指南，本页不重复实验流水账。

'''
text = old[:start] + current + old[end:]
first, last = text.index('6. 尽快完成'), text.index('\n7. 补全 MTP')
text = text[:first] + '''6. 完成独立Qwen3.5-2B纯文本、无MTP/多模态的CUDA测试消费者，以真实调用校正底座接口、布局和性能。
   已跑通完整推理，并与llama.cpp进行同窗对照；当前数值、吞吐及剩余边界见下面的重构主线和
   [实测记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md)。
''' + text[last:]
start, end = text.index('## 讨论起点'), text.index('## 首个 Qwen3.5-2B 消费者的复用材料')
text = text[:start] + text[end:]
path.write_text(text, encoding='utf-8')
print('CURRENT_WORK_COMPRESSED', len(old.splitlines()), '->', len(text.splitlines()), 'lines; original retained')
