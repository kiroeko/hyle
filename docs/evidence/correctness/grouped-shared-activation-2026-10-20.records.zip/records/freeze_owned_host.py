from pathlib import Path
import json,hashlib,shutil,difflib
root=Path.cwd();S=root/'.scratch/architecture-refactor-2026-10-18/grouped-shared-activation'
def identity(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def row(rel):
 p=root/rel;target=S/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
 before=S/'before'/rel
 return dict(path=rel,before=identity(before) if before.exists() else None,after=identity(target),product=identity(p))
host=['include/hyle/compute/model_ops.h','src/compute_provider_ggml/ggml_cpu_provider.cc','src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_provider_ggml_cuda/tensor_program.h','src/graph_route_cpu/ggml_region.cc']
rows=[row(p) for p in host]
(S/'host-source-freeze.json').write_text(json.dumps(dict(files=rows,public_operation_id_unchanged=True,activation_not_copied_per_slot=True,compiled=False,GPU_run=False),indent=2)+'\n')
diffs=[]
for r in rows:
 a=Path(r['before']['path']).read_text() if r['before'] else ''
 b=Path(r['after']['path']).read_text()
 diffs.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='before/'+r['path'],tofile='source/'+r['path']))
(S/'host-changes.diff').write_text(''.join(diffs))
tests=['tests/compute_route_cpu/grouped_shared_activation_test.cc','tests/compute_route_cpu/CMakeLists.txt','tests/graph_route_cpu/CMakeLists.txt']
(S/'CPU-test-source-freeze.json').write_text(json.dumps(dict(files=[row(p) for p in tests],shared_fixture=identity(root/'tests/compute_models/grouped_shared_activation_fixture.h'),direct_filter='CpuGroupedSharedDirect.*',graph_filter='CpuGroupedSharedGraph.*',cases_per_arm=3),indent=2)+'\n')
print('HOST',identity(S/'host-source-freeze.json'));print('CPU_TEST',identity(S/'CPU-test-source-freeze.json'));print('HEADER',identity(root/'src/compute_provider_ggml_cuda/tensor_program.h'))
