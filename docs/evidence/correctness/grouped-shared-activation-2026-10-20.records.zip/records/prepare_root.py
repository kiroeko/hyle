from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
paths = ['cmake/HyleDependencyLock.json', 'tests/compute_ops/operation_test.cc',
    'docs/user/compute.md', 'docs/user/apple-compute.md',
    'docs/implementation/model-operators.md', 'docs/developer/current-work.md']
rows = []
for relative in paths:
    p = ROOT / relative
    q = S / 'root-before' / relative
    q.parent.mkdir(parents=True, exist_ok=True)
    assert not q.exists(), 'Do not replace original before bytes'
    raw = p.read_bytes()
    q.write_bytes(raw)
    rows.append(dict(source=str(p), snapshot=str(q), bytes=len(raw),
        sha256=hashlib.sha256(raw).hexdigest()))
(S / 'root-before.json').write_text(json.dumps(dict(files=rows,
    previous_goal_turn='progress: GGUF NVFP4 wired, actual MMQ repeated-slot defect fixed,16 Windows cases/4 Apple declines/64 full-model vectors checked, docs archived and616.91MiB reclaimed.',
    current_scope='Public GroupedMatMul shared activations and correct per-occurrence native maps; no new operation/executor/owner.'), indent=2) + '\n', encoding='utf-8')
print('GROUPED_SHARED_ROOT_SNAPSHOTS',len(rows))
