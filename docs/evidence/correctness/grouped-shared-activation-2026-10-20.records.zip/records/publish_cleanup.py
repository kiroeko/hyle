from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

plan, result = read(S / 'cleanup-plan.json'), read(S / 'cleanup-result.json')
assert result['passed'] and result['files'] == plan['count'] and result['bytes'] == plan['total_bytes']
assert all(not Path(r['path']).exists() for r in plan['targets'])
for row in plan['retained_images']:
    assert identity(row['path']) == row
script = S / 'executed-reclaim.ps1'
assert script.read_bytes() == (ROOT / 'test.ps1').read_bytes()
report = dict(plan=plan, result=result, script=identity(script),
    executed_script=script.read_text(encoding='utf-8'),
    object_SDK_original_vectors_and_current_images_retained=True)
destination = ROOT / 'docs/evidence/correctness/grouped-shared-activation-2026-10-20-reclaim.json'
destination.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
path = ROOT / 'docs/evidence/correctness/grouped-shared-activation-2026-10-20.json'
public = read(path)
public['cleanup'] = dict(report=identity(destination), deleted_files=result['files'],
    deleted_bytes=result['bytes'], MiB=result['bytes']/2**20,
    all_actual_objects_SDKs_and_original_vectors_retained=True,
    current_CPU_Graph_Qwen_Vulkan_images_retained=True,
    older_measured_images_outside_this_stage_untouched=True)
path.write_text(json.dumps(public, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print('GROUPED_CLEANUP_PUBLISHED',result['files'],round(result['bytes']/2**20,2),'MiB')
