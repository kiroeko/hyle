"""Write exact file-only cleanup targets and root test.ps1; do not delete."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def identity(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

archive = read(S / 'archive-receipt.json')['archive']
assert identity(archive['path']) == archive
assert read(S / 'summary.json')['passed']
with zipfile.ZipFile(archive['path']) as z:
    saved = {r['path']: r for r in json.loads(z.read('payload-manifest.json'))['files']}
plans = sorted(S.rglob('*-link-plan.json'))
inputs = set()
for p in plans:
    for row in read(p).get('inputs', []):
        path = row['path'] if isinstance(row, dict) else row
        inputs.add(str(Path(path).resolve()).lower())
keep = [read(S / 'tests' / name / 'summary.json')['image'] for name in ['cpu-graph-fixed', 'vulkan-final-layout']]
model = read(S / 'correctness/inputs.json')['image']
keep.append(model)
keep_paths = {r['path'].lower() for r in keep}
for row in keep:
    assert identity(row['path']) == row
targets = []
for p in sorted(S.rglob('*')):
    if not p.is_file() or p.suffix.lower() not in ('.map', '.lib', '.exp', '.exe'):
        continue
    if str(p.resolve()).lower() in keep_paths:
        continue
    assert str(p.resolve()).lower() not in inputs
    row = identity(p)
    if p.suffix.lower() == '.map':
        record = saved[p.relative_to(S).as_posix()]
        assert (row['bytes'], row['sha256']) == (record['bytes'], record['sha256'])
    row['reason'] = 'Finished test/superseded image or archived map/link side product; retain actual objects, link recipes and current CPU Graph/Vulkan/Qwen images'
    targets.append(row)
references = []
for vector in read(S / 'correctness/summary.json')['observation']['vectors']:
    assert vector['byte_equal']
    actual, ref = vector['actual'], vector['reference']
    assert identity(actual['path']) == actual and identity(ref['path']) == ref
    assert (actual['bytes'],actual['sha256']) == (ref['bytes'],ref['sha256'])
    targets.append(dict(**actual, reason='Bit-identical duplicate; original reference and exact comparison retained'))
    references.append(ref)
for row in targets:
    p = Path(row['path']).resolve()
    assert p.is_relative_to(S) and not p.is_symlink()
    assert p.suffix.lower() not in ('.obj','.o','.a','.dll')
assert len(targets) == len({r['path'] for r in targets})
plan = dict(targets=targets, count=len(targets), total_bytes=sum(r['bytes'] for r in targets),
    archive=archive, retained_images=keep, retained_references=references,
    link_plans=[identity(p) for p in plans], recursive=False, SDK_or_object_deleted=False,
    link_inputs_deleted=False, older_measured_images_outside_this_stage_untouched=True)
path = S / 'cleanup-plan.json'
path.write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
plan_hash = identity(path)['sha256']
q = lambda text: "'" + str(text).replace("'", "''") + "'"
script = r'''$ErrorActionPreference = 'Stop'
$workspace = [IO.Path]::GetFullPath(__ROOT__)
$stage = [IO.Path]::GetFullPath(__STAGE__)
$planPath = __PLAN__
if ((Get-FileHash -LiteralPath $planPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne '__HASH__') { throw 'Cleanup plan changed' }
$plan = Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
$prefix = $stage.TrimEnd('\') + '\'
if (-not $stage.StartsWith($workspace.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Stage outside workspace' }
# Verify every exact target before any deletion. File-only, never recursive.
foreach ($row in $plan.targets) {
    $target = [IO.Path]::GetFullPath([string]$row.path)
    if (-not $target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Target outside stage: $target" }
    $item = Get-Item -LiteralPath $target -Force
    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not an ordinary file: $target" }
    if ($item.Length -ne $row.bytes -or (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Target identity changed: $target" }
}
foreach ($row in $plan.retained_images) {
    if ((Get-FileHash -LiteralPath $row.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256) { throw 'Retained image changed' }
}
$deleted = @()
foreach ($row in $plan.targets) {
    Remove-Item -LiteralPath $row.path -Force
    $deleted += [pscustomobject]@{ path=$row.path; bytes=$row.bytes; sha256=$row.sha256 }
}
$result = [pscustomobject]@{ passed=$true; files=$deleted.Count; bytes=($deleted | Measure-Object -Property bytes -Sum).Sum; deleted=$deleted; recursive=$false }
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath __RESULT__ -Encoding UTF8
$result | Select-Object passed,files,bytes | Format-List
'''.replace('__ROOT__', q(ROOT)).replace('__STAGE__', q(S)).replace('__PLAN__', q(path)).replace('__HASH__', plan_hash).replace('__RESULT__', q(S / 'cleanup-result.json'))
old = ROOT / 'test.ps1'
if old.exists():
    (S / 'test-before-reclaim.ps1').write_bytes(old.read_bytes())
old.write_text(script, encoding='utf-8')
(S / 'executed-reclaim.ps1').write_text(script, encoding='utf-8')
print('GROUPED_CLEANUP_READY', len(targets), plan['total_bytes'], plan_hash)
