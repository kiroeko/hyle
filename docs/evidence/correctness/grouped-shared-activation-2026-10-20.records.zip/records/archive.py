"""Retain actual sources, header, commands/results/failures and compressed maps; no SDK/binaries."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
BASE = ROOT / 'docs/evidence/correctness/grouped-shared-activation-2026-10-20'
DEST = BASE.with_suffix('.zip')
OMIT = {'.exe', '.obj', '.o', '.lib', '.a', '.exp', '.dll', '.pdb', '.pyc',
    '.bf16', '.f32', '.f16', '.zip', '.gz', '.tmp'}
OWN = {'archive-receipt.json', 'archive-inventory.json'}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

assert json.loads((S / 'summary.json').read_text(encoding='utf-8'))['passed']
assert not DEST.exists(), 'Do not overwrite an existing archive'
paths = [p for p in sorted(S.rglob('*')) if p.is_file() and p.name not in OWN
    and p.suffix.lower() not in OMIT and not any(x in p.relative_to(S).parts for x in ('tmp', '__pycache__'))]
records = []
with zipfile.ZipFile(DEST, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for p in paths:
        key, raw = p.relative_to(S).as_posix(), p.read_bytes()
        archive.writestr(key, raw)
        records.append(dict(path=key, bytes=len(raw), sha256=sha(raw)))
    manifest = json.dumps(dict(files=records, excluded_suffixes=sorted(OMIT),
        sources='Current batch includes actual original failures and final corrected sources/commands.',
        vectors='Exact per-vector hashes retained in correctness/summary.json; original reference files retained outside this stage.'), indent=2).encode()
    archive.writestr('payload-manifest.json', manifest)
with zipfile.ZipFile(DEST) as archive:
    for row in records:
        raw = archive.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    assert archive.read('payload-manifest.json') == manifest
raw = DEST.read_bytes()
receipt = dict(archive=dict(path=str(DEST), bytes=len(raw), sha256=sha(raw)),
    payload_entries=len(records), manifest_entries=1, CRC_and_payload_SHA_verified_once=True,
    binaries_objects_SDKs_and_duplicate_vectors_archived=False,
    complete_actual_header_and_failed_runs_retained=True, maps_compressed=True)
(S / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
Path(str(BASE) + '-archive.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
public = json.loads((S / 'summary.json').read_text(encoding='utf-8'))
public['archive'] = receipt
BASE.with_suffix('.json').write_text(json.dumps(public, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print('GROUPED_ARCHIVED', len(raw), 'bytes', len(records), 'payloads', receipt['archive']['sha256'])
