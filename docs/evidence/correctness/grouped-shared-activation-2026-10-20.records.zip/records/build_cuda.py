"""One changed ggml CUDA TU + focused test; late-bind the fresh shared host plan."""
from pathlib import Path
import argparse, datetime as dt, importlib.util, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('shared_cuda_helpers',A/'gguf-nvfp4/cpu-cuda/build_cuda.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
NV=A/'gguf-nvfp4/cpu-cuda'
BASE=NV/'checks/20261019T202628-grouped-fix'
NATIVE=NV/'checks/20261019T201144/native-main-identity.json'
TEST=BASE/'nvfp4-test-identity.json'

def check(plan):
    for row in plan['frozen']: assert b.same(row),row['path']

def prepare(out):
    freeze=c.read(S/'native-source-freeze.json');headers=Path(freeze['header_root'])
    native_source=S/'native-source/src/ggml-cuda/ggml-cuda.cu'
    native=c.read(NATIVE);test=c.read(TEST)
    command=h.h.h.a.strip_ccbin(b.native_command(h.h.h.a.strip_ccbin(native['command']),native_source,'native-main',out))
    command=[arg for arg in command if not (arg.startswith('-I') and 'architecture-refactor-2026-10-18' in arg)]
    command[1:1]=['-I'+str(headers/'src/ggml-cuda'),'-I'+str(headers/'src'),'-I'+str(headers/'include'),'-I'+str(ROOT/'src/compute_provider_ggml_cuda')]
    source=ROOT/'tests/graph_route_cuda/grouped_shared_activation_test.cc'
    host=b.host_command(test['command'],source,'grouped-test',out)
    # Current native headers are external/system headers, with the existing
    # project implementation include paths and strict host warning flags.
    host[1:1]=['/external:I'+str(headers/'include'),'/external:I'+str(headers/'src')]
    rows=[dict(tag='native-main',kind='native',source=b.identity(native_source),recipe=b.identity(NATIVE),command=command,object=str(out/'native-main.obj'),old_object=native['object']),
          dict(tag='grouped-test',kind='host',source=b.identity(source),recipe=b.identity(TEST),command=host,object=str(out/'grouped-test.obj'),old_object=None)]
    frozen=[b.identity(p) for p in [Path(__file__),S/'host-source-freeze.json',S/'CUDA-test-source-freeze.json',S/'native-source-freeze.json',S/'provider-version.h',NATIVE,TEST,
        ROOT/'third_party/ggml_cuda_runtime/patches.json',ROOT/'third_party/ggml_cuda_runtime/NOTICE.md',ROOT/'cmake/HyleDependencyLock.json']]
    for row in c.read(freeze['header_closure']['path'])['headers']:
        path=headers/row['path'];actual=b.identity(path)
        assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'];frozen.append(actual)
    frozen.extend(b.identity(p) for p in b.host_dependencies(test['command']))
    for name in ['host-source-freeze.json','CUDA-test-source-freeze.json']:
        frozen.extend(row['product'] for row in c.read(S/name)['files'])
    for row in rows:
        frozen.append(row['source']);snap=out/'compiled-source'/Path(row['source']['path']).relative_to(ROOT)
        snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(Path(row['source']['path']).read_bytes());frozen.append(b.identity(snap))
    return dict(compile=rows,frozen=list({c.key(row['path']):row for row in frozen}.values()),source_id=freeze['source_id'],
        environment_link=c.read(BASE/'qwen-link-plan.json'),native_TUs=1,host_test_TUs=1,SDK_build=False,GPU_run=False)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--compile',action='store_true');p.add_argument('--resume',type=Path);p.add_argument('--link',type=Path)
    args=p.parse_args()
    if args.resume:path=args.resume.resolve();out=path.parent;plan=c.read(path)
    else:
        out=S/'cpu-cuda/checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S');out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
        path=out/'plan.json';plan=prepare(out);c.save(path,plan)
    c.save(S/'cuda-latest-check.json',dict(plan=str(path)));print('PLAN',path,flush=True)
    if not (args.compile or args.link):return
    check(plan);base=plan['environment_link'];env,runtime=b.environment(base['command'],[row['path'] for row in base['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    for row in plan['compile']:
        receipt=out/(row['tag']+'-identity.json')
        if receipt.exists():
            old=c.read(receipt)
            if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):continue
        attempt=1+len(list(out.glob(row['tag']+'-compile-*.result.json')))
        c.execute(row['tag']+'-compile-'+str(attempt),row['command'],env,out);check(plan)
        if row['kind']=='host':
            dep=c.read(out/(row['tag']+'-deps.json'))['Data'];deps=[b.identity(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]
        else:deps=[r for r in plan['frozen'] if r['path'].lower().endswith(('.h','.cuh','.cu'))]
        c.save(receipt,dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=deps))
        print('COMPILED',row['tag'],flush=True)
    c.save(out/'compile-summary.json',dict(passed=True,native_TUs=1,host_test_TUs=1,SDK_build=False,GPU_run=False))
    if not args.link:return
    shared_path=args.link.resolve();shared=c.read(shared_path)
    for row in shared['inputs']:assert b.same(row),row['path']
    old=plan['compile'][0]['old_object'];assert sum(c.key(r['path'])==c.key(old['path']) for r in shared['inputs'])==1
    fresh={row['tag']:c.read(out/(row['tag']+'-identity.json'))['object'] for row in plan['compile']}
    originals={c.key(r['path']):r for r in shared['inputs']};originals.update({c.key(r['path']):r for r in fresh.values()})
    # The actual model owner is found through its fresh source receipt.
    ready=c.read(shared_path.with_name('common-objects-ready.json'))['owners']
    model=next(r['object'] for r in ready if c.key(r['source']['path'])==c.key(ROOT/'tools/qwen35_text/main.cc'))
    assert c.key(model['path']) in originals
    gtest=[r for r in c.read(BASE/'nvfp4-link-plan.json')['inputs'] if Path(r['path']).name.lower() in ('gtest.lib','gtest_main.lib')]
    assert len(gtest)==2;originals.update({c.key(r['path']):r for r in gtest})
    links={}
    for arm in ['qwen','grouped']:
        command=[fresh['native-main']['path'] if c.key(arg)==c.key(old['path']) else arg for arg in shared['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        if arm=='grouped':command=[arg for arg in command if c.key(arg)!=c.key(model['path'])];command[1:1]=[fresh['grouped-test']['path'],*(r['path'] for r in gtest)]
        image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        assert len(inputs)==len(set(map(c.key,inputs)))
        attempt=1+len(list(out.glob(arm+'-link-*.result.json')));c.execute(arm+'-link-'+str(attempt),command,env,out);check(plan)
        link=dict(command=command,inputs=[originals[c.key(p)] for p in inputs]);c.save(out/(arm+'-link-plan.json'),link);c.save(out/(arm+'-image.json'),b.identity(image))
        links[arm]=dict(command=command,inputs=inputs,image=str(image))
    plan['links']=links;plan['shared_host_plan']=b.identity(shared_path);plan['frozen'].append(plan['shared_host_plan']);c.save(path,plan)
    c.save(out/'summary.json',dict(passed=True,native_TUs=1,host_test_TUs=1,SDK_build=False,GPU_run=False,source_id=plan['source_id']))
    print('LINK_COMPLETE',path,flush=True)
if __name__=='__main__':main()
