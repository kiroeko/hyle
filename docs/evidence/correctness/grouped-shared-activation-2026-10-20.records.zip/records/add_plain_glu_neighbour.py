from pathlib import Path
p=Path('tests/graph_route_cuda/grouped_shared_activation_test.cc');s=p.read_bytes().decode()
a=s.index('TEST(CudaGroupedShared, PrivateGateUpGlu')
head,body=s[:a],s[a:]
old='''  for (const auto tokens : {1, 9})
    for (const bool shared : {false, true}) {
      SCOPED_TRACE(::testing::Message() << tokens << '/' << shared);
      const grouped_shared_test::Fixture data(tokens, 2);'''
new='''  struct Case final { std::int64_t tokens; bool shared, packed; };
  constexpr std::array cases{Case{1, false, true}, Case{1, true, true},
      Case{9, false, true}, Case{9, true, true}, Case{1, true, false}};
  for (const auto [tokens, shared, packed] : cases) {
      SCOPED_TRACE(::testing::Message() << tokens << '/' << shared << '/' << packed);
      const grouped_shared_test::Fixture data(tokens, 2);'''
assert body.count(old)==1;body=body.replace(old,new)
old='''      const auto wd = c::gguf_grouped_weight_description(c::GgufQuantizedType::kNvfp4,
          c::DataType::kFloat32, data.experts, data.rows, data.columns).value();'''
new='''      const auto wd = packed ? c::gguf_grouped_weight_description(c::GgufQuantizedType::kNvfp4,
          c::DataType::kFloat32, data.experts, data.rows, data.columns).value() :
          dense(c::DataType::kFloat32, {data.experts, data.rows, data.columns});'''
assert body.count(old)==1;body=body.replace(old,new)
body=body.replace('''      auto wg = upload(memory.ref(), std::as_bytes(std::span(gate_bank.bytes)));
      auto wu = upload(memory.ref(), std::as_bytes(std::span(up_bank.bytes)));''','''      auto wg = upload(memory.ref(), packed ? std::as_bytes(std::span(gate_bank.bytes)) : std::as_bytes(std::span(data.weights)));
      auto wu = upload(memory.ref(), packed ? std::as_bytes(std::span(up_bank.bytes)) : std::as_bytes(std::span(data.weights)));''')
body=body.replace('''          auto logical = [&](const nvfp4_test::Fixture &bank) {
            std::vector<float> result''','''          auto logical = [&](const nvfp4_test::Fixture &bank) {
            if (!packed) return data.expected(shared, values, selected);
            std::vector<float> result''')
old='''          ASSERT_TRUE(g::cuda::prepare_replay(calls[lane], queues[lane],
              {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject}).ok());'''
new='''          const auto capture = g::cuda::prepare_replay(calls[lane], queues[lane],
              {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject});
          if (packed) ASSERT_TRUE(capture.ok()) << capture.message();
          else {
            EXPECT_FALSE(capture.ok());
            ASSERT_TRUE(g::cuda::prepare_replay(calls[lane], queues[lane]).ok());
          }'''
assert body.count(old)==1;body=body.replace(old,new)
p.write_bytes((head+body).encode())
