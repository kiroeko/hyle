from pathlib import Path
import json,hashlib
S=Path('.scratch/architecture-refactor-2026-10-18/grouped-shared-activation').resolve()
plan=json.loads((S/'corrections/20261019T205952/plan.json').read_text())
row=next(r for r in plan['frozen'] if Path(r['path']).name=='build_corrections.py')
p=S/'build_corrections.py';t=p.read_text(encoding='utf-8-sig')
t=t.replace(";p.add_argument('--test-only',action='store_true')",'')
t=t.replace("        if args.test_only and tag=='cpu-region':continue\n",'')
t=t.replace("    replaced[c.key(ROOT/'src/graph_route_cpu/ggml_region.cc')]=b.identity(ROOT/'src/graph_route_cpu/ggml_region.cc')\n",'')
t=t.replace("        if args.test_only and arm=='cpu-graph':continue\n",'')
t=t.replace('host_TUs=len(rows)','host_TUs=2')
found=None
for ending in ['\n','\r\n']:
 for bom in [b'',b'\xef\xbb\xbf']:
  for terminal in ['\n','\r\n','\n\n','\n\r\n']:
   raw=bom+(t.replace('\r\n','\n').rstrip('\n').replace('\n',ending)+terminal).encode()
   if hashlib.sha256(raw).hexdigest()==row['sha256']:found=raw
assert found is not None, 'Historical helper reconstruction must match exact actual SHA'
q=S/'dependency-source-versions'/row['sha256']/'build_corrections.py';q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(found)
receipt=dict(historical_identity=row,snapshot=dict(path=str(q),bytes=len(found),sha256=hashlib.sha256(found).hexdigest()),reason='First two-host correction script before adding test-only mode; original plan remains unchanged.')
(S/'dependency-source-versions.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('HISTORICAL_HELPER_EXACT',receipt['snapshot']['sha256'])

