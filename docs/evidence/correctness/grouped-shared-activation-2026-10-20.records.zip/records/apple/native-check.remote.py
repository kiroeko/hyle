import pathlib,subprocess,json,time,hashlib,shlex
S=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/grouped-shared-activation-20261020/apple');OUT=S/'native-check';OUT.mkdir(exist_ok=True)
BUILD=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
SDK=pathlib.Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
GGML=BUILD/'hyle/src/compute_ggml_runtime/source-0bae7e9e90b384d8'
META=[{'path': 'src/ggml-metal/ggml-metal-ops.cpp', 'before_sha256': '2a1660114d129894234d6bf21840e544d05a72217c8de55de4c99bfbe905445e', 'after_sha256': '4046db2406469c0b1a2a590d51ee583839718c9e50c828bc911cbeebc85b892a', 'edits': [{'before': 'return ggml_type_size(GGML_TYPE_I32)*ne02;', 'after': '// Counts followed by compact-map offsets, one of each per expert.\n    return ggml_type_size(GGML_TYPE_I32)*2*ne02;'}, {'before': '    const int64_t ne02 = op->src[0]->ne[2]; // n_expert\n    const int64_t ne21 = op->src[2]->ne[1]; // n_token\n\n    return ggml_type_size(GGML_TYPE_I32)*ne02*ne21;', 'after': '    const int64_t ne20 = op->src[2]->ne[0]; // n_expert_used\n    const int64_t ne21 = op->src[2]->ne[1]; // n_token\n\n    // Every (token,slot) occurs once in the compact map, including duplicates.\n    return ggml_type_size(GGML_TYPE_I32)*ne20*ne21;'}, {'before': 'ggml_metal_encoder_dispatch_threadgroups(enc, (ne21 + 31)/32, (ne01 + 63)/64, ne02, 128, 1, 1);', 'after': 'ggml_metal_encoder_dispatch_threadgroups(enc, (int64_t(ne20)*ne21 + 31)/32, (ne01 + 63)/64, ne02, 128, 1, 1);'}]}, {'path': 'src/ggml-metal/ggml-metal-device.m', 'before_sha256': 'bcf70f581595f29e3257ffe998d295996c57a3b75551c82c229bbe7a7e8181aa', 'after_sha256': '13e5a2b4b0509a474de1c3008f8bf7584b2cd881548c8e8389ee131876e59b57', 'edits': [{'before': '        case GGML_OP_MUL_MAT_ID:\n            return ggml_metal_supports_mul_mat_op(', 'after': '        case GGML_OP_MUL_MAT_ID:\n            // Map values and counts are I32 flattened (token,slot) indices.\n            if (op->src[2]->ne[0] <= 0 || op->src[2]->ne[1] <= 0 ||\n                    op->src[2]->ne[0] > INT32_MAX/op->src[2]->ne[1]) {\n                return false;\n            }\n            return ggml_metal_supports_mul_mat_op('}]}, {'path': 'src/ggml-metal/kernels/mul_mm.metal', 'before_sha256': 'c3ed0e04bedb8602ce1c6b8221783b439b87c291934fa9c5ac6fcab2be0fc6ff', 'after_sha256': '4f6a400b5fa9ec2b2bbe0096c15e5015f6ed9d08e2ac865926df612775727676', 'edits': [{'before': '    device int32_t * ids_i32 = (device int32_t *) hids + ide*args.ne21;\n\n    for (int i21 = 0; i21 < args.ne21; i21 += ntg) { // n_tokens', 'after': '    // All experts share a compact T*S map. Count every lower-expert slot\n    // first, then emit this expert in stable token/slot order below.\n    uint32_t offset = 0;\n    for (int64_t token = 0; token < args.ne21; ++token) {\n        device const int32_t * row = (device const int32_t *) (src2 + token*args.nb21);\n        for (short slot = 0; slot < ne20; ++slot) {\n            offset += row[slot] < ide;\n        }\n    }\n    device int32_t * ids_i32 = (device int32_t *) hids + offset;\n\n    for (int64_t i21 = 0; i21 < args.ne21; i21 += ntg) { // n_tokens'}, {'before': '            short sel = 0;\n            #pragma unroll(ne20)\n            for (short i20 = 0; i20 < ne20; i20++) {\n                sel += (sids[i20] == ide)*(i20 + 1);\n            }\n\n            ids_i32[n_all] = (i21 + t)*ne20 + sel - 1;\n\n            n_all += sel > 0;', 'after': '            #pragma unroll(ne20)\n            for (short i20 = 0; i20 < ne20; i20++) {\n                if (sids[i20] == ide) {\n                    ids_i32[n_all++] = int((i21 + t)*ne20 + i20);\n                }\n            }'}, {'before': '    tpe_u32[ide] = n_all;', 'after': '    tpe_u32[ide] = n_all;\n    tpe_u32[args.ne02 + ide] = offset;'}, {'before': 'ids_i32[im*args.ne21 + r1 + lr1]', 'after': 'ids_i32[tpe_u32[args.ne02 + im] + r1 + lr1]'}, {'before': 'ids_i32[im*args.ne21 + r1 + j]', 'after': 'ids_i32[tpe_u32[args.ne02 + im] + r1 + j]'}, {'before': '    const short i12 = (id / args.ne20);', 'after': '    const int i12 = (id / args.ne20);'}, {'before': '        const short idt = id / args.ne20;', 'after': '        const int idt = id / args.ne20;'}]}]
def ident(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(tag,args):
 t=time.time()
 with (OUT/(tag+'.stdout.log')).open('w') as so,(OUT/(tag+'.stderr.log')).open('w') as se:
  p=subprocess.Popen(args,stdout=so,stderr=se,cwd=BUILD);r=dict(argv=args,pid=p.pid,exit=p.wait(),elapsed=time.time()-t)
 (OUT/(tag+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');print(tag,r['exit'],flush=True);return r
commands=(S/'raw-before-retry/original-metal-commands.txt').read_text().splitlines()
fresh=[];sources=[]
for rel in ['src/ggml-metal/ggml-metal-ops.cpp','src/ggml-metal/ggml-metal-device.m']:
 row=next(x for x in META if x['path']==rel)
 old=GGML/rel; source=S/'native-source'/rel
 # Existing coherent header tree is retained; record its real source identity.
 sources.append(dict(before=ident(old),expected_before_sha256=row['before_sha256'],after=ident(source)))
 args=next(shlex.split(line) for line in commands if ' -c ' in line and str(old) in line)
 target=OUT/(source.name+'.o');args[args.index('-c')+1]=str(source);args[args.index('-o')+1]=str(target)
 for opt in ['-MF','-MT']:
  if opt in args:args[args.index(opt)+1]=str(target)+('.d' if opt=='-MF' else '')
 args.insert(1,'-I'+str(GGML/'src/ggml-metal'))
 result=run('compile-'+source.name,args)
 if result['exit']:raise SystemExit(2)
 fresh.append(target)
row=next(x for x in META if x['path'].endswith('kernels/mul_mm.metal'))
old_embed=BUILD/'hyle/src/compute_ggml_runtime/vendor/src/ggml-metal/autogenerated/ggml-metal-embed-mul_mm.metal'
text=old_embed.read_text()
for e in row['edits']:
 assert text.count(e['before'])==1,e['before'][:100]
 text=text.replace(e['before'],e['after'],1)
embed=OUT/'ggml-metal-embed-mul_mm.metal';embed.write_text(text)
asm=OUT/'ggml-metal-embed-mul_mm.s'
asm.write_text('.section __DATA,__ggml_metallib\n.globl _ggml_metallib_mul_mm_start\n_ggml_metallib_mul_mm_start:\n.incbin "'+str(embed)+'"\n.globl _ggml_metallib_mul_mm_end\n_ggml_metallib_mul_mm_end:\n')
target=OUT/'ggml-metal-embed-mul_mm.s.o'
args=['/usr/bin/clang','-arch','arm64','-c',str(asm),'-o',str(target)]
if run('compile-embed',args)['exit']:raise SystemExit(3)
fresh.append(target)
raw=json.loads((S/'raw-before-retry/compile-link.command.json').read_text())['argv']
raw[raw.index('-o')+1]=str(OUT/'raw-mmid')
raw[raw.index(str(SDK/'lib/libggml-metal.a')):raw.index(str(SDK/'lib/libggml-metal.a'))]=[str(x) for x in fresh]
if run('link-raw',raw)['exit']:raise SystemExit(4)
r=run('raw',[str(OUT/'raw-mmid')])
result=dict(passed=r['exit']==0,exit=r['exit'],native_fresh=3,objects=[ident(x) for x in fresh],sources=sources,original_embed=ident(old_embed),current_embed=ident(embed),image=ident(OUT/'raw-mmid'))
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
