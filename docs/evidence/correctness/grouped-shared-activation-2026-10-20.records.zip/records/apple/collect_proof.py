import json,pathlib,subprocess,tarfile
S=pathlib.Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/grouped-shared-activation-20261020/apple'
code=r'''import pathlib,json,hashlib,tarfile,shlex
S=pathlib.Path(REMOTE)
GGML=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-0bae7e9e90b384d8')
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
headers={}
for p in (S/'native-check').glob('*.d'):
 text=p.read_text().replace('\\\n',' ')
 for item in shlex.split(text.split(':',1)[1]):
  q=pathlib.Path(item)
  if q.is_relative_to(GGML) and q.suffix=='.h':headers[q.relative_to(GGML).as_posix()]=ident(q)
(S/'native-header-dependencies.json').write_text(json.dumps(headers,indent=2)+'\n')
files=[]
for folder in ['raw-before','raw-before-retry','native-check','checks','checks-retry1','checks-carrier','checks-output-span']:
 for p in (S/folder).rglob('*'):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.txt','.d','.metal','.s']:
   files.append((p,p.relative_to(S).as_posix()))
files.append((S/'native-header-dependencies.json','native-header-dependencies.json'))
for rel,row in headers.items():files.append((pathlib.Path(row['path']),'native-header-closure/'+rel))
payloads=[dict(relative=rel,**ident(p)) for p,rel in files]
(S/'proof-payloads.json').write_text(json.dumps(payloads,indent=2)+'\n')
with tarfile.open(S/'proofs.tar.gz','w:gz') as t:
 for p,rel in files:t.add(p,arcname=rel,recursive=False)
 t.add(S/'proof-payloads.json',arcname='proof-payloads.json')
print(json.dumps(dict(files=len(files),bytes=(S/'proofs.tar.gz').stat().st_size,headers=len(headers))))
'''.replace('REMOTE',repr(REMOTE))
r=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','python3','-'],input=code,text=True,capture_output=True)
(S/'collect-proof.stdout.log').write_text(r.stdout,encoding='utf-8');(S/'collect-proof.stderr.log').write_text(r.stderr,encoding='utf-8')
print(r.stdout);print(r.stderr)
if r.returncode:raise SystemExit(r.returncode)
subprocess.run(['scp','-q','kiro@172.22.10.198:'+REMOTE+'/proofs.tar.gz',str(S/'proofs.tar.gz')],check=True)
V=S/'validation';V.mkdir(exist_ok=True)
with tarfile.open(S/'proofs.tar.gz') as t:
 for m in t.getmembers():
  dest=(V/m.name).resolve()
  if not dest.is_relative_to(V.resolve()) or m.issym() or m.islnk():raise RuntimeError(m.name)
 t.extractall(V,filter='data')
