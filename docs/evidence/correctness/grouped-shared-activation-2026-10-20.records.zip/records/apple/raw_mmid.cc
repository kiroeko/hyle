#include <ggml.h>
#include <ggml-alloc.h>
#include <ggml-backend.h>
#include <ggml-metal.h>
#include <bit>
#include <cstdio>
#include <vector>
#include "grouped_shared_activation_fixture.h"

static bool check(int tokens, bool distinct, bool shared) {
  grouped_shared_test::Fixture f(tokens, 2, 64, 5, 2);
  auto a = f.activations(shared);
  auto ids = f.ids(distinct);
  auto expected = f.expected(shared, a, ids);
  auto *ctx = ggml_init({1 << 20, nullptr, true});
  auto backend = ggml_backend_metal_init();
  if (!ctx || !backend) return false;
  auto *w = ggml_new_tensor_3d(ctx, GGML_TYPE_F32, f.columns, f.rows, f.experts);
  auto *x = ggml_new_tensor_3d(ctx, GGML_TYPE_F32, f.columns, shared ? 1 : f.slots, f.tokens);
  auto *i = ggml_new_tensor_2d(ctx, GGML_TYPE_I32, f.slots, f.tokens);
  auto *y = ggml_mul_mat_id(ctx, w, x, i);
  ggml_set_input(w); ggml_set_input(x); ggml_set_input(i); ggml_set_output(y);
  auto *g = ggml_new_graph(ctx);
  ggml_build_forward_expand(g, y);
  auto buffer = ggml_backend_alloc_ctx_tensors(ctx, backend);
  if (!buffer) return false;
  ggml_backend_tensor_set(w, f.weights.data(), 0, f.weights.size()*sizeof(float));
  ggml_backend_tensor_set(x, a.data(), 0, a.size()*sizeof(float));
  ggml_backend_tensor_set(i, ids.data(), 0, ids.size()*sizeof(int32_t));
  const auto status = ggml_backend_graph_compute(backend, g);
  std::vector<float> actual(expected.size());
  ggml_backend_tensor_get(y, actual.data(), 0, actual.size()*sizeof(float));
  int mismatches=0;
  for (std::size_t j=0;j<actual.size();++j) {
    if (std::bit_cast<uint32_t>(actual[j]) != std::bit_cast<uint32_t>(expected[j])) {
      if (mismatches<3) std::printf("mismatch[%zu] actual=%g expected=%g\n",j,actual[j],expected[j]);
      ++mismatches;
    }
  }
  std::printf("case T=%d S=2 E=2 A=%d distinct=%d status=%d mismatches=%d count=%zu\n", tokens, shared?1:2, distinct, int(status), mismatches, actual.size());
  ggml_backend_buffer_free(buffer); ggml_backend_free(backend); ggml_free(ctx);
  return status == GGML_STATUS_SUCCESS && mismatches == 0;
}
int main() {
  bool ok=true;
  for (int tokens : {31,32})
    for (bool distinct : {true,false})
      for (bool shared : {false,true}) ok=check(tokens,distinct,shared)&&ok;
  return ok?0:1;
}
