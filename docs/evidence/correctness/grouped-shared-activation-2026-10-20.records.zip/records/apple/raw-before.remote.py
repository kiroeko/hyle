import pathlib,subprocess,json,time,hashlib
S=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/grouped-shared-activation-20261020/apple')
OUT=S/'raw-before';OUT.mkdir(exist_ok=True)
SDK=pathlib.Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
BUILD=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
def identity(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(tag,args):
 t=time.time()
 with (OUT/(tag+'.stdout.log')).open('w') as so,(OUT/(tag+'.stderr.log')).open('w') as se:
  p=subprocess.Popen(args,stdout=so,stderr=se,cwd=S);r=dict(argv=args,pid=p.pid,exit=p.wait(),elapsed=time.time()-t)
 (OUT/(tag+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');return r
args=['/usr/bin/clang++','-O2','-std=c++23','-arch','arm64','-I'+str(SDK/'include'),'-I'+str(S),str(S/'raw_mmid.cc')]
args += [str(SDK/'lib'/('lib'+n+'.a')) for n in ['ggml','ggml-cpu','ggml-metal','ggml-base']]
args += ['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','Accelerate','-o',str(OUT/'raw-mmid')]
c=run('compile-link',args)
result=dict(compile=c,host=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip())
if c['exit']==0:result.update(run=run('run',[str(OUT/'raw-mmid')]),image=identity(OUT/'raw-mmid'))
# Read only exact Metal owner commands; do not invoke the old build target.
r=subprocess.run(['/opt/homebrew/bin/ninja','-C',str(BUILD),'-t','commands','ggml-metal'],capture_output=True,text=True)
(OUT/'original-metal-commands.txt').write_text(r.stdout)
result['ninja_commands_exit']=r.returncode
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
