import argparse,hashlib,json,pathlib,shlex,subprocess
ARGS=argparse.ArgumentParser();ARGS.add_argument("--out",default="raw-before-retry");ARGS=ARGS.parse_args()
S=pathlib.Path(__file__).resolve().parent
ROOT=S.parents[3]
REMOTE='/Users/kiro/hyle-scratch/compute-unified/grouped-shared-activation-20261020/apple'
def save(n,x):(S/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
for rel in ['src/compute_provider_ggml_metal/native_program.cc','third_party/ggml_runtime/metal-patches.json','third_party/ggml_runtime/NOTICE.md','tests/compute_route_apple/CMakeLists.txt']:
 p=ROOT/rel;q=S/'before'/rel
 if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','mkdir','-p',REMOTE],check=True)
for p in [S/'raw_mmid.cc',ROOT/'tests/compute_models/grouped_shared_activation_fixture.h']:
 subprocess.run(['scp','-q',str(p),'kiro@172.22.10.198:'+REMOTE+'/'+p.name],check=True)
code=r'''import pathlib,subprocess,json,time,hashlib
S=pathlib.Path(REMOTE)
OUT=S/OUTNAME;OUT.mkdir(exist_ok=True)
SDK=pathlib.Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
BUILD=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
def identity(p):
 p=pathlib.Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(tag,args):
 t=time.time()
 with (OUT/(tag+'.stdout.log')).open('w') as so,(OUT/(tag+'.stderr.log')).open('w') as se:
  p=subprocess.Popen(args,stdout=so,stderr=se,cwd=S);r=dict(argv=args,pid=p.pid,exit=p.wait(),elapsed=time.time()-t)
 (OUT/(tag+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');return r
args=['/usr/bin/clang++','-O2','-std=c++23','-arch','arm64','-I/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/ggml-456172ec733a-41b7e10fd424/include','-I'+str(S),str(S/'raw_mmid.cc')]
args += [str(SDK/'lib'/('lib'+n+'.a')) for n in ['ggml','ggml-cpu','ggml-metal','ggml-base']]
args += ['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','Accelerate','-o',str(OUT/'raw-mmid')]
c=run('compile-link',args)
result=dict(compile=c,host=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip())
if c['exit']==0:result.update(run=run('run',[str(OUT/'raw-mmid')]),image=identity(OUT/'raw-mmid'))
# Read only exact Metal owner commands; do not invoke the old build target.
r=subprocess.run(['/opt/homebrew/bin/ninja','-C',str(BUILD),'-t','commands','ggml-metal'],capture_output=True,text=True)
(OUT/'original-metal-commands.txt').write_text(r.stdout)
result['ninja_commands_exit']=r.returncode
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
'''.replace('REMOTE',repr(REMOTE)).replace('OUTNAME',repr(ARGS.out))
(S/(ARGS.out+'.remote.py')).write_text(code,encoding='utf-8')
r=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','python3','-'],input=code,text=True,capture_output=True)
(S/(ARGS.out+'.stdout.log')).write_text(r.stdout,encoding='utf-8');(S/(ARGS.out+'.stderr.log')).write_text(r.stderr,encoding='utf-8')
print(r.stdout);print(r.stderr);raise SystemExit(r.returncode)
