"""Two targeted host corrections; cached native and original Qwen image stay exact."""
from pathlib import Path
import argparse,datetime as dt,importlib.util,shutil,difflib,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('shared_correction_helpers',S/'build_cuda.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c,ROOT=h.b,h.c,h.ROOT
PRODUCTION=S/'cpu-cuda/checks/20261019T205250'
HOST=S/'windows-host/checks/current'

def main():
    p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');args=p.parse_args()
    out=S/'corrections'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S');out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    previous=c.read(PRODUCTION/'plan.json')
    cpu=next(r for r in c.read(HOST/'common-objects-ready.json')['owners'] if Path(r['source']['path']).as_posix().endswith('graph_route_cpu/ggml_region.cc'))
    test=c.read(PRODUCTION/'grouped-test-identity.json')
    rows=[];frozen=[];source_rows=[]
    for tag,old,source in [('cpu-region',cpu,ROOT/'src/graph_route_cpu/ggml_region.cc'),('grouped-test',test,ROOT/'tests/graph_route_cuda/grouped_shared_activation_test.cc')]:
        command=b.host_command(old['command'],source,tag,out)
        row=dict(tag=tag,kind='host',source=b.identity(source),old_object=old['object'],command=command,object=str(out/(tag+'.obj')));rows.append(row)
        snap=out/'source'/source.relative_to(ROOT);snap.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,snap)
        before=S/'attempt1/source'/source.relative_to(ROOT);source_rows.append(dict(path=str(source),before=b.identity(before),after=b.identity(snap),product=row['source']))
        frozen.extend([row['source'],b.identity(snap)])
        (out/(tag+'.diff')).write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),source.read_text().splitlines(True),fromfile='attempt1/'+str(source.relative_to(ROOT)),tofile=str(source.relative_to(ROOT)))))
    c.save(out/'source-freeze.json',dict(files=source_rows,old_failures=str(S/'tests'),native_changed=False,Qwen_image_relinked=False))
    # Keep exact historical production receipts. Only changed current source
    # identities are replaced for this correction's independent freeze.
    replaced={c.key(r['source']['path']):r['source'] for r in rows}
    frozen.extend(replaced.get(c.key(r['path']),r) for r in previous['frozen'] if c.key(r['path'])!=c.key(S/'CUDA-test-source-freeze.json'))
    frozen.extend(b.identity(p) for p in [Path(__file__),PRODUCTION/'plan.json',PRODUCTION/'grouped-test-identity.json',out/'source-freeze.json'])
    plan=dict(compile=rows,frozen=list({c.key(r['path']):r for r in frozen}.values()),cached_production_plan=b.identity(PRODUCTION/'plan.json'),
        source_id=previous['source_id'],links={'qwen':previous['links']['qwen']},native_TUs=0,host_TUs=2,SDK_build=False,GPU_run=False,
        Qwen_image_reused=b.identity(PRODUCTION/'qwen.exe'))
    path=out/'plan.json';c.save(path,plan);c.save(S/'corrections-latest-check.json',dict(plan=str(path)));print('CORRECTION_PLAN',path,flush=True)
    if not args.build:return
    def check():
        for r in plan['frozen']:assert b.same(r),r['path']
    check();base=c.read(PRODUCTION/'qwen-link-plan.json');env,_=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
    fresh={}
    for row in rows:
        c.execute(row['tag']+'-compile-1',row['command'],env,out);check()
        d=c.read(out/(row['tag']+'-deps.json'))['Data'];deps=[b.identity(p) for p in dict.fromkeys([d['Source'],*d['Includes']])]
        receipt=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=deps)
        c.save(out/(row['tag']+'-identity.json'),receipt);fresh[row['tag']]=receipt['object']
    for arm,base_path,tag in [('cpu-graph',HOST/'cpu-graph-link-plan.json','cpu-region'),('grouped',PRODUCTION/'grouped-link-plan.json','grouped-test')]:
        base=c.read(base_path);row=next(r for r in rows if r['tag']==tag);old=row['old_object']
        original={c.key(r['path']):r for r in base['inputs']};assert c.key(old['path']) in original
        for r in base['inputs']:assert b.same(r),r['path']
        command=[fresh[tag]['path'] if c.key(arg)==c.key(old['path']) else arg for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.lib','.obj')];original[c.key(fresh[tag]['path'])]=fresh[tag]
        link=dict(command=command,inputs=[original[c.key(p)] for p in inputs]);link_env,_=b.environment(command,inputs,out)
        c.execute(arm+'-link-1',command,link_env,out);check();c.save(out/(arm+'-link-plan.json'),link);c.save(out/(arm+'-image.json'),b.identity(image))
        plan['links'][arm]=dict(command=command,inputs=inputs,image=str(image))
    shutil.copy2(PRODUCTION/'qwen-link-plan.json',out/'qwen-link-plan.json');shutil.copy2(PRODUCTION/'qwen-image.json',out/'qwen-image.json')
    c.save(path,plan);c.save(out/'summary.json',dict(passed=True,host_TUs=2,native_TUs=0,SDK_build=False,Qwen_image_reused=plan['Qwen_image_reused'],GPU_run=False))
    print('CORRECTIONS_READY',path,flush=True)
if __name__=='__main__':main()
