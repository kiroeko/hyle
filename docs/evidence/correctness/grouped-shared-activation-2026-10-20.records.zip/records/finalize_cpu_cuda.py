from pathlib import Path
import hashlib,json,shutil,xml.etree.ElementTree as ET
root=Path.cwd();S=root/'.scratch/architecture-refactor-2026-10-18/grouped-shared-activation'
def ident(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
paths=['include/hyle/compute/model_ops.h','src/compute_provider_ggml/ggml_cpu_provider.cc',
 'src/compute_provider_ggml_cuda/tensor_program.cc','src/compute_provider_ggml_cuda/tensor_program.h',
 'src/graph_route_cpu/ggml_region.cc','tests/compute_route_cpu/grouped_shared_activation_test.cc',
 'tests/graph_route_cuda/grouped_shared_activation_test.cc','tests/graph_route_cuda/gguf_nvfp4_test.cc',
 'tests/compute_route_cpu/CMakeLists.txt','tests/graph_route_cpu/CMakeLists.txt','tests/graph_route_cuda/CMakeLists.txt',
 'third_party/ggml_cuda_runtime/patches.json','third_party/ggml_cuda_runtime/NOTICE.md']
rows=[]
for rel in paths:
 p=root/rel;q=S/'final-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 before=S/'before'/rel
 rows.append(dict(path=rel,before=ident(before) if before.exists() else None,after=ident(q),product=ident(p)))
save(S/'final-owned-source-freeze.json',dict(files=rows,initial_host_freeze=ident(S/'attempt1/host-source-freeze.json'),
 native_source_freeze=ident(S/'native-source-freeze.json'),central_lock=ident(root/'cmake/HyleDependencyLock.json'),
 private_tensor_header_layout_changed=False,public_GroupedMatMul_OpID_unchanged=True))
proofs={name:ident(S/'tests'/name/'summary.json') for name in ['cpu-direct','cpu-graph','cpu-graph-fixed','cuda','cuda-fixed','cuda-final']}
proofs['Qwen']=ident(S/'correctness/summary.json')
for name in ['cpu-direct','cpu-graph-fixed','cuda-final']:
 d=json.loads(Path(proofs[name]['path']).read_text());assert d['passed'] and d['skipped']==0
assert json.loads((S/'correctness/summary.json').read_text())['passed']
production=S/'cpu-cuda/checks/20261019T205250';fixedcpu=S/'corrections/20261019T205952';final=S/'corrections/20261019T210159'
properties={p.attrib['name']:p.attrib['value'] for p in ET.parse(S/'tests/cuda-final/results.xml').findall('.//property')}
save(S/'cpu-cuda-build-delivery.json',dict(passed=True,
 final_source_freeze=ident(S/'final-owned-source-freeze.json'),source_id='0f92138e0ac729c5',native_version='hyle-ggml-cuda-resource-iq1-inference-v28',
 initial_shared_host_build=ident(S/'windows-host/checks/current/compile-summary.json'),
 owned_compile_counts=dict(initial_native_main=1,initial_CUDA_test=1,CPU_region_correction=1,CUDA_test_corrections=2,SDK_rebuild=0),
 owned_compile_exit_codes=[0,0,0,0,0],
 production_plan=ident(production/'plan.json'),CPU_corrected_plan=ident(fixedcpu/'plan.json'),final_plan=ident(final/'plan.json'),
 final_CPU_graph_link_plan=ident(fixedcpu/'cpu-graph-link-plan.json'),final_CUDA_link_plan=ident(final/'grouped-link-plan.json'),
 final_Qwen_link_plan=ident(final/'qwen-link-plan.json'),Qwen_image=ident(production/'qwen.exe'),
 Qwen_image_relinked_after_fixture_corrections=False,proofs=proofs,
 final_counts=dict(CPU_Direct=7,CPU_Graph=3,CUDA=5,Qwen_equal_vectors=64),
 final_GLU_diagnostic_properties=properties,throughput_remeasured=False,GPU_released=True,
 failures_preserved=['tests/cpu-graph','tests/cuda','tests/cuda-fixed','attempt1','attempt2','corrections/20261019T205952'],
 compiler_failures=0,limitations=[
 'No full-model MoE journey or new physical-fusion trace; correctness Graph GLU route is exercised but not counted as physical kernel fusion.',
 'The large shared-capacity case calls descriptor-only native support; no large tensor payload is allocated or executed.',
 'Explicit S1 zero-slot runtime is covered by CPU Direct. CUDA runtime covers S2 broadcast slot0; same-shape S1 Graph broadcast preserves its input stride.',
 'The new BF16 activation witness independently proves the old narrowed mathematical reference differs, but an old CPU implementation control executable was not run in this batch.',
 'Plain cuBLAS MMID retains its native host-sorted S*T activation temporary and synchronization. Only lowering avoids materializing an S-fold broadcast input.',
 'Direct dynamic BF16 expert banks widen to a temporary F32 bank. Immutable Graph banks use the existing one-time cold artifact cache; no claim of all-model cold packing completeness.'
 ]))
save(S/'cpu-cuda-implementation-review.json',dict(source_freeze=ident(S/'final-owned-source-freeze.json'),
 public_math='A[T,A,K], IDs[T,S], W[E,N,K] -> F32 Y[T,S,N], A=1 or S; F32 A and F32 accumulation retained; OpID unchanged.',
 backend_layout='Dense per-slot/shared inputs or true readonly slot-zero views. Native view folds to [K,1,T] without input payload copy; positive singleton pitches are normalized. CUDA rejects nonintegral whole-row token pitch, CPU retains its aligned-padded native domain.',
 CPU_BF16='Native BF16 vec_dot carrier narrows A. This implementation casts W exactly to F32; Graph immutable singleton qualifies for existing region/cache widening, Direct dynamic W pays the native temporary.',
 CPU_singleton=dict(scope='Provider-local immutable BF16 Grouped constant bank only, including metadata View ancestry. No model identity or public core branch.',
  route=1,implementation=2,preference=100,dynamic_singleton='Unchanged Direct route',
  transaction='Existing artifact factory/cache and native compile transactions retained; no exception/OOM swallowed or new publication before acceptance.'),
 native_fix='Remove one premature break from the original plain CUDA host-sort occurrence loop. Existing forward/inverse maps and sorted buffers already sized T*S. Quantized MMQ/MMVQ arithmetic and v27 duplicate metadata kernel are unchanged.',
 first_failures=[
  dict(path='tests/cpu-graph',kind='Real missing CPU singleton discovery; packed count/bytes0 despite correct numeric dynamic cast. Fixed existing adapter; assertions retained.'),
  dict(path='tests/cuda',kind='Fixture supplied borrowed constants/destination; queued cold prepare properly declined. Also GLU exact-bit oracle exceeded existing F32 exp/div contract.'),
  dict(path='tests/cuda-fixed',kind='Ready source owner corrected but compile(resource.ref()) still supplied borrowed destination/metadata storage. Fixed using existing compile(StorageOwner) overload; product admission unchanged.')],
 GLU_math=dict(dot='Independent sparse dyadic double dots are exactly F32 representable.',
  nonlinear='Compare both original standalone native GLU and Graph output to independent FP64 formula, using existing |reference|*3e-6+256*denorm_min budget only on the F32 nonlinear result. Preserve original expf overflow zero class/bits.',
  source='Existing unary.cuh x/(1+expf(-x)) is instantiated in strict standalone unary TU and fast MMVQ epilogue; general bit identity is not promised.',
  observed=properties,ordinary_stable_SiLU_contract_changed=False),
 safeIDs='Invalid IDs preserve original IDs and old outputs; accepted CUDA failure requires new Invocation; no interface/math assertion relaxed.',
 reviewed_by='Local source + actual targeted CPU/CUDA tests and root full-Qwen comparison; no new GPU profile or speed claim.'))
print('FINAL_FREEZE',ident(S/'final-owned-source-freeze.json'));print('DELIVERY',ident(S/'cpu-cuda-build-delivery.json'));print('REVIEW',ident(S/'cpu-cuda-implementation-review.json'))
