from pathlib import Path
p=Path('tests/graph_route_cuda/grouped_shared_activation_test.cc');s=p.read_bytes().decode()
s=s.replace('#include "../compute_provider_native/half_test_support.h"', '#include "../compute_provider_native/half_test_support.h"\n#include "../compute_provider_ggml_cuda/test_support.h"\n#include "../../src/compute_provider_ggml_cuda/tensor_program.h"')
append=r'''
TEST(CudaGroupedShared, SharedCapacityUsesPhysicalRowsRatherThanBroadcastElements) {
  namespace native = c::ggml_cuda::internal;
  constexpr std::int64_t tokens = 32768, slots = 10, depth = 2048;
  const auto wd = dense(c::DataType::kFloat32, {1, 1, depth});
  const auto shared = c::TensorDesc::strided_bytes(c::DataType::kFloat32,
      std::array{tokens, slots, depth}, std::array<std::int64_t, 3>{depth * 4, 0, 4}).value();
  const auto per_slot = dense(c::DataType::kFloat32, {tokens, slots, depth});
  const auto id = dense(c::DataType::kInt32, {tokens, slots});
  const auto yd = dense(c::DataType::kFloat32, {tokens, slots, 1});
  const std::array output{yd};
  EXPECT_EQ(shared.required_bytes().value(), std::size_t{256} * 1024 * 1024);
  EXPECT_GT(shared.element_count().value(), std::size_t{(INT32_MAX - 1024) / sizeof(float)});
  EXPECT_TRUE(native::tensor_operation_supports(c::Operation::custom(c::model_ops::grouped_matmul()),
      std::array{wd, shared, id}, output));
  EXPECT_FALSE(native::tensor_operation_supports(c::Operation::custom(c::model_ops::grouped_matmul()),
      std::array{wd, per_slot, id}, output));
  // A folded carrier beyond the original native physical bound stays rejected.
  const auto large = c::TensorDesc::strided_bytes(c::DataType::kFloat32,
      std::array<std::int64_t, 3>{262144, slots, depth},
      std::array<std::int64_t, 3>{depth * 4, 0, 4}).value();
  EXPECT_FALSE(native::tensor_operation_supports(c::Operation::custom(c::model_ops::grouped_matmul()),
      std::array{wd, large, dense(c::DataType::kInt32, {262144, slots})},
      std::array{dense(c::DataType::kFloat32, {262144, slots, 1})}));
}

TEST(CudaGroupedShared, PrivateGateUpGluRetainsSharedAndPerSlotTopology) {
  auto context = g::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto reference_context = c::Context::create(c::cuda::device(0).value(), c::ggml_cuda::provider()).value();
  for (const auto tokens : {1, 9})
    for (const bool shared : {false, true}) {
      SCOPED_TRACE(::testing::Message() << tokens << '/' << shared);
      const grouped_shared_test::Fixture data(tokens, 2);
      const nvfp4_test::Fixture gate_bank(data.rows, data.columns, data.experts, 0);
      const nvfp4_test::Fixture up_bank(data.rows, data.columns, data.experts, 1);
      const auto wd = c::gguf_grouped_weight_description(c::GgufQuantizedType::kNvfp4,
          c::DataType::kFloat32, data.experts, data.rows, data.columns).value();
      const auto ad = dense(c::DataType::kFloat32, {tokens, shared ? 1 : data.slots, data.columns});
      const auto id = dense(c::DataType::kInt32, {tokens, data.slots});
      const auto yd = dense(c::DataType::kFloat32, {tokens, data.slots, data.rows});
      auto wg = upload(memory.ref(), std::as_bytes(std::span(gate_bank.bytes)));
      auto wu = upload(memory.ref(), std::as_bytes(std::span(up_bank.bytes)));
      auto builder = g::GraphBuilder::create().value();
      const auto gate_w = builder.constant(wd).value(), up_w = builder.constant(wd).value();
      const auto x = builder.input(ad).value(), ids = builder.input(id).value();
      const auto gate = builder.result(builder.add_node(c::model_ops::grouped_matmul(),
          std::array{gate_w, x, ids}).value()).value();
      const auto up = builder.result(builder.add_node(c::model_ops::grouped_matmul(),
          std::array{up_w, x, ids}).value()).value();
      const auto y = builder.add(c::GatedActivation{.inputs = c::GatedInputKind::kSeparate}, gate, up).value();
      ASSERT_TRUE(builder.publish(y).ok());
      const std::array constants{
          g::ConstantBinding{gate_w, c::ConstTensorView::create(wd, wg.view()).value()},
          g::ConstantBinding{up_w, c::ConstTensorView::create(wd, wu.view()).value()}};
      auto compiled = g::cuda::compile(std::move(builder).finish().value(), context, memory.ref(), {.constants = constants});
      ASSERT_TRUE(compiled) << compiled.error().message();
      EXPECT_EQ(compiled->report.step_count(), 1U);
      EXPECT_EQ(compiled->report.step(0)->provider.id, c::ggml_cuda::kProviderId);
      // Independent logical dots are exact for the sparse +/-127 activation
      // fixture. The final oracle is the original standalone native GLU, not
      // the new grouped producer path or its possible fused epilogue.
      const std::array reference_inputs{yd, yd};
      const std::array reference_outputs{yd};
      auto reference = c::prepare(reference_context,
          c::GatedActivation{.inputs = c::GatedInputKind::kSeparate}, reference_inputs, reference_outputs, memory.ref());
      ASSERT_TRUE(reference) << reference.error().message();
      auto workspace = ggml_cuda_test::workspace_buffer(*reference, memory.ref());
      auto reference_queue = reference_context.create_queue().value();
      auto reference_call = reference->create_invocation(workspace.view()).value();
      std::vector<m::Buffer> retained_inputs, retained_outputs;
      std::vector<std::vector<float>> old_values;
      std::array queues{context.create_queue().value(), context.create_queue().value()};
      std::array calls{compiled->executable.create_invocation().value(), compiled->executable.create_invocation().value()};
      for (int round = 0; round < 2; ++round)
        for (std::size_t lane = 0; lane < calls.size(); ++lane) {
          const auto values = data.activations(shared, round);
          const auto selected = data.ids(false, round + static_cast<int>(lane));
          auto logical = [&](const nvfp4_test::Fixture &bank) {
            std::vector<float> result(static_cast<std::size_t>(tokens * data.slots * data.rows));
            for (std::int64_t t = 0; t < tokens; ++t)
              for (std::int64_t slot = 0; slot < data.slots; ++slot)
                for (std::int64_t n = 0; n < data.rows; ++n) {
                  double sum = 0;
                  for (std::int64_t k = 0; k < data.columns; ++k)
                    sum += double(values[static_cast<std::size_t>((t * (shared ? 1 : data.slots) + (shared ? 0 : slot)) * data.columns + k)]) *
                        bank.decoded[static_cast<std::size_t>((selected[static_cast<std::size_t>(t * data.slots + slot)] * data.rows + n) * data.columns + k)];
                  result[static_cast<std::size_t>((t * data.slots + slot) * data.rows + n)] = static_cast<float>(sum);
                }
            return result;
          };
          const auto gate_values = logical(gate_bank), up_values = logical(up_bank);
          auto rg = upload(memory.ref(), std::as_bytes(std::span(gate_values)));
          auto ru = upload(memory.ref(), std::as_bytes(std::span(up_values)));
          auto expected = m::Buffer::create(memory.ref(), yd.required_bytes().value(), 256).value();
          const std::array reference_ports{c::ConstTensorView::create(yd, rg.view()).value(),
              c::ConstTensorView::create(yd, ru.view()).value()};
          auto reference_output = c::TensorView::create(yd, expected.view()).value();
          auto done = reference_call.submit(reference_queue, reference_ports, std::span(&reference_output, 1));
          ASSERT_TRUE(done); ASSERT_TRUE(done->wait().ok());
          const auto expected_values = half_test::read<float>(expected);
          auto input = upload(memory.ref(), std::as_bytes(std::span(values)));
          auto indices = upload(memory.ref(), std::as_bytes(std::span(selected)));
          auto output = m::Buffer::create(memory.ref(), yd.required_bytes().value(), 256).value();
          ASSERT_TRUE(calls[lane].bind(x, c::ConstTensorView::create(ad, input.view()).value()).ok());
          ASSERT_TRUE(calls[lane].bind(ids, c::ConstTensorView::create(id, indices.view()).value()).ok());
          ASSERT_TRUE(calls[lane].bind(y, c::TensorView::create(yd, output.view()).value()).ok());
          ASSERT_TRUE(g::cuda::prepare_replay(calls[lane], queues[lane],
              {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject}).ok());
          auto completed = calls[lane].submit(queues[lane]);
          ASSERT_TRUE(completed); ASSERT_TRUE(completed->wait().ok());
          const auto actual = half_test::read<float>(output);
          ASSERT_EQ(actual.size(), expected_values.size());
          for (std::size_t i = 0; i < actual.size(); ++i)
            if (std::isnan(expected_values[i])) EXPECT_TRUE(std::isnan(actual[i]));
            else EXPECT_EQ(actual[i], expected_values[i]);
          retained_inputs.push_back(std::move(input)); retained_inputs.push_back(std::move(indices));
          retained_outputs.push_back(std::move(output)); old_values.push_back(actual);
          for (std::size_t i = 0; i < retained_outputs.size(); ++i)
            EXPECT_EQ(half_test::read<float>(retained_outputs[i]), old_values[i]);
        }
    }
}
'''
assert s.count('} // namespace')==1;s=s.replace('} // namespace',append+'\n} // namespace')
p.write_bytes(s.encode())
p=Path('tests/compute_route_cpu/grouped_shared_activation_test.cc');s=p.read_bytes().decode().replace('  const auto ad = mode == Mode::kBroadcast', '  [[maybe_unused]] const auto ad = mode == Mode::kBroadcast');p.write_bytes(s.encode())
