from pathlib import Path
import json,hashlib,shutil
root=Path.cwd();s=root/'.scratch/architecture-refactor-2026-10-18/grouped-shared-activation'
def ident(p):
 b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
rows=[]
for rel in ['tests/graph_route_cuda/grouped_shared_activation_test.cc','tests/graph_route_cuda/CMakeLists.txt','tests/graph_route_cuda/gguf_nvfp4_test.cc']:
 p=root/rel;q=s/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 before=s/'before'/rel
 # Existing NV fixture changed only the old public-A=S comment; preserve prior bytes.
 if rel.endswith('gguf_nvfp4_test.cc') and not before.exists():
  old=root/'.scratch/architecture-refactor-2026-10-18/gguf-nvfp4/cpu-cuda/source/tests/graph_route_cuda/gguf_nvfp4_test.cc'
  if not old.exists(): old=root/'.scratch/architecture-refactor-2026-10-18/gguf-nvfp4/cpu-cuda/after/tests/graph_route_cuda/gguf_nvfp4_test.cc'
  if old.exists(): before.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old,before)
 rows.append(dict(path=rel,before=ident(before) if before.exists() else None,after=ident(q),product=ident(p)))
(s/'CUDA-test-source-freeze.json').write_text(json.dumps(dict(files=rows,filter='CudaGroupedShared.*',cases=5,private_capacity_check_only=True,compiled=False,GPU_run=False),indent=2)+'\n')
print(ident(s/'CUDA-test-source-freeze.json'));print(ident(root/'tests/graph_route_cuda/grouped_shared_activation_test.cc'))
