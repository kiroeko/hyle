from pathlib import Path
import shutil
root=Path.cwd(); stage=root/'.scratch/architecture-refactor-2026-10-18/grouped-shared-activation'
p=root/'src/compute_provider_ggml_cuda/tensor_program.h'; before=stage/'before'/p.relative_to(root)
before.parent.mkdir(parents=True,exist_ok=True)
if not before.exists(): shutil.copy2(p,before)
s=p.read_bytes().decode(); old='  ggml_tensor *reshape(ggml_context *, ggml_tensor *,\n                       std::array<std::int64_t, 3> shape, std::uint8_t rank);\n'
assert s.count(old)==1;s=s.replace(old,'');p.write_bytes(s.encode())
p=root/'src/compute_provider_ggml_cuda/tensor_program.cc';s=p.read_bytes().decode()
a=s.index('ggml_tensor *TensorBuildFrame::reshape(');z=s.index('bool tensor_operation_supports(',a)
s=s[:a]+s[z:]
p.write_bytes(s.encode())

