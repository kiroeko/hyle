from pathlib import Path
p=Path('tests/graph_route_cuda/grouped_shared_activation_test.cc');s=p.read_bytes().decode().replace('#include <limits>','#include <limits>\n#include <string>')
a=s.index('TEST(CudaGroupedShared, PrivateGateUpGlu')
h,b=s[:a],s[a:]
b=b.replace('  struct Case final', '  double max_relative = 0;\n  std::uint32_t max_ulp = 0;\n  struct Case final')
b=b.replace('          double max_relative = 0;\n          std::uint32_t max_ulp = 0;\n','')
p.write_bytes((h+b).encode())
