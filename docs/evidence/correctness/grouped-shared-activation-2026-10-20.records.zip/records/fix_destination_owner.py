from pathlib import Path
import shutil
s=Path('.scratch/architecture-refactor-2026-10-18/grouped-shared-activation')
p=Path('tests/graph_route_cuda/grouped_shared_activation_test.cc');q=s/'attempt2/source/tests/graph_route_cuda/grouped_shared_activation_test.cc';q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
t=p.read_bytes().decode();a=t.index('void exercise(');z=t.index('TEST(CudaGroupedShared, DenseAndBroadcast',a)
h,b,f=t[:a],t[a:z],t[z:];old='context, memory.ref(),\n      {.constants = bfloat';new='context, memory,\n      {.constants = bfloat';assert b.count(old)==1;b=b.replace(old,new);p.write_bytes((h+b+f).encode())
p=s/'build_corrections.py';t=p.read_text(encoding='utf-8-sig').replace("p.add_argument('--build',action='store_true');args=p.parse_args()","p.add_argument('--build',action='store_true');p.add_argument('--test-only',action='store_true');args=p.parse_args()")
t=t.replace("        command=b.host_command(old['command'],source,tag,out)","        if args.test_only and tag=='cpu-region':continue\n        command=b.host_command(old['command'],source,tag,out)")
t=t.replace("    frozen.extend(replaced.get(c.key(r['path']),r) for r in previous['frozen']", "    replaced[c.key(ROOT/'src/graph_route_cpu/ggml_region.cc')]=b.identity(ROOT/'src/graph_route_cpu/ggml_region.cc')\n    frozen.extend(replaced.get(c.key(r['path']),r) for r in previous['frozen']")
t=t.replace("host_TUs=2,SDK_build=False,GPU_run=False,", "host_TUs=len(rows),SDK_build=False,GPU_run=False,")
t=t.replace("        base=c.read(base_path);row=next", "        if args.test_only and arm=='cpu-graph':continue\n        base=c.read(base_path);row=next")
t=t.replace("host_TUs=2,native_TUs=0", "host_TUs=len(rows),native_TUs=0")
p.write_text(t)
