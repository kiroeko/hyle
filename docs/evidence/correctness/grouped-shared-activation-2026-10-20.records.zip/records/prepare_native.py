"""Retain duplicate slots in the original CUDA F32 host-sorted fallback."""
from pathlib import Path
import importlib.util
import json
import difflib
STAGE=Path(__file__).resolve().parent
PREVIOUS=STAGE.parent/'gguf-nvfp4/cpu-cuda'
spec=importlib.util.spec_from_file_location('shared_native_helpers',PREVIOUS/'prepare_native.py')
n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)


def main():
    assert not (STAGE/'native-source-freeze.json').exists()
    p=n.VENDOR/'patches.json';manifest=n.read(p);name='src/ggml-cuda/ggml-cuda.cu'
    row=next(r for r in manifest['files'] if r['path']==name)
    cuda=n.replay(row)
    old='''                    ids_to_sorted_host.push_back(i12*ne11 + iex % ne11);
                    tokens_per_expert[i02]++;
                    break;'''
    new='''                    ids_to_sorted_host.push_back(i12*ne11 + iex % ne11);
                    tokens_per_expert[i02]++;'''
    assert cuda.count(old.encode())==1
    row['edits'].append(dict(before=old,after=new));cuda=cuda.replace(old.encode(),new.encode(),1);row['after_sha256']=n.sha(cuda)
    n.save(p,manifest)
    notice=n.VENDOR/'NOTICE.md';notice.write_text(notice.read_text(encoding='utf-8').rstrip()+'''

The original host-sorted F32 MUL_MAT_ID fallback retains every selected slot,
including repeated expert IDs in one token. Its existing T*S map and sorted
buffer capacities already cover those occurrences; only the premature break
is removed. Input broadcast mapping, F32 cuBLAS arithmetic, explicit precision,
stream waits and capture qualification stay unchanged. This lets provider
lowering preserve the actual activation/slot shape instead of flattening all
plain-weight slots into separate artificial tokens.
''',encoding='utf-8',newline='\n')
    composer=n.load('prepare_cuda_iq1_manifest');composer.derive(n.UPSTREAM,
        PREVIOUS/'mixed-cpu-manifest.json',p,n.VENDOR/'iq1-patches.json',STAGE/'combined-manifest.json')
    oldfull={r['path']:n.replay(r) for r in n.read(PREVIOUS/'grouped-combined-manifest.json')['files']}
    full={r['path']:n.replay(r) for r in n.read(STAGE/'combined-manifest.json')['files']}
    assert {k for k in full if full[k]!=oldfull[k]}=={name}
    before=STAGE/'before'/name;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(oldfull[name])
    after=STAGE/'native-source'/name;after.parent.mkdir(parents=True,exist_ok=True);after.write_bytes(full[name])
    (STAGE/'native-changes.diff').write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),'before/'+name,'after/'+name)),encoding='utf-8')
    lock=n.read(n.ROOT/'cmake/HyleDependencyLock.json');entries={r['name']:r for r in lock['dependencies']};tree=n.tree(n.VENDOR)
    sid=n.sha((entries['ggml_runtime_patches']['vendored']['tree_sha256']+entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']+
        n.sha((n.ROOT/'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes())+
        n.sha((n.ROOT/'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes())+tree).encode())[:16]
    (STAGE/'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-'+sid+'"\n',encoding='utf-8')
    n.save(STAGE/'native-source-freeze.json',dict(version='hyle-ggml-cuda-resource-iq1-inference-v28',source_id=sid,
        files=[dict(path=name,before=n.identity(before),after=n.identity(after))],sources={name:n.sha(full[name])},
        header_root=str(PREVIOUS/'native-source'),header_closure=n.identity(PREVIOUS/'native-header-closure.json'),
        retained_native_objects='previous GetRows/convert/MMID/unary/GDN/Conv and other unchanged objects',
        native_TUs_requiring_refresh=['ggml-cuda.cu'],all_combined_edits_replayed=True,all_other_canonical_sources_unchanged=True,
        struct_or_public_native_API_changed=False,SDK_modified=False,compile_run=False,GPU_run=False))
    n.save(STAGE/'cuda-lock-proposal.json',dict(dependency='ggml_cuda_runtime_patches',version='hyle-ggml-cuda-resource-iq1-inference-v28',
        source_id=sid,vendored_tree_sha256=tree,notice_sha256=n.sha(notice.read_bytes()),central_lock_modified=False))
    print(n.read(STAGE/'cuda-lock-proposal.json'))


if __name__=='__main__':main()
