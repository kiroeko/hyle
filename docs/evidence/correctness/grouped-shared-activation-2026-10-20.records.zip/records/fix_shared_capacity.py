from pathlib import Path
root=Path.cwd()
for rel,gpu in [('src/compute_provider_ggml_cuda/tensor_program.cc',True),('src/compute_provider_ggml/ggml_cpu_provider.cc',False)]:
 p=root/rel;s=p.read_bytes().decode()
 needle='ggml_tensor *grouped_activation(ggml_context *context, ggml_tensor *source) {'
 limit='std::size_t{(INT32_MAX - 1024) / sizeof(float)}' if gpu else 'std::size_t{INT32_MAX}'
 extra=' || *bytes > INT32_MAX' if gpu else ''
 helper='''// A broadcast slot is metadata, not S physical activation rows. This narrow
// port qualification keeps the original native bounds on its folded [K,1,T]
// carrier and exact backing; ordinary per-slot tensors retain the generic gate.
bool shared_grouped_activation(const TensorDesc &description) noexcept {
  const auto bytes = description.required_bytes();
  if (!description.valid() || !grouped_activation(description) || !bytes ||
      description.byte_strides()[1] != 0EXTRA)
    return false;
  const auto shape = description.dimensions();
  constexpr auto limit = LIMIT;
  return shape[0] > 0 && shape[2] > 0 &&
         static_cast<std::size_t>(shape[2]) <= limit &&
         static_cast<std::size_t>(shape[0]) <= limit / shape[2] &&
         std::ranges::all_of(description.byte_strides(), [](auto stride) {
           return stride <= INT32_MAX && stride % sizeof(float) == 0;
         });
}

'''.replace('EXTRA',extra).replace('LIMIT',limit)
 assert s.count(needle)==1;s=s.replace(needle,helper+needle)
 needle='''        !(i == 0 && operation.custom_as<model_ops::GroupedMatMul>() &&
          native_grouped_bank(inputs[i]))'''
 replacement=needle+''' &&
        !(i == 1 && operation.custom_as<model_ops::GroupedMatMul>() &&
          shared_grouped_activation(inputs[i]))'''
 assert s.count(needle)==1;s=s.replace(needle,replacement)
 p.write_bytes(s.encode())
