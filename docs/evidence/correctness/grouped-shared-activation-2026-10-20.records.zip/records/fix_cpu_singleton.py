from pathlib import Path
import shutil,json,hashlib
root=Path.cwd();S=root/'.scratch/architecture-refactor-2026-10-18/grouped-shared-activation'
backup=S/'attempt1';backup.mkdir(exist_ok=True)
for name in ['host-source-freeze.json','host-changes.diff','CPU-test-source-freeze.json','CUDA-test-source-freeze.json']:
 p=S/name;q=backup/name
 if not q.exists():shutil.copy2(p,q)
for rel in ['src/graph_route_cpu/ggml_region.cc','tests/graph_route_cuda/grouped_shared_activation_test.cc']:
 p=root/rel;q=backup/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists():shutil.copy2(p,q)
p=root/'src/graph_route_cpu/ggml_region.cc';s=p.read_bytes().decode().replace('\r\n','\n')
needle='Status propose(void *context, const RegionDiscoveryRequest &request, mem::AllocatorRef allocator,'
helper='''// A singleton is useful when this adapter can prepare an immutable expert
// bank once. Ordinary dynamic operations keep their existing Direct route.
bool single_constant_expert(const Graph &graph, NodeId node) noexcept {
  const auto operation = graph.operation(node);
  if (!operation || !operation->custom_as<compute::model_ops::GroupedMatMul>())
    return false;
  const auto weight = graph.node_input(node, 0);
  if (!weight) return false;
  const auto description = graph.value_description(*weight);
  if (!description || !description->is_plain() || !description->is_dense() ||
      description->rank() != 3 ||
      description->data_type() != compute::DataType::kBFloat16)
    return false;
  auto value = *weight;
  for (std::size_t depth = 0; depth <= graph.node_count(); ++depth) {
    if (value.kind() == ValueKind::kConstant) return true;
    if (value.kind() != ValueKind::kNodeOutput) return false;
    const auto producer = graph.producer(value);
    if (!producer) return false;
    const auto kind = graph.operation_kind(*producer);
    const auto inputs = graph.node_input_count(*producer);
    if (!kind || *kind != compute::OperationKind::kView || !inputs || *inputs != 1)
      return false;
    const auto input = graph.node_input(*producer, 0);
    if (!input) return false;
    value = *input;
  }
  return false;
}

'''
assert s.count(needle)==1;s=s.replace(needle,helper+needle)
s=s.replace('  if (graph.node_count() < 2)\n    return Status::Ok();','  if (graph.node_count() == 0)\n    return Status::Ok();')
s=s.replace('    if (nodes.size() < 2)\n      return true;', '    if (nodes.empty() || (nodes.size() == 1 && !single_constant_expert(graph, nodes[0])))\n      return true;')
s=s.replace('  if (!request.graph || request.route != 1 || request.nodes.size() < 2 ||','  if (!request.graph || request.route != 1 || request.nodes.empty() ||')
needle='    return Status::Unimplemented("ggml CPU region boundary is not admitted");\n'
assert s.count(needle)==1;s=s.replace(needle,needle+'''  if (request.nodes.size() == 1 &&
      !single_constant_expert(*request.graph, request.nodes.front()))
    return Status::Unimplemented("ggml CPU singleton has no immutable preparation");
''')
p.write_bytes(s.replace('\n','\r\n').encode())

