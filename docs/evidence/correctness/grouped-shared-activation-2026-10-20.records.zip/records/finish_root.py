"""Record this bounded batch after its actual backend runs; no additional builds."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

S = Path(__file__).resolve().parent
ROOT = S.parents[2]


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def identity(p):
    p = Path(p).resolve()
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def main():
    names = ['cpu-direct', 'cpu-graph-fixed', 'cuda-final', 'vulkan-final-layout']
    tests = {name: read(S / 'tests' / name / 'summary.json') for name in names}
    for row in tests.values():
        assert row['passed'] and row['skipped'] == 0
    assert sum(row['cases'] for row in tests.values()) == 18
    apple = read(S / 'apple/summary.json')
    model = read(S / 'correctness/summary.json')
    assert apple['passed'] and model['passed']
    assert model['observation']['equal_vectors'] == 64

    rows, diff = [], []
    for row in read(S / 'root-before.json')['files']:
        p, before = Path(row['source']), Path(row['snapshot'])
        if p.read_bytes() == before.read_bytes():
            continue
        target = S / 'root-source' / p.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(p.read_bytes())
        rows.append(dict(source=identity(p), before=identity(before), snapshot=identity(target)))
        diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(keepends=True),
            p.read_text(encoding='utf-8').splitlines(keepends=True),
            fromfile='before/' + p.relative_to(ROOT).as_posix(),
            tofile='current/' + p.relative_to(ROOT).as_posix()))
    p = ROOT / 'tests/compute_models/grouped_shared_activation_fixture.h'
    target = S / 'root-source' / p.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(p.read_bytes())
    rows.append(dict(source=identity(p), before=None, snapshot=identity(target)))
    (S / 'root-changes.diff').write_text(''.join(diff), encoding='utf-8')
    save(S / 'root-source-freeze.json', dict(files=rows, public_GroupedMatMul_OpID_unchanged=True,
        new_public_operation_or_executor=False, shared_graph_core_changed=False))

    command = ['git', 'diff', '--check', '--'] + [
        str(p.relative_to(ROOT)).replace('\\', '/') for p in
        [Path(row['source']['path']) for row in rows]]
    result = subprocess.run(command, cwd=ROOT, capture_output=True)
    (S / 'diff.stdout.log').write_bytes(result.stdout)
    (S / 'diff.stderr.log').write_bytes(result.stderr)
    save(S / 'diff.result.json', dict(command=command, exit=result.returncode))
    assert result.returncode == 0, result.stdout.decode(errors='replace')

    summary = dict(
        passed=True,
        scope='GroupedMatMul shared activations, repeated expert IDs and native layout/allocation seams',
        public_contract='W[E,N,K], F32 A[T,A,K], I32 IDs[T,S] -> F32 Y[T,S,N]; A=1 or S; real zero-slot View admitted by provider layout facts',
        public_OpID_unchanged=True,
        shared_graph_executor_or_public_owner_added=False,
        original_valid_AS_inputs_preserved=True,
        tests=tests,
        windows_distinct_cases=18,
        apple=dict(summary=identity(S / 'apple/summary.json'), public_domains=16, native_domains=8,
            domain_counts_are_not_gtest_counts=True),
        model=dict(summary=identity(S / 'correctness/summary.json'), equal_finite_vectors=64,
            same_predictions_and_fixed_decode_inputs=True, single_hybrid_range_in_all_32_phases=True),
        fixes=[
            'Public and backend A1/zero-slot admission preserve physical span and real row pitch; no S-fold caller copy.',
            'CPU plain BF16 W widens W to F32 rather than pre-narrowing original F32 A; immutable singleton Graph constants use existing cold artifact preparation.',
            'CUDA original plain sorted fallback preserves every repeated slot; previously it stopped at the first matching expert occurrence.',
            'Metal original map kernel emits every repeated slot with O(T*S+E) metadata; shared array carrier retains actual strides and original owner.',
            'Metal result allocation reserves actual backend span, including MMID private metadata after the logical result.',
            'Vulkan qualified non-dense Grouped input boundary retains original read-only layout/backing. Existing dense input alignment adapters remain, including valid 4-byte-offset bindings.',
            'Vulkan native direct-Y MMID/MVID preserve actual span and pitch; non-vector-aligned rows use the existing unaligned variant. Matrix dispatch covers every repeated ID occurrence. No CONT/Repeat or shader ABI addition.'
        ],
        failures_retained=[
            'Apple original T32 repeated-ID native errors; carrier CONT mismatch and insufficient physical result allocation.',
            'CPU Graph immutable singleton missed cold constant preparation.',
            'CUDA fixture lacked ready owned source/destination permission for queued constant preparation; fixture now uses existing ownership APIs.',
            'CUDA nonlinear fused GLU versus standalone exact equality was an invalid oracle; final independent FP64 check retains existing bounded nonlinear error, exact dot/BF16/ID checks unchanged.',
            'Vulkan checked helper dispatch count assumption, padded-input native pitch/span bug and insufficient matrix dispatch rows for duplicate IDs.'
        ],
        costs_and_limits=[
            'Shared A1 descriptor has T*K physical rows, but CUDA original plain sorted fallback still uses T*S*K scratch and host ID readback/synchronization. No universal O(T*K) workspace claim.',
            'CPU dynamic plain BF16 banks still widen when executed; only qualified immutable Graph constants are cold-prepared once.',
            'CUDA multi-token padded row pitch must be a whole K-row multiple. General arbitrary strides remain unsupported.',
            'Vulkan non-dense shared inputs require native storage-buffer origin alignment at each bind; original dense inputs retain their alignment adapter. Native matrix occurrence dispatch is cold-bounded by actual initialized pipeline tiles and real device grid limits.',
            'Explicit singleton zero strides were executed on CPU Direct; CUDA executes multi-slot zero-stride View, while its same-shape singleton Graph View retains public original stride semantics.',
            'Apple NVFP4 kernel remains absent. Covered F32/Q8 domains do not establish every Metal codec or complete model artifact execution.',
            'Historic CPU reference helper corrections were source-reviewed; their large historical consumer suites were not run this batch.',
            'No new Linux execution, full model quality evaluation, throughput measurement or aggregate memory-peak acceptance.',
            'The current broad architecture goal remains active; this bounded batch does not complete model/quantization/fusion/platform coverage.'
        ],
        evidence=dict(root_source_freeze=identity(S / 'root-source-freeze.json'),
            cpu_cuda_source_freeze=identity(S / 'final-owned-source-freeze.json'),
            cpu_cuda_build=identity(S / 'cpu-cuda-build-delivery.json'),
            cpu_cuda_review=identity(S / 'cpu-cuda-implementation-review.json'),
            vulkan_independent_review=identity(S / 'vulkan/padded-independent-review.json'),
            vulkan_final_driver_review=identity(S / 'vulkan/native-driver/independent-review.json'),
            vulkan_driver_source=identity(S / 'vulkan/native-driver/source-freeze.json'),
            vulkan_occurrence_review=identity(S / 'vulkan/mmid-occurrence-independent-review.json'),
            vulkan_final_validation=identity(S / 'vulkan/final-validation.json'),
            final_dependency_audit=identity(S / 'dependency-audit-dispatch.result.json')),
        goal_status='active', goal_turn='progress', throughput_claim=False,
        last_accepted_throughput_unchanged=dict(hyle_warm_tokens_s=103.10, peer_warm_tokens_s=105.68,
            gap_percent=2.43, sample_overlap=True))
    save(S / 'summary.json', summary)
    save(S / 'goal-turn.json', dict(status='active', classification='progress',
        reason='Bounded shared activation and backend correctness fixes finished; broad architecture coverage/performance work remains.'))
    print('GROUPED_BATCH_RECORDED', summary['windows_distinct_cases'], 'Windows cases, Apple16+8, Qwen64')


if __name__ == '__main__':
    main()
