"""Plan only a recorded formal Flash stage2 frontier; this opens no network."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent / 'formal-controls'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--frontier', type=Path, required=True)
parser.add_argument('--label', required=True)
args = parser.parse_args()
assert re.fullmatch(r'[a-zA-Z0-9_-]+', args.label)
frontier = args.frontier.resolve()
assert frontier.is_relative_to(W)
actual = json.loads(frontier.read_text())
assert actual['section'] == 'draft' and actual['stage'] == 2
ids, union = actual['missing_ids'], actual['global_ids']
assert ids and ids == sorted(set(ids)) and union == sorted(set(union))
assert len(union) <= 30 and all(type(i) is int and 0 <= i < 256 for i in union)
assert set(ids).issubset(union)
source = R / '.scratch/dspark-pro-target-draft-20261023/formal-flash/fetch_experts.py'
command = [sys.executable, str(source), '--section', 'draft', '--stage', '2', '--ids',
    *map(str, ids), '--plan-only']
completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(W / (args.label + '-plan-only.log')).write_bytes(completed.stdout)
assert completed.returncode == 0, completed.stdout.decode(errors='replace')

def identity(path):
    return dict(path=path.relative_to(R).as_posix(), bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())

evidence = W / (args.label + '-required.json')
assert not evidence.exists()
evidence.write_text(json.dumps(actual, indent=2) + '\n', encoding='utf-8')
rows = []
remaining = 0
directories = []
for global_id in ids:
    directory = source.parent / 'original-experts/draft/stage2' / f'expert{global_id:03d}'
    plan = json.loads((directory / 'plan.json').read_text())
    assert plan['repository'] == 'deepseek-ai/DeepSeek-V4-Flash-0731'
    assert plan['revision'] == '7872f01b1d1fe23eabc4c98b48bffcef5a386062'
    assert plan['global_ids'] == [global_id] and plan['bundle_bytes'] == 13369344
    assert plan['original_roles'] == 6 and not plan['whole_shards_downloaded']
    receipt = directory / 'acquisition.json'
    verified = 0
    if receipt.exists():
        record = json.loads(receipt.read_text())
        assert not record['complete'], 'The actual native missing frontier disagrees with a complete cache'
        assert record['source_plan_sha256'] == identity(directory / 'plan.json')['sha256']
        with (directory / 'roles.bin').open('rb') as stream:
            for group in plan['groups']:
                position = group['bundle_offset']
                for part in sorted((p for p in record['chunks'] if p['group'] == group['index']), key=lambda p:p['offset']):
                    assert part['offset'] == position and part['bytes'] > 0
                    assert position + part['bytes'] <= group['bundle_offset'] + group['bytes']
                    stream.seek(position)
                    assert hashlib.sha256(stream.read(part['bytes'])).hexdigest() == part['sha256']
                    position += part['bytes']
                    verified += part['bytes']
    remaining += plan['bundle_bytes'] - verified
    rows.append(dict(cache=directory.relative_to(R).as_posix(), verified_cached_bytes=verified, plan=plan))
    directories.append(directory.relative_to(R).as_posix())
assert remaining > 0
out = W / ('acquire-' + args.label)
assert not out.exists()
batch = dict(script=source.relative_to(R).as_posix(), arguments=command[2:-1],
    out=out.relative_to(R).as_posix(), need_evidence=identity(evidence),
    new_unique_body_bytes=remaining, whole_bank=False, whole_model=False,
    timeout_seconds=900, repository='deepseek-ai/DeepSeek-V4-Flash-0731',
    revision='7872f01b1d1fe23eabc4c98b48bffcef5a386062',
    initial_and_redirect_host='hf-mirror.net only; existing budget.py refuses every other host',
    expected_cache_directories=directories,
    supplier_sources=[identity(p) for p in (source,source.parent.parent/'fetch_experts.py',source.parent.parent/'fetch_dense.py')])
plan_file = W / ('acquire-' + args.label + '-plan.json')
plan_file.write_text(json.dumps(batch, indent=2) + '\n', encoding='utf-8')
(W / (args.label + '-exact-ranges.json')).write_text(json.dumps(dict(actual_frontier=actual,
    expert_plans=rows, network_requests=0), indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(batch_plan=str(plan_file), section='draft', stage=2,
    missing_ids=ids, necessary_payload_bytes=remaining, network_requests=0), indent=2))
