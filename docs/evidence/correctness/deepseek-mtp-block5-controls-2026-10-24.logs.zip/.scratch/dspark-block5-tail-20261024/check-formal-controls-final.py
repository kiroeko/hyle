from pathlib import Path
import json, os, sys, subprocess, time, hashlib, shutil
R=Path.cwd(); W=R/'.scratch/dspark-block5-tail-20261024'; F=W/'formal-controls-final'; F.mkdir(exist_ok=True)
for name in ('compile.log','compile-command.json','compile-process.json','link.log','link-command.json','link-process.json','run.log','run-command.json','run-process.json','results.xml'):
    source=F/name
    if source.exists() and not (F/('before-'+name)).exists():shutil.copy2(source,F/('before-'+name))
tracked=[R/'tests/compute_models/dspark_pro_mtp_state_consumer_test.cc',R/'tests/compute_models/dspark_block5_policy.h']
def identity():return [{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in tracked]
frozen=identity()
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
base=json.loads((W/'dspark_pro_mtp_state_consumer_test-syntax-command.json').read_text())
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':base[0],'CMAKE_CXX_COMPILER':base[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[x for x in base if x!='/Zs']+['/Fo'+str(F/'consumer.obj'),'/Fd'+str(F/'consumer.pdb')]
def execute(name,cmd,env,timeout=600):
    (F/(name+'-command.json')).write_text(json.dumps(cmd,ensure_ascii=False,indent=2))
    started=time.time()
    with (F/(name+'.log')).open('wb') as log:
        p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    (F/(name+'-process.json')).write_text(json.dumps({'exit':p.returncode,'seconds':time.time()-started,'downloads':0,'sdk_builds':0},indent=2))
    print(name,p.returncode,(F/(name+'.log')).read_text(errors='replace')[-6500:],flush=True)
    if p.returncode:sys.exit(p.returncode)
execute('compile',cmd,env)
assert identity()==frozen
(F/'source-identity.json').write_text(json.dumps(frozen,indent=2))
base=json.loads((R/'.scratch/engine-product-20261024/cpu-budget-fix1/tests-link-plan.json').read_text())['command']
cmd=[x for x in base if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')) and not x.replace('\\','/').endswith('/cpu-budget-fix1/test/test.obj')]
cmd += [str(F/'consumer.obj'),'/OUT:'+str(F/'checks.exe'),'/IMPLIB:'+str(F/'checks.lib')]
execute('link',cmd,env)
ready=json.loads((R/'.scratch/engine-product-20261024/cpu-budget-fix1/engine-ready.json').read_text())
env=dict(env,PATH=str(F)+';'+ready['PATH'])
worker=F/'hyle_ggml_cpu_gdn_scale_v3.dll'
if not worker.exists():os.link(R/'.scratch/engine-product-20261024/cpu-build5/link'/worker.name,worker)
S=R/'.scratch/dspark-pro-target-draft-20261023'
for key in list(env):
    if key.startswith('HYLE_DSPARK_') and ('WAIT' in key or 'FRONTIER' in key):env.pop(key,None)
env.update(HYLE_DSPARK_FORMAL_FLASH_DIR=str(S/'formal-flash/original-dense'),
    HYLE_DSPARK_FLASH_EXPERT_DIR=str(S/'formal-flash/original-experts'),HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS='0',HYLE_DSPARK_FLASH_FRONTIER_FILE=str(F/'missing-frontier.json'),
    HYLE_DSPARK_ORIGINAL_TARGET_TAIL_DIR=str(R/'.scratch/dspark-original-target-tail-20261023/original-target'),
    HYLE_DSPARK_SHARED_VOCAB_DIR=str(R/'.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary'))
execute('run',[str(F/'checks.exe'),'--gtest_color=no','--gtest_filter=DSparkFlashFormalState.CudaOriginalTargetTailAndFormalDraftPublishesBlock5Prefix','--gtest_output=xml:'+str(F/'results.xml')],env,600)
