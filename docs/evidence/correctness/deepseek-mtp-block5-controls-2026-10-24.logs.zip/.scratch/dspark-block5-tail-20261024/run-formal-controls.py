"""Run the frozen current Flash consumer using local caches only; no build or HTTP."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent / 'formal-controls'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--attempt', required=True)
parser.add_argument('--wait-for-experts', action='store_true',
    help='Keep the native frontier alive for explicit external supply; never starts a downloader')
args = parser.parse_args()
if not re.fullmatch(r'[a-zA-Z0-9_-]+', args.attempt):
    parser.error('--attempt must be a simple unique label')
out = W / ('replay-' + args.attempt)
assert not out.exists(), 'Keep earlier runtime evidence; use a fresh attempt label'
frozen = json.loads((W / 'source-identity.json').read_text())
for source in frozen:
    assert hashlib.sha256(Path(source['path']).read_bytes()).hexdigest() == source['sha256']
image = json.loads((W / 'consumer-identity.json').read_text())
exe = R / image['path']
assert exe.stat().st_size == image['bytes']
assert hashlib.sha256(exe.read_bytes()).hexdigest() == image['sha256']
ready = json.loads((R / '.scratch/engine-product-20261024/cpu-budget-fix1/engine-ready.json').read_text())
env = dict(os.environ, PATH=str(W) + ';' + ready['PATH'])
for key in list(env):
    if key.startswith('HYLE_DSPARK_') and ('WAIT' in key or 'FRONTIER' in key):
        env.pop(key)
S = R / '.scratch/dspark-pro-target-draft-20261023'
env.update(HYLE_DSPARK_FORMAL_FLASH_DIR=str(S / 'formal-flash/original-dense'),
    HYLE_DSPARK_FLASH_EXPERT_DIR=str(S / 'formal-flash/original-experts'),
    HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS='1' if args.wait_for_experts else '0',
    HYLE_DSPARK_FLASH_FRONTIER_FILE=str(out / 'missing-frontier.json'),
    HYLE_DSPARK_ORIGINAL_TARGET_TAIL_DIR=str(R / '.scratch/dspark-original-target-tail-20261023/original-target'),
    HYLE_DSPARK_SHARED_VOCAB_DIR=str(R / '.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary'))
out.mkdir()
command = [str(exe), '--gtest_color=no',
    '--gtest_filter=DSparkFlashFormalState.CudaOriginalTargetTailAndFormalDraftPublishesBlock5Prefix',
    '--gtest_output=xml:' + str(out / 'results.xml')]
(out / 'command.json').write_text(json.dumps(command, indent=2))
started = time.time()
with (out / 'run.log').open('wb') as log:
    process = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT,
        timeout=1500 if args.wait_for_experts else 600)
summary = dict(exit=process.returncode, seconds=time.time() - started,
    source=frozen, image=image, downloads=0, sdk_builds=0, rebuilt_TUs=0,
    whole_original_model=False, throughput_evidence=False,
    explicit_external_supply_wait=args.wait_for_experts)
frontier = out / 'missing-frontier.json'
if frontier.exists():
    summary['actual_missing_frontier'] = json.loads(frontier.read_text())
(out / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, ensure_ascii=False, indent=2))
print((out / 'run.log').read_text(errors='replace')[-1800:])
sys.exit(process.returncode)
