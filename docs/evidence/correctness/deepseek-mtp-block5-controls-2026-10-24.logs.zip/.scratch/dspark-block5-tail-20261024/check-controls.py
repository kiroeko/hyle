from pathlib import Path
import json, os, sys, subprocess
R=Path.cwd(); W=R/'.scratch/dspark-block5-tail-20261024'; sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
command=json.loads((W/'compile-command.json').read_text())
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
ready=json.loads((R/'.scratch/engine-product-20261024/cpu-budget-fix1/engine-ready.json').read_text())
for name in ('compile','link','run','dspark_original_state_consumer_test-syntax','dspark_pro_mtp_state_consumer_test-syntax'):
    cmd=json.loads((W/(name+'-command.json')).read_text())
    runenv=dict(env)
    if name=='run': runenv['PATH']=str(W)+';'+ready['PATH']
    p=subprocess.run(cmd,env=runenv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (W/(name+'-controls.log')).write_bytes(p.stdout)
    print(name,p.returncode,p.stdout.decode('utf-8','replace')[-7500:])
    if p.returncode:sys.exit(p.returncode)
