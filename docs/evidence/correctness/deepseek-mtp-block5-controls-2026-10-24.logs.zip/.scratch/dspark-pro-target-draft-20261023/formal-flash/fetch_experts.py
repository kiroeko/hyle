"""Root-only acquisition of actual formal Flash draft expert frontiers.

Reuses CA's exact Range/ETag/SHA, immutable per-expert cache lock and recovery
implementation. Import/configuration makes no request and allocates no payload.
Target experts are already authenticated in the existing target cache.
"""
import importlib.util
from pathlib import Path
import sys

S = Path(__file__).resolve().parent
R = S.parents[2]
REPOSITORY = 'deepseek-ai/DeepSeek-V4-Flash-0731'
REVISION = '7872f01b1d1fe23eabc4c98b48bffcef5a386062'
HEADER_IDENTITIES = {
    'model-00046-of-00048.safetensors': (167728, '9517cdca91db9013fd504c7a193aae8034ebd8937c223b7ed5abb46e738b7da7'),
    'model-00047-of-00048.safetensors': (167416, '9205a8b652f63f8c0e03aeb1a630becc5c62dd89466e6dffabb349488824ebfa'),
    'model-00048-of-00048.safetensors': (168920, '2b105c0db08b1eb986f30fcdf2934bf11d7725086a38c92d6bcd0825b28b59f0'),
}


def load_helper(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError('Existing CA acquisition helper was not found: ' + str(path))
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    return helper


def configured_helper():
    dense = load_helper('_hyle_flash_expert_dense', S.parent / 'fetch_dense.py')
    # fetch_experts' existing import must bind the actual CA downloader, not
    # the neighbouring 97-role CLI wrapper with the same filename.
    preceding = sys.modules.get('fetch_dense')
    sys.modules['fetch_dense'] = dense
    try:
        helper = load_helper('_hyle_flash_expert_acquisition', S.parent / 'fetch_experts.py')
    finally:
        if preceding is None:
            del sys.modules['fetch_dense']
        else:
            sys.modules['fetch_dense'] = preceding
    helper.S, helper.R = S, R
    helper.REPOSITORY, helper.REVISION = REPOSITORY, REVISION
    helper.ROLE_COUNT, helper.EXPERT_BYTES, helper.DOMAIN = 6, 13369344, 256
    helper.HEADER_COUNT, helper.TOTAL_SHARDS = 3, 48
    helper.TARGET_SHARD_FIRST, helper.DRAFT_SHARD_FIRST, helper.FIRST_TARGET_LAYER = 42, 46, 40
    helper.HIDDEN, helper.INTERMEDIATE = 4096, 2048
    helper.SECTIONS = ('draft',)
    helper.EXPECTED_HEADERS = HEADER_IDENTITIES
    helper.__doc__ = __doc__
    dense.S, dense.R = S, R
    return helper


def main():
    configured_helper().main()


if __name__ == '__main__':
    main()
