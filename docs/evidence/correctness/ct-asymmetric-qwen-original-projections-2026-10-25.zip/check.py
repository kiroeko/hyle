from pathlib import Path
import hashlib,importlib.util,json,os,shutil,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/ct-asymmetric-qwen-projection-20261025';S=W/'source';S.mkdir()
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
files=[R/'engine/models/qwen35/main.cc',*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h'),R/'engine/reporting/execution_report.h',R/'tests/compute_models/original_role_input.h',R/'include/hyle/graph/executable.h'];pins=[]
for p in files:
 d=S/p.relative_to(R);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d);pins.append(dict(original=b.pin(p),frozen=b.pin(d)))
for name in ('consumer.cc','original-specs.h'):
 shutil.copyfile(W/name,S/name)
b.save(W/'frozen-pins.json',pins)
reference=R/'.scratch/inference-system-review-20261025/text-r2-suffix'
base=b.args(reference/'compile/command.json');cmd=[base[0],'/I'+str(S),'/I'+str(S/'include')];skip=False
for word in base[1:]:
 if skip:skip=False;continue
 if word=='/sourceDependencies':skip=True;continue
 low=word.lower().replace('\\','/')
 if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
 if low.startswith(('/i','-i'))and '/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(word)
cmd+=['/sourceDependencies',str(W/'compile/dependencies.json'),str(S/'consumer.cc'),'/Fo'+str(W/'compile/consumer.obj'),'/Fd'+str(W/'compile/consumer.pdb')]
env=b.environment(base[0]);b.execute(cmd,W/'compile',env,120)
includes=[Path(p).resolve()for p in b.read(W/'compile/dependencies.json')['Data']['Includes']];leaks=[str(p)for p in includes if p.is_relative_to(R/'engine')or p.is_relative_to(R/'tests')];assert not leaks,leaks
link=[];old=str(reference/'compile/unit.obj');found=0
for word in b.args(reference/'link/command.json'):
 if word.lower().startswith(('/out:','/pdb:','/map:','/implib:')):continue
 if word.lower()==old.lower():word=str(W/'compile/consumer.obj');found+=1
 link.append(word)
assert found==1
for word in link[1:]:
 if word.lower().endswith(('.obj','.lib'))and Path(word).is_absolute():assert Path(word).is_file(),word
link+=['/OUT:'+str(W/'link/consumer.exe'),'/PDB:'+str(W/'link/consumer.pdb'),'/IMPLIB:'+str(W/'link/consumer.lib')]
b.execute(link,W/'link',env,60)
runtime=b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json');native=Path(runtime['native']['path']);os.link(native,W/'link'/native.name)
runenv=env.copy();runenv['PATH']=str(W/'link')+';'+runtime['PATH'];runenv['HF_HUB_OFFLINE']='1';runenv['TRANSFORMERS_OFFLINE']='1'
inputs=b.read(W/'preparation.json')['original_directory']
b.save(W/'runtime-pins.json',dict(native=b.pin(native),image=b.pin(W/'link/consumer.exe'),retained_link=b.pin(reference/'link/command.json'),entry_only_replaced=True,SDK_builds=0,HTTP=0))
b.execute([str(W/'link/consumer.exe'),str(W/'source-bound-metadata.tsv'),inputs,str(W/'bad-shape.i64'),str(W/'vectors')],W/'run',runenv,120)
stdout=(W/'run/stdout.log').read_text(encoding='utf-8-sig');result=json.loads(next(line for line in stdout.splitlines()if line.startswith('{')));assert result['status']=='PASS'and result['numeric_values']==178176
for row in pins:assert b.pin(Path(row['original']['path']))['sha256']==row['original']['sha256'],row['original']['path']
b.save(W/'actual-summary.json',dict(status='PASS',consumer=result,compile=b.read(W/'compile/process.json'),link=b.read(W/'link/process.json'),run=b.read(W/'run/process.json'),actual_consumer_processes=1,SDK_builds=0,HTTP=0,source_pins='frozen-pins.json',limitations=['Finite original target63 projection component; not whole model or new MTP function.','No Graph-visible complete floating W; provider internal transient storage is not independently measured.'],outputs=[b.pin(p)for p in(W/'vectors').iterdir()if p.is_file()]));print(json.dumps(result,indent=2))
