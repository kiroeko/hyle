from pathlib import Path
import difflib,hashlib,json,zipfile
R=Path.cwd();W=R/'.scratch/ct-asymmetric-qwen-projection-20261025'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
final=W/'attempt4';actual=read(final/'actual-summary.json');assert actual['status']=='PASS'
source=final/'source';main=source/'engine/models/qwen35/main.cc';assert pin(main)['sha256']=='25c519ec48627aa5ebf82447c524b8b315f1587a024ea082f93dea863f0888a3'
patch=''
for rel in ('engine/models/qwen35/main.cc','engine/models/qwen35/projection_binding.h'):
 a=W/'before'/rel;b=source/rel
 patch+=''.join(difflib.unified_diff(a.read_text().splitlines(True),b.read_text().splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
(W/'implementation.patch').write_text(patch)
# These small non-entry source changes name the existing selected policy only.
support=[R/p for p in ('src/graph/artifact_packed_region.h','tests/compute_models/qwen_artifact_projection_fragment.h','src/compute_provider_native/native_provider.cc','src/compute_provider_native/ct_packed.cc','include/hyle/compute/resource_leases.h','src/compute/resource_leases.cc')]
sd=W/'support-source'
for p in support:
 d=sd/p.relative_to(R);d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(p.read_bytes())
cleanup=[pin(p)for p in sorted(W.rglob('*'))if p.is_file()and p.suffix.lower()in('.obj','.exe','.exp','.lib','.dll','.pdb','.ilk')]
save(W/'cleanup-candidates.json',dict(performed=False,files=cleanup,logical_bytes=sum(p['bytes']for p in cleanup),note='Exact private regenerated objects/images/import libraries and private hard links only; original SDK/native DLL, caches and c343 baseline excluded. DLL hard links need not reclaim their logical size.'))
attempts=[]
for name,d,reason in [('attempt1',W,'Private final assertion called non-const ReadLease::try_write through const bank iteration; strict compile failed, no consumer run.'),('attempt2',W/'attempt2','Actual M1 passed; private test incorrectly demanded CPU default M2 use packed policy. Existing measured M>1 native preference1001 legitimately selects decomposed execution. No product failure.'),('attempt3',W/'attempt3','All M1/M2 numerical comparisons passed; private final assertion incorrectly required loader-only unique I64 shape lease to reject promotion. Shared/native read permission is required only for actual graph operands.'),('attempt4',W/'attempt4','Corrected private assertions respect actual selected plan and lease contracts; unchanged product/math/route passed.')]:
 row=dict(name=name,reason=reason)
 for stage in('compile','link','run'):
  p=d/stage/'process.json'
  if p.exists():row[stage]=read(p)
 attempts.append(row)
producer=R/'.scratch/ct-asymmetric-int4-header/ct-source';original=R/'.scratch/qwen-bfloat-selected-20261023/derived/Q09/original-roles'
summary=dict(status='PASS_ORIGINAL_COMPONENT',scope=read(W/'preparation.json'),implementation=dict(validated_main=pin(main),validated_projection_binding=pin(source/'engine/models/qwen35/projection_binding.h'),typed_codec='kCtAsymmetric4',binding='CtPackedProjection{codes,optional zeros,scales,ArtifactWeightDecode}',io='Common load_selected_weight_roles original pipeline body; full load_weight_bank retains complete metadata selection/geometry validation.',graph='Original Decode/View/MatMul public chain with BF16 subtraction/product/projection and optional final F32 score widening.',selected_policy='kArtifactPackedProjectionPolicy names the unchanged cached SDK literal 0x48594c454354504c/1/1; SDK not rebuilt.',support_source_pins=[pin(p)for p in support]),validation=dict(attempts=attempts,actual_consumer_processes=3,successful_consumer_processes=1,compile_attempts=4,strict_successful_compiles=3,link_processes=3,final_actual=actual,HTTP=0,GPU_runs=0,SDK_builds=0,ordinary_numeric_values_per_complete_run=178176,unchanged_original_cached_weights=True,original_weight_payloads_in_archive=False),oracle=dict(kind='Independent scalar low-first signed nibble/packed zero-point reader, not Hyle ArtifactWeightDecode.',producer_revision='compressed-tensors@ac8e2ba82f4e0d5eaa40069f8fc642738f124cd4',source_files=[pin(p)for p in sorted(producer.rglob('*.py'))],equations='code=(nibble-8); Z=(nibble-8); D=BF16(BF16(code-Z)*BF16(scale)); dot uses BF16 activation, F32 accumulation then BF16 result; first projection is widened to F32 afterward.',inputs='M1 col0=BF16(1.25); M2 also row1 col33=BF16(6.5), all other activations zero. Onehot projections give exact rounding witnesses, not dense-activation accuracy/quality coverage.',independent_expected_generated_from_original_cache=True,wrong_symmetric_witnesses=131105,all_178176_final_values_exact=True),plan=dict(M1=dict(actual_packed_chains=7,chain_nodes=3,graph_visible_full_weight_intermediate_values=0),M2=dict(actual_packed_chains=0,decomposed_projections=7,graph_visible_full_weight_intermediate_values=14,reason='Existing CPU M>1 scalar packed cost preference1001 vs ordinary1000; prior measured policy retained.'),provider_internal_transient_storage='Not independently measured.',memory_benchmark=False),negative_checks=dict(real_I64_weight_shape_corruption_rejected=True,missing_original_Z_rejected=True,NF4_unsupported_at_common_IO_entry_before_IO=True),limits=['Finite target layer63 seven source projections only; not an entire Q27 model, vocabulary head or activation trajectory.','Complete metadata is authenticated from original headers; subset source identity is explicitly not the complete model-body preparation fingerprint.','Score widening uses one original component projection as a precision witness; does not claim the actual vocabulary head was loaded.','No new MTP functionality, backend matrix, end-to-end generation/quality or speed claim.','M2 default intentionally materializes Graph-visible floating W; no dense full-model resident bank was loaded.','Existing symmetric/GPTQ math/chain implementations preserved; not newly executed in this component.'],dependencies=[dict(path='docs/evidence/correctness/ct-asymmetric-qwen-cold-metadata-2026-10-25.zip',sha256=hashlib.sha256((R/'docs/evidence/correctness/ct-asymmetric-qwen-cold-metadata-2026-10-25.zip').read_bytes()).hexdigest()),pin(R/'docs/evidence/performance/ct-packed-cpu-policy-2026-10-20.json')],cleanup=read(W/'cleanup-candidates.json'))
save(W/'proof-summary.json',summary)
allowed=[]
exclude={'.obj','.exe','.exp','.lib','.dll','.pdb','.ilk'}
for p in sorted(W.rglob('*')):
 if not p.is_file()or p.suffix.lower()in exclude or p.name in('proof.zip','proof-archive.json'):continue
 allowed.append((p,p.relative_to(W).as_posix()))
for p in sorted(producer.rglob('*.py')):allowed.append((p,'original-reader/'+p.relative_to(producer).as_posix()))
for p in sorted((R/'.scratch/ct-asymmetric-int4-header/headers').glob('*.json')):allowed.append((p,'original-headers/'+p.name))
for name in('manifest.json','acquisition.json'):
 p=original/name
 if p.exists():allowed.append((p,'original-role-receipts/'+name))
# Retained link/compile commands define the exact unchanged cached closure.
for rel in('.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json','.scratch/inference-system-review-20261025/text-r2-suffix/link/command.json','.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'):
 p=R/rel;allowed.append((p,'retained-closure/'+p.parent.name+'-'+p.name))
inventory=[dict(archive_path=name,**pin(p))for p,name in allowed];save(W/'archive-payload-pins.json',inventory);allowed.append((W/'archive-payload-pins.json','archive-payload-pins.json'))
with zipfile.ZipFile(W/'proof.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p,name in allowed:z.write(p,name)
save(W/'proof-archive.json',dict(archive=pin(W/'proof.zip'),payload_files=len(allowed),cleanup=read(W/'cleanup-candidates.json')))
print(json.dumps(dict(archive=pin(W/'proof.zip'),payload_files=len(allowed),cleanup_files=len(cleanup),cleanup_logical_bytes=sum(p['bytes']for p in cleanup)),indent=2))
