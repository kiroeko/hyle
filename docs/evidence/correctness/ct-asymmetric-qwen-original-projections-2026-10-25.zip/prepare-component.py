from pathlib import Path
import hashlib,json,struct
R=Path.cwd();W=R/'.scratch/ct-asymmetric-qwen-projection-20261025';C=R/'.scratch/ct-asymmetric-int4-header';S=R/'.scratch/qwen-bfloat-selected-20261023/derived/Q09/original-roles'
import sys;sys.path.insert(0,str(R));from engine.models.qwen35 import prepare as p
manifest=json.loads((S/'manifest.json').read_text());assert manifest['revision']=='6e134bae811fb5adac50ee042ae5f029ac6779aa'
known={r['name']:r for r in manifest['roles']};all={}
for f in sorted((C/'headers').glob('*.header.json')):
 hdr=json.loads(f.read_bytes());offset=8+f.stat().st_size
 for name,row in hdr.items():
  if name=='__metadata__'or not name.startswith(('model.language_model.','mtp.','lm_head.')):continue
  row=dict(row);row['name']=name;row['bytes']=row['data_offsets'][1]-row['data_offsets'][0]
  row['path']=str(S/known[name]['file'])if name in known else str(W/'unread-original-shards'/f.name.replace('.header.json','.safetensors'))
  row['offset']=0 if name in known else offset+row['data_offsets'][0]
  all[name]=row
config=json.loads((C/'config.json').read_text());g=p.geometry.from_hf(config);p.validate_role_geometry(all,g)
assert len(all)==2063
identity=hashlib.sha256(json.dumps(dict(headers=[hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted((C/'headers').glob('*.header.json'))],policy=p.CT_ASYMMETRIC_POLICY,available_original_manifest_sha256=hashlib.sha256((S/'manifest.json').read_bytes()).hexdigest()),sort_keys=True).encode()).hexdigest()
lines=['HYLE_QWEN_ROLE_FILES_V2',identity,p.geometry.line(g),p.CT_ASYMMETRIC_POLICY_LINE]
for name,row in sorted(all.items()):lines.append('\t'.join((name,row['dtype'],str(len(row['shape'])),*(str(d)for d in row['shape']),json.dumps(row['path']),str(row['offset']),str(row['bytes']))))
(W/'source-bound-metadata.tsv').write_text('\n'.join(lines)+'\n')
selected=[r for r in manifest['roles']if r['name'].startswith('model.language_model.layers.63.')and r['name'].endswith(('.weight_packed','.weight_scale','.weight_zero_point','.weight_shape'))]
assert len(selected)==28
projections=[r for r in selected if r['name'].endswith('.weight_packed')];assert len(projections)==7
h=['#pragma once','struct OriginalSpec { const char *name,*file,*sha; std::size_t bytes; };',f'inline constexpr std::array<OriginalSpec,{len(selected)}> original_specs{{{{']
for r in selected:h.append('{'+','.join((json.dumps(r['name']),json.dumps(r['file']),json.dumps(r['sha256']),str(r['bytes'])))+'},')
h+=['}};','struct ProjectionSpec { const char *name; std::int64_t n,k; };','inline constexpr std::array<ProjectionSpec,7> original_projections{{']
for r in projections:h.append('{'+json.dumps(r['name'][:-14]+'.weight')+','+str(r['shape'][0])+','+str(r['shape'][1]*8)+'},')
h+=['}};']
(W/'original-specs.h').write_text('\n'.join(h)+'\n')
shape=next(r for r in selected if '.self_attn.k_proj.weight_shape' in r['name']);raw=(S/shape['file']).read_bytes();bad=bytearray(raw);bad[0]^=1;(W/'bad-shape.i64').write_bytes(bad)
summary=dict(repository=manifest['repository'],revision=manifest['revision'],metadata_roles=2063,ordinary_selected_metadata=2048,selected_original_component_roles=28,selected_original_component_bytes=sum(r['bytes']for r in selected),ordinary_projections=7,original_directory=str(S),source_identity=identity,source_identity_scope='Fixed complete header/typed policy plus authenticated available-role manifest; not full original-body preparation fingerprint.',role_manifest_sha256=hashlib.sha256((S/'manifest.json').read_bytes()).hexdigest(),source_role_records=selected,full_original_model=False,unread_roles_never_requested=True,planned_backend='CPU',planned_math_submissions=2,planned_rows=[1,2],planned_numeric_values=3*sum(r['shape'][0]for r in projections),HTTP=0,SDK_builds=0)
(W/'preparation.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:summary[k]for k in ('selected_original_component_roles','selected_original_component_bytes','planned_numeric_values')})
