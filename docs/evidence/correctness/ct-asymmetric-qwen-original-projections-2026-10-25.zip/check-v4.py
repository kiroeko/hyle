from pathlib import Path
import importlib.util,json,os,shutil,sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/ct-asymmetric-qwen-projection-20261025';A=W/'attempt4';A.mkdir();S=A/'source'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
# Preserve the first source snapshot. Only the private test fix and a public
# header comment relocation differ; do not consume concurrent chunked-prefill.
shutil.copytree(W/'source',S)
shutil.copyfile(W/'consumer.cc',S/'consumer.cc')
shutil.copyfile(R/'include/hyle/graph/executable.h',S/'include/hyle/graph/executable.h')
assert b.pin(S/'engine/models/qwen35/main.cc')['sha256']=='25c519ec48627aa5ebf82447c524b8b315f1587a024ea082f93dea863f0888a3'
pins=[b.pin(p)for p in S.rglob('*')if p.is_file()];b.save(A/'frozen-pins.json',pins)
reference=R/'.scratch/inference-system-review-20261025/text-r2-suffix'
base=b.args(reference/'compile/command.json');cmd=[base[0],'/I'+str(S),'/I'+str(S/'include')];skip=False
for word in base[1:]:
 if skip:skip=False;continue
 if word=='/sourceDependencies':skip=True;continue
 low=word.lower().replace('\\','/')
 if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
 if low.startswith(('/i','-i'))and '/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(word)
cmd+=['/sourceDependencies',str(A/'compile/dependencies.json'),str(S/'consumer.cc'),'/Fo'+str(A/'compile/consumer.obj'),'/Fd'+str(A/'compile/consumer.pdb')]
env=b.environment(base[0]);b.execute(cmd,A/'compile',env,120)
includes=[Path(p).resolve()for p in b.read(A/'compile/dependencies.json')['Data']['Includes']];leaks=[str(p)for p in includes if p.is_relative_to(R/'engine')or p.is_relative_to(R/'tests')];assert not leaks,leaks
link=[];old=str(reference/'compile/unit.obj');found=0
for word in b.args(reference/'link/command.json'):
 if word.lower().startswith(('/out:','/pdb:','/map:','/implib:')):continue
 if word.lower()==old.lower():word=str(A/'compile/consumer.obj');found+=1
 link.append(word)
assert found==1
for word in link[1:]:
 if word.lower().endswith(('.obj','.lib'))and Path(word).is_absolute():assert Path(word).is_file(),word
link+=['/OUT:'+str(A/'link/consumer.exe'),'/PDB:'+str(A/'link/consumer.pdb'),'/IMPLIB:'+str(A/'link/consumer.lib')]
b.execute(link,A/'link',env,60)
runtime=b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json');native=Path(runtime['native']['path']);os.link(native,A/'link'/native.name)
runenv=env.copy();runenv['PATH']=str(A/'link')+';'+runtime['PATH'];runenv['HF_HUB_OFFLINE']='1';runenv['TRANSFORMERS_OFFLINE']='1'
inputs=b.read(W/'preparation.json')['original_directory']
b.save(A/'runtime-pins.json',dict(native=b.pin(native),image=b.pin(A/'link/consumer.exe'),retained_link=b.pin(reference/'link/command.json'),entry_only_replaced=True,SDK_builds=0,HTTP=0))
b.execute([str(A/'link/consumer.exe'),str(W/'source-bound-metadata.tsv'),inputs,str(W/'bad-shape.i64'),str(A/'vectors')],A/'run',runenv,120)
stdout=(A/'run/stdout.log').read_text(encoding='utf-8-sig');result=json.loads(next(line for line in stdout.splitlines()if line.startswith('{')));assert result['status']=='PASS'and result['numeric_values']==178176
for row in pins:assert b.pin(Path(row['path']))['sha256']==row['sha256'],row['path']
b.save(A/'actual-summary.json',dict(status='PASS',consumer=result,compile=b.read(A/'compile/process.json'),link=b.read(A/'link/process.json'),run=b.read(A/'run/process.json'),actual_consumer_processes=1,SDK_builds=0,HTTP=0,source_pins='frozen-pins.json',limitations=['Finite original target63 projection component; not whole model or new MTP function.','M1 selects seven actual packed chains and has no Graph-visible full floating W; default M2 decomposes and materializes floating weight values. Provider internal transient storage is not measured.'],outputs=[b.pin(p)for p in(A/'vectors').iterdir()if p.is_file()]));print(json.dumps(result,indent=2))
