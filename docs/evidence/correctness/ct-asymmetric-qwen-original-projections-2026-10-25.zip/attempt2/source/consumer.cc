// Finite original Q27 CT asymmetric source import and ordinary projections.
#include "engine/models/qwen35/main.cc"
#include "tests/compute_models/original_role_input.h"
#include "original-specs.h"
namespace q=qwen35;
namespace fs=std::filesystem;
void require(bool yes,const char*message){if(!yes)throw std::runtime_error(message);}
std::uint16_t bf16(float value){auto bits=std::bit_cast<std::uint32_t>(value);bits+=0x7fffU+((bits>>16)&1U);return std::uint16_t(bits>>16);}
float widen(std::uint16_t value){return std::bit_cast<float>(std::uint32_t(value)<<16);}
std::uint32_t word(std::span<const std::byte> raw,std::size_t at){std::uint32_t value=0;for(unsigned i=0;i<4;++i)value|=std::uint32_t(std::to_integer<unsigned>(raw[at*4+i]))<<(i*8);return value;}
std::uint16_t halfword(std::span<const std::byte> raw,std::size_t at){return std::uint16_t(std::to_integer<unsigned>(raw[at*2])|(std::to_integer<unsigned>(raw[at*2+1])<<8));}
struct Original final{std::map<std::string,q::mem::FileMapping> mappings;
 explicit Original(const fs::path&directory){for(const auto &spec:original_specs){auto map=q::take(q::mem::FileMapping::open((directory/spec.file).string().c_str()));require(map.size()==spec.bytes,"original cached role extent changed");const auto raw=q::take(map.bytes());require(original_role_input::sha256(raw)==spec.sha,"original cached role SHA changed");mappings.emplace(spec.name,std::move(map));}}
 std::span<const std::byte> bytes(const std::string&name)const{return q::take(mappings.at(name).bytes());}
};
q::prepared::Roles select(const q::prepared::Roles&all){auto result=all;result.selected.clear();result.bytes=0;for(const auto &spec:original_specs){auto it=std::ranges::find(all.selected,spec.name,&q::prepared::Role::name);require(it!=all.selected.end(),"complete original metadata lost a selected component role");require(it->bytes==spec.bytes,"original selected role extent changed");result.selected.push_back(*it);result.bytes=q::cache::add(result.bytes,it->bytes);}return result;}
void check_negative_loaders(const q::prepared::Roles&subset,q::Backend&backend,const fs::path&bad_shape){
 {
  auto invalid=subset;invalid.selected.resize(1);invalid.selected[0].projection_codec=q::prepared::ProjectionCodec::kNf4DoubleQuant;
  std::vector<q::c::LeasePool> pools;std::map<std::string,q::LoadedWeight> bank;bool refused=false;
  try{(void)q::load_selected_weight_roles(invalid,backend,bank,pools);}catch(const std::exception&e){refused=std::string_view(e.what()).find("NF4 metadata")!=std::string_view::npos;}
  require(refused&&bank.empty()&&pools.empty(),"shared loader did not reject unsupported NF4 before IO");
 }
 {
  auto invalid=subset;invalid.selected.clear();invalid.bytes=0;const std::string base="model.language_model.layers.63.self_attn.k_proj";
  for(const auto &role:subset.selected)if(role.name.starts_with(base+".")){auto next=role;if(next.name.ends_with(".weight_shape"))next.source=bad_shape;invalid.selected.push_back(next);invalid.bytes+=next.bytes;}
  require(invalid.selected.size()==4,"negative shape component group differs");
  std::vector<q::c::LeasePool> pools;std::map<std::string,q::LoadedWeight> bank;bool refused=false;
  try{(void)q::load_selected_weight_roles(invalid,backend,bank,pools);}catch(const std::exception&e){refused=std::string_view(e.what()).find("weight_shape values differ")!=std::string_view::npos;}
  require(refused,"real loader admitted corrupted original I64 shape values");
 }
}
void save(const fs::path&path,std::span<const std::byte> bytes){std::ofstream file(path,std::ios::binary);file.write(reinterpret_cast<const char*>(bytes.data()),std::streamsize(bytes.size()));require(bool(file),"cannot save finite component output");}
void verify_packed(const q::g::Graph&graph,const q::g::CompileReport&report,const q::Recipe&recipe,const fs::path&path){
 require(recipe.packed_projection_nodes.size()==7,"all seven CT projections must report their exact closed chains");
 q::report_packed_projections(graph,report,recipe.packed_projection_nodes);
 std::ofstream out(path);out<<"step\tprovider\tpolicy_namespace\tpolicy_id\tnodes\tworkspace\n";
 std::size_t selected=0;
 for(std::size_t i=0;i<report.step_count();++i){const auto step=q::take(report.step(i));out<<i<<'\t'<<step.provider.name<<'\t'<<step.policy.namespace_id<<'\t'<<step.policy.policy_id<<'\t'<<step.node_count<<'\t'<<step.workspace.size<<'\n';if(step.policy==q::g::kArtifactPackedProjectionPolicy){require(step.node_count==3,"CT actual packed contraction is not three public nodes");++selected;}}
 require(selected==7,"actual selected plan did not use seven typed packed contracts");
 for(const auto &chain:recipe.packed_projection_nodes){require(chain.count==3,"CT acquired an unnecessary Cast");for(std::size_t j=0;j+1<chain.count;++j){const auto value=q::take(graph.result(chain.chain[j]));for(std::size_t i=0;i<report.physical_value_count();++i)require(q::take(report.physical_value(i)).value!=value,"whole floating W materialized in actual selected plan");}}
}
int main(int argc,char**argv){try{
 require(argc==5,"ct component FULL_METADATA ORIGINAL_CACHE BAD_SHAPE OUTPUT");const fs::path output=argv[4];fs::create_directories(output);
 auto backend=q::take(q::Backend::create({.primary=hyle::inference::BackendKind::kCpu}));
 const auto all=q::read_weight_roles(argv[1],false);require(all.selected.size()==2048&&all.ct_asymmetric_policy.enabled,"complete ordinary source metadata changed");
 const auto subset=select(all);require(subset.selected.size()==28&&subset.bytes==215203952,"finite original source subset differs");
 Original original(argv[2]);check_negative_loaders(subset,backend,argv[3]);
 std::vector<q::c::LeasePool> pools;std::map<std::string,q::LoadedWeight> bank;
 const auto loaded=q::load_selected_weight_roles(subset,backend,bank,pools);
 require(loaded.bytes==subset.bytes&&loaded.canonical_bytes==subset.bytes&&bank.size()==28,"shared original loader did not preserve exact component byte inventory");
 // The malformed resolver runs before a valid binding can borrow bank pointers.
 const std::string missing="model.language_model.layers.63.self_attn.k_proj.weight_zero_point";
 auto restored=std::move(bank.at(missing));bank.erase(missing);bool rejected=false;
 try{(void)q::resolve_projection(bank,"model.language_model.layers.63.self_attn.k_proj.weight");}catch(const std::exception&){rejected=true;}
 bank.emplace(missing,std::move(restored));require(rejected,"asymmetric resolver ignored its missing Z role");
 q::ProjectionBindings projections;for(const auto&spec:original_projections){auto binding=q::resolve_projection(bank,spec.name);const auto*typed=std::get_if<q::CtPackedProjection>(&binding);require(typed&&typed->zeros&&typed->decode.format==q::c::model_ops::WeightArtifactFormat::kCompressedTensorsAsymmetric4&&typed->decode.group_size==32&&typed->decode.output_type==q::Type::kBFloat16,"source component lost typed asymmetric arithmetic");projections.emplace(spec.name,std::move(binding));}
 q::GraphAssembly assembly(backend);q::Recipe recipe(bank,projections,assembly,all.geometry,2);
 std::array<q::V,7> inputs,results;
 for(std::size_t i=0;i<7;++i){inputs[i]=recipe.input(q::Recipe::dense_spec(q::Type::kBFloat16,{recipe.packed_rows,q::f(original_projections[i].k)}));results[i]=i==0?recipe.scores(inputs[i],original_projections[i].name):recipe.linear_absolute(inputs[i],original_projections[i].name);recipe.publish(results[i]);}
 auto graph=q::take(std::move(recipe.builder).finish());require(graph.node_count()==22,"ordinary CT graph must have seven Decode/View/MatMul chains and one final F32 widening");
 const std::array shapes{std::array{q::g::ShapeBinding{recipe.last_row,0}},std::array{q::g::ShapeBinding{recipe.last_row,1}}};const std::array variants{q::g::ExactShapeVariant{shapes[0]},q::g::ExactShapeVariant{shapes[1]}};
 auto compiled=q::take(backend.compile(graph,assembly.constants,assembly.options({.shape_policy=q::g::CompileShapePolicy::kFiniteExact,.exact_variants=variants,.constants=assembly.constants})));
 std::size_t checked=0,witnesses=0;std::array<std::vector<std::byte>,7> row0;
 for(std::size_t at=0;at<2;++at){const std::size_t rows=at+1;auto child=q::take(compiled.executable.exact_variant(at));auto report=q::take(compiled.report.exact_variant(at));verify_packed(graph,report,recipe,output/("M"+std::to_string(rows)+"-plan.tsv"));
  std::array<q::Tensor,7> activation,caller;std::array<hyle::inference::PreparedOutputFacts,7> facts;
  for(std::size_t i=0;i<7;++i){const auto k=original_projections[i].k;activation[i]=q::Tensor(backend.device(),q::dense(q::Type::kBFloat16,{std::int64_t(rows),k}));std::vector<std::uint16_t> raw(rows*std::size_t(k));raw[0]=0x3fa0;if(rows==2)raw[std::size_t(k)+33]=0x40d0;activation[i].write<std::uint16_t>(raw);facts[i]=q::take(hyle::inference::prepare_output(q::g::CompiledGraph{child,report},results[i]));require(facts[i].description.data_type()==(i? q::Type::kBFloat16:q::Type::kFloat32),"projection/head dtype boundary changed");if(facts[i].caller_owned())caller[i]=q::Tensor(q::take(backend.resource_for(facts[i].storage)),facts[i].description);}
  auto run=q::take(child.create_invocation());q::check(run.prepare_resources());for(std::size_t i=0;i<7;++i){q::check(run.bind(inputs[i],activation[i].read()));if(caller[i].buffer)q::check(run.bind(results[i],caller[i].view()));}
  auto queues=q::take(hyle::inference::prepare_queue_bindings(backend.queue_bindings(),report));auto bindings=hyle::inference::queue_span(queues);q::check(run.prepare_replay(bindings,{.mode=q::g::ReplayMode::kCommands,.host_wait=q::g::HostWaitPolicy::kAllow}));auto done=q::take(run.submit(bindings));q::check(done.wait());
  for(std::size_t i=0;i<7;++i){const auto&spec=original_projections[i];const std::string base=std::string(spec.name).substr(0,std::string_view(spec.name).size()-7);const auto codes=original.bytes(base+".weight_packed"),zeros=original.bytes(base+".weight_zero_point"),scales=original.bytes(base+".weight_scale");const auto groups=std::size_t(spec.k/32);
   std::vector<std::byte> actual(q::take(facts[i].description.required_bytes()));if(caller[i].buffer)q::check(backend.read(caller[i].buffer.view(),actual));else{auto lease=q::take(hyle::inference::retain_output(run,facts[i]));q::check(backend.read(q::take(lease.view()),actual));}
   std::vector<std::byte> expected(actual.size());for(std::size_t row=0;row<rows;++row)for(std::size_t n=0;n<std::size_t(spec.n);++n){const std::size_t col=row?33:0;const int code=int((word(codes,n*std::size_t(spec.k/8)+col/8)>>(4*(col%8)))&15)-8;const int zero=int((word(zeros,(n/8)*groups+col/32)>>(4*(n%8)))&15)-8;const auto scale=widen(halfword(scales,n*groups+col/32));require(std::isfinite(scale),"original scale is not finite");const auto decoded=widen(bf16(widen(bf16(float(code)-float(zero)))*scale));const float a=row?6.5F:1.25F;const auto y=bf16(0.F+a*decoded),wrong=bf16(0.F+a*widen(bf16(float(code)*scale)));witnesses+=y!=wrong;const auto index=row*std::size_t(spec.n)+n;if(i){expected[index*2]=std::byte(y&255);expected[index*2+1]=std::byte(y>>8);}else{const auto f=widen(y);std::memcpy(expected.data()+index*4,&f,4);}++checked;}
   require(actual==expected,"original CT BF16 subtraction/product/projection oracle differs");const auto first=actual.size()/rows;if(at)require(std::equal(row0[i].begin(),row0[i].end(),actual.begin()),"M2 row0 changed from the same exact M1 input");else row0[i].assign(actual.begin(),actual.begin()+std::ptrdiff_t(first));
   save(output/("P"+std::to_string(i)+"-M"+std::to_string(rows)+(i?".bf16":".f32")),actual);
  }
 }
 require(checked==178176&&witnesses>0,"original zero-point numerical witness was not exercised");for(auto&[name,value]:bank){(void)name;require(value.tensor.ready&&!value.tensor.ready.try_write(),"shared original packed input lost its readonly lease");}
 std::cout<<"{\"status\":\"PASS\",\"backend\":\"CPU\",\"original_roles\":28,\"original_bytes\":"<<loaded.bytes<<",\"canonical_bytes\":"<<loaded.canonical_bytes<<",\"source_full_metadata_roles\":2048,\"projections\":7,\"graph_submissions\":2,\"rows\":[1,2],\"actual_packed_chains_per_child\":7,\"chain_nodes\":3,\"numeric_values\":"<<checked<<",\"wrong_symmetric_witnesses\":"<<witnesses<<",\"corrupted_shape_loader_rejected\":true,\"missing_Z_resolver_rejected\":true,\"unsupported_NF4_before_IO_rejected\":true,\"graph_whole_floating_weight_bank\":false,\"source_component_not_full_model\":true,\"score_policy\":"<<std::quoted(std::string(q::score_policy(projections.at(original_projections[0].name))))<<"}\n";return 0;
}catch(const std::exception&e){std::cerr<<"CT original consumer: "<<e.what()<<'\n';return 1;}}
