from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time

mode = sys.argv[1]
assert mode in ('asan', 'ubsan', 'tsan')
repo = Path('/mnt/c/public/project-hyle/hyle')
out = repo / '.scratch/inference-gaps/g01/native-paged'
source = Path('/home/kiro/hyle-f1/sanitizers/source-03242e7723cb')
build = source.parent / (mode + '-03242e7723cb')
assert source.is_dir() and not (source / '.git').exists()
candidate = '197d39684: AUDITED NP01 draft, not native math candidate'
manifest = json.loads((out / 'native-metadata-sync-inputs.json').read_text())
copied = []
for item in manifest:
    relative = Path(item['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    origin, dest = repo / relative, source / relative
    digest = hashlib.sha256(origin.read_bytes()).hexdigest()
    assert digest == item['sha256'], str(relative)
    if not dest.exists() or hashlib.sha256(dest.read_bytes()).hexdigest() != digest:
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, dest)  # Changed bytes get this build machine timestamp; unchanged files remain untouched.
        copied.append(str(relative))
    assert hashlib.sha256(dest.read_bytes()).hexdigest() == digest
(out / ('native-metadata-' + mode + '-sync.json')).write_text(json.dumps({
    'candidate': candidate, 'destination': str(source), 'one_way': True,
    'checked': len(manifest), 'copied': copied, 'inputs': manifest}, indent=2) + '\n')
hook = out / ('native-metadata-' + mode + '-project.cmake')
body = '''if(PROJECT_NAME STREQUAL "hyle")
 get_property(_ready GLOBAL PROPERTY G01_NATIVE_METADATA_GTEST)
 if(NOT _ready)
  set_property(GLOBAL PROPERTY G01_NATIVE_METADATA_GTEST TRUE)
  set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
  add_subdirectory(/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g02-native-metadata-gtest EXCLUDE_FROM_ALL)
 endif()
 function(g01_native_metadata_tests)
  add_executable(g01_native_metadata_tests "@SOURCE@/tests/compute_batch/native_paged_metadata_test.cc" "@SOURCE@/tests/compute_batch/batch_layout_test.cc" "@SOURCE@/tests/compute_batch/batch_materialize_test.cc" "@SOURCE@/tests/compute_batch/paged_arena_test.cc")
  target_compile_features(g01_native_metadata_tests PRIVATE cxx_std_23)
  target_link_libraries(g01_native_metadata_tests PRIVATE hyle::compute GTest::gtest_main)
  hyle_apply_sanitizer(g01_native_metadata_tests)
  hyle_stage_runtime(g01_native_metadata_tests)
 endfunction()
 cmake_language(DEFER CALL g01_native_metadata_tests)
endif()
'''.replace('@SOURCE@', str(source))
if not hook.exists() or hook.read_text() != body:
    hook.write_text(body)
result_file = out / ('native-metadata-' + mode + '-result.json')
prior = json.loads(result_file.read_text()) if result_file.exists() else {}
records = prior.get('stages', [])
for row in records:
    row.setdefault('candidate', prior.get('candidate'))

def run(stage, args, env=None):
    attempt = 1 + sum(x['stage'] == stage for x in records)
    log = out / ('native-metadata-' + mode + '-' + stage + '-' + str(attempt) + '.log')
    started = time.monotonic()
    with log.open('w') as f:
        r = subprocess.run(args, env=env, stdout=f, stderr=subprocess.STDOUT)
    row = {'candidate': candidate, 'stage': stage, 'command': args, 'exit_code': r.returncode,
           'elapsed_seconds': time.monotonic() - started, 'log': str(log)}
    records.append(row)
    result_file.write_text(json.dumps({'candidate': candidate, 'mode': mode,
        'scope': 'NP01 compact owned page metadata plus original batch/layout/arena regressions; no GPU math qualification',
        'stages': records}, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if r.returncode:
        with log.open('rb') as f:
            f.seek(max(0, log.stat().st_size - 2400))
            print(f.read(2400).decode('utf-8', errors='replace'), flush=True)
        raise SystemExit(r.returncode)

print(json.dumps({'mode': mode, 'sync_checked': len(manifest), 'sync_copied': len(copied)}), flush=True)
configuration_inputs = [x for x in manifest if x['path'].endswith(('.cmake', 'CMakeLists.txt', 'patches.json', 'HyleDependencyLock.json'))]
configuration_digest = hashlib.sha256((body + json.dumps(configuration_inputs, sort_keys=True)).encode()).hexdigest()
configuration_record = out / ('native-metadata-' + mode + '-configuration.json')
previous_configuration = json.loads(configuration_record.read_text()) if configuration_record.exists() else {}
if previous_configuration.get('sha256') != configuration_digest:
    run('configure', ['cmake', '-S', str(source), '-B', str(build),
                      '-DCMAKE_PROJECT_INCLUDE=' + str(hook)])
    configuration_record.write_text(json.dumps({'sha256': configuration_digest, 'inputs': configuration_inputs}, indent=2) + '\n')
else:
    print(json.dumps({'configure': 'reused identical CMake/hook/lock/patch inputs'}), flush=True)
run('build', ['cmake', '--build', str(build), '--target', 'g01_native_metadata_tests', '--parallel', '4'])
commands = json.loads(subprocess.check_output(['ninja', '-C', str(build), '-t', 'compdb'], text=True))
flag = {'asan': '-fsanitize=address', 'ubsan': '-fsanitize=undefined', 'tsan': '-fsanitize=thread'}[mode]
checked = []
for name in ['src/compute_batch/batch_paged_native.cc', 'src/compute_batch/batch_layout.cc',
             'tests/compute_batch/native_paged_metadata_test.cc']:
    rows = [x for x in commands if x['file'].endswith(name)]
    assert rows and all(flag in x['command'] for x in rows), name
    checked.extend(rows)
(out / ('native-metadata-' + mode + '-instrumented-inputs.json')).write_text(json.dumps(checked, indent=2) + '\n')
env = os.environ.copy()
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1', TSAN_OPTIONS='halt_on_error=1')
exe = build / 'bin/g01_native_metadata_tests'
if not exe.exists():
    exe = build / 'g01_native_metadata_tests'
args = [str(exe)]
if mode == 'tsan':
    args = ['setarch', 'x86_64', '-R', *args]
run('run' if not sys.argv[2:] else 'run-selected', [*args, *sys.argv[2:]], env)
