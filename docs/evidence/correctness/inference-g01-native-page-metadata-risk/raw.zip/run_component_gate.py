from pathlib import Path
import json,subprocess,os,time,sys
root=Path.cwd();attempt=int(sys.argv[1]);folder=Path('C:/h7/g01-native-page-component-gate-3') if attempt==3 else root/'.scratch/inference-gaps/g01/native-paged'/('component-gate-'+str(attempt));target=folder/'component-contract'
if attempt==3:
 assert folder.resolve()==Path('C:/h7/g01-native-page-component-gate-3').resolve() and target.resolve().parent==folder.resolve() and target.name=='component-contract'
else:
 assert target.resolve().is_relative_to(root.resolve()) and target.name=='component-contract'
folder.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
sdk=Path('C:/public/tools/hyle-vulkan/1.4.357.0')
for rel in ['Include/vulkan/vulkan.h','Lib/vulkan-1.lib','Bin/glslc.exe']:assert (sdk/rel).is_file(),rel
env['VULKAN_SDK']=str(sdk);env['PATH']=str(sdk/'Bin')+os.pathsep+env['PATH']
print('checked recursive scratch target',str(target.resolve()),'actual existing SDK',str(sdk),flush=True)
args=['cmake','-DHYLE_SOURCE_DIR='+str(root),'-DHYLE_SMOKE_ROOT='+str(folder),'-DHYLE_SMOKE_GENERATOR=Ninja','-P','cmake/HyleCiComponentContract.cmake'];log=folder/'run.log';start=time.monotonic()
with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
record={'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log),'sdk':str(sdk),'scope':'original component contract; same tool/input, inherited installedVulkanSDK, originalFAIL/root1 preserved, fourjobsmax'}
(folder/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record),flush=True)
if r.returncode:
 with log.open('rb') as f:
  f.seek(max(0,log.stat().st_size-3000));print(f.read().decode('utf-8',errors='replace'),flush=True)
raise SystemExit(r.returncode)
