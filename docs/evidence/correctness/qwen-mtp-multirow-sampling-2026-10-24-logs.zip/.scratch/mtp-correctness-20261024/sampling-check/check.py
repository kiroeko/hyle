from pathlib import Path
import importlib.util,json,os,sys
O=Path(__file__).resolve().parent;R=O.parents[2]
spec=importlib.util.spec_from_file_location('prefix_state_local_build',O.parent/'state-check/check.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);b=a.b
def build(backend):
 folder=O/backend;source=R/'tests/graph_route_cpu/qwen_sampling_graph_test.cc';old=b.read(R/'.scratch/dense-linear-f32-20261024/test-ggml/identity.json')['command'];native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':old[0],'CMAKE_CXX_COMPILER':old[0],'CMAKE_GENERATOR':'Ninja'},backends=());flags=[];skip=False
 for arg in old:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd'))or arg.lower().endswith('.cc'):continue
  flags.append(arg)
 if backend=='cuda':flags.append('/DHYLE_TEST_QWEN_SAMPLING_CUDA=1')
 obj=folder/'test.obj';snapshot=[b.identity(p)for p in [source,R/'engine/models/qwen35/sampling_graph.h',R/'engine/models/qwen35/mtp_acceptance.h',R/'engine/models/qwen35/session_state.h']]
 a.execute([*flags,'/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(folder/'test.pdb')],native.env,folder/'compile',180)
 for x in snapshot:b.require(x)
 command=[];original=R/'.scratch/dense-linear-f32-20261024/link-plan.json'
 for arg in b.read(original)['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))or Path(arg).name in('test-ggml.obj','test-cublas.obj','test-infer.obj'):continue
  if Path(arg).name=='graph--executable.obj':arg=str(R/'.scratch/graph-system-constant-lease-20261024/executable/executable.obj')
  command.append(arg)
 image=folder/'sampling.exe';command +=[str(obj),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 a.execute(command,native.env,folder/'link',120);ready=b.read(R/'.scratch/dense-linear-f32-20261024/ready.json')
 runtime=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll';staged=folder/runtime.name
 if not staged.exists():os.link(runtime,staged)
 if b.identity(staged)['sha256']!='6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f':raise ValueError('Wrong CPU runtime')
 b.save(folder/'ready.json',dict(image=b.identity(image),PATH=str(folder)+os.pathsep+ready['PATH'],sources=snapshot,closure=b.identity(original),SDK_builds=0,HTTP=0))
def run(backend):
 folder=O/backend;ready=b.read(folder/'ready.json');b.require(ready['image']);a.execute([ready['image']['path'],'--gtest_filter=QwenSamplingGraph.MultiRowPrefix*','--gtest_output=json:'+str(folder/'tests.json')],dict(os.environ,PATH=ready['PATH']),folder/'run',120);print((folder/'run/stdout.log').read_text(encoding='utf8',errors='replace')[-6000:])
if __name__=='__main__':
 action,backend=sys.argv[1:3]
 if action in('build','all'):build(backend)
 if action in('run','all'):run(backend)
