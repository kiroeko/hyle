$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$grRoot = 'C:/hyle-scratch/r3-cpu-20260916'
$grSource = 'C:/public/project-hyle/hyle'
$grBuild = "$grRoot/w1-source-shared"
$grLogs = "$grRoot/graph-replay-w1"
function Invoke-GraphCheck([string]$Name, [scriptblock]$Action) {
  & $Action *> "$grLogs/$Name.log"
  if ($LASTEXITCODE -ne 0) {
    Get-Content "$grLogs/$Name.log" -Tail 60
    throw "Graph shared delivery failed: $Name"
  }
}
Invoke-GraphCheck shared-configure {
  cmake -S "$grRoot/consumer" -B $grBuild -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_BUILD_TESTS=OFF -DHYLE_INSTALL=ON -DHYLE_WERROR=ON -DHYLE_COMPUTE_ONEDNN=AUTO -DHYLE_COMPUTE_CUDA=OFF "-DHYLE_SOURCE_DIR=$grSource" "-DHYLE_SAMPLE_SOURCE_ROOT=$grSource"
}
Invoke-GraphCheck shared-build { cmake --build $grBuild --parallel 2 }
$grStage = [IO.Path]::GetFullPath("$grRoot/graph-replay-w1-sdk-shared")
$grSdk = [IO.Path]::GetFullPath("$grRoot/graph-replay-w1-sdk-shared-relocated")
$grBoundary = [IO.Path]::GetFullPath($grRoot).TrimEnd('\') + '\'
if (-not $grStage.StartsWith($grBoundary,[StringComparison]::OrdinalIgnoreCase) -or -not $grSdk.StartsWith($grBoundary,[StringComparison]::OrdinalIgnoreCase)) { throw 'SDK move escaped the validation root' }
if ((Test-Path -LiteralPath $grStage) -or (Test-Path -LiteralPath $grSdk)) { throw 'Fresh SDK paths already exist' }
Invoke-GraphCheck shared-install { cmake --install $grBuild --prefix $grStage }
Move-Item -LiteralPath $grStage -Destination $grSdk
$grConsumer = "$grRoot/graph-replay-w1-consume-shared"
Invoke-GraphCheck shared-consumer-configure {
  cmake -S "$grRoot/consumer" -B $grConsumer -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$grSdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$grSource"
}
Invoke-GraphCheck shared-consumer-build { cmake --build $grConsumer --parallel 2 --target r3_consume_graph r3_consume_cpu_executor }
$grDllReceipt = foreach ($grDll in Get-ChildItem -LiteralPath "$grSdk/bin" -Filter '*.dll' -File) {
  Copy-Item -LiteralPath $grDll.FullName -Destination $grConsumer
  [ordered]@{Source=$grDll.FullName; Destination=(Join-Path $grConsumer $grDll.Name); Sha256=(Get-FileHash -LiteralPath $grDll.FullName -Algorithm SHA256).Hash}
}
$grDllReceipt | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$grLogs/shared-dll-staging.json" -Encoding utf8
Invoke-GraphCheck shared-consumer-tests { ctest --test-dir $grConsumer --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -R '^r3_consume_(graph|cpu_executor)$' }
Copy-Item -LiteralPath "$grConsumer/Testing/Temporary/LastTest.log" -Destination "$grLogs/shared-last-test.log"
Copy-Item -LiteralPath "$grBuild/CMakeCache.txt" -Destination "$grLogs/shared-CMakeCache.txt"
Get-Content "$grLogs/shared-consumer-tests.log" -Tail 12
