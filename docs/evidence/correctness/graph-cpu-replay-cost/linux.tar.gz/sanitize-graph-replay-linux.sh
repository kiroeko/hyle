#!/usr/bin/env bash
set -euo pipefail
gr_root=/root/hyle-validation/r3-cpu-20260916
gr_source="$gr_root/source-79e96ceb"
gr_logs="$gr_root/logs-graph-replay-1a3a8d0e"
gr_build="$gr_root/source-shared"
cd "$gr_source"
for kind in asan ubsan tsan; do
  mkdir -p "$gr_logs/$kind"
  bash scripts/hyle-unix.sh cmake -S "$gr_root/consumer" -B "$gr_build" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release -DHYLE_WERROR=ON \
    "-DHYLE_SOURCE_DIR=$gr_source" "-DHYLE_SAMPLE_SOURCE_ROOT=$gr_source" \
    -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_COMPUTE_ONEDNN=AUTO \
    -DHYLE_COMPUTE_CUDA=OFF -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF \
    -DHYLE_INSTALL=OFF "-DHYLE_SANITIZER=$kind" \
    >"$gr_logs/$kind/configure.log" 2>&1 || {
      tail -n 55 "$gr_logs/$kind/configure.log"; exit 1;
    }
  cmake --build "$gr_build" --parallel 2 --target hyle_graph_test hyle_graph_executable_test \
    hyle_graph_route_cpu_test hyle_graph_route_cpu_cpu_executor_test hyle_graph_provider_onednn_test \
    >"$gr_logs/$kind/build.log" 2>&1 || {
      tail -n 65 "$gr_logs/$kind/build.log"; exit 1;
    }
  command=(ctest --test-dir "$gr_build" --output-on-failure --no-tests=error --timeout 120
    -R '^hyle_graph_(test|executable_test)$|^hyle_graph_(provider_onednn|route_cpu)_(test|cpu_executor_test)$')
  if [ "$kind" = tsan ]; then command=(setarch "$(uname -m)" -R "${command[@]}"); fi
  "${command[@]}" >"$gr_logs/$kind/tests.log" 2>&1 || {
    tail -n 85 "$gr_logs/$kind/tests.log"; exit 1;
  }
  cp "$gr_build/CMakeCache.txt" "$gr_logs/$kind/CMakeCache.txt"
  cp "$gr_build/Testing/Temporary/LastTest.log" "$gr_logs/$kind/last-test.log"
  tail -n 14 "$gr_logs/$kind/tests.log"
done
