#!/usr/bin/env bash
set -euo pipefail
gr_root=$1
gr_platform=$2
gr_cmake=$3
export PATH="$(dirname "$gr_cmake"):$PATH"
case "$gr_root" in
  /root/hyle-validation/r3-cpu-20260916|/Users/kiro/hyle-validation/r3-cpu-20260916) ;;
  *) exit 2 ;;
esac
gr_source="$gr_root/source-79e96ceb"
gr_logs="$gr_root/logs-graph-replay-1a3a8d0e"
gr_build="$gr_root/source-shared"
mkdir -p "$gr_logs"
cd "$gr_source"
common=(-G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_WERROR=ON
  -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_ONEDNN=AUTO
  -DHYLE_BUILD_BENCH=OFF -DHYLE_SANITIZER=off)
consumer_common=(-G Ninja -DCMAKE_BUILD_TYPE=Release)
if [ "$gr_platform" != linux ]; then
  common+=(-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4)
  consumer_common+=(-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4)
fi
run() {
  local log=$1
  shift
  if ! "$@" >"$gr_logs/$log" 2>&1; then
    tail -n 65 "$gr_logs/$log"
    return 1
  fi
}
cmake_run() { bash scripts/hyle-unix.sh "$gr_cmake" "$@"; }
targets=(hyle_graph_test hyle_graph_executable_test hyle_graph_route_cpu_test
  hyle_graph_route_cpu_cpu_executor_test r3_consume_graph r3_consume_cpu_executor)
if [ "$gr_platform" = linux ]; then targets+=(hyle_graph_provider_onednn_test); fi
run source-configure.log cmake_run -S "$gr_root/consumer" -B "$gr_build" "${common[@]}" \
  -DHYLE_STATIC=OFF -DBUILD_SHARED_LIBS=ON -DHYLE_BUILD_TESTS=ON -DHYLE_INSTALL=OFF \
  "-DHYLE_SOURCE_DIR=$gr_source" "-DHYLE_SAMPLE_SOURCE_ROOT=$gr_source"
run source-build.log "$gr_cmake" --build "$gr_build" --parallel 2 --target "${targets[@]}"
run source-tests.log ctest --test-dir "$gr_build" --output-on-failure --no-tests=error --timeout 120 \
  -R '^hyle_graph_(test|executable_test)$|^hyle_graph_(provider_onednn|route_cpu)_(test|cpu_executor_test)$|^r3_consume_(graph|cpu_executor)$'
cp "$gr_build/Testing/Temporary/LastTest.log" "$gr_logs/source-last-test.log"
cp "$gr_build/CMakeCache.txt" "$gr_logs/source-CMakeCache.txt"
tail -n 12 "$gr_logs/source-tests.log"
for linkage in shared static; do
  gr_stage="$gr_root/graph-replay-sdk-$linkage"
  gr_sdk="$gr_root/graph-replay-sdk-$linkage-relocated"
  test ! -e "$gr_stage"
  test ! -e "$gr_sdk"
  gr_static=OFF
  gr_shared=ON
  if [ "$linkage" = static ]; then gr_static=ON; gr_shared=OFF; fi
  run "$linkage-configure.log" cmake_run -S "$gr_root/consumer" -B "$gr_build" "${common[@]}" \
    "-DHYLE_SOURCE_DIR=$gr_source" "-DHYLE_SAMPLE_SOURCE_ROOT=$gr_source" \
    "-DHYLE_STATIC=$gr_static" "-DBUILD_SHARED_LIBS=$gr_shared" -DHYLE_BUILD_TESTS=OFF -DHYLE_INSTALL=ON
  run "$linkage-build.log" "$gr_cmake" --build "$gr_build" --parallel 2
  run "$linkage-install.log" "$gr_cmake" --install "$gr_build" --prefix "$gr_stage"
  mv "$gr_stage" "$gr_sdk"
  gr_consumer="$gr_root/graph-replay-consume-$linkage"
  run "$linkage-consumer-configure.log" cmake_run -S "$gr_root/consumer" -B "$gr_consumer" \
    "${consumer_common[@]}" "-DCMAKE_PREFIX_PATH=$gr_sdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$gr_source"
  run "$linkage-consumer-build.log" "$gr_cmake" --build "$gr_consumer" --parallel 2 --target r3_consume_graph r3_consume_cpu_executor
  run "$linkage-consumer-tests.log" ctest --test-dir "$gr_consumer" --output-on-failure --no-tests=error --timeout 120 \
    -R '^r3_consume_(graph|cpu_executor)$'
  cp "$gr_consumer/Testing/Temporary/LastTest.log" "$gr_logs/$linkage-last-test.log"
  cp "$gr_build/CMakeCache.txt" "$gr_logs/$linkage-CMakeCache.txt"
  tail -n 10 "$gr_logs/$linkage-consumer-tests.log"
done
printf 'Graph replay %s source/shared/static verification completed\n' "$gr_platform"
