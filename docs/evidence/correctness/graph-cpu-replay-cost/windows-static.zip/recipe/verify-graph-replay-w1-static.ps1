$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$grRoot = 'C:/hyle-scratch/r3-cpu-20260916'
$grSource = "$grRoot/candidate-7fa6dc0a"
$grBuild = "$grRoot/p1-graph-v3-build"
$grLogs = "$grRoot/graph-replay-w1"
$grCache = Get-Content -LiteralPath "$grBuild/CMakeCache.txt" -Raw
foreach ($grRequired in @('(?m)^HYLE_STATIC:BOOL=ON\r?$','(?m)^HYLE_BUILD_TESTS:BOOL=OFF\r?$','(?m)^HYLE_INSTALL:BOOL=ON\r?$')) {
  if ($grCache -notmatch $grRequired) { throw "Frozen static build contract mismatch: $grRequired" }
}
function Invoke-GraphCheck([string]$Name, [scriptblock]$Action) {
  & $Action *> "$grLogs/$Name.log"
  if ($LASTEXITCODE -ne 0) {
    Get-Content "$grLogs/$Name.log" -Tail 65
    throw "Graph static delivery failed: $Name"
  }
}
$grStage = [IO.Path]::GetFullPath("$grRoot/graph-replay-w1-sdk-static")
$grSdk = [IO.Path]::GetFullPath("$grRoot/graph-replay-w1-sdk-static-relocated")
$grBoundary = [IO.Path]::GetFullPath($grRoot).TrimEnd('\') + '\'
if (-not $grStage.StartsWith($grBoundary,[StringComparison]::OrdinalIgnoreCase) -or -not $grSdk.StartsWith($grBoundary,[StringComparison]::OrdinalIgnoreCase)) { throw 'SDK move escaped the validation root' }
if ((Test-Path -LiteralPath $grStage) -or (Test-Path -LiteralPath $grSdk)) { throw 'Fresh SDK paths already exist' }
Invoke-GraphCheck static-install { cmake --install $grBuild --prefix $grStage }
Move-Item -LiteralPath $grStage -Destination $grSdk
$grConsumer = "$grRoot/graph-replay-w1-consume-static"
Invoke-GraphCheck static-consumer-configure {
  cmake -S "$grRoot/consumer" -B $grConsumer -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$grSdk" "-DHYLE_SAMPLE_SOURCE_ROOT=$grSource"
}
Invoke-GraphCheck static-consumer-build { cmake --build $grConsumer --parallel 2 --target r3_consume_graph r3_consume_cpu_executor }
if (Test-Path -LiteralPath "$grSdk/bin") {
  $grDllReceipt = foreach ($grDll in Get-ChildItem -LiteralPath "$grSdk/bin" -Filter '*.dll' -File) {
    Copy-Item -LiteralPath $grDll.FullName -Destination $grConsumer
    [ordered]@{Source=$grDll.FullName; Destination=(Join-Path $grConsumer $grDll.Name); Sha256=(Get-FileHash -LiteralPath $grDll.FullName -Algorithm SHA256).Hash}
  }
  @($grDllReceipt) | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$grLogs/static-dll-staging.json" -Encoding utf8
}
$grCrtReceipt = foreach ($grDll in Get-ChildItem -LiteralPath "$grBuild/bin" -Filter '*.dll' -File) {
  Copy-Item -LiteralPath $grDll.FullName -Destination $grConsumer
  [ordered]@{Source=$grDll.FullName; Destination=(Join-Path $grConsumer $grDll.Name); Sha256=(Get-FileHash -LiteralPath $grDll.FullName -Algorithm SHA256).Hash}
}
@($grCrtReceipt) | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$grLogs/static-crt-staging.json" -Encoding utf8
Invoke-GraphCheck static-consumer-tests { ctest --test-dir $grConsumer --interactive-debug-mode 0 --output-on-failure --no-tests=error --timeout 120 -R '^r3_consume_(graph|cpu_executor)$' }
Copy-Item -LiteralPath "$grConsumer/Testing/Temporary/LastTest.log" -Destination "$grLogs/static-last-test.log"
Copy-Item -LiteralPath "$grBuild/CMakeCache.txt" -Destination "$grLogs/static-CMakeCache.txt"
Get-Content "$grLogs/static-consumer-tests.log" -Tail 12
