from pathlib import Path
import datetime, hashlib, json, subprocess, sys, xml.etree.ElementTree as ET, zipfile

root = Path.cwd()
base = root / '.scratch/inference-gaps/g06'
mode, attempt = sys.argv[1:3]
assert mode in ('asan', 'ubsan', 'tsan')
product = '0a29d119426b2975d48c238c37a2994675e0ba9f'
qualified = base / f'final-host-{mode}-{attempt}'
out = root / f'evidence/correctness/inference-g06-final-host-{mode}'
assert not out.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', product, 'HEAD', '--', 'include', 'src', 'cmake', 'CMakeLists.txt'], text=True).strip()
record = json.loads((qualified / 'result.json').read_text())
assert record['state'] == 'TERMINAL_PASS' and record['mode'] == mode
assert record['product_candidate'] == product
assert len(record['stages']) == 11 and all(s['exit_code'] == 0 for s in record['stages'])
assert record['reused_native_current_inputs']['derived_verified'] == 242
assert record['reused_native_current_inputs']['canonical_verified'] == 5
for item in record['inputs']:
    if item['path'].startswith(('include/', 'src/', 'cmake/', 'tests/')) or item['path'] == 'CMakeLists.txt':
        assert hashlib.sha256((root / item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']
tests = {}
for name, count in [('tests.xml', 19), ('core.xml', 263)]:
    tree = ET.parse(qualified / name).getroot()
    assert int(tree.attrib['tests']) == count
    assert all(tree.attrib.get(k, '0') == '0' for k in ['failures', 'errors', 'disabled'])
    tests[name] = dict(tree.attrib)
risk_modes = {}
for name in ['five-risk-modes', 'g06_risk_plain', 'g06_risk_encoded']:
    log = (qualified / (name + '.log')).read_text()
    assert log.count('PASS') == 5
    risk_modes[name] = 5
for name in ['g06_capture_public', 'g06_capture_hybrid', 'g06_capture_pending']:
    assert 'PASS' in (qualified / (name + '.log')).read_text()
path = '/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/' + qualified.name + '/result.json'
check = "from pathlib import Path;import hashlib,json;r=json.loads(Path(" + repr(path) + ").read_text());a=list(r['binaries'].values());a.append(r['reused_ggml_cuda']);assert all(hashlib.sha256(Path(i.get('path',i.get('archive'))).read_bytes()).hexdigest()==i['sha256'] for i in a);print(len(a),sum(Path(i.get('path',i.get('archive'))).stat().st_size for i in a))"
recheck = subprocess.check_output(['wsl', '-e', 'python3', '-c', check], text=True).strip()
folders = [qualified]
failed_attempts = []
if mode == 'asan':
    prior = base / 'final-host-asan-1'
    old = json.loads((prior / 'result.json').read_text())
    assert old['state'] == 'TERMINAL_FAIL' and old['stages'][-1]['stage'] == 'compile'
    folders.insert(0, prior)
    failed_attempts.append({'attempt': '1', 'state': old['state'], 'stages': old['stages'],
        'cause': 'New private validation targets omitted explicit hyle_graph_batch linkage; product and two affected FI CUDA TUs compiled, link failed before tests. Private harness link corrected only; attempt2 reused same configuration/tree and compiled zero CUDA TUs.'})
out.mkdir(parents=True)
with zipfile.ZipFile(out / 'raw.zip', 'x', zipfile.ZIP_DEFLATED) as z:
    for folder in folders:
        for file in sorted(folder.iterdir()):
            if file.is_file():
                z.write(file, folder.name + '/' + file.name)
    z.write(Path(__file__), 'sealer.py')
    z.write(base / 'launch_final_host_san.py', 'launcher.py')
receipt = {
    'state': 'PASS_HOST_' + mode.upper() + '_FACET_ONLY', 'product_candidate': product,
    'source_snapshot': 'b8b8ca9265c6e89c9fe94cbac6c9c922f0b2f3e4',
    'record': 'docs/implementation/tasks/compute/inference-g06-metadata-decode.md',
    'identity': record['identity'], 'tests': tests, 'risk_modes': risk_modes,
    'public_capture_consumers': ['g06_capture_public', 'g06_capture_hybrid', 'g06_capture_pending'],
    'artifact_recheck_count_bytes': recheck, 'stages': record['stages'],
    'cumulative_seconds': record['cumulative_seconds'], 'failed_attempts': failed_attempts,
    'instrumentation': 'All affected compute, graph, graph_batch, batch, joint route, CPU provider and FI native host TUs verified with the original per-mode sanitizer; exact checked commands are archived. Only the unchanged original ggml CUDA native archive is imported after 242 derived and5 canonical inputs plus exact archive SHA verification.',
    'reused_native_current_inputs': record['reused_native_current_inputs'],
    'environment': record['environment'], 'previous_f5_sanitizer_scope': record['previous_f5_sanitizer_scope'],
    'limits': record['limits'] + ['Not device/shader instrumentation, shipping SDK/header/P1 or final G06 acceptance. Original failures/cost retained; cumulative stage cost excludes unmeasured investigation/edit/launch cost.'],
    'raw_sha256': hashlib.sha256((out / 'raw.zip').read_bytes()).hexdigest(),
    'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()
}
(out / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'state': receipt['state'], 'tests': 282, 'risk_modes': 15, 'artifacts': recheck, 'receipt': str(out.relative_to(root))}))
