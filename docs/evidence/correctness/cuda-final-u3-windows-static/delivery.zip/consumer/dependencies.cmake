find_package(CUDAToolkit 13.3 REQUIRED)
find_package(Threads REQUIRED)
set(gtest_force_shared_crt ON CACHE BOOL "" FORCE)
set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
set(BUILD_GMOCK OFF CACHE BOOL "" FORCE)
add_subdirectory("${U3_GTEST_SOURCE}" fixture-gtest EXCLUDE_FROM_ALL)
# Original ggml reference library and headers are standalone fixture assets.
# HYLE implementation and all public headers come only from the relocated SDK.
foreach(_name IN ITEMS ggml-base ggml ggml-cuda)
  add_library(u3_reference_${_name} STATIC IMPORTED)
  set_target_properties(u3_reference_${_name} PROPERTIES
    IMPORTED_LOCATION "${U3_REFERENCE_DIR}/lib/${U3_LIB_PREFIX}${_name}${U3_LIB_SUFFIX}")
endforeach()
set_property(TARGET u3_reference_ggml-cuda PROPERTY INTERFACE_LINK_LIBRARIES
  "u3_reference_ggml;u3_reference_ggml-base;CUDA::cudart;CUDA::cuda_driver;CUDA::cublas;Threads::Threads;${CMAKE_DL_LIBS}")
