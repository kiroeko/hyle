add_executable(u3_direct ${U3_CONSUMER_SOURCE}/tests/compute_route_cuda/d5_qwen38_official_test.cc
  ${U3_CONSUMER_SOURCE}/tests/compute_route_cuda/context_test.cc ${U3_CONSUMER_SOURCE}/tests/compute_route_cuda/d5_qwen_gguf_vocabulary_test.cc
  ${U3_CONSUMER_SOURCE}/tests/compute_route_cuda/d5_qwen35_execution_test.cc)
add_executable(u3_graph ${U3_CONSUMER_SOURCE}/tests/graph_route_cuda/d5_qwen38_official_test.cc
  ${U3_CONSUMER_SOURCE}/tests/graph_route_cuda/artifact_test.cc ${U3_CONSUMER_SOURCE}/tests/graph_route_cuda/d5_qwen_gguf_vocabulary_test.cc)
add_executable(u3_admission ${U3_CONSUMER_SOURCE}/tests/compute_route_cuda/d5_qwen35_profile_test.cc)
add_executable(u3_graph_local ${U3_CONSUMER_SOURCE}/tests/graph_route_cuda/d5_qwen35_profile_test.cc
  ${U3_CONSUMER_SOURCE}/tests/graph_route_cuda/graph_test.cc)
add_custom_target(u3_delivery DEPENDS u3_direct u3_graph u3_admission u3_graph_local)
enable_testing()
foreach(_target IN ITEMS u3_direct u3_graph u3_admission u3_graph_local)
  target_compile_features(${_target} PRIVATE cxx_std_23)
  target_compile_options(${_target} PRIVATE $<$<CXX_COMPILER_ID:MSVC>:/utf-8>)
  target_compile_definitions(${_target} PRIVATE HYLE_GGML_CUDA_IQ1_EXTENSIONS=1)
  target_include_directories(${_target} PRIVATE "${U3_REFERENCE_DIR}/include" "${U3_REFERENCE_DIR}/src")
  target_link_libraries(${_target} PRIVATE hyle::compute hyle::graph hyle::simd GTest::gtest_main u3_reference_ggml-cuda)
  hyle_stage_runtime_dependencies(${_target})
  add_test(NAME ${_target} COMMAND ${_target} "--gtest_filter=${U3_GTEST_FILTER}")
  set_tests_properties(${_target} PROPERTIES TIMEOUT 1200)
endforeach()

add_executable(u3_q3_forensics ${U3_CONSUMER_SOURCE}/q3_forensics.cc)
target_compile_features(u3_q3_forensics PRIVATE cxx_std_23)
target_compile_options(u3_q3_forensics PRIVATE $<$<CXX_COMPILER_ID:MSVC>:/utf-8>)
target_compile_definitions(u3_q3_forensics PRIVATE HYLE_GGML_CUDA_IQ1_EXTENSIONS=1)
target_include_directories(u3_q3_forensics PRIVATE "${U3_REFERENCE_DIR}/include" "${U3_REFERENCE_DIR}/src")
target_link_libraries(u3_q3_forensics PRIVATE hyle::compute hyle::simd GTest::gtest u3_reference_ggml-cuda)
hyle_stage_runtime_dependencies(u3_q3_forensics)
