from pathlib import Path
import base64, hashlib, json, subprocess, sys, time
W=Path(__file__).resolve().parent
R=W.parents[1]
M='/Users/kiro/hyle-scratch/compute-unified/inference-copy-public-retention-20261026'
name='include/hyle/compute/batch_transfer.h'
raw=(R/name).read_bytes()
if sys.argv[1:] != ['run']:
    print('Explicit run only: preserve the failure, reuse the successful device TU, continue the fixed header.')
    raise SystemExit(0)
code=f'''from pathlib import Path
import base64,hashlib,importlib.util,json,sys
w=Path({M!r})
assert json.loads((w/'compile-device/process.json').read_text())['exit']==0
assert 'batch_transfer.h' not in (w/'device.o.d').read_text()
initial=json.loads((w/'source-freeze.json').read_text())
name={name!r};raw=base64.b64decode({base64.b64encode(raw).decode()!r})
old=w/'source'/name
(w/'source-freeze-initial.json').write_text(json.dumps(initial,indent=2))
(w/'failed-batch_transfer.h').write_bytes(old.read_bytes())
old.write_bytes(raw)
for row in initial:
 if row['path']==name:row.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(w/'source-freeze.json').write_text(json.dumps(initial,indent=2))
for row in initial:
 assert hashlib.sha256((w/'source'/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
spec=importlib.util.spec_from_file_location('runner',w/'mac-run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=json.loads((w/'plan.json').read_text());results=[]
for job in p['jobs'][1:]:
 cmd=job['command'][:];tag=job['tag']
 if tag=='compile-batch_transfer':
  tag+='2';cmd=[x.replace(str(w/'batch_transfer.o'),str(w/'batch_transfer2.o')) for x in cmd]
 if tag=='link':cmd=[x.replace(str(w/'batch_transfer.o'),str(w/'batch_transfer2.o')) for x in cmd]
 results.append(dict(tag=tag,process=m.execute(tag,cmd,job['timeout'])))
image=w/'state-transfer'
m.save(w/'actual-dependencies.json',{{n:(w/(n+'.o.d')).read_text() for n in ('device','batch_transfer2','apple_copy_program','test')}})
m.save(w/'ready.json',dict(image=dict(path=str(image),bytes=image.stat().st_size,sha256=hashlib.sha256(image.read_bytes()).hexdigest()),processes=results,compiled_TUs=4,reused_successful_device=True,SDK_builds=0))
m.run()
'''
cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -']
start=time.perf_counter()
with (W/'mac/continue.stdout.log').open('wb') as out,(W/'mac/continue.stderr.log').open('wb') as err:
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=out,stderr=err)
    (W/'mac/continue.running.json').write_text(json.dumps(dict(pid=proc.pid,command=cmd)))
    proc.communicate(code.encode(),timeout=360)
result=dict(pid=proc.pid,exit=proc.returncode,seconds=time.perf_counter()-start,header_sha256=hashlib.sha256(raw).hexdigest())
(W/'mac/continue.process.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
print((W/'mac/continue.stdout.log').read_text(),end='')
print((W/'mac/continue.stderr.log').read_text(),end='',file=sys.stderr)
raise SystemExit(proc.returncode)
