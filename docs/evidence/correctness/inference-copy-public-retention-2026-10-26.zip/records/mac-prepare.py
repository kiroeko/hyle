"""After final source freeze: mac-prepare.py prepare. Default does nothing.

Local preparation only: four canonical TUs and their current Hyle headers in a
small zip, exact retained Apple commands. Never SSH, sync, compile or download.
Root can unpack mac/source.zip in the one fixed remote directory and run
`python3 mac-run.py all` there after authorizing execution.
"""
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-transfer-retirement-20261026/mac/records'
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-copy-public-retention-20261026'
OLD = '/Users/kiro/hyle-scratch/compute-unified/inference-transfer-retirement-20261026'


def prepare():
    out = W/'mac'
    out.mkdir(exist_ok=False)
    def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
    def save(path,data): path.write_text(json.dumps(data,indent=2)+'\n')
    jobs = []
    specs = [('device','src/compute/device.cc','compile-completion'),
        ('batch_transfer','src/compute/batch_transfer.cc','compile-batch_transfer'),
        ('apple_copy_program','src/compute_route_apple/apple_copy_program.cc','compile-apple_copy_program'),
        ('test','tests/tools/inference_state_transfer_test.cc','compile-test2')]
    for tag,source,recipe in specs:
        original = read(B/recipe/'command.json')['command']
        command = [x.replace(OLD+'/source',REMOTE+'/source') for x in original]
        command[command.index('-c')+1] = REMOTE+'/source/'+source
        command[command.index('-o')+1] = REMOTE+'/'+tag+'.o'
        command[command.index('-MF')+1] = REMOTE+'/'+tag+'.o.d'
        jobs.append(dict(tag='compile-'+tag,command=command,timeout=120,source=source))
    link = read(B/'link/command.json')['command']
    remove = {OLD+'/'+x for x in ('batch_transfer.o','apple_copy_program.o','test2.o')}
    assert all(link.count(x) == 1 for x in remove)
    assert not any('/device.o' in x or 'compute--device' in x for x in link)
    link = [x for x in link if x not in remove]
    assert link.count(OLD+'/completion.o') == 1
    link[link.index('-o')+1] = REMOTE+'/state-transfer'
    link = [x.replace('-Wl,-map,'+OLD+'/image.map','-Wl,-map,'+REMOTE+'/image.map') for x in link]
    link[1:1] = [REMOTE+'/'+name+'.o' for name,_,_ in specs]
    jobs.append(dict(tag='link',command=link,timeout=120))
    # Only canonical reachable Hyle files; vendor/system headers stay in cache.
    roots = [R,R/'include',R/'src/compute',R/'src/compute_route_apple']
    todo = [R/source for _,source,_ in specs]
    files = {}
    while todo:
        source = todo.pop().resolve()
        name = source.relative_to(R).as_posix()
        if name in files: continue
        assert not name.startswith('.scratch/')
        raw = source.read_bytes()
        files[name] = raw
        for inc in re.findall(r'^\s*#\s*include\s*["<]([^">\r\n]+)[">]',raw.decode('utf-8-sig'),re.M):
            for base in [source.parent,*roots]:
                child = (base/inc).resolve()
                if child.is_file() and child.is_relative_to(R) and not child.is_relative_to(R/'.scratch'):
                    todo.append(child)
                    break
    frozen = [dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in sorted(files.items())]
    plan = dict(remote=REMOTE,jobs=jobs,environment=read(B/'plan.json')['environment'],
        previous_link_recipe=str(B/'link/command.json'),reused_completion=OLD+'/completion.o',
        removed_old_direct_objects=sorted(remove),compiled_TUs=4,SDK_builds=0,models=0,
        scope='Current device/common copy/Apple copy/canonical transfer test; exact previous CPU+Apple closure.')
    save(out/'plan.json',plan)
    save(out/'source-freeze.json',frozen)
    with zipfile.ZipFile(out/'source.zip','x',zipfile.ZIP_DEFLATED) as archive:
        for name,raw in sorted(files.items()): archive.writestr('source/'+name,raw)
        archive.write(out/'plan.json','plan.json')
        archive.write(out/'source-freeze.json','source-freeze.json')
        archive.write(W/'mac-run.py','mac-run.py')
    print(json.dumps(dict(status='LOCAL_PREPARATION_ONLY',files=len(files),zip_bytes=(out/'source.zip').stat().st_size,
        remote=REMOTE,compiled_TUs=4,SSH=False,sync=False)),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['prepare']:
        prepare()
    else:
        print(__doc__)
