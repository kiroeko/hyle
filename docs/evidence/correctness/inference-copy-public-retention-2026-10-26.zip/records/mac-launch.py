from pathlib import Path
import base64, hashlib, json, subprocess, sys, time

W = Path(__file__).resolve().parent
M = '/Users/kiro/hyle-scratch/compute-unified/inference-copy-public-retention-20261026'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'kiro@172.22.10.198', 'python3 -']

if sys.argv[1:] == ['run']:
    package = (W/'mac/source.zip').read_bytes()
    code = f'''from pathlib import Path
import base64,io,json,subprocess,sys,zipfile
w=Path({M!r})
assert subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
w.mkdir(parents=True,exist_ok=False)
data=base64.b64decode({base64.b64encode(package).decode()!r})
with zipfile.ZipFile(io.BytesIO(data)) as z:
 for member in z.infolist():
  p=(w/member.filename).resolve()
  assert p.is_relative_to(w.resolve()) and not member.is_dir()
  p.parent.mkdir(parents=True,exist_ok=True)
  p.write_bytes(z.read(member))
(w/'hardware.json').write_text(json.dumps(dict(model='Mac16,12',compiler=subprocess.check_output(['/usr/bin/c++','--version'],text=True),disk=subprocess.check_output(['df','-k',str(w)],text=True)),indent=2))
sys.exit(subprocess.call([sys.executable,str(w/'mac-run.py'),'all'],cwd=w))
'''
    start = time.perf_counter()
    with (W/'mac/ssh.stdout.log').open('wb') as out, (W/'mac/ssh.stderr.log').open('wb') as err:
        proc = subprocess.Popen(SSH, stdin=subprocess.PIPE, stdout=out, stderr=err)
        (W/'mac/ssh.running.json').write_text(json.dumps(dict(pid=proc.pid,command=SSH)))
        proc.communicate(code.encode(), timeout=480)
    result = dict(command=SSH,pid=proc.pid,exit=proc.returncode,seconds=time.perf_counter()-start,
        package_bytes=len(package),package_sha256=hashlib.sha256(package).hexdigest())
    (W/'mac/ssh.process.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result), flush=True)
    print((W/'mac/ssh.stdout.log').read_text(),end='')
    print((W/'mac/ssh.stderr.log').read_text(),end='',file=sys.stderr)
    sys.exit(proc.returncode)
else:
    print('Explicit run only. Uses the frozen local package; no retries.')
