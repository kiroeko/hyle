"""Run only the six root-authorized finite processes, stop on first failure.

Device entire TU, CPU transfer faults, CPU/Vulkan closed recovery, then the
unchanged tiny Qwen Vulkan ordinary+MTP and lag-1 byte/lifetime consumers.
No retry, original335, quality/TPS claims, or downloads.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch',W/'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b,R = m.b,m.R


def run():
    ready = b.read(W/'ready.json')
    fixture = R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    work = [('device','test',[],120),
        ('cpu-faults','transfer',['--faults'],60),
        ('cpu-closed','transfer',['--cpu','--closed-recovery'],60),
        ('vulkan-closed','transfer',['--vulkan','--closed-recovery'],60),
        ('qwen-vulkan','case',['--vulkan',str(fixture)],60),
        ('qwen-vulkan-lag1','case',['--vulkan',str(fixture),'--mtp-lag1'],60)]
    manifest = []
    for name,artifact,args,limit in work:
        item = ready['artifacts'][artifact]
        b.exact(item['image'])
        manifest.append(dict(name=name,artifact=artifact,command=[item['image']['path'],*args],
            timeout_seconds=limit,runtime=item['runtime'],image=item['image']))
    b.save(W/'run-manifest.json',dict(ready=b.pin(W/'ready.json'),processes=manifest,
        fixture_manifest=b.pin(fixture/'weights.tsv'),full335=False,performance=False))
    results = []
    for item in manifest:
        env = os.environ.copy()
        env['PATH'] = b.read(item['runtime']['path'])['PATH']
        process = b.helper().execute(item['command'],env,W/'runs'/item['name'],timeout=item['timeout_seconds'])
        results.append(dict(name=item['name'],process=process))
        print('PROCESS',json.dumps(results[-1]),flush=True)
    b.save(W/'run-summary.json',dict(status='SIX_FINITE_PROCESSES_EXIT_ZERO',processes=results,
        full335='NOT_RUN',performance='NOT_MEASURED',quality='NOT_CLAIMED'))
    print('RUN_SUMMARY',json.dumps(b.pin(W/'run-summary.json')),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['run']:
        run()
    else:
        print(__doc__)
