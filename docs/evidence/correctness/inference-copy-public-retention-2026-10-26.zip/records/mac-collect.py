from pathlib import Path
import base64,hashlib,io,json,subprocess,sys,zipfile
W=Path(__file__).resolve().parent
R=W.parents[1]
M='/Users/kiro/hyle-scratch/compute-unified/inference-copy-public-retention-20261026'
code=f'''from pathlib import Path
import base64,hashlib,io,json,zipfile
w=Path({M!r})
lines=[s for s in (w/'image.map').read_text().splitlines() if str(w) in s and any(n in s for n in ('device.o','batch_transfer2.o','apple_copy_program.o','test.o'))]
(w/'map-selection.json').write_text(json.dumps(dict(lines=lines),indent=2))
data=io.BytesIO()
with zipfile.ZipFile(data,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(w.rglob('*')):
  rel=p.relative_to(w)
  if p.is_file() and rel.parts[0]!='source' and (p.suffix in ('.json','.log','.d','.py') or p.name=='failed-batch_transfer.h'):
   z.write(p,str(rel))
raw=data.getvalue();assert len(raw)<1024*1024
print(json.dumps(dict(data=base64.b64encode(raw).decode(),sha256=hashlib.sha256(raw).hexdigest())))
'''
proc=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','kiro@172.22.10.198','python3 -'],input=code,text=True,capture_output=True,timeout=30)
if proc.returncode:raise RuntimeError(proc.stderr)
receipt=json.loads(proc.stdout);raw=base64.b64decode(receipt['data'])
assert hashlib.sha256(raw).hexdigest()==receipt['sha256']
(W/'mac/records.zip').write_bytes(raw)
out=W/'mac/records';out.mkdir(exist_ok=False)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None
    for member in z.infolist():
        path=(out/member.filename).resolve();assert path.is_relative_to(out.resolve())
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(member))
for row in json.loads((out/'source-freeze.json').read_text()):
    assert hashlib.sha256((R/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
print(json.dumps(dict(status='COLLECTED_AND_SOURCE_CHECKED',bytes=len(raw),sha256=receipt['sha256'],files=len(list(out.rglob('*'))))))
