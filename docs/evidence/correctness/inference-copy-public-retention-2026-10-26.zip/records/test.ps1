param([switch]$Delete)
$ErrorActionPreference = 'Stop'
# Default is a read-only identity check; -Delete removes only these exact files.
# Superseded images only; current case/test images and all link inputs remain.
$scope = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch')).TrimEnd('\') + '\'
$targets = @(
  @{ path='.scratch/inference-transfer-retirement-20261026/case/link/host-image-test.exe'; bytes=69550592; sha256='77c126276f2ba1f961a4153ebab7f3f070b7ac8eec62c4e9c78b4bf51a35ddc0' },
  @{ path='.scratch/inference-transfer-retirement-20261026/test/link/completion-test.exe'; bytes=67860992; sha256='79e0efba50abf14b5fac285442e66b488085f51163bbc470d3f5dfc0526db6bb' },
  @{ path='.scratch/inference-transfer-retirement-20261026/transfer/link/state-transfer-test.exe'; bytes=67456000; sha256='a9daf759d0c9791ef6804d968899df0244e70c6eac446750a1da00dc88f3bd3e' }
)
foreach ($row in $targets) {
  $resolved = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot $row.path)).ProviderPath
  if (-not $resolved.StartsWith($scope,[StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes repository scratch' }
  $file = Get-Item -LiteralPath $resolved
  if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $file.Length -ne $row.bytes) { throw 'Target identity mismatch' }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ine $row.sha256) { throw 'Target digest changed' }
}
if (-not $Delete) {
  $targets | ForEach-Object { [pscustomobject]$_ } | Format-Table path,bytes
  Write-Output 'Read-only check completed. No files deleted.'
  return
}
$scriptHash = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
foreach ($row in $targets) { Remove-Item -LiteralPath (Join-Path $PSScriptRoot $row.path) -Force }
$receipt = [ordered]@{
  status='REMOVED_THREE_EXACT_SUPERSEDED_IMAGES'
  command='& .\test.ps1 -Delete'
  executed_script_sha256=$scriptHash
  logical_bytes=204867584
  targets=$targets
  current_case_present=(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-copy-public-retention-20261026/case/link/host-image-test.exe'))
  current_focused_present=(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-copy-public-retention-20261026/test/link/device-test.exe'))
  current_transfer_present=(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-copy-public-retention-20261026/transfer/link/state-transfer-test.exe'))
}
$receipt | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-copy-public-retention-20261026/cleanup-result.json') -Encoding UTF8
$receipt | ConvertTo-Json -Depth 4
