"""In fixed Mac directory after source freeze/sync: build, run, or all.

Default does nothing. Four TUs plus one link, two bounded small transfer runs.
No SDK, model, network, implicit retry, or hidden source synchronization.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
W = Path('/Users/kiro/hyle-scratch/compute-unified/inference-copy-public-retention-20261026')


def save(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n')


def execute(tag,command,timeout):
    plan = json.loads((W/'plan.json').read_text())
    out = W/tag
    out.mkdir(exist_ok=False)
    save(out/'command.json',dict(command=command,cwd=str(W),environment=plan['environment']))
    env = os.environ.copy()
    env.update(plan['environment'])
    start = time.perf_counter()
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        proc = subprocess.Popen(command,cwd=W,env=env,stdout=stdout,stderr=stderr)
        save(out/'running.json',dict(pid=proc.pid))
        try:
            code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            code = proc.wait(timeout=5)
    result = dict(pid=proc.pid,exit=code,seconds=time.perf_counter()-start)
    save(out/'process.json',result)
    print(tag,json.dumps(result),flush=True)
    if code: raise RuntimeError(tag+' failed; original output retained')
    return result


def build():
    plan = json.loads((W/'plan.json').read_text())
    assert str(W) == plan['remote']
    for row in json.loads((W/'source-freeze.json').read_text()):
        assert hashlib.sha256((W/'source'/row['path']).read_bytes()).hexdigest() == row['sha256'],row['path']
    results = []
    for job in plan['jobs']:
        results.append(dict(tag=job['tag'],process=execute(job['tag'],job['command'],job['timeout'])))
    image = W/'state-transfer'
    save(W/'actual-dependencies.json',{name:(W/(name+'.o.d')).read_text() for name in ('device','batch_transfer','apple_copy_program','test')})
    save(W/'ready.json',dict(image=dict(path=str(image),bytes=image.stat().st_size,
        sha256=hashlib.sha256(image.read_bytes()).hexdigest()),processes=results,compiled_TUs=4,SDK_builds=0))


def run():
    ready = json.loads((W/'ready.json').read_text())
    image = ready['image']
    assert hashlib.sha256(Path(image['path']).read_bytes()).hexdigest() == image['sha256']
    rows = [execute('run-apple-closed',[image['path'],'--apple','--closed-recovery'],30),
        execute('run-cpu-faults',[image['path'],'--faults'],30)]
    save(W/'summary.json',dict(status='TWO_FINITE_PROCESSES_EXIT_ZERO',processes=rows,
        scope='Small real byte-copy/closed recovery and controlled CPU completion retirement.',
        quality_claim=False,performance_claim=False,SDK_builds=0,HTTP=0))


if __name__ == '__main__':
    if sys.argv[1:] == ['build']:
        build()
    elif sys.argv[1:] == ['run']:
        run()
    elif sys.argv[1:] == ['all']:
        build()
        run()
    else:
        print(__doc__)
