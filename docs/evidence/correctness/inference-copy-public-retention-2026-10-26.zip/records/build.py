"""After root final SOURCE_FROZEN: plan, build. Default does nothing.

Six changed TUs, three images, latest exact closures; no SDK/native/weights/report
or Completion implementation rebuild. No consumer process is launched here.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R/'.scratch/inference-transfer-retirement-20261026'
spec = importlib.util.spec_from_file_location('previous',B/'build.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
b = p.b
SPECS = [('common-copy','src/compute/batch_transfer.cc',B/'recipes/batch-transfer.json'),
    ('vulkan-copy','src/compute_route_vulkan/vulkan_copy_program.cc',B/'recipes/vulkan-copy.json'),
    ('device','src/compute/device.cc',W/'recipes/device.json'),
    ('device-test','tests/compute/device_test.cc',W/'recipes/device-test.json'),
    ('transfer','tests/tools/inference_state_transfer_test.cc',B/'compile3/transfer/command.json'),
    ('model','tests/tools/qwen_host_image_test.cc',B/'compile/model/command.json')]


def plan():
    assert not (W/'plan.json').exists()
    units = [dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),
        command=p.m.command(recipe,R/source,W/'compile'/name)) for name,source,recipe in SPECS]
    frozen = p.m.c.closure([u['source']['path'] for u in units],[r for _,_,r in SPECS])
    b.save(W/'source-freeze.json',frozen)
    baselines = {}
    for name in ('test','transfer','case'):
        inputs = b.read(B/name/'link-inputs.json')
        assert len(inputs) == (134 if name == 'transfer' else 136)
        assert all(Path(x['path']).is_file() for x in inputs)
        entry = B/('compile/completion-test/unit.obj' if name == 'test' else
            'compile3/transfer/unit.obj' if name == 'transfer' else 'compile/model/unit.obj')
        replacements = {'common-copy':B/'compile/common-copy/unit.obj',
            'vulkan-copy':B/'compile/vulkan-copy/unit.obj',
            'device-test' if name == 'test' else 'transfer' if name == 'transfer' else 'model':entry}
        assert all(sum(b.key(x['path']) == b.key(old) for x in inputs) == 1 for old in replacements.values())
        baselines[name] = dict(command=b.pin(B/name/'link/command.json'),inputs=b.pin(B/name/'link-inputs.json'),
            ready=b.pin(B/name/'ready.json'),runtime=b.pin(B/name/'runtime.json'),
            replacements={new:b.pin(old) for new,old in replacements.items()})
    b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT',units=units,baselines=baselines,
        source_freeze=b.pin(W/'source-freeze.json'),unique_TUs=6,images=3,
        appended_archive_override='complete current compute/device.cc OBJ only',
        Completion_weight_report_SDK_native_compiles=0,archive_rewrites=0,native_runs=0))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)


def build(plan_name='plan.json'):
    data = b.read(W/plan_name)
    compile_root = W/data.get('compile_directory','compile')
    assert not compile_root.exists() and not (W/'ready.json').exists()
    frozen = b.read(data['source_freeze']['path'])
    for row in frozen:
        b.exact(row)
    helper = b.helper()
    cl = data['units'][0]['command'][0]
    env = helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    own = {b.key(x['path']):x for x in frozen}
    objects,results = {},[]
    for unit in data['units']:
        out = compile_root/unit['name']
        process = helper.execute(unit['command'],env,out,timeout=180)
        dep = b.read(out/'dependencies.json')['Data']
        actual = [b.pin(q) for q in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            q = Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert b.key(q) in own and row['sha256'] == own[b.key(q)]['sha256'],str(q)
        b.save(out/'actual-dependencies.json',actual)
        objects[unit['name']] = b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],
            process=process,dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:
            b.exact(row)
    artifacts = {}
    for name,baseline in data['baselines'].items():
        replacement = {b.key(old['path']):objects[new] for new,old in baseline['replacements'].items()}
        image = W/name/'link'/('device-test.exe' if name == 'test' else 'state-transfer-test.exe' if name == 'transfer' else 'host-image-test.exe')
        args,count = [],0
        for arg in b.read(baseline['command']['path'])['command']:
            if b.key(arg) in replacement:
                arg = replacement[b.key(arg)]['path']
                count += 1
            elif arg.upper().startswith('/OUT:'):
                arg = '/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'):
                arg = '/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'):
                arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
            args.append(arg)
        assert count == 3
        args.append(objects['device']['path'])
        linked = helper.execute(args,env,image.parent,timeout=120)
        final = [replacement.get(b.key(x['path']),x) for x in b.read(baseline['inputs']['path'])]+[objects['device']]
        assert len(final) == (135 if name == 'transfer' else 137)
        b.save(W/name/'link-inputs.json',final)
        runtime = b.read(baseline['runtime']['path'])
        b.exact(runtime['native'])
        alias = image.parent/Path(runtime['native']['path']).name
        os.link(runtime['native']['path'],alias)
        runtime['native_hardlink'] = b.pin(alias)
        b.save(W/name/'runtime.json',runtime)
        artifact = dict(status='LINKED_NOT_RUN',image=b.pin(image),inputs=b.pin(W/name/'link-inputs.json'),
            runtime=b.pin(W/name/'runtime.json'),link=linked,archive_rewrites=0)
        b.save(W/name/'ready.json',artifact)
        artifacts[name] = artifact
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',plan=b.pin(W/plan_name),compiled=results,
        artifacts=artifacts,Completion_weight_report_SDK_native_compiles=0,native_runs=0))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']:
        plan()
    elif sys.argv[1:] == ['build']:
        build()
    elif sys.argv[1:] == ['build2']:
        build('plan2.json')
    else:
        print(__doc__)
