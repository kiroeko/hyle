from pathlib import Path
import hashlib,json,subprocess,zipfile
W=Path(__file__).resolve().parent
R=W.parents[1]
E=R/'docs/evidence/correctness/inference-copy-public-retention-2026-10-26'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
win=read(W/'final-summary.json');mac=read(W/'mac/records/summary.json')
assert win['Device_pass']==9 and win['native_fail']==0 and len(win['processes'])==6
assert all(x['process']['exit']==0 for x in win['processes'])
assert len(mac['processes'])==2 and all(x['exit']==0 for x in mac['processes'])
for p in (W/'source2-freeze.json', W/'mac/records/source-freeze.json'):
    for row in read(p):
        source=Path(row['path']) if p.parent==W else R/row['path']
        assert digest(source)==row['sha256'],str(source)
assert 'public_copy_retention":true' in (W/'runs/cpu-faults/stdout.log').read_text()
assert 'public_copy_retention":true' in (W/'mac/records/run-cpu-faults/stdout.log').read_text()
sources=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()
product=[x for x in sources if not x.startswith('docs/')]
patch=subprocess.check_output(['git','diff','--binary','--',*product],cwd=R)
out=E.with_suffix('.zip')
assert not out.exists()
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
    z.writestr('records/product.patch',patch)
    z.write(R/'test.ps1','records/test.ps1')
    for p in sorted(W.rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.py','.d','.h'):
            rel=p.relative_to(W)
            if p.name=='failed-batch_transfer.h' or p.suffix!='.h':
                z.write(p,'records/'+rel.as_posix())
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    count=len(z.infolist())
result=dict(status='FINITE_SCOPE_PASS_WITH_PRESERVED_HEADER_COMPILE_FAILURE',date='2026-10-26',
    source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    source_patch='records/product.patch',
    changes=[
        'Public CopyBatchUpdate retirement_count and indexed attach_retention keep source Completion handles and Apple synchronization inside the original factor. Each successful call transfers one existing reference; rejected calls consume none.',
        'All three original copy factors share their own stable source enumeration with internal composition. Actual used producers are deduplicated before accepted phases; rejected suffixes are excluded.',
        'Original invocation references protect source and Apple mutex across synchronous callbacks that may delete the entire consumer Update/retention owner. Late observation with unretired phases rejects before reading source handles; cached producer errors without retirement proof reject.',
        'StateTransfer and Qwen hidden-output copies use public retention. StateTransfer prepares through the public original Context; original Program/Queue retain Context state while its Queue wrapper remains stable in Scope.',
        'Public borrowed Context identity matches StorageOwner identity across move/close, without retention or allocation. Backend no longer reaches into ContextRef for this query.'
    ],
    validation=dict(windows=dict(device_tests='9/9',processes=win['processes'],unique_TUs=6,compile_invocations=7,compile_failures=1),
        mac=dict(model='Mac16,12',processes=mac['processes'],unique_TUs=4,compile_invocations=5,compile_failures=1,reused_successful_device=True),
        contracts=['Exact two-phase/producer source inventory; unused producer and rejected phase exclusion.',
            'Invalid index/parameters and active-node duplicate reject without consuming references.',
            'Inline release can delete the entire Update owner; native original state remains valid through return.',
            'Pending/unknown observation never releases the existing owner early; late unknown attachment rejects zero-consumption.',
            'Original seven CPU controlled failure/cancellation/abandonment branches, real CPU/Vulkan/Apple copy and closed-writer recovery.',
            'Tiny Vulkan ordinary/MTP and explicit-prefix lag1 host-image continuation.']),
    preserved_failure='The first Windows common-copy and Mac common-copy compile rejected an unqualified public type inside detail namespace. One header was qualified; Windows stopped before other TUs, Mac reused its successful independent device TU. Original outputs and failed header are archived.',
    limits=['No physical GPU driver-failure injection; controlled Completion tests are CPU protocol checks.',
        'Model host-image export/restore remains synchronous; no asynchronous session parking claim.',
        'No new CUDA/full335 run, throughput/memory benchmark, task-quality or natural MTP acceptance claim.',
        'Current selected TUs and exact cached closures were linked; unchanged vendor/SDK/Completion/weights/report were reused.',
        'Shape bucketing, stable indexed recurrent state, overlap and complete performance comparison remain separate unfinished work.'],
    cleanup=read(W/'cleanup-result.json'),
    archive=dict(path=out.relative_to(R).as_posix(),bytes=out.stat().st_size,sha256=digest(out),entries=count))
E.with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=E.with_suffix('.json').name,archive_bytes=out.stat().st_size,entries=count,sha256=digest(out))))
