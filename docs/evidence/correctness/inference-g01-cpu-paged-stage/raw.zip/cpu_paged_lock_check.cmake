set(HYLE_SOURCE_DIR "C:/public/project-hyle/hyle")
include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_runtime_patches ggml_cpu_runtime_patches)
