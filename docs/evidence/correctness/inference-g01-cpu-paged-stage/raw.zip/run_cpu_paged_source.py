from pathlib import Path
import subprocess,time,json,os
root=Path.cwd();folder=root/'.scratch/inference-gaps/g01';build=root/'.scratch/build-compute-v2-dev';hook=folder/'cpu-paged-project.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
 if(NOT TARGET GTest::gtest_main)
  set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
  add_subdirectory(C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-cpu-paged-gtest EXCLUDE_FROM_ALL)
 endif()
 function(g01_cpu_paged_source)
  add_executable(g01_cpu_paged_tests "'''+(root/'tests/compute_provider_ggml/native_paged_test.cc').as_posix()+'''" "'''+(root/'tests/compute_provider_ggml/native_ragged_test.cc').as_posix()+'''")
  target_compile_features(g01_cpu_paged_tests PRIVATE cxx_std_23)
  target_compile_options(g01_cpu_paged_tests PRIVATE /W4 /WX /wd4324 /utf-8)
  target_link_libraries(g01_cpu_paged_tests PRIVATE hyle::compute GTest::gtest_main)
  hyle_stage_runtime(g01_cpu_paged_tests)
 endfunction()
 cmake_language(DEFER CALL g01_cpu_paged_source)
endif()
'''
if not hook.exists() or hook.read_text(encoding='utf-8')!=body:hook.write_text(body,encoding='utf-8')
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(folder/'cpu-ragged-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
record=folder/'cpu-paged-source-result.json';rows=json.loads(record.read_text())['stages'] if record.exists() else []
def run(stage,args):
 n=1+sum(r['stage']==stage for r in rows);log=folder/f'cpu-paged-source-{stage}-{n}.log';start=time.monotonic()
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row);record.write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'phase':'AUDITED CPU paged draft','stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2500));print(f.read(2500).decode(errors='replace'))
  raise SystemExit(r.returncode)
if not rows or next((r for r in reversed(rows) if r['stage']=='configure'),{}).get('exit_code')!=0:run('configure',['cmake','-S',str(root),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(hook)])
run('build',['cmake','--build',str(build),'--target','g01_cpu_paged_tests','--parallel','4'])
run('run',[str(build/'bin/g01_cpu_paged_tests.exe')])
