"""Use the existing PagedAttention descriptor for the paged regression."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
S=Path(__file__).resolve().parent;ROOT=S.parents[2];T=S/'tests';O=T/'initial-paged-descriptor-mismatch'
def identity(path):
    data=path.read_bytes();return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
O.mkdir(exist_ok=False)
shutil.copy2(T/'source-freeze.json',O/'source-freeze.json')
for path in (S/'checks').glob('cpu-tests.*'):shutil.copy2(path,O/path.name)
shutil.copy2(S/'checks/cpu-results.xml',O/'cpu-results.xml')
shutil.copy2(S/'checks/cpu-image.json',O/'cpu-image.json')
files=[]
for arm,rel in [('cpu','tests/graph_batch/typed_capability_graph_test.cc'),('cuda','tests/graph_batch/batch_capture_test.cc')]:
    path=ROOT/rel;old=path.read_text();prior=O/rel;prior.parent.mkdir(parents=True,exist_ok=True);prior.write_bytes(path.read_bytes())
    marker='TEST('+('TypedCapabilityGraph' if arm=='cpu' else 'GraphBatchCapture')+', InactiveOutputRowsAreCleared'
    i=old.index(marker);prefix,body=old[:i],old[i:]
    wrong='''      const auto node = builder.add_node(c::Operation::custom(c::RaggedAttention{
          .capacity = capacity, .scale = .125F, .causal = false}), inputs).value();'''
    right='''      const auto operation = paged
          ? c::Operation::custom(c::PagedAttention{.capacity = capacity, .scale = .125F, .causal = false})
          : c::Operation::custom(c::RaggedAttention{.capacity = capacity, .scale = .125F, .causal = false});
      const auto added = builder.add_node(operation, inputs);
      ASSERT_TRUE(added) << added.error().message();
      const auto node = *added;'''
    assert body.count(wrong)==1
    new=prefix+body.replace(wrong,right);path.write_text(new,encoding='utf-8',newline='\n')
    snapshot=T/'source'/rel;snapshot.write_bytes(path.read_bytes())
    before=T/'before'/rel
    diff=T/(arm+'.diff');diff.write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),new.splitlines(True),fromfile='before/'+rel,tofile=rel)))
    files.append(dict(relative=rel,before=identity(before),after=identity(path),snapshot=identity(snapshot),diff=identity(diff)))
(T/'source-freeze.json').write_text(json.dumps(dict(files=files,compiled=False,
    initial_fixture_errors=['Second submit reused a one-shot token; test now reacquires through existing prepare/bind/replay.',
        'Paged fixture accidentally used RaggedAttention descriptor; corrected to PagedAttention with explicit construction-status assertion.'],
    product_changes_for_fixture_errors=False),indent=2))
print('TAIL_TEST_STORAGE_FIXED',flush=True)
