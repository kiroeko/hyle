"""Reuse current native closures, refreshing only two providers and two tests."""
import argparse
import concurrent.futures
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
h = load('tail_build_helpers', A/'projected-bind-cold-index/build.py')
b, c = h.b, h.c
metadata = load('tail_owner_helpers', A/'grouped-shared-activation/build_host.py').metadata

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build', action='store_true')
    args = parser.parse_args()
    out = S/'checks'
    out.mkdir(exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    paths = {'cpu': A/'batch-query-extent/checks-current/cpu-link-plan.json',
        'cuda': A/'batch-query-extent/checks/cuda-link-plan.json'}
    bases = {arm: c.read(path) for arm, path in paths.items()}
    owners = metadata(bases)
    rows = []
    for arm, tag, rel in [
        ('cpu', 'ggml-batch', 'src/compute_provider_ggml/native_batch.cc'),
        ('cuda', 'flashinfer-provider', 'src/compute_provider_flashinfer/flashinfer_provider.cc'),
        ('cpu', 'typed-test', 'tests/graph_batch/typed_capability_graph_test.cc'),
        ('cuda', 'capture-test', 'tests/graph_batch/batch_capture_test.cc')]:
        source = ROOT/rel
        candidates = [(obj, owners[c.key(obj['path'])]) for obj in bases[arm]['inputs']
            if c.key(obj['path']) in owners and
            c.key(owners[c.key(obj['path'])]['source_path']) == c.key(source)]
        assert len(candidates) == 1, (arm, rel, len(candidates))
        old, owner = candidates[0]
        rows.append(dict(arm=arm, tag=tag, source=b.identity(source), old_object=old,
            recipe=owner['recipe'], command=b.host_command(owner['command'], source, tag, out),
            object=str(out/(tag+'.obj'))))
    frozen = [*[row['source'] for row in rows],
        b.identity(ROOT/'include/hyle/compute/detail/batch_output_extent.h'),
        b.identity(S/'implementation/source-freeze.json'), b.identity(S/'tests/source-freeze.json')]
    plan = dict(compile=rows, base_paths={k:str(v) for k,v in paths.items()}, frozen=frozen,
        host_TUs=4, native_TUs=0, SDK_rebuild=False, common_CXX_unchanged=True,
        retained_red_test_objects={arm:c.read(S/arm/'tail-test-identity.json')['object'] for arm in bases})
    c.save(out/'plan.json', plan)
    print('TAIL_BUILD_PLAN', len(rows), flush=True)
    if not args.build: return
    def check():
        for row in frozen: assert b.same(row), row['path']
    for base in bases.values():
        for row in base['inputs']: assert b.same(row), row['path']
    env, runtime = b.environment(bases['cuda']['command'],
        [row['path'] for base in bases.values() for row in base['inputs']], out)
    c.save(out/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))
    def compile_one(row):
        check()
        receipt = out/(row['tag']+'-identity.json')
        if receipt.exists():
            prior = c.read(receipt)
            if prior['command'] == row['command'] and b.same(prior['object']) and all(b.same(x) for x in prior['dependencies']):
                print('REUSE', row['tag'], flush=True)
                return row['tag'], prior
        c.execute(row['tag']+'-compile', row['command'], env, out)
        check()
        data = c.read(out/(row['tag']+'-deps.json'))['Data']
        result = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
            dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])])
        c.save(receipt, result)
        return row['tag'], result
    finished, errors = {}, []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag, result = future.result()
                finished[tag] = result
            except Exception as error: errors.append(repr(error))
    c.save(out/'compile-summary.json', dict(passed=not errors, errors=errors))
    if errors: raise RuntimeError(errors)
    for arm, base in bases.items():
        replacements = {c.key(row['old_object']['path']):finished[row['tag']]['object'] for row in rows if row['arm']==arm}
        red = plan['retained_red_test_objects'][arm]
        assert b.same(red)
        lookup = {c.key(row['path']):row for row in base['inputs']}
        lookup.update({c.key(row['path']):row for row in [*replacements.values(), red]})
        command = [replacements.get(c.key(arg),{}).get('path',arg) for arg in base['command']
            if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        image = out/(arm+'.exe')
        command += [red['path'], '/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')),
            '/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs = [lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        assert len(inputs) == len({c.key(row['path']) for row in inputs})
        for row in inputs: assert b.same(row)
        check()
        link_plan = dict(command=command, inputs=inputs)
        previous, image_receipt = out/(arm+'-link-plan.json'), out/(arm+'-image.json')
        if previous.exists() and image_receipt.exists() and c.read(previous)==link_plan and b.same(c.read(image_receipt)):
            print('REUSE_LINK', arm, flush=True)
        else:
            c.execute(arm+'-link',command,env,out)
        c.save(previous, link_plan)
        c.save(image_receipt,b.identity(image))
    c.save(out/'summary.json', dict(passed=True, host_TUs=4, native_TUs=0,
        SDK_rebuild=False, common_CXX_unchanged=True, red_test_objects_reused=True))
    print('TAIL_BUILT', flush=True)

if __name__ == '__main__': main()
