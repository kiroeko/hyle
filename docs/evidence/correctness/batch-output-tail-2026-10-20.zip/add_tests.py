"""Add bounded native tail regressions to their existing CPU/CUDA owners."""
from pathlib import Path
import hashlib
import json
import difflib

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
OUT = S / 'tests'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

BODY = r'''
TEST(@SUITE@, @NAME@) {
@CONTEXT@
  auto queue = context.create_queue().value();
  struct Configuration { c::DataType type; c::BatchStorage storage; };
  // Two existing native domains, including GQA and unequal Q/V head depths.
  const std::array configurations{
      Configuration{c::DataType::kFloat16, c::BatchStorage::kRagged},
      Configuration{c::DataType::kBFloat16, c::BatchStorage::kPaged}};
  for (const auto configuration : configurations) {
    SCOPED_TRACE(static_cast<int>(configuration.type));
    const bool paged = configuration.storage == c::BatchStorage::kPaged;
    const auto plain = c::CacheStorage::plain(configuration.type).value();
    constexpr std::uint32_t capacity_rows = 128, heads = 2, value_depth = 128;
    const c::BatchCapacity capacity{
        .storage = configuration.storage,
        .query_type = configuration.type, .output_type = configuration.type,
        .key_storage = plain, .value_storage = plain,
        .max_requests = 1, .max_query_rows = capacity_rows,
        .max_kv_rows = paged ? 16u : 2u,
        .max_pages = paged ? 1u : 0u, .max_page_refs = paged ? 1u : 0u,
        .query_heads = heads, .kv_heads = 1, .qk_head_dim = 64,
        .value_head_dim = value_depth, .page_size = paged ? 16u : 1u};
    auto schema = c::BatchSchema::create(capacity).value();
    struct Episode { std::uint32_t physical_rows, active_rows; };
    // The R1 episode must not write schema slack. The empty layout still
    // owns a nonempty R4 output and must initialize all four rows.
    for (const auto episode : std::array{Episode{4, 1}, Episode{1, 1}, Episode{4, 0}}) {
      SCOPED_TRACE(episode.physical_rows);
      SCOPED_TRACE(episode.active_rows);
      const std::array<std::int32_t, 2> qp{0, static_cast<std::int32_t>(episode.active_rows)};
      const std::array<std::int32_t, 2> kp{0, paged ? 1 : 2};
      const std::array<std::int32_t, 1> ids{0}, tails{16};
      const auto layout = schema.version({qp, kp,
          paged ? std::span<const std::int32_t>(ids) : std::span<const std::int32_t>{},
          paged ? std::span<const std::int32_t>(tails) : std::span<const std::int32_t>{}}).value();
      const std::array descriptions{
          c::batch_query_description(capacity, episode.physical_rows).value(),
          c::batch_cache_description(capacity, c::BatchCacheRole::kKey).value(),
          c::batch_cache_description(capacity, c::BatchCacheRole::kValue).value(),
          schema.metadata_description().value()};
      const auto output_desc = c::batch_output_description(capacity, episode.physical_rows).value();
      auto builder = g::GraphBuilder::create().value();
      std::array<g::ValueId, 4> inputs;
      for (std::size_t port = 0; port < inputs.size(); ++port)
        inputs[port] = builder.input(descriptions[port]).value();
      const auto node = builder.add_node(c::Operation::custom(c::RaggedAttention{
          .capacity = capacity, .scale = .125F, .causal = false}), inputs).value();
      const auto output = builder.result(node).value();
      ASSERT_TRUE(builder.publish(output).ok());
      const auto graph = std::move(builder).finish().value();
      const std::array domains{g::StorageDomain{resource}};
      const std::array targets{g::ExecutionTarget{
          g::ExecutionSource::acquire(context).value(), g::StorageDomainId{0}}};
      auto compiled = gb::compile(graph, {.storage_domains = domains, .targets = targets},
          {.operation_fallback = g::OperationFallbackPolicy::kReject});
      ASSERT_TRUE(compiled) << compiled.error().message();
      auto slot = compiled->executable.create_invocation({.resources = g::ResourceOptions{}}).value();
      const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
      const std::array layouts{gb::NodeLayout{node, layout}};
      const auto prepared = gb::prepare(slot, queues, layouts, {.host_workspace = workspace,
          .max_float_workspace_bytes = 8u << 20, .max_int_workspace_bytes = 64u << 10});
      ASSERT_TRUE(prepared.ok()) << prepared.message();
      std::array<m::Buffer, 3> payload;
      for (std::size_t port = 0; port < payload.size(); ++port) {
        payload[port] = m::Buffer::create(resource, descriptions[port].required_bytes().value(), 64).value();
        ASSERT_TRUE(payload[port].view().fill(std::byte{0}).ok());
      }
      const auto low = paged ? std::uint16_t{0x3f80} : std::uint16_t{0x3c00};
      const auto high = paged ? std::uint16_t{0x4040} : std::uint16_t{0x4200};
      std::vector<std::uint16_t> values(payload[2].size() / 2, low);
      std::fill(values.begin() + values.size() / 2, values.end(), high);
      ASSERT_TRUE(payload[2].view().write(std::as_bytes(std::span(values))).ok());
      constexpr std::size_t guard_words = 32, row_words = heads * value_depth;
      auto destination = m::Buffer::create(resource,
          (capacity_rows * row_words + 2 * guard_words) * 2, 64).value();
      const auto output_view = c::TensorView::create(output_desc,
          destination.view().subview(guard_words * 2).value()).value();
      ASSERT_EQ(output_view.storage().size(), output_desc.required_bytes().value());
      for (std::size_t port = 0; port < payload.size(); ++port)
        ASSERT_TRUE(slot.bind(inputs[port], c::ConstTensorView::create(
            descriptions[port], payload[port].view()).value()).ok());
      ASSERT_TRUE(slot.bind(output, output_view).ok());
@REPLAY@
      // Poison after prepare/capture and again before replay. A one-time cold
      // clear, wrong stream, or schema-wide clear cannot satisfy this oracle.
      for (unsigned replay_index = 0; replay_index < 2; ++replay_index) {
        ASSERT_TRUE(destination.view().fill(std::byte{0x35}).ok());
        {
          auto done = slot.submit(queues);
          ASSERT_TRUE(done) << done.error().message();
          ASSERT_TRUE(done->wait().ok());
        }
        std::vector<std::uint16_t> actual(destination.size() / 2);
        ASSERT_TRUE(destination.view().read(std::as_writable_bytes(std::span(actual))).ok());
        const auto active = actual.begin() + guard_words;
        const auto tail = active + episode.active_rows * row_words;
        const auto end = active + episode.physical_rows * row_words;
        EXPECT_EQ(std::count(actual.begin(), active, std::uint16_t{0x3535}), guard_words);
        // Q=K=0: native attention averages equally many V=1 and V=3.
        // Both F16 and BF16 encode the independent exact result 2 as 0x4000.
        EXPECT_EQ(std::count(active, tail, std::uint16_t{0x4000}),
            std::size_t(episode.active_rows) * row_words);
        EXPECT_EQ(std::count(tail, end, std::uint16_t{0}),
            std::size_t(episode.physical_rows - episode.active_rows) * row_words);
        EXPECT_EQ(std::count(end, actual.end(), std::uint16_t{0x3535}),
            std::size_t(actual.end() - end));
      }
      ASSERT_TRUE(slot.close().ok());
      slot = {};
    }
  }
}
'''

def main():
    OUT.mkdir(exist_ok=False)
    files = []
    for arm, rel in [('cpu', 'tests/graph_batch/typed_capability_graph_test.cc'),
                     ('cuda', 'tests/graph_batch/batch_capture_test.cc')]:
        path = ROOT / rel
        before = OUT / 'before' / rel
        before.parent.mkdir(parents=True, exist_ok=True)
        before.write_bytes(path.read_bytes())
        body = BODY.replace('@SUITE@', 'TypedCapabilityGraph' if arm == 'cpu' else 'GraphBatchCapture')
        body = body.replace('@NAME@', 'InactiveOutputRowsAreClearedWithinTheLogicalPort' if arm == 'cpu'
            else 'InactiveOutputRowsAreClearedByCapturedCommands')
        context = '''  auto context = c::Context::create(c::cpu::device(),
      c::ggml_cpu::provider({.native_threads = 1})).value();
  const auto resource = m::system_resource(), workspace = m::system_resource();'''
        replay = '''      const auto replay = slot.prepare_replay(queues);
      ASSERT_TRUE(replay.ok()) << replay.message();'''
        if arm == 'cuda':
            context = '''  auto context = g::cuda::create_context().value();
  auto device = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto host = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost).value();
  const auto resource = device.ref(), workspace = host.ref();'''
            replay = '''      const auto replay = slot.prepare_replay(queues,
          {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject});
      ASSERT_TRUE(replay.ok()) << replay.message();
      EXPECT_EQ(slot.replay_route(), g::ReplayRoute::kCaptured);'''
        body = body.replace('@CONTEXT@', context).replace('@REPLAY@', replay)
        old = path.read_text(encoding='utf-8')
        marker = '} // namespace'
        assert old.endswith(marker + '\n')
        new = old.removesuffix(marker + '\n') + body + marker + '\n'
        path.write_text(new, encoding='utf-8', newline='\n')
        snapshot = OUT / 'source' / rel
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(path.read_bytes())
        diff = OUT / (arm + '.diff')
        diff.write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
            fromfile='before/' + rel, tofile=rel)), encoding='utf-8')
        files.append(dict(relative=rel, before=identity(before), after=identity(path), snapshot=identity(snapshot), diff=identity(diff)))
    (OUT / 'source-freeze.json').write_text(json.dumps(dict(files=files, compiled=False), indent=2), encoding='utf-8')
    print('TAIL_TESTS_SOURCE_READY', flush=True)

if __name__ == '__main__': main()
