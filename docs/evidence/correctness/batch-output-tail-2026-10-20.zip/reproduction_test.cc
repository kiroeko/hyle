#include <gtest/gtest.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>
#include "hyle/compute/batch_ops.h"
#include "hyle/graph/batch.h"
#include "hyle/mem/buffer.h"
#if defined(HYLE_TAIL_PROBE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#else
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
#endif
namespace {
namespace c=hyle::compute;namespace g=hyle::graph;namespace gb=g::batch;namespace m=hyle::mem;
TEST(BatchOutputTail, InactivePhysicalRowsMustNotPublishThePreviousSentinel) {
#if defined(HYLE_TAIL_PROBE_CUDA)
  auto context=g::cuda::create_context().value();
  auto device=c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice).value();
  auto host=c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kPinnedHost).value();
  auto resource=device.ref(),workspace=host.ref();
#else
  auto context=c::Context::create(c::cpu::device(),c::ggml_cpu::provider({.native_threads=1})).value();
  auto resource=m::system_resource(),workspace=m::system_resource();
#endif
  auto queue=context.create_queue().value();
  const auto plain=c::CacheStorage::plain(c::DataType::kFloat16).value();
  const c::BatchCapacity capacity{.storage=c::BatchStorage::kRagged,
    .query_type=c::DataType::kFloat16,.output_type=c::DataType::kFloat16,
    .key_storage=plain,.value_storage=plain,.max_requests=1,.max_query_rows=4,.max_kv_rows=2,
    .max_pages=0,.max_page_refs=0,.query_heads=1,.kv_heads=1,.qk_head_dim=64,.value_head_dim=64,.page_size=1};
  const auto schema=c::BatchSchema::create(capacity).value();
  const std::array<std::int32_t,2> qp{0,1},kp{0,2};
  const auto layout=schema.version({qp,kp,{},{}}).value();
  const std::array descriptions{c::batch_query_description(capacity).value(),
    c::batch_cache_description(capacity,c::BatchCacheRole::kKey).value(),
    c::batch_cache_description(capacity,c::BatchCacheRole::kValue).value(),
    schema.metadata_description().value()};
  auto builder=g::GraphBuilder::create().value();
  std::array<g::ValueId,4> inputs;
  for(std::size_t p=0;p<inputs.size();++p)inputs[p]=builder.input(descriptions[p]).value();
  const auto node=builder.add_node(c::Operation::custom(c::RaggedAttention{
    .capacity=capacity,.scale=.125F,.causal=false}),inputs).value();
  const auto output=builder.result(node).value();
  ASSERT_TRUE(builder.publish(output).ok());
  const auto graph=std::move(builder).finish().value();
  const std::array domains{g::StorageDomain{resource}};
  const std::array targets{g::ExecutionTarget{g::ExecutionSource::acquire(context).value(),g::StorageDomainId{0}}};
  auto compiled=gb::compile(graph,{.storage_domains=domains,.targets=targets},
    {.operation_fallback=g::OperationFallbackPolicy::kReject});
  ASSERT_TRUE(compiled)<<compiled.error().message();
  auto slot=compiled->executable.create_invocation({.resources=g::ResourceOptions{}}).value();
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
  const std::array layouts{gb::NodeLayout{node,layout}};
  auto prepared=gb::prepare(slot,queues,layouts,{.host_workspace=workspace,
    .max_float_workspace_bytes=8u<<20,.max_int_workspace_bytes=64u<<10});
  ASSERT_TRUE(prepared.ok())<<prepared.message();
  std::array<m::Buffer,3> buffers;
  for(std::size_t p=0;p<buffers.size();++p){
    buffers[p]=m::Buffer::create(resource,descriptions[p].required_bytes().value(),64).value();
    ASSERT_TRUE(buffers[p].view().fill(std::byte{0}).ok());
  }
  std::vector<std::uint16_t> values(128,0x3c00u);
  std::fill(values.begin()+64,values.end(),0x4200u); // Uniform attention: (1+3)/2 = 2.
  ASSERT_TRUE(buffers[2].view().write(std::as_bytes(std::span(values))).ok());
  auto destination=m::Buffer::create(resource,descriptions[0].required_bytes().value(),64).value();
  ASSERT_TRUE(destination.view().fill(std::byte{0x35}).ok());
  for(std::size_t p=0;p<buffers.size();++p)
    ASSERT_TRUE(slot.bind(inputs[p],c::ConstTensorView::create(descriptions[p],buffers[p].view()).value()).ok());
  ASSERT_TRUE(slot.bind(output,c::TensorView::create(descriptions[0],destination.view()).value()).ok());
  const auto replay=slot.prepare_replay(queues);ASSERT_TRUE(replay.ok())<<replay.message();
  {auto completion=slot.submit(queues);ASSERT_TRUE(completion)<<completion.error().message();ASSERT_TRUE(completion->wait().ok());}
  std::vector<std::uint16_t> actual(256);
  ASSERT_TRUE(destination.view().read(std::as_writable_bytes(std::span(actual))).ok());
  EXPECT_EQ(std::count(actual.begin(),actual.begin()+64,std::uint16_t{0x4000}),64);
  EXPECT_EQ(std::count(actual.begin()+64,actual.end(),std::uint16_t{0}),192)
    << "A=1,R=C=4: all192 inactive F16 elements must be zero, sentinel count="
    << std::count(actual.begin()+64,actual.end(),std::uint16_t{0x3535});
  ASSERT_TRUE(slot.close().ok());slot={};
}
}
