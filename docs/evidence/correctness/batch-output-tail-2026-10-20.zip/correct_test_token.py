"""Each batch submit requires a fresh token; retain the first failing fixture."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
S=Path(__file__).resolve().parent;ROOT=S.parents[2];T=S/'tests';O=T/'initial-one-shot-token-misuse'
def identity(path):
    data=path.read_bytes();return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
O.mkdir(exist_ok=False)
shutil.copy2(T/'source-freeze.json',O/'source-freeze.json')
for path in (S/'checks').glob('cpu-tests.*'):shutil.copy2(path,O/path.name)
shutil.copy2(S/'checks/cpu-results.xml',O/'cpu-results.xml')
shutil.copy2(S/'checks/cpu-image.json',O/'cpu-image.json')
files=[]
for arm,rel in [('cpu','tests/graph_batch/typed_capability_graph_test.cc'),('cuda','tests/graph_batch/batch_capture_test.cc')]:
    path=ROOT/rel;old=path.read_text();prior=O/rel;prior.parent.mkdir(parents=True,exist_ok=True);prior.write_bytes(path.read_bytes())
    marker='TEST('+('TypedCapabilityGraph' if arm=='cpu' else 'GraphBatchCapture')+', InactiveOutputRowsAreCleared'
    i=old.index(marker);prefix,body=old[:i],old[i:]
    prepare='''      const auto prepared = gb::prepare(slot, queues, layouts, {.host_workspace = workspace,
          .max_float_workspace_bytes = 8u << 20, .max_int_workspace_bytes = 64u << 10});
      ASSERT_TRUE(prepared.ok()) << prepared.message();
'''
    assert body.count(prepare)==1;body=body.replace(prepare,'')
    start=body.index('      for (std::size_t port = 0; port < payload.size(); ++port)\n        ASSERT_TRUE(slot.bind')
    end=body.index('      // Poison after prepare/capture',start)
    binding=body[start:end];body=body[:start]+body[end:]
    loop='      for (unsigned replay_index = 0; replay_index < 2; ++replay_index) {\n'
    assert body.count(loop)==1
    reprepare=''.join('  '+line if line.strip() else line for line in (prepare+binding).splitlines(True))
    body=body.replace(loop,loop+reprepare)
    new=prefix+body;path.write_text(new,encoding='utf-8',newline='\n')
    snapshot=T/'source'/rel;snapshot.write_bytes(path.read_bytes())
    before=T/'before'/rel
    diff=T/(arm+'.diff');diff.write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),new.splitlines(True),fromfile='before/'+rel,tofile=rel)))
    files.append(dict(relative=rel,before=identity(before),after=identity(path),snapshot=identity(snapshot),diff=identity(diff)))
(T/'source-freeze.json').write_text(json.dumps(dict(files=files,compiled=False,initial_fixture_error='Second submit reused a consumed one-shot Batch token. Corrected test reacquires through ordinary prepare/bind/replay before each poisoned execution; no product change or contract relaxation.'),indent=2))
print('TAIL_TEST_TOKEN_FIXED',flush=True)
