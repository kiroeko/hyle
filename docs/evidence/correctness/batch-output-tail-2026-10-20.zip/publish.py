"""Seal the native tail fix and actual red/green/error evidence, without images."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(path):
    path=path.resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def exact(row):return identity(Path(row['path']))==row
def xml(path):
    cases=ET.parse(path).findall('.//testcase')
    return dict(cases=len(cases),failures=sum(bool(c.findall('failure')) for c in cases),
        failure_elements=sum(len(c.findall('failure')) for c in cases),skipped=sum(bool(c.findall('skipped')) for c in cases),
        identity=identity(path))
def payload(path):
    if set(path.relative_to(S).parts)&{'tmp','__pycache__','documentation'}:return False
    if 'cleanup' in path.name or path.name in {'publication.json','payload-sha256.json'}:return False
    return path.suffix in {'.py','.cc','.h','.json','.diff','.log','.xml','.md'}

def main():
    build=read(S/'checks/summary.json');assert build['passed'] and build['host_TUs']==4 and build['native_TUs']==0 and not build['SDK_rebuild']
    frozen=read(S/'implementation/source-freeze.json');tests=read(S/'tests/source-freeze.json')
    for row in [*frozen['files'],*tests['files']]:
        assert exact(row['after']) and exact(row['snapshot'])
        if row['before']:assert exact(row['before'])
    assert exact(frozen['unchanged_common_bridge'])
    actual={}
    for arm in ('cpu','cuda'):
        red=xml(S/arm/'results.xml');green=xml(S/'checks'/(arm+'-results.xml'))
        assert red['cases']==red['failures']==red['failure_elements']==1 and red['skipped']==0
        assert green['cases']==4 and green['failures']==green['skipped']==0
        old=read(S/arm/'tail-test-identity.json')['object']
        link=read(S/'checks'/(arm+'-link-plan.json'))
        assert exact(old) and old in link['inputs']
        for row in link['inputs']:assert exact(row)
        assert exact(read(S/'checks'/(arm+'-image.json')))
        actual[arm]=dict(before=red,after=green,unchanged_red_test_object=old,
            actual_image=read(S/'checks'/(arm+'-image.json')),link=identity(S/'checks'/(arm+'-link-plan.json')))
    initial={name:xml(S/'tests'/name/'cpu-results.xml') for name in
        ('initial-one-shot-token-misuse','initial-paged-descriptor-mismatch')}
    assert all(row['cases']==4 and row['failures']==1 for row in initial.values())
    docs=[]
    for rel in ('docs/user/batch-attention.md','docs/architecture/graph-design.md','docs/developer/current-work.md'):
        path=ROOT/rel;snapshot=S/'documentation'/rel;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(path.read_bytes())
        docs.append(dict(relative=rel,current=identity(path),snapshot=identity(snapshot)))
    save(S/'documentation-freeze.json',docs)
    dest=ROOT/'docs/evidence/correctness/batch-output-tail-2026-10-20.zip'
    files=[p for p in S.rglob('*') if p.is_file() and payload(p)]
    files += [Path(row['snapshot']['path']) for row in docs]
    files=sorted(set(files),key=lambda p:p.relative_to(S).as_posix())
    rows=[]
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in files:
            row=dict(**identity(path),member=path.relative_to(S).as_posix());rows.append(row)
            archive.writestr(row['member'],path.read_bytes())
        archive.writestr('payload-sha256.json',json.dumps(rows,indent=2,ensure_ascii=False).encode())
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        for row in rows:assert hashlib.sha256(archive.read(row['member'])).hexdigest()==row['sha256']
    result=dict(date='2026-10-20',status='native_CPU_CUDA_tail_fix_executed',
        problem='Active native attention math was correct but all192 inactive F16 elements retained previous sentinel bytes.',
        invariant='Only output[A,R) is zeroed on the original execution sequence. A=R adds no fill command. A0/R>0 initializes the full real output.',
        implementation=dict(public_ABI_changed=False,common_CXX_changed=False,native_math_changed=False,
            owners=['src/compute_provider_ggml/native_batch.cc','src/compute_provider_flashinfer/flashinfer_provider.cc'],
            helper='include/hyle/compute/detail/batch_output_extent.h',
            CPU='Original synchronous sequence maps the exact tail; failure keeps accepted-prefix status.',
            CUDA='Original stream cudaMemsetAsync, included in original capture; no implicit synchronization or extra executor.',
            output_permission='TensorView::create already crops to required_bytes. A proposed second common crop was reviewed and removed before compilation.'),
        source_freeze=identity(S/'implementation/source-freeze.json'),test_freeze=identity(S/'tests/source-freeze.json'),
        actual=actual,regression_geometry=dict(configurations=['F16 ragged','BF16 paged'],
            query_heads=2,kv_heads=1,Q_head_depth=64,V_head_depth=128,C=128,
            episodes=[dict(A=1,R=4),dict(A=1,R=1),dict(A=0,R=4)],
            poisoned_submissions_per_episode=2,offset_and_larger_backing_guards=True,CUDA_RequireCapture=True),
        initial_fixture_failures=initial,fixture_corrections='Reacquire the existing one-shot token before every submit; use PagedAttention for paged storage. No product weakening.',
        build=dict(unique_host_sources=4,product_host_sources=2,new_native_compilations=0,SDK_rebuild=False,
            initial_and_corrected_test_compilations=True,compiled_receipts='checks/*-identity.json'),
        limits=['This fix ran only Windows CPU/CUDA. Apple/Vulkan math was not changed or rerun.',
            'No new MLA, Direct or owned-page model execution; those output extents were source-reviewed.',
            'No model, throughput, memory-peak or independent quality claim.'],
        documentation=docs,archive=dict(**identity(dest),payloads=len(rows),CRC_checked=True,all_payload_SHA256_checked=True))
    report=dest.with_suffix('.json');save(report,result)
    save(S/'publication.json',dict(report=identity(report),archive=identity(dest),payloads=len(rows),passed=True))
    print('TAIL_EVIDENCE_PUBLISHED',len(rows),dest.stat().st_size,flush=True)

if __name__=='__main__':main()
