"""Run only actual native tail and adjacent batch invocation/capture owners."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('tail_checks_build',S/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=S/'checks'
base=c.read(out/'cuda-link-plan.json')
env,runtime=b.environment(base['command'],[r['path'] for r in base['inputs']],out)
summary={}
for arm,suite in [('cpu','TypedCapabilityGraph'),('cuda','GraphBatchCapture')]:
    image=out/(arm+'.exe');assert b.same(c.read(out/(arm+'-image.json')))
    c.execute(arm+'-tests',[str(image),'--gtest_filter='+suite+'.*:BatchOutputTail.*',
        '--gtest_output=xml:'+str(out/(arm+'-results.xml'))],env,out)
    cases=ET.parse(out/(arm+'-results.xml')).findall('.//testcase')
    assert len(cases)==4,len(cases)
    assert not any(case.findall('failure') or case.findall('skipped') for case in cases)
    summary[arm]=dict(executed=True,passed=True,cases=len(cases),skipped=0,
        names=[case.attrib['classname']+'.'+case.attrib['name'] for case in cases],
        old_red_object_reused=True)
c.save(out/'test-summary.json',dict(arms=summary,scope='F16 ragged and BF16 paged; GQA 2 heads; Q64/V128; C128; A1/R4, A1/R1, A0/R4; two poisoned replays each, offset and oversized backing guards; CUDA RequireCapture plus original finite-family/capture cases; original 192-sentinel red object reused unchanged. No model or throughput run.'))
print('TAIL_CHECKS_GREEN',flush=True)
