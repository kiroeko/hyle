"""Two tiny real native executions with an explicitly poisoned output suffix."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent
spec=importlib.util.spec_from_file_location('batch_tail_repro_helpers',A/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
extent=A/'batch-query-extent'
results={}
for arm,folder,recipe_path in [
 ('cpu','checks-current',extent/'checks/typed-test-identity.json'),
 ('cuda','checks',extent/'checks/capture-test-identity.json')]:
    out=S/arm;out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    base=c.read(extent/folder/(arm+'-link-plan.json'))
    recipe=c.read(recipe_path)
    source=S/'reproduction_test.cc'
    command=b.host_command(recipe['command'],source,'tail-test',out)
    if arm=='cuda':command.insert(1,'/DHYLE_TAIL_PROBE_CUDA=1')
    for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(base['command'],[row['path']for row in base['inputs']],out)
    c.save(out/'inputs.json',dict(base_link=b.identity(extent/folder/(arm+'-link-plan.json')),
        source=b.identity(source),runtime=runtime,actual_geometry=dict(C=4,R=4,A=1),
        expected_active_F16_bits=0x4000,sentinel_F16_bits=0x3535,expected_zero_tail_elements=192))
    c.execute('tail-test-compile',command,env,out)
    data=c.read(out/'tail-test-deps.json')['Data'];obj=b.identity(out/'tail-test.obj')
    c.save(out/'tail-test-identity.json',dict(command=command,source=b.identity(source),object=obj,
      dependencies=[b.identity(p)for p in dict.fromkeys([data['Source'],*data['Includes']])]))
    link=[arg for arg in base['command']if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    image=out/'tests.exe';link += [obj['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=link,inputs=[*base['inputs'],obj]))
    c.execute('link',link,env,out);c.save(out/'image.json',b.identity(image))
    try:c.execute('tests',[str(image),'--gtest_filter=BatchOutputTail.*','--gtest_output=xml:'+str(out/'results.xml')],env,out)
    except RuntimeError:assert c.read(out/'tests.result.json')['exit']==1
    cases=ET.parse(out/'results.xml').findall('.//testcase')
    failures=[f.text for case in cases for f in case.findall('failure')]
    assert len(cases)==1 and len(failures)==1 and 'sentinel count=192' in failures[0],failures
    results[arm]=dict(executed=True,expected_red=True,defect_confirmed=True,cases=1,exit=1,
      failures=failures,skipped=0,source_or_SDK_compilations=0,new_test_TUs=1)
    c.save(out/'summary.json',results[arm])
c.save(S/'summary.json',dict(executed=True,CPU_CUDA_tail_defect_confirmed=True,arms=results,
    scope='Actual original CPU ggml and CUDA FlashInfer math writes correct active row, but leaves all192 poisoned inactive F16 elements unchanged. No product change or numerical-math weakening.'))
print('BATCH_TAIL_CPU_CUDA_REPRODUCED',flush=True)
