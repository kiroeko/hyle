"""Three CXX units, existing Vulkan native shader/runtime, four finite Store cases."""
from pathlib import Path
import importlib.util,json,os,sys,traceback,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
V=R/'.scratch/inference-native-slot-store-20261027/windows-vulkan'
spec=importlib.util.spec_from_file_location('original_vulkan_recipe',V/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m

def env():
    h=b.helper();cl=b.read(V/'compile/test/command.json')['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env

def build():
    assert not (W/'freeze.json').exists(),'Preserve every attempt'
    units=[]
    for name,source,recipe in [
      ('copy','src/compute_route_vulkan/vulkan_copy_recording.cc',R/'.scratch/gdn-vulkan-output-scale-20261024/compile1/route--vulkan_copy_recording/run/command.json'),
      ('store','src/graph_route_vulkan/native_slot_store.cc',V/'compile2/native-store/command.json'),
      ('test','tests/graph_route_vulkan/slot_store_test.cc',V/'compile/test/command.json')]:
        command=m.command(recipe,R/source,W/'compile'/name)
        b.save(W/'recipes'/f'{name}.json',dict(command=command,cwd=str(R),timeout_seconds=180))
        units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(W/'recipes'/f'{name}.json')))
    frozen=m.c.closure([u['source']['path'] for u in units],[u['recipe']['path'] for u in units])
    b.save(W/'source-freeze.json',frozen)
    for path in ['src/compute_route_vulkan/vulkan_copy_internal.h',*[str(Path(u['source']['path']).relative_to(R)) for u in units]]:
        dest=W/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((R/path).read_bytes())
    baseline=b.read(V/'link-inputs.json')
    replacements={
      b.key(V/'compile/common/unit.obj'):b.pin(R/'.scratch/inference-batched-slot-controls-20261027/compile2/common/unit.obj'),
      b.key(R/'.scratch/inference-slot-bindings-20261027/compile/slots/unit.obj'):b.pin(R/'.scratch/inference-batched-slot-controls-20261027/compile/slots/unit.obj'),
      b.key(R/'.scratch/inference-slot-source-fallback-20261027/compile/resources/unit.obj'):b.pin(R/'.scratch/inference-batched-slot-controls-20261027/compile/resources/unit.obj')}
    assert all(sum(b.key(row['path'])==key for row in baseline)==1 for key in replacements)
    for row in baseline:b.exact(row)
    for row in replacements.values():b.exact(row)
    b.save(W/'freeze.json',dict(units=units,baseline=b.pin(V/'link-inputs.json'),baseline_count=len(baseline),existing_current_overlays=list(replacements.values()),source_freeze=b.pin(W/'source-freeze.json'),scope='Only original device-backed Store halfword copies. Original I32 raw four-byte Gather unchanged; two-byte Gather not yet implemented. Three CXX units, no SDK/shader/native rebuild, model, downloads or performance.'))
    own={b.key(row['path']):row for row in frozen};h,e=env();objects={};compiled=[]
    for unit in units:
        out=W/'compile'/unit['name'];process=h.execute(b.read(unit['recipe']['path'])['command'],e,out,timeout=180)
        raw=b.read(out/'dependencies.json')['Data'];actual=[b.pin(p) for p in dict.fromkeys([raw['Source'],*raw['Includes']])]
        b.save(out/'actual-dependencies.json',actual)
        for row in actual:
            path=Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):assert own[b.key(path)]['sha256']==row['sha256'],path
        objects[unit['name']]=b.pin(out/'unit.obj');compiled.append(dict(unit=unit,object=objects[unit['name']],process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
        b.save(W/'partial-build.json',compiled)
        for row in frozen:b.exact(row)
    replacements[b.key(V/'compile2/native-store/unit.obj')]=objects['store']
    replacements[b.key(V/'compile/test/unit.obj')]=objects['test']
    image=W/'bin/halfword-store.exe';image.parent.mkdir(parents=True,exist_ok=True)
    command=b.read(V/'link2-plan.json')['command'];seen=set()
    for i,arg in enumerate(command):
        if b.key(arg) in replacements:seen.add(b.key(arg));command[i]=replacements[b.key(arg)]['path']
        elif arg.upper().startswith('/OUT:'):command[i]='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):command[i]='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):command[i]='/IMPLIB:'+str(image.with_suffix('.lib'))
    assert seen==set(replacements),(seen,set(replacements))
    command.insert(1,objects['copy']['path'])
    linked=h.execute(command,e,W/'link',timeout=120)
    inputs=[objects['copy']]+[replacements.get(b.key(row['path']),row) for row in baseline]
    b.save(W/'link-inputs.json',inputs)
    runtime=b.read(V/'runtime.json');native=runtime['native'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(W/'runtime.json',runtime)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',compiled=compiled,link=linked,image=b.pin(image),inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),freeze=b.pin(W/'freeze.json'),counts=dict(CXX_TUs=3,links=1,images=1,SDK=0,shader_compiles=0,models=0,downloads=0)))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)

def run():
    ready=b.read(W/'ready.json');b.exact(ready['image']);assert not (W/'run').exists()
    h,e=env();e['PATH']=b.read(ready['runtime']['path'])['PATH'];xml=W/'results.xml'
    process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter=VulkanSlotStore.*','--gtest_output=xml:'+str(xml)],e,W/'run',timeout=90)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
    assert len(cases)==4 and root.attrib['tests']=='4' and root.attrib['failures']=='0'
    assert all(x.attrib.get('status')=='run' and not list(x) for x in cases)
    b.save(W/'summary.json',dict(status='FOUR_STORE_CASES_PASS',process=process,ready=b.pin(W/'ready.json'),results=b.pin(xml),cases=[c.attrib for c in cases],scope='Exact device-native two/six-byte Store plus original F32/BF16 aligned generated Gather/Store. Original FIFO, Completion, take/reset and full pool/padding bytes checked. No two-byte Gather or engine/performance claim.'))
    print('PASS',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    try:{'build':build,'run':run}[sys.argv[1]]()
    except Exception:
        b.save(W/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc(),note='First failure retained; no automatic fallback or retry.'));raise
