"""Archive exact finite Store sources/commands/logs; no rebuild or rerun."""
from pathlib import Path
import hashlib,json,struct,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=digest(raw))
original=read(W/'ready.json');final=read(W/'retention/ready.json')
first_result=read(W/'summary.json');last_result=read(W/'retention/summary.json')
assert first_result['status']=='FOUR_STORE_CASES_PASS' and last_result['status']=='COMPLETION_LIFETIME_CASE_PASS'
for ready in [original,final]:
    for unit in ready['compiled']:
        saved=W/('retention/source' if ready is final else 'source')/Path(unit['unit']['source']['path']).relative_to(R)
        assert pin(saved)['sha256']==unit['unit']['source']['sha256']
current=['src/compute_route_vulkan/vulkan_copy_internal.h','src/compute_route_vulkan/vulkan_copy_recording.cc',
         'src/graph_route_vulkan/native_slot_store.cc','tests/graph_route_vulkan/slot_store_test.cc']
current_pins=[pin(R/p) for p in current]
actual={str(Path(u['unit']['source']['path']).relative_to(R)).replace('\\','/'):u['unit']['source'] for u in original['compiled']+final['compiled']}
for row in current_pins:
    rel=str(Path(row['path']).relative_to(R)).replace('\\','/')
    if rel in actual:assert actual[rel]['sha256']==row['sha256'],rel
    else:assert pin(W/'source'/rel)['sha256']==row['sha256'],rel
old_review=read(R/'.scratch/inference-native-slot-store-20261027/vulkan-exact-byte-copy-review.json')
shader=next(s for s in old_review['shaders'] if s['name']=='contig_cpy_f16_f16')
raw=Path(shader['path']).read_bytes();assert digest(raw)==shader['sha256']
words=struct.unpack('<'+'I'*(len(raw)//4),raw);caps=[];converts=0;at=5
while at<len(words):
    n,op=words[at]>>16,words[at]&65535;assert n and at+n<=len(words)
    if op==17:caps.append(words[at+1])
    converts+=op==115;at+=n
assert set(caps)=={1,4433} and converts==0
archive=old_review['actual_link']['archive'];archive_raw=Path(archive['path']).read_bytes()
assert digest(archive_raw)==archive['sha256']
offset=archive_raw.find(raw);assert offset>=0
shader_record=dict(shader=pin(shader['path']),actual_linked_archive=archive,blob_offset=offset,
    capabilities=caps,OpFConvert_count=converts,feature_gate='device.provider.native().storage_buffer16 is the actual logical-device enabled fact; 128-lane and push/descriptor/dispatch limits are checked before acceptance.',
    bit_contract='Original same-type load/store shader, no floating conversion or arithmetic. BF16 bytes use these exact 16-bit storage lanes without numerical reinterpretation.')
(W/'shader-identity.json').write_text(json.dumps(shader_record,indent=2)+'\n',encoding='utf-8')
members={}
for path in W.rglob('*'):
    if path.is_file() and path.suffix.lower() in {'.py','.json','.log','.cc','.h','.xml'}:
        members[str(path.relative_to(W)).replace('\\','/')]=path.read_bytes()
members['native-shader/contig_cpy_f16_f16.spv']=raw
receipt=dict(schema=1,title='Vulkan exact halfword native Store',date='2026-10-27',status='IMPLEMENTED_FINITE_CHECKS_PASS',
    implementation='Existing Vulkan CopyRecording/Run gains an opt-in exact two-byte storage-copy mode. Original four-byte transfer path and five-argument preparation symbol remain. Complete interval, device-usage, descriptor-origin/range and dispatch checks precede data command recording. The existing Runtime FIFO, Completion and retirement controller are reused; Run.recording_owner retains the shader pipeline independently of the wrapper.',
    current_sources=current_pins,changes=[dict(path=p,summary=s) for p,s in zip(current,[
      'Private opt-in halfword granularity overload; ordinary word preparation unchanged.',
      'Original linked pure16 copy shader, cold descriptor sets, exact selected native spans, original Run and independent pipeline retention.',
      'Even-byte item/stride Store selects the appropriate original copy mode; no padding enlargement.',
      'Real 2/6-byte Store with 2mod4 origins, gaps, writer reorder, Completion/reset and wrapper-drop lifetime case.'])],
    measured=dict(first_image=original['image'],first_compile_processes=[u['process'] for u in original['compiled']],first_link=original['link'],
      first_results=first_result,final_image=final['image'],final_compile_processes=[u['process'] for u in final['compiled']],final_link=final['link'],final_results=last_result,
      distinct_CXX_TUs=3,compiler_processes=5,links=2,actual_test_processes=2,total_GTests=5,failed_build_or_run_attempts=0,SDK_builds=0,shader_compiles=0,models=0,downloads=0),
    source_window='Four Store cases ran on first frozen copy/test source. Independent review then found missing Run-owned pipeline lifetime; one-line original Run owner retention and one dedicated wrapper-drop case were compiled and run on the second image. Original four cases were not repeated, as authorized. Their snapshots are retained separately; no final-source snapshot substitutes for an earlier window.',
    shader_identity=shader_record,
    verified_boundaries=['Device-native 2-byte and 6-byte BF16 item copies with stride6/10 and non-word origins; full byte comparisons include untouched items and padding.',
      'Two replays reverse actual writer order and use the updated original descriptors.',
      'Original generated F32 dense and BF16 padded word-row Gather-to-Store cases still pass.',
      'Unobserved Completion/result retention blocks take; reset withdraws actual authority and retired writers can be recovered.',
      'Dedicated direct copy drops CopyRecording after native submission, waits on the original Completion and checks exact destination and adjacent bytes.'],
    unverified=['Two-byte raw Gather is not implemented by this batch: existing four-byte I32 raw Gather is supported, while floating F16/BF16 GET_ROWS conversion cannot certify raw NaN bits.',
      'The new halfword path requires real enabled storageBuffer16BitAccess, legal 128-lane dispatch, even-byte item/stride and two-byte-aligned original device storage. It does not support arbitrary odd-byte ranges.',
      'Original staging buffers have transfer-only usage; this path rejects them rather than dispatching a shader against unsupported storage usage.',
      'No complete inference, throughput, multi-device hardware matrix, fault injection, validation-layer run or new SDK/native shader rebuild.'],
    members=[dict(name=name,bytes=len(data),sha256=digest(data)) for name,data in sorted(members.items())])
manifest=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode('utf-8');members['manifest.json']=manifest
dest=R/'docs/evidence/correctness';dest.mkdir(parents=True,exist_ok=True)
stem='inference-vulkan-halfword-store-2026-10-27';zpath=dest/(stem+'.zip');jpath=dest/(stem+'.json')
assert not zpath.exists() and not jpath.exists(),'Do not overwrite published evidence'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(zpath) as z:
    assert set(z.namelist())==set(members) and z.testzip() is None
    for name,expected in members.items():assert z.read(name)==expected
receipt['archive']=pin(zpath);receipt['archive_manifest_sha256']=digest(manifest);receipt['archive_integrity']='Every member reopened and compared byte-for-byte; CRC test passed.'
jpath.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(receipt=pin(jpath),archive=pin(zpath),members=len(members)),indent=2))
