"""Narrow Run-owned pipeline retention fix and one completion-lifetime case."""
from pathlib import Path
import importlib.util,json,os,sys,traceback,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1];A=W/'retention'
spec=importlib.util.spec_from_file_location('store_halfword_recipe',W/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m
def build():
    assert not (A/'freeze.json').exists()
    previous=b.read(W/'ready.json');units=[]
    for name,source in [('copy','src/compute_route_vulkan/vulkan_copy_recording.cc'),('test','tests/graph_route_vulkan/slot_store_test.cc')]:
        recipe=W/'recipes'/f'{name}.json';command=m.command(recipe,R/source,A/'compile'/name)
        b.save(A/'recipes'/f'{name}.json',dict(command=command,cwd=str(R),timeout_seconds=180))
        units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(A/'recipes'/f'{name}.json')))
    frozen=m.c.closure([u['source']['path'] for u in units],[u['recipe']['path'] for u in units]);b.save(A/'source-freeze.json',frozen)
    for unit in units:
        path=Path(unit['source']['path']);dst=A/'source'/path.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(path.read_bytes())
    b.save(A/'freeze.json',dict(previous=b.pin(W/'ready.json'),previous_four_pass=b.pin(W/'summary.json'),units=units,source_freeze=b.pin(A/'source-freeze.json'),reason='Root independent review: Completion owns Run, so Run must retain the shader pipeline independently of the CopyRecording wrapper. Existing Run.recording_owner retains it without a cycle.'))
    own={b.key(row['path']):row for row in frozen};h,e=old.env();compiled=[];objects={}
    for unit in units:
        out=A/'compile'/unit['name'];process=h.execute(b.read(unit['recipe']['path'])['command'],e,out,timeout=180)
        raw=b.read(out/'dependencies.json')['Data'];actual=[b.pin(p) for p in dict.fromkeys([raw['Source'],*raw['Includes']])];b.save(out/'actual-dependencies.json',actual)
        for row in actual:
            path=Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):assert own[b.key(path)]['sha256']==row['sha256'],path
        objects[unit['name']]=b.pin(out/'unit.obj');compiled.append(dict(unit=unit,object=objects[unit['name']],process=process,dependencies=b.pin(out/'actual-dependencies.json')));b.save(A/'partial-build.json',compiled)
    replaced={b.key(row['object']['path']):objects[row['unit']['name']] for row in previous['compiled'] if row['unit']['name'] in objects}
    command=b.read(W/'link/command.json')['command'];image=A/'bin/halfword-retention.exe';image.parent.mkdir(parents=True,exist_ok=True);seen=set()
    for i,arg in enumerate(command):
        if b.key(arg) in replaced:seen.add(b.key(arg));command[i]=replaced[b.key(arg)]['path']
        elif arg.upper().startswith('/OUT:'):command[i]='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):command[i]='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):command[i]='/IMPLIB:'+str(image.with_suffix('.lib'))
    assert seen==set(replaced)
    linked=h.execute(command,e,A/'link',timeout=120)
    retained=b.read(previous['inputs']['path']);[b.exact(row) for row in retained]
    inputs=[replaced.get(b.key(row['path']),row) for row in retained];b.save(A/'link-inputs.json',inputs)
    runtime=b.read(previous['runtime']['path']);native=runtime['native'];b.exact(native);alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(A/'runtime.json',runtime)
    [b.exact(row) for row in frozen]
    b.save(A/'ready.json',dict(status='BUILT_NOT_RUN',previous=b.pin(W/'ready.json'),compiled=compiled,link=linked,image=b.pin(image),inputs=b.pin(A/'link-inputs.json'),runtime=b.pin(A/'runtime.json'),freeze=b.pin(A/'freeze.json'),counts=dict(CXX_TUs=2,links=1,images=1,SDK=0,shaders=0,downloads=0)))
    print('READY',json.dumps(b.pin(A/'ready.json')),flush=True)
def run():
    ready=b.read(A/'ready.json');b.exact(ready['image']);assert not (A/'run').exists();h,e=old.env();e['PATH']=b.read(ready['runtime']['path'])['PATH'];xml=A/'results.xml'
    process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter=VulkanSlotStore.HalfwordCompletionOutlivesItsRecordingWrapper','--gtest_output=xml:'+str(xml)],e,A/'run',timeout=90)
    root=ET.parse(xml).getroot();assert root.attrib['tests']=='1' and root.attrib['failures']=='0'
    cases=root.findall('./testsuite/testcase');assert len(cases)==1 and cases[0].attrib.get('status')=='run' and not list(cases[0])
    b.save(A/'summary.json',dict(status='COMPLETION_LIFETIME_CASE_PASS',process=process,ready=b.pin(A/'ready.json'),results=b.pin(xml),case=cases[0].attrib,previous_four_cases=b.pin(W/'summary.json'),scope='Original four cases were not repeated. This case drops CopyRecording after actual native submission, waits on only the original Completion, and checks exact destination bytes/padding.'))
    print('PASS',json.dumps(b.pin(A/'summary.json')),flush=True)
if __name__=='__main__':
    try:{'build':build,'run':run}[sys.argv[1]]()
    except Exception:b.save(A/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc()));raise
