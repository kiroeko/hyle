from pathlib import Path
import hashlib,json,re,shutil,subprocess,time

root=Path.cwd();out=root/'.scratch/inference-gaps/g02/resume-windows-3';build=Path('C:/h7/inference-g02-impacted')
old_file=root/'.scratch/inference-gaps/g02/resume-windows-2/frozen-build.ninja'
current_file=out/'frozen-build.ninja'
old_root=build/'src/compute_ggml_runtime/source-ada61b1e5d25c18c'
prep=json.loads((out/'prepare.json').read_text());assert prep['state']=='TERMINAL_PREPARATION_ONLY'
commands=json.loads((build/'compile_commands.json').read_text())
row=next(r for r in commands if r['file'].replace('\\','/').endswith('/src/compute_provider_ggml_vulkan/region.cc'))
match=re.search(r'source-[0-9a-f]{16}',row['command']);assert match
new_root=old_root.parent/match[0];assert new_root!=old_root
old_tag=old_root.name;new_tag=new_root.name
current_text=(build/'build.ninja').read_text();pattern=r'^build [^\n]*: RERUN_CMAKE[^\n]*\n(?:[ \t][^\n]*\n|\n)*';current_text,count=re.subn(pattern,'',current_text,flags=re.M);assert count==1
current_file.write_text(current_text,encoding='utf-8')
old_files={p.relative_to(old_root).as_posix():p for p in old_root.rglob('*') if p.is_file()};new_files={p.relative_to(new_root).as_posix():p for p in new_root.rglob('*') if p.is_file()};assert old_files.keys()==new_files.keys()
changed={name for name in old_files if old_files[name].read_bytes()!=new_files[name].read_bytes()};assert changed=={'src/ggml-vulkan/vulkan-shaders/unary.comp'},changed
(out/'native-tree-diff.json').write_text(json.dumps({'old_root':str(old_root),'new_root':str(new_root),'files':len(old_files),'changed':sorted(changed)},indent=2)+'\n')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def normalize(s):return s.replace(old_tag,'NATIVE_SOURCE').replace(new_tag,'NATIVE_SOURCE')
def blocks(s):
 rows=[];lines=s.splitlines(keepends=True);i=0
 while i<len(lines):
  if lines[i].startswith('build '):
   start=i;i+=1
   while i<len(lines) and (not lines[i].strip() or lines[i].startswith((' ','\t'))):i+=1
   rows.append((start,i,lines[start:i]))
  else:i+=1
 return lines,rows
old_lines,old_blocks=blocks(old_file.read_text());lines,new_blocks=blocks(current_file.read_text())
old_compile={normalize(row[2][0]):row[2] for row in old_blocks if re.search(r': (?:CUDA|CXX|C)_COMPILER',row[2][0])}
raw=subprocess.check_output(['ninja','-C',str(build),'-t','deps'],text=True)
(out/'original-native-dependencies.log').write_text(raw,encoding='utf-8')
dependencies={};key=None
for line in raw.splitlines():
 if line and not line.startswith(' '):
  key=line.split(': #deps ',1)[0].replace('\\','/');dependencies[key]=[]
 elif line.startswith('    ') and key:dependencies[key].append(Path(line.strip()) if Path(line.strip()).is_absolute() else build/line.strip())
record={'scope':'Reuse only old built native objects with exact compiler edge except derived source path and scheduling pool; old/new entire native tree differs only unary.comp. Generated non-unary shader inputs must also retain exact bytes after normal generation. Original toolchain/cache profile unchanged. No public build core/source change. Old source path may remain in diagnostics.',
 'source_diff':'native-tree-diff.json','post_build_generated_inputs':{},'reused':[],'not_reused':[],'source_manifest_sha256':sha(current_file),'old_manifest_sha256':sha(old_file)}
replacement={};stat_cache={};git_cache={}
def external_unchanged(p,object_time):
 s=str(p.resolve()).lower()
 if s not in stat_cache:stat_cache[s]=p.stat().st_mtime_ns if p.is_file() else None
 if stat_cache[s] is None:return False
 if stat_cache[s]<=object_time:return True
 try:relative=p.resolve().relative_to(root).as_posix()
 except ValueError:return False
 if relative not in git_cache:
  r=subprocess.run(['git','show','9cd5cc678:'+relative],capture_output=True)
  git_cache[relative]=r.returncode==0 and r.stdout==p.read_bytes()
 return git_cache[relative]
for start,end,block in new_blocks:
 if not re.search(r': (?:CUDA|CXX|C)_COMPILER',block[0]) or 'compute_ggml_runtime' not in block[0]:continue
 old=old_compile.get(normalize(block[0]))
 output=block[0].split(': ',1)[0][6:]
 if 'unary.comp.cpp' in block[0] or any(rel in block[0].replace('\\','/') for rel in changed):
  record['not_reused'].append({'output':output,'reason':'explicit native translation unit changed'});continue
 if not old:record['not_reused'].append({'output':output,'reason':'no exact original compiler edge'});continue
 def semantic(rows):return normalize(''.join(x for x in rows if x.strip() and not x.strip().startswith('pool = ')))
 if semantic(old)!=semantic(block):record['not_reused'].append({'output':output,'reason':'compile properties changed beyond derived source path'});continue
 old_output=old[0].split(': ',1)[0][6:];obj=build/old_output.replace('\\','/')
 if not obj.is_file():record['not_reused'].append({'output':output,'reason':'original object missing'});continue
 deps=dependencies.get(old_output.replace('\\','/'),[])
 if not deps:record['not_reused'].append({'output':output,'reason':'original actual transitive dependencies unavailable'});continue
 reason=None;native_count=1 if new_tag in block[0] and old_tag in old[0] else 0
 generated='vendor/src/ggml-vulkan' in block[0].replace('\\','/') and '.comp.cpp' in block[0]
 for p in deps:
  native_rel=None
  for candidate_root in [old_root,old_root.parent/'source-e73b695f71c1ea2c']:
   try:native_rel=p.relative_to(candidate_root).as_posix();break
   except ValueError:pass
  if native_rel is not None:
   native_count+=1
   target=new_root/native_rel
   if not target.is_file() or p.read_bytes()!=target.read_bytes():reason='actual transitive native input changed: '+native_rel;break
  elif not external_unchanged(p,obj.stat().st_mtime_ns):reason='external/generated dependency not proven unchanged: '+str(p);break
  elif 'vendor/src/ggml-vulkan/' in p.as_posix():
   record['post_build_generated_inputs'][str(p)]=sha(p)
 if reason or (native_count==0 and not generated):record['not_reused'].append({'output':output,'reason':reason or 'no retained native/generated input identity'});continue
 dest=build/output.replace('\\','/');digest=sha(obj)
 if obj!=dest:
  if dest.exists():assert sha(dest)==digest,'do not overwrite any different validation object'
  else:
   dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(obj,dest)
  assert sha(dest)==digest
 replacement[start]=(end,[f'build {output}: phony\n','\n'])
 record['reused'].append({'old':str(obj),'output':str(dest),'sha256':digest,'dependency_count':len(deps),'native_dependency_count':native_count,'old_compiler_edge':''.join(old),'new_compiler_edge':''.join(block)})
result=[];i=0
while i<len(lines):
 if i in replacement:
  end,content=replacement[i];result.extend(content);i=end
 else:result.append(lines[i]);i+=1
p=out/'reuse-build.ninja';p.write_text(''.join(result),encoding='utf-8');record['reused_manifest_sha256']=sha(p)
(out/'native-reuse.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
args=['ninja','-C',str(build),'-f',str(p),'-n','hyle_compute_provider_ggml_vulkan_tests','hyle_compute_route_vulkan_tests','hyle_graph_route_vulkan_tests']
r=subprocess.run(args,text=True,capture_output=True);(out/'reuse-dry-plan.log').write_text(r.stdout+'\n'+r.stderr,encoding='utf-8')
counts={x:r.stdout.count(x) for x in ('Building CXX object','Building C object','Building CUDA object','Linking','Generating','Performing build step')}
record.update(dry_plan_exit=r.returncode,counts=counts)
(out/'native-reuse.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'reused':len(record['reused']),'remaining':len(record['not_reused']),'counts':counts,'exit':r.returncode}),flush=True)
assert r.returncode==0
