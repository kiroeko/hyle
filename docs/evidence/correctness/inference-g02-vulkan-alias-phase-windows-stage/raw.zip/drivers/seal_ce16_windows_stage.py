from pathlib import Path
import hashlib, json, subprocess, zipfile

root=Path.cwd();base=root/'.scratch/inference-gaps/g02'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
normal=read(base/'vulkan-phase-normal-fix-4/result.json')
assert normal['state']=='TERMINAL_TARGETED_PASS'
for a in normal['artifacts']:assert sha(Path(a['path']))==a['sha256']
for stage in ('provider','direct-phase','direct-chain','graph'):
 import xml.etree.ElementTree as ET
 tree=ET.parse(base/'vulkan-phase-normal-fix-4'/f'{stage}.xml').getroot()
 assert tree.attrib['tests']=='1' and tree.attrib['failures']=='0' and tree.attrib['errors']=='0' and not tree.findall('.//skipped')
diff=read(base/'resume-windows-3/native-tree-diff.json')
old=Path(diff['old_root']);new=Path(diff['new_root'])
oldfiles={p.relative_to(old).as_posix():p for p in old.rglob('*') if p.is_file()}
newfiles={p.relative_to(new).as_posix():p for p in new.rglob('*') if p.is_file()}
assert oldfiles.keys()==newfiles.keys() and len(newfiles)==2263
rows=[{'path':n,'before_sha256':sha(oldfiles[n]),'after_sha256':sha(newfiles[n])} for n in sorted(oldfiles)]
assert [r['path'] for r in rows if r['before_sha256']!=r['after_sha256']]==['src/ggml-vulkan/vulkan-shaders/unary.comp']
manifest=base/'resume-windows-3/full-native-input-shas.json'
manifest.write_text(json.dumps({'roots':diff,'files':rows},indent=2)+'\n',encoding='utf-8')
dest=root/'evidence/correctness/inference-g02-vulkan-alias-phase-windows-stage';dest.mkdir(exist_ok=False)
folders=['resume-windows-3','resume-windows-4']+[f'vulkan-phase-normal-fix-{i}' for i in range(1,5)]
drivers=['prepare_vulkan_phase_fix.py','freeze_phase_native_reuse.py','freeze_phase_native_reuse_4.py']+[f'validate_vulkan_phase_normal_fix{s}.py' for s in ('','_2','_3','_4')]
entries=[]
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in folders:
  for p in sorted((base/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(base).as_posix());entries.append(p.relative_to(base).as_posix())
 for name in drivers+['seal_ce16_windows_stage.py']:
  p=base/name;z.write(p,'drivers/'+name);entries.append('drivers/'+name)
receipt={'kind':'G02_CE15_CE16_NORMAL_WINDOWS_FINITE_STAGE','verdict':'PASS_FOUR_TARGETED_CASES_ONLY',
 'product_source':normal['candidate'],'evidence_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'scope':'Normal current-input source build, conflicting independent output bindings,18-position F32 phase oracle, original full DeepSeek Direct and Graph consumers. No full851 or SDK/Air/risk/wholeG02 acceptance.',
 'normal':normal,'configure':[read(base/f'resume-windows-{i}/prepare.json') for i in (3,4)],
 'native_reuse':{'objects':321,'generated_inputs':151,'actual_post_build_shas_verified':True,'full_input_manifest':'raw.zip/resume-windows-3/full-native-input-shas.json','manifest_sha256':sha(manifest),'changed_native_files':diff['changed'],'final_stage_cuda_compilations':0,'history':'One precise-unary CUDA TU conservatively rebound during earlier build because prior dependency evidence unavailable;149 existing main vendor CUDA objects retained. Full exact compiler blocks/dependencies/object SHAs and pre/post generated input SHAs archived.'},
 'prior_attempts':[{'attempt':i,'result':read(base/f'vulkan-phase-normal-fix-{i}/result.json')} for i in (1,2,3)],
 'history':'Original build errors preserved: test-only explicit double-to-float cast and missing Direct private fixture include corrected without product/tolerance changes. Setup assertion falsely requiring an already-built CUDA TU retained separately. Actual final build48.844s and all original elapsed retained.',
 'pending':['Original Vulkan851 default cases (in progress, one known pooled-indexer numerical failure; no aggregate PASS)','CE15/16 affected static/shared, Air and new metadata capacity/cleanup risk qualification'],
 'limits':['RTX4070 SM89 driver617.14; no new performance or token/s claim','No CUDA804 repeat or whole-library build','Finite original encoded attention P1 unaffected by alias-conflict and Sin/Cos branches, reused under active card'],
 'raw_entries':len(entries),'raw_zip_sha256':sha(dest/'raw.zip')}
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ('verdict','raw_entries','raw_zip_sha256')}))
