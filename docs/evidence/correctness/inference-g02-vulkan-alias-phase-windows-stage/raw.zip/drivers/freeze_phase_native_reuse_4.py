from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path.cwd()
base = root / '.scratch/inference-gaps/g02'
build = Path('C:/h7/inference-g02-impacted')
out = base / 'resume-windows-4'
old = base / 'resume-windows-3'
assert json.loads((out / 'prepare.json').read_text())['state'] == 'TERMINAL_PREPARATION_ONLY'
assert not (out / 'native-reuse.json').exists()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def blocks(text):
    lines = text.splitlines(keepends=True)
    result = {}
    index = 0
    while index < len(lines):
        if not lines[index].startswith('build '):
            index += 1
            continue
        start = index
        index += 1
        while index < len(lines) and (not lines[index].strip() or lines[index].startswith((' ', '\t'))):
            index += 1
        result[lines[start].split(': ', 1)[0][6:]] = (start, index, lines[start:index])
    return lines, result

record = json.loads((old / 'native-reuse.json').read_text())
for entry in record['reused']:
    assert sha(Path(entry['output'])) == entry['sha256']
for path, digest in record['post_build_generated_inputs'].items():
    assert sha(Path(path)) == digest
original = (build / 'build.ninja').read_text()
frozen, count = re.subn(r'^build [^\n]*: RERUN_CMAKE[^\n]*\n(?:[ \t][^\n]*\n|\n)*', '', original, flags=re.M)
assert count == 1
(out / 'frozen-build.ninja').write_text(frozen)
old_lines, old_blocks = blocks((old / 'frozen-build.ninja').read_text())
lines, new_blocks = blocks(frozen)
replacements = {}
for entry in record['reused']:
    output = str(Path(entry['output']).relative_to(build))
    previous = old_blocks[output][2]
    start, end, current = new_blocks[output]
    assert previous == current, 'Native compiler edge changed: ' + output
    replacements[start] = (end, ['build ' + output + ': phony\n', '\n'])
result = []
index = 0
while index < len(lines):
    if index in replacements:
        index, replacement = replacements[index]
        result.extend(replacement)
    else:
        result.append(lines[index])
        index += 1
manifest = out / 'reuse-build.ninja'
manifest.write_text(''.join(result))
record.update(scope='Exact prior321 native object receipts carried after test-only Direct include registration. Full current compiler blocks identical, all object/input SHA retained. No native product changes or broad rebuild.',
              previous_reuse_receipt=str(old / 'native-reuse.json'),
              previous_reuse_receipt_sha256=sha(old / 'native-reuse.json'),
              source_manifest_sha256=sha(out / 'frozen-build.ninja'),
              reused_manifest_sha256=sha(manifest))
args = ['ninja', '-C', str(build), '-f', str(manifest), '-n',
        'hyle_compute_provider_ggml_vulkan_tests', 'hyle_compute_route_vulkan_tests', 'hyle_graph_route_vulkan_tests']
run = subprocess.run(args, capture_output=True, text=True)
(out / 'reuse-dry-plan.log').write_text(run.stdout + '\n' + run.stderr)
record['dry_plan_exit'] = run.returncode
record['counts'] = {name: run.stdout.count(name) for name in ['Building CXX object', 'Building C object', 'Building CUDA object', 'Linking', 'Generating']}
(out / 'native-reuse.json').write_text(json.dumps(record, indent=2) + '\n')
assert run.returncode == 0
assert record['counts']['Building CUDA object'] == 0
print(json.dumps({'reused': len(record['reused']), 'counts': record['counts']}))
