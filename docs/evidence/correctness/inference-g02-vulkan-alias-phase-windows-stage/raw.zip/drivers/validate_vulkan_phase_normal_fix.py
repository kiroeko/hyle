from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import xml.etree.ElementTree as ET

root = Path.cwd()
base = root / '.scratch/inference-gaps/g02'
out = base / 'vulkan-phase-normal-fix-1'
out.mkdir(exist_ok=False)
build = Path('C:/h7/inference-g02-impacted')
manifest = base / 'resume-windows-3/reuse-build.ninja'
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
registry = json.loads((root / 'docs/implementation/module-status.json').read_text(encoding='utf-8-sig'))
owner = next(m for m in registry['modules'] if m['module'] == 'compute_provider_ggml_vulkan')
assert owner['state'] == 'CANDIDATE' and owner['candidate'] == '2b60d9a34be12fda9a9e3fdc26f7a61b495c3be7'
env = {k.upper(): v for k, v in os.environ.items()}
for line in subprocess.check_output(['cmd', '/d', '/c', str(base / 'resume-windows-2/vs-env.cmd')], text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key.upper()] = value
env['HYLE_D5_QWEN35_FIXTURE'] = json.loads((base / 'current-model-fixture.json').read_text())['root']
record = {'state': 'SETUP', 'candidate': owner['candidate'], 'stages': [],
          'scope': 'Finite alias/phase regression and actual Direct/Graph DeepSeek case, no full-factor or whole-G02 claim',
          'resource_policy': 'Ninja max4, below-normal, serialized native tests, no P1/CUDA build'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')

def run(stage, args):
    start = time.monotonic()
    with (out / (stage + '.log')).open('w') as log:
        child = subprocess.Popen(args, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT,
                                 creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        record.update(state='RUNNING', stage=stage, pid=child.pid)
        save()
        print(stage, child.pid, flush=True)
        code = child.wait()
    record['stages'].append({'stage': stage, 'command': args, 'exit_code': code,
                             'elapsed_seconds': time.monotonic() - start})
    save()
    if code:
        record['state'] = 'TERMINAL_FAIL'
        save()
        print((out / (stage + '.log')).read_text(errors='replace')[-6000:], flush=True)
        raise SystemExit(code)

save()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
reuse = json.loads((base/'resume-windows-3/native-reuse.json').read_text());assert reuse['dry_plan_exit']==0 and reuse['reused']
for entry in reuse['reused']:assert sha(Path(entry['output']))==entry['sha256']
targets = ['hyle_compute_provider_ggml_vulkan_tests', 'hyle_compute_route_vulkan_tests', 'hyle_graph_route_vulkan_tests']
args = ['ninja', '-C', str(build), '-f', str(manifest), '-j', '4']
run('dry-plan', args + ['-n'] + targets)
dry = (out / 'dry-plan.log').read_text()
cuda_rows=[line for line in dry.splitlines() if 'Building CUDA object' in line]
assert len(cuda_rows)==1 and 'ggml-cuda-precise-unary.dir' in cuda_rows[0] and 'unary.cu.obj' in cuda_rows[0]
record['conservative_cuda_rebind']=cuda_rows
save()
run('build', args + targets)
for entry in reuse['reused']:assert sha(Path(entry['output']))==entry['sha256'],'reused object changed'
for path,digest in reuse['post_build_generated_inputs'].items():assert sha(Path(path))==digest,'generated input changed; rebuild affected object before tests: '+path
record['reused_objects_unchanged_after_build']=len(reuse['reused'])
record['generated_inputs_unchanged_after_build']=len(reuse['post_build_generated_inputs'])
save()
for stage, executable, case in [
    ('provider', 'hyle_compute_provider_ggml_vulkan_test.exe', 'GgmlVulkanRegion.PublishedReshapesBindIndependentInputAndOutputStorage'),
    ('direct-phase', 'hyle_compute_route_vulkan_test.exe', 'VulkanView.ExplicitFrequencyRopeRetainsAccuracyAtInferencePositions'),
    ('direct-chain', 'hyle_compute_route_vulkan_test.exe', 'VulkanMoeFragments.D5DeepSeekFullAttentionChain'),
    ('graph', 'hyle_graph_route_vulkan_test.exe', 'VulkanGraphMoeFragments.D5DeepSeekFullAttentionChain'),
]:
    run(stage, [str(build / 'bin' / executable), '--gtest_filter=' + case, '--gtest_color=no',
                '--gtest_output=xml:' + str(out / (stage + '.xml'))])
    xml = ET.parse(out / (stage + '.xml')).getroot()
    assert int(xml.attrib['tests']) == 1 and int(xml.attrib['failures']) == 0 and int(xml.attrib['errors']) == 0
    tests = xml.findall('.//testcase')
    assert len(tests) == 1 and tests[0].find('skipped') is None
record.update(state='TERMINAL_TARGETED_PASS', artifacts=[
    {'path': str(build / 'bin' / name), 'sha256': sha(build / 'bin' / name)} for name in
    ['hyle_compute_provider_ggml_vulkan.dll', 'hyle_compute_provider_ggml_vulkan_test.exe', 'hyle_compute_route_vulkan_test.exe', 'hyle_graph_route_vulkan_test.exe']])
save()
print(json.dumps(record), flush=True)
