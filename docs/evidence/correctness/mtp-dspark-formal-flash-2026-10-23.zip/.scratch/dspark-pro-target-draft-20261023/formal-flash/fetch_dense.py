"""Root-only exact acquisition of the97 formal Flash draft nonexpert roles.

Reuses CA's bounded/resumable authenticated downloader without copying it.
No request occurs when this wrapper is imported.
"""
from pathlib import Path
import importlib.util

S = Path(__file__).resolve().parent
R = S.parents[2]


def main():
    spec = importlib.util.spec_from_file_location(
        '_hyle_formal_flash_dense_acquisition', S.parent / 'fetch_dense.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('Existing CA dense acquisition helper was not found')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.S, helper.R = S, R
    helper.COUNT, helper.BODY_BYTES = 97, 595182108
    return helper.main(plan_path=S / 'dense-plan.json', out=S / 'original-dense')


if __name__ == '__main__':
    main()
