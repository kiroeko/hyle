"""Prepare the fixed97-role formal Flash draft plan from authenticated headers.

Metadata only. Excludes target, vocabulary and every routed expert payload.
The existing CA downloader consumes the same exact-range plan format.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math

S = Path(__file__).resolve().parent
R = S.parents[2]
REPOSITORY = 'deepseek-ai/DeepSeek-V4-Flash-0731'
REVISION = '7872f01b1d1fe23eabc4c98b48bffcef5a386062'
FILES = tuple(f'model-{number:05d}-of-00048.safetensors' for number in (46, 47, 48))


def main():
    spec = importlib.util.spec_from_file_location(
        '_hyle_formal_flash_dense_plan_metadata', S.parent / 'prepare_dense_plan.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('Existing CA plan metadata helper was not found')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    read, width = helper.read, helper.WIDTH
    summary = read(S / 'headers/summary.json')
    expected = read(S / 'review/dense-selection.json')
    assert summary['complete'] and not summary['whole_shards_downloaded']
    assert summary['repository'] == expected['repository'] == REPOSITORY
    assert summary['revision'] == expected['revision'] == REVISION
    assert expected['original_roles'] == 97 and expected['bundle_bytes'] == 595182108
    assert not any(expected[key] for key in ('includes_vocabulary', 'includes_target', 'includes_experts'))
    records = {row['file']: row for row in summary['shards']}
    pinned = {row['file']: row for row in expected['shards']}
    assert set(records) == set(pinned) == set(FILES)
    selected = {row['name']: row for row in expected['roles']}
    assert len(selected) == 97
    roles, shards, deferred = [], [], []
    for shard, file in enumerate(FILES):
        record = records[file]
        assert record['complete'] and not record['whole_shard_downloaded']
        raw = (R / record['header']['path']).read_bytes()
        assert len(raw) == record['header']['bytes'] == pinned[file]['header_bytes']
        assert hashlib.sha256(raw).hexdigest() == record['header']['sha256'] == pinned[file]['header_sha256']
        assert record['data_base'] == 8 + len(raw)
        header = json.loads(raw)
        shards.append({key: record[key] for key in
                       ('file', 'url', 'whole_file_bytes', 'etag', 'data_base', 'header')})
        expert_count = expert_bytes = 0
        for name, value in header.items():
            if name == '__metadata__':
                continue
            assert name.startswith(f'mtp.{shard}.')
            start, end = value['data_offsets']
            extent = math.prod(value['shape']) * width[value['dtype']]
            assert 0 <= start < end and extent == end - start
            first = record['data_base'] + start
            assert first + extent <= record['whole_file_bytes']
            if '.experts.' in name:
                assert name not in selected
                expert_count += 1
                expert_bytes += extent
                continue
            wanted = selected[name]
            assert wanted['dtype'] == value['dtype'] and wanted['shape'] == value['shape']
            assert wanted['bytes'] == extent and wanted['source_shard'] == shard
            roles.append(dict(index=len(roles), name=name, kind='draft_static',
                              dtype=value['dtype'], shape=value['shape'], bytes=extent,
                              source_shard=shard, data_relative_half_open=[start, end],
                              absolute_inclusive=[first, first + extent - 1]))
        assert expert_count == 1536 and expert_bytes == 3422552064
        deferred.append(dict(source_shard=shard, file=file, roles=expert_count,
                             payload_bytes=expert_bytes, acquired=False,
                             source_prefix=f'mtp.{shard}.', domain=256,
                             hidden=4096, intermediate=2048,
                             selection='Only actual selected global IDs; absent original bytes must fail'))
    assert len(roles) == 97 and {row['name'] for row in roles} == set(selected)
    groups, offset = [], 0
    for shard in range(3):
        previous = None
        for row in sorted((row for row in roles if row['source_shard'] == shard),
                          key=lambda row: row['absolute_inclusive'][0]):
            first, last = row['absolute_inclusive']
            if previous is None or first != previous['last'] + 1:
                previous = dict(index=len(groups), source_shard=shard, first=first,
                                last=last, bundle_offset=offset, bytes=row['bytes'])
                groups.append(previous)
            else:
                previous['last'] = last
                previous['bytes'] += row['bytes']
            row['bundle_offset'] = offset
            offset += row['bytes']
    ordered = sorted(roles, key=lambda row: row['bundle_offset'])
    assert offset == 595182108 and sum(row['bytes'] for row in groups) == offset
    assert all(row['bundle_offset'] == sum(part['bytes'] for part in ordered[:index])
               for index, row in enumerate(ordered))
    assert all(group['last'] - group['first'] + 1 == group['bytes'] for group in groups)
    plan = dict(repository=REPOSITORY, revision=REVISION, original_roles=97,
                bundle_bytes=offset, whole_shards_downloaded=False,
                expert_payloads_included=False, vocabulary_payloads_included=False,
                target_payloads_included=False,
                typed_order='Original97 draft nonexpert roles in the authenticated header order; no target/vocabulary/expert roles',
                counts={'draft_static': dict(roles=97, bytes=offset)},
                shards=shards, roles=roles, groups=groups, deferred_experts=deferred,
                scope='Formal Flash0731 mtp.0/1/2 nonexpert parameters only; original BF16/E4/UE8/F32 names and byte planes. Metadata acquisition plan, no execution claim.')
    (S / 'dense-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(roles=len(roles), bytes=offset, groups=len(groups),
                         stage_counts=[sum(row['source_shard'] == stage for row in roles)
                                       for stage in range(3)])), flush=True)


if __name__ == '__main__':
    main()
