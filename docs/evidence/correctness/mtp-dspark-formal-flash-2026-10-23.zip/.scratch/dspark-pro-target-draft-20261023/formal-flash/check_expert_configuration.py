from pathlib import Path
import ast,hashlib,importlib.util,json,types
S=Path('.scratch/dspark-pro-target-draft-20261023').resolve();O=S/'formal-flash'
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
paths=[S/'fetch_experts.py',S/'fetch_dense.py',S/'run_with_supply.py',O/'fetch_experts.py',O/'run_with_supply.py']
for p in paths:ast.parse(p.read_text())
wrapper=load('formal_flash_expert_config_check',O/'fetch_experts.py');helper=wrapper.configured_helper()
# No main(), child launch, mkdir, payload allocation or HTTP path is called.
headers,receipt=helper.fixed_headers();assert len(headers)==3
count=0
for stage in range(3):
 for global_id in range(256):
  plan=helper.make_plan(headers,receipt,'draft',stage,global_id)
  assert plan['repository']==wrapper.REPOSITORY and plan['revision']==wrapper.REVISION
  assert len(plan['roles'])==6 and plan['bundle_bytes']==13369344
  assert len(plan['groups'])==6 and sum(row['bytes'] for row in plan['roles'])==13369344
  assert all(row['name'].startswith(f'mtp.{stage}.ffn.experts.{global_id}.') for row in plan['roles'])
  assert plan['shards'][0]['file']==f'model-{46+stage:05d}-of-00048.safetensors'
  assert [row['shape'] for row in plan['roles']]==[[2048,2048],[2048,128],[2048,2048],[2048,128],[4096,1024],[4096,64]]
  count+=1
rejected=[]
for section,stage,global_id in [('target',0,0),('draft',-1,0),('draft',3,0),('draft',0,-1),('draft',0,256),('draft',0,True)]:
 try:helper.make_plan(headers,receipt,section,stage,global_id)
 except ValueError:rejected.append([section,stage,global_id])
 else:raise AssertionError('Invalid Flash expert plan was accepted')
for section,stage,ids in [('target',0,[0]),('draft',0,[256]),('draft',0,[True])]:
 try:helper.selection(types.SimpleNamespace(frontier_file=None,section=section,stage=stage,ids=ids))
 except ValueError:pass
 else:raise AssertionError('Invalid Flash CLI selection was accepted')
assert helper.selection(types.SimpleNamespace(frontier_file=None,section='draft',stage=2,ids=[255,0,255]))==('draft',2,[0,255])
# Confirm configured helper retained canonical downloader, not Flash97 CLI.
assert Path(helper.fetch_dense.__file__).resolve()==S/'fetch_dense.py'
assert helper.fetch_dense.main.__code__.co_argcount==2
# Loading a separate untouched-default helper cannot inherit Flash globals.
previous=__import__('sys').modules.get('fetch_dense');__import__('sys').modules['fetch_dense']=wrapper.load_helper('_pro_default_dense_check',S/'fetch_dense.py')
try:default=wrapper.load_helper('_pro_default_expert_check',S/'fetch_experts.py')
finally:
 if previous is None:__import__('sys').modules.pop('fetch_dense',None)
 else:__import__('sys').modules['fetch_dense']=previous
assert (default.REPOSITORY,default.REVISION,default.DOMAIN,default.EXPERT_BYTES,default.HIDDEN,default.INTERMEDIATE,default.TOTAL_SHARDS,default.HEADER_COUNT,default.SECTIONS)==('deepseek-ai/DeepSeek-V4-Pro-0813','72e1d3230f6c080a530b0a1d46f8eb4602340597',384,35094528,7168,3072,66,8,('target','draft'))
assert default.EXPECTED_HEADERS is None
pro_headers,pro_receipt=default.fixed_headers()
for section,stage,global_id in [('target',0,0),('draft',2,383)]:assert default.make_plan(pro_headers,pro_receipt,section,stage,global_id)['bundle_bytes']==35094528
watch=load('formal_flash_driver_config_check',O/'run_with_supply.py').configured_helper()
assert (watch.DOMAIN,watch.SECTIONS,watch.WAIT_ENV,watch.FRONTIER_ENV)==(256,('draft',),'HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS','HYLE_DSPARK_FLASH_FRONTIER_FILE')
assert watch.S==O and watch.R==S.parents[1]
normal=load('_pro_default_driver_check',S/'run_with_supply.py')
assert (normal.DOMAIN,normal.SECTIONS,normal.WAIT_ENV,normal.FRONTIER_ENV)==(384,('target','draft'),'HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS','HYLE_DSPARK_PRO_FRONTIER_FILE')
metadata={'scope':'Offline header/shape/range/configuration only. No network/body, cache creation, subprocess/driver main, compile, native or product-source modification.','configured_repository':wrapper.REPOSITORY,'configured_revision':wrapper.REVISION,'authenticated_actual_headers':3,'all_draft_expert_plans_checked':count,'domain':256,'hidden':4096,'intermediate':2048,'roles_per_expert':6,'raw_bytes_per_expert':13369344,'target_frontier_rejected':True,'negative_overflow_bool_ids_rejected':True,'stage_bounds_rejected':True,'actual_downloader_module':str(Path(helper.fetch_dense.__file__).relative_to(S.parents[1])),'same_single_writer_cache_lock_and_authenticated_resume':True,'Pro_defaults_and_two_original_plans_checked':True,'driver_flash_env_and_domain_checked':True,'new_expert_cache_created':False,'source_files':[{'path':p.relative_to(S.parents[1]).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]}
(O/'review/expert-wrapper-checks.json').write_text(json.dumps(metadata,indent=2)+'\n')
p=O/'review/expert-wrapper-source.json';d=json.loads(p.read_text())
for row in d['common_helpers']:
 if 'before_sha256' in row:row['before_normalized_lf_sha256']=row.pop('before_sha256')
p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(metadata))
