"""Root-only publication of formal Flash and shared-source Pro regressions.

Example after the named runs terminate successfully:
  python formal-flash/publish.py --flash-runs 7 9 --pro-runs 8
Reuses CA metadata validators; no native/build/network or weight-body hash pass.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

F = Path(__file__).resolve().parent
S, R = F.parent, F.parents[2]
spec = importlib.util.spec_from_file_location('_formal_flash_metadata', S / 'publish.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
h.REPO = 'deepseek-ai/DeepSeek-V4-Flash-0731'
h.REV = '7872f01b1d1fe23eabc4c98b48bffcef5a386062'
h.TEXT.add('.patch')
PRO_REFERENCE = dict(path='docs/evidence/correctness/mtp-dspark-pro-target-verifier-2026-10-23.json',
    bytes=584249, sha256='3fae85a21636cb2d3e34dacd10b63189964f76e88bc5bc50dd2b0a4808b73ca1')
PRO_ARCHIVE = dict(path='docs/evidence/correctness/mtp-dspark-pro-target-verifier-2026-10-23.zip',
    bytes=3071885, sha256='fff3c30f815a1cf00882eee73902c3b0903879123d62fff11a2e65f5897deda0')
SUFFIX = 'OriginalTargetTailAndFormalDraftPublishesBlock5Prefix'
EXPECTED = {(suite, backend + SUFFIX) for suite in ('DSparkFlashFormalState', 'DSparkProOriginalState')
            for backend in ('Cpu', 'Cuda')}


def previous_artifacts():
    # Durable references replace copying the prior evidence/archive again.
    previous = h.read(h.verify(PRO_REFERENCE))
    assert previous['artifact']['repository'] == 'deepseek-ai/DeepSeek-V4-Pro-0813'
    assert previous['archive'] == PRO_ARCHIVE
    h.verify(PRO_ARCHIVE)
    target_evidence = h.read(h.verify(h.ANCHOR))
    assert target_evidence['artifact']['repository'] == h.REPO
    target = target_evidence['artifact']
    assert (target['original_target_roles'], target['original_target_bytes']) == (4725, 10748569116)
    h.verify(target['typed_catalog'])
    assert h.resolve(target['bundle']['path']).stat().st_size == target['bundle']['bytes']
    archive = target_evidence['archive']
    h.verify(archive)
    directory = R / '.scratch/qwen-mtp-state-20261023/original-dspark-vocabulary'
    receipt = h.read(directory / 'acquisition.json')
    assert receipt['repository'] == h.REPO and receipt['revision'] == h.REV
    expected = {'embed.weight': 'c05019ecf9435fa47cdcbb35df74c8ade6c4ceedd6ebe75db9ea7a607f6ad2ef',
                'head.weight': '029e3c5293b29cc426e21d87795e15efa4d363f27b2bc4a9e3aef7d79f047919'}
    vocabulary = []
    for name, pin in expected.items():
        row = receipt['roles'][name]
        assert row['complete'] and row['dtype'] == 'BF16' and row['shape'] == [129280, 4096]
        assert row['bytes'] == 1059061760 and row['sha256'] == pin
        path = h.resolve(row['path'])
        assert path == directory / (name + '.bf16') and path.stat().st_size == row['bytes']
        vocabulary.append(dict(name=name, path=row['path'], bytes=row['bytes'], sha256=pin,
                               body_rehashed=False, body_archived=False))
    return dict(previous_Pro=dict(evidence=PRO_REFERENCE, archive=PRO_ARCHIVE),
        original_target=dict(evidence=h.ANCHOR, archive=archive, roles=4725, bytes=10748569116,
            typed_catalog=target['typed_catalog'], body=target['bundle'], body_rehashed=False, body_archived=False),
        vocabulary=dict(receipt=h.identity(directory / 'acquisition.json'), roles=vocabulary,
                        source_bytes=2118123520, copied_or_downloaded_again=False))


def artifacts():
    dense, plan, _ = h.acquisition(F / 'original-dense', 97, 595182108)
    source = (R / 'tests/compute_models/dspark_original_formal_roles.h').read_text(encoding='utf-8-sig')
    pin = re.search(r'kFlashDraftIndexSha256\s*=\s*"([0-9a-f]{64})"', source).group(1)
    assert pin == dense['typed_catalog']['sha256']
    assert plan['target_payloads_included'] is False and plan['vocabulary_payloads_included'] is False
    assert plan['expert_payloads_included'] is False
    sparse = {}
    for receipt_path in sorted((F / 'original-experts').glob('*/stage*/expert*/acquisition.json')):
        row = h.read(receipt_path)
        if row.get('complete') is not True:
            continue
        section, stage, ids = row['section'], row['stage'], row['global_ids']
        assert section == 'draft' and stage in range(3) and len(ids) == 1 and ids[0] in range(256)
        assert receipt_path.parent == F / 'original-experts/draft' / f'stage{stage}' / f'expert{ids[0]:03d}'
        item, planned, acquired = h.acquisition(receipt_path.parent, 6, 13369344)
        assert all(planned[k] == acquired[k] == row[k] for k in ('section', 'stage', 'global_ids'))
        names = [f'mtp.{stage}.ffn.experts.{ids[0]}.{leg}.{kind}'
                 for leg in ('w1', 'w3', 'w2') for kind in ('weight', 'scale')]
        assert [role['name'] for role in planned['roles']] == names
        assert [role['dtype'] for role in planned['roles']] == ['I8', 'F8_E8M0'] * 3
        sparse[(section, stage, ids[0])] = dict(stage=stage, global_id=ids[0], **item)
    assert sparse, 'No authenticated actual selected formal Flash draft expert source'
    return dict(repository=h.REPO, revision=h.REV, dense=dense,
        composed_named_dense=dict(roles=216, source_bytes=3194218552,
            parts=dict(new_draft=97, reused_target_static=113, reused_target_final=4, reused_vocabulary=2),
            concatenated_body_created=False),
        actual_selected_draft_cache=list(sparse.values()),
        cache_scope='Authenticated available original cache, including earlier attempts; driver requests identify newly missing subsets. Inventory is not an exact per-case executed-ID trace.',
        expert_format='Original E2M1 packed nibbles and UE8M0 per32; only selected scales widen for residency. No GGUF surrogate or whole-expert F32 shadow.'), sparse


def completed_run(attempt, source, sparse):
    folder = S / f'checks{attempt}'
    summary = h.read(h.add(folder / 'summary.json'))
    assert summary['source'] == source
    assert summary['process']['exit'] == 0 and not summary['process']['timed_out']
    assert not any(summary[key] for key in ('failures', 'errors', 'disabled', 'skips'))
    assert all(summary.get(key) is False for key in ('throughput_evidence', 'physical_memory_evidence', 'whole_original_model'))
    linked = h.linked_image(summary['image'])
    command = summary['process']['command']
    driver_script = (F if source == 'flash' else S) / 'run_with_supply.py'
    assert h.resolve(command[1]) == driver_script
    assert h.resolve(command[command.index('--image') + 1]) == h.resolve(summary['image']['path'])
    assert h.verify(summary['supply_driver']) == driver_script
    frontier = h.resolve(command[command.index('--frontier-file') + 1])
    assert frontier.parent == folder
    driver_path = h.add(frontier.with_name(frontier.stem + '.driver.json'))
    driver = h.read(driver_path)
    assert driver['exit'] == driver['native']['exit'] == 0 and not driver['native'].get('stopped_by_driver', False)
    assert driver['driver_pid'] == summary['process']['pid'] and driver['native']['pid'] > 0
    assert h.resolve(driver['native']['command'][0]) == h.resolve(summary['image']['path'])
    assert driver['native']['command'][1:] == command[command.index('--') + 1:]
    for fetch in driver['fetches']:
        assert fetch['exit'] == 0 and not fetch.get('stopped_by_driver', False)
        request = fetch['request']
        assert set(request['missing_ids']) <= set(request['global_ids'])
        if source == 'flash':
            assert request['section'] == 'draft'
            assert all(('draft', request['stage'], global_id) in sparse for global_id in request['missing_ids'])
    xml = ET.parse(h.add(folder / 'results.xml')).getroot()
    actual = [dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value']
              for p in case.iter('property')}) for case in xml.iter('testcase')]
    assert actual == summary['cases'] and summary['tests'] == len(actual) > 0
    counts = {}
    for case in actual:
        a, p = case['attributes'], case['properties']
        key = (a['classname'], a['name'])
        assert key in EXPECTED and a['status'] == 'run' and a['result'] == 'completed'
        assert a['classname'] == ('DSparkFlashFormalState' if source == 'flash' else 'DSparkProOriginalState')
        for name, value in dict(dense_original_roles=216, dense_original_source_bytes=3194218552 if source == 'flash' else 6504119672,
                state_members=30, first_target_fullV_values=775680, first_draft_fullV_values=646400).items():
            assert h.number(p, name) == value, (key, name, p.get(name))
        assert h.number(p, 'state_backing_peak') <= h.number(p, 'state_backing_budget')
        assert h.number(p, 'natural_accepted_drafts') <= 5
        assert p['controlled_prefixes'] == '0,2,5; prefix policy only, not natural acceptance'
        assert h.number(p, 'actual_pending_feedback') == h.number(p, 'actual_draft_episodes') >= 2
        assert h.number(p, 'natural_proposal1') < 129280 and h.number(p, 'natural_target0') < 129280
        for name in ('actual_target_rows', 'actual_main_projection_submissions', 'actual_main_history_submissions',
                     'actual_verifier_submissions', 'target_resident_slot_bytes', 'draft_resident_slot_bytes'):
            assert h.number(p, name) > 0
        if source == 'flash':
            assert h.number(p, 'actual_expert_attachments') <= len(sparse)
        counts['.'.join(key)] = h.number(p, 'actual_submissions')
        assert counts['.'.join(key)] > 0
    for path in folder.iterdir():
        if path.is_file() and path.suffix.lower() in h.TEXT:
            h.add(path)
    for host in linked['hosts']:
        for path in h.resolve(host['record']['path']).parent.iterdir():
            if path.is_file() and path.suffix.lower() in h.TEXT:
                h.add(path)
    return dict(summary=h.identity(folder / 'summary.json'), process=summary['process'],
        driver=h.identity(driver_path), driver_processes=driver, source=source, linked=linked,
        cases=actual, graph_submissions_by_case=counts)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--flash-runs', type=int, nargs='+', required=True)
    parser.add_argument('--pro-runs', type=int, nargs='+', required=True)
    args = parser.parse_args()
    all_runs = args.flash_runs + args.pro_runs
    assert min(all_runs) > 0 and len(set(all_runs)) == len(all_runs)
    protected = h.protect()
    reused = previous_artifacts()
    artifact, sparse = artifacts()
    runs = [completed_run(attempt, 'flash', sparse) for attempt in args.flash_runs]
    runs += [completed_run(attempt, 'pro', sparse) for attempt in args.pro_runs]
    seen = [(case['attributes']['classname'], case['attributes']['name']) for run in runs for case in run['cases']]
    assert len(seen) == 4 and set(seen) == EXPECTED
    graphs = {name: count for run in runs for name, count in run['graph_submissions_by_case'].items()}
    for relative in ('publish.py', 'fetch_headers.py', 'prepare_dense_plan.py', 'fetch_dense.py',
            'fetch_experts.py', 'run_with_supply.py', 'check_expert_configuration.py',
            'review/expert-wrapper-checks.json',
            'review/expert-wrapper-source.json', 'review/expert-common-config.patch',
            'next-source/formal-flash.patch', 'next-source/manifest.json', 'next-source/source-checks.json'):
        h.add(F / relative)
    for name in ('publish.py', 'build.py', 'fetch_experts.py', 'fetch_dense.py', 'run_with_supply.py',
                 'obsolete-pro-source-removal.json', 'review/w04-formal-draft-sharing.json'):
        h.add(S / name)
    assert h.protect() == protected
    # The earlier durable evidence/archive remains an exact reference, not
    # another copy inside this batch's zip.
    h.files.discard(h.resolve(h.ANCHOR['path']))
    destination = R / 'docs/evidence/correctness/mtp-dspark-formal-flash-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(h.files):
            zipped.write(path, path.relative_to(R).as_posix())
    record = dict(date='2026-10-23', stage='W04', goal_complete=False,
        conclusion='Formal original Flash0731 draft and original target-tail/fullV K5 consumer passed on CPU/CUDA; shared named-source Pro regressions passed.',
        artifact=artifact, reused=reused,
        implementation=dict(named_source='One Data/Geometry/profile and one ordinary native consumer. Flash97 borrows existing original target and BF16 vocabulary owners; no combined weight bundle or compatibility alias.',
            state='Same30-member atomic StateHead: current+accepted0..5, actual target/capture/main-history snapshots, actual pending row lease, continuation and immutable readers. Natural decisions and controlled0/2/5 policies remain separate.',
            numerics='Original E4/UE8/A128 and selected FP4 E2M1/UE8 per32, full first5-row draft and6-row target scores, original Markov/confidence, actual BF16 boundary/reference gates retained.',
            source_scope='Full256-ID Flash expert domain with actual selected original draft experts. Existing original target expert mappings are borrowed; cache inventory is not a claim all draft experts executed.',
            build='Two existing related host TUs incrementally compiled and linked with the current cached product/native/SDK closure; no new executor or public operation.'),
        validation=dict(tests=4, failures=0, errors=0, skips=0, graph_submissions=sum(graphs.values()),
            graph_submissions_by_case=graphs, runs=runs, old_failed_attempts='Retained under the exact previous CA/BZ evidence/archive references; not relabelled or recounted here.'),
        limitations=['Layer39 upstream input and initial valid prefix are explicit finite fixtures, not a complete43-layer prompt-to-output model.',
            'Pro regression retains its prior explicit layer57/prefix fixture scope. No quality, natural acceptance-rate or TPS conclusion.',
            'Only selected formal Flash draft expert bytes are newly acquired; all256 draft experts are not claimed as executed or acquired.',
            'State backing is declared-resource accounting, not measured physical RAM/VRAM peak. No weight body is rehashed or archived by this publisher.'],
        protection=protected, archive=h.identity(archive), archive_items=len(h.files))
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=h.identity(destination), archive=h.identity(archive))
    (F / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert h.protect() == protected
    print(json.dumps(dict(**publication, tests=4, graphs=record['validation']['graph_submissions'])))


if __name__ == '__main__':
    main()
