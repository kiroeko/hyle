"""Root-only exact header acquisition for the three formal Flash draft shards.

Reuses CA's unchanged HTTP206/header-authentication path. Importing this wrapper
does not access the network; only an explicit main() call fetches headers.
"""
from pathlib import Path
import importlib.util

S = Path(__file__).resolve().parent
R = S.parents[2]
REPOSITORY = 'deepseek-ai/DeepSeek-V4-Flash-0731'
REVISION = '7872f01b1d1fe23eabc4c98b48bffcef5a386062'
SHARDS = (46, 47, 48)
TOTAL_SHARDS = 48


def main():
    spec = importlib.util.spec_from_file_location(
        '_hyle_formal_flash_header_acquisition', S.parent / 'fetch_headers.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('Existing CA header acquisition helper was not found')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.S, helper.R = S, R
    helper.REPOSITORY, helper.REVISION = REPOSITORY, REVISION
    helper.SHARDS, helper.TOTAL_SHARDS = SHARDS, TOTAL_SHARDS
    helper.main()


if __name__ == '__main__':
    main()
