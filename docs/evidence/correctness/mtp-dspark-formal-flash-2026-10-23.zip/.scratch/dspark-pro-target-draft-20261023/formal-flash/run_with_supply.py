"""Run the existing single native validation driver with formal Flash supply.

Only root invokes main(). Importing this configuration starts no child process
and performs no acquisition. All job lifetime and watcher logic stays in CA.
"""
import importlib.util
import os
from pathlib import Path
import sys

S = Path(__file__).resolve().parent
R = S.parents[2]


def configured_helper():
    spec = importlib.util.spec_from_file_location('_hyle_flash_supply_driver', S.parent / 'run_with_supply.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('Existing CA native supply driver was not found')
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.S, helper.R = S, R
    helper.DOMAIN, helper.SECTIONS = 256, ('draft',)
    helper.WAIT_ENV = 'HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS'
    helper.FRONTIER_ENV = 'HYLE_DSPARK_FLASH_FRONTIER_FILE'
    return helper


def main():
    # The request watcher invokes this same directory's fetch_experts wrapper;
    # the native consumer must observe that exact authenticated cache root.
    os.environ['HYLE_DSPARK_FLASH_EXPERT_DIR'] = str(S / 'original-experts')
    return configured_helper().main()


if __name__ == '__main__':
    sys.exit(main())
