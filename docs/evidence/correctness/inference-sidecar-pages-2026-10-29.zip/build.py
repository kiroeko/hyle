from pathlib import Path
import importlib.util
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('previous_build',R/'.scratch/inference-multimodel-observation-20261029/build.py')
previous=importlib.util.module_from_spec(spec);spec.loader.exec_module(previous)
previous.W=W;previous.b.W=W
read,save,pin,exact,key=previous.read,previous.save,previous.pin,previous.exact,previous.key

def prepare():
    old=read(R/'.scratch/inference-multimodel-observation-20261029/plan.json')
    base=read(old['base']['path'])
    for item in old['retained']:exact(item)
    exact(old['runtime']);exact(old['sdk'])
    for unit in read(old['sdk']['path'])['engine_consumers']:
        for item in unit['source_identities']:exact(item)
    units={}
    definitions={
        'ds': ('tests/compute_models/dspark_original_state_consumer_test.cc',old['units']['ds'],
            ['/I'+str(R/'.scratch/dspark-gguf-selected-20261023/S03/generated')]),
        'qwen': ('tests/tools/qwen_host_image_test.cc',dict(compile=base['compile'],link=base['link'],
            source=base['consumer_source']['path']),[]),
        'append': ('tests/tools/inference_append_transactions_test.cc',old['units']['runner'],[]),
        'ordinary': ('tests/tools/qwen_generation_batch_relay_probe.cc',dict(compile=base['compile'],link=base['link'],
            source=base['consumer_source']['path']),[])}
    old_qwen_object=read(base['previous_consumer']['path'])['object']['path']
    for name,(file,recipe,extra) in definitions.items():
        source=R/file;folder=W/'compile'/name;folder.mkdir(parents=True,exist_ok=True)
        compile_args=[]
        for index,arg in enumerate(recipe['compile']):
            if index and recipe['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
            elif key(arg)==key(recipe['source']):arg=str(source)
            compile_args.append(arg)
        compile_args+=extra
        if name in ['ds','append']:
            original=read(R/'.scratch/inference-multimodel-observation-20261029/compile'/('ds' if name=='ds' else 'runner')/'receipt.json')['object']['path']
        else:original=old_qwen_object
        link_args=[]
        for arg in recipe['link']:
            if key(arg)==key(original):arg=str(folder/'unit.obj')
            for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
                if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
            link_args.append(arg)
        assert sum(key(arg)==key(source) for arg in compile_args)==1
        assert sum(key(arg)==key(folder/'unit.obj') for arg in link_args)==1
        units[name]=dict(source=str(source),compile=compile_args,link=link_args)
    (W/'bin').mkdir(exist_ok=True)
    shutil.copyfile(old['runtime']['path'],W/'bin'/Path(old['runtime']['path']).name)
    environments={}
    for name,relative in [('bfloat-cpu','runtime.json'),('q8-cpu','q8/runtime.json')]:
        environment={k:v for k,v in read(R/'.scratch/dspark-sidecar-random-20261024'/relative).items()
            if k.startswith('HYLE_DSPARK_') and not k.endswith('FRONTIER_FILE')}
        environment['HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS']='0'
        for k,v in environment.items():
            if k.endswith('_DIR') or k.endswith('_BF16'):assert Path(v).exists(),k
        environments[name]=environment
    fixtures=read(R/'.scratch/inference-append-tail-return-20261029/plan.json')['fixtures']
    cases={
        'q8-cpu':dict(unit='ds',filter='DSparkOriginalState.CpuRandomQ8MarkovPrefixAndPendingContinue',tests=1),
        'bfloat-cpu':dict(unit='ds',filter='DSparkBfloatSidecarState.CpuRandomBfloatMarkovPrefixAndPendingContinue',tests=1)}
    save(W/'plan.json',dict(base=old['base'],worktree_base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        units=units,retained=old['retained'],runtime=old['runtime'],sdk=old['sdk'],environments=environments,cases=cases,
        fixtures=fixtures))
    print('Prepared sidecar consumer plus available Qwen/Append recipes, reused227 SDK inputs; no builds or downloads started.')

def main():
    action=sys.argv[1]
    if action=='prepare':prepare();return
    if action in ['compile','link']:
        previous.main();return
    name=sys.argv[2];attempt=sys.argv[3] if len(sys.argv)>3 else 'attempt1'
    plan=read(W/'plan.json');case=plan['cases'][name];unit=case['unit']
    previous.receipt(unit);image=read(W/('ready-'+unit+'.json'));exact(image)
    folder=W/'runs'/name/attempt;save(folder/'image.json',image)
    os.environ.update(plan['environments'].get(name,{}))
    os.environ.update(HYLE_DSPARK_BFLOAT_FRONTIER_FILE=str(folder/'missing-bfloat-frontier.json'),
        HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
    if 'filter' in case:
        args=['--gtest_color=no','--gtest_filter='+case['filter'],'--gtest_output=xml:'+str(folder/'results.xml')]
    else:args=case['args']
    previous.b.execute([image['path'],*args],folder,600)
    if 'filter' in case:
        result=ET.parse(folder/'results.xml').getroot()
        assert result.get('tests')==str(case['tests']) and result.get('failures')=='0' and result.get('errors','0')=='0'
        assert not result.findall('.//skipped')
        report=dict(status='PASS',tests=case['tests'],failures=0,skipped=0,
            properties={p.get('name'):p.get('value') for p in result.findall('.//property')})
    else:
        report=read(folder/'stdout.log');assert report['status']=='PASS'
    save(folder/'report.json',report);print('PASS',name)

if __name__=='__main__':main()
