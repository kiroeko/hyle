from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('current_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read, save, pin, exact = b.read, b.save, b.pin, b.exact
E = R / 'docs/evidence/correctness/inference-sidecar-pages-2026-10-29.json'
SOURCES = ['engine/inference/append_transactions.h', 'engine/models/qwen35/main.cc',
    'tests/tools/inference_append_transactions_test.cc', 'tests/compute_models/dspark_original_state_consumer_test.cc']
CASES = {'q8-cpu': 'attempt1', 'bfloat-cpu': 'attempt1', 'append-cpu': 'attempt1',
    'history-cpu': 'attempt1', 'mixed-lag-cuda': 'attempt1', 'mtp-cuda': 'attempt1', 'ordinary-cuda': 'attempt2'}

def prepare():
    plan = read(W / 'plan.json')
    for unit in plan['units']: b.previous.receipt(unit)
    for item in plan['retained']: exact(item)
    exact(plan['runtime']); exact(plan['sdk'])
    for unit in read(plan['sdk']['path'])['engine_consumers']:
        for item in unit['source_identities']: exact(item)
    for name, attempt in CASES.items():
        f = W / 'runs' / name / attempt
        result, process = read(f / 'report.json'), read(f / 'process.json')
        assert result['status'] == 'PASS' and process['state'] == 'TERMINAL' and process['exit'] == 0
    assert read(W / 'runs/append-cpu/attempt1/report.json')['tests'] == 12
    for name in ['q8-cpu', 'bfloat-cpu']:
        p = read(W / 'runs' / name / 'attempt1/report.json')['properties']
        for k, value in dict(random_request_committed_records=2, random_request_observed_records=2,
            random_request_family_observations=2, random_request_record_projections=3,
            random_request_late_observer_refusals=1, random_request_observe_only_retries=1,
            random_request_duplicate_observations=2, actual_submissions=35, state_members=31).items():
            assert int(p[k]) == value, (name, k)
    assert read(W / 'runs/ordinary-cuda/attempt2/report.json')['control_and_candidate_arms'] == 16
    freeze = dict(base_commit=plan['worktree_base_commit'], sources=[pin(R / p) for p in SOURCES])
    save(W / 'source-freeze.json', freeze)
    old_base = read(plan['base']['path'])
    save(W / 'model-link-base.json', dict(schema='hyle.sidecar-pages.current-link-base.v1',
        base=plan['base'], compile=plan['units']['qwen']['compile'], link=plan['units']['qwen']['link'],
        consumer_source=pin(plan['units']['qwen']['source']), previous_consumer=pin(W / 'compile/qwen/receipt.json'),
        retained=plan['retained'], runtime=plan['runtime'], sdk_engine_dependencies=plan['sdk'], source_freeze=pin(W / 'source-freeze.json')))
    save(W / 'reuse.json', dict(model_link_base=pin(W / 'model-link-base.json'),
        consumers={name: dict(**unit, receipt=pin(W / 'compile' / name / 'receipt.json')) for name, unit in plan['units'].items()},
        note='Keep four current consumer objects and original227 SDK inputs; previous three Qwen/Append objects are superseded.'))
    old = R / '.scratch/inference-append-tail-return-20261029/compile'
    roots = [W / 'bin', *[old / n for n in ['qwen', 'ordinary', 'append']]]
    targets = [p for p in (W / 'bin').iterdir() if p.is_file()]
    targets += [old / n / 'unit.obj' for n in ['qwen', 'ordinary', 'append']]
    assert all(p.is_file() for p in targets)
    retained = {b.key(p['path']) for p in plan['retained']}
    assert not any(b.key(p) in retained for p in targets)
    save(W / 'cleanup-plan.json', dict(allowed_roots=[str(p.resolve()) for p in roots], targets=[pin(p) for p in targets]))
    print('PASS seven current native processes; prepared current reuse base and exact reconstructible cleanup targets.')

def archive():
    plan = read(W / 'plan.json')
    for p in read(W / 'source-freeze.json')['sources']: exact(p)
    builds = {}
    for name in plan['units']:
        receipt = b.previous.receipt(name)
        builds[name] = dict(object=receipt['object'], compile=read(W / 'compile' / name / 'attempt1/process.json'),
            link=read(W / 'link' / name / 'attempt1/process.json'))
    cases = {name: dict(process=read(W / 'runs' / name / attempt / 'process.json'),
        report=read(W / 'runs' / name / attempt / 'report.json')) for name, attempt in CASES.items()}
    rejection = W / 'runs/ordinary-cuda/attempt1'
    assert read(rejection / 'process.json')['exit'] == 1
    result = dict(schema='hyle.correctness.sidecar-pages.v1', date='2026-10-29', status='PASS_WITH_PRESERVED_FIXTURE_REJECTION',
        base_commit=plan['worktree_base_commit'],
        changes=[
            'Q8 and BF16 original sidecars use PreparedRecordCommit/RequestProgress with real multi-token cold storage and complete preflight before original atomic Head publish.',
            'Actual late-observer refusal blocks a new round; retry only observes original committed result, duplicates do not advance output. Actual pending continues without repeating native work or changing original Head/state/RNG.',
            'Qwen target, batched draft and private NextN share complete prepare_append_pages: capacity, prefix refs, actual tail reservation, permitted COW fallback and original inventory acquisition.',
            'Model epoch/relay eligibility, bank mapping, logical state and original bind/submit/take/publication/retirement remain in their original owners. Late acquire failure retains original staged capabilities for episode recovery.',
            'Target reserves dirty metadata only for its actual target banks, rather than also reserving unrelated draft banks.'],
        counts=dict(CXX_attempts=4, links=4, current_consumer_TUs=4, retained_SDK_inputs=227, SDK_CXX=0, NVCC=0,
            full_builds=0, downloads=0, native_attempt_processes=8, current_passed_processes=7,
            current_passed_GTests=14, raw_consumer_processes=4, ordinary_control_and_candidate_arms=16, preserved_fixture_rejections=1),
        sources=read(W / 'source-freeze.json')['sources'], builds=builds, cases=cases,
        preserved_rejection=dict(process=read(rejection / 'process.json'), stderr=(rejection / 'stderr.log').read_text(),
            cause='Old ordinary fixture directory already contained generated finite stop fixture. No compile/product fix: use fresh two-file metadata directory pointing to original weights, keep rejected attempt.',
            corrected_attempt='ordinary-cuda/attempt2'),
        cleanup=read(W / 'cleanup-result.json'),
        boundaries=[
            'Sidecars are original-role CPU components with fixed layer39 input/cache history; not full DeepSeek generation, RequestLoop coverage, CUDA sidecar stochastic proof, acceptance-rate or task quality.',
            'Qwen history K2/mixed-lag/ordinary fixture cases are finite untrained geometry. MTP natural relay uses original trained Qwen3.5-2B P154/O40 and compares its two paths, not a reference engine.',
            'No new throughput, loading/memory benchmark, GPU overlap amount, device-fault injection, cross-platform or multi-device claim.',
            'Shared complete page preparation does not mean all model-independent execution orchestration is extracted.'],
        archive='inference-sidecar-pages-2026-10-29.zip')
    save(E, result)
    with zipfile.ZipFile(E.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        z.write(E, E.name)
        for relative in SOURCES:
            z.write(R / relative, 'current/' + relative)
            z.writestr('parent/' + relative, subprocess.check_output(['git','show',plan['worktree_base_commit']+':'+relative],cwd=R))
        for relative in ['build.py','record.py','plan.json','source-freeze.json','model-link-base.json','reuse.json','cleanup-plan.json','cleanup-result.json']:
            z.write(W / relative, relative)
        for f in sorted(W.glob('compile/*/receipt.json')): z.write(f, str(f.relative_to(W)))
        for section in ['compile','link','runs']:
            for f in sorted((W / section).rglob('*')):
                if f.is_file() and f.name in ['process.json','stdout.log','stderr.log','command.json','image.json','report.json','results.xml','consumer.cc','append_transactions.h','main.cc','model_graph_run.h','dspark_native_consumer.h']:
                    z.write(f, str(f.relative_to(W)))
        for relative in ['.scratch/inference-multimodel-observation-20261029/build.py','.scratch/inference-program-identity-20261029/build.py']:
            z.write(R / relative, 'support/' + Path(relative).parent.name + '/build.py')
        z.write(Path(plan['sdk']['path']), 'support/sdk-engine-dependencies.json')
        z.write(R / 'test.ps1', 'cleanup.ps1')
    print('PASS evidence', E.name, E.with_suffix('.zip').stat().st_size, 'bytes archive')

if sys.argv[1] == 'prepare': prepare()
elif sys.argv[1] == 'archive': archive()
else: raise ValueError(sys.argv[1])
