"""Publish BG source/data identity and scoped passed/failed facts, no native."""
from pathlib import Path
import fnmatch
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

S=Path(__file__).resolve().parent
R=S.parents[1]
DEST=R/'docs/evidence/correctness'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def identity(p):
    p=Path(p)
    return dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


# Select the successful final observation of each relevant case explicitly;
# failed batches are kept as failed batches, never relabeled green.
selection={1:'*',3:'CpuGraphC5Parameters.*',
           4:'DSparkOriginalState.*EncodedMainHistory*',
           5:'QwenMtpStateConsumer.Cuda*',6:'QwenMtpStateConsumer.Cpu*',
           7:'DSparkOriginalState.*OriginalSharedVocabulary*'}
selected=[]
for attempt,pattern in selection.items():
    summary=read(S/f'checks{attempt}/summary.json')
    tree=ET.parse(S/f'checks{attempt}/results.xml').getroot()
    for case in tree.iter('testcase'):
        name=case.attrib['classname']+'.'+case.attrib['name']
        if not fnmatch.fnmatchcase(name,pattern):
            continue
        assert case.find('failure') is None and case.find('skipped') is None,name
        assert case.attrib.get('result')=='completed',name
        selected.append(dict(name=name,attempt=attempt,attributes=case.attrib,
            properties={p.attrib['name']:p.attrib['value'] for p in case.iter('property')},
            image=summary['image'],xml=identity(S/f'checks{attempt}/results.xml')))
assert len(selected)==14 and len({case['name'] for case in selected})==14
assert all(not read(S/f'checks{i}/summary.json')['process']['timed_out'] for i in range(1,8))
graphs=sum(int(case['properties'].get('actual_submissions',0)) for case in selected)
references=sum(int(case['properties'].get('original_native_reference_submissions',0)) for case in selected)
assert graphs==132 and references==225

sources=set()
for freeze in ('roles-source/freeze.json','nextn-source/freeze.json',
               'dspark-shared-source/freeze.json','dspark-shared-source/real-test-freeze2.json'):
    for row in read(S/freeze)['files']:
        path=R/row['path']
        assert identity(path)['sha256']==row['sha256'],path
        sources.add(path)
sources.update(R/p for p in ('tests/graph_route_cpu/CMakeLists.txt',
    'tests/graph_route_cuda/CMakeLists.txt','docs/developer/current-work.md',
    'docs/implementation/model-operators.md','test.ps1'))
paths=set(sources)
paths.update(p for p in S.rglob('*') if p.is_file() and
    p.suffix.lower() in ('.h','.cc','.cu','.py','.ps1','.json','.txt','.diff','.log','.xml','.d'))
paths.discard(S/'publication.json')
archive=DEST/'mtp-shared-vocabulary-state-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for path in sorted(paths):
        z.write(path,path.relative_to(R).as_posix())
payloads=read(S/'original-dspark-vocabulary/acquisition.json')
record=dict(date='2026-10-23',stage='BG',goal_complete=False,
    conclusion='Actual lease-backed Q27/Q24 one-block draft state and formal Flash full-vocabulary shared roles now execute; remaining target/original/quant scopes are not closed.',
    successful_unique_tests=14,selected_cases=selected,
    counted_model_graph_submissions=graphs,
    graph_count_scope='Only12 cases record actual_submissions; the two passed legacyC5 cases do not publish a count and are excluded from132. Not a count of every successful/failed exploratory submission.',
    extra_original_native_CUDA_reference_submissions=references,
    references='225 raw original-native integration references check generated GPU codec wiring; not independent math kernels and not consumer Graph submissions. Original-role decoded/F64 and local F32 gates remain separate.',
    complete_runs=[read(S/f'checks{i}/summary.json') for i in range(1,8)],
    implementation=dict(
        qwen='Ordinary Graph shared input/QKV/GQA builder, distinct dense/MoE tails, real pendingID->fullVembedding->normalizedhidden/KV->fullVhead->pending. Six resources atomically selected after prefix0/1/2; retained heads continue; exact NaN tail preservation. Pool-root bytes, not only logical state extents, are budgeted. Primary MAIN Q27 EH/norms and Q24 KV/norm roles injected once through shared owner/ReadLease supplier. Other roles generated.',
        dspark='Formal Flash originalBF16 fullV embedding/head supplied through target-owned ReadonlyRoles and one existing cold construction path; same coefficients retainBF16 storage for mature BFloatLinearF32. Arbitrary legal actual IDs read original rows. Combined13originalroles2310699520B, original encoded main history/full three-stage draft and accepted-state journey. No full F32 LM weight bank is generated in supplied mode.'),
    repaired_observation_contracts=dict(
        cuda_quant='Failed original CPU Q8_K activation reference was being applied to CUDA Q8_1/32. Runtime-only reference selection now uses the established native CUDA integration oracle; CPU/Graph/input/provider/fusion/tolerances unchanged. Original independent input/KV and F32 gates retained.',
        confidence='Original realCPU4352-term F32 reduction differed from independentF64 by1.0789022781e-5. Former fixed relative tolerance was4.4507639408e-6. Source confirms identical actualBF16 rawhidden/Markov and BF16 coefficient values. Newreal-only analytic gamma4352F32/F64 absolute-product bound with finite/exactproduct/normalquantum/nooverflow checks; oldgenerated projection_equal unchanged. Observed firstcase sumabs26.9373978496,bound0.0069893582670,ratio0.001543635677. Graph/math/precision/greedy/IDs unchanged.'),
    numerical_observations=dict(
        original_lm_values_per_backend=646400,
        CPU_LM_max_absolute_error=8.566072210669518e-6,
        CUDA_LM_max_absolute_error=0.0005308911204338074,
        CPU_LM_max_bound_ratio=6.123581126772892e-5,
        CUDA_LM_max_bound_ratio=0.00427271797429853,
        source='checks7/stdout.log; bounded actual inputs, no cross-backend/full-model quality claim'),
    original_payload_acquisition=payloads,
    new_payload_bytes=2118123520,
    payload_archived=False,
    original_role_inventory=read(S/'review/remaining-original-roles.json'),
    next='Resolve ggml CUDA encoded MatMul RHS generic F32 element cap, then validate one full vocabulary head with this same bank; exact smaller GLM indexer/DSpark norm/HC suppliers next. Full target taps/Pro geometry and remaining confirmed quantization remain.',
    limitations=['WindowsCPU/CUDA only this round; no Linux,Apple,Vulkan model run',
        'Q27/Q24 complete draft continuation only; original target/recurrent trunk remains explicit external boundary',
        'Qwen other weights/vocabulary and8resident Q24 expert mapping generated; no full64/92-layer/original512expert model',
        'DSpark original sharedvocabulary plus Q8sidecar eleven roles is an explicit mixed-role consumer, not mainUDQ4 vocabulary or fullofficialBF16target/stages; headnorm/otherstage coefficients and targetcapture/verifier generated',
        'Manual accepted0/1/2 verifies state mechanism; not natural fullmodel acceptance or generation quality',
        'Scoped cases passed in separate images/runs; only the changed realDSpark numerical checks rerun after confidence oracle revision. All prior failures retained.',
        'CMake source wiring updated, no fullconfigure/SDK/thirdparty/NVCC/shader rebuild',
        'No newTPS/loading/physicalCPU-GPUpeak sample; preserve AV latest complete performance table'],
    final_image=read(S/'tests-link5/ready.json')['image'],
    source_identities=[identity(p) for p in sorted(sources)],
    cleanup=read(S/'cleanup-result.json'),archive=identity(archive),archive_items=len(paths))
out=DEST/'mtp-shared-vocabulary-state-2026-10-23.json'
assert not out.exists()
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(S/'publication.json').write_text(json.dumps(dict(evidence=identity(out),archive=identity(archive)),
    ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=identity(out),archive=identity(archive),tests=14,known_model_graphs=graphs),ensure_ascii=False))
