#pragma once

#include <numeric>

#include "dspark_main_history.h"
#include "dspark_complete_graph_fixture.h"

// Cold model assembly only. Shared trained LM/target captures and the other
// draft-stage parameters are still separate acquisition/integration work.
namespace dspark_original_state_consumer {
namespace b = dspark_target_binding;
namespace h = dspark_main_history;
namespace d = dspark_complete_graph;
namespace base = cpu_c4_model_branches;
namespace sem = d5_qwen38_24t_semantic_fragments;
namespace c = hyle::compute;
namespace g = hyle::graph;
using hyle::Result;
using hyle::Status;

struct ExternalConstant final { sem::ValueId value; b::ReadonlyRole role; };
struct Draft final {
  d::CompleteProgram program;
  std::vector<ExternalConstant> constants;
  struct StageChecks final {sem::ValueId activation,normalized,rotated,entry,encoded,decoded;};
  std::array<StageChecks,3> checkpoints;
};
inline Result<Draft> make_draft(const std::array<b::StageKvRoles,3> &roles,
                                const b::ReadonlyRole &frequencies,
                                d::HeadParameters heads,bool observe_boundaries=false) {
  // Reuse actual role qualification and the same codec/position definition.
  HYLE_ASSIGN_OR_RETURN(auto qualified, h::make_history(roles,frequencies,1));
  (void)qualified;
  Draft result;
  base::DraftHistoryInputs histories;
  for(std::size_t stage=0;stage<3;++stage) {
    HYLE_ASSIGN_OR_RETURN(histories[stage].description,
        c::row_cache_carrier_description(h::kEncoding,h::kWindow));
    histories[stage].append_keys=[&,stage](sem::Fragment &f,sem::ValueId activation,
        sem::ValueId history,sem::ValueId positions) {
      const auto weight=f.constant(roles[stage].projection.description,{});
      const auto norm=f.constant(roles[stage].norm.description,{});
      const auto frequency=f.constant(frequencies.description,{});
      result.constants.push_back({weight,roles[stage].projection});
      result.constants.push_back({norm,roles[stage].norm});
      result.constants.push_back({frequency,frequencies});
      auto projected=f.one(c::Operation(c::MatMul{.accumulation_type=c::DataType::kFloat32}),{activation,weight});
      auto normalized=f.one(c::Operation(c::RmsNorm{.epsilon=1.0e-6F}),{projected,norm});
      // Same selected Q8 main-history boundary: BF16 -> last64 RoPE -> BF16.
      auto rounded=base::ds::bfloat_boundary(f,normalized);
      auto shaped=base::core::reshape(f,rounded,{1,base::block,1,b::kKv});
      auto head=base::ds::slice(f,shaped,3,0,448);
      auto tail=base::ds::slice(f,shaped,3,448,64);
      auto rotated=f.one(c::Operation(c::RoPE{.rotary_dimensions=64,.sequence_axis=1,
          .layout=c::RopeLayout::kInterleaved}),{tail,positions,frequency});
      auto flat=base::core::reshape(f,base::ds::concat(f,head,rotated,3),{base::block,b::kKv});
      auto entry=f.one(c::Operation(c::Cast{c::DataType::kBFloat16}),{flat});
      auto proposed=f.one(c::model_ops::row_cache_encode(h::kEncoding),{entry});
      // Only the actual committed main rows are persistent. Proposal rows are
      // encoded and consumed inside this episode, never copied into that ring.
      auto combined=base::ds::concat(f,history,proposed,0);
      std::vector<std::int32_t> ids(std::size_t(h::kWindow+base::block));
      std::iota(ids.begin(),ids.end(),0);
      auto indices=f.constant(sem::dense({h::kWindow+base::block},c::DataType::kInt32),sem::bytes(ids));
      auto decoded=f.one(c::model_ops::row_cache_gather_decode(h::kEncoding),{combined,indices});
      auto fp32=f.one(c::Operation(c::Cast{c::DataType::kFloat32}),{decoded});
      result.checkpoints[stage]={activation,normalized,flat,entry,proposed,fp32};
      return base::core::reshape(f,fp32,{1,h::kWindow+base::block,1,b::kKv});
    };
  }
  result.program=d::build_flash(heads,&histories);
  if(!result.program.encoded || result.program.fragment.inputs.size()!=6 ||
      result.program.fragment.outputs.size()!=7 || !result.program.fragment.state_ports.empty())
    return std::unexpected(Status::Internal("DSpark encoded draft ports differ from actual read-only history boundary"));
  if(observe_boundaries) {
    // Optional test observations of existing arithmetic, never model state or
    // next-cache outputs. The semantic component still has seven named ports.
    // Observations must survive Invocation reset alongside prior proposals.
    // Materialize required views explicitly rather than binding writers to
    // an alias or borrowing a private workspace generation.
    for(auto &stage:result.checkpoints)
      for(auto *value:{&stage.activation,&stage.normalized,&stage.rotated,&stage.entry,&stage.encoded,&stage.decoded}) {
        *value=result.program.fragment.one(c::Operation(c::Copy{}),{*value});
        result.program.fragment.outputs.push_back(*value);
      }
  }
  return result;
}

struct Boundary final {
  std::uint64_t session=0,branch=0,epoch=0;
  std::int64_t next_position=0;
  std::int32_t pending=0;
  std::uint32_t consumed=0;
};
struct State final {
  b::TargetIdentity target;
  c::StateSchema schema;
  c::StateStore store;
  std::array<c::StateEntryId,8> entries;
  static Result<State> create(b::TargetIdentity target) {
    HYLE_RETURN_IF_ERROR(b::qualify_identity(target,{b::kSidecarRepository,b::kSidecarRevision,b::kSidecarFile}));
    State result{.target=std::move(target)};
    HYLE_ASSIGN_OR_RETURN(auto ring,c::row_cache_carrier_description(h::kEncoding,h::kWindow));
    HYLE_ASSIGN_OR_RETURN(auto carry,b::plain(std::array<std::int64_t,2>{1,b::kHidden}));
    HYLE_ASSIGN_OR_RETURN(auto capture,b::plain(std::array<std::int64_t,3>{1,4,b::kHidden}));
    const std::array specs{c::StateEntrySpec{.description=ring},c::StateEntrySpec{.description=ring},
      c::StateEntrySpec{.description=ring},c::StateEntrySpec{.description=carry},
      c::StateEntrySpec{.description=capture},c::StateEntrySpec{.description=capture},
      c::StateEntrySpec{.description=capture},
      c::StateEntrySpec{.kind=c::StateEntryKind::kHostMetadata,.metadata_bytes=sizeof(Boundary)}};
    HYLE_ASSIGN_OR_RETURN(result.schema,c::StateSchema::create(specs));
    HYLE_ASSIGN_OR_RETURN(result.store,c::StateStore::create(result.schema,
        {.max_versions=32,.max_drafts=4,.max_retained_blocks=256,.max_backing_bytes=64u<<20}));
    for(std::size_t i=0;i<result.entries.size();++i) {
      HYLE_ASSIGN_OR_RETURN(result.entries[i],result.schema.entry(i));
    }
    return result;
  }
  Result<Boundary> boundary(const c::StateVersion &version) const {
    HYLE_ASSIGN_OR_RETURN(auto member,version.member(entries[7]));
    HYLE_ASSIGN_OR_RETURN(auto view,member.view());Boundary result;
    HYLE_RETURN_IF_ERROR(view.read(std::as_writable_bytes(std::span(&result,1))));return result;
  }
  Result<c::StateVersion> select(const c::StateVersion &from,
      std::span<const c::ReadLease> history,std::span<const c::ReadLease> captures,
      const b::CaptureFrame &frame,std::uint32_t accepted,std::int32_t pending) {
    HYLE_ASSIGN_OR_RETURN(auto facts,boundary(from));
    HYLE_ASSIGN_OR_RETURN(auto locations,h::placement(frame));(void)locations;
    if(frame.target!=target || facts.session!=frame.session || facts.branch!=frame.branch ||
        facts.epoch>=frame.epoch || facts.next_position!=frame.first_position ||
        history.size()!=std::size_t(frame.rows*4) || captures.size()!=3 ||
        accepted>std::uint32_t(frame.rows) || pending<0 ||
        accepted>std::numeric_limits<std::uint32_t>::max()-facts.consumed)
      return std::unexpected(Status::InvalidArgument("DSpark complete prefix does not belong to this captured frontier"));
    if(!accepted) return from;
    HYLE_ASSIGN_OR_RETURN(auto draft,store.begin(from));
    for(std::size_t i=0;i<4;++i)
      HYLE_RETURN_IF_ERROR(draft.replace(entries[i],history[(accepted-1)*4+i]));
    constexpr auto row_bytes=std::size_t(4*b::kHidden*sizeof(float));
    for(std::size_t i=0;i<3;++i) {
      if(captures[i].size()!=std::size_t(frame.rows)*row_bytes)
        return std::unexpected(Status::InvalidArgument("DSpark captured target prefix row extent differs"));
      HYLE_ASSIGN_OR_RETURN(auto last,captures[i].subview(std::size_t(accepted-1)*row_bytes,row_bytes));
      HYLE_RETURN_IF_ERROR(draft.replace(entries[4+i],last));
    }
    facts.epoch=frame.epoch;facts.next_position+=accepted;facts.pending=pending;facts.consumed+=accepted;
    HYLE_RETURN_IF_ERROR(draft.replace_metadata(entries[7],std::as_bytes(std::span(&facts,1))));
    return draft.finalize();
  }
};
} // namespace dspark_original_state_consumer
