"""Focused Qwen MTP actual-lease state consumers; native work in root only."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BF = R / '.scratch/glm-encoded-state-20261023'
AY = R / '.scratch/qwen-original-mtp-20261022'
AZ = R / '.scratch/qwen24-original-mtp-20261022'
spec = importlib.util.spec_from_file_location('qwen_state_cached', BF / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = BF / 'tests-link4'
SOURCES = {
    'q27-input': R / 'tests/compute_models/qwen27_original_mtp_input_test.cc',
    'q24-kv': R / 'tests/compute_models/qwen24_original_mtp_kv_test.cc',
    'qwen-state': R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc',
    'q24-nextn': R / 'tests/graph_route_cpu/d5_qwen38_official_test.cc',
    'q24-head': R / 'tests/graph_route_cpu/d5_qwen_gguf_vocabulary_test.cc',
    'dspark-state': R / 'tests/compute_models/dspark_original_state_consumer_test.cc',
}
RECIPES = {
    'q27-input': AY / 'compile2/q27/identity.json',
    'q24-kv': AZ / 'compile1/q24-kv/identity.json',
    'qwen-state': AY / 'compile2/q27/identity.json',
    'q24-nextn': AY / 'compile2/q24/identity.json',
    'q24-head': AY / 'compile2/q24-head/identity.json',
    'dspark-state': BF / 'compile4/dspark-state/identity.json',
}


def host(tag, attempt):
    recipe = c.read(RECIPES[tag])
    if tag == 'qwen-state':
        recipe['command'] = [x for x in recipe['command'] if not x.startswith('/DHYLE_TEST_Q27_')]
        recipe['command'] += ['/DHYLE_TEST_QWEN_STATE_CPU=1', '/DHYLE_TEST_QWEN_STATE_CUDA=1',
            '/DHYLE_GGML_CPU_IQ1_EXTENSIONS=1', '/DHYLE_GGML_CUDA_IQ1_EXTENSIONS=1']
    path = S / 'recipes' / (tag + '.json')
    path.parent.mkdir(exist_ok=True)
    c.save(path, recipe)
    h.RECIPES[tag], h.SOURCES[tag] = path, SOURCES[tag]
    h.compile_one(tag, attempt)


def latest(tag):
    paths = sorted(S.glob(f'compile*/{tag}/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    assert paths, tag
    path = paths[-1]
    record = c.read(path)
    assert all(b.identity(x['path']) == x for x in (record['source'], record['object'], *record['dependencies']))
    return path, record


def link(attempt, tags):
    base = c.read(BASE / 'link-plan.json')
    remove, records = set(), []
    for row in base['compiled_records']:
        rec = c.read(row['path'])
        if '/tests/' in rec['source']['path'].replace('\\', '/'):
            remove.add(c.key(rec['object']['path']))
        else:
            records.append(row)
    added = [latest(tag) for tag in tags]
    inputs = [rec['object'] for _, rec in added] + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [rec['object']['path'] for _, rec in added]
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'qwen-state-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(p) for p, _ in added] + records,
        base=b.identity(BASE / 'link-plan.json'), SDK_builds=0, native_CPU_builds=0,
        NVCC_builds=0, shaders=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path']) == dll
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image)))
    print('LINKED actual Qwen state consumers', flush=True)


def run(link_attempt, attempt, test_filter, expected):
    spec_run = importlib.util.spec_from_file_location('qwen_state_run_helpers', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    q = importlib.util.module_from_spec(spec_run)
    spec_run.loader.exec_module(q)
    folder = S / f'tests-link{link_attempt}'
    image = c.read(folder / 'ready.json')['image']
    assert b.identity(image['path']) == image
    env = os.environ.copy()
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    env['HYLE_QWEN27_MTP_INPUT_DIR'] = str(AY / 'original-q27')
    env['HYLE_QWEN24_MTP_KV_DIR'] = str(AZ / 'original-q24')
    env['HYLE_DSPARK_TARGET_ROLES_DIR'] = str(R / '.scratch/glm-mtp-catchup-20261022/original-dspark-target')
    env['HYLE_DSPARK_HISTORY_ROLES_DIR'] = str(R / '.scratch/glm-mtp-seed-cache-20261022/original-dspark-history')
    env['HYLE_DSPARK_MARKOV_DIR'] = str(R / '.scratch/dspark-mtp-integration-20261022/original-markov')
    env['HYLE_DSPARK_CONFIDENCE_BF16'] = str(R / '.scratch/qwen-mtp-next-20261022/original-confidence/conf_proj.weight.bf16')
    env['HYLE_DSPARK_SHARED_VOCAB_DIR'] = str(S / 'original-dspark-vocabulary')
    out = S / f'checks{attempt}'
    xml = out / 'results.xml'
    process = q.execute([image['path'], '--gtest_filter=' + test_filter, '--gtest_output=xml:' + str(xml)], env, out, timeout=900)
    result = dict(process=process, image=image, throughput_evidence=False, physical_memory_evidence=False, whole_original_model=False)
    if xml.is_file():
        tree = ET.parse(xml).getroot()
        result.update(tests=int(tree.attrib['tests']), failures=int(tree.attrib['failures']), errors=int(tree.attrib['errors']),
            disabled=int(tree.attrib['disabled']), skips=sum(case.find('skipped') is not None for case in tree.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value'] for p in case.iter('property')}) for case in tree.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert process['exit'] == 0 and not process['timed_out'], process
    assert result.get('tests') == expected and not any(result[k] for k in ('failures', 'errors', 'disabled', 'skips')), result
    print('PASS Qwen state checks', expected, flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('actions', nargs='+', choices=[*SOURCES, 'link', 'run'])
    p.add_argument('--attempt', type=int, default=1)
    p.add_argument('--link-attempt', type=int, default=1)
    p.add_argument('--only', nargs='+', choices=list(SOURCES), default=list(SOURCES))
    p.add_argument('--filter', default='*')
    p.add_argument('--expected-tests', type=int, default=1)
    args = p.parse_args()
    for action in args.actions:
        if action == 'link': link(args.attempt, args.only)
        elif action == 'run': run(args.link_attempt, args.attempt, args.filter, args.expected_tests)
        else: host(action, args.attempt)
