"""Fetch only two fixed formal-Flash BF16 roles; no model/shard copy."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import struct
import time
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = S / 'original-dspark-vocabulary'
OUT.mkdir(exist_ok=True)
REPO = 'deepseek-ai/DeepSeek-V4-Flash-0731'
REV = '7872f01b1d1fe23eabc4c98b48bffcef5a386062'
CACHE = R / '.scratch/validation/cpu-quant-mtp-c1'
records = json.loads((CACHE / 'safetensors-headers.json').read_text(encoding='utf-8'))
index = json.loads((CACHE / 'deepseek-ai--DeepSeek-V4-Flash-0731--index.json').read_text(encoding='utf-8'))
MANIFEST = OUT / 'acquisition.json'
manifest = json.loads(MANIFEST.read_text(encoding='utf-8')) if MANIFEST.is_file() else dict(
    repository=REPO, revision=REV, full_model_download=False, roles={}, requests=[])


def save():
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def fetch(url, first, last, expected_total=None, etag=None):
    # Range-specific query avoids caches reusing an earlier small range.
    request = urllib.request.Request(url+f'?hyle_range={first}-{last}',
        headers={'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity', 'User-Agent': 'hyle-role-input/1'})
    record = dict(first=first, last=last, requested_bytes=last-first+1, complete=False)
    manifest['requests'].append(record)
    save()
    with urllib.request.urlopen(request, timeout=45) as response:
        total = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range',''))
        if response.status != 206 or total is None or tuple(map(int,total.groups()[:2])) != (first,last):
            raise RuntimeError('Exact HTTP206 range required: '+str(dict(status=response.status,
                content_range=response.headers.get('Content-Range'))))
        actual_total = int(total.group(3))
        actual_etag = response.headers.get('ETag')
        if (expected_total is not None and actual_total != expected_total) or (etag is not None and actual_etag != etag):
            raise RuntimeError('Fixed source size/ETag changed')
        data = response.read(last-first+2)
        if len(data) != last-first+1:
            raise RuntimeError('Incorrect role range byte count')
        record.update(complete=True, http_status=206, content_range=response.headers['Content-Range'],
            etag=actual_etag, sha256=hashlib.sha256(data).hexdigest())
        save()
        return data, actual_total, actual_etag


def headers():
    for name in ('embed.weight','head.weight'):
        file = index['weight_map'][name]
        known = [r for r in records.values() if r['repository']==REPO and r['revision']==REV and r['file']==file]
        assert len(known)==1
        known = known[0]
        url = f'https://huggingface.co/{REPO}/resolve/{REV}/{file}'
        if name in manifest['roles']:
            print('REUSE header', name, flush=True)
            continue
        prefix, total, etag = fetch(url, 0, 7)
        length = struct.unpack('<Q',prefix)[0]
        assert length == known['header_bytes'] and length < 65536
        raw, _, _ = fetch(url, 8, 7+length, total, etag)
        assert hashlib.sha256(raw).hexdigest()==known['header_sha256']
        info = json.loads(raw)[name]
        assert info['dtype']=='BF16' and info['shape']==[129280,4096]
        first, stop = info['data_offsets']
        assert stop-first==1059061760
        first, stop = first+8+length, stop+8+length
        assert stop <= total
        (OUT / (name+'.header.json')).write_bytes(raw)
        manifest['roles'][name] = dict(file=file, url=url, dtype='BF16', shape=info['shape'],
            header_bytes=length, header_sha256=known['header_sha256'],
            first=first, last=stop-1, bytes=stop-first, file_bytes=total, etag=etag)
        save()
        print('PINNED', name, stop-first, first, stop-1, flush=True)


def payloads():
    for name, role in manifest['roles'].items():
        path = OUT / (name+'.bf16')
        if role.get('complete'):
            assert path.stat().st_size==role['bytes']
            print('REUSE role', name, flush=True)
            continue
        position = path.stat().st_size if path.is_file() else 0
        assert 0 <= position <= role['bytes']
        # Resume only the exact prefix previously recorded by this script.
        chunks = role.setdefault('chunks',[])
        assert position==sum(item['bytes'] for item in chunks)
        with path.open('ab') as output:
            while position < role['bytes']:
                count = min(16*1024*1024,role['bytes']-position)
                data,_,_ = fetch(role['url'],role['first']+position,
                    role['first']+position+count-1,role['file_bytes'],role['etag'])
                output.write(data)
                output.flush()
                chunks.append(dict(offset=position, bytes=count, sha256=hashlib.sha256(data).hexdigest()))
                position += count
                save()
                print('ROLE',name,position,role['bytes'],flush=True)
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for data in iter(lambda:stream.read(16*1024*1024),b''):
                digest.update(data)
        role.update(complete=True, path=str(path), sha256=digest.hexdigest())
        save()
        print('COMPLETE',name,role['sha256'],flush=True)


if __name__=='__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--payloads',action='store_true')
    args=p.parse_args()
    headers()
    if args.payloads:
        payloads()
