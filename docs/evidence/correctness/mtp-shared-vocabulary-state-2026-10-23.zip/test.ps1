$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$scratchPrefix = (Resolve-Path -LiteralPath (Join-Path $repoRoot '.scratch')).Path.TrimEnd('\') + '\'
# Four obsolete BG executable/map pairs superseded by BG link5 and the scoped
# passing results. Retain every object, source, command, input and runtime DLL.
$entries = @(
    [pscustomobject]@{ Relative = '.scratch/qwen-mtp-state-20261023/tests-link1/qwen-state-checks.exe'; Bytes = 140382720 },
    [pscustomobject]@{ Relative = '.scratch/qwen-mtp-state-20261023/tests-link1/qwen-state-checks.map'; Bytes = 58280627 },
    [pscustomobject]@{ Relative = '.scratch/qwen-mtp-state-20261023/tests-link2/qwen-state-checks.exe'; Bytes = 142341632 },
    [pscustomobject]@{ Relative = '.scratch/qwen-mtp-state-20261023/tests-link2/qwen-state-checks.map'; Bytes = 62835859 },
    [pscustomobject]@{ Relative = '.scratch/qwen-mtp-state-20261023/tests-link3/qwen-state-checks.exe'; Bytes = 140798464 },
    [pscustomobject]@{ Relative = '.scratch/qwen-mtp-state-20261023/tests-link3/qwen-state-checks.map'; Bytes = 59001220 },
    [pscustomobject]@{ Relative = '.scratch/qwen-mtp-state-20261023/tests-link4/qwen-state-checks.exe'; Bytes = 142354944 },
    [pscustomobject]@{ Relative = '.scratch/qwen-mtp-state-20261023/tests-link4/qwen-state-checks.map'; Bytes = 62886597 }
)
$protected = @(
    '.scratch/qwen-mtp-state-20261023/tests-link5/qwen-state-checks.exe',
    '.scratch/glm-encoded-state-20261023/tests-link4/encoded-state-checks.exe',
    '.scratch/fp8-quant-output-20261023/vulkan-build/link1/fp8-quant-vulkan-checks.exe',
    '.scratch/qwen-mtp-next-20261022/hyle-link4/qwen.exe'
)
foreach ($keep in $protected) {
    if (-not (Test-Path -LiteralPath (Join-Path $repoRoot $keep) -PathType Leaf)) { throw "Protected image missing: $keep" }
}
$ready = Get-Content -LiteralPath (Join-Path $repoRoot '.scratch/qwen-mtp-state-20261023/tests-link5/ready.json') -Raw | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $ready.image.path -Algorithm SHA256).Hash -ne $ready.image.sha256) { throw 'Current checked image changed' }
foreach ($entry in $entries) {
    $target = (Resolve-Path -LiteralPath (Join-Path $repoRoot $entry.Relative)).Path
    if (-not $target.StartsWith($scratchPrefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside repository scratch: $target" }
    $expected = [System.IO.Path]::GetFullPath((Join-Path $repoRoot $entry.Relative))
    if ($target -ne $expected) { throw "Unexpected resolved target: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.Bytes) { throw "Changed size: $target" }
}
foreach ($entry in $entries) { Remove-Item -LiteralPath (Join-Path $repoRoot $entry.Relative) -Force }
$result = [pscustomobject]@{
    Removed = $entries
    RemovedPathBytes = ($entries | Measure-Object -Property Bytes -Sum).Sum
    ProtectedImagesRetained = @($protected | ForEach-Object { Test-Path -LiteralPath (Join-Path $repoRoot $_) -PathType Leaf })
    Retained = 'All objects, source, commands, data and runtime DLLs; current BG and BF CPU/CUDA, previous Vulkan and AV performance images'
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $repoRoot '.scratch/qwen-mtp-state-20261023/cleanup-result.json') -Encoding utf8
$result | Select-Object RemovedPathBytes, ProtectedImagesRetained
