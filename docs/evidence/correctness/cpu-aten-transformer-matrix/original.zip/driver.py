import hashlib, shutil
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-aten-transformer-matrix'
build=Path('C:/hv/cpu-tm-original-probe')
sdk=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
records=json.loads((out/'receipt.json').read_bytes()) if (out/'receipt.json').exists() else []
run('configure',['cmake','-S',out,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(sdk)])
run('build',['cmake','--build',build,'--parallel','2'])
identity=[]
for source in (sdk/'lib').glob('*.dll'):
    destination=build/source.name
    if not destination.exists():
        try:os.link(source,destination)
        except OSError:shutil.copy2(source,destination)
    identity.append(dict(name=source.name,sha256=hashlib.sha256(source.read_bytes()).hexdigest(),hardlink=os.stat(source).st_ino==os.stat(destination).st_ino))
(out/'runtime-identity.json').write_bytes((json.dumps(identity,indent=2)+'\n').encode())
run('original-transformer-matrix-programs',[build/'cpu_aten_cast_probe.exe'])
