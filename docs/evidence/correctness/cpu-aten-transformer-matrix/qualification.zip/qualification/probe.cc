#include "original-program.h"
#include <ATen/ATen.h>
#include <ATen/core/grad_mode.h>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <limits>

std::size_t assertions = 0;
void check(double actual, double expected, double tolerance = 1e-6) {
  ++assertions;
  bool good = std::isnan(expected)   ? std::isnan(actual)
              : std::isinf(expected) ? actual == expected
                                     : std::abs(actual - expected) <= tolerance;
  if (!good) {
    std::printf("Mismatch assertion=%zu actual=%g expected=%g\n", assertions,
                actual, expected);
    std::exit(3);
  }
}
int main() {
  at::NoGradGuard guard;
  const float inf = (std::numeric_limits<float>::infinity)();
  const float nan = (std::numeric_limits<float>::quiet_NaN)();
  // Eight-axis broadcast/zero-K are original matmul, with independent scalar
  // sums.
  auto lhs = at::arange(6, at::kFloat).view({1, 1, 1, 1, 1, 1, 2, 3});
  auto rhs = at::arange(24, at::kFloat).view({2, 1, 1, 1, 1, 1, 3, 4});
  auto product = at::matmul(lhs, rhs).contiguous();
  for (int b = 0; b < 2; ++b)
    for (int i = 0; i < 2; ++i)
      for (int j = 0; j < 4; ++j) {
        float sum = 0;
        for (int k = 0; k < 3; ++k)
          sum += float(i * 3 + k) * float(b * 12 + k * 4 + j);
        check(product.data_ptr<float>()[b * 8 + i * 4 + j], sum);
      }
  auto zero =
      at::matmul(at::empty({2, 0}, at::kFloat), at::empty({0, 3}, at::kFloat));
  for (int i = 0; i < 6; ++i)
    check(zero.data_ptr<float>()[i], 0);
  std::array<float, 12> values{0,    1,    -1, 2,   -inf, -inf,
                               -inf, -inf, 0,  nan, inf,  -inf};
  auto input = at::from_blob(values.data(), {3, 4}, at::kFloat);
  std::array<unsigned char, 4> bits{2, 0, 255, 0};
  auto mask = at::from_blob(bits.data(), {1, 4}, at::kByte);
  for (bool logarithmic : {false, true})
    for (int kind : {0, 1}) {
      auto y = original::softmax(input, mask, 1, .5F, kind, logarithmic)
                   .contiguous();
      double sum = 0;
      for (int j = 0; j < 4; ++j)
        if (kind == 0 || bits[j] != 0)
          sum += std::exp(.5 * values[j]);
      for (int j = 0; j < 4; ++j) {
        double expected = (kind == 1 && bits[j] == 0) ? (logarithmic ? -inf : 0)
                          : logarithmic ? .5 * values[j] - std::log(sum)
                                        : std::exp(.5 * values[j]) / sum;
        check(y.data_ptr<float>()[j], expected);
      }
      for (int j = 4; j < 8; ++j)
        check(y.data_ptr<float>()[j], nan);
      for (int j = 8; j < 12; ++j) {
        bool valid_nan =
            true; // +Inf is still visible at the true mask position.
        check(y.data_ptr<float>()[j],
              valid_nan ? nan : (logarithmic ? -inf : 0));
      }
    }
  // Long positions, both pair layouts, untouched tail bytes.
  auto data = at::arange(20, at::kFloat).view({1, 2, 2, 5});
  std::array<std::int64_t, 2> positions{2147483649LL, -2147483651LL};
  std::array<float, 2> frequency{.1F, .003F};
  auto pos = at::from_blob(positions.data(), {2}, at::kLong);
  auto freq = at::from_blob(frequency.data(), {2}, at::kFloat);
  for (bool split : {false, true}) {
    auto y = original::rope(data, pos, freq, 1, 4, split).contiguous();
    for (int t = 0; t < 2; ++t)
      for (int h = 0; h < 2; ++h) {
        int base = (t * 2 + h) * 5;
        for (int p = 0; p < 2; ++p) {
          int l = split ? p : p * 2, r = split ? p + 2 : p * 2 + 1;
          double angle = double(positions[t]) * double(frequency[p]);
          double a = base + l, b = base + r;
          check(y.data_ptr<float>()[base + l],
                float(a * std::cos(angle) - b * std::sin(angle)), 2e-6);
          check(y.data_ptr<float>()[base + r],
                float(a * std::sin(angle) + b * std::cos(angle)), 2e-6);
        }
        check(y.data_ptr<float>()[base + 4], base + 4);
      }
  }
  // Two query heads share one KV head. Bottom-right causal makes the first row
  // invalid.
  auto q = at::ones({1, 2, 3, 2}, at::kFloat),
       k = at::ones({1, 1, 2, 2}, at::kFloat);
  std::array<float, 4> vs{1, 2, 3, 4};
  auto v = at::from_blob(vs.data(), {1, 1, 2, 2}, at::kFloat);
  auto a = original::attention(q, k, v, at::Tensor{}, 0, false, true, .5F)
               .contiguous();
  for (int h = 0; h < 2; ++h)
    for (int t = 0; t < 3; ++t)
      for (int d = 0; d < 2; ++d)
        check(a.data_ptr<float>()[h * 6 + t * 2 + d],
              t == 0   ? nan
              : t == 1 ? vs[d]
                       : (vs[d] + vs[d + 2]) * .5);
  auto empty = original::attention(q, at::empty({1, 1, 0, 2}, at::kFloat),
                                   at::empty({1, 1, 0, 2}, at::kFloat),
                                   at::Tensor{}, 0, false, false, 1)
                   .contiguous();
  for (int i = 0; i < 12; ++i)
    check(empty.data_ptr<float>()[i], nan);
  // Qualification also covers narrow storage around an explicit F32 program.
  for (auto dtype : {at::kFloat, at::kHalf, at::kBFloat16}) {
    auto l = lhs.to(dtype).to(at::kFloat), r = rhs.to(dtype).to(at::kFloat);
    auto n = at::matmul(l, r).to(dtype).to(at::kFloat).contiguous();
    for (int i = 0; i < 16; ++i)
      check(n.data_ptr<float>()[i], product.data_ptr<float>()[i]);
    std::array<float, 4> data_norm{1, 2, 3, 4};
    auto x = at::from_blob(data_norm.data(), {1, 4}, at::kFloat)
                 .to(dtype)
                 .to(at::kFloat);
    auto rn = at::rms_norm(x, {4}, std::optional<at::Tensor>{}, 1e-5)
                  .to(dtype)
                  .to(at::kFloat);
    auto ln = at::layer_norm(x, {4}, std::optional<at::Tensor>{},
                             std::optional<at::Tensor>{}, 1e-5)
                  .to(dtype)
                  .to(at::kFloat);
    for (int i = 0; i < 4; ++i) {
      float er =
          float(double(data_norm[i]) / std::sqrt(7.5 + double(float(1e-5))));
      float el = float((double(data_norm[i]) - 2.5) /
                       std::sqrt(1.25 + double(float(1e-5))));
      auto er_storage = at::scalar_tensor(er, at::kFloat)
                            .to(dtype)
                            .to(at::kFloat)
                            .item<float>();
      auto el_storage = at::scalar_tensor(el, at::kFloat)
                            .to(dtype)
                            .to(at::kFloat)
                            .item<float>();
      check(rn.data_ptr<float>()[i], er_storage, 1e-6);
      check(ln.data_ptr<float>()[i], el_storage, 1e-6);
    }
    auto narrow = original::softmax(input.to(dtype).to(at::kFloat), mask, 1,
                                    .5F, 1, false)
                      .to(dtype)
                      .to(at::kFloat);
    check(narrow.data_ptr<float>()[1], 0);
    check(narrow.data_ptr<float>()[4], nan);
  }
  // Explicit original-library fused SDPA differs on invalid rows: record it,
  // while the public-contract math composition is the candidate carrier.
  auto fused = at::scaled_dot_product_attention(
                   q, k, v, at::zeros({3, 2}, at::kBool), 0., false,
                   std::optional<double>{.5}, true)
                   .contiguous();
  std::printf(
      "original fused SDPA all-masked first=%g; public contract requires NaN\n",
      fused.data_ptr<float>()[0]);
  std::printf("original matrix/Bool-log-softmax/I64 rope/masked-causal "
              "attention assertions=%zu PASS; no timing\n",
              assertions);
}
