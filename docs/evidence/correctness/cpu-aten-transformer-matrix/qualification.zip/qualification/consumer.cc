#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> value) {
  if (!value) {
    std::fprintf(stderr, "%.*s\n", int(value.error().message().size()),
                 value.error().message().data());
    std::exit(2);
  }
  return std::move(*value);
}
void require(hyle::Status value) {
  if (!value.ok()) {
    std::fprintf(stderr, "%.*s\n", int(value.message().size()),
                 value.message().data());
    std::exit(2);
  }
}
c::TensorDesc desc(c::DataType type,
                   std::initializer_list<std::int64_t> dimensions,
                   bool odd = false) {
  if (!odd)
    return take(
        c::TensorDesc::dense(type, {dimensions.begin(), dimensions.size()}));
  std::vector<std::int64_t> strides(dimensions.size());
  auto n = std::int64_t(c::data_type_size(type) + 1);
  for (std::size_t i = dimensions.size(); i-- > 0;) {
    strides[i] = n;
    n = n * dimensions.begin()[i] + 1;
  }
  return take(c::TensorDesc::strided_bytes(
      type, {dimensions.begin(), dimensions.size()}, strides));
}
m::Buffer allocate(const c::TensorDesc &d) {
  return take(
      m::Buffer::create(m::system_resource(), take(d.required_bytes()), 64));
}
std::size_t offset(const c::TensorDesc &d, std::size_t linear) {
  std::size_t out = 0;
  for (std::size_t i = d.rank(); i-- > 0;) {
    out += linear % std::size_t(d.dimensions()[i]) *
           std::size_t(d.byte_strides()[i]);
    linear /= std::size_t(d.dimensions()[i]);
  }
  return out;
}
template <class T>
void write(m::Buffer &b, const c::TensorDesc &d, std::span<const T> values) {
  std::vector<std::byte> bytes(b.size());
  for (std::size_t i = 0; i < values.size(); ++i)
    std::memcpy(bytes.data() + offset(d, i), &values[i], sizeof(T));
  require(b.view().write(bytes));
}
void compare(const m::Buffer &b, std::span<const float> expected) {
  std::vector<float> x(expected.size());
  require(b.view().read(std::as_writable_bytes(std::span(x))));
  for (std::size_t i = 0; i < x.size(); ++i) {
    bool match = std::isnan(expected[i]) ? std::isnan(x[i])
                 : std::isinf(expected[i])
                     ? x[i] == expected[i]
                     : std::abs(x[i] - expected[i]) <=
                           1e-6F + std::abs(expected[i]) * 8e-5F;
    if (!match) {
      std::fprintf(stderr, "Mismatch %zu actual=%g expected=%g\n", i, x[i],
                   expected[i]);
      std::exit(3);
    }
  }
}
template <class Fill, class Check>
void journey(c::Operation op, std::span<const c::TensorDesc> inputs, Fill fill,
             Check check) {
  std::vector<m::Buffer> buffers;
  for (const auto &d : inputs)
    buffers.push_back(allocate(d));
  auto context = take(c::cpu::create_context());
  auto queue = take(context.create_queue());
  const auto output = take(c::infer_single_output(op, inputs));
  auto prepared = take(c::prepare(context, op, inputs, std::span(&output, 1),
                                  m::system_resource()));
  if (prepared.provider().id != c::aten_cpu::kProviderId) {
    std::fprintf(stderr, "Unqualified default carrier %.*s\n",
                 int(prepared.provider().name.size()),
                 prepared.provider().name.data());
    std::exit(4);
  }
  auto invocation = take(prepared.create_invocation());
  auto direct = allocate(output), graph_output = allocate(output);
  std::vector<c::ConstTensorView> views;
  for (std::size_t i = 0; i < inputs.size(); ++i)
    views.push_back(
        take(c::ConstTensorView::create(inputs[i], buffers[i].view())));
  const std::array destination{
      take(c::TensorView::create(output, direct.view()))};
  auto builder = take(g::GraphBuilder::create());
  std::vector<g::ValueId> ids;
  for (const auto &d : inputs)
    ids.push_back(take(builder.input(d)));
  auto node = take(builder.add_node(op, ids));
  auto result = take(builder.result(node));
  auto final = take(builder.add(c::Copy{}, result));
  require(builder.publish(final));
  auto logical = take(std::move(builder).finish());
  auto gc = take(g::cpu::create_context());
  auto gq = take(gc.create_queue());
  auto compiled = take(g::compile(logical, gc));
  auto gi = take(compiled.executable.create_invocation());
  bool aten = false;
  for (std::size_t i = 0; i < compiled.report.step_count(); ++i)
    aten |=
        take(compiled.report.step(i)).provider.id == c::aten_cpu::kProviderId;
  if (!aten)
    std::exit(5);
  for (std::size_t i = 0; i < ids.size(); ++i)
    require(gi.bind(ids[i], views[i]));
  require(
      gi.bind(final, take(c::TensorView::create(output, graph_output.view()))));
  const std::array lanes{
      g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &gq}};
  require(gi.prepare_replay(lanes));
  for (int replay = 0; replay < 2; ++replay) {
    fill(buffers, replay);
    require(take(invocation.submit(queue, views, destination)).wait());
    require(take(gi.submit(gq)).wait());
    check(direct, replay);
    check(graph_output, replay);
  }
  require(context.close());
  require(gc.close());
  if (invocation.submit(queue, views, destination) || gi.submit(gq))
    std::exit(6);
}
int main() {
  const auto f = c::DataType::kFloat32;
  const float inf = (std::numeric_limits<float>::infinity)(),
              nan = (std::numeric_limits<float>::quiet_NaN)();
  const std::array matrix{desc(f, {1, 1, 1, 1, 1, 1, 2, 3}, true),
                          desc(f, {2, 1, 1, 1, 1, 1, 3, 4}, true)};
  journey(
      c::Operation(c::MatMul{}), matrix,
      [&](auto &b, int seed) {
        std::array<float, 6> a;
        std::array<float, 24> w;
        for (int i = 0; i < 6; ++i)
          a[i] = float(i + seed);
        for (int i = 0; i < 24; ++i)
          w[i] = float(i) * .125F;
        write<float>(b[0], matrix[0], a);
        write<float>(b[1], matrix[1], w);
      },
      [&](const auto &b, int seed) {
        std::array<float, 16> expected;
        for (int batch = 0; batch < 2; ++batch)
          for (int row = 0; row < 2; ++row)
            for (int col = 0; col < 4; ++col) {
              float sum = 0;
              for (int k = 0; k < 3; ++k)
                sum += float(row * 3 + k + seed) *
                       float(batch * 12 + k * 4 + col) * .125F;
              expected[batch * 8 + row * 4 + col] = sum;
            }
        compare(b, expected);
      });
  const std::array sm{desc(f, {3, 4}, true),
                      desc(c::DataType::kBool, {1, 4}, true)};
  for (auto kind : {c::SoftmaxKind::kSoftmax, c::SoftmaxKind::kLogSoftmax})
    journey(
        c::Operation(c::Softmax{
            .scale = .5F, .kind = kind, .mask = c::MaskKind::kBoolean}),
        sm,
        [&](auto &b, int seed) {
          std::array<float, 12> x{float(seed), 1,    -1, 2, -inf, -inf,
                                  -inf,        -inf, 0,  0, inf,  0};
          std::array<std::uint8_t, 4> mask{2, 0, 255, 1};
          write<float>(b[0], sm[0], x);
          write<std::uint8_t>(b[1], sm[1], mask);
        },
        [&](const auto &b, int seed) {
          std::array<float, 12> expected;
          double sum = std::exp(seed * .5) + std::exp(-.5) + std::exp(1.);
          for (int j = 0; j < 4; ++j) {
            double score = j == 0 ? seed * .5 : j == 2 ? -.5 : 1.;
            expected[j] = j == 1
                              ? (kind == c::SoftmaxKind::kLogSoftmax ? -inf : 0)
                              : float(kind == c::SoftmaxKind::kLogSoftmax
                                          ? score - std::log(sum)
                                          : std::exp(score) / sum);
          }
          for (int j = 4; j < 12; ++j)
            expected[j] = nan;
          compare(b, expected);
        });
  const std::array rope{desc(f, {2, 5}, true),
                        desc(c::DataType::kInt64, {2}, true),
                        desc(f, {2}, true)};
  journey(
      c::Operation(c::RoPE{.rotary_dimensions = 4, .sequence_axis = 0}), rope,
      [&](auto &b, int seed) {
        std::array<float, 10> x;
        for (int i = 0; i < 10; ++i)
          x[i] = float(i + seed) * .125F;
        const std::array<std::int64_t, 2> p{2147483649LL, -2147483651LL};
        const std::array<float, 2> w{.1F, .003F};
        write<float>(b[0], rope[0], x);
        write<std::int64_t>(b[1], rope[1], p);
        write<float>(b[2], rope[2], w);
      },
      [&](const auto &b, int seed) {
        std::array<float, 10> expected;
        const std::array<std::int64_t, 2> p{2147483649LL, -2147483651LL};
        const std::array<float, 2> w{.1F, .003F};
        for (int row = 0; row < 2; ++row) {
          for (int j = 0; j < 2; ++j) {
            double angle = double(p[row]) * w[j],
                   a = (row * 5 + j * 2 + seed) * .125,
                   b = (row * 5 + j * 2 + 1 + seed) * .125;
            expected[row * 5 + j * 2] =
                float(a * std::cos(angle) - b * std::sin(angle));
            expected[row * 5 + j * 2 + 1] =
                float(a * std::sin(angle) + b * std::cos(angle));
          }
          expected[row * 5 + 4] = float(row * 5 + 4 + seed) * .125F;
        }
        compare(b, expected);
      });
  const std::array attention{
      desc(f, {1, 3, 2, 2}, true), desc(f, {1, 2, 1, 2}, true),
      desc(f, {1, 2, 1, 3}, true), desc(c::DataType::kBool, {3, 2}, true)};
  journey(
      c::Operation(c::ScaledDotProductAttention{
          .mask = c::MaskKind::kBoolean, .scale = .5F, .causal = true}),
      attention,
      [&](auto &b, int seed) {
        const std::array<float, 12> q{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
        const std::array<float, 4> k{1, 1, 1, 1};
        std::array<float, 6> v;
        for (int i = 0; i < 6; ++i)
          v[i] = float(i + 1 + seed);
        const std::array<std::uint8_t, 6> mask{0, 0, 2, 0, 255, 1};
        write<float>(b[0], attention[0], q);
        write<float>(b[1], attention[1], k);
        write<float>(b[2], attention[2], v);
        write<std::uint8_t>(b[3], attention[3], mask);
      },
      [&](const auto &b, int seed) {
        std::array<float, 18> expected;
        for (int t = 0; t < 3; ++t)
          for (int h = 0; h < 2; ++h)
            for (int d = 0; d < 3; ++d)
              expected[(t * 2 + h) * 3 + d] = t == 0   ? nan
                                              : t == 1 ? float(d + 1 + seed)
                                                       : float(d + 2.5 + seed);
        compare(b, expected);
      });
  const std::array norm{desc(f, {2, 4}, true)};
  for (bool layer : {false, true})
    journey(
        layer ? c::Operation(c::LayerNorm{}) : c::Operation(c::RmsNorm{}), norm,
        [&](auto &b, int seed) {
          std::array<float, 8> x;
          for (int i = 0; i < 8; ++i)
            x[i] = float(i % 4 + 1 + seed);
          write<float>(b[0], norm[0], x);
        },
        [&](const auto &b, int seed) {
          std::array<float, 8> expected;
          double mean = 2.5 + seed, squared = 0;
          for (int i = 0; i < 4; ++i)
            squared += (i + 1 + seed) * (i + 1 + seed);
          for (int i = 0; i < 8; ++i)
            expected[i] =
                float(layer ? (i % 4 + 1 + seed - mean) /
                                  std::sqrt(1.25 + double(float(1e-5)))
                            : (i % 4 + 1 + seed) /
                                  std::sqrt(squared / 4 + double(float(1e-5))));
          compare(b, expected);
        });
  std::puts(
      "ordinary mature CPU matrix/Bool-log-softmax/I64 RoPE/masked-GQA/norm "
      "Direct and Graph changed-input programs PASS");
}
