#pragma once
#include <ATen/ATen.h>
#include <array>
#include <limits>

namespace original {
inline at::Tensor softmax(at::Tensor x, const at::Tensor &mask,
                          std::int64_t axis, float scale, int kind,
                          bool logarithmic) {
  // Public scores are F32 before normalization; Bool storage is nonzero=true.
  x = x.to(at::kFloat).mul(scale);
  if (kind == 1)
    x = x.masked_fill(mask.eq(0), -(std::numeric_limits<float>::infinity)());
  if (kind == 2)
    x = x.add(mask.to(at::kFloat));
  return logarithmic ? at::log_softmax(x, axis, at::kFloat)
                     : at::softmax(x, axis, at::kFloat);
}
inline at::Tensor rope(const at::Tensor &x, const at::Tensor &positions,
                       const at::Tensor &frequency, std::int64_t axis,
                       std::int64_t rotary, bool split) {
  std::vector<std::int64_t> ps(x.dim(), 1), fs(x.dim(), 1);
  if (positions.dim() == 1)
    ps[axis] = positions.size(0);
  else
    for (std::int64_t i = 0; i < positions.dim(); ++i)
      ps[i] = positions.size(i);
  fs.back() = rotary / 2;
  if (frequency.dim() == 2)
    fs[axis] = frequency.size(0);
  auto angles = positions.to(at::kDouble)
                    .view(ps)
                    .mul(frequency.to(at::kDouble).view(fs));
  auto c = angles.cos(), s = angles.sin();
  auto data = x.to(at::kDouble);
  at::Tensor left, right;
  if (split) {
    left = data.slice(-1, 0, rotary / 2);
    right = data.slice(-1, rotary / 2, rotary);
  } else {
    left = data.slice(-1, 0, rotary, 2);
    right = data.slice(-1, 1, rotary, 2);
  }
  auto a = left.mul(c).sub(right.mul(s));
  auto b = left.mul(s).add(right.mul(c));
  auto rotated =
      split ? at::cat({a, b}, -1) : at::stack({a, b}, -1).flatten(-2);
  auto output = x.clone();
  output.slice(-1, 0, rotary).copy_(rotated);
  return output;
}
inline at::Tensor attention(const at::Tensor &qin, const at::Tensor &kin,
                            const at::Tensor &vin, const at::Tensor &mask,
                            int kind, bool bshd, bool causal, float scale) {
  auto q = qin.to(at::kFloat), k = kin.to(at::kFloat), v = vin.to(at::kFloat);
  if (bshd) {
    q = q.transpose(1, 2);
    k = k.transpose(1, 2);
    v = v.transpose(1, 2);
  }
  const auto groups = q.size(1) / k.size(1);
  if (groups != 1) {
    k = k.repeat_interleave(groups, 1);
    v = v.repeat_interleave(groups, 1);
  }
  auto scores = at::matmul(q, k.transpose(-1, -2)).mul(scale);
  if (kind == 1)
    scores = scores.masked_fill(mask.eq(0),
                                -(std::numeric_limits<float>::infinity)());
  if (kind == 2)
    scores = scores.add(mask.to(at::kFloat));
  if (causal) {
    auto row = at::arange(q.size(2), at::kLong).view({q.size(2), 1});
    auto column = at::arange(k.size(2), at::kLong).view({1, k.size(2)});
    auto allowed = column.le(row.add(k.size(2) - q.size(2)));
    scores = scores.masked_fill(allowed.logical_not(),
                                -(std::numeric_limits<float>::infinity)());
  }
  auto weights = at::softmax(scores, -1, at::kFloat);
  auto result = at::matmul(weights, v);
  // With zero keys, original matmul produces zeros but public invalid rows are
  // NaN.
  if (k.size(2) == 0)
    result = at::full_like(result, (std::numeric_limits<float>::quiet_NaN)());
  return bshd ? result.transpose(1, 2) : result;
}
} // namespace original
