"""One combined current Model/fixture TU, one link, one real P154 consumer."""
from pathlib import Path
import importlib.util,json,os,sys,traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
P=R/'.scratch/inference-bounded-prefill-20261027'
spec=importlib.util.spec_from_file_location('vulkan_recipe',R/'.scratch/inference-vulkan-engine-slots-20261027/build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m
EXPECTED={'engine/models/qwen35/main.cc':'0f73055bd8b6590a67d0af4621584848b5e66316750cab97b09cb03a11648eac',
 'engine/inference/prefill_plan.h':'a895777146bc942bc0fbfac566172f4839ad23c81cf1a66cd1750ee2759f5493',
 'tests/tools/qwen_chunked_prefill_case.h':'909f712689f59f17b043fc2590ad14fdc8e64f4438094abdf2ebd2ee07590c4b'}
def plan():
 assert not (W/'plan.json').exists()
 for p,h in EXPECTED.items():assert b.pin(R/p)['sha256']==h
 baseline=b.read(P/'ready.json');inputs=b.read(baseline['inputs']['path'])
 model=baseline['object']['path'];entry=str(R/'.scratch/inference-current-closure-20261026/engine/entry/unit.obj')
 assert sum(b.key(x['path'])==b.key(model) for x in inputs)==1 and sum(b.key(x['path'])==b.key(entry) for x in inputs)==1
 retained=[x for x in inputs if b.key(x['path']) not in {b.key(model),b.key(entry)}]
 for row in retained:b.exact(row)
 b.save(W/'retained-inputs.json',retained)
 cmd=m.command(P/'compile/command.json',W/'consumer.cc',W/'compile')
 b.save(W/'recipe.json',dict(command=cmd,cwd=str(R),timeout_seconds=180))
 frozen=m.c.closure([R/'engine/models/qwen35/main.cc',R/'tests/tools/qwen_chunked_prefill_case.h'],[W/'recipe.json'])
 frozen.append(b.pin(W/'consumer.cc'));b.save(W/'source-freeze.json',frozen)
 for rel in [*EXPECTED,'engine/models/qwen35/session_state.h']:
  dst=W/'source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((R/rel).read_bytes())
 fixture=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
 assert len((fixture/'prompt.ids').read_text().split())==154 and (fixture/'weights.tsv').is_file()
 b.save(W/'plan.json',dict(status='FROZEN_NOT_BUILT_OR_RUN',baseline=b.pin(P/'ready.json'),baseline_inputs=baseline['inputs'],
  retained_inputs=b.pin(W/'retained-inputs.json'),removed_inputs=[model,entry],recipe=b.pin(W/'recipe.json'),consumer=b.pin(W/'consumer.cc'),
  source_freeze=b.pin(W/'source-freeze.json'),expected=EXPECTED,fixture=str(fixture),manifest=b.pin(fixture/'weights.tsv'),prompt=b.pin(fixture/'prompt.ids'),
  CXX_TUs=1,links=1,actual_runs=1,SDK=0,NVCC=0,downloads=0,
  fixture_change='A154=64+64+16+8+2; pending+130=64+64+2+1; B16 (previously15) retains one ready short prefill before its two interleaved decodes. Fixed independent expected rows, modes, draws and commits; no expected trace generated from PrefillPolicy.'))
 print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def build():
 p=b.read(W/'plan.json');assert not (W/'compile').exists()
 frozen=b.read(p['source_freeze']['path']);[b.exact(x) for x in frozen]
 known={b.key(x['path']):x for x in frozen};h,env=old.prior.old.old.env()
 compiled=h.execute(b.read(p['recipe']['path'])['command'],env,W/'compile',timeout=180)
 data=b.read(W/'compile/dependencies.json')['Data'];deps=[b.pin(x) for x in dict.fromkeys([data['Source'],*data['Includes']])];b.save(W/'compile/actual-dependencies.json',deps)
 for row in deps:
  q=Path(row['path'])
  if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):assert known[b.key(q)]['sha256']==row['sha256'],q
 [b.exact(x) for x in frozen];b.exact(p['consumer'])
 args=b.read(P/'link/command.json')['command'];image=W/'bin/chunked-prefill-test.exe';image.parent.mkdir(parents=True,exist_ok=True)
 removed={b.key(x) for x in p['removed_inputs']};args=[a for a in args if b.key(a) not in removed]
 for n,a in enumerate(args):
  if a.upper().startswith('/OUT:'):args[n]='/OUT:'+str(image)
  elif a.upper().startswith('/PDB:'):args[n]='/PDB:'+str(image.with_suffix('.pdb'))
  elif a.upper().startswith('/IMPLIB:'):args[n]='/IMPLIB:'+str(image.with_suffix('.lib'))
 obj=b.pin(W/'compile/unit.obj');args.append(obj['path']);inputs=b.read(p['retained_inputs']['path'])+[obj]
 for row in inputs:b.exact(row);assert sum(b.key(a)==b.key(row['path']) for a in args)==1
 linked=h.execute(args,env,W/'link',timeout=120);b.save(W/'link-inputs.json',inputs)
 runtime=b.read(P/'runtime.json');b.exact(runtime['native']);alias=image.parent/Path(runtime['native']['path']).name;os.link(runtime['native']['path'],alias)
 runtime['native_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH'];b.save(W/'runtime.json',runtime)
 b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',object=obj,compile=compiled,link=linked,image=b.pin(image),inputs=b.pin(W/'link-inputs.json'),
  runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json')))
 print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def run():
 p=b.read(W/'plan.json');r=b.read(W/'ready.json');b.exact(r['image']);assert not (W/'run').exists()
 h,env=old.prior.old.old.env();env['PATH']=b.read(r['runtime']['path'])['PATH']
 result=h.execute([r['image']['path'],p['fixture']],env,W/'run',timeout=180)
 reports=[json.loads(s) for s in (W/'run/stdout.log').read_text(encoding='utf-8-sig').splitlines() if s.startswith('{')];assert len(reports)==1
 q=reports[0];assert q['status']=='PASS' and q['actual_committed_input_rows']==304 and q['A_commits']==10 and q['B_commits']==3
 assert q['A_draw']==3 and q['B_draw']==3 and q['partial_rebuild_rows']==64 and q['partial_gdn_and_carry_exact']
 expected=['B:16','A:64','B:1','A:64','B:1','A:16','A:8','A:2','A:64','A:64','A:2','A:1','A:1']
 assert q['dispatch']==expected
 b.save(W/'summary.json',dict(status='REAL_CHUNKED_PREFILL_TAIL_CONSUMER_PASS',process=result,report=q,ready=b.pin(W/'ready.json'),
  scope=p['fixture_change'],quality_claim=False,performance_claim=False))
 print('PASS',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
 try:{'plan':plan,'build':build,'run':run}[sys.argv[1]]()
 except Exception:b.save(W/(sys.argv[1]+'-failure.json'),dict(error=traceback.format_exc()));raise
