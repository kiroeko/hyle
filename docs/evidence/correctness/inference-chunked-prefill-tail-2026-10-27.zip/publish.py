"""Publish one real Q64 tail regression; no additional execution."""
from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
p=read(W/'plan.json');ready=read(W/'ready.json');summary=read(W/'summary.json')
assert summary['status']=='REAL_CHUNKED_PREFILL_TAIL_CONSUMER_PASS' and summary['process']['exit']==0
assert ready['compile']['exit']==0 and ready['link']['exit']==0 and pin(ready['image']['path'])==ready['image']
for rel,h in p['expected'].items():assert pin(W/'source'/rel)['sha256']==h
assert pin(R/'tests/tools/qwen_chunked_prefill_case.h')['sha256']==p['expected']['tests/tools/qwen_chunked_prefill_case.h']
raw=(W/'run/stdout.log').read_text(encoding='utf-8-sig')
assert [json.loads(s) for s in raw.splitlines() if s.startswith('{')]==[summary['report']]
members={}
for path in W.rglob('*'):
 if path.is_file() and path.suffix in {'.cc','.h','.py','.json','.log'}:members[path.relative_to(W).as_posix()]=path.read_bytes()
fixture=Path(p['fixture']);members['fixture/weights.tsv']=(fixture/'weights.tsv').read_bytes();members['fixture/prompt.ids']=(fixture/'prompt.ids').read_bytes()
receipt=dict(schema=1,date='2026-10-27',title='Q64 binary prefill tails with a real Qwen consumer',status='REAL_CONSUMER_PASS',
 sources=[dict(path=rel,sha256=h,bytes=len((W/'source'/rel).read_bytes())) for rel,h in p['expected'].items()],
 changed_source='tests/tools/qwen_chunked_prefill_case.h only; product main/prefill logic belongs to the separately frozen bounded-prefill batch.',
 problem='The existing real-model fixture assumed Q64 ends P154 in 26 rows and pending+130 in 3 rows. The new finite binary-tail policy actually makes five/four chunks, leaving the old third-call completion, ledger and prefix-history assertions invalid.',
 change='Use independent explicit journeys A154=64+64+16+8+2 and next input131=64+64+2+1, including every intermediate no-output/no-RNG boundary and final output exactly once. B uses the original prompt first16 tokens instead of15 to remain a ready one-episode short request; this changes B actual committed work by one row, rather than weakening its starvation/independent-session check. Expected traces are fixed literals, never generated from PrefillPolicy.',
 fixture=dict(manifest=p['manifest'],prompt=p['prompt'],source_id='4a76decdfa58a5fd6e15acea7ff410e84fd3e81cb6c39db8a658eeb23d869fbe',
  geometry='hidden2048, FFN6144, vocabulary248320, 24 target layers GGGAGGGAGGGAGGGAGGGAGGGA; original prepared 320 physical target roles, no MTP roles.',
  payload='Existing local weight ranges reused, not copied/downloaded or archived. This is a real ordinary Qwen3.5-2B fixture, distinct from the untrained tiny CLI fixture.'),
 builds=dict(CXX_TUs=1,links=1,compile=ready['compile'],link=ready['link'],image=ready['image'],object=ready['object'],
  input_count=len(read(W/'link-inputs.json')),inputs=ready['inputs'],baseline=p['baseline'],
  reuse='Current bounded-prefill formal CUDA link closure, removing its standalone Model object and entry object. The one scratch wrapper includes actual current main plus this unique product test fixture. Matching existing weights/provider/native objects reused; no full lifecycle matrix, SDK, NVCC or shader rebuild.',
  SDK_builds=0,NVCC=0,downloads=0),
 execution=dict(actual_processes=1,process=summary['process'],report=summary['report'],
  checks=['Two real sessions interleaved; ready B decode runs between A full chunks.',
   'Retired A rebuild of its first64 input rows preserves exact GDN and carry bytes and original cursor.',
   'Cancel an actually submitted chunk, retain original A head/input offset/ledger/RNG and B boundary; retry commits once.',
   'State-only64/16/8/2 graphs expose no logits, sampler or ID output; actual intermediate chunks emit nothing and do not advance RNG.',
   'The complete initial prefix retains five actual chunk modes: four state-only, then one emitting boundary.',
   'Later pending+130 tail and final pending-only turn consume each pending token once; fixed A10/B3 commits, A3/B3 draws,304 committed input rows and no active request/episode at the end.'],
  quality_claim=False,performance_claim=False),
 failures_preserved=dict(record='plan-failure.json',explanation='Initial preparation-only helper rejected a scratch wrapper as a product root before any CXX/native run. Corrected closure roots to the two actual product files and explicitly pinned the wrapper. First compiler, link and native consumer attempts all passed; no product retry.'),
 limits=['No quality/throughput comparison, MTP, second backend, positive speculative acceptance or old full lifecycle suite rerun.',
  'Logical submitted-inflight was true at abort; exact GPU completion time at that observation is unknown. No device fault was injected.',
  'This validates the known real Q64 tail journeys and their original cancellation/rebuild/frontier contracts; unknown-prefix shape enumeration is separately checked by the bounded-prefill batch.'],
 members=[dict(name=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(members.items())])
manifest=(json.dumps(receipt,indent=2)+'\n').encode();members['manifest.json']=manifest
dest=R/'docs/evidence/correctness';stem='inference-chunked-prefill-tail-2026-10-27';public=dest/(stem+'.json');archive=dest/(stem+'.zip')
assert not public.exists() and not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(n,b)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members) and z.testzip() is None
 for n,b in members.items():assert z.read(n)==b and sha(z.read(n))==sha(b)
receipt['archive']=pin(archive);receipt['archive_manifest_sha256']=sha(manifest);receipt['integrity']='Every archive member reopened and compared bytes/SHA256; CRC passed. Source snapshots, current fixture and original stdout checked. No binary/SDK/model payload.'
public.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
result=dict(receipt=pin(public),archive=pin(archive),members=len(members));(W/'published.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
