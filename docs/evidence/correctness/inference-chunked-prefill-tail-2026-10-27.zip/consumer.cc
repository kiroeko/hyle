#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_chunked_prefill_case.h"
int main(int argc, char **argv) {
  if (argc != 2) return 2;
  return qwen_chunked_prefill_case::run(argv[1]);
}
