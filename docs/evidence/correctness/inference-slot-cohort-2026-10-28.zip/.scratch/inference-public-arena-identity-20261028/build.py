"""Explicit two-CXX public-arena component check; root schedules every action."""
from pathlib import Path
import importlib.util, json, re, sys, time, traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-indexed-store-20261028'
OLD = R / '.scratch/inference-paged-source-20261027'
spec = importlib.util.spec_from_file_location('retained_indexed_store_tools', BASE / 'build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
t.W = W  # Original execute/environment only; no old build action is invoked.
read, save, pin, exact, key = t.read, t.save, t.pin, t.exact, t.key
UNITS = {'arena': 'src/compute_batch/paged_arena.cc', 'host-test': 'tests/compute_batch/paged_arena_test.cc'}
TESTS = (
 'PagedFrame.PublicArenaIdentityDistinguishesEmptyForeignMovedAndStaleFootprints',
 'PagedFrame.LogicalFootprintCannotBorrowAWholeGuardsUnselectedInitializedRows',
 'PagedArena.BulkPagePrefixesKeepEachLogicalRequestTailAndRejectWrongOutputWithoutMutation')
NATIVE = ('resources', 'slots-region', 'batch', 'ggml-region', 'cuda-backend', 'cuda-status', 'indexed-host', 'indexed-kernel')


def tokens(body):
    text = re.sub(r'/\*.*?\*/|//[^\n]*', '', body.decode('utf-8-sig'), flags=re.S)
    return re.findall(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+|[^\s]', text)


def own_sources():
    for row in read(W / 'source-freeze.json')['sources']: exact(row)


def freeze():
    assert not (W / 'frozen.json').exists(), 'Never replace a frozen attempt'
    own_sources()
    base = read(BASE / 'ready-component.json'); rows = read(base['inputs']['path'])
    assert len(rows) == 228 and len({key(x['path']) for x in rows}) == 228
    for name in NATIVE: assert rows.count(base['compiled'][name]['object']) == 1
    # Actual compiler Data.Source selects the replaced product object.
    found = [m for row in rows if (m := t.retained_metadata(row)) and
             key(m['source']) == key(R / UNITS['arena'])]
    assert len(found) == 1
    assert found[0]['object'] in rows
    assert not any((m := t.retained_metadata(row)) and key(m['source']) == key(R / UNITS['host-test']) for row in rows)
    old_header = BASE / 'source/include/hyle/compute/paged_arena.h'
    header = R / 'include/hyle/compute/paged_arena.h'
    body = header.read_bytes().decode('utf-8-sig')
    method = 'HYLE_COMPUTE_BATCH_API bool owns(const PagedArenaFootprint &) const noexcept;'
    declaration = 'class PagedArenaFootprint;'
    assert body.count(method) == 1 and len(re.findall(r'^class PagedArenaFootprint;$', body, re.M)) == 1
    stripped = re.sub(r'^class PagedArenaFootprint;\n', '', body.replace(method, ''), count=1, flags=re.M).encode()
    assert tokens(stripped) == tokens(old_header.read_bytes()), 'Changed header is more than the exact additive method/forward declaration'
    save(W / 'abi-proof.json', dict(old_header=pin(old_header), current_header=pin(header),
        tokens_equal_after_exact_additions_removed=True, virtual_method=False,
        existing_object_layout_and_declarations_unchanged=True,
        scope='Old dependent objects remain valid for this declaration-only addition; no generalized changed-header exemption.'))
    env = read(BASE / 'environment.json'); save(W / 'environment.json', env)
    runtime = read(BASE / 'runtime-plan.json'); save(W / 'runtime-plan.json', runtime)
    units = {}; seeds = {R / source for source in UNITS.values()} | {header}
    for name, source in UNITS.items():
        recipe = OLD / ('compile/arena/command.json' if name == 'arena' else 'compile/arena-test/command.json')
        dep = OLD / ('compile/arena/dependencies.json' if name == 'arena' else 'compile/arena-test/dependencies.json')
        source_in_recipe = read(dep)['Data']['Source']
        assert key(t.canonical(source_in_recipe)) == key(R / source)
        for p in t.dep_paths(dep):
            p = t.canonical(p)
            if t.project(p): seeds.add(p)
        units[name] = dict(source=pin(R / source), recipe=pin(recipe), old_dependencies=pin(dep),
                           old_object=found[0]['object'] if name == 'arena' else None)
    # Pin only the two units' actual project dependency closure; do not copy it.
    todo = list(seeds)
    while todo:
        path = todo.pop()
        for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"', path.read_text(encoding='utf-8-sig'), re.M):
            selected = next((p.resolve() for base_dir in (path.parent, R / 'include', R)
                             if (p := base_dir / inc).is_file()), None)
            if selected and t.project(selected) and selected not in seeds:
                seeds.add(selected); todo.append(selected)
    before = [pin(path) for path in sorted(seeds)]
    save(W / 'project-dependencies-before.json', before)
    # Only the changed public header and two compiled sources need byte copies.
    snapshots = []
    for path in (header, *(R / source for source in UNITS.values())):
        out = W / 'source' / path.relative_to(R); out.parent.mkdir(parents=True, exist_ok=True)
        with out.open('xb') as stream: stream.write(path.read_bytes())
        snapshots.append(dict(original=pin(path), snapshot=pin(out)))
    save(W / 'compile-source-freeze.json', snapshots)
    for name, unit in units.items():
        out = W / 'compile' / name; old = read(unit['recipe']['path'])['command']
        command = [old[0], '/I'+str(W/'source/include'), '/I'+str(W/'source')]
        for i, arg in enumerate(old[1:], 1):
            if old[i-1].casefold() == '/sourcedependencies': arg = str(out / 'dependencies.json')
            elif arg.casefold().startswith('/fo'): arg = '/Fo'+str(out/'unit.obj')
            elif arg.casefold().startswith('/fd'): arg = '/Fd'+str(out/'unit.pdb')
            elif key(arg) == key(R/UNITS[name]): arg = str(W/'source'/UNITS[name])
            command.append(arg)
        assert '/MD' in command and '/std:c++latest' in command and '/DHYLE_STATIC' in command
        save(W/'recipes'/(name+'.json'), dict(command=command, cwd=str(R), timeout_seconds=180))
        unit['command'] = pin(W/'recipes'/(name+'.json'))
    save(W / 'plan.json', dict(units=units, tests=TESTS, input_count=228, final_input_count=229,
        baseline_ready=pin(BASE/'ready-component.json'), inputs=base['inputs'], link_recipe=base['recipe'],
        original_arena=found[0], native_objects={name:base['compiled'][name]['object'] for name in NATIVE},
        project_dependencies=pin(W/'project-dependencies-before.json'), snapshots=pin(W/'compile-source-freeze.json'),
        ABI=pin(W/'abi-proof.json'), runtime=pin(W/'runtime-plan.json'), environment=pin(W/'environment.json'),
        scope='Host identity/range contract only; no model, native fault or performance claim.'))
    save(W/'frozen.json', dict(plan=pin(W/'plan.json'), helper=pin(__file__), source_scope=pin(W/'source-freeze.json'),
        execute_helper=pin(BASE/'build.py')))
    print('FROZEN 2 CXX / 1 link / 3 host tests; no SDK/header tree copied')


def validate():
    frozen = read(W/'frozen.json')
    for row in frozen.values(): exact(row)
    own_sources(); plan = read(W/'plan.json')
    for name in ('baseline_ready', 'inputs', 'link_recipe', 'project_dependencies', 'snapshots', 'ABI', 'runtime', 'environment'): exact(plan[name])
    for row in read(plan['project_dependencies']['path']): exact(row)
    for row in read(plan['snapshots']['path']): exact(row['original']); exact(row['snapshot'])
    for unit in plan['units'].values():
        for name in ('source', 'recipe', 'old_dependencies', 'command'): exact(unit[name])
    return plan


def compile_unit(name):
    plan = validate(); unit = plan['units'][name]
    out = W/'compile'/name; out.mkdir(parents=True, exist_ok=False)
    process = t.execute(read(unit['command']['path'])['command'], W/'logs'/name, 180)
    validate()
    snapshots = {key(row['snapshot']['path']):row['snapshot'] for row in read(plan['snapshots']['path'])}
    project = {key(row['path']):row for row in read(plan['project_dependencies']['path'])}
    deps = out/'dependencies.json'; data = read(deps)['Data']
    assert key(data['Source']) == key(W/'source'/UNITS[name])
    actual = []
    for path in dict.fromkeys([data['Source'], *data['Includes']]):
        if key(path) in snapshots: exact(snapshots[key(path)])
        elif t.project(path):
            assert key(path) in project, ('Unfrozen project dependency',path)
            exact(project[key(path)])
        actual.append(pin(path))
    save(out/'actual-dependencies.json', actual)
    save(out/'compiled.json', dict(source=pin(W/'source'/UNITS[name]), object=pin(out/'unit.obj'), process=process,
        command=pin(W/'logs'/name/'command.json'), dependencies=pin(deps), actual_dependencies=pin(out/'actual-dependencies.json')))
    save(out/'project-dependencies-after.json', [pin(row['path']) for row in read(plan['project_dependencies']['path'])])
    print('COMPILE_PASS',name)


def link():
    plan = validate(); rows = read(plan['inputs']['path']); assert len(rows)==228
    compiled = {name:read(W/'compile'/name/'compiled.json') for name in UNITS}
    for value in compiled.values(): exact(value['object'])
    old = plan['units']['arena']['old_object']; new = compiled['arena']['object']; added = compiled['host-test']['object']
    assert rows.count(old)==1
    result = [new if row==old else row for row in rows]+[added]
    assert len(result)==229 and len({key(x['path']) for x in result})==229
    for native in plan['native_objects'].values(): assert result.count(native)==1
    for row in result: exact(row)
    image = W/'bin/public-arena-identity-test.exe'; image.parent.mkdir(exist_ok=True); assert not image.exists()
    args=[]; replaced=0
    for arg in read(plan['link_recipe']['path'])['command']:
        if key(arg)==key(old['path']):arg=new['path'];replaced+=1
        for option,suffix in (('/OUT:', '.exe'),('/PDB:', '.pdb'),('/IMPLIB:', '.lib'),('/MAP:', '.map')):
            if arg.upper().startswith(option):arg=option+str(image.with_suffix(suffix));break
        args.append(arg)
    assert replaced==1
    args.append(added['path'])
    for option,suffix in (('/OUT:', '.exe'),('/PDB:', '.pdb'),('/IMPLIB:', '.lib')):
        if not any(x.upper().startswith(option) for x in args):args.append(option+str(image.with_suffix(suffix)))
    save(W/'link-inputs.json',result)
    process=t.execute(args,W/'link',180)
    save(W/'ready.json',dict(status='LINKED_NOT_RUN',image=pin(image),compiled=compiled,process=process,
        inputs=pin(W/'link-inputs.json'),recipe=pin(W/'link/command.json'),runtime=plan['runtime'],plan=pin(W/'plan.json')))
    print('LINK_PASS 229 inputs; all eight indexed-Store products retained')


def parse():
    plan=validate(); ready=read(W/'ready.json'); folder=W/'run'; process=read(folder/'process.json')
    root=ET.parse(folder/'results.xml').getroot();cases=root.findall('./testsuite/testcase')
    actual=[row.attrib['classname']+'.'+row.attrib['name'] for row in cases]
    passed=process['exit']==0 and not process['timed_out'] and len(cases)==len(TESTS) and set(actual)==set(TESTS) and all(
        row.attrib.get('status')=='run' and not any(row.findall(tag) for tag in ('failure','error','skipped')) for row in cases)
    save(W/'summary.json',dict(status='PASS' if passed else 'FAIL',process=process,image=ready['image'],
        tests=[row.attrib for row in cases],filter=':'.join(TESTS),xml=pin(folder/'results.xml'),
        scope='Three selected host identity/prefix cases; no model/GPU/fault/performance validation.'))
    assert passed
    print('PASS',len(cases),'host cases')


def run():
    validate();ready=read(W/'ready.json');exact(ready['image'])
    command=[ready['image']['path'],'--gtest_color=no','--gtest_fail_fast','--gtest_filter='+':'.join(TESTS),
        '--gtest_output=xml:'+str(W/'run/results.xml')]
    try:t.execute(command,W/'run',90)
    except BaseException:
        if (W/'run/results.xml').is_file():
            try:parse()
            except BaseException:pass
        raise
    parse()


if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='freeze':freeze()
        elif action=='compile':compile_unit(sys.argv[2])
        elif action=='link':link()
        elif action=='run':run()
        elif action=='parse':parse()
        else:raise ValueError(action)
    except BaseException:
        (W/('failure-'+'-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
