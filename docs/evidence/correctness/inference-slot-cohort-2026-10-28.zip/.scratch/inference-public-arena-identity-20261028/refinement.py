"""Recipe-only host-test retry. Reuses the successful arena OBJ; no source changes."""
from pathlib import Path
import importlib.util, json, re, sys, time, traceback
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_public_arena_check',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
OUT=W/'compile/host-test-attempt2'


def prepare():
    plan=b.validate();original=plan['units']['host-test']['command'];args=read(original['path'])['command']
    recipe=[args[0],'/I'+str(b.R/'tests/compute_batch')]
    for i,arg in enumerate(args[1:],1):
        if args[i-1].casefold()=='/sourcedependencies':arg=str(OUT/'dependencies.json')
        elif arg.casefold().startswith('/fo'):arg='/Fo'+str(OUT/'unit.obj')
        elif arg.casefold().startswith('/fd'):arg='/Fd'+str(OUT/'unit.pdb')
        recipe.append(arg)
    # Both original quoted includes resolve through this one original directory.
    source=W/'source'/b.UNITS['host-test'];proof=[]
    allowed={key(row['path']):row for row in read(plan['project_dependencies']['path'])}
    for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"',source.read_text(encoding='utf-8-sig'),re.M):
        actual=(b.R/'tests/compute_batch'/inc).resolve();assert actual.is_file(),inc
        assert key(actual) in allowed,('Unpinned original fixture',actual);exact(allowed[key(actual)])
        proof.append(dict(include=inc,resolves_to=pin(actual)))
    save(W/'recipes/host-test-attempt2.json',dict(command=recipe,cwd=str(b.R),timeout_seconds=180))
    save(W/'refinement-plan.json',dict(status='PREPARED_NOT_COMPILED',helper=pin(__file__),original_frozen=pin(W/'frozen.json'),
        original_failed_command=pin(W/'logs/host-test/command.json'),original_failed_process=read(W/'logs/host-test/process.json'),
        original_recipe=original,refined_recipe=pin(W/'recipes/host-test-attempt2.json'),quoted_include_proof=proof,
        reused_successful_arena=pin(W/'compile/arena/compiled.json'),
        reason='Restore original quoted test directory after snapshot relocation; sources and frozen original plan/helper unchanged.'))
    print('PREPARED recipe-only host-test attempt2; arena is not recompiled')


def check():
    plan=b.validate();r=read(W/'refinement-plan.json')
    for field in ('helper','original_frozen','original_failed_command','original_recipe','refined_recipe','reused_successful_arena'):exact(r[field])
    for item in r['quoted_include_proof']:exact(item['resolves_to'])
    return plan,r


def compile():
    plan,r=check();OUT.mkdir(parents=True,exist_ok=False)
    process=b.t.execute(read(r['refined_recipe']['path'])['command'],W/'logs/host-test-attempt2',180);check()
    snapshots={key(x['snapshot']['path']):x['snapshot'] for x in read(plan['snapshots']['path'])}
    allowed={key(x['path']):x for x in read(plan['project_dependencies']['path'])};actual=[]
    dep=OUT/'dependencies.json';data=read(dep)['Data']
    assert key(data['Source'])==key(W/'source'/b.UNITS['host-test'])
    for path in dict.fromkeys([data['Source'],*data['Includes']]):
        if key(path) in snapshots:exact(snapshots[key(path)])
        elif b.t.project(path):assert key(path) in allowed,path;exact(allowed[key(path)])
        actual.append(pin(path))
    save(OUT/'actual-dependencies.json',actual)
    save(OUT/'compiled.json',dict(source=pin(data['Source']),object=pin(OUT/'unit.obj'),process=process,
        command=pin(W/'logs/host-test-attempt2/command.json'),dependencies=pin(dep),actual_dependencies=pin(OUT/'actual-dependencies.json')))
    print('COMPILE_PASS host-test-attempt2')


def link():
    plan,r=check();compiled={'arena':read(W/'compile/arena/compiled.json'),'host-test':read(OUT/'compiled.json')}
    for item in compiled.values():exact(item['object'])
    rows=read(plan['inputs']['path']);old=plan['units']['arena']['old_object'];new=compiled['arena']['object'];added=compiled['host-test']['object']
    assert len(rows)==228 and rows.count(old)==1
    result=[new if row==old else row for row in rows]+[added];assert len(result)==229
    for native in plan['native_objects'].values():assert result.count(native)==1
    for row in result:exact(row)
    image=W/'bin/public-arena-identity-test2.exe';image.parent.mkdir(exist_ok=True);assert not image.exists()
    args=[];replaced=0
    for arg in read(plan['link_recipe']['path'])['command']:
        if key(arg)==key(old['path']):arg=new['path'];replaced+=1
        for option,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(option):arg=option+str(image.with_suffix(suffix));break
        args.append(arg)
    assert replaced==1;args.append(added['path'])
    for option,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib')):
        if not any(x.upper().startswith(option) for x in args):args.append(option+str(image.with_suffix(suffix)))
    save(W/'link-inputs2.json',result);process=b.t.execute(args,W/'link-attempt2',180)
    save(W/'ready2.json',dict(status='LINKED_NOT_RUN',image=pin(image),compiled=compiled,process=process,
        inputs=pin(W/'link-inputs2.json'),recipe=pin(W/'link-attempt2/command.json'),runtime=plan['runtime'],refinement=pin(W/'refinement-plan.json')))
    print('LINK_PASS ready2.json; original successful arena OBJ retained')


def run():
    check();ready=read(W/'ready2.json');exact(ready['image']);out=W/'run-attempt2'
    process=b.t.execute([ready['image']['path'],'--gtest_color=no','--gtest_fail_fast','--gtest_filter='+':'.join(b.TESTS),
        '--gtest_output=xml:'+str(out/'results.xml')],out,90)
    cases=ET.parse(out/'results.xml').getroot().findall('./testsuite/testcase')
    actual=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases]
    ok=len(actual)==len(b.TESTS) and set(actual)==set(b.TESTS) and all(x.attrib.get('status')=='run' and
        not any(x.findall(tag) for tag in ('failure','error','skipped')) for x in cases)
    save(W/'summary2.json',dict(status='PASS' if ok else 'FAIL',process=process,image=ready['image'],tests=[x.attrib for x in cases],
        filter=':'.join(b.TESTS),xml=pin(out/'results.xml'),scope='Three host identity/prefix cases; first C1083 retained; no native GPU/model/performance claim.'))
    assert ok;print('PASS',len(cases),'host cases')


if __name__=='__main__':
    try:{'prepare':prepare,'compile':compile,'link':link,'run':run}[sys.argv[1]]()
    except BaseException:
        (W/('failure-refinement-'+sys.argv[1]+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
