"""Reuse the current object closures; explicit canonical-source builds only."""
from pathlib import Path
import hashlib, importlib.util, json, sys, time
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('existing_build', R/'.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
read, save, pin, exact, key = t.read, t.save, t.pin, t.exact, t.key
CLI = R/'.scratch/inference-hidden-indexed-refinement-20261028'
COMP = R/'.scratch/inference-indexed-store-20261028'
TINY = R/'.scratch/inference-hidden-state-20261028'
SDK = R/'.scratch/inference-public-arena-identity-20261028'
SOURCES = {'model':'engine/models/qwen35/main.cc', 'test':'tests/tools/inference_slot_transactions_test.cc',
           'tiny':'tests/tools/qwen_host_image_test.cc', 'probe':'engine/models/qwen35/batch_probe.cc'}
OWNED = [*SOURCES.values(), 'engine/inference/slot_transactions.h',
         'engine/models/qwen35/probe_page_prefixes.h', 'include/hyle/compute/paged_arena.h',
         'tests/tools/qwen_mtp_batch_state_case.h', 'tests/tools/qwen_mtp_prefix_value_probe.cc']

def freeze():
    W.mkdir(exist_ok=True)
    assert not (W/'plan.json').exists()
    dependencies = read(read(TINY/'compile/compiled.json')['actual_dependencies']['path'])
    project = {key(R/p):pin(R/p) for p in OWNED}
    for row in dependencies:
        p = Path(row['path'])
        if p.is_relative_to(R) and '.scratch' not in p.relative_to(R).parts:
            project[key(p)] = pin(p)
    save(W/'project-before.json', list(project.values()))
    snapshots=[]
    for name in dict.fromkeys(OWNED):
        src=R/name; out=W/'source'/name; out.parent.mkdir(parents=True,exist_ok=True)
        out.write_bytes(src.read_bytes()); snapshots.append(dict(original=pin(src),snapshot=pin(out)))
    bases={'cli':read(CLI/'ready.json'),'component':read(COMP/'ready-component.json'),'tiny':read(TINY/'ready.json')}
    templates={'model':CLI/'logs/model/command.json','test':COMP/'logs/slots-test/command.json',
               'tiny':TINY/'logs/compile/command.json','probe':TINY/'logs/compile/command.json'}
    for name,template in templates.items():
        old=read(template)['command']; out=W/'compile'/name
        args=[old[0], '/I'+str(R/'include'), '/I'+str(R), '/I'+str(R/'engine/models/qwen35')]
        for n,a in enumerate(old[1:],1):
            if old[n-1].casefold()=='/sourcedependencies': a=str(out/'dependencies.json')
            elif a.casefold().startswith('/fo'): a='/Fo'+str(out/'unit.obj')
            elif a.casefold().startswith('/fd'): a='/Fd'+str(out/'unit.pdb')
            elif a.lower().endswith(('.cc','.cpp','.cxx')): a=str(R/SOURCES[name])
            args.append(a)
        if name=='test':args.append('/DHYLE_COMPUTE_CPU=1')
        save(W/'recipes'/(name+'.json'),dict(command=args,cwd=str(R),timeout_seconds=240))
    save(W/'plan.json',dict(sources={k:pin(R/v) for k,v in SOURCES.items()}, snapshots=snapshots,
        project=pin(W/'project-before.json'),bases=bases,arena=read(SDK/'compile/arena/compiled.json')['object'],
        old_arena=read(SDK/'plan.json')['original_arena']['object'],script=pin(__file__),
        policy='Original compiler flags; canonical project source avoids relocated quoted includes. SDK dependencies are actual compiler observations, not prequalification.',
        counts=dict(Model_CXX=1,cohort_test_CXX=1,tiny_CXX=1,optional_probe_CXX=1,SDK_builds=0,NVCC=0,downloads=0)))
    print('FROZEN canonical sources; existing 226/228/225 closures')

def validate():
    p=read(W/'plan.json');exact(p['script']);exact(p['project'])
    for row in read(p['project']['path']):exact(row)
    for row in p['snapshots']:exact(row['original']);exact(row['snapshot'])
    return p

def compile_one(name):
    p=validate();assert name in SOURCES
    out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
    process=t.execute(read(W/'recipes'/(name+'.json'))['command'],W/'logs'/name,240)
    data=read(out/'dependencies.json')['Data'];assert key(data['Source'])==key(R/SOURCES[name])
    validate()
    deps=[pin(x) for x in dict.fromkeys([data['Source'],*data['Includes']])]
    save(out/'actual-dependencies.json',deps)
    save(out/'compiled.json',dict(source=p['sources'][name],object=pin(out/'unit.obj'),process=process,
        command=pin(W/'logs'/name/'command.json'),dependencies=pin(out/'actual-dependencies.json')))
    print('CXX_PASS',name)

def link(name):
    p=validate();base=p['bases']['cli' if name in ('model','probe') else 'component' if name=='test' else 'tiny']
    rows=read(base['inputs']['path']);replacements={key(p['old_arena']['path']):p['arena']}
    unit=read(W/'compile'/name/'compiled.json')['object'];removed=set()
    if name=='model':replacements[key(base['compiled']['object']['path'])]=unit
    elif name=='tiny':replacements[key(base['compiled']['object']['path'])]=unit
    elif name=='probe':
        removed.add(key(base['compiled']['object']['path']))
        entry=[x for x in rows if 'inference-current-closure-20261026/engine/entry/unit.obj' in x['path'].replace('\\','/')]
        assert len(entry)==1;removed.add(key(entry[0]['path']))
    expected=(226 if name=='model' else 229 if name=='test' else 225)
    rows=[replacements.get(key(x['path']),x) for x in rows if key(x['path']) not in removed]
    if name in ('test','probe'):rows.append(unit)
    assert len(rows)==expected
    for row in rows:exact(row)
    image=W/'bin'/(name+'.exe');image.parent.mkdir(exist_ok=True);assert not image.exists()
    args=[];seen=set()
    for a in read(base['recipe']['path'])['command']:
        k=key(a)
        if k in removed:continue
        if k in replacements:a=replacements[k]['path'];seen.add(k)
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
            if a.upper().startswith(prefix):a=prefix+str(image.with_suffix(suffix));break
        args.append(a)
    assert set(replacements)==seen
    if name in ('test','probe'):args.append(unit['path'])
    save(W/('inputs-'+name+'.json'),rows)
    process=t.execute(args,W/'link'/name,180)
    save(W/('ready-'+name+'.json'),dict(image=pin(image),inputs=pin(W/('inputs-'+name+'.json')),
        recipe=pin(W/'link'/name/'command.json'),process=process,source=p['sources'][name]))
    print('LINK_PASS',name,expected)

def run_test():
    p=validate();image=read(W/'ready-test.json')['image'];exact(image)
    out=W/'test-run';assert not out.exists()
    t.execute([image['path'],'--gtest_filter=InferenceSlotTransactions.*','--gtest_fail_fast',
        '--gtest_output=xml:'+str(out/'results.xml')],out,90)
    print('TEST_PROCESS_PASS; inspect actual XML/output')

if __name__=='__main__':
    a=sys.argv[1]
    if a=='freeze':freeze()
    elif a=='compile':compile_one(sys.argv[2])
    elif a=='link':link(sys.argv[2])
    elif a=='run-test':run_test()
    else:raise ValueError(a)
