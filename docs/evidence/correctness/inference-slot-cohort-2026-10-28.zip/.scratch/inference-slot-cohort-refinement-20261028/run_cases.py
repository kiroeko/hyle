from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
b=module('cohort_build',W/'build.py');read,save,pin=b.read,b.save,b.pin
OLD=R/'.scratch/inference-hidden-indexed-refinement-20261028'
MODELS={k:OLD/'runs'/k for k in ('ordinary-two-turn','mtp-single','mtp-two-turn')}
MODELS['k2']=OLD/'k2/candidate'
TINY=R/'.scratch/inference-hidden-state-20261028'

def parse(kind,name):
    out=W/'runs'/kind/name;process=read(out/'process.json');assert process['exit']==0 and not process['timed_out']
    if kind=='model':
        old,now=read(MODELS[name]/'stdout.log'),read(out/'stdout.log')
        f=module('original_non_time',R/'.scratch/inference-wave-recovery-final-20261027/run.py')
        differences=f.changed(f.facts.non_time(old),f.facts.non_time(now))
        save(out/'non-time-differences.json',differences);assert not differences,differences[:8]
        assert now['live_committed_versions']==0
    else:
        reports=[json.loads(x) for x in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if x.startswith('{')]
        assert len(reports)==1;now=reports[0]
        assert now['status']=='PASS' and now['final_versions']==0
        if name.endswith('r2'):
            assert now['accepted']==[[1,3],[3,1]]
            for key in ('same_width_original_candidates','old_snapshots_unchanged','controlled_rng_unchanged',
                        'nextn_checked_id_failure_recovered','same_program_valid_retry'):assert now[key],key
        else:
            assert now['all_initialized_bytes_equal'] and now['old_alias_unchanged'] and now['final_images']==0
        save(out/'report.json',now)
    save(out/'summary.json',dict(status='PASS',process=process,image=read(W/('ready-'+('model' if kind=='model' else 'tiny')+'.json'))['image'],performance_claim=False))
    print('PASS',kind,name)

def run(kind,name):
    b.validate();ready=read(W/('ready-'+('model' if kind=='model' else 'tiny')+'.json'));b.exact(ready['image'])
    if kind=='model':args=read(MODELS[name]/'command.json')['command'][1:]
    else:
        names={'cpu-r2':'cpu-r2-attempt2'}
        selected=next(x for x in read(TINY/'run-plan-attempt2.json')['ordered'] if x['name']==names.get(name,name))
        args=selected['command'][1:]
    out=W/'runs'/kind/name;assert not out.exists(),'Preserve every actual process'
    b.t.execute([ready['image']['path'],*args],out,180 if kind=='model' else 90)
    parse(kind,name)

if __name__=='__main__':
    action,kind,name=sys.argv[1:]
    if action=='run':run(kind,name)
    elif action=='parse':parse(kind,name)
    else:raise ValueError(action)
