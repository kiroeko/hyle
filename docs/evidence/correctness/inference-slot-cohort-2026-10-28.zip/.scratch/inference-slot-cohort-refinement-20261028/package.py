"""Offline archive only: no CXX, link, GPU, model, download or automatic retry.

The root invokes this after the finite recorded checks. It preserves the first
failed builds/test and the exact repairs; it never turns missing checks into PASS.
"""
from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
FIRST = R / '.scratch/inference-slot-cohort-20261028'
PUBLIC = R / '.scratch/inference-public-arena-identity-20261028'
OLD = R / '.scratch/inference-hidden-indexed-refinement-20261028'
DEST = R / 'docs/evidence/correctness/inference-slot-cohort-2026-10-28'
BASE = '885ed730a89aa8efde09b7570ca283f23e2e73a1'
MODEL_CASES = ('ordinary-two-turn', 'mtp-single', 'mtp-two-turn', 'k2')
TINY_CASES = ('cpu-r2', 'cuda-r2', 'cpu-lag1', 'cuda-lag1', 'cpu-hostrestore')
METADATA = {'.json', '.log', '.py', '.xml', '.d', '.diff'}
OMIT = {'package-manifest.json', 'package-result.json', 'source-index.json'}


def read(path):
    return json.loads(Path(path).read_bytes())


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def identity(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def pin(path):
    path = Path(path).resolve()
    return dict(path=str(path), **identity(path.read_bytes()))


def exact(row):
    assert pin(row['path']) == row, ('Changed frozen small source/receipt', row['path'])


def process(folder, success=True):
    value = read(Path(folder) / 'process.json')
    assert value['state'] == 'TERMINAL' and not value.get('timed_out', False), str(folder)
    assert (value['exit'] == 0) == success, str(folder)
    return value


def xml_tests(path, count, failures=0, skipped=0):
    root = ET.parse(path).getroot()
    cases = list(root.iter('testcase'))
    assert len(cases) == count, str(path)
    assert sum(bool(list(case.iter('failure'))) for case in cases) == failures, str(path)
    assert sum(case.attrib.get('result') == 'skipped' or bool(list(case.iter('skipped'))) for case in cases) == skipped, str(path)
    return [dict(case.attrib, failures=len(list(case.iter('failure')))) for case in cases]


# The existing complete-report comparator's exact non-time projection; no
# model/result, cache, capture, overlap, ledger or other semantic key is removed.
# Source: .scratch/inference-current-review-profile-20261027/analyze.py::non_time.
def non_time(value):
    if isinstance(value, list): return [non_time(v) for v in value]
    if isinstance(value, dict):
        return {k: non_time(v) for k, v in value.items() if not any(s in k for s in
                ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return value


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Preserve existing evidence'
    initial, current = read(FIRST/'plan.json'), read(W/'plan.json')
    assert initial['sources']['model']['sha256'] == '35cf28399872a3b7c1d095c0f6b10816c12ae3f0aadc80bda46651b529f0f7fb'
    assert initial['sources']['test']['sha256'] == '4804bd4b6e62c65f8e9d21155507f10a9423b706b30e1c2808f227f2b8e5c195'
    assert current['sources']['model']['sha256'] == 'f62d7ccb7a4366f6d7f2ed11e9d10acf03e786305ecbb4bc63bd5a5a5b72f563'
    assert current['sources']['test']['sha256'] == 'de73c7e66d10dc9f10ab1b605cbedc20ca927485503bdf3bb9d86b6a6d67cb38'
    builds = {name: read(W/('ready-'+name+'.json')) for name in ('model', 'test', 'tiny', 'probe')}
    expected_counts = dict(model=226, test=229, tiny=225, probe=225)
    for name, ready in builds.items():
        exact(ready['inputs']); exact(ready['recipe'])
        assert len(read(ready['inputs']['path'])) == expected_counts[name]
        assert ready['process']['exit'] == 0
        assert ready['source'] == current['sources'][name]
        assert read(W/'compile'/name/'compiled.json')['process']['exit'] == 0

    # Every preserved original attempt remains part of this result.
    failed_builds = []
    for name in ('model', 'tiny'):
        actual = process(FIRST/'logs'/name, False)
        text = (FIRST/'logs'/name/'stdout.log').read_bytes()
        assert b'C4456' in text and b'C2220' in text
        failed_builds.append(dict(unit=name, process=actual, cause='C4456 shadowing treated as an error by the unchanged /WX recipe'))
    first_test = dict(process=process(FIRST/'test-run', False),
        cases=xml_tests(FIRST/'test-run/results.xml', 4, failures=1, skipped=3),
        cause='Fixture omitted the published Gather output binding; prepare_replay refused, then .value() obscured the original status')
    core = dict(process=process(W/'test-run'), cases=xml_tests(W/'test-run/results.xml', 4),
        image=builds['test']['image'], scope='Four actual CPU Graph lease/cohort/observation cases, no model or GPU')
    sdk_summary = read(PUBLIC/'summary2.json')
    assert sdk_summary['status'] == 'PASS' and sdk_summary['process'] == process(PUBLIC/'run-attempt2')
    sdk_tests = xml_tests(PUBLIC/'run-attempt2/results.xml', 3)
    sdk_failure = process(PUBLIC/'logs/host-test', False)
    assert b'C1083' in (PUBLIC/'logs/host-test/stdout.log').read_bytes()
    assert read(PUBLIC/'abi-proof.json')['tokens_equal_after_exact_additions_removed'] is True
    public_ready = read(PUBLIC/'ready2.json')
    assert len(read(public_ready['inputs']['path'])) == 229
    native = read(PUBLIC/'plan.json')['native_objects']
    assert len(native) == 8
    for name in builds:
        rows = read(builds[name]['inputs']['path'])
        for native_pin in native.values():
            assert native_pin in rows, ('Lost original native product object', name, native_pin['path'])
        assert read(PUBLIC/'compile/arena/compiled.json')['object'] in rows

    complete_models = []
    for name in MODEL_CASES:
        folder = W/'runs/model'/name
        previous = OLD/('k2/candidate' if name == 'k2' else 'runs/'+name)
        actual, oracle = read(folder/'stdout.log'), read(previous/'stdout.log')
        assert read(folder/'non-time-differences.json') == []
        assert non_time(actual) == non_time(oracle), name
        assert actual['live_committed_versions'] == 0
        summary = read(folder/'summary.json')
        assert summary['status'] == 'PASS' and summary['process'] == process(folder)
        assert summary['image'] == builds['model']['image']
        complete_models.append(dict(case=name, process=summary['process'],
            current_raw_report=pin(folder/'stdout.log'), historical_raw_report=pin(previous/'stdout.log'),
            complete_non_time_differences=[], final_live_versions=0,
            reference_scope='Historical 01c1 Hyle same-mode correctness oracle; not a current timing arm or peer comparison'))

    tiny = []
    for name in TINY_CASES:
        folder = W/'runs/tiny'/name
        report = read(folder/'report.json')
        raw = [json.loads(line) for line in (folder/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert raw == [report] and report['status'] == 'PASS' and report['final_versions'] == 0
        summary = read(folder/'summary.json')
        assert summary['status'] == 'PASS' and summary['process'] == process(folder)
        assert summary['image'] == builds['tiny']['image']
        if name.endswith('r2'):
            assert report['accepted'] == [[1, 3], [3, 1]]
            for field in ('same_width_original_candidates', 'old_snapshots_unchanged', 'controlled_rng_unchanged',
                          'nextn_checked_id_failure_recovered', 'same_program_valid_retry'):
                assert report[field] is True, (name, field)
        else:
            assert report['all_initialized_bytes_equal'] and report['old_alias_unchanged'] and report['final_images'] == 0
        tiny.append(dict(case=name, process=summary['process'], report=pin(folder/'report.json'), facts=report))

    # Reuse frozen source snapshots. Do not scan or recopy unchanged dependency
    # trees: their exact compiler observations and link identities remain receipts.
    sources, by_sha, archive = [], {}, {}
    def add(path, member=None):
        path = Path(path).resolve()
        member = member or path.relative_to(R).as_posix()
        assert path.suffix.lower() not in {'.obj', '.exe', '.pdb', '.dll', '.lib', '.bin', '.safetensors', '.gguf'}
        data = path.read_bytes()
        if member in archive: assert archive[member] == data
        archive[member] = data
        return dict(path=str(path), archive=member, **identity(data))
    def source(original, snapshot, stage):
        exact(snapshot)
        rel = Path(original['path']).relative_to(R).as_posix()
        data = Path(snapshot['path']).read_bytes(); digest = identity(data)['sha256']
        if digest not in by_sha:
            by_sha[digest] = 'source-by-sha256/'+digest+'/'+Path(rel).name
            archive[by_sha[digest]] = data
        base = subprocess.run(['git','show',BASE+':'+rel], cwd=R, capture_output=True, check=False)
        baseline = base.stdout if base.returncode == 0 else None
        change = None
        if baseline != data:
            patch = ''.join(difflib.unified_diff((baseline or b'').decode('utf-8-sig').splitlines(True),
                data.decode('utf-8-sig').splitlines(True), fromfile=BASE+'/'+rel if baseline is not None else '/dev/null', tofile=stage+'/'+rel))
            change = 'diffs/'+stage+'/'+rel+'.diff'; archive[change] = patch.encode('utf-8')
        sources.append(dict(stage=stage, original=original, snapshot=snapshot, archive=by_sha[digest],
            git_base=dict(commit=BASE, path=rel, sha256=identity(baseline)['sha256']) if baseline is not None else None,
            diff=change))
    for stage, plan in (('initial', initial), ('refined', current)):
        for row in plan['snapshots']: source(row['original'], row['snapshot'], stage)
    for row in read(PUBLIC/'source-freeze.json')['sources']:
        rel = Path(row['path']).relative_to(R)
        candidates = (PUBLIC/'source'/rel, W/'source'/rel, FIRST/'source'/rel, R/rel)
        retained = next((path for path in candidates if path.exists() and identity(path.read_bytes())['sha256'] == row['sha256']), None)
        assert retained is not None, ('Missing exact owned source recorded by public freeze', row['path'])
        # The public compiler froze its three actual TUs/headers, while the
        # other migrated diagnostic sources were identity-recorded only. Their
        # same pinned bytes come from the shared candidate snapshot or checkout;
        # do not pretend those additional public snapshots existed at compile.
        source(row, dict(row, path=str(retained.resolve())), 'public-arena-owned-source')
    cmake = R/'tests/graph/CMakeLists.txt'
    cmake_pin = pin(cmake)
    assert cmake_pin['sha256'] == 'c1cbe92894dc61000c6031796019e63dd11793dbef90667137ac859d22f515fa'
    source(cmake_pin, cmake_pin, 'test-target-declaration')

    for folder in (FIRST, W, PUBLIC):
        for path in sorted(folder.rglob('*')):
            if not path.is_file() or path.suffix.lower() not in METADATA or path.name in OMIT: continue
            relative = path.relative_to(folder)
            if any(part in {'source', 'bin', 'package-artifacts', '__pycache__'} for part in relative.parts): continue
            assert path.stat().st_size < 2_000_000, ('Unexpected large metadata; review before archive', str(path))
            add(path)
    # The same original small runtime/fixture identities and complete raw oracle
    # reports are enough; model bodies, SDK files and object images stay excluded.
    for name in MODEL_CASES:
        folder = OLD/('k2/candidate' if name == 'k2' else 'runs/'+name)
        for filename in ('command.json','process.json','stdout.log','stderr.log'):
            add(folder/filename)
    for path in (PUBLIC/'runtime-plan.json', PUBLIC/'environment.json',
                 R/'.scratch/inference-current-review-profile-20261027/analyze.py',
                 R/'.scratch/inference-wave-recovery-final-20261027/run.py'):
        add(path)
    for kind, cases in (('tiny', TINY_CASES), ('model', MODEL_CASES)):
        for case in cases:
            args = read(W/'runs'/kind/case/'command.json')['command']
            fixture = Path(args[2] if kind == 'tiny' else args[args.index('--inputs')+1])
            for filename in ('weights.tsv', 'prompt.ids'):
                if (fixture/filename).exists(): add(fixture/filename)
            if '--schedule' in args:
                add(Path(args[args.index('--schedule')+1]))

    attempts = []
    for stage, directory in (('initial', FIRST), ('refined', W), ('public-arena', PUBLIC)):
        for path in sorted((directory/'logs').glob('*/process.json')):
            attempts.append(dict(stage=stage, unit=path.parent.name, process=read(path), receipt=pin(path)))
    assert len(attempts) == 10 and sum(row['process']['exit'] != 0 for row in attempts) == 3
    links = [dict(stage=stage, unit=path.parent.name, process=read(path))
        for stage, directory in (('initial', FIRST/'link'), ('refined', W/'link'), ('public-arena', PUBLIC/'link-attempt2'))
        for path in (list(directory.glob('*/process.json')) if directory.name=='link' else [directory/'process.json'])]
    assert len(links) == 6 and all(row['process']['exit'] == 0 for row in links)
    all_processes = [row['process'] for row in attempts] + [row['process'] for row in links]
    all_processes += [first_test['process'], core['process'], sdk_summary['process']]
    all_processes += [row['process'] for row in complete_models] + [row['process'] for row in tiny]
    first_time = min(row['started'] for row in all_processes)
    last_time = max(row['started']+row['seconds'] for row in all_processes)
    evidence = dict(schema='hyle.inference-slot-cohort.correctness.v1', status='FINITE_RECORDED_CHECKS_PASS_WITH_ORIGINAL_FAILURES_PRESERVED',
        generated_utc=datetime.now(timezone.utc).isoformat(), git_base=BASE,
        scope='Common original Store-transaction staging/binding/real-retirement protocol and public exact arena identity; no new executor, resource pool or Completion',
        source_scope=dict(model=current['sources']['model'], helper_sha256='46b086271c24f31183bae9af22ee54a5d8a99d545a339aa8d2fcc59d6a045a3d',
            checked_failure_case_sha256='6e029e9f5af832df0c2b4c583471367995725cc51567289de7e831285e89df0e', manifest='sources.json'),
        actual_time_range_utc=[datetime.fromtimestamp(first_time,timezone.utc).isoformat(), datetime.fromtimestamp(last_time,timezone.utc).isoformat()],
        protocol=dict(cold_counts_then_original_pool_layout=True, layout_set_once_refusals_preserve_original=True,
            original_atomic_cohort_bind=True, real_take_only=True, partial_return_facts_preserved=True,
            original_whole_graph_success_and_append_attestation_before_publication=True,
            model_kind_layer_source_index_and_accepted_prefix_policy_remain_in_model=True,
            same_cold_nextn_step_and_completion_reused=True, failed_episode_retained_until_real_retirement=True,
            application_completion_root_released_on_original_cold_scope_handoff=True),
        builds=dict(compiler_attempts=attempts, links=links, CXX_attempts=10, CXX_successes=7, CXX_failures=3,
            link_successes=6, whole_SDK_rebuilds=0, NVCC=0, downloads=0,
            current_images={key:value['image'] for key,value in builds.items()},
            current_input_counts=expected_counts, native_product_objects_retained=native,
            optional_public_batch_probe=dict(compile_and_link='PASS', executed=False, reason='Large raw metrics producer intentionally not run')),
        original_failures=dict(C4456=failed_builds, initial_cohort_test=first_test,
            SDK_C1083=dict(process=sdk_failure, cause='Relocated test fixture quoted include omitted original test directory; recipe-only repair retained original successful arena object'),
            initial_metadata_repair='Original arena descriptor reduced to its object pin in link metadata; no source/compiler action changed'),
        public_arena=dict(process=sdk_summary['process'], tests=sdk_tests, abi_proof=read(PUBLIC/'abi-proof.json'),
            scope='Add-only nonvirtual identity query delegates unchanged original predicate; diagnostic prefix reads use only actual bounded initialized rows'),
        cohort_tests=core, complete_model_checks=complete_models, tiny_checks=tiny,
        coverage=dict(successful_test_or_consumer_processes=11, failed_original_test_processes=1,
            distinct_final_host_cases=7, current_tiny_processes=5, current_complete_model_processes=4,
            nextn_checked_input_error_and_same_program_recovery_backends=['cpu','cuda'],
            per_backend_snapshot_and_state_byte_equality=True, cross_backend_bit_equality_claim=False,
            unknown_pending_native_retirement_failure_journey='NOT_RUN; guarded by unchanged original Graph retirement gates and retained Step bookkeeping',
            native_GPU_hardware_fault_injection='NOT_RUN', Apple_Vulkan_runtime='NOT_RUN',
            MTP_functional_scope_reopened=False, trained_quality_claim=False, throughput_or_memory_peak_claim=False),
        archive_policy='Only changed owned source versions/diffs, exact dependency/link identity metadata, commands, logs and full producer reports; no SDK/object/EXE/PDB/DLL/model bodies or mass source index')
    archive['sources.json'] = encode(sources)
    archive['result.json'] = encode(evidence)
    manifest = [dict(archive=name, **identity(data)) for name,data in sorted(archive.items())]
    archive['manifest.json'] = encode(manifest)
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=9) as output:
        for name,data in sorted(archive.items()): output.writestr(name,data)
    zip_pin = pin(DEST.with_suffix('.zip'))
    evidence['archive'] = zip_pin
    evidence['archive_members'] = len(archive)
    evidence['archive_bytes_excluding_compression'] = sum(len(data) for data in archive.values())
    DEST.with_suffix('.json').write_bytes(encode(evidence))
    (W/'package-manifest.json').write_bytes(encode(manifest))
    result = dict(evidence=pin(DEST.with_suffix('.json')), archive=zip_pin, members=len(archive))
    (W/'package-result.json').write_bytes(encode(result))
    print(json.dumps(result))


if __name__ == '__main__':
    main()
