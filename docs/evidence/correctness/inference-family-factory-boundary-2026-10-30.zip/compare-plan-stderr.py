"""Compare only documented existing cold plan summaries; no provider claim."""
from pathlib import Path
import importlib.util,re,json
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('repair_plan_summary_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
prefixes=('compile full text finite family ','compiled text finite family ','planned_replay T=','compiled T=','hybrid_plan ')
checks=[]
for case in ('ordinary-single','mtp-single','ordinary-two','mtp-two','cpu-ffn-real-cuda'):
 arms={}
 for arm in ('baseline','candidate'):
  path=W/'runs'/arm/case/'attempt1/stderr.log'
  lines=[line for line in path.read_text(encoding='utf-8-sig').splitlines() if line.startswith(prefixes)]
  assert lines
  arms[arm]=[re.sub(r' \w+_seconds=[^ ]+','',line) for line in lines]
 checks.append(dict(case=case,equal=arms['baseline']==arms['candidate'],existing_plan_lines=arms,
  differences=[] if arms['baseline']==arms['candidate'] else [dict(baseline=arms['baseline'],candidate=arms['candidate'])]))
b.save(W/'existing-plan-summary-comparison.json',dict(status='ALL_RECORDED_COLD_SUMMARIES_EQUAL' if all(row['equal'] for row in checks) else 'RECORDED_PLAN_SUMMARY_DIFFERENCES',
 checks=checks,selected_prefixes=prefixes,excluded_fields='Only*_seconds tokens on the selected plan lines.',
 scope='Exact existing stderr counters for preparedphase and recorded family totals/hybridplans. This is not every exactchild or a perprovider/copy-step/replica route export. DefaultJSON equality remains aggregateonly.'))
print(json.dumps(dict(cases=5,equal=[row['case'] for row in checks if row['equal']],different=[row['case'] for row in checks if not row['equal']])) )
