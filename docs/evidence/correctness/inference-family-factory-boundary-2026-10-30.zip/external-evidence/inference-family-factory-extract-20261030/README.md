# Complete Qwen Family factory: frozen scratch candidate

Base HEAD: `5cda94069f241c45b6c6f6995d5d4564f8f2e7b2`. The product tree remains unchanged. No CXX, linker, native, GPU, download or performance work has been run for this candidate.

The six-file patch creates `family_factory.h/.cc`, expands the sole model-owned cold source inventory and updates main/weights. The factory owns the complete original Family graph construction, finite-exact compilation, `PreparedProgramFamily::prepare`, and every child resource/packed validation. Model retains original admission/policy/key/table/cache/optional-head preparation and final complete publication. Main shrinks from 9,117 to 8,614 lines; the goal is the compiled cold boundary and original stable ownership, not that line count.

The four concrete input groups, synchronous borrows and resource/failure changes are specified in `design.md`; exact candidate/base/source-input pins are in `plan.json` and `source-input-pins.json`. No Model/Session/ColdResources, runtime callback table or alternate owner enters the factory. `PreparedSampling` remains only a forward-declared original pointer in Family, attached by Model after success. Family graph/program/literal field order and stable unique_ptr placement are preserved.

Static evidence:

- `static-report.json`: full graph/compile/program body restores to 6,371 tokens with this checker's explicit cold-fact/preparation projection; mathematical operations, port order, shapes/precision/frequencies, source/store dependencies, variant ordering and compile budgets remain exact. Moved types and the packed/logits helpers retain their original text. Complete main inverse restores original text.
- Independent reviewer uses a separate tokenizer/mapping: `.scratch/inference-family-factory-review-20261030/independent-candidate-review.json` and `candidate-notes.md`. It finds the same semantic preservation and no static blocker. Token counts differ by tokenizer; equality is checked within each parser, not by comparing the counts.
- Quoted-include closures: private header110, cold implementation150, weights145 local files, no missing includes or Qwen `session_state.h`/`paged_sequence.h`/main. Generic Backend runtime/resource types remain legitimate. These are source checks, not compiler dependency receipts.
- Existing engine/probe and nine tests source-list consumers continue to use the one `cold_sources.cmake`; their CMake gates and backend-capability setup are unchanged. No CMake configure/full build is claimed.

Intentional changes requiring later finite evidence: original valid chunks/batch are rejected before materializing cache/head; successfully prepared original cache/head now precede local graph construction and survive its failure; failed unpublished candidates no longer merge partial workspace diagnostic peaks; cold_seconds excludes caller cache/head preparation. No claim of identical budget high-water or runtime retry behavior follows merely from being cold. Original optional publication/sentinel, same budgets/leases, real-error propagation, packed/compact native-free capability fallback and no partial family-map insertion remain source-reviewed.

Default full-V uses an empty prepared draft view and unchanged original score projection. Explicit mapping remains a synchronous view of the original optional selected head and original-ID tensor; the free weights helper preserves original select/upload/freeze/hash. It adds no alternate prepared owner or hot lookup.

Run `prepare.py` only when intentionally regenerating the candidate; it resets the preliminary plan. `check.py` is static-only. `seal.py` adds final independent/input pins. All three write scratch only. Root must review/apply before any harness compile. Phase/recovery and performance are outside this patch.
