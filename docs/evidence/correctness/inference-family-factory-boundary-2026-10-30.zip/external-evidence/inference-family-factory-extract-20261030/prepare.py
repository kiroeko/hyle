"""Prepare the complete model-private cold Family factory in scratch only."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = '5cda94069f241c45b6c6f6995d5d4564f8f2e7b2'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == BASE

def load(rel):
    raw = (R / rel).read_bytes()
    dst = W / 'base' / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists(): assert dst.read_bytes() == raw
    else: dst.write_bytes(raw)
    return raw.decode().replace('\r\n', '\n')

def pin(path):
    p = Path(path); b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def region(text, start, end):
    return text[text.index(start):text.index(end, text.index(start))]

def once(text, old, new):
    assert text.count(old) == 1, (text.count(old), old[:120])
    return text.replace(old, new, 1)

def write(rel, text):
    p = W / 'candidate' / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    original = R / rel
    crlf = original.exists() and original.read_bytes().count(b'\r\n') > 0
    if not original.exists(): crlf = True
    p.write_bytes(text.replace('\n', '\r\n').encode() if crlf else text.encode())

MAIN = 'engine/models/qwen35/main.cc'
WEIGHTS_H = 'engine/models/qwen35/weights.h'
WEIGHTS_CC = 'engine/models/qwen35/weights.cc'
INVENTORY = 'engine/models/qwen35/cold_sources.cmake'
HEADER = 'engine/models/qwen35/family_factory.h'
SOURCE = 'engine/models/qwen35/family_factory.cc'
main, weights_h, weights_cc, inventory = map(load, (MAIN, WEIGHTS_H, WEIGHTS_CC, INVENTORY))
original_main = main
sampling_type = region(main, 'struct SamplingConfiguration final {', '// Typed ready inputs')
family_types = region(main, 'struct FamilyPorts {', 'struct FamilyChild final {')
head_type = region(main, '// Extra cold draft projection only.', '// Actual cold storage')
packed = region(main, '// Distinguish direct packed contractions', 'struct SamplingConfiguration final {')
logits = region(main, 'sampling::LogitsInputsFor<V> prepare_logits_inputs(', 'GenerationBoundary generation_boundary(')
old_record = region(main, '  void record_execution_plan(', '  void prepare_cache()')
old_prepare = region(main, '  bool prepare_family(', '  // These capacities are physical carriers.')
old_helpers = region(main, '  V draft_scores(', '  const FfnPlacement ffn_placement;')

header = '''#pragma once

// Qwen-private cold graph/program inventory. Runtime Model/Session admission,
// mutable state, carriers and publication remain with the original caller.
#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <vector>

#include "graph_builder.h"
#include "target_graph.h"
#include "../../inference/prepared_program_family.h"
#include "../../inference/sampling_graph.h"

namespace qwen35 {
namespace inference = hyle::inference;
namespace sampling = hyle::inference::sampling;

'''+sampling_type+'''struct PreparedSampling; // Stable owner lives in the original ColdResources.

'''+family_types+'''// An optional already prepared dense projection. Empty is the normal full-V
// path. The two Tensor children stay with their original cold owner; this view
// is borrowed synchronously and never becomes a second permission/owner.
struct DraftProjectionView final {
  StoredProjection projection;
  Tensor *original_ids = nullptr;
};

struct FamilyBuildRequest final {
  std::span<const std::size_t> chunks; // Original validated finite inventory.
  std::size_t requests = 1, prefix_rows = 1;
  GraphRole role = GraphRole::kText;
  TextCompletion completion = TextCompletion::kEmitNext;
  RowPacking packing = RowPacking::kRectangular;
  bool diagnostic = false, admitted_exact = false;
};
struct FamilyModelFacts final {
  const ModelGeometry &geometry;
  PrecisionProfile precision;
  std::map<std::string, LoadedWeight> &weights;
  const ProjectionBindings &projections;
  const WeightMeanings &weight_meanings;
  std::size_t cpu_ffn_layers = 0;
};
struct FamilyPreparedFacts final {
  const c::BatchSchema &attention_schema;
  std::span<const c::BatchSchema> attention_schemas;
  std::span<const StateSchema> recurrent_descriptions;
  std::uint32_t state_slots = 0, hidden_slots = 0;
  bool retain_hidden = false, emit_successor = false;
  DraftProjectionView draft_projection;
};
struct FamilyCompileContext final {
  inference::Backend &execution;
  const c::ResourceBudget &allocation_budget;
  const c::ResourceBudget &execution_budget;
};
struct ExecutionPlanFacts final {
  std::array<std::size_t, 3> workspace_peak{}, workspace_limits{};
  std::size_t domain_count = 0;
};
struct FamilyBuildResult final {
  std::unique_ptr<Family> family; // Empty only for the original cold capability fallback.
  ExecutionPlanFacts plan;
};

// All borrowed inputs are synchronous. The complete original Graph and its
// literals/programs have stable addresses before any child is prepared.
FamilyBuildResult build_family(const FamilyBuildRequest &request,
    const FamilyModelFacts &model, const FamilyPreparedFacts &prepared,
    const SamplingConfiguration &configuration, const FamilyCompileContext &context);

// Shared cold checks/math also used by the original draft/frontier builders.
// Constant spans are inspected here and never retained in returned facts.
ExecutionPlanFacts inspect_execution_plan(const inference::Backend &execution,
    std::size_t cpu_ffn_layers, const g::CompileReport &report,
    std::span<const g::ConstantBinding> constants);
sampling::LogitsInputsFor<V> prepare_logits_inputs(Recipe &recipe, sampling::LogitsPolicy policy);
V draft_scores(Recipe &recipe, V selected_hidden, DraftProjectionView projection);
V original_draft_id(Recipe &recipe, V compact_id, DraftProjectionView projection);

} // namespace qwen35
'''

# Keep a single resource-contract implementation for Family and other cold builders.
record = '\n'.join(line[2:] if line.startswith('  ') else line for line in old_record.splitlines())+'\n'
record = once(record, 'void record_execution_plan(const g::CompileReport &report, std::span<const g::ConstantBinding> constants) {',
    'ExecutionPlanFacts inspect_execution_plan(const inference::Backend &execution,\n    std::size_t cpu_ffn_layers, const g::CompileReport &report,\n    std::span<const g::ConstantBinding> constants) {\n  ExecutionPlanFacts facts;')
record = record.replace('ffn_placement.cpu_layers()', 'cpu_ffn_layers').replace('known_workspace_peak', 'facts.workspace_peak').replace('known_workspace_limits', 'facts.workspace_limits')
record = once(record, '    return;', '    facts.domain_count = 1;\n    return facts;')
record = once(record, '  if (!cpu_ffn_layers) return;', '  if (!cpu_ffn_layers) return facts;')
record = once(record, '  for (std::size_t i = 0; i < facts.workspace_peak.size(); ++i) {',
    '  facts.domain_count = facts.workspace_peak.size();\n  for (std::size_t i = 0; i < facts.workspace_peak.size(); ++i) {')
record = record.rstrip()
assert record.endswith('}')
record = record[:-1]+'  return facts;\n}\n\n'

free_helpers = '''V draft_scores(Recipe &recipe, V selected_hidden, DraftProjectionView projection) {
  if (!projection.original_ids) return recipe.scores(selected_hidden, std::string(recipe.geometry.head_role()));
  return recipe.emit_projection(selected_hidden, projection.projection, true);
}
V original_draft_id(Recipe &recipe, V compact_id, DraftProjectionView projection) {
  if (!projection.original_ids) return compact_id;
  return recipe.one(c::Gather{.axis = 0, .bounds = c::IndexBoundsPolicy::kChecked},
      {recipe.constant(*projection.original_ids), compact_id}, recipe.spec(compact_id));
}

'''

body = region(old_prepare, '    auto result = std::make_unique<Family>();', '    // Publish only a complete cold candidate.')
body = once(body, '    definition.sampling = &prepared_sampling;\n', '')
body = body.replace('planned_chunks', 'request.chunks')
body = once(body, '      if (tokens == 0 || tokens > capacity)\n        throw std::runtime_error("finite text chunk outside nonempty context capacity");\n', '')
body = once(body, '    if (requests > cache_plan.active_sequences || cache::multiply(requests, max_query_rows) > cache_plan.max_query_rows)\n      throw std::runtime_error("finite family exceeds the configured batch capacity");\n    prepare_cache();\n', '')
body = body.replace('cache_plan.hidden_slots', 'prepared.hidden_slots').replace('cache_plan.state_slots', 'prepared.state_slots')
body = body.replace('retains_sampling_frontier()', 'prepared.retain_hidden').replace('ffn_placement.cpu_layers()', 'model.cpu_ffn_layers')
body = once(body, '          const bool subset = prepare_draft_vocabulary(selected_sampler);\n', '')
body = once(body, 'draft_scores(recipe, selected, subset)', 'qwen35::draft_scores(recipe, selected, prepared.draft_projection)')
body = once(body, '})[1], subset);', '})[1], prepared.draft_projection);')
body = once(body, 'original_draft_id(r, r.op', 'qwen35::original_draft_id(r, r.op')
body = once(body, 'cache_plan.in_flight_batches >= 2 && !scheduler', 'prepared.emit_successor')
body = once(body, '      return false; // Cold capability only; no execution/device error is a fallback.',
                  '      return {}; // Cold capability only; no execution/device error is a fallback.')
body = once(body, '      record_execution_plan(child.compiled.report, assembly.constants());',
                  '      merge_execution_plan_facts(plan_facts, inspect_execution_plan(\n          execution, model.cpu_ffn_layers, child.compiled.report, assembly.constants()));')

source = '''// Complete Qwen-private cold Family assembly. No Model/Session or runtime
// admission/publication owner is included or retained by this implementation.
#include "family_factory.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <limits>
#include <optional>
#include <ranges>
#include <string>
#include <utility>

#include "mtp_graph.h"
#include "../../inference/backend.h"

namespace qwen35 {
using Clock = std::chrono::steady_clock;
namespace {
'''+packed+'''void merge_execution_plan_facts(ExecutionPlanFacts &result, const ExecutionPlanFacts &facts) {
  result.domain_count = (std::max)(result.domain_count, facts.domain_count);
  for (std::size_t i = 0; i < facts.domain_count; ++i) {
    result.workspace_peak[i] = (std::max)(result.workspace_peak[i], facts.workspace_peak[i]);
    result.workspace_limits[i] = facts.workspace_limits[i];
  }
}
} // namespace

'''+logits+free_helpers+record+'''FamilyBuildResult build_family(const FamilyBuildRequest &request,
    const FamilyModelFacts &model, const FamilyPreparedFacts &prepared,
    const SamplingConfiguration &configuration, const FamilyCompileContext &context) {
  if (request.chunks.empty()) throw std::runtime_error("text finite family requires known nonempty chunks");
  const auto &geometry = model.geometry;
  const auto precision = model.precision;
  auto &weights = model.weights;
  const auto &projections = model.projections;
  const auto &weight_meanings = model.weight_meanings;
  auto &execution = context.execution;
  const auto &allocation_budget = context.allocation_budget;
  const auto &execution_budget = context.execution_budget;
  const auto &attention_schema = prepared.attention_schema;
  const auto attention_schemas = prepared.attention_schemas;
  const auto state_schema = prepared.recurrent_descriptions;
  const auto requests = request.requests, prefix_rows = request.prefix_rows;
  const auto role = request.role;
  const auto completion = request.completion;
  const auto packing = request.packing;
  const auto diagnostic = request.diagnostic, admitted_exact = request.admitted_exact;
  const auto &selected_sampler = configuration;
  const bool packed_prefill = packs_prefill(packing), compact_draft = packs_draft(packing);
  const bool packed_verify = packs_verify(packing), packed_target = packs_target(packing);
  const auto target_kv_layers = geometry.attention_layers(), draft_bank = target_kv_layers * 2;
  const auto hidden = geometry.hidden, vocabulary = geometry.vocabulary;
  const auto ports_per_request = cache::add(76, cache::multiply(38, prefix_rows - 1));
  ExecutionPlanFacts plan_facts;
'''+body+'''  return {std::move(result), plan_facts};
}

} // namespace qwen35
'''

prefix = old_prepare[:old_prepare.index('    auto result = std::make_unique<Family>();')]
prefix = once(prefix, '    const bool packed_verify = packs_verify(packing), packed_target = packs_target(packing);',
              '    const bool packed_verify = packs_verify(packing);')
replacement = prefix+'''    // Validate admission before materializing the original cache/head tuple.
    // A later factory failure keeps that successfully prepared tuple alive.
    for (const auto tokens : planned_chunks)
      if (tokens == 0 || tokens > capacity)
        throw std::runtime_error("finite text chunk outside nonempty context capacity");
    const auto max_query_rows = *std::max_element(planned_chunks.begin(), planned_chunks.end());
    if (requests > cache_plan.active_sequences || cache::multiply(requests, max_query_rows) > cache_plan.max_query_rows)
      throw std::runtime_error("finite family exceeds the configured batch capacity");
    prepare_cache();
    const bool subset = drafts_token(role) && prepare_draft_vocabulary(selected_sampler);
    auto built = build_family(
        {planned_chunks, requests, prefix_rows, role, completion, packing, diagnostic, admitted_exact},
        {geometry, precision, weights, projections, weight_meanings, ffn_placement.cpu_layers()},
        {attention_schema, attention_schemas, state_schema, cache_plan.state_slots, cache_plan.hidden_slots,
         retains_sampling_frontier(), cache_plan.in_flight_batches >= 2 && !scheduler, prepared_draft_projection(subset)},
        selected_sampler, {execution, allocation_budget, execution_budget});
    if (!built.family) return false;
    built.family->sampling = &prepared_sampling;
    merge_execution_plan(built.plan);
    // Publish only the complete stable candidate after all children and checks.
    table.emplace(family_key, std::move(built.family));
    return true;
  }

'''
main = once(main, old_prepare, replacement)
main = once(main, old_record, '''  void merge_execution_plan(const ExecutionPlanFacts &facts) {
    for (std::size_t i = 0; i < facts.domain_count; ++i) {
      known_workspace_peak[i] = (std::max)(known_workspace_peak[i], facts.workspace_peak[i]);
      known_workspace_limits[i] = facts.workspace_limits[i];
    }
  }
  void record_execution_plan(const g::CompileReport &report, std::span<const g::ConstantBinding> constants) {
    merge_execution_plan(inspect_execution_plan(execution, ffn_placement.cpu_layers(), report, constants));
  }

''')
main = once(main, old_helpers, '''  DraftProjectionView prepared_draft_projection(bool subset) {
    if (!subset) return {};
    return {{&resources_->draft_head->weight.tensor}, &resources_->draft_head->original_ids};
  }
  V draft_scores(Recipe &recipe, V selected_hidden, bool subset) {
    return qwen35::draft_scores(recipe, selected_hidden, prepared_draft_projection(subset));
  }
  V original_draft_id(Recipe &recipe, V compact_id, bool subset) {
    return qwen35::original_draft_id(recipe, compact_id, prepared_draft_projection(subset));
  }
''')
transform = '''    auto selected = select_dense_weight_rows(execution, original, mapping.ids(), allocation_budget);
    Tensor ids(execution.device(), dense(Type::kInt32, {static_cast<std::int64_t>(mapping.size())}),
        true, allocation_budget);
    check(execution.write(ids.storage(), std::as_bytes(mapping.ids()))); ids.freeze(execution);
    auto identity = inference::artifact::sha256(std::as_bytes(mapping.ids()));
    resources_->draft_head.emplace(PreparedDraftHead{std::move(selected), std::move(ids), std::move(identity)});
'''
main = once(main, transform, '    resources_->draft_head.emplace(prepare_draft_head(execution, original, mapping, allocation_budget));\n')
for block in (packed, sampling_type, family_types, head_type, logits):
    main = once(main, block, '')
main = once(main, '#include "target_graph.h"\n', '#include "target_graph.h"\n#include "family_factory.h"\n')

weights_h = once(weights_h, 'using WeightMeanings = ', head_type+'// Transform only; policy/idle checks and optional publication belong to Model.\nPreparedDraftHead prepare_draft_head(hyle::inference::Backend &backend,\n    const LoadedWeight &original, const hyle::inference::DraftVocabulary &mapping,\n    const hyle::compute::ResourceBudget &budget = {});\n\nusing WeightMeanings = ')
new_transform = '''PreparedDraftHead prepare_draft_head(Backend &execution, const LoadedWeight &original,
    const hyle::inference::DraftVocabulary &mapping, const c::ResourceBudget &allocation_budget) {
  auto selected = select_dense_weight_rows(execution, original, mapping.ids(), allocation_budget);
  Tensor ids(execution.device(), dense(Type::kInt32, {static_cast<std::int64_t>(mapping.size())}),
      true, allocation_budget);
  check(execution.write(ids.storage(), std::as_bytes(mapping.ids()))); ids.freeze(execution);
  auto identity = hyle::inference::artifact::sha256(std::as_bytes(mapping.ids()));
  return {std::move(selected), std::move(ids), std::move(identity)};
}

'''
weights_cc = once(weights_cc, '} // namespace qwen35\n', new_transform+'} // namespace qwen35\n')
inventory = once(inventory, '  "${CMAKE_CURRENT_LIST_DIR}/target_graph.cc")', '  "${CMAKE_CURRENT_LIST_DIR}/target_graph.cc"\n  "${CMAKE_CURRENT_LIST_DIR}/family_factory.cc")')

for rel, text in ((MAIN, main), (WEIGHTS_H, weights_h), (WEIGHTS_CC, weights_cc), (INVENTORY, inventory), (HEADER, header), (SOURCE, source)):
    write(rel, text)

changed = [MAIN, WEIGHTS_H, WEIGHTS_CC, INVENTORY, HEADER, SOURCE]
patch = ''
for rel in changed:
    old = (W / 'base' / rel).read_bytes().decode() if (W / 'base' / rel).exists() else ''
    new = (W / 'candidate' / rel).read_bytes().decode()
    patch += 'diff --git a/'+rel+' b/'+rel+'\n'
    if not old: patch += 'new file mode 100644\n'
    patch += ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='a/'+rel if old else '/dev/null', tofile='b/'+rel))
(W / 'family-factory.patch').write_bytes(patch.encode())
check = subprocess.run(['git', 'apply', '--check', str(W / 'family-factory.patch')], cwd=R, capture_output=True, text=True)
assert check.returncode == 0, check.stderr

preconditions = []
for rel in changed:
    if (R / rel).exists(): preconditions.append(dict(relative=rel, **pin(R / rel)))
    else: preconditions.append(dict(relative=rel, absent=True))
plan = dict(status='SCRATCH_COMPLETE_FAMILY_FACTORY_CANDIDATE_UNAPPLIED_UNBUILT', base_head=BASE,
            preconditions=preconditions,
            candidate=[dict(relative=rel, **pin(W / 'candidate' / rel)) for rel in changed],
            patch=pin(W / 'family-factory.patch'), git_apply_check=dict(exit=check.returncode, stderr=check.stderr),
            product_edits=0, builds=0, native_runs=0, downloads=0,
            semantic_changes=['Cache and already optional head prepared before factory; shape/chunk preflight before those allocations.',
                              'Family resource diagnostics merge only after complete factory success, not from failed unpublished candidates.',
                              'Cold_seconds now measures factory assembly/compile, excluding caller cache/head preparation.'])
(W / 'plan.json').write_text(json.dumps(plan, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print(json.dumps(dict(status=plan['status'], files=len(changed), patch_bytes=plan['patch']['bytes'], patch_sha256=plan['patch']['sha256'])))
