"""Independent structural/token checks; not CXX or native validation."""
from pathlib import Path
import difflib
import hashlib
import json
import re

W = Path(__file__).resolve().parent
R = W.parents[1]
REL = 'engine/models/qwen35/'

def text(root, name):
    return (root / (REL + name)).read_text(encoding='utf-8-sig')

def part(s, start, end):
    a = s.index(start); return s[a:s.index(end, a)]

def replace(s, a, b):
    assert s.count(a) == 1, (s.count(a), a[:100])
    return s.replace(a, b, 1)

def tokens(s):
    pattern = r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/|[A-Za-z_]\w*|\d+(?:\.\d*)?|\S'
    return [m.group() for m in re.finditer(pattern, s) if not m.group().startswith(('//', '/*'))]

def pin(p):
    p = Path(p); raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

old, new = text(W / 'base', 'main.cc'), text(W / 'candidate', 'main.cc')
header, cold = text(W / 'candidate', 'family_factory.h'), text(W / 'candidate', 'family_factory.cc')
old_body = part(old, '    auto result = std::make_unique<Family>();', '    // Publish only a complete cold candidate.')
new_body = part(cold, '    auto result = std::make_unique<Family>();', '  return {std::move(result), plan_facts};')

# Reverse explicit fact projection and the documented caller-preparation moves.
restored = new_body.replace('request.chunks', 'planned_chunks')
restored = replace(restored, '    definition.requests = requests;', '    definition.sampling = &prepared_sampling;\n    definition.requests = requests;')
restored = replace(restored, '    for (const auto tokens : planned_chunks) {\n',
    '    for (const auto tokens : planned_chunks) {\n      if (tokens == 0 || tokens > capacity)\n        throw std::runtime_error("finite text chunk outside nonempty context capacity");\n')
restored = restored.replace('prepared.hidden_slots', 'cache_plan.hidden_slots').replace('prepared.state_slots', 'cache_plan.state_slots')
restored = restored.replace('prepared.retain_hidden', 'retains_sampling_frontier()').replace('model.cpu_ffn_layers', 'ffn_placement.cpu_layers()')
restored = replace(restored, '    definition.attention_schema = attention_schema;',
    '    if (requests > cache_plan.active_sequences || cache::multiply(requests, max_query_rows) > cache_plan.max_query_rows)\n      throw std::runtime_error("finite family exceeds the configured batch capacity");\n    prepare_cache();\n    definition.attention_schema = attention_schema;')
restored = replace(restored, '          const auto head = mtp::full_head(', '          const bool subset = prepare_draft_vocabulary(selected_sampler);\n          const auto head = mtp::full_head(')
restored = restored.replace('qwen35::draft_scores(recipe, selected, prepared.draft_projection)', 'draft_scores(recipe, selected, subset)')
restored = restored.replace('qwen35::original_draft_id(r, r.op', 'original_draft_id(r, r.op')
restored = replace(restored, '})[1], prepared.draft_projection);', '})[1], subset);')
restored = replace(restored, 'prepared.emit_successor', 'cache_plan.in_flight_batches >= 2 && !scheduler')
restored = replace(restored, '      return {}; // Cold capability only; no execution/device error is a fallback.', '      return false; // Cold capability only; no execution/device error is a fallback.')
restored = replace(restored, '      merge_execution_plan_facts(plan_facts, inspect_execution_plan(\n          execution, ffn_placement.cpu_layers(), child.compiled.report, assembly.constants()));',
    '      record_execution_plan(child.compiled.report, assembly.constants());')
assert tokens(restored) == tokens(old_body), 'Projected full construction/compile/program body differs'

unchanged = []
for start, end, dest in (
    ('struct SamplingConfiguration final {', '// Typed ready inputs', header),
    ('struct FamilyPorts {', 'struct FamilyChild final {', header),
    ('// Extra cold draft projection only.', '// Actual cold storage', text(W / 'candidate', 'weights.h')),
    ('sampling::LogitsInputsFor<V> prepare_logits_inputs(', 'GenerationBoundary generation_boundary(', cold),
    ('// Distinguish direct packed contractions', 'struct SamplingConfiguration final {', cold)):
    block = part(old, start, end)
    assert block in dest, start
    unchanged.append(start)

# Resource checking and its validation order remain a single original algorithm.
old_record = part(old, '  void record_execution_plan(', '  void prepare_cache()')
new_record = part(cold, 'ExecutionPlanFacts inspect_execution_plan(', 'FamilyBuildResult build_family(')
projected = new_record[new_record.index('{')+1:]
projected = replace(projected, '\n  ExecutionPlanFacts facts;', '')
projected = replace(projected, '    facts.domain_count = 1;\n', '')
projected = replace(projected, '  facts.domain_count = facts.workspace_peak.size();\n', '')
projected = replace(projected, '  return facts;\n}\n\n', '}\n\n')
projected = projected.replace('return facts;', 'return;').replace('cpu_ffn_layers', 'ffn_placement.cpu_layers()')
projected = projected.replace('facts.workspace_peak', 'known_workspace_peak').replace('facts.workspace_limits', 'known_workspace_limits')
assert tokens(projected) == tokens(old_record[old_record.index('{')+1:])

# All old main text outside the stated extraction/admission islands is untouched.
islands = [
    ('#include "target_graph.h"', '#include "hyle/compute/batch_transfer.h"'),
    ('// Distinguish direct packed contractions', '// Typed ready inputs'),
    ('sampling::LogitsInputsFor<V> prepare_logits_inputs(', 'GenerationBoundary generation_boundary('),
    ('struct FamilyPorts {', 'struct FamilyChild final {'),
    ('// Extra cold draft projection only.', '// Actual cold storage'),
    ('    auto selected = select_dense_weight_rows(execution, original, mapping.ids(), allocation_budget);', '    return true;\n  }\n\n  V draft_scores('),
    ('  V draft_scores(', '  const FfnPlacement ffn_placement;'),
    ('  void record_execution_plan(', '  void prepare_cache()'),
    ('  bool prepare_family(', '  // These capacities are physical carriers.'),
]
roundtrip = replace(new, '#include "family_factory.h"\n', '')
roundtrip = replace(roundtrip, '// Typed ready inputs',
    part(old, '// Distinguish direct packed contractions', '// Typed ready inputs')+'// Typed ready inputs')
roundtrip = replace(roundtrip, 'GenerationBoundary generation_boundary(',
    part(old, 'sampling::LogitsInputsFor<V> prepare_logits_inputs(', 'GenerationBoundary generation_boundary(')+'GenerationBoundary generation_boundary(')
roundtrip = replace(roundtrip, 'struct FamilyChild final {',
    part(old, 'struct FamilyPorts {', 'struct FamilyChild final {')+'struct FamilyChild final {')
roundtrip = replace(roundtrip, '// Actual cold storage',
    part(old, '// Extra cold draft projection only.', '// Actual cold storage')+'// Actual cold storage')
roundtrip = replace(roundtrip, '    resources_->draft_head.emplace(prepare_draft_head(execution, original, mapping, allocation_budget));\n',
    part(old, '    auto selected = select_dense_weight_rows(execution, original, mapping.ids(), allocation_budget);', '    return true;\n  }\n\n  V draft_scores('))
roundtrip = replace(roundtrip, part(roundtrip, '  DraftProjectionView prepared_draft_projection(', '  const FfnPlacement ffn_placement;'),
    part(old, '  V draft_scores(', '  const FfnPlacement ffn_placement;'))
roundtrip = replace(roundtrip, part(roundtrip, '  void merge_execution_plan(', '  void prepare_cache()'), old_record)
roundtrip = replace(roundtrip, part(roundtrip, '  bool prepare_family(', '  // These capacities are physical carriers.'),
    part(old, '  bool prepare_family(', '  // These capacities are physical carriers.'))
assert roundtrip == old, 'Complete main inverse did not restore all original bytes'

# Original budgets/shape policy/child resources and no extra owner/callback API.
for expr in ('compile_options.resource_budget = execution_budget;',
             'g::CompileShapePolicy::kFiniteExact',
             'take(execution_budget.metadata_allocator())',
             '{definition.state_sources, extra_stores}',
             'definition.literals = std::move(assembly.literals);',
             'definition.specs = std::move(r.specs);',
             'std::make_unique<Family>()'):
    assert expr in cold
assert 'std::function' not in header+cold and 'virtual ' not in header+cold
assert 'const PreparedSampling *sampling = nullptr;' in header
assert 'built.family->sampling = &prepared_sampling;' in new
assert new.index('prepare_cache();', new.index('  bool prepare_family(')) < new.index('auto built = build_family(')
assert cold.index('auto result = std::make_unique<Family>()') < cold.index('Recipe r(') < cold.index('definition.programs.prepare(')
assert 'resources_' not in cold and 'cache_plan.' not in cold and '!scheduler' not in cold
assert cold.index('inspect_execution_plan(\n          execution') < cold.index('report_packed_projections(definition.graph')
assert 'if (!cpu_ffn_layers) return facts;' in cold

def closure(relative):
    found, missing = {}, []
    def visit(rel):
        rel = Path(rel).as_posix()
        if rel in found: return
        p = W / 'candidate' / rel
        if not p.is_file(): p = R / rel
        if not p.is_file(): missing.append(rel); return
        found[rel] = pin(p)
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"', p.read_text(encoding='utf-8-sig'), re.M):
            if include.startswith('hyle/'):
                target = R / 'include' / include
            else:
                target = R / Path(rel).parent / include
            try: child = target.resolve().relative_to(R).as_posix()
            except ValueError: continue
            visit(child)
    visit(relative)
    return found, sorted(set(missing))

closures = {}
for name in ('family_factory.h', 'family_factory.cc', 'weights.cc'):
    files, missing = closure(REL+name)
    forbidden = [p for p in files if p.endswith(('/session_state.h', '/paged_sequence.h')) or p == REL+'main.cc']
    assert not forbidden, forbidden
    closures[name] = dict(files=len(files), forbidden_qwen_runtime_headers=forbidden, missing=missing, pins=list(files.values()))

plan = json.loads((W / 'plan.json').read_text())
assert all(pin(R / item['relative']) == {k: v for k, v in item.items() if k != 'relative'} for item in plan['preconditions'] if not item.get('absent'))
report = dict(status='PASS_STATIC_STRUCTURE_AND_PROJECTED_OPERATION_TOKENS_NOT_CXX',
              base_head=plan['base_head'], candidate=plan['candidate'],
              projected_full_build_tokens=len(tokens(old_body)),
              original_build_body_restored_token_exact=True,
              moved_type_and_helper_blocks_exact=unchanged,
              resource_validation_algorithm_projected_token_exact=True,
              other_main_text_unchanged_outside_explicit_islands=True,
              Family_field_order_and_defaults_exact=True,
              original_child_shape_binding_and_budget_algorithm_exact=True,
              stable_unique_family_and_original_sampling_pointer=True,
              header_runtime_dependency_scope='No Qwen session_state/paged_sequence/main; Backend implementation may legitimately include original generic runtime resource/readback types.',
              closures=closures,
              limits=['No CXX/link/native or failure-budget high-water validation.',
                      'Local host preparation/diagnostic failure order changes as explicitly documented in design/plan.',
                      'Not a universal model-family interface or completed architecture claim.'])
(W / 'static-report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print(json.dumps(dict(status=report['status'], projected_tokens=report['projected_full_build_tokens'],
                      closure_counts={k: v['files'] for k, v in closures.items()},
                      patch_sha256=plan['patch']['sha256'])))
