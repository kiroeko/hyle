from pathlib import Path
import hashlib,json,subprocess

W=Path(__file__).resolve().parent
R=W.parents[1]
P=json.loads((W/'plan.json').read_text(encoding='utf-8'))
B=R/'.scratch/inference-family-factory-harness-20261030/baseline-plan.json'
assert B.is_file(), 'Baseline source/object snapshot must exist before product changes'
baseline=json.loads(B.read_text(encoding='utf-8'))
def exact(item):
    path=Path(item.get('path',R/item.get('relative','')))
    if item.get('absent'):
        assert not path.exists(), str(path)
        return
    data=path.read_bytes()
    assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'], str(path)
for item in P['preconditions']: exact(item)
inputs=json.loads((W/'source-input-pins.json').read_text(encoding='utf-8'))
for item in inputs['preconditions']: exact(item)
for item in P['candidate']: exact(item)
for pair in baseline['snapshots']:
    exact(pair['original']);exact(pair['snapshot'])
assert not subprocess.check_output(['git','diff','--name-only','--','include','src','engine','tests'],cwd=R,text=True).strip()
subprocess.run(['git','apply','--check',str(W/'family-factory.patch')],cwd=R,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
for item in P['candidate']:
    target=R/item['relative']
    target.write_bytes(Path(item['path']).read_bytes())
for item in P['candidate']:
    exact({**item,'path':str(R/item['relative'])})
subprocess.run(['git','diff','--check'],cwd=R,check=True)
report=dict(status='REVIEWED_SIX_SOURCE_FILES_APPLIED_BYTES_EXACT_UNBUILT',observed_HEAD=head,
    candidate_base=P['base_head'],input_pins=len(inputs['preconditions']),baseline_snapshot=str(B),
    applied=[{**item,'path':str(R/item['relative'])} for item in P['candidate']],
    CXX=0,native=0,downloads=0)
(W/'applied-receipt.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='applied'}))
