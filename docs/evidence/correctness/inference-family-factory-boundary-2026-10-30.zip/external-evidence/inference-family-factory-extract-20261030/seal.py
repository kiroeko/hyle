"""Seal static-review inputs; no product apply or build."""
from pathlib import Path
import hashlib
import json
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[1]
REVIEW = R / '.scratch/inference-family-factory-review-20261030'

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p = Path(p); b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

plan, static, independent = map(read, (W/'plan.json', W/'static-report.json', REVIEW/'independent-candidate-review.json'))
assert plan['base_head'] == subprocess.check_output(['git','rev-parse','HEAD'], cwd=R, text=True).strip()
assert independent['patch'] == plan['patch'] == pin(W/'family-factory.patch')
for item in plan['candidate']:
    assert pin(item['path']) == {k:v for k,v in item.items() if k!='relative'}
inputs = {}
for closure in static['closures'].values():
    for entry in closure['pins']:
        p = Path(entry['path'])
        try: rel = p.relative_to(W/'candidate')
        except ValueError: rel = p.relative_to(R)
        actual = R / rel
        if actual.is_file(): inputs[rel.as_posix()] = dict(relative=rel.as_posix(), **pin(actual))
        else: inputs[rel.as_posix()] = dict(relative=rel.as_posix(), absent=True)
for rel in ('engine/models/qwen35/main.cc', 'engine/models/qwen35/cold_sources.cmake',
            'engine/models/qwen35/CMakeLists.txt', 'engine/CMakeLists.txt', 'tests/CMakeLists.txt'):
    inputs[rel] = dict(relative=rel, **pin(R/rel))
data = dict(status='FROZEN_LOCAL_SOURCE_INPUTS_NO_COMPILER_DEPENDENCY_CLAIM', base_head=plan['base_head'],
            scope='Current product bytes for candidate quoted-include closure and existing CMake consumers; missing candidate new files must remain absent before apply.',
            preconditions=[inputs[key] for key in sorted(inputs)])
(W/'source-input-pins.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
plan.update(status='FROZEN_COMPLETE_FAMILY_FACTORY_CANDIDATE_STATIC_REVIEWED_UNAPPLIED_UNBUILT',
            static_report=pin(W/'static-report.json'), source_input_pins=pin(W/'source-input-pins.json'),
            independent_review=pin(REVIEW/'independent-candidate-review.json'),
            independent_notes=pin(REVIEW/'candidate-notes.md'),
            original_main_lines=len((W/'base/engine/models/qwen35/main.cc').read_text().splitlines()),
            candidate_main_lines=len((W/'candidate/engine/models/qwen35/main.cc').read_text().splitlines()),
            dependency_limits='Quoted include source closure only; actual compiler deps and every backend consumer linkage require the authorized harness.')
(W/'plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=plan['status'], inputs=len(inputs), candidate_files=len(plan['candidate']),
                      patch_bytes=plan['patch']['bytes'], patch_sha256=plan['patch']['sha256'])))
