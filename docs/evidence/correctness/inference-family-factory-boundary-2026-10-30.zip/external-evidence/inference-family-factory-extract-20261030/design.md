# 完整 Qwen Family 冷工厂候选设计

基线 `5cda94069f241c45b6c6f6995d5d4564f8f2e7b2`。只生成 scratch 候选，不改产品、不构建、不运行、不下载。

`family_factory.h/.cc` 一次创建稳定 `unique_ptr<Family>`，完成原整段 Graph 构造、finite-exact compile、`PreparedProgramFamily::prepare`、每个 child 的资源/packed 检查。返回 `FamilyBuildResult { unique_ptr<Family> family; ExecutionPlanFacts plan; }`；仅原 packed/compact 纯 capability 拒绝返回空 family。原 Graph、literals、programs 字段次序不变，unique_ptr 的移动不移动 Graph。

输入按职责分成具体冷事实：

- `FamilyBuildRequest`：同步借用 chunks，以及 requests/role/completion/packing/prefix_rows/diagnostic/admitted_exact。Model 在资源准备前保留原 shape/admission/key/table 检查，预验非空且有效 chunks、batch 上界。
- `FamilyModelFacts`：同一 geometry、precision、weight map、projection bindings、weight meanings、CPU FFN 层数。没有 Model/Session/ColdResources。
- `FamilyPreparedFacts`：原 plain attention schema、target schema span、recurrent descriptor span、state/hidden slot 数、retain_hidden/emit_successor 两个冷输出事实，以及可空 `DraftProjectionView { StoredProjection projection; Tensor* original_ids; }`。两个指针只在同步工厂期间借用原 ColdResources 中的稳定 tensor，Graph 仍通过原 binding/lease 保持权限。默认 fullV view 为空。
- `FamilyCompileContext`：原 Backend 和 allocation/execution budgets。无新 executor、owner、回调表、开关或许可账本。

`SamplingConfiguration`、`FamilyPorts`、`Family` 原样迁到私有 header；仅前置声明 `PreparedSampling`，工厂不解引用它。成功后 Model 把原稳定 `PreparedSampling*` 接回 Family，再合并小诊断 facts 并一次 emplace。FamilyKey、PreparedSampling/frontier、ColdResources/maps、Phase/recovery 保留原处。

原 `record_execution_plan` 分为同步 `inspect_execution_plan(Backend&, cpu_ffn_layers, report, constants)` 和 Model 的峰值合并。原资源验证/日志只有一份实现，其余 draft/frontier 消费者继续调用它；工厂内部检查每个 child 后只返回三个 domain 的峰值与 limit，不返回 assembly 常量 span。packed-projection 检查仅 Family 使用，原实现完整迁到 .cc。`prepare_logits_inputs` 也是原单一冷数学 helper，迁 .cc 并声明，原其余冷消费者继续直调。

`PreparedDraftHead` 原布局迁 weights.h；原 select-dense-rows/upload/freeze/hash 变为 weights.cc 的 free `prepare_draft_head`。策略、原 stored head 验证、idle 检查、已有 optional 快路及完整成功后 optional.emplace 留 Model。正常显式 map 构造已准备，此处只取原 view；不让该分支影响默认 fullV 工厂设计。

失败语义：已成功准备的原 cache tuple/head optional 仍由原 ColdResources 持有；工厂失败只销毁未发布的局部 Family/Graph/literals/compiled candidate，不清原 tuple，不插 map，不换 budget/native retirement。原 chunk/batch 拒绝移到 cache 准备之前；cache/head 准备移到整个工厂之前，因而局部 host Graph emit 与这些准备的偶然先后会改变。该变化不发布 Session/RNG/状态；实际预算 high-water/失败 retry 仍需后续有限实测，不能仅凭冷期宣称不变。工厂失败后的局部 diagnostic peak 不合并到 Model，是明确的诊断行为变化；资源有效性检查与真实错误分类保留。

只扩展唯一 `cold_sources.cmake` 为 weights/graph_builder/target_graph/family_factory 四源；现 consumer 能力宏与 CMake gates 不变。本片不迁 Phase、不改恢复/调度、运行时发射或性能选路。
