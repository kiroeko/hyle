"""Read-only product verification and final seven-source scratch patch."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

W=Path(__file__).resolve().parent
R=W.parents[1]
REL='engine/models/qwen35/family_factory.cc'
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,d): Path(p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def preserve(p,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists(): assert dst.read_bytes()==p.read_bytes()
    else: dst.write_bytes(p.read_bytes())

old=(W/'candidate'/REL).read_bytes();new=(R/REL).read_bytes()
assert hashlib.sha256(old).hexdigest()=='46abd408520af7718667332af566cfa16a127e6f805a26dbc71665db4c16f006'
assert hashlib.sha256(new).hexdigest()=='4591a29c7035a0bd095474bcd9aa017738abc5b1ec446785d3b7f8ffea4260b5'
assert new.replace(b'build_request',b'request')==old
assert new.count(b'build_request')==10 and new.count(b'build_request.')==9
assert len([line for line in new.splitlines() if b'build_request' in line])==8
assert new.count(b'\n')==new.count(b'\r\n')
old_plan=json.loads((W/'plan.json').read_text())
for item in old_plan['candidate']:
    if item['relative']!=REL:
        assert pin(R/item['relative'])['sha256']==item['sha256']

history=W/'superseded-first-compile'
for name in ('pending-seven-source.patch','pending-seven-source.json'):
    if (W/name).exists():preserve(W/name,history/name)
preserve(W/'candidate'/REL,history/REL)

files=[e['relative'] for e in old_plan['candidate']]+['tests/tools/qwen_cold_family_case.h']
test_pin='1aa6ec5dad90b85dfff9bdf66c0235da80593bd1c0383ae4732de366f76b4034'
assert pin(R/files[-1])['sha256']==test_pin
patch=b'';final_sources=[]
observed_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
for rel in files:
    actual=R/rel;dst=W/'final'/'source'/rel
    preserve(actual,dst)
    before=subprocess.run(['git','show',observed_head+':'+rel],cwd=R,capture_output=True)
    original=before.stdout if before.returncode==0 else b''
    base=W/'final'/'base'/rel
    if before.returncode==0:
        base.parent.mkdir(parents=True,exist_ok=True)
        if base.exists():assert base.read_bytes()==original
        else:base.write_bytes(original)
    patch+=('diff --git a/'+rel+' b/'+rel+'\n').encode()
    if not original:patch+=b'new file mode 100644\n'
    patch+=''.join(difflib.unified_diff(original.decode().splitlines(True),actual.read_bytes().decode().splitlines(True),
        fromfile='a/'+rel if original else '/dev/null',tofile='b/'+rel)).encode()
    final_sources.append(dict(relative=rel,**pin(actual),snapshot=pin(dst),base=pin(base) if original else dict(absent=True)))
patch_path=W/'pending-seven-source-final.patch';patch_path.write_bytes(patch)
assert patch.count(b'diff --git ')==7
check=subprocess.run(['git','apply','--reverse','--check',str(patch_path)],cwd=R,capture_output=True,text=True)
assert check.returncode==0,check.stderr
forward=subprocess.run(['git','apply','--check','--directory='+(W/'final'/'base').relative_to(R).as_posix(),str(patch_path)],cwd=R,capture_output=True,text=True)
assert forward.returncode==0,forward.stderr

review=dict(status='PASS_NAME_ONLY_CORRECTION_STATIC_REVIEW_NO_NEW_CXX_CLAIM',
    original_source=pin(W/'candidate'/REL),final_source=pin(R/REL),
    inverse_rename_original_bytes_exact=True,changed_physical_lines=8,
    outer_parameter_occurrences=1,member_access_occurrences=9,
    original_member_loops_and_lambdas_byte_exact=True,header_and_other_five_factory_sources_unchanged=True,
    reason='MSVC /WX C4457: added outer parameter request shadowed three original member-loop locals. Only the new outer name and its field uses are renamed.',
    old_static_report=pin(W/'static-report.json'),
    old_independent_review=pin(R/'.scratch/inference-family-factory-review-20261030/independent-candidate-review.json'),
    static_equivalence_applicability='Inverse identifier rename restores the entire formerly reviewed cc bytes; original math/port/layout/lease checks apply after that exact projection. Historical reports keep old pins/status.',
    first_compile_status='FAILED_C4457_RECORDED_NOT_PASS',
    product_edits_by_reviewer=0,builds_by_reviewer=0,native_runs_by_reviewer=0)
save(W/'final'/'name-fix-review.json',review)
metadata=dict(status='FROZEN_FINAL_SEVEN_SOURCE_PENDING_PATCH_STATIC_REVIEWED',
    candidate_source_base=old_plan['base_head'],observed_product_HEAD=observed_head,
    HEAD_scope='Current HEAD contains documentation-only changes relative to source base; source delta is the exact current seven-path pending diff.',
    final_sources=final_sources,patch=pin(patch_path),
    reverse_check=dict(exit=check.returncode,stderr=check.stderr),forward_base_mirror_check=dict(exit=forward.returncode,stderr=forward.stderr),
    name_fix_review=pin(W/'final'/'name-fix-review.json'),
    cold_test_independent_review=pin(R/'.scratch/inference-family-factory-review-20261030/cold-test-v2/independent-review.json'),
    historical_patch=pin(W/'family-factory.patch'),historical_plan=pin(W/'plan.json'),
    limits=['Do not relabel first failed factory CXX as PASS. Further build/native state belongs to harness.',
            'Original candidate/source report pins remain historical; final cc SHA is4591a29c.',
            'No change to algorithms, budgets, ABI/type layout, registration order or owners from the name correction.'])
save(W/'pending-seven-source-final.json',metadata)
print(json.dumps(dict(status=metadata['status'],patch_bytes=metadata['patch']['bytes'],patch_sha256=metadata['patch']['sha256'],
    source_files=7,cc_sha256=review['final_source']['sha256'],reverse_check=check.returncode,forward_check=forward.returncode)))
