from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;R=W.parents[2]
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
final=json.loads((W.parent/'pending-seven-source-final.json').read_text())
assert all(pin(e['path'])['sha256']==e['sha256'] for e in final['final_sources'])
d=dict(status='TECHNICAL_BASIS_APPLIES_AFTER_EXACT_NAME_ONLY_FIX',
 observed_product_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 source_base=final['candidate_source_base'],historical_basis=pin(W/'sources.json'),
 exact_inverse_fix_review=pin(W.parent/'final/name-fix-review.json'),
 final_source_set=pin(W.parent/'pending-seven-source-final.json'),
 scope='Outer parameter spelling only; same cold calls, hot suffix, graph/math/ports/owner conclusions. First CXX failure retained. No new runtime/performance claim.',
 product_edits=0,candidate_edits=0,builds=0,native_runs=0)
(W/'post-name-fix.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':d['status'],'final_source_files':len(final['final_sources'])}))
