from pathlib import Path
import hashlib
import json
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[2]
PEER = R.parent / 'llama.cpp'
TRT = R.parent / 'TensorRT-LLM'
C = W.parent / 'candidate'
B = W.parent / 'base'

def head(root):
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()

def entry(root, rel, scopes):
    p = root / rel; raw = p.read_bytes(); lines = raw.decode('utf-8-sig').splitlines()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                scopes=[dict(first=a,last=b,excerpt='\n'.join(lines[a-1:b])) for a,b in scopes])

old = (B/'engine/models/qwen35/main.cc').read_bytes()
new = (C/'engine/models/qwen35/main.cc').read_bytes()
marker = b'  Phase &prepare_child('
assert old[old.index(marker):] == new[new.index(marker):]
old_text, new_text = old.decode(), new.decode()
find_start = '  std::optional<FamilyChild> find_child('
find_end = '  std::size_t prefill_capacity('
def part(s,a,b): return s[s.index(a):s.index(b,s.index(a))]
assert part(old_text,find_start,find_end) == part(new_text,find_start,find_end)
factory = (C/'engine/models/qwen35/family_factory.cc').read_text()
header = (C/'engine/models/qwen35/family_factory.h').read_text()
assert 'std::function' not in header+factory and 'virtual ' not in header+factory
assert new_text.count('auto built = build_family(') == 1
assert new_text.index('auto built = build_family(') < new_text.index('  bool prepare_prefill_family(')

sources = [
    entry(PEER,'src/models/qwen35.cpp',[(33,40),(130,174),(183,198)]),
    entry(PEER,'src/llama-model.h',[(794,810)]),
    entry(PEER,'src/llama-model.cpp',[(2965,2984)]),
    entry(PEER,'src/llama-context.cpp',[(1414,1465),(1467,1475),(2626,2635)]),
    entry(PEER,'src/llama-graph.h',[(785,803),(1084,1103),(1129,1144)]),
    entry(C,'engine/models/qwen35/main.cc',[(898,930),(1355,1365),(1489,1497),(1545,1569),(1582,1599),(1643,1683),(1686,1695),(2033,2043),(2314,2327),(2599,2617)]),
    entry(C,'engine/models/qwen35/family_factory.h',[(28,60),(61,116)]),
    entry(C,'engine/models/qwen35/family_factory.cc',[(141,185),(494,548)]),
    entry(R,'engine/inference/prepared_program_family.h',[(24,38),(53,82),(87,109)]),
    entry(TRT,'tensorrt_llm/_torch/pyexecutor/model_engine.py',[(80,101),(591,609)]),
    entry(TRT,'tensorrt_llm/_torch/pyexecutor/engine/model_call.py',[(26,51),(53,88)]),
    entry(TRT,'tensorrt_llm/_torch/pyexecutor/engine/runners/decoder/runner.py',[(123,149),(176,203),(323,349)]),
]
dirty = subprocess.check_output(['git','status','--short','--', *[str(Path(x['path']).relative_to(PEER)).replace('\\','/') for x in sources[:5]]],cwd=PEER,text=True)
assert not dirty.strip()
previous = json.loads((R/'.scratch/inference-cold-model-boundary-20261030/external-evidence/inference-graph-builder-review-20261030/reference-boundaries.json').read_text())['TensorRT-LLM']
assert previous['actual_local_HEAD'] == head(TRT)
assert all(a['sha256'] == b['sha256'] for a,b in zip(sources[-3:],previous['files']))
trt_dirty = subprocess.check_output(['git','status','--short','--', *[str(Path(x['path']).relative_to(TRT)).replace('\\','/') for x in sources[-3:]]],cwd=TRT,text=True)
for source in sources[-3:]:
    rel = Path(source['path']).relative_to(TRT).as_posix()
    blob = subprocess.check_output(['git','show','HEAD:'+rel],cwd=TRT)
    assert Path(source['path']).read_bytes() == blob
    source['exact_HEAD_bytes'] = True
candidate_plan = json.loads((W.parent/'plan.json').read_text())
product_exact = {e['relative']:hashlib.sha256((R/e['relative']).read_bytes()).hexdigest()==e['sha256'] for e in candidate_plan['candidate']}
assert all(product_exact.values())
report = dict(status='READ_ONLY_TECHNICAL_BASIS_AND_CALL_PATH_SOURCE_REVIEW',
              hyle_head=head(R), llama_head=head(PEER), referenced_peer_worktree_clean=True,
              trt_head=head(TRT), reused_three_TRT_reference_pins_exact=True,
              candidate_source_base=candidate_plan['base_head'],
              TRT_original_reference_artifact=str(R/'.scratch/inference-cold-model-boundary-20261030/external-evidence/inference-graph-builder-review-20261030/reference-boundaries.json'),
              TRT_index_worktree_status=trt_dirty,
              TRT_status_note='Local sparse/index bookkeeping lists staged deletions and untracked restored files; all three actual file bytes directly equal HEAD blobs and the earlier reference pins. No clean-checkout claim.',
              product_applied_by_root_equals_frozen_six_candidates=product_exact,
              peer_version_scope='Actual local checkout only; no online latest-version assertion.',
              candidate_patch=json.loads((W.parent/'plan.json').read_text())['patch'],
              hot_source_checks=dict(prepare_child_through_complete_main_EOF_byte_exact=True,
                  unchanged_suffix_bytes=len(old[old.index(marker):]),find_child_source_byte_exact=True,
                  new_build_family_call_sites=1, new_factory_function_pointer_or_virtual_dispatch=False,
                  new_return_facts_heap_allocation=False,
                  admission_is_not_all_startup_only='Existing idle exact-shape admission may invoke cold compile during a request; that pre-existing path remains.'),
              sources=sources, product_edits=0, candidate_edits=0, builds=0,native_runs=0,downloads=0,
              limits=['Source path preservation is not a machine-code/performance measurement.',
                      'llama graph parameters include runtime context and virtual model entry; those are not adopted by Hyle.',
                      'No claim that all engines or model families share a single layer/cache schema.'])
(W/'sources.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'],source_files=len(sources),llama_head=report['llama_head'],
                      unchanged_hot_suffix_bytes=report['hot_source_checks']['unchanged_suffix_bytes'])))
