# 技术依据与热路径核对

本地 llama.cpp 实际 HEAD `23b0202a189c44a54625aadcb37a946dd1d6278d`；引用的5个源文件工作树未改。Hyle candidate/source base 为 `5cda94069`，观测产品 HEAD 为 `9496cab`（文档提交，完整实际SHA由git rev-parse存入sources.json）；sources.json观测时root应用的6个产品文件与当时冻结候选SHA一致。本审查不改产品或候选，不构建、不运行、不下载。文件 bytes/SHA 与短行片段见 `sources.json`。

随后 root 因首次 CXX 的 `/WX C4457`，仅将 factory.cc 外层 `request` 参数及其字段访问改名 `build_request`；最新cc为 `4591a29c`，其余5源未改。`../final/name-fix-review.json` 已独立逆rename恢复原cc全bytes，`post-name-fix.json` 将本报告的冷调用/热字节结论明确接到最终7源码集合。首次编译失败仍保留，不用源等价将它改写成通过。

| 具体成熟机制 | 本片对应和边界 |
| --- | --- |
| `src/models/qwen35.cpp:33–40` 独立加载模型权重；`:130–135` 直接选择 Qwen 的普通 graph 或 graph_mtp。`llama-model.h:794–808` 分开 memory creation、graph building 和每架构实现。 | Qwen 私有工厂只借已加载 weights/projections 和准备完成的 schema；仍构造 Qwen 专用 ordinary/MTP 完整图，没有把所有模型套成一份通用层实现。此处借鉴职责分离，不借其 virtual 模型接口。 |
| `qwen35.cpp:167–174` 在专用模型数学中保留 GDN 与全 attention 差异，`:183–198` 保留原 residual/FFN 顺序；`llama-graph.h:1084–1103,1129–1144` 提供共用 projection/norm/FFN helper。 | 共用基础设施与模型专用图可以并存。Hyle 仍走原 target_graph/block_graph/MTP 数学与原 provider route，保留 dtype/shape/权重含义和端口序列；不是为了架构统一增加 cast、copy 或强制统一 KV/层形状。源码投影等价检查支持本片的结构判断，尚不替代实际选路/性能证据。 |
| `llama-context.cpp:1414–1465` 单独判断 graph reuse、重建及 allocation，`:1472` 设置实际输入，`:2631` 调用 scheduler compute。`llama-model.cpp:2965–2984` 先具体架构构图，再装配 pooling/sampling/outputs。 | 构图职责独立于输入/提交职责有实际依据。Hyle 用自己原有有限 `PreparedProgramFamily` 和具体 child，不能据 llama 运行时重建流程宣称所有构图都只在启动期，也不把其含 ubatch/mctx/scheduler 的 gparams 整包照搬成 Hyle factory 输入。 |
| 本地 TensorRT-LLM HEAD `46d9966b54d9d11998b712e732fb20f64d4d35c0`：`model_engine.py:96–101` 明确在 runtime resources 初始化后 warmup，`:591–609` 创建 ModelCaller 与特定 runner；`engine/runners/decoder/runner.py:176–203` 在 runner 初始化时建立 buffers、metadata、input preparer、graphs/warmup，`:323–349` 分开 forward 和 warmup。 | 复用此前3份实际源pins，本次核当前HEAD/SHA仍全同。这只支持准备事实/缓冲与实际调用分责；TRT runner自己保留runtime状态，不能搬成Hyle第二owner。`engine/model_call.py:53–88` 每次forward会设置attrs/context并调用model.forward，明确是运行时机制；它不是本片“零新增热分派”的证明，也不是全部纯cold设计。Hyle的cold性质和热链结论必须由下面自己的调用点/字节对照证明。 |

TRT三份原证据来自 `.scratch/inference-cold-model-boundary-20261030/external-evidence/inference-graph-builder-review-20261030/reference-boundaries.json`，路径、旧SHA与本次HEAD blob逐字节核对均保存在sources.json。该checkout的index/worktree有“staged删除＋同路径untracked恢复文件”记录，不称整个checkout clean；这3个实际文件仍逐字节等于HEAD blob。没有改动该参考checkout。

本片新增调用只有冷准备链：Model `prepare_family`（候选 main:1489、1556）直接调用一次 `build_family`；`inspect_execution_plan` 只在原 child/其他冷 builder 的 compile 后同步检查；selected-head free helper 只在原 optional-head 冷准备中调用。`prepare_logits_inputs` 和 draft score/ID helper 改为直接 out-of-line 调用，其消费者仍是 `prepare_draft_program`、`prepare_prefix_sampling`、`prepare_sampling_frontier` 与 factory 的构图代码。没有新增运行时函数表、virtual 分派、每 token factory lookup 或权限 owner。

`FamilyBuildResult` 只带原 unique_ptr 和固定3domain标量 facts，没有新动态诊断容器；Family 的一次 heap allocation 本来已存在。所有原 graph/variant/local vector、Tensor/literal 分配仍在冷构造，原唯一 native executor、budget/lease/retirement 不变。具体 Family/Graph 从原稳定 unique_ptr 开始存在，`PreparedSampling*` 由原 owner 成功后接回。不能据这些源事实宣称编译器指令或实际时间完全不变。

热点源核对：原 `find_child` 的 map/child 查找实现逐字节未改；候选从 `Phase &prepare_child` 到整个 main 文件末尾与基线逐字节相同（涵盖原 Phase 初始化、步骤准备/submit/wait/publish/driver/应用路径）。原有首次 carrier 准备和 idle `admit_exact_shape` 仍可能分配/编译，后者保留已有 lookup、退休后淘汰和受限重试；不能把它包装成“整个请求过程中绝不 cold compile”。本片没有在稳定 child 的逐步执行上增加查表或分配算法。

性能保护的实际标准仍是默认构建、默认 full-V 完整消费者的普通/MTP GPU decode；显式32K或局部数学一致不能代签。静态保持专用数学和执行接线，说明此边界无需引入额外热分派；是否达到各模型专用引擎水平、是否有更好 kernel/融合/缓存设计，仍需后续具体功能/执行与完整性能证据。本审查不启动独立性能候选。
