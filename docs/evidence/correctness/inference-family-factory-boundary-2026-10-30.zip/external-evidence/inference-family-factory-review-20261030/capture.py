from pathlib import Path
import hashlib, json, subprocess

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
paths = ['engine/models/qwen35/main.cc', 'engine/models/qwen35/graph_builder.h',
         'engine/models/qwen35/graph_builder.cc', 'engine/models/qwen35/target_graph.h',
         'engine/models/qwen35/weights.h', 'engine/models/qwen35/weights.cc',
         'engine/models/qwen35/projection_binding.h',
         'engine/models/qwen35/cold_sources.cmake',
         'engine/inference/prepared_program_family.h']
pins = []
for name in paths:
    data = (root / name).read_bytes()
    pins.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
(out / 'source-pins.json').write_text(json.dumps(dict(head=head, scope='Read-only existing-source contract audit; no candidate application, build, native execution or download.', sources=pins), indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(head=head, sources=len(pins)), separators=(',', ':')))
