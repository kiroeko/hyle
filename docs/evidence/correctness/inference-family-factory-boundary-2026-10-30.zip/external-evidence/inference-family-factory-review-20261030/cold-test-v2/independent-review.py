from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[2]
REL = 'tests/tools/qwen_cold_family_case.h'
old = (W/'base'/REL).read_bytes()
new = (W/'candidate'/REL).read_bytes()
assert hashlib.sha256(new).hexdigest() == '1aa6ec5dad90b85dfff9bdf66c0235da80593bd1c0383ae4732de366f76b4034'
assert (R/REL).read_bytes() == new
def once(s,a,b):
    assert s.count(a)==1,(s.count(a),a[:70]);return s.replace(a,b,1)
text = new.decode()
a = text.index('  // The first real Family compile fails')
b = text.index('  const auto first = model.find_child',a)
text = text[:a]+'  require(model.prepare_family(finite_rows), "original finite cold family was unavailable");\n'+text[b:]
text = once(text,'  const auto *const original_graph = &original_family->graph;\n  const auto *const original_sampling = &model.sampling_configuration();\n','')
text = once(text,'        &a->family.graph == original_graph && &b->family.graph == original_graph &&\n        &a->program.resource_graph() == original_graph && &b->program.resource_graph() == original_graph &&\n        a->family.sampling == original_sampling && b->family.sampling == original_sampling &&\n','')
text = once(text,'  const q::FamilyKey state_key(1, q::GraphRole::kText, 0, q::TextCompletion::kStateOnly);\n',
    '  const q::FamilyKey state_key(1, q::GraphRole::kText, 0, q::TextCompletion::kStateOnly);\n  const auto resource = q::mem::system_resource();\n')
text = once(text,'      "\\\"first_compile_refusal_kept_kv_only\\\":true,\\\"stable_graph_and_sampling_identity\\\":true,"\n','')
assert text.encode() == old
report = dict(status='PASS_INDEPENDENT_STATIC_REVIEW_NOT_NATIVE_VALIDATION',
    candidate_sha256=hashlib.sha256(new).hexdigest(),candidate_bytes=len(new),
    original_sha256=hashlib.sha256(old).hexdigest(),inverse_five_changes_original_bytes_exact=True,
    checks=[
        'CPU default constructor passes no shared allocation budget; cache_budget and execution_budget are independent accounting scopes even on the same system_resource.',
        'Pressure is an original execution_budget Reservation, not fake compiler outcome or payload allocation. Cache schema/arenas use cache_budget; the real finite compile uses execution_budget.',
        'Fresh control excludes schema, bank, pool, snapshots and payload readiness. A/H64 untrained graph has no recurrent slots and disabled sampler has no hidden store.',
        'Expected retained bytes are key/value bank payloads only, subtracting actual cache Metadata category. Does not compare KV-only actual storage to full state plan.',
        'First typed native-free ResourceExhausted must retain complete cache tuple and leave maps/phases/versions/loans/workspace diagnostics empty. Reservation and failed metadata release are checked.',
        'Same finite key retries after pressure scope exits. Original complete children/Graph/PreparedSampling identity and original remaining tests remain.',
        'For this A/no-hidden graph, state_sources and extra_stores are empty. PreparedProgramFamily.needs_specialization returns false, so resource_graph() legitimately returns original Family.graph.',
    ],
    actual_source_basis=['engine/models/qwen35/main.cc:1126-1145 separate budget construction',
        'engine/models/qwen35/main.cc:1273-1281 cache_usage payload scope',
        'engine/models/qwen35/family_factory.cc:188-195 hidden schema condition',
        'engine/inference/prepared_program_family.h:39-40 resource_graph and114-141 needs_specialization'],
    limits=['Not a late inspection-error or optional-head failure test.',
        'Static review does not assert reserve/compile/native execution passed.'],
    product_edits=0,candidate_edits=0,builds=0,native_runs=0)
(W/'independent-review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ('status','candidate_sha256','inverse_five_changes_original_bytes_exact')}))
