from pathlib import Path
import difflib, hashlib, json, re

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
batch = root / '.scratch/inference-family-factory-extract-20261030'
plan = json.loads((batch / 'plan.json').read_text(encoding='utf-8'))
base = (root / 'engine/models/qwen35/main.cc').read_text(encoding='utf-8')
candidate = (batch / 'candidate/engine/models/qwen35/main.cc').read_text(encoding='utf-8')
factory = (batch / 'candidate/engine/models/qwen35/family_factory.cc').read_text(encoding='utf-8')
header = (batch / 'candidate/engine/models/qwen35/family_factory.h').read_text(encoding='utf-8')
weights_h = (batch / 'candidate/engine/models/qwen35/weights.h').read_text(encoding='utf-8')
weights_cc = (batch / 'candidate/engine/models/qwen35/weights.cc').read_text(encoding='utf-8')

def between(text, start, end):
    first = text.index(start)
    return text[first:text.index(end, first)]

def tokens(text):
    pattern = r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27|[a-zA-Z_][a-zA-Z_0-9]*|(?:[0-9]+(?:\.[0-9]*)?)|[^\s]'
    return [value for value in re.findall(pattern, text, re.S) if not value.startswith(('//', '/*'))]

checks = {}
for item in plan['preconditions']:
    path = root / item['relative']
    checks['base:' + item['relative']] = not path.exists() if item.get('absent') else hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
for item in plan['candidate']:
    checks['candidate:' + item['relative']] = hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
checks['patch_pin'] = hashlib.sha256(Path(plan['patch']['path']).read_bytes()).hexdigest() == plan['patch']['sha256']
checks['SamplingConfiguration'] = tokens(between(base, 'struct SamplingConfiguration final {', '// Typed ready inputs')) == tokens(between(header, 'struct SamplingConfiguration final {', 'struct PreparedSampling;'))
checks['Family_layout'] = tokens(between(base, 'struct FamilyPorts {', 'struct FamilyChild final {')) == tokens(between(header, 'struct FamilyPorts {', '// An optional already prepared'))
checks['PreparedDraftHead_layout'] = tokens(between(base, 'struct PreparedDraftHead final {', '// Actual cold storage')) == tokens(between(weights_h, 'struct PreparedDraftHead final {', '// Transform only;'))
checks['prepare_logits_inputs_body'] = tokens(between(base, 'sampling::LogitsInputsFor<V> prepare_logits_inputs(', '\nGenerationBoundary generation_boundary')) == tokens(between(factory, 'sampling::LogitsInputsFor<V> prepare_logits_inputs(', '\nV draft_scores'))
checks['packed_projection_check'] = tokens(between(base, 'void report_packed_projections(', '\nstruct SamplingConfiguration')) == tokens(between(factory, 'void report_packed_projections(', '\nvoid merge_execution_plan_facts'))

old = between(base[base.index('  bool prepare_family('):], '    auto result = std::make_unique<Family>();', '    // Publish only a complete cold candidate.')
new = between(factory, '    auto result = std::make_unique<Family>();', '  return {std::move(result), plan_facts};')
substitutions = [
    ('    definition.sampling = &prepared_sampling;\n', ''),
    ('planned_chunks', 'request.chunks'),
    ('      if (tokens == 0 || tokens > capacity)\n        throw std::runtime_error("finite text chunk outside nonempty context capacity");\n', ''),
    ('retains_sampling_frontier()', 'prepared.retain_hidden'),
    ('cache_plan.hidden_slots', 'prepared.hidden_slots'),
    ('cache_plan.state_slots', 'prepared.state_slots'),
    ('    if (requests > cache_plan.active_sequences || cache::multiply(requests, max_query_rows) > cache_plan.max_query_rows)\n      throw std::runtime_error("finite family exceeds the configured batch capacity");\n    prepare_cache();\n', ''),
    ('          const bool subset = prepare_draft_vocabulary(selected_sampler);\n', ''),
    ('draft_scores(recipe, selected, subset)', 'qwen35::draft_scores(recipe, selected, prepared.draft_projection)'),
    ('original_draft_id(r, r.op(', 'qwen35::original_draft_id(r, r.op('),
    ('})[1], subset);', '})[1], prepared.draft_projection);'),
    ('ffn_placement.cpu_layers()', 'model.cpu_ffn_layers'),
    ('cache_plan.in_flight_batches >= 2 && !scheduler', 'prepared.emit_successor'),
    ('return false; // Cold capability only;', 'return {}; // Cold capability only;'),
    ('      record_execution_plan(child.compiled.report, assembly.constants());', '      merge_execution_plan_facts(plan_facts, inspect_execution_plan(\n          execution, model.cpu_ffn_layers, child.compiled.report, assembly.constants()));'),
]
applied = []
for before, after in substitutions:
    count = old.count(before)
    applied.append(dict(before=before, after=after, occurrences=count))
    old = old.replace(before, after)
checks['Family_body_after_explicit_fact_projection'] = tokens(old) == tokens(new)
checks['Family_body_projection_no_unused_transform'] = all(item['occurrences'] > 0 for item in applied)
diff = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='independent-projected-base', tofile='candidate-factory-body'))
(out / 'family-body-remaining.diff').write_text(diff, encoding='utf-8')

old_inspect = between(base, '  void record_execution_plan(', '\n  void prepare_cache()')
old_inspect = old_inspect[old_inspect.index('{') + 1:old_inspect.rfind('}')]
old_inspect = old_inspect.replace('known_workspace_peak', 'facts.workspace_peak').replace('known_workspace_limits', 'facts.workspace_limits').replace('ffn_placement.cpu_layers()', 'cpu_ffn_layers')
old_inspect = old_inspect.replace('      return;', '      facts.domain_count = 1;\n      return facts;')
old_inspect = old_inspect.replace('if (!cpu_ffn_layers) return;', 'if (!cpu_ffn_layers) return facts;')
old_inspect = old_inspect.replace('    for (std::size_t i = 0; i < facts.workspace_peak.size(); ++i)', '    facts.domain_count = facts.workspace_peak.size();\n    for (std::size_t i = 0; i < facts.workspace_peak.size(); ++i)')
new_inspect = between(factory, 'ExecutionPlanFacts inspect_execution_plan(', '\nFamilyBuildResult build_family(')
new_inspect = new_inspect[new_inspect.index('{') + 1:new_inspect.rfind('}')]
new_inspect = new_inspect.replace('  ExecutionPlanFacts facts;\n', '')
new_inspect = new_inspect[:new_inspect.rfind('  return facts;')]
checks['execution_plan_strict_validation_after_local_fact_projection'] = tokens(old_inspect) == tokens(new_inspect)
(out / 'execution-inspection-remaining.diff').write_text(''.join(difflib.unified_diff(old_inspect.splitlines(True), new_inspect.splitlines(True))), encoding='utf-8')

source_transform = between(base, '    auto selected = select_dense_weight_rows(', '    return true;\n  }\n\n  V draft_scores')
source_transform = source_transform.replace('    resources_->draft_head.emplace(PreparedDraftHead{std::move(selected), std::move(ids), std::move(identity)});', '    return {std::move(selected), std::move(ids), std::move(identity)};')
source_transform = source_transform.replace('inference::artifact::sha256', 'hyle::inference::artifact::sha256')
target_transform = between(weights_cc, 'PreparedDraftHead prepare_draft_head(', '\n} // namespace qwen35')
target_transform = target_transform[target_transform.index('{')+1:target_transform.rfind('}')]
checks['draft_head_transform_body'] = tokens(source_transform) == tokens(target_transform)

# Independently restore complete original main from candidate using only the
# explicit extraction islands. No generator or author's mapping is imported.
restored = candidate.replace('#include "family_factory.h"\n', '')
islands = [
    ('// Distinguish direct packed contractions', '// Typed ready inputs', '// Typed ready inputs'),
    ('sampling::LogitsInputsFor<V> prepare_logits_inputs(', 'GenerationBoundary generation_boundary', 'GenerationBoundary generation_boundary'),
    ('struct FamilyPorts {', 'struct FamilyChild final {', 'struct FamilyChild final {'),
    ('// Extra cold draft projection only.', '// Actual cold storage', '// Actual cold storage'),
]
for start, end, target in islands:
    restored = restored.replace(target, between(base, start, end) + target, 1)
replaced_islands = [
    ('  bool prepare_draft_vocabulary(', '  const FfnPlacement ffn_placement;', '  bool prepare_draft_vocabulary('),
    ('  void record_execution_plan(', '  void prepare_cache()', '  void merge_execution_plan('),
    ('  bool prepare_family(', '  // These capacities are physical carriers.', '  bool prepare_family('),
]
for start, end, candidate_start in replaced_islands:
    restored = restored.replace(between(restored, candidate_start, end), between(base, start, end), 1)
checks['complete_main_inverse_restoration'] = restored == base
(out / 'main-inverse-remaining.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True), restored.splitlines(True))), encoding='utf-8')
old_preflight = between(base, '  bool prepare_family(', '    auto result = std::make_unique<Family>();')
new_preflight = between(candidate, '  bool prepare_family(', '    // Validate admission before materializing')
old_preflight = old_preflight.replace('const bool packed_verify = packs_verify(packing), packed_target = packs_target(packing);', 'const bool packed_verify = packs_verify(packing);')
checks['Model_admission_preflight_unchanged'] = tokens(old_preflight) == tokens(new_preflight)

result = dict(status='PASS_STATIC_ONLY' if all(checks.values()) else 'REVIEW_REQUIRES_INSPECTION',
              base_head=plan['base_head'], patch=plan['patch'], checks=checks,
              family_body_tokens=len(tokens(new)), explicit_projection=applied,
              no_build=True, no_native=True, product_edits=0)
(out / 'independent-candidate-review.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(status=result['status'], failed=[k for k,v in checks.items() if not v], family_tokens=result['family_body_tokens'])))
