from pathlib import Path
import hashlib, json, subprocess

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
factory_plan = json.loads((root / '.scratch/inference-family-factory-extract-20261030/plan.json').read_text(encoding='utf-8'))
test_plan = json.loads((out / 'cold-test-v2/plan.json').read_text(encoding='utf-8'))
checks, pins = {}, []
for entry in [*factory_plan['candidate'], test_plan['candidate']]:
    relative = entry['relative']
    data = (root / relative).read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    checks['current_product_exact:' + relative] = actual == entry['sha256'] and len(data) == entry['bytes']
    pins.append(dict(relative=relative, bytes=len(data), sha256=actual))
for relative in ['engine/models/qwen35/cache_plan.h', 'engine/models/qwen35/session_state.h', 'engine/inference/prepared_program_family.h']:
    data = (root / relative).read_bytes()
    pins.append(dict(relative=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
checks['test_original_inverse_exact'] = test_plan['inverse_restoration']['byte_exact'] and test_plan['inverse_restoration']['original_sha256'] == test_plan['base']['sha256'] == test_plan['inverse_restoration']['restored_sha256']
checks['test_patch_pin'] = hashlib.sha256(Path(test_plan['patch']['path']).read_bytes()).hexdigest() == test_plan['patch']['sha256']
report = dict(status='PASS_SOURCE_DESIGN_REVIEW_ONLY' if all(checks.values()) else 'PIN_MISMATCH',
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), checks=checks, sources=pins,
    verdict='No static blocker. Test pressure/accounting/identity assumptions are valid for its explicitly guarded A/H64/V64 CPU fixture.',
    accounting=['Fresh cache metadata may be nonzero; payload must be zero, not total live bytes.',
                'Post-refusal payload = cache live - metadata = known cache bytes = target-bank sum plus optional draft-bank bytes.',
                'No assertion equates KV-only bytes with full cache_plan.backing_bytes before prepare_state_storage.',
                'Cache budget and execution budget are distinct ResourceBudget objects even when both use process-system resource.',
                'Execution reservation charges requested bytes without allocating a dummy payload; destruction must restore the original exact live charge.'],
    identity=['A has no recurrent slots and this greedy/no-frontier/no-MTP plan has no hidden stores; resource_graph borrows original Family.graph.',
              'Default PreparedSampling pointer is the original owner object; no copied configuration replaces its identity.',
              'Original finite/exact selection, later state-storage phase, warm reuse and existing budget refusal checks remain.'],
    coverage_limits=['No native/build result inferred from source review.',
                     'Early cold budget failure does not simulate a later child resource-inspection/packed-validation throw after an earlier child succeeded.',
                     'Therefore unchanged failed diagnostics only cover the early rejection; the changed post-inspection merge timing remains an explicit behavior/source-review fact.',
                     'The cold-only case submits zero graphs and does not measure numeric or runtime behavior.',
                     'Optional selected draft head is constructor-prepared; no absent-head/late-head failure is covered by this A fixture.'],
    product_edits=0, builds=0, native_runs=0, downloads=0)
(out / 'cold-test-design-risk-review.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=report['status'], sources=len(pins), failed=[k for k,v in checks.items() if not v])))
