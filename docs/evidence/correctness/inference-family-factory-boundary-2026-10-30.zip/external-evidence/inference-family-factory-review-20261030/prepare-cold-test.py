from pathlib import Path
import hashlib, json, subprocess

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent / 'cold-test-v2'
relative = Path('tests/tools/qwen_cold_family_case.h')
original = (root / relative).read_bytes()
text = original.decode('utf-8')
newline = '\r\n' if b'\r\n' in original else '\n'
text = text.replace('\r\n', '\n')
changes = []
old = '''  const std::array finite_rows{std::size_t{1}, std::size_t{2}};
  require(model.prepare_family(finite_rows), "original finite cold family was unavailable");
'''
new = '''  const std::array finite_rows{std::size_t{1}, std::size_t{2}};
  // The first real Family compile fails after its original KV tuple is ready.
  // This is still KV-only storage: no state/hidden pool has been prepared.
  const auto resource = q::mem::system_resource();
  const auto fresh_execution = q::take(model.execution_budget.usage(resource));
  const auto fresh_cache = model.cache_usage();
  const auto fresh_peaks = model.known_workspace_peak, fresh_limits = model.known_workspace_limits;
  require(!model.attention_schema.valid() && model.families.empty() &&
      !model.known_cache_backing_bytes && !model.state_storage_prepared &&
      model.attention_schemas.empty() && model.page_inventory.banks.empty() &&
      model.draft_inventory.banks.empty() && !model.hidden_pool.valid() &&
      std::ranges::all_of(model.state_pools, [](const auto &pools) {
        return !pools.history.valid() && !pools.recurrent.valid();
      }) && !model.snapshot_versions.capacity && !model.snapshot_versions.live &&
      fresh_cache.live_bytes == fresh_cache.live_by_category[
          static_cast<std::size_t>(q::c::ResourceBudgetCategory::kMetadata)] &&
      fresh_execution.live_bytes < fresh_execution.limit_bytes,
      "cold-first failure fixture was already prepared or had no metadata allowance");
  const auto expected_kv_bytes = q::cache::add(q::cache::multiply(
      q::cache::add(plan.key_bank_bytes, plan.value_bank_bytes), geometry.attention_layers()),
      q::cache::add(plan.draft_key_bank_bytes, plan.draft_value_bank_bytes));
  {
    auto pressure = q::take(model.execution_budget.reserve(resource,
        fresh_execution.limit_bytes - fresh_execution.live_bytes));
    bool exhausted = false;
    try { (void)model.prepare_family(finite_rows); }
    catch (const i::EvaluationFailure &failure) {
      exhausted = failure.status().IsResourceExhausted() && !failure.status().has_native_error();
    }
    require(exhausted && model.attention_schema.valid() && model.families.empty() &&
        model.probe_families.empty() && model.phases.empty() && !model.active_step &&
        !model.carrier_borrowed && !model.snapshot_versions.live && !model.state_storage_prepared &&
        !model.hidden_pool.valid() && model.known_workspace_peak == fresh_peaks &&
        model.known_workspace_limits == fresh_limits,
        "cold-first budget refusal lost its KV tuple or published Family/state/execution/diagnostics");
    const auto kv_usage = model.cache_usage();
    const auto kv_metadata = kv_usage.live_by_category[
        static_cast<std::size_t>(q::c::ResourceBudgetCategory::kMetadata)];
    require(kv_usage.live_bytes - kv_metadata == expected_kv_bytes &&
        model.known_cache_backing_bytes == expected_kv_bytes &&
        kv_usage.live_bytes <= kv_usage.limit_bytes &&
        model.page_inventory.banks.size() == geometry.attention_layers() * 2 &&
        model.snapshot_versions.capacity == plan.snapshot_slots &&
        q::take(model.execution_budget.usage(resource)).live_bytes == fresh_execution.limit_bytes,
        "cold-first refusal lost exact KV-only payload/accounting or leaked execution metadata");
  }
  require(q::take(model.execution_budget.usage(resource)).live_bytes == fresh_execution.live_bytes,
      "cold-first refusal retained execution metadata after pressure release");
  require(model.prepare_family(finite_rows), "same first Family could not retry with its retained KV tuple");
  require(model.known_cache_backing_bytes == expected_kv_bytes && !model.state_storage_prepared,
      "same first Family retry duplicated KV backing or prepared unrelated state pools");
'''
assert text.count(old) == 1
changes.append((old, new))
text = text.replace(old, new)
old = '''  const auto *const original_second = &second->program;
  const auto original_unchanged = [&] {
'''
new = '''  const auto *const original_second = &second->program;
  const auto *const original_graph = &original_family->graph;
  const auto *const original_sampling = &model.sampling_configuration();
  const auto original_unchanged = [&] {
'''
assert text.count(old) == 1
changes.append((old, new))
text = text.replace(old, new)
old = '''        &a->program == original_first && &b->program == original_second &&
        original_family->programs.size() == 2 && original_family->chunks == std::vector<std::size_t>{1, 2} &&
'''
new = '''        &a->program == original_first && &b->program == original_second &&
        &a->family.graph == original_graph && &b->family.graph == original_graph &&
        &a->program.resource_graph() == original_graph && &b->program.resource_graph() == original_graph &&
        a->family.sampling == original_sampling && b->family.sampling == original_sampling &&
        original_family->programs.size() == 2 && original_family->chunks == std::vector<std::size_t>{1, 2} &&
'''
assert text.count(old) == 1
changes.append((old, new))
text = text.replace(old, new)
old = '''  const auto resource = q::mem::system_resource();
  const auto before = q::take(model.execution_budget.usage(resource));
'''
new = '''  const auto before = q::take(model.execution_budget.usage(resource));
'''
assert text.count(old) == 1
changes.append((old, new))
text = text.replace(old, new)
old = '''      "\\"plan_prepare_selection_equal\\":true,\\"unlisted_warm_rejected\\":true,\\"submitted_graphs\\":0,\\"HTTP\\":0}\\n";
'''
new = '''      "\\"first_compile_refusal_kept_kv_only\\":true,\\"stable_graph_and_sampling_identity\\":true,"
      "\\"plan_prepare_selection_equal\\":true,\\"unlisted_warm_rejected\\":true,\\"submitted_graphs\\":0,\\"HTTP\\":0}\\n";
'''
assert text.count(old) == 1
changes.append((old, new))
text = text.replace(old, new)
data = text.replace('\n', newline).encode('utf-8')
restored = text
for before, after in reversed(changes):
    assert restored.count(after) == 1
    restored = restored.replace(after, before)
restored_bytes = restored.replace('\n', newline).encode('utf-8')
assert restored_bytes == original
base_path, candidate_path = out / 'base' / relative, out / 'candidate' / relative
for path, value in ((base_path, original), (candidate_path, data)):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == value, f'refusing to overwrite {path}'
    else:
        path.write_bytes(value)
diff = subprocess.run(['git', 'diff', '--no-index', '--no-ext-diff', '--binary', '--', str(base_path), str(candidate_path)], cwd=root, capture_output=True)
assert diff.returncode == 1
lines = diff.stdout.decode('utf-8').splitlines(keepends=True)
prefix = relative.as_posix()
for i, line in enumerate(lines):
    if line.startswith('diff --git '): lines[i] = f'diff --git a/{prefix} b/{prefix}\n'
    elif line.startswith('--- '): lines[i] = f'--- a/{prefix}\n'
    elif line.startswith('+++ '): lines[i] = f'+++ b/{prefix}\n'
patch = ''.join(lines).encode('utf-8')
patch_path = out / 'cold-family-test.patch'
if patch_path.exists(): assert patch_path.read_bytes() == patch
else: patch_path.write_bytes(patch)
check = subprocess.run(['git', 'apply', '--check', str(patch_path)], cwd=root, capture_output=True)
assert check.returncode == 0, check.stderr.decode('utf-8', errors='replace')
def pin(path, value): return dict(path=str(path), relative=prefix, bytes=len(value), sha256=hashlib.sha256(value).hexdigest())
report = dict(status='SCRATCH_TEST_CANDIDATE_UNAPPLIED_UNBUILT', base=pin(base_path, original), candidate=pin(candidate_path, data),
              patch=dict(path=str(patch_path), bytes=len(patch), sha256=hashlib.sha256(patch).hexdigest()),
              scope='Existing cold-family CPU case only; one first-compile budget refusal/retry plus explicit stable Graph/sampling checks. Original remaining assertions unchanged.',
              limits=['KV-only pre-state-storage accounting, not full backing plan.', 'Compile budget failure precedes per-child inspection; no claim of late inspection fault coverage.', 'Optional draft head remains constructor-prepared; this case does not exercise subset head.'],
              builds=0, native_runs=0, product_edits=0, git_apply_check=True)
report['inverse_restoration'] = dict(changes=len(changes), original_sha256=hashlib.sha256(original).hexdigest(),
                                   restored_sha256=hashlib.sha256(restored_bytes).hexdigest(), byte_exact=True)
(out / 'plan.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(status=report['status'], bytes=len(data), sha256=report['candidate']['sha256'], patch_bytes=len(patch))))
