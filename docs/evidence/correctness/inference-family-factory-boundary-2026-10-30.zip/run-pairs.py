"""Serial exact finite pairs, stop on anynative or comparison error."""
from pathlib import Path
import importlib.util,json,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('factory_pair_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def stable(value):
 if isinstance(value,dict):return {key:stable(item) for key,item in value.items() if not key.endswith('_seconds') and not key.endswith('_per_second')}
 if isinstance(value,list):return [stable(item) for item in value]
 return value
def delta(a,z,path='$'):
 if isinstance(a,dict) and isinstance(z,dict):return [row for key in sorted(a.keys()|z.keys()) for row in delta(a.get(key),z.get(key),path+'.'+key)]
 if isinstance(a,list) and isinstance(z,list):
  if len(a)!=len(z):return [dict(path=path,old_length=len(a),new_length=len(z))]
  return [row for at,(x,y) in enumerate(zip(a,z)) for row in delta(x,y,path+'['+str(at)+']')]
 return [] if a==z else [dict(path=path,old=a,new=z)]
plan=b.read(W/'run-plan.json');checks=[]
for case in plan['cases']:
 reports={};pins={}
 for arm in ('baseline','candidate'):
  subprocess.run([sys.executable,str(W/'build.py'),'run',case,arm,'attempt1'],cwd=R,check=True)
  path=W/'runs'/arm/case/'attempt1/report.json';reports[arm]=b.read(path);pins[arm]=b.pin(path)
 old,new=stable(reports['baseline']),stable(reports['candidate']);added={}
 if case=='cold-family-cpu':
  for field in plan['cold_new_fields']:
   assert field not in old and new[field] is True;added[field]=new.pop(field)
 if case=='optional-v64':
  assert reports['candidate']['draft_vocabulary_rows']==4 and reports['candidate']['draft_vocabulary_weight_bytes']==512
  assert reports['candidate']['draft_vocabulary_map_bytes']==16
 differences=delta(old,new)
 result=dict(case=case,status='PASS' if not differences else 'FAIL',reports=pins,all_original_non_timing_fields_equal=not differences,
  differences=differences,explicit_new_fields=added,
  scope='All originalnon-time report fields exact; only*_seconds/*_per_second omitted. Cold2new booleans are explicitadditional candidateassertions. DefaultJSON isaggregateonly, not detailedprovider route.')
 b.save(W/('compare-'+case+'.json'),result);assert not differences,differences
 checks.append(result);print('PASS EXACT PAIR',case,flush=True)
b.save(W/'pair-summary.json',dict(status='PASS_ALL_15_FINITE_PAIRS',pairs=checks,native_processes=30))
