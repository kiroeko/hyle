"""Metadata-only exact finite pairs approved for thefactory extraction."""
from pathlib import Path
import importlib.util,shutil,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('factory_cases_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
assert not (W/'run-plan.json').exists()
old=R/'.scratch/inference-graph-alias-repair-harness-20261030'
original=b.read(old/'whole-plan.json')['cases'];tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
a=R/'.scratch/inference-e4-model-20261025/fixture-preparation/bf16-original'
e4=R/'.scratch/inference-mtp-e4-20261028/fixture'
local=W/'session-input';local.mkdir()
for name in ('weights.tsv','prompt.ids'):shutil.copyfile(old/'session-input'/name,local/name)
mapping_source=R/'.scratch/inference-draft-vocabulary-20261030/metadata-rows-cpu/probe-draft-vocabulary.ids'
mapping=W/'optional-v64.ids';shutil.copyfile(mapping_source,mapping)
tokens=mapping.read_text().split();assert tokens[:3]==['hyle-draft-vocabulary-v1','6'*64,'64'] and list(map(int,tokens[3:]))==[7,2,5,0]
cases={
 'cold-family-cpu':dict(consumer='tiny',args=['--cpu',str(a),'--cold-family']),
 'rows-cpu':dict(consumer='rows',args=['cpu',str(tiny/'weights.tsv'),'{METADATA}']),
 'rows-cuda':dict(consumer='rows',args=['cuda',str(tiny/'weights.tsv'),'{METADATA}']),
 'history-cpu':dict(consumer='tiny',args=['--cpu',str(tiny),'--history-control']),
 'packed-cuda':dict(consumer='tiny',args=['--cuda',str(tiny),'--mtp-packed-prefill']),
 'varlen-cuda':dict(consumer='tiny',args=['--cuda',str(tiny),'--mtp-varlen-verify']),
 'e4-cuda':dict(consumer='tiny',args=['--cuda',str(e4),'--mtp-e4']),
}
failed=b.read(R/'.scratch/inference-graph-alias-harness-20261030/plan.json')['original_failed_command']
cases['mixed-h64']=dict(consumer='tiny',args=failed[1:],outputs=4)
cases['cpu-ffn-real-cuda']=original['cpu-ffn-real-cuda']
cases['optional-v64']=dict(consumer='cli',args=['--inputs',str(tiny),'--capacity','16','--max-sessions','1','--active-sequences','1',
 '--prefix-cache','off','--progress','direct','--replay','auto','--backend','cuda','--sampling','greedy','--decode-overlap','auto',
 '--mtp','on','--mtp-max-drafts','1','--steps','4','--mtp-draft-vocabulary',str(mapping)],outputs=4)
for name in ('ordinary-single','mtp-single','ordinary-two','mtp-two'):cases[name]=original[name]
cases['session-cuda']=dict(consumer='session',args=['--backend','cuda','--inputs',str(local),'--output','{OUTPUT}','--scenario','sessions'])
b.save(W/'run-plan.json',dict(status='AUTHORIZED_FINITE_OLD229_NEW230_PAIRS',cases=cases,case_pairs=len(cases),native_processes=2*len(cases),
 original_whole_plan=b.pin(old/'whole-plan.json'),optional_map=b.pin(mapping),optional_map_original=b.pin(mapping_source),
 cold_new_fields=['first_compile_refusal_kept_kv_only','stable_graph_and_sampling_identity'],
 scope='Baseline then candidate percase,serializednative. Preserve fullnontime reports; onlycoldcase declares2newtrue fields. No trace/profile/performancewindow/download.'))
print('PREPARED15finite pairs/30processes;no native run by thispreparation.')
