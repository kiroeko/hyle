"""Seal metadata/source/log archive; no build/native or deletion."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('factory_collect_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
summary=read(W/'verification-summary.json');assert summary['status']=='FINITE_FACTORY_BOUNDARY_CHECKS_PASS_HISTORY_RETAINED'
baseline=read(W/'baseline-plan.json');base=read(baseline['base']['path']);source_proofs=[]
def matches(path,item):
 return path.is_file() and path.stat().st_size==item['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
for name,row in baseline['consumers'].items():
 receipt=read(row['receipt']['path']);exact(row['receipt']);exact(receipt['object']);proofs=[]
 for item in receipt['source_identities']:
  original=Path(item['path'])
  if matches(original,item):proofs.append(dict(identity=item,status='CURRENT_EXACT'));continue
  relative=original.relative_to(R);snapshot=W/'baseline-source'/relative
  if not matches(snapshot,item):
   data=subprocess.check_output(['git','show',baseline['source_base_commit']+':'+relative.as_posix()],cwd=R)
   assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],original
   snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(data)
  proofs.append(dict(identity=item,status='EXACT_PRE_APPLY_BASELINE_SOURCE',snapshot=pin(snapshot)))
 source_proofs.append(dict(consumer=name,receipt=row['receipt'],source_proofs=proofs))
current_receipts={}
for path in sorted((W/'compile').glob('*/receipt.json')):
 receipt=read(path)
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
 current_receipts[path.parent.name]=dict(receipt=pin(path),object=receipt['object'],repo_source_pins=len(receipt['source_identities']))
assert len(current_receipts)==9
save(W/'baseline-source-proofs.json',source_proofs)
save(W/'current-receipt-summary.json',current_receipts)
extract=R/'.scratch/inference-family-factory-extract-20261030'
review=R/'.scratch/inference-family-factory-review-20261030'
external=[]
for root in (extract,review):
 for path in sorted(root.rglob('*')):
  if not path.is_file() or path.suffix.lower() not in ('.json','.md','.patch','.py'):continue
  if any(part in ('__pycache__','candidate','base','test-apply','apply-check') for part in path.relative_to(root).parts):continue
  target=W/'external-evidence'/root.name/path.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes());external.append(pin(target))
# Re-read every rawpayload before allowing a futurecleanup; archive retains
# all identities and observations, never binarytensor payloads or SDK objects.
vectors=read(W/'session-vector-manifest.json');arms=vectors['arms']
assert len(arms['baseline'])==len(arms['candidate'])==378
for name in arms['baseline']:
 first,second=(arms[arm][name] for arm in ('baseline','candidate'));exact(first);exact(second)
 with Path(first['path']).open('rb') as a,Path(second['path']).open('rb') as z:
  while True:
   x,y=a.read(1048576),z.read(1048576);assert x==y,name
   if not x:break
summary['archive_source_proofs']=pin(W/'baseline-source-proofs.json')
summary['current_receipts']=pin(W/'current-receipt-summary.json')
summary['external_review_evidence']=external
summary['raw_vectors_rechecked_at_collection']=dict(files_per_arm=378,bytes_per_arm=150761472,sha256_and_direct_bytes=True,archived=False)
save(W/'summary-draft.json',summary)
allow={'.py','.json','.log','.txt','.md','.patch','.cc','.h','.cmake','.tsv','.ids','.xml','.ps1'}
files=[]
for path in sorted(W.rglob('*')):
 if not path.is_file() or path.suffix.lower() not in allow:continue
 if any(part in ('bin','tmp','__pycache__') for part in path.relative_to(W).parts):continue
 if path.name in ('evidence-draft.zip','archive-receipt.json','cleanup-targets.json'):continue
 files.append(path)
archive=W/'evidence-draft.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for path in files:out.write(path,path.relative_to(W).as_posix())
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None and len(check.namelist())==len(files)
 for path in files:
  data=check.read(path.relative_to(W).as_posix());assert data==path.read_bytes(),path
save(W/'archive-receipt.json',dict(archive=pin(archive),members=len(files),all_members_readback_byte_equal=True,
 summary=pin(W/'summary-draft.json'),raw_tensor_members=0,binary_SDK_members=0,
 published_names=['docs/evidence/correctness/inference-family-factory-boundary-2026-10-30.json',
 'docs/evidence/correctness/inference-family-factory-boundary-2026-10-30.zip']))
# Exact candidate cleanup inventory only; root must write/review test.ps1 and
# execute cleanup separately after archive review. Preserve objects/receipts.
cleanup=[]
for path in sorted((W/'bin').rglob('*')):
 if path.is_file():cleanup.append(pin(path))
for arm in ('baseline','candidate'):cleanup.extend(arms[arm].values())
save(W/'cleanup-targets.json',dict(status='PREPARED_NOT_EXECUTED',workspace_root=str(W),files=cleanup,
 count=len(cleanup),bytes=sum(item['bytes'] for item in cleanup),
 scope='Only generated binfiles and already byte/hash-verified rawSession vectors. Keep all CXXobjects/source/deps/logs/receipts andexistingcachedSDK/runtime original. Root owns test.ps1 and deletion.'))
print(json.dumps(dict(archive_bytes=archive.stat().st_size,members=len(files),sha256=pin(archive)['sha256'],
 raw_vector_files_rechecked=756,cleanup_files=len(cleanup),cleanup_bytes=sum(item['bytes'] for item in cleanup),cleanup_executed=False),ensure_ascii=False))
