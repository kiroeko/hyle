"""Actual cold dependency receipts/inventory, not a fullCMake claim."""
from pathlib import Path
import importlib.util,json,re,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('factory_static_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
rows=[]
for name in ('weights','builder','target','factory','leaf'):
 receipt=b.read(W/'compile'/name/'receipt.json')
 for item in [receipt['object'],receipt['dependencies'],*receipt['source_identities']]:b.exact(item)
 sources=[Path(item['path']).relative_to(R).as_posix() for item in receipt['source_identities']]
 forbidden=['engine/models/qwen35/main.cc','engine/models/qwen35/session_state.h','engine/inference/paged_sequence.h']
 assert not any(path in forbidden for path in sources),(name,sources)
 rows.append(dict(unit=name,source_pin_count=len(sources),repository_sources=sources,receipt=b.pin(W/'compile'/name/'receipt.json'),
  no_Model_main_or_Qwen_runtime_state_or_paged_sequence=True))
b.save(W/'cold-dependency-proof.json',rows)
inventory=R/'engine/models/qwen35/cold_sources.cmake';files=re.findall(r'"\$\{CMAKE_CURRENT_LIST_DIR\}/([^\"]+)"',inventory.read_text())
assert files==['weights.cc','graph_builder.cc','target_graph.cc','family_factory.cc']
guards=[];baseline=b.read(W/'baseline-plan.json')
for relative in ('engine/models/qwen35/CMakeLists.txt','tests/CMakeLists.txt'):
 path=R/relative;data=subprocess.check_output(['git','show',baseline['source_base_commit']+':'+relative],cwd=R)
 assert path.read_bytes()==data
 guards.append(dict(source=b.pin(path),byte_equal_source_baseline=True))
b.save(W/'cmake-inventory-proof.json',dict(status='FOUR_COLD_SOURCES_ORIGINAL_GUARDS_EXACT',inventory=b.pin(inventory),
 sources=[b.pin(inventory.parent/name) for name in files],guards=guards,configure_executed=False,full_default_build_executed=False))
print(json.dumps(dict(cold_dependencies={row['unit']:row['source_pin_count'] for row in rows},source_inventory=4,guards_exact=True)))
