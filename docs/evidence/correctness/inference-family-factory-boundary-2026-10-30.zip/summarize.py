"""Compact terminal facts; no native/build/cleanup execution."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('factory_final_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
attempts=[];failures=[]
for directory in ('compile','link','runs'):
 for path in sorted((W/directory).rglob('process.json')):
  process=read(path);assert process['state']=='TERMINAL' and not process['timed_out']
  row=dict(name=path.parent.relative_to(W).as_posix(),actual=process,process=pin(path),command=pin(path.parent/'command.json'))
  attempts.append(row)
  if process['exit']:failures.append(dict(**row,stdout=pin(path.parent/'stdout.log'),stderr=pin(path.parent/'stderr.log')))
counts=dict(total=len(attempts),CXX=sum(row['name'].startswith('compile/') for row in attempts),
 links=sum(row['name'].startswith('link/') for row in attempts),native=sum(row['name'].startswith('runs/') for row in attempts),
 failed_CXX=sum(row['name'].startswith('compile/') for row in failures),failed_native=sum(row['name'].startswith('runs/') for row in failures))
assert counts==dict(total=52,CXX=10,links=8,native=34,failed_CXX=1,failed_native=0)
assert len(failures)==1 and failures[0]['name']=='compile/factory/attempt1'
save(W/'process-inventory.json',dict(attempts=attempts,historical_failures=failures))
pairs=read(W/'pair-summary.json');assert pairs['status']=='PASS_ALL_15_FINITE_PAIRS' and len(pairs['pairs'])==15
extra=read(W/'sampling-supplement-summary.json');assert extra['status']=='PASS_TWO_POLICY_PAIRS'
for row in pairs['pairs']:assert row['status']=='PASS' and not row['differences']
for row in extra['checks']:assert row['status']=='PASS' and not row['differences']
session=read(W/'session-compare.json');vectors=read(W/'session-vector-manifest.json')
assert session['status']=='PASS_EXACT_COMPLETE_SESSION' and vectors['file_count_per_arm']==378 and vectors['bytes_per_arm']==150761472
whole=read(W/'whole-cli-summary.json');cold=read(W/'existing-plan-summary-comparison.json')
assert cold['status']=='ALL_RECORDED_COLD_SUMMARIES_EQUAL'
base=read(W/'model-link-base.json');assert len(base['retained'])==230
for item in base['retained']:exact(item)
final=R/'.scratch/inference-family-factory-extract-20261030/pending-seven-source-final.json'
sources=read(W/'source-freeze-attempt2.json')['sources']
for item in sources:exact(item)
summary=dict(schema='hyle.inference-family-factory-boundary.v1',date='2026-10-30',status='FINITE_FACTORY_BOUNDARY_CHECKS_PASS_HISTORY_RETAINED',
 full_goal_complete=False,baseline_HEAD=read(W/'baseline-plan.json')['observed_HEAD'],source_base=read(W/'baseline-plan.json')['source_base_commit'],
 doc_only_ancestry_source_exact=True,sources=sources,attempts=counts,
 build=dict(original_inputs=229,old_replaced=3,old_reused=226,new_factory_object=1,current_inputs=230,
  unique_current_TUs=9,CXX_attempts=10,weights_SDK_CXX=1,existing_model_cold_CXX=2,new_factory_CXX_attempts=2,
  consumers_CXX=4,header_only_leaf_CXX=1,max_compilers=2,NVCC=0,downloads=0,full_default_CMake_build=False),
 native=dict(processes=34,all_exit0=True,main_pairs=15,policy_pairs=2,
  cold_original_fields_exact=True,cold_explicit_added_true=['first_compile_refusal_kept_kv_only','stable_graph_and_sampling_identity'],
  optional_V64=dict(rows=4,head_weight_bytes=512,map_bytes=16,old_new_non_time_exact=True,quality_claim=False,performance_claim=False)),
 historical_CXX_failure=dict(unit='factory',attempt='attempt1',reason='WX C4457 innerrequest shadowed outerrequest;onlyouterparameter/fielduses renamed.',
  failed_source_snapshot=pin(W/'source-frozen/engine/models/qwen35/family_factory.cc'),final_source=pin(R/'engine/models/qwen35/family_factory.cc'),
  inverse_name_restores_original=True),
 scratch_preparation_events=[pin(W/'snapshot-preparation-note.json'),pin(W/'sampling-parser-note.json')],
 comparison=dict(all_17_original_non_time_report_pairs_exact=True,explicit_added_fields_only_on_cold_case=True,
  natural_sampling_large_JSON_and_text_observation_preserved=True,
  default_and_CPU2_existing_cold_stderr_summaries_exact=True,provider_route_scope='Aggregateandexistingselectedsummariesonly;not everyprovider/detailedcopy route export.'),
 Session=dict(payload_files_per_arm=378,payload_bytes_per_arm=150761472,all_rehashed_and_direct_byte_equal=True,
  observation_equal_except_absolute_output_root=True,differences=[],final_live_versions=0,idle_complete_head_checks=4,
  A_calls_after_B_stop=3,payload_known_plan_bytes=80240691),
 default_decode=[dict(case=row['case'],**row['timing_diagnostic']['decode_seconds']) for row in whole['checks']],
 timing_scope='Oneprocesspair percase for obviousregressiononly;factory cold_seconds intentionally excludescaller cache/headpreparation. Not a stableperformance result or MTP headqualitycomparison.',
 artifacts={name:pin(W/name) for name in ['baseline-plan.json','plan.json','source-freeze.json','source-freeze-attempt2.json',
  'model-link-base.json','sdk-engine-dependencies.json','current-consumer-source-audit.json','process-inventory.json',
  'pair-summary.json','sampling-supplement-summary.json','whole-cli-summary.json','existing-plan-summary-comparison.json',
  'session-compare.json','session-vector-manifest.json','cold-dependency-proof.json','cmake-inventory-proof.json','hardware-toolchain.json']},
 final_source_bundle=pin(final),
 limits=['FiniteQwen completeFamily coldmodule migration,not wholearchitecture/feature/quality completion.',
  'Coldtest earlycompile metadata refusal only,not latechildinspection fault injection. KV-only prefailurepayload isnot fullstatepool backing.',
  'SameFamilyGraph pointer assertion isguarded A/no-slot fixture only;GDN childresource graphs can legitimately specialize.',
  'Optionalhead isconstructor-preparedV64 syntheticrows4;not lateheadfailure/quality/globalV32K performance.',
  'No trace/profile/newperformancewindow,SDKfullbuild,NVCC/download orcleanup.'])
save(W/'verification-summary.json',summary)
print(json.dumps(dict(status=summary['status'],attempts=counts,pairs=17,retained=230,Session_bytes_per_arm=150761472,Session_byte_equal=True),ensure_ascii=False))
