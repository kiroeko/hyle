"""Current230: threeactual cached replacements plusone newfactory only."""
from pathlib import Path
import copy,importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('factory_seal_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
plan=read(W/'plan.json');base=read(plan['base']['path']);replacements={};receipts={}
for name in ('weights','builder','target','factory','cli','tiny','session','rows','leaf'):
 path=W/'compile'/name/'receipt.json';receipt=read(path)
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
 receipts[name]=dict(receipt=pin(path),object=receipt['object'])
for name,unit in plan['units'].items():
 if not unit.get('new'):replacements[key(unit['original']['path'])]=name
retained=[receipts[replacements[key(item['path'])]]['object'] if key(item['path']) in replacements else item for item in base['retained']]+[receipts['factory']['object']]
assert len(retained)==230 and len({key(item['path']) for item in retained})==230
for item in retained:exact(item)
sdk=copy.deepcopy(read(base['sdk_engine_dependencies']['path']))
for section in ('inspected','engine_consumers','native_consumers'):
 for index,row in enumerate(sdk[section]):
  if key(row['object']) not in replacements:continue
  name=replacements[key(row['object'])];receipt=read(receipts[name]['receipt']['path'])
  current=dict(row,object=receipt['object']['path'],dependencies=receipt['dependencies'])
  if section!='inspected':current.update(receipt=receipts[name]['receipt'],source_identities=receipt['source_identities'],
   engine_dependencies=[item['path'] for item in receipt['source_identities'] if Path(item['path']).is_relative_to(R/'engine')])
  sdk[section][index]=current
factory=read(receipts['factory']['receipt']['path'])
sdk['inspected'].append(dict(object=factory['object']['path'],dependencies=factory['dependencies']))
sdk['engine_consumers'].append(dict(object=factory['object']['path'],dependencies=factory['dependencies'],receipt=receipts['factory']['receipt'],
 source_identities=factory['source_identities'],engine_dependencies=[item['path'] for item in factory['source_identities'] if Path(item['path']).is_relative_to(R/'engine')]))
sdk['scope']='Current230. Replace weights/builder/target3 in original229 and appendfactory1.161actual dependency rows;69historical native/library metadata unavailable. ExistingGraphrepair9f4 reused.'
save(W/'sdk-engine-dependencies.json',sdk)
current={};previous={};audit=[]
for name,row in base['current_consumers'].items():
 exact(row['receipt']);exact(row['object']);receipt=read(row['receipt']['path'])
 mismatch=[item for item in receipt['source_identities'] if not Path(item['path']).is_file() or pin(item['path'])!=item]
 if mismatch or name in ('cli','tiny','session','rows'):
  previous[name]=dict(**row,status='HISTORICAL_NOT_CURRENT',mismatched_source_pins=mismatch)
  audit.append(dict(name=name,status='HISTORICAL',mismatched_source_pin_count=len(mismatch)))
 else:current[name]=row;audit.append(dict(name=name,status='CURRENT_EXACT',source_pin_count=len(receipt['source_identities'])))
for name in ('cli','tiny','session','rows'):current[name]=receipts[name]
historical=copy.deepcopy(base['historical_consumers']);historical['before-family-factory-5cda']=previous
args=[];count=0
for arg in base['link']:
 if key(arg)==key(plan['original_consumer']['path']):arg=receipts['cli']['object']['path'];count+=1
 if key(arg) in replacements:arg=receipts[replacements[key(arg)]]['object']['path']
 for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
  if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/cli').with_suffix(suffix));break
 args.append(arg)
assert count==1;args.append(factory['object']['path'])
for name in ('weights','builder','target','factory'):assert sum(key(arg)==key(receipts[name]['object']['path']) for arg in args)==1
save(W/'current-consumer-source-audit.json',audit)
save(W/'model-link-base.json',dict(schema='hyle.current-model-link-base.v1',base=plan['base'],compile=plan['consumers']['cli']['compile'],link=args,
 consumer_source=str(W/'cli.cc'),previous_consumer=plan['original_consumer']['path'],retained=retained,runtime=base['runtime'],
 sdk_engine_dependencies=pin(W/'sdk-engine-dependencies.json'),current_consumers=current,historical_consumers=historical,
 retained_categories=dict(SDK_and_engine=227,model_cold_objects=3,total_retained=230,old_replacements=3,old_inputs_reused=226,new_factory=1),
 model_cold_objects=[dict(source=plan['units'][name]['source'],**receipts[name]) for name in ('builder','target','factory')],
 current_compile_only=dict(leaf=receipts['leaf']),note='Familycold factory completeowner boundary; matching weights/header andall affectedconsumers compiled. No old/newPreparedSampling header consumers markedcurrent.'))
print(json.dumps(dict(status='SEALED_CURRENT230',retained=230,old_replaced=3,old_reused=226,new_factory=1,
 available_dependencies=len(sdk['inspected']),unavailable_metadata=len(sdk['unavailable']),historical=list(previous)),ensure_ascii=False))
