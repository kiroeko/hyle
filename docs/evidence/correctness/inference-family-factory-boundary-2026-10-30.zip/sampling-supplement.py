"""Exactly two extra policy cases, two arms each; original15plan unchanged."""
from pathlib import Path
import importlib.util,json,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('factory_sampling_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def stable(value):
 if isinstance(value,dict):return {key:stable(item) for key,item in value.items() if not key.endswith('_seconds') and not key.endswith('_per_second')}
 if isinstance(value,list):return [stable(item) for item in value]
 return value
def delta(a,z,path='$'):
 if isinstance(a,dict) and isinstance(z,dict):return [r for key in sorted(a.keys()|z.keys()) for r in delta(a.get(key),z.get(key),path+'.'+key)]
 if isinstance(a,list) and isinstance(z,list):
  if len(a)!=len(z):return [dict(path=path,old_length=len(a),new_length=len(z))]
  return [r for at,(x,y) in enumerate(zip(a,z)) for r in delta(x,y,path+'['+str(at)+']')]
 return [] if a==z else [dict(path=path,old=a,new=z)]
path=W/'sampling-supplement-plan.json'
tiny=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
cases={'sampling-policies-cpu':dict(consumer='tiny',args=['--cpu',str(tiny),'--sampling-policies']),
 'mtp-logits-cuda':dict(consumer='tiny',args=['--cuda',str(tiny),'--mtp-logits'])}
if not path.exists():
 b.save(path,dict(status='ROOT_AUTHORIZED_TWO_POLICY_PAIRS',cases=cases,native_processes=4,
  original15plan_unchanged=b.pin(W/'run-plan.json'),scope='Existingpolicy identity/logits consumers only; not thewholehistorical matrix.'))
else:assert b.read(path)['cases']==cases
checks=[]
for case in cases:
 values={};pins={}
 for arm in ('baseline','candidate'):
  report_path=W/'runs'/arm/case/'attempt1/report.json';process_path=report_path.parent/'process.json'
  if process_path.exists():
   process=b.read(process_path);assert process['state']=='TERMINAL' and process['exit']==0
   if not report_path.exists():b.parse_report(case,arm,'attempt1')
  else:subprocess.run([sys.executable,str(W/'build.py'),'run',case,arm,'attempt1'],cwd=R,check=True)
  report=W/'runs'/arm/case/'attempt1/report.json';values[arm]=b.read(report);pins[arm]=b.pin(report)
 differences=delta(stable(values['baseline']),stable(values['candidate']))
 row=dict(case=case,status='PASS' if not differences else 'FAIL',all_non_timing_fields_equal=not differences,differences=differences,reports=pins)
 b.save(W/('compare-'+case+'.json'),row);assert not differences,differences
 checks.append(row);print('PASS EXACT POLICY PAIR',case,flush=True)
b.save(W/'sampling-supplement-summary.json',dict(status='PASS_TWO_POLICY_PAIRS',checks=checks,native_processes=4))
