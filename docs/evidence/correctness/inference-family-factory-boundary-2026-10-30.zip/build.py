"""Family factory harness: snapshot/recipes now, candidate builds only afterfreeze."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,importlib.util,json,os,re,shutil,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-graph-alias-repair-harness-20261030/model-link-base.json'
CANDIDATE=R/'.scratch/inference-family-factory-extract-20261030/plan.json'
spec=importlib.util.spec_from_file_location('factory_prior_build',BASE.parent/'build.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
s=p.s;s.W=s.b.W=W
read,save,pin,exact,key=p.read,p.save,p.pin,p.exact,p.key
def snapshot():
 assert not (W/'baseline-plan.json').exists()
 base=read(BASE);candidate=read(CANDIDATE)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 source_base=candidate['base_head']
 assert not subprocess.check_output(['git','diff',source_base,head,'--','include','src','engine','tests'],cwd=R,text=True).strip()
 assert not subprocess.check_output(['git','diff','--name-only','--','include','src','engine','tests'],cwd=R,text=True).strip()
 for item in [*base['retained'],base['runtime']]:exact(item)
 assert len(base['retained'])==229
 for item in candidate['preconditions']:
  if item.get('absent'):assert not (R/item['relative']).exists()
  else:exact(item)
 for name in ('family_factory.h','family_factory.cc'):assert not (R/'engine/models/qwen35'/name).exists()
 consumers={}
 for name in ('cli','tiny','session','rows'):
  row=base['current_consumers'][name];receipt=read(row['receipt']['path'])
  for item in [row['receipt'],receipt['object'],*receipt['source_identities']]:exact(item)
  consumers[name]=dict(receipt=row['receipt'],object=receipt['object'],source_identities=receipt['source_identities'])
 copies=[]
 for relative in ('engine/models/qwen35/main.cc','engine/models/qwen35/weights.h','engine/models/qwen35/weights.cc',
  'engine/models/qwen35/graph_builder.h','engine/models/qwen35/graph_builder.cc',
  'engine/models/qwen35/target_graph.h','engine/models/qwen35/target_graph.cc','engine/models/qwen35/cold_sources.cmake'):
  source=R/relative;target=W/'baseline-source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
  copies.append(dict(original=pin(source),snapshot=pin(target)))
 sdk=read(base['sdk_engine_dependencies']['path']);changed={key(R/item['relative']) for item in candidate['candidate']}
 affected=[]
 for row in sdk['inspected']:
  d=read(row['dependencies']['path'])['Data']
  if any(key(path) in changed for path in [d['Source'],*d['Includes']]):
   command,recipe=s.command_for(row['object'],d['Source'])
   affected.append(dict(object=next(item for item in base['retained'] if key(item['path'])==key(row['object'])),
    source=d['Source'],dependencies=row['dependencies'],compile_command=command,recipe=recipe))
 assert {Path(row['source']).name for row in affected}=={'weights.cc','graph_builder.cc','target_graph.cc'}
 consumer_affected={name:[item['path'] for item in row['source_identities'] if key(item['path']) in changed] for name,row in consumers.items()}
 assert all(consumer_affected[name] for name in consumers)
 save(W/'baseline-plan.json',dict(status='BASELINE_SNAPSHOT_AND_RECIPES_ONLY',observed_HEAD=head,source_base_commit=source_base,
  doc_only_descendant_source_equal=True,base=pin(BASE),candidate_plan_at_snapshot=pin(CANDIDATE),
  retained=base['retained'],runtime=base['runtime'],consumers=consumers,snapshots=copies,
  original_link=base['link'],original_consumer=base['current_consumers']['cli']['object'],
  available_dependency_rows=len(sdk['inspected']),unavailable_dependency_metadata=sdk['unavailable'],
  predicted_affected_retained=affected,predicted_consumer_changed_pins=consumer_affected,
  candidate_closure_rule='Replace exactly actuallyimpacted229 input objects in place, append onlynewfamily_factory coldobject once →230. Existinggraph_builder/target already present, neverappend them twice.',
  candidate_not_prepared=True,CXX=0,native=0,NVCC=0,downloads=0))
 save(W/'baseline-candidate-source-diff.txt',subprocess.check_output(['git','diff',source_base,head,'--','include','src','engine','tests'],cwd=R,text=True))
 (W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
 print(json.dumps(dict(status='SNAPSHOT_READY_SOURCE_EXACT',observed_HEAD=head,source_base=source_base,retained=229,
  snapshots=len(copies),consumer_pins={name:len(row['source_identities']) for name,row in consumers.items()},
  predicted_affected_sources=[Path(row['source']).name for row in affected],predicted_consumers=list(consumer_affected)),ensure_ascii=False),flush=True)
def link_baseline(name,attempt):
 baseline=read(W/'baseline-plan.json');consumer=baseline['consumers'][name]
 for item in [consumer['object'],*baseline['retained'],baseline['runtime']]:exact(item)
 args=[];count=0
 for arg in baseline['original_link']:
  if key(arg)==key(baseline['original_consumer']['path']):arg=consumer['object']['path'];count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/('baseline-'+name)).with_suffix(suffix));break
  args.append(arg)
 assert count==1
 s.b.execute(args,W/'link'/('baseline-'+name)/attempt,240)
 save(W/('ready-baseline-'+name+'.json'),pin(W/'bin'/('baseline-'+name+'.exe')))
def prepare():
 assert not (W/'plan.json').exists()
 baseline=read(W/'baseline-plan.json');base=read(BASE);candidate=read(CANDIDATE)
 cold_plan_path=R/'.scratch/inference-family-factory-review-20261030/cold-test-v2/plan.json';cold=read(cold_plan_path)
 frozen=[]
 for item in [*candidate['candidate'],cold['candidate']]:
  exact(item);actual=pin(R/item['relative']);assert all(actual[field]==item[field] for field in ('bytes','sha256'));frozen.append(actual)
 changed={key(item['path']) for item in frozen};sdk=read(base['sdk_engine_dependencies']['path']);units={};affected=[]
 for row in sdk['inspected']:
  dep=read(row['dependencies']['path'])['Data']
  if not any(key(path) in changed for path in [dep['Source'],*dep['Includes']]):continue
  name={'weights.cc':'weights','graph_builder.cc':'builder','target_graph.cc':'target'}[Path(dep['Source']).name]
  original=next(item for item in base['retained'] if key(item['path'])==key(row['object']))
  command,recipe=s.command_for(original['path'],dep['Source'])
  units[name]=dict(source=dep['Source'],original=original,old_dependencies=row['dependencies'],recipe=recipe,compile=s.relocated(command,name));affected.append(row)
 assert set(units)=={'weights','builder','target'}
 factory=R/'engine/models/qwen35/family_factory.cc';units['factory']=dict(source=str(factory),compile=s.relocated(base['compile'],'factory',factory),new=True)
 wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
 leaf=W/'family-header.cc';leaf.write_text('#include "../../engine/models/qwen35/family_factory.h"\n')
 sources=dict(cli=wrapper,tiny=R/'tests/tools/qwen_host_image_test.cc',session=R/'engine/models/qwen35/mtp_session_probe.cc',
  rows=R/'tests/tools/qwen_draft_vocabulary_probe.cc',leaf=leaf)
 consumers={name:dict(source=str(source),compile=s.relocated(base['compile'],name,source)) for name,source in sources.items()}
 source_copies=[]
 for item in frozen:
  target=W/'source-frozen'/Path(item['path']).relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(item['path']).read_bytes())
  source_copies.append(dict(original=item,snapshot=pin(target)))
 save(W/'source-freeze.json',dict(sources=frozen,snapshots=source_copies,candidate_plan=pin(CANDIDATE),cold_test_plan=pin(cold_plan_path)))
 save(W/'plan.json',dict(base=pin(BASE),baseline=pin(W/'baseline-plan.json'),source_freeze=pin(W/'source-freeze.json'),
  retained=base['retained'],runtime=base['runtime'],units=units,consumers=consumers,actual_affected_dependency_rows=affected,
  available_dependency_rows=len(sdk['inspected']),unavailable_dependency_metadata=sdk['unavailable'],unchanged_retained=226,
  SDK_weights_CXX=1,existing_model_cold_CXX=2,new_factory_CXX=1,consumer_CXX=4,leaf_CXX=1,max_compilers=2,NVCC=0,downloads=0,
  candidate_retained_count=230,original_link=base['link'],original_consumer=base['current_consumers']['cli']['object'],
  cold_case_new_fields=['first_compile_refusal_kept_kv_only','stable_graph_and_sampling_identity']))
 print('PREPARED actualaffected3 + newfactory1 +4consumers/leaf1;max2cl;closure230.',flush=True)
def compile(attempt,names):
 plan=read(W/'plan.json');available=plan['units']|plan['consumers']
 def one(name):
  unit=available[name];s.b.execute(unit['compile'],W/'compile'/name/attempt,600)
  deps=read(W/'compile'/name/'dependencies.json')['Data']
  paths=sorted({Path(path).resolve() for path in [deps['Source'],*deps['Includes']] if Path(path).is_relative_to(R)})
  save(W/'compile'/name/'receipt.json',dict(object=pin(W/'compile'/name/'unit.obj'),dependencies=pin(W/'compile'/name/'dependencies.json'),
   process=pin(W/'compile'/name/attempt/'process.json'),source_identities=[pin(path) for path in paths]))
  print('COMPILED',name,flush=True)
 with ThreadPoolExecutor(max_workers=2) as pool:
  futures={pool.submit(one,name):name for name in names}
  for future in as_completed(futures):future.result()
def link(name,attempt):
 plan=read(W/'plan.json');receipt=read(W/'compile'/name/'receipt.json');replacements={}
 for unit,old in plan['units'].items():
  if old.get('new'):continue
  current=read(W/'compile'/unit/'receipt.json')
  for item in [current['object'],*current['source_identities']]:exact(item)
  replacements[key(old['original']['path'])]=current['object']
 factory=read(W/'compile/factory/receipt.json')
 retained=[replacements.get(key(item['path']),item) for item in plan['retained']]+[factory['object']]
 assert len(retained)==230 and len({key(item['path']) for item in retained})==230
 for item in [receipt['object'],*receipt['source_identities'],*factory['source_identities'],*retained]:exact(item)
 args=[];count=0
 for arg in plan['original_link']:
  if key(arg)==key(plan['original_consumer']['path']):arg=receipt['object']['path'];count+=1
  if key(arg) in replacements:arg=replacements[key(arg)]['path']
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 assert count==1 and not any(key(arg)==key(factory['object']['path']) for arg in args);args.append(factory['object']['path'])
 s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
def run(case,arm,attempt):
 cases=read(W/'run-plan.json')['cases']
 if (W/'sampling-supplement-plan.json').exists():cases=cases|read(W/'sampling-supplement-plan.json')['cases']
 row=cases[case];stem=('baseline-' if arm=='baseline' else '')+row['consumer']
 image=read(W/('ready-'+stem+'.json'));exact(image)
 folder=W/'runs'/arm/case/attempt;save(folder/'image.json',image)
 args=[str(folder/'vectors') if arg=='{OUTPUT}' else str(folder/'metadata') if arg=='{METADATA}' else arg for arg in row['args']]
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
 s.b.execute([image['path'],*args],folder,600)
 parse_report(case,arm,attempt)
def parse_report(case,arm,attempt):
 cases=read(W/'run-plan.json')['cases']
 if (W/'sampling-supplement-plan.json').exists():cases=cases|read(W/'sampling-supplement-plan.json')['cases']
 row=cases[case];folder=W/'runs'/arm/case/attempt
 process=read(folder/'process.json');assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
 exact(read(folder/'image.json'))
 text=(folder/'stdout.log').read_text(encoding='utf-8-sig');decoder=json.JSONDecoder();values=[];offset=0
 observations=[]
 while offset<len(text):
  while offset<len(text) and text[offset].isspace():offset+=1
  if offset==len(text):break
  try:value,offset=decoder.raw_decode(text,offset);values.append(value)
  except json.JSONDecodeError:
   end=text.find('\n',offset);end=len(text) if end<0 else end
   line=text[offset:end].strip()
   match=re.fullmatch(r'batched_text_sampling=true flat_identity_rows=2 flat_identity_words=4 families=(\d+) phases=(\d+)',line)
   assert case=='sampling-policies-cpu' and match,('Unexpected nonJSON stdout',case,line)
   observations.append(dict(batched_text_sampling=True,flat_identity_rows=2,flat_identity_words=4,families=int(match[1]),phases=int(match[2]),raw=line))
   offset=end
 assert values
 result=values[0] if len(values)==1 else dict(status='PASS',reports=values)
 if case=='sampling-policies-cpu':
  assert len(values)==2 and len(observations)==1
  assert values[0].get('source_id') and 'actual_graph_calls' in values[0]
  assert values[1].get('status')=='PASS' and values[1].get('case')=='sampling-policies'
  result=dict(status='PASS',reports=values,text_observations=observations)
 if row.get('outputs'):assert result['generated_tokens']==row['outputs'] and result['live_committed_versions']==0
 elif case=='session-cuda':assert result['status']=='MTP_SESSION_PROBE_COMPLETED'
 elif case=='sampling-policies-cpu':pass
 else:assert all(value['status']=='PASS' for value in values)
 save(folder/'report.json',result);print('PASS',arm,case,flush=True)
if __name__=='__main__':
 if sys.argv[1]=='snapshot':snapshot()
 elif sys.argv[1]=='link-baseline':link_baseline(sys.argv[2],sys.argv[3])
 elif sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='compile':compile(sys.argv[2],sys.argv[3:])
 elif sys.argv[1]=='link':link(sys.argv[2],sys.argv[3])
 elif sys.argv[1]=='run':run(sys.argv[2],sys.argv[3],sys.argv[4])
 elif sys.argv[1]=='parse-report':parse_report(sys.argv[2],sys.argv[3],sys.argv[4])
 else:raise ValueError(sys.argv[1])
