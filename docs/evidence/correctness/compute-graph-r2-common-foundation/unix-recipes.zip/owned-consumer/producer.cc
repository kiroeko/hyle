#include "producer.h"
#include <array>
#include <cstdint>
#include <limits>
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/detail/generated_result.h"
NativeTensor::~NativeTensor() noexcept {
  if (destroyed != nullptr) {
    buffer = {};
    ++*destroyed;
  }
}
hyle::Result<hyle::compute::OwnedResult<NativeTensor>>
negate(std::span<const float> values, int& destroyed) noexcept {
  using namespace hyle::compute;
  if (values.size() > static_cast<std::uint64_t>(INT64_MAX))
    return std::unexpected(hyle::Status::OutOfRange("shape exceeds int64"));
  HYLE_ASSIGN_OR_RETURN(auto context, cpu::create_context());
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto desc, TensorDesc::dense(
      DataType::kFloat32, std::array{static_cast<std::int64_t>(values.size())}));
  HYLE_ASSIGN_OR_RETURN(auto input, hyle::mem::Buffer::create(
      hyle::mem::system_resource(), values.size_bytes(), 64));
  HYLE_ASSIGN_OR_RETURN(auto output, hyle::mem::Buffer::create(
      hyle::mem::system_resource(), values.size_bytes(), 64));
  HYLE_RETURN_IF_ERROR(input.view().write(std::as_bytes(values)));
  HYLE_ASSIGN_OR_RETURN(auto input_view, ConstTensorView::create(desc, input.view()));
  HYLE_ASSIGN_OR_RETURN(auto output_view, TensorView::create(desc, output.view()));
  HYLE_ASSIGN_OR_RETURN(auto prepared, prepare(context, Unary{UnaryKind::kNeg}, desc));
  HYLE_ASSIGN_OR_RETURN(auto invocation, prepared.create_invocation());
  HYLE_ASSIGN_OR_RETURN(auto slot,
      detail::ResultSlot<NativeTensor>::create(hyle::mem::system_allocator()));
  HYLE_ASSIGN_OR_RETURN(auto writer, slot.begin());
  HYLE_RETURN_IF_ERROR(writer.emplace(NativeTensor(std::move(output), destroyed)));
  HYLE_ASSIGN_OR_RETURN(auto done, invocation.submit(queue, input_view, output_view));
  // CPU has finished reading input. Publish its real completion; the result
  // retains the native output allocation after this Context and slot die.
  return writer.publish(std::move(done));
}

