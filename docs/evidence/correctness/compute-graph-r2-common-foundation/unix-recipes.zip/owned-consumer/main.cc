#include "producer.h"
#include <array>
#include <cstdio>
#include "hyle/compute/cpu.h"
#include "hyle/compute/delegated_operation.h"
#include "hyle/graph/executable.h"
hyle::Status check() {
  using namespace hyle::compute;
  const std::array<float, 4> values{-3, 1, -2, 4};
  int destroyed = 0;
  ResultLease<NativeTensor> retained;
  {
    HYLE_ASSIGN_OR_RETURN(auto result, negate(values, destroyed));
    HYLE_ASSIGN_OR_RETURN(retained, result.wait());
  }
  if (destroyed != 0) return hyle::Status::Internal("early native owner destruction");
  {
    HYLE_ASSIGN_OR_RETURN(auto next, negate(std::array<float, 2>{7, -8}, destroyed));
    HYLE_ASSIGN_OR_RETURN(auto lease, next.wait());
    std::array<float, 2> actual{};
    HYLE_RETURN_IF_ERROR(lease->buffer.view().read(std::as_writable_bytes(std::span(actual))));
    if (actual != std::array<float, 2>{-7, 8})
      return hyle::Status::Internal("second output mismatch");
  }
  if (destroyed != 1) return hyle::Status::Internal("second owner not released");
  std::array<float, 4> actual{};
  HYLE_RETURN_IF_ERROR(retained->buffer.view().read(std::as_writable_bytes(std::span(actual))));
  if (actual != std::array<float, 4>{3, -1, 2, -4})
    return hyle::Status::Internal("retained output mismatch");
  auto copy = retained;
  retained = {};
  if (destroyed != 1) return hyle::Status::Internal("copied lease lost owner");
  copy = {};
  if (destroyed != 2) return hyle::Status::Internal("DSO native destructor missing");

  HYLE_ASSIGN_OR_RETURN(auto context, cpu::create_context());
  HYLE_ASSIGN_OR_RETURN(auto desc,
      TensorDesc::dense(DataType::kFloat32, std::array<std::int64_t, 1>{4}));
  HYLE_ASSIGN_OR_RETURN(auto source, hyle::mem::Buffer::create(
      hyle::mem::system_resource(), sizeof(values), 64));
  HYLE_ASSIGN_OR_RETURN(auto destination, hyle::mem::Buffer::create(
      hyle::mem::system_resource(), sizeof(values), 64));
  HYLE_ASSIGN_OR_RETURN(auto in_view, ConstTensorView::create(desc, source.view()));
  HYLE_ASSIGN_OR_RETURN(auto out_view, TensorView::create(desc, destination.view()));
  auto delegated = prepare_delegated(context, Operation(Unary{UnaryKind::kNeg}),
                                     std::array{in_view}, std::array{out_view});
  if (delegated || !delegated.error().IsUnimplemented())
    return hyle::Status::Internal("shared/delegated mode mismatch");

  HYLE_ASSIGN_OR_RETURN(auto builder, hyle::graph::GraphBuilder::create());
  HYLE_ASSIGN_OR_RETURN(auto input, builder.input(desc));
  HYLE_ASSIGN_OR_RETURN(auto neg, builder.add(Unary{UnaryKind::kNeg}, input));
  HYLE_ASSIGN_OR_RETURN(auto output, builder.add(Unary{UnaryKind::kAbs}, neg));
  HYLE_RETURN_IF_ERROR(builder.publish(output));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  HYLE_ASSIGN_OR_RETURN(auto compiled, hyle::graph::compile(
      graph, context, {.require_concurrent_invocations = true}));
  HYLE_ASSIGN_OR_RETURN(auto run, compiled.executable.create_invocation());
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  HYLE_RETURN_IF_ERROR(run.bind(input, in_view));
  HYLE_RETURN_IF_ERROR(run.bind(output, out_view));
  for (int iteration = 1; iteration <= 3; ++iteration) {
    const std::array<float, 4> changed{-3.F * iteration, 1, -2, 4};
    HYLE_RETURN_IF_ERROR(source.view().write(std::as_bytes(std::span(changed))));
    HYLE_ASSIGN_OR_RETURN(auto done, run.submit(queue));
    HYLE_RETURN_IF_ERROR(done.wait());
    HYLE_RETURN_IF_ERROR(destination.view().read(std::as_writable_bytes(std::span(actual))));
    if (actual != std::array<float, 4>{3.F * iteration, 1, 2, 4})
      return hyle::Status::Internal("Graph replay mismatch");
  }
  return hyle::Status::Ok();
}
int main() {
  const auto status = check();
  if (!status.ok()) {
    const auto message = status.message();
    std::fprintf(stderr, "%.*s\n", static_cast<int>(message.size()), message.data());
    return 1;
  }
  std::puts("PASS: native owning result across DSO, retained outputs, Direct mode, Graph replay");
}

