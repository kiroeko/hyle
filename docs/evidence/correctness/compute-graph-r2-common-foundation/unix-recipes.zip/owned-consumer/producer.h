#pragma once
#include <span>
#include <utility>
#include "hyle/compute/result.h"
#include "hyle/mem/buffer.h"
#if defined(_WIN32)
#if defined(R2_BUILD_PRODUCER)
#define R2_API __declspec(dllexport)
#else
#define R2_API __declspec(dllimport)
#endif
#else
#define R2_API __attribute__((visibility("default")))
#endif
struct NativeTensor final {
  hyle::mem::Buffer buffer;
  int* destroyed = nullptr;
  NativeTensor(hyle::mem::Buffer&& value, int& count) noexcept
      : buffer(std::move(value)), destroyed(&count) {}
  NativeTensor(NativeTensor&& other) noexcept
      : buffer(std::move(other.buffer)), destroyed(std::exchange(other.destroyed, nullptr)) {}
  R2_API ~NativeTensor() noexcept;
};
R2_API hyle::Result<hyle::compute::OwnedResult<NativeTensor>>
negate(std::span<const float> input, int& destroyed) noexcept;
#undef R2_API

