#!/usr/bin/env bash
set -euo pipefail
r2_root=/root/hyle-validation/r2-q4-20260916
cd "$r2_root"
tar -xf /mnt/c/hyle-scratch/r2-q4-20260916/r2-test-portability-worktree2.tar -C source-4e9f74a0
cd source-4e9f74a0
scripts/hyle-unix.sh cmake --build "$r2_root/factors-4e9f74a0-off" --parallel 2 --target hyle_mem_tests hyle_compute_tests hyle_compute_backend_cpu_tests hyle_compute_provider_native_tests hyle_graph_tests -- -k 0 >"$r2_root/logs-4e9f74a0/gcc-portability-final-build.log" 2>&1
ctest --test-dir "$r2_root/factors-4e9f74a0-off" --output-on-failure --no-tests=error --timeout 120 -L '^(mem|compute|compute_backend_cpu|compute_provider_native|graph)$' >"$r2_root/logs-4e9f74a0/gcc-portability-final-tests.log" 2>&1
