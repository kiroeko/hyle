#!/usr/bin/env bash
set -euo pipefail
r2_root=/root/hyle-validation/r2-q4-20260916
cd "$r2_root"
test ! -e logs-4e9f74a0/off-gcc-initial
cp -a logs-4e9f74a0/off logs-4e9f74a0/off-gcc-initial
tar -xf /mnt/c/hyle-scratch/r2-q4-20260916/r2-test-portability-worktree.tar -C source-4e9f74a0
cd source-4e9f74a0
scripts/hyle-unix.sh cmake --build "$r2_root/factors-4e9f74a0-off" --parallel 2 --target hyle_mem_tests hyle_compute_tests hyle_compute_backend_cpu_tests hyle_compute_provider_native_tests hyle_graph_tests -- -k 0 >"$r2_root/logs-4e9f74a0/gcc-portability-build.log" 2>&1
