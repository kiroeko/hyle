$ErrorActionPreference = 'Stop'
$r2Scratch = 'C:\hyle-scratch\r2-q4-20260916'
$r2UnixRoot = '/root/hyle-validation/r2-q4-20260916'
$r2MacRoot = '/Users/kiro/hyle-validation/r2-q4-20260916'
function Invoke-R2Gate {
    param([string]$GateName, [string]$Program, [string[]]$ArgumentList)
    $r2Log = Join-Path $r2Scratch "$GateName.log"
    Write-Output "START $GateName"
    & $Program @ArgumentList *> $r2Log
    $r2Code = $LASTEXITCODE
    Get-Content -LiteralPath $r2Log -Tail 12
    if ($r2Code -ne 0) { Write-Output "FAIL $GateName ($r2Code)"; exit $r2Code }
    Write-Output "PASS $GateName"
}
Invoke-R2Gate 'r2-linux-source' 'wsl.exe' @('-d', 'Ubuntu-24.04', '--exec', 'bash', '/mnt/c/hyle-scratch/r2-q4-20260916/r2-linux-owning-source.sh')
foreach ($r2Sanitizer in @('asan', 'ubsan', 'tsan')) {
    Invoke-R2Gate "r2-linux-$r2Sanitizer" 'wsl.exe' @('-d', 'Ubuntu-24.04', '--exec', 'bash', "$r2UnixRoot/run-r2-unix.sh", $r2UnixRoot, 'linux', $r2Sanitizer)
}
Invoke-R2Gate 'r2-air-off' 'ssh' @('kiro@172.22.10.198', 'bash', "$r2MacRoot/run-r2-unix.sh", $r2MacRoot, 'air', 'off')
Invoke-R2Gate 'r2-mini-off' 'ssh' @('-i', 'C:/Users/kiro/.ssh/codex_mac_172_22_10_107_win', 'kiro@172.22.10.107', 'bash', "$r2MacRoot/run-r2-unix.sh", $r2MacRoot, 'mini', 'off')
Write-Output 'PASS all R2 remaining gates'
