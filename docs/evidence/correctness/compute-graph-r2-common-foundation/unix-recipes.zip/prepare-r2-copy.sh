#!/usr/bin/env bash
set -euo pipefail
r2_root=$1
case "$r2_root" in
 /root/hyle-validation/r2-q4-20260916|/Users/kiro/hyle-validation/r2-q4-20260916) ;;
 *) exit 2 ;;
esac
cd "$r2_root"
if command -v sha256sum >/dev/null; then
 sha256sum candidate-4e9f74a0.tar
 printf '%s  %s\n' 9bfab18d206391024e411b087444c5f5bdabfe7712f8abd2d7895c159fafd8dd candidate-4e9f74a0.tar | sha256sum -c -
else
 shasum -a 256 candidate-4e9f74a0.tar
 printf '%s  %s\n' 9bfab18d206391024e411b087444c5f5bdabfe7712f8abd2d7895c159fafd8dd candidate-4e9f74a0.tar | shasum -a 256 -c -
fi
test ! -e source-4e9f74a0
mkdir source-4e9f74a0
tar -xf candidate-4e9f74a0.tar -C source-4e9f74a0
tar -xf r2-owning-consumer.tar
printf 'READY immutable 4e9f74a0 validation copy\n'

