#!/usr/bin/env bash
set -euo pipefail
export PATH=/opt/homebrew/bin:$PATH
r2_root=/Users/kiro/hyle-validation/r2-q4-20260916
r2_source="$r2_root/source-4e9f74a0"
r2_logs="$r2_root/logs-4e9f74a0/off"
r2_build="$r2_root/factors-4e9f74a0-off"
cd "$r2_source"
ctest --test-dir "$r2_build" --output-on-failure --no-tests=error --timeout 120 -L '^(mem|compute|compute_backend_cpu|compute_provider_native|graph)$' >"$r2_logs/tests.log" 2>&1
tail -n 15 "$r2_logs/tests.log"
r2_consumer="$r2_root/owned-source-4e9f74a0"
scripts/hyle-unix.sh cmake -S "$r2_root/owned-consumer" -B "$r2_consumer" -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_POSITION_INDEPENDENT_CODE=ON "-DHYLE_SOURCE_DIR=$r2_source" -DCMAKE_OSX_DEPLOYMENT_TARGET=14.4 >"$r2_logs/owning-source-configure.log" 2>&1
scripts/hyle-unix.sh cmake --build "$r2_consumer" --parallel 2 >"$r2_logs/owning-source-build.log" 2>&1
ctest --test-dir "$r2_consumer" --output-on-failure --no-tests=error >"$r2_logs/owning-source-tests.log" 2>&1
tail -n 10 "$r2_logs/owning-source-tests.log"
