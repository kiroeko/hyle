#!/usr/bin/env bash
set -euo pipefail
r2_root=/root/hyle-validation/r2-q4-20260916
r2_source="$r2_root/source-4e9f74a0"
r2_logs="$r2_root/logs-4e9f74a0/off"
r2_build="$r2_root/owned-source-4e9f74a0"
cd "$r2_source"
scripts/hyle-unix.sh cmake -S "$r2_root/owned-consumer" -B "$r2_build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_POSITION_INDEPENDENT_CODE=ON "-DHYLE_SOURCE_DIR=$r2_source" >"$r2_logs/owning-source-configure.log" 2>&1
scripts/hyle-unix.sh cmake --build "$r2_build" --parallel 2 >"$r2_logs/owning-source-build.log" 2>&1
ctest --test-dir "$r2_build" --output-on-failure --no-tests=error >"$r2_logs/owning-source-tests.log" 2>&1
tail -n 10 "$r2_logs/owning-source-tests.log"
