#!/usr/bin/env bash
set -euo pipefail
r2_root=$1
r2_platform=$2
case "$r2_root" in /root/hyle-validation/r2-q4-20260916|/Users/kiro/hyle-validation/r2-q4-20260916) ;; *) exit 2 ;; esac
cd "$r2_root"
if [ "$r2_platform" = linux ]; then
 grep -q '100% tests passed' logs-4e9f74a0/gcc-portability-final-tests.log
 for r2_kind in asan ubsan tsan; do grep -q '100% tests passed' "logs-4e9f74a0/$r2_kind/tests.log"; done
else
 grep -q '100% tests passed' logs-4e9f74a0/off/tests.log
fi
grep -q '100% tests passed' logs-4e9f74a0/off/owning-source-tests.log
python3 - "$r2_root" >"logs-4e9f74a0/test-overlay-sha256.log" <<'PY'
from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1])
manifest=json.loads((root/'r2-test-portability-files.json').read_text())
print('Product candidate:',manifest['product_candidate'])
print('Corrected test revision:',manifest['corrected_test_revision'])
for path,expected in manifest['files'].items():
    actual=hashlib.sha256((root/'source-4e9f74a0'/path).read_bytes()).hexdigest()
    assert actual==expected,path
    print('PASS',actual,path)
PY
tar -czf "$r2_platform-logs-4e9f74a0.tar.gz" logs-4e9f74a0 r2-test-portability-files.json
printf 'ARCHIVED %s actual passed gates and original attempts\n' "$r2_platform"
