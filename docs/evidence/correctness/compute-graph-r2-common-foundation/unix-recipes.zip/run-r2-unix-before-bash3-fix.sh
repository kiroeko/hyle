#!/usr/bin/env bash
set -euo pipefail
r2_root=$1
r2_platform=$2
r2_sanitizer=${3:-off}
case "$r2_root" in
 /root/hyle-validation/r2-q4-20260916|/Users/kiro/hyle-validation/r2-q4-20260916) ;;
 *) printf 'Unexpected validation root: %s\n' "$r2_root" >&2; exit 2 ;;
esac
case "$r2_sanitizer" in off|asan|ubsan|tsan) ;; *) exit 2 ;; esac
export PATH=/Users/kiro/hyle-verify-tools/bin:/opt/homebrew/bin:/usr/local/cuda-13.3/bin:$PATH
r2_source="$r2_root/source-4e9f74a0"
r2_logs="$r2_root/logs-4e9f74a0/$r2_sanitizer"
mkdir -p "$r2_logs"
r2_log_run() {
 r2_name=$1; shift
 printf 'START %s / %s / %s\n' "$r2_platform" "$r2_sanitizer" "$r2_name"
 if "$@" >"$r2_logs/$r2_name.log" 2>&1; then
  printf 'PASS %s / %s / %s\n' "$r2_platform" "$r2_sanitizer" "$r2_name"
 else
  r2_status=$?
  tail -n 45 "$r2_logs/$r2_name.log"
  exit "$r2_status"
 fi
}
cd "$r2_source"
scripts/hyle-unix.sh --print-toolchain
uname -a
r2_args=()
if [ "$r2_platform" != linux ]; then r2_args+=(-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4); fi
r2_build="$r2_root/factors-4e9f74a0-$r2_sanitizer"
r2_log_run configure scripts/hyle-unix.sh cmake -S "$r2_source" -B "$r2_build" -G Ninja \
 -DCMAKE_BUILD_TYPE=Release -DHYLE_DEV_FACTORS=mem,compute,compute_backend_cpu,compute_provider_native,graph \
 -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF -DHYLE_TEST_INSTRUMENTATION=OFF \
 -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_WERROR=ON \
 "-DHYLE_SANITIZER=$r2_sanitizer" "${r2_args[@]}"
r2_log_run build scripts/hyle-unix.sh cmake --build "$r2_build" --parallel 2 \
 --target hyle_mem_tests hyle_compute_tests hyle_compute_backend_cpu_tests hyle_compute_provider_native_tests hyle_graph_tests
r2_test_args=()
if [ "$r2_sanitizer" != off ]; then r2_test_args+=(-LE headers); fi
r2_ctest() {
 if [ "$r2_sanitizer" = tsan ]; then setarch -R ctest "$@"; else ctest "$@"; fi
}
r2_log_run tests r2_ctest --test-dir "$r2_build" --output-on-failure --no-tests=error --timeout 120 \
 -L '^(mem|compute|compute_backend_cpu|compute_provider_native|graph)$' "${r2_test_args[@]}"
if [ "$r2_sanitizer" = off ]; then
 r2_consumer="$r2_root/owned-source-4e9f74a0"
 r2_log_run owning-source-configure scripts/hyle-unix.sh cmake -S "$r2_root/owned-consumer" \
  -B "$r2_consumer" -G Ninja -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_POSITION_INDEPENDENT_CODE=ON "-DHYLE_SOURCE_DIR=$r2_source" "${r2_args[@]}"
 r2_log_run owning-source-build scripts/hyle-unix.sh cmake --build "$r2_consumer" --parallel 2
 r2_log_run owning-source-tests ctest --test-dir "$r2_consumer" --output-on-failure --no-tests=error
fi
printf 'PASS all declared %s / %s R2 checks\n' "$r2_platform" "$r2_sanitizer"

