$ErrorActionPreference = 'Stop'
$r2Repo = 'C:\public\project-hyle\hyle'
$r2Scratch = 'C:\hyle-scratch\r2-q4-20260916'
Set-Location -LiteralPath $r2Repo
$r2Vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$r2Vs = & $r2Vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $r2Vs) { throw 'MSVC installation missing' }
$r2Dev = Join-Path $r2Vs 'Common7\Tools\VsDevCmd.bat'
$r2Command = 'call "' + $r2Dev + '" -arch=x64 >nul && set'
$r2Environment = & $env:ComSpec /d /s /c $r2Command
if ($LASTEXITCODE -ne 0) { throw 'MSVC initialization failed' }
foreach ($r2Line in $r2Environment) {
    $r2Split = $r2Line.IndexOf('=')
    if ($r2Split -le 0) { continue }
    $r2Name = $r2Line.Substring(0, $r2Split)
    $r2Value = $r2Line.Substring($r2Split + 1)
    if ($r2Name -ieq 'Path' -and $r2Value -notlike "*$r2Vs\VC\Tools\MSVC\*") { continue }
    [Environment]::SetEnvironmentVariable($r2Name, $r2Value, 'Process')
}
$r2Consumer = Join-Path $r2Scratch 'owned-consumer'
$r2Candidate = Join-Path $r2Scratch 'windows-validation'
$r2SdkRoot = Join-Path $r2Scratch 'selector-ninja/6b8490e302b0e35298d2/delivery-graph/selected-graph'
foreach ($r2Mode in @('source', 'shared', 'static')) {
    $r2Build = Join-Path $r2Scratch "owning-$r2Mode-4e9f74a0"
    $r2Args = @('-S', $r2Consumer, '-B', $r2Build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_POSITION_INDEPENDENT_CODE=ON')
    if ($r2Mode -eq 'source') {
        $r2Args += "-DHYLE_SOURCE_DIR=$r2Candidate"
    } else {
        $r2Sdk = Join-Path $r2SdkRoot "$r2Mode-sdk-relocated"
        if (-not (Test-Path -LiteralPath $r2Sdk)) { throw "Missing selected SDK: $r2Sdk" }
        $r2Args += "-DCMAKE_PREFIX_PATH=$r2Sdk"
    }
    cmake @r2Args *> "$r2Scratch/owning-$r2Mode-configure.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$r2Scratch/owning-$r2Mode-configure.log" -Tail 35; exit $LASTEXITCODE }
    cmake --build $r2Build --parallel 2 *> "$r2Scratch/owning-$r2Mode-build.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$r2Scratch/owning-$r2Mode-build.log" -Tail 35; exit $LASTEXITCODE }
    ctest --test-dir $r2Build --output-on-failure --no-tests=error *> "$r2Scratch/owning-$r2Mode-tests.log"
    Get-Content "$r2Scratch/owning-$r2Mode-tests.log" -Tail 10
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
