"""Freeze the shared readback migration and one actual tiny K2 journey."""
from pathlib import Path
import hashlib
import json
import zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
OUT = R / 'docs/evidence/correctness/mtp-shared-draft-readback-2026-10-24'

def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def main():
    summary = load(D / 'summary.json')
    for name in ['cpu-syntax', 'run']:
        process = load(D / name / 'process.json')
        if process['exit'] != 0 or process.get('timeout'):
            raise RuntimeError('Require successful terminal consumer checks')
    report = json.loads((D / 'run/stdout.log').read_text(encoding='utf8').strip())
    if report != summary['run']['report'] or report['status'] != 'PASS_TINY_DRAFT_READBACK':
        raise RuntimeError('Actual tiny consumer report differs')
    if (report['head_true_calls'], report['head_false_calls'], report['cursor']) != (2, 1, 6):
        raise RuntimeError('Actual recursive proposal, repair and cursor were not observed')
    sources = [R / name for name in (
        'engine/models/qwen35/main.cc', 'engine/models/qwen35/mtp_graph.h',
        'engine/models/qwen35/mtp_schedule.h', 'engine/inference/readback.h',
        'engine/inference/backend.h', 'engine/inference/prepared_output.h',
        'engine/inference/execution_resources.h', 'engine/inference/sampling_graph.h')]
    records = [p for p in D.rglob('*') if p.is_file() and p.suffix in {'.json', '.log', '.py', '.cc'}]
    with zipfile.ZipFile(OUT.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(sources + records)):
            z.write(p, p.relative_to(R).as_posix())
    with zipfile.ZipFile(OUT.with_suffix('.zip')) as z:
        if z.testzip() is not None: raise RuntimeError('Evidence archive CRC failed')
        entries = len(z.namelist())
    result = dict(date='2026-10-24', status='PASS shared scalar readback and actual tiny stochastic K2',
        sources=[identity(p) for p in sources], archive=identity(OUT.with_suffix('.zip')),
        archive_entries=entries,
        previous=identity(R / 'docs/evidence/correctness/mtp-shared-backend-domains-2026-10-24.json'),
        changes=['Move finite caller/native readback into model-independent engine/inference/readback.h',
            'Use original Buffer and GraphOutput contracts, with Status/Result propagation',
            'Migrate DraftProgram ID, valid predicate and maximum probability',
            'Reuse the same helper in prefix sampling and sampling frontier'],
        run=report, untrained_fixture=dict(physical_roles=28, bytes=206336,
            geometry='H64, FFN128, V64, one attention layer plus one NextN',
            committed_target_rows=1, consumed_drafts=0,
            interpretation='Both proposals were actually generated; the verifier rejected the first, preserving mandatory-current state and publishing residual pending42.'),
        checks=dict(cpu_strict_syntax=load(D / 'cpu-syntax/process.json'),
            tiny_vulkan_actual_journey=load(D / 'run/process.json'),
            independent_review='All optional/head=false/m0 paths preserve preparation, binding and read conditions; failed readback cannot publish head or RNG'),
        limits=['Untrained finite functional fixture; not model quality, throughput or memory-comparison evidence',
            'Positive threshold reads actual probability; this fixture does not force threshold clipping',
            'No new greedy, backend or quantization matrix was run',
            'Persistent q/hidden/page ownership and original retirement remain unchanged',
            'Remaining main-phase outputs and runtime backend selection are still pending'],
        full_trained_model_runs=0, untrained_tiny_model_journeys=1, SDK_builds=0,
        HTTP_requests=0, model_download_bytes=0)
    with OUT.with_suffix('.json').open('x', encoding='utf8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False); f.write('\n')
    print(json.dumps(dict(evidence=identity(OUT.with_suffix('.json')),
        archive=result['archive'], entries=entries)))

if __name__ == '__main__': main()
