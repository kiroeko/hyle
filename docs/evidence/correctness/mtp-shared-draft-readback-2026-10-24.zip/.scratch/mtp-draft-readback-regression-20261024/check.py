from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[1]
spec = importlib.util.spec_from_file_location('retained_extraction_tools', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)

def freeze():
    source = D / 'source'; source.mkdir(exist_ok=False)
    main = R / 'engine/models/qwen35/main.cc'
    readback = R / 'engine/inference/readback.h'
    assert b.pin(main)['sha256'] == '37e848baedf1bf8e86b840433e4d2943455d3742e08707ec1b759c86c98eef1c'
    assert b.pin(readback)['sha256'] == '87c003172827bced25ac85132b285e3356c25dbea68ce521f444937d8a527861'
    paths = [main, *(R / 'engine/models/qwen35').glob('*.h'), *(R / 'engine/inference').glob('*.h')]
    pins = []
    for original in paths:
        target = source / original.relative_to(R)
        target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(original.read_bytes())
        pins.append({'canonical': b.pin(original), 'frozen': b.pin(target)})
    (source / 'tiny.cc').write_bytes((D / 'tiny.cc').read_bytes())
    b.save(D / 'source-pins.json', pins)

if __name__ == '__main__':
    if sys.argv[1] == 'syntax':
        b.compile(R / 'engine/models/qwen35/main.cc', D / 'cpu-syntax', syntax=True)
    elif sys.argv[1] == 'run':
        freeze()
        env = b.compile(D / 'source/tiny.cc', D / 'compile', vulkan=True)
        image = b.link(D / 'compile/unit.obj', D / 'link', env, vulkan=True)
        env.update({k: v for k, v in b.read(b.VK / 'runtime.json').items() if isinstance(v, str)})
        b.execute([str(image), str(D / 'run')], D / 'run', env, 60)
    else:
        raise SystemExit('syntax | run')
