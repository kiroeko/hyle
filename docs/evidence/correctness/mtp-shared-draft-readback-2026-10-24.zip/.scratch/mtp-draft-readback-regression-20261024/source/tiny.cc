// One untrained, finite Model journey. Exercises product NextN/Graph/state;
// never a trained-model quality or performance test.
#include "engine/models/qwen35/main.cc"

namespace q = qwen35;
void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}
q::ModelGeometry geometry() {
  q::ModelGeometry shape;
  shape.hidden = 64; shape.intermediate = 128; shape.vocabulary = 64;
  shape.query_heads = shape.kv_heads = 1;
  shape.key_depth = shape.value_depth = shape.rotary = 64;
  shape.gdn_key_heads = shape.gdn_value_heads = 1;
  shape.gdn_key_depth = shape.gdn_value_depth = 64;
  shape.conv_kernel = 4; shape.context_limit = 16;
  shape.rope_theta = 10000; shape.epsilon = 1.e-6F;
  shape.tied_head = true; shape.layers = "A"; shape.mtp_layers = 1;
  shape.validate(); return shape;
}
std::pair<std::filesystem::path, std::size_t> weights(
    const std::filesystem::path &folder, const q::ModelGeometry &shape) {
  std::filesystem::create_directories(folder);
  const auto payload_path = folder / "untrained-bf16.bin";
  std::ofstream payload(payload_path, std::ios::binary), manifest(folder / "weights.tsv");
  if (!payload || !manifest) throw std::runtime_error("cannot create finite NextN fixture");
  manifest << "HYLE_QWEN_ROLE_FILES_V2\n" << std::string(64, '3') << '\n'
      << "geometry 64 128 64 1 1 64 64 64 1 1 64 64 4 16 10000 1e-6 1 1 grouped \"A\"\n";
  std::size_t offset = 0, role_index = 0;
  for (const auto &[name, parameter] : q::prepared::parameter_inventory(true, shape)) {
    std::size_t elements = 1;
    for (const auto extent : parameter.shape) elements *= static_cast<std::size_t>(extent);
    std::vector<std::uint16_t> values(elements);
    for (std::size_t n = 0; n < elements; ++n) {
      const float value = parameter.shape.size() == 1 ? 0.F
          : .03F * std::sin(float(n + role_index * 17) * .13F);
      auto bits = std::bit_cast<std::uint32_t>(value);
      bits += 0x7fffU + ((bits >> 16) & 1U);
      values[n] = static_cast<std::uint16_t>(bits >> 16);
    }
    payload.write(reinterpret_cast<const char *>(values.data()),
        static_cast<std::streamsize>(values.size() * sizeof(std::uint16_t)));
    manifest << name << " BF16 " << parameter.shape.size();
    for (const auto extent : parameter.shape) manifest << ' ' << extent;
    manifest << ' ' << std::quoted(payload_path.generic_string()) << ' ' << offset
        << ' ' << values.size() * sizeof(std::uint16_t) << '\n';
    offset += values.size() * sizeof(std::uint16_t); ++role_index;
  }
  require(offset < 256 * 1024, "tiny fixture accidentally grew beyond its declared bound");
  return {folder / "weights.tsv", offset};
}
int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("tiny-draft-readback PRIVATE_WORK_DIR");
    const auto shape = geometry();
    const auto fixture = weights(std::filesystem::path(argv[1]) / "fixture", shape);
    const auto plan = q::cache::plan(shape, 16, 2, 3,
        q::recurrent_bytes(q::state_schema_for(shape, 16), shape), 1, 3, true, true);
    q::Model model(fixture.first, shape, 16, plan, {}, false, q::ReplayPolicy::kCommands,
        16 * 1024 * 1024, {.enabled = true, .policy = {1.F, 8, .9F}, .seed = 123});
    model.max_drafts = 2; model.min_draft_probability = 1.e-4F;
    const std::array prefill{std::size_t{2}}, verifier{std::size_t{3}};
    model.prepare_family(prefill, false, 1, q::GraphRole::kMtpPrefill);
    model.plan_replay_uses(2, 1, 1, q::GraphRole::kMtpPrefill);
    model.prepare_family(verifier, false, 1, q::GraphRole::kVerify);
    model.plan_replay_uses(3, 1, 1, q::GraphRole::kVerify);
    for (std::size_t rows = 1; rows <= 3; ++rows) model.prepare_draft_program(rows, false);
    model.prepare_draft_program(1, true); model.prepare_draft_program(2, true);
    model.prepare_prefix_sampling(2);
    auto session = model.create_session(prefill, {}, q::GraphRole::kMtpPrefill);
    const std::array<std::int32_t, 2> prompt{1, 2};
    model.prepare_evaluation(*session, prompt, nullptr, q::GraphRole::kMtpPrefill);
    model.submit_evaluation(*session);
    model.finish_evaluation(*session, "seed", {}, false);
    auto base = session->head;
    require(base->sampling == q::cache::SamplingCursor{123, 0, 1}, "seed cursor differs");
    const auto pending = base->next_id;
    std::vector<q::c::ReadLease> log_q;
    auto ids = model.propose_recursive(*session, 2, {}, &log_q);
    // Maximum probability after topK8 is >=1/8. The small positive threshold
    // therefore exercises actual probability readback without forcing a stop.
    require(ids.size() == 3 && log_q.size() == 2 && ids[0] == pending,
        "actual two-proposal categorical/threshold journey was not reached");
    require(model.draft_program_graph_calls == 2, "unexpected proposal program calls");
    auto &program = *model.draft_programs.at({1, true});
    require(program.id_value.facts.description.data_type() == q::Type::kInt32,
        "actual id readback description differs");
    require(program.valid_value.facts.description.data_type() == q::host_predicate_type &&
        program.probability_value.facts.description.data_type() == q::Type::kFloat32,
        "actual predicate/probability readback descriptions differ");
    const bool id_caller = program.id_value.facts.caller_owned();
    const bool valid_caller = program.valid_value.facts.caller_owned();
    const bool probability_caller = program.probability_value.facts.caller_owned();
    const std::array inputs{q::EvaluationRequest{session, ids}};
    const std::array outputs{q::EvaluationOutput{.session = session, .name = "verify", .trace_states = false}};
    const std::array selections{q::MtpGenerationSelection{session, pending, 3, log_q, 2}};
    std::array<q::MtpRoundResult, 1> results;
    model.prepare_evaluations(inputs, nullptr, q::GraphRole::kVerify); model.submit_evaluations();
    model.finish_recursive_mtp(selections, {}, outputs, results);
    const auto &result = results[0];
    require(result.proposal_count == 2 && result.verified_rows == 3 && result.processed_target >= 1 &&
        result.processed_target <= 3, "verifier selected an invalid complete prefix");
    require(model.draft_program_graph_calls == 3 && model.prefix_decision_graph_calls == 1,
        "real head=false prefix repair or stochastic decision did not execute");
    require(session->head != base && session->head->sampling.draw == 6 && base->sampling.draw == 1,
        "complete state/pending/RNG did not publish atomically");
    require(session->head->length == 2 + result.processed_target &&
        session->head->draft->frontier + session->head->draft->lag == session->head->length,
        "target and repaired NextN frontiers differ");
    model.validate_mtp_snapshot(*session->head);
    std::cout << "{\"status\":\"PASS_TINY_DRAFT_READBACK\",\"backend\":\"" << q::Backend::name()
        << "\",\"fixture_bytes\":" << fixture.second << ",\"head_true_calls\":2,\"head_false_calls\":1"
        << ",\"id_caller_owned\":" << id_caller << ",\"valid_caller_owned\":" << valid_caller
        << ",\"probability_caller_owned\":" << probability_caller << ",\"proposals\":[" << ids[1] << ',' << ids[2]
        << "],\"consumed\":" << result.processed_target << ",\"pending\":" << session->head->next_id
        << ",\"cursor\":" << session->head->sampling.draw << ",\"draft_lag\":" << session->head->draft->lag
        << model.cache_report() << ",\"quality_claim\":false,\"performance_claim\":false}\n";
    log_q.clear(); base.reset();
    q::check(session->stop()); q::check(session->drain());
    require(q::take(session->try_retire()), "tiny original session did not retire"); session.reset();
    require(!model.active_step && !model.carrier_borrowed && model.snapshot_versions.live == 0,
        "tiny journey retained an uncommitted carrier or model state");
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "tiny draft readback: " << error.what() << '\n'; return 1;
  }
}
