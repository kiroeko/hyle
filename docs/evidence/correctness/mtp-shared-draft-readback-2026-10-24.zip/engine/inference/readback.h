#pragma once

#include <cstddef>
#include <cstdint>
#include <span>

#include "backend.h"
#include "prepared_output.h"

namespace hyle::inference {

// Prepare only the caller-owned backing. Native-owned results are obtained
// from the original Invocation after successful completion, never cached.
// The Backend resource owners must outlive this buffer and its native uses.
struct PreparedReadback final {
  PreparedOutputFacts facts;

  static Result<PreparedReadback> prepare(const graph::CompiledGraph &compiled,
                                        graph::ValueId value,
                                        const Backend &backend) noexcept {
    PreparedReadback result;
    HYLE_ASSIGN_OR_RETURN(result.facts, prepare_output(compiled, value));
    HYLE_ASSIGN_OR_RETURN(auto resource, backend.resource_for(result.facts.storage));
    if (result.facts.caller_owned()) {
      HYLE_ASSIGN_OR_RETURN(auto bytes, result.facts.description.required_bytes());
      HYLE_ASSIGN_OR_RETURN(result.caller_, mem::Buffer::create(resource, bytes, 256));
    }
    return result;
  }

  Status bind(graph::Invocation &run) noexcept {
    if (!facts.caller_owned()) return Status::Ok();
    HYLE_ASSIGN_OR_RETURN(auto tensor,
                         compute::TensorView::create(facts.description, caller_.view()));
    return run.bind(facts.value, tensor);
  }

  // The caller has already waited successfully and has exclusive access to
  // these results. A temporary native output/lease remains alive for the
  // complete synchronous read; it does not change the output's ownership.
  Status read(const Backend &backend, graph::Invocation &run,
              std::span<std::byte> bytes) const noexcept {
    if (facts.caller_owned()) return backend.read(caller_.view(), bytes);
    HYLE_ASSIGN_OR_RETURN(auto output, run.result(facts.value));
    if (auto tensor = output.tensor(); tensor)
      return backend.read(tensor->storage(), bytes);
    HYLE_ASSIGN_OR_RETURN(auto owner, output.storage_lease());
    HYLE_ASSIGN_OR_RETURN(auto storage, owner.view());
    return backend.read(storage, bytes);
  }

  Result<std::uint8_t> predicate(const Backend &backend,
                                 graph::Invocation &run) const noexcept {
    HYLE_ASSIGN_OR_RETURN(auto bytes, facts.description.required_bytes());
    if (facts.description.data_type() == compute::DataType::kBool && bytes == 1) {
      std::uint8_t value = 0;
      HYLE_RETURN_IF_ERROR(read(backend, run, std::as_writable_bytes(std::span(&value, 1))));
      if (value > 1)
        return std::unexpected(Status::InvalidArgument("host predicate is not exact Bool zero or one"));
      return value;
    }
    if (facts.description.data_type() == compute::DataType::kFloat32 && bytes == sizeof(float)) {
      float value = 0;
      HYLE_RETURN_IF_ERROR(read(backend, run, std::as_writable_bytes(std::span(&value, 1))));
      if (value != 0 && value != 1)
        return std::unexpected(Status::InvalidArgument("host predicate is not exact F32 zero or one"));
      return static_cast<std::uint8_t>(value == 1);
    }
    return std::unexpected(Status::InvalidArgument("prepared predicate output is not a Bool or F32 scalar"));
  }

private:
  mem::Buffer caller_;
};

} // namespace hyle::inference
