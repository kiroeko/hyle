import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

repo = Path.cwd()
fixture = repo / '.scratch/validation/cpu-onednn-hybrid-retirement'
evidence = repo / 'evidence/correctness/cpu-onednn-hybrid-ffn'
manifest = json.loads((fixture / 'manifest.json').read_text())
for name, digest in manifest['files'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest, name


def tests(path):
    root = ET.parse(path).getroot()
    cases = list(root.iter('testcase'))
    assert not any(case.find('failure') is not None or case.find('error') is not None for case in cases)
    skipped = [case.attrib.get('classname', '') + '.' + case.attrib['name']
               for case in cases if case.find('skipped') is not None]
    return dict(registered=len(cases), passed=len(cases) - len(skipped), skipped=skipped)


required = {'configure', 'batch-build', 'provider-tests', 'public-header',
            'affected-graph-tests',
            *[stage + '-' + name for stage in ('shared', 'static')
              for name in ('producer-configure', 'producer-build', 'source-ordinary',
                           'install', 'consumer-configure', 'consumer-build', 'installed-ordinary')]}
result = dict(candidate=manifest['candidate'], fixture_commit=manifest['fixture_commit'],
              scope='NX1-3; retire invalid hybrid FFN, keep original Norm/MatMul/SIMD',
              performance='P0; no self operator performance comparison', platforms={})
for platform in ('windows', 'linux'):
    folder = fixture / platform
    records = json.loads((folder / 'receipt.json').read_text())
    latest = {row['name']: row for row in records}
    assert not (required - latest.keys()), (platform, required - latest.keys())
    assert all(latest[name]['returncode'] == 0 for name in required), platform
    identity = json.loads((folder / 'source-identity.json').read_text())
    assert identity['candidate'] == manifest['candidate'] and identity['checked'] == len(manifest['files'])
    result['platforms'][platform] = dict(commands=len(records),
        actual_validation_commits=sorted({r['candidate'] for r in records}),
        tests={name: tests(folder / (name + '.xml')) for name in ('provider', 'graph', 'header')},
        source_identity=identity, latest_commands_passed=sorted(required))
    cleanup = json.loads((folder / 'cleanup.json').read_text(encoding='utf-8-sig'))
    assert all(row['removed'] for row in cleanup)
    result['platforms'][platform]['cleanup'] = cleanup

loc = json.loads((fixture / 'loc.json').read_text(encoding='utf-8-sig'))
metric = next(row for row in loc['metrics'] if row['id'] == 'module')
result['loc'] = dict(code=metric['code'], files=metric['files'], commit=loc['repository']['commit'])
files = [(path, 'qualification/' + path.relative_to(fixture).as_posix())
         for path in fixture.rglob('*') if path.is_file()]
for name in ('cpu-nx-windows.py', 'cpu-nx-linux.py', 'cleanup-cpu-nx-windows.ps1',
             'cleanup-cpu-nx-linux.py', 'cpu-ggml-wsl-launch.py', 'collect-cpu-nx-evidence.py'):
    files.append((repo / '.scratch' / name, 'drivers/' + name))
for name in ('src/graph_provider_onednn/onednn_region_provider.cc',
             'tests/graph_provider_onednn/onednn_region_provider_test.cc',
             'tests/graph_route_cpu/hybrid_ffn_numeric_test.cc'):
    files.append((repo / name, 'source/' + name))
archive = evidence / 'qualification.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for path, name in sorted(files, key=lambda row: row[1]):
        z.write(path, name)
result['artifact'] = dict(file='qualification.zip', entries=len(files), bytes=archive.stat().st_size,
    sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(evidence / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('candidate', 'loc', 'artifact')}))
