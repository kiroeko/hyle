#include <cstdio>
#include <cstdlib>

#include <array>
#include <cmath>
#include <limits>
#include <span>
#include <utility>

#include "hyle/compute/cpu.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/compute/providers/native.h"
#include "hyle/compute/providers/onednn.h"
#include "hyle/graph/cpu.h"

namespace {
[[noreturn]] void fail(const char *expression) {
  std::fprintf(stderr, "FAIL: %s\n", expression);
  std::exit(2);
}
#define ASSERT_TRUE(x)                                                         \
  do {                                                                         \
    if (!(x))                                                                  \
      fail(#x);                                                                \
  } while (false)
#define EXPECT_TRUE(x) ASSERT_TRUE(x)
#define EXPECT_EQ(x, y) ASSERT_TRUE((x) == (y))
#define EXPECT_NEAR(x, y, e) ASSERT_TRUE(std::abs((x) - (y)) <= (e))

namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;

c::TensorDesc matrix(std::int64_t rows, std::int64_t columns) {
  return c::TensorDesc::dense(c::DataType::kFloat32, std::array{rows, columns})
      .value();
}
m::Buffer buffer(const c::TensorDesc &desc) {
  return m::Buffer::create(m::system_resource(), desc.required_bytes().value(),
                           64)
      .value();
}

void graph_ffn() {

  for (float x : {-80.F, -90.F, -100.F}) {
    for (float value : {1e38F, (std::numeric_limits<float>::infinity)()}) {
      const auto input_desc = matrix(1, 8), weight_desc = matrix(8, 8);
      auto gate_weights = buffer(weight_desc), up_weights = buffer(weight_desc);
      auto down_weights = buffer(weight_desc);
      std::array<float, 64> gate{}, up{}, down{};
      for (std::size_t i = 0; i < 8; ++i) {
        gate[i] = x;
        up[i] = value;
      }
      down.fill(0.125F);
      ASSERT_TRUE(
          gate_weights.view().write(std::as_bytes(std::span(gate))).ok());
      ASSERT_TRUE(up_weights.view().write(std::as_bytes(std::span(up))).ok());
      ASSERT_TRUE(
          down_weights.view().write(std::as_bytes(std::span(down))).ok());
      auto builder = g::GraphBuilder::create().value();
      auto input = builder.input(input_desc).value();
      auto wg = builder.constant(weight_desc).value();
      auto wu = builder.constant(weight_desc).value();
      auto wd = builder.constant(weight_desc).value();
      const c::MatMul mm{.accumulation_type = c::DataType::kFloat32};
      auto score = builder.add(mm, input, wg).value();
      auto values = builder.add(mm, input, wu).value();
      auto gated =
          builder
              .add(c::GatedActivation{.inputs = c::GatedInputKind::kSeparate},
                   score, values)
              .value();
      auto output = builder.add(mm, gated, wd).value();
      ASSERT_TRUE(builder.publish(output).ok());
      auto graph = std::move(builder).finish().value();
      auto context = g::cpu::create_context().value();
      const std::array constants{
          g::ConstantBinding{
              wg, c::ConstTensorView::create(weight_desc, gate_weights.view())
                      .value()},
          g::ConstantBinding{
              wu, c::ConstTensorView::create(weight_desc, up_weights.view())
                      .value()},
          g::ConstantBinding{
              wd, c::ConstTensorView::create(weight_desc, down_weights.view())
                      .value()}};
      auto result = g::compile(graph, context, {.constants = constants});
      ASSERT_TRUE(result);
      auto compiled = std::move(*result);
      bool qualified_gate = false;
      for (std::size_t i = 0; i < compiled.report.step_count(); ++i) {
        const auto step = compiled.report.step(i).value();
        const auto id = step.provider.id;
        EXPECT_TRUE(id == c::aten_cpu::kProviderId ||
                    id == c::onednn::kProviderId ||
                    id == c::ggml_cpu::kProviderId);
        qualified_gate |= id == c::aten_cpu::kProviderId;
      }
      ASSERT_TRUE(qualified_gate);
      auto queue = context.create_queue().value();
      std::array invocations{compiled.executable.create_invocation().value(),
                             compiled.executable.create_invocation().value()};
      std::array inputs{buffer(input_desc), buffer(input_desc)};
      std::array outputs{buffer(input_desc), buffer(input_desc)};
      const std::array lanes{
          g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &queue}};
      for (std::size_t slot = 0; slot < 2; ++slot) {
        ASSERT_TRUE(invocations[slot]
                        .bind(input, c::ConstTensorView::create(
                                         input_desc, inputs[slot].view())
                                         .value())
                        .ok());
        ASSERT_TRUE(invocations[slot]
                        .bind(output, c::TensorView::create(
                                          input_desc, outputs[slot].view())
                                          .value())
                        .ok());
        ASSERT_TRUE(invocations[slot].prepare_replay(lanes).ok());
      }
      std::array<std::array<float, 8>, 2> retained{};
      for (int replay = 0; replay < 4; ++replay) {
        const auto slot = std::size_t(replay % 2);
        const float scale = replay < 2 ? 1.F : 0.5F;
        std::array<float, 8> activation{};
        activation[0] = scale;
        ASSERT_TRUE(inputs[slot]
                        .view()
                        .write(std::as_bytes(std::span(activation)))
                        .ok());
        auto done = invocations[slot].submit(queue);
        ASSERT_TRUE(done);
        ASSERT_TRUE(done->wait().ok());
        std::array<float, 8> actual;
        ASSERT_TRUE(outputs[slot]
                        .view()
                        .read(std::as_writable_bytes(std::span(actual)))
                        .ok());
        const auto gate_value = double(x * scale);
        const double e = std::exp(gate_value);
        const float expected =
            float(gate_value * e / (1 + e)) * (value * scale);
        for (float item : actual) {
          if (std::isinf(expected)) {
            EXPECT_EQ(item, expected);
          } else {
            EXPECT_NEAR(item, expected, 1e-8F + 1e-5F * std::abs(expected));
          }
        }
        retained[slot] = actual;
        if (replay != 0) {
          std::array<float, 8> other;
          ASSERT_TRUE(outputs[1 - slot]
                          .view()
                          .read(std::as_writable_bytes(std::span(other)))
                          .ok());
          EXPECT_EQ(other, retained[1 - slot]);
        }
      }
    }
  }
}

void direct_ffn() {
  const auto d = matrix(1, 8), w = matrix(8, 8);
  auto context = c::cpu::create_context().value();
  auto queue = context.create_queue().value();
  auto mm =
      c::prepare(context, c::MatMul{.accumulation_type = c::DataType::kFloat32},
                 d, w)
          .value();
  auto gated =
      c::prepare(context,
                 c::GatedActivation{.inputs = c::GatedInputKind::kSeparate}, d,
                 d)
          .value();
  ASSERT_TRUE(gated.provider().id == c::aten_cpu::kProviderId);
  const auto requirement = mm.workspace_requirement();
  auto make_workspace = [&] {
    return requirement.size == 0
               ? m::Buffer{}
               : m::Buffer::create(m::system_resource(), requirement.size,
                                   requirement.alignment)
                     .value();
  };
  std::array workspaces{make_workspace(), make_workspace(), make_workspace()};
  std::array matmul{mm.create_invocation(workspaces[0].view()).value(),
                    mm.create_invocation(workspaces[1].view()).value(),
                    mm.create_invocation(workspaces[2].view()).value()};
  auto gate_call = gated.create_invocation().value();
  auto input = buffer(d), wg = buffer(w), wu = buffer(w), wd = buffer(w),
       score = buffer(d), value = buffer(d), activation = buffer(d),
       output = buffer(d);
  for (float x : {-80.F, -90.F, -100.F}) {
    std::array<float, 64> gs{}, us{}, ds{};
    for (std::size_t i = 0; i < 8; ++i) {
      gs[i] = x;
      us[i] = 1e38F;
    }
    ds.fill(.125F);
    ASSERT_TRUE(wg.view().write(std::as_bytes(std::span(gs))).ok());
    ASSERT_TRUE(wu.view().write(std::as_bytes(std::span(us))).ok());
    ASSERT_TRUE(wd.view().write(std::as_bytes(std::span(ds))).ok());
    for (float scale : {1.F, .5F}) {
      std::array<float, 8> a{};
      a[0] = scale;
      ASSERT_TRUE(input.view().write(std::as_bytes(std::span(a))).ok());
      auto cv = [](const c::TensorDesc &desc, m::Buffer &b) {
        return c::ConstTensorView::create(desc, b.view()).value();
      };
      auto ov = [](const c::TensorDesc &desc, m::Buffer &b) {
        return c::TensorView::create(desc, b.view()).value();
      };
      ASSERT_TRUE(matmul[0]
                      .submit(queue, cv(d, input), cv(w, wg), ov(d, score))
                      .value()
                      .wait()
                      .ok());
      ASSERT_TRUE(matmul[1]
                      .submit(queue, cv(d, input), cv(w, wu), ov(d, value))
                      .value()
                      .wait()
                      .ok());
      ASSERT_TRUE(
          gate_call.submit(queue, cv(d, score), cv(d, value), ov(d, activation))
              .value()
              .wait()
              .ok());
      ASSERT_TRUE(
          matmul[2]
              .submit(queue, cv(d, activation), cv(w, wd), ov(d, output))
              .value()
              .wait()
              .ok());
      std::array<float, 8> actual;
      ASSERT_TRUE(
          output.view().read(std::as_writable_bytes(std::span(actual))).ok());
      double g = double(x * scale), e = std::exp(g);
      float expected = float(g * e / (1 + e)) * (1e38F * scale);
      for (float item : actual)
        EXPECT_NEAR(item, expected, 1e-8F + 1e-5F * std::abs(expected));
    }
  }
  ASSERT_TRUE(context.close().ok());
}
} // namespace
int main() {
  direct_ffn();
  graph_ffn();
  std::puts("ordinary CPU mature FFN Direct/Graph, six tail/Inf programs, "
            "changed-input and independent slots PASS");
}
