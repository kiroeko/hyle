from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[3]
route,mode,attempt=sys.argv[1:4];tag=f'{route}-{mode}-{attempt}'
OUT=ROOT/'.scratch/inference-gaps/g04-g05/sdk';OUT.mkdir(exist_ok=True)
archive=OUT/f'source-{tag}.zip';assert not archive.exists()
(OUT/f'runner-{tag}.py').write_bytes((OUT.parent/'encoded_sdk.py').read_bytes())
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
    for name in sorted(set(paths)):
        if name.startswith(('evidence/','.scratch/','.git')):continue
        file=ROOT/name
        if not file.is_file():continue
        raw=file.read_bytes();inputs.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest()});package.writestr(name,raw)
    package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
if route=='cuda':
    command=['wsl','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g04-g05/encoded_sdk.py',route,mode,attempt,*sys.argv[4:]]
    raise SystemExit(subprocess.run(command).returncode)
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g04-g05-encoded-sdk'
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
subprocess.run(['scp',str(archive),str(OUT.parent/'encoded_sdk.py'),host+':'+remote+'/'],check=True)
code=subprocess.run(['ssh','-o','BatchMode=yes',host,'python3',remote+'/encoded_sdk.py',route,mode,attempt,*sys.argv[4:]]).returncode
for pattern in [f'result-{tag}.json',f'job-{tag}.json',f'*-{tag}.log',f'*-{tag}.xml',f'shipping-{tag}.json',f'consumer-commands-{tag}.json',f'consumer-project-{tag}.cmake',f'public-inputs-{tag}.json',f'artifacts-{tag}.json']:
    subprocess.run(['scp',host+':'+remote+'/'+pattern,str(OUT)],check=False)
raise SystemExit(code)
