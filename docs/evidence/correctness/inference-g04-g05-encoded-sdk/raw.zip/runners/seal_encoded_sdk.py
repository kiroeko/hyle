from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'.scratch/inference-gaps/g04-g05';RUN=BASE/'sdk'
OUT=ROOT/'evidence/correctness/inference-g04-g05-encoded-sdk'
records=[]
for file in sorted(RUN.glob('result-*.json')):
    data=json.loads(file.read_text());assert data['state'].startswith('TERMINAL_'),file
    records.append((file.stem.removeprefix('result-'),data))
latest={}
for tag,record in records:
    key=record['route'],record['mode']
    if key not in latest or record['attempt']>latest[key][1]['attempt']:latest[key]=tag,record
expected={(route,mode) for route in ('apple','vulkan','cuda') for mode in ('static','shared')}
assert set(latest)==expected
air_profiles=json.loads((RUN/'air-shipping-profile-cache.json').read_text())
assert air_profiles['verdict']=='PASS_AIR_FOUR_SHIPPING_PROFILES' and len(air_profiles['profiles'])==4
manifest=records[0][1]['inputs']
for row in manifest:
    assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
for tag,record in records:assert record['inputs']==manifest,tag
matrix=[]
for (route,mode),(tag,record) in sorted(latest.items()):
    assert record['state']=='TERMINAL_PASS',tag
    commands=json.loads((RUN/f'consumer-commands-{tag}.json').read_text())
    assert len(commands)==16 and all(record['producer'] not in c['command'] and '/source-c8874688/' not in c['command'] and '/source-7a7b4c3b/' not in c['command'] for c in commands)
    shipping=json.loads((RUN/f'shipping-{tag}.json').read_text())
    assert shipping and all('HYLE_TESTING' not in c['command'] and '-fsanitize=' not in c['command'] for c in shipping)
    inputs=json.loads((RUN/f'public-inputs-{tag}.json').read_text())
    assert len(inputs['headers'])==12
    counts={}
    for stage,count in [('cpu_math',13),('native_math',10 if route=='cuda' else 11),('cpu',3),('native',4 if route=='apple' else 3)]:
        xml=ET.parse(RUN/f'{stage}-{tag}.xml').getroot()
        assert int(xml.attrib['tests'])>=count and xml.attrib['failures']=='0' and xml.attrib.get('disabled','0')=='0' and xml.attrib.get('errors','0')=='0',(tag,stage,xml.attrib)
        if stage=='cpu_math':
            names=[suite.attrib['name']+'.'+case.attrib['name'] for suite in xml.findall('testsuite') for case in suite.findall('testcase') if suite.attrib['name'] in ('GgmlCpuCacheEncode','GgmlCpuBoxed')]
            assert len(names)==13 and all(case.find('skipped') is None for suite in xml.findall('testsuite') for case in suite.findall('testcase'))
        counts[stage]=int(xml.attrib['tests'])
    if route=='apple':assert all(any(s['stage']==name and s['exit_code']==0 for s in record['stages']) for name in ('installed-metal-lifetime-compile','installed-metal-lifetime'))
    assert (RUN/f'runner-{tag}.py').is_file() and (RUN/f'consumer-project-{tag}.cmake').is_file()
    matrix.append({'route':route,'mode':mode,'tag':tag,'public_header_tus':12,'consumer_tus':16,'tests':counts,'verdict':'PASS'})
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()==''
result={'kind':'G04_G05_RELOCATED_SHIPPING_STATIC_SHARED_SDK','verdict':'PASS_SIX_CONFIGURATIONS',
        'product_commit':commit,'matrix':matrix,'air_shipping_profile_cache':air_profiles,
        'qualified':['CPU+Apple, CPU+Vulkan and CPU+CUDA cached production static/shared trees incrementally built and installed to new staging directories, then relocated before consumer configure/build/run',
            'Twelve changed public headers compiled as twelve separate object translation units in every configuration',
            'Independent external consumers use installed HYLE headers/libraries only, no producer/canonical HYLE source includes; fixed original GoogleTest is only an external test dependency',
            'Each configuration actual new CPU encode and finite attention mathematical domain, direct/Graph incremental Q8 CPU pages and failures, native encoded cache/attention domain plus original native/joint incremental producers and accepted failures',
            'F16 and BF16 CPU/Apple/CUDA domains and F16 Vulkan finite domain; single/multi, D64/128 and main D256/256, six updates and original frame/page/history lifetime',
            'Apple installed product-derived SharedPtr header and allocator header SHA match current exact manifests; installed license/notice match canonical. Independent installed-header Clang21/O3/UBSan lifetime passes for static/shared',
            'All selected shipping HYLE compile commands have no HYLE_TESTING and no sanitizer; CUDA explicitly clears the old private source-risk CMAKE_PROJECT_INCLUDE before configuring and recompiles affected host TU normally'],
        'limits':['No Vulkan BF16 claim','Mixed-route SDK CPU consumption is actual CPU execution, not an additional CPU-only packaging profile certificate','No P1, shader/driver sanitizer, private-pool byte upper bound or whole G04/G05/G01-G10 completion'],
        'input_manifest_sha256':hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest(),
        'runs':[dict(tag=tag,**{k:v for k,v in record.items() if k!='inputs'}) for tag,record in records],
        'cumulative_seconds':sum(record['cumulative_seconds'] for _,record in records)}
OUT.mkdir(parents=True,exist_ok=False)
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as raw:
    for file in sorted(RUN.iterdir()):
        if file.is_file() and file.suffix!='.zip':raw.write(file,file.name)
    names=['tests/compute_batch/encoded_page_common_consumer.cc','tests/compute_batch/encoded_page_native_consumer.cc',
           'tests/compute_provider_native/half_test_support.h','tests/compute_provider_ggml/native_paged_test.cc',
           'tests/compute_route_apple/native_cache_test.cc','tests/compute_route_vulkan/native_cache_test.cc',
           'tests/compute_provider_flashinfer/native_cache_test.cc','tests/compute_route_apple/metal_shared_ptr_lifetime.cc']
    for name in names:raw.write(ROOT/name,'public-fixtures/'+name)
    for tag,_ in records:
        with zipfile.ZipFile(RUN/f'source-{tag}.zip') as source:raw.writestr(f'inputs/{tag}/source-manifest.json',source.read('source-manifest.json'))
    for name in ('encoded_sdk.py','launch_encoded_sdk.py','seal_encoded_sdk.py'):raw.write(BASE/name,'runners/'+name)
print(json.dumps({'verdict':result['verdict'],'configurations':len(matrix),'cumulative_seconds':result['cumulative_seconds'],'raw_bytes':(OUT/'raw.zip').stat().st_size}))
