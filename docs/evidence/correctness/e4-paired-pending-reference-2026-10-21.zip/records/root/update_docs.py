from pathlib import Path
import json
P=Path(__file__).resolve().parents[1]; R=P.parents[2]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
for arm,attempt in read(P/'root/final-attempts.json').items():
    d=read(P/arm/'validation'/attempt/'receipt.json'); assert d['passed'] and not d['skipped']
d=read(P/'apple/final-validation.json'); assert d['failed']==d['skipped']==0
pending={}
def change(path,old,new):
    p=R/path; s=pending.get(p,p.read_text(encoding='utf8')); assert s.count(old)==1,(path,old)
    pending[p]=s.replace(old,new)
e='../evidence/correctness/e4-paired-pending-reference-2026-10-21.json'
change('docs/developer/current-work.md',
 '第8包进行中；GLM首层两组原始head权重已四端消费，Apple补齐原生非连续只读结果导出；下一项核普通E4成对生产／页读取旅程',
 '第8包进行中；普通E4成对pending生产／页读取已四端闭环，修复未提交copy槽的原生产者退休检查；下一项核正式GA非CUDA indexer／状态链')
change('docs/developer/current-work.md',
 '**当前下一动作**：沿现CacheEncode、成对pending／ready与页reader，补CPU／Apple／Vulkan的普通E4真实生产者旅程；CUDA已有该链，先核其实际证据。随后核交付3的正式GA非CUDA indexer／状态链，不扩大为33整模型验收。',
 '**当前下一动作**：核交付3的正式GA非CUDA BF16 indexer→score／TopK→压缩状态旅程，继续对齐精确角色与原公共执行链，不扩大为33整模型验收。\n'
 f'普通E4成对／独立生产者经原CopyBatchUpdate进入pending页读取的[四端旅程]({e})已通过：4项新增、3项邻居，0跳过；其中新E4共9个成功旅程、54轮更新和18个预期失败旅程。\n'
 '另修共同copy槽在尚未提交复制时漏观察已绑定生产者的非阻塞退休检查；pending／失败仍拒绝撤回，不增加成功路径host等待。CPU／CUDA旧孤立测试已登记常规CMake。\n'
 '可重建测试镜像的删除与增量对象保留范围见[清理实录](../evidence/correctness/e4-paired-pending-reference-2026-10-21.cleanup.json)。')
change('docs/developer/current-work.md',
 '只签有界普通页路径，E4成对pending生产者链、compact MLA／制品scale绑定、Linux及吞吐仍未签；',
 '只签该批有界普通页读取；普通E4成对pending生产者链已由后续批次补验，compact生产者／具体制品scale绑定、Linux及吞吐仍未签；')
change('docs/implementation/model-operators.md',
 '只签BF16 D64→128等本批有界数学／寿命；未签E4成对pending生产者链、compact MLA／具体制品scale绑定、Linux、质量或吞吐。CUDA归约的scale位置保留，不承诺任意scale跨端逐bit相同',
 f'普通E4成对／独立CacheEncode→F2→pending页读取另有[4项新增与3项邻居]({e})通过，含CPU Direct／Graph、CUDA Direct／GPU Graph／mixed及Apple／Vulkan native／mixed；其中新E4共9个成功旅程、54轮更新和18个预期失败旅程。修未提交copy槽的生产者退休检查，保原K→V绑定与非阻塞撤回。只签BF16 D64→128等有限域；compact成对生产者／具体制品scale绑定、Linux、质量、吞吐与任意scale跨端逐bit仍未签')
change('docs/implementation/model-operators.md',
 '`MlxQuantized{format,kind,bits,group_size}`已接affine4/5/6/8，连续U32行末轴`(K/32)*bits`。',
 '`MlxQuantized{format,kind,bits,group_size,orientation}`已接affine4/5/6/8，连续U32行末轴`(K/32)*bits`。affine另支持`kWeightAsStored`：物理W[N,K]及K分组不变，A[...,N]→Y[...,K]；[四端同bank两方向](../evidence/correctness/mlx-weight-orientation-reference-2026-10-21.json)已验。')
change('docs/implementation/model-operators.md',
 'GLM31的156个head-bank是64头投影：L1可用原grouped＋小A Copy，实际consumer未跑；prefill `embed_q(...,transpose=False)`所需非转置packed-W接口尚缺。',
 'GLM31的156个head-bank是64头投影；[首层embed_q／unembed_out六个原tensor](../evidence/correctness/mlx-head-payload-reference-2026-10-21.json)（7.875MiB）已四端消费，覆盖decode小query Copy、独立attention输入边界、prefill非转置／共享latent和head顺序，Apple补原生非连续只读结果投影。其余层／全部156个bank仍未验。')
change('docs/implementation/model-operators.md',
 '不签实际GLM routing／shared expert／mHC、payload／整制品、质量、吞吐或峰值；',
 '不签实际GLM routing／shared expert／mHC、其余payload／整制品、质量、吞吐或峰值；')
p=R/'docs/user/batch-attention.md'
before=P/'root/docs-before/docs--user--batch-attention.md'; before.write_bytes(p.read_bytes())
change('docs/user/batch-attention.md',
 '不能由普通分页支持推导其已接通。见[定向数值与寿命回归](../evidence/correctness/paged-e4-kv-reference-2026-10-21.json)。',
 '不能由普通分页支持推导其已接通。见[定向数值与寿命回归](../evidence/correctness/paged-e4-kv-reference-2026-10-21.json)。\n\n'
 '同一E4 spec也可经成对或独立`CacheEncode`生产者、原`CopyBatchUpdate`和pending页frame进入后继attention；\n'
 '成功路径只等最终消费，不要求先host等待encoder或copy。绑定失败保留未被消费的原Completion；\n'
 '撤回已绑定writer前须观察其生产者的真实退休，不能用“copy尚未in_flight”推断生产者没有在途工作。\n'
 f'CPU／CUDA／Apple／Vulkan的[有限旅程]({e})覆盖BF16 D64→128、双请求、六轮交替生产、旧结果与NaN失败；失败旅程使用独立context，不代表同context重试。')
p=R/'docs/implementation/model-quantizations.json'; d=read(p)
for a in d['artifacts']:
    coverage=a['provider_coverage']
    if 'ordinary_paged_e4_reference' not in coverage: continue
    coverage['ordinary_paged_e4_reference']['limits']='Original ordinary-page reader window; later e4_paired_pending_reference supplies the finite producer/pending journey. Neither establishes compact paired producers, exact artifact scalar/exporter binding, whole model, Linux, throughput or quality.'
    coverage['e4_paired_pending_reference']=dict(evidence='docs/evidence/correctness/e4-paired-pending-reference-2026-10-21.json',
        scope='Four-backend ordinary CacheEncode paired/independent -> F2 -> pending paged attention. BF16 Q/Y D64/128, two requests, distinct Kscale0.5/Vscale2, six updates per successful episode; original owners, exact bytes, old pages/results and V-NaN failure retirement.',
        regression='4 new plus3 neighbor cases,0 skips. New E4 alone:9 success episodes/54 update rounds and18 expected failure episodes. CPU Direct/Graph; CUDA Direct/GPU Graph/CPU+GPU Graph; Apple/Vulkan native/CPU+GPU.',
        limits='Not exact artifact scalar/exporter binding or payload, compact MLA paired producers, scaledDSA656/528, same-context retry, Linux, quality, capture or throughput.')
    old=coverage.get('compact_mla_e4_reference',{}).get('limits','')
    if old:
        coverage['compact_mla_e4_reference']['limits']=old.replace('Ordinary E4 paired-pending producer chain remains separate and unqualified;','Ordinary E4 paired-pending producer chain is separately qualified by e4_paired_pending_reference; this does not qualify compact paired producers;')
d['followup_reviews'].append(dict(observed_on='2026-10-21',evidence='docs/evidence/correctness/e4-paired-pending-reference-2026-10-21.json',artifact_indices=[28,29],
    scope='Finite ordinary E4 paired/independent producer -> F2 -> pending pages, four backends; no exact artifact binding.',
    partial_backend_snapshot=False,distinct_cases=7,new_cases=4,neighbors=3,skipped=0,
    success_episodes=9,update_rounds=54,expected_failure_episodes=18,
    limits='All33 artifact_execution_verified remainfalse. No compact producer, exact scalar/exporter/payload, model, Linux, quality, capture or throughput acceptance.'))
pending[p]=json.dumps(d,ensure_ascii=False,indent=2)+'\n'
for p,s in pending.items(): p.write_text(s,encoding='utf8')
print('Updated current plan, ordinary E4 user guide and catalog; corrected stale MLX table.')
