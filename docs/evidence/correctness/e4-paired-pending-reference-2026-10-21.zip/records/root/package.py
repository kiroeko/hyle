from pathlib import Path
import hashlib, json, zipfile, xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1]; R=P.parents[2]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):
    p=Path(p); return p if p.is_absolute() else R/p
def ident(p): return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(row):
    p=resolve(row['path']); assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
cases=[]; receipts=[]
def collect(arm,path):
    for x in ET.parse(path).findall('.//testcase'):
        assert x.find('failure') is None and x.find('skipped') is None
        cases.append(dict(backend=arm,name=x.get('classname')+'.'+x.get('name'),
            properties={v.get('name'):v.get('value') for v in x.findall('./properties/property')}))
attempts=read(P/'root/final-attempts.json')
for arm,attempt in attempts.items():
    p=P/arm/'validation'/attempt/'receipt.json'; d=read(p)
    assert d['passed'] and not d['failed'] and not d['skipped']
    for k in ('image','xml','link_plan'): check(d[k])
    plan=read(resolve(d['link_plan']['path']))
    for row in plan['inputs']: check(row)
    consumer=(read(resolve(plan['new_consumer']['path']).parent/'identity.json')
        if plan.get('new_consumer') else read(P/arm/'checks/attempt1/identity.json'))
    check(consumer['source']); check(consumer['oracle'])
    product=read(P/'common/checks/final-common/identity.json'); check(product['source']); check(product['object'])
    assert sum(x['sha256']==product['object']['sha256'] for x in plan['inputs'])==1
    if arm=='cuda':
        modules=read(p.parent/'runtime-environment.json')['private_modules']; assert len(modules)==1
        for module in modules:
            check(module['source']); check(module['destination']); assert module['hardlink']
            assert module['source']['sha256']==module['destination']['sha256']
    collect(arm,resolve(d['xml']['path'])); receipts.append(dict(backend=arm,receipt=ident(p)))
apple_path=P/'apple/final-validation.json'; apple=read(apple_path)
assert apple['failed']==apple['skipped']==0
check(apple['source_freeze']); check(apple['gtest'])
collect('apple',resolve(apple['gtest']['path']))
e4=[x for x in cases if x['name'].endswith('.Float8PairedPendingConsumers')]
assert len(cases)==7 and len(e4)==4 and {x['backend'] for x in e4}=={'cpu','cuda','vulkan','apple'}
totals={k:sum(int(x['properties'][k]) for x in e4) for k in ('success_episodes','expected_failure_episodes','update_rounds')}
assert totals==dict(success_episodes=9,expected_failure_episodes=18,update_rounds=54)
assert all(x['properties']['key_scale']=='0.5' and x['properties']['value_scale']=='2' for x in e4)
catalog=read(R/'docs/implementation/model-quantizations.json')
assert len(catalog['artifacts'])==33 and all(a['provider_coverage']['artifact_execution_verified'] is False for a in catalog['artifacts'])
sources=['tests/compute_batch/encoded_page_common_consumer.cc','tests/compute_batch/encoded_page_native_consumer.cc',
 'tests/compute_batch/encoded_page_codec_oracle.h','tests/compute_provider_native/half_test_support.h','tests/graph_batch/CMakeLists.txt',
 'include/hyle/compute/batch_transfer.h','include/hyle/compute/batch_ops.h','include/hyle/compute/resource_leases.h',
 'src/compute/batch_transfer.cc','src/compute/resource_leases.cc','src/graph_route_cpu_cuda/compile.cc',
 'cmake/HyleRuntimeStaging.cmake','src/compute_ggml_runtime/cpu_program.cmake','src/compute_ggml_runtime/HyleGgmlCpuRuntimeConfig.cmake.in',
 'docs/user/compute.md','docs/user/batch-attention.md','docs/developer/current-work.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json']
assert all((R/s).is_file() for s in sources)
entries={'source/'+s:R/s for s in sorted(sources)}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.md','.mm','.ps1','.cmake','.in'}
for p in P.rglob('*'):
    if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
        entries['records/'+p.relative_to(P).as_posix()]=p
archive=R/'docs/evidence/correctness/e4-paired-pending-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for name,p in sorted(entries.items()): z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(entries)
    for name,p in entries.items(): assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='ordinary_E4_paired_pending_four_backend_reference_passed',
 scope='Existing CacheEncode -> original paired/independent Completion ownership -> F2 CopyBatchUpdate -> pending paged attention, BF16 Q/Y, D64/128, two requests. CPU Direct/Graph, CUDA Direct/GPU Graph/CPU+GPU Graph, Apple and Vulkan native/CPU+GPU. No new public format, executor or routing policy.',
 execution=dict(codec='E4M3FN, distinct F32 Kscale0.5/Vscale2',updates='Each success episode alternates paired/independent original encoders over six updates. Exact copy logical bytes13056 then768*5=16896 per episode; independent bytes/dequant/softmax oracle checks old pages, clean/history/tail and retained results.',
  completion='Only final successful consumption waits on host; each failure checks original numeric error, no result/page publication, original writer ownership and actual original Completion retirement. Failure observation does not add a wait to successful producer/copy/paged execution.'),
 regression=dict(total=len(cases),new_cases=len(e4),neighbors=len(cases)-len(e4),failed=0,skipped=0,**totals,windows=receipts,apple=ident(apple_path),cases=cases),
 fixes=read(P/'root/fix-summary.json'),
 build='Only relevant consumer sources, the corrected common batch-transfer owner and one existing thin CPU+CUDA compile helper refreshed. Mixed CUDA focused link explicitly adds current CPU context/default provider owners and cached libraries by identity; no SDK or NVCC build. Source/dependency/owner records and initial compile/link/runtime failures are retained.',
 limitations=['Finite ordinary E4 path, not all FP8 IEEE inputs or shape combinations, scaled DSA656/528, exact publisher scalar/exporter binding, whole artifact/model, Linux, quality, throughput, capture acceptance or peak-memory measurement.',
  'Failure episodes use separate contexts, not a same-context retry claim. CPU+GPU native tests place attention on GPU and small ordinary graph operations on CPU.',
  'Capability7/8 and delivery0/3 remain open. All33 artifact_execution_verified flags remainfalse. Current-source/install/Linux closure remains delivery1.'],
 remaining_required='Proceed to formal GA non-CUDA BF16 indexer/score/TopK/compressed-state role journey and remaining exact bindings. Do not rerun completed broad matrices.',
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],sources=len(sources),cases=len(cases),**totals)
save(P/'root/package-summary.json',summary); print(json.dumps(summary,ensure_ascii=False))
