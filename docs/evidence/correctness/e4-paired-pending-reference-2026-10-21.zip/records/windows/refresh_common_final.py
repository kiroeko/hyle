"""Refresh the final common consumer, preserving CUDA's real mixed carrier."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('pending_helpers', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R, P = h.b, h.c, h.R, h.P


def compile_product(attempt):
    recipe_path = h.A / 'batch-query-extent/vulkan/checks/compute-batch_transfer-identity.json'
    recipe = c.read(recipe_path)
    source = R / 'src/compute/batch_transfer.cc'
    out = P / 'common/checks' / attempt
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists()
    command = b.host_command(recipe['command'], source, 'batch-transfer', out)
    frozen = b.identity(source)
    c.save(out / 'plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe_path),
        scope='Single backend-neutral product owner reused by CPU/CUDA/Vulkan; no ABI/header edits'))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / 'batch-transfer-deps.json')['Data']
    record = dict(command=command, source=frozen, object=b.identity(out / 'batch-transfer.obj'),
        recipe=b.identity(recipe_path), source_dependencies=b.identity(out / 'batch-transfer-deps.json'),
        dependencies=[b.identity(x) for x in dict.fromkeys([data['Source'], *data['Includes']])])
    assert b.same(frozen)
    assert all(b.same(x) for x in record['dependencies'])
    c.save(out / 'identity.json', record)
    return record


def link_one(arm, record, product, directory):
    sub = 'link2' if arm == 'cuda' else 'link1'
    basepath = P / arm / 'checks' / sub / 'link-plan.json'
    base = c.read(basepath)
    replacements = {}
    old_record = c.read(P / arm / 'checks/attempt2/identity.json') if record else None
    if record:
        replacements[c.key(old_record['object']['path'])] = record['object']
    audit = c.read(S / 'base-owner-audit.json')
    old_product = next(x['object'] for a in audit['arms'] if a['arm'] == arm
        for x in a['related_products'] if x['source'] == 'src/compute/batch_transfer.cc')
    replacements[c.key(old_product['path'])] = product['object']
    assert all(sum(c.key(x['path']) == key for x in base['inputs']) == 1 for key in replacements)
    assert all(b.same(row) for row in base['inputs'])
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    command = [replacements.get(c.key(x), {}).get('path', x) for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = P / arm / 'checks' / directory
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
        '/IMPLIB:' + str(image.with_suffix('.lib'))]
    paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert [c.key(x) for x in paths] == [c.key(x['path']) for x in inputs]
    if arm == 'cuda':
        helper = c.read(P / 'cuda/checks/mixed-helper/identity.json')['object']
        assert sum(c.key(x['path']) == c.key(helper['path']) for x in inputs) == 1
        assert len(inputs) == len(base['inputs']) == 217
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(basepath),
        replaced_consumer=old_record['object'] if old_record else None,
        new_consumer=record['object'] if record else None,
        old_product=old_product, new_product=product['object'],
        retained_other_inputs=len(inputs)-len(replacements), preserves_mixed_cpu_context_carrier=arm == 'cuda',
        common_product_compiles=1, SDK_builds=0, GPU_runs=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    c.save(out / 'image.json', b.identity(image))
    print('LINKED', arm, directory, flush=True)
    return dict(arm=arm, image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
        identity=b.identity(Path(record['object']['path']).parent / 'identity.json') if record
            else b.identity(P / 'vulkan/checks/attempt1/identity.json'),
        product_identity=b.identity(Path(product['object']['path']).parent / 'identity.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        filter=('EncodedNativePages' if arm == 'vulkan' else 'EncodedCommonPages') + '.Float8PairedPendingConsumers')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--link-dir', required=True)
    args = parser.parse_args()
    # This script is invoked only after the shared consumer owner confirms freeze.
    product = compile_product(args.attempt)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = dict(pool.map(lambda arm: h.compile_one(arm, args.attempt), ['cpu', 'cuda']))
    arms = [link_one(arm, records.get(arm), product, args.link_dir) for arm in ['cpu', 'cuda', 'vulkan']]
    c.save(S / 'ready-for-root-run.json', dict(status='final_common_consumers_compiled_linked',
        arms=arms, agent_product_source_edits=0,
        package_product_source_changed=['src/compute/batch_transfer.cc'], SDK_builds=0, NVCC_compiles=0,
        source_freeze=b.identity(P / 'source-freeze.json'),
        fresh_common_product_owners=1, fresh_consumer_owners=2,
        limits='Agent did not execute CPU tests or GPU; Vulkan consumer object unchanged, common product refreshed'))


if __name__ == '__main__':
    main()
