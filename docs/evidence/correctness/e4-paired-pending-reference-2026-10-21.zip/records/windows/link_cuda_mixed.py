"""Link the actual CPU default-provider carrier required by the mixed consumer."""
from pathlib import Path
import importlib.util
import json
import re
import subprocess
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('e4_pending', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, R, P, A, Q = h.b, h.c, h.R, h.P, h.A, h.Q


def visit(value):
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from visit(item)
    elif isinstance(value, list):
        for item in value:
            yield from visit(item)


metadata = c.read(S / 'metadata-index.json')
cpu_plan_path = Q / 'cpu/checks/link3/link-plan.json'
cpu = c.read(cpu_plan_path)
base_path = P / 'cuda/checks/link1/link-plan.json'
base = c.read(base_path)
helper_path = P / 'cuda/checks/mixed-helper/identity.json'
helper = c.read(helper_path)
assert b.same(helper['source']) and b.same(helper['object'])
inputs = list(base['inputs'])
seen = {c.key(x['path']) for x in inputs}
source_seen = {metadata[c.key(x['path'])]['source_path'] for x in inputs if c.key(x['path']) in metadata}
added = [dict(identity=helper['object'], reason='Existing CPU+CUDA Graph compile helper')]
provider_prefixes = ('src/compute_route_cpu/', 'src/compute_backend_cpu/',
    'src/compute_provider_native/', 'src/compute_provider_ggml/', 'src/compute_provider_onednn/')
for row in cpu['inputs']:
    entry = metadata.get(c.key(row['path']))
    if not entry or c.key(row['path']) in seen:
        continue
    source = Path(entry['source_path'])
    relative = source.relative_to(R).as_posix() if source.is_relative_to(R) else ''
    if not relative.startswith(provider_prefixes) or entry['source_path'] in source_seen:
        continue
    assert b.same(row)
    added.append(dict(identity=row, reason='Actual CPU default Context provider dependency', source=relative,
        recipe=b.identity(entry['recipe'])))
    seen.add(c.key(row['path']))
    source_seen.add(entry['source_path'])
library_names = {'hyle_compute_route_cpu.lib', 'hyle_compute_backend_cpu.lib',
    'hyle_compute_provider_native.lib', 'hyle_compute_provider_ggml.lib', 'ggml-cpu.lib',
    'hyle_compute_provider_onednn.lib', 'dnnl.lib'}
seen_names = {Path(x['path']).name.lower() for x in inputs if Path(x['path']).suffix.lower() == '.lib'}
for row in cpu['inputs']:
    name = Path(row['path']).name.lower()
    if name not in library_names or name in seen_names:
        continue
    assert b.same(row)
    added.append(dict(identity=row, reason='Existing cached CPU provider dependency library'))
    seen_names.add(name)
new_rows = [x['identity'] for x in added]
assert len({c.key(x['path']) for x in new_rows}) == len(new_rows)
inputs = [*new_rows, *inputs]
assert all(b.same(x) for x in inputs)

# The CPU context is a current, already validated object, not a stale archive fallback.
context_recipe = A / 'ct-packed-cross-platform/checks/compile-summary.json'
context = next(x for x in visit(c.read(context_recipe)) if isinstance(x.get('object'), dict)
    and x['object']['path'].endswith('src--compute_route_cpu--cpu_context.obj'))
assert b.same(context['source']) and b.same(context['object'])
workspace_drift = [x for x in context['dependencies'] if Path(x['path']).is_relative_to(R) and not b.same(x)]
assert len(workspace_drift) == 1 and workspace_drift[0]['path'].endswith('include\\hyle\\mem\\allocator.h')
old_allocator = subprocess.run(['git', 'show', 'HEAD:include/hyle/mem/allocator.h'], cwd=R,
    check=True, stdout=subprocess.PIPE).stdout
import hashlib
assert hashlib.sha256(old_allocator).hexdigest() == workspace_drift[0]['sha256']
strip = lambda s: re.sub(r'\s+', '', re.sub(r'/\*.*?\*/|//[^\r\n]*', '', s, flags=re.S))
assert strip(old_allocator.decode()) == strip((R / 'include/hyle/mem/allocator.h').read_text())
policy_path = A / 'native-ready-pages/windows/compute_route_cpu--default_policy-identity.json'
policy = c.read(policy_path)
assert b.same(policy['source'])

out = P / 'cuda/checks/link2'
out.mkdir(parents=True, exist_ok=True)
(out / 'tmp').mkdir(exist_ok=True)
assert not (out / 'link.result.json').exists()
command = [x for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
command[1:1] = [x['path'] for x in new_rows]
image = out / 'cuda.exe'
command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
    '/IMPLIB:' + str(image.with_suffix('.lib'))]
paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
assert [c.key(x) for x in paths] == [c.key(x['path']) for x in inputs]
c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path),
    cpu_dependency_base=b.identity(cpu_plan_path), added_carrier=added,
    context_reuse=dict(identity=b.identity(context_recipe), source=context['source'], object=context['object'],
        workspace_drift=workspace_drift, allocator_comment_only_proved=True),
    policy_source_reuse=b.identity(policy_path), helper=b.identity(helper_path),
    product_source_edits=0, fresh_existing_helper_CXX=1, provider_recompiles=0, SDK_builds=0, GPU_runs=0))
env, runtime = b.environment(command, [x['path'] for x in inputs], out)
c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
c.execute('link', command, env, out)
c.save(out / 'image.json', b.identity(image))
print(out / 'link-plan.json')
