"""Refresh only two consumer test sources in their three actual Windows domains."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
P = S.parent
A = P.parent
R = A.parents[1]
Q = A / 'mlx-head-payload-2026-10-21'
spec = importlib.util.spec_from_file_location('e4_pending_helpers', A / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASES = {arm: Q / arm / 'checks' / sub / 'link-plan.json'
    for arm, sub in [('cpu', 'link3'), ('cuda', 'link2'), ('vulkan', 'link3')]}
RECIPES = {
    'cpu': Q / 'cpu/checks/attempt3/test-identity.json',
    'cuda': Q / 'cuda/checks/attempt3/test-identity.json',
    'vulkan': A / 'paged-e4-kv-reference/vulkan/checks/q8-neighbor/q8-neighbor-identity.json',
}


def source_for(arm):
    return R / ('tests/compute_batch/encoded_page_native_consumer.cc' if arm == 'vulkan'
        else 'tests/compute_batch/encoded_page_common_consumer.cc')


def compile_one(arm, attempt):
    recipe = c.read(RECIPES[arm])
    source = source_for(arm)
    out = P / arm / 'checks' / attempt
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists()
    command = b.host_command(recipe['command'], source, 'encoded-page', out)
    if arm == 'cuda' and '/DHYLE_ENCODED_CUDA=1' not in command:
        command.insert(1, '/DHYLE_ENCODED_CUDA=1')
    source_before = b.identity(source)
    oracle = b.identity(R / 'tests/compute_batch/encoded_page_codec_oracle.h')
    replaced = recipe['object'] if arm == 'vulkan' else None
    c.save(out / 'compile-plan.json', dict(command=command, source=source_before,
        oracle=oracle, recipe=b.identity(RECIPES[arm]), replaces=replaced,
        added=arm != 'vulkan', product_compiles=0, SDK_builds=0, GPU_runs=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / 'encoded-page-deps.json')['Data']
    record = dict(command=command, source=source_before, oracle=oracle,
        object=b.identity(out / 'encoded-page.obj'), replaces=replaced,
        recipe=b.identity(RECIPES[arm]),
        source_dependencies=b.identity(out / 'encoded-page-deps.json'),
        dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])])
    assert b.same(source_before) and b.same(oracle)
    assert all(b.same(d) for d in record['dependencies'])
    c.save(out / 'identity.json', record)
    print('COMPILED', arm, flush=True)
    return arm, record


def link_one(arm, record, directory):
    base = c.read(BASES[arm])
    assert all(b.same(row) for row in base['inputs'])
    oldkey = c.key(record['replaces']['path']) if record['replaces'] else None
    inputs = list(base['inputs'])
    command = [x for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    if oldkey:
        assert sum(c.key(x['path']) == oldkey for x in inputs) == 1
        inputs = [record['object'] if c.key(x['path']) == oldkey else x for x in inputs]
        command = [record['object']['path'] if c.key(x) == oldkey else x for x in command]
    else:
        inputs.insert(0, record['object'])
        command.insert(1, record['object']['path'])
    assert len({c.key(x['path']) for x in inputs}) == len(inputs)
    paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert [c.key(x) for x in paths] == [c.key(x['path']) for x in inputs]
    out = P / arm / 'checks' / directory
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
        '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(BASES[arm]),
        new_consumer=record['object'], replaced_consumer=record['replaces'],
        added=0 if oldkey else 1, replaced=1 if oldkey else 0,
        product_compiles=0, SDK_builds=0, GPU_runs=0,
        duplicate_owner_audit=b.identity(S / 'base-owner-audit.json')))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    image_identity = b.identity(image)
    c.save(out / 'image.json', image_identity)
    print('LINKED', arm, flush=True)
    return dict(arm=arm, image=image_identity, link_plan=b.identity(out / 'link-plan.json'),
        consumer_identity=b.identity(Path(record['object']['path']).parent / 'identity.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        filter=('EncodedNativePages' if arm == 'vulkan' else 'EncodedCommonPages') + '.Float8PairedPendingConsumers')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--link', action='store_true')
    parser.add_argument('--attempt', default='attempt1')
    parser.add_argument('--compile-arms', nargs='+', choices=list(BASES), default=list(BASES))
    parser.add_argument('--reuse-attempt', default='attempt1')
    parser.add_argument('--link-dir', default='link1')
    args = parser.parse_args()
    arms = list(BASES)
    if args.compile:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            records = dict(pool.map(lambda arm: compile_one(arm, args.attempt), args.compile_arms))
        for arm in arms:
            if arm not in records:
                records[arm] = c.read(P / arm / 'checks' / args.reuse_attempt / 'identity.json')
    else:
        records = {arm: c.read(P / arm / 'checks' / args.attempt / 'identity.json') for arm in arms}
    if args.link:
        rows = [link_one(arm, records[arm], args.link_dir) for arm in arms]
        results = [c.read(p) for arm in arms for p in (P / arm / 'checks').glob('attempt*/compile.result.json')]
        c.save(S / 'ready-for-root-run.json', dict(status='focused_consumers_compiled_linked_not_executed',
            CXX_attempts=len(results), CXX_success=sum(r['exit'] == 0 for r in results),
            focused_link_success=3, product_compiles=0, NVCC_compiles=0, SDK_builds=0,
            agent_CPU_runs=0, agent_GPU_runs=0, arms=rows,
            limits='Filters select only finite new E4 tests; previous all-profile matrices are not requested',
            owner_audit=b.identity(S / 'base-owner-audit.json')))


if __name__ == '__main__':
    main()
