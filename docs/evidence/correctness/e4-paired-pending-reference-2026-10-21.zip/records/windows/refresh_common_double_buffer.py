"""Refresh only the final test-pool correction, preserving all product inputs."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('e4_pending', S / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c, P = h.b, h.c, h.P


def link_one(arm, record, directory):
    basepath = P / arm / 'checks/final-link1/link-plan.json'
    base = c.read(basepath)
    old = c.read(P / arm / 'checks/final-common/identity.json')
    oldkey = c.key(old['object']['path'])
    assert sum(c.key(x['path']) == oldkey for x in base['inputs']) == 1
    assert all(b.same(x) for x in base['inputs'])
    inputs = [record['object'] if c.key(x['path']) == oldkey else x for x in base['inputs']]
    product = c.read(P / 'common/checks/final-common/identity.json')
    assert sum(x == product['object'] for x in inputs) == 1
    assert b.same(product['source']) and b.same(product['object'])
    assert len(inputs) == (217 if arm == 'cuda' else 156)
    if arm == 'cuda':
        helper = c.read(P / 'cuda/checks/mixed-helper/identity.json')
        assert sum(x == helper['object'] for x in inputs) == 1
    command = [record['object']['path'] if c.key(x) == oldkey else x for x in base['command']
        if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    out = P / arm / 'checks' / directory
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
        '/IMPLIB:' + str(image.with_suffix('.lib'))]
    paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert [c.key(x) for x in paths] == [c.key(x['path']) for x in inputs]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(basepath),
        replaced_consumer=old['object'], new_consumer=record['object'],
        preserved_batch_transfer=product['object'], retained_other_inputs=len(inputs)-1,
        preserves_mixed_cpu_context_carrier=arm == 'cuda', product_compiles=0, SDK_builds=0, GPU_runs=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    c.save(out / 'image.json', b.identity(image))
    print('LINKED', arm, directory, flush=True)
    return dict(arm=arm, image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
        identity=b.identity(Path(record['object']['path']).parent / 'identity.json'),
        product_identity=b.identity(P / 'common/checks/final-common/identity.json'),
        runtime_environment=b.identity(out / 'runtime-environment.json'),
        filter='EncodedCommonPages.Float8PairedPendingConsumers')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--link-dir', required=True)
    args = parser.parse_args()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = dict(pool.map(lambda arm: h.compile_one(arm, args.attempt), ['cpu', 'cuda']))
    arms = [link_one(arm, records[arm], args.link_dir) for arm in ['cpu', 'cuda']]
    vk = P / 'vulkan/checks/final-link1'
    arms.append(dict(arm='vulkan', image=c.read(vk / 'image.json'),
        link_plan=b.identity(vk / 'link-plan.json'),
        identity=b.identity(P / 'vulkan/checks/attempt1/identity.json'),
        product_identity=b.identity(P / 'common/checks/final-common/identity.json'),
        runtime_environment=b.identity(vk / 'runtime-environment.json'),
        unchanged=True, filter='EncodedNativePages.Float8PairedPendingConsumers',
        root_validation=str(P / 'vulkan/validation/final2')))
    c.save(S / 'ready-for-root-run.json', dict(status='double_buffer_consumer_correction_compiled_linked',
        arms=arms, product_compiles_this_step=0, consumer_compiles_this_step=2,
        links_this_step=2, SDK_builds=0, NVCC_compiles=0, agent_GPU_runs=0, agent_CPU_runs=0,
        source_freeze=b.identity(P / 'source-freeze.json'),
        limits='Vulkan image and shared product object unchanged; root owns all actual execution'))


if __name__ == '__main__':
    main()
