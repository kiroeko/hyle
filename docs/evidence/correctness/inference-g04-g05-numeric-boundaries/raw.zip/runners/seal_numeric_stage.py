from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'.scratch/inference-gaps/g04-g05'
OUT=ROOT/'evidence/correctness/inference-g04-g05-numeric-boundaries'
RUNS=[]
def load(label,path,xml,expected,archive=None):
    record=json.loads(path.read_text())
    assert record['state'].startswith('TERMINAL_'),label
    tree=ET.parse(xml).getroot()
    if expected is not None:
        assert record['state']=='TERMINAL_PASS',label
        assert int(tree.attrib['tests'])==expected and int(tree.attrib['failures'])==0,label
    else:
        assert record['state']=='TERMINAL_FAIL' and int(tree.attrib['failures'])>0,label
    RUNS.append((label,path,record,archive))

for n in (7,8):
    directory=BASE/f'common-encoded/cpu-{n}'
    load(f'cpu-{n}',directory/'result.json',directory/'tests.xml',2)
directory=BASE/'common-encoded/cuda-9'
load('cuda-9',directory/'result.json',directory/'tests.xml',1,BASE/'common-encoded/source-cuda-9.zip')
for route in ('apple','vulkan'):
    for n in (1,2,3):
        directory=BASE/f'{route}-native'
        load(f'{route}-numeric-{n}',directory/f'result-numeric-{n}.json',
             directory/f'tests-numeric-{n}.xml',None if n==1 else 1 if n==2 else 11,
             directory/f'source-numeric-{n}.zip')
directory=BASE/'numeric/ubsan-1'
load('ubsan-1',directory/'result.json',directory/'tests.xml',9,BASE/'numeric/source-ubsan-1.zip')
san=RUNS[-1][2]
assert san['actual_original_reference_float_cast_failure']
negative=next(s for s in san['stages'] if s['stage']=='negative-control')
assert negative['exit_code']==1
assert "inf is outside the range of representable values of type 'signed char'" in (directory/'negative-control.log').read_text()
instrumented=json.loads((directory/'instrumented-inputs.json').read_text())
assert len(instrumented)==4

names=['include/hyle/compute/model_ops.h','src/compute_provider_ggml/ggml_cpu_provider.cc',
       'src/compute_route_apple/apple_mature_float.cc','third_party/ggml_vulkan_runtime/patches.json',
       'third_party/ggml_vulkan_runtime/NOTICE.md','cmake/HyleDependencyLock.json',
       'tests/compute_provider_ggml/native_paged_test.cc','tests/compute_provider_flashinfer/native_cache_test.cc',
       'tests/compute_route_apple/native_cache_test.cc','tests/compute_route_vulkan/native_cache_test.cc',
       'tests/compute_batch/encoded_page_common_consumer.cc']
sha={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in names}
for label,_,record,archive in RUNS:
    if label.endswith('-1') and label!='ubsan-1' or label=='cpu-7':continue
    inputs=record['inputs']
    inputs=inputs if isinstance(inputs,dict) else {i['path']:i['sha256'] for i in inputs}
    relevant=(['tests/compute_provider_flashinfer/native_cache_test.cc'] if label=='cuda-9' else
              ['src/compute_provider_ggml/ggml_cpu_provider.cc','tests/compute_provider_ggml/native_paged_test.cc',
               'tests/compute_batch/encoded_page_common_consumer.cc'] if label.startswith(('cpu','ubsan')) else
              ['src/compute_route_apple/apple_mature_float.cc','tests/compute_route_apple/native_cache_test.cc'] if label.startswith('apple') else
              ['third_party/ggml_vulkan_runtime/patches.json','third_party/ggml_vulkan_runtime/NOTICE.md',
               'cmake/HyleDependencyLock.json','tests/compute_route_vulkan/native_cache_test.cc'])
    for name in relevant:assert inputs[name]==sha[name],(label,name)

OUT.mkdir(parents=True,exist_ok=False)
result={
 'kind':'G04_G05_FINITE_Q8_ZERO_SCALE_AND_FP8_EXTREME_SCALE_STAGE',
 'verdict':'PASS_FINITE_NUMERIC_GRID_AND_CPU_FLOAT_CAST_NEGATIVE_CONTROL',
 'owners_remain':'Eleven owners AUDITED; not whole G04/G05 acceptance',
 'input_sha256':sha,
 'contract':'When the F32 absmax/127 rounds to F16 zero, the entire34-byte Q8 block is canonical zero before reciprocal/integer conversion. Nonzero stored scales keep original F32 reference rounding. This explicitly changes formerly nonzero codes with zero stored scale; decoded values are unchanged.',
 'qualified':[
   'Actual Windows CPU-only static shipping: two finite-boundary tests PASS',
   'Actual Air Mac16,12 Apple and Vulkan: each three source input dtypes, full34-byte oracle at14 amplitudes plus F32 maximum; both F16 zero-scale threshold neighbours, signed zero, tiny/subnormal and maximum inputs',
   'Actual Air Apple and Vulkan: each all11 existing/new encoder and attention tests PASS after the narrow product fix',
   'Actual CPU and RTX4070 CUDA FP8 E4M3FN: positive scales denorm_min, FLT_MIN and FLT_MAX with independent enumerated saturation/zero byte oracle',
   'Actual GCC14 CPU-only UBSan plus explicit float-cast-overflow: locked original ggml quantizer negative control exits1 at ggml-quants.c:296 on Inf-to-int8; repaired public encoder and original F2/Graph consumers9tests PASS',
   'Actual compile commands verify both undefined and float-cast-overflow instrumentation on original ggml quantizer, HYLE CPU encoder and both positive test TUs'],
 'history':'CPU7 ordinary diagnostic PASS is not sanitizer or full canonical-zero qualification. Original Apple/Vulkan numeric1 FAILs and all elapsed times retained; negative-control exit1 is expected proof, not a successful product run.',
 'P0':'CPU amax is accumulated during the existing dirty-block validation scan. Apple masks operands before normalization; Vulkan only private exact encoder branches before inverse/residual. No new metadata/queues/history decode; normal ggml quantizer and Copy/SetRows are unchanged.',
 'not_proven':['Exhaustive all-F32-input enumeration','GPU shader/driver sanitizer or LSan/TSan','New-domain full OOM/budget/cancel/unknown/concurrency/retirement risk grid','Installed static/shared and standalone-header qualification for the new domain','Immutable-candidate P1 and whole G04/G05'],
 'runs':[dict(label=label,**{k:v for k,v in record.items() if k!='inputs'}) for label,_,record,_ in RUNS],
 'cumulative_seconds':sum(record['cumulative_seconds'] for _,_,record,_ in RUNS)}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(OUT/'raw.zip','w',zipfile.ZIP_DEFLATED) as raw:
    for label,path,record,archive in RUNS:
        files=path.parent.glob('*') if not label.startswith(('apple','vulkan')) else path.parent.glob('*numeric-'+label.rsplit('-',1)[1]+'.*')
        for file in sorted(files):
            if file.is_file() and file.suffix!='.zip':raw.write(file,f'{label}/{file.name}')
        if archive:
            with zipfile.ZipFile(archive) as source:
                for name in [*names,'source-manifest.json']:
                    raw.writestr(f'inputs/{label}/{name}',source.read(name))
    for name in names:raw.write(ROOT/name,'inputs/current/'+name)
    for name in ['seal_numeric_stage.py','q8_numeric_ubsan.py','run_common_encoded_cpu.py',
                 'common_encoded_cuda.py','launch_common_cuda.py','apple_cache_air.py',
                 'launch_apple_cache.py','vulkan_cache_air.py','launch_vulkan_cache.py']:
        raw.write(BASE/name,'runners/'+name)
    for file in sorted((BASE/'numeric').glob('*')):
        if file.is_file() and file.suffix!='.zip':raw.write(file,'runners/numeric/'+file.name)
print(json.dumps({'runs':len(RUNS),'cumulative_seconds':result['cumulative_seconds'],'raw_bytes':(OUT/'raw.zip').stat().st_size}))
