#include <ggml-quants.h>
#include <array>
#include <cmath>
int main(){
 std::array<float,32> values{};
 values[0]=std::ldexp(1.F,-122);values[1]=-values[0];
 block_q8_0 output{};
 quantize_row_q8_0_ref(values.data(),&output,32);
 return 0;
}
