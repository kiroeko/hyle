from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
ROOT=Path('/mnt/c/public/project-hyle/hyle')
OUT=ROOT/'.scratch/inference-gaps/g04-g05/common-encoded'
SOURCE=Path('/root/hyle-scratch/compute-unified/source-7a7b4c3b')
BUILD=Path('/root/hyle-scratch/compute-unified/l-cpu-cuda/selected-graph/shared-sdk-build')
attempt=sys.argv[2];RUN=OUT/f'cuda-{attempt}';RUN.mkdir(exist_ok=False)
assert SOURCE.is_dir() and not (SOURCE/'.git').exists() and (BUILD/'CMakeCache.txt').exists()
with zipfile.ZipFile(sys.argv[1]) as archive:
 inputs=json.loads(archive.read('source-manifest.json'))
 for item in inputs:
  name=Path(item['path']);assert not name.is_absolute() and '..' not in name.parts
  raw=archive.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
  target=SOURCE/name
  if not target.exists() or target.read_bytes()!=raw:
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
identity={key:subprocess.check_output(command,text=True).strip() for key,command in [
 ('host',['uname','-a']),('compiler',['g++-14','--version']),('cuda',['/usr/local/cuda-13.3/bin/nvcc','--version']),
 ('gpu',['nvidia-smi','--query-gpu=name,driver_version,memory.total,memory.used,utilization.gpu','--format=csv,noheader'])]}
hook=OUT/'cuda-project.cmake';target='g04_g05_encoded_common_cuda'
hook_text='''if(PROJECT_NAME STREQUAL "hyle")
 function(g04_encoded_common_cuda)
  add_executable(g04_g05_encoded_common_cuda "'''+str(SOURCE/'tests/compute_batch/encoded_page_common_consumer.cc')+'''")
  target_compile_features(g04_g05_encoded_common_cuda PRIVATE cxx_std_23)
  target_compile_options(g04_g05_encoded_common_cuda PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_compile_definitions(g04_g05_encoded_common_cuda PRIVATE HYLE_ENCODED_CUDA=1)
  target_link_libraries(g04_g05_encoded_common_cuda PRIVATE hyle::graph hyle::compute GTest::gtest_main)
  hyle_stage_runtime(g04_g05_encoded_common_cuda)
 endfunction()
 cmake_language(DEFER CALL g04_encoded_common_cuda)
endif()
'''
if '--with-native-math' in sys.argv:
 hook_text=hook_text.replace('  target_compile_features(',
   '  target_sources(g04_g05_encoded_common_cuda PRIVATE "'+str(SOURCE/'tests/compute_provider_flashinfer/native_cache_test.cc')+'")\n  target_compile_features(',1)
if not hook.exists() or hook.read_text()!=hook_text:hook.write_text(hook_text)

env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
result={'state':'RUNNING','identity':identity,'inputs':inputs,'max_jobs':4,'stages':[],'cumulative_seconds':0,
 'scope':'Actual CUDA/CPU+CUDA encoded producer/F2/Direct/Graph source; no model/SDK/san/P1 verdict'}
def save():(RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n')
save()
commands=[('configure',['cmake','-S',str(SOURCE),'-B',str(BUILD),'-DCMAKE_PROJECT_INCLUDE='+str(hook)]),
 ('compile',['cmake','--build',str(BUILD),'--target',target,'--parallel','4']),
 ('tests',[str(BUILD/'bin'/target),'--gtest_output=xml:'+str(RUN/'tests.xml')])]
if '--numeric-only' in sys.argv:commands[-1][1].append('--gtest_filter=FlashinferCacheEncode.Finite*')
if '--negative-control' in sys.argv:
 commands.insert(-1,('negative-control',[str(BUILD/'bin'/target),
  '--gtest_filter=FlashinferCache.MixedFp8ShortKeyStrongWeightsInLoopAndRepackedTiles',
  '--gtest_output=xml:'+str(RUN/'negative-control.xml')]))
if '--skip-configure' in sys.argv:commands=commands[1:]
for stage,command in commands:
 start=time.monotonic();log=RUN/f'{stage}.log'
 stage_env=env;expected=0
 if stage=='negative-control':
  expected=1;stage_env=env.copy();old=OUT/'pre-short-k-library'
  stage_env['LD_LIBRARY_PATH']=str(old)+':'+str(BUILD/'bin')+':'+env['LD_LIBRARY_PATH']
  stage_env['LD_PRELOAD']=str(old/'libhyle_compute_provider_flashinfer.so.0.1.0')
  loaded=subprocess.check_output(['ldd',str(BUILD/'bin'/target)],env=stage_env,text=True)
  (RUN/'negative-control-loader.txt').write_text(loaded)
  assert str(old/'libhyle_compute_provider_flashinfer.so.0.1.0') in loaded
  result['negative_control_original_provider']=json.loads((old/'identity.json').read_text())
 with log.open('w') as stream:
  process=subprocess.Popen(command,env=stage_env,stdout=stream,stderr=subprocess.STDOUT)
  (RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}));print(f'{stage}: pid={process.pid}',flush=True)
  code=process.wait()
 elapsed=time.monotonic()-start;result['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 result['cumulative_seconds']+=elapsed;save();print(f'{stage}: exit={code}, elapsed={elapsed:.3f}s',flush=True)
 if stage=='negative-control' and code==1:
  import xml.etree.ElementTree as ET
  x=ET.parse(RUN/'negative-control.xml').getroot()
  assert x.attrib['tests']=='1' and x.attrib['failures']=='1'
  result['negative_control_expected_failure']=True;save()
 if code!=expected:
  result['state']='TERMINAL_FAIL';save();(RUN/'job.json').write_text(json.dumps({'state':result['state'],'exit_code':code}));raise SystemExit(code)
result['state']='TERMINAL_PASS';save();(RUN/'job.json').write_text(json.dumps({'state':result['state'],'exit_code':0}))
