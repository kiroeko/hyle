from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/f'.scratch/inference-gaps/g04-g05/common-encoded/cpu-{sys.argv[1]}'
OUT.mkdir(parents=True,exist_ok=False)
BUILD=ROOT/'.scratch/build-compute-v2-dev'
HOOK=ROOT/'.scratch/inference-gaps/g02/native-page-node/project.cmake'
target='g04_g05_encoded_common_pages'
body=HOOK.read_text(encoding='utf-8')
if target not in body:
 body+='''
if(PROJECT_NAME STREQUAL "hyle")
 function(g04_encoded_common_source)
  add_executable(g04_g05_encoded_common_pages
    "'''+(ROOT/'tests/compute_batch/encoded_page_common_consumer.cc').as_posix()+'''"
    "'''+(ROOT/'tests/compute_provider_ggml/native_paged_test.cc').as_posix()+'''"
    "'''+(ROOT/'tests/compute_provider_ggml/native_ragged_test.cc').as_posix()+'''")
  target_compile_features(g04_g05_encoded_common_pages PRIVATE cxx_std_23)
  target_compile_options(g04_g05_encoded_common_pages PRIVATE /W4 /WX /wd4324 /utf-8)
  target_link_libraries(g04_g05_encoded_common_pages PRIVATE hyle::graph hyle::compute GTest::gtest_main)
  hyle_stage_runtime(g04_g05_encoded_common_pages)
 endfunction()
 cmake_language(DEFER CALL g04_encoded_common_source)
endif()
'''
 HOOK.write_text(body,encoding='utf-8',newline='\n')
setup=subprocess.run(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.stdout.splitlines() if '=' in line and not line.startswith('=')))
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in paths if (ROOT/name).is_file() and not name.startswith(('evidence/','.scratch/','.git'))}
result={'state':'RUNNING','identity':{'host':env.get('COMPUTERNAME'),'compiler':env.get('VCTOOLSVERSION'),'routes':'cpu','source_pin':'check actual derived ggml after configure'},'inputs':inputs,
 'scope':'CPU-only actual encoder/F2/Direct/Graph source plus bounded native CPU numerical tests; no SDK/san/P1 verdict','max_jobs':4,'stages':[],'cumulative_seconds':0}
def save():(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
commands=[('configure',['cmake','-S',str(ROOT),'-B',str(BUILD)]),
 ('compile',['cmake','--build',str(BUILD),'--target',target,'--parallel','4']),
 ('tests',[str(BUILD/'bin'/f'{target}.exe'),'--gtest_output=xml:'+str(OUT/'tests.xml')])]
if '--numeric-only' in sys.argv:commands[-1][1].append('--gtest_filter=GgmlCpuCacheEncode.Finite*')
if '--new-only' in sys.argv:commands[-1][1].append('--gtest_filter=EncodedCommonPages.*')
if '--skip-configure' in sys.argv:commands=commands[1:]
for stage,command in commands:
 start=time.monotonic();log=OUT/f'{stage}.log'
 with log.open('wb') as stream:
  process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (OUT/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}));print(f'{stage}: pid={process.pid}',flush=True)
  code=process.wait()
 elapsed=time.monotonic()-start
 result['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 result['cumulative_seconds']+=elapsed;save();print(f'{stage}: exit={code}, elapsed={elapsed:.3f}s',flush=True)
 if code:
  result['state']='TERMINAL_FAIL';save();(OUT/'job.json').write_text(json.dumps({'state':result['state'],'exit_code':code}));raise SystemExit(code)
result['state']='TERMINAL_PASS';save();(OUT/'job.json').write_text(json.dumps({'state':result['state'],'exit_code':0}))
