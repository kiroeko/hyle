from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
ROOT=Path('/mnt/c/public/project-hyle/hyle')
SOURCE=Path('/home/kiro/hyle-f1/sanitizers/source-03242e7723cb')
BUILD=SOURCE.parent/'ubsan-03242e7723cb'
OUT=ROOT/'.scratch/inference-gaps/g04-g05/numeric'
RUN=OUT/f'ubsan-{sys.argv[2]}';RUN.mkdir(parents=True,exist_ok=False)
assert SOURCE.is_dir() and not (SOURCE/'.git').exists()
with zipfile.ZipFile(sys.argv[1]) as package:
 inputs=json.loads(package.read('source-manifest.json'))
 for item in inputs:
  name=Path(item['path']);assert not name.is_absolute() and '..' not in name.parts
  data=package.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
  dest=SOURCE/name
  if not dest.exists() or dest.read_bytes()!=data:
   dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
control=OUT/'q8-reference-control.cc'
control.write_text('''#include <ggml-quants.h>
#include <array>
#include <cmath>
int main(){
 std::array<float,32> values{};
 values[0]=std::ldexp(1.F,-122);values[1]=-values[0];
 block_q8_0 output{};
 quantize_row_q8_0_ref(values.data(),&output,32);
 return 0;
}
''')
hook=OUT/'ubsan-project.cmake'
body='''if(PROJECT_NAME STREQUAL "hyle")
 set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
 add_subdirectory("/mnt/c/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6" g04-numeric-gtest EXCLUDE_FROM_ALL)
 function(g04_numeric)
  target_compile_options(ggml-base PRIVATE -fsanitize=float-cast-overflow -fno-sanitize-recover=all)
  target_compile_options(hyle_compute_provider_ggml PRIVATE -fsanitize=float-cast-overflow -fno-sanitize-recover=all)
  add_executable(g04_q8_numeric_ubsan "@SOURCE@/tests/compute_provider_ggml/native_paged_test.cc" "@SOURCE@/tests/compute_batch/encoded_page_common_consumer.cc")
  target_compile_features(g04_q8_numeric_ubsan PRIVATE cxx_std_23)
  target_link_libraries(g04_q8_numeric_ubsan PRIVATE hyle::compute hyle::graph GTest::gtest_main)
  hyle_apply_sanitizer(g04_q8_numeric_ubsan)
  target_compile_options(g04_q8_numeric_ubsan PRIVATE -fsanitize=float-cast-overflow -fno-sanitize-recover=all)
  hyle_stage_runtime(g04_q8_numeric_ubsan)
  add_executable(g04_q8_reference_control "@CONTROL@")
  target_compile_features(g04_q8_reference_control PRIVATE cxx_std_23)
  target_include_directories(g04_q8_reference_control PRIVATE "@GGML@/src")
  target_link_libraries(g04_q8_reference_control PRIVATE ggml-base hyle::compute)
  hyle_apply_sanitizer(g04_q8_reference_control)
  target_compile_options(g04_q8_reference_control PRIVATE -fsanitize=float-cast-overflow -fno-sanitize-recover=all)
  hyle_stage_runtime(g04_q8_reference_control)
 endfunction()
 cmake_language(DEFER CALL g04_numeric)
endif()
'''.replace('@SOURCE@',str(SOURCE)).replace('@CONTROL@',str(control)).replace('@GGML@',chr(36)+'{HYLE_GGML_SOURCE_DIR}')
if not hook.exists() or hook.read_text()!=body:hook.write_text(body)
result={'state':'RUNNING','max_jobs':4,'inputs':inputs,'stages':[],'cumulative_seconds':0,
 'scope':'Actual CPU-only UBSan plus explicit float-cast-overflow, original native reference negative control and public encoded F2/Graph positive consumers; no GPU/LSan/TSan/SDK/P1 claim',
 'identity':{'host':subprocess.check_output(['uname','-a'],text=True).strip(),
 'compiler':subprocess.check_output(['g++-14','--version'],text=True).splitlines()[0]}}
def save():(RUN/'result.json').write_text(json.dumps(result,indent=2)+'\n')
env=os.environ.copy();env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
commands=[
 ('configure',['cmake','-S',str(SOURCE),'-B',str(BUILD),'-DCMAKE_PROJECT_INCLUDE='+str(hook)]),
 ('compile',['cmake','--build',str(BUILD),'--target','g04_q8_numeric_ubsan','g04_q8_reference_control','--parallel','4']),
 ('negative-control',[str(BUILD/'bin/g04_q8_reference_control')]),
 ('tests',[str(BUILD/'bin/g04_q8_numeric_ubsan'),'--gtest_filter=GgmlCpuCacheEncode.*:EncodedCommonPages.*','--gtest_output=xml:'+str(RUN/'tests.xml')])]
save()
for stage,command in commands:
 if stage=='negative-control':
  rows=json.loads(subprocess.check_output(['ninja','-C',str(BUILD),'-t','compdb'],text=True))
  checked=[]
  for name in ['ggml-quants.c','ggml_cpu_provider.cc','native_paged_test.cc','encoded_page_common_consumer.cc']:
   matching=[r for r in rows if r['file'].endswith('/'+name)]
   assert matching and all('-fsanitize=undefined' in r['command'] and '-fsanitize=float-cast-overflow' in r['command'] for r in matching),name
   checked.extend(matching)
  (RUN/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2)+'\n')
 start=time.monotonic();log=RUN/f'{stage}.log'
 with log.open('w') as stream:
  process=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
  (RUN/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid}))
  print(f'{stage}: pid={process.pid}',flush=True);code=process.wait()
 elapsed=time.monotonic()-start;result['cumulative_seconds']+=elapsed
 result['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 print(f'{stage}: exit={code} elapsed={elapsed:.3f}s',flush=True)
 expected=1 if stage=='negative-control' else 0
 if stage=='negative-control' and code==1:
  assert 'outside the range of representable values' in log.read_text()
  result['actual_original_reference_float_cast_failure']=True
 result['state']='RUNNING' if code==expected else 'TERMINAL_FAIL';save()
 if code!=expected:
  (RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
result['state']='TERMINAL_PASS';save()
(RUN/'job.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
