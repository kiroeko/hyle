from pathlib import Path
import subprocess,sys
script=Path(__file__).parent/'g07_apple_host_risk.py';attempt=sys.argv[1]
for mode in ['asan','ubsan','tsan']:
 subprocess.run([sys.executable,str(script),mode,attempt,attempt],check=True)
print('ALL_THREE_HOST_FACETS_PASS',attempt,flush=True)
