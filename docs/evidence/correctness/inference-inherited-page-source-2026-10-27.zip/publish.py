"""Offline receipt packaging only; does not build or execute a consumer."""
from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent
R = W.parents[1]
BASE = R / '.scratch/inference-pending-append-20261027'
OUT = R / 'docs/evidence/correctness/inference-inherited-page-source-2026-10-27'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def exact(path, expected):
    actual = pin(path)
    assert actual['bytes'] == expected['bytes'], (path, actual, expected)
    assert actual['sha256'] == expected['sha256'], (path, actual, expected)
    return actual


plan, ready, summary = (read(W / x) for x in ('plan.json', 'ready.json', 'summary.json'))
assert summary['status'] == 'PASS' and summary['process']['exit'] == 0
assert summary['process']['pid'] == 7736
assert len(plan['units']) == len(ready['compiled']) == 3
assert ready['link']['exit'] == 0
assert all(x['process']['exit'] == 0 for x in ready['compiled'])
cases = ET.parse(W / 'results.xml').getroot().findall('./testsuite/testcase')
assert len(cases) == 18 and len(plan['tests']) == 18
assert {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases} == set(plan['tests'])
assert all(x.attrib.get('status') == 'run' and not any(
    x.findall(tag) for tag in ('failure', 'error', 'skipped')) for x in cases)
assert not list(W.rglob('*failure.json'))

members = {}


def add(path, archive):
    path = Path(path)
    assert archive not in members
    assert path.suffix.lower() not in {'.obj', '.exe', '.pdb', '.dll', '.lib', '.exp'}
    data = path.read_bytes()
    members[archive] = (path, data)


sources = []
for original in plan['sources']:
    relative = Path(original['path']).relative_to(R)
    snapshot = W / 'source' / relative
    exact(snapshot, original)
    add(snapshot, 'source/' + relative.as_posix())
    sources.append({**original, 'archive': 'source/' + relative.as_posix(),
                    'origin': 'as-run frozen snapshot; not reconstructed from current working tree'})

for name in ('check.py', 'plan.json', 'ready.json', 'compiled.json', 'link-inputs.json',
             'summary.json', 'results.xml'):
    add(W / name, 'records/' + name)
for stage in ('compile/resources', 'compile/append', 'compile/paged-test', 'link', 'run'):
    for path in sorted((W / stage).iterdir()):
        if path.suffix.lower() in {'.json', '.log'}:
            add(path, 'records/' + path.relative_to(W).as_posix())
add(__file__, 'publish.py')
add(BASE / 'check.py', 'baseline/check.py')
add(BASE / 'link-inputs-final.json', 'baseline/link-inputs-final.json')
runtime = Path(ready['runtime']['path'])
exact(runtime, ready['runtime'])
add(runtime, 'records/runtime.json')

baseline = read(BASE / 'link-inputs-final.json')
linked = read(W / 'link-inputs.json')
assert len(baseline) == len(linked) == 233
changes = [(a, b) for a, b in zip(baseline, linked) if a != b]
assert len(changes) == 3
assert {b['path'] for _, b in changes} == {x['object']['path'] for x in ready['compiled']}
exact(W / 'plan.json', ready['plan'])
exact(W / 'link-inputs.json', ready['inputs'])
for unit in plan['units']:
    metadata = read(W / 'compile' / unit['name'] / 'dependencies.json')
    assert Path(metadata['Data']['Source']).resolve() == Path(unit['source']['path']).resolve()

manifest = [dict(archive=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
            for name, (_, data) in sorted(members.items())]
archive_path = OUT.with_suffix('.zip')
archive_path.parent.mkdir(parents=True, exist_ok=True)
assert not archive_path.exists() and not OUT.with_suffix('.json').exists()
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, (_, data) in sorted(members.items()):
        archive.writestr(name, data)
    archive.writestr('manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(archive_path, 'r') as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members) | {'manifest.json'}
    for item in manifest:
        data = archive.read(item['archive'])
        assert len(data) == item['bytes']
        assert hashlib.sha256(data).hexdigest() == item['sha256']
    assert json.loads(archive.read('manifest.json')) == manifest

reused_test_sources = [x for x in read(BASE / 'plan.json')['sources'] if
    x['path'].replace('\\', '/').endswith(('/tests/graph/output_source_cuda_test.cc',
                                         '/tests/graph/region_provider_test.cc'))]
receipt = {
    'date': '2026-10-27',
    'status': 'PASS',
    'scope': 'Flat inherited page permissions and genuine ready-origin publication, with two real CUDA A-to-B-to-C page-boundary/COW journeys and finite adjacent regressions.',
    'environment': {
        'platform': 'Windows', 'gpu': 'NVIDIA GeForce RTX 4070', 'compute_capability': '8.9',
        'vram_MiB_reported': 12281,
        'basis': 'Original run/stderr.log. No new hardware query, exclusivity or frequency claim.',
        'compiler': plan['units'][0]['command'][0],
        'runtime': ready['runtime'],
    },
    'build': {
        'CXX_TUs': 3, 'compile_attempts': 3, 'compile_failures': 0,
        'link_attempts': 1, 'successful_links': 1,
        'test_processes': 1, 'NVCC_TUs': 0, 'SDK_rebuilds': 0, 'downloads': 0,
        'baseline_inputs': 233, 'final_inputs': 233, 'replaced_inputs': 3, 'retained_inputs': 230,
        'baseline_receipt': 'inference-pending-append-source-2026-10-27.json',
        'baseline_closure': plan['baseline'],
        'compiled': ready['compiled'], 'link': ready['link'],
        'closure': ready['inputs'],
        'closure_replacements': [{'old': a, 'new': b} for a, b in changes],
        'reused_test_sources': reused_test_sources,
        'reuse_boundary': 'Only resources.cc, paged_append.cc and the paged Source test TU were recompiled. Other 230 pinned input records are unchanged from the preceding final closure; their prior runtime/source/ABI evidence is reused, not rerun as separate build attempts.',
        'outputs': 'As-run OUT/PDB/IMPLIB all target this window scratch. No binary payload is in this archive.',
    },
    'execution': {
        'process': summary['process'], 'image': summary['image'],
        'passed': 18, 'failed': 0, 'skipped': 0,
        'tests': plan['tests'],
        'command': 'records/run/command.json', 'xml': 'records/results.xml',
        'failures_in_this_window': [],
    },
    'checks': [
        'B Source prepares while A is not captured yet; after B submission, inherited untouched physical prefixes flatten to original permission slots, without a recursive submission/terminal owner chain.',
        'Page-boundary A-to-B-to-C: B has no COW GPU reads but still imports the complete A verdict; C reads B own fresh page plus A inherited pages after A true publication changed its fresh writer into append mode.',
        'COW A-to-B-to-C: B replaces A tail page with its own fresh page; C reads the B result. After unrelated A/returned-transaction aliases are dropped, the replaced original page can be reacquired while B Source, B frame and C bundle remain alive; live inherited pages remain protected.',
        'Publication while B is pending is rejected. After real B retirement, a complete same-geometry foreign-root guard set is rejected; subsequent genuine publication succeeds without poisoning the Source.',
        'Existing explicit and private-owned layout controls, A-to-B COW and empty-copy effects, I32/Store Source whole-failure, Hybrid reuse-only, and nominated-writer adjacent cases also pass in this same image/process.',
    ],
    'sources': sources,
    'limits': [
        'No complete inference-engine continuous pipeline, throughput/TPS, overlap speedup, memory benchmark, HTTP service, other OS/backend or new native fault-injection proof.',
        'This is the original single shared Compute Queue Source contract; it does not establish delegated Apple/Vulkan pending imports or native indexed GDN/conv predecessor wiring.',
        'The existing own-ready contribution versus registered-ready matching scan remains. Pending-previous preparation contributes ownready=0 and inherited prefixes; this window does not claim a general ready-path complexity reduction.',
        'True typed publication remains predecessor-first and requires whole mathematical success plus actual retirement. Raw capacity/prefix carriers are never ready permissions.',
        'The archived orchestration script uses the preserved predecessor cache helpers; actual compile/link/run commands, inputs and dependencies are archived directly. This ZIP is not a standalone SDK or binary distribution.',
        'Elapsed test-process time is a correctness-run duration, not a performance measurement.',
    ],
    'archive': {
        **pin(archive_path), 'path': archive_path.relative_to(R).as_posix(),
        'member_count': len(manifest) + 1,
        'payload_bytes': sum(x['bytes'] for x in manifest),
        'verification': 'Every ZIP member was decompressed and compared with its exact expected bytes and SHA-256; manifest.json was independently parsed. No EXE/OBJ/PDB/DLL/LIB/EXP, SDK or model payload included.',
    },
}
receipt_path = OUT.with_suffix('.json')
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
report = {'receipt': pin(receipt_path), 'archive': pin(archive_path),
          'members_verified': len(manifest) + 1, 'tests_passed': len(cases)}
(W / 'publish-result.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
