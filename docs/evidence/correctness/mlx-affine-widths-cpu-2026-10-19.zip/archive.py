import hashlib,json,pathlib,xml.etree.ElementTree as ET,zipfile
STAGE=pathlib.Path(__file__).resolve().parent
ROOT=STAGE.parents[3]
DEST=ROOT/'docs/evidence/correctness/mlx-affine-widths-cpu-2026-10-19.zip'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def sha(b): return hashlib.sha256(b).hexdigest()
def save(name,value): (STAGE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for attempt,count in [('run-cpu-a1',13),('run-cpu-a2',17)]:
    folder=STAGE/'checks/current'/attempt
    summary=read(folder/'summary.json')
    assert summary['passed'] and summary['counts']==dict(tests=count,failures=0,errors=0,skipped=0)
    xml=ET.parse(folder/'cpu.xml').getroot()
    assert int(xml.attrib['tests'])==count and int(xml.attrib['failures'])==0
    assert not xml.findall('.//skipped')
manifest=read(STAGE/'validated-source-manifest.json')
for row in manifest:
    b=(STAGE/'validated-source'/row['path']).read_bytes()
    assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
after=[]
for row in read(STAGE/'before.json'):
    rel=row['path']; validated=STAGE/'validated-source'/rel
    source=validated if validated.exists() else ROOT/rel
    b=source.read_bytes(); target=STAGE/'after'/rel
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
    after.append(dict(path=rel,bytes=len(b),sha256=sha(b),compiled_dependency=validated.exists()))
save('after.json',after)
plan=read(STAGE/'checks/current/plan.json')
image=read(STAGE/'checks/current/cpu-image.json')
save('archive-summary.json',dict(state='CPU common affine-width and native-capacity closeout.',
    original_tests=13,final_tests=17,failures=0,skipped=0,image=image,
    link_plan=dict(path='checks/current/cpu-link-plan.json',sha256=sha((STAGE/'checks/current/cpu-link-plan.json').read_bytes())),
    capacity_fresh=['torch_cpu_program.cc','cpu_mlx_quantized_test.cc Direct','cpu_mlx_quantized_test.cc Graph'],
    capacity_reused=10,source_snapshots=len(manifest),
    scope='Schema/continuous4,5,6,8bit packing, Direct/Graph selected cases and native I64 capacity checks only; no all-artifact/model, speed or cross-platform bit-parity claim.',
    graph_snapshot='Retained Graph source context was frozen before the next batch edits: executable2ad22f60... and plan_state cb8b127d.... The CPU17 image validates that older layout; later live Graph edits are outside this archive.',
    dependency_scope='Actual compiled-owner repository dependency snapshots plus original argv/sourceDependencies/identity records; external compiler/SDK/cache inputs remain identity references and are not copied.',
    cleanup='None. Current CPUobjects/link plan remain available to Vulkan.'))
excluded={'.exe','.obj','.o','.lib','.a','.exp','.map','.pdb','.dll','.pyc','.tmp','.cubin','.spv','.nsys-rep','.sqlite'}
payload=[p for p in STAGE.rglob('*') if p.is_file() and p.suffix not in excluded
    and p.name!='archive-receipt.json' and '__pycache__' not in p.parts and 'tmp' not in p.relative_to(STAGE).parts]
hashes={p.relative_to(STAGE).as_posix():sha(p.read_bytes()) for p in payload}
DEST.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in sorted(payload): archive.write(p,p.relative_to(STAGE).as_posix())
    archive.writestr('payload-sha256.json',json.dumps(hashes,indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist())==set(hashes)|{'payload-sha256.json'}
    for name,digest in hashes.items(): assert sha(archive.read(name))==digest
save('archive-receipt.json',dict(path=str(DEST),bytes=DEST.stat().st_size,sha256=sha(DEST.read_bytes()),
    payloads=len(hashes),crc_verified=True,payload_sha256_verified=True,original_tests=13,final_tests=17,failures=0,skipped=0))
print(json.dumps(read(STAGE/'archive-receipt.json'),indent=2))
