from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parents[1]
spec = importlib.util.spec_from_file_location('width_run_helpers', ARCH / 'cuda-grouped-fusion/build.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
b, c = helper.b, helper.c
BUILD = STAGE / 'checks/current'
attempt = 1
while (BUILD / ('run-cpu-a' + str(attempt))).exists():
    attempt += 1
OUT = BUILD / ('run-cpu-a' + str(attempt))
OUT.mkdir()
(OUT / 'tmp').mkdir()
plan = c.read(BUILD / 'cpu-link-plan.json')
env, _ = b.environment(plan['command'], [x['path'] for x in plan['inputs']], OUT)
command = [str(BUILD / 'cpu.exe'),
    '--gtest_filter=OperationModelOps.Mlx*:OperationModelOps.ArtifactDecodeRejectsWrongPackingAndPrecisionPorts:CpuMlxQuantizedDirect.*:CpuMlxQuantizedGraph.*',
    '--gtest_output=xml:' + str(OUT / 'cpu.xml')]
try:
    c.execute('cpu', command, env, OUT)
finally:
    if (OUT / 'cpu.xml').exists():
        root = ET.parse(OUT / 'cpu.xml').getroot()
        cases = list(root.iter('testcase'))
        counts = dict(tests=len(cases), failures=sum(x.find('failure') is not None for x in cases),
            errors=sum(x.find('error') is not None for x in cases),
            skipped=sum(x.find('skipped') is not None for x in cases))
        c.save(OUT / 'summary.json', dict(passed=bool(cases) and not any(counts[k] for k in ('failures','errors','skipped')),
            counts=counts, observed=[x.get('classname') + '.' + x.get('name') for x in cases],
            image=b.identity(BUILD / 'cpu.exe')))
        print('TESTS', counts, flush=True)
