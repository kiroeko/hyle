cmake_minimum_required(VERSION 3.24)
include("${CMAKE_CURRENT_LIST_DIR}/../../../../../cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(mlx_cpu_quant iree_vulkan_runtime_patches)
message(STATUS "Selected MLX CPU and IREE Vulkan in-tree audits passed")
