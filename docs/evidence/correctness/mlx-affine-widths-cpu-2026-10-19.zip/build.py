"""Increment only the CPU header owners and MLX/schema tests; reuse native SDKs."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parents[1]
ROOT = ARCH.parents[1]
spec = importlib.util.spec_from_file_location('width_common_helpers', ARCH / 'cuda-grouped-fusion/build.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
b, c = helper.b, helper.c
OUT = STAGE / 'checks/current'
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'tmp').mkdir(exist_ok=True)
recipes = c.read(ARCH / 'recurrent-gdn-schema/host-recipes.json')['compile']
base = c.read(ARCH / 'decode-host-path-review/checks/20261019T133822-fixture/cpu-link-plan.json')
template = recipes[29]['command_template']
specs = [('weight-decode', ROOT / 'src/compute_ops/weight_decode.cc', template, None)]
for i in (0, 1, 2, 3, 4, 5, 6, 7, 8):
    row = recipes[i]
    source = ROOT / row['source_name']
    suffix = source.parent.name + '-' + source.stem + '.obj'
    matches = [x for x in base['inputs'] if Path(x['path']).name.replace('--', '-').endswith(suffix)]
    assert len(matches) == 1, (suffix, matches)
    specs.append((row['tag'], source, row['command_template'], matches[0]['path']))
specs.extend((
    ('ops-test', ROOT / 'tests/compute_ops/operation_test.cc', template, None),
    ('mlx-direct-test', ROOT / 'tests/compute_route_cpu/cpu_mlx_quantized_test.cc', template, None),
    ('mlx-graph-test', ROOT / 'tests/compute_route_cpu/cpu_mlx_quantized_test.cc',
        template + ['/DHYLE_TEST_GRAPH_ROUTE_CPU=1'], None)))
removed_tests = {'workspace-test.obj', '28-cpu-provider-test.obj', '29-ops-test.obj',
    '10-executable_test.obj', 'region-test.obj', '8-constant_artifact_cache_test.obj', 'candidate.obj'}
replacements = {c.key(old): str(OUT / (tag + '.obj')) for tag, _, _, old in specs if old}
command = [replacements.get(c.key(x), x) for x in base['command']
    if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))
    and Path(x).name not in removed_tests]
command[1:1] = [str(OUT / (tag + '.obj')) for tag, _, _, old in specs if not old]
command += ['/OUT:' + str(OUT / 'cpu.exe'), '/MAP:' + str(OUT / 'cpu.map'), '/IMPLIB:' + str(OUT / 'cpu.lib')]
env, _ = b.environment(base['command'], [x['path'] for x in base['inputs']], OUT)
rows = []
for tag, source, recipe, old in specs:
    identity = OUT / (tag + '-identity.json')
    compile_command = b.host_command(recipe, source, tag, OUT)
    # A successful unchanged source/dependency/object can be reused after a
    # fixture correction. Only its affected image is linked again below.
    if identity.exists():
        prior = c.read(identity)
        depfile = OUT / (tag + '-deps.json')
        dep = c.read(depfile)['Data']
        dependencies = [Path(dep['Source']), *(Path(x) for x in dep['Includes'])]
        if prior['command'] == compile_command and b.same(prior['object']) and all(
                b.same(row) for row in prior.get('dependencies', [])) and prior.get('dependencies'):
            rows.append(prior)
            print('REUSE', tag, flush=True)
            continue
    attempt = 1 + len(list(OUT.glob(tag + '-a*.command.json')))
    data = source.read_bytes()
    (OUT / (tag + '-source-a' + str(attempt) + source.suffix)).write_bytes(data)
    c.execute(tag + '-a' + str(attempt), compile_command, env, OUT)
    dep = c.read(OUT / (tag + '-deps.json'))['Data']
    dependencies = [Path(dep['Source']), *(Path(x) for x in dep['Includes'])]
    row = dict(tag=tag, command=compile_command, source=b.identity(source),
        object=b.identity(OUT / (tag + '.obj')),
        dependencies=[b.identity(p) for p in dependencies], old_object=old)
    c.save(identity, row)
    rows.append(row)
    print('COMPILED', tag, flush=True)
inputs = [Path(x) for x in command if x.lower().endswith(('.obj', '.lib')) and Path(x).is_absolute()]
plan = dict(command=command, inputs=[b.identity(p) for p in inputs], compile=rows,
    source_header=b.identity(ROOT / 'include/hyle/compute/model_ops.h'),
    removed_unrelated_test_owners=sorted(removed_tests), SDK_build=False, GPU_run=False)
prior_plan = OUT / 'cpu-link-plan.json'
if prior_plan.exists() and c.read(prior_plan) == dict(command=command, inputs=plan['inputs']) and (OUT / 'cpu.exe').exists():
    print('REUSE_CPU_IMAGE', flush=True)
else:
    attempt = 1 + len(list(OUT.glob('cpu-link-a*.command.json')))
    c.execute('cpu-link-a' + str(attempt), command, env, OUT)
c.save(prior_plan, dict(command=command, inputs=plan['inputs']))
c.save(OUT / 'plan.json', plan)
c.save(OUT / 'cpu-image.json', b.identity(OUT / 'cpu.exe'))
c.save(OUT / 'summary.json', dict(passed=True, host_owners=len(rows), SDK_build=False, GPU_run=False))
print('BUILD_COMPLETE', OUT, flush=True)
