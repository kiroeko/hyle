"""Only replace a verified stale Hyle mapping archive member; preserve frozen math/TU."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;R=B.parents[1];OLD=B/'engine-cpu-current1';NEW=B/'engine-cpu-current2'
spec=importlib.util.spec_from_file_location('cpu_build',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,x):b.save(p,x)
def require(row):
 p=Path(row['path']);p=p if p.is_absolute()else R/p
 actual=b.identity(p)
 if any(actual[k]!=row[k]for k in ['bytes','sha256']):raise ValueError('Retained input changed: '+str(p))
 return actual
def main():
 NEW.mkdir(exist_ok=False);(NEW/'bin').mkdir()
 ready=read(OLD/'ready.json')
 for key in ['image','native','environment','source','pins']:require(ready[key])
 if ready['image']['sha256']!='b57ff968cb526b3ce969c79823167eac2ebf7344d1cd493b403a62b136031377':raise ValueError('Wrong frozen CPU image')
 originalpins=read(OLD/'pinned-closure.json')
 for row in originalpins.values():
  if isinstance(row,dict)and 'sha256'in row:require(row)
 retained=read(R/originalpins['retained_input_pins']['path'])
 for row in retained:require(row)
 mapping_path=R/'.scratch/dspark-original-experts-20261023/compile3/mapping-view/identity.json';mapping=read(mapping_path)
 for row in [mapping['source'],mapping['object'],*mapping['dependencies']]:require(row)
 if mapping['source']['sha256']!='725496e5d62a7798d93c2616c674e6f46181b26a1c44bfda1c4f9a56f606197c' or mapping['object']['sha256']!='d358aa12e1d24c3270360ba30051295d1782c2265bb773e55c65a906078d44e5':raise ValueError('Wrong mapping fix')
 cc=read(OLD/'compile-command.json')[0]
 env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
 original=read(OLD/'link-command.json')
 command=[]
 for arg in original:
  if arg.startswith(('/OUT:','/PDB:','/IMPLIB:')):arg=arg.replace(str(OLD),str(NEW))
  command.append(arg)
 command.insert(2,mapping['object']['path'])
 save(NEW/'link-command.json',command)
 save(NEW/'original-link-inputs.json',[b.identity(p)for p in original if p.lower().endswith(('.obj','.lib'))and Path(p).is_file()])
 b.execute(command,env,NEW/'link',180)
 native=NEW/'bin'/Path(ready['native']['path']).name;os.link(ready['native']['path'],native)
 runtime=read(OLD/'runtime-environment.json');runtime['PATH']=runtime['PATH'].replace(str(OLD/'bin'),str(NEW/'bin'));save(NEW/'runtime-environment.json',runtime)
 pins=dict(original_image=ready['image'],original_plan=b.identity(B/'run-ready-plan.json'),original_ready=b.identity(OLD/'ready.json'),original_link_recipe=b.identity(OLD/'link-command.json'),original_frozen_main=b.identity(OLD/'main.obj'),original_source=ready['source'],original_closure=ready['pins'],original_inputs=b.identity(NEW/'original-link-inputs.json'),mapping_identity=b.identity(mapping_path),mapping_source=mapping['source'],mapping_object=mapping['object'],mapping_dependencies=mapping['dependencies'],link_recipe=b.identity(NEW/'link-command.json'),delta='One explicit mapping-view.obj before unchanged cached libraries; all other exact frozen link inputs retained. Old mem_vm archive flags0x45 vs audited mapping flags0xc5.',product_TUs_compiled=0,SDK_builds=0,HTTP=0)
 save(NEW/'pinned-closure.json',pins)
 fixed=dict(kind='Derivative frozen FP8 CPU engine with corrected Hyle mapping closure only',image=b.identity(NEW/'bin/hyle.exe'),native=b.identity(native),environment=b.identity(NEW/'runtime-environment.json'),source=ready['source'],pins=b.identity(NEW/'pinned-closure.json'),product_TUs_compiled=0,SDK_builds=0,HTTP=0)
 save(NEW/'ready.json',fixed)
 probe=NEW/'host-mapping-import';probe.mkdir()
 source=B/'host-mapping-import-v2.cc';obj=probe/'probe.obj'
 compile=[cc,'/nologo','/c','/std:c++latest','/EHsc','/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/O2','/MD','/permissive-','/W4','/WX','/wd4324','/wd4702','/DHYLE_STATIC','/DNOMINMAX','/I'+str(R/'include'),'/I'+str(R),'/sourceDependencies',str(probe/'dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(probe/'probe.pdb')]
 b.execute(compile,env,probe/'compile',120)
 removed=[];link=[]
 for arg in command:
  if arg==str(OLD/'main.obj')or arg.lower().endswith('engine/main.cc.obj')or arg.lower().endswith('engine\\main.cc.obj'):
   removed.append(arg);continue
  if arg.startswith('/OUT:'):arg='/OUT:'+str(probe/'probe.exe')
  elif arg.startswith('/PDB:'):arg='/PDB:'+str(probe/'probe.pdb')
  elif arg.startswith('/IMPLIB:'):arg='/IMPLIB:'+str(probe/'probe.lib')
  link.append(arg)
 if len(removed)!=2:raise ValueError('Expected exactly frozen model and engine dispatch app TU: '+repr(removed))
 link.insert(2,str(obj));save(probe/'link-command.json',link)
 b.execute(link,env,probe/'link',180)
 runenv=dict(os.environ,PATH=runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 b.execute([str(probe/'probe.exe'),str(probe/'nonzero-offset-original.bin')],runenv,probe/'run',30)
 save(probe/'result.json',dict(passed=True,source=b.identity(source),object=b.identity(obj),image=b.identity(probe/'probe.exe'),mapping_object=mapping['object'],process=b.identity(probe/'run/process.json'),SDK_builds=0,HTTP=0))
 print(json.dumps(dict(ready=fixed,smallcheck=True,product_TUs_compiled=0,SDK_builds=0,HTTP=0)))
if __name__=='__main__':main()
