"""Read-only postrun checks for the two frozen finite FP8 CPU journeys.

Never publishes, prepares, runs a model, imports the runner or opens HTTP.
Original body authentication remains the frozen publisher/runner's job.
"""
from pathlib import Path
import argparse, copy, hashlib, json, sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
EOS = {248044, 248046}  # The pinned engine's explicit generation terminators.

def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def require(condition, message):
    if not condition: raise ValueError(message)
def expected_cases(plan):
    pin = plan['acquisition_plan']; path = ROOT/pin['path']
    require(identity(path) == pin, 'Frozen original acquisition plan changed')
    roles = load(path)['selected_roles']; expected = {}
    for case in plan['cases']:
        selected = [r for r in roles if case['mtp'] or not r['name'].startswith('mtp.')]
        bank = {r['name']: r for r in selected}
        scales = [r for r in selected if r['name'].endswith('.weight_scale_inv')]
        peaks = []
        for scale in scales:
            code = bank[scale['name'][:-17]+'.weight']; n, k = code['shape']
            require(code['dtype'] == 'F8_E4M3' and scale['dtype'] == 'BF16' and
                    k % 128 == 0 and scale['shape'] == [(n+127)//128, k//128],
                    'Frozen FP8 code/scale geometry differs')
            require(code['bytes'] == n*k and scale['bytes'] == ((n+127)//128)*(k//128)*2,
                    'Frozen FP8 code/scale extent differs')
            # Original code+BF16 scale mapping, canonical code+F32 scale,
            # and the temporary exact widened F32 scale grid.
            peaks.append(2*code['bytes']+5*scale['bytes'])
        raw = sum(r['bytes'] for r in selected)
        expected[case['name']] = dict(canonical_weight_bytes=raw+sum(r['bytes'] for r in scales),
            fp8_import_temporary_group_peak_bytes=max(peaks),
            original_host_weight_bytes=raw, original_device_weight_bytes=0,
            canonical_weight_tensors=len(selected)-len(scales), fp8_block128_groups=len(scales),
            text_tensors=case['physical_text_roles'], mtp_tensors=case['physical_mtp_roles'])
    return expected

def check_report(report, case, plan, expected):
    ids = report['generated_ids']; n = len(ids); limit = plan['maximum_outputs']
    require(0 < n <= limit and report['generated_tokens'] == n and
            all(type(x) is int and 0 <= x < plan['geometry']['vocabulary'] for x in ids),
            'Invalid emitted token inventory')
    require(not any(x in EOS for x in ids[:-1]) and (n == limit or ids[-1] in EOS),
            'Generation stopped without the fixed quota or terminal pending token')
    require(report['backend'] == 'cpu' and report['mtp'] is case['mtp'] and
            report['score_dtype'] == 'F32' and report['score_policy'] == 'bf16_inputs_f32_output',
            'Actual route or score boundary differs')
    require(report['requested_steps'] == limit and report['prefill_graph_calls'] == 1 and
            report['prefill_target_rows'] == plan['P'] == 1 and report['visible_tokens'] == n and
            report['committed_target_rows'] == n and report['committed_target_decode_rows'] == n-1,
            'Committed target frontier does not preserve one final emitted pending token')
    require(all(report.get(k) == v for k, v in expected.items()),
            'Original/canonical weight, scale, role or import-peak inventory differs')
    policy = dict(plan['policy']); policy.pop('block_size')
    require(report['fp8_block128_policy'] in (plan['policy'], policy), 'FP8 reader/math policy differs')
    require(report['cache_requested_byte_limit'] == plan['cache_limit_bytes'] and
            0 <= report['cache_live_requested_bytes'] <= report['cache_peak_requested_bytes'] <= plan['cache_limit_bytes'],
            'Finite requested cache accounting differs')
    if not case['mtp']:
        require(report['sampling'] == 'greedy' and report['sampling_draw_cursor'] == 0 and
                report['decode_input_ids'] == ids[:-1] and report['decode_graph_calls'] == n-1 and
                report['actual_target_rows'] == n and report['actual_draft_rows'] == 0 and
                report['draft_rounds'] == report['draft_rows'] == report['consumed_drafts'] == 0,
                'Ordinary journey includes inconsistent input, state or RNG accounting')
        return dict(coverage='complete_finite_ordinary_journey', generated_ids=ids,
                    emitted_pending=ids[-1], actual_mtp_proposals=0)
    require((report['sampling'], report['mtp_max_drafts'], report['sampling_temperature'],
             report['sampling_top_k'], report['sampling_top_p'], report['sampling_seed'],
             report['mtp_acceptance_policy']) == ('random', 1, 1, 8, 0.9, 123, 'min_one_p_over_q'),
            'K1 stochastic policy differs')
    emitted = [ids[0]]; proposals = consumed = verified = draft_rows = 0; lag = 0
    rounds = report['rounds']
    for row in rounds:
        require(emitted[-1] not in EOS and row['pending'] == emitted[-1], 'Pending chain differs')
        quota = limit-len(emitted)
        p = min(1, quota-1, plan['C']-len(emitted)-1)
        require(p >= 0 and row['proposals'] == p and row['verified_rows'] == p+1,
                'Actual K1/tail verifier width differs from finite quota/context')
        count = row['consumed_drafts']
        require(type(count) is int and 0 <= count <= p and row['accepted_draft'] is bool(count) and
                row['committed_target_rows'] == 1+count and row['draft_rows'] == 1+lag,
                'Complete target/draft prefix accounting differs')
        if p:
            require(type(row['draft']) is int and 0 <= row['draft'] < plan['geometry']['vocabulary'],
                    'No valid actual draft ID')
        else: require(row['draft'] == -1 and not count, 'Target-only tail invented a draft')
        emitted.append(row['target_first'])
        if count:
            require(row['target_first'] == row['draft'] and row['target_first'] not in EOS,
                    'Consumed draft differs from its accepted nonterminal output')
            emitted.append(row['target_second'])
        lag = count; proposals += p; consumed += count
        verified += row['verified_rows']; draft_rows += row['draft_rows']
    require(emitted == ids, 'Round outputs do not reconstruct the exact emitted sequence')
    require(report['sampling_draw_cursor'] == 1+sum(2*r['proposals']+1 for r in rounds),
            'Published Philox cursor differs from actual K1/tail draw addresses')
    require(report['decode_graph_calls'] == len(rounds) and report['draft_rounds'] == proposals and
            report['consumed_drafts'] == consumed and report['verified_target_rows'] == verified and
            report['actual_target_rows'] == 1+verified and report['draft_rows'] == draft_rows and
            report['prefill_draft_rows'] == 1 and report['actual_draft_rows'] == 1+draft_rows and
            report['draft_lag'] == lag and report['draft_frontier']+lag == n,
            'Aggregate target/draft/state counters differ from retired rounds')
    accepts = report['agreements']
    require(type(accepts) is int and consumed <= accepts <= proposals, 'Invalid raw acceptance count')
    # An accepted EOS remains pending and need not count as a consumed draft.
    return dict(coverage='complete_finite_K1_journey' if proposals else 'prefill_only_no_MTP_verifier_observed',
        generated_ids=ids, emitted_pending=ids[-1], actual_mtp_proposals=proposals,
        raw_accepts=accepts, raw_rejections=proposals-accepts, consumed_drafts=consumed,
        unobserved_branches=[name for name, count in [('accept', accepts), ('reject', proposals-accepts)] if count == 0],
        final_draft_lag=lag, final_sampling_draw_cursor=report['sampling_draw_cursor'])

def audit(plan, case, attempt, expected):
    folder = HERE/'runs-v2'/case['name']/f'attempt-{attempt}'
    if not (folder/'process.json').exists(): return dict(case=case['name'], state='pending_no_terminal_process')
    process = load(folder/'process.json')
    if process.get('timeout') or process.get('exit') != 0:
        return dict(case=case['name'], state='native_failure_or_timeout', process=process)
    if not (folder/'functional-result.json').exists():
        return dict(case=case['name'], state='runner_validation_failed_or_not_yet_complete', process=process)
    command = load(folder/'command.json'); result = load(folder/'functional-result.json')
    require(command['case'] == case and command['plan'] == identity(HERE/'run-ready-v2-plan.json') and
            command['image'] == plan['runtime']['image'], 'Run command/source pins differ')
    reports = [json.loads(x) for x in (folder/'stdout.log').read_text(encoding='utf8').splitlines() if x.startswith('{')]
    require(len(reports) == 1 and reports[0] == result['full_native_report'], 'Actual stdout report differs from runner result')
    receipt = load(HERE/'complete-v2/input.json')
    require(result['source_id'] == reports[0]['source_id'] == receipt['source_id'], 'Prepared source identity differs')
    require(command['manifest'] == identity(HERE/'complete-v2/weights.tsv') == receipt['prepared_manifest'], 'Prepared manifest changed')
    require(receipt['source_record'] == identity(HERE/'body/payload-role-files.json') and
            receipt['original_validation'] == identity(HERE/'body/published-validation.json'), 'Authenticated source receipt changed')
    outcome = check_report(reports[0], case, plan, expected)
    return dict(case=case['name'], state='passed' if outcome['coverage'].startswith('complete_finite') else 'coverage_incomplete',
        outcome=outcome, expected_inventory=expected, process=process,
        artifacts={name: identity(folder/name) for name in ['command.json', 'process.json', 'stdout.log', 'stderr.log', 'functional-result.json']})

def selftest(plan, expected):
    case = next(c for c in plan['cases'] if c['mtp'])
    report = dict(expected, generated_ids=[100, 101, 102, 103], generated_tokens=4, backend='cpu', mtp=True,
        score_dtype='F32', score_policy='bf16_inputs_f32_output', requested_steps=4, prefill_graph_calls=1,
        prefill_target_rows=1, visible_tokens=4, committed_target_rows=4, committed_target_decode_rows=3,
        fp8_block128_policy=plan['policy'], cache_requested_byte_limit=plan['cache_limit_bytes'],
        cache_live_requested_bytes=1000, cache_peak_requested_bytes=2000, sampling='random', mtp_max_drafts=1,
        sampling_temperature=1, sampling_top_k=8, sampling_top_p=0.9, sampling_seed=123,
        mtp_acceptance_policy='min_one_p_over_q', sampling_draw_cursor=5, decode_graph_calls=2, draft_rounds=1,
        consumed_drafts=1, verified_target_rows=3, actual_target_rows=4, draft_rows=3, prefill_draft_rows=1,
        actual_draft_rows=4, draft_lag=0, draft_frontier=4, agreements=1,
        rounds=[dict(pending=100, draft=101, target_first=101, target_second=102, proposals=1, verified_rows=2,
            consumed_drafts=1, accepted_draft=True, committed_target_rows=2, draft_rows=1),
            dict(pending=102, draft=-1, target_first=103, target_second=-1, proposals=0, verified_rows=1,
            consumed_drafts=0, accepted_draft=False, committed_target_rows=1, draft_rows=2)])
    require(check_report(report, case, plan, expected)['actual_mtp_proposals'] == 1, 'Valid fixture failed')
    wrong = copy.deepcopy(report); wrong['sampling_draw_cursor'] += 1
    try: check_report(wrong, case, plan, expected)
    except ValueError: pass
    else: raise AssertionError('Wrong RNG cursor accepted')
    first_eos = dict(report, generated_ids=[248046], generated_tokens=1, visible_tokens=1, committed_target_rows=1,
        committed_target_decode_rows=0, sampling_draw_cursor=1, decode_graph_calls=0, draft_rounds=0, consumed_drafts=0,
        verified_target_rows=0, actual_target_rows=1, draft_rows=0, actual_draft_rows=1, draft_frontier=1, agreements=0, rounds=[])
    require(check_report(first_eos, case, plan, expected)['coverage'] == 'prefill_only_no_MTP_verifier_observed', 'Prefill-only overclaimed MTP')
    print(json.dumps(dict(passed=True, tests=['actual K1 acceptance plus quota tail accounting', 'wrong RNG rejected', 'prefill EOS is incomplete MTP coverage'],
        HTTP=0, models_started=0, original_body_read_bytes=0)))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--selftest', action='store_true'); args = parser.parse_args()
    if args.attempt < 1: parser.error('attempt must be positive')
    plan = load(HERE/'run-ready-v2-plan.json'); expected = expected_cases(plan)
    if args.selftest: selftest(plan, expected[next(c['name'] for c in plan['cases'] if c['mtp'])])
    else:
        results = []
        for case in plan['cases']:
            try: results.append(audit(plan, case, args.attempt, expected[case['name']]))
            except (ValueError, KeyError, IndexError, OSError) as error:
                results.append(dict(case=case['name'], state='audit_failed', error_type=type(error).__name__, error=str(error)))
        print(json.dumps(dict(results=results, HTTP=0, models_started=0, original_body_read_bytes=0,
            scope='Two fixed-source pure CPU finite journeys; no task quality, numerical equivalence, all MTP features or performance claim.'), indent=2))
        raise SystemExit(0 if all(x['state'] == 'passed' for x in results) else 2)
