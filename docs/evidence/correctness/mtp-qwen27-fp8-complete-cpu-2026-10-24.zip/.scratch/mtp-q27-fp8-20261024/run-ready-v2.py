"""Two explicitly triggered original Qwen27 FP8 CPU journeys; offline planning.

No HTTP, SDK build, automatic acquisition/preparation, retry or model matrix.
Preparation uses the frozen product role verifier and the declared source BOS.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, shutil, subprocess, sys, time
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;R=B.parents[1]
PLAN=B/'run-ready-v2-plan.json';INPUT=B/'complete-v2';MANIFEST=B/'body/payload-role-files.json'
VALIDATION=B/'body/published-validation.json';PUBLISHER=B/'publish-text-roles.py'
FROZEN=B/'run-ready-source';IMAGE=B/'engine-cpu-current2'
CONFIG=R/'.scratch/model-quantization-discovery-2026-10-19/qwen-kimi/Qwen--Qwen3.8-27B-FP8/config.json'
EXPECTED_REPOSITORY='Qwen/Qwen3.8-27B-FP8';EXPECTED_REVISION='017b9c7af6b5689d5dd426a76e0bc077eb5ca20a'
READER='sglang-06992c92';CACHE=2147483648

def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,value):
 with p.open('x',encoding='utf8',newline='\n')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
def identity(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def pin(record):
 p=Path(record['path']);p=p if p.is_absolute()else R/p
 actual=identity(p)
 if any(actual[k]!=record[k]for k in ['bytes','sha256']):raise ValueError('Pinned source/runtime changed: '+str(p))
 return p

def preparer(plan=None):
 if plan:
  for row in plan['preparer'].values():pin(row)
 sys.path.insert(0,str(FROZEN))
 spec=importlib.util.spec_from_file_location('cat06_frozen_preparer',FROZEN/'prepare.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 if module.ROOT!=R or Path(module.geometry.__file__).resolve()!=FROZEN/'geometry.py':raise ValueError('Frozen preparer geometry/root changed')
 return module

def make_plan():
 if PLAN.exists()or FROZEN.exists():raise ValueError('Retained plan/source already exists; never overwrite')
 FROZEN.mkdir()
 shutil.copyfile(IMAGE/'source/engine/models/qwen35/prepare.py',FROZEN/'prepare.py')
 # geometry.py was confirmed unchanged by its owner; freeze it independently,
 # without modifying the existing qualified engine source/image pins.
 shutil.copyfile(R/'engine/models/qwen35/geometry.py',FROZEN/'geometry.py')
 p=preparer();cfg=load(CONFIG);geometry=p.geometry.from_hf(cfg)
 if cfg['text_config']['bos_token_id']!=248044 or cfg['text_config']['dtype']!='bfloat16':raise ValueError('Source BOS/dtype differs')
 ready=load(IMAGE/'ready.json')
 for key in ['image','native','environment','source','pins']:pin(ready[key])
 if ready['image']['sha256']!='b57ff968cb526b3ce969c79823167eac2ebf7344d1cd493b403a62b136031377':raise ValueError('Wrong qualified CPU engine')
 acquisition=load(B/'cat06-text-mtp-range-plan.json')
 if(acquisition['repository'],acquisition['revision'],len(acquisition['selected_roles']))!=(EXPECTED_REPOSITORY,EXPECTED_REVISION,1273):raise ValueError('Fixed original role plan differs')
 rows=acquisition['selected_roles'];full=sum(x['bytes']for x in rows);text=sum(x['bytes']for x in rows if not x['name'].startswith('mtp.'))
 assert(full,text)==(29945203072,29468003328)
 common=['--inputs',str(INPUT),'--capacity','32','--steps','4','--max-sessions','1','--active-sequences','1','--cache-bytes',str(CACHE),'--prefix-cache','off','--replay','commands']
 cases=[]
 for name,mtp in [('cpu-ordinary',False),('cpu-k1-random',True)]:
  command=[ready['image']['path'],*common,'--mtp','on'if mtp else'off']
  if mtp:command+=['--mtp-max-drafts','1','--sampling','random','--temperature','1','--top-k','8','--top-p','0.9','--seed','123']
  cases.append(dict(name=name,mtp=mtp,command=command,original_bytes=full if mtp else text,physical_text_roles=1251,physical_mtp_roles=22 if mtp else 0,canonical_tensors=866 if mtp else 851,fp8_groups=407 if mtp else 400))
 plan=dict(kind='Two bounded complete original Qwen27 FP8 pure CPU journeys',runner=identity(Path(__file__)),runtime=ready,
  preparer={name:identity(FROZEN/(name+'.py'))for name in ['prepare','geometry']},config=identity(CONFIG),publisher=identity(PUBLISHER),
  acquisition_plan=identity(B/'cat06-text-mtp-range-plan.json'),reader_contract=identity(B/'cat06-reader-contract.json'),
  repository=EXPECTED_REPOSITORY,revision=EXPECTED_REVISION,geometry=geometry,policy=dict(p.FP8_POLICY),policy_line=p.FP8_POLICY_LINE,
  manifest=MANIFEST.relative_to(R).as_posix(),validation=VALIDATION.relative_to(R).as_posix(),
  source_qualification='65 complete source files require original full LFS; outside.safetensors only the three selected original text roles are acquired, no excluded vision bytes/full outside LFS claim.',
  physical_roles=1273,logical_roles=866,full_original_bytes=full,text_original_bytes=text,P=1,BOS=248044,C=32,maximum_outputs=4,cache_limit_bytes=CACHE,
  cases=cases,prepare_command=[sys.executable,str(Path(__file__)),'prepare','--mtp','--fp8-reader',READER],
  timeout_seconds=600,automatic_retry=False,HTTP=0,SDK_builds=0,performance_claim=False)
 save(PLAN,plan)
 print(json.dumps(dict(plan=identity(PLAN),cases=[x['name']for x in cases],models_started=0,HTTP=0)))

def checked_plan():
 plan=load(PLAN)
 for key in ['runner','config','publisher','acquisition_plan','reader_contract']:pin(plan[key])
 for key in ['image','native','environment','source','pins']:pin(plan['runtime'][key])
 for row in plan['preparer'].values():pin(row)
 return plan

def source_ready(plan):
 result=subprocess.run([sys.executable,str(pin(plan['publisher'])),'check'],cwd=R,capture_output=True,text=True,
  env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1'),timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
 if result.returncode==2:
  return False,dict(reason='Original source/publication not complete',publisher_output=result.stdout.strip())
 if result.returncode:raise RuntimeError('Original publisher gate failed: '+result.stdout+result.stderr)
 gate=json.loads(result.stdout)
 if gate.get('ready')is not True or gate.get('HTTP')!=0:raise ValueError('Publisher did not certify finite original source readiness')
 validation=load(VALIDATION);original=load(MANIFEST)
 required=dict(state='complete',canonical_prepare_inputs_ready=True,physical_roles=1273,logical_roles=866,full_original_lfs_verified_files=65,
  outside_vision_acquired=False,outside_full_lfs_claimed=False,selected_weight_bytes=29945203072,locally_joined_original_role_bytes=5243520,second_full_bank_created=False)
 if any(validation.get(k)!=v for k,v in required.items()):raise ValueError('Original LFS/outside qualification differs')
 if validation['original_plan']!=plan['acquisition_plan']or validation['publisher']!=plan['publisher']or validation['manifest']!=identity(MANIFEST):raise ValueError('Published source is not bound to this fixed plan')
 if original.get('complete')is not True or(original['repository'],original['revision'])!=(plan['repository'],plan['revision']):raise ValueError('Original source identity differs')
 expected={x['name']:x for x in load(pin(plan['acquisition_plan']))['selected_roles']};seen=set()
 for row in original['roles']:
  if row['name']in seen or row['name']not in expected:raise ValueError('Duplicate or unknown physical role')
  seen.add(row['name']);exp=expected[row['name']]
  if any(row[k]!=exp[k]for k in ['dtype','shape','bytes'])or row['original_file']!=exp['file']or row['original_closed_inclusive']!=exp['closed_inclusive_range']:raise ValueError('Original physical type/extent differs')
 if seen!=set(expected):raise ValueError('Complete1273 physical inventory required')
 return True,dict(manifest=identity(MANIFEST),validation=identity(VALIDATION))

def prepared_ready(plan):
 ready,details=source_ready(plan)
 if not ready:return False,details
 if any(not(INPUT/name).is_file()for name in ['weights.tsv','prompt.ids','input.json']):return False,dict(reason='Explicit authenticated preparation not complete')
 receipt=load(INPUT/'input.json')
 if receipt['source_record']!=identity(MANIFEST)or receipt['original_validation']!=identity(VALIDATION):raise ValueError('Prepared source record changed')
 if receipt['geometry']!=plan['geometry']or receipt['fp8_block128_policy']!=plan['policy']or receipt['fp8_block128_groups']!=407:raise ValueError('Prepared geometry/math policy differs')
 if(receipt['physical_roles'],receipt['selected_weight_bytes'],receipt['text_weight_bytes'],receipt['weight_selection'])!=(1273,plan['full_original_bytes'],plan['text_original_bytes'],'text+mtp'):raise ValueError('Prepared physical inventory differs')
 if(INPUT/'prompt.ids').read_bytes()!=b'248044\n' or receipt['prompt_ids']!=[248044]:raise ValueError('Exactly one fixed original BOS required')
 if identity(INPUT/'weights.tsv')!=receipt['prepared_manifest']:raise ValueError('Prepared manifest changed')
 lines=(INPUT/'weights.tsv').read_text().splitlines()
 if lines[1]!=receipt['source_id']or lines[3]!=plan['policy_line']:raise ValueError('Prepared source/math identity changed')
 return True,details

def prepare(plan,args):
 if not args.mtp or args.fp8_reader!=READER:raise ValueError('prepare requires --mtp --fp8-reader '+READER)
 ready,_=source_ready(plan)
 if not ready:raise RuntimeError('Complete original body/LFS publication required; nothing prepared or executed')
 if INPUT.exists():raise ValueError('Prepared input directory already exists; never overwrite')
 attempt=B/'prepare-attempts'/('attempt-'+str(args.attempt));attempt.mkdir(parents=True,exist_ok=False)
 save(attempt/'command.json',dict(command=sys.argv,plan=identity(PLAN),HTTP=0,models_started=0));start=time.time()
 try:
  p=preparer(plan);lines,receipt=p.prepare_role_files(MANIFEST,True,load(pin(plan['config'])),READER)
  if(receipt['physical_roles'],receipt['selected_weight_bytes'],receipt['geometry'],receipt['fp8_block128_policy'])!=(1273,29945203072,plan['geometry'],plan['policy']):raise ValueError('Actual frozen product preparation differs')
  INPUT.mkdir()
  (INPUT/'weights.tsv').write_text('\n'.join(lines)+'\n',encoding='utf8');(INPUT/'prompt.ids').write_bytes(b'248044\n');(INPUT/'continuation.ids').write_bytes(b'\n')
  receipt.update(source_record=identity(MANIFEST),original_validation=identity(VALIDATION),prepared_manifest=identity(INPUT/'weights.tsv'),
   product_scripts=plan['preparer'],reader_contract=plan['reader_contract'],weight_selection='text+mtp',manifest_signature=lines[0],prompt_ids=[248044],
   prompt_scope='One declared source BOS for a bounded functional journey; no chat/tokenizer/task-quality claim.',copied_weight_bytes=0,HTTP=0)
  save(INPUT/'input.json',receipt);save(attempt/'process.json',dict(complete=True,seconds=time.time()-start,HTTP=0,models_started=0))
 except BaseException as error:
  save(attempt/'failure.json',dict(error=type(error).__name__,message=str(error),seconds=time.time()-start,HTTP=0,models_started=0));raise
 print(json.dumps(dict(prepared=True,physical_roles=1273,source_id=receipt['source_id'],HTTP=0,models_started=0)))

def run(plan,args):
 ready,_=prepared_ready(plan)
 if not ready:raise RuntimeError('Published original source and explicit authenticated preparation required; no model started')
 case=next(x for x in plan['cases']if x['name']==args.case);folder=B/'runs-v2'/case['name']/('attempt-'+str(args.attempt));folder.mkdir(parents=True,exist_ok=False)
 temporary=folder/'tmp';temporary.mkdir();runtime=load(pin(plan['runtime']['environment']));env=dict(os.environ,PATH=runtime['PATH'],TEMP=str(temporary),TMP=str(temporary),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 save(folder/'command.json',dict(case=case,plan=identity(PLAN),image=plan['runtime']['image'],manifest=identity(INPUT/'weights.tsv'),HTTP=0,SDK_builds=0,performance_claim=False));start=time.time()
 with(folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:
  process=subprocess.Popen(case['command'],cwd=R,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  save(folder/'live.json',dict(pid=process.pid,started=start,command=case['command']))
  try:exit_code=process.wait(timeout=plan['timeout_seconds'])
  except subprocess.TimeoutExpired:
   process.kill();process.wait();save(folder/'process.json',dict(timeout=True,seconds=time.time()-start,HTTP=0));raise
 save(folder/'process.json',dict(exit=exit_code,seconds=time.time()-start))
 if exit_code:raise RuntimeError('Actual native failure preserved; no automatic retry')
 reports=[json.loads(x)for x in(folder/'stdout.log').read_text(encoding='utf8').splitlines()if x.startswith('{')];report=reports[-1];receipt=load(INPUT/'input.json')
 if(report['source_id'],report['backend'],report['mtp'],report['score_dtype'],report['score_policy'])!=(receipt['source_id'],'cpu',case['mtp'],'F32','bf16_inputs_f32_output'):raise ValueError('Actual native source/route/score boundary differs')
 if(report['sampling'],report['sampling_draw_cursor']>0)!=('random'if case['mtp']else'greedy',case['mtp']):raise ValueError('Actual sampling/RNG publication differs')
 if case['mtp']and(report['mtp_max_drafts'],report['sampling_temperature'],report['sampling_top_k'],report['sampling_top_p'],report['sampling_seed'])!=(1,1,8,0.9,123):raise ValueError('Actual K1 sampling policy differs')
 if report['fp8_block128_policy']!=plan['policy']|{}:
  # Runtime policy omits the fixed block_size field; it is encoded by the typed
  # codec/physical carrier and remains explicit in the prepared identity.
  expected=dict(plan['policy']);expected.pop('block_size')
  if report['fp8_block128_policy']!=expected:raise ValueError('Actual FP8 arithmetic policy differs')
 if(report['text_tensors'],report['mtp_tensors'],report['canonical_weight_tensors'],report['fp8_block128_groups'])!=(case['physical_text_roles'],case['physical_mtp_roles'],case['canonical_tensors'],case['fp8_groups']):raise ValueError('Actual original/canonical counts differ')
 if(report['original_host_weight_bytes'],report['original_device_weight_bytes'])!=(case['original_bytes'],0):raise ValueError('Actual original host/device bytes differ')
 if report['cache_requested_byte_limit']!=CACHE or report['cache_peak_requested_bytes']>CACHE:raise ValueError('Finite requested cache budget differs')
 ids=report['generated_ids']
 if not 0<len(ids)<=4 or len(ids)!=report['generated_tokens']or any(type(x)is not int or not 0<=x<plan['geometry']['vocabulary']for x in ids):raise ValueError('Invalid generated output domain')
 if report['visible_tokens']!=len(ids)or not 0<report['visible_tokens']<32:raise ValueError('One-BOS committed state frontier differs')
 if case['mtp']and(report['draft_lag']not in(0,1)or report['draft_frontier']+report['draft_lag']!=report['visible_tokens']):raise ValueError('Final complete target/draft frontier differs')
 save(folder/'functional-result.json',dict(case=args.case,native_exit=0,generated_ids=ids,source_id=report['source_id'],sampling_draw_cursor=report['sampling_draw_cursor'],
  visible_tokens=report['visible_tokens'],draft_frontier=report.get('draft_frontier'),draft_lag=report.get('draft_lag'),original_host_weight_bytes=report['original_host_weight_bytes'],
  canonical_weight_bytes=report['canonical_weight_bytes'],cache_peak_requested_bytes=report['cache_peak_requested_bytes'],full_native_report=report,HTTP=0,SDK_builds=0,performance_claim=False))
 print(json.dumps(dict(case=args.case,native_exit=0,generated_ids=ids,HTTP=0,performance_claim=False)))

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['check','run']);p.add_argument('--case',choices=['cpu-ordinary','cpu-k1-random']);p.add_argument('--attempt',type=int,default=1);p.add_argument('--mtp',action='store_true');p.add_argument('--fp8-reader',choices=[READER]);args=p.parse_args()
 if args.attempt<1:p.error('--attempt must be positive')
 if args.action=='plan':make_plan();return
 plan=checked_plan()
 if args.action=='check':
  ready,details=prepared_ready(plan);print(json.dumps(dict(ready=ready,details=details,cases=plan['cases'],HTTP=0,models_started=0)));return
 if args.action=='prepare':prepare(plan,args);return
 if args.case is None:p.error('run requires exactly one explicit --case')
 run(plan,args)
if __name__=='__main__':main()
