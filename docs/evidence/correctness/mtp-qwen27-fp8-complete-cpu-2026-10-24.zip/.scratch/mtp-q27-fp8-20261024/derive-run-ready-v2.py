"""Derive immutable bounded journey pins for the one-object closure correction."""
from pathlib import Path
import copy,hashlib,json,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;R=B.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):
 with p.open('x',encoding='utf8',newline='\n')as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
original=B/'run-ready.py';planpath=B/'run-ready-plan.json'
if identity(original)['sha256']!='6e737907c2214c97b504a71a50e2c2c75c69de1591efb377c72df030124c52f3' or identity(planpath)['sha256']!='ee506adf534a95f716a9e9b9a3bcd38852d46fe72d4c025589c3214e8e2ffcfd':raise ValueError('Original frozen runner/plan differs')
runner=B/'run-ready-v2.py';text=original.read_text(encoding='utf8')
changes=[("PLAN=B/'run-ready-plan.json'","PLAN=B/'run-ready-v2-plan.json'"),("IMAGE=B/'engine-cpu-current1'","IMAGE=B/'engine-cpu-current2'"),("folder=B/'runs'/case['name']","folder=B/'runs-v2'/case['name']"),("choices=['plan','check','prepare','run']","choices=['check','run']")]
for old,new in changes:
 if text.count(old)!=1:raise ValueError('Unexpected runner delta: '+old)
 text=text.replace(old,new)
with runner.open('x',encoding='utf8',newline='\n')as f:f.write(text)
old=read(planpath);plan=copy.deepcopy(old);ready=read(B/'engine-cpu-current2/ready.json')
plan['kind']='Derivative of frozen two bounded CPU journeys; corrected mapping archive closure only'
plan['runner']=identity(runner);plan['runtime']=ready
for case,originalcase in zip(plan['cases'],old['cases']):
 case['command'][0]=ready['image']['path']
 if case['command'][1:]!=originalcase['command'][1:]:raise ValueError('Math/config command changed')
plan['derivative_of']=identity(planpath)
plan['verification_closure_delta']=identity(B/'engine-cpu-current2/pinned-closure.json')
plan['prepare_command']=old['prepare_command'] # retained provenance; derivative CLI cannot prepare
save(B/'run-ready-v2-plan.json',plan)
auditor=B/'audit-finite-runs.py';audit=auditor.read_text(encoding='utf8')
if audit.count("HERE/'runs'")!=1 or audit.count("'run-ready-plan.json'")!=2:raise ValueError('Unexpected audit paths')
audit=audit.replace("HERE/'runs'","HERE/'runs-v2'").replace("'run-ready-plan.json'","'run-ready-v2-plan.json'")
with(B/'audit-finite-runs-v2.py').open('x',encoding='utf8',newline='\n')as f:f.write(audit)
save(B/'run-ready-v2-derivation.json',dict(original_runner=identity(original),original_plan=identity(planpath),derivative_runner=identity(runner),derivative_plan=identity(B/'run-ready-v2-plan.json'),original_audit=identity(auditor),derivative_audit=identity(B/'audit-finite-runs-v2.py'),runner_literal_changes=changes,audit_delta='Only output runs-v2 and derivative plan paths; all numerical/RNG/source/policy/retirement/budget checks unchanged.',configuration_and_math_unchanged=True,HTTP=0,SDK_builds=0))
print(json.dumps(dict(plan=identity(B/'run-ready-v2-plan.json'),models_started=0,HTTP=0)))
