"""Finish only the private small probe after preserving its fopen /WX diagnostic."""
from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('correct',B/'correct-cpu-closure-v2.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
b=c.b;R=c.R;OLD=c.OLD;NEW=c.NEW;probe=NEW/'host-mapping-import'
cc=c.read(OLD/'compile-command.json')[0]
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
command=c.read(probe/'compile/command.json')['command']
b.execute(command,env,probe/'compile2',120)
command=c.read(NEW/'link-command.json');removed=[];link=[]
for arg in command:
 if arg==str(OLD/'main.obj')or arg.lower().endswith('engine/main.cc.obj')or arg.lower().endswith('engine\\main.cc.obj'):
  removed.append(arg);continue
 if arg.startswith('/OUT:'):arg='/OUT:'+str(probe/'probe.exe')
 elif arg.startswith('/PDB:'):arg='/PDB:'+str(probe/'probe.pdb')
 elif arg.startswith('/IMPLIB:'):arg='/IMPLIB:'+str(probe/'probe.lib')
 link.append(arg)
if len(removed)!=2:raise ValueError('Expected exactly2 app TUs: '+repr(removed))
link.insert(2,str(probe/'probe.obj'));c.save(probe/'link-command.json',link)
b.execute(link,env,probe/'link',180)
runtime=c.read(NEW/'runtime-environment.json')
runenv=dict(os.environ,PATH=runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
b.execute([str(probe/'probe.exe'),str(probe/'nonzero-offset-original.bin')],runenv,probe/'run',30)
c.save(probe/'result.json',dict(passed=True,source=b.identity(B/'host-mapping-import-v2.cc'),object=b.identity(probe/'probe.obj'),image=b.identity(probe/'probe.exe'),mapping_object=c.read(NEW/'pinned-closure.json')['mapping_object'],process=b.identity(probe/'run/process.json'),SDK_builds=0,HTTP=0))
print('MAPPING_IMPORT_PASS',flush=True)
