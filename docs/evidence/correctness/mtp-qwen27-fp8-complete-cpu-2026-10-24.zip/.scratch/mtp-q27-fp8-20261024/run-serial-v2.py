"""One serial attempt per explicitly fixed case; stop at first native/guard failure."""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
B=Path(__file__).resolve().parent;R=B.parents[1]
spec=importlib.util.spec_from_file_location('cpu_build',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
folder=B/'serial-v2';folder.mkdir(exist_ok=False)
snapshot=b.read(B/'engine-cpu-current2/pre-run-memory.json')
minimum=29948218112+2147483648+178312320
if snapshot['free_virtual_bytes']<minimum or snapshot['free_physical_bytes']<minimum:raise RuntimeError('Insufficient known canonical/cache/import budget before serial run')
b.save(folder/'memory-admission.json',dict(snapshot=snapshot,known_minimum_bytes=minimum,extra_private_memory_unknown=True,scope='Bounded finite correctness journey; no parallel model, time cap600s per native case.'))
try:
 for case in ['cpu-ordinary','cpu-k1-random']:
  b.execute([sys.executable,str(B/'run-ready-v2.py'),'run','--case',case,'--attempt','1'],dict(os.environ,PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1'),folder/case,660)
 b.execute([sys.executable,str(B/'audit-finite-runs-v2.py'),'--attempt','1'],dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),folder/'postrun-audit',30)
 b.save(folder/'result.json',dict(state='both_finite_journeys_and_postrun_audit_passed',automatic_retry=False,SDK_builds=0,HTTP=0,performance_claim=False))
except BaseException as error:
 b.save(folder/'failure.json',dict(state='failed_stop_no_retry',error=type(error).__name__,message=str(error),SDK_builds=0,HTTP=0))
 raise
