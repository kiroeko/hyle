#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <span>
#include "hyle/compute/low_precision.h"
#include "hyle/compute/weight_import.h"
#include "hyle/mem/mapping.h"

hyle::Status check(const char* path) {
  namespace c = hyle::compute;
  namespace m = hyle::mem;
  std::array<std::byte, 385> original{};
  for (std::size_t i = 0; i < 128; ++i)
    original[257+i] = std::byte(i % 2 ? 0xb8 : 0x38);
  std::FILE* file = nullptr;
  if (fopen_s(&file, path, "wb") || !file)
    return hyle::Status::Internal("cannot create bounded probe input");
  const auto written = std::fwrite(original.data(), 1, original.size(), file);
  const auto closed = std::fclose(file);
  if (written != original.size() || closed) return hyle::Status::Internal("probe input write failed");
  HYLE_ASSIGN_OR_RETURN(auto mapping, m::FileMapping::open(path, m::MappingAccess::kReadOnly, 257, 128));
  HYLE_ASSIGN_OR_RETURN(auto mapped, mapping.view());
  const auto flags = mapped.resource().properties();
  if (!flags.has(m::MemoryProperty::kHostAccessible | m::MemoryProperty::kHostAddressIdentity))
    return hyle::Status::Internal("actual FileMapping lacks canonical host identity");
  const std::array<std::int64_t, 2> ws{1,128}, ss{1,1};
  HYLE_ASSIGN_OR_RETURN(auto wd, c::TensorDesc::dense(c::DataType::kFloat8E4M3FN, ws));
  HYLE_ASSIGN_OR_RETURN(auto sd, c::TensorDesc::dense(c::DataType::kFloat32, ss));
  HYLE_ASSIGN_OR_RETURN(auto yd, c::float8_weight_description(128,1,c::Float8ScaleMode::kFloat32Block128));
  HYLE_ASSIGN_OR_RETURN(auto ybytes, yd.required_bytes());
  if (ybytes != 132) return hyle::Status::Internal("canonical carrier size changed");
  HYLE_ASSIGN_OR_RETURN(auto scales, m::Buffer::create(m::system_resource(),4,64));
  HYLE_ASSIGN_OR_RETURN(auto output, m::Buffer::create(m::system_resource(),ybytes,256));
  const auto scale = std::bit_cast<std::array<std::byte,4>>(0.5f);
  HYLE_RETURN_IF_ERROR(scales.write(0,scale));
  HYLE_RETURN_IF_ERROR(output.fill(0,ybytes,std::byte{0xa5}));
  HYLE_ASSIGN_OR_RETURN(auto w, c::ConstTensorView::create(wd,mapped));
  HYLE_ASSIGN_OR_RETURN(auto s, c::ConstTensorView::create(sd,scales.view()));
  HYLE_ASSIGN_OR_RETURN(auto y, c::TensorView::create(yd,output.view()));
  HYLE_RETURN_IF_ERROR(c::import_float8_block128_weight(w,s,y));
  std::array<std::byte,132> actual{};
  HYLE_RETURN_IF_ERROR(output.read(0,actual));
  if (std::memcmp(actual.data(),original.data()+257,128) ||
      std::memcmp(actual.data()+128,scale.data(),4))
    return hyle::Status::Internal("FP8 import changed original codes or exact F32 scale");
  std::printf("{\"mapping_offset\":257,\"mapping_bytes\":128,\"mapping_flags\":%u,\"canonical_bytes\":132,\"code_bytes_unchanged\":true,\"scale_bits\":1056964608,\"HTTP\":0}\n",static_cast<unsigned>(flags.flags));
  return {};
}
int main(int argc,char** argv) {
  if (argc != 2) return 2;
  const auto status=check(argv[1]);
  if (!status.ok()) { const auto msg=status.message(); std::fprintf(stderr,"%.*s\n",static_cast<int>(msg.size()),msg.data()); return 1; }
  return 0;
}
