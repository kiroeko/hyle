from pathlib import Path
import json,hashlib
root=Path.cwd()
manifest=root/'third_party/ggml_vulkan_runtime/patches.json'
j=json.loads(manifest.read_text(encoding='utf-8'))
entry=next(x for x in j['files'] if x['path']=='src/ggml-vulkan/ggml-vulkan.cpp')
original=Path('C:/h7/inference-g02-impacted/src/compute_ggml_runtime/source-e73b695f71c1ea2c/src/ggml-vulkan/ggml-vulkan.cpp').read_bytes()
assert hashlib.sha256(original).hexdigest()==entry['after_sha256']
data=original.decode('utf-8');edits=[]
def change(before,after):
 global data
 assert data.count(before)==1,(before[:100],data.count(before))
 data=data.replace(before,after,1);edits.append({'before':before,'after':after})
change('    ggml_type v_type;\n\n    bool operator<(const vk_fa_pipeline_state &b)',
       '    ggml_type v_type;\n    bool hyle_full_f32 = false;\n\n    bool operator<(const vk_fa_pipeline_state &b)')
change('aligned, f32acc, flags, limit_occupancy_shmem, k_type, v_type) <\n               std::tie(b.HSK, b.HSV, b.Br, b.Bc, b.D_split, b.row_split, b.shmem_staging, b.path, b.workgroup_size, b.subgroup_size, b.aligned, b.f32acc, b.flags, b.limit_occupancy_shmem, b.k_type, b.v_type);',
       'aligned, f32acc, flags, limit_occupancy_shmem, k_type, v_type, hyle_full_f32) <\n               std::tie(b.HSK, b.HSV, b.Br, b.Bc, b.D_split, b.row_split, b.shmem_staging, b.path, b.workgroup_size, b.subgroup_size, b.aligned, b.f32acc, b.flags, b.limit_occupancy_shmem, b.k_type, b.v_type, b.hyle_full_f32);')
decl='static bool ggml_vk_flash_attn_scalar_shmem_support(const vk_device& device, const vk_fa_tuning_params& params, uint32_t hsk, uint32_t hsv, bool f32acc, ggml_type k_type, ggml_type v_type)'
change(decl+';',decl[:-1]+', bool hyle_full_f32 = false);')
change(decl+' {',decl[:-1]+', bool hyle_full_f32) {')
signature='static vk_fa_tuning_params get_fa_tuning_params_scalar(const vk_device& device, uint32_t hsk, uint32_t hsv, uint32_t n_rows, uint32_t n_kv, ggml_type k_type, ggml_type v_type, bool f32acc)'
change(signature+' {',signature[:-1]+', bool hyle_full_f32 = false) {')
change('!ggml_vk_flash_attn_scalar_shmem_support(device, result, hsk, hsv, f32acc, k_type, v_type))',
       '!ggml_vk_flash_attn_scalar_shmem_support(device, result, hsk, hsv, f32acc, k_type, v_type, hyle_full_f32))')
change('    const uint32_t float_type_size = (device->fp16 && k_type != GGML_TYPE_BF16) ? sizeof(ggml_fp16_t) : sizeof(float);',
       '    const uint32_t float_type_size = (!hyle_full_f32 && device->fp16 && k_type != GGML_TYPE_BF16) ? sizeof(ggml_fp16_t) : sizeof(float);')
change('    const bool mmq = ggml_vk_fa_scalar_uses_mmq(device, k_type, v_type);',
       '    const bool mmq = !hyle_full_f32 && ggml_vk_fa_scalar_uses_mmq(device, k_type, v_type);')
change('        if (bf16_kv) {\n            spv_data = flash_attn_f32_f16_fp32_data;',
       '        if (fa.first.hyle_full_f32 || bf16_kv) {\n            spv_data = flash_attn_f32_f16_fp32_data;')
change('            name = aligned ? "flash_attn_f32_bf16_aligned" : "flash_attn_f32_bf16";',
       '            name = fa.first.hyle_full_f32 ? "hyle_flash_attn_full_f32" :\n                   (aligned ? "flash_attn_f32_bf16_aligned" : "flash_attn_f32_bf16");')
change('    const bool f32acc = !ctx->device->fp16 || dst->op_params[3] == GGML_PREC_F32 || k->type == GGML_TYPE_BF16;',
       '    const bool hyle_full_f32 = dst->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionMathSlot] ==\n                               hyle::compute::ggml_vulkan::bridge::kFlashAttentionFullF32;\n    const bool f32acc = hyle_full_f32 || !ctx->device->fp16 || dst->op_params[3] == GGML_PREC_F32 || k->type == GGML_TYPE_BF16;')
change('    const bool use_dequant_kv = k_quant && v_quant && neq1 >= 64 &&',
       '    const bool use_dequant_kv = !hyle_full_f32 && k_quant && v_quant && neq1 >= 64 &&')
change('    vk_fa_tuning_params tuning_params = get_fa_tuning_params(ctx->device, HSK, HSV, 512, KV, k_type_eff, v_type_eff, f32acc);',
       '    vk_fa_tuning_params tuning_params = hyle_full_f32\n        ? get_fa_tuning_params_scalar(ctx->device, HSK, HSV, 512, KV, k_type_eff, v_type_eff, true, true)\n        : get_fa_tuning_params(ctx->device, HSK, HSV, 512, KV, k_type_eff, v_type_eff, f32acc);')
change('    tuning_params = get_fa_tuning_params(ctx->device, HSK, HSV, N, KV, k_type_eff, v_type_eff, f32acc);',
       '    tuning_params = hyle_full_f32\n        ? get_fa_tuning_params_scalar(ctx->device, HSK, HSV, N, KV, k_type_eff, v_type_eff, true, true)\n        : get_fa_tuning_params(ctx->device, HSK, HSV, N, KV, k_type_eff, v_type_eff, f32acc);')
change('                                                                   mask != nullptr, use_mask_opt, logit_softcap != 0, k_type_eff, v_type_eff);',
       '                                                                   mask != nullptr, use_mask_opt, logit_softcap != 0, k_type_eff, v_type_eff);\n    fa_pipeline_state.hyle_full_f32 = hyle_full_f32;')
change('                uint32_t HSV = op->src[2]->ne[0];\n                if ((HSK % 8)',
       '                uint32_t HSV = op->src[2]->ne[0];\n                const bool hyle_full_f32 = op->op_params[hyle::compute::ggml_vulkan::bridge::kFlashAttentionMathSlot] ==\n                                           hyle::compute::ggml_vulkan::bridge::kFlashAttentionFullF32;\n                if (hyle_full_f32) {\n                    if (HSK != HSV || (HSK != 64 && HSK != 128 && HSK != 256) ||\n                        (op->src[1]->type != GGML_TYPE_F16 && op->src[1]->type != GGML_TYPE_F32) ||\n                        (op->src[2]->type != GGML_TYPE_F16 && op->src[2]->type != GGML_TYPE_F32)) {\n                        return false;\n                    }\n                    const auto params = get_fa_tuning_params_scalar(device, HSK, HSV, 512u,\n                        uint32_t(op->src[1]->ne[1]), op->src[1]->type, op->src[2]->type, true, true);\n                    if (!ggml_vk_flash_attn_scalar_shmem_support(device, params, HSK, HSV, true,\n                            op->src[1]->type, op->src[2]->type, true)) {\n                        return false;\n                    }\n                }\n                if ((HSK % 8)')
entry['edits']+=edits;entry['after_sha256']=hashlib.sha256(data.encode()).hexdigest()
manifest.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'.scratch/inference-gaps/g01/full-f32-native.cpp').write_text(data,encoding='utf-8',newline='\n')
print(json.dumps({'edits_added':len(edits),'native_after_sha256':entry['after_sha256']}))
