"""B02 original BF16 roles: loose files, authenticated resume, three workers.

Root may inspect with --plan-only, then run without it to acquire only the29
declared tensor ranges. No aggregate roles.bin, native execution or shard fetch.
"""
import argparse
import ast
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
from threading import RLock
import time
import urllib.error
import urllib.request

S = Path(__file__).resolve().parent
R = S.parents[1]
ARTIFACT_DIR = S / 'B02'
TARGET_SECTION = 'target63'
NEXTN_COUNT, TARGET_COUNT = 17, 12
HELPER = R / '.scratch/q24-target-verifier-20261023/fetch_target_parallel.py'
HELPER_SHA = '0ef1c2c1c7da6b6c2d94eec0be4041451ab4735f4b40628980f83a38bd50565d'
REPO = 'Qwen/Qwen3.8-27B'
REV = '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0'
COUNT, BODY = 29, 6679513088
CHUNK, IO, WORKERS = 128 * 1024 * 1024, 1024 * 1024, 3


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=Path(path).relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))


def checked_plan():
    path = ARTIFACT_DIR / 'static-plan.json'
    plan = read(path)
    proof = read(ARTIFACT_DIR / 'summary.json')
    assert proof['complete'] and proof['complete_absolute_ranges'] and proof['tensor_payload_bytes'] == 0
    assert identity(path) in proof['plans']
    assert (plan['repository'], plan['revision'], plan['original_roles'], plan['source_bytes']) == (REPO, REV, COUNT, BODY)
    assert plan['complete_absolute_ranges'] is True and plan['metadata_only'] is True
    assert len(plan['roles']) == COUNT and sum(r['bytes'] for r in plan['roles']) == BODY
    assert len({r['name'] for r in plan['roles']}) == len({r['filename'] for r in plan['roles']}) == COUNT
    assert all(Path(r['filename']).name == r['filename'] for r in plan['roles'])
    headers = []
    for shard in plan['shards']:
        info = shard['header']
        raw = (R / info['path']).read_bytes()
        assert len(raw) == info['bytes'] <= 1024 * 1024 and sha(raw) == info['sha256']
        assert shard['data_base'] == len(raw) + 8
        assert shard['etag'].startswith('"') and shard['etag'].endswith('"')
        assert shard['url'] == f"https://huggingface.co/{REPO}/resolve/{REV}/{shard['file']}"
        headers.append(json.loads(raw))
    for row in plan['roles']:
        shard, actual = plan['shards'][row['source_shard']], headers[row['source_shard']][row['name']]
        assert row['dtype'] == actual['dtype'] == 'BF16' and row['shape'] == actual['shape']
        assert all(type(n) is int and n > 0 for n in row['shape'])
        assert row['data_relative_half_open'] == actual['data_offsets']
        first, end = actual['data_offsets']
        assert end - first == row['bytes'] == 2 * math.prod(row['shape'])
        assert row['absolute_inclusive'] == [shard['data_base'] + first, shard['data_base'] + end - 1]
        assert row['absolute_inclusive'][1] < shard['whole_file_bytes']
    assert sum(r['section'] == 'nextn' for r in plan['roles']) == NEXTN_COUNT
    assert sum(r['section'] == TARGET_SECTION for r in plan['roles']) == TARGET_COUNT
    return path, plan


@contextmanager
def single_writer(path):
    # The lock belongs to this opened handle; no PID or stale marker is trusted.
    with path.open('a+b') as stream:
        if stream.seek(0, os.SEEK_END) == 0:
            stream.write(b'\0')
            stream.flush()
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)


def downloader(record, receipt):
    """Reuse only the pinned downloader's unchanged functions, not its GGUF plan."""
    raw = HELPER.read_bytes()
    assert sha(raw) == HELPER_SHA
    parsed = ast.parse(raw, filename=str(HELPER))
    names = {'now', 'save', 'acquire_role'}
    definitions = [node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in definitions} == names
    namespace = dict(R=R, CHUNK=CHUNK, IO=IO, record=record, receipt=receipt, LOCK=RLock(),
                     datetime=datetime, hashlib=hashlib, json=json, os=os, time=time, urllib=urllib)
    # Function bodies are unmodified from the already used parallel role
    # downloader. Its top-level plan/file/network side effects are not executed.
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(HELPER), 'exec'), namespace)
    return namespace


def manifests(out, record):
    # Both filtered manifests refer to these same loose role files. The
    # original embedding/head are stored once, shared by the model assembly.
    for section, name in [(None, 'manifest.json'), ('nextn', 'nextn-manifest.json'),
                          (TARGET_SECTION, 'target-manifest.json')]:
        roles = [dict(name=r['name'], file=r['filename'], sha256=r['payload']['sha256'],
                      dtype=r['dtype'], shape=r['shape'], bytes=r['bytes'], section=r['section'])
                 for r in record['roles'] if section is None or r['section'] == section]
        value = dict(repository=REPO, revision=REV, directory=out.relative_to(R).as_posix(),
                     original_roles=len(roles), source_bytes=sum(r['bytes'] for r in roles), roles=roles,
                     source_receipt=(out / 'acquisition.json').relative_to(R).as_posix(),
                     complete=True, artifact_executed=False,
                     scope='Actual loose original BF16 role files and SHA pins for caller-provided Data::load Specs; no weight repack or duplicated vocabulary.')
        (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    plan_path, plan = checked_plan()
    assert sha(HELPER.read_bytes()) == HELPER_SHA
    out = ARTIFACT_DIR / 'original-roles'
    if args.plan_only:
        print(json.dumps(dict(repository=REPO, revision=REV, roles=COUNT, body_bytes=BODY,
             output_directory=out.relative_to(R).as_posix(), role_workers=WORKERS,
             range_bytes=CHUNK, stream_buffer_bytes=IO, maximum_live_stream_bytes=WORKERS*IO,
             source_plan=identity(plan_path), reused_downloader=identity(HELPER), network_requests=0)))
        return
    out.mkdir(exist_ok=True)
    with single_writer(out / '.fetch.lock'):
        receipt = out / 'acquisition.json'
        roles = []
        for row in plan['roles']:
            shard = plan['shards'][row['source_shard']]
            roles.append(dict(row, url=shard['url'], etag=shard['etag'], whole_file_bytes=shard['whole_file_bytes'],
                complete=False, chunks=[], payload=dict(path=(out / row['filename']).relative_to(R).as_posix(),
                                                        bytes=row['bytes'], sha256=None)))
        expected = dict(repository=REPO, revision=REV, source_plan=plan_path.relative_to(R).as_posix(),
                        source_plan_sha256=identity(plan_path)['sha256'], expected_role_payload_bytes=BODY,
                        downloader=identity(HELPER))
        if receipt.exists():
            record = read(receipt)
            assert all(record[k] == value for k, value in expected.items())
            for actual, wanted in zip(record['roles'], roles, strict=True):
                assert all(actual[k] == value for k, value in wanted.items() if k not in ('complete', 'chunks', 'payload'))
                assert actual['payload']['path'] == wanted['payload']['path'] and actual['payload']['bytes'] == wanted['bytes']
        else:
            assert not any((R / r['payload']['path']).exists() for r in roles), 'Unrecorded loose file is not an authenticated resume prefix'
            record = dict(expected, complete=False, original_roles=COUNT, whole_shard_downloaded=False,
                          chunk_bytes=CHUNK, stream_buffer_bytes=IO, requests=[], roles=roles)
        functions = downloader(record, receipt)
        with functions['LOCK']:
            record.update(complete=False, chunk_bytes=CHUNK, stream_buffer_bytes=IO, parallel_role_workers=WORKERS)
            functions['save']()
        errors = []
        with ThreadPoolExecutor(max_workers=WORKERS, thread_name_prefix='qwen-bfloat-role') as executor:
            futures = [executor.submit(functions['acquire_role'], row) for row in record['roles']]
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as error:
                    errors.append(error)
        # All futures have joined. A failure retains every verified role/chunk,
        # but never publishes complete/manifest pins for a partial artifact.
        if errors:
            with functions['LOCK']:
                record['complete'] = False
                functions['save']()
            raise errors[0]
        with functions['LOCK']:
            assert all(row['complete'] and row['payload']['sha256'] for row in record['roles'])
            payload_bytes = sum(row['payload']['bytes'] for row in record['roles'])
            request_bytes = sum(row['bytes'] for row in record['requests'] if row['complete'])
            assert payload_bytes == request_bytes == BODY
            record.update(complete=True, role_payload_bytes=payload_bytes,
                          successful_request_body_bytes=request_bytes, finished_utc=functions['now']())
            functions['save']()
        manifests(out, record)
        print(json.dumps(dict(complete=True, roles=COUNT, role_payload_bytes=BODY,
                             receipt=identity(receipt), manifest=identity(out / 'manifest.json'))))


if __name__ == '__main__':
    main()
