"""Three fixed MTP physical schemas: JSON index and safetensors headers only.

Root runs this; no tensor payload, native model, compiler or latest revision.
Q30 uses its complete fixed JSON index to select only actual MTP shards.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import re
import struct
import sys
import time
import urllib.request
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
MAX_HEADER, MAX_INDEX, MAX_TOTAL = 1024 * 1024, 12 * 1024 * 1024, 24 * 1024 * 1024
GPTQ = R / 'docs/evidence/correctness/gptq-reference-2026-10-20.zip'
QUARK = R / 'docs/evidence/research/quark-mxfp4-contract-2026-10-20.zip'
SPECS = {
    'Q01': ('Vishva007/Qwen3.5-2B-W4A16-AutoRound-GPTQ', '8ec79a3b08636bc68fd40d69df80e97ff1263995', 'q35'),
    'Q10': ('Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ', '1b9d56b428e9f841d7ad566f87660b5f47553c97', 'q27'),
    'Q30': ('amd/GLM-5.3-Flash-Quark-MXFP4', 'b5688f25491202978c19c4d036eef579f61bbe07', None),
}
requests = []
reserved = 0


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))


def archived(archive, entry):
    with zipfile.ZipFile(archive) as z:
        raw = z.read(entry)
    return raw, dict(archive=archive.relative_to(R).as_posix(), entry=entry, bytes=len(raw), sha256=sha(raw))


def exact(url, first, last, *, total=None, etag=None):
    global reserved
    size = last - first + 1
    if size <= 0 or reserved + size > MAX_TOTAL:
        raise ValueError('Metadata request exceeds the24MiB aggregate limit')
    reserved += size
    headers = {'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity', 'User-Agent': 'hyle-mtp-physical-schema/1'}
    if etag is not None:
        headers['If-Range'] = etag
    attempt = dict(url=url, absolute_inclusive=[first, last], maximum_body_bytes=size, started=time.time(), complete=False)
    requests.append(attempt)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=60) as response:
            attempt.update(status=response.status, headers=dict(response.headers.items()))
            if response.status != 206:
                raise ValueError('Metadata Range must return206; refuse any200 response body')
            match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', response.headers.get('Content-Range', ''))
            if not match or tuple(map(int, match.groups()[:2])) != (first, last):
                raise ValueError('Incorrect metadata Content-Range')
            actual_total = int(match.group(3))
            actual_etag = response.headers.get('ETag', '')
            if (total is not None and actual_total != total) or actual_total <= last:
                raise ValueError('Metadata source total length changed')
            if not actual_etag.startswith('"') or not actual_etag.endswith('"'):
                raise ValueError('Metadata source has no strong ETag')
            if etag is not None and actual_etag != etag:
                raise ValueError('Metadata ETag changed between exact ranges')
            if response.headers.get('Content-Encoding') not in (None, 'identity'):
                raise ValueError('Encoded metadata response is not an exact byte range')
            if response.headers.get('Content-Length') != str(size):
                raise ValueError('Metadata response length differs from exact range')
            commit = response.headers.get('X-Repo-Commit')
            expected_commit = url.split('/resolve/', 1)[1].split('/', 1)[0]
            if commit is not None and commit != expected_commit:
                raise ValueError('Metadata response identifies a different repository revision')
            raw = response.read(size)
            if len(raw) != size:
                raise ValueError('Truncated metadata range')
            # Never read one extra byte past the declared header/index range.
            attempt.update(complete=True, bytes=len(raw), sha256=sha(raw), finished=time.time())
            return raw, actual_total, actual_etag
    except Exception as error:
        attempt.update(error_type=type(error).__name__, error=str(error), finished=time.time())
        raise


def parse_header(raw, total):
    header = json.loads(raw)
    sizes = {'I8': 1, 'U8': 1, 'F8_E4M3': 1, 'F8_E5M2': 1, 'F8_E8M0': 1,
             'F16': 2, 'BF16': 2, 'F32': 4, 'I32': 4, 'U32': 4, 'I64': 8, 'U64': 8, 'BOOL': 1}
    tensors = {}
    for name, value in header.items():
        if name == '__metadata__':
            continue
        dtype, shape = value['dtype'], value['shape']
        first, end = value['data_offsets']
        if (dtype not in sizes or not isinstance(shape, list)
                or any(type(n) is not int or n <= 0 for n in shape)
                or type(first) is not int or type(end) is not int or first < 0
                or end - first != math.prod(shape) * sizes[dtype] or 8 + len(raw) + end > total):
            raise ValueError('Invalid physical safetensors metadata: ' + name)
        tensors[name] = value
    return tensors


def header(id_, repo, revision, file):
    if Path(file).name != file or not file.endswith('.safetensors'):
        raise ValueError('Refuse a non-safetensors header filename')
    folder = S / id_ / file.removesuffix('.safetensors')
    folder.mkdir(parents=True, exist_ok=True)
    path, receipt_path = folder / 'header.json', folder / 'receipt.json'
    url = f'https://huggingface.co/{repo}/resolve/{revision}/{file}'
    if receipt_path.exists():
        receipt = read(receipt_path)
        raw = path.read_bytes()
        if (receipt['url'] != url or receipt['repository'] != repo or receipt['revision'] != revision
                or receipt['file'] != file or receipt['header']['bytes'] != len(raw)
                or receipt['header']['sha256'] != sha(raw) or len(raw) > MAX_HEADER):
            raise ValueError('Cached physical header identity differs')
        return parse_header(raw, receipt['whole_file_bytes']), receipt
    if id_ == 'Q30' and file in ('model-00001-of-00062.safetensors', 'model-00019-of-00062.safetensors'):
        entry = f'artifact/30/{file}/header.json'
        raw, proof = archived(QUARK, entry)
        old_raw, old_proof = archived(QUARK, entry + '.http.json')
        old = json.loads(old_raw)
        old_headers = {key.lower(): value for key, value in old['headers'].items()}
        match = re.fullmatch(r'bytes 8-(\d+)/(\d+)', old_headers['content-range'])
        if (old['status'] != 206 or not match or int(match.group(1)) != len(raw) + 7
                or old['body']['sha256'] != sha(raw) or len(raw) > MAX_HEADER):
            raise ValueError('Archived header is not an authenticated exact metadata range')
        total, etag = int(match.group(2)), old_headers['etag']
        provenance = dict(reused=[proof, old_proof], network_bytes=0)
    else:
        length, total, etag = exact(url, 0, 7)
        size = struct.unpack('<Q', length)[0]
        if size < 2 or size > MAX_HEADER or 8 + size >= total:
            raise ValueError('Safetensors header exceeds1MiB or reaches beyond source file')
        (folder / 'header-length.bin').write_bytes(length)
        raw, _, _ = exact(url, 8, 7 + size, total=total, etag=etag)
        provenance = dict(network_bytes=8 + size)
    tensors = parse_header(raw, total)
    path.write_bytes(raw)
    receipt = dict(url=url, repository=repo, revision=revision, file=file, etag=etag,
                   whole_file_bytes=total, data_base=8 + len(raw), header=identity(path),
                   tensor_count=len(tensors), whole_shard_downloaded=False, tensor_payload_bytes=0, **provenance)
    save(receipt_path, receipt)
    return tensors, receipt


def quark_index(repo, revision):
    path, receipt_path = S / 'Q30/model.safetensors.index.json', S / 'Q30/index-receipt.json'
    url = f'https://huggingface.co/{repo}/resolve/{revision}/model.safetensors.index.json'
    if receipt_path.exists():
        receipt = read(receipt_path)
        raw = path.read_bytes()
        if (receipt['repository'] != repo or receipt['revision'] != revision or receipt['url'] != url
                or receipt['index']['sha256'] != sha(raw) or len(raw) != 8561704
                or receipt['etag'] != '"1927f743f40c0b3681b39fde7c9e47d1e679e536"'):
            raise ValueError('Cached complete index hash differs')
        return json.loads(raw), receipt
    old_raw, proof = archived(QUARK, 'artifact/30/index-prefix-262144.jsonpart.http.json')
    old = json.loads(old_raw)
    old_headers = {key.lower(): value for key, value in old['headers'].items()}
    total = int(old_headers['content-range'].rsplit('/', 1)[1])
    etag = old_headers['etag']
    if total != 8561704 or total > MAX_INDEX or etag != '"1927f743f40c0b3681b39fde7c9e47d1e679e536"':
        raise ValueError('Fixed complete JSON index identity exceeds the approved bound')
    raw, _, _ = exact(url, 0, total - 1, total=total, etag=etag)
    index = json.loads(raw)
    if not isinstance(index.get('weight_map'), dict):
        raise ValueError('Complete index has no named weight_map')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    receipt = dict(repository=repo, revision=revision, url=url, index=identity(path),
                   etag=etag, complete=True, fixed_size_provenance=proof, tensor_payload_bytes=0)
    save(receipt_path, receipt)
    return index, receipt


def physical_schema(id_):
    repo, revision, key = SPECS[id_]
    source = []
    if key is not None:
        raw, proof = archived(GPTQ, f'evidence/gptq-contract-review/{key}/index.json')
        index = json.loads(raw)
        source.append(proof)
        expected = {name: file for name, file in index['weight_map'].items() if name.startswith('mtp.')}
        if len(expected) != 15 or set(expected.values()) != {'model_extra_tensors.safetensors'}:
            raise ValueError('Fixed GPTQ extra-file role index differs')
        config = None
    else:
        index, proof = quark_index(repo, revision)
        source.append(proof)
        expected = {name: file for name, file in index['weight_map'].items() if name.startswith('model.language_model.layers.45.')}
        raw, proof = archived(QUARK, 'artifact/30/fixed-config.json')
        source.append(proof)
        config = json.loads(raw)['quantization_config']
        if not expected:
            raise ValueError('Complete Quark index has no layer45 roles')
    files = sorted(set(expected.values()))
    receipts, rows, observed = [], [], set()
    for file in files:
        if id_ == 'Q30' and not re.fullmatch(r'model-\d{5}-of-00062\.safetensors', file):
            raise ValueError('Unexpected Quark index shard filename')
        tensors, receipt = header(id_, repo, revision, file)
        receipts.append(receipt)
        for name, value in tensors.items():
            is_mtp = name.startswith('mtp.') if key is not None else name.startswith('model.language_model.layers.45.')
            if is_mtp and expected.get(name) != file:
                raise ValueError('Original MTP header/index name or shard differs: ' + name)
        for name in sorted(name for name, where in expected.items() if where == file):
            value = tensors[name]
            observed.add(name)
            rows.append(dict(name=name, source_file=file, dtype=value['dtype'], shape=value['shape'],
                             data_relative_half_open=value['data_offsets'],
                             bytes=value['data_offsets'][1] - value['data_offsets'][0]))
    assert observed == set(expected)
    counts = {}
    for row in rows:
        counts[row['dtype']] = counts.get(row['dtype'], 0) + 1
    result = dict(id=id_, repository=repo, revision=revision,
                  hf=f'https://huggingface.co/{repo}/tree/{revision}', complete_physical_MTP_census=True,
                  roles=len(rows), dtypes=counts, actual_MTP_shards=files, sources=source,
                  headers=receipts, physical_roles=sorted(rows, key=lambda row: row['name']),
                  tensor_payload_bytes=0, artifact_executed=False, native_builds=0)
    if config is None:
        original = read(R / 'docs/evidence/research/mtp-artifact-scope-2026-10-22.json')['official_header_extract']
        model = 'qwen35_2b' if id_ == 'Q01' else 'qwen38_27b'
        reference = {row['name']: row for row in next(item for item in original if item['model_id'] == model)['mtp_roles']}
        bf16 = [row['name'] for row in rows if row['dtype'] == 'BF16' and row['name'] in reference
                and row['shape'] == reference[row['name']]['shape']]
        result['W01_reuse'] = dict(BF16_shape_compatible_roles=bf16,
            other_geometry_roles=[row for row in rows if row['name'] not in reference or row['shape'] != reference[row['name']]['shape']],
            other_storage_roles=[row for row in rows if row['dtype'] != 'BF16'],
            meaning='Actual BF16 roles of the same15-role dense NextN shape can use the shared explicit-convention BF16 supplier/prefix/dense builder. F16/F32/packed roles, if present, cannot be relabelled BF16. Header shape/presence is not original role acquisition or execution; target/vocabulary GPTQ remains its own source contract.')
    else:
        overrides = {name: value for name, value in config['layer_quant_config'].items() if name.startswith('model.language_model.layers.45.')}
        assert len(overrides) == 871
        by_name = {row['name']: row for row in rows}
        for name, spec in overrides.items():
            w, sf = by_name[name + '.weight'], by_name[name + '.weight_scale']
            assert w['dtype'] == 'F8_E4M3' and len(w['shape']) == 2
            assert sf['dtype'] == 'F32' and sf['shape'] == [(n + 127) // 128 for n in w['shape']]
            assert spec['weight']['dtype'] == 'fp8_e4m3' and spec['weight']['block_size'] == [128, 128]
            assert spec['input_tensors']['dtype'] == 'fp8_e4m3' and spec['input_tensors']['group_size'] == 128
        result['quantized_adapter'] = dict(exact_FP8_matrix_overrides=871, original_weight='E4M3 with F32 block128x128 scales',
            activation='Dynamic E4M3 group128 with existing explicit MultiplyReciprocal/floor contract, not official Divide or title-derived MXFP4',
            excluded_BF16_roles=[row['name'] for row in rows if row['dtype'] == 'BF16'],
            W01_boundary='Plain BF16 byte bindings/primitives can be reused; this is GLM MLA/indexer/MoE, not Qwen prefix/state. The871 original E4/SF matrices require the existing GLM FP8/MoE source adapter, not BF16 substitution.')
    return result


def main():
    global requests
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only', nargs='+', choices=list(SPECS), default=list(SPECS))
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    S.mkdir(parents=True, exist_ok=True)
    plan = dict(identities=[dict(id=id_, repository=SPECS[id_][0], revision=SPECS[id_][1]) for id_ in args.only],
                index_first=True, maximum_header_bytes=MAX_HEADER, maximum_index_bytes=MAX_INDEX,
                maximum_network_metadata_bytes=MAX_TOTAL, tensor_payload_bytes=0)
    save(S / 'plan.json', plan)
    if args.plan_only:
        print(json.dumps(plan))
        return
    if (S / 'http-requests.json').exists():
        requests = read(S / 'http-requests.json')
    first_request = len(requests)
    results, failures = [], []
    for id_ in dict.fromkeys(args.only):
        try:
            result = physical_schema(id_)
            save(S / id_ / 'physical-schema.json', result)
            results.append(result)
            print(json.dumps(dict(id=id_, complete=True, roles=result['roles'], dtypes=result['dtypes'], shards=result['actual_MTP_shards'])), flush=True)
        except Exception as error:
            failures.append(dict(id=id_, complete=False, type=type(error).__name__, error=str(error)))
        finally:
            save(S / 'http-requests.json', requests)
    save(S / 'summary.json', dict(complete=not failures, results=results, failures=failures,
        metadata_request_budget_reserved=reserved, successful_network_metadata_bytes_this_invocation=sum(row.get('bytes', 0) for row in requests[first_request:] if row['complete']),
        http_history_requests=len(requests),
        tensor_payload_bytes=0, scope_edited=False, currentwork_edited=False, native_builds=0))
    if failures:
        raise RuntimeError('Physical schema remains partial: ' + ','.join(item['id'] for item in failures))


if __name__ == '__main__':
    main()
