"""Root-only S01 incremental Qwen TU on the published B05 cached ABI.
Compile requires the completed real pin header. No SDK/NVCC/full rebuild.
"""
from pathlib import Path
import argparse
import ast
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
S01_DIRECTORY = S / 'S01/original-roles'
R = S.parents[1]
QB = R / '.scratch/qwen-bfloat-selected-20261023'
CA = R / '.scratch/dspark-pro-target-draft-20261023'
BASE = QB / 'tests-link8'
RECIPE = CA / 'compile10/qwen-state-bfloat/identity.json'
SOURCE = R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc'
TAG = 'qwen-state'
MACRO = '/DHYLE_TEST_QWEN_GGUF_ARTIFACTS_HEADER='


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


cached = load('w02_cached_abi', CA / 'build.py')
b, c = cached.b, cached.c


def current(row):
    assert b.identity(row['path']) == row, row['path']


RETAINED_PROOF = S / 'integration/retained-header-equivalence.json'
RETAINED_PROOF_SHA = 'a04fd27d8ad3b009d011e41d41a87711b50610d0411236c343cf18d5b3550055'
RETAINED_HEADER_PAIRS = (
    ('include/hyle/compute/model_ops.h', 78969,
     '9654a9973b1c5ae56ed9295e348d2706b60cc9ebc1708e169fb5eba62a597b1b',
     '.scratch/mtp-packed-head-m2-20261023/source-final/source/include/hyle/compute/model_ops.h',
     79485, '351978e0a82a28cf9d4f7fbe9b75bf34bb65e03522de6e4f89a395a1975abbda'),
    ('include/hyle/compute/providers/cuda.h', 7236,
     'e28f0f8b2d790aafd5556908d8f1359d218691b43ea3a13bc2c647a4503907ea',
     '.scratch/dspark-original-target-tail-20261023/numeric-contract-source/before/include/hyle/compute/providers/cuda.h',
     7424, 'fe16eb6930251b2a95261fa89be3baf8f3d546bc06e46f8eb2a672322dfd8997'),
)


def retained_proof():
    identity = b.identity(RETAINED_PROOF)
    assert identity['bytes'] == 4911 and identity['sha256'] == RETAINED_PROOF_SHA
    proof = c.read(RETAINED_PROOF)
    assert len(proof['header_pairs']) == len(RETAINED_HEADER_PAIRS)
    for pair, expected in zip(proof['header_pairs'], RETAINED_HEADER_PAIRS, strict=True):
        path, old_bytes, old_sha, snapshot, new_bytes, new_sha = expected
        assert pair['cached_expected'] == dict(path=str(R / path), bytes=old_bytes, sha256=old_sha)
        assert pair['cached_snapshot'] == dict(path=str(R / snapshot), bytes=old_bytes, sha256=old_sha)
        assert pair['current_header'] == dict(path=str(R / path), bytes=new_bytes, sha256=new_sha)
        current(pair['cached_snapshot'])
        current(pair['current_header'])
        non_comments = lambda raw: [line for line in raw.splitlines() if not line.lstrip().startswith(b'//')]
        assert non_comments((R / snapshot).read_bytes()) == non_comments((R / path).read_bytes())
    return identity, proof['header_pairs']


def retained_current(row):
    if b.identity(row['path']) == row:
        return
    _, pairs = retained_proof()
    for pair in pairs:
        if row == pair['cached_expected']:
            # The exact old record remains historical. Only this known header
            # pair may reuse its object, with actual code lines proven equal.
            return
    current(row)  # Every unknown path/hash/size difference remains fatal.


def artifacts(header):
    header = Path(header).resolve()
    assert header.is_relative_to(R) and header.is_file()
    paths = [header, S / 'S01/roles-plan.json', S / 'S01/original-roles/acquisition.json',
             S / 'S01/original-roles/manifest.json', S / 'S01/original-roles/sidecar-files.json']
    receipt, manifest = c.read(paths[2]), c.read(paths[3])
    assert receipt['complete'] is True and manifest['complete'] is True
    assert receipt['original_roles'] == manifest['original_roles'] == 18
    assert receipt['role_payload_bytes'] == manifest['source_bytes'] == 1358645248
    assert receipt['source_plan']['sha256'] == b.identity(paths[1])['sha256']
    witness, actual = manifest['source_receipt'], b.identity(paths[2])
    assert witness['sha256'] == actual['sha256'] and witness['bytes'] == actual['bytes']
    assert (R / witness['path']).resolve() == paths[2].resolve()
    text = header.read_text(encoding='utf-8-sig')
    assert 'namespace qwen_gguf_original_artifacts::s01' in text
    assert b.identity(paths[2])['sha256'] in text and receipt['source_plan']['sha256'] in text
    for row in receipt['roles']:
        assert row['complete'] and row['payload']['sha256'] in text
        path = R / row['payload']['path']
        assert path.is_file() and path.stat().st_size == row['payload']['bytes']
    return [b.identity(path) for path in paths]


def host(attempt, header):
    pin_inputs = artifacts(header)
    recipe = c.read(RECIPE)
    assert c.read(RECIPE.with_name('compile.result.json'))['exit'] == 0
    out = S / f'compile{attempt}' / TAG
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    command = b.host_command(recipe['command'], SOURCE, TAG, out)
    assert all(flag in command for flag in ('/W4', '/WX', '/O2', '/MD',
        '/DHYLE_TEST_QWEN_STATE_CPU=1', '/DHYLE_TEST_QWEN_STATE_CUDA=1'))
    assert not any(arg.startswith(MACRO) for arg in command)
    # Passing an argument list preserves literal quote characters for the /D
    # string macro. Forward slashes avoid C string escape sequences in #include.
    command.insert(1, MACRO + '"' + Path(header).resolve().as_posix() + '"')
    frozen = b.identity(SOURCE)
    snapshot = out / 'source' / SOURCE.relative_to(R)
    snapshot.parent.mkdir(parents=True)
    snapshot.write_bytes(SOURCE.read_bytes())
    (out / 'artifacts-header.h').write_bytes(Path(header).read_bytes())
    c.save(out / 'plan.json', dict(source=frozen, command=command, recipe=b.identity(RECIPE),
        artifact_inputs=pin_inputs, script=b.identity(__file__), host_translation_units=1,
        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / (TAG + '-deps.json'))['Data']
    paths = list(dict.fromkeys([data['Source'], *data['Includes']]))
    assert c.key(header) in {c.key(path) for path in paths}, 'Actual generated pin header missing from compiler dependencies'
    current(frozen)
    for row in pin_inputs:
        current(row)
    c.save(out / 'identity.json', dict(source=frozen, object=b.identity(out / (TAG + '.obj')),
        command=command, recipe=b.identity(RECIPE), dependencies=[b.identity(path) for path in paths],
        artifact_inputs=pin_inputs, script=b.identity(__file__)))
    print('COMPILED one Qwen TU with real S01 pin dependency and unchanged CPU/CUDA ABI', flush=True)


def host_record(attempt):
    path = S / f'compile{attempt}' / TAG / 'identity.json'
    result = c.read(path.with_name('compile.result.json'))
    assert result['exit'] == 0 and result.get('terminal', True)
    record = c.read(path)
    assert c.key(record['source']['path']) == c.key(SOURCE)
    for row in [record['source'], record['object'], *record['dependencies'], *record['artifact_inputs']]:
        current(row)
    assert c.key(record['artifact_inputs'][0]['path']) in {c.key(row['path']) for row in record['dependencies']}
    return path, record


def link(attempt, compile_attempt):
    compiled_path, compiled = host_record(compile_attempt)
    base_path = BASE / 'link-plan.json'
    base = c.read(base_path)
    assert c.read(BASE / 'link.result.json')['exit'] == 0
    proof_identity, _ = retained_proof()
    retained, replaced = [], []
    graphs = {}
    for item in base['compiled_records']:
        current(item)
        record = c.read(item['path'])
        if c.key(record['source']['path']) == c.key(SOURCE):
            replaced.append((item, record))
        else:
            for row in [record['source'], record['object']]:
                current(row)
            for row in record['dependencies']:
                retained_current(row)
            retained.append(item)
            if c.key(record['source']['path']) in {c.key(R / 'src/graph/executable.cc'), c.key(R / 'src/graph/submission.cc')}:
                graphs[c.key(record['source']['path'])] = record['object']
    assert len(replaced) == 1 and len(graphs) == 2
    old = replaced[0][1]['object']
    current(old)
    assert sum(c.key(row['path']) == c.key(old['path']) for row in base['inputs']) == 1
    assert sum(c.key(arg) == c.key(old['path']) for arg in base['command']) == 1
    inputs = [compiled['object'] if c.key(row['path']) == c.key(old['path']) else row for row in base['inputs']]
    for row in inputs:
        current(row)
    command = [compiled['object']['path'] if c.key(arg) == c.key(old['path']) else arg
        for arg in base['command'] if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    for row in graphs.values():
        assert sum(c.key(item['path']) == c.key(row['path']) and item == row for item in inputs) == 1
        assert sum(c.key(arg) == c.key(row['path']) for arg in command) == 1
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'qwen-gguf-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(compiled_path), *retained], replaced_qwen_record=replaced[0][0],
        retained_fixed_graph_objects=list(graphs.values()), artifact_inputs=compiled['artifact_inputs'],
        retained_header_equivalence=proof_identity,
        base=b.identity(base_path), host_translation_units=1, product_host_translation_units=0,
        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0))
    env, _ = b.environment(command, [row['path'] for row in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        current(dll)
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(path for path in runtime['PATH'].split(';') if c.key(path) != c.key(BASE))
    runtime['staged_dlls'] = [b.identity(path) for path in out.glob('*.dll')]
    runtime['previous'] = b.identity(BASE / 'runtime-environment.json')
    runtime['host_translation_units'] = 1
    runtime['product_host_translation_units'] = 0
    runtime['full_SDK_builds'] = runtime['native_CPU_TUs'] = runtime['NVCC_builds'] = 0
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image), source_record=b.identity(compiled_path),
        link_plan=b.identity(out / 'link-plan.json'), artifact_inputs=compiled['artifact_inputs']))
    print('LINKED one replaced Qwen TU; both repaired Graph objects retained; DLLs hardlinked', flush=True)


SUFFIX = 'OriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'
SIDECAR = 'Q27SidecarOriginalNextNAndMainTargetFullVocabularyVerifierPublishesRepairedPrefix'
CASES = {'s01cpu': 'QwenMtpStateConsumer.Cpu' + SIDECAR,
         's01cuda': 'QwenMtpStateConsumer.Cuda' + SIDECAR,
         'primarycpu': 'QwenMtpStateConsumer.CpuQ27' + SUFFIX,
         'primarycuda': 'QwenMtpStateConsumer.CudaQ27' + SUFFIX,
         'b05cpu': 'QwenMtpStateConsumer.CpuQ24OriginalBFloatTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'}


def legacy_environment():
    # Read the actual existing QB config expression, without importing/running
    # its build script or duplicating/guessing the three original source paths.
    parsed = ast.parse((QB / 'build.py').read_text(encoding='utf-8-sig'))
    function = next(node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name == 'run')
    definition = next(node for node in ast.walk(function) if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == 'legacy_role_paths' for target in node.targets))
    assert isinstance(definition.value, ast.Call) and isinstance(definition.value.func, ast.Name) and definition.value.func.id == 'dict'
    needed = {'HYLE_QWEN27_MTP_INPUT_DIR', 'HYLE_QWEN27_ORIGINAL_NEXTN_DIR', 'HYLE_QWEN27_ORIGINAL_TARGET_DIR'}
    result = {}
    for item in definition.value.keywords:
        if item.arg in needed:
            value = item.value
            assert isinstance(value, ast.BinOp) and isinstance(value.op, ast.Div)
            assert isinstance(value.left, ast.Name) and value.left.id == 'R' and isinstance(value.right, ast.Constant)
            result[item.arg] = R / value.right.value
    assert set(result) == needed and all(path.is_dir() for path in result.values())
    return result


def b05_environment():
    # Resolve the two actual B05 paths from the existing QB run configuration.
    # Do not import its driver or enable its external download/wait protocol.
    parsed = ast.parse((QB / 'build.py').read_text(encoding='utf-8-sig'))
    function = next(node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name == 'run')
    assignments = {target.id: node.value for node in ast.walk(function) if isinstance(node, ast.Assign)
        for target in node.targets if isinstance(target, ast.Name) and target.id in ('role_dir', 'experts')}
    role = assignments['role_dir']
    assert isinstance(role, ast.BinOp) and isinstance(role.op, ast.Div)
    assert isinstance(role.left, ast.Name) and role.left.id == 'S' and isinstance(role.right, ast.IfExp)
    condition = role.right.test
    assert isinstance(condition, ast.Compare) and isinstance(condition.left, ast.Name) and condition.left.id == 'source'
    assert len(condition.ops) == 1 and isinstance(condition.ops[0], ast.Eq)
    assert len(condition.comparators) == 1 and isinstance(condition.comparators[0], ast.Constant)
    assert condition.comparators[0].value == 'bfloat-moe' and isinstance(role.right.body, ast.Constant)
    expert = assignments['experts']
    assert isinstance(expert, ast.BinOp) and isinstance(expert.op, ast.Div)
    assert isinstance(expert.left, ast.Name) and expert.left.id == 'S' and isinstance(expert.right, ast.Constant)
    needed = {'HYLE_QWEN_BFLOAT_24_DIR': 'role_dir', 'HYLE_QWEN_BFLOAT_24_EXPERT_DIR': 'experts'}
    definitions = [node.value for node in ast.walk(function) if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == 'role_paths' for target in node.targets)]
    assert any(isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == 'dict'
        and {item.arg: item.value.id for item in value.keywords if isinstance(item.value, ast.Name)} == needed
        and len(value.keywords) == 2 for value in definitions)
    result = dict(HYLE_QWEN_BFLOAT_24_DIR=QB / role.right.body.value,
                  HYLE_QWEN_BFLOAT_24_EXPERT_DIR=QB / expert.right.value)
    assert all(path.is_dir() for path in result.values())
    return result


def run(link_attempt, attempt, selected, timeout, list_only=False):
    folder = S / f'tests-link{link_attempt}'
    ready = c.read(folder / 'ready.json')
    for row in [ready['image'], ready['source_record'], ready['link_plan'], *ready['artifact_inputs']]:
        current(row)
    plan = c.read(ready['link_plan']['path'])
    proof_identity, _ = retained_proof()
    assert plan['retained_header_equivalence'] == proof_identity
    for info in plan['compiled_records']:
        current(info)
        record = c.read(info['path'])
        for row in [record['source'], record['object'], *record.get('artifact_inputs', [])]:
            current(row)
        for row in record['dependencies']:
            if c.key(info['path']) == c.key(ready['source_record']['path']):
                current(row)  # New Qwen TU and all its pins are always strict.
            else:
                retained_current(row)
    current_pins = artifacts(ready['artifact_inputs'][0]['path'])
    assert current_pins == ready['artifact_inputs']
    env = os.environ.copy()
    for name in list(env):
        if name.startswith('HYLE_QWEN'):
            env.pop(name)
    role_paths = b05_environment() if selected == 'b05cpu' else legacy_environment()
    if selected.startswith('s01'):
        role_paths['HYLE_QWEN27_ORIGINAL_SIDECAR_DIR'] = S01_DIRECTORY
    for name, path in role_paths.items():
        assert path.is_dir()
        env[name] = str(path)
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    temporary = S / 'runtime-tmp'
    temporary.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(temporary)
    expected = CASES[selected]
    out = S / (f'listing{attempt}' if list_only else f'checks{attempt}')
    command = [ready['image']['path'], '--gtest_filter=' + expected]
    command += ['--gtest_list_tests'] if list_only else ['--gtest_output=xml:' + str(out / 'results.xml')]
    environment = {name:env[name] for name in ['PATH', 'TMP', 'TEMP', *role_paths]}
    (S / 'run-plans').mkdir(exist_ok=True)
    c.save(S / 'run-plans' / (out.name + '.json'), dict(command=command, environment=environment,
        image=ready['image'], source_record=ready['source_record'], artifact_inputs=current_pins,
        link_plan=ready['link_plan'], environment_config=b.identity(QB / 'build.py'), expected_case=expected))
    quality = load('w02_existing_process_runner', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    process = quality.execute(command, env, out, timeout=timeout)
    c.save(out / 'environment.json', environment)
    result = dict(process=process, terminal=True, image=ready['image'], selected_cases=[expected],
        source_record=ready['source_record'], link_plan=ready['link_plan'], artifact_inputs=current_pins,
        environment=environment, retained_header_equivalence=proof_identity,
        throughput_evidence=False, whole_original_model=False,
        scope=('S01 original draft plus explicitly paired MAIN target63/head' if selected.startswith('s01') else
               'Affected original B05 BF16 MoE target91/NextN92 regression with existing selected cache' if selected == 'b05cpu' else
               'Original primary Q27 NextN64 plus target63/head') +
              '; finite upstream/history fixtures; no model quality/TPS claim')
    if list_only:
        suite, listed = None, []
        for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines():
            if line and not line[0].isspace() and line.rstrip().endswith('.'):
                suite = line.strip()
            elif suite and line.startswith('  '):
                listed.append(suite + line.strip().split(' #', 1)[0])
        result['listed_cases'] = listed
    elif (out / 'results.xml').is_file():
        root = ET.parse(out / 'results.xml').getroot()
        result.update(tests=int(root.attrib['tests']), failures=int(root.attrib['failures']),
            errors=int(root.attrib['errors']), disabled=int(root.attrib['disabled']),
            skips=sum(case.find('skipped') is not None for case in root.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']:p.attrib['value']
                for p in case.iter('property')}) for case in root.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert process['exit'] == 0 and not process['timed_out'], process
    if list_only:
        assert result['listed_cases'] == [expected], result
    else:
        assert result.get('tests') == 1 and not any(result[key] for key in ('failures', 'errors', 'disabled', 'skips')), result
        assert {case['attributes']['classname'] + '.' + case['attributes']['name'] for case in result['cases']} == {expected}
    print('LISTED' if list_only else 'PASS', expected, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['compile', 'link', 'run', 'list'])
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--artifacts-header', type=Path)
    parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--case', choices=list(CASES), default='s01cpu')
    parser.add_argument('--timeout', type=int, default=1800)
    args = parser.parse_args()
    assert min(args.attempt, args.compile_attempt, args.link_attempt, args.timeout) > 0
    if args.action == 'compile':
        if args.artifacts_header is None:
            parser.error('compile requires the actual generated --artifacts-header')
        host(args.attempt, args.artifacts_header)
    elif args.action == 'link':
        link(args.attempt, args.compile_attempt)
    else:
        run(args.link_attempt, args.attempt, args.case, args.timeout, args.action == 'list')
