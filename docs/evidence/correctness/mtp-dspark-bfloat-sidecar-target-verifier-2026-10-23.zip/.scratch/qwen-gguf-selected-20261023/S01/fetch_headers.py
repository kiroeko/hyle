"""Authenticate S01's exact GGUF metadata prefix, never tensor payload.

Offline: python .scratch/qwen-gguf-selected-20261023/S01/fetch_headers.py --plan-only
Root acquisition: the same command without --plan-only. This script has no body mode.
The GGUF parser is locally parameterized from frozen S02/fetch.py; that file is
not imported or modified. Exact HTTP validation reuses the bounded206 helper.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import struct

S = Path(__file__).resolve().parent
R = S.parents[2]
REPO = 'unsloth/Qwen3.8-27B-GGUF'
REV = '4ca720788d1e01f1bff70c033e0d0028fd02e502'
FILE = 'MTP/mtp-Qwen3.8-27B-Q4_0.gguf'
URL = f'https://huggingface.co/{REPO}/resolve/{REV}/{FILE}'
HEADER_BYTES = 10945408
CACHE_KEY = 'aa4c5cdcdc17cc7feb5432611b417069f9c67d3dbb47f48d4265fb1df76572e4'
TABLE_SHA = '99290cc16affe6677dae6c8ab093842df0e838bec9f96984439d3cd17598cf2e'
MINIMAL = R / '.scratch/qwen-gguf-selected-20261023/review/w02-minimal-plan.json'
CACHE = R / '.scratch/validation/cpu-quant-mtp-c1/headers.json'
PUBLISHED = R / 'docs/evidence/correctness/cpu-quant-mtp-c4-three-stage/sidecar-roles.json'
HTTP_HELPER = R / '.scratch/mtp-artifact-schema-20261023/fetch_headers.py'
PARSER_SOURCE = R / '.scratch/dspark-gguf-vocabulary-20261023/fetch.py'
# Actual encodings present in this finite source, block elements/physical bytes.
CODECS = {0: ('F32', 1, 4), 11: ('Q3_K', 256, 110),
          12: ('Q4_K', 256, 144), 14: ('Q6_K', 256, 210)}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))


def save(path, value):
    # No partially written successful metadata plan is exposed after a failure.
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def canonical_tensor(row):
    return dict(name=row['name'], shape=list(map(int, row['shape'])),
                dtype_code=int(row['dtype_code']), offset=int(row['offset']))


def checked_cached_plan():
    proposal = next(row for row in read(MINIMAL)['identities'] if row['id'] == 'S01')
    cached = read(CACHE)[CACHE_KEY]
    published = next(row for row in read(PUBLISHED) if row['file'] == FILE)
    for record in (proposal, cached, published):
        assert (record['repository'], record['revision'], record['file']) == (REPO, REV, FILE)
    assert cached['url'] == published['url'] == URL
    assert proposal['data_base'] == int(cached['tensor_data_offset']) == HEADER_BYTES
    assert len(proposal['roles']) == cached['tensor_count'] == published['tensor_count'] == 18
    assert sha(json.dumps(cached['tensors'], ensure_ascii=False, separators=(',', ':')).encode()) == TABLE_SHA
    assert proposal['raw_cached_tensor_table_sha256'] == cached['tensor_table_sha256'] == TABLE_SHA
    assert proposal['published_tensor_table_digest'] == published['tensor_table_digest']
    expected = [canonical_tensor(row) for row in cached['tensors']]
    assert expected == [canonical_tensor(row) for row in published['tensors']]
    assert len({row['name'] for row in expected}) == 18
    roles, previous_end = [], 0
    for ordinal, (tensor, role) in enumerate(zip(expected, proposal['roles'], strict=True)):
        name, block, physical = CODECS[tensor['dtype_code']]
        assert name == role['native'] and tensor['shape'] == role['gguf_shape']
        assert tensor['name'] == role['name'] and tensor['offset'] == role['relative_offset']
        assert tensor['shape'][0] % block == 0 and all(n > 0 for n in tensor['shape'])
        size = math.prod(tensor['shape']) // block * physical
        assert size == role['bytes'] and tensor['offset'] >= previous_end
        assert tensor['offset'] % 32 == 0
        first = HEADER_BYTES + tensor['offset']
        assert first == role['absolute_first']
        roles.append(dict(ordinal=ordinal, name=tensor['name'], filename=tensor['name'] + '.bin',
                          dtype=name, dtype_code=tensor['dtype_code'], shape=tensor['shape'],
                          bytes=size, source_shard=0,
                          data_relative_half_open=[tensor['offset'], tensor['offset'] + size],
                          absolute_inclusive=[first, first + size - 1], payload_sha256=None))
        previous_end = tensor['offset'] + size
    assert sum(row['bytes'] for row in roles) == proposal['all18_payload_bytes'] == 1358645248
    assert HEADER_BYTES + previous_end == proposal['minimum_body_end'] == 1369590656
    return cached, expected, roles


def parse_header(raw, tensor_count, header_bytes, retained_metadata):
    """S02 parser with finite count/length parameters and skipped large metadata arrays."""
    offset = 0

    def unpack(fmt):
        nonlocal offset
        size = struct.calcsize('<' + fmt)
        assert offset + size <= len(raw), 'GGUF metadata exceeds the exact header'
        result = struct.unpack_from('<' + fmt, raw, offset)
        offset += size
        return result[0] if len(result) == 1 else result

    def string(keep=True):
        nonlocal offset
        size = unpack('Q')
        assert size <= len(raw) - offset
        result = raw[offset:offset + size].decode('utf-8') if keep else None
        offset += size
        return result

    def value(kind, keep=True):
        formats = {0: 'B', 1: 'b', 2: 'H', 3: 'h', 4: 'I', 5: 'i', 6: 'f',
                   7: '?', 10: 'Q', 11: 'q', 12: 'd'}
        if kind in formats:
            result = unpack(formats[kind])
            return result if keep else None
        if kind == 8:
            return string(keep)
        if kind == 9:
            element, count = unpack('I'), unpack('Q')
            assert element != 9 and count <= len(raw)
            if keep:
                return [value(element) for _ in range(count)]
            for _ in range(count):
                value(element, False)
            return None
        raise ValueError('Unknown GGUF metadata type ' + str(kind))

    assert len(raw) == header_bytes and raw[:4] == b'GGUF'
    offset = 4
    assert unpack('I') in (2, 3)
    actual_count, metadata_count = unpack('Q'), unpack('Q')
    assert actual_count == tensor_count and metadata_count <= 1000
    metadata, seen = {}, set()
    for _ in range(metadata_count):
        key = string()
        assert key not in seen
        seen.add(key)
        kind = unpack('I')
        keep = key in retained_metadata or key == 'general.alignment'
        result = value(kind, keep)
        if keep:
            metadata[key] = result
    tensors = []
    for _ in range(actual_count):
        name, rank = string(), unpack('I')
        assert 0 < rank <= 4
        dimensions = [unpack('Q') for _ in range(rank)]
        assert all(n > 0 for n in dimensions)
        tensors.append(dict(name=name, shape=dimensions, dtype_code=unpack('I'), offset=unpack('Q')))
    alignment = metadata.get('general.alignment', 32)
    assert type(alignment) is int and 0 < alignment <= 4096
    assert (offset + alignment - 1) // alignment * alignment == header_bytes
    assert len({row['name'] for row in tensors}) == tensor_count
    return metadata, tensors, metadata_count


def plan_record(roles, receipt=None):
    authenticated = receipt is not None
    return dict(id='S01', repository=REPO, revision=REV, file=FILE, url=URL,
                original_roles=18, source_bytes=1358645248, data_base=HEADER_BYTES,
                shards=[dict(file=FILE, url=URL, data_base=HEADER_BYTES,
                             whole_file_bytes=receipt['whole_file_bytes'] if authenticated else None,
                             etag=receipt['etag'] if authenticated else None,
                             header=receipt['header'] if authenticated else None)],
                roles=roles, source_plan=identity(MINIMAL), cached_header=identity(CACHE),
                published_census=identity(PUBLISHED), raw_cached_tensor_table_sha256=TABLE_SHA,
                complete_absolute_ranges=True, http_identity_authenticated=authenticated,
                metadata_only=True, tensor_payload_bytes=0, whole_shards_downloaded=False,
                note='Original 15 NextN roles + its own embedding/head + separate output_norm. '
                     'This sidecar contains no target63 parameters; payload SHA pins remain absent.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true', help='Only verify local cached metadata; zero HTTP.')
    args = parser.parse_args()
    S.mkdir(parents=True, exist_ok=True)
    cached, expected, roles = checked_cached_plan()
    if args.plan_only:
        save(S / 'cached-plan.json', plan_record(roles))
        print(json.dumps(dict(complete=True, offline=True, http_identity_authenticated=False,
                              plan=identity(S / 'cached-plan.json'), roles=18, payload_bytes=1358645248,
                              planned_metadata_range=[0, HEADER_BYTES - 1], network_bytes=0)))
        return
    path, receipt_path = S / 'original-header.bin', S / 'header.json'
    if receipt_path.exists():
        receipt = read(receipt_path)
        assert (receipt['repository'], receipt['revision'], receipt['file'], receipt['url']) == (REPO, REV, FILE, URL)
        assert receipt['http_status'] == 206 and receipt['range'] == [0, HEADER_BYTES - 1]
        assert identity(path) == receipt['header'] and receipt['whole_file_bytes'] >= 1369590656
        assert receipt['etag'].startswith('"') and receipt['etag'].endswith('"')
        raw = path.read_bytes()
    else:
        assert not path.exists(), 'Unreceipted cached header requires explicit root review'
        spec = importlib.util.spec_from_file_location('s01_exact_metadata_http', HTTP_HELPER)
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)  # No helper __main__/body/downloader is invoked.
        helper.MAX_TOTAL = HEADER_BYTES
        try:
            raw, whole, etag = helper.exact(URL, 0, HEADER_BYTES - 1)
        finally:
            save(S / 'http-requests.json', helper.requests)
        assert whole >= 1369590656
        receipt = dict(repository=REPO, revision=REV, file=FILE, url=URL,
                       http_status=206, range=[0, HEADER_BYTES - 1], whole_file_bytes=whole,
                       etag=etag, tensor_payload_bytes=0, http_helper=identity(HTTP_HELPER),
                       parser_origin=identity(PARSER_SOURCE))
    metadata, actual, metadata_count = parse_header(raw, 18, HEADER_BYTES, cached['metadata'])
    assert actual == expected, 'Fresh full tensor table differs from the fixed cached S01 table'
    assert all(key in metadata and metadata[key] == val for key, val in cached['metadata'].items())
    assert all(row['absolute_inclusive'][1] < receipt['whole_file_bytes'] for row in roles)
    # Commit successful bytes/receipt only after the full metadata comparison.
    path.write_bytes(raw)
    receipt.update(header=identity(path), tensor_count=18, metadata_count=metadata_count,
                   data_base=HEADER_BYTES, complete=True, cached_tensor_table_matches=True,
                   raw_cached_tensor_table_sha256=TABLE_SHA, cached_source=identity(CACHE))
    save(receipt_path, receipt)
    save(S / 'roles-plan.json', plan_record(roles, receipt))
    save(S / 'summary.json', dict(complete=True, repository=REPO, revision=REV, file=FILE,
                                header=identity(receipt_path), plan=identity(S / 'roles-plan.json'),
                                http_identity_authenticated=True, original_roles=18,
                                tensor_payload_bytes=0, network_metadata_budget=HEADER_BYTES,
                                artifact_executed=False, native_builds=0))
    print(json.dumps(read(S / 'summary.json')))


if __name__ == '__main__':
    main()
