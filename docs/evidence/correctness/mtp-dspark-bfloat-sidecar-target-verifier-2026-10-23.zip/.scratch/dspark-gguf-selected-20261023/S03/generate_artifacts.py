"""Export S03's real static catalogue pin after a completed acquisition.

Only small metadata is hashed here. Data::load authenticates roles.bin itself.
An absent/incomplete body or inconsistent receipt produces no generated header.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
ACQUIRE = S / 'payload-proposal/acquire.py'
ACQUIRE_SHA = '1870f9b3fbab74eb27b7eec1754fdc05d53a11bbc181537f53734369d606426b'


def require(value, message):
    if not value:
        raise ValueError(message)


def pin(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.resolve().relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def check_identity(record, path):
    require(record == identity(path), 'Actual small metadata identity differs: ' + str(path))


def validate(directory):
    require(identity(ACQUIRE)['sha256'] == ACQUIRE_SHA, 'Frozen S03 acquisition helper changed')
    spec = importlib.util.spec_from_file_location('_s03_acquisition_metadata', ACQUIRE)
    acquire = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(acquire)
    static, experts = acquire.fixed_source()  # authenticated header metadata, no HTTP
    receipt_path = directory / 'acquisition.json'
    require(receipt_path.is_file(), 'Complete S03 static acquisition is required before generating pins')
    record = read(receipt_path)
    require(record.get('complete') is True, 'Incomplete S03 acquisition cannot generate pins')
    require((record['repository'], record['revision']) == (acquire.REPO, acquire.REV),
            'Static acquisition artifact identity differs')
    require(record['source_plan'] == (S / 'static-plan.json').relative_to(R).as_posix() and
            record['source_plan_sha256'] == acquire.STATIC_PLAN_SHA,
            'Static acquisition source-plan pin differs')
    require(record['original_roles'] == 72 and record['bundle_bytes'] ==
            record['role_payload_bytes'] == acquire.STATIC_BYTES,
            'Static acquisition count/body extent differs')
    require(record['whole_shards_downloaded'] is False and record['unrequested_bytes'] == 0,
            'Static acquisition scope differs')
    require(record['groups'] == static['groups'] and record['shards'] == static['shards'],
            'Static acquisition physical ranges differ')
    bundle = directory / 'roles.bin'
    require((R / record['bundle']['path']).resolve() == bundle.resolve() and bundle.is_file() and
            bundle.stat().st_size == record['bundle']['bytes'] == acquire.STATIC_BYTES and
            pin(record['bundle']['sha256']), 'Static bundle extent/path/hash certificate differs')
    acquire.check_catalog(record, 72, acquire.STATIC_BYTES)
    typed_path, catalogue_path = directory / 'catalog.bin', directory / 'catalog.json'
    check_identity(record['typed_catalog'], typed_path)
    check_identity(record['catalog'], catalogue_path)
    catalogue = read(catalogue_path)
    require((catalogue['repository'], catalogue['revision'], catalogue['original_roles']) ==
            (acquire.REPO, acquire.REV, 72), 'Static catalogue identity/count differs')
    require(catalogue['bundle'] == dict(file='roles.bin', bytes=acquire.STATIC_BYTES,
            sha256=record['bundle']['sha256']), 'Static catalogue bundle hash differs')
    require(len(catalogue['roles']) == 72, 'Static catalogue must contain all72 exact roles')
    typed = typed_path.read_bytes()
    for index, (actual, expected) in enumerate(zip(catalogue['roles'], static['roles'], strict=True)):
        require(all(actual.get(key) == value for key, value in expected.items()) and pin(actual.get('sha256')),
                'Static catalogue role differs: ' + expected['name'])
        require(struct.unpack_from('<QQ', typed, 64 + 16 * index) ==
                (expected['bundle_offset'], expected['bytes']), 'Typed catalogue role order differs')
    # Require a complete, contiguous physical-range certificate for every role.
    require(len(record['chunks']) > 0, 'Static acquisition has no authenticated range certificates')
    for group in static['groups']:
        cursor = group['bundle_offset']
        for part in sorted((part for part in record['chunks'] if part['group'] == group['index']),
                           key=lambda part: part['offset']):
            require(part['offset'] == cursor and 0 < part['bytes'] <= record['chunk_bytes'] and pin(part['sha256']),
                    'Static role range certificate has a gap/overlap')
            first = group['first'] + cursor - group['bundle_offset']
            require(part['absolute_inclusive'] == [first, first + part['bytes'] - 1],
                    'Static role certificate source range differs')
            cursor += part['bytes']
        require(cursor == group['bundle_offset'] + group['bytes'], 'Static role certificate is incomplete')
    require(sum(part['bytes'] for part in record['chunks']) == acquire.STATIC_BYTES,
            'Static certificate contains unrelated or duplicated bytes')
    header = read(S / 'header.json')
    vocabulary_path = R / static['reused_vocabulary']['path']
    check_identity(static['reused_vocabulary'], vocabulary_path)
    require(read(vocabulary_path)['complete'] is True, 'Reused S02 vocabulary is incomplete')
    return acquire, record, header, static, experts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=S / 'original-static')
    parser.add_argument('--output', type=Path, default=S / 'generated/dspark_bfloat_sidecar_artifacts.h')
    args = parser.parse_args()
    directory = args.directory.resolve()
    acquire, record, header, static, experts = validate(directory)
    receipt_identity = identity(directory / 'acquisition.json')
    values = dict(kRepository=acquire.REPO, kRevision=acquire.REV, kFile=acquire.FILE,
        kStaticCatalogueSha256=record['typed_catalog']['sha256'],
        kStaticAcquisitionSha256=receipt_identity['sha256'], kStaticBundleSha256=record['bundle']['sha256'],
        kStaticPlanSha256=acquire.STATIC_PLAN_SHA, kExpertSourcePlanSha256=acquire.EXPERT_PLAN_SHA,
        kOriginalHeaderSha256=header['header']['sha256'], kOriginalFileETag=header['etag'],
        kVocabularyManifestSha256=static['reused_vocabulary']['sha256'])
    lines = ['#pragma once', '#include <cstddef>', '#include <string_view>',
             '// Generated from a COMPLETE real S03 static acquisition; never from cached shape metadata.',
             'namespace dspark_bfloat_sidecar_artifacts {']
    lines += ['inline constexpr std::string_view ' + key + '=' + json.dumps(value) + ';'
              for key, value in values.items()]
    lines += ['inline constexpr std::size_t kStaticRoles=72,kStaticBytes=1041922972;',
              'inline constexpr std::size_t kOriginalHeaderBytes=5253152,kOriginalFileBytes=11314832480;',
              '} // namespace dspark_bfloat_sidecar_artifacts', '']
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text('\n'.join(lines), encoding='utf-8', newline='\n')
    result = dict(complete=True, repository=acquire.REPO, revision=acquire.REV, file=acquire.FILE,
        static_directory=directory.relative_to(R).as_posix(), static_acquisition=receipt_identity,
        typed_catalog=record['typed_catalog'], bundle=record['bundle'], original_header=header['header'],
        original_file=dict(url=header['url'], bytes=header['whole_file_bytes'], etag=header['etag'],
                           sha256=None, note='Only selected payload ranges are acquired; no whole-file SHA is asserted.'),
        source_plan=identity(S / 'static-plan.json'), expert_source_plan=identity(S / 'expert-source-plan.json'),
        reused_vocabulary=static['reused_vocabulary'], new_vocabulary_bytes=0,
        generated_header=identity(args.output), body_rehashed=False, network_requests=0)
    acquire.save(args.output.with_suffix('.json'), result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
