"""Root-only S03 static72 / selected-expert proposal; --plan-only is offline.

  python acquire.py static --plan-only
  python acquire.py experts --stage 0 --ids 1 7 --plan-only
  python acquire.py experts --frontier-file REQUEST.json
Fresh authenticated S03 headers/plans must exist first. No vocabulary fetch,
whole expert-bank request, conversion, native/model execution or full GGUF copy.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import importlib.util
import json
from pathlib import Path
import struct
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent.parent
R = S.parents[2]
FETCH = R / '.scratch/dspark-pro-target-draft-20261023/fetch_dense.py'
FETCH_SHA = '37d4414444a565f5b393d6908c63d176996c32cd359f519a60661f702091d5bf'
LOCK_HELPER = R / '.scratch/qwen-bfloat-selected-20261023/fetch_roles.py'
REPO = 'unsloth/DeepSeek-V4-Flash-0731-GGUF'
REV = 'fbbb5b93fb787c21338159b0af3318bb3f4d9768'
FILE = 'dspark/dspark-DeepSeek-V4-Flash-0731-BF16.gguf'
HEADER, STATIC_BYTES, STRIDE = 5253152, 1041922972, 4456448
HEADER_RECEIPT_SHA = '6e831a9e97c1d69057c4f11c4d6e52b540e8f3d3353590f1e9d5a0f71558f78c'
STATIC_PLAN_SHA = '2e7eb0a9fc9c19995d41d2d41c93dd928c082a3e9e5b756aaf9c26132310e428'
EXPERT_PLAN_SHA = 'e3cfe35aec5870034d0b384553fd90b242806e63fedab435d18c16969324984f'
EXPERT_BYTES, DOMAIN, CAPACITY = 13369344, 256, 30
LEGS = ('gate', 'up', 'down')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


headers = module('s03_payload_header_support', S / 'fetch_headers.py')
read, identity, save = headers.read, headers.identity, headers.save


def fixed_source():
    proposal, cached, expected = headers.cached_plan()
    receipt_path = S / 'header.json'
    if not receipt_path.exists():
        raise ValueError('Root must first complete S03/fetch_headers.py; cached offsets alone are not HTTP identity')
    assert identity(receipt_path)['sha256'] == HEADER_RECEIPT_SHA
    assert identity(S / 'static-plan.json')['sha256'] == STATIC_PLAN_SHA
    assert identity(S / 'expert-source-plan.json')['sha256'] == EXPERT_PLAN_SHA
    receipt = read(receipt_path)
    assert receipt['complete'] and receipt['all_cached_tensors_match'] and receipt['tensor_payload_bytes'] == 0
    assert (receipt['repository'],receipt['revision'],receipt['file'],receipt['url']) == (REPO,REV,FILE,headers.URL)
    assert receipt['http_status'] == 206 and receipt['range'] == [0,HEADER-1]
    assert receipt['whole_file_bytes'] >= proposal['minimum_whole_file_bytes']
    assert receipt['etag'].startswith('"') and receipt['etag'].endswith('"')
    assert identity(S / 'original-header.bin') == receipt['header']
    headers.validate_raw((S / 'original-header.bin').read_bytes(),cached,expected)
    summary = read(S / 'summary.json')
    assert summary['complete'] and summary['header'] == identity(receipt_path)
    for name,key in [('static-plan.json','static_plan'),('expert-source-plan.json','expert_source_plan')]:
        assert identity(S / name) == summary[key]
    static, experts = read(S / 'static-plan.json'), read(S / 'expert-source-plan.json')
    for plan in (static,experts):
        assert (plan['repository'],plan['revision'],plan['file']) == (REPO,REV,FILE)
        assert plan['source_format'] == 'GGUF' and plan['new_vocabulary_bytes'] == 0
        assert plan['source_header'] == identity(receipt_path) and plan['source_proposal'] == identity(headers.PROPOSAL)
        assert plan['reused_vocabulary'] == identity(headers.VOCAB)
        assert len(plan['shards']) == 1
        shard = plan['shards'][0]
        assert shard['file'] == FILE and shard['url'] == headers.URL and shard['data_base'] == HEADER
        assert shard['etag'] == receipt['etag'] and shard['whole_file_bytes'] == receipt['whole_file_bytes']
        assert shard['raw_gguf_header'] == receipt['header']
        assert identity(R / shard['header']['path']) == shard['header']
    expected_static = [row for row in proposal['roles'] if row['acquire_full_role']]
    assert len(static['roles']) == 72 and static['bundle_bytes'] == STATIC_BYTES
    assert len(static['groups']) == 72
    cursor = 0
    for index,(row,original,group) in enumerate(zip(static['roles'],expected_static,static['groups'],strict=True)):
        assert (row['name'],row['dtype'],row['dtype_code'],row['shape'],row['bytes'],row['absolute_inclusive']) == (
            original['name'],original['dtype'],original['dtype_code'],original['gguf_dimensions'],original['bytes'],original['absolute_inclusive'])
        assert row['index'] == group['index'] == index and row['source_shard'] == group['source_shard'] == 0
        assert row['bundle_offset'] == group['bundle_offset'] == cursor
        assert [group['first'],group['last']] == row['absolute_inclusive']
        assert group['bytes'] == row['bytes']
        cursor += row['bytes']
    assert cursor == STATIC_BYTES
    assert experts['roles'] == [row for row in proposal['roles'] if not row['acquire_full_role']]
    assert experts['expert_domain'] == DOMAIN and experts['per_selected_expert_bytes'] == EXPERT_BYTES
    return static,experts


def retain_plan(path, plan):
    if path.exists():
        assert read(path) == plan, 'Existing plan has a different original source'
    else:
        save(path,plan)


def expert_plan(source,stage,global_id,directory):
    table,rows,groups = {},[],[]
    offset = 0
    for index,leg in enumerate(LEGS):
        name = f'blk.{stage}.ffn_{leg}_exps.weight'
        bank = next(row for row in source['roles'] if row['name'] == name)
        assert bank['dtype'] == 'MXFP4' and bank['dtype_code'] == 39
        assert bank['selected_slice']['domain'] == DOMAIN and bank['selected_slice']['expert_stride_bytes'] == STRIDE
        assert bank['gguf_dimensions'][2] == DOMAIN and bank['bytes'] == STRIDE*DOMAIN
        first = bank['absolute_inclusive'][0] + global_id*STRIDE
        last = first+STRIDE-1
        assert last <= bank['absolute_inclusive'][1]
        shape = bank['gguf_dimensions'][:2]
        table[name] = dict(dtype='MXFP4',shape=shape,data_offsets=[first-HEADER,last+1-HEADER])
        rows.append(dict(index=index,name=name,dtype='MXFP4',dtype_code=39,shape=shape,bytes=STRIDE,
            section='draft',stage=stage,global_id=global_id,source_shard=0,bundle_offset=offset,
            data_relative_half_open=[first-HEADER,last+1-HEADER],absolute_inclusive=[first,last],
            source_bank=bank))
        groups.append(dict(index=index,source_shard=0,first=first,last=last,bundle_offset=offset,bytes=STRIDE))
        offset += STRIDE
    assert offset == EXPERT_BYTES
    projection_path = directory / 'header-table.json'
    # Explicit metadata-only expert view, derived from the original GGUF bank.
    # No code or scale byte is split, decoded or re-encoded.
    retain_plan(projection_path,table)
    shard = dict(source['shards'][0],header=identity(projection_path),source_format='GGUF_EXPERT_VIEW')
    return dict(repository=REPO,revision=REV,file=FILE,section='draft',stage=stage,global_ids=[global_id],
        original_roles=3,bundle_bytes=EXPERT_BYTES,whole_shards_downloaded=False,unrequested_bytes=0,
        source_format='GGUF_MXFP4_INLINE17_PER32',source_plan=identity(S / 'expert-source-plan.json'),
        source_header=source['source_header'],typed_order='gate,up,down; one explicit stage/global ID',
        shards=[shard],roles=rows,groups=groups)


def selected(args):
    if args.frontier_file:
        assert args.stage is None and args.ids is None
        request = read(args.frontier_file)
        assert request['section'] == 'draft'
        stage, ids = request['stage'], request['missing_ids']
        global_ids = request['global_ids']
        assert isinstance(global_ids,list) and global_ids == sorted(set(global_ids)) and len(global_ids) <= CAPACITY
        assert all(type(value) is int and 0 <= value < DOMAIN for value in global_ids)
        assert set(ids) <= set(global_ids)
    else:
        stage,ids = args.stage,args.ids
    assert type(stage) is int and 0 <= stage < 3
    assert isinstance(ids,list) and len(ids) <= CAPACITY
    assert all(type(value) is int and 0 <= value < DOMAIN for value in ids)
    return stage,sorted(set(ids))


def check_catalog(record,count,size):
    assert record['complete'] and record['bundle']['bytes'] == record['role_payload_bytes'] == size
    path = R / record['typed_catalog']['path']
    raw = path.read_bytes()
    assert identity(path) == record['typed_catalog'] and len(raw) == 64+16*count
    magic,version,n,body_bytes,reserved,digest = struct.unpack('<8sIIQQ32s',raw[:64])
    assert (magic,version,n,body_bytes,reserved) == (b'HYDSPT01',1,count,size,0)
    assert digest.hex() == record['bundle']['sha256']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['static','experts'])
    parser.add_argument('--stage',type=int,choices=range(3))
    parser.add_argument('--ids',type=int,nargs='+')
    parser.add_argument('--frontier-file',type=Path)
    parser.add_argument('--plan-only',action='store_true')
    args = parser.parse_args()
    static,experts = fixed_source()
    assert identity(FETCH)['sha256'] == FETCH_SHA
    fetch = module('s03_existing_bundle_downloader',FETCH)
    locks = module('s03_existing_single_writer',LOCK_HELPER)
    assert (fetch.CHUNK,fetch.IO,fetch.WORKERS) == (128*1024*1024,1024*1024,3)
    if args.action == 'static':
        assert args.stage is None and args.ids is None and args.frontier_file is None
        if args.plan_only:
            print(json.dumps(dict(complete=False,plan_only=True,original_roles=72,bundle_bytes=STATIC_BYTES,
                source_plan=identity(S/'static-plan.json'),typed_catalog_bytes=1216,new_vocabulary_bytes=0,network_requests=0)))
            return
        directory = S / 'original-static'
        directory.mkdir(parents=True,exist_ok=True)
        fetch.COUNT,fetch.BODY_BYTES,fetch.WORKERS = 72,STATIC_BYTES,3
        with locks.single_writer(directory / '.fetch.lock'):
            record = fetch.main(plan_path=S/'static-plan.json',out=directory)
            check_catalog(record,72,STATIC_BYTES)
        print(json.dumps(dict(complete=True,original_roles=72,bundle_bytes=STATIC_BYTES,
            directory=directory.relative_to(R).as_posix(),typed_catalog=record['typed_catalog'],
            acquisition=identity(directory/'acquisition.json'),new_vocabulary_bytes=0)))
        return
    stage,ids = selected(args)
    # Set once before all expert workers. Three IDs run concurrently, while
    # one unchanged downloader worker fetches each ID's three legs serially:
    # at most three HTTP streams /3MiB live stream buffers across this process.
    fetch.COUNT,fetch.BODY_BYTES,fetch.WORKERS = 3,EXPERT_BYTES,1
    def acquire(global_id):
        directory = S / 'original-experts/draft' / f'stage{stage}' / f'expert{global_id:03d}'
        directory.mkdir(parents=True,exist_ok=True)
        with locks.single_writer(directory/'.fetch.lock'):
            plan = expert_plan(experts,stage,global_id,directory)
            retain_plan(directory/'plan.json',plan)
            item = dict(repository=REPO,revision=REV,file=FILE,section='draft',stage=stage,global_ids=[global_id],
                directory=directory.relative_to(R).as_posix(),source_plan=identity(S/'expert-source-plan.json'),
                original_roles=3,bundle_bytes=EXPERT_BYTES,plan=identity(directory/'plan.json'),
                per_id_range_workers=1,outer_expert_workers=3,maximum_http_streams=3,
                maximum_live_stream_bytes=3*fetch.IO)
            if args.plan_only:
                return dict(item,complete=False,plan_only=True,network_requests=0)
            record = fetch.main(plan_path=directory/'plan.json',out=directory)
            check_catalog(record,3,EXPERT_BYTES)
            assert record['workers'] == 1
            item.update(complete=True,typed_catalog=record['typed_catalog'],catalog_sha256=record['typed_catalog']['sha256'],
                acquisition=identity(directory/'acquisition.json'))
            save(directory/'ready.json',item)
            return item
    completed,failures = [],[]
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = {pool.submit(acquire,global_id):global_id for global_id in ids}
        for future in as_completed(futures):
            try:
                completed.append(future.result())
            except Exception as error:
                failures.append(dict(global_id=futures[future],type=type(error).__name__,error=str(error)))
    # Every worker is terminal before this aggregate result is published.
    event = dict(event='expert_frontier_failed' if failures else
        'expert_frontier_planned' if args.plan_only else 'expert_frontier_complete',
        complete=not args.plan_only and not failures,plan_only=args.plan_only,section='draft',stage=stage,
        global_ids=ids,caches=sorted(completed,key=lambda row:row['global_ids'][0]),errors=failures,
        per_id_range_workers=1,outer_expert_workers=3,maximum_http_streams=3,maximum_live_stream_bytes=3*fetch.IO)
    print(json.dumps(event),flush=True)
    if failures:
        raise RuntimeError('Selected original S03 expert acquisition failed: '+json.dumps(failures))


if __name__ == '__main__':
    main()
