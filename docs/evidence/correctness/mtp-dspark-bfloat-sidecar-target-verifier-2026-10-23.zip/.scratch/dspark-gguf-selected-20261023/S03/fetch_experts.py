"""S03 frontier adapter for the unchanged bounded acquisition proposal."""
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent


def main():
    spec = importlib.util.spec_from_file_location('_s03_selected_acquisition', S / 'payload-proposal/acquire.py')
    acquire = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(acquire)
    sys.argv = [sys.argv[0], 'experts', *sys.argv[1:]]
    return acquire.main()


if __name__ == '__main__':
    sys.exit(main())
