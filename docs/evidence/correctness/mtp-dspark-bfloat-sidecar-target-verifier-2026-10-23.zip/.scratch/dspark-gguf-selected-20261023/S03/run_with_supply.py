"""S03 configuration of the existing Windows owned-process supply driver."""
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
DRIVER = R / '.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'


def main():
    spec = importlib.util.spec_from_file_location('_s03_owned_supply_driver', DRIVER)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    driver.S, driver.R = S, R
    driver.DOMAIN, driver.SECTIONS = 256, ('draft',)
    driver.WAIT_ENV = 'HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS'
    driver.FRONTIER_ENV = 'HYLE_DSPARK_BFLOAT_FRONTIER_FILE'
    return driver.main()


if __name__ == '__main__':
    sys.exit(main())
