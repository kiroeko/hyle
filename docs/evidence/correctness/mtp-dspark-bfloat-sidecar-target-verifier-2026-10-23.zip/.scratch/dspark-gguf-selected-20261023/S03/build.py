"""Root-only S03 one-test-TU increment on the actual GQ product closure.

Reuses both repaired Graph objects and the exact two comment-header proofs.
No SDK, worker, CUDA kernel, shader, provider or product TU is rebuilt here.
"""
import argparse
import ast
import importlib.util
import os
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
GQ = R / '.scratch/qwen-gguf-selected-20261023'
CA = R / '.scratch/dspark-pro-target-draft-20261023'
BASE = GQ / 'tests-link1'
RECIPE = CA / 'compile7/dspark-state/identity.json'
SOURCE = R / 'tests/compute_models/dspark_original_state_consumer_test.cc'
OLD_TEST = R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc'
TAG = 'dspark-state'
CASES = {
    'cpu': 'DSparkBfloatSidecarState.CpuOriginalBfloatSidecarAndTargetTailPublishesBlock5Prefix',
    'cuda': 'DSparkBfloatSidecarState.CudaOriginalBfloatSidecarAndTargetTailPublishesBlock5Prefix',
    's02cuda': 'DSparkOriginalState.CudaMainGgufQ8VocabularyAndOriginalTargetTailPublishesBlock5Prefix',
}


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Pure definitions only. Reuse the fixed proof rather than widening stale
# admission or editing historical compile records to match current headers.
cached = load('s03_actual_gq_closure', GQ / 'build.py')
b, c = cached.b, cached.c
current, retained_current, retained_proof = cached.current, cached.retained_current, cached.retained_proof


def artifact_inputs(header):
    header = Path(header).resolve()
    assert header.is_relative_to(R) and header.name == 'dspark_bfloat_sidecar_artifacts.h' and header.is_file()
    metadata_path = header.with_suffix('.json')
    metadata = c.read(metadata_path)
    assert metadata['complete'] is True and metadata['generated_header'] == {
        'path': header.relative_to(R).as_posix(), 'bytes': header.stat().st_size,
        'sha256': b.identity(header)['sha256']}
    generator = load('s03_static_artifact_check', S / 'generate_artifacts.py')
    _, record, _, static, _ = generator.validate(S / 'original-static')
    assert metadata['typed_catalog'] == record['typed_catalog'] and metadata['bundle'] == record['bundle']
    assert metadata['source_plan'] == generator.identity(S / 'static-plan.json')
    assert metadata['expert_source_plan'] == generator.identity(S / 'expert-source-plan.json')
    assert metadata['new_vocabulary_bytes'] == 0 and metadata['reused_vocabulary'] == static['reused_vocabulary']
    text = header.read_text(encoding='utf-8-sig')
    assert 'namespace dspark_bfloat_sidecar_artifacts' in text
    assert record['typed_catalog']['sha256'] in text and record['bundle']['sha256'] in text
    assert metadata['static_acquisition'] == generator.identity(S / 'original-static/acquisition.json')
    paths = [header, metadata_path, S / 'generate_artifacts.py', S / 'header.json',
        S / 'static-plan.json', S / 'expert-source-plan.json', S / 'original-static/acquisition.json',
        S / 'original-static/catalog.bin', S / 'original-static/catalog.json',
        R / static['reused_vocabulary']['path']]
    # Every body remains at its one canonical path. Validation above stat'ed
    # the1GiB bundle; native Data::load performs its actual hash authentication.
    return [b.identity(path) for path in paths]


def host(attempt, header):
    pins = artifact_inputs(header)
    recipe = c.read(RECIPE)
    assert c.read(RECIPE.with_name('compile.result.json'))['exit'] == 0
    assert c.key(recipe['source']['path']) == c.key(SOURCE)
    out = S / f'compile{attempt}' / TAG
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    command = b.host_command(recipe['command'], SOURCE, TAG, out)
    assert all(flag in command for flag in ('/W4', '/WX', '/O2', '/MD',
        '/DHYLE_TEST_DSPARK_STATE_CPU=1', '/DHYLE_TEST_DSPARK_STATE_CUDA=1'))
    command.insert(1, '/I' + str(Path(header).resolve().parent))
    source_identity = b.identity(SOURCE)
    snapshot = out / 'source' / SOURCE.relative_to(R)
    snapshot.parent.mkdir(parents=True)
    snapshot.write_bytes(SOURCE.read_bytes())
    (out / 'artifacts-header.h').write_bytes(Path(header).read_bytes())
    c.save(out / 'plan.json', dict(source=source_identity, command=command, recipe=b.identity(RECIPE),
        artifact_inputs=pins, script=b.identity(__file__), host_translation_units=1,
        product_host_translation_units=0, SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / (TAG + '-deps.json'))['Data']
    paths = list(dict.fromkeys([data['Source'], *data['Includes']]))
    assert c.key(header) in {c.key(path) for path in paths}, 'Actual generated S03 pin header missing from compiler dependencies'
    current(source_identity)
    for row in pins:
        current(row)
    c.save(out / 'identity.json', dict(source=source_identity, object=b.identity(out / (TAG + '.obj')),
        command=command, recipe=b.identity(RECIPE), dependencies=[b.identity(path) for path in paths],
        artifact_inputs=pins, script=b.identity(__file__)))
    print('COMPILED one actual DSpark TU with actual S03 pin dependency', flush=True)


def compiled(attempt):
    path = S / f'compile{attempt}' / TAG / 'identity.json'
    result = c.read(path.with_name('compile.result.json'))
    assert result['exit'] == 0 and result.get('terminal', True)
    record = c.read(path)
    assert c.key(record['source']['path']) == c.key(SOURCE)
    for row in [record['source'], record['object'], *record['dependencies'], *record['artifact_inputs']]:
        current(row)
    current(record['script'])
    assert c.key(record['artifact_inputs'][0]['path']) in {c.key(row['path']) for row in record['dependencies']}
    return path, record


def link(attempt, compile_attempt):
    path, fresh = compiled(compile_attempt)
    base_path = BASE / 'link-plan.json'
    base = c.read(base_path)
    assert c.read(BASE / 'link.result.json')['exit'] == 0
    proof, _ = retained_proof()
    retained, tests, graphs = [], [], {}
    for item in base['compiled_records']:
        current(item)
        record = c.read(item['path'])
        if '/tests/' in record['source']['path'].replace('\\', '/').lower():
            assert c.key(record['source']['path']) == c.key(OLD_TEST)
            tests.append((item, record))
            continue
        for row in [record['source'], record['object']]:
            current(row)
        for row in record['dependencies']:
            retained_current(row)
        retained.append(item)
        if c.key(record['source']['path']) in {c.key(R / 'src/graph/executable.cc'), c.key(R / 'src/graph/submission.cc')}:
            graphs[c.key(record['source']['path'])] = record['object']
    assert len(tests) == 1 and len(graphs) == 2
    old = tests[0][1]['object']
    current(old)
    assert sum(c.key(row['path']) == c.key(old['path']) for row in base['inputs']) == 1
    assert sum(c.key(arg) == c.key(old['path']) for arg in base['command']) == 1
    inputs = [fresh['object'] if c.key(row['path']) == c.key(old['path']) else row for row in base['inputs']]
    for row in inputs:
        current(row)
    command = [fresh['object']['path'] if c.key(arg) == c.key(old['path']) else arg
        for arg in base['command'] if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    for row in graphs.values():
        assert sum(item == row for item in inputs) == 1
        assert sum(c.key(arg) == c.key(row['path']) for arg in command) == 1
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'dspark-s03-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(path), *retained], replaced_test_record=tests[0][0],
        retained_fixed_graph_objects=list(graphs.values()), retained_header_equivalence=proof,
        artifact_inputs=fresh['artifact_inputs'], base=b.identity(base_path), host_translation_units=1,
        product_host_translation_units=0, SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0))
    env, _ = b.environment(command, [row['path'] for row in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        current(dll)
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(p for p in runtime['PATH'].split(';') if c.key(p) != c.key(BASE))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    runtime['previous'] = b.identity(BASE / 'runtime-environment.json')
    runtime['host_translation_units'], runtime['product_host_translation_units'] = 1, 0
    runtime['full_SDK_builds'] = runtime['native_CPU_TUs'] = runtime['NVCC_builds'] = 0
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image), source_record=b.identity(path),
        link_plan=b.identity(out / 'link-plan.json'), artifact_inputs=fresh['artifact_inputs']))
    print('LINKED one DSpark test TU; GQ product closure and both Graph fixes retained', flush=True)


def s02_environment():
    # The actual checks11 run used CA's explicit flash-vocab-q8 source branch.
    # Read its existing path expressions, without running or duplicating it.
    previous_path = CA / 'checks11/summary.json'
    previous = c.read(previous_path)
    assert previous['source'] == 'flash-vocab-q8' and previous['supply_driver'] is None
    assert previous['process']['exit'] == 0 and not previous['process']['timed_out']
    assert previous['tests'] == 1 and not any(previous[key] for key in ('failures', 'errors', 'disabled', 'skips'))
    assert {row['attributes']['classname'] + '.' + row['attributes']['name'] for row in previous['cases']} == {CASES['s02cuda']}
    parsed = ast.parse((CA / 'build.py').read_text(encoding='utf-8-sig'))
    function = next(node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name == 'run')
    def path_expression(value):
        assert isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == 'str'
        assert len(value.args) == 1 and not value.keywords
        path = value.args[0]
        assert isinstance(path, ast.BinOp) and isinstance(path.op, ast.Div)
        assert isinstance(path.left, ast.Name) and path.left.id == 'R' and isinstance(path.right, ast.Constant)
        return R / path.right.value
    roles = {}
    for node in function.body:
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if (isinstance(target, ast.Subscript) and isinstance(target.value, ast.Name) and target.value.id == 'env'
                and isinstance(target.slice, ast.Constant) and isinstance(target.slice.value, str)
                and target.slice.value.startswith('HYLE_DSPARK_')):
            roles[target.slice.value] = path_expression(node.value)
    vocabulary = next(node.value for node in ast.walk(function) if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == 'vocabulary' for target in node.targets))
    assert isinstance(vocabulary, ast.BinOp) and isinstance(vocabulary.op, ast.Div)
    assert isinstance(vocabulary.left, ast.Name) and vocabulary.left.id == 'R' and isinstance(vocabulary.right, ast.Constant)
    roles['HYLE_DSPARK_GGUF_VOCAB_DIR'] = R / vocabulary.right.value
    expected = {'HYLE_DSPARK_GGUF_VOCAB_DIR', 'HYLE_DSPARK_ORIGINAL_TARGET_TAIL_DIR',
        'HYLE_DSPARK_TARGET_ROLES_DIR', 'HYLE_DSPARK_HISTORY_ROLES_DIR', 'HYLE_DSPARK_MARKOV_DIR',
        'HYLE_DSPARK_CONFIDENCE_BF16', 'HYLE_DSPARK_SHARED_VOCAB_DIR', 'HYLE_DSPARK_PARAMETER_ROLES_DIR',
        'HYLE_DSPARK_SHARED_FFN_DIR', 'HYLE_DSPARK_ATTENTION_ROLES_DIR', 'HYLE_DSPARK_EXPERT_ROLES_DIR'}
    assert set(roles) == expected and all(path.exists() for path in roles.values())
    current(previous['artifact_manifest'])
    assert b.identity(roles['HYLE_DSPARK_GGUF_VOCAB_DIR'] / 'manifest.json') == previous['artifact_manifest']
    return roles, dict(previous_run=b.identity(previous_path), environment_config=b.identity(CA / 'build.py'),
                       artifact_manifest=previous['artifact_manifest'], external_supply=False)


def run(link_attempt, attempt, selected, timeout, wait_for_experts=False):
    assert not wait_for_experts or selected != 's02cuda'
    folder = S / f'tests-link{link_attempt}'
    ready = c.read(folder / 'ready.json')
    for row in [ready['image'], ready['source_record'], ready['link_plan'], *ready['artifact_inputs']]:
        current(row)
    plan = c.read(ready['link_plan']['path'])
    proof, _ = retained_proof()
    assert plan['retained_header_equivalence'] == proof
    for item in plan['compiled_records']:
        current(item)
        record = c.read(item['path'])
        for row in [record['source'], record['object'], *record.get('artifact_inputs', [])]:
            current(row)
        for row in record['dependencies']:
            (current if c.key(item['path']) == c.key(ready['source_record']['path']) else retained_current)(row)
    assert artifact_inputs(ready['artifact_inputs'][0]['path']) == ready['artifact_inputs']
    env = os.environ.copy()
    for name in list(env):
        if name.startswith('HYLE_DSPARK_'):
            env.pop(name)
    previous_source = None
    if selected == 's02cuda':
        roles, previous_source = s02_environment()
    else:
        roles = dict(HYLE_DSPARK_BFLOAT_SIDECAR_DIR=S / 'original-static',
            HYLE_DSPARK_BFLOAT_EXPERT_DIR=S / 'original-experts',
            HYLE_DSPARK_GGUF_VOCAB_DIR=R / '.scratch/dspark-gguf-vocabulary-20261023/original-vocabulary',
            HYLE_DSPARK_ORIGINAL_TARGET_TAIL_DIR=R / '.scratch/dspark-original-target-tail-20261023/original-target')
        # Empty selected cache is legal: only actual router frontiers populate it.
        roles['HYLE_DSPARK_BFLOAT_EXPERT_DIR'].mkdir(exist_ok=True)
    for name, directory in roles.items():
        assert directory.exists()
        env[name] = str(directory)
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    temporary = S / 'runtime-tmp'
    temporary.mkdir(exist_ok=True)
    env['TMP'] = env['TEMP'] = str(temporary)
    out = S / f'checks{attempt}'
    frontier, driver, supply = None, None, []
    if selected != 's02cuda':
        frontier = out / 'frontier-request.json'
        # Native consumes authenticated caches only. Optional waiting lets a
        # separate explicit batch supply recorded IDs without restarting it.
        # This native process and runner never start a downloader.
        env['HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS'] = '1' if wait_for_experts else '0'
        env['HYLE_DSPARK_BFLOAT_FRONTIER_FILE'] = str(frontier)
    # Pin the actual indirect metadata/locking helpers too. This is a source
    # list for this one run, not a downloader, compiler or native route registry.
    tools = [b.identity(p) for p in (Path(__file__).resolve(), S / 'generate_artifacts.py',
        S / 'fetch_headers.py', S / 'fetch_experts.py', S / 'run_with_supply.py',
        S / 'payload-proposal/acquire.py', CA / 'fetch_dense.py', CA / 'run_with_supply.py',
        CA / 'build.py', GQ / 'build.py', GQ / 'S01/fetch_headers.py',
        R / '.scratch/qwen-bfloat-selected-20261023/fetch_roles.py',
        R / '.scratch/mtp-artifact-schema-20261023/fetch_headers.py',
        R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')]
    expected = CASES[selected]
    native = [ready['image']['path'], '--gtest_filter=' + expected, '--gtest_output=xml:' + str(out / 'results.xml')]
    command = ([sys.executable, str(driver), '--image', ready['image']['path'], '--frontier-file', str(frontier), '--', *native[1:]]
        if driver else native)
    environment = {name: env[name] for name in ['PATH', 'TMP', 'TEMP', *roles,
        *(['HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS', 'HYLE_DSPARK_BFLOAT_FRONTIER_FILE'] if frontier else [])]}
    (S / 'run-plans').mkdir(exist_ok=True)
    c.save(S / 'run-plans' / (out.name + '.json'), dict(command=command, native_command=native,
        environment=environment, image=ready['image'], source_record=ready['source_record'],
        link_plan=ready['link_plan'], artifact_inputs=ready['artifact_inputs'], supply=supply,
        tool_sources=tools, previous_source=previous_source, expected_case=expected,
        waiting_for_explicit_supply=wait_for_experts, automatic_downloads=False))
    quality = load('s03_actual_process_runner', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    process = quality.execute(command, env, out, timeout=timeout)
    unchanged_tools = all(b.identity(row['path']) == row for row in tools)
    result = dict(process=process, terminal=True, image=ready['image'], selected_cases=[expected],
        source_record=ready['source_record'], link_plan=ready['link_plan'], artifact_inputs=ready['artifact_inputs'],
        environment=environment, supply=supply, tool_sources=tools, tool_sources_unchanged=unchanged_tools,
        automatic_downloads=False, waiting_for_explicit_supply=wait_for_experts,
        previous_source=previous_source,
        frontier_file=str(frontier) if frontier else None, retained_header_equivalence=proof,
        throughput_evidence=False, whole_original_model=False,
        scope=('Affected existing S02 Q8/MXFP4 draft and Q8 vocab, exactly reused checks11 source paths, no new source fetch' if selected == 's02cuda' else
            'Actual S03 BF16/MXFP4 three-stage draft, S02 original Q8 vocab') +
            '; original formal40/41/42 target-tail and one same30-member StateHead/K5; upstream layer39/history fixtures remain external; no complete trained main model, quality or TPS claim')
    xml = out / 'results.xml'
    if xml.is_file():
        tree = ET.parse(xml).getroot()
        result.update(tests=int(tree.attrib['tests']), failures=int(tree.attrib['failures']),
            errors=int(tree.attrib['errors']), disabled=int(tree.attrib['disabled']),
            skips=sum(case.find('skipped') is not None for case in tree.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']:p.attrib['value']
                for p in case.iter('property')}) for case in tree.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert unchanged_tools, 'S03 tool source changed during the actual native/supply run'
    assert process['exit'] == 0 and not process['timed_out'], process
    assert result.get('tests') == 1 and not any(result[key] for key in ('failures', 'errors', 'disabled', 'skips')), result
    assert {row['attributes']['classname'] + '.' + row['attributes']['name'] for row in result['cases']} == {expected}
    print('PASS', expected, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('compile', 'link', 'run'))
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--artifacts-header', type=Path, default=S / 'generated/dspark_bfloat_sidecar_artifacts.h')
    parser.add_argument('--case', choices=tuple(CASES), default='cpu')
    parser.add_argument('--timeout', type=int, default=3600)
    parser.add_argument('--wait-for-experts', action='store_true',
        help='Wait for separately acquired original S03 expert caches; never downloads')
    args = parser.parse_args()
    assert min(args.attempt, args.compile_attempt, args.link_attempt, args.timeout) > 0
    if args.wait_for_experts and (args.action != 'run' or args.case == 's02cuda'):
        parser.error('--wait-for-experts applies only to S03 CPU/CUDA run')
    if args.action == 'compile':
        host(args.attempt, args.artifacts_header)
    elif args.action == 'link':
        link(args.attempt, args.compile_attempt)
    else:
        run(args.link_attempt, args.attempt, args.case, args.timeout, args.wait_for_experts)
