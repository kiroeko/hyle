#include <array>
#include <cstdio>
#include <exception>
#include <stdexcept>
#include <string>
#include <utility>

#include "hyle/graph/graph.h"

namespace c=hyle::compute;
namespace g=hyle::graph;

template<class T> T checked(hyle::Result<T> result,const std::string &step) {
  if(!result) {
    std::fprintf(stderr,"FAIL %s: %.*s\n",step.c_str(),
        int(result.error().message().size()),result.error().message().data());
    std::fflush(stderr);
    throw std::runtime_error(step);
  }
  std::printf("PASS %s\n",step.c_str());std::fflush(stdout);
  return std::move(*result);
}
void checked(hyle::Status result,const std::string &step) {
  if(!result.ok()) {
    std::fprintf(stderr,"FAIL %s: %.*s\n",step.c_str(),
        int(result.message().size()),result.message().data());
    std::fflush(stderr);
    throw std::runtime_error(step);
  }
  std::printf("PASS %s\n",step.c_str());std::fflush(stdout);
}

int main() {
  try {
    auto builder=checked(g::GraphBuilder::create(),"GraphBuilder::create");
    const auto original=checked(c::TensorDesc::dense(c::DataType::kBFloat16,
        std::array<std::int64_t,2>{8192,4096}),"original BF16[8192,4096] description");
    std::array<g::ValueId,3> weights,outputs;
    // Same make_graph order: three empty-payload immutable parameter ports,
    // then reshape/permute/Copy nodes. No weight file or backend is touched.
    for(std::size_t stage=0;stage<weights.size();++stage)
      weights[stage]=checked(builder.constant(original),"constant stage"+std::to_string(stage));
    const auto shape=checked(c::TensorShape::create(std::array<std::int64_t,3>{8,1024,4096}),
        "TensorShape[8,1024,4096]");
    const auto reshape=checked(c::View::reshape(shape),"View::reshape descriptor");
    const auto permute=checked(c::View::permute(std::array<std::int32_t,3>{0,2,1}),
        "View::permute[0,2,1] descriptor");
    for(std::size_t stage=0;stage<weights.size();++stage) {
      const auto prefix="stage"+std::to_string(stage)+" ";
      const auto reshape_node=checked(builder.add_node(c::Operation(reshape),
          std::array{weights[stage]}),prefix+"node reshape");
      const auto grouped=checked(builder.result(reshape_node),prefix+"result reshape");
      const auto permute_node=checked(builder.add_node(c::Operation(permute),
          std::array{grouped}),prefix+"node permute");
      const auto rhs=checked(builder.result(permute_node),prefix+"result permute");
      const auto copy_node=checked(builder.add_node(c::Operation(c::Copy{}),
          std::array{rhs}),prefix+"node Copy");
      outputs[stage]=checked(builder.result(copy_node),prefix+"result Copy");
    }
    for(std::size_t stage=0;stage<outputs.size();++stage)
      checked(builder.publish(outputs[stage]),"publish stage"+std::to_string(stage));
    const auto graph=checked(std::move(builder).finish(),"GraphBuilder::finish");
    std::printf("COLD OA GRAPH COMPLETE: inputs=%zu constants=%zu nodes=%zu outputs=%zu; no execute/weights\n",
        graph.input_count(),graph.constant_count(),graph.node_count(),graph.output_count());
    return graph.input_count()==0&&graph.constant_count()==3&&graph.node_count()==9&&graph.output_count()==3?0:2;
  } catch(const std::exception &error) {
    std::fprintf(stderr,"PROBE STOP: %s\n",error.what());return 1;
  }
}
