"""Root-only one-host-TU cold-Graph diagnostic; this script is not inference.

python build.py --attempt1 compiles/links against the exact S03 cached closure.
Root separately runs the printed image. No SDK/NVCC/native worker build.
"""
import argparse
import importlib.util
import os
from pathlib import Path
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
STAGE=S.parent
R=STAGE.parents[2]


def load(name,path):
  spec=importlib.util.spec_from_file_location(name,path)
  module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def main():
  parser=argparse.ArgumentParser(description=__doc__)
  parser.add_argument('--attempt',type=int,required=True)
  args=parser.parse_args();assert args.attempt>0
  original=load('s03_exact_probe_recipe',STAGE/'build.py');b,c=original.b,original.c
  record_path=STAGE/'compile1/dspark-state/identity.json'
  recipe=c.read(record_path)
  assert c.read(record_path.with_name('compile.result.json'))['exit']==0
  out=S/f'attempt{args.attempt}';out.mkdir(exist_ok=False);(out/'tmp').mkdir()
  source=S/'probe.cc';tag='cold-oa-probe'
  command=b.host_command(recipe['command'],source,tag,out)
  assert all(flag in command for flag in ('/W4','/WX','/O2','/MD'))
  c.save(out/'plan.json',dict(source=b.identity(source),recipe=b.identity(record_path),
      command=command,weight_files_read=0,backend_executions=0,network_requests=0,
      SDK_builds=0,NVCC_builds=0,native_CPU_builds=0))
  env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
  deps=c.read(out/(tag+'-deps.json'))['Data']
  paths=list(dict.fromkeys([deps['Source'],*deps['Includes']]))
  compiled=dict(source=b.identity(source),object=b.identity(out/(tag+'.obj')),
      command=command,recipe=b.identity(record_path),dependencies=[b.identity(path) for path in paths])
  c.save(out/'identity.json',compiled)
  base=STAGE/'tests-link1';link=c.read(base/'link-plan.json')
  assert c.read(base/'link.result.json')['exit']==0
  old=recipe['object']
  assert sum(c.key(item['path'])==c.key(old['path']) for item in link['inputs'])==1
  assert sum(c.key(item)==c.key(old['path']) for item in link['command'])==1
  inputs=[compiled['object'] if c.key(item['path'])==c.key(old['path']) else item for item in link['inputs']]
  for item in inputs:original.current(item)
  command=[compiled['object']['path'] if c.key(item)==c.key(old['path']) else item
      for item in link['command'] if not item.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
  image=out/'cold-oa-probe.exe'
  command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
  c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base/'link-plan.json'),
      source_record=b.identity(out/'identity.json'),replaced_object=old,
      retained_compiled_records=[row for row in link['compiled_records'] if c.key(row['path'])!=c.key(record_path)],
      SDK_builds=0,NVCC_builds=0,native_CPU_builds=0))
  env,_=b.environment(command,[item['path'] for item in inputs],out);c.execute('link',command,env,out)
  runtime=c.read(base/'runtime-environment.json')
  for item in runtime['staged_dlls']:
    original.current(item);os.link(item['path'],out/Path(item['path']).name)
  runtime['PATH']=str(out)+';'+runtime['PATH']
  c.save(out/'runtime-environment.json',runtime)
  c.save(out/'ready.json',dict(image=b.identity(image),source_record=b.identity(out/'identity.json'),
      runtime=b.identity(out/'runtime-environment.json'),scope='Cold Graph construction only; no backend execute or weight I/O.'))
  print(str(image),flush=True)


if __name__=='__main__':main()
