"""S03: one exact authenticated GGUF metadata request, never tensor payload.

--plan-only checks existing metadata offline. Without it, root fetches only
bytes0..5253151, then emits static72 and selected-expert source range plans.
"""
import argparse
import gzip
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import struct
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
REPO = 'unsloth/DeepSeek-V4-Flash-0731-GGUF'
REV = 'fbbb5b93fb787c21338159b0af3318bb3f4d9768'
FILE = 'dspark/dspark-DeepSeek-V4-Flash-0731-BF16.gguf'
URL = f'https://huggingface.co/{REPO}/resolve/{REV}/{FILE}'
HEADER = 5253152
STATIC_BYTES, EXPERT_BYTES, EXPERT_STRIDE = 1041922972, 10267656192, 4456448
PROPOSAL = R / '.scratch/dspark-pro-target-draft-20261023/review/s03-bf16-sidecar-ranges.json'
PROPOSAL_SHA = '678227f126fae83c6424ae8aab5d491c6bd510d2cbb559cb38860313af87c711'
CACHE_KEY = '37db6ffce0c993c18defc9a62810e4b50c8524bb752b2b27a7e40abb134e88dd'
TABLE_SHA = 'c93fa628f656654ba421e1d7d161c3edb754646e9da634b3f0cad592bb0d91ed'
VOCAB = R / '.scratch/dspark-gguf-vocabulary-20261023/original-vocabulary/manifest.json'
VOCAB_SHA = '7502444e1150da9b5e15e79ec68be087b81c6ad02146d74b9b03a08e465db1e0'
PARSER = R / '.scratch/qwen-gguf-selected-20261023/S01/fetch_headers.py'
HTTP = R / '.scratch/mtp-artifact-schema-20261023/fetch_headers.py'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))


def save(path, value):
    temporary = path.with_name(path.name + '.next')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def cached_plan():
    assert identity(PROPOSAL)['sha256'] == PROPOSAL_SHA
    proposal = read(PROPOSAL)
    cache = R / proposal['cached_header']['path']
    assert identity(cache) == proposal['cached_header']
    cached = json.loads(gzip.decompress(cache.read_bytes()))[CACHE_KEY]
    assert (cached['repository'], cached['revision'], cached['file'], cached['url']) == (REPO, REV, FILE, URL)
    assert cached['tensor_count'] == len(cached['tensors']) == len(proposal['roles']) == 81
    assert sha(json.dumps(cached['tensors'], ensure_ascii=False, separators=(',', ':')).encode()) == TABLE_SHA
    assert cached['tensor_table_sha256'] == proposal['tensor_table_sha256'] == TABLE_SHA
    assert int(cached['tensor_data_offset']) == proposal['tensor_data_base'] == HEADER
    expected = []
    for tensor, row in zip(cached['tensors'], proposal['roles'], strict=True):
        shape = list(map(int, tensor['shape']))
        code = tensor['dtype_code']
        block, stored = {0:(1,4),30:(1,2),39:(32,17)}[code]
        size = math.prod(shape) // block * stored
        offset = int(tensor['offset'])
        assert shape[0] % block == 0
        assert (row['name'], row['dtype'], row['dtype_code'], row['gguf_dimensions'], row['bytes']) == (
            tensor['name'], tensor['dtype'], code, shape, size)
        assert row['data_relative_offset'] == offset
        assert row['absolute_inclusive'] == [HEADER + offset, HEADER + offset + size - 1]
        assert row['acquire_full_role'] == (code != 39)
        expected.append(dict(name=tensor['name'], shape=shape, dtype_code=code, offset=offset))
    static = [r for r in proposal['roles'] if r['acquire_full_role']]
    experts = [r for r in proposal['roles'] if not r['acquire_full_role']]
    assert len(static) == 72 and sum(r['bytes'] for r in static) == STATIC_BYTES
    assert len(experts) == 9 and sum(r['bytes'] for r in experts) == EXPERT_BYTES
    assert all(r['gguf_dimensions'][2] == 256 and r['bytes'] == 256 * EXPERT_STRIDE for r in experts)
    assert identity(VOCAB)['sha256'] == VOCAB_SHA
    vocabulary = read(VOCAB)
    assert vocabulary['complete'] and vocabulary['original_roles'] == 2 and vocabulary['source_bytes'] == 1125253120
    return proposal, cached, expected


def emit_plans(proposal, receipt):
    # This is a metadata projection from the authenticated GGUF table, not a
    # safetensors header. The unchanged downloader validates names/ranges here.
    table = {r['name']: dict(dtype=r['dtype'], shape=r['gguf_dimensions'],
             data_offsets=[r['data_relative_offset'], r['data_relative_offset'] + r['bytes']]) for r in proposal['roles']}
    save(S / 'header-table.json', table)
    shard = dict(file=FILE, url=URL, whole_file_bytes=receipt['whole_file_bytes'],
                 etag=receipt['etag'], data_base=HEADER, header=identity(S / 'header-table.json'),
                 raw_gguf_header=receipt['header'], source_format='GGUF')
    static, groups, offset = [], [], 0
    for original in proposal['roles']:
        if not original['acquire_full_role']:
            continue
        first, last = original['absolute_inclusive']
        index = len(static)
        static.append(dict(index=index, name=original['name'], dtype=original['dtype'],
            dtype_code=original['dtype_code'], shape=original['gguf_dimensions'], bytes=original['bytes'],
            source_shard=0, data_relative_half_open=[first-HEADER,last+1-HEADER],
            absolute_inclusive=[first,last], bundle_offset=offset))
        groups.append(dict(index=index, source_shard=0, first=first, last=last,
                           bundle_offset=offset, bytes=original['bytes']))
        offset += original['bytes']
    assert len(static) == 72 and offset == STATIC_BYTES
    common = dict(repository=REPO, revision=REV, file=FILE, source_format='GGUF',
        source_header=identity(S / 'header.json'), source_proposal=identity(PROPOSAL),
        shape_convention='Original GGUF dimension order; no dtype/stride conversion.',
        reused_vocabulary=identity(VOCAB), new_vocabulary_bytes=0,
        whole_shards_downloaded=False, unrequested_bytes=0)
    save(S / 'static-plan.json', dict(common, original_roles=72, bundle_bytes=STATIC_BYTES,
        typed_order='Non-MXFP4 roles in the complete original GGUF tensor-table order.',
        typed_catalog_magic='HYDSPT01', typed_catalog_bytes=1216,
        shards=[shard], roles=static, groups=groups))
    save(S / 'expert-source-plan.json', dict(common, original_roles=9,
        expert_domain=256, per_expert_per_leg_bytes=EXPERT_STRIDE,
        per_selected_expert_bytes=3*EXPERT_STRIDE, source_banks_bytes=EXPERT_BYTES,
        acquire_full_bank=False, typed_order='Single stage/global ID: gate,up,down original inline MXFP4.',
        shards=[shard], roles=[r for r in proposal['roles'] if not r['acquire_full_role']]))
    save(S / 'summary.json', dict(complete=True, repository=REPO, revision=REV, file=FILE,
        header=identity(S / 'header.json'), static_plan=identity(S / 'static-plan.json'),
        expert_source_plan=identity(S / 'expert-source-plan.json'), original_roles=81,
        static_roles=72, static_bytes=STATIC_BYTES, expert_source_roles=9,
        expert_bank_payload_bytes=0, tensor_payload_bytes=0, metadata_network_budget=HEADER,
        reused_vocabulary=identity(VOCAB), new_vocabulary_bytes=0,
        artifact_executed=False, native_builds=0))


def validate_raw(raw,cached,expected):
    # The old stock-parser census placed these GGUF preamble fields beside
    # actual KV entries. Check their real binary source rather than discarding
    # them or asking the KV parser to manufacture three non-KV keys.
    assert raw[:4] == b'GGUF'
    version,tensor_count,kv_count = struct.unpack_from('<IQQ',raw,4)
    assert cached['metadata']['version'] == version == 3
    assert cached['metadata']['tensor_count'] == str(tensor_count) == '81'
    assert cached['metadata']['kv_count'] == str(kv_count) == '59'
    structural = {'version','tensor_count','kv_count'}
    actual_kv = {key:value for key,value in cached['metadata'].items() if key not in structural}
    gguf = module('s03_parameterized_gguf_parser',PARSER)
    metadata,actual,metadata_count = gguf.parse_header(raw,81,HEADER,actual_kv)
    assert metadata_count == kv_count
    assert actual == expected and all(metadata[key] == value for key,value in actual_kv.items())
    return dict(version=version,tensor_count=tensor_count,kv_count=kv_count,
                checked_structural_keys=sorted(structural),checked_cached_kv_keys=sorted(actual_kv))


def next_attempt():
    attempt = 1
    while (S/f'http-requests-attempt{attempt}.json').exists():
        attempt += 1
    return attempt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    proposal, cached, expected = cached_plan()
    if args.plan_only:
        print(json.dumps(dict(offline=True, network_bytes=0, http_identity_authenticated=False,
            planned_header_range=[0,HEADER-1], static_roles=72, static_bytes=STATIC_BYTES,
            selected_expert_bytes=3*EXPERT_STRIDE, new_vocabulary_bytes=0,
            cached_plan=identity(PROPOSAL))))
        return
    S.mkdir(parents=True, exist_ok=True)
    path, receipt_path = S / 'original-header.bin', S / 'header.json'
    if receipt_path.exists():
        receipt = read(receipt_path)
        assert (receipt['repository'],receipt['revision'],receipt['file'],receipt['url']) == (REPO,REV,FILE,URL)
        assert receipt['http_status'] == 206 and receipt['range'] == [0,HEADER-1]
        assert identity(path) == receipt['header']
        assert receipt['etag'].startswith('"') and receipt['etag'].endswith('"')
        raw = path.read_bytes()
    else:
        assert not path.exists(), 'Unreceipted header requires explicit root review'
        helper = module('s03_bounded_metadata_http', HTTP)
        helper.MAX_TOTAL = HEADER
        attempt = next_attempt()
        http_path = S/f'http-requests-attempt{attempt}.json'
        previous = read(S/'http-requests.json') if (S/'http-requests.json').exists() else []
        expected_whole,expected_etag,expected_sha = None,None,None
        if previous:
            assert len(previous) == 1 and previous[0]['url'] == URL and previous[0]['complete']
            prior = previous[0]
            assert prior['status'] == 206 and prior['absolute_inclusive'] == [0,HEADER-1]
            prior_headers = {key.lower():value for key,value in prior['headers'].items()}
            expected_whole = int(prior_headers['content-range'].rsplit('/',1)[1])
            expected_etag,expected_sha = prior_headers['etag'],prior['sha256']
        try:
            raw, whole, etag = helper.exact(URL,0,HEADER-1,total=expected_whole,etag=expected_etag)
        finally:
            save(http_path,helper.requests)
            if not (S/'http-requests.json').exists():
                save(S/'http-requests.json',helper.requests)
        if expected_sha is not None:
            assert sha(raw) == expected_sha, 'Fresh metadata bytes differ from the retained first HTTP observation'
        # Commit the exact acquired bytes before attempting schema validation.
        # A parser/schema failure must not force another metadata download.
        with path.open('xb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        receipt = dict(repository=REPO,revision=REV,file=FILE,url=URL,http_status=206,
                       range=[0,HEADER-1],whole_file_bytes=whole,etag=etag,
                       tensor_payload_bytes=0,http_helper=identity(HTTP),parser=identity(PARSER),
                       http_receipt=identity(http_path),header=identity(path),acquired=True,
                       complete=False,schema_validated=False,phase='acquired_pending_schema_validation')
        save(receipt_path,receipt)
    try:
        assert receipt['whole_file_bytes'] >= proposal['minimum_whole_file_bytes']
        checked = validate_raw(raw,cached,expected)
    except Exception as error:
        receipt.update(complete=False,schema_validated=False,phase='acquired_schema_validation_failed')
        failures = receipt.setdefault('validation_errors',[])
        failures.append(dict(type=type(error).__name__,error=str(error),header=identity(path)))
        save(receipt_path,receipt)
        failure_path = S/f'header-schema-failure{len(failures)}.json'
        assert not failure_path.exists()
        save(failure_path,dict(complete=False,header=identity(path),http_receipt=receipt.get('http_receipt'),
                               failure=failures[-1]))
        raise
    receipt.update(complete=True,acquired=True,schema_validated=True,phase='schema_validated',
                   tensor_count=81,metadata_count=checked['kv_count'],structural_and_kv_validation=checked,
                   data_base=HEADER,all_cached_tensors_match=True,tensor_table_sha256=TABLE_SHA)
    save(receipt_path,receipt)
    emit_plans(proposal,receipt)
    print(json.dumps(read(S / 'summary.json')))


if __name__ == '__main__':
    main()
