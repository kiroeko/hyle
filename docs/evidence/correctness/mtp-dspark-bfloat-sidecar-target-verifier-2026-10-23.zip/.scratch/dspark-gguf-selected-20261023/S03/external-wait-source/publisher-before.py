"""Root-only S03 publication after CPU/CUDA and affected S02 CUDA pass.

python publish.py --link N --runs CPU_RUN CUDA_RUN S02_RUN
Read actual XML/metadata; no model, build, download or weight-body hash pass.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import struct
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
CA = R / '.scratch/dspark-pro-target-draft-20261023'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


shared = load('s03_shared_metadata_publisher', CA / 'publish.py')
build = load('s03_actual_incremental_build', S / 'build.py')
shared.TEXT.update({'.patch', '.cuh', '.cu'})
read, identity, verify, add = shared.read, shared.identity, shared.verify, shared.add
resolve, number = shared.resolve, shared.number
REPO = 'unsloth/DeepSeek-V4-Flash-0731-GGUF'
REV = 'fbbb5b93fb787c21338159b0af3318bb3f4d9768'
FILE = 'dspark/dspark-DeepSeek-V4-Flash-0731-BF16.gguf'
EXPECTED = set(build.CASES.values())


def retain(folder):
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix.lower() in shared.TEXT:
            add(path)


def compile_history():
    """Keep recorded identities and available snapshots, never relabel old runs."""
    rows = []
    for path in sorted(S.glob('compile*/dspark-state/identity.json')):
        record = read(add(path))
        result = read(add(path.with_name('compile.result.json')))
        snapshot = path.parent / 'source' / 'tests/compute_models/dspark_original_state_consumer_test.cc'
        assert snapshot.is_file() and identity(snapshot)['sha256'] == record['source']['sha256']
        add(snapshot)
        script = resolve(record['script']['path'])
        script_matches = script.is_file() and identity(script)['sha256'] == record['script']['sha256']
        if script_matches:
            add(script)
        rows.append(dict(record=identity(path), process=result, source=record['source'],
            source_snapshot=identity(snapshot), recorded_compile_script=record['script'],
            compile_script_available_at_original_path=script_matches,
            dependencies_are_recorded_original_identities=True))
    return rows


def catalogue(directory, count, size):
    """Authenticate small catalogues/certificates; stat the actual body only."""
    acquisition = read(add(directory / 'acquisition.json'))
    assert acquisition['complete'] is True
    assert (acquisition['repository'], acquisition['revision'], acquisition['original_roles']) == (REPO, REV, count)
    assert acquisition['bundle_bytes'] == acquisition['role_payload_bytes'] == size
    assert acquisition['unrequested_bytes'] == 0 and acquisition['whole_shards_downloaded'] is False
    bundle = resolve(acquisition['bundle']['path'])
    assert bundle == (directory / 'roles.bin').resolve() and bundle.stat().st_size == size
    assert acquisition['bundle']['bytes'] == size and re.fullmatch('[0-9a-f]{64}', acquisition['bundle']['sha256'])
    typed_path = add(verify(acquisition['typed_catalog']))
    raw = typed_path.read_bytes()
    assert len(raw) == 64 + 16 * count
    magic, version, entries, body_bytes, reserved, digest = struct.unpack('<8sIIQQ32s', raw[:64])
    assert (magic, version, entries, body_bytes, reserved) == (b'HYDSPT01', 1, count, size, 0)
    assert digest.hex() == acquisition['bundle']['sha256']
    catalog = read(add(verify(acquisition['catalog'])))
    assert len(catalog['roles']) == count
    assert catalog['bundle'] == dict(file='roles.bin', bytes=size, sha256=acquisition['bundle']['sha256'])
    cursor = 0
    for index, role in enumerate(catalog['roles']):
        assert role['bundle_offset'] == cursor and re.fullmatch('[0-9a-f]{64}', role['sha256'])
        assert struct.unpack_from('<QQ', raw, 64 + 16 * index) == (cursor, role['bytes'])
        cursor += role['bytes']
    assert cursor == size
    plan_path = add(acquisition['source_plan'])
    assert identity(plan_path)['sha256'] == acquisition['source_plan_sha256']
    return acquisition, catalog, read(plan_path)


def artifacts():
    header_path = S / 'generated/dspark_bfloat_sidecar_artifacts.h'
    for row in build.artifact_inputs(header_path):
        add(verify(row))
    generated = read(header_path.with_suffix('.json'))
    acquisition, catalog, plan = catalogue(S / 'original-static', 72, 1041922972)
    assert (plan['repository'], plan['revision'], plan['file']) == (REPO, REV, FILE)
    assert generated['typed_catalog'] == acquisition['typed_catalog'] and generated['bundle'] == acquisition['bundle']
    assert len(plan['roles']) == 72 and plan['new_vocabulary_bytes'] == 0
    for actual, expected in zip(catalog['roles'], plan['roles'], strict=True):
        assert all(actual.get(key) == value for key, value in expected.items())
    header = read(add(S / 'header.json'))
    assert header['complete'] and header['schema_validated'] and header['http_status'] == 206
    assert header['range'] == [0, 5253151] and header['data_base'] == 5253152 and header['tensor_count'] == 81
    assert header['tensor_payload_bytes'] == 0
    raw_header = verify(header['header'])
    assert raw_header.stat().st_size == 5253152
    shared.files.add(raw_header)  # Explicit original GGUF metadata, never weight payload.
    source_plan_path = add(S / 'expert-source-plan.json')
    source = read(source_plan_path)
    assert source['expert_domain'] == 256 and source['per_selected_expert_bytes'] == 13369344
    assert source['source_banks_bytes'] == 10267656192 and source['acquire_full_bank'] is False
    banks = {row['name']: row for row in source['roles']}
    selected, failed = [], []
    for path in sorted((S / 'original-experts').glob('draft/stage*/expert*/acquisition.json')):
        directory = path.parent
        current = read(add(path))
        if not current.get('complete'):
            failed.append(dict(acquisition=identity(path), complete=False, counted_as_acquired=False))
            retain(directory)
            continue
        ready_path = add(directory / 'ready.json')
        ready = read(ready_path)
        assert ready['complete'] and ready['section'] == 'draft' and len(ready['global_ids']) == 1
        stage, global_id = ready['stage'], ready['global_ids'][0]
        assert type(stage) is int and 0 <= stage < 3 and type(global_id) is int and 0 <= global_id < 256
        assert directory == S / 'original-experts/draft' / f'stage{stage}' / f'expert{global_id:03d}'
        assert (ready['repository'], ready['revision'], ready['file']) == (REPO, REV, FILE)
        assert ready['directory'] == directory.relative_to(R).as_posix()
        assert ready['source_plan'] == identity(source_plan_path)
        actual, cat, per_id = catalogue(directory, 3, 13369344)
        assert ready['typed_catalog'] == actual['typed_catalog'] and ready['catalog_sha256'] == actual['typed_catalog']['sha256']
        assert ready['acquisition'] == identity(path) and ready['plan'] == identity(directory / 'plan.json')
        assert actual['section'] == per_id['section'] == 'draft'
        assert actual['stage'] == per_id['stage'] == stage and actual['global_ids'] == per_id['global_ids'] == [global_id]
        assert per_id['source_plan'] == identity(source_plan_path)
        for index, leg in enumerate(('gate', 'up', 'down')):
            name = f'blk.{stage}.ffn_{leg}_exps.weight'
            bank, row = banks[name], cat['roles'][index]
            first = bank['absolute_inclusive'][0] + global_id * 4456448
            assert (row['name'], row['dtype'], row['dtype_code'], row['bytes']) == (name, 'MXFP4', 39, 4456448)
            assert row['absolute_inclusive'] == [first, first + 4456448 - 1]
            assert row['shape'] == bank['gguf_dimensions'][:2] and row['source_bank'] == bank
        retain(directory)
        selected.append(dict(stage=stage, global_id=global_id, bytes=13369344,
            ready=identity(ready_path), acquisition=identity(path), typed_catalog=actual['typed_catalog'],
            bundle=actual['bundle'], body_rehashed=False, body_archived=False))
    assert selected, 'Passing S03 must retain actual authenticated selected experts'
    vocabulary_path = add(verify(source['reused_vocabulary']))
    vocabulary = read(vocabulary_path)
    assert vocabulary['complete'] and vocabulary['original_roles'] == 2 and vocabulary['source_bytes'] == 1125253120
    for row in vocabulary['roles']:
        assert row['dtype'] == 'Q8_0' and row['shape'] == [4096, 129280]
        assert (vocabulary_path.parent / row['file']).stat().st_size == row['bytes'] == 562626560
    return dict(repository=REPO, revision=REV, file=FILE, original_draft_roles=81,
        static_roles=72, static_payload_bytes=1041922972, static_catalogue=acquisition['typed_catalog'],
        static_acquisition=identity(S / 'original-static/acquisition.json'),
        full_expert_source_roles=9, expert_bank_metadata_bytes=10267656192,
        acquired_expert_sets=selected, acquired_expert_bytes=sum(row['bytes'] for row in selected),
        incomplete_expert_history=failed, original_header=identity(raw_header), header_receipt=identity(S / 'header.json'),
        generated_header=identity(header_path), original_file_etag=header['etag'], whole_file_sha256_established=False,
        reused_vocabulary=identity(vocabulary_path), new_vocabulary_bytes=0, body_rehashed=False, body_archived=False)


def completed_run(number_, ready, source_record):
    out = S / f'checks{number_}'
    summary = read(add(out / 'summary.json'))
    process = read(add(out / 'process.json'))
    assert process == summary['process'] and process['exit'] == 0 and not process['timed_out']
    assert summary['terminal'] and summary['tool_sources_unchanged']
    # The S02 regression may precede a later S03-only observer repair. Keep
    # its actual image/compile/link identity rather than relabeling that pass.
    actual_plan_path = add(verify(summary['link_plan']))
    assert actual_plan_path.parent.parent == S and re.fullmatch(r'tests-link[1-9][0-9]*', actual_plan_path.parent.name)
    actual_ready_path = add(actual_plan_path.with_name('ready.json'))
    actual_ready = read(actual_ready_path)
    assert all(summary[key] == actual_ready[key] for key in ('image', 'source_record', 'link_plan'))
    verify(actual_ready['image'])
    add(verify(actual_ready['source_record']))
    shared.successful(actual_plan_path.with_name('link.result.json'))
    for item in summary['tool_sources']:
        add(verify(item))
    for item in summary['artifact_inputs']:
        add(verify(item))
    xml = ET.parse(add(out / 'results.xml')).getroot()
    assert int(xml.attrib['tests']) == summary['tests'] == 1
    assert all(int(xml.attrib[key]) == summary[key] == 0 for key in ('failures', 'errors', 'disabled'))
    cases = []
    for case in xml.iter('testcase'):
        assert case.find('skipped') is None and not any(case.findall(key) for key in ('failure', 'error'))
        props = {prop.attrib['name']: prop.attrib['value'] for prop in case.iter('property')}
        fullname = case.attrib['classname'] + '.' + case.attrib['name']
        assert fullname in EXPECTED and summary['selected_cases'] == [fullname]
        graphs = number(props, 'actual_submissions')
        assert graphs > 0
        assert number(props, 'target_state_resources') == 21 and number(props, 'complete_state_members') == 30
        assert number(props, 'target_full_vocabulary_values_checked') == 6 * 129280
        assert number(props, 'full_vocabulary_lm_values_checked') == 5 * 129280
        assert number(props, 'state_backing_peak') <= number(props, 'state_backing_budget')
        for key in ('actual_pending_embedding_feedback_checks', 'whole_state_publications', 'continued_prefix_branches',
                    'cancelled_unpublished_drafts', 'rejected_stale_publishes', 'actual_main_history_catchup_submissions'):
            assert number(props, key) > 0
        if fullname != build.CASES['s02cuda']:
            assert all(summary[key] == ready[key] for key in ('image', 'source_record', 'link_plan')), 'New S03 pair must use the selected final link/compile'
            assert number(props, 'draft_static_roles') == 72 and number(props, 'draft_static_source_bytes') == 1041922972
            assert number(props, 'draft_expert_source_roles') == 9 and number(props, 'retained_expert_source_bytes') > 0
            assert 'explicit BF16' in props['draft_activation_policy']
            # Final native checks are cache-only. Separate explicit, budgeted
            # acquisition batches authenticate caches before the native run.
            assert summary['automatic_downloads'] is False and not summary['supply']
            assert summary['frontier_file']
            assert summary['environment']['HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS'] == '0'
            assert summary['process']['command'][0] == ready['image']['path']
        else:
            assert not summary['supply'] and summary['frontier_file'] is None
            assert summary['previous_source']['external_supply'] is False
            add(verify(summary['previous_source']['previous_run']))
            add(verify(summary['previous_source']['environment_config']))
        cases.append(dict(attributes=case.attrib, properties=props, actual_submissions=graphs))
    assert cases == [dict(attributes=row['attributes'], properties=row['properties'],
                         actual_submissions=number(row['properties'], 'actual_submissions')) for row in summary['cases']]
    retain(out)
    return dict(summary=identity(out / 'summary.json'), process=process, image=summary['image'],
        source_record=summary['source_record'], link_plan=summary['link_plan'], cases=cases,
        actual_link_ready=identity(actual_ready_path), final_selected_image=summary['image'] == ready['image'],
        graph_submissions=sum(row['actual_submissions'] for row in cases),
        automatic_downloads=summary.get('automatic_downloads', False),
        supply_policy='cached-only native; any acquisition is an explicit separate process')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--link', type=int, required=True)
    parser.add_argument('--runs', type=int, nargs='+', required=True)
    args = parser.parse_args()
    assert args.link > 0 and len(args.runs) == 3 and len(set(args.runs)) == 3 and min(args.runs) > 0
    protected = shared.protect()
    folder = S / f'tests-link{args.link}'
    ready = read(add(folder / 'ready.json'))
    verify(ready['image'])  # Identity only; never archived.
    link_plan = read(add(verify(ready['link_plan'])))
    shared.successful(folder / 'link.result.json')
    proof, pairs = build.retained_proof()
    assert link_plan['retained_header_equivalence'] == proof and len(link_plan['retained_fixed_graph_objects']) == 2
    add(verify(proof))
    for pair in pairs:
        add(verify(pair['cached_snapshot'])); add(verify(pair['current_header']))
    source_record_path = add(verify(ready['source_record']))
    source_record = read(source_record_path)
    shared.successful(source_record_path.with_name('compile.result.json'))
    assert source_record['source']['path'].replace('\\', '/').endswith('/tests/compute_models/dspark_original_state_consumer_test.cc')
    for item in [source_record['source'], source_record['script'], *source_record['artifact_inputs']]:
        add(verify(item))
    # compile1 used the preserved compile-only script690ed317; later compiles
    # use their own recorded build.py. Do not label them all as one script.
    for item in source_record['dependencies']:
        path = resolve(item['path'])
        if path.is_relative_to(R / 'tests') or path.is_relative_to(R / 'include/hyle'):
            add(verify(item))
    for item in link_plan['compiled_records']:
        record = read(add(verify(item)))
        verify(record['object'])
        add(verify(record['source']))
        for dep in record['dependencies']:
            build.retained_current(dep) if item != ready['source_record'] else build.current(dep)
    artifact = artifacts()
    runs = [completed_run(value, ready, source_record) for value in args.runs]
    names = [row['attributes']['classname'] + '.' + row['attributes']['name'] for run in runs for row in run['cases']]
    assert len(names) == 3 and set(names) == EXPECTED
    histories = []
    for path in sorted(S.glob('checks*/summary.json')):
        if path.parent.name in {f'checks{value}' for value in args.runs}:
            continue
        summary = read(add(path))
        assert 'exit' in summary['process'], 'Cannot publish while a different native attempt is live'
        histories.append(dict(summary=identity(path), process=summary['process'], counted_as_pass=False))
    for path in (S / 'integration/applied.json', S / 'integration/source-before.json', S / 'integration/apply-commands.json'):
        add(path)
    proposal_path = CA / 's03-bfloat-sidecar/proposal.json'
    proposal = read(add(proposal_path))
    add(verify(proposal['patch']))
    for item in proposal['files']:
        if 'before' in item:
            add(verify(item['before']))
        add(verify(item['source']))
    for leaf in ('compile*', 'tests-link*', 'checks*'):
        for path in S.glob(leaf):
            retain(path)
    compilations = compile_history()
    # Include the actual observation-liveness repair, original failure context,
    # and cold-OA diagnostic source/results. These are history, not extra passes.
    retain(S / 'integration')
    retain(S / 'diagnostic-liveness')
    retain(S / 'diagnostic-cold-oa')
    retain(S / 'f32-rms-reference')
    retain(S / 'static-fetch1')
    peer = CA / 'review/s03-fixed-source/dflash.cpp'
    add(peer)  # One pinned model source file, not the third-party repository.
    acquisition_batches = []
    for directory in sorted(S.glob('prefetch-*')):
        retain(directory)
        for path in sorted(directory.rglob('summary.json')):
            batch = read(add(path))
            assert 'exit' in batch['process'], 'Explicit acquisition batch is still live'
            acquisition_batches.append(dict(summary=identity(path), process=batch['process'],
                counted_as_native_pass=False))
    for path in S.glob('*.py'):
        add(path)
    for path in S.glob('*.json'):
        if path.name != 'publication.json':
            add(path)
    retain(S / 'run-plans')
    retain(S / 'payload-proposal')
    assert shared.protect() == protected
    destination = R / 'docs/evidence/correctness/mtp-dspark-bfloat-sidecar-target-verifier-2026-10-23.json'
    archive = destination.with_suffix('.zip')
    assert not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(shared.files):
            assert path.name != 'roles.bin' and path.suffix.lower() not in {'.exe', '.obj', '.dll', '.lib', '.pdb'}
            zipped.write(path, path.relative_to(R).as_posix())
    graphs = {row['attributes']['classname'] + '.' + row['attributes']['name']: row['actual_submissions']
              for run in runs for row in run['cases']}
    record = dict(date='2026-10-23', identity='S03', goal_complete=False,
        conclusion='Original S03 BF16/F32/MXFP4 three-stage draft with matching original Q8 vocabulary and formal Flash target-tail passed Windows CPU/CUDA; affected original S02 CUDA regression passed.',
        artifact=artifact, validation=dict(tests=3, failures=0, errors=0, skips=0,
            graph_submissions=sum(graphs.values()), graph_submissions_by_case=graphs, runs=runs,
            other_and_failed_attempts=histories, compile_history=compilations,
            explicit_acquisition_batches=acquisition_batches),
        implementation=dict(build='One DSpark host test TU replaces the GQ test object. All13 product objects, two Graph retirement fixes and staged native/SDK closure are reused; exact two comment-header equivalence proof only. Actual compile-script and link/run-script identities remain separate.',
            source_record=identity(source_record_path), compile_script=source_record['script'],
            supply='Native checks use existing authenticated per-ID caches only (WAIT=0, no fetch driver). Explicit acquisition attempts and failures are retained separately.',
            f32_norm_reference=dict(peer=identity(peer), anchors=['dflash.cpp:846 F32 input',
                'dflash.cpp:855-856 fc then RMS', 'dflash.cpp:864-865 wkv then RMS'],
                change='Only three S03 F32-accumulator RMS observer calls use the existing independent FP64 F32-input RMS reference. HC BF16 guards, Graph precision and tolerance values are unchanged.'),
            state='Same K5/30-member StateHead, all21 target caches, actual six-row fullV verifier and pending leases, mandatory current plus accepted prefix, actual main-history catchup, continuation/cancel/stale/oldreader/budget checks.',
            numerics='Explicit BF16 projection activations/stores, actual BF16 predecessors, original F32 norms/HC, original inline17B/32 MXFP4 selected experts and original Q8 LM native-activation certificates. No widened tolerances or full-F32 weight shadow.',
            SDK_builds=0, product_host_TUs=0, native_CPU_builds=0, NVCC_builds=0),
        limitations=['Layer39 upstream inputs and finite initial histories remain fixtures; this is not complete43-layer target inference or a full-model quality result.',
            'Actual selected expert cache inventory is separate from nine complete expert-bank metadata capacities; unselected experts are not claimed acquired/executed.',
            'Natural fixture and controlled accepted-prefix scenarios are separate, with no model-quality or natural-acceptance-rate claim.',
            'The affected S02 CUDA regression retains its own actual image/source and check time; it is not relabeled as the final S03 image.',
            'No new TPS/load/physical-memory result; state backing counters are declared-resource accounting. Overall MTP goal completion is not asserted.'],
        protection=protected, archive=identity(archive), archive_items=len(shared.files))
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=identity(destination), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert shared.protect() == protected
    print(json.dumps(dict(**publication, tests=3, graphs=sum(graphs.values()))), flush=True)


if __name__ == '__main__':
    main()
