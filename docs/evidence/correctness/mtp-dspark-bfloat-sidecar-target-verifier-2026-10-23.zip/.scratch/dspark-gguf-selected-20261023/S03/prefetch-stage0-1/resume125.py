"""One observed missing expert leg; reuse both authenticated completed legs."""
import hashlib, importlib.util, json, os, sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[4]
S=R/'.scratch/dspark-gguf-selected-20261023/S03'
B=R/'.scratch/mtp-download-budget-20261023'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
b=load('resume125_budget',B/'budget.py')
c=load('resume125_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
out=S/'prefetch-stage0-1/fetch2';out.mkdir(exist_ok=False)
directory=S/'original-experts/draft/stage0/expert125'
plan=json.loads((directory/'plan.json').read_text('utf-8'))
receipt=json.loads((directory/'acquisition.json').read_text('utf-8'))
assert not receipt['complete'] and receipt['global_ids']==[125] and receipt['stage']==0
assert hashlib.sha256((directory/'plan.json').read_bytes()).hexdigest()==receipt['source_plan_sha256']
assert len(receipt['chunks'])==2
with (directory/'roles.bin').open('rb') as stream:
    for chunk in receipt['chunks']:
        stream.seek(chunk['offset']);data=stream.read(chunk['bytes'])
        assert len(data)==chunk['bytes'] and hashlib.sha256(data).hexdigest()==chunk['sha256']
missing=[g for g in plan['groups'] if not any(x['group']==g['index'] and x['bytes']==g['bytes'] for x in receipt['chunks'])]
assert [(x['first'],x['last'],x['bytes']) for x in missing]==[(562309152,566765599,4456448)]
c.save(out/'plan.json',dict(reason='Native checks3 stage0 actual routing requires expert125; two legs already authenticated.',stage=0,global_ids=[125],new_unique_body_bytes=4456448,reused_verified_body_bytes=sum(x['bytes'] for x in receipt['chunks']),missing_ranges=missing,whole_bank=False))
marker=B/'PAUSED'
with b.locked() as record:
    assert marker.is_file()
    c.save(out/'pause-before.json',json.loads(marker.read_text('utf-8')))
    marker.replace(out/'PAUSED.before')
    before=record['reserved_request_bytes']
try:
    command=[sys.executable,str(B/'budget.py'),'run',str(S/'fetch_experts.py'),'--','--stage','0','--ids','125']
    process=c.execute(command,os.environ.copy(),out/'run',timeout=420)
finally:
    with b.locked() as record:
        c.save(marker,dict(paused_at=b.now(),reason='Explicit expert125 batch ended; only planned necessary ranges may be fetched.',reserved_request_bytes=record['reserved_request_bytes'],requests=len(record['requests'])))
        reserved=record['reserved_request_bytes']-before
c.save(out/'summary.json',dict(process=process,new_unique_body_bytes=4456448,reserved_request_bytes=reserved,whole_bank=False,paused_after=True))
print(json.dumps(dict(exit=process['exit'],new_unique_body_bytes=4456448,reserved_request_bytes=reserved,paused_after=True)),flush=True)
sys.exit(process['exit'])
