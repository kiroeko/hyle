#pragma once

#include <array>
#include <unordered_map>

#include <ggml.h>

#include "hyle/mem/std_allocator.h"

#include "program.h"

namespace hyle::compute::ggml_cuda::internal {

// Build-local forms are keyed by native tensor identity, never payload address.
// The public values retain their original shape and ownership/reader edges.
class TensorBuildFrame final {
 public:
  TensorBuildFrame(const Recipe &, mem::AllocatorRef allocator);
  ggml_tensor *matrix_form(ggml_context *, ggml_tensor *, const TensorDesc &);
  void remember_grouped(std::uint32_t value, ggml_tensor *producer) noexcept {
    grouped_[value] = producer;
  }
  ggml_tensor *grouped(std::uint32_t value) const noexcept {
    return grouped_[value];
  }
  ggml_tensor *private_bfloat_widen_source(
      std::uint32_t value, std::span<ggml_tensor *const> tensors) const noexcept;

 private:
  struct ShapeKey final {
    ggml_tensor *source = nullptr;
    std::array<std::int64_t, 3> shape{};
    std::uint8_t rank = 0;
    bool operator==(const ShapeKey &) const = default;
  };
  struct ShapeHash final {
    std::size_t operator()(const ShapeKey &) const noexcept;
  };
  using ViewEntry = std::pair<const ShapeKey, ggml_tensor *>;
  std::unordered_map<ShapeKey, ggml_tensor *, ShapeHash,
      std::equal_to<ShapeKey>, mem::StdAllocator<ViewEntry>> views_;
  std::vector<ggml_tensor *, mem::StdAllocator<ggml_tensor *>> grouped_;
  struct WidenSource final {
    std::uint32_t source = UINT32_MAX;
    std::uint8_t readers = 0;
    bool published = false;
  };
  std::vector<WidenSource, mem::StdAllocator<WidenSource>> widen_sources_;
};

struct ScalarConstant final {
  ggml_tensor *tensor;
  float value;
};
struct DenseConstant final {
  ggml_tensor *tensor;
  const void *data;
  std::size_t bytes;
};

struct HadamardFactors final {
  std::int64_t low, high;
  constexpr std::size_t constant_elements() const noexcept {
    return static_cast<std::size_t>(
        low * low + (high != 1 && high != low ? high * high : 0));
  }
};
constexpr HadamardFactors hadamard_factors(std::int64_t width) noexcept {
  return width > 512 ? HadamardFactors{64, width / 64}
                     : HadamardFactors{width, 1};
}

// Two cold facts from the fixed native MMVQ selector. The public small-batch
// range remains M<=4; only Orin's five K-quants stop at M1. Neither fact
// authorizes MMQ/cuBLAS fallback or changes weight/input representation.
struct PackedMmvqRows final {
  std::int64_t other = 1;
  std::int64_t k_quant = 1;
  constexpr std::int64_t for_type(ggml_type type) const noexcept {
    switch (type) {
    case GGML_TYPE_Q2_K:
    case GGML_TYPE_Q3_K:
    case GGML_TYPE_Q4_K:
    case GGML_TYPE_Q5_K:
    case GGML_TYPE_Q6_K:
      return k_quant;
    default:
      return other;
    }
  }
};
constexpr PackedMmvqRows packed_mmvq_rows_for_device(int major, int minor) noexcept {
  if (major <= 0 || minor < 0)
    return {};
  return {4, major == 8 && minor == 7 ? 1 : 4};
}

bool tensor_operation_supports(Operation, std::span<const TensorDesc>,
                               std::span<const TensorDesc>,
                               PackedMmvqRows packed_mmvq_rows = {}) noexcept;
ggml_tensor *create_tensor_input(ggml_context *, const TensorDesc &);
std::vector<ggml_tensor *> lower_tensor_operation(
    ggml_context *, const Recipe &, const Node &, std::span<ggml_tensor *const>,
    TensorBuildFrame &,
    std::vector<ScalarConstant> &, std::vector<DenseConstant> &,
    std::span<const float> hadamard,
    std::span<const std::int32_t> snapshot_order);

} // namespace hyle::compute::ggml_cuda::internal
