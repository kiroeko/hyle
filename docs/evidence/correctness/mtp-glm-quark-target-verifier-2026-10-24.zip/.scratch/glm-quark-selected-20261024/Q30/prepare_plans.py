"""Offline Q30 original-role plans, derived only from authenticated metadata."""
from pathlib import Path
import hashlib
import json
import math
import re
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[2]
CACHE = R / '.scratch/mtp-artifact-schema-20261023/Q30'
REPO = 'amd/GLM-5.3-Flash-Quark-MXFP4'
REV = 'b5688f25491202978c19c4d036eef579f61bbe07'
PREFIX = 'model.language_model.layers.45.'
SCHEMA_SHA = '0a6660ce3780007b0c561914c7a0ecf453f4a3cfe92883a8c139020cc4c9d8ac'
INDEX_SHA = '1a91c7f25ab61e7a0e537b047075d91537441e43263be01faf47d8b895f302cd'
CONFIG_SHA = '3a2c766e6a5256241b0b6ad82bc07e65bf4881b7211a0484cf18ce7020bfbd8f'
WIDTH = {'BF16': 2, 'F32': 4, 'F8_E4M3': 1}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def checked_metadata():
    assert identity(CACHE / 'physical-schema.json')['sha256'] == SCHEMA_SHA
    assert identity(CACHE / 'model.safetensors.index.json')['sha256'] == INDEX_SHA
    schema, index = read(CACHE / 'physical-schema.json'), read(CACHE / 'model.safetensors.index.json')
    assert (schema['repository'], schema['revision'], schema['roles']) == (REPO, REV, 1760)
    assert schema['complete_physical_MTP_census'] is True
    shards, headers = [], []
    for number in (1, 2):
        folder = CACHE / f'model-{number:05}-of-00062'
        receipt = read(folder / 'receipt.json')
        raw = (R / receipt['header']['path']).read_bytes()
        assert identity(R / receipt['header']['path']) == receipt['header']
        assert (receipt['repository'], receipt['revision']) == (REPO, REV)
        assert receipt['data_base'] == len(raw) + 8
        assert receipt['url'] == f'https://huggingface.co/{REPO}/resolve/{REV}/' + receipt['file']
        assert re.fullmatch(r'"[0-9a-f]{64}"', receipt['etag'])
        shards.append({k: receipt[k] for k in ('file', 'url', 'etag', 'whole_file_bytes', 'data_base', 'header')})
        headers.append(json.loads(raw))
    rows = []
    for original in schema['physical_roles']:
        shard_index = int(original['source_file'][6:11]) - 1
        assert shard_index in (0, 1)
        shard, header = shards[shard_index], headers[shard_index]
        name, dtype, shape = original['name'], original['dtype'], original['shape']
        actual = header[name]
        assert index['weight_map'][name] == shard['file'] == original['source_file']
        assert dtype == actual['dtype'] and shape == actual['shape']
        first, end = actual['data_offsets']
        assert original['data_relative_half_open'] == [first, end]
        assert end - first == original['bytes'] == math.prod(shape) * WIDTH[dtype]
        assert first >= 0 and end + shard['data_base'] <= shard['whole_file_bytes']
        rows.append(dict(original, source_shard=shard_index,
            absolute_inclusive=[shard['data_base'] + first, shard['data_base'] + end - 1]))
    assert len(rows) == 1760 and sum(x['bytes'] for x in rows) == 7493399168
    return schema, index, shards, headers, rows


def filename(row):
    if row['name'] == 'model.language_model.embed_tokens.weight':
        return 'embedding.bf16'
    if row['name'] == 'lm_head.weight':
        return 'head.bf16'
    if row['name'] == PREFIX + 'shared_head.norm.weight':
        return 'norm.bf16'
    suffix = row['name'].removeprefix(PREFIX)
    if suffix.startswith('self_attn.indexer.'):
        suffix = suffix.removeprefix('self_attn.indexer.')
    elif suffix.startswith('self_attn.'):
        suffix = suffix.removeprefix('self_attn.')
        module, leaf = suffix.split('.', 1)
        module = {'q_a_proj': 'q_a', 'q_b_proj': 'q_b', 'kv_a_proj_with_mqa': 'kv_a',
                  'kv_b_proj': 'kv_b', 'o_proj': 'o'}.get(module, module)
        suffix = module + '.' + leaf
    return suffix + {'BF16': '.bf16', 'F32': '.f32', 'F8_E4M3': '.e4m3'}[row['dtype']]


def main():
    schema, index, shards, headers, rows = checked_metadata()
    with zipfile.ZipFile(R / 'docs/evidence/research/quark-mxfp4-contract-2026-10-20.zip') as archive:
        raw = archive.read('artifact/30/fixed-config.json')
    assert sha(raw) == CONFIG_SHA
    config_bytes = len(raw)
    config = json.loads(raw)
    t = config['text_config']
    assert (t['hidden_size'], t['q_lora_rank'], t['kv_lora_rank'], t['n_routed_experts'], t['num_experts_per_tok']) == (4096, 1536, 512, 288, 8)
    assert t['qk_nope_head_dim'] == 256 and t['qk_rope_head_dim'] == 0 and t['v_head_dim'] == 256
    assert (t['index_kpool'], t['index_topk'], t['index_n_heads'], t['index_head_dim']) == (4, 2048, 32, 128)
    static = [dict(x, section='nextn45', filename=filename(x)) for x in rows if '.mlp.experts.' not in x['name']]
    assert len(static) == 32 and sum(x['bytes'] for x in static) == 243872384
    for name in ('model.language_model.embed_tokens.weight', 'lm_head.weight'):
        actual = headers[0][name]
        assert actual['dtype'] == 'BF16' and actual['shape'] == [154880, 4096]
        first, end = actual['data_offsets']
        row = dict(name=name, source_shard=0, source_file=shards[0]['file'], dtype='BF16', shape=actual['shape'],
            data_relative_half_open=[first, end], bytes=end-first,
            absolute_inclusive=[shards[0]['data_base']+first, shards[0]['data_base']+end-1], section='vocabulary')
        assert row['bytes'] == 1268776960 and index['weight_map'][name] == shards[0]['file']
        static.append(dict(row, filename=filename(row)))
    base = dict(repository=REPO, revision=REV, metadata_only=True, tensor_payload_bytes=0,
        complete_absolute_ranges=True, shards=shards,
        source_schema=identity(CACHE / 'physical-schema.json'), source_index=identity(CACHE / 'model.safetensors.index.json'))
    save(S / 'static-plan.json', dict(base, original_roles=34, source_bytes=2781426304,
        roles=static, full_expert_bank_download_allowed=False,
        vocabulary=dict(embedding='model.language_model.embed_tokens.weight', head='lm_head.weight',
            norm=PREFIX+'shared_head.norm.weight', unique_banks=2, vocabulary=154880, hidden=4096)))
    experts = []
    for global_id in range(288):
        selected = [dict(x, section='nextn45', global_id=global_id) for x in rows
            if x['name'].startswith(PREFIX+f'mlp.experts.{global_id}.')]
        assert len(selected) == 6 and sum(x['bytes'] for x in selected) == 25171968
        for x in selected:
            leaf = x['name'].split(f'.experts.{global_id}.', 1)[1]
            leg = leaf.split('_proj.', 1)[0]
            assert leg in ('gate', 'up', 'down')
            x.update(leg=leg, plane='scales' if x['dtype']=='F32' else 'codes',
                filename=leg + ('.weight_scale.f32' if x['dtype']=='F32' else '.weight.e4m3'))
        assert {(x['leg'],x['plane']) for x in selected} == {(leg,plane) for leg in ('gate','up','down') for plane in ('codes','scales')}
        experts.extend(selected)
    save(S / 'expert-source-plan.json', dict(base, original_roles=1728, logical_full_domain=288,
        full_source_bytes=7249526784, bytes_per_actual_id=25171968, roles_per_actual_id=6,
        full_expert_bank_download_allowed=False, maximum_ids_per_frontier=8,
        selection='Only caller-supplied actual global IDs; no discovery/sample/zero-filled bank.', roles=experts))
    missing = []
    for number in (52, 53, 54, 62):
        file = f'model-{number:05}-of-00062.safetensors'
        names = sorted(name for name, source in index['weight_map'].items() if source==file and
            (name.startswith('model.language_model.layers.43.') or name.startswith('model.language_model.layers.44.') or name=='model.language_model.norm.weight'))
        assert names
        missing.append(dict(file=file, url=f'https://huggingface.co/{REPO}/resolve/{REV}/{file}',
            initial_range_inclusive=[0,7], subsequent_header_range='[8,7+LE64(length)] only after first206',
            maximum_header_bytes=1048576, expected_roles=names, header=None, etag=None, whole_file_bytes=None))
    save(S / 'target-metadata-plan.json', dict(repository=REPO, revision=REV, metadata_only=True,
        complete_absolute_ranges=False, tensor_payload_bytes=0, requests=missing,
        maximum_requested_bytes=4*(8+1048576),
        target43_roles=sum(name.startswith('model.language_model.layers.43.') for name in index['weight_map']),
        target44_roles=sum(name.startswith('model.language_model.layers.44.') for name in index['weight_map']),
        global_norm='model.language_model.norm.weight',
        paired_vocabulary=identity(S / 'static-plan.json'),
        prohibition='No target body Range/pin until actual headers. Do not substitute official eb9 target43/44, globalnorm, or weights.'))
    # The original official1760 and Q30 have identical names/types/shapes after
    # one precise exporter spelling change. No byte-equivalence is inferred.
    coverage = read(R / '.scratch/glm-original-moe-20261023/review/role-coverage.json')
    official = {}
    for info in coverage['source_headers']:
        raw = (R / info['path']).read_bytes()
        assert sha(raw) == info['sha256']
        official.update({n:v for n,v in json.loads(raw).items() if n.startswith(PREFIX)})
    normalized = {x['name'].replace('.weight_scale', '.weight_scale_inv'): x for x in rows}
    assert len(normalized)==len(official)==1760 and normalized.keys()==official.keys()
    assert all(x['dtype']==official[n]['dtype'] and x['shape']==official[n]['shape'] for n,x in normalized.items())
    save(S / 'metadata-proof.json', dict(repository=REPO, revision=REV, original_nextn_roles=1760,
        original_nextn_bytes=7493399168, original_dtype_counts=schema['dtypes'],
        original_full_nextn_plus_vocabulary_roles=1762, original_full_nextn_plus_vocabulary_bytes=10030953088,
        fixed_config=dict(archive='docs/evidence/research/quark-mxfp4-contract-2026-10-20.zip',
            entry='artifact/30/fixed-config.json', bytes=config_bytes, sha256=CONFIG_SHA),
        official_name_dtype_shape_equivalent_after_exact_scale_suffix_change=True,
        official_payload_equivalence_claimed=False, planned_static=identity(S/'static-plan.json'),
        planned_selected_experts=identity(S/'expert-source-plan.json'), planned_target_metadata=identity(S/'target-metadata-plan.json'),
        payload_acquired=False, native_executed=False))
    print(json.dumps(dict(static_roles=34,static_bytes=2781426304,per_actual_expert_bytes=25171968,
        target_metadata_requests=4,http_requests=0)))


if __name__ == '__main__':
    main()
