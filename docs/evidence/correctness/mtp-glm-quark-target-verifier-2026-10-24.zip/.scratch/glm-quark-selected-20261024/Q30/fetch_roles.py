"""Root-only necessary Q30 ranges. No implicit experts, target or whole shard.

--static selects32 immutable NextN roles plus the two actual vocabulary banks.
--expert-ids selects1..8 supplied global IDs, six original roles per ID. Each
ID has an immutable cache directory. HTTP/resume code is the existing pinned
QB transport:8MiB new requests,128MiB authenticated legacy chunks,1MiB IO.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
REPO = 'amd/GLM-5.3-Flash-Quark-MXFP4'
REV = 'b5688f25491202978c19c4d036eef579f61bbe07'
PLAN_PINS = {'static-plan.json': 'c8e7b648a97c7aa7d396a37234f29d35d827f6ab0308dc23560835c2b920a31a',
             'expert-source-plan.json': '6896583d1e52a281513e80d29185a68742d5bf5238862b4827dace4a0e72579c'}
TRANSPORT = R / '.scratch/qwen-bfloat-selected-20261023/derived/Q01/fetch_roles.py'
TRANSPORT_SHA = 'b583d84e47d6d252b170194fa00720f1f091545c377666f87485d43978f1f577'
RETRY = R / '.scratch/qwen-bfloat-selected-20261023/B05/fetch_experts.py'
RETRY_SHA = '072ef65cd3afd0e4130616af134dfd7c5bfe252c4fd0a0c5dc5f9c06717b81ab'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()  # Small metadata/script, never a body.
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked_plan(filename):
    path = S / filename
    assert identity(path)['sha256'] == PLAN_PINS[filename]
    plan = read(path)
    assert (plan['repository'], plan['revision']) == (REPO, REV)
    assert plan['metadata_only'] and plan['tensor_payload_bytes'] == 0 and plan['complete_absolute_ranges']
    assert plan['full_expert_bank_download_allowed'] is False
    assert len(plan['roles'])==len({row['name'] for row in plan['roles']})==plan['original_roles']
    if filename=='static-plan.json':
        assert len(plan['roles'])==len({row['filename'] for row in plan['roles']})==34
        assert sum(row['bytes'] for row in plan['roles'])==plan['source_bytes']==2781426304
    else:
        assert plan['logical_full_domain']==288 and plan['maximum_ids_per_frontier']==8
        assert sum(row['bytes'] for row in plan['roles'])==plan['full_source_bytes']==7249526784
    headers = []
    for shard in plan['shards']:
        assert identity(R / shard['header']['path']) == shard['header']
        raw = (R / shard['header']['path']).read_bytes()
        assert shard['data_base'] == len(raw)+8
        assert shard['url'] == f'https://huggingface.co/{REPO}/resolve/{REV}/'+shard['file']
        assert re.fullmatch(r'"[0-9a-f]{64}"', shard['etag'])
        headers.append(json.loads(raw))
    for row in plan['roles']:
        shard = plan['shards'][row['source_shard']]
        actual = headers[row['source_shard']][row['name']]
        assert row['source_file'] == shard['file']
        assert (row['dtype'],row['shape'],row['data_relative_half_open']) == (actual['dtype'],actual['shape'],actual['data_offsets'])
        first,end=actual['data_offsets']
        assert end-first==row['bytes']>0
        assert row['absolute_inclusive']==[shard['data_base']+first,shard['data_base']+end-1]
        assert row['absolute_inclusive'][1]<shard['whole_file_bytes']
        assert Path(row['filename']).name==row['filename']
    return path,plan


def shared_transport():
    assert identity(TRANSPORT)['sha256'] == TRANSPORT_SHA
    spec=importlib.util.spec_from_file_location('_q30_existing_transport',TRANSPORT)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # Definitions only; no guarded main.
    shared=module.shared_downloader()
    assert (module.REQUEST_CHUNK,module.CHUNK,module.IO,module.WORKERS)==(8388608,134217728,1048576,3)
    assert identity(RETRY)['sha256'] == RETRY_SHA
    retry_spec=importlib.util.spec_from_file_location('_q30_existing_transport_retry',RETRY)
    retry=importlib.util.module_from_spec(retry_spec)
    retry_spec.loader.exec_module(retry)  # Definitions only; its guarded main is not called.
    return shared,retry.acquire_with_retry


def acquire(out, plan_path, plan, selected, shared, acquire_with_retry):
    out.mkdir(parents=True,exist_ok=True)
    with shared.single_writer(out/'.fetch.lock'):
        receipt=out/'acquisition.json'
        roles=[]
        for row in selected:
            shard=plan['shards'][row['source_shard']]
            actual=dict(row)
            actual.setdefault('global_id',None)
            actual.setdefault('leg','static')
            roles.append(dict(actual,url=shard['url'],etag=shard['etag'],whole_file_bytes=shard['whole_file_bytes'],
                complete=False,chunks=[],payload=dict(path=(out/row['filename']).relative_to(R).as_posix(),bytes=row['bytes'],sha256=None)))
        expected=dict(repository=REPO,revision=REV,source_plan=plan_path.relative_to(R).as_posix(),
            source_plan_sha256=identity(plan_path)['sha256'],selected_names=[x['name'] for x in selected],
            expected_role_payload_bytes=sum(x['bytes'] for x in selected),downloader=identity(TRANSPORT))
        if receipt.exists():
            record=read(receipt)
            assert all(record[k]==value for k,value in expected.items())
            for prior,wanted in zip(record['roles'],roles,strict=True):
                assert all(prior[k]==value for k,value in wanted.items() if k not in ('complete','chunks','payload'))
                assert prior['payload']['path']==wanted['payload']['path'] and prior['payload']['bytes']==wanted['bytes']
        else:
            assert not any((R/x['payload']['path']).exists() for x in roles), 'Unrecorded body is not an authenticated prefix'
            record=dict(expected,complete=False,original_roles=len(roles),whole_shard_downloaded=False,requests=[],roles=roles)
        functions=shared.downloader(record,receipt)
        with functions['LOCK']:
            record.update(complete=False,chunk_bytes=134217728,request_chunk_bytes=8388608,
                stream_buffer_bytes=1048576,parallel_role_workers=3)
            functions['save']()
        failures=[]
        with ThreadPoolExecutor(max_workers=3,thread_name_prefix='q30-role') as executor:
            for future in as_completed([executor.submit(acquire_with_retry,functions,record,row) for row in record['roles']]):
                try:
                    future.result()
                except Exception as error:
                    failures.append(error)
        if failures:
            with functions['LOCK']:
                record['complete']=False
                functions['save']()
            raise failures[0]
        with functions['LOCK']:
            assert all(x['complete'] and re.fullmatch('[0-9a-f]{64}',x['payload']['sha256']) for x in record['roles'])
            total=sum(x['payload']['bytes'] for x in record['roles'])
            assert total==expected['expected_role_payload_bytes']==sum(x['bytes'] for x in record['requests'] if x['complete'])
            record.update(complete=True,role_payload_bytes=total,finished_utc=functions['now']())
            functions['save']()
        manifest=dict(repository=REPO,revision=REV,complete=True,original_roles=len(selected),source_bytes=total,
            source_plan=identity(plan_path),source_receipt=identity(receipt),artifact_executed=False,
            roles=[dict(name=x['name'],file=x['filename'],dtype=x['dtype'],shape=x['shape'],bytes=x['bytes'],
                sha256=x['payload']['sha256'],absolute_inclusive=x['absolute_inclusive']) for x in record['roles']])
        (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(complete=True,directory=out.relative_to(R).as_posix(),roles=len(selected),body_bytes=total,
            receipt=identity(receipt),manifest=identity(out/'manifest.json'))),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--static',action='store_true')
    group.add_argument('--expert-ids',nargs='+',type=int)
    parser.add_argument('--plan-only',action='store_true')
    parser.add_argument('--write-batch-plan',type=Path,
        help='Write a root budget-wrapper plan only; never starts acquisition')
    args=parser.parse_args()
    ids=sorted(set(args.expert_ids or []))
    if not args.static:
        assert 1<=len(ids)<=8 and all(0<=i<288 for i in ids), 'One actual Top8 frontier, original288 domain only'
    plan_path,plan=checked_plan('static-plan.json' if args.static else 'expert-source-plan.json')
    batches=[(S/'original-static',plan['roles'])] if args.static else [
        (S/'original-experts'/f'expert{global_id:03}',[x for x in plan['roles'] if x['global_id']==global_id]) for global_id in ids]
    assert all(len(rows)==(34 if args.static else 6) for _,rows in batches)
    total=sum(x['bytes'] for _,rows in batches for x in rows)
    if args.write_batch_plan:
        destination=args.write_batch_plan.resolve()
        assert destination.is_relative_to(R/'.scratch')
        arguments=['--static'] if args.static else ['--expert-ids',*map(str,ids)]
        label='static' if args.static else 'experts-'+'-'.join(map(str,ids))
        batch=dict(script=Path(__file__).relative_to(R).as_posix(),arguments=arguments,
            out=(S/'prefetch'/label).relative_to(R).as_posix(),need_evidence=identity(plan_path),
            new_unique_body_bytes=total,whole_bank=False,whole_model=False,timeout_seconds=14400,
            roles=sum(len(rows) for _,rows in batches),globals=ids,
            new_request_limit_bytes=8388608,authenticated_legacy_chunk_limit_bytes=134217728,
            stream_buffer_bytes=1048576,role_workers=3,
            reason='Only declared Q30 static roles or this caller-supplied actual Top8 frontier; no other experts.',
            retry_note='Unique necessary payload is not a traffic guarantee; every retry stays under existing budget accounting.',
            compile_and_native_authorized_by_this_plan=False)
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(json.dumps(batch,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(batch_plan=identity(destination),body_bytes=total,http_requests=0)))
        return
    if args.plan_only:
        print(json.dumps(dict(repository=REPO,revision=REV,source_plan=identity(plan_path),
            globals=ids,roles=sum(len(rows) for _,rows in batches),body_bytes=total,
            new_request_bytes=8388608,authenticated_legacy_chunk_limit=134217728,io_bytes=1048576,workers=3,
            output_directories=[out.relative_to(R).as_posix() for out,_ in batches],http_requests=0)))
        return
    shared,acquire_with_retry=shared_transport()
    for out,rows in batches:
        acquire(out,plan_path,plan,rows,shared,acquire_with_retry)


if __name__=='__main__':
    main()
