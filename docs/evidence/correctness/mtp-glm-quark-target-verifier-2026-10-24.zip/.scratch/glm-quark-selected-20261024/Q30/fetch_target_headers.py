"""Root-only exact Q30 target metadata, reusing the existing checked reader."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[2]
HELPER=R/'.scratch/mtp-artifact-schema-20261023/fetch_headers.py'
HELPER_SHA='bab682186d8be2318669b1e70d5b9cd7365b589751d16b15094f30706a40685a'
PLAN_SHA='4cd8b9524e17ea4df3782d3cb20bd79fbf19119c1f4e1e00c2b5639ab964c463'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only',action='store_true')
    args=parser.parse_args()
    raw=(S/'target-metadata-plan.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==PLAN_SHA
    plan=json.loads(raw)
    assert (plan['repository'],plan['revision'])==('amd/GLM-5.3-Flash-Quark-MXFP4','b5688f25491202978c19c4d036eef579f61bbe07')
    assert len(plan['requests'])==4 and plan['tensor_payload_bytes']==0
    assert hashlib.sha256(HELPER.read_bytes()).hexdigest()==HELPER_SHA
    if args.plan_only:
        print(json.dumps(dict(files=[x['file'] for x in plan['requests']],maximum_requested_bytes=plan['maximum_requested_bytes'],http_requests=0)))
        return
    spec=importlib.util.spec_from_file_location('_q30_existing_header_reader',HELPER)
    reader=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    reader.S=S/'target-headers'
    reader.MAX_TOTAL=plan['maximum_requested_bytes']
    try:
        sources=[]
        for wanted in plan['requests']:
            tensors,receipt=reader.header('Q30',plan['repository'],plan['revision'],wanted['file'])
            assert all(name in tensors for name in wanted['expected_roles'])
            sources.append(receipt)
        reader.save(S/'target-headers/summary.json',dict(complete=True,repository=plan['repository'],revision=plan['revision'],
            tensor_payload_bytes=0,sources=sources))
    finally:
        reader.save(S/'target-headers/http-requests.json',dict(requests=reader.requests,requested_bytes=reader.reserved))


if __name__=='__main__':
    main()
