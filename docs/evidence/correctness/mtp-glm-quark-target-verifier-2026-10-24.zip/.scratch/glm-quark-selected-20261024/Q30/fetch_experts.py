"""Thin actual-frontier supplier for the existing Q30 bounded acquisition.

Executed only by root's explicit owned-process supply driver. No acquisition
starts on import/plan-only. One required per-ID set is immutable; the source
hook itself never performs HTTP.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

S=Path(__file__).resolve().parent
R=S.parents[2]
REPO='amd/GLM-5.3-Flash-Quark-MXFP4'
REV='b5688f25491202978c19c4d036eef579f61bbe07'


def main():
    if os.environ.get('HYLE_GLM_Q30_CACHE_ONLY') == '1':
        # The native consumer reached a missing-ID frontier. During another
        # approved batch, a cache-only check must stop here before any fetch.
        print('Q30 cache-only run needs uncached experts; no download started.',flush=True)
        return 4
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frontier-file',type=Path,required=True)
    parser.add_argument('--plan-only',action='store_true')
    args=parser.parse_args()
    raw=args.frontier_file.read_bytes()
    assert 0<len(raw)<=65536
    request=json.loads(raw)
    layer={'target43':43,'target44':44,'nextn':45}[request['section']]
    assert request['stage']==0 and type(request['stage']) is int
    assert request['repository']==REPO and request['revision']==REV
    assert request['layer_prefix']==f'model.language_model.layers.{layer}.'
    ids=request['missing_ids'];globals_=request['global_ids']
    assert 1<=len(ids)<=8 and len(set(ids))==len(ids)
    assert all(type(x) is int and 0<=x<288 for x in ids+globals_) and set(ids)<=set(globals_)
    plan=S/('expert-source-plan.json' if layer==45 else f'target{layer}-expert-source-plan.json')
    assert request['source_plan_sha256']==hashlib.sha256(plan.read_bytes()).hexdigest()
    script=S/('fetch_roles.py' if layer==45 else 'fetch_target_roles.py')
    arguments=[] if layer==45 else ['--layer',str(layer)]
    arguments+=['--expert-ids',*map(str,sorted(ids))]
    if args.plan_only:
        return subprocess.run([sys.executable,str(script),*arguments,'--plan-only'],cwd=R,check=True).returncode
    # The consumer's cache paths and the bounded supplier must be identical.
    assert Path(os.environ['HYLE_GLM_Q30_ORIGINAL_DIR']).resolve()==S
    label=f'{request["section"]}-'+ '-'.join(map(str,sorted(ids)))
    batch=S/'frontier-plans'/(label+'.json');batch.parent.mkdir(exist_ok=True)
    subprocess.run([sys.executable,str(script),*arguments,'--write-batch-plan',str(batch)],cwd=R,check=True)
    subprocess.run([sys.executable,str(R/'.scratch/mtp-download-budget-20261023/run_batch.py'),str(batch)],cwd=R,check=True)
    for global_id in sorted(ids):
        pins=[sys.executable,str(S/'generate_pins.py'),'--expert-id',str(global_id)]
        if layer!=45:pins+=['--target-layer',str(layer)]
        subprocess.run(pins,cwd=R,check=True)
    return 0


if __name__=='__main__':
    sys.exit(main())
