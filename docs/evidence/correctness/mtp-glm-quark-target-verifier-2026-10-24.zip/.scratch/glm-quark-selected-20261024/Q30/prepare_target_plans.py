"""Offline Q30 original43/44 plans from their actual authenticated headers.

Only immutable non-expert roles and per-ID original expert planes are planned;
the full288-expert metadata catalogue never authorizes a full-bank download.
"""
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
REPO, REV = 'amd/GLM-5.3-Flash-Quark-MXFP4', 'b5688f25491202978c19c4d036eef579f61bbe07'
SUMMARY = S / 'target-headers/summary.json'
SUMMARY_SHA = 'de2f925330358bcbe2fae329797a385f85f3353366b73abd83d2bca874c0d1a1'
SEMANTIC_PINS = {
    43: 'e895eeba9fb6be4cc7582ca894822c608c162a0beec0936e1ee49b7de2879d8d',
    44: '104770c83cfb8132cd64aa8b41697a081b29b8ee23cb14e28ef8351af8f62940',
}
WIDTH = {'BF16': 2, 'F32': 4, 'F8_E4M3': 1, 'U8': 1}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=Path(path).relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def headers():
    assert identity(SUMMARY)['sha256'] == SUMMARY_SHA
    summary = read(SUMMARY)
    assert summary['complete'] and summary['tensor_payload_bytes'] == 0
    assert (summary['repository'], summary['revision']) == (REPO, REV)
    assert [x['file'] for x in summary['sources']] == [f'model-{n:05}-of-00062.safetensors' for n in (52, 53, 54, 62)]
    table, shards = {}, []
    for source in summary['sources']:
        assert (source['repository'], source['revision']) == (REPO, REV)
        assert source['url'] == f'https://huggingface.co/{REPO}/resolve/{REV}/'+source['file']
        assert re.fullmatch('"[0-9a-f]{64}"', source['etag'])
        assert source['tensor_payload_bytes'] == 0 and not source['whole_shard_downloaded']
        path = R / source['header']['path']
        assert identity(path) == source['header'] and source['data_base'] == path.stat().st_size + 8
        header = read(path)
        shard = len(shards)
        shards.append({k:source[k] for k in ('file','url','etag','whole_file_bytes','data_base','header')})
        for name, row in header.items():
            if name == '__metadata__':
                continue
            assert name not in table
            first, end = row['data_offsets']
            assert 0 <= first < end and source['data_base'] + end <= source['whole_file_bytes']
            if row['dtype'] in WIDTH:
                elements = 1
                for n in row['shape']:
                    assert type(n) is int and n > 0
                    elements *= n
                assert end - first == elements * WIDTH[row['dtype']]
            table[name] = dict(row, source_shard=shard, source_file=source['file'])
    return table, shards


def plans(layer):
    assert layer in (43, 44)
    table, shards = headers()
    semantic = R / f'.scratch/glm-original-target{layer}-20261023/static-plan.json'
    assert identity(semantic)['sha256'] == SEMANTIC_PINS[layer]
    old = read(semantic)['roles']  # Reuse schema/name/file only; never its bytes or pins.
    prefix = f'model.language_model.layers.{layer}.'
    expected = {x['name']:x for x in old}
    if layer == 43:
        expected = {name.replace('.weight_scale_inv','.weight_scale'):row for name,row in expected.items()}
    assert len(expected) == (26 if layer == 43 else 24)
    selected = {}
    for name, row in expected.items():
        actual = table[name]
        assert (actual['dtype'], actual['shape']) == (row['dtype'], row['shape'])
        selected[name] = row['filename']
    for name, actual in table.items():
        if not name.startswith(prefix+'mlp.') or '.mlp.experts.' in name:
            continue
        suffix = name.removeprefix(prefix+'mlp.')
        if suffix == 'gate.weight':
            assert actual['dtype'] == 'BF16' and actual['shape'] == [288,4096]
            filename = 'router.weight.bf16'
        elif suffix == 'gate.e_score_correction_bias':
            assert actual['dtype'] == 'F32' and actual['shape'] == [288]
            filename = 'router.e_score_correction_bias.f32'
        else:
            match = re.fullmatch(r'shared_experts\.(gate|up|down)_proj\.(weight|weight_scale)', suffix)
            assert match, name
            leg, plane = match.groups()
            n,k = (4096,2048) if leg == 'down' else (2048,4096)
            assert actual['dtype'] == 'U8' and actual['shape'] == [n,k//(32 if plane == 'weight_scale' else 2)]
            filename = f'shared_{leg}.{plane}.'+('ue8' if plane == 'weight_scale' else 'mxfp4')
        selected[name] = filename
    assert len(selected) == (34 if layer == 43 else 32)

    def role(name, filename, **extra):
        raw = table[name];first,end = raw['data_offsets'];shard = shards[raw['source_shard']]
        return dict(name=name, filename=filename, dtype=raw['dtype'], shape=raw['shape'],
            bytes=end-first, source_file=raw['source_file'], source_shard=raw['source_shard'],
            data_relative_half_open=[first,end],
            absolute_inclusive=[shard['data_base']+first,shard['data_base']+end-1], **extra)

    static = [role(name,filename) for name,filename in selected.items()]
    experts = []
    for global_id in range(288):
        for leg in ('gate','up','down'):
            n,k = (4096,2048) if leg == 'down' else (2048,4096)
            for plane in ('weight','weight_scale'):
                name = prefix+f'mlp.experts.{global_id}.{leg}_proj.{plane}'
                actual = table[name]
                assert actual['dtype'] == 'U8' and actual['shape'] == [n,k//(32 if plane == 'weight_scale' else 2)]
                experts.append(role(name,f'{leg}.{plane}.'+('ue8' if plane == 'weight_scale' else 'mxfp4'),
                    global_id=global_id, leg=leg, plane=plane))
    assert len(experts) == 1728
    assert sum(row['bytes'] for row in experts[:6]) == 13369344
    full = {name for name in table if name.startswith(prefix)}
    assert full == {row['name'] for row in static+experts if row['name'].startswith(prefix)}
    assert len(full) == (1762 if layer == 43 else 1759)
    common = dict(repository=REPO, revision=REV, layer=layer, metadata_only=True,
        tensor_payload_bytes=0, complete_absolute_ranges=True, shards=shards,
        header_receipt=identity(SUMMARY), semantic_names_shapes=identity(semantic),
        full_expert_bank_download_allowed=False, paired_nextn_static=identity(S/'static-plan.json'),
        weight_contract='Original U8 low-even/high-odd E2M1 and U8 E8M0 group32. Public Mxfp4Linear/GroupedMxfp4Linear W4A4; BF16 actual A/Y, no A128 substitution or floating W shadow.')
    return (dict(common, original_roles=len(static), source_bytes=sum(row['bytes'] for row in static), roles=static),
        dict(common, original_roles=len(experts), logical_full_domain=288, maximum_ids_per_frontier=8,
            per_expert_bytes=13369344, full_source_bytes=sum(row['bytes'] for row in experts), roles=experts))


def checked_plan(layer, experts=False):
    name = f'target{layer}-'+('expert-source-plan.json' if experts else 'static-plan.json')
    path = S / name
    actual = plans(layer)[int(experts)]
    assert read(path) == actual
    return path, actual


def main():
    result = []
    for layer in (43,44):
        for suffix, value in zip(('static-plan.json','expert-source-plan.json'),plans(layer),strict=True):
            path = S / f'target{layer}-{suffix}'
            if path.exists():
                assert read(path) == value
            else:
                path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
            result.append(identity(path))
    print(json.dumps(dict(plans=result, http_requests=0)))


if __name__ == '__main__':
    main()
