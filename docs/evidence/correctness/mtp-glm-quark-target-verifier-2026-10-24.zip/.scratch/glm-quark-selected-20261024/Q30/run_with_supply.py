"""Q30 configuration of the existing owned-process supply driver."""
import importlib.util
from pathlib import Path
import sys

S=Path(__file__).resolve().parent
R=S.parents[2]
DRIVER=R/'.scratch/dspark-pro-target-draft-20261023/run_with_supply.py'


def main():
    spec=importlib.util.spec_from_file_location('_q30_explicit_supply_driver',DRIVER)
    if spec is None or spec.loader is None:raise RuntimeError('Existing owned supply driver missing')
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    driver.S,driver.R=S,R
    driver.DOMAIN,driver.SECTIONS=288,('nextn','target43','target44')
    driver.WAIT_ENV='HYLE_GLM_Q30_WAIT_FOR_EXPERTS'
    driver.FRONTIER_ENV='HYLE_GLM_Q30_FRONTIER_FILE'
    return driver.main()


if __name__=='__main__':
    sys.exit(main())
