"""Run one exact Q30 original case through its owned actual-frontier supplier."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;R=S.parents[3]
spec=importlib.util.spec_from_file_location('q30_original_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def verify(info):
    raw=Path(info['path']).read_bytes()
    assert len(raw)==info['bytes'] and hashlib.sha256(raw).hexdigest()==info['sha256']
p=argparse.ArgumentParser();p.add_argument('backend',choices=('cpu','cuda'));p.add_argument('--attempt',type=int,required=True)
p.add_argument('--image-dir',type=Path,default=Path('tests-link1'),help='Image directory; relative paths are under this fixed validation directory')
a=p.parse_args();image_dir=(a.image_dir if a.image_dir.is_absolute() else S/a.image_dir).resolve()
ready=read(image_dir/'ready.json');verify(ready['image']);verify(ready['runtime_environment'])
runtime=read(image_dir/'runtime-environment.json')
for item in runtime['staged_dlls']:verify(item)
env=os.environ.copy();env.update(PATH=runtime['PATH'],HYLE_GLM_Q30_ORIGINAL_DIR=str(A))
out=S/f'checks{a.attempt}-{a.backend}';assert not out.exists();out.mkdir()
case='GlmMtpStateConsumer.'+('Cpu' if a.backend=='cpu' else 'Cuda')+'QuarkOriginalTarget43And44AndNextNFullVocabularyVerifier'
command=[sys.executable,str(A/'run_with_supply.py'),'--image',ready['image']['path'],
    '--frontier-file',str(out/'frontier.json'),'--','--gtest_filter='+case,
    '--gtest_throw_on_failure=1','--gtest_output=xml:'+str(out/'results.xml')]
(out/'plan.json').write_text(json.dumps(dict(command=command,image=ready['image'],image_directory=str(image_dir),case=case,
    original_root=str(A),scope='Finite original target43/44/NextN source and state; not full-model quality/TPS'),indent=2)+'\n',encoding='utf-8')
result=q.execute(command,env,out/'run',timeout=14400)
if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
driver=read(out/'frontier.driver.json')
assert driver['native']['exit']==0 and not driver['native']['stopped_by_driver']
assert all(item['exit']==0 and not item.get('stopped_by_driver',False) for item in driver['fetches'])
tree=ET.parse(out/'results.xml').getroot();cases=list(tree.iter('testcase'))
assert len(cases)==1 and all(int(tree.get(k,'0'))==0 for k in ('failures','errors','disabled'))
assert not list(tree.iter('skipped'))
actual=cases[0];assert actual.get('classname')+'.'+actual.get('name')==case
summary=dict(case=case,tests=1,failures=0,skips=0,
    properties={x.get('name'):x.get('value') for x in actual.iter('property')},
    throughput_evidence=False,memory_evidence=False)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('PASSED actual Q30',a.backend,flush=True)
