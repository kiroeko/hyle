"""Link the actually compiled current Flash image and stage its one CPU module."""
from pathlib import Path
import hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[3]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
h=module('flash_link_env',R/'.scratch/native-paged-effects-20261022/build_windows.py')
q=module('flash_link_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
cache={}
def identity(path):
    path=Path(path);key=str(path)
    if key not in cache:
        sha=hashlib.sha256()
        with path.open('rb') as stream:
            for block in iter(lambda:stream.read(1048576),b''):sha.update(block)
        cache[key]=dict(path=key,bytes=path.stat().st_size,sha256=sha.hexdigest())
    return cache[key]
def check(info):assert identity(info['path'])==info,info['path']
plan_path=S/'link-plan.json';plan=read(plan_path);assert plan['pending_consumer'] is False
for item in plan['retained_inputs']:check(item)
records=[Path(plan['consumer_record']['path'])]
records += list((S/'host1/records').glob('*/identity.json'))+list((S/'support1/records').glob('*/identity.json'))
records += [Path(info['path']) for info in plan['reused_current_records']]
for path in records:
    record=read(path)
    for item in (record['source'],record['object'],*record['dependencies']):check(item)
out=S/'tests-link1';(out/'tmp').mkdir(exist_ok=True)
env,_=h.b.environment(plan['command'],[],out);env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
result=q.execute([plan['command'][0],'@'+str(S/'link-flash.rsp')],env,out/'link1',timeout=1800)
if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
module_info=plan['runtime_avx2_dll'];check(module_info)
target=out/Path(module_info['path']).name;os.link(module_info['path'],target)
base=Path(plan['base']['path']).parent
runtime=read(base/'runtime-environment.json')
runtime['PATH']=str(out)+os.pathsep+runtime['PATH'].replace(str(base),str(out))
runtime['staged_dlls']=[identity(target)]
runtime['previous']=identity(base/'runtime-environment.json')
(out/'runtime-environment.json').write_text(json.dumps(runtime,indent=2)+'\n',encoding='utf-8')
image=out/'glm-flash-checks.exe'
(out/'ready.json').write_text(json.dumps(dict(image=identity(image),link_plan=identity(plan_path),
    runtime_environment=identity(out/'runtime-environment.json'),consumer_record=plan['consumer_record'],
    scope='Actual current shared Flash source and original Q30 pins; native execution pending'),indent=2)+'\n',encoding='utf-8')
print('LINKED current Flash with three actual Q30 static pin headers; native pending',flush=True)
