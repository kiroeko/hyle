"""Offline actual-cache host recipe emission. No compiler or network invocation."""
from pathlib import Path
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
OUT = HERE / 'host1'
HELPERS = ROOT / '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/recipe-preparation'
sys.path.insert(0, str(HELPERS))
import prepare_native as n
import prepare_host as h

BASE = ROOT / '.scratch/glm-gguf-selected-20261023/B09/native-integration/tests-link3/link-plan.json'


def record_for_object(obj, cache):
    obj = Path(obj)
    candidates = [obj.parent / 'identity.json', obj.parent / (obj.stem + '-identity.json')]
    candidates += list(obj.parent.glob('*identity.json'))
    for path in dict.fromkeys(candidates):
        if not path.is_file():
            continue
        if path not in cache:
            try:
                cache[path] = n.read(path)
            except (ValueError, UnicodeError):
                cache[path] = {}
        record = cache[path]
        if isinstance(record, dict) and isinstance(record.get('object'), dict):
            if record['object'].get('path', '').lower() == str(obj).lower():
                return path, record
    return None


def main():
    OUT.mkdir(exist_ok=True)
    sources = n.read(HERE / 'must-compile-sources.json')['sources']
    base = n.read(BASE)
    records, cache = {}, {}
    for arg in base['command']:
        if arg.lower().endswith('.obj'):
            found = record_for_object(arg, cache)
            if found:
                path, record = found
                records[record['source']['path'].lower()] = (path, record)
    module_records = {}
    for path, record in records.values():
        source = Path(record['source']['path'])
        if source.parent.parent == ROOT / 'src' and 'command' in record:
            module_records.setdefault(source.parent.name, (path, record))
    ninja = h.ninja_recipes()
    cl = n.read(ROOT / '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/compile1/cpu-provider/identity.json')['command'][0]
    jobs = []
    for relative in sources:
        source = ROOT / relative
        module = source.parent.name
        tag = module + '--' + source.stem
        if str(source).lower() in records and 'command' in records[str(source).lower()][1]:
            recipe, old = records[str(source).lower()]
            args = n.cl_command(old['command'], old['source']['path'], source, tag)
            mode = 'actual same-source object recipe'
        elif source.as_posix().lower() in ninja:
            recipe = h.NINJA
            args = n.cl_command([cl, '/nologo', '/TP', '/c'] + ninja[source.as_posix().lower()], source, source, tag)
            mode = 'actual cached Ninja source rule'
        elif module in module_records:
            recipe, old = module_records[module]
            args = n.cl_command(old['command'], old['source']['path'], source, tag)
            mode = 'same owner module actual recipe'
        else:
            raise RuntimeError('No real recipe: ' + relative)
        args = [x.replace(str(n.OUT), str(OUT)) for x in args]
        args = ['/MD' if x == '-MD' else x for x in args]
        # Current module's common include, needed by its original MLX kernel
        # declarations; this is an existing CMake include, not a new SDK.
        if module == 'compute_provider_cuda':
            flag = '/I' + str(ROOT / 'third_party/mlx_cuda_quant')
            if flag not in args:
                args.insert(1, flag)
        assert '/W4' in args and '/WX' in args and '/O2' in args and '/MD' in args, relative
        jobs.append(dict(name=tag, command=args, source=n.ident(source),
                         recipe=n.ident(recipe), recipe_selection=mode,
                         working_directory=str(ROOT)))
    assert len(jobs) == 84
    data = dict(executed=False, provider_contract=18, jobs=jobs,
                actual_link_baseline=n.ident(BASE), sdk_builds=0, nvcc_builds=0,
                final_flash_test_tu='deferred until all three Q30 actual generated headers exist',
                note='Fresh active Graph/default assembly/provider owners only. Focused current compute/ops/backends and foundation objects are reused separately.')
    (HERE / 'host-commands.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    vcvars = Path(cl).parents[6] / 'Auxiliary/Build/vcvars64.bat'
    lines = ['@echo off', 'call ' + subprocess.list2cmdline([str(vcvars)]),
             'if errorlevel 1 exit /b %errorlevel%', 'cd /d ' + subprocess.list2cmdline([str(ROOT)])]
    for job in jobs:
        rsp = HERE / (job['name'] + '.rsp')
        rsp.write_text('\r\n'.join(subprocess.list2cmdline([x]) for x in job['command'][1:]) + '\r\n', encoding='utf-8')
        lines += ['rem ' + job['name'], subprocess.list2cmdline([cl, '@' + str(rsp)]),
                  'if errorlevel 1 exit /b %errorlevel%']
    (HERE / 'compile-host.cmd').write_text('\r\n'.join(lines) + '\r\n', encoding='utf-8')
    print('PREPARED 84 actual host recipes; no compile/link/native/HTTP')


if __name__ == '__main__':
    main()
