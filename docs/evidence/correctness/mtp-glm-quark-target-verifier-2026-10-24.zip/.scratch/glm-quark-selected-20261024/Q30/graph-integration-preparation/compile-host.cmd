@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
cd /d C:\public\project-hyle\hyle
rem graph--graph
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--graph.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--effect_order
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--effect_order.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--executable
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--executable.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--submission
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--submission.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--execution_source
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--execution_source.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--view_domain
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--view_domain.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--constant_artifact
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--constant_artifact.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--resources
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--resources.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--lease_submission
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--lease_submission.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--region_access
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--region_access.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--input_sources
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--input_sources.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph--resource_report
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph--resource_report.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_batch--batch
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_batch--batch.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_batch--materialized_invocation
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_batch--materialized_invocation.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_batch--native_paged_node
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_batch--native_paged_node.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_batch--native_batch_regions
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_batch--native_batch_regions.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_batch--native_pending_regions
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_batch--native_pending_regions.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_batch--row_cache_node
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_batch--row_cache_node.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_batch--paged_append
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_batch--paged_append.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_batch--batch_execution
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_batch--batch_execution.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_batch--batch_materialize
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_batch--batch_materialize.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_batch--batch_paged_native
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_batch--batch_paged_native.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_batch--materialized_invocation
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_batch--materialized_invocation.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_batch--paged_arena
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_batch--paged_arena.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_batch--paged_append_program
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_batch--paged_append_program.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_batch--row_cache_paged_reader
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_batch--row_cache_paged_reader.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_route_cpu--cpu_context
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_route_cpu--cpu_context.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_route_cpu--default_policy
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_route_cpu--default_policy.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_route_cuda--cuda_context
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_route_cuda--cuda_context.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_route_cuda--default_policy
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_route_cuda--default_policy.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_route_cuda--weights
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_route_cuda--weights.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cpu--cpu_context
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cpu--cpu_context.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cpu--compile
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cpu--compile.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cpu--ct_packed_linear_region
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cpu--ct_packed_linear_region.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cpu--ggml_region
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cpu--ggml_region.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cuda--cuda_context
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cuda--cuda_context.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cuda--weight_binding
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cuda--weight_binding.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cuda--dense_bfloat_scores_region
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cuda--dense_bfloat_scores_region.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cuda--ct_packed_linear_region
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cuda--ct_packed_linear_region.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cuda--fp8_shared_prologue_region
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cuda--fp8_shared_prologue_region.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_provider_ggml_cuda--ggml_cuda_region
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_provider_ggml_cuda--ggml_cuda_region.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_provider_onednn--onednn_region_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_provider_onednn--onednn_region_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--aten_cpu_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--aten_cpu_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--blockwise_w4a8
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--blockwise_w4a8.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--cast
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--cast.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--ct_packed
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--ct_packed.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--static_fp8
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--static_fp8.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--default_rules
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--default_rules.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--ds4_quantization
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--ds4_quantization.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--elementwise
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--elementwise.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--indexing
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--indexing.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--native_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--native_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--nvfp4
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--nvfp4.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--normalization
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--normalization.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--reduction
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--reduction.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--row_cache
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--row_cache.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--sampling
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--sampling.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--transform
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--transform.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--transformer
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--transformer.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_native--torch_cpu_program
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_native--torch_cpu_program.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--collectives_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--collectives_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--sampling_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--sampling_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--cuda_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--cuda_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--router_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--router_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--fp8_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--fp8_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--grouped_fp8_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--grouped_fp8_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--deepseek_fp8_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--deepseek_fp8_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--deepseek_grouped_fp4_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--deepseek_grouped_fp4_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--tensor_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--tensor_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--norm_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--norm_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--nvfp4_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--nvfp4_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--blockwise_w4a8_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--blockwise_w4a8_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--reduction_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--reduction_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--concat_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--concat_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--scatter_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--scatter_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--row_cache_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--row_cache_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--float8_quantize_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--float8_quantize_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cuda--row_cache_indexer_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cuda--row_cache_indexer_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_cublas--cublas_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_cublas--cublas_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_torch_cuda--artifact_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_torch_cuda--artifact_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_flashinfer--flashinfer_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_flashinfer--flashinfer_provider.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_onednn--brgemm_internal
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_onednn--brgemm_internal.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_onednn--normalization_internal
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_onednn--normalization_internal.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_provider_onednn--onednn_provider
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_provider_onednn--onednn_provider.rsp
if errorlevel 1 exit /b %errorlevel%
