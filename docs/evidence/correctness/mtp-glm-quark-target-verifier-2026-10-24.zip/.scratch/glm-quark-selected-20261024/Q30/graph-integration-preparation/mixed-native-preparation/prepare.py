"""Offline same-mixed-family CPU module recipe; never invokes a build."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess

R=Path(__file__).resolve().parents[5]
S=Path(__file__).resolve().parent
QI=S.parent
OUT=QI/'native-mixed1'
MIXED=R/'.scratch/validation/cpu-final-f1/mixed-iq1/source'
CACHE=R/'.scratch/build-cpu-final-mixed-probe'
GV=R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation'
OPS=R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-proposal/native-after/cpu-mixed/src/ggml-cpu/ops.cpp'


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def identity(path):
    raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')


def main():
    helper_path=GV/'recipe-preparation/prepare_native.py'
    spec=importlib.util.spec_from_file_location('_existing_native_recipe_helpers',helper_path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.OUT=OUT
    compdb=CACHE/'compile_commands.json';rows=read(compdb)
    cpu=[row for row in rows if '/ggml-cpu/' in row['file'].replace('\\','/')]
    assert len(cpu)==15 and all(Path(row['file']).is_relative_to(MIXED) for row in cpu)
    recipe=next(row for row in cpu if row['file'].endswith('/ggml-cpu/ops.cpp'))
    assert identity(OPS)['sha256']=='f9da47ed013172ee48973c5a012bd88fce90930680bcbdf39268f72d33a4aa68'
    original=Path(recipe['file'])
    retained=[dict(source=identity(Path(row['file'])),object=identity(Path(row['output'])),
        command=row['command'],directory=row['directory']) for row in cpu if row is not recipe]
    assert len(retained)==14
    hadamard_path=GV/'foundation1/records/cpu-hadamard/identity.json';hadamard=read(hadamard_path)
    for info in (hadamard['source'],hadamard['object'],*hadamard['dependencies']):
        assert identity(Path(info['path']))==info
    ggml_deps=[row for row in hadamard['dependencies'] if Path(row['path']).name.lower() in ('ggml.h','ggml-cpu.h','ggml-impl.h')]
    assert len(ggml_deps)==3 and all(Path(row['path']).is_relative_to(MIXED) for row in ggml_deps)
    flags=['/EHsc-','/DGGML_AVX','/DGGML_AVX2','/DGGML_FMA','/DGGML_F16C','/DGGML_BMI2','/D__BMI2__','/arch:AVX2']
    command=helper.cl_command(helper.split_windows(recipe['command']),original,OPS,'cpu-avx2-mixed')
    command[1:1]=flags
    export=R/'src/compute_ggml_runtime/cpu_program_export.cc'
    export_command=helper.cl_command(helper.split_windows(recipe['command']),original,export,'cpu-program-export-mixed')
    export_command[1:1]=flags+['/I'+str(R/'include')]
    jobs=[dict(name='cpu-avx2-mixed',command=command,source=identity(OPS),object=str(OUT/'cpu-avx2-mixed.obj'),
        dependencies=str(OUT/'cpu-avx2-mixed-deps.json'),recipe=identity(compdb)),
        dict(name='cpu-program-export-mixed',command=export_command,source=identity(export),object=str(OUT/'cpu-program-export-mixed.obj'),
        dependencies=str(OUT/'cpu-program-export-mixed-deps.json'),recipe=identity(compdb))]
    prior=read(GV/'native1/records/cpu-avx2-dll/plan.json')['job']['command']
    system_libraries=[x for x in prior if x.lower().endswith('.lib') and ':'not in x and '/'not in x and '\\'not in x]
    base=CACHE/'ggml/src/ggml-base.lib'
    link=[str(Path(command[0]).with_name('link.exe')),'/nologo','/DLL','/MACHINE:X64','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(OUT/'hyle_ggml_cpu_gdn_scale_v3.dll'),'/IMPLIB:'+str(OUT/'mixed-module.lib'),'/MAP:'+str(OUT/'mixed-module.map'),
        jobs[0]['object'],jobs[1]['object'],*[row['object']['path'] for row in retained],hadamard['object']['path'],str(base),*system_libraries]
    assert len([x for x in link if x.lower().endswith('.obj')])==17
    assert not any('source-e74fc9' in x or 'ffa4' in x for x in link)
    jobs.append(dict(name='cpu-mixed-dll',command=link,retained_inputs=[row['object']for row in retained]+[hadamard['object'],identity(base)]))
    plan=dict(preparation_only=True,executed=False,working_directory=str(R),output_directory=str(OUT),jobs=jobs,
        source_family='mixed456172ec owning closure; not ffa4',cached_cpu_object_flags='Original mixed-probe cached flags retained; current ops/export rebuilt with explicit AVX2 flags. No performance claim.',
        mixed_source_root=str(MIXED),compilation_database=identity(compdb),recipe_helpers=identity(helper_path),
        retained_cpu=retained,hadamard_record=identity(hadamard_path),hadamard=hadamard,
        base_library=identity(base),owning_headers=[identity(MIXED/'include/ggml.h'),identity(MIXED/'include/ggml-cpu.h'),identity(MIXED/'src/ggml-impl.h')],
        constructor_source=identity(MIXED/'src/ggml.c'),public_export=identity(export),
        base_image_ready=identity(QI/'tests-link1/ready.json'),
        hc_contract='Mixed ggml_dsv4_hc_pre and mixed worker have no scale/gated op_params. This corrects only the hand assembled module family; no product compensation.',
        sdk_builds=0,nvcc_builds=0,recompiled_native_host_tus=2,retained_native_cpu_objects=14,retained_mixed_hadamard_objects=1,
        stale_ffa4_checks='Previous GDN-focused ffa4 module/checks remain untouched historical scope; they did not exercise HCpre.')
    save(S/'native-plan.json',plan)
    vcvars=Path(command[0]).parents[6]/'Auxiliary/Build/vcvars64.bat';assert vcvars.is_file()
    lines=['@echo off','call '+subprocess.list2cmdline([str(vcvars)]),'if errorlevel 1 exit /b %errorlevel%',
        'cd /d '+subprocess.list2cmdline([str(R)]),'if not exist '+subprocess.list2cmdline([str(OUT)])+' mkdir '+subprocess.list2cmdline([str(OUT)])]
    for job in jobs:lines += ['rem '+job['name'],subprocess.list2cmdline(job['command']),'if errorlevel 1 exit /b %errorlevel%']
    (S/'compile-native.cmd').write_text('\r\n'.join(lines)+'\r\n',encoding='utf-8',newline='')
    print(json.dumps(dict(plan=identity(S/'native-plan.json'),command_file=identity(S/'compile-native.cmd'),builds=0)))


if __name__=='__main__':main()
