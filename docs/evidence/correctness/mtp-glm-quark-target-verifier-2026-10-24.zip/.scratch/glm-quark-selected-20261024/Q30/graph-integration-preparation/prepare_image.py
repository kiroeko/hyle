"""Offline focused-to-Flash image composition. Never builds, runs, or downloads."""
from pathlib import Path
import argparse
import json
import re
import subprocess
import prepare_commands as p

ROOT, HERE, n = p.ROOT, p.HERE, p.n
GDN = ROOT / '.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation'


def emit_cmd(path, jobs):
    cl = jobs[0]['command'][0]
    vcvars = Path(cl).parents[6] / 'Auxiliary/Build/vcvars64.bat'
    lines = ['@echo off', 'call ' + subprocess.list2cmdline([str(vcvars)]),
             'if errorlevel 1 exit /b %errorlevel%', 'cd /d ' + subprocess.list2cmdline([str(ROOT)])]
    for job in jobs:
        rsp = HERE / (job['name'] + '.rsp')
        rsp.write_text('\r\n'.join(subprocess.list2cmdline([x]) for x in job['command'][1:]) + '\r\n', encoding='utf-8')
        lines += ['rem ' + job['name'], subprocess.list2cmdline([cl, '@' + str(rsp)]),
                  'if errorlevel 1 exit /b %errorlevel%']
    path.write_text('\r\n'.join(lines) + '\r\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--consumer-record', type=Path)
    args = parser.parse_args()
    base = n.read(p.BASE)
    host = n.read(HERE / 'host-commands.json')
    reused = []
    for directory in [GDN / 'host1/records', GDN / 'foundation1/records']:
        reused += list(directory.glob('*/identity.json'))
    reused += [GDN / 'compile1/cpu-provider/identity.json', GDN / 'compile1/tensor-program/identity.json']
    source_to_fresh = {}
    for path in reused:
        record = n.read(path)
        for value in [record['source'], record['object'], *record['dependencies']]:
            assert n.ident(Path(value['path'])) == value, value['path']
        source_to_fresh[record['source']['path'].lower()] = record['object']['path']
    for job in host['jobs']:
        source_to_fresh[job['source']['path'].lower()] = str(HERE / 'host1' / (job['name'] + '.obj'))
    cache = {}
    old_records = {}
    for value in base['command']:
        if value.lower().endswith('.obj'):
            found = p.record_for_object(value, cache)
            if found:
                old_records[value.lower()] = found
    # Three already linked support owners also include Graph/state headers.
    # Refresh these small exact owners rather than waiving old header deps.
    support_names = ['src/graph_progress/progress.cc', 'src/graph_route_cpu_cuda/compile.cc',
                     'src/compute_state/state_versions.cc']
    support = []
    support_out = HERE / 'support1'
    support_out.mkdir(exist_ok=True)
    for relative in support_names:
        source = ROOT / relative
        recipe, record = next(x for x in old_records.values()
                              if x[1]['source']['path'].lower() == str(source).lower())
        name = source.parent.name + '--' + source.stem
        command = n.cl_command(record['command'], record['source']['path'], source, name)
        command = [x.replace(str(n.OUT), str(support_out)) for x in command]
        support.append(dict(name=name, command=command, source=n.ident(source), recipe=n.ident(recipe)))
        source_to_fresh[str(source).lower()] = str(support_out / (name + '.obj'))
    (HERE / 'support-commands.json').write_text(json.dumps(dict(executed=False, jobs=support), indent=2) + '\n', encoding='utf-8')
    emit_cmd(HERE / 'compile-support.cmd', support)
    # One actual Flash TU; the prior source recipe already enables CPU+CUDA.
    consumer_recipe = ROOT / '.scratch/glm-quark-selected-20261024/Q30/regression/compile2/glm-state/identity.json'
    old_consumer = n.read(consumer_recipe)
    source = ROOT / 'tests/compute_models/glm_mtp_state_consumer_test.cc'
    generated = HERE.parent / 'generated'
    headers = [generated / ('q30_' + kind + '_static_pins.h') for kind in ['nextn', 'target43', 'target44']]
    macros = ['HYLE_TEST_GLM_Q30_NEXTN_ARTIFACTS_HEADER', 'HYLE_TEST_GLM_Q30_TARGET43_ARTIFACTS_HEADER',
              'HYLE_TEST_GLM_Q30_TARGET44_ARTIFACTS_HEADER']
    manifests = [HERE.parent / 'original-static/manifest.json',
                 HERE.parent / 'original-target43/static/manifest.json',
                 HERE.parent / 'original-target44/static/manifest.json']
    consumer_out = HERE / 'consumer1'
    consumer_out.mkdir(exist_ok=True)
    consumer_obj = consumer_out / 'flash-state.obj'
    available = all(x.is_file() for x in headers + manifests)
    consumer_plan = dict(ready=available, source=n.ident(source), recipe=n.ident(consumer_recipe),
                         required_actual_headers=[str(x) for x in headers], missing=[str(x) for x in headers + manifests if not x.is_file()], executed=False)
    if available:
        for header, manifest, count in zip(headers, manifests, [34,34,32]):
            value = n.read(manifest)
            assert value['complete'] is True and len(value['roles']) == count
            text = header.read_text(encoding='utf-8')
            assert f'kManifestSha256="{n.ident(manifest)["sha256"]}"' in text
            assert f'array<PinnedRole,{count}>' in text
        command = n.cl_command(old_consumer['command'], old_consumer['source']['path'], source, 'flash-state')
        command = [x.replace(str(n.OUT), str(consumer_out)) for x in command]
        command = [x for x in command if not any(x.startswith('/D' + macro + '=') for macro in macros)]
        command[1:1] = ['/D' + macro + '="' + str(header).replace('\\', '/') + '"'
                        for macro, header in zip(macros, headers)]
        consumer_plan.update(command=command, actual_headers=[n.ident(x) for x in headers],
                             actual_manifests=[n.ident(x) for x in manifests])
        emit_cmd(HERE / 'compile-consumer.cmd', [dict(name='flash-state', command=command)])
    (HERE / 'consumer-plan.json').write_text(json.dumps(consumer_plan, indent=2) + '\n', encoding='utf-8')
    if args.consumer_record:
        assert available, 'All three actual pin headers are required'
        consumer_record = n.read(args.consumer_record)
        assert consumer_record['source']['path'].lower() == str(source).lower()
        for value in [consumer_record['source'], consumer_record['object'], *consumer_record['dependencies']]:
            assert n.ident(Path(value['path'])) == value
        dep_paths = {x['path'].lower() for x in consumer_record['dependencies']}
        assert all(str(x).lower() in dep_paths for x in headers)
        consumer_obj = Path(consumer_record['object']['path'])
    removed, retained, unresolved = [], [], []
    command = [base['command'][0], '/NOLOGO', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE',
               '/INCREMENTAL:NO', '/OPT:REF', '/OPT:ICF', '/NODEFAULTLIB:LIBCMT', str(consumer_obj)]
    command += list(dict.fromkeys(source_to_fresh.values()))
    command += [str(GDN / 'native1/cpu-baseline.obj'), str(GDN / 'native1/cuda-gated-delta.obj')]
    for value in base['command'][1:]:
        upper = value.upper()
        if upper.startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:', '/SUBSYSTEM:', '/NOLOGO', '/MACHINE:', '/INCREMENTAL:', '/OPT:', '/NODEFAULTLIB:')):
            continue
        path = Path(value)
        if value.lower().endswith('.lib') and path.name.startswith(('hyle_compute', 'hyle_graph')):
            removed.append(dict(path=value, reason='fresh whole HYLE owner module; no old provider17/archive fallback'))
            continue
        if value.lower().endswith('.obj'):
            found = old_records.get(value.lower())
            if found:
                recipe, record = found
                source_path = record['source']['path']
                if str(source_path).lower() in source_to_fresh or str(source_path).lower().startswith(str(ROOT / 'tests').lower()):
                    removed.append(dict(path=value, source=source_path, reason='fresh owner or excluded old test TU'))
                    continue
                if Path(source_path).suffix == '.cu':
                    if Path(source_path).name == 'gated_delta_net.cu':
                        removed.append(dict(path=value, reason='fresh same-owning-overlay GDN TU'))
                        continue
                elif Path(source_path).parent.name not in {'mem', 'mem_vm', 'io_core', 'compute_stream', 'compute_stream_cuda'}:
                    unresolved.append(dict(path=value, source=source_path))
                    continue
            elif path.name in {'native-baseline.obj', 'graph.obj', 'sampling.obj', 'candidate.obj'}:
                removed.append(dict(path=value, reason='fresh native/schema owner or unnecessary old blocking-pool override'))
                continue
            elif not ('.cu.obj' in value or any(t in path.name for t in [
                    'native-batch-portable', 'native-cache-portable', 'native-attention-portable',
                    'native_cache_encoder.', 'concat_kernel.', 'sampling_kernel.', 'guard.obj',
                    'native_highdim.obj', 'row-codec.obj', 'ggml-alloc.obj'])):
                unresolved.append(dict(path=value, source='unclassified old object'))
                continue
        command.append(value)
        if path.is_file():
            retained.append(n.ident(path))
    assert not unresolved, unresolved
    # These three kernel-only owners are not explicit in the old command:
    # they came from old backend archives, now entirely replaced by fresh hosts.
    kernels = [ROOT / '.scratch/build-compute-v2-dev/src/compute_backend_cuda/CMakeFiles/hyle_compute_backend_cuda.dir/device_status_kernel.cu.obj']
    for path in kernels:
        assert path.is_file()
        if str(path) not in command:
            command.append(str(path)); retained.append(n.ident(path))
    out = HERE / 'tests-link1'
    out.mkdir(exist_ok=True)
    command += ['/OUT:' + str(out / 'glm-flash-checks.exe'), '/MAP:' + str(out / 'glm-flash-checks.map'),
                '/IMPLIB:' + str(out / 'glm-flash-checks.lib')]
    plan = dict(command=command, base=n.ident(p.BASE), fresh_graph_host_commands=n.ident(HERE / 'host-commands.json'),
                fresh_support_commands=n.ident(HERE / 'support-commands.json'), reused_current_records=[n.ident(x) for x in reused],
                removed_inputs=removed, retained_inputs=retained, pending_consumer=args.consumer_record is None,
                consumer_record=n.ident(args.consumer_record) if args.consumer_record else None,
                sdk_builds=0, nvcc_builds=0, executed=False,
                runtime_avx2_dll=n.ident(GDN / 'native1/hyle_ggml_cpu_gdn_scale_v3.dll'),
                runtime_rule='Hardlink actual required cached DLLs; replace old AVX2 CPU program DLL with the v3 DLL next to this image. Never copy SDK contents.')
    (HERE / 'link-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
    rsp = HERE / 'link-flash.rsp'
    rsp.write_text('\r\n'.join(subprocess.list2cmdline([x]) for x in command[1:]) + '\r\n', encoding='utf-8')
    vcvars = Path(command[0]).parents[6] / 'Auxiliary/Build/vcvars64.bat'
    (HERE / 'link-flash.cmd').write_text('\r\n'.join(['@echo off',
        'call ' + subprocess.list2cmdline([str(vcvars)]), 'if errorlevel 1 exit /b %errorlevel%',
        'cd /d ' + subprocess.list2cmdline([str(ROOT)]), subprocess.list2cmdline([command[0], '@' + str(rsp)]),
        'exit /b %errorlevel%']) + '\r\n', encoding='utf-8')
    print('PREPARED support3 + link', len(command), 'args; consumer ready:', available,
          '; actual consumer record:', args.consumer_record is not None, '; no build/native/HTTP')


if __name__ == '__main__':
    main()
