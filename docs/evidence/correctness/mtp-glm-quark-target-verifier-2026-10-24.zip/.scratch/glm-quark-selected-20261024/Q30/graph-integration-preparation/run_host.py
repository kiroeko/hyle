"""Build the affected current Graph/default-provider host closure, serially."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[3]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
h=module('mtp_graph_build_env',R/'.scratch/native-paged-effects-20261022/build_windows.py')
q=module('mtp_graph_execute',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
def identity(path):
    raw=Path(path).read_bytes()
    return dict(path=str(Path(path)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
p=argparse.ArgumentParser();p.add_argument('--kind',choices=('host','support','consumer'),default='host');p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
path=S/('consumer-plan.json' if a.kind=='consumer' else a.kind+'-commands.json')
plan=json.loads(path.read_text(encoding='utf-8-sig'))
if a.kind=='consumer':
    assert plan['ready']
    for item in (*plan['actual_headers'],*plan['actual_manifests']):assert identity(item['path'])==item
    plan={'jobs':[dict(plan,name='flash-state')]}
assert len(plan['jobs'])=={'host':84,'support':3,'consumer':1}[a.kind]
for job in plan['jobs']:
    assert identity(job['source']['path'])==job['source']
    assert identity(job['recipe']['path'])==job['recipe']
    name=job['name'] if a.attempt==1 else job['name']+f'-attempt{a.attempt}'
    out=S/(a.kind+'1')/'records'/name;assert not out.exists()
    out.mkdir(parents=True);(out/'tmp').mkdir()
    (out/'plan.json').write_text(json.dumps(dict(job=job,source_plan=identity(path)),indent=2)+'\n',encoding='utf-8')
    env,_=h.b.environment(job['command'],[],out);env.update(TEMP=str(out/'tmp'),TMP=str(out/'tmp'))
    result=q.execute(job['command'],env,out/'run',timeout=1800)
    if result['exit'] or result['timed_out']:raise SystemExit(result['exit'] or 1)
    command=job['command'];deps=Path(command[command.index('/sourceDependencies')+1])
    data=json.loads(deps.read_text(encoding='utf-8-sig'))['Data']
    dependencies=[identity(name) for name in dict.fromkeys([data['Source'],*data['Includes']])]
    target=Path(next(arg[3:] for arg in command if arg.lower().startswith('/fo')))
    assert identity(job['source']['path'])==job['source']
    (out/'identity.json').write_text(json.dumps(dict(source=job['source'],object=identity(target),
        command=command,dependencies=dependencies,recipe=job['recipe']),indent=2)+'\n',encoding='utf-8')
    print('COMPILED Graph host',job['name'],flush=True)
