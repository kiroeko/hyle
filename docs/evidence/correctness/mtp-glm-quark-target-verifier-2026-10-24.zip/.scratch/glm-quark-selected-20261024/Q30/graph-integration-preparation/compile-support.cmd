@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
cd /d C:\public\project-hyle\hyle
rem graph_progress--progress
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_progress--progress.rsp
if errorlevel 1 exit /b %errorlevel%
rem graph_route_cpu_cuda--compile
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\graph_route_cpu_cuda--compile.rsp
if errorlevel 1 exit /b %errorlevel%
rem compute_state--state_versions
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\compute_state--state_versions.rsp
if errorlevel 1 exit /b %errorlevel%
