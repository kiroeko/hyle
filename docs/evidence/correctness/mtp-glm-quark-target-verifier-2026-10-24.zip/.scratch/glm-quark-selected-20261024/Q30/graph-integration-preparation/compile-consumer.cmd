@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
cd /d C:\public\project-hyle\hyle
rem flash-state
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.50.35717\bin\Hostx64\x64\cl.exe" @C:\public\project-hyle\hyle\.scratch\glm-quark-selected-20261024\Q30\graph-integration-preparation\flash-state.rsp
if errorlevel 1 exit /b %errorlevel%
