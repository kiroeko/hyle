#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_212 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="4522659b34a2db88695b013b67948a9c12c55ed83fdcde136699b30a65632afb";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.212.down_proj.weight","down.weight.e4m3","82cbde657d49adc885e3e1700d3c3a8cff43f5c08133e95de18a70d37217c3d0","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.212.down_proj.weight_scale","down.weight_scale.f32","c059ea66ddf2528e050a64e63b384e90e4a733894daedbdd64bd2f774fbe781c","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.212.gate_proj.weight","gate.weight.e4m3","04be0cdd27acba3ac5adc6e7f2990a7b384ecef5833a28dcb33966b94ecc4adb","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.212.gate_proj.weight_scale","gate.weight_scale.f32","8ebf20b5e2507065e8b464c23d9dee5d2de8778ac929cf0ff4fb69ab07dcc879","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.212.up_proj.weight","up.weight.e4m3","85794118b585698dbfd52a34890cb95b235c3a343e72a6381011b36181dc70b0","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.212.up_proj.weight_scale","up.weight_scale.f32","21568e9ba49ab46b8dbef43c7f97600bca1cf91fa13b1c876d2b074a4659b84b","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_212
