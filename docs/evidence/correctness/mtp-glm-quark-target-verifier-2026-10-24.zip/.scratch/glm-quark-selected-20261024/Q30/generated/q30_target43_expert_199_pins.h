#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_199 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="9f13cd390db9db683f6ece448f0e8471e0306fcc5652af2681dc42512560f494";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.199.gate_proj.weight","gate.weight.mxfp4","650e37e3c24b9dc6b7107c220a87b513b7aef16ca32f59c692bb59bbadbe191a","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.199.gate_proj.weight_scale","gate.weight_scale.ue8","07b6de815f0570aea578e4204ae58f74f4c2131c7278cddec72102e9df579871","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.199.up_proj.weight","up.weight.mxfp4","0dcc87b5b3861d1cc6e248ba6810fa9f83af298b834ea1b155295f3bfecf3604","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.199.up_proj.weight_scale","up.weight_scale.ue8","4276690d158cf6c8229218518a48425a7daec5bb2fa7bfe6b681e82cc2a7739b","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.199.down_proj.weight","down.weight.mxfp4","20adecfb6f41da3f399abda09cd98ad000bdee6ebed4661afd42f157ee28ab4e","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.199.down_proj.weight_scale","down.weight_scale.ue8","15f0c3637176c0f8309276d421364866a3a0070b06b694d2f499bf9b5ed48d6c","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_199
