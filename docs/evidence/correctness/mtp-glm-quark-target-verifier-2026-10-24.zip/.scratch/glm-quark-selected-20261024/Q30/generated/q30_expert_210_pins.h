#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_210 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="0292ff8255f35a324633989ed9a3e1cf49e0020dcef9da44b0a62782ec69ba07";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.210.down_proj.weight","down.weight.e4m3","facb2820bd1ed7c6e0d1d3886ae0e81d9d74335a27f5e6f39eabdee9d36deff3","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.210.down_proj.weight_scale","down.weight_scale.f32","dbef5ef356140dc89c90fed2b68850008a34fd961e6fc3eec19c615e33f37dec","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.210.gate_proj.weight","gate.weight.e4m3","604b10103a60cd2defc58349132d49173c9dc9a0b5990e04c8a97aec8b87f79c","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.210.gate_proj.weight_scale","gate.weight_scale.f32","f57aaa7b9c7186472464475e948aa00b962e63985817f5684f4f3b7afbc84e07","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.210.up_proj.weight","up.weight.e4m3","f4b44e4bdd5c8246078dd9aa738cc7f247c15da66740ed414db2f9cda2fcedab","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.210.up_proj.weight_scale","up.weight_scale.f32","cea65817319ab3694868f244ec0873045e5b42beee086d2e53b4940b91cb9b92","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_210
