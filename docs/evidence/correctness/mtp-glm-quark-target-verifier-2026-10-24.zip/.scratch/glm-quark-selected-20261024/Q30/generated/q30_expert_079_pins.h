#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_079 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="56d88545c755aee76d75c146e807c9dd5217745c65e419a73216fa2101dc0e6f";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.79.down_proj.weight","down.weight.e4m3","da6f924cb1a69d9c0e561bc2b49d285db23387f7d8a7351bcb495b83885cbba6","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.79.down_proj.weight_scale","down.weight_scale.f32","db5434e3dc94aebf8b21f6f5900ed407ec761b797590a55c50fdec1c2c1874d4","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.79.gate_proj.weight","gate.weight.e4m3","43e4e6daa0b394a3ae6947b71831bbb07386e9dc13767476da801865bb9a61cd","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.79.gate_proj.weight_scale","gate.weight_scale.f32","d2fdf3d284cde682c437af63b91b26597705bd906a98c46e5bc829ef8b69e2ed","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.79.up_proj.weight","up.weight.e4m3","fffa578c9c64e8b7f3de44be81da661192339dcfd2819ad6c5f6490f9815e49c","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.79.up_proj.weight_scale","up.weight_scale.f32","4bb9f1b031b07647ba10bc0cac9ffd6b363974b332cc023ab82a50025d8174f7","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_079
