#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_173 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="4ea15d6509deb6864d13d1cef63b6acb6ff0340a9382fb52dd0e51fd00753fa5";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.173.down_proj.weight","down.weight.e4m3","f1388248761759ccf3156baa31f03ea4ff805d28e9e838eef8f884208b63df00","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.173.down_proj.weight_scale","down.weight_scale.f32","a3f976a5bb957a2abf2708c9b2baac8b682f913a8b76575b44f28883f4e674e2","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.173.gate_proj.weight","gate.weight.e4m3","7c06f0ce741491d331717150951b15ac998852c42629011cb26ef43d0b470cfa","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.173.gate_proj.weight_scale","gate.weight_scale.f32","1e9bd9b71ac9ee837bd96613486097cc59eddfc4ddd33833d846137ae96427a2","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.173.up_proj.weight","up.weight.e4m3","63c6f4c5086c12713616cb00937cfa0c575d1dbada2d09ce43aecd1467fb36b6","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.173.up_proj.weight_scale","up.weight_scale.f32","327133a9cff516b8530586f06bb4e4c3c9b8175cdbc11de3dfcdad5472b0ca94","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_173
