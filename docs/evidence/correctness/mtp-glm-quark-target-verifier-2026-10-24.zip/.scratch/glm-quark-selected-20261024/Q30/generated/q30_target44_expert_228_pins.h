#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_228 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d697f861478e09a660919ab5e4c76612882a0e72810022c35683b93e7c090042";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.228.gate_proj.weight","gate.weight.mxfp4","94d3bcf700df057a2a7aef1d9482fd28e0b99d2d7d6711e597e4c25321d992db","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.228.gate_proj.weight_scale","gate.weight_scale.ue8","bc7d56b976112bef03b912a3973ef1dd9274be0049dbeb5987af77a4c05fdae6","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.228.up_proj.weight","up.weight.mxfp4","5220f7912d01b321a9810af56a2c9047d3bbfe1fc8968b2ba4303effabc5f74b","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.228.up_proj.weight_scale","up.weight_scale.ue8","60d96af2cb25db9564be39ec828d091941ad2e51e5844b4647ecc7a263b273c7","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.228.down_proj.weight","down.weight.mxfp4","b946b710c1418715cb56a7173d2785a4574c0e2c768562143f039f6b9670ffea","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.228.down_proj.weight_scale","down.weight_scale.ue8","b199eb279ed12848aab3f75f6f6c3b8818436c55921006fb65589e6c8ede88ee","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_228
