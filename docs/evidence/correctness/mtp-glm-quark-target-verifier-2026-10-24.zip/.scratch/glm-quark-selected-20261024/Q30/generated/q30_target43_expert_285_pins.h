#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_285 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="3112ec834d634e8421a28eb51e6bd4efc64b2634322144a5a2795c56b5ef3227";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.285.gate_proj.weight","gate.weight.mxfp4","207665019cca6191b4e7e3a4ee776f498efdc0b86c51d550e0170ddb55d9a414","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.285.gate_proj.weight_scale","gate.weight_scale.ue8","a1f53361e46a0b32b57471ff48ebf7ea84963613f3744c0a41cd9c2b5f45d7cf","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.285.up_proj.weight","up.weight.mxfp4","97de6aebd61ad30dda724f21d60a6d69e6ae1de1a5cc3ebff7d3f8060d26d8aa","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.285.up_proj.weight_scale","up.weight_scale.ue8","3a405303be6a4286e9b586f38359b464ea1837540e7c7d6214c468d2a12c5aa9","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.285.down_proj.weight","down.weight.mxfp4","772480adaf5a1b67036dc0ba03b9d331e83373de9fd51f1d3fa211c82212444d","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.285.down_proj.weight_scale","down.weight_scale.ue8","b3dc94a9ede7e6e4afb8c684d3e4556039513dbd3dad4ca8748c92b56245a30d","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_285
