#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_091 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="3ce96034cb044031e41fd130a800723cff8312bb6d9770ae5a890b84fe4e5013";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.91.gate_proj.weight","gate.weight.mxfp4","56bd9a90411ea75364a21d9e69aae01659dc3065b65c5527e4bee9862d601795","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.91.gate_proj.weight_scale","gate.weight_scale.ue8","30bfcff33601a77608c8eddb45a2a2f8d740d52ff50aac254d2a80f9a71d5689","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.91.up_proj.weight","up.weight.mxfp4","70ff1eec30d69bf77ba308476cc74dd525ef4c4ae8cffb58ddb981fc09b9b4f7","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.91.up_proj.weight_scale","up.weight_scale.ue8","de5abfba8343ff9c85792d9c46ad54abffedd92ac1c3747e0ba6bc2298328eed","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.91.down_proj.weight","down.weight.mxfp4","8f82201e681454c328941e5ed338c207231925c285a78e27dee97fc3c0337c5b","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.91.down_proj.weight_scale","down.weight_scale.ue8","89b7ebb6b5b697cff447d3376e3d5ca880fbcbbe202345d4f837e78a349aae93","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_091
