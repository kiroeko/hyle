#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_003 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="ac3d58fcbbe6241534006ec3624e87c225af9f257c486a49202bddd6d6750b32";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.3.down_proj.weight","down.weight.e4m3","4a3d814771f8849747d1291baac27312384270a6f2dd506b76c73f891a25a0f7","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.3.down_proj.weight_scale","down.weight_scale.f32","7ea382ab8363d5915a70c5a50451fbe5bc5e0cd6ad7a14cac951676a24afa7b0","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.3.gate_proj.weight","gate.weight.e4m3","ce14134d8b723daff6837f6fce9c45729f582a1b3b98d925991201cff5ebf678","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.3.gate_proj.weight_scale","gate.weight_scale.f32","497030d93a730096798d88a6e50b178684262c5be5ddab451dadf273b3c4e4e5","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.3.up_proj.weight","up.weight.e4m3","d73dbf1e93c6c0af8aabd00b11818b91a0556566ac8bf31a752cb5c66ff53b3e","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.3.up_proj.weight_scale","up.weight_scale.f32","8f5da4a17d3492da80f4137f88f1c5c5ff1137699a224fff58b26577a4483149","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_003
