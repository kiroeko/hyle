#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_057 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="1f8bf84fd1acef05996a05ae1c34a06b8a2d09fdc7dfb863f891c2d2209549b3";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.57.gate_proj.weight","gate.weight.mxfp4","fca2a18e9c4d4af33bebd7b2219fa3595689129ba115eac4d60f9912bbd38331","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.57.gate_proj.weight_scale","gate.weight_scale.ue8","72341036ec81331bf8017eabc59eeb042d9205c180d660a59ae276f7dbced2fb","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.57.up_proj.weight","up.weight.mxfp4","3da60fbf27e91b86969032206637337287b2b399998277bd65530fe40489c152","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.57.up_proj.weight_scale","up.weight_scale.ue8","d9a936377bd220a6da2892b5656674c97e9c5eb967619b35e531d3ba07b912e4","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.57.down_proj.weight","down.weight.mxfp4","23d9d8fa6b2141ed81442b7c4a875f82c778242839d6690245a4358de3cce28a","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.57.down_proj.weight_scale","down.weight_scale.ue8","29b6c3be19df76e33f87d50ce11791ab0ee4f47778c09bda91c6766c5d2cf164","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_057
