#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_132 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="a9bfdc44cfa645cf600bc19abb41bf33f2fe25417085862cd625945d0453b8b1";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.132.down_proj.weight","down.weight.e4m3","959e8fff360e0a04590ee3c02f14692d890362957016e9cfaee45d6e387362f9","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.132.down_proj.weight_scale","down.weight_scale.f32","500acbae37e16e9cc6c33a173c12ab2f84d3c9f0074543113970bdbd6f3d4a73","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.132.gate_proj.weight","gate.weight.e4m3","40eb2a19ef422d56121f89cbf1ba50352901413d5c9610a0f3d45e780ff73054","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.132.gate_proj.weight_scale","gate.weight_scale.f32","e37345c9f788450ee57d2b689bc8843273281d0142ee8990b98fdd9453265d7f","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.132.up_proj.weight","up.weight.e4m3","df4d0098a642f04ae020784b136da8a4dfbd72b365ca354d3dafc3da35be1936","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.132.up_proj.weight_scale","up.weight_scale.f32","021c79e147ca1dda7fc4aec013d7e52baad4a63c59046e9c94f6ae4ff0ec86a3","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_132
