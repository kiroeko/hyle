#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_181 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="e6095baf38626c4c60b7a7b10fb9a2fa81b93c616217ac03d10a7c964853bf4a";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.181.gate_proj.weight","gate.weight.mxfp4","1b3970774e53552660824b90ad697a96c864231d41088e75a3e4dbd95435859c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.181.gate_proj.weight_scale","gate.weight_scale.ue8","0b24f6eec7effe90f93e64821aec32442708b015840d905e2958c3d3072e91df","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.181.up_proj.weight","up.weight.mxfp4","b275dbe526ed935841f3e705830434f3c405317ae6e71e50177387187e3f88d4","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.181.up_proj.weight_scale","up.weight_scale.ue8","6acbabc669997c714006925855f6cefe5ea4197b219f36d5d773cb515c31625f","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.181.down_proj.weight","down.weight.mxfp4","c100e6059266a767c3c64779a2a3943891757dd36b30abcd488e28392f45aec8","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.181.down_proj.weight_scale","down.weight_scale.ue8","f9e6aca242e4a0581ff7ae213c8f7bd3ac11434cb66aa026de3552c5c92911af","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_181
