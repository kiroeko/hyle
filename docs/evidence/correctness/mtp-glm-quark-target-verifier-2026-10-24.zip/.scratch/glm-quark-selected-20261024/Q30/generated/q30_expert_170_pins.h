#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_170 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="e1aa458696b141613a94c4ea45eca24090cbee2775c9f0ce12eca099040a730c";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.170.down_proj.weight","down.weight.e4m3","ebf554bd1932bf98fa26df651fd0fdc3040cfc4c6df3caa043ee1b19b10949e9","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.170.down_proj.weight_scale","down.weight_scale.f32","5c78048c28893b1f0a47240bde4d260f6b1b7986b13ae7fd45f728b893ee603e","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.170.gate_proj.weight","gate.weight.e4m3","da15deea9382805be753722721684847327a391ad3ccf8a97370ce02dcc49bca","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.170.gate_proj.weight_scale","gate.weight_scale.f32","d9561cb6f9e59fd8cdd8ac9d832245390479b9422450ff1f27283c1a6831cee7","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.170.up_proj.weight","up.weight.e4m3","69d1a7f7ce44988772a493b645b0960e26805f3b6015a2279ce64a286a3ea21d","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.170.up_proj.weight_scale","up.weight_scale.f32","eb614441e11ac12cf4c1d97e1028154a2c62e091ded16f768b3d9b6d895d2627","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_170
