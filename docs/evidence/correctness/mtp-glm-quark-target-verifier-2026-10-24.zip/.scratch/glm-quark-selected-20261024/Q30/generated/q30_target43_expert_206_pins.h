#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_206 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="b6b24c9232f23e18eea185a0e4b5db3893d82dad1df98138d33d21f301cdf068";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.206.gate_proj.weight","gate.weight.mxfp4","16f1cf8de5ad5e8ded9c70d459b2a12d9d1d3b25e5b1663b9cfbec26eab6814a","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.206.gate_proj.weight_scale","gate.weight_scale.ue8","98516f0532ee09f93c1f41c42f38886c325179ef83ab1f09f10b8e44f04086c9","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.206.up_proj.weight","up.weight.mxfp4","7acfd4420575b2e4814f6b1d04d6b0211a9ed1016ebb58a3af9b7a56d1e8c914","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.206.up_proj.weight_scale","up.weight_scale.ue8","62ed80a773873f97c9919c98c3c48a93dbd805832e50b3e5030b0dd0937947c1","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.206.down_proj.weight","down.weight.mxfp4","22ad195a6cc297ea7e069baac18165581497fbe4a6334ca748cd91f2ac4eed0f","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.206.down_proj.weight_scale","down.weight_scale.ue8","58f754535ae108e32e501f36f9cc10d2e1e713534c49f312a71e00082c37c055","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_206
