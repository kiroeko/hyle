#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_277 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="9f68c7ca24b3a0565ee981dad18dee8e8cd9799726c9bc9429c043525af52cbb";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.277.down_proj.weight","down.weight.e4m3","826dbe91bc3c0b39793f059bedaea6ed1adf09ce5570f202488e213420d30beb","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.277.down_proj.weight_scale","down.weight_scale.f32","867cea2479b9f7d3561ff2377768f76d060617fe2584bc849c74c7ec97222c44","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.277.gate_proj.weight","gate.weight.e4m3","69f8eaf43b51717118262745ff6b05621128298f159a08bce90e40d6dd1d0e86","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.277.gate_proj.weight_scale","gate.weight_scale.f32","2a0cd96dfdca2a6cc08df4b37a826917f04ab888f7f1663211eb4f3e51b0b0b6","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.277.up_proj.weight","up.weight.e4m3","4eb00a339cd1e350cee7e9b231c30db83533cba1a0a3883b34eaf1fe755ebafa","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.277.up_proj.weight_scale","up.weight_scale.f32","1a289f9723647777059fec442f91622b3d16843b2b7db6733585718e248cec7f","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_277
