#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_178 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="a86528cc672c833c337f75c0f2da950b4fa0ceebb91a6010e0ed59fa04ede167";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.178.gate_proj.weight","gate.weight.mxfp4","4bd441ec2482e274965b09446bb2bab61e6b8552fc349f05c0f72ac681485b2c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.178.gate_proj.weight_scale","gate.weight_scale.ue8","20512df1185741ee87b1e653d0546533f0b62c5f7504a28181c481a69b52abd6","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.178.up_proj.weight","up.weight.mxfp4","321e372e2a3d311779b5560b032f5b2127c9706129e8d4f392b1494cab2d8108","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.178.up_proj.weight_scale","up.weight_scale.ue8","5ae2dd294c6d3ad0c6b48f304bf1683cf86176fd85d48467561b87ffe0071d7b","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.178.down_proj.weight","down.weight.mxfp4","53641cc862262e7c88a76c23eb3d89fdeec6d165e494e6a872a4e837423ee7b0","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.178.down_proj.weight_scale","down.weight_scale.ue8","83fa064404c0e06f53d478b8b25e56ac062c578e6d40e0dd848bd355273d73c6","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_178
