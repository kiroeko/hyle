#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_164 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="509d7098116b4752411791faa35b7288c5968874fa8e074b6a55809ecf6ea778";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.164.gate_proj.weight","gate.weight.mxfp4","cff8d7428f85569c8eeed4f0ac9f254e01353f22b83082208cc182205ec2b825","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.164.gate_proj.weight_scale","gate.weight_scale.ue8","40d85b26ee4cef433f519d28efd5fa61b9dfc368dd5291d2a7f2a2efaec4443b","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.164.up_proj.weight","up.weight.mxfp4","fcd51b04c1d9d3501993549a81be85e78aa71e0347164f7f05cfd6c2d5dc6258","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.164.up_proj.weight_scale","up.weight_scale.ue8","e6c1110656adf3e4fd795e1554cd0ca5d495e234cca875742c86643854f0168d","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.164.down_proj.weight","down.weight.mxfp4","f8896f697648c986d5add927910bfac6acbc847caecf7f5754cddb079653e041","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.164.down_proj.weight_scale","down.weight_scale.ue8","4adb41725d2fb7561226c3f965099d3dec66bc5883c6484ad9b0fc8ad435274f","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_164
