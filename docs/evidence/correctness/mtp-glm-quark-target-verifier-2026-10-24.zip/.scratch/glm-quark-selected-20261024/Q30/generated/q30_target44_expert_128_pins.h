#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_128 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="8ec9f31063e0f9729147243f762b5f5dc0d044fc102333585bcdd8adef74e9cb";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.128.gate_proj.weight","gate.weight.mxfp4","cfc79b680770958bc3c4dffbf1d6b1ef652d6483b949e0ff75f58ce8fb601033","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.128.gate_proj.weight_scale","gate.weight_scale.ue8","74beba3a0918f1a1f6451095f7f5a663d040baf5f3d3e9f5ae63f2c0fae368ae","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.128.up_proj.weight","up.weight.mxfp4","62db3d63615dd939f061dea448782a092f114011e2961939f26fc67c256dc562","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.128.up_proj.weight_scale","up.weight_scale.ue8","ce98ca92b09c9a302004acb9db5b9300ad2b643954d1a51db3b4caaeb32cf576","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.128.down_proj.weight","down.weight.mxfp4","3fbc366f366e60ab0e16d0c4f000248b3854f8fed7ac5962873c14d37074cf9c","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.128.down_proj.weight_scale","down.weight_scale.ue8","202b939608d87a9992442d5d1fa7da6af44e400ebb2dd43324c83135791192f3","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_128
