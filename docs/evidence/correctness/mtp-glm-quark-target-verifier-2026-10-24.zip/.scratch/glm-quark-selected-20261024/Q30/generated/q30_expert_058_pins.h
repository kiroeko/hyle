#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_058 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="36517482aa605b4bdcc2342708a79c9e2539f79e395a37780a271c00f5cd7afb";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.58.down_proj.weight","down.weight.e4m3","34b264d1c5266345d5cbd1fd536a7d6d9bf1b4e441bbee9a6f68fa5436f3e127","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.58.down_proj.weight_scale","down.weight_scale.f32","9375e0e8be4313d91fdc45c64ff34c3321816817a819ddbb683d469e37ba1bcf","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.58.gate_proj.weight","gate.weight.e4m3","8f430a89f87e82e2285502cd639c9c81100bc1b7c1145dcd91735ea702010ea0","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.58.gate_proj.weight_scale","gate.weight_scale.f32","780a5038309a24b45e7a9b4fbaab8428f4f36ffd38b591ea0b2aba0b7f2b9c25","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.58.up_proj.weight","up.weight.e4m3","4d4e76fa8e87b3418cc097a16291ebf5651541438fdbade3041551014c8a902f","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.58.up_proj.weight_scale","up.weight_scale.f32","1eb45a2f2f6848cafc3b4615e47e60fdb348f971914cefcd2a9fd5f88ce0f293","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_058
