#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_192 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="056c3187aaf1d6b1149461c545488691ea38c72d39f37e657a31ad619905aaee";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.192.gate_proj.weight","gate.weight.mxfp4","108ea4d556c4d0fc77a3d033d212baadc4287fd3c34670efd9d56ebcafa95501","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.192.gate_proj.weight_scale","gate.weight_scale.ue8","39bb010a3bcf3fa1e9d2cc13f563c4736ec4253d6384bca4822122840d79dba3","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.192.up_proj.weight","up.weight.mxfp4","ebae1a89993cfbcd0fb82d04fde32d23faa5ce930a243e4449f39b93228aae40","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.192.up_proj.weight_scale","up.weight_scale.ue8","b5abbf44589ac61bb3e16758e8acc5df9efbf775f8bb46dcca64c6d8cbf96b44","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.192.down_proj.weight","down.weight.mxfp4","e34ad0717c0e944670f69a1c4506b580ef6e7cf27d475b2ecfc3ccf6e0353a2e","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.192.down_proj.weight_scale","down.weight_scale.ue8","d38b12305f6c92d00dc06b60eb90071ba09d6beb554c8acaa1f73550c8dc3e76","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_192
