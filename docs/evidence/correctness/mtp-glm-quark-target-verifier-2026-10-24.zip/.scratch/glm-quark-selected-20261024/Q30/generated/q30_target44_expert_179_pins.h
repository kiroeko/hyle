#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_179 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="75b676f694ccda41b9d46053774e5867a4ec8bccff21c12ad297e0f677afe05f";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.179.gate_proj.weight","gate.weight.mxfp4","07978f1106665e8313b40454b4ddcbbd2a838827ca6551860b5077aef4c88819","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.179.gate_proj.weight_scale","gate.weight_scale.ue8","0559818b45b7677d92cb53c4d5d632c5cc5417ba6b9e34263ed646d55f519f89","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.179.up_proj.weight","up.weight.mxfp4","5cd97efe0e33a3a53bf9fa7054c64791a1acf38db427276c91903c3ad06a0343","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.179.up_proj.weight_scale","up.weight_scale.ue8","a001d8fc6d86c2b02f68e5d19981ba84d02956eed8921e5aaefd6836ef11e8a6","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.179.down_proj.weight","down.weight.mxfp4","32a22f3515b98e6cde376add90ec313abb498e51aba622dcf327a73ad86d31fc","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.179.down_proj.weight_scale","down.weight_scale.ue8","d8a0a576d5efd36ab1d4d89ec1ab266da6b00c264655fb6cc507d6a4fb4ac9b3","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_179
