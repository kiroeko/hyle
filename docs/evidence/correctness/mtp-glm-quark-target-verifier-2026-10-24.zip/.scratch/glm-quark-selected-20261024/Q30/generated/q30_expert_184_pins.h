#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_184 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="f840b1921fb2eb32e3f439f133cedee89e14c52ee9716a113bb849218a07a13b";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.184.down_proj.weight","down.weight.e4m3","c564416544b1af916f3aba1480c0a393b87a19922fc3aba4e417f66c3eb1227d","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.184.down_proj.weight_scale","down.weight_scale.f32","d0017f5e10c2cb4343e3709594508e63c9f3bcfcc277e44222eceed226109fc7","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.184.gate_proj.weight","gate.weight.e4m3","c506328c57f80c4751f192329156d79f530270f1385a128d90b88a16944642c5","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.184.gate_proj.weight_scale","gate.weight_scale.f32","e681ccd1529ebdbe06cdb08d4def083a4817c216824df096ee65b6936ed8316e","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.184.up_proj.weight","up.weight.e4m3","69dd2b3e195792f016f8c1c84de67522fc400eaed9188108fa4d2f87e17259c3","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.184.up_proj.weight_scale","up.weight_scale.f32","e2952b95d4efc2c1a5efb442514eba68654da8b3d1532dda39509a31a95dab80","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_184
