#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_168 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="3399e2357413a9b1456fc168818c12564cc06aee661f320238609c65574f7067";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.168.down_proj.weight","down.weight.e4m3","5fbcfe63433437da3f27d93e3efcb08ac8ef94090750a2ba80bfacb98a2f0248","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.168.down_proj.weight_scale","down.weight_scale.f32","3c12d7540edecc0a3d644dbe00dd543db7d3de2e8e94081b9706344cb3dbb806","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.168.gate_proj.weight","gate.weight.e4m3","ce9dfdbf2f7722522e8a5a5425dfa4c29c3c8ceae0fc022750dd7ef7ada289d0","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.168.gate_proj.weight_scale","gate.weight_scale.f32","0d94f59033291dae3e7087acda8ff96b29a54190aec0b184300a647b9f03e8ff","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.168.up_proj.weight","up.weight.e4m3","b8fad1a2d639a9e3e2410d4a28d1885e06d2d3ccd32b8b2cc8b6d3da8e3091b8","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.168.up_proj.weight_scale","up.weight_scale.f32","78f9c93387de9388f94cff95e218a934c5e591f8ae055c0f42dd507053cf9fc8","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_168
