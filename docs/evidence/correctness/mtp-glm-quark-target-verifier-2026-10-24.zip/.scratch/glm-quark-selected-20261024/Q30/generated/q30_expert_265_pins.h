#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_265 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="43cbed5318fe05339cefa751a62d41b2257c829714616c0ca1069bc56bfe3739";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.265.down_proj.weight","down.weight.e4m3","fe5ddbfc73b16945b11eda69fa9c6c72c60ab76414291b79e86b3efa6be5b289","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.265.down_proj.weight_scale","down.weight_scale.f32","30a424cb4c3c758a383a8d844b465b984ca0536d8f1d6db9c4c79e967132f37b","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.265.gate_proj.weight","gate.weight.e4m3","5a3d29d1f3ea4c526375ab74f6a43d5e1444a736f4b2b5de785725728b1f8d29","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.265.gate_proj.weight_scale","gate.weight_scale.f32","e9ec079fa246333ae3ef1bfea3ae2d4b459a2ef4e73d06f45bb87ac802a93c67","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.265.up_proj.weight","up.weight.e4m3","2304fcea3c2223eb1a922f4a4c60503e2dc3740ac1a62726e4063ee1e376a050","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.265.up_proj.weight_scale","up.weight_scale.f32","20238198a88208b0fa5fbd2aff248a8cff7621350f3b867edd31112f941baf46","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_265
