#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_187 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="5d36cf6686ae06d3d5e495ff567771ef32b021ebec3a9aa6c77481639a3851bc";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.187.gate_proj.weight","gate.weight.mxfp4","91a8171f82193c9382e391a8fc24bc2f8a4781f4840a250cf23a9779c6ebed7c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.187.gate_proj.weight_scale","gate.weight_scale.ue8","0511cd977a1714c51172468a196064ae95eeb915217d753db4bdb32dde40b2d9","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.187.up_proj.weight","up.weight.mxfp4","93453fa70823834b3c9aa478f25a823b0dba56d36549a3a7359e8dea58cec8c7","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.187.up_proj.weight_scale","up.weight_scale.ue8","160ee6cffa6128ea1dfaf9b38f3c96896f7e64c5f022b775425eee6a62e5d847","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.187.down_proj.weight","down.weight.mxfp4","02aedc80267d81a796cca75b602478192c175d52a704370351c8661757dfe1e9","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.187.down_proj.weight_scale","down.weight_scale.ue8","f403d977be47ca0960d84429fee96f1cd6f508377b295c70cd8256f863c8e7e3","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_187
