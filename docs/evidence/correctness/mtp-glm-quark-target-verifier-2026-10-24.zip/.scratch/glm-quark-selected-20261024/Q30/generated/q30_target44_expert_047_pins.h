#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_047 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="ef5b8dcb8dfec5f827b484946d41620ad76193bd5a17c93e1384fe0d404d6f2f";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.47.gate_proj.weight","gate.weight.mxfp4","e16d825e4c80699121e9da218f5b1da014c42cf1754b005be3bfb14fcc2c48de","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.47.gate_proj.weight_scale","gate.weight_scale.ue8","eec3e538ad2f9eb2a8e5827e91034d82e566b83903ea0cf3acf85afc3455cd8c","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.47.up_proj.weight","up.weight.mxfp4","9449af4c8f319e7f9d47ed35a129f96d2f6cfd1e367d7752cc9a682504bb5fac","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.47.up_proj.weight_scale","up.weight_scale.ue8","92717399487fc701fc909d0377aba3a5b319961d0b1b21c24a4f76f9dd2421d0","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.47.down_proj.weight","down.weight.mxfp4","b8f4fb4aa77cd912c96573df4e2825db4f1377be573074f122dd7b1fcdb52ab3","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.47.down_proj.weight_scale","down.weight_scale.ue8","5dfdd3cf13fdf65036d74309d296afa8423dc834ccefe65815d3360eafd69947","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_047
