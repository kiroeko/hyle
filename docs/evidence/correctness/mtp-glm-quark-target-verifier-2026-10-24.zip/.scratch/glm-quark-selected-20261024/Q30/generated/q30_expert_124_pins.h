#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_124 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="4d1422c0abc46e475d5585a5c9a0ace6cd1d349b86e02ff9a47b7e2fbdf7ccf8";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.124.down_proj.weight","down.weight.e4m3","6b0c3b0b046c00e812eec897093416d14be7eb7fd55119767e164dcf6810b488","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.124.down_proj.weight_scale","down.weight_scale.f32","9508f978a8dcaae96362615373282ba1bc348d3025149e99415d26e4cdf1a55e","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.124.gate_proj.weight","gate.weight.e4m3","a16e63b457650f31f55b3ca064d630559c953a7288d63b041b3f5346541957de","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.124.gate_proj.weight_scale","gate.weight_scale.f32","b7ff3abd118a3f879b6c4d99f9ba1f02b092c9f0521978479c70cedf6f3f7daf","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.124.up_proj.weight","up.weight.e4m3","71c72ad5abf9f459defdcf1eba02e6f7d38ca8d42af1192f5ea75f6fe82346e2","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.124.up_proj.weight_scale","up.weight_scale.f32","5d4578806a5b8043042bbf768ad2179ea0a42e8f5374ba121762f9c6a481ea52","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_124
