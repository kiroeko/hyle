#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_042 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="0631af3ea204150946e71961c3393609260e47a8ffd93f33643aec35880b35fd";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.42.down_proj.weight","down.weight.e4m3","d8fd38e52d491efe760c228c12fab95beebf9b1b217c940ab595ad7b28c604a2","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.42.down_proj.weight_scale","down.weight_scale.f32","87f42641e0d02287fa79a63fe544bace8ec07272b74162f418021a68d94aa920","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.42.gate_proj.weight","gate.weight.e4m3","c0dd49a4378d016b1529a818b24dc10d527e704f893ba3becdccafa4a89b25f5","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.42.gate_proj.weight_scale","gate.weight_scale.f32","6044234d3f115823c32756cb8d1d6eacd3e5ac3929ee96a5308f941eef902cc9","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.42.up_proj.weight","up.weight.e4m3","6efb6d6913432af6c6ccdaa83b38d58749deeb2ce74fc6c98e33071fe2cc5f0e","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.42.up_proj.weight_scale","up.weight_scale.f32","5317f68967841dcad32ace2110976bad2611fe1723bfd886e8563d96915ff33d","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_042
