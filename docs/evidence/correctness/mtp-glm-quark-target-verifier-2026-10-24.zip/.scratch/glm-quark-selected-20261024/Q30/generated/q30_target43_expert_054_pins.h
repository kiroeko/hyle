#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_054 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="30cc3d659b11dcfde35fc77dbb839d12f374582ce335d734a4d0666509639c29";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.54.gate_proj.weight","gate.weight.mxfp4","0681e4c8b2b63f555191a40ef2d76b3a5bcc29fd694711aa92fef8427665b6b6","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.54.gate_proj.weight_scale","gate.weight_scale.ue8","13320d828de45c2640bbfb71be6bf94dc5d5da9dd7b3f23593125c6eb84e2ced","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.54.up_proj.weight","up.weight.mxfp4","401241300bf8af6656962c9f4f88fad31ef2b5f671944422e248c7e3e52a9fe3","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.54.up_proj.weight_scale","up.weight_scale.ue8","063e1cca1ae627b6e9cc83ffc5f52f69b05685fedc4f127ee4c9df271252b68a","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.54.down_proj.weight","down.weight.mxfp4","1f15dea69157a8e2bf559184465513a3f6d3b44cd3718d43e13a1c5cd2096bd0","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.54.down_proj.weight_scale","down.weight_scale.ue8","571f9754fcd400cebf32f578fa877a27485744780c0f55c0605a416b713c7a60","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_054
