#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_029 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d8c47abea5cc4a96c4687f2619a41eab396ff677d6d84c900ecff7c56e0667b2";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.29.gate_proj.weight","gate.weight.mxfp4","29439d98a48e7a209ad846ecaa985734f112974c80b0c6f9f37d91096953d5c8","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.29.gate_proj.weight_scale","gate.weight_scale.ue8","1a08da11c4f7a8bc30a28c43727344819999fa2c2b0968992b2e123c4a19c1ce","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.29.up_proj.weight","up.weight.mxfp4","5ab56403d1454103c411a1b08e2697fc66242e7b73c6957f7d9a818488d33404","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.29.up_proj.weight_scale","up.weight_scale.ue8","c8470666aaa0d149076c531cb390fbe39cf8ba58ef14b4ba9bfe54606576018f","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.29.down_proj.weight","down.weight.mxfp4","f1e9be7d62d0d741f0b686a75b3237879c382fd0fdf123551411dc053687ae17","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.29.down_proj.weight_scale","down.weight_scale.ue8","213bb40fcffb22ae4b7f6752c7689dabc1909b1ab5288fc0788916a02a38d80f","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_029
