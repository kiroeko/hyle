#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_206 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="93050f66eafee6e0a5c4605ef5747309b4cbf0c9ed5ef31473f25b10fa6d7ef7";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.206.down_proj.weight","down.weight.e4m3","f590078c0917b617b1f0b3bf252e323e7b91ceb4f4cdeba1e2fe8fb6565f8a0e","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.206.down_proj.weight_scale","down.weight_scale.f32","6ecbdf1a208677a967999ae2520d5f5141852ac39584eeb02f0fdf76a9f74f8f","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.206.gate_proj.weight","gate.weight.e4m3","38235f7b6c7d8cf28826f742d8e61b19322652424a8e3c5b54b82550eb07feee","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.206.gate_proj.weight_scale","gate.weight_scale.f32","8c0d806532049f2b8e07e834f94fa917c126aad15991ab90bf913659abda0e55","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.206.up_proj.weight","up.weight.e4m3","8eaf3d280aa0661ce2dfe74cc8c9459b23acc12101d8789b79932dd5c58ffd09","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.206.up_proj.weight_scale","up.weight_scale.f32","e2e50195d72b9fd1ec2938d65d67ff7dc8bcbe862a2bfebb532d93a822bec06f","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_206
