#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_242 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="50dc5c6ff465b3c8a3e21ab7aa1c3e4eca659633cf89fa3cb9cdf4688200719c";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.242.down_proj.weight","down.weight.e4m3","ee4a16e6afdc8662053f6855208212f75a42814398511d3fbdc12de93d2b78b2","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.242.down_proj.weight_scale","down.weight_scale.f32","9afe2c5bc95b1aa105ad1c8248784cb3009c9d05951d90a31184aae7da8062fe","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.242.gate_proj.weight","gate.weight.e4m3","c3ea1ab697af99cfda3078bbe66d5d772f2647fa3e79f26730827f5daeefc08b","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.242.gate_proj.weight_scale","gate.weight_scale.f32","c8eb1d6e4f6e7a0c390860e177120ba5668785b211ed52ec8b84d184ef805666","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.242.up_proj.weight","up.weight.e4m3","a631a84ba5c290f658d2897e3e58d4ccdddad6eabbbe039c32a14d2474774d49","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.242.up_proj.weight_scale","up.weight_scale.f32","01950654166d77eb090d5ac94a5ae42e9a8d790ffa349a67ebe5bb53b5bcef54","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_242
