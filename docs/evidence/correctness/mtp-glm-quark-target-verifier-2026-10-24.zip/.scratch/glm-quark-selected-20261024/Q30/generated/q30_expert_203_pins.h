#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_203 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d9adaa41bb0ae609e4e93b1124d20acd59ccbf6718238c611ebc756c9dbdfe00";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.203.down_proj.weight","down.weight.e4m3","bb0c1d8787be2bfe1bece3d3d26d0d43fe829bae142206091daf695d3d760450","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.203.down_proj.weight_scale","down.weight_scale.f32","947695cb1a35c832f092ca0083230b85eccb83e7ca04120f7f17bf1eeee9b5dd","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.203.gate_proj.weight","gate.weight.e4m3","30fda91a5f7b379132e39f875e6162745f0dc61eab50aeddfba92aa49c52ecc0","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.203.gate_proj.weight_scale","gate.weight_scale.f32","f26242c1b227dd52a4ebc6acb97728732d3469c82b68cf32cc2b6bc7c0073cc4","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.203.up_proj.weight","up.weight.e4m3","5b2ae5e1aab7c56a81efc4d4ab7dbdfb2bbf86885f4717c4df218f32780bafbf","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.203.up_proj.weight_scale","up.weight_scale.f32","0cf9690eb4d5204dc180cc2109803097310f71cd5de7f18db757c39dc487edb8","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_203
