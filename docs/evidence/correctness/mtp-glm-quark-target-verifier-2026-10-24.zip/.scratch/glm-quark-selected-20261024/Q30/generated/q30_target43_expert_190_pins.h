#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_190 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d5ab09a081dd56d010fef2908fb5227dbd22760b404d29516553cc8677554564";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.190.gate_proj.weight","gate.weight.mxfp4","6baef27f7f9a73023e439a8bbaa51774113d14dfcf94599d4e4ff6f06060cd68","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.190.gate_proj.weight_scale","gate.weight_scale.ue8","a653dc9884e8c28c9e956c8cc1036929ff6a2e4f79c9e66ace5be1e6965b3c22","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.190.up_proj.weight","up.weight.mxfp4","5ca88367797c67f75fed7c2dcd5113f6fc6ecf7b0e9b64d518278ef03e7134d0","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.190.up_proj.weight_scale","up.weight_scale.ue8","e7ff8fbafd9cb634b523750a363c9cc11cfd1b3765589da6b50f1356d72d19a9","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.190.down_proj.weight","down.weight.mxfp4","e852ed8b8d54f3ca6f01fa3ac8dd1312b280cedc6e7555fe97376a41f4476621","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.190.down_proj.weight_scale","down.weight_scale.ue8","696a56a3c68059850d4f5aed376218bd84554e681ec2bdcba0e02a875150f4bd","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_190
