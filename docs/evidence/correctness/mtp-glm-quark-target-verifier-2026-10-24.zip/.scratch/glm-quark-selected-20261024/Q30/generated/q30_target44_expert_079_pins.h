#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_079 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="f3767fc5b72b34e4e09f69bd4dcdfdd4595ba05db4d127d8a2986b2cc638bea0";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.79.gate_proj.weight","gate.weight.mxfp4","952bafd6b1053169e570d031397a4c3f36d27b69b0b39a0fc5a9b7c40966e330","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.79.gate_proj.weight_scale","gate.weight_scale.ue8","1d74a85f78612e807d43ee8d75ac1169b462ee4f727e0a81ae56236f8693914c","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.79.up_proj.weight","up.weight.mxfp4","f98e8074298c1dd20598a6497e211b3ba977c0ba3dae461b5b0340cf1c2f97bf","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.79.up_proj.weight_scale","up.weight_scale.ue8","c4185d3c0fe5c201623e70b66249b901ae7161001b026dfaeb1b45e856d59472","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.79.down_proj.weight","down.weight.mxfp4","35d4369f02fa6173c4156c0555f4fc4da8e63d9d6d66048fd739fcde47fa69af","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.79.down_proj.weight_scale","down.weight_scale.ue8","e6be4f5613b5094583809a8a4bc3e0af15113928b41c93e71d0d7775ba2fcb22","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_079
