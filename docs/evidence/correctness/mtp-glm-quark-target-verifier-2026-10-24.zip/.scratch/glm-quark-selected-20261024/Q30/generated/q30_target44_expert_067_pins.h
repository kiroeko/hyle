#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_067 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="6748bf3e1d3126dbd867c9c48ed9ec49be298b721b1f396bd172bdd30c52d9e4";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.67.gate_proj.weight","gate.weight.mxfp4","cc7d1707a79584715a39d99087cdb64a22e2fc68abe9eeb9739dd30a5b73aa57","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.67.gate_proj.weight_scale","gate.weight_scale.ue8","63232b4e811be5e1a2fae020a70dba84cb8f973da162b5ac8e9e581506cde58c","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.67.up_proj.weight","up.weight.mxfp4","2e03912acaf6d4b07370ceac037467329e405cf2b3678ad691a4f9a7d0036378","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.67.up_proj.weight_scale","up.weight_scale.ue8","553c5b6fb14e9650c196ca500777a333ea4ee6d8e74be713038ad6b38d97d295","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.67.down_proj.weight","down.weight.mxfp4","32661257662c4d168daf0a8c5f38ecf90bda0b856879b0285e167a94dd84356b","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.67.down_proj.weight_scale","down.weight_scale.ue8","edbc802da8255b3077aff0ffc7fe055a4f08843d2b739a9cc1fdba1e24a68f6d","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_067
