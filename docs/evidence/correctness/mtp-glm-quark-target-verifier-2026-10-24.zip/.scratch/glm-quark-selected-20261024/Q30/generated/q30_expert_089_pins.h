#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_089 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d4bf357d1a6cb832ce2bdc2b3e496b06cc70926df4955992430cc45f7d9b0a24";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.89.down_proj.weight","down.weight.e4m3","32246a35f6e7c4bc8d9a4c2f52f5bc39b315cf402d166d7e66d6177b2f05f8a2","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.89.down_proj.weight_scale","down.weight_scale.f32","b2002a9ccff836d2f3e7238f953fd91b81044940b5114029cb4b95dc8651765e","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.89.gate_proj.weight","gate.weight.e4m3","4df71f7f90a410c297232d2756aae3b270ac7a415c1108f3e3797b5397356054","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.89.gate_proj.weight_scale","gate.weight_scale.f32","bb700b1251a9fae5cc8a0ed9c8db46d1db4fd08c7ffc937177e6df74843c747f","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.89.up_proj.weight","up.weight.e4m3","7e5efc359da9ad4283404d28b54715e24bc5d238ebaad37ef3e84414b0099fdb","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.89.up_proj.weight_scale","up.weight_scale.f32","768f2539969abff596a06c3f9676c16847979517cf2d18d5d0c2133073dfed81","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_089
