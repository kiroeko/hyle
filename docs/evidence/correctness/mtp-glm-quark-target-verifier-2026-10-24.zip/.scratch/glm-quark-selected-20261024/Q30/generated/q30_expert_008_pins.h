#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_008 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d4c2e8493ed1a971644bb5464f0d36330244e1c0c3e920d0d110f188ae66b9fb";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.8.down_proj.weight","down.weight.e4m3","c79a2ac9053e7ee7430a60a8bb55c6664d1881c326b7145b81cc689045098dc0","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.8.down_proj.weight_scale","down.weight_scale.f32","8302cc93891daed3fd10ac461909df8362c7c50ad3615a7e70e6ff8e259a2273","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.8.gate_proj.weight","gate.weight.e4m3","faa3df8d8e942543a3cbdef3e3b45a86163a76b587ef673ae10b6d9b0e6bf4f9","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.8.gate_proj.weight_scale","gate.weight_scale.f32","89863e43bf36a55d9c4f9730b5f329637fdf10a50e66d3992fefa175f6f9397b","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.8.up_proj.weight","up.weight.e4m3","31ee4091dac3c3c010698fe2df2675d2f6523e3b7f69939e0bf0529f24cc7353","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.8.up_proj.weight_scale","up.weight_scale.f32","6a4f2678d63c92902bb5934eeb2068debe567535b61751875a500411ad8308ee","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_008
