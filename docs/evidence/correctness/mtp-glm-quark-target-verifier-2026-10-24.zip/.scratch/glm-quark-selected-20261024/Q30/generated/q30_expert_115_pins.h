#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_115 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="dead39dca22f90747fe4f0a157f6af1871af01d428a746386ba873201c09233e";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.115.down_proj.weight","down.weight.e4m3","17f33a391e936d2847b2bee5b1519a4bb50fcadd80c4c61fa7ffcf3cd9489e83","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.115.down_proj.weight_scale","down.weight_scale.f32","d7888d87440a6b23a1c681f74fd4ac5b423bf5bff84be5e727d5e9b993ee58e5","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.115.gate_proj.weight","gate.weight.e4m3","c0f2195c2b610f21644111f2afdcb6f1a54916e99a91402492766c06ea65e9d3","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.115.gate_proj.weight_scale","gate.weight_scale.f32","a15da7ed50750015456415818987df52bd7bf78809d2d0f1ccd4314cd5c75b85","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.115.up_proj.weight","up.weight.e4m3","8dbc02a45c0a7add290c3e9f9e2ff27b6017f39934bc8f66c94bc118836275c4","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.115.up_proj.weight_scale","up.weight_scale.f32","b9a2bc8c09f044aa7a3585b984872433adfe0662136fb1f711e878dabf319d8b","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_115
