#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_083 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="1e5833c701dd6af8d1857ad1b6a3bd8bea867a0b26261ea0c6489f22690d815f";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.83.down_proj.weight","down.weight.e4m3","52ce67df3304a0988199eff79b8a79da95a76a1c02669787002d06ae8e34ccf4","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.83.down_proj.weight_scale","down.weight_scale.f32","1d05163b00f9ffcfb272a154fe966ed9d335454664c886c5886be5aef5acbe49","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.83.gate_proj.weight","gate.weight.e4m3","87d8b79f2177438b10c0e676f062235698547161368a403e8b142ed21105170e","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.83.gate_proj.weight_scale","gate.weight_scale.f32","60f850d66c2e0deaf724cf0d342ae317c6605005a5abef94f3aa4996384b237e","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.83.up_proj.weight","up.weight.e4m3","3f03a643f436603c526b480395be3f5cdfd0c61043c2c487b57a48f8e4242fad","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.83.up_proj.weight_scale","up.weight_scale.f32","2db44337c7a1115dfe6be86b746046cb9df687250abd4043d4d8e0bdb201b687","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_083
