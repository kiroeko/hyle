#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_113 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="dd2efc250cb9e77d03b333b46e5c2dc38fdae4ac3a51a75e71d3ec3c99a04b2b";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.113.down_proj.weight","down.weight.e4m3","3776099f3e17ac324f2d0be8cf66a18812aa81e5b759236726bf784c7954957e","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.113.down_proj.weight_scale","down.weight_scale.f32","48034541de29391d3f0bdf65949d145f5eefea5b70a77479c5e423cd8a2290a9","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.113.gate_proj.weight","gate.weight.e4m3","0ca24eba07f8047cfe2ded225bc5d2a405b3c760af060aaa16f6575738b11511","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.113.gate_proj.weight_scale","gate.weight_scale.f32","a22ead5dc2edaa327198d48d2288fe257559d7dfef1f9e0a530415044fca7bc6","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.113.up_proj.weight","up.weight.e4m3","63e880192ce7fb25ae3d2a8e81ad65da208c7fe42a5b4a1bb38f45f470161c3d","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.113.up_proj.weight_scale","up.weight_scale.f32","ae4fe1fa9a91083872f0a8444529a24c4d5fee34ad3ef70ec874d090c5566b6d","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_113
