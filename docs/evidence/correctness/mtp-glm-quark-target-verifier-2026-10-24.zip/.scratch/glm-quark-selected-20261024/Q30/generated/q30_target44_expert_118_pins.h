#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_118 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="53f1ce8d5fd9e11fd91bfc0d6a4596ec089a7fc664b7a161b9cbfa5778a4fa3e";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.118.gate_proj.weight","gate.weight.mxfp4","95f9d59ef180b49c90f980186eb3549dd3ab3121dc79fd96b72ee923af89d65b","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.118.gate_proj.weight_scale","gate.weight_scale.ue8","0f9fe0fc0826b5c8711e51d46ffaf2a279b5fba0e58702393656cbe775f6dce5","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.118.up_proj.weight","up.weight.mxfp4","642bf88b81670262f1f4fda700e06fdd1236ac339df68feb24742995cbb6c4af","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.118.up_proj.weight_scale","up.weight_scale.ue8","7b431d18fa738252b145fa1a2f29e0208c192988a3bdbb0c164d1bbff809f010","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.118.down_proj.weight","down.weight.mxfp4","f58b0d7e3b3d22a89b40f4a4cf060b5bf0b955518bda4f2a88f785079c8fe1ab","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.118.down_proj.weight_scale","down.weight_scale.ue8","9abedd14561545474a056181ffc0bc880c928ec18942d33ae0d12d3f88ff24a9","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_118
