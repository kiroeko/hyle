#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_160 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="405a068f296018a007b828147129a89cde1c9d6aedb1e39c487907d2f5b630bd";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.160.down_proj.weight","down.weight.e4m3","22b6ba77c391143438db62b8358e741183b50b92a54696db8d1081dddd287987","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.160.down_proj.weight_scale","down.weight_scale.f32","7cf60a21c6f8dce5da57207374a345dc0ff23696830b1b020ca2452f350e71bc","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.160.gate_proj.weight","gate.weight.e4m3","1117e98164f8f361285921ed60af4b95074b0e9af49ed14bf0df5944028b8dd4","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.160.gate_proj.weight_scale","gate.weight_scale.f32","c7d6a9f2c2d2040ade52e51f2d8095481ca83b0d684ab201c096e28359f96b48","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.160.up_proj.weight","up.weight.e4m3","3dc5a89348671a200163093eefec85d5f9ce6bd448bc648a60aeb77815079bc3","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.160.up_proj.weight_scale","up.weight_scale.f32","799ad50687e60e605c626418e8cdb4a23995bd7b8d21d90b53248b0575b33354","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_160
