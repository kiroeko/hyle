#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_135 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="3df38ff26b318022a8d78cdf0709447cef56a02341aaeb7a8d3de9fefc7a4831";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.135.down_proj.weight","down.weight.e4m3","1be803b51252af6520ef007e954383a3179b18262cc8bd6112f83c8fbe573e3e","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.135.down_proj.weight_scale","down.weight_scale.f32","44ddee0c14fd9d15e9f15ae5f4f71f933ad81330a4d003948a8aeb1d88b726e6","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.135.gate_proj.weight","gate.weight.e4m3","94951a711e1196d754ff5807d4d8295540385816c18374b59d2084bcf47b76b6","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.135.gate_proj.weight_scale","gate.weight_scale.f32","05ce9a205889f90732ef58c7dddb414d1433ba55dc9ef16548c17f63977d4016","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.135.up_proj.weight","up.weight.e4m3","039520ffb03a741b42025f9648558cc3ebf5d6043d0585334b9c32dfef4e0d2d","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.135.up_proj.weight_scale","up.weight_scale.f32","1373ff21c5b628511554d53398d8bfb73109b11fb28a0a736391e7708ad7d1a2","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_135
