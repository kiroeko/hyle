#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_175 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="65e0bd3fc44ca82ee63cfe26415aff82d7b519fd3efc4568ed7b952cd41d33bf";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.175.gate_proj.weight","gate.weight.mxfp4","a1d47188c1329b0d174068f83b70a8e9f095781ac8c42bf2d9697d422d3853e1","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.175.gate_proj.weight_scale","gate.weight_scale.ue8","14776d74bb41c9f76d65a7d14c71c1e5d15ab6111e8158d3fcbe2cc82b57ac7f","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.175.up_proj.weight","up.weight.mxfp4","5870663aa8a2c358c46a1db1aca8779a7ba42cbb7cdd4cbe93ad444a55df04ea","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.175.up_proj.weight_scale","up.weight_scale.ue8","52f5078ccafd1e62c453237cae732da1f93bd3867a6c2bff99d095f4a0f78502","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.175.down_proj.weight","down.weight.mxfp4","1e435095ffc168d1f37db3f2db152ea01a78d5e504cb33f22510978c78a44f2f","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.175.down_proj.weight_scale","down.weight_scale.ue8","b76aab4dd573d74f284cb6591d61570ad56e5ddce821fee53dd32b478baf73c7","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_175
