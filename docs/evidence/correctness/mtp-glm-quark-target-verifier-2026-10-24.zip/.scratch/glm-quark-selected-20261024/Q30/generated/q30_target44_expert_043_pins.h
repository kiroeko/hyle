#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_043 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="c8cc564404ae0dfadd26ce0b6c175dc1b054f1e11756fff40444b5eb6f0ee85a";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.43.gate_proj.weight","gate.weight.mxfp4","3feb4730918bbd9952d51cca789a109d4f844b5b5c4b0cbb474e2df5d4249338","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.43.gate_proj.weight_scale","gate.weight_scale.ue8","85251353d8e4e6a59914d8635e6bd8e921a602d6d9f9bbc1f790ed3c18a6e79d","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.43.up_proj.weight","up.weight.mxfp4","84af957f0b9cd3acedff9d2931696bc643839de6aa8657fa398639ee96a2d702","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.43.up_proj.weight_scale","up.weight_scale.ue8","d006e4e3802d1045c2f898506c5186eec0a2d9457b8cb744a1c251ca02cdbbcd","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.43.down_proj.weight","down.weight.mxfp4","79c6e4625d09a229b886ef94b13bec495f652ead37db473124b3f4ba1ef69be7","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.43.down_proj.weight_scale","down.weight_scale.ue8","211166641b4f51f9394aa17de179ef9c8f46a731399083745fcf34208f4c51d5","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_043
