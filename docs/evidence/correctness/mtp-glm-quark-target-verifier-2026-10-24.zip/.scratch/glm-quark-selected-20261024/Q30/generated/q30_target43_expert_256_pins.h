#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_256 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="dab3426d7462964f8340bdf9b7aac5a1a5a790d93a0089851aa39aa44dea8729";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.256.gate_proj.weight","gate.weight.mxfp4","f3ee51266f713cba37cf16b0c27d3ea969c2a9940c0bb2a6122a881c476447d2","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.256.gate_proj.weight_scale","gate.weight_scale.ue8","5aefc6e86bb8d9c12f6e6696a4ab13b06b77cc137965886678e96204eadc0fa6","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.256.up_proj.weight","up.weight.mxfp4","bc5e9f6ce34b3d5b26fb00a743a7b95ada68a72cd3839e21dd7ef8387e30a5b3","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.256.up_proj.weight_scale","up.weight_scale.ue8","859813aeb4cd2f390619d0f048f4b482043a8538ed4844b3289dad48bdf31fbf","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.256.down_proj.weight","down.weight.mxfp4","fdf19225435dfc550b65b870c229d5dec469d44a386c60f0749bf67895c8ec68","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.256.down_proj.weight_scale","down.weight_scale.ue8","695c7fe0ede5788abd45262f01eaad950f498bf442ef169aa5c0f08b686b177a","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_256
