#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_095 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="51905a68e7213823b49f615c33dcc38714e5affce2760b59461a519af266e5c7";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.95.gate_proj.weight","gate.weight.mxfp4","98e501ebbb2de4244a4b069cc36f0249b33c5b0f55efd67023cc06ce132cf9f8","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.95.gate_proj.weight_scale","gate.weight_scale.ue8","18bfeaddc8b36453cc484cefb859f4d7518082d57ee8bf6570bbf6e8b512bc76","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.95.up_proj.weight","up.weight.mxfp4","98c4e9e735bd23c720b62a436a8755ccb6e579b086654408af2d363c7592632d","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.95.up_proj.weight_scale","up.weight_scale.ue8","bf1f88632e7065002efc2474644f7835b84bacdebc02a8b861e66c4b5e9f01f1","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.95.down_proj.weight","down.weight.mxfp4","6354a94ddee7ce5ba02a239962618c1133a41ebca1bb37456c6cc0474a970ca8","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.95.down_proj.weight_scale","down.weight_scale.ue8","3d8a63bc7b0204cf8d9e1119d4ed31ed814a264c7f4153888927423ba0f4dfc0","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_095
