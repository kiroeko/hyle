#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_013 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="69473133e202cdc41797bfd81242f98ee40e223dfe5ad5f9287ea7493c3eb352";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.13.gate_proj.weight","gate.weight.mxfp4","39e431f82905975643edc3931315f223d76eeb71d6c7e0848d0f63a5752bdbe8","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.13.gate_proj.weight_scale","gate.weight_scale.ue8","243a66aa08b40d20296bd80bf181cbbac47fd213c434586530bd48167dd0a12e","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.13.up_proj.weight","up.weight.mxfp4","880fff8ee2d2d90c1e8fb189d315ed659726ad9419ab37dc29e596ffe0980c70","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.13.up_proj.weight_scale","up.weight_scale.ue8","c1d85af458f4c6f45cd90b8cf89cc42c66a74346d5cda165424448f3064ab5c7","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.13.down_proj.weight","down.weight.mxfp4","be73a0769ec142cb62b7d57abdbfdfbb80f6d8d3ff16b954812efe5e24e28476","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.13.down_proj.weight_scale","down.weight_scale.ue8","6dd3ad6f9dff0bed9631aa4138995d4fd9ab695ad42ceb689b20f6bee2af5ac4","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_013
