#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_146 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="e6f4426d0d68ff24d3aad133f477e3afeb1619e6c7936be2635bc143d4bcf4ab";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.146.down_proj.weight","down.weight.e4m3","2ef07528373238e55b656ce7a792328080f582f17d5db01a7fba1451fd14dd55","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.146.down_proj.weight_scale","down.weight_scale.f32","7c89c4454568659ba33704613900ba3c6f1a3076dfd77158df615df9f913f2c5","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.146.gate_proj.weight","gate.weight.e4m3","b5c2764b610e78191ecd46bf9224f131ce45ccc9e08cc39a6a798f61871b22d5","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.146.gate_proj.weight_scale","gate.weight_scale.f32","8ed22041c372bef6d109ab5057d5cfc81000d3aa4deb34cf4b031e0c8bc73eb7","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.146.up_proj.weight","up.weight.e4m3","8c43a22e69a5173120792e5e21a8778987f8b2d8ab9f2191e5d47a32d996d6a4","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.146.up_proj.weight_scale","up.weight_scale.f32","9a441e14bc3bcb482befa0727493f3bd66b336b00572dcaee872244ce169240a","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_146
