#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_167 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="02be69a96ca964b98459fdfe980c4b9d059cb9ae5b38a0d3f7987623c604efcf";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.167.down_proj.weight","down.weight.e4m3","013a3d8a4721c9dd484d84d7b23ae061be9a56dd5be08f37f8f2555ed7385c53","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.167.down_proj.weight_scale","down.weight_scale.f32","4e1a9901e987302fe7772bf8b7f4db72b2c0c0da9e020b7fc54fc2b38215b083","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.167.gate_proj.weight","gate.weight.e4m3","0a4bb4e167fe6463c22dc84c4d48a746e9aec76fbdbec1b2bae9df38e943eb52","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.167.gate_proj.weight_scale","gate.weight_scale.f32","9de121448eaa90545c930ba3628e0fbd4596b6fefb7d7c97bb84ecffb04b23ae","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.167.up_proj.weight","up.weight.e4m3","0aa6925325e3b08d46f46068b3195a32f59426874dd8f6cacbe40f656cc47a72","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.167.up_proj.weight_scale","up.weight_scale.f32","196a35383686cdcef11df3ccd2743b4c1e242399058320008a456133c7dd0003","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_167
