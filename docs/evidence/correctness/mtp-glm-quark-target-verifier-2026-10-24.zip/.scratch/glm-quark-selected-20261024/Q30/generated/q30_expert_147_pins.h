#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_147 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="5c553f53bcc0f330cfcc2d430738a1b2b372a31688f683e818f1b48a6407e0fa";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.147.down_proj.weight","down.weight.e4m3","218ee6abffb86ae0491d7739bb9eb45f2990d093c6211b6323cefb11feca6835","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.147.down_proj.weight_scale","down.weight_scale.f32","d0cb48259be0b939ca5d50729e9f80e637dd5c55e6c5ec1a23fc8617b5e6442d","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.147.gate_proj.weight","gate.weight.e4m3","c3602d24786ce335a05b11132cb01160c570a0a1a2efb4c22101adadefc29d85","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.147.gate_proj.weight_scale","gate.weight_scale.f32","3f9bc7eb6f2508610a3c20ed0ed64fc96765e61e68b49ea7ff38376cb5edf871","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.147.up_proj.weight","up.weight.e4m3","57ad892c3998d134f95cabf56a305c56b68ba518a53d258051c7693e0afd8dad","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.147.up_proj.weight_scale","up.weight_scale.f32","d35325e0018f8b5c7e5b02a2261666f0fb8621ad0a3d79401d3bee260408314f","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_147
