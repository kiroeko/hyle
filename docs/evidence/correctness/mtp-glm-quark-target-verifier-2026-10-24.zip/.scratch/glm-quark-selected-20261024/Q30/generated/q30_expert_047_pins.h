#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_047 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="46547e6f0c2e165c6d28c11075af3f1bfdf623c8ad9f498a5b492cbe0185d726";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.47.down_proj.weight","down.weight.e4m3","91163d935d9ec92165b5830085c54ca3604b87c8f6f89acc1aff2503ad2adb65","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.47.down_proj.weight_scale","down.weight_scale.f32","f7fffaa06246916292118953661cfcf7c4c5f402b368bbe1ffa5a7b11205b639","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.47.gate_proj.weight","gate.weight.e4m3","2759f508b87fd341aa3873bc03522a799cea7ebe85c82c903a5318fe5a106f5f","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.47.gate_proj.weight_scale","gate.weight_scale.f32","84a673d044aa12c6c3e8b3898f6829c8c058c479e403f0009bddf6aaade9d9b7","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.47.up_proj.weight","up.weight.e4m3","edb40d5d989ccd174d80b8179c7b467a55fbdb7d555b6874fca147ab717e28e6","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.47.up_proj.weight_scale","up.weight_scale.f32","f0f1d1ef820e229599870275e923eb0880a90eea3e957f08d18351a6ff4cb820","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_047
