#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_116 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="3491a8a83d99000e63e64618e9c002be567ccd7755ac033827811087a3749fc4";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.116.down_proj.weight","down.weight.e4m3","e0398566407c3b83d606fd41b37af1ba48ab442151f5d100d6920f2ae7a9c606","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.116.down_proj.weight_scale","down.weight_scale.f32","a26466b6e0492b4d4bc4e1dc0957e72c40987a7c26b5af1857770f026fa21c14","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.116.gate_proj.weight","gate.weight.e4m3","5b9c5b102f4ae7ca273c85d5544d868cc8b1fa47177c9f7a3e0474f4f92c5df8","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.116.gate_proj.weight_scale","gate.weight_scale.f32","9c7c621e9b2e2ff2460dcb95f0089a6036f0e6da62b8eb3a3efce27f5044a5e8","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.116.up_proj.weight","up.weight.e4m3","55dcad4db6ba8f363ac8eaf11781fddc9e2608a369784a4899a16140a0746e1d","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.116.up_proj.weight_scale","up.weight_scale.f32","cb7a2afc66a6058fc684f4384a024f42c623d0aecf30922e812881703ffa3de8","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_116
