#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_055 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="87179a3247c17ea48a9589c1168f515afb62ea4f913a91a30e63e9ee413c596a";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.55.gate_proj.weight","gate.weight.mxfp4","a723dbffd0a01c7a5dd2b7ff883d7dcb70be1750271931f088b4526f0e848c4d","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.55.gate_proj.weight_scale","gate.weight_scale.ue8","5ec0049dc2dee6885f9654297b6957daef9fc196b5925bc2bf6f26c29cc18f98","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.55.up_proj.weight","up.weight.mxfp4","78a805810e51c73bad04f2518bebb20181ac8f351d94dbf96ccdc9cbd25805e8","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.55.up_proj.weight_scale","up.weight_scale.ue8","446fcf4fe766f66cf0dafa4330ac718e4d186d0feb5175241fc8b59e001de0f4","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.55.down_proj.weight","down.weight.mxfp4","fbbf606b5b080907a993c3c74b9affe50f838d9d59450a49424221bd194a0376","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.55.down_proj.weight_scale","down.weight_scale.ue8","624033ed02d03170ab8aaa0a7f1b4a4a61e25d7ba9abd9c063b1bf5abcd59e37","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_055
