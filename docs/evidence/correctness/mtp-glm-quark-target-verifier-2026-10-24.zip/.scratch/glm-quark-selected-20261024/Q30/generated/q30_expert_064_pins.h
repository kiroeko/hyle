#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_064 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="1c0a04c897337eefa1527148ac754e8ab26f1a55996a1b245b1e07042abc0858";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.64.down_proj.weight","down.weight.e4m3","5469520d1a69c0167baf78d51410b636a9e06cf6e46618a2868182df220bf992","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.64.down_proj.weight_scale","down.weight_scale.f32","96fe76b371659cdc5454b0ac59ed4d025dcd5c43621566631a439ca3d5f7d4e4","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.64.gate_proj.weight","gate.weight.e4m3","683817333ce7531c91bcdda5074d40f335d4949bf5169934a9f99f332579e7f3","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.64.gate_proj.weight_scale","gate.weight_scale.f32","609af0cc9218ab38eeb99c788433fd749a8b36add525f666609b7779dd2dd521","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.64.up_proj.weight","up.weight.e4m3","8395ec3055de4b73ea705d45d0f630eea2c6f10368bd002e26e8760bf01146cd","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.64.up_proj.weight_scale","up.weight_scale.f32","de7be480af2311b4e0b3ba08e84e51169ea4ec4b70541a93b3e3dca333c157da","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_064
