#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_116 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="0bee14eef7e6a1b207f0f4b37aaf8425d146a6925481be0842f686c84c052fa3";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.116.gate_proj.weight","gate.weight.mxfp4","4913ce79f13bd3d8bd86b9c0106c78fa8407f773bf2376f597ad3b8a3ec2754d","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.116.gate_proj.weight_scale","gate.weight_scale.ue8","d0d34e12c7b8f40e71de34f748c18de928535294fa5392277ec1df5f0df1cd4d","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.116.up_proj.weight","up.weight.mxfp4","a066cbced0fa09d3bf93964366a317b26a3c9ed0b1bb8e1281726aafa9d215b8","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.116.up_proj.weight_scale","up.weight_scale.ue8","255f64ed17255cfe6649b3a6d7c90ee0a1a40f2116e96021b0429cd102b98c9b","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.116.down_proj.weight","down.weight.mxfp4","aecdf934743548718bc47615e2e673e713160daf6c3c18463a1a905f635cbfb3","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.116.down_proj.weight_scale","down.weight_scale.ue8","3f476ad6b6eb461a053a84011209a5b3af73a0e8dbbf7be1d6c6701848b822d9","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_116
