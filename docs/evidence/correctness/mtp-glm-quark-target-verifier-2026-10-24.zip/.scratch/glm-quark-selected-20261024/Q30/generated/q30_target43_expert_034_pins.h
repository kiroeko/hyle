#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_034 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="da2039b39dd5d5ccd0648c1c7d5181e833e741a2667bbaa3459dbca0240d7d12";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.34.gate_proj.weight","gate.weight.mxfp4","ee9b16cd955e383ec0d148466a77a759fc7d7751e543486e575f0d5b06c53cbf","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.34.gate_proj.weight_scale","gate.weight_scale.ue8","18109d5f4de5f8c3a660cd3ec3fbd8781fc6d650f983de2e92bd172a86a4d49c","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.34.up_proj.weight","up.weight.mxfp4","03f09c38b2fc5f969fcfbf8ca6674ac06209f8f76d4dee853c4437e2c72bf29c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.34.up_proj.weight_scale","up.weight_scale.ue8","e16e8c096de05b6e3b4e6adb744ad6b57798dc573c82da7c2f0e7fac631b7ca3","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.34.down_proj.weight","down.weight.mxfp4","89028b442ef4fdfcc85b17bf1857e071e572cdd2bde1465b7776aa87e8e8799b","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.34.down_proj.weight_scale","down.weight_scale.ue8","e1afdcd788287ab396b5ea04709fe319b10f357907504712f97ab95efa919b09","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_034
