#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_253 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="32832b610b97a99af8e33ea34cad1dbb28609173e5de094e3ff895917a09880b";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.253.down_proj.weight","down.weight.e4m3","091479328fa4b9e5ec6b14a2ace8b9ba7d2df64497ce498fbf729684599ab9b3","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.253.down_proj.weight_scale","down.weight_scale.f32","1f12e6634c51463668cfbfe671a4ef6115eca2a419e64750646ac227a9d63bf7","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.253.gate_proj.weight","gate.weight.e4m3","177152424c0c5e298cee6c7ab15ef66b16e560cf7099d9a21762fe5e6d3da79d","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.253.gate_proj.weight_scale","gate.weight_scale.f32","3b2e28238522c5691c39afdea87092acbcfb52fea58ce5ca30bd81eb51d04e15","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.253.up_proj.weight","up.weight.e4m3","c02958ec782a42b7194f58ee02f896b1cc80d99f8199be1df03684c5074051c7","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.253.up_proj.weight_scale","up.weight_scale.f32","e19096eeb8fa401dbeb63a045f4a435782de8bab49706b9cc6619f85ef816beb","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_253
