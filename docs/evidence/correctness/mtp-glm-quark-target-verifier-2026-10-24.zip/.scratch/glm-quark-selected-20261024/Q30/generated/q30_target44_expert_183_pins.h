#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_183 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="0ada0cc10ed77abd36738c36c2d82b6b4e827e553abccb6cde4d96a6f0ce7dda";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.183.gate_proj.weight","gate.weight.mxfp4","00084553fda4845b9c2defbcb010f2b7083bbc8c30cddc4fd1fd2c32918c2846","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.183.gate_proj.weight_scale","gate.weight_scale.ue8","382dc7b6d324bb6cb371fe674a1262872d74c6a11ed3b550fbf9ce914c9e4d6d","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.183.up_proj.weight","up.weight.mxfp4","46066d1b7b092ac16528f56fe9564ac9f9cfd39d7d59b210f6bd5050a0beef7c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.183.up_proj.weight_scale","up.weight_scale.ue8","e7843d8a42fb225150c07af981566371503c37d6c4b477184eda0024351d82ef","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.183.down_proj.weight","down.weight.mxfp4","879870e6ba8e07f9ae2a5e89086bcea49a25a47917865b7cdbe74404613185d5","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.183.down_proj.weight_scale","down.weight_scale.ue8","6039f40d82df48663d035d99a39769962636e785aa7fd1817539a992c81bbbf0","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_183
