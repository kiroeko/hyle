#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_214 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="a2d9981ea66dcbb598baf737d7c1a0dc59672ca00f58887b8b5d3318c2ce6bc4";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.214.gate_proj.weight","gate.weight.mxfp4","defc247d3927f3d7f6dff5186ee97b236b67d2076fe90fc2ee920983e9b6f041","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.214.gate_proj.weight_scale","gate.weight_scale.ue8","021545a4944a8c3a80e884257e949e2c872bcbbc8dc067f9b3931d57ad95d84a","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.214.up_proj.weight","up.weight.mxfp4","86cacb0bc02a3fffb8831c9e7e05fd4c4eb60b926a47218a76e0e4daab299784","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.214.up_proj.weight_scale","up.weight_scale.ue8","dcb32b268c26b87d9c845a6cacc7634f7447cc9e1af7f28087310734db41b2b0","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.214.down_proj.weight","down.weight.mxfp4","690ecee15b2e5b8965d64d01d57a3d463f8330325dd82bf2163a88c71dcd5d85","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.214.down_proj.weight_scale","down.weight_scale.ue8","6c2f3d3228ab0292ee636302e0b1a8595feaeae281a99f558813b0073b6cd022","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_214
