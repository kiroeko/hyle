#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_040 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="7103c22093dbf6aba36e945a8825fa8eeeabc6e7dced8112d8988ce896a47242";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.40.down_proj.weight","down.weight.e4m3","393be7d35c1ba0a17035bc38f7e10a833e67e295807d47ec1fdad474baff47c5","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.40.down_proj.weight_scale","down.weight_scale.f32","5568b43f20094a3830d8af3ca8e73fb303c482bb31e596e710533223e7b26da0","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.40.gate_proj.weight","gate.weight.e4m3","766d1281eaf534cdefbb46237e2df08f985fca8ecf5016b10d69f16cdbe648c1","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.40.gate_proj.weight_scale","gate.weight_scale.f32","92fc7b9ca88b5600140901971caa0878e0b71b6f4e42d423e743ca9818de7dbb","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.40.up_proj.weight","up.weight.e4m3","df3bb73a1cf464bffa3e04f238cbcec415f9e15d4688178e8f8c1719bdb499ec","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.40.up_proj.weight_scale","up.weight_scale.f32","14c4c6bcbbf8767d4cf88cc87b33d0e5bef13c38dd8a6dba66292b8dea077b39","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_040
