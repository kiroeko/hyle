#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_260 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="089f5f149444384c09021e4f1f80234858a8280fd5c888b5843ee223d2ff42b8";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.260.gate_proj.weight","gate.weight.mxfp4","981e347a0c9acabd0668390a7ee9398d921699a147533fc85cdcb65475253d57","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.260.gate_proj.weight_scale","gate.weight_scale.ue8","59a16d96b52e3d1d263b12d3abf66e19c7c3648d20b1aebda92cf44102a8d6d5","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.260.up_proj.weight","up.weight.mxfp4","f2b4f2ca860c2370b885b845365b4f2a3da1c8f92bac38f8ff66daff49a0dd8f","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.260.up_proj.weight_scale","up.weight_scale.ue8","c5695c7069d0b97e98c1e022c6e1486e6005a4cc30a6466eccb84594af6ee62b","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.260.down_proj.weight","down.weight.mxfp4","3a83dcf32a29739bd7954dc396b7a53e687b8f3c46331521f234f66a92d122aa","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.260.down_proj.weight_scale","down.weight_scale.ue8","1ac1690760e507f874ed98c164698213f86f61fa5f58083d4f5768dcee0acb6f","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_260
