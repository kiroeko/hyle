#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_static {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="740215d20c0018feeee5269cbca756f945a268960bafe6f476e6f66f59dc649e";
inline constexpr std::string_view kExpertPlanSha256="c61018d5831bb4e6b9e931c4712f14c39ebbc00ba57277efee00a7ddfd11c76c";
inline constexpr bool kBaseRevisionKnown=false;
inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{
  "amd","amd/GLM-5.3-Flash-Quark-MXFP4","glm5-next","GLM-5.3-Flash-Quark-MXFP4",
  "b5688f25491202978c19c4d036eef579f61bbe07","3a2c766e6a5256241b0b6ad82bc07e65bf4881b7211a0484cf18ce7020bfbd8f",
  "amd/GLM-5.3-Flash-Quark-MXFP4","b5688f25491202978c19c4d036eef579f61bbe07","Quark-MXFP4",
  "1a91c7f25ab61e7a0e537b047075d91537441e43263be01faf47d8b895f302cd","safetensors"};
inline constexpr std::array<PinnedRole,32> kRoles{{
  {"model.language_model.layers.44.self_attn.q_proj.weight","self_attn.q_proj.weight.bf16","c2570fd60a3add837dfff06db309271cec6fd323f5ed5d6937d3c2bf54b8524a","BF16",{8192,4096,0},2,67108864},
  {"model.language_model.layers.44.self_attn.k_proj.weight","self_attn.k_proj.weight.bf16","67b8a0eec7be8ab87773c0784bfb0bdff403e5f02c560bf3e644871cc23b5b29","BF16",{8192,4096,0},2,67108864},
  {"model.language_model.layers.44.self_attn.v_proj.weight","self_attn.v_proj.weight.bf16","12d10807246c8981d815b9284b933ddd2dcc5ec602fbf1f98772d5bc68701cf0","BF16",{8192,4096,0},2,67108864},
  {"model.language_model.layers.44.self_attn.f_a_proj.weight","self_attn.f_a_proj.weight.bf16","670b3c0619eca43aa022b85dcdf80ad61066107d3cd10a8e6f3db1a55dcbc897","BF16",{128,4096,0},2,1048576},
  {"model.language_model.layers.44.self_attn.f_b_proj.weight","self_attn.f_b_proj.weight.bf16","ce802d2af7d55a771cd5a7ee9264cb64f6d9e0e9059c8b2c43144bce156218d6","BF16",{8192,128,0},2,2097152},
  {"model.language_model.layers.44.self_attn.g_a_proj.weight","self_attn.g_a_proj.weight.bf16","214f7316fe05cef05ce379b9207e73c56d624869f3a4232e3460a6efb7447889","BF16",{128,4096,0},2,1048576},
  {"model.language_model.layers.44.self_attn.g_b_proj.weight","self_attn.g_b_proj.weight.bf16","0394a7c94463a477bd4e0f6c56445a3dae057b4fae0e7a012a27b995b4edae16","BF16",{8192,128,0},2,2097152},
  {"model.language_model.layers.44.self_attn.b_proj.weight","self_attn.b_proj.weight.bf16","22437572dcf63f8fd0215e3e6b621cd0f6718fae53000a47e08dfac73774bfee","BF16",{64,4096,0},2,524288},
  {"model.language_model.layers.44.self_attn.o_proj.weight","self_attn.o_proj.weight.bf16","fc33867c99b23bcd8a9de21fad878248c968f439fd50f250e963ef891086ea7c","BF16",{4096,8192,0},2,67108864},
  {"model.language_model.layers.44.self_attn.q_conv1d.weight","self_attn.q_conv1d.weight.bf16","225d2510e8ee5f8e8e053a12c62c3996dc4051e402396a693c9e2411b7820b42","BF16",{8192,1,4},3,65536},
  {"model.language_model.layers.44.self_attn.k_conv1d.weight","self_attn.k_conv1d.weight.bf16","689e51f88abd9c25b536e2af7e36c78302e5f7ed1c6f328dc631ac802a217cf1","BF16",{8192,1,4},3,65536},
  {"model.language_model.layers.44.self_attn.v_conv1d.weight","self_attn.v_conv1d.weight.bf16","d4eac8ba7eb744cb02e32d65ee4708759e5d10a68f832d10032fbfb4cb7e66e9","BF16",{8192,1,4},3,65536},
  {"model.language_model.layers.44.self_attn.A_log","self_attn.A_log.f32","c0227d397bdcefef8553cc1981d9580bdb312443fda1fc2dffbb1ef12b9040b4","F32",{64,0,0},1,256},
  {"model.language_model.layers.44.self_attn.dt_bias","self_attn.dt_bias.f32","3a0296f7b6eff5f2b714f1ee9b5786668cc20e906e3dad4ada9123783beed7cc","F32",{8192,0,0},1,32768},
  {"model.language_model.layers.44.self_attn.o_norm.weight","self_attn.o_norm.weight.bf16","4c109a7bdd01133da1cb8bf9500d62db3237f9354db4eee55624994d38de64ea","BF16",{128,0,0},1,256},
  {"model.language_model.layers.44.hc_attn_fn","hc_attn_fn.bf16","b5f3e569fc060345c3f4c9d1e7ec35d106587766325848717adea09e236d12ac","BF16",{24,16384,0},2,786432},
  {"model.language_model.layers.44.hc_attn_scale","hc_attn_scale.f32","892c4503190695517bec43acd35bf1de881fc243af97277ec698ee40be769997","F32",{3,0,0},1,12},
  {"model.language_model.layers.44.hc_attn_base","hc_attn_base.f32","441bfea20b5575f487d2f9d742d5a5403064b83d570db3326cee092af66350a0","F32",{24,0,0},1,96},
  {"model.language_model.layers.44.hc_ffn_fn","hc_ffn_fn.bf16","a4d59b06a0258af0f2c3026722c1a441edb9198967d1641e19e0a3f9d80c4dfd","BF16",{24,16384,0},2,786432},
  {"model.language_model.layers.44.hc_ffn_scale","hc_ffn_scale.f32","7c66c9379664cb8b2332b2675d33f4b5bca7050e024c1b47bf2cec074379f9b1","F32",{3,0,0},1,12},
  {"model.language_model.layers.44.hc_ffn_base","hc_ffn_base.f32","57998d7d83e42c111a0758ae478f34a1b13ccf9912869fd4e1b5d31cdd076936","F32",{24,0,0},1,96},
  {"model.language_model.layers.44.input_layernorm.weight","input_layernorm.weight.bf16","6a8b917f4f110355207a77b56ebc68e4b5c0fac8cda9f0c820078fa1e1ddcddd","BF16",{4096,0,0},1,8192},
  {"model.language_model.layers.44.post_attention_layernorm.weight","post_attention_layernorm.weight.bf16","ca52c0b03f154e1ae561bc47fdd54f662edcf797d7fb1af9ec13bb88a40eaafb","BF16",{4096,0,0},1,8192},
  {"model.language_model.norm.weight","model_norm.weight.bf16","aeae580add5eb1328bd06dbf47a218b316e01d7ecf857fb4ab8e987973f7ed22","BF16",{4096,0,0},1,8192},
  {"model.language_model.layers.44.mlp.gate.e_score_correction_bias","router.e_score_correction_bias.f32","627c39a4732b65c355cb69ef64f12c13945827f685001b5bac94ca349e31b824","F32",{288,0,0},1,1152},
  {"model.language_model.layers.44.mlp.gate.weight","router.weight.bf16","c7783d34ee8585983720b855af327b9babd381be13e4b0fd2ea59245bacae816","BF16",{288,4096,0},2,2359296},
  {"model.language_model.layers.44.mlp.shared_experts.down_proj.weight","shared_down.weight.mxfp4","baa72df017a265690cc69a5625b23d2c0021479a59ce066f40d4d3f5792b3dbe","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.shared_experts.down_proj.weight_scale","shared_down.weight_scale.ue8","c9a0002584e08bf24bb7529c03e5cad9a8313e23e4d500c4dc6f597a0e1f0250","U8",{4096,64,0},2,262144},
  {"model.language_model.layers.44.mlp.shared_experts.gate_proj.weight","shared_gate.weight.mxfp4","155446895723cc1aca101c5922ab8bd6a9ae9f9f11e145357d6ca30b8659cdc4","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.shared_experts.gate_proj.weight_scale","shared_gate.weight_scale.ue8","754edca65ab032eced721c09e8be9e10842bb87e1dee75e4d1fda050aefe5da0","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.shared_experts.up_proj.weight","shared_up.weight.mxfp4","8bd7cb50d1bf50e70bfe9f4e694092aeebfbd8abc841350ab39512d52528510a","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.shared_experts.up_proj.weight_scale","shared_up.weight_scale.ue8","131b72c401ed06b9857c7475f4c4c951d86e846df53c890521096a4fa64675e3","U8",{2048,128,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_static
