#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_110 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="cce1b4b6d235ce682944a578e27b60a1625ee7ef77c8cac81b5f960d8d243777";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.110.down_proj.weight","down.weight.e4m3","bb9625a63098b0296ee79ef3fd0403334d30aa39b59db2d0fe50a77f5bd4311f","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.110.down_proj.weight_scale","down.weight_scale.f32","2b5329a17736ca65e1cea32857122e2d57ca931d498fbea0bd9a9eeaa4a3889c","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.110.gate_proj.weight","gate.weight.e4m3","9ab1a6de4f8ad76790ea0abf453e93b011e2eca42e22926440d8122246e888ae","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.110.gate_proj.weight_scale","gate.weight_scale.f32","6685a59bee78e7950fb56864fb5f01650a87bc775efc5fe77b73171209f803a8","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.110.up_proj.weight","up.weight.e4m3","c3e7f2474b29b2e0f970261af11b257a0a04668d7d93911fda4493bbd0298cca","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.110.up_proj.weight_scale","up.weight_scale.f32","47897e5d7d7350ce67a0270e8007471b26698ea0ab1397ed833de1dd90486020","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_110
