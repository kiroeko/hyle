#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_043 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="75b61e5dfe1991fda06c51c2bfa04b9dec9abd5b7b10d8e6fb380c111b4af274";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.43.gate_proj.weight","gate.weight.mxfp4","6e9d8714c730b33b11596cdf0bf90fc088ce3b5bd8b7c5a73ec191d7aec398ce","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.43.gate_proj.weight_scale","gate.weight_scale.ue8","ca10d8bca2dbaa52ae0d977bd7ec21dc976dfa3bf308e22e8b410f2ecb8b15c8","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.43.up_proj.weight","up.weight.mxfp4","24f420e5094151aa5e668c9f12f94592cddabd47f0d88dbf084b31b4de220bb0","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.43.up_proj.weight_scale","up.weight_scale.ue8","29112729769f912522a5772b9bbce6bf345f85baed697064739bead317b5e8d9","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.43.down_proj.weight","down.weight.mxfp4","9ec0e6a25ba77ceef170a0eff189fdda86a14220d72673063e7dce28c86d4981","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.43.down_proj.weight_scale","down.weight_scale.ue8","9e0b535a6f406d30e0ec0275a604d4b8354037e1e408894575d68be41066107f","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_043
