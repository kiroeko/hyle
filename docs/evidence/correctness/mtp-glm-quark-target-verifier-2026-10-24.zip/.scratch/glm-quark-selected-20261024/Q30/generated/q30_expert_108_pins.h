#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_108 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d590180b2ee2d0bada23d21967116b26c26225729247fd9326b5c213f47da3d4";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.108.down_proj.weight","down.weight.e4m3","6869f547f3a93349c9387a3fac55cead64cc564adfcebe80023c066378de1ca6","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.108.down_proj.weight_scale","down.weight_scale.f32","41fcb6035bff2aaebd061bc29022a1ec6f0e7e46bf61a5f7beea3c67bc8d9e5e","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.108.gate_proj.weight","gate.weight.e4m3","ee798a910b9c0a27bedd2a47b9659eb368d192b2b098ad8b2f7cee44df51db2c","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.108.gate_proj.weight_scale","gate.weight_scale.f32","bb61efcb1d332f05f7711b73776a018da15420258fb996ac2725ad48739c7f83","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.108.up_proj.weight","up.weight.e4m3","b2416b02932f2a244bb2641cca23ac4731d5b7cef109c93273a4c92838365238","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.108.up_proj.weight_scale","up.weight_scale.f32","cebb766cda985cf48f5f16658bbee1775436b2a136f8d9b3d578293630058cbc","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_108
