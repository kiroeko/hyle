#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_225 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="6fbf851d4cb956e22bc5a94f8072e53764ac5919f751518b1c9b2e2709b2d1c1";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.225.down_proj.weight","down.weight.e4m3","c7303d4e9d2de53c1221b3c216a2a4f4d83b702114112856cbee69fb1c8cbb82","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.225.down_proj.weight_scale","down.weight_scale.f32","5e63f2e6eec686c275f001e0b76b7c36d68fed27a0e7f5274c26f1abae5915f5","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.225.gate_proj.weight","gate.weight.e4m3","3dcb60fa71d441872f53767a0c82b6314848a250214ecdff0d2b80663fe78636","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.225.gate_proj.weight_scale","gate.weight_scale.f32","514387403ab2929dd27821b26498a34ad12c82d33a5aa2f5d3b77e0952014786","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.225.up_proj.weight","up.weight.e4m3","49108e611b900b22c4b8e6d4929e31ec9ad256eac2ce111177c5e40fc3bd7ade","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.225.up_proj.weight_scale","up.weight_scale.f32","66b48271252bf310c9208a1ed151f6635cd52d98f5d0b755cd6c96742bd1c652","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_225
