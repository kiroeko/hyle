#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_280 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="ea9419431912841bed2c7b5697b06a93fcd20a6dfa5ab6fbbf9e9e7f8ea853f3";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.280.down_proj.weight","down.weight.e4m3","d4b921bb6a0a8f0b6a9f69b82168f619d3fe7bb024f0f0a24c8f297759fc3ea5","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.280.down_proj.weight_scale","down.weight_scale.f32","706dd509dca070b182ff9b89f8026f374f6e5dfa84b38963df7a4a08c864deaf","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.280.gate_proj.weight","gate.weight.e4m3","81488929c61841dfc8b92779f95579497703dc0b0e2ec47304ac7d5102cc0063","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.280.gate_proj.weight_scale","gate.weight_scale.f32","90a23ca4c77b8393879edc36e2c141b015d52f8ce4f3d3a6c4ece1dc5633da00","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.280.up_proj.weight","up.weight.e4m3","6b53eddc9c08dc416c1553784f06214e55887e5c6b990af9293207fb9a789efc","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.280.up_proj.weight_scale","up.weight_scale.f32","d09ce923ecb7deeff9c019054111f0bfb96a8475c62c5056dbbe584488c2a04c","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_280
