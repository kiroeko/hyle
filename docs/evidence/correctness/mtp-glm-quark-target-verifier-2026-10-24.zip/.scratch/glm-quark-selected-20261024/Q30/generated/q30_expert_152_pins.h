#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_152 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="29cbb1f18d84ef76207196b08036b9e2cd9e1bdbc6416f393d38f1e2d685256d";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.152.down_proj.weight","down.weight.e4m3","404a228b54f2261e7aa206d7ad03c50103fcee7303454950db23ec963bb94960","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.152.down_proj.weight_scale","down.weight_scale.f32","a5b5b60ad5d66ddbc7733ac6de10afb82f6bc2421d7dc6e519664c977df4f48b","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.152.gate_proj.weight","gate.weight.e4m3","26fd79b5ac5467b1aa59403d1ee4658ce82c24a65676753a9a3b153fa13023bc","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.152.gate_proj.weight_scale","gate.weight_scale.f32","d5acd93a1018c376f29af0f283fe566f0acaf62bbd06e888c376bce1eed8a44f","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.152.up_proj.weight","up.weight.e4m3","e1583e769c797940ea2eb4eb598eb878d2cf12cc664304ae81fe974184137583","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.152.up_proj.weight_scale","up.weight_scale.f32","ab00e5bf1bbd7961e8236332505692c60f9d55309808428cb1f40ff3a2aeb616","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_152
