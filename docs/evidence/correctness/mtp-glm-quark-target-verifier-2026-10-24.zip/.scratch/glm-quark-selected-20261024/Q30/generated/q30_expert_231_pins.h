#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_231 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="f378e5e21ff3d1defc5d1e43532e432ee2a978c9661523524ed93af424529bc8";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.231.down_proj.weight","down.weight.e4m3","b1aa74cada534abc812307c8d41e70acc3caa3318d4f98f20aa9fc41f29f453e","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.231.down_proj.weight_scale","down.weight_scale.f32","6dd7bf214b25b375eae976bf0012b9b1bfe9ce5e93a0429ffffbf76e33e015b8","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.231.gate_proj.weight","gate.weight.e4m3","6f54d53c21e1fb41ad6b5ce2f03853cb0e7a4bb4fb034599b892a4e9e3582664","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.231.gate_proj.weight_scale","gate.weight_scale.f32","c73b7a912d86309f84fbbcebb82457392154737067d2e993a27be6e308cfced5","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.231.up_proj.weight","up.weight.e4m3","a377422a9aa414f651cdd6f7721bbd6e96c7b283bf26b5f520b5d000f1bd617a","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.231.up_proj.weight_scale","up.weight_scale.f32","0411792ac3b8c71e3bd728d4c31eabd551b9bf54f97863272999477db4a80e7b","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_231
