#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_163 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="f4f356a5ce5feec2a3c16b10d066bf7cd4c069ced589000bdca444c6c284fbb2";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.163.down_proj.weight","down.weight.e4m3","6fe07236eee195b5442dd2b1b65c52e6bd4d0f4714b6974793bea03f86bb99ba","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.163.down_proj.weight_scale","down.weight_scale.f32","d1cdb77389b3c26f8ddb6888a77918b7349e7141ba2222daefe496ad9c4da076","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.163.gate_proj.weight","gate.weight.e4m3","6642ad38572483af355196f71e05d9fc2f6bbabf439f57cad65d3d978eddf51d","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.163.gate_proj.weight_scale","gate.weight_scale.f32","dd520aaaa3128f6f5a7f6aad6e0cfb721eb3e682d46999b11a99bdcc02b6c0b1","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.163.up_proj.weight","up.weight.e4m3","c64b2116636248369672f52e858eb9286640ce19cf9f84c96432e17f9aff1046","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.163.up_proj.weight_scale","up.weight_scale.f32","a2f1713d2b5c83f3ba2e063889c101e87068392a3b497a4740f2aea3cd039eef","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_163
