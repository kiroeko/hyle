#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_071 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="8950325f1b11c93b257150e967b7cde581200aac70e53e80d27453d8a6938d2c";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.71.gate_proj.weight","gate.weight.mxfp4","c129968268419647d4dd758e8011fc30fddf39e78ac104a897fef02beca15820","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.71.gate_proj.weight_scale","gate.weight_scale.ue8","1bdf90995dce984ccdaa25d6797753d5519f48f14ac67f64cb79a2a25d6844f9","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.71.up_proj.weight","up.weight.mxfp4","f6dc3a9e15e2c1bdab80bcaf65ae2def8e62b4221d8d142479c9c8372e85129c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.71.up_proj.weight_scale","up.weight_scale.ue8","e4a7822ea0568dbbccbbca8b059c80405b6d1d61767c18e99f06633947bc984d","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.71.down_proj.weight","down.weight.mxfp4","9e7554bb710d2f33ba47df26418445630dadd7c730f0f25fc5ae59d45688e628","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.71.down_proj.weight_scale","down.weight_scale.ue8","8e5e066b94a666ae12720e2a0a283d4d2eb5fb5b02db3dc33628d2f5c553d3e2","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_071
