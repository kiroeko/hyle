#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_088 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="9ed2eff425418c005fbea6896f2dc244ab44ab3fad14b7911539c1944446a6e4";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.88.gate_proj.weight","gate.weight.mxfp4","385ab25a3aa6f8ccd8d85dfe58ae27259ba10653e5583c71709b09153aac488a","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.88.gate_proj.weight_scale","gate.weight_scale.ue8","9ed893a3673e1ef78186cc44a454a6ac35acce31a8c8eb679a90149644e3dce6","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.88.up_proj.weight","up.weight.mxfp4","7e02088c176369441d54fde0ec32cc1e3f9f040357a740622609abb27e797cba","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.88.up_proj.weight_scale","up.weight_scale.ue8","e39829fcd2197d10ec0016e491c9d020300ff7111de4aec74fad1845ccf5027d","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.88.down_proj.weight","down.weight.mxfp4","244168cd2e67342e4d4983a89a2947c19c5c6ee7bec600e71e50196c046a7b60","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.88.down_proj.weight_scale","down.weight_scale.ue8","43659c9794573400809f74b2562250ddadec40dc9e1b198cc8b8ce6cefc2eda0","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_088
