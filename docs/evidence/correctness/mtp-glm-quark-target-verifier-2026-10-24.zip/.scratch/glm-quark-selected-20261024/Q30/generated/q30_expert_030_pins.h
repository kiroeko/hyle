#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_030 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="5283e2d98db78a2f81a1ff6013454a57a4b08087a3881ce2811f7f329daeb3d9";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.30.down_proj.weight","down.weight.e4m3","e233b9696601d49eec80c7c35b7be493e416e47fc8d07948f59845052be45257","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.30.down_proj.weight_scale","down.weight_scale.f32","e859b2b114e3e4e47440a883ee198e55993cfdc36330b30992cad41f16d0e8f2","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.30.gate_proj.weight","gate.weight.e4m3","20a2a632c59f68ad67287094b30f676b7b61e1f6345bc47df9bf1e8016959ca0","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.30.gate_proj.weight_scale","gate.weight_scale.f32","96bc3f57357c109c5277667232d60e5c4dac834fa5aa705286e6fcdf10a33b1a","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.30.up_proj.weight","up.weight.e4m3","3c39c0fc219133bcc1b61fde4af16a672835bb528d03b9577d31dac9d09b17e9","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.30.up_proj.weight_scale","up.weight_scale.f32","b142fa35e53b22dc8f6015506125bfac614ca8d15979560f68b8d506e696fdc0","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_030
