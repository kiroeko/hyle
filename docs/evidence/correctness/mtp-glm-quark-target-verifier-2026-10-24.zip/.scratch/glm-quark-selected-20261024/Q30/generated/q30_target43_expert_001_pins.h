#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_001 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="428d6b29a1eaaddd537e5232872c4069b2497c04c75f31ed22f421a62c0cce25";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.1.gate_proj.weight","gate.weight.mxfp4","bfc924b20d5339156921fdda5d4ef8e506bcded376442cc2e81e4982ee3e9d5d","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.1.gate_proj.weight_scale","gate.weight_scale.ue8","70805f9416be70c64133b8d9fdfec730801cdff2a6c205c3930e22d131ccf7b9","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.1.up_proj.weight","up.weight.mxfp4","bab0a3a339bd9ca84353ef6472568cc16230266c52e38ba2b9b359c9e96b9fc6","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.1.up_proj.weight_scale","up.weight_scale.ue8","89549a7419583586ebd5824a41cd1e165b4fae46497a038410037db427833a48","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.1.down_proj.weight","down.weight.mxfp4","8b13a732c62b9eb10bb27c8c3335ef0c09b66c9caf3e8d1d592946f721af0c42","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.1.down_proj.weight_scale","down.weight_scale.ue8","e9f378a557cafe722be2790f413bacac4d0510793de9649d1e2296b05bf5051d","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_001
