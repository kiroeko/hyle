#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_286 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="71de528af59a2066557f7996c5a888fbd23558f691410f3294ba8c9b10cc2296";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.286.gate_proj.weight","gate.weight.mxfp4","c62386d4c6d6383576c70c77271d4be52c044f9dae9036d8b21a35c69b2f908f","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.286.gate_proj.weight_scale","gate.weight_scale.ue8","bf41ca30be02ed9fbe29df494d3adc2572fe14ead7f71968624e9c9df188c08b","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.286.up_proj.weight","up.weight.mxfp4","cc483d0ffbbdf0199bc4e0cb4c6f57f7de487fa1c9b187c691d68f39309b0659","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.286.up_proj.weight_scale","up.weight_scale.ue8","b5ee976b1f363384b32b6fb5437ae02abf532dddb83efaf610da7cb093b5874b","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.286.down_proj.weight","down.weight.mxfp4","ef6afbffe0f7622ecac9696bee7d20f08d242f1bb354d0cf3819851f4677f5f8","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.286.down_proj.weight_scale","down.weight_scale.ue8","c831c8d44254b01feb268865a1238e6d28fb77ca011c7b5ff3754e294fc3d384","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_286
