#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_022 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="82d785c8649dab238f8e273642a957f9e777be50f42e13998c2b9a2c8c10ea52";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.22.gate_proj.weight","gate.weight.mxfp4","d7face501593e55cd93425af13e047059a9e438a201c718ae01e35e8b7540cc8","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.22.gate_proj.weight_scale","gate.weight_scale.ue8","b15e397b34ef4181d8296ac190157b374a5f6c50c545924166e377eb020f8503","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.22.up_proj.weight","up.weight.mxfp4","aa755e2032b91fb9ef47167f760dfb43739d24fc4f99f36a71a2e12801d9ea4c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.22.up_proj.weight_scale","up.weight_scale.ue8","4e46467f161fde835e9e7bb75a18698833b5046c80b9c559ff0cd912a9250fdc","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.22.down_proj.weight","down.weight.mxfp4","684c735b77241602495a326dd705f17dba280c4b50e28f5ba480642e98d0e1cb","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.22.down_proj.weight_scale","down.weight_scale.ue8","b89b372c068021bf0f9c45a9b975904632a3642f18ac38f557b89549151a0452","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_022
