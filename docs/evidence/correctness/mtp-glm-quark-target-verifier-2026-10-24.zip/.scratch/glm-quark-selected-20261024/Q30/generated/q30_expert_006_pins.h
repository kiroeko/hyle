#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_006 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="154ec64956628d554162757d4595fafa1a04f90068f8c1915f036c7eac9b6055";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.6.down_proj.weight","down.weight.e4m3","ec8e69299ac51ceb757f1164fd46ec1d0d374199574bac1fca4aa709300c5655","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.6.down_proj.weight_scale","down.weight_scale.f32","2d0f224c4d84be4d9db84f29ba2cdb752b1c82f61b5f6dbbc8a45ef3d9728314","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.6.gate_proj.weight","gate.weight.e4m3","d2265bcb52ef08ebd08ac9c27fa54dbb7c7b73463af84f09d76fef9b2cafa23b","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.6.gate_proj.weight_scale","gate.weight_scale.f32","7b1872fd8d326667a820ca65ed75b41f04abb8a33e2c54a02a29727c2830275b","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.6.up_proj.weight","up.weight.e4m3","83414a34c859a673949ec0815ddcfaf00b86db1b13c86e801588c86bd3f86f98","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.6.up_proj.weight_scale","up.weight_scale.f32","aa0916f3d759f8956a9e1e9aa6d45c5f034abb7070195d2a4d21e1f011b0e44a","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_006
