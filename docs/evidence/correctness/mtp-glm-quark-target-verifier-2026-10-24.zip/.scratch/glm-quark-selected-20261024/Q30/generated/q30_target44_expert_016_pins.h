#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_016 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="ed6d6f98b4c82142b4e3d7cd4fc484d33dd9a6be07fa9084e8a028b7b268af5a";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.16.gate_proj.weight","gate.weight.mxfp4","8b62756ce815d7546033d70f61069df88959fdd023e2e4799b1c3cddef7651cd","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.16.gate_proj.weight_scale","gate.weight_scale.ue8","29acb1f1af76cbeb7406528f5c90d31fe216be2415dda52e2f3eb097c3a7a3cc","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.16.up_proj.weight","up.weight.mxfp4","0a2a05ae6c5a08c1576cf12ac3711ba04441d3534f2beccb963a87be919e3a27","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.16.up_proj.weight_scale","up.weight_scale.ue8","ccb08b5f2800b9dfc6db3ba0aebebafdebff13202349c69698ba85a5af6bdcc8","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.16.down_proj.weight","down.weight.mxfp4","f0ca11c833f1831166d66ae081fca0a0be4b74bad5eb3eede4d7e73964ce95e7","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.16.down_proj.weight_scale","down.weight_scale.ue8","5e6762982195dfb665617e9b6017bcff7c2d1419be9dfcce9918d35090b2f097","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_016
