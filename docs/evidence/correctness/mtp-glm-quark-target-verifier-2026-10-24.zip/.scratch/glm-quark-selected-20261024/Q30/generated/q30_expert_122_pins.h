#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_122 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="6ca533caaa10f0e49f66059e0e65f51a1113762e36149090901881ae362a81be";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.122.down_proj.weight","down.weight.e4m3","61ced328b4abc8eb26ae86b9ec0a47f7ae947d402c81243f64b79355e0795a90","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.122.down_proj.weight_scale","down.weight_scale.f32","10f3f61d30dcb5d3ee0e88b0581413476486a748b0ec6a40f853a59e0725775a","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.122.gate_proj.weight","gate.weight.e4m3","60d8e7c262eb00a245ff67f30a6d7c4f77af8f3e14844abfbcec5f2a493ae8ea","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.122.gate_proj.weight_scale","gate.weight_scale.f32","0fc85767116fb5f812eb1f7c2a66fe864889901fbbd2fed8e0412281850a036e","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.122.up_proj.weight","up.weight.e4m3","cc8f3618ffd70805622078f658555947493420202f66363bf5ee8b161a84dfa9","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.122.up_proj.weight_scale","up.weight_scale.f32","aa240acb683eeae7803f9998d47640ec8d5b68f71d898b601bd60d0bc38ef743","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_122
