#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_040 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="21d2b4acf199f7e612d62ef497c2c416c0da5ede7ad7fdeb0a0d5879e3b71507";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.40.gate_proj.weight","gate.weight.mxfp4","a21ca32b2ff74cb3c32874f7bcb8923c0aef7c88787ee22b0e7d610ea37faa9b","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.40.gate_proj.weight_scale","gate.weight_scale.ue8","9aac9d141c51c9f10dea6ebb8f1516506be0824a33a65bd2d856f072cd02764f","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.40.up_proj.weight","up.weight.mxfp4","1d2064f9fe69c24b47b57d7b14caa714affb4c8c7c4aa41b6d364c8b1317da50","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.40.up_proj.weight_scale","up.weight_scale.ue8","146c7720e57b8cf00b7b482ad52fab750f083522b3b5277bdfc19f58861638d5","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.40.down_proj.weight","down.weight.mxfp4","b282f5369b0550b776eafb2737e477bac2abe85fb17d677998c42509e21b76c7","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.40.down_proj.weight_scale","down.weight_scale.ue8","b6349b8acd36a18924467e26689596f59bfb569bb83d6aa1e98aa282c0bf6cc4","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_040
