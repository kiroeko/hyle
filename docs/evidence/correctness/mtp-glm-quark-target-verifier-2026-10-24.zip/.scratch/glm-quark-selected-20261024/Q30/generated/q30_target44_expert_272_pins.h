#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_272 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="71068bded1c27ffd03c96d54c883ba3ac6d457f27e09577c5080fce60225da15";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.272.gate_proj.weight","gate.weight.mxfp4","b3030921fc6fc54f39bb1f19205d71e99bad9317832019a963bb03018ed1b988","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.272.gate_proj.weight_scale","gate.weight_scale.ue8","e6fcfff7a0dfd5c59704cee7f6bfeda7d1a6d3deb8f61e909a23f8ca14f4f9bf","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.272.up_proj.weight","up.weight.mxfp4","dd71e988882dbe3e1f809f4478933cc8530ef51b78d93cacd1441d50ca702576","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.272.up_proj.weight_scale","up.weight_scale.ue8","6b4c19551c0826ef6803693481076ea61f28e1ccb263292b5b1e6b54b4b9fc4c","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.272.down_proj.weight","down.weight.mxfp4","44b03c7f004ca89cd3464989814cf47160ac75bfaedd874365ed88046e44c16c","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.272.down_proj.weight_scale","down.weight_scale.ue8","67db865d9aebaa25da31f94b4a40cc857eeb0ade71479dea958db55977a2920e","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_272
