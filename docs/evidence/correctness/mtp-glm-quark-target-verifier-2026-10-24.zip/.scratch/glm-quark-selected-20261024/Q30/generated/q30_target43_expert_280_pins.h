#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_280 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="9b817e320af64a363fa0bec64a8786a291d5b4962c4823df1c154fb931d9d1f3";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.280.gate_proj.weight","gate.weight.mxfp4","fba3809267eab4361300e1e71af8f8f6f930200cc000067eb21648111479ffd9","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.280.gate_proj.weight_scale","gate.weight_scale.ue8","28ca014d097a2f5da6e597ba17a53b8c0620193a6c9adca11b6e8b808440a99a","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.280.up_proj.weight","up.weight.mxfp4","9346e1db51c43bcd978d344b30c0611e744de03766992d72d17efbcc5f09d904","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.280.up_proj.weight_scale","up.weight_scale.ue8","963db4d3fe54ffb85712f0721a8224784794654e0d7e7104be4bfcf28169c08d","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.280.down_proj.weight","down.weight.mxfp4","cb6076abefd97175bfbb8a55a8c4a1a7cfed5d8cd9ca9da417e2e0e87c2a249b","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.280.down_proj.weight_scale","down.weight_scale.ue8","83b74553bb35ce1827319c98de45129ac3efe05377df6cb0cab0a71e4743b722","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_280
