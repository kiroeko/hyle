#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_254 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="9e398e8d44102865ca99b76da293748aa26a3e5db29280dabe3e7571b0cbffb7";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.254.down_proj.weight","down.weight.e4m3","ce0a7deab79fef38b9806a44b666a909cfdae5bba12ec1469422f7d89dc9a5b2","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.254.down_proj.weight_scale","down.weight_scale.f32","0cc58a400a4906c689ac9581c2aeecc14d4381f3e11573fb5980860cc16d2cdf","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.254.gate_proj.weight","gate.weight.e4m3","60cd699e2bbb55a6fcddf504c3a6dbd2b1249363c7579556b7597d2eac0c5da4","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.254.gate_proj.weight_scale","gate.weight_scale.f32","eafd46f9e749f20c8b4552db9113da8e67acd73e17bf28f326caaaa38def1ea9","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.254.up_proj.weight","up.weight.e4m3","212408398d81fbb3cf722c6b54889bac94e7249975b7f86d0583d9e7d9f9a4d6","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.254.up_proj.weight_scale","up.weight_scale.f32","1d2cf277cc70138c3eeaa253b9a419390135b65de47efc2a8c3d59af0a3df7a0","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_254
