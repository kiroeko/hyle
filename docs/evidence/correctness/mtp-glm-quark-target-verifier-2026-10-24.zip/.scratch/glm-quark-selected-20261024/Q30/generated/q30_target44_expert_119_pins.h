#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_119 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="1ec89d2db7c77234f9981fc689620d40c1f2f13a080ef59ef8eaafeeab9cebe9";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.119.gate_proj.weight","gate.weight.mxfp4","69e16b94238fe734969e1c0d107993db6062b4a34aef332a16aa1a7dbb5538dd","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.119.gate_proj.weight_scale","gate.weight_scale.ue8","21909ffbecc050e52cea1632003ea6ac7b4de545946af40d353ee87148156ca4","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.119.up_proj.weight","up.weight.mxfp4","5a6947b4623eb67a9a42054c9d4498774c6c0bd9025814fb9ba96ee0bd280f67","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.119.up_proj.weight_scale","up.weight_scale.ue8","0cc54308b3194619cb9a02c366f510bfc4d4de50c0ebdd2477559a4b8822e0cb","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.119.down_proj.weight","down.weight.mxfp4","b5a200d71633a2d2a7181a311aeb56a449a31dc567fd2af96c16fc97ce92061e","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.119.down_proj.weight_scale","down.weight_scale.ue8","a2a130983b35892738f0a7e4709cf234c9173224e49bfc1a57494bc7999077e4","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_119
