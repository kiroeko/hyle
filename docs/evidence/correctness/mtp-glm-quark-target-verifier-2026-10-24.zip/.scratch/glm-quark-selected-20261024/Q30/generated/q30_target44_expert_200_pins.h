#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_200 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="2759483a2854b08052c11f52570757e4c56aa67dde182cfb3343b579abc9908f";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.200.gate_proj.weight","gate.weight.mxfp4","c4247a0653085b457ce733d1edacc5caae3e7810218c403dc51b0f12ceba3423","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.200.gate_proj.weight_scale","gate.weight_scale.ue8","d0d46bd53a5647440a95d282be977cde011c766bcc40c6db8da908a0ab8e5fdd","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.200.up_proj.weight","up.weight.mxfp4","c9169e6358330bcfd6f6ef0cddd8903cdcff9102dcf4e72962fde7b5333d2f5c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.200.up_proj.weight_scale","up.weight_scale.ue8","c5b11a0197cf7a883eea061df1834707adab4b72ba1680e58557b9382a164860","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.200.down_proj.weight","down.weight.mxfp4","8cadfe9feaa2781a87e0d5ddad3ffffe235e9200c9cc992761eeea6d22cb86b2","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.200.down_proj.weight_scale","down.weight_scale.ue8","d6151a145aee482d3dc0cf4af44f5612fefca4b1612ff946e531a5c4e648ac4e","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_200
