#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_static {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,2> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="a25d372b9779b7188a030d9687f3b3c1c980084f80e9ae7e5ae30c3aa4d9e94b";
inline constexpr std::string_view kExpertPlanSha256="c62da6b456bc0ca148d717b24bd5645ec4e50701b38c7f17c4393c45e5c07d34";
inline constexpr bool kBaseRevisionKnown=false;
inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{
  "amd","amd/GLM-5.3-Flash-Quark-MXFP4","glm5-next","GLM-5.3-Flash-Quark-MXFP4",
  "b5688f25491202978c19c4d036eef579f61bbe07","3a2c766e6a5256241b0b6ad82bc07e65bf4881b7211a0484cf18ce7020bfbd8f",
  "amd/GLM-5.3-Flash-Quark-MXFP4","b5688f25491202978c19c4d036eef579f61bbe07","Quark-MXFP4",
  "1a91c7f25ab61e7a0e537b047075d91537441e43263be01faf47d8b895f302cd","safetensors"};
inline constexpr std::array<PinnedRole,34> kRoles{{
  {"model.language_model.layers.43.hc_attn_base","hc_attn_base.f32","b95e45dac4eddaf979e5f90ea42ff599ca91b1edefd57485350f8b1ca2f1226b","F32",{24,0},1,96},
  {"model.language_model.layers.43.hc_attn_fn","hc_attn_fn.bf16","4070a1fe33f2e95178aa92fca292c0f0102f591194e393821b59389b6db63d73","BF16",{24,16384},2,786432},
  {"model.language_model.layers.43.hc_attn_scale","hc_attn_scale.f32","d2a40c7cc9d8189d439d482f54e38d734ae62fa7636d6c860ffa62d6b17f484d","F32",{3,0},1,12},
  {"model.language_model.layers.43.hc_ffn_base","hc_ffn_base.f32","19af9c4158561db1106e7fc15ced68755205b1b007d149784425376dedaee022","F32",{24,0},1,96},
  {"model.language_model.layers.43.hc_ffn_fn","hc_ffn_fn.bf16","800dbe6e6cb08d60d8559b6453985584b5559eff22eab3c0347eb879f01df8d1","BF16",{24,16384},2,786432},
  {"model.language_model.layers.43.hc_ffn_scale","hc_ffn_scale.f32","79f53704021df20fd2bd69f7d63a438f281a8fa5a88b321409f6c0d763d8d33c","F32",{3,0},1,12},
  {"model.language_model.layers.43.input_layernorm.weight","input_layernorm.weight.bf16","83deadc36c0d4cb49376e9a76f67964c53f2c1b2610e39c96a57243c6d4767b5","BF16",{4096,0},1,8192},
  {"model.language_model.layers.43.self_attn.q_a_proj.weight","q_a.weight.e4m3","31feb1d307d0046f847f6576f1ec3d8f3ee9190a4820b253c06178f6552394d1","F8_E4M3",{1536,4096},2,6291456},
  {"model.language_model.layers.43.self_attn.q_a_proj.weight_scale","q_a.weight_scale.f32","882586f237a1dfd3a7e21b9ad537d059739cb2af4cf67d615619700e131d9f70","F32",{12,32},2,1536},
  {"model.language_model.layers.43.self_attn.q_a_layernorm.weight","q_a_layernorm.weight.bf16","3c1820761e31a221f7db8cf02268e982da1eee237eadbfe3daee999888bd6a05","BF16",{1536,0},1,3072},
  {"model.language_model.layers.43.self_attn.q_b_proj.weight","q_b.weight.e4m3","f25d9c90fae9246b1faa736968cb2ba15bf12028cb97ba16bcb8d0d3c72e9272","F8_E4M3",{16384,1536},2,25165824},
  {"model.language_model.layers.43.self_attn.q_b_proj.weight_scale","q_b.weight_scale.f32","1935561604fe8e93cbebc6fbe75918a7cf362c21f25949b2f12ac7d2c03964ee","F32",{128,12},2,6144},
  {"model.language_model.layers.43.self_attn.kv_a_proj_with_mqa.weight","kv_a.weight.e4m3","06d3d83403b2fd3da16e7e9d991145628886c41a73664211be6c6f5c87cd01cf","F8_E4M3",{512,4096},2,2097152},
  {"model.language_model.layers.43.self_attn.kv_a_proj_with_mqa.weight_scale","kv_a.weight_scale.f32","b80caa10b610fcd8890c12399d299de17f7382f7341e31fb94ba9eb27418dd64","F32",{4,32},2,512},
  {"model.language_model.layers.43.self_attn.o_proj.weight","o.weight.e4m3","8e153c8adef30a480e44396f7c1ae3c09a694268e7402859bab6fb26272591f4","F8_E4M3",{4096,16384},2,67108864},
  {"model.language_model.layers.43.self_attn.o_proj.weight_scale","o.weight_scale.f32","53981a5b2e0b56b9a3445950b6ef44a65175192330efa1ee91558340951a6d40","F32",{32,128},2,16384},
  {"model.language_model.layers.43.self_attn.kv_b_proj.weight","kv_b.weight.bf16","383a3246c5985b8a8c8ee7dac6955ce3292746b19f54687f1a5d564b2f403522","BF16",{32768,512},2,33554432},
  {"model.language_model.layers.43.self_attn.kv_a_layernorm.weight","kv_a_layernorm.weight.bf16","f11ae45b3220a86879ed24b22db77a958a97501c706fd9da6f800112a1fe7a78","BF16",{512,0},1,1024},
  {"model.language_model.layers.43.post_attention_layernorm.weight","post_attention_layernorm.weight.bf16","d5a0aff5e2533d698e1958f881a55120448e8ac0aa5cc291b83a1eec622f852b","BF16",{4096,0},1,8192},
  {"model.language_model.layers.43.self_attn.indexer.index_kpool_compress_ape","index_kpool_compress_ape.bf16","4af70e57e3ece6448a410f7800e046ddfdb32d6fa835925360404060bafbd991","BF16",{4,128},2,1024},
  {"model.language_model.layers.43.self_attn.indexer.index_kpool_compress_gate","index_kpool_compress_gate.bf16","2bda06ad717874478f2413dd9f5d8484097686e967e5cd05ca39aac712acb840","BF16",{128,4096},2,1048576},
  {"model.language_model.layers.43.self_attn.indexer.k_norm.bias","k_norm.bias.bf16","4998508622c40255ec31824d8db73c7efcac203f4d9c7771542ade3caf87bcd6","BF16",{128,0},1,256},
  {"model.language_model.layers.43.self_attn.indexer.k_norm.weight","k_norm.weight.bf16","25b5022f401267c722ed328f5f8157a2888c2e14f30711f0a69fd6ff06683ae1","BF16",{128,0},1,256},
  {"model.language_model.layers.43.self_attn.indexer.weights_proj.weight","weights_proj.weight.bf16","610c0972a246f0e3fe0066238bf43160dc2b81c6c7f0420634970deaa89a781d","BF16",{32,4096},2,262144},
  {"model.language_model.layers.43.self_attn.indexer.wk.weight","wk.weight.bf16","596d10661e1ba868e4d26d59f0eabe3d15eefafcde4f656a2d122da42b8cd24d","BF16",{128,4096},2,1048576},
  {"model.language_model.layers.43.self_attn.indexer.wq_b.weight","wq_b.weight.bf16","12a9693f54ef865d8eb974f9e6d3e9e42cde50652d57017a30a249b6ea202052","BF16",{4096,1536},2,12582912},
  {"model.language_model.layers.43.mlp.gate.e_score_correction_bias","router.e_score_correction_bias.f32","2923b02092b43f669e79cb8d15ff6784de30328e177690ef65ec99d7c55501ee","F32",{288,0},1,1152},
  {"model.language_model.layers.43.mlp.gate.weight","router.weight.bf16","e7f977a6bdb5b5c908b102f5f9c824cf8f6bf766a2e9fcf5e897c6f4a43141fc","BF16",{288,4096},2,2359296},
  {"model.language_model.layers.43.mlp.shared_experts.down_proj.weight","shared_down.weight.mxfp4","daade12fda8c62c7b001bd3c85eeb0a47c6c2a15159206d0833ae9a0d8adb100","U8",{4096,1024},2,4194304},
  {"model.language_model.layers.43.mlp.shared_experts.down_proj.weight_scale","shared_down.weight_scale.ue8","64b1763e24ba8de9c21e5712ec49bb904a67252bf4a4b5a001d2f63525acd143","U8",{4096,64},2,262144},
  {"model.language_model.layers.43.mlp.shared_experts.gate_proj.weight","shared_gate.weight.mxfp4","acbf995b3eaf99f6bb543dae274181d908dedf1773bdee9b02efe189d474a3b0","U8",{2048,2048},2,4194304},
  {"model.language_model.layers.43.mlp.shared_experts.gate_proj.weight_scale","shared_gate.weight_scale.ue8","dbeab32682da3766e4ddb1f2b64ebf5502a01a6b413f46b7030e5b5c5e6ae030","U8",{2048,128},2,262144},
  {"model.language_model.layers.43.mlp.shared_experts.up_proj.weight","shared_up.weight.mxfp4","2bca88331fcc02dfed0bd856680f6b33400d630649ed9d04ea93bfcfc46fe022","U8",{2048,2048},2,4194304},
  {"model.language_model.layers.43.mlp.shared_experts.up_proj.weight_scale","shared_up.weight_scale.ue8","5e4773fa4675397e3d7ebffa75a814a4978235f1403f10852cf0b2febf5f6cc6","U8",{2048,128},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_static
