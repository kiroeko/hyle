#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_109 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="8bf15fa46356d8b184518d6e26086eafeadcf5d59b7af4a666f76c2b6d5b43ab";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.109.gate_proj.weight","gate.weight.mxfp4","71da5d5c5f725f7177a46131726bbd33912c41d0bceb2aa2e03d9a3fd91c1356","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.109.gate_proj.weight_scale","gate.weight_scale.ue8","76bff8c44996b607e34d06aafeb35ace766cabef8985d810abb637610fbeffdc","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.109.up_proj.weight","up.weight.mxfp4","926e41d292c77d1d69776b488f91251f429d0491be56668f596c11d0e0d3adca","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.109.up_proj.weight_scale","up.weight_scale.ue8","849e6b7558cc21aaa854b3a524763d8f460d00273d8d860a75bcf1d77bc560b5","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.109.down_proj.weight","down.weight.mxfp4","2f6b4291aa40bcc6f979c4fd6f7a53faf35784a0149d1908a158634f1134eae8","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.109.down_proj.weight_scale","down.weight_scale.ue8","55511fa4bf01d94bcba20a34f1e3ba7cc7205e8c51b183cf1ffac6ad82a6a01b","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_109
