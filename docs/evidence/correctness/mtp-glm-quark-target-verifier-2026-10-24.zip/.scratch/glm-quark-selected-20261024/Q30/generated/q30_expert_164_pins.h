#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_164 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="5be3c5ededfaebe5e43c451501bedf72e42cf80e294f1187faf732352926390f";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.164.down_proj.weight","down.weight.e4m3","f78c5b06a43619e59c796b98b110c6a360eff60f346a50a53021a6f13e77a586","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.164.down_proj.weight_scale","down.weight_scale.f32","ca196e35ee5e2e91cbb4f6c2576f45b9a65981df6de1a3e4067cf6014f7fe755","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.164.gate_proj.weight","gate.weight.e4m3","21612ebbd5bdad1935483c8b3a8e00cffe8a08d4ebb401c6f643bb23b2c4b8c8","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.164.gate_proj.weight_scale","gate.weight_scale.f32","effe780ed3672d968324d71ae66b58f82dfb2f93f91e7964ed8fea842229f354","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.164.up_proj.weight","up.weight.e4m3","2078c054b1e8b2a49e367d1fc1ea0bc2d80c461069632c196b603b3f76e831a1","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.164.up_proj.weight_scale","up.weight_scale.f32","417319cbd7ec7941db3b3d335075143baedfe5c019acfab1561693bd3a464cea","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_164
