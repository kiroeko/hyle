#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_204 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="93aec159007c8f84592b20f9480c3e1a774d1a075356893feb8896a3011fabc4";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.204.down_proj.weight","down.weight.e4m3","e198ea8487a24dca1d491dba1031dd2f223886f69bd7c13c3ee7680f542451bc","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.204.down_proj.weight_scale","down.weight_scale.f32","b40247a349dba01e4dde69d0d512005eb9079985233f6de65dd230b7c823a911","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.204.gate_proj.weight","gate.weight.e4m3","ff91ec86e721ff3cc6e754ff786b9979147c423f9296bd6d31c33d96a3f6e8f8","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.204.gate_proj.weight_scale","gate.weight_scale.f32","b3abf402296872b3cd988e97fdab7778b3dff4d29d10e0b0cc0f342990d90326","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.204.up_proj.weight","up.weight.e4m3","16d1f4f01c5aaceedf46c8175228a50d274c06d575373a5a64f7140c551a9c46","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.204.up_proj.weight_scale","up.weight_scale.f32","a7781a7eb855c4a527223d53c497261d4ed8a94149531a185ed9e4e41ad37ec2","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_204
