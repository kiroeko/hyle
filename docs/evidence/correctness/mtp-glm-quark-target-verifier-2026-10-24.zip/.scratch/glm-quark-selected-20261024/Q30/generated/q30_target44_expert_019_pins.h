#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_019 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="e203d87b8255bda3b06ffad60d6b1561ce9df177faecec1b39eee6206a0ae540";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.19.gate_proj.weight","gate.weight.mxfp4","87b8e1290e0ff2935dbc883e281aba7f47f5e5a455105cb5620047c7ec6cee16","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.19.gate_proj.weight_scale","gate.weight_scale.ue8","cf5cc8191658f01af5fcf19df9aebd946a40f98ec3216d6fb5c09cb9d3fbefc3","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.19.up_proj.weight","up.weight.mxfp4","42012a931fafbeb165f894bdb99808b5fc73965780a80b77d500bbc52fd7e279","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.19.up_proj.weight_scale","up.weight_scale.ue8","c6e80c642c086cc174cfc8b5491bd4df420b60c51c6d622bf34ccfb2ff663b61","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.19.down_proj.weight","down.weight.mxfp4","4a1b0715dae2ab93d8d4e7a1b825859e79955d57f0d4558d441abf7a66b368c7","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.19.down_proj.weight_scale","down.weight_scale.ue8","b7e5fdfc00bf69ebcf6327f9108226f0a8d6df8b3d14a0b4318684eb5aab4ddb","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_019
