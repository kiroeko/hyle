#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_208 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="dc6a7e33d5c82add33a1f11728907405804ae19d57eadd7c1f82ee91ffee1e59";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.208.down_proj.weight","down.weight.e4m3","a0b4d639e54f4e4219a0f3e1dca94b79f24635e0c5b3ee695b53cea87e33a7be","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.208.down_proj.weight_scale","down.weight_scale.f32","23fe77e9b3b49683a9b75b8365a878b929fa6e239a16dde0c1b5b7b318adac1a","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.208.gate_proj.weight","gate.weight.e4m3","75b702f2add830e0bcf1c70fd0c80d3921a6104d05cf3d093c1b9b32365cca85","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.208.gate_proj.weight_scale","gate.weight_scale.f32","fcdb382ee2e472e731ac54ec6aa0fcd0bf26abda998a21f2da8eabcdcb700418","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.208.up_proj.weight","up.weight.e4m3","23bc135da192dffe5f5388e0768f70291ce240937aad24c78032ca082f7f5767","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.208.up_proj.weight_scale","up.weight_scale.f32","07ad86109ff6c68d870b7a429c9e5766f1511c8c04b80be8afccc431bc603d76","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_208
