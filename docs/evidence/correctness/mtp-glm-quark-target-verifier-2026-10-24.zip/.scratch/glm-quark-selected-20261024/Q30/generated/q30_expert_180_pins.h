#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_180 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="a8a5ea04d81c445ff072d720a2fc9bd091a91f310b651c8ba56df2e73a0e7d4e";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.180.down_proj.weight","down.weight.e4m3","e853b17506da6635004f646147cf26862bdb00cf19bc5a86aca52731cb8a8762","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.180.down_proj.weight_scale","down.weight_scale.f32","2db908237185a1b67bfdc9606a3035f2c09a6cda9e4e142a01d8244fc49c7335","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.180.gate_proj.weight","gate.weight.e4m3","c2bd22bc3f3164dae2e4d3d37f9538446a1403991262aa74dfc81a46a5ae2e3d","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.180.gate_proj.weight_scale","gate.weight_scale.f32","b5012a917a4a22c639d59ebe0c1e403d3223bc2183a0faf163d50938cd6c7519","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.180.up_proj.weight","up.weight.e4m3","3771f8cac7d5f27b800da85c2075d71245d70370cd6356993a6dca2445e50734","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.180.up_proj.weight_scale","up.weight_scale.f32","a5c652a73e980ec1c989a98b911165772ba741060181884b91646a22e1fa9831","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_180
