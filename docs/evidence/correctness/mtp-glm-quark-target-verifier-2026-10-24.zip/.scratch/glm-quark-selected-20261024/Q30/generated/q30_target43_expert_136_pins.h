#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_136 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="aefd1030db12c80555d6ef921395829b5ae3cded7ff91a5653a93647683ab6f6";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.136.gate_proj.weight","gate.weight.mxfp4","bce343332ceb4e61723b124d6edab6fb4b7c93e71b6559ab21c9a7deab25ad78","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.136.gate_proj.weight_scale","gate.weight_scale.ue8","fa074b3ad8a6f8e5f1d99714eafb3176ef89ff8f7cb6531e5790789e757b4a52","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.136.up_proj.weight","up.weight.mxfp4","32f28b98788c5d1c5168857cc3382d821871302a69b308a581363c9c592e162d","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.136.up_proj.weight_scale","up.weight_scale.ue8","1c7f1621c44f353dbe48e4034947db65120afde0c7ab7391064c2d02b425264a","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.136.down_proj.weight","down.weight.mxfp4","5a1821de9684b8b38ca3ac3ffe40f227924b4a8733781f175d67da5899fc9501","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.136.down_proj.weight_scale","down.weight_scale.ue8","5520404988ac09e830a379722e7d1e0427bb6a7603efa9a2110e15a53e34c47b","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_136
