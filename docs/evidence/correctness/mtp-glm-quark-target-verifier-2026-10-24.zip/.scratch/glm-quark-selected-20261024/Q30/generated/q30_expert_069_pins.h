#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_069 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="310f32afdfd9f53ab67a7190acab396c5ea46c013a1de51a7c8fbf12f3c40fbd";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.69.down_proj.weight","down.weight.e4m3","bfc5b3e47bf4f136ad0f24e2d8243e46b97ab42cd2597eccdbfdae84a665d63e","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.69.down_proj.weight_scale","down.weight_scale.f32","f3ef8fcd0828b36196a6315a8e0eaf987ec3e0ec68d7d3a88127ccb4ff40f96d","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.69.gate_proj.weight","gate.weight.e4m3","2966780e5e1e12b0cad743f4f072ba3a9136128ee64b788c82b0e30abfde8645","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.69.gate_proj.weight_scale","gate.weight_scale.f32","585c2ccd3ab389100e47503d23202fc8db98a82d331e6a00ab6dc59d0bcc742f","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.69.up_proj.weight","up.weight.e4m3","c3350d93ac7fc4e5674c727e61c77fad133272bb2b56cd703e9383f5b94676c9","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.69.up_proj.weight_scale","up.weight_scale.f32","70046fceb6acf26015b328d320bf0eca0538874c23cfd0e56a58d8c111d7bf7d","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_069
