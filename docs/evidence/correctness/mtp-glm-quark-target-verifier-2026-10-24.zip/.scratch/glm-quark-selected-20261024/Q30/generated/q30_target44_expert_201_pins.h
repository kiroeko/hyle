#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_201 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="e84f8e70aa3992d5ca8eef28b41ae52ba96b50d3a46b4a2892b283479b12c2e3";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.201.gate_proj.weight","gate.weight.mxfp4","33d5938d34df8341db9fd871f048c4e587e193cb4698647487b25def84df48d6","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.201.gate_proj.weight_scale","gate.weight_scale.ue8","d18b18218411f1fb28c8a2a9eac21480052d5c67a866627d1ff6aa83607b0e24","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.201.up_proj.weight","up.weight.mxfp4","c8db0e5be2931960e61dc4f1ed497e5bee8eccda06b82042f4066b14d1398205","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.201.up_proj.weight_scale","up.weight_scale.ue8","eff31049e75f15fde8d201e536c0b927c0579cb0a5d5bb16f80b4053e5ecf709","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.201.down_proj.weight","down.weight.mxfp4","a9d4a1d6ec89e07274333a27b5b4838f6feeb5cd4e6bb78bb03b82acf0fea475","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.201.down_proj.weight_scale","down.weight_scale.ue8","040ec60d03916191d03da01794f19d88ed2108779834ff4c47d824aee4e926a9","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_201
