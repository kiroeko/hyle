#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_282 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="3a8506033601632cd7e63159ca55218e8746691c5b46daa7828e10e278683c36";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.282.gate_proj.weight","gate.weight.mxfp4","4be0ba467581abb3847c9b3ce806d1da5dd94891fac3b2d73e77c911f23ab909","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.282.gate_proj.weight_scale","gate.weight_scale.ue8","386c05f487f0b0bd9dd78fd82aae714a1fc4ede69d6084ab981100036a59b27a","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.282.up_proj.weight","up.weight.mxfp4","267fa2b0ea04fbf73e0d69f71af3add2715abaa9657753f54dbee71f37ff9b3d","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.282.up_proj.weight_scale","up.weight_scale.ue8","85598ffe6637e50e7b960471002d7b0ce7a3a16c232148b1c042c4762121c952","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.282.down_proj.weight","down.weight.mxfp4","5b4183f742e03b3e5f7e668425beae6fca9bef1d37f9ed9892cffbf1578f21f4","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.282.down_proj.weight_scale","down.weight_scale.ue8","851ef6cec2be802b76f763916663f741fa063a1e21422d2e03ea0f215cb9e2c1","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_282
