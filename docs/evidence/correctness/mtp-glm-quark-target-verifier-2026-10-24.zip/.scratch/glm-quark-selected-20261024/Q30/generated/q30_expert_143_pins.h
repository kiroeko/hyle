#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_143 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="dfb38a80e3d54721d06ef65a11b3508967e573faa6f2beba20d3b82f70c8fcaa";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.143.down_proj.weight","down.weight.e4m3","d2f444e6875f5fd84617eec57161faec3e4f2a57ace55274aa596ef3cca95b14","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.143.down_proj.weight_scale","down.weight_scale.f32","97235b984c6d1d1bf173f4af14946bc693d788327f1fa6d98c41ccecb351a65e","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.143.gate_proj.weight","gate.weight.e4m3","a5c4a7e87a2b59d1c11b0459b43bbb78b58a063d24a9c84f6b87f90726719de9","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.143.gate_proj.weight_scale","gate.weight_scale.f32","21c3f1207e038066c0a30127b8353448e5a6cf473a344deb1e767f84a6683a79","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.143.up_proj.weight","up.weight.e4m3","78ea1a84be8e36ab61a8d39b19379efd4a2df8d3c60e851c7b80b063757ef9bd","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.143.up_proj.weight_scale","up.weight_scale.f32","ce0e6ea7aaaab1d8dc1ac1b9d99bab81b6d84ca525a383bb5d9a320b26faddd4","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_143
