#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_098 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d293d168bd3679db0bf5372a711cf4cb8dae4709741014018c172ef7e595c1e6";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.98.gate_proj.weight","gate.weight.mxfp4","31a67564a9e722655dd2be9fcbc0908e43ed78b139e22c904198156349cec086","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.98.gate_proj.weight_scale","gate.weight_scale.ue8","2a5fb6926dcac65f53d3fc404063548b8b63a21247cbbe4387500bb8ea49c180","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.98.up_proj.weight","up.weight.mxfp4","2b4406526090b2dc1cff05bd140800a2546c0698ef8ed1d56333070309246799","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.98.up_proj.weight_scale","up.weight_scale.ue8","637d577f1f7b16b272b7b6132dd69c4a6c1a695f7f51275e47f365a1f42c3716","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.98.down_proj.weight","down.weight.mxfp4","cf19a40e9ff784fd208aa59f24947c75d330ccbf616251fb7606fb9d94fd1343","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.98.down_proj.weight_scale","down.weight_scale.ue8","150267e1589e4fab7b9b1505e6d70fe4cec64e934ea9a7f853c73b0dd9d3b9a2","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_098
