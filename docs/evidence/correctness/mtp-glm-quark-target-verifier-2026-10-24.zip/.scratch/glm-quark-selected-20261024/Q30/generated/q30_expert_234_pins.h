#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_234 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="1dda753fb55cfbc68f9e0fadf203091c5958d3fd81983a266bb2957df7bf4553";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.234.down_proj.weight","down.weight.e4m3","51281ebf677330b80ad07942d82fe69f1277418fd342bd43eb7a0c84872dde55","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.234.down_proj.weight_scale","down.weight_scale.f32","16a34b04cea875b8b1a3007ec128c0ce3404514ef284837b0b50df27d28565dc","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.234.gate_proj.weight","gate.weight.e4m3","27800d627e7beee649325ccf3c183ed7c372373d723752b1e66b8116045f76db","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.234.gate_proj.weight_scale","gate.weight_scale.f32","7110b28fe104f9d0a9ca203ea045066a4f5315b946aa109e314f35b7dba50734","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.234.up_proj.weight","up.weight.e4m3","49695814651efb491430f250eb3b9cd720ff805da03cb2881bb1488781b590d4","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.234.up_proj.weight_scale","up.weight_scale.f32","8e0a367d9f0fdb274ab4d6c25515e12b1cc6f6426b8f18a8be5515f01c01532f","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_234
