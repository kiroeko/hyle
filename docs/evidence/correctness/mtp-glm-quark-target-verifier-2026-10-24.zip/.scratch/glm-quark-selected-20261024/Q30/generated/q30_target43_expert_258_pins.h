#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_258 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="52e0bf463616a0aeb5c6fa81396d164c3d51f87af29362ced9a2cb2c5b7f6b3a";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.258.gate_proj.weight","gate.weight.mxfp4","647a606161cf1840061b72dbc026ad245c77611dbaff896906049a4d01fac875","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.258.gate_proj.weight_scale","gate.weight_scale.ue8","732c331f69e0e9a0494c8e51ce1640fe0173acae40fdcf323d7a422719c27c9c","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.258.up_proj.weight","up.weight.mxfp4","debe885c17c7965e0e7afae9819bd65f5baf5070d454366ce7ff23df44721a23","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.258.up_proj.weight_scale","up.weight_scale.ue8","4298d58041dc06ba017299ed6939e1ed85e40609177dd202a5ace2cb0e8d2d85","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.258.down_proj.weight","down.weight.mxfp4","6ff8129d67353378116aa4c6c79dd621f599890e9ca982ded8911fbce05b8f37","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.258.down_proj.weight_scale","down.weight_scale.ue8","b566184c67d7df1603d303a02664f21d11d62fad12ce76f6de80c115de75d596","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_258
