#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_107 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="cd237c87a8ed6bad0ed193fbd39a9a7e89b02cc1b2a8edb19c66dbff7fcc73c5";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.107.down_proj.weight","down.weight.e4m3","ed9eaf9fe7e57f26be5ba33b382a9869ae8105c41bcc3297c25a4dc81e55d7db","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.107.down_proj.weight_scale","down.weight_scale.f32","fcdc2828b533b506ec5d82b7720eb78a2d563df3ad79aefc7eca7754818fcc5d","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.107.gate_proj.weight","gate.weight.e4m3","c4628dc29f5bd74e739188c9e675a0cb6afcd1da76496122c644fda17e16fd73","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.107.gate_proj.weight_scale","gate.weight_scale.f32","09b5c1a2ea247bf40d383775c9b40a3278d6fda8cad52851af4d74d3c3370679","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.107.up_proj.weight","up.weight.e4m3","be93c838fc14cbd3a054585e6516661109223b47d181691a579c854ba50029c0","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.107.up_proj.weight_scale","up.weight_scale.f32","304da127f68f1147615f1d680b4e1b26ac4974f1888157074a9aaf25cfbd8a87","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_107
