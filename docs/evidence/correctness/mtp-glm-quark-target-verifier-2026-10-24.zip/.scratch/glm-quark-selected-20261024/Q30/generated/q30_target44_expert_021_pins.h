#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_021 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="d41fac2fa8a743ffdbc825bcbca706dd83251cd0748bd9b29dd4c07cb4be542d";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.21.gate_proj.weight","gate.weight.mxfp4","0bc6a08f6a7166d9d394c4ee921aed960e4ee2f9108dea11c880ff9379d02f55","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.21.gate_proj.weight_scale","gate.weight_scale.ue8","6f687b2b800e7c04166b6f36c3a78a0de5465311c2af03833cd92ab732cfde4c","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.21.up_proj.weight","up.weight.mxfp4","8a7c242cbdf248a2a4cfe1af3dfd439164c39068833a73f126f5c636bfae4866","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.21.up_proj.weight_scale","up.weight_scale.ue8","2261ab9dc4fd8a706b23ce47040ccbf91c44d9b6b6bc1021c3a9fcf456fe5e72","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.21.down_proj.weight","down.weight.mxfp4","04fdaa23b03a78d38644866b41ef28ee1bd8f85c1b3de88c1755d6c84f53a0e1","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.21.down_proj.weight_scale","down.weight_scale.ue8","9c734cbf048e6fb833411101d31b26691f933d190b24638153a178184993b1c9","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_021
