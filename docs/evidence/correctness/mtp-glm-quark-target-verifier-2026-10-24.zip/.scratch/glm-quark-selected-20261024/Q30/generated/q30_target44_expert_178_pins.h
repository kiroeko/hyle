#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_178 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="bade5ddaff681af4081df709aa76085c85516850dbeb3f4a86e6d2a03645bb8a";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.178.gate_proj.weight","gate.weight.mxfp4","604560cf8f79708a0ca8e3759b023636c03e9e3962c60f2ca3e9289fcc4f6a0e","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.178.gate_proj.weight_scale","gate.weight_scale.ue8","be67d19930e81afcd6c740464980bea4d694a658b047b1a36ea2c84647e457f3","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.178.up_proj.weight","up.weight.mxfp4","202028d3eb959abb334187ae09c47760df2a5ce123367738bfaa99155e096642","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.178.up_proj.weight_scale","up.weight_scale.ue8","a32397faba18b5b368687b6270b159511911a2fb34d585d28e04de6b48389599","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.178.down_proj.weight","down.weight.mxfp4","fe3f2933e5ac652f028e2228b95b5a999241be21b9df9f73889f30be81e0f06f","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.178.down_proj.weight_scale","down.weight_scale.ue8","1c722f8d86fb99be4bceda756cf976520b468e3e3fe6307151911bcedba72c3e","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_178
