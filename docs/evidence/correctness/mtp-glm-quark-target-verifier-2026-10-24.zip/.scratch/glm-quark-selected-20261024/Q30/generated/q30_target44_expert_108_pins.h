#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_108 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="f98fe7ee710a9ebd3815b0168af6b5f409ef64c56e4981c33da28f55520e4edf";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.108.gate_proj.weight","gate.weight.mxfp4","f93c04d7625b1a32e8debc7755a0a0e625a29cb919266f9c33f1430904de3ec7","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.108.gate_proj.weight_scale","gate.weight_scale.ue8","78d0034978f0b996b6ac4b7aecb86f7e053311a421eeddf863d03b5d6f87767e","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.108.up_proj.weight","up.weight.mxfp4","b181984547964d45d2844450e1b728c350e1f75022a509cdcc6495328147a6dd","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.108.up_proj.weight_scale","up.weight_scale.ue8","ca35e6e53e9eb8dc437eede56cdb553a201a3279a2a89d88e93cbac8f5f3ccf0","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.108.down_proj.weight","down.weight.mxfp4","2ac32588480af2416ec1f1d25a6fbc3d29f513909ce9f629a9d293ffea8276f1","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.108.down_proj.weight_scale","down.weight_scale.ue8","b4b3aa271851bdf9c2c4c176ce0500f9f1a495a267129ed4bb6cb6ced5e7433d","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_108
