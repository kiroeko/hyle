#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_276 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="e9b1c0e256c5e53ee6e31465a6711d44c731f918172548df41630f758c5e375b";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.276.gate_proj.weight","gate.weight.mxfp4","01527d73906aea77c90e50349d16119e7ebea95b8afad06dc3ffb73a2b75803f","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.276.gate_proj.weight_scale","gate.weight_scale.ue8","04fdd85c03c4a1db3b4e366d45d83e5d41ef5c4139c650f1e43405920f9f15ef","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.276.up_proj.weight","up.weight.mxfp4","57b5928dee248d3c0f9838f495212ea43d93fbe05aa6cbd0e13ccf93050ca39a","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.276.up_proj.weight_scale","up.weight_scale.ue8","db3550bea18e15be653a8c9268868adfb45499343b6aeccc437a68c0d8d084ab","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.276.down_proj.weight","down.weight.mxfp4","65e9344bf0f1f1044d436c7e56622f7017892aa51c300b18ae8364dab710c272","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.276.down_proj.weight_scale","down.weight_scale.ue8","141015b0f4f77b9b3b7691d233585d19279f55f86c2675ee030c2d183793776a","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_276
