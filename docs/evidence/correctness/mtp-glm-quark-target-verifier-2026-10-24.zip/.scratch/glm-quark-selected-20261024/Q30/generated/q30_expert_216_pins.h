#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_216 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="51fe90de9508476fc91c40215f90b2b37c0f2a7410d4919b7c9b040b8e7e78b3";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.216.down_proj.weight","down.weight.e4m3","f31cb349719b15fb7b0426060dd7f8225f2eb8c72b5c8d017b5de351448f6e54","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.216.down_proj.weight_scale","down.weight_scale.f32","b9136e771820b8701b1574c0aa8f24115e254f82ee17482af8b9a7daa6be1d4b","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.216.gate_proj.weight","gate.weight.e4m3","f9fade3ca6262ed19c46d4bde2437eee2e8fa1bce4026d103dabde6e811abb6e","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.216.gate_proj.weight_scale","gate.weight_scale.f32","8ed567a6966a8214ea51f524326823684a29389e184b38de2a42306fa65d22b0","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.216.up_proj.weight","up.weight.e4m3","980bab5835a20634286f821a3461d98ed252eae63677f663418cf4c9849e9aa6","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.216.up_proj.weight_scale","up.weight_scale.f32","d074e18df60ab8a01532f43e941d4626438d8f6c60e47b9f4976c3a853cc3f7f","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_216
