#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_189 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="8634119d7bb02a347f587b144870597fe95372053d3ccbd8a5c5d7a0fb12aa79";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.189.gate_proj.weight","gate.weight.mxfp4","0eb7b7f50ac3cf3681a5b82d6b280faf334dc98a88e9600d9f1db32eab9878a4","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.189.gate_proj.weight_scale","gate.weight_scale.ue8","25801d492e5a84fcdfa3145311ee315c1e1ff0a98d49315ba78ce72451f05eaf","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.189.up_proj.weight","up.weight.mxfp4","736216fe17dfc2db07fdd0b87c58fb0a330ddd1fb955cad46a320c676eb441b2","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.189.up_proj.weight_scale","up.weight_scale.ue8","2f6b0028d7eedd9df5278acb4c0584fe00d9c411b29085322661d93b6a59ed77","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.189.down_proj.weight","down.weight.mxfp4","08b7cb9b7f5690e821d5f83a4d8b8cc4936a1130bbab59b4a23db705c902f8a4","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.189.down_proj.weight_scale","down.weight_scale.ue8","ccec1a39e6d1c516bf88b00cfd68167abda97e90f802959f3869ce37cda661b3","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_189
