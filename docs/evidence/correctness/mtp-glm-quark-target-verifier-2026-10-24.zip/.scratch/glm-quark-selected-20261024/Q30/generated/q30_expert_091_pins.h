#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_091 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="12288c826fa0c82b1a86b5859881999fbaf06ab384418e73cff70d8a774d3ee7";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.91.down_proj.weight","down.weight.e4m3","4324535124f47151c1f9e66711313f1a4d5a84dbc7f2998b0817bf9f41b8c5db","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.91.down_proj.weight_scale","down.weight_scale.f32","48c632a97216ff0901055aa4212536ba4f1bb6b5667a558010ca4a462ab6f703","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.91.gate_proj.weight","gate.weight.e4m3","b2e9a77d2ce732b4eee76ceaa8534b5cc767896b64a878f49965742869f3f5be","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.91.gate_proj.weight_scale","gate.weight_scale.f32","fc30ed172ad8955ef905030794f9e4241289fbb176c6c7e689469b8b3427a6fd","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.91.up_proj.weight","up.weight.e4m3","01195ce05e401e88714120aff04cd5b20d574f32c9fd7a8679ae40ef822cf748","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.91.up_proj.weight_scale","up.weight_scale.f32","b88c96dfcd13d86cc4105a2d9600fb216b253002ae5d19ab03226c807fae710b","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_091
