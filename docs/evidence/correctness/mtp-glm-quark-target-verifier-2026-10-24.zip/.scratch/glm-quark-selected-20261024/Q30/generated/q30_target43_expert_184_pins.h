#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_184 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="6b333488f974c02c046a5ecde5cf390ed7bfe421b078f0a78ffcad26c273ab90";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.184.gate_proj.weight","gate.weight.mxfp4","48a882aae3c15a96a9dd3e1a946945733f62c9147b718f39428209272f6afba4","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.184.gate_proj.weight_scale","gate.weight_scale.ue8","ca7e066945668072f95267011fde93b27b77723b83439f3dccb024c0947e87f2","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.184.up_proj.weight","up.weight.mxfp4","b7df1ae3b3683fb370ac01c557e5fed7322609804cd10938796447b9c080c369","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.184.up_proj.weight_scale","up.weight_scale.ue8","48befe7c5bbd610bb9bbc6d4139cf312947cf0e53b629f9db0ba47eab90ed3c3","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.184.down_proj.weight","down.weight.mxfp4","997b781bfea56fea4c9f5ea2413e3ab41e08de3c86aadeaf1437e2f378c9697a","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.184.down_proj.weight_scale","down.weight_scale.ue8","0d792162786a2ad8246082e2a095c9a5e0ec95434605f96169043d7e8c7c1c14","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_184
