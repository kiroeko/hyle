#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_052 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="cd333657464b9c46daf8d90ca845815a519a3aae4d2197c791a973ec36c47ce8";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.52.gate_proj.weight","gate.weight.mxfp4","4deadfa7990e5b7f8e32ff9342f2c0eb6291d9d5b7ac0af04547d398507e38c7","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.52.gate_proj.weight_scale","gate.weight_scale.ue8","7db58c7e0945a6f9a3423e486f0a1141aec94d505c668e2043b0e2d57b70572a","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.52.up_proj.weight","up.weight.mxfp4","a523bb6aeb89a17e252b128384c0bc54aa3e80b9df0ec921c8e456a008e125f8","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.52.up_proj.weight_scale","up.weight_scale.ue8","cdb26a2f6a0f78774a2a7d20c5e354856c8dfb843ae2122f3d80de2c8d9e51bc","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.52.down_proj.weight","down.weight.mxfp4","f0ec723b2132a42d0e1cc43ad7e098d8246ae705f74ac8bdcea86e1d51b5cdd6","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.52.down_proj.weight_scale","down.weight_scale.ue8","eb099779ff2d10882c172ca37824220766934ed2fa5d6ddc6cc835bf173acc50","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_052
