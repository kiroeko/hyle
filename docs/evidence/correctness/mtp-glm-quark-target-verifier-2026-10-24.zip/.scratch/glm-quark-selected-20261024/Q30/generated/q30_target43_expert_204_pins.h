#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target43_expert_204 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="15171070655f3016d08307b794f03fcfd6f2e0f242ec4927ad4c2f02bbc09dfc";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.43.mlp.experts.204.gate_proj.weight","gate.weight.mxfp4","b71eddff63c54dcc485666a37108c5c4d3f1fbc83e94dadb3ba06a1ebf33e182","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.204.gate_proj.weight_scale","gate.weight_scale.ue8","846a7c905d8bdd4abd67a384c992f322cd0fd315785574087f1b04812dc5e289","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.204.up_proj.weight","up.weight.mxfp4","c25c2455dab1c9777eafb269c0923a47290fcc856f092c5803515ace5c87c804","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.204.up_proj.weight_scale","up.weight_scale.ue8","86f4dbb6149a3dde449a221675546db5cb1da99fca543bbf581d1ad52b7775fa","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.43.mlp.experts.204.down_proj.weight","down.weight.mxfp4","41ab89a21ba2e51bba0752f5e8e6ed103438e1d9a96f4e685e9d224cc782c474","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.43.mlp.experts.204.down_proj.weight_scale","down.weight_scale.ue8","c13f016812ee6f45d1de9720755929598743398389b15ed1cb4ffae97195a9cb","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target43_expert_204
