#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::nextn_static {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,2> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="72d1c2e8e3f6d0c877b017681b0186939edcd7418ffb559a7bd31a26ffb2d485";
inline constexpr std::string_view kExpertPlanSha256="6896583d1e52a281513e80d29185a68742d5bf5238862b4827dace4a0e72579c";
inline constexpr bool kBaseRevisionKnown=false;
inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{
  "amd","amd/GLM-5.3-Flash-Quark-MXFP4","glm5-next","GLM-5.3-Flash-Quark-MXFP4",
  "b5688f25491202978c19c4d036eef579f61bbe07","3a2c766e6a5256241b0b6ad82bc07e65bf4881b7211a0484cf18ce7020bfbd8f",
  "amd/GLM-5.3-Flash-Quark-MXFP4","b5688f25491202978c19c4d036eef579f61bbe07","Quark-MXFP4",
  "1a91c7f25ab61e7a0e537b047075d91537441e43263be01faf47d8b895f302cd","safetensors"};
inline constexpr std::array<PinnedRole,34> kRoles{{
  {"model.language_model.layers.45.eh_proj.weight","eh_proj.weight.bf16","17af8402a6b674a462f2847612b2477e76c0de7dfc5ff9fba50ead1e5c88d649","BF16",{4096,8192},2,67108864},
  {"model.language_model.layers.45.enorm.weight","enorm.weight.bf16","187f2b4efe991b8c69a1a0365ded195b7fd463d50a7facd0d7196402a66dcc54","BF16",{4096,0},1,8192},
  {"model.language_model.layers.45.hnorm.weight","hnorm.weight.bf16","3fbc01762fea938ae24e94ece075b03dd5cb44cbe218884712b35d865b820501","BF16",{4096,0},1,8192},
  {"model.language_model.layers.45.input_layernorm.weight","input_layernorm.weight.bf16","34ebd6b797e89011997e3f8fa674e4d0b9bc322d88bee17a91fe0a5421263e0c","BF16",{4096,0},1,8192},
  {"model.language_model.layers.45.mlp.gate.e_score_correction_bias","mlp.gate.e_score_correction_bias.f32","6352e1bbea7b072128fc66263a24b14d338a15091b6d048e24685de664d99864","F32",{288,0},1,1152},
  {"model.language_model.layers.45.mlp.gate.weight","mlp.gate.weight.bf16","d0254be35dbf5cb57037224ea78a7adb4e11160c3b0d54deeca2b13bac5f6715","BF16",{288,4096},2,2359296},
  {"model.language_model.layers.45.mlp.shared_experts.down_proj.weight","mlp.shared_experts.down_proj.weight.e4m3","1159518d984b3166efc732828c5fedc368a2ba8eef7677d1b63090b3d8a402d8","F8_E4M3",{4096,2048},2,8388608},
  {"model.language_model.layers.45.mlp.shared_experts.down_proj.weight_scale","mlp.shared_experts.down_proj.weight_scale.f32","2e26e94f72b83efdbd65532852276050a90b86c02e00d4a5be65809c2bcf3d18","F32",{32,16},2,2048},
  {"model.language_model.layers.45.mlp.shared_experts.gate_proj.weight","mlp.shared_experts.gate_proj.weight.e4m3","fb73882cca09f4e1f06cd518d13d38f18126bf0c92d64f06f9b9d29530a8a247","F8_E4M3",{2048,4096},2,8388608},
  {"model.language_model.layers.45.mlp.shared_experts.gate_proj.weight_scale","mlp.shared_experts.gate_proj.weight_scale.f32","cf15e1d4249fddaeb42623253ffbce0908a9eb31baa055644126e700c1f46c6c","F32",{16,32},2,2048},
  {"model.language_model.layers.45.mlp.shared_experts.up_proj.weight","mlp.shared_experts.up_proj.weight.e4m3","46cf1277af4442eec2ffa4371e6d9534c1bc185e24718cfdae493153fd1b9ff4","F8_E4M3",{2048,4096},2,8388608},
  {"model.language_model.layers.45.mlp.shared_experts.up_proj.weight_scale","mlp.shared_experts.up_proj.weight_scale.f32","f29aecf1a6c5b3085d397db4cb17fe35ec95fe3a84363bdbddfc845e9d76d5a9","F32",{16,32},2,2048},
  {"model.language_model.layers.45.post_attention_layernorm.weight","post_attention_layernorm.weight.bf16","85d70bee15e028083a5a38ab63fbaabb6fabafa64d9a66d9a61ab4604c2a52dc","BF16",{4096,0},1,8192},
  {"model.language_model.layers.45.self_attn.indexer.index_kpool_compress_ape","index_kpool_compress_ape.bf16","5409e5d02ce7e14b2b8bca99ec7cb051dd4c2c11d6f9570f5e4dfb827cddbd29","BF16",{4,128},2,1024},
  {"model.language_model.layers.45.self_attn.indexer.index_kpool_compress_gate","index_kpool_compress_gate.bf16","2c4a613a9c17143de1c939032d036b2276c465421837026eb406ef873ef7c229","BF16",{128,4096},2,1048576},
  {"model.language_model.layers.45.self_attn.indexer.k_norm.bias","k_norm.bias.bf16","0550bb42f1eb03b957705e89b41bbe4892cf319961da7cc0559b6e07321b5185","BF16",{128,0},1,256},
  {"model.language_model.layers.45.self_attn.indexer.k_norm.weight","k_norm.weight.bf16","71fb05d01b44ab8b80da4190a803e4fce846bf31009bfd41d267365d392e9359","BF16",{128,0},1,256},
  {"model.language_model.layers.45.self_attn.indexer.weights_proj.weight","weights_proj.weight.bf16","e31cf93353922020249dbf5b0ee7ca85813308048cac03cc838ca03462d1eada","BF16",{32,4096},2,262144},
  {"model.language_model.layers.45.self_attn.indexer.wk.weight","wk.weight.bf16","9348fb28363eed7797f751edf5dfd7be0bea2b397bfa62db1ea3aa4dac7842de","BF16",{128,4096},2,1048576},
  {"model.language_model.layers.45.self_attn.indexer.wq_b.weight","wq_b.weight.bf16","a3ce61c176747c383284a40d75634f70f3fa59dc0f94c523e933ef933cadb6da","BF16",{4096,1536},2,12582912},
  {"model.language_model.layers.45.self_attn.kv_a_layernorm.weight","kv_a_layernorm.weight.bf16","937e8ba89741a026ddefd5d2db42d3066aab723ab43995b0ed3b53bf4c3811e7","BF16",{512,0},1,1024},
  {"model.language_model.layers.45.self_attn.kv_a_proj_with_mqa.weight","kv_a.weight.e4m3","c1b6d576b22544c67a0a5d99c3cfdb0a70a56a38e96d68970d15490074c8ceb4","F8_E4M3",{512,4096},2,2097152},
  {"model.language_model.layers.45.self_attn.kv_a_proj_with_mqa.weight_scale","kv_a.weight_scale.f32","6a262630b028697ea60d85d7da1042de2b8b2e4e3f37b52246b17798bc6ede8d","F32",{4,32},2,512},
  {"model.language_model.layers.45.self_attn.kv_b_proj.weight","kv_b.weight.bf16","2c9d7ecb2b3863a52d5b27bc113b7241471a5d955f5046557b24b7e3b8289dc9","BF16",{32768,512},2,33554432},
  {"model.language_model.layers.45.self_attn.o_proj.weight","o.weight.e4m3","c6402d1f100e7e99776a97bd1ce33618f960e98c63f56c4ddd0ced8cc494c2dd","F8_E4M3",{4096,16384},2,67108864},
  {"model.language_model.layers.45.self_attn.o_proj.weight_scale","o.weight_scale.f32","346ca13b45aca744256624a84a5d39740d10be9f2ba31714bd8daf8378b09237","F32",{32,128},2,16384},
  {"model.language_model.layers.45.self_attn.q_a_layernorm.weight","q_a_layernorm.weight.bf16","33fec4645dc799a2a96b870b48012fcd096e66c2003c528881d98cd397afa96a","BF16",{1536,0},1,3072},
  {"model.language_model.layers.45.self_attn.q_a_proj.weight","q_a.weight.e4m3","615e317d19a83114b756e4634599ebba333c95241f3e775c77cc1633802d8be6","F8_E4M3",{1536,4096},2,6291456},
  {"model.language_model.layers.45.self_attn.q_a_proj.weight_scale","q_a.weight_scale.f32","c93393c24ed2c12f5458fbf88a257df91e22f586acc58436b861465c56f4d3fb","F32",{12,32},2,1536},
  {"model.language_model.layers.45.self_attn.q_b_proj.weight","q_b.weight.e4m3","c5b33a523ec8aa477e0a1a3f02049ed8f122c83e70dc77b9777741cd076a79d9","F8_E4M3",{16384,1536},2,25165824},
  {"model.language_model.layers.45.self_attn.q_b_proj.weight_scale","q_b.weight_scale.f32","58f7973cd4f6cd70dc2e05ebfc307dd2c0998f41ea12e84267590f1f443463a1","F32",{128,12},2,6144},
  {"model.language_model.layers.45.shared_head.norm.weight","norm.bf16","200c13367cfe6166220338e4c1ccd5d4e8bb414b251cb3c5b73a4bd49bb37188","BF16",{4096,0},1,8192},
  {"model.language_model.embed_tokens.weight","embedding.bf16","4f7aecd51589ce7879d0ae48a5a1ed25750e4e94d2abe2d14c9526e5ce5641d6","BF16",{154880,4096},2,1268776960},
  {"lm_head.weight","head.bf16","aa21c427970f64edd82669db3a8fb46613084e8bc271a3728784a52eb3f25ab4","BF16",{154880,4096},2,1268776960},
}};
} // namespace glm_original_artifacts::q30::nextn_static
