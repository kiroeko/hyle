#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::target44_expert_037 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="28bfa93825d4524ea20762f43d4cc5b067024c35fca81d53bbcc8358a7a60f3d";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.44.mlp.experts.37.gate_proj.weight","gate.weight.mxfp4","a6d8f7a14c8215603ebb26f0a3b525edf9bad06ee45086709308781eb2f7b74f","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.37.gate_proj.weight_scale","gate.weight_scale.ue8","c0d3bd5906c5e6f4b6e762e99a967fad1e8e49d13065422eddb8385d96d385c9","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.37.up_proj.weight","up.weight.mxfp4","5ab0621fa7ff59678c02e30d8490cb9da486f693c2314e81298591e7b42c0f6c","U8",{2048,2048,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.37.up_proj.weight_scale","up.weight_scale.ue8","a40dc4c9166526210692d66f20c3940f18d9676ac4aecde7334be31fdb1e26e2","U8",{2048,128,0},2,262144},
  {"model.language_model.layers.44.mlp.experts.37.down_proj.weight","down.weight.mxfp4","f945321069548caa44b7b09aa7b509ecbb958b7e419138bf58eff93ebeb2b18e","U8",{4096,1024,0},2,4194304},
  {"model.language_model.layers.44.mlp.experts.37.down_proj.weight_scale","down.weight_scale.ue8","8635294441037d35e0cf71ae9f21109e07bf93de875c495d6941000556618bf6","U8",{4096,64,0},2,262144},
}};
} // namespace glm_original_artifacts::q30::target44_expert_037
