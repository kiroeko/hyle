#pragma once
#include <array>
#include <cstddef>
#include <string_view>
#include "hyle/compute/workload.h"
namespace glm_original_artifacts::q30::expert_049 {
struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };
inline constexpr std::string_view kRepository="amd/GLM-5.3-Flash-Quark-MXFP4";
inline constexpr std::string_view kRevision="b5688f25491202978c19c4d036eef579f61bbe07";
inline constexpr std::string_view kManifestSha256="11baf0d38c88bb81d9ae03618035c8af36d975eb45f9c8abef148e5d2b25702f";
inline constexpr std::array<PinnedRole,6> kRoles{{
  {"model.language_model.layers.45.mlp.experts.49.down_proj.weight","down.weight.e4m3","68bb7bee1a6e43038f3352f2042cbff4fd872d98987140b23737c526d4adce54","F8_E4M3",{4096,2048,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.49.down_proj.weight_scale","down.weight_scale.f32","29cfd9730aca328207ce727d0c0f79c6506cccc372548959b6b935d19fd43941","F32",{32,16,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.49.gate_proj.weight","gate.weight.e4m3","205b782f551ea86b3993faf9f372503f20bf84f71d67fd725dabc34b00500ebd","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.49.gate_proj.weight_scale","gate.weight_scale.f32","70f8ead495e7a740001f6b95be9500534d5de9f42f9a9a2b9b8f7b625642315e","F32",{16,32,0},2,2048},
  {"model.language_model.layers.45.mlp.experts.49.up_proj.weight","up.weight.e4m3","13313ab23b51a03805cac9789b6db324aaffd1825ad172263154043e2a9fdeb6","F8_E4M3",{2048,4096,0},2,8388608},
  {"model.language_model.layers.45.mlp.experts.49.up_proj.weight_scale","up.weight_scale.f32","6b933e76fe357a313f30f17166823651a929266fe2d8b0b5440c1b4679f1d46e","F32",{16,32,0},2,2048},
}};
} // namespace glm_original_artifacts::q30::expert_049
