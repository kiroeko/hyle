"""Thin Q30 target43/44 adapter to the same authenticated loose acquisition.

--static is bounded immutable roles; --expert-ids requires an actual Top8
frontier. Definitions and plan/batch-plan modes never start HTTP.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import urllib.request

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name,path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--layer',type=int,choices=(43,44),required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--static',action='store_true')
    group.add_argument('--expert-ids',type=int,nargs='+')
    parser.add_argument('--plan-only',action='store_true')
    parser.add_argument('--write-batch-plan',type=Path)
    args = parser.parse_args()
    schema = module('q30_actual_target_schema',S/'prepare_target_plans.py')
    common = module('q30_same_original_acquisition',S/'fetch_roles.py')
    assert common.identity(S/'fetch_roles.py')['sha256'] == 'f4b4b66a5be6ab7b4bd753433a262e4edc516f806d90bde65ce3874670fe1118'
    ids = sorted(set(args.expert_ids or []))
    if not args.static:
        assert 1 <= len(ids) <= 8 and all(0 <= value < 288 for value in ids)
    plan_path,plan = schema.checked_plan(args.layer,not args.static)
    base = S/f'original-target{args.layer}'
    batches = [(base/'static',plan['roles'])] if args.static else [
        (base/'experts'/f'expert{global_id:03}',[row for row in plan['roles'] if row['global_id']==global_id])
        for global_id in ids]
    assert all(len(rows)==((34 if args.layer==43 else 32) if args.static else 6) for _,rows in batches)
    total = sum(row['bytes'] for _,rows in batches for row in rows)
    if args.write_batch_plan:
        path = args.write_batch_plan.resolve()
        assert path.is_relative_to(R/'.scratch')
        arguments = ['--layer',str(args.layer),'--static'] if args.static else [
            '--layer',str(args.layer),'--expert-ids',*map(str,ids)]
        label = f'target{args.layer}-'+('static' if args.static else 'experts-'+'-'.join(map(str,ids)))
        value = dict(script=Path(__file__).relative_to(R).as_posix(),arguments=arguments,
            out=(S/'prefetch'/label).relative_to(R).as_posix(),need_evidence=common.identity(plan_path),
            new_unique_body_bytes=total,whole_bank=False,whole_model=False,timeout_seconds=14400,
            roles=sum(len(rows) for _,rows in batches),globals=ids,metadata_only=False,
            maximum_request_bytes=8388608,authenticated_legacy_chunk_limit_bytes=134217728,
            stream_buffer_bytes=1048576,role_workers=3,source=common.identity(Path(__file__)),
            scope='Own Q30 target original immutable roles or only caller-supplied actual Top8 experts. No whole bank, weight expansion, official-target substitution or vocabulary redownload.',
            transport='Existing exclusive hf-mirror.net budget runner; no cross-origin fallback',preparation_only=True)
        if path.exists():
            assert common.read(path)==value
        else:
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(plan=common.identity(path),roles=value['roles'],body_bytes=total,http_requests=0)))
        return
    if args.plan_only:
        print(json.dumps(dict(layer=args.layer,globals=ids,roles=sum(len(rows) for _,rows in batches),
            body_bytes=total,source_plan=common.identity(plan_path),http_requests=0)))
        return
    opener = urllib.request.urlopen
    code = getattr(opener,'__code__',None)
    assert code and Path(code.co_filename).resolve()==(R/'.scratch/mtp-download-budget-20261023/budget.py').resolve()
    assert opener.__qualname__=='guarded.<locals>.open_range' and opener.__globals__.get('MIRROR_HOST')=='hf-mirror.net'
    shared,retry = common.shared_transport()
    for out,rows in batches:
        common.acquire(out,plan_path,plan,rows,shared,retry)


if __name__=='__main__':
    main()
