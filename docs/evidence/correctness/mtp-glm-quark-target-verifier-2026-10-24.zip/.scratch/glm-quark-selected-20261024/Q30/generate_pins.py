"""Emit typed pins only from one completed Q30 static or per-ID acquisition.

No body rehash/copy: the downloader already streamed SHA256 of every exact
payload. This generator authenticates the plan/receipt/manifest and complete
chunk coverage, and checks unchanged actual file extents. Runtime Data must
still authenticate mapped original bytes against the emitted explicit pins.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[2]


def load_fetch():
    spec=importlib.util.spec_from_file_location('_q30_pin_metadata',S/'fetch_roles.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--static',action='store_true')
    group.add_argument('--expert-id',type=int)
    parser.add_argument('--target-layer',type=int,choices=(43,44),
        help='Own target static or actual selected expert; absent preserves NextN45')
    args=parser.parse_args()
    fetch=load_fetch()
    if args.target_layer is None:
        path,plan=fetch.checked_plan('static-plan.json' if args.static else 'expert-source-plan.json')
        base,label_prefix,static_count=S,'',34
    else:
        spec=importlib.util.spec_from_file_location('_q30_target_pin_schema',S/'prepare_target_plans.py')
        target=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(target)
        path,plan=target.checked_plan(args.target_layer,not args.static)
        base,label_prefix,static_count=S/f'original-target{args.target_layer}',f'target{args.target_layer}_',34 if args.target_layer==43 else 32
    if args.static:
        out,selected,label=(base/'static' if args.target_layer else base/'original-static'),plan['roles'],label_prefix+'static' if args.target_layer else 'nextn_static'
    else:
        assert args.expert_id is not None and 0<=args.expert_id<288
        out=base/('experts' if args.target_layer else 'original-experts')/f'expert{args.expert_id:03}'
        selected=[x for x in plan['roles'] if x['global_id']==args.expert_id]
        label=label_prefix+f'expert_{args.expert_id:03}'
    receipt,manifest=fetch.read(out/'acquisition.json'),fetch.read(out/'manifest.json')
    assert (receipt['repository'],receipt['revision'])==(fetch.REPO,fetch.REV)
    assert receipt['complete'] is True and manifest['complete'] is True
    assert receipt['source_plan_sha256']==fetch.identity(path)['sha256']
    assert manifest['source_plan']==fetch.identity(path) and manifest['source_receipt']==fetch.identity(out/'acquisition.json')
    assert receipt['selected_names']==[x['name'] for x in selected]
    assert len(receipt['roles'])==len(manifest['roles'])==len(selected)==(static_count if args.static else 6)
    expected_bytes=sum(x['bytes'] for x in selected)
    assert receipt['expected_role_payload_bytes']==receipt['role_payload_bytes']==manifest['source_bytes']==expected_bytes
    assert sum(x['bytes'] for x in receipt['requests'] if x['complete'])==expected_bytes
    pins=[]
    for actual,published,wanted in zip(receipt['roles'],manifest['roles'],selected,strict=True):
        assert actual['complete'] is True
        assert all(actual[k]==wanted[k] for k in wanted)
        assert actual['payload']['bytes']==wanted['bytes'] and re.fullmatch('[0-9a-f]{64}',actual['payload']['sha256'])
        assert (R/actual['payload']['path']).resolve()==(out/wanted['filename']).resolve()
        assert (out/wanted['filename']).stat().st_size==wanted['bytes']
        offset=0
        for chunk in actual['chunks']:
            assert chunk['offset']==offset and 0<chunk['bytes']<=134217728
            assert re.fullmatch('[0-9a-f]{64}',chunk['sha256'])
            offset+=chunk['bytes']
        assert offset==wanted['bytes']
        assert (published['name'],published['file'],published['sha256'],published['dtype'],published['shape'],published['bytes'])==(
            wanted['name'],wanted['filename'],actual['payload']['sha256'],wanted['dtype'],wanted['shape'],wanted['bytes'])
        pins.append(published)
    # Table order follows this authenticated manifest, not any model enum.
    # The later cold adapter must match exact names and descriptions.
    lines=['#pragma once','#include <array>','#include <cstddef>','#include <string_view>','#include "hyle/compute/workload.h"',
        f'namespace glm_original_artifacts::q30::{label} {{',
        'struct PinnedRole final { std::string_view name,file,sha256,dtype; std::array<std::size_t,3> shape; std::size_t rank,bytes; };',
        f'inline constexpr std::string_view kRepository={json.dumps(fetch.REPO)};',
        f'inline constexpr std::string_view kRevision={json.dumps(fetch.REV)};',
        f'inline constexpr std::string_view kManifestSha256="{fetch.identity(out/"manifest.json")["sha256"]}";']
    if args.static:
        if args.target_layer is None:
            expert_path,_=fetch.checked_plan('expert-source-plan.json')
        else:
            expert_path,_=target.checked_plan(args.target_layer,True)
        lines.append(f'inline constexpr std::string_view kExpertPlanSha256="{fetch.identity(expert_path)["sha256"]}";')
        lines+=['inline constexpr bool kBaseRevisionKnown=false;',
            'inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{',
            '  "amd","amd/GLM-5.3-Flash-Quark-MXFP4","glm5-next","GLM-5.3-Flash-Quark-MXFP4",',
            f'  {json.dumps(fetch.REV)},"3a2c766e6a5256241b0b6ad82bc07e65bf4881b7211a0484cf18ce7020bfbd8f",',
            f'  {json.dumps(fetch.REPO)},{json.dumps(fetch.REV)},"Quark-MXFP4",',
            '  "1a91c7f25ab61e7a0e537b047075d91537441e43263be01faf47d8b895f302cd","safetensors"};']
    lines.append(f'inline constexpr std::array<PinnedRole,{len(pins)}> kRoles{{{{')
    for x in pins:
        assert 1<=len(x['shape'])<=3
        shape=x['shape']+[0]*(3-len(x['shape']))
        lines.append('  {'+','.join(json.dumps(x[k]) for k in ('name','file','sha256','dtype'))+
            ',{'+','.join(map(str,shape))+'},'+str(len(x['shape']))+','+str(x['bytes'])+'},')
    lines+=['}};',f'}} // namespace glm_original_artifacts::q30::{label}','']
    generated=S/'generated'
    generated.mkdir(exist_ok=True)
    header=generated/f'q30_{label}_pins.h'
    header.write_text('\n'.join(lines),encoding='utf-8')
    if not args.static:
        # Immutable per-ID catalogue for the explicit before-upload handshake.
        # All hashes are the actual downloader's complete streamed payload SHA.
        ordered=[]
        prefix=f'model.language_model.layers.{args.target_layer or 45}.'
        for leg in ('gate','up','down'):
            for member in ('weight','weight_scale'):
                name=prefix+f'mlp.experts.{args.expert_id}.{leg}_proj.'+member
                matches=[x for x in pins if x['name']==name]
                assert len(matches)==1 and len(matches[0]['shape'])==2
                x=matches[0]
                assert not any(c in str(x[k]) for k in ('name','file','sha256','dtype') for c in '\r\n\t')
                ordered.append('\t'.join([x['name'],x['file'],x['sha256'],x['dtype'],*map(str,x['shape']),str(x['bytes'])]))
        catalog=out/'catalog.tsv'
        catalog_bytes=('HYGLME01\t1\t6\n'+'\n'.join(ordered)+'\n').encode('utf-8')
        if catalog.exists():
            assert catalog.read_bytes()==catalog_bytes, 'Original per-ID catalogue cannot be rebound'
        else:
            temporary_catalog=out/'catalog.tsv.tmp';temporary_catalog.write_bytes(catalog_bytes)
            temporary_catalog.replace(catalog)
        ready='\t'.join(['HYGLMR01','1',fetch.REPO,fetch.REV,prefix,'weight_scale',fetch.identity(path)['sha256'],str(args.expert_id),fetch.identity(catalog)['sha256']])+'\n'
        temporary=out/'ready.tsv.tmp';temporary.write_bytes(ready.encode('utf-8'));temporary.replace(out/'ready.tsv')
    print(json.dumps(dict(header=fetch.identity(header),roles=len(pins),bytes=expected_bytes,
        receipt=fetch.identity(out/'acquisition.json'),manifest=fetch.identity(out/'manifest.json'))))


if __name__=='__main__':
    main()
