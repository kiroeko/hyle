"""Two private CPU consumers; seven fixed math cases, no model/SDK/HTTP."""
from pathlib import Path
import hashlib,importlib.util,json,os,re,shutil,sys,zipfile
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2];S=D/'source'
BASE=R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2';MAIN=R/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current1'
spec=importlib.util.spec_from_file_location('cpu_build',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
NAMES=['source-contracts','packed-formats']
def read(p):return b.read(p)
def save(p,x):b.save(p,x)
def require(yes,message):
 if not yes:raise ValueError(message)
def freeze():
 S.mkdir(exist_ok=False)
 sources=[R/'engine/models/qwen35/main.cc',*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h')]
 pending=[R/'tests/tools/qwen_geometry_fixture.h',*(R/'tests/compute_models'/name for name in ['nvfp4_reference_fixture.h','fp8_channel_token_qdq_fixture.h','local_nvfp4_reference_fixture.h','gptq_reference_fixture.h','ct_packed_linear_fixture.h'])];seen=set()
 while pending:
  p=pending.pop().resolve()
  if p in seen:continue
  seen.add(p)
  for word in re.findall(r'^#include "([^"]+)"',p.read_text(encoding='utf8'),re.M):
   q=(p.parent/word).resolve()
   if not q.is_file():q=(R/word).resolve()
   if q.is_file()and(q.is_relative_to(R/'tests')or q.is_relative_to(R/'engine')):pending.append(q)
 sources+=sorted(seen);pins=[]
 for p in sources:
  target=S/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());pins.append(dict(original=b.identity(p),frozen=b.identity(target)))
 for p in [D/(name+'.cc')for name in NAMES]+list(D.glob('*.inc'))+[D/'graph-metadata.h']:
  target=S/p.name;shutil.copyfile(p,target);pins.append(dict(original=b.identity(p),frozen=b.identity(target)))
 save(D/'source-pins.json',pins)
 save(D/'frozen-plan.json',dict(current_main=b.identity(S/'engine/models/qwen35/main.cc'),binding_header=b.identity(S/'engine/models/qwen35/projection_binding.h'),baseline_input_and_oracle_pins=b.identity(D/'preparation.json'),native=read(BASE/'ready.json')['native'],source_freeze_only=True,SDK_builds=0,HTTP=0))
def command(name,folder,syntax):
 old=read(MAIN/'compile-command.json');args=[old[0],'/I'+str(S)];skip=False
 for word in old[1:]:
  if skip:skip=False;continue
  if word=='/sourceDependencies':skip=True;continue
  lower=word.lower().replace('\\','/')
  if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
  if lower.startswith(('/i','-i'))and '/.scratch/'in lower and lower.endswith('/source'):continue
  args.append(word)
 gtest=Path('C:/public/tools/hyle-dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
 require((gtest/'gtest/gtest.h').is_file(),'Existing gtest header cache missing')
 args+=['/external:I'+str(gtest),'/sourceDependencies',str(folder/'dependencies.json'),str(S/(name+'.cc')),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
 if syntax:args.append('/Zs')
 return args
def compile(name,syntax=False):
 folder=D/name/('syntax1'if syntax else'compile1');args=command(name,folder,syntax)
 env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':args[0],'CMAKE_CXX_COMPILER':args[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 b.execute(args,env,folder,240)
 if not syntax:
  includes=[Path(p).resolve()for p in read(folder/'dependencies.json')['Data']['Includes']]
  leaks=[str(p)for p in includes if p.is_relative_to(R/'engine')or p.is_relative_to(R/'tests')or(p.is_relative_to(R/'.scratch')and not p.is_relative_to(S))]
  require(not leaks,'Frozen self header leak: '+repr(leaks));save(folder/'self-header-pins.json',[b.identity(p)for p in includes if p.is_relative_to(R)])
  link=[];removed=[]
  for word in read(BASE/'link-command.json'):
   normalized=word.lower().replace('\\','/')
   if word==str(MAIN/'main.obj')or normalized.endswith('engine/main.cc.obj'):removed.append(word);continue
   if word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:')):continue
   link.append(word)
  require(len(removed)==2,'Expected exact frozen engine and model app TU')
  out=D/name/'link1';link.insert(1,str(folder/'unit.obj'));link+=['/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb')]
  b.execute(link,env,out,120)
  native=read(BASE/'ready.json')['native'];b.require(native);os.link(native['path'],out/Path(native['path']).name)
  runtime=read(BASE/'runtime-environment.json');runtime['PATH']=str(out)+';'+runtime['PATH'];save(out/'runtime.json',runtime)
  save(out/'ready.json',dict(image=b.identity(out/'probe.exe'),object=b.identity(folder/'unit.obj'),native=b.identity(out/Path(native['path']).name),retained_link= b.identity(BASE/'link-command.json'),removed_app_objects=removed,source_pins=b.identity(D/'source-pins.json'),SDK_builds=0,HTTP=0))
def run(name):
 folder=D/name;ready=read(folder/'link1/ready.json');b.require(ready['image']);runtime=read(folder/'link1/runtime.json')
 env=dict(os.environ,PATH=runtime['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1')
 if name=='source-contracts':args=[str(R/'.scratch/mtp-metadata-offline-20261024/components'),str(R/'.scratch/mtp-q27-fp8-20261024')]
 else:args=[str(R/'.scratch/mtp-metadata-offline-20261024/components/q27-nvfp4-original-head'),str(R/'.scratch/mtp-correctness-20261024/projection-check/cpu/head-vectors/logits.f32'),str(folder/'vectors')]
 b.execute([ready['image']['path'],*args],env,folder/'run1',120)
def summarize():
 rows=[];actual_calls={}
 for name in NAMES:
  folder=D/name;process=read(folder/'run1/process.json');require(process['exit']==0 and not process['timed_out'],'Actual terminal success required')
  stdout=(folder/'run1/stdout.log').read_text(encoding='utf8');lines=stdout.splitlines()
  if name=='source-contracts':
   markers=['PASS source=q27-fp8-bf16-sf ','PASS recipe=lm_head.weight ','PASS recipe=model.language_model.layers.0.mlp.gate_proj.weight ']
   require(all(sum(x.startswith(marker)for x in lines)==1 for marker in markers),'Actual original-source completed result missing');actual_calls[name]=len(markers)
  else:
   head=[json.loads(x)for x in lines if x.startswith('{')];require(len(head)==1 and head[0]['graph_calls']==1,'Actual original head submission missing')
   markers=['PASS contract=gptq_F16_decode_BF16_operand_closed4 ','PASS contract=CTsym_BF16_product_BF16_projection_F32_head ','PASS contract=F32_weight_F32_projection_logits ']
   require(all(sum(x.startswith(marker)for x in lines)==1 for marker in markers),'Actual synthetic-oracle completed result missing');actual_calls[name]=head[0]['graph_calls']+len(markers)
   require(sum(x.startswith('PASS_COLD_ONLY contract=GGUF_F32_MatMul_logits ')and 'submissions=0'in x for x in lines)==1,'GGUF cold-only distinction lost')
  rows.append(dict(name=name,process=process,ready=read(folder/'link1/ready.json'),actual_math_graph_submissions=actual_calls[name],stdout=b.identity(folder/'run1/stdout.log'),stderr=b.identity(folder/'run1/stderr.log')))
 outputs={p.relative_to(D/'packed-formats/vectors').as_posix():b.identity(p)for p in(D/'packed-formats/vectors').rglob('*')if p.is_file()}
 summary=dict(state='passed_finite_CPU_projection_binding_math',cases=rows,actual_math_graph_submissions=sum(actual_calls.values()),cold_GGUF_graphs=1,cold_GGUF_graph_submissions=0,component_processes=2,whole_model_processes=0,compiled_private_TUs=2,syntax_checks=2,output_artifacts=outputs,source_pins=b.identity(D/'source-pins.json'),historical_preparation_snapshot=read(D/'preparation.json'),scope='Original Q27 FP8 block128, CT channel head/localNVFP4, original ModelOpt head; existing synthetic GPTQ F16 closed4-node and CTsym independent-oracle cases, plus plain F32 head precision witness. Only fixed CPU, no whole model/trained quality/performance or other format/backend qualification.',SDK_builds=0,HTTP=0)
 save(D/'summary.json',summary)
 with zipfile.ZipFile(D/'logs.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in D.rglob('*'):
   if p.is_file()and p.suffix.lower()in('.py','.cc','.h','.inc','.json','.log','.bin','.f32','.bf16','.tsv')and 'tmp'not in p.relative_to(D).parts:z.write(p,p.relative_to(D).as_posix())
  for row in read(D/'preparation.json')['cached_inputs']:
   b.require(row);p=Path(row['path']);z.write(p,'cached-inputs/'+p.relative_to(R).as_posix())
 print(json.dumps(dict(state=summary['state'],summary=b.identity(D/'summary.json'),archive=b.identity(D/'logs.zip'),SDK_builds=0,HTTP=0)))
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':freeze();[compile(n,True)for n in NAMES]
 elif action=='build':[compile(n)for n in NAMES]
 elif action=='run':
  for n in NAMES:run(n)
  summarize()
 else:raise SystemExit('prepare|build|run')
