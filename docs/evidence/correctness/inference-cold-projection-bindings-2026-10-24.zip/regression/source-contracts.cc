// Reused fixed original source tiles and unchanged independent oracles.
#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_geometry_fixture.h"
#include "tests/compute_models/nvfp4_reference_fixture.h"
#include "tests/compute_models/fp8_channel_token_qdq_fixture.h"
#include "tests/compute_models/local_nvfp4_reference_fixture.h"
#include "graph-metadata.h"
#include "block128.inc"
#include "ct-mixed.inc"
int main(int argc,char**argv){try{
 if(argc!=3)throw std::runtime_error("projection-source-contracts COMPONENTS_ROOT FP8_SCRATCH_ROOT");
 block128_binding::one(argv[1],"q27-fp8-bf16-sf",5120);
 const std::filesystem::path root=argv[2];const auto roles=qwen35::read_weight_roles(root/"cat08-metadata1/original-headers.tsv",true);
 if(roles.selected.size()!=1603||roles.omitted_cache_calibration.size()!=32)throw std::runtime_error("actual CT header inventory changed");
 ct_mixed_binding::channel(root,roles,true); // Head exercises the same channel projection plus BF16→F32.
 ct_mixed_binding::local(root,roles);
 return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
