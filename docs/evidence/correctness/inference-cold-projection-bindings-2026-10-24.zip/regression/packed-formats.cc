// One CPU case per moved equation. Existing independent fixtures/oracles and
// the already-qualified original8KB head are reused; no trained/full-model claim.
#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_geometry_fixture.h"
#include "tests/compute_models/gptq_reference_fixture.h"
#include "tests/compute_models/ct_packed_linear_fixture.h"
namespace q=qwen35;
#include "packed-head.inc"
namespace small_contracts {
using Type=q::Type;
using Bytes=std::vector<std::byte>;
void require(bool yes,const char* message){if(!yes)throw std::runtime_error(message);}
void add(std::map<std::string,q::Tensor>&bank,q::Backend&backend,const std::string&name,
    q::c::TensorDesc desc,std::span<const std::byte> bytes,
    q::prepared::ProjectionCodec codec=q::prepared::ProjectionCodec::kUnspecified,std::uint32_t group=0){
  require(q::take(desc.required_bytes())==bytes.size(),"fixture descriptor extent differs");
  q::Tensor t(backend.device(),desc);t.projection_codec=codec;t.projection_group_size=group;
  q::check(backend.write(t.buffer.view(),bytes));t.freeze(backend);bank.emplace(name,std::move(t));
}
template<class T>Bytes bytes(std::span<const T> values){auto b=std::as_bytes(values);return {b.begin(),b.end()};}
struct NodeCounts{std::size_t decode=0,cast_bf16=0,cast_f32=0,transpose=0,matmul_f32=0,dense_f32=0;};
NodeCounts inspect(const q::g::Graph&graph,const std::filesystem::path&path){
  std::ofstream out(path);NodeCounts counts;
  out<<"index\toperation\tdecode_format\tgroup\tdecode_dtype\tcast_dtype\taccum_dtype\tpermutation\n";
  for(std::size_t i=0;i<graph.node_count();++i){
    const auto op=q::take(graph.operation(q::take(graph.node_id(i))));
    out<<i<<'\t'<<q::c::operation_name(op)<<'\t';
    if(auto d=op.custom_as<q::c::model_ops::ArtifactWeightDecode>()){++counts.decode;out<<unsigned(d->format)<<'\t'<<d->group_size<<'\t'<<unsigned(d->output_type);}
    else out<<"-\t-\t-";
    out<<'\t';if(auto cast=op.get_if<q::c::Cast>()){out<<unsigned(cast->output_type);counts.cast_bf16+=cast->output_type==Type::kBFloat16;counts.cast_f32+=cast->output_type==Type::kFloat32;}else out<<'-';
    out<<'\t';if(auto mm=op.get_if<q::c::MatMul>()){out<<unsigned(mm->accumulation_type);counts.matmul_f32+=mm->accumulation_type==Type::kFloat32;}else out<<'-';
    out<<'\t';if(auto v=op.get_if<q::c::View>();v&&v->kind()==q::c::ViewKind::kPermute){auto p=v->permutation();require(p.size()==2&&p[0]==1&&p[1]==0,"projection transpose changed");++counts.transpose;out<<"1,0";}else out<<'-';out<<'\n';
    counts.dense_f32+=q::c::operation_name(op)=="dense-linear-f32";
  }
  require(bool(out),"cannot record typed graph metadata");return counts;
}
Bytes execute(q::Backend&backend,q::Recipe&r,q::V x,q::V y,q::c::TensorDesc ad,
    std::span<const std::byte> raw,const std::filesystem::path&output,std::string_view name,
    bool gptq,bool ct_head,bool dense_head){
  r.publish(y);const auto graph=q::take(std::move(r.builder).finish());const auto counts=inspect(graph,output/(std::string(name)+"-graph.tsv"));
  if(gptq){require(graph.node_count()==4&&counts.decode==1&&counts.cast_bf16==1&&counts.transpose==1&&counts.matmul_f32==1&&r.packed_projection_nodes.size()==1,"GPTQ F16/closed four-node graph changed");
    for(std::size_t i=0;i<4;++i)require(r.packed_projection_nodes[0].chain[i]==q::take(graph.node_id(i)),"GPTQ closed chain lost its exact node order");
  }
  if(ct_head)require(graph.node_count()==4&&counts.decode==1&&counts.cast_bf16==0&&counts.transpose==1&&counts.matmul_f32==1&&counts.cast_f32==1,"CTsym BF16 projection plus F32 logits graph changed");
  if(dense_head)require(counts.dense_f32==1&&counts.cast_bf16==0&&counts.cast_f32==1,"plain F32 head acquired a BF16 intermediate");
  const std::array shape{q::g::ShapeBinding{r.last_row,1}};const std::array variants{q::g::ExactShapeVariant{shape}};
  auto compiled=q::take(backend.compile(graph,r.constants,r.options({.shape_policy=q::g::CompileShapePolicy::kFiniteExact,.exact_variants=variants})));
  compiled.executable=q::take(compiled.executable.exact_variant(0));compiled.report=q::take(compiled.report.exact_variant(0));
  const auto facts=q::take(hyle::inference::prepare_output(compiled,y));q::Tensor input(backend.device(),ad);input.write<std::byte>(raw);input.freeze(backend);
  auto run=q::take(compiled.executable.create_invocation());q::check(run.prepare_resources());q::check(run.bind(x,input.read()));q::Tensor caller;
  if(facts.caller_owned()){caller=q::Tensor(q::take(backend.resource_for(facts.storage)),facts.description);q::check(run.bind(y,caller.view()));}
  auto queues=q::take(hyle::inference::prepare_queue_bindings(backend.queue_bindings(),compiled.report));const auto bindings=hyle::inference::queue_span(queues);
  q::check(run.prepare_replay(bindings,{.mode=q::g::ReplayMode::kCommands,.host_wait=q::g::HostWaitPolicy::kAllow}));auto done=q::take(run.submit(bindings));q::check(done.wait());
  Bytes result(q::take(facts.description.required_bytes()));if(caller.buffer)q::check(backend.read(caller.buffer.view(),result));else{auto retained=q::take(hyle::inference::retain_output(run,facts));q::check(backend.read(q::take(retained.view()),result));}
  original_packed_head::save(output/(std::string(name)+"-actual.bin"),result);return result;
}
void numeric(std::span<const std::byte> actual,std::span<const double> expected,Type type){
  require(actual.size()==expected.size()*q::c::data_type_size(type),"result byte extent differs");
  for(std::size_t i=0;i<expected.size();++i){double value;
    if(type==Type::kFloat32){float x;std::memcpy(&x,actual.data()+i*4,4);value=x;}
    else{std::uint16_t x;std::memcpy(&x,actual.data()+i*2,2);value=half_test::decode_bits<hyle::simd::bfloat16_t>(x);}
    if(value!=expected[i])throw std::runtime_error("independent source rounding oracle differs at"+std::to_string(i));
  }
}
void gptq(const std::filesystem::path&out){
  namespace t=gptq_reference_test;const t::Case f(t::profiles[2]);const auto data=f.data();const auto payload=f.payloads(data);const auto expected=f.oracle(data);
  auto backend=q::take(q::Backend::create({.primary=hyle::inference::BackendKind::kCpu}));std::map<std::string,q::Tensor>bank;const std::string base="mtp.layers.0.self_attn.k_proj",logical=base+".weight";
  add(bank,backend,base+".qweight",f.descriptions[1],payload[1],q::prepared::ProjectionCodec::kGptqV1Int4,64);
  add(bank,backend,base+".qzeros",f.descriptions[2],payload[2]);add(bank,backend,base+".scales",f.descriptions[3],payload[3]);add(bank,backend,base+".g_idx",f.descriptions[4],payload[4]);
  q::ProjectionBindings projections;projections.emplace(logical,q::resolve_projection(bank,logical));q::Recipe r(bank,projections,backend,qwen_test::q35(),2);
  const auto x=r.input(f.descriptions[0]);const auto y=r.linear_absolute(x,logical);const auto result=execute(backend,r,x,y,f.descriptions[0],payload[0],out,"gptq",true,false,false);numeric(result,expected,Type::kBFloat16);
  std::cout<<"PASS contract=gptq_F16_decode_BF16_operand_closed4 outputs="<<expected.size()<<" score_policy="<<q::score_policy(projections.at(logical))<<"\n";
}
void ct(const std::filesystem::path&out){
  namespace t=ct_packed_test;const t::Fixture f(false);const auto a=f.activation(2,Type::kBFloat16,0,true);const auto w=f.decoded(Type::kBFloat16,Type::kBFloat16,Type::kBFloat16);
  const auto a_bytes=gptq_reference_test::floating(Type::kBFloat16,a),sf=gptq_reference_test::floating(Type::kBFloat16,f.scales),codes=bytes<std::int32_t>(f.codes);
  std::vector<double>expected(std::size_t(2*f.rows));for(std::int64_t row=0;row<2;++row)for(std::int64_t n=0;n<f.rows;++n)expected[std::size_t(row*f.rows+n)]=w[std::size_t(n*f.depth+(row?32:0))];
  auto backend=q::take(q::Backend::create({.primary=hyle::inference::BackendKind::kCpu}));std::map<std::string,q::Tensor>bank;const std::string base="lm_head",logical=base+".weight";
  add(bank,backend,base+".weight_packed",q::dense(Type::kInt32,{f.rows,f.depth/8}),codes,q::prepared::ProjectionCodec::kCtSymmetric4,32);
  add(bank,backend,base+".weight_scale",q::dense(Type::kBFloat16,{f.rows,f.depth/32}),sf);
  q::ProjectionBindings projections;projections.emplace(logical,q::resolve_projection(bank,logical));q::Recipe r(bank,projections,backend,qwen_test::q35(),2);
  const auto ad=q::dense(Type::kBFloat16,{2,f.depth});const auto x=r.input(ad),y=r.scores(x,logical);const auto result=execute(backend,r,x,y,ad,a_bytes,out,"ctsym-head",false,true,false);numeric(result,expected,Type::kFloat32);
  std::cout<<"PASS contract=CTsym_BF16_product_BF16_projection_F32_head outputs="<<expected.size()<<" score_policy="<<q::score_policy(projections.at(logical))<<"\n";
}
void f32_head(const std::filesystem::path&out){
  auto backend=q::take(q::Backend::create({.primary=hyle::inference::BackendKind::kCpu}));std::map<std::string,q::Tensor>bank;
  const std::array<float,12>w{.1001F,1.0031F,0,0,-.1001F,.0313F,0,0,.3333F,1.007F,0,0};
  const std::array<std::uint16_t,8>a{0x3f80,0,0,0,0,0x3f80,0,0};std::vector<double>expected{w[0],w[4],w[8],w[1],w[5],w[9]};
  const std::string logical="lm_head.weight";add(bank,backend,logical,q::dense(Type::kFloat32,{3,4}),std::as_bytes(std::span(w)));
  q::ProjectionBindings projections;projections.emplace(logical,q::resolve_projection(bank,logical));q::Recipe r(bank,projections,backend,qwen_test::q35(),2);
  const auto ad=q::dense(Type::kBFloat16,{2,4});const auto x=r.input(ad),y=r.scores(x,logical);const auto result=execute(backend,r,x,y,ad,std::as_bytes(std::span(a)),out,"plain-f32-head",false,false,true);numeric(result,expected,Type::kFloat32);
  require(std::ranges::any_of(expected,[](double x){return x!=gptq_reference_test::round(Type::kBFloat16,x);}),"plain F32 logits rounding witness is degenerate");
  std::cout<<"PASS contract=F32_weight_F32_projection_logits outputs=6 score_policy="<<q::score_policy(projections.at(logical))<<"\n";
}
void gguf_cold_head(const std::filesystem::path&out){
  // Cold shape/precision proof only. Existing complete original GGUF journeys
  // remain the numeric evidence; do not add another quant/backend execution.
  auto backend=q::take(q::Backend::create({.primary=hyle::inference::BackendKind::kCpu}));std::map<std::string,q::Tensor>bank;
  const auto desc=q::take(q::take(q::c::gguf_weight_description(q::c::GgufQuantizedType::kQ4_0,Type::kFloat32,32,3)).transposed());
  Bytes codes(q::take(desc.required_bytes()));const std::string logical="lm_head.weight";add(bank,backend,logical,desc,codes);
  q::ProjectionBindings projections;projections.emplace(logical,q::resolve_projection(bank,logical));q::Recipe r(bank,projections,backend,qwen_test::q35(),2);
  const auto x=r.input(q::dense(Type::kBFloat16,{2,32})),y=r.scores(x,logical);r.publish(y);const auto graph=q::take(std::move(r.builder).finish());
  const auto counts=inspect(graph,out/"gguf-head-cold-graph.tsv");const auto yd=q::take(graph.value_description(y));
  require(counts.cast_bf16==0&&counts.cast_f32==1&&counts.transpose==1&&counts.matmul_f32==1&&yd.data_type()==Type::kFloat32,"GGUF head acquired an intermediate BF16 projection");
  std::cout<<"PASS_COLD_ONLY contract=GGUF_F32_MatMul_logits graph_nodes="<<graph.node_count()<<" submissions=0 score_policy="<<q::score_policy(projections.at(logical))<<"\n";
}
}
int main(int argc,char**argv){try{
  if(argc!=4)throw std::runtime_error("projection-packed-formats ORIGINAL_HEAD_ROOT BASELINE_LOGITS OUTPUT");const std::filesystem::path out=argv[3];std::filesystem::create_directories(out);
  original_packed_head::check_packed_head(argv[1],out/"original-head");
  if(original_packed_head::exact_file(out/"original-head/logits.f32",24)!=original_packed_head::exact_file(argv[2],24))throw std::runtime_error("original packed head differs from frozen independent-oracle-qualified baseline bytes");
  small_contracts::gptq(out);small_contracts::ct(out);small_contracts::f32_head(out);small_contracts::gguf_cold_head(out);return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
