#pragma once
namespace projection_regression {
inline void report_graph(const qwen35::g::Graph&graph,std::string_view label){
  namespace c=hyle::compute;
  std::cout<<"GRAPH contract="<<label<<" nodes="<<graph.node_count()<<'\n';
  for(std::size_t i=0;i<graph.node_count();++i){
    const auto op=qwen35::take(graph.operation(qwen35::take(graph.node_id(i))));
    std::cout<<"NODE index="<<i<<" op="<<c::operation_name(op);
    if(const auto* v=op.get_if<c::Cast>())std::cout<<" cast_type="<<unsigned(v->output_type);
    if(const auto* v=op.get_if<c::MatMul>())std::cout<<" accumulation_type="<<unsigned(v->accumulation_type);
    if(const auto* v=op.get_if<c::View>();v&&v->kind()==c::ViewKind::kPermute){std::cout<<" perm=";for(auto n:v->permutation())std::cout<<int(n)<<',';}
    if(auto v=op.custom_as<c::model_ops::ArtifactWeightDecode>())std::cout<<" format="<<unsigned(v->format)<<" group="<<v->group_size<<" decode_type="<<unsigned(v->output_type);
    if(auto v=op.custom_as<c::model_ops::Float8BlockLinear>())std::cout<<" scale_policy="<<unsigned(v->scale_policy)<<" floor_bits="<<std::bit_cast<std::uint32_t>(v->absmax_floor);
    if(auto v=op.custom_as<c::model_ops::LocalNvfp4Linear>())std::cout<<" input_preround="<<unsigned(v->rounding);
    std::cout<<'\n';
  }
}
}
