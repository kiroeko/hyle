"""Prepare only bounded original-oracle CPU consumers for cold projection binding."""
from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(p,s):
 if p.exists():
  if p.read_text(encoding='utf8')!=s:raise ValueError('Prepared private file differs: '+str(p))
  return
 with p.open('x',encoding='utf8',newline='\n')as f:f.write(s)
def replace(s,a,b):
 if s.count(a)!=1:raise ValueError('Unexpected original consumer: '+a)
 return s.replace(a,b)
def body(p):
 s=p.read_text(encoding='utf8');return '\n'.join(line for line in s.splitlines()if not line.startswith('#include '))+'\n'
block=R/'.scratch/mtp-q27-fp8-20261024/binding-probe.cc';s=body(block);s=s[:s.index('int main(')]
s=replace(s,'namespace {','namespace block128_binding {')
s=s.replace('q::Backend::create()','q::Backend::create({.primary=hyle::inference::BackendKind::kCpu})').replace('q::Backend::name()','backend.name()')
s=replace(s,'q::Recipe r(bank,backend,geometry,3);','q::ProjectionBindings projections; projections.emplace(w.name,q::resolve_projection(bank,w.name));\n q::Recipe r(bank,projections,backend,geometry,3);')
write(D/'block128.inc',s)
mixed=R/'.scratch/mtp-q27-fp8-20261024/cat08-binding-probe.cc';s=body(mixed)
s=s[:s.index('void tiny_loader(')]+'}\n'
s=replace(s,'namespace {','namespace ct_mixed_binding {')
s=s.replace('q::Backend::create()','q::Backend::create({.primary=hyle::inference::BackendKind::kCpu})').replace('q::Backend::name()','backend.name()')
s=replace(s,'q::Recipe r(bank,backend,geometry,M);','q::ProjectionBindings projections;projections.emplace(name,q::resolve_projection(bank,name));q::Recipe r(bank,projections,backend,geometry,M);')
s=replace(s,'<<" zero_outputs="<<zeros','<<" score_policy="<<q::score_policy(projections.at(name))<<" zero_outputs="<<zeros')
write(D/'ct-mixed.inc',s)
header='''// Reused fixed original source tiles and unchanged independent oracles.
#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_geometry_fixture.h"
#include "tests/compute_models/nvfp4_reference_fixture.h"
#include "tests/compute_models/fp8_channel_token_qdq_fixture.h"
#include "tests/compute_models/local_nvfp4_reference_fixture.h"
#include "block128.inc"
#include "ct-mixed.inc"
int main(int argc,char**argv){try{
 if(argc!=3)throw std::runtime_error("projection-source-contracts COMPONENTS_ROOT FP8_SCRATCH_ROOT");
 block128_binding::one(argv[1],"q27-fp8-bf16-sf",5120);
 const std::filesystem::path root=argv[2];const auto roles=qwen35::read_weight_roles(root/"cat08-metadata1/original-headers.tsv",true);
 if(roles.selected.size()!=1603||roles.omitted_cache_calibration.size()!=32)throw std::runtime_error("actual CT header inventory changed");
 ct_mixed_binding::channel(root,roles,true); // Head exercises the same channel projection plus BF16→F32.
 ct_mixed_binding::local(root,roles);
 return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\\n';return 1;}}
'''
write(D/'source-contracts.cc',header)
packed=R/'tests/tools/qwen_mtp_projection_width_probe.cc';s=body(packed);s=s[:s.index('int main(')]
s=s.replace('namespace q=qwen35;\n','');s=replace(s,'namespace {','namespace original_packed_head {')
s=s.replace('q::Backend::create()','q::Backend::create({.primary=hyle::inference::BackendKind::kCpu})')
if 'q::Recipe recipe(bank,backend,geometry,2);'in s:
 s=replace(s,'q::Recipe recipe(bank,backend,geometry,2);','q::ProjectionBindings projections;projections.emplace("lm_head.weight",q::resolve_projection(bank,"lm_head.weight"));\n  q::Recipe recipe(bank,projections,backend,geometry,2);')
 s=replace(s,'q::Recipe bad(bank,backend,geometry,2);','q::ProjectionBindings bad_bindings;bad_bindings.emplace("lm_head.weight",q::resolve_projection(bank,"lm_head.weight"));q::Recipe bad(bank,bad_bindings,backend,geometry,2);')
 s=s.replace('q::projection_score_policy(bank,"lm_head.weight")','q::score_policy(projections.at("lm_head.weight"))')
 s=replace(s,'bank.emplace("lm_head.input_scale",std::move(missing));if(!rejected)','bank.emplace("lm_head.input_scale",std::move(missing));projections.at("lm_head.weight")=q::resolve_projection(bank,"lm_head.weight");if(!rejected)')
elif s.count('q::Recipe recipe(bank,projections,backend,geometry,2);')!=1 or s.count('q::score_policy(projections.at("lm_head.weight"))')!=2:
 raise ValueError('Unknown already-migrated packed head consumer')
write(D/'packed-head.inc',s)
proofs=[R/'docs/evidence/correctness/mtp-qwen-fp8-block128-prepared-binding-2026-10-24.json',R/'docs/evidence/correctness/mtp-qwen-ct-mixed-prepared-binding-2026-10-24.json',R/'docs/evidence/correctness/mtp-fixed-width-packed-head-2026-10-24.json',R/'docs/evidence/correctness/gptq-reference-2026-10-20.json',R/'docs/evidence/correctness/ct-packed-cpu-2026-10-20.json']
data=[R/'.scratch/mtp-metadata-offline-20261024/components/q27-fp8-bf16-sf/codes.bin',R/'.scratch/mtp-metadata-offline-20261024/components/q27-fp8-bf16-sf/scales.bin',R/'.scratch/mtp-q27-fp8-20261024/cat08-metadata1/original-headers.tsv',R/'.scratch/mtp-correctness-20261024/projection-check/cpu/head-vectors/logits.f32']
data += [R/'.scratch/mtp-metadata-offline-20261024/components/q27-nvfp4-original-head'/name for name in ['codes.bin','scales.bin','globals.bin']]
data += [R/f'.scratch/mtp-q27-fp8-20261024/cat08-tiles/{n:02d}/payload.bin'for n in range(2,8)]
for p in data:
 if not p.is_file():raise ValueError('Missing already-cached fixture: '+str(p))
record=dict(state='prepared_not_compiled_or_run',original_consumers=[ident(p)for p in [block,mixed,packed]],baseline_proofs=[ident(p)for p in proofs],cached_inputs=[ident(p)for p in data],independent_fixture_headers=[ident(R/p)for p in ['tests/compute_models/gptq_reference_fixture.h','tests/compute_models/ct_packed_linear_fixture.h']],execution_plan='Only CPU. TU1 q27 block128, CT channel head, CT localNVFP4. TU2 original NVFP4 head plus existing small GPTQ F16→BF16 quartet, CTsym BF16 projection→F32 head, plain F32 head. No full loader/whole model, repeated source publishers or backend matrix.',runtime_closure='Reuse corrected pureCPU engine-cpu-current2 exact closure and native runtime, replace only two app objects with each private TU; do not build or copy SDK.',models_started=0,builds_started=0,HTTP=0)
write(D/'preparation.json',json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(state=record['state'],cached_inputs=len(data),source_contracts=['block128 divide/BF16 SF','channel/token BF16 QDQ + head widening','localNVFP4 F32 preround','original ModelOpt NVFP4 head','GPTQ F16 closed4nodes','CTsym BF16 + F32 head','plain F32 head'],HTTP=0)))
