"""Install the reviewed cold binding resolver and unchanged projection equations."""
from pathlib import Path
import hashlib
import json

D = Path(__file__).resolve().parent
R = D.parents[1]
p = R/'engine/models/qwen35/main.cc'
old = p.read_bytes()
assert hashlib.sha256(old).hexdigest() == '5f39cf6138a7544034ab126714a8805dac34e5e47c85c39ef317f7f427e9c339'
s = old.decode('utf8').replace('\r\n','\n')
def replace(before, after, count=1):
    global s
    assert s.count(before) == count, (before, s.count(before))
    s = s.replace(before, after)

replace('#include <thread>', '#include <thread>\n#include <type_traits>')
replace('#include "prepared_roles.h"', '#include "prepared_roles.h"\n#include "projection_binding.h"')
replace('constexpr char score_policy[] = "bf16_inputs_f32_output";\n', '')
start = s.index('prepared::ProjectionCodec projection_codec_for(')
end = s.index('struct StateSchema final', start)
s = s[:start] + (D/'resolver.inc').read_text() + '\n' + s[end:]
replace('  std::map<std::string, V> weights;\n', '  std::map<Tensor *, V> operands;\n')
replace('  std::map<std::string, Tensor> &bank;\n',
        '  std::map<std::string, Tensor> &bank;\n  const ProjectionBindings &projections;\n')
replace('Recipe(std::map<std::string, Tensor> &selected, const Backend &environment, const ModelGeometry &model_geometry,',
        'Recipe(std::map<std::string, Tensor> &selected, const ProjectionBindings &selected_projections,\n         const Backend &environment, const ModelGeometry &model_geometry,')
replace(': bank(selected), meanings(parameter_meanings), resource(environment.device()),',
        ': bank(selected), projections(selected_projections), meanings(parameter_meanings), resource(environment.device()),')
start = s.index('  V weight_absolute(')
end = s.index('  V weight(', start)
s = s[:start] + '''  V operand(Tensor &tensor) {
    const auto found = operands.find(&tensor);
    if (found != operands.end()) return found->second;
    const auto value = constant(tensor);
    operands.emplace(&tensor, value);
    return value;
  }
  V weight_absolute(const std::string &name) {
    const auto original = bank.find(name);
    if (original == bank.end()) throw std::runtime_error("missing original model role: " + name);
    return operand(original->second);
  }
''' + s[end:]
start = s.index('  V linear_absolute(')
end = s.index('  V norm_absolute(', start)
s = s[:start] + (D/'emitter.inc').read_text() + s[end:]
replace('  std::map<std::string, Tensor> weights;\n',
        '  std::map<std::string, Tensor> weights;\n  ProjectionBindings projections;\n')
replace('  std::map<std::string, Tensor> &weights;\n',
        '  std::map<std::string, Tensor> &weights;\n  ProjectionBindings &projections;\n')
replace('weight_pools(resources_->weight_pools), weights(resources_->weights),',
        'weight_pools(resources_->weight_pools), weights(resources_->weights), projections(resources_->projections),')
replace('    weight_meanings = std::move(loading.meanings);',
        '    weight_meanings = std::move(loading.meanings);\n    projections = prepare_projection_bindings(weights, cache_plan.draft_cache, geometry);')
replace('    return projection_score_policy(weights, geometry.head_role());',
        '    return score_policy(projections.at(std::string(geometry.head_role())));')
replace('Recipe r(weights, execution, geometry,', 'Recipe r(weights, projections, execution, geometry,', 4)
p.write_text(s, encoding='utf8', newline='\n')
(D/'main-before.cc').write_bytes(old)
(D/'main-integration.json').write_text(json.dumps({'before_sha256':hashlib.sha256(old).hexdigest(),
    'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'resolver_sha256':hashlib.sha256((D/'resolver.inc').read_bytes()).hexdigest(),
    'emitter_sha256':hashlib.sha256((D/'emitter.inc').read_bytes()).hexdigest()},indent=2)+'\n')
print('Integrated cold projection bindings, all four Model Recipe sites and score reporting')
