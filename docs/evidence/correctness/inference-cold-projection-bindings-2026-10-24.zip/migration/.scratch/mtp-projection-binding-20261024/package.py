"""Publish only the bounded cold-projection migration results and reproduction inputs."""
from pathlib import Path
import difflib, hashlib, json, zipfile
D=Path(__file__).resolve().parent
R=D.parents[1]
G=D/'regression'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p): return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
s=read(G/'summary.json')
assert s['state']=='passed_finite_CPU_projection_binding_math'
assert s['actual_math_graph_submissions']==7 and s['cold_GGUF_graph_submissions']==0 and s['SDK_builds']==0 and s['HTTP']==0
integration=read(D/'main-integration.json')
main=R/'engine/models/qwen35/main.cc'
assert pin(main)['sha256']==integration['after_sha256']
for name in ['main-syntax1','probe-syntax1']:
    r=read(D/name/'process.json'); assert r['exit']==0 and not r['timeout']
for row in read(G/'source-pins.json'):
    a,b=row['original'],row['frozen']
    assert hashlib.sha256(Path(a['path']).read_bytes()).hexdigest()==a['sha256']
    assert hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['sha256']
out=R/'docs/evidence/correctness/inference-cold-projection-bindings-2026-10-24'
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    with zipfile.ZipFile(G/'logs.zip') as source:
        assert source.testzip() is None
        for entry in source.infolist():
            if not entry.is_dir(): z.writestr('regression/'+entry.filename,source.read(entry))
    for name in ['main-syntax1','probe-syntax1']:
        for p in (D/name).iterdir():
            if p.suffix in {'.json','.log'}: z.write(p,'strict/'+name+'/'+p.name)
    for p in [D/'main-before.cc',D/'main-integration.json',D/'resolver.inc',D/'emitter.inc',D/'integrate-main.py',Path(__file__),R/'tests/tools/qwen_mtp_projection_width_probe.cc']:
        z.write(p,'migration/'+p.relative_to(R).as_posix())
    for item in s['historical_preparation_snapshot']['cached_inputs']:
        p=Path(item['path']); assert p.stat().st_size==item['bytes']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
        assert 'regression/cached-inputs/'+p.relative_to(R).as_posix() in z.namelist()
    delta=''.join(difflib.unified_diff((D/'main-before.cc').read_text().splitlines(True),main.read_text().splitlines(True),fromfile='before/main.cc',tofile='current/main.cc'))
    z.writestr('migration/main.patch',delta)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any(Path(x).suffix.lower() in {'.obj','.exe','.lib','.dll','.pdb'} for x in z.namelist())
result=dict(
 status='PASS bounded ordinary/MTP cold projection binding migration',
 scope='Model-private loaded-weight binding reused by ordinary and MTP; foundational Graph/Compute execution and backend selection remain unchanged.',
 changes=[
  'One cold binding per logical projection owns no storage: stable loaded Tensor references and existing typed computation parameters only.',
  'One emitter serves ordinary/MTP target and draft, frontier and prefix programs; score policy uses the same binding.',
  'Dense/GGUF logits remain direct F32; quantized reference projections retain their original BF16 result followed by F32 widening.',
  'GPTQ F16 decode and exact four-node fusion candidate chain, CT BF16 product rounding, the two NVFP4 global contracts, block128 Divide/floor and channel/token BF16 QDQ are preserved.',
  'Binding destruction precedes original weights and pools; no Provider/platform fields or per-token dispatch were added.'
 ],
 actual_checks=dict(CPU_strict_main=read(D/'main-syntax1/process.json'),CPU_strict_projection_tool=read(D/'probe-syntax1/process.json'),finite_CPU_consumers={k:s[k] for k in ['state','actual_math_graph_submissions','cold_GGUF_graphs','cold_GGUF_graph_submissions','component_processes','whole_model_processes','compiled_private_TUs','scope']},finite_summary=pin(G/'summary.json')),
 source=[pin(R/p) for p in ['engine/models/qwen35/main.cc','engine/models/qwen35/projection_binding.h','tests/tools/qwen_mtp_projection_width_probe.cc']],
 limits=['Seven fixed CPU Graph submissions and one GGUF cold graph do not establish trained-model quality or end-to-end performance.',
         'No complete model, new backend matrix or SDK build; existing separate backend/model evidence remains separate.',
         'Actual selected Provider fusion regions and end-to-end speed were not measured in these component probes.',
         'Shared cross-model state and ordinary/MTP orchestration architecture are still being converged.'],
 SDK_builds=0,HTTP=0,performance_claim=False,archive=pin(archive))
out.with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(result=pin(out.with_suffix('.json')),archive=pin(archive))))
