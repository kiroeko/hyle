# DS greedy 共用选择算法：实施交接

只改三个文件；差异以 `before/` 对当前源码生成的 `changes.patch` 为准，精确身份见 `source-pins.json`。
本代理没有编译、运行、下载或修改 main/RequestWindow；另一代理负责有限真实验证。

- `engine/inference/mtp_acceptance.h`：原 `choose_prefix` 仍是唯一接受/EOS/quota扫描。
  私有输出准备/写入仅按 vector/span 静态重载；vector 仍先检查输入和terminal pending，再clear/reserve，
  不多分配、不改变发出的前缀。只新增 greedy 的 span 重载，没有增加 sampled 或控制器框架。
  span 要完整 `min(quota, inputs.size())` 容量，即使首个EOS可使实际输出更短；不足在写前拒绝。
  只写 result.consumed 个元素，余下尾部不改；输出与输入/target span 不重叠是明示前置条件。
- `dspark_block5_policy.h`：原 trained6/单current特例、全部proposal ID（包括未验证tail）、
  全部target ID、confidence域/数量、EOS与容量校验及各原Status返回完全保留。
  已有 `VerifiedPrefix` 保留是因为它还报告DS的quota/context耗尽及can_continue，不是新建另一个接受结果。
  删除原本重复的接受扫描，栈上6个I32供公共selector输出；无vector/堆分配、无kernel/同步/provider查询。
  pending_row=selected.consumed-1、emitted_count=consumed及耗尽标志从公共选择事实直接投影。
- 实际Pro和sidecar消费者源码未改，因为它们原来就调用这个policy入口；现在实际运行也会到公共算法。
  它们仍以原 `verified_rows[pending_row]` 真实I32输出lease传给完整 `State::selected`，
  原StateHead/RNG/所有资源事务范围、取消/退休与旧读者寿命都没有迁移或旁路。
- `dspark_block5_policy_test.cc` 新增一个有意义的span边界例：实际修正prefix只写3项，保留尾canary；
  即使首row EOS会提前结束，容量5仍不能承载完整上界6，必须拒绝且全部canary不变。
  原负例补充未验证第6个proposal非法仍返回InvalidArgument，以及terminal pending仍返回FailedPrecondition。

风险与验证边界：span输出是新API，其长度和非重叠合同不能从旧vector测试推断；新增例覆盖长度及尾写入。
DS前置校验保证进入公共selector时形状/ID/quota/terminal合法，因此原Result失败不改成异常。
新公共selector不会验证其他模型的训练shape/confidence，仍由模型自己负责。
原14个host例、新增1个span例和一条原权重Pro short-tail消费者待另一代理实际执行；不能仅凭源码判定通过。
