# 交付一：有限 generation 合同独立源码审查

结论：本次选定范围未发现确定阻断；不需要为收口增加 RoundPlan、第二控制器、共享 publisher 或统一状态容器。
范围是当前源码与已存在的有限证据对照；本代理没有编译、运行、下载，没有代签本轮 DS 在途实际结果或新的全模型/GLM运行。

## 公共边界与实际调用

- `engine/inference/mtp_acceptance.h:56` 的 `detail::choose_prefix` 是通用接受/EOS/quota 扫描的唯一实现。
  greedy 的 vector/span 两输出适配和 sampled（含 m0）均调用它；`consumed` 包含 mandatory current，`consumed_drafts` 仅计已消费非终止草稿。
  匹配/接受 EOS 或 quota 最后一个输出仍 pending，不进入 state；selector 不执行图、不拥有 lease、状态、RNG 或 cache。
  新 span greedy 明示输出不重叠，先核完整上界容量，仅写 consumed 项；DS 栈上6项满足此合同。
- Qwen engine `main.cc:4185/4272` 的 recursive 与 classic m0/K1 finish 都直接调用公共 selector。
  context/实际 width 由原 prepare/admission 裁剪，selector 不伪造尚未执行的行；Text 单行的 EOS 判定是请求停止/观察，不是另一套 speculative scan。
- GLM Flash/Pro greedy K1、随机 K1、随机 K2 和单行尾部均用公共 selector；原 `K1Decision/Checkpoint/decide_k1` 已移除。
  `glm_stochastic_prefix_fragment.h:103` 的 K2 只把实际 decisions 和 quota/EOS 交给公共选择，m2 的 T3/context 前提仍由调用方保证。
- DS `dspark_block5_policy.h:137` 现在调用 span greedy 公共入口；旧 trained6/单current、全ID、confidence 域、容量和 Status 校验仍在模型策略层。
  `VerifiedPrefix` 只是公共 consumed/next/stopped 到原 pending_row 与 DS quota/context exhaustion 的投影，未保留第二段接受扫描。
  DS formal/sidecar stochastic 也调用公共 sampled；Pro:740、sidecar:1980 的 while(accepted...accepts)只用于统计/受控fixture判断，candidate取 choice.consumed-1，未用该计数旁路 EOS/quota。

## 完整状态、pending 与失败原子范围

- Qwen `main.cc:3880–4055` 先取被选 GDN/carry 与完整 KV prefix，再做必要 draft repair；所有 fallible 导出/解绑/metadata/expected-base 检查完成后才批次换 head并提交ledger。
  RNG 在未发布 next 内更新；异常 abort 原 episode。trace/report 在权威 commit 后，后续观察据原 ledger 幂等补齐，不重新采样。
- GLM K1 随机保 `accepted && consumed==1 ? original q lease : residual/bonus lease`；完整 after-current 与 after-proposal/repair 由 consumed_drafts 选择。
  K2 用 consumed-1 选原 proposal/final lease，replay(consumed_drafts) 修真实 target tap；原 store.begin→replace pending+cursor→finalize→head.publish(expected-base) 保留。
  消费器中的取消、错类型及 stale 分支是有意负例，不是另一个发布协议；expected-base失败不推进原 Head/RNG。
- DS `dspark_original_state_consumer.h:407` 的 select_verified 仍认证 frame/session/epoch/position/rows，再同一 StateDraft 绑定真实 history/captures/全部target state/pending/metadata/RNG。
  Pro `selected` 和 sidecar 同理；pending_row=consumed-1 对应原 verifier I32 lease。trained五行几何、Markov/confidence、四行history捕获保原模型合同。
- Qwen Snapshot+整batch host原子发布，与 GLM/DS StateHead 单版本 expected-base 发布不能机械合并；两者共用选择事实，不共用伪 Snapshot 或第二份端口/owner表。

## 需保留的有限差异（不作为追加任务）

- `qwen_mtp_state_consumer_test.cc:2970` 的原角色 greedy K1仍是单次 proposal==target0、固定两输出/无EOS 的旧组件合同；它不是通用EOS/quota扫描。
  该消费器 SamplingLimits 只在 stochastic 分支启用；不能把它的 greedy 测试解释成任意 limits 支持或声称每个历史fixture都已调用公共selector。
- GLM greedy 原组件也明确固定quota2/noEOS，只是已用公共selector表达；可配置尾部证明属于其随机组件与实际单行分流。
- DS短宽/EOS/quota控制和GLM/Qwen受控prefix分支，复用真实结果lease验证状态选择，但人为指定边界/分支不代表自然EOS、接受率或完整模型质量。
- 生产路径的预停止EOS检查、草稿遇EOS截短、context/quota决定提交宽度，以及模型repair/catchup循环属于不同职责，不能为了零重复而并入接受扫描。
- 新模型仍需声明原 q/p 产生方式、完整checkpoint与真实pending lease映射、repair和expected-base适配；更换这些不要求改其它模型的容器/数学。
  新codec仍由模型/artifact cold projection binding处理，不进入公共selector、RequestWindow或状态发布原语。

## 可复用证据及边界

- `docs/evidence/correctness/inference-k1-acceptance-2026-10-24.json`：已有Qwen K1/m0 old/current与有限原角色GLM调用证据；不是本轮新增运行。
- `docs/evidence/correctness/inference-request-window-2026-10-24.json`：共享Text/MTP窗口实际有限回归，不能替代DS/GLM全模型。
- `deepseek-mtp-block5-controls-2026-10-24.json`、`mtp-{qwen24,glm}-original-stochastic-k2-state-2026-10-24.json`：原有限状态/随机组件覆盖，保其trained/upstream/硬件边界。
- Root已告知本轮DS15host通过；本审查不把该通知或在途Pro短宽任务写成新的本代理执行结果。

## 本次读取源码身份

- `engine/inference/mtp_acceptance.h`: `8d72de0dc241901758188fddc78b04f5b3aedde2e500ef521c71ec13a05df9ec`
- `engine/models/qwen35/main.cc`: `da27965d52d1e67897eb4e3af9c634be0dc454559e5317004353be968db641c1`
- `tests/compute_models/dspark_block5_policy.h`: `5f167e24f824b9f21162d75f8f6a94cb8402db5309515f11f9abc5ccb1550153`
- `tests/compute_models/glm_mtp_state_consumer_test.cc`: `d11bbfd8d29d506c234ca007ccff5986d09dc11cb2bb5c06442976874fa758b1`
- `tests/compute_models/glm_pro_mtp_state_consumer_test.cc`: `0ce7d5cdd15ed9da0bba28cde094e903965e25b00a9f6ccee5429e58d27419b2`
- `tests/compute_models/qwen_mtp_state_consumer_test.cc`: `de1d7ba915fa5448b2468936be653e17c72aa355650949e1fc2656e0d0190f3f`
- `tests/compute_models/dspark_original_state_consumer.h`: `c59f8d35cad2a435806e82fc07f433c19b2969e9ed76930b5591db9eec52f748`
- `tests/compute_models/dspark_original_state_consumer_test.cc`: `965d9ea3d2236c9fd0ab018c5214da8095b114215a66bef48a099aadeb8087b8`
- `tests/compute_models/dspark_pro_mtp_state_consumer_test.cc`: `c900340d1c86996d6fbf3ab10f15fc56336d914fab9875c7656be42dc40f00e2`
- `tests/compute_models/glm_stochastic_prefix_fragment.h`: `8a4826ad409bc7c72acc841d6ace224cccb1ecc867e359b36812958c93906566`
