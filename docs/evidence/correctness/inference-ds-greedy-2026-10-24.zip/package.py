from pathlib import Path
import hashlib
import json
import shutil
import zipfile

D = Path(__file__).resolve().parent
R = D.parents[1]

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def pin(path):
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

records = {}
for kind in ('host', 'actual'):
    base = D / kind / 'attempt3'
    result = read(base / 'run1/summary.json')
    assert result['passed'] and result['skips'] == 0
    records[kind] = {'summary': result, 'image': read(base / 'ready.json')['image'],
                    'compile': read(base / 'compile/process.json'),
                    'link': read(base / 'link/process.json'), 'run': read(base / 'run1/process.json')}
comparison = read(D / 'actual/attempt3/run1/baseline-comparison.json')
assert not comparison['added_properties'] and not comparison['removed_properties']
assert set(comparison['differences']) == {'scope'}
correction = R / '.scratch/dspark-block5-tail-20261024/short-verifier/report-only-scope-correction.diff'
assert comparison['differences']['scope']['current'] in correction.read_text(encoding='utf-8')
baseline = D / 'baseline'
baseline.mkdir(exist_ok=False)
old = R / '.scratch/dspark-block5-tail-20261024/short-verifier/pro-focused'
for name in ('results.xml', 'process.json', 'command.json', 'environment.json'):
    shutil.copy2(old / name, baseline / name)
shutil.copy2(correction, baseline / correction.name)
summary = {'passed': True, 'scope': 'one DS Pro original short-tail case and one existing host policy TU',
           'distinct_consumer_tus': 2, 'compile_attempts_per_tu': 3, 'actual_runtime_cases': 1,
           'host_runtime_actions': 1, 'new_sdk_tus': 0, 'new_HTTP': 0,
           'throughput_claim': False, 'canonical_edits_by_verification_agent': 0,
           'stable_input_pins': read(D / 'stable-inputs.json'), 'checks': records,
           'actual_baseline_comparison': comparison,
           'baseline_review': {'all_properties_identical': False,
               'unchanged_common_properties': len(comparison['properties']) - 1,
               'added': 0, 'removed': 0, 'unexpected_differences': 0,
               'scope_only_change': 'The old image predates an already-recorded report-only scope correction. Exact current text matches that prior diff; no new scope change is attributed to this batch.',
               'prior_report_only_correction': pin(correction),
               'claim': '34 common non-time behavior/provider/contract properties are identical; all35 are not claimed identical.'},
           'attempt_history': [
               {'attempt': 1, 'actual': 'Compile failed: private frozen dependency list missed later stochastic helper. No link/run.',
                'host': 'Strict compile failed C4459: public template local proposals hid host fixture constant. Product source owner renamed local proposal_count; warning remained enabled.'},
               {'attempt': 2, 'actual': 'Compile/link passed but private loop variable shadowed source filename; canonical TU consumed rather than intended frozen source. No model run.',
                'host': 'Compile passed with same canonical-source instrumentation issue; initial link omitted Console subsystem, LNK1561. Same obj Console link2 passed; no runtime.'},
               {'attempt': 3, 'actual': 'One frozen TU, dependency-isolation gate, strict compile/link and original Pro short-tail runtime.',
                'host': 'One frozen TU, dependency-isolation gate, strict compile/link and existing policy/state plus span case runtime.'}],
           'limitations': ['One Pro greedy short-tail original-role path; no new Flash, stochastic or full-model matrix.',
                           'The greedy Pro case has 30 state members and does not execute stochastic cursor publication; no new RNG runtime coverage is claimed.',
                           'Actual short-tail EOS/quota/context cases are controlled policies on authentic IDs/leases, not natural EOS or acceptance-rate evidence.',
                           'Host cases use the existing StateStore fixtures, not trained inference or TPS measurements.']}
save(D / 'proof-summary.json', summary)
candidates = []
for kind in ('host', 'actual'):
    for attempt in ('attempt1', 'attempt2', 'attempt3'):
        base = D / kind / attempt
        for path in base.iterdir():
            if path.is_file() and path.suffix.lower() in ('.obj', '.exe', '.exp', '.lib', '.pdb', '.map', '.dll'):
                candidates.append(pin(path))
save(D / 'cleanup-candidates.json', {'delete_performed': False, 'files': candidates,
     'logical_bytes': sum(row['bytes'] for row in candidates),
     'note': 'Native runtime is a hardlink; logical bytes do not promise physical disk release. Root owns test.ps1 cleanup.'})
archive = D / 'proof.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in sorted(D.rglob('*')):
        if not path.is_file() or path == archive or '__pycache__' in path.parts:
            continue
        if path.suffix.lower() in ('.obj', '.exe', '.exp', '.lib', '.pdb', '.map', '.dll', '.pyc'):
            continue
        if path.suffix.lower() in ('.py', '.json', '.xml', '.log', '.h', '.cc', '.patch'):
            output.write(path, str(path.relative_to(D)))
save(D / 'publication.json', {'summary': pin(D / 'proof-summary.json'), 'archive': pin(archive),
     'cleanup': pin(D / 'cleanup-candidates.json')})
print(json.dumps(read(D / 'publication.json'), indent=2))
