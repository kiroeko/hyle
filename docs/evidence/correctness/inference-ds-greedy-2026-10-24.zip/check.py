from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import re
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[1]
spec = importlib.util.spec_from_file_location('retained_checks', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
OLD = R / '.scratch/dspark-block5-tail-20261024/short-verifier'
POLICY = R / '.scratch/dspark-stochastic-tails-20261024/policy'
CASE = 'DSparkProOriginalState.CudaShortVerifierTailsPreserveActualStateAndContinue'
ATTEMPT = '1'

def work(kind):
    return D / kind / ('attempt' + ATTEMPT)

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def args(path):
    value = read(path)
    return value['command'] if isinstance(value, dict) else value

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

def pin(path):
    path = Path(path).resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def check_stable():
    stable = read(D / 'stable-inputs.json')
    for row in stable:
        if pin(row['path']) != row:
            raise RuntimeError('Canonical input changed before freeze: ' + row['path'])
    return stable

def build(kind):
    stable = check_stable()
    target = work(kind)
    target.mkdir(parents=True, exist_ok=False)
    original = OLD / 'compile-command.json' if kind == 'actual' else POLICY / 'command.json'
    deps = OLD / 'dependencies.json' if kind == 'actual' else POLICY / 'dependencies.json'
    source_name = 'dspark_pro_mtp_state_consumer_test.cc' if kind == 'actual' else 'dspark_block5_policy_test.cc'
    inputs = [R / 'tests/compute_models' / source_name]
    inputs += [Path(path) for path in read(deps)['Data']['Includes']
               if Path(path).is_relative_to(R / 'tests/compute_models')
               or Path(path).is_relative_to(R / 'engine/inference')]
    inputs += [Path(row['path']) for row in stable]
    # Old short-tail dependency records precede later stochastic/source helper
    # additions. Close literal local includes over the current private Hyle
    # test/engine sources, not a copied SDK or a fabricated model fixture.
    visited = set()
    pending = list(inputs)
    while pending:
        source = pending.pop().resolve()
        if source in visited:
            continue
        visited.add(source)
        for include_name in re.findall(r'^\s*#\s*include\s+"([^"]+)"', source.read_text(encoding='utf-8-sig'), re.MULTILINE):
            included = (source.parent / include_name).resolve()
            if not included.is_file():
                included = (R / include_name).resolve()
            if included.is_file() and (included.is_relative_to(R / 'tests') or included.is_relative_to(R / 'engine')):
                pending.append(included)
    inputs = sorted(visited)
    frozen = []
    for source in dict.fromkeys(path.resolve() for path in inputs):
        record = pin(source)
        output = target / 'source' / source.relative_to(R)
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, output)
        assert pin(source) == record
        frozen.append(dict(record, frozen_path=str(output)))
    save(target / 'frozen-sources.json', frozen)
    save(target / 'stable-inputs.json', stable)
    flags = []
    skip = False
    for flag in args(original):
        if skip:
            skip = False
            continue
        if flag == '/sourceDependencies':
            skip = True
            continue
        if flag.startswith(('/Fo', '/Fd')) or flag.endswith(source_name):
            continue
        flags.append(flag)
    command = [flags[0], '/I' + str(target / 'source'), *flags[1:], str(target / 'source/tests/compute_models' / source_name),
               '/Fo' + str(target / 'consumer.obj'), '/sourceDependencies', str(target / 'dependencies.json')]
    sources = [flag for flag in command if flag.endswith('.cc')]
    assert sources == [str(target / 'source/tests/compute_models' / source_name)]
    env = b.environment(command[0])
    b.execute(command, target / 'compile', env, 240)
    dependency_paths = [Path(path) for path in read(target / 'dependencies.json')['Data']['Includes']]
    canonical_leaks = [str(path) for path in dependency_paths
                       if path.is_relative_to(R / 'tests') or path.is_relative_to(R / 'engine')]
    private_leaks = [str(path) for path in dependency_paths
                     if path.is_relative_to(R / '.scratch') and not path.is_relative_to(target / 'source')
                     and any(segment in str(path).replace('\\', '/').lower()
                             for segment in ('/source/tests/', '/source/engine/'))]
    save(target / 'dependency-isolation.json', {'canonical_test_engine_leaks': canonical_leaks,
         'old_private_test_engine_leaks': private_leaks, 'frozen_test_engine': [pin(path) for path in dependency_paths
          if path.is_relative_to(target / 'source')],
         'public_include_and_sdk_cache': [pin(path) for path in dependency_paths
          if not path.is_relative_to(target / 'source') and not path.is_relative_to(R / 'tests')
          and not path.is_relative_to(R / 'engine')]})
    if canonical_leaks or private_leaks:
        raise RuntimeError('Actual compiler dependencies escaped frozen test/engine source')
    save(target / 'project-dependency-pins.json', [pin(path) for path in read(target / 'dependencies.json')['Data']['Includes']
         if Path(path).is_relative_to(R)])
    if kind == 'actual':
        link = [flag for flag in args(OLD / 'link-command.json')
                if not flag.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:'))
                and Path(flag).name.lower() != 'consumer.obj']
    else:
        link = [flag for flag in args(R / '.scratch/qwen35-unsloth-mtp-20261024/prefix-check1/link2/command.json')
                if not flag.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:'))
                and Path(flag).name.lower() != 'prefix.obj']
        actual = args(OLD / 'link-command.json')
        required = ('compute_state--state_versions.obj', 'budget.obj', 'leases.obj', 'layout.obj')
        for suffix in required:
            matches = [flag for flag in actual if Path(flag).name == suffix]
            if len(matches) != 1:
                raise RuntimeError('No unique retained current object: ' + suffix)
            link.append(matches[0])
        link += [str(R / '.scratch/build-compute-v2-dev/lib' / name) for name in ('gtest.lib', 'gtest_main.lib')]
        link.append('/SUBSYSTEM:CONSOLE')
    link += [str(target / 'consumer.obj'), '/OUT:' + str(target / 'checks.exe'), '/IMPLIB:' + str(target / 'checks.lib')]
    save(target / 'reused-inputs.json', [pin(flag) for flag in link if Path(flag).is_file()])
    b.execute(link, target / 'link', env, 120)
    if kind == 'actual':
        native = R / '.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
        os.link(native, target / native.name)
        save(target / 'native.json', pin(target / native.name))
    check_stable()
    save(target / 'ready.json', {'image': pin(target / 'checks.exe'), 'new_consumer_tus': 1,
         'new_sdk_tus': 0, 'new_HTTP': 0, 'kind': kind})
    print('READY', kind, flush=True)

def linkhost(kind):
    assert kind == 'host' and ATTEMPT == '2'
    target = work(kind)
    failed = read(target / 'link/process.json')
    assert failed['exit'] == 1561 and not failed['timeout']
    command = args(target / 'link/command.json')
    assert not any(flag.upper().startswith('/SUBSYSTEM:') for flag in command)
    b.execute([*command, '/SUBSYSTEM:CONSOLE'], target / 'link2', b.environment(args(POLICY / 'command.json')[0]), 120)
    check_stable()
    save(target / 'ready.json', {'image': pin(target / 'checks.exe'), 'new_consumer_tus': 1,
         'new_sdk_tus': 0, 'new_HTTP': 0, 'kind': kind, 'link_folder': 'link2',
         'initial_private_link_failure': 'Missing Console subsystem for gtest_main; original failed command retained.'})
    print('READY', kind, flush=True)

def run(kind):
    target = work(kind)
    ready = read(target / 'ready.json')
    assert pin(ready['image']['path']) == ready['image']
    env = {key: value for key, value in os.environ.items() if not key.startswith('HYLE_DSPARK_')}
    env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    if kind == 'actual':
        env.update(read(OLD / 'pro-focused/environment.json'))
        env.update(HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS='0',
                   HYLE_DSPARK_PRO_FRONTIER_FILE=str(target / 'run1/missing-frontier.json'))
        env['PATH'] = str(target) + ';' + read(R / '.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json')['PATH']
        selected = CASE
    else:
        selected = 'DSparkBlock5Policy.*:DSparkBlock5State.*'
    save(target / 'run-inputs.json', {key: value for key, value in env.items()
         if key.startswith(('HYLE_DSPARK_', 'HF_', 'TRANSFORMERS_'))})
    output = target / 'run1'
    b.execute([str(target / 'checks.exe'), '--gtest_color=no', '--gtest_filter=' + selected,
               '--gtest_output=xml:' + str(output / 'results.xml')], output, env, 360 if kind == 'actual' else 30)
    tree = ET.parse(output / 'results.xml').getroot()
    cases = list(tree.iter('testcase'))
    assert cases and int(tree.get('failures', 0)) == int(tree.get('errors', 0)) == int(tree.get('disabled', 0)) == 0
    assert all(case.find('skipped') is None for case in cases)
    if kind == 'actual':
        assert len(cases) == 1
        before = ET.parse(OLD / 'pro-focused/results.xml').getroot()
        old = {x.get('name'): x.get('value') for x in before.iter('property')}
        new = {x.get('name'): x.get('value') for x in tree.iter('property')}
        common = old.keys() & new.keys()
        compared = {key: {'old': old[key], 'current': new[key]} for key in sorted(common)}
        save(output / 'baseline-comparison.json', {'baseline': pin(OLD / 'pro-focused/results.xml'),
             'properties': compared, 'differences': {key: row for key, row in compared.items() if row['old'] != row['current']},
             'added_properties': {key: new[key] for key in new.keys() - old.keys()},
             'removed_properties': {key: old[key] for key in old.keys() - new.keys()}, 'throughput_claim': False})
    save(output / 'summary.json', {'passed': True, 'tests': len(cases), 'skips': 0, 'filter': selected,
         'scope': 'DS shared-greedy-selector source migration; no whole-model quality or throughput claim',
         'properties': {x.get('name'): x.get('value') for x in tree.iter('property')}})
    print('PASS', kind, len(cases), flush=True)

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('action', choices=('build', 'linkhost', 'run'))
    p.add_argument('kind', choices=('actual', 'host'))
    p.add_argument('--attempt', choices=('1', '2', '3'), default='1')
    args_ = p.parse_args()
    ATTEMPT = args_.attempt
    globals()[args_.action](args_.kind)
