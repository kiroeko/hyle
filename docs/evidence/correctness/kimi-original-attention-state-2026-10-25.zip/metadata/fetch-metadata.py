"""Pinned Kimi shard1/shard4 metadata only; run through existing budget.py."""
from pathlib import Path
import hashlib
import importlib.util
import inspect
import json
import sys
import urllib.request

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SCRIPT = Path(__file__).resolve().relative_to(ROOT).as_posix()
BUDGET = ROOT / '.scratch/mtp-download-budget-20261023/budget.py'
TRANSPORT = ROOT / '.scratch/mtp-metadata-offline-20261024/fetch-small-headers.py'
PLAN = HERE / 'plan.json'
OUT = HERE / 'attempt1'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def run():
    plan = json.loads(PLAN.read_text(encoding='utf-8'))
    assert plan['repository'] == 'moonshotai/Kimi-K3'
    assert plan['revision'] == 'f831ab66814297da540d832a5235f8e904f29d06'
    assert plan['hard_application_body_limit_bytes'] == 8 * 1024 * 1024
    for row in plan['pins']:
        assert sha((ROOT / row['path']).read_bytes()) == row['sha256'], row['path']
    spec = importlib.util.spec_from_file_location('kimi_existing_small_header_transport', TRANSPORT)
    transport = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(transport)
    transport.SCRIPT = SCRIPT
    budget = transport.module()
    guard = urllib.request.urlopen
    assert Path(guard.__code__.co_filename).resolve() == BUDGET.resolve()
    assert inspect.getclosurevars(guard).nonlocals.get('script') == SCRIPT
    budget.require_enabled()
    OUT.mkdir(exist_ok=False)
    inventory = transport.parse_json((ROOT / plan['inventory']).read_bytes())
    assert (inventory['repository'], inventory['revision']) == (plan['repository'], plan['revision'])
    assert len(inventory['metadata_roles']) == 23
    with budget.locked() as ledger:
        start = len(ledger['requests'])
    admitted_upper = 0
    complete = None
    failure_type = None

    def get(fetch, first, last, *, source=None, metadata_kind='expanded'):
        nonlocal admitted_upper
        # Existing Fetch reads at most requested bytes plus one EOF byte for
        # complete bounded API JSON. Pre-admit that worst case, never refund.
        ceiling = last - first + 1 + (source is None)
        if ceiling <= 0 or ceiling > plan['hard_application_body_limit_bytes'] - admitted_upper:
            raise ValueError('Metadata batch total bound would be exceeded; no HTTP opened')
        admitted_upper += ceiling
        budget.require_enabled()
        return fetch.get(first, last, source=source, metadata_kind=metadata_kind)

    try:
        common = dict(repository=plan['repository'], revision=plan['revision'],
            metadata_url=plan['expanded_api_url'], tree_metadata_url=plan['tree_api_url'])
        rows = [dict(common, file=name,
            uri=f'https://hf-mirror.net/{plan["repository"]}/resolve/{plan["revision"]}/{name}')
            for name in plan['files']]
        api_fetch = transport.Fetch(budget, rows[0], timeout=45, receipt_dir=OUT)
        expanded, response = get(api_fetch, 0, transport.API_LIMIT - 1)
        (OUT / 'expanded-api.json').write_bytes(expanded)
        sources = [transport.original_identity(row, expanded) for row in rows]
        # One shared tree response only when needed for the strong Xet ETag.
        if any(source['api_xet_hash'] is None for source in sources):
            tree, response = get(api_fetch, 0, transport.API_LIMIT - 1, metadata_kind='tree')
            (OUT / 'tree-api.json').write_bytes(tree)
            sources = [transport.crosscheck_tree_identity(row, expanded, tree) for row in rows]
        results = []
        for row, source in zip(rows, sources):
            folder = OUT / row['file']
            folder.mkdir()
            transport.save(folder / 'file-identity.json', source)
            fetch = transport.Fetch(budget, row, timeout=45, receipt_dir=OUT)
            preamble, preamble_receipt = get(fetch, 0, 7, source=source)
            (folder / 'header-length.bin').write_bytes(preamble)
            length = transport.header_length(preamble, source['size'])
            raw, receipt = get(fetch, 8, 7 + length, source=source)
            (folder / 'header.json').write_bytes(raw)
            facts = transport.parse_header(raw, source['size'])
            expected = [item for item in inventory['metadata_roles'] if item['shard'] == row['file']]
            checked = []
            for role in expected:
                actual = facts['all_physical_tensors'].get(role['name'])
                if actual is None or any(actual[key] != role[key] for key in ('dtype', 'shape', 'data_offsets')):
                    raise ValueError('Original Kimi selected role metadata differs: ' + role['name'])
                checked.append(dict(role, absolute_inclusive_range=[8 + length + role['data_offsets'][0],
                    7 + length + role['data_offsets'][1]]))
            result = dict(source=source, data_base=8 + length, header_bytes=length,
                header_sha256=sha(raw), tensor_count=facts['tensor_count'],
                unknown_dtype_bytewidths=facts['unknown_dtype_bytewidths'],
                checked_roles=checked, tensor_payload_bytes_read=0,
                full_source_LFS_body_verified=False,
                header_receipt_id=receipt['budget_request_id'],
                prefix_receipt_id=preamble_receipt['budget_request_id'])
            transport.save(folder / 'complete.json', result)
            results.append(result)
        assert sum(len(row['checked_roles']) for row in results) == 23
        complete = dict(status='AUTHENTICATED_ORIGINAL_KIMI_TWO_HEADERS_23_ROLES_ONLY',
            repository=plan['repository'], revision=plan['revision'], results=results,
            tensor_payload_bytes_read=0, automatic_retries=0, full_source_LFS_body_verified=False)
        transport.save(OUT / 'complete.json', complete)
    except BaseException as error:
        failure_type = type(error).__name__
        transport.save(OUT / 'failed.json', dict(status='FAILED_NO_RETRY',
            error_type=failure_type, automatic_retries=0, tensor_payload_bytes_read=0))
        raise
    finally:
        with budget.locked() as ledger:
            requests = [row for row in ledger['requests'][start:] if row['script'] == SCRIPT]
        received = sum(row.get('received_bytes') or 0 for row in requests)
        assert received <= admitted_upper <= plan['hard_application_body_limit_bytes']
        summary = dict(status='PASS' if complete else 'FAILED_NO_RETRY',
            error_type=failure_type, actual_request_ids=[row['id'] for row in requests],
            requests=len(requests), application_body_received_bytes=received,
            admitted_body_ceiling_bytes=admitted_upper,
            hard_application_body_limit_bytes=plan['hard_application_body_limit_bytes'],
            received_bytes_by_final_host={host:sum((row.get('received_bytes') or 0)
                for row in requests if row.get('final_host') == host)
                for host in sorted({row.get('final_host') or 'not-opened' for row in requests})},
            all_opened_final_hosts_mirror=all(row.get('final_host') in (None, 'hf-mirror.net') for row in requests),
            tensor_payload_bytes_read=0, automatic_retries=0)
        transport.save(OUT / 'transfer-summary.json', summary)
        # No request/redirect URL or authorization/signed query is printed.
        print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    run()
