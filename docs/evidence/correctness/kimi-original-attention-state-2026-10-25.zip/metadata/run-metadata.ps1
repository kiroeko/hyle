$ErrorActionPreference = 'Stop'
$kimiRoot = 'C:\public\project-hyle\hyle'
$kimiExpected = Join-Path $kimiRoot '.scratch/inference-kimi-original-binding-20261025/metadata-only'
$kimiActual = (Resolve-Path -LiteralPath $PSScriptRoot).Path
if ($kimiActual -ne $kimiExpected) { throw 'Unexpected fixed metadata task directory' }
$kimiPause = Join-Path $kimiRoot '.scratch/mtp-download-budget-20261023/PAUSED'
$kimiHeld = Join-Path $PSScriptRoot 'PAUSED.before'
if (!(Test-Path -LiteralPath $kimiPause -PathType Leaf) -or (Test-Path -LiteralPath $kimiHeld)) { throw 'Expected unchanged PAUSED marker' }
$kimiPauseHash = (Get-FileHash -LiteralPath $kimiPause -Algorithm SHA256).Hash.ToLowerInvariant()
$kimiStarted = [DateTime]::UtcNow.ToString('o')
Move-Item -LiteralPath $kimiPause -Destination $kimiHeld
$kimiExit = $null
try {
    & python (Join-Path $kimiRoot '.scratch/mtp-download-budget-20261023/budget.py') run (Join-Path $PSScriptRoot 'fetch-metadata.py')
    $kimiExit = $LASTEXITCODE
} finally {
    if ((Test-Path -LiteralPath $kimiPause) -or !(Test-Path -LiteralPath $kimiHeld -PathType Leaf)) { throw 'PAUSED marker changed during exclusive metadata batch' }
    Move-Item -LiteralPath $kimiHeld -Destination $kimiPause
    $kimiAfterHash = (Get-FileHash -LiteralPath $kimiPause -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($kimiAfterHash -ne $kimiPauseHash) { throw 'Restored PAUSED bytes differ' }
    [ordered]@{ started_utc=$kimiStarted; finished_utc=[DateTime]::UtcNow.ToString('o'); process_exit=$kimiExit; paused_restored=$true; original_pause_sha256=$kimiPauseHash; restored_pause_sha256=$kimiAfterHash; automatic_retries=0 } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'pause-restoration.json') -Encoding utf8
}
if ($kimiExit -ne 0) { throw "Kimi metadata-only batch failed; exit $kimiExit; no retry" }
