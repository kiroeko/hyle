# Kimi 原参数方程来源窄审（只读）

- 实际来源／逐文件 SHA 和已完成 union00 的六角色 SHA、有限性见 `summary.json`；未改源码、未编译／运行、未新增 HTTP。
- 原 config 来自既有固定制品审计的 `kimi_k3` 记录（固定 revision f831ab6…），提取原字节 SHA `3fbe29f668729a05a13fa6dbeb01d18e34a77df6a1225e80130a929f8de67b85`，并保留上游记录既有 pin。config 的 `rms_norm_eps=1e-5` 没有单独给 Q/K L2 epsilon。
- config 指向 `modeling_kimi_linear.KimiLinear*`。本次检查范围未找到该固定 revision 的 publisher 执行文件正文；不能用 auto_map 推定 Q/K L2 默认值。

## 明确差异：KDA 的两处 epsilon

- 当前 READY 与独立 raw-row oracle：Q/K 是 `x/sqrt(sum(x²)+1e-5)`；输出 gated RMS 为 `x/sqrt(mean(x²)+1e-5)*原gamma`。
- 固定 llama.cpp `d9e03f1074dbd2979126d91dce1b5d304ec8394e`：`src/models/kimi-k3.cpp:455–457` 把 config RMS eps 传给 Q/K；`src/models/models.h:14–17` 用 eps/D 的 RMS 再缩放，正是上述 sum-space epsilon。
- 本地 vLLM `276fbcff2717bd934cfa37c8a2e4c391f3e7237b`：`vllm/models/kimi_k3/nvidia/ops/third_party/kda/fused_recurrent.py:233–234,550–551` 明确 sum-space **1e-6**；输出 norm 在 `nvidia/kda.py:788` 使用 FusedRMSNormGated，`third_party/flash_linear_attention/ops/kda.py:459–474` 默认 **1e-5**。
- 因此这是实际读取器 policy 差异。冻结 case 若 PASS，只能签“原参数 + 显式 llama/config/F32 operand 合同”，不能签 publisher/vLLM 数值等价。本轮不换 oracle，不改 epsilon。

## 其余已核方程

- 卷积：llama `kimi-k3.cpp:374–395` 按旧 history→当前 input 拼接；converter `kimi_k3.py:307–319` 原 tap-order 纯 reshape。补充本地 GGML（llama HEAD `23b0202…`）`ggml/src/ggml-cpu/ops.cpp:9975–9976` 按 tap 正序点积。当前 tap3 最新、Q/K/V 三 bank 顺序一致，没有反卷积。
- 衰减：converter `:320–324` 取原 A_log 前96并折为 -exp；llama `:412–437` 和 vLLM gate `fused_recurrent.py:61–76` 同为 `-5*sigmoid(exp(A_log)*(f_b(f_a(x))+dt_bias))`，然后递归乘 `exp(gate)`，没有下界 clamp／双重负号。
- 实际 union00 六角色全部有限，原 output norm gamma 位于 [0.0035117012,0.0333751850]；按原 gamma 直接乘，没有 1+gamma。该读取不替代完整23角色数值验证。
- NoPE：原 config `mla_use_nope=true`；llama converter `:230–231` 和模型 `:511`；vLLM `nvidia/model.py:913–918` 断言 NoPE，`mla.py:161–170` 仅显式 use_rope 时创建旋转。当前 PE64 是不旋转的通道，不因变量名含 PE 就加入 RoPE。
- MLA scale：原 QK 128+64=192，llama `kimi-k3.cpp:271`、vLLM `mla.py:150–158` 及当前 append 均 `1/sqrt(192)`，不是 absorbed latent+PE 的576。
- input/QA/latent norm 都使用原 gamma、RMS eps1e-5；MLA sigmoid gate 从 normalized layer input 读取，随后 o projection。与当前 append/raw oracle 的系数及方程边界一致。

## 数值资格限制

原参数 case 仍是 typed BF16 projection／F32中间与完整状态合同；不签 PyTorch/vLLM 的全部 BF16 storepoint／kernel 融合逐位等价。KDA 已归一化上游输入、layer0 输出直供 layer3 MLA 都是明确 fixture；不含跳过层、残差／AttnRes／FFN／全模型质量。READY／数值门完全未改。
