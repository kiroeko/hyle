"""Only the four authenticated Kimi attention-role unions; no retries."""
from pathlib import Path
import hashlib
import importlib.util
import inspect
import json
import os
import sys
import urllib.request

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SCRIPT = Path(__file__).resolve().relative_to(ROOT).as_posix()
BUDGET = ROOT / '.scratch/mtp-download-budget-20261023/budget.py'
TRANSPORT = ROOT / '.scratch/mtp-metadata-offline-20261024/fetch-small-headers.py'
OUT = HERE / 'attempt1'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def run():
    plan = json.loads((HERE / 'plan.json').read_text(encoding='utf-8'))
    assert plan['repository'] == 'moonshotai/Kimi-K3'
    assert plan['revision'] == 'f831ab66814297da540d832a5235f8e904f29d06'
    assert plan['payload_upper_bytes'] == 1352207360 and plan['part_upper_bytes'] == 4194304
    assert len(plan['unions']) == 4 and len(plan['roles']) == 23
    assert sum(row['bytes'] for row in plan['unions']) == plan['payload_upper_bytes']
    for row in plan['pins']:
        assert sha((ROOT / row['path']).read_bytes()) == row['sha256'], row['path']
    spec = importlib.util.spec_from_file_location('kimi_payload_existing_transport', TRANSPORT)
    transport = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(transport)
    transport.SCRIPT = SCRIPT
    budget = transport.module()
    guard = urllib.request.urlopen
    assert Path(guard.__code__.co_filename).resolve() == BUDGET.resolve()
    assert inspect.getclosurevars(guard).nonlocals.get('script') == SCRIPT
    budget.require_enabled()
    OUT.mkdir(exist_ok=False)
    with budget.locked() as ledger:
        start = len(ledger['requests'])
    admitted = 0
    written = 0
    parts = []
    completed_unions = []
    complete = None
    failure_type = None
    try:
        for union in plan['unions']:
            first, last = union['absolute_inclusive']
            assert union['bytes'] == last - first + 1
            assert union['data_base'] + union['data_relative_half_open'][0] == first
            assert union['data_base'] + union['data_relative_half_open'][1] - 1 == last
            source = union['source']
            assert source['file'] == union['file'] and 0 <= first <= last < source['size']
            row = dict(repository=plan['repository'], revision=plan['revision'],
                       file=union['file'], uri=union['uri'])
            fetch = transport.Fetch(budget, row, timeout=45, receipt_dir=OUT)
            filename = OUT / union['output']
            union_parts = []
            union_hash = hashlib.sha256()
            with filename.open('xb') as output:
                for absolute in range(first, last + 1, plan['part_upper_bytes']):
                    end = min(absolute + plan['part_upper_bytes'] - 1, last)
                    amount = end - absolute + 1
                    if amount > plan['payload_upper_bytes'] - admitted:
                        raise ValueError('Kimi exact payload hard bound exceeded before open')
                    admitted += amount
                    budget.require_enabled()
                    raw, receipt = fetch.get(absolute, end, source=source)
                    assert len(raw) == amount
                    offset = output.tell()
                    output.write(raw)
                    output.flush()
                    os.fsync(output.fileno())
                    union_hash.update(raw)
                    part = dict(union_index=union['index'], union_offset=offset,
                        absolute_inclusive=[absolute, end], bytes=amount, sha256=sha(raw),
                        receipt_id=receipt['budget_request_id'])
                    parts.append(part)
                    union_parts.append(part)
                    written += amount
                    transport.save(OUT / 'progress.json', dict(status='IN_PROGRESS',
                        written_bytes=written, admitted_bytes=admitted,
                        verified_parts=len(parts), last_verified_part=part,
                        upper_bytes=plan['payload_upper_bytes']))
                    if len(parts) % 16 == 0:
                        print(json.dumps(dict(verified_parts=len(parts), written_bytes=written,
                            upper_bytes=plan['payload_upper_bytes'])), flush=True)
            assert filename.stat().st_size == union['bytes']
            # Check actual retained bytes against the network part hashes.
            with filename.open('rb') as stored:
                for part in union_parts:
                    assert stored.tell() == part['union_offset']
                    raw = stored.read(part['bytes'])
                    if len(raw) != part['bytes'] or sha(raw) != part['sha256']:
                        raise ValueError('Retained original Kimi part SHA differs')
                assert stored.read(1) == b''
            completed_unions.append(dict(index=union['index'], path=filename.relative_to(ROOT).as_posix(),
                bytes=union['bytes'], sha256=union_hash.hexdigest(),
                original_file=union['file'], absolute_inclusive=union['absolute_inclusive']))
            transport.save(OUT / 'verified-parts.json', dict(parts=parts, completed_unions=completed_unions))
        assert admitted == written == plan['payload_upper_bytes']
        roles = []
        for role in plan['roles']:
            union = plan['unions'][role['union_index']]
            digest = hashlib.sha256()
            remaining = role['bytes']
            with (OUT / union['output']).open('rb') as stored:
                stored.seek(role['union_offset'])
                while remaining:
                    block = stored.read(min(1024 * 1024, remaining))
                    if not block:
                        raise EOFError('Original Kimi role slice ended early')
                    digest.update(block)
                    remaining -= len(block)
            roles.append(dict(role, path=(OUT / union['output']).relative_to(ROOT).as_posix(),
                offset=role['union_offset'], sha256=digest.hexdigest()))
        complete = dict(status='ACQUIRED_ONLY_ORIGINAL_KDA0_14_AND_MLA3_9_ROLES',
            repository=plan['repository'], revision=plan['revision'], payload_bytes=written,
            roles=roles, unions=completed_unions, parts=parts,
            encoded_original_values_changed=False, whole_file_LFS_body_verified=False,
            metadata_HTTP_requests=0, automatic_retries=0)
        transport.save(OUT / 'complete.json', complete)
    except BaseException as error:
        failure_type = type(error).__name__
        transport.save(OUT / 'failed.json', dict(status='FAILED_NO_RETRY',
            error_type=failure_type, verified_bytes_written=written,
            admitted_bytes=admitted, automatic_retries=0))
        raise
    finally:
        with budget.locked() as ledger:
            requests = [row for row in ledger['requests'][start:] if row['script'] == SCRIPT]
        received = sum(row.get('received_bytes') or 0 for row in requests)
        assert received <= admitted <= plan['payload_upper_bytes']
        hosts = sorted({row.get('final_host') or 'not-opened' for row in requests})
        summary = dict(status='PASS' if complete else 'FAILED_NO_RETRY', error_type=failure_type,
            actual_request_ids=[row['id'] for row in requests], requests=len(requests),
            application_body_received_bytes=received, verified_bytes_written=written,
            admitted_bytes=admitted, hard_body_limit_bytes=plan['payload_upper_bytes'],
            received_bytes_by_final_host={host:sum((row.get('received_bytes') or 0)
                for row in requests if row.get('final_host') == host) for host in hosts},
            all_opened_final_hosts_mirror=all(row.get('final_host') in (None, 'hf-mirror.net') for row in requests),
            whole_file_LFS_body_verified=False, automatic_retries=0)
        transport.save(OUT / 'transfer-summary.json', summary)
        print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    run()
