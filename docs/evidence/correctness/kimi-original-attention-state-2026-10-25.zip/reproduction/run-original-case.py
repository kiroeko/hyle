"""Execute ONLY after real body completion/pause restoration and GPU grant.

Uses the already compiled source-bound case. No build, source mutation,
download, fallback, profiler, GPU-idle gate or automatic retry.
"""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent;P=D/'payload-only';T=D/'native-case/compile-check2'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
terminal=b.read(P/'process.json');assert terminal['exit']==0 and not terminal.get('timeout',False)
pause=b.read(P/'pause-restoration.json');assert pause['paused_restored'] and pause['process_exit']==0
assert b.pin(R/'.scratch/mtp-download-budget-20261023/PAUSED')['sha256']==pause['restored_pause_sha256']
complete=b.read(P/'attempt1/complete.json');transfer=b.read(P/'attempt1/transfer-summary.json')
assert complete['repository']=='moonshotai/Kimi-K3' and complete['revision']=='f831ab66814297da540d832a5235f8e904f29d06'
assert complete['payload_bytes']==transfer['application_body_received_bytes']==1352207360
assert transfer['status']=='PASS' and transfer['all_opened_final_hosts_mirror'] and transfer['automatic_retries']==0
assert len(complete['roles'])==23 and len(complete['unions'])==4
assert (P/'attempt1/original-role-pins.txt').is_file()
ready=b.read(T/'ready.json');assert b.pin(T/'checks.exe')==ready['image']
env=os.environ.copy();runtime=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json'
env['PATH']=b.read(runtime)['PATH'];env['HYLE_KIMI_ORIGINAL_ATTENTION_DIR']=str(P/'attempt1')
b.save(T/'original-run-inputs.json',{'image':ready['image'],'complete':b.pin(P/'attempt1/complete.json'),
    'transfer':b.pin(P/'attempt1/transfer-summary.json'),'pins':b.pin(P/'attempt1/original-role-pins.txt'),
    'pause_restoration':b.pin(P/'pause-restoration.json'),'runtime':b.pin(runtime),
    'GPU':'Explicit bounded grant, no idle qualification','whole_shard_LFS_body_verified':False})
b.execute([str(T/'checks.exe'),
    '--gtest_filter=KimiHeterogeneousState.CudaOriginalParametersKdaMlaKeepCompleteStateAcrossContinuation',
    '--gtest_output=xml:'+str(T/'original-result.xml')],T/'original-run',env,120)
