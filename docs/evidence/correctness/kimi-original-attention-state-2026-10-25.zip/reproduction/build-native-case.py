"""Authorized compile/link of one frozen consumer; no payload read or GPU."""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
R=Path.cwd()
D=Path(__file__).resolve().parent
attempt=sys.argv[1] if len(sys.argv)>1 else 'compile-check1'
assert attempt.replace('-','').isalnum()
T=D/'native-case'/attempt
T.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
pins=b.read(D/'native-case/source-pins.json')
for row in pins['before_canonical']+pins['after_private']:
    actual=b.pin(R/row['path'])
    assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],row
expected=[R/row['path'] for row in pins['after_private']]
source=expected[0]
assert source.name=='kimi_heterogeneous_state_consumer_test.cc'
base=D/'borrowed-literal-check1'
original=b.args(base/'compile/command.json')
env=b.environment(original[0]);flags=[];skip=False
for word in original[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    lower=word.lower()
    if lower.startswith(('/fo','/fd')) or lower.endswith(('.cc','.cpp')):continue
    if lower.startswith('/i') and 'inference-kimi-original-binding-20261025' in lower:continue
    flags.append(word)
assert '/W4' in flags and '/WX' in flags
b.execute([original[0],'/I'+str(source.parent),*flags,str(source),
    '/sourceDependencies',str(T/'dependencies.json'),'/Fo'+str(T/'consumer.obj'),
    '/Fd'+str(T/'consumer.pdb')],T/'compile',env,120)
deps=b.read(T/'dependencies.json')['Data']
included={str(Path(path).resolve()).lower() for path in [deps['Source'],*deps['Includes']]}
for path in expected:assert str(path.resolve()).lower() in included,('not compiled',path)
for name in ['kimi_original_attention_layout.h','kimi_original_attention_roles.h','kimi_original_attention_values.h']:
    assert str((R/'tests/compute_models'/name).resolve()).lower() in included,('not canonical',name)
    assert str((D/'source/tests/compute_models'/name).resolve()).lower() not in included,('historical copy',name)
actual_dependencies=[]
for name in [deps['Source'],*deps['Includes']]:
    path=Path(name).resolve()
    if path.is_relative_to(R):actual_dependencies.append(b.pin(path))
b.save(T/'actual-repository-dependencies.json',actual_dependencies)
old=b.args(base/'link/command.json')
previous=str(base/'consumer.obj').lower();count=0;args=[]
for word in old[1:]:
    if word.lower()==previous:args.append(str(T/'consumer.obj'));count+=1
    elif not word.lower().startswith(('/out:','/pdb:','/implib:','/map:')):args.append(word)
assert count==1
b.execute([old[0],*args,'/OUT:'+str(T/'checks.exe'),'/IMPLIB:'+str(T/'checks.lib'),
    '/PDB:'+str(T/'checks.pdb')],T/'link',env,120)
library_paths=[Path(word[len('/LIBPATH:'):].strip('"')) for word in args if word.upper().startswith('/LIBPATH:')]
library_paths += [Path(word) for word in env.get('LIB','').split(';') if word]
def input_path(word):
    path=Path(word)
    if path.is_file():return path
    for directory in library_paths:
        if (directory/path).is_file():return directory/path
    raise RuntimeError('Missing retained input: '+word)
inputs=[dict(argument=word,**b.pin(input_path(word))) for word in args if not word.startswith('/')]
assert len(inputs)==232
b.save(T/'actual-link-inputs.json',inputs)
native=b.read(base/'ready.json')['native']
assert b.pin(Path(native['path']))==native
os.link(native['path'],T/Path(native['path']).name)
for row in pins['before_canonical']+pins['after_private']:
    actual=b.pin(R/row['path'])
    assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],'source changed during build'
b.save(T/'ready.json',{'status':'COMPILED_LINKED_ONLY_ORIGINAL_PAYLOAD_NOT_READ',
    'image':b.pin(T/'checks.exe'),'object':b.pin(T/'consumer.obj'),'native':native,
    'source_pins':pins,'actual_repository_dependencies':len(actual_dependencies),'cached_link_inputs':232,
    'new_TUs':1,'new_SDK_core_provider_TUs':0,'GPU_runs':0,'new_HTTP':0})
print(json.dumps({'status':'READY_COMPILE_ONLY','image':b.pin(T/'checks.exe'),
                  'actual_repository_dependencies':len(actual_dependencies),'cached_link_inputs':232}))
