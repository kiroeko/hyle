"""Source assembly only. Does not modify canonical or the checked four files."""
from pathlib import Path
import difflib
import hashlib
import json
D=Path(__file__).resolve().parent
R=D.parents[1]
T=D/'native-case'
S=T/'source/tests/compute_models'
S.mkdir(parents=True,exist_ok=True)
def pin(path):
    return {'path':str(path.relative_to(R)),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def main():
    canonical=R/'tests/compute_models/kimi_heterogeneous_state_consumer_test.cc'
    original=canonical.read_bytes()
    assert hashlib.sha256(original).hexdigest()=='b79e5fcec7fa926f6fb8468313d8db25bac7b14a7dc41253d81090e30e9df14f'
    base=original.decode()
    ending='} // namespace\n#endif\n'
    assert base.endswith(ending)
    candidate=base.replace('#include "kimi_original_attention_roles.h"',
        '#include "kimi_original_attention_roles.h"\n#include "kimi_original_attention_input.h"\n#include "kimi_original_attention_reference.h"',1)
    body=(D/'native-case-body.txt').read_text()
    candidate=candidate[:-len(ending)]+body+'\n'+ending
    (S/canonical.name).write_text(candidate,encoding='utf8',newline='')
    for name in ['kimi_original_attention_input.h','kimi_original_attention_reference.h']:
        (S/name).write_bytes((D/'source/tests/compute_models'/name).read_bytes())
    patch=''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),
        fromfile='a/tests/compute_models/'+canonical.name,tofile='b/tests/compute_models/'+canonical.name))
    (T/'source.patch').write_text(patch,encoding='utf8',newline='')
    before=[pin(canonical),*[pin(R/'tests/compute_models'/name) for name in [
        'kimi_original_attention_layout.h','kimi_original_attention_roles.h','kimi_original_attention_values.h',
        'd5_kda_full_fragments.h','d5_kimi_remaining_fragments.h']]]
    after=[pin(path) for path in sorted(S.iterdir())]
    (T/'source-pins.json').write_text(json.dumps({'status':'PRIVATE_SOURCE_ONLY_NOT_COMPILED_OR_RUN',
        'before_canonical':before,'after_private':after,'product_edits':0,
        'weights_copied':0,'new_network':0,'new_GPU_runs':0},indent=2)+'\n')
    print(json.dumps({'status':'SOURCE_ONLY','path':str(T.relative_to(R)),
                      'after':after,'checked_four_inputs_unchanged':True}))
if __name__=='__main__':main()
