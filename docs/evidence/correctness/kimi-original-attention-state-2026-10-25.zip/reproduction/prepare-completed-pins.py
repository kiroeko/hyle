"""Offline only, after the original live body batch reaches its real terminal.

Emit the tiny exact test input from retained hashes. No HTTP, weight copy,
upload, build or execution; do not run while acquisition is incomplete.
"""
from pathlib import Path
import hashlib
import json

D=Path(__file__).resolve().parent
R=D.parents[1]
P=D/'payload-only'
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def pinned(text): return len(text)==64 and all(ch in '0123456789abcdef' for ch in text)
def main():
    terminal=read(P/'process.json')
    assert terminal['exit']==0 and not terminal.get('timeout',False)
    pause=read(P/'pause-restoration.json')
    assert pause['paused_restored']
    complete=read(P/'attempt1/complete.json')
    plan=read(P/'plan.json')
    assert complete['repository']==plan['repository']=='moonshotai/Kimi-K3'
    assert complete['revision']==plan['revision']=='f831ab66814297da540d832a5235f8e904f29d06'
    assert complete['payload_bytes']==plan['payload_upper_bytes']==1352207360
    assert len(complete['roles'])==23 and len(complete['unions'])==4
    rows=['KIMI_ORIGINAL_ATTENTION_V1',complete['repository'],complete['revision']]
    for source,wanted in zip(complete['unions'],plan['unions']):
        assert source['index']==wanted['index'] and source['bytes']==wanted['bytes'] and pinned(source['sha256'])
        path=R/source['path'];assert path.stat().st_size==source['bytes']
        rows.append(path.name+' '+source['sha256'])
    completed_roles={role['name']:role for role in complete['roles']}
    wanted_roles={role['name']:role for role in plan['roles']}
    mapping=read(D/'binding-plan.json')['role_mapping']
    assert len(completed_roles)==len(wanted_roles)==len(mapping)==23
    # Source acquisition is ordered by absolute file range; the typed source
    # adapter is ordered by its explicit role enumeration. Join on exact name.
    for binding in mapping:
        source=completed_roles[binding['name']]
        wanted=wanted_roles[binding['name']]
        assert source['bytes']==wanted['bytes'] and pinned(source['sha256'])
        assert source['union_index']==wanted['union_index'] and source['offset']==wanted['union_offset']
        rows.append(source['name']+' '+source['sha256'])
    path=P/'attempt1/original-role-pins.txt'
    raw=('\n'.join(rows)+'\n').encode()
    assert len(raw)<16384
    with path.open('xb') as output:output.write(raw)
    print(json.dumps({'path':str(path.relative_to(R)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
                      'HTTP':0,'weight_bytes_copied':0,'numeric_checked':False}))
if __name__=='__main__':main()
