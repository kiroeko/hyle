include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(ggml_cpu_runtime_patches ggml_runtime_patches)
message(STATUS "CE13 two exact in-tree patch identities passed")
