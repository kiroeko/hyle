from pathlib import Path
import hashlib,json,re,subprocess,zipfile,xml.etree.ElementTree as ET

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g04-g05';FOLDER=BASE/'ce13'
queue=json.loads((BASE/'ce13-validation-job-3.json').read_text(encoding='utf-8'))
assert queue['state']=='TERMINAL_PASS'
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha for p,sha in queue['inputs'].items())
dest=ROOT/'evidence/correctness/inference-g04-g05-ce13-cpu-validation'
assert not dest.exists()
runs=[];files=[]
def xml_count(path,count):
 x=ET.parse(path).getroot()
 assert int(x.attrib['tests'])==count
 assert all(int(x.attrib.get(k,0))==0 for k in ('failures','errors','disabled'))
def folder_files(folder):
 files.extend((p,p.relative_to(BASE).as_posix()) for p in folder.rglob('*') if p.is_file())
source=FOLDER/'cpu-source-1';r=json.loads((source/'result.json').read_text(encoding='utf-8'))
assert r['state']=='TERMINAL_PASS';xml_count(source/'tests.xml',22)
source_record=r
factor=(source/'selected-factors.log').read_text(encoding='utf-8')
assert re.search(r'100% tests passed(?:, 0 tests failed)? out of [1-9][0-9]*',factor)
assert re.search(r'\bhyle_compute_provider_ggml_test\s+\.+\s+Passed',factor)
assert re.search(r'\bhyle_compute_ggml_runtime_test\s+\.+\s+Passed',factor)
runs.append({'kind':'source','record':r});folder_files(source)
for mode in ('asan','ubsan','tsan'):
 folder=BASE/f'risk/host-{mode}-ce13-1'
 r=json.loads((folder/'result.json').read_text(encoding='utf-8'));assert r['state']=='TERMINAL_PASS'
 xml_count(folder/'tests.xml',17)
 assert sum(line.endswith(' PASS') for line in (folder/'nine-risk-modes.log').read_text(encoding='utf-8').splitlines())==9
 runs.append({'kind':'host-risk','mode':mode,'record':r});folder_files(folder)
 archive=BASE/f'risk/source-host-{mode}-ce13-1.zip';files.append((archive,archive.relative_to(BASE).as_posix()))
for mode in ('static','shared'):
 tag=f'cpu-{mode}-ce13-1';r=json.loads((BASE/f'cpu-sdk/result-{tag}.json').read_text(encoding='utf-8'))
 assert r['state']=='TERMINAL_PASS'
 xml_count(BASE/f'cpu-sdk/cpu_math-{tag}.xml',14);xml_count(BASE/f'cpu-sdk/cpu-{tag}.xml',3)
 runs.append({'kind':'sdk','mode':mode,'record':r})
 files.extend((p,p.relative_to(BASE).as_posix()) for p in (BASE/'cpu-sdk').glob(f'*-{tag}.*') if p.is_file())
for run in runs:
 inputs=run['record']['inputs'];inputs=inputs if isinstance(inputs,dict) else {x['path']:x['sha256'] for x in inputs}
 for p,sha in queue['inputs'].items():assert inputs[p]==sha,(run['kind'],run.get('mode'),p)
folder_files(FOLDER)
files.extend((p,p.name) for p in BASE.glob('ce13-validation-job-*.json'))
for name in ('ce13_cpu_source.py','ce13_cpu_host_san.py','launch_ce13_cpu_host_san.py','queue_ce13_validation.py','encoded_cpu_sdk.py','seal_ce13_cpu_validation.py','ce13-validation-plan.json'):
 files.append((BASE/name,'runners/'+name))
last=ROOT/'.scratch/build-compute-v2-dev/Testing/Temporary/LastTest.log'
assert last.is_file();files.append((last,'source-factor-LastTest.log'))
dest.mkdir()
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as package:
 for p,name in sorted(set(files)):package.write(p,name)
failure=json.loads((FOLDER/'identity-audit-failure-1.json').read_text(encoding='utf-8'))
receipt={'kind':'G04_G05_CE13_CPU_PHYSICAL_ROW_AND_IMMUTABLE_EXTENT_VALIDATION',
 'verdict':'PASS_FINITE_ORDINARY_GATES','product_commit':queue['product_commit'],
 'inputs':queue['inputs'],'source_tests':22,'factor_scope':'CPU runtime/provider and actual public Direct/Graph page/ragged consumers',
 'host_tests_per_mode':17,'source_risk_modes_per_mode':9,'sdk_math_per_mode':14,'sdk_common_per_mode':3,'sdk_independent_headers_per_mode':12,
 'runs':[{'kind':x['kind'],'mode':x.get('mode'),'state':x['record']['state'],'stages':x['record']['stages'],'cumulative_seconds':x['record']['cumulative_seconds']} for x in runs],
 'cumulative_measured_stage_seconds':sum(x['record']['cumulative_seconds'] for x in runs),
 'outer_orchestrator_seconds_overlaps_stage_times':sum(x['elapsed_seconds'] for x in queue['stages']),
 'original_packaging_failure':failure,'source_and_before_codegen_audit':json.loads((FOLDER/'source-audit.json').read_text(encoding='utf-8')),
 'codegen':source_record.get('codegen'),'cold_request_extent_bytes_64bit':32,'accounting':'Existing sizeof(Request) metadata/workspace bound; no extra allocation or cache',
 'previous_performance':'evidence/performance/inference-g04-g05-ce12-cpu-encoded-w1-p1/receipt.json remains QUALIFIED/FAIL',
 'limits':['No new performance PASS; unchanged original contract/margin/sampling required after candidate freeze',
  'No public API/layout, query-safety, attention arithmetic, permission, completion or retirement change',
  'CPU-only ordinary gates; mixed Apple/CUDA/Vulkan CPU finite runs remain separately required',
  'Two installed SDK modes reuse one explicitly reconfigured producer tree',
  'Original central-lock selector over-selection retained; no unrelated global factors executed'],
 'raw_zip_sha256':hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest()}
(dest/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('inputs','runs','source_and_before_codegen_audit')},ensure_ascii=False))
