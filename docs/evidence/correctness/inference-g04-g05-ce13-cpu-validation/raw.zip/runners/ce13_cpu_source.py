from pathlib import Path
import hashlib,json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/f'.scratch/inference-gaps/g04-g05/ce13/cpu-source-{sys.argv[1]}'
OUT.mkdir(parents=True,exist_ok=False)
BUILD=ROOT/'.scratch/build-compute-v2-dev'
HOOK=ROOT/'.scratch/inference-gaps/g02/native-page-node/project.cmake'
target='g04_g05_encoded_common_pages'
body=HOOK.read_text(encoding='utf-8')
if target not in body:
 body+='''
if(PROJECT_NAME STREQUAL "hyle")
 function(g04_encoded_common_source)
  add_executable(g04_g05_encoded_common_pages
    "'''+(ROOT/'tests/compute_batch/encoded_page_common_consumer.cc').as_posix()+'''"
    "'''+(ROOT/'tests/compute_provider_ggml/native_paged_test.cc').as_posix()+'''"
    "'''+(ROOT/'tests/compute_provider_ggml/native_ragged_test.cc').as_posix()+'''")
  target_compile_features(g04_g05_encoded_common_pages PRIVATE cxx_std_23)
  target_compile_options(g04_g05_encoded_common_pages PRIVATE /W4 /WX /wd4324 /utf-8)
  target_link_libraries(g04_g05_encoded_common_pages PRIVATE hyle::graph hyle::compute GTest::gtest_main)
  hyle_stage_runtime(g04_g05_encoded_common_pages)
 endfunction()
 cmake_language(DEFER CALL g04_encoded_common_source)
endif()
'''
 HOOK.write_text(body,encoding='utf-8',newline='\n')
setup=subprocess.run(['cmd','/d','/c',str(ROOT/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],capture_output=True,encoding='utf-8',errors='replace',check=True)
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.stdout.splitlines() if '=' in line and not line.startswith('=')))
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
inputs={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in paths if (ROOT/name).is_file() and not name.startswith(('evidence/','.scratch/','.git'))}
result={'state':'RUNNING','identity':{'host':env.get('COMPUTERNAME'),'compiler':env.get('VCTOOLSVERSION'),'routes':'cpu','source_pin':'check actual derived ggml after configure'},'inputs':inputs,
 'scope':'CE13 CPU private generic row-resolution and cold request extents: runtime/provider factors plus actual encoder/F2/Direct/Graph, original paged/ragged/budget failures and query representation boundaries; no unrelated route-global tests, SDK/san/P1 verdict','max_jobs':4,'stages':[],'cumulative_seconds':0}
def save():(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
save()
commands=[('configure',['cmake','-S',str(ROOT),'-B',str(BUILD),'-DCMAKE_PROJECT_INCLUDE='+str(HOOK),'-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=cpu','-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF']),
 ('compile',['cmake','--build',str(BUILD),'--target',target,'hyle_compute_provider_ggml_tests','hyle_compute_ggml_runtime_tests','--parallel','4']),
 ('tests',[str(BUILD/'bin'/f'{target}.exe'),'--gtest_output=xml:'+str(OUT/'tests.xml')])]
commands.append(('selected-factors',['ctest','--test-dir',str(BUILD),'-C','Release','--output-on-failure','--no-tests=error','-L','^(compute_provider_ggml|compute_ggml_runtime)$','-LE','headers']))
if '--numeric-only' in sys.argv:commands[-1][1].append('--gtest_filter=GgmlCpuCacheEncode.Finite*')
if '--encoder-only' in sys.argv:commands[-1][1].append('--gtest_filter=GgmlCpuCacheEncode.*')
if '--new-only' in sys.argv:commands[-1][1].append('--gtest_filter=EncodedCommonPages.*')
if '--skip-configure' in sys.argv:commands=commands[1:]
def capture_generic_codegen():
 ninja=(BUILD/'build.ninja').read_text(encoding='utf-8')
 target=next(line.replace('\\','/') for line in ninja.splitlines()
  if line.startswith('build ') and 'hyle_ggml_cpu_avx2.dir' in line and '/ops.cpp.obj:' in line.replace('\\','/'))
 object_path=BUILD/target.split(': ',1)[0][6:]
 source_id=next(part for part in object_path.parts if part.startswith('source-'))
 derived=BUILD/'src/compute_ggml_runtime'/source_id/'src/ggml-cpu/ops.cpp'
 manifest=json.loads((ROOT/'third_party/ggml_cpu_runtime/patches.json').read_text(encoding='utf-8'))
 expected=next(row['after_sha256'] for row in manifest['files'] if row['path']=='src/ggml-cpu/ops.cpp')
 assert hashlib.sha256(derived.read_bytes()).hexdigest()==expected,'compiled CPU patch source differs'
 cache=(BUILD/'CMakeCache.txt').read_text(encoding='utf-8')
 compiler=Path(next(line.split('=',1)[1] for line in cache.splitlines() if line.startswith('CMAKE_CXX_COMPILER:FILEPATH=')))
 dumpbin=compiler.with_name('dumpbin.exe');raw=OUT/'after-ops-disasm.txt'
 with raw.open('wb') as stream:
  subprocess.run([str(dumpbin),'/disasm:nobytes',str(object_path)],stdout=stream,stderr=subprocess.STDOUT,check=True)
 lines=raw.read_text(encoding='utf-8',errors='replace').splitlines()
 starts=[i for i,line in enumerate(lines) if line.startswith('?ggml_compute_forward_flash_attn_ext_f16_one_chunk')]
 excerpt=[]
 if starts:
  start=starts[0]
  end=next((i for i in range(start+1,len(lines)) if lines[i] and not lines[i].startswith(' ') and lines[i].endswith(':')),len(lines))
  excerpt=lines[start:end]
 (OUT/'after-generic-disasm.txt').write_text('\n'.join(excerpt)+'\n',encoding='utf-8')
 result['codegen']={'object':str(object_path),'object_sha256':hashlib.sha256(object_path.read_bytes()).hexdigest(),
  'derived_source':str(derived),'derived_source_sha256':expected,'compiler':str(compiler),
  'generic_symbol_present':bool(starts),
  'helper_call_instructions':[line for line in excerpt if 'call ' in line and 'hyle_flash_row_offset' in line],
  'limit':'Actual existing-loop codegen evidence only; correctness and qualified performance remain separate'}
 save()

for stage,command in commands:
 start=time.monotonic();log=OUT/f'{stage}.log'
 with log.open('wb') as stream:
  process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
  (OUT/'job.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}));print(f'{stage}: pid={process.pid}',flush=True)
  code=process.wait()
 elapsed=time.monotonic()-start
 result['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
 result['cumulative_seconds']+=elapsed;save();print(f'{stage}: exit={code}, elapsed={elapsed:.3f}s',flush=True)
 if code:
  result['state']='TERMINAL_FAIL';save();(OUT/'job.json').write_text(json.dumps({'state':result['state'],'exit_code':code}));raise SystemExit(code)
 if stage=='compile':capture_generic_codegen()
result['state']='TERMINAL_PASS';save();(OUT/'job.json').write_text(json.dumps({'state':result['state'],'exit_code':0}))
