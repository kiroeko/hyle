from pathlib import Path
import ctypes,ctypes.wintypes as wt,hashlib,json,os,subprocess,sys,time

ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'.scratch/inference-gaps/g04-g05'
queue_id=int(sys.argv[1]) if len(sys.argv)>1 else 1
dependency_queue=int(sys.argv[2]) if len(sys.argv)>2 else 2
path=BASE/f'ce13-validation-job-{queue_id}.json'
assert not path.exists(),'never duplicate an existing queued validation'
dependency_file=BASE/f'queued-vulkan-encoded-page-preflight-{dependency_queue}.json'
dependency=json.loads(dependency_file.read_text(encoding='utf-8'))
paths=subprocess.check_output(['git','ls-files','include/hyle','src/compute','src/compute_batch',
 'src/compute_provider_ggml','src/compute_ggml_runtime','src/compute_route_cpu','src/graph_batch',
 'cmake/HyleDependencyLock.json','third_party/ggml_cpu_runtime','third_party/ggml_runtime'],text=True).splitlines()
inputs={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
record={'state':'WAITING_FOR_CUDA_AND_VULKAN_NUMERIC','pid':os.getpid(),
 'queue_id':queue_id,'dependency_queue':dependency_queue,'dependency_pid':dependency['pid'],'dependency_record':str(dependency_file),
 'product_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'inputs':inputs,'stages':[],'heavy_serial':True,'max_compile_jobs':4}
child=None
def save():path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
def failed(kind,error,traceback):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if child and child.poll() is None else 'TERMINAL_FAIL',error=repr(error));save()
 sys.__excepthook__(kind,error,traceback)
sys.excepthook=failed;save()
if not dependency['state'].startswith('TERMINAL'):
 kernel=ctypes.WinDLL('kernel32',use_last_error=True)
 kernel.OpenProcess.argtypes=[wt.DWORD,wt.BOOL,wt.DWORD];kernel.OpenProcess.restype=wt.HANDLE
 kernel.WaitForSingleObject.argtypes=[wt.HANDLE,wt.DWORD];kernel.WaitForSingleObject.restype=wt.DWORD
 kernel.CloseHandle.argtypes=[wt.HANDLE]
 handle=kernel.OpenProcess(0x00100000,False,dependency['pid'])
 assert handle,'dependency handle missing: inspect actual state; do not restart'
 try:
  while True:
   result=kernel.WaitForSingleObject(handle,5000)
   if result==0:break
   assert result==258,('dependency observation failure',result)
 finally:kernel.CloseHandle(handle)
dependency=json.loads(dependency_file.read_text(encoding='utf-8'))
assert dependency['state']=='TERMINAL_PASS','inspect original CUDA/Air terminal evidence before starting this independent heavy batch'
commands=[('source',[sys.executable,str(BASE/'ce13_cpu_source.py'),'1'])]
commands += [(mode,[sys.executable,str(BASE/'launch_ce13_cpu_host_san.py'),mode,'ce13-1']) for mode in ('asan','ubsan','tsan')]
commands += [(mode+'-sdk',[sys.executable,str(BASE/'encoded_cpu_sdk.py'),mode,'ce13-1']) for mode in ('static','shared')]
for stage,args in commands:
 assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha for p,sha in inputs.items()),'product changed during frozen validation batch'
 log=BASE/'ce13'/f'{stage}-1.log';start=time.monotonic()
 with log.open('wb') as stream:
  child=subprocess.Popen(args,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
  record.update(state='RUNNING',stage=stage,child_pid=child.pid,log=str(log));save();print(stage,child.pid,flush=True)
  code=child.wait()
 record['stages'].append({'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-start,'log':str(log)});save()
 print(stage,'exit',code,flush=True)
 if code:
  record.update(state='TERMINAL_FAIL');save()
  print(log.read_text(encoding='utf-8',errors='replace')[-5000:],flush=True);raise SystemExit(code)
record.update(state='TERMINAL_PASS');save();print('CE13 ordinary source, three host risks and two installed SDK configurations completed',flush=True)
