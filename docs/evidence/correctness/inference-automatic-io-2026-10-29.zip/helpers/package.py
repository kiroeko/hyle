from pathlib import Path
import json, hashlib, zipfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
E=R/'docs/evidence/correctness/inference-automatic-io-2026-10-29.json'
Z=E.with_suffix('.zip')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(data):return hashlib.sha256(data).hexdigest()
def pin(p):
 p=Path(p).resolve();data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=digest(data))
script=read(W/'script-source-freeze.json');cmake=read(W/'cmake-source-freeze.json')
sources=[];files={}
for row in script['sources']+cmake['sources']:
 p=Path(row['path']);p=p if p.is_absolute() else R/p
 actual=pin(p);assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256'])
 sources.append(actual);files['source/'+p.relative_to(R).as_posix()]=p.read_bytes()
for rel in cmake['removed']:assert not (R/rel).exists()
result=dict(schema='hyle.automatic-product-dependencies.v1',date='2026-10-29',status='PASS_FINITE_CONFIGURATION_CHECKS',
 change=['Selected io protocol factors require their dependencies automatically; public TLS/HTTP2 toggles and AUTO helper removed.',
         'The complete CPU/CUDA ATen dependency remains automatic; only real product/route/development choices remain.',
         'Multi-config Debug ignores inherited CMAKE_BUILD_TYPE=Release; existing configurations and invalid selection checks remain.'],
 script_checks=script['checks'],metadata_checks=dict(command='python -B tests/tooling/compute_routes_test.py',tests=15,exit=0,seconds=13.098,source='root tool execution; includes real CMake script and SDK metadata fixtures, no native builds'),
 product_closure=dict(command='cmake -S tests/build_system/component_selection -B .scratch/inference-automatic-io-20261029/component-selection',exit=0,language='NONE',source='root tool execution',cache=pin(W/'component-selection/CMakeCache.txt')),
 dependency_checks=read(W/'dependency-checks.json'),entrypoints=read(W/'entrypoint-checks.json'),sources=sources,removed=cmake['removed'],
 limits=['External OpenSSL discovery and locked nghttp2 materialization are mocked only in the isolated dependency fixture.',
         'No fresh native protocol compilation, complete package smoke/install, network download, or cross-platform run.',
         'Script unit results are the delegated run recorded in script-source-freeze.json; other checks were executed by the root agent.'])
for pattern in ('*-source-freeze.json','*-checks.json','*-help.*.log','util-dry-run.*.log'):
 for p in W.glob(pattern):files['checks/'+p.name]=p.read_bytes()
for directory in ['checks','dependency-fixture']:
 for p in (W/directory).rglob('*'):
  if p.is_file():files[directory+'/'+p.relative_to(W/directory).as_posix()]=p.read_bytes()
files['helpers/package.py']=Path(__file__).read_bytes();files['result.json']=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
manifest={name:dict(bytes=len(data),sha256=digest(data)) for name,data in files.items()}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode('utf-8')
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None and set(z.namelist())==set(files)
 for name,row in manifest.items():
  data=z.read(name);assert len(data)==row['bytes'] and digest(data)==row['sha256']
result['archive']={**pin(Z),'members':len(files),'CRC':'PASS','member_SHA256':'PASS'}
E.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',sources=len(sources),archive_bytes=Z.stat().st_size,members=len(files))))
