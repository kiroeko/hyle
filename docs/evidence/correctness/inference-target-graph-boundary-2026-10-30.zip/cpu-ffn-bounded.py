"""Root-authorized3 processes: attribute tiny refusal, realCPU2 exact pair."""
from pathlib import Path
import importlib.util,json,re
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('target_cpu_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
spec=importlib.util.spec_from_file_location('target_cpu_compare',W/'finite.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
assert not (W/'cpu-ffn-bounded-plan.json').exists()
p=read(W/'baseline-plan.json');args=list(p['cases']['ordinary-single']['args'])
steps=args.index('--steps')+1;assert args[steps]=='64';args[steps]='4';args+=['--cpu-ffn-layers','2']
inputs=Path(args[args.index('--inputs')+1]);manifest=inputs/'weights.tsv';lines=manifest.read_text().splitlines()
assert lines[0]=='HYLE_QWEN_ROLE_FILES_V2' and lines[1].startswith('4a76')
save(W/'cpu-ffn-bounded-plan.json',dict(status='AUTHORIZED_THREE_PROCESSES',original_tiny_case='cpu-ffn-tiny-cuda',
 tiny_candidate_processes=1,real_pair_case='cpu-ffn-real-cuda',real_pair_processes=2,real_args=args,
 manifest=pin(manifest),source_identity=lines[1],geometry=next(line for line in lines if line.startswith('geometry')),
 scope='Current defaultordinary-single exact V2 source/arguments, only steps64→4 and explicitCPUFFN2. Historical4068 source is not current identity. No budget increase, replay fallback changes or prompt-width search.'))
try:b.run('cpu-ffn-tiny-cuda','attempt1')
except BaseException as error:
 save(W/'cpu-ffn-tiny-candidate-driver-exception.json',dict(type=type(error).__name__,message=str(error),
  scope='Expected native refusal captured after real exit; original process/stdout/stderr preserved.'))
tiny={};needle='graph input alias offset cannot satisfy region port alignment'
for arm in ('baseline','candidate'):
 folder=W/'runs'/arm/'cpu-ffn-tiny-cuda/attempt1';process=read(folder/'process.json')
 stderr=(folder/'stderr.log').read_text(encoding='utf-8-sig')
 assert process['state']=='TERMINAL' and process['exit']==1 and not process['timed_out']
 assert needle in stderr and 'finite exact variant index 0' in stderr
 tiny[arm]=dict(process=pin(folder/'process.json'),stderr=pin(folder/'stderr.log'),exit=1,
  refusal='finite variant0 graph input alias port alignment/resource search exhaustion',hybrid_plan_succeeded='hybrid_plan ' in stderr)
assert not any(row['hybrid_plan_succeeded'] for row in tiny.values())
save(W/'cpu-ffn-tiny-attribution.json',dict(status='IDENTICAL_REFUSAL_CLASS_ON_BASELINE_AND_CANDIDATE',arms=tiny,
 scope='Same original tiny input/configuration fails in both old and extracted target math. This pair is failed native coverage, not candidate regression, hardware unsupported or successful mixed placement.'))
print('ATTRIBUTED tiny refusal both arms',flush=True)
reports={};plans={}
for arm,image_name in [('baseline','baseline'),('candidate','cli')]:
 image=read(W/('ready-'+image_name+'.json'));exact(image)
 folder=W/'runs'/arm/'cpu-ffn-real-cuda/attempt1';save(folder/'image.json',image)
 b.c.b.s.b.execute([image['path'],*args],folder,600)
 report=read(folder/'stdout.log');assert report['generated_tokens']==4 and report['live_committed_versions']==0
 assert report['cpu_ffn_layers']==2
 stderr=(folder/'stderr.log').read_text(encoding='utf-8-sig')
 hybrid=[line for line in stderr.splitlines() if line.startswith('hybrid_plan ')]
 constants=[int(re.search(r'host_constants=(\d+)',line).group(1)) for line in hybrid]
 assert constants and all(value>0 for value in constants)
 assert 'weight_placement cpu_ffn_layers=2 ' in stderr
 save(folder/'report.json',report);reports[arm]=report
 plans[arm]=dict(hybrid_plans=hybrid,positive_host_constants=constants,
  original_domain_assertions_executed=True,
  assertion_scope='Unchanged record_execution_plan requires3storage domains/2targets, finite domain admissions and every host original constant in storageDomain1 with zero materialized canonical replica; every hybrid_plan line is after these assertions.')
 print('PASS realCPU2',arm,flush=True)
differences=f.delta(f.stable(reports['baseline']),f.stable(reports['candidate']))
save(W/'compare-cpu-ffn-real-cuda.json',dict(status='PASS' if not differences else 'FAIL',
 all_non_timing_fields_equal=not differences,differences=differences,
 baseline=pin(W/'runs/baseline/cpu-ffn-real-cuda/attempt1/report.json'),
 candidate=pin(W/'runs/candidate/cpu-ffn-real-cuda/attempt1/report.json'),
 source_identity=lines[1],manifest=pin(manifest),actual_plan_evidence=plans,
 scope='Same current real BF16 H2048 full-vocabulary source/154-ID prompt,4generated tokens,first2targetFFNs CPU then primaryGPU. Exact before/after non-time reports; original mixed-domain assertions intact. Finite coverage, not all mixed placements or performance.'))
assert not differences,differences
print('PASS EXACT realCPU2 complete non-time reports; hybrid positive host constants/domain assertions',flush=True)
