"""Finite target-graph verification: only current affected CXX, original cache229."""
from pathlib import Path
import importlib.util,json,os,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('target_graph_prepare',W/'prepare-after-freeze.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.c;read,save,pin,exact,key=m.read,m.save,m.pin,m.exact,m.key
def leaf_recipe():
 assert not (W/'extra-consumers.json').exists()
 source=W/'target-graph-header.cc';source.write_text('#include "../../engine/models/qwen35/target_graph.h"\n')
 base=read(read(W/'plan.json')['base']['path'])
 save(W/'extra-consumers.json',dict(leaf=dict(source=str(source),compile=c.b.s.relocated(base['compile'],'leaf',source))))
def link(name,attempt):
 p=read(W/'plan.json');base=read(p['base']['path'])
 receipt=read(p['reused_consumers'][name]['receipt']['path']) if name in p['reused_consumers'] else read(W/'compile'/name/'receipt.json')
 target=read(W/'compile/target/receipt.json');replacements={}
 for unit,old in p['units'].items():
  current=read(W/'compile'/unit/'receipt.json');replacements[key(old['original']['path'])]=current['object']
 retained=[replacements.get(key(item['path']),item) for item in p['retained']]
 for item in [receipt['object'],*receipt['source_identities'],target['object'],*target['source_identities'],*retained]:exact(item)
 args=[];count=0
 for arg in p['original_link']:
  if key(arg)==key(p['original_consumer']):arg=receipt['object']['path'];count+=1
  if key(arg) in replacements:arg=replacements[key(arg)]['path']
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 assert count==1 and not any(key(arg)==key(target['object']['path']) for arg in args)
 args.append(target['object']['path'])
 for old in base['model_cold_objects']:
  expected=replacements.get(key(old['object']['path']),old['object'])
  assert sum(key(arg)==key(expected['path']) for arg in args)==1
 c.b.s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
def run(case,attempt,baseline=False):
 cases=read(W/'baseline-plan.json')['cases']|read(W/'extra-cases.json');row=cases[case]
 consumer=row['consumer']
 if baseline:consumer={'cli':'baseline','tiny':'baseline-tiny','session':'baseline-session'}[consumer]
 image=read(W/('ready-'+consumer+'.json'));exact(image)
 folder=W/'runs'/('baseline' if baseline else 'candidate')/case/attempt;save(folder/'image.json',image)
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1')
 args=[str(folder/'vectors') if value=='{OUTPUT}' else value for value in row['args']]
 c.b.s.b.execute([image['path'],*args],folder,600)
 text=(folder/'stdout.log').read_text(encoding='utf-8-sig');decoder=json.JSONDecoder();values=[];offset=0
 while offset<len(text):
  while offset<len(text) and text[offset].isspace():offset+=1
  if offset==len(text):break
  value,offset=decoder.raw_decode(text,offset);values.append(value)
 assert values;result=values[0] if len(values)==1 else dict(status='PASS',reports=values)
 if 'outputs' in row:assert result['generated_tokens']==row['outputs'] and result['live_committed_versions']==0
 elif row.get('expected_status'):assert result['status']==row['expected_status']
 else:assert all(value['status'].startswith('PASS') for value in values)
 save(folder/'report.json',result);print('PASS',consumer,case,flush=True)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='leaf-recipe':leaf_recipe()
 elif action=='compile':c.b.compile_group(sys.argv[2],sys.argv[3:])
 elif action=='link':link(sys.argv[2],sys.argv[3])
 elif action=='run':run(sys.argv[2],sys.argv[3],len(sys.argv)>4 and sys.argv[4]=='baseline')
 else:raise ValueError(action)
