"""Seal the completed finite target-graph boundary check, metadata/source only.

Run ONLY after bridge_evidence sends its explicit terminal-ready notification.
This script invokes no build, inference, download, cleanup, or product writes.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
REVIEW = R / '.scratch/inference-target-graph-review-20261030'
EXTRACTION = R / '.scratch/inference-target-graph-extract-20261030'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def pin(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            digest.update(block)
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


verified = {}


def exact(item):
    key = str(Path(item['path']).resolve()).lower()
    if key not in verified:
        verified[key] = pin(item['path'])
    actual = verified[key]
    assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256'], item['path']
    return actual


def key(path):
    return str(Path(path).resolve()).lower()


def terminal(process, successful=False):
    assert process['state'] == 'TERMINAL' and not process.get('timed_out'), process
    if successful:
        assert process['exit'] == 0, process


def normalize_output_root(value, root):
    if isinstance(value, str):
        return value.replace(str(root), '{VECTORS}')
    if isinstance(value, list):
        return [normalize_output_root(item, root) for item in value]
    if isinstance(value, dict):
        return {name: normalize_output_root(item, root) for name, item in value.items()}
    return value


def stable(value):
    if isinstance(value, dict):
        return {name: stable(item) for name, item in value.items()
                if not name.endswith('_seconds') and not name.endswith('_per_second')}
    if isinstance(value, list):
        return [stable(item) for item in value]
    return value


def collect(ready):
    assert ready == 'bridge-terminal-ready', 'Explicit terminal-ready notification is required before collection.'
    assert not (W / 'archive-draft.json').exists(), 'Never silently overwrite an already sealed evidence attempt.'
    plan = read(W / 'plan.json')
    base = read(W / 'model-link-base.json')
    baseline = read(W / 'baseline-plan.json')
    verification = read(W / 'verification-summary.json')
    extraction = read(EXTRACTION / 'plan.json')
    assert plan['base_commit'] == baseline['base_commit'] == extraction['base_head']
    assert plan['base_commit'] == 'e41c31cd83603b951d074f5b2fc0ac0cf8e038ce'
    assert verification['status'] == 'FINITE_TARGET_CHECKS_PASS_TWO_ATTRIBUTED_TINY_REFUSALS_RETAINED'
    assert verification['full_goal_complete'] is False
    assert len(plan['retained']) == len(baseline['retained']) == 228
    assert len(base['retained']) == 229
    assert not plan['units'], 'This slice should reuse all original228; do not hide an actual changed old unit.'
    assert set(plan['consumers']) == {'cli', 'tiny', 'session'}
    assert set(plan['reused_consumers']) == {'rows'}
    old_by_path = {key(item['path']): item for item in plan['retained']}
    new_by_path = {key(item['path']): item for item in base['retained']}
    assert len(old_by_path) == 228 and len(new_by_path) == 229
    assert all(new_by_path.get(path) == item for path, item in old_by_path.items())
    for item in [*plan['retained'], *base['retained'], *baseline['retained'], plan['runtime'], base['runtime']]:
        exact(item)

    baseline_source_readback = []
    for name, baseline_plan in [('cli', baseline),
                                ('session', read(W / 'baseline-session-plan.json')),
                                ('tiny', read(W / 'baseline-tiny-plan.json'))]:
        object_item = baseline_plan.get('object', baseline_plan.get('cli_object'))
        exact(object_item)
        current_count, snapshot_count = 0, 0
        for proof in baseline_plan['source_proofs']:
            identity = proof['identity']
            source = Path(identity['path'])
            if source.is_file() and pin(source) == identity:
                current_count += 1
                continue
            relative = source.relative_to(R)
            snapshot = W / 'baseline-source' / relative
            actual = pin(snapshot)
            assert actual['bytes'] == identity['bytes'] and actual['sha256'] == identity['sha256'], source
            committed = subprocess.check_output(['git', 'show', plan['base_commit'] + ':' + relative.as_posix()], cwd=R)
            assert committed == snapshot.read_bytes(), source
            snapshot_count += 1
        baseline_source_readback.append({'consumer': name, 'source_pin_count': len(baseline_plan['source_proofs']),
            'unchanged_current_exact': current_count, 'exact_committed_baseline_snapshots': snapshot_count,
            'cached_object_hash_exact': True, 'baseline_CXX': 0})
    save(W / 'collector-baseline-source-readback.json', baseline_source_readback)

    # Candidate bytes must be exactly both the author's final full files and
    # the actual source freeze which the compiler consumed.
    freeze = read(W / 'source-freeze.json')
    for item in freeze['sources']:
        exact(item)
    for entry in extraction['candidate']:
        product = R / entry['path']
        candidate = EXTRACTION / 'candidate' / entry['path']
        assert product.read_bytes() == candidate.read_bytes()
        assert pin(product)['sha256'] == entry['sha256']

    receipts = {}
    source_proofs = []
    for path in sorted((W / 'compile').glob('*/receipt.json')):
        receipt = read(path)
        for name in ('object', 'dependencies', 'process'):
            exact(receipt[name])
        terminal(read(receipt['process']['path']), successful=True)
        for item in receipt['source_identities']:
            exact(item)
        receipts[path.parent.name] = {
            'receipt': pin(path), 'object': receipt['object'],
            'source_pin_count': len(receipt['source_identities']), 'all_source_pins_current_exact': True,
        }
        source_proofs.append({'unit': path.parent.name, 'sources': receipt['source_identities'],
                              'all_current_exact': True})
    assert set(receipts) == {'target', 'leaf', 'cli', 'tiny', 'session'}
    target_object = read(W / 'compile/target/receipt.json')['object']
    assert set(new_by_path) - set(old_by_path) == {key(target_object['path'])}
    assert new_by_path[key(target_object['path'])] == target_object
    save(W / 'source-receipt-proofs.json', source_proofs)

    attempts, counts, failed = [], {}, []
    for directory in ('compile', 'link', 'runs'):
        paths = sorted((W / directory).rglob('process.json'))
        counts[directory] = len(paths)
        for path in paths:
            process = read(path)
            terminal(process)
            command = path.parent / 'command.json'
            assert command.is_file(), path
            name = path.parent.relative_to(W).as_posix()
            row = {'name': name, 'process': pin(path), 'actual': process, 'command': pin(command)}
            if process['exit'] != 0:
                failed.append(name)
            if directory == 'runs' and process['exit'] == 0:
                row['report'] = pin(path.parent / 'report.json')
            attempts.append(row)
    native_records = [row for row in attempts if row['name'].startswith('runs/')]
    failed_native = [row['name'] for row in native_records if row['actual']['exit'] != 0]
    assert failed == failed_native, 'No failed compiler/linker attempt can be hidden by a native-only summary.'
    actual_attempts = {'total': sum(counts.values()), 'CXX': counts['compile'], 'links': counts['link'],
        'native': counts['runs'], 'native_pass': counts['runs'] - len(failed_native), 'native_failed': len(failed_native),
        'scratch_parser_exceptions': 1, 'downloads': 0, 'NVCC': 0}
    assert verification['attempts'] == actual_attempts, (verification['attempts'], actual_attempts)
    assert counts['compile'] >= 5 and counts['link'] >= 6 and counts['runs'] >= 18

    whole = read(W / 'whole-cli-summary.json')
    assert whole['status'] == 'PASS_ALL_FOUR_DEFAULT_CASES' and len(whole['checks']) == 4
    assert {row['case'] for row in whole['checks']} == {'ordinary-single', 'mtp-single', 'ordinary-two', 'mtp-two'}
    paired = []
    for row in [*whole['checks'], read(W / 'compare-cpu-ffn-real-cuda.json')]:
        assert row['all_non_timing_fields_equal'] and not row['differences']
        for arm in ('baseline', 'candidate'):
            exact(row[arm])
        assert stable(read(row['baseline']['path'])) == stable(read(row['candidate']['path']))
        paired.append({'case': row.get('case', 'cpu-ffn-real-cuda'), 'complete_non_timing_report_equal': True})
    hybrid_compare = read(W / 'compare-cpu-ffn-real-cuda.json')
    for arm in ('baseline', 'candidate'):
        folder = W / 'runs' / arm / 'cpu-ffn-real-cuda/attempt1'
        terminal(read(folder / 'process.json'), successful=True)
        stderr_lines = (folder / 'stderr.log').read_text(encoding='utf-8-sig').splitlines()
        hybrid_lines = [line for line in stderr_lines if line.startswith('hybrid_plan ')]
        assert hybrid_lines == hybrid_compare['actual_plan_evidence'][arm]['hybrid_plans']
        assert len(hybrid_lines) == 2
        assert all('host_constants=10 ' in line and 'materialized_constant_bytes=0 ' in line for line in hybrid_lines)
        report = read(folder / 'report.json')
        assert report['cpu_ffn_layers'] == 2 and report['generated_tokens'] == 4
        assert report['source_id'] == '4a76decdfa58a5fd6e15acea7ff410e84fd3e81cb6c39db8a658eeb23d869fbe'
        assert report['original_host_weight_bytes'] == 151003136 and report['original_device_weight_bytes'] == 3612652224
        assert len(report['workspace_domains']) == 3 and report['draft_program_graph_calls'] == 0
    tiny_hybrid_rejections = []
    for arm in ('baseline', 'candidate'):
        folder = W / 'runs' / arm / 'cpu-ffn-tiny-cuda/attempt1'
        process = read(folder / 'process.json')
        terminal(process)
        assert process['exit'] == 1
        stderr = (folder / 'stderr.log').read_text(encoding='utf-8-sig')
        assert 'finite exact variant index 0' in stderr
        assert 'graph input alias offset cannot satisfy region port alignment' in stderr
        assert 'graph resource search state budget is exhausted' in stderr
        assert 'hybrid_plan' not in stderr and not (folder / 'report.json').exists()
        tiny_hybrid_rejections.append({'arm': arm, 'exit': 1, 'same_cold_alias_alignment_rejection_category': True,
            'hybrid_plan_or_execution_success_observed': False, 'process': pin(folder / 'process.json'),
            'stderr': pin(folder / 'stderr.log')})
    parser_exception = W / 'finite-attempt1-parser-failure.json'
    assert parser_exception.is_file()
    branches = read(W / 'finite-branch-summary.json')
    assert branches['status'].startswith('PASS_')
    assert {row['case'] for row in branches['checks']} == {'mtp-packed-prefill-cuda', 'mtp-varlen-verify-cuda', 'mtp-e4-cuda'}
    required_branches = {'history-cpu', 'mtp-packed-prefill-cuda', 'mtp-varlen-verify-cuda', 'mtp-e4-cuda'}
    for case in required_branches:
        folders = sorted((W / 'runs/candidate' / case).glob('attempt*'))
        assert folders, case
        terminal(read(folders[-1] / 'process.json'), successful=True)
        report = read(folders[-1] / 'report.json')
        assert report['status'].startswith('PASS'), (case, report.get('status'))

    session = read(W / 'session-compare.json')
    assert session['status'] == 'PASS_EXACT_COMPLETE_SESSION'
    assert session['payload_byte_equal'] and session['observation_equal_after_only_output_root_normalization']
    assert not session['ignored_semantic_fields'] and not session['differences'] and not session['report_differences']
    manifest = read(W / 'session-vector-manifest.json')
    assert manifest['status'] == 'PASS_EXACT_COMPLETE_VECTOR_BYTES'
    assert manifest['file_count_per_arm'] == 378 and manifest['bytes_per_arm'] == 150761472
    assert manifest['all_cross_arm_bytes_identical'] and manifest['numerical_tolerance'] is None
    assert manifest['metadata_equal_except_output_root']
    arms = manifest['arms']
    assert arms['baseline'].keys() == arms['candidate'].keys()
    for arm in ('baseline', 'candidate'):
        assert len(arms[arm]) == manifest['file_count_per_arm']
        assert sum(item['bytes'] for item in arms[arm].values()) == manifest['bytes_per_arm']
        for item in arms[arm].values():
            exact(item)
    for name in arms['baseline']:
        left, right = arms['baseline'][name], arms['candidate'][name]
        assert left['bytes'] == right['bytes'] and left['sha256'] == right['sha256'], name
        with Path(left['path']).open('rb') as one, Path(right['path']).open('rb') as two:
            while True:
                first, second = one.read(4 << 20), two.read(4 << 20)
                assert first == second, name
                if not first:
                    break
    observations = {}
    for arm in ('baseline', 'candidate'):
        folder = W / 'runs' / arm / 'session-cuda/attempt1/vectors'
        observation = read(folder / 'observation.json')
        assert observation['status'] == 'PASS_BYTE_EXACT' and observation['all_vectors_byte_equal']
        assert observation['all_finite'] and observation['numerical_tolerance_policy'] is None
        assert observation['final_live_snapshot_versions'] == 0
        assert observation['idle_head_full_byte_checks'] == 4 and observation['A_calls_after_B_stop'] == 3
        assert observation['managed_backing_bytes'] == observation['planned_backing_bytes'] == 80240691
        for vector in observation['vectors']:
            assert vector['byte_equal'] and vector['max_abs'] == vector['squared_error'] == 0
            assert vector['nonfinite_baseline'] == vector['nonfinite_actual'] == 0
        observations[arm] = normalize_output_root(observation, folder)
    assert observations['baseline'] == observations['candidate']
    save(W / 'collector-vector-readback.json', {
        'status': 'PASS_INDEPENDENT_ALL_HASHES_AND_DIRECT_COMPLETE_BYTES',
        'files_per_arm': manifest['file_count_per_arm'], 'bytes_per_arm': manifest['bytes_per_arm'],
        'all_complete_pairs_byte_equal': True, 'all_original_numerical_checks_zero_error_finite': True,
        'numerical_tolerance': None, 'observation_normalization': 'Only the run-specific output root.',
        'original_manifest': pin(W / 'session-vector-manifest.json'),
    })

    author = read(EXTRACTION / 'operation-token-report.json')
    reviewer = read(REVIEW / 'static-review.json')
    assert author['whole_body_tokens_equal_after_explicit_fact_projections'] and author['full_main_byte_exact_recovery']
    assert author['full_original_equation_control_effect_token_count'] == reviewer['original_tokens'] == 4135
    assert reviewer['author_mapping_or_token_script_used'] is False
    assert reviewer['all_operation_control_effect_tokens_equal_under_declared_fact_projections']
    assert reviewer['complete_main_recovered_identically'] and reviewer['call_input_and_output_projections_checked']
    assert reviewer['original_three_description_types_identical_normalized_text']
    for item in reviewer['candidate_pins']:
        exact(item)
    exact(reviewer['patch_pin'])
    dependencies = read(W / 'cold-dependency-proof.json')
    assert {row['unit'] for row in dependencies} == {'target', 'leaf'}
    for row in dependencies:
        assert row['no_Qwen_main_or_state_owner_or_runtime_paged_sequence_headers']
        assert row['repository_source_pin_count'] == {'target': 115, 'leaf': 44}[row['unit']]
        exact(row['receipt'])
    inventory = read(W / 'cmake-inventory-proof.json')
    assert inventory['status'] == 'THREE_COLD_SOURCES_AND_ORIGINAL_GUARDS_EXACT' and inventory['source_count'] == 3
    for item in [inventory['inventory'], *inventory['sources']]:
        exact(item)
    for row in inventory['unchanged_existing_guards']:
        assert row['byte_equal_baseline_commit']
        exact(row['source'])

    reference = read(REVIEW / 'llama-family-boundary-reference.json')
    assert reference['status'] == 'ACTUAL_LOCAL_HEAD_AND_SOURCE_BYTES_VERIFIED' and len(reference['files']) == 6
    reference_root = Path(reference['files'][0]['path']).parents[2]
    actual_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=reference_root, text=True).strip()
    assert actual_head == reference['actual_HEAD']
    reference_checks = []
    for item in reference['files']:
        exact(item)
        blob = subprocess.check_output(['git', 'show', actual_head + ':' + item['relative']], cwd=reference_root)
        assert hashlib.sha256(blob).hexdigest() == item['HEAD_blob_sha256']
        assert Path(item['path']).read_bytes().replace(b'\r\n', b'\n') == blob.replace(b'\r\n', b'\n')
        reference_checks.append({'relative': item['relative'], 'working_source_sha256': item['sha256'],
                                 'HEAD_blob_sha256': item['HEAD_blob_sha256'], 'source_equals_actual_HEAD_after_line_endings': True})
    save(W / 'collector-reference-readback.json', {'actual_HEAD': actual_head, 'files': reference_checks,
        'scope': 'Only these six current local source files and responsibility boundaries; no latest/global-clean/performance claim.'})

    snapshot_paths = {
        'engine/models/qwen35/main.cc', 'engine/models/qwen35/target_graph.h', 'engine/models/qwen35/target_graph.cc',
        'engine/models/qwen35/cold_sources.cmake', 'engine/models/qwen35/graph_builder.h', 'engine/models/qwen35/graph_builder.cc',
        'engine/models/qwen35/cache_plan.h', 'engine/models/qwen35/session_state.h', 'engine/models/qwen35/weights.h',
        'engine/models/qwen35/weights.cc', 'engine/models/qwen35/model_geometry.h', 'engine/models/qwen35/precision_profile.h',
        'engine/models/qwen35/execution_mode.h', 'engine/models/qwen35/block_graph.h', 'engine/models/qwen35/ffn_placement.h',
        'engine/models/qwen35/mtp_graph.h', 'engine/models/qwen35/mtp_session_probe.cc',
        'engine/models/qwen35/CMakeLists.txt', 'tests/CMakeLists.txt',
        'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_draft_vocabulary_probe.cc',
    }
    source_snapshots = []
    for relative in sorted(snapshot_paths):
        source = R / relative
        destination = W / 'source-current' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())
        assert pin(destination)['sha256'] == pin(source)['sha256']
        source_snapshots.append({'relative': relative, 'current': pin(source), 'snapshot': pin(destination)})
    save(W / 'source-snapshots.json', source_snapshots)
    # Original exact working-file snapshots and the original extraction patch
    # are retained below, avoiding a git-newline reconstruction as source proof.

    extensions = {'.py', '.json', '.jsonl', '.log', '.xml', '.txt', '.md', '.cc', '.h', '.cmake', '.patch', '.ids', '.tsv'}
    external = []
    for directory in (REVIEW, EXTRACTION):
        for source in sorted(directory.rglob('*')):
            if source.is_file() and source.suffix in extensions and '__pycache__' not in source.parts:
                target = W / 'external-evidence' / directory.name / source.relative_to(directory)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.read_bytes())
                external.append(pin(target))
    actual_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
    current_delta = subprocess.check_output(['git', 'diff', '--', 'engine/models/qwen35/main.cc',
        'engine/models/qwen35/cold_sources.cmake'], cwd=R)
    (W / 'source-tracked-delta.patch').write_bytes(current_delta)
    save(W / 'collector-source-state.json', {'HEAD_at_collection': actual_head,
        'base_commit': plan['base_commit'], 'frozen_candidate_exact': True,
        'complete_four_file_patch': pin(EXTRACTION / 'target-graph.patch'),
        'tracked_delta': pin(W / 'source-tracked-delta.patch'), 'product_writes_by_collector': False})
    summary = {
        'schema': 'hyle-inference-target-graph-boundary-v1', 'status': verification['status'],
        'base_commit': plan['base_commit'], 'HEAD_at_collection': actual_head, 'full_goal_complete': False,
        'implementation': {'changed_product_files': 4, 'original_target_body_lines': 204,
            'three_existing_description_types_moved_unchanged': True, 'original_equation_tokens': 4135,
            'only_same_recipe_cold_emit_and_borrowed_ports': True, 'Family_Phase_and_runtime_owners_not_moved': True,
            'original_preparation_compile_fallback_and_publish_order_preserved': True,
            'one_existing_cold_inventory_source_added': True, 'existing_module_backend_guards_unchanged': True},
        'compile': {'actual_CXX_processes': counts['compile'], 'new_target_CXX': 1, 'compile_only_leaf_CXX': 1,
            'affected_consumer_CXX': 3, 'changed_original228_inputs': 0, 'unchanged_original_inputs_reused': 228,
            'candidate_retained_inputs': 229, 'baseline_CXX': 0, 'NVCC': 0, 'downloads': 0,
            'scope': 'One target source TU compiled in this harness; normal CMake still compiles cold inventory per actual target.'},
        'attempts': actual_attempts, 'failure_attempt_names': failed, 'all_attempts_terminal': True,
        'tiny_hybrid_actual_failed_native_attempts': tiny_hybrid_rejections,
        'scratch_postprocess_exception': pin(parser_exception),
        'checks': verification, 'paired_non_timing_reports_independently_equal': paired,
        'native_count_scope': '8 default fullV CLI + 2 complete Session + 4 finite branches (historyCPU/packed/varlen/E4) + 2 rejected tiny CPU-FFN processes + 2 complete real2B CPU-FFN paired processes; actual attempts above include any retries. The scratch postprocess exception is not a native attempt.',
        'source_receipts': receipts, 'attempt_records': attempts,
        'candidate_model_link_base': pin(W / 'model-link-base.json'),
        'baseline_source_plan': pin(W / 'baseline-plan.json'), 'source_snapshots': pin(W / 'source-snapshots.json'),
        'baseline_source_readback': pin(W / 'collector-baseline-source-readback.json'),
        'all_receipt_source_pins_current_exact': True, 'dependency_proof': pin(W / 'cold-dependency-proof.json'),
        'cmake_inventory_proof': pin(W / 'cmake-inventory-proof.json'), 'author_static': pin(EXTRACTION / 'operation-token-report.json'),
        'independent_static': pin(REVIEW / 'static-review.json'), 'reference': pin(REVIEW / 'llama-family-boundary-reference.json'),
        'reference_readback': pin(W / 'collector-reference-readback.json'), 'hardware_toolchain': pin(W / 'hardware-toolchain.json'),
        'whole_cli_comparison': pin(W / 'whole-cli-summary.json'), 'branch_summary': pin(W / 'finite-branch-summary.json'),
        'cpu_ffn_pair': pin(W / 'compare-cpu-ffn-real-cuda.json'), 'session_comparison': pin(W / 'session-compare.json'),
        'session_vector_manifest': pin(W / 'session-vector-manifest.json'), 'independent_vector_recheck': pin(W / 'collector-vector-readback.json'),
        'external_evidence': external,
        'limits': [
            'Only this model-private target cold emit seam is verified. Full Family/Phase cold separation and cross-model integration remain future work.',
            'New header/source actual compiler closures exclude Qwen runtime owners; legitimate generic Graph/Compute/read-lease declarations remain.',
            'Manual exact CXX/link reused original228. Full normal default CMake build/install was not run; its existing module/backend guards are byte-identical.',
            'Current actual finite default fullV pairs, branches and Session checks establish this extraction only, not exhaustive feature completion or speed improvement.',
            'Both tiny BF16 hybrid arms actually fail cold region-port alias alignment/search before hybrid_plan; real2B paired validation does not mark the tiny configuration supported or fix this independent generic planner gap.',
            'Single finite timings diagnose obvious regressions only; no profiler, sustained performance window, GPU candidate or download.',
            'Local llama.cpp actual23b0202a six-file responsibility evidence does not require virtual dispatch, runtime graph rebuild, or a universal model layer in Hyle.',
            'No model payload, SDK/vendor copy, binary/object/debug artifact, or raw vector bytes is retained in the archive.',
        ],
    }
    save(W / 'summary-draft.json', summary)
    files = set()
    for path in W.iterdir():
        if path.is_file() and path.suffix in extensions and path.name not in ('archive-draft.json', 'retention-manifest.json'):
            files.add(path)
    for directory in ('compile', 'link', 'runs', 'baseline-source', 'source-current', 'external-evidence', 'session-input'):
        for path in (W / directory).rglob('*'):
            if path.is_file() and path.suffix in extensions and '__pycache__' not in path.parts:
                files.add(path)
    # No generated vector payload suffixes or binaries can enter this whitelist.
    prohibited = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.f32', '.bf16', '.f16', '.safetensors', '.gguf'}
    assert not any(path.suffix.lower() in prohibited for path in files)
    members = [{'member': path.relative_to(W).as_posix(), 'bytes': path.stat().st_size,
                'sha256': pin(path)['sha256']} for path in sorted(files)]
    save(W / 'retention-manifest.json', {'members': members,
        'excluded': 'Model weights; SDK/vendor copies; EXE/OBJ/PDB/DLL/LIB/EXP; raw binary vector payloads. Full source/hash/HEAD/commands/deps/reports and complete-vector hashes/comparisons retained.'})
    files.add(W / 'retention-manifest.json')
    archive = W / 'evidence-draft.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as zipped:
        for path in sorted(files):
            zipped.write(path, path.relative_to(W).as_posix())
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None and len(zipped.namelist()) == len(files)
        for item in members:
            body = zipped.read(item['member'])
            assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
        retained_manifest = json.loads(zipped.read('retention-manifest.json'))
        assert retained_manifest['members'] == members
    archive_record = {'archive': pin(archive), 'members': len(files), 'all_members_readback_bytes_sha256_verified': True,
        'summary': pin(W / 'summary-draft.json'), 'model_link_base': pin(W / 'model-link-base.json'),
        'retention_manifest': pin(W / 'retention-manifest.json'), 'session_vector_manifest': pin(W / 'session-vector-manifest.json'),
        'independent_vector_recheck': pin(W / 'collector-vector-readback.json'), 'no_cleanup_performed': True,
        'no_product_or_docs_or_test_ps1_write': True}
    save(W / 'archive-draft.json', archive_record)
    print(json.dumps({'status': summary['status'], 'CXX': counts['compile'], 'links': counts['link'], 'native': counts['runs'],
        'failures': len(failed), 'archive_bytes': archive_record['archive']['bytes'], 'members': len(files),
        'archive_sha256': archive_record['archive']['sha256'], 'vector_files_per_arm': manifest['file_count_per_arm']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ready', required=True, choices=['bridge-terminal-ready'])
    collect(parser.parse_args().ready)
