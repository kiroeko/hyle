"""Read-only actual host/toolchain inventory; no model/GPU execution."""
from pathlib import Path
import datetime,hashlib,importlib.util,json,platform,subprocess
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cache_inventory_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin=b.read,b.save,b.pin
p=read(W/'plan.json');base=read(p['base']['path']);compiler=p['consumers']['cli']['compile'][0];linker=p['original_link'][0]
commands=[]
def run(args):
 result=subprocess.run(args,capture_output=True,text=True,encoding='utf-8',errors='replace')
 commands.append(dict(command=args,exit=result.returncode,stdout=result.stdout,stderr=result.stderr))
 assert result.returncode==0,(args,result.returncode,result.stderr)
 return result.stdout.strip()
gpu=run(['nvidia-smi','--query-gpu=name,uuid,driver_version,memory.total,pstate,clocks.current.sm,temperature.gpu','--format=csv,noheader'])
ps="$ErrorActionPreference='Stop'; $p=Get-CimInstance Win32_Processor | Select-Object -First 1; $c=Get-Item -LiteralPath '"+compiler+"'; $l=Get-Item -LiteralPath '"+linker+"'; [pscustomobject]@{OS=[Environment]::OSVersion.VersionString; CPU=$p.Name; CXX_FileVersion=$c.VersionInfo.FileVersion; CXX_ProductVersion=$c.VersionInfo.ProductVersion; Linker_FileVersion=$l.VersionInfo.FileVersion} | ConvertTo-Json -Compress"
host=json.loads(run(['powershell','-NoProfile','-NonInteractive','-Command',ps]))
cuda=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/version.json')
save(W/'hardware-toolchain.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),hostname=platform.node(),
 actual_host=host,actual_gpu_csv=gpu,columns=['name','uuid','driver_version','memory.total','pstate','clocks.current.sm','temperature.gpu'],
 compiler=pin(compiler),linker=pin(linker),compiler_path_equal_cached_base=compiler==base['compile'][0],
 CUDA_version_metadata=read(cuda) if cuda.exists() else None,
 commands=commands,scope='Read-only post-run current-machine inventory; clocks/temperature are point samples, no controls changed. CXX and link executables are actual command tools and path-equal cached base; no NVCC was invoked.'))
print(json.dumps(dict(host=platform.node(),GPU=gpu,CXX=host['CXX_FileVersion'],compiler_path_equal_cached_base=compiler==base['compile'][0]),ensure_ascii=False))
