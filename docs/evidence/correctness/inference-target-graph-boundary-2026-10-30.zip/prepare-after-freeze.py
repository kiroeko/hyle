"""Future metadata preparation only; no compiler, linker or model execution.

Invoke only after root commit and implementation freeze. The freeze JSON must
contain `sources: [{path, bytes, sha256}, ...]` for current changed product files.
This file is intentionally not executed during the planning turn.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-cold-cache-facts-20261030/model-link-base.json'
spec=importlib.util.spec_from_file_location('target_prior_cache_build',BASE.parent/'build.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
c.W=W;c.BASE=BASE;c.b.W=W;c.b.BASE=BASE;c.b.s.W=c.b.s.b.W=W
read,save,pin,exact,key=c.read,c.save,c.pin,c.exact,c.key
def prepare(commit,freeze_path):
 assert not (W/'plan.json').exists()
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 assert head==commit,'Root baseline commit must be current HEAD; do not use fdae before cachefacts commit.'
 frozen=read(freeze_path);assert frozen['sources']
 frozen_paths=set()
 for item in frozen['sources']:
  exact(item);frozen_paths.add(key(item['path']))
 target=R/'engine/models/qwen35/target_graph.cc'
 assert target.is_file() and key(target) in frozen_paths
 changed_names=subprocess.check_output(['git','diff','--name-only','--','include','src','engine','tests'],cwd=R,text=True).splitlines()
 changed_names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','include','src','engine','tests'],cwd=R,text=True).splitlines()
 changed={key(R/name) for name in changed_names}
 assert changed<=frozen_paths,('Changed product paths omitted from freeze',sorted(changed-frozen_paths))
 base=read(BASE);assert len(base['retained'])==228
 # This verifies old cached source identities against exact current files or
 # committed baseline snapshots, never silently repins candidate source bytes.
 if not (W/'baseline-plan.json').exists():c.baseline()
 baseline=read(W/'baseline-plan.json');assert baseline['base_commit']==commit
 tiny=read(base['current_consumers']['tiny']['receipt']['path']);proofs=[]
 for item in [tiny['object'],*base['retained']]:exact(item)
 for item in tiny['source_identities']:
  path=Path(item['path'])
  if path.is_file() and pin(path)==item:proofs.append(dict(identity=item,proof='CURRENT_EXACT'))
  else:
   relative=path.relative_to(R);data=subprocess.check_output(['git','show',commit+':'+relative.as_posix()],cwd=R)
   assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],relative
   snapshot=W/'baseline-source'/relative;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(data)
   proofs.append(dict(identity=item,proof='EXACT_COMMITTED_BASELINE_SNAPSHOT',snapshot=pin(snapshot)))
 if not (W/'baseline-tiny-plan.json').exists():
  save(W/'baseline-tiny-plan.json',dict(receipt=base['current_consumers']['tiny']['receipt'],object=tiny['object'],
   source_proofs=proofs,original_closure_inputs=228,compile=0,
   note='Baseline tiny --engine needs this cached tiny object in place of CLI, not baseline CLI with an unrecognized --engine flag.'))
 else:assert read(W/'baseline-tiny-plan.json')['object']==tiny['object']
 sdk=read(base['sdk_engine_dependencies']['path'])
 rows={key(row['object']):row for row in sdk['inspected']}
 rows.update({key(row['object']):row for row in sdk['engine_consumers'] if 'dependencies' in row})
 units={};available=[];unavailable=[]
 for item in base['retained']:
  exact(item);obj=Path(item['path']);row=rows.get(key(obj))
  for adjacent in (obj.parent/'dependencies.json',obj.with_name(obj.stem+'-deps.json'),obj.with_suffix('.deps.json')):
   if adjacent.is_file() and 'Data' in read(adjacent):row=dict(object=str(obj),dependencies=pin(adjacent));break
  if row is None:unavailable.append(str(obj));continue
  available.append(row);deps=read(row['dependencies']['path'])['Data']
  if not any(key(path) in changed for path in [deps['Source'],*deps['Includes']]):continue
  command,recipe=c.b.s.command_for(obj,deps['Source'])
  name='cold' if Path(deps['Source']).name=='graph_builder.cc' else 'sdk-'+Path(deps['Source']).stem
  assert name not in units
  units[name]=dict(source=deps['Source'],original=item,recipe=recipe,old_dependencies=row['dependencies'],
   compile=c.b.s.relocated(command,name))
 wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
 sources=dict(cli=wrapper,tiny=R/'tests/tools/qwen_host_image_test.cc',session=R/'engine/models/qwen35/mtp_session_probe.cc',
  rows=R/'tests/tools/qwen_draft_vocabulary_probe.cc')
 consumers={};reuse={};consumer_scan=[]
 for name,source in sources.items():
  old=base['current_consumers'][name];receipt=read(old['receipt']['path'])
  mismatch=[item for item in receipt['source_identities'] if not Path(item['path']).is_file() or pin(item['path'])!=item]
  consumer_scan.append(dict(name=name,source_pin_count=len(receipt['source_identities']),mismatches=mismatch))
  if mismatch:consumers[name]=dict(source=str(source),compile=c.b.s.relocated(base['compile'],name,source))
  else:reuse[name]=old
 assert {'cli','tiny','session'}<=consumers.keys(),'Expected changed main consumers must actually be recompiled.'
 spec=importlib.util.spec_from_file_location('target_proposed_cases',W/'planned-cases.py')
 cases=importlib.util.module_from_spec(spec);spec.loader.exec_module(cases)
 save(W/'extra-cases.json',cases.proposed_cases())
 save(W/'plan.json',dict(base=pin(BASE),base_commit=commit,source_freeze=pin(freeze_path),retained=base['retained'],
  runtime=base['runtime'],sdk=base['sdk_engine_dependencies'],original_link=base['link'],original_consumer=baseline['cli_object']['path'],
  actual_dependency_rows=available,unavailable_dependencies=unavailable,units=units,
  engine_units=dict(target=dict(source=str(target),compile=c.b.s.relocated(base['compile'],'target',target))),
  consumers=consumers,reused_consumers=reuse,consumer_scan=consumer_scan,cases=baseline['cases'],
  expected_retained_after_replacements_and_one_append=229,new_model_cold_CXX=1,
  SDK_CXX=sum(name!='cold' for name in units),existing_model_cold_CXX=int('cold' in units),
  max_compilers=2,NVCC=0,downloads=0,
  link_rule='Start from original228: replace actual impacted old object paths once, swap consumer once, append only new target object once. Existing graph_builder is already in228; never append it again.',
  status='METADATA_PREPARED_NOT_COMPILED_OR_RUN'))
 print('Prepared future exact baseline/candidate metadata only; no CXX, link or native. Candidate closure229.')
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--baseline-commit',required=True)
 parser.add_argument('--source-freeze',required=True,type=Path)
 args=parser.parse_args();prepare(args.baseline_commit,args.source_freeze.resolve())
