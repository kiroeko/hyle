"""Seal229: reuse original228 exactly and append only new target cold object."""
from pathlib import Path
import copy,importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('target_base_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
p=read(W/'plan.json');base=read(p['base']['path'])
assert not p['units'] and len(p['retained'])==228
receipts={name:read(W/'compile'/name/'receipt.json') for name in ['target','leaf','cli','tiny','session']}
for receipt in receipts.values():
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
retained=p['retained']+[receipts['target']['object']]
assert len(retained)==229 and len({key(item['path']) for item in retained})==229
for item in retained:exact(item)
sdk=copy.deepcopy(read(p['sdk']['path']))
sdk['inspected'].append(dict(object=receipts['target']['object']['path'],dependencies=receipts['target']['dependencies']))
sdk['engine_consumers'].append(dict(object=receipts['target']['object']['path'],dependencies=receipts['target']['dependencies'],
 receipt=pin(W/'compile/target/receipt.json'),source_identities=receipts['target']['source_identities'],
 engine_dependencies=[item['path'] for item in receipts['target']['source_identities'] if Path(item['path']).is_relative_to(R/'engine')]))
sdk['scope']='Current229 closure: original228 retained byte-exact, only target_graph model cold object appended. Actual target dependency proof excludes Qwen main/session_state/runtime paged_sequence. Original69 unavailable native/library metadata rows remain explicit.'
save(W/'sdk-engine-dependencies.json',sdk)
current={};previous={};audit=[]
for name,row in base['current_consumers'].items():
 exact(row['receipt']);exact(row['object']);receipt=read(row['receipt']['path'])
 mismatch=[item for item in receipt['source_identities'] if not Path(item['path']).is_file() or pin(item['path'])!=item]
 if mismatch or name in ('cli','tiny','session'):
  previous[name]=dict(**row,status='HISTORICAL_NOT_CURRENT',reason='Source dependency mismatch or replaced consumer',mismatched_source_pins=mismatch)
  audit.append(dict(name=name,status='HISTORICAL',mismatched_source_pin_count=len(mismatch)))
 else:
  current[name]=row;audit.append(dict(name=name,status='CURRENT_EXACT',source_pin_count=len(receipt['source_identities'])))
historical=copy.deepcopy(base['historical_consumers']);historical['before-target-graph-e41c31cd8']=previous
for name in ('cli','tiny','session'):current[name]=dict(receipt=pin(W/'compile'/name/'receipt.json'),object=receipts[name]['object'])
args=[];count=0
for arg in p['original_link']:
 if key(arg)==key(p['original_consumer']):arg=receipts['cli']['object']['path'];count+=1
 for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
  if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/cli').with_suffix(suffix));break
 args.append(arg)
assert count==1;args.append(receipts['target']['object']['path'])
for old in base['model_cold_objects']:assert sum(key(arg)==key(old['object']['path']) for arg in args)==1
assert sum(key(arg)==key(receipts['target']['object']['path']) for arg in args)==1
save(W/'current-consumer-source-audit.json',audit)
save(W/'model-link-base.json',dict(schema='hyle.current-model-link-base.v1',base=p['base'],compile=p['consumers']['cli']['compile'],
 link=args,consumer_source=str(W/'cli.cc'),previous_consumer=p['original_consumer'],retained=retained,runtime=p['runtime'],
 sdk_engine_dependencies=pin(W/'sdk-engine-dependencies.json'),current_consumers=current,historical_consumers=historical,
 retained_categories=dict(cached_SDK_and_engine_inputs=227,existing_model_cold_object=1,new_target_model_cold_object=1,total_retained=229),
 model_cold_objects=base['model_cold_objects']+[dict(source=str(R/'engine/models/qwen35/target_graph.cc'),
  receipt=pin(W/'compile/target/receipt.json'),object=receipts['target']['object'])],
 current_compile_only=dict(leaf=dict(receipt=pin(W/'compile/leaf/receipt.json'),object=receipts['leaf']['object'])),
 note='Target graph extraction: original228 byte-exact cache plus one new model-local target builder. Weights/graph_builder/rows/math were not recompiled. Old main consumers are historical; current CLI/tiny/Session use matching current target header and target object.'))
print(json.dumps(dict(status='SEALED_CURRENT229',retained=229,reused=228,new_model_cold=1,
 current_consumers=list(current),inspected=len(sdk['inspected']),unavailable=len(sdk['unavailable'])),ensure_ascii=False))
