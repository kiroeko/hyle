"""Verify this scratch extraction against saved and live exact-source pins.

No compiler, backend, download or product mutation is invoked. New declarations
and caller projections are checked separately from the full original equations.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MODEL = "engine/models/qwen35/"
plan = json.loads((HERE / "plan.json").read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()


def read(path):
    return path.read_bytes().decode().replace("\r\n", "\n")


# A token retains every identifier/operator/numeric spelling and every quoted
# byte, while disregarding only comments and whitespace (including line ends).
lexer = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|R"([^ ()\\\t\r\n]{0,16})\([\s\S]*?\)\1"|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|(?:\d[\w.\']*|\.\d[\w.\']*)|::|->|<<|>>|<=|>=|==|!=|&&|\|\||\+\+|--|\+=|-=|\*=|/=|\S')


def tokens(text):
    return [m.group(0) for m in lexer.finditer(text)
            if not m.group(0).startswith(("//", "/*"))]


pin_results = []
for entry in plan["preconditions"]:
    data = (ROOT / entry["path"]).read_bytes()
    ok = len(data) == entry["bytes"] and sha(data) == entry["sha256"]
    pin_results.append({"path": entry["path"], "match": ok})
assert all(e["match"] for e in pin_results), "a live baseline precondition changed"
assert all(not (ROOT / p).exists() for p in plan["must_be_absent"])
for entry in plan["candidate"]:
    data = (HERE / "candidate" / entry["path"]).read_bytes()
    assert len(data) == entry["bytes"] and sha(data) == entry["sha256"], entry["path"]
assert sha((HERE / "target-graph.patch").read_bytes()) == plan["patch_sha256"]

original = read(HERE / "original-target-body.txt")
source = read(HERE / "candidate" / MODEL / "target_graph.cc")
header = read(HERE / "candidate" / MODEL / "target_graph.h")
new_main = read(HERE / "candidate" / MODEL / "main.cc")
base_main = read(HERE / "base" / MODEL / "main.cc")
body_begin = source.index('  auto x = r.embedding(target_tokens, "model.language_model.embed_tokens.weight");\n')
body_end = source.index("  return {x, prior_append, has_prior_append};\n", body_begin)
new_body = source[body_begin:body_end]
restored = new_body
mappings = json.loads((HERE / "operation-mappings.json").read_text())
for mapping in reversed(mappings):
    assert restored.count(mapping["new"]) == mapping["occurrences"], mapping
    restored = restored.replace(mapping["new"], mapping["old"])
new_prior = """  g::NodeId prior_append = inputs.preceding_append;
  bool has_prior_append = inputs.has_preceding_append;
"""
old_prior = """  // Writer-only draft maintenance has no attention data edge into target.
  // Order its real cache effects before target's first append as well.
  g::NodeId prior_append = has_mtp(role) && !is_mtp_prefill(role)
      ? definition.append_nodes[draft_bank + 1] : g::NodeId{};
  bool has_prior_append = has_mtp(role) && !is_mtp_prefill(role);
"""
assert restored.count(new_prior) == 1
restored = restored.replace(new_prior, old_prior)
assert tokens(original) == tokens(restored), "equation/control/effect tokens changed beyond the declared substitutions"

schema = "struct StateSchema final {\n  c::TensorDesc history, recurrent;\n};\n"
ports = "struct StatePorts final {\n  V pool, source_ids, destination_ids;\n  g::NodeId gather, store;\n};\nstruct Ports final {\n  V key, value;\n  StatePorts history, recurrent;\n};\n"
assert header.count(schema) == header.count(ports) == 1
assert schema + ports == read(HERE / "original-moved-types.txt")

# Recover the complete original main byte for byte after reversing only the
# intended new include, moved types and one replacement call site.
call_begin = new_main.index("    // Writer-only draft maintenance has no attention data edge into target.\n")
call_end = new_main.index("    if (diagnostic) for (std::size_t i = 0; i < definition.probe_ports.size(); ++i) {\n", call_begin)
call = new_main[call_begin:call_end]
recovered_main = new_main[:call_begin] + original + new_main[call_end:]
recovered_main = recovered_main.replace('#include "target_graph.h"\n', "", 1)
recovered_main = recovered_main.replace("std::vector<StateSchema> state_schema_for", schema + "std::vector<StateSchema> state_schema_for", 1)
recovered_main = recovered_main.replace("struct FamilyPorts {\n", ports + "struct FamilyPorts {\n", 1)
assert recovered_main == base_main

required_call_facts = [
    ".token_ids = target_tokens", ".positions = definition.position_port",
    ".attention_metadata = definition.metadata_port", ".frequencies = frequencies",
    ".sequence_offsets = definition.sequence_offsets_port", ".history_select = definition.history_select_port",
    ".requests = requests", ".prefix_rows = prefix_rows", ".packing = packing",
    ".state_slots = cache_plan.state_slots", ".recurrent_descriptions = state_schema",
    ".plain_attention_schema = attention_schema", ".target_attention_schemas = attention_schemas",
    ".cpu_ffn_layers = ffn_placement.cpu_layers()",
    ".preceding_append = has_mtp(role) && !is_mtp_prefill(role)\n            ? definition.append_nodes[draft_bank + 1] : g::NodeId{}",
    ".has_preceding_append = has_mtp(role) && !is_mtp_prefill(role)",
    "std::span<g::NodeId>(definition.append_nodes).first(draft_bank)",
    "std::span<V>(definition.append_cache_inputs).first(draft_bank)",
    "definition.state_sources, definition.probe_ports",
    "auto x = target.hidden_rows;", "auto prior_append = target.last_append;", "bool has_prior_append = target.has_append;",
]
assert all(fact in call for fact in required_call_facts)
assert "std::uint32_t state_slots;" in header
assert "struct Family" not in header and "struct Phase" not in header

base_cmake = read(HERE / "base" / MODEL / "cold_sources.cmake")
new_cmake = read(HERE / "candidate" / MODEL / "cold_sources.cmake")
assert new_cmake.replace('  "${CMAKE_CURRENT_LIST_DIR}/graph_builder.cc"\n  "${CMAKE_CURRENT_LIST_DIR}/target_graph.cc")\n',
                         '  "${CMAKE_CURRENT_LIST_DIR}/graph_builder.cc")\n') == base_cmake

check = subprocess.run(["git", "apply", "--check", str(HERE / "target-graph.patch")],
    cwd=ROOT, capture_output=True, text=True)
assert check.returncode == 0, check.stderr

# Quoted repository include closure, with candidate files as an overlay. This
# is static evidence only, not compiler-derived includes or ABI validation.
visited = set()
missing = []


def visit(relative):
    if relative in visited:
        return
    visited.add(relative)
    overlay = HERE / "candidate" / relative
    path = overlay if overlay.exists() else ROOT / relative
    contents = read(path)
    for include in re.findall(r'^\s*#\s*include\s+"([^"]+)"', contents, re.M):
        trials = [(ROOT / relative).parent / include, ROOT / "include" / include]
        resolved = next((p.resolve() for p in trials if p.exists() or
            (HERE / "candidate" / str(p.relative_to(ROOT))).exists()), None)
        if resolved is None:
            missing.append({"from": relative, "include": include})
            continue
        child = str(resolved.relative_to(ROOT)).replace("\\", "/")
        visit(child)


closures = {}
for path in [MODEL + "target_graph.h", MODEL + "target_graph.cc"]:
    visited = set()
    missing = []
    visit(path)
    forbidden = [p for p in visited if p in [MODEL + "main.cc", MODEL + "session_state.h", MODEL + "host_image.h",
        MODEL + "session_schedule.h", MODEL + "prefix_cache.h"] or p.endswith("/paged_sequence.h")]
    assert not forbidden, forbidden
    closures[path] = {"quoted_repository_headers": sorted(visited), "count": len(visited),
                      "forbidden_runtime_headers": forbidden, "unresolved_quoted_includes": missing}

operations = re.findall(r'\br\.(\w+)\s*\(', original)
counts = {name: operations.count(name) for name in sorted(set(operations))}
report = {
    "status": "STATIC_PASS_UNAPPLIED_UNBUILT",
    "baseline_live_pins": pin_results,
    "candidate_pins_match": True,
    "full_original_equation_control_effect_token_count": len(tokens(original)),
    "whole_body_tokens_equal_after_explicit_fact_projections": True,
    "original_three_type_bytes_equal_after_line_ending_normalization": True,
    "full_main_byte_exact_recovery": True,
    "original_prior_append_predicate_and_node_preserved_at_call_site": True,
    "original_recipe_graph_literal_profile_owner_reused": True,
    "original_prepare_draft_finish_compile_publish_order_unchanged": True,
    "target_append_spans_exclude_draft_slots": True,
    "state_slot_type": "uint32_t, unchanged from actual cache::Plan and slots::Schema parameter",
    "schema_selection": "same empty-overrides ? original plain : original layer override; exact source-derived capacity guards before first emit",
    "new_guard_scope": "Only description/port span counts; no request/runtime/admission/fallback policy",
    "operation_call_inventory": counts,
    "explicit_projections": mappings,
    "static_include_closures": closures,
    "git_apply_check": {"returncode": check.returncode, "stdout": check.stdout, "stderr": check.stderr},
    "limits": "No product application, CXX/ABI validation, compiler-derived dependency proof, native/GPU or performance measurement. Static call counts are not native dispatches.",
}
report_path = HERE / "operation-token-report.json"
report_path.write_text(json.dumps(report, indent=2) + "\n", newline="\n")
print(json.dumps({"status": report["status"], "equation_tokens": len(tokens(original)),
    "new_header_closure": closures[MODEL + "target_graph.h"]["count"],
    "new_cc_closure": closures[MODEL + "target_graph.cc"]["count"],
    "git_apply_check": check.returncode}, indent=2))
