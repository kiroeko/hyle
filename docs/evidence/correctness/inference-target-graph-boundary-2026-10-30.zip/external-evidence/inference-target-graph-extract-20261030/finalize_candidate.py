"""Finalize the scratch draft's exact state-slot count type; no product writes."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
plan_path = HERE / "plan.json"
plan = json.loads(plan_path.read_text())
header_path = HERE / "candidate/engine/models/qwen35/target_graph.h"
header = header_path.read_bytes()
assert header.count(b"  std::size_t state_slots;\r\n") == 1
header = header.replace(b"#include <cstddef>\r\n", b"#include <cstddef>\r\n#include <cstdint>\r\n", 1)
header = header.replace(b"  std::size_t state_slots;\r\n", b"  std::uint32_t state_slots;\r\n", 1)
header_path.write_bytes(header)

patch = ""
for entry in plan["candidate"]:
    path = entry["path"]
    data = (HERE / "candidate" / path).read_bytes()
    base_path = HERE / "base" / path
    previous = base_path.read_bytes() if base_path.exists() else b""
    patch += f"diff --git a/{path} b/{path}\n"
    if not base_path.exists():
        patch += "new file mode 100644\n"
    patch += "".join(difflib.unified_diff(previous.decode().splitlines(keepends=True),
        data.decode().splitlines(keepends=True), fromfile="a/" + path if base_path.exists() else "/dev/null",
        tofile="b/" + path))
    entry.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                 crlf=data.count(b"\r\n"), lf=data.count(b"\n"))
(HERE / "target-graph.patch").write_bytes(patch.encode())
plan["patch_sha256"] = hashlib.sha256(patch.encode()).hexdigest()
plan["draft_corrections"] = [
    "State slot count retains actual cache::Plan / slots::Schema uint32_t, rather than the design sketch's size_t.",
    "Original frequencies ValueId is an explicit borrowed input; no literal creation moves.",
]
plan_path.write_text(json.dumps(plan, indent=2) + "\n", newline="\n")
print("Finalized scratch-only candidate; no product files touched.")
