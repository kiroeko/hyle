# Qwen target 主干冷 emit 候选

状态：**仅 scratch；未应用、未编译、未运行 GPU**。完整基线是
`e41c31cd83603b951d074f5b2fc0ac0cf8e038ce`。准备开始时 cachefacts 尚未提交，
随后已核全部 39 个输入文件哈希与该提交一致；`plan.json` 同时保留两次 HEAD 事实。

`candidate/` 保存四个完整文件；`target-graph.patch` 是可独立应用的完整差异。
产品工作树保持未改。`plan.json` 记录所有输入/输出与 patch 的 SHA256、新文件不存在前置、
原主干 1880–2083 行范围。运行 `python operation-token-check.py` 会重新核对这些前置，
只读执行 `git apply --check`，并写静态报告；不会应用补丁或启动构建。

改动仅为：移出三个原描述类型，新增 `target_graph.h/.cc` 同步冷函数，main 原位置调用，
唯一 `cold_sources.cmake` 增加一个源文件。`FamilyPorts`、`Family`、`Phase`、资源准备、
Graph finish/compile、有限族和发布全部留在原 main。函数借同一 Recipe、GraphAssembly、
geometry 和 activation profile；RoPE 只借原 frequencies ValueId。端口 span 只覆盖 target
的前 `2 * attention_layers` 个 append 槽，draft 槽与真实前驱 node 仍在 caller 控制。

操作保持证据：`operation-token-check.py` 对原主干 4135 个 C++ token（去注释/空白）
逐项比较；仅反向恢复 `operation-mappings.json` 中的描述/端口字段投影、原前驱传参。
三描述类型规范化行尾后字节全等；将调用替回并恢复类型/include 后，完整原 main 字节全等。
原顺序、文字/数字、Copy/cast、packed prefixes、state Store、E4M3 编码、依赖和 FFN
Scope 全部包含在这一完整比较内，不能以静态调用数代签 native dispatch 或性能。

新函数只额外检查 cold span/描述数量与真实 geometry 一致，检查在首个 emit 前。
attention schema 保持空 overrides 选 plain、否则选原 layer override；state_slots 使用
实际 Plan/Schema 的 `uint32_t`。CPU FFN 保持 `layer < cpu_layers()` 原语义。
所有输入借用仅到同步函数返回，不保存 Model/Session/State/Snapshot 或新资源 owner。

现 main 和 cold inventory 实际都是 LF，候选保留；新头/源按本片要求采用 CRLF。
静态仓库 include 闭包：新头 43 文件、cc 115 文件，无 main、Qwen session_state/host_image/
session_schedule/prefix_cache 或 paged_sequence。此结论还不是实际编译依赖或 ABI 证明。

准备脚本分为 `prepare.py`（原稿）与 `finalize_candidate.py`（把设计草图的 size_t
纠正为原 uint32_t，并更新完整 patch/hash）。两者都只写本目录；准备拒绝覆盖已存在 plan。
当前最终文件已冻结，root 审阅后决定是否应用和有限验证。
