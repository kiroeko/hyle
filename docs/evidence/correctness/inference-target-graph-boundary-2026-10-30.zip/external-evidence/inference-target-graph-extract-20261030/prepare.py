"""Prepare a pinned, scratch-only Qwen target graph extraction candidate.

This script never writes product files and refuses to replace an existing plan.
"""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MODEL = "engine/models/qwen35/"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(relative, data):
    path = HERE / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise RuntimeError(f"refusing to replace {path}")
    path.write_bytes(data)


if (HERE / "plan.json").exists():
    raise RuntimeError("this immutable candidate was already prepared")

main_path = MODEL + "main.cc"
cmake_path = MODEL + "cold_sources.cmake"
main_bytes = (ROOT / main_path).read_bytes()
cmake_bytes = (ROOT / cmake_path).read_bytes()
assert b"\r" not in main_bytes and b"\r" not in cmake_bytes
main = main_bytes.decode()
cmake = cmake_bytes.decode()
schema = "struct StateSchema final {\n  c::TensorDesc history, recurrent;\n};\n"
ports = "struct StatePorts final {\n  V pool, source_ids, destination_ids;\n  g::NodeId gather, store;\n};\nstruct Ports final {\n  V key, value;\n  StatePorts history, recurrent;\n};\n"
assert main.count(schema) == main.count(ports) == 1
start_marker = '    auto x = r.embedding(target_tokens, "model.language_model.embed_tokens.weight");\n'
end_marker = '    if (diagnostic) for (std::size_t i = 0; i < definition.probe_ports.size(); ++i) {\n'
start = main.index(start_marker)
end = main.index(end_marker, start)
old_body = main[start:end]
assert len(old_body.splitlines()) == 204

old_prior = """    // Writer-only draft maintenance has no attention data edge into target.
    // Order its real cache effects before target's first append as well.
    g::NodeId prior_append = has_mtp(role) && !is_mtp_prefill(role)
        ? definition.append_nodes[draft_bank + 1] : g::NodeId{};
    bool has_prior_append = has_mtp(role) && !is_mtp_prefill(role);
"""
assert old_body.count(old_prior) == 1
new_prior = """    g::NodeId prior_append = inputs.preceding_append;
    bool has_prior_append = inputs.has_preceding_append;
"""
body = old_body.replace(old_prior, new_prior)
replacements = [
    ("definition.layers", "outputs.layers"),
    ("definition.append_cache_inputs", "outputs.append_cache_inputs"),
    ("definition.append_nodes", "outputs.append_nodes"),
    ("definition.attention_nodes", "outputs.attention_nodes"),
    ("definition.state_sources", "outputs.state_sources"),
    ("definition.probe_ports", "outputs.layer0_probes"),
    ("definition.history_select_port", "inputs.history_select"),
    ("definition.sequence_offsets_port", "inputs.sequence_offsets"),
    ("definition.position_port", "inputs.positions"),
    ("definition.metadata_port", "inputs.attention_metadata"),
    ("cache_plan.state_slots", "inputs.state_slots"),
    ("precision.activation_type()", "r.activation_type()"),
    ("ffn_placement.ffn_on_cpu(i)", "i < inputs.cpu_ffn_layers"),
    ("target_attention_schema(layer)",
     "inputs.target_attention_schemas.empty() ? inputs.plain_attention_schema : inputs.target_attention_schemas[layer]"),
]
counts = []
for old, new in replacements:
    count = body.count(old)
    assert count, old
    body = body.replace(old, new)
    counts.append({"old": old, "new": new, "occurrences": count})
assert "definition." not in body
assert "precision." not in body
assert "cache_plan." not in body
assert "ffn_placement." not in body
body = "\n".join(line[2:] if line.startswith("  ") else line for line in body.splitlines()) + "\n"

header = """#pragma once

// Qwen-private cold target equations. All values and descriptions borrow the
// caller's original graph and storage facts; no runtime state owner is retained.
#include <cstddef>
#include <span>
#include <vector>

#include "execution_mode.h"
#include "hyle/compute/batch_layout.h"
#include "hyle/compute/tensor_desc.h"
#include "hyle/graph/graph.h"
#include "hyle/graph/slots.h"

namespace qwen35 {
namespace c = hyle::compute;
namespace g = hyle::graph;
using V = g::ValueId;

""" + schema + ports + """
struct Recipe;

struct TargetGraphInputs final {
  V token_ids, positions, attention_metadata, frequencies;
  V sequence_offsets, history_select; // Read only by packed target equations.
  std::size_t requests, prefix_rows;
  RowPacking packing;
  std::size_t state_slots;
  std::span<const StateSchema> recurrent_descriptions;
  const c::BatchSchema &plain_attention_schema;
  std::span<const c::BatchSchema> target_attention_schemas;
  std::size_t cpu_ffn_layers;
  g::NodeId preceding_append;
  bool has_preceding_append;
};
struct TargetGraphPorts final {
  std::span<Ports> layers;
  std::span<g::NodeId> attention_nodes;
  std::span<g::NodeId> append_nodes; // Only the target's original 2*N slots.
  std::span<V> append_cache_inputs;
  std::vector<g::slots::SourceBinding> &state_sources;
  std::span<V, 9> layer0_probes;
};
struct TargetGraphResult final {
  V hidden_rows;
  g::NodeId last_append;
  bool has_append;
};
TargetGraphResult emit_target_graph(Recipe &recipe,
    const TargetGraphInputs &inputs, TargetGraphPorts outputs);

} // namespace qwen35
"""

prologue = """// Cold Qwen target embedding, recurrent/attention blocks and FFN equations.
// Preparation, compilation, state ownership and publication stay with the caller.
#include "target_graph.h"

#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "graph_builder.h"
#include "block_graph.h"
#include "cache_plan.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/sequence_ops.h"
#include "hyle/graph/batch.h"

namespace qwen35 {
TargetGraphResult emit_target_graph(Recipe &r,
    const TargetGraphInputs &inputs, TargetGraphPorts outputs) {
  const auto &geometry = r.geometry;
  auto &assembly = r.assembly;
  const auto t = r.token_rows, packed = r.packed_rows;
  const auto requests = inputs.requests, prefix_rows = inputs.prefix_rows;
  const auto batch = f(static_cast<std::int64_t>(requests));
  const auto state_schema = inputs.recurrent_descriptions;
  const bool packed_verify = packs_verify(inputs.packing), packed_target = packs_target(inputs.packing);
  const auto frequencies = inputs.frequencies;
  const auto target_tokens = inputs.token_ids;
  const auto attention_layers = geometry.attention_layers();
  if (state_schema.size() != geometry.layers.size() || outputs.layers.size() != state_schema.size() ||
      outputs.attention_nodes.size() != attention_layers || outputs.append_nodes.size() != 2 * attention_layers ||
      outputs.append_cache_inputs.size() != 2 * attention_layers ||
      (!inputs.target_attention_schemas.empty() && inputs.target_attention_schemas.size() != attention_layers))
    throw std::runtime_error("target graph cold ports do not match the source geometry");
"""
source = prologue + body + "  return {x, prior_append, has_prior_append};\n}\n} // namespace qwen35\n"

call = """    // Writer-only draft maintenance has no attention data edge into target.
    // Order its real cache effects before target's first append as well.
    const auto target = emit_target_graph(r, {
        .token_ids = target_tokens, .positions = definition.position_port,
        .attention_metadata = definition.metadata_port, .frequencies = frequencies,
        .sequence_offsets = definition.sequence_offsets_port, .history_select = definition.history_select_port,
        .requests = requests, .prefix_rows = prefix_rows, .packing = packing,
        .state_slots = cache_plan.state_slots, .recurrent_descriptions = state_schema,
        .plain_attention_schema = attention_schema, .target_attention_schemas = attention_schemas,
        .cpu_ffn_layers = ffn_placement.cpu_layers(),
        .preceding_append = has_mtp(role) && !is_mtp_prefill(role)
            ? definition.append_nodes[draft_bank + 1] : g::NodeId{},
        .has_preceding_append = has_mtp(role) && !is_mtp_prefill(role)},
        {definition.layers, definition.attention_nodes,
         std::span<g::NodeId>(definition.append_nodes).first(draft_bank),
         std::span<V>(definition.append_cache_inputs).first(draft_bank),
         definition.state_sources, definition.probe_ports});
    auto x = target.hidden_rows;
    auto prior_append = target.last_append;
    bool has_prior_append = target.has_append;
"""
new_main = main[:start] + call + main[end:]
new_main = new_main.replace(schema, "", 1).replace(ports, "", 1)
assert new_main.count('#include "graph_builder.h"\n') == 1
new_main = new_main.replace('#include "graph_builder.h"\n', '#include "graph_builder.h"\n#include "target_graph.h"\n')
assert cmake.count('  "${CMAKE_CURRENT_LIST_DIR}/graph_builder.cc")\n') == 1
new_cmake = cmake.replace('  "${CMAKE_CURRENT_LIST_DIR}/graph_builder.cc")\n',
    '  "${CMAKE_CURRENT_LIST_DIR}/graph_builder.cc"\n  "${CMAKE_CURRENT_LIST_DIR}/target_graph.cc")\n')

baseline = {main_path: main_bytes, cmake_path: cmake_bytes}
candidate = {main_path: new_main.encode(), cmake_path: new_cmake.encode(),
             MODEL + "target_graph.h": header.replace("\n", "\r\n").encode(),
             MODEL + "target_graph.cc": source.replace("\n", "\r\n").encode()}
for path, data in baseline.items():
    write("base/" + path, data)
for path, data in candidate.items():
    assert not (path not in baseline and (ROOT / path).exists()), path
    write("candidate/" + path, data)
write("original-target-body.txt", old_body.encode())
write("original-moved-types.txt", (schema + ports).encode())
write("operation-mappings.json", (json.dumps(counts, indent=2) + "\n").encode())

patch = ""
for path, data in candidate.items():
    previous = baseline.get(path, b"")
    patch += f"diff --git a/{path} b/{path}\n"
    if path not in baseline:
        patch += "new file mode 100644\n"
    patch += "".join(difflib.unified_diff(previous.decode().splitlines(keepends=True),
        data.decode().splitlines(keepends=True), fromfile="a/" + path if path in baseline else "/dev/null",
        tofile="b/" + path))
write("target-graph.patch", patch.encode())

inputs = sorted(set([str(p.relative_to(ROOT)).replace("\\", "/") for p in (ROOT / MODEL).glob("*.h")] +
    [main_path, cmake_path, MODEL + "graph_builder.cc", MODEL + "CMakeLists.txt", "tests/CMakeLists.txt"]))
pins = [{"path": path, "bytes": len((ROOT / path).read_bytes()), "sha256": sha((ROOT / path).read_bytes())}
        for path in inputs]
plan = {"status": "SCRATCH_CANDIDATE_UNBUILT_UNAPPLIED", "base_head": subprocess.check_output(
    ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "scope": "Only target embedding/layer emit and three existing description types; no Family/Phase/runtime moves",
    "preconditions": pins,
    "must_be_absent": [path for path in candidate if path not in baseline],
    "candidate": [{"path": path, "bytes": len(data), "sha256": sha(data),
                   "crlf": data.count(b"\r\n"), "lf": data.count(b"\n")} for path, data in candidate.items()],
    "patch_sha256": sha(patch.encode()),
    "source_body_lines": {"first": main[:start].count("\n") + 1, "last": main[:end].count("\n")},
    "line_endings": "Existing main/cold inventory are actually LF and preserved; new h/cc are CRLF.",
    "validation": "Static token verification only. No product apply, CXX build, GPU, download or performance claim."}
write("plan.json", (json.dumps(plan, indent=2) + "\n").encode())
print(json.dumps({"base_head": plan["base_head"], "candidate_files": len(candidate),
    "body_lines": plan["source_body_lines"], "patch_bytes": len(patch.encode())}, indent=2))
