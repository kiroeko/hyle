"""Independent scratch-only review; no compiler, native execution, apply or download."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[1]
D = R / '.scratch/inference-target-graph-extract-20261030'
M = 'engine/models/qwen35/'


def read(path):
    return Path(path).read_text(encoding='utf-8-sig')


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(name, data):
    (W / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


plan = json.loads(read(D / 'plan.json'))
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert head == plan['base_head'] == 'e41c31cd83603b951d074f5b2fc0ac0cf8e038ce'
for item in plan['preconditions']:
    actual = pin(R / item['path'])
    assert (actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256']), item['path']
for item in plan['candidate']:
    actual = pin(D / 'candidate' / item['path'])
    assert (actual['bytes'], actual['sha256']) == (item['bytes'], item['sha256']), item['path']
assert pin(D / 'target-graph.patch')['sha256'] == plan['patch_sha256']
assert not (R / M / 'target_graph.h').exists() and not (R / M / 'target_graph.cc').exists()

old = read(R / M / 'main.cc')
new = read(D / 'candidate' / M / 'main.cc')
cpp = read(D / 'candidate' / M / 'target_graph.cc')
header = read(D / 'candidate' / M / 'target_graph.h')
begin = '    auto x = r.embedding(target_tokens, "model.language_model.embed_tokens.weight");\n'
after = '    if (diagnostic) for (std::size_t i = 0; i < definition.probe_ports.size(); ++i) {\n'
old_start = old.index(begin)
old_end = old.index(after, old_start)
old_body = old[old_start:old_end]
body_start = cpp.index(begin.strip() + '\n')
body_end = cpp.index('  return {x, prior_append, has_prior_append};\n', body_start)
new_body = cpp[body_start:body_end]

# Independently enumerate the allowed fact projections; do not consume the author's mapping file.
renames = [
    ('definition.append_cache_inputs', 'outputs.append_cache_inputs'),
    ('definition.attention_nodes', 'outputs.attention_nodes'),
    ('definition.state_sources', 'outputs.state_sources'),
    ('definition.append_nodes', 'outputs.append_nodes'),
    ('definition.probe_ports', 'outputs.layer0_probes'),
    ('definition.layers', 'outputs.layers'),
    ('definition.history_select_port', 'inputs.history_select'),
    ('definition.sequence_offsets_port', 'inputs.sequence_offsets'),
    ('definition.position_port', 'inputs.positions'),
    ('definition.metadata_port', 'inputs.attention_metadata'),
    ('cache_plan.state_slots', 'inputs.state_slots'),
    ('precision.activation_type()', 'r.activation_type()'),
    ('ffn_placement.ffn_on_cpu(i)', 'i < inputs.cpu_ffn_layers'),
    ('target_attention_schema(layer)', 'inputs.target_attention_schemas.empty() ? inputs.plain_attention_schema : inputs.target_attention_schemas[layer]'),
]
expected = old_body
occurrences = []
for before, replacement in renames:
    count = expected.count(before)
    assert count > 0, before
    expected = expected.replace(before, replacement)
    occurrences.append({'original': before, 'projected': replacement, 'occurrences': count})
expected, count = re.subn(
    r'g::NodeId prior_append = has_mtp\(role\) && !is_mtp_prefill\(role\)\s*'
    r'\? outputs\.append_nodes\[draft_bank \+ 1\] : g::NodeId\{\};\s*'
    r'bool has_prior_append = has_mtp\(role\) && !is_mtp_prefill\(role\);',
    'g::NodeId prior_append = inputs.preceding_append;\n'
    'bool has_prior_append = inputs.has_preceding_append;', expected)
assert count == 1
# Tokenize strings/chars before identifiers, discard only comments/whitespace.
lexer = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|'
                   r'[A-Za-z_]\w*|(?:\d[\w.\']*|\.\d[\w.\']*)|::|->|<<|>>|<=|>=|==|!=|&&|\|\||'
                   r'\+\+|--|\+=|-=|\*=|/=|\S')


def tokens(text):
    return [m.group(0) for m in lexer.finditer(text) if not m.group(0).startswith(('//', '/*'))]


assert tokens(expected) == tokens(new_body), 'Original operation/control/effect sequence differs'
schema = re.search(r'struct StateSchema final \{[\s\S]*?\n\};\n', old).group()
ports = re.search(r'struct StatePorts final \{[\s\S]*?\n\};\nstruct Ports final \{[\s\S]*?\n\};\n', old).group()
assert header.count(schema) == header.count(ports) == 1
assert schema not in new and ports not in new
call_start = new.index('    // Writer-only draft maintenance has no attention data edge into target.\n')
call_end = new.index(after, call_start)
call = new[call_start:call_end]
restored = new[:call_start] + old_body + new[call_end:]
restored = restored.replace('#include "target_graph.h"\n', '', 1)
restored = restored.replace('std::vector<StateSchema> state_schema_for', schema + 'std::vector<StateSchema> state_schema_for', 1)
restored = restored.replace('struct FamilyPorts {\n', ports + 'struct FamilyPorts {\n', 1)
assert restored == old, 'Unrelated original main content or execution/preparation order changed'
required = [
    '.token_ids = target_tokens', '.positions = definition.position_port',
    '.attention_metadata = definition.metadata_port', '.frequencies = frequencies',
    '.sequence_offsets = definition.sequence_offsets_port', '.history_select = definition.history_select_port',
    '.requests = requests', '.prefix_rows = prefix_rows', '.packing = packing',
    '.state_slots = cache_plan.state_slots', '.recurrent_descriptions = state_schema',
    '.plain_attention_schema = attention_schema', '.target_attention_schemas = attention_schemas',
    '.cpu_ffn_layers = ffn_placement.cpu_layers()',
    '.preceding_append = has_mtp(role) && !is_mtp_prefill(role)\n            ? definition.append_nodes[draft_bank + 1] : g::NodeId{}',
    '.has_preceding_append = has_mtp(role) && !is_mtp_prefill(role)',
    'std::span<g::NodeId>(definition.append_nodes).first(draft_bank)',
    'std::span<V>(definition.append_cache_inputs).first(draft_bank)',
    'definition.state_sources, definition.probe_ports',
    'auto x = target.hidden_rows;', 'auto prior_append = target.last_append;', 'bool has_prior_append = target.has_append;',
]
assert all(item in call for item in required)
assert 'std::uint32_t state_slots;' in header and 'std::span<V, 9> layer0_probes;' in header
assert 'struct Family' not in header and 'struct Phase' not in header

prelude = cpp[cpp.index('  const auto &geometry'):body_start]
for item in [
    'const auto &geometry = r.geometry;', 'auto &assembly = r.assembly;',
    'const auto t = r.token_rows, packed = r.packed_rows;',
    'const auto requests = inputs.requests, prefix_rows = inputs.prefix_rows;',
    'const auto batch = f(static_cast<std::int64_t>(requests));',
    'const auto state_schema = inputs.recurrent_descriptions;',
    'const bool packed_verify = packs_verify(inputs.packing), packed_target = packs_target(inputs.packing);',
    'const auto frequencies = inputs.frequencies;', 'const auto target_tokens = inputs.token_ids;',
    'state_schema.size() != geometry.layers.size()', 'outputs.layers.size() != state_schema.size()',
    'outputs.attention_nodes.size() != attention_layers', 'outputs.append_nodes.size() != 2 * attention_layers',
    'outputs.append_cache_inputs.size() != 2 * attention_layers',
    '(!inputs.target_attention_schemas.empty() && inputs.target_attention_schemas.size() != attention_layers)',
]:
    assert item in prelude, item


def include_closure(entry):
    seen, missing = set(), []

    def visit(relative):
        if relative in seen:
            return
        seen.add(relative)
        source = D / 'candidate' / relative
        if not source.is_file():
            source = R / relative
        for include in re.findall(r'^\s*#\s*include\s+"([^"]+)"', read(source), re.M):
            resolved = None
            for trial in [(R / relative).parent / include, R / 'include' / include, R / include]:
                try:
                    candidate = trial.resolve().relative_to(R).as_posix()
                except ValueError:
                    continue
                if (D / 'candidate' / candidate).is_file() or (R / candidate).is_file():
                    resolved = candidate
                    break
            if resolved is None:
                missing.append({'from': relative, 'include': include})
            else:
                visit(resolved)
    visit(entry)
    forbidden = [p for p in seen if p in [M + 'main.cc', M + 'session_state.h', M + 'host_image.h',
                 M + 'session_schedule.h', M + 'prefix_cache.h'] or p.endswith('/paged_sequence.h')]
    assert not forbidden, forbidden
    return {'count': len(seen), 'repository_files': sorted(seen), 'unresolved_external_includes': missing,
            'forbidden_qwen_runtime_headers': forbidden}


closures = {name: include_closure(M + name) for name in ['target_graph.h', 'target_graph.cc']}
assert not re.search(r'#\s*(if|elif).*HYLE_|Backend::|Backend\s+|\.submit\(|\.evaluate\(|\.compile\(', cpp)
old_cmake = read(R / M / 'cold_sources.cmake')
new_cmake = read(D / 'candidate' / M / 'cold_sources.cmake')
expected_cmake = old_cmake.replace('  "${CMAKE_CURRENT_LIST_DIR}/graph_builder.cc")',
                                  '  "${CMAKE_CURRENT_LIST_DIR}/graph_builder.cc"\n  "${CMAKE_CURRENT_LIST_DIR}/target_graph.cc")')
assert new_cmake == expected_cmake
tests_cmake = read(R / 'tests/CMakeLists.txt')
assert tests_cmake.count('${_hyle_qwen35_cold_sources}') == 9
check = subprocess.run(['git', 'apply', '--check', str(D / 'target-graph.patch')], cwd=R,
                       capture_output=True, text=True)
assert check.returncode == 0, check.stderr

report = {
    'status': 'PASS_INDEPENDENT_STATIC_REVIEW_UNAPPLIED_UNBUILT', 'actual_base_commit': head,
    'author_mapping_or_token_script_used': False,
    'source_body_original_lines': {'first': 1880, 'last': 2083},
    'original_tokens': len(tokens(old_body)), 'projected_tokens_compared': len(tokens(expected)),
    'all_operation_control_effect_tokens_equal_under_declared_fact_projections': True,
    'allowed_fact_projections': occurrences,
    'original_three_description_types_identical_normalized_text': True,
    'complete_main_recovered_identically': True, 'call_input_and_output_projections_checked': True,
    'port_guard_before_first_emit_and_only_cold_shape_counts': True,
    'constant_graph_specs_recipe_identity_and_preparation_order_preserved': True,
    'CMake': {'change': 'one existing model-owned inventory entry only', 'test_consumer_source_lists': 9,
              'engine_and_probe_configuration_preserved': True, 'no_new_backend_macro_initialization': True,
              'normal_build_or_configure_not_run': True},
    'schema_bounds': 'Current validated geometry attention_slot(i) is less than attention_layers for every A layer. Exact override-count guard precedes unchecked span indexing; empty overrides retains original plain schema. No new schema reconstruction.',
    'spans_and_lifetime': 'Only original unpublished Family target arrays; spans borrow synchronously and exclude draft banks. Original same state_sources vector is appended. Result contains graph IDs only, no owner transfer.',
    'profile_placement': 'Recipe.activation_type -> same GraphAssembly precision. FfnPlacement.ffn_on_cpu(i) is exactly i<cpu_layers. Existing Scope restores original placement on unwind.',
    'failure_scope': 'Only malformed private argument count now throws before embedding. Existing Model supplies matching arrays, and actual cache/draft preparation, allocation/Graph operation order, compilation fallback and success publication are unchanged.',
    'static_include_closures': closures, 'patch_read_only_check_exit': check.returncode,
    'candidate_pins': [pin(D / 'candidate' / item['path']) for item in plan['candidate']],
    'patch_pin': pin(D / 'target-graph.patch'),
    'limits': ['No CXX/link/ABI/native validation or actual compiler dependencies.',
               'Private Qwen model equations only; no universal layer, full Family or Phase abstraction.',
               'No backend execution or performance claim; static operation call counts are not GPU dispatch counts.'],
}
save('static-review.json', report)

# Refresh mature-practice evidence against actual local HEAD and actual source bytes.
L = R.parent / 'llama.cpp'
llama_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=L, text=True).strip()
assert llama_head == '23b0202a189c44a54625aadcb37a946dd1d6278d'
scopes = {
    'src/models/qwen35.cpp': [(130, 180)],
    'src/llama-model.h': [(798, 809)],
    'src/llama-model.cpp': [(2965, 2982)],
    'src/llama-graph.h': [(1002, 1065)],
    'src/llama-graph.cpp': [(1512, 1529), (1662, 1680), (1827, 1844)],
    'src/llama-context.cpp': [(1414, 1454)],
}
files = []
for relative, regions in scopes.items():
    path = L / relative
    raw = path.read_bytes()
    blob = subprocess.check_output(['git', 'show', llama_head + ':' + relative], cwd=L)
    assert raw.replace(b'\r\n', b'\n') == blob.replace(b'\r\n', b'\n')
    lines = raw.decode('utf-8').splitlines()
    files.append({**pin(path), 'relative': relative,
                  'HEAD_blob_sha256': hashlib.sha256(blob).hexdigest(),
                  'source_matches_actual_HEAD_normalized_line_endings': True,
                  'scopes': [{'first': first, 'last': last, 'excerpt': '\n'.join(lines[first-1:last])}
                             for first, last in regions]})
save('llama-family-boundary-reference.json', {
    'status': 'ACTUAL_LOCAL_HEAD_AND_SOURCE_BYTES_VERIFIED', 'actual_HEAD': llama_head, 'files': files,
    'useful_mechanism': 'Architecture-specific model equations have a concrete implementation separate from common graph helpers and context execution/reuse. Only that responsibility boundary is borrowed.',
    'non_transferable_details': 'llama uses a virtual build_arch_graph and can rebuild its graph at runtime process_ubatch; its graph context also borrows memory/context/backend facts. This does not prove a universally pure cold builder, a shared layer model, or any requirement to add virtual dispatch to Hyle.',
    'hyle_scope': 'Synchronous direct Qwen-private emit into the original Recipe, only called during current Model finite preparation; caller retains compilation/resources/runtime admission.',
})
print(json.dumps({'status': report['status'], 'original_tokens': report['original_tokens'],
                  'header_closure': closures['target_graph.h']['count'],
                  'cc_closure': closures['target_graph.cc']['count'], 'llama_reference_files': len(files),
                  'patch_check_exit': check.returncode}))
