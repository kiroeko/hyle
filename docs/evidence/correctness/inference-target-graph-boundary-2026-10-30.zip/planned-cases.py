"""Commands only. Deliberately has no subprocess/build/native functions."""
from pathlib import Path
import json
W=Path(__file__).resolve().parent;R=W.parents[1]
TINY=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
E4=R/'.scratch/inference-mtp-e4-20261028/fixture'
def proposed_cases():
 return {
 'rows-cpu':dict(consumer='rows',args=['cpu',str(TINY/'weights.tsv'),str(W/'metadata-cpu')]),
 'rows-cuda':dict(consumer='rows',args=['cuda',str(TINY/'weights.tsv'),str(W/'metadata-cuda')]),
 'history-cpu':dict(consumer='tiny',args=['--cpu',str(TINY),'--history-control']),
 'mtp-packed-prefill-cuda':dict(consumer='tiny',args=['--cuda',str(TINY),'--mtp-packed-prefill']),
 'mtp-varlen-verify-cuda':dict(consumer='tiny',args=['--cuda',str(TINY),'--mtp-varlen-verify']),
 'mtp-e4-cuda':dict(consumer='tiny',args=['--cuda',str(E4),'--mtp-e4']),
 'cpu-ffn-tiny-cuda':dict(consumer='tiny',arms=['baseline','candidate'],args=['--engine','--inputs',str(TINY),
  '--capacity','16','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--progress','direct',
  '--replay','commands','--backend','cuda','--sampling','greedy','--decode-overlap','auto',
  '--mtp','off','--steps','4','--cpu-ffn-layers','1'],outputs=4,
  comparison='All before/after non-timing report fields exact; do not compare mixed placement with an allGPU reference.'),
 'session-cuda':dict(consumer='session',arms=['baseline','candidate'],args=['--backend','cuda','--inputs',str(W/'session-input'),
  '--output','{OUTPUT}','--scenario','sessions'],expected_status='MTP_SESSION_PROBE_COMPLETED'),
 }
if __name__=='__main__':
 path=W/'planned-cases.json';assert not path.exists()
 path.write_text(json.dumps(dict(status='PLANNED_NOT_RUN',baseline_commit=None,
  default_fullV_four_pairs='Use baseline-plan cases generated from the current cachefacts CLI recipe after root commit/source freeze.',
  replacement_for_old_small_cases=dict(omit_unchanged_math_cpu=True,replace_natural_control_by=['mtp-packed-prefill-cuda','mtp-varlen-verify-cuda']),
  cases=proposed_cases(),limits=dict(max_compilers=2,GPU_serial=True,NVCC=0,downloads=0,profiler=0)),indent=2)+'\n',encoding='utf-8')
 print('Wrote command plan only; no baseline pins, build, link or native execution.')
