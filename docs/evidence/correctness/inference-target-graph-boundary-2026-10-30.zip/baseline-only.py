"""Authorized pre-migration baseline snapshot/zero-compile relinks only."""
from pathlib import Path
import argparse,importlib.util,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('target_prepare_module',W/'prepare-after-freeze.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.c;read,save,pin,exact,key=m.read,m.save,m.pin,m.exact,m.key
def prepare(expected):
 assert not (W/'baseline-plan.json').exists()
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==expected
 base=read(m.BASE);assert len(base['retained'])==228
 for name in ('cli','tiny','session'):
  receipt=read(base['current_consumers'][name]['receipt']['path'])
  for item in [receipt['object'],*receipt['source_identities']]:exact(item)
 c.baseline()
 receipt=read(base['current_consumers']['tiny']['receipt']['path'])
 save(W/'baseline-tiny-plan.json',dict(receipt=base['current_consumers']['tiny']['receipt'],object=receipt['object'],
  source_proofs=[dict(identity=item,proof='CURRENT_EXACT_BEFORE_SOURCE_MIGRATION') for item in receipt['source_identities']],
  original_closure_inputs=228,compile=0))
 snapshots=[]
 for relative in ('engine/models/qwen35/main.cc','engine/models/qwen35/cache_plan.h',
  'engine/models/qwen35/graph_builder.h','engine/models/qwen35/graph_builder.cc',
  'engine/models/qwen35/block_graph.h','engine/models/qwen35/cold_sources.cmake'):
  path=R/relative;target=W/'baseline-source'/relative;target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert target.read_bytes()==path.read_bytes()
  else:target.write_bytes(path.read_bytes())
  snapshots.append(dict(original=pin(path),snapshot=pin(target)))
 save(W/'baseline-source-before-migration.json',dict(base_commit=head,base=pin(m.BASE),snapshots=snapshots,
  checked_consumers=['cli','tiny','session'],all_cached_consumer_source_pins_current_before_migration=True,
  closure_inputs=228,baseline_CXX=0,baseline_note='Original228 includes227SDK/engine plus existingcold1; the inherited old template note mentioning227 is not the authoritative count.'))
 print('EXACT BASELINE228 CURRENT e41 source snapshots ready; no CXX/native.')
def link(name,attempt):
 if name=='cli':return c.b.link_baseline(attempt)
 if name=='session':return c.link_baseline_session(attempt)
 assert name=='tiny'
 p=read(W/'baseline-plan.json');t=read(W/'baseline-tiny-plan.json')
 for item in [t['object'],*p['retained']]:exact(item)
 args=[];count=0
 for arg in p['link']:
  if key(arg)==key(p['cli_object']['path']):arg=t['object']['path'];count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/baseline-tiny').with_suffix(suffix));break
  args.append(arg)
 assert count==1
 c.b.s.b.execute(args,W/'link/baseline-tiny'/attempt,240)
 save(W/'ready-baseline-tiny.json',pin(W/'bin/baseline-tiny.exe'))
if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='action',required=True)
 p=sub.add_parser('prepare');p.add_argument('commit')
 p=sub.add_parser('link');p.add_argument('name',choices=['cli','tiny','session']);p.add_argument('attempt')
 args=parser.parse_args()
 if args.action=='prepare':prepare(args.commit)
 else:link(args.name,args.attempt)
