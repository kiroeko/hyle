"""Four paired finite default-usage checks; no profiler or throughput window."""
from pathlib import Path
import importlib.util,json,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('cold_cli_compare',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def stable(value):
 if isinstance(value,dict):return {key:stable(item) for key,item in value.items() if not key.endswith('_seconds') and not key.endswith('_per_second')}
 if isinstance(value,list):return [stable(item) for item in value]
 return value
def delta(old,new,path='$'):
 if isinstance(old,dict) and isinstance(new,dict):
  return [row for key in sorted(old.keys()|new.keys()) for row in delta(old.get(key),new.get(key),path+'.'+key)]
 if isinstance(old,list) and isinstance(new,list):
  if len(old)!=len(new):return [dict(path=path,old_length=len(old),new_length=len(new))]
  return [row for at,(a,z) in enumerate(zip(old,new)) for row in delta(a,z,path+'['+str(at)+']')]
 return [] if old==new else [dict(path=path,old=old,new=new)]
checks=[]
for case in ('ordinary-single','mtp-single','ordinary-two','mtp-two'):
 for arm in ('baseline','candidate'):
  command=[sys.executable,str(W/'build.py'),'run',case,'attempt1']+(['baseline'] if arm=='baseline' else [])
  subprocess.run(command,cwd=R,check=True)
 old_path=W/'runs/baseline'/case/'attempt1/report.json';new_path=W/'runs/candidate'/case/'attempt1/report.json'
 old,new=b.read(old_path),b.read(new_path);differences=delta(stable(old),stable(new))
 value=dict(case=case,status='PASS' if not differences else 'FAIL',baseline=b.pin(old_path),candidate=b.pin(new_path),
  all_non_timing_fields_equal=not differences,differences=differences,
  timing_diagnostic={key:dict(baseline=old[key],candidate=new[key]) for key in ('prefill_seconds','decode_seconds','session_seconds','startup_to_ready_seconds')},
  scope='One same-args finite process pair, default full vocabulary, current exact source/SDK closure. All IDs/state scalar/RNG/ledger/work/metadata facts compared, only timing suffixes excluded; no speed claim.')
 b.save(W/('compare-'+case+'.json'),value);assert not differences,differences
 checks.append(value);print('PASS EXACT NON_TIME',case,flush=True)
b.save(W/'whole-cli-summary.json',dict(status='PASS_ALL_FOUR_DEFAULT_CASES',checks=checks))
