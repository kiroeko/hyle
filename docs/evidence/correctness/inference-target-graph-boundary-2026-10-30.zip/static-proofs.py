"""Actual compiler dependency receipts and unchanged CMake guard inventory."""
from pathlib import Path
import hashlib,importlib.util,json,re,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('target_static_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
proofs=[]
for name in ('target','leaf'):
 receipt=b.read(W/'compile'/name/'receipt.json')
 for item in [receipt['object'],receipt['dependencies'],*receipt['source_identities']]:b.exact(item)
 sources=[Path(item['path']).relative_to(R).as_posix() for item in receipt['source_identities']]
 prohibited=['engine/models/qwen35/main.cc','engine/models/qwen35/session_state.h','engine/inference/paged_sequence.h']
 assert not any(path in prohibited for path in sources),sources
 proofs.append(dict(unit=name,receipt=b.pin(W/'compile'/name/'receipt.json'),repository_source_pin_count=len(sources),
  repository_sources=sources,no_Qwen_main_or_state_owner_or_runtime_paged_sequence_headers=True,
  scope='Actual /sourceDependencies; generic Graph/Compute declarations are legitimate borrowed graph primitives, not Model/Session ownership.'))
b.save(W/'cold-dependency-proof.json',proofs)
inventory=R/'engine/models/qwen35/cold_sources.cmake';text=inventory.read_text()
files=re.findall(r'"\$\{CMAKE_CURRENT_LIST_DIR\}/([^\"]+)"',text)
assert files==['weights.cc','graph_builder.cc','target_graph.cc'],files
guards=[]
commit=b.read(W/'baseline-plan.json')['base_commit']
for relative in ('engine/models/qwen35/CMakeLists.txt','tests/CMakeLists.txt'):
 path=R/relative;old=subprocess.check_output(['git','show',commit+':'+relative],cwd=R)
 assert path.read_bytes()==old,relative
 guards.append(dict(source=b.pin(path),byte_equal_baseline_commit=True))
b.save(W/'cmake-inventory-proof.json',dict(status='THREE_COLD_SOURCES_AND_ORIGINAL_GUARDS_EXACT',inventory=b.pin(inventory),
 sources=[b.pin(inventory.parent/name) for name in files],source_count=3,unchanged_existing_guards=guards,
 configure_executed=False,full_default_CMake_build_executed=False,
 scope='Source inventory and exact existing predicates only; actual manual CXX/link are recorded separately. No claim that normal CMake targets were built.'))
print(json.dumps(dict(deps={row['unit']:row['repository_source_pin_count'] for row in proofs},
 no_Qwen_runtime_owners=True,cold_inventory_sources=3,original_guards_exact=True,full_CMake_build=False)))
