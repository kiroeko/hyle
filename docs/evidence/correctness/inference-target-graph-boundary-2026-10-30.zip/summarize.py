"""Compact terminal inventory; preserves all failed and unvalidated facts."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('target_summary_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin=b.read,b.save,b.pin
attempts=[];failures=[]
for directory in ('compile','link','runs'):
 for path in sorted((W/directory).rglob('process.json')):
  process=read(path);assert process['state']=='TERMINAL' and not process['timed_out']
  row=dict(path=path.parent.relative_to(W).as_posix(),exit=process['exit'],process=pin(path),command=pin(path.parent/'command.json'))
  attempts.append(row)
  if process['exit']:failures.append(dict(**row,stderr=pin(path.parent/'stderr.log'),stdout=pin(path.parent/'stdout.log')))
assert len(attempts)==29 and len(failures)==2
assert {row['path'] for row in failures}=={
 'runs/baseline/cpu-ffn-tiny-cuda/attempt1','runs/candidate/cpu-ffn-tiny-cuda/attempt1'}
whole=read(W/'whole-cli-summary.json');assert all(row['all_non_timing_fields_equal'] and not row['differences'] for row in whole['checks'])
session=read(W/'session-compare.json');assert session['status']=='PASS_EXACT_COMPLETE_SESSION'
vector=read(W/'session-vector-manifest.json');assert vector['file_count_per_arm']==378 and vector['bytes_per_arm']==150761472
cpu=read(W/'compare-cpu-ffn-real-cuda.json');assert cpu['status']=='PASS' and not cpu['differences']
branch=read(W/'finite-branch-summary.json');assert branch['status']=='PASS_THREE_EXISTING_TARGET_BRANCHES'
tiny=read(W/'cpu-ffn-tiny-attribution.json');assert tiny['status']=='IDENTICAL_REFUSAL_CLASS_ON_BASELINE_AND_CANDIDATE'
source=read(W/'source-freeze.json')
for item in source['sources']:b.exact(item)
counts=dict(total=len(attempts),CXX=sum(row['path'].startswith('compile/') for row in attempts),
 links=sum(row['path'].startswith('link/') for row in attempts),native=sum(row['path'].startswith('runs/') for row in attempts),
 native_pass=sum(row['path'].startswith('runs/') and row['exit']==0 for row in attempts),native_failed=len(failures),
 scratch_parser_exceptions=1,downloads=0,NVCC=0)
assert counts['CXX']==5 and counts['links']==6 and counts['native']==18 and counts['native_pass']==16
save(W/'process-inventory.json',dict(attempts=attempts,failed_native_attempts=failures))
summary=dict(schema='hyle.target-graph-finite-verification.v1',status='FINITE_TARGET_CHECKS_PASS_TWO_ATTRIBUTED_TINY_REFUSALS_RETAINED',
 base_commit=read(W/'baseline-plan.json')['base_commit'],full_goal_complete=False,attempts=counts,
 closure=dict(original_inputs_reused_byte_exact=228,new_target_model_cold=1,total=229,SDK_CXX=0,existing_graph_builder_CXX=0,
  current_consumers_CXX=3,new_header_compile_only_CXX=1,rows_and_math_recompiled=False),
 deps=dict(target_repository_pins=115,leaf_repository_pins=44,no_Qwen_main_or_state_owner_headers=True,
  available_dependency_rows=160,unavailable_old_native_library_metadata=69),
 default_fullV=dict(scenarios=4,processes=8,all_non_timing_exact=True,differences=[],
  timing_diagnostic=[dict(case=row['case'],**row['timing_diagnostic']) for row in whole['checks']],
  scope='One process pair per case only; obvious regression observation, no stable timing/performance lead claim.'),
 Session=dict(processes=2,payload_files_per_arm=378,payload_bytes_per_arm=150761472,byte_equal=True,
  all_metadata_exact_except_absolute_output_root=True,differences=[],idle_complete_head_checks=4,A_calls_after_B_stop=3,
  final_live_versions=0,payload_known_plan_bytes=80240691,metadata_requested_bytes=0),
 successful_tiny_checks=['history-control CPU','MTP packed-prefill CUDA','MTP varlen-verify CUDA','MTP E4 cache CUDA'],
 inherited_packed_numerics='Original3e-6 newly computedF32 GDN component bound unchanged; other within-case payload contracts unchanged. Varlen internal packed-v-exact payloads are not all byteequal; same-implementation Session before/after is byteexact.',
 CPU_FFN_real=dict(status='PASS',case='cpu-ffn-real-cuda',processes=2,generated_tokens=4,source_identity=cpu['source_identity'],
  capacity=1024,replay='auto',cpu_layers=2,all_non_timing_exact=True,differences=[],
  host_constants_per_plan=[10,10],original_3_domain_2_target_host_Domain1_assertions_executed=True,
  scope='Current BF16 H2048/154-ID fullV source;2target FFNs CPU then primaryGPU. Original capacity1024/auto run had already finished before root suggested256/commands; not rerun. This is finite placement coverage.'),
 CPU_FFN_tiny=dict(status='FAILED_BOTH_ARMS',processes=2,cpu_layers=1,
  refusal='finite variant0 graph input alias port alignment/resource search exhausted',candidate_regression=False,
  hardware_unsupported=False,hybrid_plan_successfully_reported=False,
  next='Original common Graph alias/materialization fallback capability remains in the active goal; this fixture is not successful native mixed coverage.'),
 scratch_parser_exception=dict(count=1,record=pin(W/'finite-attempt1-parser-failure.json'),
  correction='Preserve all completeJSON values and assert every statusPASS; select exactly one branch by its expected mode/case schema. Accepted native processes were not rerun.'),
 artifacts={name:pin(W/name) for name in ['model-link-base.json','process-inventory.json','session-compare.json','session-vector-manifest.json',
  'whole-cli-summary.json','finite-branch-summary.json','compare-cpu-ffn-real-cuda.json','cpu-ffn-tiny-attribution.json',
  'cold-dependency-proof.json','cmake-inventory-proof.json','hardware-toolchain.json']},
 boundaries=['Manual actualCXX/link with exact cache; inventory3files and existingCMake guards exact, full defaultCMake build not run.',
  'No source edits by evidence runner, no download/NVCC/profile/independent performance candidate.',
  'Finite Qwen targetcold extraction check only, not whole architecture/feature/quality completion.'])
save(W/'verification-summary.json',summary)
print(json.dumps(dict(status=summary['status'],attempts=counts,retained=229,Session_byte_equal=True,CPU_FFN_real='PASS',CPU_FFN_tiny='2FAILED_ATTRIBUTED'),ensure_ascii=False))
