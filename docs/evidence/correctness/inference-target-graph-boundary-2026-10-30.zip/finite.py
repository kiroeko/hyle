"""Only the authorized3 target branches and2 same-placement tiny CLI arms."""
from pathlib import Path
import importlib.util,json,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('target_finite_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def stable(value):
 if isinstance(value,dict):return {key:stable(item) for key,item in value.items() if not key.endswith('_seconds') and not key.endswith('_per_second')}
 if isinstance(value,list):return [stable(item) for item in value]
 return value
def delta(old,new,path='$'):
 if isinstance(old,dict) and isinstance(new,dict):
  return [row for key in sorted(old.keys()|new.keys()) for row in delta(old.get(key),new.get(key),path+'.'+key)]
 if isinstance(old,list) and isinstance(new,list):
  if len(old)!=len(new):return [dict(path=path,old_length=len(old),new_length=len(new))]
  return [row for at,(a,z) in enumerate(zip(old,new)) for row in delta(a,z,path+'['+str(at)+']')]
 return [] if old==new else [dict(path=path,old=old,new=new)]
def run(case,arm='candidate'):
 path=W/'runs'/arm/case/'attempt1/report.json'
 if path.exists():
  process=b.read(path.parent/'process.json');assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
  b.exact(b.read(path.parent/'image.json'))
  return path,b.read(path)
 assert not (path.parent/'process.json').exists(),'Existing non-report attempt must stay preserved; use a separately authorized fresh attempt.'
 args=[sys.executable,str(W/'build.py'),'run',case,'attempt1']+(['baseline'] if arm=='baseline' else [])
 subprocess.run(args,cwd=R,check=True)
 return path,b.read(path)
if __name__=='__main__':
 checks=[]
 for case in ('mtp-packed-prefill-cuda','mtp-varlen-verify-cuda','mtp-e4-cuda'):
  path,report=run(case)
  values=report.get('reports',[report]);assert all(value['status']=='PASS' for value in values)
  selector={'mtp-packed-prefill-cuda':('mode','mtp_packed_prefill'),
   'mtp-varlen-verify-cuda':('mode','mtp_varlen_verify'),'mtp-e4-cuda':('case','mtp-e4-cache')}
  key,expected=selector[case];matches=[value for value in values if value.get(key)==expected]
  assert len(matches)==1,(case,values)
  selected=matches[0];assert selected['final_versions']==0
  checks.append(dict(case=case,report=b.pin(path),status=report['status'],final_versions=0))
  print('PASS TARGET BRANCH',case,flush=True)
 b.save(W/'finite-branch-summary.json',dict(status='PASS_THREE_EXISTING_TARGET_BRANCHES',checks=checks,
  scope='Current candidate only; inherited within-case contracts unchanged. Packed GDN keeps original3e-6 component budget; other byte contracts and E4 same-precision11full-byte checks preserved. No trained-model quality or speed claim.'))
 old_path,old=run('cpu-ffn-tiny-cuda','baseline');new_path,new=run('cpu-ffn-tiny-cuda')
 differences=delta(stable(old),stable(new))
 assert old['cpu_ffn_layers']==new['cpu_ffn_layers']==1
 b.save(W/'compare-cpu-ffn-tiny-cuda.json',dict(status='PASS' if not differences else 'FAIL',baseline=b.pin(old_path),
  candidate=b.pin(new_path),all_non_timing_fields_equal=not differences,differences=differences,
  scope='Same cached GA/H64/V64 CUDA tiny --engine,4greedy output tokens, first target FFN onCPU then primaryGPU; only timing suffixes excluded.'))
 assert not differences,differences
 print('PASS EXACT NON_TIME CPU_FFN_TINY',flush=True)
