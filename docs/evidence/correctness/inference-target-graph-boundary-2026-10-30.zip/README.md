# Target graph 冷边界：有限验证终态

root 先封存精确基线 `e41c31cd83603b951d074f5b2fc0ac0cf8e038ce` 源码与228项缓存，再应用冻结四文件。实际5次 CXX、6次 link 全部 exit0；18次 native 为16成功与2次同参数 tiny CPUFFN 拒绝，另有1次已修的 scratch 多JSON汇总解析异常。没有产品源码修补、下载、NVCC 或性能候选。全部过程已终态；以 `verification-summary.json`、`process-inventory.json` 和各原始命令/日志为准，以下保留准备时范围和选择依据。

默认四对的全部非计时字段相同；Session 两臂各378 payload/150,761,472B逐字节相同，完整 observation 仅归一输出目录后零差异。真实 BF16 H2048 CPUFFN2 的4-token两臂全非计时相同，各2个原 hybrid_plan 的 host_constants=10，原3域/2target和host Domain1常量断言完整经过。该对照使用1024/auto，是 root 后来提出256/commands前已完成的实际边界，不重跑替换。tiny CPUFFN1 两臂则同在 finite variant0 因 alias port alignment/search拒绝；不能记成成功覆盖、硬件不支持或候选回归，底层 Graph 修复仍在 active goal。

原计划 rows/math 未运行、未重链/重编；rows 对当前主干没有依赖且全部旧 source pins 精确。仅保留 historyCPU 以及 packed/varlen/E4 三个小分支检查。229 项闭包为旧228字节精确复用加 target 新对象1。设计依据为 `../inference-cache-plan-review-20261030/first-target-graph-slice-design.md`。

## 构建闭包

- 基线使用 `../inference-cold-cache-facts-20261030/model-link-base.json` 的准确 228 项：227 SDK/engine（含当前 weights）加既有 graph_builder 冷对象。CLI、tiny、Session 基线均使用其当前 receipt，零编译重新链接；若相同精确 image 仍保留，可直接校验后复用。
- 候选新增 `target_graph.cc` 一个模型冷对象，228 → 229。已有 graph_builder 不再 append；实际受影响的旧对象只能原位替换。权重和 graph_builder 的源码/头预计不改，故预计 SDK CXX=0、旧 cold CXX=0；以实际依赖扫描为准，不能为了凑预期跳过变更。
- 按 228 项已有 sourceDependencies 扫描（159 可读、69 原历史 native/library 元数据缺失）。CLI/tiny/Session 的 main 依赖会变化，需当前头闭包重新编译。rows 若全部 source pins 仍精确相同则复用旧对象，只重新链接 229 项；不因新增 inventory 文件就盲重编它。任何额外受影响消费者也需重编或标历史，不能旧新头混用。
- 新 target TU 按原 CLI/graph_builder 的 Backend capability 编译参数构建；最多两个 cl，无 NVCC、SDK 全量构建、下载或整套源码复制。使用唯一 cold_sources.cmake 加入 engine/测试消费者；本轮需检查真实 source inventory，完整默认 CMake 是否运行由 root 选定，不以手工链接冒充默认构建通过。
- 实际依赖检查：target_graph.cc 不包含 main、session_state 或其他 Qwen Session/Snapshot owner 头；cache_plan/Graph/Compute 的真实图原语可合法存在。rows 仍仅消费 Recipe/GraphAssembly，无 target 主干头必要依赖。新对象只同步追加同一 Recipe，不保存 span、发布 Family 或拥有 runtime state。

## 有限 case 选择

继续使用 cachefacts harness 的默认 fullV 四对 ordinary/MTP single64/two128 和两臂 corrected Session；所有非计时字段保持精确比较。Session 重新保存全部逻辑 target/draft KV、GDN、conv、carry、hidden/logits，并直接逐字节比较；仅归一绝对输出目录。既有 378 文件/150,761,472B 是计划参考，不代替新运行实测。

原五个小检查中保留 rows CPU/CUDA（metadata、三种存储、预算/退休）和 history-control CPU；cache-plan 24 组的实现未改，下一片建议不重复。natural-logits-control CUDA 可由下列更直接覆盖本次构图分支的 packed/verify 检查替代，不大批扫描所有 tiny flags：

| 现有入口 | 建议后端/次数 | 本次作用 |
| --- | --- | --- |
| `--mtp-packed-prefill` | CUDA，一次 | packed target 的 GDN history/conv、target attention；MtpPrefill/MtpCatchupPrefill，lag1 draft 尾依赖、Verify3、MtpSingle，旧头/RNG/epoch/退出退休合同 |
| `--mtp-varlen-verify` | CUDA，一次 | 真实 `RowPacking::kVerify` R2 物理3/成员，实际长度 `[1,3]`、`[3,1]`，history/prefix selectors、接受前缀1/2/3、real q、R1控制与完整状态 |
| tiny `--engine` 转发 CLI，`--cpu-ffn-layers 1` | CUDA，两臂各一次、4 token | 当前 tiny case 的 Model 构造 cpu_ffn 参数均为0；`--cpu` 后端本身不等同非零 CPU FFN Scope。GA 两层 fixture 的第一个 FFN 在 CPU、下一层返回 GPU，检查 Scope 选择/恢复与默认激活类型 |
| `--mtp-e4` | CUDA，一次 | 已有本地 E4 fixture 验证 target 两个独立校准的 CacheEncode 与 BF16 draft 分离、11次完整字节检查、K1/K2/B2及退休 |

packed 的现有 self-check 仅允许其原 `gdn_state_absolute_budget=0.000003`，依据是既有独立 FP64 GDN 组件 oracle；其他 payload 是 byte exact。此预算不能扩大，也不能据它给 before/after 新增容差。默认四对、CPU FFN 两臂与 Session 都无新增非计时排除项。

`--mtp-e4` 的现成输入是 `../inference-mtp-e4-20261028/fixture/weights.tsv`，GA/H64/V64/C16、`E4M3FN original_kv_scales`；离线查到其三个引用文件均存在（未下载、未执行）。旧报告仅说明输入用途，不能当新候选通过。原 case 会逐 family 检查两个 target CacheEncode 及原 K/V calibration，不以 E4 与 BF16 数值相等作要求。

`planned-cases.py` 保留准备时命令数组。`prepare-after-freeze.py` 已在冻结后生成计划；原计划状态不覆盖，真实终态由 process receipts 与 summary表示。`baseline-only.py` 是已运行的基线封存/三次链接入口；`build.py`、`finite.py`、`whole-cli.py`、`cpu-ffn-bounded.py` 保存实际执行路径；`compare.py` 独立完成完整状态与默认报告精确比较。

时间只保留同参完整消费者的单配明显退化诊断；没有独立优化、ABBA、Nsight、peer window 或性能领先结论。
