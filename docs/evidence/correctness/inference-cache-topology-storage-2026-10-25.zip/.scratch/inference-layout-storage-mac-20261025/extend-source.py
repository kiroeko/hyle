from pathlib import Path
import json,re,hashlib,tarfile
R=Path(__file__).resolve().parents[2];B=Path(__file__).resolve().parent
p=json.loads((B/'plan.json').read_text());D=p['remote']
own_dirs={R,R/'include'}
for job in p['jobs']:
 for w in job['command']:
  if w.startswith('-I'+D+'/source'):
   rel=w[len('-I'+D+'/source'):].lstrip('/')
   own_dirs.add(R/rel)
seen=set();pending=[B/'source'/x['path'] for x in p['source_pins']]
added=[]
while pending:
 f=pending.pop().resolve()
 if f in seen:continue
 seen.add(f)
 rel=f.relative_to((B/'source').resolve())
 for spelling in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',f.read_text(encoding='utf-8-sig'),re.M):
  candidates=[R/rel.parent/spelling]+[q/spelling for q in own_dirs]
  for q in candidates:
   q=q.resolve()
   if q.is_file() and q.is_relative_to(R):
    name=q.relative_to(R).as_posix();target=B/'source'/name
    if not target.exists():
     target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(q.read_bytes())
     added.append({'path':name,'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
    if target.resolve() not in seen:pending.append(target)
    break
allpins={x['path']:x for x in p['source_pins']}
allpins.update({x['path']:x for x in added})
(B/'source-pins2.json').write_text(json.dumps(list(allpins.values()),indent=2)+'\n')
(B/'source-extension.json').write_text(json.dumps({'reason':'Include search directories were part of the old actual compile recipe but omitted from first lexical source sync','added':added},indent=2)+'\n')
with tarfile.open(B/'source-extension.tar.gz','w:gz') as z:
 for x in added:z.add(B/'source'/x['path'],arcname='source/'+x['path'])
 for n in ['source-pins2.json','source-extension.json']:z.add(B/n,arcname=n)
print(json.dumps({'added':len(added),'bytes':sum(x['bytes'] for x in added),'archive_bytes':(B/'source-extension.tar.gz').stat().st_size}))

