from pathlib import Path
import hashlib,json,subprocess,time,sys,re
D=Path(__file__).resolve().parent
p=json.loads((D/'consumer-plan.json').read_text())
def run(tag,command,timeout=120):
 out=D/tag;out.mkdir(parents=True,exist_ok=False)
 (out/'command.json').write_text(json.dumps({'command':command,'cwd':str(D)},indent=2)+'\n')
 t=time.monotonic()
 with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
  r=subprocess.run(command,cwd=D,stdout=so,stderr=se,timeout=timeout)
 result={'exit':r.returncode,'seconds':time.monotonic()-t}
 (out/'process.json').write_text(json.dumps(result,indent=2)+'\n')
 print(tag,json.dumps(result),flush=True)
 if r.returncode:
  print((out/'stderr.log').read_text(errors='replace')[-12000:],flush=True);sys.exit(r.returncode)
 return result
def pin(x):
 f=Path(x);return {'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
for x in p['source_added']:
 assert pin(D/'source'/x['path'])['sha256']==x['sha256'],x['path']
results={'compile':run('consumer',p['compile'])}
objects=[x for x in p['link'] if x.endswith('.o')]
n=subprocess.run(['/usr/bin/nm','-u']+objects,capture_output=True,text=True,timeout=60)
old=[x for x in n.stdout.splitlines() if 'BatchLayoutVersion6schema' in x]
(D/'selected-getter-symbols.json').write_text(json.dumps({'command':['/usr/bin/nm','-u']+objects,'exit':n.returncode,'old_getter_references':old,'scope':'Selected direct objects only; archive-selected members checked again in final image.'},indent=2)+'\n')
assert n.returncode==0 and not old,old
inputs=[pin(x) for x in p['link'] if x.endswith(('.o','.a','.dylib')) and Path(x).is_file()]
(D/'retained-link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
results['link']=run('link',p['link'])
n=subprocess.run(['/usr/bin/nm','-gU',str(D/'paged-e4')],capture_output=True,text=True,timeout=60)
old=[x for x in n.stdout.splitlines() if 'BatchLayoutVersion6schema' in x]
origin=[x for x in n.stdout.splitlines() if 'BatchLayoutVersion13origin_schema' in x]
(D/'image-getter-symbols.json').write_text(json.dumps({'command':['/usr/bin/nm','-gU',str(D/'paged-e4')],'exit':n.returncode,'old_getter_definitions':old,'origin_getter_definitions':origin,'total_symbol_lines':len(n.stdout.splitlines())},indent=2)+'\n')
assert n.returncode==0 and not old and origin,(old,origin)
(D/'consumer-summary.json').write_text(json.dumps({'status':'LINKED_NOT_RUN','results':results,'image':pin(D/'paged-e4'),'old_getter_symbols':0,'case':p['case'],'SDK_builds':0,'model_runs':0,'HTTP':0},indent=2)+'\n')

