from pathlib import Path
import hashlib,json,difflib
D=Path('/Users/kiro/hyle/.scratch/inference-layout-storage-20261025')
O=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-graph-bridge-20261024/attempt1/source')
names=['src/compute_route_apple/apple_runtime_internal.h','src/compute_route_apple/apple_memory_internal.h','src/compute_route_apple/apple_program_internal.h','src/graph_route_apple/native_region.h','src/graph/compile_internal.h','src/graph/execution_source_internal.h']
out=[]
for n in names:
 a=D/'source'/n;b=O/n
 if not a.exists() or not b.exists():
  out.append({'path':n,'current':a.exists(),'cached':b.exists()});continue
 x=a.read_bytes();y=b.read_bytes()
 out.append({'path':n,'current_sha':hashlib.sha256(x).hexdigest(),'cached_sha':hashlib.sha256(y).hexdigest(),'same':x==y,'diff':list(difflib.unified_diff(y.decode().splitlines(),x.decode().splitlines(),n+'/cached',n+'/current'))})
print(json.dumps(out,indent=2))

