import pathlib,json
d=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified')
paths=[d/'qwen-k1-functional-20261024/attempt1/plan.json',d/'architecture-refactor-20261019-apple-page-invocation/gdn-graph-bridge-20261024/attempt1/commands.json',d/'qwen-cpu-apple-functional-20261024/attempt1/delta2-plan.json']
print(json.dumps([{'path':str(p),'data':json.loads(p.read_text())} for p in paths]))
