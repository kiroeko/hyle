from pathlib import Path,PurePosixPath
import re,json,hashlib,tarfile
R=Path(__file__).resolve().parents[2];B=Path(__file__).resolve().parent
p=json.loads((B/'plan.json').read_text());D=p['remote']
gdn=json.loads((B/'build-recipes.json').read_text())[1]['data']
original=gdn['probe'][0]['argv']
source='tests/graph_route_apple/paged_e4_kv_test.cc'
command=[];skip=False
for w in original:
 if skip:skip=False;continue
 if w in ['-o','-MF']:skip=True;continue
 if w in ['-c','-MD','-MMD'] or str(w).endswith('gdn_graph_bridge_test.cc'):continue
 if w.startswith('-I') and '/source/' in w:
  w='-I'+D+'/source/'+w.split('/source/',1)[1]
 command.append(w)
command[1:1]=['-I'+D+'/source/include','-I'+D+'/source']
command += ['-Werror','-MMD','-MF',D+'/consumer/unit.d','-c',D+'/source/'+source,'-o',D+'/consumer/unit.o']
known={x['path'] for x in json.loads((B/'source-pins2.json').read_text())}
pending=[R/source];seen=set();added=[]
while pending:
 f=pending.pop().resolve()
 if f in seen:continue
 seen.add(f)
 rel=f.relative_to(R).as_posix();target=B/'source'/rel
 if rel not in known:
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes())
  added.append({'path':rel,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()});known.add(rel)
 for spelling in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',f.read_text(encoding='utf-8-sig'),re.M):
  for q in [f.parent/spelling,R/'include'/spelling,R/spelling]:
   q=q.resolve()
   if q.is_file() and q.is_relative_to(R):
    pending.append(q);break
newobj=[]
for i,j in enumerate(p['jobs']):
 folder='compile' if i<2 else 'compile2' if i<5 else 'compile3'
 newobj.append(D+'/'+folder+'/'+j['tag']+'/unit.o')
stems={j['tag'] for j in p['jobs']}|{j['tag'].removesuffix('.cc') for j in p['jobs']}
link=[];removed=[]
for w in p['baseline_link']['command']:
 name=PurePosixPath(w).name.removeprefix('current--')
 if w.endswith('.o') and (name=='model.o' or name.removesuffix('.o') in stems):
  removed.append(w);continue
 if 'hyle-cpu-apple-current5' in w:w=w.replace('hyle-cpu-apple-current5',D+'/paged-e4') if w=='hyle-cpu-apple-current5' else w
 link.append(w)
# Exact original output/map replacement without shell rewriting.
i=link.index('-o');old_output=link[i+1];link[i+1]=D+'/paged-e4'
link=[('-Wl,-map,'+D+'/paged-e4.map') if x.startswith('-Wl,-map,') else x for x in link]
link[1:1]=[D+'/consumer/unit.o']+newobj
gtests=[x for x in gdn['link']['metal']['argv'] if x.endswith('.a') and PurePosixPath(x).name in ['libgtest_main.a','libgtest.a']]
assert len(gtests)==2 and any(x.endswith('/objects/model.o') for x in removed)
link+=gtests
plan={'remote':D,'compile':command,'link':link,'removed_original_objects':removed,'new_objects':newobj,
      'old_output':old_output,'case':'ApplePagedE4Kv.FixedQ1GrowsHistoryThroughOriginalReader',
      'scope':'One unchanged existing Apple E4 Q1 case. New topology/storage variants are compile-covered only; no native dual-scale-domain or E4append execution claim.',
      'source_added':added,'runtime':['--gtest_filter=ApplePagedE4Kv.FixedQ1GrowsHistoryThroughOriginalReader','--gtest_output=xml:'+D+'/run/results.xml']}
(B/'consumer-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with tarfile.open(B/'consumer-source.tar.gz','w:gz') as z:
 for x in added:z.add(B/'source'/x['path'],arcname='source/'+x['path'])
 z.add(B/'consumer-plan.json',arcname='consumer-plan.json')
print(json.dumps({'consumer_source_files':len(added),'consumer_source_bytes':sum(x['bytes'] for x in added),'removed_direct_objects':len(removed),'new_objects':len(newobj),'gtest_libs':gtests}))

