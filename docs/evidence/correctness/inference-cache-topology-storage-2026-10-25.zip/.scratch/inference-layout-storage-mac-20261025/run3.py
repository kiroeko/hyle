from pathlib import Path
import hashlib,json,subprocess,time,sys
D=Path(__file__).resolve().parent
p=json.loads((D/'plan.json').read_text())
initial=json.loads((D/'compile-summary2.json').read_text())
assert len(initial['results'])==6 and initial['results'][-1]['exit']!=0
(D/'compile-summary-attempt2.json').write_text(json.dumps(initial,indent=2)+'\n')
results=initial['results'][:5]
for job in p['jobs'][5:]:
 out=D/'compile3'/job['tag'];out.mkdir(parents=True,exist_ok=False)
 command=[x.replace(str(D/'compile')+'/',str(D/'compile3')+'/') for x in job['command'] if x not in ['-MD','-MMD']]
 command.insert(1,'-MMD')
 (out/'command.json').write_text(json.dumps({'command':command,'cwd':str(D),'original_recipe':job['original_recipe'],'correction':'exactly one dependency-generation mode; preserved original failed attempt'},indent=2)+'\n')
 t=time.monotonic()
 with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
  r=subprocess.run(command,cwd=D,stdout=so,stderr=se,timeout=120)
 result={'source':job['source'],'exit':r.returncode,'seconds':time.monotonic()-t,'directory':str(out)}
 (out/'process.json').write_text(json.dumps(result,indent=2)+'\n')
 results.append(result)
 (D/'compile-summary3.json').write_text(json.dumps({'status':'RUNNING' if r.returncode==0 else 'FAILED','results':results},indent=2)+'\n')
 print(json.dumps(result),flush=True)
 if r.returncode:
  print((out/'stderr.log').read_text(errors='replace')[-12000:],flush=True);sys.exit(r.returncode)
for x in json.loads((D/'source-pins2.json').read_text()):
 f=D/'source'/x['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'],f
(D/'compile-summary3.json').write_text(json.dumps({'status':'PASS_11_STRICT_TUS_COMPILE_ONLY','results':results,'SDK_builds':0,'model_runs':0,'HTTP':0,'source_pins_unchanged':True,'first_failure':str(D/'compile-summary-attempt2.json')},indent=2)+'\n')

