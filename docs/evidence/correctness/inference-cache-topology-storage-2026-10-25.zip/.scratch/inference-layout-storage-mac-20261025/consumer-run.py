from pathlib import Path
import hashlib,json,os,subprocess,time,sys,xml.etree.ElementTree as ET
D=Path(__file__).resolve().parent
p=json.loads((D/'consumer-plan.json').read_text())
summary=json.loads((D/'consumer-summary.json').read_text())
image=D/'paged-e4'
assert hashlib.sha256(image.read_bytes()).hexdigest()==summary['image']['sha256']
out=D/'run';out.mkdir(exist_ok=False)
env=dict(os.environ,MLX_METAL_PATH='/Users/kiro/hyle-scratch/compute-unified/qwen-k1-functional-20261024/attempt1/mlx.metallib',OMP_NUM_THREADS='4',VECLIB_MAXIMUM_THREADS='4')
assert Path(env['MLX_METAL_PATH']).is_file()
command=[str(image)]+p['runtime']
(out/'command.json').write_text(json.dumps({'command':command,'cwd':str(D),'environment':{k:env[k] for k in ['MLX_METAL_PATH','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']},'timeout_seconds':120},indent=2)+'\n')
t=time.monotonic()
with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
 r=subprocess.run(command,cwd=D,env=env,stdout=so,stderr=se,timeout=120)
result={'exit':r.returncode,'seconds':time.monotonic()-t}
(out/'process.json').write_text(json.dumps(result,indent=2)+'\n')
summary['run']=result
summary['status']='FAILED_ORIGINAL_APPLE_CASE' if r.returncode else 'PASS_MAC_COMPILE_AND_ORIGINAL_E4_Q1_CASE'
if (out/'results.xml').exists():
 x=ET.parse(out/'results.xml').getroot()
 summary['gtest']={k:x.attrib.get(k) for k in ['tests','failures','disabled','errors']}
 summary['gtest']['skipped_cases']=len(x.findall('.//testcase/skipped'))
 summary['gtest']['properties']=[dict(n.attrib) for n in x.findall('.//property')]
summary['scope_limits']=['11 related product TUs strictly compiled; one unchanged original Apple E4 Q1 reader/history/old-output test executed.','No native two-storage-variant shared-domain case and no E4 append executed.','Original cached 456/MLX/vendor libraries reused, no SDK or third-party build, no model weights/network.']
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
print((out/'stdout.log').read_text(errors='replace')[-4000:],flush=True)
if r.returncode:print((out/'stderr.log').read_text(errors='replace')[-8000:],flush=True)
sys.exit(r.returncode)

