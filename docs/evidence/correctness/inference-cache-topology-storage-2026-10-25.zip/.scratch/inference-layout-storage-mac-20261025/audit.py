from pathlib import Path
import json, subprocess, hashlib
D=Path('/Users/kiro/hyle-scratch/compute-unified')
B=D/'qwen-cpu-apple-functional-20261024/attempt1'
def read(p):
    return json.loads(p.read_text()) if p.is_file() else None
out={}
out['hardware']={key:subprocess.check_output(cmd,text=True).strip() for key,cmd in [
('model',['sysctl','-n','hw.model']),('memory',['sysctl','-n','hw.memsize']),
('clang',['xcrun','clang++','--version']),('macos',['sw_vers'])]}
p=read(B/'plan.json')
out['baseline_plan']={'path':str(B/'plan.json'),'jobs':p['jobs']} if p else None
p=read(B/'link5/command.json')
out['baseline_link']=p
for name in ['qwen-native-lifetime-audit-20261024','qwen-multik-functional-20261024',
             'apple-memory-lifetime-20261024','architecture-refactor-20261019-apple-page-invocation']:
    base=D/name
    if not base.is_dir():continue
    entry={'path':str(base),'files':[str(x.relative_to(base)) for x in sorted(base.iterdir())]}
    for sub in ['attempt1','check1']:
        b=base/sub
        if b.is_dir():
            entry[sub]=[str(x.relative_to(base)) for x in sorted(b.iterdir())]
    out[name]=entry
print(json.dumps(out,indent=2))

