from pathlib import Path
import hashlib,json,subprocess,time,sys
D=Path(__file__).resolve().parent
p=json.loads((D/'plan.json').read_text())
for x in p['source_pins']:
 f=D/'source'/x['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'],f
results=[]
for job in p['jobs']:
 out=D/'compile'/job['tag'];out.mkdir(parents=True,exist_ok=False)
 record={'command':job['command'],'cwd':str(D),'original_recipe':job['original_recipe']}
 (out/'command.json').write_text(json.dumps(record,indent=2)+'\n')
 t=time.monotonic()
 with (out/'stdout.log').open('wb') as so,(out/'stderr.log').open('wb') as se:
  r=subprocess.run(job['command'],cwd=D,stdout=so,stderr=se,timeout=120)
 result={'source':job['source'],'exit':r.returncode,'seconds':time.monotonic()-t}
 (out/'process.json').write_text(json.dumps(result,indent=2)+'\n')
 results.append(result)
 (D/'compile-summary.json').write_text(json.dumps({'status':'RUNNING' if r.returncode==0 else 'FAILED','results':results,'SDK_builds':0,'model_runs':0,'HTTP':0},indent=2)+'\n')
 print(json.dumps(result),flush=True)
 if r.returncode:
  print((out/'stderr.log').read_text(errors='replace')[-12000:],flush=True)
  sys.exit(r.returncode)
for x in p['source_pins']:
 f=D/'source'/x['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'],f
(D/'compile-summary.json').write_text(json.dumps({'status':'PASS_11_STRICT_TUS_COMPILE_ONLY','results':results,'SDK_builds':0,'model_runs':0,'HTTP':0,'source_pins_unchanged':True},indent=2)+'\n')

