from pathlib import Path
import json
D=Path('/Users/kiro/hyle-scratch/compute-unified')
names=['batch_layout.cc','batch.cc','native_batch_regions.cc','native_paged_node.cc','paged_append.cc','native_batch.cc','apple_context.cc','apple_batch.cc','apple_materialized_invocation.cc','native_paged_region.cc','native_ragged_region.cc']
out={'recipes':[]}
for base in [D/'qwen-k1-functional-20261024/attempt1',D/'qwen-cpu-apple-functional-20261024/attempt1',D/'qwen-multik-functional-20261024/attempt1']:
    plan=base/'plan.json'
    if plan.exists():
        obj=json.loads(plan.read_text())
        for job in obj.get('jobs',[]):
            cmd=job.get('command',[])
            if any(Path(x).name in names for x in cmd if isinstance(x,str)):
                out['recipes'].append({'plan':str(plan),'job':job})
B=D/'qwen-cpu-apple-functional-20261024/attempt1'
out['cpuapple_files']=[p.name for p in sorted(B.iterdir())]
A=D/'architecture-refactor-20261019-apple-page-invocation'
for name in ['src--compute_route_apple--apple_context.o.json','src--compute_route_apple--apple_batch.o.json','src--graph_route_apple--native_paged_region.o.json']:
    p=A/name
    if p.exists():out[name]={'path':str(p),'record':json.loads(p.read_text())}
out['gdn_bridge']=[p.name for p in sorted((A/'gdn-graph-bridge-20261024/attempt1').iterdir())] if (A/'gdn-graph-bridge-20261024/attempt1').is_dir() else None
print(json.dumps(out,indent=2))

