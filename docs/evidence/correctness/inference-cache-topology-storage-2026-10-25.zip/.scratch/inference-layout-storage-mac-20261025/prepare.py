from pathlib import Path, PurePosixPath
import json,re,hashlib,tarfile
R=Path(__file__).resolve().parents[2]
B=Path(__file__).resolve().parent
D='/Users/kiro/hyle/.scratch/inference-layout-storage-20261025'
names=[
 'src/compute_batch/batch_layout.cc',
 'src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc',
 'src/graph_batch/native_paged_node.cc','src/graph_batch/paged_append.cc',
 'src/compute_provider_ggml/native_batch.cc',
 'src/compute_route_apple/apple_context.cc','src/compute_route_apple/apple_batch.cc',
 'src/compute_route_apple/apple_materialized_invocation.cc',
 'src/graph_route_apple/native_paged_region.cc','src/graph_route_apple/native_ragged_region.cc']
records=json.loads((B/'selected-recipes.json').read_text())
chosen={}
for name in names:
 matches=[x for x in records if any(str(w).endswith('/source/'+name) for w in x['command'])]
 assert matches,name
 # Latest qwen CPU/Apple overrides for shared Graph; the complete Apple recipe
 # contains the original source-specific vendor and Objective-C++ settings.
 chosen[name]=matches[-1]
jobs=[]
roots=set()
for x in chosen.values():
 for w in x['command']:
  if isinstance(w,str) and w.startswith('-I') and '/source/' in w:
   roots.add(w[2:].split('/source/',1)[0]+'/source')
for name,x in chosen.items():
 old=x['command'];out=[];skip=False
 for i,w in enumerate(old):
  if skip:skip=False;continue
  if w in ['-o','-MF']:skip=True;continue
  if w=='-c' or str(w).endswith('/source/'+name):continue
  for origin in sorted(roots,key=len,reverse=True):
   if isinstance(w,str) and w.startswith('-I'+origin+'/'):
    w='-I'+D+'/source/'+w[len('-I'+origin+'/'):]
    break
  out.append(w)
 out[1:1]=['-I'+D+'/source/include','-I'+D+'/source']
 if '-Werror' not in out:out.append('-Werror')
 tag=name.replace('/','--')
 out += ['-MMD','-MF',D+'/compile/'+tag+'/unit.d','-c',D+'/source/'+name,'-o',D+'/compile/'+tag+'/unit.o']
 jobs.append({'source':name,'tag':tag,'command':out,'original_recipe':x['origin']})
# Quoted Hyle dependency closure only; third-party headers stay cached on Mac.
seen=set();pending=[R/n for n in names]
while pending:
 p=pending.pop().resolve()
 if p in seen:continue
 seen.add(p)
 data=p.read_text(encoding='utf-8-sig',errors='strict')
 for spelling in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',data,re.M):
  candidates=[p.parent/spelling,R/'include'/spelling,R/spelling]
  for q in candidates:
   q=q.resolve()
   if q.is_file() and q.is_relative_to(R):
    if q not in seen:pending.append(q)
    break
pins=[]
source=B/'source'
for p in sorted(seen):
 rel=p.relative_to(R);target=source/rel;target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(p.read_bytes())
 pins.append({'path':rel.as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
plan={'scope':'11 affected Hyle core/Graph/Apple TUs strict compile first, no SDK/provider third-party or model rebuild; runtime only after explicit closure check',
      'remote':D,'jobs':jobs,'source_pins':pins,'baseline_link':json.loads((B/'audit.json').read_text())['baseline_link']}
(B/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(B/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
with tarfile.open(B/'source.tar.gz','w:gz') as z:
 for p in sorted(source.rglob('*')):
  if p.is_file():z.add(p,arcname='source/'+p.relative_to(source).as_posix())
 z.add(B/'plan.json',arcname='plan.json')
 z.add(B/'source-pins.json',arcname='source-pins.json')
print(json.dumps({'TUs':len(jobs),'files':len(pins),'source_bytes':sum(p['bytes'] for p in pins),'archive_bytes':(B/'source.tar.gz').stat().st_size}))

