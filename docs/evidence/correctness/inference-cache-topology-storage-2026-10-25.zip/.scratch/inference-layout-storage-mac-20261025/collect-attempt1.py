from pathlib import Path
import json,hashlib,shlex,tarfile
D=Path(__file__).resolve().parent
p=json.loads((D/'plan.json').read_text())
cp=json.loads((D/'consumer-plan.json').read_text())
pins=json.loads((D/'source-pins2.json').read_text())+cp['source_added']
expected={x['path']:x for x in pins}
def pin(x):
 d=x.read_bytes();return {'path':str(x),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def deps(folder):
 f=folder/'unit.d'
 text=f.read_text().replace('\\\n',' ')
 paths=shlex.split(text.split(':',1)[1])
 rows=[];cached_hyle=[]
 for s in paths:
  x=Path(s)
  if not x.is_absolute():x=(D/x).resolve()
  if not x.is_file():continue
  record=pin(x)
  if x.is_relative_to(D/'source'):
   rel=x.relative_to(D/'source').as_posix()
   assert rel in expected and record['sha256']==expected[rel]['sha256'],rel
   record['relative']=rel;record['kind']='current_overlay'
  elif '/source/include/hyle/' in str(x) or '/source/src/' in str(x):
   record['kind']='cached_hyle';cached_hyle.append(str(x))
  else:record['kind']='cached_external'
  rows.append(record)
 (folder/'actual-dependencies.json').write_text(json.dumps({'rows':rows,'cached_hyle_leaks':cached_hyle},indent=2)+'\n')
 return {'directory':str(folder),'dependencies':len(rows),'current_overlay':sum(x['kind']=='current_overlay' for x in rows),'cached_hyle_leaks':cached_hyle}
used=[]
summary=json.loads((D/'compile-summary3.json').read_text())
for i,j in enumerate(p['jobs']):
 name='compile' if i<2 else 'compile2' if i<5 else 'compile3'
 used.append(deps(D/name/j['tag']))
used.append(deps(D/'consumer'))
assert not any(x['cached_hyle_leaks'] for x in used),used
for rel,x in expected.items():assert hashlib.sha256((D/'source'/rel).read_bytes()).hexdigest()==x['sha256'],rel
(D/'actual-dependency-summary.json').write_text(json.dumps({'status':'PASS_ACTUAL_SOURCE_PINS','TUs':used,'source_pins_unchanged':True,'cached_hyle_leaks':0},indent=2)+'\n')
s=json.loads((D/'summary.json').read_text())
s['product_compile']=summary
s['actual_dependency_summary']='actual-dependency-summary.json'
s['source_pins_unchanged']=True
s['first_failures']=[
 {'kind':'private dependency-generation recipe conflict','directory':'compile/src--graph_batch--native_batch_regions.cc','note':'Old -MD plus appended -MMD caused strict unused-command-line-argument; no product syntax reached.'},
 {'kind':'private source-sync omission','directory':'compile2/src--compute_provider_ggml--native_batch.cc','note':'provider_internal.h omitted from lexical include sync; only five actual own headers added, no product/SDK change.'}]
(D/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
maptext=(D/'paged-e4.map').read_text()
section=maptext.split('# Object files:',1)[1].split('# Sections:',1)[0]
(D/'selected-archive-members.txt').write_text(section)
binaries=[D/'paged-e4']+[D/('compile' if i<2 else 'compile2' if i<5 else 'compile3')/j['tag']/'unit.o' for i,j in enumerate(p['jobs'])]+[D/'consumer/unit.o']
(D/'cleanup-candidates.json').write_text(json.dumps({'scope':'Exact newly built Mac binaries only; not executed','count':len(binaries),'logical_bytes':sum(f.stat().st_size for f in binaries),'files':[pin(f) for f in binaries]},indent=2)+'\n')
with tarfile.open(D/'metadata.tar.gz','w:gz') as z:
 for f in sorted(D.rglob('*')):
  if not f.is_file() or f.is_relative_to(D/'source'):continue
  rel=f.relative_to(D)
  if f.suffix in ['.o','.gz'] or f.name in ['paged-e4','paged-e4.map']:continue
  z.add(f,arcname=rel.as_posix())
print(json.dumps({'status':s['status'],'dependency_TUs':len(used),'cached_hyle_leaks':0,'metadata_archive_bytes':(D/'metadata.tar.gz').stat().st_size,'cleanup_files':len(binaries),'cleanup_logical_bytes':sum(f.stat().st_size for f in binaries)}))

