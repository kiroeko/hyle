from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import discover_environment

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def identity(path):
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def is_project(path):
    try: rel=path.resolve().relative_to(ROOT)
    except ValueError:return False
    return bool(rel.parts) and rel.parts[0] in {'include','src','engine','tests'}
def command(path):
    value=read(path)
    return value['command'] if isinstance(value,dict) else value
def includes(args):
    result=[]
    for word in args:
        lower=word.lower()
        for prefix in ('/external:i','-external:i','/i','-i'):
            if lower.startswith(prefix):result.append(Path(word[len(prefix):]));break
    return result

def main():
    attempt=WORK/(sys.argv[1] if len(sys.argv)>1 else 'host1')
    assert not attempt.exists() or not list(attempt.glob('*/running.json')),'Preserve prior compiler raw; select a fresh attempt name'
    cuda=ROOT/'.scratch/mtp-performance-convergence-20261025/current-cuda/product-0/command.json'
    vk=ROOT/'.scratch/vulkan-retained-paged-20261022/compile1'
    jobs=[
        ('flashinfer','src/compute_provider_flashinfer/flashinfer_provider.cc',cuda),
        ('vk-batch','src/compute_route_vulkan/vulkan_batch.cc',vk/'page/compile.command.json'),
        ('vk-program','src/compute_route_vulkan/vulkan_program.cc',vk/'program/compile.command.json'),
        ('vk-paged','src/graph_route_vulkan/native_paged_region.cc',vk/'page/compile.command.json'),
        ('vk-ragged','src/graph_route_vulkan/native_ragged_region.cc',vk/'ragged/compile.command.json'),
        ('vk-materialized','src/compute_route_vulkan/vulkan_materialized_invocation.cc',vk/'page/compile.command.json')]
    expected={}
    for p in read(ROOT/'.scratch/inference-layout-storage-core-20261025/source-pins.json')['files']:
        expected[p['path']]=p['after_sha256']
    for p in read(ROOT/'.scratch/inference-layout-storage-routes-20261025/source-pins.json')['files']:
        expected[p['path']]=p['after']['sha256']
    changed=[]
    for name,sha in expected.items():
        pin=identity(ROOT/name)
        assert pin['sha256']==sha,('Canonical source differs from reviewed A/B pins',name,pin['sha256'],sha)
        changed.append(dict(relative=name,**pin))
    save(attempt/'source-pins.json',changed)
    tree=attempt/'source';queue=[x[1] for x in jobs];seen=set();frozen=[]
    search_dirs=[ROOT/'include',ROOT,ROOT/'src/compute',ROOT/'src/compute_backend_cuda']
    for _,_,recipe in jobs:search_dirs.extend(includes(command(recipe)))
    while queue:
        name=queue.pop()
        if name in seen:continue
        seen.add(name);path=ROOT/name;data=path.read_bytes();dest=tree/name
        dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        frozen.append(dict(relative=name,original=identity(path),frozen=identity(dest)))
        for include in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]',data.decode('utf-8-sig'),re.M):
            for directory in [path.parent,*search_dirs]:
                candidate=(directory/include).resolve()
                if candidate.is_file():
                    if is_project(candidate):queue.append(candidate.relative_to(ROOT).as_posix())
                    break
    assert 'include/hyle/compute/batch_layout.h' in seen
    assert 'include/hyle/compute/detail/materialized_native_controller.h' in seen
    save(attempt/'frozen-project.json',frozen)
    compiler=command(cuda)[0]
    env=discover_environment(compiler='msvc',cache=dict(CMAKE_C_COMPILER=compiler,CMAKE_CXX_COMPILER=compiler,CMAKE_GENERATOR='Ninja'),backends=()).env
    plans=[]
    for tag,name,recipe in jobs:
        old=command(recipe);flags=[];skip=False
        for word in old[1:]:
            if skip:skip=False;continue
            if word=='/sourceDependencies':skip=True;continue
            if word.lower().startswith(('/fo','/fd')) or word.lower().endswith(('.cc','.cpp')):continue
            directories=includes([word])
            if directories and is_project(directories[0]):
                flags.append('/I'+str(tree/directories[0].resolve().relative_to(ROOT)))
            else:flags.append(word)
        flags=['/I'+str(tree/'include'),'/I'+str(tree),'/I'+str(tree/'src/compute'),
            '/I'+str(tree/'src/compute_backend_cuda'),'/I'+str(tree/Path(name).parent),*flags]
        assert '/W4' in flags and '/WX' in flags
        output=attempt/tag
        argv=[compiler,*flags,str(tree/name),'/sourceDependencies',str(output/'dependencies.json'),
            '/Fo'+str(output/'unit.obj'),'/Fd'+str(output/'unit.pdb')]
        plans.append(dict(tag=tag,source=name,recipe=identity(recipe),command=argv,timeout_seconds=180))
    sdk=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include')
    vk_headers=Path('C:/public/tools/hyle-dependencies/v1/sources/vulkan_headers-e3b1eec08173-69d6adc9001f/include')
    for path in [Path(compiler),sdk/'cuda.h',sdk/'cuda_runtime_api.h',vk_headers/'vulkan/vulkan.h']:assert path.is_file(),path
    save(attempt/'plan.json',dict(status='AUTHORIZED_SIX_STRICT_HOST_TUS_ONLY',max_workers=2,jobs=plans,
        toolchain=dict(compiler=identity(Path(compiler)),cuda_header=identity(sdk/'cuda.h'),vulkan_header=identity(vk_headers/'vulkan/vulkan.h')),
        extra_header_consumer='vulkan_materialized_invocation.cc directly instantiates changed materialized_native_controller.h',
        GPU=False,links=0,runs=0,SDK_copied_or_rebuilt=False))
    print('FROZEN',len(frozen),'project files',sum(x['frozen']['bytes'] for x in frozen),'bytes;',len(changed),'reviewed A/B pins; 6 TU max2workers',flush=True)

    def compile_one(plan):
        output=attempt/plan['tag'];output.mkdir(parents=True,exist_ok=False)
        save(output/'command.json',dict(command=plan['command'],cwd=str(ROOT),timeout_seconds=plan['timeout_seconds']))
        start=time.monotonic()
        with (output/'stdout.log').open('wb') as stdout,(output/'stderr.log').open('wb') as stderr:
            process=subprocess.Popen(plan['command'],cwd=ROOT,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
            save(output/'running.json',dict(pid=process.pid));print('START',plan['tag'],process.pid,flush=True)
            try:code=process.wait(timeout=plan['timeout_seconds'])
            except subprocess.TimeoutExpired:process.kill();process.wait();code=-999
        result=dict(tag=plan['tag'],source=plan['source'],pid=process.pid,exit=code,seconds=time.monotonic()-start)
        save(output/'process.json',result);print('END',plan['tag'],code,round(result['seconds'],3),flush=True)
        if code:
            print((output/'stdout.log').read_text(encoding='utf-8',errors='replace')[-10000:],flush=True)
            print((output/'stderr.log').read_text(encoding='utf-8',errors='replace')[-3000:],flush=True)
            return result
        data=read(output/'dependencies.json')['Data'];paths=[Path(x) for x in dict.fromkeys([data['Source'],*data['Includes']])]
        assert not any(is_project(p) for p in paths),'Unfrozen canonical project header was consumed'
        resolved={str(p.resolve()).casefold() for p in paths}
        assert str((tree/plan['source']).resolve()).casefold() in resolved
        assert str((tree/'include/hyle/compute/batch_layout.h').resolve()).casefold() in resolved
        if plan['tag']=='vk-materialized':assert str((tree/'include/hyle/compute/detail/materialized_native_controller.h').resolve()).casefold() in resolved
        deps=[identity(p) for p in paths];save(output/'actual-dependencies.json',deps)
        result['actual_dependencies']=len(deps);result['object']=identity(output/'unit.obj');return result
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(compile_one,plans))
    for pin in changed:assert identity(ROOT/pin['relative'])['sha256']==pin['sha256'],pin['relative']
    for row in frozen:assert identity(Path(row['frozen']['path']))==row['frozen']
    result=dict(status='PASS_STRICT_SIX_HOST_TUS' if all(x['exit']==0 for x in results) else 'FAIL_STRICT_HOST_COMPILE',
        results=results,source_pins=changed,frozen_project_files=len(frozen),max_workers=2,
        SDK_rebuilds=0,core_rebuilds=0,links=0,runs=0,GPU=False,HTTP=0,
        boundaries=['Host compile only, not backend link/runtime/native arithmetic/performance validation.',
            'No Vulkan shader or CUDA device TU was rebuilt or executed.',
            'No new engine, model consumer or GPU throughput experiment.'])
    save(attempt/'summary.json',result)
    if any(x['exit'] for x in results):raise SystemExit(1)

if __name__=='__main__':main()
