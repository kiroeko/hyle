from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from hyle_environment import discover_environment
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def pin(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def execute(args,env,folder,timeout=120):
    folder.mkdir(parents=True,exist_ok=False)
    save(folder/'command.json',dict(command=args,cwd=str(ROOT),timeout_seconds=timeout))
    start=time.monotonic()
    with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
        proc=subprocess.Popen(args,cwd=ROOT,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        print('START',folder.name,proc.pid,flush=True)
        try:code=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:proc.kill();proc.wait();code=-999
    result=dict(exit=code,seconds=time.monotonic()-start,pid=proc.pid)
    save(folder/'process.json',result);print('END',folder.name,json.dumps(result),flush=True)
    if code:
        print((folder/'stdout.log').read_text(errors='replace')[-10000:],flush=True)
        print((folder/'stderr.log').read_text(errors='replace')[-4000:],flush=True)
        raise RuntimeError(str(folder))
    return result
def main():
    attempt=WORK/sys.argv[1];assert not attempt.exists()
    pins=read(WORK/'integrated-pins.json')
    for d in pins['files']:assert pin(ROOT/d['path'])['sha256']==d['after'],d['path']
    link_base=ROOT/'.scratch/inference-assembly-placement-20261025/consumer1/link'
    inputs=read(link_base/'inputs.json');basecmd=read(link_base/'command.json')['command']
    for d in inputs['unchanged_common_inputs']+[inputs['app']]:assert pin(Path(d['path']))==d,d['path']
    layout_recipe=read(ROOT/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt2/layout/command.json')['command']
    compiler=layout_recipe[0]
    env=discover_environment(compiler='msvc',cache=dict(CMAKE_C_COMPILER=compiler,CMAKE_CXX_COMPILER=compiler,CMAKE_GENERATOR='Ninja'),backends=()).env
    host=read(ROOT/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host-commands.json')['jobs']
    host={Path(d['source']['path']).resolve():d['command'] for d in host}
    names=['src/compute_batch/batch_layout.cc','src/compute_provider_ggml/native_batch.cc',
        'src/graph_batch/batch.cc','src/graph_batch/native_batch_regions.cc',
        'src/graph_batch/native_paged_node.cc','src/graph_batch/paged_append.cc',
        'tests/compute_batch/batch_layout_test.cc','tests/graph_batch/typed_capability_graph_test.cc']
    compiled=[]
    def job(name):
        source=ROOT/name;label=source.parent.name+'--'+source.stem
        recipe=host.get(source.resolve(),layout_recipe)
        flags=[];skip=False
        for arg in recipe[1:]:
            if skip:skip=False;continue
            if arg=='/sourceDependencies':skip=True;continue
            if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
            flags.append(arg)
        if name=='src/compute_provider_ggml/native_batch.cc':
            flags=[x for x in flags if not x.startswith('/DHYLE_GGML_CPU_PROVIDER_VERSION=')]
            flags += ['/DHYLE_GGML_CPU_PROVIDER_VERSION="ffa4e8b8-current-pure-cpu-closure"']
        folder=attempt/'compile'/label;obj=folder/'unit.obj'
        args=[compiler,*flags,str(source),'/sourceDependencies',str(folder/'dependencies.json'),'/Fo'+str(obj),'/Fd'+str(folder/'unit.pdb')]
        result=execute(args,env,folder)
        dependencies=read(folder/'dependencies.json')['Data']
        deps=[Path(x) for x in dict.fromkeys([dependencies['Source'],*dependencies['Includes']])]
        save(folder/'actual-dependencies.json',[pin(p) for p in deps])
        assert (ROOT/'include/hyle/compute/batch_layout.h').resolve() in [p.resolve() for p in deps]
        return dict(source=pin(source),object=pin(obj),result=result,dependencies=len(deps),name=name)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(job,n) for n in names]
        for future in futures:compiled.append(future.result())
    replacements={}
    byname={d['name']:d for d in compiled}
    for old in inputs['unchanged_common_inputs']:
        p=Path(old['path']);data=p.read_bytes()
        if b'?schema@BatchLayoutVersion@' not in data:continue
        if p.name=='layout.obj':name=names[0]
        elif p.name=='native_batch.cc.obj':name=names[1]
        else:
            name='src/graph_batch/'+p.stem.split('--',1)[1]+'.cc'
        replacements[str(p)]=byname[name]['object']['path']
    assert len(replacements)==6,replacements
    save(attempt/'compiled.json',compiled);save(attempt/'replacements.json',replacements)
    common=[]
    for arg in basecmd:
        if arg.lower().startswith(('/out:','/pdb:','/implib:','/map:')) or arg==inputs['app']['path']:continue
        common.append(replacements.get(arg,arg))
    assert not any(b'?schema@BatchLayoutVersion@' in Path(a).read_bytes() for a in common[1:] if Path(a).is_absolute() and Path(a).suffix=='.obj')
    testargs=common+[byname[n]['object']['path'] for n in names[-2:]]
    testargs += [str(ROOT/'.scratch/build-compute-v2-dev/lib/gtest_main.lib'),str(ROOT/'.scratch/build-compute-v2-dev/lib/gtest.lib')]
    image=attempt/'test-link/component.exe'
    testlink=execute(testargs+['/OUT:'+str(image),'/PDB:'+str(image.with_suffix('.pdb'))],env,image.parent)
    native=Path(inputs['native_original']['path']);os.link(native,image.parent/native.name)
    runtime=read(ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')
    runenv=dict(env);runenv['PATH']=str(image.parent)+';'+runtime['PATH']
    runenv['HF_HUB_OFFLINE']=runenv['TRANSFORMERS_OFFLINE']='1'
    testrun=execute([str(image),'--gtest_filter=BatchLayout.*:TypedCapabilityGraph.*','--gtest_output=xml:'+str(attempt/'test-result.xml')],runenv,attempt/'test-run')
    ordinary=attempt/'ordinary-link/component.exe'
    ordinarylink=execute(common+[inputs['app']['path'],'/OUT:'+str(ordinary),'/PDB:'+str(ordinary.with_suffix('.pdb'))],env,ordinary.parent)
    os.link(native,ordinary.parent/native.name);runenv['PATH']=str(ordinary.parent)+';'+runtime['PATH']
    fixture=ROOT/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
    ordinaryrun=execute([str(ordinary),str(fixture)],runenv,attempt/'ordinary-run')
    for d in pins['files']:assert pin(ROOT/d['path'])['sha256']==d['after'],d['path']
    save(attempt/'summary.json',dict(status='PASS',sources=pins,compiled=compiled,test_link=testlink,test_run=testrun,
        ordinary_link=ordinarylink,ordinary_run=ordinaryrun,reused_ordinary_app=inputs['app'],native=inputs['native_original'],
        replaced_core_graph_provider_objects=len(replacements),unchanged_common_objects=len(inputs['unchanged_common_inputs'])-len(replacements),
        SDK_TUs=0,CUDA=False,Vulkan=False,Apple=False,HTTP=0,performance=False))
    print('CPU_FINITE_PASS',flush=True)
if __name__=='__main__':main()
