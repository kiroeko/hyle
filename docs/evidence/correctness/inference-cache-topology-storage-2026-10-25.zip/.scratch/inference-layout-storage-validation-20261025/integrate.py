from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
def sha(data): return hashlib.sha256(data).hexdigest()
changes = []
for name, folder, keys in [
    ('inference-layout-storage-core-20261025', 'source', ('before_sha256', 'after_sha256')),
    ('inference-layout-storage-routes-20261025', 'after/source', ('before', 'after')),
]:
    base = ROOT / '.scratch' / name
    pins = json.loads((base / 'source-pins.json').read_text())
    for pin in pins['files']:
        old, new = (pin[k] for k in keys)
        if isinstance(old, dict): old, new = old['sha256'], new['sha256']
        path = ROOT / pin['path']
        body = (base / folder / pin['path']).read_bytes()
        assert sha(path.read_bytes()) == old, pin['path']
        assert sha(body) == new, pin['path']
        changes.append((path, body, dict(path=pin['path'], before=old, after=new, bytes=len(body))))
assert len(changes) == 28 and len({p for p, _, _ in changes}) == 28
assert not (WORK / 'integrated-pins.json').exists()
for path, body, pin in changes:
    path.write_bytes(body)
    assert sha(path.read_bytes()) == pin['after']
(WORK / 'integrated-pins.json').write_text(json.dumps(dict(files=[pin for _, _, pin in changes]), indent=2)+'\n')
print('INTEGRATED', len(changes))
