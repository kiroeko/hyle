import shutil
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-aten-compilation-storage/baseline';out.mkdir(parents=True,exist_ok=True)
records=[]
compiler=shutil.which('cl',path=env.get('Path',env.get('PATH','')));assert compiler
exe=build/'bin/cpu_compilation_budget_baseline.exe'
libs=['graph_route_cpu','graph_provider_onednn','graph','compute_route_cpu','compute_provider_ggml','compute_provider_onednn','compute_provider_native','compute_backend_cpu','compute','compute_ops','mem','platform','error']
run('compile-real-ordinary-counterexample',[compiler,'/nologo','/std:c++latest','/Zc:__cplusplus','/Zc:preprocessor','/utf-8','/EHsc','/O2','/MD','/I'+str(repo/'include'),str(out.parent/'consumer.cc'),'/Fo'+str(out/'consumer.obj'),'/Fe'+str(exe)]+[str(build/('bin/hyle_'+lib+'.lib')) for lib in libs])
# Expected refusal of the qualified mature carrier is recorded, not PASS.
start=time.monotonic()
with (out/'baseline.log').open('wb') as log:r=subprocess.run([exe],env=env,stdout=log,stderr=subprocess.STDOUT,**flags)
assert r.returncode==5,r.returncode
records.append({'name':'strict-compilation-budget-wrong-carrier-counterexample','returncode':r.returncode,'expected_counterexample_returncode':5,'seconds':round(time.monotonic()-start,3),'product_baseline':'e6a34210731f7d0e957f5470eab8e0a3988029c8'})
(out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
print(records[-1],flush=True)
