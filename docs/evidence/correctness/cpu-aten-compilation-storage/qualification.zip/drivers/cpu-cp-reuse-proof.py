from pathlib import Path
import hashlib,json,subprocess
repo=Path(__file__).resolve().parents[1]
fixture=repo/'.scratch/validation/cpu-aten-compilation-storage'
source='src/compute_provider_native/aten_cpu_provider.cc'
old=subprocess.check_output(['git','show','e6a34210:'+source],cwd=repo).decode('utf-8')
new=(repo/source).read_text(encoding='utf-8')
sections={
 'program-layout-and-all-math-execution-invocation-mapping-lifecycle':lambda s:s.split('Status propose(')[0],
 'cold-prepare-and-artifact-storage':lambda s:s.split('ProviderPrepareOutcome prepare(')[1].split('const detail::ProviderVTable kProviderVTable')[0],
 'sdk-off-stub':lambda s:s.rsplit('#else',1)[1],
}
proof={'baseline':'e6a34210731f7d0e957f5470eab8e0a3988029c8','reuse_source':'evidence/correctness/cpu-aten-scatter-add/receipt.json','sections':{},'unchanged_inputs':[],'reuse_scope':'Existing AS math/lifecycle/D5/SDK-off/header contract only; new cold cost facts, budget selection and rebuilt C++ deliveries require current actual qualification.'}
for name,extract in sections.items():
    before,after=extract(old),extract(new)
    assert before==after,name
    proof['sections'][name]=hashlib.sha256(after.encode()).hexdigest()
manifest=json.loads((repo/'.scratch/validation/cpu-aten-scatter-add/manifest.json').read_text())
for name,digest in manifest['files'].items():
    if name==source or name=='tests/compute_provider_native/provider_shape_test.cc' or name.startswith('.scratch/'):continue
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
    proof['unchanged_inputs'].append(name)
(fixture/'reuse-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'protected_source_sections':len(sections),'unchanged_inputs':len(proof['unchanged_inputs'])}))
