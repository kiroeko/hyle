import sys
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-aten-compilation-storage'
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
candidate='a527dd73dcc21a5b4b89979d43339d67becabe86'
paths=json.loads((repo/'.scratch/validation/cpu-aten-scatter-add/loc.json').read_text())['module']['paths']
args=[sys.executable,'-X','utf8',repo/'scripts/loc-report.py','--commit',candidate,'--module','compute-graph','--json']
for path in paths:args.extend(['--module-path',path])
run('unified-implementation-loc',args)
(out/'loc.json').write_bytes((out/records[-1]['log']).read_bytes())
(out/'tool-receipt.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
metric=next(row for row in json.loads((out/'loc.json').read_text())['metrics'] if row['id']=='module')
print(json.dumps(metric),flush=True)
