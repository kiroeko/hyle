from pathlib import Path
import hashlib,json,subprocess
repo=Path(__file__).resolve().parents[1]
old=repo/'.scratch/validation/cpu-aten-scatter-add'
out=repo/'.scratch/validation/cpu-aten-compilation-storage'
out.mkdir(parents=True,exist_ok=True)
def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists() or path.read_bytes()!=data:path.write_bytes(data)
consumer=(old/'consumer.cc').read_text(encoding='utf-8')
consumer=consumer.replace('auto compiled = take(g::compile(logical, gc));','''g::CompileOptions options{};
  options.compilation_storage = g::CompilationStorageLimits{
      .max_resident_bytes = 64 << 20, .max_peak_bytes = 64 << 20};
  auto compiled = take(g::compile(logical, gc, options));
  if (compiled.report.compilation_storage()->has_unknown_storage)
    std::exit(7);
  auto too_small = options;
  too_small.compilation_storage->max_resident_bytes = 0;
  too_small.compilation_storage->max_peak_bytes = 0;
  auto denied = g::compile(logical, gc, too_small);
  if (denied || !denied.error().IsResourceExhausted()) std::exit(8);
  auto invocation_limit = options;
  invocation_limit.invocation_storage = g::InvocationStorageLimits{.max_bytes = 1 << 20};
  const std::array allowed{c::aten_cpu::kProviderId};
  invocation_limit.allowed_providers = allowed;
  auto restricted = g::compile(logical, gc, invocation_limit);
  if (restricted) {
    auto lane = restricted->executable.create_invocation();
    if (lane) std::exit(9);
  }
  auto prepared_only = options;
  prepared_only.allowed_providers = allowed;
  prepared_only.provider_replay = g::ProviderReplayPolicy::kRequirePrepared;
  if (g::compile(logical, gc, prepared_only)) std::exit(10);''')
consumer=consumer.replace('PASS ordinary mature CPU ScatterAdd Direct/Graph duplicate multi-axis/odd-stride/scalar/empty/changed inputs/close','PASS ordinary mature CPU strict compilation-budget Graph/Direct results/replay/close; zero metadata budget rejected; invocation-private unknown and managed replay retained')
write(out/'consumer.cc',consumer.encode())
write(out/'consumer/CMakeLists.txt',(old/'consumer/CMakeLists.txt').read_bytes())
for platform in ('windows','linux'):
    text=(old/(platform+'-overlay.cmake')).read_text(encoding='utf-8').replace('cpu-aten-scatter-add','cpu-aten-compilation-storage')
    write(out/(platform+'-overlay.cmake'),text.encode())
previous=json.loads((old/'manifest.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
manifest={'candidate':head,'fixture_commit':head,'files':{}}
for name in previous['files']:
    if name.startswith('.scratch/validation/cpu-aten-scatter-add/'):continue
    manifest['files'][name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
for name in ('consumer.cc','consumer/CMakeLists.txt','windows-overlay.cmake','linux-overlay.cmake'):
    manifest['files'][(out/name).relative_to(repo).as_posix()]=hashlib.sha256((out/name).read_bytes()).hexdigest()
write(out/'manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())
for platform in ('windows','linux'):
    text=(repo/('.scratch/cpu-as-'+platform+'.py')).read_text(encoding='utf-8').replace('cpu-aten-scatter-add','cpu-aten-compilation-storage').replace('cpu-as-','cpu-cp-').replace("+'-as-consumer'","+'-cp-consumer'")
    text=text.replace('CpuDefaultGraph.*:CpuGraph.*','CpuGraph.*:CpuDefaultGraph.*-CpuDefaultGraph.D5*')
    write(repo/('.scratch/cpu-cp-'+platform+'.py'),text.encode())
print(json.dumps({'candidate':head,'inputs':len(manifest['files'])}))
