include("${CMAKE_CURRENT_LIST_DIR}/../../../cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(sglang_activation)
message(STATUS "grouped FP8 dependency identity audit passed")
