"""Three host TUs; exact cached CUDA/control/neighbor134 and Qwen125 links."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
ARCH = STAGE.parent
ROOT = ARCH.parents[1]
BASE = ARCH / 'cuda-grouped-fusion/checks/20261019T123025'
PROVIDER_RECIPE = ARCH / 'recurrent-gdn-schema/checks/20261019T113131/14-compute_provider_cuda-grouped_fp8_provider-identity.json'
TEST_RECIPE = BASE / 'stable-test-final-compile.command.json'
spec = importlib.util.spec_from_file_location('grouped_slots_cached_build', ARCH / 'cuda-grouped-fusion/build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, c = prior.b, prior.c


def check(plan):
    for row in plan['frozen']:
        if not b.same(row):
            raise ValueError('Frozen source/header/recipe differs: ' + row['path'])


def check_cached(plan):
    for row in plan['cached_inputs']:
        if not b.same(row):
            raise ValueError('Retained linked input differs: ' + row['path'])


def inputs(command):
    return [x for x in command if Path(x).is_absolute() and
            Path(x).suffix.lower() in ('.obj', '.lib')]


def counts(path):
    tree = ET.parse(path).getroot()
    result = {k: int(tree.attrib.get(k, '0')) for k in ('tests', 'failures', 'errors', 'disabled')}
    result['skipped'] = sum(int(x.attrib.get('skipped', '0')) for x in tree.findall('testsuite'))
    return result


def run(plan, out):
    check(plan)
    results = {}
    for tag, selected, expected in (
        ('control', 'CudaGroupedFp8.*', (3, 3)),
        ('cuda', 'CudaGroupedFp8.*', (3, 0)),
        ('neighbor', 'SglangFp8.GroupedColdDomainAndActivationAlignment:SglangFp8.GroupedWorkspaceOomConcurrencyCompletionAndInvalidIds', (2, 0)),
    ):
        link = plan['links'][tag]
        env, directories = b.environment(link['command'], link['inputs'], out)
        c.save(out / (tag + '-runtime.json'), {'link_input_paths': link['inputs'],
            'runtime_library_directories': directories, 'CPU_CUDA_cached_input_union_used': False})
        command = [link['image'], '--gtest_color=no', '--gtest_filter=' + selected,
                   '--gtest_output=xml:' + str(out / (tag + '-tests.xml'))]
        try:
            c.execute(tag + '-tests', command, env, out)
        except RuntimeError:
            if tag != 'control':
                raise
        actual = counts(out / (tag + '-tests.xml'))
        wanted = dict(tests=expected[0], failures=expected[1], errors=0, disabled=0, skipped=0)
        c.save(out / (tag + '-counts.json'), actual)
        if actual != wanted:
            raise ValueError('Unexpected exact test result for ' + tag + ': ' + str(actual))
        results[tag] = actual
    check(plan)
    c.save(out / 'test-summary.json', {'passed': True, 'results': results,
        'control': 'Same new test object, all old production owners; fixed-top8 admission control.',
        'coverage': '7 selected Direct/Graph shapes plus two-dtype checked-ID recovery; existing S8 workspace/concurrency and cold-domain tests.',
        'full_model_run': False, 'throughput_claim': False, 'native_CUDA_recompiled': False})
    print('TESTS_COMPLETE', results, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run and not args.build:
        parser.error('--run requires --build')
    out = HERE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    applied = c.read(STAGE / 'application.json')
    frozen_paths = [Path(__file__), Path(b.__file__), Path(c.__file__),
        ARCH / 'cuda-grouped-fusion/build.py', PROVIDER_RECIPE, TEST_RECIPE,
        STAGE / 'application.json', ROOT / 'tests/compute_provider_cuda/CMakeLists.txt']
    for row in applied['files']:
        path = ROOT / row['path']
        actual = b.identity(path)
        if (actual['bytes'], actual['sha256']) != (row['after']['bytes'], row['after']['sha256']):
            raise ValueError('Applied product differs: ' + row['path'])
        frozen_paths.append(path)
    recipe = c.read(PROVIDER_RECIPE)
    old_provider = recipe['object']
    test_template = c.read(TEST_RECIPE)['command']
    sources = (
        ('grouped-provider', ROOT / 'src/compute_provider_cuda/grouped_fp8_provider.cc', recipe['command']),
        ('grouped-test', ROOT / 'tests/compute_provider_cuda/grouped_fp8_test.cc', test_template),
        ('legacy-test', ROOT / 'tests/compute_provider_cuda/cuda_provider_test.cc', test_template),
    )
    rows = []
    for tag, source, template in sources:
        command = b.host_command(template, source, tag, out)
        rows.append({'tag': tag, 'source': b.identity(source), 'command': command,
                     'object': str(out / (tag + '.obj'))})
        frozen_paths.extend(b.host_dependencies(template))
    frozen_paths.extend(prior.a.hyle_literal_dependencies([x[1] for x in sources]))
    frozen = {c.key(p): b.identity(p) for p in frozen_paths}
    by_tag = {x['tag']: x for x in rows}
    links, cached = {}, {}
    for tag, base_tag, extra, replace, count in (
        ('cuda', 'cuda', 'grouped-test', True, 134),
        ('control', 'cuda', 'grouped-test', False, 134),
        ('neighbor', 'cuda', 'legacy-test', True, 134),
        ('qwen', 'qwen', None, True, 125),
    ):
        base_path = BASE / (base_tag + '-link-plan.json')
        base = c.read(base_path)
        if len(base['inputs']) != (133 if base_tag == 'cuda' else 125):
            raise ValueError('Unexpected retained base input count')
        frozen[c.key(base_path)] = b.identity(base_path)
        for row in base['inputs']:
            key = c.key(row['path'])
            if key in cached and cached[key] != row:
                raise ValueError('Base closures disagree on retained identity')
            cached[key] = row
        old = c.key(old_provider['path'])
        if sum(c.key(x) == old for x in base['command']) != 1 or cached[old] != old_provider:
            raise ValueError('Expected unique, exact old grouped provider owner')
        command = [by_tag['grouped-provider']['object'] if replace and c.key(x) == old else x
                   for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        if extra:
            command.insert(1, by_tag[extra]['object'])
        image = out / (tag + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        linked = inputs(command)
        if len(linked) != count or len(set(map(c.key, linked))) != count:
            raise ValueError('Final exact input closure differs: ' + tag)
        links[tag] = {'command': command, 'inputs': linked, 'image': str(image),
                      'base': str(base_path), 'input_count': count,
                      'provider_replaced': replace, 'added_test_tag': extra}
    plan = {'compile': rows, 'links': links, 'cached_inputs': list(cached.values()),
        'frozen': list(frozen.values()), 'host_TUs': 3, 'native_TUs': 0,
        'SDK_build': False, 'GPU_run': False,
        'legacy_test_was_in_base133': False,
        'legacy_neighbor_separate_image': True,
        'full_model_run_planned': False, 'throughput_claim': False}
    c.save(out / 'plan.json', plan)
    print('PLAN', out / 'plan.json', flush=True)
    check(plan)
    check_cached(plan)
    if not args.build:
        return
    env, _ = b.environment(links['cuda']['command'], links['cuda']['inputs'], out)
    fresh = []
    for row in rows:
        c.execute(row['tag'] + '-compile', row['command'], env, out)
        check(plan)
        identity = b.identity(row['object'])
        fresh.append(identity)
        dependencies = c.read(out / (row['tag'] + '-deps.json'))['Data']['Includes']
        project_headers = [b.identity(p) for p in dependencies
            if Path(p).resolve().is_relative_to(ROOT) and not Path(p).resolve().is_relative_to(ROOT / '.scratch')]
        c.save(out / (row['tag'] + '-identity.json'), {'command': row['command'],
            'source': row['source'], 'object': identity, 'current_project_headers': project_headers})
        for header in project_headers:
            frozen[c.key(header['path'])] = header
        plan['frozen'] = list(frozen.values())
        c.save(out / 'plan.json', plan)
    for tag, link in links.items():
        c.execute(tag + '-link', link['command'], env, out)
        check(plan)
        c.save(out / (tag + '-image.json'), b.identity(link['image']))
    check_cached(plan)
    identities = {c.key(x['path']): x for x in [*plan['cached_inputs'], *fresh]}
    for tag, link in links.items():
        c.save(out / (tag + '-link-plan.json'), {'command': link['command'],
            'inputs': [identities[c.key(x)] for x in link['inputs']]})
    c.save(out / 'build-summary.json', {'passed': True, 'host_TUs': 3, 'native_TUs': 0,
        'input_counts': {k: v['input_count'] for k, v in links.items()},
        'SDK_build': False, 'GPU_run': False, 'old_provider_same_test_control': True})
    print('BUILD_COMPLETE', out / 'plan.json', flush=True)
    if args.run:
        run(plan, out)


if __name__ == '__main__':
    main()
