"""One offline generation of the two generic indexing variants; no GPU run."""
from pathlib import Path
import dataclasses
import hashlib
import importlib.util
import json
import os
import sys
import time

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
OUT = STAGE / 'aot'
os.environ['TRITON_CACHE_DIR'] = str(OUT / 'cache')
sys.path.insert(0, str(ROOT / '.scratch/tools/d5-triton/unpacked'))
import triton
import triton.language as tl
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource

assert triton.__version__ == '3.8.0'
vendor = ROOT / 'third_party/sglang_activation/fp8/grouped'
origin = json.loads((vendor / 'source.json').read_bytes())
original = (vendor / 'original_kernels.py').read_bytes()
assert hashlib.sha256(original).hexdigest() == origin['module_sha256']
adapter = origin['runtime_top_k']
text = original.decode().replace('\r\n', '\n')
assert text.count(adapter['before']) == 1
text = text.replace(adapter['before'], adapter['after'])
assert hashlib.sha256(text.encode()).hexdigest() == adapter['module_sha256']
adapted = OUT / 'runtime_top_k_kernels.py'
adapted.write_text(text, encoding='utf-8', newline='\n')
spec = importlib.util.spec_from_file_location('grouped_runtime_top_k', adapted)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
record = json.loads((STAGE / 'jobs-to-compile.json').read_bytes())
for job in record['kernels']:
    constants = dict(job['constexprs'])
    constants['compute_type'] = tl.float32 if constants['compute_type'] == 'fp32' else tl.bfloat16
    start = time.monotonic()
    compiled = triton.compile(ASTSource(fn=module.fused_moe_kernel,
        signature=job['signature'], constexprs=constants), target=GPUTarget('cuda',89,32),
        options=job['options'])
    blob = compiled.asm['cubin']
    job['seconds'] = round(time.monotonic() - start, 4)
    job['metadata'] = compiled.metadata._asdict()
    job['cubin_sha256'] = hashlib.sha256(blob).hexdigest()
    (OUT / (job['label'] + '.cubin')).write_bytes(blob)
    (OUT / (job['label'] + '.ptx')).write_text(compiled.asm['ptx'])
    print(job['label'], len(blob), job['cubin_sha256'], flush=True)
(STAGE / 'compilation.json').write_text(
    json.dumps(record, indent=2, default=dataclasses.asdict) + '\n', encoding='utf-8')
