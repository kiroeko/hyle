"""Refresh provider facts only; retain all publisher discovery metadata."""
from pathlib import Path
import copy
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
PATH = ROOT / 'docs/implementation/model-quantizations.json'
before_bytes = PATH.read_bytes()
before = json.loads(before_bytes)
after = copy.deepcopy(before)
EVIDENCE = '../evidence/correctness/cuda-grouped-fp8-slots-2026-10-19.zip'
REPLACEMENTS = {
    'Conditional canonical block128 dense/CPU-Apple-Vulkan grouped entries; CUDA grouped AOT currently rejects actual Top10':
        'Conditional canonical block128 dense/grouped entries; CUDA actual-S operator regression verified, artifact import/execution unverified',
    'Public GroupedFloat8Linear accepts A=1 or S, duplicate checked IDs and arbitrary positive S; current CUDA grouped AOT is top-8 only, while the Q24 fixture is Top10':
        'CUDA GroupedFloat8Linear now uses actual S and A=1 or S; primitive regressions cover S3/6/10/16 and checked duplicate IDs. Exact Q24 artifact tensor/import/numerical execution remains unverified',
    'If actual routed tensors bind to canonical FP8, the generic GroupedFloat8Linear descriptor permits S16 but current CUDA grouped_fp8_provider requires S8. This does not prove the artifact routed tensors are FP8':
        'CUDA GroupedFloat8Linear now admits actual S16 within SM89/E/I32 limits and has a primitive regression. This does not establish that the artifact routed tensors are canonical FP8',
    'If routed experts were separately converted to canonical FP8, S6 would also not satisfy current CUDA grouped S8; this conversion is not established':
        'CUDA actual-S grouped indexing is repaired, including an S6 primitive regression; a separate expert conversion to canonical FP8 is still not established',
    'Current CUDA GroupedFloat8Linear requires S8; S6 is not admitted even after any independently verified canonical import':
        'CUDA GroupedFloat8Linear now admits actual S6 within SM89/E/I32 limits; independently verified canonical import and artifact numerical execution remain required',
    'CUDA linear SM89 only; grouped additionally S8':
        'CUDA linear/grouped SM89; grouped actual positive S within E<=1022 and native padded grid/I32 limits',
}
REMOVE = {
    'CUDA GroupedFloat8Linear checked align/GEMM specialization for actual Top10; do not substitute top-8 or plain/grouped BF16 math',
    'CUDA grouped FP8 general S support for an otherwise matching S6 domain',
}
counts = {text: 0 for text in (*REPLACEMENTS, *REMOVE)}

def update(value):
    if isinstance(value, str) and value in REPLACEMENTS:
        counts[value] += 1
        return REPLACEMENTS[value]
    if isinstance(value, list):
        result = []
        for item in value:
            if isinstance(item, str) and item in REMOVE:
                counts[item] += 1
            else:
                result.append(update(item))
        return result
    if isinstance(value, dict):
        return {('conditional_provider_status' if key == 'conditional_provider_gap'
                 and isinstance(item, str) and item in REPLACEMENTS else key): update(item)
                for key, item in value.items()}
    return value

changed = []
for index, artifact in enumerate(after['artifacts']):
    coverage = artifact['provider_coverage']
    artifact['provider_coverage'] = coverage = update(coverage)
    remaining = []
    for entry in coverage.get('declining_entry_points', []):
        if entry.get('provider') != 'CUDA SGLang grouped':
            remaining.append(entry)
            continue
        expected = 'select requires S==8, E<=1022, native padded grid/I32 limits and SM89 qualification; Q24 Top10 does not pass'
        assert entry.pop('decline') == expected
        entry['admission'] = 'Actual positive S; A=1 shares token rows, A=S keeps per-slot rows; E<=1022, native padded grid/I32 limits and SM89 qualification'
        entry['operator_regression_evidence'] = EVIDENCE
        coverage['reachable_entry_points'].append(entry)
    if 'declining_entry_points' in coverage:
        if remaining:
            coverage['declining_entry_points'] = remaining
        else:
            del coverage['declining_entry_points']
    if coverage != before['artifacts'][index]['provider_coverage']:
        coverage['operator_regression_evidence'] = EVIDENCE
        changed.append(index)
    assert coverage['review'] == 'static_contract_review'
    assert coverage['artifact_execution_verified'] is False

assert all(counts.values()), counts
def publisher(document):
    value = copy.deepcopy(document)
    for artifact in value['artifacts']:
        artifact.pop('provider_coverage')
    return value
assert publisher(before) == publisher(after)
target = STAGE / 'table-update'
target.mkdir(exist_ok=False)
(target / 'before.json').write_bytes(before_bytes)
PATH.write_text(json.dumps(after, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
receipt = dict(changed_artifact_indices=changed, artifacts=len(after['artifacts']),
    publisher_metadata_unchanged=True, artifact_execution_verified=False,
    before_sha256=hashlib.sha256(before_bytes).hexdigest(),
    after_sha256=hashlib.sha256(PATH.read_bytes()).hexdigest(), replacements=counts)
(target / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'replacements'}, indent=2))
