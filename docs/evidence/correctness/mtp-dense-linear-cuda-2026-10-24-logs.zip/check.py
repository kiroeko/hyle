from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parents[1];B=R/'.scratch/mtp-full-quant-20261024/engine-check'
s=importlib.util.spec_from_file_location('h',B/'check.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);h.OUT=O;b=h.b
TP=R/'.scratch/mtp-packed-head-20261024/orin-proposal/mmq-query-proposal/compile1/tensor-program/identity.json'

def flags(old):
 result=[];skip=False
 for arg in old['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith('.cc'):continue
  result.append(arg)
 return result

def build():
 old=b.read(TP);cl=old['command'][0]
 native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=())
 prod=flags(old);test=flags(b.read(R/'.scratch/mtp-random-20261024/cuda-component-check/test/identity.json'))
 test += ['/DHYLE_COMPUTE_GGML_CUDA=1']; units={'tensor-program':('src/compute_provider_ggml_cuda/tensor_program.cc',prod),'cublas':('src/compute_provider_cublas/cublas_provider.cc',prod),
 'test-ggml':('tests/compute_provider_ggml_cuda/bfloat_matvec_test.cc',test),'test-cublas':('tests/compute_provider_cublas/cublas_provider_test.cc',test),'test-infer':('tests/compute_ops/operation_test.cc',test)}
 objects={}
 for name,(source,args) in units.items():
  folder=O/name;folder.mkdir(exist_ok=True);obj=folder/(name+'.obj');frozen=b.identity(R/source)
  cmd=[*args,'/sourceDependencies',str(folder/'dependencies.json'),str(R/source),'/Fo'+str(obj),'/Fd'+str(folder/(name+'.pdb'))]
  h.execute(cmd,native.env,name,180)
  if b.identity(R/source)!=frozen:raise RuntimeError('source changed during compile')
  b.save(folder/'identity.json',dict(source=frozen,object=b.identity(obj),command=cmd));objects[name]=str(obj)
 oldplan=b.read(R/'.scratch/mtp-random-20261024/engine-integration/link-cuda.json');command=[];replaced={}
 for arg in oldplan['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')) or arg.endswith('\\entry\\entry.obj') or arg.endswith('\\model-cuda\\qwen.obj'):continue
  if arg==b.read(TP)['object']['path']:replaced[arg]=objects['tensor-program'];arg=objects['tensor-program']
  if Path(arg).name=='compute_provider_cublas--cublas_provider.obj':replaced[arg]=objects['cublas'];arg=objects['cublas']
  command.append(arg)
 if len(replaced)!=2:raise RuntimeError('required two replacement objects')
 testsplan=b.read(R/'.scratch/engine-product-20261024/cpu-budget-fix1/tests-link-plan.json')
 command += [a for a in testsplan['command'] if 'gtest' in Path(a).name.lower() and a.lower().endswith('.lib')]
 command += [objects['test-ggml'],objects['test-cublas'],objects['test-infer']]
 image=O/'checks.exe';command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 b.save(O/'link-plan.json',dict(command=command,replacements=replaced,fresh_TUs=5,SDK_builds=0,HTTP=0,closure=b.identity(R/'.scratch/mtp-random-20261024/engine-integration/link-cuda.json')))
 h.execute(command,native.env,'link',120)
 ready=b.read(R/'.scratch/mtp-random-20261024/engine-integration/ready-cuda.json');b.save(O/'ready.json',dict(image=b.identity(image),PATH=ready['PATH']))

def run():
 ready=b.read(O/'ready.json');env=dict(os.environ,PATH=ready['PATH'])
 f='OperationModelOps.DenseLinearF32*:GgmlCudaBfloatMatvec.*:GgmlCudaDenseLinear.*:CublasProvider.BfloatLinearF32*:CublasProvider.DenseHalfProjection*:CublasProvider.DenseFloatingProjection*:CublasProvider.ScoreOperation*'
 h.execute([ready['image']['path'],'--gtest_filter='+f,'--gtest_output=json:'+str(O/'tests.json')],env,'run',180)
 print((O/'run/stdout.log').read_text())

if __name__=='__main__':
 if sys.argv[1] in ('build','all'):build()
 if sys.argv[1] in ('run','all'):run()
