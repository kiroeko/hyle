"""Q10 actual50 pins on the shared current Graph/provider18 one-TU closure.

Root-only compile/link/run; no acquisition is started here. The original cold
artifact validator is preserved verbatim beside this current-ABI thin entry.
"""
from pathlib import Path
import hashlib
import importlib.util
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
VALIDATOR=S/'abi18-before/build.py'
VALIDATOR_SHA='dd2debc91eb0324286ef5efa5ff1417177e69a4126c0b70e50d927363a744c29'
HELPER=S.parents[1]/'native_build_current.py'
HELPER_SHA='fc0bea30eabdf82286447fe29549bcf430204958c886007fb0963237ce764eb8'
CURRENT=S.parents[4]/'.scratch/mtp-packed-head-20261024/current-integration/build.py'
CURRENT_SHA='b9d48cef256f9ceb868ab1f337661ba0b36f454098d046bc2c505cb0a9fa4307'
UTILITY_SHA='96f154b81677aeeccf2cfb499818e5b0ab3bb24ff6ef8740cc1207e152a4b2d2'
def load(name,path,sha):
    assert hashlib.sha256(path.read_bytes()).hexdigest()==sha
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
if __name__=='__main__':
    old=load('_q10_original_artifact_adapter',VALIDATOR,VALIDATOR_SHA)
    old.S,old.ARTIFACT_DIR=S,S.parent
    old.TEMPLATE=S.parent.parent/'Q01/native-integration/build.py'
    adapter=old.configured();adapter.S=S;adapter.ENTRY_SCRIPT=Path(__file__).resolve()
    lifecycle=load('_q10_current_native_closure',HELPER,HELPER_SHA)
    current=load('_q10_new_source_closure',CURRENT,CURRENT_SHA)
    # The fixed native/command utilities retain their actual manifest; source
    # records, image base and runtime come exclusively from the new closure.
    utility=current.base
    assert hashlib.sha256(Path(utility.__file__).read_bytes()).hexdigest()==UTILITY_SHA
    utility.BASE=current.S/'current-link1';utility.BASE_IMAGE=utility.BASE
    lifecycle.closure=lambda:(utility,current.closure())
    lifecycle.main(adapter,Path(__file__).resolve())
