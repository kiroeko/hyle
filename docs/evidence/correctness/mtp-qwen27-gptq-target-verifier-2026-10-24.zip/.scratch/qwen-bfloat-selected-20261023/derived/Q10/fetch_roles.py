"""Root-only Q10 original50 selected roles on the existing Q01/QB transport.

Requires the real8-byte HTTP identity stage first. No automatic metadata/body
fetch, no official-weight substitution, no controller or new transport loop.
"""
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[3]
REPO,REV='Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ','1b9d56b428e9f841d7ad566f87660b5f47553c97'
COUNT,BODY=50,6135883776
CHUNK,REQUEST_CHUNK,IO,WORKERS=128*1024*1024,8*1024*1024,1024*1024,3
SOURCE_PLAN_SHA='dc65103544c1f1fb1eae3d363bd53342b003dc72960036be90bb9f16db741a5b'
PLAN_FILE=S/'header2-identity/roles-plan.complete.json'
PLAN_SHA=None  # Set only after authenticating the actual metadata completion.
Q01=S.parent/'Q01/fetch_roles.py'
Q01_SHA='b583d84e47d6d252b170194fa00720f1f091545c377666f87485d43978f1f577'


def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))


def identity(p):
    b=p.read_bytes()  # Fixed small metadata,never original role bodies.
    return dict(path=p.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def content_reuse():
    path=S/'content_reuse.py'
    assert identity(path)['sha256']=='425d39beddeb1bd62209063f90727dc4c954ce0e6a849cb395b7794536ae0f46'
    spec=importlib.util.spec_from_file_location('q10_authenticated_content_reuse',path)
    reuse=importlib.util.module_from_spec(spec);spec.loader.exec_module(reuse)
    return reuse


def checked_plan():
    global PLAN_SHA
    original=S/'roles-plan.json';assert identity(original)['sha256']==SOURCE_PLAN_SHA
    source=read(original);assert (source['repository'],source['revision'],source['original_roles'],source['source_bytes'])==(REPO,REV,COUNT,BODY)
    assert source['geometry']==dict(hidden=5120,heads=24,kv_heads=4,depth=256,rotary=64,
        intermediate=17408,vocabulary=248320,target_layer=63,target_type='full_attention',group=64)
    assert identity(S/'source/config.json')['sha256']=='a99d32f3dff4af3b9187cb31b233d69906919a9dc18bbba2fb5d3741c767f230'
    receipt_path=S/'header2-identity/acquisition.json'
    assert receipt_path.is_file() and PLAN_FILE.is_file(),'Actual missing shard2 ETag/total metadata must complete before body/pins'
    receipt=read(receipt_path);assert receipt.get('complete') is True
    assert receipt['source_plan']==identity(original) and (receipt['repository'],receipt['revision'])==(REPO,REV)
    assert receipt['source_file']==source['shards'][1]['file']
    assert receipt['tensor_payload_bytes']==0 and receipt['metadata_body_bytes']==8
    prefix=S/'header2-identity/prefix8.bin';assert receipt['prefix']==identity(prefix)
    raw=prefix.read_bytes();assert len(raw)==8 and int.from_bytes(raw,'little')==48584
    assert receipt['cached_header']==source['shards'][1]['header'] and receipt['whole_file_bytes']==4976925072
    actual=[x for x in receipt['attempts'] if x['complete']];assert len(actual)==1
    a=actual[0];assert a['url']==source['shards'][1]['url'] and a['status']==206 and a['range_inclusive']==[0,7]
    assert a['content_range']=='bytes 0-7/4976925072' and a['bytes']==8 and a['sha256']==receipt['prefix']['sha256']
    assert a['etag']==receipt['etag'] and receipt['etag'].startswith('"') and receipt['etag'].endswith('"')
    expected=copy.deepcopy(source)
    expected['shards'][1].update(etag=receipt['etag'],whole_file_bytes=receipt['whole_file_bytes'],response_source=dict(actual=identity(receipt_path)))
    expected['strict_download_metadata_complete']=True
    expected['completed_http_identity']=dict(source_plan=identity(original),receipt=identity(receipt_path))
    plan=read(PLAN_FILE);assert plan==expected,'Only the missing authenticated HTTP identity may modify the original source plan'
    assert len(plan['roles'])==len({x['name'] for x in plan['roles']})==len({x['filename'] for x in plan['roles']})==COUNT
    assert plan['vocabulary']==dict(embedding='model.language_model.embed_tokens.weight',head='lm_head.weight',unique_banks=2)
    headers=[]
    for item in plan['source_entries']:
        x=item.get('extracted',item.get('cached'));assert identity(R/x['path'])==x
    for shard in plan['shards']:
        assert identity(R/shard['header']['path'])==shard['header']
        h=read(R/shard['header']['path']);headers.append(h)
        assert shard['data_base']==shard['header']['bytes']+8
        assert shard['data_base']+max(x['data_offsets'][1] for k,x in h.items() if k!='__metadata__')==shard['whole_file_bytes']
        assert shard['url']==f'https://huggingface.co/{REPO}/resolve/{REV}/'+shard['file']
        assert isinstance(shard['etag'],str) and shard['etag'].startswith('"') and shard['etag'].endswith('"')
    total=0
    for row in plan['roles']:
        shard=plan['shards'][row['source_shard']];h=headers[row['source_shard']][row['name']]
        assert row['source_file']==shard['file'] and row['dtype']==h['dtype'] and row['shape']==h['shape']
        assert row['data_relative_half_open']==h['data_offsets'] and Path(row['filename']).name==row['filename']
        first,end=h['data_offsets'];assert end-first==row['bytes']==math.prod(row['shape'])*{'BF16':2,'F16':2,'I32':4}[row['dtype']]>0
        assert row['absolute_inclusive']==[shard['data_base']+first,shard['data_base']+end-1]
        assert row['absolute_inclusive'][1]<shard['whole_file_bytes'];total+=row['bytes']
    assert total==BODY
    PLAN_SHA=identity(PLAN_FILE)['sha256']
    return PLAN_FILE,plan


def configured():
    path,plan=checked_plan()
    assert identity(Q01)['sha256']==Q01_SHA
    spec=importlib.util.spec_from_file_location('q10_existing_gptq_transport',Q01)
    job=importlib.util.module_from_spec(spec);spec.loader.exec_module(job)
    job.S,job.REPO,job.REV,job.COUNT,job.BODY=S,REPO,REV,COUNT,BODY
    job.PLAN_FILE,job.PLAN_SHA=path,PLAN_SHA
    job.FILE_DESCRIPTION='+'.join(x['file'] for x in plan['shards'])
    job.VARIANT='GPTQ-v1-int4-group64'
    job.checked_plan=lambda:(path,plan)
    content_reuse().install_fetch(job)
    return job


def main():
    job=configured();job.__doc__=__doc__
    if not any(arg in sys.argv[1:] for arg in ('--plan-only','--help','-h')):
        content_reuse().require_seed(job)
    job.main()


if __name__=='__main__':main()
