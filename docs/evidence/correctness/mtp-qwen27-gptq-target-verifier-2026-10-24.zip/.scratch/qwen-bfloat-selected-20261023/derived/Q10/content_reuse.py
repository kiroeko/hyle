"""Q10-only authenticated Q09 head reuse; no HTTP or shared-source mutation.

Reconstruct SHA256(LE64(120) || original120B header || full BF16 head),
require both fixed repository objects' LFS identity, then hardlink the payload.
The original downloader still checks every cached chunk and whole payload.
Only two exact, SHA-pinned accounting assertions are rebound in Q10 modules.
"""
import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
S = next(path for path in Path(__file__).resolve().parents
         if path.name == 'Q10' and (path / 'roles-plan.json').is_file())
R = S.parents[3]
Q09 = S.parent / 'Q09'
NAME, FILENAME = 'lm_head.weight', 'lm_head.weight.bf16'
PAYLOAD, WHOLE = 2542796800, 2542796928
ETAG_ID = '4a8c494ff93bdcba95af387374af1c82bb96538ae699bc428a152ae160e654fc'
# Original Q09 expanded API, not ETag. Q10's own actual pointer is mandatory.
LFS_SHA = '54d83c1d36631de231876217a8e0c2483eccee8746369a482b79442bdfc5d958'
Q09_API_SHA = 'a951b2e2dc4895afbf709dfed9684095acdd4fafb26cd8821e49875d3085e63e'
PAYLOAD_SHA = 'd922b751f014ee1139488cb94c0e164a1eb3da5c14048070ed1b784e00f92723'
HEADER_SHA = '1c0b3397aa02f43ff6571f52e9845e1df5d9a742d8ce37d54c1d08a9eaa962f5'
SOURCE_RECEIPT_SHA = '60d72be81d2598cf5f1f660627d457f303b803269ff5f1acbcfd4941b8f4d7e4'
SOURCE_PLAN_SHA = 'de024cbff3441dcf45babf8e6a0c088edfbf88a6d63fa6700a61f2fe61651db3'
FETCH_SHA = 'b583d84e47d6d252b170194fa00720f1f091545c377666f87485d43978f1f577'
PINS_SHA = '310955e079d976dac5568316eae46ccf1ed521bcf3b89ca7bd796a0df8e34e54'
IO, CHUNK = 1024 * 1024, 128 * 1024 * 1024
OUT = S / 'original-roles'
PROOF_DIR = S / 'content-reuse'
PROOF = PROOF_DIR / 'verified-head.json'
SNAPSHOT = PROOF_DIR / 'q09-source-receipt.json'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def info(path):
    path = Path(path).resolve()
    raw = path.read_bytes()  # Small source/plan/receipt/proof only, never role bodies.
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verified_lfs_identity():
    """Two own-revision content identities, neither inferred from HTTP ETag."""
    api_path = PROOF_DIR / 'q09-api-model.json'
    if not api_path.is_file():
        api_path = S / 'content-reuse-proposal/cached-metadata/q09-api-model.json'
    assert info(api_path)['sha256'] == Q09_API_SHA
    api = read(api_path)
    assert api['id'] == 'cyankiwi/Qwen3.8-27B-AWQ-INT4' and api['sha'] == '6e134bae811fb5adac50ee042ae5f029ac6779aa'
    siblings = [item for item in api['siblings'] if item['rfilename'] == 'model-00001-of-00005.safetensors']
    assert len(siblings) == 1
    assert siblings[0]['lfs']['sha256'] == LFS_SHA and siblings[0]['lfs']['size'] == WHOLE
    receipt_path = S / 'head-lfs-identity/acquisition.json'
    receipt = read(receipt_path)
    assert receipt['complete'] is True and receipt['source_kind'] == 'original-git-lfs-pointer'
    assert (receipt['repository'], receipt['revision'], receipt['source_file']) == (
        'Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ', '1b9d56b428e9f841d7ad566f87660b5f47553c97',
        'model-00001-of-00005.safetensors')
    assert receipt['source_plan'] == info(S / 'header2-identity/roles-plan.complete.json')
    assert receipt['lfs_sha256'] == LFS_SHA and receipt['original_file_bytes'] == WHOLE
    pointer = S / 'head-lfs-identity/q10-head.pointer.txt'
    assert receipt['pointer'] == info(pointer)
    raw = pointer.read_bytes()
    assert 0 < len(raw) <= 1024 and receipt['metadata_body_bytes'] == len(raw) and receipt['tensor_payload_bytes'] == 0
    match = re.fullmatch(rb'version https://git-lfs.github.com/spec/v1\r?\n'
        rb'oid sha256:([0-9a-f]{64})\r?\nsize ([0-9]+)\r?\n?', raw)
    assert match and match[1].decode('ascii') == LFS_SHA and int(match[2]) == WHOLE
    attempts = [item for item in receipt['attempts'] if item['complete']]
    assert len(attempts) == 1
    actual = attempts[0]
    expected_url = 'https://hf-mirror.net/Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ/raw/1b9d56b428e9f841d7ad566f87660b5f47553c97/model-00001-of-00005.safetensors'
    assert actual['url'] == expected_url and actual['range_inclusive'] == [0, 4095]
    assert actual['status'] in (200, 206) and actual['bytes'] == len(raw) and actual['sha256'] == info(pointer)['sha256']
    headers = {key.lower(): value for key, value in actual['headers'].items()}
    assert int(headers['content-length']) == len(raw) and headers.get('content-encoding') in (None, '', 'identity')
    if actual['status'] == 206:
        assert headers['content-range'] == f'bytes 0-{len(raw)-1}/{len(raw)}'
    return [info(api_path), info(receipt_path), info(pointer)]


def head(plan):
    rows = [row for row in plan['roles'] if row['name'] == NAME]
    assert len(rows) == 1
    row = rows[0]
    assert row['source_shard'] == 0 and row['filename'] == FILENAME
    assert (row['dtype'], row['shape'], row['bytes']) == ('BF16', [248320, 5120], PAYLOAD)
    assert row['data_relative_half_open'] == [0, PAYLOAD]
    assert row['absolute_inclusive'] == [128, WHOLE - 1]
    shard = plan['shards'][0]
    assert shard['data_base'] == 128 and shard['whole_file_bytes'] == WHOLE
    assert shard['etag'] == '"' + ETAG_ID + '"'
    assert shard['header']['bytes'] == 120 and shard['header']['sha256'] == HEADER_SHA
    assert info(R / shard['header']['path']) == shard['header']
    return row, shard


def metadata():
    fetch = load('_q10_reuse_metadata', S / 'fetch_roles.py')
    destination_path, destination = fetch.checked_plan()
    source_path = Q09 / 'roles-plan.json'
    assert info(source_path)['sha256'] == SOURCE_PLAN_SHA
    source = read(source_path)
    assert (source['repository'], source['revision']) == (
        'cyankiwi/Qwen3.8-27B-AWQ-INT4', '6e134bae811fb5adac50ee042ae5f029ac6779aa')
    for plan in (source, destination):
        head(plan)
    assert (R / source['shards'][0]['header']['path']).read_bytes() == (
        R / destination['shards'][0]['header']['path']).read_bytes()
    return fetch, destination_path, destination, source_path, source


def source_head(receipt):
    assert (receipt['repository'], receipt['revision']) == (
        'cyankiwi/Qwen3.8-27B-AWQ-INT4', '6e134bae811fb5adac50ee042ae5f029ac6779aa')
    assert receipt['complete'] and receipt['original_roles'] == 50
    assert receipt['source_plan_sha256'] == SOURCE_PLAN_SHA
    rows = [row for row in receipt['roles'] if row['name'] == NAME]
    assert len(rows) == 1
    row = rows[0]
    assert info(Q09 / 'roles-plan.json')['sha256'] == SOURCE_PLAN_SHA
    wanted, _ = head(read(Q09 / 'roles-plan.json'))
    assert all(row[key] == value for key, value in wanted.items())
    assert row['complete'] and row['payload']['bytes'] == PAYLOAD
    assert row['payload']['sha256'] == PAYLOAD_SHA
    assert row['payload']['path'] == (Q09 / 'original-roles' / FILENAME).relative_to(R).as_posix()
    assert row['etag'] == '"' + ETAG_ID + '"' and row['whole_file_bytes'] == WHOLE
    return row


def validate(record, plan):
    """Validate the explicit local source kind, never invent Q10 HTTP attempts."""
    wanted, shard = head(plan)
    reused = [row for row in record['roles'] if 'authenticated_content_reuse' in row]
    assert len(reused) == 1 and reused[0]['name'] == NAME
    row = reused[0]
    assert row['complete'] and row['authenticated_content_reuse'] == info(PROOF)
    assert row['payload'] == dict(path=(OUT / FILENAME).relative_to(R).as_posix(),
                                  bytes=PAYLOAD, sha256=PAYLOAD_SHA)
    assert (OUT / FILENAME).stat().st_size == PAYLOAD
    assert row['url'] == shard['url'] and row['etag'] == shard['etag']
    for key in ('name', 'section', 'dtype', 'shape', 'bytes', 'source_file', 'absolute_inclusive'):
        assert row[key] == wanted[key]
    assert not any(attempt['role'] == NAME for attempt in record['requests'])
    proof = read(PROOF)
    assert proof['kind'] == 'authenticated-content-reuse-v1'
    assert proof['source_plan'] == info(Q09 / 'roles-plan.json')
    assert proof['source_plan']['sha256'] == SOURCE_PLAN_SHA
    assert proof['destination_plan'] == info(S / 'header2-identity/roles-plan.complete.json')
    assert proof['source_header'] == read(Q09 / 'roles-plan.json')['shards'][0]['header']
    assert proof['destination_header'] == shard['header']
    assert proof['source_receipt_snapshot'] == info(SNAPSHOT)
    assert proof['source_receipt_snapshot']['sha256'] == SOURCE_RECEIPT_SHA
    assert proof['original_source_receipt']['path'] == (Q09 / 'original-roles/acquisition.json').relative_to(R).as_posix()
    assert all(proof['original_source_receipt'][key] == proof['source_receipt_snapshot'][key]
               for key in ('bytes', 'sha256'))
    assert proof['payload_sha256'] == PAYLOAD_SHA and proof['whole_file_sha256'] == LFS_SHA
    assert proof['lfs_identity_metadata'] == verified_lfs_identity()
    assert proof['payload_bytes'] == PAYLOAD and proof['whole_file_bytes'] == WHOLE
    assert proof['reconstructed_prefix_bytes'] == 128 and proof['actual_stream_hashed'] is True
    assert proof['new_HTTP_requests'] == 0 and proof['published_by'] == 'hardlink'
    original = source_head(read(SNAPSHOT))
    assert row['chunks'] == original['chunks']
    return PAYLOAD


def pin_accounting(source, receipt, plan):
    assert source.S.resolve() == S and source.REPO == plan['repository'] and source.REV == plan['revision']
    assert receipt['expected_role_payload_bytes'] == receipt['role_payload_bytes'] == source.BODY
    reused = validate(receipt, plan)
    requests = sum(attempt['bytes'] for attempt in receipt['requests'] if attempt['complete'])
    assert receipt['successful_request_body_bytes'] == requests
    assert receipt['authenticated_reused_body_bytes'] == reused
    assert requests + reused == source.BODY


def rewrite_one(path, expected_sha, function, old, replacement, namespace):
    """One fixed function and one exact assertion; all other AST is retained."""
    raw = Path(path).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected_sha
    tree = ast.parse(raw, filename=str(path))
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == function]
    assert len(definitions) == 1
    node = definitions[0]
    original_hash = hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
    old_node = ast.parse(old).body[0]
    matches = [item for item in ast.walk(node) if ast.dump(item, include_attributes=False) == ast.dump(old_node, include_attributes=False)]
    assert len(matches) == 1 and isinstance(matches[0], ast.Assert)
    class OneAssertion(ast.NodeTransformer):
        def visit_Assert(self, item):
            if item is matches[0]:
                return ast.parse(replacement).body
            return item
    new = OneAssertion().visit(node)
    ast.fix_missing_locations(new)
    exec(compile(ast.Module(body=[new], type_ignores=[]), str(path), 'exec'), namespace)
    return dict(source=info(path), function=function, original_function_AST_sha256=original_hash,
                exact_targets=1, original_formula=old, replacement_formula=replacement)


def install_fetch(job):
    job.validate_q10_reuse = validate
    facts = rewrite_one(S.parent / 'Q01/fetch_roles.py', FETCH_SHA, 'main',
        'assert payload_bytes == request_bytes == BODY',
        'reused_bytes = validate_q10_reuse(record, plan)\n'
        'assert payload_bytes == BODY and request_bytes + reused_bytes == BODY\n'
        'record["authenticated_reused_body_bytes"] = reused_bytes', job.__dict__)
    original_manifest = job.manifest
    def manifest(out, record, plan):
        original_manifest(out, record, plan)
        path = out / 'manifest.json'
        result = read(path)
        result.update(authenticated_reused_body_bytes=PAYLOAD,
            successful_request_body_bytes=record['successful_request_body_bytes'],
            authenticated_content_reuses=[info(PROOF)],
            scope='Original Q10 roles. Head content matches independently reconstructed full safetensors SHA and is hardlinked from actual Q09; no Q10 head HTTP is claimed. Other roles retain ordinary authenticated ranges.')
        path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    job.manifest = manifest
    return facts


def install_generator(shared):
    shared.validate_q10_pin_accounting = pin_accounting
    return rewrite_one(S.parent / 'Q01/generate_pins.py', PINS_SHA, 'checked_metadata',
        "assert receipt['expected_role_payload_bytes'] == receipt['role_payload_bytes'] == receipt['successful_request_body_bytes'] == source.BODY",
        'validate_q10_pin_accounting(source, receipt, plan)', shared.__dict__)


def require_seed(job):
    path, plan = job.checked_plan()
    receipt = OUT / 'acquisition.json'
    assert receipt.is_file() and PROOF.is_file(), 'Run Q10 content_reuse.py seed first; refusing automatic head HTTP'
    record = read(receipt)
    assert record['source_plan_sha256'] == info(path)['sha256']
    validate(record, plan)


def atomic(path, raw):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def seed():
    verified_lfs_identity()  # Fail before payload/link/output writes if Q10 identity is absent.
    fetch, destination_path, destination, source_path, source = metadata()
    job = fetch.configured()
    shared = job.shared_downloader()
    OUT.mkdir(exist_ok=True)
    with shared.single_writer(OUT / '.fetch.lock'):
        receipt_path = OUT / 'acquisition.json'
        if receipt_path.exists() and PROOF.exists():
            record = read(receipt_path)
            if any(row['name'] == NAME and 'authenticated_content_reuse' in row for row in record['roles']):
                assert record['source_plan_sha256'] == info(destination_path)['sha256']
                validate(record, destination)
                print(json.dumps(dict(reused_existing_authenticated_seed=True, proof=info(PROOF), new_HTTP_requests=0)))
                return
        source_receipt_path = Q09 / 'original-roles/acquisition.json'
        raw_receipt = source_receipt_path.read_bytes()
        assert len(raw_receipt) == 704654 and hashlib.sha256(raw_receipt).hexdigest() == SOURCE_RECEIPT_SHA
        source_row = source_head(json.loads(raw_receipt))
        source_body = R / source_row['payload']['path']
        assert source_body.stat().st_size == PAYLOAD
        header = (R / source['shards'][0]['header']['path']).read_bytes()
        whole = hashlib.sha256(len(header).to_bytes(8, 'little') + header)
        payload = hashlib.sha256()
        offset = 0
        with source_body.open('rb') as stream:
            for chunk in source_row['chunks']:
                assert chunk['offset'] == offset and 0 < chunk['bytes'] <= CHUNK
                assert chunk['absolute_range_inclusive'] == [128 + offset, 128 + offset + chunk['bytes'] - 1]
                digest, remaining = hashlib.sha256(), chunk['bytes']
                while remaining:
                    raw = stream.read(min(IO, remaining))
                    assert raw, 'Truncated actual Q09 head'
                    digest.update(raw); payload.update(raw); whole.update(raw)
                    remaining -= len(raw)
                assert digest.hexdigest() == chunk['sha256']
                offset += chunk['bytes']
            assert not stream.read(1) and offset == PAYLOAD
        assert payload.hexdigest() == PAYLOAD_SHA and whole.hexdigest() == LFS_SHA
        assert source_body.stat().st_size == PAYLOAD
        roles = []
        for row in destination['roles']:
            shard = destination['shards'][row['source_shard']]
            roles.append(dict(row, url=shard['url'], etag=shard['etag'], whole_file_bytes=shard['whole_file_bytes'],
                complete=False, chunks=[], payload=dict(path=(OUT / row['filename']).relative_to(R).as_posix(), bytes=row['bytes'], sha256=None)))
        expected = dict(repository=job.REPO, revision=job.REV, file=job.FILE_DESCRIPTION,
            source_plan=destination_path.relative_to(R).as_posix(), source_plan_sha256=job.PLAN_SHA,
            expected_role_payload_bytes=job.BODY, downloader=info(shared.HELPER), wrapper=info(Path(shared.__file__)))
        if receipt_path.exists():
            record = read(receipt_path)
            assert all(record[key] == value for key, value in expected.items())
            for actual, wanted in zip(record['roles'], roles, strict=True):
                assert all(actual[key] == value for key, value in wanted.items() if key not in ('complete', 'chunks', 'payload'))
                assert actual['payload']['path'] == wanted['payload']['path'] and actual['payload']['bytes'] == wanted['payload']['bytes']
        else:
            assert not any((OUT / row['filename']).exists() for row in roles if row['name'] != NAME)
            record = dict(expected, complete=False, original_roles=job.COUNT, whole_shard_downloaded=False, requests=[], roles=roles)
        assert not any(attempt['role'] == NAME for attempt in record['requests'])
        target = next(row for row in record['roles'] if row['name'] == NAME)
        assert not target['chunks'] and not target['complete'] and target['payload']['sha256'] is None
        PROOF_DIR.mkdir(exist_ok=True)
        api = PROOF_DIR / 'q09-api-model.json'
        if not api.is_file():
            atomic(api, (S / 'content-reuse-proposal/cached-metadata/q09-api-model.json').read_bytes())
        if SNAPSHOT.exists():
            assert SNAPSHOT.read_bytes() == raw_receipt
        else:
            atomic(SNAPSHOT, raw_receipt)
        proof = dict(kind='authenticated-content-reuse-v1', role=NAME,
            source_plan=info(source_path), destination_plan=info(destination_path),
            original_source_receipt=dict(path=source_receipt_path.relative_to(R).as_posix(), bytes=len(raw_receipt), sha256=SOURCE_RECEIPT_SHA),
            source_receipt_snapshot=info(SNAPSHOT), source_header=source['shards'][0]['header'],
            destination_header=destination['shards'][0]['header'], payload_sha256=PAYLOAD_SHA,
            lfs_identity_metadata=verified_lfs_identity(),
            whole_file_sha256=whole.hexdigest(), payload_bytes=PAYLOAD, whole_file_bytes=WHOLE,
            reconstructed_prefix_bytes=128, actual_stream_hashed=True, published_by='hardlink', new_HTTP_requests=0)
        proof_raw = (json.dumps(proof, indent=2) + '\n').encode()
        if PROOF.exists():
            assert PROOF.read_bytes() == proof_raw
        else:
            atomic(PROOF, proof_raw)
        target_path = OUT / FILENAME
        if target_path.exists():
            assert os.path.samefile(source_body, target_path), 'Refuse to overwrite unrecorded/different Q10 head'
        else:
            os.link(source_body, target_path)
        target.update(complete=True, chunks=copy.deepcopy(source_row['chunks']), authenticated_content_reuse=info(PROOF))
        target['payload']['sha256'] = PAYLOAD_SHA
        record['authenticated_reused_body_bytes'] = PAYLOAD
        validate(record, destination)
        atomic(receipt_path, (json.dumps(record, indent=2) + '\n').encode())
        print(json.dumps(dict(complete=True, receipt=info(receipt_path), proof=info(PROOF),
            whole_file_sha256=whole.hexdigest(), reused_original_bytes=PAYLOAD,
            new_HTTP_requests=0, remaining_unique_role_HTTP_bytes=job.BODY - PAYLOAD)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'seed'))
    args = parser.parse_args()
    if args.action == 'seed':
        seed()
    else:
        fetch, path, destination, _, _ = metadata()
        print(json.dumps(dict(source_receipt_required=SOURCE_RECEIPT_SHA, expected_whole_sha256=LFS_SHA,
            source_payload_sha256=PAYLOAD_SHA, reused_body_bytes=PAYLOAD,
            remaining_unique_body_bytes=fetch.BODY - PAYLOAD, new_HTTP_requests=0,
            seed_not_executed=True, destination_plan=info(path))))
