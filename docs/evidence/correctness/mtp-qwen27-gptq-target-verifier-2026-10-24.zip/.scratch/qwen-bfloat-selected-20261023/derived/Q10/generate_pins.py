"""Root-only Q10 metadata/pins adapter on the shared Q01 GPTQ template.

No output until actual50 selected role acquisition is complete. Untied source
embedding/head remain two independent actual BF16 banks and pins.
"""
import hashlib
import importlib.util
from pathlib import Path
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[3]
TEMPLATE=S.parent/'Q01/generate_pins.py'
TEMPLATE_SHA='310955e079d976dac5568316eae46ccf1ed521bcf3b89ca7bd796a0df8e34e54'


def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


assert hashlib.sha256(TEMPLATE.read_bytes()).hexdigest()==TEMPLATE_SHA
shared=load('q10_shared_gptq_pin_template',TEMPLATE)
fetch=load('q10_actual_gptq_source_metadata',S/'fetch_roles.py')
assert hashlib.sha256((S/'content_reuse.py').read_bytes()).hexdigest()=='425d39beddeb1bd62209063f90727dc4c954ce0e6a849cb395b7794536ae0f46'
reuse=load('q10_authenticated_content_reuse_pins',S/'content_reuse.py')
reuse.install_generator(shared)
PROFILE=dict(family='qwen3.8',model_name='Qwen3.8-27B-W4A16-AutoRound-GPTQ',
    config_sha='a99d32f3dff4af3b9187cb31b233d69906919a9dc18bbba2fb5d3741c767f230',
    header_sha='e2ce79ec318758339cfe39d2e7a521631422a3b09734acfb046e28ba2d405a7f')


def checked_metadata():return shared.checked_metadata(fetch)


def header(plan,rows,receipt_sha,manifest_sha):
    return shared.header(plan,rows,receipt_sha,manifest_sha,source=fetch,tag='q10',**PROFILE)


def main():shared.main_for(fetch,tag='q10',**PROFILE)


if __name__=='__main__':main()
