#pragma once
#include <array>
#include <algorithm>
#include <span>
#include <vector>
#include "qwen_bfloat_original_roles.h"
#include "qwen_gptq_projection_fragment.h"

// Actual acquisition pins; the shared Data/Bound and K1 controller are reused.
// Original GPTQ quartets remain packed; compile reports must prove all7 contractions.
namespace qwen_bfloat_original_artifacts::q10 {
namespace roles=qwen_bfloat_original_roles;
inline constexpr qwen_original_mtp_roles::Identity kIdentity{"Vishva007/Qwen3.8-27B-W4A16-AutoRound-GPTQ","1b9d56b428e9f841d7ad566f87660b5f47553c97","GPTQ-v1-int4-group64","model-00001-of-00005.safetensors+model-00002-of-00005.safetensors+model-00005-of-00005.safetensors+model_extra_tensors.safetensors"};
inline constexpr qwen_full_attention_fragment::Geometry kGeometry{5120,24,4,256,64,1.e-6F,0.F,hyle::compute::DataType::kBFloat16};
inline constexpr std::int64_t kIntermediate=17408,kVocabulary=248320;
inline constexpr float kRopeTheta=10'000'000.F;
inline constexpr std::uint64_t kOriginalBytes=6135883776ULL;
inline constexpr std::string_view kPlanSha256="2923ff4d43d328f0b344edffeed291208875ca78133ce42aba2d0b13245c73fc",kReceiptSha256="cc295f9f3fb7fc08037c4740954bb06f7556d9c17453b56ba1a91c832bcd9fea",kManifestSha256="c797e4690e580788ad5d676599b78e23f156a157fa00e42f94721384d995ec12";
inline constexpr std::string_view kTargetLayer="model.language_model.layers.63",kTargetNorm="model.language_model.norm.weight";
inline constexpr roles::VocabularyNames kVocabularyNames{"model.language_model.embed_tokens.weight","lm_head.weight"};
// Both identities name this exact publisher artifact; no unpinned official base revision is inferred.
inline constexpr hyle::compute::ModelArtifactProfileDescription kProfile{
    .model_publisher="Vishva007",.model_repository=kIdentity.repository,.model_family="qwen3.8",
    .model_name="Qwen3.8-27B-W4A16-AutoRound-GPTQ",.model_revision=kIdentity.revision,
    .configuration_digest="a99d32f3dff4af3b9187cb31b233d69906919a9dc18bbba2fb5d3741c767f230",
    .artifact_repository=kIdentity.repository,.artifact_revision=kIdentity.revision,.variant=kIdentity.variant,
    .manifest_digest="e2ce79ec318758339cfe39d2e7a521631422a3b09734acfb046e28ba2d405a7f",.format_family="safetensors"};
static_assert(kProfile.complete());
inline constexpr roles::DenseNormConventions kNormConventions{
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,
    roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne,roles::NormConvention::kDeltaPlusOne};
inline constexpr std::array<roles::PinnedFile,17> kNextnFiles{{
    {"mtp.pre_fc_norm_hidden.weight.bf16","f2e1aa414ce84d89d016f2260923f7d47eb9827be043d1823dc6e783e4205efe"},
    {"mtp.pre_fc_norm_embedding.weight.bf16","9b03e3af7824cd765abdcfc21da960c25f3c7ee1294ce25c226f0ebc5ff39998"},
    {"mtp.fc.weight.bf16","4eee377b67ec2122cf214dbe6946d16261873441f1851d64409d9c7566bb20cc"},
    {"mtp.layers.0.input_layernorm.weight.bf16","bf04147cf2ecff83cd7b4f8b8611df55955041bc7749c95f6c9eb741e2ce7ec0"},
    {"mtp.layers.0.self_attn.q_proj.weight.bf16","8b27ef96b91e0b0564f82f11d9010efee6aa40a0eaa1900336bf597f767e7c98"},
    {"mtp.layers.0.self_attn.k_proj.weight.bf16","0ab4e67930451a2f1140e865d2e3e7e23cd752a3bb25042c36e7e546361073d0"},
    {"mtp.layers.0.self_attn.v_proj.weight.bf16","9606be457a48d7d9a78d72f255246f4e346845d752c1e82e41e14728255c5e13"},
    {"mtp.layers.0.self_attn.o_proj.weight.bf16","9165a161837a5d4489a838279805b15dd5b5827f1d3ac2f3f4067a71131a5fd7"},
    {"mtp.layers.0.self_attn.q_norm.weight.bf16","76aae220c35e2dea96f0985239b719fdcab93e208add6c32ca399b1166ec444e"},
    {"mtp.layers.0.self_attn.k_norm.weight.bf16","73723b12e89816afcc8faab883f88079f0eccf6c3208b2d7d851adc2597b3c63"},
    {"mtp.layers.0.post_attention_layernorm.weight.bf16","248f158f48a4b9b1d140e6728b77b19f132ae19de5cb60dac292742f7a695bbf"},
    {"mtp.layers.0.mlp.gate_proj.weight.bf16","e2fa26989b3103cc595990f53c13a295f95507d0a480276e642a084e6b1f62cc"},
    {"mtp.layers.0.mlp.up_proj.weight.bf16","8c6a44250d5976dc707703ea09e994eaeabef309c3faac8599e2e282eb4933ba"},
    {"mtp.layers.0.mlp.down_proj.weight.bf16","2fdda9751e3b7c1444632878283116550a1824dcad691aa8366793ba21faf935"},
    {"mtp.norm.weight.bf16","414fb74a971b168fb9a073c3486cbc61c46e992757179e724a345bbf56896fb1"},
    {"model.language_model.embed_tokens.weight.bf16","a158f24c6ad72736067768b4255e70a384e2e931f601b12f853e98ce83ec6bbe"},
    {"lm_head.weight.bf16","d922b751f014ee1139488cb94c0e164a1eb3da5c14048070ed1b784e00f92723"},
}};
struct Pin final {std::string_view name,file,sha256,dtype;std::array<std::int64_t,2> shape;std::size_t rank;std::uint64_t bytes;};
inline constexpr std::array<Pin,50> kPins{{
    {"lm_head.weight","lm_head.weight.bf16","d922b751f014ee1139488cb94c0e164a1eb3da5c14048070ed1b784e00f92723","BF16",{248320,5120},2,2542796800ULL},
    {"model.language_model.embed_tokens.weight","model.language_model.embed_tokens.weight.bf16","a158f24c6ad72736067768b4255e70a384e2e931f601b12f853e98ce83ec6bbe","BF16",{248320,5120},2,2542796800ULL},
    {"model.language_model.layers.63.mlp.down_proj.g_idx","model.language_model.layers.63.mlp.down_proj.g_idx.i32","4c2c94c3831375fdbe2d2949513a78f860f132c1589020156ea3d9284f054939","I32",{17408,0},1,69632ULL},
    {"model.language_model.layers.63.mlp.down_proj.qweight","model.language_model.layers.63.mlp.down_proj.qweight.i32","c3374505721ec5233904b1b0275519fc70fb95b57c6af9cab8eccfd8e281b57c","I32",{2176,5120},2,44564480ULL},
    {"model.language_model.layers.63.mlp.down_proj.qzeros","model.language_model.layers.63.mlp.down_proj.qzeros.i32","7ad050f663bb808fcb1bfd977debd63c577b0a59d16773501b87aed3ff4a7ec9","I32",{272,640},2,696320ULL},
    {"model.language_model.layers.63.mlp.gate_proj.g_idx","model.language_model.layers.63.mlp.gate_proj.g_idx.i32","39cbf6fdcb6c0ce9fae1188a1dad1ad73dcedb247f4264ff8ff7986c250361c5","I32",{5120,0},1,20480ULL},
    {"model.language_model.layers.63.mlp.gate_proj.qweight","model.language_model.layers.63.mlp.gate_proj.qweight.i32","433812a3db8a48a728522fca1cd9579ea95f98fcd2d73e26c137b4931affe5f4","I32",{640,17408},2,44564480ULL},
    {"model.language_model.layers.63.mlp.gate_proj.qzeros","model.language_model.layers.63.mlp.gate_proj.qzeros.i32","7ad050f663bb808fcb1bfd977debd63c577b0a59d16773501b87aed3ff4a7ec9","I32",{80,2176},2,696320ULL},
    {"model.language_model.layers.63.mlp.up_proj.g_idx","model.language_model.layers.63.mlp.up_proj.g_idx.i32","39cbf6fdcb6c0ce9fae1188a1dad1ad73dcedb247f4264ff8ff7986c250361c5","I32",{5120,0},1,20480ULL},
    {"model.language_model.layers.63.mlp.up_proj.qweight","model.language_model.layers.63.mlp.up_proj.qweight.i32","2ccb25b7958f8d4cc35fab2d65280096fcf2318f150a0319005649147c441e9b","I32",{640,17408},2,44564480ULL},
    {"model.language_model.layers.63.mlp.up_proj.qzeros","model.language_model.layers.63.mlp.up_proj.qzeros.i32","7ad050f663bb808fcb1bfd977debd63c577b0a59d16773501b87aed3ff4a7ec9","I32",{80,2176},2,696320ULL},
    {"model.language_model.layers.63.self_attn.k_proj.g_idx","model.language_model.layers.63.self_attn.k_proj.g_idx.i32","39cbf6fdcb6c0ce9fae1188a1dad1ad73dcedb247f4264ff8ff7986c250361c5","I32",{5120,0},1,20480ULL},
    {"model.language_model.layers.63.self_attn.k_proj.qweight","model.language_model.layers.63.self_attn.k_proj.qweight.i32","f33962e6ffb59d0ea76e07fab28e1330fc7ba9c0334694e4ca84bf219d47ec10","I32",{640,1024},2,2621440ULL},
    {"model.language_model.layers.63.self_attn.k_proj.qzeros","model.language_model.layers.63.self_attn.k_proj.qzeros.i32","a4d29f551aa8fdd0ca3738242ff9bf3c275fd9c12e8381cf15fad89e7bc2a7bd","I32",{80,128},2,40960ULL},
    {"model.language_model.layers.63.self_attn.o_proj.g_idx","model.language_model.layers.63.self_attn.o_proj.g_idx.i32","571ef277fb17569673869b739babab96f7136ff4563d0fb36415521e07f050e4","I32",{6144,0},1,24576ULL},
    {"model.language_model.layers.63.self_attn.o_proj.qweight","model.language_model.layers.63.self_attn.o_proj.qweight.i32","5286524f987dcebda5cc411b47aaa9103d44a1de791b78739d7cb2b6416b7de9","I32",{768,5120},2,15728640ULL},
    {"model.language_model.layers.63.self_attn.o_proj.qzeros","model.language_model.layers.63.self_attn.o_proj.qzeros.i32","f01dc50577a97ce887032c1db3545a4145706dbce245f70cbde80f865ebbc18d","I32",{96,640},2,245760ULL},
    {"model.language_model.layers.63.self_attn.q_proj.g_idx","model.language_model.layers.63.self_attn.q_proj.g_idx.i32","39cbf6fdcb6c0ce9fae1188a1dad1ad73dcedb247f4264ff8ff7986c250361c5","I32",{5120,0},1,20480ULL},
    {"model.language_model.layers.63.self_attn.q_proj.qweight","model.language_model.layers.63.self_attn.q_proj.qweight.i32","38296b38f0d7010f949a0ded40000774ea6666b0b74e2defa786ce69ca294534","I32",{640,12288},2,31457280ULL},
    {"model.language_model.layers.63.self_attn.q_proj.qzeros","model.language_model.layers.63.self_attn.q_proj.qzeros.i32","3c389c0733bc9a91b32156a4627bb10cd853fe011f028b320ae5d85c463bb6a9","I32",{80,1536},2,491520ULL},
    {"model.language_model.layers.63.self_attn.v_proj.g_idx","model.language_model.layers.63.self_attn.v_proj.g_idx.i32","39cbf6fdcb6c0ce9fae1188a1dad1ad73dcedb247f4264ff8ff7986c250361c5","I32",{5120,0},1,20480ULL},
    {"model.language_model.layers.63.self_attn.v_proj.qweight","model.language_model.layers.63.self_attn.v_proj.qweight.i32","5229e287084250b8e6f37c9e1666c242b53c60d0eb570a9bfc783847f4f8b95e","I32",{640,1024},2,2621440ULL},
    {"model.language_model.layers.63.self_attn.v_proj.qzeros","model.language_model.layers.63.self_attn.v_proj.qzeros.i32","a4d29f551aa8fdd0ca3738242ff9bf3c275fd9c12e8381cf15fad89e7bc2a7bd","I32",{80,128},2,40960ULL},
    {"model.language_model.layers.63.input_layernorm.weight","model.language_model.layers.63.input_layernorm.weight.bf16","2f14073bc5a0014672d21dab66710e0ff1830cb06d968dd64fa7ec16a35bf730","BF16",{5120,0},1,10240ULL},
    {"model.language_model.layers.63.post_attention_layernorm.weight","model.language_model.layers.63.post_attention_layernorm.weight.bf16","19008b67d6ad56bdfeb6cab38aaa52fd182757b22912f1eeecc28345fa10dd2b","BF16",{5120,0},1,10240ULL},
    {"model.language_model.layers.63.self_attn.k_norm.weight","model.language_model.layers.63.self_attn.k_norm.weight.bf16","956090c277d9eefa1d7fcaa55ebfa03ae0c0f3eed08a7cd667d28e6e3e5160a1","BF16",{256,0},1,512ULL},
    {"model.language_model.layers.63.self_attn.q_norm.weight","model.language_model.layers.63.self_attn.q_norm.weight.bf16","a724704567558321f52e7057362a98c185857f6255bc507e3452275dc31f29f1","BF16",{256,0},1,512ULL},
    {"model.language_model.norm.weight","model.language_model.norm.weight.bf16","d1d9fbdef187db987c117e021c7e4574ef32a5784c29f99d2722ce7654214738","BF16",{5120,0},1,10240ULL},
    {"model.language_model.layers.63.mlp.down_proj.scales","model.language_model.layers.63.mlp.down_proj.scales.f16","ac7b2488532026845643ef86aabb7eb4755c240147dbcf40fe3e420cf05166eb","F16",{272,5120},2,2785280ULL},
    {"model.language_model.layers.63.mlp.gate_proj.scales","model.language_model.layers.63.mlp.gate_proj.scales.f16","49b2d4a4829a8ec357cbdf0e404de9cc38fb4ef74c0039c58b5e3ff7175378ce","F16",{80,17408},2,2785280ULL},
    {"model.language_model.layers.63.mlp.up_proj.scales","model.language_model.layers.63.mlp.up_proj.scales.f16","68eb9f8e1ce100a12c6b926d809d557767d61f7483db3c87cd58089a7ca8d579","F16",{80,17408},2,2785280ULL},
    {"model.language_model.layers.63.self_attn.k_proj.scales","model.language_model.layers.63.self_attn.k_proj.scales.f16","5391dbca572b1c7e7465e87a49a062095730e36f7964a0f37aac190d650cb5ed","F16",{80,1024},2,163840ULL},
    {"model.language_model.layers.63.self_attn.o_proj.scales","model.language_model.layers.63.self_attn.o_proj.scales.f16","d2d064c1f50dadbc36c14ba9c6e64e78093a0c4f1a0e3a02b8dd1ca633e3691f","F16",{96,5120},2,983040ULL},
    {"model.language_model.layers.63.self_attn.q_proj.scales","model.language_model.layers.63.self_attn.q_proj.scales.f16","15a7916fa8baf7facd115a0f949a8b0e95c89328c1b73df3550d836ab5d56b60","F16",{80,12288},2,1966080ULL},
    {"model.language_model.layers.63.self_attn.v_proj.scales","model.language_model.layers.63.self_attn.v_proj.scales.f16","49cf28d7341634e33e4b6f7ff1748cc072344bead35d453ae6e7613f4d99d752","F16",{80,1024},2,163840ULL},
    {"mtp.fc.weight","mtp.fc.weight.bf16","4eee377b67ec2122cf214dbe6946d16261873441f1851d64409d9c7566bb20cc","BF16",{5120,10240},2,104857600ULL},
    {"mtp.layers.0.input_layernorm.weight","mtp.layers.0.input_layernorm.weight.bf16","bf04147cf2ecff83cd7b4f8b8611df55955041bc7749c95f6c9eb741e2ce7ec0","BF16",{5120,0},1,10240ULL},
    {"mtp.layers.0.mlp.down_proj.weight","mtp.layers.0.mlp.down_proj.weight.bf16","2fdda9751e3b7c1444632878283116550a1824dcad691aa8366793ba21faf935","BF16",{5120,17408},2,178257920ULL},
    {"mtp.layers.0.mlp.gate_proj.weight","mtp.layers.0.mlp.gate_proj.weight.bf16","e2fa26989b3103cc595990f53c13a295f95507d0a480276e642a084e6b1f62cc","BF16",{17408,5120},2,178257920ULL},
    {"mtp.layers.0.mlp.up_proj.weight","mtp.layers.0.mlp.up_proj.weight.bf16","8c6a44250d5976dc707703ea09e994eaeabef309c3faac8599e2e282eb4933ba","BF16",{17408,5120},2,178257920ULL},
    {"mtp.layers.0.post_attention_layernorm.weight","mtp.layers.0.post_attention_layernorm.weight.bf16","248f158f48a4b9b1d140e6728b77b19f132ae19de5cb60dac292742f7a695bbf","BF16",{5120,0},1,10240ULL},
    {"mtp.layers.0.self_attn.k_norm.weight","mtp.layers.0.self_attn.k_norm.weight.bf16","73723b12e89816afcc8faab883f88079f0eccf6c3208b2d7d851adc2597b3c63","BF16",{256,0},1,512ULL},
    {"mtp.layers.0.self_attn.k_proj.weight","mtp.layers.0.self_attn.k_proj.weight.bf16","0ab4e67930451a2f1140e865d2e3e7e23cd752a3bb25042c36e7e546361073d0","BF16",{1024,5120},2,10485760ULL},
    {"mtp.layers.0.self_attn.o_proj.weight","mtp.layers.0.self_attn.o_proj.weight.bf16","9165a161837a5d4489a838279805b15dd5b5827f1d3ac2f3f4067a71131a5fd7","BF16",{5120,6144},2,62914560ULL},
    {"mtp.layers.0.self_attn.q_norm.weight","mtp.layers.0.self_attn.q_norm.weight.bf16","76aae220c35e2dea96f0985239b719fdcab93e208add6c32ca399b1166ec444e","BF16",{256,0},1,512ULL},
    {"mtp.layers.0.self_attn.q_proj.weight","mtp.layers.0.self_attn.q_proj.weight.bf16","8b27ef96b91e0b0564f82f11d9010efee6aa40a0eaa1900336bf597f767e7c98","BF16",{12288,5120},2,125829120ULL},
    {"mtp.layers.0.self_attn.v_proj.weight","mtp.layers.0.self_attn.v_proj.weight.bf16","9606be457a48d7d9a78d72f255246f4e346845d752c1e82e41e14728255c5e13","BF16",{1024,5120},2,10485760ULL},
    {"mtp.norm.weight","mtp.norm.weight.bf16","414fb74a971b168fb9a073c3486cbc61c46e992757179e724a345bbf56896fb1","BF16",{5120,0},1,10240ULL},
    {"mtp.pre_fc_norm_embedding.weight","mtp.pre_fc_norm_embedding.weight.bf16","9b03e3af7824cd765abdcfc21da960c25f3c7ee1294ce25c226f0ebc5ff39998","BF16",{5120,0},1,10240ULL},
    {"mtp.pre_fc_norm_hidden.weight","mtp.pre_fc_norm_hidden.weight.bf16","f2e1aa414ce84d89d016f2260923f7d47eb9827be043d1823dc6e783e4205efe","BF16",{5120,0},1,10240ULL},
}};
inline const Pin &pin(std::string_view name) {
  const auto found=std::find_if(kPins.begin(),kPins.end(),[&](const auto &x){return x.name==name;});
  if(found==kPins.end())throw std::runtime_error("Q10 role absent from actual authenticated header");return *found;
}
inline std::array<qwen_gptq_projection_fragment::Names,7> target_projection_names() {
  return {{
    {"model.language_model.layers.63.self_attn.q_proj.qweight","model.language_model.layers.63.self_attn.q_proj.qzeros","model.language_model.layers.63.self_attn.q_proj.scales","model.language_model.layers.63.self_attn.q_proj.g_idx",64},
    {"model.language_model.layers.63.self_attn.k_proj.qweight","model.language_model.layers.63.self_attn.k_proj.qzeros","model.language_model.layers.63.self_attn.k_proj.scales","model.language_model.layers.63.self_attn.k_proj.g_idx",64},
    {"model.language_model.layers.63.self_attn.v_proj.qweight","model.language_model.layers.63.self_attn.v_proj.qzeros","model.language_model.layers.63.self_attn.v_proj.scales","model.language_model.layers.63.self_attn.v_proj.g_idx",64},
    {"model.language_model.layers.63.self_attn.o_proj.qweight","model.language_model.layers.63.self_attn.o_proj.qzeros","model.language_model.layers.63.self_attn.o_proj.scales","model.language_model.layers.63.self_attn.o_proj.g_idx",64},
    {"model.language_model.layers.63.mlp.gate_proj.qweight","model.language_model.layers.63.mlp.gate_proj.qzeros","model.language_model.layers.63.mlp.gate_proj.scales","model.language_model.layers.63.mlp.gate_proj.g_idx",64},
    {"model.language_model.layers.63.mlp.up_proj.qweight","model.language_model.layers.63.mlp.up_proj.qzeros","model.language_model.layers.63.mlp.up_proj.scales","model.language_model.layers.63.mlp.up_proj.g_idx",64},
    {"model.language_model.layers.63.mlp.down_proj.qweight","model.language_model.layers.63.mlp.down_proj.qzeros","model.language_model.layers.63.mlp.down_proj.scales","model.language_model.layers.63.mlp.down_proj.g_idx",64},
  }};
}
inline std::vector<roles::Spec> specs() {
  auto result=roles::dense_specs(kGeometry,kIntermediate,kVocabulary,kNextnFiles,kVocabularyNames);result.reserve(kPins.size());
  const auto names=target_projection_names();
  constexpr std::array<std::int64_t,7> outputs{12288,1024,1024,5120,17408,17408,5120},widths{5120,5120,5120,6144,5120,5120,17408};
  for(std::size_t slot=0;slot<names.size();++slot) {
    const auto &p=names[slot];const std::array ids{p.qweight,p.qzeros,p.scales,p.group_index};std::array<roles::PinnedFile,4> files;
    for(std::size_t n=0;n<4;++n){const auto &x=pin(ids[n]);files[n]={x.file,x.sha256};}
    const auto quartet=roles::gptq_projection_specs(outputs[slot],widths[slot],p.group_size,ids,files);
    result.insert(result.end(),quartet.begin(),quartet.end());
  }
  {const auto &x=pin("model.language_model.layers.63.input_layernorm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({5120},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.63.self_attn.q_norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({256},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.63.self_attn.k_norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({256},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.layers.63.post_attention_layernorm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({5120},hyle::compute::DataType::kBFloat16)});}
  {const auto &x=pin("model.language_model.norm.weight");result.push_back({x.name,x.file,x.sha256,roles::sem::dense({5120},hyle::compute::DataType::kBFloat16)});}
  if(result.size()!=kPins.size())throw std::runtime_error("original GPTQ source requires its unique physical roles");std::uint64_t bytes=0;
  for(std::size_t slot=0;slot<result.size();++slot) {
    const auto &s=result[slot];const auto &p=pin(s.name);const auto &d=s.description;
    const auto type=d.data_type()==hyle::compute::DataType::kBFloat16?"BF16":d.data_type()==hyle::compute::DataType::kFloat16?"F16":d.data_type()==hyle::compute::DataType::kInt32?"I32":"unsupported";
    if(s.file!=p.file||s.sha256!=p.sha256||p.dtype!=type||d.rank()!=p.rank||
        !std::equal(d.dimensions().begin(),d.dimensions().end(),p.shape.begin())||
        qwen_original_mtp_roles::detail::take(d.required_bytes(),"Q10 actual role extent")!=p.bytes)
      throw std::runtime_error("Q10 typed role differs from actual name/dtype/shape/bytes/SHA");
    for(std::size_t previous=0;previous<slot;++previous)if(result[previous].name==s.name)throw std::runtime_error("Q10 physical role cannot be duplicated");
    bytes+=p.bytes;
  }
  if(bytes!=kOriginalBytes)throw std::runtime_error("Q10 original source total differs");return result;
}
} // namespace qwen_bfloat_original_artifacts::q10
