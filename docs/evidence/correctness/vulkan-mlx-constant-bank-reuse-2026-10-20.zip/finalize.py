"""Independently check recorded bank red/green evidence; no compiler or GPU."""
from pathlib import Path
import importlib.util,json,re,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('bank_final_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def recorded_run(directory,filename,expected):
    xml=directory/filename
    tree=ET.parse(xml);cases=tree.findall('.//testcase')
    failed=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases if x.findall('failure')]
    skipped=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases if x.findall('skipped')]
    result=c.read(directory/'tests.result.json')
    assert len(cases)==expected and not skipped
    return dict(cases=len(cases),failed=failed,skipped=skipped,exit=result['exit'],
        names=[x.attrib['classname']+'.'+x.attrib['name'] for x in cases],
        properties={p.attrib['name']:p.attrib['value'] for p in tree.findall('.//property')},
        XML=b.identity(xml),command=b.identity(directory/'tests.command.json'),
        result=b.identity(directory/'tests.result.json')),cases

def main():
    before,cases=recorded_run(S/'before-checks','results.xml',1)
    green,_=recorded_run(S/'validation/new','tests.xml',1)
    neighbors,_=recorded_run(S/'validation/neighbors','tests.xml',11)
    assert before['exit']==1 and len(before['failed'])==1
    assert green['exit']==neighbors['exit']==0 and not green['failed'] and not neighbors['failed']
    assert before['names']==green['names']
    assert before['properties']==dict(mlx_bank_programs='9',mlx_native_bank_aliases='0',mlx_native_bank_copy_fallbacks='4')
    assert green['properties']==dict(mlx_bank_programs='9',mlx_native_bank_aliases='42',mlx_native_bank_copy_fallbacks='4')
    locations={}
    for case in cases:
        for failure in case.findall('failure'):
            match=re.search(r'^.*?iree_test\.cc:(\d+)',failure.attrib['message'],re.M)
            assert match
            line=match.group(1);locations[line]=locations.get(line,0)+1
    assert locations=={'101':14,'108':42,'111':42,'112':42,'156':1},locations
    test=c.read(S/'before-checks/bank-test-identity.json')
    assert b.same(test['source']) and b.same(test['object'])
    assert all(b.same(d) for d in test['dependencies'])
    freezes=c.read(S/'core/source-freeze.json')
    for row in freezes['files']:
        current=b.identity(ROOT/row['path'])
        assert current['sha256']==row['sha256'] and current['bytes']==row['bytes']
        assert (S/'core/after'/row['path']).read_bytes()==(ROOT/row['path']).read_bytes()
        assert (S/'core/before'/row['path']).read_bytes()==(S/'before'/row['path']).read_bytes()
    products=[]
    for tag in ('compute_route_vulkan-vulkan_iree','compute_provider_iree_vulkan-native_program'):
        receipt=S/'checks'/(tag+'-identity.json');owner=c.read(receipt)
        assert b.same(owner['source']) and b.same(owner['object']) and all(b.same(d) for d in owner['dependencies'])
        compile_result=c.read(S/'checks'/(tag+'-compile.result.json'))
        assert compile_result['exit']==0
        products.append(dict(receipt=b.identity(receipt),source=owner['source'],object=owner['object'],dependencies=len(owner['dependencies']),compile_result=b.identity(S/'checks'/(tag+'-compile.result.json'))))
    old=c.read(S/'before-checks/link-plan.json');new=c.read(S/'checks/link-plan.json')
    for row in [*old['inputs'],*new['inputs']]:assert b.same(row),row
    assert len(old['inputs'])==len(new['inputs'])
    old_inputs={c.key(x['path']):x for x in old['inputs']};new_inputs={c.key(x['path']):x for x in new['inputs']}
    removed=[x for key,x in old_inputs.items() if key not in new_inputs]
    added=[x for key,x in new_inputs.items() if key not in old_inputs]
    changed=[dict(before=row,after=new_inputs[key]) for key,row in old_inputs.items() if key in new_inputs and row!=new_inputs[key]]
    assert len(removed)==len(added)==2 and not changed
    assert test['object'] in old['inputs'] and test['object'] in new['inputs']
    for p in (S/'before-checks/link.result.json',S/'checks/link.result.json'):assert c.read(p)['exit']==0
    assert c.read(S/'attempt1/bank-test-compile.result.json')['exit']==2
    assert c.read(S/'before-checks/bank-test-compile.result.json')['exit']==0
    image=c.read(S/'checks/image.json');assert b.same(image)
    result=dict(passed=True,scope='Vulkan immutable MLX original-bank native reuse; CPU/CUDA/Apple math paths unchanged.',
        before=dict(before,failure_count=141,failure_locations=locations,mathematical_or_lifetime_failures=0,proof=b.identity(S/'before-checks/structural-red-proof.json')),
        after=green,neighbors=neighbors,
        bank_journey=dict(actual_programs=9,semantic_families=7,
            family_ports={'affine linear/grouped':[1,2,3],'affine embedding':[0,1,2],'MX4/MX8 linear/grouped':[1,2]},
            invocation_slots_per_program=2,successful_submissions_per_bank_run=27,retained_output_rejections_per_bank_run=9,
            eligible_bank_aliases_before=0,eligible_bank_aliases_after=42,
            fallback_scenarios=2,fallback_kind=['one affine-linear scale metadata View','one opaque borrow_ready scale metadata import'],
            fallback_input_spans_across_two_slots=4,
            mutable_inputs='Only A/IDs bind/rebind. Changed Inputs retains original codes/scales/biases/exponents before scalar oracle calculation.',
            lifetimes='Argument/resident/Program copies dropped before replay; banks stay alive through slots; old outputs survive sibling replay and Invocation disposal; final bank weak owners expire.'),
        exact_same_test_object=dict(verified=True,source=test['source'],object=test['object'],receipt=b.identity(S/'before-checks/bank-test-identity.json'),dependency_count=len(test['dependencies']),current_dependency_drift=0),
        link_closure=dict(before=b.identity(S/'before-checks/link-plan.json'),after=b.identity(S/'checks/link-plan.json'),actual_inputs_per_image=len(new['inputs']),changed_existing_input_bytes=changed,removed_product_objects=removed,added_product_objects=added,all_actual_input_SHA_match=True,image=image),
        product_owners=products,product_source_freeze=b.identity(S/'core/source-freeze.json'),test_source_freeze=b.identity(S/'test-source-freeze.json'),source_diff=b.identity(S/'core/source.diff'),test_diff=b.identity(S/'test.diff'),
        actual_counts=dict(compiler_attempts=4,successful_product_CXX=2,successful_test_CXX=1,failed_test_CXX=1,distinct_translation_units=3,links=2,GPU_processes=3,before_GPU_processes=1,after_GPU_processes=1,neighbors_GPU_processes=1,new_green_gtests=1,neighbor_green_gtests=11,green_skips=0,SDK_rebuilds=0,NVCC=0,module_regeneration=0,header_changes=0,ABI_changes=0),
        first_error=dict(kind='Test called nonexistent Context::borrow; changed only to the existing Context::borrow_ready.',source=b.identity(S/'attempt1/iree_test.cc'),result=b.identity(S/'attempt1/bank-test-compile.result.json')),
        independent_review=dict(blockers=[],design='Existing BorrowedInput/input_view/HAL owner path reused only for semantic immutable bank ports, preserving original scalar dtype/shape and duplicate/range/device/alignment validation. A/IDs remain private dynamic inputs; View/import copies remain per-port fallbacks.',scope='Source-only review plus independently re-read recorded XML/receipts; no new compiler or GPU execution.'),
        limitations=['Root-owned, ready immutable native bank buffers only. Lease/weight/View/opaque imports retain copy fallback.', 'Native VM context/input wrappers and selected-group workspaces remain per Invocation; no global cache or executor added.', 'No full artifact/model quality, throughput/latency, peak-memory measurement, other GPU or other platform acceptance.', 'The test records VkBuffer/offset/span identity and format/kind/counts, not the selected GPU UUID; actual hardware provenance remains the existing Windows Vulkan validation context.'])
    c.save(S/'final-validation.json',result)
    print(json.dumps(b.identity(S/'final-validation.json')),flush=True)

if __name__=='__main__':main()
