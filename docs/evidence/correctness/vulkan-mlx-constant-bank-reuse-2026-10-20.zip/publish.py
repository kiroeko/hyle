"""Retain bank reuse source and actual red/green, excluding rebuildable payloads."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

S = Path(__file__).resolve().parent
ROOT = S.parents[2]


def read(p):
    return json.loads(p.read_text(encoding='utf-8'))


def identity(p):
    data = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')


def main():
    final = read(S/'final-validation.json')
    assert final['passed']
    for folder, count in [('validation/new', 1), ('validation/neighbors', 11)]:
        cases = ET.parse(S/folder/'tests.xml').findall('.//testcase')
        assert len(cases) == count
        assert not any(c.findall('failure') or c.findall('skipped') for c in cases)
    old_xml = list((S/'before-checks').glob('*.xml'))
    assert len(old_xml) == 1
    old = ET.parse(old_xml[0]).findall('.//testcase')
    assert len(old) == 1 and len(old[0].findall('failure')) == 141
    test = read(S/'before-checks/bank-test-identity.json')
    assert identity(Path(test['source']['path'])) == test['source']
    assert identity(Path(test['object']['path'])) == test['object']
    assert test['object'] in read(S/'checks/link-plan.json')['inputs']
    for row in read(S/'checks/link-plan.json')['inputs']:
        assert identity(Path(row['path'])) == row, row['path']
    for row in read(S/'core/source-freeze.json')['files']:
        actual = identity(ROOT/row['path'])
        assert actual['sha256'] == row['sha256'] and actual['bytes'] == row['bytes']
    for rel in ['docs/architecture/compute-design.md', 'docs/implementation/model-operators.md',
                'docs/developer/current-work.md']:
        target = S/'snapshot'/rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((ROOT/rel).read_bytes())
    files = sorted((p for p in S.rglob('*') if p.is_file() and
        p.suffix in {'.cc','.h','.py','.json','.log','.xml','.diff','.md'} and
        not set(p.relative_to(S).parts) & {'tmp','__pycache__'} and
        p.name not in {'publication.json','payload-sha256.json'}),
        key=lambda p: p.relative_to(S).as_posix())
    dest = ROOT/'docs/evidence/correctness/vulkan-mlx-constant-bank-reuse-2026-10-20.zip'
    payloads = []
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            row = dict(**identity(path), member=path.relative_to(S).as_posix())
            archive.writestr(row['member'], path.read_bytes())
            payloads.append(row)
        archive.writestr('payload-sha256.json', json.dumps(payloads).encode())
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        assert all(hashlib.sha256(archive.read(row['member'])).hexdigest() == row['sha256'] for row in payloads)
    report = dict(date='2026-10-20', status='executed',
        problem='Ready immutable MLX banks were copied into separate original-typed IREE input allocations for every Invocation.',
        fix='Reuse the existing readonly BorrowedInput path for actual affine/MX bank ports; native shape/type validation and retained Buffer lifetime remain authoritative.',
        policy='Only known owned ready immutable DeviceLocal roots qualify. Dynamic inputs and uncertain views/imports retain the original copy path. No runtime provider search, cache, executor, shader or precision changes.',
        observation='The same regression object changes from zero to42 actual original VkBuffer aliases across nine small programs/two slots. Four explicit copied spans remain for view/import fallback. These counts are not whole-model peak memory or throughput.',
        actual=final, limitations=final['limitations'],
        archive=dict(**identity(dest), payloads=len(payloads), CRC_checked=True, all_payload_SHA256_checked=True))
    save(dest.with_suffix('.json'), report)
    save(S/'publication.json', dict(passed=True, report=identity(dest.with_suffix('.json')), archive=identity(dest)))
    print('BANK_REUSE_EVIDENCE_PUBLISHED', len(payloads), dest.stat().st_size, flush=True)


if __name__ == '__main__':
    main()
