"""Run only the bank regression and its native numerical/lifetime neighbors."""
from pathlib import Path
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
spec = importlib.util.spec_from_file_location('bank_run_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
phase = sys.argv[1]
names = ['VulkanIree.ImmutableMlxBanksShareNativeStorageAcrossInvocationSlots'] if phase == 'new' else [
    'VulkanGraph.OrdinaryMixedMlxMoeUsesSharedInputsAndOnlyPublishesFinalResults',
    'VulkanGraph.OfficialConstantBanksBorrowOwnedStorageAcrossSlots',
    'VulkanIree.MlxGroupedSharesOriginalActivationAcrossSelectedExperts',
    'VulkanGraph.MlxGroupedSharesOriginalActivationAcrossSelectedExperts',
    'VulkanIree.OriginalMlxBatchPreservesGroupsSourceTypesAndCheckedSlots',
    'VulkanGraph.OriginalMlxBatchUsesOrdinaryTypedNodesAndCheckedSlots',
    'VulkanIree.OriginalMlxAffineWidthsUseContinuousBitstreamsAndCheckedRebinding',
    'VulkanGraph.OriginalMlxAffineWidthsUseContinuousBitstreamsAndCheckedRebinding',
    'VulkanIree.OriginalMlxConstantsKeepBanksAcrossRebindingAndSlots',
    'VulkanGraph.OriginalMlxConstantsKeepBanksAcrossRebindingAndSlots',
    'VulkanIree.OriginalMlxAffineWidthsKeepDecodedWeightsInF32BeforeDot']
out = S/'validation'/phase
out.mkdir(parents=True, exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
image = c.read(S/'checks/image.json')
assert h.same_identity(image)
for row in c.read(S/'checks/link-plan.json')['inputs']:
    assert h.same_identity(row), row['path']
for row in c.read(S/'core/source-freeze.json')['files']:
    assert b.identity(A.parents[1]/row['path'])['sha256'] == row['sha256']
test = c.read(S/'before-checks/bank-test-identity.json')
assert h.same_identity(test['source']) and h.same_identity(test['object'])
env = os.environ.copy()
env['PATH'] = c.read(S/'checks/runtime-environment.json')['PATH']
env['TEMP'] = env['TMP'] = str(out/'tmp')
command = [image['path'], '--gtest_filter='+':'.join(names), '--gtest_output=xml:'+str(out/'tests.xml')]
failure = None
try:
    c.execute('tests', command, env, out)
except RuntimeError as error:
    failure = str(error)
cases = ET.parse(out/'tests.xml').findall('.//testcase')
actual = [case.attrib['classname']+'.'+case.attrib['name'] for case in cases]
failed = [case.attrib['name'] for case in cases if case.findall('failure')]
skipped = [case.attrib['name'] for case in cases if case.findall('skipped')]
passed = not failure and not failed and not skipped and sorted(names) == sorted(actual)
c.save(out/'summary.json', dict(passed=passed, cases=len(cases), failed=failed, skipped=skipped,
    names=actual, image=image, XML=b.identity(out/'tests.xml'), process_error=failure))
print('BANK_'+phase.upper(), 'PASS' if passed else 'FAIL', len(cases), flush=True)
if not passed:
    raise SystemExit(1)
