"""One permanent test owner; actual owner-fixed closure, unchanged before bank product."""
from pathlib import Path
import importlib.util,json,shutil,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('bank_test_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
BASE=A/'vulkan-view-root-owner/checks/link-plan.json'
OUT=S/'before-checks';OUT.mkdir(exist_ok=True);(OUT/'tmp').mkdir(exist_ok=True)
source=ROOT/'tests/compute_route_vulkan/iree_test.cc'
base=c.read(BASE);meta=h.metadata({'vulkan':base});matches=[]
for old in base['inputs']:
 assert b.same(old),old
 recipe=meta.get(c.key(old['path']))
 if recipe and c.key(recipe['source_path'])==c.key(source):matches.append((old,recipe))
assert len(matches)==1,len(matches)
old,recipe=matches[0];tag='bank-test';command=b.host_command(recipe['command'],source,tag,OUT)
env,runtime=b.environment(base['command'],[row['path'] for row in base['inputs']],OUT)
c.save(OUT/'runtime.json',dict(PATH=env['PATH'],runtime=runtime))
frozen=[]
for rel in ('src/compute_route_vulkan/vulkan_iree.cc','src/compute_provider_iree_vulkan/native_program.cc'):
 path=ROOT/rel;target=S/'before'/rel;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==path.read_bytes(),rel
 else:shutil.copyfile(path,target)
 frozen.append(b.identity(path))
test=c.read(S/'test-source-freeze.json')['files'][0];frozen.append({k:test[k] for k in ('path','bytes','sha256')})
def check():
 for row in frozen:assert b.same(row),row
check();c.save(OUT/'plan.json',dict(base=b.identity(BASE),old_object=old,recipe=recipe['recipe'],source=b.identity(source),command=command,frozen=frozen,product_CXX=0,test_CXX=1,SDK_rebuild=False,NVCC=0))
receipt=OUT/'bank-test-identity.json'
if not receipt.exists():
 c.execute('bank-test-compile',command,env,OUT);check();deps=c.read(OUT/'bank-test-deps.json')['Data']
 c.save(receipt,dict(command=command,source=b.identity(source),object=b.identity(OUT/'bank-test.obj'),dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]))
else:
 record=c.read(receipt);assert b.same(record['source']) and b.same(record['object']) and all(b.same(d) for d in record['dependencies'])
print('BANK_TEST_COMPILED',json.dumps(b.identity(receipt)),flush=True)
if '--link' not in sys.argv:raise SystemExit(0)
new=c.read(receipt)['object'];inputs=[new if c.key(row['path'])==c.key(old['path']) else row for row in base['inputs']]
image=OUT/'bank-before.exe';link=[new['path'] if c.key(arg)==c.key(old['path']) else arg for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]+['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
for row in inputs:assert b.same(row),row
check();c.save(OUT/'link-plan.json',dict(command=link,inputs=inputs));c.execute('link',link,env,OUT);c.save(OUT/'image.json',b.identity(image))
if '--test' not in sys.argv:raise SystemExit(0)
try:c.execute('tests',[str(image),'--gtest_filter=VulkanIree.ImmutableMlxBanksShareNativeStorageAcrossInvocationSlots','--gtest_output=xml:'+str(OUT/'results.xml')],env,OUT)
except RuntimeError:pass
check();cases=ET.parse(OUT/'results.xml').findall('.//testcase');failures=[x.attrib for x in cases if x.findall('failure')];skipped=[x.attrib for x in cases if x.findall('skipped')];messages=[f.text for x in cases for f in x.findall('failure')]
summary=dict(passed=len(cases)==1 and not failures and not skipped and c.read(OUT/'tests.result.json')['exit']==0,cases=len(cases),failed=failures,skipped=skipped,failure_count=len(messages),failure_messages=messages,properties=[dict(p.attrib) for x in cases for p in x.findall('./properties/property')],test_source=b.identity(source),test_object=new,base_owner_fix=b.identity(A/'vulkan-view-root-owner/source-freeze.json'),bank_product_sources=frozen[:2],actual_link_inputs=len(inputs),product_CXX=0,test_CXX=1,links=1,GPU_runs=1,SDK_rebuild=False,NVCC=0)
c.save(OUT/'summary.json',summary);print('BANK_BEFORE_RESULT',summary['passed'],len(cases),len(messages),len(skipped),flush=True)
if not summary['passed']:raise SystemExit(1)
