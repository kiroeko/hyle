"""Refresh the two bank binding implementations, retaining the exact red test object."""
from pathlib import Path
import concurrent.futures
import difflib
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
out = S/'checks'
out.mkdir(exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('bank_build_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
base_path = S/'before-checks/link-plan.json'
base = c.read(base_path)
for row in base['inputs']:
    assert h.same_identity(row), row['path']
env, runtime = b.environment(base['command'], [r['path'] for r in base['inputs']], out)
c.save(out/'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
rows = []
for tag in ('compute_route_vulkan-vulkan_iree', 'compute_provider_iree_vulkan-native_program'):
    recipe = A/'mlx-moe-typed-inputs/vulkan/checks'/(tag+'-identity.json')
    rec = c.read(recipe)
    source = Path(rec['source']['path'])
    assert rec['object'] in base['inputs']
    rows.append(dict(tag=tag, source=b.identity(source), recipe=b.identity(recipe),
        old_object=rec['object'], command=b.host_command(rec['command'], source, tag, out)))
c.save(S/'core/source-freeze.json', dict(files=[dict(path=str(Path(r['source']['path']).relative_to(ROOT)).replace('\\','/'),
    bytes=r['source']['bytes'], sha256=r['source']['sha256']) for r in rows],
    public_or_private_ABI_changes=False, SDK_or_module_changes=False))
diff = ''
for row in rows:
    source = Path(row['source']['path'])
    rel = source.relative_to(ROOT)
    before = S/'core/before'/rel
    snapshot = S/'core/after'/rel
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(source.read_bytes())
    diff += ''.join(difflib.unified_diff(before.read_text().splitlines(True), source.read_text().splitlines(True),
        fromfile='before/'+rel.as_posix(), tofile='after/'+rel.as_posix()))
(S/'core/source.diff').write_text(diff, encoding='utf-8')
c.save(out/'plan.json', dict(products=rows, base=b.identity(base_path), CXX=2, SDK=0, NVCC=0,
    unchanged_red_test_object=c.read(S/'before-checks/bank-test-identity.json')['object']))


def compile_one(row):
    assert h.same_identity(row['source'])
    c.execute(row['tag']+'-compile', row['command'], env, out)
    assert h.same_identity(row['source'])
    dep = out/(row['tag']+'-deps.json')
    data = c.read(dep)['Data']
    result = dict(command=row['command'], source=row['source'], recipe=row['recipe'],
        object=b.identity(out/(row['tag']+'.obj')), source_dependencies=b.identity(dep),
        dependencies=[b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])])
    c.save(out/(row['tag']+'-identity.json'), result)
    return result


with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    products = list(pool.map(compile_one, rows))
replacements = {c.key(row['old_object']['path']): result['object'] for row, result in zip(rows, products)}
command = [replacements.get(c.key(arg), dict(path=arg))['path'] for arg in base['command']
    if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
image = out/'vulkan.exe'
command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
lookup = {c.key(r['path']): r for r in [*base['inputs'], *replacements.values()]}
inputs = [lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj', '.lib')]
for row in inputs:
    assert h.same_identity(row)
c.save(out/'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path)))
c.execute('link', command, env, out)
c.save(out/'image.json', b.identity(image))
c.save(out/'summary.json', dict(passed=True, product_CXX=2, test_CXX=0, links=1, SDK=0, NVCC=0,
    unchanged_test_object=True, image=b.identity(image)))
print('BANK_BINDING_BUILT', flush=True)
