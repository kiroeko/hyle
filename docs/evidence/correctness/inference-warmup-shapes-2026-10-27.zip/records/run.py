"""Three tiny CUDA warm-shape checks plus one pre-Model parser refusal."""
from pathlib import Path
import ast
import importlib.util
import json
import re
import subprocess
import sys
import time
import traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[2]
spec=importlib.util.spec_from_file_location('warmup_build',W/'build.py')
build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
b=build.b
spec=importlib.util.spec_from_file_location('prior_cli_checks',W.parent/'cli/run.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)


def normalize_functions():
    path=R/'.scratch/inference-current-closure-20261026/behavior.py'
    tree=ast.parse(path.read_text(encoding='utf-8'));ns={}
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('normalize','differences')]
    assert len(nodes)==2
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path)+':pure-only','exec'),ns)
    return ns,b.pin(path)


def main():
    assert sys.argv[1:]==['run'] and not (W/'run-plan.json').exists()
    ready=b.read(W/'ready.json');b.exact(ready['image']);b.exact(ready['source'])
    basecase=next(x for x in b.read(W.parent/'cli/run-plan2.json')['commands'] if x['name']=='b2-multiturn')
    cases=[]
    for policy in ('lazy','planned'):
        command=list(basecase['command']);command[0]=ready['image']['path'];command+=['--warmup-shapes',policy]
        cases.append(dict(name=policy,command=command,policy=policy,expected_turns=basecase['expected_turns']))
    mtp=next(x for x in b.read(R/'.scratch/inference-engine-slot-state-20261027/run-commands.json') if x['name']=='cuda-cli-mtp-k2')
    command=list(mtp['argv']);command[0]=ready['image']['path'];command+=['--warmup-shapes','planned']
    cases.append(dict(name='mtp-k2-planned',policy='planned',command=command))
    invalid=[ready['image']['path'],'--inputs',str(W.parent/'cli/inputs'),'--warmup-shapes','eager']
    b.save(W/'run-plan.json',dict(image=ready['image'],source=ready['source'],cases=cases,invalid_policy=invalid,
        cached_inputs=b.pin(W.parent/'cli/run-plan2.json'),mtp_inputs=b.pin(Path(command[command.index('--inputs')+1])/'weights.tsv'),
        scope='Carrier preparation only;3 real tiny CUDA processes+1 pre-Model parser. No benchmark/capture warmup/quality/varlen or cross-width bitwise claim.'))
    helper=b.helper();cl=b.read(W/'compile-plan.json')['command'][0]
    env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    env['PATH']=b.read(ready['runtime']['path'])['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    runs=[];reports={};normalizer,normalizer_pin=normalize_functions()
    for case in cases:
        folder=W/'runs'/case['name'];process=helper.execute(case['command'],env,folder,timeout=90)
        raw=json.loads((folder/'stdout.log').read_text(encoding='utf-8-sig'));b.save(folder/'report.json',raw)
        stderr=(folder/'stderr.log').read_text(encoding='utf-8-sig');lines=stderr.splitlines()
        ready_at=next(i for i,x in enumerate(lines) if x.startswith('generation_shape_prepare_seconds='))
        execution_at=next(i for i,x in enumerate(lines) if x.startswith('generation_session '))
        assert ready_at<execution_at
        warm=[(i,re.search(r'^shape_warmup policy=planned shapes=(\d+) seconds=([^ ]+)$',x)) for i,x in enumerate(lines) if x.startswith('shape_warmup ')]
        compiled=[i for i,x in enumerate(lines) if x.startswith('compiled T=')]
        facts=dict(ready_line=ready_at,first_request_line=execution_at,compiled_before_ready=sum(i<ready_at for i in compiled),compiled_after_ready=sum(i>ready_at for i in compiled))
        if case['policy']=='planned':
            assert len(warm)==1 and warm[0][1] and warm[0][0]<ready_at
            facts['planned_shapes']=int(warm[0][1][1]);assert facts['planned_shapes']>0
            assert facts['compiled_after_ready']==0,'Actual finite shape was still cold at the first request'
        else:assert not warm
        if case['name']!='mtp-k2-planned':
            facts['ledger']=prior.check_regular(raw,dict(case,name='b2-multiturn'))
            reports[case['name']]=raw
            if case['policy']=='planned':assert facts['compiled_before_ready']>=facts['planned_shapes']
        else:
            assert raw['backend']=='cuda' and raw['mtp'] is True and raw['mtp_max_drafts']==2
            assert raw['generated_tokens']==8 and raw['admitted_requests']==raw['retired_requests']==1
            assert raw['live_committed_versions']==0 and raw['cold_exact_admissions']==0
            session=raw['sessions'][0]['result'];assert len(session['generated_ids'])==8 and session['sampling_draw_cursor']==0
            facts['generated_ids']=session['generated_ids'];facts['actual_target_rows']=raw['actual_target_rows'];facts['actual_graph_calls']=raw['actual_graph_calls']
        b.save(folder/'facts.json',dict(status='PASS',image=ready['image'],process=process,facts=facts))
        runs.append(dict(name=case['name'],process=process,facts=b.pin(folder/'facts.json')))
        print('PASS',case['name'],json.dumps(facts),flush=True)
    delta=normalizer['differences'](normalizer['normalize'](reports['lazy']),normalizer['normalize'](reports['planned']))
    b.save(W/'lazy-planned-nontime-differences.json',delta)
    assert not delta,'Complete non-clock report changed; preserve before interpreting'
    folder=W/'invalid-policy';folder.mkdir(parents=True,exist_ok=False)
    start=time.perf_counter();p=subprocess.Popen(invalid,cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    stdout,stderr=p.communicate(timeout=15);(folder/'stdout.log').write_bytes(stdout);(folder/'stderr.log').write_bytes(stderr)
    refusal=dict(command=invalid,pid=p.pid,exit=p.returncode,seconds=time.perf_counter()-start)
    b.save(folder/'process.json',refusal)
    assert p.returncode==1 and b'--warmup-shapes requires lazy or planned' in stderr and b'weights_load_seconds=' not in stderr
    runs.append(dict(name='invalid-policy',process=refusal))
    b.save(W/'summary.json',dict(status='THREE_TINY_CUDA_AND_ONE_PARSER_PASS',source=ready['source'],image=ready['image'],runs=runs,
        complete_lazy_planned_nonclock_differences=0,normalization=normalizer_pin,counts=dict(CXX_TUs=1,links=1,model_processes=3,parser_processes=1,SDK=0,NVCC=0,downloads=0),
        scope='Preparation of eligible full ExecutionShape keys, no inference in the warmup method. CLI functional equivalence only; log shapes includes eligible already-existing carriers. No device capture warmup or performance conclusion.'))
    print('PASS_ALL',json.dumps(b.pin(W/'summary.json')),flush=True)


if __name__=='__main__':
    try:main()
    except BaseException:
        b.save(W/'run-failure.json',dict(error=traceback.format_exc(),note='First failure retained, no automatic retry'))
        raise
