"""One frozen Model TU and one link, exact last-CLI closure; no inference."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[2]
B=W.parent/'cli'
spec=importlib.util.spec_from_file_location('previous_cli_build',B/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m


def main():
    assert sys.argv[1:]==['build'] and not (W/'plan.json').exists()
    source=R/'engine/models/qwen35/main.cc'
    assert b.pin(source)['sha256']=='45b124b0febe4bf32e31c7ab207877696379f224d71461ce905dcb61ccb71cff'
    baseline=b.read(B/'ready.json')
    retained=[x for x in b.read(baseline['inputs']['path']) if b.key(x['path'])!=b.key(baseline['object']['path'])]
    assert len(retained)==223
    command=m.command(B/'compile/command.json',source,W/'compile')
    b.save(W/'compile-plan.json',dict(command=command,cwd=str(R),timeout_seconds=180))
    frozen=m.c.closure([source],[W/'compile-plan.json'])
    b.save(W/'source-freeze.json',frozen)
    (W/'main.cc').write_bytes(source.read_bytes())
    image=W/'image/hyle.exe';link=[];replaced=0
    for arg in b.read(B/'link-process/command.json')['command']:
        if b.key(arg)==b.key(baseline['object']['path']):arg=str(W/'compile/unit.obj');replaced+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        link.append(arg)
    assert replaced==1
    b.save(W/'link-plan.json',dict(command=link,cwd=str(R),timeout_seconds=120))
    b.save(W/'retained-inputs.json',retained)
    b.save(W/'plan.json',dict(source=b.pin(source),snapshot=b.pin(W/'main.cc'),baseline=b.pin(B/'ready.json'),
        compile=b.pin(W/'compile-plan.json'),link=b.pin(W/'link-plan.json'),source_freeze=b.pin(W/'source-freeze.json'),
        counts=dict(CXX_TUs=1,links=1,reused_inputs=223,SDK=0,NVCC=0,downloads=0)))
    helper=b.helper();env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=helper.execute(command,env,W/'compile',timeout=180)
    raw=b.read(W/'compile/dependencies.json')['Data']
    deps=[b.pin(p) for p in dict.fromkeys([raw['Source'],*raw['Includes']])]
    b.save(W/'compile/actual-dependencies.json',deps)
    own={b.key(x['path']):x for x in frozen}
    for dep in deps:
        p=Path(dep['path'])
        if p.is_relative_to(R) and not p.is_relative_to(R/'.scratch'):assert own[b.key(p)]['sha256']==dep['sha256'],str(p)
    for x in frozen:b.exact(x)
    for x in retained:b.exact(x)
    image.parent.mkdir(parents=True,exist_ok=True)
    linked=helper.execute(link,env,W/'link',timeout=120)
    b.save(W/'link-inputs.json',retained+[b.pin(W/'compile/unit.obj')])
    runtime=b.read(baseline['runtime']['path']);native=runtime['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_cpu_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH']
    b.save(W/'runtime.json',runtime)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),source=b.pin(source),object=b.pin(W/'compile/unit.obj'),
        actual_dependencies=b.pin(W/'compile/actual-dependencies.json'),compile=compiled,link=linked,
        inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json')))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)


if __name__=='__main__':
    try:main()
    except BaseException:
        b.save(W/'build-failure.json',dict(error=traceback.format_exc(),note='First failure retained; no automatic retry'))
        raise
