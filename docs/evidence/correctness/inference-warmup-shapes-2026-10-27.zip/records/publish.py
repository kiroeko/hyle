"""Offline evidence only; no imports or execution of build/model scripts."""
from pathlib import Path
import hashlib
import json
import zipfile
W=Path(__file__).resolve().parent
R=W.parents[2]
STEM='inference-warmup-shapes-2026-10-27'


def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return dict(path=str(Path(p).resolve()),**digest(Path(p).read_bytes()))


def main():
    destination=R/'docs/evidence/correctness'
    report_path,archive=(destination/(STEM+ext) for ext in ('.json','.zip'))
    # Parent added the fixed branch after the first finite publication.
    # Preserve its identity, then replace the same evidence with all observed runs.
    previous=W/'publication-before-fixed.json'
    if report_path.exists() and not previous.exists():
        previous.write_text(json.dumps(dict(report=pin(report_path),archive=pin(archive),
            reason='Authorized addition of one fixed-replay planned functional case; no rebuild or repeated prior runs.'),indent=2)+'\n',encoding='utf-8')
    ready,summary=read(W/'ready.json'),read(W/'summary.json')
    assert ready['source']['sha256']=='45b124b0febe4bf32e31c7ab207877696379f224d71461ce905dcb61ccb71cff'
    assert pin(W/'main.cc')['sha256']==ready['source']['sha256']
    assert summary['status']=='THREE_TINY_CUDA_AND_ONE_PARSER_PASS'
    assert summary['complete_lazy_planned_nonclock_differences']==0
    assert ready['compile']['exit']==ready['link']['exit']==0 and len(read(W/'retained-inputs.json'))==223
    observations={name:read(W/'runs'/name/'facts.json') for name in ('lazy','planned','mtp-k2-planned','fixed-planned')}
    assert all(x['status']=='PASS' and x['process']['exit']==0 for x in observations.values())
    fixed=observations['fixed-planned']['facts']
    assert fixed['planned_shapes']==2 and fixed['compiled_before_ready']==2 and fixed['compiled_after_ready']==0
    assert fixed['warmup_line']<fixed['ready_line'] and fixed['decode_input_ids']==[4,5]
    assert fixed['actual_graph_calls']==3 and fixed['actual_target_rows']==5 and fixed['cold_exact_admissions']==0
    refusal=read(W/'invalid-policy/process.json');assert refusal['exit']==1
    final_summary=dict(status='FOUR_TINY_CUDA_AND_ONE_PARSER_PASS',initial_summary=pin(W/'summary.json'),
        fixed_addition=pin(W/'runs/fixed-planned/facts.json'),image=ready['image'],
        model_processes=4,parser_processes=1,source=ready['source'],no_additional_build=True)
    (W/'final-summary.json').write_text(json.dumps(final_summary,indent=2)+'\n',encoding='utf-8')
    report=dict(status='PASS_FINITE_PLANNED_CARRIER_PREPARATION',date='2026-10-27',source=ready['source'],image=ready['image'],
        source_snapshot=pin(W/'main.cc'),ready=pin(W/'ready.json'),actual_dependencies=ready['actual_dependencies'],
        counts=dict(CXX_TUs=1,link_processes=1,reused_link_inputs=223,tiny_CUDA_model_processes=4,
            parser_refusals=1,pre_build_source_pin_guards=1,failed_CXX_or_link_processes=0,SDK_builds=0,NVCC=0,downloads=0),
        implementation='prepare_planned_execution traverses existing positive-use ExecutionShape keys with original B/T/role/completion/sampling identity. planned runs before ready; default lazy preserves existing minimum carrier setup. No second executor, Session, fake input, submit or state/RNG/cache publication in the warmup method.',
        cold_source_review=['All family/replay plans precede carrier preparation; known keys use original idempotent prepare_execution.',
            'The logged shapes count is eligible complete keys, including already-initialized carriers, not necessarily new allocations.',
            'Unknown suffixes remain subject to the existing idle bounded exact admission; this batch does not claim every context length is prewarmed.'],
        results={name:dict(pid=x['process']['pid'],exit=x['process']['exit'],facts=x['facts']) for name,x in observations.items()},
        lazy_planned=dict(complete_nonclock_report_differences=0,
            includes='All original nonclock work, generated IDs, ledger, RNG, route/cache/resource report fields; no extra memory/counter exclusions.',
            normalizer=summary['normalization'],difference_record=pin(W/'lazy-planned-nontime-differences.json')),
        invalid_policy=dict(pid=refusal['pid'],exit=refusal['exit'],scope='eager rejected before Model construction'),
        pre_build_guard=dict(record=pin(W/'pre-freeze-guard.json'),scope='Root replaced the freeze pin while the script was checking the previous hash. Python guard stopped before any compiler or linker; the final frozen source was compiled once.'),
        reuse=dict(input_record=pin(W/'retained-inputs.json'),baseline=read(W/'plan.json')['baseline'],
            prior_prefill_evidence=pin(R/'docs/evidence/correctness/inference-prefill-chunk-cli-2026-10-27.json')),
        fixed_branch=dict(scope='One separately authorized fixed-replay planned journey on the same built image; input IDs [4,5], one prefill and two decode calls. No prior run repeated.',
            original_three_run_summary=pin(W/'summary.json'),final_summary=pin(W/'final-summary.json')),
        limits=['Four tiny cached untrained CUDA functional journeys plus one parser refusal, not a benchmark/quality/full-model or all-platform matrix.',
            'This is carrier preparation, not device execution or CUDA capture warmup. Dynamic layouts, real lease bindings and prepare_replay still use the original execution path.',
            'No varlen or padding semantics are added. Ordinary Q2 real blocks remain separate StateOnly/EmitNext; finite Q with MTP remains explicitly unsupported.',
            'planned may retain additional Phase IO/readback/Invocation resources. Existing allocation/execution budgets are reused; --cache-bytes is not a total warmup VRAM cap. No physical-memory or speed equality/benefit claim.',
            'The source, dependencies and recorded limits describe this fixed configuration only; no assertion of latest third-party versions.'])
    members,origins={},{}
    def add(name,p):
        p=Path(p);assert name not in members and p.is_file() and p.suffix.lower() in {'.py','.json','.cc','.log','.ids','.schedule','.tsv'}
        members[name]=p.read_bytes();origins[name]=str(p.resolve())
    for p in sorted(W.iterdir()):
        if p.is_file() and p.suffix.lower() in {'.py','.json','.cc'}:add('records/'+p.name,p)
    for folder in ('compile','link','runs','invalid-policy'):
        for p in sorted((W/folder).rglob('*')):
            if p.is_file() and p.suffix.lower() in {'.json','.log'}:add('records/'+p.relative_to(W).as_posix(),p)
    prior=W.parent/'cli'
    for p in [prior/'run.py',prior/'run-plan2.json',prior/'inputs/weights.tsv',prior/'inputs/prompt.ids',prior/'inputs/fixed.ids']:
        add('prior-inputs/'+p.relative_to(prior).as_posix(),p)
    for p in sorted((prior/'cases/b2-multiturn').iterdir()):
        if p.is_file():add('prior-inputs/cases/b2-multiturn/'+p.name,p)
    source=R/'.scratch/inference-engine-slot-state-20261027/run-commands.json'
    add('prior-inputs/mtp-source-commands.json',source)
    for name in ('weights.tsv','prompt.ids'):
        add('prior-inputs/mtp/'+name,R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'/name)
    add('normalizer/behavior.py',summary['normalization']['path'])
    index=dict(members=[dict(member=n,original_path=origins[n],**digest(raw)) for n,raw in sorted(members.items())],
        exclusions='No binary/OBJ/PDB/library, model weight payload, SDK or full source/dependency tree. Metadata manifests refer to existing cached payloads.')
    index_bytes=(json.dumps(index,indent=2,ensure_ascii=False)+'\n').encode()
    destination.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(members.items()):z.writestr(name,raw)
        z.writestr('member-sha256.json',index_bytes)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(members)+1 and z.read('member-sha256.json')==index_bytes
        for name,raw in members.items():assert digest(z.read(name))==digest(raw)
    report['archive']=dict(**pin(archive),members=len(members)+1,CRC_and_member_SHA256_verified=True)
    report_path.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(dict(report=pin(report_path),archive=report['archive'],image=ready['image']),indent=2))


if __name__=='__main__':main()
