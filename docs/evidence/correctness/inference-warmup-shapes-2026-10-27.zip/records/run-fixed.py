"""Only the additionally authorized fixed-input planned carrier branch."""
from pathlib import Path
import importlib.util
import json
import re
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[2]
spec=importlib.util.spec_from_file_location('warmup_build',W/'build.py')
bld=importlib.util.module_from_spec(spec);spec.loader.exec_module(bld)
b=bld.b
ready=b.read(W/'ready.json');b.exact(ready['image']);b.exact(ready['source'])
inputs=W.parent/'cli/inputs'
command=[ready['image']['path'],'--inputs',str(inputs),'--backend','cuda','--capacity','16',
    '--decode-ids',str(inputs/'fixed.ids'),'--sampling','greedy','--mtp','off','--max-sessions','1',
    '--active-sequences','1','--prefix-cache','off','--progress','direct','--replay','commands','--warmup-shapes','planned']
b.save(W/'fixed-plan.json',dict(command=command,image=ready['image'],manifest=b.pin(inputs/'weights.tsv'),
    prompt=b.pin(inputs/'prompt.ids'),fixed_tape=b.pin(inputs/'fixed.ids'),scope='One additional fixed-replay branch function check only; no finite Q, benchmark or capture claim.'))
helper=b.helper();cl=b.read(W/'compile-plan.json')['command'][0]
env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
env['PATH']=b.read(ready['runtime']['path'])['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
folder=W/'runs/fixed-planned';process=helper.execute(command,env,folder,timeout=90)
raw=json.loads((folder/'stdout.log').read_text(encoding='utf-8-sig'));b.save(folder/'report.json',raw)
lines=(folder/'stderr.log').read_text(encoding='utf-8-sig').splitlines()
at=next(i for i,x in enumerate(lines) if x.startswith('initialized model_seconds='))
warm=[(i,re.search(r'^shape_warmup policy=planned shapes=(\d+) seconds=([^ ]+)$',x)) for i,x in enumerate(lines) if x.startswith('shape_warmup ')]
compiled=[i for i,x in enumerate(lines) if x.startswith('compiled T=')]
assert len(warm)==1 and warm[0][1] and warm[0][0]<at and int(warm[0][1][1])>0
assert all(i<at for i in compiled)
assert raw['backend']=='cuda' and raw['mtp'] is False and raw['fixed_decode'] is True
assert raw['decode_input_ids']==[4,5] and raw['generated_tokens']==len(raw['generated_ids'])==3
assert raw['actual_graph_calls']==3 and raw['prefill_graph_calls']==1 and raw['decode_graph_calls']==2
assert raw['prefill_target_rows']==3 and raw['actual_target_rows']==raw['visible_tokens']==5
assert raw['cold_exact_admissions']==0 and raw['sampling_draw_cursor']==0
facts=dict(status='PASS',process=process,image=ready['image'],facts=dict(planned_shapes=int(warm[0][1][1]),
    compiled_before_ready=len(compiled),compiled_after_ready=0,ready_line=at,warmup_line=warm[0][0],
    generated_ids=raw['generated_ids'],decode_input_ids=raw['decode_input_ids'],actual_graph_calls=3,actual_target_rows=5,
    cold_exact_admissions=0,sampling_draw_cursor=0))
b.save(folder/'facts.json',facts)
print(json.dumps(facts,indent=2),flush=True)
