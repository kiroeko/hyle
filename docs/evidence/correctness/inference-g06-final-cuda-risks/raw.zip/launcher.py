from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path.cwd();candidate,attempt=sys.argv[1:3]
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==candidate
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
archive=root/('.scratch/inference-gaps/g06/final-risks-input-'+attempt+'.zip')
assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    inputs=[]
    for name in subprocess.check_output(['git','ls-files'],text=True).splitlines():
        if name.startswith(('evidence/','.scratch/','.git')):continue
        p=root/name
        if p.is_file():
            data=p.read_bytes();inputs.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest()));z.writestr(name,data)
    z.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
raise SystemExit(subprocess.run(['wsl','-e','python3','/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/final_risks_wsl.py',
    '/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/'+archive.name,candidate,attempt,*sys.argv[3:]]).returncode)
