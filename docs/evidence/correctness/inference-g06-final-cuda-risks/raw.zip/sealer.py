from pathlib import Path
import datetime,hashlib,json,re,subprocess,xml.etree.ElementTree as ET,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';out=root/'evidence/correctness/inference-g06-final-cuda-risks'
assert not out.exists()
product='0a29d119426b2975d48c238c37a2994675e0ba9f'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',product,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
results={name:json.loads((base/name/'result.json').read_text()) for name in ['final-risks-shared-1','final-risks-static-1','final-risks-static-2']}
assert results['final-risks-static-1']['state']=='TERMINAL_FAIL'
qualified=['final-risks-shared-1','final-risks-static-2'];tests={};rechecks={}
for name in qualified:
 folder=base/name;r=results[name];assert r['state']=='TERMINAL_INSTRUMENTED_RISKS_PASS_FINAL_GATES_PENDING'
 t=ET.parse(folder/'provider.xml').getroot();assert all(t.attrib.get(k,'0')=='0' for k in ['failures','errors','disabled'])
 assert int(t.attrib['tests'])==(23 if 'static' in name else 20)
 tests[name]={'provider':dict(t.attrib),'pending_targets':{}}
 for storage in ['plain','encoded']:
  for kind in ['ordinary','captured']:
   label='hyle_g06_risk_'+storage+'_'+kind;log=(folder/(label+'.log')).read_text();count=log.count('PASS');assert count==5,(label,count)
   tests[name]['pending_targets'][label]={'passed_modes':count}
 inputs=json.loads((folder/'input-manifest.json').read_text())
 for item in inputs:
  if item['path'].startswith(('include/','src/','cmake/')) or item['path']=='CMakeLists.txt':
   assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
 path='/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/g06/'+name+'/artifacts.json'
 check="from pathlib import Path;import hashlib,json;rows=json.loads(Path("+repr(path)+").read_text());assert all(hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()==i['sha256'] for i in rows);print(len(rows),sum(i['bytes'] for i in rows))"
 rechecks[name]=subprocess.check_output(['wsl','-e','python3','-c',check],text=True).strip()
assert not results['final-risks-shared-1']['native_cuda_edges']
assert len(results['final-risks-static-1']['native_cuda_edges'])==2
assert not results['final-risks-static-2']['native_cuda_edges']
out.mkdir(parents=True)
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in results:
  for p in sorted((base/name).iterdir()):
   if p.is_file():z.write(p,name+'/'+p.name)
 z.write(Path(__file__),'sealer.py');z.write(base/'launch_final_risks.py','launcher.py')
r={'state':'PASS_FINITE_CUDA_INSTRUMENTED_RISKS_ONLY','product_candidate':product,
 'source_snapshots':{k:v['candidate'] for k,v in results.items()},
 'product_identity':'Current canonical include/src/cmake/root CMake unchanged from frozen product candidate, each qualified actual source manifest rechecked; later changes fix only test ragged capacity/schema diagnostics and docs.',
 'record':'docs/implementation/tasks/compute/inference-g06-metadata-decode.md','tests':tests,'artifact_rechecks_count_bytes':rechecks,
 'qualification':['Four original pending risk targets each five actual source-known/unknown-before-acceptance/late-source/abandon/CPU-foreign-queue modes, shared and static, plain/FP8 and ordinary/captured.',
 'Static23 includes original native partial-acceptance error plus new real native capture attribute failure and cudaGraphLaunch failure; each new test covers plain and FP8, original native error domain/code, failed slot rejection, fresh independent slot .25 oracle and metadata cleanup.',
 'Original core compute108/Graph289 and separate fresh-process actual cold capture32x64 pass in each qualified configuration; no new mathematical kernels.',
 'Existing observation hooks only in original backend host TU; source unchanged. Static native faults use original link-time wrappers, not product hooks.'],
 'attempts':results,'limits':['Not a shipping SDK/header/sanitizer/P1 or full G06 acceptance verdict','Original static attempt1 21/23 FAIL retained: new fixture default paged capacities in ragged setup; actual fault injection not reached in these two tests. Corrected fixture only.','Original G04/G05 performance unresolved and causal attribution UNKNOWN remain; no P1/profile/tile search here','Native driver/private memory cost UNKNOWN'],
 'raw_sha256':hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest(),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'state':r['state'],'artifacts':rechecks,'receipt':str(out.relative_to(root))},ensure_ascii=False))
