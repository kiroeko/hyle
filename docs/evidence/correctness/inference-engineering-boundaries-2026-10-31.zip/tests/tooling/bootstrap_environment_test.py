"""Installed-tool discovery contracts. All tool execution is mocked."""
from __future__ import annotations

import os
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import sys
import tempfile
import unittest
from unittest.mock import patch

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "scripts"))
import hyle_environment as tools


class EnvironmentTests(unittest.TestCase):
    def setUp(self):
        scratch = REPO / ".scratch/validation/bootstrap-environment"
        scratch.mkdir(parents=True, exist_ok=True)
        self.directory = tempfile.TemporaryDirectory(dir=scratch)
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)

    @staticmethod
    def gcc(args, env):
        return "gcc (GCC) 14.2.0" if "--version" in args else "14.2.0"

    @staticmethod
    def environment(system, env):
        return tools.Environment(env, system, "x86_64", "cmake", "ctest",
                                 "cc", "c++", "Ninja", {})

    def test_matching_compiler_pair(self):
        with patch.object(tools, "_which", side_effect=lambda name, env: name), \
                patch.object(tools, "_run", side_effect=self.gcc):
            self.assertEqual(tools._compiler_pair("gcc-14", "g++-14", {}),
                             ("gcc-14", "g++-14", "gcc"))

    def test_compiler_discovery_preserves_symlink_driver_name(self):
        driver = self.root / "clang++"
        with patch.object(tools.shutil, "which", return_value=str(driver)), \
                patch.object(tools.Path, "resolve", return_value=self.root / "clang") as resolve:
            self.assertEqual(tools._which("clang++", {}), str(driver.absolute()))
        resolve.assert_not_called()

    def test_compiler_pair_rejects_mismatch_and_old_versions(self):
        for banners in (("clang version 18.0", "clang version 19.0"),
                        ("clang version 17.0", "clang version 17.0")):
            with self.subTest(banners=banners), \
                    patch.object(tools, "_which", side_effect=lambda name, env: name), \
                    patch.object(tools, "_run", side_effect=banners):
                with self.assertRaises(tools.SetupError):
                    tools._compiler_pair("cc", "c++", {})

    def test_cached_unix_compilers_override_new_shell_defaults(self):
        cache = {"CMAKE_C_COMPILER": "/cached/gcc-14", "CMAKE_CXX_COMPILER": "/cached/g++-14"}
        with patch.object(tools, "_which", side_effect=lambda name, env: name), \
                patch.object(tools, "_run", side_effect=self.gcc) as run:
            pair = tools._unix_compilers("auto", cache,
                                         {"CC": "/new/gcc-15", "CXX": "/new/g++-15"}, "Linux")
        self.assertEqual(pair, (cache["CMAKE_C_COMPILER"], cache["CMAKE_CXX_COMPILER"]))
        self.assertTrue(all("/cached/" in call.args[0][0] for call in run.call_args_list))

    def test_vs_metadata_restores_old_toolset_without_vswhere(self):
        installation = self.root / "VS"
        for version in ("14.44.35207", "14.50.35717"):
            compiler = installation / f"VC/Tools/MSVC/{version}/bin/Hostx64/x64/cl.exe"
            compiler.parent.mkdir(parents=True)
            compiler.write_text("compiler placeholder")
        selected = installation / "VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/cl.exe"
        metadata = self.root / "build/CMakeFiles/4.2.0"
        metadata.mkdir(parents=True)
        (metadata / "CMakeCXXCompiler.cmake").write_text(
            f'set(CMAKE_CXX_COMPILER "{selected.as_posix()}")\n', encoding="utf-8")
        cache = {"CMAKE_CACHEFILE_DIR": str(self.root / "build"),
                 "CMAKE_CACHE_MAJOR_VERSION": "4", "CMAKE_CACHE_MINOR_VERSION": "2",
                 "CMAKE_CACHE_PATCH_VERSION": "0"}
        tools._restore_cached_compilers(cache)
        with patch.object(tools, "_vs_environment", side_effect=lambda install, version, arch, env: env) as setup, \
                patch.object(tools, "_which", side_effect=lambda name, env: str(Path(name).resolve())), \
                patch.object(tools, "_run", side_effect=AssertionError("must not reselect VS")):
            result = tools._windows_compilers("auto", cache, {}, "Ninja")
        self.assertEqual(Path(result[2]), selected)
        self.assertEqual(result[0]["VSLANG"], "1033")
        self.assertEqual(setup.call_args.args[1], "14.44.35207")
        clang = installation / "VC/Tools/Llvm/x64/bin/clang-cl.exe"
        clang.parent.mkdir(parents=True)
        clang.write_text("compiler placeholder")
        with patch.object(tools, "_vs_environment", side_effect=lambda install, version, arch, env: env) as setup, \
                patch.object(tools, "_which", side_effect=lambda name, env: str(Path(name).resolve())), \
                patch.object(tools, "_run", return_value="clang version 18.0") as run:
            tools._windows_compilers("auto", {"CMAKE_CXX_COMPILER": str(clang),
                                              "CMAKE_VS_PLATFORM_TOOLSET_VERSION": "14.44.35207"}, {}, "Ninja")
        self.assertEqual(setup.call_args.args[:2], (installation, "14.44.35207"))
        self.assertEqual(run.call_args.args[0], [str(clang), "--version"])

    def test_missing_cached_make_program_does_not_switch_tools(self):
        cache = {"CMAKE_GENERATOR": "Ninja", "CMAKE_MAKE_PROGRAM": str(self.root / "missing-ninja")}
        with patch.object(tools.platform, "system", return_value="Linux"), \
                patch.object(tools.platform, "machine", return_value="x86_64"), \
                patch.object(tools, "_unix_compilers", return_value=("gcc-14", "g++-14")), \
                patch.object(tools, "_cmake_tools", return_value=("/mock/cmake", "/mock/ctest")), \
                patch.object(tools, "_which", return_value="/new/ninja") as which:
            with self.assertRaisesRegex(tools.SetupError, "Cached build tool is missing"):
                tools.discover_environment(cache=cache)
        which.assert_not_called()

    def test_windows_build_and_header_environments_fix_include_language(self):
        installation = self.root / "VS"
        compiler = installation / "VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe"
        compiler.parent.mkdir(parents=True)
        compiler.write_text("compiler fixture")
        ninja = self.root / "ninja.exe"
        ninja.write_text("build tool fixture")
        cache = {"CMAKE_C_COMPILER": str(compiler), "CMAKE_CXX_COMPILER": str(compiler),
                 "CMAKE_GENERATOR": "Ninja", "CMAKE_MAKE_PROGRAM": str(ninja)}
        active = {"VSINSTALLDIR": str(installation), "VCTOOLSVERSION": "14.50.35717",
                  "VSCMD_ARG_TGT_ARCH": "x64", "VSCMD_VER": "18.0", "WINDOWSSDKDIR": "SDK",
                  "INCLUDE": "headers", "LIB": "libs", "PATH": "existing"}
        for language in (None, "2052", "1033"):
            parent = dict(active)
            if language is not None:
                parent["VSLANG"] = language
            with self.subTest(language=language), patch.dict(os.environ, parent, clear=True), \
                    patch.object(tools.platform, "system", return_value="Windows"), \
                    patch.object(tools.platform, "machine", return_value="AMD64"), \
                    patch.object(tools, "_which", side_effect=lambda name, env: str(Path(name).resolve())), \
                    patch.object(tools, "_cmake_tools", return_value=("/mock/cmake", "/mock/ctest")), \
                    patch.object(tools.subprocess, "run", side_effect=AssertionError("active VS must be reused")):
                before = dict(os.environ)
                build = tools.discover_environment(cache=cache)
                header = tools.windows_compiler_environment(cache)
                self.assertEqual(build.env["VSLANG"], "1033")
                self.assertEqual(header["VSLANG"], "1033")
                self.assertEqual(build.cxx, str(compiler.resolve()))
                for key in ("INCLUDE", "LIB", "WINDOWSSDKDIR", "VCTOOLSVERSION", "VSCMD_ARG_TGT_ARCH"):
                    self.assertEqual(build.env[key], active[key])
                    self.assertEqual(header[key], active[key])
                self.assertEqual(dict(os.environ), before)

    def test_unix_environment_keeps_explicit_diagnostic_language(self):
        with patch.dict(os.environ, {"PATH": "existing", "VSLANG": "2052"}, clear=True), \
                patch.object(tools.platform, "system", return_value="Linux"), \
                patch.object(tools.platform, "machine", return_value="x86_64"), \
                patch.object(tools, "_unix_compilers", return_value=("gcc", "g++")), \
                patch.object(tools, "_cmake_tools", return_value=("/mock/cmake", "/mock/ctest")):
            result = tools.discover_environment(generator="Xcode")
        self.assertEqual(result.env["VSLANG"], "2052")

    def test_ninja_language_repair_allows_init_in_same_build_directory(self):
        build = self.root / "cached build"
        rules = build / "CMakeFiles/rules.ninja"
        rules.parent.mkdir(parents=True)
        rules.write_text("msvc_deps_prefix = 注意: 包含文件:  \n", encoding="utf-8")
        metadata = build / "CMakeFiles/4.4.0/CMakeCXXCompiler.cmake"
        metadata.parent.mkdir()
        metadata.write_text('set(CMAKE_CXX_CL_SHOWINCLUDES_PREFIX "注意: 包含文件:  ")\n', encoding="utf-8")
        before = metadata.read_bytes()
        ninja = self.root / "ninja.exe"
        ninja.write_text("build tool fixture")
        cache = {"CMAKE_CACHEFILE_DIR": str(build), "CMAKE_GENERATOR": "Ninja",
                 "CMAKE_MAKE_PROGRAM": str(ninja)}
        with patch.object(tools.platform, "system", return_value="Windows"), \
                patch.object(tools.platform, "machine", return_value="AMD64"), \
                patch.object(tools, "_windows_compilers", return_value=(
                    {"PATH": "selected", "VSLANG": "1033"}, "cl", "cl", self.root, "14.50.35717")), \
                patch.object(tools, "_cmake_tools", return_value=("/mock/cmake", "/mock/ctest")):
            with self.assertRaisesRegex(tools.SetupError, "repair it in place") as error:
                tools.discover_environment(cache=cache)
            self.assertIn(f'--build-dir "{build}"', str(error.exception))
            tools.discover_environment(cache=cache, configuring=True)
            # Configuration changes only the actual Ninja parser setting.
            # The old compiler metadata remains valid toolchain identity.
            rules.write_text("msvc_deps_prefix = Note: including file: \n", encoding="utf-8")
            selected = tools.discover_environment(cache=cache)
        self.assertEqual(selected.env["VSLANG"], "1033")
        self.assertEqual(metadata.read_bytes(), before)

    def test_ninja_language_checks_every_scoped_parser_prefix(self):
        build = self.root / "mixed rules"
        rules = build / "CMakeFiles/rules.ninja"
        rules.parent.mkdir(parents=True)
        cache = {"CMAKE_CACHEFILE_DIR": str(build)}
        rules.write_text("msvc_deps_prefix = Note: including file: \n"
                         "rule CXX_COMPILER\n  msvc_deps_prefix = 注意: 包含文件:  \n", encoding="utf-8")
        with self.assertRaisesRegex(tools.SetupError, "repair it in place"):
            tools._check_ninja_include_language(cache, "Ninja")
        rules.write_text("msvc_deps_prefix = Note: including file: \n"
                         "rule CXX_COMPILER\n  msvc_deps_prefix = Note: including file: \n", encoding="utf-8")
        tools._check_ninja_include_language(cache, "Ninja")

    def test_windows_cmd_import_preserves_unicode_and_parent_environment(self):
        installation = self.root / "VS"
        devcmd = installation / "Common7/Tools/VsDevCmd.bat"
        devcmd.parent.mkdir(parents=True)
        devcmd.write_text("fixture")
        output = "PATH=C:\\工具\\bin\r\nINCLUDE=C:\\头文件\r\nLIB=C:\\库\r\nWindowsSdkDir=C:\\SDK\r\n"
        before = dict(os.environ)
        supplied = {"PATH": "original", "STALE": "removed by DevCmd"}
        with patch.object(tools, "_ROOT", self.root), \
                patch.object(tools.subprocess, "run", return_value=SimpleNamespace(
                    returncode=0, stdout=output.encode("utf-16-le"), stderr=b"")) as run:
            selected = tools._vs_environment(installation, "14.50.35717", "x64", supplied)
        self.assertEqual(selected["PATH"], "C:\\工具\\bin")
        self.assertEqual(selected["INCLUDE"], "C:\\头文件")
        self.assertNotIn("STALE", selected)
        self.assertEqual(supplied, {"PATH": "original", "STALE": "removed by DevCmd"})
        self.assertEqual(dict(os.environ), before)
        self.assertIn("/u", run.call_args.args[0])

    def test_active_vs_must_match_instance_toolset_and_complete_environment(self):
        selected = self.root / "selected-VS"
        other = self.root / "other-VS"
        for installation in (selected, other):
            devcmd = installation / "Common7/Tools/VsDevCmd.bat"
            devcmd.parent.mkdir(parents=True)
            devcmd.write_text("fixture")
        matching = {"VSINSTALLDIR": str(selected), "VCTOOLSVERSION": "14.50.35717",
                    "VSCMD_ARG_TGT_ARCH": "x64", "VSCMD_VER": "18.0",
                    "WINDOWSSDKDIR": "SDK", "INCLUDE": "headers", "LIB": "libs", "PATH": "tools"}
        mismatches = [{**matching, "VSINSTALLDIR": str(other)},
                      {**matching, "VCTOOLSVERSION": "14.44.35207"},
                      {**matching, "INCLUDE": ""}]
        def execute(args, **kwargs):
            script = Path(args[-1]).read_text(encoding="utf-8")
            self.assertIn("-clean_env", script)
            self.assertIn(f'call "{selected / "Common7/Tools/VsDevCmd.bat"}"', script)
            self.assertIn("-vcvars_ver=14.50.35717", script)
            output = "\r\n".join(f"{key}={value}" for key, value in matching.items())
            return SimpleNamespace(returncode=0, stdout=output.encode("utf-16-le"), stderr=b"")
        with patch.object(tools, "_ROOT", self.root), patch.object(tools.subprocess, "run", side_effect=execute) as run:
            for supplied in mismatches:
                with self.subTest(supplied=supplied):
                    env = tools._vs_environment(selected, "14.50.35717", "x64", supplied)
                    self.assertEqual(env, matching)
            self.assertEqual(run.call_count, len(mismatches))
            tools._vs_environment(selected, "14.50.35717", "x64", matching)
            self.assertEqual(run.call_count, len(mismatches))

    def test_header_checker_delegates_windows_setup_and_preserves_unix_behavior(self):
        spec = importlib.util.spec_from_file_location("hyle_header_checker", REPO / "scripts/header-self-contained.py")
        header = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(header)
        selected = {"PATH": "selected compiler environment"}
        with patch.object(header.platform, "system", return_value="Windows"), \
                patch.object(header, "windows_compiler_environment", return_value=selected) as setup:
            self.assertIs(header.visual_studio_environment("VS", "ARM64", "14.50.35717", "clang-cl"), selected)
            setup.assert_called_once_with({"CMAKE_CXX_COMPILER": "clang-cl", "CMAKE_GENERATOR_INSTANCE": "VS",
                                           "CMAKE_GENERATOR_PLATFORM": "ARM64", "CMAKE_VS_PLATFORM_TOOLSET_VERSION": "14.50.35717"})
        with patch.object(header.platform, "system", return_value="Linux"), \
                patch.object(header, "windows_compiler_environment") as setup:
            self.assertIsNone(header.visual_studio_environment("", "", "", "g++-14"))
            setup.assert_not_called()

    def test_linux_rejects_windows_nvcc(self):
        for env in ({}, {"CUDACXX": "nvcc"}):
            with self.subTest(env=env), patch.object(tools.glob, "glob", return_value=[]), \
                    patch.object(tools, "_which", return_value="C:/CUDA/bin/nvcc.exe"), \
                    patch.object(tools, "_run") as run:
                with self.assertRaisesRegex(tools.SetupError, "WSL requires Linux nvcc"):
                    tools._cuda(env, {}, "Linux")
            run.assert_not_called()

    def test_cached_cuda_does_not_fall_back_to_newer_sdk(self):
        with patch.object(tools.glob, "glob") as glob, patch.object(tools, "_run") as run:
            with self.assertRaisesRegex(tools.SetupError, "Cached CUDA compiler"):
                tools._cuda({"CUDA_PATH": "/new/cuda"},
                            {"CMAKE_CUDA_COMPILER": str(self.root / "missing-nvcc")}, "Linux")
        glob.assert_not_called()
        run.assert_not_called()

    def test_explicit_cuda_compiler_does_not_fall_back(self):
        compiler = self.root / "selected CUDA/bin/nvcc.exe"
        compiler.parent.mkdir(parents=True)
        for exists in (False, True):
            if exists:
                compiler.touch()
            with self.subTest(exists=exists), \
                    patch.object(tools.glob, "glob", side_effect=AssertionError("no automatic toolkit search")), \
                    patch.object(tools, "_which", side_effect=AssertionError("no PATH compiler fallback")), \
                    patch.object(tools, "_run", return_value="Cuda compilation tools, release 13.2") as run:
                with self.assertRaisesRegex(tools.SetupError, "selected by CUDACXX"):
                    tools._cuda({"CUDACXX": str(compiler)}, {}, "Windows")
                self.assertEqual(run.call_count, int(exists))
                if exists:
                    self.assertEqual(run.call_args.args[0], [str(compiler.resolve()), "--version"])

    def test_explicit_cuda_root_does_not_fall_back(self):
        for source in ("cache", "environment"):
            toolkit = self.root / ("selected root " + source)
            compiler = toolkit / "bin/nvcc.exe"
            compiler.parent.mkdir(parents=True)
            for exists in (False, True):
                if exists:
                    compiler.touch()
                env = {"CUDATOOLKIT_ROOT": str(toolkit)} if source == "environment" else {}
                cache = {"CUDAToolkit_ROOT": str(toolkit)} if source == "cache" else {}
                with self.subTest(source=source, exists=exists), \
                        patch.object(tools.glob, "glob", side_effect=AssertionError("no automatic toolkit search")), \
                        patch.object(tools, "_which", side_effect=AssertionError("no PATH compiler fallback")), \
                        patch.object(tools, "_run", return_value="Cuda compilation tools, release 13.2") as run:
                    with self.assertRaisesRegex(tools.SetupError, "CUDAToolkit_ROOT does not contain"):
                        tools._cuda(env, cache, "Windows")
                    self.assertEqual(run.call_count, int(exists))

    def test_explicit_cuda_compiler_and_root_must_match(self):
        first, second = self.root / "first CUDA", self.root / "second CUDA"
        compiler = first / "bin/nvcc.exe"
        compiler.parent.mkdir(parents=True); compiler.touch()
        second.mkdir()
        selections = (
            ({}, {"CMAKE_CUDA_COMPILER": str(compiler), "CUDAToolkit_ROOT": str(second)}),
            ({"CUDACXX": str(compiler), "CUDATOOLKIT_ROOT": str(second)}, {}),
            ({"CUDACXX": str(compiler)}, {"CUDAToolkit_ROOT": str(second)}),
        )
        for env, cache in selections:
            with self.subTest(env=env, cache=cache), \
                    patch.object(tools.glob, "glob", side_effect=AssertionError("no automatic toolkit search")), \
                    patch.object(tools, "_run", side_effect=AssertionError("mismatch is known before nvcc executes")):
                with self.assertRaisesRegex(tools.SetupError, "same installation"):
                    tools._cuda(env, cache, "Windows")

    def test_cuda_keeps_cached_compiler_and_automatic_discovery(self):
        selected, other = self.root / "cached CUDA", self.root / "other CUDA"
        for toolkit in (selected, other):
            compiler = toolkit / "bin/nvcc.exe"
            compiler.parent.mkdir(parents=True); compiler.touch()
        compiler = selected / "bin/nvcc.exe"
        for cached_root in (False, True):
            cache = {"CMAKE_CUDA_COMPILER": str(compiler)}
            if cached_root:
                cache["CUDAToolkit_ROOT"] = str(selected)
            with self.subTest(cached_root=cached_root), \
                    patch.object(tools.glob, "glob", side_effect=AssertionError("cached compiler is authoritative")), \
                    patch.object(tools, "_run", return_value="Cuda compilation tools, release 13.3") as run:
                result = tools._cuda({"CUDACXX": str(other / "bin/nvcc.exe"), "CUDATOOLKIT_ROOT": str(other)},
                                     cache, "Windows")
            self.assertEqual(run.call_args.args[0], [str(compiler.resolve()), "--version"])
            self.assertEqual(result["CUDAToolkit_ROOT"], str(selected.resolve()))
        with patch.object(tools.glob, "glob", return_value=[str(other)]) as search, \
                patch.object(tools, "_which", return_value=None), \
                patch.object(tools, "_run", return_value="Cuda compilation tools, release 13.3"):
            result = tools._cuda({}, {}, "Windows")
        search.assert_called_once()
        self.assertEqual(result["CMAKE_CUDA_COMPILER"], str((other / "bin/nvcc.exe").resolve()))
        with patch.object(tools.glob, "glob", side_effect=AssertionError("explicit name is not automatic discovery")), \
                patch.object(tools, "_which", return_value=str(compiler)) as which, \
                patch.object(tools, "_run", return_value="Cuda compilation tools, release 13.3"):
            result = tools._cuda({"CUDACXX": "nvcc.exe"}, {}, "Windows")
        which.assert_called_once()
        self.assertEqual(which.call_args.args[0], "nvcc.exe")
        self.assertEqual(result["CMAKE_CUDA_COMPILER"], str(compiler.resolve()))

    def test_windows_cuda_child_path_includes_split_runtime_directory(self):
        for nested in (False, True):
            with self.subTest(nested=nested):
                toolkit = self.root / ("split-cuda" if nested else "flat-cuda")
                compiler = toolkit / "bin/nvcc.exe"
                compiler.parent.mkdir(parents=True)
                compiler.write_text("compiler fixture")
                runtime = compiler.parent / "x64" if nested else compiler.parent
                runtime.mkdir(exist_ok=True)
                (runtime / "cudart64_13.dll").write_text("runtime fixture")
                env = {"PATH": "existing"}
                with patch.object(tools, "_run", return_value="Cuda compilation tools, release 13.3"):
                    selected = tools._cuda(env, {"CMAKE_CUDA_COMPILER": str(compiler)}, "Windows")
                paths = env["PATH"].split(os.pathsep)
                self.assertIn(str(compiler.parent.resolve()), paths)
                self.assertIn(str(runtime.resolve()), paths)
                self.assertIn("existing", paths)
                self.assertEqual(selected["CUDAToolkit_ROOT"], str(toolkit.resolve()))

    def test_macos_nonlogin_environment_includes_homebrew(self):
        observed = []
        def compilers(compiler, cache, env, system):
            observed.append(env["PATH"])
            return "/mock/clang", "/mock/clang++"
        with patch.dict(os.environ, {"PATH": "/system/bin"}, clear=True), \
                patch.object(tools.platform, "system", return_value="Darwin"), \
                patch.object(tools.platform, "machine", return_value="arm64"), \
                patch.object(tools.Path, "is_dir", return_value=True), \
                patch.object(tools, "_unix_compilers", side_effect=compilers), \
                patch.object(tools, "_cmake_tools", return_value=("/mock/cmake", "/mock/ctest")):
            result = tools.discover_environment(generator="Xcode")
        self.assertEqual(observed[0].split(os.pathsep)[0], "/opt/homebrew/bin")
        self.assertEqual(result.arch, "aarch64")

    def test_missing_cmake_and_metal_have_installation_guidance(self):
        with patch.object(tools, "_which", return_value=None):
            required = "\\.".join(map(str, tools._minimum_cmake_version()))
            with self.assertRaisesRegex(tools.SetupError, rf"CMake/CTest {required}.*docs/developer/setup"):
                tools._cmake_tools({"PATH": ""}, "Linux")
        with patch.object(tools, "_run", side_effect=tools.SetupError("not installed")):
            with self.assertRaisesRegex(tools.SetupError, r"Metal.*docs/developer/setup/macos.md"):
                tools._apple({"TOOLCHAINS": "user-selection"}, "Darwin", "aarch64")

    def test_cmake_minimum_comes_from_the_project_declaration(self):
        source = self.root / "CMakeLists.txt"
        source.write_text("cmake_minimum_required(VERSION 3.25)\n", encoding="utf-8")
        with patch.object(tools, "_ROOT", self.root):
            self.assertEqual(tools._minimum_cmake_version(), (3, 25))
            source.write_text("cmake_minimum_required(VERSION 3.27.2)\n", encoding="utf-8")
            self.assertEqual(tools._minimum_cmake_version(), (3, 27, 2))
            source.write_text("project(no_version_declaration)\n", encoding="utf-8")
            with self.assertRaisesRegex(tools.SetupError, "Cannot parse.*cmake_minimum_required"):
                tools._minimum_cmake_version()
        with patch.object(tools, "_ROOT", self.root / "missing checkout"):
            with self.assertRaisesRegex(tools.SetupError, "Cannot read.*CMake minimum"):
                tools._minimum_cmake_version()

    def test_tool_version_gate_matches_the_declared_minimum(self):
        (self.root / "CMakeLists.txt").write_text("cmake_minimum_required(VERSION 3.25)\n", encoding="utf-8")
        cmake, ctest = self.root / "cmake", self.root / "ctest"
        cmake.touch(); ctest.touch()
        with patch.object(tools, "_ROOT", self.root), \
                patch.object(tools, "_which", return_value=str(cmake)), \
                patch.object(tools, "_run", return_value="cmake version 3.25.0"):
            self.assertEqual(tools._cmake_tools({"PATH": ""}, "Linux"), (str(cmake), str(ctest)))
        with patch.object(tools, "_ROOT", self.root), \
                patch.object(tools, "_which", return_value=str(cmake)), \
                patch.object(tools, "_run", return_value="cmake version 3.24.9"):
            with self.assertRaisesRegex(tools.SetupError, r"CMake/CTest 3\.25"):
                tools._cmake_tools({"PATH": ""}, "Linux")

    def test_cached_cmake_precedes_visual_studio_path(self):
        cached, bundled = self.root / "CMake/bin", self.root / "VS/CMake/bin"
        for directory in (cached, bundled):
            directory.mkdir(parents=True)
            (directory / "cmake.exe").touch()
            (directory / "ctest.exe").touch()
        cache = {"CMAKE_COMMAND": str(cached / "cmake.exe")}
        def version(args, env):
            return "cmake version 4.4.0" if Path(args[0]).parent == cached else "cmake version 4.2.3-msvc3"
        with patch.object(tools, "_which", return_value=str(bundled / "cmake.exe")), \
                patch.object(tools, "_run", side_effect=version) as run:
            selected = tools._cmake_tools({"PATH": str(bundled)}, "Windows", cache)
        self.assertEqual(selected, (str(cached / "cmake.exe"), str(cached / "ctest.exe")))
        run.assert_called_once_with([str(cached / "cmake.exe"), "--version"], {"PATH": str(bundled)})

    def test_unusable_cached_cmake_keeps_existing_fallbacks(self):
        cached, bundled = self.root / "cached", self.root / "bundled"
        for directory in (cached, bundled):
            directory.mkdir()
            (directory / "cmake.exe").touch()
        (bundled / "ctest.exe").touch()
        env = {"PATH": str(bundled)}
        for reason in ("missing compiler", "missing ctest", "old version"):
            with self.subTest(reason=reason):
                candidate = cached / ("missing.exe" if reason == "missing compiler" else "cmake.exe")
                if reason == "old version":
                    (cached / "ctest.exe").touch()
                def version(args, env):
                    return "cmake version 3.24.0" if reason == "old version" and Path(args[0]).parent == cached else "cmake version 4.2.3-msvc3"
                with patch.object(tools, "_which", return_value=str(bundled / "cmake.exe")), \
                        patch.object(tools, "_run", side_effect=version):
                    selected = tools._cmake_tools(env, "Windows", {"CMAKE_COMMAND": str(candidate)})
                self.assertEqual(selected, (str(bundled / "cmake.exe"), str(bundled / "ctest.exe")))

    @staticmethod
    def openssl(root, suffix):
        (root / "include/openssl").mkdir(parents=True)
        (root / "include/openssl/ssl.h").write_text("header fixture")
        (root / "lib").mkdir()
        for name in ("ssl", "crypto"):
            (root / f"lib/lib{name}.{suffix}").write_text("library fixture")

    def test_openssl_discovers_installed_windows_and_brew_packages(self):
        vcpkg = self.root / "vcpkg"
        windows = vcpkg / "installed/x64-windows"
        brew = self.root / "brew"
        macos = brew / "opt/openssl@3"
        self.openssl(windows, "lib")
        self.openssl(macos, "dylib")
        cases = [("Windows", {"VCPKG_ROOT": str(vcpkg)}, windows),
                 ("Darwin", {"HOMEBREW_PREFIX": str(brew)}, macos),
                 ("Windows", {"OPENSSL_ROOT_DIR": str(macos), "VCPKG_ROOT": str(vcpkg)}, macos)]
        for system, env, expected in cases:
            with self.subTest(system=system, env=env):
                self.assertEqual(tools.find_openssl(self.environment(system, env)),
                                 {"OPENSSL_ROOT_DIR": str(expected.resolve())})

    def test_openssl_absence_keeps_native_cmake_search_without_installing(self):
        with patch.object(tools.Path, "is_file", return_value=False), \
                patch.object(tools, "_run", side_effect=AssertionError("must not install or acquire")):
            for system in ("Windows", "Linux", "Darwin"):
                with self.subTest(system=system):
                    self.assertEqual(tools.find_openssl(self.environment(system, {})), {})


if __name__ == "__main__":
    unittest.main()
