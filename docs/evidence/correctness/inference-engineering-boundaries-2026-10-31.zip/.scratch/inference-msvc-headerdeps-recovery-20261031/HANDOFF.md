Normal header dependencies restored with original CMake4.4.0 and childVSLANG1033.

- Final: attempt3/verification-summary.json;16CXX=9SDK+7app,3links,0NVCC,0model/GPU.
- Full original/current Ninja commands unchanged; all16 real deps restored with required PlanState/EvaluationFailure headers.727C/CXX closure retains only3 legitimate empty conditional TUs.
- All16 source bytes directly equal and originalmtime_ns restored; actual default second build is0CXX/0links. Three control/new .text sections equal.
- Historical: first VS-bundled4.2 configure wrongly selected, then original4.4 restoration; both exit0. Two dryrun exact-plan gates stopped beforeCXX due realVerifyGlobs phony. Raw commands/logs/source/control retained; noobject deletion or fake dependencies.
- Public environment fix now also prefers validcachedCMAKE_COMMAND; sourcefreeze+70Python tests under ../inference-msvc-include-language-20261031. No further build after that script-onlyfix.
