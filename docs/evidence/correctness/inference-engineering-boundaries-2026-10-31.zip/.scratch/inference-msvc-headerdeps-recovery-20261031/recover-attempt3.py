from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent / 'attempt3'
PINNED_CMAKE = Path('C:/Program Files/CMake/bin/cmake.exe')
BUILD = ROOT / '.scratch/build-compute-v2-dev'
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import discover_environment
from hyle_support import read_cache


def put(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'mtime_ns': path.stat().st_mtime_ns}


def sections(path):
    data = path.read_bytes()
    pe = struct.unpack_from('<I', data, 0x3c)[0]
    assert data[pe:pe+4] == b'PE\0\0'
    count = struct.unpack_from('<H', data, pe+6)[0]
    table = pe + 24 + struct.unpack_from('<H', data, pe+20)[0]
    result = {}
    for index in range(count):
        offset = table + index * 40
        name = data[offset:offset+8].split(b'\0')[0].decode()
        size, raw = struct.unpack_from('<II', data, offset+16)
        result[name] = {'bytes': size, 'sha256': hashlib.sha256(data[raw:raw+size]).hexdigest()}
    return result


def run(label, argv, env, cwd=ROOT):
    directory = BATCH / label
    directory.mkdir(parents=True, exist_ok=False)
    put(directory / 'command.json', {'argv': [str(a) for a in argv], 'cwd': str(cwd),
                                    'VSLANG': env.get('VSLANG')})
    started = time.time()
    with (directory / 'stdout.log').open('wb') as out, (directory / 'stderr.log').open('wb') as err:
        process = subprocess.Popen([str(a) for a in argv], cwd=cwd, env=env, stdout=out, stderr=err)
        put(directory / 'process.json', {'pid': process.pid, 'started_unix': started, 'status': 'RUNNING'})
        print(f'{label}: PID {process.pid} started', flush=True)
        code = process.wait()
    receipt = {'pid': process.pid, 'status': 'TERMINAL', 'exit_code': code,
               'started_unix': started, 'ended_unix': time.time()}
    put(directory / 'process.json', receipt)
    print(f'{label}: exit {code}, {receipt["ended_unix"]-started:.3f}s', flush=True)
    if code:
        raise RuntimeError(f'{label} failed with exit {code}')
    return (directory / 'stdout.log').read_bytes() + (directory / 'stderr.log').read_bytes()


def main():
    BATCH.mkdir(exist_ok=False)
    plan_path = ROOT / '.scratch/inference-msvc-include-language-20261031/headerdeps-recovery-plan-v2/recovery-plan.json'
    plan = json.loads(plan_path.read_text())
    selected = plan['recovery_objects']
    assert len(selected) == 16
    source_saved = {}
    primary_pins = []
    for row in selected:
        source = Path(row['source'])
        current = pin(source)
        assert current['sha256'] == row['source_pin']['sha256'] and current['bytes'] == row['source_pin']['bytes'], source
        original = source.read_bytes()
        source_saved[source] = (original, source.stat().st_atime_ns, source.stat().st_mtime_ns)
        destination = BATCH.parent / 'primary-sources' / source.relative_to(ROOT)
        destination.parent.mkdir(parents=True, exist_ok=True)
        assert destination.read_bytes() == original
        primary_pins.append(current)
    # Also retain exact pre-existing private/public header identities from the
    # successful Graph and Model build receipts, without copying an SDK tree.
    input_pins = {}
    for prior in [ROOT / '.scratch/inference-cross-turn-capture-20261031/normal-graph-build-plan/plan.json',
                  ROOT / '.scratch/inference-cross-turn-capture-20261031/normal-engine-build-plan-v2/build/attempt1/result.json']:
        for old in json.loads(prior.read_text())['source_pins']:
            source = Path(old['path'])
            current = pin(source)
            assert current['sha256'] == old['sha256'], source
            input_pins[str(source)] = current
    put(BATCH / 'source-pins-before.json', {'primary': primary_pins, 'additional_current_inputs': list(input_pins.values())})
    control = BATCH.parent / 'control'
    assert control.is_dir()
    expected = {'hyle_graph.dll': 'fe7d949f41f53325e6e150f1c9bc59d5455707eda898f617a2be719679cb6877',
                'hyle_graph_progress.dll': 'dcadbf81e098abb36d63bbddeae486f4ff812ab0eb417e5710fdd57380c126c0',
                'hyle.exe': '850aec109a978a3557cc940aabdc77015b42e03282d5e1acf755262bad2b0203'}
    old_images = {}
    for name, digest in expected.items():
        image = BUILD / 'bin' / name
        assert pin(image)['sha256'] == digest, image
        target = control / name
        assert target.is_file()
        assert target.read_bytes() == image.read_bytes()
        old_images[name] = {'original_pin': pin(image), 'control_pin': pin(target), 'sections': sections(target)}
    put(BATCH / 'control-images.json', old_images)
    cache = read_cache(BUILD)
    assert cache['HYLE_COMPONENTS'] == 'engine' and cache['HYLE_COMPUTE_ROUTES'] == 'cpu;cuda'
    assert cache['HYLE_BUILD_TESTS'] == 'OFF' and cache['HYLE_STATIC'] == 'OFF'
    assert cache['FETCHCONTENT_FULLY_DISCONNECTED'] == 'ON'
    environment = discover_environment(cache=cache, backends=('cpu', 'cuda'), configuring=True)
    assert environment.env['VSLANG'] == '1033'
    allow = ('PATH', 'INCLUDE', 'LIB', 'LIBPATH', 'VSLANG', 'VSINSTALLDIR', 'VCTOOLSVERSION',
             'WINDOWSSDKDIR', 'WINDOWSSDKVERSION', 'VSCMD_ARG_TGT_ARCH')
    put(BATCH / 'environment.json', {key: environment.env[key] for key in allow if key in environment.env})
    prior_configure = json.loads((BATCH.parent / 'attempt2/configure/attempt1/process.json').read_text())
    assert prior_configure['exit_code'] == 0
    put(BATCH / 'retained-configure-provenance.json', {'path': str(BATCH.parent / 'attempt2/configure/attempt1'), 'actual_CMake': str(PINNED_CMAKE), 'no_third_configure_run': True})
    cache_after = read_cache(BUILD)
    assert cache_after['CMAKE_COMMAND'].replace('\\', '/').lower() == str(PINNED_CMAKE).replace('\\', '/').lower()
    for key, value in [('CMAKE_CACHE_MAJOR_VERSION','4'),('CMAKE_CACHE_MINOR_VERSION','4'),('CMAKE_CACHE_PATCH_VERSION','0')]:
        assert cache_after[key] == value, (key, cache_after[key])
    original_compdb = json.loads((ROOT / '.scratch/inference-msvc-include-language-20261031/headerdeps-recovery-plan-v2/query-actual-ninja-compdb/stdout.log').read_bytes())
    current_compdb = json.loads(run('query-actual-compdb-after-original4_4', [cache_after['CMAKE_MAKE_PROGRAM'], '-t', 'compdb'], environment.env, BUILD))
    original_commands = {row['output']: row['command'] for row in original_compdb}
    current_commands = {row['output']: row['command'] for row in current_compdb}
    changed_commands = [key for key in set(original_commands) | set(current_commands) if original_commands.get(key) != current_commands.get(key)]
    put(BATCH / 'full-command-diff-gate.json', {'original_provenance': '.scratch/inference-msvc-include-language-20261031/headerdeps-recovery-plan-v2/query-actual-ninja-compdb/stdout.log', 'original_entries': len(original_commands), 'current_entries': len(current_commands), 'changed': changed_commands})
    assert not changed_commands, changed_commands
    for key in ('HYLE_COMPONENTS', 'HYLE_COMPUTE_ROUTES', 'HYLE_BUILD_TESTS', 'HYLE_STATIC',
                'CMAKE_BUILD_TYPE', 'HYLE_TRACE', 'HYLE_TEST_INSTRUMENTATION',
                'FETCHCONTENT_FULLY_DISCONNECTED', 'FETCHCONTENT_UPDATES_DISCONNECTED'):
        assert cache_after.get(key) == cache.get(key), key
    # Build discovery must accept the actual retained parser after configure.
    environment = discover_environment(cache=cache_after, backends=('cpu', 'cuda'))
    ninja = cache_after['CMAKE_MAKE_PROGRAM']
    query_manifest = BATCH / 'normal-manifest.ninja'
    original_manifest_bytes = (BUILD / 'build.ninja').read_bytes()
    query_manifest.write_bytes(original_manifest_bytes)
    assert query_manifest.read_bytes() == original_manifest_bytes
    put(BATCH / 'query-manifest.json', {'original': pin(BUILD / 'build.ninja'), 'copy': pin(query_manifest), 'bytes_direct_equal': True, 'purpose': 'Read-only prediction avoids default manifest auto-regeneration ambiguity; actual build still uses unchanged default Ninja/VerifyGlobs rules.'})
    before = run('predict-before-touch', [ninja, '-f', query_manifest, '-n', 'hyle_engine'], environment.env, BUILD)
    assert b'Building CXX object' not in before and b'nvcc' not in before.lower(), before.decode(errors='replace')
    restore_receipt = []
    touched = []
    try:
        boost = max(time.time_ns(), max(Path(row['object_pin']['path']).stat().st_mtime_ns for row in selected) + 1_000_000)
        for source, (original, atime, mtime) in source_saved.items():
            assert source.read_bytes() == original
            os.utime(source, ns=(atime, boost))
            touched.append(source)
        put(BATCH / 'temporary-source-times.json', {'known_time_ns': boost, 'sources': [pin(source) for source in touched]})
        prediction = run('predict-exact16', [ninja, '-f', query_manifest, '-n', 'hyle_engine'], environment.env, BUILD)
        actions = re.findall(r'Building CXX object ([^\r\n]+)', prediction.decode('utf-8', errors='replace'))
        expected_objects = {row['object'].replace('\\', '/') for row in selected}
        assert {action.replace('\\', '/') for action in actions} == expected_objects, actions
        assert not re.search(rb'Building (?:CUDA|C) object|nvcc', prediction, re.I)
        put(BATCH / 'actual-plan.json', {'CXX_count': len(actions), 'SDK_CXX': 9, 'app_CXX': 7,
                                       'objects': actions, 'CUDA_compile': 0, 'parallel': 2})
        run('build/attempt1', [PINNED_CMAKE, '--build', BUILD, '--target', 'hyle_engine', '--parallel', '2'], environment.env)
    finally:
        for source in touched:
            original, atime, mtime = source_saved[source]
            equal = source.read_bytes() == original
            if equal:
                os.utime(source, ns=(atime, mtime))
            restore_receipt.append({'source': str(source), 'bytes_direct_equal': equal,
                                    'original_mtime_ns': mtime, 'after_mtime_ns': source.stat().st_mtime_ns,
                                    'restored': equal and source.stat().st_mtime_ns == mtime})
        put(BATCH / 'restore-source-times.json', restore_receipt)
        assert all(item['restored'] for item in restore_receipt)
    for source, old in input_pins.items():
        assert pin(Path(source))['sha256'] == old['sha256'], source
    all_deps = run('verify-actual-deps', [ninja, '-t', 'deps'], environment.env, BUILD).decode('utf-8', errors='replace')
    blocks = {}
    for block in re.split(r'\n\s*\n', all_deps):
        found = re.match(r'(.+): #deps (\d+),.*', block)
        if found:
            blocks[found[1].replace('\\', '/').lower()] = (int(found[2]), block.replace('\\', '/').lower())
    verified = []
    for row in selected:
        count, block = blocks[row['object'].lower()]
        required = 'engine/inference/evaluation_failure.h' if row['object'].startswith('engine/') else 'src/graph/plan_state.h'
        assert count > 0 and required in block, (row['object'], count, required)
        verified.append({'object': row['object'], 'actual_headerdeps': count, 'required_changed_header': required,
                         'required_header_present': True, 'new_object_pin': pin(BUILD / row['object'])})
    closure_objects = [row['object'] for row in json.loads((plan_path.parent / 'plan.json').read_text())['all_C_CXX_closure']]
    remaining_zero = [obj for obj in closure_objects if blocks.get(obj.lower(), (0, ''))[0] == 0]
    expected_empty = {row['object'] for row in plan['legitimate_empty_TU_exclusions']}
    assert set(remaining_zero) == expected_empty, remaining_zero
    no_op = run('verify-default-no-op', [PINNED_CMAKE, '--build', BUILD, '--target', 'hyle_engine', '--parallel', '2'], environment.env)
    assert not re.search(rb'Building (?:CXX|CUDA|C) object|Linking |nvcc', no_op, re.I)
    images = {}
    for name, old in old_images.items():
        path = BUILD / 'bin' / name
        current_sections = sections(path)
        images[name] = {'old_pin': old['original_pin'], 'new_pin': pin(path), 'new_sections': current_sections,
                        'text_section_equal': current_sections.get('.text') == old['sections'].get('.text')}
    output = (BATCH / 'build/attempt1/stdout.log').read_text(encoding='utf-8', errors='replace')
    actual = re.findall(r'Building CXX object ([^\r\n]+)', output)
    assert {a.replace('\\', '/') for a in actual} == {row['object'] for row in selected}
    result = {'status': 'PASS', 'actual_CXX': len(actual), 'SDK_CXX': 9, 'app_CXX': 7,
              'actual_links': re.findall(r'Linking [^\r\n]+', output), 'NVCC_compile': 0,
              'source_bytes_and_original_mtimes_restored': True, 'objects_with_restored_real_headerdeps': verified,
              'C_CXX_closure': len(closure_objects), 'remaining_legitimate_empty_TUs': remaining_zero,
              'default_Ninja_no_op_CXX_and_links': True, 'images': images, 'native_model_GPU_runs': 0}
    put(BATCH / 'verification-summary.json', result)
    print(json.dumps({'status': 'PASS', 'actual_CXX': 16, 'actual_links': len(result['actual_links']),
                      'remaining_empty_TUs': len(remaining_zero),
                      'text_sections_equal': {name: value['text_section_equal'] for name, value in images.items()}}), flush=True)


if __name__ == '__main__':
    main()
