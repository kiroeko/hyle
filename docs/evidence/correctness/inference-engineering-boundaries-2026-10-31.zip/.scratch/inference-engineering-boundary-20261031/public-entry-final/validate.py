from pathlib import Path
import argparse
import contextlib
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
DEST = Path(__file__).resolve().parent
OLD = ROOT / '.scratch/inference-engineering-review-20261031'
UTIL = OLD / 'util-build'
INSTALL = OLD / 'util-install'
CONSUMER_SOURCE = OLD / 'consumer'
CONSUMER_BUILD = OLD / 'consumer-build'
HELPERS = ['scripts/init.py', 'scripts/build.py', 'scripts/test.py',
           'scripts/hyle_support.py', 'scripts/hyle_environment.py', 'scripts/hyle_resources.py',
           'cmake/HyleBuildContract.cmake', 'cmake/HyleNinjaHeaderDeps.cmake']
RESULTS = []


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def helpers_exact(freeze):
    for item in freeze['sources']:
        assert pin(Path(item['path'])) == item, f'Helper changed after freeze: {item["path"]}'


def preserve_internal_logs(directory):
    directory.mkdir(parents=True, exist_ok=True)
    for pattern in ['hyle-*.log', 'hyle-*.json', '.hyle-*.json']:
        for source in UTIL.glob(pattern):
            if source.is_file():
                shutil.copyfile(source, directory / source.name)


def public_step(support, freeze, name, action, arguments):
    helpers_exact(freeze)
    directory = DEST / name
    directory.mkdir()
    start = time.monotonic()
    with (directory / 'stdout.log').open('w', encoding='utf-8') as out, \
            (directory / 'stderr.log').open('w', encoding='utf-8') as err:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = support.main(action, arguments)
    preserve_internal_logs(directory / 'public-internal-logs')
    row = {'stage': name, 'entry': 'hyle_support.main', 'action': action, 'argv': arguments,
           'exit_code': code, 'seconds': time.monotonic() - start}
    save_json(directory / 'process.json', row)
    RESULTS.append(row)
    save_json(DEST / 'results.json', {'status': 'RUNNING' if code == 0 else 'FAILED', 'steps': RESULTS})
    print(json.dumps(row), flush=True)
    if code:
        raise SystemExit(code)
    helpers_exact(freeze)


def external_step(freeze, name, command, environment):
    helpers_exact(freeze)
    directory = DEST / name
    directory.mkdir()
    start = time.monotonic()
    with (directory / 'stdout.log').open('wb') as out, (directory / 'stderr.log').open('wb') as err:
        with subprocess.Popen(command, cwd=ROOT, env=environment, stdout=out, stderr=err) as process:
            pid = process.pid
            code = process.wait()
    row = {'stage': name, 'command': command, 'pid': pid, 'exit_code': code,
           'seconds': time.monotonic() - start}
    save_json(directory / 'process.json', row)
    RESULTS.append(row)
    save_json(DEST / 'results.json', {'status': 'RUNNING' if code == 0 else 'FAILED', 'steps': RESULTS})
    print(json.dumps(row), flush=True)
    if code:
        raise SystemExit(code)
    helpers_exact(freeze)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--freeze-current-helpers', action='store_true',
                        help='Use only after the parent confirms helper final freeze; does not run a build.')
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    for path in [UTIL / 'CMakeCache.txt', INSTALL / 'lib/cmake/Hyle/HyleConfig.cmake',
                 CONSUMER_SOURCE / 'CMakeLists.txt', CONSUMER_BUILD / 'CMakeCache.txt']:
        assert path.is_file(), str(path)
    if args.freeze_current_helpers:
        assert not args.execute
        path = DEST / 'helper-source-freeze.json'
        assert not path.exists()
        engineering = ROOT / '.scratch/inference-ninja-headerdeps-migration-20261031/source-freeze.json'
        engineering_data = json.loads(engineering.read_text())
        for item in engineering_data['files']:
            actual = pin(ROOT / item['path'])
            assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256']
        sources = list(dict.fromkeys(HELPERS + [item['path'] for item in engineering_data['files']]))
        save_json(path, {'sources': [pin(ROOT / relative) for relative in sources],
                         'engineering_eight_source_freeze': pin(engineering),
                         'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
        print(str(path))
        return
    if not args.execute:
        print('Prepared only; awaiting final helper freeze and execution authorization.')
        return
    freeze = json.loads((DEST / 'helper-source-freeze.json').read_text())
    helpers_exact(freeze)
    assert not (DEST / 'results.json').exists(), 'Never overwrite an execution attempt.'
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT / 'scripts'))
    import hyle_support as support
    from hyle_environment import discover_environment
    # Only redirect the current-selection metadata. The public implementation,
    # actual source, discovery, dependency policy and CMake execution are intact.
    support._current = lambda: DEST / 'selected.json'
    for module in list(sys.modules.values()):
        file = getattr(module, '__file__', None)
        if file and Path(file).parent == ROOT / 'scripts':
            assert str(Path(file)) in [item['path'] for item in freeze['sources']]
    temp = DEST / 'temp'
    temp.mkdir()
    os.environ['TMP'] = os.environ['TEMP'] = str(temp)
    preserve_internal_logs(DEST / 'previous-internal-logs')
    cache = support.read_cache(UTIL)
    assert cache['HYLE_COMPONENTS'] == 'util' and cache['HYLE_STATIC'] == 'OFF'
    assert cache['HYLE_BUILD_TESTS'] == 'OFF' and not cache.get('HYLE_COMPUTE_ROUTES')
    save_json(DEST / 'before.json', {'util_cache': pin(UTIL / 'CMakeCache.txt'),
                                   'consumer_cache': pin(CONSUMER_BUILD / 'CMakeCache.txt'),
                                   'consumer_sources': [pin(CONSUMER_SOURCE / p) for p in ['CMakeLists.txt', 'main.cc']],
                                   'previous_receipts': [pin(OLD / p) for p in ['real-entry-results.json', 'consumer-results.json']],
                                   'global_selection': pin(ROOT / '.scratch/hyle/current.json') if (ROOT / '.scratch/hyle/current.json').is_file() else None,
                                   'normal_engine_cache': [dict(pin(p), mtime_ns=p.stat().st_mtime_ns) for p in
                                                           [ROOT / '.scratch/build-compute-v2-dev/CMakeCache.txt', ROOT / '.scratch/build-compute-v2-dev/build.ninja']]})
    public_step(support, freeze, '01-init', 'init',
                ['--build-dir', str(UTIL), '--components', 'util', '--cache-dir',
                 'C:/public/tools/hyle-dependencies/v1', '--offline', '--jobs', '2'])
    public_step(support, freeze, '02-repeat-init', 'init', [])
    public_step(support, freeze, '03-build-install', 'build', ['--install', str(INSTALL), '--jobs', '2'])
    cache = support.read_cache(UTIL)
    assert cache['HYLE_COMPONENTS'] == 'util' and cache['HYLE_BUILD_TESTS'] == 'OFF'
    assert cache['HYLE_STATIC'] == 'OFF' and cache['CMAKE_BUILD_TYPE'] == 'Release'
    assert cache['FETCHCONTENT_FULLY_DISCONNECTED'] == 'ON'
    assert cache['FETCHCONTENT_UPDATES_DISCONNECTED'] == 'ON'
    environment = discover_environment(cache=cache)
    environment.env['TMP'] = environment.env['TEMP'] = str(temp)
    save_json(DEST / 'toolchain.json', {'cmake': environment.cmake, 'ctest': environment.ctest,
                                     'cc': environment.cc, 'cxx': environment.cxx,
                                     'generator': environment.generator, 'definitions': environment.definitions})
    configure = [environment.cmake, '-S', str(CONSUMER_SOURCE), '-B', str(CONSUMER_BUILD),
                 '-G', environment.generator, '-DCMAKE_BUILD_TYPE=Release',
                 '-DCMAKE_PREFIX_PATH=' + str(INSTALL), '-DCMAKE_CXX_COMPILER=' + environment.cxx,
                 '-DCMAKE_MAKE_PROGRAM=' + environment.definitions['CMAKE_MAKE_PROGRAM']]
    external_step(freeze, '04-consumer-configure', configure, environment.env)
    external_step(freeze, '05-consumer-build',
                  [environment.cmake, '--build', str(CONSUMER_BUILD), '--parallel', '2'], environment.env)
    external_step(freeze, '06-consumer-run', [str(CONSUMER_BUILD / 'util_consumer.exe')], environment.env)
    public_step(support, freeze, '07-final-repeat-init', 'init', [])
    public_step(support, freeze, '08-final-repeat-build', 'build', ['--jobs', '2'])
    log = (DEST / '08-final-repeat-build/stdout.log').read_text()
    assert 'no work to do' in log.lower(), 'Final actual public build did not report a no-op.'
    assert not re.search(r'Building (?:C|CXX|CUDA) object|Linking (?:CXX|CUDA|C) ', log)
    helpers_exact(freeze)
    before = json.loads((DEST / 'before.json').read_text())
    assert [pin(OLD / p) for p in ['real-entry-results.json', 'consumer-results.json']] == before['previous_receipts']
    current_selection = ROOT / '.scratch/hyle/current.json'
    assert (pin(current_selection) if current_selection.is_file() else None) == before['global_selection']
    assert [dict(pin(Path(p['path'])), mtime_ns=Path(p['path']).stat().st_mtime_ns)
            for p in before['normal_engine_cache']] == before['normal_engine_cache']
    summary = {'status': 'PASS', 'scope': 'Real public util offline init/repeat/build/install and independent installed-SDK consumer; existing Windows caches only.',
               'steps': RESULTS, 'helpers': freeze, 'only_public_entry_override': '_current points to this batch selected.json',
               'source_tree_and_sdk_copied': False, 'normal_engine_cache_touched': False,
               'final_repeat_build_cxx': 0, 'final_repeat_build_links': 0, 'model_gpu_processes': 0,
               'offline': True, 'jobs': 2, 'old_receipts_preserved': True,
               'boundary': 'This util consumer does not validate all products/platforms, a model, or a GPU/ABI combination.'}
    save_json(DEST / 'summary.json', summary)
    save_json(DEST / 'results.json', {'status': 'PASS', 'steps': RESULTS})
    print(json.dumps({'status': 'PASS', 'steps': len(RESULTS), 'final_repeat_no_work': True}), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if isinstance(error, SystemExit) and error.code in (None, 0):
            raise
        if RESULTS and not (DEST / 'failure.json').exists():
            save_json(DEST / 'failure.json', {'exception': type(error).__name__,
                                            'message': str(error), 'completed_steps': RESULTS})
        raise
