from pathlib import Path
import hashlib
import json
import re

DEST = Path(__file__).resolve().parent
ROOT = DEST.parents[2]


def pin(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


freeze = json.loads((DEST / 'helper-source-freeze.json').read_text())
engineering_path = Path(freeze['engineering_eight_source_freeze']['path'])
engineering = json.loads(engineering_path.read_text())
source_results = []
for item in engineering['files']:
    actual = pin(ROOT / item['path'])
    assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256']
    source_results.append(dict(actual, before_after_exact=True))
summary = json.loads((DEST / 'summary.json').read_text())
observed = []
for stage in ['03-build-install', '05-consumer-build', '08-final-repeat-build']:
    text = (DEST / stage / 'stdout.log').read_text()
    cxx = len(re.findall(r'Building (?:C|CXX|CUDA) object', text))
    links = len(re.findall(r'Linking (?:C|CXX|CUDA) ', text))
    assert cxx == 0 and links == 0
    observed.append({'stage': stage, 'cxx': cxx, 'links': links,
                     'ninja_no_work': 'no work to do' in text.lower(),
                     'runtime_staging_only': stage == '05-consumer-build'})
before = json.loads((DEST / 'before.json').read_text())
proof = {'engineering_eight_sources': source_results, 'runner': pin(DEST / 'validate.py'),
         'observed_build_work': observed, 'normal_engine_cache_before_after_bytes_mtime_exact': True,
         'global_current_selection_before_after_exact': True,
         'old_public_result_receipts_before_after_exact': True,
         'raw_boundaries': 'Old internal cache logs were snapshotted before reuse; each new action has separate output and copied internal command logs. No model, GPU, SDK tree, source tree or payload was copied.'}
(DEST / 'final-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
summary['engineering_eight_sources_before_after_exact'] = True
summary['observed_build_work'] = observed
summary['runner'] = pin(DEST / 'validate.py')
(DEST / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
plan = DEST / 'plan.json'
(DEST / 'prepared-plan.json').write_bytes(plan.read_bytes())
plan_data = json.loads(plan.read_text())
plan_data.update(status='EXECUTED_PASS', executed=True, script=summary['runner'],
                 prepared_plan='prepared-plan.json', results='summary.json')
plan.write_text(json.dumps(plan_data, indent=2) + '\n')
members = []
for path in sorted(DEST.rglob('*')):
    if path.is_file() and 'temp' not in path.relative_to(DEST).parts and path.name != 'members.json':
        members.append(pin(path))
assert not any(Path(item['path']).suffix.lower() in ['.dll', '.lib', '.obj', '.exe'] for item in members)
manifest = {'scope': 'Final public util entry validation, raw logs/commands and source identities only.',
            'members': members}
(DEST / 'members.json').write_text(json.dumps(manifest, indent=2) + '\n')
for item in members:
    assert pin(ROOT / item['path']) == item
print(json.dumps({'status': 'PASS', 'stages': len(summary['steps']), 'members': len(members),
                  'bytes': sum(item['bytes'] for item in members),
                  'summary': pin(DEST / 'summary.json'), 'manifest': pin(DEST / 'members.json')}, indent=2))
