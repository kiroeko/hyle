from pathlib import Path
import hashlib,json,zipfile,subprocess
R=Path.cwd(); B=R/'.scratch/inference-engineering-boundary-20261031'; E=R/'docs/evidence/correctness'
def sha(b): return hashlib.sha256(b).hexdigest()
def readj(p): return json.loads(Path(p).read_text(encoding='utf-8'))
payload={}
def add(name,data):
 name=str(name).replace('\\','/'); assert not name.startswith('/') and '..' not in Path(name).parts,name
 if name in payload: assert payload[name]==data,name
 payload[name]=data

def disk(path):
 p=Path(path); p=p if p.is_absolute() else R/p
 add(p.relative_to(R).as_posix(),p.read_bytes())
C=R/'.scratch/inference-msvc-engineering-evidence-20261031'
receipt=readj(C/'archive-receipt.json'); zpath=C/'evidence-draft.zip'
assert sha(zpath.read_bytes())==receipt['sha256']
expected={x['member']:x for x in readj(C/'manifest.json')['members']}
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None and set(z.namelist())==set(expected)|{'manifest.json'} and len(z.namelist())==568
 for name in z.namelist():
  b=z.read(name)
  if name=='manifest.json':
   assert b==(C/'manifest.json').read_bytes(); add((C/'manifest.json').relative_to(R).as_posix(),b); continue
  pin=expected[name]
  assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],name
  assert (R/name).read_bytes()==b,name
  add(name,b)
for filename in ('summary-draft.json','manifest.json','archive-receipt.json'): disk(C/filename)
K=R/'.scratch/inference-kimi-test-boundary-20261031'
for item in readj(K/'members.json')['members']:
 p=K/item['path']; b=p.read_bytes(); assert len(b)==item['bytes'] and sha(b)==item['sha256']; disk(p)
disk(K/'members.json')
U=B/'public-entry-final'
for item in readj(U/'members.json')['members']:
 p=R/item['path']; b=p.read_bytes(); assert len(b)==item['bytes'] and sha(b)==item['sha256']; disk(p)
disk(U/'members.json')
D=R/'.scratch/inference-engineering-entry-docs-20261031'
for p in D.rglob('*'):
 if p.is_file(): disk(p)
for name in ('publish.py','publish-attempt1.json','root-doc-readback.json','root-kimi-readback.json','root-migration-readback.json','shared-usage-review.json','ninja-migration-independent-review.json'): disk(B/name)
for name in ('validate-public-entry.py','validate-consumer.py'):
 disk(R/'.scratch/inference-engineering-review-20261031'/name)
for p in (R/'.scratch/inference-engineering-review-20261031/consumer').iterdir():
 if p.is_file(): disk(p)
f=readj(R/'.scratch/inference-ninja-headerdeps-migration-20261031/source-freeze.json')
for x in f['files']:
 p=R/x['path']; data=p.read_bytes(); assert sha(data)==x['sha256']; disk(p)
current=['engine/models/kimi_k3/CMakeLists.txt','tests/tooling/engine_components_test.py','CMakeLists.txt','cmake/HyleComponents.cmake','cmake/HyleComputeRoutes.cmake','cmake/HyleTrace.cmake','scripts/hyle_resources.py','engine/CMakeLists.txt','README.md','docs/README.md','docs/developer/setup/README.md','docs/developer/setup/windows.md','docs/architecture/build-system.md','docs/user/README.md','docs/developer/inference-progress.md','docs/implementation/inference-roadmap.md','engine/models/qwen35/README.md']
for p in current: disk(p)
source_paths=list(dict.fromkeys([x['path'] for x in f['files']]+current))
source_pins=[dict(path=p,bytes=len((R/p).read_bytes()),sha256=sha((R/p).read_bytes())) for p in source_paths]
manifest={'members':[dict(member=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(payload.items())]}
manifest_path=B/'published-member-manifest.json'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8'); disk(manifest_path)
output=E/'inference-engineering-boundaries-2026-10-31.zip'; assert not output.exists()
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(payload.items()):
  info=zipfile.ZipInfo(n,(2026,10,31,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED; z.writestr(info,b)
verified=0
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
 for n,b in payload.items(): assert z.read(n)==b,n; verified+=1
j={'schema':'hyle.finite-engineering-boundaries.v1','date':'2026-10-31','status':'PASS_WITH_RETAINED_FAILURES_AND_FINITE_SCOPE','entry_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Engineering documentation, application/library/test-source ownership, public usage contracts and MSVC Ninja initialization/dependency recovery. Not a model correctness or performance claim.','changes':['Keep product/backend closure and real diagnostics/linkage/install options; no new user selector.','Clarify hyle CLI versus independently usable C++ libraries; centralize common parameters and default commands.','Move Kimi real-weight diagnostic registration into tests; preserve private component and graph-only validation consumer.','Keep Windows compiler children at VSLANG1033, repair retained Ninja parser, and prefer usable cached CMake/CTest.','Recover existing C/CXX objects with empty or missing dependency records through persistent build-local OBJECT_DEPENDS inputs; never delete objects, change source times or compiler flags.','Identify owned targets through the actual CMake directory tree, including external dependency subdirectories while preserving parent/sibling targets.'],'checks':{'script_tests':{'environment':28,'entry':42,'passed':70},'engine_configure_tests':{'passed':9,'skipped':0,'old_layout_regression':'RED retained','no_tests_tree_standalone_and_embedded_generation':'PASS','scope':'Interface SDK facades and retained compiler identity; no SDK or model link claim.'},'real_ninja_migration_tests':{'passed':3,'cases':['zero/missing records, empty TU, same-source shared scope and independent healthy object','embedded parent-root dependency base and genuinely external dependency child','Ninja Multi-Config nondefault Release, with healthy Release object preserved'],'unicode_paths':True,'repeat_no_CXX':True,'source_object_bytes_and_times_unchanged_by_configure':True,'compiler_commands_unchanged':True,'pure_CMake_no_new_Python_requirement':True,'same_source_scope':'A healthy target in the same directory compiling the same source may conservatively rebuild once.'},'public_entry':{'passed_stages':8,'all_exit_zero':True,'offline':True,'reuse':'Existing util build/install/independent consumer; no SDK or source copies.','first_and_final_util_build_CXX':0,'first_and_final_util_build_links':0,'consumer_exit_code':0,'consumer_build':'Existing objects reused; runtime staging executed.','normal_engine_cache_and_global_selection':'bytes and timestamps unchanged'},'docs':{'agent_local_links_and_anchors':88,'help_invocations':4,'root_local_file_links_at_doc_commit':305,'shared_usage_contract_review':'No contradictions found with public headers and CMake; independent Invocations do not override non-concurrent artifact limits.'},'normal_headerdeps_recovery':{'CXX':16,'SDK_CXX':9,'app_CXX':7,'links':3,'NVCC':0,'Ninja_commands_compared':1600,'changed_commands':0,'C_CXX_objects_audited':727,'remaining_legitimate_empty_TUs':3,'three_control_and_new_text_sections_equal':True,'scope':'Earlier actual dependency repair/build only, against preserved worktree sources; not a model runtime check.'}},'limits':['Finite Windows MSVC/Ninja native checks only; no all-platform, all-product, sanitizer, trace or ISA matrix.','CMake3.25 helper signature checked against official tagged source; minimum-version binary execution was not performed.','Actual migration tests use installed CMake4.4; the public util entry reuses its existing compatible cached CMake.','clang-cl follows the MSVC-family environment/helper path but native language-mismatch regression is registered only for actual MSVC; no new clang-cl native result claimed.','No new model inference, GPU performance window or downloads. Current architecture worktree changes remain pending their own liveness verification.'],'history':'All failed reproductions/preparation/configure/encoding attempts are retained in the archive. Historical open migration review is resolved by the later implementation/proofs, not erased.','current_source_pins':source_pins,'archive':{'path':output.name,'bytes':output.stat().st_size,'sha256':sha(output.read_bytes()),'members':len(payload),'payload_bytes':sum(map(len,payload.values())),'manifest_member':manifest_path.relative_to(R).as_posix(),'root_all_members_CRC_SHA_size_and_bytes_verified':True},'proof_index':{'language_cache_and_actual16':'.scratch/inference-msvc-engineering-evidence-20261031/summary-draft.json','kimi':'.scratch/inference-kimi-test-boundary-20261031/summary.json','migration':'.scratch/inference-ninja-headerdeps-migration-20261031/source-freeze.json','public_entry':'.scratch/inference-engineering-boundary-20261031/public-entry-final/summary.json','docs':'.scratch/inference-engineering-entry-docs-20261031/verification.json','shared_usage':'.scratch/inference-engineering-boundary-20261031/shared-usage-review.json','migration_independent_review':'.scratch/inference-engineering-boundary-20261031/ninja-migration-independent-review.json'}}
summary=E/'inference-engineering-boundaries-2026-10-31.json'; assert not summary.exists(); summary.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(B/'root-published-readback.json').write_text(json.dumps(dict(status='PASS',archive=j['archive'],source_pins=len(source_pins),verified_members=verified),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',archive=j['archive'],current_source_pins=len(source_pins))))
