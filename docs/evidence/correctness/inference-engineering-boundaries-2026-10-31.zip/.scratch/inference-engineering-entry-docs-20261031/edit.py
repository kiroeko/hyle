from pathlib import Path
import hashlib,json
R=Path.cwd();B=Path(__file__).resolve().parent
files=['README.md','docs/README.md','docs/developer/setup/README.md','engine/models/qwen35/README.md']
def pin(p):
 p=Path(p);data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'CRLF':data.count(b'\r\n'),'LF':data.count(b'\n')-data.count(b'\r\n')}
before={}
for relative in files:
 source=R/relative;saved=B/'baseline'/relative;assert not saved.exists();saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(source.read_bytes());before[relative]=pin(source)
def update(relative,edit):
 raw=(R/relative).read_bytes();newline='\r\n'if b'\r\n'in raw else'\n';text=raw.decode().replace('\r\n','\n');changed=edit(text);assert changed!=text;result=changed.replace('\n',newline).encode();(R/relative).write_bytes(result)
def once(text,old,new):
 assert text.count(old)==1,old;return text.replace(old,new,1)
def root_readme(s):
 return once(s,'交付形式有完整源码、头文件＋静态库、头文件＋动态库三种，API 相同；不承诺跨编译器或\n跨标准库的 C++ 二进制兼容，详见[交付与集成](docs/user/distribution.md)。',
 '基础库提供完整源码、头文件＋静态库、头文件＋动态库三种交付形式，使用相同的 C++ API；\n不承诺跨编译器或跨标准库的二进制兼容，详见[交付与集成](docs/user/distribution.md)。\n当前引擎交付入口是 `hyle` 命令行程序，稳定的引擎应用 API 尚未交付。')
def docs_index(s):
 s=once(s,'项目内的 Qwen 引擎用于执行真实模型、发现接口与性能问题；通用加载、tokenizer 和服务接口尚未完成。',
 '项目内的 Qwen 引擎用于执行真实模型、发现接口与性能问题；通用加载、tokenizer 和服务接口尚未完成。\n`engine` 构建 `hyle` 命令行应用；基础库可以按产品独立构建、安装，并由 C++ 程序链接 `hyle::<product>`。')
 s=once(s,'| 运行推理引擎 |','| 初始化、构建、测试和安装 | [构建指南](developer/setup/README.md) |\n| 运行推理引擎 |')
 return once(s,'| 修改代码、构建、测试、排障 |','| 修改代码与排障 |')
def setup(s):
 s=once(s,'# CUDA 引擎，启用测试环境\npython scripts/init.py --name inference --components engine --backends cuda --tests',
 '# CUDA 引擎\npython scripts/init.py --name inference --components engine --backends cuda')
 s=once(s,'实际设备与 CPU/GPU 分置仍由应用决定。只构建基础库也可用 `--components mem,container` 或 `compute,graph`。',
 '实际设备与 CPU/GPU 分置仍由应用决定。只构建或安装基础库 SDK 时，可选择 `--components mem,container`\n或 `compute,graph`；C++ 链接方式见[使用指南](../../user/usage-guide.md)。')
 s=once(s,'对上面已启用测试的 `inference` 配置，先构建再运行 CTest：\n\n```text\npython scripts/build.py',
 '对上面的 `inference` 配置显式启用测试，再构建并运行 CTest：\n\n```text\npython scripts/init.py --name inference --tests\npython scripts/build.py')
 return once(s,'`test.py` 不隐式构建；未启用测试时会给出重新初始化的命令。',
 '这次初始化保留该配置的组件和后端。`test.py` 不隐式构建；未启用测试时会给出重新初始化的命令。')
def model_readme(s):
 a=s.index('`--backend cpu|cuda|apple|vulkan` 选择主后端');z=s.index('- `--continuation IDS`',a)
 s=s[:a]+'''后端选择、默认普通生成、采样、MTP 和 CPU／GPU 分置的常用参数统一见
[引擎指南](../../../docs/user/inference.md#常用选项)；构建后端与运行时名称的对应见
[构建说明](../../../docs/user/inference.md#构建)。Model／Session 属于引擎私有实现，
基础库 SDK 不提供稳定的引擎应用 API。

普通与 MTP 都在执行前校验完整旅程：prompt、可选 continuation 和后续最多 `steps−1` 行输入
须容纳于 `--capacity`；`--steps` 包含 prefill 首 token，自然生成遇 EOS 提前停止。

### 输入、会话与诊断参数

以下保留模型特有的文件、资源与诊断合同；完整参数语法以 `hyle --help` 为准。

'''+s[z:]
 lines=s.splitlines(True);prefixes=('- `--mtp on|off`','- `--mtp-max-drafts N`','- `--mtp-min-probability P`','- `--cpu-ffn-layers N`')
 for prefix in prefixes:assert sum(line.startswith(prefix)for line in lines)==1,prefix
 s=''.join(line for line in lines if not line.startswith(prefixes))
 return once(s,'[当前容量实现](session_state.h)','[当前容量实现](cache_plan.h)')
for relative,edit in zip(files,[root_readme,docs_index,setup,model_readme]):update(relative,edit)
report={'status':'FOUR_DOCS_EDITED_ONLY','before':before,'after':{relative:pin(R/relative)for relative in files},'model_or_build_runs':0}
(B/'source-edit-receipt.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'files':files,'EOL_preserved':all((bool(before[f]['CRLF']),bool(before[f]['LF']))==(bool(report['after'][f]['CRLF']),bool(report['after'][f]['LF']))for f in files)},ensure_ascii=False))
