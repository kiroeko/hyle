from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,re,subprocess,time,urllib.parse
R=Path.cwd();B=Path(__file__).resolve().parent
files=['README.md','docs/README.md','docs/developer/setup/README.md','engine/models/qwen35/README.md']
def pin(p):
 p=Path(p);data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'CRLF':data.count(b'\r\n'),'LF':data.count(b'\n')-data.count(b'\r\n')}
def headings(p):
 text=p.read_text(encoding='utf-8-sig');result=set()
 for line in text.splitlines():
  match=re.match(r'^#{1,6}\s+(.+?)\s*#*$',line)
  if match:
   title=re.sub(r'[`*_~]','',match[1]).lower()
   slug=''.join(c for c in title if c.isalnum() or c in ' _-').replace(' ','-');result.add(slug)
 return result
links=[];missing=[]
for relative in files:
 page=R/relative
 for label,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',page.read_text(encoding='utf-8-sig')):
  if '://' in target or target.startswith('mailto:'):continue
  location,_,anchor=target.partition('#');path=(page.parent/urllib.parse.unquote(location)).resolve()if location else page
  item={'source':relative,'label':label,'target':target,'exists':path.exists()}
  if anchor and path.is_file() and path.suffix=='.md':item['anchor_exists']=urllib.parse.unquote(anchor)in headings(path)
  links.append(item)
  if not item['exists']or item.get('anchor_exists')is False:missing.append(item)
(B/'link-check.json').write_text(json.dumps({'checked_pages':files,'local_links':len(links),'missing':missing,'links':links},indent=2,ensure_ascii=False)+'\n',encoding="utf-8")
cases=[('init',['python',str(R/'scripts/init.py'),'--help'],['--name','--components','--backends','--tests','--no-tests']),
 ('build',['python',str(R/'scripts/build.py'),'--help'],['--name','--target','--jobs','--install']),
 ('test',['python',str(R/'scripts/test.py'),'--help'],['--name','--filter','--jobs']),
 ('hyle',[str(R/'.scratch/build-compute-v2-dev/bin/hyle.exe'),'--help'],['--inputs','--mtp','--steps','--capacity','--schedule','--session-schedules','--max-sessions','--active-sequences','--cache-bytes','--prefix-cache','--progress','--replay','--trace','--continuation','--cpu-ffn-layers','--preparation-diagnostics','--layer0-probe'])]
def help_check(case):
 name,argv,options=case;folder=B/'help'/name;folder.mkdir(parents=True,exist_ok=False);start=time.perf_counter()
 process=subprocess.run(argv,cwd=R,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
 (folder/'stdout.log').write_bytes(process.stdout);(folder/'stderr.log').write_bytes(process.stderr)
 text=(process.stdout+process.stderr).decode('utf-8',errors='replace');missing=[option for option in options if option not in text]
 result={'argv':argv,'cwd':str(R),'exit_code':process.returncode,'elapsed_seconds':time.perf_counter()-start,'required_options':options,'missing_options':missing}
 if name=='hyle':result['actual_image']=pin(argv[0])
 (folder/'command-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding="utf-8");return {'case':name,**result}
initial=B/'verification.json'
if initial.exists()and not(B/'verification-initial.json').exists():
 (B/'verification-initial.json').write_bytes(initial.read_bytes())
helps=[]
parser=R/'engine/models/qwen35/main.cc';parser_text=parser.read_text(encoding='utf-8-sig')
for name,argv,options in cases:
 result=json.loads((B/'help'/name/'command-result.json').read_text(encoding='utf-8-sig'))
 # Reuse the four real, terminal --help invocations, rather than rerunning.
 option_missing=result['missing_options'];source_verified=[]
 if name=='hyle':
  source_verified=[option for option in option_missing if re.search(r'option\s*==\s*"'+re.escape(option)+'"',parser_text)]
  result['not_enumerated_by_help']=option_missing;result['source_parser_verified_options']=source_verified
  result['parser_source']=pin(parser);result['missing_options']=[option for option in option_missing if option not in source_verified]
 helps.append({'case':name,**result})
diff=subprocess.run(['git','diff','--check','--',*files],cwd=R,capture_output=True,text=True)
(B/'diff-check.stdout.log').write_text(diff.stdout,encoding='utf-8')
(B/'diff-check.stderr.log').write_text(diff.stderr,encoding='utf-8')
before=json.loads((B/'source-edit-receipt.json').read_text(encoding='utf-8-sig'))['before'];after={f:pin(R/f)for f in files};eol=all((bool(before[f]['CRLF']),bool(before[f]['LF']))==(bool(after[f]['CRLF']),bool(after[f]['LF']))for f in files)
report={'status':'PASS'if not missing and all(p['exit_code']==0 and not p['missing_options']for p in helps)and not diff.returncode and eol else'FAIL','source_pins':after,'local_links_checked':len(links),'missing_links_or_anchors':missing,'link_check':str(B/'link-check.json'),'help_cases':helps,'original_EOLS_preserved':eol,'diff_check_exit_code':diff.returncode,'build_or_configure':0,'model_runs':0,'GPU_model_runs':0,'downloads':0,'scope':'Documentation links/anchors and four --help invocations only; no build, initialization or model inference. Existing source modifications and frozen five-arm candidate remain untouched.'}
(B/'verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'links':len(links),'missing':missing,'help':[{k:p[k]for k in ['case','exit_code','missing_options']}for p in helps],'EOL_preserved':eol,'diff_check':diff.returncode,'report':str(B/'verification.json')},ensure_ascii=False))
assert report['status']=='PASS'
