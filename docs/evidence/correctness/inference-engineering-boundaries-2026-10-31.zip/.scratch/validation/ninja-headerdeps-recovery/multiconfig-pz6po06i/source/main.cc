#include "data.h"
int probe() { return VALUE; }
