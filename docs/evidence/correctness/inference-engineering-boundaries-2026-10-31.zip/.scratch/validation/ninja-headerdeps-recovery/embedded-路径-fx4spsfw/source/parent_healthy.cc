#include "parent.h"
int parent_healthy() { return VALUE; }
