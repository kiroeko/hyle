#include "child.h"
int child() { return VALUE; }
