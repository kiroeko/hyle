int parent_zero() { return 1; }
