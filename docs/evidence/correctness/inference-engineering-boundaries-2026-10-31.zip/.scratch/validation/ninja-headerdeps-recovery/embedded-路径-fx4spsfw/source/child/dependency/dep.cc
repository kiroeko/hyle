#include "dep.h"
int dependency() { return VALUE; }
