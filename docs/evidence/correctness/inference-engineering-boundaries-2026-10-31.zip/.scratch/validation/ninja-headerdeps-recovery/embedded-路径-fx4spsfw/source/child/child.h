#define VALUE 7
