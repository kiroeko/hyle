int empty() { return 1; }
