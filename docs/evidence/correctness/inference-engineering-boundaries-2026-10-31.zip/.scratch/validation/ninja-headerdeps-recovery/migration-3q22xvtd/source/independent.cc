#include "independent.h"
int independent() { return VALUE; }
