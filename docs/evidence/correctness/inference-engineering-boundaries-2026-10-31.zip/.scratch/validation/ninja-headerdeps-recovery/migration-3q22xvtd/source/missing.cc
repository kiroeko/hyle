#include "missing.h"
int missing() { return VALUE; }
