#include "shared.h"
int shared() { return VALUE; }
