#include "healthy.h"
int healthy() { return VALUE; }
