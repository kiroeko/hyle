from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import reproduce as record

ROOT = record.ROOT
BATCH = Path(__file__).resolve().parent / 'headerdeps-recovery-plan-v2'
BUILD = ROOT / '.scratch/build-compute-v2-dev'
record.BATCH = BATCH


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'mtime_ns': path.stat().st_mtime_ns}


def main():
    BATCH.mkdir(exist_ok=False)
    manifest_before = pin(BUILD / 'build.ninja')
    database_before = pin(BUILD / '.ninja_deps')
    cache = (BUILD / 'CMakeCache.txt').read_text()
    ninja = next(line.split('=', 1)[1] for line in cache.splitlines()
                 if line.startswith('CMAKE_MAKE_PROGRAM:FILEPATH='))
    commands = record.run('query-engine-commands', [ninja, '-t', 'commands', 'hyle_engine'], dict(os.environ), BUILD)
    graph = record.run('query-engine-graph', [ninja, '-t', 'graph', 'hyle_engine'], dict(os.environ), BUILD)
    deps = record.run('query-all-current-deps', [ninja, '-t', 'deps'], dict(os.environ), BUILD)
    # Ninja graph labels are quoted with the same slash/backslash escapes as JSON.
    labels = {json.loads('"' + found + '"').replace('\\', '/').lower()
              for found in re.findall(rb'\[label="((?:[^"\\]|\\.)*)"', graph) for found in [found.decode()]}
    dependency_counts = {}
    for line in deps.decode('utf-8', errors='replace').splitlines():
        match = re.match(r'(.+): #deps (\d+), deps mtime (\d+) \(([^)]+)\)', line)
        if match:
            dependency_counts[match[1].replace('\\', '/').lower()] = {
                'count': int(match[2]), 'ninja_status': match[4], 'deps_mtime': match[3]}
    compdb = json.loads(record.run('query-actual-ninja-compdb', [ninja, '-t', 'compdb'], dict(os.environ), BUILD))
    closure, missing = [], []
    for entry in compdb:
        obj = Path(entry['output'])
        if not obj.is_absolute():
            obj = BUILD / obj
        relative = obj.relative_to(BUILD).as_posix()
        if relative.lower() not in labels:
            continue
        source = Path(entry['file'])
        if not source.is_absolute():
            source = BUILD / source
        if source.suffix.lower() not in ('.c', '.cc', '.cpp', '.cxx'):
            continue
        info = dependency_counts.get(relative.lower())
        row = {'object': relative, 'source': str(source), 'dependency_record': info,
               'source_pin': pin(source), 'object_pin': pin(obj) if obj.is_file() else None,
               'command': entry['command']}
        closure.append(row)
        if info is None or info['count'] == 0:
            text = source.read_text(encoding='utf-8', errors='replace')
            row['source_include_directives'] = [line for line in text.splitlines()
                                                if re.match(r'\s*#\s*include\b', line)]
            row['forced_include_in_command'] = bool(re.search(r'(?:^|\s)[/-]FI', entry['command']))
            row['classification'] = ('HEADER_SOURCE_REQUIRES_DEPS_RECOVERY' if row['source_include_directives']
                                     or row['forced_include_in_command'] else 'NEEDS_MANUAL_NO_HEADER_REVIEW')
            missing.append(row)
    manifest_after = pin(BUILD / 'build.ninja')
    database_after = pin(BUILD / '.ninja_deps')
    assert manifest_before == manifest_after and database_before == database_after
    result = {'status': 'READ_ONLY_PLAN_NO_RECOVERY_EXECUTED', 'target': 'hyle_engine',
              'actual_C_CXX_object_closure': len(closure), 'zero_or_missing_dependency_records': len(missing),
              'zero_header_sources': sum(row['classification'] == 'HEADER_SOURCE_REQUIRES_DEPS_RECOVERY' for row in missing),
              'objects': missing, 'all_C_CXX_closure': closure,
              'normal_manifest_before_after_equal': True, 'normal_dependency_database_before_after_equal': True,
              'limits': ['Source #include evidence is static; conditional includes need manual classification. No compiler/preprocessor run.',
                         'Only C/CXX actual hyle_engine dependency graph objects examined; CUDA .cu is excluded from recovery.',
                         'No cache regeneration, object/source modification, cleanup, timestamp change, model or GPU run.'],
              'proposed_recovery_not_executed': 'Root schedules real Ninja CXX with English env for exact source/object list, then verifies real headerdeps. Lost deps are not synthesized.'}
    record.put(BATCH / 'plan.json', result)
    print(json.dumps({key: result[key] for key in ['actual_C_CXX_object_closure', 'zero_or_missing_dependency_records', 'zero_header_sources']}, indent=2))
    print('\n'.join(row['object'] + ' <- ' + row['source'] for row in missing))


if __name__ == '__main__':
    main()
