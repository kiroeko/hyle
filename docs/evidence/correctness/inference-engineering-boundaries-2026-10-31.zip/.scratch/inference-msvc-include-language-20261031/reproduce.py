from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
CMAKE = Path('C:/Program Files/CMake/bin/cmake.exe')
NINJA = Path('C:/Program Files/Python314/Scripts/ninja.exe')
CL = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')


def put(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def run(label, args, env, cwd):
    destination = BATCH / label
    destination.mkdir(parents=True, exist_ok=False)
    put(destination / 'command.json', {'argv': [str(a) for a in args], 'cwd': str(cwd),
                                     'VSLANG': env.get('VSLANG')})
    started = time.time()
    process = subprocess.Popen([str(a) for a in args], cwd=cwd, env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    put(destination / 'process.json', {'pid': process.pid, 'started_unix': started, 'status': 'RUNNING'})
    stdout, stderr = process.communicate()
    (destination / 'stdout.log').write_bytes(stdout)
    (destination / 'stderr.log').write_bytes(stderr)
    result = {'pid': process.pid, 'exit_code': process.returncode, 'status': 'TERMINAL',
              'started_unix': started, 'ended_unix': time.time()}
    put(destination / 'process.json', result)
    if process.returncode:
        raise RuntimeError(f'{label} failed: {process.returncode}')
    return stdout + stderr


def main():
    saved = json.loads((ROOT / '.scratch/inference-default-product-build-20261031/environment.json').read_text(encoding='utf-8-sig'))
    env = dict(os.environ)
    env.update(saved)
    env.pop('VSLANG', None)
    english = dict(env, VSLANG='1033')
    # Reuse the actual selected normal-cache build tool, not PATH discovery.
    cache = (ROOT / '.scratch/build-compute-v2-dev/CMakeCache.txt').read_text(encoding='utf-8')
    ninja = next(line.split('=', 1)[1] for line in cache.splitlines()
                 if line.startswith('CMAKE_MAKE_PROGRAM:FILEPATH='))
    source = BATCH / 'fixture'
    source.mkdir(exist_ok=False)
    (source / 'CMakeLists.txt').write_text(
        'cmake_minimum_required(VERSION 3.25)\nproject(IncludeLanguage LANGUAGES CXX)\n'
        'add_library(probe OBJECT main.cc)\n', encoding='utf-8')
    header = source / 'packet_config.h'
    header.write_text('#define PACKET_VALUE 7\n', encoding='utf-8')
    (source / 'main.cc').write_text('#include "packet_config.h"\nint probe() { return PACKET_VALUE; }\n', encoding='utf-8')
    builds = {}
    for arm, child in [('legacy', env), ('english', english)]:
        build = BATCH / f'build-{arm}'
        builds[arm] = build
        run(f'{arm}-configure', [CMAKE, '-S', source, '-B', build, '-G', 'Ninja',
                               f'-DCMAKE_MAKE_PROGRAM={ninja}', f'-DCMAKE_CXX_COMPILER={CL}',
                               '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY'], english, BATCH)
        run(f'{arm}-build', [CMAKE, '--build', build, '--verbose', '--parallel', '1'], child, BATCH)
        run(f'{arm}-deps', [ninja, '-t', 'deps'], child, build)
    header.write_text('#define PACKET_VALUE 9\n', encoding='utf-8')
    dirty = {}
    for arm, child in [('legacy', env), ('english', english)]:
        output = run(f'{arm}-header-change-dry-run', [ninja, '-n'], child, builds[arm])
        dirty[arm] = b'Building CXX object' in output
    run('english-header-change-rebuild', [CMAKE, '--build', builds['english'], '--verbose', '--parallel', '1'], english, BATCH)
    run('english-rebuilt-deps', [ninja, '-t', 'deps'], english, builds['english'])
    arms = {}
    for arm in builds:
        deps = (BATCH / f'{arm}-deps/stdout.log').read_bytes()
        build_output = (BATCH / f'{arm}-build/stdout.log').read_bytes()
        include_lines = [line for line in build_output.splitlines() if b'packet_config.h' in line]
        arms[arm] = {'header_in_actual_ninja_deps': b'packet_config.h' in deps,
                     'header_change_detected': dirty[arm],
                     'showincludes_lines_hex': [line.hex() for line in include_lines],
                     'showincludes_lines_cp936': [line.decode('cp936', errors='replace') for line in include_lines]}
    report = {'scope': 'Independent tiny CXX/Ninja projects only; normal cache and existing objects untouched.',
              'configure_VSLANG': '1033', 'legacy_build_VSLANG': None,
              'english_build_VSLANG': '1033', 'arms': arms,
              'expected_old_red': not arms['legacy']['header_in_actual_ninja_deps'] and not dirty['legacy'],
              'expected_fixed_pass': arms['english']['header_in_actual_ninja_deps'] and dirty['english'],
              'normal_environment_sha256': hashlib.sha256((ROOT / '.scratch/inference-default-product-build-20261031/environment.json').read_bytes()).hexdigest()}
    put(BATCH / 'reproduction.json', report)
    assert report['expected_old_red'] and report['expected_fixed_pass'], report
    print(json.dumps({'old_deps_missing': report['expected_old_red'], 'english_deps_and_dirty_pass': report['expected_fixed_pass']}))


if __name__ == '__main__':
    main()
