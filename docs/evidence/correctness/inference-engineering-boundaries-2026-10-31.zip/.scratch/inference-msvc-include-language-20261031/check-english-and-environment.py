from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import sys
import urllib.request
import reproduce as record

ROOT = record.ROOT
BATCH = Path(__file__).resolve().parent / 'english-skip-proof'
record.BATCH = BATCH


def pin(path):
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'mtime_ns': path.stat().st_mtime_ns}


def main():
    BATCH.mkdir(exist_ok=False)
    sys.path.insert(0, str(ROOT / 'scripts'))
    import hyle_environment as tools
    cache = {}
    for line in (ROOT / '.scratch/build-compute-v2-dev/CMakeCache.txt').read_text().splitlines():
        if line and not line.startswith(('#', '//')) and ':' in line and '=' in line:
            key, value = line.split('=', 1)
            cache[key.split(':', 1)[0]] = value
    prior = dict(os.environ)
    os.environ['VSLANG'] = '2052'
    supplied = dict(os.environ)
    selected = tools.discover_environment(cache=cache, configuring=True)
    assert dict(os.environ) == supplied
    os.environ.clear()
    os.environ.update(prior)
    assert selected.env['VSLANG'] == '1033'
    record.put(BATCH / 'actual-child-environment.json', {'external_VSLANG': '2052', 'child_VSLANG': selected.env['VSLANG'],
               'parent_unchanged': True, 'selected_cxx': selected.cxx, 'selected_cmake': selected.cmake,
               'selected_generator': selected.generator, 'INCLUDE_present': bool(selected.env.get('INCLUDE')),
               'LIB_present': bool(selected.env.get('LIB')), 'WindowsSdkDir_present': bool(selected.env.get('WINDOWSSDKDIR'))})
    source, build = BATCH / 'fixture', BATCH / 'build'
    source.mkdir()
    (source / 'CMakeLists.txt').write_text(
        'cmake_minimum_required(VERSION 3.25)\nproject(IncludeLanguage LANGUAGES CXX)\n'
        f'include("{(ROOT / "cmake/HyleBuildContract.cmake").as_posix()}")\n'
        'add_library(probe OBJECT main.cc)\ntarget_link_libraries(probe PRIVATE hyle::_build_contract)\n', encoding='utf-8')
    (source / 'main.cc').write_text('#include "packet_config.h"\nint probe() { return PACKET_VALUE; }\n')
    (source / 'packet_config.h').write_text('#define PACKET_VALUE 7\n')
    command = [selected.cmake, '-S', source, '-B', build, '-G', 'Ninja',
               f'-DCMAKE_MAKE_PROGRAM={cache["CMAKE_MAKE_PROGRAM"]}', f'-DCMAKE_CXX_COMPILER={selected.cxx}',
               '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY']
    record.run('configure-first', command, selected.env, BATCH)
    detection_object = build / 'CMakeFiles/ShowIncludes/main.obj'
    before = pin(detection_object)
    record.run('configure-repeat', command, selected.env, BATCH)
    after = pin(detection_object)
    assert before == after
    record.run('actual-helper-env-build', [selected.cmake, '--build', build, '--verbose', '--parallel', '1'], selected.env, BATCH)
    deps = record.run('actual-helper-env-deps', [cache['CMAKE_MAKE_PROGRAM'], '-t', 'deps'], selected.env, build)
    assert b'packet_config.h' in deps
    record.put(BATCH / 'proof.json', {'existing_English_prefix_does_not_reprobe': before == after,
               'official_detection_object_before': before, 'after_repeat': after,
               'actual_script_selected_env_has_real_header_deps': b'packet_config.h' in deps,
               'normal_cache_and_objects_untouched': True})
    url = 'https://raw.githubusercontent.com/Kitware/CMake/v3.25.0/Modules/CMakeDetermineCompilerId.cmake'
    with urllib.request.urlopen(url, timeout=20) as response:
        official = response.read()
    start = official.index(b'function(CMAKE_DETERMINE_MSVC_SHOWINCLUDES_PREFIX lang userflags)')
    excerpt = official[start:official.index(b'endfunction()', start) + len(b'endfunction()')]
    (BATCH / 'cmake-3.25-official-helper.cmake').write_bytes(excerpt + b'\n')
    record.put(BATCH / 'official-helper-source.json', {'url': url, 'tag': 'v3.25.0', 'full_source_bytes': len(official),
               'full_source_sha256': hashlib.sha256(official).hexdigest(), 'saved': 'Exact function excerpt only',
               'signature': 'CMAKE_DETERMINE_MSVC_SHOWINCLUDES_PREFIX(lang,userflags)',
               'compatibility': 'Source signature and variables checked; CMake 3.25 binary not installed/run. Actual CMake4.4 run passed.'})
    print('Actual public environment 2052→1033, parent unchanged, header deps, repeated English configure no-probe: PASS')


if __name__ == '__main__':
    main()
