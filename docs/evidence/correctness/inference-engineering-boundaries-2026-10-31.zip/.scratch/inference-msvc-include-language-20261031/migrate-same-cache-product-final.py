from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import reproduce as record

ROOT = record.ROOT
BATCH = Path(__file__).resolve().parent / 'same-cache-product-final-proof'
record.BATCH = BATCH


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'mtime_ns': path.stat().st_mtime_ns}


def main():
    BATCH.mkdir(exist_ok=False)
    env = dict(os.environ)
    env.update(json.loads((ROOT / '.scratch/inference-default-product-build-20261031/environment.json').read_text()))
    chinese, english = dict(env, VSLANG='2052'), dict(env, VSLANG='1033')
    normal_cache = (ROOT / '.scratch/build-compute-v2-dev/CMakeCache.txt').read_text()
    ninja = next(line.split('=', 1)[1] for line in normal_cache.splitlines()
                 if line.startswith('CMAKE_MAKE_PROGRAM:FILEPATH='))
    source, build = BATCH / 'fixture', BATCH / 'build'
    source.mkdir()
    (source / 'CMakeLists.txt').write_text(
        'cmake_minimum_required(VERSION 3.25)\nproject(IncludeLanguage LANGUAGES CXX)\n'
        f'include("{(ROOT / "cmake/HyleBuildContract.cmake").as_posix()}")\n'
        'add_library(probe OBJECT main.cc)\ntarget_link_libraries(probe PRIVATE hyle::_build_contract)\n', encoding='utf-8')
    header = source / 'packet_config.h'
    main_source = source / 'main.cc'
    header.write_text('#define PACKET_VALUE 7\n')
    main_source.write_text('#include "packet_config.h"\nint probe() { return PACKET_VALUE; }\n')
    command = [record.CMAKE, '-S', source, '-B', build, '-G', 'Ninja',
               f'-DCMAKE_MAKE_PROGRAM={ninja}', f'-DCMAKE_CXX_COMPILER={record.CL}',
               '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY']
    run = record.run
    run('configure-chinese', command, chinese, BATCH)
    run('build-chinese', [record.CMAKE, '--build', build, '--verbose', '--parallel', '1'], chinese, BATCH)
    commands_before = run('commands-before', [ninja, '-t', 'commands', 'probe'], chinese, build)
    object_path = build / 'CMakeFiles/probe.dir/main.cc.obj'
    initial = pin(object_path)
    mismatch_deps = run('deps-before-repair', [ninja, '-t', 'deps'], english, build)
    before_config = pin(object_path)
    run('configure-cache-variable-attempt', command + ['-DCMAKE_CL_SHOWINCLUDES_PREFIX=Note: including file: ',
                                                    '-DCMAKE_CXX_CL_SHOWINCLUDES_PREFIX=Note: including file: '], chinese, BATCH)
    rules = build / 'CMakeFiles/rules.ninja'
    after_cache_override = rules.read_bytes()
    (BATCH / 'rules-after-cache-override.ninja').write_bytes(after_cache_override)
    run('configure-scope-probe', command, english, BATCH)
    after_probe = rules.read_bytes()
    (BATCH / 'rules-after-scope-probe.ninja').write_bytes(after_probe)
    commands_after = run('commands-after', [ninja, '-t', 'commands', 'probe'], english, build)
    after_config = pin(object_path)
    no_work = run('dry-run-after-scope-probe', [ninja, '-n'], english, build)
    main_source.write_text('#include "packet_config.h"\nint probe() { return PACKET_VALUE + 1; }\n')
    run('rebuild-one-source', [record.CMAKE, '--build', build, '--verbose', '--parallel', '1'], english, BATCH)
    repaired_deps = run('deps-after-rebuild', [ninja, '-t', 'deps'], english, build)
    header.write_text('#define PACKET_VALUE 11\n')
    detected = run('header-change-dry-run', [ninja, '-n'], english, build)
    prefix = lambda data: next(line for line in data.splitlines() if line.startswith(b'msvc_deps_prefix'))
    result = {'existing_localized_parser_has_lost_header_deps': b'packet_config.h' not in mismatch_deps,
              'cache_D_override_did_not_replace_compiler_normal_variable': b'Note: including file:' not in prefix(after_cache_override),
              'scope_probe_actual_English_prefix': prefix(after_probe).decode('utf-8'),
              'CXX_command_bytes_unchanged': commands_before == commands_after,
              'object_bytes_and_mtime_unchanged_by_two_reconfigures': before_config == after_config,
              'reconfigure_did_not_force_object_rebuild': b'no work to do' in no_work,
              'lost_deps_require_explicit_affected_object_rebuild': True,
              'rebuilt_object_has_actual_header_deps': b'packet_config.h' in repaired_deps,
              'later_header_change_detected': b'Building CXX object' in detected,
              'initial_object': initial, 'before_reconfigure_object': before_config,
              'after_reconfigure_object': after_config,
              'scope': 'Actual product HyleBuildContract included by one tiny project; normal cache and objects untouched. Chinese CMake prefix was already wrongly transcoded before repair.'}
    record.put(BATCH / 'migration-proof.json', result)
    assert all(result[key] for key in ['existing_localized_parser_has_lost_header_deps', 'cache_D_override_did_not_replace_compiler_normal_variable',
                'CXX_command_bytes_unchanged', 'object_bytes_and_mtime_unchanged_by_two_reconfigures',
                'reconfigure_did_not_force_object_rebuild', 'rebuilt_object_has_actual_header_deps', 'later_header_change_detected'])
    print(json.dumps(result, ensure_ascii=True))


if __name__ == '__main__':
    main()
