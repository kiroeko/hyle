# Reuse already discovered compiler identity; no try_compile or CXX execution.
include("C:/public/project-hyle/hyle/.scratch/build-compute-v2-dev/CMakeFiles/4.4.0/CMakeCXXCompiler.cmake")
set(CMAKE_CXX_COMPILER_FORCED TRUE)
set(CMAKE_MAKE_PROGRAM "C:/Program Files/Python312/Scripts/ninja.exe" CACHE FILEPATH "" FORCE)
