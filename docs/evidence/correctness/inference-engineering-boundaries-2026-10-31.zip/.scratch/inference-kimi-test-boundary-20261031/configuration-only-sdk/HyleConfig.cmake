# Interface fixture: source layout/generation only, no native SDK validation.
foreach(product IN ITEMS compute graph graph_progress compute_stream mem)
  add_library(hyle::${product} INTERFACE IMPORTED)
endforeach()
set(Hyle_AVAILABLE_COMPUTE_ROUTES "cpu;cuda")
include("C:/public/project-hyle/hyle/cmake/HyleRuntimeStaging.cmake")
