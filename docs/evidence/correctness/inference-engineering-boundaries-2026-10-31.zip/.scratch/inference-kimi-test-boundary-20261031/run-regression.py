from pathlib import Path
import importlib.util
import json
import os
import subprocess
import time
import unittest

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
TEST = ROOT / 'tests/tooling/engine_components_test.py'
spec = importlib.util.spec_from_file_location('engine_components_regression', TEST)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

os.environ.update(json.loads((ROOT / '.scratch/inference-default-product-build-20261031/environment.json').read_text()))
os.environ['CMAKE_GENERATOR'] = 'Ninja'
os.environ['CMAKE_TOOLCHAIN_FILE'] = str(BATCH / 'cached-compiler.cmake')
os.environ['PATH'] = 'C:/Program Files/CMake/bin;' + os.environ['PATH']
records = []
phase = 'unstarted'
original_run = subprocess.run


def recorded_run(command, **kwargs):
    start = time.time()
    result = original_run(command, **kwargs)
    directory = BATCH / 'regression' / phase / 'commands' / f'{len(records) + 1:02}'
    directory.mkdir(parents=True, exist_ok=True)
    record = {'command': command, 'exit_code': result.returncode, 'seconds': time.time() - start,
              'cwd': str(Path.cwd()), 'compiler_identity_reused_without_try_compile': True}
    (directory / 'stdout.log').write_text(result.stdout, encoding='utf-8')
    (directory / 'stderr.log').write_text(result.stderr, encoding='utf-8')
    (directory / 'process.json').write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    return result


module.subprocess.run = recorded_run


def retained_set_up(self):
    self.directory = BATCH / 'regression' / phase / self._testMethodName
    self.directory.mkdir(parents=True, exist_ok=False)


module.EngineComponentsTest.setUp = retained_set_up
module.EngineComponentsTest.tearDown = lambda self: None
new_case = 'test_cuda_tests_off_keeps_kimi_diagnostic_out_of_application'
minimal = BATCH / 'minimal-source'
(minimal / 'cmake/HyleRuntimeStaging.cmake').write_bytes((ROOT / 'cmake/HyleRuntimeStaging.cmake').read_bytes())
model = minimal / 'engine/models/kimi_k3/CMakeLists.txt'

phase = 'old-layout-red'
module.ROOT = minimal
model.write_bytes((BATCH / 'base/engine/models/kimi_k3/CMakeLists.txt').read_bytes())
try:
    with (BATCH / 'regression-red.log').open('w', encoding='utf-8') as output:
        result = unittest.TextTestRunner(stream=output, verbosity=2).run(
            unittest.TestSuite([module.EngineComponentsTest(new_case)]))
    assert result.testsRun == 1 and len(result.failures) == 1 and not result.errors
    assert 'testsOFF application acquired the Kimi test diagnostic' in result.failures[0][1]
finally:
    model.write_bytes((ROOT / 'engine/models/kimi_k3/CMakeLists.txt').read_bytes())

phase = 'current-layout-green'
module.ROOT = ROOT
suite = unittest.defaultTestLoader.loadTestsFromTestCase(module.EngineComponentsTest)
with (BATCH / 'regression-green.log').open('w', encoding='utf-8') as output:
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
assert result.wasSuccessful(), (result.failures, result.errors)
summary = {'new_regression_old_layout': {'tests': 1, 'failures': 1, 'reason': 'Kimi diagnostic appeared in actual CUDA testsOFF target graph'},
           'current_engine_components_group': {'tests': result.testsRun, 'failures': len(result.failures),
                                                'errors': len(result.errors), 'skipped': len(result.skipped)},
           'configure_processes': len(records), 'sdk_cxx_link_native_processes': 0,
           'environment_source': str(ROOT / '.scratch/inference-default-product-build-20261031/environment.json'),
           'compiler_check_scope': 'Existing MSVC compiler identity supplied via toolchain; configure/generate tests only.',
           'retained_configurations': 'regression/', 'normal_cache_reconfigured': False}
(BATCH / 'regression-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
