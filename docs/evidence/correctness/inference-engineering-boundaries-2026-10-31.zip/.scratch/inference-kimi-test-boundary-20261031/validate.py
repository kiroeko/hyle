from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
CMAKE = Path('C:/Program Files/CMake/bin/cmake.exe')
NINJA = Path('C:/Program Files/Python312/Scripts/ninja.exe')
CACHE = ROOT / '.scratch/build-compute-v2-dev'
SOURCE = BATCH / 'minimal-source'
SOURCE.mkdir(exist_ok=True)


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8', newline='\n')


def copy(path):
    dest = SOURCE / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((ROOT / path).read_bytes())


def link(path):
    dest = SOURCE / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        os.link(ROOT / path, dest)
    assert dest.read_bytes() == (ROOT / path).read_bytes()


def run(name, args, expected=0):
    directory = BATCH / 'validation' / name
    directory.mkdir(parents=True, exist_ok=True)
    if (directory / 'process.json').exists():
        record = json.loads((directory / 'process.json').read_text())
        assert (record['exit_code'] == 0) == (expected == 0)
        return record
    start = time.time()
    result = subprocess.run([str(x) for x in args], capture_output=True, cwd=ROOT, timeout=45)
    (directory / 'stdout.log').write_bytes(result.stdout)
    (directory / 'stderr.log').write_bytes(result.stderr)
    record = {'command': [str(x) for x in args], 'exit_code': result.returncode,
              'expected_exit_code': expected, 'seconds': time.time() - start}
    write(directory / 'process.json', json.dumps(record, indent=2) + '\n')
    assert (result.returncode == 0) == (expected == 0), (name, result.stdout.decode(errors='replace'), result.stderr.decode(errors='replace'))
    return record


cmake_files = ['engine/CMakeLists.txt', 'engine/models/qwen35/CMakeLists.txt',
               'engine/models/qwen35/cold_sources.cmake', 'engine/models/kimi_k3/CMakeLists.txt',
               'engine/models/kimi_k3/component_sources.cmake', 'cmake/HyleWarnings.cmake',
               'cmake/HylePackage.cmake']
for relative in cmake_files:
    copy(relative)
source_files = ['engine/main.cc', 'engine/reporting/execution_report.cc',
                'engine/models/qwen35/main.cc', 'engine/models/qwen35/native_gate.cc']
source_files += ['engine/models/qwen35/' + name + '.cc' for name in
                 ['weights', 'graph_builder', 'target_graph', 'family_factory', 'phase_preparation',
                  'auxiliary_programs', 'mtp_session_probe', 'retirement_probe', 'batch_probe']]
source_files += ['engine/models/kimi_k3/' + name + '.cc' for name in ['roles', 'cold_graph', 'component']]
for relative in source_files + ['LICENSE', 'NOTICE', 'THIRD_PARTY_NOTICES.md']:
    link(relative)
assert not (SOURCE / 'tests').exists()

compiler_info = CACHE / 'CMakeFiles/4.4.0/CMakeCXXCompiler.cmake'
assert compiler_info.exists()
toolchain = BATCH / 'cached-compiler.cmake'
write(toolchain, f'''# Reuse already discovered compiler identity; no try_compile or CXX execution.
include("{compiler_info.as_posix()}")
set(CMAKE_CXX_COMPILER_FORCED TRUE)
set(CMAKE_MAKE_PROGRAM "{NINJA.as_posix()}" CACHE FILEPATH "" FORCE)
''')
sdk = BATCH / 'configuration-only-sdk'
write(sdk / 'HyleConfig.cmake', f'''# Interface fixture: source layout/generation only, no native SDK validation.
foreach(product IN ITEMS compute graph graph_progress compute_stream mem)
  add_library(hyle::${{product}} INTERFACE IMPORTED)
endforeach()
set(Hyle_AVAILABLE_COMPUTE_ROUTES "cpu;cuda")
include("{(ROOT / 'cmake/HyleRuntimeStaging.cmake').as_posix()}")
''')
write(sdk / 'HyleConfigVersion.cmake', '''set(PACKAGE_VERSION "0.1.0")
if(PACKAGE_FIND_VERSION VERSION_EQUAL PACKAGE_VERSION)
  set(PACKAGE_VERSION_EXACT TRUE)
  set(PACKAGE_VERSION_COMPATIBLE TRUE)
endif()
''')
args = ['-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', f'-DCMAKE_TOOLCHAIN_FILE={toolchain.as_posix()}',
        f'-DHyle_DIR={sdk.as_posix()}', '-DFETCHCONTENT_FULLY_DISCONNECTED=ON']

# Genuine old source-layout failure, using exactly the same no-tests source view.
model = SOURCE / 'engine/models/kimi_k3/CMakeLists.txt'
model.write_bytes((BATCH / 'base/engine/models/kimi_k3/CMakeLists.txt').read_bytes())
old = run('standalone-before', [CMAKE, '-S', SOURCE / 'engine', '-B', BATCH / 'build-before', *args], expected=1)
old_error = (BATCH / 'validation/standalone-before/stderr.log').read_text()
assert 'kimi_kda_mla_probe.cc' in old_error and 'Cannot find source file' in old_error
model.write_bytes((ROOT / 'engine/models/kimi_k3/CMakeLists.txt').read_bytes())
fixed = run('standalone-after', [CMAKE, '-S', SOURCE / 'engine', '-B', BATCH / 'build-after', *args])
generated = (BATCH / 'build-after/build.ninja').read_text()
assert 'kimi_kda_mla_probe' not in generated
assert '/tests/' not in generated
assert 'hyle_kimi_k3_component' in generated
run('standalone-engine-query', [NINJA, '-C', BATCH / 'build-after', '-t', 'query', 'hyle_engine'])
engine_query = (BATCH / 'validation/standalone-engine-query/stdout.log').read_text()
assert 'hyle_kimi_k3_component' not in engine_query

embedded = BATCH / 'embedded'
write(embedded / 'CMakeLists.txt', f'''cmake_minimum_required(VERSION 3.25)
project(EngineBoundary LANGUAGES CXX)
include("{(sdk / 'HyleConfig.cmake').as_posix()}")
set(HYLE_COMPUTE_ROUTE_LIST "cpu;cuda")
add_subdirectory("{(SOURCE / 'engine').as_posix()}" engine)
if(TARGET hyle_kimi_kda_mla_probe)
  message(FATAL_ERROR "testsOFF acquired a diagnostic")
endif()
''')
run('embedded-tests-off', [CMAKE, '-S', embedded, '-B', BATCH / 'build-embedded', *args])

# Test the exact moved registration block, rather than a rewritten equivalent.
tests_text = (ROOT / 'tests/CMakeLists.txt').read_text()
begin = tests_text.index('if(TARGET hyle_engine AND _HYLE_COMPUTE_HAVE_CUDA)\n')
end = tests_text.index('  hyle_add_test(graph_route_cuda NAME inference_submission_views', begin)
registration = tests_text[begin:end] + 'endif()\n'
test_entry = BATCH / 'test-entry'
write(test_entry / 'CMakeLists.txt', f'''cmake_minimum_required(VERSION 3.25)
project(EngineTestBoundary LANGUAGES CXX)
set(HYLE_SANITIZER off)
include("{(sdk / 'HyleConfig.cmake').as_posix()}")
include("{(ROOT / 'cmake/HyleWarnings.cmake').as_posix()}")
include("{(ROOT / 'cmake/HyleSanitizers.cmake').as_posix()}")
set(HYLE_COMPUTE_ROUTE_LIST "cpu;cuda")
set(_HYLE_COMPUTE_HAVE_CUDA TRUE)
add_subdirectory("{(SOURCE / 'engine').as_posix()}" engine)
add_subdirectory(tests)
get_target_property(excluded hyle_kimi_kda_mla_probe EXCLUDE_FROM_ALL)
get_target_property(owner hyle_kimi_kda_mla_probe HYLE_TEST_MODULE)
get_target_property(links hyle_engine LINK_LIBRARIES)
if(NOT excluded OR NOT owner STREQUAL "project" OR "hyle_kimi_k3_component" IN_LIST links)
  message(FATAL_ERROR "diagnostic/default app ownership changed")
endif()
''')
write(test_entry / 'tests/CMakeLists.txt', registration)
(test_entry / 'tests/tools').mkdir(exist_ok=True)
probe_link = test_entry / 'tests/tools/kimi_kda_mla_probe.cc'
if not probe_link.exists():
    os.link(ROOT / 'tests/tools/kimi_kda_mla_probe.cc', probe_link)
run('tests-on-registration-attempt2', [CMAKE, '-S', test_entry, '-B', BATCH / 'build-tests-on', *args])
run('tests-on-probe-query', [NINJA, '-C', BATCH / 'build-tests-on', '-t', 'query', 'hyle_kimi_kda_mla_probe'])

# Use the unmodified actual graph-only fragment; no engine target is created.
module = BATCH / 'module-entry'
write(module / 'CMakeLists.txt', f'''cmake_minimum_required(VERSION 3.25)
project(KimiModuleBoundary LANGUAGES CXX)
enable_testing()
include("{(sdk / 'HyleConfig.cmake').as_posix()}")
set(_HYLE_COMPUTE_HAVE_CUDA TRUE)
set(HYLE_GGML_SOURCE_DIR "{(ROOT / 'include').as_posix()}")
foreach(name IN ITEMS hyle_graph_route_cuda hyle_graph_batch hyle_compute_state hyle_mem_vm
    hyle_graph_progress hyle_compute_backend_cuda hyle_compute_provider_flashinfer hyle_simd ggml)
  add_library(${{name}} INTERFACE)
endforeach()
function(hyle_add_header_self_contained_test)
endfunction()
function(hyle_add_test module)
  cmake_parse_arguments(ARG "" "NAME" "SOURCES;DEPS;DEFINES" ${{ARGN}})
  if(ARG_NAME)
    set(name hyle_${{module}}_${{ARG_NAME}}_test)
  else()
    set(name hyle_${{module}}_test)
  endif()
  add_executable(${{name}} EXCLUDE_FROM_ALL ${{ARG_SOURCES}})
  target_link_libraries(${{name}} PRIVATE ${{ARG_DEPS}})
  target_compile_definitions(${{name}} PRIVATE ${{ARG_DEFINES}})
  add_test(NAME ${{name}} COMMAND ${{name}})
endfunction()
add_subdirectory("{(ROOT / 'tests/graph_route_cuda').as_posix()}" graph_route_cuda)
if(TARGET hyle_engine OR TARGET hyle_kimi_kda_mla_probe)
  message(FATAL_ERROR "module-only acquired an engine diagnostic")
endif()
if(NOT TARGET hyle_graph_route_cuda_kimi_heterogeneous_state_test OR NOT TARGET hyle_kimi_k3_component)
  message(FATAL_ERROR "module consumer lost its private component")
endif()
get_target_property(links hyle_graph_route_cuda_kimi_heterogeneous_state_test LINK_LIBRARIES)
if(NOT "hyle_kimi_k3_component" IN_LIST links)
  message(FATAL_ERROR "module consumer no longer uses the component")
endif()
''')
run('graph-only-fragment', [CMAKE, '-S', module, '-B', BATCH / 'build-module', *args])
run('graph-only-consumer-query', [NINJA, '-C', BATCH / 'build-module', '-t', 'query',
                                'hyle_graph_route_cuda_kimi_heterogeneous_state_test'])

records = [json.loads(p.read_text()) for p in sorted((BATCH / 'validation').glob('*/process.json'))]
summary = {'scope': 'Configure/generate-only source-layout and target-ownership fixtures. Interface SDK targets, no native SDK link/install claim.',
           'minimal_source_has_tests_tree': (SOURCE / 'tests').exists(),
           'source_view': {'cmake_copies': cmake_files, 'read_only_source_hard_links': source_files},
           'compiler_identity': pin(compiler_info), 'toolchain': pin(toolchain),
           'normal_cache_untouched': True, 'cxx_link_native_processes': 0,
           'old_layout_missing_probe_source_reproduced': True,
           'standalone_tests_off_generation': True, 'embedded_tests_off_generation': True,
           'tests_on_explicit_probe_registration': True,
           'graph_only_original_consumer_reuses_component_without_engine': True,
           'default_qwen_has_no_kimi_component_link': True,
           'product_pins': [pin(ROOT / p) for p in ['engine/models/kimi_k3/CMakeLists.txt', 'tests/CMakeLists.txt',
                                                'engine/models/kimi_k3/component_sources.cmake', 'tests/graph_route_cuda/CMakeLists.txt']],
           'processes': records}
write(BATCH / 'summary.json', json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: v for k, v in summary.items() if k not in ['processes', 'source_view', 'product_pins']}, indent=2))
