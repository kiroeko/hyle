from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
PATHS = ['engine/models/kimi_k3/CMakeLists.txt', 'tests/CMakeLists.txt',
         'tests/tooling/engine_components_test.py']


def pin(path):
    content = path.read_bytes()
    return {'path': str(path.relative_to(BATCH)), 'bytes': len(content),
            'sha256': hashlib.sha256(content).hexdigest()}


changes = []
for relative in PATHS:
    original = BATCH / 'base' / relative
    current = ROOT / relative
    dest = BATCH / 'current' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(current.read_bytes())
    assert b'\r' not in original.read_bytes() and b'\r' not in dest.read_bytes()
    changes.append({'relative': relative, 'base': pin(original), 'current': pin(dest)})

original = (BATCH / 'base/tests/tooling/engine_components_test.py').read_bytes()
current = (ROOT / 'tests/tooling/engine_components_test.py').read_bytes()
begin = current.index(b'    def test_cuda_tests_off_keeps_kimi_diagnostic_out_of_application(self):\n')
end = current.index(b'    def test_empty_or_ambiguous_selection_is_rejected(self):\n', begin)
assert current[:begin] + current[end:] == original
proof = json.loads((BATCH / 'final-proof.json').read_text())
proof['source_inverse_bytes_exact'][PATHS[2]] = True
(BATCH / 'final-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
(BATCH / 'source-change.json').write_text(json.dumps(changes, indent=2) + '\n')
diff = subprocess.run(['git', 'diff', '--', *PATHS], capture_output=True, check=True).stdout
(BATCH / 'test-boundary.patch').write_bytes(diff)
check = subprocess.run(['git', 'diff', '--check', '--', *PATHS], capture_output=True)
assert check.returncode == 0, check.stdout + check.stderr
regression = json.loads((BATCH / 'regression-summary.json').read_text())
summary = json.loads((BATCH / 'summary.json').read_text())
summary['regression'] = regression
summary['product_changes'] = changes
summary['inverse_original_files_bytes_exact'] = True
summary['patch'] = pin(BATCH / 'test-boundary.patch')
summary['remaining_boundaries'] = [
    'No new CXX, link, native inference, or installed-SDK link validation in this slice.',
    'The existing normal cache remains at its historical generated target inventory until its next authorized configure.',
    'Kimi remains a finite model-private KDA-to-MLA component, not a complete Kimi model.',
]
(BATCH / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')

members = [BATCH / name for name in ['summary.json', 'source-change.json', 'test-boundary.patch',
                                   'final-proof.json', 'regression-summary.json', 'regression-red.log',
                                   'regression-green.log', 'validate.py', 'run-regression.py', 'seal.py',
                                   'cached-compiler.cmake']]
members += list((BATCH / 'base').rglob('*')) + list((BATCH / 'current').rglob('*'))
members += list((BATCH / 'configuration-only-sdk').glob('*.cmake'))
for directory in ['validation', 'regression']:
    for path in (BATCH / directory).rglob('*'):
        if path.is_file() and (path.name in ['stdout.log', 'stderr.log', 'process.json', 'CMakeLists.txt']):
            members.append(path)
members = sorted(set(p for p in members if p.is_file()))
manifest = {'scope': 'Minimum raw records/source patch for root combined engineering evidence; no SDK/model/binaries/generated build trees.',
            'members': [pin(p) for p in members]}
(BATCH / 'members.json').write_text(json.dumps(manifest, indent=2) + '\n')
for item in manifest['members']:
    assert pin(BATCH / item['path']) == item
print(json.dumps({'members': len(members), 'total_bytes': sum(x['bytes'] for x in manifest['members']),
                  'patch': pin(BATCH / 'test-boundary.patch'), 'summary': pin(BATCH / 'summary.json'),
                  'manifest': pin(BATCH / 'members.json'), 'sources': changes}, indent=2))
