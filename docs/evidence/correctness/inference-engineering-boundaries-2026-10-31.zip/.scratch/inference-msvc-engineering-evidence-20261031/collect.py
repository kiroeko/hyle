from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
LANG = ROOT / '.scratch/inference-msvc-include-language-20261031'
REC = ROOT / '.scratch/inference-msvc-headerdeps-recovery-20261031'
MIG = ROOT / '.scratch/inference-ninja-headerdeps-migration-20261031'
DERIVED = BATCH / 'derived'
DERIVED.mkdir(exist_ok=True)
selected: dict[str, Path] = {}


def put(name, value):
    path = DERIVED / name
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    add(path)
    return path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def add(path):
    path = Path(path)
    assert path.is_file(), path
    assert path.suffix.lower() not in {'.obj', '.dll', '.exe', '.lib', '.pdb', '.sqlite'}, path
    assert path.name != 'environment.json', path
    selected[path.relative_to(ROOT).as_posix()] = path


def records(directory, fixture_source=False):
    for path in directory.rglob('*'):
        if not path.is_file():
            continue
        relative = path.relative_to(directory)
        if 'build' in relative.parts or (directory / relative.parts[0] / 'CMakeCache.txt').is_file():
            continue
        if relative.parts[0] == 'source' and not fixture_source:
            continue
        if path.name in {'command.json', 'process.json', 'stdout.log', 'stderr.log', 'proof.json'}:
            add(path)
        elif fixture_source and relative.parts[0] == 'source' and path.suffix in {'.txt', '.cc', '.h'}:
            add(path)
        elif path.name in {'legacy-rule-original.ninja', 'legacy-rule-no-recorder.ninja', 'migration-proof.json', 'reproduction.json',
                           'actual-child-environment.json', 'official-helper-source.json'}:
            add(path)


def main():
    freeze = json.loads((MIG / 'source-freeze.json').read_text())
    for pin in freeze['files']:
        source = ROOT / pin['path']
        assert digest(source.read_bytes()) == pin['sha256'], source
        add(source)
    for name in ('source-freeze.json', 'combined-engineering-fix.patch', 'patch-check.json'):
        add(MIG / name)
    for name in ('source-freeze.json', 'source-freeze-v1.json', 'source-freeze-v2.json',
                 'environment-language-fix.patch', 'environment-language-fix-v1.patch', 'environment-language-fix-v2.patch',
                 'verification-summary.json', 'preparation-failures.json', 'historical-proof-correction.json',
                 'cached-cmake-actual-readback.json', 'final-engineering-independent-review.json',
                 'reproduce.py', 'reproduce-explicit-language.py', 'migrate-same-cache-product-final.py',
                 'check-english-and-environment.py', 'plan-header-deps-recovery.py'):
        add(LANG / name)
    for name in ('explicit-2052', 'same-cache-product-final-proof', 'english-skip-proof',
                 'tests-bootstrap_environment-cached-cmake-final', 'tests-development_scripts-cached-cmake-final',
                 'legacy-configure', 'legacy-build', 'legacy-deps', 'legacy-header-change-dry-run',
                 'english-configure', 'english-build', 'english-deps', 'english-header-change-dry-run',
                 'english-header-change-rebuild', 'english-rebuilt-deps',
                 'direct-unset', 'direct-2052', 'direct-1033'):
        records(LANG / name)
    add(LANG / 'reproduction.json')
    old_plan = LANG / 'headerdeps-recovery-plan-v2'
    add(old_plan / 'recovery-plan.json')
    add(old_plan / 'query-engine-graph/command.json')
    add(old_plan / 'query-engine-graph/process.json')
    add(old_plan / 'query-actual-ninja-compdb/command.json')
    add(old_plan / 'query-actual-ninja-compdb/process.json')
    old_commands = old_plan / 'query-actual-ninja-compdb/stdout.log'
    new_commands = REC / 'attempt3/query-actual-compdb-after-original4_4/stdout.log'
    assert old_commands.read_bytes() == new_commands.read_bytes()
    add(old_commands)  # One 2MB compdb supports the exact full1600-command proof.
    put('full-command-output-identity.json', {'original': str(old_commands.relative_to(ROOT)),
        'current': str(new_commands.relative_to(ROOT)), 'bytes_direct_equal': True,
        'bytes': old_commands.stat().st_size, 'sha256': digest(old_commands.read_bytes()),
        'one_copy_archived': True, 'command_map_entries': 1600})
    # Keep recovery commands and terminal receipts, omitting full environments,
    # duplicate compdbs, raw11MB all-deps output, and normal2.2MB manifest copies.
    for path in REC.rglob('*'):
        if not path.is_file() or 'control' in path.relative_to(REC).parts or 'primary-sources' in path.relative_to(REC).parts:
            continue
        if path.name == 'environment.json' or path.suffix in {'.obj', '.dll', '.exe', '.lib', '.pdb', '.ninja'}:
            continue
        if path.name == 'stdout.log' and ('query-actual-compdb' in str(path) or 'verify-actual-deps' in str(path)):
            continue
        if path.suffix in {'.py', '.json', '.log', '.md'}:
            add(path)
    # Extract exact retained raw blocks for16 repaired objects and the3 known
    # empty units; retain a count ledger for the full actual727-object closure.
    raw_path = REC / 'attempt3/verify-actual-deps/stdout.log'
    raw = raw_path.read_bytes()
    heads = list(re.finditer(rb'(?m)^(.+): #deps ([0-9]+),[^\n]*', raw))
    blocks, counts = {}, {}
    for index, head in enumerate(heads):
        key = head[1].decode('utf-8').replace('\\', '/')
        blocks[key] = raw[head.start():heads[index+1].start() if index+1 < len(heads) else len(raw)]
        counts[key] = int(head[2])
    recovery = json.loads((old_plan / 'recovery-plan.json').read_text())
    needed = [row['object'] for row in recovery['recovery_objects']] + [row['object'] for row in recovery['legitimate_empty_TU_exclusions']]
    excerpt = DERIVED / 'actual16-plus3-deps.log'
    excerpt.write_bytes(b''.join(blocks[key] for key in needed))
    add(excerpt)
    all_before = json.loads((old_plan / 'plan.json').read_text())['all_C_CXX_closure']
    ledger = [{'object': row['object'], 'source': row['source'],
               'before_deps': row['dependency_record']['count'] if row['dependency_record'] else None,
               'after_deps': counts[row['object']]} for row in all_before]
    assert len(ledger) == 727 and sum(row['after_deps'] == 0 for row in ledger) == 3
    put('all727-dependency-counts.json', {'objects': ledger, 'raw_source': str(raw_path.relative_to(ROOT)),
        'raw_bytes': len(raw), 'raw_sha256': digest(raw), 'raw_not_archived': 'Exact19 blocks plus complete727 count ledger suffice; original raw retained in scratch.'})
    final_tests = freeze['actual_final_tests']
    for value in final_tests.values():
        records(Path(value['directory']), fixture_source=True)
    # Real historical fixture failures remain distinct from product/native
    # assertions and from successful superseded positive test iterations.
    failures = []
    fixture_root = ROOT / '.scratch/validation/ninja-headerdeps-recovery'
    for directory in fixture_root.iterdir():
        if (directory / 'proof.json').exists():
            continue
        if directory.name.startswith('migration-') and len(list(directory.glob('*/process.json'))) == 1:
            reason = 'Fixture legacy rule name orCRLF regex assertion before target-object builds; configure exit0.'
        elif directory.name.startswith('multiconfig-') and not (directory / 'configure-recovery').exists():
            reason = 'Fixture queried defaultDebug deps and KeyError onRelease record; later fix unions each actual manifest deps as well as compdb.'
        else:
            reason = 'Fixture Python read_text defaultGBK failed readingUTF8 recovery JSON in Unicode path; configure succeeded; repair build not reached. Fixed UTF8 decoder only.'
        failures.append({'directory': str(directory.relative_to(ROOT)), 'reason': reason})
        records(directory, fixture_source=True)
    put('failure-history.json', {'migration_fixture_attempts': failures,
        'language_and_parser_preparation_failures': str((LANG / 'preparation-failures.json').relative_to(ROOT)),
        'normal_recovery_attempt1': 'Public discovery selectedVS CMake4.2.3 rather than original4.4; configure exit0, exact-plan gate stopped beforeCXX. Sources restored; old objects unchanged.',
        'normal_recovery_attempt2': 'Original4.4 restored. Default Ninja dryrun seesVerifyGlobs phony only, so exact-plan gate again stopped beforeCXX; sources restored.',
        'normal_recovery_attempt3': 'Byte-exact nondefault-name manifest used forprediction only; actual default normalbuild/VerifyGlobs16CXX+3links passed.',
        'outer_test_output_limit': 'Early outer Python assertions were observed in tool output and preserved as notes/source; per-native command/process/stdout/stderr receipts are retained. No synthetic outer process receipt.'})
    put('review-addendum.json', {'supersedes_open_gap_only': str((LANG / 'final-engineering-independent-review.json').relative_to(ROOT)),
        'general_legacy_cache_migration': 'Implemented: config reads realexisting C/CXX zero/missing records, appends once-stable build-local OBJECT_DEPENDS stamps in actual ownedCMake directory/source scopes, true normalbuild recaptures deps.',
        'finite_actual_proofs': final_tests, 'healthy_shared_source_conservative_extra_once': True,
        'ownership': 'ActualHyle CMake SUBDIRECTORIES/BUILDSYSTEM_TARGETS; includes logical dependencychildren outside Hylebinary and excludes parent/siblings even whenDEP_BUILDbase isparentroot.',
        'multi_config': 'Unions compdb and deps for existingconfig manifests; normalizedabsoluteobjectSHA dedup.',
        'limitations': ['No newnormalengine configure/build for finalhelper. Prior16 recovery is separate actualproof.',
                       'Newtooling test is registered foractualMSVC+Windows+Ninja only. Clang-cl family helper is source-reviewed, not natively claimed tested.',
                       'CMake3.25 official source signature checked; actual binary execution4.4 only.',
                       'No allplatform/ISA/sanitizer/trace/install matrix, no model/GPU run.',
                       'Source OBJECT_DEPENDS isdirectory-scoped: healthy targets sharing thatsource/scope can rebuild once.']})
    put('toolchain-facts.json', {'actual_CMake': 'C:/Program Files/CMake/bin/cmake.exe4.4.0',
        'MSVC': 'C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe',
        'Ninja': 'C:/PROGRA~1/PYTHON~1/Scripts/ninja.exe', 'VSLANG': '1033',
        'full_environment_not_archived': True, 'normal_cache_current_flags': 'engine/testsOFF/cpu;cuda/shared/Release/offline',
        'old_wrong_CMake_attempt': 'VS bundled4.2.3-msvc3 retained as actualhistory, never used for recoveryCXX.'})
    summary = {'status': 'PASS_FINITE_ENGINEERING_BOUNDARY', 'source_freeze': str((MIG / 'source-freeze.json').relative_to(ROOT)),
        'source_files': 8, 'entry_commit': freeze['head'], 'Python_script_tests': 70, 'actual_tiny_migration_tests': 3,
        'normal_recovery': {'CXX': 16, 'SDK_CXX': 9, 'app_CXX': 7, 'links': 3, 'NVCC_compile': 0,
            'commands_compared': 1600, 'changed_commands': 0, 'C_CXX_closure': 727, 'remaining_legitimate_empty_TUs': 3,
            'source_bytes_and_original_times_restored': True, 'three_text_sections_equal': True, 'default_second_build_no_CXX_or_links': True},
        'migration': final_tests, 'normal_model_GPU_runs': 0,
        'proof_index': {'language': str((LANG / 'verification-summary.json').relative_to(ROOT)),
            'actual16': str((REC / 'attempt3/verification-summary.json').relative_to(ROOT)),
            'final_source': str((MIG / 'source-freeze.json').relative_to(ROOT)),
            'resolved_gap': str((DERIVED / 'review-addendum.json').relative_to(ROOT)),
            'history': str((DERIVED / 'failure-history.json').relative_to(ROOT))},
        'scope': 'Scratchcandidate only. Excludes SDK/objects/binaries/fullenv/model/SQLite, excludes normalNinja fullmanifest and all11MBdeps. Root will combine publicentry/docs/Kimi evidence separately.'}
    summary_path = BATCH / 'summary-draft.json'
    summary_path.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    add(summary_path)
    add(Path(__file__))
    manifest = [{'member': name, 'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())}
                for name, path in sorted(selected.items())]
    manifest_path = BATCH / 'manifest.json'
    manifest_path.write_text(json.dumps({'members': manifest, 'manifest_excludes_itself': True,
        'source_paths': 'Each payload member is repository-relative and maps to the same retained localfile.'}, indent=2) + '\n', encoding='utf-8')
    archive = BATCH / 'evidence-draft.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for row in manifest:
            z.write(selected[row['member']], row['member'])
        z.write(manifest_path, 'manifest.json')
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for row in manifest:
            data = z.read(row['member'])
            assert len(data) == row['bytes'] and digest(data) == row['sha256']
            assert data == selected[row['member']].read_bytes()
        assert z.read('manifest.json') == manifest_path.read_bytes()
    receipt = {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()),
               'members': len(manifest)+1, 'all_members_CRC_SHA_size_and_direct_source_bytes_equal': True,
               'payload_bytes': sum(row['bytes'] for row in manifest), 'manifest': str(manifest_path)}
    (BATCH / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
