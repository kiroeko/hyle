"""Freeze actual focused Apple full-FFN consumer; inventory only, no deletion."""
from pathlib import Path
import hashlib,json,runpy,shutil,xml.etree.ElementTree as ET
ROOT=Path.cwd();A=ROOT/".scratch/architecture-refactor-2026-10-18";P=A/"ga-full-ffn-2026-10-21/apple"
OUT=P/"mac/final";RESULTS=OUT/"results"
def read(p):return json.loads(p.read_text())
def save(p,value):p.write_text(json.dumps(value,indent=2)+"\n")
def identity(p):
 b=p.read_bytes();return dict(path=p.relative_to(ROOT).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
runpy.run_path(str(P/"audit_dependencies.py"))
audit=read(P/"actual-dependencies-canonical-audit.json");assert audit["drift_count"]==0
compiles=read(RESULTS/"compile-summary.json")["compiles"];assert len(compiles)==1
unique={r["current"]["path"]:r["current"]for c in audit["compiles"]for r in c["canonical"]}
ssh = runpy.run_path(str(A / "batch-query-extent/delegated/apple/validate.py"))["ssh"]
remote = read(OUT / "plan.json")["remote"]
inventory = ssh('''from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['root']);assert r.is_absolute() and r.exists() and not r.is_symlink()
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),symlink=p.is_symlink())
images=[];objects=[];dsym=[]
for q in sorted(r.rglob('*')):
 if q.is_symlink():continue
 if q.is_dir():
  if q.suffix=='.dSYM':dsym.append(str(q))
  continue
 if q.suffix=='.o':objects.append(ident(q))
 elif q.suffix=='.map':images.append(ident(q))
 else:
  with q.open('rb')as f:magic=f.read(4)
  if magic in [bytes.fromhex(x)for x in ('cffaedfe','feedfacf','cafebabe','bebafeca')]:images.append(ident(q))
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
active=[s for s in ps.splitlines()if str(r)in s and 'python3 -c'not in s and '/usr/bin/ssh'not in s]
lsof=subprocess.run(['lsof','--',*[x['path']for x in images]],capture_output=True,text=True)
print(json.dumps(dict(remote_root=str(r),root_symlink=r.is_symlink(),deletable_files=images,retained_objects=objects,dsym=dsym,active_image_processes=active,lsof_stdout=lsof.stdout,lsof_stderr=lsof.stderr,lsof_exit=lsof.returncode,deleted=False)))
''', dict(root=remote))
assert not inventory["active_image_processes"] and not inventory["lsof_stdout"]
save(P / "cleanup-readonly-inventory.json", inventory)

for rel,row in unique.items():
    assert identity(ROOT/rel)==row
    dest=P/"source"/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/rel,dest)
registration="tests/graph_route_apple/CMakeLists.txt"
dest=P/"source"/registration;dest.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(ROOT/registration,dest)
inputs=read(RESULTS/"link-inputs.json")
reused_products=[row for row in inputs if row["path"].endswith(("src--compute_route_apple--apple_weights.mm.o","src--compute_route_apple--apple_memory.mm.o","src--graph--resources.cc.o"))]
assert len(reused_products)==3
assert next(x for x in reused_products if x["path"].endswith("apple_weights.mm.o"))["sha256"]=="cf4622f43748d2aca74841492e3eaa0a0f2c225bd8ac267d2262c1fd0307f2df"
freeze=dict(status="actual_wrapper_CXX_source_and_every_actual_canonical_dependency_equal_final_Windows_bytes",
    sources=sorted(unique.values(),key=lambda r:r["path"]),registration=identity(ROOT/registration),
    compiled_translation_units=[c["source"]for c in compiles],
    canonical_dependency_audit=identity(P/"actual-dependencies-canonical-audit.json"),
    actual_dependency_references=audit["actual_dependency_references"],unique_canonical_files=audit["unique_canonical_files"],
    actual_whole_dependencies_drift=0,source_snapshot="source/",SDK_source_copied=False,
    reused_current_products=reused_products,
    Apple_product_changes=0,new_test="tests/graph_route_apple/ga_full_ffn_test.cc",new_CMake_target="hyle_graph_route_apple_ga_full_ffn_test",
    initial_review_preserved="first-review/",shared_final_sha256="d9539801978b441ee7590c43602bb1f21184269364f0ceb19816dbc1258883b8")
save(P/"source-freeze.json",freeze)
cases=[dict(name=t.attrib["classname"]+"."+t.attrib["name"],
    properties={v.attrib["name"]:v.attrib["value"]for v in t.findall("./properties/property")})
    for t in ET.parse(RESULTS/"tests.xml").iter("testcase")]
assert len(cases)==1 and cases[0]["name"]=="AppleGaFullFfn.SourceBoundScoreAndHashKeepPreDownWeights"
assert cases[0]["properties"]["successful_submissions"]=="6"
assert cases[0]["properties"]["maximum_first_projection_bf16_ulp"]=="0"
validation=read(RESULTS/"validation.json")
assert validation["tests"]==1 and validation["exit"]==0 and not validation["failed"]and not validation["skipped"]
final=dict(status="actual_Mac16_12_Metal_source_bound_full_GA_FFN_consumer_pass",source_freeze=identity(P/"source-freeze.json"),
    hardware=identity(OUT/"hardware.json"),tests=1,new_cases=1,original_neighbors=0,failed=0,skipped=0,cases=cases,
    successful_submissions=6,score_submissions=3,hash_submissions=3,expected_failed_submissions=0,
    successful_weight_upload_generations=2,
    upload_accounting="Original same-generation mixed encoded/plain WeightBatch.wait/report; per-upload logical/staged, actual native submitted/completed bounds and successful retirement, not measured bus/DRAM traffic.",
    capacities_estimated_from_shared={"score_logical_bytes":139469848,"hash_logical_bytes":139468824,"score_slot_capacity":139470080,"hash_slot_capacity":139469056,"per_family_backing_allocations":4},
    CXX_jobs=1,Apple_product_CXX_jobs=0,test_CXX_jobs=1,SDK_jobs=0,
    Apple_native_runtime_or_math_changes=0,shared_math_or_oracle_changed_for_Apple=False,
    compiles=[dict(source=c["source"],exit=c["exit"],object=c["object_identity"],
        dependency_count=len(c["dependencies"]),source_drifts=c["source_drifts"])for c in compiles],
    reused_current_products=reused_products,
    actual_whole_dependencies_drift=0,actual_dependency_references=audit["actual_dependency_references"],
    unique_canonical_files=audit["unique_canonical_files"],run=read(RESULTS/"run.result.json"),image=validation["image"],
    artifacts={n:identity(RESULTS/n)for n in ("compile-summary.json","link-inputs.json","link.command.json","link.result.json","run.command.json","run.result.json","tests.xml","validation.json")},
    attempts_preserved=["Initial6bb556 shared source was reviewed only, never compiled or run on Apple; first-review retains its identities and original capacity correction.",
      "Only actual Apple compile/run uses rootCPU-passed finald9539801 shared source; first actual Apple run PASS, no rejected/failed Apple attempt."],
    scope="Formal Flash-sized finite synthetic complete routed/shared FFN ordinary composition, D4096/H2048/globalE256/Top6/resident7, score/hash each3 replays; original6 packed FP4/FP8 banks plus router/bias/tags/scale/I32map bound as original mixed WeightBatch. Nonidentity global IDs remap via original checked I32 Gather before FP4 experts, route weighting before down's BF16/A8 boundary, old outputs retained across3 independent Invocations and after producer teardown.",
    complete_GA_routed_shared_FFN_validated=True,
    limits=["Finite source-bound consumer does not claim complete model/checkpoint, end-to-end engine throughput, or all geometries.","Tolerance policy was fixed in shared fixture before this backend execution; first projections exactBF16 remain0ULP.","No SDK source/Metal runtime code was rebuilt by this incremental build; ordinary runtime MLX kernel compilation remains its original behavior, and elapsed test time is not a throughput measurement."],
    cleanup_inventory=identity(P/"cleanup-readonly-inventory.json"),no_deletion_performed=True)
save(P/"final-validation.json",final)
for q in (P/"source-freeze.json",P/"final-validation.json",P/"actual-dependencies-canonical-audit.json",P/"cleanup-readonly-inventory.json"):
    print(json.dumps(identity(q)))
