"""Freeze source/build/actual root results and inspect rebuildable Windows outputs; never execute tests or delete."""
from pathlib import Path
import difflib
import importlib.util
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
A=P.parent
R=A.parents[1]
spec=importlib.util.spec_from_file_location('full_ffn_freeze_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
header=R/'tests/compute_models/ga_full_ffn_fixture.h'
assert b.identity(header)['sha256']=='d9539801978b441ee7590c43602bb1f21184269364f0ceb19816dbc1258883b8'
relative_sources=['tests/compute_models/ga_full_ffn_fixture.h',
    *[f'tests/graph_route_{arm}/ga_full_ffn_test.cc' for arm in ['cpu','cuda','vulkan']],
    *[f'tests/graph_route_{arm}/CMakeLists.txt' for arm in ['cpu','cuda','vulkan']]]
sources=[]
for relative in relative_sources:
    path=R/relative
    dest=S/'source-final'/relative
    dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():assert path.read_bytes()==dest.read_bytes(),relative
    else:dest.write_bytes(path.read_bytes())
    sources.append(dict(source=b.identity(path),snapshot=b.identity(dest)))
c.save(S/'source-freeze.json',dict(status='final_sources_match_actual_link2_and_root_final1',
    sources=sources,source_count=len(sources),product_source_changes=0,
    final_shared_sha256=b.identity(header)['sha256'],
    first_shared_snapshot=b.identity(S/'source-attempt1/tests/compute_models/ga_full_ffn_fixture.h'),
    first_harness_issue='The initial generic read callback copied std::vector by value; the final explicit span callback writes the actual result destination. Numerical data, formula, tolerances and graph are unchanged.'))

identities=[P/'cpu/checks/attempt1/identity.json',
    *[P/arm/'checks/attempt2/identity.json' for arm in ['cpu','cuda','vulkan']]]
owners=[];unique={};entries=0;drift=[];workspace_entries=0
for path in identities:
    record=c.read(path)
    assert b.same(record['source']) and b.same(record['object'])
    final=path.parent.name=='attempt2'
    if final: assert all(b.same(x) for x in record['frozen_shared'])
    for dependency in record['dependencies']:
        entries+=1
        key=c.key(dependency['path'])
        if final:
            if key in unique:assert unique[key]==dependency
            unique[key]=dependency
            if not b.same(dependency):drift.append(dependency)
            if c.key(dependency['path']).startswith(c.key(R)+os.sep):workspace_entries+=1
    owners.append(dict(identity=b.identity(path),source=record['source'],object=record['object'],
        final=final,dependency_entries=len(record['dependencies'])))
assert not drift,drift
baseline=c.read(S/'source-review.json')
for owner in baseline['actual_product_owner_source_audit']:
    assert b.same(owner['source']) and b.same(owner['object'])
c.save(S/'current-source-dependency-audit.json',dict(status='final_three_wrappers_0_dependency_drift',
    compile_owners=4,current_compile_owners=3,owners=owners,
    all_attempt_dependency_entries=entries,final_dependency_entries=sum(x['dependency_entries'] for x in owners if x['final']),
    final_workspace_dependency_entries=workspace_entries,unique_final_dependencies=len(unique),
    drift=drift,dependencies=list(unique.values()),
    inherited_product_source_audit=baseline['actual_product_owner_source_audit'],
    weak_inline_scope='No schema, inline custom operation layout or product code changes. Current V products are retained; old test TU alone is replaced in each focused closure. Historical attempt1 is not required to match the later fixed test header.'))

actual=[];staging=[];metrics=[]
for arm in ['cpu','cuda','vulkan']:
    folder=P/arm/'validation/final1'
    receipt=c.read(folder/'receipt.json')
    assert receipt['passed'] and receipt['cases']==1 and not receipt['failed'] and not receipt['skipped']
    assert b.same(receipt['image']) and b.same(receipt['xml']) and b.same(receipt['link_plan'])
    plan_path=P/arm/'checks/link2/link-plan.json'
    assert c.key(receipt['link_plan']['path'])==c.key(plan_path)
    plan=c.read(plan_path)
    assert all(b.same(x) for x in plan['inputs'])
    result=c.read(folder/'tests.result.json')
    assert result['exit']==0 and result['terminal']
    cases=ET.parse(receipt['xml']['path']).findall('.//testcase')
    assert len(cases)==1 and cases[0].find('failure') is None and cases[0].find('skipped') is None
    properties={p.get('name'):p.get('value') for p in cases[0].findall('./properties/property')}
    assert properties['successful_submissions']=='6'
    assert properties['maximum_first_projection_bf16_ulp']=='0'
    metrics.append(dict(arm=arm,properties=properties))
    actual.append(dict(arm=arm,receipt=b.identity(folder/'receipt.json'),command=b.identity(folder/'tests.command.json'),
        result=b.identity(folder/'tests.result.json'),xml=receipt['xml'],image=receipt['image'],
        link_plan=receipt['link_plan'],input_count=len(plan['inputs']),successful_submissions=6))
    runtime=c.read(folder/'runtime-environment.json')
    for item in runtime['private_modules']:
        assert b.same(item['source']) and b.same(item['destination'])
        assert item['source']['sha256']==item['destination']['sha256']
        assert item['hardlink'] and os.path.samefile(item['source']['path'],item['destination']['path'])
    staging.append(dict(arm=arm,runtime_record=b.identity(folder/'runtime-environment.json'),
        modules=runtime['private_modules'],source_destination_identity_and_hardlink_verified=True))
c.save(S/'private-module-staging-proof.json',dict(status='actual_root_runtime_staging_verified',arms=staging,
    reason='Only the exact cached image-selected CPU AVX2 module is hardlinked into the application directory; source cache retained and unchanged, no SDK copy or loader flag change.',
    source_cache_deletion_authorized=False,agent_staging_actions=0))

first=P/'cpu/validation/first1'
first_result=c.read(first/'tests.result.json')
assert first_result['exit']==1 and first_result['terminal']
first_artifacts=[b.identity(path) for path in sorted(first.iterdir()) if path.is_file()]
compile_results=[]
for identity in identities:
    path=identity.parent/'compile.result.json'
    assert c.read(path)['exit']==0
    compile_results.append(b.identity(path))
link_results=[]
for arm,folder in [('cpu','link1'),('cpu','link2'),('cuda','link2'),('vulkan','link2')]:
    path=P/arm/'checks'/folder/'link.result.json'
    assert c.read(path)['exit']==0
    link_results.append(b.identity(path))
diff=[]
for arm in ['cpu','cuda','vulkan']:
    relative=f'tests/graph_route_{arm}/CMakeLists.txt'
    diff.extend(difflib.unified_diff((S/'before'/relative).read_bytes().decode().splitlines(True),
        (R/relative).read_bytes().decode().splitlines(True),fromfile='before/'+relative,tofile='after/'+relative))
(S/'cmake-scoped.diff').write_text(''.join(diff),encoding='utf-8')
c.save(S/'build-report.json',dict(status='root_windows_three_cases_18_successful_submissions_zero_fail_skip',
    successful_test_CXX=4,successful_links=4,compile_results=compile_results,link_results=link_results,
    product_CXX=0,SDK_builds=0,NVCC_compiles=0,offline_shader_compiles=0,
    actual=actual,distinct_final_tests=3,successful_submissions=18,failed_final_tests=0,skipped_final_tests=0,
    numerical_metrics=metrics,
    first_failed_run=dict(arm='cpu',classification='harness_read_callback_destination_copy_not_a_product_or_numeric_failure',
        source_header_sha256='6bb5569d8e375da704695ba3ec09fdc423f356012a8c19f549845c4cbdaad80e',
        final_header_sha256='d9539801978b441ee7590c43602bb1f21184269364f0ceb19816dbc1258883b8',
        artifacts=first_artifacts,original_logs_preserved=True),
    consumer='Existing ordinary source-bound Flash score/hash recipe, each three payloads: router -> selected original A8/W4 gate/up -> clamp/SiLU -> route weight before BF16/down quantization -> selected down -> shared power2 A8/W8 FFN -> final BF16 boundary.',
    resource='Seven resident nonidentity global experts with I32 map in the same original-bank generation. GPU real mixed encoded/plain WeightSlots; CPU actual host ReadLease bindings. Independent result generations preserve old results after teardown.',
    cuda_replay=dict(policy='Unmodified default prepare_replay; no whole-graph capture requirement.',
        final_hash_observed_route=2,enum_name='kCaptured',
        limitation='RecordProperty is overwritten by successive prepares; this is only the last hash observation. It does not prove score-route capture or that all six submits were fully captured.'),
    scope=['Finite complete synthetic FFN role/reference and resource composition only.',
        'No checkpoint weight payload, whole model, throughput, quality, Linux or full global-bank capacity claim.'],
    current_source_freeze=b.identity(S/'source-freeze.json'),dependency_audit=b.identity(S/'current-source-dependency-audit.json'),
    private_module_staging=b.identity(S/'private-module-staging-proof.json'),
    agent_CPU_runs=0,agent_GPU_runs=0,actual_execution_owner='root',no_cleanup_performed=True))

reparse=[];files=[]
for directory,dirs,names in os.walk(P,followlinks=False):
    for name in list(dirs):
        path=Path(directory)/name
        if path.stat(follow_symlinks=False).st_file_attributes&0x400:
            reparse.append(str(path));dirs.remove(name)
    for name in names:
        path=Path(directory)/name
        if path.stat(follow_symlinks=False).st_file_attributes&0x400 and path.suffix.lower()!='.dll':
            reparse.append(str(path))
        files.append(path)
assert not reparse,reparse
candidates=[b.identity(path) for path in sorted(files) if path.suffix.lower() in {'.exe','.map','.dll'}]
objects=[b.identity(path) for path in sorted(files) if path.suffix.lower()=='.obj']
native_paths={c.key(x['path']) for x in candidates if Path(x['path']).suffix.lower()=='.exe'}
query="Get-CimInstance Win32_Process | Select-Object ProcessId,Name,ExecutablePath | ConvertTo-Json -Compress"
proc=subprocess.run(['powershell','-NoProfile','-Command',query],capture_output=True,text=True,check=True)
processes=json.loads(proc.stdout)
live=[row for row in processes if row.get('ExecutablePath') and c.key(row['ExecutablePath']) in native_paths]
assert not live,live
current_objects=[owner['object'] for owner in owners if owner['final']]
c.save(S/'cleanup-windows-inventory.json',dict(status='read_only_exact_candidates_no_deletion_or_test_script_edit',
    workspace_root=str(P.resolve()),reparse_points=reparse,native_test_processes_running=live,
    candidate_types=['exe','map','staged DLL hardlink target only'],candidates=candidates,
    candidate_count=len(candidates),candidate_bytes=sum(x['bytes'] for x in candidates),
    retained_objects=objects,retained_object_count=len(objects),retained_object_bytes=sum(x['bytes'] for x in objects),
    current_wrapper_objects=current_objects,
    cached_DLL_sources_protected=[item['source'] for row in staging for item in row['modules']],
    rule='Root may delete only after evidence packaging and exact test.ps1 review. All objects, SDK/cache sources, commands, source snapshots, first failure and final receipts remain.'))
for name in ['source-freeze.json','current-source-dependency-audit.json','private-module-staging-proof.json',
             'build-report.json','cleanup-windows-inventory.json']:
    print(b.identity(S/name))
