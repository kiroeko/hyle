"""Compile focused full-FFN wrappers, retaining the current encoded-bank product closures; never run."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
A=P.parent
R=A.parents[1]
V=A/'ga-route-ffn-2026-10-21/opaque-slices'
spec=importlib.util.spec_from_file_location('full_ffn_build_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
RECIPES={
    'cpu':A/'ga-mhc-2026-10-21/cpu/checks/attempt4/identity.json',
    'cuda':V/'cuda/checks/test1/identity.json',
    'vulkan':V/'vulkan/checks/test1/identity.json',
}


def compile_one(arm,attempt,frozen):
    source=R/f'tests/graph_route_{arm}/ga_full_ffn_test.cc'
    recipe_path=RECIPES[arm]
    recipe=c.read(recipe_path)
    out=P/arm/'checks'/attempt
    out.mkdir(parents=True,exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'compile.result.json').exists(),out
    command=b.host_command(recipe['command'],source,'ga-full-ffn-test',out)
    source_id=b.identity(source)
    c.save(out/'compile-plan.json',dict(command=command,source=source_id,recipe=b.identity(recipe_path),
        frozen_shared=frozen,product_compiles=0,SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0))
    env,_=b.environment(command,[],out)
    c.execute('compile',command,env,out)
    dep_path=out/'ga-full-ffn-test-deps.json'
    data=c.read(dep_path)['Data']
    deps=[b.identity(p) for p in dict.fromkeys([data['Source'],*data['Includes']])]
    assert all(b.same(x) for x in [source_id,*frozen,*deps])
    record=dict(command=command,source=source_id,recipe=b.identity(recipe_path),frozen_shared=frozen,
        object=b.identity(out/'ga-full-ffn-test.obj'),dependencies=deps,source_dependencies=b.identity(dep_path))
    c.save(out/'identity.json',record)
    print('COMPILED',arm,flush=True)
    return arm,record


def link_one(arm,record,folder):
    base_path=V/arm/'checks/link1/link-plan.json'
    base=c.read(base_path)
    assert all(b.same(x) for x in base['inputs'])
    old=c.read(V/arm/'checks/test1/identity.json')['object']
    old_key=c.key(old['path'])
    assert sum(c.key(x['path'])==old_key for x in base['inputs'])==1
    inputs=[record['object'] if c.key(x['path'])==old_key else x for x in base['inputs']]
    required=[A/'ga-ratio4-producer-2026-10-21/common/checks/root-resources1/graph-resources.obj']
    if arm=='cuda':
        required += [A/'ga-ratio4-producer-2026-10-21/common/checks/attempt1/cuda-tensor/cuda-tensor.obj',
            V/'cuda/checks/attempt1/cuda-weights.obj']
    if arm=='vulkan':
        required += [A/'ga-ratio4-producer-2026-10-21/vulkan/checks/rowpitch-fix1/vulkan-provider-region.obj',
            V/'vulkan/checks/attempt1/vulkan-weights.obj']
    assert all(sum(c.key(x['path'])==c.key(path) for x in inputs)==1 for path in required)
    assert all(b.same(x) for x in [record['source'],record['object'],*record['frozen_shared'],*inputs])
    command=[record['object']['path'] if c.key(x)==old_key else x for x in base['command']
        if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    out=P/arm/'checks'/folder
    out.mkdir(parents=True,exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    assert not (out/'link.result.json').exists(),out
    image=out/(arm+'.exe')
    command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),
        '/IMPLIB:'+str(image.with_suffix('.lib'))]
    paths=[x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj','.lib')]
    assert list(map(c.key,paths))==[c.key(x['path']) for x in inputs]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(base_path),
        replaced_test=old,new_test=record['object'],retained_current_owners=[b.identity(p) for p in required],
        inherited_product_source_audit=b.identity(S/'source-review.json'),
        weak_inline_scope='No operation, Graph or native ABI changes. Only the encoded-bank/host-unit test TU is replaced; all current product objects remain.',
        product_compiles=0,SDK_builds=0,NVCC_compiles=0,agent_GPU_runs=0))
    env,runtime=b.environment(command,[x['path'] for x in inputs],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    c.execute('link',command,env,out)
    c.save(out/'image.json',b.identity(image))
    name={'cpu':'Cpu','cuda':'Cuda','vulkan':'Vulkan'}[arm]
    return dict(arm=arm,image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),
        runtime_environment=b.identity(out/'runtime-environment.json'),expected_tests=1,
        filter=name+'GaFullFfn.SourceBoundScoreAndHashKeepPreDownWeights')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixture-sha',required=True)
    parser.add_argument('--attempt',default='attempt1')
    parser.add_argument('--link-dir',default='link1')
    parser.add_argument('--arm',choices=['cpu','cuda','vulkan'],action='append')
    args=parser.parse_args()
    arms=args.arm or ['cpu','cuda','vulkan']
    header=R/'tests/compute_models/ga_full_ffn_fixture.h'
    frozen=[b.identity(header)]
    assert frozen[0]['sha256']==args.fixture_sha
    for relative in ['tests/compute_models/ga_full_ffn_fixture.h',
        *[f'tests/graph_route_{arm}/ga_full_ffn_test.cc' for arm in arms],
        *[f'tests/graph_route_{arm}/CMakeLists.txt' for arm in arms]]:
        dest=S/('source-'+args.attempt)/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists(): assert dest.read_bytes()==(R/relative).read_bytes()
        else: dest.write_bytes((R/relative).read_bytes())
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records=dict(pool.map(lambda arm:compile_one(arm,args.attempt,frozen),arms))
    ready=[link_one(arm,records[arm],args.link_dir) for arm in arms]
    path=S/('ready-for-root-run-'+ '-'.join(arms)+'.json')
    c.save(path,dict(status='focused_wrappers_compiled_linked_not_executed',arms=ready,
        frozen_shared=frozen,successful_test_CXX=len(arms),successful_links=len(arms),
        product_compiles=0,SDK_builds=0,NVCC_compiles=0,agent_CPU_runs=0,agent_GPU_runs=0))
    print(b.identity(path))


if __name__=='__main__':main()
