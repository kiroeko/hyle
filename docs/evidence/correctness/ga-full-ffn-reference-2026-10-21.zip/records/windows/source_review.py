"""Bounded CPU/full-FFN entry and current Windows cache review, with no compilation or execution."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
P=S.parent
A=P.parent
R=A.parents[1]
spec=importlib.util.spec_from_file_location('full_ffn_helpers',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b,c=h.b,h.c
V=A/'ga-route-ffn-2026-10-21/opaque-slices'
recipes={
    'cpu':A/'ga-mhc-2026-10-21/cpu/checks/attempt4/identity.json',
    'cuda':V/'cuda/checks/test1/identity.json',
    'vulkan':V/'vulkan/checks/test1/identity.json',
}
actual=[]
for arm in ['cpu','cuda','vulkan']:
    base=V/arm/'checks/link1/link-plan.json'
    plan=c.read(base)
    assert all(b.same(x) for x in plan['inputs'])
    previous=c.read(V/arm/'checks/test1/identity.json')
    assert sum(c.key(x['path'])==c.key(previous['object']['path']) for x in plan['inputs'])==1
    actual.append(dict(arm=arm,base=b.identity(base),input_count=len(plan['inputs']),
        test_recipe=b.identity(recipes[arm]),replace_test=previous['object'],
        pending_test_source=str(R/f'tests/graph_route_{arm}/ga_full_ffn_test.cc')))
owners=[]
for relative in [
    'mlx-weight-orientation-2026-10-21/cpu-cuda/checks/attempt1/torch-cpu/identity.json',
    'paged-e4-kv-reference/cpu/checks/products/attempt1/provider/identity.json',
    'ct-packed-cross-platform/checks/src--compute_route_cpu--cpu_context-identity.json',
    'ct-packed-cross-platform/checks/src--graph_route_cpu--cpu_context-identity.json',
    'mlx-moe-typed-inputs/checks/cpu-route-compile-identity.json',
    'native-ready-pages/windows/compute_route_cpu--default_policy-identity.json',
]:
    path=A/relative
    row=c.read(path)
    assert b.same(row['source']) and b.same(row['object'])
    owners.append(dict(identity=b.identity(path),source=row['source'],object=row['object'],
        current_source_bytes_equal=True))
sources=[
    'src/compute_provider_native/torch_cpu_program.cc','src/compute_provider_ggml/ggml_cpu_provider.cc',
    'src/compute_route_cpu/cpu_context.cc','src/compute_route_cpu/default_policy.cc',
    'tests/compute_models/d5_deepseek_official_fragments.h','tests/compute_models/d5_moe_execution_fragments.h',
    'tests/compute_models/d5_dynamic_fp8_fragments.h','tests/compute_models/d5_moe_execution_cases.h',
    'tests/compute_models/d5_cpu_official_boundary.h','tests/compute_route_cpu/d5_qwen38_official_test.cc',
    'tests/compute_route_cpu/CMakeLists.txt','tests/graph_route_cpu/CMakeLists.txt',
]
c.save(S/'source-review.json',dict(status='source_supported_pending_new_complete_consumer_run',
    result='No concrete missing CPU arithmetic leaf found for the finite full Flash score/hash recipe. New compilation and execution are still required; this is not a full-FFN pass.',
    cpu_entries=[
      dict(operation='GroupedFloat4Linear',source='src/compute_provider_native/torch_cpu_program.cc:155,574',
        contract='Original encoded E2M1 W, F32 group32 scales, dynamic E4 group128 A with explicit floor/power policy. All expert IDs are checked before selected decoding. Current K-block code-dot and scale order remain ATen; no full dense W bank.'),
      dict(operation='Float8BlockLinear',source='src/compute_provider_native/torch_cpu_program.cc:165,586',
        contract='Canonical block128 E4 W plus original F32 scale grid; quantize BF16/F32 A according to explicit power2 policy and floor, block F32 dot then output storage rounding.'),
      dict(operation='BFloatLinearF32',source='src/compute_provider_ggml/ggml_cpu_provider.cc:1147,2108',
        contract='Original BF16 activation/router W -> ggml_mul_mat with F32 accumulation -> F32 output. Not a missing Torch custom kind; existing ggml CPU provider owns it.'),
      dict(operation='Portable routing and gated activation',source='tests/compute_models/d5_moe_execution_fragments.h:116',
        contract='F32 MatMul or BFloatLinearF32 -> Softplus -> Sqrt -> bias-only selection -> TopK -> GatherElements from unbiased scores -> sum -> Divide(no epsilon) -> scaling. Existing Clamp/generic Minimum/Maximum, SiLU, Multiply and Cast leaves express expert activation and pre-down route weighting.'),
    ],
    precise_dtype_caution='Legacy Flash Case has router_bf16=true, whereas the fixed GA source uses F32 router weight and x.float(). Root was advised to copy the Case with router_bf16=false for typed GA source equivalence; the sparse64 test weights happen to be exactly representable in both, so matching numbers alone does not prove the dtype contract.',
    stale_test_assessment=[
      dict(path='tests/compute_route_cpu/d5_qwen38_official_test.cc:1054-1105',
        names=['D5OfficialFp8DenseColdRejection','D5OfficialFullMoeColdBoundary'],
        conclusion='Both are under #if !defined(HYLE_TEST_TORCH_CPU). Canonical compute_route_cpu and graph_route_cpu CMake define that macro when native torch_cpu capability is present. Therefore they are fallback-build rejection sentinels, not a proven currently enabled equipped-CPU failure. Do not blindly run/modify the old all-model target.'),
      dict(path='tests/compute_models/d5_cpu_official_boundary.h',
        conclusion='Retains rejected-entry labeling and missing-operation list for the guarded fallback diagnostics. Existing current TorchCPU implementation contradicts using this helper as a general CPU capability summary, but no product change follows.'),
    ],
    resources='CPU must bind the same original encoded/typed bank descriptions with real host ReadLease owners. GPU uses the now-qualified native WeightSlots encoded-byte fragments plus plain I32 map in the same batch. Do not fabricate CPU WeightSlots or replace original encoded descriptions with U8 banks.',
    consumer_cautions=[
      'Keep route weight before BF16 Cast and down activation quantization, with shared branch and final BF16 boundary unchanged.',
      'Map seven selected nonidentity global IDs to seven resident experts; keep router sparse rows, selected global IDs, map and oracle on the same generation.',
      'Retain actual host constants through all compiled/invocation/result readers; output ReadLease lifetime follows existing material-output ownership.',
      'Current canonical original FP4 scales are F32. Only source E8 scale-grid widening is implied, never a dense floating weight bank.',
      'No full-model payload, throughput, Linux or complete global-bank capacity claim follows from this finite recipe.'
    ],
    actual_product_owner_source_audit=owners,actual_base_closures=actual,
    minimal_build=dict(test_CXX=3,links=3,product_CXX=0,SDK_builds=0,NVCC_compiles=0,shader_compiles=0,
        status='Prepare only until root shared API/source freeze. No compilation or execution performed by this review.'),
    sources=[b.identity(R/path) for path in sources],
    agent_compiles=0,agent_CPU_runs=0,agent_GPU_runs=0))
print(b.identity(S/'source-review.json'))
