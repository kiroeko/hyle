"""Host-only counterfactual over the EXISTING D5 Flash sparse source formulas.
No product codec, tensor library, model payload, compilation or GPU call.
"""
from pathlib import Path
import struct,math,bisect,json,hashlib
F=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
def BF(x):
 b=bits(x);return ((b+0x7fff+((b>>16)&1))>>16)&65535
def W(b):return struct.unpack('<f',struct.pack('<I',b<<16))[0]
R=lambda x:W(BF(x))
LUT=[0.,.5,1.,1.5,2.,3.,4.,6.,0.,-.5,-1.,-1.5,-2.,-3.,-4.,-6.]
E4=[math.ldexp(float(c&7),-9) if c>>3==0 else math.ldexp(1.+(c&7)/8.,(c>>3)-7) for c in range(127)]
GLOBALS=[11,37,83,127,191,223,251]
D,H,EXPERTS,TOP=4096,2048,256,6
INV448=F(1./448.)
LINEAR_WIDTH={}
def exact_lattice_width(values):
 ratios=[v.as_integer_ratio() for v in values];den=max(q for _,q in ratios);ints=[num*(den//q) for num,q in ratios];g=0
 for v in ints:g=math.gcd(g,abs(v))
 return sum(abs(v)//g for v in ints).bit_length() if g else 0
def quant(x):
 out=[]
 for base in range(0,len(x),128):
  group=x[base:base+128];amax=max(F(1e-4),max(abs(v) for v in group));scaled=F(amax*INV448)
  m,e=math.frexp(scaled);scale=math.ldexp(1.,e-1 if m==.5 else e)
  for v in group:
   value=F(v/scale);mag=min(abs(value),448.);hi=bisect.bisect_left(E4,mag);lo=max(0,hi-1)
   dl=F(mag-E4[lo]);du=F(E4[hi]-mag);code=lo if dl<du or (dl==du and lo%2==0) else hi
   out.append(R(F(math.copysign(E4[code],value)*scale)))
 return out
def activation(replay):
 seed=3+14*replay
 v=[R(F(math.cos((i+31*seed)*.017)*.0625+((i+seed)%7)*.002-.006)) for i in range(D)]
 for e in range(7):v[e]=(2.+(6-e if replay==1 else e)/8.)/64.
 if replay==2:v[0]=5./64.
 return v
def sqrtsp(x):
 ex=F(math.exp(-abs(x)));lg=F(math.log1p(ex));sp=F(max(x,0.)+lg);return F(math.sqrt(sp))
def route(x,replay,hash_mode):
 scores=[sqrtsp(F(x[e]*64.)) if e<7 else sqrtsp(0.) for e in range(EXPERTS)]
 if hash_mode:
  token=[0,129279,37][replay];ids=[(token*3+s*2+replay)%7 for s in range(TOP)]
 else:
  selection=[scores[e]+((e%3-1)/16. if e<7 else -4.) for e in range(EXPERTS)]
  ids=sorted(range(EXPERTS),key=lambda e:-selection[e])[:TOP]
 denom=sum(scores[e] for e in ids);weights=[F(scores[e]/denom*1.5) for e in ids]
 return ids,weights
def projection(x,ids,n,k,seed):
 out=[]
 for slot,e in enumerate(ids):
  for o in range(n):
   row=e*n+o;s=0.;terms=[]
   for term in range(2):
    col=(17*row+seed+term*(k//2+17))%k
    code=1+(row+seed+term*3)%7+((row+term)%2)*8
    coeff=math.ldexp(LUT[code],122+(row+col//32+seed)%3-127)
    terms.append(x[slot*k+col]*coeff);s+=terms[-1]
   LINEAR_WIDTH[str(seed)]=max(LINEAR_WIDTH.get(str(seed),0),exact_lattice_width(terms));out.append(R(F(s)))
 return out
def shared_linear(input_values,n,k,seed):
 q=quant(list(map(R,input_values)));out=[]
 coeffs=[.5,1.,1.5,2.]
 for row in range(n):
  terms=[]
  for term in range(2):
   col=(row*17+seed+term*(k//2+13))%k
   sf=math.ldexp(1.,121+(row//128+col//128+seed)%3-127)
   terms.append((col//128,q[col]*coeffs[(row+seed+term)%4]*sf))
  LINEAR_WIDTH[str(seed)]=max(LINEAR_WIDTH.get(str(seed),0),exact_lattice_width([v for _,v in terms]));terms.sort(key=lambda x:x[0]);acc=0.
  for _,value in terms:acc=F(acc+value)
  out.append(R(acc))
 return out
def metrics(correct,wrong):
 peak=max(abs(x) for x in correct);energy=sum(x*x for x in correct)
 return dict(normalized_peak=max(abs(a-b) for a,b in zip(correct,wrong))/peak,relative_L2=math.sqrt(sum((a-b)**2 for a,b in zip(correct,wrong))/energy),BF16_different_words=sum(BF(a)!=BF(b) for a,b in zip(correct,wrong)))
def counter(hash_mode,replay):
 x=activation(replay);ids,weights=route(x,replay,hash_mode);q=quant(x);a=q*TOP
 gate=projection(a,ids,H,D,71);up=projection(a,ids,H,D,79)
 act=[F(min(g,10.)/(1.+math.exp(-min(g,10.)))*min(max(u,-10.),10.)) for g,u in zip(gate,up)]
 weighted=[F(v*weights[i//H]) for i,v in enumerate(act)]
 correct=projection(quant(list(map(R,weighted))),ids,D,H,83)
 unweighted_down=projection(quant(list(map(R,act))),ids,D,H,83)
 wrong=[F(v*weights[i//D]) for i,v in enumerate(unweighted_down)]
 correct_sum=[0.]*D;wrong_sum=[0.]*D
 for e in sorted(ids):
  slot=ids.index(e)
  for o in range(D):
   correct_sum[o]=F(correct_sum[o]+correct[slot*D+o]);wrong_sum[o]=F(wrong_sum[o]+wrong[slot*D+o])
 max_integer_bits=0;columns_over24=0;slot_order_differences=0;reverse_order_differences=0
 for o in range(D):
  vals=[correct[slot*D+o] for slot in range(TOP)];ratios=[v.as_integer_ratio() for v in vals];den=max(q for _,q in ratios)
  ints=[num*(den//q) for num,q in ratios];g=0
  for val in ints:g=math.gcd(g,abs(val))
  width=(sum(abs(val)//g for val in ints).bit_length() if g else 0)
  max_integer_bits=max(max_integer_bits,width);columns_over24+=width>24
  sl=0.;rev=0.
  for val in vals:sl=F(sl+val)
  for val in reversed(vals):rev=F(rev+val)
  slot_order_differences+=bits(sl)!=bits(correct_sum[o]);reverse_order_differences+=bits(rev)!=bits(correct_sum[o])
 sg=shared_linear(x,H,D,113);su=shared_linear(x,H,D,127)
 sa=[F(min(g,10.)/(1.+math.exp(-min(g,10.)))*min(max(u,-10.),10.)) for g,u in zip(sg,su)]
 shared=shared_linear(sa,D,H,139)
 final=[R(F(a+b)) for a,b in zip(correct_sum,shared)]
 wrong_final=[R(F(a+b)) for a,b in zip(wrong_sum,shared)]
 different=sum(BF(a)!=BF(b) for a,b in zip(correct,wrong));sumdifferent=sum(BF(a)!=BF(b) for a,b in zip(correct_sum,wrong_sum))
 assert different>0 and sumdifferent>0
 # The chosen global map is monotone; actual expert-order accumulation is unchanged.
 assert sorted(GLOBALS[i] for i in ids)==[GLOBALS[i] for i in sorted(ids)]
 return dict(family='hash' if hash_mode else 'score',replay=replay,local_ids=ids,global_ids=[GLOBALS[i] for i in ids],route_weights=weights,wrong_postdown_metrics=dict(routed=metrics(correct,wrong),combined=metrics(correct_sum,wrong_sum),final_with_same_shared=metrics(final,wrong_final)),sum_exactness=dict(maximum_common_lattice_absolute_sum_bits=max_integer_bits,columns_requiring_over24_significand_bits=columns_over24,slot_order_vs_expert_order_F32_words=slot_order_differences,reverse_order_vs_expert_order_F32_words=reverse_order_differences),routed_bf16_different_words=different,combined_bf16_different_words=sumdifferent,maximum_routed_F32_difference=max(abs(a-b) for a,b in zip(correct,wrong)),correct_routed_peak=max(abs(v) for v in correct),note='Wrong branch runs unweighted BF16 activation through the same dynamicA128/down BF16 primitive,then multiplies routeweight inF32. BF16 comparison is an observation,not an extra mathematical operation in the wrong graph.')
def main():
 cases=[counter(h,r) for h in [False,True] for r in range(3)]
 source=Path('tests/compute_models/d5_deepseek_official_fragments.h')
 result=dict(scope='Host-only six original D5 Flash payloads,logicalD4096/H2048,E256/Top6,resident7; no backend or wholeFFN actual-run claim',formula_source=dict(path=str(source),sha256=hashlib.sha256(source.read_bytes()).hexdigest()),contract='Correct routeweight is applied after F32SiLU*up and before BF16 narrowing,dynamicFP8A128 and down. Moving it after down changes rounding and quantization; linearity of ideal real-valued matrix multiplication does not establish equivalence.',cases=cases,sparse_dot_absolute_sum_common_lattice_bits=LINEAR_WIDTH,limitations=['This follows the already independent D5 helper arithmetic,including its named F64 route denominator/SiLU/sparse dot conveniences; it is not a new universal F32 bit-level oracle.','Shared branch follows the same existing sparse ModelLinear helpers and is identical in both arms. Final observed BF16 word differences demonstrate this fixed counterfactual; they are not backend execution.'])
 Path(__file__).with_name('routeweight-counterfactual.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps([dict(family=c['family'],replay=c['replay'],metrics=c['wrong_postdown_metrics']) for c in cases],indent=2))
if __name__=='__main__':main()
