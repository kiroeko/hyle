from pathlib import Path, PurePosixPath
import hashlib, json, re, zipfile, xml.etree.ElementTree as ET

P = Path(__file__).resolve().parents[1]
R = P.parents[2]


def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def resolve(p):
    p = Path(p)
    return p if p.is_absolute() else R / p


def ident(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size, sha256=sha(p))


def check(d):
    p = resolve(d['path'])
    assert p.is_file() and p.stat().st_size == d['bytes'] and sha(p) == d['sha256'], str(p)


def save(p, d):
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n', encoding='utf8')


config = read(P / 'root/final-results.json')
cases, receipts = [], []


def collect(arm, p):
    tree = ET.parse(p)
    tests = tree.findall('.//testcase')
    assert len(tests) == 1, (arm, len(tests))
    for x in tests:
        assert x.find('failure') is None and x.find('skipped') is None
        name = x.get('classname') + '.' + x.get('name')
        assert name.endswith('.SourceBoundScoreAndHashKeepPreDownWeights'), name
        cases.append(dict(backend=arm, name=name, neighbor=False,
                          properties={i.get('name'): i.get('value')
                                      for i in x.findall('./properties/property')}))


for arm in ('cpu', 'cuda', 'vulkan'):
    p = resolve(config[arm])
    d = read(p)
    assert d['passed'] and d['cases'] == 1 and not d['skipped'] and not d['failed']
    for key in ('image', 'link_plan', 'xml'):
        check(d[key])
    for row in read(resolve(d['link_plan']['path']))['inputs']:
        check(row)
    for row in read(p.parent / 'runtime-environment.json').get('private_modules', []):
        check(row['source'])
        check(row['destination'])
        assert row['hardlink'] and row['source']['sha256'] == row['destination']['sha256']
    collect(arm, resolve(d['xml']['path']))
    receipts.append(dict(backend=arm, receipt=ident(p)))

ap = resolve(config['apple'])
a = read(ap)
assert a['tests'] == 1 and a['failed'] == a['skipped'] == 0
check(a['source_freeze'])
for row in a['artifacts'].values():
    check(row)
assert a['run']['exit'] == 0
assert read(resolve(a['artifacts']['link.result.json']['path']))['exit'] == 0
collect('apple', resolve(a['artifacts']['tests.xml']['path']))
assert len(cases) == 4 and not any(x['neighbor'] for x in cases)
assert all(x['properties']['successful_submissions'] == '6' for x in cases)
assert all(x['properties']['maximum_first_projection_bf16_ulp'] == '0' for x in cases)
for x in cases:
    for stage in (2, 3, 4, 5, 6, 7, 9, 10):
        for metric in ('peak_error', 'relative_l2'):
            assert float(x['properties'][f'stage{stage}_{metric}']) == 0
successful_submissions = sum(int(x['properties']['successful_submissions']) for x in cases)
assert successful_submissions == 24
observed_peak = max(float(x['properties']['maximum_peak_normalized_error']) for x in cases)
observed_l2 = max(float(x['properties']['maximum_relative_l2_error']) for x in cases)
shared = R / 'tests/compute_models/ga_full_ffn_fixture.h'
assert sha(shared) == 'd9539801978b441ee7590c43602bb1f21184269364f0ceb19816dbc1258883b8'
catalog = read(R / 'docs/implementation/model-quantizations.json')
assert len(catalog['artifacts']) == 33
assert all(x['provider_coverage']['artifact_execution_verified'] is False
           for x in catalog['artifacts'])

# Original implementation references are snapshots, not new product builds.
sources = {
    'src/compute/weight_assembly.h', 'include/hyle/compute/weight_assembly.h',
    'src/compute_route_cuda/weights.cc', 'src/compute_route_vulkan/vulkan_weights.cc',
    'src/compute_route_apple/apple_weights.mm',
    'include/hyle/compute/cuda_weights.h', 'include/hyle/compute/vulkan_weights.h',
    'include/hyle/compute/apple_weights.h',
    'src/graph_route_cuda/weight_binding.cc', 'src/graph_route_vulkan/weight_binding.cc',
    'src/graph_route_apple/weight_binding.cc', 'include/hyle/graph/weight_binding.h',
    'include/hyle/graph/result.h', 'include/hyle/graph/executable.h',
    'include/hyle/compute/resource_leases.h', 'include/hyle/compute/model_ops.h',
    'include/hyle/compute/operation.h', 'src/compute/resource_leases.cc',
    'src/graph/input_sources.cc', 'src/graph/resources.cc', 'src/graph/executable.cc',
    'src/compute_ops/low_precision.cc',
    'src/compute_provider_native/torch_cpu_program.cc',
    'src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc',
    'src/compute_provider_cuda/deepseek_grouped_fp4_provider.h',
    'src/compute_provider_cuda/deepseek_fp8_provider.cc',
    'src/compute_provider_cuda/fp8_shared_linear.h',
    'src/compute_provider_cuda/collectives_provider.cc',
    'src/compute_route_apple/apple_mature_float.cc',
    'src/compute_route_vulkan/vulkan_official.cc',
    'src/compute_route_vulkan/vulkan_program.cc',
    'docs/developer/current-work.md', 'docs/user/graph.md', 'docs/user/compute.md',
    'docs/implementation/model-operators.md', 'docs/implementation/model-quantizations.json',
}
sources.update(f'tests/graph_route_{arm}/{name}'
               for arm in ('cpu', 'cuda', 'vulkan', 'apple')
               for name in ('ga_full_ffn_test.cc', 'CMakeLists.txt'))

# Include the existing D5 oracle and its local test-helper closure; no duplicate
# oracle or SDK source tree is introduced. Angle-bracket SDK includes stay out.
pending = [shared]
while pending:
    p = pending.pop()
    relative = p.relative_to(R).as_posix()
    if relative in sources:
        continue
    sources.add(relative)
    for name in re.findall(r'^\s*#include\s+"([^"]+)"', p.read_text(encoding='utf-8-sig'), re.M):
        child = (p.parent / name).resolve()
        if child.is_file() and child.is_relative_to(R / 'tests'):
            pending.append(child)

entries = {'source/' + s: R / s for s in sorted(sources)}
suffixes = {'.json', '.py', '.log', '.txt', '.xml', '.diff', '.cc', '.h', '.hpp',
            '.md', '.mm', '.ps1', '.cmake', '.in', '.d', '.cu', '.cuh', '.metal', '.comp'}
for p in P.rglob('*'):
    if (p.is_file() and p.suffix.lower() in suffixes
            and not p.name.startswith(('package-summary', 'cleanup-plan', 'cleanup-script', 'final-package'))):
        entries['records/' + p.relative_to(P).as_posix()] = p
for extension in ('zip',):
    p = R / f'docs/evidence/research/deepseek-v4-ga-2026-10-19.{extension}'
    entries['provenance/' + p.name] = p
prerequisite = R / 'docs/evidence/correctness/encoded-bank-slices-reference-2026-10-21.json'
entries['provenance/' + prerequisite.name] = prerequisite

archive = R / 'docs/evidence/correctness/ga-full-ffn-reference-2026-10-21.zip'
for name, p in entries.items():
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and p.is_file(), name

# The historical first1 XML/log are retained verbatim as compressed ZIP members.
# They are intentionally not parsed into the small public summary or inlined.
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=8) as z:
    for name, p in sorted(entries.items()):
        z.write(p, name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(entries)
    for name, p in entries.items():
        h = hashlib.sha256()
        with z.open(name) as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                h.update(block)
        assert h.hexdigest() == sha(p), name

doc = dict(
    observed_on='2026-10-21', status='four_backend_formal_GA_finite_routed_and_shared_FFN_passed',
    scope='Complete source-bound ordinary Flash FFN composition: D4096/H2048/globalE256/Top6/resident7, score and hash families with three original replays each. Synthetic original-format weight bytes and finite inputs, not a whole checkpoint/model run.',
    source='Fixed formal GA model.py Gate/Expert/MoE and kernel FP8/FP4 contracts. Existing d5_deepseek_official_fragments::moe_chain and independent D5 source oracle are reused; no new duplicated FFN arithmetic oracle.',
    mathematics='Router linear explicitly uses F32 operands, with bias only for score selection. Original BF16 input feeds dynamic group128 E4 quantization with floor1e-4/power2 scales, original E2M1/group32 scale FP4 gate/up, gate upper clip10/up clip[-10,10] and F32 SiLU multiply. F32 routeweights multiply before BF16 narrowing and down A128 quantization. Routed BF16 results sum in F32; original shared block128 FP8 branch returns BF16 and final addition narrows BF16. No ModelOpt NVFP4 substitution.',
    mapping='Seven original resident expert rows move to nonidentity globals[11,37,83,127,191,223,251] without changing feature columns. Bias/hash entries and published expected tags follow the same map. Checked I32 global-to-local map feeds the three original FP4 expert nodes. Dense physical F32[E,D] router plus metadata transpose restores original RHS; other expected stages are unchanged.',
    numerical_policy='Declared before backend observations: exact global tags and BF16 first projections; F32 routeweight/SiLU stages normalized peak and relativeL2<=2e-5, routeweights also abs<=2e-6. Later BF16/A8 chain relativeL2<=.005 and normalized peak<=.03. First-projection representability and maximumULP remain0 after aggregating assertions. Independent host counterfactual places wrong post-down routeweight routedL2>=.041 and finalL2>=.052, rejecting the fixed policy; finite six-term sum lattice uses at most19 significant bits. No universal F32 reduction-tree bitwise claim.',
    observations=dict(maximum_peak_normalized_error=observed_peak,
                      maximum_relative_l2_error=observed_l2,
                      first_projection_BF16_ULP=0,
                      stages_with_exact_observed_numeric_arrays=[2, 3, 4, 5, 6, 7, 9, 10]),
    journey='One actual mixed encoded/plain immutable weight batch per score/hash family, including the I32 remap; original typed host ReadLease banks on CPU. Three independent original Invocations per family retain all12 source-boundary GraphOutputs. Sources are destroyed after successful upload; old results are checked after later submissions and destruction of public batch/catalog/program/pool/Invocation handles. Context/resources and retained dynamic input leases stay live.',
    resources='Finite output pool reserves all published spans at their original alignment across three retained results per family. Original score/hash bank and aligned capacity accounting, including the six F32 scalar constants, is preserved in actual receipts. Upload reports follow actual staged/submitted/completed bounds. Opaque/private provider allocations and physical bus/DRAM traffic are not inferred.',
    fixes=config['fixes'], build=config['build'],
    prerequisite=ident(prerequisite),
    regression=dict(total=4, new_cases=4, neighbors=0, failed=0, skipped=0,
                    successful_Graph_submissions=successful_submissions,
                    windows=receipts, apple=ident(ap), cases=cases),
    limitations=[
        'Finite complete FFN source/resource composition only; no checkpoint numeric payload, all256 resident experts, complete attention/model, quality or throughput result.',
        'No product changes in this package. Four new wrapper sources use current existing product/SDK objects; prior encoded-bank slice fix is a prerequisite, not a new operator/transfer/executor implementation here. Actual compile/link attempts remain in receipts.',
        'Historical CPU first1 readback failure is retained with original6bb source, raw log and XML: auto-by-value destination copied the vector, leaving actual read buffer zero. Explicit span<byte> callbacks fix the harness; oracle and numeric thresholds are unchanged. Giant repeated first1 diagnostics are compressed ZIP members, not public JSON payload.',
        'CUDA uses original default replay preparation; ordinary TopK does not universally promise full capture. The final hash replay property is a captured-route observation, not evidence for every replay. This package does not claim all commands captured or new capture compatibility.',
        'No Linux/full canonical configure/install/device/dtype/geometry matrix, total private memory or universal floating-point bitwise guarantee. BF16 zero-sign equivalence is not a general raw signed-zero test.',
        'All33 artifact_execution_verified flags remainfalse. This finite role result does not automatically complete capability8 or delivery0/3.',
    ],
    current_sources=[ident(R / s) for s in sorted(sources)],
    archive=dict(**ident(archive), members=len(entries)),
    archive_entries=[dict(entry=name, bytes=p.stat().st_size, sha256=sha(p))
                     for name, p in sorted(entries.items())],
)
save(archive.with_suffix('.json'), doc)
summary = dict(evidence=ident(archive.with_suffix('.json')), archive=doc['archive'],
               sources=len(sources), cases=4, successful_submissions=24)
save(P / 'root/package-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False))
