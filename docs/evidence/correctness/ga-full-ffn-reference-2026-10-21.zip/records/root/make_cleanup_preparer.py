from pathlib import Path

root = Path(__file__).resolve().parent
source = root.parents[1] / 'ga-route-ffn-2026-10-21/root/prepare_cleanup.py'
text = source.read_text(encoding='utf-8')
text = text.replace('encoded-bank-slices-reference', 'ga-full-ffn-reference')
text = text.replace('ga-route-ffn-2026-10-21', 'ga-full-ffn-2026-10-21')
text = text.replace('Exact encoded-bank slice test-artifact cleanup', 'Exact full-FFN test-artifact cleanup')
addition = '''first_failure=[P/'cpu/validation/first1/tests.stdout.log',P/'cpu/validation/first1/tests.xml']
from zipfile import ZipFile
with ZipFile(archive) as z:
 for p in first_failure:
  matches=[m for m in z.infolist() if m.filename.endswith(p.relative_to(P).as_posix())]
  assert len(matches)==1 and matches[0].file_size==p.stat().st_size
remove.extend(ident(p) for p in first_failure)
keep=[ident(p)'''
assert text.count('keep=[ident(p)') == 1
text = text.replace('keep=[ident(p)', addition)
assert text.count("'.exe','.map','.dll'") == 1
text = text.replace("'.exe','.map','.dll'", "'.exe','.map','.dll','.log','.xml'")
(root / 'prepare_cleanup.py').write_text(text, encoding='utf-8')
print('Prepared W cleanup generator; no cleanup plan or deletion executed.')
