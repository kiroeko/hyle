#include "/mnt/c/public/project-hyle/hyle/engine/models/qwen35/prepared_roles.h"
#include <iostream>
namespace qwen35 {
ModelGeometry read_weight_geometry(const std::filesystem::path &manifest) {
  std::ifstream input(manifest); std::string signature, identity, line;
  if (!input) throw std::runtime_error("cannot open prepared input: " + manifest.string());
  prepared::read_manifest_line(input, signature, 128); prepared::read_manifest_line(input, identity, 65);
  if (!prepared::is_role_signature(signature)) throw std::runtime_error("input requires a prepared Qwen V2 manifest; rerun prepare.py");
  prepared::validate_identity(identity); prepared::read_manifest_line(input, line);
  return read_model_geometry(line);
}
}

int main(int argc, char **argv) {
  try {
    if (argc != 2) return 2;
    const std::filesystem::path folder(argv[1]);
    const auto expected = qwen35::read_weight_geometry(folder / "hf-lf.tsv");
    for (const auto *name : {"hf-lf.tsv", "hf-crlf.tsv", "gguf-lf.tsv", "gguf-crlf.tsv"}) {
      if (qwen35::read_weight_geometry(folder / name) != expected) return 3;
      std::cout << "PASS " << name << '\n';
    }
    return 0;
  } catch (const std::exception &error) { std::cerr << error.what() << '\n'; return 1; }
}
