from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

root = Path.cwd()
out = root / '.scratch/qwen-multi-draft-20261024' / ('source-geometry-newlines-' + sys.argv[1])
out.mkdir(exist_ok=False)
product = root / 'engine/models/qwen35/main.cc'
text = product.read_text(encoding='utf-8')
first = text.index('ModelGeometry read_weight_geometry(')
last = text.index('\nprepared::Roles read_weight_roles(', first)
body = text[first:last]
original = root / '.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original/weights.tsv'
lines = original.read_text(encoding='utf-8').splitlines()[:3]
for signature, name in [('HYLE_QWEN_ROLE_FILES_V2', 'hf'), ('HYLE_QWEN_GGUF_ROLE_FILES_V2', 'gguf')]:
    for newline, style in [('\n', 'lf'), ('\r\n', 'crlf')]:
        (out / f'{name}-{style}.tsv').write_bytes((newline.join([signature, *lines[1:]]) + newline).encode('utf-8'))
source = '#include "' + '/mnt/c/public/project-hyle/hyle/engine/models/qwen35/prepared_roles.h' + '"\n#include <iostream>\nnamespace qwen35 {\n' + body + '\n}\n'
source += '''
int main(int argc, char **argv) {
  try {
    if (argc != 2) return 2;
    const std::filesystem::path folder(argv[1]);
    const auto expected = qwen35::read_weight_geometry(folder / "hf-lf.tsv");
    for (const auto *name : {"hf-lf.tsv", "hf-crlf.tsv", "gguf-lf.tsv", "gguf-crlf.tsv"}) {
      if (qwen35::read_weight_geometry(folder / name) != expected) return 3;
      std::cout << "PASS " << name << '\\n';
    }
    return 0;
  } catch (const std::exception &error) { std::cerr << error.what() << '\\n'; return 1; }
}
'''
(out / 'exact-function.cc').write_text(source, encoding='utf-8')
linux = '/mnt/c/' + out.relative_to(Path('C:/')).as_posix()
commands = [
    ['wsl', '-d', 'Ubuntu-24.04', '--', 'g++', '-std=c++23', '-O0', '-Wall', '-Wextra', '-Werror',
     linux + '/exact-function.cc', '-o', linux + '/check'],
    ['wsl', '-d', 'Ubuntu-24.04', '--', linux + '/check', linux],
]
records = []
for index, command in enumerate(commands):
    start = time.time()
    result = subprocess.run(command, capture_output=True, timeout=60, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / f'{index}-stdout.log').write_bytes(result.stdout)
    (out / f'{index}-stderr.log').write_bytes(result.stderr)
    records.append(dict(command=command, exit=result.returncode, seconds=time.time()-start))
    if index == 0 and result.returncode:
        raise RuntimeError('metadata-only compile failed')
record = dict(scope='Exact source read_weight_geometry function body isolated with its real standard-library-only prepared headers; no copied implementation or model execution.',
              product_sha256=hashlib.sha256(product.read_bytes()).hexdigest(),
              extracted_function_sha256=hashlib.sha256(body.encode()).hexdigest(), records=records,
              SDK_builds=0, HTTP=0, model_body_reads=0)
(out / 'result.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
sys.exit(records[-1]['exit'])
