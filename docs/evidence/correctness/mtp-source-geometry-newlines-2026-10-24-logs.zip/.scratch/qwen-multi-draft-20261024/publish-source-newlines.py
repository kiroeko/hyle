from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd()
base = root / '.scratch/qwen-multi-draft-20261024'
evidence = root / 'docs/evidence/correctness'
name = 'mtp-source-geometry-newlines-2026-10-24'
members = [Path(__file__), base / 'check-source-geometry-newlines.py']
results = {}
for phase in ['before', 'after']:
    folder = base / ('source-geometry-newlines-' + phase)
    results[phase] = json.loads((folder / 'result.json').read_text())
    members.extend(p for p in folder.iterdir() if p.suffix in ['.cc', '.log', '.json', '.tsv'])
assert results['before']['records'][-1]['exit'] == 1
assert results['after']['records'][-1]['exit'] == 0
assert (base / 'source-geometry-newlines-after/1-stdout.log').read_text().count('PASS ') == 4
archive = evidence / (name + '-logs.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as out:
    for path in sorted(set(members)):
        out.write(path, path.relative_to(root).as_posix())
proof = dict(date='2026-10-24',
    problem='The early geometry reader preserved CR on the source identity under Linux; the full prepared reader already accepted CRLF but could not be reached.',
    fix='Strip the identity line terminal CR before validating its hash, matching the full role reader.',
    method='Compile and execute the exact product function body, extracted without edits, with the real prepared headers under WSL GCC. This is a metadata-only focused check, not a whole-engine build or inference.',
    before=results['before'], after=results['after'],
    cases=['HF LF', 'HF CRLF', 'GGUF LF', 'GGUF CRLF'], SDK_builds=0, HTTP=0, weight_body_reads=0,
    archive=dict(path=archive.relative_to(root).as_posix(), bytes=archive.stat().st_size,
                 sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
(evidence / (name + '.json')).write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(passed=True,cases=4,archive_bytes=archive.stat().st_size)))
