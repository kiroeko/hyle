from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
H=R/'.scratch/inference-packed-row-geometry-20261028'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
    p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):
    with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
sources=['engine/inference/packed_rows.h','engine/models/qwen35/main.cc','engine/models/qwen35/mtp_graph.h',
 'tests/tools/inference_prefill_plan_test.cc','tests/tools/qwen_host_image_test.cc','tests/tools/qwen_mtp_packed_prefill_case.h']
for p in sources:
    out=W/'source'/p;out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('xb') as f:f.write((R/p).read_bytes())
summary={}
for backend in ('cpu','cuda'):
    path=W/('tiny-'+backend+'-run/report.json');a=read(path)
    assert a['status']=='PASS' and len(a['steps'])==7 and a['numerically_equivalent']
    assert a['final_length']==a['final_frontier']==16 and a['final_rng_draws']==5
    assert a['old_checkpoints_byte_unchanged'] and a['rng_and_epochs_equal']
    assert a['final_versions']==a['final_images']==a['final_native_episodes']==0
    diffs=[d for s in a['steps'] for d in s['state']['differences']]
    assert all(d['role']==3 and not d['nonfinite_differences'] for d in diffs)
    summary[backend]=dict(status='PASS',report=pin(path),target_capacity=a['target_capacity'],lag1_draft_capacity=a['lag1_draft_capacity'],
       steps=[dict(role=s['role'],target_active=s['state']['active_rows'],target_physical=s['state']['physical_rows'],
            draft_active=s['draft_active_rows'],draft_physical=s['draft_physical_rows'],
            lag_before=s['lag_before'],lag_after=s['lag_after']) for s in a['steps']],
       maximum_absolute_gdn_error=max([d['maximum_absolute'] for d in diffs],default=0),
       payloads_byte_equal=a['payloads_byte_equal'],numerically_equivalent=True,
       old_checkpoints_byte_unchanged=True,rng_and_epochs_equal=True,final_length=16,final_frontier=16,
       final_rng_draws=5,final_versions=0,final_images=0,final_native_episodes=0,
       controlled_verify_width=a['controlled_verify_width'],controlled_accepted_rows=a['controlled_accepted_rows'],
       discarded_target_rows=a['discarded_target_rows'],natural_acceptance_claim=False)
cli=read(W/'cli-mtp-run/report.json')
assert cli['mtp'] and cli['packed_prefill_calls']==1 and cli['cold_exact_admissions']==0
assert (cli['packed_prefill_active_rows'],cli['packed_prefill_physical_rows'])==(154,154)
assert cli['sessions'][0]['result']['generated_ids']==[71093,12305,198,464,19298,198,1445,18904]
regression=read(W/'ragged-cuda-regression/report.json');assert regression['status']=='PASS'
host=read(H/'summary.json');assert host['status']=='PASS' and host['groups']==9
processes=[]
for folder in (W,H):
    for p in sorted(folder.rglob('process.json')):
        x=read(p);assert x['exit']==0 and not x['timed_out'];processes.append(dict(path=str(p),**x))
target=R/'docs/evidence/correctness/inference-mtp-packed-prefill-2026-10-28.json'
data=dict(date='2026-10-28',base_commit='955817d5b',status='Finite checks passed',
 scope='R1 MTP effective-length prefill/catchup and shared integer input geometry; not full varlen completion or performance closure.',
 sources=[pin(R/p) for p in sources],
 implementation=['pack_sequence_rows fills original caller cold-reserved offsets/last IDs/positions with no allocation, payload, queue, lease or permission owner; all validation precedes writes.',
  'Target and draft both use this same geometry function, with distinct base positions, actual Li versus Li+lag, and physical R versus R+lag.',
  'R1 MTP packed prefill/catchup reuses original KV shift, checked actual-last-hidden selection, Append/Store transactions and retirement; recursive verifier repair is unchanged.',
  'Natural Li1 retains original Single/CatchupSingle; only cold unsupported selects exact fallback.'],
 host_geometry=dict(status='PASS',groups=9,summary=pin(H/'summary.json'),
  coverage='Unequal lengths/order, target/draft lag geometry, complete padding positions, bad final member preserves every output, alias/extents, I32 position limit and overflow rejection.'),
 tiny=summary,
 real_cli=dict(image=read(W/'ready-model.json')['image'],report=pin(W/'cli-mtp-run/report.json'),
    packed_prefill_calls=1,active_rows=154,physical_rows=154,cold_exact_admissions=0,
    generated_ids=cli['sessions'][0]['result']['generated_ids'],performance_claim=False),
 ordinary_b2_regression=dict(report=pin(W/'ragged-cuda-regression/report.json'),backend='cuda',
    status='PASS',actual_rows=22,physical_rows=64,committed_rows=21,old_checkpoints_byte_unchanged=True),
 numerical_contract='Only recomputed finite F32 GDN payloads use existing 3e-6 FP64 component absolute budget; other target/draft KV, history, carry/prior, old checkpoints, metadata and RNG stay strict. No full-model FP64/quality claim.',
 processes=processes,cost=dict(model_CXX=2,model_links=2,host_CXX=1,host_link=1,consumer_processes=4,host_processes=1,SDK_builds=0,NVCC=0,downloads=0),
 remaining=['B2 variable-length MTP hidden/token shifts and independent draft offsets',
  'MTP bounded prefill/StateOnly feature combination','Other platform/provider/dtype combinations',
  'Shared execution architecture and current full performance comparison'],
 limits=['Controlled verifier accepts two of three real rows and executes original repair; it does not measure natural acceptance probability.',
  'The normal real-model CLI has no padding in its P154 carrier; tiny cases establish short-active-R4/R5 behavior.',
  'No refreshed speed/memory A/B or cross-engine window.'])
save(target,data)
files={'evidence.json':target}
for folder,name in ((W,'mtp'),(H,'host')):
    for p in folder.rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.json','.log','.py','.h','.cc'} and '__pycache__' not in p.parts:
            files[name+'/'+str(p.relative_to(folder)).replace('\\','/')]=p
manifest=[dict(name=k,**pin(v)) for k,v in sorted(files.items())]
archive=target.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for k,v in sorted(files.items()):z.write(v,k)
    z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
save(W/'packaged.json',dict(evidence=pin(target),archive=pin(archive),members=len(manifest)+1))
print(json.dumps(read(W/'packaged.json'),indent=2))
