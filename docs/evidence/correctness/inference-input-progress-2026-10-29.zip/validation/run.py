"""Three current Model TUs and one standalone host TU; six finite cases."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
OLD = R / '.scratch/inference-program-installation-20261028'
SOURCE_BATCH = R / '.scratch/inference-submission-views-20261028'
PLAIN = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
A_FIXTURE = R / '.scratch/inference-request-progress-20261025/verification/qwen/output/fixed'
UNITS = {'tiny': R/'tests/tools/qwen_host_image_test.cc',
         'relay': R/'tests/tools/qwen_generation_batch_relay_probe.cc',
         'lifecycle': R/'tests/tools/qwen_request_lifecycle_test.cc',
         'host': R/'tests/tools/inference_request_progress_test.cc'}
SOURCES = ('engine/inference/prepared_program_family.h', 'engine/models/qwen35/main.cc',
           'tests/tools/inference_program_carrier_case.h', 'tests/tools/qwen_host_image_test.cc',
           'tests/tools/qwen_generation_batch_relay_probe.cc', 'tests/tools/qwen_generation_state_case.h',
           'tests/tools/qwen_geometry_fixture.h', 'tests/tools/qwen_packed_prefill_case.h',
           'tests/tools/qwen_ragged_prefill_case.h', 'tests/tools/qwen_mtp_packed_prefill_case.h',
           'tests/tools/qwen_mtp_batch_state_case.h', 'tests/tools/qwen_mtp_sampling_case.h')
CASES = {'host': ('host','host',''),
         'sampling-cpu': ('tiny','cpu','--sampling-policies'),
         'history-cuda': ('tiny','cuda','--history-logits'),
         'wave-cuda': ('tiny','cuda','--generation-wave'),
         'midturn-cpu': ('lifecycle','cpu','--midturn-resume'),
         'midturn-cpu-cached-a': ('lifecycle','cpu','--midturn-resume'),
         'relay-cuda': ('relay','cuda','--cuda')}


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


t = module(R/'.scratch/inference-indexed-store-20261028/build.py', 'resource_graph_executor')
t.W = W


def prepare():
    prior = t.read(OLD/'plan.json'); assert len(prior['retained']) == 227
    for row in prior['retained']: t.exact(row)
    units = {}
    for name, source in UNITS.items():
        compile_args = []
        for index, arg in enumerate(prior['compile']):
            if t.key(arg) == t.key(UNITS['tiny']): arg = str(source)
            elif index and prior['compile'][index-1].casefold() == '/sourcedependencies':
                arg = str(W/'compile'/name/'dependencies.json')
            elif arg.casefold().startswith('/fo'): arg = '/Fo'+str(W/'compile'/name/'unit.obj')
            elif arg.casefold().startswith('/fd'): arg = '/Fd'+str(W/'compile'/name/'unit.pdb')
            compile_args.append(arg)
        assert sum(t.key(arg)==t.key(source) for arg in compile_args) == 1
        link_args = []
        for arg in prior['link']:
            if t.key(arg) == t.key(OLD/'compile/unit.obj'): arg = str(W/'compile'/name/'unit.obj')
            for prefix, suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
                if arg.upper().startswith(prefix): arg = prefix+str((W/'bin'/name).with_suffix(suffix)); break
            link_args.append(arg)
        assert sum(t.key(arg)==t.key(W/'compile'/name/'unit.obj') for arg in link_args) == 1
        assert not any(t.key(arg)==t.key(OLD/'compile/unit.obj') for arg in link_args)
        units[name] = dict(source=str(source), compile=compile_args, link=link_args)
    host_object = W/'compile/host/unit.obj'
    units['host']['compile'] = [prior['compile'][0], '/nologo', '/std:c++latest', '/EHsc', '/O2', '/MD', '/DNOMINMAX', '/c',
        str(UNITS['host']), '/Fo'+str(host_object), '/sourceDependencies', str(W/'compile/host/dependencies.json')]
    units['host']['link'] = [prior['link'][0], '/NOLOGO', '/INCREMENTAL:NO', '/OPT:REF', '/OPT:ICF',
        '/SUBSYSTEM:CONSOLE', '/OUT:'+str(W/'bin/host.exe'), str(host_object)]
    paths = {t.key(R/path):str(R/path) for path in SOURCES}
    for old in (OLD, SOURCE_BATCH):
        for row in t.read(old/'compile/compiled.json')['project_dependencies']:
            path = t.canonical(row['path'])
            if t.project(path): paths[t.key(path)] = str(path)
    import subprocess
    changed = subprocess.check_output(['git','diff','--name-only','--','engine','tests/tools'], cwd=R, text=True).splitlines()
    for relative in changed: paths[t.key(R/relative)] = str(R/relative)
    env = t.read(OLD/'environment.json'); env['PATH'] = str(W/'bin')+';'+env['PATH']
    t.save(W/'environment.json', env)
    t.save(W/'plan.json', dict(base=t.pin(OLD/'plan.json'), retained=prior['retained'], units=units,
        runtime=prior['runtime'], fixture=t.pin(PLAIN/'weights.tsv'), prompt=t.pin(PLAIN/'prompt.ids'),
        sources=list(paths.values()), changed_sources=changed, counts=dict(CXX=4,links=4,SDK_CXX=0,NVCC=0,model_inputs_each=228,host_inputs=1,
            retained_inputs=227,native_processes=6,downloads=0)))
    print('PREPARED: current Tiny/Lifecycle/Relay and standalone host; retained 227; no compiler/native started')


def freeze():
    plan = t.read(W/'plan.json')
    t.save(W/'source-freeze.json', [t.pin(path) for path in plan['sources']])
    print('SOURCE FROZEN', len(plan['sources']))


def validate():
    for row in t.read(W/'source-freeze.json'): t.exact(row)
    return t.read(W/'plan.json')


def parse_compile(name):
    plan = validate(); directory = W/'compile'/name
    process = t.read(W/'logs'/('compile-'+name)/'process.json'); assert process['exit']==0
    deps = [t.pin(path) for path in t.dep_paths(directory/'dependencies.json') if t.project(path)]
    t.save(directory/'compiled.json', dict(source=t.pin(plan['units'][name]['source']),
        object=t.pin(directory/'unit.obj'), process=process, project_dependencies=deps))
    print('CXX METADATA PASS', name, process['pid'])


def compile(name):
    plan = validate(); (W/'compile'/name).mkdir(parents=True)
    t.execute(plan['units'][name]['compile'], W/'logs'/('compile-'+name), 300)
    parse_compile(name)


def link(name):
    plan = validate(); compiled = t.read(W/'compile'/name/'compiled.json'); t.exact(compiled['object'])
    for row in plan['retained']: t.exact(row)
    (W/'bin').mkdir(exist_ok=True)
    native = plan['runtime']; alias = W/'bin'/Path(native['path']).name
    if not alias.exists():
        try: alias.hardlink_to(native['path'])
        except FileExistsError: pass  # Independent links can create this same real DLL alias.
    assert alias.samefile(native['path'])
    process = t.execute(plan['units'][name]['link'], W/'logs'/('link-'+name), 240)
    t.save(W/f'ready-{name}.json', dict(image=t.pin(W/'bin'/f'{name}.exe'),
        inputs=([] if name=='host' else plan['retained'])+[compiled['object']], compiled=compiled, process=process,
        runtime=native, source_freeze=t.pin(W/'source-freeze.json')))
    print('LINK PASS', name, process['pid'])


def parse(name):
    unit, backend, flag = CASES[name]; out = W/'runs'/name
    process = t.read(out/'process.json'); assert process['exit']==0 and not process['timed_out']
    reports = [json.loads(line) for line in (out/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if name == 'host':
        assert not reports
        lines=(out/'stdout.log').read_text(encoding='utf-8-sig').splitlines()
        assert len(lines)==12 and all(line.startswith('PASS ') for line in lines)
        report=dict(status='PASS', case='request-progress', host_groups=12, groups=lines, model=False, performance_claim=False)
    elif name == 'sampling-cpu':
        report=next(row for row in reports if row.get('case')=='sampling-policies')
        assert report['status']=='PASS' and report['partial_prefix_input_cursor'] is True
        assert (report['configurations'],report['requests'],report['turns'])==(4,6,12)
    elif name == 'relay-cuda':
        parser=module(R/'.scratch/inference-phase-carrier-20261028/run.py','input_progress_relay_parser')
        report=parser.relay_report(reports)
    else:
        if name=='history-cuda':
            assert len(reports)==2 and reports[0]['case']=='history-finite-math' and reports[0]['result']=='PASS'
            report=reports[1]
        else:
            assert len(reports)==1; report=reports[0]
        assert report['status']=='PASS' and report['backend']==backend
        if name.startswith('midturn-cpu'):
            assert report['same_key'] is True and report['final_versions']==0
            assert (report['checkpoint_hits'],report['actual_evictions'],report['ledger_rebuilds'],report['final_sampling_draw'])==(1,2,2,3)
            assert report['GPU'] is False and report['HTTP'] is False
        else:
            assert report['performance_claim'] is False and report['final_versions']==0
            if name=='history-cuda':
                for field in ('K1_K2_greedy_random','derived_vs_manual_B2','StateOnly_no_counts_or_draw','same_key_HostImage','full_hit_seed_before_frontier'):
                    assert report[field] is True,field
                assert len(report['state_checks'])>0
                assert all(row['numerically_equivalent'] for row in report['state_checks'])
            elif name=='wave-cuda':
                for field in ('whole_wave_prepare_before_publish','cancelled_heads_ledger_rng_unchanged','survivor_same_key_retry','prefix_unpublished_on_cancel'):
                    assert report[field] is True,field
    t.save(out/'report.json', report)
    print('PASS', name, 'PID', process['pid'])


def run(name):
    plan = validate(); unit, backend, flag = CASES[name]
    ready = t.read(W/f'ready-{unit}.json'); t.exact(ready['image']); t.exact(plan['fixture']); t.exact(plan['prompt'])
    if unit=='host': args=[ready['image']['path']]
    elif unit=='lifecycle':
        fixture=A_FIXTURE if name=='midturn-cpu-cached-a' else PLAIN
        if name=='midturn-cpu-cached-a':
            previous=t.read(W/'runs/midturn-cpu/process.json')
            assert previous['exit']==1 and previous['state']=='TERMINAL'
            assert 'requires the cached untrained A/H64/FFN128/V64 fixture' in (W/'runs/midturn-cpu/stderr.log').read_text()
            import shlex
            lines=(fixture/'weights.tsv').read_text(encoding='utf-8-sig').splitlines()
            assert shlex.split(lines[2])[-1]=='A'
            for line in lines[3:]:
                row=shlex.split(line); payload=Path(row[-3]); offset,length=int(row[-2]),int(row[-1])
                assert offset>=0 and length>0 and offset+length<=payload.stat().st_size
            t.save(W/'fixture-correction.json',dict(failed_process=previous,fixture=t.pin(fixture/'weights.tsv'),
                reason='Original GA fixture rejected by existing pure-A entry guard before Model creation; use original cached pure-A payload ranges.',
                payload_copy=False,downloads=0))
        args=[ready['image']['path'],flag,str(fixture)]
    else:
        args=[ready['image']['path'],'--'+backend,str(PLAIN)]
        if unit=='tiny': args.append(flag)
    t.execute(args, W/'runs'/name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare','freeze'): globals()[action]()
    elif action in ('compile','parse_compile','link','run','parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
