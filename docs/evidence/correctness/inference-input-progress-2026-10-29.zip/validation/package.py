"""Root-only offline packaging; no compilation, native execution or retries."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-input-progress-2026-10-29'
CASES = ('host', 'sampling-cpu', 'history-cuda', 'wave-cuda', 'midturn-cpu-cached-a', 'relay-cuda')
PRIMARY = ('engine/inference/request_progress.h', 'engine/models/qwen35/main.cc',
           'tests/tools/inference_request_progress_test.cc', 'tests/tools/qwen_sampling_policy_case.h')


def read(path): return json.loads(Path(path).read_bytes())
def encode(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))
def key(path): return str(path).replace('/', '\\').casefold()
def terminal(row): assert row['state'] == 'TERMINAL' and row['exit'] == 0 and row['timed_out'] is False, row


def main():
    outjson, outzip = DEST.with_suffix('.json'), DEST.with_suffix('.zip')
    assert not outjson.exists() and not outzip.exists(), 'Preserve existing evidence'
    plan, frozen = read(W/'plan.json'), read(W/'source-freeze.json')
    archive, builds, cases, dependencies, observed_only = {}, [], [], {}, {}
    def add(path, name=None):
        path = Path(path); name = name or 'validation/' + path.relative_to(W).as_posix()
        assert name not in archive and 'environment' not in path.name.casefold()
        assert path.suffix.lower() not in ('.exe', '.obj', '.dll', '.lib', '.pdb', '.bin', '.safetensors', '.gguf')
        archive[name] = path.read_bytes()
    for rel in ('package.py', 'run.py', 'plan.json', 'source-freeze.json'): add(W/rel)
    frozen_index = {key(row['path']): row for row in frozen}
    consumer_sources = {}
    for unit in ('host', 'tiny', 'lifecycle', 'relay'):
        compiled, ready = read(W/f'compile/{unit}/compiled.json'), read(W/f'ready-{unit}.json')
        cxx, link = read(W/f'logs/compile-{unit}/process.json'), read(W/f'logs/link-{unit}/process.json')
        terminal(cxx); terminal(link)
        assert compiled['process'] == cxx and ready['compiled'] == compiled and ready['process'] == link
        expected = plan['counts']['host_inputs' if unit == 'host' else 'model_inputs_each']
        assert len(ready['inputs']) == len({key(row['path']) for row in ready['inputs']}) == expected
        assert ready['inputs'][-1] == compiled['object']
        for row in compiled['project_dependencies']:
            identity = key(row['path'])
            if identity in frozen_index: assert row == frozen_index[identity], row['path']
            else: observed_only[identity] = row
            if identity in dependencies: assert dependencies[identity] == row
            dependencies[identity] = row
        consumer_sources[key(compiled['source']['path'])] = compiled['source']
        builds.append(dict(unit=unit, compile_process=cxx, link_process=link, image=ready['image'], inputs=expected))
        for rel in (f'compile/{unit}/compiled.json', f'compile/{unit}/dependencies.json', f'ready-{unit}.json'): add(W/rel)
        for stage in ('compile', 'link'):
            for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(W/f'logs/{stage}-{unit}'/filename)
    changed = [frozen_index[key(R/rel)] for rel in plan['changed_sources']]
    for row in changed: assert pin(row['path']) == row
    primary = {key(R/rel): frozen_index[key(R/rel)] for rel in PRIMARY}
    for row in (primary | consumer_sources).values():
        assert pin(row['path']) == row and dependencies[key(row['path'])] == row
        add(row['path'], 'source/' + Path(row['path']).relative_to(R).as_posix())
    mechanical = [dict(**row, included_by_actual_compilation=key(row['path']) in dependencies)
                  for row in changed if key(row['path']) not in primary]
    assert len(changed) == 17 and len(mechanical) == 13
    fixture = plan['fixture']; assert pin(fixture['path']) == fixture and pin(plan['prompt']['path']) == plan['prompt']
    add(fixture['path'], 'fixture/weights.tsv'); add(plan['prompt']['path'], 'fixture/prompt.ids')
    correction = read(W/'fixture-correction.json'); failed_directory = W/'runs/midturn-cpu'
    failed = read(failed_directory/'process.json')
    assert failed == correction['failed_process'] and failed['state'] == 'TERMINAL' and failed['exit'] == 1 and failed['timed_out'] is False
    assert not (failed_directory/'report.json').exists() and correction['payload_copy'] is False and correction['downloads'] == 0
    assert pin(correction['fixture']['path']) == correction['fixture']
    add(W/'fixture-correction.json'); add(correction['fixture']['path'], 'fixture/corrected-pure-a-weights.tsv')
    for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(failed_directory/filename)
    for name in CASES:
        directory = W/'runs'/name; process = read(directory/'process.json'); terminal(process)
        report = read(directory/'report.json'); assert report['status'] == 'PASS'
        lines = (directory/'stdout.log').read_text(encoding='utf-8-sig').splitlines()
        raw = [json.loads(line) for line in lines if line.startswith('{')]
        if name == 'host':
            assert not raw and report['host_groups'] == 12 and report['groups'] == lines
            assert len(lines) == 12 and all(line.startswith('PASS ') for line in lines) and report['model'] is False
        else:
            statuses = [row['status'] for row in raw if 'status' in row]
            assert statuses and all(value == 'PASS' for value in statuses)
            if name == 'sampling-cpu': assert report['partial_prefix_input_cursor'] is True
        facts = {k: v for k, v in report.items() if not isinstance(v, (dict, list))}
        if isinstance(report.get('state_checks'), list): facts['state_check_records'] = len(report['state_checks'])
        cases.append(dict(name=name, process=process, facts=facts, report=pin(directory/'report.json')))
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'report.json'): add(directory/filename)
    assert len({(row['process']['pid'], row['process']['started']) for row in cases}) == len(CASES)
    manifest = encode([dict(name=name, bytes=len(body), sha256=sha(body)) for name, body in sorted(archive.items())])
    archive['MANIFEST.json'] = manifest
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, body in sorted(archive.items()): z.writestr(name, body)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, body in archive.items(): assert sha(z.read(name)) == sha(body), name
    result = dict(schema='hyle.correctness.input-progress.v1', date='2026-10-29', status='PASS_SIX_FINITE_CASES',
        change='RequestProgress borrows each admitted input, partitions its remaining span, and observes committed input/output facts together; '
               'prefix history, StateOnly chunks, ordinary/MTP output and later-turn pending retain their original authorities.',
        planned_counts=plan['counts'], counts=dict(CXX=len(builds), links=len(builds), SDK_CXX=0, NVCC=0,
            retained_model_inputs=227, model_inputs_each=228, host_inputs=1, OS_process_attempts=len(cases)+1,
            successful_processes=len(cases), failed_fixture_attempts=1, downloads=0),
        host_groups=12, primary_sources=list(primary.values()), mechanical_test_migrations=mechanical,
        source_freeze=pin(W/'source-freeze.json'), builds=builds, cases=cases, fixture=fixture,
        failed_fixture_attempt=dict(name='midturn-cpu', process=failed, report_generated=False, correction=correction),
        parser_note='History native PID55080 exited0 and printed history-finite-math plus history-logits; '
                    'root corrected only the offline parser and parsed the same raw output without a native rerun.',
        actual_dependency_pins_absent_from_preflight_freeze=list(observed_only.values()),
        limits=['The unchanged Lifecycle consumer and its additional headers were pinned in actual compiler receipts, not the original preflight freeze.',
                '13 mechanical test migrations are source identities; inclusion by a compiled TU does not claim all their runtime cases executed.',
                'Host12 plus five finite synthetic CPU/CUDA model journeys; original case oracles/parsers apply. No full feature, real device fault, trained quality or performance claim.',
                'Three model consumers reuse 227 SDK/weights inputs each; host links one OBJ and standard CRT. No SDK/NVCC compilation, downloads, payload or environment data in this archive.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', member_SHA256='PASS'))
    with outjson.open('xb') as out: out.write(encode(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', member_SHA256='PASS')
    with (W/'package-readback.json').open('xb') as out: out.write(encode(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
