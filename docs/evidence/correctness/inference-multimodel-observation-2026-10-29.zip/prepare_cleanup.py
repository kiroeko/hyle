from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('current_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=R/'.scratch/inference-glm-request-loop-20261029/compile/glm/unit.obj'
roots=[W/'bin',old.parent]
targets=[b.pin(p) for p in sorted((W/'bin').iterdir()) if p.is_file()]+[b.pin(old)]
assert all(Path(p['path']).parent in roots for p in targets)
assert all(Path(p['path']).suffix.lower() in ['.exe','.dll','.pdb','.lib','.exp','.map','.obj'] for p in targets)
b.save(W/'cleanup-plan.json',dict(allowed_roots=list(map(str,roots)),targets=targets,
    kept='All227 original SDK inputs, original runtime DLL, three current consumer objects and independent useful consumer objects; only current bin copies/linker products and superseded same-GLM object are removed.'))
script=r'''$ErrorActionPreference = 'Stop'
$TaskRoot = 'C:\public\project-hyle\hyle\.scratch\inference-multimodel-observation-20261029'
$ExpectedRoots = @(
    'C:\public\project-hyle\hyle\.scratch\inference-multimodel-observation-20261029\bin',
    'C:\public\project-hyle\hyle\.scratch\inference-glm-request-loop-20261029\compile\glm'
)
$Plan = Get-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$AllowedRoots = @($Plan.allowed_roots | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') })
if ($AllowedRoots.Count -ne 2 -or @($AllowedRoots | Where-Object { $_ -notin $ExpectedRoots }).Count) { throw 'Unexpected cleanup roots' }
foreach ($Receipt in Get-ChildItem -LiteralPath (Join-Path $TaskRoot 'runs') -Filter 'process.json' -File -Recurse) {
    $Fact = Get-Content -LiteralPath $Receipt.FullName -Raw | ConvertFrom-Json
    if ($Fact.state -ne 'TERMINAL') { throw "Original native process is not terminal: $($Receipt.FullName)" }
}
foreach ($Target in $Plan.targets) {
    $Resolved = [IO.Path]::GetFullPath($Target.path)
    if ([IO.Path]::GetDirectoryName($Resolved) -notin $AllowedRoots) { throw "Outside exact allowed directories: $Resolved" }
    $Item = Get-Item -LiteralPath $Resolved
    if ($Item.PSIsContainer -or $Item.Length -ne $Target.bytes) { throw "Changed cleanup target: $Resolved" }
    if ((Get-FileHash -LiteralPath $Resolved -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Target.sha256) { throw "Changed cleanup hash: $Resolved" }
}
$Removed = @()
foreach ($Target in $Plan.targets) {
    Remove-Item -LiteralPath $Target.path -Force
    $Removed += [pscustomobject]@{ path=$Target.path; bytes=$Target.bytes; removed=(-not (Test-Path -LiteralPath $Target.path)) }
}
if (@($Removed | Where-Object { -not $_.removed }).Count) { throw 'Cleanup incomplete' }
[pscustomobject]@{ status='PASS'; files=$Removed.Count; bytes=($Removed | Measure-Object bytes -Sum).Sum; removed=$Removed } |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-result.json') -Encoding utf8
Write-Output "Removed $($Removed.Count) checked reconstructible binary files."
'''
(R/'test.ps1').write_text(script,encoding='utf-8-sig')
(W/'cleanup.ps1').write_text(script,encoding='utf-8-sig')
print('Prepared',len(targets),'exact files,',sum(p['bytes'] for p in targets),'bytes')
for target in targets:print(target['path'],target['bytes'])
