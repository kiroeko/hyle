from pathlib import Path
import importlib.util
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('current_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin = b.read, b.save, b.pin
plan = read(W / 'plan.json')
cases = {}
for name, case in plan['cases'].items():
    attempt = 'retained' if name == 'runner-cpu' else 'attempt1'
    folder = W / 'runs' / name / attempt
    process = read(folder / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    report = read(folder / 'report.json')
    assert report['status'] == 'PASS' and report['tests'] == case['tests'] and not report['skipped']
    cases[name] = dict(process=process, report=report, image=read(folder / 'image.json'))
for name in ['ds-pro-cpu', 'ds-flash-cpu']:
    p = cases[name]['report']['properties']
    for field, value in {'random_request_committed_records': '2', 'random_request_observed_records': '2',
        'random_request_family_observations': '2', 'random_request_record_projections': '3',
        'random_request_late_observer_refusals': '1', 'random_request_observe_only_retries': '1',
        'actual_missing_frontiers': '0', 'state_members': '31'}.items():
        assert p[field] == value, (name, field, p.get(field))
comparisons = {}
for name, old in [
    ('ds-pro-cpu', R / '.scratch/dspark-random-mtp-20261024/pro-natural/results.xml'),
    ('ds-flash-cpu', R / '.scratch/dspark-random-mtp-20261024/attempt2-source/results.xml'),
    ('glm-cuda', R / '.scratch/inference-glm-request-loop-20261029/runs/glm-cuda/attempt1/results.xml')]:
    previous = {p.get('name'): p.get('value') for p in ET.parse(old).getroot().findall('.//property')}
    current = cases[name]['report']['properties']
    numeric = {k: v for k, v in previous.items() if v.isnumeric()}
    different = {k: [v, current.get(k)] for k, v in numeric.items() if current.get(k) != v}
    comparisons[name] = dict(previous_result=pin(old), compared_numeric_fields=len(numeric), different=different)
    if name == 'ds-pro-cpu':
        assert not (set(different) - {'state_backing_budget'}), (name, different)
    elif name == 'glm-cuda':
        assert not different, (name, different)
parent_source = subprocess.check_output(['git', 'show', plan['worktree_base_commit'] + ':tests/compute_models/dspark_pro_mtp_state_consumer_test.cc'], cwd=R)
(W / 'parent-model-source.cc').write_bytes(parent_source)
assert b'auto threshold=round(threshold_head,2,40' in parent_source
builds = {}
for name in plan['units']:
    receipt = b.receipt(name)
    builds[name] = dict(object=receipt['object'],
        compiles=[read(p) for p in sorted((W / 'compile' / name).rglob('process.json'))],
        links=[read(p) for p in sorted((W / 'link' / name).rglob('process.json'))])
    assert all(p['state'] == 'TERMINAL' and p['exit'] == 0 and not p['timed_out'] for p in builds[name]['compiles'] + builds[name]['links'])
for item in plan['retained']:
    b.exact(item)
attempts = {str(p.parent.relative_to(W)): read(p) for p in sorted((W / 'runs').rglob('process.json'))}
failed = [name for name, p in attempts.items() if p['exit'] != 0 or p['timed_out']]
assert failed == ['runs/runner-cpu/attempt1'] or failed == ['runs\\runner-cpu\\attempt1'], failed
assert 'owned bindings require prepare_resources or factory.resources' in (W / 'runs/runner-cpu/attempt1/stdout.log').read_text(encoding='utf-8')
source_names = ['tests/compute_models/model_graph_run.h', 'tests/compute_models/model_graph_run_test.cc',
    'tests/compute_models/dspark_native_consumer.h', 'tests/compute_models/dspark_pro_mtp_state_consumer_test.cc',
    'tests/compute_models/glm_pro_mtp_state_consumer_test.cc', 'tests/graph_route_cpu/CMakeLists.txt',
    'engine/inference/commit_observation.h', 'engine/inference/request_progress.h',
    'engine/inference/evaluation_failure.h', 'engine/inference/retirement_observation.h']
save(W / 'reuse.json', dict(schema='hyle.multimodel-observation.reuse.v1', current_qwen_link_base=plan['base'],
    units={name: dict(compile=unit['compile'], link=unit['link'], receipt=pin(W / 'compile' / name / 'receipt.json'))
        for name, unit in plan['units'].items()},
    note='Unchanged original 227 SDK inputs. Retain the three current consumer objects; older GLM object with the previous shared-header identity is obsolete.'))
archive = R / 'docs/evidence/correctness/inference-multimodel-observation-2026-10-29.zip'
files = set()
for pattern in ['*.py', 'parent-model-source.cc', 'plan.json', 'reuse.json', 'compile/**/*.json', 'compile/**/*.log',
    'compile/**/consumer.cc', 'compile/**/model_graph_run.h', 'compile/**/dspark_native_consumer.h',
    'link/**/*.json', 'link/**/*.log', 'runs/**/*.json', 'runs/**/*.log', 'runs/**/*.xml',
    'cleanup-*.json', 'cleanup.ps1']:
    files.update(W.glob(pattern))
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(files):
        z.write(path, str(path.relative_to(W)).replace('\\', '/'))
    for name in source_names:
        z.write(R / name, 'source/' + name)
report = dict(schema='hyle.correctness.multimodel-observation.v1', date='2026-10-29',
    status='PASS_WITH_PRESERVED_FIXTURE_REJECTION',
    base_commit=plan['worktree_base_commit'],
    changes=[
        'Original formal Pro/Flash stochastic prefix and ordinary continuation share PreparedRecordCommit/RequestProgress observation, cold real multi-token storage, pre-publication complete host preflight and observation-only late failure retry.',
        'Result records contain only actual emitted tokens, scalar Boundary and SamplingCursor; they do not own StateVersion/StateIdentity or pin historical GPU/CPU states.',
        'DS ordinary native lifecycle now delegates to the same model_graph_run used by GLM/Kimi. Original cold ports/output facts, caller pool, integral completed counter and expert ownership remain in their original owners.',
        'Status errors carry EvaluationFailure with existing WithContext preserving status code/native detail. Original exception is rethrown after separate original Invocation cleanup/retirement observation; foreign binder exceptions retain their own type.',
        'Drain is limited to actual in-flight or accepted-unobserved work. An idle retained-source reset refusal does not close the slot or grant permission release.'],
    counts=dict(CXX_attempts=sum(len(v['compiles']) for v in builds.values()),
        links=sum(len(v['links']) for v in builds.values()), current_consumer_TUs=3,
        retained_SDK_inputs=227, SDK_CXX=0, NVCC=0, full_builds=0, downloads=0,
        native_attempt_processes=len(attempts), current_passed_processes=4, current_passed_GTests=6,
        preserved_failed_fixture_processes=1, earlier_passed_runner_revision=1),
    builds=builds, cases=cases, previous_numeric_comparisons=comparisons, attempts=attempts,
    historical_comparison_note='The Oct24 records are historical, not a paired fresh baseline. Pro keeps its prior numeric facts except the older state-budget value. The older Flash record ran four rounds; the current parent already includes the threshold round and five publications (parent-model-source.cc preserves it), so its work/counter differences are not attributed to this slice. State-budget/peak differences are retained, not claimed as measured memory changes from this slice. The current state-budget formula and model Graph call sequence are unchanged by this slice. GLM numeric facts match the previous current-SDK RequestLoop run.',
    fixture_correction='First runner process used new test Invocations without the original owned ResourceOptions declaration. All three cases were refused at bind, before their intended scenario. Added the declaration at initial/fresh slot creation only; product Graph and expected failure/recovery checks unchanged. Then enhanced the third existing test with actual retained GraphOutput/Lease/Completion cleanup refusal and reran only that small runner TU.',
    boundaries=[
        'Pro and formal Flash real source roles, finite initial history/upstream fixture and 31-member complete state; no arbitrary prompt, complete large-model generation, task quality, acceptance rate or throughput claim.',
        'Only the two named CPU DS cases ran. No new CUDA stochastic DS case, compressed GGUF/BF16 sidecar observation journey or multi-GPU implementation is certified.',
        'CPU checked Gather produces a real task OutOfRange failure; this is not injected CUDA/driver failure. Machine native detail preservation uses existing Status.WithContext, not a new Status representation.',
        'CPU and CUDA libraries coexist in the reused SDK closure. CPU cases do not prove a pure CPU-only distribution package.',
        'GLM CUDA repeated the original finite RequestLoop/component case with the current shared runner. Kimi shared-header usage is source-reviewed, not a newly run Kimi consumer.',
        'Native processes overlapped for correctness verification. Their wall times are not performance measurements.',
        'Current DS acquisitions report zero missing frontiers. Cached expert subsets are not claimed to cover the complete expert domain; WAIT_FOR_EXPERTS remains0 and no download helper was run.',
        'CMake test registration is source-reviewed; listed consumers were incrementally compiled/linked, without full CMake reconfigure, full SDK build or CI.'],
    sources=[pin(R / name) for name in source_names], archive=pin(archive))
if (W / 'cleanup-result.json').exists():
    report['cleanup'] = read(W / 'cleanup-result.json')
save(R / 'docs/evidence/correctness/inference-multimodel-observation-2026-10-29.json', report)
print('Recorded four current finite processes / six tests; numeric baseline fields:',
    {name: value['compared_numeric_fields'] for name, value in comparisons.items()}, 'archive bytes', archive.stat().st_size)
