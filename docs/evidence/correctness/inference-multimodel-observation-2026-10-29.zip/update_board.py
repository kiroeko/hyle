from pathlib import Path
path=Path(__file__).resolve().parents[2]/'docs/developer/inference-progress.md'
with path.open(encoding='utf-8',newline='') as f:text=f.read()
start=text.index('本批[执行槽检查]')
end=text.index('## 最近完整性能对照',start)
note=('最近交付：[多模型提交与错误接入](../evidence/correctness/inference-multimodel-observation-2026-10-29.json)。\r\n'
      '四个当前有限进程、六项测试通过；含DeepSeek Pro／正式Flash原角色、GLM CUDA及真实CPU错误／恢复。\r\n'
      '新夹具首次资源声明遗漏已修并保留；无SDK重编、下载或吞吐刷新。此前交付依据保留在[工程计划](../implementation/inference-roadmap.md)及所属证据。\r\n\r\n')
with path.open('w',encoding='utf-8',newline='') as f:f.write(text[:start]+note+text[end:])
