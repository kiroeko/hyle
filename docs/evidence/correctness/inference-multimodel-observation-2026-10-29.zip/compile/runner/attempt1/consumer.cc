#include <gtest/gtest.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>

#include "model_graph_run.h"
#include "hyle/compute/providers/native.h"
#include "hyle/graph/cpu.h"

namespace {
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
namespace i=hyle::inference;
namespace run=model_graph_run;

struct System final {m::MemoryResourceRef ref() const noexcept {return m::system_resource();}};

// Ordinary public CPU Graph, original Invocation, real caller-owned pool and
// ready input leases. The checked native Gather provides an actual task error.
struct Program final {
  c::Context context=g::cpu::create_context({.native_threads=1}).value();
  c::StorageOwner owner=c::StorageOwner::adopt(context,System{}).value();
  c::Queue queue=context.create_queue().value();
  g::Graph graph;
  g::CompiledGraph compiled;
  c::LeasePool outputs=c::LeasePool::create(owner.ref(),256,{.max_blocks=1}).value();
  std::array<run::Port,2> input_ports;
  std::array<run::OutputPort,1> output_ports;
  std::array<c::ReadLease,2> inputs;
  g::Invocation invocation;
  int completed=0;

  template<class T,std::size_t Count>
  c::ReadLease input(const std::array<T,Count> &values) {
    const auto payload=std::as_bytes(std::span(values));
    auto backing=m::Buffer::create(owner.ref(),payload.size(),256).value();
    if(auto status=backing.view().write(payload);!status.ok())
      throw std::runtime_error(std::string(status.message()));
    return owner.adopt_buffer(std::move(backing)).value();
  }

  Program() {
    const auto data=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,2>{3,2}).value();
    const auto index=c::TensorDesc::dense(c::DataType::kInt32,std::array<std::int64_t,1>{1}).value();
    auto builder=g::GraphBuilder::create().value();
    const auto source=builder.input(data).value(),ids=builder.input(index).value();
    const auto node=builder.add_node(c::Operation(c::Gather{0,c::IndexBoundsPolicy::kChecked}),
        std::array{source,ids}).value();
    const auto selected=builder.result(node).value();
    if(auto status=builder.publish(selected);!status.ok())throw std::runtime_error(std::string(status.message()));
    graph=std::move(builder).finish().value();
    const std::array required{g::NodeProviderConstraint{node,c::native::kProviderId}};
    compiled=g::cpu::compile(graph,context,{.node_providers=required}).value();
    invocation=compiled.executable.create_invocation().value();
    input_ports={run::Port{source,data},run::Port{ids,index}};
    output_ports={run::prepare_output(compiled,{selected,graph.value_description(selected).value()})};
    inputs={input(std::array<float,6>{1,2,3,4,5,6}),input(std::array<std::int32_t,1>{1})};
  }

  std::array<float,2> values(const c::ReadLease &output) {
    std::array<float,2> result;
    if(auto status=output.view().value().read(std::as_writable_bytes(std::span(result)));!status.ok())
      throw std::runtime_error(std::string(status.message()));
    return result;
  }
};

TEST(ModelGraphRun, PoolRefusalRetainsTypedStatusAndSameInvocationCanRecover) {
  Program program;
  auto occupied=program.outputs.allocate(8).value();
  i::RetirementObservation cleanup;
  bool caught=false;
  try {
    (void)run::execute(program.invocation,program.outputs,program.queue,program.input_ports,program.inputs,
        program.output_ports,program.completed,{},{},&cleanup);
    FAIL()<<"the actual output pool is occupied";
  } catch(const i::EvaluationFailure &failure) {
    caught=true;
    EXPECT_TRUE(failure.status().IsResourceExhausted());
    EXPECT_NE(failure.status().message().find("ordinary model Graph output writer"),std::string::npos);
    EXPECT_FALSE(failure.status().has_native_error());
    EXPECT_TRUE(failure.retirement_observed());EXPECT_TRUE(failure.retirement().retired);
    EXPECT_TRUE(failure.retirement().status.ok());
  }
  ASSERT_TRUE(caught);EXPECT_TRUE(cleanup.retired);EXPECT_TRUE(cleanup.status.ok());
  EXPECT_FALSE(program.invocation.in_flight());EXPECT_EQ(program.completed,0);
  EXPECT_FALSE(program.invocation.result(program.output_ports[0].value));
  EXPECT_EQ(program.outputs.stats().active_uses,0u);
  occupied.reset();
  const auto result=run::execute(program.invocation,program.outputs,program.queue,program.input_ports,
      program.inputs,program.output_ports,program.completed);
  ASSERT_EQ(result.size(),1u);EXPECT_EQ(program.completed,1);
  EXPECT_EQ(program.values(result[0]),(std::array<float,2>{3,4}));
}

TEST(ModelGraphRun, CheckedGatherErrorKeepsFailedSlotTerminalAndFreshInvocationSucceeds) {
  Program program;program.inputs[1]=program.input(std::array<std::int32_t,1>{3});
  i::RetirementObservation cleanup;
  bool caught=false;
  try {
    (void)run::execute(program.invocation,program.outputs,program.queue,program.input_ports,program.inputs,
        program.output_ports,program.completed,{},{},&cleanup);
    FAIL()<<"checked Gather must reject the actual out-of-range index";
  } catch(const i::EvaluationFailure &failure) {
    caught=true;EXPECT_TRUE(failure.status().IsOutOfRange());EXPECT_FALSE(failure.status().has_native_error());
    const auto message=failure.status().message();
    EXPECT_TRUE(message.find("ordinary model Graph submit")!=std::string::npos||
        message.find("ordinary model Graph retirement")!=std::string::npos);
    EXPECT_TRUE(failure.retirement_observed());EXPECT_TRUE(failure.retirement().retired);
    EXPECT_EQ(failure.retirement().status,cleanup.status);
  }
  ASSERT_TRUE(caught);EXPECT_TRUE(cleanup.retired);EXPECT_FALSE(program.invocation.in_flight());
  EXPECT_EQ(program.completed,0);EXPECT_FALSE(program.invocation.result(program.output_ports[0].value));
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&program.queue}};
  EXPECT_TRUE(program.invocation.reset().IsFailedPrecondition());
  const auto rejected=program.invocation.submit(queues);ASSERT_FALSE(rejected);
  EXPECT_TRUE(rejected.error().IsFailedPrecondition());
  // Native retirement does not turn a failed Invocation into a reusable slot.
  // Drop that original owner before reusing its caller-owned output capacity.
  program.invocation={};
  auto fresh=program.compiled.executable.create_invocation().value();
  program.inputs[1]=program.input(std::array<std::int32_t,1>{1});
  const auto result=run::execute(fresh,program.outputs,program.queue,program.input_ports,program.inputs,
      program.output_ports,program.completed);
  ASSERT_EQ(result.size(),1u);EXPECT_EQ(program.completed,1);
  EXPECT_EQ(program.values(result[0]),(std::array<float,2>{3,4}));
}

TEST(ModelGraphRun, ExternalBinderPreservesItsOwnExceptionAndReportsActualCleanup) {
  struct BinderFailure final {int marker;};
  Program program;i::RetirementObservation cleanup;std::size_t calls=0;
  const std::array external{std::size_t{1}};
  bool caught=false;
  try {
    (void)run::execute(program.invocation,program.outputs,program.queue,program.input_ports,program.inputs,
        program.output_ports,program.completed,external,[&](g::Invocation &original) {
          EXPECT_EQ(&original,&program.invocation);++calls;throw BinderFailure{19};
        },&cleanup);
    FAIL()<<"external binder exception must not become an EvaluationFailure";
  } catch(const BinderFailure &failure) {caught=true;EXPECT_EQ(failure.marker,19);}
  ASSERT_TRUE(caught);EXPECT_EQ(calls,1u);EXPECT_TRUE(cleanup.retired);EXPECT_TRUE(cleanup.status.ok());
  EXPECT_FALSE(program.invocation.in_flight());EXPECT_EQ(program.completed,0);
  EXPECT_FALSE(program.invocation.result(program.output_ports[0].value));
  EXPECT_EQ(program.outputs.stats().live_blocks,0u);
  const auto result=run::execute(program.invocation,program.outputs,program.queue,program.input_ports,
      program.inputs,program.output_ports,program.completed);
  ASSERT_EQ(result.size(),1u);EXPECT_EQ(program.completed,1);
  EXPECT_EQ(program.values(result[0]),(std::array<float,2>{3,4}));
}
} // namespace
