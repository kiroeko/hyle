# 冷形状、真实分块与预热：最小实施建议

仅 Windows 当前源码及本地参考源码审查；没有构建、执行、下载或产品修改。本文不是完成声明，也不预言性能收益。

## 当前真实能力

- `engine/models/qwen35/main.cc:2144–2220,2559–2584`：一个符号 Family 显式编译有限 exact T 子计划；键还区分 B、role、completion、sampling。不是把任何 T 自动映射到较大 T 的执行桶。
- `main.cc:2650–2688`：未知普通/MTP-prefill 后缀可在 idle、未借 carrier 时冷接纳；受原 query/state 容量约束。额外 exact 家族数量当前为 resident_sessions × active_sequences，FIFO 淘汰且先 drain 原 Invocation；已有初始 Family 不属于该 FIFO。失败不假称新形状可用；这不是 LRU，也不是无限缓存。
- `main.cc:3657–3672`：`prepare_execution` 可预建已知或新接纳 exact shape 的 Phase/载体；`initialize_slot` 从3460开始。它不提交真实输入，不能声称完成设备执行预热或全部 capture：动态 state/layout 权限绑定后的 `prepare_replay` 仍在4071。
- `prepare_generation_call(...,max_prefill_rows)`（5460–5601）、`TextCompletion::kStateOnly`、提交 ledger 和 `generation_record_capacity`（4954）已有真实分块。中间块消费真实 token，提交 KV/history/GDN/head，不输出/不抽样；只有最后块产生首输出。`tests/tools/qwen_chunked_prefill_case.h` 使用 Q64 并检查中间块 RNG、取消、partial rebuild 和真实 GDN/carry 摘要。该测试源码存在不等于本次又运行通过。
- 正式自然生成入口尚未接通这项政策：6146 仍以 SIZE_MAX 计算 ledger，6265 调用使用默认无限块长；CLI help/parser（6438起）没有 prefill-chunk、shape-list 或 warmup 选项。普通单次 evaluate 路径也未因此自动分块。
- `dispatch_batches` 已统一索引遍历，调用方6270–6275仍要求同 role/completion/sampling、同 T；Model3847拒不等长输入。因此 B>1 是 equal-T 实际物理合批，异长请求目前分组/串行，不是全模型 varlen。

## A ≤ R ≤ C 的准确边界

这里 A=布局的真实 query_rows，R=选中 Graph Q/output 的实际 extent，C=BatchSchema 上限；B另指请求数，不能把 R 与 active_sequences 混用。

- `src/graph_batch/native_batch_regions.cc:18,35–38,59–65`、`batch.cc:448–457`、`src/compute_batch/batch_execution.cc:307–330` 已检查 A≤R≤C。某些 owned-layout/paged-program 形式还明确要求 A=R；不能放松这些门来接大桶。
- 这是 attention/batch 端口的合同，不是任意 Graph 算子自动认识 active length。当前 Qwen token/position/projection 是实际 B×T，GDN/conv 仍执行统一 T，最后行选择和状态 Store 也按 T/K 描述。
- 因此仅把 T 补到某个 R、只给 attention 写正确 query_indptr，仍会让递归层消费假 token、写错 history/末态/候选前缀。现有 indexed GDN/conv 的原池地址优化没有增加 per-request length 数学语义。

## 推荐实施顺序

1. **先接通真实 ordinary prefill 分块。** 给自然生成入口增加一个正的 `prefill_chunk_tokens` 政策，CLI 一个 `--prefill-chunk-tokens N` 参数即可。规划、ledger 容量、`max_query_rows`、实际 `prepare_generation_call` 都取同一份政策。中间块用原 StateOnly，最终块 EmitNext；每块之后仍回到原 RequestLoop，不能内部连续吃完整 prompt 导致 ready decode 饥饿。
2. **有限长度集合通过分解真实输入实现，不伪装 ceiling padding。** 首批可仅 Q + exact 尾长，复用已有 bounded exact admission。若要进一步减少尾长种类，在一个很小的纯政策 helper 中定义 `next_rows(remaining)`，从有限偏好集合选不超过真实 remaining 的块；保证包含1、正进展、每块受 token/context/query-budget 约束。可用按2分解尾部作为明确可选算法，不能把额外小块的成本隐去。各请求 independently 选真实 T 后复用 equal-T dispatch；末块和中间块 completion 不同仍分别合批。不要为此新增执行器。
3. **统一冷准备清单和运行时选择。** 同一 helper 同时给冷 planner、实际下一块和 ledger count 使用；不要一套公式预热、另一套公式执行。初始输入/后续 turn 的真实 pending 行、prefix hit 后 remaining、StateOnly/EmitNext、B 和 sampling 都进入 exact key。unknown suffix 可按同政策分块后命中有限清单；保留 idle exact 接纳作为未预知形状的真实 fallback，仍记录耗时/淘汰。不将已知 execute plan 数量误当实际执行次数。
4. **显式预热，区分准备与执行。** 最小先提供 `--warmup none|prepare`：none 仅表示不额外预热，不跳过必要的 Family 编译；prepare 只调用同清单的 `prepare_execution`，完成时才宣布 ready，报告 prepared/cold-admitted shape 数和时间。不能声称已有 capture/device warmup。若确需 `execute`，在同 Model、同真实接口上用可退休的一次性 Session/候选执行明确形状，wait/清理原事务，且不入用户 prefix/cache、不推进用户 RNG/ledger；将执行与准备分别计时、计入内存和 replay-use 规划。不得拿旧全零图替代真实状态路径。
5. **只有需要全模型 varlen/ceiling buckets 时再扩 active-length。** 要同时表达真实每请求 query boundaries、per-request last real row、conv/history写入、GDN递归终点、MTP各候选接受前缀及 inactive 行无 Store；每个 selected provider 必须承载或自然拆回现有等长真实子块。不能用当前 attention 的 A≤R≤C 资格代签这些功能。此为独立未完成能力，不能把第2步真实分块称作已经实现全模型 padding replay。

## 最小文件及责任边界

- 可新增 `engine/inference/prefill_policy.h`：仅正整数块选择/有限形状枚举与计数；冷 planner 和实际消费者是两个真实调用者。没有 provider、Graph、Session、资源或回调执行器。若首批只一个 Q，可先原文件窄接线，不强造抽象。
- `engine/models/qwen35/main.cc`：CLI、真实输入分解、冷 Family/Phase 清单、ledger 容量、调用政策和报告；Model 保持 exact B/T 验证和原成功/失败发布。自然生成已在6747–6751汇入同一入口；teacher-forced固定工作量/诊断入口若暂不适用新政策，应显式拒绝组合，不能静默忽略，也不应重写其原测量窗口。MTP 当前明确拒有限 prefill 量子（5475），第一批应清楚拒该组合，不能默默退回无限块长或假称已支持；后续扩 MTP-prefill 必须同时保存 draft lag/carry/replay 真合同。
- `engine/inference/request_loop.h`：现有 request/turn/retirement/credit owner；原则上不必修改。它不关心模型 shape 或 kernel。`dispatch_batches` 也不需改。
- `admit_exact_shape` 原 owner 保持 idle drain/淘汰；若要独立配置额外 shape 数，把其现有 count limit 变成清晰政策，复用原 execution ResourceBudget，不另建缓存/预算管理器。初始 finite Family 与额外 exact FIFO 的统计要区分。
- Compute/Graph：第一批无需改 API/ABI、算子、provider 资格或 A≤R≤C 合同。真正 varlen 再另做跨层实际合同，不能只加统一 active_count scalar。
- 测试扩既有 `qwen_chunked_prefill_case.h` 及真实 CLI 消费者：未知尾长、B>1同 T子块、不同总长度、多轮 pending、prefix partial/full hit、取消/重建和输出背压；有限覆盖，不扩全平台/模型矩阵。整数政策只测分解完整性/边界，不写镜像实现测试。不同 GEMM T 可能有数值舍入差异，不能把逐位同输出作为未经论证的通用保证。

## 本地参考及可借鉴点

- llama.cpp HEAD `23b0202a189c44a54625aadcb37a946dd1d6278d`，所读文件与 HEAD 逐字相同。`src/llama-batch.cpp:585–616,619–732` 区分 simple 与 equal-sequence microbatch、受 n_ubatch 限制，借鉴真实物理切分而非虚拟 token。`common/common.cpp:1489–1529` 真正执行 warmup 后清 memory、synchronize、reset perf/sampler；这正说明 prepare-only 不应冒称执行预热。
- vLLM HEAD `276fbcff2717bd934cfa37c8a2e4c391f3e7237b`，所读文件与 HEAD 相同。`vllm/v1/core/sched/scheduler.py:692–709` 以真实 remaining/token budget切块；`v1/cudagraph_dispatcher.py:71–107,130–154,272–320` 对有限 capture key 做 ceiling/模式资格和 NONE fallback。更关键 `v1/attention/backends/gdn_attn.py:537–598` 给 GDN 单独保 per-request状态/query边界、NULL_BLOCK_ID、序列mask，而非把 token padding当真实递归长度。
- TensorRT-LLM HEAD `46d9966b54d9d11998b712e732fb20f64d4d35c0`。工作树索引为对应文件 staged-deleted + untracked 重现，不能称仓库 clean；本次实际读的 `engine/cuda_graph.py` 和 `cuda_graph_runner.py` 均与 HEAD 逐字相同。前者30–118显式筛 batch/token/seq桶与预算，后者1311–1324通过受资源管理的一次性 dummy requests补 Graph-compatible batch，退出撤回这些请求。可借“物理执行桶、真实请求、资源限额分离”，不能直接照搬 dummy rows给 Hyle 原 GDN执行真长度。

## 首批应验收什么

有限政策与实际分块一致、没有漏/重复token/多抽样、真实状态与取消/恢复合同正确、warmup准备范围如实可观察，且冷接纳/淘汰仍有界。只有完整同窗消费者才能判断额外块是否划算；本次没有运行或速度结论。
