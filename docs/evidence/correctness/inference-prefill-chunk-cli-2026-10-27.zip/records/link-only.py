"""Resume after directory bookkeeping failure; reuse the successful Model object."""
from pathlib import Path
import importlib.util
import os
import json
import sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cli_build',W/'build.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
b,m=s.b,s.m
assert not (W/'ready.json').exists()
plan=b.read(W/'plan.json')
for x in b.read(W/'source-freeze.json'):b.exact(x)
retained=b.read(W/'retained-inputs.json')
for x in retained:b.exact(x)
process=b.read(W/'compile/process.json')
assert process['exit']==0
command=b.read(W/'compile-plan.json')['command'];helper=b.helper()
env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
linked=helper.execute(b.read(W/'link-plan.json')['command'],env,W/'link-process',timeout=120)
image=W/'link/hyle.exe'
b.save(W/'link-inputs.json',retained+[b.pin(W/'compile/unit.obj')])
baseline=b.read(s.B/'formal3-ready.json');runtime=b.read(baseline['runtime']['path'])
native=runtime['native_cpu'];b.exact(native)
alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
runtime['native_cpu_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH']
b.save(W/'runtime.json',runtime)
b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),source=plan['source'],object=b.pin(W/'compile/unit.obj'),
    actual_dependencies=b.pin(W/'compile/actual-dependencies.json'),compile=process,link=linked,
    inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json'),
    adaptation='Initial successful compile reused; original link was never started because log directory existed. Only resume link logs moved to link-process.'))
print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
