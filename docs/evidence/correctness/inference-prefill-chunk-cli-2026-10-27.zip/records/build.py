"""Explicit one-TU CUDA CLI rebuild from retained formal3; no model execution."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[2]
B = R / '.scratch/inference-engine-slot-state-20261027'
spec = importlib.util.spec_from_file_location('retained_build', R / '.scratch/inference-batched-slot-controls-20261027/build.py')
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
b, m = old.helpers()


def main():
    assert sys.argv[1:] == ['build'] and not (W / 'plan.json').exists()
    source = R / 'engine/models/qwen35/main.cc'
    assert b.pin(source)['sha256'] == '2709af3dc68494634b106cc2d0b7bce6efcde0de4ff023838a6f10080b469a42'
    ready = b.read(B / 'formal3-ready.json')
    retained = [row for row in b.read(ready['inputs']['path']) if b.key(row['path']) != b.key(ready['object']['path'])]
    assert len(retained) == 223
    out = W / 'compile'
    command = m.command(B / 'compile3/formal-cuda/command.json', source, out)
    b.save(W / 'compile-plan.json', dict(command=command, cwd=str(R), timeout_seconds=180))
    frozen = m.c.closure([source], [W / 'compile-plan.json'])
    b.save(W / 'source-freeze.json', frozen)
    (W / 'main.cc').write_bytes(source.read_bytes())
    image = W / 'link/hyle.exe'
    link, replaced = [], 0
    for arg in b.read(B / 'formal3-link/command.json')['command']:
        if b.key(arg) == b.key(ready['object']['path']):
            arg = str(out / 'unit.obj'); replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:' + str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        link.append(arg)
    assert replaced == 1
    b.save(W / 'link-plan.json', dict(command=link, cwd=str(R), timeout_seconds=120))
    b.save(W / 'retained-inputs.json', retained)
    b.save(W / 'plan.json', dict(baseline=b.pin(B / 'formal3-ready.json'), source=b.pin(source),
        source_snapshot=b.pin(W / 'main.cc'), source_freeze=b.pin(W / 'source-freeze.json'),
        compile=b.pin(W / 'compile-plan.json'), link=b.pin(W / 'link-plan.json'), retained_inputs=b.pin(W / 'retained-inputs.json'),
        counts=dict(CXX_TUs=1, reused_inputs=223, SDK=0, NVCC=0, weights=0, report=0, downloads=0)))
    helper = b.helper()
    env = helper.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':command[0], 'CMAKE_CXX_COMPILER':command[0], 'CMAKE_GENERATOR':'Ninja'}, backends=()).env
    process = helper.execute(command, env, out, timeout=180)
    dep = b.read(out / 'dependencies.json')['Data']
    actual = [b.pin(path) for path in dict.fromkeys([dep['Source'], *dep['Includes']])]
    b.save(out / 'actual-dependencies.json', actual)
    own = {b.key(x['path']):x for x in frozen}
    for x in actual:
        path = Path(x['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
            assert own[b.key(path)]['sha256'] == x['sha256'], str(path)
    for row in frozen: b.exact(row)
    for row in retained: b.exact(row)
    image.parent.mkdir(parents=True, exist_ok=True)
    linked = helper.execute(link, env, W / 'link', timeout=120)
    b.save(W / 'link-inputs.json', retained + [b.pin(out / 'unit.obj')])
    runtime = b.read(ready['runtime']['path'])
    native = runtime['native_cpu']; b.exact(native)
    alias = image.parent / Path(native['path']).name
    os.link(native['path'], alias)
    runtime['native_cpu_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(W / 'runtime.json', runtime)
    b.save(W / 'ready.json', dict(status='BUILT_NOT_RUN', image=b.pin(image), source=b.pin(source),
        object=b.pin(out / 'unit.obj'), actual_dependencies=b.pin(out / 'actual-dependencies.json'),
        compile=process, link=linked, inputs=b.pin(W / 'link-inputs.json'), runtime=b.pin(W / 'runtime.json'), plan=b.pin(W / 'plan.json')))
    print('READY', json.dumps(b.pin(W / 'ready.json')), flush=True)


if __name__ == '__main__':
    try: main()
    except BaseException:
        b.save(W / 'build-failure.json', dict(error=traceback.format_exc(), no_retry=True))
        raise
