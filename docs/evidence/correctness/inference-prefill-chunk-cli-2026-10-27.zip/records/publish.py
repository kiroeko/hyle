"""Offline archive of the completed, bounded prefill CLI batch; never imports a runner."""
from pathlib import Path
import hashlib
import json
import zipfile

W=Path(__file__).resolve().parent
R=W.parents[2]
STEM='inference-prefill-chunk-cli-2026-10-27'


def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return dict(path=str(Path(p).resolve()),**digest(Path(p).read_bytes()))
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')


def ledger_check():
    plan=read(W/'run-plan2.json');result=[]
    for case in plan['commands']:
        report=read(W/'runs2'/case['name']/'report.json')
        for session in report['sessions']:
            name=session['session_id'];previous_pending=None;checked=0;turns=[]
            for index,expected in enumerate(case['expected_turns'][name],1):
                rows=[x for x in session['ledger'] if x['turn']==index]
                prompt=expected['prompt'] if index==1 else [previous_pending,*expected['prompt']]
                position=0;blocks=[]
                for row in rows:
                    if row['generation']:
                        ids=[row['before_next_id']]
                        assert row['input_rows']==1 and row['first_input']==ids[0]
                    else:
                        ids=prompt[position:position+row['input_rows']];position+=len(ids)
                        assert len(ids)==row['input_rows'] and row['first_input']==ids[0]
                        blocks.append(dict(rows=len(ids),imported=row['imported'],no_output=row['next_id']==-1))
                    value=1469598103934665603
                    for token in ids:value=((value^token)*1099511628211)&((1<<64)-1)
                    assert row['input_hash']==value
                    checked+=1
                assert position==len(prompt)
                previous_pending=rows[-1]['next_id']
                actual_turn=session['result']['turns'][index-1]
                assert actual_turn['input_ids']==prompt
                assert actual_turn['output_end']-actual_turn['output_begin']==expected['quota']
                turns.append(dict(turn=index,true_prompt_rows=len(prompt),blocks=blocks,pending_once=index>1))
            result.append(dict(case=case['name'],session=name,checked_ledger_records=checked,turns=turns))
    return dict(status='PASS_OFFLINE_INPUT_AND_LEDGER_HASH_CHECK',results=result,
        scope='Every committed input row represented in each printed ledger, including imported prefixes, is checked against original tiny request inputs and actual preceding pending IDs. This is not a hidden-state byte oracle or cross-chunk numerical/quality comparison.')


def main():
    target=R/'docs/evidence/correctness'
    output,archive=(target/(STEM+ext) for ext in ('.json','.zip'))
    assert not output.exists() and not archive.exists()
    ready,summary,review=read(W/'ready.json'),read(W/'summary2.json'),read(W/'cold-plan-review.json')
    assert ready['source']['sha256']=='2709af3dc68494634b106cc2d0b7bce6efcde0de4ff023838a6f10080b469a42'
    assert ready['image']['sha256']=='217bad1bb6eb6bc1412fa093eb33fabb5f2f2d352c6b76491af4ac74a5541b59'
    assert summary['status']=='THREE_REAL_CLI_AND_THREE_PARSER_CASES_PASS'
    assert ready['compile']['exit']==ready['link']['exit']==0 and len(read(W/'retained-inputs.json'))==223
    assert pin(W/'main.cc')['sha256']==ready['source']['sha256']
    results=[]
    for item in summary['completed']:
        p=item['process'];expected=1 if item['name'].startswith('parser-') else 0
        assert p['exit']==expected
        results.append(dict(name=item['name'],pid=p['pid'],exit=p['exit'],kind='pre_Model_parser_refusal' if expected else 'actual_tiny_CUDA_inference'))
    first=read(W/'runs/single/process.json');assert first['exit']==1
    offline=ledger_check();save(W/'offline-ledger-check.json',offline)
    facts={name:read(W/'runs2'/name/'facts.json')['facts'] for name in ('single','b2-multiturn','prefix-evict')}
    report=dict(status='PASS_BOUNDED_ORDINARY_PREFILL_CLI',date='2026-10-27',source=ready['source'],source_snapshot=pin(W/'main.cc'),
        image=ready['image'],ready=pin(W/'ready.json'),actual_dependencies=pin(W/'compile/actual-dependencies.json'),
        reuse=dict(retained_inputs=223,record=pin(W/'retained-inputs.json'),baseline=read(W/'plan.json')['baseline'],
            scope='All retained223 link inputs unchanged; only current main Model TU recompiled. No SDK, weights, report, native/NVCC or third-party rebuild.'),
        counts=dict(CXX_compile_processes=1,link_processes=1,successful_real_CUDA_inference_processes=3,
            parser_refusal_processes=3,recipe_capacity_refusal_processes=1,total_native_CLI_processes=7,
            Python_bookkeeping_failure_before_link=1,SDK_builds=0,NVCC=0,downloads=0,model_payload_copies=0),
        builds=dict(compile=ready['compile'],link=ready['link']),completed=results,
        first_capacity_refusal=dict(pid=first['pid'],exit=first['exit'],record=pin(W/'runs/single/process.json'),
            scope='Original recipe --capacity32 exceeded unchanged tiny fixture maximum16. Metadata preparation occurred, but Model was not constructed and no inference was performed; corrected recipe uses16 without a new build, fixture, seed or token input.'),
        results=facts,source_review=review['review'],offline_ledger_check=pin(W/'offline-ledger-check.json'),
        setup_failures=review['retained_setup_failures'],
        design_reference=dict(file=pin(W.parent/'design.md'),scope='Read-only local design study preceding this patch; explanatory reference, not project instructions or an instruction to execute its future recommendations.'),
        boundary=['Ordinary natural generation only. Finite Q with MTP/fixed replay and zero are explicitly rejected before Model construction.',
            'Actual token chunks; no whole-model varlen, fake padding, preferred ceiling-bucket policy or device execution warmup/capture claim.',
            'Tiny cached untrained GA weights, original math/seed and real public CLI. Not task quality, cross-chunk-width bitwise equivalence, speed, memory peak, complete model/backend matrix or all-state byte correctness.',
            'Prefix case ends with one intentionally retained directory version within N1; not asserted zero or treated as a leak. Original failures and corrected recipe scope are retained.',
            'All three real journeys used only preplanned exact shapes: cold_exact_admissions=0 and cold_exact_evictions=0. Broader unknown-shape eviction and warmup are outside this test.'])
    members,origins={},{}
    def add(name,p):
        p=Path(p);assert name not in members and p.is_file()
        assert p.suffix.lower() in {'.py','.json','.cc','.md','.log','.ids','.schedule','.tsv'}
        members[name]=p.read_bytes();origins[name]=str(p.resolve())
    for p in sorted(W.iterdir()):
        if p.is_file() and p.suffix.lower() in {'.py','.json','.cc'}:add('records/'+p.name,p)
    add('reference/read-only-design.md',W.parent/'design.md')
    add('baseline/formal3-ready.json',R/'.scratch/inference-engine-slot-state-20261027/formal3-ready.json')
    # Enumerate only this finite batch's named folders; no SDK/tree walk.
    for name in ('compile','link-process','inputs','cases','runs','runs2','parser2'):
        for p in sorted((W/name).rglob('*')):
            if p.is_file() and p.suffix.lower() in {'.py','.json','.log','.ids','.schedule','.tsv'}:
                add('records/'+p.relative_to(W).as_posix(),p)
    index=dict(members=[dict(member=n,original_path=origins[n],**digest(raw)) for n,raw in sorted(members.items())],
        exclusions='No EXE/OBJ/PDB/import/static/shared library, binary weight payload, complete SDK/source/dependency tree. weights.tsv is only the small original metadata manifest pointing to the retained payload.')
    encoded=(json.dumps(index,indent=2,ensure_ascii=False)+'\n').encode()
    target.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,raw in sorted(members.items()):z.writestr(n,raw)
        z.writestr('member-sha256.json',encoded)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist())==len(members)+1
        assert z.read('member-sha256.json')==encoded
        for n,raw in members.items():assert digest(z.read(n))==digest(raw)
    report['archive']=dict(**pin(archive),members=len(members)+1,CRC_and_member_SHA256_verified=True)
    save(output,report)
    print(json.dumps(dict(report=pin(output),archive=report['archive'],actual_counts=report['counts']),indent=2))


if __name__=='__main__':main()
