"""Three bounded real tiny CLI journeys and three parser refusals; no benchmark."""
from pathlib import Path
import importlib.util
import json
import os
import subprocess
import sys
import time
import traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[2]
spec=importlib.util.spec_from_file_location('cli_build',W/'build.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
b,m=s.b,s.m


def write(path,text):
    path.parent.mkdir(parents=True,exist_ok=True)
    assert not path.exists()
    path.write_text(text,encoding='utf-8')


def prepare():
    assert not (W/'run-plan.json').exists()
    inputs=W/'inputs';inputs.mkdir()
    original=R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    (inputs/'weights.tsv').write_bytes((original/'weights.tsv').read_bytes())
    write(inputs/'prompt.ids','1 2 3\n')
    write(inputs/'fixed.ids','4 5\n')
    cases={
        'single':{'default':[([1,2,3],3)]},
        'b2-multiturn':{'A':[([1,2,3,4,5],2),([4,5,6],2)],'B':[([1,2,3],2),([7],2)]},
        'prefix-evict':{'A':[([1,2,3],1),([4],2)],'B':[([1,2,3,4,5],1)],'C':[([1,2,3,4,5],1)]}}
    ready=b.read(W/'ready.json')
    common=[ready['image']['path'],'--inputs',str(inputs),'--backend','cuda','--capacity','32',
        '--sampling','random','--top-k','4','--seed','123','--mtp','off','--prefill-chunk-tokens','2',
        '--progress','direct','--replay','auto']
    commands=[]
    for name, schedules in cases.items():
        cmd=list(common)
        if name=='single':cmd+=['--steps','3','--max-sessions','1','--active-sequences','1','--prefix-cache','off']
        else:
            folder=W/'cases'/name
            for session,turns in schedules.items():
                lines=[]
                for i,(ids,quota) in enumerate(turns):
                    write(folder/f'{session}{i}.ids',' '.join(map(str,ids))+'\n')
                    lines += [f'prompt {session}{i}.ids',f'generate {quota}']
                write(folder/f'{session}.schedule','\n'.join(lines)+'\n')
            write(folder/'sessions.tsv','\n'.join(f'{x} {x}.schedule' for x in schedules)+'\n')
            cmd+=['--session-schedules',str(folder/'sessions.tsv'),'--max-sessions','2' if name=='b2-multiturn' else '1',
                  '--active-sequences','2' if name=='b2-multiturn' else '1','--prefix-cache','off' if name=='b2-multiturn' else 'auto']
        commands.append(dict(name=name,command=cmd,expected_turns={k:[dict(prompt=p,quota=q) for p,q in v] for k,v in schedules.items()}))
    parser=[dict(name='zero',command=[ready['image']['path'],'--inputs',str(inputs),'--prefill-chunk-tokens','0'],error='--prefill-chunk-tokens requires a positive size'),
        dict(name='mtp',command=[ready['image']['path'],'--inputs',str(inputs),'--backend','cuda','--mtp','on','--prefill-chunk-tokens','2'],error='requires ordinary natural generation'),
        dict(name='fixed',command=[ready['image']['path'],'--inputs',str(inputs),'--backend','cuda','--decode-ids',str(inputs/'fixed.ids'),'--prefill-chunk-tokens','2'],error='requires ordinary natural generation')]
    b.save(W/'run-plan.json',dict(image=ready['image'],source=ready['source'],runtime=ready['runtime'],
        prepared_manifest=b.pin(inputs/'weights.tsv'),original_manifest=b.pin(original/'weights.tsv'),cached_payload=b.pin(original/'untrained-bf16.bin'),
        commands=commands,parser_refusals=parser,real_model_processes=3,
        scope='Untrained cached tiny GA ordinary CUDA functional work, not quality, bitwise cross-chunk-width equivalence, performance or memory peak claim. No payload copied/downloaded.'))


def fnv(ids):
    out=1469598103934665603
    for x in ids:out=((out^x)*1099511628211)&((1<<64)-1)
    return out


def check_regular(raw,case):
    assert raw['backend']=='cuda' and raw['mtp'] is False
    assert raw['admitted_requests']==raw['retired_requests']==len(case['expected_turns'])
    assert raw['generated_tokens']==sum(t['quota'] for turns in case['expected_turns'].values() for t in turns)
    assert raw['live_committed_versions']<=raw['max_sessions']
    assert all(0<batch['tokens']<=2 for batch in raw['batches'])
    facts={}; cursors={}
    for session in raw['sessions']:
        name=session['session_id'];turns=case['expected_turns'][name];result=session['result'];ledger=session['ledger']
        assert not any(x['imported'] for x in ledger)
        assert result['sampling_draw_cursor']==len(result['generated_ids'])==sum(x['quota'] for x in turns)
        previous_pending=None;stateonly=0
        for index,turn in enumerate(turns,1):
            entries=[x for x in ledger if x['turn']==index];prompt=turn['prompt'] if index==1 else [previous_pending,*turn['prompt']]
            position=0
            for row in entries:
                if row['generation']:
                    assert row['input_rows']==1 and row['first_input']==row['before_next_id'] and row['input_hash']==fnv([row['before_next_id']])
                else:
                    ids=prompt[position:position+row['input_rows']];assert len(ids)==row['input_rows']
                    assert row['first_input']==ids[0] and row['input_hash']==fnv(ids)
                    if not position and index>1:assert ids[0]==row['before_next_id']==previous_pending
                    position+=len(ids)
                delta=row['sampling_draw_after']-row['sampling_draw_before']
                if row['next_id']==-1:
                    assert not row['generation'] and delta==0;stateonly+=1
                else:assert delta==1
            assert position==len(prompt)
            assert sum(x['next_id']>=0 for x in entries)==turn['quota']
            previous_pending=entries[-1]['next_id']
        facts[name]=dict(state_only_records=stateonly,rows=sum(x['input_rows'] for x in ledger),ledger_records=len(ledger),
            visible=result['visible_tokens'],draws=result['sampling_draw_cursor'],generated=result['generated_ids'])
        cursors[name]=0
    # Derive completion groups from actual no-output/draw observations, not a hidden test-only provider preference.
    sessions={s['session_id']:s['ledger'] for s in raw['sessions']}
    for batch in raw['batches']:
        observed=[]
        for i,name in enumerate(batch['session_ids']):
            row=sessions[name][cursors[name]];cursors[name]+=1
            assert row['input_rows']==batch['tokens'] and row['generation']==batch['generation']
            assert row['requests']==batch['requests'] and row['member_index']==i
            observed.append(row['next_id']==-1)
        assert len(set(observed))==1,'StateOnly/EmitNext members were mixed'
    assert all(cursors[name]==len(sessions[name]) for name in sessions)
    if case['name']=='single':
        assert facts['default']['state_only_records']==1 and facts['default']['rows']==5
        assert [x['input_rows'] for x in sessions['default']]==[2,1,1,1]
        assert raw['actual_target_rows']==5 and raw['actual_graph_calls']==4 and raw['prefill_target_rows']==3
    else:
        assert facts['A']['visible']==11 and facts['B']['visible']==7
        assert raw['actual_target_rows']==18 and raw['prefill_target_rows']==14 and raw['pending_flushed_tokens']==2
        assert any(x['requests']==2 and x['tokens']==2 and not x['generation'] for x in raw['batches'])
    assert raw['live_committed_versions']==0
    return facts


def run(attempt=1):
    plan=b.read(W/('run-plan2.json' if attempt==2 else 'run-plan.json'));ready=b.read(W/'ready.json');b.exact(ready['image']);b.exact(ready['source'])
    helper=b.helper();cl=b.read(W/'compile-plan.json')['command'][0]
    env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    env['PATH']=b.read(ready['runtime']['path'])['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    completed=[]
    for case in plan['commands']:
        folder=W/('runs2' if attempt==2 else 'runs')/case['name']
        process=helper.execute(case['command'],env,folder,timeout=90)
        raw=json.loads((folder/'stdout.log').read_text(encoding='utf-8-sig'));b.save(folder/'report.json',raw)
        if case['name']!='prefix-evict':facts=check_regular(raw,case)
        else:
            assert raw['backend']=='cuda' and raw['mtp'] is False
            assert raw['max_sessions']==raw['active_sequences']==1
            assert raw['admitted_requests']==raw['retired_requests']==3 and raw['generated_tokens']==5
            assert all(0<x['tokens']<=2 for x in raw['batches'])
            assert raw['prefix_hits']>=2 and raw['prefix_full_hits']>=1 and raw['reused_tokens']>=8
            assert raw['idle_evictions']>=1 and raw['restore_count']>=1 and raw['restored_target_rows']>=3
            a=next(x for x in raw['sessions'] if x['session_id']=='A')
            assert a['result']['visible_tokens']==6 and a['result']['generated_tokens']==3
            assert a['result']['sampling_draw_cursor']==3 and raw['live_committed_versions']<=1
            facts={k:raw[k] for k in ['prefix_hits','prefix_full_hits','reused_tokens','idle_evictions','restore_count','restored_target_rows','live_committed_versions']}
        b.save(folder/'facts.json',dict(status='PASS',facts=facts,process=process,image=ready['image']))
        completed.append(dict(name=case['name'],process=process,facts=b.pin(folder/'facts.json')))
        print('PASS',case['name'],flush=True)
    for case in plan['parser_refusals']:
        folder=W/('parser2' if attempt==2 else 'parser')/case['name'];folder.mkdir(parents=True,exist_ok=False)
        start=time.perf_counter();p=subprocess.Popen(case['command'],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
        stdout,stderr=p.communicate(timeout=15);(folder/'stdout.log').write_bytes(stdout);(folder/'stderr.log').write_bytes(stderr)
        record=dict(command=case['command'],pid=p.pid,exit=p.returncode,seconds=time.perf_counter()-start,scope='Rejected before Model construction; metadata parse permitted, no inference')
        b.save(folder/'process.json',record)
        assert p.returncode!=0 and case['error'] in stderr.decode('utf-8',errors='replace')
        assert b'weights_load_seconds=' not in stderr and b'compile full text finite family' not in stderr
        completed.append(dict(name='parser-'+case['name'],process=record))
        print('PASS parser',case['name'],flush=True)
    b.save(W/('summary2.json' if attempt==2 else 'summary.json'),dict(status='THREE_REAL_CLI_AND_THREE_PARSER_CASES_PASS',image=ready['image'],source=ready['source'],completed=completed,
        counts=dict(Model_TUs=1,links=1,model_processes=3,parser_processes=3,SDK=0,NVCC=0,downloads=0),
        scope=plan['scope']))


if __name__=='__main__':
    try:
        if sys.argv[1:]==['prepare']:prepare()
        elif sys.argv[1:]==['run']:run()
        elif sys.argv[1:]==['run2']:run(2)
        else:raise SystemExit('prepare | run')
    except BaseException:
        b.save(W/('run2-failure.json' if sys.argv[1:]==['run2'] else 'run-failure.json'),dict(error=traceback.format_exc(),note='First failure preserved; no automatic retry or replacement sample.'))
        raise
