"""Generated tiny AA consumer data; borrowed original calibration, no native work."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import shlex
import struct
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = R/'.scratch/inference-e4-model-20261025/fixture-preparation'
BASE = R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
POLICY = R/'engine/models/qwen35/prepare.py'
CHECKED_POLICY = R/'.scratch/inference-cache-precision-20261025/role-policy/source/engine/models/qwen35/prepare.py'
SCALARS = R/'.scratch/inference-cache-precision-20261025/scalar-binding-plan/attempt1/complete.json'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    raw=path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(),bytes=len(raw),sha256=sha(raw))
def save(path, value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def f32(value): return struct.unpack('<f',struct.pack('<f',value))[0]
def bf16(value):
    bits=struct.unpack('<I',struct.pack('<f',value))[0]
    return ((bits+0x7fff+((bits>>16)&1))>>16)&0xffff
def wide(bits): return struct.unpack('<f',struct.pack('<I',bits<<16))[0]
# Independent finite E4M3FN table and nearest-neighbor ties-to-even from the
# existing fp8_channel_token_qdq_fixture; no product encoder, Torch or NumPy.
def e4(code):
    mag=code&127;exp=mag>>3;frac=mag&7
    value=math.ldexp(float(frac),-9) if exp==0 else math.ldexp(1.0+frac/8.0,exp-7)
    return -value if code&128 else value
def encode(value):
    magnitude=min(abs(float(value)),448.0)
    best=min(range(127),key=lambda code:(abs(magnitude-e4(code)),code&1))
    return best|(128 if math.copysign(1.0,value)<0 else 0)

assert sha(CHECKED_POLICY.read_bytes())=='03d383a6ead36e8b830bcdb59cc14cfa4ab44dfd5580311bdebd2a8e17c01d09'
assert POLICY.read_text()==CHECKED_POLICY.read_text()
sys.path.insert(0,str(POLICY.parent))
spec=importlib.util.spec_from_file_location('e4_fixture_preparer',POLICY)
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
assert pin(BASE/'weights.tsv')['sha256']=='11ebd54357e5f87839792ee772d228536256b8fb59ef65f37fe432fcdd5413d2'
assert pin(BASE/'untrained-bf16.bin')['sha256']=='a22e65e0c344eee9f38d39fe406db1e0d690367e389698b570c3f68859e44c84'
original={}
for line in (BASE/'weights.tsv').read_text().splitlines()[3:]:
    fields=shlex.split(line)
    rank=int(fields[2]);name=fields[0]
    original[name]=dict(name=name,dtype=fields[1],shape=list(map(int,fields[3:3+rank])),
        path=fields[3+rank],offset=int(fields[4+rank]),bytes=int(fields[5+rank]))

config=dict(text_config=dict(model_type='qwen3_5_text',attn_output_gate=True,
    attention_bias=False,hidden_act='silu',mtp_use_dedicated_embeddings=False,
    hidden_size=64,intermediate_size=128,vocab_size=64,num_attention_heads=1,
    num_key_value_heads=1,head_dim=64,linear_num_key_heads=1,linear_num_value_heads=1,
    linear_key_head_dim=64,linear_value_head_dim=64,linear_conv_kernel_dim=4,
    max_position_embeddings=16,num_hidden_layers=2,mtp_num_hidden_layers=0,
    layer_types=['full_attention','full_attention'],rms_norm_eps=1.e-6,tie_word_embeddings=True,
    rope_parameters=dict(rope_type='default',rope_theta=10000,
        partial_rotary_factor=1.0,mrope_section=[11,11,10])))
common=dict(num_bits=8,type='float',symmetric=True,group_size=None)
config['quantization_config']=dict(quant_method='compressed-tensors',version='0.17.2.a20260716',
    config_groups=dict(generated_channel=dict(format='float-quantized',
        weights=dict(common,strategy='channel',dynamic=False),
        input_activations=dict(common,strategy='token',dynamic=True))),
    kv_cache_scheme=dict(common,strategy='tensor',dynamic=False))
geometry=p.geometry.from_hf(config)
case=W/'ct-e4-aa';case.mkdir(exist_ok=False)
old=W/'bf16-original';old.mkdir(exist_ok=False)
(old/'weights.tsv').write_bytes((BASE/'weights.tsv').read_bytes())
(old/'prompt.ids').write_text('1 2\n',encoding='utf-8')
roles=[];bindings=[]
for name,dims in p.geometry.role_shapes(geometry,include_mtp=False).items():
    source_name=name.replace('layers.1.','layers.0.')
    row=dict(original[source_name]);row['name']=name
    assert row['dtype']=='BF16' and row['shape']==list(dims)
    raw=Path(row['path']).read_bytes()[row['offset']:row['offset']+row['bytes']]
    assert len(raw)==row['bytes']
    row['sha256']=sha(raw)
    roles.append(row)
    bindings.append(dict(generated=name,source_fixture_role=source_name,
        source_path=row['path'],source_offset=row['offset'],bytes=row['bytes'],sha256=row['sha256']))

projection='model.language_model.layers.0.mlp.down_proj.weight'
weight=next(row for row in roles if row['name']==projection)
raw=Path(weight['path']).read_bytes()[weight['offset']:weight['offset']+weight['bytes']]
values=[wide(v) for (v,) in struct.iter_unpack('<H',raw)]
n,k=weight['shape'];codes=bytearray();scale_bits=[]
for channel in range(n):
    row=values[channel*k:(channel+1)*k]
    scale=bf16(f32(max(abs(v) for v in row)/448.0))
    assert wide(scale)>0 and math.isfinite(wide(scale))
    scale_bits.append(scale)
    codes.extend(encode(wide(bf16(f32(v/wide(scale))))) for v in row)
assert any(code&127 for code in codes) and len(set(codes))>16 and all((v&127)!=127 for v in codes)
packed=bytes(codes)+struct.pack('<'+'H'*n,*scale_bits)
payload=case/'generated-channel-token.bin';payload.write_bytes(packed)
weight.update(dtype='F8_E4M3',path=payload.as_posix(),offset=0,bytes=len(codes),sha256=sha(codes))
roles.append(dict(name=projection[:-7]+'.weight_scale',dtype='BF16',shape=[n,1],
    path=payload.as_posix(),offset=len(codes),bytes=2*n,sha256=sha(packed[len(codes):])))

scalars=json.loads(SCALARS.read_text())
scalar_path=R/scalars['payload']['path'];scalar_raw=scalar_path.read_bytes()
assert len(scalar_raw)==64 and sha(scalar_raw)==scalars['payload']['sha256']
calibration=[]
for slot in range(2):
    for side in ('k','v'):
        src=next(row for row in scalars['roles'] if row['attention_slot']==slot and row['side']==side)
        offset=src['destination_offset'];data=scalar_raw[offset:offset+2]
        assert sha(data)==src['source_sha256']
        name=f'model.language_model.layers.{slot}.self_attn.{side}_scale'
        roles.append(dict(name=name,dtype='BF16',shape=[1],bytes=2,path=scalar_path.as_posix(),
            offset=offset,sha256=sha(data)))
        calibration.append(dict(generated_role=name,source_repository=scalars['repository'],
            source_revision=scalars['revision'],source_role=src['name'],source_layer=src['layer'],
            original_bf16_bits=src['original_bf16_bits'],value_f32_bits=src['value_f32_bits'],
            path=scalar_path.relative_to(R).as_posix(),offset=offset,bytes=2,sha256=sha(data)))
assert calibration[0]['value_f32_bits']!=calibration[2]['value_f32_bits']
assert calibration[1]['value_f32_bits']!=calibration[3]['value_f32_bits']
provenance=dict(kind='GENERATED_TINY_AA_NOT_ORIGINAL_Q27',base_fixture=pin(BASE/'weights.tsv'),
    base_payload=pin(BASE/'untrained-bf16.bin'),calibration_source=pin(SCALARS),
    weights='Generated AA target; second A layer renames and borrows original untrained tiny layer0 BF16 ranges.',
    projection='Generated nonzero layer0 down CT E4 codes, BF16 per-channel scales; independent finite encoder.',
    scale_policy='BF16-RNE(row absmax / 448), BF16-RNE(original BF16 weight / BF16 scale), E4M3FN RNE.',
    calibration='Only four exact original scalar roles are borrowed; source layer3/7 map explicitly to generated layer0/1.',
    original_Q27_model_or_quality_verified=False)
revision=hashlib.sha1(json.dumps(provenance,sort_keys=True).encode()).hexdigest()
source=dict(complete=True,repository='hyle/generated-tiny-AA-CT-E4-fixture',revision=revision,roles=roles)
save(case/'roles-source.json',source);save(case/'config.json',config)
lines,receipt=p.prepare_role_files(case/'roles-source.json',False,config,p.CT_MIXED_READER,'e4m3fn')
assert lines[3:5]==[p.CT_MIXED_POLICY_LINE,p.FLOAT8_CACHE_POLICY_LINE]
assert receipt['ct_channel_token_groups']==1 and receipt['ct_local_nvfp4_groups']==0
assert receipt['cache_calibration']['bytes']==8 and receipt['physical_roles']==25
(case/'weights.tsv').write_text('\n'.join(lines)+'\n',encoding='utf-8')
(case/'prompt.ids').write_text('1 2\n',encoding='utf-8')
save(case/'preparation-receipt.json',receipt)
save(case/'provenance.json',dict(provenance,calibration_bindings=calibration,weight_bindings=bindings,
    projection_payload=pin(payload),nonzero_codes=sum((v&127)!=0 for v in codes),
    unique_codes=len(set(codes)),unique_weight_scale_bits=len(set(scale_bits))))
summary=dict(status='REAL_PREPARER_GENERATED_FIXTURES_NO_NATIVE_EXECUTION',
    e4_manifest=pin(case/'weights.tsv'),receipt=pin(case/'preparation-receipt.json'),
    original_default_manifest=pin(old/'weights.tsv'),
    geometry=geometry,calibration_bindings=calibration,
    metadata_tensor_count=receipt['metadata_tensor_count'],selected_weight_roles=receipt['physical_roles'],
    selected_weight_bytes=receipt['selected_weight_bytes'],calibration_bytes=8,
    extra_payload_bytes=len(packed),no_original_bf16_or_scalar_payload_copies=True,
    source_pins=[pin(POLICY),pin(POLICY.parent/'geometry.py'),pin(POLICY.parent/'nf4_state.py'),
        pin(R/'tests/compute_models/fp8_channel_token_qdq_fixture.h'),pin(Path(__file__))],
    scope='Only Python fixture generation and actual prepared-role authentication; no C++/Model/native/GPU/HTTP/quality/TPS.')
save(W/'summary.json',summary)
print(json.dumps(dict(status=summary['status'],e4_manifest=summary['e4_manifest'],
    selected_weight_roles=summary['selected_weight_roles'],selected_weight_bytes=summary['selected_weight_bytes'],
    calibration_bytes=8,extra_payload_bytes=len(packed),nonzero_codes=sum((v&127)!=0 for v in codes),
    unique_codes=len(set(codes)),unique_weight_scale_bits=len(set(scale_bits))),indent=2))
