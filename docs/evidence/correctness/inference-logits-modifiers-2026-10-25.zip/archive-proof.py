"""Offline, compact source/command/raw evidence only; never builds or runs."""
from pathlib import Path
import hashlib
import json
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
PUBLIC = ROOT / 'docs/evidence/correctness'
NAME = 'inference-logits-modifiers-2026-10-25'


def read(path):
    return json.loads(path.read_text(encoding='utf8'))


def digest(data):
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def pin(path):
    return dict(path=path.relative_to(ROOT).as_posix(), **digest(path.read_bytes()))


pins = read(WORK / 'product-pins.json')
for item in pins['files']:
    assert digest((ROOT / item['path']).read_bytes()) == item['after']
    assert digest((WORK / 'source' / item['path']).read_bytes()) == item['after']
final = read(WORK / 'cpu7/summary.json')
assert final['status'] == 'FINITE_CPU_LOGITS_MODIFIERS_PASS'
assert final['run']['exit'] == 0
result = final['results'][0]
assert result['final_versions'] == 0 and result['same_key_restore']
stderr = (WORK / 'cpu7/run/stderr.log').read_text()
assert 'participant=0' in stderr and 'retirement_seen=1 retired=1' in stderr
assert 'qualified=1 slot=1 same_A=1 same_B=1 B_boundary=1 outputs=0,0 commits=0,0 active=0 carrier=0' in stderr
actual = []
for number in range(1, 8):
    folder = WORK / f'cpu{number}'
    stages = {}
    for stage in ('formal-compile', 'compile', 'link', 'run'):
        path = folder / stage / 'process.json'
        if path.is_file():
            stages[stage] = read(path)
    actual.append(dict(attempt=folder.name, stages=stages))
assert sum('run' in item['stages'] for item in actual) == 4
assert 'run' not in actual[5]['stages']

failures = [
    dict(attempt='cpu1', stage='formal-compile', classification='recipe',
         cause='Existing formal lifecycle includes CUDA declarations; original CPU flags omitted the installed CUDA header path.',
         fix='Formal compile only adds cached CUDA13.3 external header include; no CUDA macro/library/provider build or GPU execution.'),
    dict(attempt='cpu2', stage='formal-compile', classification='source',
         cause='New helper incorrectly called namespace q::caller_tensor instead of Model::caller_tensor; existing sampling-policy case ignored nodiscard retirement observation.',
         fix='Use model.caller_tensor; the seventh product path explicitly checks retirement.status and retirement.retired.'),
    dict(attempt='cpu3', stage='run', classification='fixture ownership',
         cause='Unconditional StorageOwner::adopt_buffer rejected CPU primary, whose existing process-system resource domain has no StorageOwner.',
         fix='Use existing Backend::adopt_buffer, retaining actual native StorageOwner when present and the original CPU process-system domain otherwise. No numeric assertion reached.'),
    dict(attempt='cpu4', stage='run', classification='new R2 binding shape',
         cause='Modified greedy TopK produces I32[1,1], while categorical produces I32[1]. R1 concat shortcut hid the distinction; R2 concat with explicit [R] correctly rejected.',
         fix='Only the new modifier Family branch reshapes each member ID to [1] before concatenation. Default graph and selection math are unchanged.'),
    dict(attempt='cpu5', stage='run', classification='fixture fixed-slot assumption',
         cause='RequestWindow.enqueue(index) names the fixed slot. Test assigned A slot0 but required A.slot!=0; the assertion was necessarily false.',
         fix='Keep actual calls [A,B], explicitly assign B slot0/A slot1 and admit FIFO B then A. No weakened predicate or state-publication gate.'),
    dict(attempt='cpu6', stage='not run', classification='unused diagnostic image',
         cause='Compiled extra failure facts before the fixed-slot mistake was identified from source.',
         fix='Skipped execution rather than running a known-invalid test. Source, commands and successful compile/link are retained.'),
]

report = dict(
    status='FINITE_CPU_MODEL_DYNAMIC_LOGITS_MODIFIERS_PASS', date='2026-10-25',
    change='Ordinary precommit typed F32 bias and Bool allowed-mask inputs use the original Graph/Invocation leases, greedy/categorical selection, commit ledger and request lifecycle. Cold policy fixes port existence; ready values can change each output episode.',
    sources=pins['files'],
    input_contract=dict(bias='optional dense F32[1,V], every supplied value finite',
                        allowed='optional dense Bool[1,V], uint8_t carrier',
                        lifetime='Existing read permission and real StorageOwner, or caller-retained borrowed allocator/resource/Context until every copy/native use retires. No extra owner/registry.'),
    actual_final_CPU=dict(formal_compile_only=final['formal_compile'],
                          thin_compile=final['compile'], link=final['link'], run=final['run'],
                          result=result, native=final['native'], fixture=final['fixture']),
    actual_attempts=actual, failures_and_corrections=failures,
    totals=dict(formal_strict_compile_attempts=7, linked_thin_app_compile_attempts=5,
                CPU_process_attempts=4, final_successful_processes=1,
                core_provider_SDK_TUs=0, GPU_processes=0, HTTP_requests=0),
    finite_checks=[
        'One real shared Recipe/Graph in the same CPU process checks greedy and categorical on nine explicit rows: finite, masked raw NaN/+Inf, masked bias NaN/+Inf/-Inf, all masked, all raw -Inf, and one masked raw -Inf.',
        'The real Model default greedy cold Family has no modifier inputs or validity readback. Default graph code branches remain intact; this is not a fresh full default behavior/performance window.',
        'R2 ordinary execution rejects unique all-masked participant0 (Window slot1) before publishing either head, ledger, output or cursor; actual retirement succeeds and same-key B requeues and emits4.',
        'StateOnly prefill has no modifier input requirement or binding. Bad typed rank rejects before mutation; final prefill emits3, next ready lease emits5.',
        'After pause and actual Session retirement, original committed input partitions rebuild with StateOnly, restore historical pending/cursor, then a new ready mask emits7 without replaying prior selections.',
        'A new request fully reuses the completed consumed-state prefix, uses its own ready inputs and current random cursor, shares physical state/carry, emits6 with exactly one committed draw.',
        'Final published Snapshot versions are0; no active episode/carrier or queued/active key remains.'
    ],
    boundaries=[
        'Actual fixture is the cached untrained A/H64/FFN128/V64 BF16 Model, N3/R2/C16, pure CPU. No trained-model quality, complete model-family, GPU/backend, capture or throughput conclusion.',
        'Normal lifecycle --logits-modifiers reaches the same helper. Its existing dual-Model case directly references CUDA symbols, so this batch strict-compiles that exact formal TU only and executes a thin CPU driver; it does not link/run the full lifecycle executable.',
        'Cold flags, not bias/mask values, are part of PreparedSampling identity. Values do not enter Snapshot, KV or historical commit records. Ordinary-only; MTP modifier configurations reject and existing default MTP math is unchanged by source review, not rerun here.',
        'Modifier recovery requires the owner to cold-prepare StateOnly historical widths and use budgets. The finite consumer explicitly prepares widths1,2; no new dispatcher or generic restore controller is added.',
        'Raw NaN/+Inf validity is checked before masking. Modified greedy uses safe placeholders before TopK and typed invalidity before publication. No numerical tolerance was relaxed.',
        'Final versions0 is not a claim that Model workspace/input leases or all resource-budget bytes are0. No physical-memory cap, concurrency throughput or arbitrary callback/grammar policy is established.'
    ],
    reproduction=dict(runner='.scratch/inference-logits-modifiers-20261025/check_cpu.py',
                      commands=['python .scratch/inference-logits-modifiers-20261025/check_cpu.py prepare --attempt repro1',
                                'python .scratch/inference-logits-modifiers-20261025/check_cpu.py build --attempt repro1',
                                'python .scratch/inference-logits-modifiers-20261025/check_cpu.py run --attempt repro1'],
                      cache='129 pinned common link inputs; original CPU native DLL. No core/provider/SDK rebuild.',
                      fixture_directory='.scratch/inference-e4-model-20261025/fixture-preparation/bf16-original',
                      generators=read(WORK / 'cpu7/recipe.json')['fixture_generator_sources']),
    review_scope='Independent reviews pin the earlier six-source draft. Final small changes and seventh legacy-call migration are separately preserved in source revisions and actual strict compiles; earlier review hashes are not relabeled final.',
    cleanup=read(WORK / 'cleanup-candidates.json'),
)

members = {}


def add(path, name):
    assert name not in members
    members[name] = path.read_bytes()


for name in ('product-pins.json', 'product.patch', 'check_cpu.py', 'check-plan.json',
             'implement-main.py', 'archive-proof.py', 'applied.json', 'independent-review-sampling.json',
             'independent-review-architecture.json', 'ownership-review-followup.json', 'cleanup-candidates.json'):
    path = WORK / name
    if path.is_file():
        add(path, name)
for item in pins['files']:
    for side in ('before', 'source'):
        path = WORK / side / item['path']
        if path.is_file():
            add(path, side + '/' + item['path'])
for path in sorted((WORK / 'revisions').rglob('*')):
    if path.is_file():
        add(path, path.relative_to(WORK).as_posix())
for number in range(1, 8):
    folder = WORK / f'cpu{number}'
    for name in ('recipe.json', 'product-pins.json', 'frozen-source.json', 'consumer.cc', 'ready.json', 'summary.json'):
        path = folder / name
        if path.is_file():
            add(path, path.relative_to(WORK).as_posix())
    for stage in ('formal-compile', 'compile', 'link', 'run'):
        for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'dependencies.json', 'repository-inputs.json'):
            path = folder / stage / name
            if path.is_file():
                add(path, path.relative_to(WORK).as_posix())
    # Exact changing regression source, not the complete frozen dependency tree.
    add(folder / 'source/tests/tools/qwen_logits_modifier_case.h', f'cpu{number}/compiled-helper.h')
for path in read(WORK / 'cpu7/recipe.json')['fixture_generator_sources']:
    source = Path(path['path'])
    assert digest(source.read_bytes()) == {key: path[key] for key in ('bytes', 'sha256')}
    add(source, 'fixture-generators/' + source.name)
report_bytes = (json.dumps(report, indent=2) + '\n').encode()
members['report.json'] = report_bytes
members['archive-members.json'] = (json.dumps([dict(path=name, **digest(data))
    for name, data in sorted(members.items())], indent=2) + '\n').encode()
PUBLIC.mkdir(parents=True, exist_ok=True)
archive = PUBLIC / (NAME + '.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(members.items()):
        output.writestr(name, data)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert set(check.namelist()) == set(members)
    for name, data in members.items():
        assert check.read(name) == data, name
report['archive'] = pin(archive)
report['archive']['members'] = len(members)
report['archive']['CRC_and_member_SHA_verified'] = True
target = PUBLIC / (NAME + '.json')
target.write_bytes((json.dumps(report, indent=2) + '\n').encode())
(WORK / 'publication.json').write_bytes((json.dumps(dict(json=pin(target), zip=pin(archive),
    members=len(members), CRC_and_member_SHA_verified=True), indent=2) + '\n').encode())
print((WORK / 'publication.json').read_text())
