"""Prepare, then explicitly build/run one finite CPU logits-modifier process.

Two strict C++ compiles: one thin linked driver and the existing formal
lifecycle TU (/c only; its dual-Model mode requires CUDA when linked).
Only the thin driver runs. No core/provider/SDK build, download or GPU.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
spec = importlib.util.spec_from_file_location('original_cpu_recipe',
    ROOT / '.scratch/inference-duplicate-session-20261025/check_cpu.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.WORK = WORK
base.CASE = CASE = 'tests/tools/qwen_logits_modifier_case.h'
MAIN = base.MAIN
FORMAL = 'tests/tools/qwen_request_lifecycle_test.cc'
read, save, pin = base.read, base.save, base.pin


def prepare(args):
    attempt = base.folder(args.attempt)
    assert not attempt.exists(), 'Preserve original attempts'
    pins = read(WORK / 'product-pins.json')
    for item in pins['files']:
        actual = pin(WORK / 'source' / item['path'])
        assert all(actual[k] == item['after'][k] for k in ('bytes', 'sha256')), item['path']
    tree = attempt / 'source'
    search = [ROOT / 'include', ROOT, ROOT / 'engine', ROOT / 'tests/tools', ROOT / 'engine/models/qwen35']
    queue, seen, frozen = [MAIN, CASE, FORMAL], set(), []
    while queue:
        rel = queue.pop()
        if rel in seen:
            continue
        seen.add(rel)
        canonical = ROOT / rel
        supplied = WORK / 'source' / rel
        source = supplied if supplied.is_file() else canonical
        raw = source.read_bytes()
        target = tree / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        frozen.append(dict(relative=rel, original=pin(source), frozen=pin(target)))
        for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"', raw.decode('utf-8-sig'), re.M):
            for directory in [canonical.parent, *search]:
                child = (directory / inc).resolve()
                if child.is_relative_to(ROOT):
                    child_rel = child.relative_to(ROOT).as_posix()
                    if child.is_file() or (WORK / 'source' / child_rel).is_file():
                        queue.append(child_rel)
                        break
    save(attempt / 'frozen-source.json', frozen)
    save(attempt / 'product-pins.json', pins)
    consumer = attempt / 'consumer.cc'
    consumer.write_bytes(('#include "source/engine/models/qwen35/main.cc"\n'
        '#include "source/tests/tools/qwen_logits_modifier_case.h"\n'
        'int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("logits-modifiers PREPARED_INPUTS");'
        'return qwen_logits_modifier_case::run(argv[1]);}'
        'catch(const std::exception &e){std::cerr<<"logits_modifier_case_failure="<<e.what()<<"\\n";return 1;}}\n').encode())
    original = read(base.COMPILE_RECIPE)['command']
    compiler, flags, skip = original[0], [], False
    canonical_dirs = {ROOT, ROOT / 'include', ROOT / 'engine', ROOT / 'engine/models/qwen35'}
    for arg in original[1:]:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        if 'inference-assembly-placement-20261025' in arg:
            continue
        if arg.startswith(('/I', '-I')) and Path(arg[2:]).resolve() in canonical_dirs:
            continue
        flags.append(arg)
    flags = ['/I' + str(tree / 'include'), '/I' + str(tree), '/I' + str(tree / 'engine'),
        '/I' + str(tree / 'engine/models/qwen35'), *flags]
    assert '/W4' in flags and '/WX' in flags and any('HYLE_COMPUTE_CPU=1' in x for x in flags)
    assert not any('HYLE_COMPUTE_CUDA=1' in x for x in flags)
    obj, image = attempt / 'compile/unit.obj', attempt / 'link/component.exe'
    compile_command = [compiler, *flags, str(consumer), '/sourceDependencies',
        str(attempt / 'compile/dependencies.json'), '/Fo' + str(obj), '/Fd' + str(attempt / 'compile/unit.pdb')]
    # Existing formal lifecycle directly includes CUDA public declarations.
    # Headers only: no CUDA macro, library, provider TU or runtime process.
    cuda_headers = Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3/include')
    assert (cuda_headers / 'cuda.h').is_file() and (cuda_headers / 'cuda_runtime_api.h').is_file()
    formal_command = [compiler, *flags, '/external:I' + str(cuda_headers), str(tree / FORMAL), '/sourceDependencies',
        str(attempt / 'formal-compile/dependencies.json'), '/Fo' + str(attempt / 'formal-compile/unit.obj'),
        '/Fd' + str(attempt / 'formal-compile/unit.pdb')]
    replacements = {
        str(ROOT / '.scratch/inference-e4-model-20261025/cpu1/compile/unit.obj'): str(obj),
        str(ROOT / '.scratch/inference-e4-model-20261025/cpu2/compile-arena/unit.obj'):
            str(ROOT / '.scratch/inference-f32-append-20261025/cpu1/compile/cpu-arena/unit.obj'),
        str(ROOT / '.scratch/inference-e4-append-implementation-20261025/clean-final/compile/cpu-append/unit.obj'):
            str(ROOT / '.scratch/inference-f32-append-20261025/cpu1/compile/cpu-append/unit.obj')}
    link, changed = [], []
    for arg in read(base.LINK_RECIPE)['command']:
        if arg.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:')):
            continue
        if arg in replacements:
            changed.append(dict(before=arg, after=replacements[arg]))
            arg = replacements[arg]
        link.append(arg)
    assert len(changed) == 3
    common = [pin(Path(arg)) for arg in link if Path(arg).is_absolute()
        and Path(arg).suffix.lower() in ('.obj', '.lib') and arg != str(obj)]
    assert len(common) == 129
    link += ['/OUT:' + str(image), '/PDB:' + str(attempt / 'link/component.pdb'),
        '/IMPLIB:' + str(attempt / 'link/component.lib')]
    manifest = base.FIXTURE / 'weights.tsv'
    bodies = sorted({Path(x) for x in re.findall(r'"([^"]+)"\s+\d+\s+\d+\s*$', manifest.read_text(), re.M)})
    assert bodies
    generators = [ROOT / '.scratch/mtp-runtime-backend-20261024/verification1/source/tiny.cc',
        ROOT / '.scratch/inference-e4-model-20261025/fixture-preparation/prepare-fixture.py']
    save(attempt / 'recipe.json', dict(status='PREPARED_NOT_COMPILED_OR_RUN', phase='current',
        main_source=pin(WORK / 'source' / MAIN), case_source=pin(WORK / 'source' / CASE),
        compile=compile_command, formal_compile=formal_command, link=link, common_inputs=common,
        replacements=changed, native=pin(base.NATIVE), runtime=pin(base.RUNTIME), fixture=pin(manifest),
        fixture_bodies=[pin(p) for p in bodies], fixture_generator_sources=[pin(p) for p in generators],
        consumer=pin(consumer), compiler_recipe=pin(base.COMPILE_RECIPE), link_recipe=pin(base.LINK_RECIPE),
        formal_cuda_declaration_headers=[pin(cuda_headers / n) for n in ('cuda.h', 'cuda_runtime_api.h')],
        argv=[str(image), str(base.FIXTURE)], app_TUs=1, formal_strict_compile_only_TUs=1,
        core_provider_SDK_TUs=0, actual_processes=1, watchdog_seconds=120, GPU=False, HTTP=0))
    print('PREPARED', args.attempt, len(frozen), 'own source files; 129 cached common inputs; no compile/run')


def build(args):
    attempt = base.folder(args.attempt)
    plan = read(attempt / 'recipe.json')
    base.verify([entry['frozen'] for entry in read(attempt / 'frozen-source.json')])
    env = base.environment(plan['compile'][0])
    formal = base.cached.execute(plan['formal_compile'], env, attempt / 'formal-compile', 120)
    deps = read(attempt / 'formal-compile/dependencies.json')['Data']
    actual = [Path(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
    for rel in [MAIN, CASE, FORMAL, 'engine/inference/sampling_graph.h',
                'engine/inference/prefix_directory.h', 'engine/models/qwen35/prefix_cache.h']:
        assert attempt / 'source' / rel in actual, rel
    assert not any(p.is_relative_to(ROOT / category) for p in actual for category in ('engine', 'tests', 'include'))
    save(attempt / 'formal-compile/repository-inputs.json', [pin(p) for p in actual if p.is_relative_to(ROOT)])
    base.build(args)
    thin = read(attempt / 'compile/dependencies.json')['Data']
    actual = [Path(p) for p in dict.fromkeys([thin['Source'], *thin['Includes']])]
    for rel in [MAIN, CASE, 'engine/inference/sampling_graph.h',
                'engine/inference/prefix_directory.h', 'engine/models/qwen35/prefix_cache.h']:
        assert attempt / 'source' / rel in actual, rel
    ready = read(attempt / 'ready.json')
    ready['formal_compile'] = formal
    save(attempt / 'ready.json', ready)


def run(args):
    attempt = base.folder(args.attempt)
    plan, ready = read(attempt / 'recipe.json'), read(attempt / 'ready.json')
    base.verify([ready['image'], ready['object'], ready['native'], *plan['common_inputs'],
        plan['fixture'], *plan['fixture_bodies']])
    env = base.environment(plan['compile'][0])
    env['PATH'] = str(attempt / 'link') + ';' + read(base.RUNTIME)['PATH']
    env['HF_HUB_OFFLINE'] = env['TRANSFORMERS_OFFLINE'] = '1'
    process = base.cached.execute(plan['argv'], env, attempt / 'run', 120)
    results = [json.loads(line) for line in (attempt / 'run/stdout.log').read_text().splitlines() if line.startswith('{')]
    assert process['exit'] == 0 and len(results) == 1 and results[0]['status'] == 'PASS'
    result = results[0]
    assert result['dynamic_inputs'] and result['state_only_without_inputs'] and result['allmasked_survivor']
    assert result['greedy_draws'] == 0 and result['fullhit_random_draws'] == 1 and result['final_versions'] == 0
    save(attempt / 'summary.json', dict(status='FINITE_CPU_LOGITS_MODIFIERS_PASS', results=results,
        formal_compile=ready['formal_compile'], compile=ready['compile'], link=ready['link'], run=process,
        source_pins=read(attempt / 'product-pins.json'), native=plan['native'], fixture=plan['fixture'],
        app_TUs=1, formal_strict_compile_only_TUs=1, core_provider_SDK_TUs=0, actual_processes=1, GPU=False, HTTP=0))
    print('FINITE_CPU_LOGITS_MODIFIERS_PASS')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest='action', required=True)
    for name in ('prepare', 'build', 'run'):
        command = actions.add_parser(name)
        command.add_argument('--attempt', required=True)
    args = parser.parse_args()
    dict(prepare=prepare, build=build, run=run)[args.action](args)
