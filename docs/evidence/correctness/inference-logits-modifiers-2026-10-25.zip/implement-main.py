from pathlib import Path

WORK = Path(__file__).resolve().parent
path = WORK / 'source/engine/models/qwen35/main.cc'
raw = (WORK / 'before/engine/models/qwen35/main.cc').read_bytes()
newline = '\r\n' if b'\r\n' in raw else '\n'
s = raw.decode().replace('\r\n', '\n')


def replace(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:120], s.count(old), count)
    s = s.replace(old, new)


replace('  sampling::Policy policy;\n};\nstruct PreparedSampling;', '''  sampling::Policy policy;
  sampling::LogitsPolicy modifiers;
};
// Typed ready inputs for one ordinary output episode. Copies only retain the
// original read permission. Use a lease carrying its existing StorageOwner,
// or keep its borrowed allocator/resource/Context alive through every retained
// copy and native use. Owners may supply different leases next episode; no
// modifier payload enters a Snapshot, commit ledger or KV cache.
struct LogitsInput final {
  c::TensorDesc description;
  c::ReadLease lease;
};
struct LogitsInputs final { LogitsInput bias, allowed; };
struct PreparedSampling;''')
replace('      a.policy.top_k == b.policy.top_k && a.policy.top_p == b.policy.top_p;','''      a.policy.top_k == b.policy.top_k && a.policy.top_p == b.policy.top_p && a.modifiers == b.modifiers;''')
replace('\nstruct GenerationBoundary final {','''
void validate_logits_inputs(const SamplingConfiguration &configuration, const LogitsInputs &inputs,
                            std::int64_t vocabulary) {
  const auto require = [&](const LogitsInput &input, bool enabled, Type type) {
    if (input.lease.valid() != enabled || input.description.valid() != enabled)
      throw std::runtime_error("logits input does not match its cold port configuration");
    if (enabled) {
      if (input.description != dense(type, {1, vocabulary}))
        throw std::runtime_error("logits input requires the exact cold dense [1,V] descriptor");
      (void)take(input.lease.tensor(input.description));
    }
  };
  require(inputs.bias, configuration.modifiers.bias, Type::kFloat32);
  require(inputs.allowed, configuration.modifiers.allowed, Type::kBool);
}
sampling::LogitsInputsFor<V> prepare_logits_inputs(Recipe &r, sampling::LogitsPolicy policy) {
  sampling::LogitsInputsFor<V> result;
  if (policy.bias) result.bias = r.input(dense(Type::kFloat32, {1, r.geometry.vocabulary}));
  if (policy.allowed) result.allowed = r.input(dense(Type::kBool, {1, r.geometry.vocabulary}));
  return result;
}

struct GenerationBoundary final {''')
replace('  V sampling_identity_port, sampling_valid_port, sampling_accept_port;', '''  V sampling_identity_port, sampling_valid_port, sampling_accept_port;
  std::vector<V> logits_bias_ports, logits_allowed_ports; // Cold per-member inputs only.''')
replace('  const inference::RequestStopPolicy *stop_policy = nullptr;\n};\nstruct EvaluationOutput', '''  const inference::RequestStopPolicy *stop_policy = nullptr;
  LogitsInputs logits;
};
struct EvaluationOutput''')
replace('  V hidden_port, identity_port, id_port, valid_port;', '  V hidden_port, identity_port, id_port, valid_port, bias_port, allowed_port;')
replace('        retain_sampling_frontier(first.enabled || std::ranges::any_of(additional, [](const auto &value) { return value.enabled; })) {', '''        retain_sampling_frontier(first.enabled || !first.modifiers.empty() || std::ranges::any_of(additional,
            [](const auto &value) { return value.enabled || !value.modifiers.empty(); })) {''')
replace('    std::uint64_t seed = 0;\n  };', '    std::uint64_t seed = 0;\n    sampling::LogitsPolicy modifiers;\n  };')
replace('SamplingConfiguration{sampling_configuration.enabled, sampling_configuration.policy}, additional_sampling,',
        'SamplingConfiguration{sampling_configuration.enabled, sampling_configuration.policy, sampling_configuration.modifiers}, additional_sampling,')
replace('if (cache_plan.draft_cache && !additional_sampling.empty())',
        'if (cache_plan.draft_cache && (!additional_sampling.empty() || !default_sampler.modifiers.empty()))')
replace('if (role != GraphRole::kText && sampling_index) throw std::runtime_error("nondefault sampling is ordinary Text only");',
        'if (role != GraphRole::kText && (sampling_index || !selected_sampler.modifiers.empty()))\n      throw std::runtime_error("nondefault sampling is ordinary Text only");', 3)
replace('      if (!selected_sampler.enabled || role == GraphRole::kVerify) definition.id_port',
        '      if ((!selected_sampler.enabled && selected_sampler.modifiers.empty()) || role == GraphRole::kVerify) definition.id_port')
replace('      else {\n        std::vector<V> ids, valid, accepted;', '''      else if (!selected_sampler.modifiers.empty()) {
        std::vector<V> ids, valid;
        for (std::size_t request = 0; request < requests; ++request) {
          const auto inputs = prepare_logits_inputs(r, selected_sampler.modifiers);
          if (inputs.bias) { definition.logits_bias_ports.push_back(*inputs.bias); definition.state_resource_ports.push_back(*inputs.bias); }
          if (inputs.allowed) { definition.logits_allowed_ports.push_back(*inputs.allowed); definition.state_resource_ports.push_back(*inputs.allowed); }
          const auto selection = sampling::ordinary_selection(r, sampling_row(definition.logits_port, request),
              selected_sampler.enabled ? std::optional<V>(sampling_identity(request, 0)) : std::nullopt,
              selected_sampler.policy, inputs);
          ids.push_back(r.reshape(selection.id, {f(1)})); valid.push_back(*selection.valid);
        }
        definition.id_port = r.reshape(r.concat(ids, 0, r.dense_spec(Type::kInt32, {batch})), {batch, f(1)});
        definition.sampling_valid_port = r.host_predicate(r.concat(valid, 0, r.dense_spec(Type::kBool, {batch})));
        r.publish(definition.sampling_valid_port);
      } else {
        std::vector<V> ids, valid, accepted;''')
replace('if (!selected_sampler.enabled && sampling_configuration_count() == 1) continue;',
        'if (!selected_sampler.enabled && selected_sampler.modifiers.empty() && sampling_configuration_count() == 1) continue;')
old='''        if (selected_sampler.enabled) {
          const auto probabilities = sampling::distribution(r,
              r.scores(prepared->hidden_port, std::string(geometry.head_role())), selected_sampler.policy);
          prepared->id_port = r.one(c::sampling_ops::categorical(), {probabilities.log_probabilities, prepared->identity_port});
          prepared->valid_port = r.host_predicate(probabilities.valid);
        } else prepared->id_port = r.op(c::Operation(c::TopK{.count = 1}),
            {r.scores(prepared->hidden_port, std::string(geometry.head_role()))})[1];
        r.publish(prepared->id_port); if (selected_sampler.enabled) r.publish(prepared->valid_port);'''
new='''        const auto inputs = prepare_logits_inputs(r, selected_sampler.modifiers);
        if (inputs.bias) prepared->bias_port = *inputs.bias;
        if (inputs.allowed) prepared->allowed_port = *inputs.allowed;
        const auto selection = sampling::ordinary_selection(r,
            r.scores(prepared->hidden_port, std::string(geometry.head_role())),
            selected_sampler.enabled ? std::optional<V>(prepared->identity_port) : std::nullopt,
            selected_sampler.policy, inputs);
        prepared->id_port = selection.id;
        if (selection.valid) prepared->valid_port = r.host_predicate(*selection.valid);
        r.publish(prepared->id_port); if (prepared->valid_port) r.publish(prepared->valid_port);'''
replace(old,new)
replace('if (selected_sampler.enabled) prepared->valid = take(PreparedReadback::prepare(prepared->compiled, prepared->valid_port, execution, allocation_budget));',
        'if (prepared->valid_port) prepared->valid = take(PreparedReadback::prepare(prepared->compiled, prepared->valid_port, execution, allocation_budget));')
replace('cache::SnapshotRef sample_prefix(cache::SnapshotRef base, cache::SamplingCursor cursor, std::size_t sampling_index = 0) {',
        'cache::SnapshotRef sample_prefix(cache::SnapshotRef base, cache::SamplingCursor cursor, std::size_t sampling_index = 0,\n                                   const LogitsInputs &inputs = {}) {')
replace('''    const auto &selected_sampler = selected.configuration;
    if (!base''', '''    const auto &selected_sampler = selected.configuration;
    validate_logits_inputs(selected_sampler, inputs, vocabulary);
    if (!base''')
replace('    check(frontier.id.bind(run)); if (selected_sampler.enabled) check(frontier.valid.bind(run));', '''    if (frontier.bias_port) check(run.bind(frontier.bias_port, inputs.bias.description, inputs.bias.lease));
    if (frontier.allowed_port) check(run.bind(frontier.allowed_port, inputs.allowed.description, inputs.allowed.lease));
    check(frontier.id.bind(run)); if (frontier.valid_port) check(frontier.valid.bind(run));''')
replace('const auto valid = selected_sampler.enabled ? take(frontier.valid.predicate(execution, run)) : std::uint8_t{1};',
        'const auto valid = frontier.valid_port ? take(frontier.valid.predicate(execution, run)) : std::uint8_t{1};')
replace('TextCompletion completion = TextCompletion::kEmitNext, std::size_t sampling_index = 0) {\n    const auto &prepared_sampling = sampling_configuration(sampling_index);\n    const auto &selected_sampler = prepared_sampling.configuration;\n    if (role != GraphRole::kText && (sampling_index || !selected_sampler.modifiers.empty()))\n      throw std::runtime_error("nondefault sampling is ordinary Text only");\n    prepare_state_storage();',
'''TextCompletion completion = TextCompletion::kEmitNext, std::size_t sampling_index = 0,
                                         const LogitsInputs &logits = {}) {
    const auto &prepared_sampling = sampling_configuration(sampling_index);
    const auto &selected_sampler = prepared_sampling.configuration;
    if (role != GraphRole::kText && (sampling_index || !selected_sampler.modifiers.empty()))
      throw std::runtime_error("nondefault sampling is ordinary Text only");
    if (resample_frontier) validate_logits_inputs(selected_sampler, logits, vocabulary);
    prepare_state_storage();''')
replace('if (resample_frontier && (selected_sampler.enabled || sampling_configuration_count() > 1))\n        prefix = sample_prefix(std::move(prefix), cursor.value_or(cache::SamplingCursor{}), sampling_index);',
'''if (resample_frontier && (selected_sampler.enabled || !selected_sampler.modifiers.empty() || sampling_configuration_count() > 1))
        prefix = sample_prefix(std::move(prefix), cursor.value_or(cache::SamplingCursor{}), sampling_index, logits);''')
replace('else if (selected_sampler.enabled && cursor) prefix = sampling_fork(std::move(prefix), *cursor, -1);',
'''else if ((selected_sampler.enabled || !selected_sampler.modifiers.empty()) && cursor)
        prefix = sampling_fork(std::move(prefix), selected_sampler.enabled ? *cursor : cache::SamplingCursor{}, -1);''')
replace('''      check(run.bind(phase.sampling_identity_port, phase.sampling_identities.read()));
      check(phase.sampling_valid.bind(run));''', '''      check(run.bind(phase.sampling_identity_port, phase.sampling_identities.read()));
    }
    if (phase.sampling_valid_port) {
      check(phase.sampling_valid.bind(run));''')
replace('''      phase.sampling_valid = take(PreparedReadback::prepare(phase.child->compiled, phase.sampling_valid_port, execution, allocation_budget));''', '''    }
    if (phase.sampling_valid_port) {
      phase.sampling_valid = take(PreparedReadback::prepare(phase.child->compiled, phase.sampling_valid_port, execution, allocation_budget));''')
replace('''      if (&session.sampling_configuration() != &prepared_sampling) throw std::runtime_error("batch requires one cold sampling configuration");''', '''      if (&session.sampling_configuration() != &prepared_sampling) throw std::runtime_error("batch requires one cold sampling configuration");
      if (completion == TextCompletion::kEmitNext) validate_logits_inputs(selected_sampler, request.logits, vocabulary);''')
replace('''      phase.tokens.write<std::int32_t>(width == 1 ? requests[0].ids : std::span<const std::int32_t>(packed_ids));''', '''      for (std::size_t j = 0; j < width; ++j) {
        if (!phase.logits_bias_ports.empty()) check(run.bind(phase.logits_bias_ports[j], requests[j].logits.bias.description, requests[j].logits.bias.lease));
        if (!phase.logits_allowed_ports.empty()) check(run.bind(phase.logits_allowed_ports[j], requests[j].logits.allowed.description, requests[j].logits.allowed.lease));
      }
      phase.tokens.write<std::int32_t>(width == 1 ? requests[0].ids : std::span<const std::int32_t>(packed_ids));''')
replace('''                          const inference::RequestStopPolicy *stop_policy = nullptr) {
    const std::array requests{EvaluationRequest{session.shared_from_this(), ids, stop_policy}};''', '''                          const inference::RequestStopPolicy *stop_policy = nullptr, const LogitsInputs &logits = {}) {
    const std::array requests{EvaluationRequest{session.shared_from_this(), ids, stop_policy, logits}};''')
replace('if (selected_sampler.enabled && !state_only && phase.family->role != GraphRole::kVerify) {',
        'if (phase.sampling_valid_port && !state_only && phase.family->role != GraphRole::kVerify) {')
replace('''    const auto &selected_sampler = phase.family->sampling->configuration;
    const bool state_only''', '''    const bool state_only''')
replace('std::string_view probe_subdirectory = {}, const inference::RequestStopPolicy *stop_policy = nullptr) {\n  model.prepare_evaluation(session, ids, preparation, GraphRole::kText, TextCompletion::kEmitNext, stop_policy);',
'''std::string_view probe_subdirectory = {}, const inference::RequestStopPolicy *stop_policy = nullptr,
    const LogitsInputs &logits = {}) {
  model.prepare_evaluation(session, ids, preparation, GraphRole::kText, TextCompletion::kEmitNext, stop_policy, logits);''')
replace('  const std::size_t sampling_index;\n  std::size_t input_turn', '''  const std::size_t sampling_index;
  LogitsInputs logits; // Owner may replace ready inputs between output episodes.
  std::size_t input_turn''')
replace('''  const auto first_ids = ledger.records[0].committed_ids();''', '''  // Modifier values are per-output inputs, not replay history. Rebuild only
  // consumed state, then restore each recorded pending/cursor below; no old
  // mask/bias retention, historical resampling or extra RNG draw is required.
  const bool state_rebuild = !model.sampling_configuration(sampling_index).configuration.modifiers.empty();
  const auto first_ids = ledger.records[0].committed_ids();''')
replace('ledger.records[0].before.sampling, false, ledger.records[0].completion, sampling_index);',
        'ledger.records[0].before.sampling, false, state_rebuild ? TextCompletion::kStateOnly : ledger.records[0].completion, sampling_index);')
replace('''      const auto role = role_for(ids.size());
      prepare_generation_record(actual''', '''      const auto role = role_for(ids.size());
      const auto completion = state_rebuild ? TextCompletion::kStateOnly : source.completion;
      prepare_generation_record(actual''')
replace('''          source.completion, source.input_begin, source.prefill_complete);
      make_generation_room''', '''          completion, source.input_begin, source.prefill_complete);
      make_generation_room''')
replace('''          completion, source.input_begin, source.prefill_complete);
      make_generation_room''', '''          completion, source.input_begin, state_rebuild ? false : source.prefill_complete);
      make_generation_room''')
replace('if (fresh.after.next_id != old.after.next_id)', 'if (!state_rebuild && fresh.after.next_id != old.after.next_id)')
replace('model.prepare_evaluation(*session, ids, nullptr, role, source.completion, &actual.stop_policy()); model.submit_evaluation(*session);',
        'model.prepare_evaluation(*session, ids, nullptr, role, completion, &actual.stop_policy()); model.submit_evaluation(*session);')
replace('''  bool generation = false, full_hit = false, initial_prefix = false, prefill_complete = true;
  TextCompletion completion''', '''  bool generation = false, full_hit = false, initial_prefix = false, prefill_complete = true;
  LogitsInputs logits; // Snapshot the caller's input leases for this prepared episode.
  TextCompletion completion''')
replace('''  if (model.cache_plan.draft_cache && request.sampling_index)
    throw std::runtime_error("nondefault request sampling is ordinary Text only");''', '''  if (model.cache_plan.draft_cache && (request.sampling_index || !prepared_sampling.configuration.modifiers.empty()))
    throw std::runtime_error("nondefault request sampling is ordinary Text only");''')
replace('''  preflight_generation_sampling(model, request);
  if (!request.progress.turn_started())''', '''  preflight_generation_sampling(model, request);
  if (!sampler.modifiers.empty()) {
    bool emits = request.progress.prefilled;
    if (!emits) {
      auto consumed = request.input_turn == request.progress.turn_index ? request.turn_input_consumed : 0;
      if (consumed > request.prompt.size()) throw std::runtime_error("prefill offset exceeds its turn input");
      if (prefix && request.progress.turn_index == 0 && !request.session) {
        if (!request.input) throw std::runtime_error("prefix admission requires its complete token plan");
        // No eviction/publication or directory mutation occurs between this
        // pure length preview and the original pinned lookup below.
        consumed = prefix->match_length(*request.input, request.prompt.size(), 1, &model, model.math_identity());
      }
      emits = request.prompt.size() - consumed <= max_prefill_rows;
    }
    if (emits) validate_logits_inputs(sampler, request.logits, model.vocabulary);
  }
  if (!request.progress.turn_started())''')
replace('PreparedGenerationCall call; call.request = &request; call.steps = steps;',
        'PreparedGenerationCall call; call.request = &request; call.steps = steps; call.logits = request.logits;')
replace('request.progress.initial_sampling, suffix == 0, suffix_completion, request.sampling_index);',
        'request.progress.initial_sampling, suffix == 0, suffix_completion, request.sampling_index, call.logits);')
replace('if (sampler.enabled || model.sampling_configuration_count() > 1) {',
        'if (sampler.enabled || !sampler.modifiers.empty() || model.sampling_configuration_count() > 1) {', 2)
replace('''    request.ledger->validate_sampling(sampling, model.resources_);
    if (request.ledger->stop_policy()''', '''    request.ledger->validate_sampling(sampling, model.resources_);
    if (call.completion == TextCompletion::kEmitNext) validate_logits_inputs(sampling.configuration, call.logits, model.vocabulary);
    if (request.ledger->stop_policy()''')
replace('inputs.push_back({request.session, call.ids(), &request.ledger->stop_policy()});',
        'inputs.push_back({request.session, call.ids(), &request.ledger->stop_policy(), call.logits});')
replace('''  return call;
}
''', '''  if (call.completion == TextCompletion::kStateOnly) call.logits = {};
  return call;
}
''')
path.write_bytes(s.replace('\n', newline).encode())
# apply_patch may normalize a file on Windows. Keep its original line format.
p = WORK / 'source/engine/inference/sampling_graph.h'
before = (WORK / 'before/engine/inference/sampling_graph.h').read_bytes()
nl = '\r\n' if b'\r\n' in before else '\n'
p.write_bytes(p.read_text().replace('\r\n', '\n').replace('\n', nl).encode())
