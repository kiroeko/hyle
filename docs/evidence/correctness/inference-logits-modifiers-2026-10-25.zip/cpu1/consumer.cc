#include "source/engine/models/qwen35/main.cc"
#include "source/tests/tools/qwen_logits_modifier_case.h"
int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("logits-modifiers PREPARED_INPUTS");return qwen_logits_modifier_case::run(argv[1]);}catch(const std::exception &e){std::cerr<<"logits_modifier_case_failure="<<e.what()<<"\n";return 1;}}
