"""Inspect exact cached CPU/CUDA owner records; no compilation or execution."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess

mac=platform.system()=='Darwin'
base=Path('/Users/kiro/hyle-scratch/compute-unified' if mac else '/root/hyle-scratch/compute-unified')
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def lines(p,words):
    if not p.is_file():return dict(path=str(p),exists=False)
    text=p.read_text(errors='replace').splitlines()
    return dict(identity=ident(p),matches=[dict(line=i+1,text=x[:500]) for i,x in enumerate(text) if any(w in x for w in words)][:80])
result=dict(HTTP=0,builds=0,models_started=0,records=[])
if mac:
    build=base/'a-cpu/selected-graph/source-build'
    result['compile_commands']=json.loads((build/'compile_commands.json').read_text())
    result['source_libraries']=[dict(path=str(p),bytes=p.stat().st_size) for p in sorted((build/'hyle/src').glob('*/libhyle*')) if p.is_file()]
    ggml=build/'hyle/src/compute_ggml_runtime/source-e74fc9bb8964d04f'
    for p in [ggml/'src/ggml-cpu/ops.cpp',ggml/'src/ggml-cpu/ggml-cpu.cpp',
        ggml/'src/ggml-cpu/ggml-cpu.c',build/'hyle/src/compute_ggml_runtime/cmake_install.cmake']:
        result['records'].append(lines(p,['gdn_output_scale','snapshot_count','HYLE_GDN','hyle_ggml_cpu','gated_delta_net']))
    cache=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sdks/torch-cpu')
    result['torch_cpu']=[]
    if cache.is_dir():
        for root in cache.iterdir():
            lib=root/'libtorch/lib'
            if lib.is_dir():result['torch_cpu'].append(dict(root=str(root),libraries=[dict(name=p.name,bytes=p.stat().st_size) for p in sorted(lib.iterdir()) if p.is_file()][:45]))
else:
    current=base/'linux-current-graph'
    for name in ['selected-owners.json','retained-objects.json','summary.json','run-environment.json','native/current-manifest.json','native/compile-plan.json','native/source-identities.json']:
        p=current/name
        if p.is_file():result['records'].append(dict(identity=ident(p),contents=json.loads(p.read_text())))
    ggml=base/'l-cuda/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-f99368c68335266b'
    for name in ['src/ggml-cuda/gated_delta_net.cu','src/ggml-cuda/ggml-cuda.cu','src/ggml-cpu/ops.cpp']:
        result['records'].append(lines(ggml/name,['gdn_output_scale','snapshot_count','HYLE_GDN','HYLE_MTP','hyle_ggml_cpu','gated_delta_net']))
    model=base/'qwen-v2-cpu-functional-20261024/inputs/weights.tsv'
    rows=model.read_text().splitlines()
    result['prepared_input']=dict(identity=ident(model),head=rows[:4],last=rows[-1])
    import re
    # Read only path fields from the small manifest; no model payload reads.
    paths={x for line in rows[4:] for x in line.split('\t') if x.startswith('/mnt/c/')}
    result['weight_paths']=[dict(path=x,exists=Path(x).is_file(),bytes=Path(x).stat().st_size if Path(x).is_file() else None) for x in sorted(paths)[:8]]
print(json.dumps(result,indent=2))
