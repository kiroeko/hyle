"""Read the original Ninja dependency database; hash only Hyle source/header paths."""
from pathlib import Path
import hashlib,json,shutil,subprocess
B=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu/selected-graph/source-build')
tool=shutil.which('ninja') or '/opt/homebrew/bin/ninja'
p=subprocess.run([tool,'-t','deps'],cwd=B,capture_output=True,text=True,timeout=30)
if p.returncode:raise RuntimeError(p.stderr)
dependencies={};key=None
for line in p.stdout.splitlines():
    if line and not line.startswith(' '):
        key=line.split(': #deps',1)[0]
        dependencies[key]=[]
    elif line.startswith('    ') and key is not None:
        dependencies[key].append(line.strip())
identities={}
rows=[]
for row in json.loads((B/'compile_commands.json').read_text()):
    source=row['file']
    if '/source-c8874688/' not in source or '/src/' not in source:continue
    output=Path(row['output']);relative=output.relative_to(B).as_posix()
    deps=dependencies.get(relative)
    if deps is None:deps=dependencies.get(str(output))
    repo=[x for x in (deps or []) if '/source-c8874688/' in x]
    for value in repo:
        if value not in identities:
            f=Path(value)
            identities[value]=dict(relative=value.split('/source-c8874688/',1)[1],exists=f.is_file(),
                sha256=hashlib.sha256(f.read_bytes()).hexdigest() if f.is_file() else None)
    rows.append(dict(source=source,object=str(output),object_exists=output.is_file(),dependency_record_found=deps is not None,repo_dependencies=repo))
print(json.dumps(dict(HTTP=0,builds=0,models_started=0,tool=tool,command=[tool,'-t','deps'],
    exit=p.returncode,rows=rows,identities=identities),indent=2))
