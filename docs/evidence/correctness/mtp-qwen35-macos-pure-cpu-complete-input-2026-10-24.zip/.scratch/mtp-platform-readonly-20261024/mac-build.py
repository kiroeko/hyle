"""One finite ARM CPU closure, using existing platform SDKs/native objects."""
from pathlib import Path
import concurrent.futures
import hashlib,json,os,subprocess,sys,tarfile,time
sys.dont_write_bytecode=True
D=Path('/Users/kiro/hyle-scratch/compute-unified/qwen-pure-cpu-functional-20261024/attempt1')
ROUND=sys.argv[1] if len(sys.argv)>1 else 'compile1'
def load(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def execute(tag,argv,timeout=240):
    out=D/'results'/(ROUND+'--'+tag.replace('/','--'));out.mkdir(parents=True,exist_ok=False)
    save(out/'command.json',dict(command=argv,cwd=str(D)))
    start=time.monotonic()
    with (out/'stdout.log').open('wb')as stdout,(out/'stderr.log').open('wb')as stderr:
        process=subprocess.run(argv,cwd=D,stdout=stdout,stderr=stderr,timeout=timeout)
    result=dict(exit=process.returncode,seconds=time.monotonic()-start)
    save(out/'process.json',result)
    print(tag,result,flush=True)
    return result
if not (D/'plan.json').exists():
    with tarfile.open(D/'source.tar.gz')as tar:
        for item in tar.getmembers():
            target=(D/item.name).resolve()
            assert target.is_relative_to(D.resolve()) and item.isfile()
        tar.extractall(D)
plan=load(D/'plan.json')
for row in plan['source_records']:
    assert ident(D/'source'/row['relative'])['sha256']==row['identity']['sha256'],row['relative']
patch=load(D/'source/native/patches.json');native_base=Path(plan['native_cache_root']);native=[]
for row in patch['files']:
    p=native_base/row['path'];actual=ident(p)
    if actual['sha256']!=row['after_sha256']:
        overlay=D/'source/native'/row['path']
        assert row['path']in ['src/ggml-cpu/ops.cpp','src/ggml-alloc.c'],actual
        assert overlay.is_file()and ident(overlay)['sha256']==row['after_sha256']
        native.append(dict(original=actual,overlay=ident(overlay)))
assert len(native)==2,native
save(D/'native-overlays.json',native)
cached=[]
for item in plan['shared_public_objects_and_libraries']+plan['pure_cpu_native_objects']:
    p=Path(item);assert p.is_file(),str(p);cached.append(ident(p))
save(D/'cached-input-identities.json',cached)
(D/'objects').mkdir(exist_ok=True)
results=[]
selected=plan['jobs']
if ROUND not in ('compile1','compile2'):
    previous=load(D/'compile-results.json')
    save(D/('compile-results-before-'+ROUND+'.json'),previous)
    retry={x['tag']for x in previous if x['process']['exit']}
    if ROUND=='compile3':retry|={j['tag']for j in selected if j['tag'].startswith('src/compute_provider_ggml/')}
    selected=[j for j in selected if j['tag']in retry]
    results=[x for x in previous if x['tag']not in retry]
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
    jobs={pool.submit(execute,j['tag'],j['command']):j for j in selected}
    for future in concurrent.futures.as_completed(jobs):
        job=jobs[future];result=future.result();results.append(dict(tag=job['tag'],process=result))
save(D/'compile-results.json',results)
if any(x['process']['exit']for x in results):sys.exit(1)
link=execute('link',plan['link'],120)
if link['exit']:sys.exit(link['exit'])
for row in plan['source_records']:
    assert ident(D/'source'/row['relative'])['sha256']==row['identity']['sha256']
save(D/'ready.json',dict(image=ident(D/'hyle-cpu'),objects=[ident(Path(j['output']))for j in plan['jobs']],
    cached_inputs=cached,HTTP=0,SDK_builds=0,weight_copies=0,source_stable=True,models_started=0))
print('READY',ident(D/'hyle-cpu'),flush=True)
