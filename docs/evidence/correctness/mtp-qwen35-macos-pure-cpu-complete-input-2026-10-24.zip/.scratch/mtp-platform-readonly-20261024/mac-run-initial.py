"""Two bounded current CPU endpoint journeys over the already local original model."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
D=Path('/Users/kiro/hyle-scratch/compute-unified/qwen-pure-cpu-functional-20261024/attempt1')
OLD=Path('/Users/kiro/hyle-scratch/compute-unified/qwen-multik-functional-20261024/attempt1/inputs')
def load(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def command(argv):
    p=subprocess.run(argv,capture_output=True,text=True,timeout=20)
    return dict(command=argv,exit=p.returncode,stdout=p.stdout,stderr=p.stderr)
ready=load(D/'ready.json');assert ident(D/'hyle-cpu')==ready['image']
inputs=D/'inputs';inputs.mkdir(exist_ok=False)
shutil.copyfile(OLD/'weights.tsv',inputs/'weights.tsv')
ids=list(map(int,(OLD/'prompt.ids').read_text().split()))[:15]
assert len(ids)==15
(inputs/'prompt.ids').write_text(' '.join(map(str,ids))+'\n')
save(D/'input-identity.json',dict(manifest=ident(inputs/'weights.tsv'),prompt=ident(inputs/'prompt.ids'),
    prompt_tokens=15,original_manifest=ident(OLD/'weights.tsv'),weight_copies=0,HTTP=0))
diagnostics=[command(['otool','-L',str(D/'hyle-cpu')])]
nm=command(['nm','-g',str(D/'hyle-cpu')])
diagnostics.append(dict(command=nm['command'],exit=nm['exit'],forbidden_Hyle_GPU_symbols=[line for line in nm['stdout'].splitlines()
    if any(x in line for x in ('ggml_backend_metal','ggml_backend_cuda','hyle7compute5apple','hyle7compute6vulkan','mlx'))],stderr=nm['stderr']))
save(D/'native-dependencies.json',diagnostics)
assert not diagnostics[-1]['forbidden_Hyle_GPU_symbols']
base=[str(D/'hyle-cpu'),'--inputs',str(inputs),'--capacity','32','--steps','4','--max-sessions','1',
    '--active-sequences','1','--cache-bytes','268435456','--prefix-cache','off','--progress','direct','--replay','commands']
env=dict(os.environ,OMP_NUM_THREADS='4',VECLIB_MAXIMUM_THREADS='4')
results=[]
for name,extra in [('ordinary',['--mtp','off','--sampling','greedy']),
    ('mtp-k1-random',['--mtp','on','--max-draft','1','--sampling','random','--temperature','0.8','--top-k','40','--top-p','0.95','--seed','42'])]:
    folder=D/name;folder.mkdir(exist_ok=False)
    argv=base+extra;save(folder/'command.json',dict(command=argv,cwd=str(D),image=ready['image'],
        environment={k:env[k]for k in ['OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']},timeout_seconds=240,performance_claim=False))
    start=time.monotonic()
    with (folder/'stdout.log').open('wb')as stdout,(folder/'stderr.log').open('wb')as stderr:
        p=subprocess.run(['/usr/bin/time','-l',*argv],cwd=D,env=env,stdout=stdout,stderr=stderr,timeout=240)
    process=dict(exit=p.returncode,seconds=time.monotonic()-start)
    save(folder/'process.json',process)
    print(name,process,flush=True)
    if p.returncode:raise RuntimeError('Actual CPU journey failed; no automatic retry')
    rows=[json.loads(line)for line in(folder/'stdout.log').read_text().splitlines()if line.startswith('{')]
    report=next(row for row in reversed(rows)if 'generated_ids'in row)
    assert report['backend']=='cpu' and report['original_device_weight_bytes']==0
    assert report['original_host_weight_bytes']==(3885311680 if name!='ordinary' else 3763655360)
    assert report['mtp']==(name!='ordinary')
    assert report['cache_peak_requested_bytes']<=268435456
    assert 0<len(report['generated_ids'])<=4 and all(0<=x<248320 for x in report['generated_ids'])
    save(folder/'report.json',report)
    results.append(dict(name=name,process=process,report=report))
    save(D/'functional-results.json',dict(cases=results,HTTP=0,weight_copies=0,SDK_builds=0,
        scope='One true ARM CPU-only Hyle route with retained pure ffa4 original native CPU math; no Apple/MLX/Metal Hyle provider or queue; two finite complete-input source-geometry journeys, no task-quality/performance claim.'))
    print('IDS',name,report['generated_ids'],flush=True)
print('COMPLETE',flush=True)
