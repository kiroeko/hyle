"""Collect finite command/state evidence, excluding images, objects and weights."""
from pathlib import Path
import hashlib,json,tarfile
D=Path('/Users/kiro/hyle-scratch/compute-unified/qwen-pure-cpu-functional-20261024/attempt1')
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files=[]
for p in D.iterdir():
    if p.is_file()and p.suffix in ('.json','.py'):files.append(p)
for root in ['results','ordinary','mtp-k1-random','mtp-k1-random-actual-option']:
    for p in (D/root).rglob('*'):
        if p.is_file()and p.suffix in ('.json','.log','.d'):files.append(p)
files += [D/'inputs/weights.tsv',D/'inputs/prompt.ids']
archive=D/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
    for p in sorted(set(files)):tar.add(p,arcname=p.relative_to(D),recursive=False)
print(json.dumps(dict(archive=ident(archive),records=len(set(files)),
    summary=json.loads((D/'functional-results.json').read_text())),indent=2))
