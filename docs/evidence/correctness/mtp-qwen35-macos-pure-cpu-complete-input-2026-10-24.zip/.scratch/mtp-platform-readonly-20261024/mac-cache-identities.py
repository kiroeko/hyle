"""Hash only source files named by the retained finite CPU compile database."""
from pathlib import Path
import json,hashlib
B=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu/selected-graph/source-build')
rows=json.loads((B/'compile_commands.json').read_text())
result=[]
for row in rows:
    p=Path(row['file'])
    if '/source-c8874688/' not in str(p):continue
    relative=str(p).split('/source-c8874688/',1)[1]
    if not relative.startswith('src/'):continue
    result.append(dict(relative=relative,source=str(p),exists=p.is_file(),
        sha256=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None,
        object=row.get('output'),object_exists=Path(row['output']).is_file() if row.get('output') else None))
print(json.dumps(dict(HTTP=0,builds=0,models_started=0,rows=result),indent=2))
