"""Bounded existing platform/cache inventory. No builds, inference or writes."""
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess

def command(argv):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=15)
        return dict(command=argv, exit=p.returncode, stdout=p.stdout, stderr=p.stderr)
    except Exception as e:
        return dict(command=argv, error=str(e))
def entry(p):
    try:
        return dict(path=str(p), directory=p.is_dir(), bytes=p.stat().st_size,
                    symlink=p.is_symlink(), modified=p.stat().st_mtime)
    except Exception as e:
        return dict(path=str(p), error=str(e))
def listing(p, limit=100):
    if not p.is_dir():
        return dict(path=str(p), exists=False)
    children = sorted(p.iterdir(), key=lambda p:p.name)
    return dict(path=str(p), exists=True, entries=[entry(x) for x in children[:limit]],
                truncated=len(children)>limit)

mac = platform.system() == 'Darwin'
base = Path('/Users/kiro/hyle-scratch/compute-unified' if mac else '/root/hyle-scratch/compute-unified')
commands = [['uname','-a']]
commands += ([['sysctl','-n','hw.model'],['sysctl','-n','hw.memsize'],['/usr/bin/clang++','--version']]
    if mac else [['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'],['nvcc','--version'],['g++-14','--version']])
commands += [['df','-k',str(base)]]
result = dict(system=platform.platform(), HTTP=0, builds=0, models_started=0,
    commands=[command(c) for c in commands], base=listing(base,150), paths=[])
roots = ([base/'a-cpu-apple',base/'models/qwen35-2b',base/'qwen-k1-functional-20261024/attempt1',
          base/'qwen-multik-functional-20261024/attempt1',
          base/'architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21',
          Path('/Users/kiro/.cache/hyle/dependencies/v1/sdks')]
    if mac else [base/'qwen-v2-cpu-functional-20261024',base/'models',
          Path('/root/hyle-scratch/active-cpu-z/delivery1-linux-current-build-2026-10-21/static-sdk-relocated'),
          Path('/root/hyle-scratch/active-cpu-z/delivery1-linux-current-build-2026-10-21'),
          Path('/root/.cache/hyle/dependencies/v1/sdks'),Path('/usr/local/cuda')])
for root in roots:
    result['paths'].append(listing(root))
    for name in ('lib','bin','results','output','model','source-build','sdk','install','input','inputs'):
        p=root/name
        if p.is_dir():
            result['paths'].append(listing(p,90))
result['small_result_files'] = []
known = ([base/'qwen-k1-functional-20261024/attempt1',base/'qwen-multik-functional-20261024/attempt1']
    if mac else [base/'qwen-v2-cpu-functional-20261024'])
for root in known:
    for pattern in ('*ready*.json','*link*.json','*run*.json','*result*.json','*source*.json','*identity*.json'):
        for p in sorted(root.glob(pattern)):
            if p.is_file() and p.stat().st_size < 300000:
                result['small_result_files'].append(dict(identity=entry(p), contents=json.loads(p.read_text())))
print(json.dumps(result, indent=2))
