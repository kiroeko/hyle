"""Publish the two bounded actual ARM CPU journeys and their retained closure."""
from pathlib import Path
import hashlib,json,re,tarfile,zipfile
R=Path(__file__).resolve().parents[2];S=Path(__file__).resolve().parent
OUT=R/'docs/evidence/correctness/mtp-qwen35-macos-pure-cpu-complete-input-2026-10-24'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
collected=load(S/'mac-collected.json');plan=load(S/'mac-cpu-plan.json')
with tarfile.open(S/'mac-evidence.tar.gz')as tar:
    def record(name):return json.loads(tar.extractfile(name).read())
    ready=record('ready.json');compiles=record('compile-results.json')
    assert len(compiles)==35 and all(x['process']['exit']==0 for x in compiles)
    dependencies=record('native-dependencies.json')
    assert dependencies[0]['exit']==dependencies[1]['exit']==0
    assert dependencies[1]['forbidden_Hyle_GPU_symbols']==[]
    source=record('input-identity.json');initial_cli=record('mtp-k1-random/process.json')
    assert initial_cli['exit']==1
    native_overlays=record('native-overlays.json')
    cases=[]
    for entry in collected['summary']['cases']:
        name=entry['name'];r=entry['report']
        folder='ordinary'if name=='ordinary'else'mtp-k1-random-actual-option'
        command=record(folder+'/command.json');process=record(folder+'/process.json')
        assert command['image']==ready['image'] and process['exit']==0
        assert r['backend']=='cpu'and r['original_device_weight_bytes']==0
        assert r['committed_target_rows']==18
        raw=tar.extractfile(folder+'/stderr.log').read().decode()
        memory={}
        for field in ['maximum resident set size','peak memory footprint']:
            m=re.search(r'^\s*(\d+)\s+'+field+r'\s*$',raw,re.MULTILINE)
            if m:memory[field.replace(' ','_')+'_bytes']=int(m.group(1))
        cases.append(dict(name=name,process=process,generated_ids=r['generated_ids'],
            committed_target_rows=r['committed_target_rows'],sampling_draw_cursor=r['sampling_draw_cursor'],
            draft_frontier=r.get('draft_frontier'),draft_lag=r.get('draft_lag'),
            host_weight_bytes=r['original_host_weight_bytes'],device_weight_bytes=r['original_device_weight_bytes'],
            cache_limit_bytes=r['cache_requested_byte_limit'],cache_peak_bytes=r['cache_peak_requested_bytes'],
            known_workspace=r['workspace_domains'],shared_execution_limit=r['execution_shared_requested_byte_limit'],
            native_private_unknown=r['native_execution_private_bytes_unknown'],OS_process_memory=memory))
    assert len(cases)==2
    assert cases[1]['generated_ids']==[1328,5675,8,248046]
    assert cases[1]['sampling_draw_cursor']==7 and cases[1]['draft_frontier']==17 and cases[1]['draft_lag']==1
mac=load(S/'mac-inventory.json')
records=[Path(__file__).resolve(),S/'mac-evidence.tar.gz',S/'mac-cpu-source.tar.gz',S/'mac-cpu-plan.json',
    S/'mac-collected.json',S/'mac-run.py',S/'mac-run-initial.py',S/'mac-build.py',S/'prepare-mac-cpu.py',S/'collect-mac.py',
    S/'inventory.py',S/'focus.py',S/'owners.py',S/'mac-cache-identities.py',S/'mac-cached-dependencies.py',
    S/'mac-cache-identities.json',S/'mac-cache-delta.json',S/'mac-cached-dependencies.json',S/'mac-dependency-delta.json',
    S/'mac-dependency-delta-lf.json',S/'mac-cpu-plan-before-path-fix.json',S/'mac-inventory.json',S/'mac-focus.json',S/'mac-owners.json']
archive=OUT.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in records:z.write(p,p.relative_to(R))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
summary=dict(date='2026-10-24',status='PASS two finite complete-original-input ARM CPU-only Hyle journeys',
    scope='Mac16,12 complete original BF16 Qwen3.5-2B source-derived geometry, ordinary greedy and MTP K1 random, P15/+4/C32/N1/R1. Independent CPU endpoint and pure original ffa4 native CPU implementation; no Apple Hyle provider/queue or MLX/Metal kernel.',
    hardware=mac['commands'],deployment='Compiled/linked arm64 macOS14.4; actual runtime macOS27.0.1, not an actual14.4 operating-system execution.',
    input=dict(original='/Users/kiro/hyle-scratch/compute-unified/models/qwen35-2b/model.safetensors',
        original_bytes=4548221488,original_prior_SHA256='aa33250c4fc64891ddfaba3a314fd9542ea371843c387178b425fbcc5ed680b1',
        prior_whole_file_identity_not_rehashed_by_audit=True,prepared=source,selected_original_roles=335,
        original_weight_copies=0,new_model_downloads=0),
    image=ready['image'],cases=cases,
    closure=dict(fresh_CPU_Hyle_TUs=32,fresh_model_TUs=1,fresh_native_TUs=2,
        reused_pure_ARM_GGML_objects=len(plan['pure_cpu_native_objects']),
        reused_neutral_public_and_CPU_SIMD_inputs=len(plan['shared_public_objects_and_libraries']),
        native_overlays=native_overlays,
        native_core='Actual pure CPU ffa4e8b80930029a35991f94e7c8a93cd67730ab cached headers/objects, plus exactly the current canonical ops.cpp/allocator differences. No mixed456 GGML or GGMLMetal program.',
        shared_public='Current Compute/Graph/Batch/IO neutral owners from already exercised Apple SDK closures; remove Apple/MLX/Metal/provider/queue/native owners. The CPU source defaults/provider/native/stream/GraphRoute objects are rebuilt current, so the model actually executes CPU operations.',
        CPU_SIMD_leaf='Reuse the existing ARM CPU SIMD static math leaf, whose pointer/scalar symbols resolve directly. It has no Hyle GPU route/runtime dependency. This is retained implementation, not a fresh SIMD rebuild.',
        stale_CPU_cache='Ninja dependency identities showed138/142 old CPU compile records affected by real Hyle source/header changes. Its95 identical source files were not treated as ABI proof. The old deleted graph/leased_invocation.cc and compute_route_cpu/file_stream.cc objects were not admitted.',
        source_package=ident(S/'mac-cpu-source.tar.gz'),dependency_diagnostics=dependencies,
        final_compile_tags=[x['tag']for x in compiles],SDK_rebuilds=0,third_party_tree_copies=0,HTTP=0),
    retained_failures=[
        'Initial scratch Windows Path formatting produced backslashes in remote compiler input names. The compiler rejected the nonexistent paths before parsing product code; original command/error records remain.',
        'Initial source overlay omitted four private shared headers and the native include directory; only those affected TUs and three provider version flags were corrected. No product mathematics changed.',
        'First link omitted the CPU SIMD leaf from the Apple-only neutral closure. Adding the existing CPU math leaf resolved the exact CPU function references; no GPU library was added.',
        'First K1 command used the wrong --max-draft spelling and exited1 before Model creation/loading. The explicit corrected --mtp-max-drafts1 command then ran the actual MTP case; successful ordinary was not repeated.'],
    limits=['Two short functional journeys only; no all-platform/model/format/placement matrix or complete generation-quality result.',
        'No throughput comparison. External process seconds include source loading/preparation and must not be presented as decode speed.',
        'Known per-invocation CPU Graph workspace limits are finite; shared execution allocation tracking is not a physical total-memory cap, and native provider-private size remains unknown.',
        'otool lists the image direct imports (TorchCPU/c10/Accelerate/Foundation/system C++); this does not claim that every optional implementation inside the vendor Torch distribution was rebuilt or removed.',
        'The frozen source and selected retained object closure are documented; this is not a new top-level installed SDK build or actual macOS14.4 runtime proof.'],
    archive=ident(archive),archive_records=len(records),
    prior_evidence=['docs/evidence/correctness/mtp-qwen35-apple-k1-complete-input-2026-10-24.json',
        'docs/evidence/correctness/mtp-qwen-source-geometry-v2-preparation-2026-10-24.json'])
save(OUT.with_suffix('.json'),summary)
print(json.dumps(dict(evidence=OUT.with_suffix('.json').relative_to(R).as_posix(),archive=ident(archive),cases=cases),indent=2))
