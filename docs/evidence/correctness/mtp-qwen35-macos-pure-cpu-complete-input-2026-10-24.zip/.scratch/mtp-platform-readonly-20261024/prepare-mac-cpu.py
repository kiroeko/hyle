"""Prepare a small current CPU overlay against cached platform objects; no SDK/weights."""
from pathlib import Path, PurePosixPath
import hashlib,json,re,shlex,tarfile
R=Path(__file__).resolve().parents[2]
S=R/'.scratch/mtp-platform-readonly-20261024'
D=PurePosixPath('/Users/kiro/hyle-scratch/compute-unified/qwen-pure-cpu-functional-20261024/attempt1')
OLD='/Users/kiro/hyle-scratch/compute-unified/source-c8874688'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
old=load(S/'mac-owners.json')['compile_commands']
apple=load(R/'.scratch/qwen-apple-multik-20261024/plan.json')
modules={
 'compute_backend_cpu':['cpu_backend.cc'],
 'compute_ggml_runtime':['cpu_execution.cc','metadata_arena.cc','cpu_program.cc'],
 'compute_provider_ggml':['ggml_cpu_provider.cc','native_batch.cc','standard_index.cc'],
 'compute_route_cpu':['cpu_context.cc','default_policy.cc'],
 'graph_route_cpu':['cpu_context.cc','compile.cc','ct_packed_linear_region.cc','ggml_region.cc'],
 'compute_stream_cpu':['file_stream.cc']}
native_cmake=(R/'src/compute_provider_native/CMakeLists.txt').read_text()
native_block=native_cmake.split('hyle_add_module(compute_provider_native SOURCES',1)[1].split(')',1)[0]
modules['compute_provider_native']=re.findall(r'[a-z0-9_]+\.cc',native_block)+['torch_cpu_program.cc']
sources=['src/'+module+'/'+name for module,names in modules.items()for name in names]
assert len(sources)==32, len(sources)
records=[];jobs=[]
def record(local,relative):
    p=R/local; records.append(dict(identity=ident(p),relative=relative));return D/'source'/relative
for path in sources:record(path,path)
roots=['include/hyle']+['src/'+m for m in set(modules)|{'compute','compute_ops','compute_batch','compute_stream','graph','graph_batch','compute_packed_shared','compute_torch_shared','graph_ggml_shared'}]
for root in roots:
    for p in (R/root).rglob('*'):
        if p.is_file() and p.suffix in ('.h','.hpp','.inc','.inl'):
            record(p.relative_to(R).as_posix(),p.relative_to(R).as_posix())
for module in ['ds4_quantization','torchao_cpu','bitsandbytes_cpu','awq_cpu','compressed_tensors_cpu','mlx_cpu_quant','random123_counter']:
    for p in (R/'third_party'/module).rglob('*'):
        if p.is_file() and p.suffix in ('.h','.hpp','.inc','.inl'):
            record(p.relative_to(R).as_posix(),p.relative_to(R).as_posix())
frozen=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1/source'
for p in frozen.rglob('*'):
    if p.is_file() and p.suffix in ('.h','.cc') and ('/engine/inference/' in p.as_posix() or '/engine/models/qwen35/' in p.as_posix() or p.name=='probe.cc'):
        record(p.relative_to(R).as_posix(),p.relative_to(frozen).as_posix())
for path in ['src/ggml-cpu/ops.cpp','src/ggml-alloc.c']:
    record('.scratch/qwen-pure-cpu-deployment-20261024/native-source/'+path,'native/'+path)
record('third_party/ggml_cpu_runtime/patches.json','native/patches.json')
def cpp_flags(module):
    donor=next(row for row in old if '/src/'+module+'/' in row['file']) if module!='compute_stream_cpu' else next(row for row in old if '/src/compute_route_cpu/' in row['file'])
    words=shlex.split(donor['command']); out=[];skip=False
    for a in words:
        if skip:skip=False;continue
        if a in ['-o','-c']:skip=True;continue
        if a==donor['file'] or a.startswith(('-Dhyle_','-DHYLE_GGML_CPU_PROVIDER_VERSION=')) or a=='-Werror':continue
        out.append(a.replace(OLD,str(D/'source')))
    out.insert(1,'-DHYLE_STATIC')
    pure='/Users/kiro/hyle-scratch/compute-unified/a-cpu/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-e74fc9bb8964d04f'
    out[1:1]=['-I'+str(D/'source/include'),'-I'+str(D/'source/src/compute'),'-I'+str(D/'source/src/compute_ggml_runtime'),'-I'+str(D/'source/src/compute_provider_ggml'),'-I'+pure+'/include','-I'+pure+'/src','-I'+pure+'/src/ggml-cpu']
    out+=['-DHYLE_GGML_CPU_IQ1_EXTENSIONS=1']
    if module=='compute_provider_ggml':out+=['-DHYLE_GGML_CPU_F32_FLASH=1','-DHYLE_GGML_CPU_PROVIDER_VERSION="ffa4-current-arm-cpu-functional"']
    return out
for source in sources:
    module=source.split('/')[1];output=D/'objects'/(source.replace('/','--')+'.o')
    argv=cpp_flags(module)+['-MMD','-MF',str(output)+'.d','-c',str(D/'source'/source),'-o',str(output)]
    jobs.append(dict(tag=source,command=argv,source=D.joinpath('source',source).as_posix(),output=str(output)))
native=[]
for row in old:
    if '/compute_ggml_runtime/source-e74fc9bb8964d04f/' not in row['file']:continue
    relative=row['file'].split('/source-e74fc9bb8964d04f/',1)[1]
    if relative not in ['src/ggml-cpu/ops.cpp','src/ggml-alloc.c']:
        native.append(row['output']);continue
    argv=shlex.split(row['command']); argv=argv[:argv.index('-o')]+argv[argv.index('-o')+2:]
    ci=argv.index('-c');argv=argv[:ci]+argv[ci+2:]
    output=D/'objects'/('native--'+relative.replace('/','--')+'.o')
    argv+=['-I'+str(D/'source/src/compute_ggml_runtime'),'-MMD','-MF',str(output)+'.d','-c',str(D/'source/native'/relative),'-o',str(output)]
    jobs.append(dict(tag='native/'+relative,command=argv,source=str(D/'source/native'/relative),output=str(output)))
main_flags=cpp_flags('compute_route_cpu')
main_flags+=['-I'+str(D/'source'),'-DHYLE_COMPUTE_TORCH_CPU=1']
main_output=D/'objects/model.o'
jobs.append(dict(tag='engine/probe.cc',command=main_flags+['-MMD','-MF',str(main_output)+'.d','-c',str(D/'source/probe.cc'),'-o',str(main_output)],source=str(D/'source/probe.cc'),output=str(main_output)))
# Public Compute/Graph owners are backend-neutral. Deliberately exclude every
# Apple/MLX/Metal native owner and all original GGML456 objects from that list.
shared=[]
for value in apple['link']:
    if not value.endswith(('.o','.a')):continue
    name=Path(value).name
    if name=='model.o' or any(word in name.lower() for word in ['apple','metal','mlx','ggml','metadata_arena']):continue
    shared.append(value)
assert len(shared)>20
# SIMD is the CPU math leaf. The Apple-only application closure did not need
# it; the cached static leaf has no provider/Metal/runtime dependency.
shared.append('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/static-sdk-relocated/lib/libhyle_simd.a')
torch='/Users/kiro/Library/Caches/hyle/dependencies/v1/sdks/torch-cpu/Darwin-be0642231d2008c7b90071fc0898d82a0c002d47f38350ebf3ed779fc01972d7/libtorch/lib'
link=['/usr/bin/clang++','-O3','-DNDEBUG','-arch','arm64','-mmacosx-version-min=14.4']+[j['output']for j in jobs]+shared+native+[torch+'/libtorch.dylib',torch+'/libtorch_cpu.dylib',torch+'/libc10.dylib','-framework','Accelerate','-framework','Foundation','-lpthread','-lm','-Wl,-rpath,'+torch,'-Wl,-map,'+str(D/'image.map'),'-o',str(D/'hyle-cpu')]
plan=dict(kind='Finite current ARM CPU endpoint closure, no new SDK or weight copies',remote=str(D),jobs=jobs,
    shared_public_objects_and_libraries=shared,pure_cpu_native_objects=native,link=link,source_records=records,
    cached_CPU_source_delta=load(S/'mac-cache-delta.json'),cached_CPU_transitive_delta=load(S/'mac-dependency-delta.json'),
    deployment='14.4',model_source='current1 frozen app source with unchanged mathematics',
    current_neutral_public_dependency_catalog=apple['public_dependency_catalog'],
    native_cache_root='/Users/kiro/hyle-scratch/compute-unified/a-cpu/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-e74fc9bb8964d04f',
    source_only_local_overlays=True,HTTP=0,SDK_builds=0,weight_copies=0)
save(S/'mac-cpu-plan.json',plan)
with tarfile.open(S/'mac-cpu-source.tar.gz','w:gz',compresslevel=6)as tar:
    for row in records:tar.add(R/row['identity']['path'],arcname='source/'+row['relative'],recursive=False)
    tar.add(S/'mac-cpu-plan.json',arcname='plan.json',recursive=False)
print(json.dumps(dict(plan=ident(S/'mac-cpu-plan.json'),archive=ident(S/'mac-cpu-source.tar.gz'),fresh_CXX_TUs=len(sources)+1,fresh_native_TUs=2,reused_native_objects=len(native),reused_neutral_inputs=len(shared),source_files=len(records))))
