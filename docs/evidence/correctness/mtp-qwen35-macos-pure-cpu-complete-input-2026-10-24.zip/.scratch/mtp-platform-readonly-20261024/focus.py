"""Second bounded platform cache inspection; never runs a model/build."""
from pathlib import Path
import json
import platform
import subprocess
import hashlib
import re

mac = platform.system() == 'Darwin'
base = Path('/Users/kiro/hyle-scratch/compute-unified' if mac else '/root/hyle-scratch/compute-unified')
def command(argv):
    try:
        p=subprocess.run(argv,capture_output=True,text=True,timeout=20)
        return dict(command=argv,exit=p.returncode,stdout=p.stdout,stderr=p.stderr)
    except Exception as e:return dict(command=argv,error=str(e))
def small(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def listing(p):
    if not p.is_dir():return dict(path=str(p),exists=False)
    return dict(path=str(p),exists=True,entries=[dict(name=q.name,directory=q.is_dir(),bytes=q.stat().st_size)
        for q in sorted(p.iterdir())[:100]])
result=dict(HTTP=0,builds=0,models_started=0,
    matching_top_entries=[x.name for x in sorted(base.iterdir()) if any(s in x.name.lower()
        for s in ('cpu','cuda','qwen','mtp','torch','gdn','cache'))],paths=[],cmake=[],commands=[],small_files=[])
if mac:
    roots=[base/'a-cpu/selected-graph',base/'a-cpu-apple/selected-graph',
        base/'architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/relocated',
        base/'qwen-multik-functional-20261024/attempt1']
else:
    roots=[base/'l-cpu/selected-graph',base/'l-cuda/selected-graph',base/'l-cpu-cuda/selected-graph',base/'linux-current-graph']
    result['commands'].append(command(['/usr/local/cuda/bin/nvcc','--version']))
for root in roots:
    result['paths'].append(listing(root))
    for sub in ['static-sdk-relocated','static-sdk-relocated/lib','shared-sdk-relocated/lib','sdk/lib','source-build',
        'source-build/hyle/src/compute_ggml_runtime','source-build/hyle/src/compute_ggml_runtime/build-release',
        'source-build/hyle/src/compute_ggml_runtime/build-release/src','native','models','inputs']:
        p=root/sub
        if p.is_dir():result['paths'].append(listing(p))
    for sub in ['source-build/CMakeCache.txt','static-sdk-relocated/lib/cmake/hyle/hyleConfig.cmake',
        'static-sdk-relocated/lib/cmake/hyle/HyleDependencies.cmake','build/CMakeCache.txt','CMakeCache.txt']:
        p=root/sub
        if p.is_file():
            lines=[x for x in p.read_text(errors='replace').splitlines() if
                re.search('HYLE_(COMPUTE|GRAPH|ROUTES|BACKENDS)|CMAKE_(CXX_COMPILER|C_COMPILER|CUDA_COMPILER|BUILD_TYPE)|ggml.*cpu|ggml.*cuda',x,re.I)]
            result['cmake'].append(dict(identity=small(p),lines=lines[:180]))
    if root.name=='linux-current-graph':
        for name in ['native-ready.json','compile_commands.json','manifest.json','current-mixed-manifest.json','ready.json','link-plan.json']:
            p=root/name
            if p.is_file() and p.stat().st_size<200000:
                result['small_files'].append(dict(identity=small(p),contents=json.loads(p.read_text())))
if not mac:
    p=base/'qwen-v2-cpu-functional-20261024/input-remap.json'
    result['small_files'].append(dict(identity=small(p),contents=json.loads(p.read_text())))
    result['commands'].append(command(['readelf','-d',str(base/'qwen-v2-cpu-functional-20261024/hyle-linux-cpu')]))
print(json.dumps(result,indent=2))
