"""Explicit single selected check; no implicit model run or retry."""
from pathlib import Path
import importlib.util, json, sys, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('wave_current_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)


def facts(value):
    if isinstance(value, list): return [facts(x) for x in value]
    if isinstance(value, dict):
        return {key: facts(item) for key, item in value.items()
                if not any(x in key for x in ('seconds', 'per_second', 'capture', 'replay', 'trace_name'))}
    return value


def main(name):
    plan = b.read(W / 'build-plan.json'); row = next(x for x in plan['planned_runs'] if x['name'] == ('host' if name == 'host2' else name))
    unit = 'host2' if name == 'host2' else ('probe2' if row['unit'] == 'probe' and (W / 'ready-probe2.json').exists() else row['unit'])
    ready_path = W / ('ready-' + unit + '.json'); ready = b.read(ready_path)
    b.exact(ready['image']); out = W / 'runs' / name
    assert not out.exists(), 'Preserve attempted checks; no automatic rerun'
    if 'fixture_manifest' in row: b.exact(row['fixture_manifest'])
    process = b.h.execute([ready['image']['path'], *row['args']], b.environment(), out, timeout=240)
    stdout = (out / 'stdout.log').read_text(encoding='utf-8-sig')
    result = dict(name=name, process=process, image=ready['image'], ready=b.pin(ready_path))
    if name in ('host', 'host2'):
        assert 'request loop: 11 host contract groups passed; no model/device loaded' in stdout
        result.update(groups=11, model_device_loaded=False)
    else:
        report = json.loads(stdout); b.m.save(out / 'report.json', report)
        result['report'] = b.pin(out / 'report.json')
        if 'compare' in row:
            b.exact(row['compare']); before = b.read(row['compare']['path'])
            if facts(report) != facts(before):
                changed = [key for key in set(facts(report)) | set(facts(before))
                           if facts(report).get(key) != facts(before).get(key)]
                b.m.save(out / 'comparison-failure.json', dict(changed=changed, original=row['compare']))
                raise AssertionError((name, 'complete non-time report changed', changed))
            assert report['live_committed_versions'] == 0
            result.update(complete_non_time_report_equal=True, original=row['compare'],
                          generated_tokens=report['generated_tokens'], actual_graph_calls=report['actual_graph_calls'])
        else:
            assert report['status'] == 'PASS'
            result['scope'] = 'Actual existing tiny CPU Model/Graph consumer; no new continuous pipeline or performance claim'
    result['status'] = 'PASS'; b.m.save(out / 'summary.json', result)
    rows = [b.read(p) for p in sorted((W / 'runs').glob('*/summary.json'))]
    b.m.save(W / 'run-summary.json', dict(status='PASS' if len(rows) == 7 else 'PARTIAL_PASS',
        successful_processes=len(rows), results=rows, no_reruns=True,
        scope='11 host groups plus four synchronous tiny CPU/CUDA ordinary/MTP CLI regressions and two original CPU request cases; no throughput claim'))
    print('PASS ' + name + ' pid=' + str(process['pid']), flush=True)


if __name__ == '__main__':
    try:
        if len(sys.argv) != 2: raise SystemExit('run.py host | cli-NAME | request-loop | request-control')
        main(sys.argv[1])
    except BaseException:
        (W / ('failure-run-' + '-'.join(sys.argv[1:]) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
