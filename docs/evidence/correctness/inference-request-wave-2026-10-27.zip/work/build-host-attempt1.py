"""Prepare three narrow frozen TUs; compile/link only by explicit action.

No compiler, model, GPU, SDK build, closure hash or download during prepare.
"""
from pathlib import Path
import hashlib, importlib.util, json, os, re, sys, traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
B = R / '.scratch/inference-generation-batch-continuation-20261027'
S = R / '.scratch/inference-store-source-range-20261027'
H = R / '.scratch/inference-request-driver-20261026/host'
spec = importlib.util.spec_from_file_location('wave_frozen_reuse', B / 'build.py')
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
m, h = prior.m, prior.h
m.W = W
OVERLAY = W / 'source'
ROOTS = ('include', 'engine', 'src', 'tests')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def pin(path):
    path = Path(path).resolve(); digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20): digest.update(block)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    actual = pin(row['path'])
    assert m.key(actual['path']) == m.key(row['path']) and (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), ('frozen file changed', row['path'])


def project(path):
    path = Path(path).resolve()
    return path.is_relative_to(R) and bool(path.relative_to(R).parts) and path.relative_to(R).parts[0] in ROOTS


def environment():
    env = dict(os.environ); env.update(read(S / 'environment.json'))
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    for key in ('HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE'): env[key] = '1'
    return env


def prepare():
    assert not (W / 'build-plan.json').exists(), 'Preserve frozen attempts'
    model = read(B / 'compile/model1/compiled.json')
    host = read(H / 'plan.json')
    sources = dict(host=R / 'tests/tools/inference_request_loop_test.cc',
                   model=R / 'engine/models/qwen35/main.cc',
                   probe=R / 'tests/tools/qwen_request_lifecycle_test.cc')
    # Only project text is copied now. The retained 224 binary inputs and SDK
    # dependencies are not read/hashed until explicitly scheduled validation.
    project_files = {Path(x).resolve() for x in read(model['compiler_dependencies']['path'])['Data']['Includes'] if project(x)}
    project_files.update(sources.values())
    include_dirs = [R / 'include', R, R / 'engine/models/qwen35', R / 'tests/tools', R / 'src/graph', R / 'src/compute']
    todo = list(project_files)
    while todo:
        source = todo.pop()
        for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"', source.read_text(encoding='utf-8-sig'), re.M):
            target = next((x.resolve() for directory in [source.parent, *include_dirs]
                           if (x := directory / name).is_file()), None)
            if target is not None and project(target) and target not in project_files:
                project_files.add(target); todo.append(target)
    frozen = []
    for source in sorted(project_files):
        target = OVERLAY / source.relative_to(R); target.parent.mkdir(parents=True, exist_ok=True)
        body = source.read_bytes(); target.write_bytes(body)
        original, snapshot = pin(source), pin(target)
        assert (original['bytes'], original['sha256']) == (snapshot['bytes'], snapshot['sha256'])
        frozen.append(dict(original=original, snapshot=snapshot))
    m.save(W / 'source-freeze.json', frozen)
    old_cli = read(S / 'ready-cli2.json'); inputs = read(old_cli['inputs']['path'])
    old_model = model['object']
    entry = next(row for row in inputs if '\\engine\\entry\\unit.obj' in row['path'].lower())
    assert len(inputs) == 224 and sum(row == old_model for row in inputs) == 1
    units = []
    for name, source in sources.items():
        recipe = H / 'compile/command.json' if name == 'host' else B / 'logs/model1/command.json'
        template = read(recipe)['command']; out = W / 'compile' / name; command = []
        for index, arg in enumerate(template):
            if index and template[index - 1].lower() == '/sourcedependencies': arg = str(out / 'dependencies.json')
            elif arg.lower().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
            elif arg.lower().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
            elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = str(OVERLAY / source.relative_to(R))
            elif arg.lower().startswith('/i') and project(arg[2:]): arg = '/I' + str(OVERLAY / Path(arg[2:]).resolve().relative_to(R))
            elif arg.lower() == ('/i' + str(R)).lower(): arg = '/I' + str(OVERLAY)
            command.append(arg)
        command[1:1] = ['/I' + str(OVERLAY / 'include'), '/I' + str(OVERLAY),
                         '/I' + str(OVERLAY / 'engine/models/qwen35'), '/I' + str(OVERLAY / 'tests/tools')]
        assert m.build_contract(command) == m.build_contract(template)
        units.append(dict(name=name, source=pin(source), snapshot=pin(OVERLAY / source.relative_to(R)),
                          recipe=pin(recipe), command=command))
    validation = read(R / '.scratch/inference-mtp-ahead-20261027/build-plan.json')['validation']
    fixture = R / '.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
    planned_runs = [dict(name='host', unit='host', args=[], expected='11 host contract groups; no model/device')]
    for row in validation['CLI_processes']:
        original = B / 'runs' / ('cli-' + row['name']) / 'report.json'
        assert original.is_file()
        planned_runs.append(dict(name='cli-' + row['name'], unit='model', args=row['command'][1:],
                                 compare=pin(original), expected='complete non-time report identical to W6'))
    for flag in ('--request-loop', '--request-control'):
        planned_runs.append(dict(name=flag[2:], unit='probe', args=[flag, str(fixture)],
                                 expected='existing actual CPU Model/Graph case; not host simulation',
                                 fixture_manifest=pin(fixture / 'weights.tsv')))
    m.save(W / 'build-plan.json', dict(status='SOURCE_FROZEN_NOT_COMPILED_OR_RUN', units=units,
        source_freeze=pin(W / 'source-freeze.json'), project_text_files=len(frozen),
        baseline=dict(host=pin(H / 'ready.json'), host_plan=host, cli_ready=pin(S / 'ready-cli2.json'),
                      cli=old_cli, model=model, entry=entry, original_model=old_model,
                      weights_dependencies=read(R / '.scratch/inference-mtp-ahead-20261027/build-plan.json')['baseline']['weights_actual_dependencies']),
        planned_runs=planned_runs,
        counts=dict(planned_CXX=3, planned_links=3, planned_processes=7, CXX=0, links=0, processes=0, SDK=0, NVCC=0, downloads=0),
        scope='Host TU plus current Model TU and existing lifecycle combined probe. CLI uses W12 corrected resources2 and all 223 other original inputs. '
              'Probe derives that exact current 224 closure, removes its separate Model and entry, adds only combined probe (223 total). '
              'No independent old probe Graph/resources closure; no performance, real-model quality or true cross-pump consumer claim. '
              'SDK/system and retained binary closure pins are checked only after GPU scheduling permits it.'))
    print('PREPARED project_text=' + str(len(frozen)) + ' CXX=0 link=0 run=0', flush=True)


def compile_unit(name):
    plan = read(W / 'build-plan.json'); unit = next(x for x in plan['units'] if x['name'] == name)
    for row in read(plan['source_freeze']['path']): exact(row['original']); exact(row['snapshot'])
    exact(unit['recipe']); exact(unit['source']); exact(unit['snapshot'])
    # weights/session_state remains the actually retained ABI owner. Refuse a
    # hidden necessary weight rebuild rather than claiming an old object current.
    for row in read(plan['baseline']['weights_dependencies']['path']): exact(row)
    out = W / 'compile' / name; out.mkdir(parents=True, exist_ok=False)
    process = h.execute(unit['command'], environment(), W / 'logs' / name, timeout=240)
    data = read(out / 'dependencies.json')['Data']
    assert m.key(data['Source']) == m.key(unit['snapshot']['path'])
    assert all(not project(path) for path in data['Includes']), 'live canonical project header leaked past overlay'
    if name == 'probe':
        assert m.key(OVERLAY / 'engine/models/qwen35/main.cc') in {m.key(x) for x in data['Includes']}
    frozen = {m.key(x['snapshot']['path']): x['snapshot'] for x in read(plan['source_freeze']['path'])}
    actual = [pin(x) for x in dict.fromkeys([data['Source'], *data['Includes']])]
    for row in actual:
        if Path(row['path']).is_relative_to(OVERLAY): assert row == frozen[m.key(row['path'])]
    m.save(out / 'actual-dependencies.json', actual)
    m.save(out / 'compiled.json', dict(name=name, source=unit['source'], snapshot=unit['snapshot'],
        object=pin(out / 'unit.obj'), process=process, actual_dependencies=pin(out / 'actual-dependencies.json'),
        compiler_dependencies=pin(out / 'dependencies.json'), command=pin(W / 'logs' / name / 'command.json')))
    print('CXX_PASS ' + name, flush=True)


def link(name):
    plan = read(W / 'build-plan.json'); compiled = read(W / 'compile' / name / 'compiled.json'); exact(compiled['object'])
    if name == 'host':
        old = plan['baseline']['host_plan']; inputs = [compiled['object'], *old['reused_libraries']]
        template = old['link_command']
        old_object = next(x for x in template if x.lower().endswith('.obj'))
        replacements = {m.key(old_object): compiled['object']['path']}; removed = set()
    else:
        original = plan['baseline']['cli']; rows = read(original['inputs']['path'])
        old_model, entry = plan['baseline']['original_model'], plan['baseline']['entry']
        template = read(original['recipe']['path'])['command']
        replacements = {m.key(old_model['path']): compiled['object']['path']}
        removed = {m.key(entry['path'])} if name == 'probe' else set()
        inputs = [compiled['object'] if row == old_model else row for row in rows if m.key(row['path']) not in removed]
        assert len(inputs) == (223 if name == 'probe' else 224)
    for row in inputs: exact(row)
    image = W / 'bin' / {'host': 'request-wave-host.exe', 'model': 'hyle.exe', 'probe': 'qwen-request-lifecycle.exe'}[name]
    image.parent.mkdir(parents=True, exist_ok=True)
    command = []
    for arg in template:
        if m.key(arg) in removed: continue
        if m.key(arg) in replacements: arg = replacements[m.key(arg)]
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:' + str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'): continue
        command.append(arg)
    m.save(W / (name + '-link-inputs.json'), inputs)
    runtime = read(S / 'runtime.json'); native = runtime['original_native_cpu']; exact(native)
    alias = image.parent / Path(native['path']).name
    if not alias.exists(): os.link(native['path'], alias)
    env = environment(); m.save(W / 'environment.json', {key: env.get(key, '') for key in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH')})
    m.save(W / 'runtime.json', dict(original=pin(S / 'runtime.json'), original_native_cpu=native, alias=pin(alias), PATH=env['PATH']))
    process = h.execute(command, env, W / ('link-' + name), timeout=180)
    m.save(W / ('ready-' + name + '.json'), dict(status='LINKED_NOT_RUN', image=pin(image), compiled=compiled,
        link=process, inputs=pin(W / (name + '-link-inputs.json'),), recipe=pin(W / ('link-' + name) / 'command.json'),
        runtime=pin(W / 'runtime.json')))
    print('LINK_PASS ' + name, flush=True)


if __name__ == '__main__':
    try:
        if sys.argv[1:] == ['prepare']: prepare()
        elif len(sys.argv) == 3 and sys.argv[1] in ('compile', 'link'):
            {'compile': compile_unit, 'link': link}[sys.argv[1]](sys.argv[2])
        else: raise SystemExit('prepare | compile host|model|probe | link host|model|probe; no default execution')
    except BaseException:
        (W / ('failure-' + '-'.join(sys.argv[1:]) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
