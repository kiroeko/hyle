"""Offline only: archive the finite wave contract and its actual checks."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, shlex, subprocess, sys, zipfile
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent; R = W.parents[1]
spec = importlib.util.spec_from_file_location('wave_package_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
spec2 = importlib.util.spec_from_file_location('wave_package_compare', W / 'run.py')
run = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(run)
OUT = R / 'docs/evidence/correctness/inference-request-wave-2026-10-27.json'
ZIP = OUT.with_suffix('.zip')


def fixture(directory):
    manifest = directory / 'weights.tsv'; roles = []; bodies = {}
    for line in manifest.read_text(encoding='utf-8-sig').splitlines()[3:]:
        tokens = shlex.split(line)
        if not tokens or not tokens[0].startswith('model.'): continue
        rank = int(tokens[2]); source = Path(tokens[3 + rank]); offset, count = map(int, tokens[4 + rank:6 + rank])
        assert 0 <= offset <= source.stat().st_size and 0 <= count <= source.stat().st_size - offset
        assert source.stat().st_size <= 64 << 20, 'Only the known small untrained fixtures may be hashed here'
        key = str(source.resolve())
        if key not in bodies: bodies[key] = b.pin(source)
        roles.append(dict(name=tokens[0], dtype=tokens[1], shape=list(map(int, tokens[3:3 + rank])),
                          source=key, offset=offset, bytes=count))
    return dict(directory=str(directory), manifest=b.pin(manifest), roles=roles, bodies=list(bodies.values()),
                geometry_line=manifest.read_text(encoding='utf-8-sig').splitlines()[2],
                body_payload_archived=False, untrained=True)


def process(path):
    value = b.read(path); value['receipt'] = b.pin(path)
    value['receipt_written_utc'] = datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()
    return value


def main():
    assert not OUT.exists() and not ZIP.exists(), 'Do not overwrite published evidence'
    summary = b.read(W / 'run-summary.json')
    assert summary['status'] == 'PASS' and summary['successful_processes'] == 7
    compiled = [process(W / 'logs' / name / 'process.json') for name in ('host', 'host2', 'model', 'probe', 'probe2')]
    links = [process(W / ('link-' + name) / 'process.json') for name in ('host', 'host2', 'model', 'probe2')]
    checks = [process(W / 'runs' / name / 'process.json') for name in (
        'host', 'host2', 'cli-cpu-ordinary-b2', 'cli-cpu-mtp-k3-b2', 'cli-cuda-ordinary-b2', 'cli-cuda-mtp-k3-b2',
        'request-loop', 'request-control')]
    assert [x['exit'] for x in compiled] == [0, 0, 0, 2, 0]
    assert all(x['exit'] == 0 for x in links)
    assert [x['exit'] for x in checks] == [1, 0, 0, 0, 0, 0, 0, 0]
    assert '11 host contract groups passed; no model/device loaded' in (W / 'runs/host2/stdout.log').read_text()
    assert 'wave replaced its original exception identity' in (W / 'runs/host/stdout.log').read_text() + (W / 'runs/host/stderr.log').read_text()
    cli = []
    for name in ('cpu-ordinary-b2', 'cpu-mtp-k3-b2', 'cuda-ordinary-b2', 'cuda-mtp-k3-b2'):
        current = b.read(W / 'runs' / ('cli-' + name) / 'report.json')
        result = b.read(W / 'runs' / ('cli-' + name) / 'summary.json')
        original = b.read(result['original']['path'])
        assert run.facts(current) == run.facts(original) and current['live_committed_versions'] == 0
        cli.append(dict(name=name, report=b.pin(W / 'runs' / ('cli-' + name) / 'report.json'),
                        original=result['original'], complete_non_time_report_equal=True,
                        generated_tokens=current['generated_tokens'], actual_graph_calls=current['actual_graph_calls']))
    cases = {}
    for name in ('request-loop', 'request-control'):
        report = b.read(W / 'runs' / name / 'report.json')
        assert report['status'] == 'PASS' and report['fixture'] == 'untrained_A_H64' and report['final_versions'] == 0
        cases[name] = report
    plan = b.read(W / 'build-plan.json')
    freezes = {name: b.read(W / file) for name, file in (
        ('initial', 'source-freeze.json'), ('host2', 'source-freeze-host2.json'), ('probe2', 'source-freeze-probe2.json'))}
    products = {}
    for relative, which in (
        ('engine/inference/request_loop.h', 'initial'), ('engine/models/qwen35/main.cc', 'initial'),
        ('tests/tools/inference_request_loop_test.cc', 'host2'), ('tests/tools/qwen_e4_cache_case.h', 'probe2')):
        row = next(x for x in freezes[which] if b.m.key(x['original']['path']) == b.m.key(R / relative))
        b.exact(row['snapshot']); b.exact(row['original']); products[relative] = row
    fixtures = [fixture(R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'),
                fixture(R / '.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture')]
    b.m.save(W / 'fixture-identities.json', fixtures)
    archive_files = []
    permitted = {'.py', '.json', '.log', '.cc', '.h', '.txt'}
    for path in sorted(W.rglob('*')):
        if path.is_file() and path.suffix.lower() in permitted and '__pycache__' not in path.parts:
            archive_files.append((path, 'work/' + path.relative_to(W).as_posix()))
    # Copy small original controls and manifests, never model payloads or SDKs.
    controls = [Path(x['original']['path']) for x in cli]
    controls += [Path(x['manifest']['path']) for x in fixtures]
    controls += [Path(plan['planned_runs'][1]['args'][plan['planned_runs'][1]['args'].index('--session-schedules') + 1])]
    for index, path in enumerate(controls): archive_files.append((path, 'controls/' + str(index) + '-' + path.name))
    manifest = [dict(archive=arc, **b.pin(path)) for path, arc in archive_files]
    b.m.save(W / 'archive-manifest.json', manifest)
    with zipfile.ZipFile(ZIP, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path, arc in archive_files: archive.write(path, arc)
        archive.write(W / 'archive-manifest.json', 'archive-manifest.json')
    with zipfile.ZipFile(ZIP) as archive:
        assert archive.testzip() is None
        assert all(not x.filename.lower().endswith(('.bin', '.obj', '.exe', '.pdb', '.lib', '.dll', '.safetensors', '.gguf')) for x in archive.infolist())
        assert len(archive.namelist()) == len(archive_files) + 1
        for row in manifest:
            body = archive.read(row['archive'])
            assert len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256']
    record = dict(schema='hyle.inference.request-wave.v1', status='PASS_AFTER_DOCUMENTED_TEST_FIXES',
        generated_utc=datetime.now(timezone.utc).isoformat(),
        git_base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
        product_sources=products,
        implementation=dict(single_contract='RequestWave/RequestCreditGrant/RequestWaveResult plus parallel remaining_reserved span',
            completion_owner='Original model Step/Source only; RequestLoop owns no Completion or device executor',
            logical_progress='advanced/executed does not count native submissions',
            in_flight='Frozen ordered keys and exact output reservation; next pump may advance successor before observing predecessor',
            failure='Preserve actual retirement and committed progress before propagating original exception; subsequent cleanup-only calls grant no fresh credit',
            yield_policy='Explicit policy intent only; no new successors while draining; after original retirement handle EOS/cancel then requeue unfinished survivors without changing turn',
            default_policy='Original synchronous FIFO retained; no automatic fairness policy or extra scheduler'),
        counts=dict(CXX_attempts=5, CXX_pass=4, CXX_fail=1, distinct_TUs=3, links=4, links_pass=4,
                    process_attempts=8, process_pass=7, process_fail=1, final_host_groups=11,
                    CLI_CPU_CUDA_ordinary_MTP=4, actual_CPU_request_cases=2, SDK=0, NVCC=0, downloads=0),
        compiler_processes=compiled, linker_processes=links, check_processes=checks,
        failures=[dict(kind='archive_script_parse_before_execution', evidence=b.pin(W / 'package-attempt1.json'),
                       cause='Reserved Python keyword used as a dictionary keyword; corrected before any archive was written, no compiler or model process.'),
                  dict(kind='setup_before_compiler', evidence=b.pin(W / 'setup-attempt1-before-compiler.log'),
                       cause='Windows c:/C: pin dictionary path case differed; size/SHA were equal. Corrected normalized-path/content comparison before any compiler was started.'),
                  dict(kind='first_host_assertion', process=checks[0],
                       cause='Nonportable cross-rethrow current_exception()==prebuilt exception_ptr assertion failed on MSVC.',
                       correction='Test only checks propagated dedicated derived exception type, fixed payload and what. Adapter still repeatedly returns the same original failure ptr; product contract unchanged.',
                       preserved='Original source/OBJ/image receipts and failed process raw logs retained; separate host2 snapshot/image used.'),
                  dict(kind='existing_E4_helper_compile', process=compiled[3],
                       cause='Old helper passed PagedArenaFrame to removed detail PagedArenaAccess::pages overload.',
                       correction='Public Frame::view() and Footprint::page_prefixes return exact initialized-prefix ReadLease; deleted obsolete detail include.',
                       runtime_boundary='E4 case compiled as part of the existing combined TU but E4 run itself was not executed.')],
        CLI_regressions=cli, CPU_request_cases=cases, fixtures=fixtures,
        build=dict(plan=b.pin(W / 'build-plan.json'), original_overlay_files=len(freezes['initial']),
                   CLI_closure_inputs=224, combined_probe_closure_inputs=223,
                   preserved_graph='W12 corrected resources2 and retained Graph executable, no hidden SDK/Graph rebuild',
                   replacement='CLI replaces only old e006 Model object; combined probe replaces Model and removes separate entry, retaining all other current inputs'),
        archive=b.pin(ZIP), archive_members=len(archive_files) + 1,
        limitations=['Host scripts provide explicit retirement inputs, not evidence of actual GPU overlap.',
                     'Actual CLI/CPU request consumers remain synchronous wrappers; true continuous cross-pump engine plumbing is not complete.',
                     'All model checks use cached untrained tiny fixtures, not trained-model task quality or throughput evidence.',
                     'No new performance, peak memory, Apple/Vulkan, native fault injection or E4 runtime conclusion.'])
    b.m.save(OUT, record)
    b.m.save(W / 'package-result.json', dict(status=record['status'], evidence=b.pin(OUT), archive=b.pin(ZIP), members=len(archive_files) + 1))
    print(json.dumps(b.read(W / 'package-result.json'), indent=2), flush=True)


if __name__ == '__main__': main()
