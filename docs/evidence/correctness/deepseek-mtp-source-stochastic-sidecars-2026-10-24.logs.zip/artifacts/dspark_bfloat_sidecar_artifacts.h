#pragma once
#include <cstddef>
#include <string_view>
// Generated from a COMPLETE real S03 static acquisition; never from cached shape metadata.
namespace dspark_bfloat_sidecar_artifacts {
inline constexpr std::string_view kRepository="unsloth/DeepSeek-V4-Flash-0731-GGUF";
inline constexpr std::string_view kRevision="fbbb5b93fb787c21338159b0af3318bb3f4d9768";
inline constexpr std::string_view kFile="dspark/dspark-DeepSeek-V4-Flash-0731-BF16.gguf";
inline constexpr std::string_view kStaticCatalogueSha256="df5a2d071590bcdbd2e8e32cdb631d8cbe95f9f32d7763a2cb0aa72d30840369";
inline constexpr std::string_view kStaticAcquisitionSha256="6ba3bd9b54b69f119b16174c83aa2f07a5e57ef81919559c81b6c8d5987eeba7";
inline constexpr std::string_view kStaticBundleSha256="fde8f545189f4abd7b077ca20a9c965a50a9b8ff63e7964dabc14a4c257b5c94";
inline constexpr std::string_view kStaticPlanSha256="2e7eb0a9fc9c19995d41d2d41c93dd928c082a3e9e5b756aaf9c26132310e428";
inline constexpr std::string_view kExpertSourcePlanSha256="e3cfe35aec5870034d0b384553fd90b242806e63fedab435d18c16969324984f";
inline constexpr std::string_view kOriginalHeaderSha256="0a530d8e43675e4d83695d2a9397c9179d8a12100ffebc4b55df6a932d0cd185";
inline constexpr std::string_view kOriginalFileETag="\"0afbd396f916269afdf517851203735829c46c4601754671fabccdae23688b2e\"";
inline constexpr std::string_view kVocabularyManifestSha256="7502444e1150da9b5e15e79ec68be087b81c6ad02146d74b9b03a08e465db1e0";
inline constexpr std::size_t kStaticRoles=72,kStaticBytes=1041922972;
inline constexpr std::size_t kOriginalHeaderBytes=5253152,kOriginalFileBytes=11314832480;
} // namespace dspark_bfloat_sidecar_artifacts
