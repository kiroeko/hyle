from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path.cwd();O=R/'.scratch/dspark-sidecar-random-20261024'
q8='--q8' in sys.argv
L=O/'q8' if q8 else O
L.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
cc=json.loads((O/'compile-command.json').read_text(encoding='utf-8'))[0]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=()).env
base=json.loads((R/'.scratch/dspark-random-mtp-20261024/link-command.json').read_text(encoding='utf-8'))
cmd=[];replaced=0
for a in base:
 if a.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
 if a.replace('\\','/').endswith('/dspark-random-mtp-20261024/consumer.obj'):a=str(O/'consumer.obj');replaced+=1
 cmd.append(a)
assert replaced==1
cmd+=['/OUT:'+str(O/'checks.exe'),'/IMPLIB:'+str(O/'checks.lib')]
(L/'link-command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8');start=time.monotonic()
with (L/'link.log').open('wb')as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
(L/'link-process.json').write_text(json.dumps(dict(exit=p.returncode,seconds=time.monotonic()-start)),encoding='utf-8')
print('link',p.returncode,(L/'link.log').read_text(encoding='utf-8',errors='replace')[-3000:]);assert not p.returncode
worker=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
assert hashlib.sha256(worker.read_bytes()).hexdigest()=='6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f'
staged=O/worker.name
if not staged.exists():os.link(worker,staged)
ready=json.loads((R/'.scratch/dspark-random-mtp-20261024/runtime.json').read_text(encoding='utf-8'))
env['PATH']=str(O)+';'+ready['PATH']
for k in list(env):
 if k.startswith('HYLE_DSPARK_'):env.pop(k,None)
source_env=json.loads((R/'.scratch/dspark-gguf-selected-20261023/S03/run-plans/checks10.json').read_text(encoding='utf-8'))['environment']
env.update({k:v for k,v in source_env.items()if k.startswith('HYLE_DSPARK_') and 'WAIT' not in k and 'FRONTIER' not in k})
env.update(HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS='0',HYLE_DSPARK_BFLOAT_FRONTIER_FILE=str(O/'missing-frontier.json'))
if q8:
 roles={'TARGET_ROLES_DIR':'.scratch/glm-mtp-catchup-20261022/original-dspark-target','HISTORY_ROLES_DIR':'.scratch/glm-mtp-seed-cache-20261022/original-dspark-history','MARKOV_DIR':'.scratch/dspark-mtp-integration-20261022/original-markov','CONFIDENCE_BF16':'.scratch/qwen-mtp-next-20261022/original-confidence/conf_proj.weight.bf16','PARAMETER_ROLES_DIR':'.scratch/dspark-original-hc-20261023/original-parameters','SHARED_FFN_DIR':'.scratch/dspark-original-shared-20261023/original-shared','ATTENTION_ROLES_DIR':'.scratch/dspark-original-attention-20261023/original-attention','EXPERT_ROLES_DIR':'.scratch/dspark-original-experts-20261023/original-experts'}
 for key,relative in roles.items():
  assert (R/relative).exists(),relative
  env['HYLE_DSPARK_'+key]=str(R/relative)
(L/'runtime.json').write_text(json.dumps({k:v for k,v in env.items()if k.startswith('HYLE_DSPARK_')or k=='PATH'},indent=2),encoding='utf-8')
files=['tests/compute_models/dspark_original_state_consumer_test.cc','tests/compute_models/dspark_original_state_consumer.h','tests/compute_models/dspark_stochastic_head.h','tests/compute_models/model_sampling_fragment.h','engine/inference/sampling_graph.h','engine/inference/sampling_cursor.h']
identities=[]
for relative in files:
 source=R/relative;target=L/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
 identities.append(dict(path=relative,bytes=source.stat().st_size,sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(L/'sources.json').write_text(json.dumps(identities,indent=2),encoding='utf-8')
case='DSparkOriginalState.CpuRandomQ8MarkovPrefixAndPendingContinue' if q8 else 'DSparkBfloatSidecarState.CpuRandomBfloatMarkovPrefixAndPendingContinue'
cmd=[str(O/'checks.exe'),'--gtest_color=no','--gtest_filter='+case,'--gtest_output=xml:'+str(L/'results.xml')]
(L/'run-command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8');start=time.monotonic()
with (L/'run.log').open('wb')as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=600)
(L/'run-process.json').write_text(json.dumps(dict(exit=p.returncode,seconds=time.monotonic()-start)),encoding='utf-8')
print('run',p.returncode,(L/'run.log').read_text(encoding='utf-8',errors='replace')[-12000:])
