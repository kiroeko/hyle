from pathlib import Path
import hashlib,json,re,zipfile,xml.etree.ElementTree as ET
R=Path.cwd();O=R/'.scratch/dspark-sidecar-random-20261024';E=R/'docs/evidence/correctness'
name='deepseek-mtp-source-stochastic-sidecars-2026-10-24'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(directory):
 root=ET.parse(directory/'results.xml').getroot()
 assert int(root.attrib['tests'])==1 and int(root.attrib['failures'])==0 and int(root.attrib['errors'])==0
 case=root.find('.//testcase');assert case.find('skipped')is None
 props={x.attrib['name']:x.attrib['value']for x in case.findall('.//property')}
 log=(directory/'run.log').read_text(encoding='utf-8')
 sample=re.search(r'sidecar random sampled pending=(\d+) ids=([^ ]+) draw=(\d+)',log)
 commits=[dict(m=int(m),accepted=int(a),consumed=int(c),pending=int(p),draw=int(d))for m,a,c,p,d in re.findall(r'sidecar random commit m=(\d+) accepted=(\d+) consumed=(\d+) pending=(\d+) draw=(\d+)',log)]
 assert len(commits)==2 and commits[0]['m']==2 and commits[1]['m']==0 and commits[1]['draw']==6
 return dict(test=case.attrib['classname']+'.'+case.attrib['name'],tests=1,failures=0,skips=0,backend='CPU',policy=dict(temperature=1,top_k=0,top_p=1),seed=123,stream=7,sampled_sequence_including_current=[int(x)for x in sample[2].strip(',').split(',')],commits=commits,consumed_pending_next=int(props['actual_random_pending_consumed_next']),state_members=int(props['state_members']),random_publications=int(props['random_publications']),actual_pending_continuations=int(props['random_pending_continuations']),sampled_markov_rows=int(props['sampled_markov_rows']),graph_submissions=int(props['actual_submissions']),state_backing_peak_bytes=int(props['state_backing_peak']),state_backing_budget_bytes=int(props['state_backing_budget']),head_storage=props['head_storage'],process=read(directory/'run-process.json'),xml_total_seconds=float(root.attrib['time']),xml_case_seconds=float(case.attrib['time']),sources=read(directory/'sources.json'))
actual={'S03_original_BF16_sidecar':run(O),'original_Q8_sidecar':run(O/'q8')}
actual['original_Q8_sidecar']['image']=read(O/'q8/image.json')
actual['S03_original_BF16_sidecar']['image_identity_boundary']='The one image was reused for the subsequent Q8 TU. Its pre-overwrite binary SHA was not captured; exact run XML/log, run-start changed-source snapshots and matching build/link recipe are retained. No later image SHA is attributed to this run.'
static=read(R/'.scratch/dspark-gguf-selected-20261023/S03/original-static/catalog.json')
vocab=read(R/'.scratch/dspark-gguf-vocabulary-20261023/original-vocabulary/manifest.json')
target=read(R/'.scratch/dspark-original-target-tail-20261023/original-target/catalog.json')
q8=read(R/'.scratch/dspark-original-hc-20261023/original-parameters/acquisition.json')
source_identities=dict(S03={k:static[k]for k in ('repository','revision','original_roles','bundle')},Q8={k:q8[k]for k in ('repository','revision','file','whole_file_bytes','etag','tensor_table_sha256')},shared_vocabulary={k:vocab[k]for k in ('repository','revision','variant','original_roles','source_bytes','complete')},target_tail={k:target[k]for k in ('repository','revision','original_roles','bundle')})
archive=E/(name+'.logs.zip')
kept=[]
for d in [O,O/'q8']:
 for n in ['run.log','results.xml','run-process.json','run-command.json','link-command.json','link-process.json','link.log','runtime.json','sources.json','image.json']:
  p=d/n
  if p.exists():kept.append(p)
 kept.extend(p for p in (d/'source').rglob('*')if p.is_file())
for n in ['compile-command.json','compile-process.json','compile.log','dependencies.json']:
 kept.append(O/n)
kept.extend(p for p in (O/'attempt1-missing-pins').rglob('*')if p.is_file())
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(set(kept)):z.write(p,p.relative_to(O).as_posix())
 for n in ['build-dspark-sidecar-random.py','run-dspark-sidecar-random.py','publish-dspark-sidecar-random.py']:
  z.write(R/'.scratch/qwen35-unsloth-mtp-20261024'/n,'commands/'+n)
 pins=R/'.scratch/dspark-gguf-selected-20261023/S03/generated/dspark_bfloat_sidecar_artifacts.h'
 z.write(pins,'artifacts/dspark_bfloat_sidecar_artifacts.h')
assert zipfile.ZipFile(archive).testzip()is None
record=dict(status='PASS_BOUNDED_ACTUAL_BF16_AND_Q8_SIDECAR_STOCHASTIC_PREFIX_AND_PENDING_CONTINUATION',date='2026-10-24',actual=actual,source_identities=source_identities,
 implementation=['Same dspark_stochastic_head uses source-declared hidden/projection input types, actual readonly BF16 Markov/confidence banks and the common inference sampling math. No separate sampler/executor or source-label/provider route is introduced.','S03: actual F32 hidden and widened BF16 Markov stay visible, then original stored-projection BF16 input boundary precedes F32-product/accum DenseLinearF32.','Legacy Q8: preserve actual F32 hidden/Markov activation and original BF16 weights with F32 product/accum; the new head does not widen the whole weight bank or narrow F32 A. The reused old diagnostic head still has its original implementation.','Each q_i uses Gather at the actual sampled preceding ID; original BF16 Markov row bytes are checked. The actual sampled sequence drives original target40/41/42, full-V head p_i and the common speculative-prefix decision.','First rejection chooses the actual residual-sample output lease and only 1+accepted target rows/history/captures. Complete model/cache/history/carry, pending and SamplingCursor publish together under expected-base StateHead. Target-only then consumes the actual committed pending exactly once.','Stale Head publication is refused, old cursor/version remains unchanged, all StateStore versions/drafts retire at the end. Raw captured-prefix select rejects sampled State so it cannot advance model while forgetting RNG.'],
 build=dict(fresh_consumer_TUs=1,SDK_builds=0,native_rebuilds=0,HTTP_bytes=0,missing_expert_requests=0,current_final_compile='Only this consumer TU was incrementally rebuilt. The recorded final /W4 /WX compile and Q8 image include the raw-select guard and added Q8 test. The earlier S03 run snapshot precedes these two additions; its exercised verified-prefix math is unchanged.',native_cpu_worker=ident(R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'),runtime_scope='Actual CPU execution using an existing CPU+CUDA library closure, not a claim of CPU-only packaging.'),
 initial_failure=dict(status='FAILED_SETUP_NOT_A_FUNCTIONAL_PASS',reason='The first private recipe omitted the already existing generated authenticated S03 pins include directory. SetUpTestSuite explicitly threw and the test skipped; adding the actual generated header include and rebuilding corrected this private preparation mistake. No fake pins, body acquisition or fallback were used.'),
 reused_evidence=['docs/evidence/correctness/deepseek-mtp-source-stochastic-flash-2026-10-24.json','docs/evidence/correctness/deepseek-mtp-source-stochastic-pro-2026-10-24.json','docs/evidence/correctness/mtp-dspark-bfloat-sidecar-target-verifier-2026-10-23.json'],
 boundaries=['Both new natural sidecar fixtures reject the first proposal. They do not claim natural or forced sidecar acceptance/bonus; the same generic conditional decision math and state-commit contract already have actual controlled legal acceptance/bonus and failure/cancel/retry evidence in formal Flash.','Source precision contracts differ deliberately. This does not certify numerical equivalence between BF16, Q8, FP8 or FP4 variants.','Initial target history/cache and upstream layer39 four-stream activation are explicit finite fixtures. This is real source-component inference, not whole43-layer prompt-to-output, task quality, natural acceptance-rate or TPS evidence.','The BF16-vocabulary combination of the same Q8 sidecar is not another new runtime run here. Actual source adapter uses the same raw-F32 logits/hidden/pending interface; existing BF16-head and packed-head contracts remain separately evidenced, without publisher/backend Cartesian testing.','StateStore backing accounting is not physical RSS/VRAM or a total model-memory cap.','One final executable is kept for replay; ZIP contains no binaries, SDK, model/expert weights or copied full source tree.'],
 seams_for_later_architecture=['The original sidecar stem still executes its previous greedy diagnostic head before the new policy head; source-derived head ports should be cold-selected once later.','Formal and GGUF consumers have separate source loading, State-schema and actual-target driver adapters. They now share cursor/math/head, but common stage/publication adapters can remove repeated code while preserving explicit store/codec and trained-bank boundaries.'],archive=ident(archive))
out=E/(name+'.json');out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert read(out)['actual']['original_Q8_sidecar']['commits'][1]['pending']==93208
print(json.dumps(dict(evidence=ident(out),archive=ident(archive))))
