from pathlib import Path
import json,os,sys,subprocess,time
R=Path.cwd();O=R/'.scratch/dspark-sidecar-random-20261024';O.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
base=json.loads((R/'.scratch/dspark-block5-tail-20261024/dspark_original_state_consumer_test-syntax-command.json').read_text(encoding='utf-8'))
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':base[0],'CMAKE_CXX_COMPILER':base[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
cmd=[];skip=False
for a in base:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a=='/Zs' or a.startswith(('/Fo','/Fd')):continue
 cmd.append(a)
cmd+=['/I'+str(R/'.scratch/dspark-gguf-selected-20261023/S03/generated'),'/Fo'+str(O/'consumer.obj'),'/Fd'+str(O/'consumer.pdb'),'/sourceDependencies',str(O/'dependencies.json')]
(O/'compile-command.json').write_text(json.dumps(cmd,indent=2),encoding='utf-8')
start=time.monotonic()
with (O/'compile.log').open('wb') as out:p=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
(O/'compile-process.json').write_text(json.dumps(dict(exit=p.returncode,seconds=time.monotonic()-start)),encoding='utf-8')
print(p.returncode,(O/'compile.log').read_text(encoding='utf-8',errors='replace')[-16000:])
