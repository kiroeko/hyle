#include <hyle/graph/cuda.h>
void probe(){auto factory=&hyle::graph::cuda::create_context;}
