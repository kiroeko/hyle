#include <hyle/compute/apple_batch.h>
#include <hyle/graph/apple.h>
void probe(){hyle::compute::apple::MaterializedBatchInvocation control; auto factory=&hyle::graph::apple::prepare_materialized_batch;}
