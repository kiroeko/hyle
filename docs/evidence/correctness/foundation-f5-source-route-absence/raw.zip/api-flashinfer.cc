#include <hyle/compute/providers/flashinfer.h>
void probe(){auto factory=&hyle::compute::flashinfer::provider;}
