#include <hyle/compute/vulkan_batch.h>
#include <hyle/graph/vulkan.h>
void probe(){hyle::compute::vulkan::MaterializedBatchInvocation control; auto factory=&hyle::graph::vulkan::prepare_materialized_batch;}
