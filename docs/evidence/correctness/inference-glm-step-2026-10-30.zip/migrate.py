"""Separate original GLM model computation from finite scenario oracles."""
from pathlib import Path
import subprocess

W = Path(__file__).resolve().parent
R = W.parents[1]
relative = 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
path = R / relative
original = subprocess.check_output(['git', 'show', '5c39dfda4:' + relative])
(W / 'baseline').mkdir(exist_ok=True)
(W / 'baseline/glm_pro_mtp_state_consumer_test.cc').write_bytes(original)
s = original.decode('utf-8').replace('\r\n', '\n')
s = s.replace('#include <string>\n', '#include <string>\n#include <type_traits>\n')

def replace(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:90], s.count(old), count)
    s = s.replace(old, new)

runtime = (W / 'runtime.inc').read_text(encoding='utf-8')
at = s.index('struct GlmRequestDirectory final')
s = s[:at] + runtime + '\n\n' + s[at:]
replace('            execute(actual.keys[0]);', '            execute(actual.keys[0],actual.credits[0]);')
replace('          const auto execute=[&](hyle::inference::RequestKey key) {',
        '          const auto execute=[&](hyle::inference::RequestKey key,hyle::inference::RequestCreditGrant grant) {')
replace('    std::vector<std::int32_t> selection_emitted;selection_emitted.reserve(2);', '''    std::vector<std::int32_t> selection_emitted;selection_emitted.reserve(2);
    using ModelSteps=GlmStepRuntime<Runtime>;
    std::optional<typename ModelSteps::Target> step_target;
    std::optional<typename ModelSteps::Sampler> step_sampler;
    if(use_target)step_target.emplace(typename ModelSteps::Target{*target_source,*target_step,*target_program,
        upstream_ids,*policy,*policy_program,{*repair_step,*repair_program}});
    if(stochastic)step_sampler.emplace(typename ModelSteps::Sampler{*random_q,*random_decision});
    ModelSteps model_steps{state,owner,queue,*source,cuda,step_target?&*step_target:nullptr,
        step_sampler?&*step_sampler:nullptr,{second_step,second_program},verifier,verifier_program,
        {feedback,skips,repairs,repair_submissions}};''')

start = s.index('      // The ordinary scenario and the request wave call these same original')
end = s.index('      const auto single_current=', start)
s = s[:start] + '''      // Only finite numeric/control observations stay here. Both request and
      // ordinary scenarios call the same actual borrowed model steps.
      const auto check_current=[&](const c::StateVersion &first) {
        if(use_target&&!stochastic) {
          const std::array input{state.member(first,kTargetTap)};
          policy_checked=policy_program->execute(queue,input);
          (void)check_verifier(*policy,policy_checked,values<Tap>(input[0]),false);
        }
      };
      const auto check_verified=[&](const c::StateVersion &first,const c::StateVersion &second) {
        if(use_target) {
          auto taps=values<Tap>(state.member(first,kTargetTap));
          const auto tail=values<Tap>(state.member(second,kTargetTap));
          taps.insert(taps.end(),tail.begin(),tail.end());
          target_ids=check_verifier(verifier,checked,taps,!full_target_checked);full_target_checked=true;
        }
      };
''' + s[end:]
start = s.index('      const auto execute_second=')
end = s.index('      const auto prepare_acceptance=', start)
s = s[:start] + s[end:]
replace('      const auto prepare_acceptance=', '      const auto exercise_acceptance_cancel=')
start = s.index('        auto acceptance=take(state.store.begin(checkpoint),"all-resource K1 Pro acceptance");')
end = s.index('      const auto exercise_prefix_policies=', start)
s = s[:start] + '      };\n' + s[end:]
start = s.index('      const auto continue_from=')
end = s.index('      if(request_directory_demo)', start)
s = s[:start] + s[end:]

for prefix, assignment in [('              ', 'first='), ('        ', 'auto first=')]:
    replace(prefix + assignment + 'execute_first(first_logits);', prefix + '''if(stochastic&&std::ranges::find(limits.eos,state.scalar(base,kPending))!=limits.eos.end())
''' + prefix + '''  throw std::runtime_error("Pro cannot consume an EOS pending token");
''' + prefix + '''EXPECT_THROW(validate_step(state,base,catchup_step),std::runtime_error);
''' + prefix + assignment + '''model_steps.advance(base,{first_step,first_program},7,target_before,stochastic?&first_logits:nullptr);
''' + prefix + '''check_current(first);''')

proposal = '''random_draft=sample_logits(first_logits,initial_random);
                auto sampled=take(state.store.begin(first),"actual original Pro random proposal");
                check(sampled.replace(state.entry(kPending),random_draft[1]),"real NextN categorical I32 feeds target row1");
                first=take(sampled.finalize(),"preserve complete original Pro proposal checkpoint");'''
replace(proposal, '''auto proposed=model_steps.propose(first,first_logits,initial_random);
                random_draft=std::move(proposed.random);first=std::move(proposed.checkpoint);''')
replace(proposal.replace('                ', '          '), '''auto proposed=model_steps.propose(first,first_logits,initial_random);
          random_draft=std::move(proposed.random);first=std::move(proposed.checkpoint);''')

replace('              second=execute_second(first_checkpoint);', '''              auto candidate=model_steps.verify_and_prepare(base,first_checkpoint,random_draft,initial_random,
                  grant,limits,checked,selection_emitted,7);
              second=candidate.second;if(use_target)checked=std::move(candidate.checked);check_verified(first_checkpoint,second);''')
replace('            auto second=execute_second(first_checkpoint);', '''            auto candidate=model_steps.verify_and_prepare(base,first_checkpoint,random_draft,initial_random,
                {.additional=2},limits,checked,selection_emitted,7);
            auto second=candidate.second;if(use_target)checked=std::move(candidate.checked);check_verified(first_checkpoint,second);''')
replace('const auto selected_prefix=select_current_prefix(proposal,random_draft);',
        'const auto &selected_prefix=candidate.selected;', 2)
replace('auto checkpoint=repair_prefix(first_checkpoint,second,decision.consumed_drafts);',
        'auto checkpoint=std::move(candidate.checkpoint);', 2)
replace('              published=prepare_acceptance(head,checkpoint,first,pending);',
        '              exercise_acceptance_cancel(head,checkpoint,first,pending);\n              published=std::move(candidate.version);')
replace('const auto published=prepare_acceptance(head,checkpoint,first,pending);',
        'exercise_acceptance_cancel(head,checkpoint,first,pending);\n            const auto published=std::move(candidate.version);')
replace('auto continued=continue_from(caught,next_step,next_program,',
        'auto continued=model_steps.ordinary(caught,{next_step,next_program},8,', 2)
replace('auto continued=continue_from(second_request.version,step,program,state.member(second_request.version,kTargetTap),second_random.advanced(1));',
        'auto continued=model_steps.ordinary(second_request.version,{step,program},8,state.member(second_request.version,kTargetTap),second_random.advanced(1));')

replace('"finite original request adapter retains its real one-emission natural K1 branch"',
        '"actual GLM grant bounds its selected K1 prefix before publication"')
replace('Shared RequestProgress on the existing real one-emission natural K1 branch and new-request cache fork,',
        'Shared RequestProgress with the actual grant applied to the selected K1 prefix and new-request cache fork,')
path.write_text(s, encoding='utf-8', newline='\r\n')
print('Installed real borrowed model computation; actual request grant enters K1 selection.')
