"""Retain finite model-adapter evidence and current cached link inputs."""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key


def properties(path,name):
    root=ET.parse(path).getroot()
    found=[t for t in root.findall('.//testcase') if t.get('name')==name]
    assert len(found)==1
    return {v.get('name'):v.get('value') for v in found[0].findall('./properties/property')}


def prepare():
    p=read(W/'plan.json')
    reports={name:read(W/'runs'/name/'attempt1/report.json') for name in p['cases']}
    assert all(x['status']=='PASS' and x['tests']==1 and x['failures']==x['skipped']==0 for x in reports.values())
    request=reports['request-cuda']['cases'][0]['properties']
    greedy=reports['greedy-cuda']['cases'][0]['properties']
    anchor=b.STAGE/'runs/glm-cuda/attempt1/results.xml'
    before=properties(anchor,'CudaOriginalTarget77AndNextNRandomVerifierContinuesAtomically')
    differences={name:dict(before=value,after=request.get(name)) for name,value in before.items()
        if name!='request_progress_scope' and request.get(name)!=value}
    assert not differences,differences
    for name,value in [('model_step_credit_preflight_rejections','3'),('model_step_preflight_native_submissions','0')]:
        assert request[name]==greedy[name]==value
    assert request['model_step_stale_cursor_rejected']=='1'
    assert greedy['model_step_grant1_matched_consumed']=='1'
    assert greedy['model_step_grant1_matched_consumed_drafts']=='0' and greedy['model_step_grant1_extra_graphs']=='0'
    receipt=read(W/'compile/glm/receipt.json')
    exact(receipt['object'])
    for item in receipt['source_identities']:exact(item)
    for item in p['retained']:exact(item)
    assert len(p['retained'])==227
    save(W/'analysis.json',dict(status='PASS_FINITE_GLM_STEP_AND_ACTUAL_GRANT_CHECKS',
        gtests=2,failures=0,skipped=0,reports={name:pin(W/'runs'/name/'attempt1/report.json') for name in reports},
        request_original_properties=dict(anchor=pin(anchor),compared=len(before)-1,differences=differences,
            excluded_prose='request_progress_scope',added={k:v for k,v in request.items() if k not in before}),
        greedy_actual_grant1={k:v for k,v in greedy.items() if k.startswith('model_step_')},
        implementation=dict(current_consumer_CXX_TUs=1,successful_compile_invocations=3,
            superseded='First succeeded with LF, second preserved original CRLF, final also restored original ordinary policy-logits oracle via borrowed observation; only final object linked and run.',
            retained_SDK_engine_objects=227,SDK_CXX=0,NVCC=0,downloads=0,performance_experiments=0),
        limits=[
            'Actual finite target77/NextN78 suffix and original RequestLoop, not complete GLM prompt prefill, all78layers, asynchronous GLM batches or server.',
            'Request demo remains synchronous N1 with record output capacity1; actual grant wiring does not claim request grants2.',
            'Greedy matched Top1 controls prove grant1 pending semantics; no natural stochastic accepted=true claim.',
            'CPU/converted variants compile in this TU but are not natively run in this batch. K2 body preserved except initial shared advance, not rerun here.',
            'No new performance, peer, VRAM or native-failure injection window.',
            'Full shared execution architecture and other model adaptation remain incomplete.'
        ]))
    base=read(p['base']['path'])
    current=dict(receipt=pin(W/'compile/glm/receipt.json'),object=receipt['object'])
    base['current_consumers']['glm']=current
    base.update(schema='hyle.glm-step.current-link-base.v1',base=p['base'])
    save(W/'model-link-base.json',base)
    targets=[]
    for path in sorted((W/'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe','.dll','.lib','.exp')
        targets.append(pin(path))
    save(W/'cleanup-targets.json',dict(boundary=str(W/'bin'),targets=targets))
    (W/'product.diff').write_bytes(subprocess.check_output(['git','diff','--','tests/compute_models/glm_pro_mtp_state_consumer_test.cc'],cwd=R))
    print('PASS2 actual cached GLM consumers; original request properties unchanged; cleanup targets',len(targets))


def finish():
    p,a=read(W/'plan.json'),read(W/'analysis.json')
    cleanup=read(W/'cleanup-report.json')
    assert cleanup['status']=='REMOVED_EXACT_FLAT_BATCH_IMAGES'
    shutil.copyfile(R/'test.ps1',W/'cleanup.ps1')
    out=R/'docs/evidence/correctness/inference-glm-step-2026-10-30.json'
    save(out,dict(schema='hyle.correctness.glm-step.v1',date='2026-10-30',
        status='BORROWED_REAL_GLM_STEPS_AND_ACTUAL_GRANT_FINITE_CHECKED',base_commit=p['base_commit'],
        contract=dict(
            model='Borrow original State/Step/programs, Source, Queue, actual target inputs and cursor. Both scenario and RequestLoop directly use ordinary or K1 model computation; no fixed base/random identity is captured in the runtime.',
            grant='Actual RequestWave credit reaches K1 selection. Effective quota=min(original policy quota,actual grant). Zero/cancelled/reserved credit and inconsistent actual cursor reject before verification submission.',
            rng='Selected K1 retains q0/accept1/final2 and complete-state cursor+3; standalone target-only remains cursor+1. A grant1 accepted proposal stays pending, no accepted-row repair or journal catchup.',
            boundaries='Candidate formation is separate from Head/CAS/record publication and postcommit journal maintenance; late failures only observe original committed record. No new owner, executor, callback table or Graph path.',
            observation='Cold real verifier outputs move to the caller; external verifier outputs stay borrowed. The original ordinary full-V oracle uses the same executed policy outputs without another Graph.'),
        source=pin(R/'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'),diff=pin(W/'product.diff'),
        results=a,current_link_base=pin(W/'model-link-base.json'),
        cleanup=dict(script=pin(R/'test.ps1'),archived_script=pin(W/'cleanup.ps1'),manifest=pin(W/'cleanup-targets.json'),result=cleanup),
        evidence_archive=out.with_suffix('.zip').name))
    with zipfile.ZipFile(out.with_suffix('.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in sorted(W.rglob('*')):
            if not path.is_file() or any(x in ('bin','__pycache__') for x in path.relative_to(W).parts):continue
            if path.suffix.lower() in ('.json','.py','.ps1','.cc','.h','.inc','.diff','.log','.xml'):
                z.write(path,path.relative_to(W).as_posix())
    with zipfile.ZipFile(out.with_suffix('.zip')) as z:assert z.testzip() is None
    print('Evidence archived and checked',pin(out.with_suffix('.zip'))['bytes'])


if __name__=='__main__':{'prepare':prepare,'finish':finish}[sys.argv[1]]()
