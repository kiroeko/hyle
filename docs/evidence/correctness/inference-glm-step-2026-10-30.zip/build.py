"""Build the actual GLM component TU against the retained current SDK."""
from pathlib import Path
import importlib.util
import os
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
STAGE = R / '.scratch/inference-stage-resources-20261030'
PREV = R / '.scratch/inference-stage-handoff-20261030'
spec = importlib.util.spec_from_file_location('stage', STAGE / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.s.W = b.s.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key


def prepare():
    base, stage = read(PREV / 'model-link-base.json'), read(STAGE / 'plan.json')
    for item in base['retained']:
        exact(item)
    unit = stage['consumers']['glm']
    consumer = dict(unit, compile=b.s.relocated(unit['compile'], 'glm'))
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    cases = {
        'request-cuda': dict(filter='GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNRandomVerifierContinuesAtomically', tests=1),
        'greedy-cuda': dict(filter='GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNFullVocabularyVerifier', tests=1)
    }
    save(W / 'plan.json', dict(base=pin(PREV / 'model-link-base.json'), base_commit='5c39dfda4',
        retained=base['retained'], runtime=base['runtime'], original_link=base['link'],
        original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        consumers={'glm': consumer}, units={}, cases=cases, environment=stage['environments']['glm'],
        SDK_CXX=0, NVCC=0, downloads=0, performance_experiments=0))
    print('One GLM TU,227 current SDK objects reused; no SDK/NVCC/download/performance.')


def link(attempt):
    p = read(W / 'plan.json')
    receipt = read(W / 'compile/glm/receipt.json')
    for item in [receipt['object'], *p['retained']]:
        exact(item)
    args = []
    for arg in p['original_link']:
        if key(arg) == key(p['original_consumer']):
            arg = receipt['object']['path']
        for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
            if arg.upper().startswith(prefix):
                arg = prefix + str((W / 'bin/glm').with_suffix(suffix))
                break
        args.append(arg)
    args.extend(str(R / '.scratch/build-compute-v2-dev/lib' / x) for x in ('gtest_main.lib', 'gtest.lib'))
    b.s.b.execute(args, W / 'link/glm' / attempt, 240)
    save(W / 'ready-glm.json', pin(W / 'bin/glm.exe'))


def run(name, attempt):
    p = read(W / 'plan.json')
    case = p['cases'][name]
    folder = W / 'runs' / name / attempt
    image = read(W / 'ready-glm.json')
    exact(image)
    save(folder / 'image.json', image)
    os.environ.update(p['environment'])
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
        HYLE_GLM_Q30_WAIT_FOR_EXPERTS='0', HYLE_GLM_MLX_WAIT_FOR_EXPERTS='0', HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS='0')
    b.s.b.execute([image['path'], '--gtest_color=no', '--gtest_fail_fast', '--gtest_filter=' + case['filter'],
        '--gtest_output=xml:' + str(folder / 'results.xml')], folder, 600)
    result = ET.parse(folder / 'results.xml').getroot()
    assert result.get('tests') == str(case['tests']) and result.get('failures') == result.get('errors', '0') == '0'
    assert not result.findall('.//skipped')
    save(folder / 'report.json', dict(status='PASS', tests=case['tests'], failures=0, skipped=0,
        cases=[dict(name=t.get('classname') + '.' + t.get('name'),
            properties={v.get('name'): v.get('value') for v in t.findall('./properties/property')})
            for t in result.findall('.//testcase')]))
    print('PASS', name, flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': b.s.compile_one('glm', sys.argv[2])
    elif action == 'link': link(sys.argv[2])
    elif action == 'run': run(sys.argv[2], sys.argv[3])
    else: raise ValueError(action)
