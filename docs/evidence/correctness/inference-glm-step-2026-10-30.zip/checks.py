"""Finite checks using the actual already computed GLM verifier outputs."""
from pathlib import Path

R = Path(__file__).resolve().parents[2]
path = R / 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
s = path.read_text(encoding='utf-8')
marker = '      const auto single_current='
at = s.index(marker)
checks = '''      const auto native_step_counts=[&] {
        return std::array{source->checked_steps,second_program.native_submissions(),
            target_program?target_program->native_submissions():std::size_t{},
            repair_program?repair_program->native_submissions():std::size_t{},verifier_program.submissions,
            random_decision?random_decision->submissions:std::size_t{}};
      };
      const auto check_step_admission=[&](const c::StateVersion &first_checkpoint,
          std::span<const c::ReadLease> q,hyle::inference::RequestCreditGrant grant) {
        const auto before=native_step_counts();
        const auto versions=state.store.stats().versions;
        for(const auto refused:{hyle::inference::RequestCreditGrant{},
            hyle::inference::RequestCreditGrant{.additional=2,.cancelled=true},
            hyle::inference::RequestCreditGrant{.reserved=1,.additional=1}}) {
          std::vector<std::int32_t> ignored;
          EXPECT_THROW((void)model_steps.verify_and_prepare(base,first_checkpoint,q,initial_random,
              refused,limits,checked,ignored,7),std::runtime_error);
          EXPECT_TRUE(ignored.empty());EXPECT_EQ(native_step_counts(),before);
          EXPECT_EQ(state.store.stats().versions,versions);EXPECT_EQ(state.store.stats().drafts,0u);
        }
        if(stochastic) {
          std::vector<std::int32_t> ignored;
          EXPECT_THROW((void)model_steps.verify_and_prepare(base,first_checkpoint,q,initial_random.advanced(1),
              grant,limits,checked,ignored,7),std::runtime_error);
          EXPECT_TRUE(ignored.empty());EXPECT_EQ(native_step_counts(),before);
          EXPECT_EQ(state.store.stats().versions,versions);EXPECT_EQ(state.store.stats().drafts,0u);
        }
        ::testing::Test::RecordProperty("model_step_credit_preflight_rejections",3);
        ::testing::Test::RecordProperty("model_step_preflight_native_submissions",0);
        ::testing::Test::RecordProperty("model_step_stale_cursor_rejected",stochastic?1:0);
      };
'''
s = s[:at] + checks + s[at:]
old = '              auto candidate=model_steps.verify_and_prepare(base,first_checkpoint,random_draft,initial_random,'
assert s.count(old) == 1
s = s.replace(old, '              check_step_admission(first_checkpoint,random_draft,grant);\n' + old)
old = '            auto candidate=model_steps.verify_and_prepare(base,first_checkpoint,random_draft,initial_random,'
assert s.count(old) == 2  # Indentation substring also occurs in the request branch.
full = '\n' + old
assert s.count(full) == 1
s = s.replace(full, '\n            if(!scenario)check_step_admission(first_checkpoint,random_draft,{.additional=2});' + full)
marker = '            auto second=candidate.second;if(use_target)checked=std::move(candidate.checked);check_verified(first_checkpoint,second);\n'
assert s.count('\n' + marker) == 1
bounded = '''            if(!stochastic&&scenario==1) {
              const auto before=native_step_counts();
              std::vector<std::int32_t> tokens;
              auto bounded=model_steps.prepare_verified(base,first_checkpoint,second,checked,random_draft,
                  initial_random,{.additional=1},limits,tokens,7);
              EXPECT_TRUE(bounded.selected.prefix.first_agrees);
              EXPECT_EQ(bounded.selected.prefix.consumed,1u);EXPECT_EQ(bounded.selected.prefix.consumed_drafts,0u);
              EXPECT_EQ(tokens,(std::vector<std::int32_t>{proposal}));
              EXPECT_EQ(state.scalar(bounded.version,kPending),proposal);
              EXPECT_EQ(state.scalar(bounded.version,kCursor),state.scalar(first_checkpoint,kCursor));
              EXPECT_EQ(state.scalar(bounded.version,kLag),0);
              for(std::size_t slot=0;slot<resource_count;++slot)if(slot!=layout.slot(kPending))
                same_storage(state.physical_member(bounded.version,slot),state.physical_member(first_checkpoint,slot));
              if(use_target)for(const auto entry:{kTargetMain,kTargetCursor,kTargetTap})
                same_storage(state.member(bounded.version,entry),state.member(first_checkpoint,entry));
              EXPECT_EQ(native_step_counts(),before);EXPECT_EQ(image(state,base),base_image);
              ::testing::Test::RecordProperty("model_step_grant1_matched_proposal_pending",proposal);
              ::testing::Test::RecordProperty("model_step_grant1_matched_consumed",1);
              ::testing::Test::RecordProperty("model_step_grant1_matched_consumed_drafts",0);
              ::testing::Test::RecordProperty("model_step_grant1_extra_graphs",0);
            }
'''
s = s.replace('\n' + marker, '\n' + marker + bounded)
path.write_text(s, encoding='utf-8', newline='\r\n')
print('Added actual-credit/RNG preflight and already-verified matched-proposal quota1 checks.')
