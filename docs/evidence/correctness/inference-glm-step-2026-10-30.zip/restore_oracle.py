"""Retain the original ordinary policy-logits oracle outside model math."""
from pathlib import Path

W = Path(__file__).resolve().parent
R = W.parents[1]
product = R / 'tests/compute_models/glm_pro_mtp_state_consumer_test.cc'
old_signature = '      c::ReadLease target_input,Cursor cursor) {'
new_signature = '      c::ReadLease target_input,Cursor cursor,std::vector<c::ReadLease> *observed_policy=nullptr) {'
for path in (W / 'runtime.inc', product):
    s = path.read_text(encoding='utf-8')
    if old_signature in s:
        assert s.count(old_signature) == 1
        s = s.replace(old_signature,new_signature)
        old = '    const auto policy=target->policy_program.execute(queue,input);'
        assert s.count(old) == 1
        s = s.replace(old, '    auto policy=target->policy_program.execute(queue,input);')
        old = '    return take(draft.finalize(),"original complete Pro next target pending and RNG");'
        assert s.count(old) == 1
        s = s.replace(old, '''    auto result=take(draft.finalize(),"original complete Pro next target pending and RNG");
    if(observed_policy)*observed_policy=std::move(policy);
    return result;''')
    else:
        assert new_signature in s
    if path == product:
        marker = '      const auto native_step_counts='
        at = s.index(marker)
        observation = '''      const auto execute_checked_ordinary=[&](const c::StateVersion &from,typename ModelSteps::Stage stage,
          const c::ReadLease &target_input,SamplingCursor cursor) {
        std::vector<c::ReadLease> policy_observation;
        auto continued=model_steps.ordinary(from,stage,8,target_input,cursor,&policy_observation);
        if(use_target)EXPECT_EQ(state.scalar(continued,kTargetCursor),state.scalar(continued,kCursor));
        if(stochastic)(void)check_verifier(*policy,policy_observation,values<Tap>(state.member(continued,kTargetTap)),false);
        return continued;
      };
'''
        assert 'const auto execute_checked_ordinary=' not in s
        s = s[:at] + observation + s[at:]
        assert s.count('model_steps.ordinary(caught,{next_step,next_program},8,') == 2
        s = s.replace('model_steps.ordinary(caught,{next_step,next_program},8,',
                      'execute_checked_ordinary(caught,{next_step,next_program},')
        assert s.count('model_steps.ordinary(second_request.version,{step,program},8,') == 1
        s = s.replace('model_steps.ordinary(second_request.version,{step,program},8,',
                      'execute_checked_ordinary(second_request.version,{step,program},')
    path.write_text(s, encoding='utf-8', newline='\r\n')
print('Original ordinary policy oracle observes the same native outputs; no extra Graph.')
