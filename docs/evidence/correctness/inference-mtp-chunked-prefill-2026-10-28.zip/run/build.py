"""Only current Model and tiny-consumer increments; retained SDK/object closure."""
from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/inference-indexed-store-20261028/build.py')
t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
BASE=R/'.scratch/inference-mtp-ragged-prefill-20261028'
SOURCES={'model':'engine/models/qwen35/main.cc','tiny':'tests/tools/qwen_host_image_test.cc'}
def compile_one(name):
    source=R/SOURCES[name];out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
    old=t.command(BASE/'logs'/name/'command.json');args=[]
    for i,a in enumerate(old):
        if i and old[i-1].casefold()=='/sourcedependencies':a=str(out/'dependencies.json')
        elif a.casefold().startswith('/fo'):a='/Fo'+str(out/'unit.obj')
        elif a.casefold().startswith('/fd'):a='/Fd'+str(out/'unit.pdb')
        elif a.casefold().endswith(('.cc','.cpp','.cxx')):a=str(source)
        args.append(a)
    before=t.pin(source)
    process=t.execute(args,W/'logs'/name,300)
    t.exact(before)
    deps=[t.pin(x) for x in dict.fromkeys(t.dep_paths(out/'dependencies.json'))]
    t.save(out/'actual-dependencies.json',deps)
    t.save(out/'compiled.json',dict(source=before,object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/'logs'/name/'command.json'),actual_dependencies=t.pin(out/'actual-dependencies.json')))
    print('CXX_PASS',name)
def link(name):
    base=t.read(BASE/('ready-'+name+'.json'));rows=t.read(base['inputs']['path'])
    previous=BASE/'compile'/name/'unit.obj';new=t.read(W/'compile'/name/'compiled.json')['object'];t.exact(new)
    assert sum(t.key(x['path'])==t.key(previous) for x in rows)==1
    inputs=[new if t.key(x['path'])==t.key(previous) else x for x in rows]
    for x in inputs:
        path=Path(x['path']);assert path.is_file() and path.stat().st_size==x['bytes'],path
    image=W/'bin'/(name+'.exe');image.parent.mkdir(exist_ok=True);assert not image.exists()
    args=[]
    for a in t.command(base['recipe']['path']):
        if t.key(a)==t.key(previous):a=new['path']
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/MAP:','.map'),('/IMPLIB:','.lib')):
            if a.upper().startswith(prefix):a=prefix+str(image.with_suffix(suffix));break
        args.append(a)
    t.save(W/('inputs-'+name+'.json'),inputs)
    process=t.execute(args,W/'link'/name,240)
    t.save(W/('ready-'+name+'.json'),dict(image=t.pin(image),inputs=t.pin(W/('inputs-'+name+'.json')),
        recipe=t.pin(W/'link'/name/'command.json'),process=process,compiled=t.read(W/'compile'/name/'compiled.json')))
    print('LINK_PASS',name,len(inputs))
if __name__=='__main__':
    if sys.argv[1]=='compile':compile_one(sys.argv[2])
    elif sys.argv[1]=='link':link(sys.argv[2])
    else:raise ValueError(sys.argv[1])
