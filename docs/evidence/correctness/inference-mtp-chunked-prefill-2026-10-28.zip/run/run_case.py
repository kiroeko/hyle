from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/inference-indexed-store-20261028/build.py')
t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
name=sys.argv[1]
binary=W/'bin';binary.mkdir(exist_ok=True)
source=R/'.scratch/inference-slot-cohort-refinement-20261028/bin/hyle_ggml_cpu_gdn_scale_v3.dll'
target=binary/source.name
if not target.exists():os.link(source,target)
assert os.path.samefile(source,target)
fixture=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
if name in ('tiny-cpu','tiny-cuda'):
    backend=name.split('-')[1]
    args=[str(binary/'tiny.exe'),'--'+backend,str(fixture),'--mtp-chunked-prefill']
elif name=='cli-mtp':
    args=[str(binary/'model.exe'),'--inputs',str(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),
        '--session-schedules',str(W/'natural-inputs/sessions.txt'),
        '--capacity','512','--max-sessions','2','--active-sequences','2','--prefix-cache','off',
        '--progress','direct','--replay','auto','--mtp','on','--mtp-max-drafts','1','--backend','cuda',
        '--sampling','greedy','--warmup-shapes','planned','--prefill-chunk-tokens','64']
elif name=='cli-q1':
    args=[str(binary/'model.exe'),'--inputs',str(fixture),
        '--schedule',str(W/'natural-inputs/q1.turns'),'--capacity','16',
        '--max-sessions','1','--active-sequences','1','--prefix-cache','off',
        '--progress','direct','--replay','auto','--mtp','on','--mtp-max-drafts','4',
        '--backend','cuda','--sampling','greedy','--warmup-shapes','planned','--prefill-chunk-tokens','1']
else:raise ValueError(name)
out=W/(name+'-run')
t.execute(args,out,240)
lines=(out/'stdout.log').read_text(encoding='utf-8-sig').splitlines()
reports=[json.loads(line) for line in lines if line.startswith('{')]
assert len(reports)==1,len(reports)
report=reports[0]
t.save(out/'report.json',report)
print(json.dumps(dict(case=name,status=report.get('status','PROCESS_PASS'),
    generated=[x.get('result',{}).get('generated_ids') for x in report.get('sessions',[])],
    packed_calls=report.get('packed_prefill_calls'),cold_exact=report.get('cold_exact_admissions')),indent=2))
