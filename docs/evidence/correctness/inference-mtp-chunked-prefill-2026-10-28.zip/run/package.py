from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];W=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def pin(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):
 with Path(p).open('x',encoding='utf-8') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
sources=['engine/models/qwen35/main.cc','engine/models/qwen35/execution_mode.h',
 'tests/tools/qwen_host_image_test.cc','tests/tools/qwen_mtp_chunked_prefill_case.h']
for p in sources:
 out=W/'source'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((R/p).read_bytes())
tiny={}
for backend in ('cpu','cuda'):
 path=W/('tiny-'+backend+'-run/report.json');a=read(path)
 assert a['status']=='PASS' and a['numerically_equivalent']
 assert a['A']['final_length']==4 and a['A']['final_draw']==1 and a['A']['state_only_commits']==3
 assert a['A']['cancelled_submitted'] and a['A']['ledger_rebuilt_rows']==2
 assert a['B']['final_length']==a['B']['final_frontier']==10 and a['B']['final_draw']==2
 assert a['B']['parts']==[2,2,1] and a['B']['host_restored_pending']==-1
 assert a['partial_restore_byte_equal'] and a['old_checkpoints_byte_unchanged']
 assert a['final_versions']==a['final_images']==a['final_native_episodes']==0
 diffs=a['A']['comparison']['differences']+a['B']['comparison']['differences']
 assert all(d['role']==3 and not d['nonfinite_differences'] for d in diffs)
 tiny[backend]=dict(report=pin(path),status='PASS',
  maximum_absolute_gdn_error=max([d['maximum_absolute'] for d in diffs],default=0),
  Q1=dict(real_commits=4,state_only_commits=3,final_draw=1,cancelled_submitted=True,
   hardware_inflight_at_abort=a['A']['hardware_inflight_at_abort'],ledger_rebuilt_rows=2),
  lag1=dict(parts=[2,2,1],seed_length=5,seed_frontier=4,host_restored_length=7,
   host_restored_pending=-1,final_length=10,final_frontier=10,final_draw=2),
  old_checkpoints_byte_unchanged=True,partial_restore_byte_equal=True,
  state_only_score_sampler_id_ports_absent=True,final_versions=0,final_images=0,final_native_episodes=0)
path=W/'cli-mtp-run/report.json';cli=read(path)
assert cli['mtp'] and cli['packed_prefill_calls']==3 and cli['cold_exact_admissions']==0
assert (cli['packed_prefill_active_rows'],cli['packed_prefill_physical_rows'])==(284,384)
assert [b['input_rows'] for b in cli['batches'][:3]]==[[64,64],[64,64],[26,2]]
for s in cli['sessions']:
 for e in s['ledger'][:2]:assert e['next_id']==-1 and e['after_length']==e['after_frontier'] and e['sampling_draw_before']==e['sampling_draw_after']
assert [s['result']['generated_ids'] for s in cli['sessions']]==[[71093,12305,198,464],[35358,248046]]
qpath=W/'cli-q1-run/report.json';q1=read(qpath)
assert q1['cold_exact_admissions']==0 and len(q1['batches'])==4
assert all(b['role']==5 and b['input_rows']==[1] for b in q1['batches'])
assert [e['next_id'] for e in q1['sessions'][0]['ledger']]==[-1,-1,-1,41]
processes=[]
for p in sorted(W.rglob('process.json')):
 x=read(p);assert x['exit']==0 and not x['timed_out'];processes.append(dict(path=str(p),**x))
target=R/'docs/evidence/correctness/inference-mtp-chunked-prefill-2026-10-28.json'
data=dict(date='2026-10-28',base_commit='e8acf58fe',status='Finite checks passed',
 scope='Natural MTP bounded prefill and StateOnly with original request, ledger, target/draft state and retirement; not full varlen/platform or performance closure.',
 sources=[pin(R/p) for p in sources],
 implementation=['Shared completion eligibility admits teacher-forced MTP Prefill/CatchupPrefill and Single/CatchupSingle; proposal/Verify retain original complete-output contract.',
  'Only final input chunk emits a next token. Intermediate chunks commit original target/draft KV and full state without sampling or a completed prefix.',
  'Cold natural planning uses catchup only on the first real input chunk, actual suffix rows choose Single, and strict replay preserves completion/input offset/finality.',
  'Original partial boundary next_id=-1, complete-prefix gates, transactions, whole Completion and real retirement remain unchanged.'],
 tiny=tiny,
 real_cli=dict(image=read(W/'ready-model.json')['image'],report=pin(path),
  input_lengths=[154,130],query_quantum=64,first_batches=[[64,64],[64,64],[26,2]],
  active_prefill_rows=284,physical_prefill_rows=384,cold_exact_admissions=0,
  generated_ids=[s['result']['generated_ids'] for s in cli['sessions']],second_session_stopped_at_eos=True,
  performance_claim=False),
 natural_Q1=dict(report=pin(qpath),inputs=4,query_quantum=1,max_drafts=4,output_quota=1,
  actual_single_input_calls=4,next_ids=[-1,-1,-1,41],cold_exact_admissions=0),
 numerical_contract='Only recomputed finite F32 GDN payloads use the existing 3e-6 component absolute budget. Other payloads, previous checkpoints and state boundaries remain strict.',
 processes=processes,cost=dict(CXX=2,links=2,consumer_processes=4,SDK_builds=0,NVCC=0,downloads=0),
 remaining=['Other platform/provider/dtype combinations','Shared execution architecture and current full performance comparison'],
 limits=['Direct controlled StateOnly journey runs Single, Prefill and CatchupPrefill; CatchupSingle eligibility is implemented but was not directly executed in this finite case.',
  'Controlled verifier seeds real lag1 state, not a natural acceptance-rate or task-quality claim.',
  'Synthetic tiny test cancellation records actual pending/inflight observation; submission is not a promise the hardware remained busy until abort.',
  'New HostImage session has its own local epoch; only same-owner commit epoch increment is asserted.',
  'No refreshed full performance or cross-engine window.'])
save(target,data)
files={'evidence.json':target}
for p in W.rglob('*'):
 if p.is_file() and p.suffix.lower() in {'.json','.log','.py','.h','.cc','.ids','.turns','.txt'} and '__pycache__' not in p.parts:
  files['run/'+str(p.relative_to(W)).replace('\\','/')]=p
manifest=[dict(name=k,**pin(v)) for k,v in sorted(files.items())]
archive=target.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for k,v in sorted(files.items()):z.write(v,k)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in manifest:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
save(W/'packaged.json',dict(evidence=pin(target),archive=pin(archive),members=len(manifest)+1))
print(json.dumps(read(W/'packaged.json'),indent=2))
