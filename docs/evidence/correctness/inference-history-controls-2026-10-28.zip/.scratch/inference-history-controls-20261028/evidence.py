"""Offline evidence only. Invoke after the root has inspected all actual results."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = Path(r'C:\public\project-hyle\hyle')
DEST = R / 'docs/evidence/correctness/inference-history-controls-2026-10-28'
ARMS = {f'{kind}-{backend}': (case, backend, checks) for kind, case, checks in
    [('replay', 'history-replay', 9), ('control', 'history-control', 2), ('ordinary', 'history-logits', 13)]
    for backend in ('cpu', 'cuda')}
FIELDS = {
    'history-replay': ('history_only', 'strict_K1_K2_greedy_random', 'StateOnly_history',
        'HostImage_same_ledger', 'post_replay_K1_K2', 'full_hit_explicit_C0', 'synthetic_untrained'),
    'history-control': ('history_only', 'cancelled_B2_K2', 'whole_episode_retired',
        'postsubmit_cancel_returned_normally', 'peer_same_key_R1', 'committed_counts_only',
        'escaped_readonly_C0', 'bounded_pool_refusal', 'release_then_retry', 'idle_HostImage_restore',
        'idle_resident_versions_zero', 'old_checkpoints_unchanged'),
    'history-logits': ('derived_vs_manual_B2', 'StateOnly_no_counts_or_draw', 'same_key_HostImage',
        'full_hit_seed_before_frontier', 'synthetic_untrained')}


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
def key(path): return str(Path(path).resolve()).casefold()
def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def exact(row):
    path = Path(row['path']); path = path if path.is_absolute() else R / path
    actual = pin(path)
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']
def process(path):
    result = read(path)
    assert result['state'] == 'TERMINAL' and result['exit'] is not None, path
    return result
def passed(p): return p['exit'] == 0 and p['timed_out'] is False


def main():
    # No missing process, planned count, or failed parser is treated as PASS.
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists()
    frozen = read(W / 'source-freeze.json'); expected = read(W / 'expected-sources.json')
    assert len(expected) == 11 and len(frozen['snapshots']) == 11
    for field in ('expected', 'helper', 'project_dependencies'): exact(frozen[field])
    for row in frozen['snapshots']:
        exact(row['snapshot']); exact(row['original'])
        relative = Path(row['original']['path']).relative_to(R).as_posix()
        assert row['original']['sha256'] == row['snapshot']['sha256'] == expected[relative]
    plan = read(W / 'plan.json'); append_plan = read(W / 'append-plan.json')
    run_plan = read(W / 'run-plan.json')
    assert run_plan['order'] == list(ARMS) and run_plan['actual_planned_models'] == 6 and run_plan['host_processes'] == 1
    for field in ('parser', 'fixture', 'runtime'): exact(run_plan[field])
    for field in ('baseline', 'inputs', 'recipe', 'link', 'old_dependencies', 'retained_stats', 'environment', 'runtime'): exact(plan[field])
    for field in ('recipe', 'link', 'old_dependencies'): exact(append_plan[field])
    baseline_rows = read(plan['inputs']['path']); assert len(baseline_rows) == 228
    retained = [row for row in baseline_rows if key(row['path']) != key(plan['original_object']['path'])]
    assert len(retained) == 227 and plan['weights_retained']['object'] in retained
    builds = []; images = {}
    for unit, count in (('tiny', 228), ('append', 230)):
        ready = read(W / f'ready-{unit}.json'); compiled = read(W / f'compile/{unit}/compiled.json')
        assert ready['compiled'] == compiled
        for row in (ready['inputs'], ready['source_freeze'], compiled['command'], compiled['dependencies'], ready['recipe']): exact(row)
        assert ready['source_freeze']['sha256'] == pin(W / 'source-freeze.json')['sha256']
        rows = read(ready['inputs']['path']); assert len(rows) == count
        other = [row for row in rows if key(row['path']) != key(compiled['object']['path'])]
        assert other == retained + (append_plan['libraries'] if unit == 'append' else [])
        cxx = process(W / f'logs/{unit}/process.json'); link = process(W / f'link/{unit}/process.json')
        assert cxx == compiled['process'] and link == ready['process']
        builds.append(dict(unit=unit, CXX=cxx, link=link, inputs=count))
        images[unit] = dict(image=ready['image'], inputs=ready['inputs'], ready=pin(W / f'ready-{unit}.json'),
            actual_dependencies=pin(W / f'compile/{unit}/dependencies.json'),
            actual_project_dependencies=pin(W / f'compile/{unit}/actual-project-dependencies.json'))
    all_pass = all(passed(b[stage]) for b in builds for stage in ('CXX', 'link'))
    runs = []
    for arm, (case, backend, expected_checks) in ARMS.items():
        out = W / 'runs' / arm; proc = process(out / 'process.json')
        summary = read(out / 'summary.json'); report = read(out / 'report.json')
        exact(summary['report']); exact(summary['source_freeze'])
        assert summary['process'] == proc and summary['arm'] == arm
        raw = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        assert raw == [report], arm
        assert report['case'] == case and report['backend'] == backend and report['models'] == 1
        assert report['final_versions'] == 0 and report['quality_claim'] is False and report['performance_claim'] is False
        assert report['configurations'] == (1 if case == 'history-control' else 2)
        if case == 'history-logits': assert report['draft'] is False and report['K1_K2_greedy_random'] is False
        for field in FIELDS[case]: assert report[field] is True, (arm, field)
        checks = report['state_checks']; assert len(checks) == expected_checks == summary['actual_state_checks']
        for check in checks:
            assert check['boundary_equal'] is True and check['numerically_equivalent'] is True
            assert check['payloads_byte_equal'] is True and check['differences'] == [], (arm, check)
        as_run = read(out / 'as-run.json')
        exact(as_run['ready']); exact(as_run['inputs']); exact(as_run['source_freeze'])
        assert as_run['image'] == images['tiny']['image'] and as_run['process'] == proc and as_run['same_file'] is True
        ok = passed(proc) and summary['status'] == report['status'] == 'PASS'
        all_pass = all_pass and ok
        runs.append(dict(arm=arm, pid=proc['pid'], exit=proc['exit'], seconds=proc['seconds'],
            status='PASS' if ok else 'FAIL', complete_initialized_state_checks=len(checks),
            all_payloads_byte_equal=True, final_versions=report['final_versions']))
    host = process(W / 'runs/append/process.json'); hs = read(W / 'runs/append/summary.json')
    exact(hs['ready']); exact(hs['results']); exact(hs['source_freeze'])
    assert hs['process'] == host and hs['tests'] == 6
    xml = ET.parse(W / 'runs/append/results.xml').getroot()
    assert int(xml.attrib['tests']) == 6
    cases = [case.attrib['name'] for case in xml.iter('testcase')]
    assert len(cases) == 6
    host_ok = passed(host) and hs['status'] == 'PASS' and int(xml.attrib['failures']) == 0 and int(xml.attrib.get('errors', 0)) == 0
    all_pass = all_pass and host_ok
    references = [R / 'docs/evidence/correctness/inference-history-logits-2026-10-28.json',
        R / 'docs/evidence/correctness/inference-history-logits-2026-10-28.zip']
    evidence = dict(status='PASS_BOUNDED_HISTORY_CONTROLS' if all_pass else 'FAILED_HISTORY_CONTROLS',
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        counts=dict(actual_CXX=2, successful_CXX=sum(passed(b['CXX']) for b in builds),
            failed_CXX=sum(not passed(b['CXX']) for b in builds), actual_links=2,
            successful_links=sum(passed(b['link']) for b in builds), actual_model_processes=6,
            successful_model_processes=sum(r['status'] == 'PASS' for r in runs),
            actual_host_processes=1, host_tests=6, successful_host_tests=6 if host_ok else 0,
            actual_runtime_failures=sum(r['exit'] != 0 for r in runs) + int(host['exit'] != 0),
            complete_initialized_state_checks=sum(r['complete_initialized_state_checks'] for r in runs),
            SDK_CXX=0, NVCC=0, downloads=0, automatic_reruns=0),
        implementation=[
            'History-only strict ledger replay preserves sampling identity, same-key HostImage continuation and explicit C0 on full prefix hits. K1/K2 continuation is compared against the same Model with complete initialized state bytes.',
            'A stopped member after real B2/K2 submission causes normal whole-episode retirement without publication. Committed state, ledger, epoch and RNG stay unchanged; the peer continues under its original key. Unknown or erroneous retirement still follows the original error gate.',
            'Escaped readonly C0 aliases occupy the original bounded pool. Refusal preserves conditional counts; releasing aliases permits retry. Checkpoint pins are released before a real zero-resident HostImage park and restore.',
            'Target append, MTP draft append and NextN now share checked append_extent, readonly tail_compatible and original SDK reserve_tail with late-Unavailable rollback. Actual writer authority and retirement remain with the original resources.',
            'Callers reserve dirty capacity after readonly tail reuse eligibility, retaining the target fast path and avoiding unused draft reserve capacity. NextN prepares caller vector capacity before native tail reservation. This is a source-level allocation change, not a measured performance result.'],
        model_runs=runs, host=dict(process=host, status='PASS' if host_ok else 'FAIL', tests=cases),
        builds=builds, actual_images=images, source_pins=expected, source_freeze=pin(W / 'source-freeze.json'),
        dependency_boundary=dict(baseline=plan['baseline'], baseline_inputs=228, retained_objects=227,
            Tiny_inputs=228, append_host_inputs=230, private_objects_replaced_per_link=1,
            retained_weights=plan['weights_retained']['object'],
            scope='Engine-private inline/declaration changes compile in each actual consumer TU. The public SDK and PreparedWeightSource ABI are unchanged; this is not a blanket compatibility proof for every retained header.'),
        preparation_notes=[
            'The initial runtime-plan retained four planned consumers. The separate pinned run-plan expands the executed scope to six Model consumers plus one host process; the initial preparation receipt is preserved unchanged.',
            'Three test API/oracle/lifetime issues were corrected during static review before the first actual build. They are not failed CXX or failed native processes.'],
        limits=[
            'Cached synthetic GA/H64/V64/C16 CPU and CUDA consumers only. No trained-model quality, real model EOS, throughput, other-native-platform, all-shape or all-dtype conclusion.',
            'All 48 complete state comparisons are byte equal. Replay/control/ordinary counts are respectively 9/2/13 per backend. These finite journeys do not exhaust every request cancellation, restore or alias pattern.',
            'Normal requested cancellation and real retirement are exercised. Native fault and unknown retirement are not injected; unchanged source gates are not runtime fault coverage.',
            'History uses Commands with the original full 4*V-byte C0 upload. No graph-capture, sparse-transfer, no-copy or measured allocation/TPS gain is claimed.',
            'Tail compatibility is readonly metadata, not a permission grant. The host late-Unavailable test uses a real unsubmitted read admission; it does not claim an accepted asynchronous native submission.',
            'Durations are process provenance only. No performance window, statistical significance or cross-engine comparison is added.'],
        references=[pin(path) for path in references],
        reproduction=dict(build='python -B '+str(W / 'build.py')+' compile; python -B '+str(W / 'build.py')+' link',
            host='python -B '+str(W / 'host.py')+' compile; python -B '+str(W / 'host.py')+' link; python -B '+str(W / 'run.py')+' host',
            model='python -B '+str(W / 'run.py')+' run ARM', arms=list(ARMS),
            note='Actual output paths are single-use. Reparse existing raw output offline rather than rerunning a successful process.'),
        raw_manifest='manifest.json')
    members = {}; allowed = {'.py', '.json', '.h', '.cc', '.diff', '.log', '.xml'}
    def add(path):
        path = Path(path); assert path.is_file() and path.suffix.lower() in allowed, path
        name = path.relative_to(R).as_posix()
        if name not in members: members[name] = path.read_bytes()
    for path in sorted(W.iterdir()):
        if path.is_file() and path.suffix.lower() in allowed: add(path)
    for sub in ('logs', 'compile', 'link', 'runs'):
        for path in sorted((W / sub).rglob('*')):
            if path.is_file() and path.suffix.lower() in allowed: add(path)
    for row in frozen['snapshots']: add(row['snapshot']['path'])
    base = Path(plan['baseline']['path']).parent
    for path in (Path(plan['baseline']['path']), Path(plan['inputs']['path']), base / 'plan.json',
        R / '.scratch/inference-indexed-store-20261028/build.py',
        R / '.scratch/inference-append-tail-20261028/source-freeze.json', references[0]): add(path)
    diff = []
    for relative in expected:
        before, after = base / 'source' / relative, W / 'source' / relative
        old = before.read_text(encoding='utf-8-sig').splitlines(True) if before.is_file() else []
        new = after.read_text(encoding='utf-8-sig').splitlines(True)
        diff.extend(difflib.unified_diff(old, new, fromfile='baseline/'+relative, tofile='current/'+relative))
    members['source-changes.diff'] = ''.join(diff).encode('utf-8')
    members['evidence-core.json'] = encoded(evidence)
    members['manifest.json'] = encoded(dict(files=[dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        for name, raw in sorted(members.items())], excluded=['EXE/OBJ/EXP/LIB/PDB/DLL', 'SDK/header tree',
        'model/weights payload', 'unrelated docs/license']))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(members.items()): archive.writestr(name, raw)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        assert archive.testzip() is None
        manifest = json.loads(archive.read('manifest.json'))
        assert len(archive.namelist()) == len(manifest['files']) + 1
        for row in manifest['files']:
            raw = archive.read(row['path'])
            assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
    evidence['archive'] = dict(**pin(DEST.with_suffix('.zip')), files=len(members), CRC_and_member_SHA256_verified=True)
    with DEST.with_suffix('.json').open('xb') as stream: stream.write(encoded(evidence))
    print(json.dumps(dict(summary=pin(DEST.with_suffix('.json')), archive=evidence['archive'], counts=evidence['counts']), indent=2))


if __name__ == '__main__': main()
