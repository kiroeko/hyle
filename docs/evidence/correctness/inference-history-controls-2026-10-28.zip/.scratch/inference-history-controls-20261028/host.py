"""One standalone append-transaction TU with the retained current SDK objects."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('controls_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
SOURCE = 'tests/tools/inference_append_transactions_test.cc'
OLD = R / '.scratch/inference-slot-cohort-20261028'


def prepare():
    plan = b.prepared(); before = t.command(OLD / 'logs/test/command.json')
    deps = OLD / 'compile/test/dependencies.json'; actual = t.read(deps)['Data']
    assert t.key(actual['Source']) == t.key(R / 'tests/tools/inference_slot_transactions_test.cc')
    args = []
    for at, arg in enumerate(before):
        if t.key(arg) == t.key(actual['Source']): arg = str(R / SOURCE)
        elif at and before[at - 1].lower() == '/sourcedependencies': arg = str(W / 'compile/append/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/append/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/append/unit.pdb')
        args.append(arg)
    assert '/MD' in args and '/O2' in args and any(t.key(a) == t.key(R / SOURCE) for a in args)
    t.save(W / 'recipe-append.json', dict(command=args, timeout_seconds=240))
    libraries = [t.pin(R / '.scratch/build-compute-v2-dev/lib' / name) for name in ('gtest_main.lib', 'gtest.lib')]
    link = []
    for arg in t.command(plan['link']['path']):
        if t.key(arg) == t.key(W / 'compile/tiny/unit.obj'): arg = str(W / 'compile/append/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/MAP:', '.map'), ('/IMPLIB:', '.lib')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/append').with_suffix(suffix)); break
        link.append(arg)
    link.extend(row['path'] for row in libraries)
    t.save(W / 'link-append.json', dict(command=link, timeout_seconds=240))
    t.save(W / 'append-plan.json', dict(source=str(R / SOURCE),
        recipe=t.pin(W / 'recipe-append.json'), link=t.pin(W / 'link-append.json'),
        old_dependencies=t.pin(deps), libraries=libraries,
        compatibility='Same current 228 Tiny closure: replace its only Model/main TU with append test, add gtest_main/gtest. No copied SDK, weights, old deleted test object, or second engine main. Current public SDK ABI is unchanged.'))
    print('PREPARED append host TU/link')


def prepared():
    p = t.read(W / 'append-plan.json')
    for field in ('recipe', 'link', 'old_dependencies'): t.exact(p[field])
    for row in p['libraries']: t.exact(row)
    return p


def compile_one():
    _, frozen = b.validate(); p = prepared()
    allowed = {t.key(x['path']): x for x in t.read(frozen['project_dependencies']['path'])}
    for row in allowed.values(): t.exact(row)
    out = W / 'compile/append'; out.mkdir(parents=True, exist_ok=False)
    process = t.execute(t.command(p['recipe']['path']), W / 'logs/append', 240)
    b.validate(); actual = []
    for path in dict.fromkeys(t.dep_paths(out / 'dependencies.json')):
        if t.project(path):
            assert t.key(path) in allowed, ('unfrozen append include',str(path))
            t.exact(allowed[t.key(path)]); actual.append(t.pin(path))
    t.save(out / 'actual-project-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / SOURCE), object=t.pin(out / 'unit.obj'),
        process=process, command=t.pin(W / 'logs/append/command.json'), dependencies=t.pin(out / 'dependencies.json')))
    print('CXX PASS append')


def link_one():
    plan, _ = b.validate(); p = prepared(); compiled = t.read(W / 'compile/append/compiled.json'); t.exact(compiled['object'])
    for row in t.read(plan['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns'])
    rows = [compiled['object'] if t.key(row['path']) == t.key(plan['original_object']['path']) else row for row in t.read(plan['inputs']['path'])]
    rows.extend(p['libraries']); assert len(rows) == 230
    (W / 'bin').mkdir(exist_ok=True); t.save(W / 'inputs-append.json', rows)
    process = t.execute(t.command(p['link']['path']), W / 'link/append', 240)
    t.save(W / 'ready-append.json', dict(image=t.pin(W / 'bin/append.exe'), inputs=t.pin(W / 'inputs-append.json'),
        compiled=compiled, process=process, recipe=t.pin(W / 'link/append/command.json'),
        plan=t.pin(W / 'append-plan.json'), source_freeze=t.pin(W / 'source-freeze.json')))
    print('LINK PASS append')


if __name__ == '__main__':
    {'prepare': prepare, 'compile': compile_one, 'link': link_one}[sys.argv[1]]()
