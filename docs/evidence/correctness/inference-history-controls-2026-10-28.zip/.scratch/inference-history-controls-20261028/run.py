"""Finite cached consumers; offline parse never launches a completed process."""
from pathlib import Path
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('controls_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t, R = b.t, b.R
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
ARMS = {f'{kind}-{backend}': (backend, flag, case) for kind,flag,case in
    [('replay','--history-replay','history-replay'), ('control','--history-control','history-control'),
     ('ordinary','--history-ordinary','history-logits')] for backend in ('cpu','cuda')}


def prepare():
    b.prepared()
    t.save(W / 'run-plan.json', dict(parser=t.pin(W / 'run.py'), fixture=t.pin(FIXTURE / 'weights.tsv'),
        runtime=t.pin(W / 'runtime-plan.json'), order=list(ARMS), actual_planned_models=6, host_processes=1,
        scope='Four history control/replay consumers and two ordinary consumers for the shared append migration; one focused original append transaction host suite. Initial Tiny preparation predates the shared append scope.',
        arms={arm:dict(backend=backend,flag=flag,case=case) for arm,(backend,flag,case) in ARMS.items()}))
    print('RUN PLAN: six cached Model consumers and one focused host suite')


def parse(arm):
    backend, _, case = ARMS[arm]; out = W / 'runs' / arm
    process = t.read(out / 'process.json'); assert process['exit'] == 0 and not process['timed_out'], process
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports)==1, len(reports)
    report=reports[0]; assert report['status']=='PASS' and report['case']==case and report['backend']==backend
    assert report['models']==1 and report['final_versions']==0 and not report['performance_claim'] and not report['quality_claim']
    if case=='history-replay':
        assert report['configurations']==2
        fields=('history_only','strict_K1_K2_greedy_random','StateOnly_history','HostImage_same_ledger',
            'post_replay_K1_K2','full_hit_explicit_C0','synthetic_untrained')
    elif case=='history-control':
        assert report['configurations']==1
        fields=('history_only','cancelled_B2_K2','whole_episode_retired','postsubmit_cancel_returned_normally',
            'peer_same_key_R1','committed_counts_only','escaped_readonly_C0','bounded_pool_refusal',
            'release_then_retry','idle_HostImage_restore','idle_resident_versions_zero','old_checkpoints_unchanged')
    else:
        assert report['configurations']==2 and report['draft'] is False and report['K1_K2_greedy_random'] is False
        fields=('derived_vs_manual_B2','StateOnly_no_counts_or_draw','same_key_HostImage','full_hit_seed_before_frontier','synthetic_untrained')
    for field in fields: assert report[field] is True, field
    checks=report['state_checks']; assert checks
    for check in checks:
        assert check['boundary_equal'] and check['numerically_equivalent'] and check['payloads_byte_equal'] and check['differences']==[], check
    t.save(out / 'report.json', report)
    t.save(out / 'summary.json', dict(status='PASS',arm=arm,process=process,actual_state_checks=len(checks),
        complete_payloads_byte_equal=True,report=t.pin(out/'report.json'),source_freeze=t.pin(W/'source-freeze.json')))
    print('PASS',arm,'PID',process['pid'],'state_checks',len(checks))


def run(arm):
    b.validate(); plan=t.read(W/'run-plan.json')
    for field in ('parser','fixture','runtime'):t.exact(plan[field])
    ready=t.read(W/'ready-tiny.json');t.exact(ready['image'])
    native=t.read(W/'runtime-plan.json')['native'];t.exact(native)
    alias=W/'bin'/Path(native['path']).name
    if not alias.exists():os.link(native['path'],alias)
    assert os.path.samefile(native['path'],alias)
    backend,flag,_=ARMS[arm];out=W/'runs'/arm
    assert not out.exists(),'Already attempted; inspect/parse original output'
    process=t.execute([ready['image']['path'],'--'+backend,str(FIXTURE),flag],out,300)
    t.save(out/'as-run.json',dict(ready=t.pin(W/'ready-tiny.json'),image=ready['image'],inputs=ready['inputs'],
        source_freeze=ready['source_freeze'],plan=t.pin(W/'run-plan.json'),native=native,same_file=True,process=process))
    parse(arm)


def host():
    b.validate();ready=t.read(W/'ready-append.json');t.exact(ready['image'])
    out=W/'runs/append';assert not out.exists()
    process=t.execute([ready['image']['path'],'--gtest_filter=InferenceAppendTransactions.*',
        '--gtest_output=xml:'+str(out/'results.xml')],out,120)
    result=ET.parse(out/'results.xml').getroot()
    assert int(result.attrib['tests'])==6 and int(result.attrib['failures'])==0 and int(result.attrib.get('errors',0))==0
    t.save(out/'summary.json',dict(status='PASS',process=process,tests=6,ready=t.pin(W/'ready-append.json'),
        results=t.pin(out/'results.xml'),source_freeze=ready['source_freeze'],performance_claim=False))
    print('PASS six append transaction host tests PID',process['pid'])


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='run':run(sys.argv[2])
    elif action=='parse':parse(sys.argv[2])
    elif action=='host':host()
    else:raise ValueError(action)
