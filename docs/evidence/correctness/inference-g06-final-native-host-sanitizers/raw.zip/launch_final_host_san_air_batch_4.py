from pathlib import Path
import hashlib, json, os, shlex, subprocess, sys, time, zipfile

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g06';OUT=BASE/'final-host-air'
PRODUCT='669121418669b31f6849c74f64362aaf8d6eb919'
assert OUT.is_dir()
prior=json.loads((BASE/'final-host-air-batch-3.json').read_text());assert prior['state']=='TERMINAL_FAIL' and prior['stage']=='vulkan-tsan-1'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',PRODUCT,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
registry=json.loads((ROOT/'docs/implementation/module-status.json').read_text(encoding='utf8'))
owners=[r for r in registry['modules'] if 'inference-g06' in r.get('record','')]
assert len(owners)==11 and all(r['state']=='CANDIDATE' for r in owners)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
receipt=json.loads((ROOT/'evidence/correctness/inference-g06-final-relocated-sdk/receipt.json').read_text(encoding='utf8'))
assert receipt['state']=='PASS_FOUR_ROUTE_RELOCATED_STATIC_SHARED_SDK'
archive=OUT/'source-current.zip'
with zipfile.ZipFile(archive) as package:
    snapshot=json.loads(package.read('snapshot.json'));inputs=json.loads(package.read('source-manifest.json'))
assert snapshot=={'product_candidate':PRODUCT,'head':head}
assert all(hashlib.sha256((ROOT/i['path']).read_bytes()).hexdigest()==i['sha256'] for i in inputs)
worker=BASE/'final_host_san_air.py';(OUT/'runner-resume4.py').write_bytes(worker.read_bytes())
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g06-final-host-air'
subprocess.run(['ssh','-o','BatchMode=yes',host,'mkdir','-p',remote],check=True)
subprocess.run(['scp','-q',str(archive),str(worker),str(BASE/'reuse_current_vulkan_generated.py'),host+':'+remote+'/'],check=True)
record={'state':'RUNNING','product_candidate':PRODUCT,'source_snapshot':head,'stages':[],'prior_failed_batch':prior,'scope':'Only original applicable native host sanitizer qualification of current G06 Apple/Vulkan branches. Nine finite direct targets per original cached profile, six profiles serial, max4 workers. Original TSan boundary models/LSan/driver/private limitations and all old failures retained; no product/SDK/P1 rerun.'}
result_file=BASE/'final-host-air-batch-4.json';assert not result_file.exists()
for route in ['vulkan']:
    for mode in ['tsan']:
        attempt='2';tag=f'{route}-{mode}-{attempt}';start=time.monotonic()
        command=['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15',host,'/usr/bin/python3','-u',remote+'/final_host_san_air.py',route,mode,attempt,'--skip-configure']
        with (OUT/('outer-'+tag+'.log')).open('w',encoding='utf8') as stream:
            process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
            record.update(stage=tag,child_pid=process.pid);result_file.write_text(json.dumps(record,indent=2)+'\n')
            print('G06_SERIAL_AIR_HOST',tag,'ssh pid',process.pid,flush=True)
            for line in process.stdout:
                stream.write(line);stream.flush();print(line,end='',flush=True)
            code=process.wait()
        stage={'stage':tag,'command':command,'exit_code':code,'elapsed_seconds':time.monotonic()-start}
        record['stages'].append(stage);record['state']='TERMINAL_FAIL' if code else 'RUNNING';record.pop('child_pid',None)
        result_file.write_text(json.dumps(record,indent=2)+'\n')
        pack="from pathlib import Path;import zipfile;root=Path("+repr(remote)+");tag="+repr(tag)+";z=zipfile.ZipFile(root/('raw-'+tag+'.zip'),'w',zipfile.ZIP_DEFLATED);[(z.write(p,p.name)) for p in root.iterdir() if p.is_file() and tag in p.name and p.suffix in ['.json','.log','.xml','.cmake','.ninja']];z.close()"
        subprocess.run(['ssh','-o','BatchMode=yes',host,'/usr/bin/python3 -c '+shlex.quote(pack)],check=True)
        raw=OUT/('raw-'+tag+'.zip');subprocess.run(['scp','-q',host+':'+remote+'/raw-'+tag+'.zip',str(raw)],check=True)
        with zipfile.ZipFile(raw) as package:package.extractall(OUT)
        if code:raise SystemExit(code)
record['state']='TERMINAL_PASS';result_file.write_text(json.dumps(record,indent=2)+'\n');print('G06_FINAL_AIR_HOST_BATCH_PASS',flush=True)
