from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time,zipfile
route,mode,attempt=sys.argv[1:4]
assert route in ('apple','vulkan') and mode in ('asan','ubsan','tsan')
BASE=Path('/Users/kiro/hyle-scratch/compute-unified')
SOURCE=BASE/'source-c8874688'
PARENT=BASE/f'foundation-f5-native-host-{route}-{mode}/parent'
BUILD=PARENT.parent/'build'
OUT=BASE/'g06-final-host-air';OUT.mkdir(exist_ok=True)
MODEL_BASE=BASE/'g04-g05-encoded-host-sanitizers'
tag=f'{route}-{mode}-{attempt}';record_file=OUT/f'result-{tag}.json';assert not record_file.exists()
identity={name:subprocess.check_output(args,text=True).strip() for name,args in [
    ('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
    ('compiler',['/Library/Developer/CommandLineTools/usr/bin/clang++','--version']),('memory',['/usr/sbin/sysctl','-n','hw.memsize'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
assert SOURCE.is_dir() and not (SOURCE/'.git').exists() and BUILD.is_dir()
with zipfile.ZipFile(OUT/'source-current.zip') as package:
    snapshot=json.loads(package.read('snapshot.json'));assert snapshot['product_candidate']=='669121418669b31f6849c74f64362aaf8d6eb919'
    inputs=json.loads(package.read('source-manifest.json'))
    for item in inputs:
        relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
        raw=package.read(item['path']);assert hashlib.sha256(raw).hexdigest()==item['sha256']
        file=SOURCE/relative
        if not file.exists() or file.read_bytes()!=raw:
            file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(raw)
cache=(BUILD/'CMakeCache.txt').read_text()
assert f'HYLE_SANITIZER:STRING={mode}' in cache
assert 'HYLE_COMPUTE_ROUTES:STRING=cpu;'+route in cache
cases=[('g06_gpu_san_math',f'tests/compute_route_{route}/native_cache_test.cc',True),
       ('g06_gpu_san_pages','tests/compute_batch/encoded_page_native_consumer.cc',True),
       ('g06_gpu_san_risks',f'tests/compute_batch/native_paged_{route}_risks.cc',False),
       ('g06_gpu_san_plain_risks',f'tests/compute_batch/native_paged_{route}_risks.cc',False),
       ('g06_gpu_san_paged',f'tests/compute_batch/native_paged_{route}_consumer.cc',False),
       ('g06_gpu_san_ragged',f'tests/compute_route_{route}/native_ragged_test.cc',True),
       ('g06_gpu_san_joint','tests/graph_batch/native_paged_joint_consumer.cc',False),
       ('g06_gpu_san_pending','tests/compute_batch/pending_paged_receiver_native_consumer.cc',False),
       ('g06_gpu_san_joint_risks','tests/graph_batch/native_pending_joint_risks.cc',False)]
cmake=PARENT/'CMakeLists.txt';body=cmake.read_text();models=[]
if route=='apple' and 'hyle_apply_sanitizer(mlx)' not in body:body+='\nhyle_apply_sanitizer(mlx)\n'
if mode=='tsan':
    ref=BASE/'g02-refcount-fence-probe/tsan-headers/hyle/util/ref_counted.h'
    text=ref.read_text().replace('#include <sanitizer/tsan_interface.h>\n','').replace('    __tsan_acquire(const_cast<std::atomic<std::uint32_t>*>(&value_));\n','')
    # The already-qualified model needs the particular counter address. Reverse
    # its exact static-to-const method and two call-site edits as well.
    assert text.count('  void acquire_before_destroy() const noexcept {')==1
    assert text.count('      refcount_.acquire_before_destroy();')==2
    text=text.replace('  void acquire_before_destroy() const noexcept {','  static void acquire_before_destroy() noexcept {')
    text=text.replace('      refcount_.acquire_before_destroy();','      decltype(refcount_)::acquire_before_destroy();')
    assert text==(SOURCE/'include/hyle/util/ref_counted.h').read_text(),'Original final-acquire model must match current product exactly'
    assert hashlib.sha256(ref.read_bytes()).hexdigest()=='2b90ab655a49ec3b9158a964872cd1fc3395ebf64d8ae430a2e19c4805bf5416'
    models.append(ref)
    if route=='apple':
        metal=BASE/'g01-metal-callback-tsan-probe/tsan-metal-cpp/Metal/MTLCommandBuffer.hpp'
        assert hashlib.sha256(metal.read_bytes()).hexdigest()=='4a58c6e564e3a7efcdf5c7709eeee99ec7b7c40594e2ada5ec5c91012171d504'
        models.append(metal)
        dependency=json.loads((SOURCE/'cmake/HyleDependencyLock.json').read_text())
        bundle=next(x for x in dependency['dependencies'] if x['name']=='mlx_cast_patches')
        patch_id=bundle['vendored']['tree_sha256'][:16]
        product_metal=MODEL_BASE/f'metal-product-{patch_id}'
        subprocess.run(['python3',str(SOURCE/'src/compute_ggml_runtime/prepare_source.py'),
            '--source',str(Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/metal_cpp-f567ed836e4c-3874e9e28e8e')),
            '--output',str(product_metal),'--manifest',str(SOURCE/'third_party/mlx_cast/metal-shared-ptr.json')],check=True)
        metal_model=MODEL_BASE/f'metal-tsan-{patch_id}'
        if not metal_model.exists():
            shutil.copytree(product_metal,metal_model)
            (metal_model/'Metal/MTLCommandBuffer.hpp').write_bytes(metal.read_bytes())
        for file in product_metal.rglob('*'):
            if file.is_file():
                relative=file.relative_to(product_metal)
                expected=metal.read_bytes() if relative.as_posix()=='Metal/MTLCommandBuffer.hpp' else file.read_bytes()
                assert (metal_model/relative).read_bytes()==expected,str(relative)
        models[-1]=metal_model/'Metal/MTLCommandBuffer.hpp'
        body=re.sub(re.escape(str(MODEL_BASE))+'/metal-tsan-[0-9a-f]{16}',str(metal_model),body)
        marker='# G04 current product Metal headers plus original exact completion model'
        if marker not in body:
            body+='\n'+marker+'\n'
            for target in ('mlx','hyle_compute_route_apple'):
                body+=f'target_include_directories({target} BEFORE PRIVATE "{metal_model}")\n'
for target,name,gtest in cases:
    if f'add_executable({target} ' in body:continue
    body+=f'\nadd_executable({target} "{SOURCE/name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\n'
    body+=f'target_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\n'
    body+=f'target_link_libraries({target} PRIVATE hyle::compute hyle::graph'+(' GTest::gtest_main' if gtest else '')+')\n'
    body+=f'hyle_apply_sanitizer({target})\nhyle_stage_runtime({target})\n'
    if route=='apple' and target=='g06_gpu_san_pages':body+=f'target_compile_definitions({target} PRIVATE HYLE_ENCODED_APPLE=1)\n'
    if target=='g06_gpu_san_risks':body+=f'target_compile_definitions({target} PRIVATE HYLE_ENCODED_PAGE_RISK=1)\n'
    if route=='apple' and target=='g06_gpu_san_joint':body+=f'target_compile_definitions({target} PRIVATE HYLE_JOINT_PAGE_APPLE=1)\n'
    if route=='apple' and target=='g06_gpu_san_joint_risks':body+=f'target_compile_definitions({target} PRIVATE HYLE_JOINT_PAGE_APPLE=1)\n'
    if target=='g06_gpu_san_pending':
        body+=f'target_compile_definitions({target} PRIVATE HYLE_PENDING_NATIVE_RESULT_SOURCE=1 HYLE_PENDING_NATIVE_JOINT_GRAPH=1'+(' HYLE_PENDING_RECEIVER_APPLE=1' if route=='apple' else '')+')\n'
    if mode=='tsan':
        body+=f'target_include_directories({target} BEFORE PRIVATE "{models[0].parents[2]}")\n'
        if route=='apple':body+=f'target_include_directories({target} BEFORE PRIVATE "{metal_model}")\n'
if route=='apple':
    fix='target_compile_definitions(g06_gpu_san_joint_risks PRIVATE HYLE_JOINT_PAGE_APPLE=1)'
    if fix not in body:body+='\n'+fix+'\n'
if cmake.read_text()!=body:cmake.write_text(body)
(OUT/f'parent-{tag}.cmake').write_text(body)
for file in models:
    (OUT/f'model-{tag}-{file.name}').write_bytes(file.read_bytes())
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
result={'state':'RUNNING','route':route,'mode':mode,'identity':identity,'inputs':inputs,'max_jobs':4,'stages':[],'cumulative_seconds':0,
        'product_candidate':snapshot['product_candidate'],'source_snapshot':snapshot,'scope':'G06 actual Air current host sanitizer facets: native paged runtime, ragged update and Vulkan Recorder, original encoded/native/joint/pending and plain/encoded failure/retirement consumers. Same six cached profiles and original explicit TSan boundary models. No new product, native math, LSan/shader/driver/private-pool/SDK/P1 verdict.',
        'models':[{'path':str(file),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()} for file in models]}
if route=='apple' and mode=='asan' and attempt=='2':
    prior=json.loads((OUT/'result-apple-asan-1.json').read_text())
    assert prior['state']=='TERMINAL_FAIL' and prior['stages'][-1]['stage']=='compile'
    assert prior['inputs']==inputs and prior['identity']==identity
    result['prior_failed_attempt']={'path':'result-apple-asan-1.json','stages':prior['stages'],'reason':'Private new joint risk target omitted HYLE_JOINT_PAGE_APPLE selector. No product failure or test ran; reuse same tree and compiled objects, add missing original route definition.'}
commands=[('configure',['/opt/homebrew/bin/cmake','-S',str(PARENT),'-B',str(BUILD)]),
          ('prepare-manifest',['/opt/homebrew/bin/ninja','-C',str(BUILD),'build.ninja'])]
for target,name,testing in cases:
    assert (SOURCE/name).is_file()
commands += [('compile',['/opt/homebrew/bin/cmake','--build',str(BUILD),'--target',*[c[0] for c in cases],'--parallel','4'])]
commands += [(target,[str(BUILD/target)]+(['--gtest_output=xml:'+str(OUT/f'{target}-{tag}.xml')] if testing else [])) for target,name,testing in cases]
if route=='apple' and mode=='ubsan':
    dependency=json.loads((SOURCE/'cmake/HyleDependencyLock.json').read_text())
    bundle=next(x for x in dependency['dependencies'] if x['name']=='mlx_cast_patches')
    derived=BUILD/'hyle/_deps'/('metal-cpp-'+bundle['vendored']['tree_sha256'][:16])/'source'
    binary=OUT/f'metal-lifetime-{tag}'
    commands[2:2]=[
        ('metal-lifetime-compile',['xcrun','clang++','-std=c++20','-O3','-g','-Wall','-Wextra','-Wpedantic','-Werror',
            '-fsanitize=undefined','-fno-sanitize-recover=all','-isystem',str(derived),
            str(SOURCE/'tests/compute_route_apple/metal_shared_ptr_lifetime.cc'),'-framework','Foundation','-framework','Metal','-o',str(binary)]),
        ('metal-lifetime',[str(binary)])]
if '--skip-configure' in sys.argv:commands=commands[1:]
for stage,command in commands:
    if stage=='compile':
        preview=OUT/f'preview-{tag}.ninja';preview.write_bytes((BUILD/'build.ninja').read_bytes())
        if route=='vulkan':
            from reuse_current_vulkan_generated import apply
            result['generated_shader_reuse']=apply(BUILD,preview,OUT,tag)
            command=['/opt/homebrew/bin/ninja','-C',str(BUILD),'-f',str(preview),'-j','4',*[c[0] for c in cases]]
        plan=subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(BUILD),'-f',str(preview),'-n',*[c[0] for c in cases]],env=env,text=True)
        (OUT/f'dry-run-{tag}.log').write_text(plan)
        assert not any(term in plan for term in ['Re-running CMake','Building CUDA object','Generate vulkan shaders']),'Unplanned native rebuild'
    if stage==cases[0][0]:
        rows=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(BUILD),'-t','compdb'],env=env,text=True))
        flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]
        names=[f'src/compute_route_{route}/{route}_materialized_invocation.cc',
               f'src/compute_route_{route}/{route}_copy_program.cc',f'src/graph_route_cpu_{route}/invocation.cc',
               'src/compute_batch/batch_paged_native.cc','src/compute_batch/paged_arena.cc','src/graph/lease_submission.cc','src/graph/leased_invocation.cc','src/graph/executable.cc',*[c[1] for c in cases]]
        if route=='apple':names+=['src/compute_route_apple/apple_mature_float.cc','mlx/fast.cpp','mlx/backend/metal/scaled_dot_product_attention.cpp']
        else:names+=['src/compute_provider_ggml_vulkan/region.cc','ggml-vulkan/ggml-vulkan.cpp']
        checked=[]
        for name in names:
            found=[r for r in rows if r['file'].endswith(name)]
            assert found and all(flag in r['command'] for r in found),name
            checked.extend(found)
        (OUT/f'instrumentation-{tag}.json').write_text(json.dumps(checked,indent=2)+'\n')
    start=time.monotonic();log=OUT/f'{stage}-{tag}.log'
    with log.open('w') as stream:
        process=subprocess.Popen(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'RUNNING','stage':stage,'pid':process.pid,'log':str(log)}))
        print(tag,stage,'pid',process.pid,flush=True);code=process.wait()
    elapsed=time.monotonic()-start
    result['stages'].append({'stage':stage,'command':command,'exit_code':code,'elapsed_seconds':elapsed,'log':str(log)})
    result['cumulative_seconds']+=elapsed;result['state']='TERMINAL_FAIL' if code else 'RUNNING'
    record_file.write_text(json.dumps(result,indent=2)+'\n')
    print(tag,stage,'exit',code,'elapsed',round(elapsed,3),flush=True)
    if code:
        (OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_FAIL','exit_code':code}));raise SystemExit(code)
artifacts=[]
for path in sorted(BUILD.rglob('*')):
    if path.is_file() and (path.name in {c[0] for c in cases} or (path.name.startswith('libhyle') and path.suffix in ['.a','.dylib'])):
        artifacts.append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(OUT/f'artifacts-{tag}.json').write_text(json.dumps(artifacts,indent=2)+'\n')
assert len([p for p in artifacts if Path(p['path']).name in {c[0] for c in cases}])==len(cases)
assert all(hashlib.sha256((SOURCE/i['path']).read_bytes()).hexdigest()==i['sha256'] for i in inputs)
if route=='vulkan':assert all(hashlib.sha256(Path(i['path']).read_bytes()).hexdigest()==i['sha256'] for i in result['generated_shader_reuse']['copied'])
result['state']='TERMINAL_PASS';record_file.write_text(json.dumps(result,indent=2)+'\n')
(OUT/f'job-{tag}.json').write_text(json.dumps({'state':'TERMINAL_PASS','exit_code':0}))
