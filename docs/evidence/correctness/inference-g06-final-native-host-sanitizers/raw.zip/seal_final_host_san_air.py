from pathlib import Path
import datetime, hashlib, json, shlex, subprocess, xml.etree.ElementTree as ET, zipfile

ROOT=Path.cwd();BASE=ROOT/'.scratch/inference-gaps/g06';FOLDER=BASE/'final-host-air'
OUT=ROOT/'evidence/correctness/inference-g06-final-native-host-sanitizers'
PRODUCT='669121418669b31f6849c74f64362aaf8d6eb919'
assert not OUT.exists()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',PRODUCT,'HEAD','--','include','src','cmake','CMakeLists.txt'],text=True).strip()
matrix=json.loads((BASE/'final-host-air-batch-4.json').read_text());assert matrix['state']=='TERMINAL_PASS' and len(matrix['stages'])==1
prior_matrix=json.loads((BASE/'final-host-air-batch-2.json').read_text());assert prior_matrix['state']=='TERMINAL_FAIL' and prior_matrix['stage']=='vulkan-asan-1'
assert all(r['exit_code']==0 for r in prior_matrix['stages'][:3])
prior_vulkan=json.loads((BASE/'final-host-air-batch-3.json').read_text());assert prior_vulkan['state']=='TERMINAL_FAIL' and prior_vulkan['stage']=='vulkan-tsan-1'
assert all(r['exit_code']==0 for r in prior_vulkan['stages'][:2])
native={};raw_files=set()
for route in ['apple','vulkan']:
    for mode in ['asan','ubsan','tsan']:
        attempt='2' if mode=='asan' or (route=='vulkan' and mode=='tsan') else '1';tag=f'{route}-{mode}-{attempt}'
        result=json.loads((FOLDER/f'result-{tag}.json').read_text())
        assert result['state']=='TERMINAL_PASS' and result['product_candidate']==PRODUCT
        assert result['identity']['model']=='Mac16,12' and result['identity']['arch']=='arm64'
        assert all(s['exit_code']==0 for s in result['stages'])
        for row in result['inputs']:
            assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
        commands=json.loads((FOLDER/f'instrumentation-{tag}.json').read_text())
        flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]
        assert commands and all(flag in c['command'] for c in commands)
        targets=[s for s in result['stages'] if s['stage'].startswith('g06_gpu_san_')]
        assert len(targets)==9 and len({s['stage'] for s in targets})==9
        tests={}
        for part,count in [('math',13 if route=='apple' else 11),('pages',4 if route=='apple' else 3),('ragged',3)]:
            tree=ET.parse(FOLDER/f'g06_gpu_san_{part}-{tag}.xml').getroot()
            assert int(tree.attrib['tests'])==count
            assert all(tree.attrib.get(k,'0')=='0' for k in ['failures','errors','disabled']) and not list(tree.iter('skipped'))
            names=[c.get('classname')+'.'+c.get('name') for c in tree.iter('testcase')]
            assert len(names)==count
            tests[part]={'tests':count,'failures':0,'skips':0,'cases':names}
        assert any('PublicRuntimeKvUpdatesKeepIndependentSlotsAndCheckedBoundaries' in n for n in tests['ragged']['cases'])
        plan=(FOLDER/f'dry-run-{tag}.log').read_text()
        assert not any(t in plan for t in ['Re-running CMake','Building CUDA object','Generate vulkan shaders'])
        native[tag]={'route':route,'mode':mode,'attempt':attempt,'identity':result['identity'],'source_snapshot':result['source_snapshot'],'tests':tests,'standalone_targets':[s['stage'] for s in targets if s['stage'] not in ['g06_gpu_san_math','g06_gpu_san_pages','g06_gpu_san_ragged']],'stages':result['stages'],'stage_seconds':result['cumulative_seconds'],'models':result['models'],'prior_failed_attempt':result.get('prior_failed_attempt'),'generated_shader_reuse':result.get('generated_shader_reuse')}
        for p in FOLDER.iterdir():
            if p.is_file() and tag in p.name and p.suffix in ['.json','.log','.xml','.cmake','.ninja']:
                raw_files.add(p)
prior=json.loads((FOLDER/'result-apple-asan-1.json').read_text());assert prior['state']=='TERMINAL_FAIL'
for p in FOLDER.iterdir():
    if p.is_file() and 'apple-asan-1' in p.name and p.suffix in ['.json','.log','.xml','.cmake','.ninja']:
        raw_files.add(p)

# Exact runtime binaries and the original explicit TSan model bytes are
# rechecked on the actual Air; no product sync, rebuild or test rerun.
remote='/Users/kiro/hyle-scratch/compute-unified/g06-final-host-air'
check=r'''
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
base=Path(sys.argv[1]);tags=json.loads(sys.argv[2]);answer={}
for tag in tags:
 record=json.loads((base/('result-'+tag+'.json')).read_text())
 artifacts=json.loads((base/('artifacts-'+tag+'.json')).read_text())
 for a in artifacts:
  p=Path(a['path']);assert p.is_file() and p.stat().st_size==a['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==a['sha256'],p
 for a in record['models']:
  assert hashlib.sha256(Path(a['path']).read_bytes()).hexdigest()==a['sha256']
 wrappers=[]
 if tag.startswith('vulkan'):
  proof=record['generated_shader_reuse'];assert proof['state']=='PASS_CURRENT_INPUT_GENERATED_SHADER_DATA_REUSE_ONLY' and len(proof['copied'])==152
  for a in proof['copied']:
   assert hashlib.sha256(Path(a['path']).read_bytes()).hexdigest()==a['sha256']==hashlib.sha256(Path(a['source']).read_bytes()).hexdigest()
  build=next(Path(a['path']).parent for a in artifacts if Path(a['path']).name=='g06_gpu_san_paged')
  commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],text=True))
  wrappers=[r for r in commands if r['file'].endswith('.comp.cpp')]
  flag='-fsanitize='+('address' if '-asan-' in tag else 'undefined' if '-ubsan-' in tag else 'thread')
  assert len(wrappers)==151 and all(flag in r['command'] for r in wrappers)
  (base/('generated-instrumentation-'+tag+'.json')).write_text(json.dumps(wrappers,indent=2)+'\n')
 answer[tag]={'artifacts':len(artifacts),'artifact_bytes':sum(a['bytes'] for a in artifacts),'models':len(record['models']),'instrumented_generated_cpp_wrappers':len(wrappers)}
with zipfile.ZipFile(base/'final-models.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in base.iterdir():
  if p.is_file() and ((p.name.startswith('model-') and p.suffix in ['.h','.hpp']) or p.name.startswith('generated-instrumentation-')):
   z.write(p,p.name)
print(json.dumps(answer))
'''
recheck=json.loads(subprocess.check_output(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','/usr/bin/python3 -c '+shlex.quote(check)+' '+shlex.quote(remote)+' '+shlex.quote(json.dumps(list(native)))],text=True))
link_failure=json.loads((FOLDER/'result-vulkan-tsan-1.json').read_text())
assert link_failure['state']=='TERMINAL_FAIL' and link_failure['stages'][-1]['exit_code']==1
actual_tsan=json.loads((FOLDER/'result-vulkan-tsan-2.json').read_text())
assert actual_tsan['inputs']==link_failure['inputs'] and actual_tsan['identity']==link_failure['identity']
assert actual_tsan['source_snapshot']==link_failure['source_snapshot']
cleanup=json.loads((FOLDER/'disk-cleanup.json').read_text());assert cleanup['state']=='CLEANED_DISPOSABLE_SEALED_VALIDATION_OUTPUTS'
for p in FOLDER.iterdir():
    if p.is_file() and any(tag in p.name for tag in ['vulkan-asan-1','vulkan-tsan-1']) and p.suffix in ['.json','.log','.cmake','.ninja','.xml']:
        raw_files.add(p)
raw_files.add(FOLDER/'disk-cleanup.json');raw_files.add(BASE/'cleanup_sealed_air_validation.py')
models=FOLDER/'final-models.zip';subprocess.run(['scp','-q','kiro@172.22.10.198:'+remote+'/final-models.zip',str(models)],check=True);raw_files.add(models)
for tag,answer in recheck.items():native[tag]['artifact_recheck']=answer
for name in ['final_host_san_air.py','final_host_san_air-first-joint-macro-failed.py','launch_final_host_san_air_batch.py','launch_final_host_san_air_batch_2.py','launch_final_host_san_air_batch_3.py','launch_final_host_san_air_batch_4.py','final_host_san_air-before-vulkan-generation-guard.py','reuse_current_vulkan_generated.py','final-host-air-batch-1.json','final-host-air-batch-2.json','final-host-air-batch-3.json','final-host-air-batch-4.json']:
    raw_files.add(BASE/name)
raw_files.add(Path(__file__).resolve())
OUT.mkdir(parents=True)
with zipfile.ZipFile(OUT/'raw.zip','x',zipfile.ZIP_DEFLATED) as package:
    for p in sorted(raw_files):package.write(p,p.relative_to(BASE).as_posix())
receipt={'state':'PASS_SIX_CURRENT_NATIVE_HOST_SANITIZER_FACETS','product_candidate':PRODUCT,'source_snapshot':matrix['source_snapshot'],'record':'docs/implementation/tasks/compute/inference-g06-metadata-decode.md','configurations':native,'failed_attempt':{'tag':'apple-asan-1','reason':'Private new joint-risk target omitted original HYLE_JOINT_PAGE_APPLE selector, compile failed before any tests. Only fixture CMake definition corrected; same tree/compiled objects reused.','stages':prior['stages'],'stage_seconds':prior['cumulative_seconds']},'prior_vulkan_prebuild_guard_failure':{'stage':prior_matrix['stages'][-1],'reason':'Current derived ggml source namespace required shader generation in the old sanitizer cache. Guard stopped before compile; current SDK generated shader data reused only after exact input/features/normalized commands proof. No compiled objects or archives borrowed; all151 data-wrapper C++ TUs retain each sanitizer.'},'disk_full_link_failure':{'stages':link_failure['stages'],'scope':'Vulkan TSan1 errno28 at linker, no tests started; same successful configure and objects reused for TSan2 after disposable validation cleanup, no product change or budget reset.'},'disposable_cleanup':cleanup,'serial_stages':prior_matrix['stages']+prior_vulkan['stages']+matrix['stages'],'raw_sha256':hashlib.sha256((OUT/'raw.zip').read_bytes()).hexdigest(),'limits':['Actual MacBook Air Mac16,12 arm64 only. Host ASan/UBSan/TSan facets cover the changed Apple/Vulkan branches; WSL facets remain separate. No LSan/shader/driver/private-pool byte bound or instrumentation claim.','TSan uses the original separately qualified final-refcount-acquire model and, on Apple, original Metal command-buffer commit/completion boundary annotation. Exact reversal/product-derived tree identity is checked by the inherited helper and exact model SHAs rechecked at sealing. No race suppressions or product modifications.','Nine finite declared targets per cached profile: actual paged runtime, ragged update/Recorder, native CacheEncode/attention, public encoded pages, plain/encoded failure/retirement, CPU/native/CPU, native-producer pending64 and pending joint risks. Original source/static/shared and common WSL tests retain their own qualification scopes.','Stages overlap serial wrapper totals. Original first compile failure19.743s and configuration costs retained, no budget reset. Investigation/edit/pack/launch costs without measurement remain UNKNOWN.','Vulkan uses152 current-input shader-data files from the already qualified current static SDK after exact shader input tree/features/generator-command equivalence. Only disposable validation manifest generation/helper edges are replaced; all product/native C++ and151 generated-data wrapper TUs compile with each sanitizer. No GPU shader regeneration or cross-sanitizer object/archive borrowing.', 'No new P1, G04/G05 performance acceptance, complete G06 or whole G01-G10 acceptance.'],'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'state':receipt['state'],'configurations':len(native),'gtests_per_apple':20,'gtests_per_vulkan':17,'standalone_per_config':6,'artifacts':recheck,'raw_files':len(raw_files)}))
