from pathlib import Path
import hashlib, json, re, subprocess


def apply(build, preview, out, tag):
    """One finite G06 validation reuse of current, already-qualified GLSL data.

    Only generated C++ shader DATA are borrowed. Every original product/native
    C++ TU is still compiled normally with this profile's sanitizer.
    """
    sdk=Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-vulkan/selected-graph/static-sdk-build')
    identity='5909b243d5fdb965'
    own_source=build/f'hyle/src/compute_ggml_runtime/source-{identity}'
    sdk_source=sdk/f'src/compute_ggml_runtime/source-{identity}'
    own_generated=build/'hyle/src/compute_ggml_runtime/vendor/src/ggml-vulkan'
    sdk_generated=sdk/'src/compute_ggml_runtime/vendor/src/ggml-vulkan'
    own_cfg=build/f'hyle/_deps/gg-{identity}/tmp/vulkan-shaders-gen-cfgcmd.txt'
    sdk_cfg=sdk/f'_deps/gg-{identity}/tmp/vulkan-shaders-gen-cfgcmd.txt'
    assert own_cfg.read_text().replace(str(build),'@BUILD')==sdk_cfg.read_text().replace(str(sdk),'@BUILD')
    rows=[]
    for path in sorted((sdk_source/'src/ggml-vulkan/vulkan-shaders').rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(sdk_source);data=path.read_bytes()
        assert (own_source/relative).read_bytes()==data,relative
        rows.append({'path':relative.as_posix(),'sha256':hashlib.sha256(data).hexdigest()})
    own_files={p.relative_to(own_source).as_posix() for p in (own_source/'src/ggml-vulkan/vulkan-shaders').rglob('*') if p.is_file()}
    assert own_files=={r['path'] for r in rows} and len(rows)>100
    pattern=re.compile(r'^build (.+?): (\S+)([^\n]*)\n((?:  [^\n]*\n)*)',re.M)
    sdk_manifest=(sdk/'build.ninja').read_text()
    original=preview.read_text()
    def generated_edges(text):
        return {re.search(r'^  DESC = (Generate vulkan shaders[^\n]*)$',m[4],re.M)[1]:m for m in pattern.finditer(text) if re.search(r'^  DESC = Generate vulkan shaders',m[4],re.M)}
    own_edges=generated_edges(original);sdk_edges=generated_edges(sdk_manifest)
    assert len(own_edges)==len(sdk_edges)==152 and own_edges.keys()==sdk_edges.keys()
    def normalize(command,root,source,generated):
        command=command.split(' && /opt/homebrew/bin/cmake -E cmake_transform_depfile ',1)[0]
        return command.replace(str(source),'@SOURCE').replace(str(generated),'@GENERATED').replace(str(root),'@BUILD')
    copied=[]
    for name,m in own_edges.items():
        other=sdk_edges[name]
        command=re.search(r'^  COMMAND = ([^\n]+)$',m[4],re.M)[1]
        sdk_command=re.search(r'^  COMMAND = ([^\n]+)$',other[4],re.M)[1]
        assert normalize(command,build,own_source,own_generated)==normalize(sdk_command,sdk,sdk_source,sdk_generated),name
        filename='ggml-vulkan-shaders.hpp' if name=='Generate vulkan shaders header' else name.removeprefix('Generate vulkan shaders for ')+'.cpp'
        src=sdk_generated/filename;dst=own_generated/filename
        data=src.read_bytes();assert data
        dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists() or dst.read_bytes()!=data:dst.write_bytes(data)
        copied.append({'source':str(src),'path':str(dst),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    changed=[]
    def replace(m):
        shader=bool(re.search(r'^  DESC = Generate vulkan shaders',m[4],re.M))
        generator=m[2]=='CUSTOM_COMMAND' and f'hyle/_deps/gg-{identity}/src/vulkan-shaders-gen-stamp/' in m[1]
        if not shader and not generator:return m[0]
        assert m[2]=='CUSTOM_COMMAND'
        changed.append({'outputs':m[1],'reason':'checked generated shader data' if shader else 'unused helper generation after checked data reuse'})
        return 'build '+m[1]+': phony\n'
    replaced=pattern.sub(replace,original)
    assert len(changed)==160,(len(changed),len(own_edges))
    preview.write_text(replaced)
    proof={'state':'PASS_CURRENT_INPUT_GENERATED_SHADER_DATA_REUSE_ONLY','source_identity':identity,'shader_input_count':len(rows),'shader_inputs':rows,'generator_feature_configuration':own_cfg.read_text(),'generator_cfg_sha256':hashlib.sha256(own_cfg.read_bytes()).hexdigest(),'copied':copied,'replaced_edges':changed,'original_manifest_sha256':hashlib.sha256(original.encode()).hexdigest(),'reuse_manifest_sha256':hashlib.sha256(replaced.encode()).hexdigest(),'limits':['Current SDK static qualification is product669/source73; unchanged native GLSL inputs and exact normalized generator commands/features are rechecked here. Only152 generated C++ data files are reused, not compiled objects or native archives.','All product/native C++ TUs, including generated-data wrappers, retain the original per-mode sanitizer compilation. Public CMake/product/build manifests are unchanged; only a disposable frozen validation Ninja copy has these160 generated-data/helper edges replaced. No new shader/math verdict from reuse.']}
    (out/f'generated-reuse-{tag}.json').write_text(json.dumps(proof,indent=2)+'\n')
    return proof
