from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess

BASE=Path('/Users/kiro/hyle-scratch/compute-unified').resolve()
OUT=BASE/'g06-final-host-air';record_path=OUT/'disk-cleanup.json'
assert not record_path.exists()
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()=='Mac16,12'
assert BASE.is_dir() and BASE.name=='compute-unified'
protected={p.resolve() for route in ['apple','vulkan'] for mode in ['asan','ubsan','tsan'] for p in (BASE/f'foundation-f5-native-host-{route}-{mode}/build').glob('g06_gpu_san_*') if p.is_file()}
assert protected


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()


legacy=[]
for route in ['apple','vulkan']:
    for mode in ['asan','ubsan','tsan']:
        build=(BASE/f'foundation-f5-native-host-{route}-{mode}/build').resolve()
        assert build.is_relative_to(BASE) and build.name=='build'
        for path in build.iterdir():
            if not(path.is_file() and not path.is_symlink() and os.access(path,os.X_OK)):continue
            if not(path.name.startswith(('g01_','g02_','g03_','g04_')) or path.name in ['native','public_native']):continue
            assert path.resolve().parent==build and path.resolve() not in protected
            kind=subprocess.check_output(['/usr/bin/file','-b',str(path)],text=True)
            assert 'Mach-O' in kind and 'executable' in kind,(path,kind)
            legacy.append({'path':str(path.resolve()),'bytes':path.stat().st_size,'sha256':sha(path)})
sdk=BASE/'g06-final-sdk';directories=[]
for tag in ['apple-static-1','apple-shared-1','vulkan-static-2','vulkan-shared-1']:
    result=json.loads((sdk/f'result-{tag}.json').read_text())
    assert result['state']=='TERMINAL_PASS' and result['product_candidate']=='669121418669b31f6849c74f64362aaf8d6eb919'
    for artifact in json.loads((sdk/f'artifacts-{tag}.json').read_text()):
        path=Path(artifact['path']);assert path.resolve().is_relative_to((sdk/tag/'relocated').resolve())
        assert path.stat().st_size==artifact['bytes'] and sha(path)==artifact['sha256']
    for name in ['build','relocated']:
        path=sdk/tag/name;resolved=path.resolve()
        assert resolved.is_relative_to(sdk.resolve()) and resolved.parent.parent==sdk.resolve() and resolved.name==name
        assert path.is_dir() and not path.is_symlink()
        directories.append({'path':str(resolved),'bytes':sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())})
record={'state':'VALIDATED_BEFORE_DELETE','reason':'Final Vulkan TSan1 linker errno28, no tests started. Remove only disposable already-qualified old G01-G04 host test executables and already-sealed G06 SDK installation/consumer copies. Canonical Windows evidence/source untouched; current G06 sanitizer binaries/libraries/objects, all producer trees/shader data, logs/raw records and validation models retained.','legacy_executables':legacy,'sealed_sdk_directories':directories,'protected_current_g06_binary_count':len(protected),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'df_before':subprocess.check_output(['df','-h','/'],text=True)}
record_path.write_text(json.dumps(record,indent=2)+'\n')
for row in legacy:
    path=Path(row['path']);assert path.resolve().is_relative_to(BASE) and path.resolve() not in protected
    path.unlink()
for row in directories:
    path=Path(row['path']);assert path.resolve().is_relative_to(sdk.resolve()) and path.name in ['build','relocated']
    shutil.rmtree(path)
assert all(p.is_file() for p in protected)
record['state']='CLEANED_DISPOSABLE_SEALED_VALIDATION_OUTPUTS';record['df_after']=subprocess.check_output(['df','-h','/'],text=True)
record_path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'state':record['state'],'legacy_executables':len(legacy),'legacy_bytes':sum(r['bytes'] for r in legacy),'sdk_directories':len(directories),'sdk_bytes':sum(r['bytes'] for r in directories),'df_after':record['df_after']}))
