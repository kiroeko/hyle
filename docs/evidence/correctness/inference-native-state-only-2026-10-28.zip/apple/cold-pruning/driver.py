"""Remote two-object driver; separate command actions, no implicit GPU work."""
import importlib.util
import json
from pathlib import Path
import shlex
import sys

W = Path(__file__).resolve().parent
P = json.loads((W / 'plan.json').read_text())
BASE = Path(P['base'])
spec = importlib.util.spec_from_file_location('base_driver', BASE / 'driver-v4.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def verify():
    for item in P['sources']:
        actual = b.pin(W / 'source' / item['path'])
        if (actual['bytes'], actual['sha256']) != (item['bytes'], item['sha256']):
            raise RuntimeError('cold frozen source drift: ' + item['path'])


def compile_units(name):
    verify()
    units = P['units'] if name == 'all' else [x for x in P['units'] if x['name'] == name]
    if not units:
        raise RuntimeError('unknown compile unit')
    for unit in units:
        out = W / 'compile' / unit['name']
        out.mkdir(parents=True, exist_ok=True)
        result = b.execute(unit['command'], out / 'logs', 240)
        raw = (out / 'dependencies.d').read_text().replace('\\\n', '')
        deps = []
        for value in dict.fromkeys(shlex.split(raw.split(':', 1)[1])):
            path = Path(value)
            if not path.is_absolute():
                path = BASE / path
            deps.append(b.pin(path) if path.is_relative_to(W / 'source') else b.stat(path))
        b.save(out / 'actual-dependencies.json', deps)
        b.save(out / 'compiled.json', dict(source=unit['source'], object=b.pin(unit['object']), process=result))
    verify()


def link():
    verify()
    old_ready = json.loads(Path(P['base_ready']).read_text())
    # Preserve the original Q1/failed-Q2 image and its ready receipt.
    if b.pin(old_ready['image']['path']) != old_ready['image']:
        raise RuntimeError('original Apple image changed')
    generated = {}
    for unit in P['units']:
        receipt = json.loads((W / 'compile' / unit['name'] / 'compiled.json').read_text())
        obj = b.pin(unit['object'])
        if obj != receipt['object']:
            raise RuntimeError('cold new object drift')
        generated[obj['path']] = obj
    old_inputs = json.loads(Path(P['base_inputs']).read_text())
    by_path = {x['path']: x for x in old_inputs}
    inputs = []
    for value in P['link_command']:
        if not value.endswith(('.o', '.a', '.dylib')):
            continue
        if value in generated:
            inputs.append(generated[value])
        else:
            prior = by_path[value]
            actual = b.stat(value)
            if actual['bytes'] != prior['bytes'] or ('mtime_ns' in prior and actual['mtime_ns'] != prior['mtime_ns']):
                raise RuntimeError('retained link input changed: ' + value)
            inputs.append(dict(prior, current_stat=actual, identity_basis='original actual link receipt + unchanged size/mtime where recorded'))
    (W / 'bin').mkdir(exist_ok=True)
    process = b.execute(P['link_command'], W / 'link/logs', 180)
    b.save(W / 'link-inputs.json', inputs)
    b.save(W / 'ready.json', dict(status='PASS', image=b.pin(W / 'bin/hyle'), inputs=str(W / 'link-inputs.json'),
        plan=b.pin(W / 'plan.json'), source_freeze=b.pin(W / 'source-freeze.json'), source_identity=P['source_identity'],
        native_fix=P['author_freeze'], link=process, runtime=P['runtime'], reused_image=old_ready['image'],
        scope='Two Apple cold-admission CXX and link only; original Model/weights/twelve SDK objects reused.'))
    print('READY ' + str(W / 'ready.json'), flush=True)


if __name__ == '__main__':
    if sys.argv[1] == 'compile':
        compile_units(sys.argv[2] if len(sys.argv) > 2 else 'all')
    elif sys.argv[1] == 'link':
        link()
    else:
        raise RuntimeError('expected compile [unit|all] or link')
