"""Root-invoked bounded Apple CLI checks; original Queue/retirement unchanged."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

W = Path('/Users/kiro/hyle-scratch/compute-unified/inference-native-state-only-20261028/apple/cold-pruning')
ROOT = W.parents[1]
MAIN_SHA = 'd58a2d408265871a11966691c116e49d2384dadb8199006e2963833488a52c7c'


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def check(value, message):
    if not value:
        raise RuntimeError(message)


def analyze(report, quantum, random):
    check(report['backend'] in ('apple', 'mlx') and report['mtp'], 'unexpected backend/MTP mode')
    check(report['session_count'] == report['turn_count'] == 1, 'not the original single request/turn')
    check(report['logical_prompt_tokens'] == 3 and report['generated_tokens'] == 4,
          'cached V64 fixture must consume P3 and emit its requested four non-EOS IDs')
    check(report['live_committed_versions'] == 0, 'engine retained a committed version')
    check(report['packed_prefill_calls'] == 0, 'native route unexpectedly used packed prefill')
    session = report['sessions'][0]
    result, ledger = session['result'], session['ledger']
    check(len(result['generated_ids']) == 4 and all(0 <= x < 64 for x in result['generated_ids']),
          'generated IDs/count outside fixture vocabulary')
    prefill = [x for x in ledger if not x['generation']]
    expected = [1, 1, 1] if quantum == 1 else [2, 1]
    check([x['input_rows'] for x in prefill] == expected, 'actual prefill chunk rows differ')
    check(report['prefill_graph_calls'] == len(expected), 'prefill call count differs from actual ledger')
    length, draw = 0, 0
    for at, item in enumerate(ledger):
        check(item['index'] == at and item['turn'] == 1, 'ledger order/turn changed')
        check(item['before_length'] == length and item['sampling_draw_before'] == draw,
              'ledger does not continue the previously committed length/RNG')
        check(item['after_length'] == length + item['accepted'], 'accepted rows do not match length advance')
        check(item['after_frontier'] + item['after_lag'] == item['after_length'], 'draft frontier/lag mismatch')
        check(item['sampling_draw_after'] >= draw, 'RNG cursor moved backwards')
        if at < len(prefill) - 1:
            check(item['next_id'] == -1 and item['target_first'] == -1 and item['quota'] == 0,
                  'intermediate StateOnly chunk published a decision')
            check(item['sampling_draw_after'] == draw, 'StateOnly chunk consumed a sampling draw')
        elif at == len(prefill) - 1:
            check(item['next_id'] >= 0 and item['target_first'] >= 0,
                  'final prefill chunk did not publish its real decision')
            check(item['sampling_draw_after'] == (1 if random else 0), 'final prefill RNG differs')
        if not random:
            check(item['sampling_draw_after'] == 0, 'greedy execution changed the RNG cursor')
        length, draw = item['after_length'], item['sampling_draw_after']
    check(length == result['visible_tokens'] == 6, 'final committed visible length differs from P+outputs-1')
    check(draw == result['sampling_draw_cursor'], 'final RNG report differs from committed ledger')
    check(result['draft_frontier'] + result['draft_lag'] == length, 'final draft state does not match head')
    check(ledger[-1]['next_id'] == result['fresh_next_id'] == result['generated_ids'][-1],
          'final pending ID differs from committed head')
    return dict(status='PASS', generated_ids=result['generated_ids'], prefill_rows=expected,
        intermediate_next_ids=[x['next_id'] for x in prefill[:-1]],
        intermediate_draws=[x['sampling_draw_after'] for x in prefill[:-1]],
        committed_length=length, next_id=result['fresh_next_id'], sampling_draw_cursor=draw,
        draft_frontier=result['draft_frontier'], draft_lag=result['draft_lag'],
        actual_graph_calls=report['actual_graph_calls'], packed_prefill_calls=report['packed_prefill_calls'],
        cold_exact_admissions=report['cold_exact_admissions'], engine_live_committed_versions=0,
        scope='CLI ledger/endpoints and engine live versions only; no full hidden-state/native allocation oracle or performance claim.')


def main(name):
    check(name in ('mtp-q1', 'mtp-q2', 'mtp-q2-random'), 'unknown finite run')
    ready = read(W / 'ready-v2.json')
    check(ready['source_identity']['effective_main']['sha256'] == MAIN_SHA, 'not adb2ee9a9 effective main')
    image = pin(ready['image']['path'])
    check(image == ready['image'], 'linked image drift')
    quantum, random = (1 if name == 'mtp-q1' else 2), name.endswith('random')
    plan = read(W / 'root-controlled-runs.json')
    selected = next(x for x in plan['runs'] if x['name'] == ('mtp-q1' if quantum == 1 else 'mtp-q2'))
    command = list(selected['command'])
    command[0] = image['path']
    if random:
        command[command.index('--sampling') + 1] = 'random'
        command += ['--temperature', '1', '--top-k', '8', '--seed', '123']
    output = W / 'runs' / name
    output.mkdir(parents=True, exist_ok=False)
    environment = os.environ.copy()
    environment.update(plan['environment'])
    check(Path(environment['MLX_METAL_PATH']).is_file(), 'original cached MLX metallib missing')
    recorded_environment = {key: environment[key] for key in
        ('PATH', 'DYLD_LIBRARY_PATH', 'DYLD_FALLBACK_LIBRARY_PATH', 'HOME', 'TMPDIR') if key in environment}
    save(output / 'command.json', dict(command=command, cwd=str(W), environment_overrides=plan['environment'],
         inherited_environment_whitelist=recorded_environment, timeout_seconds=240, image=image, effective_source_commit='adb2ee9a9',
         source_origin='314707293 plus only EvaluationRequest::LogitsInputs logits{};', effective_main_sha256=MAIN_SHA))
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    with (output / 'stdout.log').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
        p = subprocess.Popen(command, cwd=W, env=environment, stdout=stdout, stderr=stderr)
        save(output / 'running.json', dict(pid=p.pid, started_utc=started))
        timed_out = False
        try:
            code = p.wait(timeout=240)
        except subprocess.TimeoutExpired:
            timed_out = True
            p.kill()
            code = p.wait()
        process = dict(pid=p.pid, exit=code, timed_out=timed_out, started_utc=started,
            ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), seconds=time.monotonic() - clock)
        save(output / 'process.json', process)
    check(code == 0 and not timed_out, 'actual CLI failure preserved: ' + str(output))
    report = json.loads((output / 'stdout.log').read_text())
    save(output / 'report.json', report)
    facts = analyze(report, quantum, random)
    facts.update(process=process, image=image, source_commit='adb2ee9a9', main_sha256=MAIN_SHA)
    save(output / 'summary.json', facts)
    print(json.dumps(facts, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    try:
        main(sys.argv[1])
    except Exception as error:
        print(type(error).__name__ + ': ' + str(error), file=sys.stderr, flush=True)
        raise
