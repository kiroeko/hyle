"""One private-header preparation repair; no product edit or implicit build."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shlex
import tarfile

W = Path(__file__).resolve().parent
F = W / 'retained-v2'
spec = importlib.util.spec_from_file_location('apple_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def prepare():
    if F.exists():
        raise RuntimeError('refinement already prepared; do not overwrite')
    F.mkdir()
    old = b.read(W / 'plan.json')
    plan = json.loads(json.dumps(old))
    rel = 'src/compute/completion_internal.h'
    actual = b.pin(b.R / rel)
    item = dict(actual, path=rel, reason='retained_completion.cc directly quoted private header missing from original leases template roots')
    target = F / 'source' / rel
    target.parent.mkdir(parents=True)
    target.write_bytes((b.R / rel).read_bytes())
    plan['sources'].append(item)
    unit = next(u for u in plan['units'] if u['name'] == 'retained')
    old_object = unit['object']
    unit['name'] = 'retained-v2'
    unit['object'] = old_object.replace('/compile/retained/', '/compile/retained-v2/')
    unit['command'] = [x.replace('/compile/retained/', '/compile/retained-v2/') for x in unit['command']]
    unit['refinement'] = 'Only one unchanged private declaration added; source/flags preserved, new attempt output.'
    plan['link_command'] = [unit['object'] if x == old_object else x for x in plan['link_command']]
    plan['status'] = 'HEADER_REFINEMENT_PREPARED_NOT_SYNCED_OR_BUILT'
    plan['refinement'] = dict(previous_plan=b.pin(W / 'plan.json'),
        preserved_failed_attempt=b.REMOTE + '/compile/retained/logs',
        successful_unchanged_unit='leases', additional_project_header=item,
        transitive_header_proof='completion_internal.h includes only hyle/compute/detail/completion_access.h; existing completion_access/completion/dependent_completion/copy_outcome_source headers matched canonical SHA256 by read-only SSH.')
    b.save(F / 'plan-retained-v2.json', plan)
    b.save(F / 'source-freeze-retained-v2.json', dict(base_commit='314707293', files=plan['sources']))
    driver = (W / 'driver.py').read_text(encoding='utf-8')
    assert driver.count("PLAN = json.loads((W / 'plan.json').read_text())") == 1
    driver = driver.replace("PLAN = json.loads((W / 'plan.json').read_text())", "PLAN = json.loads((W / 'plan-retained-v2.json').read_text())")
    driver = driver.replace("name == 'all'", "name in ('all', 'remaining')")
    needle = "        output = W / 'compile' / u['name']\n"
    assert driver.count(needle) == 1
    driver = driver.replace(needle, needle + "        if name == 'remaining' and (output / 'compiled.json').exists():\n"
        "            previous = json.loads((output / 'compiled.json').read_text())\n"
        "            if previous.get('status') != 'PASS' or pin(u['object']) != previous['object']:\n"
        "                raise RuntimeError('successful object drift: ' + u['name'])\n"
        "            print('REUSE successful unit ' + u['name'], flush=True)\n"
        "            continue\n")
    driver = driver.replace("plan=pin(W / 'plan.json')", "plan=pin(W / 'plan-retained-v2.json')")
    driver = driver.replace("source_freeze=pin(W / 'source-freeze.json')", "source_freeze=pin(W / 'source-freeze-retained-v2.json')")
    compile(driver, 'driver-v2.py', 'exec')
    (F / 'driver-v2.py').write_text(driver, encoding='utf-8')
    with tarfile.open(F / 'thin-refinement.tar.gz', 'w:gz') as archive:
        archive.add(target, arcname='source/' + rel)
        for name in ['plan-retained-v2.json', 'source-freeze-retained-v2.json', 'driver-v2.py']:
            archive.add(F / name, arcname=name)
    b.save(F / 'prepared.json', dict(status='PREPARED_ONLY',
        archive=b.pin(F / 'thin-refinement.tar.gz'), plan=b.pin(F / 'plan-retained-v2.json'),
        added_source_bytes=item['bytes'], CXX_already_passed=1, remaining_CXX=13,
        preserved='Original plan/driver/source-freeze/retained failure/leases success remain untouched.'))
    print(json.dumps(b.read(F / 'prepared.json'), indent=2))


def sync():
    receipt = b.read(F / 'prepared.json')
    if b.pin(F / 'thin-refinement.tar.gz') != receipt['archive']:
        raise RuntimeError('refinement archive drift')
    code = """import io,pathlib,tarfile,sys
w=pathlib.Path(%r)
if not (w/'compile/retained/logs/process.json').is_file():raise RuntimeError('original failure receipt missing')
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name)
  if not m.isfile() or p.is_absolute() or '..' in p.parts:raise RuntimeError('unsafe refinement member')
  if (w/m.name).exists():raise RuntimeError('refinement would overwrite existing file: '+m.name)
 for m in t.getmembers():
  p=w/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
print('REFINEMENT SYNCED',w)
""" % b.REMOTE
    b.call(b.SSH + ['python3 -c ' + shlex.quote(code)], F / 'sync', (F / 'thin-refinement.tar.gz').read_bytes())


def invoke(action, unit):
    args = ['python3', b.REMOTE + '/driver-v2.py', action]
    if action == 'compile':
        args.append(unit or 'remaining')
    label = action + ('-' + (unit or 'remaining') if action == 'compile' else '')
    b.call(b.SSH + [shlex.join(args)], F / 'invocations' / label)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'sync', 'compile', 'link'])
    parser.add_argument('unit', nargs='?')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'sync':
        sync()
    else:
        invoke(args.action, args.unit)
