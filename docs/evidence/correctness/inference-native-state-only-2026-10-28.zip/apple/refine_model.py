"""Strict-Clang one-line Model repair derived only from immutable main314."""
import argparse
import difflib
import importlib.util
import json
from pathlib import Path
import shlex
import tarfile

W = Path(__file__).resolve().parent
F = W / 'model-v2'
spec = importlib.util.spec_from_file_location('apple_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def prepare():
    if F.exists():
        raise RuntimeError('Model refinement already exists; do not overwrite')
    F.mkdir()
    old_plan = W / 'headers-v3' / 'plan-headers-v3.json'
    plan = b.read(old_plan)
    original = W / 'headers-v3' / 'source-v3/engine/models/qwen35/main.cc'
    before = original.read_bytes()
    expected = plan['source_identity']['main']
    assert (b.pin(original)['bytes'], b.pin(original)['sha256']) == (expected['bytes'], expected['sha256'])
    begin = before.index(b'struct EvaluationRequest final {')
    end = before.index(b'\n};', begin) + 3
    block = before[begin:end]
    assert block.count(b'LogitsInputs logits;') == 1
    after = before[:begin] + block.replace(b'LogitsInputs logits;', b'LogitsInputs logits{};') + before[end:]
    # Same source directory as v3 preserves exact quoted-header lookup while
    # retaining the original failed main.cc byte-for-byte.
    relative = 'engine/models/qwen35/main-model-v2.cc'
    target = F / 'source-v3' / relative
    target.parent.mkdir(parents=True)
    target.write_bytes(after)
    item = dict(b.pin(target), path=relative)
    plan['sources'].append(item)
    model = next(u for u in plan['units'] if u['name'] == 'model')
    previous_object = model['object']
    model['name'] = 'model-v2'
    model['canonical_source'] = model['source']
    model['source'] = relative
    model['object'] = model['object'].replace('/compile/model/', '/compile/model-v2/')
    model['command'] = [x.replace('/compile/model/', '/compile/model-v2/')
                        .replace('/source-v3/engine/models/qwen35/main.cc', '/source-v3/' + relative)
                        for x in model['command']]
    plan['link_command'] = [model['object'] if x == previous_object else x for x in plan['link_command']]
    plan['status'] = 'STRICT_CLANG_SINGLE_MEMBER_INITIALIZER_REFINEMENT_PREPARED'
    plan['source_identity']['effective_main'] = dict(item, logical_path='engine/models/qwen35/main.cc',
        derivation='immutable 314/main953f + exactly EvaluationRequest::LogitsInputs logits{};')
    proof = dict(original=b.pin(original), effective_source=item,
        canonical_latest_not_read=True, changed_lines=['-  LogitsInputs logits;', '+  LogitsInputs logits{};'],
        member='EvaluationRequest::logits', ABI='No field/type/layout change; explicit default member initialization.',
        previous_failure=b.REMOTE + '/compile/model/logs',
        existing_successful_objects='All twelve SDK units reused; only model-v2 and never-attempted weights remain.')
    b.save(F / 'source-change-proof.json', proof)
    (F / 'source.diff').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
        fromfile='immutable-main314.cc', tofile='main314-plus-default-logits.cc')), encoding='utf-8')
    b.save(F / 'plan-model-v2.json', plan)
    b.save(F / 'source-freeze-model-v2.json', dict(base_commit='314707293', amendment=proof, files=plan['sources']))
    driver = (W / 'headers-v3' / 'driver-v3.py').read_text(encoding='utf-8')
    driver = driver.replace('plan-headers-v3.json', 'plan-model-v2.json')
    driver = driver.replace('source-freeze-headers-v3.json', 'source-freeze-model-v2.json')
    compile(driver, 'driver-v4.py', 'exec')
    (F / 'driver-v4.py').write_text(driver, encoding='utf-8')
    with tarfile.open(F / 'thin-model-v2.tar.gz', 'w:gz') as archive:
        archive.add(target, arcname='source-v3/' + relative)
        for name in ['plan-model-v2.json', 'source-freeze-model-v2.json', 'driver-v4.py', 'source-change-proof.json', 'source.diff']:
            archive.add(F / name, arcname=name)
    b.save(F / 'prepared.json', dict(status='PREPARED_ONLY', archive=b.pin(F / 'thin-model-v2.tar.gz'),
        plan=b.pin(F / 'plan-model-v2.json'), source=item, successful_CXX_reused=12, remaining_CXX=2,
        no_current_canonical_WIP_read=True))
    print(json.dumps(b.read(F / 'prepared.json'), indent=2))


def sync():
    receipt = b.read(F / 'prepared.json')
    if b.pin(F / 'thin-model-v2.tar.gz') != receipt['archive']:
        raise RuntimeError('Model archive drift')
    code = """import io,pathlib,tarfile,sys
w=pathlib.Path(%r)
if not (w/'compile/model/logs/process.json').is_file():raise RuntimeError('original Model failure missing')
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name)
  if not m.isfile() or p.is_absolute() or '..' in p.parts:raise RuntimeError('unsafe Model refinement member')
  if (w/m.name).exists():raise RuntimeError('Model refinement would overwrite: '+m.name)
 for m in t.getmembers():
  p=w/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
print('MODEL REFINEMENT SYNCED',w)
""" % b.REMOTE
    b.call(b.SSH + ['python3 -c ' + shlex.quote(code)], F / 'sync', (F / 'thin-model-v2.tar.gz').read_bytes())


def invoke(action, unit):
    args = ['python3', b.REMOTE + '/driver-v4.py', action]
    if action == 'compile':
        args.append(unit or 'remaining')
    label = action + ('-' + (unit or 'remaining') if action == 'compile' else '')
    b.call(b.SSH + [shlex.join(args)], F / 'invocations' / label)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'sync', 'compile', 'link'])
    parser.add_argument('unit', nargs='?')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'sync':
        sync()
    else:
        invoke(args.action, args.unit)
