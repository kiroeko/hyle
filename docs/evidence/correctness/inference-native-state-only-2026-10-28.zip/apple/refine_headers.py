"""Bounded current-header closure for the same fourteen selected Apple TUs."""
import argparse
import difflib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import subprocess
import tarfile

W = Path(__file__).resolve().parent
F = W / 'headers-v3'
spec = importlib.util.spec_from_file_location('apple_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def prepare():
    if F.exists():
        raise RuntimeError('header refinement already exists; do not overwrite')
    F.mkdir()
    previous = W / 'retained-v2' / 'plan-retained-v2.json'
    plan = b.read(previous)
    for item in plan['sources']:
        actual = b.pin(b.R / item['path'])
        if (actual['bytes'], actual['sha256']) != (item['bytes'], item['sha256']):
            raise RuntimeError('canonical drift before header refinement: ' + item['path'])
    pending = [b.R / u['source'] for u in plan['units']]
    visited, unresolved = set(), []
    pattern = re.compile(r'^\s*#\s*include\s*([<\"])([^>\"]+)[>\"]', re.MULTILINE)
    while pending:
        path = pending.pop().resolve()
        if path in visited or not path.is_file() or not path.is_relative_to(b.R):
            continue
        visited.add(path)
        for delimiter, name in pattern.findall(path.read_text(encoding='utf-8-sig')):
            if name.startswith('hyle/'):
                candidate = b.R / 'include' / name
            elif delimiter == '"':
                candidate = (path.parent / name).resolve()
            else:
                continue  # System/vendor headers stay in the original cached SDK.
            if candidate.is_file() and candidate.is_relative_to(b.R):
                pending.append(candidate)
            else:
                unresolved.append(dict(including=path.relative_to(b.R).as_posix(), literal=name,
                                       reason='not a canonical project file; retained original include resolution'))
    files = []
    for path in sorted(visited):
        rel = path.relative_to(b.R).as_posix()
        item = dict(b.pin(path), path=rel)
        files.append(item)
        out = F / 'source-v3' / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(path.read_bytes())
    assert any(x['path'] == 'include/hyle/compute/resource_leases.h' for x in files)
    # Preserve both actual old public declarations. The native-slot template
    # used by the two already-successful units has the current declaration;
    # the earlier arena template selected the older header without it.
    remote = "/Users/kiro/hyle-scratch/compute-unified/"
    paths = [remote + 'inference-paged-frame-20261026/source/include/hyle/compute/resource_leases.h',
             remote + 'inference-native-slot-store-20261027/source/include/hyle/compute/resource_leases.h']
    proof = []
    for index, path in enumerate(paths):
        result = subprocess.run(b.SSH + ['python3 -c ' + shlex.quote('import sys;sys.stdout.buffer.write(open(' + repr(path) + ',"rb").read())')],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        old_file = F / ('old-resource-leases-' + str(index) + '.h')
        old_file.write_bytes(result.stdout)
        proof.append(dict(b.pin(old_file), remote_path=path))
    current = (b.R / 'include/hyle/compute/resource_leases.h').read_bytes()
    assert (F / 'old-resource-leases-1.h').read_bytes() == current
    delta = ''.join(difflib.unified_diff((F / 'old-resource-leases-0.h').read_text().splitlines(True),
                                       current.decode().splitlines(True), fromfile=paths[0], tofile='canonical/include/hyle/compute/resource_leases.h'))
    (F / 'resource-leases-declaration.diff').write_text(delta, encoding='utf-8')
    b.save(F / 'header-proof.json', dict(old_actual_headers=proof,
        canonical=b.pin(b.R / 'include/hyle/compute/resource_leases.h'),
        declaration_delta='Forward declaration and friends for the independent LeaseSlotLayout; no original lease object fields changed.',
        reuse='leases and retained-v2 already used the byte-identical native-slot-store public header; no recompilation of those successful units.'))
    old_object = next(u['object'] for u in plan['units'] if u['name'] == 'arena')
    for unit in plan['units']:
        if unit['name'] in ('leases', 'retained-v2'):
            unit['reuse_successful_original_attempt'] = True
            continue
        if unit['name'] == 'arena':
            unit['name'] = 'arena-v2'
            unit['object'] = unit['object'].replace('/compile/arena/', '/compile/arena-v2/')
        unit['command'] = [x.replace(b.REMOTE + '/source', b.REMOTE + '/source-v3')
                           .replace('/compile/arena/', '/compile/arena-v2/') for x in unit['command']]
    new_object = next(u['object'] for u in plan['units'] if u['name'] == 'arena-v2')
    plan['link_command'] = [new_object if x == old_object else x for x in plan['link_command']]
    plan['sources'] = files
    plan['status'] = 'BOUNDED_CURRENT_HEADER_CLOSURE_PREPARED_NOT_SYNCED_OR_BUILT'
    plan['header_refinement'] = dict(previous_plan=b.pin(previous), source_root='source-v3',
        count=len(files), bytes=sum(x['bytes'] for x in files),
        method='Literal quoted and hyle/ include reachability from exactly the 14 selected canonical TUs; conditional branches form a bounded superset. No external SDK/model files traversed or copied.',
        preserved_failures=['compile/retained/logs', 'compile/arena/logs'],
        reuse_successful_units=['leases', 'retained-v2'],
        ABI='Only current header selection is repaired. Existing object reuse still follows platform-plan ABI facts; header drift alone does not cause a full SDK rebuild.')
    b.save(F / 'plan-headers-v3.json', plan)
    b.save(F / 'source-freeze-headers-v3.json', dict(base_commit='314707293', files=files))
    b.save(F / 'include-closure.json', dict(files=files, unresolved_literals=unresolved))
    driver = (W / 'retained-v2' / 'driver-v2.py').read_text(encoding='utf-8')
    driver = driver.replace('plan-retained-v2.json', 'plan-headers-v3.json')
    driver = driver.replace('source-freeze-retained-v2.json', 'source-freeze-headers-v3.json')
    driver = driver.replace("W / 'source'", "W / 'source-v3'")
    compile(driver, 'driver-v3.py', 'exec')
    (F / 'driver-v3.py').write_text(driver, encoding='utf-8')
    with tarfile.open(F / 'thin-headers-v3.tar.gz', 'w:gz') as archive:
        for item in files:
            archive.add(F / 'source-v3' / item['path'], arcname='source-v3/' + item['path'])
        for name in ['plan-headers-v3.json', 'source-freeze-headers-v3.json', 'driver-v3.py', 'header-proof.json', 'include-closure.json']:
            archive.add(F / name, arcname=name)
    b.save(F / 'prepared.json', dict(status='PREPARED_ONLY', archive=b.pin(F / 'thin-headers-v3.tar.gz'),
        plan=b.pin(F / 'plan-headers-v3.json'), project_files=len(files),
        header_files=sum(x['path'].endswith(('.h', '.hpp')) for x in files),
        bytes=sum(x['bytes'] for x in files), CXX_already_passed=2, remaining_CXX=12,
        no_external_SDK_or_weight_copy=True))
    print(json.dumps(b.read(F / 'prepared.json'), indent=2))


def sync():
    receipt = b.read(F / 'prepared.json')
    if b.pin(F / 'thin-headers-v3.tar.gz') != receipt['archive']:
        raise RuntimeError('header archive drift')
    code = """import io,pathlib,tarfile,sys
w=pathlib.Path(%r)
if not (w/'compile/arena/logs/process.json').is_file():raise RuntimeError('original arena failure missing')
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name)
  if not m.isfile() or p.is_absolute() or '..' in p.parts:raise RuntimeError('unsafe header refinement member')
  if (w/m.name).exists():raise RuntimeError('header refinement would overwrite: '+m.name)
 for m in t.getmembers():
  p=w/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
print('CURRENT HEADERS SYNCED',w)
""" % b.REMOTE
    b.call(b.SSH + ['python3 -c ' + shlex.quote(code)], F / 'sync', (F / 'thin-headers-v3.tar.gz').read_bytes())


def invoke(action, unit):
    args = ['python3', b.REMOTE + '/driver-v3.py', action]
    if action == 'compile':
        args.append(unit or 'remaining')
    label = action + ('-' + (unit or 'remaining') if action == 'compile' else '')
    b.call(b.SSH + [shlex.join(args)], F / 'invocations' / label)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'sync', 'compile', 'link'])
    parser.add_argument('unit', nargs='?')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'sync':
        sync()
    else:
        invoke(args.action, args.unit)
