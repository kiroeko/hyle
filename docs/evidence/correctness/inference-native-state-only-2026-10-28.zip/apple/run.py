"""Prepared locally only. Root explicitly invokes each remote run/fetch."""
import argparse
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import shlex
import subprocess
import tarfile

W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('apple_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def run(name):
    script = (W / 'run_remote.py').read_bytes()
    out = W / 'run-invocations' / name
    b.call(b.SSH + ['python3 - ' + shlex.quote(name)], out, script)


def fetch(label):
    if not label or not all(c.isalnum() or c in '-_' for c in label):
        raise RuntimeError('readback label must be a single simple directory name')
    out = W / label
    out.mkdir(exist_ok=False)
    # Only receipts/logs and compiler include lists, never OBJ/image/SDK/model.
    code = """import io,json,pathlib,sys,tarfile
w=pathlib.Path(%r)
selected=[]
for name in ['ready.json','link-inputs.json','original-input-stats.json','preflight.json','plan-model-v2.json','source-freeze-model-v2.json','source-change-proof.json','source.diff']:
 p=w/name
 if p.is_file():selected.append(p)
for root in ['runs','compile','link','cold-pruning']:
 for p in sorted((w/root).rglob('*')):
  if p.is_file() and p.suffix in ('.json','.log','.d'):selected.append(p)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w:gz') as t:
 for p in selected:t.add(p,arcname=p.relative_to(w).as_posix(),recursive=False)
sys.stdout.buffer.write(buf.getvalue())
""" % b.REMOTE
    command = b.SSH + ['python3 -c ' + shlex.quote(code)]
    b.save(out / 'command.json', dict(command=command, selection='small receipt/log/include-list only'))
    with (out / 'records.tar.gz').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
        process = subprocess.run(command, stdout=stdout, stderr=stderr)
    b.save(out / 'process.json', dict(exit=process.returncode))
    if process.returncode:
        raise RuntimeError('readback failed; kept actual stdout/stderr')
    manifest = []
    with tarfile.open(out / 'records.tar.gz', 'r:gz') as archive:
        for member in archive.getmembers():
            relative = PurePosixPath(member.name)
            if not member.isfile() or relative.is_absolute() or '..' in relative.parts:
                raise RuntimeError('unsafe/nonfile archive member')
            if relative.suffix not in ('.json', '.log', '.d', '.diff'):
                raise RuntimeError('unexpected payload member: ' + member.name)
            data = archive.extractfile(member).read()
            target = out / 'records' / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            manifest.append(dict(path=member.name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    b.save(out / 'manifest.json', dict(files=manifest, archive=b.pin(out / 'records.tar.gz')))
    print(json.dumps(dict(files=len(manifest), archive=b.pin(out / 'records.tar.gz')), indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['mtp-q1', 'mtp-q2', 'mtp-q2-random', 'fetch'])
    parser.add_argument('label', nargs='?', help='fetch only: new local output directory (default readback)')
    args = parser.parse_args()
    if args.action == 'fetch':
        fetch(args.label or 'readback')
    else:
        if args.label:
            parser.error('label is supported only by fetch')
        run(args.action)
