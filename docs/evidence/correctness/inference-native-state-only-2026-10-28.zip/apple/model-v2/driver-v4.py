"""Remote incremental build driver. Invoked only by root's local build.py."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

W = Path(__file__).resolve().parent
PLAN = json.loads((W / 'plan-model-v2.json').read_text())


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def verify_sources():
    for item in PLAN['sources']:
        actual = pin(W / 'source-v3' / item['path'])
        if (actual['bytes'], actual['sha256']) != (item['bytes'], item['sha256']):
            raise RuntimeError('frozen source drift: ' + item['path'])


def stat(path):
    p = Path(path)
    s = p.stat()
    return dict(path=str(p), bytes=s.st_size, mtime_ns=s.st_mtime_ns)


def execute(command, output, timeout):
    output.mkdir(parents=True, exist_ok=False)
    save(output / 'command.json', dict(command=command, cwd=str(W), timeout_seconds=timeout))
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    with (output / 'stdout.log').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
        p = subprocess.Popen(command, cwd=W, env=os.environ.copy(), stdout=stdout, stderr=stderr)
        save(output / 'running.json', dict(pid=p.pid, started_utc=started))
        timed_out = False
        try:
            code = p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            p.kill()
            code = p.wait()
        result = dict(pid=p.pid, exit=code, timeout=timed_out, started_utc=started,
                      ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      seconds=time.monotonic() - clock)
        save(output / 'process.json', result)
    print(json.dumps(dict(output=str(output), process=result)), flush=True)
    if code or timed_out:
        raise RuntimeError('actual command failed; preserved: ' + str(output))
    return result


def preflight():
    verify_sources()
    if (W / 'original-input-stats.json').exists():
        raise RuntimeError('preflight already recorded; do not overwrite the original window')
    save(W / 'original-input-stats.json', [stat(p) for p in PLAN['retained_inputs']])
    save(W / 'preflight.json', dict(status='PASS', sources=len(PLAN['sources']),
         retained_inputs=len(PLAN['retained_inputs']), root=str(W),
         note='Existence/stat checks only for cached inputs; no SDK/archive payload rehash.'))
    print('PREFLIGHT PASS', flush=True)


def compile_units(name):
    verify_sources()
    units = PLAN['units'] if name in ('all', 'remaining') else [u for u in PLAN['units'] if u['name'] == name]
    if not units:
        raise RuntimeError('unknown unit: ' + name)
    for u in units:
        output = W / 'compile' / u['name']
        if name == 'remaining' and (output / 'compiled.json').exists():
            previous = json.loads((output / 'compiled.json').read_text())
            if previous.get('status') != 'PASS' or pin(u['object']) != previous['object']:
                raise RuntimeError('successful object drift: ' + u['name'])
            print('REUSE successful unit ' + u['name'], flush=True)
            continue
        if (output / 'logs').exists():
            raise RuntimeError('actual attempt already exists; no automatic retry: ' + u['name'])
        output.mkdir(parents=True, exist_ok=True)
        process = execute(u['command'], output / 'logs', 240)
        # Preserve clang's actual include list. Only new overlay files are
        # hashed; retained SDK/library files receive stat identities.
        raw = (output / 'dependencies.d').read_text().replace('\\\n', '')
        deps = shlex.split(raw.split(':', 1)[1])
        actual = []
        for value in dict.fromkeys(deps):
            p = Path(value)
            if not p.is_absolute():
                p = W / p
            entry = stat(p)
            if p.is_relative_to(W / 'source-v3'):
                entry = pin(p)
            actual.append(entry)
        save(output / 'actual-dependencies.json', actual)
        save(output / 'compiled.json', dict(status='PASS', source=u['source'],
             object=pin(u['object']), process=process,
             dependencies=str(output / 'actual-dependencies.json')))
    verify_sources()


def link():
    verify_sources()
    previous = json.loads((W / 'original-input-stats.json').read_text())
    for item in previous:
        if stat(item['path']) != item:
            raise RuntimeError('retained cached input changed during this window: ' + item['path'])
    generated = {}
    for u in PLAN['units']:
        receipt = json.loads((W / 'compile' / u['name'] / 'compiled.json').read_text())
        actual = pin(u['object'])
        if actual != receipt['object']:
            raise RuntimeError('new object drift: ' + u['name'])
        generated[actual['path']] = actual
    (W / 'bin').mkdir(exist_ok=True)
    process = execute(PLAN['link_command'], W / 'link' / 'logs', 180)
    inputs = []
    for value in PLAN['link_command']:
        if value.endswith(('.o', '.a', '.dylib')):
            item = generated.get(value)
            if item is None:
                item = dict(stat(value), identity_basis='retained original cached input stat + original recipe/archive receipt')
            inputs.append(item)
    save(W / 'link-inputs.json', inputs)
    save(W / 'ready.json', dict(status='PASS', image=pin(W / 'bin' / 'hyle'),
         inputs=str(W / 'link-inputs.json'), plan=pin(W / 'plan-model-v2.json'),
         source_freeze=pin(W / 'source-freeze-model-v2.json'), link=process,
         runtime=PLAN['runtime'], source_identity=PLAN['source_identity'],
         scope='14 selected host CXX plus one link; no SDK, Metal library, shader, model or GPU execution.'))
    print('READY ' + str(W / 'ready.json'), flush=True)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'preflight':
            preflight()
        elif action == 'compile':
            compile_units(sys.argv[2] if len(sys.argv) > 2 else 'all')
        elif action == 'link':
            link()
        else:
            raise RuntimeError('expected preflight | compile [unit|all] | link')
    except Exception as error:
        print(type(error).__name__ + ': ' + str(error), file=sys.stderr, flush=True)
        raise
