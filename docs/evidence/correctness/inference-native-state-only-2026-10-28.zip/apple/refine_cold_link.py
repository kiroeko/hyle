"""Recipe-only duplicate-direct-object repair. Never recompiles either TU."""
import argparse
import importlib.util
import json
from pathlib import Path
import shlex
import tarfile

W = Path(__file__).resolve().parent
F = W / 'cold-pruning'
V = F / 'link-v2'
spec = importlib.util.spec_from_file_location('apple_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
REMOTE = b.REMOTE + '/cold-pruning'


def prepare():
    if V.exists():
        raise RuntimeError('link refinement exists; preserve original attempts')
    V.mkdir()
    plan = b.read(F / 'plan.json')
    command = plan['link_command']
    region = next(x for x in plan['units'] if x['name'] == 'region')['object']
    old = '/Users/kiro/hyle-scratch/compute-unified/inference-native-slot-store-20261027/native.o'
    assert command.count(region) == command.count(old) == 1
    command.remove(region)
    command[command.index(old)] = region
    command[command.index('-o') + 1] = REMOTE + '/bin/hyle-v2'
    plan['recipe_refinement'] = dict(cause='Original direct native.o was incorrectly retained alongside the new region object.',
        replacement=dict(old=old, new=region), sources_unchanged=True, CXX_reused=2,
        preserved_failed_link=REMOTE + '/link/logs',
        preserved_run_preflight='Original run invocation failed before GPU launch because ready.json did not exist.')
    b.save(V / 'plan-link-v2.json', plan)
    driver = (F / 'driver.py').read_text(encoding='utf-8')
    driver = driver.replace("W / 'plan.json'", "W / 'plan-link-v2.json'")
    driver = driver.replace("W / 'link/logs'", "W / 'link-v2/logs'")
    driver = driver.replace("W / 'ready.json'", "W / 'ready-v2.json'")
    driver = driver.replace("W / 'link-inputs.json'", "W / 'link-inputs-v2.json'")
    driver = driver.replace("W / 'bin/hyle'", "W / 'bin/hyle-v2'")
    compile(driver, 'driver-link-v2.py', 'exec')
    (V / 'driver-link-v2.py').write_text(driver, encoding='utf-8')
    run = (F / 'run_remote.py').read_text(encoding='utf-8')
    run = run.replace("W / 'ready.json'", "W / 'ready-v2.json'")
    run = run.replace('command = list(selected[\'command\'])',
                      "command = list(selected['command'])\n    command[0] = image['path']")
    compile(run, 'run-remote-v2.py', 'exec')
    (V / 'run-remote-v2.py').write_text(run, encoding='utf-8')
    b.save(V / 'amendment.json', plan['recipe_refinement'])
    with tarfile.open(V / 'thin-link-v2.tar.gz', 'w:gz') as archive:
        for name in ['plan-link-v2.json', 'driver-link-v2.py', 'run-remote-v2.py', 'amendment.json']:
            archive.add(V / name, arcname=name)
    b.save(V / 'prepared.json', dict(status='PREPARED_RECIPE_ONLY', CXX=0, links=1,
        inputs=sum(x.endswith(('.o', '.a', '.dylib')) for x in command), archive=b.pin(V / 'thin-link-v2.tar.gz')))
    print(json.dumps(b.read(V / 'prepared.json'), indent=2))


def sync():
    if b.pin(V / 'thin-link-v2.tar.gz') != b.read(V / 'prepared.json')['archive']:
        raise RuntimeError('link archive drift')
    code = """import io,pathlib,tarfile,sys
w=pathlib.Path(%r)
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name)
  if not m.isfile() or p.is_absolute() or '..' in p.parts or (w/m.name).exists():raise RuntimeError('unsafe/existing link refinement')
 for m in t.getmembers():(w/m.name).write_bytes(t.extractfile(m).read())
print('LINK-V2 RECIPES SYNCED')
""" % REMOTE
    b.call(b.SSH + ['python3 -c ' + shlex.quote(code)], V / 'sync', (V / 'thin-link-v2.tar.gz').read_bytes())


def invoke(action, name):
    if action == 'link':
        command = ['python3', REMOTE + '/driver-link-v2.py', 'link']
        b.call(b.SSH + [shlex.join(command)], V / 'invocations/link')
    elif action == 'run':
        if name not in ('mtp-q2', 'mtp-q2-random'):
            raise RuntimeError('only two Q2 cases')
        b.call(b.SSH + ['python3 - ' + shlex.quote(name)], V / 'invocations' / ('run-' + name),
               (V / 'run-remote-v2.py').read_bytes())


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'sync', 'link', 'run'])
    parser.add_argument('name', nargs='?')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'sync':
        sync()
    else:
        invoke(args.action, args.name)
