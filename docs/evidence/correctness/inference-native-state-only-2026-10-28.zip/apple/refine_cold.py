"""Two-TU Apple cold-admission refinement; root invokes actions separately."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import tarfile

W = Path(__file__).resolve().parent
F = W / 'cold-pruning'
spec = importlib.util.spec_from_file_location('apple_build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
REMOTE = b.REMOTE + '/cold-pruning'
EXPECTED = {
    'src/compute_route_apple/apple_tensor.cc': '7bc85787dbc90ef89b8292ff147045dc4d7caffc06762fe206dde32a32789bfd',
    'src/graph_route_apple/native_region.cc': 'db34e1b85b899b13b5dd75b613908ba21460f9c828c7c481ab44f0ac73ac6e41',
    'src/compute_route_apple/apple_carrier.h': 'f286ebe991efffb4de87b90e479b75e6c8a17b0300dc95bb5791e2f6e87cc106',
}


def prepare():
    if F.exists():
        raise RuntimeError('cold refinement exists; never overwrite')
    for relative, sha in EXPECTED.items():
        if b.pin(b.R / relative)['sha256'] != sha:
            raise RuntimeError('author freeze mismatch: ' + relative)
    F.mkdir()
    old = b.read(W / 'model-v2/plan-model-v2.json')
    # Bounded literal project header closure, compared against the existing v3
    # snapshot. Copy only missing/changed files and relative-include bridges.
    roots = ['src/compute_route_apple/apple_tensor.cc', 'src/graph_route_apple/native_region.cc']
    pending, visited, edges = list(roots), {}, {}
    pattern = re.compile(r'^\s*#\s*include\s*([<\"])([^>\"]+)[>\"]', re.MULTILINE)
    while pending:
        relative = pending.pop()
        if relative in visited:
            continue
        path = b.R / relative
        data = path.read_bytes()
        visited[relative] = data
        children = []
        for delimiter, name in pattern.findall(data.decode('utf-8-sig')):
            target = b.R / 'include' / name if name.startswith('hyle/') else (path.parent / name).resolve() if delimiter == '"' else None
            if target is None or not target.is_file() or not target.is_relative_to(b.R):
                continue
            child = target.relative_to(b.R).as_posix()
            pending.append(child)
            if delimiter == '"' and not name.startswith('hyle/'):
                children.append(child)
        edges[relative] = children
    selected = set(EXPECTED)
    for relative, data in visited.items():
        old_path = W / 'headers-v3/source-v3' / relative
        if not old_path.is_file() or old_path.read_bytes() != data:
            selected.add(relative)
    while True:
        bridges = {relative for relative, children in edges.items() if any(c in selected for c in children)}
        added = bridges - selected
        if not added:
            break
        selected.update(added)
    sources = []
    for relative in sorted(selected):
        target = F / 'source' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(visited[relative])
        sources.append(dict(b.pin(target), path=relative))
    inventory = W / 'cold-pruning-inventory'
    templates = [('tensor', roots[0], 'apple-tensor-original-recipe.json'),
                 ('region', roots[1], 'native-region-original-recipe.json')]
    units = []
    prefixes = ['include', '', 'src/compute', 'src/graph', 'src/compute_batch',
                'src/compute_route_apple', 'src/graph_route_apple', 'src/compute_provider_ggml_metal']
    for name, source, recipe in templates:
        template = b.read(inventory / recipe)
        command = list(template['command'])
        old_source = command[command.index('-c') + 1]
        old_object = command[command.index('-o') + 1]
        output = REMOTE + '/compile/' + name
        command[command.index('-c') + 1] = REMOTE + '/source/' + source
        command[command.index('-o') + 1] = output + '/unit.o'
        command[command.index('-MF') + 1] = output + '/dependencies.d'
        include = []
        for base in (REMOTE + '/source', b.REMOTE + '/source-v3'):
            include.extend('-I' + base + ('/' + suffix if suffix else '') for suffix in prefixes)
        command[1:1] = include
        units.append(dict(name=name, source=source, object=output + '/unit.o', command=command,
                          original_recipe=str((inventory / recipe).relative_to(b.R)),
                          original_source=old_source, original_object=old_object))
    command = list(old['link_command'])
    old_tensor = next(x for x in command if x.endswith('/current--src--compute_route_apple--apple_tensor.cc.o'))
    command[command.index(old_tensor)] = units[0]['object']
    command.insert(next(i for i, x in enumerate(command) if x.endswith('.a')), units[1]['object'])
    command[command.index('-o') + 1] = REMOTE + '/bin/hyle'
    plan = dict(status='FROZEN_TWO_TU_COLD_ADMISSION', remote=REMOTE, base=b.REMOTE,
        author_freeze=EXPECTED, source_identity=old['source_identity'], sources=sources,
        units=units, link_command=command, runtime=old['runtime'],
        base_ready=b.REMOTE + '/ready.json', base_inputs=b.REMOTE + '/link-inputs.json',
        reuse='Original adb2ee9a9 Model/weights and all twelve successful SDK objects, MLX/BF16/system libraries; only direct tensor replacement and native-region archive override.',
        ABI='One private free function may_lower_operation; no public type, object layout, vtable or Model change.')
    b.save(F / 'plan.json', plan)
    b.save(F / 'source-freeze.json', dict(author_freeze=EXPECTED, files=sources,
        reachable_project_files=len(visited), selected_files=len(sources), bytes=sum(x['bytes'] for x in sources)))
    driver = (W / 'cold_driver.py').read_bytes()
    (F / 'driver.py').write_bytes(driver)
    run = (W / 'run_remote.py').read_text(encoding='utf-8')
    run = run.replace("W = Path('" + b.REMOTE + "')", "W = Path('" + REMOTE + "')")
    # The parent helper still validates the original main, but the new native
    # objects have their own exact source freeze and independent actual image.
    (F / 'run_remote.py').write_text(run, encoding='utf-8')
    runs = b.read(W / 'root-controlled-runs.json')
    for item in runs['runs']:
        item['command'][0] = REMOTE + '/bin/hyle'
    b.save(F / 'root-controlled-runs.json', runs)
    with tarfile.open(F / 'thin-cold-pruning.tar.gz', 'w:gz') as archive:
        for item in sources:
            archive.add(F / 'source' / item['path'], arcname='source/' + item['path'])
        for name in ['plan.json', 'source-freeze.json', 'driver.py', 'run_remote.py', 'root-controlled-runs.json']:
            archive.add(F / name, arcname=name)
    b.save(F / 'prepared.json', dict(status='PREPARED_ONLY', source_files=len(sources),
        source_bytes=sum(x['bytes'] for x in sources), archive=b.pin(F / 'thin-cold-pruning.tar.gz'),
        CXX=2, links=1, Q1_not_repeated=True, planned_runs=['mtp-q2', 'mtp-q2-random']))
    print(json.dumps(b.read(F / 'prepared.json'), indent=2))


def sync():
    expected = b.read(F / 'prepared.json')['archive']
    if b.pin(F / 'thin-cold-pruning.tar.gz') != expected:
        raise RuntimeError('thin cold archive drift')
    code = """import io,pathlib,tarfile,sys
w=pathlib.Path(%r)
if w.exists():raise RuntimeError('new refinement destination exists')
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name)
  if not m.isfile() or p.is_absolute() or '..' in p.parts:raise RuntimeError('unsafe archive member')
 for m in t.getmembers():
  p=w/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
print('COLD DELTA SYNCED',w)
""" % REMOTE
    b.call(b.SSH + ['python3 -c ' + shlex.quote(code)], F / 'sync', (F / 'thin-cold-pruning.tar.gz').read_bytes())


def invoke(action, name):
    if action == 'run':
        if name not in ('mtp-q2', 'mtp-q2-random'):
            raise RuntimeError('only the two uncompleted Q2 journeys may run')
        b.call(b.SSH + ['python3 - ' + shlex.quote(name)], F / 'invocations' / ('run-' + name),
               (F / 'run_remote.py').read_bytes())
    else:
        command = ['python3', REMOTE + '/driver.py', action] + ([name or 'all'] if action == 'compile' else [])
        b.call(b.SSH + [shlex.join(command)], F / 'invocations' / (action + ('-' + (name or 'all') if action == 'compile' else '')))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'sync', 'compile', 'link', 'run'])
    parser.add_argument('unit', nargs='?')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    elif args.action == 'sync':
        sync()
    else:
        invoke(args.action, args.unit)
