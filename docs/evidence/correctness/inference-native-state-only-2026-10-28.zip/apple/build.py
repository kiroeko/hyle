"""Local preparation/sync/invocation only; build and GPU never start implicitly."""
import argparse
import datetime
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess
import sys
import tarfile
import time

W = Path(__file__).resolve().parent
R = W.parents[2]
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/inference-native-state-only-20261028/apple'
HOST = 'kiro@172.22.10.198'
SSH = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', HOST]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def prepare():
    if (W / 'plan.json').exists():
        if (W / 'sync').exists() or (W / 'invocations').exists() or (W / 'preparation1').exists():
            raise RuntimeError('executed or already refined plan exists; no overwrite')
        # The initial, never-synced local candidate is retained verbatim. This
        # is a recipe preparation refinement, with zero remote/CXX effect.
        backup = W / 'preparation1'
        backup.mkdir()
        for name in ['plan.json', 'source-freeze.json', 'prepared.json', 'thin-sync.tar.gz']:
            (backup / name).write_bytes((W / name).read_bytes())
    report = read(W.parent / 'platform-plan.json')
    requested = read(W.parent / 'sync-candidates.json')['files']
    files = list(requested)
    # This unchanged private declaration is directly quoted by the derived
    # Apple append TU; copying 751 bytes avoids relying on a coincidental SDK
    # private-header search path. No SDK tree is duplicated.
    extra = 'src/graph_route_apple/native_paged_append_region.h'
    if extra not in {x['path'] for x in files}:
        x = pin(R / extra)
        files.append(dict(x, path=extra, reason='unchanged direct private declaration for relocated Apple append TU'))
    # A relative include is searched beside its including file before -I.
    # Retain only unchanged bridge headers that would otherwise select an old
    # changed sibling from a cached source root (weights.h -> session_state.h,
    # for example). This is smaller than copying an entire project include tree.
    selected = {x['path'] for x in files}
    pending = [R / x for x in report['mac']['refresh_candidate_TUs']]
    visited, relative_edges = set(), {}
    pattern = re.compile(r'^\s*#\s*include\s*([<\"])([^>\"]+)[>\"]', re.MULTILINE)
    while pending:
        path = pending.pop().resolve()
        if path in visited or not path.is_file() or not path.is_relative_to(R):
            continue
        visited.add(path)
        text = path.read_text(encoding='utf-8-sig')
        edges = []
        for delimiter, name in pattern.findall(text):
            candidate = R / 'include' / name if name.startswith('hyle/') else (path.parent / name).resolve() if delimiter == '"' else None
            if candidate is None or not candidate.is_file() or not candidate.is_relative_to(R):
                continue
            pending.append(candidate)
            if delimiter == '"' and not name.startswith('hyle/'):
                edges.append(candidate.relative_to(R).as_posix())
        relative_edges[path.relative_to(R).as_posix()] = edges
    bridges = []
    changed = True
    while changed:
        changed = False
        for rel, children in relative_edges.items():
            if rel in selected or not rel.endswith(('.h', '.hpp')) or not any(x in selected for x in children):
                continue
            selected.add(rel)
            x = pin(R / rel)
            files.append(dict(x, path=rel, reason='unchanged relative-include bridge to current frozen sibling'))
            bridges.append(dict(path=rel, selected_children=[x for x in children if x in selected]))
            changed = True
    save(W / 'quoted-header-bridges.json', dict(method='bounded literal include graph from the 14 selected project TUs; only reverse relative-include bridges copied', bridges=bridges))
    for x in files:
        original = R / x['path']
        actual = pin(original)
        if (actual['bytes'], actual['sha256']) != (x['bytes'], x['sha256']):
            raise RuntimeError('canonical source drift before freeze: ' + x['path'])
        target = W / 'source' / x['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(original.read_bytes())
    records = {
        'engine': '.scratch/inference-apple-engine-slots-20261027/plan.json',
        'frame': '.scratch/inference-paged-frame-20261026/mac/plan.json',
        'host': '.scratch/inference-native-host-image-20261026/mac-model-attempt4/plan.json',
        'store': '.scratch/inference-native-slot-byte-ranges-20261027/records/plan3.json',
        'leases': '.scratch/inference-native-slot-store-20261027/plan.json',
    }
    plans = {k: read(R / v) for k, v in records.items()}
    # name, canonical source, exact template plan/tag, derivation
    specs = [
        ('leases', 'src/compute/resource_leases.cc', 'leases', 'compile-leases', False),
        ('retained', 'src/compute/retained_completion.cc', 'leases', 'compile-leases', True),
        ('arena', 'src/compute_batch/paged_arena.cc', 'frame', 'compile-arena', False),
        ('batch-execution', 'src/compute_batch/batch_execution.cc', 'frame', 'compile-arena', True),
        ('executable', 'src/graph/executable.cc', 'frame', 'compile-executable', False),
        ('input-sources', 'src/graph/input_sources.cc', 'engine', 'compile-resources', True),
        ('resources', 'src/graph/resources.cc', 'engine', 'compile-resources', False),
        ('slots-region', 'src/graph/slots_region.cc', 'engine', 'compile-slots_region', False),
        ('batch', 'src/graph_batch/batch.cc', 'host', 'compile-src--graph_batch--batch.cc', False),
        ('append', 'src/graph_batch/paged_append.cc', 'frame', 'compile-append', False),
        ('native-append', 'src/graph_route_apple/native_paged_append_region.cc', 'store', 'compile-store', True),
        ('native-store', 'src/graph_route_apple/native_slot_store_region.cc', 'store', 'compile-store', False),
        ('model', 'engine/models/qwen35/main.cc', 'engine', 'compile-model', False),
        ('weights', 'engine/models/qwen35/weights.cc', 'engine', 'compile-weights', False),
    ]
    templates = []
    for _, _, key, tag, _ in specs:
        templates.append(next(j for j in plans[key]['jobs'] if j.get('tag') == tag))
    # Keep each original quoted-include directory after the overlay. This
    # preserves original header lookup for the unchanged private files.
    quote_dirs = list(dict.fromkeys(str(PurePosixPath(j['command'][j['command'].index('-c') + 1]).parent) for j in templates))
    overlay_dirs = ['include', '', 'engine', 'src/compute', 'src/graph', 'src/compute_batch',
                    'src/graph_batch', 'src/graph_route_apple', 'src/compute_route_apple',
                    'src/compute_provider_native', 'src/compute_stream']
    units = []
    for (name, source, key, tag, derived), original in zip(specs, templates):
        command = list(original['command'])
        old_source = command[command.index('-c') + 1]
        old_object = command[command.index('-o') + 1]
        obj = f'{REMOTE}/compile/{name}/unit.o'
        command[command.index('-c') + 1] = f'{REMOTE}/source/{source}'
        command[command.index('-o') + 1] = obj
        command[command.index('-MF') + 1] = f'{REMOTE}/compile/{name}/dependencies.d'
        extras = [f'-I{REMOTE}/source' + ('/' + p if p else '') for p in overlay_dirs]
        own_quote = str(PurePosixPath(old_source).parent)
        quotes = [own_quote] + [q for q in quote_dirs if q != own_quote]
        command[1:1] = extras + [v for q in quotes for v in ['-iquote', q]]
        assert '-DHYLE_STATIC' in command and '-std=c++23' in command and '-O3' in command
        units.append(dict(name=name, source=source, object=obj, command=command,
                          original_recipe=records[key], original_tag=tag,
                          original_source=old_source, original_object=old_object,
                          derived_same_module_template=derived))
        save(W / 'recipes' / (name + '.json'), units[-1])
    old_link = list(next(j['command'] for j in plans['engine']['jobs'] if j.get('tag') == 'link'))
    base = '/Users/kiro/hyle-scratch/compute-unified/'
    direct = {
        'leases': base + 'inference-native-slot-store-20261027/leases.o',
        'arena': base + 'inference-paged-frame-20261026/arena.o',
        'batch-execution': base + 'qwen-k1-functional-20261024/attempt1/objects/src--compute_batch--batch_execution.cc.o',
        'executable': base + 'inference-paged-frame-20261026/executable.o',
        'resources': base + 'inference-apple-engine-slots-20261027/resources.o',
        'slots-region': base + 'inference-apple-engine-slots-20261027/slots_region.o',
        'batch': base + 'inference-native-host-image-20261026/model-attempt4/src--graph_batch--batch.cc.o',
        'append': base + 'inference-paged-frame-20261026/append.o',
        'native-store': base + 'inference-native-slot-byte-ranges-20261027/store.o',
        'model': base + 'inference-apple-engine-slots-20261027/model.o',
        'weights': base + 'inference-apple-engine-slots-20261027/weights.o',
    }
    for value in direct.values():
        assert old_link.count(value) == 1, value
    replacements = {old: next(u['object'] for u in units if u['name'] == name) for name, old in direct.items()}
    link = [replacements.get(x, x) for x in old_link]
    additions = [u['object'] for u in units if u['name'] not in direct]
    first_archive = next(i for i, x in enumerate(link) if x.endswith('.a'))
    link[first_archive:first_archive] = additions
    link[link.index('-o') + 1] = f'{REMOTE}/bin/hyle'
    link = [f'-Wl,-map,{REMOTE}/link/image.map' if x.startswith('-Wl,-map,') else x for x in link]
    retained = [x for x in link if x.endswith(('.o', '.a', '.dylib')) and not x.startswith(REMOTE + '/')]
    plan = dict(status='PREPARED_NOT_SYNCED_OR_BUILT', remote=REMOTE, source_identity=report['current_source_pins'],
                sources=files, units=units, retained_inputs=retained, link_command=link,
                original_link_recipe=records['engine'], direct_object_replacements=direct,
                archive_overrides=[dict(unit='input-sources', original='libhyle_graph_current.a(src--graph--input_sources.cc.o)'),
                                   dict(unit='native-append', original='libhyle_graph_route_apple_current.a(src--graph_route_apple--native_paged_append_region.cc.o)'),
                                   dict(unit='retained', original='libhyle_compute_gdn_scale.a(compute--retained_completion.o)')],
                runtime=plans['engine']['environment'],
                limits=['Original lazy archive extraction/order retained; new direct objects precede archives.',
                        'No SDK/library/weight copies or full source-tree snapshot.',
                        '14 TUs are the initial candidate, not permission to ignore real missing symbols or incompatible dependencies.'])
    save(W / 'source-freeze.json', dict(base_commit='314707293', files=files))
    save(W / 'plan.json', plan)
    save(W / 'root-controlled-runs.json', dict(status='PLANNED_NOT_RUN', environment=plan['runtime'],
         runs=[dict(name=f'mtp-q{q}', command=[f'{REMOTE}/bin/hyle', '--inputs', base + 'inference-apple-engine-slots-20261027/fixture',
              '--backend', 'apple', '--capacity', '16', '--max-sessions', '4', '--active-sequences', '1', '--prefix-cache', 'off',
              '--replay', 'commands', '--progress', 'direct', '--sampling', 'greedy', '--mtp', 'on', '--mtp-max-drafts', '3',
              '--steps', '4', '--prefill-chunk-tokens', str(q)]) for q in [1, 2]],
         scope='CLI endpoints/ledger and engine live_committed_versions only; no native allocation live-zero claim or full hidden-state oracle.'))
    with tarfile.open(W / 'thin-sync.tar.gz', 'w:gz') as archive:
        for x in files:
            archive.add(W / 'source' / x['path'], arcname='source/' + x['path'])
        for name in ['driver.py', 'plan.json', 'source-freeze.json', 'root-controlled-runs.json', 'quoted-header-bridges.json']:
            archive.add(W / name, arcname=name)
    save(W / 'prepared.json', dict(status='PREPARED_ONLY', archive=pin(W / 'thin-sync.tar.gz'), plan=pin(W / 'plan.json'),
         files=len(files), source_bytes=sum(x['bytes'] for x in files), CXX=14, links=1, remote=REMOTE))
    print(json.dumps(read(W / 'prepared.json'), ensure_ascii=False, indent=2))


def call(command, output, payload=None):
    output.mkdir(parents=True, exist_ok=False)
    save(output / 'command.json', dict(command=command, cwd=str(R)))
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    with (output / 'stdout.log').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr:
        p = subprocess.Popen(command, cwd=R, stdin=subprocess.PIPE if payload is not None else subprocess.DEVNULL, stdout=stdout, stderr=stderr)
        save(output / 'running.json', dict(pid=p.pid, started_utc=started))
        p.communicate(payload)
        result = dict(pid=p.pid, exit=p.returncode, started_utc=started, seconds=time.monotonic() - clock)
    save(output / 'process.json', result)
    print(json.dumps(result))
    if p.returncode:
        raise RuntimeError('preserved command failure: ' + str(output))


def sync():
    prepared = read(W / 'prepared.json')
    if pin(W / 'thin-sync.tar.gz') != prepared['archive']:
        raise RuntimeError('thin archive drift')
    code = """import io,pathlib,tarfile,sys
w=pathlib.Path(%r)
if w.exists() and any(w.iterdir()):raise RuntimeError('destination exists; no overwrite')
blob=sys.stdin.buffer.read()
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as t:
 for m in t.getmembers():
  p=pathlib.PurePosixPath(m.name)
  if not m.isfile() or p.is_absolute() or '..' in p.parts:raise RuntimeError('unsafe archive member')
 for m in t.getmembers():
  p=w/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
print('SYNCED',w)
""" % REMOTE
    call(SSH + ['python3 -c ' + shlex.quote(code)], W / 'sync', (W / 'thin-sync.tar.gz').read_bytes())
    invoke('preflight', None)


def invoke(action, unit):
    args = ['python3', REMOTE + '/driver.py', action] + ([unit or 'all'] if action == 'compile' else [])
    label = action + ('-' + (unit or 'all') if action == 'compile' else '')
    call(SSH + [shlex.join(args)], W / 'invocations' / label)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('action', choices=['prepare', 'sync', 'compile', 'link'])
    ap.add_argument('unit', nargs='?')
    a = ap.parse_args()
    if a.action == 'prepare':
        prepare()
    elif a.action == 'sync':
        sync()
    else:
        invoke(a.action, a.unit)
