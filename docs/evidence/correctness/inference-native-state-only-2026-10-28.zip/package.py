"""Offline native StateOnly evidence. Execute only after root's six runs/fetch."""
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
APPLE = W / 'apple'
MAC = APPLE / 'readback-final/records'
VK = W / 'vulkan'
DEST = R / 'docs/evidence/correctness/inference-native-state-only-2026-10-28'
MAIN314 = '953f3610c2a0bd12a3b0a88ee9b9cc1bec321e72e993a707c2790adf52d65f50'
MAIN_ADB = 'd58a2d408265871a11966691c116e49d2384dadb8199006e2963833488a52c7c'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def blob(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.relative_to(R)) if path.is_relative_to(R) else str(path),
                bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def require(value, message):
    if not value:
        raise RuntimeError(message)


def compact_run(platform, name, quantum, random, fixed=False):
    root = MAC / 'cold-pruning' if fixed else MAC if platform == 'apple' else VK
    directory = root / 'runs' / name
    process = read(directory / 'process.json')
    require(process['exit'] == 0 and not process.get('timed_out', False), 'actual failed run: ' + name)
    # Always parse the original producer stdout, not an amended summary.
    report = json.loads((directory / 'stdout.log').read_text(encoding='utf-8-sig'))
    require(report['backend'] == platform and report['mtp'], 'wrong producer route: ' + name)
    require(report['session_count'] == report['turn_count'] == 1, 'unexpected cohort: ' + name)
    require(report['logical_prompt_tokens'] == 3 and report['generated_tokens'] == 4, 'wrong P/output count')
    require(report['live_committed_versions'] == 0 and report['packed_prefill_calls'] == 0,
            'not exact cold fallback with engine versions released')
    session = report['sessions'][0]
    result, ledger = session['result'], session['ledger']
    rows = [1, 1, 1] if quantum == 1 else [2, 1]
    prefill = [x for x in ledger if not x['generation']]
    require([x['input_rows'] for x in prefill] == rows and report['prefill_graph_calls'] == len(rows),
            'actual prefill ledger differs: ' + name)
    previous_length, previous_draw = 0, 0
    for at, item in enumerate(ledger):
        require(item['index'] == at and item['turn'] == 1, 'ledger order differs')
        require(item['before_length'] == previous_length and item['sampling_draw_before'] == previous_draw,
                'committed ledger length/RNG discontinuity')
        require(item['after_length'] == previous_length + item['accepted'] and
                item['after_frontier'] + item['after_lag'] == item['after_length'], 'length/frontier differs')
        require(item['sampling_draw_after'] >= previous_draw, 'RNG moved backwards')
        if at < len(prefill) - 1:
            require(item['next_id'] == item['target_first'] == -1 and item['quota'] == 0 and
                    item['sampling_draw_after'] == previous_draw, 'StateOnly chunk made a decision')
        elif at == len(prefill) - 1:
            require(item['next_id'] >= 0 and item['target_first'] >= 0 and
                    item['sampling_draw_after'] == (1 if random else 0), 'final EmitNext/RNG differs')
        if not random:
            require(item['sampling_draw_after'] == 0, 'greedy draw advanced')
        previous_length, previous_draw = item['after_length'], item['sampling_draw_after']
    require(result['sampling_draw_cursor'] == previous_draw and result['visible_tokens'] == previous_length == 6,
            'final cursor/visible length differs')
    require(len(result['generated_ids']) == 4 and all(0 <= x < 64 for x in result['generated_ids']), 'bad IDs')
    require(result['fresh_next_id'] == ledger[-1]['next_id'] == result['generated_ids'][-1], 'final head ID differs')
    if platform == 'apple':
        require(read(directory / 'summary.json')['status'] == 'PASS', 'missing Apple actual parser PASS')
    ready = read(root / ('ready-v2.json' if fixed else 'ready.json'))
    return dict(platform=platform, name=name, image_sha256=ready['image']['sha256'],
        native_cold_fix=fixed, pid=process['pid'], exit=process['exit'],
        prompt_rows=rows, state_only_next=[x['next_id'] for x in prefill[:-1]],
        state_only_draws=[x['sampling_draw_after'] for x in prefill[:-1]],
        ids=result['generated_ids'], final_length=previous_length, next_id=result['fresh_next_id'],
        rng_draw=previous_draw, draft_frontier=result['draft_frontier'], draft_lag=result['draft_lag'],
        packed_calls=report['packed_prefill_calls'], cold_exact_admissions=report['cold_exact_admissions'],
        engine_live_versions=report['live_committed_versions'])


def main():
    require(not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(),
            'evidence destination exists; never overwrite')
    vk_ready, mac_ready = read(VK / 'ready.json'), read(MAC / 'ready.json')
    cold_ready = read(MAC / 'cold-pruning/ready-v2.json')
    require(mac_ready['source_identity']['effective_main']['sha256'] == MAIN_ADB, 'wrong Apple effective source')
    vk_plan = read(VK / 'plan.json')
    require(next(x for x in vk_plan['units'] if x['name'] == 'model')['source']['sha256'] == MAIN314,
            'wrong Vulkan original source')
    vk_compiles = vk_ready['compiled']
    require(len(vk_compiles) == 4 and all(x['process']['exit'] == 0 for x in vk_compiles), 'Vulkan compile failure')
    mac_plan = read(MAC / 'plan-model-v2.json')
    mac_compiles = []
    for unit in mac_plan['units']:
        receipt = read(MAC / 'compile' / unit['name'] / 'compiled.json')
        require(receipt['process']['exit'] == 0, 'Mac successful unit receipt failed')
        mac_compiles.append(dict(unit=unit['name'], pid=receipt['process']['pid'], exit=0))
    require(len(mac_compiles) == 14 and mac_ready['link']['exit'] == vk_ready['link']['exit'] == 0,
            'wrong successful CXX/link totals')
    cold_compiles = [read(MAC / 'cold-pruning/compile' / name / 'compiled.json') for name in ('tensor', 'region')]
    require(all(x['process']['exit'] == 0 for x in cold_compiles) and cold_ready['link']['exit'] == 0,
            'cold fix compilation/link did not pass')
    require(cold_ready['source_identity']['effective_main']['sha256'] == MAIN_ADB,
            'cold fix unexpectedly changed the original Model')
    initial_attempts = [read(p) for p in (MAC / 'compile').glob('*/logs/process.json')]
    require(len(initial_attempts) == 17 and sum(x['exit'] == 0 for x in initial_attempts) == 14,
            'Mac original actual CXX process counts differ')
    failures = []
    reasons = [('retained', 'Thin same-module template omitted completion_internal.h; no product change.'),
               ('arena', 'Old cached public resource_leases.h lacked LeaseSlotLayout declarations; bounded reachable-header overlay repaired selection, no layout change.'),
               ('model', 'Strict Clang -Werror missing-field-initializers; adb2ee9a9 adds only EvaluationRequest::LogitsInputs logits{}.')]
    for unit, reason in reasons:
        process = read(MAC / 'compile' / unit / 'logs/process.json')
        require(process['exit'] != 0, 'missing preserved initial failure: ' + unit)
        failures.append(dict(unit=unit, pid=process['pid'], exit=process['exit'], reason=reason))
    original_q2 = read(MAC / 'runs/mtp-q2/process.json')
    require(original_q2['exit'] != 0, 'missing preserved original Q2 failure')
    failures.append(dict(kind='actual_model_cold_compile', platform='apple', name='mtp-q2-original',
        pid=original_q2['pid'], exit=original_q2['exit'],
        reason='Unsupported Apple typed operation proposal reached Graph search and exhausted its resource-search budget. Not swallowed as a budget fallback.'))
    failed_link = read(MAC / 'cold-pruning/link/logs/process.json')
    require(failed_link['exit'] != 0, 'missing preserved duplicate-symbol link failure')
    failures.append(dict(kind='link_recipe', pid=failed_link['pid'], exit=failed_link['exit'],
        reason='Old direct native.o was retained alongside new region/unit.o; recipe-only replacement in independent link-v2, no extra CXX.'))
    preflight = read(APPLE / 'cold-pruning/invocations/run-mtp-q2/process.json')
    require(preflight['exit'] != 0 and 'ready.json' in
            (APPLE / 'cold-pruning/invocations/run-mtp-q2/stderr.log').read_text(),
            'missing original ready-preflight failure')
    runs = [compact_run(platform, name, quantum, random, fixed=platform == 'apple' and quantum == 2)
            for platform in ('vulkan', 'apple')
            for short, quantum, random in [('q1', 1, False), ('q2', 2, False), ('q2-random', 2, True)]
            for name in [short if platform == 'vulkan' else 'mtp-' + short]]

    files = {}

    def add(path, archive_name=None):
        path = Path(path)
        require(path.is_file(), 'missing required evidence: ' + str(path))
        require(path.suffix.lower() in {'.py', '.json', '.log', '.d', '.h', '.hpp', '.cc', '.cpp', '.diff', '.patch'},
                'forbidden evidence payload: ' + str(path))
        name = archive_name or path.relative_to(W).as_posix()
        require(name not in files, 'duplicate archive member: ' + name)
        files[name] = path

    def tree(path):
        for item in sorted(Path(path).rglob('*')):
            if item.is_file() and item.suffix.lower() in {'.py', '.json', '.log', '.d', '.diff', '.patch'}:
                add(item)

    for name in ['package.py', 'platform-plan.json', 'sync-candidates.json']:
        add(W / name)
    for name in ['build.py', 'driver.py', 'refine_retained.py', 'refine_headers.py', 'refine_model.py',
                 'refine_cold.py', 'cold_driver.py', 'refine_cold_link.py',
                 'run.py', 'run_remote.py', 'root-controlled-runs.json', 'plan.json', 'source-freeze.json',
                 'quoted-header-bridges.json', 'evaluation-init.patch']:
        add(APPLE / name)
    for folder in ['recipes', 'invocations', 'run-invocations', 'retained-v2', 'headers-v3', 'model-v2']:
        base = APPLE / folder
        # Header overlays/source trees and nested archives are not recopied.
        for item in sorted(base.iterdir()):
            if item.is_file() and item.suffix.lower() in {'.py', '.json', '.diff'}:
                add(item)
        if folder in ('model-v2', 'retained-v2', 'headers-v3') and (base / 'invocations').exists():
            tree(base / 'invocations')
        elif folder in ('recipes', 'invocations', 'run-invocations'):
            for item in sorted(base.iterdir()):
                if item.is_dir():
                    tree(item)
    tree(MAC)
    for folder in ['cold-pruning-inventory', 'cold-pruning']:
        tree(APPLE / folder)
    for item in read(APPLE / 'cold-pruning/source-freeze.json')['files']:
        add(APPLE / 'cold-pruning/source' / item['path'], 'apple/cold-pruning/source/' + item['path'])
    # Selected project source is bounded by the fourteen refreshed TUs and
    # actual initial delta, not an SDK/header-tree copy. The full reachable
    # header identities and compiler dependencies remain in raw receipts.
    selected = {x['path'] for x in read(W / 'sync-candidates.json')['files']}
    selected.update(['src/compute/completion_internal.h', 'src/graph_route_apple/native_paged_append_region.h'])
    for relative in sorted(selected):
        add(APPLE / 'headers-v3/source-v3' / relative, 'frozen-project/' + relative)
    add(APPLE / 'model-v2/source-v3/engine/models/qwen35/main-model-v2.cc',
        'frozen-project/engine/models/qwen35/main-model-v2.cc')
    author_fix = R / '.scratch/inference-apple-cold-admission-20261028'
    for name in ['source-freeze.json', 'candidate.diff']:
        add(author_fix / name, 'apple-cold-author/' + name)
    fix_receipt = read(author_fix / 'source-freeze.json')
    require({x['path']: x['sha256'] for x in fix_receipt['sources']} == cold_ready['native_fix'],
            'author/native image patch identity mismatch')
    # Add the two Vulkan-only implementations from their actual preflight pins.
    for unit in vk_plan['units']:
        source = unit['source']
        relative = Path(source['path']).relative_to(R).as_posix()
        # main is now legitimately newer in the shared worktree. Its immutable
        # v3 snapshot is the exact original Vulkan source, not current WIP.
        frozen = APPLE / 'headers-v3/source-v3' / relative
        actual = frozen if frozen.is_file() else Path(source['path'])
        require(pin(actual)['sha256'] == source['sha256'], 'Vulkan as-run source mismatch: ' + str(actual))
        if 'frozen-project/' + relative not in files:
            add(actual, 'frozen-project/' + relative)
    for name in ['build.py', 'inventory.py', 'plan.json', 'ready.json', 'link-inputs.json', 'source-freeze.json',
                 'freeze.json', 'common-reuse.json', 'abi-review.json', 'environment.json', 'runtime.json',
                 'run-q1.json', 'run-q2.json', 'report-q1.json', 'report-q2.json', 'report-q2-random.json']:
        add(VK / name)
    for folder in ['recipes', 'logs', 'compile', 'link', 'runs']:
        tree(VK / folder)
    references = []
    for name in ['inference-append-transactions-2026-10-28.json', 'inference-paged-frame-macos-2026-10-26.json',
                 'inference-native-slot-store-2026-10-27.json']:
        path = R / 'docs/evidence/correctness' / name
        identity = pin(path)
        references.append(identity)
        add(path, 'referenced-evidence/' + name)
    report = dict(status='PASS_SIX_NATIVE_CLI_CHECKS', created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Cached synthetic GA/H64/V64/C16; native exact fallback and StateOnly/EmitNext ledger facts. No model quality or performance claim.',
        source=dict(vulkan_commit='314707293', vulkan_main_sha256=MAIN314, apple_commit='adb2ee9a9',
            apple_main_sha256=MAIN_ADB, apple_amendment='314707293 plus only default initialization of EvaluationRequest::logits; no layout change.'),
        builds=dict(apple_initial_selected_TUs=14, apple_initial_actual_CXX_attempts=17,
            apple_initial_successful_CXX=14, apple_initial_refreshed_Hyle_SDK_TUs=12,
            apple_cold_fix_selected_TUs=2, apple_total_actual_CXX_attempts=19,
            apple_total_successful_CXX=16, apple_failed_CXX=3,
            vulkan_actual_CXX_attempts=4, vulkan_successful_CXX=4,
            total_actual_CXX_attempts=23, total_successful_CXX=20,
            actual_link_attempts=4, successful_links=3, failed_recipe_links=1,
            third_party_SDK_MLX_library_full_rebuilds=0,
            downloads=0, Metal_shader_rebuilds=0),
        images=dict(vulkan=vk_ready['image'], apple_q1_original=mac_ready['image'], apple_q2_fixed=cold_ready['image']),
        native_cold_fix=dict(files=cold_ready['native_fix'],
            author_patch_base=fix_receipt['base'],
            image_composition='adb2ee9a9 Model d58a2 plus the three exact native patch files; not an entire current HEAD build.',
            contract='Compute-owned actual lowering predicate prunes unsupported native Graph candidates; CustomLowering retained; native/other errors propagate. No Model, public layout or generic search changes.'),
        actual_inference_processes=dict(total=7, successful=6, original_Q2_failed=1,
            Q1_success_not_repeated=True, original_random_not_started=True,
            extra_missing_ready_invocation=dict(local_ssh_pid=preflight['pid'], exit=preflight['exit'],
                kind='Runner preflight only after failed link; no inference/GPU process started.')),
        preserved_failures=failures, runs=runs,
        checks=['Q1 actual chunks 1+1+1; Q2 actual chunks 2+1; packed_calls=0 exact native route.',
                'Intermediate StateOnly next_id=-1 and unchanged RNG; final EmitNext has a real ID.',
                'Original ledger length/frontier/lag/RNG chain and engine live_committed_versions=0.',
                'Q2 random uses the original temperature=1/top-k=8/seed=123 path.'],
        limits=['CLI facts do not prove full KV/GDN/conv/hidden state byte identity or native allocation live-zero.',
                'No cross-platform bit identity, capture/device relay, R2 effective-length native support or full route matrix claim.',
                'Only the cached untrained fixture and three bounded MTP journeys per platform were run.',
                'Build/run durations are raw provenance, not performance samples.',
                'System/MLX/BF16/Torch libraries and weights are reused by identity; no binary/SDK/model payload is archived.'],
        references=references, raw_manifest='manifest.json')
    entries = {name: path.read_bytes() for name, path in files.items()}
    entries['evidence-core.json'] = blob(report)
    manifest = [dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
                for name, data in sorted(entries.items())]
    entries['manifest.json'] = blob(dict(files=manifest, excludes=['binary', 'OBJ', 'EXE', 'PDB', 'DLL', 'SDK', 'weights']))
    DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DEST.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(entries.items()):
            archive.writestr(name, data)
    with zipfile.ZipFile(DEST.with_suffix('.zip')) as archive:
        require(archive.testzip() is None, 'ZIP CRC failure')
        require(set(archive.namelist()) == set(entries), 'ZIP member mismatch')
        for name, expected in entries.items():
            require(archive.read(name) == expected, 'ZIP readback mismatch: ' + name)
    report['archive'] = dict(pin(DEST.with_suffix('.zip')), files=len(entries), verified_readback=True)
    DEST.with_suffix('.json').write_bytes(blob(report))
    print(json.dumps(dict(json=pin(DEST.with_suffix('.json')), archive=report['archive'],
                         actual_successful_runs=len(runs), actual_failed_runs=1,
                         CXX_success=20, CXX_failure=3, link_success=3, link_failure=1), indent=2))


if __name__ == '__main__':
    main()
