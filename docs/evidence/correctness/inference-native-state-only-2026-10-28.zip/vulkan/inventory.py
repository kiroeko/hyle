from pathlib import Path
import json,re
R=Path.cwd();W=R/'.scratch/inference-native-state-only-20261028/vulkan'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def source_name(p):
 n=str(p).replace('\\','/').lower();root=str(R).replace('\\','/').lower()+'/'
 if n.startswith(root) and not n[len(root):].startswith('.scratch/'):return n[len(root):]
 for marker in ['/source/src/','/source/engine/','/source2/src/']:
  if marker in n:return marker.split('/')[-2]+'/'+n.split(marker,1)[1]
 return None
cache={}
def record(row):
 p=Path(row['path']);out={'object':row};d=p.parent
 if p.suffix.lower()!='.obj':return out
 candidates=[d/'dependencies.json',d/'deps.json',d/(p.stem+'-deps.json'),d/(p.stem+'.deps.json'),d/(p.stem+'-dependencies.json')]
 candidates=[x for x in candidates if x.exists()]
 found=[]
 for c in candidates:
  try:v=read(c)
  except Exception:continue
  if isinstance(v,dict) and isinstance(v.get('Data'),dict) and v['Data'].get('Source'):
   found.append((c,v['Data']))
 if not found:
  if str(d) not in cache:
   a=[]
   for c in d.glob('*.json'):
    if 'dep' not in c.name.lower():continue
    try:v=read(c)
    except Exception:continue
    if isinstance(v,dict) and isinstance(v.get('Data'),dict) and v['Data'].get('Source'):a.append((c,v['Data']))
   cache[str(d)]=a
  a=cache[str(d)];wanted=p.stem.lower().replace('--','/').replace('-','_')
  found=[x for x in a if wanted.endswith(Path(x[1]['Source']).stem.lower())]
  if len(found)!=1 and len(a)==1:found=a
 if len(found)!=1:out['error']={'dependency_candidates':[str(x[0]) for x in found]};return out
 dp,data=found[0];out.update(data_source=data['Source'],source=source_name(data['Source']),dependencies=str(dp))
 rp=d/'command.json'
 if not rp.exists():rp=d/(p.stem+'-command.json')
 if rp.exists():
  c=read(rp);args=c.get('command',c) if isinstance(c,dict) else c
  if isinstance(args,list):out.update(recipe=str(rp),defines=[x for x in args if x.startswith(('/D','-D'))])
 return out
inventory={name:[record(x) for x in read(R/path)] for name,path in [('vulkan','.scratch/inference-vulkan-engine-slots-20261027/link-inputs.json'),('current','.scratch/inference-append-transactions-20261028/inputs-model.json')]}
(W/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for k,rows in inventory.items():
 print(k,'inputs',len(rows),'objects',sum(x['object']['path'].endswith('.obj') for x in rows),'unmapped',[(x['object']['path'],x.get('error')) for x in rows if x['object']['path'].endswith('.obj') and not x.get('source')])
a={x['source']:x for x in inventory['vulkan'] if x.get('source')};b={x['source']:x for x in inventory['current'] if x.get('source')}
print('CURRENT COMMON DELTA')
for src,x in a.items():
 if src in b and x['object']['path'].lower()!=b[src]['object']['path'].lower():print(src, b[src].get('defines'),b[src].get('recipe'))
print('CURRENT ADDITIONS')
for src,x in b.items():
 if src not in a and not any(y in src for y in ['cuda','cublas','flashinfer']):print(src,x.get('defines'),x.get('recipe'))
