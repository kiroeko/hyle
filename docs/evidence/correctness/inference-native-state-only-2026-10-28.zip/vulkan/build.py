"""Current Windows Vulkan closure; explicit metadata/one-unit/link/run actions only."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[2]
BASE=R/'.scratch/inference-vulkan-engine-slots-20261027'
CURRENT=R/'.scratch/inference-append-transactions-20261028'
PLATFORM=W.parent/'platform-plan.json'
PREFIX=('src/compute/','src/compute_batch/','src/compute_ops/','src/compute_state/','src/compute_stream/','src/compute_stream_cpu/','src/compute_backend_cpu/','src/compute_provider_native/','src/compute_provider_ggml/','src/compute_ggml_runtime/','src/compute_route_cpu/','src/graph/','src/graph_batch/','src/graph_progress/','src/graph_route_cpu/','src/graph_provider_onednn/','src/io_core/','src/mem/','src/mem_vm/')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p;p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def key(p):return str(p).replace('\\','/').casefold().rstrip('/')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def exact(v):
 p=pin(v['path']);assert p['bytes']==v['bytes'] and p['sha256']==v['sha256'],(v,p)
def command(p):
 v=read(p);return v['command'] if isinstance(v,dict) else v
def depfiles(p):
 d=read(p)['Data'];return list(dict.fromkeys([d['Source']]+d.get('Includes',[])))
def project(p):
 try:rel=Path(p).resolve().relative_to(R);return rel.parts[0]!='.scratch'
 except ValueError:return False
def recipe_for(row):
 if row.get('recipe'):return Path(row['recipe'])
 p=Path(row['object']['path']).parent/'compiled.json'
 if p.exists():
  c=read(p).get('command');q=c.get('path') if isinstance(c,dict) else None
  if q and Path(q).exists():return Path(q)
 return None

def prepare():
 assert not (W/'plan.json').exists()
 inv=read(W/'inventory.json');old=inv['vulkan'];current=inv['current'];platform=read(PLATFORM)
 a={x['source']:x for x in old if x.get('source')};common={x['source']:x for x in current if (x.get('source') or '').startswith(PREFIX)}
 assert len(old)==145 and len(current)==229
 # These are actual compiler Data.Source mappings, with byte equality for every
 # adopted current source/snapshot. Engine endpoint variants are never adopted.
 reuse=[]
 for src,row in common.items():
  assert Path(row['data_source']).read_bytes()==(R/src).read_bytes(),src
  rp=recipe_for(row)
  reuse.append(dict(source=src,data_source=row['data_source'],source_identity=pin(R/src),object=row['object'],
    dependencies=pin(row['dependencies']),recipe=pin(rp) if rp else None,
    defines=[x for x in command(rp) if x.startswith(('/D','-D'))] if rp else None,
    flags_basis='Actual command where retained; otherwise already verified current common object, not a backend-dependent engine endpoint.'))
 retained=[];replacements=[]
 names={'engine/models/qwen35/main.cc':'model','engine/models/qwen35/weights.cc':'weights',
  'src/graph_route_vulkan/native_paged_append.cc':'native-append','src/graph_route_vulkan/native_slot_store.cc':'native-store'}
 for row in old:
  src=row.get('source')
  if src in names:
   name=names[src];retained.append({'path':str(W/'compile'/name/'unit.obj'),'unit':name})
  elif src in common:
   retained.append(common[src]['object'])
   if key(row['object']['path'])!=key(common[src]['object']['path']):replacements.append({'source':src,'old':row['object'],'current':common[src]['object']})
  else:retained.append(row['object'])
 additions=[]
 for src,row in common.items():
  if src not in a:retained.append(row['object']);additions.append({'source':src,'object':row['object']})
 assert len(retained)==170 and len({key(x['path']) for x in retained})==170
 for x in retained:
  if 'unit' not in x:assert Path(x['path']).is_file() and Path(x['path']).stat().st_size==x['bytes']
 units=[];known={}
 recipes={
  'model':BASE/'recipes/model.json','weights':BASE/'recipes/weights.json',
  'native-append':Path(platform['windows_vulkan']['vulkan_specific_refresh'][0]['recipe']),
  'native-store':Path(platform['windows_vulkan']['vulkan_specific_refresh'][1]['recipe'])}
 byname={v:k for k,v in names.items()}
 for name,src in byname.items():
  before=a[src];oldrecipe=recipes[name];args=command(oldrecipe);out=W/'compile'/name;nextargs=[]
  assert any(str(x).lower().endswith(('.cc','.cpp','.cxx')) for x in args)
  for i,x in enumerate(args):
   if i and args[i-1].lower()=='/sourcedependencies':x=str(out/'dependencies.json')
   elif x.lower().startswith('/fo'):x='/Fo'+str(out/'unit.obj')
   elif x.lower().startswith('/fd'):x='/Fd'+str(out/'unit.pdb')
   elif x.lower().endswith(('.cc','.cpp','.cxx')):x=str(R/src)
   nextargs.append(x)
  assert not any('HYLE_COMPUTE_CUDA' in x or 'HYLE_COMPUTE_APPLE' in x for x in nextargs)
  if name in ['model','weights']:assert '/DHYLE_COMPUTE_CPU=1' in nextargs and '/DHYLE_COMPUTE_VULKAN=1' in nextargs
  rp=W/'recipes'/(name+'.json');save(rp,{'command':nextargs,'cwd':str(R),'timeout_seconds':300})
  units.append({'name':name,'source':pin(R/src),'old_object':before['object'],'old_recipe':pin(oldrecipe),'recipe':pin(rp),'original_dependencies':pin(before['dependencies'])})
  for p in depfiles(before['dependencies']):
   if Path(p).is_file():known[key(p)]=pin(p)
  sp=W/'source'/src;sp.parent.mkdir(parents=True,exist_ok=True);sp.write_bytes((R/src).read_bytes())
 # New Model/includes are current while the endpoint macros remain Vulkan.
 for dp in [CURRENT/'compile/model/dependencies.json',CURRENT/'compile/tiny/dependencies.json']:
  for p in depfiles(dp):
   if Path(p).is_file():known[key(p)]=pin(p)
 # Follow canonical quote/project angle includes, avoiding old source overlays.
 roots=[R,R/'include',R/'engine'];todo=[Path(x['path']) for x in known.values() if project(x['path'])];seen=set()
 while todo:
  p=todo.pop();k=key(p)
  if k in seen:continue
  seen.add(k);known[k]=pin(p)
  for inc in re.findall(r'^\s*#\s*include\s*[<"]([^>"]+)[>"]',p.read_text(encoding='utf-8',errors='replace'),re.M):
   found=next((d/inc for d in [p.parent,*roots] if (d/inc).is_file()),None)
   if found and project(found):todo.append(found)
 for u in units:known[key(u['source']['path'])]=u['source']
 save(W/'source-freeze.json',list(known.values()));save(W/'common-reuse.json',reuse)
 # Exact private ABI consumers found by actual Includes, not inferred from names.
 stores=[]
 for row in old:
  if row.get('dependencies') and any(p.replace('\\','/').lower().endswith('/src/graph/slots_region.h') for p in depfiles(row['dependencies'])):
   stores.append({'source':row.get('source'),'resolution':'refresh native-store' if row.get('source')==byname['native-store'] else 'current common object'})
 abi={'store_facts_consumers':stores,'shared_headers':{},'platform_basis':platform['abi_reuse_basis']}
 for rel in ['src/graph_batch/native_append_regions.h','src/graph_batch/native_pending_regions.h']:
  oldb=subprocess.check_output(['git','show','bfe7159d4:'+rel],cwd=R)
  assert oldb==(R/rel).read_bytes(),rel;abi['shared_headers'][rel]={'current':pin(R/rel),'bfe7159d4_identical':True}
 save(W/'abi-review.json',abi)
 env=read(R/'.scratch/inference-indexed-store-20261028/environment.json');save(W/'environment.json',env)
 native=pin(R/'.scratch/inference-slot-cohort-refinement-20261028/bin/hyle_ggml_cpu_gdn_scale_v3.dll')
 assert native['sha256']=='6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f'
 assert read(BASE/'runtime.json')['native']['sha256']==native['sha256']
 dirs=[W/'bin',Path(next(x['object']['path'] for x in old if x['object']['path'].endswith('torch_cpu.lib'))).parent,
  R/'.scratch/gdn-vulkan-output-scale-20261024/link1',R/'.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/vendor/src',
  R/'.scratch/bench-api-runtime/vulkan/build/native/hyle/src/compute_ggml_runtime/vendor/src/ggml-vulkan',
  R/'.scratch/bench-api-runtime/vulkan/build/native/hyle/_deps/iv/build/runtime/src/iree/runtime',
  R/'.scratch/bench-api-runtime/vulkan/build/native/hyle/_deps/iv/build/build_tools/third_party/flatcc',
  R/'.scratch/build-compute-v2-dev/bin',R/'.scratch/build-compute-v2-dev/lib',Path(recipes['model'] and command(recipes['model'])[0]).parent,
  Path(os.environ.get('SystemRoot','C:/Windows'))/'System32',Path(os.environ.get('SystemRoot','C:/Windows'))]
 save(W/'runtime.json',{'PATH':';'.join(str(x) for x in dict.fromkeys(dirs)),'native':native,'same_as_verified_old_native':True,'hardlink_on_link':str(W/'bin'/Path(native['path']).name)})
 fixture=R/platform['windows_vulkan']['fixture']['directory']
 fixture_pins=[pin(fixture/x) for x in ['weights.tsv','prompt.ids']]
 save(W/'plan.json',{'status':'PREPARED_NOT_COMPILED','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
  'platform_plan':pin(PLATFORM),'baseline_ready':pin(BASE/'ready.json'),'baseline_inputs':pin(BASE/'link-inputs.json'),
  'current_ready':pin(CURRENT/'ready-model.json'),'current_inputs':pin(CURRENT/'inputs-model.json'),
  'units':units,'link_template':pin(BASE/'link/command.json'),'link_inputs':retained,'replacements':replacements,'additions':additions,
  'input_count':len(retained),'source_freeze':pin(W/'source-freeze.json'),'common_reuse':pin(W/'common-reuse.json'),'abi_review':pin(W/'abi-review.json'),
  'environment':pin(W/'environment.json'),'runtime':pin(W/'runtime.json'),'fixture':str(fixture),'fixture_metadata':fixture_pins,
  'budgets':{'host_CXX':4,'link':1,'SDK':0,'shaders':0,'NVCC':0,'downloads':0},'run_actions':['q1','q2'],
  'boundaries':['Prepared only; no current Vulkan compile/link/device pass asserted.','Current common objects are model-neutral; Model/weights use matching original CPU+Vulkan endpoint macros.','No zero-live claim is inferred from ordinary CLI exit; actual ledger/endpoints remain to be checked.']})
 print('PREPARED',len(units),'CXX',len(retained),'inputs')

def load():
 p=read(W/'plan.json');exact(p['source_freeze']);exact(p['environment']);exact(p['runtime'])
 for u in p['units']:exact(u['source']);exact(u['recipe'])
 return p

def freeze():
 p=load()
 for x in read(W/'source-freeze.json'):exact(x)
 save(W/'freeze.json',{'status':'SOURCE_FROZEN_NOT_BUILT','plan':pin(W/'plan.json'),'source_freeze':p['source_freeze'],'script':pin(__file__)})
 print('FROZEN')

def env(runtime=False):
 e=os.environ.copy();e.update(read(W/'environment.json'))
 if runtime:e['PATH']=read(W/'runtime.json')['PATH']
 e.update(HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',TRANSFORMERS_OFFLINE='1');return e

def execute(args,out,timeout,runtime=False):
 out=Path(out);out.mkdir(parents=True,exist_ok=False);save(out/'command.json',{'command':args,'cwd':str(R),'timeout_seconds':timeout})
 start=time.time()
 with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
  proc=subprocess.Popen(args,cwd=R,env=env(runtime),stdout=stdout,stderr=stderr)
  save(out/'running.json',{'pid':proc.pid,'started':start})
  timed=False
  try:code=proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:timed=True;proc.kill();code=proc.wait()
 result={'pid':proc.pid,'exit':code,'started':start,'seconds':time.time()-start,'timed_out':timed,'state':'TERMINAL'}
 save(out/'process.json',result);assert code==0 and not timed,result;return result

def parse_compile(name):
 p=load();u=next(x for x in p['units'] if x['name']==name);out=W/'compile'/name;process=read(W/'logs'/name/'process.json');assert process['exit']==0
 assert not (out/'compiled.json').exists();known={key(x['path']):x for x in read(W/'source-freeze.json')};actual=[]
 for f in depfiles(out/'dependencies.json'):
  assert key(f) in known,('Missing prepin after successful compiler; metadata error do not recompile',f)
  exact(known[key(f)]);actual.append(known[key(f)])
 exact(u['source']);save(out/'actual-dependencies.json',actual)
 save(out/'compiled.json',{'unit':u,'source':u['source'],'object':pin(out/'unit.obj'),'process':process,'command':pin(W/'logs'/name/'command.json'),'actual_dependencies':pin(out/'actual-dependencies.json')})
 print('PARSED',name)

def compile_one(name):
 p=load();exact(read(W/'freeze.json')['plan']);u=next(x for x in p['units'] if x['name']==name)
 for x in read(W/'source-freeze.json'):exact(x)
 out=W/'compile'/name;out.mkdir(parents=True,exist_ok=False)
 execute(command(u['recipe']['path']),W/'logs'/name,300);parse_compile(name)

def link():
 p=load();exact(read(W/'freeze.json')['plan']);compiled={u['name']:read(W/'compile'/u['name']/'compiled.json') for u in p['units']};inputs=[]
 for x in p['link_inputs']:inputs.append(compiled[x['unit']]['object'] if 'unit' in x else x)
 for x in inputs:exact(x)
 image=W/'bin/hyle.exe';image.parent.mkdir(exist_ok=True);assert not image.exists()
 original=read(p['baseline_inputs']['path']);repls={key(a['path']):b['path'] for a,b in zip(original,inputs[:145])};args=[]
 for a in command(p['link_template']['path']):
  if key(a) in repls:a=repls[key(a)]
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map'),('/ILK:','.ilk')]:
   if a.upper().startswith(prefix):a=prefix+str(image.with_suffix(suffix));break
  args.append(a)
 args.extend(x['path'] for x in inputs[145:])
 for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib')]:
  if not any(a.upper().startswith(prefix) for a in args):args.append(prefix+str(image.with_suffix(suffix)))
 save(W/'link-inputs.json',inputs);process=execute(args,W/'link',240)
 rt=read(W/'runtime.json');exact(rt['native']);alias=Path(rt['hardlink_on_link']);assert not alias.exists();os.link(rt['native']['path'],alias)
 save(W/'ready.json',{'status':'BUILT_NOT_RUN','image':pin(image),'link':process,'recipe':pin(W/'link/command.json'),'inputs':pin(W/'link-inputs.json'),'compiled':list(compiled.values()),'plan':pin(W/'plan.json'),'runtime':pin(W/'runtime.json'),'native_hardlink':pin(alias)})
 print('READY',str(image))

def run(name):
 assert name in ['q1','q2'];p=load();ready=read(W/'ready.json');exact(ready['image']);exact(ready['native_hardlink'])
 for x in p['fixture_metadata']:exact(x)
 args=[ready['image']['path'],'--inputs',p['fixture'],'--backend','vulkan','--replay','commands','--progress','direct','--capacity','16',
  '--max-sessions','4','--active-sequences','1','--prefix-cache','off','--steps','4','--sampling','greedy','--mtp','on','--mtp-max-drafts','3','--prefill-chunk-tokens',name[1:]]
 result=execute(args,W/'runs'/name,240,True);save(W/('run-'+name+'.json'),{'process':result,'image':ready['image'],'raw_stdout':str(W/'runs'/name/'stdout.log'),'raw_stderr':str(W/'runs'/name/'stderr.log'),'scope':'Functional raw report only; ledger/native retirement interpretation is separate.'});print('RAN',name)

if __name__=='__main__':
 try:
  action=sys.argv[1]
  if action=='prepare':prepare()
  elif action=='freeze':freeze()
  elif action=='compile':compile_one(sys.argv[2])
  elif action=='parse-compile':parse_compile(sys.argv[2])
  elif action=='link':link()
  elif action=='run':run(sys.argv[2])
  else:raise ValueError(action)
 except Exception:
  traceback.print_exc();raise SystemExit(1)
