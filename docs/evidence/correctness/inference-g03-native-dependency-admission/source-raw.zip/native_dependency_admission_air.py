from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688'
out=base/'g03-native-dependency-admission';out.mkdir(exist_ok=True)
candidate='9404af694'
identity={n:subprocess.check_output(a,text=True).strip() for n,a in [
    ('model',['/usr/sbin/sysctl','-n','hw.model']),('arch',['uname','-m']),
    ('os',['sw_vers']),('compiler',['xcrun','clang','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
with zipfile.ZipFile(out/sys.argv[1]) as archive:
    manifest=json.loads(archive.read('input-manifest.json'))
    for row in manifest:
        relative=Path(row['path']);assert not relative.is_absolute() and '..' not in relative.parts
        data=archive.read(row['path']);assert hashlib.sha256(data).hexdigest()==row['sha256']
        path=source/relative
        if not path.exists() or path.read_bytes()!=data:path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
record=out/'result.json';rows=json.loads(record.read_bytes()).get('stages',[]) if record.exists() else []
def run(route,stage,args):
    attempt=1+sum(r['route']==route and r['stage']==stage for r in rows)
    log=out/f'{route}-{stage}-{attempt}.log';start=time.monotonic()
    with log.open('w') as stream:
        p=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT)
        (out/'job.json').write_text(json.dumps({'state':'RUNNING','route':route,'stage':stage,'pid':p.pid,'log':str(log)}))
        print('RUN',route,stage,'PID',p.pid,flush=True);code=p.wait()
    row={'route':route,'stage':stage,'attempt':attempt,'command':args,'exit_code':code,'log':str(log),'elapsed_seconds':time.monotonic()-start}
    rows.append(row)
    record.write_text(json.dumps({'candidate':candidate,'identity':identity,'inputs':manifest,'stages':rows,
        'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows),
        'scope':'finite original native cancelled dependency admission; private source fixture plus public65 and original lifecycle; not final receiver aggregation'},indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if code:
        print(log.read_text(errors='replace')[-5500:],flush=True)
        (out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':code,'route':route,'stage':stage}));raise SystemExit(code)
for route in ['apple','vulkan']:
    producer=base/f'a-cpu-{route}/selected-graph/static-sdk-build'
    cache=(producer/'CMakeCache.txt').read_text()
    assert 'CMAKE_HOME_DIRECTORY:INTERNAL='+str(source) in cache
    run(route,'producer-build',['/opt/homebrew/bin/cmake','--build',str(producer),'--target',f'hyle_compute_route_{route}','--parallel','4'])
    prefix=out/(route+'-source-static-stage')
    run(route,'install',['/opt/homebrew/bin/cmake','--install',str(producer),'--prefix',str(prefix)])
    parent=out/(route+'-source-parent');parent.mkdir(exist_ok=True);build=out/(route+'-source-build')
    admission='pending_attention_receiver'+('' if route=='apple' else '_vulkan')+'_probe.cc'
    risk='pending_copy_owner_probe.cc' if route=='apple' else 'copy_update_vulkan_risks.cc'
    targets=[('admission',admission),('public','copy_update_public_consumer.cc'),('risks',risk)]
    cmake='cmake_minimum_required(VERSION 3.25)\nproject(g03_native_dependency_admission LANGUAGES CXX)\nfind_package(Hyle CONFIG REQUIRED COMPONENTS compute)\n'
    for target,name in targets:
        cmake+=f'add_executable({target} "{source/"tests/compute_batch"/name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_compile_options({target} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({target} PRIVATE hyle::compute)\nhyle_stage_runtime({target})\n'
        if route=='vulkan':cmake+=f'target_include_directories({target} SYSTEM PRIVATE /opt/homebrew/include)\n'
    cmake+='target_compile_definitions(admission PRIVATE HYLE_PENDING_ADMISSION_QUALIFICATION=1)\n'
    cmake+=f'target_compile_definitions(public PRIVATE HYLE_COPY_UPDATE_{route.upper()}=1)\n'
    (parent/'CMakeLists.txt').write_text(cmake)
    run(route,'configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
    run(route,'build',['/opt/homebrew/bin/cmake','--build',str(build),'--target']+[t for t,_ in targets]+['--parallel','4'])
    commands=json.loads((build/'compile_commands.json').read_bytes())
    assert all('-DHYLE_STATIC' in r['command'] for r in commands)
    assert any(r['file'].endswith(admission) and '-DHYLE_PENDING_ADMISSION_QUALIFICATION=1' in r['command'] for r in commands)
    (out/(route+'-compiled-inputs.json')).write_text(json.dumps(commands,indent=2)+'\n')
    for target,_ in targets:run(route,target,[str(build/target)])
(out/'job.json').write_text(json.dumps({'state':'TERMINAL','exit_code':0}))
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in out.iterdir():
        if path.is_file() and path.suffix in ['.log','.json','.py']:archive.write(path,path.name)
