from pathlib import Path
import json,subprocess,time,zipfile
root=Path('/Users/kiro/hyle-scratch/compute-unified/g03-native-dependency-admission-validation')
rows=[]
for script,modes in [('dependency_admission_san_air.py',['asan','ubsan','tsan']),('dependency_admission_sdk_air.py',['static','shared'])]:
 for route in ['apple','vulkan']:
  for mode in modes:
   args=['python3',str(root/script),route,mode]
   print('BEGIN',route,mode,flush=True)
   started=time.monotonic();result=subprocess.run(args)
   rows.append({'route':route,'mode':mode,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-started})
   (root/'result.json').write_text(json.dumps({'candidate':'9404af694','stages':rows,'cumulative_seconds':sum(r['elapsed_seconds'] for r in rows)},indent=2)+'\n')
   if result.returncode:raise SystemExit(result.returncode)
with zipfile.ZipFile(root/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for route in ['apple','vulkan']:
  for mode in ['asan','ubsan','tsan','static','shared']:
   dirname='g03-dependency-admission-'+('host-'+route+'-'+mode if mode in ['asan','ubsan','tsan'] else route+'-'+mode+'-sdk')
   folder=root.parent/dirname
   for p in folder.iterdir():
    if p.is_file() and p.suffix in ['.json','.log','.py']:z.write(p,dirname+'/'+p.name)
 for p in root.iterdir():
  if p.is_file() and p.suffix in ['.json','.py']:z.write(p,p.name)
