from pathlib import Path
import importlib.util,os
WORK=Path(__file__).resolve().parent;ROOT=WORK.parents[1];E4=ROOT/'.scratch/inference-e4-model-20261025'
spec=importlib.util.spec_from_file_location('e4_check',E4/'check_cpu.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
attempt=WORK/'model-regression1';assert not attempt.exists()
previous=c.read(E4/'cpu2/link/command.json')['command']
compiler=c.read(E4/'cpu1/compile/command.json')['command'][0]
env=c.discover_environment(compiler='msvc',cache=dict(CMAKE_C_COMPILER=compiler,CMAKE_CXX_COMPILER=compiler,CMAKE_GENERATOR='Ninja'),backends=()).env
mapping={str(E4/'cpu2/compile-arena/unit.obj'):str(WORK/'cpu1/compile/cpu-arena/unit.obj'),
    str(ROOT/'.scratch/inference-e4-append-implementation-20261025/clean-final/compile/cpu-append/unit.obj'):str(WORK/'cpu1/compile/cpu-append/unit.obj')}
command=[];replaced=[]
for word in previous:
    if word.lower().startswith(('/out:','/pdb:','/implib:','/map:')):continue
    if word in mapping:replaced.append(dict(before=word,after=mapping[word]));word=mapping[word]
    command.append(word)
assert len(replaced)==2
app=E4/'cpu1/compile/unit.obj'
c.save(attempt/'link-inputs.json',dict(replacements=replaced,reused_app=c.pin(app),
    absolute_inputs=[c.pin(Path(word)) for word in command if Path(word).is_absolute() and Path(word).suffix.lower() in ('.obj','.lib')]))
image=attempt/'link/component.exe'
linked=c.execute([*command,'/OUT:'+str(image),'/PDB:'+str(attempt/'link/component.pdb'),'/IMPLIB:'+str(attempt/'link/component.lib')],env,attempt/'link',90)
native=ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,image.parent/native.name)
run_env=dict(env);run_env['PATH']=str(image.parent)+';'+c.read(ROOT/'.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')['PATH']
run_env['HF_HUB_OFFLINE']=run_env['TRANSFORMERS_OFFLINE']='1'
default=c.execute([str(image),'default',str(E4/'fixture-preparation/bf16-original')],run_env,attempt/'run-default')
e4=c.execute([str(image),'e4',str(E4/'fixture-preparation/ct-e4-aa')],run_env,attempt/'run-e4')
c.save(attempt/'summary.json',dict(status='ACTUAL_CPU_DEFAULT_AND_E4_MODEL_REGRESSION_PASS',link=linked,default=default,E4=e4,
    reused_app=c.pin(app),new_app_compiles=0,SDK_rebuilt=False,HTTP=0,GPU=False,
    scope='Current Q8-updated Arena and Graph append, unchanged cached actual Model/case. This checks plain/default and E4 shared paths; it is not a Q8 Model, new full Model build, quality or performance test.'))
