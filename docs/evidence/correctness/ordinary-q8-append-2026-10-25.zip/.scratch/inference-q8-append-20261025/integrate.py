from pathlib import Path
import hashlib,json,subprocess
work=Path(__file__).resolve().parent;root=work.parents[1]
data=json.loads((work/'source-pins.json').read_text(encoding='utf-8-sig'))
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip(),'Expected clean E4 commit before Q8 integration'
def check(path,entry):
    body=path.read_bytes();assert len(body)==entry['bytes'] and hashlib.sha256(body).hexdigest()==entry['sha256'],str(path)
for row in data['files']:
    check(root/row['path'],row['before']);check(work/row['after']['path'],row['after'])
for row in data['files']:
    (root/row['path']).write_bytes((work/row['after']['path']).read_bytes());check(root/row['path'],row['after'])
(work/'integrated.json').write_text(json.dumps(dict(status='EXACT_EIGHT_PATH_INTEGRATED_NOT_YET_COMPILED',base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),files=data['files']),indent=2)+'\n',encoding='utf-8')
print('integrated exact 8 paths')
