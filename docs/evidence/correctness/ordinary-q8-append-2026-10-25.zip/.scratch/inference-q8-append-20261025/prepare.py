from pathlib import Path
import json,hashlib,difflib
R=Path.cwd();D=R/'.scratch/inference-q8-append-20261025';S=D/'source';B=D/'before'
paths=['src/graph_batch/paged_append.cc','src/graph_batch/paged_append.h','src/graph_route_apple/native_paged_append_region.cc','src/graph_route_vulkan/native_paged_append.cc','src/compute_batch/paged_arena.cc','include/hyle/compute/paged_arena.h','include/hyle/graph/batch.h','tests/graph_batch/typed_capability_graph_test.cc']
for n in paths:
 p=B/n;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():p.write_bytes((R/n).read_bytes())
 p=S/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((B/n).read_bytes())
def rd(n):return (S/n).read_bytes().decode('utf-8')
def wr(n,t):(S/n).write_bytes(t.encode('utf-8'))
def rep(t,a,b):assert t.count(a)==1,(a,t.count(a));return t.replace(a,b)
n=paths[1];t=rd(n);e='\r\n' if '\r\n' in t else '\n'
t=rep(t,'namespace hyle::graph::batch::detail {','namespace hyle::graph::batch::detail {'+e+'// Exact original carrier -> logical token rows; no storage/content conversion.'+e+'HYLE_GRAPH_BATCH_API Result<std::uint32_t> append_query_rows('+e+'    const PagedAppend&, const compute::TensorDesc&) noexcept;');wr(n,t)
n=paths[0];t=rd(n);e='\r\n' if '\r\n' in t else '\n'
t=rep(t,'  if(!storage.format().is_plain() ||'+e+'      (storage.data_type()!=c::DataType::kFloat16 && storage.data_type()!=c::DataType::kBFloat16 &&'+e+'       storage.data_type()!=c::DataType::kFloat8E4M3FN))', '  if(storage!=c::CacheStorage::q8_0().value() && (!storage.format().is_plain() ||'+e+'      (storage.data_type()!=c::DataType::kFloat16 && storage.data_type()!=c::DataType::kBFloat16 &&'+e+'       storage.data_type()!=c::DataType::kFloat8E4M3FN)))')
t=t.replace('paged append copies plain F16/BF16/E4 rows','paged append copies exact F16/BF16/E4 or Q8_0 rows')
a='Status PagedAppend::infer_output_descriptions(std::span<const c::TensorDesc>inputs,std::span<c::TensorDesc>outputs)const noexcept{'+e+'  if(inputs.size()!=1 || !inputs[0].valid() || inputs[0].rank()!=3 || !outputs.empty())'+e+'    return Status::InvalidArgument("paged append needs packed new rows and no tensor output");'+e+'  HYLE_ASSIGN_OR_RETURN(auto expected,row_description(*this,inputs[0].dimensions()[0]));'+e+'  if(inputs[0]!=expected)return Status::InvalidArgument("paged append needs exact packed new rows");'+e+'  return Status::Ok();'+e+'}'
b='''Result<std::uint32_t> detail::append_query_rows(const PagedAppend&op,const c::TensorDesc&carrier)noexcept{
  if(!op.schema.valid() || !carrier.valid())
    return std::unexpected(Status::InvalidArgument("paged append needs its schema and exact row carrier"));
  const auto cap=op.schema.capacity();
  const bool q8=row_storage(op)==c::CacheStorage::q8_0().value();
  if(carrier.rank()!=(q8?2u:3u) || (q8 && (!cap.kv_heads || carrier.dimensions()[0]%cap.kv_heads)))
    return std::unexpected(Status::InvalidArgument("paged append carrier does not contain whole logical head rows"));
  const auto rows=q8?carrier.dimensions()[0]/cap.kv_heads:carrier.dimensions()[0];
  HYLE_ASSIGN_OR_RETURN(auto expected,row_description(op,rows));
  if(carrier!=expected)
    return std::unexpected(Status::InvalidArgument("paged append needs exact original cache carrier rows"));
  return static_cast<std::uint32_t>(rows);
}
Status PagedAppend::infer_output_descriptions(std::span<const c::TensorDesc>inputs,std::span<c::TensorDesc>outputs)const noexcept{
  if(inputs.size()!=1 || !outputs.empty())
    return Status::InvalidArgument("paged append needs packed new rows and no tensor output");
  HYLE_ASSIGN_OR_RETURN(auto rows,detail::append_query_rows(*this,inputs[0]));(void)rows;
  return Status::Ok();
}'''.replace('\n',e)
t=rep(t,a,b)
t=rep(t,'  PagedAppend descriptor;c::TensorDesc rows;mem::MemoryResourceRef resource;NodeId node;','  PagedAppend descriptor;c::TensorDesc rows;mem::MemoryResourceRef resource;NodeId node;'+e+'  std::uint32_t query_rows=0;')
t=rep(t,'  const auto validation=append->infer_output_descriptions(std::span(&*rows,1),{});if(!validation.ok())return c::ProviderPrepareOutcome::error(validation);','  auto query_rows=append_query_rows(*append,*rows);if(!query_rows)return c::ProviderPrepareOutcome::error(query_rows.error());')
t=rep(t,'  p->descriptor=*append;p->rows=*rows;p->resource=adapter.resource;p->node=r.nodes[0];','  p->descriptor=*append;p->rows=*rows;p->resource=adapter.resource;p->node=r.nodes[0];p->query_rows=*query_rows;')
t=rep(t,'const auto cap=append->schema.capacity();const auto q=std::uint32_t(rows->dimensions()[0]);','const auto cap=append->schema.capacity();const auto q=p->query_rows;')
t=rep(t,'  HYLE_ASSIGN_OR_RETURN(auto facts,region.table->inspect(region.prepared,region.invocation));','  HYLE_ASSIGN_OR_RETURN(auto facts,region.table->inspect(region.prepared,region.invocation));'+e+'  HYLE_ASSIGN_OR_RETURN(auto query_rows,append_query_rows(facts.descriptor,facts.rows));')
t=t.replace('p->layout.facts().query_rows!=facts.rows.dimensions()[0]','p->layout.facts().query_rows!=query_rows')
assert t.count('p.layout.facts().query_rows!=f.prepared->rows.dimensions()[0]')==2
t=t.replace('p.layout.facts().query_rows!=f.prepared->rows.dimensions()[0]','p.layout.facts().query_rows!=f.prepared->query_rows')
wr(n,t)
n=paths[2];t=rd(n);e='\r\n' if '\r\n' in t else '\n'
t=rep(t,'#include "../graph_batch/native_append_regions.h"','#include "../graph_batch/native_append_regions.h"'+e+'#include "../graph_batch/paged_append.h"')
t=rep(t,'  std::uint32_t range_capacity = 0;','  std::uint32_t range_capacity = 0, query_rows = 0;')
t=rep(t,'configuration.layout.facts().query_rows != artifact.rows.dimensions()[0]','configuration.layout.facts().query_rows != artifact.query_rows')
t=rep(t,'    const auto query = static_cast<std::size_t>(artifact->rows.dimensions()[0]);','    HYLE_ASSIGN_OR_RETURN(artifact->query_rows, bd::append_query_rows(artifact->descriptor, artifact->rows));'+e+'    const auto query = static_cast<std::size_t>(artifact->query_rows);');wr(n,t)
n=paths[3];t=rd(n);e='\r\n' if '\r\n' in t else '\n'
t=rep(t,'#include "../graph_batch/native_append_regions.h"','#include "../graph_batch/native_append_regions.h"'+e+'#include "../graph_batch/paged_append.h"')
t=rep(t,'  if (type != compute::DataType::kFloat16 && type != compute::DataType::kBFloat16 &&'+e+'      type != compute::DataType::kFloat8E4M3FN)', '  const auto capacity = append->schema.capacity();'+e+'  const auto storage = append->role == compute::BatchCacheRole::kValue ? capacity.value_storage : capacity.key_storage;'+e+'  const bool q8 = storage == compute::CacheStorage::q8_0().value();'+e+'  if (!q8 && type != compute::DataType::kFloat16 && type != compute::DataType::kBFloat16 &&'+e+'      type != compute::DataType::kFloat8E4M3FN)')
t=t.replace('Vulkan append requires plain F16/BF16/E4 rows','Vulkan append requires exact F16/BF16/E4 or Q8_0 rows');wr(n,t)
n=paths[4];t=rd(n);e='\r\n' if '\r\n' in t else '\n'
t=t.replace('appendable pages require plain F16/BF16/E4 attention storage','appendable pages require supported whole attention rows')
t=rep(t,'  if(!storage.format().is_plain() ||'+e+'      (type!=DataType::kFloat16 && type!=DataType::kBFloat16 && type!=DataType::kFloat8E4M3FN) || arena_->page_bytes%page_rows)', '  const bool q8=storage==CacheStorage::q8_0().value();'+e+'  if((!q8 && (!storage.format().is_plain() ||'+e+'      (type!=DataType::kFloat16 && type!=DataType::kBFloat16 && type!=DataType::kFloat8E4M3FN))) || arena_->page_bytes%page_rows ||'+e+'      (q8 && (arena_->page_bytes/page_rows)%storage.format().bytes_per_block()))')
t=t.replace('appendable pages require whole plain F16/BF16/E4 rows','appendable pages require whole F16/BF16/E4 or Q8_0 rows');wr(n,t)
n=paths[5];t=rd(n);t=rep(t,'Opt-in plain F16/BF16/E4 attention storage publication. Bounds use the','Opt-in F16/BF16/E4 or whole-block Q8_0 attention publication. Bounds use the');wr(n,t)
n=paths[6];t=rd(n);e='\r\n' if '\r\n' in t else '\n';t=rep(t,'// R is inferred from the concrete input of each selected exact Graph child.','// R is inferred from the exact cache carrier and schema of each selected child.'+e+'// Q8_0 uses U8[R*kv_heads, block_row_bytes], not one carrier row per token.');wr(n,t)
# Test source will be added independently below; no implementation compiled here.
(D/'product-paths.json').write_text(json.dumps(paths,indent=2)+'\n',encoding='utf-8')
print('private production source prepared',len(paths)-1)
