from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
OUT = WORK / 'cpu1'
E4 = ROOT / '.scratch/inference-e4-append-implementation-20261025/clean-final'
OLD_CACHE = ROOT / '.scratch/inference-cache-shared-source-20261025'
spec = importlib.util.spec_from_file_location('finite_helpers', E4.parent / 'check_finite.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
read, save, pin, execute = helper.read, helper.save, helper.pin, helper.execute

def include_path(arg):
    for prefix in ('/external:i', '-external:i', '/i', '-i'):
        if arg.lower().startswith(prefix):
            return arg[:len(prefix)], Path(arg[len(prefix):])
    return None

def canonical(path):
    for old in (E4 / 'source', OLD_CACHE / 'source'):
        try:
            return ROOT / path.resolve().relative_to(old)
        except ValueError:
            pass
    return path

def project(path):
    try:
        parts = path.resolve().relative_to(ROOT).parts
        return bool(parts) and parts[0] in {'include', 'src', 'tests', 'engine'}
    except ValueError:
        return False

def main():
    assert not OUT.exists(), 'Do not overwrite a recorded attempt'
    source_pins = read(WORK / 'source-pins.json')
    for entry in source_pins['files']:
        assert pin(ROOT / entry['path'])['sha256'] == entry['after']['sha256'], entry['path']
    jobs = [
        ('cpu-arena', 'src/compute_batch/paged_arena.cc', OLD_CACHE / 'attempt1/arena/command.json'),
        ('cpu-append', 'src/graph_batch/paged_append.cc', E4 / 'compile/cpu-append/command.json'),
        ('cpu-test', 'tests/graph_batch/typed_capability_graph_test.cc', E4 / 'compile/cpu-test/command.json'),
        ('vk-append', 'src/graph_route_vulkan/native_paged_append.cc', E4 / 'compile/vk-append/command.json')]
    recipes = {name: read(recipe)['command'] for name, _, recipe in jobs}
    search = [ROOT / 'include', ROOT, ROOT / 'src/compute', ROOT / 'src/graph_batch']
    for args in recipes.values():
        for arg in args:
            parsed = include_path(arg)
            if parsed:
                search.append(canonical(parsed[1]))
    tree = OUT / 'source'
    pending = [entry['path'] for entry in source_pins['files']]
    seen = set()
    frozen = []
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        original = ROOT / name
        data = original.read_bytes()
        target = tree / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        frozen.append({'relative': name, 'canonical': pin(original), 'frozen': pin(target)})
        for inc in re.findall(r'^\s*#\s*include\s*["<]([^">]+)[">]', data.decode('utf-8-sig'), re.M):
            for directory in [original.parent, *search]:
                candidate = (directory / inc).resolve()
                if candidate.is_file():
                    if project(candidate):
                        pending.append(candidate.relative_to(ROOT).as_posix())
                    break
    save(OUT / 'frozen-project.json', frozen)
    save(OUT / 'source-pins.json', source_pins)
    compiler = recipes['cpu-test'][0]
    env = helper.discover_environment(compiler='msvc', cache={
        'CMAKE_C_COMPILER': compiler, 'CMAKE_CXX_COMPILER': compiler,
        'CMAKE_GENERATOR': 'Ninja'}, backends=()).env

    def frozen_directory(path):
        path = canonical(path)
        if path.resolve() == ROOT.resolve():
            return tree
        return tree / path.resolve().relative_to(ROOT) if project(path) else path

    def compile_one(job):
        name, source, recipe = job
        flags, skip = [], False
        for arg in recipes[name][1:]:
            if skip:
                skip = False
                continue
            if arg.lower() == '/sourcedependencies':
                skip = True
                continue
            if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')):
                continue
            parsed = include_path(arg)
            flags.append(parsed[0] + str(frozen_directory(parsed[1])) if parsed else arg)
        flags = ['/I' + str(tree / 'include'), '/I' + str(tree),
                 '/I' + str(tree / Path(source).parent), *flags]
        assert '/W4' in flags and '/WX' in flags
        assert not any(arg.startswith('/i') and not arg.startswith('/interface') for arg in flags)
        directory = OUT / 'compile' / name
        command = [compiler, *flags, str(tree / source), '/sourceDependencies',
                   str(directory / 'dependencies.json'), '/Fo' + str(directory / 'unit.obj'),
                   '/Fd' + str(directory / 'unit.pdb')]
        result = execute(command, env, directory)
        item = {'tag': name, 'source': source, 'result': result, 'recipe': pin(recipe)}
        if result['exit']:
            return item
        data = read(directory / 'dependencies.json')['Data']
        dependencies = [Path(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
        assert not any(project(path) for path in dependencies), 'Unfrozen canonical project dependency'
        save(directory / 'actual-dependencies.json', [pin(p) for p in dependencies])
        item.update(object=pin(directory / 'unit.obj'), dependencies=len(dependencies))
        return item

    print('FROZEN', len(frozen), 'files; strict 3 CPU + 1 Vulkan host TUs', flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        compiled = list(pool.map(compile_one, jobs))
    save(OUT / 'compiled.json', compiled)
    if any(item['result']['exit'] for item in compiled):
        save(OUT / 'summary.json', {'status': 'COMPILE_FAILED_NO_TEST', 'compiled': compiled})
        return 1
    objects = {item['tag']: item['object']['path'] for item in compiled}
    link = read(E4 / 'link/command.json')['command']
    replace = {
        str(OLD_CACHE / 'attempt1/arena/unit.obj'): objects['cpu-arena'],
        str(E4 / 'compile/cpu-append/unit.obj'): objects['cpu-append'],
        str(E4 / 'compile/cpu-test/unit.obj'): objects['cpu-test']}
    assert all(link.count(old) == 1 for old in replace)
    args = [replace.get(arg, arg) for arg in link
            if not arg.lower().startswith(('/out:', '/pdb:', '/implib:', '/map:'))]
    files = [pin(Path(arg)) for arg in args[1:] if Path(arg).is_absolute()
             and Path(arg).suffix.lower() in {'.obj', '.lib'}]
    save(OUT / 'link-inputs.json', {'replacements': replace, 'absolute_files': files,
                                   'absolute_count': len(files), 'original': pin(E4 / 'link/command.json')})
    image = OUT / 'link/component.exe'
    linked = execute([*args, '/OUT:' + str(image), '/PDB:' + str(image.with_suffix('.pdb'))], env, image.parent)
    if linked['exit']:
        save(OUT / 'summary.json', {'status': 'LINK_FAILED_NO_TEST', 'compiled': compiled, 'link': linked})
        return 1
    native = ROOT / '.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
    assert pin(native)['sha256'] == '1066e80261cc58d1c0ea57e50475e2e38b7675b666eb2b639969e01e85916a46'
    os.link(native, image.parent / native.name)
    runtime = read(ROOT / '.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json')
    runenv = dict(env)
    runenv['PATH'] = str(image.parent) + ';' + runtime['PATH']
    runenv['HF_HUB_OFFLINE'] = runenv['TRANSFORMERS_OFFLINE'] = '1'
    save(OUT / 'runtime.json', {'PATH': runenv['PATH'], 'native': pin(native)})
    ran = execute([str(image), '--gtest_filter=TypedCapabilityGraph.*',
                   '--gtest_output=xml:' + str(OUT / 'test-result.xml')], runenv, OUT / 'run')
    result_xml = ET.parse(OUT / 'test-result.xml').getroot()
    facts = {key: int(result_xml.attrib.get(key, '0')) for key in ('tests', 'failures', 'errors')}
    facts['skipped'] = sum(int(s.attrib.get('skipped', '0')) for s in result_xml.findall('testsuite'))
    passed = ran['exit'] == 0 and facts == {'tests': 7, 'failures': 0, 'errors': 0, 'skipped': 0}
    for entry in source_pins['files']:
        assert pin(ROOT / entry['path'])['sha256'] == entry['after']['sha256']
    summary = {'status': 'PASS' if passed else 'CPU_TEST_FAILED', 'compiled': compiled,
               'link': linked, 'run': ran, 'xml': facts, 'image': pin(image),
               'native': pin(native), 'source_pins': source_pins,
               'replaced_CPU_objects': 3, 'cpu_processes': 1,
               'Vulkan': 'host strict object only; not linked/executed',
               'CUDA': False, 'Apple': False, 'SDK_rebuilt': False, 'HTTP': 0}
    save(OUT / 'summary.json', summary)
    print(json.dumps({'status': summary['status'], 'xml': facts, 'seconds': ran['seconds']}), flush=True)
    return int(not passed)

if __name__ == '__main__':
    sys.exit(main())
