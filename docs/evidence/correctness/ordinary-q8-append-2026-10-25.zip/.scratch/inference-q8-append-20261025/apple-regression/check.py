import hashlib
import json
import pathlib
import re
import shlex
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = pathlib.Path('/Users/kiro/hyle/.scratch/inference-q8-append-20261025')
E4 = pathlib.Path('/Users/kiro/hyle/.scratch/inference-e4-appendable-20261025')
OLD = pathlib.Path('/Users/kiro/hyle/.scratch/inference-layout-storage-20261025')
BRIDGE = pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-graph-bridge-20261024/attempt1')

def pin(p):
    p = pathlib.Path(p)
    return {'path': str(p), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n')

def run(args, directory):
    directory.mkdir(parents=True, exist_ok=False)
    save(directory / 'command.json', {'command': args, 'cwd': str(ROOT), 'timeout_seconds': 120})
    start = time.perf_counter()
    with (directory / 'stdout.log').open('wb') as out, (directory / 'stderr.log').open('wb') as err:
        try:
            p = subprocess.run(args, cwd=ROOT, stdout=out, stderr=err, timeout=120)
            result = {'exit': p.returncode, 'seconds': time.perf_counter() - start}
        except subprocess.TimeoutExpired:
            result = {'exit': None, 'timeout': True, 'seconds': time.perf_counter() - start}
    save(directory / 'process.json', result)
    print(str(directory.relative_to(ROOT)), json.dumps(result), flush=True)
    if result['exit'] != 0:
        save(ROOT / 'summary.json', {'status': 'FAILED', 'stage': str(directory), 'result': result})
        sys.exit(1)
    return result

source_pins = json.loads((ROOT / 'source-pins.json').read_text())
for entry in source_pins:
    actual = pin(ROOT / 'source' / entry['path'])
    assert (actual['bytes'], actual['sha256']) == (entry['bytes'], entry['sha256'])
required = json.loads((ROOT / 'retained-required-pins.json').read_text())
for entry in required:
    assert pin(entry['path']) == entry

def tokens(text):
    return re.findall(r'\w+|[^\s]', re.sub(r'//[^\n]*|/\*.*?\*/', '', text, flags=re.S))

headers = []
for rel, base in [('include/hyle/compute/paged_arena.h', E4 / 'source'),
                  ('include/hyle/graph/batch.h', OLD / 'source')]:
    before, after = base / rel, ROOT / 'source' / rel
    assert tokens(before.read_text()) == tokens(after.read_text()), rel
    headers.append({'path': rel, 'old': pin(before), 'new': pin(after), 'cpp_tokens_equal': True})
save(ROOT / 'consumer-abi-review.json', {'consumer_recompiled': False, 'headers': headers,
                                      'consumer': required[0]})
recipes = json.loads((ROOT / 'recipes.json').read_text())
jobs = [('arena', 'src/compute_batch/paged_arena.cc'),
        ('append', 'src/graph_batch/paged_append.cc'),
        ('native-append', 'src/graph_route_apple/native_paged_append_region.cc')]
compiled = []
deps = {}
for name, relative in jobs:
    directory = ROOT / 'compile' / ('native-append2' if name == 'native-append' else name)
    args = recipes[name][:]
    args[1:1] = ['-I' + str(ROOT / 'source/include'), '-I' + str(ROOT / 'source'),
                 '-I' + str(E4 / 'source/include'), '-I' + str(E4 / 'source'),
                 '-I' + str(OLD / 'source/src/graph_batch')]
    args[args.index('-MF') + 1] = str(directory / 'unit.d')
    args[args.index('-c') + 1] = str(ROOT / 'source' / relative)
    args[args.index('-o') + 1] = str(directory / 'unit.o')
    if name == 'native-append':
        args.insert(args.index('-c'), '-I' + str(BRIDGE / 'source/src/graph_route_apple'))
        result = run(args, directory)
    else:
        result = json.loads((directory / 'process.json').read_text())
    compiled.append({'tag': name, 'source': relative, 'result': result, 'object': pin(directory / 'unit.o')})
    words = shlex.split((directory / 'unit.d').read_text().replace('\\\n', ' ').split(':', 1)[1])
    actual = []
    for word in words:
        if any(word.startswith(str(base / 'source')) for base in (ROOT, E4, OLD, BRIDGE)):
            item = pin(word)
            deps[word] = item
            actual.append(item)
    save(directory / 'actual-dependencies.json', actual)
save(ROOT / 'compiled.json', compiled)
save(ROOT / 'actual-source-dependencies.json', list(deps.values()))
obj = {entry['tag']: entry['object']['path'] for entry in compiled}
old_link = json.loads((ROOT / 'old-link.json').read_text())['command']
replace = {str(E4 / 'compile/arena/unit.o'): obj['arena'],
           str(E4 / 'compile/append/unit.o'): obj['append']}
assert all(old_link.count(p) == 1 for p in replace)
args = [replace.get(arg, arg) for arg in old_link]
args.insert(1, obj['native-append'])
args[args.index('-o') + 1] = str(ROOT / 'e4-regression')
args = ['-Wl,-map,' + str(ROOT / 'e4-regression.map') if arg.startswith('-Wl,-map,') else arg for arg in args]
inputs = [pin(arg) for arg in args if pathlib.Path(arg).is_file()
          and pathlib.Path(arg).suffix in ('.o', '.a', '.dylib')]
save(ROOT / 'link-inputs.json', {'replacement': replace, 'added_object': obj['native-append'],
                               'inputs': inputs, 'consumer_recompiled': False})
linked = run(args, ROOT / 'link')
ran = run([str(ROOT / 'e4-regression'),
           '--gtest_filter=AppleE4Appendable.EncodesAppendsAndKeepsBoundedOldReader',
           '--gtest_output=xml:' + str(ROOT / 'run/results.xml')], ROOT / 'run')
xml = ET.parse(ROOT / 'run/results.xml').getroot()
facts = {k: int(xml.attrib.get(k, '0')) for k in ('tests', 'failures', 'errors')}
facts['skipped'] = sum(int(s.attrib.get('skipped', '0')) for s in xml.findall('testsuite'))
assert facts == {'tests': 1, 'failures': 0, 'errors': 0, 'skipped': 0}
properties = {e.attrib['name']: e.attrib['value'] for e in xml.findall('.//property')}
save(ROOT / 'summary.json', {
    'status': 'PASS_APPLE_NATIVE_E4_REGRESSION_AFTER_Q8_SOURCE_CHANGES',
    'compiled': compiled, 'link': linked, 'run': ran, 'xml': facts, 'properties': properties,
    'source_pins': source_pins, 'source_logical_bytes': sum(p['bytes'] for p in source_pins),
    'actual_project_dependency_count': len(deps), 'link_input_count': len(inputs),
    'image': pin(ROOT / 'e4-regression'), 'consumer_recompiled': False,
    'retained_required_objects': required,
    'cached_helper_header': pin(BRIDGE / 'source/src/graph_route_apple/native_paged_append_region.h'),
    'first_failure': 'compile/native-append lacked unchanged private header in old partial source; corrected by original archive source include, no extra TU or SDK/source sync',
    'scope': 'Three product TUs only. Original cached E4 native case once, no Q8 native numerical execution claim.',
    'limits': ['No SDK/provider/vendor rebuild, Model, new consumer, download or backend matrix.',
               'Q8 branches are compile/link-covered; only original E4 journey is executed.',
               'Public header differences are comments only; original consumer object is hash-identical.']})
