# 模型、量化 profile 与算子子图

本表是模型与计算能力的地图：模型／量化制品→权重角色与推理主链→基础算子和常见融合→实际后端实现。
正向用于找缺算子、缺融合和漏接线，反向用于判断哪些实现仍有消费者。融合本身也需要精确的格式、数值和资源合同；
图上的 region、批量 capture 和物理 kernel 融合分别记录，不把几种实现形状当成同一种能力。

这是当前模型与量化版本到权重角色、计算子图、Hyle custom descriptor 的现行人读入口。模型范围由[需求目录 D](tasks/compute/llm-moe-provider-demand-matrix.json) 的 `/current_scope` 定义：六个既有模型，加 DeepSeek V4 Pro-0813、Flash-0731 两个正式版，共 **8 个模型**；下表的 **24 个 profile 是本轮已锁基线，不是量化支持范围上限**。旧 `deepseek_v4_pro`、`deepseek_v4_flash` preview 及其量化衍生制品不再属于当前范围；正式版属于单独锁定的身份，不自动扩大到 V4.1。

目标模型的 Unsloth 量化制品及 Hugging Face 上的主流量化制品也属于后续覆盖范围，不能用“每模型三个profile”排除其他实际发布的格式。新增制品按 D 的 `/current_scope/quantization_scope` 核定真实仓库、固定revision、对应GA base model、逐角色格式与数值合同后扩充本表；尚未核实的格式不写成某个模型已经发布或Hyle已经支持。

来源索引：D 的 `/profile_catalog` 与 `/current_scope/added_releases` 保存身份，`/demand_units` 保存 15 个区域；[需求明细 C](tasks/compute/llm-moe-coverage-matrix.json) 的 `/requirements` 保存 64 条历史需求；[原生映射 P](tasks/compute/llm-moe-provider-map.json) 的 `/requirements` 回指 C 的具体 domain。下面保留这些来源的反向关系，不继承旧状态、通过结论或 Provider 支持声明。

工作顺序是维护总表、核实并移除仅属旧 preview 的非通用实现、再逐量化精度检查融合与接入切割。**历史 64 行不是完整 GA 清单，也不是 24 个 profile 的逐角色量化与融合审查完成清单。** 这里的“保留”只表示当前需求或独立能力仍在、暂不删除；不表示现有 descriptor 已数值等价或已经支持 GA。

## 模型与量化身份

`official`、`primary`、`fidelity` 分别对应目录键 `official`、`primary_gguf`、`fidelity_gguf`。身份 pointer 均相对 D；variant 链接指向已锁 revision 的 Hugging Face 制品目录。GA GGUF 的发布者与 `base_model` 已核对，主文件逐 tensor header 尚未核定，因此精确混合 codec 继续留空，不由 variant 名推断。

| 模型 | Profile | 具体 variant（HF） | 记录的 formats / 未核项 | 身份 pointer（D） |
| --- | --- | --- | --- | --- |
| Qwen3.5-2B | official | [official-bf16](https://huggingface.co/Qwen/Qwen3.5-2B/tree/15852e8c16360a2fea060d615a32b45270f8a8fc) | BF16；F32 recurrent | `/profile_catalog/0/official` |
| Qwen3.5-2B | primary | [UD-Q4_K_XL](https://huggingface.co/unsloth/Qwen3.5-2B-GGUF/tree/f6d5376be1edb4d416d56da11e5397a961aca8ae) | Q4_K；Q5_K；Q6_K；Q8_0；IQ4_XS；F16；F32 | `/profile_catalog/0/primary_gguf` |
| Qwen3.5-2B | fidelity | [UD-Q8_K_XL](https://huggingface.co/unsloth/Qwen3.5-2B-GGUF/tree/f6d5376be1edb4d416d56da11e5397a961aca8ae) | Q8_0；F16；F32 | `/profile_catalog/0/fidelity_gguf` |
| Qwen3.8-27B | official | [official-bf16](https://huggingface.co/Qwen/Qwen3.8-27B/tree/1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0) | BF16；F32 recurrent | `/profile_catalog/1/official` |
| Qwen3.8-27B | primary | [UD-Q4_K_M](https://huggingface.co/unsloth/Qwen3.8-27B-GGUF/tree/4ca720788d1e01f1bff70c033e0d0028fd02e502) | Q3_K；Q4_K；Q5_K；Q6_K；Q8_0；IQ3；IQ4；BF16；F32 | `/profile_catalog/1/primary_gguf` |
| Qwen3.8-27B | fidelity | [UD-Q8_K_XL](https://huggingface.co/unsloth/Qwen3.8-27B-GGUF/tree/4ca720788d1e01f1bff70c033e0d0028fd02e502) | Q8_0；BF16；F32 | `/profile_catalog/1/fidelity_gguf` |
| Qwen3.8-2.4T-A95B | official | [official-bf16](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B/tree/207bd685a7e3696cfaff12ded7c6a7ea0f88c996) | BF16；F32 recurrent/router | `/profile_catalog/2/official` |
| Qwen3.8-2.4T-A95B | primary | [UD-IQ4_XS](https://huggingface.co/unsloth/Qwen3.8-2.4T-A95B-GGUF/tree/567d3e6ac26c5474b18311e619c04350fb9a5556) | IQ4_XS；Q4_K；Q5_K；Q6_K；F32 | `/profile_catalog/2/primary_gguf` |
| Qwen3.8-2.4T-A95B | fidelity | [Q8_0](https://huggingface.co/unsloth/Qwen3.8-2.4T-A95B-GGUF/tree/567d3e6ac26c5474b18311e619c04350fb9a5556) | Q8_0；F32 | `/profile_catalog/2/fidelity_gguf` |
| Kimi-K3 | official | [official-mxfp4](https://huggingface.co/moonshotai/Kimi-K3/tree/f831ab66814297da540d832a5235f8e904f29d06) | MXFP4 packed expert；UE8M0 scale；BF16；F32 | `/profile_catalog/3/official` |
| Kimi-K3 | primary | [UD-Q4_K_XL](https://huggingface.co/unsloth/Kimi-K3-GGUF/tree/a0836360ce58dfec088d966a97f2ddc8a606279b) | MXFP4；Q8_0；F32 | `/profile_catalog/3/primary_gguf` |
| Kimi-K3 | fidelity | [UD-Q8_K_XL](https://huggingface.co/unsloth/Kimi-K3-GGUF/tree/a0836360ce58dfec088d966a97f2ddc8a606279b) | MXFP4；BF16；F32 | `/profile_catalog/3/fidelity_gguf` |
| GLM-5.3 | official | [official-fp8](https://huggingface.co/zai-org/GLM-5.3/tree/aca966e4e02791568aa6a4ced368624b3d897f42) | FP8 E4M3 block128；BF16；F32 | `/profile_catalog/6/official` |
| GLM-5.3 | primary | [UD-Q4_K_XL](https://huggingface.co/unsloth/GLM-5.3-GGUF/tree/346b3591c7f28d1a23716f97a065ecf12ec14771) | Q4_K；Q5_K；Q6_K；Q8_0；F32 | `/profile_catalog/6/primary_gguf` |
| GLM-5.3 | fidelity | [Q8_0](https://huggingface.co/unsloth/GLM-5.3-GGUF/tree/346b3591c7f28d1a23716f97a065ecf12ec14771) | Q8_0；F32 | `/profile_catalog/6/fidelity_gguf` |
| GLM-5.3-Flash | official | [official-fp8](https://huggingface.co/zai-org/GLM-5.3-Flash/tree/eb9eb208eb0d988989d07a6a12d0fdeb5f52574a) | FP8 E4M3 block128；BF16；F32 | `/profile_catalog/7/official` |
| GLM-5.3-Flash | primary | [UD-Q4_K_XL](https://huggingface.co/unsloth/GLM-5.3-Flash-GGUF/tree/621d456e93e926e4b52f85cff5f634358c1828f9) | Q4_K；Q5_K；Q6_K；Q8_0；F32 | `/profile_catalog/7/primary_gguf` |
| GLM-5.3-Flash | fidelity | [Q8_0](https://huggingface.co/unsloth/GLM-5.3-Flash-GGUF/tree/621d456e93e926e4b52f85cff5f634358c1828f9) | Q8_0；F32 | `/profile_catalog/7/fidelity_gguf` |
| DeepSeek-V4-Pro-0813 | official | [official-fp4-fp8-dspark](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/tree/72e1d3230f6c080a530b0a1d46f8eb4602340597) | packed FP4 expert；FP8 E4M3；UE8M0 scale；BF16；F32；I64 | `/current_scope/added_releases/0/official` |
| DeepSeek-V4-Pro-0813 | primary | [UD-Q4_K_XL](https://huggingface.co/unsloth/DeepSeek-V4-Pro-0813-GGUF/tree/6d053616d152293da72569f56b861466f10ace7d) | 主 GGUF 逐角色 codec / DSpark 打包待核 | `/current_scope/added_releases/0/primary_gguf` |
| DeepSeek-V4-Pro-0813 | fidelity | [UD-Q8_K_XL](https://huggingface.co/unsloth/DeepSeek-V4-Pro-0813-GGUF/tree/6d053616d152293da72569f56b861466f10ace7d) | 主 GGUF 逐角色 codec / DSpark 打包待核 | `/current_scope/added_releases/0/fidelity_gguf` |
| DeepSeek-V4-Flash-0731 | official | [official-fp4-fp8-dspark](https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731/tree/7872f01b1d1fe23eabc4c98b48bffcef5a386062) | packed FP4 expert；FP8 E4M3；UE8M0 scale；BF16；F32；I64 | `/current_scope/added_releases/1/official` |
| DeepSeek-V4-Flash-0731 | primary | [UD-Q4_K_XL](https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF/tree/fbbb5b93fb787c21338159b0af3318bb3f4d9768) | 主 GGUF 逐角色 codec / DSpark 打包待核 | `/current_scope/added_releases/1/primary_gguf` |
| DeepSeek-V4-Flash-0731 | fidelity | [UD-Q8_K_XL](https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF/tree/fbbb5b93fb787c21338159b0af3318bb3f4d9768) | 主 GGUF 逐角色 codec / DSpark 打包待核 | `/current_scope/added_releases/1/fidelity_gguf` |

Variant 名称不表示所有权重采用同一精度。例如 Kimi 的 `UD-Q4_K_XL` 目录仍记录 MXFP4/Q8_0/F32；`IQ3`、`IQ4` 仍是宽泛名称，不能补写成已确定 codec。Qwen3.5-2B 两个 GGUF profile 明确排除 R13（MTP）。官方、GGUF、历史人工量化样例不能互相替代。

Pro GA GGUF 固定为 [Unsloth Pro-0813][pro-gguf] `6d053616d152293da72569f56b861466f10ace7d`，两种 variant 各20分片；Flash GA GGUF 固定为 [Unsloth Flash-0731][flash-gguf] `fbbb5b93fb787c21338159b0af3318bb3f4d9768`，各5分片。[Flash GGUF DSpark 说明][flash-dspark]将其列为独立 optional add-on；不能把主 profile 自动解释成启用 DSpark，也不额外增加上述24个主 profile。发布者关于 MXFP4 passthrough、Q8_0/BF16 转换的声明仍须与实际选定文件的 tensor header 对照。

## 正式版 DeepSeek：角色、存储与数值边界

[Pro-0813][pro-card] 与 [Flash-0731][flash-card]均明确替代 preview 并附带 DSpark。官方固定 revision 分别为 `72e1d3230f6c080a530b0a1d46f8eb4602340597`、`7872f01b1d1fe23eabc4c98b48bffcef5a386062`。两份 config 的 `quant_method=fp8` 与仓库 FP8 标签都**不表示全 FP8**：`expert_dtype=fp4` 仍在。

下表的存储与计算分开记录：checkpoint 身份、转换后载体、参考实现 parameter dtype 不是同一件事。FP4/FP8 kernel 的 F32 累加由固定源码声明；`F.linear` / `einsum` 的物理执行算法与设备精度仍由具体后端核定。来源为两份固定 [Pro config][pro-config] / [Flash config][flash-config]、[Pro inference][pro-source] / [Flash inference][flash-source]及相同 revision 的 `inference/kernel.py`、`inference/convert.py`。

| 权重角色 / 子图 | Pro-0813 / Flash-0731 形状与模型参数 | 存储 / 转换 | Activation → accumulate → output；待核边界 |
| --- | --- | --- | --- |
| Embedding / LM head | vocab129280；hidden7168 / 4096 | checkpoint BF16；LM head 在参考程序持有 F32 parameter | embedding Gather→BF16；head 以 F32 operands 计算→F32 logits；完整词表不得用缩小 head 代替 |
| Q low-rank、Q/KV、输出 `wo_b`、shared expert 线性 | Q rank1536 / 1024；attention heads128 / 64，D512；输出 groups16 / 8、rank1024；FFN intermediate3072 / 2048 | 默认 E4M3FN `[N,K]`，128×128 UE8M0 scales；BF16/F32 例外逐角色处理 | BF16→动态 E4M3 group128；absmax floor1e-4、向上 power2 scale；FP8 GEMM F32累加→BF16 |
| `wo_a` 输出中间投影 | Pro / Flash 按各自 groups 与 output rank | checkpoint FP8 block128；官方 convert 解码并改为 BF16；参考层明确 BF16 | BF16 grouped `einsum("bsgd,grd->bsgr",...)`→BF16；不得把冷转换遗漏后直接套默认 FP8，也不把其物理累加算法写成已验证 |
| Routed expert gate/up/down | E384 / 256，Top6；`w1/w3: N3072,K7168 / N2048,K4096`，`w2` 方向相反 | packed E2M1 FP4 `[N,K/2]`，I8 容器；UE8M0 scales `[N,K/32]` | BF16→动态 FP8 group128→F32 kernel累加→BF16；gate/up转F32并按10裁剪、SiLU乘法，route weight 在 down 前施加；不能换成 Kimi 的 group32 activation 合同 |
| Router / hash table | E384 / 256、Top6、scale2.5 / 1.5；首3层 hash | BF16 router weight转F32计算；F32 selection bias；checkpoint API 有 I64，参考 `tid2eid` 为 I32 | F32 logits→sqrt(softplus)；普通层按带 bias 分数选 ID、无 bias 分数归一化；hash 按 token table 原序选 ID；GA `Gate.forward` 的归一化没有 `+1e-20` |
| mHC / norms / attention sink | HC4、Sinkhorn20、eps1e-6；每层 attention/FFN 与输出 head 分开 | HC fn/base/scale、norm weights、sink 为 F32 parameter；不能把整个 checkpoint 标成 F32 | F32 norm/projection/coefficients→HC pre/post；残差与返回的 BF16 边界必须保留；GLM Flash 仍共享 HC 数学需求 |
| CSA/HCA compressor 与缓存 | SWA128；ratio4（重叠）/128；Pro主干31×128+30×4，Flash主干20×128+21×4+2×0；两者另有3个 ratio0 DSpark stages | F32 compressor 计算/增量 KV 与 score state，随后 norm/转换；checkpoint各角色 dtype 与参考F32 parameter需区别 | BF16 hidden→F32 gated pooling/state→BF16；普通 NoPE KV 有 FP8/group64 simulation；ratio4 index compressor另走 Hadamard/FP4-QAT；GLM K4 pooling 不等同此合同 |
| Index projection / score / TopK | H64/D128；Pro Top1024，Flash Top512；causal 压缩候选 | `wq_b` 默认FP8；`weights_proj` BF16；参考 index cache 是 BF16 QAT 值 | RoPE→Hadamard→FP4/group32 QAT；BF16 dot/ReLU/weighted product/head sum边界后选TopK；Hyle物理68B行与paged metadata是接入载体，不是官方checkpoint格式 |
| DSpark `mtp.*` 新角色 | 3 stages；block_size5；Pro target layers58/59/60、Markov rank512；Flash40/41/42、rank256；noise token128799 | stage0 `main_proj/main_norm`；末stage Markov embedding/head、confidence projection与HC head；各角色按正式源 dtype核对 | target hidden拼接/投影→draft block/Markov logits→confidence；另核draft/verify、接受前缀、KV/state生命周期，不能承接旧单层MTP结论 |

Pro 的 `inference/kernel.py` 与旧 `b596…` 字节相同；两份 GA 的 Linear、Gate、Expert、MoE、Indexer、Compressor 主体及 HC pre/post 与各自 preview 保持相同计算。这证明需求仍在，不证明 Hyle 原有实现与 GA 精确等价。两份顶层 config 仍写 `num_nextn_predict_layers=1`，但固定 `inference/config.json` 写 `n_mtp_layers=3`，源码构造三个 `DSparkBlock`；总表保留这项来源差异，不能只取旧字段作结论。固定源码、元数据与差异对照见[本轮来源包](../evidence/research/deepseek-v4-ga-2026-10-19.zip)，其中没有权重payload。

普通/hash sqrt-softplus 路由现已按 GA 直接除以分数和，移除 carrier 的 epsilon/零和回退并更新 OpID；CUDA Direct/Graph 的极小分数、零和、表序、bounds、独立槽及OOM回归通过，旧内核对照能检出偏差。这不代表完整 GA 模型已执行，也不代表其它后端已有这两个 custom 入口。
`LightningIndexer` 的旧 F32 接口仍不等价于 GA 三处 BF16 舍入；公共 MatMul／Relu／Mul／Reduce 已能表达这套数学。
CUDA 现已为这段公共图接入 dense BF16 scorer，直接消费 K/W 的实际 View，支持 batch 前缀间距、可选 F16 mask 先窄为 BF16、BF16/F32 输出及空结果。
11 项 CUDA 回归通过，含独立舍入见证、双槽、旧结果、8 次强制 capture 与原 packed/paged 路径；小 trace 确认每 key tile 实际执行 Lt＋Relu/Mul/Reduce/publish 五颗 kernel。
见[源码、失败与验证记录](../evidence/correctness/ga-dense-indexer-cuda-2026-10-20.json)。这只补该 CUDA 复合承载；四后端 FP4 RowCache bank 仍与正式 BF16 cache 分开，完整 GA 模型及其它平台的新承载仍待完成。

## 扩展量化制品

[量化制品明细](model-quantizations.json)另保存首批33条来源记录，覆盖八个目标模型，包含固定revision、
base-model声明、codec/packing/activation域、配置证据和未知项。除原UD-Q4/UD-Q8外，已发现AWQ产生的
compressed-tensors INT4、GPTQ、FP8、NVFP4/MXFP4、BNB NF4和MLX混合位宽等实际制品。
其中部分配置尚未完整读取，源模型commit通常也未由发布者锁定；这些是需求发现，不是后端支持结论，
也未穷尽HF的主流制品。Unsloth目录已发现的其他GGUF变体同样保留为需求，不把文件名当逐tensor格式。
[原始metadata与配置](../evidence/research/model-quantization-discovery-2026-10-19.zip)不含权重payload。

33条现均已补入 `provider_coverage` 的首轮静态合同核对。记录分别指出条件可达入口、
缺失格式和仍需逐tensor核实的部分，均为 `artifact_execution_verified=false`：CT INT4已补四后端普通图packed线性路径，
GPTQ-v1也已接原四端口decode及有界packed候选；小型算子回归不代表制品导入或整模型执行。
CT grouped另以相同原flat bank、精确reshape和GroupedMatMul接通四后端selected packed路径；
group32/128/512的[数值与资源寿命回归](../evidence/correctness/ct-packed-grouped-space-2026-10-21.json)保留实际scale与W舍入，
分立expert到working-set的资源桥及publisher绑定仍未完成。
ModelOpt 存储 scale 的静态 FP8 也已接四后端普通图参考及有界冷候选，独立 SA/SW 不套动态 block128；
所选 mixed 制品的 payload、其它角色与整体执行仍未验。
MLX 的 affine4/5/6/8 基础入口已接通；六份制品的完整header集合现已核对，实际资源导入、producer舍入和完整执行仍须分别验证；
channel/token FP8 与 ModelOpt 静态 NVFP4 不能套现有 block128 动态合同；前者的固定CT BF16 QDQ参考
已接通四后端普通Graph；Apple/Vulkan本轮补普通Bool转换／选择及所需FP8存储桥，
[20项定向及邻居回归](../evidence/correctness/ct-channel-token-cross-backend-2026-10-20.json)通过，仍未验证整制品或部署端原生FP8点积。
[CPU](../evidence/correctness/mlx-affine-widths-cpu-2026-10-19.zip)、
[CUDA](../evidence/correctness/mlx-affine-widths-cuda-2026-10-19.zip)及
[Apple](../evidence/correctness/mlx-affine-widths-apple-2026-10-19.zip)另记录本轮算子回归。
这些记录没有完成各制品的完整资源导入、prefill/decode 物理融合或整模型运行；33条仍不是完整量化范围。
[来源与源码审查](../evidence/research/model-provider-coverage-2026-10-19.zip)保留配置缺失、root/text_config优先级、
精确packing和舍入未知项，不能把已审过的未知项当作已支持。

[2026-10-21固定来源复核](../evidence/research/fixed-role-binding-2026-10-21.json)更新其中16条：
MLX六制品164个header完整对齐；Kimi INT4实际为BF16 scale，FP8-BLOCK的已读角色是E4＋BF16 block128，
嵌套旧MXFP4配置不能覆盖物理dtype。ModelOpt Kimi注意力存F32四维block128 scale，不能套标量静态SA/SW；
DeepSeek派生27实际存F32 block128 scale，25/26部分attention/shared才是真E8M0。
K512发布源码还确认另一条BF16 W4A8数学，已补四后端，见下表。Inferact样本则是U8 W＋F32 micro32 scale，
其activation／码序／macro规则尚缺producer依据，继续独立记录，不能按MXFP4名称套Quark。
CT BF16 block128普通图、grouped power2 A规则、普通分页E4 KV及E8M0 macroblock128冷导入已四端闭环，见下表；uniform compact MLA E4也已四端接通；具体制品的精确producer／scalar绑定仍分开记录。

[compact MLA来源复核](../evidence/research/compact-mla-e4-contract-2026-10-21.json)分开记录producer QDQ与运行时缓存：
固定ModelOpt recipe只量化展开后的K/V，不能推出CKV/KPE物理格式。独立runtime源码及GLM Flash发布卡的TRTLLM选项
确认uniform E4 CKV512／CKV512+KPE64的需求，同一latent缓存共享一个scale；另一动态per128 scale＋BF16 KPE的
DSA布局为528／656字节，另行承载。Hyle uniform compact E4已接四后端原paged/ragged路径，见下表；不由此签收另一DSA格式或精确producer。

## 模型到计算与融合子图

公共项包括布局/物化/转换、embedding/head、norm/逐点/残差、线性/FFN与状态资源复用（D：R01–R03、R15）；量化另查 R14。R 编号只是区域索引，不表示所有 dtype、role 或 fusion 已接入。

| 模型 | 主要计算与待核融合子图 | D / C 索引 |
| --- | --- | --- |
| Qwen3.5-2B / Qwen3.8-27B | Q/K/V→norm/RoPE→GQA→output gate→projection；causal conv→gate/decay→GDN→state；dense FFN；按profile核MTP | R04/R05/R13；F03.4、F04.3/4、F07–F10、F14.3 |
| Qwen3.8-2.4T-A95B | 上述attention/GDN；router→TopK→dispatch→grouped/shared experts→combine；MTP | R04/R05/R10/R11/R13；F07–F10、F12.1/2、F13.1/2、F14.3 |
| Kimi-K3 | KDA三路conv→gate/decay→recurrent；MLA；latent expert→SiTU/再量化→combine；AttnRes | R06/R07/R10–R12/R14；F09、F11–F13、F14.2、F15、F18.3 |
| GLM-5.3 | MLA/YaRN；index projection→score/TopK→sparse gather/attention；跨层选择复用；MoE；MTP index carry | R07–R11/R13/R14；F08.2、F12/13、F14.5、F15、F16.1/2、F18.1/5 |
| GLM-5.3-Flash | KDA/MLA；pooled index+未池化tail；跨层选择复用；MoE；mHC；MTP | R06–R14相应分支；F11–F16、F18.1/5 |
| Pro-0813 / Flash-0731 GA | MLA/CSA/HCA；H64 index；hash / sqrt-softplus router；mHC；FP4 expert+FP8 activation；DSpark | 对照R07–R14、旧F08/F12–F18；DSpark另列新合同 |

## 当前融合与量化接线缺口

以下是2026-10-19首批审查及后续修复，主看Qwen3.5/3.8 dense与MoE FFN，依据现有制品配置、Hyle admission/lowering和[锁定依赖](../../cmake/HyleDependencyLock.json)中的原生实现；未穷尽模型、格式、阶段或设备。表内区分已运行的修复与源码发现；制品发布、普通算子接通和物理融合分别核定。普通 `Unary SiLU→Multiply` 与 `GatedActivation` 是不同数值合同，不能互换来制造融合命中。

| 模型 / 格式域 | 已核源码事实 | 最小下一步 |
| --- | --- | --- |
| Qwen dense；F32/F16/BF16普通SiLU | [真实FFN](../../tools/qwen35_text/main.cc#L181)发普通SiLU再乘法。F32/BF16已有稳定SiLU→Mul，保留[stable-tail、`-Inf→+0`](../../third_party/sglang_activation/activation.cuh#L96)与SiLU输出RNE。CUDA BF16 单向量现另接 gate/up＋SiLU×Mul，直接读两份权重，保留 G/U/A/Y 四处RNE；真实Qwen decode每步24处物理命中 | F16、prefill/其他shape及其他精度的完整投影融合仍未接；F32点积归约树可不同于cuBLASLt，整模型差异与吞吐须单独判断 |
| GDN z门控；BF16来源／F32 SiLU与乘法／BF16结果 | CUDA已接闭合Cast→稳定SiLU→Mul→Cast的typed输入／存储，保F32两处舍入和末BF16 RNE；外部精确metadata View及两Mul顺序可用。13项相关回归及完整64向量通过，当前Qwen每步18处物理命中、少36个转换核；[实际证据](../evidence/performance/typed-gating-suffix-2026-10-20.json) | 中间值逃逸保原分解；内部插入View、非连续／广播及其它dtype保持原路径。未融合前置投影，不代签其它平台、模型或长期吞吐 |
| GDN单快照状态输出 | CUDA对闭合packed→score/state CONT段复用原GDN数学kernel，直接写独立状态输出；真实CONT可发布／多读，保原score拷贝、F32状态与BF16边界。13项CUDA及完整64向量通过；实际每步少18次、合计18MiB D2D，kernel仍596。[源码与实测](../evidence/performance/gdn-direct-state-output-2026-10-20.json) | 仅K=1且当前地址／owner／不重叠检查通过；私有中间值额外读者、其它snapshot或布局保原路径。packed分配保留，未证明吞吐或峰值改善 |
| 同A小行BF16双投影；Qwen GDN a/b等 | CUDA已接两个普通MatMul的多输出冷候选，直接读原BF16权重、各自F32累加与末BF16 RNE，两个结果均可发布／多读；完整FFN优先。5项新CUDA与7项邻居、8项共同CPU回归、完整64向量通过，实际Qwen每步18处命中、614→596核。[源码与实测](../evidence/performance/paired-small-projections-2026-10-20.json) | 目前M1/evenK、转置dense W、等N，cached NVIDIA/MMVF几何且N不超过SM数；其它shape/精度保原叶。两窗波动大，未证明稳定decode提速；不把局部热cache微基准推广成整模型收益 |
| Qwen dense；F16/BF16投影→GatedActivation | 原生gate/up向量融合要求F32 activation/output；Hyle [MatMul输出转换](../../src/compute_provider_ggml_cuda/tensor_program.cc#L239)及[BF16 gate输入扩宽](../../src/compute_provider_ggml_cuda/tensor_program.cc#L659)保留公开舍入边界 | 需要显式保留gate/up舍入的融合变体；普通SiLU recipe还须保留SiLU舍入。不能只删Cast或放宽matcher |
| Q24 plain/BF16与GGUF K/IQ/Q8/MXFP4专家 | [GroupedMatMul](../../include/hyle/compute/model_ops.h)使用 W `[E,N,K]`、F32 A `[T,A,K]`、IDs `[T,S]`→F32 `[T,S,N]`，A=1或S，共享可用真实零slot步幅View；重复ID保留各slot。NVIDIA plain及严格BF16W/F32A小T直接读GPU IDs，按实际元素宽度、pair步幅、grid及原F32计算偏好执行；BF16位扩宽后保F32累加，不留整bank F32副本。奇K／大T保F32 A，BF16仅临时转换单专家N×K。[16项CUDA回归与常量对照](../evidence/performance/bf16-grouped-bank-2026-10-20.json)通过，充分冷准备的原实现未被证明更慢，已确认空间节省；原F32-ID及Q8/MXFP4数学保持 | 大T及其他不合资格域仍有O(T×S×K+T×S×N)排序临时量、IDs读回／同步和原生池空间；严格mixed indexed GLU尚未融合。四后端共享布局／寿命见[原记录](../evidence/correctness/grouped-shared-activation-2026-10-20.json)；K/IQ、其他shape/平台、gate/up舍入与失败slot仍逐域核定，不据此签收整模型MoE或整体零复制 |
| Qwen官方block128 FP8；另有CT channel/token FP8 | [Float8BlockLinear](../../src/compute_provider_cuda/fp8_provider.cc)保精确E4M3/F32 block128合同；CUDA Graph已接同一激活、相同floor/scale rounding的两线性共享量化，保原两个GEMM及各自输出舍入。[16项相关回归与4→3核trace](../evidence/performance/fp8-shared-prologue-2026-10-20.json)通过，含F32、BF16、BF16 power2、捕获、双槽和旧结果，未执行所选FP8整制品 | CT固定BF16逐token QDQ／逐channel权重舍入已沿四后端普通图执行，[20项数值／寿命及邻居回归](../evidence/correctness/ct-channel-token-cross-backend-2026-10-20.json)通过，含三浮点型Bool与Select位保持；不承接Quark其它axis/F32 scale或block128数学。部署端原生FP8点积、更多分支与完整FFN另核；共享量化不等于两个GEMM物理融合，不据此推导当前BF16 Qwen提速或整个图的峰值工作区减半 |
| Grouped FP8 power2 A；E4／F32 macroblock128 W | `grouped_float8_linear(kPowerOfTwo,1e-4F)`沿四端原执行体系保BF16输入、F32 absmax／乘倒数／ceil及原FP8点积；共享A一次量化，CUDA原BF16 colmajor AOT的scale直接用实际列步幅，无额外transpose。[9项新检查及10项邻居](../evidence/correctness/grouped-fp8-power2-reference-2026-10-21.json)通过，含双槽、旧结果、重复／非法IDs和None邻居 | 只签有界BF16参考；CUDA F32 power在prepare拒绝，未签整制品、Linux、质量或吞吐。E8M0 macroblock128冷导入另见下一行；专家工作集仍待。Vulkan另修旧None scale常数除法的RN，未改power／normalize |
| E8M0 macroblock128权重冷导入；DeepSeek GA混合制品的attention/shared角色 | `import_float8_block128_weight(E4[N,K],U8[ceil(N/128),K/128],canonical)`沿compute runtime检查host映射、容量和别名，保原E4字节，仅扩宽scale表。4项host单测覆盖全部256码、stride／尾界、写前拒绝及映射错误；四后端各1项原dense power2 Graph检查通过，含CUDA捕获、双槽和旧结果。[实测](../evidence/correctness/e8m0-block128-import-reference-2026-10-21.json)共8项、无跳过 | host导入不暗中上传／发布，不做激活量化或整W浮点展开；SF0=`2^-127`，255保原NaN位。GPU见证仅有限普通scale，不代签特殊码执行、精确制品绑定、分立专家工作集、Linux、质量或吞吐；group32另合同 |
| 普通分页E4 KV；独立固定K/V scale | 原CacheEncode与CPU boxed／Vulkan FullF32／Apple Steel页读取器直接承载E4，并与既有CUDA核对；不展开整套浮点KV。[16项新检查及6项邻居](../evidence/correctness/paged-e4-kv-reference-2026-10-21.json)通过，含精确编码字节、GQA、引用页／尾界、双槽旧结果和Q1 warm/fresh增长 | 只签BF16 D64→128等本批有界数学／寿命；未签E4成对pending生产者链、compact MLA／具体制品scale绑定、Linux、质量或吞吐。CUDA归约的scale位置保留，不承诺任意scale跨端逐bit相同 |
| compact MLA E4；共享CKV512／KPE64与V前缀 | `MlaBatchCapacity`分开Q／输出类型和一个共享`CacheStorage`，沿四端原paged/ragged读者补uniform E4；V同根前512项，不展开V或整缓存。CUDA保Q64调度、E4 KV16与F32 scale后BF16 RNE；Apple保F32计算并缩小Q共享存储。[18项新增与10项邻居](../evidence/correctness/compact-mla-e4-reference-2026-10-21.json)通过，含KPE错省略见证、warm/fresh与真实旧结果 | BF16 Q／输出有界参考；CUDA KV增长沿原cold replan，native delegated ragged无page-report不签无重规划。未签mixed DSA656／528、具体制品payload、Linux、质量、吞吐或新capture；独立Q／输出schema也不代表所有执行组合 |
| CT BF16 block128 W／动态group128 A | 普通Gather／View／Reduce／Binary／Cast／Select／MatMul保留原BF16 scale与逐节点舍入；共享A只QDQ每token一次，先选原E4专家W／BF16 SF再解码。[18项新检查及18项邻居](../evidence/correctness/ct-bf16-block128-reference-2026-10-21.json)分窗口通过，含四端双槽、旧结果、非法IDs恢复、tiny；CUDA原捕获与SiLU融合均保留 | 有限源激活、N/K整128、有界E3参考；未签payload／整模型、Linux、质量或吞吐。Vulkan一般非affine batch用原DAG冷拆MatMul再concat结果，仍有Y复制；CT M1保native广播。分立expert工作集桥仍归交付3，不套F32-scale code-dot |
| FP8存储转换；F32/F16/BF16与E4M3FN/E5M2 | CUDA Native已统一五种浮点Cast并删旧managed分支；无Provider workspace/private result，支持dense、byte-stride、广播与外部capture。CPU BF16 NaN payload按SIMD对齐。[CPU14项与CUDA14项](../evidence/correctness/cuda-native-storage-cast-2026-10-20.json)通过；固定CT rank3 BF16 QDQ各双槽四次逐bit等于独立oracle，CUDA完整链RequireCapture | 8B元素只做descriptor冷准备；未签巨型payload、整制品、原生FP8 GEMM、质量或吞吐。CT逐channel BF16 scale不等于block128；[原生code-dot反例](../evidence/correctness/cuda-fp8-codedot-feasibility-2026-10-20.json)仍禁止把普通F32 MatMul静默替换成另一FP8点积 |
| ModelOpt 存储 scale 的静态 FP8 Linear | plain E4M3 `W[N,K]` 与独立 F32 标量 SA/SW；普通图保 `F32(A)*F32(1/SA)`→SATFINITE E4→F32 code-dot→先 SA 再 SW→末端 Cast。四后端已接精确闭合链的私有有界候选，直接读原 W、不留 NK F32 bank；公开中间值沿原分解。[数值／寿命与普通图红绿](../evidence/correctness/static-fp8-reference-2026-10-20.json) | 只签存储 scale 软件参考，不等同 fake-QDQ、动态 block128、CT token/channel 或原生 scaled_mm；固定 producer/header 研究不证明所选 mixed 制品 payload、KV/conv、整模型、质量或吞吐。保原默认偏好与设备范围 |
| 官方/CT grouped FP8；Q24 Top10及其他合法S | checked align/GEMM已按实际S承载，A=1共享或A=S独立行，不复制activation。两份F32/BF16 AOT在SM89的S3/6/10/16及Top8相邻回归通过，非法ID仍由Completion报告；[证据](../evidence/correctness/cuda-grouped-fp8-slots-2026-10-19.zip)。随后修复有限scale预乘使零权重产生NaN：dot先乘As、再乘Bs，两次F32 RNE后原顺序累加；实际PTX/SASS及[5项CUDA红绿／邻居回归](../evidence/correctness/grouped-fp8-scale-order-2026-10-20.json)通过，原dot、量化器、ABI/geometry和checked align保留。[锁定源码](../../third_party/sglang_activation/fp8/grouped/original_kernels.py#L327)虽有interleaved W13的`FUSE_SWIGLU`，当前两job仍关闭；各制品routed角色、packing及scale域尚须核定 | 核融合分支fast-math、BF16边界与GatedActivation合同，再接W13准备及region matcher；UE8M0与F32 scale等不同域不能混用，不以算子回归或F32累加命名签收普通F32点积等价、制品/整模型、质量、吞吐或其他平台 |
| Q35/Q27 AWQ命名制品、CT INT4 | [ArtifactWeightDecode](../../include/hyle/compute/model_ops.h#L229)提供NF4、legacy AWQ GEMM4与CT symmetric/asymmetric4冷decode。Q27 artifact9的399角色[header](../evidence/correctness/ct-asymmetric-int4-header-2026-10-20.zip)确认group32/BF16 scale/zero沿N。普通同图Decode[/Cast]→精确Transpose View→F32累加MatMul已接四后端packed候选，保三次舍入及逃逸原分解；[CPU三系统与CUDA](../evidence/correctness/ct-packed-cpu-portability-2026-10-20.json)、[Vulkan](../evidence/correctness/ct-packed-vulkan-2026-10-20.json)、[Apple](../evidence/correctness/ct-packed-apple-2026-10-20.json)各有实际算子／寿命回归。CT grouped另沿精确Reshape→GroupedMatMul直接读选中原Q/Z/SF，[四后端软件参考](../evidence/correctness/ct-packed-grouped-space-2026-10-21.json)覆盖group32/128/512及F32 scale，无ENK浮点bank | dense默认性能另核：CPU单向量、Vulkan已测单行BF16优先packed；Apple保原。grouped按空间合同优先、CPU普通默认已验，不据此声称吞吐提升。原flat EN行的zero布局不等于分立expert各自padding，working-set桥仍待；未验publisher binding／整模型、峰值或tensorcore／完整FFN融合。AWQ命名不能选择legacy packing；独立decode再绑dense constant不能恢复codec身份 |
| Q35/Q27 AutoRound GPTQ-v1 INT4 | `ArtifactWeightDecode{kGptqV1Int4}`接原I32 Q/Z、F16 scale、I32 g_idx；零nibble加一且15→16、F16乘法后转decode／operand，g_idx选组而非重排K。四后端原decode与普通闭合packed候选均已接通，其中packed候选直接读压缩bank、不留额外dense W；全部ID先验证再寻址。[48项数值／寿命及邻居回归](../evidence/correctness/gptq-reference-2026-10-20.json)均通过，无跳过，含CUDA实际捕获；同包保固定producer、Q35完整150组与Q27第二分片73组header | Q27 index共400组，其余分片dtype／值、两个制品payload／整模型与MTP均未执行。新候选不代表默认更快、硬件INT4 GEMM、FFN／专家融合或其它GPTQ变体；独立发布decode仍物化dense W。Kimi名称含GPTQ但实际CT packing不归此合同 |
| GGUF NVFP4；Q27 混合制品 | 独立64值/36字节身份沿原MatMul/GroupedMatMul/Gather接CPU/CUDA/Vulkan/Apple；Apple保F32激活与累加，含共享激活、重复expert IDs及普通Graph的[数值／寿命验证](../evidence/correctness/apple-gguf-nvfp4-2026-10-20.json)。所选Q27固定header的866张量含374 NVFP4、122 Q5_K、9 Q6_K、1 Q8_0和360 F32，embedding为Q6_K、head为Q8_0；[原记录](../evidence/correctness/gguf-nvfp4-2026-10-20.json)保留header及CUDA MMQ修复 | 未读取所选制品权重payload、未运行27B/MTP整模型，也未验证该制品的融合、质量、吞吐或峰值内存；HF W4A4是另一合同 |
| HF MXFP4/NVFP4 | ModelOpt group16原packed W、E4M3 scale和两个F32 global接`Nvfp4Linear`软件参考；四后端直接读压缩bank，保非fast scale先乘和BF16操作数边界。[dense实测](../evidence/correctness/nvfp4-cross-backend-reference-2026-10-20.json)含N16/K2048、非零subnormal及失败后重建Invocation。`GroupedNvfp4Linear`另接末端IDs与每专家WG/IG，按选中专家分别QDQ，支持共享／独立／零slot步幅A、重复IDs，不展开整E×N×K bank；[CPU与三GPU的数值／寿命回归](../evidence/correctness/grouped-nvfp4-reference-2026-10-20.json)通过。QDQ本体分别为2×M×K／2×T×S×K字节，运行时及状态成本另计 | 未运行所选制品payload／整模型或Linux该入口；Q24专家0–7的[锁定header与最小合同](../evidence/research/nvfp4-grouped-expert-contract-2026-10-20.json)仅证明角色形状，未读取数值。硬件native W4A4、Marlin A16、其他producer和CT local-dynamic不能据此签等价，质量／吞吐未验。原[header/生产者研究](../evidence/research/nvfp4-channel-global-contract-2026-10-20.json)保留 |
| CT local-dynamic NVFP4；Q27/Q24 | 独立`LocalNvfp4Linear`／`GroupedLocalNvfp4Linear`复用group16几何，保原WG／IG直接除法及local零规则；`Fp4InputRounding`明确FP4阈值前F32／BF16边界，不套ModelOpt数学。CPU/CUDA caller激活工作区为2×R×K字节（R=M或T×S），Apple/Vulkan复用原native program并另计检查／状态成本，直接读压缩W。[27项回归](../evidence/correctness/ct-local-nvfp4-reference-2026-10-20.json)全部通过、0跳过：Windows CPU8／CUDA6／Vulkan6，macOS M4 Apple7 | [固定header与producer研究](../evidence/research/ct-local-nvfp4-contract-2026-10-20.json)核artifact8前56层的168个NVFP4 MLP角色，末8层MLP为FP8；artifact18所存首分片含1593组完整NVFP4角色，其中layer0为512专家加shared的1539组、layer1另54组。均为header范围，未读权重数值；512份分立专家tensor的完整工作集接线、任意大bank／整制品、Linux、硬件FP4等价、质量与吞吐均未签 |
| Quark MXFP4 W4A4；Q24／Kimi K3／GLM Flash | `Mxfp4Linear`／`GroupedMxfp4Linear`真3／4端口已接四后端软件参考，直接读原U8 `W[N,K/2]` 与E8M0 `SF[N,K/32]`；保BF16量化／重构边界、完整ID先验与selected SF校验。共享A1／零slot步幅只QDQ每token一次，CPU/CUDA本体工作区2TK，独立S为2TSK，不展开整专家浮点bank。[37项数值／寿命与旧FP4邻居回归](../evidence/correctness/quark-mxfp4-reference-2026-10-20.json)全部通过，无跳过 | [固定config、6个header与producer](../evidence/research/quark-mxfp4-contract-2026-10-20.json)仅核角色／来源；portable零／极值定义不冒充原HIP／Triton全域等价，SF0非零、SF255失败，合法有限算术溢出仍IEEE。Kimi独立896专家与外侧BF16投影分开，GLM混合MXFP4／FP8block／BF16；分立expert到有界working-set的资源桥、所选payload／整模型、Linux、原生硬件FP4、质量与吞吐仍未签 |
| Group512 INT4／INT8，逐组BF16累加；Kimi custom K512 | `BlockwiseW4A8Linear`／`GroupedBlockwiseW4A8Linear`沿四后端现执行体系读原I32低位先offset nibble和F32 scale；A每512元素按BF16 absmax×BF16(1/127)、BF16倒数／乘法后向零截断I8，I32点积及两次scale乘法分别转BF16，按K组顺序BF16累加。共享A只量化一次，不展开ENK浮点bank。[10项新路径与14项邻居](../evidence/correctness/blockwise-w4a8-reference-2026-10-21.json)分相关窗口通过，含CUDA真实capture、四布局、旧结果、tiny和失败重建 | 原source的NaN／越界float→I8没有可移植定义；本参考拒绝这些derived码，不造饱和或wrap。合法SF转BF16的0／Inf和后续IEEE结果保留。仅签有界软件数学／寿命，不签所选payload、整制品、Linux、硬件整数GEMM、质量或吞吐；分立专家working-set桥仍待。不能由CT packing相同套W4A16或GPTQ-v1 |
| MLX混合位宽；Qwen、GLM等 | `MlxQuantized{format,kind,bits,group_size}` 已接 affine4/5/6/8，连续 U32 行末轴 `(K/32)*bits`。Grouped支持 `A[T,1,K]`、`A[T,S,K]`及真实零slot步幅／token行距View，IDs决定 `[T,S,N]`并保重复槽，[四后端共享输入回归](../evidence/correctness/mlx-grouped-shared-activation-2026-10-20.json)通过。Vulkan mixed affine linear/grouped直接读取原F32/F16/BF16端口；CPU/CUDA/Vulkan的[完整普通MoE](../evidence/correctness/mlx-moe-typed-inputs-2026-10-20.json)已覆盖普通5/6/4bit组合。六制品的164个header现完整核对，GLM Flash全部37338份scale/bias为F16，4/5/6bit triple分别24822／12387／129 | 46个5bit配置override不等于46个tensor。37152个专家碎片需129组working-set绑定；GLM另有156个attention head-bank，真实forward几何须核，不能按rank3签专家路由。producer typed舍入、Apple完整mixed MoE及嵌套lazy View仍待；Vulkan合资格不可变bank已[跨槽复用](../evidence/correctness/vulkan-mlx-constant-bank-reuse-2026-10-20.json)。未验收整制品、质量、吞吐或峰值内存；MXFP8不能代替integer affine8 |

F32 activation/output配合已接plain/GGUF权重，已有原生gate/up→GLU向量融合候选；它不含down projection/residual，也不覆盖任意prefill GEMM。[现有GGUF fixture](../../tests/graph_route_cuda/d5_qwen35_gguf_fragment_test.cc#L158)发布gate/up等全部中间值，[lowering会保护这些输出](../../src/compute_provider_ggml_cuda/ggml_cuda_provider.cc#L544)，因此不能用该case证明中间值已消除。物理命中须另用同数学、仅发布所需末端结果的case核定，保留诊断case与真实输出合同。

九处原生MMVF/MMVQ现将潜在融合的真实读集交给冷分配，防止未融合时可回收的输入覆盖融合仍需读取的值；
执行图和最终地址保护保留。[定向记录](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md#融合读集进入冷分配)
已证明F32 raw普通完整GLU在dense/VIEW/NONE根的6组物理命中，以及公共Graph的内部输入、预算、双槽重绑；
这不补齐上表BF16舍入变体、grouped metadata拓扑或各种量化的实际接线，也未证明吞吐提升。

投影底座已补ggml CUDA rank2/batched矩阵末两轴transpose-dense RHS，并修正fast NVIDIA双BF16输入/F32累加被意外扩成整份F32输入的问题。能力准入与默认优先级分开：早先无条件扩大普通region造成49个投影改路由，因完整prefill退化而[撤回该默认选择](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md#投影接线与输入累加精度)；现在冷发现读取实际叶提案，普通region不吞已知更优叶，真实融合独立提案。rank2能力已开放，默认及GGML400/cuBLAS300同分反例均保留cuBLAS投影；定向回归通过。新增单向量BF16完整FFN是单独融合候选，不改变普通投影叶偏好，也不构成跨平台覆盖声明。

真实Qwen的prefill与decode均已物理命中24个BF16 FFN及18个F32 SSM SiLU→Mul融合。此前prefill的18个F32候选被内部逆reshape切断，现已通过共同lowering的相邻同值折叠恢复；64份向量与旧路径相同。kernel数从原prefill1932/decode1794降为1890/1752，仍不代表完整FFN或decode提速；[实测与未完成项](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md#相邻逆-reshape-与-prefill-融合)区分逻辑候选、物理覆盖与完整step吞吐。

原生CUDA的独立MMVF现可直接接BF16权重／activation／output，限定连续、无batch、偶数K、单向量、F32累加；
读取时精确扩宽，输出显式BF16 RNE，无整份输入转换。两种RHS布局、舍入中点、双槽换址及奇数K/F32原路径
回归通过。它尚无保留投影与SiLU逐节点舍入的完整gate/up epilogue；默认投影仍选cuBLAS。
三种真实尺寸的冷L2权重轮换配对筛选未显示足够的整体收益，不能用接通typed载体宣称模型提速；
[测量与边界](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md#bf16-向量投影的直接承载)单独记录。

CUDA 普通常量表达式现沿真实 immutable roots 在冷准备中执行原生数学，保留逐节点 dtype/RNE；
同一片段多输出共享准备，相同只读 Cast 共享存储。完整 Qwen 的61组 norm scale Cast/Add、18组 dt bias Cast
和18组 A_log Exp/Neg 已移出热执行，并恢复48处已有 RMSNorm×scale 融合；warm decode 实测1528 kernels/步。
随后 Graph 补全 metadata View 的真实常量根、物理绑定与偏移，CUDA 冷准备接通剩余18组 conv weight Cast；
warm decode 实测1528→1510 kernels/步，64份hidden/logits逐byte不变。本轮未另测吞吐，不能由kernel数推导提速。
随后CUDA复用原RMS归约，在读取/写回中合并BF16扩宽/舍入；允许由归约同步和线程归属证明安全的完全同址连续映射，
保持部分重叠、不同映射、scale别名及公开读者保护。完整模型48处weighted和18处unscaled norm真实命中，
warm每步1510→1414→1378 kernels，64份hidden/logits逐byte不变。配对计时尚未证明整体提速。
BF16 GDN L2随后已补square→sum→epsilon→Rsqrt→multiply的五处舍入，保留原SUM_ROWS树、严格sqrt与fast div；
36处真实命中，warm1378→1054 kernels，19项CUDA与64份Qwen向量通过。冷matrix复用另消除prefill首窗72次512KiB D2D复制。
随后Provider按实际边补充13条Cast→RMS→Cast短链，冷scale保持独立；61处weighted及18处unscaled norm均typed读写，
warm1054→1028 kernels。20项CUDA及64份Qwen向量通过，配对计时未观察到本批decode收益。
随后CUDA单向量BF16 FFN补齐完整gate/up＋普通SiLU×Mul，正确识别两投影之间实际的只读权重TRANSPOSE，
不剥离数学节点或改变usecount；24处物理命中使warm1028→980 kernels，28项相关CUDA通过。
T1 workspace每槽2,103,424→2,054,272B，未测总显存峰值。同轮完整decode只观察到79.05→79.92、参考91.51 tokens/s，
仍低12.66%，不把少48个kernel当作稳定提速；F32点积树变化后的独立模型质量仍需单独判断。
显式频率RoPE的CUDA承载随后将位置转换、广播、三角函数与旋转合为单kernel，保留原F32运算及最终类型舍入。
F16/BF16/F32定向GPU对照及原回归合计30项通过；完整BF16 Qwen的64份向量逐byte不变，warm980→812 kernels，
其中BF16/F32独立转换223→199。其他后端仍沿原分解；本批不改变HF与当前RoPE的舍入差异。
随后F32首标量Divide／Rsqrt用真实只读零步幅View承载，不物化重复numerator；L2按实际私有读者融合最终扩宽，
保留五处BF16舍入与原归约树。32项相关CUDA及64份模型向量通过，warm812→740 kernels、转换199→163、Repeat36→0；
同窗warm98.30→98.50 tokens/s，尚未证明稳定提速。其他shape/精度的完整投影融合及剩余转换仍未完成；
普通二元kernel的广播支持不能推导旧bias融合的布局资格。随后CUDA九处旧MMVF/MMVQ融合已共用实际
bias/gate/scale读取布局、elided来源及restrict别名资格，并把量化尾行界改为真实N；35项相关CUDA通过，
旧实现的3个反例均可复现，64份模型向量保持。随后F16融合显式传原MatMul精度，OAI alpha/limit完整传至
普通、量化和MoE融合；38项相关CUDA与64份模型向量通过，小trace三条OAI路线各命中4次。未重测本批吞吐。
随后 GDN V/beta 已接通 BF16 typed load，原 F32 数学、state 与舍入边界保持。Provider 冷规划同时修复
跨输入前沿的 Cast 分段和互相占用候选问题，保留已有 RMS 融合；完整 Qwen 的18层实际命中，warm740→704 kernels，
转换163→127（73次扩宽、54次窄化）。3项CUDA含10个内部case检查实际融合选择与数值，完整64份向量逐byte相同。
该GDN窗口warm100.03→101.46 tokens/s，参考106.23，仍低4.50%；小窗口、样本重叠，不作为稳定收益或其他模型覆盖证明。
随后 CUDA SSM conv 已接通私有 BF16 sample 的真实 time/channel/batch strides；公开 F32 Conv、F32权重/MAC/输出、
输出 BF16 RNE、普通稳定 SiLU 与 history Copy 保持。共同长核补末块加载界，冷支持拒绝未实现 K 和非法跨度/geometry。
6项 CUDA（含原GDN邻居）零skip、完整64份向量逐byte相同；真实18层 typed conv命中，warm704→668核，
转换127→109（55扩宽＋54窄化）、18次F32实体转置消失。本窗warm101.6379→100.4901 tokens/s，回退1.13%，
不将更少物化或更小workspace写成速度成功；[证据与计时边界](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md#conv-typed-load-与真实布局)。
随后私有Cast(F32→BF16)＋普通稳定SiLU已跨叶偏好接成原生单kernel，保两次BF16 RNE及未发布Cast的真实闭包；不修改原Conv数学或引擎。
5项CUDA（全BF16位型、F32 RNE边界、发布/读者/View/control保护与重绑）及完整64份向量通过；实际18处命中，668→650核、转换109→91。
同窗warm101.3918→101.5118、参考105.3241，差3.62%；完整decode反慢0.17%，不作稳定提速或其他模型覆盖证明。
[本轮实测](../evidence/performance/qwen35-full-cuda-2026-10-19/README.md#常量表达式冷准备与-rmsnorm-融合)不作为其他模型/量化/平台的覆盖证明。

## 64 条历史需求的反向索引

以下恰好逐行覆盖 C 的64个ID。`Q35/Q27/Q24/K/G/GF` 对应上文六模型；“六模型”即这六者。六模型列是 C 的 `models` 去重求交，保留其历史指向；它不是对当前所选每个量化profile的实际tensor存在声明。尤其旧 Q4-S128、Q4-A64、Q8-B32、人工FP8样例，不自动成为24个profile的格式身份。

GA列依据当前固定源码补反向需要；F14.4旧单层MTP与DSpark分开。精确分支不相同或来源尚不足时直接写待核，不由family范围推导独占或删除。ID链接中的 `/requirements/N` 是 C 的 JSON pointer，不引入旧 route status。

| C ID / pointer | 具体数值、形状或子图边界 | 六模型历史指向 | GA Pro / Flash 现行反向关系 |
| --- | --- | --- | --- |
| [F01.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/0) | View/stride/alias、边界与空tail | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F01.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/1) | Copy/Concat；显式连续物化 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F01.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/2) | Cast与索引转换；IEEE舍入边界 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F02.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/3) | Embedding/轴向Gather、重复及越界ID | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F02.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/4) | Scatter赋值/加法；重复目的地与F32端口 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F02.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/5) | causal/ragged/全mask；动态offset | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F02.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/6) | 计数、exclusive scan、稳定dispatch逆映射 | Q24、K、G、GF | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F03.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/7) | 逐点/残差/广播及strided tail | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F03.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/8) | 稳定exp/log/silu/softplus/sqrt/Clamp | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F03.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/9) | gate/up→SwiGLU→down；保留转换 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F03.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/10) | Qwen head-interleaved sigmoid output gate | Q35、Q27、Q24 | —；按六模型对应分支保留 |
| [F04.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/11) | RMSNorm末轴F32归约、eps/gamma | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F04.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/12) | LayerNorm mean/variance、gamma/beta | 六模型 | 未见GA独立LayerNorm需求；公共能力保留，不由历史全模型映射补算子 |
| [F04.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/13) | L2归一化epsilon在sqrt内 | Q35、Q27、Q24、K、GF | —；按六模型对应分支保留 |
| [F04.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/14) | norm→gamma/输出舍入→swish gate | Q35、Q27、Q24、K、GF | —；按六模型对应分支保留 |
| [F04.5](tasks/compute/llm-moe-coverage-matrix.json#/requirements/15) | Reduce/Softmax的F32归约与全mask | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F04.6](tasks/compute/llm-moe-coverage-matrix.json#/requirements/16) | TopK真实k/tie/NaN与ID顺序 | Q24、K、G、GF | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F05.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/17) | M=1/17/128、真实N/K、累加类型 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F05.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/18) | batched/broadcast QK/PV及leading strides | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F05.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/19) | checkpoint转置/slice、GEMV尾部 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F05.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/20) | gate/up→activation→down→residual、活中间值 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F06.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/21) | 历史本地132张量signed Q4/group128 | Q35（历史本地派生） | 不是GA官方格式；不得把历史派生样例冒作GA/GGUF |
| [F06.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/22) | unsigned affine Q4/group64、scale+bias | 六模型（历史载体，选定profile归属待核） | 不是GA官方格式；GA GGUF逐role codec待header核 |
| [F06.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/23) | 历史本地Q8/block32 W8A16，无A8替代 | Q35（历史本地派生） | 不是GA官方格式；GA GGUF逐role codec待header核 |
| [F07.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/24) | Qwen真实GQA/MQA ratio、head256 | Q35、Q27、Q24 | —；GA使用自身D512/MLA/CSA，不套Qwen head256合同 |
| [F07.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/25) | KV append/read、page ID、valid length | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F07.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/26) | 完整Qwen gated attention及旧state | Q35、Q27、Q24 | —；GA attention链另按sink/HC/compression核 |
| [F08.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/27) | Qwen partial/interleaved RoPE与非零offset | Q35、Q27、Q24 | —；GA RoPE/YaRN按F08.2与正式源 |
| [F08.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/28) | YaRN/NoPE、原context与参数 | G、GF | 需；GA YaRN/rope参数及NoPE转换按两份config |
| [F08.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/29) | normalized Hadamard、符号/layout及1/sqrt(D) | — | 需；GA index Hadamard仍在；通用Hadamard不删 |
| [F09.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/30) | causal depthwise conv K4、真实QKV宽 | Q35、Q27、Q24、K、GF | —；此行为Qwen/KDA卷积合同 |
| [F09.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/31) | causal conv update、非零history/reset | Q35、Q27、Q24、K、GF | —；此行为Qwen/KDA卷积合同 |
| [F10.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/32) | scalar-decay GDN chunk、真实K/V比与state | Q35、Q27、Q24、K、GF | —；K/GF在C的宽指向不表示其KDA等同scalar GDN |
| [F10.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/33) | scalar-decay GDN recurrent、state布局 | Q35、Q27、Q24、K、GF | —；K/GF的实际KDA另查F11 |
| [F11.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/34) | KDA逐channel decay/chunk、GLM下界-5 | K、GF | —；K/GF需求保留 |
| [F11.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/35) | KDA recurrent、tail/reset/双state | K、GF | —；K/GF需求保留 |
| [F12.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/36) | 按模型score函数；bias仅用于selection | Q24、K、G、GF | 需；E384/256、Top6、sqrtsoftplus、bias只选ID；保留router并核数值 |
| [F12.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/37) | 真实E/TopK/group、原分数归一化 | Q24、K、G、GF | 需；scale2.5/1.5；GA无epsilon的归一化/tie需精确对照 |
| [F12.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/38) | 早期hash层token table→原序expert IDs | — | 需；首3层hash；I64 checkpoint/I32参考表；不能以score TopK替代 |
| [F13.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/39) | dispatch稳定映射、空expert、grouped GEMM | Q24、K、G、GF | 需；E384/256与Top6；各expert dtype另核 |
| [F13.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/40) | 路由加权/共享expert、重复目的地累加 | Q24、K、G、GF | 需；GA route weight在down前；F32 sum→BF16边界单列 |
| [F13.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/41) | Kimi latent3584/expert3072、SiTU softcaps | K | —；不能把Kimi latent/SiTU当GA FFN |
| [F14.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/42) | mHC4、Sinkhorn20、F32系数及pre/post/head | GF | 需；GA HC4/Sinkhorn20，与GF共享数学但逐dtype核 |
| [F14.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/43) | Kimi block12 AttnRes、prior blockstate | K | —；Kimi AttnRes独立合同保留 |
| [F14.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/44) | Qwen MTP norm/concat/full attention | Q35、Q27、Q24 | —；Qwen MTP按各profile，不能转签DSpark |
| [F14.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/45) | 旧DeepSeek单nextn层e/h投影与HC head | — | 待DSpark对照：旧单层MTPBlock已替换；不继承旧合同，也非可删公共能力 |
| [F14.5](tasks/compute/llm-moe-coverage-matrix.json#/requirements/46) | GLM MTP BF16角色与跨层index carry | G、GF | —；GLM index carry不等同DSpark target hidden |
| [F15.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/47) | MLA low-rank/absorbed投影、NoPE/RoPE/V宽 | K、G、GF | 需；GA q-rank1536/1024、D512与output组投影，按各角色核 |
| [F15.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/48) | 模型各自gated MLA/NoPE分支 | K、G、GF | GA自身sink/HC边界另核；不继承Kimi gate或GLM NoPE分支 |
| [F16.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/49) | learned index score→TopK→sparse attention | G、GF | 需；GA H64/D128、Top1024/512、BF16逐步舍入；GLM是H32合同 |
| [F16.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/50) | GLM跨层index选择复用/versioned state | G、GF | —；DSpark取target hidden不能据此宣称同一index carry |
| [F16.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/51) | GLM Flash pool4、learned gate与unpooled tail | GF | —；GA ratio4 overlap不是GLM pooled/tail合同 |
| [F17.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/52) | CSA/HCA learned KV/gate、ratio4/128 | — | 需；GA learned compressor仍在，ratio4/128；GGUF角色另核 |
| [F17.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/53) | SWA128、ratio4 overlap及causal压缩位置 | — | 需；SWA128与重叠窗口/causal位置保留 |
| [F17.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/54) | compression增量state、ratio±1边界/reset | — | 需；prefill/chunk/decode state与边界；不以旧回执签GA |
| [F18.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/55) | E4M3FN weight128x128/A128、F32 scales | Q35、G、GF | GA官方是UE8M0分支，非本行F32-scale身份；GLM及旧派生另核 |
| [F18.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/56) | FP8 UE8M0 power2、group/饱和/舍入 | — | 需；GA dense/shared FP8与UE8M0，不表示全FP8模型 |
| [F18.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/57) | Kimi W4A8：weight32/A32 UE8M0、SiTU再量化 | K | —；Kimi A32数值域保留，不以GA A128替代 |
| [F18.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/58) | DeepSeek E2M1 weight32、dynamic FP8 A128 | — | 需；两GA官方仍FP4/A128；GroupedFP4保留，GGUF不能按名称套格式 |
| [F18.5](tasks/compute/llm-moe-coverage-matrix.json#/requirements/59) | 按源区分KV/index codec、FP4 QAT与score | G、GF | 需；GA FP4-QAT index仍在；物理68B Hyle载体/GLM codec分开 |
| [F19.1](tasks/compute/llm-moe-coverage-matrix.json#/requirements/60) | 冷shape/参数绑定、动态position/valid length | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F19.2](tasks/compute/llm-moe-coverage-matrix.json#/requirements/61) | state端口/读写范围、独立slot与旧结果 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F19.3](tasks/compute/llm-moe-coverage-matrix.json#/requirements/62) | immutable weights、packing/cache/workspace复用 | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |
| [F19.4](tasks/compute/llm-moe-coverage-matrix.json#/requirements/63) | Direct/Graph交付、OOM/accepted-failure/close | 六模型 | 需；正式版公共子图，实际role/dtype与逐profile接线另核 |

DSpark 新合同不塞入旧64行：三个stage的main-hidden抽取/concat、draft attention与Markov/confidence角色、proposal/verify/accepted-prefix状态及可选GGUF sidecar需要另补精确行；顶层nextn字段与实际inference构造差异也保留。64行中标“需”只是现行需求存在，不是完整精度覆盖、实际kernel融合或端到端收益声明。

## 25 个 custom descriptor 与实际反向关系

下表逐项对应当前 [model_ops.h](../../include/hyle/compute/model_ops.h) 的25个描述符。源码链接定位入口；fixture链接说明已有消费者，GA源码链接说明计算需求。旧fixture仍使用旧profile身份时只作为recipe证据，必须迁移身份/逐角色合同后才可能提供GA执行证据。公共能力和固定模型组合分别判断，不能因为测试是消费者就永久保留一个废弃专用组合，也不能因移除preview就删除GA仍需的数学。

| Descriptor / 源码入口 | 现行需求、已有消费者或接线证据 | 保留边界 / 尚待核实 |
| --- | --- | --- |
| [`GatherElements`](../../include/hyle/compute/model_ops.h#L19) | [generic MoE routing](../../tests/compute_models/d5_moe_execution_fragments.h)：Q24/K/G/GF；GA selection也需逐元素Gather | 通用axis/bounds能力保留，实际GA ID与stride合同另核 |
| [`RowCacheEncode`](../../include/hyle/compute/model_ops.h#L64) | [row-cache状态消费者](../../tests/compute_state/row_cache_consumer.cc)与typed batch缓存；GA量化index有逻辑需求 | 通用row-inline codec保留；不能将Hyle物理行格式称官方checkpoint |
| [`RowCacheGatherDecode`](../../include/hyle/compute/model_ops.h#L94) | [row-cache Graph fixture](../../tests/compute_models/row_cache_graph_fixture.h)与状态消费者 | 通用typed gather/decode保留；选定profile的codec另绑 |
| [`RowCacheGatherDecodePadded`](../../include/hyle/compute/model_ops.h#L134) | [typed paged reader](../../include/hyle/graph/batch.h)：padding/空history语义 | 通用-1 padding、mask与页权限保留，不随专用scorer一起删 |
| [`RowCacheIndexerScores`](../../include/hyle/compute/model_ops.h#L169) | GA两版H64/D128、FP4-QAT score数学仍在；现有[scorer fixture](../../tests/compute_models/row_cache_indexer_fixture.h)是post-QAT合成边界 | 保留H64承载，GA接线/逐步BF16舍入待核；不是GLM H32通用indexer，也非已验证GA consumer |
| [`CacheEncode`](../../include/hyle/compute/model_ops.h#L213) | [公开cache codec](../../include/hyle/compute/model_ops.h#L205)面向追加的新行与native GGUF cache | 通用codec保留；GA cache实际codec不能由同名推断 |
| [`ArtifactWeightDecode`](../../include/hyle/compute/model_ops.h#L244) | [非GGUF载体fixture](../../tests/compute_models/cpu_c5_non_gguf_fixture.h)；NF4/compressed-tensors精确格式 | 保留独立通用artifact能力；24个profile的逐role使用与未使用仍需反查 |
| [`MlxQuantized`](../../include/hyle/compute/model_ops.h#L280) | [MLX packed fixture](../../tests/compute_models/cpu_c5_non_gguf_fixture.h)：affine/MXFP独立载体 | 保留通用MLX能力；不能将人工MLX样例签为所选GGUF/官方profile |
| [`BlockQuantizationRoundtrip`](../../include/hyle/compute/model_ops.h#L322) | [GA同族量化recipe](../../tests/compute_models/d5_deepseek_official_fragments.h)与正式源FP8/FP4 QAT | GA域仍需而保留；roundtrip不能替代完整量化MatMul证明 |
| [`Float8WeightDecode`](../../include/hyle/compute/model_ops.h#L359) | [GLM absorbed权重准备](../../tests/compute_models/d5_glm_remaining_fragments.h#L327)实际调用；GA wo_a也有冷转换 | 共享GLM能力保留；GA UE8M0→接入scale载体与BF16转换须精确核 |
| [`Float8BlockLinear`](../../include/hyle/compute/model_ops.h#L395) | [动态FP8线性fixture](../../tests/compute_models/d5_dynamic_fp8_fragments.h)：GLM；GA非expert线性仍需FP8 | 保留；F32-scale carrier、UE8M0值与floor/power2合同分别核 |
| [`GroupedFloat8Linear`](../../include/hyle/compute/model_ops.h#L442) | [GLM grouped FP8 fixture](../../tests/compute_models/d5_grouped_fp8_fragments.h) | GLM域保留；不能把可选FP4→FP8转换当GA原始expert格式 |
| [`GroupedFloat4Linear`](../../include/hyle/compute/model_ops.h#L490) | 两GA仍是FP4 weight32/FP8 A128；[旧同族recipe](../../tests/compute_models/d5_deepseek_official_fragments.h)与[CUDA固定N/K](../../src/compute_provider_cuda/deepseek_grouped_fp4_provider.cc) | 保留GA组合；不等同Kimi A32；旧fixture身份和GA tensor角色仍须迁移 |
| [`Clamp`](../../include/hyle/compute/model_ops.h#L531) | GLM learned index ReLU、GA gate/up clip10；[MoE fixture](../../tests/compute_models/d5_moe_execution_fragments.h) | 通用min/max/clamp能力保留，Infinity/NaN规则按端口核 |
| [`SqrtSoftplusRouting`](../../include/hyle/compute/model_ops.h#L575) | 两GA E384/256、Top6、scale2.5/1.5仍需；[routing recipe](../../tests/compute_models/d5_moe_execution_fragments.h) | 保留；CUDA已核bias只选ID、无epsilon归一化、原生tie与零和；完整制品仍待核 |
| [`SqrtSoftplusHashRouting`](../../include/hyle/compute/model_ops.h#L622) | 两GA首3层token-table hash；[SGLang接线](../../src/compute_provider_cuda/router_provider.cc) | 保留；已改按真实分数和归一化，含零和NaN、表序/重复ID/bounds回归；完整制品仍待核 |
| [`SinkAttention`](../../include/hyle/compute/model_ops.h#L655) | GA learned sink/sparse attention；[状态消费者](../../tests/compute_state/deepseek_sparse_prefix_consumer.cc) | 保留；BF16逐节点转换、mask/sink分母和稀疏位置另核 |
| [`CausalConv1d`](../../include/hyle/compute/model_ops.h#L706) | Q35/Q27/Q24 GDN、K/GF KDA；[真实Qwen消费者](../../tools/qwen35_text/main.cc) | 共享通用conv/history能力保留；GA无需conv不构成删除理由 |
| [`RecurrentGatedDeltaNet`](../../include/hyle/compute/model_ops.h#L765) | 参数化scalar-gated GDN；[GDN recipe](../../tests/compute_models/d5_qwen38_24t_semantic_fragments.h) | 普通GDN推导QKV/状态/快照，backend另核真实能力；Kimi/GLM KDA的channel raw gate是另外合同，不能由宽family映射等同 |
| [`GroupedMatMul`](../../include/hyle/compute/model_ops.h#L817) | Q24/K/G/GF routed专家、GA分组投影；[Q24完整router](../../tests/compute_models/d5_qwen38_24t_full_router.h) | 通用stored-bank/ID能力保留；格式、A=1/S、累加/输出逐role核 |
| [`HyperConnectionCombine`](../../include/hyle/compute/model_ops.h#L863) | [GLM Flash](../../tests/compute_models/d5_glm_remaining_fragments.h#L211)实际接入[共享HC core](../../tests/compute_models/d5_moe_semantic_fragments.h#L331)；GA也需HC4/Sinkhorn20 | 共享GF与GA，保留；F32/BF16边界与epsilon不能被同名消除 |
| [`HyperConnectionPre`](../../include/hyle/compute/model_ops.h#L904) | GLM Flash共享core与GA HC collapse；输出head也有对应数学 | 共享能力保留，旧单层MTP与DSpark角色分开 |
| [`HyperConnectionPost`](../../include/hyle/compute/model_ops.h#L939) | GLM Flash共享core与GA HC expansion/residual | 共享能力保留；combination方向、残差与转换边界逐profile核 |
| [`LightningIndexer`](../../include/hyle/compute/model_ops.h#L988) | GA仍需H64/D128 learned score；现有[稀疏fixture](../../tests/sparse_fragment_test_support.h)仅合成F32/F16-mask端口 | 保留该承载并核GA BF16舍入/接线；模型fixture未直接调用，不能把GLM H32或合成测试称GA支持 |
| [`BFloatLinearF32`](../../include/hyle/compute/model_ops.h#L1039) | [Q24 BF16 router near-tie](../../tests/compute_models/d5_qwen38_24t_full_router.h)及KDA投影；GA router也有F32 score需求 | 共享能力保留；BF16权重/F32分数合同不等同普通BF16 MatMul输出 |

派生关系也必须保留在反向核对中：[detail::RowCachePagedIndexerScores](../../src/compute_batch/row_cache_map.h#L67) 与 [Graph PagedRowCacheIndexer](../../include/hyle/graph/batch.h#L81)依赖上述H64 scorer，另有页权限/metadata/empty-history合同；它们不增加25个公开descriptor的计数。不能只删schema而漏掉CUDA/Apple/Vulkan/CPU接线，也不能顺带删除generic row-cache map/gather/decode与typed paging能力。

[Hadamard](../../include/hyle/compute/operation.h#L390)是普通公开operation，不在25个custom描述符内；两GA仍需normalized Hadamard。带 `deepseek` 名称的[CUDA FP8 provider](../../src/compute_provider_cuda/deepseek_fp8_provider.cc)还承载GLM使用的decode与独立roundtrip能力；ggml `dsv4_hc_*` 也被GLM Flash使用。因此不能按路径/符号前缀或旧preview标签批量删除第三方依赖。

## 继续细化与融合审查边界

下一轮按每个选定profile的真实tensor角色补齐精确codec、block/group/axis、codes/scales/bias、pack/stride/orientation、activation量化、饱和/舍入、累加与输出。GA GGUF主header、DSpark可选sidecar及各backend原生域分别记录；全profile汇总formats不能代替逐role身份。

每条实际recipe需连到Hyle admission/lowering、原生standalone/region入口和依赖版本，并区分prefill/chunk/decode、真实M/N/K、ragged/tail、KV/state有效范围、动态参数及设备容量。核对Cast、公开中间值、外部reader、alias/state顺序与融合被切断的位置；packing/cache、workspace所有者、rebind/replay/capture、completion/失败不发布和旧结果寿命同时保留。源码可达、实际kernel执行、数值一致、融合命中与端到端收益各自有证据后再分别陈述；本表没有完成这些运行审查。

本轮没有确认可仅因撤销preview而删除上述router、GroupedFP4、HC、压缩或indexer实现。F14.4旧MTPBlock的变更应由DSpark角色对照解决；公共数学与仍有现行需求的载体继续保留。历史catalog、provider map、ledger及状态只提供来源，不签署当前支持。

[pro-card]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/blob/72e1d3230f6c080a530b0a1d46f8eb4602340597/README.md
[flash-card]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731/blob/7872f01b1d1fe23eabc4c98b48bffcef5a386062/README.md
[pro-config]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/blob/72e1d3230f6c080a530b0a1d46f8eb4602340597/config.json
[flash-config]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731/blob/7872f01b1d1fe23eabc4c98b48bffcef5a386062/config.json
[pro-source]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/blob/72e1d3230f6c080a530b0a1d46f8eb4602340597/inference/model.py
[flash-source]: https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash-0731/blob/7872f01b1d1fe23eabc4c98b48bffcef5a386062/inference/model.py
[pro-gguf]: https://huggingface.co/unsloth/DeepSeek-V4-Pro-0813-GGUF/tree/6d053616d152293da72569f56b861466f10ace7d
[flash-gguf]: https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF/tree/fbbb5b93fb787c21338159b0af3318bb3f4d9768
[flash-dspark]: https://huggingface.co/unsloth/DeepSeek-V4-Flash-0731-GGUF/blob/fbbb5b93fb787c21338159b0af3318bb3f4d9768/dspark/README.md

