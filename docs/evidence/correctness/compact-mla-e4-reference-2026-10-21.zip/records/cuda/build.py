from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess,sys,time
sys.dont_write_bytecode=True
R=Path.cwd();P=R/'.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda'
NBASE=R/'.scratch/inference-foundation-review-2026-10-18/cuda-ragged-mla/native-command.json'
HBASE=R/'.scratch/architecture-refactor-2026-10-18/batch-output-tail/checks/flashinfer-provider-identity.json'
sys.path.insert(0,str(R/'scripts'));from hyle_environment import windows_compiler_environment
def load(f):return json.loads(Path(f).read_text(encoding='utf-8-sig'))
def save(f,x):Path(f).write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def ident(f):
 f=Path(f).resolve();b=f.read_bytes();return {'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def build(kind):
 out=P/'checks/attempt1'/kind;out.mkdir(parents=True,exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
 assert not(out/'compile-result.json').exists(),'Preserve actual attempts'
 native=kind=='native-mla';recipe=NBASE if native else HBASE;old=load(recipe);args=[];skip=False
 source=R/'src/compute_provider_flashinfer'/('native_mla.cu'if native else'flashinfer_provider.cc')
 if native:
  oldheaders=str(NBASE.parent/'verified-headers');newheaders=str(P/'verified-headers')
  args=[x.replace(oldheaders,newheaders)for x in old['command']]
  args[args.index('-c')+1]=str(source);args[args.index('-o')+1]=str(out/'native-mla.obj')
  args+=['-MD','-MF',str(out/'native-mla.d')]
  compiler=args[args.index('--compiler-bindir')+1]+'\\cl.exe'
 else:
  for a in old['command']:
   if skip:skip=False;continue
   if a.lower()=='/sourcedependencies':skip=True;continue
   if a.lower().startswith(('/fo','/fd')):continue
   args.append(a)
  # Actual recipe source is the same canonical owner.
  assert any(Path(a).resolve()==source.resolve()for a in args if a.lower().endswith('.cc'))
  args+=['/sourceDependencies',str(out/'dependencies.json'),'/Fo'+str(out/'provider.obj'),'/Fd'+str(out/'provider.pdb')]
  compiler=args[0]
 env=windows_compiler_environment({'CMAKE_CXX_COMPILER':compiler});env['VSLANG']='1033';env['TMP']=env['TEMP']=str(out/'tmp')
 snapshot=out/source.name;snapshot.write_bytes(source.read_bytes())
 record={'command':args,'cwd':str(R),'source':ident(source),'retained_source':ident(snapshot),'recipe':ident(recipe),'public_batch_header':ident(R/'include/hyle/compute/batch_layout.h'),'started':time.time(),'SDK_rebuilds':0,'GPU_runs':0}
 if native:record.update(manifest=ident(R/'third_party/flashinfer_cache/patches.json'),patched_MLA=ident(P/'verified-headers/include/flashinfer/attention/mla.cuh'))
 save(out/'compile-command.json',record);start=time.monotonic()
 with (out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
  proc=subprocess.run(args,cwd=R,env=env,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
 record.update(exit=proc.returncode,seconds=time.monotonic()-start,finished=time.time(),stdout=ident(out/'stdout.log'),stderr=ident(out/'stderr.log'))
 save(out/'compile-result.json',record)
 if proc.returncode:
  print(kind,'FAILED',proc.returncode,flush=True);print((out/'stdout.log').read_text(errors='replace')[-6500:],flush=True);print((out/'stderr.log').read_text(errors='replace')[-3000:],flush=True);return record
 assert record['source']==ident(source)
 if native:
  dep=(out/'native-mla.d').read_text().replace('\\\n',' ').split(' : ',1)[1];paths=[]
  for a in re.findall(r'(?:\\.|[^\s])+',dep):paths.append(Path(re.sub(r'\\([ ()#])',r'\1',a)).resolve())
 else:
  dep=load(out/'dependencies.json')['Data'];paths=[Path(dep['Source']),*[Path(x)for x in dep['Includes']]]
 paths=list({str(x).lower():x for x in paths}.values());assert all(x.is_file()for x in paths)
 record.update(object=ident(out/('native-mla.obj'if native else'provider.obj')),dependencies=[ident(x)for x in paths],dependency_count=len(paths))
 save(out/'identity.json',record);print(kind,'PASS',round(record['seconds'],3),record['object']['path'],flush=True);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(build,['native-mla','host-provider']))
failed=[x['source']['path']for x in results if x['exit']]
save(P/'checks/attempt1/summary.json',{'results':[{'source':x['source'],'object':x.get('object'),'exit':x['exit'],'seconds':x['seconds']}for x in results],'compile_processes':2,'successful':2-len(failed),'failed':failed,'links':0,'GPU_runs':0,'SDK_rebuilds':0})
raise SystemExit(bool(failed))
