C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/checks/attempt1/native-mla/native-mla.obj : C:/public/project-hyle/hyle/src/compute_provider_flashinfer/native_mla.cu \
    C:/public/project-hyle/hyle/src/compute_provider_flashinfer/native_mla.cu \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_runtime.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_config.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/crtdefs.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/sal.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/concurrencysal.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vadefs.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdarg \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/yvals_core.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xkeycheck.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdarg.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/builtin_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_defines.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/ctype.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wctype.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/driver_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_types.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/limits.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stddef.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/surface_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/texture_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/library_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/channel_descriptor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_runtime_api.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_device_runtime_api.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stdlib.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_malloc.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_search.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstdlib.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/driver_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/vector_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/common_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/host_defines.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/string.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_memory.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_memcpy_s.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/errno.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_string.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstring.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/time.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wtime.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/new \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/exception \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/yvals.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/crtdbg.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_new_debug.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_new.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/use_ansi.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdlib \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/math.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_math.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/type_traits \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstddef \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xtr1common \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdint \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdint.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/malloc.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_exception.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/eh.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_terminate.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/stdio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wstdio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_stdio_config.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/assert.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/math_functions.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cmath \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/math_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_double_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/device_double_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_35_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_60_atomic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_60_atomic_functions.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_20_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_30_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_30_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_32_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_35_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_61_intrinsics.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/sm_61_intrinsics.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_70_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_70_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_80_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_80_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_90_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_90_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_100_rt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/sm_100_rt.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/texture_indirect_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/surface_indirect_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/crt/cudacc_ext.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/device_launch_parameters.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/utility \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/initializer_list \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/verified-headers/include/flashinfer/vec_dtypes.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_bf16.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp16.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/target \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/detail/__target_macros \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/nv/detail/__preprocessor \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp16.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_bf16.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_fp8.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp8.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_fp4.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp6.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp6.hpp \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cuda_fp4.hpp \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/verified-headers/include/flashinfer/math.cuh \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/verified-headers/include/flashinfer/pos_enc.cuh \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/iostream \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/istream \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_ostream.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ios \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xlocnum \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cfloat \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/float.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/climits \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstdio \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/iterator \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/iosfwd \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cstring \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cwchar \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/wchar.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wconio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wdirect.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wio.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_share.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_wprocess.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/sys/stat.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/sys/types.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin0.inl.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/setjmp.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/immintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/wmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/nmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/smmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/tmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/pmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/emmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/mmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/zmmintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ammintrin.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xutility \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_iter_core.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/streambuf \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xiosbase \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/share.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/system_error \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_system_error_abi.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cerrno \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/stdexcept \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xstring \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_sanitizer_annotate_container.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_string_view.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xmemory \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/limits \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/intrin0.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xatomic.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xpolymorphic_allocator.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/tuple \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xcall_once.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xerrc.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/atomic \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xthreads.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_threads_core.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xtimec.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ctime \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xlocale \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/memory \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/typeinfo \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_typeinfo.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xfacet \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xlocinfo \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_xlocinfo_types.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cctype \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/clocale \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/locale.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ostream \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/string \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/layout.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/page.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/driver_types.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vector \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_bit_utils.hpp \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/exception.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/sstream \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/fastdiv.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/cmath \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/detail/__config \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/atomic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cccl_config \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/architecture.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/compiler.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/preprocessor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/assert.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/system_header.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/is_non_narrowing_convertible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/attributes.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/diagnostic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/dialect.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/builtin.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/extended_data_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/cuda_toolkit.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/execution_space.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/os.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/host_std_lib.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/version \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/prologue.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/epilogue.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/cuda_capabilities.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/deprecated.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/exceptions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/ptx_isa.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/rtti.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/sequence_access.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/unreachable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/version.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cccl/visibility.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/features.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/cpp_dialect.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/namespaces.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/version.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/pstl_config.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__internal/thread_api.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/ceil_div.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/min.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/comp.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/integral_constant.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/comp_ref_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/declval.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/void_t.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/min_element.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/identity.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/reference_wrapper.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/invoke.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/concept_macros.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/reference_wrapper.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/decay.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_referenceable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_same.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_void.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_cvref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_cv.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_const.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_volatile.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/cstddef \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cstddef/byte.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_integral.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cstddef/types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/version \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/conditional.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_array.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_function.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_const.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_extent.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/enable_if.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_base_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_core_convertible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_member_function_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_member_object_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/nat.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/forward.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/weak_result_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/binary_function.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/unary_function.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__memory/addressof.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/iterator_traits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/arithmetic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_arithmetic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_floating_point.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_signed.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_signed_integer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_unsigned_integer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/convertible_to.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_convertible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/destructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_destructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_all_extents.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_destructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_scalar.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_enum.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_member_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_null_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_object.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_class.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_union.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/same_as.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_lvalue_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_callable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_valid_expansion.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/conjunction.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/disjunction.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/negation.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/copyable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/common_reference_with.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/common_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/common_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/copy_cvref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_rvalue_reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_extended_floating_point.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/copy_cv.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/make_const_lvalue_ref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/movable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/swappable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/class_or_enum.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/extent.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_move_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_move_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/type_identity.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/exchange.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/move.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_copy_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_const.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/equality_comparable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/boolean_testable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_comparable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/totally_ordered.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/iterator.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/pair.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/incrementable_traits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_primary_template.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/make_signed.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/type_list.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/type_set.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/fold.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/integer_sequence.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/undefined.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/readable_traits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/priority_tag.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/initializer_list \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/make_unsigned.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_unsigned.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/underlying_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/to_underlying.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/fast_modulo_division.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/ilog.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__bit/has_single_bit.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__bit/popcount.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/cstdint \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/limits \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__limits/numeric_limits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__bit/bit_cast.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_copyable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_default_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/cstring \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cstring/memcpy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memory/check_address.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memory/address_space.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/get_sreg.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/ptx_dot_variants.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/ptx_helper_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/get_sreg.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cstring/memset.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__string/constexpr_c_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/make_nbit_int.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/always_false.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/climits \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/cfloat \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__limits/numeric_limits_ext.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/storage.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/cuda_fp_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/format.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/fp.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/traits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/properties.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__bit/integral.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/bfind.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/bfind.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/shl.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/shl.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/shr.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/shr.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/max.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/max_element.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__bit/countl.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/rounding_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__host_stdlib/math.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/promote.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_integer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/array \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/equal.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/distance.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/concepts.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/derived_from.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/invocable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/predicate.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/regular.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/semiregular.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__concepts/relation.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/iter_move.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__memory/pointer_traits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__ranges/access.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__ranges/enable_borrowed_range.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/auto_cast.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__ranges/concepts.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__ranges/data.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/reverse_iterator.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/unwrap_iter.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/advance.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/convert_to_integral.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/iter_swap.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/iterator.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/next.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/prev.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_default_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_convertible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/lazy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_copy_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_default_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_pointer.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__ranges/enable_view.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__ranges/size.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_unbounded_array.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/fill_n.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/lexicographical_compare.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/swap_ranges.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/iterator_operations.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/iter_swap.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/swap.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_move_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_move_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_swappable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__algorithm/ranges_iterator_concept.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/pair.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/unwrap_ref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/get.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/array.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/complex.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/subrange.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/tuple.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__tuple_dir/tuple_element.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__tuple_dir/tuple_indices.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__tuple_dir/tuple_types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_cv.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/add_volatile.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__tuple_dir/sfinae_helpers.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_copy_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__tuple_dir/structured_bindings.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__fwd/complex.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__tuple_dir/tuple_size.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_volatile.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_implicitly_default_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_nothrow_copy_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/piecewise_construct.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__exception/throw_error.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__exception/terminate.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__host_stdlib/stdexcept \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/unreachable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/access.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/data.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/empty.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/reverse_access.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__iterator/size.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/mul_hi.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/num_bits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/has_unique_object_representation.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/pow2.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/ipow.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/neg.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/uabs.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/cmp.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/isqrt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/round_down.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/round_up.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__cmath/sincos.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/trigonometric_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_extended_arithmetic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/cmath \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/abs.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/fp.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/arithmetic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/mask.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/native_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/cast.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/cccl_fp.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/conversion_rank_order.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/common_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/constants.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/decompose.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__floating_point/overflow_handler.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/copysign.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/error_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/exponential_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/isinf.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/isnan.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/fdim.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/fma.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/fpclassify.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/gamma.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/hyperbolic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/hypot.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/min_max.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__type_traits/is_floating_point.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/roots.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/inverse_hyperbolic_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/inverse_trigonometric_functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/isfinite.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/isnormal.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/lerp.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/logarithms.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/modulo.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/nan.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/remainder.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/signbit.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cmath/traits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__cstdlib/abs.h \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/utils.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_device_runtime_api.h \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/vec_dtypes.cuh \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/verified-headers/include/flashinfer/attention/scheduler.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cuda_runtime_api.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/algorithm \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_heap_algorithms.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_minmax.hpp \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/../allocator.h \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/heap.h \
    C:/public/project-hyle/hyle/src/compute_provider_flashinfer/native_batch.h \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/verified-headers/include/flashinfer/attention/mla.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cooperative_groups.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cooperative_groups/details/info.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/type_traits \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/hash.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/aligned_storage.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/aligned_union.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/alignment_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/can_extract_key.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/remove_const_ref.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/dependent_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/has_virtual_destructor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_abstract.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_aggregate.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_allocator.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_bounded_array.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_char_like_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_standard_layout.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivial.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_compound.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_fundamental.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_constant_evaluated.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_corresponding_member.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_empty.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_execution_policy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__fwd/execution_policy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_final.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_layout_compatible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_literal_type.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_one_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_pod.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_pointer_interconvertible_base_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_pointer_interconvertible_with_class.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_polymorphic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_scoped_enum.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_copy_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_copy_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_destructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_move_assignable.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/is_trivially_move_constructible.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/maybe_const.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/rank.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/reference_constructs_from_temporary.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/reference_converts_from_temporary.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__type_traits/result_of.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cooperative_groups/details/driver_abi.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cooperative_groups/details/helpers.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cooperative_groups/details/sync.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/include/cooperative_groups/details/memory.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/atomic \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__atomic/atomic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/atomic \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/platform.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/platform/msvc_to_builtins.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/order.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/cassert \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/cassert \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/scopes.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/wait/polling.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/types.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/types/base.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/functions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/functions/cuda_ptx_derived.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/functions/cuda_ptx_generated.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/functions/common.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/functions/cuda_ptx_generated_helper.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/functions/cuda_local.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/types/common.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__functional/operations.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__utility/ctad_support.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/functions/host.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/types/locked.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/types/reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/types/small.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__thread/threading_support.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__chrono/duration.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/ratio \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__chrono/high_resolution_clock.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__chrono/steady_clock.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__chrono/system_clock.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__chrono/time_point.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/ctime \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/chrono \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/__msvc_chrono.hpp \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/ratio \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/xfilesystem_abi.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__thread/threading_support_cuda.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/wait/notify_wait.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/api/owned.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/api/common.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__atomic/api/reference.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cooperative_groups/details/partitioning.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cooperative_groups/details/invoke.h \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/../profiler.cuh \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/verified-headers/include/flashinfer/attention/mla_params.cuh \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/verified-headers/include/flashinfer/attention/prefill.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/../cp_async.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/../frag_layout_swizzle.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/../mma.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/../permuted_smem.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/pipeline \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/check_preconditions.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memory/aligned_size.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/completion_mechanism.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/memcpy_async_barrier.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__barrier/barrier.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__fwd/barrier.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__barrier/empty_completion.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__barrier/barrier.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__barrier/poll_tester.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__new_ \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__new/allocate.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__new/bad_alloc.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__new/device_new.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__new/launder.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__barrier/barrier_block_scope.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/mbarrier_arrive.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_arrive.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_arrive_expect_tx.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_arrive_no_complete.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/mbarrier_init.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_init.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/mbarrier_inval.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_inval.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/mbarrier_wait.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_test_wait.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_test_wait_parity.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_try_wait.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_try_wait_parity.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__barrier/barrier_thread_scope.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/dispatch_memcpy_async.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/cp_async_bulk_shared_global.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/elect_one.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/group_traits.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/elect_sync.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/elect_sync.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/cp_async_bulk.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_bulk.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_bulk_multicast.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/mbarrier_expect_tx.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/mbarrier_expect_tx.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/cp_async_fallback.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/cp_async_shared_global.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/is_local_smem_barrier.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/memcpy_completion.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__barrier/async_contract_fulfillment.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__barrier/barrier_expect_tx.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__fwd/pipeline.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/try_get_barrier_handle.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/barrier \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__barrier/barrier_arrive_tx.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/memcpy_async.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__memcpy_async/memcpy_async_tx.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/ptx \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/barrier_cluster.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/barrier_cluster.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/bmsk.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/bmsk.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/clusterlaunchcontrol.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/clusterlaunchcontrol.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/cp_async_bulk_commit_group.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_bulk_commit_group.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/cp_async_bulk_tensor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_bulk_tensor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_bulk_tensor_gather_scatter.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_bulk_tensor_multicast.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/cp_async_bulk_wait_group.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_bulk_wait_group.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/cp_async_mbarrier_arrive.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_mbarrier_arrive.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_async_mbarrier_arrive_noinc.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/cp_reduce_async_bulk.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_reduce_async_bulk.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_reduce_async_bulk_f16.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_reduce_async_bulk_bf16.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/cp_reduce_async_bulk_tensor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/cp_reduce_async_bulk_tensor.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/exit.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/exit.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/fence.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/fence.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/fence_mbarrier_init.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/fence_proxy_alias.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/fence_proxy_async.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/fence_proxy_async_generic_sync_restrict.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/fence_proxy_tensormap_generic.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/fence_sync_restrict.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/getctarank.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/getctarank.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/ld.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/ld.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/multimem_ld_reduce.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/multimem_ld_reduce.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/multimem_red.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/multimem_red.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/multimem_st.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/multimem_st.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/prmt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/prmt.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/red_async.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/red_async.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/setmaxnreg.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/setmaxnreg.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/shfl_sync.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/st.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/st.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/st_async.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/st_async.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/st_bulk.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/st_bulk.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_alloc.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_alloc.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_commit.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_commit.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_cp.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_cp.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_fence.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_fence.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_ld.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_ld.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_mma.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_mma.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_mma_ws.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_mma_ws.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_shift.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_shift.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_st.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_st.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tcgen05_wait.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tcgen05_wait.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tensormap_cp_fenceproxy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tensormap_cp_fenceproxy.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/tensormap_replace.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/tensormap_replace.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/trap.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/instructions/generated/trap.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/__ptx/pragmas/enable_smem_spilling.h \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/barrier \
    C:/public/project-hyle/hyle/.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda/verified-headers/include/flashinfer/attention/cascade.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/state.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/../math.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/../vec_dtypes.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/mask.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/variants.cuh \
    C:/public/project-hyle/hyle/.scratch/g04-bf16-partials-vendor/upstream/include/flashinfer/attention/variant_helper.cuh \
    C:/Program\ Files/NVIDIA\ GPU\ Computing\ Toolkit/CUDA/v13.3/bin/../include/cccl/cuda/std/__thread/threading_support_win32.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/process.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/ucrt/corecrt_startup.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/vcruntime_startup.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/windows.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/winapifamily.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/winpackagefamily.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/sdkddkver.h \
    C:/Program\ Files/Microsoft\ Visual\ Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/include/excpt.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/windef.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/minwindef.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/specstrings.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/specstrings_strict.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/specstrings_undef.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/driverspecs.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/sdv_driverspecs.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winnt.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/kernelspecs.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/basetsd.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/guiddef.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/pshpack4.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/poppack.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/pshpack2.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/pshpack8.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/pshpack1.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/apiset.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/ktmtypes.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winbase.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/apisetcconv.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/minwinbase.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/apiquery2.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/processenv.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/fileapifromapp.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/fileapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/debugapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/utilapiset.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/handleapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/errhandlingapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/fibersapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/namedpipeapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/profileapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/heapapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/ioapiset.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/synchapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/interlockedapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/processthreadsapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/sysinfoapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/memoryapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/enclaveapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/threadpoollegacyapiset.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/threadpoolapiset.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/jobapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/jobapi2.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/wow64apiset.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/libloaderapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/securitybaseapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/namespaceapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/systemtopologyapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/processtopologyapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/securityappcontainer.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/realtimeapiset.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/winerror.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/timezoneapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/wingdi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winuser.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/tvout.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winnls.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/datetimeapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/stringapiset.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/wincon.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/wincontypes.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/consoleapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/consoleapi2.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/consoleapi3.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winver.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/verrsrc.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winreg.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/reason.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winnetwk.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/wnnc.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/cderr.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/dde.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/ddeml.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/dlgs.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/lzexpand.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/mmsystem.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/mmsyscom.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/mciapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/mmiscapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/mmiscapi2.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/playsoundapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/mmeapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/timeapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/joystickapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/nb30.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/rpc.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/rpcdce.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/rpcdcep.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/rpcnsi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/rpcnterr.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/rpcasync.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/shellapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winperf.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winsock.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/inaddr.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/wincrypt.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/bcrypt.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/ncrypt.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/dpapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winefs.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winscard.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/wtypes.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/rpcndr.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/rpcnsip.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/rpcsal.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/wtypesbase.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winioctl.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/winsmcrd.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winspool.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/prsht.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/ole2.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/objbase.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/combaseapi.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/unknwnbase.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/objidlbase.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/cguid.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/coml2api.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/objidl.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/unknwn.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/propidlbase.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/oaidl.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/urlmon.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/oleidl.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/servprov.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/msxml.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/propidl.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/oleauto.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/commdlg.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/shared/stralign.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/winsvc.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/mcx.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/imm.h \
    C:/Program\ Files\ (x86)/Windows\ Kits/10/include/10.0.26100.0/um/ime_cmodes.h
