from pathlib import Path
import hashlib,json,subprocess,sys
r=Path.cwd();p=r/'.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/cuda';m=r/'third_party/flashinfer_cache/patches.json';d=json.loads(m.read_text());raw=r/'.scratch/g04-bf16-partials-vendor/upstream'
def ident(f):
 f=Path(f);b=f.read_bytes();return {'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
subset=p/'manifest-originals';subset.mkdir(exist_ok=True);inputs=[]
for f in d['files']:
 if 'content'in f:continue
 src=raw/f['path'];b=src.read_bytes().replace(b'\r\n',b'\n');assert hashlib.sha256(b).hexdigest()==f['before_sha256'],f['path']
 dest=subset/f['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);inputs.append({'source':ident(src),'subset':ident(dest)})
command=[sys.executable,str(r/'src/compute_ggml_runtime/prepare_source.py'),'--source',str(subset),'--output',str(p/'verified-headers'),'--manifest',str(m)]
proc=subprocess.run(command,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
(p/'prepare.stdout.log').write_bytes(proc.stdout);(p/'prepare.stderr.log').write_bytes(proc.stderr)
record={'command':command,'exit':proc.returncode,'manifest':ident(m),'preparer':ident(r/'src/compute_ggml_runtime/prepare_source.py'),'upstream_revision':d['upstream_revision'],'inputs':inputs,'scope':'Bounded manifest-originals view from exact pinned existing source; every original checked against beforeSHA; canonical product preparer applies every locked edit. Reuses unmodified original/verified include paths for all other headers. This is not a fresh full-SDK copy or full-tree archive authentication.','GPU_runs':0,'shared_cache_mutated':False}
assert proc.returncode==0,(proc.stdout+proc.stderr).decode(errors='replace')
outputs=[]
for f in d['files']:
 src=p/'verified-headers'/f['path'];i=ident(src);assert i['sha256']==f['after_sha256'];outputs.append(i)
actual=p/'verified-headers/include/flashinfer/attention/mla.cuh';expected=p/'expected-mla.cuh';assert actual.read_bytes()==expected.read_bytes()
record.update(outputs=outputs,exact_MLA_equals_frozen_candidate=True)
(p/'canonical-preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'receipt':ident(p/'canonical-preparation.json'),'result_files':len(outputs),'original_bytes':sum(x['subset']['bytes']for x in inputs),'stdout':proc.stdout.decode().strip()},indent=2))
