from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'compact-mla-e4-reference/vulkan';C=S/'checks/attempt2';C.mkdir(parents=True,exist_ok=True)
BASE=A/'e8m0-block128-import-reference/vulkan/checks/link1/link-plan.json'
def read(p):return json.loads(Path(p).read_bytes())
def save(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
def ident(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
base=read(BASE)
def recipe(obj):
 for p in Path(obj).parent.glob('*identity.json'):
  d=read(p)
  if Path(d.get('object',{}).get('path',''))==obj:return p
 raise ValueError(obj)
def owner(name):
 found=[Path(x['path']) for x in base['inputs'] if Path(x['path']).name==name]
 assert len(found)==1,(name,found)
 return found[0]
pairs=[('batch',R/'src/compute_route_vulkan/vulkan_batch.cc',owner('batch.obj')),('program',R/'src/compute_route_vulkan/vulkan_program.cc',owner('program.obj')),('route-region',R/'src/compute_route_vulkan/vulkan_region.cc',owner('route-region.obj')),('provider-region',R/'src/compute_provider_ggml_vulkan/region.cc',owner('region.obj')),('driver',S/'current-patch-source/src/ggml-vulkan/ggml-vulkan.cpp',owner('driver.obj')),('native-ragged',R/'src/graph_route_vulkan/native_ragged_region.cc',owner('graph_route_vulkan-native_ragged_region.obj'))]
plan=[dict(name=n,source=ident(src),old_object=ident(o),old_identity=ident(recipe(o))) for n,src,o in pairs]
save(C/'compile-plan.json',dict(baseline=ident(BASE),CXX=plan,shader_compiles=0,links=0,GPU=0,SDK_build=0))
env=os.environ.copy();result=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in result.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
(S/'tmp').mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(S/'tmp')
def compile_one(entry):
 name,src,old=entry;rp=recipe(old);original=read(rp);command=[];skip=False
 for arg in original['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  command.append(arg)
 command+=['/sourceDependencies',str(C/(name+'-deps.json')),str(src),'/Fo'+str(C/(name+'.obj')),'/Fd'+str(C/(name+'.pdb'))]
 start=time.time();p=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace')
 save(C/(name+'-command.json'),dict(command=command,cwd=str(R),exit_code=p.returncode,seconds=time.time()-start))
 (C/(name+'-stdout.txt')).write_text(p.stdout,encoding='utf8');(C/(name+'-stderr.txt')).write_text(p.stderr,encoding='utf8')
 print(name,p.returncode,flush=True)
 if p.returncode:raise RuntimeError((p.stdout+p.stderr)[-5000:])
 deps=read(C/(name+'-deps.json'))['Data'];record=dict(source=ident(src),object=ident(C/(name+'.obj')),command=command,recipe=ident(rp),replaces=ident(old),dependencies=[ident(x) for x in dict.fromkeys([deps['Source'],*deps['Includes']])])
 save(C/(name+'-identity.json'),record)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(compile_one,pairs))
save(C/'objects-ready.json',dict(status='all_six_actual_Vulkan_owners_compiled',objects=[x['object'] for x in records],identities=[ident(C/(n+'-identity.json')) for n,_,_ in pairs],successful_CXX=6,shader_compiles=0,links=0,GPU=0,SDK_build=0,baseline=ident(BASE)))
