from pathlib import Path
import json,hashlib,shutil
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';P=A/'compact-mla-e4-reference/apple';old=A/'paged-e4-kv-reference/apple'
p=ROOT/'src/graph_route_apple/native_ragged_region.cc';dest=P/'before/src/graph_route_apple/native_ragged_region.cc';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
s=p.read_text(encoding='utf-8')
b='Result<compute::RaggedAttention> qualify(void *context,'
a='''struct Recipe final {
  compute::RaggedAttention attention;
  compute::MlaCacheLayout mla = compute::MlaCacheLayout::kNone;
};
Result<Recipe> recipe(const compute::Operation &operation) noexcept {
  if (const auto attention = operation.custom_as<compute::RaggedAttention>()) {
    if (attention->capacity.key_storage.data_type() == compute::DataType::kFloat8E4M3FN)
      return std::unexpected(Status::Unimplemented("Apple ragged E4 needs its compact MLA operation"));
    return Recipe{*attention};
  }
  if (const auto mla = operation.custom_as<compute::RaggedMlaAttention>()) {
    HYLE_ASSIGN_OR_RETURN(auto capacity, compute::mla_batch_capacity(mla->capacity));
    return Recipe{{.capacity = capacity, .scale = mla->scale,
        .causal = mla->causal, .window_left = mla->window_left}, mla->capacity.layout};
  }
  return std::unexpected(Status::Unimplemented("not ordinary or compact MLA ragged attention"));
}
Result<Recipe> qualify(void *context,'''
assert s.count(b)==1;s=s.replace(b,a)
b='''  const auto attention = operation.custom_as<compute::RaggedAttention>();
  if (!attention)
    return std::unexpected(Status::Unimplemented("not ordinary ragged attention"));
  HYLE_RETURN_IF_ERROR(an::PagedBatchAccess::validate_ragged(source_runtime(context), *attention));
  return *attention;'''
a='''  HYLE_ASSIGN_OR_RETURN(auto selected, recipe(operation));
  HYLE_RETURN_IF_ERROR(an::PagedBatchAccess::validate_ragged(source_runtime(context), selected.attention));
  return selected;'''
assert s.count(b)==1;s=s.replace(b,a)
s=s.replace('  compute::RaggedAttention attention;\n  NodeId node;', '  compute::RaggedAttention attention;\n  compute::MlaCacheLayout mla = compute::MlaCacheLayout::kNone;\n  std::size_t payloads = 3;\n  NodeId node;')
s=s.replace('layout.schema().mla_layout() != compute::MlaCacheLayout::kNone ||','layout.schema().mla_layout() != artifact.mla ||')
s=s.replace('.mla = compute::MlaCacheLayout::kNone,','.mla = artifact.mla,')
s=s.replace('inputs[artifact.metadata_port].description != artifact.descriptions[3]','inputs[artifact.metadata_port].description != artifact.descriptions[artifact.payloads]')
s=s.replace('port < artifact.inputs.size();','port < artifact.payloads;')
s=s.replace('an::InvocationAccess::prepare_inputs(slot.native, slot.bindings)','an::InvocationAccess::prepare_inputs(slot.native, std::span(slot.bindings).first(artifact.payloads))')
b='''  const auto attention = operation.custom_as<compute::RaggedAttention>();
  return attention && an::PagedBatchAccess::validate_ragged(source_runtime(context), *attention).ok();'''
a='''  const auto selected = recipe(operation);
  return selected && an::PagedBatchAccess::validate_ragged(source_runtime(context), selected->attention).ok();'''
assert s.count(b)==1;s=s.replace(b,a)
b='''    const auto attention = operation.custom_as<compute::RaggedAttention>();
    if (!attention) continue;
    const auto admitted = an::PagedBatchAccess::validate_ragged(source_runtime(context), *attention);'''
a='''    auto selected = recipe(operation);
    if (!selected) { if (selected.error().IsUnimplemented()) continue; return selected.error(); }
    const auto admitted = an::PagedBatchAccess::validate_ragged(source_runtime(context), selected->attention);'''
assert s.count(b)==1;s=s.replace(b,a)
s=s.replace('  (void)selected;\n','')
s=s.replace('for (std::size_t port = 0; port < 3; ++port) {','for (std::size_t port = 0; port < (selected.mla == compute::MlaCacheLayout::kNone ? 3u : 2u); ++port) {')
s=s.replace('artifact->attention = *attention;','artifact->attention = attention->attention;\n    artifact->mla = attention->mla;\n    artifact->payloads = artifact->mla == compute::MlaCacheLayout::kNone ? 3u : 2u;')
s=s.replace('port < 4; ++port) {','port < artifact->payloads + 1; ++port) {').replace('if (port == 3) {','if (port == artifact->payloads) {')
b='''    HYLE_RETURN_IF_ERROR(artifact->attention.infer_output_descriptions(
        artifact->descriptions, std::span(&expected, 1)));'''
a='''    HYLE_ASSIGN_OR_RETURN(auto operation, request.graph->operation(artifact->node));
    HYLE_RETURN_IF_ERROR(compute::infer_output_descriptions(operation,
        std::span(artifact->descriptions).first(artifact->payloads + 1), std::span(&expected, 1)));'''
assert s.count(b)==1;s=s.replace(b,a);p.write_text(s,encoding='utf-8',newline='\n')
p=ROOT/'src/compute_route_apple/apple_batch.cc';s=p.read_text(encoding='utf-8')
b='''  const bool e4=c.storage==BatchStorage::kPaged &&
      c.key_storage.data_type()==DataType::kFloat8E4M3FN &&
      c.value_storage.data_type()==DataType::kFloat8E4M3FN;'''
a='''  const bool compact_shape=c.kv_heads==1 && c.value_head_dim==512 &&
      (c.qk_head_dim==512 || c.qk_head_dim==576) && c.key_storage==c.value_storage;
  const bool e4=(c.storage==BatchStorage::kPaged || compact_shape) &&
      c.key_storage.data_type()==DataType::kFloat8E4M3FN &&
      c.value_storage.data_type()==DataType::kFloat8E4M3FN;'''
assert s.count(b)==1;s=s.replace(b,a).replace('((plain || e4) && (c.qk_head_dim==512 || c.qk_head_dim==576) &&','((plain || (e4 && compact_shape)) && (c.qk_head_dim==512 || c.qk_head_dim==576) &&')
b='  const bool mla=recipe.schema().mla_layout()!=MlaCacheLayout::kNone;\n  HYLE_RETURN_IF_ERROR(validate_paged'
a='''  const bool mla=recipe.schema().mla_layout()!=MlaCacheLayout::kNone;
  if(c.key_storage.data_type()==DataType::kFloat8E4M3FN && c.value_head_dim==512 && !mla)
    return std::unexpected(Status::Unimplemented("Apple high-dimensional E4 needs its single compact MLA cache"));
  HYLE_RETURN_IF_ERROR(validate_paged'''
assert s.count(b)==1;s=s.replace(b,a)
b='  const auto c=attention.capacity;\n  const auto query_rows='
a='''  const auto c=attention.capacity;
  const bool mla=layout.schema().mla_layout()!=MlaCacheLayout::kNone;
  if(c.key_storage.data_type()==DataType::kFloat8E4M3FN && !mla)
    return std::unexpected(Status::Unimplemented("Apple ragged E4 needs its single compact MLA cache"));
  const auto query_rows='''
assert s.count(b)==1;s=s.replace(b,a)
b='''    HYLE_ASSIGN_OR_RETURN(auto v,batch_cache_description(c,BatchCacheRole::kValue));
    std::array<InputSpec,3> inputs;HYLE_ASSIGN_OR_RETURN(inputs[0],input_spec(q));HYLE_ASSIGN_OR_RETURN(inputs[1],input_spec(k));HYLE_ASSIGN_OR_RETURN(inputs[2],input_spec(v));'''
a='''    std::array<InputSpec,3> inputs;HYLE_ASSIGN_OR_RETURN(inputs[0],input_spec(q));HYLE_ASSIGN_OR_RETURN(inputs[1],input_spec(k));
    if(!mla){HYLE_ASSIGN_OR_RETURN(auto v,batch_cache_description(c,BatchCacheRole::kValue));HYLE_ASSIGN_OR_RETURN(inputs[2],input_spec(v));}'''
assert s.count(b)==1;s=s.replace(b,a)
s=s.replace('prepare_runtime_program(runtime,layout,inputs,\n        [attention,output_query_rows]', 'prepare_runtime_program(runtime,layout,std::span(inputs).first(mla?2u:3u),\n        [attention,output_query_rows,mla]')
s=s.replace('if(inputs.size()!=3)return std::unexpected(Status::InvalidArgument("Apple ragged needs Q/K/V"));','if(inputs.size()!=(mla?2u:3u))return std::unexpected(Status::InvalidArgument("Apple ragged payload count differs"));')
b='auto value_rows=mlx::core::reshape(inputs[2],{int(c.max_kv_rows),int(c.kv_heads),cache_width(c.value_storage,c.value_head_dim)},stream);'
a='''// Compact V aliases the CKV prefix with the original CKV/KPE row pitch.
        auto value_rows=mla?mlx::core::slice(key_rows,{0,0,0},{int(c.max_kv_rows),1,512},stream):
            mlx::core::reshape(inputs[2],{int(c.max_kv_rows),int(c.kv_heads),cache_width(c.value_storage,c.value_head_dim)},stream);'''
assert s.count(b)==1;s=s.replace(b,a)
b='''        auto output=mlx::core::fast::hyle_ragged_attention(
            mlx::core::transpose(q,{0,2,1,3},stream),mlx::core::transpose(k,{0,2,1,3},stream),
            mlx::core::transpose(v,{0,2,1,3},stream),attention.scale,attention.causal,stream,q8,attention.window_left);'''
a='''        const auto qh=mlx::core::transpose(q,{0,2,1,3},stream),kh=mlx::core::transpose(k,{0,2,1,3},stream),vh=mlx::core::transpose(v,{0,2,1,3},stream);
        const bool e4=c.key_storage.data_type()==DataType::kFloat8E4M3FN;
        auto output=e4?mlx::core::fast::hyle_ragged_attention(qh,kh,vh,attention.scale,attention.causal,stream,attention.window_left,c.key_storage.scale(),c.value_storage.scale()):
            mlx::core::fast::hyle_ragged_attention(qh,kh,vh,attention.scale,attention.causal,stream,q8,attention.window_left);'''
assert s.count(b)==1;s=s.replace(b,a);p.write_text(s,encoding='utf-8',newline='\n')
# Append the finite ragged E4 extension to the already-compiled first source.
m=json.loads((ROOT/'third_party/mlx_cast/patches.json').read_text(encoding='utf-8'));changes={};edits={}
def edit(path,before,after):
 s=changes.get(path,(P/'native-after'/path).read_text(encoding='utf-8'));assert s.count(before)==1,(path,s.count(before),before[:70]);changes[path]=s.replace(before,after);edits.setdefault(path,[]).append(dict(before=before,after=after))
f='mlx/fast.h';s=(P/'native-after'/f).read_text();a=s.index('MLX_API array hyle_ragged_attention(');b=s.index(';',a)+1;old=s[a:b]
edit(f,old,old+'''\n// Uniform compact E4 MLA: the caller supplies one root and its V prefix.\nMLX_API array hyle_ragged_attention(\n    const array& q, const array& k, const array& v, float scale, bool causal,\n    Stream stream, int window_left, float key_scale, float value_scale);''')
f='mlx/fast.cpp';edit(f,'(e4 && (!pages || q8 || !(key_scale > 0.0f)', '(e4 && (q8 || (!pages && !((dk == 512 || dk == 576) && dv == 512)) || !(key_scale > 0.0f)')
needle='array scaled_dot_product_attention(\n';edit(f,needle,'''array hyle_ragged_attention(const array& q, const array& k, const array& v,
    float scale, bool causal, Stream stream, int window,
    float key_scale, float value_scale) {
  return hyle_cache_attention(q,k,v,std::nullopt,k.shape(2),-1,scale,causal,
      stream,false,window,true,key_scale,value_scale);
}

'''+needle)
f='mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h'
for role,word in [('k','key'),('v','value')]:
 edit(f,f'loader_{role}.load_e4({role.upper()}bytes, hyle_pages, hyle_offset, kb * BK, params->kL - kb * BK, hyle_{word}_scale);',f'loader_{role}.load_e4({role.upper()}bytes, hyle_paged ? hyle_pages : nullptr, hyle_paged ? hyle_offset : 0, kb * BK, params->kL - kb * BK, hyle_{word}_scale);')
 edit(f,f'if (!hyle_paged && !hyle_q8 && !hyle_window) loader_{role}.next();',f'if (!hyle_paged && !hyle_q8 && !hyle_e4 && !hyle_window) loader_{role}.next();')
(P/'native-source-freeze.stage1.json').write_bytes((P/'native-source-freeze.json').read_bytes())
for row in m['files']:
 name=row['path']
 if name in changes:
  row['edits']+=edits[name];row['after_sha256']=hashlib.sha256(changes[name].encode()).hexdigest();(P/'native-after'/name).write_bytes(changes[name].encode())
(ROOT/'third_party/mlx_cast/patches.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=ROOT/'third_party/mlx_cast/NOTICE.md';s=p.read_text();s+='''\nCompact ragged MLA uses the original ragged region with two payloads (Q and\none shared cache), plus metadata. Per-request slices retain the physical\nCKV/KPE pitch and V is an internal prefix view. The original owned-layout\nupdate, input imports, native result observer and retirement gates are reused.\n''';p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'Apple_sources':['src/compute_route_apple/apple_batch.cc','src/graph_route_apple/native_ragged_region.cc'],'additional_native_files':list(changes),'first_actual_red_preserved':True}))