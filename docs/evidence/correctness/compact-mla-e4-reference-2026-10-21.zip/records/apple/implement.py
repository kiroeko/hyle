from pathlib import Path
import json,hashlib,difflib
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';P=A/'compact-mla-e4-reference/apple';P.mkdir(parents=True,exist_ok=True);old=A/'paged-e4-kv-reference/apple'
owned=['src/compute_route_apple/apple_batch.cc','third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md']
for rel in owned:
 p=P/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes((ROOT/rel).read_bytes())
m=json.loads((ROOT/owned[1]).read_text(encoding='utf-8'));changes={};edits={}
for row in m['files']:
 s=(old/'upstream'/row['path']).read_text(encoding='utf-8');assert hashlib.sha256(s.encode()).hexdigest()==row['before_sha256']
 for e in row['edits']:assert s.count(e['before'])==1;s=s.replace(e['before'],e['after'])
 assert hashlib.sha256(s.encode()).hexdigest()==row['after_sha256'];p=P/'native-before'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(s.encode())
def edit(path,before,after):
 s=changes.get(path,(P/'native-before'/path).read_text(encoding='utf-8'));assert s.count(before)==1,(path,s.count(before),before[:60]);changes[path]=s.replace(before,after);edits.setdefault(path,[]).append(dict(before=before,after=after))
f='mlx/fast.cpp';edit(f,'(!q8 && !e4 && (dk == 512 || dk == 576) && dv == 512)','(!q8 && (dk == 512 || dk == 576) && dv == 512)')
f='mlx/backend/metal/scaled_dot_product_attention.cpp'
for before in ['const bool highdim_cache = page && !page->q8 && !page->e4 &&\n      (q.dtype() == float16 || q.dtype() == bfloat16) &&','const bool highdim_cache = page && !page->q8 && !page->e4 &&\n      (q_pre.dtype() == float16 || q_pre.dtype() == bfloat16) &&']:
 edit(f,before,before.replace(' && !page->e4','').replace('(q.dtype() == float16','(page->e4 || q.dtype() == float16').replace('(q_pre.dtype() == float16','(page->e4 || q_pre.dtype() == float16'))
edit(f,'const bool half_query = page && page->q8 && page->query_f16;','''// E4 high-dimensional caches retain the original query storage precision
  // in shared memory; K/V tiles, accumulators and output remain F32.
  const bool half_query = page && page->query_f16 &&
      (page->q8 || (page->e4 && highdim_cache));
  const bool bf16_query = page && page->e4 && highdim_cache && !page->query_f16;''')
edit(f,'if (half_query) base_name += "_query_half";','if (half_query) base_name += "_query_half";\n    if (bf16_query) base_name += "_query_bfloat16";')
edit(f,'(has_mask ? *mask : q), bv, half_query);','(has_mask ? *mask : q), bv, half_query, bf16_query);')
f='mlx/backend/metal/kernels.h';edit(f,'const array& m, int bv = -1, bool half_query = false);','const array& m, int bv = -1, bool half_query = false, bool bf16_query = false);')
f='mlx/backend/metal/jit_kernels.cpp';edit(f,'const array& m, int bv, bool half_query) {','const array& m, int bv, bool half_query, bool bf16_query) {');edit(f,'half_query ? "half" : get_type_string(q.dtype())));','bf16_query ? "bfloat16_t" : half_query ? "half" : get_type_string(q.dtype())));')
f='mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h'
edit(f,'using QueryFragT = metal::conditional_t<is_same_v<QueryT, T>, AccumType, QueryT>;','''// BF16 is only a lossless shared storage of the original BF16 query.
  // Widen its fragments to F32 rather than introducing BF16 MMA arithmetic.
  using QueryFragT = metal::conditional_t<
      is_same_v<QueryT, T> || is_same_v<QueryT, bfloat16_t>, AccumType, QueryT>;''')
edit(f,'// Source Query is still F32; only a known original F16 Query may instantiate\n  // QueryT=half. Each element is an exact round-trip, including F16 subnormals.','''// Source Query is F32 widened from the original F16/BF16 query. QueryT
  // stores only that original type; decoded KV and probabilities stay F32.
  // BF16 uses a bit-preserving store so no native conversion can flush it.''')
edit(f,'Qs[row * LDQ_tgp + col] = valid ? QueryT(Q[row * params->Q_strides[2] + col]) : QueryT(0);','''if constexpr (is_same_v<QueryT, bfloat16_t>) {
        const ushort bits = valid ? ushort(as_type<uint>(Q[row * params->Q_strides[2] + col]) >> 16u) : ushort(0);
        Qs[row * LDQ_tgp + col] = as_type<bfloat16_t>(bits);
      } else {
        Qs[row * LDQ_tgp + col] = valid ? QueryT(Q[row * params->Q_strides[2] + col]) : QueryT(0);
      }''')
identities=[]
for row in m['files']:
 name=row['path'];before=(P/'native-before'/name).read_bytes();final=changes.get(name,before.decode())
 if name in changes:
  row['edits']+=edits[name];row['after_sha256']=hashlib.sha256(final.encode()).hexdigest();identities.append(dict(path=name,before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=row['after_sha256'],new_edits=len(edits[name])))
  (P/(name.replace('/','--')+'.diff')).write_text(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),final.splitlines(keepends=True),fromfile=name+' before',tofile=name+' after')),encoding='utf-8')
 p=P/'native-after'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(final.encode())
(ROOT/'third_party/mlx_cast/patches.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=ROOT/'src/compute_route_apple/apple_batch.cc';s=p.read_text(encoding='utf-8');b='(plain && (c.qk_head_dim==512 || c.qk_head_dim==576) &&';a='((plain || e4) && (c.qk_head_dim==512 || c.qk_head_dim==576) &&';assert s.count(b)==1;s=s.replace(b,a)
b='hyle_paged_attention(q,k,v,inputs[3],int(nk)';a='hyle_paged_attention(q,k,v,inputs[mla?2:3],int(nk)';assert s.count(b)==1;s=s.replace(b,a);p.write_text(s,encoding='utf-8',newline='\n')
p=ROOT/'third_party/mlx_cast/NOTICE.md';s=p.read_text(encoding='utf-8');s+='''\nUniform E4 compact MLA reuses the same physical row for CKV512 and its optional\nKPE64 tail; V is a strided alias of the first512 values, with the same scalar\ninterpretation. Original F16/BF16 query precision is retained in the small\nSteel shared-memory tile, while decoded K/V, QK, softmax and PV stay F32. BF16\nquery fragments widen to F32; there is no BF16 cache/probability narrowing.\nThe BQ8/BK8 D576 shared allocation is27,648 bytes with16-bit query storage,\ninstead of36,864 bytes for two F32 tiles, within the actual32KiB Air limit.\n''';p.write_text(s,encoding='utf-8',newline='\n')
(P/'native-source-freeze.json').write_text(json.dumps(dict(status='first_source_freeze_precompile',files=identities,native_owners=['mlx/fast.cpp','mlx/backend/metal/scaled_dot_product_attention.cpp','mlx/backend/metal/jit_kernels.cpp','generated mlx::core::metal::steel_attention()'],query_storage='Original F16/BF16 query only; BF16 shared write uses upper16 original F32-widened raw bits and fragment accumulators F32.',static_shared_bytes={'D512':24576,'D576':27648,'D576_all_F32_rejected':36864,'actual_device_limit':32768}),indent=2)+'\n')
print(json.dumps(identities,indent=2))