from pathlib import Path
import json,hashlib,runpy,xml.etree.ElementTree as E
R=Path.cwd();P=R/'.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference/apple';D=P/'mac/remote';O=D/'results'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def ident(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p.relative_to(R)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
manifest=read(P/'mac/source-manifest.json')
for row in manifest:
 p=P/'native-after'/row['path'].removeprefix('native/') if row['path'].startswith('native/') else R/row['path']
 assert ident(p)['sha256']==row['sha256'],row['path']
records=read(O/'compile-summary.json')['compiles'];assert len(records)==13 and all(x['exit']==0 and not x['source_drifts']for x in records)
cases=E.parse(O/'tests.xml').getroot().findall('.//testcase');neighbors=E.parse(D/'neighbors/tests.xml').getroot().findall('.//testcase');assert len(cases)==4 and len(neighbors)==3
assert all(not x.findall('failure') and not x.findall('skipped')for x in cases+neighbors)
assert all(read(p)['exit']==0 for p in [O/'link.result.json',O/'run.result.json',D/'neighbors/run.result.json'])
owned=['src/compute_route_apple/apple_batch.cc','src/graph_route_apple/native_ragged_region.cc','third_party/mlx_cast/patches.json','third_party/mlx_cast/NOTICE.md']
common=['include/hyle/compute/batch_layout.h','include/hyle/compute/batch_ops.h','src/compute_batch/batch_layout.cc','src/graph_batch/batch.cc','src/graph_batch/native_paged_node.cc','src/graph_batch/native_batch_regions.cc','src/graph_route_apple/native_paged_region.cc','tests/compute_models/compact_mla_e4_fixture.h','tests/graph_route_apple/compact_mla_e4_test.cc','tests/graph_batch/native_ragged_attention_test.cc']
for rel in common:
 p=P/'source'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/rel).read_bytes())
freeze=dict(status='current_Windows_canonical_matches_actual_Mac_overlay',owned=[ident(R/x)for x in owned],shared_and_test_sources=[ident(R/x)for x in common],manifest=ident(P/'mac/source-manifest.json'),canonical_and_native_files=len(manifest),all_manifest_hashes_current=True,native_replay=ident(P/'native-source-freeze.json'),vendor_identity=ident(P/'mlx-vendored-identity.json'),compile_owners=[x['source']for x in records],SDK_rebuilt=False,baseline='e8m0-block128-import-reference/apple actual link command and all input identities verified before compile',ABI_closure='Refresh current Mla capacity value arguments and all actual Apple custom_as/construction owners in this image. New MLX private factory signature definition and caller both refreshed. No old MLX compatibility symbol. CPU-specific new MLA route was not signed by this Apple image.')
save(P/'source-freeze.json',freeze)
def case(x):return dict(name=x.get('classname')+'.'+x.get('name'),properties={p.get('name'):p.get('value')for p in x.findall('./properties/property')})
validation=dict(status='actual_Mac16_12_Metal_pass',source_freeze=ident(P/'source-freeze.json'),hardware=ident(D/'hardware.json'),runtime=ident(D/'runtime-identity.json'),tests=7,new_tests=4,neighbors=3,failed=0,skipped=0,new_successful_submissions=sum(int(case(x)['properties']['successful_submissions'])for x in cases),cases=[case(x)for x in cases],neighbor_cases=[case(x)for x in neighbors],actual_compile_count=13,compiles=[dict(source=x['source'],object=x['object_identity'],exit=x['exit'],dependency_count=len(x['dependencies']),source_drifts=x['source_drifts'])for x in records],actual_commands='mac/remote/results/*command.json; mac/remote/neighbors/run.command.json',link=ident(O/'link.result.json'),run=ident(O/'run.result.json'),gtest=ident(O/'tests.xml'),neighbor_run=ident(D/'neighbors/run.result.json'),neighbor_gtest=ident(D/'neighbors/tests.xml'),
 scope=['Uniform E4 shared scalar0.5 physical rows CKV512 or CKV512+KPE64, BF16 Q/output, one root and strided V512 prefix.','Paged576 and ragged512 general, paged512 Q1 and ragged576 Q1; two slots and epochs, warm/fresh result equality, retained prior output prevents unsafe reuse and stays readable after destruction.','KPE64-sensitive oracle, nonmonotonic/repeated paged IDs, unreferenced NaN, ragged global offset17.','Paged Q1 reports two reused plans. Delegated ragged has no public native-page report; its two updates are marked unreported, with numerical/lifetime/fresh-invocation checks still executed.','Old plain ragged F16/BF16, ordinary separate-scale E4 and Q8 paired/separate pending producer consumer cases passed.'],
 shared_memory=dict(BQ=8,BK=8,D512_query=8192,D512_KV=16384,D512_total=24576,D576_query=9216,D576_KV=18432,D576_total=27648,device_limit=32768,all_F32_D576=36864,proof='Template static arrays and executed D576 PSO; no per-PSO dynamic diagnostic instrumentation added. Original BF16/F16 query is losslessly stored; QK/softmax/PV and decoded KV stay F32.'),
 first_errors=[dict(path='mac/remote/attempt1-raw-paged-and-ragged-admission',cause='Fixture omitted existing arena sentinel byte and original Apple ragged route did not yet recognize new compact MLA operation.'),dict(path='mac/remote/attempt2-common-ragged-mla-rejected',cause='Shared facts validator still rejected all ragged MLA; root removed unjustified hard rejection with schema/geometry/ports checks retained.'),dict(path='mac/remote/attempt3-ragged-port-span',cause='New Apple artifact facts initially exposed full capacity3 instead of its actual2 payload span; fixed locally.'),dict(path='mac/remote/attempt4-ragged-math',cause='Three complete cases pass; final ragged Q1 had completed math but fixture demanded a page report unavailable to existing delegated ragged. Root corrected report probing, with no product report API added.')],
 limitations=['No mixed CKV E4/KPE BF16 or per-token group128 DSA format, model artifact import or end-to-end inference claimed.','No throughput or latency claim; first PSO compilations are not inference measurements.','Apple-specific execution only; retained CPU native objects in this linked image are not evidence of updated CPU MLA admission.'],performance_claim=False)
save(P/'final-validation.json',validation)
f=runpy.run_path(str(R/'.scratch/architecture-refactor-2026-10-18/batch-query-extent/delegated/apple/validate.py'))['ssh'];remote=read(P/'mac/plan.json')['remote']
cleanup=f('''from pathlib import Path
import json,sys,hashlib,subprocess
r=Path(json.load(sys.stdin)['remote'])
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
files=[r/'compact-mla-e4',r/'compact-mla-e4.map'];ps=subprocess.run(['ps','-axo','pid=,command='],capture_output=True,text=True)
v=dict(remote=str(r),root_is_symlink=r.is_symlink(),deletable_files=[identity(x)for x in files if x.is_file()and not x.is_symlink()],retain_objects=[identity(x)for x in sorted((r/'objects').glob('*.o'))],dSYM=[str(x)for x in r.glob('*.dSYM')],process_matches=[x for x in ps.stdout.splitlines()if str(r)in x and 'python3 -c'not in x and '/bin/sh -c'not in x],metallib=dict(path=str(r/'mlx.metallib'),is_symlink=(r/'mlx.metallib').is_symlink(),target=str((r/'mlx.metallib').resolve())),lsof=[],action='Read-only. Root owns evidence packing and test.ps1 cleanup; preserve all incremental objects.')
for x in files:
 p=subprocess.run(['lsof',str(x)],capture_output=True,text=True);v['lsof'].append(dict(path=str(x),exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
print(json.dumps(v))''',dict(remote=remote));save(P/'cleanup-readonly-inventory.json',cleanup)
print(json.dumps(dict(validation=ident(P/'final-validation.json'),freeze=ident(P/'source-freeze.json'),cleanup=ident(P/'cleanup-readonly-inventory.json'),deletable_bytes=sum(x['bytes']for x in cleanup['deletable_files']),retained_object_bytes=sum(x['bytes']for x in cleanup['retain_objects']),process_matches=cleanup['process_matches']),indent=2))
