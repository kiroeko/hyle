from pathlib import Path
import hashlib,json
r=Path.cwd();s=r/'.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference';p=s/'revisions/first-cuda-window';record=json.loads((p/'restore.json').read_text());fixture=r/'tests/compute_models/compact_mla_e4_fixture.h';t=fixture.read_text()
for e in record['inverse_edits']:
 assert t.count(e['old'])==1;t=t.replace(e['old'],e['new'],1)
# The only later lifetime assertion adds exactly the84-byte remaining delta.
a='      if(epoch && index==0 && held[1].valid())EXPECT_EQ(observe(held[1]),saved[1]);\n';assert len(a.encode())==84 and t.count(a)==1
t=t.replace(a,'',1);checks=[];matched=None
for ending in ['LF','CRLF']:
 b=(t if ending=='LF'else t.replace('\n','\r\n')).encode();row={'line_endings':ending,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};row['matches']=row['sha256']==record['expected_dependency']['sha256']and row['bytes']==record['expected_dependency']['bytes'];checks.append(row)
 if row['matches']:matched=b
assert matched is not None,checks
(p/'restore-attempt1.json').write_bytes((p/'restore.json').read_bytes());dst=p/'tests/compute_models/compact_mla_e4_fixture.h';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(matched)
record.update(checks=checks,strict_match_restored=True,extra_inverse_edit={'old':a,'new':'','reason':'Later cross-epoch oldslot assertion is84B, precisely the remaining size delta; strict original SHA verifies the reconstruction.'},restored_source={'path':str(dst),'bytes':len(matched),'sha256':hashlib.sha256(matched).hexdigest()})
(p/'restore.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'match':record['restored_source'],'checks':checks},indent=2))
