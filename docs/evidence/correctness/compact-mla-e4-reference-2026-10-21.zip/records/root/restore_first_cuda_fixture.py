from pathlib import Path
import hashlib,json
r=Path.cwd();s=r/'.scratch/architecture-refactor-2026-10-18/compact-mla-e4-reference';fixture=r/'tests/compute_models/compact_mla_e4_fixture.h'
identity=json.loads((s/'cuda/checks/attempt1/test-identity.json').read_text());expected=next(x for x in identity['dependencies']if x['path'].endswith('compact_mla_e4_fixture.h'))
raw=fixture.read_bytes();t=fixture.read_text();events=[]
def replace(a,b):
 global t
 assert t.count(a)==1,repr(a[:110]);t=t.replace(a,b,1);events.append({'old':a,'new':b})
replace('''        const auto value=lane>=512?float(int(row%5)-2)*.25F:
            float(int((row*5+lane%11)%13)-6)*.0625F;
        const auto code=exact?std::uint8_t{3}:paged_e4_kv_test::encode(value,scale);''','''        const auto code=exact?std::uint8_t{3}:paged_e4_kv_test::encode(
            float(int((row*5+lane%11)%13)-6)*.0625F,scale);''')
replace('''      query[(t*heads+h)*depth+lane]=scalar::bf16(lane>=512?.25F*float((h+t)%3+1):
          float(int((h+t+lane)%7)-3)*.0625F);''','''      query[(t*heads+h)*depth+lane]=scalar::bf16(float(int((h+t+lane)%7)-3)*.0625F);''')
replace('oracle(unsigned epoch,bool wrong_scale=false,bool omit_kpe=false)','oracle(unsigned epoch,bool wrong_scale=false)')
replace('lane<(omit_kpe?std::min(depth,512u):depth)','lane<depth')
replace('''    if(depth==576 && !exact) {
      const auto omitted=shape.oracle(epoch,false,true);float kpe_witness=0;
      for(std::size_t i=0;i<expected.size();++i)kpe_witness=std::max(kpe_witness,std::abs(scalar::wide(expected[i])-scalar::wide(omitted[i])));
      ASSERT_GT(kpe_witness,.016F)<<"fixture must detect dropping all64 KPE lanes";
    }
''','')
replace('''         m::MemoryResourceRef host_workspace=m::system_resource(),bool exact=false,
         bool require_plan_reuse=true)''','''         m::MemoryResourceRef host_workspace=m::system_resource(),bool exact=false)''')
replace('unsigned submissions=0,reused_plans=0,cold_replans=0;','unsigned submissions=0;')
replace('''        const bool reused=common?common->reused_native_plan:take(g::batch::native_report(slot,shape.node),"native Q1 report").reused_native_plan;
        if(require_plan_reuse)EXPECT_TRUE(reused);
        reused?++reused_plans:++cold_replans;''','''        EXPECT_TRUE(common?common->reused_native_plan:take(g::batch::native_report(slot,shape.node),"native Q1 report").reused_native_plan);''')
replace('''  ::testing::Test::RecordProperty("q1_reused_plans",int(reused_plans));
  ::testing::Test::RecordProperty("q1_cold_replans",int(cold_replans));
''','')
checks=[];matched=None
for ending in ['LF','CRLF']:
 b=(t if ending=='LF' else t.replace('\n','\r\n')).encode();h=hashlib.sha256(b).hexdigest();checks.append({'line_endings':ending,'bytes':len(b),'sha256':h,'matches':h==expected['sha256']and len(b)==expected['bytes']})
 if checks[-1]['matches']:matched=b
out=s/'revisions/first-cuda-window';out.mkdir(parents=True,exist_ok=True)
record={'kind':'bounded inverse of known KPE-witness and native-reuse-report fixture edits','expected_dependency':expected,'current_fixture':{'path':str(fixture),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'checks':checks,'replacement_count':len(events),'strict_match_restored':matched is not None,'inverse_edits':events}
if matched is not None:
 dst=out/'tests/compute_models/compact_mla_e4_fixture.h';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(matched);record['restored_source']={'path':str(dst),'bytes':len(matched),'sha256':hashlib.sha256(matched).hexdigest()}
assert raw==fixture.read_bytes()
(out/'restore.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'strict_match_restored':matched is not None,'checks':checks,'record':str(out/'restore.json')},indent=2))
