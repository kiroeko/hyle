from pathlib import Path
P=Path(__file__).resolve().parents[1];R=P.parents[2]
for arm,label in [('cpu','Cpu'),('cuda','Cuda'),('vulkan','Vulkan'),('apple','Apple')]:
 directory=R/f'tests/graph_route_{arm}'
 old=(directory/'paged_e4_kv_test.cc').read_text(encoding='utf8')
 prefix=old.split('TEST(',1)[0].replace('paged_e4_kv_fixture.h','compact_mla_e4_fixture.h').replace('paged_e4_kv_test','compact_mla_e4_test')
 definitions=[]
 for name,depth,paged,single in [('PagedRope64SharesScaleAndOldResults',576,True,False),
  ('RaggedNoPeSharesScaleAndOldResults',512,False,False),('PagedNoPeQ1GrowsThroughOriginalPlan',512,True,True),
  ('RaggedRope64Q1GrowsThroughOriginalPlan',576,False,True),*([('OriginalF32ScalePrecedesBfloatTileRounding',512,True,True)] if arm=='cuda' else [])]:
  tail='' if arm=='cpu' else ',auto workspace' if arm=='cuda' else ',auto'
  arguments=f'resource,queues,compile,write,read,{depth},{str(paged).lower()},{str(single).lower()}'
  if arm=='cuda':arguments+=',workspace'+(',true' if name.startswith('Original') else '')
  definitions.append(f'TEST({label}CompactMlaE4, {name}) {{\n  run_{arm}([](auto resource,auto queues,auto compile,auto write,auto read{tail}) {{\n    compact_mla_e4_test::run({arguments});\n  }});\n}}\n')
 (directory/'compact_mla_e4_test.cc').write_text(prefix+'\n'.join(definitions),encoding='utf8')
 cm=directory/'CMakeLists.txt';s=cm.read_text(encoding='utf8');old='e8m0_weight_import_test.cc'
 assert s.count(old)==1 and 'compact_mla_e4_test.cc' not in s
 before=P/'root/before'/cm.relative_to(R);before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(cm.read_bytes())
 cm.write_text(s.replace(old,old+' compact_mla_e4_test.cc'),encoding='utf8')
