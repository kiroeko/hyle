from pathlib import Path
P=Path(__file__).resolve().parents[1];R=P.parents[2]
p=R/'docs/developer/current-work.md';s=p.read_text(encoding='utf8')
replacements={
 '普通分页 E4 KV 和 E8M0 block128 冷导入已补四后端；下一项 compact MLA，另有精确 producer 余项':
 '普通分页 E4 KV、E8M0 block128 冷导入和 uniform compact MLA E4 已补四后端；下一项 Inferact micro32 的精确 producer 合同与余项',
 '下一项compact MLA，随后精确producer余项':'下一项Inferact micro32的精确producer合同与余项',
 '**接下来**：compact MLA的CKV/KPE物理布局、scalar绑定与FlashInfer域；':
 'uniform compact MLA E4的[18项新增与10项邻居](../evidence/correctness/compact-mla-e4-reference-2026-10-21.json)已通过；',
 '剩余接线包括compact MLA具体物理布局／scale绑定，不能由普通页读取推导具体制品KV链已接通。':
 'compact MLA的uniform E4也已接通；具体制品的精确producer／scalar绑定仍分开记录。'}
for old,new in replacements.items():
 if old in s:s=s.replace(old,new)
old=s[s.index('**当前下一动作**'):s.index('\n专门的 [decode 性能规划]')]
new='''**当前下一动作**：核Inferact U8／F32 micro32的producer码序、activation与macro合同，按精确角色补余项；不套Quark W4A4。
uniform compact MLA E4已接CPU、CUDA、Vulkan、Apple的原paged/ragged路径，缓存512／576字节一行、V同根前512项。
[18项新增与10项相邻回归](../evidence/correctness/compact-mla-e4-reference-2026-10-21.json)通过，无跳过；其中18项包含16个四端Graph、1个CUDA精确scale见证和1个CPU schema检查。
原ModelOpt QDQ与runtime缓存格式的归因保留在[来源复核](../evidence/research/compact-mla-e4-contract-2026-10-21.json)。
CUDA完整kernel在4070实跑，576维共享内存99KiB；Apple用无损原Q存储使共享tile降至27KiB。
原CUDA MLA增长KV仍需冷重规划；原生GPU delegated ragged无公开page-plan报告，只签warm/fresh与寿命，不宣称无冷重规划。
动态per128 scale＋BF16 KPE的656／528字节DSA另合同；本包未验新E4 capture、精确制品payload／全模型、Linux、质量或吞吐。
'''
s=s.replace(old,new.rstrip());p.write_text(s,encoding='utf8')
p=R/'docs/implementation/model-operators.md';s=p.read_text(encoding='utf8')
old='剩余接线包括compact MLA具体物理布局／scale绑定，不能由普通页读取推导具体制品KV链已接通。'
assert old in s;s=s.replace(old,'uniform compact MLA E4也已四端接通；具体制品的精确producer／scalar绑定仍分开记录。')
row='| compact MLA E4；共享CKV512／KPE64与V前缀 | `MlaBatchCapacity`分开Q／输出类型和一个共享`CacheStorage`，沿四端原paged/ragged读者补uniform E4；V同根前512项，不展开V或整缓存。CUDA保Q64调度、E4 KV16与F32 scale后BF16 RNE；Apple保F32计算并缩小Q共享存储。[18项新增与10项邻居](../evidence/correctness/compact-mla-e4-reference-2026-10-21.json)通过，含KPE错省略见证、warm/fresh与真实旧结果 | BF16 Q／输出有界参考；CUDA KV增长沿原cold replan，native delegated ragged无page-report不签无重规划。未签mixed DSA656／528、具体制品payload、Linux、质量、吞吐或新capture；独立Q／输出schema也不代表所有执行组合 |\n'
anchor='| 普通分页E4 KV；独立固定K/V scale |';i=s.index(anchor);end=s.index('\n',i)
s=s[:end+1]+row+s[end+1:];p.write_text(s,encoding='utf8')
