from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parents[1];R=P.parents[2]
p=R/'cmake/HyleDependencyLock.json';before=p.read_bytes();d=json.loads(before)
saved=P/'root/dependency-lock-before-root.json'
if not saved.exists():saved.write_bytes(before)
vk=json.loads((P/'vulkan/dependency-entry-proposal.json').read_text())
mlx=json.loads((P/'apple/mlx-vendored-identity.json').read_text())
updates={vk['entry']:(vk['canonical_tree_sha256'],vk['NOTICE_normalized_sha256']),
 mlx['name']:(mlx['tree_sha256'],next(x['normalized_sha256'] for x in mlx['files'] if x['path']=='NOTICE.md'))}
for entry in d['dependencies']:
 if entry['name'] not in updates:continue
 tree,notice=updates[entry['name']];entry['vendored']['tree_sha256']=tree
 for row in entry['license']['files']:
  if row['path'].endswith('/NOTICE.md'):row['sha256']=notice
 if entry['name']=='mlx_cast_patches':entry['version']='hyle-apple-native-patches-v6'
s=json.dumps(d,ensure_ascii=False,indent=2)+'\n'
if b'\r\n' in before:s=s.replace('\n','\r\n')
p.write_bytes(s.encode('utf8'))
(P/'root/check-lock.cmake').write_text('include("'+(R/'cmake/HyleDependencyVersions.cmake').as_posix()+'")\nhyle_audit_in_tree_dependencies(flashinfer_cache_patches ggml_vulkan_runtime_patches mlx_cast_patches)\n')
print(updates)
