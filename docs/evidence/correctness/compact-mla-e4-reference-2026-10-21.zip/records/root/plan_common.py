from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
spec=importlib.util.spec_from_file_location('mla_common_build',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
bases={arm:A/f'e8m0-block128-import-reference/{arm}/checks/link1/link-plan.json' for arm in ['cpu','cuda','vulkan']}
plans={a:c.read(p) for a,p in bases.items()};metadata=h.metadata(plans)
changed={c.key(R/p) for p in ['src/compute_batch/batch_layout.cc','src/graph_batch/batch.cc',
 'src/graph_batch/native_paged_node.cc','src/graph_route_apple/native_paged_region.cc',
 'src/graph_route_vulkan/native_paged_region.cc','src/compute_provider_ggml/native_batch.cc',
 'src/graph_batch/native_batch_regions.cc']}
objects={}
for arm,plan in plans.items():
 for row in plan['inputs']:
  if Path(row['path']).suffix.lower()!='.obj':continue
  entry=objects.setdefault(c.key(row['path']),dict(old_object=row,arms=[]));entry['arms'].append(arm)
rows=[];unresolved=[]
for key,entry in objects.items():
 m=metadata.get(key)
 if not m:
  unresolved.append(entry);continue
 source=Path(m['source_path'])
 if c.key(source) not in changed:continue
 rows.append(dict(**entry,source=b.identity(source),recipe=m['recipe'],command=m['command']))
out=P/'root/common-plan.json';c.save(out,dict(bases={a:b.identity(p) for a,p in bases.items()},owners=rows,
 unresolved_objects=unresolved,policy='Refresh actual product constructors/extractors of changed MLA inline descriptor plus changed schema/CPU leaf; unchanged SDK/ordinary math reused.'))
print(json.dumps(dict(plan=str(out),owners=[dict(source=x['source']['path'],arms=x['arms'],object=x['old_object']['path']) for x in rows],unresolved=len(unresolved)),ensure_ascii=False))
