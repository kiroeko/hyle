from pathlib import Path
import re,json
P=Path(__file__).resolve().parents[1];R=P.parents[2]
files=['tests/compute_provider_flashinfer/ragged_mla_test.cc',
 'tests/graph_route_vulkan/native_region_test.cc',
 'tests/compute_batch/public_mla_cpu_consumer.cc','tests/compute_batch/public_mla_pending_cuda_consumer.cc',
 'tests/compute_batch/public_mla_native_consumer.cc','tests/compute_batch/public_mla_cuda_consumer.cc',
 'tests/compute_batch/public_mla_pending_graph_cuda_consumer.cc','docs/user/batch-attention.md']
changed=[]
for name in files:
 p=R/name;s=p.read_text(encoding='utf8')
 before=P/'root/before'/name;before.parent.mkdir(parents=True,exist_ok=True)
 if not before.exists():before.write_bytes(p.read_bytes())
 qualifier='' if name.startswith('docs/') else 'c::'
 def update(match):
  t=match.group(1).strip()
  return f'.query_type={t}, .output_type={t}, .cache_storage={qualifier}CacheStorage::plain({t}).value(),'
 result,n=re.subn(r'\.data_type\s*=\s*([^,\n]+),',update,s)
 assert n>=1 or '.cache_storage=' in s,(name,n)
 p.write_text(result,encoding='utf8');changed.append(dict(path=name,replacements=n))
(P/'root/migrated-callers.json').write_text(json.dumps(changed,indent=2)+'\n')
print(changed)
