from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1];A=P.parent;R=A.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def resolve(p):
 p=Path(p);return p if p.is_absolute() else R/p
def check(row):
 p=resolve(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
cases=set();records=[];submissions=0
for arm,window in [('cpu','final3'),('cuda','final2'),('vulkan','final1')]:
 receipt=P/arm/'validation'/window/'receipt.json';d=read(receipt)
 assert d['passed'] and not d['failed'] and not d['skipped'];check(d['xml']);check(d['image']);check(d['link_plan'])
 xml=ET.parse(resolve(d['xml']['path'])).findall('.//testcase')
 names=[x.get('classname')+'.'+x.get('name') for x in xml]
 assert names==d['names'] and all(x.find('failure') is None and x.find('skipped') is None for x in xml)
 cases.update((arm,n) for n in names);records.append(dict(backend=arm,receipt=ident(receipt),names=names))
 submissions+=sum(int(p['value']) for x in d['properties'] if 'CompactMlaE4.' in x['case'] for p in x['properties'] if p['name']=='successful_submissions')
applepath=P/'apple/final-validation.json';apple=read(applepath)
assert apple['tests']==7 and apple['failed']==apple['skipped']==0
for key in ['gtest','neighbor_gtest']:
 check(apple[key]);xml=ET.parse(resolve(apple[key]['path'])).findall('.//testcase')
 assert xml and all(x.find('failure') is None and x.find('skipped') is None for x in xml)
 cases.update(('apple',x.get('classname')+'.'+x.get('name')) for x in xml)
submissions+=apple['new_successful_submissions']
new={x for x in cases if 'CompactMlaE4.' in x[1]}
assert len(new)==18 and len(cases)==28 and submissions==77
sources={'include/hyle/compute/batch_layout.h','include/hyle/compute/batch_ops.h',
 'src/compute_batch/batch_layout.cc','src/compute_provider_ggml/native_batch.cc',
 'src/graph_batch/batch.cc','src/graph_batch/native_paged_node.cc','src/graph_batch/native_batch_regions.cc',
 'src/graph_route_vulkan/native_paged_region.cc',
 'tests/compute_models/compact_mla_e4_fixture.h','tests/compute_models/paged_e4_kv_fixture.h',
 'tests/compute_models/nvfp4_reference_fixture.h','cmake/HyleDependencyLock.json',
 'docs/developer/current-work.md','docs/user/batch-attention.md','docs/user/apple-compute.md',
 'docs/user/vulkan-compute.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json'}
for row in read(P/'root/migrated-callers.json'):sources.add(row['path'])
for row in read(P/'vulkan/source-freeze.json')['sources']:
 source=row['source'];p=resolve(source['path'])
 if p.is_relative_to(R/'src') or p.is_relative_to(R/'third_party'):
  check(source);sources.add(p.relative_to(R).as_posix())
af=read(P/'apple/source-freeze.json')
for row in [*af['owned'],*af['shared_and_test_sources']]:
 check(row);sources.add(resolve(row['path']).relative_to(R).as_posix())
for row in read(P/'cuda/product-objects-final.json')['replacements']:
 check(row['source']);sources.add(resolve(row['source']['path']).relative_to(R).as_posix())
sources.update(['third_party/flashinfer_cache/patches.json','third_party/flashinfer_cache/NOTICE.md',
 'third_party/ggml_vulkan_runtime/patches.json','third_party/ggml_vulkan_runtime/NOTICE.md'])
for arm in ['cpu','cuda','vulkan','apple']:
 sources.update(f'tests/graph_route_{arm}/{n}' for n in ['compact_mla_e4_test.cc','CMakeLists.txt'])
entries={'source/'+s:R/s for s in sorted(sources)}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cuh','.cpp','.c','.md','.cu','.d','.metal','.cmake','.sass'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
archive=R/'docs/evidence/correctness/compact-mla-e4-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='four_backend_bounded_uniform_compact_MLA_E4_reference_passed',
 architecture='MlaBatchCapacity separates query_type/output_type from one scalar CacheStorage; no old data_type compatibility field. Existing schema/Graph compile/Invocation/layout/Completion/result retirement retained. One original physical CKV512(+KPE64) bank, V is its exact same-root512prefix with512/576 rowpitch; no separateVbank/fullcache floating expansion/newexecutor.',
 math='BF16Q/Y, uniformE4 cache with sharedpositiveF32scale. CPUboxed/VulkanFullF32/AppleSteel address referenced E4 values and scale inF32. CUDA boundedtile multiplies originalF32scale then BF16RNE; originalQK/PV F32acc and BF16probabilitytile/F32partials+merge retained. Final BF16 tolerance0.008 against independentFP64 oracle; no arbitraryscale bitwise crossbackend equivalence claim.',
 regression=dict(new_cases=18,neighbors=10,final_backend_scoped_cases=28,failed=0,skipped=0,windows=records,apple=ident(applepath),
  new_names=[dict(backend=a,name=n) for a,n in sorted(new)],neighbor_names=[dict(backend=a,name=n) for a,n in sorted(cases-new)],
  counting='16fourbackendGraphcases +1CUDAexactscaleGraph +1CPU schema-only. Neighbors2CPU/plain+Q8,1CUDAplainMLA,4Vulkan/Q8+ordinaryE4,3Apple/plainragged+Q8+ordinaryE4. Earlier diagnosticCPUextra cases retained but not counted in final28.',
  successful_new_Graph_submissions=submissions,
  fixture='Heads64, CKV512/576, page16/5physicalpages, requestQ1+3/general andfixedQ1; repeated/nonmonotonic{2,0,1,0}, histories17/23->17/31 andQ1 17->31, inactiveNaNs, raggedglobaloffset17. Two independent slots/epochs, thirdfreshQ1, realGraphOutput observer plusReadLease, cross-epoch otheroldslot readable, results survive destruction.',
  oracle='LiteralE4 decode and independentFP64 QK/softmax/PV/finalBF16. Wrongsharedscale changesoutput>0.01; omittingKPE64 changesoutput>0.016, twice0.008 tolerance. CUDA oneKV E4code3 and originalF32scale0x3f805586 must give everyBF16output0x3bc1, not earlyBF16scale0x3bc0.',
  plan_observability='CPUQ1 paged/ragged and Apple/Vulkanpaged reused2percase. OriginalCUDAMLA KVlengthchange coldreplans2pergrowthcase; equal-length exactscale case reused2. DelegatedApple/Vulkanragged lacks publicpage-plan report, recordsunreported2; warm/fresh andlifetime execute fully, no no-replan claim.'),
 product_fixes=['Public compact capacity separates Q/output/cache interpretation; blockedcache rejected by scalar physicalschema. Paged/Ragged computeMLA OpID suffix0003, oldcallers migrated, no compatibility overload.',
  'CPU highdimE4 qualification uses existing boxedF32 row decoder and original stridedVprefix, no vendor CPUmath change.',
  'CUDA canonicalFlashInfer E4SharedStorage removes512B deadnonsharded crosswarpstate; one-stageKV16 keepsQ64/256threads/scheduler. Rope64 sizeof101376B(99KiB), NoPE91296B; originalplain16 geometry/layout retained. Full nativeMLA templates compiled and actual4070 execution passed.',
  'Canonical scheduler already-locked no-split bookkeeping guard is now present in actual native include closure; currentbefore/after manifest scheduler math unchanged. OriginalMLA KVlength/work/split/merge metadata stays cold-baked.',
  'Vulkan exact private single-root/pitch/offset/sharedscale wideE4 qualification; originalFullF32 tile shader/SPIRV reused. Originalragged family gains2payloadMLA plusmetadata and stridedVprefix, no equivalentpage table.',
  'Apple fixesMLA metadata index2 versusordinary3, admitsuniform highdimE4, uses lossless originalQ sharedstorage withF32 fragments/KV/softmax/PV. Actual576 tile27648B<32768B versus36864BallF32;512tile24576B. Originalraggedfamily gains singlebank route.',
  'Common delegatedfacts removes arbitraryragged MLA prohibition; exactmetadata/portcount/capacity/schema/layout checks still precede nativeprepare. No common executor or policy duplication.'],
 failures_retained=['Apple firstfixture omitted existing arena onebyte sentinel; fixedtestbudget only. First raw3portpagedfixture switched to existingowned2payload publicGraph route.',
  'RaggedApple/Vulkan real missing nativeoperation/codec wiring fixed through originalfamilies; then sharedfacts hardreject removed while exactschema checks retained.',
  'Apple newraggedfacts first exposed capacity3 span rather than real2payload span; correctedlocally.',
  'CUDA firstwindow allmath/lifetime/3bc1 passed but2Q1cases failed test-only universalreuse assumption. Actual originalscheduler requirescoldreplan; observedreport recorded, numericthreshold unchanged. Exactfirstfixture restored bySHA.',
  'Delegatedragged reportprobe first requested unavailablepage report. Fixedtestobservability torecordunreported without addingproductAPI; allnumeric/warmfresh/lifetimechecks retained.',
  'KPE sensitivity source review found originalinput couldmiss omitted64lanes within tolerance; existing576data strengthened andexplicitwrongoracle witness added, no tolerancechange/newcase.'],
 limits=['Uniformscalar compactE4 only; no dynamicgroup128scales/mixedBF16KPE DSA656/528 format, allgeometry/device orIEEEscale execution domain acceptance.',
  'Newfourbackendexecution BF16Q/Y; mixedquery/output schema-only test does not establish mixedexecution. Originalplainneighbors are separate actualcases.',
  'No explicitRequireCapture/newE4capture acceptance, pairedE4pendingproducer chain, publisherweightpayload/exactexporterbinding, wholemodel, Linux, quality or throughput acceptance.',
  'Globalcompressedbank remains originalbytes. Boundednative/opaque allocation totals and largecache/buffer-limit performance are not measured by this reference.',
  'Goal remains active: capabilitypackage8 has preciseproducer residuals and3deliverypackages still remain.'],
 dependency_audit=ident(P/'root/lock-audit.json'),independent_reviews=[ident(P/'root/final-fixture-source-review.json'),ident(P/'vulkan/fixture-source-review.json'),ident(P/'cuda/runtime-source-review.json')],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],current_sources=len(sources),new_cases=18,neighbors=10)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
