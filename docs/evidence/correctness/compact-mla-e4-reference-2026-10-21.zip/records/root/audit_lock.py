from pathlib import Path
import importlib.util,sys,os
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parents[1];A=P.parent
spec=importlib.util.spec_from_file_location('compact_lock_audit',A/'grouped-shared-activation/build_host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
out=P/'root/lock-audit';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
command=['cmake','-P',str(P/'root/check-lock.cmake')]
env=dict(os.environ,TMP=str(out/'tmp'),TEMP=str(out/'tmp'));c.execute('audit',command,env,out)
c.save(P/'root/lock-audit.json',dict(command=command,exit=0,
 lock=b.identity(A.parents[1]/'cmake/HyleDependencyLock.json'),entries=['flashinfer_cache_patches','ggml_vulkan_runtime_patches','mlx_cast_patches']))
