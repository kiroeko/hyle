include("C:/public/project-hyle/hyle/cmake/HyleDependencyVersions.cmake")
hyle_audit_in_tree_dependencies(flashinfer_cache_patches ggml_vulkan_runtime_patches mlx_cast_patches)
