"""Compile one native prefix probe TU over retained Apple library caches."""
from pathlib import Path
import argparse, base64, importlib.util, json, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('aq_apple_cached',R/'.scratch/qwen-retained-budget-20261022/apple.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
m=h.m;ROOT=m.BASE+'/qwen-native-protocol-20261022'

def build(revision):
    remote=ROOT+'/prefix'+str(revision);m.REMOTE=remote
    source='tools/qwen35_text/mtp_session_probe.cc'
    row=next(x for x in json.loads((R/'.scratch/native-paged-effects-20261022/apple/mac-cached-closure.json').read_bytes())['compile']if x['file'].endswith('/src/graph_route_apple/native_region.cc'))
    obj=remote+'/consumer.o';command=m.overlay_command(row,source,obj)
    files=[]
    for path in m.include_closure([source],[command]):
        entry=m.ident(path);entry['path']=path.relative_to(R).as_posix();entry['data']=base64.b64encode(path.read_bytes()).decode();files.append(entry)
    core=json.loads((R/'.scratch/native-state-ownership-20261022/apple-core2-plan.json').read_bytes())['libraries']
    link=json.loads((R/'.scratch/qwen-native-assembly-20261022/apple/revision4.json').read_bytes())['records'][1]['command']
    link=[obj if x==h.AJ+'/revision4/main.o'else next((lib['path']for lib in core if x==lib['old']),x)for x in link]
    image=remote+'/probe';link[link.index('-o')+1]=image
    payload=dict(remote=remote,sdk=m.SDK,files=files,actions=[['compile',command],['link',link]],image=image,metallib=h.AJ+'/mlx.metallib')
    m.save(S/f'apple-prefix{revision}-plan.json',{**payload,'files':[{k:v for k,v in x.items()if k!='data'}for x in files]})
    result=m.ssh(r'''
from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['remote']);root.mkdir(parents=True);source=root/'source';source.mkdir()
for x in p['files']:
 target=source/x['path'];target.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(x['data']);assert len(raw)==x['bytes']and hashlib.sha256(raw).hexdigest()==x['sha256'];target.write_bytes(raw)
hardware={x:subprocess.check_output(['/usr/sbin/sysctl','-n',x],text=True).strip()for x in ['hw.model','hw.memsize']};assert hardware['hw.model']=='Mac16,12'
records=[]
for action,argv in p['actions']:
 record=dict(command=argv,cwd=p['sdk']+'/build',started=time.time())
 with(root/(action+'.stdout.log')).open('wb')as so,(root/(action+'.stderr.log')).open('wb')as se:
  child=subprocess.Popen(argv,cwd=record['cwd'],env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
 record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(root/(action+'.result.json')).write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 if child.returncode:break
result=dict(records=records,hardware=hardware,all_exit_zero=len(records)==len(p['actions'])and all(x['exit']==0 for x in records))
if result['all_exit_zero']:
 os.link(p['metallib'],root/'mlx.metallib');image=Path(p['image']);raw=image.read_bytes();result['image']=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
else:result['stderr']=(root/(p['actions'][len(records)-1][0]+'.stderr.log')).read_text(errors='replace')
(root/'ready.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
''',payload,timeout=240)
    m.save(S/f'apple-prefix{revision}.json',result)
    print(json.dumps(dict(all_exit_zero=result['all_exit_zero'],image=result.get('image'),records=[dict(exit=x['exit'],pid=x['pid'],seconds=x['seconds'])for x in result['records']],stderr=result.get('stderr'))),flush=True)
    if not result['all_exit_zero']:raise SystemExit(1)

def run(revision,attempt):
    image=json.loads((S/f'apple-prefix{revision}.json').read_bytes())['image']
    inputs=m.BASE+'/qwen-native-assembly-20261022/inputs/mtp'
    # The old-prefix probe requires the original first23 token fixture. Keep
    # the same existing weight manifest and write only those existing IDs.
    prompt=R/'.scratch/qwen-mtp-weights-20261022/prepared/prompt.ids'
    payload=dict(root=ROOT,folder=f'prefix-run{attempt}',image=image,inputs=inputs,sdk=m.SDK,prompt=prompt.read_text(),prompt_identity=m.ident(prompt))
    result=m.ssh(r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p['root']);out=root/p['folder'];out.mkdir()
inputs=out/'inputs';inputs.mkdir();(inputs/'weights.tsv').write_bytes((Path(p['inputs'])/'weights.tsv').read_bytes());(inputs/'prompt.ids').write_text(p['prompt'])
image=Path(p['image']['path']);assert hashlib.sha256(image.read_bytes()).hexdigest()==p['image']['sha256']
command=[str(image),'--inputs',str(inputs),'--scenario','prefix','--output',str(out/'vectors')]
record=dict(command=command,cwd=str(image.parent),image=p['image'],started=time.time(),performance_comparison=False,prompt=p['prompt_identity'])
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
 child=subprocess.Popen(command,cwd=image.parent,env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',DYLD_LIBRARY_PATH=p['sdk']+'/relocated/sdk/lib'),stdout=so,stderr=se);record.update(pid=child.pid,state='running');(out/'command.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n');child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');(root/'live.json').write_text(json.dumps(record,indent=2)+'\n')
result=dict(record=record,stdout=(out/'stdout.log').read_text(errors='replace'),stderr=(out/'stderr.log').read_text(errors='replace'))
if(out/'vectors/observation.json').is_file():result['report']=json.loads((out/'vectors/observation.json').read_bytes())
print(json.dumps(result))
''',payload,timeout=1800)
    m.save(S/f'apple-prefix-run{attempt}.json',result)
    if result['record']['exit']:
        print(result['stderr'][-6500:]);raise SystemExit(1)
    report=result['report'];keys=['status','actual_graph_calls','full_hits','full_hit_head_vectors','old_prefix_full_byte_checks','peak_live_snapshot_versions','final_live_snapshot_versions','all_vectors_byte_equal','all_finite','negative_rejected','negative_bound_banks','retry_same_carrier_slot','peak_retained_output_backing_bytes']
    summary={k:report[k]for k in keys};summary.update(vector_comparisons=len(report['vectors']),cache={k:v for k,v in report.items()if k.startswith('cache_')},quality_pass=False,performance_comparison=False)
    m.save(S/f'apple-prefix-run{attempt}-summary.json',summary)
    assert report['status']=='PASS_BYTE_EXACT'and report['all_vectors_byte_equal']and report['all_finite']
    assert report['actual_graph_calls']==15 and report['full_hits']==3 and report['full_hit_head_vectors']==156 and report['final_live_snapshot_versions']==0
    assert report['negative_rejected']and report['negative_bound_banks']==14 and report['retry_same_carrier_slot']
    print(json.dumps(summary),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['build','run']);p.add_argument('--revision',type=int,default=1);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
    build(a.revision)if a.action=='build'else run(a.revision,a.attempt)
