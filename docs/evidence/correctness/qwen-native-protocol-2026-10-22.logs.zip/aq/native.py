"""Current two-TU Vulkan cancellation overlay, without rebuilding its SDK."""
from pathlib import Path
import importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('aq_native_cached',S/'build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c,h=m.b,m.c,m.h;h.S=S
recipes={
 'vulkan-run':R/'.scratch/architecture-refactor-2026-10-18/mlx-moe-typed-inputs/vulkan/checks/compute_route_vulkan-vulkan_run-identity.json',
 'vulkan-iree':R/'.scratch/architecture-refactor-2026-10-18/quark-block128-scale-2026-10-21/vulkan/windows/checks/attempt1/iree/identity.json',
}
for tag,recipe in recipes.items():
 original=c.read(recipe);original['command']=[{'-MD':'/MD','-O2':'/O2'}.get(x,x)for x in original['command']]
 prepared=S/'recipes'/f'{tag}.json';c.save(prepared,original)
 h.RECIPES[tag]=prepared;h.SOURCES[tag]=R/('src/compute_route_vulkan/'+tag.replace('-','_')+'.cc');h.compile_one(tag,1)
base=S/'vulkan-retirement-link3';plan=c.read(base/'link-plan.json');replacements={}
for tag,recipe in recipes.items():
 old=c.read(recipe)['object'];record=c.read(S/f'compile1/{tag}/identity.json')
 assert all(b.identity(x['path'])==x for x in [record['source'],record['object'],*record['dependencies']])
 assert sum(c.key(x['path'])==c.key(old['path'])for x in plan['inputs'])==1
 replacements[c.key(old['path'])]=record['object']
inputs=[replacements.get(c.key(x['path']),x)for x in plan['inputs']]
for x in inputs:assert b.identity(x['path'])==x
out=S/'vulkan-retirement-link6';out.mkdir();(out/'tmp').mkdir();image=out/'probe.exe'
command=[replacements.get(c.key(x),{'path':x})['path']for x in plan['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,SDK_builds=0,NVCC=0,shaders=0,temporary_diagnostic=False))
env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
runtime=c.read(base/'runtime-environment.json');c.save(out/'runtime-environment.json',runtime)
for x in runtime.get('staged_dlls',[]):
 path=Path(x['path'])
 if not(out/path.name).exists():os.link(path,out/path.name)
c.save(out/'ready.json',dict(image=b.identity(image)));print('LINKED current native Vulkan cancellation',flush=True)
