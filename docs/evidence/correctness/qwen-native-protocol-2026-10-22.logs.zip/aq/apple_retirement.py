"""Plan/build two Apple retirement host TUs over AQ's proven cached closure.

The plan action is local only. Build/run are explicit root-owned SSH actions.
Apple's instrument proves an accepted Model Job in its original Runtime FIFO;
it does not prove that the Model's GPU commands have been submitted.
"""
from pathlib import Path
import argparse
import base64
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
spec = importlib.util.spec_from_file_location("aq_apple_prefix", S / "apple.py")
cached = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cached)
m = cached.m
ROOT = m.BASE + "/qwen-native-protocol-20261022"
PREFIX_PLAN = S / "apple-prefix1-plan.json"
PROMPT = R / ".scratch/qwen-mtp-weights-20261022/prepared/prompt.ids"
MODEL_ADMISSION_PROOF = "original_fifo_accepted_job"


def payload_for(revision):
    remote = ROOT + "/retirement" + str(revision)
    m.REMOTE = remote
    original = json.loads(PREFIX_PLAN.read_bytes())
    assert original["sdk"] == m.SDK
    rows = json.loads(
        (R / ".scratch/native-paged-effects-20261022/apple/mac-cached-closure.json").read_bytes()
    )["compile"]
    row = next(x for x in rows if x["file"].endswith("/src/graph_route_apple/native_region.cc"))
    sources = ["tools/qwen35_text/retirement_probe.cc", "tools/qwen35_text/native_gate_apple.mm"]
    objects = [remote + "/consumer.o", remote + "/native_gate.o"]
    commands = [m.overlay_command(row, source, obj) for source, obj in zip(sources, objects)]
    # Match the original cached .mm language mode. No ARC or blocks policy is
    # introduced; retain the same arm64, deployment target and SDK includes.
    commands[1][1:1] = ["-x", "objective-c++"]
    files = []
    for path in m.include_closure(sources, commands):
        entry = m.ident(path)
        entry["path"] = path.relative_to(R).as_posix()
        entry["data"] = base64.b64encode(path.read_bytes()).decode()
        files.append(entry)
    assert all(any(x["path"] == source for x in files) for source in sources)
    assert any(x["path"] == "src/compute_route_apple/apple_runtime_internal.h" for x in files)
    compile_template = next(argv for action, argv in original["actions"] if action == "compile")
    old_object = compile_template[compile_template.index("-o") + 1]
    old_link = next(argv for action, argv in original["actions"] if action == "link")
    assert old_link.count(old_object) == 1
    link = []
    for word in old_link:
        link.extend(objects if word == old_object else [word])
    image = remote + "/probe"
    link[link.index("-o") + 1] = image
    frameworks = [link[i + 1] for i, word in enumerate(link[:-1]) if word == "-framework"]
    assert {"Foundation", "Metal", "MetalKit", "QuartzCore"} <= set(frameworks)
    payload = dict(
        remote=remote, sdk=m.SDK, files=files,
        actions=[["compile-consumer", commands[0]], ["compile-gate", commands[1]], ["link", link]],
        image=image, metallib=original["metallib"],
        cached_plan=m.ident(PREFIX_PLAN), source_TUs=sources, CXX_TUs=1, OBJCXX_TUs=1,
        SDK_builds=0, shaders=0, model_copies=0,
        model_admission_proof=MODEL_ADMISSION_PROOF, model_gpu_submission_proven=False,
        run_template=[
            image, "--inputs", ROOT + "/prefix-run1/inputs", "--mtp", "on", "--verify-rows", "2"
        ],
    )
    plan = {**payload, "files": [{k: v for k, v in entry.items() if k != "data"} for entry in files]}
    m.save(S / f"apple-retirement{revision}-plan.json", plan)
    return payload


BUILD = r'''
from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p["remote"])
hardware={key:subprocess.check_output(["/usr/sbin/sysctl","-n",key],text=True).strip()for key in ["hw.model","hw.memsize"]}
assert hardware["hw.model"]=="Mac16,12"
toolchain=subprocess.check_output([p["actions"][0][1][0],"--version"],text=True)
assert (Path(p["sdk"])/"build").is_dir()and Path(p["metallib"]).is_file()
root.mkdir(parents=True);source=root/"source";source.mkdir()
for entry in p["files"]:
 target=source/entry["path"];assert target.is_relative_to(source)
 target.parent.mkdir(parents=True,exist_ok=True);raw=base64.b64decode(entry["data"])
 assert len(raw)==entry["bytes"]and hashlib.sha256(raw).hexdigest()==entry["sha256"]
 target.write_bytes(raw)
records=[]
for action,argv in p["actions"]:
 record=dict(command=argv,cwd=p["sdk"]+"/build",started=time.time())
 with(root/(action+".stdout.log")).open("wb")as so,(root/(action+".stderr.log")).open("wb")as se:
  child=subprocess.Popen(argv,cwd=record["cwd"],env=dict(os.environ,PATH="/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"),stdout=so,stderr=se)
  record.update(pid=child.pid,state="running");(root/"live.json").write_text(json.dumps(record,indent=2)+"\n");child.wait()
 record.update(exit=child.returncode,state="terminal",seconds=time.time()-record["started"])
 (root/(action+".result.json")).write_text(json.dumps(record,indent=2)+"\n");(root/"live.json").write_text(json.dumps(record,indent=2)+"\n")
 records.append(record)
 if child.returncode:break
result=dict(records=records,hardware=hardware,toolchain=toolchain,
 all_exit_zero=len(records)==len(p["actions"])and all(x["exit"]==0 for x in records),
 SDK_builds=0,shaders=0,model_copies=0,model_gpu_submission_proven=False)
if result["all_exit_zero"]:
 os.link(p["metallib"],root/"mlx.metallib");image=Path(p["image"]);raw=image.read_bytes()
 result["image"]=dict(path=str(image),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
else:result["stderr"]=(root/(p["actions"][len(records)-1][0]+".stderr.log")).read_text(errors="replace")
(root/"ready.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result))
'''


def build(revision):
    payload = payload_for(revision)
    result = m.ssh(BUILD, payload, timeout=300)
    m.save(S / f"apple-retirement{revision}.json", result)
    print(json.dumps(dict(
        all_exit_zero=result["all_exit_zero"], image=result.get("image"),
        records=[{k: row[k] for k in ["exit", "pid", "seconds"]} for row in result["records"]],
        stderr=result.get("stderr"),
    )), flush=True)
    if not result["all_exit_zero"]:
        raise SystemExit(1)


RUN = r'''
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
p=json.load(sys.stdin);root=Path(p["root"]);out=root/p["folder"];out.mkdir()
hardware={key:subprocess.check_output(["/usr/sbin/sysctl","-n",key],text=True).strip()for key in ["hw.model","hw.memsize"]}
assert hardware["hw.model"]=="Mac16,12"
image=Path(p["image"]["path"]);assert hashlib.sha256(image.read_bytes()).hexdigest()==p["image"]["sha256"]
inputs=Path(p["inputs"]);prompt=inputs/"prompt.ids";weights=inputs/"weights.tsv"
assert [int(x)for x in prompt.read_text().split()]==p["prompt_tokens"]
assert weights.is_file()and weights.read_text().splitlines()[0]=="HYLE_QWEN35_TEXT_MTP_V1"
input_records=[]
for path in [weights,prompt]:
 raw=path.read_bytes();input_records.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
command=[str(image),"--inputs",str(inputs),"--mtp","on","--verify-rows",str(p["verify_rows"])]
record=dict(command=command,cwd=str(image.parent),image=p["image"],inputs=input_records,hardware=hardware,
 started=time.time(),performance_comparison=False,model_admission_proof="original_fifo_accepted_job",
 model_gpu_submission_proven=False)
with(out/"stdout.log").open("wb")as so,(out/"stderr.log").open("wb")as se:
 child=subprocess.Popen(command,cwd=image.parent,env=dict(os.environ,PATH="/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",DYLD_LIBRARY_PATH=p["sdk"]+"/relocated/sdk/lib"),stdout=so,stderr=se)
 record.update(pid=child.pid,state="running");(out/"command.json").write_text(json.dumps(record,indent=2)+"\n");(root/"live.json").write_text(json.dumps(record,indent=2)+"\n");child.wait()
record.update(exit=child.returncode,state="terminal",seconds=time.time()-record["started"])
(out/"result.json").write_text(json.dumps(record,indent=2)+"\n");(root/"live.json").write_text(json.dumps(record,indent=2)+"\n")
result=dict(record=record,stdout=(out/"stdout.log").read_text(errors="replace"),stderr=(out/"stderr.log").read_text(errors="replace"))
print(json.dumps(result))
'''


def run(revision, attempt, verify_rows):
    ready = json.loads((S / f"apple-retirement{revision}.json").read_bytes())
    assert ready["all_exit_zero"]
    payload = dict(
        root=ROOT, folder=f"retirement-T{verify_rows}-run{attempt}", image=ready["image"],
        inputs=ROOT + "/prefix-run1/inputs", sdk=m.SDK, prompt_identity=m.ident(PROMPT),
        verify_rows=verify_rows, prompt_tokens=[int(x) for x in PROMPT.read_text().split()],
    )
    result = m.ssh(RUN, payload, timeout=1800)
    label = f"apple-retirement-T{verify_rows}-run{attempt}"
    m.save(S / (label + ".json"), result)
    if result["record"]["exit"]:
        print(result["stderr"][-6500:], flush=True)
        raise SystemExit(1)
    report = json.loads(result["stdout"])
    assert report["status"] == "PASS" and report["backend"] == "apple" and report["mtp"]
    assert report["native_gate"] == "original_apple_fifo_and_stream_shared_event"
    assert report["model_native_submission_observed"] and not report["gate_watchdog_opened"]
    assert "proof=original_fifo_accepted_job" in result["stderr"]
    assert report["scheduled_progress"] and report["actual_graph_submissions"] == 6
    assert report["pending_target_query_rows"] == verify_rows and report["bound_append_banks"] == 14
    for key in [
        "dropped_live_public_completion", "all14_native_permissions_retained_until_actual_retirement",
        "same_slot_rebuilt_after_close", "old_target_and_draft_kv_bytes_unchanged",
        "old_carry_and_prior_bytes_unchanged", "selector_failed_after_successful_terminal",
        "selector_abort_reclaimed_all14_dirty_banks",
    ]:
        assert report[key], key
    assert report["old_recurrent_resources_byte_unchanged"] == 36
    assert not report["selector_failure_published_head"] and not report["native_error_injected"]
    assert report["host_policy_error_injected"] and not report["cancel_means_native_preemption"]
    summary = dict(
        status="PASS_LIMITED_APPLE_FIFO_RETIREMENT_RETRY",
        report=report, model_admission_proof=MODEL_ADMISSION_PROOF,
        model_fifo_job_admitted=True, model_gpu_submission_proven=False,
        scope="Original Runtime FIFO accepted the Model Job behind the scheduled native gate. "
              "Original Model/Completion retirement, old bytes and retry were checked; "
              "Model GPU submission, GPU preemption and device-failure injection were not proved.",
        budget_scope="Reported managed pending bytes are cache accounting, not private/physical memory peak. "
                     "The raw managed_backing_bytes field describes the caller-pool plan.",
        quality_pass=False, performance_comparison=False,
    )
    m.save(S / (label + "-summary.json"), summary)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["plan", "build", "run"])
    parser.add_argument("--revision", type=int, default=1)
    parser.add_argument("--attempt", type=int, default=1)
    parser.add_argument("--verify-rows", type=int, choices=[1, 2], default=2)
    args = parser.parse_args()
    if args.revision < 1 or args.attempt < 1:
        parser.error("revision and attempt must be positive")
    if args.action == "plan":
        payload = payload_for(args.revision)
        print(json.dumps(dict(
            plan=str(S / f"apple-retirement{args.revision}-plan.json"),
            CXX_TUs=1, OBJCXX_TUs=1, overlay_files=len(payload["files"]),
            overlay_bytes=sum(x["bytes"] for x in payload["files"]), SSH=False,
            SDK_builds=0, shaders=0, model_copies=0, model_gpu_submission_proven=False,
        )), flush=True)
    elif args.action == "build":
        build(args.revision)
    else:
        run(args.revision, args.attempt, args.verify_rows)
