"""Reuse current AP closures; rebuild only the native protocol probe TU."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent; R=S.parents[1]
AP=R/'.scratch/vulkan-native-memory-20261022'
spec=importlib.util.spec_from_file_location('aq_cached',AP/'build.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
b,c,h=m.b,m.c,m.h; h.S=S
SOURCES={tag:R/'tools/qwen35_text/mtp_session_probe.cc'for tag in ['vulkan-prefix','cuda-prefix']}
for backend in ['vulkan','cuda']:
    SOURCES[backend+'-retirement']=R/'tools/qwen35_text/retirement_probe.cc'
    SOURCES[backend+'-gate']=R/'tools/qwen35_text/native_gate.cc'
SOURCES['vulkan-budget']=R/'tools/qwen35_text/retained_budget_probe.cc'
RECIPES={tag:AP/f'compile1/{tag.split("-")[0]}-main/identity.json'for tag in SOURCES}

def compile_one(tag,attempt):
    original=c.read(RECIPES[tag])
    original['command']=[{'-MD':'/MD','-O2':'/O2'}.get(x,x)for x in original['command']]
    path=S/'recipes'/f'{tag}.json';path.parent.mkdir(exist_ok=True);c.save(path,original)
    h.RECIPES[tag]=path;h.SOURCES[tag]=SOURCES[tag];h.compile_one(tag,attempt)

def link(tag,attempt):
    root=AP/(tag.split('-')[0]+'-main-link1');base=c.read(root/'link-plan.json')
    record=c.read(S/f'compile{attempt}/{tag}/identity.json');old=c.read(RECIPES[tag])['object'];new=record['object']
    assert all(b.identity(x['path'])==x for x in [record['source'],record['object'],*record['dependencies']])
    assert sum(c.key(x['path'])==c.key(old['path'])for x in base['inputs'])==1
    addons=[]
    if tag.endswith('-retirement'):
        helper=c.read(S/f'compile{attempt}/{tag.split("-")[0]}-gate/identity.json')
        assert all(b.identity(x['path'])==x for x in [helper['source'],helper['object'],*helper['dependencies']])
        addons.append(helper['object'])
    inputs=addons+[new if c.key(x['path'])==c.key(old['path'])else x for x in base['inputs']]
    for x in inputs:assert b.identity(x['path'])==x
    out=S/f'{tag}-link{attempt}';out.mkdir();(out/'tmp').mkdir();image=out/'probe.exe'
    command=[new['path']if c.key(x)==c.key(old['path'])else x for x in base['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command[1:1]=[x['path']for x in addons]
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,inputs=inputs,compiled_record=b.identity(S/f'compile{attempt}/{tag}/identity.json'),SDK_builds=0,NVCC=0,shaders=0))
    env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
    runtime=c.read(root/'runtime-environment.json');c.save(out/'runtime-environment.json',runtime)
    for x in runtime.get('staged_dlls',[]):
        path=Path(x['path'])
        if not(out/path.name).exists():os.link(path,out/path.name)
    c.save(out/'ready.json',dict(image=b.identity(image)));print('LINKED',tag,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('actions',nargs='+',choices=[*SOURCES,*['link-'+x for x in SOURCES]]);p.add_argument('--attempt',type=int,default=1);a=p.parse_args()
    for action in a.actions:link(action[5:],a.attempt)if action.startswith('link-')else compile_one(action,a.attempt)
