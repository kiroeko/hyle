"""Run one current native MTP lifetime or retained-budget check, without timing claims."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, time

S = Path(__file__).resolve().parent
R = S.parents[1]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--backend', choices=['vulkan', 'cuda'], required=True)
p.add_argument('--scenario', choices=['retirement', 'budget'], required=True)
p.add_argument('--attempt', type=int, default=1)
p.add_argument('--image-attempt', type=int, default=1)
a = p.parse_args()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf8')

def ident(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

root = S / f'{a.backend}-{a.scenario}-link{a.image_attempt}'
out = S / f'{a.backend}-{a.scenario}-run{a.attempt}'
out.mkdir()
inputs = R / '.scratch/qwen-mtp-weights-20261022/prepared'
command = [str(root / 'probe.exe'), '--inputs', str(inputs)]
command += ['--mtp', 'on'] if a.scenario == 'retirement' else ['--out', str(out / 'vectors')]
record = dict(command=command, cwd=str(R), image=ident(root / 'probe.exe'),
              inputs=[ident(inputs / x) for x in ['weights.tsv', 'prompt.ids']],
              started=time.time(), performance_comparison=False)
with (out / 'stdout.log').open('wb') as so, (out / 'stderr.log').open('wb') as se:
    child = subprocess.Popen(command, cwd=R,
        env=dict(os.environ, PATH=json.loads((root / 'runtime-environment.json').read_bytes())['PATH']),
        stdout=so, stderr=se)
    record.update(pid=child.pid, state='running')
    save(out / 'command.json', record)
    save(S / 'live.json', record)
    print('START', a.scenario, a.backend, 'PID', child.pid, flush=True)
    child.wait()
record.update(exit=child.returncode, state='terminal', seconds=time.time() - record['started'])
save(out / 'result.json', record)
save(S / 'live.json', record)
if child.returncode:
    print((out / 'stderr.log').read_text(errors='replace')[-8500:], flush=True)
    raise SystemExit(1)
stdout = (out / 'stdout.log').read_text(errors='replace')
report = json.loads(stdout.strip().splitlines()[-1])
save(out / 'summary.json', report)
print(json.dumps(report), flush=True)
