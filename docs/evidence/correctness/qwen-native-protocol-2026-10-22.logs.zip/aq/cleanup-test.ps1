$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022'
$taskPrefix = $taskRoot + '\'
$taskFiles = @(
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\vulkan-retirement-link1\probe.exe'; Bytes = 68823552; Sha256 = 'CE936EBA3DECFB27C660D0959671D6AF2B6A837AEC734FAE900A00B22ADE08EC' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\vulkan-retirement-link2\probe.exe'; Bytes = 68826624; Sha256 = '7733A02FCB67ECD320659949591E0DC0F47DF9F477B413A94A0CE5879525E22A' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\vulkan-retirement-link3\probe.exe'; Bytes = 68826112; Sha256 = '736AEDF2E0F90E27712D841E76F1D9D923DB1A44332D5F48249EE8DF3F20126C' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\vulkan-retirement-link4\probe.exe'; Bytes = 68826112; Sha256 = '9510883D7CFCF4597EE3A0B4388DD3DDF39D3B68674B2C0924889867AF7D8033' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\vulkan-retirement-link5\probe.exe'; Bytes = 68827648; Sha256 = '0E8281218C2AFBEA5B4DB2BCC4AB3DFD144CC4A0348D70A120CE6F9BF7501FF4' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\vulkan-budget-link1\probe.exe'; Bytes = 68790272; Sha256 = 'D8CC11C087750C8D031F9C4AAF81F5617FACD58F05FD247262C2285FF07419CA' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\cpu-test-link1\test.exe'; Bytes = 70690816; Sha256 = 'BD05C98552D08F2D73F171E21952A60F1863D3678844538F502B7099F7EAF21A' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\cuda-prefix-link1\probe.exe'; Bytes = 140387328; Sha256 = '51DBE36FEC54F58396D052483921840A314CC6C3DA49845A34B0FACF4374E8BC' }
  @{ Path = 'C:\public\project-hyle\hyle\.scratch\qwen-native-protocol-20261022\vulkan-prefix-link1\probe.exe'; Bytes = 68903424; Sha256 = '12635FE76030CEB2C5155F4C6CB8A5E72FE331EB78A1CCFDE355BC4415C0C8D4' }
)
foreach ($taskFile in $taskFiles) {
  $taskResolved = (Resolve-Path -LiteralPath $taskFile.Path).Path
  if (-not $taskResolved.StartsWith($taskPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup target outside exact AQ workspace' }
  $taskInfo = Get-Item -LiteralPath $taskResolved
  if ($taskInfo.PSIsContainer -or ($taskInfo.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Unexpected cleanup target type' }
  if ($taskInfo.Length -ne $taskFile.Bytes) { throw 'Cleanup target size changed' }
  if ((Get-FileHash -LiteralPath $taskResolved -Algorithm SHA256).Hash -ne $taskFile.Sha256) { throw 'Cleanup target content changed' }
}
foreach ($taskFile in $taskFiles) { Remove-Item -LiteralPath $taskFile.Path -Force }
$taskResult = @{ status = 'REMOVED_EXACT_REBUILDABLE_FILES'; files = $taskFiles.Count; logical_bytes = ($taskFiles | Measure-Object -Property Bytes -Sum).Sum; physical_free_space_gain_claimed = $false }
$taskResult | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding UTF8
$taskResult | ConvertTo-Json -Compress
