"""Actual whole-state prefix protocol probe over the original first23 fixture."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, time
S=Path(__file__).resolve().parent;R=S.parents[1]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--backend',choices=['vulkan','cuda'],required=True);p.add_argument('--attempt',type=int,default=1);p.add_argument('--image-attempt',type=int,default=1);a=p.parse_args()
root=S/f'{a.backend}-prefix-link{a.image_attempt}';out=S/f'{a.backend}-prefix-run{a.attempt}';out.mkdir()
inputs=R/'.scratch/qwen-mtp-weights-20261022/prepared'
command=[str(root/'probe.exe'),'--inputs',str(inputs),'--scenario','prefix','--output',str(out/'vectors')]
def save(path,x):path.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(path):
    raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
record=dict(command=command,cwd=str(R),image=ident(root/'probe.exe'),inputs=[ident(inputs/x)for x in ['weights.tsv','prompt.ids']],started=time.time(),performance_comparison=False)
with(out/'stdout.log').open('wb')as so,(out/'stderr.log').open('wb')as se:
    child=subprocess.Popen(command,cwd=R,env=dict(os.environ,PATH=json.loads((root/'runtime-environment.json').read_bytes())['PATH']),stdout=so,stderr=se)
    record.update(pid=child.pid,state='running');save(out/'command.json',record);save(S/'live.json',record);print('START prefix',a.backend,'PID',child.pid,flush=True);child.wait()
record.update(exit=child.returncode,state='terminal',seconds=time.time()-record['started']);save(out/'result.json',record);save(S/'live.json',record)
if child.returncode:
    print((out/'stderr.log').read_text(errors='replace')[-6500:]);raise SystemExit(1)
report=json.loads((out/'vectors/observation.json').read_bytes())
keys=['status','actual_graph_calls','full_hits','full_hit_head_vectors','old_prefix_full_byte_checks','peak_live_snapshot_versions','final_live_snapshot_versions','all_vectors_byte_equal','all_finite','negative_rejected','negative_bound_banks','retry_same_carrier_slot','peak_retained_output_backing_bytes']
summary={k:report[k]for k in keys}
summary.update(vector_comparisons=len(report['vectors']),cache={k:v for k,v in report.items()if k.startswith('cache_')},quality_pass=False,performance_comparison=False)
save(out/'summary.json',summary)
assert report['status']=='PASS_BYTE_EXACT'and report['all_vectors_byte_equal']and report['all_finite']
assert report['actual_graph_calls']==15 and report['full_hits']==3 and report['full_hit_head_vectors']==156
assert report['negative_rejected']and report['negative_bound_banks']==14 and report['retry_same_carrier_slot']and report['final_live_snapshot_versions']==0
print(json.dumps(summary),flush=True)
