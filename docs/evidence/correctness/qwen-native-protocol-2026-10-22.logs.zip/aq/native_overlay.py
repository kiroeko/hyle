"""Link an already compiled consumer with the two current Vulkan cancellation objects."""
from pathlib import Path
import argparse, importlib.util, os, sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
spec=importlib.util.spec_from_file_location('aq_overlay_cached',S/'build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b,c=m.b,m.c
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--scenario',choices=['budget','retirement'],required=True);p.add_argument('--base',type=int,required=True);p.add_argument('--revision',type=int,required=True);a=p.parse_args()
base=S/f'vulkan-{a.scenario}-link{a.base}';plan=c.read(base/'link-plan.json')
recipes={
 'vulkan-run':R/'.scratch/architecture-refactor-2026-10-18/mlx-moe-typed-inputs/vulkan/checks/compute_route_vulkan-vulkan_run-identity.json',
 'vulkan-iree':R/'.scratch/architecture-refactor-2026-10-18/quark-block128-scale-2026-10-21/vulkan/windows/checks/attempt1/iree/identity.json',
}
replacements={}
for tag,recipe in recipes.items():
 old=c.read(recipe)['object'];record=c.read(S/f'compile1/{tag}/identity.json')
 assert all(b.identity(x['path'])==x for x in [record['source'],record['object'],*record['dependencies']])
 assert sum(c.key(x['path'])==c.key(old['path'])for x in plan['inputs'])==1
 replacements[c.key(old['path'])]=record['object']
inputs=[replacements.get(c.key(x['path']),x)for x in plan['inputs']]
for x in inputs:assert b.identity(x['path'])==x
out=S/f'vulkan-{a.scenario}-link{a.revision}';out.mkdir();(out/'tmp').mkdir();image=out/'probe.exe'
command=[replacements.get(c.key(x),{'path':x})['path']for x in plan['command']if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=command,inputs=inputs,SDK_builds=0,NVCC=0,shaders=0))
env,_=b.environment(command,[x['path']for x in inputs],out);c.execute('link',command,env,out)
runtime=c.read(base/'runtime-environment.json');c.save(out/'runtime-environment.json',runtime)
for x in runtime.get('staged_dlls',[]):
 path=Path(x['path'])
 if not(out/path.name).exists():os.link(path,out/path.name)
c.save(out/'ready.json',dict(image=b.identity(image)));print('LINKED',a.scenario,'with current Vulkan cancellation',flush=True)
