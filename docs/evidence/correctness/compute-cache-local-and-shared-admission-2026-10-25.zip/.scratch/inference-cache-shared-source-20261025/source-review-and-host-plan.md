# Private source batch, awaiting the finite host build

Only seven existing source files are proposed. Canonical files are untouched.
`before-pins.json`, `after-pins.json` and `source.patch` record the exact boundary.

- Three additive public cold symbols: the LeasePool create overload and both
  typed PagedArena factory overloads. Old exported signatures, options and public
  handle layouts are unchanged. PagedArenaData does not gain another owner table.
- One additional detail cold symbol, ResourceBudgetAccess::original_allocator.
  Existing backing_allocator now returns the actual allocator behind only exact
  known ResourceBudget callbacks. The four existing call sites use it for owner
  proof, never for freeing. Unknown custom allocators stop traversal and retain
  their original owner requirement. Graph/StorageOwner gates are unchanged.
- LeaseDomain already keeps a stable allocator whose actual Domain allocation
  retains its budget scopes. The cold Graph ownership query resolves that
  original allocator directly, never the consumable payload charge. No second
  allocator fact or Domain layout change is needed. Actual frees/reallocations
  still use the original quota callbacks. Public/private layouts are unchanged.
- Additional source admission uses exact capacity/resource before Buffer::create.
  Its pending secondary Reservation is declared before the owning pool root.
  A real host mapping then establishes the original address identity. Each
  successfully adopted token is attached immediately into pre-reserved entries;
  any later failure destroys Buffer/domain/attached owners before the remaining
  pending secondary charge. Empty additional and same-scope cases keep one gate.
- Qwen changes only cache-budget metadata allocation and the existing KV arena /
  state-pool source factories. The finite local device row is preserved. Its
  separate GPU system-metadata row stays unlimited; on CPU the same actual
  resource row remains finite as before. Global selected rows have their own
  aggregate constraint. Existing metadata callbacks charge each physical host
  allocation once globally. This is not a claim that the allocator gates payload.
- Existing native output creation still uses its original execution/global
  scope; local export uses retain_budget rather than StorageOwner::adopt_buffer.
  Cache generated-result aggregate retention is not implemented in this first
  source batch. Original native/private/unattributed exclusions remain.

Proposed finite host check (no GPU, SDK/vendor rebuild or Model consumer):

1. Refresh exactly resource_budget.cc, resource_leases.cc and paged_arena.cc,
   plus the one private cache_source_budget_test.cc TU, /std:c++latest /W4 /WX.
   Reuse the existing CPU host include/toolchain closure. Private include first;
   original src/compute_batch remains the internal-header fallback.
2. Reuse batch1/host-final1/link/command.json. Replace exactly its two core OBJ,
   old compute_batch--paged_arena.obj and host consumer OBJ; add existing gtest
   and gtest_main libraries. Use the existing pure ffa4 CPU DLL in executable
   directory, preserving its source/hash identity.
3. Run only CacheSourceBudget.* (eight tests): local/aggregate payload rejection
   before source allocation; mapping and either-record metadata failure with
   both quotas live in actual deallocate; canonical independent host wrapper /
   subview dedup and no export allocation; empty/same/additional-only paths;
   real metadata grow rejection/shrink/free; two genuine same-ready Graph
   preparations across source-charge adoption by actual result export,
   including nested local/global metadata; unknown custom owner rejection; real
   PagedArena whole-backing/per-page forwarding and escaped-page lifetime.
4. A single CPU main /Zs may then check the seven new source calls without any
   Model execution. No CUDA consumer or runtime is part of this proposal.

The Graph test prepares/submits a source-alias input/output graph, then obtains
the actual GraphOutput::storage_lease(local) to adopt its source charge. The
export reader remains live while the same original lease is used as a constant
in a second compile/ResourceOptions prepare. Invocation::bind by itself does
not adopt the charge. No old-image negative run has occurred; do not label its
expected old failure as an actual result. First fixture failures remain raw.
