#include <gtest/gtest.h>

#include <array>
#include <optional>

#include "engine/inference/backend.h"
#include "hyle/compute/detail/lease_access.h"
#include "hyle/compute/detail/resource_budget_access.h"
#include "hyle/compute/paged_arena.h"

namespace {
namespace c=hyle::compute;
namespace d=hyle::compute::detail;
namespace g=hyle::graph;
namespace i=hyle::inference;
namespace m=hyle::mem;

bool same_allocator(m::AllocatorRef a,m::AllocatorRef b) {
  return a.valid()&&b.valid()&&a.alloc_fn()==b.alloc_fn()&&a.free_fn()==b.free_fn()&&
      a.realloc_fn()==b.realloc_fn()&&a.state()==b.state();
}
std::size_t external(const c::ResourceBudget &b,m::MemoryResourceRef r) {
  return b.usage(r)->live_by_category[static_cast<std::size_t>(c::ResourceBudgetCategory::kExternal)];
}
c::ResourceBudget budget(m::MemoryResourceRef resource,std::size_t payload=SIZE_MAX,
                        m::AllocatorRef allocator=m::system_allocator(),bool shared=false) {
  const std::array limits{c::ResourceBudgetLimit{resource,payload},c::ResourceBudgetLimit{m::system_resource()}};
  const auto count=resource==m::system_resource()?1u:2u;
  const std::array nominated{resource,m::system_resource()};
  const c::ResourceBudgetOptions options{.limits=std::span(limits).first(count),.allocator=allocator};
  return shared?c::ResourceBudget::create(options,std::span(nominated).first(count),1u<<20).value()
               :c::ResourceBudget::create(options).value();
}
struct Allocations final {
  std::size_t calls=0,reallocations=0,frees=0;
  int remaining=-1;
  m::AllocatorRef ref() noexcept { return {allocate,free,reallocate,this}; }
  bool fail() noexcept { if(remaining==0)return true;if(remaining>0)--remaining;return false; }
  static void *allocate(void *p,std::size_t n,std::size_t a) noexcept {
    auto &s=*static_cast<Allocations*>(p);++s.calls;
    return s.fail()?nullptr:m::system_allocator().allocate(n,a);
  }
  static void free(void *p,void *v,std::size_t n,std::size_t a) noexcept {
    ++static_cast<Allocations*>(p)->frees;m::system_allocator().deallocate(v,n,a);
  }
  static void *reallocate(void *p,void *v,std::size_t old,std::size_t n,std::size_t a) noexcept {
    auto &s=*static_cast<Allocations*>(p);++s.reallocations;
    return s.fail()?nullptr:m::system_allocator().reallocate(v,old,n,a);
  }
};
class Source final:public m::MemoryResource {
public:
  std::size_t allocations=0,free_calls=0,roots=0;
  bool map_failure=false;
  Allocations *arm_allocator=nullptr;
  int fail_after=-1;
  const c::ResourceBudget *local=nullptr,*shared=nullptr;
  std::size_t local_at_free=0,shared_at_free=0;
  bool local_nested=false,shared_nested=false;
  m::ResourceAllocation actual{};
  m::MemoryResourceRef ref() noexcept {return m::MemoryResourceRef(*this);}
  std::string_view name()const noexcept override{return "cache-source-test";}
  m::MemoryProperties properties()const noexcept override{return m::system_resource().properties();}
  hyle::Result<m::ResourceAllocation> allocate(std::size_t n,std::size_t a)noexcept override{
    auto result=m::system_resource().resource().allocate(n,a);
    if(result){++allocations;actual=*result;roots=1;if(arm_allocator)arm_allocator->remaining=fail_after;}
    return result;
  }
  m::ResourceAllocation alias()noexcept{++roots;return actual;}
  void deallocate(m::ResourceAllocation value)noexcept override{
    ++free_calls;
    if(local){local_at_free=external(*local,ref());local_nested=bool(local->reserve(ref(),value.size));}
    if(shared){shared_at_free=external(*shared,ref());shared_nested=bool(shared->reserve(ref(),value.size));}
    if(--roots==0)m::system_resource().resource().deallocate(value);
  }
  hyle::Result<m::ResourceHostMapping> map_host(void *h,std::size_t o,std::size_t n,m::HostAccess a)noexcept override{
    if(map_failure)return std::unexpected(hyle::Status::Unavailable("injected source mapping failure"));
    return m::system_resource().resource().map_host(h,o,n,a);
  }
  hyle::Status unmap_host(void *h,void *t,std::size_t o,std::size_t n,m::HostAccess a)noexcept override{
    return m::system_resource().resource().unmap_host(h,t,o,n,a);
  }
};

TEST(CacheSourceBudget, EitherPayloadGateRejectsBeforeResourceAllocation) {
  Source source;
  auto shared=budget(source.ref(),SIZE_MAX,m::system_allocator(),true);
  auto local=budget(source.ref(),511);
  const auto shared_base=shared.shared_usage()->live_bytes;
  EXPECT_FALSE(c::LeasePool::create(source.ref(),512,{.max_blocks=1,.resource_budget=local},shared));
  EXPECT_EQ(source.allocations,0u);EXPECT_EQ(external(local,source.ref()),0u);
  EXPECT_EQ(shared.shared_usage()->live_bytes,shared_base);
  local=budget(source.ref(),512);
  const auto available=shared.shared_usage()->limit_bytes-shared.shared_usage()->live_bytes;
  auto occupied=shared.reserve(source.ref(),available-511);ASSERT_TRUE(occupied);
  const auto blocked=shared.shared_usage()->live_bytes;
  EXPECT_FALSE(c::LeasePool::create(source.ref(),512,{.max_blocks=1,.resource_budget=local},shared));
  EXPECT_EQ(source.allocations,0u);EXPECT_EQ(external(local,source.ref()),0u);
  EXPECT_EQ(shared.shared_usage()->live_bytes,blocked);
}

TEST(CacheSourceBudget, PostAllocationFailuresKeepBothChargesUntilActualFree) {
  for(const int point:{-1,0,1}){
    SCOPED_TRACE(point);Allocations allocation;Source source;
    auto shared=budget(source.ref(),512,allocation.ref(),true);
    auto local=budget(source.ref(),512,shared.metadata_allocator().value());
    source.local=&local;source.shared=&shared;
    const auto local_base=local.usage(m::system_resource())->live_bytes;
    const auto shared_base=shared.shared_usage()->live_bytes;
    source.map_failure=point<0;
    if(point>=0){source.arm_allocator=&allocation;source.fail_after=point;}
    EXPECT_FALSE(c::LeasePool::create(source.ref(),512,{.max_blocks=1,.resource_budget=local},shared));
    EXPECT_EQ(source.allocations,1u);EXPECT_EQ(source.free_calls,1u);
    EXPECT_EQ(source.local_at_free,512u);EXPECT_EQ(source.shared_at_free,512u);
    EXPECT_FALSE(source.local_nested);EXPECT_FALSE(source.shared_nested);
    EXPECT_EQ(external(local,source.ref()),0u);EXPECT_EQ(external(shared,source.ref()),0u);
    EXPECT_EQ(local.usage(m::system_resource())->live_bytes,local_base);
    EXPECT_EQ(shared.shared_usage()->live_bytes,shared_base);
    allocation.remaining=-1;
  }
}

TEST(CacheSourceBudget, CanonicalHostAliasAndSubviewsKeepOneChargeAndNoExportAllocation) {
  Allocations allocation;Source source;
  auto shared=budget(source.ref(),512,allocation.ref(),true);
  auto local=budget(source.ref(),512,shared.metadata_allocator().value());
  auto made=c::LeasePool::create(source.ref(),512,{.max_blocks=1,.resource_budget=local},shared);ASSERT_TRUE(made);
  auto pool=std::move(*made);auto writer=pool.allocate(512,16).value();
  ASSERT_TRUE(writer.view()->fill(std::byte{17}).ok());auto ready=writer.publish().value();
  auto piece=ready.subview(16,32).value();const auto calls=allocation.calls;
  ASSERT_TRUE(d::LeaseAccess::retain_budget(piece,source.ref(),local).ok());
  ASSERT_TRUE(d::LeaseAccess::retain_budget(piece,source.ref(),shared).ok());
  EXPECT_EQ(allocation.calls,calls);EXPECT_EQ(external(local,source.ref()),512u);
  EXPECT_EQ(external(shared,source.ref()),512u);
  auto alias_buffer=m::Buffer::adopt(source.ref(),source.alias()).value();
  auto alias=c::ReadLease::adopt(std::move(alias_buffer)).value();
  ASSERT_TRUE(d::LeaseAccess::retain_budget(alias,source.ref(),shared).ok());
  EXPECT_EQ(external(shared,source.ref()),512u);
  piece.reset();ready.reset();pool={};EXPECT_EQ(external(local,source.ref()),0u);
  EXPECT_EQ(external(shared,source.ref()),512u); // the other actual wrapper is still live
  std::array<std::byte,1> byte{};ASSERT_TRUE(alias.view()->subview(0,1)->read(byte).ok());EXPECT_EQ(byte[0],std::byte{17});
  alias.reset();EXPECT_EQ(external(shared,source.ref()),0u);EXPECT_EQ(source.roots,0u);
}

TEST(CacheSourceBudget, EmptyAndSameScopesPreserveNaturalSourcePaths) {
  Source source;auto primary=budget(source.ref(),512);
  {
    auto made=c::LeasePool::create(source.ref(),512,{.max_blocks=1,.resource_budget=primary},primary);
    ASSERT_TRUE(made);EXPECT_EQ(external(primary,source.ref()),512u);
  }
  EXPECT_EQ(external(primary,source.ref()),0u);
  {
    auto made=c::LeasePool::create(source.ref(),512,{.max_blocks=1,.resource_budget=primary},{});
    ASSERT_TRUE(made);EXPECT_EQ(external(primary,source.ref()),512u);
  }
  {
    auto made=c::LeasePool::create(source.ref(),512,{.max_blocks=1},primary);
    ASSERT_TRUE(made);EXPECT_EQ(external(primary,source.ref()),512u);
  }
  EXPECT_EQ(external(primary,source.ref()),0u);EXPECT_EQ(source.roots,0u);
}

TEST(CacheSourceBudget, NestedMetadataGrowthRejectsAndRollsBackBothScopes) {
  Allocations allocation;Source source;
  auto shared=budget(source.ref(),SIZE_MAX,allocation.ref(),true);
  auto local=budget(source.ref(),SIZE_MAX,shared.metadata_allocator().value());
  auto allocator=local.metadata_allocator().value();const auto local_base=local.usage(m::system_resource())->live_bytes;
  const auto shared_base=shared.shared_usage()->live_bytes;
  void *p=allocator.allocate(32,16);ASSERT_NE(p,nullptr);
  EXPECT_EQ(local.usage(m::system_resource())->live_bytes,local_base+32);
  EXPECT_EQ(shared.shared_usage()->live_bytes,shared_base+32);
  auto occupied=shared.reserve(m::system_resource(),shared.shared_usage()->limit_bytes-shared.shared_usage()->live_bytes);ASSERT_TRUE(occupied);
  const auto calls=allocation.reallocations;
  EXPECT_EQ(allocator.reallocate(p,32,64,16),nullptr);
  EXPECT_EQ(allocation.reallocations,calls);EXPECT_EQ(local.usage(m::system_resource())->live_bytes,local_base+32);
  occupied->reset();p=allocator.reallocate(p,32,16,16);ASSERT_NE(p,nullptr);
  EXPECT_EQ(local.usage(m::system_resource())->live_bytes,local_base+16);
  EXPECT_EQ(shared.shared_usage()->live_bytes,shared_base+16);
  allocator.deallocate(p,16,16);
  EXPECT_EQ(local.usage(m::system_resource())->live_bytes,local_base);
  EXPECT_EQ(shared.shared_usage()->live_bytes,shared_base);
}

struct ConstantGraph final {
  g::Graph graph;
  g::ConstantBinding binding;
  g::ValueId input;
  c::TensorDesc description;
};
ConstantGraph constant_graph(const c::ReadLease &ready) {
  const auto desc=c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{4}).value();
  auto builder=g::GraphBuilder::create().value();const auto port=builder.constant(desc).value();
  const auto input=builder.input(desc).value();
  const auto output=builder.add(c::Unary{c::UnaryKind::kNeg},input).value();
  EXPECT_TRUE(builder.publish(port).ok());EXPECT_TRUE(builder.publish(output).ok());
  auto graph=std::move(builder).finish().value();
  const g::ConstantBinding binding{.value=port,.tensor=ready.tensor(desc).value(),.lease=ready};
  return {std::move(graph),binding,input,desc};
}

TEST(CacheSourceBudget, SameReadyLeasePreparesTwiceAcrossChargeAdoptionAndNestedMetadata) {
  auto backend=i::Backend::create({.primary=i::BackendKind::kCpu},{}).value();
  for(const bool nested:{false,true}){
    SCOPED_TRACE(nested);auto shared=budget(m::system_resource(),1u<<20);
    auto local=budget(m::system_resource(),1u<<20,nested?shared.metadata_allocator().value():m::system_allocator());
    auto pool=c::LeasePool::create(m::system_resource(),16,{.max_blocks=1,.resource_budget=local}).value();
    auto writer=pool.allocate(16,16).value();ASSERT_TRUE(writer.view()->fill(std::byte{}).ok());
    auto ready=writer.publish().value();auto fixture=constant_graph(ready);
    auto first=backend.compile(fixture.graph,std::span(&fixture.binding,1));ASSERT_TRUE(first)<<first.error().message();
    auto run=first->executable.create_invocation().value();
    ASSERT_TRUE(run.prepare_resources({.resource_budget=local}).ok());
    // This actual Graph resource import adopts the source charge. No helper
    // call is substituted for the original prepare/bind path.
    const auto bound=run.bind(fixture.input,fixture.description,ready);
    ASSERT_TRUE(bound.ok())<<bound.message();
    EXPECT_TRUE(same_allocator(d::LeaseAccess::metadata_backing_allocator(ready),m::system_allocator()));
    auto second=backend.compile(fixture.graph,std::span(&fixture.binding,1));ASSERT_TRUE(second)<<second.error().message();
    auto again=second->executable.create_invocation().value();
    ASSERT_TRUE(again.prepare_resources({.resource_budget=local}).ok());
    const auto rebound=again.bind(fixture.input,fixture.description,ready);
    ASSERT_TRUE(rebound.ok())<<rebound.message();
  }
}

TEST(CacheSourceBudget, UnknownAllocatorStillRequiresItsActualOwner) {
  Allocations allocation;auto local=budget(m::system_resource(),1u<<20,allocation.ref());
  auto pool=c::LeasePool::create(m::system_resource(),16,{.max_blocks=1,.resource_budget=local}).value();
  auto writer=pool.allocate(16,16).value();ASSERT_TRUE(writer.view()->fill(std::byte{}).ok());
  auto ready=writer.publish().value();auto fixture=constant_graph(ready);
  auto backend=i::Backend::create({.primary=i::BackendKind::kCpu},{}).value();
  EXPECT_TRUE(same_allocator(d::ResourceBudgetAccess::original_allocator(allocation.ref()),allocation.ref()));
  auto first=backend.compile(fixture.graph,std::span(&fixture.binding,1));ASSERT_FALSE(first);
  EXPECT_TRUE(first.error().IsInvalidArgument());
  ASSERT_TRUE(d::LeaseAccess::retain_budget(ready,m::system_resource(),local).ok());
  EXPECT_TRUE(same_allocator(d::LeaseAccess::metadata_backing_allocator(ready),allocation.ref()));
  auto second=backend.compile(fixture.graph,std::span(&fixture.binding,1));ASSERT_FALSE(second);
  EXPECT_TRUE(second.error().IsInvalidArgument());
}

TEST(CacheSourceBudget, PagedArenaForwardsBothGatesWithoutPerPageCharge) {
  Source source;auto shared=budget(source.ref(),SIZE_MAX,m::system_allocator(),true);
  auto local=budget(source.ref(),4096,shared.metadata_allocator().value());
  const c::BatchCapacity capacity{.max_requests=1,.max_query_rows=1,.max_kv_rows=8,
      .max_pages=4,.max_page_refs=4,.query_heads=2,.kv_heads=2,.qk_head_dim=64,.value_head_dim=64,.page_size=2};
  auto schema=c::BatchSchema::create(capacity,{.resource_budget=local}).value();
  auto made=c::PagedArena::create(schema,c::BatchCacheRole::kKey,source.ref(),
      {.max_backing_bytes=4096,.resource_budget=local},shared);ASSERT_TRUE(made);
  auto arena=std::move(*made);const auto whole=external(local,source.ref());
  EXPECT_EQ(whole,arena.page_bytes()*4+1);EXPECT_EQ(external(shared,source.ref()),whole);
  auto page=arena.acquire(0).value();ASSERT_TRUE(page.lease().view()->fill(std::byte{29}).ok());
  auto ready=page.publish(2).value();page={};ASSERT_TRUE(d::LeaseAccess::retain_budget(ready,source.ref(),shared).ok());
  EXPECT_EQ(external(shared,source.ref()),whole);arena={};EXPECT_EQ(external(shared,source.ref()),whole);
  ready.reset();EXPECT_EQ(external(local,source.ref()),0u);EXPECT_EQ(external(shared,source.ref()),0u);
}
} // namespace
