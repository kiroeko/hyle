from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
R=Path.cwd();D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
result=ET.parse(D/'attempt3/results.xml').getroot();assert result.attrib['tests']=='8' and result.attrib['failures']=='0'
actual_core=[]
for name,path in [('budget','src/compute/resource_budget.cc'),('leases','src/compute/resource_leases.cc'),('arena','src/compute_batch/paged_arena.cc')]:
    actual_core.append(dict(source=pin(D/'source'/path),object=pin(D/'attempt1'/name/'unit.obj'),
                           process=read(D/'attempt1'/name/'process.json')))
old_main=read(D/'main-cpu-syntax1/source.json')
assert hashlib.sha256((D/'main-cpu-syntax1/checked-main.cc').read_bytes()).hexdigest()==old_main['sha256']
summary=dict(status='HOST_8_PASS_ATOMIC_MAIN_SOURCE_REVIEW_PENDING',canonical_modified=False,
    source_patch=pin(D/'source.patch'),current_sources=read(D/'after-pins.json'),host_core=actual_core,
    host=dict(tests=8,failures=0,skipped=0,process=read(D/'attempt3/run/process.json'),
              xml=pin(D/'attempt3/results.xml'),consumer=pin(D/'cache_source_budget_test.cc'),
              ready=read(D/'attempt3/ready.json')),
    first_failures=[dict(attempt='attempt1',result='6/8 passed',reason='Fixture exact-read span size and unsafe overlap between published constant/input'),
                    dict(attempt='attempt2',result='7/8 passed',reason='Unsafe overlap preserved; actual Status identifies the fixture collision')],
    corrections='Subview read uses exact one-byte view; true source-alias Graph output is submitted and exported with storage_lease(local), then retained as the original ready constant for a second preparation. No alias or permission guard changed.',
    graph_contract=dict(first='prepare_resources(local), bind, submit/wait, GraphOutput.storage_lease(local)',
                        second='same original ready lease as constant, compile/prepare with independent input backing',
                        nested_system_metadata=True,unknown_custom_owner_rejected=True,old_image_negative_run=False),
    main_syntax=dict(process=read(D/'main-cpu-syntax1/process.json'),source=old_main,
                     scope='Before new atomic prepare_cache edit; not claimed for current main',
                     current_atomic_main=pin(D/'source/engine/models/qwen35/main.cc'),current_atomic_checked=False),
    changes=['three additive public cold source factories, unchanged old signatures/options/layouts',
             'one detail cold exact-original-allocator helper; only known budget callbacks unwrapped',
             'ownership query uses existing stable Domain allocator rather than consumed primary charge',
             'Qwen source pools/arenas get independent local and injected scopes; CPU metadata goes through both original allocators',
             'current additional source-only main edit publishes prepared schema/inventories only after all cold factories succeed'],
    limits=['GPU=0; no SDK/vendor or Model consumer build/run',
            'Local GPU device cache row remains finite and its separate system-metadata row remains unlimited; CPU coalesces the actual system row as before',
            'Generated-output second-scope retention is an explicit next slice, not included in these checked objects',
            'Native/private/unattributed allocations and original mappings/std host containers are not a physical VRAM cap'],
    GPU=0,HTTP=0,SDK_full_build=0)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(status=summary['status'],core_TUs=3,host_tests=8,current_atomic_main=summary['main_syntax']['current_atomic_main']),indent=2))
