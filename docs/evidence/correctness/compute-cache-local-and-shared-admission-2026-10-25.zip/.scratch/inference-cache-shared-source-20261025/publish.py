"""Freeze the checked source/commands/raw only; never archive binaries or payloads."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import zipfile

R=Path.cwd();D=Path(__file__).resolve().parent;F=D/'formal-regressions'
PUBLIC=R/'docs/evidence/correctness/compute-cache-local-and-shared-admission-2026-10-25.json'
ARCHIVE=PUBLIC.with_suffix('.zip')
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def pin(path):
    data=path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')

before=read(D/'before-pins.json')+read(F/'before-pins.json')
after=read(D/'after-pins.json')+read(F/'after-pins.json')
patch='';bindings=[]
for old,new in zip(before,after):
    assert old['path']==new['path']
    name=old['path'];base=D if (D/'source'/name).exists() else F
    old_path,new_path=base/'before'/name,base/'source'/name
    assert pin(old_path)['sha256']==old['sha256'] and pin(new_path)['sha256']==new['sha256']
    assert pin(R/name)['sha256']==new['sha256'], ('canonical differs from root-integrated checked source',name)
    patch+=''.join(difflib.unified_diff(old_path.read_text().splitlines(keepends=True),
        new_path.read_text().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
    bindings.append(dict(path=name,before=old,after=new,private_source=new_path.relative_to(R).as_posix()))
save(D/'final-before-pins.json',before);save(D/'final-after-pins.json',after)
save(D/'integration-source-map.json',bindings)
(D/'final-source.patch').write_text(patch,encoding='utf8')

host=read(D/'summary.json')
host['status']='PASS_CHECKED_CLOSURE_CANONICAL_SOURCE_INTEGRATED'
host['canonical_modified']=True
host['source_patch']=pin(D/'final-source.patch')
host['before_sources']=before;host['current_sources']=after
host['main_syntax']['current_atomic_checked']=True
host['main_syntax']['current_atomic_check']='Strict CUDA consumer compile plus actual one-process ordinary CUDA run, not the earlier CPU /Zs'
host['changes'][-1]='prepare_cache publishes locally prepared schema/target/draft inventories and known bytes atomically, with completion sentinel last; actual same-Model failures/retry checked'
host['limits'][0]='Exactly 3 refreshed core TUs, original private host 8 tests, 4 formal TU strict-only checks, one final CUDA consumer TU and one CUDA process; first consumer missing-include compile preserved'
host['GPU']=1
host['formal_regressions']=read(F/'syntax1/summary.json')
ready=read(D/'dual-cuda2/ready.json');actual=read(D/'dual-cuda2/run/stdout.log')
assert actual['status']=='PASS'
stages=[]
for line in (D/'dual-cuda2/run/stderr.log').read_text(errors='replace').splitlines():
    found=re.fullmatch(r'cache_budget_stage=(\S+) live=(\d+) peak=(\d+) limit=(\d+)',line)
    if found:stages.append(dict(stage=found[1],live=int(found[2]),peak=int(found[3]),limit=int(found[4])))
host['cuda']=dict(ready=ready,compile=read(D/'dual-cuda2/compile/process.json'),
    link=read(D/'dual-cuda2/link/process.json'),run=read(D/'dual-cuda2/run/process.json'),actual=actual,
    stages=stages,scope='Original generated A-only H64/V64/FFN128 BF16 fixture, C16/P2/N1R1 per Model; not original artifact/quality/TPS',
    deliberate_pressure='ResourceBudget::Reservation pressure is accounting/admission credit, not claimed allocated physical memory; the 134217727 peak includes this credit',
    local_rejection='First payload under original local device cap; metadata system row remains locally unlimited on CUDA',
    aggregate_rejection='Shared aggregate leaves one byte; actual failure is batch schema metadata, no claim of a specific bank',
    actual_source_delta=8194,raw_stdout=pin(D/'dual-cuda2/run/stdout.log'))
host['first_failures'].append(dict(attempt='dual-cuda1',result='Compile exit2, no GPU',
    reason='Consumer old-page observation lacked detail/paged_arena_access.h include; consumer-only explicit include fixed in dual-cuda2, unchanged product source/geometry/quota/assertions'))
host['formal_regression_boundary']='Four existing layer TUs strict compiled only. Private 8-case runtime is retained separately; formal ports were not linked/run.'
host['canonical_integration']=dict(status='ROOT_EXACT_INTEGRATION',paths=11,
    source_map=pin(D/'integration-source-map.json'),receipt=pin(D/'root-integration.json'),
    actual=read(D/'root-integration.json'),extra_build_or_run=False)
save(D/'final-summary.json',host)

cleanup=[]
for folder in [D/'attempt1/tests',D/'attempt1/link',D/'attempt2/tests',D/'attempt2/link']:
    for path in sorted(folder.iterdir()):
        if path.suffix.lower() in ('.obj','.exe','.exp','.lib','.dll'):cleanup.append(pin(path))
save(D/'rebuildable-cleanup-candidates.json',dict(status='LIST_ONLY_NOT_REMOVED',files=cleanup,
    logical_bytes=sum(v['bytes'] for v in cleanup),reason='Superseded failing host fixture objects/images only',
    preserve=['attempt1/{budget,leases,arena}/unit.obj','attempt3/tests/unit.obj','attempt3/link/*',
              'dual-cuda2/compile/unit.obj','dual-cuda2/link/*'],
    execution='Root test.ps1 exact preview/Apply required; this script performs no deletion'))

files=set()
for name in ['before-pins.json','after-pins.json','source.patch','final-before-pins.json','final-after-pins.json',
    'final-source.patch','integration-source-map.json','final-summary.json','summary.json',
    'cache_source_budget_test.cc','dual-cache-consumer.cc','dual-model-cache-case.h','check-dual-cache.py',
    'dual-source-pins.json','check-formal-regressions.py','prepare-formal-regressions.py','check.py',
    'recheck-host.py','check-main.py','summarize.py','source-review-and-host-plan.md',
    'dual-model-next-plan.md','permanent-regression-plan.md','rebuildable-cleanup-candidates.json','publish.py',
    'root-integrate.py','root-integration.json']:
    path=D/name
    if path.exists():files.add(path)
for folder in [D/'before',D/'source',F/'before',F/'source']:
    files.update(p for p in folder.rglob('*') if p.is_file())
for folder in [D/'attempt1',D/'attempt2',D/'attempt3',D/'main-cpu-syntax1',D/'dual-cuda1',D/'dual-cuda2',F/'syntax1']:
    for path in folder.rglob('*'):
        if path.is_file() and path.name in ('command.json','process.json','stdout.log','stderr.log','repository-inputs.json',
            'ready.json','source-pins.json','source.json','link-inputs.json','runtime.json','results.xml','summary.json',
            'checked-main.cc','cache_source_budget_test.cc','dual-cache-consumer.cc','dual-model-cache-case.h',
            'check-dual-cache.py','dual-source-pins.json','text-weights.tsv'):
            files.add(path)
for name in ['before-pins.json','after-pins.json','source.patch']:
    files.add(F/name)
members=[pin(p) for p in sorted(files)]
save(D/'archive-members.json',members)
files.add(D/'archive-members.json')
with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(files):
        assert path.suffix.lower() not in ('.obj','.exe','.dll','.lib','.bin','.pdb','.exp')
        z.write(path,path.relative_to(R).as_posix())
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    for row in members:
        data=z.read(row['path'])
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
host['archive']=dict(**pin(ARCHIVE),members=len(files),logical_bytes=sum(p.stat().st_size for p in files),CRC=True,member_sha256=True)
host['cleanup']=read(D/'rebuildable-cleanup-candidates.json')
save(PUBLIC,host)
print(json.dumps(dict(public=pin(PUBLIC),archive=host['archive'],canonical_paths=len(after),
    host_tests=8,formal_strict_TUs=4,actual_CUDA_processes=1,canonical_modified_by_root=True),indent=2))
