# Proposed one-process CUDA continuation; not built or run

Reuse the original Batch1 generated A-only H64/V64/FFN128 13-role BF16 payload,
original C16/P2/N1R1 geometry, SDK/vendor closure and the three checked new core
objects. One consumer TU only after root approval. No quality/TPS/real-artifact
claim. No GDN or MTP matrix; recurrent-pool branches remain compile-only.

1. Prepare two original CUDA Backends, then one explicit actual-resource scope
   G with nominated device/staging/system rows and a finite 128MiB aggregate.
   Construct A/B with unchanged finite per-Model local cache cap (e.g. 64KiB,
   sufficient for this tiny geometry). Weights continue using G only; local
   cache counters keep their original policy meaning.
2. Keep A cache unprepared. L=its original cache budget. Temporarily reserve
   `L.device.limit-live-(K-1)` with its original Reservation, where K is the
   actual first key-bank capacity from A.cache_plan. G stays ample. On
   A.prepare_cache(), the local system metadata row is unlimited on CUDA,
   schema succeeds, and first payload reserve rejects. Assert no schema,
   inventories, capacity or known-cache completion is published, and live
   counters return to the pre-call baseline (including the explicit credit).
   Release this L reservation. This is a reservation pressure test, not
   unallocated bytes claimed as physical storage.
3. Reserve `G.shared_available-1` in its nominated system row. L now has ample
   device space. The same A.prepare_cache rejects under G (possibly at schema
   metadata; do not claim a particular bank). Assert the same unpublished
   sentinel/empty tuple and rollback. Release the G reservation. No threshold
   search, geometry change or new fixture identity is needed.
4. Retry A.prepare_cache on the same Model; require success. Compare actual
   per-device external-source usage before/after with the exact key+value bank
   capacities and original known_cache_backing_bytes. L counts its cache once;
   G counts the same original source backing once, with metadata separately.
   Only source factories are claimed, not missing generated-result retention.
5. Continue the existing ordinary A/B prefill/decode/cancel-retire journey.
   Keep B's original whole head/pending/RNG unchanged during A admission errors.
   Preserve one actual A Snapshot (therefore its original ColdResources owner)
   across A stop/retirement/Model destruction; verify its cache bytes/old values
   remain readable and charged. Drop that escaped reader, require actual A
   source release, then finish B's previously submitted work and a continuation.
   Original controller/context/stream and finite quota assertions remain.
6. Require original final G control baseline after all Models/readers retire.
   Physical completion at A teardown stays unknown unless actually observed;
   cancellation is not retirement proof. Keep failed attempts raw and do not
   automatically retune quota or retry the process.

Before running: root reviews the atomic prepare_cache main delta, then one
relevant strict CPU syntax check records that new main (the earlier /Zs was
before this edit). Native generated-output second-scope export is a separate
Graph seam; do not expand the current checked core closure while testing this
source-only admission continuation.
