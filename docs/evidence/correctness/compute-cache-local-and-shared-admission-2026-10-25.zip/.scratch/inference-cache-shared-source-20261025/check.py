from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
OUT=D/(sys.argv[1] if len(sys.argv)>1 else 'attempt1');OUT.mkdir(exist_ok=False)
base=R/'.scratch/inference-shared-budget-engine-20261025/batch1/host-final1'
old=b.args(R/'.scratch/lease-budget-deallocation-order-20261025/implementation/attempt1/leases/command.json')
flags=[];skip=False
for word in old[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    n=word.lower().replace('\\','/')
    if n.startswith(('/fo','/fd')) or n.endswith(('.cc','.cpp')):continue
    if n.startswith('/i') and '/.scratch/' in n:continue
    flags.append(word)
flags=['/I'+str(D/'source/include'),'/I'+str(R/'src/compute_batch'),*flags]
env=b.environment(old[0])
sources=[('budget',D/'source/src/compute/resource_budget.cc'),
         ('leases',D/'source/src/compute/resource_leases.cc'),
         ('arena',D/'source/src/compute_batch/paged_arena.cc'),
         ('tests',D/'cache_source_budget_test.cc')]
frozen=[b.pin(p) for _,p in sources]+[b.pin(D/'source'/p['path']) for p in b.read(D/'after-pins.json')]
b.save(OUT/'source-pins.json',frozen)
objects=[]
for name,source in sources:
    folder=OUT/name
    b.execute([old[0],*flags,str(source),'/sourceDependencies',str(folder/'dependencies.json'),
               '/Fo'+str(folder/'unit.obj')],folder,env,120)
    deps=b.read(folder/'dependencies.json')['Data']
    actual=[Path(deps['Source']),*(Path(p) for p in deps['Includes'])]
    b.save(folder/'repository-inputs.json',[b.pin(p) for p in actual if p.is_relative_to(R)])
    objects.append(folder/'unit.obj')
assert frozen==[b.pin(Path(p['path'])) for p in frozen]
oldlink=b.args(base/'link/command.json');args=[];removed=[]
ends=['/lease-budget-deallocation-order-20261025/implementation/attempt1/budget/unit.obj',
      '/lease-budget-deallocation-order-20261025/implementation/attempt1/leases/unit.obj',
      '/compute_batch--paged_arena.obj','/host-final1/compile/unit.obj']
for word in oldlink[1:]:
    n=word.lower().replace('\\','/')
    if any(n.endswith(end) for end in ends):removed.append(word);continue
    if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
    args.append(word)
assert len(removed)==4,removed
b.save(OUT/'link-inputs.json',dict(original=b.pin(base/'link/command.json'),removed=removed,
    replacements=[b.pin(p) for p in objects]))
args.extend(str(p) for p in objects)
args.extend(str(R/'.scratch/build-compute-v2-dev/lib'/name) for name in ['gtest.lib','gtest_main.lib'])
b.execute([oldlink[0],*args,'/OPT:REF','/OUT:'+str(OUT/'link/checks.exe'),
           '/IMPLIB:'+str(OUT/'link/checks.lib')],OUT/'link',env,120)
native=R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,OUT/'link'/native.name)
env=os.environ.copy();env['PATH']=b.read(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')['PATH']
b.save(OUT/'ready.json',dict(image=b.pin(OUT/'link/checks.exe'),native=b.pin(native),
    core_TUs=3,test_TUs=1,SDK_build=0,GPU=0,HTTP=0))
b.execute([str(OUT/'link/checks.exe'),'--gtest_filter=CacheSourceBudget.*',
           '--gtest_output=xml:'+str(OUT/'results.xml')],OUT/'run',env,60)
