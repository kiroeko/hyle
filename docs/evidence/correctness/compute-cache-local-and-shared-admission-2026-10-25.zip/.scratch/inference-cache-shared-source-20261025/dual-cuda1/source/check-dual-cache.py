"""One strict consumer TU and old CUDA closure; run is separately explicit."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
BASE=R/'.scratch/inference-shared-budget-engine-20261025/batch1/cuda-final1'
OUT=D/'dual-cuda1'
CORE=[D/'attempt1/budget/unit.obj',D/'attempt1/leases/unit.obj',D/'attempt1/arena/unit.obj']

def compile_link():
    OUT.mkdir(exist_ok=False)
    old=b.args(BASE/'compile/command.json');flags=[];skip=False
    for word in old[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        n=word.lower().replace('\\','/')
        if n.startswith(('/fo','/fd')) or n.endswith(('.cc','.cpp')):continue
        flags.append(word)
    frozen=b.read(D/'dual-source-pins.json')
    for row in frozen:
        assert b.pin(Path(row['path']))==row
    env=b.environment(old[0])
    b.execute([old[0],'/I'+str(D/'source/include'),'/I'+str(D/'source'),*flags,
        str(D/'dual-cache-consumer.cc'),'/sourceDependencies',str(OUT/'compile/dependencies.json'),
        '/Fo'+str(OUT/'compile/unit.obj')],OUT/'compile',env,120)
    deps=b.read(OUT/'compile/dependencies.json')['Data']
    b.save(OUT/'compile/repository-inputs.json',[b.pin(p) for p in
        [Path(deps['Source']),*(Path(v) for v in deps['Includes'])] if p.is_relative_to(R)])
    for row in frozen:assert b.pin(Path(row['path']))==row
    oldlink=b.args(BASE/'link/command.json');args=[];removed=[]
    suffixes=['/lease-budget-deallocation-order-20261025/implementation/attempt1/budget/unit.obj',
              '/lease-budget-deallocation-order-20261025/implementation/attempt1/leases/unit.obj',
              '/compute_batch--paged_arena.obj','/batch1/cuda-final1/compile/unit.obj']
    for word in oldlink[1:]:
        n=word.lower().replace('\\','/')
        if any(n.endswith(s) for s in suffixes):removed.append(word);continue
        if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
        args.append(word)
    assert len(removed)==4,removed
    b.save(OUT/'link-inputs.json',dict(original=b.pin(BASE/'link/command.json'),removed=removed,
        core=[b.pin(p) for p in CORE],consumer=b.pin(OUT/'compile/unit.obj')))
    b.execute([oldlink[0],*args,*map(str,CORE),str(OUT/'compile/unit.obj'),'/OPT:REF',
        '/OUT:'+str(OUT/'link/consumer.exe'),'/IMPLIB:'+str(OUT/'link/consumer.lib')],OUT/'link',env,120)
    native=R/'.scratch/inference-system-review-20261025/schedule-inputs/link/hyle_ggml_cpu_gdn_scale_v3.dll'
    os.link(native,OUT/'link'/native.name)
    b.save(OUT/'ready.json',dict(image=b.pin(OUT/'link/consumer.exe'),native=b.pin(native),
        core_objects=[b.pin(p) for p in CORE],consumer_TUs=1,SDK_build=0,HTTP=0,GPU_run=False))

def run():
    env=os.environ.copy();runtime=R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json'
    env.update({k:v for k,v in b.read(runtime).items() if isinstance(v,str)})
    env['PATH']=str(OUT/'link')+';'+env['PATH']
    b.save(OUT/'runtime.json',dict(PATH=env['PATH'],original=b.pin(runtime)))
    (OUT/'output').mkdir(exist_ok=False)
    b.execute([str(OUT/'link/consumer.exe'),str(R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture/weights.tsv'),
        str(OUT/'output')],OUT/'run',env,180)

assert len(sys.argv)==2 and sys.argv[1] in ('build','run')
if sys.argv[1]=='build':compile_link()
else:run()
