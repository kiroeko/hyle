from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=b.args(R/'.scratch/inference-shared-budget-engine-20261025/batch1/host-final1/compile/command.json')
flags=[];skip=False
for word in old[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    n=word.lower().replace('\\','/')
    if n.startswith(('/fo','/fd')) or n.endswith(('.cc','.cpp')):continue
    if n.startswith('/i') and '/.scratch/' in n:continue
    flags.append(word)
out=D/'main-cpu-syntax1';source=D/'source/engine/models/qwen35/main.cc'
before=b.pin(source)
b.execute([old[0],'/I'+str(D/'source/include'),*flags,'/Zs',str(source),
    '/sourceDependencies',str(out/'dependencies.json')],out,b.environment(old[0]),120)
assert before==b.pin(source)
deps=b.read(out/'dependencies.json')['Data']
b.save(out/'repository-inputs.json',[b.pin(p) for p in [Path(deps['Source']),*(Path(v) for v in deps['Includes'])] if p.is_relative_to(R)])
b.save(out/'source.json',before)
