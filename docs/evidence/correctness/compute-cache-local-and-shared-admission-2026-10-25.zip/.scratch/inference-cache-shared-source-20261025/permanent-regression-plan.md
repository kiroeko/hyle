# Keep the tested contracts in their existing layer targets

The eight checked private bodies remain frozen; no formal port is performed yet.
No new test target or Engine dependency is necessary.

- `tests/compute/retained_lease_budget_test.cc`: the four source-pool cases
  (independent payload gates, post-allocation failure/free order, independent
  canonical host alias/subview, empty/same/additional-only scope). Reuse its
  actual MemoryResource/deallocation witness; the small allocation fault probe
  can remain local to this existing TU. No Graph/PagedArena/Engine includes.
- `tests/compute/shared_backing_budget_test.cc`: nested metadata grow/shrink/free
  and second-gate rejection rollback, reusing its allocator probe. This is only
  ResourceBudget/Allocator behavior, not Graph or a cache policy.
- `tests/compute_batch/paged_arena_test.cc`: whole original backing admission in
  both scopes, no per-page double charge, escaped page retains source capacity.
  Use its existing BatchCapacity and original page publication fixture.
- `tests/graph/executable_test.cc` (already the CPU executable target): the two
  actual constant ownership regressions. Replace private Engine Backend only
  with existing `cpu_context_fixture.h` / `test_environment.h` and ordinary
  `graph::compile(graph, context, options)`, keeping the source-alias submission
  and GraphOutput::storage_lease(local) as the exact charge-adoption point.
  Unknown custom allocator without owner remains rejected. No GraphBatch or
  Engine link dependency is added. `constant_artifact_cache_test.cc` is in the
  same target, but executable_test already has the real compile fixture.

All four files are already registered. Formal adapter changes require finite
strict compilation; their existing private runtime is not automatically a
claim that the ported source was run. Root chooses that next boundary.
