from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
root = base.parents[1]

def read(path):
    return json.loads(path.read_bytes())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def lf(data):
    return data.replace(b'\r\n', b'\n')

host = ET.parse(base / 'attempt3/results.xml').getroot()
assert int(host.attrib['tests']) == 8
assert int(host.attrib['failures']) == int(host.attrib.get('errors', 0)) == 0
for name in ('attempt3/run/process.json', 'dual-cuda2/run/process.json'):
    path = base / name
    if path.exists():
        result = read(path)
        assert result['exit'] == 0 and not result['timeout'], name
actual = [json.loads(line) for line in (base / 'dual-cuda2/run/stdout.log').read_text().splitlines()
          if line.startswith('{')][-1]
assert actual['status'] == 'PASS' and actual['models'] == 2 and actual['C'] == 16
for name in ('same_A_local_failure', 'same_A_aggregate_failure', 'same_A_retry_success',
             'escaped_reader_kept_source_charge', 'A_last_reader_scope_released', 'B_continued'):
    assert actual[name] is True, name
assert actual['partial_source_publication'] is False
assert actual['shared_final_baseline'] == 1184 and actual['cache_source_bytes_A'] == 8194
formal = read(base / 'formal-regressions/syntax1/summary.json')
assert formal['strict_compile_only'] and not formal['run'] and len(formal['paths']) == 4
strict = {item['source']['path']: item for item in formal['paths']}
assert all(item['process']['exit'] == 0 and not item['process']['timeout'] for item in strict.values())

changes = []
for directory, expected in ((base, 7), (base / 'formal-regressions', 4)):
    before = {item['path']: item for item in read(directory / 'before-pins.json')}
    after = read(directory / 'after-pins.json')
    assert len(before) == len(after) == expected
    for pin in after:
        name = pin['path']
        target = (root / name).resolve()
        assert target.is_relative_to(root) and not target.is_symlink()
        original = target.read_bytes()
        assert len(original) == before[name]['bytes'] and sha(original) == before[name]['sha256'], name
        selected = (directory / 'source' / name).read_bytes()
        assert len(selected) == pin['bytes'] and sha(selected) == pin['sha256'], name
        if name in strict:
            assert strict[name]['source']['sha256'] == pin['sha256'], name
        ending = b'\r\n' if b'\r\n' in original else b'\n'
        output = lf(selected).replace(b'\n', ending)
        changes.append((target, output, dict(path=name, bytes=len(output),
            before_sha256=sha(original), after_sha256=sha(output),
            checked_private_raw_sha256=sha(selected), normalized_source_equal=True)))
assert len(changes) == 11
for target, output, _ in changes:
    target.write_bytes(output)
result = dict(status='INTEGRATED_REVIEWED_SOURCE_CACHE_DUAL_CONSTRAINT',
    files=[item for _, _, item in changes],
    checked='Private eight host cases, current atomic main compiled by one CUDA consumer TU, one original C16 dual-Model CUDA process, four formal layer TUs strict compile only.',
    root_review='Both payload gates before actual source allocation; same identity and charge transfer without reservation gap; actual backing release before quota return; known budget allocator unwrapping only; complete cold cache tuple published atomically with schema sentinel last.',
    further_build_or_run=False,
    remaining='Generated native output exports still lack the second retention scope. GDN state source call sites compiled but not exercised by this A-only fixture. No whole-model, cross-platform runtime, physical VRAM cap or throughput claim.')
(base / 'root-integration.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status=result['status'], paths=len(changes), formal_runtime=False)))
