#pragma once

#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/detail/paged_arena_access.h"

// This is a source-only continuation of the checked Batch1 A-only C16 case.
namespace qwen_cache_budget_case {
namespace q=qwen35;
namespace i=hyle::inference;
namespace {
void require(bool value,const char *message){if(!value)throw std::runtime_error(message);}
struct Endpoint final {
  std::uintptr_t wrapper=0,context_owner=0,queue_wrapper=0,primary=0,stream=0,cold_resources=0;
  int device_ordinal=0;
  friend bool operator==(const Endpoint &,const Endpoint &)=default;
};
Endpoint endpoint(q::Model &model){
  auto *context=q::take(model.execution.common_context());auto *queue=q::take(model.execution.common_queue());
  return {reinterpret_cast<std::uintptr_t>(context),
      reinterpret_cast<std::uintptr_t>(model.execution.storage_owner().context_identity()),
      reinterpret_cast<std::uintptr_t>(queue),
      reinterpret_cast<std::uintptr_t>(q::take(q::c::cuda::primary_context(*context))),
      reinterpret_cast<std::uintptr_t>(q::take(q::c::cuda::stream(*queue))),
      reinterpret_cast<std::uintptr_t>(model.resources_.get()),q::take(q::c::cuda::device_ordinal(context->device()))};
}
void normal_retire(q::GenerationRequest &request){
  q::check(request.session->stop());q::check(request.session->drain());
  require(q::take(request.session->try_retire()),"normal payload did not retire");request.session.reset();
}
void expected_cancel(const hyle::Status &status){
  if(!status.IsCancelled()||status.has_native_error())q::check(status);
}
std::size_t external(const q::c::ResourceBudget &scope,hyle::mem::MemoryResourceRef resource){
  return q::take(scope.usage(resource)).live_by_category[
      static_cast<std::size_t>(q::c::ResourceBudgetCategory::kExternal)];
}
std::vector<std::vector<std::byte>> committed_pages(const q::cache::Snapshot &head){
  std::vector<std::vector<std::byte>> result;
  const auto append=[&](const q::c::PagedArenaRead &frame){
    for(const auto &lease:q::c::detail::PagedArenaAccess::pages(frame)){
      auto &bytes=result.emplace_back(lease.size());q::check(q::take(lease.view()).read(bytes));
    }
  };
  for(std::size_t layer=0;layer<head.keys.size();++layer){append(head.keys[layer]);append(head.values[layer]);}
  return result;
}
void require_unprepared(const q::Model &model){
  require(!model.attention_schema.valid()&&model.page_inventory.keys.empty()&&model.page_inventory.values.empty()&&
      model.page_inventory.owners.empty()&&model.page_inventory.free_ids.empty()&&!model.page_inventory.active_layers&&
      model.draft_inventory.keys.empty()&&model.draft_inventory.values.empty()&&
      !model.known_cache_backing_bytes&&!model.snapshot_versions.capacity&&!model.state_storage_prepared,
      "failed cache preparation published a partial source tuple");
}
}

inline int run(const std::filesystem::path &manifest){try{
  constexpr std::size_t local_limit=64u<<10,aggregate_limit=128u<<20;
  const auto geometry=q::read_weight_geometry(manifest);
  const std::vector<std::int32_t> prompt{1,2};
  const auto plan=q::cache::plan(geometry,16,1,2,q::recurrent_bytes(q::state_schema_for(geometry,16),geometry),1,1,false,true);
  const auto endpoint_for=[&]{return q::create_execution(geometry,plan,0,{.primary=q::BackendKind::kCuda});};
  const auto make_scope=[&](std::span<const hyle::mem::MemoryResourceRef> resources){
    std::vector<q::c::ResourceBudgetLimit> limits;std::vector<hyle::mem::MemoryResourceRef> rows;
    for(auto resource:resources)if(std::ranges::find(rows,resource)==rows.end()){rows.push_back(resource);limits.push_back({resource});}
    return q::take(q::c::ResourceBudget::create({.limits=limits,.allow_unattributed=true},rows,aggregate_limit));
  };
  const auto make_model=[&](q::Backend &&backend,const q::c::ResourceBudget &scope){
    return std::make_unique<q::Model>(std::move(backend),scope,q::prepare_weight_source(manifest,false),geometry,16,plan,
        std::filesystem::path{},true,q::ReplayPolicy::kCommands,local_limit,
        q::Model::Sampling{.enabled=true,.policy={1,8,.9F},.seed=123},0);
  };
  auto backend_a=endpoint_for(),backend_b=endpoint_for();
  auto scope=make_scope(std::array{backend_a.device(),backend_a.staging(),backend_b.device(),backend_b.staging(),hyle::mem::system_resource()});
  const auto scope_baseline=scope.shared_usage()->live_bytes;
  const auto scope_stage=[&](const char *stage){const auto value=*scope.shared_usage();
    require(value.live_bytes<=value.limit_bytes&&value.peak_bytes<=value.limit_bytes,"finite shared requested byte gate was exceeded");
    std::cerr<<"cache_budget_stage="<<stage<<" live="<<value.live_bytes<<" peak="<<value.peak_bytes<<" limit="<<value.limit_bytes<<'\n';};
  auto model_a=make_model(std::move(backend_a),scope),model_b=make_model(std::move(backend_b),scope);
  const auto a_endpoint=endpoint(*model_a),b_endpoint=endpoint(*model_b);
  require(a_endpoint.wrapper!=b_endpoint.wrapper&&a_endpoint.context_owner!=b_endpoint.context_owner&&
      a_endpoint.queue_wrapper!=b_endpoint.queue_wrapper&&a_endpoint.stream&&b_endpoint.stream&&a_endpoint.stream!=b_endpoint.stream&&
      a_endpoint.cold_resources!=b_endpoint.cold_resources,"Models do not retain independent original endpoints");
  require(a_endpoint.device_ordinal==0&&b_endpoint.device_ordinal==0,"Models did not select the same CUDA device");
  require(model_a->source_identity==model_b->source_identity&&model_a->math_identity()!=model_b->math_identity(),"source/model identities were conflated");
  const auto prepare_model=[&](q::Model &model){
    require(model.physical_text_roles==13&&!model.physical_mtp_roles&&!model.cache_plan.draft_cache,"unexpected Text source roles");
    const std::array shapes{std::size_t{2},std::size_t{1}};model.prepare_family(shapes);
    for(auto rows:shapes)model.plan_replay_uses(rows,1,4);model.prepare_execution(shapes);
  };
  const std::array turns{i::GenerationTurn{prompt,3}};
  q::GenerationRequest a("A",prompt,{},3),b("B",prompt,{},3);
  for(auto *request:{&a,&b}){
    request->progress.bind_turns(turns);request->progress.initial_sampling={123,request==&a?100ULL:101ULL,0};
    request->ledger=std::make_unique<q::GenerationLedger>(q::generation_record_capacity(turns),1);
    request->round_emitted.resize(2);for(auto &row:request->round_emitted)row.reserve(1);
    request->turn_observations.resize(1);request->warm_inputs.push_back(std::make_shared<std::vector<std::int32_t>>(prompt));
    request->prompt=request->progress.begin_turn(*request->warm_inputs[0]);
  }
  const auto prepare=[&](q::Model &model,q::GenerationRequest &request){return q::prepare_generation_call(model,request,request.progress.output_limit(),nullptr,{},1);};
  const auto execute=[&](q::Model &model,q::GenerationRequest &request){std::array calls{prepare(model,request)};q::execute_generation_calls(model,calls,false);};
  // B owns a real complete head while A fails only cold source admission.
  prepare_model(*model_b);execute(*model_b,b);
  const auto *head_b=b.session->head.get();const auto b_boundary=q::generation_boundary(*head_b);
  const auto b_unchanged=[&]{
    require(b.session->head.get()==head_b&&q::generation_boundary(*head_b)==b_boundary&&
        b.ledger->committed_count==1&&b.progress.observed_commits()==1&&b.progress.generated.size()==1&&
        !model_b->active_step&&endpoint(*model_b)==b_endpoint,"A admission failure changed B complete state/pending/RNG");
  };
  require_unprepared(*model_a);const auto resource_a=model_a->execution.device();
  const auto local_base=q::take(model_a->cache_budget.usage(resource_a));
  require(plan.key_bank_bytes>1&&local_base.live_bytes+plan.key_bank_bytes<=local_base.limit_bytes,"tiny finite local cap is insufficient");
  {
    auto credit=q::take(model_a->cache_budget.reserve(resource_a,local_base.limit_bytes-local_base.live_bytes-(plan.key_bank_bytes-1)));
    const auto pressured=q::take(model_a->cache_budget.usage(resource_a));const auto global_before=scope.shared_usage()->live_bytes;
    bool failed=false;try{model_a->prepare_cache();}catch(const std::runtime_error &error){failed=true;std::cerr<<"expected_local_cache_rejection="<<error.what()<<'\n';}
    require(failed,"local cache gate did not reject");require_unprepared(*model_a);
    require(q::take(model_a->cache_budget.usage(resource_a)).live_bytes==pressured.live_bytes&&
        scope.shared_usage()->live_bytes==global_before,"local rejection leaked cold metadata or payload charges");b_unchanged();
  }
  require(q::take(model_a->cache_budget.usage(resource_a)).live_bytes==local_base.live_bytes,"local admission credit did not release");
  {
    const auto usage=*scope.shared_usage();require(usage.limit_bytes>usage.live_bytes+1,"insufficient shared credit fixture");
    auto credit=q::take(scope.reserve(hyle::mem::system_resource(),usage.limit_bytes-usage.live_bytes-1));
    const auto pressured=scope.shared_usage()->live_bytes;
    bool failed=false;try{model_a->prepare_cache();}catch(const std::runtime_error &error){failed=true;std::cerr<<"expected_aggregate_cache_rejection="<<error.what()<<'\n';}
    require(failed,"shared aggregate gate did not reject");require_unprepared(*model_a);
    require(scope.shared_usage()->live_bytes==pressured&&q::take(model_a->cache_budget.usage(resource_a)).live_bytes==local_base.live_bytes,
        "aggregate rejection leaked source admission");b_unchanged();
  }
  const auto global_device_before=external(scope,resource_a);
  model_a->prepare_cache();const auto cache_source_bytes=model_a->known_cache_backing_bytes;
  require(model_a->attention_schema.valid()&&model_a->snapshot_versions.capacity==plan.snapshot_slots&&
      cache_source_bytes==(plan.key_bank_bytes+plan.value_bank_bytes)*model_a->target_kv_layers&&
      external(model_a->cache_budget,resource_a)==cache_source_bytes&&
      external(scope,resource_a)-global_device_before==cache_source_bytes,"same Model retry did not admit each actual cache source once");
  scope_stage("A_cache_retry_success");b_unchanged();
  prepare_model(*model_a);execute(*model_a,a);
  require(a.session->head->sampling.draw==1&&a.ledger->committed_count==1,"A retry did not execute its original prefill");
  auto escaped=a.session->head;const auto old_pages=committed_pages(*escaped);
  const auto a_boundary=q::generation_boundary(*escaped);const auto *head_a=escaped.get();
  auto *local_a=&model_a->cache_budget;
  const auto old_local_external=external(*local_a,resource_a),old_global_external=external(scope,resource_a);
  auto a_call=prepare(*model_a,a),b_call=prepare(*model_b,b);
  for(auto *call:{&a_call,&b_call})q::prepare_generation_record(*call->request->ledger,*call->request->session,q::GraphRole::kText,
      call->ids(),true,call->quota,0,{},0,call->completion,call->input_begin,call->prefill_complete);
  model_a->prepare_evaluation(*a.session,a_call.ids());model_a->submit_evaluation(*a.session);
  model_b->prepare_evaluation(*b.session,b_call.ids());model_b->submit_evaluation(*b.session);
  require(model_a->active_step&&model_b->active_step&&a.session->pending==model_a->active_step.get()&&b.session->pending==model_b->active_step.get(),
      "two Models lost their independent submitted episodes");
  const bool a_inflight=model_a->active_step->run->in_flight(),b_inflight=model_b->active_step->run->in_flight();
  auto *b_pending=b.session->pending;std::weak_ptr<q::ColdResources> a_resources=model_a->resources_;
  expected_cancel(a.session->stop());expected_cancel(model_a->abort_episode());
  require(!model_a->active_step&&!a.session->pending&&a.session->head.get()==head_a&&q::generation_boundary(*head_a)==a_boundary&&
      a.ledger->committed_count==1&&!a.ledger->records[1].committed,"cancelled A published new state/output/RNG");
  require(q::take(a.session->try_retire()),"A did not actually retire");a.session.reset();model_a.reset();
  require(!a_resources.expired()&&external(*local_a,resource_a)==old_local_external&&external(scope,resource_a)>=old_global_external&&
      committed_pages(*escaped)==old_pages,"escaped A reader lost original pages, source charges or cold resource owner");
  const auto escaped_live=scope.shared_usage()->live_bytes;
  escaped.reset();require(a_resources.expired()&&scope.shared_usage()->live_bytes<escaped_live,"last A snapshot did not release original source scope");
  scope_stage("A_last_reader_retired_B_live");
  require(model_b->active_step&&b.session->pending==b_pending&&b.session->head.get()==head_b&&
      q::generation_boundary(*head_b)==b_boundary&&b.ledger->committed_count==1&&!b.ledger->records[1].committed&&
      b.progress.generated.size()==1&&b.session->retirement_status.ok()&&endpoint(*model_b)==b_endpoint,"A retirement invalidated B episode/head/ledger/RNG");
  (void)q::finish_evaluation(*model_b,*b.session,"Bdecode1",{},false,&b_call.step_seconds,&b.endpoint,nullptr,nullptr,{},b.ledger.get());
  q::finish_generation_call(*model_b,b_call,nullptr);
  require(b.ledger->committed_count==2&&b.progress.observed_commits()==2&&b.progress.generated.size()==2&&b.session->head->sampling.draw==2&&
      b.ledger->records[1].pending_input==b_boundary.next_id&&b.session->length()==3,"B submitted episode failed after A final reader retirement");
  const auto pending=b.session->head->next_id;execute(*model_b,b);
  require(b.progress.request_done()&&b.ledger->committed_count==3&&b.progress.observed_commits()==3&&b.session->head->sampling.draw==3&&
      b.session->length()==4&&b.ledger->records[2].pending_input==pending&&b.session->retirement_status.ok()&&endpoint(*model_b)==b_endpoint,
      "B could not continue after A destruction");
  const auto ids=b.progress.generated;normal_retire(b);model_b.reset();scope_stage("all_retired");
  require(scope.shared_usage()->live_bytes==scope_baseline,"retired Models leaked the shared scope");
  std::cout<<"{\"status\":\"PASS\",\"ordinary\":true,\"models\":2,\"P\":2,\"C\":16,\"N_each\":1,\"R_each\":1,\"physical_text_roles_each\":13,\"physical_mtp_roles_each\":0"
      <<",\"local_cache_limit_each\":"<<local_limit<<",\"shared_limit\":"<<aggregate_limit<<",\"cache_source_bytes_A\":"<<cache_source_bytes
      <<",\"same_A_local_failure\":true,\"same_A_aggregate_failure\":true,\"same_A_retry_success\":true,\"partial_source_publication\":false"
      <<",\"escaped_reader_kept_source_charge\":true,\"A_last_reader_scope_released\":true,\"B_continued\":true,\"A_draw\":1,\"B_draw\":3,\"B_committed_records\":3"
      <<",\"A_logical_inflight_at_cancel\":"<<(a_inflight?"true":"false")<<",\"B_logical_inflight_before_A_teardown\":"<<(b_inflight?"true":"false")
      <<",\"physical_GPU_completion_at_A_teardown\":\"unknown\",\"generated_export_second_scope\":\"not_implemented\",\"shared_final_baseline\":"<<scope_baseline<<",\"B_ids\":[";
  for(std::size_t at=0;at<ids.size();++at)std::cout<<(at?",":"")<<ids[at];std::cout<<"]}\n";return 0;
}catch(const std::exception &error){std::cerr<<"cache_dual_model_failure="<<error.what()<<'\n';return 1;}}
} // namespace qwen_cache_budget_case
