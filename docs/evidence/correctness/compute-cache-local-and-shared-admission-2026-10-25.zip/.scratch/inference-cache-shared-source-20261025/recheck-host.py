from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
OUT=D/sys.argv[1];OUT.mkdir(exist_ok=False)
old=b.args(D/'attempt1/tests/command.json');command=[];skip=False
for word in old:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    if word.lower().startswith(('/fo','/fd')):continue
    command.append(word)
env=b.environment(command[0]);before=b.pin(D/'cache_source_budget_test.cc')
b.execute([*command,'/sourceDependencies',str(OUT/'tests/dependencies.json'),
    '/Fo'+str(OUT/'tests/unit.obj')],OUT/'tests',env,120)
assert before==b.pin(D/'cache_source_budget_test.cc')
oldlink=b.args(D/'attempt1/link/command.json');args=[];removed=[]
for word in oldlink[1:]:
    n=word.lower().replace('\\','/')
    if n.endswith('/inference-cache-shared-source-20261025/attempt1/tests/unit.obj'):removed.append(word);continue
    if n.startswith(('/out:','/pdb:','/map:','/implib:')):continue
    args.append(word)
assert len(removed)==1
b.execute([oldlink[0],*args,str(OUT/'tests/unit.obj'),'/OUT:'+str(OUT/'link/checks.exe'),
    '/IMPLIB:'+str(OUT/'link/checks.lib')],OUT/'link',env,120)
native=R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
os.link(native,OUT/'link'/native.name)
env=os.environ.copy();env['PATH']=b.read(R/'.scratch/qwen-pure-cpu-deployment-20261024/current1/runtime-environment.json')['PATH']
b.save(OUT/'ready.json',dict(image=b.pin(OUT/'link/checks.exe'),source=before,
    reused_core_objects=[b.pin(D/'attempt1'/name/'unit.obj') for name in ('budget','leases','arena')],native=b.pin(native)))
b.execute([str(OUT/'link/checks.exe'),'--gtest_filter=CacheSourceBudget.*',
    '--gtest_output=xml:'+str(OUT/'results.xml')],OUT/'run',env,60)
