"""Strict compile-only ports in their existing layers; no target build or run."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode=True
R=Path.cwd();D=Path(__file__).resolve().parent;F=D/'formal-regressions'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
OUT=F/'syntax1';OUT.mkdir(exist_ok=False)
old=b.args(R/'.scratch/lease-budget-deallocation-order-20261025/implementation/attempt1/retained-tests/command.json')
flags=[];skip=False
for word in old[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    n=word.lower().replace('\\','/')
    if n.startswith(('/fo','/fd')) or n.endswith(('.cc','.cpp')):continue
    if n.startswith('/i') and '/.scratch/' in n:continue
    flags.append(word)
flags=['/I'+str(D/'source/include'),*flags,'/I'+str(R/'tests/compute'),
       '/I'+str(R/'tests/compute_batch'),'/I'+str(R/'tests/graph')]
before=b.read(F/'after-pins.json');env=b.environment(old[0]);rows=[]
for at,row in enumerate(before):
    source=F/'source'/row['path'];assert b.pin(source)['sha256']==row['sha256']
    folder=OUT/str(at)
    b.execute([old[0],*flags,'/Zs',str(source),'/sourceDependencies',str(folder/'dependencies.json')],folder,env,120)
    deps=b.read(folder/'dependencies.json')['Data']
    b.save(folder/'repository-inputs.json',[b.pin(p) for p in
        [Path(deps['Source']),*(Path(v) for v in deps['Includes'])] if p.is_relative_to(R)])
    assert b.pin(source)['sha256']==row['sha256']
    rows.append(dict(source=row,process=b.read(folder/'process.json')))
b.save(OUT/'summary.json',dict(paths=rows,strict_compile_only=True,run=False,
    target_build=False,SDK_build=0,HTTP=0,GPU=0))
