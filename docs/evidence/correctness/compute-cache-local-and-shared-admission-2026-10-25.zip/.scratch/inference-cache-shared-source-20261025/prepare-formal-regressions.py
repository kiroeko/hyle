"""Source-only ports of the eight checked bodies; no build or execution."""
from pathlib import Path
import difflib
import hashlib
import json

R = Path.cwd()
D = Path(__file__).resolve().parent
F = D / 'formal-regressions'
F.mkdir(exist_ok=False)
text = (D / 'cache_source_budget_test.cc').read_text()
names = [
    'EitherPayloadGateRejectsBeforeResourceAllocation',
    'PostAllocationFailuresKeepBothChargesUntilActualFree',
    'CanonicalHostAliasAndSubviewsKeepOneChargeAndNoExportAllocation',
    'EmptyAndSameScopesPreserveNaturalSourcePaths',
    'NestedMetadataGrowthRejectsAndRollsBackBothScopes',
    'SameReadyLeasePreparesTwiceAcrossChargeAdoptionAndNestedMetadata',
    'UnknownAllocatorStillRequiresItsActualOwner',
    'PagedArenaForwardsBothGatesWithoutPerPageCharge',
]
starts = [text.index('TEST(CacheSourceBudget, ' + n + ')') for n in names]
ends = starts[1:] + [text.rindex('} // namespace')]
ends[4] = text.index('struct ConstantGraph final')
tests = [text[a:b].strip() for a, b in zip(starts, ends)]
allocator = text[text.index('struct Allocations final'):text.index('class Source final')]
source = text[text.index('class Source final'):starts[0]]
budget = text[text.index('std::size_t external('):text.index('struct Allocations final')]
same_allocator = text[text.index('bool same_allocator('):text.index('std::size_t external(')]
constant = text[text.index('struct ConstantGraph final'):starts[5]]
aliases = ('namespace c=hyle::compute;\nnamespace d=hyle::compute::detail;\n'
           'namespace m=hyle::mem;\n')

ports = {}
ports['tests/compute/retained_lease_budget_test.cc'] = (
    '#include "hyle/mem/buffer.h"\n', aliases + budget + allocator + source +
    '\n\n'.join(tests[:4]))
metadata = tests[4].replace('Allocations allocation;Source source;', 'Allocations allocation;')
metadata = metadata.replace('budget(source.ref(),', 'budget(m::system_resource(),')
ports['tests/compute/shared_backing_budget_test.cc'] = (
    '', aliases + budget + allocator + metadata)
ports['tests/compute_batch/paged_arena_test.cc'] = (
    '', aliases + budget + source.replace('Allocations *arm_allocator=nullptr;', '')
        .replace('int fail_after=-1;', '')
        .replace('if(arm_allocator)arm_allocator->remaining=fail_after;', '') + tests[7])

graph = '\n\n'.join(tests[5:7])
graph = graph.replace(
    'auto backend=i::Backend::create({.primary=i::BackendKind::kCpu},{}).value();',
    'auto context=g::test::cpu_context().value();\n  auto queue=context.create_queue().value();')
graph = graph.replace(
    'auto context=g::test::cpu_context().value();\n  auto queue=context.create_queue().value();\n'
    '  EXPECT_TRUE(same_allocator',
    'auto context=g::test::cpu_context().value();\n  EXPECT_TRUE(same_allocator')
graph = graph.replace('auto first=backend.compile(source_graph,{});',
    'auto first=g::compile(source_graph,context);')
graph = graph.replace(
    'auto selected=i::prepare_queue_bindings(backend.queue_bindings(),first->report).value();\n'
    '    const auto queues=i::queue_span(selected);',
    'std::vector<g::QueueBinding> queues;\n'
    '    for(std::size_t lane=0;lane<first->report.lane_count();++lane){\n'
    '      const auto facts=first->report.lane(lane).value();\n'
    '      if(facts.queue_required)queues.push_back({facts.lane,&queue});\n'
    '    }')
graph = graph.replace('backend.compile(fixture.graph,std::span(&fixture.binding,1))',
    'g::compile(fixture.graph,context,{.constants=std::span(&fixture.binding,1)})')
ports['tests/graph/executable_test.cc'] = (
    '#include "hyle/compute/detail/lease_access.h"\n'
    '#include "hyle/compute/detail/resource_budget_access.h"\n',
    aliases + 'namespace g=hyle::graph;\n' + same_allocator + budget + allocator + constant + graph)

def pin(path, name):
    data = path.read_bytes()
    return dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

before, after, patch = [], [], ''
for name, (includes, body) in ports.items():
    original = R / name
    old = original.read_bytes()
    before_path, current = F / 'before' / name, F / 'source' / name
    before_path.parent.mkdir(parents=True, exist_ok=True)
    current.parent.mkdir(parents=True, exist_ok=True)
    before_path.write_bytes(old)
    newline = '\r\n' if b'\r\n' in old else '\n'
    suffix = ('\n// Source payload gates and metadata ownership retain their original scopes.\n'
              + includes + '\nnamespace { namespace cache_source_budget {\n' + body +
              '\n} } // namespace cache_source_budget\n')
    current.write_bytes(old + suffix.replace('\n', newline).encode())
    before.append(pin(before_path, name))
    after.append(pin(current, name))
    patch += ''.join(difflib.unified_diff(
        old.decode().replace('\r\n', '\n').splitlines(keepends=True),
        current.read_text().splitlines(keepends=True),
        fromfile='a/' + name, tofile='b/' + name))
(F / 'before-pins.json').write_text(json.dumps(before, indent=2) + '\n')
(F / 'after-pins.json').write_text(json.dumps(after, indent=2) + '\n')
(F / 'source.patch').write_text(patch)
print(json.dumps(dict(paths=len(ports), cases=len(names),
    compiled=False, run=False, Engine_dependency=False), indent=2))
