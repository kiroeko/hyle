from pathlib import Path
import hashlib,json,os,subprocess,time
for name in['HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_DATASETS_OFFLINE']:os.environ[name]='1'
from transformers import AutoTokenizer
from judge import judge
O=Path(__file__).resolve().parent;R=O.parents[1];B=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2'
def read(p):return json.loads(p.read_text(encoding='utf8'))
def identity(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def require(x):
 p=Path(x['path']);actual=identity(p);assert all(x[k]==actual[k]for k in ['bytes','sha256']),p
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
def main():
 ledger_path=O/'generation-ledger.json';assert not ledger_path.exists(),'No automatic retries or additional model runs are permitted'
 frozen=read(O/'pre-generation-freeze.json');plan=read(O/'plan.json')
 for x in [frozen['plan'],frozen['judge'],frozen['python_judge'],frozen['weights_manifest'],*frozen['tokenizer_files']]:require(x)
 for x in frozen['cases']:require(x['prompt']);require(x['rendered'])
 assert read(O/'judge-self-check.json')['checks']==[True]*6
 tokenizer=AutoTokenizer.from_pretrained(plan['tokenizer'],local_files_only=True,trust_remote_code=False)
 image=B/'recursive-probe.exe';image_identity=identity(image);stat=image.stat();image_stat=(stat.st_size,stat.st_mtime_ns)
 ready=read(R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cuda.json');env=dict(os.environ,PATH=str(B)+os.pathsep+ready['PATH'])
 ledger=dict(freeze=identity(O/'pre-generation-freeze.json'),plan_sha256=frozen['plan']['sha256'],image=image_identity,source_snapshot=identity(B/'sources.json'),maximum_model_runs=9,attempts=[])
 save(ledger_path,ledger);results=[];arms={'ordinary':['--mtp','off'],'k1':['--mtp','on'],'k4':['--mtp','on','--mtp-max-drafts','4']}
 for task in plan['tasks']:
  case=next(c for c in frozen['cases']if c['id']==task['id'])
  for arm in plan['arms']:
   assert len(ledger['attempts'])<9 and (image.stat().st_size,image.stat().st_mtime_ns)==image_stat
   folder=O/'results'/(task['id']+'-'+arm);folder.mkdir(parents=True,exist_ok=True);(folder/'tmp').mkdir(exist_ok=True)
   command=[str(image),'--inputs',case['inputs'],'--capacity',str(plan['capacity']),'--steps',str(plan['maximum_output_tokens']),'--cache-bytes',str(plan['cache_bytes']),'--prefix-cache','off','--replay','commands',*arms[arm]]
   entry=dict(task=task['id'],arm=arm,started=time.time(),command=command);ledger['attempts'].append(entry);save(ledger_path,ledger);save(folder/'command.json',dict(command=command,plan_sha256=frozen['plan']['sha256'],prompt_sha256=case['prompt']['sha256'],P=case['prompt_tokens'],C=plan['capacity'],max_output_tokens=plan['maximum_output_tokens'],greedy=True,HTTP=0,SDK_builds=0))
   print('START',task['id'],arm,flush=True);begin=time.time();case_env=dict(env,TEMP=str(folder/'tmp'),TMP=str(folder/'tmp'))
   with (folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:
    process=subprocess.run(command,cwd=R,env=case_env,stdout=out,stderr=err,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
   outcome=dict(exit=process.returncode,seconds=time.time()-begin);save(folder/'process.json',outcome);entry.update(outcome);save(ledger_path,ledger)
   if process.returncode:raise RuntimeError('Native function failure retained; no quality compensating retry')
   rows=[json.loads(line)for line in (folder/'stdout.log').read_text(encoding='utf8').splitlines()if line.startswith('{')];report=rows[-1]
   ids=report['generated_ids'];assert report['generated_tokens']==len(ids)and 0<len(ids)<=128 and report['backend']=='cuda'
   assert report['cache_requested_byte_limit']==plan['cache_bytes']and report['cache_peak_requested_bytes']<=plan['cache_bytes']
   eos=next((i for i,t in enumerate(ids)if t in frozen['EOS_ids']),None);content=ids if eos is None else ids[:eos]
   raw=tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False);text=tokenizer.decode(content,skip_special_tokens=True,clean_up_tokenization_spaces=False)
   assessment=judge(task,text);result=dict(task=task['id'],arm=arm,P=case['prompt_tokens'],C=512,max_output_tokens=128,generated_tokens=len(ids),generated_ids=ids,
    raw_decoded_text=raw,judged_text=text,natural_EOS=eos is not None,EOS_id=ids[eos]if eos is not None else None,stop_reason='natural_EOS'if eos is not None else'output_quota'if len(ids)==128 else'unexpected_short_stop',
    task_passed=bool(assessment['passed']),judge=assessment,native_report=report,command=command,plan_sha256=frozen['plan']['sha256'])
   save(folder/'task-result.json',result);(folder/'decoded.txt').write_text(raw,encoding='utf8');results.append(result)
   save(O/'summary.json',dict(status='RUNNING',completed=len(results),maximum_model_runs=9,results=results));print(json.dumps(dict(task=task['id'],arm=arm,task_passed=result['task_passed'],natural_EOS=result['natural_EOS'],generated_tokens=len(ids))),flush=True)
 require(frozen['plan']);require(frozen['judge']);require(frozen['python_judge']);assert len(ledger['attempts'])==len(results)==9
 summary=dict(status='FIXED_NINE_RUN_TASK_CHECK_COMPLETE',plan_sha256=frozen['plan']['sha256'],completed=9,task_passes=sum(r['task_passed']for r in results),natural_EOS=sum(r['natural_EOS']for r in results),results=results,
  interpretation=plan['interpretation'],performance_claim=False,new_HTTP=0,SDK_builds=0,new_model_runs_after_declared_nine=0)
 save(O/'summary.json',summary);print(json.dumps(dict(status=summary['status'],task_passes=summary['task_passes'],natural_EOS=summary['natural_EOS'],runs=9)))
if __name__=='__main__':main()
