"""Fixed child process. Generated code receives no file/network/command builtins."""
import ast,json,sys,typing,__future__
def main():
 request=json.load(sys.stdin);tree=ast.parse(request['code'])
 allowed=(ast.FunctionDef,ast.AsyncFunctionDef,ast.Import,ast.ImportFrom,ast.Assign,ast.AnnAssign)
 tree.body=[node for node in tree.body if isinstance(node,allowed)or(isinstance(node,ast.Expr)and isinstance(node.value,ast.Constant)and isinstance(node.value.value,str))]
 for node in ast.walk(tree):
  if isinstance(node,(ast.Import,ast.ImportFrom)):
   modules=[a.name for a in node.names]if isinstance(node,ast.Import)else[node.module]
   if any(name not in('typing','__future__')for name in modules):raise ValueError('Only optional typing/future imports are accepted')
  if isinstance(node,ast.Attribute)and node.attr.startswith('__'):raise ValueError('Dunder attributes are unavailable')
  if isinstance(node,ast.Name)and node.id.startswith('__'):raise ValueError('Dunder names are unavailable')
 def safe_import(name,*args,**kwargs):
  if name=='typing':return typing
  if name=='__future__':return __future__
  raise ValueError('External imports are unavailable')
 safe={name:globals().get(name)for name in()}
 import builtins
 for name in['sum','filter','map','list','tuple','len','enumerate','range','int','float','bool','str','abs','min','max','all','any','zip','sorted','reversed','isinstance','set','dict','ValueError','TypeError','Exception']:
  safe[name]=getattr(builtins,name)
 safe['__import__']=safe_import;safe['print']=lambda *a,**k:None
 environment={'__builtins__':safe};exec(compile(tree,'<fixed-quality-code>','exec'),environment)
 function=environment.get('sum_even');outcomes=[]
 if not callable(function):raise ValueError('sum_even function is missing')
 for case in request['cases']:
  values=list(case['input']);before=list(values);result=function(values)
  outcomes.append(dict(input=before,result=result,expected=case['expected'],unchanged=values==before,passed=type(result)is int and result==case['expected']and values==before))
 print(json.dumps(dict(passed=all(x['passed']for x in outcomes),cases=outcomes)))
if __name__=='__main__':
 try:main()
 except BaseException as error:print(json.dumps(dict(passed=False,error=type(error).__name__+': '+str(error))))
