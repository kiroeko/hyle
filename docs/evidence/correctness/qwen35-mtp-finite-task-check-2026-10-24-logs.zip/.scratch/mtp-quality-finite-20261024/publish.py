from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;B=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-check2';E=R/'docs/evidence/correctness'
def read(p):return json.loads(p.read_text(encoding='utf8'))
def identity(p):
 raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix()if p.is_relative_to(R)else str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
summary=read(O/'summary.json');freeze=read(O/'pre-generation-freeze.json');ledger=read(O/'generation-ledger.json');assert summary['completed']==len(ledger['attempts'])==9
assert summary['task_passes']==6 and summary['natural_EOS']==9
plan=read(O/'plan.json');assert identity(O/'plan.json')['sha256']==freeze['plan']['sha256']==summary['plan_sha256']==ledger['plan_sha256']
for key in['judge','python_judge']:
 p=Path(freeze[key]['path']);assert identity(p)['sha256']==freeze[key]['sha256']
tasks=[]
for task in plan['tasks']:
 rows=[r for r in summary['results']if r['task']==task['id']];assert len(rows)==3 and len({tuple(r['generated_ids'])for r in rows})==1
 tasks.append(dict(task=task['id'],prompt=task['prompt'],rule=task['rule'],expected=task.get('expected',task.get('cases')),all_arm_IDs_equal=True,
  arms=[{k:r[k]for k in['arm','P','C','max_output_tokens','generated_tokens','generated_ids','raw_decoded_text','judged_text','natural_EOS','EOS_id','stop_reason','task_passed','judge']}for r in rows]))
files={}
def add(p,name=None):assert p.is_file(),p;files[name or p.relative_to(R).as_posix()]=p
for p in O.rglob('*'):
 if p.is_file()and p.suffix in('.json','.py','.ids','.tsv','.txt','.log')and'__pycache__'not in p.parts:add(p)
for p in (B/'source').rglob('*'):
 if p.is_file():add(p)
for name in ['sources.json','identity.json','compile-command.json','compile-process.json','compile.log','link-command.json','link-process.json','link.log','shared-object-dependencies.json']:add(B/name)
for asset in freeze['tokenizer_files']:
 p=Path(asset['path']);assert identity(p)['sha256']==asset['sha256']
 if p.name!='tokenizer.json':add(p,'local-tokenizer-assets/'+p.name)
stem='qwen35-mtp-finite-task-check-2026-10-24';archive=E/(stem+'-logs.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,p in sorted(files.items()):z.write(p,name)
proof=dict(date='2026-10-24',status='FIXED_NINE_RUN_CHECK_COMPLETE_WITH_COMMON_ARITHMETIC_FAILURE',
 purpose='A finite, predeclared executable task sample for ordinary/K1/K4 generation; neither readable prose nor equality alone is a task-success criterion.',
 predeclared_plan=plan,plan_identity=identity(O/'plan.json'),pre_generation_freeze=identity(O/'pre-generation-freeze.json'),judge_self_check=read(O/'judge-self-check.json'),
 input_identity=dict(BF16_role_manifest=freeze['weights_manifest'],source_id=(O/'inputs/arithmetic/weights.tsv').read_text(encoding='utf8').splitlines()[1],
  tokenizer_files=freeze['tokenizer_files'],actual_chat_template_sha256=freeze['actual_chat_template_sha256'],tokenizer_class=freeze['tokenizer_class'],
  local_files_only=True,offline_environment=freeze['offline_environment'],enable_thinking=False,maximum_output_tokens=128,capacity=512,cache_byte_limit=268435456,replay='commands',sampling='greedy',
  prompts=freeze['cases']),
 results=tasks,
 summary=dict(native_processes_exit0=9,natural_EOS=9,output_quota_stops=0,total_task_passes=6,total_task_failures=3,
  each_arm=dict(passed_tasks=2,total_tasks=3),
  arithmetic='All three arms naturally end with65, while the unchanged expected answer is59. These are actual task failures, not waived or treated as passing because output is readable.',
  extraction='All three arms produce the exact requested name/age/city object. Key order/Markdown do not determine success.',
  python='All three arms emit the same executable sum_even function and pass the fixed five cases, with an integer return and unchanged input lists.',
  comparison='Complete generated IDs are equal across ordinary/K1/K4 for each fixed task; no MTP-specific task regression is observed in this sample.'),
 interpretation=['The shared arithmetic failure is also present in ordinary Hyle, so this nine-run check does not attribute it to MTP. It does not independently prove whether the trained model, ordinary numerical differences or task sensitivity is the ultimate cause.',
  'No questions, answer rules, token limits or decoder settings changed after model generation. There were exactly9native runs, zero retries and no compensating extra tasks.',
  'The frozen old four-arm coding failures remain unchanged and are not replaced with these easier tasks.',
  'Finite task results are not a model-intelligence threshold and do not prove all workloads, all prompt lengths or equality across target execution widths.'],
 algorithm_correctness_evidence=['docs/evidence/correctness/qwen35-mtp-prefix-state-values-2026-10-24.json','docs/evidence/correctness/qwen-mtp-multirow-sampling-2026-10-24.json','docs/evidence/correctness/mtp-fixed-width-packed-head-2026-10-24.json'],
 prior_task_evidence='docs/evidence/correctness/qwen-mtp-quality-prefix-2026-10-22.json',
 model_runs=dict(attempts=len(ledger['attempts']),maximum=9,image=ledger['image'],source_snapshot=ledger['source_snapshot'],HTTP=0,SDK_builds=0,new_model_downloads=0,new_weight_copies=0,
  source_note='All nine runs used the same already built frozen CUDA consumer. A subsequent source-only move of the common sampling header was not recompiled or mixed into this window.'),
 limitations=['Only one local original BF16 Qwen3.5-2B and one CUDA GPU are exercised. No throughput measurement, hardware-memory peak, other model or broad benchmark suite is signed.',
  'Python judgments execute only the predeclared code body in a fixed isolated2-second child with restricted builtins, optional typing/future imports and no external command/network/file APIs.',
  'The archive contains complete IDs, raw/decoded text, EOS/quota, original reports, commands and frozen source. It contains no model weight, SDK, object, executable or full tokenizer vocabulary.'],
 reproduction=dict(prepare='python .scratch/mtp-quality-finite-20261024/prepare.py (only before a fresh explicit finite window)',run='python .scratch/mtp-quality-finite-20261024/run.py (refuses an existing ledger; no automatic retry)',judge='The archived judge.py/python_judge.py consume the original fixed plan without model-dependent rule changes.'),archive=identity(archive),archived_files=len(files))
path=E/(stem+'.json');path.write_text(json.dumps(proof,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8');print(json.dumps(dict(report=identity(path),archive=identity(archive),runs=9,task_passes=6,natural_EOS=9)))
