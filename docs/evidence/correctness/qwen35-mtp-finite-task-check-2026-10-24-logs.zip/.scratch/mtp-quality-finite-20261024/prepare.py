from pathlib import Path
import hashlib,json,os
for name in['HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_DATASETS_OFFLINE']:os.environ[name]='1'
from transformers import AutoTokenizer
O=Path(__file__).resolve().parent;R=O.parents[1];SOURCE=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 assert not(O/'generation-ledger.json').exists(),'Plan cannot change after generation begins'
 plan=json.loads((O/'plan.json').read_text(encoding='utf8'));local=Path(plan['tokenizer'])
 tokenizer=AutoTokenizer.from_pretrained(str(local),local_files_only=True,trust_remote_code=False)
 cases=[]
 for task in plan['tasks']:
  folder=O/'inputs'/task['id'];folder.mkdir(parents=True,exist_ok=True)
  messages=[dict(role='system',content=plan['system_message']),dict(role='user',content=task['prompt'])]
  kwargs=dict(add_generation_prompt=True,enable_thinking=False)
  rendered=tokenizer.apply_chat_template(messages,tokenize=False,**kwargs)
  ids=tokenizer.apply_chat_template(messages,tokenize=True,return_dict=False,**kwargs)
  assert ids and all(type(x)is int for x in ids)and len(ids)+plan['maximum_output_tokens']<=plan['capacity']
  assert tokenizer.encode(rendered,add_special_tokens=False)==ids
  weights=folder/'weights.tsv'
  if not weights.exists():os.link(SOURCE/'weights.tsv',weights)
  assert weights.read_bytes()==(SOURCE/'weights.tsv').read_bytes()
  (folder/'prompt.ids').write_text(' '.join(map(str,ids))+'\n')
  (folder/'rendered-prompt.txt').write_text(rendered,encoding='utf8')
  (folder/'input.json').write_text(json.dumps(dict(source_id=(SOURCE/'weights.tsv').read_text(encoding='utf8').splitlines()[1],messages=messages,prompt_tokens=len(ids),enable_thinking=False,tokenizer_local_only=True),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
  cases.append(dict(id=task['id'],prompt_tokens=len(ids),inputs=str(folder),prompt=identity(folder/'prompt.ids'),rendered=identity(folder/'rendered-prompt.txt')))
 frozen=dict(plan=identity(O/'plan.json'),judge=identity(O/'judge.py'),python_judge=identity(O/'python_judge.py'),tokenizer_files=[identity(local/name)for name in['tokenizer.json','tokenizer_config.json','chat_template.jinja']],
  actual_chat_template_sha256=hashlib.sha256(tokenizer.chat_template.encode()).hexdigest(),tokenizer_class=type(tokenizer).__name__,local_files_only=True,offline_environment={n:os.environ[n]for n in['HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_DATASETS_OFFLINE']},weights_manifest=identity(SOURCE/'weights.tsv'),EOS_ids=[248044,248046],cases=cases,HTTP=0)
 (O/'pre-generation-freeze.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(prompts={x['id']:x['prompt_tokens']for x in cases},plan_sha256=frozen['plan']['sha256'],HTTP=0)))
if __name__=='__main__':main()
