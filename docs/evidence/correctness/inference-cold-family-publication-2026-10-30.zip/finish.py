from pathlib import Path
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact = b.read, b.save, b.pin, b.exact

plan = read(W / 'plan.json')
for item in [*plan['retained'], plan['runtime'], plan['sdk']]:
    exact(item)
builds = []
for name in plan['units']:
    receipt = b.b.receipt(name)
    compile_process = read(W / 'compile' / name / 'attempt1/process.json')
    link_process = read(W / 'link' / name / 'attempt1/process.json')
    assert all(p['state'] == 'TERMINAL' and p['exit'] == 0 and not p['timed_out']
               for p in [compile_process, link_process])
    builds.append(dict(unit=name, object=receipt['object'], compile=compile_process, link=link_process))
runs = []
for name, case in plan['cases'].items():
    folder = W / 'runs' / name / 'attempt1'
    process = read(folder / 'process.json')
    report = read(folder / 'report.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    assert report['status'] == 'PASS'
    runs.append(dict(case=name, process=process, report=report, image=read(folder / 'image.json')))
comparisons = []
previous = R / '.scratch/inference-continuation-control-20261030/runs'
for name, attempt in [('continuous-cuda', 'attempt2'), ('natural-cuda', 'attempt1')]:
    old = previous / name / attempt / 'report.json'
    current = W / 'runs' / name / 'attempt1/report.json'
    assert read(old) == read(current)
    comparisons.append(dict(case=name, original_report=pin(old), current_report=pin(current), complete_report_equal=True))

files = sorted(path for path in (W / 'bin').iterdir() if path.is_file())
assert files and all(path.suffix in {'.exe', '.dll', '.exp', '.lib', '.map', '.pdb'} for path in files)
cleanup = dict(root=str(W / 'bin'), files=[pin(path) for path in files],
               bytes=sum(path.stat().st_size for path in files))
save(W / 'cleanup-plan.json', cleanup)

base = read(plan['base']['path'])
model = plan['units']['model']
next_base = dict(schema='hyle.cold-family-publication.current-link-base.v1', base=plan['base'],
    compile=model['compile'], link=model['link'], consumer_source=pin(model['source']),
    previous_consumer=pin(W / 'compile/model/receipt.json'), retained=base['retained'],
    runtime=base['runtime'], sdk_engine_dependencies=base['sdk_engine_dependencies'])
save(W / 'model-link-base.json', next_base)

record = dict(schema='hyle.correctness.cold-family-publication.v1', date='2026-10-30', status='PASS',
    base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(),
    changes=[
        'Qwen builds a stable complete local Family and publishes one table entry only after successful graph and child preparation.',
        'Cold unsupported/exception paths leave no empty family entry; prefill adapter and two CLI branches no longer repair Model inventory.',
        'Finite/exact planning, Session validation and physical preparation share family plus concrete program selection without new resource owners.',
        'Diagnostic/role/completion/sampling/packing isolation and zero-row full-prefix admission remain distinct; original ColdShapePlan retirement and rollback are preserved.'
    ],
    sources=[pin(R / path) for path in ['engine/models/qwen35/main.cc', 'tests/tools/qwen_cold_family_case.h',
        'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_chunked_prefill_case.h', 'tests/tools/qwen_host_image_request_case.h']],
    counts=dict(current_CXX_consumers=3, CXX_attempts=3, link_attempts=3, native_processes=5,
        current_passed_processes=5, retained_SDK_engine_inputs=227, SDK_CXX=0, NVCC=0, downloads=0,
        whole_builds=0, throughput_windows=0),
    builds=builds, runs=runs, previous_reports=comparisons, fixtures=plan['fixtures'],
    cleanup_plan=pin(W / 'cleanup-plan.json'), next_link_base=pin(W / 'model-link-base.json'),
    boundaries=[
        'The new cold Model case submits no Graph; it exercises real CPU compilation, budget ResourceExhausted, retry, stable children and original Invocation installation.',
        'Original program-carrier CPU case submits two actual graphs; request journey covers partial prefix, StateOnly, actual host eviction/restore and output credit.',
        'CUDA ordinary continuation covers 16 arms; original BF16 Qwen P154 MTP compares 40 outputs, state, ledger, RNG and retirement. Their complete reports equal the prior batch.',
        'Consumers are compiled with current CPU/CUDA configuration; CPU execution is not a CUDA-free-link claim.',
        'Unsupported packed-provider return-false was not forced; implementation removes its early map mutation but this batch does not claim an observed Unimplemented branch.',
        'No fresh CMake configure/install, Apple/Vulkan execution, whole-large-model checks or throughput claim; multi-width cold calls are not whole-call transactions.'
    ])
evidence = R / 'docs/evidence/correctness/inference-cold-family-publication-2026-10-30.json'
save(evidence, record)
bundle = evidence.with_suffix('.zip')
excluded = {'unit.obj', 'unit.pdb'}
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(W.rglob('*')):
        if not path.is_file() or any(part in {'bin', 'tmp', '__pycache__'} for part in path.relative_to(W).parts):
            continue
        if path.name in excluded or path.suffix in {'.obj', '.pdb'}:
            continue
        archive.write(path, str(path.relative_to(W)))
    archive.write(evidence, evidence.name)
record['archive'] = pin(bundle)
save(evidence, record)
print(dict(status='PASS', processes=len(runs), consumers=len(builds), archive_bytes=bundle.stat().st_size,
           cleanup_files=len(files), cleanup_bytes=cleanup['bytes']))
