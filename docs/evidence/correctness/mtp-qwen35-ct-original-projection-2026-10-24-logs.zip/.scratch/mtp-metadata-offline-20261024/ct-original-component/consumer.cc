#include <gtest/gtest.h>
#include "tests/compute_models/ct_packed_graph_fixture.h"
#include "engine/models/qwen35/prepared_roles.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cpu.h"
#include "hyle/graph/cuda.h"

#include <filesystem>
#include <fstream>
#include <iostream>

namespace {
namespace f = ct_packed_graph_test;
namespace p = qwen35::prepared;
constexpr std::int64_t N = 512, K = 2048, M = 3;
std::filesystem::path data_directory;
std::vector<std::byte> load(const std::filesystem::path& path, std::size_t expected) {
  std::ifstream in(path, std::ios::binary | std::ios::ate);
  if (!in || in.tellg() != static_cast<std::streamoff>(expected))
    throw std::runtime_error("Missing or wrong-size original component: " + path.string());
  std::vector<std::byte> result(expected); in.seekg(0);
  if (!in.read(reinterpret_cast<char*>(result.data()), static_cast<std::streamsize>(expected)))
    throw std::runtime_error("Cannot read original component: " + path.string());
  return result;
}
unsigned little(std::span<const std::byte> bytes, std::size_t at, unsigned count) {
  unsigned value = 0;
  for (unsigned i = 0; i < count; ++i)
    value |= std::to_integer<unsigned>(bytes[at + i]) << (i * 8);
  return value;
}
struct Original final {
  std::vector<std::byte> codes = load(data_directory / "weight_packed.bin", N*K/2);
  std::vector<std::byte> scales = load(data_directory / "weight_scale.bin", N*K/32*2);
  std::vector<double> weights;
  std::size_t source_round_witnesses = 0;
  Original() {
    const auto shapes = load(data_directory.parent_path() / "shape-tensors.bin", 2512);
    p::Role principal;
    principal.dtype = "I32"; principal.shape = {N, K/8};
    principal.projection_codec = p::ProjectionCodec::kCtSymmetric4;
    principal.projection_group_size = 32;
    p::validate_ct_shape_values(principal, std::span(shapes).subspan(2448,16));
    weights.resize(N*K);
    for (std::int64_t n = 0; n < N; ++n) for (std::int64_t k = 0; k < K; ++k) {
      const auto i = static_cast<std::size_t>(n*K+k);
      const auto word = little(codes, static_cast<std::size_t>((n*(K/8)+k/8)*4), 4);
      const auto q = static_cast<int>((word >> ((k%8)*4)) & 15u) - 8;
      const auto sf = static_cast<std::uint16_t>(little(scales,
          static_cast<std::size_t>((n*(K/32)+k/32)*2), 2));
      const double scale = half_test::decode_bits<ct_packed_test::BF16>(sf);
      if (!std::isfinite(scale)) throw std::runtime_error("Original scale is not finite");
      // Independent software half encoder; no product decoder or producer helper.
      const double product = q * scale;
      weights[i] = ct_packed_test::round(f::Type::kBFloat16, product);
      source_round_witnesses += weights[i] != product;
    }
    if (source_round_witnesses == 0) throw std::runtime_error("Original source has no BF16 product-round witness");
  }
};
struct SystemResource final { f::m::MemoryResourceRef ref() noexcept { return f::m::system_resource(); } };
struct Cpu final {
  static f::c::Context context() { return f::take(f::g::cpu::create_context(), "CPU context"); }
  static f::c::StorageOwner owner(const f::c::Context& c) {
    return f::take(f::c::StorageOwner::adopt(c, SystemResource{}), "CPU owner");
  }
  static hyle::Result<f::g::CompiledGraph> compile(const f::Logical& l,
      const f::c::Context& c, const f::c::StorageOwner&, f::g::CompileOptions o) {
    return f::g::cpu::compile(l.graph, c, o);
  }
  static hyle::Status prepare(f::g::Invocation& slot, f::c::Queue& queue, bool) {
    const std::array queues{f::g::QueueBinding{f::g::ExecutionLaneId{0}, &queue}};
    return slot.prepare_replay(queues, {.mode=f::g::ReplayMode::kCommands,
        .host_wait=f::g::HostWaitPolicy::kAllow});
  }
};
struct Cuda final {
  static f::c::Context context() { return f::take(f::g::cuda::create_context(), "CUDA context"); }
  static f::c::StorageOwner owner(const f::c::Context& c) {
    return f::take(f::c::StorageOwner::adopt(c,
        f::take(f::c::cuda::MemoryResource::create(c, f::c::cuda::MemoryKind::kDevice),
            "CUDA resource")), "CUDA owner");
  }
  static hyle::Result<f::g::CompiledGraph> compile(const f::Logical& l,
      const f::c::Context& c, const f::c::StorageOwner& owner, f::g::CompileOptions o) {
    return f::g::cuda::compile(l.graph, c, owner, o);
  }
  static hyle::Status prepare(f::g::Invocation& slot, f::c::Queue& queue, bool) {
    return f::g::cuda::prepare_replay(slot, queue, {.mode=f::g::ReplayMode::kCommands,
        .host_wait=f::g::HostWaitPolicy::kAllow});
  }
};
template<class Backend> void verify() {
  const Original original;
  auto context = Backend::context(); auto owner = Backend::owner(context);
  auto queue = f::take(context.create_queue(), "create queue");
  for (const auto type : {f::Type::kBFloat16, f::Type::kFloat32}) {
    SCOPED_TRACE(static_cast<int>(type));
    const auto graph = f::build({false,f::Type::kBFloat16,type,type,M},N,K,
        f::Escape::kPublishedDecode,true);
    std::vector<f::c::ReadLease> source{
        f::upload(owner,original.codes), f::upload(owner,original.scales)};
    std::vector<f::g::ConstantBinding> constants;
    for (std::size_t i=0;i<source.size();++i) constants.push_back({graph.ports[i+1],
        f::take(source[i].tensor(graph.descriptions[i+1]),"original constant"),
        f::g::ConstantPolicy::kBorrow,owner,source[i]});
    auto program=f::take(Backend::compile(graph,context,owner,{.constants=constants}),"compile original CT graph");
    auto slot=f::invocation(program.executable);
    std::vector<double> activation(M*K,0);
    activation[0]=type==f::Type::kFloat32 ? 1+std::ldexp(1.0,-15) : 1;
    activation[K+7]=-1.0/16;
    activation[2*K+31]=1; activation[2*K+32]=-1;
    auto input=f::upload(owner,f::floating(type,activation));
    f::check(slot.bind(graph.ports[0],graph.descriptions[0],input),"bind activation");
    std::vector<f::c::LeasePool> pools;
    for(auto value:{graph.output,graph.extra}) {
      auto desc=f::take(graph.graph.value_description(value),"output desc");
      const auto bytes=f::take(desc.required_bytes(),"output bytes");
      pools.push_back(f::take(f::c::LeasePool::create(owner.ref(),bytes,
          {.max_blocks=1,.backing_alignment=256}),"output pool"));
      auto writer=f::take(pools.back().allocate(bytes,256),"output writer");
      f::check(slot.bind(value,desc,std::move(writer)),"bind original output");
    }
    f::submit<Backend>(slot,queue,false);
    const auto decoded=f::read(f::output(slot,graph.extra));
    ASSERT_EQ(decoded.size(),original.weights.size());
    for(std::size_t i=0;i<decoded.size();++i) {
      if(decoded[i]!=original.weights[i]) { ADD_FAILURE()<<"original decode mismatch at "<<i
          <<" actual="<<decoded[i]<<" expected="<<original.weights[i]; return; }
    }
    const auto actual=f::read(f::output(slot,graph.output));
    ASSERT_EQ(actual.size(),static_cast<std::size_t>(M*N));
    std::size_t f32_narrowing_witnesses=0;
    for(std::int64_t row=0;row<M;++row) for(std::int64_t n=0;n<N;++n) {
      double sum=0;
      for(std::int64_t k=0;k<K;++k) sum+=activation[static_cast<std::size_t>(row*K+k)]*
          original.weights[static_cast<std::size_t>(n*K+k)];
      const auto expected=ct_packed_test::round(type,sum);
      const auto i=static_cast<std::size_t>(row*N+n);
      EXPECT_EQ(actual[i],expected)<<"row="<<row<<" n="<<n;
      if(type==f::Type::kFloat32 && row==0 && expected!=ct_packed_test::round(f::Type::kBFloat16,sum))
        ++f32_narrowing_witnesses;
    }
    if(type==f::Type::kFloat32) EXPECT_GT(f32_narrowing_witnesses,0u);
    std::cout<<"CT component dtype="<<static_cast<int>(type)<<" checked_decode="<<decoded.size()
        <<" checked_projection="<<actual.size()<<" source_round_witnesses="<<original.source_round_witnesses
        <<" f32_not_bf16_witnesses="<<f32_narrowing_witnesses<<'\n';
  }
}
TEST(OriginalCtMtpProjection,Cpu) { verify<Cpu>(); }
TEST(OriginalCtMtpProjection,Cuda) { verify<Cuda>(); }
} // namespace
int main(int argc,char**argv) {
  if(argc<2) { std::cerr<<"Original source component directory is required\n"; return 2; }
  data_directory=argv[1]; --argc;
  for(int i=1;i<argc;++i) argv[i]=argv[i+1];
  ::testing::InitGoogleTest(&argc,argv);
  return RUN_ALL_TESTS();
}
