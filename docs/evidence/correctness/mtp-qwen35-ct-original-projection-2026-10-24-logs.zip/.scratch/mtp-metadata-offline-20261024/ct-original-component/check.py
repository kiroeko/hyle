from pathlib import Path
import importlib.util,json,os,subprocess,sys,time,hashlib
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parents[2];S=O.parent
spec=importlib.util.spec_from_file_location('ct_host_helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def execute(command,env,name,timeout):
 folder=O/name;folder.mkdir(parents=True,exist_ok=True);(folder/'tmp').mkdir(exist_ok=True)
 env=dict(env,TEMP=str(folder/'tmp'),TMP=str(folder/'tmp'))
 record=dict(command=command,cwd=str(R),started=time.time(),timeout_seconds=timeout);b.save(folder/'command.json',record)
 with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
  result=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
 record.update(exit=result.returncode,finished=time.time());b.save(folder/'process.json',record)
 if result.returncode:raise RuntimeError('Component failed: '+str(folder))
 return record
def build():
 old=b.read(R/'.scratch/dense-linear-f32-20261024/test-ggml/identity.json');cc=old['command'][0]
 native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
 flags=[];skip=False
 for arg in old['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith('.cc'):continue
  flags.append(arg)
 source=O/'consumer.cc';folder=O/'compile';folder.mkdir(exist_ok=True);obj=folder/'consumer.obj'
 command=[*flags,'/DHYLE_COMPUTE_CPU=1','/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(folder/'consumer.pdb')]
 execute(command,native.env,'compile',180)
 b.save(folder/'identity.json',dict(command=command,source=b.identity(source),object=b.identity(obj)))
 original=R/'.scratch/dense-linear-f32-20261024/link-plan.json';command=[]
 for arg in b.read(original)['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
  if Path(arg).name in ('test-ggml.obj','test-cublas.obj','test-infer.obj','gtest_main.lib'):continue
  command.append(arg)
 image=O/'component.exe';command += [str(obj),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 b.save(O/'link-plan.json',dict(command=command,closure=b.identity(original),fresh_TUs=1,SDK_builds=0,HTTP=0))
 execute(command,native.env,'link',120)
 runtime=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
 if b.identity(runtime)['sha256']!='6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f':raise RuntimeError('Wrong CPU runtime identity')
 staged=O/runtime.name
 if not staged.exists():os.link(runtime,staged)
 if b.identity(staged)['sha256']!=b.identity(runtime)['sha256']:raise RuntimeError('Wrong staged CPU runtime')
 ready=b.read(R/'.scratch/dense-linear-f32-20261024/ready.json')
 b.save(O/'ready.json',dict(image=b.identity(image),PATH=str(O)+os.pathsep+ready['PATH'],native_runtime=b.identity(staged)))
def preflight():
 plan=b.read(S/'cat00/k-proj-component-plan.json');acquisition=S/'cat00/k-proj-component/acquisition.json'
 if not acquisition.exists():raise RuntimeError('Original body acquisition evidence is missing; no source-body test may run')
 # Each exact range is pinned independently in the retained acquisition receipt.
 raw=acquisition.read_text(encoding='utf-8');evidence=json.loads(raw)
 for row in plan['new_source_ranges']:
  source=R/row['output'];identity=b.identity(source)
  if identity['bytes']!=row['bytes']:raise RuntimeError('Wrong original component byte length')
  if identity['sha256'] not in raw:raise RuntimeError('Original component hash absent from acquisition evidence')
 b.save(O/'source-preflight.json',dict(acquisition=b.identity(acquisition),plan=b.identity(S/'cat00/k-proj-component-plan.json'),source=evidence,
  files=[b.identity(R/row['output'])for row in plan['new_source_ranges']],new_HTTP=0))
def run():
 preflight();ready=b.read(O/'ready.json');b.require(ready['image'])
 execute([ready['image']['path'],str(S/'cat00/k-proj-component'),'--gtest_filter=OriginalCtMtpProjection.*','--gtest_output=json:'+str(O/'tests.json')],dict(os.environ,PATH=ready['PATH']),'run',180)
 print((O/'run/stdout.log').read_text())
 b.save(O/'result.json',dict(tests=b.identity(O/'tests.json'),consumer=b.identity(O/'consumer.cc'),source_preflight=b.identity(O/'source-preflight.json'),fresh_TUs=1,SDK_builds=0,HTTP=0,
  scope='One original CT symmetric4 MTP k_proj, full decoded N512*K2048 source-round oracle, BF16 and F32 sparse M3 projections, actual CPU and CUDA Graph commands; not complete model or performance.'))
if __name__=='__main__':
 if sys.argv[1] in ('build','all'):build()
 if sys.argv[1] in ('run','all'):run()
