from pathlib import Path
import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path.cwd()
base = root / '.scratch/inference-gaps/g02'
out = base / 'vulkan-port-binding-diagnostic'
build = Path('C:/h7/inference-g02-impacted')
assert not (out / 'result.json').exists()
row = json.loads((out / 'compile-row.json').read_text())
source = Path(row['file'])
normal_dll = build / 'bin/hyle_compute_provider_ggml_vulkan.dll'
normal_exe = build / 'bin/hyle_graph_route_vulkan_test.exe'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

record = {
    'state': 'SETUP',
    'scope': 'One failed native case; scratch-only port trace, unchanged public source, normal DLL and exe. No product modification or acceptance verdict.',
    'source_sha256': sha(source),
    'normal_dll_sha256': sha(normal_dll),
    'normal_exe_sha256': sha(normal_exe),
    'stages': [],
}

def save():
    (out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')

save()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
shell32 = ctypes.WinDLL('shell32', use_last_error=True)
shell32.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
shell32.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
kernel32.LocalFree.argtypes = [ctypes.c_void_p]
kernel32.LocalFree.restype = ctypes.c_void_p

def argv(command):
    count = ctypes.c_int()
    pointer = shell32.CommandLineToArgvW(command, ctypes.byref(count))
    assert pointer
    try:
        return [pointer[i] for i in range(count.value)]
    finally:
        kernel32.LocalFree(pointer)

env = {k.upper(): v for k, v in os.environ.items()}
for line in subprocess.check_output(['cmd', '/d', '/c', str(base / 'resume-windows-2/vs-env.cmd')], text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        env[key.upper()] = value
env['PATH'] = str(build / 'bin') + os.pathsep + env['PATH']
env['HYLE_D5_QWEN35_FIXTURE'] = json.loads((base / 'current-model-fixture.json').read_text())['root']

def run(stage, args):
    start = time.monotonic()
    with (out / (stage + '.log')).open('w') as log:
        child = subprocess.Popen(args, cwd=build, env=env, stdout=log, stderr=subprocess.STDOUT,
                                 creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        record.update(state='RUNNING', stage=stage, pid=child.pid)
        save()
        print(stage, child.pid, flush=True)
        code = child.wait()
    record['stages'].append({'stage': stage, 'command': args, 'exit_code': code,
                             'elapsed_seconds': time.monotonic() - start})
    save()
    return code

cpp = out / 'region-diagnostic.cc'
obj = out / 'region-diagnostic.obj'
text = source.read_text()
needle = '    for (auto *tensor : state.ports) {\n      HYLE_ASSIGN_OR_RETURN(auto buffer,'
assert text.count(needle) == 1
trace = r'''
    std::fprintf(stderr, "# G02_PORTS region=%llu inputs=%zu outputs=%zu ports=%zu\n",
                 static_cast<unsigned long long>(recipe.id), recipe.inputs.size(), recipe.outputs.size(), state.ports.size());
    for (std::size_t i = 0; i < state.ports.size(); ++i) {
      auto *t = state.ports[i];
      std::fprintf(stderr, "# G02_PORT index=%zu value=%u tensor=%p buffer=%p data=%p view=%p op=%s ne=%lld,%lld,%lld,%lld nb=%zu,%zu,%zu,%zu\n",
                   i, unsigned(i < recipe.inputs.size() ? recipe.inputs[i] : recipe.outputs[i - recipe.inputs.size()]),
                   static_cast<void *>(t), static_cast<void *>(t->buffer), t->data, static_cast<void *>(t->view_src), ggml_op_name(t->op),
                   static_cast<long long>(t->ne[0]), static_cast<long long>(t->ne[1]), static_cast<long long>(t->ne[2]), static_cast<long long>(t->ne[3]),
                   t->nb[0], t->nb[1], t->nb[2], t->nb[3]);
    }
'''
# Recipe identity is not needed to diagnose native storage identity.
trace = trace.replace('region=%llu ', '').replace('                 static_cast<unsigned long long>(recipe.id), ', '                 ')
text = '#include <cstdio>\n' + text.replace(needle, trace + needle)
cpp.write_text(text, encoding='utf-8')
args = argv(row['command'])
source_arg = next(i for i, a in enumerate(args) if a.replace('\\', '/') == str(source).replace('\\', '/'))
args[source_arg] = str(cpp)
for i, arg in enumerate(args):
    if arg.startswith('/Fo'):
        args[i] = '/Fo' + str(obj)
    if arg.startswith('/Fd'):
        args[i] = '/Fd' + str(out / 'compile.pdb')
args.insert(1, '/I' + str(source.parent))
code = run('compile', args)
if code:
    record['state'] = 'TERMINAL_SETUP_FAIL'
    save()
    raise SystemExit(code)

link = (out / 'original-link-command.txt').read_text().strip()
args = argv(link[link.index('&& "') + 3:].rsplit(' && cd .', 1)[0])
assert args[1:3] == ['-E', 'vs_link_dll']
old_obj = str(Path(row['output']).relative_to(build))
assert args.count(old_obj) == 1
args[args.index(old_obj)] = str(obj)
binary_dir = out / 'bin'
binary_dir.mkdir()
binary = binary_dir / normal_dll.name
for i, arg in enumerate(args):
    if arg.startswith('--intdir='):
        args[i] = '--intdir=' + str(out / 'link')
    if arg.lower().startswith('/out:'):
        args[i] = '/out:' + str(binary)
    if arg.lower().startswith('/implib:'):
        args[i] = '/implib:' + str(out / 'diagnostic.lib')
    if arg.lower().startswith('/pdb:'):
        args[i] = '/pdb:' + str(out / 'diagnostic.pdb')
(out / 'link').mkdir()
code = run('link', args)
if code:
    record['state'] = 'TERMINAL_SETUP_FAIL'
    save()
    raise SystemExit(code)
test_exe = binary_dir / normal_exe.name
shutil.copy2(normal_exe, test_exe)
code = run('test', [str(test_exe), '--gtest_filter=VulkanGraphMoeFragments.D5DeepSeekFullAttentionChain', '--gtest_color=no'])
assert sha(source) == record['source_sha256']
assert sha(normal_dll) == record['normal_dll_sha256']
assert sha(normal_exe) == record['normal_exe_sha256']
raw = (out / 'test.log').read_text(errors='replace')
record.update(state='TERMINAL_DIAGNOSTIC_REPRODUCED' if code == 3 and '# G02_PORTS' in raw and 'tensor->buffer == NULL' in raw else 'TERMINAL_DIAGNOSTIC_OTHER',
              diagnostic_dll_sha256=sha(binary))
save()
print(raw[-12000:], flush=True)
