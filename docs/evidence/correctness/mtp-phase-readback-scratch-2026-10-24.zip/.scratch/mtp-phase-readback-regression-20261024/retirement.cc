#include "tests/tools/qwen_resource_retirement_test.cc"
