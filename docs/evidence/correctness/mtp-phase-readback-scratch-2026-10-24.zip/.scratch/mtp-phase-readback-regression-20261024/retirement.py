from pathlib import Path
import importlib.util

D = Path(__file__).resolve().parent
R = D.parents[1]
spec = importlib.util.spec_from_file_location('readback_regression_tools', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
test = R / 'tests/tools/qwen_resource_retirement_test.cc'
main = R / 'engine/models/qwen35/main.cc'
assert b.pin(test)['sha256'] == '089399d8dee882a74ffdc4c2e68877fa6c7f85c937ca7ff888d20286bc422cd0'
assert b.pin(main)['sha256'] == 'b021078bd6845b8b38afdb3154a11db278060159e023e82c6aab99a17e2f8648'
(D / 'retirement-test.cc').write_bytes(test.read_bytes())
b.save(D / 'retirement-source-pins.json', [b.pin(test), b.pin(main),
    b.pin(R / 'engine/inference/readback.h')])
env = b.compile(D / 'retirement.cc', D / 'retirement-compile', vulkan=True)
image = b.link(D / 'retirement-compile/unit.obj', D / 'retirement-link', env, vulkan=True, gtest=True)
env.update({k: v for k, v in b.read(b.VK / 'runtime.json').items() if isinstance(v, str)})
b.execute([str(image), '--gtest_output=json:' + str(D / 'retirement-gtests.json')],
    D / 'retirement-run', env, 60)
