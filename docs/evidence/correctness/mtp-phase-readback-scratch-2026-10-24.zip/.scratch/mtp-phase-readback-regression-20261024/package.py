"""Keep the finite Phase readback/host-scratch regression evidence."""
from pathlib import Path
import hashlib
import json
import zipfile

R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
OUT = R / 'docs/evidence/correctness/mtp-phase-readback-scratch-2026-10-24'

def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def main():
    summary = load(D / 'summary.json')
    processes = {name: load(D / name / 'process.json')
                 for name in ['cpu-syntax', 'run', 'retirement-run']}
    if any(row['exit'] != 0 or row.get('timeout') for row in processes.values()):
        raise RuntimeError('Require actual successful terminal consumer checks')
    report = json.loads((D / 'run/stdout.log').read_text(encoding='utf8').strip())
    if (report['status'], report['classic_R2'], report['classic_cursors']) != (
            'PASS_TINY_PHASE_READBACK', True, [4, 4]):
        raise RuntimeError('Actual two-request MTP journey was not observed')
    guards = load(D / 'retirement-gtests.json')
    if guards['tests'] != 4 or guards['failures'] or guards['errors']:
        raise RuntimeError('Require original retirement and new readback guard cases')
    sources = [R / name for name in (
        'engine/models/qwen35/main.cc', 'engine/inference/readback.h',
        'engine/inference/backend.h', 'engine/inference/prepared_output.h',
        'tests/tools/qwen_resource_retirement_test.cc', 'tests/CMakeLists.txt')]
    if (R / 'engine/models/qwen35/host_predicates.h').exists():
        raise RuntimeError('Old macro-based predicate helper must be removed')
    records = [p for p in D.rglob('*') if p.is_file()
               and p.suffix in {'.json', '.log', '.py', '.cc'}]
    with zipfile.ZipFile(OUT.with_suffix('.zip'), 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(sources + records)):
            z.write(p, p.relative_to(R).as_posix())
    with zipfile.ZipFile(OUT.with_suffix('.zip')) as z:
        if z.testzip() is not None: raise RuntimeError('Evidence archive CRC failed')
        entries = len(z.namelist())
    result = dict(date='2026-10-24', status='PASS finite main-Phase readback and prepared host scratch',
        sources=[identity(p) for p in sources], archive=identity(OUT.with_suffix('.zip')),
        archive_entries=entries,
        previous=identity(R / 'docs/evidence/correctness/mtp-shared-draft-readback-2026-10-24.json'),
        changes=['Prepare next-ID, draft-ID, valid and accept outputs using actual compiled facts',
            'Decode Bool/F32 arrays with caller-prepared scratch and exact dense byte/count checks',
            'Keep valid/accept/draft-ID/prefix-candidate host arrays in the original finite Phase',
            'Remove the unused old macro decoder and its standalone test target',
            'Move real invalid-value and bounds coverage into the original native retirement/readback test target'],
        checks=dict(processes=processes, tiny_vulkan_journey=report,
            native_regression_cases=4,
            guarded_inputs=['Bool2', 'F32 nonbinary/Inf/NaN', 'short scratch', 'wrong count', 'range canaries'],
            source_review='Actual phase cardinalities and serial carrier ownership preserve prepared host-array lifetime'),
        limits=['One 206336-byte untrained fixture; no trained-model quality or throughput claim',
            'Host-array preparation was verified in source and real R2 execution; entire-loop allocation count was not measured',
            'No backend or quantization matrix was rerun',
            'The runtime BackendSelection candidate is separate and is not part of this checked product source',
            'Persistent logits/hidden/state leases keep their original lifecycle'],
        full_trained_model_runs=0, untrained_tiny_model_journeys=1,
        SDK_builds=0, HTTP_requests=0, model_download_bytes=0)
    with OUT.with_suffix('.json').open('x', encoding='utf8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False); f.write('\n')
    print(json.dumps(dict(evidence=identity(OUT.with_suffix('.json')),
        archive=result['archive'], entries=entries)))

if __name__ == '__main__': main()
