"""Two CPU app TUs / two CPU journeys; no SDK, core, provider or GPU build."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = R / '.scratch/inference-ordinary-boundaries-20261025/implementation'
OLD = R / '.scratch/inference-prefix-admission-20261025/attempt3'
spec = importlib.util.spec_from_file_location('retained_commands', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def commands(side):
    root = W / ('before' if side == 'baseline' else 'source')
    folder = W / 'attempt2' / side
    original = b.args(OLD / 'compile/command.json')
    command = [original[0], '/I' + str(root), '/I' + str(W / 'source')]
    skip = False
    for arg in original[1:]:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        if 'inference-prefix-admission-20261025' in arg:
            continue
        command.append(arg)
    if side == 'baseline':
        command.append('/DHYLE_CONTEXT_BASELINE_WITNESS=1')
    command += [str(W / 'consumer.cc'), '/sourceDependencies', str(folder / 'compile/dependencies.json'),
                '/Fo' + str(folder / 'compile/unit.obj'), '/Fd' + str(folder / 'compile/unit.pdb')]
    link = []
    count = 0
    for arg in b.args(OLD / 'link/command.json'):
        if arg.lower().startswith(('/out:', '/pdb:', '/implib:')):
            continue
        if Path(arg) == OLD / 'compile/unit.obj':
            arg = str(folder / 'compile/unit.obj')
            count += 1
        link.append(arg)
    assert count == 1
    link += ['/OUT:' + str(folder / 'link/component.exe'), '/PDB:' + str(folder / 'link/component.pdb'),
             '/IMPLIB:' + str(folder / 'link/component.lib')]
    return root, folder, command, link


def freeze_plan():
    expected = {
        'budget': R / '.scratch/inference-cache-shared-source-20261025/attempt1/budget/unit.obj',
        'leases': R / '.scratch/inference-cache-shared-source-20261025/attempt1/leases/unit.obj',
        'arena': R / '.scratch/inference-cache-shared-source-20261025/attempt1/arena/unit.obj',
        'resources': R / '.scratch/inference-native-retention-scopes-20261025/attempt1/resources/unit.obj',
    }
    _, _, _, link = commands('baseline')
    originals = b.args(OLD / 'link/command.json')
    for name, path in expected.items():
        assert sum(Path(x) == path for x in link) == 1, (name, path)
    common = [b.pin(Path(x)) for x in originals if Path(x).is_absolute() and
              Path(x).suffix.lower() in {'.obj', '.lib'} and Path(x) != OLD / 'compile/unit.obj']
    assert len(common) == 129
    native = R / '.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll'
    fixture = R / '.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
    plan = dict(status='SOURCE_FROZEN_AWAITING_ROOT_BUILD_CONFIRMATION',
        scope='two pure-CPU app TUs and two CPU processes; cached untrained A/H64/FFN128/V64 C16',
        baseline_main=b.pin(W / 'before/engine/models/qwen35/main.cc'),
        candidate_main=b.pin(W / 'source/engine/models/qwen35/main.cc'),
        source=[b.pin(W / 'consumer.cc'), b.pin(W / 'source/tests/tools/qwen_turn_context_case.h')],
        canonical_main=b.pin(R / 'engine/models/qwen35/main.cc'),
        compile_template=b.pin(OLD / 'compile/command.json'), link_template=b.pin(OLD / 'link/command.json'),
        common_input_count=len(common), total_inputs_each=len(common) + 1,
        common_inputs=common, required_current_objects={k: b.pin(v) for k, v in expected.items()},
        native=b.pin(native), fixture=b.pin(fixture / 'weights.tsv'), fixture_body=b.pin(fixture / 'untrained-bf16.bin'),
        runtime=b.pin(R / '.scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json'),
        baseline_expected='P15/quota3 commits two outputs and length16, then actual context refusal with remaining1 and turn_done false; diagnostic witness is not a fixed-product pass',
        candidate_expected='P15/quota3 refused before input_turn/Session/ledger/output; P15/quota2 reaches length16/output2/pending remains; later empty suffix quota1 uses last row once',
        formal_registration='existing lifecycle consumer --turn-context dispatch; helper body compiled and executed by candidate consumer; dispatch TU itself source-only this batch',
        build_commands={side: dict(compile=commands(side)[2], link=commands(side)[3]) for side in ['baseline', 'candidate']},
        no_new_weight_or_SDK_copy=True, core_or_provider_TUs=0, GPU=False, HTTP=0,
        runtime_watchdog_seconds=120,
        excluded='No MTP cases, whole SDK, additional model/process matrix, profiling or speed claim')
    b.save(W / 'execution-plan2.json', plan)


def build(side):
    root, folder, compile_command, link_command = commands(side)
    plan = b.read(W / 'execution-plan2.json')
    assert b.pin(R / 'engine/models/qwen35/main.cc')['sha256'] == plan['canonical_main']['sha256']
    for item in plan['common_inputs']:
        assert b.pin(Path(item['path'])) == item
    env = b.environment(compile_command[0])
    b.execute(compile_command, folder / 'compile', env, 150)
    dep = b.read(folder / 'compile/dependencies.json')
    repository = []
    for item in [dep['Data']['Source'], *dep['Data']['Includes']]:
        p = Path(item)
        if p.is_relative_to(R):
            repository.append(b.pin(p))
        assert not p.is_relative_to(R / 'engine'), ('canonical engine source leaked into shadow', p)
    assert any(Path(x['path']) == root / 'engine/models/qwen35/main.cc' for x in repository)
    b.save(folder / 'compile/repository-inputs.json', repository)
    b.execute(link_command, folder / 'link', env, 90)
    native = Path(plan['native']['path'])
    os.link(native, folder / 'link' / native.name)
    b.save(folder / 'link/ready.json', dict(image=b.pin(folder / 'link/component.exe'), native=b.pin(native),
        app=b.pin(folder / 'compile/unit.obj'), actual_inputs=[b.pin(Path(x)) for x in link_command
            if Path(x).is_absolute() and Path(x).suffix.lower() in {'.obj', '.lib'}]))


def run(side):
    _, folder, compile_command, _ = commands(side)
    plan = b.read(W / 'execution-plan2.json')
    ready = b.read(folder / 'link/ready.json')
    for item in [ready['image'], ready['native'], *ready['actual_inputs'], plan['fixture'], plan['fixture_body']]:
        assert b.pin(Path(item['path'])) == item
    env = b.environment(compile_command[0])
    env['PATH'] = str(folder / 'link') + ';' + b.read(Path(plan['runtime']['path']))['PATH']
    env['HF_HUB_OFFLINE'] = '1'
    env['TRANSFORMERS_OFFLINE'] = '1'
    b.execute([ready['image']['path'], str(Path(plan['fixture']['path']).parent)], folder / 'run', env, 120)
    text = (folder / 'run/stdout.log').read_text(encoding='utf-8')
    result = json.loads(text.strip().splitlines()[-1])
    expected = 'BASELINE_REPRODUCED_LATE_CONTEXT_REFUSAL' if side == 'baseline' else 'PASS'
    assert result['status'] == expected
    b.save(folder / 'run/result.json', result)
    print(json.dumps(result))


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'plan':
        freeze_plan()
    elif mode == 'build':
        build(sys.argv[2])
    elif mode == 'run':
        run(sys.argv[2])
    else:
        raise SystemExit('plan | build baseline|candidate | run baseline|candidate')
