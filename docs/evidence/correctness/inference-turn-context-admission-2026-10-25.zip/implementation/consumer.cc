#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_turn_context_case.h"

int main(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("turn-context PRIVATE_CACHED_FIXTURE_DIRECTORY");
    const std::filesystem::path input(argv[1]);
#if defined(HYLE_CONTEXT_BASELINE_WITNESS)
    namespace t = qwen_turn_context_case;
    namespace q = qwen35;
    const auto manifest = input / "weights.tsv";
    const auto geometry = q::read_weight_geometry(manifest);
    t::require(geometry.hidden == 64 && geometry.intermediate == 128 && geometry.vocabulary == 64 && geometry.layers == "A",
        "baseline witness requires the cached untrained A/H64/FFN128/V64 fixture");
    const auto plan = q::cache::plan(geometry, 16, 1, 15,
        q::recurrent_bytes(q::state_schema_for(geometry, 16), geometry), 1, 1, false, true);
    q::Model model(manifest, geometry, 16, plan, {}, false, q::ReplayPolicy::kCommands, 16u << 20,
        {.enabled = true, .policy = {1.F, 8, .9F}, .seed = 123}, 0,
        {.primary = hyle::inference::BackendKind::kCpu});
    const std::array shapes{std::size_t{15}, std::size_t{1}};
    model.prepare_family(shapes);
    for (auto rows : shapes) model.plan_replay_uses(rows, 1, 1);
    model.prepare_execution(shapes);
    auto prompt = std::make_shared<std::vector<std::int32_t>>(15, 1);
    auto value = t::request("baseline-oversized", prompt, 3);
    const std::array turns{hyle::inference::GenerationTurn{*prompt, 3}, hyle::inference::GenerationTurn{}};
    value.progress.bind_open_turns(std::span(turns).first(1), 2, 15);
    value.prompt = value.progress.begin_turn(*value.warm_inputs[0]);
    t::execute(model, value);
    t::execute(model, value);
    const auto before = q::generation_boundary(*value.session->head);
    std::string refusal;
    try { (void)q::prepare_generation_call(model, value, 3, nullptr, {}); }
    catch (const std::runtime_error &error) { refusal = error.what(); }
    std::cerr << "actual_baseline_late_refusal=" << refusal << '\n';
    t::require(refusal == "MTP has exhausted the configured context capacity" &&
        value.session->length() == 16 && value.progress.generated.size() == 2 &&
        !value.progress.turn_done && value.progress.remaining_outputs() == 1 &&
        value.ledger->committed_count == 2 && value.progress.observed_commits() == 2 &&
        value.session->head->sampling.draw == 2 && q::generation_boundary(*value.session->head) == before &&
        !model.active_step && !model.carrier_borrowed,
        "baseline did not reproduce its exact late-refusal partial-commit boundary");
    const auto ids = value.progress.generated;
    t::retire(value);
    t::require(!model.snapshot_versions.live, "baseline witness retained state versions");
    std::cout << "{\"status\":\"BASELINE_REPRODUCED_LATE_CONTEXT_REFUSAL\",\"ordinary\":true,"
        "\"backend\":\"cpu\",\"fixture\":\"cached_untrained_A_H64_FFN128_V64\","
        "\"capacity\":16,\"prompt_rows\":15,\"quota\":3,\"partial_outputs\":2,"
        "\"committed_records\":2,\"observed_commits\":2,\"length\":16,\"draw\":2,"
        "\"turn_done\":false,\"remaining_outputs\":1,\"ids\":[" << ids[0] << ',' << ids[1]
        << "],\"final_versions\":0,\"GPU\":false,\"HTTP\":false}\n";
    return 0;
#else
    return qwen_turn_context_case::run(input);
#endif
  } catch (const std::exception &error) {
    std::cerr << "turn_context_failure=" << error.what() << '\n';
    return 1;
  }
}
