from pathlib import Path
import hashlib
import json

R=Path.cwd()
W=Path(__file__).resolve().parent
I=W/'implementation'

def load(p):return json.loads(p.read_bytes())
def pin(p):
    return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

before=load(I/'before-pins.json');after=load(I/'after-pins.json')
for x in before:
    p=R/x['path'];q=pin(p)
    assert (q['bytes'],q['sha256'])==(x['bytes'],x['sha256']),x['path']
assert {x['path'] for x in after}=={
    'engine/models/qwen35/main.cc','tests/tools/qwen_request_lifecycle_test.cc',
    'tests/tools/qwen_turn_context_case.h'}
assert not (R/'tests/tools/qwen_turn_context_case.h').exists()
for x in after:
    q=pin(I/'source'/x['path'])
    assert (q['bytes'],q['sha256'])==(x['bytes'],x['sha256']),x['path']
def report(side):
    p=I/'attempt2'/side/'run'
    assert load(p/'process.json')['exit']==0
    rows=[json.loads(x) for x in (p/'stdout.log').read_text(encoding='utf-8').splitlines() if x.startswith('{')]
    assert len(rows)==1
    return rows[0]
a,b=report('baseline'),report('candidate')
assert a['status']=='BASELINE_REPRODUCED_LATE_CONTEXT_REFUSAL'
assert (a['partial_outputs'],a['committed_records'],a['length'],a['remaining_outputs'],a['turn_done'])==(2,2,16,1,False)
assert b['status']=='PASS' and b['early_refused_outputs']==b['early_refused_commits']==0
assert a['ids']==b['exact_ids']==b['pending_only_ids']==[1,44]
assert b['exact_length']==b['pending_only_length']==16
assert a['draw']==b['exact_draw']==b['pending_only_draw']==2
assert a['final_versions']==b['final_versions']==0
for x in after:
    (R/x['path']).write_bytes((I/'source'/x['path']).read_bytes())
for x in after:
    assert pin(R/x['path'])==x
out=dict(status='INTEGRATED_EXACT_FINITE_CPU_CHECKED_SOURCE',before_files_verified=len(before),
         changed_paths=after,baseline_bug_reproduced=True,candidate_formal_helper_CPU_pass=True,
         identical_two_valid_token_sequences=[1,44],
         scope='Cached untrained A/H64/FFN128/V64 CPU C16 only; full lifecycle dispatch and other modes not rebuilt',
         source_patch=pin(I/'source.patch'),baseline=a,candidate=b,
         no_new_build_or_runtime=True)
(W/'root-integration.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['changed_paths','baseline','candidate']},indent=2))
