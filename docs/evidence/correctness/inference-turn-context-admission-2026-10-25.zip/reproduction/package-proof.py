"""Publish compact, source/raw-only evidence; never builds, runs models or deletes."""
from pathlib import Path
import hashlib
import json
import zipfile

R = Path.cwd()
W = R / '.scratch/inference-ordinary-boundaries-20261025'
I = W / 'implementation'
PUBLIC = R / 'docs/evidence/correctness/inference-turn-context-admission-2026-10-25.json'
ARCHIVE = PUBLIC.with_suffix('.zip')


def load(p):
    return json.loads(p.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size, sha256=sha(p.read_bytes()))


def save(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


summary = load(I / 'summary.json')
integration = load(W / 'root-integration.json')
assert integration['status'] == 'INTEGRATED_EXACT_FINITE_CPU_CHECKED_SOURCE'
after = load(I / 'after-pins.json')
for row in after:
    assert pin(R / row['path']) == row
assert integration['changed_paths'] == after
assert summary['actual_baseline']['status'] == 'BASELINE_REPRODUCED_LATE_CONTEXT_REFUSAL'
assert summary['actual_candidate']['status'] == 'PASS'
assert summary['actual_baseline']['ids'] == summary['actual_candidate']['exact_ids'] == summary['actual_candidate']['pending_only_ids'] == [1, 44]

# Only the superseded failed-fixture app products are nominated. No deletion.
deletable = []
for folder in [I / 'attempt1/baseline/compile', I / 'attempt1/baseline/link']:
    for p in sorted(folder.iterdir()):
        if p.is_file() and p.suffix.lower() in {'.obj', '.exe', '.dll', '.exp', '.lib', '.pdb'}:
            assert p.resolve().is_relative_to(W.resolve()) and not p.is_symlink()
            deletable.append({**pin(p), 'resolved': str(p.resolve()), 'hardlink_count': p.stat().st_nlink})
retain = []
for side in ['baseline', 'candidate']:
    for name in ['compile/unit.obj', 'link/component.exe', 'link/component.exp', 'link/component.lib',
                 'link/hyle_ggml_cpu_pure_ffa4_current.dll']:
        p = I / 'attempt2' / side / name
        if p.exists():
            retain.append(pin(p))
plan = load(I / 'execution-plan2.json')
for p in [Path(row['path']) for row in plan['required_current_objects'].values()] + [Path(plan['native']['path'])]:
    retain.append(pin(p))
cleanup = dict(status='PROPOSED_NOT_PERFORMED', delete=deletable, count=len(deletable),
               logical_bytes=sum(x['bytes'] for x in deletable), retain=retain,
               rule='Root test.ps1 owns exact preview/Apply. Preserve all current attempt2 products, shared objects/original DLL, source and raw logs.')
save(W / 'cleanup-candidates.json', cleanup)

files = {}


def add(p, member):
    assert p.is_file() and p.suffix.lower() not in {'.obj', '.exe', '.dll', '.exp', '.lib', '.pdb', '.bin', '.gguf', '.safetensors'}
    assert member not in files
    files[member] = p


for name in ['source.patch', 'before-pins.json', 'after-pins.json', 'source-checks.json', 'summary.json',
             'review.md', 'first-failure.md', 'execution-plan.json', 'execution-plan2.json', 'check.py', 'consumer.cc']:
    add(I / name, 'implementation/' + name)
add(I / 'source/tests/tools/qwen_turn_context_case.h', 'source/tests/tools/qwen_turn_context_case.h')
add(I / 'source/tests/tools/qwen_request_lifecycle_test.cc', 'source/tests/tools/qwen_request_lifecycle_test.cc')
for name in ['consumer.cc', 'qwen_turn_context_case.h', 'check.py', 'after-pins.json']:
    add(I / 'attempt1' / name, 'history/attempt1/' + name)
for attempt, sides in [('attempt1', ['baseline']), ('attempt2', ['baseline', 'candidate'])]:
    for side in sides:
        for stage in ['compile', 'link', 'run']:
            folder = I / attempt / side / stage
            names = ['command.json', 'process.json', 'stdout.log', 'stderr.log']
            names += ['dependencies.json', 'repository-inputs.json'] if stage == 'compile' else []
            names += ['ready.json'] if stage == 'link' else []
            names += ['result.json'] if stage == 'run' else []
            for name in names:
                p = folder / name
                if p.exists():
                    add(p, '/'.join(['raw', attempt, side, stage, name]))
for name in ['root-integrate.py', 'root-integration.json']:
    add(W / name, 'root-integration/' + name)
for name in ['ordinary-findings.md', 'request-findings.md', 'retirement-design.md', 'request-source-pins.json']:
    if (W / name).exists():
        add(W / name, ('source-review/' if name == 'ordinary-findings.md' else 'followup/source-only/') + name)
independent = W / 'capacity-independent-review.md'
if independent.exists():
    add(independent, 'independent-review/' + independent.name)
followup = W / 'followup-scope.txt'
followup.write_text('Only the whole-turn context admission guard and its regression helper/dispatch are implemented by this evidence. request-findings.md, request-source-pins.json and retirement-design.md are source-only follow-up records. Retirement observation/status changes described there are NOT implemented or runtime-verified by this batch. Historical private summary/source-checks describe the pre-integration checkpoint; root-integration records the later exact integration without further build/run. Full prefix-hit/chunk/extreme-size boundaries are source-reviewed only, not new actual CPU cases.\n', encoding='utf-8', newline='\n')
add(followup, 'followup/README.txt')
add(W / 'cleanup-candidates.json', 'cleanup/proposed-only.json')
add(Path(__file__).resolve(), 'reproduction/package-proof.py')

manifest = dict(scope='Compact source/raw evidence; no binary, SDK, weights or complete engine tree',
                members=[dict(member=n, **pin(p)) for n, p in files.items()])
save(W / 'archive-manifest.json', manifest)
files['manifest.json'] = W / 'archive-manifest.json'
PUBLIC.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(ARCHIVE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for member, p in files.items():
        z.write(p, member)
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(files)
    for member, p in files.items():
        assert sha(z.read(member)) == sha(p.read_bytes())
    logical = sum(x.file_size for x in z.infolist())

public = dict(status='PASS_FINITE_ORDINARY_TURN_CONTEXT_ADMISSION_CANONICAL_INTEGRATED', date='2026-10-25',
    problem=summary['problem'], change=summary['change'],
    actual_scope='Pure CPU C16, cached untrained A/H64/FFN128/V64; actual model consumer, not publisher model quality',
    source=after, baseline_main=summary['before_main'], canonical_integration=integration,
    actual=dict(first_fixture_error=dict(status='FIXTURE_FAILURE_BEFORE_GENERATION_NOT_PRODUCT_BUG',
        compile=summary['first_failure']['compile'], link=summary['first_failure']['link'], run=summary['first_failure']['run'],
        error=summary['first_failure']['error'], cause=summary['first_failure']['cause'], correction=summary['first_failure']['correction']),
        baseline=dict(result=summary['actual_baseline'], feature_pass=False,
            interpretation='The diagnostic process successfully reproduced the original late refusal after two committed outputs; it does not pass the corrected feature contract.',
            process=summary['actual_processes']['baseline']),
        candidate=dict(result=summary['actual_candidate'], formal_helper_body_actually_compiled_and_run=True,
            process=summary['actual_processes']['candidate'])),
    counts=summary['counts'], fixture=summary['fixture'],
    actual_link_contract=dict(inputs_per_image=130, common_inputs=129, app_input=1,
        current_object_sources=plan['required_current_objects'], native=plan['native'],
        closure='Original prefix-admission attempt3 strict CPU command/retained link closure. No SDK/core/provider rebuild. Actual dependency pins and full 130-input maps are in archive raw compile/link records.'),
    assertions=dict(early_refusal='Open borrowed turn P15/quota3 is refused before input_turn/Session/ledger/sampling/output publication; begin_turn may already be marked.',
        exact_fit='No-turn-span P15/quota2 commits length16, outputs [1,44], draw2; final output remains pending, not another KV input.',
        pending_only='Later empty suffix/quota1 consumes its historical pending once into the final context row, outputs [1,44], draw2.',
        retirement='Actual finite CPU payload stop/drain/try_retire returns final state version count zero; no native device failure injected.'),
    limits=summary['limits'],
    source_only_boundaries=['P=C/quota1 full prefix hit; resumed/cancelled chunk admission; extreme size/overflow arithmetic: source review only, no new model run.',
        'The existing lifecycle --turn-context dispatcher and other modes were not recompiled as a full target; only the same new formal helper body was compiled/run by the private candidate consumer.'],
    independent_review=dict(included=independent.exists(), scope='Source-only capacity review, no additional build/runtime'),
    followup=dict(status='NOT_IMPLEMENTED_SOURCE_ONLY', records=['request-findings.md', 'retirement-design.md', 'request-source-pins.json'],
        retirement_fix_claimed=False),
    archive={**pin(ARCHIVE), 'members': len(files), 'logical_bytes': logical, 'CRC_and_member_SHA256_checked': True,
        'manifest': pin(W / 'archive-manifest.json')},
    cleanup=dict(status='PROPOSED_NOT_PERFORMED', plan=pin(W / 'cleanup-candidates.json'),
        files=cleanup['count'], logical_bytes=cleanup['logical_bytes'], deleted_files=0,
        retained='Latest attempt2 images/app objects and all shared objects/original native DLL/source/raw logs'),
    new_build_or_run_after_root_integration=False, HTTP_requests=0, GPU_processes=0,
    performance_or_independent_numeric_oracle_claim=False)
save(PUBLIC, public)
publication = dict(public_json=pin(PUBLIC), archive=pin(ARCHIVE), members=len(files), logical_bytes=logical,
                   cleanup_count=cleanup['count'], cleanup_logical_bytes=cleanup['logical_bytes'])
save(W / 'publication.json', publication)
print(json.dumps(publication, indent=2))
