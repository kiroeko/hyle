# Ordinary sampling / stop / context: bounded source findings

Source-only, 2026-10-25. Read current AGENTS.md, architecture sections on authoritative pending/RNG, turn admission, open-input bounds, output credit and prior prefix/frontier fixes. No build/test/GPU/network, product/docs/git/remote changes. This is not a new runtime pass or an MTP functional audit.

## 1. Direct / incremental ordinary requests lack the CLI's whole-turn context admission

**Classification:** concrete model-adapter admission gap, not Compute/Graph out-of-bounds execution and not a CLI regression. Exactly one new finding.

- The current policy is explicit: qwen35/README.md:59 requires the prompt and maximum generation journey to fit context. `generation_schedule.h:139-152` preflights each turn's pending row, suffix and `max_outputs-1`; unscheduled CLI has the same rule at `main.cc:6509-6513`.
- The actual incremental consumer bypasses the schedule parser: `tests/tools/qwen_request_lifecycle_test.cc:92,114,173-176` binds/extends shared turns and calls `prepare_generation_call` directly. This is an existing supported bottom-layer consumer, not a proposed server interface. `RequestProgress::bind_open_turns/extend_turns` correctly bound only host prompts/output reservations, and architecture:240-246 expressly leaves actual model-context admission to the model owner.
- `main.cc:5414-5420` checks only that the complete current `request.prompt` (including a later pending slot) fits `capacity-session.length()`. It does not admit the remainder of the turn's output quota. The request can therefore commit outputs before learning that its admitted turn can never complete.
- `main.cc:5523-5524` eventually throws at zero remaining context. No shared context-stop terminal exists: `SamplingLimits::remaining_context` narrows an episode, while `AcceptedPrefix::stopped` is only EOS (`mtp_acceptance.h:89-95`); ordinary record/observation stop is also only EOS (`main.cc:4514,5136`). `RequestProgress::apply_outputs` ends a turn only on its quota or caller's stopped fact (`request_progress.h:190-202`). There is no request terminal state to observe for context exhaustion.

### Reachable sequence with no EOS assumption

Use the already cached untrained A-only H64/FFN128/**V64** fixture and C16. The model's EOS IDs 248044/248046 cannot occur in V64, so this does not depend on a speculative output choice. Cold-prepared T15 and T1 are sufficient.

| Step | Model boundary | Host progress |
|---|---|---|
| Request P15 / quota3 before preparation | no head, no committed ledger | generated0, prefilled=false, turn_done=false |
| Current prefill commits | length15, pending a, RNG draw1 if random | generated[a], remaining2, turn_done=false |
| Current ordinary decode commits a | length16, pending b, RNG draw2 | generated[a,b], remaining1, turn_done=false |
| Next prepare and every same-request retry | unchanged length16/head/ledger | throws `... exhausted ... context capacity`, never marks a terminal turn |

An equivalent later-turn trigger is an existing head at length15 followed by pending-only input and quota2. The host extension is valid, but only one output can be produced before the same permanent error. No invalid token or overflow is needed.

### Smallest consistent correction (proposal only)

Keep shared RequestProgress model-independent. In the model-specific initial-turn input-admission branch, before publishing `input_turn`, looking up a prefix or creating a Session, perform overflow-safe maximum-journey admission: after validating `prompt_rows <= remaining_context`, require `remaining_outputs-1 <= remaining_context-prompt_rows`. Prompt already includes a later historical pending exactly once. This preserves the current CLI rule; do not silently redefine context exhaustion as EOS or clip immutable user quota in this slice.

Important boundaries: (a) initial full-prefix P16/quota1 remains valid: its final returned pending costs no new context row, and lookup/frontier still runs normally; (b) P15/quota2 ends at length16 and returns its second valid pending, also allowed; (c) a later pending-only quota1 can consume the final remaining row; (d) validate the **whole** turn once before any chunk, not the full original prompt against each shrinking context after state-only chunks; original `input_turn`/`turn_input_consumed` and cancellation retry semantics must stay intact; (e) do not compare total request quota across earlier/future turns with this turn's remaining context.

### Minimal reproduction / regression plan, not run

Reuse the existing pure-CPU tiny source/weights and host closure from `.scratch/inference-prefix-admission-20261025/execution-plan.json`, fixture `.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture/weights.tsv`; no new SDK/weights/backend. One consumer TU / one CPU process can demonstrate current P15/quota3 above; after a bounded correction assert the same request rejects before Session/head/ledger/sampling/output publication (the already permitted begin-turn marker may remain), then use a separate P15/quota2 control to prove the final context row still returns its pending output and completes. Existing shared host tests already cover gap/duplicate/quota failure, pending-only and output reservation; do not rerun a model matrix. Full-hit/chunked boundaries can initially be source-reviewed against the existing retained proofs, adding an actual case only if the changed branch needs it.

## Confirmed existing boundaries; no additional defect asserted

- `RequestProgress` preflights contiguous ordinal, actual constructor quota and reserved output extent before mutation; duplicate observations are no-ops. `observe_generation_commits` stages reserved family bookkeeping before advancing the shared cursor (`main.cc:5121-5187`). No new duplicate-observation failure was found.
- EOS ends the **current turn**, not the entire open request (README:17 and shared early-stop tests); a subsequent pending-only turn is intentional. Stopped/open-input quota refunds and repeated observations already have host evidence; no new common-progress flaw found in this narrow read.
- Prefix import/adoption now follows successful Session/frontier admission, and full-hit output is observed once without inventing a Graph ordinal (`main.cc:5435-5486,5560-5576`). The selected frontier's early retirement gate is already integrated. These are prior fixes, not reopened findings.
- Caller output credit is checked before new admission, and ledger-backed postcommit IO failure is caught by `execute_generation_calls` and observed from authoritative committed facts (`main.cc:5402-5404,5683-5707`). This source review does not newly validate native faults or every IO path.

## Source pins

- `engine/models/qwen35/main.cc` SHA256 `75d4d9cb214602a5971fd5f8abe5d9563b86bcbb2575fa7d7ce76e12ce8035c9`.
- `engine/inference/request_progress.h` SHA256 `10999f16df16658b1b128b50b852c12a608acf6fc5a0578dfe8400c739bc14f6`.
- `engine/models/qwen35/generation_schedule.h` SHA256 `ef99737c5e6714e570a269c8d96979de31da86584b7d4d679cb26d3ae721da4f`.
- `engine/inference/mtp_acceptance.h` SHA256 `8d72de0dc241901758188fddc78b04f5b3aedde2e500ef521c71ec13a05df9ec`.
