# Retirement observation: minimal interface convergence

Source-only follow-up, current main75d4d9cb; no code/test/build/GPU/network/remote changes. Goal: an error never grants release permission and never prevents the owner from collecting actual retirement. Post-commit observer IO remains outside retirement status; normal peer cancellation still leaves its survivor usable.

## Existing pieces and what they cannot replace

- `compute::Completion::poll()->Result<CompletionPoll>` (`completion.h:8–11,38`) observes one accepted execution. An error is not proof that all native/page/resource lifetimes retired. Reusing kComplete as whole-Session retirement would lose that distinction.
- `RetainedResources::pending()` (`execution_resources.h:20–45`) is the actual original attachment's lifetime flag; its terminal callback deliberately does not own/cache another Status. Keep it unchanged: do not turn the scope-retention node into a second result store.
- `ColdResources::retire(bool)` drives the original backend and then checks all original pending attachments (`main.cc:2071–2081`). Its synthesized Unavailable-on-pending currently mixes incomplete cleanup with real backend error in one Status; the pending guard itself is the useful fact.
- `Session` already owns cumulative `retirement_status`; `drain()` already drives the original blocking retirement path. `Model::try_retire_episode` has the correct separate retirement/error internals. No new cleanup engine, Completion, queue or resource owner is required.

## Two possible shapes; prefer A

**A. One mandatory, named by-value fact:** a small `[[nodiscard]] RetirementObservation { bool retired; Status status; }`, with no conversion to bool, no owned native resources and no new persistent table. Replace Session's Result<bool> retirement observation with this return shape; do not keep the old overload/alias. `retired=false,status=error` and `retired=true,status=error` are both valid. Invalid API preconditions and failed cleanup also report status but cannot set retired=true without the original gate. Internally retain the original cumulative Session status, collect once, and export it on every path. Repeated stop returns the actual accumulated status. A bool must not be inferred from status.ok().

**B. Mandatory output reference:** `bool Session::try_retire(Status& observed) noexcept`, no optional/default argument and no Result<bool> error alternative. It merges the same cumulative error into the caller's required Status and returns only actual retirement. This avoids a named fact type but is easier to misuse across calls. Old owners must still migrate; it is not an optional compatibility escape. Session's original status remains authoritative while pending.

Neither shape makes every error fatal. The owner distinguishes requested pure Cancelled, original native/retirement failure and already-committed observer IO using the actual execution/ledger boundary. In particular, do not assign Session.failed in a generic catch or based on every non-Ok status. A later IO failure must not undo/pollute a committed head (`retirement_probe.cc:333–355`).

## Owner protocol, including errors

1. Request stop once; preserve its status but **do not `check(stop())` before collection**. Poll/collect the original owner. If a synchronous path needs progress, call existing drain then observe again; drain's returned error is not retirement proof. No busy loop and no alternate cleaner.
2. While observation.retired is false, keep the payload, key/Retiring directory charge, accepted Graph owners and original Session. Report an observed error if appropriate, but schedule further collection rather than declaring cleanup complete. Existing Session status retains the first real error across retries.
3. When retired is true, release the original Session/payload and directory/window reservation even if status is non-Ok; then report/classify that exact saved status. Do not retry cancelled work or admit unrelated native work implicitly after a real backend failure. Pure caller cancellation is an expected request outcome, not an exception that strands the payload.

The merge rule already exists at `main.cc:1363–1369 record_retirement_status`. If moved, share this exact inference-specific rule; do not globally change `Status::Update`, which intentionally keeps the first error. The observation struct does not need a new merger/ledger/container.

## Three actual runtime release sites

| Site | Minimal migration and ordering |
|---|---|
| Natural ordinary completion / idle eviction: `retire_generation_request`, main5755–5760, callers6070/6160 | Stop, collect/drain through the original Model, inspect both facts. Do not throw solely from stop before collection. Reset Session and release Window only after retired; retain/report the returned error afterward. A pending cleanup remains the same request, not an admission success. |
| Fixed replay LRU callback: `ensure_resident`, main6800–6815 | Its present `!Result || !bool => false` hides actual error as RetirementUnproven. The directory must clear a genuinely retired old entry, yet stop before admitting the new entry if the retirement outcome is a real failure. Smallest clean directory change: use the same two-fact callback/result, preserve existing `CacheAdmissionResult` and add its original retirement Status plus one distinct owner-failure enum result; clear old accounting when retired, then return that failure without entering the new entry. This is returned metadata, not a second owner/status table. Do not throw inside the callback before `collect_retired` can clear an already released owner. |
| Fixed prefix replacement: main6971–6977 | New adopted Session is local already. Retire the old Session using both facts; on pending, retain the old identity and unwind the uninstalled adopted candidate; on retired+failure, release the old Session, preserve/report failure and do not publish the replacement. Only retired+acceptable outcome installs the adopted Session/history. Do not ignore stop or collapse native error into a generic “cannot retire”. |

SessionCache's current boolean collect callback (`session_cache.h:133–143`) cannot carry known-retired-plus-error to its caller: returning false or throwing retains the old charge, while returning true continues admission. This is the one real companion interface that needs the same observation shape, rather than a sidecar error catcher or a second cleanup callback. Keep its existing pin/withdrawal/LRU algorithm and physical budget separation.

## Finite checks if implementation is selected

- Host: extend the existing SessionCache retirement tests with one callback sequence `{false,synthetic native Status} → {true,same Status}`. Require invisible+charged while pending; then old entry/charge released, original error returned and new entry not admitted. This checks a real owner/accounting behavior, not a mirror of the merger. Use legal Status::FromNative values; explicitly no native fault was injected.
- Host: keep the original seven `--retirement-status-only` merge checks; add repeated observation/stop visibility using legal Status values. Do not fabricate a Session or treat a constructed Status as an actual backend failure. Pure status checks alone cannot prove Model lifetime wiring.
- Existing actual probe only if needed: the current blocked native gate/SessionCache collector at `retirement_probe.cc:260–277` already distinguishes incomplete retirement from a released owner. A declared synthetic error can be injected through the public Session.retirement_status while the real gate is closed, then the same real gate opened: observation must return pending+error, later retired+the same error, and the original directory may finally release. This tests export/collection with real lifetimes, **not GPU fault handling**. No new model/backend matrix.
- Preserve the already-real post-commit IO continuation at333–355 and normal A-cancel/B-survives lifecycle assertion. Neither should become failed/poisoned. Actual backend fault injection, fatal-vs-recoverable native classification and all arbitrary request owners remain untested here.

Recommendation: A shared two-field observation plus the three explicit release migrations. Session/ColdResources keep their existing owners and retirement actions; RetainedResources stays untouched. No implementation or test was performed in this memo.
