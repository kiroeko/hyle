# Ordinary request boundaries: narrow source review

2026-10-25; source-only. No canonical edit, build, GPU/model/test execution, network, or remote operation. Read latest AGENTS, inference-design, existing requests-findings, prefix-admission review and the previous lifecycle/status fixes. This is not a re-audit of server/MTP/multimodal functionality.

## One reachable missing boundary: retirement completion can hide a newly observed error

The facts “native work really retired” and “that work failed” are separate. `main.cc:3930–3939` already expresses this correctly in `Model::try_retire_episode(Status* observed_status)`: collect/poll merges the real error, optionally exports it, and only actual retirement allows detach. `StepState::try_abort` may return true after its completion has reported an error and every original append/writer has legally retired (`:1401–1460`). That is successful cleanup, not successful computation.

The Session adapter drops the separate status: `Session::try_retire` (`:4957–4966`) calls `model_->try_retire_episode()` without its existing out-status. `detach_episode` stores the terminal error in each relevant `session.retirement_status` (`:3914–3927`), but try_retire can return true and reset the head. A second `Session::stop` returns unconditional Ok when stopping is already true (`:4944–4946`). Destructor drain intentionally ignores diagnostics (`:4974`), so it is not an owner-reporting fallback.

Concrete journey: owner submits ordinary A+B; asks A to stop, receiving the then-current Ok/pure requested-cancel fact; a later poll/retirement collection observes an actual failure; cleanup genuinely completes. `A.try_retire()` returns true, so an owner following stop→try_retire→Window.retire_active/release can release the payload without receiving the later error. Repeating stop reports Ok. The preserved field is accessible, but existing API returns do not require the owner to retrieve it. This does not claim that a particular GPU fault was injected or necessarily permits native cleanup; it is the source-supported branch where cleanup is successful.

Minimal correction is to reuse the existing out-status mechanism, not reinterpret bool: add optional `Status* observed_status` to Session::try_retire, merge/export its existing retirement_status on both pending/retired outcomes, and make repeated stop expose its accumulated status rather than erase it. Keep actual bool retirement, original errors from cleanup, Session head release and all Graph/page gates unchanged. A small owner helper should classify the exported outcome before requeue/release, while still requiring true retirement for payload reuse. Do not introduce another terminal-state table, executor or permission owner.

Related resubmission observation, not a second independently proved bug: `prepare_evaluations:4075` rejects stopping/failed/pending; `failed` has no assignment in this TU. An unchanged B can therefore be mechanically prepared after its retirement_status received a real error. This must not be “fixed” by poisoning every catch/error: request-local post-commit IO and normal peer cancellation are valid continuation paths. The shared owner needs explicit outcome classification; no blanket “has error => poison Session” rule is justified here.

## Preserve three different outcomes

| Situation | Actual committed state | Safe owner behavior |
|---|---|---|
| Expected caller cancellation, no native error | This aborted batch publishes nothing; unchanged B retains original head/ledger/pending/RNG | After actual whole-batch retirement, cancel A; requeue B with its same key. Existing detach exception remains. |
| Actual completion/native/retirement failure | Inspect original ledger/head witness; unknown retirement is never release permission | Export original failure even when retired=false; retain guards until true. Owner decides whether recovery is supported; do not silently treat it as normal cancellation or request-local IO. |
| Observer/trace IO fails after publish | Original head+ledger already committed | Exactly-once host observation and future continuation remain allowed. `retirement_probe.cc:333–355` explicitly checks this; the exception must not set failed or undo the head. |

The third path already stays separate: normal finish detaches the committed episode before entry observation; a later observer exception finds no active episode to abort. Existing execute_generation_calls catch observes original committed ledgers before rethrow (`main.cc:5705–5707`). No request-wide error registry is needed to preserve this distinction.

## Shared status rule and smallest host check

Current reusable rule is `main.cc:1363–1369 record_retirement_status`: promote an earlier pure caller Cancelled when a later real/non-pure-cancel error arrives; otherwise preserve the first real error. The common base `hyle::Status::Update` (`include/hyle/error/status.h:345–352`) deliberately keeps the first non-Ok and cannot replace that specialized cancellation rule. `engine/inference` currently has no equivalent helper. If shared ownership needs it, move this exact small function to a shared inference header and keep qwen call sites direct; do not globally change Status::Update or add a wrapper status object.

Reuse `tests/tools/qwen_request_lifecycle_test.cc:26–48` / `--retirement-status-only`: the existing seven legal host Status checks already cover pure cancel→real/native/native-Cancelled and preservation of the first real error. Extend only with the split-outcome assertions: a synthesized later native Status remains owner-visible for both retired=false and retired=true; duplicate export/stop cannot turn it into Ok; an unrelated post-commit IO Status is not merged into retirement facts. No fake Session constructor, GPU error injection, mocked permission owner or new allocator/framework is needed. These host checks establish status policy only; final Session wiring needs source/strict compile and, if selected, one existing tiny actual owner case, not a new model matrix. No test was run by this review.

## Checked and intentionally not reported as new gaps

- RequestWindow queue/paused cancellation, stale generations, FIFO wake/requeue and retirement-before-reuse; no new primitive defect found.
- RequestProgress stable borrowed extension, wait-for-input versus request_done, EOS unused-quota refund, pending-once next-turn begin, atomic bounds; no new primitive defect found.
- OutputDelivery current-produced credit, absolute/duplicate ACK and owner-key routing; no new primitive defect found.
- The previously fixed prefix admission rollback, complete Text R2 suffix admission, ordinary same-batch Cancelled survivor, chunked prefill state-only and late observer IO boundaries were preserved in this review.
- Finite CLI still preloads schedules and does not itself implement a live transport/event loop; that is already documented and not re-listed as a new finding. Existing requests-findings#5 broader per-request terminal outcome work is not claimed complete here.
- No device failure was injected, no actual memory pressure/driver failure or arbitrary concurrent host control was exercised, and no backend×model matrix was audited.
