from pathlib import Path
import hashlib
import json
import zipfile

R=Path.cwd();W=Path(__file__).resolve().parent;C=W/'turn-context-cleanup'
J=R/'docs/evidence/correctness/inference-turn-context-admission-2026-10-25.json';Z=J.with_suffix('.zip')
def load(p):return json.loads(p.read_bytes())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())

d=load(J);old=d['archive'].copy()
for x in d['source']:
    assert pin(R/x['path'])==x
cleanup=load(C/'removed.json');assert cleanup['applied'] and len(cleanup['files'])==5
assert all(not Path(x['path']).exists() for x in cleanup['files'])
for x in load(W/'cleanup-candidates.json')['retain']:
    assert pin(R/x['path'])==x
review=dict(status='INDEPENDENT_SOURCE_REVIEW_NO_BLOCKER',reviewer='/root/mtp_performance_audit',
            received='collaboration message',main_sha256=d['source'][0]['sha256'],
            patch=pin(W/'implementation/source.patch'),
            checks=['First turn only, before input marker/prefix/Session publication',
                    'Subtract after bounds, no overflowing extent sum',
                    'Remaining current-turn quota, not cumulative request output count',
                    'Final pending not charged as another context row',
                    'No repeated whole-prompt charge after committed chunks'],
            source_only_boundaries=['Full prefix P=C/quota1','Intermediate chunk continuation','size_t extreme'],
            no_new_build_or_runtime=True,
            limits='Finite actual CPU journeys are those in original proof; lifecycle dispatch/other platforms not rerun')
review_path=W/'root-independent-review-receipt.json'
review_path.write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8',newline='\n')
files={'root-followup/independent-review.json':review_path,
       'root-followup/cleanup/plan.json':C/'plan.json',
       'root-followup/cleanup/preview.json':C/'preview.json',
       'root-followup/cleanup/removed.json':C/'removed.json',
       'root-followup/cleanup/delete-commands.ps1.txt':R/'test.ps1',
       'root-followup/finalize-evidence.py':Path(__file__).resolve()}
independent_file=W/'capacity-independent-review.md'
if independent_file.exists():files['root-followup/capacity-independent-review.md']=independent_file
manifest=dict(previous_archive=old,cleanup_files=5,logical_bytes=38093841,
              physical_bytes_freed_unknown=True,latest_and_shared_inputs_preserved=True,
              members={name:pin(p) for name,p in files.items()})
mp=C/'manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
files['root-followup/manifest.json']=mp
with zipfile.ZipFile(Z) as src:data={name:src.read(name) for name in src.namelist()}
assert not set(data)&set(files),'Already appended'
data.update({name:p.read_bytes() for name,p in files.items()})
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for name,payload in data.items():out.writestr(name,payload)
with zipfile.ZipFile(Z) as check:assert check.testzip() is None
d['archive'].update(pin(Z),members=len(data),logical_bytes=sum(map(len,data.values())))
d['archive']['manifest_scope']='Original agent members plus appended archive:root-followup/manifest.json'
d['root_followup']=dict(independent_review=review,cleanup=manifest)
J.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status=review['status'],archive=d['archive']),ensure_ascii=False))
