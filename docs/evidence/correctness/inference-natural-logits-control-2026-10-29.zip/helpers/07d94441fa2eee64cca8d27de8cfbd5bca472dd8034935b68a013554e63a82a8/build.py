"""One explicit consumer CXX/link and five bounded local-only cases; root executes."""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-natural-logits-20261029'
BASE = OLD / 'model-link-base.json'
PRIOR_HELPER = OLD / 'build.py'
spec = importlib.util.spec_from_file_location('controls_prior_logits', PRIOR_HELPER)
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
b, t = prior.b, prior.t
b.W = t.W = W
b.SOURCES = {'tiny': R / 'tests/tools/qwen_host_image_test.cc'}
b.CASES = {'controls-cpu': ('tiny', 'cpu', '--natural-logits-control'),
           'controls-cuda': ('tiny', 'cuda', '--natural-logits-control'),
           'logits-cpu': ('tiny', 'cpu', '--natural-logits'),
           'logits-cuda': ('tiny', 'cuda', '--natural-logits'),
           'natural-cuda': ('tiny', 'cuda', '--mtp-natural-relay')}
CONTROL_PARSER_READY = True


def prepare():
    base = t.read(BASE); previous_path = Path(base['previous_consumer']['path']); previous = t.read(previous_path)
    assert len(base['retained']) == 227
    t.exact(previous['object'])  # The retained current OBJ, never its deleted EXE.
    retained_keys = {t.key(row['path']) for row in base['retained']}; assert len(retained_keys) == 227
    for row in base['retained']: t.exact(row)
    old_objects = [arg for arg in base['link'] if arg.lower().endswith('.obj') and t.key(arg) not in retained_keys]
    assert len(old_objects) == 1
    source = b.SOURCES['tiny']; compile_args = []
    for index, arg in enumerate(base['compile']):
        if index and base['compile'][index - 1].lower() == '/sourcedependencies':
            arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        compile_args.append(arg)
    if not any(arg.lower().startswith('/fd') for arg in compile_args):
        compile_args.append('/Fd' + str(W / 'compile/tiny/unit.pdb'))
    assert sum(t.key(arg) == t.key(source) for arg in compile_args) == 1
    link_args = []
    for arg in base['link']:
        if t.key(arg) == t.key(old_objects[0]): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(arg) == t.key(W / 'compile/tiny/unit.obj') for arg in link_args) == 1
    assert all(sum(t.key(arg) == key for arg in link_args) == 1 for key in retained_keys)
    sources = prior.closure([str(t.canonical(row['path'])) for row in previous['project_dependencies']] + [str(source)])
    for rel in ('engine/inference/logits_inputs.h', 'tests/tools/qwen_natural_logits_case.h',
                'tests/tools/qwen_natural_logits_control_case.h'):
        assert t.key(R / rel) in map(t.key, sources), rel
    t.save(W / 'sdk-engine-dependencies.json', prior.sdk_engine_dependencies(base['retained']))
    env = t.read(OLD / 'environment.json'); env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local only; never print/archive environment values.
    t.save(W / 'plan.json', dict(base=t.pin(BASE), previous_consumer=t.pin(previous_path),
        units={'tiny': dict(source=str(source), compile=compile_args, link=link_args)}, retained=base['retained'],
        runtime=base['runtime'], sources=sources,
        fixtures=dict(conditional=prior.fixture(b.PLAIN), natural=prior.fixture(b.NATURAL)),
        sdk_engine_dependencies=t.pin(W / 'sdk-engine-dependencies.json'),
        helpers=[t.pin(__file__), t.pin(PRIOR_HELPER), t.pin(prior.NATURAL_HELPER),
                 t.pin(R / '.scratch/inference-indexed-store-20261028/build.py')],
        cases=b.CASES, control_parser_ready=CONTROL_PARSER_READY,
        counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, retained_inputs=227, inputs_per_link=228,
                    maximum_native_cases=5, downloads=0),
        policy='Explicit root actions only; no implicit retry, native work, SDK build/copy, download or cleanup.'))
    print('PREPARED one consumer CXX/link; 227 retained SDK inputs; no native execution')


def validate():
    plan = t.read(W / 'plan.json')
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    for row in [plan['base'], plan['previous_consumer'], plan['sdk_engine_dependencies'], *plan['helpers']]: t.exact(row)
    for consumer in t.read(plan['sdk_engine_dependencies']['path'])['engine_consumers']:
        t.exact(consumer['original_receipt'])
        for identity in consumer['source_identities']: t.exact(identity)
    for entry in plan['fixtures'].values():
        t.exact(entry['manifest']); t.exact(entry['prompt'])
        for row in entry['local_weight_sources']:
            st = Path(row['path']).stat()
            assert (st.st_size, st.st_mtime_ns, st.st_ino) == (row['bytes'], row['mtime_ns'], row['file_id'])
    return plan


b.validate = validate


def parse_controls(report, backend):
    assert CONTROL_PARSER_READY
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['case'] == 'natural-logits-control' and report['models'] == report['configurations'] == 1
    assert report['original_GenerationRequest'] is True and report['natural_RequestLoop'] is False
    assert report['synthetic_untrained'] is True
    assert report['quality_claim'] is False and report['performance_claim'] is False
    assert report['target_submissions'] == 9 and report['final_versions'] == 0
    assert report['terminated_hypothesis_callbacks'] == report['ended_prepare_provider_calls'] == 0
    assert report['stop_provider_calls'] == report['stop_verified_rows'] == 2 and report['stop_reserved_draws'] == 3
    assert report['successful_R2_Verify_submissions'] == report['cancelled_R2_Verify_submissions'] == 1
    assert report['survivor_R1_Verify_submissions'] == 1 and report['real_q_leases_per_R2'] == 4
    assert report['parked_resident_versions'] == 0
    for field in ('extra_stop_first_draft', 'absorbing_bonus_reuses_last_row', 'mixed_R2_dynamic_static',
                  'q_conditional_owners_cleared', 'whole_episode_retired',
                  'cancelled_heads_ledger_RNG_unchanged', 'independent_request_RNG',
                  'HostImage_same_key_restore', 'old_checkpoints_unchanged'):
        assert report[field] is True, field
    assert len(report['state_checks']) == 3
    prior.check_states(report['state_checks'])
    assert [row['sequence'] for row in report['state_checks']] == [0, 1, 2]
    for row in report['state_checks']:
        assert row['active_rows'] == row['physical_rows'] == 3


def parse_relay(report, backend):
    assert report['case'] == 'mtp-natural-relay' and report['backend'] == backend
    assert report['quality_claim'] is False and report['performance_claim'] is False
    assert report['natural_RequestLoop'] is True and report['controlled_acceptance'] is False
    assert report['models'] == 1 and report['journeys'] == 2 and report['output_limit'] == 40
    assert report['final_versions'] == 0 and len(report['state_checks']) == 1
    for field in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
        assert report[field] is True, field
    prior.check_states(report['state_checks'])
    for field in ('successor_submissions', 'successor_publications', 'pending_pairs_before_A_publish',
                  'deferred_waves', 'reserved_two_grants'):
        assert report[field] > 0, field


def parse(name):
    validate(); _, backend, _ = b.CASES[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    # One complete document can contain multiple nested reports and newlines.
    report = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
    assert isinstance(report, dict) and report['status'] == 'PASS' and report['backend'] == backend
    if name.startswith('controls-'): parse_controls(report, backend)
    elif name.startswith('logits-'): prior.parse_natural_logits(report, backend)
    else: parse_relay(report, backend)
    t.save(out / 'report.json', report); print('PASS', name, 'PID', process['pid'])


def run(name):
    if name.startswith('controls-'):
        assert CONTROL_PARSER_READY, 'Finalize control parser before starting its native consumer.'
    plan = validate(); _, backend, flag = b.CASES[name]
    fixture = plan['fixtures']['natural' if name == 'natural-cuda' else 'conditional']
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image'])
    t.execute([ready['image']['path'], '--' + backend, fixture['directory'], flag], W / 'runs' / name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action in ('freeze', 'validate'): getattr(b, action)()
    elif action in ('compile', 'parse_compile', 'link'):
        assert len(sys.argv) == 3 and sys.argv[2] == 'tiny'; getattr(b, action)('tiny')
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
