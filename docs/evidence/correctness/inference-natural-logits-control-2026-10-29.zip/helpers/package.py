"""Offline compact evidence. No build, consumer execution, download or deletion."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-natural-logits-control-2026-10-29'
spec = importlib.util.spec_from_file_location('controls_evidence_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
CASES = ('controls-cpu', 'controls-cuda', 'logits-cpu', 'logits-cuda', 'natural-cuda')
FORBIDDEN_NAMES = {'environment.json', 'env.json'}
FORBIDDEN_SUFFIXES = {'.obj', '.lib', '.dll', '.exe', '.pdb', '.bin', '.safetensors', '.gguf', '.map', '.exp'}


def terminal(directory):
    process = t.read(directory / 'process.json')
    assert process['state'] == 'TERMINAL', (directory, process)
    return process


def successful(process):
    return process['exit'] == 0 and not process['timed_out']


def checked_report(name, report):
    backend = name.rsplit('-', 1)[1]
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['quality_claim'] is False and report['performance_claim'] is False
    assert report['final_versions'] == 0
    if name.startswith('controls-'):
        b.parse_controls(report, backend)
        facts = {key: report[key] for key in ('models', 'target_submissions', 'stop_provider_calls',
            'stop_verified_rows', 'stop_reserved_draws', 'terminated_hypothesis_callbacks',
            'successful_R2_Verify_submissions', 'cancelled_R2_Verify_submissions', 'survivor_R1_Verify_submissions',
            'real_q_leases_per_R2', 'parked_resident_versions', 'independent_request_RNG',
            'HostImage_same_key_restore', 'natural_RequestLoop')}
        return facts, report['state_checks']
    if name.startswith('logits-'):
        b.prior.parse_natural_logits(report, backend)
        states = [state for journey in report['journeys'] for state in journey['state_checks']]
        return dict(models=3, natural_RequestLoop=True, stochastic_K2=report['stochastic_K2'],
            independent_request_RNG=report['independent_request_RNG'],
            late_provider_retired=report['late_provider_retired'], same_key_retry=report['same_key_retry'],
            complete_state_comparisons=len(states)), states
    assert name == 'natural-cuda'; b.parse_relay(report, backend)
    return {key: report[key] for key in ('models', 'outputs', 'resident_capacity', 'state_slots', 'hidden_slots',
        'successor_submissions', 'successor_publications', 'successor_discards', 'successor_refusals',
        'natural_RequestLoop', 'controlled_acceptance')}, report['state_checks']


def main():
    plan = b.validate(); frozen_path = W / 'source-freeze.json'; frozen = t.read(frozen_path)
    source_index = {t.key(row['path']): row for row in frozen}; assert len(source_index) == len(frozen)
    compiled_path = W / 'compile/tiny/compiled.json'; ready_path = W / 'ready-tiny.json'
    compiled = t.read(compiled_path); ready = t.read(ready_path)
    cxx = terminal(W / 'logs/compile-tiny'); link = terminal(W / 'logs/link-tiny')
    assert successful(cxx) and successful(link)
    assert compiled['process'] == cxx and ready['process'] == link and ready['compiled'] == compiled
    assert t.command(W / 'logs/compile-tiny/command.json') == plan['units']['tiny']['compile']
    assert t.command(W / 'logs/link-tiny/command.json') == plan['units']['tiny']['link']
    assert ready['source_freeze'] == t.pin(frozen_path)
    t.exact(compiled['object']); t.exact(ready['image'])
    assert len(plan['retained']) == 227
    assert collections.Counter(Path(row['path']).suffix.lower() for row in plan['retained']) == {'.obj': 202, '.lib': 25}
    assert ready['inputs'] == plan['retained'] + [compiled['object']]
    assert len({t.key(row['path']) for row in ready['inputs']}) == 228
    for row in compiled['project_dependencies']: assert source_index[t.key(row['path'])] == row
    assert [row for row in compiled['actual_dependencies'] if t.project(row['path'])] == compiled['project_dependencies']
    sdk_review = t.read(plan['sdk_engine_dependencies']['path'])
    assert len(sdk_review['inspected']) + len(sdk_review['unavailable']) == 202
    runs = {}; issues = []; states = []
    for name in CASES:
        out = W / 'runs' / name; process = terminal(out)
        _, backend, flag = b.b.CASES[name]
        fixture = plan['fixtures']['natural' if name == 'natural-cuda' else 'conditional']
        assert t.command(out / 'command.json') == [ready['image']['path'], '--' + backend, fixture['directory'], flag]
        report_path = out / 'report.json'; problems = []; facts = None; checked_states = []
        try: raw = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
        except json.JSONDecodeError: raw = None
        report = t.read(report_path) if report_path.is_file() else None
        if not successful(process): problems.append('Native process did not exit successfully.')
        if report is None: problems.append('No parsed report; preserve the original stdout/stderr.')
        else:
            if raw != report: problems.append('Parsed report differs from the complete original JSON document.')
            try: facts, checked_states = checked_report(name, report)
            except (AssertionError, KeyError, TypeError, ValueError) as error:
                problems.append('Report check failed: ' + repr(error))
        passed = not problems
        if passed: states.extend(checked_states)
        issues.extend(name + ': ' + problem for problem in problems)
        runs[name] = dict(process=process, verified_finite_pass=passed, problems=problems, facts=facts,
            report=(dict(member='records/runs/' + name + '/report.json', **t.pin(report_path)) if report is not None else None),
            logs_prefix='records/runs/' + name + '/')
    members = {}
    def add(path, name, expected=None):
        path = Path(path)
        assert path.name.lower() not in FORBIDDEN_NAMES and path.suffix.lower() not in FORBIDDEN_SUFFIXES
        body = path.read_bytes()
        if expected: assert (len(body), hashlib.sha256(body).hexdigest()) == (expected['bytes'], expected['sha256'])
        assert name not in members or members[name] == body
        members[name] = body
    for row in frozen:
        path = Path(row['path']); assert t.project(path) and path.is_relative_to(R)
        add(path, 'source/' + path.relative_to(R).as_posix(), row)
    for path in sorted((W / 'before').rglob('*')):
        if path.is_file():
            assert path.suffix.lower() in ('.h', '.cc', '.md')
            add(path, 'before/' + path.relative_to(W / 'before').as_posix())
    for rel in ('plan.json', 'source-freeze.json', 'ready-tiny.json', 'compile/tiny/compiled.json',
                'compile/tiny/dependencies.json', 'sdk-engine-dependencies.json'):
        add(W / rel, 'records/' + rel)
    for directory in (W / 'logs/compile-tiny', W / 'logs/link-tiny', *(W / 'runs' / name for name in CASES)):
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'report.json', 'host-report.json', 'checks.json'):
            path = directory / filename
            if path.is_file(): add(path, 'records/' + path.relative_to(W).as_posix())
    for name, fixture in plan['fixtures'].items():
        for field in ('manifest', 'prompt'):
            row = fixture[field]; add(row['path'], 'fixtures/' + name + '/' + Path(row['path']).name, row)
    for row in plan['helpers']:
        add(row['path'], 'helpers/' + row['sha256'] + '/' + Path(row['path']).name, row)
    add(__file__, 'helpers/package.py'); add(W / 'next-base.py', 'helpers/next-base.py')
    for field in ('base', 'previous_consumer'):
        row = plan[field]; add(row['path'], 'referenced/' + row['sha256'] + '/' + Path(row['path']).name, row)
    for consumer in sdk_review['engine_consumers']:
        row = consumer['original_receipt']
        add(row['path'], 'referenced/sdk-engine/' + row['sha256'] + '/' + Path(row['path']).name, row)
    manifest = dict(schema='hyle.natural-logits-control.archive.v1', source_freeze=t.pin(frozen_path),
        frozen_project_files=len(frozen), actual_compiled_project_files=len(compiled['project_dependencies']),
        members={name: dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest()) for name, body in sorted(members.items())})
    members['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    archive = DEST.with_suffix('.zip'); DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, body in sorted(members.items()): output.writestr(name, body)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist()) == set(members)
        assert json.loads(check.read('manifest.json')) == manifest
        for name, body in members.items(): assert check.read(name) == body, name
    status = 'PASS_FINITE_NATURAL_LOGITS_CONTROL' if not issues else 'INCOMPLETE_WITH_RETAINED_FAILURES'
    controls_pass = all(runs[name]['verified_finite_pass'] for name in ('controls-cpu', 'controls-cuda'))
    t.save(DEST.with_suffix('.json'), dict(schema='hyle.natural-logits-control.v1', status=status,
        source_inputs=[source_index[t.key(R / rel)] for rel in ('engine/inference/logits_inputs.h',
            'engine/models/qwen35/main.cc', 'tests/tools/qwen_natural_logits_control_case.h', 'tests/tools/qwen_host_image_test.cc')],
        source_freeze=t.pin(frozen_path), frozen_project_files=len(frozen),
        actual_compiled_project_files=len(compiled['project_dependencies']), image=ready['image'], object=compiled['object'],
        CXX=cxx, link=link, actual_process_counts=dict(CXX=1, failed_CXX=0, link=1, native=5,
            failed_native=sum(not successful(row['process']) for row in runs.values())),
        SDK=dict(retained_inputs=227, objects=202, libraries=25, SDK_CXX=0, NVCC=0, downloads=0,
            existing_object_receipts_inspected=len(sdk_review['inspected']), unavailable_object_receipts=len(sdk_review['unavailable']),
            existing_engine_consumers=len(sdk_review['engine_consumers']), source_identities_checked_unchanged=True),
        native_processes=runs, unresolved_evidence_issues=issues,
        complete_state_comparisons=dict(total=len(states), numerically_equivalent=len(states),
            byte_equal_state_payloads=sum(row['payloads_byte_equal'] for row in states), F32_GDN_absolute_budget=3e-6),
        scope=dict(conditional_controls_verified=controls_pass, stochastic_stop_shortening_verified=controls_pass,
            absorbing_bonus_and_zero_ended_prepare_callbacks_verified=controls_pass,
            mixed_R2_static_dynamic_policy_verified=controls_pass,
            shared_episode_cancel_and_unchanged_survivor_verified=controls_pass,
            same_key_HostImage_restore_and_continuation_verified=controls_pass,
            independent_actual_request_RNG_verified=controls_pass,
            natural_RequestLoop_control_case=False, trained_quality_claim=False, throughput_claim=False,
            full_goal_completion=False),
        records=dict(plan='records/plan.json', compile='records/compile/tiny/compiled.json', ready='records/ready-tiny.json',
            SDK_review='records/sdk-engine-dependencies.json', fixtures='fixtures/',
            note='Full nested natural reports, all state rows, commands and original process results are preserved in ZIP only; no inherited parser failure counts are attributed to this batch.'),
        limits=['Finite cached untrained GA/H64/V64/C16 CPU/CUDA components use actual singleton sampling inputs and original kernels; acceptance is never forced by a selector.',
            'The new control consumer uses original GenerationRequest, RequestWindow and native episode owners. It does not claim a new end-to-end RequestLoop control journey.',
            'Stop consumes one target row, repairs lag0 and reserves three actual stochastic draw addresses after a real one-draft Verify2. Its unreachable bonus retains the last live immutable policy without querying a terminated grammar.',
            'Mixed R2 compares static and dynamic policies against original R1 consumers, with each actual seed/stream/draw preserved. Whole-episode cancellation is retained; the dynamic survivor resumes after exact HostImage park/restore on its original key.',
            'Natural K1/K2/cache RequestLoop consumers and the real cached Qwen CUDA greedy K1 pipeline are separate regressions; they do not imply all control/provider/backend combinations are complete.',
            'Only new F32 GDN computations use the pre-existing3e-6 absolute comparison budget; non-GDN state and old checkpoints remain exact.',
            'Prior helpers are reused as source dependencies. Prior native/parser failures are not copied into this batch process counts. No current full throughput comparison, SDK rebuild or model download is performed.',
            'Environment values, tensor payloads and binaries are excluded. Any failed actual process/report remains a failure in the evidence.'],
        archive=t.pin(archive), archive_members=len(members), crc_and_member_sha256_readback=True))
    print('ARCHIVE WRITTEN', archive.name, t.pin(archive)['bytes'], t.pin(archive)['sha256'], status)


if __name__ == '__main__': main()
