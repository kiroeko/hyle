from pathlib import Path
import hashlib
import json
import zipfile

root = Path.cwd()
base = root / '.scratch/qwen-multi-draft-20261024'
evidence = root / 'docs/evidence/correctness'
name = 'mtp-gguf-source-capability-2026-10-24'

def identity(path):
    return dict(path=path.relative_to(root).as_posix(), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

before = base / 'gguf-mtp-source-before'
after = base / 'gguf-mtp-source-after'
assert 'invalid prepared roles were accepted' in (before / 'run/stderr.log').read_text()
assert json.loads((before / 'run/process.json').read_text())['exit'] == 1
assert 'PASS 299 checks' in (after / 'run/stdout.log').read_text()
assert json.loads((after / 'run/process.json').read_text())['exit'] == 0
sources = [root / 'engine/models/qwen35' / x for x in
           ['prepared_gguf_roles.h', 'prepared_roles.h', 'model_geometry.h']]
sources += [root / 'tests/tools' / x for x in ['qwen_prepared_roles_test.cc', 'qwen_geometry_fixture.h']]
members = list(sources) + [Path(__file__)]
for folder in [before, after]:
    for section in ['compile', 'link', 'run']:
        for pattern in ['*.json', '*.log']:
            members.extend((folder / section).glob(pattern))
members.append(after / 'summary.json')
archive = evidence / (name + '-logs.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as out:
    for path in sorted(set(members)):
        out.write(path, path.relative_to(root).as_posix())
proof = dict(date='2026-10-24', scope='Prepared GGUF metadata capability guard; no weight body, device or performance claim.',
    problem='The main entry rejected MTP on a zero-NextN source, but select_gguf_roles itself silently returned ordinary roles for include_mtp=true.',
    fix='Reject an explicit MTP request unless the source geometry declares one NextN layer; ordinary zero-NextN sources remain legal.',
    before=dict(exit=1, diagnostic='invalid prepared roles were accepted',
                prepared_gguf_header_sha256='9d8bb89742960f45ad71005197f29ab09ac92fdd8b5af33fc1188ef8f2563810'),
    after=dict(exit=0, checks=299, new_checks=4,
               cases=['Direct ordinary zero-NextN selection succeeds', 'Direct MTP zero-NextN selection rejects',
                      'Shared ordinary zero-NextN reader succeeds', 'Shared MTP zero-NextN reader rejects']),
    reuse='The existing 295 metadata checks run in the same standard-library-only program, including three cached real V2 manifests.',
    SDK_builds=0, HTTP=0, model_payload_bytes_read=0, sources=[identity(p) for p in sources],
    archive=identity(archive), archive_members=len(set(members)))
(evidence / (name + '.json')).write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(passed=True, checks=299, archive_bytes=archive.stat().st_size)))
