"""Offline compact evidence only. Never build, run consumers or delete files."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import math
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-natural-logits-2026-10-29'
spec = importlib.util.spec_from_file_location('natural_logits_evidence_build', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
CASES = ('logits-cpu', 'logits-cuda', 'verify-cpu', 'verify-cuda', 'natural-cuda')
FORBIDDEN_NAMES = {'environment.json', 'env.json'}
FORBIDDEN_SUFFIXES = {'.obj', '.lib', '.dll', '.exe', '.pdb', '.bin', '.safetensors', '.gguf', '.map', '.exp'}


def terminal(directory):
    process = t.read(directory / 'process.json')
    assert process['state'] == 'TERMINAL', (directory, process)
    return process


def successful(process):
    return process['exit'] == 0 and not process['timed_out']


def check_states(rows):
    assert isinstance(rows, list) and rows
    for row in rows:
        assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
        assert row['payloads_byte_equal'] == (not row['differences'])
        for diff in row['differences']:
            assert diff['role'] == 3 and diff['nonfinite_differences'] == 0
            assert math.isfinite(diff['maximum_absolute']) and 0 <= diff['maximum_absolute'] <= 3e-6


def report_facts(name, report):
    backend = name.rsplit('-', 1)[1]
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['quality_claim'] is False and report['performance_claim'] is False and report['final_versions'] == 0
    if name.startswith('logits-'):
        b.parse_natural_logits(report, backend)  # Pure checks; never execute the build helper's actions.
        journeys = []
        for row in report['journeys']:
            native = row['natural_report']
            journeys.append(dict(maximum_drafts=row['maximum_drafts'], provider_calls=row['provider_calls'],
                StateOnly_commits=row['StateOnly_commits'], Verify_commits=row['Verify_commits'],
                turn_row0_calls=row['turn_row0_calls'], late_private_draft_calls=row['late_private_draft_calls'],
                late_probability_leases=row['late_probability_leases'], complete_state_comparisons=len(row['state_checks']),
                actual_natural_counts={key: native[key] for key in ('session_count', 'turn_count', 'generated_tokens',
                    'active_sequences', 'prefix_full_hits', 'admitted_requests', 'retired_requests', 'admitted_turns')}))
        return dict(models=3, natural_RequestLoop=True, stochastic_K2=report['stochastic_K2'],
            independent_request_RNG=report['independent_request_RNG'], same_key_retry=report['same_key_retry'],
            late_provider_retired=report['late_provider_retired'], old_checkpoint_unchanged=report['old_checkpoint_unchanged'],
            journeys=journeys), [state for row in report['journeys'] for state in row['state_checks']]
    if name.startswith('verify-'):
        b.parse_verify(report, backend)
        return {key: report[key] for key in ('models', 'conditional_rows', 'target_submissions', 'actual_target_F32_oracles',
            'actual_private_q_rows', 'accepted_target_rows', 'RNG_reserved_draws', 'complete_target_draft_state',
            'same_q_retry', 'numeric_failure_retired', 'natural_conditional_supplier', 'final_versions')}, report['state_checks']
    assert name == 'natural-cuda' and report['case'] == 'mtp-natural-relay' and report['models'] == 1
    assert report['natural_RequestLoop'] is True and report['controlled_acceptance'] is False
    assert (report['resident_capacity'], report['state_slots'], report['hidden_slots']) == (1, 5, 6)
    assert report['outputs'] == report['output_limit'] == len(report['ids']) == 40
    for field in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
        assert report[field] is True, field
    for field in ('successor_submissions', 'successor_publications', 'pending_pairs_before_A_publish',
                  'deferred_waves', 'reserved_two_grants'):
        assert report[field] > 0, field
    assert len(report['state_checks']) == 1
    check_states(report['state_checks'])
    return {key: report[key] for key in ('models', 'outputs', 'ledger_records', 'resident_capacity', 'state_slots',
        'hidden_slots', 'successor_submissions', 'successor_publications', 'successor_discards', 'successor_refusals',
        'accepted_drafts', 'rejected_drafts', 'natural_RequestLoop', 'controlled_acceptance', 'final_versions')}, report['state_checks']


def main():
    plan = b.validate()
    repair_path = W / 'parser-repair.json'; repair = t.read(repair_path)
    for field in ('original_helper_saved', 'intermediate_helper', 'repaired_helper'):
        t.exact(repair[field])
    assert repair['original_helper']['sha256'] == repair['original_helper_saved']['sha256']
    assert repair['native_reexecuted'] is False and repair['compile_reexecuted'] is False
    assert repair['plan_overwritten'] is False and repair['prior_parser_failure']['native_failure'] is False
    assert len(repair['offline_parser_attempts']) == 1
    frozen_path = W / 'source-freeze.json'; frozen = t.read(frozen_path)
    source_index = {t.key(row['path']): row for row in frozen}
    assert len(source_index) == len(frozen)
    compiled_path = W / 'compile/tiny/compiled.json'; ready_path = W / 'ready-tiny.json'
    compiled = t.read(compiled_path); ready = t.read(ready_path)
    cxx = terminal(W / 'logs/compile-tiny'); link = terminal(W / 'logs/link-tiny')
    assert successful(cxx) and successful(link), 'Preserve any failed build attempt; do not claim it as a linked image.'
    assert compiled['process'] == cxx and ready['process'] == link and ready['compiled'] == compiled
    assert t.command(W / 'logs/compile-tiny/command.json') == plan['units']['tiny']['compile']
    assert t.command(W / 'logs/link-tiny/command.json') == plan['units']['tiny']['link']
    assert ready['source_freeze'] == t.pin(frozen_path)
    t.exact(compiled['object']); t.exact(ready['image'])
    sdk = {t.key(row['path']): row for row in plan['retained']}
    assert len(sdk) == 227
    assert collections.Counter(Path(row['path']).suffix.lower() for row in sdk.values()) == {'.obj': 202, '.lib': 25}
    assert ready['inputs'] == plan['retained'] + [compiled['object']]
    assert len({t.key(row['path']) for row in ready['inputs']}) == 228
    for row in compiled['project_dependencies']: assert source_index[t.key(row['path'])] == row
    assert [row for row in compiled['actual_dependencies'] if t.project(row['path'])] == compiled['project_dependencies']
    sdk_review = t.read(plan['sdk_engine_dependencies']['path'])
    assert len(sdk_review['inspected']) + len(sdk_review['unavailable']) == 202
    for consumer in sdk_review['engine_consumers']:
        t.exact(consumer['original_receipt'])
        for identity in consumer['source_identities']: t.exact(identity)
    runs = {}; issues = []; states = []
    for name in CASES:
        out = W / 'runs' / name; process = terminal(out)
        _, backend, flag = b.b.CASES[name]
        entry = plan['fixtures']['natural' if name == 'natural-cuda' else 'conditional']
        assert t.command(out / 'command.json') == [ready['image']['path'], '--' + backend, entry['directory'], flag]
        try: raw = json.loads((out / 'stdout.log').read_text(encoding='utf-8-sig'))
        except json.JSONDecodeError: raw = None
        report_path = out / 'report.json'; report = t.read(report_path) if report_path.is_file() else None
        problems = []; facts = None; checked_states = []
        if not successful(process): problems.append('Native process did not exit successfully.')
        if report is None: problems.append('No parsed report; original stdout/stderr remain authoritative.')
        else:
            if raw != report: problems.append('Parsed report differs from the original complete JSON stdout document.')
            try: facts, checked_states = report_facts(name, report)
            except (AssertionError, KeyError, TypeError, ValueError) as error:
                problems.append('Report check failed: ' + repr(error))
        passed = not problems
        if passed: states.extend(checked_states)
        issues.extend(name + ': ' + problem for problem in problems)
        runs[name] = dict(process=process, verified_finite_pass=passed, problems=problems, facts=facts,
            report=(dict(member='records/runs/' + name + '/report.json', **t.pin(report_path)) if report is not None else None),
            logs_prefix='records/runs/' + name + '/')
    members = {}
    def add(path, name, expected=None):
        path = Path(path)
        assert path.name.lower() not in FORBIDDEN_NAMES and path.suffix.lower() not in FORBIDDEN_SUFFIXES
        body = path.read_bytes()
        if expected: assert (len(body), hashlib.sha256(body).hexdigest()) == (expected['bytes'], expected['sha256'])
        assert name not in members or members[name] == body
        members[name] = body
    for row in frozen:
        path = Path(row['path']); assert t.project(path) and path.is_relative_to(R)
        add(path, 'source/' + path.relative_to(R).as_posix(), row)
    for path in sorted((W / 'before').rglob('*')):
        if path.is_file():
            assert path.suffix.lower() in ('.h', '.cc', '.md')
            add(path, 'before/' + path.relative_to(W / 'before').as_posix())
    for rel in ('plan.json', 'source-freeze.json', 'ready-tiny.json', 'compile/tiny/compiled.json',
                'compile/tiny/dependencies.json', 'sdk-engine-dependencies.json'):
        add(W / rel, 'records/' + rel)
    for directory in (W / 'logs/compile-tiny', W / 'logs/link-tiny', *(W / 'runs' / name for name in CASES)):
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'report.json', 'host-report.json', 'checks.json'):
            path = directory / filename
            if path.is_file(): add(path, 'records/' + path.relative_to(W).as_posix())
    for name, entry in plan['fixtures'].items():
        for field in ('manifest', 'prompt'):
            row = entry[field]; add(row['path'], 'fixtures/' + name + '/' + Path(row['path']).name, row)
    for row in plan['helpers']:
        if t.key(row['path']) == t.key(repair['original_helper']['path']):
            assert row == repair['original_helper']
            path = repair['original_helper_saved']['path']
        else: path = row['path']
        add(path, 'helpers/' + row['sha256'] + '/' + Path(row['path']).name, row)
    add(repair_path, 'records/parser-repair.json')
    for field in ('original_helper_saved', 'intermediate_helper', 'repaired_helper'):
        row = repair[field]
        add(row['path'], 'helpers/' + row['sha256'] + '/' + Path(row['path']).name, row)
    add(__file__, 'helpers/package.py'); add(W / 'next-base.py', 'helpers/next-base.py')
    for field in ('base', 'previous_consumer'):
        row = plan[field]; add(row['path'], 'referenced/' + row['sha256'] + '/' + Path(row['path']).name, row)
    for consumer in sdk_review['engine_consumers']:
        row = consumer['original_receipt']
        add(row['path'], 'referenced/sdk-engine/' + row['sha256'] + '/' + Path(row['path']).name, row)
    manifest = dict(schema='hyle.inference-natural-logits.archive.v1', source_freeze=t.pin(frozen_path),
        frozen_project_files=len(frozen), actual_compiled_project_files=len(compiled['project_dependencies']),
        members={name: dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest()) for name, body in sorted(members.items())})
    members['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    archive = DEST.with_suffix('.zip'); DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, body in sorted(members.items()): output.writestr(name, body)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist()) == set(members)
        assert json.loads(check.read('manifest.json')) == manifest
        for name, body in members.items(): assert check.read(name) == body, name
    changed = ('engine/inference/logits_inputs.h', 'engine/models/qwen35/main.cc',
               'tests/tools/qwen_natural_logits_case.h', 'tests/tools/qwen_host_image_test.cc')
    natural_verified = all(runs[name]['verified_finite_pass'] for name in ('logits-cpu', 'logits-cuda'))
    status = 'PASS_FINITE_NATURAL_LOGITS' if not issues else 'INCOMPLETE_WITH_RETAINED_FAILURES'
    t.save(DEST.with_suffix('.json'), dict(schema='hyle.inference-natural-logits.v1', status=status,
        product_sources=[source_index[t.key(R / name)] for name in changed],
        source_freeze=t.pin(frozen_path), frozen_project_files=len(frozen),
        actual_compiled_project_files=len(compiled['project_dependencies']), image=ready['image'], object=compiled['object'],
        CXX=cxx, link=link, actual_process_counts=dict(CXX=1, failed_CXX=0, link=1, native=5,
            failed_native=sum(not successful(row['process']) for row in runs.values())),
        offline_parser_repair=dict(errors=2, native_failure=False, native_reexecuted=False,
            compile_reexecuted=False, original_CPU_pid=repair['existing_native_process']['pid'],
            original_CPU_exit=repair['existing_native_process']['exit'],
            record='records/parser-repair.json',
            reasons=['Line-by-line parsing rejected a valid complete JSON document with nested reports.',
                'Intermediate cache report has two live prefix entries; final consumer retirement still verifies final_versions0.']),
        SDK=dict(retained_inputs=227, objects=202, libraries=25, SDK_CXX=0, NVCC=0, downloads=0,
            existing_object_receipts_inspected=len(sdk_review['inspected']), unavailable_object_receipts=len(sdk_review['unavailable']),
            existing_engine_consumers=len(sdk_review['engine_consumers']), source_identities_checked_unchanged=True),
        native_processes=runs, unresolved_evidence_issues=issues,
        complete_state_comparisons=dict(total=len(states), numerically_equivalent=len(states),
            byte_equal_state_payloads=sum(row['payloads_byte_equal'] for row in states), F32_GDN_absolute_budget=3e-6,
            stochastic_K2_actual_RNG_independently_checked=natural_verified,
            stochastic_K2_comparison='Full expected state/ledger copies translate only the known stream0 to stream1 after checking each actual seed/stream/draw. Actual streams are distinct, not byte-identical.'),
        scope=dict(natural_RequestLoop_provider_verified=natural_verified,
            genuine_conditional_q_and_target_Verify_verified=natural_verified,
            complete_target_draft_state_verified=natural_verified,
            finite_R1_CPU_CUDA_untrained_model_verified=natural_verified, models_per_new_case=3,
            stochastic_K2_late_probability_lease_retirement_verified=natural_verified,
            old_checkpoint_and_same_key_retry_verified=natural_verified,
            current_turn_and_future_prefix_verified=natural_verified,
            p_rows_reuse_frozen_q_inputs_verified=natural_verified,
            StateOnly_zero_provider_calls_verified=natural_verified,
            ordinary_cache_full_hit='N2, three one-output requests A/B/A with current request policy',
            EOS_stop_absorbing_implementation_exercised=False, cancellation_or_host_restore_exercised=False,
            mixed_R2_provider_exercised=False, trained_quality_claim=False, throughput_claim=False,
            full_goal_completion=False, verified_for_all_requested_cases=not issues),
        records=dict(plan='records/plan.json', compile='records/compile/tiny/compiled.json', ready='records/ready-tiny.json',
            SDK_review='records/sdk-engine-dependencies.json', fixtures='fixtures/',
            note='Three full nested natural reports, all state rows and all335 real weight identities/extents are kept only in original ZIP reports/plan, not repeated in this summary.'),
        limits=['Finite cached untrained GA/H64/V64/C16 checks use actual singleton bias/mask policy inputs; outputs are selected by the original kernels, without forced selectors or a trained quality claim.',
            'K1 stays greedy. K2 uses stochastic private q and target sampling with independent actual request seed/stream/draw checks. Only expected comparison copies translate known stream identity.',
            'The new natural consumer covers current-turn committed outputs, future hypotheses excluding pending, q-row/bonus callback counts, immutable p-row reuse, StateOnly zero calls and full state/ledger publication.',
            'The late K2 bonus failure happens after two actual valid q probability leases; original retirement, unchanged head/ledger/RNG/checkpoint, cleared leases and same-key retry are checked.',
            'The ordinary prefix-cache case is bounded to N2 and three one-output A/B/A requests. It does not claim all cache eviction, cancellation, host restore, mixed-R2 or provider composition cases.',
            'New EOS/stop absorbing-provider implementation is not exercised by this slice. Remaining broader cancellation/host-restore/mixed-R2 journeys stay pending; this is not full feature completion.',
            'Existing raw EvaluationRequest conditional Verify mathematics/publication and natural greedy CUDA K1 pipeline remain separate regressions; no broader pipeline applicability is claimed.',
            'Complete-state comparison keeps the original F32 GDN absolute budget3e-6. Distinct stochastic streams are not described as identical actual state bytes; old checkpoints remain exact.',
            'SDK review uses available adjacent receipts and unchanged engine dependencies; unavailable receipts remain explicit. No SDK CXX, NVCC, model download or complete performance benchmark is run by this helper.',
            'Environment values, tensor payloads and binaries are excluded. Original failing process/report/log facts are preserved and are never relabeled PASS.'],
        archive=t.pin(archive), archive_members=len(members), crc_and_member_sha256_readback=True))
    print('ARCHIVE WRITTEN', archive.name, t.pin(archive)['bytes'], t.pin(archive)['sha256'], status)


if __name__ == '__main__': main()
