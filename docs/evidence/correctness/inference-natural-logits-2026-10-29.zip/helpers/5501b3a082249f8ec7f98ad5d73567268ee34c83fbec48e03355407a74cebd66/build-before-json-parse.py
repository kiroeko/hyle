"""Thin natural logits consumer build. Explicit root actions only."""
from pathlib import Path
import importlib.util
import json
import re
import shlex
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-conditional-verify-20261029'
BASE = OLD / 'model-link-base.json'
NATURAL_HELPER = R / '.scratch/inference-mtp-natural-20261029/build.py'
spec = importlib.util.spec_from_file_location('natural_logits_existing_build', NATURAL_HELPER)
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
b.W = t.W = W
b.SOURCES = {'tiny': R / 'tests/tools/qwen_host_image_test.cc'}
b.CASES = {'logits-cpu': ('tiny', 'cpu', '--natural-logits'),
           'logits-cuda': ('tiny', 'cuda', '--natural-logits'),
           'verify-cpu': ('tiny', 'cpu', '--conditional-verify'),
           'verify-cuda': ('tiny', 'cuda', '--conditional-verify'),
           'natural-cuda': ('tiny', 'cuda', '--mtp-natural-relay')}
# Verify is the preceding frozen actual-target consumer contract.
# Both result contracts are final; root owns every execution action.
VERIFY_PARSER_READY = True
NATURAL_LOGITS_PARSER_READY = True



def fixture(directory):
    files = {}; extents = []
    for line in (directory / 'weights.tsv').read_text(encoding='utf-8-sig').splitlines()[3:]:
        fields = shlex.split(line)
        if not fields: continue
        rank = int(fields[2]); path = Path(fields[3 + rank]).resolve()
        start, length = map(int, fields[4 + rank:6 + rank]); st = path.stat()
        assert start >= 0 and length >= 0 and start + length <= st.st_size
        files[t.key(path)] = dict(path=str(path), bytes=st.st_size,
                                 mtime_ns=st.st_mtime_ns, file_id=st.st_ino)
        extents.append(dict(path=str(path), start=start, length=length))
    assert files
    return dict(directory=str(directory), manifest=t.pin(directory / 'weights.tsv'),
                prompt=t.pin(directory / 'prompt.ids'), local_weight_sources=list(files.values()),
                referenced_extents=extents)


def closure(paths):
    found = {t.key(Path(path).resolve()): str(Path(path).resolve()) for path in paths}
    todo = list(found.values())
    while todo:
        current = Path(todo.pop())
        for inc in re.findall(r'^\s*#\s*include\s*"([^\"]+)"', current.read_text(encoding='utf-8-sig'), re.M):
            path = next((q.resolve() for root in (current.parent, R / 'include', R)
                         if (q := root / inc).is_file()), None)
            if path is not None and t.project(path) and t.key(path) not in found:
                found[t.key(path)] = str(path); todo.append(str(path))
    return sorted(found.values(), key=t.key)


def sdk_engine_dependencies(retained):
    inspected = []; unavailable = []; matches = []
    for row in retained:
        if not row['path'].lower().endswith('.obj'): continue
        metadata = t.retained_metadata(row)
        if metadata is None:
            unavailable.append(row['path']); continue
        inspected.append(dict(object=row['path'], dependencies=metadata['dependencies']))
        headers = [path for path in [metadata['source'], *metadata['includes']]
                   if Path(path).is_relative_to(R / 'engine')]
        if headers:
            directory = Path(row['path']).parent; compiled = directory / 'compiled.json'
            receipt = directory / 'actual-dependencies.json'
            if compiled.is_file() and 'freeze' in (record := t.read(compiled)):
                original = record['freeze']; t.exact(original); receipt = Path(original['path'])
                pins = t.read(receipt)['dependencies']
            else:
                assert receipt.is_file(), ('engine object lacks source identities', row['path'])
                pins = t.read(receipt)
            by_path = {t.key(pin['path']): pin for pin in pins}
            assert all(t.key(path) in by_path for path in headers)
            identities = [by_path[t.key(path)] for path in headers]
            for identity in identities: t.exact(identity)
            matches.append(dict(object=row['path'], engine_dependencies=headers,
                                source_identities=identities, original_receipt=t.pin(receipt)))
    return dict(scope='Existing adjacent MSVC dependency receipts only; unavailable records are explicit.',
                inspected=inspected, unavailable=unavailable, engine_consumers=matches)


def prepare():
    base = t.read(BASE); previous_path = Path(base['previous_consumer']['path'])
    previous = t.read(previous_path)
    assert len(base['retained']) == 227
    t.exact(previous['object'])  # Previous consumer OBJ retained; its deleted EXE is not required.
    retained_keys = {t.key(row['path']) for row in base['retained']}
    assert len(retained_keys) == 227
    for row in base['retained']: t.exact(row)
    old = [arg for arg in base['link'] if arg.lower().endswith('.obj') and t.key(arg) not in retained_keys]
    assert len(old) == 1
    source = b.SOURCES['tiny']; compile_args = []
    for index, arg in enumerate(base['compile']):
        if index and base['compile'][index - 1].lower() == '/sourcedependencies':
            arg = str(W / 'compile/tiny/dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / 'compile/tiny/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / 'compile/tiny/unit.pdb')
        compile_args.append(arg)
    if not any(arg.lower().startswith('/fd') for arg in compile_args):
        compile_args.append('/Fd' + str(W / 'compile/tiny/unit.pdb'))
    assert sum(t.key(arg) == t.key(source) for arg in compile_args) == 1
    link_args = []
    for arg in base['link']:
        if t.key(arg) == t.key(old[0]): arg = str(W / 'compile/tiny/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/tiny').with_suffix(suffix)); break
        link_args.append(arg)
    assert sum(t.key(arg) == t.key(W / 'compile/tiny/unit.obj') for arg in link_args) == 1
    assert all(sum(t.key(arg) == key for arg in link_args) == 1 for key in retained_keys)
    sources = closure([str(t.canonical(row['path'])) for row in previous['project_dependencies']] + [str(source)])
    assert t.key(R / 'tests/tools/qwen_conditional_logits_case.h') in map(t.key, sources)
    assert t.key(R / 'engine/inference/sampling_graph.h') in map(t.key, sources)
    assert t.key(R / 'engine/inference/logits_inputs.h') in map(t.key, sources)
    assert t.key(R / 'tests/tools/qwen_conditional_verify_case.h') in map(t.key, sources)
    assert t.key(R / 'tests/tools/qwen_natural_logits_case.h') in map(t.key, sources)
    sdk_headers = sdk_engine_dependencies(base['retained'])
    t.save(W / 'sdk-engine-dependencies.json', sdk_headers)
    env = t.read(OLD / 'attempt2/environment.json')
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    t.save(W / 'environment.json', env)  # Local only; never print/archive environment values.
    t.save(W / 'plan.json', dict(base=t.pin(BASE), previous_consumer=t.pin(previous_path),
        units={'tiny': dict(source=str(source), compile=compile_args, link=link_args)},
        retained=base['retained'], runtime=base['runtime'], sources=sources,
        fixtures=dict(conditional=fixture(b.PLAIN), natural=fixture(b.NATURAL)),
        sdk_engine_dependencies=t.pin(W / 'sdk-engine-dependencies.json'),
        helpers=[t.pin(__file__), t.pin(NATURAL_HELPER),
                 t.pin(R / '.scratch/inference-indexed-store-20261028/build.py')],
        cases=b.CASES, verify_parser_ready=VERIFY_PARSER_READY, natural_logits_parser_ready=NATURAL_LOGITS_PARSER_READY, counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0,
            inputs_per_link=228, retained_inputs=227, maximum_native_cases=5, downloads=0),
        policy='Explicit actions only: no retry, implicit build/run, SDK copy, download or cleanup. '
               'Only existing local manifest SHA and weight file identity/size/mtime/extents are checked.'))
    print('PREPARED one consumer CXX/link; 227 retained SDK inputs, no native execution')


def validate():
    plan = t.read(W / 'plan.json')
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    for row in [plan['base'], plan['previous_consumer'], plan['sdk_engine_dependencies'], *plan['helpers']]: t.exact(row)
    for consumer in t.read(plan['sdk_engine_dependencies']['path'])['engine_consumers']:
        t.exact(consumer['original_receipt'])
        for identity in consumer['source_identities']: t.exact(identity)
    for entry in plan['fixtures'].values():
        t.exact(entry['manifest']); t.exact(entry['prompt'])
        for row in entry['local_weight_sources']:
            st = Path(row['path']).stat()
            assert (st.st_size, st.st_mtime_ns, st.st_ino) == (row['bytes'], row['mtime_ns'], row['file_id'])
    return plan


b.validate = validate


def check_states(rows):
    assert rows
    for row in rows:
        assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
        assert row['payloads_byte_equal'] == (not row['differences'])
        for diff in row['differences']:
            assert diff['role'] == 3 and diff['nonfinite_differences'] == 0 and 0 <= diff['maximum_absolute'] <= 3e-6


def parse_verify(report, backend):
    assert VERIFY_PARSER_READY
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['case'] == 'conditional-verify' and report['models'] == 1
    assert report['synthetic_untrained'] is True
    assert report['quality_claim'] is False and report['performance_claim'] is False
    assert report['natural_conditional_supplier'] is False and report['final_versions'] == 0
    assert report['conditional_rows'] == 3 and report['target_submissions'] == 4
    assert report['actual_target_F32_oracles'] == 2 and report['actual_private_q_rows'] == 2
    assert report['numeric_failure_participant'] == 0 and report['RNG_reserved_draws'] == 5
    assert type(report['accepted_target_rows']) is int and 1 <= report['accepted_target_rows'] <= 3
    for field in ('host_owner_move_prefix', 'same_q_retry', 'metadata_and_role_key_zero_target',
                  'numeric_failure_retired', 'immutable_owner_survives_caller',
                  'old_checkpoints_unchanged', 'complete_target_draft_state'):
        assert report[field] is True, field
    assert len(report['state_checks']) == 1
    check_states(report['state_checks'])
    state = report['state_checks'][0]
    assert state['prefix'] == 3 and state['active_rows'] == 3 and state['physical_rows'] == 3


def parse_natural_logits(report, backend):
    assert NATURAL_LOGITS_PARSER_READY
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['case'] == 'natural-logits' and report['models'] == 3
    assert report['synthetic_untrained'] is True
    assert report['quality_claim'] is False and report['performance_claim'] is False
    assert report['final_versions'] == 0
    for field in ('natural_RequestLoop', 'provider_future_excludes_pending', 'current_turn_outputs',
                  'p_rows_reuse_q_inputs', 'StateOnly_zero_calls', 'dynamic_K1_Verify',
                  'cache_current_payload', 'stochastic_K2', 'independent_request_RNG',
                  'late_provider_retired', 'same_key_retry', 'old_checkpoint_unchanged'):
        assert report[field] is True, field
    journeys = report['journeys']
    assert len(journeys) == 3 and [row['maximum_drafts'] for row in journeys] == [1, 2, 0]
    for journey in journeys:
        drafts = journey['maximum_drafts']; native = journey['natural_report']
        assert isinstance(native, dict), 'The captured natural report must be nested JSON, not an opaque string.'
        assert native['mtp'] is (drafts != 0) and native['score_dtype'] == 'F32'
        assert native['live_committed_versions'] == 0 and native['active_sequences'] == 1
        assert native['decode_overlap'] is False
        assert native['admitted_requests'] == native['retired_requests'] == native['session_count']
        assert native['admitted_turns'] == native['turn_count']
        assert journey['StateOnly_commits'] > 0
        if drafts:
            assert journey['provider_calls'] > 0 and journey['Verify_commits'] > 0
            assert journey['turn_row0_calls'] == 4
            assert native['session_count'] == 2 and native['turn_count'] == 4
            assert native['prefix_cache'] is False and native['generated_tokens'] == 14
            assert len(native['sessions']) == 2
            ledgers = []
            for index, session in enumerate(native['sessions']):
                assert session['session_id'] == ('natural-a' if index == 0 else 'natural-b')
                assert session['result']['generated_ids'] == [8, 9, 10, 11, 8, 9, 10]
                ledger = session['ledger']; assert ledger
                ledgers.append(ledger); next_draw = 0
                for ordinal, record in enumerate(ledger):
                    assert record['index'] == ordinal and record['requests'] == 1 and record['member_index'] == 0
                    assert record['imported'] is False
                    if drafts == 2:
                        assert record['sampling_seed'] == 123 and record['sampling_stream'] == index
                        assert record['sampling_draw_before'] == next_draw
                        delta = 0 if record['next_id'] < 0 else 2 * (record['verified_rows'] - 1) + 1 if record['role'] == 1 else 1
                        next_draw += delta
                        assert record['sampling_draw_after'] == next_draw
                    else:
                        assert record['sampling_seed'] == record['sampling_stream'] == 0
                        assert record['sampling_draw_before'] == record['sampling_draw_after'] == 0
                    if record['generation'] and record['draft_limit']:
                        assert record['role'] == 1 and record['verified_rows'] >= 2
                assert next_draw > 0 if drafts == 2 else next_draw == 0
            assert len(ledgers[0]) == len(ledgers[1]) == len(journey['state_checks'])
            check_states(journey['state_checks'])
            for record, state in zip(ledgers[1], journey['state_checks']):
                assert state['prefix'] == record['before_length']
                assert state['active_rows'] > 0 and state['physical_rows'] >= state['active_rows']
                assert state['prefill'] is (not record['generation'])
            expected_late = 2 if drafts == 2 else 0
            assert journey['late_private_draft_calls'] == expected_late
            assert journey['late_probability_leases'] == expected_late
        else:
            assert journey['provider_calls'] == 3 and journey['Verify_commits'] == journey['turn_row0_calls'] == 0
            assert journey['late_private_draft_calls'] == journey['late_probability_leases'] == 0
            assert journey['state_checks'] == []
            assert native['prefix_cache'] is True and native['prefix_full_hits'] == 1
            assert native['session_count'] == native['turn_count'] == native['generated_tokens'] == 3
            assert [row['session_id'] for row in native['sessions']] == ['cache-a', 'cache-b', 'cache-new']
            assert [row['result']['generated_ids'] for row in native['sessions']] == [[8], [12], [16]]


def parse(name):
    validate()
    if name == 'natural-cuda': b.parse(name); return
    assert name in ('logits-cpu', 'logits-cuda', 'verify-cpu', 'verify-cuda')
    _, backend, _ = b.CASES[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports) == 1; report = reports[0]
    assert report['status'] == 'PASS' and report['backend'] == backend
    assert report['models'] == (3 if name.startswith('logits-') else 1)
    assert report['synthetic_untrained'] is True and report['quality_claim'] is False
    assert report['performance_claim'] is False and report['final_versions'] == 0
    if name.startswith('verify-'):
        parse_verify(report, backend)
    else:
        parse_natural_logits(report, backend)
    t.save(out / 'report.json', report)
    print('PASS', name, 'PID', process['pid'])


def run(name):
    if name.startswith('logits-'):
        assert NATURAL_LOGITS_PARSER_READY, 'Finalize natural logits parser before starting its consumer.'
    if name.startswith('verify-'):
        assert VERIFY_PARSER_READY, 'Finalize Verify parser before any new consumer process.'
    plan = validate(); _, backend, flag = b.CASES[name]
    entry = plan['fixtures']['natural' if name == 'natural-cuda' else 'conditional']
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image'])
    argv = [ready['image']['path'], '--' + backend, entry['directory'], flag]
    t.execute(argv, W / 'runs' / name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action in ('freeze', 'validate'): getattr(b, action)()
    elif action in ('compile', 'parse_compile', 'link'):
        assert len(sys.argv) == 3 and sys.argv[2] == 'tiny'; getattr(b, action)('tiny')
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
