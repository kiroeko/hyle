"""Two matching engine TUs; reuse actual Vulkan product closure; two tiny CLI runs."""
from pathlib import Path
import importlib.util
import json
import os
import shlex
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
I = R / '.scratch/inference-vulkan-halfword-io-20261027'
spec = importlib.util.spec_from_file_location('halfword_io_recipe', I / 'build.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
b, m = prior.b, prior.m
EXPECTED = {
    'engine/models/qwen35/main.cc': '3d85397362f767f7c9516faf1927086d1bf087afeb0ff856783dc8cab048a67d',
    'engine/inference/prefill_plan.h': 'fb5f0afd618ed4af6dae02ae48d11b0de2fe9dcebb68392e9286823892e2f707',
    'engine/models/qwen35/weights.cc': '0eb25dbcd62439fb1a1e849278c3950e99ec32d7bdba3c9d4566b8bfee086d96',
}


def key(path):
    return b.key(str(path))


def plan():
    assert not (W / 'plan.json').exists()
    for relative, expected in EXPECTED.items():
        assert b.pin(R / relative)['sha256'] == expected
    baseline = b.read(I / 'ready.json')
    inputs = b.read(baseline['inputs']['path'])
    assert len(inputs) == 146
    for row in inputs:
        b.exact(row)
    remove = {
        key(I / 'compile/test/unit.obj'),
        key(R / '.scratch/build-compute-v2-dev/lib/gtest_main.lib'),
        key(R / '.scratch/build-compute-v2-dev/lib/gtest.lib'),
    }
    old_cpu = {
        'default_rules': R / '.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_provider_native--default_rules.obj',
        'indexing': R / '.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_provider_native--indexing.obj',
        'native_provider': R / '.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/compute_provider_native--native_provider.obj',
    }
    replacements = {}
    cpu_records = []
    cpu_root = R / '.scratch/inference-cpu-storage-gather-20261027'
    cpu_ready = b.read(cpu_root / 'ready.json')
    for name, old in old_cpu.items():
        unit = next(x for x in cpu_ready['compiled'] if x['name'] == name)
        b.exact(unit['source'])
        b.exact(unit['object'])
        deps = b.read(unit['actual_dependencies']['path'])
        # These actual project headers are all identical to the tested CPU objects.
        for row in deps:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                b.exact(row)
        replacements[key(old)] = unit['object']
        cpu_records.append(unit)
    for path in remove | set(replacements):
        assert sum(key(row['path']) == path for row in inputs) == 1
    retained = [replacements.get(key(row['path']), row) for row in inputs if key(row['path']) not in remove]
    assert len(retained) == 143
    b.save(W / 'retained-inputs.json', retained)
    units = []
    host_recipe = R / '.scratch/inference-paged-frame-20261026/engine/compile/cpu-vulkan/command.json'
    weight_recipe = R / '.scratch/inference-stream-padding-20261026/compile/weights/command.json'
    for name, relative, template in [
        ('model', 'engine/models/qwen35/main.cc', host_recipe),
        ('weights', 'engine/models/qwen35/weights.cc', weight_recipe),
    ]:
        command = m.command(template, R / relative, W / 'compile' / name)
        assert '/DHYLE_COMPUTE_CPU=1' in command and '/DHYLE_COMPUTE_VULKAN=1' in command
        assert not any('HYLE_COMPUTE_CUDA' in x or 'GGML_USE_CUDA' in x for x in command)
        recipe = W / 'recipes' / (name + '.json')
        b.save(recipe, dict(command=command, cwd=str(R), timeout_seconds=180))
        units.append(dict(name=name, source=b.pin(R / relative), recipe=b.pin(recipe)))
    frozen = m.c.closure([u['source']['path'] for u in units], [u['recipe']['path'] for u in units])
    b.save(W / 'source-freeze.json', frozen)
    for relative in [*EXPECTED, 'engine/models/qwen35/session_state.h', 'engine/inference/backend.h']:
        dst = W / 'source' / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes((R / relative).read_bytes())
    entry_dir = R / '.scratch/inference-current-closure-20261026/engine/entry'
    entry = b.pin(entry_dir / 'unit.obj')
    for row in b.read(entry_dir / 'actual-dependencies.json'):
        path = Path(row['path'])
        if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
            b.exact(row)
    fixture = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    assert (fixture / 'prompt.ids').read_text().split() == ['1', '2', '3']
    spans = []
    manifest_lines = (fixture / 'weights.tsv').read_text(encoding='utf-8-sig').splitlines()
    assert manifest_lines[0] == 'HYLE_QWEN_ROLE_FILES_V2'
    assert manifest_lines[2].startswith('geometry ')
    for line in manifest_lines[3:]:
        if not line or line.startswith('#'):
            continue
        fields = shlex.split(line)
        role, dtype, rank = fields[0], fields[1], int(fields[2])
        payload, offset, size = Path(fields[3 + rank]), int(fields[4 + rank]), int(fields[5 + rank])
        assert dtype == 'BF16' and payload.is_file() and offset >= 0 and size > 0 and offset + size <= payload.stat().st_size
        spans.append(dict(role=role, type=dtype, shape=[int(x) for x in fields[3:3+rank]], path=str(payload), offset=offset, bytes=size))
    assert len(spans) == 42 and len(set(x['path'] for x in spans)) == 1
    b.save(W / 'fixture.json', dict(manifest=b.pin(fixture / 'weights.tsv'), geometry=manifest_lines[2], prompt=b.pin(fixture / 'prompt.ids'), payload=b.pin(spans[0]['path']), roles=spans,
        purpose='Untrained recursive+attention tiny fixture; no task-quality claim or full-model claim.'))
    b.save(W / 'plan.json', dict(status='PREPARED_NOT_BUILT_OR_RUN', baseline=b.pin(I / 'ready.json'),
        baseline_inputs=baseline['inputs'], removed_inputs=sorted(remove), replaced_CPU_objects=cpu_records,
        retained_inputs=b.pin(W / 'retained-inputs.json'), entry=entry, units=units,
        source_freeze=b.pin(W / 'source-freeze.json'), fixture=b.pin(W / 'fixture.json'),
        legacy_weights_replaced=str(R / '.scratch/inference-stream-padding-20261026/compile/weights/unit.obj'),
        private_ABI='CPU native 3 objects actual canonical project source/header hashes match current. Recompile matching CPU+Vulkan weights because Backend conditional variant and session_state changed. Reuse entry only after all actual two project dependencies match. Vulkan private Pipeline/DescriptorBinding and original Run ABI/constructors retain the already-verified raw16+halfword-IO closure; no new private struct edit in this batch. Model and weights both see current prefill_plan/session_state/backend/public headers; do not reuse CUDA Model/weights.',
        compiler=units[0]['recipe'], expected=EXPECTED, CXX_TUs=2, links=1, final_input_count=145,
        planned_runs=['ordinary', 'mtp-k3'], shader_builds=0, SDK_builds=0, NVCC=0, downloads=0, benchmark=False))
    print('PLAN', json.dumps(b.pin(W / 'plan.json')), flush=True)


def build():
    p = b.read(W / 'plan.json')
    assert not (W / 'compile').exists() and not (W / 'ready.json').exists()
    frozen = b.read(p['source_freeze']['path'])
    for row in frozen:
        b.exact(row)
    known = {key(row['path']): row for row in frozen}
    h, env = prior.old.old.env()
    compiled = []
    for unit in p['units']:
        out = W / 'compile' / unit['name']
        result = h.execute(b.read(unit['recipe']['path'])['command'], env, out, timeout=180)
        actual = b.read(out / 'dependencies.json')['Data']
        deps = [b.pin(path) for path in dict.fromkeys([actual['Source'], *actual['Includes']])]
        b.save(out / 'actual-dependencies.json', deps)
        for row in deps:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R / '.scratch'):
                assert known[key(path)]['sha256'] == row['sha256'], str(path)
        compiled.append(dict(unit=unit, object=b.pin(out / 'unit.obj'), process=result, dependencies=b.pin(out / 'actual-dependencies.json')))
        b.save(W / 'partial-build.json', compiled)
        for row in frozen:
            b.exact(row)
    objects = {x['unit']['name']: x['object'] for x in compiled}
    base_args = b.read(I / 'link/command.json')['command']
    retained = b.read(p['retained_inputs']['path'])
    old = b.read(p['baseline_inputs']['path'])
    new_cpu = {}
    for name in ('default_rules', 'indexing', 'native_provider'):
        old_row = next(x for x in old if x['path'].endswith('compute_provider_native--' + name + '.obj'))
        new_row = next(x for x in p['replaced_CPU_objects'] if x['name'] == name)
        new_cpu[key(old_row['path'])] = new_row['object']
    image = W / 'bin/hyle.exe'
    image.parent.mkdir(parents=True, exist_ok=True)
    args = []
    for arg in base_args:
        if key(arg) in set(p['removed_inputs']):
            continue
        if key(arg) in new_cpu:
            arg = new_cpu[key(arg)]['path']
        elif key(arg) == key(p['legacy_weights_replaced']):
            arg = objects['weights']['path']
        elif arg.upper().startswith('/OUT:'):
            arg = '/OUT:' + str(image)
        elif arg.upper().startswith('/PDB:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        args.append(arg)
    args.extend([objects['model']['path'], p['entry']['path']])
    inputs = [objects['weights'] if key(x['path']) == key(p['legacy_weights_replaced']) else x for x in retained]
    inputs.extend([objects['model'], p['entry']])
    assert len(inputs) == 145 and len(set(key(x['path']) for x in inputs)) == 145
    for row in inputs:
        b.exact(row)
        assert sum(key(arg) == key(row['path']) for arg in args) == 1, row['path']
    linked = h.execute(args, env, W / 'link', timeout=120)
    b.save(W / 'link-inputs.json', inputs)
    runtime = b.read(I / 'runtime.json')
    b.exact(runtime['native'])
    alias = image.parent / Path(runtime['native']['path']).name
    os.link(runtime['native']['path'], alias)
    runtime['native_hardlink'] = b.pin(alias)
    runtime['PATH'] = str(image.parent) + ';' + runtime['PATH']
    b.save(W / 'runtime.json', runtime)
    b.save(W / 'ready.json', dict(status='BUILT_NOT_RUN', compiled=compiled, link=linked, image=b.pin(image),
        inputs=b.pin(W / 'link-inputs.json'), runtime=b.pin(W / 'runtime.json'), plan=b.pin(W / 'plan.json')))
    print('READY', json.dumps(b.pin(W / 'ready.json')), flush=True)


def run():
    ready = b.read(W / 'ready.json')
    assert not (W / 'runs').exists()
    b.exact(ready['image'])
    h, env = prior.old.old.env()
    env['PATH'] = b.read(ready['runtime']['path'])['PATH']
    old_command = b.read(R / '.scratch/inference-engine-slot-state-20261027/runs/ordinary3/command.json')['command']
    records = []
    for name in ['ordinary', 'mtp-k3']:
        args = list(old_command)
        args[0] = ready['image']['path']
        args[args.index('--backend') + 1] = 'vulkan'
        if name == 'mtp-k3':
            args[args.index('--mtp') + 1] = 'on'
            args.extend(['--mtp-max-drafts', '3'])
        out = W / 'runs' / name
        result = h.execute(args, env, out, timeout=90)
        lines = (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines()
        reports = [json.loads(line) for line in lines if line.startswith('{')]
        assert len(reports) == 1
        report = reports[0]
        assert report['backend'] == 'vulkan' and report['generated_tokens'] == 8
        assert report['live_committed_versions'] == 0 and report['retired_requests'] == 1
        assert report['cpu_ffn_layers'] == 0 and report['original_host_weight_bytes'] == 0
        assert report['mtp'] == (name == 'mtp-k3')
        if name == 'mtp-k3':
            assert report['mtp_max_drafts'] == 3 and report['draft_program_graph_calls'] > 0
        sessions = report['sessions']
        assert len(sessions) == 1
        generated = sessions[0]['result']['generated_ids']
        assert len(generated) == 8 and all(isinstance(x, int) and 0 <= x < 64 for x in generated)
        records.append(dict(name=name, process=result, report=report, generated_ids=generated))
        b.save(W / 'partial-run.json', records)
    b.save(W / 'summary.json', dict(status='ORDINARY_AND_MTP_K3_VULKAN_CLI_PASS', ready=b.pin(W / 'ready.json'),
        runs=records, actual_processes=2, quality_claim=False, performance_claim=False,
        scope='Current provider-independent indexed state Graphs execute through ordinary Vulkan Gather/math/external Store fallback; no CUDA indexed fusion claim, no complete model or cross-width bit identity claim.'))
    print('PASS', json.dumps(b.pin(W / 'summary.json')), flush=True)


if __name__ == '__main__':
    try:
        {'plan': plan, 'build': build, 'run': run}[sys.argv[1]]()
    except Exception:
        b.save(W / (sys.argv[1] + '-failure.json'), dict(error=traceback.format_exc()))
        raise
