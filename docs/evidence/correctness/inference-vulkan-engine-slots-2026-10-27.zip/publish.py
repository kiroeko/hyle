"""Archive two actual Vulkan tiny CLI runs, without new execution or binaries."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


plan = read(W / 'plan.json')
ready = read(W / 'ready.json')
summary = read(W / 'summary.json')
assert summary['status'] == 'ORDINARY_AND_MTP_K3_VULKAN_CLI_PASS'
assert len(summary['runs']) == 2
assert pin(ready['image']['path']) == ready['image']
assert pin(W / 'ready.json') == summary['ready']
for relative, expected in plan['expected'].items():
    assert pin(R / relative)['sha256'] == expected
    assert pin(W / 'source' / relative)['sha256'] == expected
for unit in ready['compiled']:
    assert unit['process']['exit'] == 0
    assert pin(unit['object']['path']) == unit['object']
    assert pin(unit['dependencies']['path']) == unit['dependencies']
assert ready['link']['exit'] == 0
inputs = read(W / 'link-inputs.json')
assert len(inputs) == 145
for row in inputs:
    assert pin(row['path']) == row
observations = []
for run in summary['runs']:
    raw = (W / 'runs' / run['name'] / 'stdout.log').read_text(encoding='utf-8-sig')
    reports = [json.loads(line) for line in raw.splitlines() if line.startswith('{')]
    assert reports == [run['report']] and run['process']['exit'] == 0
    report = run['report']
    assert report['backend'] == 'vulkan' and report['generated_tokens'] == 8
    assert report['retired_requests'] == 1 and report['live_committed_versions'] == 0
    assert report['cpu_ffn_layers'] == 0 and report['original_host_weight_bytes'] == 0
    session = report['sessions'][0]['result']
    observations.append(dict(name=run['name'], process=run['process'],
        generated_ids=run['generated_ids'], mtp=report['mtp'],
        actual_graph_calls=report['actual_graph_calls'], draft_program_graph_calls=report['draft_program_graph_calls'],
        verified_target_rows=report['verified_target_rows'], mtp_max_drafts=report['mtp_max_drafts'],
        retired_requests=report['retired_requests'], live_committed_versions=report['live_committed_versions'],
        draft_rounds=session.get('draft_rounds'), consumed_drafts=session.get('consumed_drafts'),
        original_host_weight_bytes=report['original_host_weight_bytes']))
assert observations[1]['mtp_max_drafts'] == 3 and observations[1]['draft_program_graph_calls'] == 21
assert observations[1]['consumed_drafts'] == 0
assert summary['runs'][0]['generated_ids'] == summary['runs'][1]['generated_ids']
fixture = read(W / 'fixture.json')
for name in ('manifest', 'prompt', 'payload'):
    assert pin(fixture[name]['path']) == fixture[name]
members = {}
for path in W.rglob('*'):
    if path.is_file() and path.suffix.lower() in {'.py', '.json', '.log', '.cc', '.h'}:
        members[path.relative_to(W).as_posix()] = path.read_bytes()
members['fixture/weights.tsv'] = Path(fixture['manifest']['path']).read_bytes()
members['fixture/prompt.ids'] = Path(fixture['prompt']['path']).read_bytes()
cpu_proofs = []
for unit in plan['replaced_CPU_objects']:
    path = Path(unit['actual_dependencies']['path'])
    members['cpu-object-proof/' + unit['name'] + '-actual-dependencies.json'] = path.read_bytes()
    actual = read(path)
    count = 0
    for row in actual:
        dep = Path(row['path'])
        if dep.is_relative_to(R) and not dep.is_relative_to(R / '.scratch'):
            assert pin(dep)['sha256'] == row['sha256']
            count += 1
    cpu_proofs.append(dict(name=unit['name'], source=unit['source'], object=unit['object'],
        actual_project_dependencies_identical_to_current=count,
        actual_dependencies=unit['actual_dependencies']))

receipt = dict(
    schema=1, date='2026-10-27', title='Provider-independent indexed state Vulkan tiny CLI',
    status='FINITE_ORDINARY_AND_MTP_K3_CLI_PASS',
    source_head_context='97cab7aac552ee9e0adfa158467f42524f135988',
    source_scope='No product modification in this validation batch. The current engine uses one provider-independent slot-state Graph; Vulkan executes ordinary selected-row Gather/math/external Store through its original native source and real retirement path. No engine backend-specific graph or duplicated executor was introduced.',
    sources=[pin(R / relative) for relative in plan['expected']],
    cold_build=dict(
        CXX_processes=2, distinct_CXX_TUs=2, links=1,
        compiled=ready['compiled'], link=ready['link'], image=ready['image'],
        linked_input_count=145, linked_inputs=ready['inputs'],
        baseline=plan['baseline'], replaced_CPU_objects=cpu_proofs,
        reuse='Original latest Vulkan halfword-I/O closure of 146 inputs, removing its one test TU and two GTest libraries. Replace three stale native CPU objects with the actual tested storage-Gather objects, replace old matching weights with a fresh CPU+Vulkan weights TU, then add current standalone Model and original unchanged entry TU: 145 inputs. No SDK/native frontend/shader/NVCC operation. Original cached reporting object remains; this batch does not change reporting observation layout.',
        private_ABI=plan['private_ABI'],
        source_freeze=plan['source_freeze'],
        shader_builds=0, SDK_builds=0, NVCC=0, downloads=0,
    ),
    fixture=dict(
        manifest=fixture['manifest'], prompt=fixture['prompt'], payload=fixture['payload'],
        geometry=fixture['geometry'], roles=42,
        bounds='All 42 role offset/byte ranges checked against the existing single 298628-byte BF16 file. Two target layers GA include GDN/causal-conv and dense attention, with MTP role weights. Only 3 prompt IDs; C16/N4/R1, greedy, Commands, prefix-cache off, steps8. Payload is not archived or downloaded.',
    ),
    execution=dict(
        actual_processes=2, observations=observations,
        results='Both exited zero once, each generated 8 legal vocabulary IDs; IDs equal for this synthetic fixture. Actual backend Vulkan, no CPU FFN or host weight placement, one retired request and zero live committed versions at exit.',
        acceptance_boundary='MTP K3 made 6 draft rounds, 21 draft graph calls and verified 22 target rows, but consumed_drafts is zero for these untrained weights. This exercises candidate generation/verification/rejection/repair and final resource cleanup; it does not prove positive accepted prefixes longer than one on Vulkan.',
        quality_claim=False, performance_claim=False,
    ),
    failures_preserved=dict(
        preparation=pin(W / 'preparation-failures.json'),
        explanation='Two pre-compilation recipe errors: old cached receipt filename ready2.json instead of ready.json, then tensor parser failed to skip the real three-line manifest header. Both corrected without CXX/product/GPU execution. First original plan-failure.json was overwritten by the second; exact causes and that limitation are recorded. The second traceback remains. Actual 2 CXX, link and 2 native CLI processes have no failures or retries.',
    ),
    verified=[
        'Current main/prefill-plan and matching CPU+Vulkan Backend/session-state code compile together, link against the exact native Vulkan raw16 Gather, Store and halfword-I/O objects, then execute complete ordinary/MTP tiny request loops.',
        'The same provider-independent history/recurrent state Graph executes on Vulkan; no CUDA-only kernel or special engine model branch is needed.',
        'K3 candidates and rejection/repair continuation finish with zero live committed versions. Actual generated IDs are retained in raw report and receipt.',
    ],
    limits=[
        'Synthetic untrained hidden64 two-layer fixture, not complete Qwen3.5-2B weights, task quality or performance. CLI-reported wall/throughput fields are diagnostic only; this is not a benchmark.',
        'No positive multi-token draft acceptance in these weights; no randomized sampling, B2 multi-request, capture, failure injection, new host-image/lag1 suite or exhaustive shape/device matrix in this batch.',
        'Earlier raw16 Gather/Store/I/O tests remain their original independent evidence and were not rerun. The fixture rows are word-sized overall; exact two-byte partial I/O is proven separately by the halfword-I/O receipt, not newly by this CLI.',
    ],
    members=[dict(name=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(members.items())],
)
manifest = (json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
members['manifest.json'] = manifest
dest = R / 'docs/evidence/correctness'
stem = 'inference-vulkan-engine-slots-2026-10-27'
archive = dest / (stem + '.zip')
public = dest / (stem + '.json')
assert not archive.exists() and not public.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(members.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(members) and z.testzip() is None
    for name, data in members.items():
        actual = z.read(name)
        assert len(actual) == len(data) and sha(actual) == sha(data) and actual == data
receipt['archive'] = pin(archive)
receipt['archive_manifest_sha256'] = sha(manifest)
receipt['integrity'] = 'All ZIP members reopened and compared byte-for-byte and SHA256; CRC passed. Current source snapshots, native image, actual objects, dependency proofs and complete stdout reports checked before publication. No OBJ/EXE/DLL/SDK/model payload included.'
public.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
published = dict(receipt=pin(public), archive=pin(archive), members=len(members))
(W / 'published.json').write_text(json.dumps(published, indent=2) + '\n', encoding='utf-8')
print(json.dumps(published, indent=2))
