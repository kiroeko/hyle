"""After Qwen: compile two current CUDA host owners and publish one current image.

Only root executes compile/link. plan is offline. The two ordered patches must
already be applied, and the actual successful Flash compile2 is retained. No
SDK/NVCC, old-source equivalence claim, model download or new executor.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
R = S.parents[2]
CONSUMER = R / '.scratch/glm-gguf-selected-20261023/flash-consumer-proposal/compile2/flash-state/identity.json'
TAG_SOURCE = {'provider': 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
              'tensor-program': 'src/compute_provider_ggml_cuda/tensor_program.cc'}
OLD = R / '.scratch/glm-gguf-selected-20261023/B10/native-integration/build.py'
spec = importlib.util.spec_from_file_location('_packed_head_current_base', OLD)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
read, save, identity, require, resolve = base.read, base.save, base.identity, base.require, base.resolve


def expected_sources(after):
    previous = {row['path']: row for row in read(P / 'proposal/source-facts.json')}
    for row in read(P / 'orin-proposal/source-facts.json'):
        name = row['path']
        expected = row['after'] if after else (
            {'bytes': previous[name]['before_bytes'], 'sha256': previous[name]['before_sha256']}
            if name in previous else row['before'])
        actual = identity(R / name)
        if any(actual[key] != expected[key] for key in ('bytes', 'sha256')):
            raise ValueError(('Final after' if after else 'Original before') + ' source differs: ' + name)


def consumer():
    record = base.check_record(CONSUMER)
    process = read(CONSUMER.parent / 'compile.result.json')
    if process['exit'] != 0 or process['command'] != record['command']:
        raise ValueError('Flash compile2 must have an actual successful matching compile')
    if resolve(record['source']['path']) != R / 'tests/compute_models/glm_mtp_state_consumer_test.cc':
        raise ValueError('Expected the actual current Flash consumer')
    if any(arg.startswith(('/DHYLE_TEST_GLM_B12_', '/DHYLE_TEST_GLM_B13_')) for arg in record['command']):
        raise ValueError('Unexpected B12/B13 artifact macros in the retained Flash consumer')
    return record


def inputs():
    original, ready, runtime, old_consumer, records = base.closure()
    metadata = read(P / 'current-closure-metadata.json')
    old = {}
    for tag, source in TAG_SOURCE.items():
        matches = [row for row in metadata['tensor_program_header_consumers']
                   if resolve(row['source']) == R / source]
        if len(matches) != 1:
            raise ValueError('Expected one exact retired object for ' + tag)
        old[tag] = resolve(matches[0]['record'])
    if len(records) != 131:
        raise ValueError('Expected the actual131-host source closure')
    # Retired records are command/object provenance only. Their changed source
    # dependencies must not be labelled current after the ordered patches.
    for path in records:
        if resolve(path) not in set(old.values()):
            base.check_record(path)
    consumer()
    return original, ready, runtime, old_consumer, records, old


def plan(attempt):
    expected_sources(False)
    original, _, runtime, _, records, old = inputs()
    h = base.helpers()
    prepared = S / f'prepared{attempt}'
    prepared.mkdir(exist_ok=False)
    commands = []
    for tag, source in TAG_SOURCE.items():
        prior = read(old[tag])
        recipe = dict(command=prior['command'], source={'path': str(R / source)},
                      historical_recipe=identity(old[tag]), preparation_only=True)
        path = prepared / f'{tag}.json'
        save(path, recipe)
        commands.append(dict(tag=tag, source=str(R / source), recipe=identity(path),
            command=h.b.host_command(recipe['command'], R / source, tag, S / f'compile{attempt}' / tag)))
    save(S / f'commands{attempt}.json', dict(preparation_only=True, executed=False,
        trigger='Immediately after the current Q09/Q10 old-source runs finish: apply both ordered patches, compile two host owners, link current Flash compile2.',
        ordered_patches=[identity(P / 'proposal/source.patch'), identity(P / 'orin-proposal/source.patch')],
        final_sources=read(P / 'orin-proposal/source-facts.json'), compile=commands,
        retained_consumer=identity(CONSUMER), consumer_compile_process=identity(CONSUMER.parent / 'compile.result.json'),
        base_plan=identity(base.BASE / 'link-plan.json'), base_runtime=identity(runtime),
        retired_records=[identity(path) for path in old.values()],
        retained_host_records=[identity(path) for path in records if resolve(path) not in set(old.values())],
        root_commands=[[sys.executable, str(Path(__file__)), action, '--attempt', str(attempt)]
                       for action in ('compile', 'link')],
        SDK_builds=0, NVCC_builds=0, product_host_TUs=2, new_consumer_TUs=0,
        Orin_native_verified=False))
    print('PREPARED', S / f'commands{attempt}.json')


def compile_hosts(attempt):
    expected_sources(True)
    inputs()
    commands = read(S / f'commands{attempt}.json')
    require(commands['retained_consumer'])
    for row in commands['ordered_patches']:
        require(row)
    for row in commands['compile']:
        require(row['recipe'])
    h = base.helpers()
    h.S = S
    h.RECIPES = {tag: S / f'prepared{attempt}' / f'{tag}.json' for tag in TAG_SOURCE}
    h.SOURCES = {tag: R / source for tag, source in TAG_SOURCE.items()}
    for tag in TAG_SOURCE:
        h.compile_one(tag, attempt)
        base.check_record(S / f'compile{attempt}' / tag / 'identity.json')


def link(attempt):
    expected_sources(True)
    original, _, runtime_path, old_consumer, records, old = inputs()
    fresh_paths = {tag: S / f'compile{attempt}' / tag / 'identity.json' for tag in TAG_SOURCE}
    fresh = {tag: base.check_record(path) for tag, path in fresh_paths.items()}
    new_consumer = consumer()
    replacements = {str(resolve(read(old[tag])['object']['path'])).lower(): fresh[tag]['object']['path']
                    for tag in TAG_SOURCE}
    replacements[str(resolve(old_consumer['object']['path'])).lower()] = new_consumer['object']['path']
    counts = dict.fromkeys(replacements, 0)
    command = []
    for arg in original['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        key = str(resolve(arg)).lower() if arg.lower().endswith('.obj') else None
        if key in replacements:
            counts[key] += 1
            arg = replacements[key]
        command.append(arg)
    if set(counts.values()) != {1}:
        raise ValueError('Must replace exactly two provider objects and one Flash consumer')
    current_records = [path for path in records if resolve(path) not in set(old.values())] + list(fresh_paths.values())
    if len(current_records) != 131:
        raise ValueError('New host-record collection must have exactly131 actual records')
    objects = {str(resolve(arg)).lower() for arg in command if arg.lower().endswith('.obj')}
    known = {str(resolve(new_consumer['object']['path'])).lower()}
    for path in current_records:
        known.add(str(resolve(base.check_record(path)['object']['path'])).lower())
    for row in base.native_inputs():
        known.add(str(resolve(row['object']['path'])).lower())
    for row in original['retained_inputs']:
        require(row)
        known.add(str(resolve(row['path'])).lower())
    if not objects <= known or any(key in objects for key in replacements):
        raise ValueError('Unaccounted object or retired source object remains in current link')
    out = S / f'current-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'hyle-current-flash.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    save(out / 'host-records.json', dict(records=[identity(path) for path in current_records],
        count=131, current_source_dependencies_checked=True,
        retired=[identity(path) for path in old.values()], fresh=[identity(path) for path in fresh_paths.values()]))
    save(out / 'link-plan.json', dict(command=command, base=identity(base.BASE / 'link-plan.json'),
        consumer_record=identity(CONSUMER), host_records=identity(out / 'host-records.json'),
        retained_inputs=original['retained_inputs'], native_inputs=identity(base.S / 'native-inputs.json'),
        replaced_objects=list(replacements), current_host_count=131, pending_consumer=False,
        ordered_patches=read(S / f'commands{attempt}.json')['ordered_patches'],
        SDK_builds=0, NVCC_builds=0, rebuilt_product_host_TUs=2, new_consumer_TUs=0))
    h = base.helpers()
    env, _ = h.b.environment(command, [], out)
    h.c.execute('link', command, env, out)
    runtime = read(runtime_path)
    for dll in runtime['staged_dlls']:
        require(dll)
        source = resolve(dll['path'])
        os.link(source, out / source.name)
    runtime['PATH'] = str(out) + os.pathsep + runtime['PATH'].replace(str(base.BASE_IMAGE), str(out))
    runtime.update(previous=identity(runtime_path), staged_dlls=[identity(path) for path in out.glob('*.dll')],
                   host_translation_units=2, consumer_translation_units=0, full_SDK_builds=0, NVCC_builds=0)
    runtime['matched_HC_PRE_worker'] = runtime['staged_dlls'][0]
    save(out / 'runtime-environment.json', runtime)
    save(out / 'ready.json', dict(image=identity(image), link_plan=identity(out / 'link-plan.json'),
        runtime_environment=identity(out / 'runtime-environment.json'), host_records=identity(out / 'host-records.json'),
        consumer_record=identity(CONSUMER), link_result=identity(out / 'link.result.json'),
        native_result=False, Orin_native_verified=False))
    print('PUBLISHED CURRENT', out)


def closure(attempt=1):
    """Read the actual new image for the next single-consumer overlay."""
    out = S / f'current-link{attempt}'
    ready = read(out / 'ready.json')
    for key in ('image', 'link_plan', 'runtime_environment', 'host_records', 'consumer_record', 'link_result'):
        require(ready[key])
    if read(out / 'link.result.json')['exit'] != 0:
        raise ValueError('Current image link failed')
    plan = read(out / 'link-plan.json')
    require(plan['native_inputs'])
    base.native_inputs()
    for row in plan['retained_inputs']:
        require(row)
    for row in read(out / 'runtime-environment.json')['staged_dlls']:
        require(row)
    records = [resolve(row['path']) for row in read(out / 'host-records.json')['records']]
    for row in read(out / 'host-records.json')['records']:
        require(row)
        base.check_record(resolve(row['path']))
    current_consumer = base.check_record(resolve(ready['consumer_record']['path']))
    return plan, ready, out / 'runtime-environment.json', current_consumer, records


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'compile', 'link'))
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    if args.attempt <= 0:
        raise ValueError('Positive attempt required')
    {'plan': plan, 'compile': compile_hosts, 'link': link}[args.action](args.attempt)
