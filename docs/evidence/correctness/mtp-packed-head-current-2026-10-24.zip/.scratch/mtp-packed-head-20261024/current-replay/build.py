"""Replay the four existing head probes on the actual current two-owner closure.

Only links/runs when explicitly selected. Reuses the already compiled probe;
no compile, SDK, NVCC, model payload, HTTP or canonical-source edits.
"""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
P = S.parent
R = S.parents[2]
PROBE = P / 'focused/compile1/probe/identity.json'
EXPECTED = {
    'GgmlCudaPackedBounds.FullVocabularySmallBatchPreparesWithoutWeightStorage',
    'GgmlCudaPackedBounds.LargeHeadsDeclineFallbackAndPaddedLayouts',
    'GgmlCudaPackedBounds.EncodedAndLogicalLimitsKeepOtherPortsBounded',
    'GgmlCudaPackedLargeRead.GeneratedQ8TailBeyondI32RunsM1AndM2',
}


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


current = module('_packed_head_actual_current_closure', P / 'current-integration/build.py')
base = current.base
read, save, identity, require, resolve = current.read, current.save, current.identity, current.require, current.resolve


def checked_probe():
    probe = base.check_record(PROBE)
    changed = {str(resolve(row['path'])).lower() for row in read(P / 'orin-proposal/source-facts.json')}
    overlap = [row['path'] for row in probe['dependencies'] if str(resolve(row['path'])).lower() in changed]
    if overlap:
        raise ValueError('Compiled probe sees a changed canonical dependency: ' + repr(overlap))
    return probe


def link(attempt):
    current.expected_sources(True)
    original, actual_ready, runtime_path, old_consumer, records = current.closure(1)
    probe = checked_probe()
    fresh_paths = [P / 'current-integration/compile1' / tag / 'identity.json'
                   for tag in ('provider', 'tensor-program')]
    fresh = [base.check_record(path) for path in fresh_paths]
    old_object = str(resolve(old_consumer['object']['path'])).lower()
    command, replaced = [], 0
    for arg in original['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:')):
            continue
        if arg.lower().endswith('.obj') and str(resolve(arg)).lower() == old_object:
            arg = probe['object']['path']
            replaced += 1
        command.append(arg)
    if replaced != 1:
        raise ValueError('Must replace exactly the current Flash consumer with the compiled probe')
    objects = [str(resolve(arg)).lower() for arg in command if arg.lower().endswith('.obj')]
    for record in fresh:
        if objects.count(str(resolve(record['object']['path'])).lower()) != 1:
            raise ValueError('New current provider object not present exactly once')
    if old_object in objects:
        raise ValueError('Retired Flash consumer remains in probe link')
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'packed-head-current.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    source_facts = read(P / 'orin-proposal/source-facts.json')
    save(out / 'link-plan.json', dict(command=command,
        actual_base_link=actual_ready['link_plan'], base_ready=identity(P / 'current-integration/current-link1/ready.json'),
        compiled_probe_record=identity(PROBE), reused_probe=probe['object'],
        probe_changed_dependencies=[], retained_host_records=[identity(path) for path in records],
        required_fresh_provider_records=[identity(path) for path in fresh_paths],
        removed_consumer=old_consumer['object'], source_facts=source_facts,
        canonical_final_sources=[identity(R / row['path']) for row in source_facts],
        retained_inputs=original['retained_inputs'], native_inputs=original['native_inputs'],
        rebuilt_translation_units=0, SDK_builds=0, NVCC_builds=0, HTTP=0,
        generated_probe_not_original_model=True, Orin_verified=False))
    h = base.helpers()
    env, _ = h.b.environment(command, [], out)
    h.c.execute('link', command, env, out)
    if read(out / 'link.result.json')['exit'] != 0:
        raise ValueError('Probe overlay link failed')
    runtime = read(runtime_path)
    old_dir = str(resolve(runtime_path).parent)
    for row in runtime['staged_dlls']:
        require(row)
        dll = resolve(row['path'])
        os.link(dll, out / dll.name)
    runtime['PATH'] = str(out) + os.pathsep + runtime['PATH'].replace(old_dir, str(out))
    runtime.update(previous=identity(runtime_path), staged_dlls=[identity(path) for path in out.glob('*.dll')],
                   no_recompile=True, single_probe_overlay=True)
    save(out / 'runtime-environment.json', runtime)
    save(out / 'ready.json', dict(image=identity(image), link_plan=identity(out / 'link-plan.json'),
        link_result=identity(out / 'link.result.json'), runtime_environment=identity(out / 'runtime-environment.json'),
        probe_record=identity(PROBE), required_provider_records=[identity(path) for path in fresh_paths],
        script=identity(Path(__file__)), original_model_result=False, Orin_verified=False))
    print('LINKED', image)


def run(attempt, timeout):
    current.expected_sources(True)
    checked_probe()
    folder = S / f'tests-link{attempt}'
    ready = read(folder / 'ready.json')
    for key in ('image', 'link_plan', 'link_result', 'runtime_environment', 'probe_record', 'script'):
        require(ready[key])
    for row in ready['required_provider_records']:
        require(row)
        base.check_record(resolve(row['path']))
    runtime = read(folder / 'runtime-environment.json')
    for row in runtime['staged_dlls']:
        require(row)
    out = S / f'run{attempt}'
    out.mkdir(exist_ok=False)
    env = os.environ.copy()
    env['PATH'] = runtime['PATH']
    command = [ready['image']['path'], '--gtest_filter=GgmlCudaPackedBounds.*:GgmlCudaPackedLargeRead.*',
               '--gtest_throw_on_failure=1', '--gtest_output=xml:' + str(out / 'gtest.xml')]
    save(out / 'plan.json', dict(command=command, ready=identity(folder / 'ready.json'), image=ready['image'],
        timeout_seconds=timeout, expected_cases=sorted(EXPECTED), generated_probe_not_original_model=True,
        HTTP=0, SDK_builds=0, NVCC_builds=0, Orin_verified=False))
    runner = module('_packed_head_actual_bounded_runner', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    process = runner.execute(command, env, out / 'native', timeout=timeout)
    root = ET.parse(out / 'gtest.xml').getroot() if (out / 'gtest.xml').exists() else None
    cases = root.findall('.//testcase') if root is not None else []
    names = [case.attrib['classname'] + '.' + case.attrib['name'] for case in cases]
    failures = sum(bool(case.findall('failure') or case.findall('error')) for case in cases)
    skips = sum(bool(case.findall('skipped')) or case.attrib.get('status') != 'run'
                or case.attrib.get('result') != 'completed' for case in cases)
    passed = process['exit'] == 0 and not process['timed_out'] and len(cases) == 4 and set(names) == EXPECTED and failures == skips == 0
    current.expected_sources(True)
    save(out / 'summary.json', dict(process=process, passed=passed, cases=len(cases), failures=failures, skipped=skips,
        case_names=names, properties={name: {p.attrib['name']: p.attrib['value'] for p in case.findall('./properties/property')}
                                     for name, case in zip(names, cases)},
        gtest=identity(out / 'gtest.xml') if root is not None else None,
        image=ready['image'], ready=identity(folder / 'ready.json'), link_plan=ready['link_plan'],
        runtime_environment=ready['runtime_environment'], required_provider_records=ready['required_provider_records'],
        probe_record=ready['probe_record'], original_model_result=False, Orin_verified=False,
        HTTP=0, SDK_builds=0, NVCC_builds=0, rebuilt_translation_units=0))
    print('RESULT', out / 'summary.json', 'PASS' if passed else 'FAIL')
    if not passed:
        raise SystemExit(process['exit'] or 1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('link', 'run'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--timeout', type=int, default=180)
    args = parser.parse_args()
    if args.attempt <= 0 or args.timeout <= 0:
        raise ValueError('Positive attempt and timeout required')
    link(args.attempt) if args.action == 'link' else run(args.attempt, args.timeout)
