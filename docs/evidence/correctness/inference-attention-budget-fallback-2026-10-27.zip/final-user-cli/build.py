"""Explicit one-Model-TU followup; preparing never builds or starts a model.

The deferred link uses the cap followup's real224 closure when ready. No probe,
SDK/NVCC, download, full performance window or automatic process retry.
"""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
import traceback
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
ROOT = W.parents[2]
BASE = W.parent
CAP = BASE / 'followup-budget'
MODEL = ROOT / '.scratch/inference-wave-recovery-final-20261027'
spec = importlib.util.spec_from_file_location('retained_user_cli_tools', MODEL / 'check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key
PROJECT_ROOTS = ('include', 'engine', 'src', 'tests')

def project(path):
    p = Path(path).resolve()
    return p.is_relative_to(ROOT) and p.relative_to(ROOT).parts and p.relative_to(ROOT).parts[0] in PROJECT_ROOTS

def environment():
    value = b.environment()
    runtime = read(CAP / 'runtime-plan.json')
    value['PATH'] = str(W / 'bin') + ';' + runtime['PATH']
    return value

def prepare():
    assert not (W / 'plan.json').exists(), 'Preserve first preparation'
    old_ready = read(MODEL / 'ready-model.json')
    old = Path(old_ready['compiled']['snapshot']['path']).read_text(encoding='utf-8-sig')
    new = (ROOT / 'engine/models/qwen35/main.cc').read_text(encoding='utf-8-sig')
    help_line = '        "  --decode-overlap auto|off   Automatic CUDA greedy continuation (default: auto)\\n"\n'
    comment = ('        // Internal benchmark/diagnostic override. Normal use selects the\n'
               '        // automatic policy and falls back using actual execution facts.\n')
    assert old.count(help_line) == 1 and old.count(' [--decode-overlap auto|off]') == 1
    assert new.count(comment) == 1
    assert old.replace(help_line, '', 1).replace(' [--decode-overlap auto|off]', '', 1) == new.replace(comment, '', 1), 'Unexpected behavior change outside approved help/usage/comment'
    proof = dict(old_model=old_ready['compiled']['snapshot'], current_model=pin(ROOT/'engine/models/qwen35/main.cc'),
        public_help_and_usage_removed_only=True, internal_parser_default_and_execution_unchanged=True,
        performance_claim=False, old_40_window_image=read(BASE/'ready-cli.json')['image'])
    save(W/'source-change-proof.json', proof)
    (W/'source-change.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='W17-main441ff',tofile='current-user-cli-main')), encoding='utf-8')
    old_freeze = read(MODEL/'source-freeze-model.json')
    rows = old_freeze['fresh'] + old_freeze['reused']
    files = {Path(row['original']['path']).resolve() for row in rows if project(row['original']['path'])}
    files.add(ROOT/'engine/models/qwen35/main.cc')
    include_dirs = [ROOT/'include', ROOT, ROOT/'engine/models/qwen35', ROOT/'engine/inference', ROOT/'src/graph', ROOT/'src/compute']
    todo = list(files)
    while todo:
        path = todo.pop()
        for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"', path.read_text(encoding='utf-8-sig'), re.M):
            found = next((p.resolve() for parent in (path.parent,*include_dirs) if (p:=parent/name).is_file()), None)
            if found is not None and project(found) and found not in files:
                files.add(found); todo.append(found)
    frozen=[]
    for path in sorted(files):
        original=pin(path); snapshot=W/'source'/path.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True,exist_ok=True)
        with snapshot.open('xb') as f: f.write(path.read_bytes())
        saved=pin(snapshot); assert (original['bytes'],original['sha256']) == (saved['bytes'],saved['sha256'])
        frozen.append(dict(original=original,snapshot=saved))
    save(W/'source-freeze.json',frozen)
    template=read(MODEL/'logs/model/command.json')['command']
    out=W/'compile/model'; source=W/'source/engine/models/qwen35/main.cc'
    command=[template[0],*('/I'+str(W/'source'/p) for p in ('include','','engine/models/qwen35','engine/inference','src/graph','src/compute','tests/tools'))]
    for index,arg in enumerate(template[1:],1):
        if template[index-1].lower()=='/sourcedependencies': arg=str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'): arg='/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'): arg='/Fd'+str(out/'unit.pdb')
        elif arg.lower().endswith(('.cc','.cpp','.cxx')): arg=str(source)
        elif arg.lower().startswith('/i'):
            directory=Path(arg[2:]).resolve()
            if directory==ROOT or project(directory) or directory.is_relative_to(ROOT/'.scratch'): continue
        command.append(arg)
    save(W/'recipe-compile.json',dict(command=command, original_recipe=pin(MODEL/'logs/model/command.json')))
    save(W/'environment.json',{k:environment().get(k,'') for k in ('PATH','INCLUDE','LIB','LIBPATH')})
    save(W/'plan.json',dict(status='FROZEN_NOT_BUILT', current_main=pin(ROOT/'engine/models/qwen35/main.cc'),
        snapshot=pin(source), source_freeze=pin(W/'source-freeze.json'), change_proof=pin(W/'source-change-proof.json'),
        command=command, recipe=pin(W/'recipe-compile.json'), original_model=old_ready['compiled']['object'],
        counts=dict(CXX=1,links=1,NVCC=0,SDK_rebuilds=0,probe_builds=0),
        deferred_cap_ready=str(CAP/'ready-cli.json'),
        pending_link='Bind actual cap ready/224 inputs only during link; replace original81813 Model only.',
        pending_sanity='One real natural two-turn check replaces cap model-sanity. No new TPS/memory window.',
        script=pin(__file__)))
    print('PREPARED_AND_FROZEN one Model TU; no compile/link/model started')

def validate():
    plan=read(W/'plan.json'); exact(plan['script']); exact(plan['source_freeze']); exact(plan['change_proof']); exact(plan['recipe'])
    for row in read(plan['source_freeze']['path']): exact(row['original']); exact(row['snapshot'])
    return plan

def compile_model():
    plan=validate(); out=W/'compile/model'; out.mkdir(parents=True,exist_ok=False)
    process=b.b.h.execute(plan['command'],environment(),W/'logs/model',timeout=240)
    data=read(out/'dependencies.json')['Data']; assert key(data['Source'])==key(plan['snapshot']['path'])
    allowed={key(row['snapshot']['path']):row['snapshot'] for row in read(plan['source_freeze']['path'])}
    actual=[]
    for path in dict.fromkeys([data['Source'],*data['Includes']]):
        row=pin(path)
        if Path(path).is_relative_to(W/'source'): assert row==allowed[key(path)]
        else:
            assert not project(path), ('Live product include',path)
            assert not (Path(path).is_relative_to(ROOT/'.scratch') and any(part.startswith('source') for part in Path(path).parts)), ('Old source overlay include',path)
        actual.append(row)
    validate(); save(out/'actual-dependencies.json',actual)
    save(out/'compiled.json',dict(source=plan['current_main'],snapshot=plan['snapshot'],object=pin(out/'unit.obj'),
        process=process,command=pin(W/'logs/model/command.json'),dependencies=pin(out/'dependencies.json'),actual_dependencies=pin(out/'actual-dependencies.json')))
    print('CXX_PASS one Model TU only')

def link_model():
    plan=validate(); compiled=read(W/'compile/model/compiled.json'); exact(compiled['object'])
    cap_ready=read(CAP/'ready-cli.json'); exact(cap_ready['inputs']); exact(cap_ready['recipe'])
    original=read(cap_ready['inputs']['path']); assert len(original)==224
    old=plan['original_model']; assert sum(row==old for row in original)==1
    inputs=[compiled['object'] if row==old else row for row in original]
    assert sum(a!=z for a,z in zip(original,inputs))==1
    for row in inputs: exact(row)
    image=W/'bin/hyle-user-cli.exe'; image.parent.mkdir(parents=True,exist_ok=True)
    assert not image.exists() and not (W/'link-model').exists(), 'Preserve first link'
    command=[]; replaced=0
    for arg in read(cap_ready['recipe']['path'])['command']:
        if key(arg)==key(old['path']): arg=compiled['object']['path']; replaced+=1
        for option,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(option): arg=option+str(image.with_suffix(suffix)); break
        command.append(arg)
    assert replaced==1
    save(W/'link-inputs.json',inputs)
    save(W/'link-plan.json',dict(cap_ready=pin(CAP/'ready-cli.json'),original_inputs=cap_ready['inputs'],
        changed_input_count=1,replaced=old,new_model=compiled['object'],runtime=pin(CAP/'runtime-plan.json')))
    process=b.b.h.execute(command,environment(),W/'link-model',timeout=180)
    save(W/'ready-cli.json',dict(status='LINKED_NOT_RUN',image=pin(image),compiled=compiled,
        inputs=pin(W/'link-inputs.json'),recipe=pin(W/'link-model/command.json'),runtime=pin(CAP/'runtime-plan.json'),
        plan=pin(W/'plan.json'),link_plan=pin(W/'link-plan.json'),process=process,
        performance_claim=False,old_40_window_identity=read(BASE/'ready-cli.json')['image']))
    print('LINK_PASS changed Model/help image, not the measured40 image')

def help_checks():
    validate(); ready=read(W/'ready-cli.json'); exact(ready['image'])
    cases=[('help',['--help'],0),('usage',[],1),('internal-off-parse',['--decode-overlap','off'],1)]
    results=[]
    for name,args,expected in cases:
        folder=W/'cli-checks'/name; folder.mkdir(parents=True,exist_ok=False)
        command=[ready['image']['path'],*args]; save(folder/'command.json',dict(command=command,expected_exit=expected,timeout=15))
        start=time.monotonic()
        with (folder/'stdout.log').open('wb') as stdout,(folder/'stderr.log').open('wb') as stderr:
            child=subprocess.Popen(command,cwd=ROOT,env=environment(),stdout=stdout,stderr=stderr)
            try: code=child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                child.kill(); code=child.wait(); save(folder/'process.json',dict(exit=code,pid=child.pid,seconds=time.monotonic()-start,timeout=True)); raise
        process=dict(exit=code,pid=child.pid,seconds=time.monotonic()-start)
        save(folder/'process.json',process)
        text=(folder/'stdout.log').read_text(encoding='utf-8-sig')+(folder/'stderr.log').read_text(encoding='utf-8-sig')
        assert code==expected and 'decode-overlap' not in text, (name,process,text)
        assert ('Usage: hyle' if name=='help' else 'usage: hyle') in text
        results.append(dict(name=name,process=process,model_started=False))
    save(W/'cli-checks/summary.json',dict(status='PASS',cases=results,scope='No inference; help/usage hide option, internal off parsing reaches normal missing-input usage.'))
    print('PASS help/usage/internal parser, zero model processes')

def model_sanity():
    validate(); ready=read(W/'ready-cli.json'); exact(ready['image'])
    assert not (CAP/'model-two-turn').exists(), 'Root requested one sanity replacing cap sanity, not another model rerun'
    previous=BASE/'model-checks/two-turn-auto'
    command=[ready['image']['path'],*read(previous/'command.json')['command'][1:]]
    # Keep the exact internal auto parameter in the retained diagnostic command;
    # no user-facing help is used to configure policy or bypass capability checks.
    process=b.b.h.execute(command,environment(),W/'model-two-turn',timeout=180)
    spec=importlib.util.spec_from_file_location('retained_user_cli_semantics',MODEL/'run.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    actual=read(W/'model-two-turn/stdout.log'); expected=read(previous/'stdout.log')
    changes=m.changed(m.facts.non_time(expected),m.facts.non_time(actual))
    save(W/'model-two-turn/complete-non-time-differences.json',changes)
    assert not changes,changes[:8]
    assert actual['live_committed_versions']==0
    save(W/'model-two-turn/summary.json',dict(status='PASS_COMPLETE_NON_TIME',process=process,image=ready['image'],
        previous=pin(previous/'stdout.log'),differences=changes,performance_claim=False,
        scope='One current cap+user-help sanity replaces followup-budget model-sanity; no new TPS/VRAM comparison.'))
    print('PASS one natural two-turn sanity; no performance claim')

if __name__=='__main__':
    try:
        action=sys.argv[1]
        if action=='prepare': prepare()
        elif action=='compile': compile_model()
        elif action=='link': link_model()
        elif action=='help-checks': help_checks()
        elif action=='model-sanity': model_sanity()
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True,exist_ok=True)
        (W/('failure-'+ '-'.join(sys.argv[1:2])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8')
        raise
