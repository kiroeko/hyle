"""Additive recovery of a wrong CLI-checker message assertion, no model rerun."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
import traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_user_cli_reader',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact

def check(folder,name,expected):
    command=read(folder/'command.json');process=read(folder/'process.json')
    assert process['exit']==expected,(name,process)
    stdout=(folder/'stdout.log').read_text(encoding='utf-8-sig')
    stderr=(folder/'stderr.log').read_text(encoding='utf-8-sig')
    text=stdout+stderr
    assert 'decode-overlap' not in text,(name,text)
    if name=='help':assert 'Usage: hyle --inputs DIR' in stdout and not stderr
    else:
        assert stderr.strip()=='Qwen3.5 text consumer: --inputs DIR is required',(name,text)
        assert not stdout and 'unknown' not in text.lower() and 'invalid' not in text.lower()
    return dict(name=name,process=process,command=pin(folder/'command.json'),
        stdout=pin(folder/'stdout.log'),stderr=pin(folder/'stderr.log'),model_started=False)

def main():
    b.validate();ready=read(W/'ready-cli.json');exact(ready['image'])
    original=[pin(path) for path in sorted(W.glob('failure-help-checks-*.log'))]
    assert original,'Preserve the actual first helper assertion failure'
    results=[check(W/'cli-checks/help','help',0),check(W/'cli-checks/usage','usage',1)]
    folder=W/'cli-checks/internal-off-parse'
    folder.mkdir(parents=True,exist_ok=False)
    command=[ready['image']['path'],'--decode-overlap','off']
    save(folder/'command.json',dict(command=command,expected_exit=1,timeout=15,
        scope='Internal off parsing only. Missing inputs stops before Model construction.'))
    start=time.monotonic()
    with (folder/'stdout.log').open('wb') as stdout,(folder/'stderr.log').open('wb') as stderr:
        child=subprocess.Popen(command,cwd=b.ROOT,env=b.environment(),stdout=stdout,stderr=stderr)
        try:code=child.wait(timeout=15)
        except subprocess.TimeoutExpired:
            child.kill();code=child.wait()
            save(folder/'process.json',dict(exit=code,pid=child.pid,seconds=time.monotonic()-start,timeout=True))
            raise
    save(folder/'process.json',dict(exit=code,pid=child.pid,seconds=time.monotonic()-start))
    results.append(check(folder,'internal-off-parse',1))
    save(W/'cli-checks/resumed-summary.json',dict(status='PASS_AFTER_HELPER_MESSAGE_ASSERTION_CORRECTION',
        frozen_ready=pin(W/'ready-cli.json'),frozen_plan=pin(W/'plan.json'),frozen_build=pin(W/'build.py'),
        correction_script=pin(__file__),original_helper_failures=original,cases=results,
        preserved_existing_processes=['help','usage'],new_processes=['internal-off-parse'],
        product_changed=False,frozen_plan_changed=False,model_processes=0,performance_claim=False,
        explanation='Original help/usage processes had correct exits and hidden option. Their checker incorrectly required usage: hyle; actual missing-input text is --inputs DIR is required. Read original logs offline and run only the previously unexecuted internal-off parser check.'))
    print('PASS reused2 CLI process receipts +1 previously unrun internal-off parse;0 model processes')

if __name__=='__main__':
    try:main()
    except BaseException:
        (W/('failure-help-resume-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(),encoding='utf-8');raise
