"""Independent cap-compatibility receipt, after final user-CLI sanity exists.

This action never compiles, runs a model, or changes the original pre-cap/40
evidence. The final UI process replaces the deliberately unrun budget sanity.
"""
from pathlib import Path
import difflib
import importlib.util
import json
import re
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
BASE = W.parent
R = W.parents[2]
UI = BASE / 'followup-user-cli'
OUT = R / 'docs/evidence/correctness/inference-attention-budget-fallback-2026-10-27'
spec = importlib.util.spec_from_file_location('retained_attention_receipt_helpers', BASE / 'package.py')
p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
read, pin, exact, short = p.read, p.pin, p.exact, p.short
CHANGED = ('src/compute_provider_flashinfer/native_batch.cu',
           'src/compute_provider_flashinfer/native_batch.h',
           'src/compute_provider_flashinfer/flashinfer_provider.cc',
           'tests/graph_batch/batch_capture_test.cc')


def main():
    assert not OUT.with_suffix('.zip').exists(), 'Keep any previously published evidence'
    assert not (W / 'model-two-turn').exists(), 'Budget model sanity must not have been redundantly run'
    # These are actual records, not promises about the forthcoming UI process.
    ui_summary = read(UI / 'model-two-turn/summary.json')
    assert ui_summary['status'] == 'PASS_COMPLETE_NON_TIME' and ui_summary['process']['exit'] == 0
    assert ui_summary['differences'] == [] and read(UI / 'model-two-turn/complete-non-time-differences.json') == []
    help_summary = read(UI / 'cli-checks/resumed-summary.json')
    assert help_summary['status'] == 'PASS_AFTER_HELPER_MESSAGE_ASSERTION_CORRECTION'
    assert help_summary['model_processes'] == 0 and help_summary['new_processes'] == ['internal-off-parse']
    assert [row['process']['exit'] for row in help_summary['cases']] == [0, 1, 1]
    component = read(W / 'component-summary.json')
    assert component['status'] == 'PASS' and component['executions'] == 100 and component['process']['exit'] == 0
    ready_component, ready_cli, ready_ui = (read(folder / name) for folder, name in (
        (W, 'ready-component.json'), (W, 'ready-cli.json'), (UI, 'ready-cli.json')))
    source_rows = read(W / 'source-freeze.json')
    sources = []
    changes = []
    for relative in CHANGED:
        row = next(row for row in source_rows if Path(row['original']['path']) == R / relative)
        exact(row['original']); exact(row['snapshot'])
        sources.append(dict(path=relative, bytes=row['snapshot']['bytes'], sha256=row['snapshot']['sha256']))
        old = BASE / ('component-source3' if relative.startswith('tests/') else 'source') / relative
        new = Path(row['snapshot']['path'])
        changes.extend(difflib.unified_diff(old.read_text(encoding='utf-8-sig').splitlines(keepends=True),
            new.read_text(encoding='utf-8-sig').splitlines(keepends=True),
            fromfile='pre-cap/' + relative, tofile='budget/' + relative))
    (W / 'budget.diff').write_text(''.join(changes), encoding='utf-8')
    frozen = read(W / 'frozen.json')
    assert all(frozen['struct_ABI'][name]['tokens_identical'] for name in ('BatchSpec', 'BatchFacts'))
    ui_inputs = read(ready_ui['inputs']['path'])
    assert len(ui_inputs) == 224
    # Mechanically prove final user-CLI really contains these cap products,
    # rather than using its successful process to qualify another binary.
    for name in ('native', 'provider'):
        expected = read(W / 'compile' / name / 'compiled.json')['object']
        assert sum(row == expected for row in ui_inputs) == 1, name
    retained_batch = read(W / 'plan.json')['retained_batch']['object']
    assert sum(row == retained_batch for row in ui_inputs) == 1
    assert ui_summary['image'] == ready_ui['image']
    exact(ready_ui['compiled']['source']); exact(ready_ui['compiled']['snapshot'])
    stdout = (W / 'run-component/stdout.log').read_text(encoding='utf-8-sig')
    records = []
    for match in re.finditer(r'^stable_attention slot=(.*)$', stdout, re.M):
        record = {'slot': int(match[1].split()[0])}
        record.update({name: int(value) for name, value in re.findall(r'(\w+)=(-?\d+)', match[1])})
        records.append(record)
    assert len(records) == 100
    capped = [row for row in records if row['float_cap'] == (1 << 20)]
    assert len(capped) == 4 and [row['KV'] for row in capped] == [127, 128, 129, 129]
    assert all(row['float_bytes'] <= row['float_cap'] for row in capped)
    graph_127 = next(row['float_bytes'] for row in records
                     if row['slot'] == 0 and row['R'] == 1 and row['T'] == 1 and row['KV'] == 127 and row['float_cap'] > (1 << 20))
    assert graph_127 > (1 << 20)
    totals = re.search(r'^stable_attention totals recorded=(\d+) reused=(\d+) plan_waits=(\d+) max_abs_error=(\S+)', stdout, re.M)
    assert totals
    build_processes = {name: read(W / 'logs' / name / 'process.json') for name in ('native', 'provider', 'test')}
    assert all(row['exit'] == 0 for row in build_processes.values())
    assert all(read(W / ('link-' + name) / 'process.json')['exit'] == 0 for name in ('cli', 'component'))
    original_evidence = R / 'docs/evidence/correctness/inference-stable-attention-2026-10-27.json'
    before = read(original_evidence)
    receipt = dict(schema='hyle.correctness.attention-budget-fallback.v1', date='2026-10-27', status='PASS_FINITE_FOLLOWUP',
        scope='Preserve executable requests under explicit small workspace caps; original stable-attention40 window is pre-cap evidence.',
        implementation=dict(sources=sources,
            change='Stage graph scheduler only when its real workspace fits original caps; otherwise query and materialize the original non-graph scheduler using the same cached allow_graph_plan choice.',
            invariants='BatchSpec/Facts declarations unchanged. Original admission, exact workspace limits, native Queue/error/retirement and BeforeCommandChange remain.',
            ABI_proof='frozen.json contains both original and current BatchSpec/Facts declarations and matching token hashes.'),
        build=dict(scope='Budget product/test followup only; final user-CLI Model build is separate below.',
            NVCC=1, host_CXX=2, links=2, processes=build_processes, first_attempts_passed=True,
            CLI_inputs=224, component_inputs=225, reuse='Retain original successful batch_execution object and all other exact inputs; replace only native/provider/test.'),
        component=dict(process=component['process'], executions=100,
            original_matrix='96 real Graph executions: R1/R2 × T1/T2 × KV127/128/129/383/384/385/1023, BF16 page16 D256, two Invocations, fresh/shape/replay checks.',
            numerical_oracle='Original FP64 dot/softmax/value reference for every active output, exact inactive zeros and both caller guards after each poison/submit.',
            allowed_abs_error=.007, maximum_abs_error=float(totals[4]),
            recorded_ranges=int(totals[1]), reused_ranges=int(totals[2]), actual_preparation_host_waits=int(totals[3]),
            uncapped_graph_float_bytes_at_R1_T1_KV127=graph_127, small_float_cap=1 << 20, capped_observations=capped,
            interpretation='The cap really excludes the padded graph workspace, yet the original native schedule executes inside actual Graph RequireCapture. The native scheduler flag is not a fallback to Graph Commands. Fresh capture at KV129 is legitimate and numerically checked. Capture reuse is not a zero-wait promise.'),
        final_model_sanity=dict(process=ui_summary['process'], image=short(ready_ui['image']),
            actual_UI_Model_source=short(ready_ui['compiled']['source']),
            UI_build=dict(host_CXX=1, links=1, compile_process=read(UI / 'logs/model/process.json'),
                          link_process=read(UI / 'link-model/process.json')),
            summary=short(pin(UI / 'model-two-turn/summary.json')), complete_non_time_differences=[],
            replaced_unrun_budget_sanity=True,
            attribution='Final user-CLI224 closure mechanically contains these exact native/provider objects and retained batch object; only its Model/help TU differs from budget CLI.',
            UI_only_checks=help_summary['cases'],
            preserved_helper_errors=[
                dict(stage='Before actual CXX', reason="TypeError from read(pin) missing ['path']; only helper amended, source/recipe unchanged; one actual Model CXX followed."),
                dict(stage='After help/usage processes', reason='Checker assumed usage: hyle; actual valid missing-input diagnostic is --inputs DIR is required. Existing help/usage were rechecked offline, only unrun internal-off was resumed.')]),
        runtime_processes=dict(Graph_component=1, natural_model_sanity=1, UI_only_no_model=3),
        images=dict(component=short(ready_component['image']), budget_CLI_linked_not_run=short(ready_cli['image']),
                    final_UI_CLI=short(ready_ui['image']), measured40_pre_budget=before['artifacts']['cli_image']),
        prior=dict(receipt=short(pin(original_evidence)), archive=before['archive'],
            reuse='Original v16 native header/recipe and common three-TU provenance are referenced, not recopied as SDK payload.'),
        limits=['No new TPS/VRAM measurement; original40-process results remain tied to d9a2fe2c pre-budget-fallback image.',
            'One final natural two-turn model sanity replaces an extra budget model run; no fresh40 window or extra off/MTP reruns.',
            'Finite BF16 D256 Graph geometry and cap case do not prove every supported dtype/shape/device or injected-failure behavior.',
            'Complete existing CLI non-time report equality is not a bitwise proof of every hidden intermediate.',
            'No SDK/model download or whole rebuild. Archive excludes binaries, objects, libraries, model data and SDK trees.'])
    entries = {}
    def add(path, arc):
        path = Path(path)
        assert path.is_file(), path
        assert path.suffix.lower() not in ('.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.gguf', '.safetensors', '.bin')
        assert arc not in entries, arc
        entries[arc] = path
    for name in ('package.py', 'build.py', 'budget.diff', 'plan.json', 'frozen.json', 'source-freeze.json',
                 'environment.json', 'runtime-plan.json', 'ready-cli.json', 'ready-component.json',
                 'cli-link-inputs.json', 'component-link-inputs.json', 'component-summary.json'):
        add(W / name, 'budget/' + name)
    for relative in CHANGED:
        add(W / 'source' / relative, 'source/' + relative)
    for directory in ('recipes', 'logs', 'link-cli', 'link-component', 'run-component'):
        for path in sorted((W / directory).rglob('*')):
            if path.is_file() and path.suffix.lower() in ('.json', '.log', '.xml', '.d'):
                add(path, 'budget/' + path.relative_to(W).as_posix())
    for unit in ('native', 'provider', 'test'):
        for path in sorted((W / 'compile' / unit).glob('*')):
            if path.is_file() and path.suffix.lower() in ('.json', '.log', '.d'):
                add(path, 'budget/' + path.relative_to(W).as_posix())
    # UI source differs only in user-facing help. Preserve its bounded patch,
    # token/source proof and exact compiled dependencies, not a second header tree.
    for name in ('build.py', 'build-attempt1.py', 'plan-attempt1.json', 'helper-amendment.json', 'help-resume.py',
                 'environment.json', 'plan.json', 'source-change-proof.json', 'source-change.diff',
                 'source-freeze.json', 'recipe-compile.json', 'ready-cli.json', 'link-plan.json', 'link-inputs.json'):
        add(UI / name, 'final-user-cli/' + name)
    add(ready_ui['compiled']['snapshot']['path'], 'source/final-user-cli/engine/models/qwen35/main.cc')
    for path in UI.glob('failure-*.log'):
        add(path, 'final-user-cli/' + path.name)
    for directory in ('logs', 'link-model', 'model-two-turn', 'cli-checks', 'compile/model'):
        for path in sorted((UI / directory).rglob('*')):
            if path.is_file() and path.suffix.lower() in ('.json', '.log', '.xml', '.d'):
                add(path, 'final-user-cli/' + path.relative_to(UI).as_posix())
    manifest = []
    for arc, path in sorted(entries.items()):
        identity = pin(path)
        manifest.append(dict(member=arc, bytes=identity['bytes'], sha256=identity['sha256']))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(OUT.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for arc, path in sorted(entries.items()): archive.write(path, arc)
        archive.writestr('manifest.json', json.dumps(dict(members=manifest, self_hash_excluded=True), indent=2) + '\n')
    with zipfile.ZipFile(OUT.with_suffix('.zip')) as archive:
        assert set(archive.namelist()) == set(entries) | {'manifest.json'}
        for row in manifest:
            value = archive.read(row['member'])
            assert len(value) == row['bytes'] and p.hashlib.sha256(value).hexdigest() == row['sha256'], row['member']
        assert json.loads(archive.read('manifest.json'))['members'] == manifest
    receipt['archive'] = dict(**short(pin(OUT.with_suffix('.zip'))), members=len(manifest) + 1, every_member_verified=True)
    OUT.with_suffix('.json').write_text(p.compact(receipt), encoding='utf-8')
    result = dict(receipt=pin(OUT.with_suffix('.json')), archive=pin(OUT.with_suffix('.zip')),
        members=len(manifest) + 1, status='VERIFIED_ALL_MEMBERS', no_new_build_or_inference=True)
    (W / 'package-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
