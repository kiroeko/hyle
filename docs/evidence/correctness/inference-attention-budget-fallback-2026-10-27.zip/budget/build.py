"""Explicit bounded cap-compatibility followup; never rebuild the SDK.

prepare records metadata only. freeze/compile/link/run are independent actions.
Original prototype sources, 40-process image and correctness package stay intact.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys
import time
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
BASE = W.parent
R = W.parents[2]
spec = importlib.util.spec_from_file_location('retained_stable_attention_tools', BASE / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key
SOURCES = dict(native='src/compute_provider_flashinfer/native_batch.cu',
               provider='src/compute_provider_flashinfer/flashinfer_provider.cc',
               test='tests/graph_batch/batch_capture_test.cc')
FILTER = 'GraphBatchCapture.UniformDecodePlansKeepCaptureAcrossGrowingPagedPrefixes'


def canonical(path):
    p = Path(path).resolve()
    for root in (BASE / 'source', BASE / 'component-source3'):
        if p.is_relative_to(root):
            return R / p.relative_to(root)
    return p


def environment():
    value = b.environment()
    value['PATH'] = str(W / 'bin') + ';' + value['PATH']
    return value


def prepare():
    units = {}
    for name, previous in (('native', 'native'), ('provider', 'provider'), ('test', 'component3')):
        compiled = read(BASE / 'compile' / previous / 'compiled.json')
        recipe = BASE / 'recipes' / ('compile-' + previous + '.json')
        units[name] = dict(source=str(R / SOURCES[name]), old_object=compiled['object'],
                           recipe=pin(recipe), original_compiled=pin(BASE / 'compile' / previous / 'compiled.json'))
        if name != 'native':
            units[name]['dependencies'] = pin(BASE / 'compile' / previous / 'dependencies.json')
    images = {}
    for name in ('cli', 'component'):
        ready = read(BASE / ('ready-' + name + '.json'))
        images[name] = dict(ready=pin(BASE / ('ready-' + name + '.json')),
            image_as_run=ready['image'], inputs=ready['inputs'], recipe=ready['recipe'])
    assert len(read(images['cli']['inputs']['path'])) == 224
    assert len(read(images['component']['inputs']['path'])) == 225
    save(W / 'plan.json', dict(status='METADATA_ONLY_NOT_FROZEN', units=units, baselines=images,
        retained_batch=read(BASE / 'compile/batch/compiled.json'),
        original_vendor=read(BASE / 'frozen-plan.json')['vendor_headers'],
        counts=dict(NVCC=1, host_CXX=2, links=2, component_GTests=1, component_executions=100, model_sanity=1),
        policy='Only native/provider/test are replaced. Retain the successful prototype batch_execution object and all other actual inputs. Original d9a2fe2c image and40 window remain pre-budget-fallback evidence.'))
    save(W / 'environment.json', {k: environment().get(k, '') for k in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH')})
    save(W / 'runtime-plan.json', dict(PATH=environment()['PATH'], original_runtime=pin(BASE / 'runtime-plan.json'),
        ownership='Use original prototype bin runtime alias and already retained dependencies; no new SDK/DLL copy.'))
    print('PREPARED only: native/provider/test 3TUs +2links +1component +1natural sanity; no freeze/build/run')


def freeze():
    plan = read(W / 'plan.json')
    # Reusing this exact common product must not hide a source change.
    exact(plan['retained_batch']['source']); exact(plan['retained_batch']['snapshot'])
    for row in plan['original_vendor']:
        exact(row)
    files = {R / source for source in SOURCES.values()}
    files.add(R / 'src/compute_provider_flashinfer/native_batch.h')
    for name in ('provider', 'test'):
        for path in read(plan['units'][name]['dependencies']['path'])['Data']['Includes']:
            if b.project(canonical(path)):
                files.add(canonical(path))
    todo = list(files)
    while todo:
        p = todo.pop()
        for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"', p.read_text(encoding='utf-8-sig'), re.M):
            found = next((q.resolve() for root in (p.parent, R / 'include', R)
                          if (q := root / include).is_file()), None)
            if found is not None and b.project(found) and found not in files:
                files.add(found); todo.append(found)
    rows = []
    for p in sorted(files):
        snapshot = W / 'source' / p.relative_to(R)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        with snapshot.open('xb') as stream: stream.write(p.read_bytes())
        original, frozen = pin(p), pin(snapshot)
        assert (original['sha256'], original['bytes']) == (frozen['sha256'], frozen['bytes'])
        rows.append(dict(original=original, snapshot=frozen))
    save(W / 'source-freeze.json', rows)
    previous = (BASE / 'source/src/compute_provider_flashinfer/native_batch.h').read_text(encoding='utf-8-sig')
    current = (W / 'source/src/compute_provider_flashinfer/native_batch.h').read_text(encoding='utf-8-sig')
    ABI = {}
    for name in ('BatchSpec', 'BatchFacts'):
        pattern = r'struct ' + name + r' final \{.*?\n\};'
        old, new = re.search(pattern, previous, re.S).group(), re.search(pattern, current, re.S).group()
        assert b.tokens(old) == b.tokens(new)
        ABI[name] = dict(tokens_identical=True, old=old, new=new,
            sha256=hashlib.sha256(b.tokens(new).encode()).hexdigest())
    commands = {}
    for name, unit in plan['units'].items():
        exact(unit['recipe'])
        template = read(unit['recipe']['path'])['command']
        out = W / 'compile' / name
        command = [template[0]]
        if name != 'native':
            command += ['/I' + str(W / 'source' / folder) for folder in ('include', '', 'src/compute_provider_flashinfer')]
        for at, arg in enumerate(template[1:], 1):
            if name == 'native':
                if template[at - 1] == '-o': arg = str(out / 'unit.obj')
                elif template[at - 1] == '--dependency-output': arg = str(out / 'dependencies.d')
                elif arg.lower().endswith('.cu'): arg = str(W / 'source' / SOURCES[name])
            else:
                if template[at - 1].lower() == '/sourcedependencies': arg = str(out / 'dependencies.json')
                elif arg.lower().startswith('/fo'): arg = '/Fo' + str(out / 'unit.obj')
                elif arg.lower().startswith('/fd'): arg = '/Fd' + str(out / 'unit.pdb')
                elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = str(W / 'source' / SOURCES[name])
                elif arg.lower().startswith(('/i', '/external:i')):
                    lead = '/external:I' if arg.lower().startswith('/external:i') else '/I'
                    p = canonical(arg[len(lead):])
                    if p == R or b.project(p): arg = lead + str(W / 'source' / p.relative_to(R))
            command.append(arg)
        commands[name] = command
        save(W / 'recipes' / ('compile-' + name + '.json'), dict(command=command, previous=unit['recipe']))
    save(W / 'frozen.json', dict(plan=pin(W / 'plan.json'), source_freeze=pin(W / 'source-freeze.json'),
        commands=commands, struct_ABI=ABI))
    print('FROZEN exact followup sources/actual project dependencies; no compilation')


def validate():
    frozen = read(W / 'frozen.json')
    exact(frozen['plan']); exact(frozen['source_freeze'])
    for row in read(frozen['source_freeze']['path']): exact(row['original']); exact(row['snapshot'])
    plan = read(frozen['plan']['path'])
    exact(plan['retained_batch']['source']); exact(plan['retained_batch']['snapshot'])
    for row in plan['original_vendor']: exact(row)
    return frozen, plan


def compile_unit(name):
    frozen, plan = validate()
    assert name in SOURCES
    out = W / 'compile' / name; out.mkdir(parents=True, exist_ok=False)
    process = b.b.b.h.execute(frozen['commands'][name], environment(), W / 'logs' / name,
                             timeout=600 if name == 'native' else 240)
    if name == 'native':
        deps = pin(out / 'dependencies.d')
        actual = dict(generated_makefile=deps, original_v16_headers=plan['original_vendor'])
    else:
        deps = pin(out / 'dependencies.json'); data = read(deps['path'])['Data']
        assert key(data['Source']) == key(W / 'source' / SOURCES[name])
        assert not any(b.project(p) or (canonical(p) != Path(p).resolve()) for p in data['Includes']), 'old/live project header leak'
        allowed = {key(row['snapshot']['path']): row['snapshot'] for row in read(W / 'source-freeze.json')}
        actual = []
        for p in dict.fromkeys([data['Source'], *data['Includes']]):
            row = pin(p)
            if Path(p).is_relative_to(W / 'source'): assert row == allowed[key(p)]
            actual.append(row)
    validate(); save(out / 'actual-dependencies.json', actual)
    save(out / 'compiled.json', dict(source=pin(R / SOURCES[name]), snapshot=pin(W / 'source' / SOURCES[name]),
        object=pin(out / 'unit.obj'), process=process, dependencies=deps, actual_dependencies=pin(out / 'actual-dependencies.json'),
        command=pin(W / 'logs' / name / 'command.json')))
    print('COMPILE_PASS', name)


def link(name):
    _, plan = validate(); assert name in ('cli', 'component')
    base = plan['baselines'][name]; exact(base['inputs']); exact(base['recipe'])
    units = ('native', 'provider') if name == 'cli' else ('native', 'provider', 'test')
    compiled = {unit: read(W / 'compile' / unit / 'compiled.json') for unit in units}
    replacements = {key(plan['units'][unit]['old_object']['path']): compiled[unit]['object'] for unit in units}
    inputs = read(base['inputs']['path'])
    assert len(inputs) == (224 if name == 'cli' else 225)
    assert all(sum(key(row['path']) == old for row in inputs) == 1 for old in replacements)
    inputs = [replacements.get(key(row['path']), row) for row in inputs]
    for row in inputs: exact(row)
    image = W / 'bin' / ('hyle-attention-budget.exe' if name == 'cli' else 'attention-budget-test.exe')
    image.parent.mkdir(parents=True, exist_ok=True); assert not image.exists()
    command = []
    for arg in read(base['recipe']['path'])['command']:
        if key(arg) in replacements: arg = replacements[key(arg)]['path']
        for option, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(option): arg = option + str(image.with_suffix(suffix)); break
        command.append(arg)
    save(W / (name + '-link-inputs.json'), inputs)
    process = b.b.b.h.execute(command, environment(), W / ('link-' + name), timeout=180)
    save(W / ('ready-' + name + '.json'), dict(status='LINKED_NOT_RUN', image=pin(image), compiled=compiled,
        inputs=pin(W / (name + '-link-inputs.json')), recipe=pin(W / ('link-' + name) / 'command.json'),
        runtime=pin(W / 'runtime-plan.json'), frozen=pin(W / 'frozen.json'), process=process))
    print('LINK_PASS', name)


def run_component():
    validate(); ready = read(W / 'ready-component.json'); exact(ready['image'])
    report = W / 'run-component/results.xml'
    command = [ready['image']['path'], '--gtest_filter=' + FILTER, '--gtest_fail_fast', '--gtest_output=xml:' + str(report)]
    process = b.b.b.h.execute(command, environment(), W / 'run-component', timeout=180)
    xml = ET.parse(report).getroot(); assert int(xml.attrib['tests']) == 1 and int(xml.attrib['failures']) == 0
    text = (W / 'run-component/stdout.log').read_text(encoding='utf-8-sig')
    assert len(re.findall(r'^stable_attention slot=', text, re.M)) == 100
    save(W / 'component-summary.json', dict(status='PASS', process=process, image=ready['image'], executions=100,
        xml=pin(report), scope='Original96 executions plus small float-cap127/128/129 and explicit fresh; same full FP64/tail/guard oracle.'))
    print('PASS one Graph group /100 executions')


def model_sanity():
    validate(); ready = read(W / 'ready-cli.json'); exact(ready['image'])
    previous = BASE / 'model-checks/two-turn-auto'
    command = [ready['image']['path'], *read(previous / 'command.json')['command'][1:]]
    process = b.b.b.h.execute(command, environment(), W / 'model-two-turn', timeout=180)
    spec = importlib.util.spec_from_file_location('previous_attention_model_compare', BASE / 'model_check.py')
    checks = importlib.util.module_from_spec(spec); spec.loader.exec_module(checks)
    differences = checks.prior.changed(checks.prior.facts.non_time(read(previous / 'stdout.log')),
                                       checks.prior.facts.non_time(read(W / 'model-two-turn/stdout.log')))
    save(W / 'model-two-turn/differences.json', differences)
    assert not differences, differences[:8]
    save(W / 'model-two-turn/summary.json', dict(status='PASS_COMPLETE_NON_TIME', process=process, image=ready['image'],
        previous=pin(previous / 'stdout.log'), differences=differences, performance_claim=False))
    print('PASS one natural two-turn sanity, not a new performance sample')


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'freeze': freeze()
        elif action == 'compile': compile_unit(sys.argv[2])
        elif action == 'link': link(sys.argv[2])
        elif action == 'run-component': run_component()
        elif action == 'model-sanity': model_sanity()
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True, exist_ok=True)
        (W / ('failure-' + '-'.join(sys.argv[1:3]) + '-' + str(time.time_ns()) + '.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
