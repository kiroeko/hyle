"""Preserve the finite original-Q24 KV check, its inputs and its limits."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = R / 'docs/evidence/correctness/qwen24-original-mtp-kv-2026-10-22.json'
ZIP = OUT.with_suffix('.logs.zip')

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

assert not OUT.exists() and not ZIP.exists()
checks = read(S / 'checks1/summary.json')
assert checks['tests'] == 2 and checks['process']['exit'] == 0
assert not checks['process']['timed_out']
assert not any(checks[k] for k in ('failures', 'errors', 'disabled', 'skips'))
assert all(c['properties']['actual_submissions'] == '3' for c in checks['cases'])
assert identity(checks['image']['path'])['sha256'] == checks['image']['sha256']
acquisition = read(S / 'original-q24/acquisition.json')
assert acquisition['complete'] and len(acquisition['roles']) == 3
assert sum(r['payload']['bytes'] for r in acquisition['roles']) == 11_535_360
for role in acquisition['roles']:
    assert identity(role['payload']['path'])['sha256'] == role['payload']['sha256']
assert acquisition['sources']['first']['metadata_only']
cleanup = read(S / 'cleanup-result.json')
assert cleanup['CurrentImageRetained'] and cleanup['CurrentMapRetained']
assert cleanup['Bytes'] == 602_693_640
assert all(not Path(e['path']).exists() for e in cleanup['Removed'])
files = [
    'tests/compute_models/qwen24_original_mtp_kv_test.cc',
    'tests/compute_models/original_role_input.h',
    'tests/graph_route_cpu/CMakeLists.txt',
    'tests/graph_route_cuda/CMakeLists.txt',
    'docs/developer/current-work.md',
    'docs/implementation/model-operators.md',
    'docs/evidence/planning/current-work-through-2026-10-22-ay.md',
]
for name in files:
    dest = S / 'source-current' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((R / name).read_bytes())
assert identity(R / files[0])['sha256'] == '763ad127a74968b1d91e3bbe9db2cec36beab110ea4f2d94addecf08a3dacedc'
(S / 'cleanup-script.ps1').write_bytes((R / 'test.ps1').read_bytes())
observations = []
backend = None
for line in (S / 'checks1/stdout.log').read_text(encoding='utf-8').splitlines():
    if '[ RUN ' in line:
        backend = 'CUDA' if '.Cuda' in line else 'CPU'
    m = re.search(r'Q24 original Q5_K (.+) maxAbs=([\deE.+-]+) rmse=([\deE.+-]+)', line)
    if m:
        observations.append(dict(backend=backend, reference=m[1],
            max_absolute_error=float(m[2]), RMSE=float(m[3])))
assert len(observations) == 18
report = dict(
    date='2026-10-22', status='ORIGINAL_Q24_SINGLE_LAYER_KV_PREFIX_AND_CONTINUATION_PASS',
    goal_complete=False, changes=[identity(R / n) for n in files],
    final_checks=checks, actual_graph_submissions=6, original_roles=acquisition,
    original_role_import=dict(
        parser='Existing cached @huggingface/gguf parser applied to authenticated local prefixes; no parser network.',
        architecture='qwen35moe; primary UD-IQ4_XS blk92 NextN K/V Q5_K and K-norm F32.',
        metadata='H8192, KVheads4, key/value256, RoPE64, sections11/11/10/0, theta10000000, epsilon1e-6F.',
        first_file='Verified24B zero-tensor format first, then exact10943296B metadata-only first shard. This is not a full weight shard.',
        last_file='Parsed52 tensors and data base3456 from exact2MB prefix of shard29; each role fetched by its own exact HTTP206 physical range.',
        acquisition_corrections='Initial12MB first-prefix requests were EOF-clamped and refused before payload. Verified zero-tensor metadata size then fetched exact range. Initial qwen35 assertion refused before roles; actual source architecture is qwen35moe. Receipts preserve these failures.',
        whole_weight_shard_download=False),
    graph=dict(
        input='F32 already-attention-normalized H boundary; original packed K/V -> reshape[1,T,4,256]; K RMSNorm with original gamma -> HalfSplit RoPE64, V reshape only.',
        text_positions='Text MRoPE axes share positions; this finite case uses their equivalent HalfSplit RoPE. Nonrotary192F32/head bytes unchanged relative to K-normalized output.',
        constant_binding='Each backend binds the three original roles once. Actual execution stays packed Q5_K, with no expanded weight bank.',
        reference='Independent FP64 Neumaier dot after row-wise baseGGML Q5_K decode; independent F64 norm/RoPE equation. Oracle-only one-row decode; no ggml_cpu_init requirement in CUDA-only tests.',
        numerical_gates='Existing F32 norm3e-5 abs+2e-5 rel and RoPE8e-5 abs+4e-5 rel, plus existing normalized quantized-chain gate, unchanged. CPU Q8_K and CUDA Q8_1 activation quantization need not be byte-equal.',
        numerical_observations=observations),
    state=dict(
        layout='Finite cap6 F32 K/V banks plus8B valid_rows/next_position; initial valid2/position37 with NaN-tagged unused tails.',
        journey='Actual T2(H0@37,H1@38), artificial selector accepts prefix1 onlyH0; atomically publish complete K/V/position. Actual accepted head then supplies banks and position for T1(freshH2@38), publish valid4/position39. Retained old base separately replays original T2 Invocation withH0/H2.',
        checks='Compare accepted-prefix continuation with old-base full branch; H1 rejected row never published. Earlier rows/tails remain byte-exact; only the fresh H2 cross-shape row uses finite existing F32 gate. Old base/selected/continued/results and original role bytes remain unchanged.',
        atomicity='Wrong V extent after staging K, draft cancel, and stale prefix2 CAS after prefix1 must leave actual head unchanged. Read leases stay read-only.',
        budget='Output pool22blocks/320KiB including10complete finite KV banks; initial base48KiB separate, StateStore512KiB. Final state versions/drafts and active pool uses/blocks return to0.',
        serving_cache=False, complete_model_state=False, natural_acceptance=False),
    build=dict(
        scope='One new host C++ test TU, incrementally compiled and linked against existing matched CPU/CUDA closure; no SDK/NVCC/shader/full-tree build.',
        CMake='CPU and CUDA targets register the same source with independent HYLE_TEST_Q24_CPU/CUDA guards. Dedicated full CMake configurations were source-reviewed, not rebuilt.',
        cache='Preserved AY fixed CPU-provider capability, CPU public compile and native CPU program ABI2 closure. No provider gate, production math or public API changed.',
        compile=read(S / 'compile1/q24-kv/compile.result.json'),
        link=read(S / 'tests-link1/link.result.json')),
    remaining_scope_review=identity(S / 'review/remaining-mtp.json'),
    cleanup=cleanup,
    limits=[
        'Windows CPU/CUDA one-layer KV component only; no complete original Q24 target/draft, natural proposal/acceptance, MLA or conv/GDN state claim.',
        'Normalized H is supplied at the declared boundary; this check does not execute the preceding original NextN input component or following full attention/MLP/head.',
        'No new TPS or physical GPU/CPU memory measurement. AV remains latest full four-arm performance window.',
        'GLM actual index-carry source is in progress and uncompiled; its review/glm-carry-source subtree is deliberately excluded from this archive.',
        'Other applicable original roles/codecs and complete model-specific state compositions remain incomplete; no new shared executor/API has been justified by this finite review.',
    ],
    next='Close GLM same-iteration actual index-output lease -> skip-indexer consumer -> atomic state publication, then applicable original E4+F32-scale and DSpark stage/LM/target-hidden bindings.',
)
save(S / 'report-before-archive.json', report)
allowed = {'.json', '.py', '.mjs', '.cc', '.h', '.cuh', '.md', '.diff', '.log', '.xml', '.txt', '.ps1'}
selected = [p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in allowed
            and '__pycache__' not in p.parts and 'glm-carry-source' not in p.parts]
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(selected):
        archive.write(path, path.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
report['sources_commands_results_and_cleanup'] = identity(ZIP)
report['large_original_payloads_archived'] = False
save(OUT, report)
receipt = dict(result=identity(OUT), logs=identity(ZIP), goal_complete=False)
save(S / 'publication-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
