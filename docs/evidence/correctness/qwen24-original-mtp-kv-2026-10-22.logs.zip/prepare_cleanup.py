"""Retire old executable copies; keep their sources, objects, commands and data."""
from pathlib import Path
import hashlib
import json
S=Path(__file__).resolve().parent;R=S.parents[1]
old=[
    R/'.scratch/dspark-mtp-integration-20261022/tests-link9/dspark-checks.exe',
    R/'.scratch/dspark-natural-journey-20261022/tests-link4/mtp-checks.exe',
    R/'.scratch/qwen-original-mtp-20261022/tests-link3/qwen-mtp-checks.exe',
]
entries=[]
for image in old:
    for path in [image,image.with_suffix('.map')]:
        raw=path.read_bytes()
        entries.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
plan=dict(keep=str(S/'tests-link1'),allowed_parents=[str(p.parent) for p in old],
    entries=entries,bytes=sum(p['bytes'] for p in entries),
    retained='All corresponding source snapshots, object/native inputs, exact link plans, commands, logs and original role data remain; the Qwen AV performance image is untouched.')
(S/'cleanup-plan.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
script=r'''$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/qwen24-original-mtp-20261022').Path
$scratchRoot = (Resolve-Path -LiteralPath '.scratch').Path
$scratchPrefix = $scratchRoot.TrimEnd('\') + '\'
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$keep = [System.IO.Path]::GetFullPath($plan.keep)
$allowed = @($plan.allowed_parents | ForEach-Object { [System.IO.Path]::GetFullPath($_) })
foreach ($parent in $allowed) {
    if (-not $parent.StartsWith($scratchPrefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace scratch: $parent" }
    if ($parent -eq $keep) { throw 'Current image directory is protected' }
}
$targets = @($plan.entries)
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $targets) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if ((Split-Path -Parent $target) -notin $allowed) { throw "Outside exact old image directories: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe','.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
if (-not (Test-Path -LiteralPath (Join-Path $keep 'qwen24-kv-checks.exe') -PathType Leaf)) { throw 'Final image missing' }
foreach ($entry in $targets) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = $targets
    Bytes = $plan.bytes
    CurrentImageRetained = (Test-Path -LiteralPath (Join-Path $keep 'qwen24-kv-checks.exe'))
    CurrentMapRetained = (Test-Path -LiteralPath (Join-Path $keep 'qwen24-kv-checks.map'))
    PriorReproductionInputsRetained = $plan.retained
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object Bytes, CurrentImageRetained, CurrentMapRetained
'''
(R/'test.ps1').write_text(script,encoding='utf-8')
print(json.dumps(plan,indent=2))
