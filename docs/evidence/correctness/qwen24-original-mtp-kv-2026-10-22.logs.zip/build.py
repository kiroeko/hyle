"""Two related native consumers on the matched AY CPU/CUDA closure."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=S.parents[1]
AY=R/'.scratch/qwen-original-mtp-20261022'
spec=importlib.util.spec_from_file_location('az_cached',AY/'build.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
b,c,h=a.b,a.c,a.h
h.S=S
BASE=AY/'tests-link3'
SOURCE=R/'tests/compute_models/qwen24_original_mtp_kv_test.cc'

def compile_one(attempt):
    old=c.read(AY/'compile2/q27/identity.json')
    old['command']=[x for x in old['command'] if not x.startswith('/DHYLE_TEST_Q27_')]
    old['command']+=['/DHYLE_TEST_Q24_CPU=1','/DHYLE_TEST_Q24_CUDA=1']
    recipe=S/'recipes'/'q24-kv.json'
    recipe.parent.mkdir(parents=True,exist_ok=True)
    c.save(recipe,old)
    h.RECIPES['q24-kv'],h.SOURCES['q24-kv']=recipe,SOURCE
    h.compile_one('q24-kv',attempt)

def link(attempt):
    records=sorted(S.glob('compile*/q24-kv/identity.json'),key=lambda p:int(p.parents[1].name[7:]))
    assert records
    record_path=records[-1];record=c.read(record_path)
    assert all(b.identity(x['path'])==x for x in [record['source'],record['object'],*record['dependencies']])
    base=c.read(BASE/'link-plan.json')
    remove=set()
    for item in base['compiled_records']:
        rec=c.read(item['path'])
        if '/tests/' in rec['source']['path'].replace('\\','/'):remove.add(c.key(rec['object']['path']))
    inputs=[record['object']]+[x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path'])==x for x in inputs)
    command=[x for x in base['command'] if c.key(x) not in remove and
             not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    command.insert(1,record['object']['path'])
    folder=S/f'tests-link{attempt}';folder.mkdir();(folder/'tmp').mkdir()
    image=folder/'qwen24-kv-checks.exe'
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(folder/'link-plan.json',dict(command=command,inputs=inputs,compiled_records=[b.identity(record_path)],
        base=b.identity(BASE/'link-plan.json'),SDK_builds=0,NVCC_builds=0,shader_builds=0))
    env,_=b.environment(command,[x['path'] for x in inputs],folder)
    c.execute('link',command,env,folder)
    runtime=c.read(BASE/'runtime-environment.json')
    for item in runtime['staged_dlls']:os.link(item['path'],folder/Path(item['path']).name)
    runtime['staged_dlls']=[b.identity(path) for path in folder.glob('*.dll')]
    c.save(folder/'runtime-environment.json',runtime)
    c.save(folder/'ready.json',dict(image=b.identity(image)))
    print('LINKED',image,flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('actions',nargs='+',choices=['compile','link'])
    parser.add_argument('--attempt',type=int,default=1)
    args=parser.parse_args()
    for action in args.actions:
        if action=='compile':compile_one(args.attempt)
        else:link(args.attempt)
