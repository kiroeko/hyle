import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import {gguf,GGMLQuantizationType} from '../hf-gguf-tools/node_modules/@huggingface/gguf/dist/index.mjs';
const folder='.scratch/qwen24-original-mtp-20261022/original-q24';
const acquisition=JSON.parse(await fs.readFile(`${folder}/acquisition.json`,'utf8'));
for(const tag of ['first','last']){
 const source=acquisition.sources[tag];
 const raw=await fs.readFile(`${folder}/${tag}-header-prefix.bin`);
 if(raw.length!==source.prefix.bytes || crypto.createHash('sha256').update(raw).digest('hex')!==source.prefix.sha256)throw new Error('Prefix identity differs');
 const parsed=await gguf(source.url,{fetch:async(_url,options={})=>{
  const range=new Headers(options.headers).get('range');
  const match=/^bytes=(\d+)-(\d+)$/.exec(range||'');
  if(!match)throw new Error(`Unbounded parser request: ${range}`);
  const first=Number(match[1]),last=Number(match[2]);
  if(first>last || first>=raw.length)throw new Error('Parser exceeds exact acquired prefix');
  if(last>=raw.length && !source.metadata_only)throw new Error('Parser exceeds actual weight-file prefix');
  const end=Math.min(last,raw.length-1);
  return new Response(raw.subarray(first,end+1),{status:206,headers:{
    'content-range':`bytes ${first}-${end}/${source.file_bytes}`,'content-length':String(end-first+1)}});
 }});
 if(BigInt(parsed.tensorDataOffset)>BigInt(raw.length))throw new Error('Header exceeds real prefix');
 const tensors=parsed.tensorInfos.map(t=>({name:t.name,shape:t.shape,dtype:GGMLQuantizationType[t.dtype],dtype_code:t.dtype,offset:t.offset}));
 const value={repository:acquisition.repository,revision:acquisition.revision,file:source.file,
  tensor_count:tensors.length,tensor_data_offset:parsed.tensorDataOffset,
  metadata:Object.fromEntries(Object.entries(parsed.metadata).filter(([key])=>!key.startsWith('tokenizer.'))),tensors,
  parser:'Existing @huggingface/gguf, authenticated local prefix only; no parser network access'};
 await fs.writeFile(`${folder}/${tag}-header.json`,JSON.stringify(value,(_key,v)=>typeof v==='bigint'?String(v):v,2)+'\n');
 console.log(tag,'tensors',tensors.length,'data base',String(parsed.tensorDataOffset));
 console.log(tensors.filter(t=>['blk.92.attn_k.weight','blk.92.attn_v.weight','blk.92.attn_k_norm.weight'].includes(t.name)));
}
