"""Read fixed GGUF headers and only the three complete original NextN KV roles."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import struct
import urllib.request

S=Path(__file__).resolve().parent
F=S/'original-q24'
REPOSITORY='unsloth/Qwen3.8-2.4T-A95B-GGUF'
REVISION='567d3e6ac26c5474b18311e619c04350fb9a5556'
FILES={tag:f'UD-IQ4_XS/Qwen3.8-2.4T-A95B-UD-IQ4_XS-{index:05d}-of-00029.gguf'
       for tag,index in [('first',1),('last',29)]}

def save():
    (F/'acquisition.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')

def fetch(tag,first,count,path):
    source=receipt['sources'][tag]
    last=first+count-1
    item=dict(source=tag,first=first,last=last,bytes=count,complete=False)
    receipt['requests'].append(item);save()
    request=urllib.request.Request(source['url'],headers={
        'Range':f'bytes={first}-{last}','Accept-Encoding':'identity',
        'User-Agent':'hyle-original-nextn-kv/1'})
    with urllib.request.urlopen(request,timeout=45) as response:
        value=response.headers.get('Content-Range','')
        match=re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)',value)
        item.update(http_status=response.status,content_range=value,
                    etag=response.headers.get('ETag'),content_length=response.headers.get('Content-Length'))
        save()
        assert response.status==206 and match and (int(match[1]),int(match[2]))==(first,last), \
            f'Refuse whole file or mismatched range before reading body: status={response.status} range={value}'
        total=int(match[3]);etag=response.headers.get('ETag')
        if 'file_bytes' in source:assert total==source['file_bytes'] and etag==source['etag']
        source.update(file_bytes=total,etag=etag)
        length=response.headers.get('Content-Length')
        assert length is None or int(length)==count
        item.update(http_status=response.status,content_range=value,etag=etag)
        digest,remaining=hashlib.sha256(),count
        with path.open('xb') as output:
            while remaining:
                part=response.read(min(1<<20,remaining))
                assert part,'Truncated exact role/header range'
                output.write(part);digest.update(part);remaining-=len(part)
            assert not response.read(1),'Response exceeds exact range'
    item.update(complete=True,path=str(path),sha256=digest.hexdigest());save()
    return dict(path=str(path),bytes=count,sha256=item['sha256'])

parser=argparse.ArgumentParser()
parser.add_argument('action',choices=['headers','first-header','roles'])
args=parser.parse_args()
if args.action=='headers':
    F.mkdir(parents=True,exist_ok=False)
    receipt=dict(repository=REPOSITORY,revision=REVISION,variant='UD-IQ4_XS',
        sources={tag:dict(file=name,url=f'https://huggingface.co/{REPOSITORY}/resolve/{REVISION}/{name}')
                 for tag,name in FILES.items()},
        whole_weight_shard_download_allowed=False,requests=[],roles=[],complete=False)
    for tag,count in [('last',2_000_000),('first',12_000_000)]:
        receipt['sources'][tag]['prefix']=fetch(tag,0,count,F/f'{tag}-header-prefix.bin')
        save();print('HEADER',tag,receipt['sources'][tag]['prefix'],flush=True)
elif args.action=='first-header':
    receipt=json.loads((F/'acquisition.json').read_text(encoding='utf-8'))
    assert 'prefix' not in receipt['sources']['first']
    receipt.pop('whole_file_download_allowed',None)
    receipt['whole_weight_shard_download_allowed']=False
    if '?' not in receipt['sources']['first']['url']:
        receipt['sources']['first']['url'] += '?download=true'
    if not (F/'first-format.bin').exists():
        receipt['sources']['first']['format']=fetch('first',0,24,F/'first-format.bin')
    magic,version,tensors,metadata=struct.unpack('<4sIQQ',(F/'first-format.bin').read_bytes())
    assert magic==b'GGUF' and version==3 and tensors==0, 'Only a verified metadata-only first file may be read whole'
    size=receipt['sources']['first']['file_bytes']
    assert 24<=size<=12_000_000
    receipt['sources']['first']['metadata_only']=True
    receipt['sources']['first']['prefix']=fetch('first',0,size,F/'first-header-prefix.bin')
    save();print('HEADER first',receipt['sources']['first']['prefix'],flush=True)
else:
    receipt=json.loads((F/'acquisition.json').read_text(encoding='utf-8'))
    assert receipt['revision']==REVISION and not receipt['roles']
    first=json.loads((F/'first-header.json').read_text(encoding='utf-8'))
    header=json.loads((F/'last-header.json').read_text(encoding='utf-8'))
    assert first['revision']==header['revision']==REVISION
    meta=first['metadata']
    assert meta['general.architecture']=='qwen35moe' and int(meta['qwen35moe.embedding_length'])==8192
    assert int(meta['split.count'])==29 and int(header['metadata']['split.no'])==28
    receipt['model_metadata']={key:value for key,value in meta.items() if key.startswith('qwen35moe.')}
    specifications=[
        ('blk.92.attn_k.weight',[8192,1024],'Q5_K',5_767_168,'attn_k.weight.q5_k'),
        ('blk.92.attn_v.weight',[8192,1024],'Q5_K',5_767_168,'attn_v.weight.q5_k'),
        ('blk.92.attn_k_norm.weight',[256],'F32',1024,'attn_k_norm.weight.f32'),
    ]
    for name,shape,codec,count,local in specifications:
        tensor=next(t for t in header['tensors'] if t['name']==name)
        assert list(map(int,tensor['shape']))==shape and tensor['dtype']==codec
        offset=int(tensor['offset']);base=int(header['tensor_data_offset'])
        following=[int(t['offset']) for t in header['tensors'] if int(t['offset'])>offset]
        assert not following or offset+count<=min(following)
        assert base+offset+count<=receipt['sources']['last']['file_bytes']
        payload=fetch('last',base+offset,count,F/local)
        receipt['roles'].append(dict(name=name,dtype=codec,GGUF_shape=shape,
            tensor_data_offset=base,relative_offset=offset,absolute_start=base+offset,payload=payload))
        save();print(name,payload,flush=True)
    receipt['complete']=True;save()
