"""Retire superseded executable names after this round's final pass."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
R = S.parents[1]
selection = json.loads((S / 'final-checks.json').read_text(encoding='utf-8'))
summary = json.loads((S / selection['summary']).read_text(encoding='utf-8'))
assert summary['tests'] == selection['tests'] and summary['process']['exit'] == 0
assert not any(summary[k] for k in ('failures', 'errors', 'disabled', 'skips'))
keep = Path(summary['image']['path'])
assert hashlib.sha256(keep.read_bytes()).hexdigest() == summary['image']['sha256']
parents = [R / '.scratch/glm-mtp-catchup-20261022/tests-link5']
parents += [p for p in sorted(S.glob('tests-link*')) if p.is_dir() and p != keep.parent]
entries, groups = [], {}
for parent in parents:
    assert parent.resolve().is_relative_to(R / '.scratch') and parent != keep.parent
    for path in sorted(parent.iterdir()):
        if path.suffix not in ('.exe', '.map'):
            continue
        raw = path.read_bytes()
        st = path.stat()
        item = dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                    file_id=st.st_ino, device=st.st_dev, links=st.st_nlink)
        entries.append(item)
        groups.setdefault((st.st_dev, st.st_ino), []).append(item)
assert entries
protected = [keep, keep.with_suffix('.map'), R / '.scratch/qwen-mtp-next-20261022/hyle-link4/qwen.exe']
assert all(p.is_file() for p in protected)
plan = dict(allowed_parents=[str(p) for p in parents], entries=entries,
    removed_path_bytes=sum(x['bytes'] for x in entries),
    known_reclaimable_unique_bytes=sum(x[0]['bytes'] for x in groups.values() if len(x) == x[0]['links']),
    protected=[str(p) for p in protected],
    retained='Final executable/map, all source/object/SDK/link inputs and corrected CPU worker DLLs, original roles, AV performance image.',
    hardlink_note='Only unique file IDs with all known links selected count as reclaimable.')
(S / 'cleanup-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
(S / 'prior-test.ps1').write_bytes((R / 'test.ps1').read_bytes())
script = r'''$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/glm-mtp-seed-cache-20261022').Path
$scratchPrefix = (Resolve-Path -LiteralPath '.scratch').Path.TrimEnd('\') + '\'
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$allowed = @($plan.allowed_parents | ForEach-Object { (Resolve-Path -LiteralPath $_).Path })
foreach ($parent in $allowed) {
    if (-not $parent.StartsWith($scratchPrefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace scratch: $parent" }
}
foreach ($keep in $plan.protected) {
    if (-not (Test-Path -LiteralPath $keep -PathType Leaf)) { throw "Protected input missing: $keep" }
}
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $plan.entries) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if ((Split-Path -Parent $target) -notin $allowed -or $target -in $plan.protected) { throw "Unplanned target: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe','.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
foreach ($entry in $plan.entries) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = @($plan.entries)
    RemovedPathBytes = $plan.removed_path_bytes
    KnownReclaimableUniqueBytes = $plan.known_reclaimable_unique_bytes
    ProtectedInputsRetained = @($plan.protected | ForEach-Object { Test-Path -LiteralPath $_ })
    Retained = $plan.retained
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object RemovedPathBytes, KnownReclaimableUniqueBytes, ProtectedInputsRetained
'''
(R / 'test.ps1').write_text(script, encoding='utf-8', newline='\r\n')
print(json.dumps(dict(files=len(entries), paths=[x['path'] for x in entries],
    removed_path_bytes=plan['removed_path_bytes'], known_reclaimable_unique_bytes=plan['known_reclaimable_unique_bytes']), indent=2))
