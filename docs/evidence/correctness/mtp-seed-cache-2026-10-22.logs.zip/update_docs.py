"""Update the existing two scope docs only after finite native success."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
R = S.parents[1]
selection = json.loads((S / 'final-checks.json').read_text(encoding='utf-8'))
checks = json.loads((S / selection['summary']).read_text(encoding='utf-8'))
assert checks['process']['exit'] == 0 and checks['tests'] == selection['tests']
assert not any(checks[k] for k in ('failures', 'errors', 'disabled', 'skips'))
count = checks['tests']
graphs = sum(int(x['properties']['actual_submissions']) for x in checks['cases'])
path = R / 'docs/developer/current-work.md'
old = path.read_text(encoding='utf-8')
performance = old[old.index('## 最新完整性能对比'):]
replacements = [
('更新：**2026-10-22**。进入“实际推理驱动的性能、功能与架构收敛”阶段。',
 '更新：**2026-10-23**。进入“实际推理驱动的性能、功能与架构收敛”阶段。'),
('本轮源审未证明必须增加新的公共MTP算子或状态API。typed dtype／量化、冷导入、GDN／KDA快照、页权限、租约和StateHead已有；真实用例暴露的合同或实现错误仍须修，不重复造执行器、加载框架或缓存管理器',
 '确认一项实际缺口：GLM默认ue8m0 reader需要动态E4量化独立输出codes＋F32 scales。现有FP8线性内部已有power-of-two scale数学，但未暴露压缩缓存输出；须复用该合同补两输出原语。其余状态、页权限、租约与StateHead继续共用，不重复造执行器／缓存管理器'),
('GLM原7角色query链及FP8修复保留；DSpark正式Flash Q8 sidecar的原fc／norm／stage0 KV／KV norm四角色55,724,032B已CPU／CUDA执行。继续补其余stage／共享LM、GLM／Q27／Q24适用角色和已确认MTP量化的冷供给；GLM官方缓存的BF16／Hadamard／E4＋F32 scale及匹配query／scorer仍须接，不能用GGUF F32缓存代签',
 'GLM原7角色query链及FP8修复保留；DSpark正式Flash Q8 sidecar的fc／norm及三stage KV／norm共八原角色60,184,576B已CPU／CUDA执行。GLM合法scale_fmt=None的E4＋逐行F32 scale、匹配query／scorer→TopK→MLA组件已接；默认ue8m0须先补两输出量化，再并入完整NextN／target状态。继续共享LM、GLM／Q27／Q24适用角色及已确认MTP量化冷供给，不用F32缓存代签原codec'),
('GLM实际nx进入有界接受记录，跨轮只追赶接受的skip并fresh重选；末层44的KDA／conv／双mHC／FFN／final-norm tap与NextN共20资源＋epoch已在同一Head原子选择、发布和续算，CPU／CUDA有限检查通过。正常draft-extend末接受位置的seed→下一轮step0直接skip、target43 MLA／index历史→44的实际组合仍待接。Q27／Q24完整组合、DSpark各stage真实参数的verified-main历史仍待接',
 'GLM有界接受记录、跨轮追赶、target44＋NextN同Head组合已有；正常draft-extend末接受位置的真实hidden／完整IDs→下一轮step0直接skip本轮也通过。target43 MLA／index历史→44、官方codec并入完整NextN及Q27／Q24完整组合仍待接。DSpark三stage实际编码main ring／前缀选择／后继attention已接，完整draft状态与main历史组合、真实target taps及共享LM仍待接'),
('下一步补GLM正常draft-extend seed旅程、官方缓存／query／scorer及必要target层间状态组合，继续DSpark各原stage／共享LM与真实target taps、Q27／Q24适用角色和已确认MTP量化；最后做必要回归和普通／MTP完整对照，再进入图片。',
 '下一步补独立动态FP8量化输出，接GLM默认ue8m0 cache及完整NextN、target43→44实际状态组合；把DSpark三stage原main历史与完整draft状态、真实target taps／共享LM组合，继续Q27／Q24适用角色及已确认MTP量化。最后做必要回归和普通／MTP完整对照，再进入图片。'),
('**GLM-Flash**：[本轮组合与原角色](../evidence/correctness/mtp-target-state-2026-10-22.json)最终10项检查、130次Graph全部通过，其中6项GLM：每端原单轮7次、跨轮追赶14次、target＋NextN组合26次。实际nx接受记录、split cursor、末层KDA／conv／完整mHC／FFN及正确final-norm tap均沿实际租约；partial／all接受、新epoch、独立base重算、旧版本、取消与stale提交通过。上层4H仍生成、未跑45层原模型，官方cache及正常draft-extend seed旅程仍待接。CPU首跑失败来自验证closure的旧constructor／新HC_PRE reader合同混用，已定点匹配原生实现；同一EXE复跑通过，原数值门不变。原输入与FP8修复见[前批证据](../evidence/correctness/glm-mtp-state-2026-10-22.json)。',
 f'**GLM-Flash**：[本轮正常seed与编码缓存](../evidence/correctness/mtp-seed-cache-2026-10-22.json)GLM／DSpark合计{count}项CPU／CUDA检查、{graphs}次Graph，零失败／零跳过。GLM新增每端24次正常seed旅程和12次编码cache旅程：实际draft-extend末接受版本直接交接hidden／完整IDs，step0跳过整个indexer；cache实际持久E4＋逐行F32 scale，经匹配query／scorer→TopK512展开2048 IDs→MLA，接受A／拒B／续C与独立base重算通过。codec限固定06992的合法scale_fmt=None及完整K4池块，未代签vendor页ABI；固定构造默认为ue8m0，仍须补独立量化输出和对应取整scale。此前[20资源target44＋NextN组合](../evidence/correctness/mtp-target-state-2026-10-22.json)保留；target43、默认codec与完整NextN组合及原45层模型仍未完成。复用已匹配HC_PRE的CPU worker，本轮未重编原生SDK；原输入与FP8修复见[前批证据](../evidence/correctness/glm-mtp-state-2026-10-22.json)。'),
('**DSpark**：本轮原fc／norm／stage0 wkv／KV norm四角色55,724,032B，在CPU／CUDA各三代9次Graph，实际HC输出→原投影／norm→实际main_x→原512维KV投影／norm；独立逐行Q8解码／FP64参考、零输入、旧结果及只读权重均核。它止于pre-RoPE，HC仍生成，未代签真实target captures、三stage rings或共享LM；[此前自然旅程](../evidence/correctness/mtp-natural-journey-2026-10-22.json)四轮均拒绝proposal，也不代表原模型接受率。',
 '**DSpark**：[本轮](../evidence/correctness/mtp-seed-cache-2026-10-22.json)补齐三stage各自原wkv／norm，连同fc／norm共八角色60,184,576B。实际main投影租约→三stage KV／norm→显式BF16边界／末64维RoPE→真实584B编码ring，接受前缀与后继decode／attention沿同Head和实际租约；保旧分支及独立数值参考。上游仍为所选Q8／F32计算，未代签原BF16权重完整等价、训练target captures、完整draft状态／共享LM或自然接受率。此前生成参数[自然旅程](../evidence/correctness/mtp-natural-journey-2026-10-22.json)不代替这些原角色接线。'),
('当前优先；GLM跨轮追赶／末target层＋NextN组合、DSpark原四角色均已CPU／CUDA通过。继续正常seed／官方cache及剩余实际角色／状态，再做完整性能对照；有限组件不代签全部制品',
 '当前优先；正常GLM seed交接、官方cache/scorer组件、DSpark三stage原main编码历史已CPU／CUDA核。继续完整状态组合和适用角色，再做完整性能对照；有限组件不代签全部制品'),
]
text = old
for before, after in replacements:
    assert text.count(before) == 1, before[:100]
    text = text.replace(before, after)
assert text[text.index('## 最新完整性能对比'):] == performance
before_folder = S / 'docs-before'
before_folder.mkdir(exist_ok=False)
(before_folder / path.name).write_text(old, encoding='utf-8')
path.write_text(text, encoding='utf-8')
model = R / 'docs/implementation/model-operators.md'
old_model = model.read_text(encoding='utf-8')
before = 'K4窗口／尾部及接受记录成套保留；NextN跨轮追赶与末target44层组合共20资源／epoch已CPU／CUDA核，正常draft-extend seed／官方cache和其余target状态仍待接'
after = 'K4窗口／尾部及接受记录成套保留；20资源target44＋NextN组合、正常draft-extend seed交接已核；本轮合法scale_fmt=None cache／scorer→TopK→MLA组件CPU／CUDA通过；默认ue8m0的两输出量化及完整NextN／target43组合仍待接'
assert old_model.count(before) == 1
new_model = old_model.replace(before, after)
before = '已有ratio4／128完整接受前缀及投影target的两轮自然拒绝续算；原43层target未运行；适用原角色／codec与完整状态组合尚待核'
after = '已有ratio4／128接受前缀；本轮DSpark八原角色、三stage main编码ring及实际decode／attention后继CPU／CUDA通过；原43层target未运行，完整draft／main状态及共享LM组合仍待核'
assert new_model.count(before) == 1
new_model = new_model.replace(before, after)
(before_folder / model.name).write_text(old_model, encoding='utf-8')
model.write_text(new_model, encoding='utf-8')
result = dict(tests=count, actual_Graph_submissions=graphs,
    performance_section_unchanged=True,
    performance_utf8_sha256=hashlib.sha256(performance.encode('utf-8')).hexdigest(),
    performance_latest_window='AV; no new throughput or physical-memory measurement',
    remaining='Actual full-state composition and applicable role/codec supply remain, then final performance; images afterward.')
(S / 'docs-update.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
