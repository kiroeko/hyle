"""Compile only this round's consumers; retain the matched native closure."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BC = R / '.scratch/glm-mtp-catchup-20261022'
BB = R / '.scratch/glm-mtp-state-20261022'
spec = importlib.util.spec_from_file_location('seed_cached', BC / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = BC / 'tests-link5'
SOURCES = {
    'glm-state': R / 'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'glm-cache': R / 'tests/compute_models/glm_official_index_cache_test.cc',
    'dspark-history': R / 'tests/compute_models/dspark_main_history_test.cc',
    'dspark-target': R / 'tests/compute_models/dspark_target_binding_test.cc',
    'tensor-program': R / 'src/compute_provider_ggml_cuda/tensor_program.cc',
    'ggml-provider': R / 'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
}
MACROS = {'glm-state': 'GLM_STATE', 'glm-cache': 'GLM_CACHE',
          'dspark-history': 'DSPARK_HISTORY', 'dspark-target': 'DSPARK_TARGET'}
EXTRA_RECIPES = {name: R / ('.scratch/qwen-mtp-next-20261022/compile3/' + name + '/identity.json')
                 for name in ('tensor-program', 'ggml-provider')}


def compile_one(name, attempt):
    old = c.read(EXTRA_RECIPES[name] if name in EXTRA_RECIPES else BB / 'compile2/glm-state/identity.json')
    if name not in EXTRA_RECIPES:
        old['command'] = [x for x in old['command'] if not x.startswith('/DHYLE_TEST_GLM_STATE_')]
        old['command'] += [f'/DHYLE_TEST_{MACROS[name]}_CPU=1', f'/DHYLE_TEST_{MACROS[name]}_CUDA=1']
    recipe = S / 'recipes' / (name + '.json')
    recipe.parent.mkdir(parents=True, exist_ok=True)
    c.save(recipe, old)
    h.RECIPES[name], h.SOURCES[name] = recipe, SOURCES[name]
    h.compile_one(name, attempt)


def link(attempt, names=None):
    base = c.read(BASE / 'link-plan.json')
    replaced = {c.key(str(p)) for p in SOURCES.values()}
    remove, retained_records = set(), []
    for item in base['compiled_records']:
        rec = c.read(item['path'])
        if c.key(rec['source']['path']) in replaced:
            remove.add(c.key(rec['object']['path']))
        else:
            retained_records.append(item)
    for recipe in EXTRA_RECIPES.values():
        remove.add(c.key(c.read(recipe)['object']['path']))
    added, compiled = [], []
    for name in (names or SOURCES):
        records = sorted(S.glob(f'compile*/{name}/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
        if not records:
            raise RuntimeError('No compiled consumer: ' + name)
        path = records[-1]
        rec = c.read(path)
        assert all(b.identity(x['path']) == x for x in [rec['source'], rec['object'], *rec['dependencies']])
        added.append(rec['object'])
        compiled.append(b.identity(path))
    inputs = added + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [x['path'] for x in added]
    folder = S / f'tests-link{attempt}'
    folder.mkdir()
    (folder / 'tmp').mkdir()
    image = folder / 'mtp-seed-cache-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(folder / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=compiled + retained_records, base=b.identity(BASE / 'link-plan.json'),
        SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shader_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], folder)
    c.execute('link', command, env, folder)
    runtime = c.read(BASE / 'runtime-environment.json')
    for item in runtime['staged_dlls']:
        assert b.identity(item['path']) == item
        os.link(item['path'], folder / Path(item['path']).name)
    runtime['PATH'] = str(folder) + ';' + ';'.join(
        p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in folder.glob('*.dll')]
    runtime['base_runtime'] = b.identity(BASE / 'runtime-environment.json')
    c.save(folder / 'runtime-environment.json', runtime)
    c.save(folder / 'ready.json', dict(image=b.identity(image)))
    print('LINKED', image, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('actions', nargs='+', choices=[*SOURCES, 'link'])
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--only', nargs='+', choices=list(SOURCES))
    args = parser.parse_args()
    for name in args.actions:
        link(args.attempt, args.only) if name == 'link' else compile_one(name, args.attempt)
