"""Fetch four bounded stage1/2 roles from the already fixed DSpark sidecar."""
from pathlib import Path
import hashlib
import json
import time
import urllib.request
S = Path(__file__).resolve().parent
R = S.parents[1]
prior = json.loads((R / '.scratch/glm-mtp-catchup-20261022/review/dspark-original-target-roles.json').read_text(encoding='utf-8'))
assert prior['revision'] == 'fbbb5b93fb787c21338159b0af3318bb3f4d9768'
assert prior['known_whole_file_bytes'] == 10896057440
roles = [
    ('blk.1.attn_kv.weight.q8_0', 10472070944, 10474299167),
    ('blk.1.attn_kv_a_norm.weight.f32', 10472064800, 10472066847),
    ('blk.2.attn_kv.weight.q8_0', 10617732384, 10619960607),
    ('blk.2.attn_kv_a_norm.weight.f32', 10617726240, 10617728287),
]
folder = S / 'original-dspark-history'
folder.mkdir(exist_ok=False)
receipt = dict(repository=prior['repository'], revision=prior['revision'], file=prior['file'],
    tensor_table_sha256=prior['tensor_table_sha256'], tensor_data_offset=prior['tensor_data_offset'],
    whole_file_bytes=prior['known_whole_file_bytes'], expected_etag=prior['known_etag'],
    whole_file_download_allowed=False, roles=[], complete=False)


def save():
    (folder / 'acquisition.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')


save()
for name, first, last in roles:
    count = last - first + 1
    assert count in (2228224, 2048)
    record = dict(name=name, absolute_range=[first, last], requested_bytes=count,
                  started_unix=time.time(), status='REQUESTING')
    receipt['roles'].append(record)
    save()
    print('REQUEST', name, count, flush=True)
    try:
        request = urllib.request.Request(prior['url'], headers={
            'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity',
            'If-Range': prior['known_etag'], 'User-Agent': 'hyle-original-role-consumer/1'})
        with urllib.request.urlopen(request, timeout=45) as response:
            record.update(http_status=response.status, content_range=response.headers.get('Content-Range'),
                content_length=response.headers.get('Content-Length'), etag=response.headers.get('ETag'))
            assert response.status == 206 and record['content_range'] == f'bytes {first}-{last}/{receipt["whole_file_bytes"]}', \
                'Refuse whole file or incorrect range before reading body'
            assert record['etag'] == prior['known_etag']
            if record['content_length'] is not None:
                assert int(record['content_length']) == count
            digest, remaining = hashlib.sha256(), count
            path = folder / name
            with path.open('xb') as output:
                while remaining:
                    chunk = response.read(min(1 << 20, remaining))
                    assert chunk, 'Truncated original role'
                    output.write(chunk)
                    digest.update(chunk)
                    remaining -= len(chunk)
                assert not response.read(1), 'Unexpected bytes after exact role'
        record.update(status='ACQUIRED_EXACT_ROLE', payload=dict(path=str(path), bytes=count, sha256=digest.hexdigest()))
        print('ACQUIRED', name, digest.hexdigest(), flush=True)
    except Exception as error:
        record.update(status='ACQUISITION_FAILED_NO_WHOLE_FILE', error=repr(error))
        raise
    finally:
        record['finished_unix'] = time.time()
        save()
receipt['complete'] = True
receipt['payload_bytes'] = sum(x['payload']['bytes'] for x in receipt['roles'])
assert receipt['payload_bytes'] == 4460544
save()
print('ALL FOUR EXACT ROLES', receipt['payload_bytes'], flush=True)
