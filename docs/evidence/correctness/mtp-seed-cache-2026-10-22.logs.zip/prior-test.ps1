$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/glm-mtp-catchup-20261022').Path
$scratchPrefix = (Resolve-Path -LiteralPath '.scratch').Path.TrimEnd('\') + '\'
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$allowed = @($plan.allowed_parents | ForEach-Object { (Resolve-Path -LiteralPath $_).Path })
foreach ($parent in $allowed) {
    if (-not $parent.StartsWith($scratchPrefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace scratch: $parent" }
}
foreach ($keep in $plan.protected) {
    if (-not (Test-Path -LiteralPath $keep -PathType Leaf)) { throw "Protected reproduction input missing: $keep" }
}
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $plan.entries) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if ((Split-Path -Parent $target) -notin $allowed -or $target -in $plan.protected) { throw "Unplanned target: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe','.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
foreach ($entry in $plan.entries) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = @($plan.entries)
    RemovedPathBytes = $plan.removed_path_bytes
    KnownReclaimableUniqueBytes = $plan.known_reclaimable_unique_bytes
    ProtectedInputsRetained = @($plan.protected | ForEach-Object { Test-Path -LiteralPath $_ })
    Retained = $plan.retained
    HardlinkNote = $plan.hardlink_note
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object RemovedPathBytes, KnownReclaimableUniqueBytes, ProtectedInputsRetained
