"""Publish actual finite execution, retained sources and unclosed contracts."""
from pathlib import Path
import hashlib
import json
import zipfile
S = Path(__file__).resolve().parent
R = S.parents[1]
BC = R / '.scratch/glm-mtp-catchup-20261022'
OUT = R / 'docs/evidence/correctness/mtp-seed-cache-2026-10-22.json'
ZIP = OUT.with_suffix('.logs.zip')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def ident(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


assert not OUT.exists() and not ZIP.exists()
selection = read(S / 'final-checks.json')
checks = read(S / selection['summary'])
assert checks['tests'] == selection['tests'] and checks['process']['exit'] == 0 and not checks['process']['timed_out']
assert not any(checks[k] for k in ('failures', 'errors', 'disabled', 'skips'))
assert ident(checks['image']['path'])['sha256'] == checks['image']['sha256']
submissions = sum(int(x['properties']['actual_submissions']) for x in checks['cases'])
assert submissions > 130
original = [read(BC / 'original-dspark-target/acquisition.json'), read(S / 'original-dspark-history/acquisition.json')]
for receipt in original:
    assert receipt['complete'] and len(receipt['roles']) == 4
    for item in receipt['roles']:
        assert item['http_status'] == 206 and item['status'] == 'ACQUIRED_EXACT_ROLE'
        assert item['etag'] == receipt['expected_etag']
        actual = ident(item['payload']['path'])
        assert actual['sha256'] == item['payload']['sha256'] and actual['bytes'] == item['payload']['bytes']
assert sum(x['payload_bytes'] for x in original) == 60_184_576
changes = [
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
    'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'tests/compute_models/glm_official_index_cache.h',
    'tests/compute_models/glm_official_index_cache_test.cc',
    'tests/compute_models/dspark_target_binding.h',
    'tests/compute_models/dspark_main_history.h',
    'tests/compute_models/dspark_main_history_test.cc',
    'tests/graph_route_cpu/CMakeLists.txt', 'tests/graph_route_cuda/CMakeLists.txt',
    'docs/developer/current-work.md', 'docs/implementation/model-operators.md',
]
for name in changes:
    target = S / 'source-current' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((R / name).read_bytes())
doc = read(S / 'docs-update.json')
text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
perf = text[text.index('## 最新完整性能对比'):].encode('utf-8')
assert hashlib.sha256(perf).hexdigest() == doc['performance_utf8_sha256']
link = Path(checks['image']['path']).parent
runtime = read(link / 'runtime-environment.json')
assert any(x['sha256'] == '5581bf8442abfa1262ca99e564b03401c993537ab04a38ea7893bf07dac2dba7'
           for x in runtime['staged_dlls'])
source_reviews = {p.relative_to(S).as_posix(): read(p) for p in sorted((S / 'review').glob('*.json'))}
freezes = {p.relative_to(S).as_posix(): read(p) for p in sorted(S.glob('*source*/freeze*.json'))}
compiles = [read(p) for p in sorted(S.glob('compile*/*/compile.result.json'))]
report = dict(date='2026-10-23', round_started='2026-10-22', status='FINITE_NORMAL_SEED_AND_ENCODED_CACHE_CONSUMERS_PASS',
    goal_complete=False, changes=[ident(R / p) for p in changes], checks=checks,
    actual_Graph_submissions=submissions,
    predecessor=ident(R / 'docs/evidence/correctness/mtp-target-state-2026-10-22.json'),
    GLM=dict(
        normal_seed='Actual sequential draft-extend last-accepted whole-version hidden/selection/frontier -> next-epoch decode step0 whole-indexer skip, without a handoff submission or changing resource/epoch labels. Accepted-only nx journal catchup and actual next producer precede the subsequent handoff; independent accepted-prefix base recomputation.',
        logical_cache='Pinned06992 scale_fmt=None reader: pooled F32 -> BF16 -> normalized Hadamard128 -> BF16 -> E4 codes and per-row F32 scale max(absmax,1e-4)/448. Matching query rotation/quantization and code-domain ReLU/scaled-head score -> TopK512 -> actual expanded I32 IDs -> MLA.',
        persistence='Actual E4 code bank and per-row F32 scale, not a retained F32 shadow. Temporary scorer decoding is explicit ordinary Graph work.',
        composition='Independent finite cache consumer and full NextN normal-seed consumer. Cache storage must still be composed into complete NextN/target state; target43 upstream MLA/indexer remains uncovered.',
        limits='Generated logical cache inputs and sequential single-row seed protocol, not vendor page ABI, batched vendor extend, original45-layer model, original full vocabulary, natural acceptance, quality, throughput or physical memory.'),
    DSpark=dict(original_parameters=original,
        distinct_original_roles=8, original_payload_bytes=60_184_576,
        main_history='Actual projection result lease -> three stage-specific original Q8 wkv/F32norm -> declared BF16 cache boundary and last64 interleaved positive RoPE(base10000,noYaRN) -> actual row-inline E4 group64/UE8M0 plus BF16tail encoded128-slot rings. Prefix selection publishes all three rings, last main and explicit frontier under one StateHead. Actual decode/attention successor must read selected state.',
        maintenance='Standalone main KV and embedded main history share append_main_kv math/role qualification; no reliance on graph node count/order, no second executor or loader.',
        limits='Generated target HC taps; selected Q8/F32 projection route and explicit cache boundaries do not certify original BF16-weight computation, full target captures, complete draft state/shared LM, natural acceptance or all profiles.'),
    source_reviews=source_reviews, source_freezes=freezes,
    initial_native_failure=read(S / 'checks1/summary.json'),
    corrections=dict(
        seed='The skip Graph intentionally copies selection into its own result lease; catchup must retain that actual accepted step0 lease, while seed ID bytes remain equal. Corrected test ownership assertion, not computation.',
        hadamard='Public F32-accumulation Hadamard does not specify the native summation order. Independently validate raw typed input, mathematical F64 transform with a predeclared F32 dot error bound, exact BF16 conversion, then exact independent E4/scale quantization from that validated input. Signed zero remains checked; no zeroing or product gate change.',
        history_precision='Q8 projection approximation is checked at its actual continuous postnorm boundary with the original gate. BF16, explicit RoPE, cache-entry rounding, independent row encoding and ring state are then checked at their actual boundaries; do not apply a continuous F32 tolerance after a discontinuous BF16/E4 roundtrip or couple the consumer oracle to every backend activation codec.',
        history_CUDA='Real product wiring gap: RoPE previously rejected a valid strided last-axis suffix. Existing representability and size checks remain; nonnegative strides are accepted and the provider materializes only noncontiguous data. Canonicalize singleton-axis metadata by a conditional same-shape view before the strict explicit-frequency carrier, without copying a single row or editing shared metadata. Source/map audit excluded an old dimensions ABI mismatch. No platform copy policy in the model builder.',
        error_context='Native cold rejection now identifies operation, type and value; RoPE adds relevant shape/layout metadata rather than only a generic decline.',
        consumer_compile='Corrected new test TensorShape construction, rope_frequencies second argument and explicit uint16 narrowing; initial compile failures retained.'),
    validation=dict(platform='Windows CPU and CUDA only in this round',
        scope='Changed host consumer TUs plus two CUDA-provider host TUs compiled; other provider/native SDK objects and corrected CPU worker reused.',
        host_compile_attempts=len(compiles),
        full_SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shader_builds=0,
        throughput_evidence=False, physical_memory_evidence=False, performance_section=doc),
    remaining=[
        'Add actual dynamic E4 code+F32-scale output using existing power-of-two math: pinned default indexer construction selects scale_fmt=ue8m0, not the optional unrounded branch tested here. Then compose default cache and actual target43 MLA/indexer ->44 into complete NextN accepted state; applicable original GLM roles/codecs and geometry.',
        'Compose DSpark actual main histories with complete draft stage state, qualified actual target taps/shared head and remaining applicable role suppliers.',
        'Q27/Q24 actual role/codec and complete state combination, confirmed-MTP selected quantized artifacts.',
        'Necessary related regressions and final ordinary/MTP prefill/decode/combined/physical-memory comparison; image chain afterward.'
    ],
    cleanup=read(S / 'cleanup-result.json'), original_payloads_archived=False,
    payload_retention='All exact original role bodies retained once locally; archived range/hash/command receipts and small F32 norms only.')
save(S / 'report-before-archive.json', report)
extensions = {'.json', '.py', '.cc', '.cpp', '.h', '.md', '.diff', '.log', '.xml', '.txt', '.ps1'}
files = [p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in extensions and '__pycache__' not in p.parts]
files += list((S / 'original-dspark-history').glob('*.f32'))
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        archive.write(path, path.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
report['sources_commands_and_results'] = ident(ZIP)
save(OUT, report)
receipt = dict(evidence=ident(OUT), archive=ident(ZIP), goal_complete=False)
save(S / 'publication-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
