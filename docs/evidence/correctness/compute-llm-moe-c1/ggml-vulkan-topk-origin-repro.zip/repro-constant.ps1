$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$source = Join-Path $canonicalRoot '.scratch\validation\vulkan-topk\odd-rank8-constant'
$build = 'C:\hyle-scratch\active-vk\topk-origin-repro'
. (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir 'C:\hyle-scratch\active-vk\shared' -ExtraArgs @('--target','help') > (Join-Path $source 'environment.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& 'C:\Program Files\CMake\bin\cmake.exe' -S $source -B $build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH=C:/hyle-scratch/active-vk/t/relocated-sdk-shared > (Join-Path $source 'configure.log') 2>&1
if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $source 'configure.log') -Tail 30; exit $LASTEXITCODE }
& 'C:\Program Files\CMake\bin\cmake.exe' --build $build --parallel 1 > (Join-Path $source 'build.log') 2>&1
if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $source 'build.log') -Tail 30; exit $LASTEXITCODE }
$crt = Get-ChildItem -LiteralPath 'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Redist\MSVC' -Directory |
  Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'x64\Microsoft.VC145.CRT') } |
  Sort-Object Name -Descending | Select-Object -First 1
Get-ChildItem -LiteralPath (Join-Path $crt.FullName 'x64\Microsoft.VC145.CRT') -Filter '*.dll' -File | Copy-Item -Destination $build -Force
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class TopkOriginErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[TopkOriginErrorMode]::SetErrorMode(0x8003) | Out-Null
& 'C:\Program Files\CMake\bin\cmake.exe' -E env --unset=PATH (Join-Path $build 'topk_constant_origin_repro.exe') > (Join-Path $source 'run.log') 2>&1
$result = $LASTEXITCODE
Get-Content (Join-Path $source 'run.log')
exit $result
