#include <hyle/compute/vulkan.h>
#include <array>
#include <cstdio>
#include <cstring>
#include <span>
#include <vector>

namespace c = hyle::compute;
namespace v = c::vulkan;

hyle::Status reproduce() {
  HYLE_ASSIGN_OR_RETURN(auto context, v::Context::create());
  const std::array<std::int64_t, 8> shape{1, 1, 1, 1, 1, 1, 1, 520};
  const std::array<std::int64_t, 8> strides{516, 516, 516, 516, 516, 516, 516, 1};
  HYLE_ASSIGN_OR_RETURN(auto storage_desc,
                       c::TensorDesc::strided_bytes(c::DataType::kFloat32, shape, strides));
  std::vector<std::byte> host(*storage_desc.required_bytes(), std::byte{0});
  for (std::size_t i = 0; i < 129; ++i) {
    const float value = static_cast<float>(i);
    std::memcpy(host.data() + 1 + i * 4, &value, 4);
  }
  HYLE_ASSIGN_OR_RETURN(auto storage, context.upload(storage_desc, host));
  HYLE_ASSIGN_OR_RETURN(auto view, c::View::slice(7, 1, 129, 4));
  HYLE_ASSIGN_OR_RETURN(auto input, storage.view(view));
  std::printf("rank=%zu dense=%d byte_origin=%llu\n", input.description().rank(),
              input.description().is_dense(), static_cast<unsigned long long>(input.native_offset()));
  HYLE_ASSIGN_OR_RETURN(auto program, v::prepare(context, c::TopK{.count = 8}, input));
  HYLE_ASSIGN_OR_RETURN(auto slot, program.create_invocation());
  HYLE_RETURN_IF_ERROR(slot.bind(std::span<const v::Tensor>{}));
  HYLE_ASSIGN_OR_RETURN(auto work, slot.submit());
  HYLE_ASSIGN_OR_RETURN(auto result, work.wait());
  std::array<float, 8> actual{};
  HYLE_RETURN_IF_ERROR(context.download(result->tensors()[0], std::as_writable_bytes(std::span(actual))));
  for (std::size_t i = 0; i < actual.size(); ++i)
    if (actual[i] != 128.f - static_cast<float>(i))
      return hyle::Status::Internal("TopK values differ");
  return hyle::Status::Ok();
}

int main() {
  const auto status = reproduce();
  if (status.ok()) {
    std::puts("PASS");
    return 0;
  }
  const auto message = status.message();
  std::fprintf(stderr, "FAIL: %.*s\n", static_cast<int>(message.size()), message.data());
  return 1;
}
