param([switch]$ResumeConsumer)
$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-c1-fragment'
$candidate = 'a03f6786bfd9ecdcf0e158d5ea90f1a627f31236'
if ((git rev-parse HEAD).Trim() -ne $candidate -or (git status --porcelain)) { throw 'Frozen candidate changed' }
$env:VULKAN_SDK = 'C:\public\tools\hyle-vulkan\1.4.357.0'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
& ./scripts/hyle-windows.ps1 -Action Build -BinaryDir C:/hyle-scratch/active-vk/static -ExtraArgs @('--target','hyle_source_package','--parallel','2') > (Join-Path $taskRoot $(if ($ResumeConsumer) {'resume-package.log'} else {'source-package.log'})) 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if (-not $ResumeConsumer) {
    python (Join-Path $taskRoot 'freeze-inputs.py')
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
$inputRecord = Get-Content -LiteralPath (Join-Path $taskRoot 'inputs.json') -Raw -Encoding utf8 | ConvertFrom-Json
$arguments = @((Join-Path $taskRoot 'verify-delivery.py'), '--root', 'C:/hyle-scratch/active-vk/j31', '--archive', $inputRecord.source_archive, '--sha256', $inputRecord.source_archive_sha256, '--candidate', $candidate, '--consumer', (Join-Path $taskRoot 'consumer'), '--fixtures', (Join-Path $taskRoot 'fixtures'))
if ($ResumeConsumer) { $arguments += '--resume-source-build' }
python @arguments
exit $LASTEXITCODE
