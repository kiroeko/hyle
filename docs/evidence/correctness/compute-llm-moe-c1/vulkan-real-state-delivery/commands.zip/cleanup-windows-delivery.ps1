$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-c1-fragment'
$recordPath = Join-Path $taskRoot 'qualification\windows-delivery.json'
$record = Get-Content -LiteralPath $recordPath -Raw -Encoding utf8 | ConvertFrom-Json
$archive = Join-Path (Split-Path -Parent $recordPath) $record.archive
if ($record.status -ne 'PASS' -or $record.candidate -ne 'a03f6786bfd9ecdcf0e158d5ea90f1a627f31236' -or
    (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $record.archive_sha256) {
    throw 'Verified delivery archive is required before producer cleanup'
}
$root = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath 'C:\hyle-scratch\active-vk\j31').Path).TrimEnd('\')
$boundary = $root + '\'
$targets = @('bs-hidden','bd-hidden','complete-source-hidden')
$planned = @()
foreach ($name in $targets) {
    $path = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath (Join-Path $root $name)).Path)
    if (-not $path.StartsWith($boundary, [StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetFileName($path) -ne $name) { throw 'Producer cleanup escaped its workspace' }
    $item = Get-Item -LiteralPath $path -Force
    $entries = @(Get-ChildItem -LiteralPath $path -Recurse -Force)
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw ('Producer root is a reparse point: ' + $path) }
    $links = @()
    foreach ($entry in @($entries | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })) {
        # ggml contains a documentation file symlink. Unlink only the verified
        # file; never recurse through a directory reparse point or its target.
        if ($entry.PSIsContainer -or $entry.LinkType -ne 'SymbolicLink') { throw ('Unexpected producer reparse point: ' + $entry.FullName) }
        $linkPath = [IO.Path]::GetFullPath($entry.FullName)
        $linkTarget = [IO.Path]::GetFullPath((Join-Path $entry.DirectoryName $entry.Target))
        if (-not $linkPath.StartsWith($path + '\', [StringComparison]::OrdinalIgnoreCase) -or
            -not $linkTarget.StartsWith($path + '\', [StringComparison]::OrdinalIgnoreCase)) {
            throw ('Producer file symlink escapes its build: ' + $linkPath)
        }
        $links += @{path=$linkPath; target=$linkTarget; action='unlink file only'}
    }
    $files = @($entries | Where-Object { -not $_.PSIsContainer })
    $planned += @{path=$path; files=$files.Count; logical_bytes=($files | Measure-Object -Property Length -Sum).Sum; links=$links}
}
$receipt = @{candidate=$record.candidate; archive_sha256=$record.archive_sha256; state='READY'; producers=$planned;
    retained=@('relocated-sdk-static','relocated-sdk-shared','consumer-static','consumer-shared','fixtures','logs','independent-consumer')}
$output = Join-Path $taskRoot 'qualification\windows-producer-cleanup.json'
if (Test-Path -LiteralPath $output) { throw 'Inspect prior cleanup receipt before repeating' }
$receipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $output -Encoding utf8
foreach ($target in $planned) {
    foreach ($link in $target.links) { Remove-Item -LiteralPath $link.path -Force }
    Remove-Item -LiteralPath $target.path -Recurse -Force
    if (Test-Path -LiteralPath $target.path) { throw ('Producer still present after cleanup: ' + $target.path) }
}
$receipt.state = 'PASS'
$receipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $output -Encoding utf8
$planned | Select-Object @{Name='Path';Expression={$_.path}},@{Name='LogicalBytes';Expression={$_.logical_bytes}}
