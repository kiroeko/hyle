"""Extract local real weights and an independent FP64 fragment oracle; no HYLE verdict."""
import hashlib
import json
import math
from pathlib import Path
import struct

task = Path(__file__).resolve().parent
repo = task.parents[2]
out = task / 'fixtures'
out.mkdir(exist_ok=True)
assert not any(out.iterdir()), 'do not overwrite frozen fixtures'
verification = json.loads((task / 'source-current.json').read_text(encoding='utf-8'))
assert verification['result'] == 'PASS' and verification['files_verified'] == 13
cases_path = repo / 'tests/compute_models/qwen35_cases.json'
cases = json.loads(cases_path.read_text(encoding='utf-8'))
assert cases['source_id'] == verification['source_id']
tokens = cases['state_boundary']['token_ids']
assert len(tokens) == 257
for case in cases['reference_cases']:
    assert case['prompt_ids'] == tokens[:len(case['prompt_ids'])]
unique = sorted(set(tokens))
assert len(unique) == 34
lookup = {token: row for row, token in enumerate(unique)}
source = Path(verification['directory']) / 'model.safetensors-00001-of-00001.safetensors'
before = source.stat()
width = 2048

def f32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]

def decode(bits):
    return struct.unpack('<f', struct.pack('<I', bits << 16))[0]

with source.open('rb') as stream:
    size = struct.unpack('<Q', stream.read(8))[0]
    raw = stream.read(size)
    header = json.loads(raw)
    assert hashlib.sha256(raw).hexdigest() == 'ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d'
    table_key = 'model.language_model.embed_tokens.weight'
    scale_key = 'model.language_model.layers.0.input_layernorm.weight'
    table = header[table_key]
    scale = header[scale_key]
    assert table['dtype'] == scale['dtype'] == 'BF16'
    assert table['shape'] == [248320, width] and scale['shape'] == [width]
    rows = []
    for token in unique:
        stream.seek(8 + size + table['data_offsets'][0] + token * width * 2)
        data = stream.read(width * 2)
        assert len(data) == width * 2
        rows.append(data)
    stream.seek(8 + size + scale['data_offsets'][0])
    parameter = stream.read(width * 2)
    assert len(parameter) == width * 2
scales = [f32(1.0 + decode(v)) for v in struct.unpack('<2048H', parameter)]
epsilon = f32(1e-6)
updates = []
for row in rows:
    values = [decode(v) for v in struct.unpack('<2048H', row)]
    denominator = math.sqrt(math.fsum(x * x for x in values) / width + epsilon)
    for x, weight in zip(values, scales):
        norm = x / denominator * weight
        silu = norm / (1.0 + math.exp(-norm))
        updates.append(silu * x + x)
assert all(math.isfinite(x) for x in updates)
data = {
    'table.bf16': b''.join(rows),
    'gemma_parameter.bf16': parameter,
    'gemma_scale.f32': struct.pack('<2048f', *scales),
    'token_rows.i32': struct.pack('<257i', *(lookup[t] for t in tokens)),
    'update_oracle.f64': struct.pack('<' + str(len(updates)) + 'd', *updates),
}
records = []
for name, payload in data.items():
    (out / name).write_bytes(payload)
    records.append({'file': name, 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()})
assert hashlib.sha256(data['table.bf16']).hexdigest() == '53fee1601e7807f42995e56d62bd437027d5ee344976435f14ec40ecbb43f0c8'
assert hashlib.sha256(data['gemma_scale.f32']).hexdigest() == '4f189e0e0cb573c744e0f3e4683304728ddd51e977bbc2ffbafdc96bb297cce2'
after = source.stat()
assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
receipt = {
    'kind': 'Y31 actual BF16 fragment fixtures and independent scalar oracle; HYLE NOT_RUN',
    'source_id': verification['source_id'], 'source_verification': verification,
    'source_file_size': before.st_size, 'source_file_mtime_ns': before.st_mtime_ns,
    'header_sha256': hashlib.sha256(raw).hexdigest(),
    'tensor_sources': {table_key: table, scale_key: scale},
    'original_token_by_local_row': unique, 'epsilon_f32': epsilon,
    'cases_sha256': hashlib.sha256(cases_path.read_bytes()).hexdigest(),
    'shapes': [[1, 1], [1, 17], [1, 128], [1, 23], [1, 129], [2, 23], [2, 129]],
    'streams': 2, 'steps_each': 5,
    'indices': 'token_rows[(batch*17 + time + step*3 + stream*11) % 257]',
    'float_scan_input': 'gemma_scale[(local_index*31 + step*7 + stream*13) % 2048]',
    'oracle': 'independent Python FP64 fsum/RMS, SiLU(norm)*embedding + embedding; BF16 RNE in consumer',
    'files': records, 'generator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'limitation': 'Composed real-tensor basic-library fragment; not literal Qwen forward, whole model, performance, or C1 verdict.',
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'files': len(records), 'bytes': sum(r['bytes'] for r in records), 'hyle': 'NOT_RUN'}))
