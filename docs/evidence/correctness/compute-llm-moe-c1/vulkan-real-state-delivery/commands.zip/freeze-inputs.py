import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

task = Path(__file__).resolve().parent
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert candidate == 'a03f6786bfd9ecdcf0e158d5ea90f1a627f31236'
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
archive = Path('C:/hyle-scratch/active-vk/static/dist/hyle-0.1.0-source.zip')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(archive) as z:
    assert candidate in z.read('hyle-0.1.0-source/SOURCE-MANIFEST.txt').decode('utf-8')
assets = task / 'y31-assets.zip'
with zipfile.ZipFile(assets, 'x', zipfile.ZIP_DEFLATED) as z:
    for directory in ('consumer', 'fixtures'):
        for p in sorted((task / directory).rglob('*')):
            if p.is_file(): z.write(p, p.relative_to(task).as_posix())
record = {'candidate': candidate, 'product_unchanged_since': '55fe0b8a505c0f725473f53e1a3eb875006b85fb',
          'source_archive': str(archive), 'source_archive_sha256': sha(archive),
          'source_archive_bytes': archive.stat().st_size, 'assets_sha256': sha(assets),
          'consumer_files': {p.name: sha(p) for p in (task / 'consumer').iterdir() if p.is_file()},
          'fixture_receipt_sha256': sha(task / 'fixtures/receipt.json'),
          'verifier_sha256': sha(task / 'verify-delivery.py'),
          'state': 'FROZEN_NOT_RUN', 'scope': 'Y31 real state fragment Direct/Graph source/static/shared'}
(task / 'inputs.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
