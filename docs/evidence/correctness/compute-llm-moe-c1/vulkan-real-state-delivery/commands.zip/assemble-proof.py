import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

task = Path(__file__).resolve().parent
repo = task.parents[2]
out = repo / 'evidence/correctness/compute-llm-moe-c1/vulkan-real-state-delivery'
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
results = []
for platform in ('windows', 'air'):
    receipt = task / 'qualification' / (platform + '-delivery.json')
    record = json.loads(receipt.read_text(encoding='utf-8'))
    assert record['status'] == 'PASS' and record['candidate'] == 'a03f6786bfd9ecdcf0e158d5ea90f1a627f31236'
    archive = receipt.parent / record['archive']
    assert sha(archive) == record['archive_sha256']
    counts = []
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for build in ('bs', 'consumer-static', 'consumer-shared'):
            text = z.read('logs/' + build + '-LastTest.log').decode('utf-8', errors='replace')
            assert text.count('PASS B=') == 14 and text.count('BEGIN B=') == 140
            assert not any(x in text for x in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
            peaks = [int(x) for x in re.findall(r'peak=(\d+)', text)]
            counts.append({'delivery': build, 'cases': 14, 'stateful_steps': 140,
                           'checked_failures': 14, 'fresh_after_failure': 14,
                           'max_charged_bytes_including_failure_slots': max(peaks)})
    shutil.copy2(receipt, out / receipt.name)
    shutil.copy2(archive, out / archive.name)
    results.append({'platform': record['platform'], 'deliveries': counts,
                    'receipt_sha256': sha(receipt), 'archive_sha256': sha(archive)})
for source in ('implementation-loc.json', 'source-current.json', 'air-initial-launch.json', 'air-machine.json'):
    shutil.copy2(task / source, out / source)
for source in ('windows-producer-cleanup.json', 'air-producer-cleanup.json'):
    shutil.copy2(task / 'qualification' / source, out / source)
command_files = ['prepare-fixture.py', 'verify-delivery.py', 'freeze-inputs.py', 'w1-delivery.ps1',
                 'air-delivery.py', 'pack-delivery.py', 'relocate.ps1', 'cleanup-windows-delivery.ps1',
                 'cleanup-air-delivery.py', 'assemble-proof.py', 'inputs.json', 'fixtures/receipt.json',
                 'scope-plan.json']
with zipfile.ZipFile(out / 'commands.zip', 'x', zipfile.ZIP_DEFLATED) as z:
    for name in command_files: z.write(task / name, name)
with zipfile.ZipFile(out / 'commands.zip') as z:
    assert z.testzip() is None
    for name in command_files:
        assert hashlib.sha256(z.read(name)).hexdigest() == sha(task / name)
summary = {'scope': 'C1-Y31 Vulkan real BF16 state fragment, Direct/Graph, six deliveries',
           'candidate': 'a03f6786bfd9ecdcf0e158d5ea90f1a627f31236', 'local_verdict': 'PASS',
           'product_corrections': 0, 'consumer_corrections': 0, 'air_launcher_corrections': 1,
           'cases': 84, 'stateful_steps': 840, 'checked_failures': 84, 'fresh_after_failure': 84,
           'results': results, 'commands_sha256': sha(out / 'commands.zip'),
           'C1_aggregate': 'NOT_ACCEPTED', 'P1': 'NOT_RUN',
           'remaining': ['global selected gates', 'C1 all-route fixed performance qualification and rule/elimination decisions',
                         'CPU oneDNN preflight qualification BLOCKED', 'other C1 acceptance not covered by this fragment'],
           'matrix_rows_accepted': 0, 'matrix_cells_accepted': 0}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'result': 'PASS', 'cases': 84, 'steps': 840, 'path': str(out)}))
