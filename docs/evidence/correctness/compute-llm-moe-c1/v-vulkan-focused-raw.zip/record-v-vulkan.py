from pathlib import Path
import hashlib, json, re, subprocess, zipfile

root = Path('C:/hyle-scratch/llm-moe-c1-20260917')
repo = Path('C:/public/project-hyle/hyle')
evidence = repo / 'evidence/correctness/compute-llm-moe-c1'
product = '40f4cbe397c626bc116cbb97badbaa36542d8f23'
candidate = '82c221fb0a2f0646eca99ce1b014b13c9f5d3655'
entries = [('windows', '40f4cbe3'), ('windows', 'c62247ba'),
           ('windows', candidate[:8]), ('air', candidate[:8]), ('mini', candidate[:8])]
failures = {
    '40f4cbe3': 'Product and SPIR-V compiled; new tests failed to compile because the helper needs explicit Operation construction and Result needs explicit contained-value reset. Only test code was corrected.',
    'c62247ba': 'All new Direct/Graph math and lifecycle cases passed. One old assertion expected half-precision GatedActivation preparation to fail. Changed only that refusal domain to unsupported F64.'}
attempts, raw_files = [], []
for host, revision in entries:
    directory = root / f'v-{host}' / revision
    path = directory / 'result.json'
    record = json.loads(path.read_text(encoding='utf-8'))
    assert record['verdict'] == ('FAIL' if revision in failures else 'PASS')
    record['validation_host'] = host
    record['local_result'] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    for command in record['commands']:
        log = directory / Path(command['log']).name
        assert hashlib.sha256(log.read_bytes()).hexdigest() == command['sha256']
        command['local_log'] = str(log)
    if revision in failures:
        record['failure'] = failures[revision]
    if revision == '40f4cbe3':
        assert not (directory / 'test.log').exists()
        record['test_cases'] = None
    else:
        text = (directory / 'test.log').read_text(encoding='utf-8')
        # CTest echoes failed test output without its verbose numeric prefix.
        counts = [int(n) for n in re.findall(r'^\d+: \[==========\] Running (\d+) tests? from', text, re.M)]
        only_changed = host == 'windows' and revision == candidate[:8]
        assert counts == ([1] if only_changed else [24, 11])
        record['test_cases'] = {'compute_route_vulkan': counts[0],
            'graph_route_vulkan': 0 if only_changed else counts[1],
            'separate_header_checks': 0 if only_changed else 2}
        if revision == 'c62247ba':
            assert '23 tests.' in text and '[  PASSED  ] 11 tests.' in text
            assert 'Actual: true' in text and 'Expected: false' in text
        else:
            assert hashlib.sha256((directory / 'LastTest.log').read_bytes()).hexdigest() == record['last_test_sha256']
        if host != 'mini':
            assert not any(marker in text for marker in ('Validation Error', 'VUID-', 'SYNC-HAZARD'))
    attempts.append(record)
    raw_files.extend(p for p in directory.iterdir() if p.is_file())
selectors = []
for host, revision in [('windows', 'c62247ba'), ('air', candidate[:8])]:
    path = root / f'v-{host}' / revision / 'selector.json'
    plan = json.loads(path.read_text(encoding='utf-8'))
    selectors.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'verdict': plan['verdict'], 'selected': [g['id'] for g in plan['selected_gates']],
        'skipped_count': len(plan['skipped_gates']),
        'skipped_reasons': [{'id': g['id'], 'reason': g['reason']} for g in plan['skipped_gates']],
        'execution_boundary': 'Focused factors plus the card-declared headers; whole-C1 delivery/performance gates remain pending.'})
for name in ('run-v-vulkan-windows.py', 'run-v-vulkan-windows.ps1',
             'run-v-vulkan-windows-tests.py', 'run-v-vulkan-windows-tests.ps1',
             'run-v-vulkan-windows-refusal.py', 'run-v-vulkan-windows-refusal.ps1',
             'run-v-vulkan-air.py', 'run-v-vulkan-mini.py', 'record-v-vulkan.py',
             'v-documentation-plan.json'):
    raw_files.append(root / name)
archive = evidence / 'v-vulkan-focused-raw.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
    for path in sorted(set(raw_files)):
        output.write(path, path.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as result:
    archive_entries = len(result.namelist())
    assert result.testzip() is None
boundaries = json.loads((evidence / 'v-implementation-loc.json').read_text(encoding='utf-8'))['module']['paths']
assert not subprocess.check_output(['git', 'diff', product, candidate, '--', *boundaries], cwd=repo)
assert subprocess.check_output(['git', 'diff', '--name-only', 'c62247ba', candidate], cwd=repo, text=True).splitlines() == ['tests/compute_route_vulkan/tensor_test.cc']
record = {
    'kind': 'C1-V focused Vulkan gates and mixed normalization; not full C1 acceptance',
    'product_candidate': product, 'validation_candidate': candidate,
    'validation_tree': 'fda6a864d25c5a6dcd2bb2b968144dc60a145636',
    'product_unchanged_since': '40f4cbe3 (all Compute/Graph implementation boundaries match the validation candidate)',
    'verdict': 'PASS', 'scope': 'V01-V04 focused correctness/lifecycle/P0; whole-C1 gates remain unproven',
    'attempts': attempts,
    'qualification': [
        'Air and Mini each passed 24 Direct + 11 Graph cases and two separate header checks. W1 passed 23 Direct + 11 Graph plus headers before correcting the one obsolete refusal assertion; only the changed Direct case was rerun and passed. All other tests and product code are identical. This is explicitly incremental W1 evidence, not a claim that its first full test invocation passed.',
        'Initial test-construction compilation errors and the obsolete refusal assertion are retained. No product, numeric algorithm or tolerance correction was required after the immutable product candidate.',
        'W1/Air installed validation layers reported no Validation Error, VUID or SYNC-HAZARD. Mini is correctness/portability only and has no installed validation layer.',
        'F32/F16/BF16 three gates in packed/separate form, odd byte strides and View origins, empty/tails and rank-eight broadcast use independent FP64 activation and storage-rounding checks. Captured aligned F32 SiLU also exercises the retained ggml GLU shell with corrected IEEE boundaries.',
        'RMSNorm/LayerNorm use F32 accumulation and independently typed scale/bias without narrowing parameters. Widths 0/1/127/128/129/257/2048, 1/2/3 rows, rank-eight, zero strides, odd origins, zero epsilon, NaN/Inf and large-mean small-variance rows passed. Exact affine cancellation proves F32 learned parameters survive through final storage rounding.',
        'One native normalization dispatch, fixed shared memory, paired odd half rows and no extra device scratch. Fixed Recorder tests verify adjacent guard bytes; the ordinary gate/norm/residual Graph reports four dispatches/three reused output blocks and keeps shared constants, independent slots and old results across close.',
        'Preparation binds native rules; execution does no provider search or timing. Existing qualified ggml GLU addressing/dispatch is preserved where alignment is provable; the new numeric adapter and normalization have not yet passed the full-C1 P1 gate.'
    ],
    'selectors': selectors,
    'raw_archive': {'path': archive.relative_to(repo).as_posix(), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'entries': archive_entries},
    'not_run': ['Remaining Vulkan C1 Concat/reduce/Softmax/TopK/index/Scan mechanisms',
                'Full C1 actual model-weight consumer and 64-row/256-cell acceptance',
                'Full C1 source/installed-static/installed-shared and remaining applicable environment/sanitizer gates',
                'P1 and final default-rule qualification']}
header = 'include/hyle/graph/vulkan.h'
before = subprocess.check_output(['git', 'show', candidate + ':' + header], cwd=repo)
after = (repo / header).read_bytes()
code_lines = lambda raw: [line for line in raw.decode('utf-8').splitlines() if not line.lstrip().startswith('//')]
assert code_lines(before) == code_lines(after)
assert '__LINE__' not in after.decode('utf-8') and '#line' not in after.decode('utf-8')
record['documentation_followup'] = {
    'file': header, 'base': candidate,
    'base_sha256': hashlib.sha256(before).hexdigest(), 'current_sha256': hashlib.sha256(after).hexdigest(),
    'proof': 'Removing only full-line // comments leaves exactly identical lines; no __LINE__/#line use. Corrected stale F32/SiLU-only and alias comments, with no C++ token/API/ABI change.',
    'selector': 'The unmodified selector conservatively selects configure/Graph/header/delivery for a public-header edit. Its maintenance plan is retained in the raw archive as v-documentation-plan.json.',
    'selector_plan_sha256': hashlib.sha256((root / 'v-documentation-plan.json').read_bytes()).hexdigest(),
    'execution': 'Those additional product gates were not run and are not PASS. This mechanically proven documentation-only followup follows the user no-rebuild rule; current docs/closure checks run normally. No selector/governance code was changed.'}
(evidence / 'v-vulkan-focused.json').write_bytes((json.dumps(record, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
registry = repo / 'docs/implementation/module-status.json'
data = json.loads(registry.read_text(encoding='utf-8'))
summary = 'LLM/MoE C1-V AUDITED：V01–V04 已实现三类门控、mixed RMS/LayerNorm、原生单 dispatch/word 写入和既有 GLU 薄适配；W1/Air/Mini 各35例及2个头检查已覆盖（W1 旧拒绝断言定向修正）。完整 C1 其余机制、真实权重/三交付和 P1 尚未签收。'
for row in data['modules']:
    if row['module'] in ('compute_route_vulkan', 'graph_route_vulkan'):
        assert row['state'] == 'AUDITED'
        row['summary'] = summary
registry.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print('V receipt written;', archive_entries, 'raw files;', archive.stat().st_size, 'archive bytes')
