$ErrorActionPreference = 'Stop'
$sourceRoot = 'C:\public\project-hyle\hyle'
$taskRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-cpu\aa')
$target = [IO.Path]::GetFullPath((Join-Path $taskRoot 'selected-compute'))
if (-not $target.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Resume target is outside the active task root'
}
foreach ($linkage in @('shared','static')) {
  foreach ($suffix in @('-sdk-staging','-sdk-relocated')) {
    if (Test-Path -LiteralPath (Join-Path $target ($linkage + $suffix))) {
      throw 'Resume is only valid before the first SDK installation'
    }
  }
}
$logRoot = Join-Path $sourceRoot '.scratch\validation\onednn-aa'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CMAKE_TOOLCHAIN_FILE = Join-Path $logRoot 'delivery-toolchain.cmake'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleAaResumeErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[HyleAaResumeErrorMode]::SetErrorMode(0x8003) | Out-Null
$candidate = '58543f8c08dc3f8d22efeaf3620f3e74eaa33091'
if ((& git -C $sourceRoot rev-parse HEAD) -ne $candidate) { throw 'Candidate changed before resume' }
if (& git -C $sourceRoot status --porcelain) { throw 'Tracked workspace is not clean' }
# Import the normal compiler environment; this build is already complete.
. (Join-Path $sourceRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir (Join-Path $target 'source-build') -ExtraArgs @('--parallel','2')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$resumeLog = Join-Path $logRoot 'delivery-compute-resume.log'
& 'C:\Program Files\CMake\bin\cmake.exe' "-DHYLE_SOURCE_DIR=$sourceRoot" "-DHYLE_SMOKE_ROOT=$taskRoot" -DHYLE_SMOKE_COMPONENT=compute -DHYLE_SMOKE_GENERATOR=Ninja '-DCMAKE_CTEST_COMMAND=C:/public/project-hyle/hyle/.scratch/validation/onednn-aa/delivery-ctest.cmd' -P (Join-Path $logRoot 'delivery-resume.cmake') > $resumeLog 2>&1
$code = $LASTEXITCODE
if ((& git -C $sourceRoot rev-parse HEAD) -ne $candidate) { throw 'Candidate changed during resume' }
Get-Content -LiteralPath $resumeLog -Tail 26
exit $code
