import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('linkage', choices=('static', 'shared'))
parser.add_argument('phase', choices=('focus', 'selected'))
args = parser.parse_args()
root = Path(__file__).resolve().parents[3]
candidate = '5f4df55b287b9c895048bf05ab350ff49c96fd6c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
build = Path('C:/hyle-scratch/active-vk') / args.linkage
logs = root / '.scratch/validation/vulkan-topk/origin-correction/w1' / ('y25-' + args.linkage + '-' + args.phase)
logs.mkdir(exist_ok=False)
ctypes.windll.kernel32.SetErrorMode(0x8003)
env = dict(os.environ, VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin',
           VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', HYLE_TEST_VULKAN_VALIDATE='1',
           HYLE_VULKAN_VALIDATION='1', TRACY_ONLY_LOCALHOST='1', CTEST_INTERACTIVE_DEBUG_MODE='0',
           VK_LOADER_LAYERS_DISABLE='~implicit~')
env.pop('PATH', None)
redist = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC')
crt = sorted(p / 'x64/Microsoft.VC145.CRT' for p in redist.iterdir() if (p / 'x64/Microsoft.VC145.CRT').is_dir())[-1]
for dll in crt.glob('*.dll'):
    shutil.copy2(dll, build / 'bin' / dll.name)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
record = {'candidate': candidate, 'linkage': args.linkage, 'phase': args.phase,
          'scope': 'Y25 per-input native descriptor alignment correction; no P1',
          'cmake_cache_sha256': sha(build / 'CMakeCache.txt'), 'status': 'RUNNING', 'commands': []}
try:
    for factor, case in (('compute_route_vulkan', 'VulkanTopK.CapturedDenseRankEightRetainsItsByteOrigin'),
                         ('graph_route_vulkan', 'VulkanGraph.TopKCapturedSliceAddsRootAndAliasByteOrigins')):
        executable = build / 'bin' / ('hyle_' + factor + '_test.exe')
        output = logs / factor
        output.mkdir()
        if args.phase == 'focus':
            command = [str(executable), '--gtest_filter=' + case,
                       '--gtest_output=json:' + str(output / 'result.json')]
        else:
            env['GTEST_OUTPUT'] = 'json:' + str(output) + '/'
            command = ['C:/Program Files/CMake/bin/ctest.exe', '--test-dir', str(build), '-C', 'Release',
                       '--output-on-failure', '--no-tests=error', '-L', '^' + factor + '$', '-LE', 'headers',
                       '--parallel', '1', '--output-junit', str(output / 'ctest.xml')]
        start = time.monotonic()
        with (output / 'run.log').open('w') as stream:
            p = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
        row = {'factor': factor, 'command': command, 'exit_code': p.returncode,
               'seconds': time.monotonic() - start, 'log_sha256': sha(output / 'run.log'),
               'executable_sha256': sha(executable), 'path_unset': True}
        record['commands'].append(row)
        log = (output / 'run.log').read_text(errors='replace')
        print(log[-5000:], flush=True)
        p.check_returncode()
        assert not any(marker in log for marker in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
        reports = list(output.glob('*.json'))
        assert len(reports) == 1
        report = json.loads(reports[0].read_text())
        assert report['tests'] > 0 and report['failures'] == 0 and report['errors'] == 0
        assert report.get('disabled', 0) == 0
        assert all(t['status'] == 'RUN' and t['result'] == 'COMPLETED' for s in report['testsuites'] for t in s['testsuite'])
        row['tests'] = report['tests']
        row['gtest_json_sha256'] = sha(reports[0])
    record['status'] = 'PASS'
except BaseException as e:
    record['status'] = 'FAIL'
    record['failure'] = str(e)
    raise
finally:
    (logs / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
