import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parents[4]
base = root / '.scratch/validation/vulkan-topk'
logs = base / 'origin-correction'
candidate = '5f4df55b287b9c895048bf05ab350ff49c96fd6c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
out = root / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-topk-origin-correction'
out.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

platforms = []
for linkage in ('static', 'shared'):
    r = read(logs / 'w1' / ('y25-' + linkage + '-selected') / 'result.json')
    assert r['status'] == 'PASS'
    platforms.append({'platform': 'W1 ' + linkage, 'candidate': r['candidate'],
                      'tests': sum(c['tests'] for c in r['commands']), 'status': 'PASS'})
for host in ('air', 'mini'):
    receipt = read(logs / ('y25-' + host + '-focused.json'))
    archive = logs / receipt['archive']
    assert sha(archive) == receipt['sha256']
    with zipfile.ZipFile(archive) as z:
        r = json.loads(z.read('result.json'))
        assert r['verdict'] == 'PASS' and r['candidate'] == candidate
        for name, item in json.loads(z.read('archive-manifest.json')).items():
            assert hashlib.sha256(z.read(name)).hexdigest() == item['sha256']
    platforms.append({'platform': host + ' static', 'candidate': r['candidate'],
                      'tests': sum(a['tests'] for a in r['artifacts']), 'status': 'PASS'})
assert sum(p['tests'] for p in platforms) == 283
deliveries = []
for stem in ('windows-delivery-raw', 'y25-air-delivery-raw'):
    r = read(logs / (stem + '.json'))
    assert r['status'] == 'PASS' and r['snapshot'] == candidate and r['executable_count'] == 6
    assert sha(logs / (stem + '.zip')) == r['sha256']
    deliveries.append(r)
selected = read(logs / 'w1/selected-configure.json')
assert selected['verdict'] == 'PASS' and all(a['identical'] for a in selected['artifacts'])
cleanup = [read(logs / 'windows-cleanup.json'), read(logs / 'y25-air-delivery-cleanup.json')]
loc = read(logs / 'loc.json')
assert loc['repository']['commit'] == candidate and loc['self_check'] == 'pass'
assert loc['metrics'][-1]['code'] == 47202

files = {p.relative_to(logs).as_posix(): p for p in (logs / 'w1').rglob('*') if p.is_file()}
for name in ('y25-final-plan.json', 'loc.json', 'source-package.json', 'source-package.log',
             'windows-cleanup.json', 'y25-air-delivery-cleanup.json', 'y25-candidate.json',
             'run-y25-air.py', 'run-y25-mini.py', 'record-y25.py'):
    files[name] = logs / name
for name in ('origin-check.py', 'y25-check.py'):
    files['controller/' + name] = base / name
manifest = {name: {'sha256': sha(p), 'bytes': p.stat().st_size} for name, p in files.items()}
archive = out / 'windows-raw.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
    for name, p in files.items():
        z.write(p, name)
    z.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
for stem in ('y25-air-focused', 'y25-mini-focused', 'windows-delivery-raw', 'y25-air-delivery-raw'):
    for extension in ('.zip', '.json'):
        shutil.copyfile(logs / (stem + extension), out / (stem + extension))
shutil.copyfile(logs / 'loc.json', out / 'loc.json')
record = {
    'candidate': candidate, 'product_candidate': '7f4a3fb647f17ab984a3faaad36d8d66d08834f9',
    'scope': 'Y23-P2 and Y25 Vulkan TopK captured root/alias origin and per-input descriptor alignment',
    'correction_budget': 'original two corrections exhausted; Y25 explicitly re-audited one correction, now implemented and locally qualified',
    'product': 'PASS for the named counterexamples and module correctness below; no full C1 verdict',
    'platforms': platforms, 'deliveries': deliveries,
    'selected_configure': selected,
    'static_evidence_identity': '6b8b52d1 tests have identical implementation/test files at 5f4df55b; final isolated configure/build retained both exact EXE hashes, so tests were not repeated',
    'prior_failures': ['../ggml-vulkan-topk-origin-repro.json', '../ggml-vulkan-topk-descriptor-failure.json',
                       'windows-raw.zip: initial Graph fixture compile diagnostics and corrected build logs'],
    'cleanup_logical_bytes': sum(r['logical_bytes'] for r in cleanup),
    'remaining_selected_delivery': '15 generic gates running separately on immutable Windows verification copy; no aggregate 112 PASS claim',
    'performance': 'NOT_RUN; C1 bundle is not frozen; oneDNN BLOCKED unchanged',
    'coverage_matrix': '64 requirements/256 route cells remain UNPROVEN for complete acceptance',
    'archives': {p.name: sha(p) for p in out.glob('*.zip')},
}
write(out / 'result.json', record)
(out / 'README.md').write_text('''# Vulkan TopK 字节起点与设备对齐纠正

产品 `7f4a3fb6`；测试/三交付快照 `5f4df55b`。完整记录见 [result.json](result.json)。

| 验证 | 实际结果 |
|---|---|
| Windows strict static / shared | 51 Direct + 20 Graph / 51 Direct + 19 Graph |
| Air / Mini static | 各51 Direct + 20 Graph；Mini只签正确性/可移植性 |
| Windows / Air source、relocated static、relocated shared | 各6个普通消费者；包含rank8捕获起点1/4/7、TopK双输出和mixed FFN |

合法dense View仍可有非对齐字节起点；冷降秩别名必须计入常量根native offset，且直接进入
原版Argsort的输入满足设备descriptor对齐。其他偏移感知算子继续四字节合同。Graph测试覆盖
root=1与alias=alignment−1相加后重新对齐，断言不多复制。没有新排序算法、公开API或热期搜索。

Windows全部283项跨配置测试中的本机部分使用DLL邻置、PATH unset与非交互错误模式；
W1/Air日志未见VUID/同步错误。最终两factor配置保留已运行Windows static EXE的精确hash，
因此复用其测试记录，不重复计数或运行。构建/断言失败和fixture修正日志保留于原始归档。

已核对归档后清理Windows/Air producer与展开源码，共1,933,074,359逻辑字节；保留SDK和
consumer。统一实现LOC为47,202行/193文件，不含测试、bench和第三方。

15个通用交付门仍单独运行，未签整个112门通过。C1完整真实权重片段、索引/状态接入、
固定优选与实现淘汰、性能和矩阵签收仍未完成；CPU oneDNN性能资格BLOCKED不变，没有P1。
''', encoding='utf-8', newline='\n')
print(json.dumps({'evidence': str(out), 'tests': 283, 'delivery_consumers': 12,
                  'cleanup_bytes': record['cleanup_logical_bytes']}))
