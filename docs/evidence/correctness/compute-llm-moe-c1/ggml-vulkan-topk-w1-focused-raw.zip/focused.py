import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--round', required=True)
parser.add_argument('--scope', choices=('all', 'remaining'), default='all')
args = parser.parse_args()
base = Path(__file__).resolve().parent / 'w1' / args.round
base.mkdir(exist_ok=False)
ctypes.windll.kernel32.SetErrorMode(0x8003)
env = dict(os.environ)
env.update(VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin',
           VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation',
           HYLE_TEST_VULKAN_VALIDATE='1', HYLE_VULKAN_VALIDATION='1',
           TRACY_ONLY_LOCALHOST='1')
env.pop('PATH', None)
result = {'status': 'RUNNING', 'scope': 'TopK correction focused correctness; no P1', 'commands': []}
try:
    for suite, pattern, expected in (
        ('compute_route_vulkan',
         'VulkanTopK.RebindingByteOriginsRefreshesFrozenProviderViews' if args.scope == 'remaining' else
         'VulkanTopK.*:VulkanLifetime.ManagedPrefixSurvivesRejectedNativeSuffixUntilDrain',
         1 if args.scope == 'remaining' else 11),
        ('graph_route_vulkan', 'VulkanGraph.TopK*', 2)):
        print('START ' + suite, flush=True)
        executable = Path('C:/hyle-scratch/active-vk/static/bin') / ('hyle_' + suite + '_test.exe')
        command = [str(executable), '--gtest_filter=' + pattern,
                   '--gtest_output=json:' + str(base / (suite + '.json'))]
        begin = time.monotonic()
        with (base / (suite + '.log')).open('w') as stream:
            child = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT,
                                   env=env, timeout=180)
        output = (base / (suite + '.log')).read_text(errors='replace')
        record = {'command': command, 'exit_code': child.returncode,
                  'executable_sha256': hashlib.sha256(executable.read_bytes()).hexdigest(),
                  'log_sha256': hashlib.sha256((base / (suite + '.log')).read_bytes()).hexdigest(),
                  'elapsed_seconds': time.monotonic() - begin, 'path_unset': True}
        result['commands'].append(record)
        print(output[-4500:], flush=True)
        child.check_returncode()
        tests = json.loads((base / (suite + '.json')).read_text())
        assert tests['tests'] == expected and tests['failures'] == 0 and tests['errors'] == 0
        assert tests['disabled'] == 0
        assert not any(x in output for x in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
    result['status'] = 'PASS'
except Exception as error:
    result['status'] = 'FAIL'
    result['failure'] = str(error)
    raise
finally:
    (base / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
