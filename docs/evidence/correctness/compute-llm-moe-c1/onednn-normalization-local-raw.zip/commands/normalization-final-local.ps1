$ErrorActionPreference = 'Stop'
$buildRoot = 'C:\hyle-scratch\active-cpu\static'
$logRoot = 'C:\public\project-hyle\hyle\.scratch\validation\onednn-aa'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
& 'C:\public\project-hyle\hyle\scripts\hyle-windows.ps1' -Action Build -BinaryDir $buildRoot -ExtraArgs @('--parallel','2','--target','hyle_compute_provider_onednn_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests') > (Join-Path $logRoot 'test-braces-build.log') 2>&1
if ($LASTEXITCODE -ne 0) {
  Get-Content -LiteralPath (Join-Path $logRoot 'test-braces-build.log') -Tail 30
  exit $LASTEXITCODE
}
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleNormFinalErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[HyleNormFinalErrorMode]::SetErrorMode(0x8003) | Out-Null
& 'C:\Program Files\CMake\bin\cmake.exe' -E env --unset=PATH 'C:\Program Files\CMake\bin\ctest.exe' --test-dir $buildRoot --output-on-failure --parallel 1 --no-tests=error -R '^hyle_(compute_provider_onednn|compute_route_cpu|graph_route_cpu)_' -LE headers --output-junit (Join-Path $logRoot 'test-braces-ctest.xml') > (Join-Path $logRoot 'test-braces-test.log') 2>&1
$code = $LASTEXITCODE
Copy-Item -LiteralPath (Join-Path $buildRoot 'Testing\Temporary\LastTest.log') -Destination (Join-Path $logRoot 'test-braces-LastTest.log') -Force
Get-Content -LiteralPath (Join-Path $logRoot 'test-braces-test.log') -Tail 25
exit $code
