#!/usr/bin/env bash
set -euo pipefail
task_root=/root/hyle-scratch/active-cpu-z
log_root=/mnt/c/public/project-hyle/hyle/.scratch/validation/onednn-aa
archive=/mnt/c/hyle-scratch/active-cpu/candidate.tar
case "${1:-}" in
  configure)
    test -f "$archive"
    test -f "$task_root/source/src/compute_provider_onednn/normalization_internal.cc"
    sha256sum "$archive" > "$log_root/wsl-source-archive.sha256"
    cmake -S "$task_root/source" -B "$task_root/build" -G Ninja \
      -DCMAKE_C_COMPILER=gcc-14 -DCMAKE_CXX_COMPILER=g++-14 \
      -DCMAKE_BUILD_TYPE=Release -DHYLE_WERROR=ON -DHYLE_STATIC=ON \
      -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF -DHYLE_INSTALL=OFF \
      -DHYLE_TRACE=OFF -DHYLE_SANITIZER=off -DHYLE_TEST_INSTRUMENTATION=OFF \
      -DHYLE_COMPUTE_CPU=ON -DHYLE_COMPUTE_ONEDNN=ON \
      -DHYLE_DEP_SOURCE_CACHE=/root/.cache/hyle/dependencies/v1 \
      -DFETCHCONTENT_FULLY_DISCONNECTED=ON \
      '-DHYLE_DEV_FACTORS=compute_provider_native;compute_provider_onednn;compute_route_cpu;graph_route_cpu;graph_provider_onednn' \
      > "$log_root/wsl-configure.log" 2>&1
    tail -20 "$log_root/wsl-configure.log"
    ;;
  build)
    cmake --build "$task_root/build" --parallel 2 --target \
      hyle_compute_provider_native_tests hyle_compute_provider_onednn_tests \
      hyle_compute_route_cpu_tests hyle_graph_route_cpu_tests \
      hyle_graph_provider_onednn_tests > "$log_root/wsl-build.log" 2>&1
    tail -20 "$log_root/wsl-build.log"
    ;;
  test)
    ctest --test-dir "$task_root/build" --output-on-failure --parallel 1 \
      --no-tests=error -R '^hyle_(compute_provider_(native|onednn)|compute_route_cpu|graph_route_cpu|graph_provider_onednn)_' -LE headers \
      --output-junit "$log_root/wsl-ctest.xml" > "$log_root/wsl-test.log" 2>&1
    cp "$task_root/build/Testing/Temporary/LastTest.log" "$log_root/wsl-LastTest.log"
    cp "$task_root/build/CMakeCache.txt" "$log_root/wsl-CMakeCache.txt"
    sha256sum "$task_root/build"/bin/hyle_compute_provider_{native,onednn}_test \
      "$task_root/build"/bin/hyle_{compute,graph}_route_cpu_test \
      "$task_root/build"/bin/hyle_graph_provider_onednn_test > "$log_root/wsl-artifacts.sha256"
    tail -28 "$log_root/wsl-test.log"
    ;;
  *) exit 2 ;;
esac
