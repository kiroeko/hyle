$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-cpu')
$transfer = [IO.Path]::GetFullPath((Join-Path $taskRoot 'candidate.tar'))
if (-not $transfer.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Transfer path escaped the active task directory'
}
$expected = '82083b55f8b0d70de07c74df689c9f9623c899a6ad10d64ab59acba5ad175c1a'
$receipt = 'C:\public\project-hyle\hyle\.scratch\validation\onednn-aa\wsl-source-archive.sha256'
if (-not (Get-Content -LiteralPath $receipt -Raw).ToLowerInvariant().Contains($expected)) {
  throw 'Validated WSL extraction receipt differs'
}
if (Test-Path -LiteralPath $transfer) {
  if ((Get-FileHash -LiteralPath $transfer -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) {
    throw 'Transfer bytes changed; refuse deletion'
  }
  $size = (Get-Item -LiteralPath $transfer).Length
  Remove-Item -LiteralPath $transfer -Force
  Write-Output ('Removed validated transfer archive: ' + $size + ' bytes')
}
