[CmdletBinding()]
param([ValidateSet('Configure','Build','Verify')][string]$Action)
$ErrorActionPreference = 'Stop'
$sourceRoot = 'C:\public\project-hyle\hyle'
$buildRoot = 'C:\hyle-scratch\active-cpu\static'
$logs = Join-Path $sourceRoot '.scratch\validation\onednn-aa'
$wrapper = Join-Path $sourceRoot 'scripts\hyle-windows.ps1'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$log = Join-Path $logs ('bench-' + $Action.ToLowerInvariant() + '.log')
if ($Action -eq 'Configure') {
  $options = @('-DHYLE_STATIC=ON','-DHYLE_BUILD_BENCH=ON','-DHYLE_BUILD_TESTS=ON',
    '-DCMAKE_BUILD_TYPE=Release','-DHYLE_WERROR=ON','-DHYLE_INSTALL=OFF',
    '-DHYLE_TEST_INSTRUMENTATION=OFF','-DHYLE_SANITIZER=off','-DHYLE_TRACE=OFF',
    '-DHYLE_COMPUTE_ONEDNN=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF',
    '-DHYLE_COMPUTE_VULKAN=OFF',
    '-DFETCHCONTENT_SOURCE_DIR_ONEDNN=C:/public/project-hyle/hyle/.scratch/onednn-lock-v3.13.2/extract/oneDNN-71094df451909e95ceeefc8f64c275cdcbbcdff5')
  & $wrapper -Action Configure -BinaryDir $buildRoot -Factor 'compute_provider_native;compute_provider_onednn;compute_route_cpu;graph_route_cpu;graph_provider_onednn' -ExtraArgs $options > $log 2>&1
} elseif ($Action -eq 'Build') {
  & $wrapper -Action Build -BinaryDir $buildRoot -ExtraArgs @('--parallel','2','--target','hyle_onednn_normalization_bench','hyle_onednn_normalization_bench_placement') > $log 2>&1
} else {
  Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleNormBenchErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
  [HyleNormBenchErrorMode]::SetErrorMode(0x8003) | Out-Null
  $bin = Join-Path $buildRoot 'bin'
  $crt = Get-ChildItem -LiteralPath 'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Redist\MSVC' -Directory |
    Where-Object {Test-Path -LiteralPath (Join-Path $_.FullName 'x64\Microsoft.VC145.CRT')} |
    Sort-Object Name -Descending | Select-Object -First 1
  if (-not $crt) {throw 'CRT not found'}
  Get-ChildItem -LiteralPath (Join-Path $crt.FullName 'x64\Microsoft.VC145.CRT') -Filter '*.dll' -File | Copy-Item -Destination $bin -Force
  & 'C:\Program Files\CMake\bin\cmake.exe' -E env --unset=PATH 'HYLE_BENCH_VERIFY_ONLY=1' (Join-Path $bin 'hyle_onednn_normalization_bench.exe') > $log 2>&1
}
$code = $LASTEXITCODE
Get-Content -LiteralPath $log -Tail 20
exit $code
