import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
META = json.loads((ROOT / 'y35-f2-candidate.json').read_text())
platform = sys.argv[1]
assert platform in ('air', 'mini')
LOGS = ROOT / ('y35-' + META['candidate'][:8])
report = json.loads((LOGS / 'result.json').read_text())
assert report['verdict'] == 'PASS' and report['candidate'] == META['candidate']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for path, digest in META['verified_implementation_files'].items():
    assert sha(ROOT / 'source' / path) == digest, path
for row in report['commands']:
    assert row['exit_code'] == 0 and sha(Path(row['log'])) == row['sha256']
for artifact in report['artifacts']:
    assert sha(Path(artifact['path'])) == artifact['sha256']
files = {str(p.relative_to(LOGS)): p for p in LOGS.rglob('*') if p.is_file()}
files['commands/run-' + platform + '.py'] = ROOT / ('run-y35-f2-' + platform + '.py')
files['commands/pack-y35-f2-platform.py'] = Path(__file__)
files['identity/candidate.json'] = ROOT / 'y35-f2-candidate.json'
for p in LOGS.glob('*.log'):
    assert not any(x in p.read_text(errors='replace') for x in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
archive = ROOT / ('y35-f2-' + platform + '-focused.zip')
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as output:
    for name, path in files.items():
        output.write(path, name)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None
    for name, path in files.items():
        assert hashlib.sha256(output.read(name)).hexdigest() == sha(path)
receipt = {'candidate': META['candidate'], 'product_candidate': META['product_candidate'],
           'platform': platform, 'status': 'PASS', 'scope': 'Y35-F2 static native modules; not three-delivery or performance qualification',
           'result': report, 'archive': archive.name, 'archive_sha256': sha(archive),
           'archive_bytes': archive.stat().st_size, 'members': {name: sha(path) for name, path in files.items()}}
(ROOT / ('y35-f2-' + platform + '-focused.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'platform': platform, 'candidate': META['candidate'],
                  'passed': sum(a.get('passed', a['tests']) for a in report['artifacts']),
                  'skipped': sum(a.get('skipped', 0) for a in report['artifacts']),
                  'archive_bytes': archive.stat().st_size}))
