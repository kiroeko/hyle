"""Fixed local-weight inputs for the Y35 ordinary consumer, not a model forward."""
from pathlib import Path
import hashlib
import json
import os
import struct

for name in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS'):
    os.environ[name] = '1'
import numpy as np

TASK = Path(__file__).resolve().parent
DEST = TASK / 'fixtures'
DEST.mkdir(exist_ok=False)
ORIGINAL = TASK.parent / 'vulkan-c1-fragment/fixtures'
prior = json.loads((ORIGINAL / 'receipt.json').read_text(encoding='utf-8'))
model = Path('C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors')
stat = model.stat()
assert stat.st_size == prior['source_file_size'] and stat.st_mtime_ns == prior['source_file_mtime_ns']
sha = lambda data: hashlib.sha256(data).hexdigest()
with model.open('rb') as stream:
    length = struct.unpack('<Q', stream.read(8))[0]
    header_bytes = stream.read(length)
assert sha(header_bytes) == prior['header_sha256']
header = json.loads(header_bytes)
sources = {}

def decode(raw):
    return (np.frombuffer(raw, dtype='<u2').astype(np.uint32) << 16).view(np.float32).astype(np.float64)

def encode(values):
    bits = np.asarray(values, dtype=np.float32).view(np.uint32)
    return ((bits + np.uint32(0x7fff) + ((bits >> 16) & 1)) >> 16).astype('<u2')

def tensor(suffix):
    name = 'model.language_model.layers.0.' + suffix
    meta = header[name]
    start, end = meta['data_offsets']
    with model.open('rb') as stream:
        stream.seek(8 + length + start)
        raw = stream.read(end - start)
    assert len(raw) == end - start
    sources[name] = dict(meta, sha256=sha(raw))
    if meta['dtype'] == 'F32':
        return np.frombuffer(raw, dtype='<f4').astype(np.float64).reshape(meta['shape'])
    assert meta['dtype'] == 'BF16'
    return decode(raw).reshape(meta['shape'])

table_bytes = (ORIGINAL / 'table.bf16').read_bytes()
assert sha(table_bytes) == next(x['sha256'] for x in prior['files'] if x['file'] == 'table.bf16')
table = decode(table_bytes).reshape(34, 2048)
scale = tensor('input_layernorm.weight') + 1.0
# A deterministic projection fixture from actual tensors. Attention/state and the
# complete layer are absent; this is deliberately not signed as a model forward.
normalized = table / np.sqrt(np.mean(table * table, axis=1, keepdims=True) + 1e-6) * scale
normalized = decode(encode(normalized).tobytes()).reshape(table.shape)
files = {}

def save(name, values, dtype):
    raw = encode(values).tobytes() if dtype == 'BF16' else np.asarray(values, dtype='<f4').tobytes()
    (DEST / name).write_bytes(raw)
    files[name] = {'file': name, 'bytes': len(raw), 'sha256': sha(raw), 'shape': list(values.shape), 'dtype': dtype}

save('a-log.f32', tensor('linear_attn.A_log'), 'F32')
save('dt-bias.f32', tensor('linear_attn.dt_bias'), 'F32')
for suffix, name in [('linear_attn.in_proj_a.weight', 'a.bf16'),
                     ('linear_attn.in_proj_b.weight', 'b.bf16'),
                     ('mlp.gate_proj.weight', 'gate.bf16'),
                     ('mlp.up_proj.weight', 'up.bf16')]:
    projection = normalized @ tensor(suffix).T
    assert np.isfinite(projection).all()
    save(name, projection, 'BF16')
receipt = {
    'kind': 'Y35 fixed local-weight projection inputs; HYLE NOT_RUN; not model-forward evidence',
    'source_id': prior['source_id'], 'source_directory': str(model.parent),
    'reused_verified_input_receipt': {'sha256': sha((ORIGINAL / 'receipt.json').read_bytes()),
                                     'source_file_size': stat.st_size, 'source_file_mtime_ns': stat.st_mtime_ns,
                                     'header_sha256': sha(header_bytes), 'table_sha256': sha(table_bytes)},
    'tensor_sources': sources,
    'generation': 'FP64 normalized actual embedding rows and actual layer0 projection weights; explicit BF16 RNE normalized input and projection output; no attention/state/model execution',
    'rows': 34, 'gate_width': 6144, 'decay_width': 16, 'files': list(files.values()),
    'generator_sha256': sha(Path(__file__).read_bytes()), 'numpy_version': np.__version__,
    'threads': {k: os.environ[k] for k in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS')},
}
(DEST / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'source_id': receipt['source_id'], 'fixture_bytes': sum(x['bytes'] for x in files.values()),
                  'ranges': {name: {'bytes': x['bytes']} for name, x in files.items()}}))
