import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = root.parents[2]
prior = root.parent / 'vulkan-reduction'
candidate = 'f58d26096dac635fe4ff23a141a0194d94faeebb'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
contract = {
    'candidate': candidate, 'product_candidate': 'aa6690c6e5ce5fa7a58706e778052d91504e0c3a',
    'state': 'FROZEN_NOT_RUN', 'scope': 'C1-Y35 local2B weight-derived stable/gate fragments, not model forward',
    'consumer': {p.name: sha(p) for p in (root / 'consumer').iterdir() if p.is_file()},
    'storage': ['F32', 'BF16'], 'batch_time': [[1, 1], [1, 17], [2, 23]],
    'widths': {'stable': 16, 'gate': 6144},
    'modes': ['stable transforms/decay/sigmoid branches', 'packed SwiGLU', 'separate SwiGLU'],
    'reference': 'independent scalar FP64 formulas with operation-level F32 boundaries and final BF16 RNE',
    'tolerance': {'F32': {'relative': 6e-6, 'absolute': 2e-6}, 'BF16': {'relative': 0.008, 'absolute': 2e-7}},
    'per_journey': {'cases': 36, 'runs': 108, 'retained_close': 36, 'quota_zero': 36},
    'slot_schedule': 'one retained first slot, one changing working slot executed twice; Direct Recorder, Graph Invocation',
    'source_id': json.loads((root / 'fixtures/receipt.json').read_text(encoding='utf-8'))['source_id'],
    'fixture_receipt_sha256': sha(root / 'fixtures/receipt.json'),
    'consumer_compile_correction_budget': 2, 'consumer_compile_corrections': 0,
    'product_corrections_used': 2, 'product_correction_budget': 2, 'performance': False,
}
for name in ('verify-delivery.py', 'pack-delivery.py', 'air-delivery.py', 'w1-delivery.py', 'w1-delivery.ps1', 'relocate.ps1'):
    text = (prior / name).read_text(encoding='utf-8')
    text = text.replace('Y34', 'Y35').replace('y34', 'y35').replace('d34', 'd35')
    text = text.replace('Reduction', 'Elementwise').replace('reduction', 'elementwise')
    text = text.replace('923895c58a07bcdb29649ddd89e1b6a14f983065', candidate)
    text = text.replace('cases=72 runs=216 retained_close=72 quota_zero=72', 'cases=36 runs=108 retained_close=36 quota_zero=36')
    text = text.replace("'cases': 72, 'runs': 216, 'retained_after_close': 72, 'quota_zero': 72", "'cases': 36, 'runs': 108, 'retained_after_close': 36, 'quota_zero': 36")
    if name == 'w1-delivery.py':
        text = text.replace("fixtures = root.parent / 'vulkan-c1-fragment/fixtures'", "fixtures = root / 'fixtures'")
        text = text.replace("'assets_sha256': sha(assets),", "'assets_sha256': sha(assets), 'assets': assets.name,")
    (root / name).write_text(text, encoding='utf-8', newline='\n')
contract['drivers'] = {name: sha(root / name) for name in ('verify-delivery.py', 'pack-delivery.py', 'air-delivery.py', 'w1-delivery.py', 'w1-delivery.ps1', 'relocate.ps1')}
(root / 'consumer-contract.json').write_text(json.dumps(contract, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'candidate': candidate, 'consumer': contract['consumer'], 'cases_each': 36, 'runs_each': 108}))
