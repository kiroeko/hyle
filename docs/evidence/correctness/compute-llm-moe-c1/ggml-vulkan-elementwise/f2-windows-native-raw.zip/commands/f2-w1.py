import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('C:/public/project-hyle/hyle')
TASK = Path(__file__).resolve().parent
VARIANT = sys.argv[1]
assert VARIANT in ('static', 'shared')
BUILD = Path('C:/hyle-scratch/active-vk') / VARIANT
CANDIDATE = 'aa6690c6e5ce5fa7a58706e778052d91504e0c3a'
CMAKE = 'C:/Program Files/CMake/bin/cmake.exe'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == CANDIDATE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
changes = subprocess.check_output(['git', 'diff', '--name-only', '6af6bfe4', CANDIDATE, '--',
                                 'include', 'src', 'third_party', 'tests', 'cmake', 'CMakeLists.txt'], cwd=ROOT, text=True).splitlines()
assert changes == ['src/compute_route_vulkan/vulkan_elementwise.cc'], changes
ctypes.windll.kernel32.SetErrorMode(0x8003)
OUT = TASK / ('f2-w1-' + VARIANT)
OUT.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
runtime = os.environ.copy()
runtime.pop('PATH', None)
runtime.update(HYLE_VULKAN_VALIDATION='1', HYLE_TEST_VULKAN_VALIDATE='1',
               VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin',
               VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LOADER_LAYERS_DISABLE='~implicit~')
prior = json.loads((ROOT / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-elementwise/windows-native.json').read_text(encoding='utf-8'))
provider = next(row for row in prior['qualified'][VARIANT]['suites'] if row['label'] == 'compute_provider_ggml_vulkan')
provider_exe = BUILD / 'bin/hyle_compute_provider_ggml_vulkan_test.exe'
assert sha(provider_exe) == provider['executable_sha256']
prior_record = json.loads((TASK / ('f1-w1' if VARIANT == 'static' else 'shared-w1') / 'result.json').read_text(encoding='utf-8'))
assert all(sha(BUILD / 'bin' / name) == digest for name, digest in prior_record['dlls'].items())
commands_before = json.loads((BUILD / 'compile_commands.json').read_text(encoding='utf-8'))
provider_commands = [row for row in commands_before if 'compute_provider_ggml_vulkan' in row['file'] or 'source-fb15744d' in row['file']]
assert provider_commands
record = {'candidate': CANDIDATE, 'scope': 'C1-Y35 F2 W1 ' + VARIANT + ' native modules only',
          'status': 'RUNNING', 'commands': [], 'build_parallelism': 2, 'heavy_steps': 'serial',
          'runtime_PATH_unset': True, 'runtime_environment': {key: runtime[key] for key in (
              'HYLE_VULKAN_VALIDATION', 'HYLE_TEST_VULKAN_VALIDATE', 'VK_LAYER_PATH', 'VK_INSTANCE_LAYERS', 'VK_LOADER_LAYERS_DISABLE')},
          'reused_provider': provider, 'provider_source_baseline': prior['candidate'],
          'provider_compile_commands': provider_commands}

def save():
    (OUT / 'result.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')

def run(label, argv, native=False):
    print('START ' + VARIANT + ' ' + label, flush=True)
    log = OUT / (label + '.log')
    start = time.monotonic()
    with log.open('wb') as stream:
        stream.write((json.dumps(argv) + '\n').encode())
        stream.flush()
        result = subprocess.run(argv, cwd=ROOT, env=runtime if native else os.environ,
                                stdout=stream, stderr=subprocess.STDOUT, creationflags=0x08000000)
    row = {'label': label, 'argv': argv, 'exit_code': result.returncode, 'log': log.name,
           'sha256': sha(log), 'seconds': time.monotonic() - start}
    record['commands'].append(row)
    if result.returncode:
        record['status'] = 'FAIL'
        save()
        print('FAIL ' + label, flush=True)
        raise SystemExit(result.returncode)
    save()
    print('PASS ' + VARIANT + ' ' + label, flush=True)
    return row

save()
run('configure', [CMAKE, '-S', str(ROOT), '-B', str(BUILD), '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
                  '-DHYLE_DEV_FACTORS=compute_provider_ggml_vulkan,compute_route_vulkan,graph_route_vulkan',
                  '-DHYLE_BUILD_TESTS=ON', '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_INSTALL=OFF',
                  '-DHYLE_TEST_INSTRUMENTATION=OFF', '-DHYLE_WERROR=ON', '-DHYLE_COMPUTE_VULKAN=ON',
                  '-DHYLE_STATIC=' + ('ON' if VARIANT == 'static' else 'OFF'),
                  '-DCMAKE_TOOLCHAIN_FILE=' + str(ROOT / '.scratch/validation/vulkan-reduction/global/remaining-toolchain.cmake')])
commands_after = json.loads((BUILD / 'compile_commands.json').read_text(encoding='utf-8'))
assert provider_commands == [row for row in commands_after if 'compute_provider_ggml_vulkan' in row['file'] or 'source-fb15744d' in row['file']]
run('build', [CMAKE, '--build', str(BUILD), '--config', 'Release', '--target',
              'hyle_compute_route_vulkan_tests', 'hyle_graph_route_vulkan_tests', '--parallel', '2'])
versions = sorted(p for p in Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Redist/MSVC').iterdir()
                  if (p / 'x64/Microsoft.VC145.CRT').is_dir())
for source in (versions[-1] / 'x64/Microsoft.VC145.CRT').glob('*.dll'):
    shutil.copy2(source, BUILD / 'bin' / source.name)
shutil.copy2('C:/Windows/System32/vulkan-1.dll', BUILD / 'bin/vulkan-1.dll')
record['dlls'] = {p.name: sha(p) for p in (BUILD / 'bin').glob('*.dll')}
changed_dlls = [name for name, digest in prior_record['dlls'].items() if record['dlls'][name] != digest]
assert all(name == 'hyle_compute_route_vulkan.dll' for name in changed_dlls), changed_dlls
assert sha(provider_exe) == provider['executable_sha256']
record['provider_artifact_identity_verified'] = True
record['changed_dlls'] = changed_dlls
for component, expected in [('compute_route_vulkan', 95), ('graph_route_vulkan', 27 if VARIANT == 'static' else 26)]:
    exe = BUILD / 'bin' / ('hyle_' + component + '_test.exe')
    report = OUT / (component + '.json')
    row = run(component, [str(exe), '--gtest_output=json:' + str(report)], True)
    data = json.loads(report.read_text(encoding='utf-8'))
    row.update(tests=data['tests'], failures=data['failures'], executable_sha256=sha(exe), gtest_sha256=sha(report))
    log = (OUT / row['log']).read_text(encoding='utf-8', errors='replace')
    ok = data['tests'] == expected and data['failures'] == 0 and data.get('disabled', 0) == 0
    ok = ok and all(t['status'] == 'RUN' and t['result'] == 'COMPLETED' for group in data['testsuites'] for t in group['testsuite'])
    ok = ok and not any(marker in log for marker in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
    if not ok:
        record['status'] = 'FAIL'
        save()
        raise SystemExit('qualification metadata or validation-layer failure')
    save()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == CANDIDATE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
record['status'] = 'PASS'
record['passed_cases'] = provider['tests'] + sum(row.get('tests', 0) for row in record['commands'])
save()
print('Y35-F2 W1 ' + VARIANT + ' PASS ' + str(record['passed_cases']) + ' cases including 19 identity-reused provider cases', flush=True)
