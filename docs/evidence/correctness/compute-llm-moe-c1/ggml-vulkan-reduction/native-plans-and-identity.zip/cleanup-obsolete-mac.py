import hashlib
import json
from pathlib import Path
import shutil
import sys

root = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918').resolve()
platform = sys.argv[1]
assert platform in ('air', 'mini')
receipt_path = root / ('y34-' + platform + '-cleanup.json')
assert not receipt_path.exists()
proof = json.loads((root / ('y34-' + platform + '-focused.json')).read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert proof['status'] == 'PASS'
assert sha(root / proof['archive']) == proof['archive_sha256']
meta = json.loads((root / 'y34-corrected-candidate.json').read_text())
for name, expected in meta['verified_implementation_files'].items():
    assert sha(root / 'source' / name) == expected, name
build = root / 'build-vulkan-static'
old = 'source-641c36f67482a39f4540361598722ce0c2a2dab1d841d75b9e858552c6ab46cc'
new = 'source-5b19b4886eaac1040c8f69820c9d2320f00c6caf57690d6328996f35e238b5a3'
assert new in (build / 'build.ninja').read_text()
assert old not in (build / 'build.ninja').read_text()
assert old not in (build / 'CMakeCache.txt').read_text()
targets = [build / 'src/compute_provider_ggml_vulkan' / old]
if platform == 'mini':
    targets.append(root / 'source-prior-y34-11804be7')
rows = []
for target in targets:
    assert not target.is_symlink()
    assert target.resolve().is_relative_to(root) and target.resolve() != root
    assert target != root / 'source' and target != build
    if not target.exists():
        continue
    assert target.is_dir()
    entries = list(target.rglob('*'))
    assert not any(p.is_symlink() and p.is_dir() for p in entries)
    files = [p for p in entries if p.is_file() and not p.is_symlink()]
    rows.append({'path': str(target), 'files': len(files), 'bytes': sum(p.stat().st_size for p in files)})
for row in rows:
    shutil.rmtree(row['path'])
    assert not Path(row['path']).exists()
receipt = {'scope': 'Y34 proof-verified obsolete private source copies only', 'platform': platform,
           'removed': rows, 'bytes': sum(row['bytes'] for row in rows),
           'retained': ['current source/build', 'vendor source/cache', 'SDKs', 'proof archives']}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
