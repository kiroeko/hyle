$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-reduction'
$receiptPath = Join-Path $taskRoot 'cleanup-obsolete-w1-sources.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup receipt already exists; inspect it first.' }
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'proof\windows-native.json') -Raw -Encoding utf8 | ConvertFrom-Json
if ($proof.status -ne 'PASS') { throw 'Native qualification is not PASS.' }
$proofHash = (Get-FileHash -LiteralPath (Join-Path $taskRoot 'proof\windows-native-raw.zip') -Algorithm SHA256).Hash.ToLowerInvariant()
if ($proofHash -ne $proof.archive_sha256) { throw 'Native proof archive identity mismatch.' }
$buildRoot = (Resolve-Path -LiteralPath 'C:\hyle-scratch\active-vk').Path
$oldName = 'source-641c36f67482a39f4540361598722ce0c2a2dab1d841d75b9e858552c6ab46cc'
$newName = 'source-5b19b4886eaac1040c8f69820c9d2320f00c6caf57690d6328996f35e238b5a3'
$plan = @()
foreach ($linkage in @('static', 'shared')) {
  $build = Join-Path $buildRoot $linkage
  $provider = Join-Path $build 'src\compute_provider_ggml_vulkan'
  $target = (Resolve-Path -LiteralPath (Join-Path $provider $oldName)).Path
  $expected = [IO.Path]::GetFullPath((Join-Path $provider $oldName))
  if ($target -ne $expected -or -not $target.StartsWith($buildRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing target outside intended build workspace: $target"
  }
  if (-not (Test-Path -LiteralPath (Join-Path $provider $newName) -PathType Container)) { throw 'Current private source is absent.' }
  $ninja = Get-Content -LiteralPath (Join-Path $build 'build.ninja') -Raw
  $cache = Get-Content -LiteralPath (Join-Path $build 'CMakeCache.txt') -Raw
  if ($ninja.Contains($oldName) -or $cache.Contains($oldName) -or -not $ninja.Contains($newName)) {
    throw 'Current build still references the obsolete source, or new identity is absent.'
  }
  $items = @(Get-Item -LiteralPath $target -Force) + @(Get-ChildItem -LiteralPath $target -Recurse -Force)
  $links = @($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })
  foreach ($link in $links) {
    if ($link.PSIsContainer -or $link.LinkType -ne 'SymbolicLink' -or $link.FullName -ne (Join-Path $target '.pi\SYSTEM.md')) {
      throw 'Refusing unexpected reparse point.'
    }
  }
  $files = @($items | Where-Object { -not $_.PSIsContainer })
  $plan += [ordered]@{ path = $target; files = $files.Count; bytes = [long](($files | Measure-Object Length -Sum).Sum); links = @($links | ForEach-Object { $_.FullName }) }
}
foreach ($entry in $plan) {
  foreach ($linkPath in $entry.links) {
    # Remove only the named file link, never its target or a directory junction.
    Remove-Item -LiteralPath $linkPath -Force
  }
  Remove-Item -LiteralPath $entry.path -Recurse -Force
  if (Test-Path -LiteralPath $entry.path) { throw 'Target remains after cleanup.' }
}
$receipt = [ordered]@{
  scope = 'Only obsolete build-local ggml source copies after Y34 static/shared proof verification'
  retained = @('current source-5b19b488 copies', 'active builds and binaries', 'shared dependency cache', 'SDKs', 'canonical ggml checkout')
  removed = $plan
  bytes = [long](($plan | ForEach-Object { [long]$_.bytes } | Measure-Object -Sum).Sum)
}
$json = $receipt | ConvertTo-Json -Depth 6
[IO.File]::WriteAllText($receiptPath, $json.Replace("`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$json
