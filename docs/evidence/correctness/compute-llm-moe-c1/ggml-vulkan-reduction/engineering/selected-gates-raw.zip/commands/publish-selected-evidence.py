"""Publish Y34 engineering evidence only after every selected gate is qualified."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path('C:/public/project-hyle/hyle')
TASK = Path(__file__).resolve().parent
CANDIDATE = 'ec240ac9392cb8144d326d8407d9af4b8456026a'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def write(path, text):
    path.write_text(text, encoding='utf-8', newline='\n')


def append(path, text):
    old = path.read_text(encoding='utf-8')
    assert text.splitlines()[0] not in old
    write(path, old.rstrip() + '\n\n' + text.rstrip() + '\n')


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == CANDIDATE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
selected = read(TASK / 'selected-gates-result.json')
delivery = read(TASK / 'remaining-deliveries-receipt.json')
cleanup = read(TASK / 'remaining-deliveries-cleanup.json')
loc = read(TASK / 'current-loc.json')
assert selected['status'] == delivery['status'] == 'PASS'
assert selected['candidate'] == delivery['candidate'] == cleanup['candidate'] == CANDIDATE
assert selected['selected_gate_count'] == len(selected['gates']) == 112
assert all(g['status'] == 'PASS' for g in selected['gates'])
assert len(delivery['components']) == 15
assert sum(len(c['journeys']) for c in delivery['components']) == 45
assert len(cleanup['removed']) == 45
assert loc['repository']['commit'] == CANDIDATE and loc['self_check'] == 'pass'
for archive, digest in [(TASK / selected['archive']['path'], selected['archive']['sha256']),
                        (TASK / delivery['archive'], delivery['archive_sha256'])]:
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == digest
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None

destination = ROOT / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-reduction/engineering'
destination.mkdir(exist_ok=False)
for name in ('selected-gates-result.json', 'selected-gates-raw.zip',
             'remaining-deliveries-receipt.json', 'remaining-deliveries-raw.zip',
             'remaining-deliveries-cleanup.json', 'current-loc.json'):
    shutil.copyfile(TASK / name, destination / name)
removed = int(cleanup['logical_bytes'])
write(destination / 'README.md', f'''# C1-Y34 所选工程验收

不可变候选 `{CANDIDATE}`，产品仍为 `05581df8`，测试编译修正为 `11804be7`。
[结果](selected-gates-result.json)与[原始日志](selected-gates-raw.zip)覆盖112项selected：
96项maintenance/configure/correctness/headers、1项component-contract、15项默认三交付。
8项未选理由保留；四个完整gate复用既有Y34证据，ggml Provider另复用其C++ suite，
源码合同及MASM组合本次实际执行。其余gate实际执行通过，没有伪造selector cache收据。

复用核对原归档CRC/SHA、不可变源码差异、EXE/DLL hash、设备/驱动与编译参数。
重新configure后163条原有编译命令逐条一致，相关编译选项不变；保留before/after证据。
Direct使用`11804be7`的91例，Provider/Graph分别使用产品候选的19/26例；公开头使用
`923895c5`的两个既有gate。没有因文档提交重跑已通过的GPU数值回归。

[交付](remaining-deliveries-receipt.json)与[交付日志](remaining-deliveries-raw.zip)证明15个
默认产品的45条source/static/shared消费，含重定位和接口/导出检查。header-only组件签
实际接口包消费，不虚构动态库。这里不替代此前W1/Air的实际归约/Softmax/L2六条GPU交付。
重型步骤串行、并行度2，Windows DLL邻exe、PATH隔离、SetErrorMode禁错误弹窗。

本次component-contract在初始化后的独立缓存放置已锁定Highway archive；无需修改产品
或公共工具。[清理](remaining-deliveries-cleanup.json)在核验归档后删除45个重复producer，
释放{removed:,}逻辑字节；保留SDK、安装消费者、当前缓存和共享依赖。

[统一统计](current-loc.json)：Compute+Graph实现48,737行/197文件，不含测试/第三方。
本轮产品没有变化，没有P1、性能赢家或自有实现淘汰裁决。Y34本批适用工程门完成；C1其余
Provider覆盖、完整成本优选和CPU Q2 BLOCKED保持，不签C1、共同矩阵或整模型完成。
''')

brief = f'''### Y34 所选工程门：已完成

候选`ec240ac9`的[112项所选工程门](../../../../evidence/correctness/compute-llm-moe-c1/ggml-vulkan-reduction/engineering/README.md)
全部资格化：96项普通工程检查、1项component-contract、15项默认三交付（45条消费）。
既有Y34三个C++ suite及两个公开头按源码、产物、163条未变编译命令与机器身份复用；
Provider的源码/MASM组合另行执行，未把旧版本门直接代签为本候选。8项未选理由保留。
本次没有产品、测试、公共工具改动或P1；W1/Air此前432例/1296次实际GPU三交付不重复。

归档核验后清理45个重复producer，共{removed:,}逻辑字节。实现仍48,737行/197文件。
本批验收到此停止重复；C1其余Provider覆盖、完整成本比较/条件规则/存量淘汰与CPU Q2
BLOCKED仍待处理，C1及共同矩阵没有签收。C1全部适用验收完成后通知用户，在C2前等待提问。
'''
for card in ['llm-moe-c1-vulkan-reduction.md', 'llm-moe-c1-tensor-state.md',
             'llm-moe-c1-ggml-vulkan-region.md']:
    append(ROOT / 'docs/implementation/tasks/compute' / card, brief)

readme = destination.parent / 'README.md'
text = readme.read_text(encoding='utf-8')
old = '''selected工程余门尚未完成。[选择计划归档](native-plans-and-identity.json)记录112项selected、
8项未选理由，不能由本目录已完成的原生/真实片段三交付/公开头结果推导112项PASS。'''
assert old in text
write(readme, text.replace(old, '''[当前工程验收](engineering/README.md)已完成112项selected，8项未选理由保留；
15个默认产品的45条三交付通过，旧证据按身份复用。本批Y34验收停止重复。
此前[阶段记录](delivery-progress.json)保留当时工程门尚未完成的事实。'''))

audit = ROOT / 'docs/implementation/tasks/compute/llm-moe-c1-provider-reuse-audit.md'
text = audit.read_text(encoding='utf-8')
text = text.replace('2026-09-19按`923895c5`', '2026-09-19按`ec240ac9`')
text = text.replace('核对余域，完成工程余门、完整成本比较、条件规则及自有重复路径取舍',
                    '本批工程门已通过；核对余域，完成完整成本比较、条件规则及自有重复路径取舍')
text = text.replace('selected工程余门、完整成本和存量取舍未签收',
                    'selected112工程门已通过；完整成本和存量取舍未签收')
write(audit, text)

registry_path = ROOT / 'docs/implementation/module-status.json'
registry = read(registry_path)
owners = {'compute_route_vulkan', 'graph_route_vulkan', 'compute_provider_ggml_vulkan'}
for module in registry['modules']:
    if module['module'] in owners:
        assert module['state'] == 'AUDITED'
        module['summary'] = ('LLM/MoE C1-Y34 AUDITED：产品05581df8的成熟Sum/Mean/Softmax已完成'
            'W1 static/shared、Air/Mini适用模块回归和W1/Air真实归约/概率/L2六交付432例/1296次；'
            'ec240ac9的112项所选工程门及45条默认三交付通过，原有Y34模块证据按身份复用。'
            '本批停止重复验证；C1其余Provider覆盖、完整成本优选/淘汰及CPU Q2 BLOCKED保持。')
assert sum(m['module'] in owners for m in registry['modules']) == 3
write(registry_path, json.dumps(registry, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'published': str(destination.relative_to(ROOT)), 'selected': 112,
                  'journeys': 45, 'cleanup_logical_bytes': removed}))
