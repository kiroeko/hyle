"""Verify existing Y34 evidence before reusing five selected module gates."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(output, value):
    (output / 'reuse-proof.json').write_text(
        json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def cache_values(text):
    return {line.split(':', 1)[0]: line.split('=', 1)[1]
            for line in text.splitlines()
            if line and not line.startswith(('#', '//')) and ':' in line and '=' in line}


def prepare(root, build, output):
    evidence = root / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-reduction'
    proof = {'compatible': False, 'gates': {}, 'archives': [], 'source_deltas': {}}
    receipts = {}
    for name, member in [('windows-native', 'first-w1/result.json'),
                         ('windows-test-correction', 'result.json'),
                         ('delivery-inputs-and-headers', 'windows/result.json')]:
        manifest = json.loads((evidence / (name + '.json')).read_text(encoding='utf-8'))
        archive = evidence / manifest['archive']
        assert sha(archive) == manifest['archive_sha256']
        with zipfile.ZipFile(archive) as bundle:
            assert bundle.testzip() is None
            receipt = json.loads(bundle.read(member))
            assert receipt['status'] == 'PASS'
            base = member.rsplit('/', 1)[0] + '/' if '/' in member else ''
            for command in receipt['commands']:
                assert command['exit_code'] == 0
                assert hashlib.sha256(bundle.read(base + command['log'])).hexdigest() == command['sha256']
            if name == 'windows-native':
                proof['original_cache'] = cache_values(bundle.read('static/CMakeCache.txt').decode('utf-8'))
        receipts[name] = receipt
        proof['archives'].append({'file': str(archive.relative_to(root)),
                                  'sha256': manifest['archive_sha256'], 'member': member})
        changed = subprocess.check_output(
            ['git', 'diff', '--name-only', receipt['candidate'], 'HEAD'], cwd=root, text=True).splitlines()
        non_docs = [p for p in changed if not p.startswith(('docs/', 'evidence/'))]
        expected = ['tests/compute_route_vulkan/reduction_test.cc'] if name == 'windows-native' else []
        assert non_docs == expected, (name, non_docs)
        proof['source_deltas'][receipt['candidate']] = {
            'non_documentation_files': non_docs, 'all_changed_files': changed}

    for factor, source in [('compute_provider_ggml_vulkan', 'windows-native'),
                           ('compute_route_vulkan', 'windows-test-correction'),
                           ('graph_route_vulkan', 'windows-native')]:
        receipt = receipts[source]
        command = next(c for c in receipt['commands'] if c.get('label') == factor)
        executable = build / 'bin' / ('hyle_' + factor + '_test.exe')
        assert sha(executable) == command['executable_sha256']
        for name, digest in receipt['dlls'].items():
            assert sha(build / 'bin' / name) == digest, name
        proof['gates']['factor:' + factor] = {
            'candidate': receipt['candidate'], 'tests': command['tests'],
            'scope': 'C++ suite only; source and MASM composition are executed separately',
            'executable': str(executable), 'executable_sha256': command['executable_sha256'],
            'receipt': source + '.json', 'runtime_DLL_hashes_match': True}
    headers = receipts['delivery-inputs-and-headers']
    assert sha(build / 'CMakeCache.txt') == headers['build_cache_sha256']
    for command in headers['commands']:
        proof['gates'][command['id']] = {
            'candidate': headers['candidate'], 'receipt': 'delivery-inputs-and-headers.json',
            'original_log_sha256': command['sha256']}
    gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=uuid,driver_version',
                                   '--format=csv,noheader'], text=True).strip()
    assert gpu == 'GPU-e7376560-6f5d-ec19-6ee4-3dd3a2c81ef8, 610.62', gpu
    proof['gpu'] = gpu
    shutil.copy2(build / 'compile_commands.json', output / 'compile-commands-before.json')
    shutil.copy2(build / 'CMakeCache.txt', output / 'CMakeCache-before.txt')
    write(output, proof)
    return proof


def check_configure(proof, build, output):
    def commands(path):
        return {(c['file'], c['output']): c['command']
                for c in json.loads(path.read_text(encoding='utf-8'))}
    before = commands(output / 'compile-commands-before.json')
    after = commands(build / 'compile_commands.json')
    changed = [key[0] for key, value in before.items() if after.get(key) != value]
    current = cache_values((build / 'CMakeCache.txt').read_text(encoding='utf-8'))
    original = proof.pop('original_cache')
    keys = ['CMAKE_CXX_COMPILER', 'CMAKE_CXX_FLAGS', 'CMAKE_CXX_FLAGS_RELEASE',
            'CMAKE_BUILD_TYPE', 'HYLE_STATIC', 'HYLE_COMPUTE_VULKAN',
            'HYLE_TEST_INSTRUMENTATION', 'HYLE_WERROR']
    drift = {k: [original.get(k), current.get(k)] for k in keys
             if original.get(k) != current.get(k)}
    proof['configure_check'] = {'previous_compile_entries': len(before),
                              'changed_previous_commands': changed, 'relevant_cache_drift': drift,
                              'current_compile_commands_sha256': sha(build / 'compile_commands.json')}
    proof['compatible'] = not changed and not drift
    shutil.copy2(build / 'CMakeCache.txt', output / 'CMakeCache-after.txt')
    shutil.copy2(build / 'compile_commands.json', output / 'compile-commands-after.json')
    write(output, proof)
    print('Existing Y34 evidence compatible: ' + str(proof['compatible']), flush=True)
