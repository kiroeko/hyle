"""Archive the executed Y34 commands without minting selector cache receipts."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[4]
TASK = Path(__file__).resolve().parent
CANDIDATE = 'ec240ac9392cb8144d326d8407d9af4b8456026a'
sha = lambda data: hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == CANDIDATE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
files = {}
gates = []
plans = []
for group, count in (('native', 96), ('contract', 1), ('delivery', 15)):
    folder = TASK / ('remaining-' + group)
    result = json.loads((folder / 'result.json').read_text(encoding='utf-8'))
    assert result['status'] == 'PASS' and len(result['gates']) == count
    assert result['candidate'] == CANDIDATE
    assert sha((folder / 'plan.json').read_bytes()) == result['plan_sha256']
    plan = json.loads((folder / 'plan.json').read_text(encoding='utf-8'))
    assert plan['candidate_commit'] == CANDIDATE
    plans.append(plan)
    for path in folder.iterdir():
        if path.is_file(): files[group + '/' + path.name] = path.read_bytes()
    for gate in result['gates']:
        assert gate['status'] in ('PASS', 'REUSED')
        if 'reuse' in gate:
            proof = json.loads((folder / 'reuse-proof.json').read_text(encoding='utf-8'))
            assert proof['compatible'] and proof['gates'][gate['id']] == gate['reuse']
        for command in gate['commands']:
            assert command['exit_code'] == 0
            assert sha((folder / command['log']).read_bytes()) == command['sha256']
            if 'ctest_detail' in command:
                detail = command['ctest_detail']
                assert sha((folder / detail['log']).read_bytes()) == detail['sha256']
        gates.append({'id': gate['id'], 'status': 'PASS', 'group': group,
                      'execution': gate['status'], 'reused_evidence': gate.get('reuse')})
assert len(gates) == 112 and len({g['id'] for g in gates}) == 112
expected = {g['id'] for g in plans[0]['selected_gates']}
assert expected == {g['id'] for g in gates}
assert all({g['id'] for g in p['selected_gates']} == expected for p in plans)

for path in TASK.iterdir():
    if (path.is_file() and path.name != 'selected-gates-raw.zip'
            and not path.name.endswith('-source-notes.json')
            and path.suffix in ('.py', '.ps1', '.cmd', '.cmake', '.json', '.log', '.zip')):
        files['commands/' + path.name] = path.read_bytes()
build = Path('C:/hyle-scratch/active-vk/static')
for path in (build / 'CMakeCache.txt', *build.glob('CMakeFiles/*/CMakeCXXCompiler.cmake')):
    files['native-build/' + path.relative_to(build).as_posix()] = path.read_bytes()
artifacts = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
             for p in sorted((build / 'bin').glob('*test*.exe'))}
archive = TASK / 'selected-gates-raw.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(files.items()): z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(files)
    for name, data in files.items(): assert z.read(name) == data
record = {
    'schema': 'hyle.c1-selected-validation/v1', 'candidate': CANDIDATE,
    'candidate_tree': plans[0]['candidate_tree'], 'baseline': plans[0]['baseline_commit'],
    'status': 'PASS', 'selected_gate_count': 112, 'gates': gates,
    'skipped_gates': plans[0]['skipped_gates'], 'native_artifacts': artifacts,
    'fixture_correction': None,
    'reuse': 'Y34 immutable source, matching EXE/DLL hashes, unchanged 163 compilation commands, same machine/driver; C++ suites and two headers reused; source/MASM tests executed.',
    'limits': ['Windows correctness, headers, component isolation, and default source/static/shared deliveries only.',
               'Apple runtime gates are not applicable on Windows; OFF headers are not Apple runtime acceptance.',
               'No P1 or route winner/retirement verdict. CPU Q2 qualification remains BLOCKED.',
               'No C1 package, matrix, or whole-model completion claim.'],
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
                'files': {k: {'bytes': len(v), 'sha256': sha(v)} for k, v in sorted(files.items())}}
}
with (TASK / 'selected-gates-result.json').open('x', encoding='utf-8', newline='\n') as f:
    f.write(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'gates': len(gates), 'archive_bytes': archive.stat().st_size}))
