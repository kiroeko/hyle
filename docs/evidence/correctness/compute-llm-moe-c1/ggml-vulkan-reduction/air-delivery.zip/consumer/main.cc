#include <hyle/graph/vulkan.h>

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <expected>
#include <filesystem>
#include <fstream>
#include <limits>
#include <span>
#include <utility>
#include <vector>

namespace c = hyle::compute;
namespace v = c::vulkan;
namespace g = hyle::graph;
namespace gv = g::vulkan;
using hyle::Result;
using hyle::Status;
constexpr std::size_t table_width = 2048;
constexpr std::size_t table_rows = 34;
constexpr float epsilon = 1e-6F;
enum class Mode { Sum, Mean, Probability, Boolean, Additive, L2 };

template <class T>
Result<std::vector<T>> read(const std::filesystem::path &path,
                            std::size_t count) {
  std::ifstream file(path, std::ios::binary | std::ios::ate);
  if (!file || file.tellg() != static_cast<std::streamoff>(count * sizeof(T)))
    return std::unexpected(Status::DataLoss("fixture byte size"));
  std::vector<T> result(count);
  file.seekg(0);
  if (!file.read(reinterpret_cast<char *>(result.data()),
                 static_cast<std::streamsize>(count * sizeof(T))))
    return std::unexpected(Status::DataLoss("fixture read"));
  return result;
}

float decode(std::uint16_t value) {
  return std::bit_cast<float>(static_cast<std::uint32_t>(value) << 16);
}
std::uint16_t encode(double value) {
  auto bits = std::bit_cast<std::uint32_t>(static_cast<float>(value));
  bits += 0x7fffU + ((bits >> 16) & 1U);
  return static_cast<std::uint16_t>(bits >> 16);
}

bool masked(Mode mode) {
  return mode == Mode::Boolean || mode == Mode::Additive;
}
c::Operation operation(Mode mode) {
  if (mode == Mode::Sum || mode == Mode::Mean)
    return c::Operation(c::Reduce{.kind = mode == Mode::Sum
                                              ? c::ReductionKind::kSum
                                              : c::ReductionKind::kMean,
                                  .axes = c::Axes::from(std::array{-1}).value(),
                                  .keep_dimensions = true,
                                  .accumulation_type = c::DataType::kFloat32});
  return c::Operation(
      c::Softmax{.scale = mode == Mode::Boolean    ? -0.5F
                          : mode == Mode::Additive ? 1.25F
                                                   : 0.5F,
                 .mask = mode == Mode::Boolean    ? c::MaskKind::kBoolean
                         : mode == Mode::Additive ? c::MaskKind::kAdditive
                                                  : c::MaskKind::kNone,
                 .accumulation_type = c::DataType::kFloat32});
}

Result<v::Tensor> upload(const v::Context &context,
                         const c::TensorDesc &description,
                         std::span<const double> values) {
  if (description.data_type() == c::DataType::kFloat32) {
    std::vector<float> packed;
    for (double value : values)
      packed.push_back(static_cast<float>(value));
    return context.upload(description, std::as_bytes(std::span(packed)));
  }
  if (description.data_type() == c::DataType::kBool) {
    std::vector<std::uint8_t> packed;
    for (double value : values)
      packed.push_back(value != 0 ? 1 : 0);
    return context.upload(description, std::as_bytes(std::span(packed)));
  }
  std::vector<std::uint16_t> packed;
  for (double value : values)
    packed.push_back(encode(value));
  return context.upload(description, std::as_bytes(std::span(packed)));
}

Result<std::vector<std::byte>> bytes(const v::Context &context,
                                     const v::Tensor &tensor) {
  HYLE_ASSIGN_OR_RETURN(auto size, tensor.description().required_bytes());
  std::vector<std::byte> result(size);
  HYLE_RETURN_IF_ERROR(context.download(tensor, result));
  return result;
}

// Scalar FP64 formulas with the operation contract's explicit F32 boundaries.
std::vector<std::vector<double>> reference(std::span<const double> input,
                                           std::span<const double> mask,
                                           std::size_t width, Mode mode) {
  const bool reduction = mode == Mode::Sum || mode == Mode::Mean;
  std::vector<std::vector<double>> results{
      std::vector<double>(reduction ? input.size() / width : input.size())};
  if (mode == Mode::L2)
    results.emplace_back(input.size() / width);
  for (std::size_t row = 0; row < input.size() / width; ++row) {
    const auto values = input.subspan(row * width, width);
    double sum = 0;
    if (reduction || mode == Mode::L2) {
      for (double value : values)
        sum += mode == Mode::L2 ? static_cast<float>(value * value) : value;
      if (reduction) {
        results[0][row] =
            mode == Mode::Mean ? sum / static_cast<double>(width) : sum;
      } else {
        results[1][row] = sum;
        const float shifted = static_cast<float>(sum) + epsilon;
        const float inverse =
            static_cast<float>(1.0 / std::sqrt(static_cast<double>(shifted)));
        for (std::size_t column = 0; column < width; ++column)
          results[0][row * width + column] =
              static_cast<float>(values[column]) * inverse;
      }
      continue;
    }
    const auto probability = *operation(mode).get_if<c::Softmax>();
    std::vector<double> logits(width);
    for (std::size_t column = 0; column < width; ++column) {
      const float scaled =
          static_cast<float>(values[column]) * probability.scale;
      float value = scaled;
      if (mode == Mode::Boolean && mask[column] == 0)
        value = -std::numeric_limits<float>::infinity();
      if (mode == Mode::Additive)
        value = scaled + static_cast<float>(mask[column]);
      logits[column] = value;
    }
    const double maximum = *std::max_element(logits.begin(), logits.end());
    for (double value : logits)
      sum += std::exp(value - maximum);
    for (std::size_t column = 0; column < width; ++column)
      results[0][row * width + column] =
          std::exp(logits[column] - maximum) / sum;
  }
  return results;
}

Status verify(const v::Context &context, const v::Tensor &tensor,
              std::span<const double> expected) {
  HYLE_ASSIGN_OR_RETURN(auto count, tensor.description().element_count());
  if (count != expected.size())
    return Status::DataLoss("result element count");
  const bool half = tensor.description().data_type() == c::DataType::kBFloat16;
  std::vector<float> floats(half ? 0 : count);
  std::vector<std::uint16_t> halves(half ? count : 0);
  if (half)
    HYLE_RETURN_IF_ERROR(
        context.download(tensor, std::as_writable_bytes(std::span(halves))));
  else
    HYLE_RETURN_IF_ERROR(
        context.download(tensor, std::as_writable_bytes(std::span(floats))));
  for (std::size_t i = 0; i < count; ++i) {
    const double wanted =
        half ? decode(encode(expected[i])) : static_cast<float>(expected[i]);
    const double actual = half ? decode(halves[i]) : floats[i];
    const double tolerance =
        (half ? 0.008 : 6e-6) * std::abs(wanted) + (half ? 2e-7 : 2e-6);
    if (!std::isfinite(actual) || std::abs(actual - wanted) > tolerance) {
      std::fprintf(stderr, "element=%zu actual=%.12g expected=%.12g\n", i,
                   actual, wanted);
      return Status::DataLoss("independent reduction/probability/L2 oracle");
    }
  }
  return Status::Ok();
}

Result<std::vector<v::Program>> prepare(const v::Context &context,
                                        const c::TensorDesc &desc,
                                        const c::TensorDesc &mask, Mode mode,
                                        bool graph) {
  std::vector<v::Program> programs;
  HYLE_ASSIGN_OR_RETURN(auto scalar,
                        c::TensorDesc::dense(c::DataType::kFloat32,
                                             std::array<std::int64_t, 0>{}));
  HYLE_ASSIGN_OR_RETURN(
      auto eps, upload(context, scalar, std::array<double, 1>{epsilon}));
  if (graph) {
    HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
    HYLE_ASSIGN_OR_RETURN(auto input, builder.input(desc));
    g::ValueId output, sum;
    std::vector<v::Tensor> constants;
    if (mode == Mode::L2) {
      HYLE_ASSIGN_OR_RETURN(auto high,
                            builder.add(c::Cast{c::DataType::kFloat32}, input));
      HYLE_ASSIGN_OR_RETURN(
          auto squared,
          builder.add(c::Binary{c::BinaryKind::kMultiply}, high, high));
      HYLE_ASSIGN_OR_RETURN(sum, builder.add(operation(Mode::Sum), squared));
      HYLE_ASSIGN_OR_RETURN(auto epsilon_value, builder.constant(scalar));
      constants.push_back(eps);
      HYLE_ASSIGN_OR_RETURN(auto shifted,
                            builder.add(c::Binary{}, sum, epsilon_value));
      HYLE_ASSIGN_OR_RETURN(
          auto inverse, builder.add(c::Unary{c::UnaryKind::kRsqrt}, shifted));
      HYLE_ASSIGN_OR_RETURN(
          auto normalized,
          builder.add(c::Binary{c::BinaryKind::kMultiply}, high, inverse));
      HYLE_ASSIGN_OR_RETURN(output,
                            builder.add(c::Cast{desc.data_type()}, normalized));
    } else if (masked(mode)) {
      HYLE_ASSIGN_OR_RETURN(auto flags, builder.input(mask));
      HYLE_ASSIGN_OR_RETURN(output, builder.add(operation(mode), input, flags));
    } else {
      HYLE_ASSIGN_OR_RETURN(output, builder.add(operation(mode), input));
    }
    HYLE_RETURN_IF_ERROR(builder.publish(output));
    if (mode == Mode::L2)
      HYLE_RETURN_IF_ERROR(builder.publish(sum));
    HYLE_ASSIGN_OR_RETURN(auto plan, std::move(builder).finish());
    gv::CompileReport report;
    HYLE_ASSIGN_OR_RETURN(auto program, gv::compile(context, plan, constants,
                                                    {.report = &report}));
    if (report.managed_region_count == 0)
      return std::unexpected(
          Status::DataLoss("Graph did not bind mature region"));
    programs.push_back(std::move(program));
    return programs;
  }
  if (mode != Mode::L2) {
    if (masked(mode)) {
      HYLE_ASSIGN_OR_RETURN(auto program,
                            v::prepare(context, operation(mode), desc, mask));
      programs.push_back(std::move(program));
    } else {
      HYLE_ASSIGN_OR_RETURN(auto program,
                            v::prepare(context, operation(mode), desc));
      programs.push_back(std::move(program));
    }
    return programs;
  }
  HYLE_ASSIGN_OR_RETURN(auto high, c::TensorDesc::dense(c::DataType::kFloat32,
                                                        desc.dimensions()));
  HYLE_ASSIGN_OR_RETURN(
      auto sum_desc,
      c::infer_single_output(operation(Mode::Sum), std::span(&high, 1)));
  HYLE_ASSIGN_OR_RETURN(
      auto cast, v::prepare(context, c::Cast{c::DataType::kFloat32}, desc));
  HYLE_ASSIGN_OR_RETURN(
      auto square,
      v::prepare(context, c::Binary{c::BinaryKind::kMultiply}, high, high));
  HYLE_ASSIGN_OR_RETURN(auto sum,
                        v::prepare(context, operation(Mode::Sum), high));
  HYLE_ASSIGN_OR_RETURN(auto shifted,
                        v::prepare(context, c::Binary{}, sum_desc, eps));
  HYLE_ASSIGN_OR_RETURN(
      auto inverse,
      v::prepare(context, c::Unary{c::UnaryKind::kRsqrt}, sum_desc));
  HYLE_ASSIGN_OR_RETURN(
      auto norm,
      v::prepare(context, c::Binary{c::BinaryKind::kMultiply}, high, sum_desc));
  HYLE_ASSIGN_OR_RETURN(auto low,
                        v::prepare(context, c::Cast{desc.data_type()}, high));
  return std::vector<v::Program>{cast,    square, sum, shifted,
                                 inverse, norm,   low};
}

Result<std::vector<v::Tensor>> execute(std::vector<v::Invocation> &slots,
                                       const v::Tensor &input,
                                       const v::Tensor &mask, Mode mode) {
  HYLE_RETURN_IF_ERROR(masked(mode) ? slots[0].bind(input, mask)
                                    : slots[0].bind(input));
  HYLE_ASSIGN_OR_RETURN(auto work, slots[0].submit());
  HYLE_ASSIGN_OR_RETURN(auto result, work.wait());
  const auto values = result.get()->tensors();
  return std::vector<v::Tensor>(values.begin(), values.end());
}

struct L2Recording {
  v::Tensor input;
  std::vector<v::Tensor> outputs;
  v::RecordedProgram program;
};

Result<L2Recording> record_l2(const v::Context &context,
                              const c::TensorDesc &desc,
                              std::span<const v::Program> programs) {
  L2Recording result;
  HYLE_ASSIGN_OR_RETURN(result.input, context.allocate(desc));
  HYLE_ASSIGN_OR_RETURN(auto recorder, v::Recorder::create(context));
  for (std::size_t stage = 0; stage < programs.size(); ++stage) {
    HYLE_ASSIGN_OR_RETURN(
        auto output,
        context.allocate(programs[stage].output_descriptions()[0]));
    result.outputs.push_back(output);
    const auto &outputs = result.outputs;
    if (stage == 0)
      HYLE_RETURN_IF_ERROR(recorder.append(
          programs[stage], std::array{result.input}, std::array{output}));
    else if (stage == 1)
      HYLE_RETURN_IF_ERROR(recorder.append(programs[stage],
                                           std::array{outputs[0], outputs[0]},
                                           std::array{output}));
    else if (stage == 5)
      HYLE_RETURN_IF_ERROR(recorder.append(programs[stage],
                                           std::array{outputs[0], outputs[4]},
                                           std::array{output}));
    else
      HYLE_RETURN_IF_ERROR(recorder.append(
          programs[stage], std::array{outputs[stage - 1]}, std::array{output}));
  }
  HYLE_ASSIGN_OR_RETURN(result.program, recorder.finish());
  return result;
}

Result<std::vector<v::Tensor>> execute_l2(const v::Context &context,
                                          L2Recording &record,
                                          std::span<const double> input) {
  if (record.input.description().data_type() == c::DataType::kFloat32) {
    std::vector<float> packed;
    for (double value : input)
      packed.push_back(static_cast<float>(value));
    HYLE_RETURN_IF_ERROR(
        context.upload(record.input, std::as_bytes(std::span(packed))));
  } else {
    std::vector<std::uint16_t> packed;
    for (double value : input)
      packed.push_back(encode(value));
    HYLE_RETURN_IF_ERROR(
        context.upload(record.input, std::as_bytes(std::span(packed))));
  }
  HYLE_ASSIGN_OR_RETURN(auto work, record.program.submit());
  HYLE_RETURN_IF_ERROR(work.wait());
  return std::vector<v::Tensor>{record.outputs[6], record.outputs[2]};
}

Status run_case(std::span<const std::uint16_t> table,
                const std::array<std::int64_t, 3> &shape, c::DataType type,
                Mode mode, bool graph) {
  hyle::mem::QuotaAllocator quota(hyle::mem::system_allocator(),
                                  128 * 1024 * 1024);
  {
    HYLE_ASSIGN_OR_RETURN(
        auto context,
        v::Context::create({.validation = true, .memory_quota = &quota}));
    HYLE_ASSIGN_OR_RETURN(auto desc, c::TensorDesc::dense(type, shape));
    HYLE_ASSIGN_OR_RETURN(auto count, desc.element_count());
    const auto width = static_cast<std::size_t>(shape.back());
    HYLE_ASSIGN_OR_RETURN(
        auto mask_desc,
        c::TensorDesc::dense(mode == Mode::Boolean ? c::DataType::kBool : type,
                             std::array{shape.back()}));
    HYLE_ASSIGN_OR_RETURN(auto programs,
                          prepare(context, desc, mask_desc, mode, graph));
    std::vector<v::Invocation> first, working;
    std::array<L2Recording, 2> recordings;
    const bool recorded = mode == Mode::L2 && !graph;
    if (recorded) {
      HYLE_ASSIGN_OR_RETURN(recordings[0], record_l2(context, desc, programs));
      HYLE_ASSIGN_OR_RETURN(recordings[1], record_l2(context, desc, programs));
    } else {
      for (const auto &program : programs) {
        HYLE_ASSIGN_OR_RETURN(auto a, program.create_invocation());
        HYLE_ASSIGN_OR_RETURN(auto b, program.create_invocation());
        first.push_back(std::move(a));
        working.push_back(std::move(b));
      }
    }
    std::vector<v::Tensor> retained;
    std::vector<std::vector<std::byte>> snapshot;
    for (std::size_t phase = 0; phase < 3; ++phase) {
      std::vector<double> input(count), mask(width);
      for (std::size_t row = 0; row < count / width; ++row)
        for (std::size_t column = 0; column < width; ++column)
          input[row * width + column] = decode(
              table[((row + phase * 7) % table_rows) * table_width + column]);
      for (std::size_t column = 0; column < width; ++column)
        mask[column] = mode == Mode::Boolean
                           ? ((column + phase) % 3 != 1 ? 1.0 : 0.0)
                           : -static_cast<double>((column + phase) % 7) * 0.125;
      std::vector<v::Tensor> results;
      if (recorded) {
        HYLE_ASSIGN_OR_RETURN(
            results,
            execute_l2(context, recordings[phase == 0 ? 0 : 1], input));
      } else {
        HYLE_ASSIGN_OR_RETURN(auto x, upload(context, desc, input));
        v::Tensor mask_tensor;
        if (masked(mode)) {
          HYLE_ASSIGN_OR_RETURN(mask_tensor, upload(context, mask_desc, mask));
        }
        auto &slots = phase == 0 ? first : working;
        HYLE_ASSIGN_OR_RETURN(results, execute(slots, x, mask_tensor, mode));
      }
      const auto expected = reference(input, mask, width, mode);
      if (results.size() != expected.size())
        return Status::DataLoss("result count");
      for (std::size_t i = 0; i < results.size(); ++i)
        HYLE_RETURN_IF_ERROR(verify(context, results[i], expected[i]));
      if (phase == 0) {
        retained = results;
        for (const auto &tensor : retained) {
          HYLE_ASSIGN_OR_RETURN(auto saved, bytes(context, tensor));
          snapshot.push_back(std::move(saved));
        }
      } else {
        for (std::size_t i = 0; i < retained.size(); ++i) {
          HYLE_ASSIGN_OR_RETURN(auto current, bytes(context, retained[i]));
          if (current != snapshot[i])
            return Status::DataLoss("retained result overwritten");
        }
      }
    }
    first.clear();
    working.clear();
    programs.clear();
    for (auto &record : recordings)
      record = {};
    HYLE_RETURN_IF_ERROR(context.close());
    for (std::size_t i = 0; i < retained.size(); ++i) {
      HYLE_ASSIGN_OR_RETURN(auto current, bytes(context, retained[i]));
      if (current != snapshot[i])
        return Status::DataLoss("retained result changed after close");
    }
  }
  if (quota.used() != 0)
    return Status::DataLoss("reduction owners leaked quota");
  return Status::Ok();
}

Status run(const std::filesystem::path &fixtures) {
  HYLE_ASSIGN_OR_RETURN(
      auto table,
      read<std::uint16_t>(fixtures / "table.bf16", table_rows * table_width));
  const std::array<std::array<std::int64_t, 3>, 3> shapes{
      {{1, 1, 128}, {1, 17, 129}, {2, 257, 128}}};
  std::size_t cases = 0;
  for (auto type : {c::DataType::kFloat32, c::DataType::kBFloat16})
    for (const auto &shape : shapes)
      for (auto mode : {Mode::Sum, Mode::Mean, Mode::Probability, Mode::Boolean,
                        Mode::Additive, Mode::L2})
        for (bool graph : {false, true}) {
          const auto status = run_case(table, shape, type, mode, graph);
          if (!status.ok()) {
            std::fprintf(
                stderr, "type=%d shape=%lld/%lld/%lld mode=%d graph=%d\n",
                static_cast<int>(type), static_cast<long long>(shape[0]),
                static_cast<long long>(shape[1]),
                static_cast<long long>(shape[2]), static_cast<int>(mode),
                graph);
            return status;
          }
          ++cases;
        }
  std::printf(
      "PASS Reduction cases=%zu runs=%zu retained_close=%zu quota_zero=%zu\n",
      cases, cases * 3, cases, cases);
  return Status::Ok();
}

int main(int argc, char **argv) {
  if (argc != 2)
    return 2;
  const auto status = run(argv[1]);
  if (!status.ok()) {
    const auto message = status.message();
    std::fprintf(stderr, "%.*s\n", static_cast<int>(message.size()),
                 message.data());
    return 1;
  }
  return 0;
}
