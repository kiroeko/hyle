[CmdletBinding()]
param(
  [ValidateSet('static','shared')][string]$Linkage = 'static',
  [ValidateSet('Configure','Build','Test','RedTest')][string]$Action = 'Configure'
)
$ErrorActionPreference = 'Stop'
$sourceRoot = 'C:\public\project-hyle\hyle'
# Reconfigure linkage in one fixed build tree. oneDNN stays static in both
# products, so its unchanged objects are reused instead of duplicated.
$buildRoot = 'C:\hyle-scratch\active-cpu\static'
$logRoot = Join-Path $sourceRoot '.scratch\validation\cpu-precision'
[IO.Directory]::CreateDirectory($logRoot) | Out-Null
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$wrapper = Join-Path $sourceRoot 'scripts\hyle-windows.ps1'
$log = Join-Path $logRoot ($Linkage + '-' + $Action.ToLowerInvariant() + '.log')
if ($Action -eq 'Configure') {
  $options = @(
    '-DCMAKE_BUILD_TYPE=Release','-DHYLE_WERROR=ON','-DHYLE_INSTALL=OFF',
    '-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF',
    '-DHYLE_TRACE=OFF','-DHYLE_SANITIZER=off','-DHYLE_COMPUTE_CPU=ON',
    '-DHYLE_COMPUTE_ONEDNN=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=OFF',
    '-DHYLE_COMPUTE_VULKAN=OFF',
    '-DFETCHCONTENT_SOURCE_DIR_ONEDNN=C:/public/project-hyle/hyle/.scratch/onednn-lock-v3.13.2/extract/oneDNN-71094df451909e95ceeefc8f64c275cdcbbcdff5',
    ('-DHYLE_STATIC=' + $(if ($Linkage -eq 'static') {'ON'} else {'OFF'})))
  & $wrapper -Action Configure -BinaryDir $buildRoot -Factor 'compute_provider_native;compute_provider_onednn;compute_route_cpu;graph_route_cpu;graph_provider_onednn' -ExtraArgs $options > $log 2>&1
} elseif ($Action -eq 'Build') {
  & $wrapper -Action Build -BinaryDir $buildRoot -ExtraArgs @('--parallel','2','--target','hyle_compute_provider_native_tests','hyle_compute_provider_onednn_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests','hyle_graph_provider_onednn_tests') > $log 2>&1
} else {
  $bin = Join-Path $buildRoot 'bin'
  $crt = Get-ChildItem -LiteralPath 'C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Redist\MSVC' -Directory |
    Where-Object {Test-Path -LiteralPath (Join-Path $_.FullName 'x64\Microsoft.VC145.CRT')} |
    Sort-Object Name -Descending | Select-Object -First 1
  if (-not $crt) {throw 'Selected CRT not found'}
  Get-ChildItem -LiteralPath (Join-Path $crt.FullName 'x64\Microsoft.VC145.CRT') -Filter '*.dll' -File | Copy-Item -Destination $bin -Force
  Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HylePrecisionErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
  [HylePrecisionErrorMode]::SetErrorMode(0x8003) | Out-Null
  if ($Action -eq 'RedTest') {
    $failed = $false
    foreach ($suite in @('compute_provider_native','compute_provider_onednn','compute_route_cpu','graph_route_cpu')) {
      $output = Join-Path $logRoot ('red-'+$suite)
      & 'C:\Program Files\CMake\bin\cmake.exe' -E env --unset=PATH (Join-Path $bin ('hyle_'+$suite+'_test.exe')) '--gtest_filter=*UnsupportedAccumulationAtBothColdStages:*NeverFallsBackToLowerAccumulationPrecision' ('--gtest_output=json:'+$output+'.json') > ($output+'.log') 2>&1
      if ($LASTEXITCODE -ne 0) {$failed = $true}
      Get-Content -LiteralPath ($output+'.log') -Tail 18
    }
    exit $(if ($failed) {1} else {0})
  }
  & 'C:\Program Files\CMake\bin\cmake.exe' -E env --unset=PATH 'C:\Program Files\CMake\bin\ctest.exe' --test-dir $buildRoot --output-on-failure --parallel 1 --no-tests=error -R '^hyle_(compute_provider_(native|onednn)|compute_route_cpu|graph_route_cpu|graph_provider_onednn)_' -LE headers --output-junit (Join-Path $logRoot ($Linkage+'-ctest.xml')) > $log 2>&1
}
$result = $LASTEXITCODE
Get-Content -LiteralPath $log -Tail 26
exit $result
