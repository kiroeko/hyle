from pathlib import Path
import hashlib, json, re, shutil, subprocess, zipfile

root = Path('C:/hyle-scratch/llm-moe-c1-20260917')
repo = Path('C:/public/project-hyle/hyle')
evidence = repo / 'evidence/correctness/compute-llm-moe-c1'
candidate = '6be8e6a7aa2ca898b8e6e89d4dd10679d1f40476'
tree = '464e122cee593dd1f30549c7598e057bd784add1'
attempts, raw_files, selectors = [], [], []
identities = [
    ('windows', '94252bf7e3511ece8f14ee03a52bc9652ee8ed61', 'FAIL'),
    ('windows', 'c93c3b9ce728ab04a943e26f9c2761b6400e8b8d', 'FAIL'),
    ('windows', candidate, 'PASS'), ('air', candidate, 'PASS'),
    ('mini', candidate, 'PASS')]
for host, revision, verdict in identities:
    directory = root / f'x-{host}' / revision[:8]
    path = directory / 'result.json'
    record = json.loads(path.read_text(encoding='utf-8'))
    assert record['candidate'] == revision and record['verdict'] == verdict
    expected_tree = subprocess.check_output(['git', 'rev-parse', revision+'^{tree}'], cwd=repo, text=True).strip()
    assert record['tree'] == expected_tree
    record['validation_host'] = host
    record['local_result'] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    for command in record['commands']:
        log = directory / Path(command['log']).name
        assert hashlib.sha256(log.read_bytes()).hexdigest() == command['sha256']
        command['local_log'] = str(log)
    if verdict == 'PASS':
        assert record['tree'] == tree
        assert all(c['exit_code'] == 0 for c in record['commands'])
        text = (directory/'test.log').read_text(encoding='utf-8')
        counts = [int(n) for n in re.findall(r'^\d+: \[==========\] Running (\d+) tests? from', text, re.M)]
        assert counts == [32, 14], (host, counts)
        assert re.search(r'100% tests passed(?:, 0 tests failed)? out of 4', text)
        record['test_cases'] = {'compute_route_vulkan':32, 'graph_route_vulkan':14, 'separate_header_checks':2}
        assert hashlib.sha256((directory/'LastTest.log').read_bytes()).hexdigest() == record['last_test_sha256']
        if host != 'mini':
            assert not any(marker in text for marker in ('Validation Error', 'VUID-', 'SYNC-HAZARD'))
    elif revision.startswith('94252'):
        assert record['commands'][-1]['label'] == 'build' and record['commands'][-1]['exit_code'] != 0
        record['qualification'] = 'Product/SPIR-V compiled; test compilation failed on MSVC C4244 implicit uint64-to-double reference conversion. No runtime tests.'
    else:
        assert record['commands'][-1]['label'] == 'test' and record['commands'][-1]['exit_code'] != 0
        text = (directory/'test.log').read_text(encoding='utf-8')
        assert 'NonfiniteRowsTinyLogTailBroadcastAndRejection' in text
        assert re.search(r'\[  PASSED  \] 31 tests', text)
        assert re.search(r'\[  PASSED  \] 14 tests', text)
        record['qualification'] = '31/32 Direct, 14/14 Graph and two headers passed; the remaining Direct case failed tiny-tail F32/BF16 LogSoftmax and large-common-offset F32 LogSoftmax.'
    attempts.append(record)
    raw_files.extend(p for p in directory.iterdir() if p.is_file())
    if host != 'mini':
        selector_path = directory/'selector.json'
        plan = json.loads(selector_path.read_text(encoding='utf-8'))
        selectors.append({'host':host, 'candidate':revision, 'path':str(selector_path),
            'sha256':hashlib.sha256(selector_path.read_bytes()).hexdigest(), 'verdict':plan['verdict'],
            'selected':[g['id'] for g in plan['selected_gates']],
            'skipped_reasons':[{'id':g['id'],'reason':g['reason']} for g in plan['skipped_gates']],
            'execution_boundary':'Two route factors and card-declared public headers; full C1 delivery/P1 pending.'})

loc_path = root/'x-implementation-loc.json'
loc = json.loads(loc_path.read_text(encoding='utf-8'))
assert loc['repository']['commit'] == candidate and loc['self_check'] == 'pass'
assert not subprocess.check_output(['git','diff',candidate,'HEAD','--',*loc['module']['paths']],cwd=repo)
shutil.copy2(loc_path,evidence/loc_path.name)
for name in ('run-x-vulkan-windows.py','run-x-vulkan-windows.ps1',
             'run-x-vulkan-windows-tests.py','run-x-vulkan-windows-tests.ps1',
             'run-x-vulkan-windows-numerical.py','run-x-vulkan-windows-numerical.ps1',
             'run-x-vulkan-air.py','run-x-vulkan-mini.py','record-x-vulkan.py',
             'x-reduction-before-precision.spirv.txt','x-initial-implementation-loc.json'):
    raw_files.append(root/name)
archive = evidence/'x-vulkan-focused-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as output:
    for path in sorted(set(raw_files)):
        assert path.is_file(), path
        output.write(path,path.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as output:
    archive_entries = len(output.namelist())
    assert output.testzip() is None

record = {
    'kind':'C1-X focused Vulkan reduction and masked probabilities; not full C1 acceptance',
    'baseline':subprocess.check_output(['git','rev-parse','38d98cc6'],cwd=repo,text=True).strip(),
    'initial_product_candidate':identities[0][1], 'product_candidate':candidate,
    'validation_candidate':candidate, 'validation_tree':tree,
    'verdict':'PASS', 'scope':'X01-X04 focused correctness/lifecycle/P0 only',
    'attempts':attempts,
    'qualification':[
        'Final immutable candidate passed 32 Direct + 14 Graph cases and two public-header checks on each of W1, Air and Mini. W1/Air validation layers reported no Validation Error, VUID or SYNC-HAZARD; Mini signs correctness/portability only.',
        'One test-only compilation correction and one audited product numerical correction followed the initial candidate. Original FAIL logs remain included. No tolerance was relaxed.',
        'LogSoftmax excludes one maximum from the exponential sum. Below tail 1/64 a fifth-degree log1p polynomial avoids native log near one; precise preserves the subtraction/compensation order. Tiny tails, tied maxima, both cutoff sides and large common offsets passed independent FP64/rounded references.',
        'Reduce Sum/Mean/Min/Max supports F32/F16/BF16, arbitrary admitted axes/keepdim/strides/Views, scalar/rank-eight/empty domains, NaN propagation and signed-zero min/max. Half outputs have one writer per packed word.',
        'Softmax/LogSoftmax supports three floating storage types, finite scale, arbitrary axis and broadcast Bool/same-type additive masks. Widths 0/1/127/129/2048/2049/8193/32769, inner 1/2/3, odd native View origins and nonfinite rows passed.',
        'F32, contiguous-axis half and even-inner half use one dispatch. Odd inner greater than one uses bounded eight-byte-per-row statistics and a second word-owned dispatch. Shared row caching is cold-qualified by width and device shared-memory capacity.',
        'Independent L2 and masked-probability Graph combinations, two invocation slots, changing bindings, retained old outputs, close, guard bytes, alias rejection and native buffer/recording counters passed. Steady submit does not allocate/record/search providers.',
        'These reduction shaders are HYLE implementations using reviewed algorithm structures, not a newly integrated ggml runtime or proof of best-of. The provider-first source audit governs the next C1 work.'
    ],
    'setup_issues':[
        'An initial Air SSH launcher referenced absent /opt/homebrew/bin/python3; corrected to existing /usr/bin/python3 before any validation attempt.',
        'Air selector initially lacked cmake on SSH PATH; failure log is retained. Adding the existing /opt/homebrew/bin to that command PATH produced READY; no product build/test was repeated for this environment issue.'
    ],
    'selectors':selectors,
    'raw_archive':{'path':archive.relative_to(repo).as_posix(),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':archive_entries},
    'not_run':['New mature-region/Provider integration and selection qualification',
               'Remaining Vulkan C1 TopK/checked indexing/Scatter/Scan',
               'Full C1 actual model-weight consumer and 64-row/256-cell acceptance',
               'Full C1 source/installed-static/installed-shared and remaining applicable environments/sanitizers',
               'P1 and final default-rule qualification']}
(evidence/'x-vulkan-focused.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
registry = repo/'docs/implementation/module-status.json'
data = json.loads(registry.read_text(encoding='utf-8'))
summary = 'LLM/MoE C1-X AUDITED：Reduce/Softmax/LogSoftmax 已实现，6be8e6a7 在 W1/Air/Mini 各46例及两个头检查通过；保留原始失败和一次数值纠正。后续先按成熟 Provider 承载复核解决接入，不延续默认自写队列；完整 C1 权重/三交付/P1 未签收。'
for row in data['modules']:
    if row['module'] in ('compute_route_vulkan','graph_route_vulkan'):
        assert row['state'] == 'AUDITED'
        row['summary'] = summary
registry.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('X receipt:',archive_entries,'raw files;',archive.stat().st_size,'archive bytes')
print('LOC:',next(m for m in loc['metrics'] if m['id']=='module')['code'])
