from pathlib import Path
import hashlib, json, os, subprocess, sys, time, tarfile

root = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
source = root / 'source-6be8e6a7'
build = root / 'build-vulkan-static-6be8e6a7'
candidate = '6be8e6a7aa2ca898b8e6e89d4dd10679d1f40476'
tree = '464e122cee593dd1f30549c7598e057bd784add1'
archive = root / 'x-6be8e6a7.tar.gz'
expected = '5dd3978d9566ba6d59712531c19185844ad7f83c3a33770f6640c785e64e5d93'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
logs = root / ('x-' + candidate[:8])
assert not logs.exists(), 'inspect the existing attempt before any restart'
logs.mkdir(parents=True)
assert not source.exists(), 'never overlay an existing source tree'
with tarfile.open(archive) as inputs:
    for member in inputs.getmembers():
        target = (root / member.name).resolve()
        assert target.is_relative_to(source.resolve())
        if member.issym():
            assert (target.parent / member.linkname).resolve().is_relative_to(source.resolve())
        if member.islnk():
            assert (root / member.linkname).resolve().is_relative_to(source.resolve())
    inputs.extractall(root)
tools = root / 't-mini-vulkan-tools'
tool_archive = root / 't-mini-vulkan-tools.tar.gz'
assert hashlib.sha256(tool_archive.read_bytes()).hexdigest() == 'a34568e2d301473e39469a4c6cbbf2328ec41d100caf02175a98cc06e7c94144'
assert tools.is_dir() # Reuse the already verified local tool archive.
for item in json.loads((tools/'manifest.json').read_text())['files']:
    assert hashlib.sha256((tools/item['file']).read_bytes()).hexdigest() == item['sha256']
# Build Python/OS tool launchers may strip DYLD variables. Restore the local
# library path at the native compiler boundary without changing Mach-O files.
compiler = tools/'glslang-local'
compiler.write_text('#!/bin/sh\nexport DYLD_LIBRARY_PATH="'+str(tools/'lib')+'"\nexec "'+str(tools/'bin/glslangValidator')+'" "$@"\n')
compiler.chmod(0o755)
cmake_bin = next(Path('/Users/kiro/hyle-verify-tools/lib').glob('python*/site-packages/cmake/data/bin/cmake'))
ctest_bin = cmake_bin.with_name('ctest')

env = os.environ.copy()
env.update(PATH='/Users/kiro/hyle-verify-tools/bin:' + env['PATH'],
           CMAKE_BUILD_PARALLEL_LEVEL='2', CTEST_PARALLEL_LEVEL='1', TRACY_ONLY_LOCALHOST='1', DYLD_LIBRARY_PATH=str(tools/'lib'),
           VK_ICD_FILENAMES=str(tools/'MoltenVK_icd.json'), VK_LOADER_LAYERS_DISABLE='~implicit~')
configure = [str(cmake_bin), '-S', str(source), '-B', str(build), '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4',
    '-DHYLE_DEV_FACTORS=compute_route_vulkan;graph_route_vulkan', '-DHYLE_COMPUTE_APPLE=OFF',
    '-DHYLE_COMPUTE_CPU=OFF', '-DHYLE_COMPUTE_CUDA=OFF', '-DHYLE_COMPUTE_VULKAN=ON', '-DHYLE_COMPUTE_ONEDNN=OFF',
    '-DHYLE_BUILD_TESTS=ON', '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_STATIC=ON', '-DHYLE_INSTALL=OFF',
    '-DHYLE_WERROR=ON', '-DHYLE_SANITIZER=off', '-DFETCHCONTENT_FULLY_DISCONNECTED=ON', '-DHYLE_VULKAN_GLSLANG='+str(compiler), '-DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS='+str(tools/'vulkan-headers')]
commands = [('configure', configure),
    ('build', [str(cmake_bin), '--build', str(build), '--parallel', '2', '--target', 'hyle_compute_route_vulkan_test', 'hyle_graph_route_vulkan_test']),
    ('test', [str(ctest_bin), '--test-dir', str(build), '--output-on-failure', '--no-tests=error', '--timeout', '300', '--verbose', '-L', '^(compute_route_vulkan|graph_route_vulkan)$'])]
result = {'candidate': candidate, 'tree': tree, 'kind': 'C1-X Vulkan reduction/Softmax focused correctness and headers; not full C1 delivery/P1',
    'source': str(source), 'build': str(build), 'archive_sha256': expected, 'source_kind': 'complete canonical git archive', 'role': 'Mac mini correctness/portability only', 'validation_layer': 'not installed; validation-layer evidence is from W1 and Air', 'tools_archive_sha256': hashlib.sha256(tool_archive.read_bytes()).hexdigest(),
    'machine': {'model': subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip(),
                'os': subprocess.check_output(['/usr/bin/sw_vers'], text=True),
                'compiler': subprocess.check_output(['/Library/Developer/CommandLineTools/usr/bin/clang++', '--version'], text=True)},
    'commands': [], 'verdict': 'RUNNING'}
def save():
    (logs / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
save()
for label, command in commands:
    print('RUN', label, flush=True)
    log = logs / (label + '.log')
    start = time.monotonic()
    with log.open('wb') as output:
        rc = subprocess.run(command, cwd=source, env=env, stdout=output, stderr=subprocess.STDOUT).returncode
    result['commands'].append({'label': label, 'command': command, 'exit_code': rc, 'seconds': time.monotonic() - start,
                              'log': str(log), 'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    if rc:
        result['verdict'] = 'FAIL'; save()
        print(label, 'FAIL', flush=True)
        print(log.read_text(errors='replace')[-8000:], flush=True)
        sys.exit(rc)
    save()
raw = (build / 'Testing/Temporary/LastTest.log').read_bytes()
(logs / 'LastTest.log').write_bytes(raw)
result['last_test_sha256'] = hashlib.sha256(raw).hexdigest()
result['verdict'] = 'PASS'; save()
print('C1-X Vulkan focused PASS', flush=True)
