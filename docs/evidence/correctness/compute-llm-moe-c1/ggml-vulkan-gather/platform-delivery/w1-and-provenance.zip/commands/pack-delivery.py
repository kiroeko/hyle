import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--workspace', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = args.workspace.resolve()
output = args.output.resolve()
output.parent.mkdir(parents=True, exist_ok=True)
archive = output.with_suffix('.zip')
receipt_path = output.with_suffix('.json')
assert not archive.exists() and not receipt_path.exists()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = json.loads((root / 'logs/identity.json').read_text(encoding='utf-8'))
assert identity['state'] == 'PASS'
assert identity['snapshot'] == 'd54ddc5afb8f9df3a3b5b6444e0b8e2bf03cb18e'
assert all(r['exit_code'] == 0 for r in identity['records'])
assert identity['producer_paths_hidden_before_sdk_consumption']
assert not any((root / path).exists() for path in ('bs', 'bd', 'complete-source', 'sdk-static', 'sdk-shared'))
assert identity['fixture_receipt_sha256'] == sha(root / 'fixtures/receipt.json')
assert identity['test_registration_sha256'] == sha(root / 'independent-consumer/CMakeLists.txt')
assert identity['consumer_files']['main.cc'] == sha(root / 'independent-consumer/main.cc')
for key, expected in identity['executables'].items():
    build, name = key.split('/')
    actual = root / ('bs-hidden' if build == 'bs' else build) / (name + ('.exe' if identity['platform'] == 'Windows' else ''))
    assert sha(actual) == expected, actual
assert len(identity['executables']) == 3
for path, expected in identity['logs'].items():
    assert sha(root / 'logs' / path) == expected, path
tests = {}
for build in ('bs', 'consumer-static', 'consumer-shared'):
    log = root / 'logs' / (build + '-LastTest.log')
    text = log.read_text(encoding='utf-8', errors='replace')
    assert text.count('PASS actual-weight Gather -> Gemma RMS') == 6
    assert 'PASS C1 actual BF16 embedding subset: Direct + Graph' in text
    assert not any(marker in text for marker in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
    tests[build] = {'sha256': sha(log), 'cases': 6, 'replays_per_case': 5, 'checked_failures': 6}
manifests = {}
for linkage in ('static', 'shared'):
    prefix = root / ('relocated-sdk-' + linkage)
    assert prefix.is_dir()
    manifests[linkage] = [{'path': p.relative_to(prefix).as_posix(), 'bytes': p.stat().st_size,
                          'sha256': sha(p)} for p in sorted(prefix.rglob('*')) if p.is_file()]
files = {'logs/' + p.relative_to(root / 'logs').as_posix(): p
         for p in (root / 'logs').rglob('*') if p.is_file()}
files.update({'consumer/' + p.name: p for p in (root / 'independent-consumer').iterdir() if p.is_file()})
files['input/fixture-receipt.json'] = root / 'fixtures/receipt.json'
files['commands/pack-delivery.py'] = Path(__file__)
files['input/SOURCE-MANIFEST.txt'] = root / 'complete-source-hidden/hyle-0.1.0-source/SOURCE-MANIFEST.txt'
for p in root.glob('previous-*.zip'):
    files['prior-failures/' + p.name] = p
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as package:
    for name, path in files.items():
        package.write(path, name)
    package.writestr('sdk-manifests.json', json.dumps(manifests, indent=2) + '\n')
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for name, path in files.items():
        assert hashlib.sha256(package.read(name)).hexdigest() == sha(path)
result = {
    'candidate': identity['snapshot'], 'platform': identity['platform'], 'status': 'PASS',
    'scope': identity['scope'], 'source_archive_sha256': identity['source_archive_sha256'],
    'fixture_receipt_sha256': identity['fixture_receipt_sha256'],
    'consumer_files': identity['consumer_files'], 'executables': identity['executables'], 'tests': tests,
    'slot_schedule': {'Direct': {'gather': 3, 'norm': 2, 'retained_snapshot_slots': 1},
                     'Graph': {'whole_fragment': 2, 'retained_snapshot_slots': 1}},
    'producer_paths_hidden_before_sdk_consumption': True,
    'archive': archive.name, 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
    'payloads_in_archive': False,
    'not_claimed': ['complete C1', 'model inference', 'performance', 'all selected global package gates'],
}
with receipt_path.open('w', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'platform': result['platform'], 'candidate': result['candidate'],
                  'deliveries': 3, 'archive_bytes': result['archive_bytes'], 'archive_sha256': result['archive_sha256']}))
