import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

task = Path(__file__).resolve().parent
root = task.parents[2]
candidate = 'd54ddc5afb8f9df3a3b5b6444e0b8e2bf03cb18e'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == candidate
output = root / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-gather/platform-delivery'
output.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
factors = ('compute_provider_ggml_vulkan', 'compute_route_vulkan', 'graph_route_vulkan')
windows = {}
raw = {}
def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
for linkage in ('static', 'shared'):
    logs = task / ('wide-w1-static' if linkage == 'static' else 'w1')
    previous = json.loads((logs / 'result.json').read_text()) if linkage == 'static' else None
    if previous:
        assert previous['candidate'] == candidate and previous['status'] == 'PASS'
    suites = []
    for factor, expected in zip(factors, (19, 62, 21 if linkage == 'static' else 20)):
        report_path = logs / (linkage + '-' + factor + '.json')
        log_path = report_path.with_suffix('.log')
        report = json.loads(report_path.read_text())
        assert report['tests'] == expected and report['failures'] == 0 and report['errors'] == 0
        assert report.get('disabled', 0) == 0
        assert all(t['status'] == 'RUN' and t['result'] == 'COMPLETED' for suite in report['testsuites'] for t in suite['testsuite'])
        assert not any(marker in log_path.read_text(encoding='utf-8', errors='replace') for marker in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
        exe = Path('C:/hyle-scratch/active-vk') / linkage / 'bin' / ('hyle_' + factor + '_test.exe')
        executable_hash = sha(exe)
        if previous:
            assert next(s for s in previous['suites'] if s['factor'] == factor)['executable_sha256'] == executable_hash
        suites.append({'factor': factor, 'tests': expected, 'executable_sha256': executable_hash,
                       'gtest_sha256': sha(report_path), 'log_sha256': sha(log_path)})
        raw['w1-' + linkage + '/' + report_path.name] = report_path
        raw['w1-' + linkage + '/' + log_path.name] = log_path
    ctest = logs / (linkage + '-ctest.xml')
    cases = ET.parse(ctest).getroot().findall('testcase')
    assert len(cases) == 2 and all(c.find('failure') is None and c.find('skipped') is None for c in cases)
    raw['w1-' + linkage + '/' + ctest.name] = ctest
    cache = Path('C:/hyle-scratch/active-vk') / linkage / 'CMakeCache.txt'
    raw['w1-' + linkage + '/CMakeCache.txt'] = cache
    windows[linkage] = {'candidate': candidate, 'status': 'PASS', 'suites': suites, 'cases': sum(s['tests'] for s in suites),
                        'source_masm_contract_checks': 2, 'path_unset_for_native_exe': True,
                        'dlls_next_to_exe': True, 'error_mode': '0x8003', 'cache_sha256': sha(cache)}
    for name in (('wide-correction-static-build.log', 'wide-correction-static-configure.log') if linkage == 'static'
                 else ('f2-shared-build.log', 'f2-shared-configure.log', 'f2-shared-test.log')):
        path = task / 'w1' / name
        if path.exists():
            raw['w1-' + linkage + '/' + name] = path
platforms = {}
for platform in ('air', 'mini'):
    name = 'y26-wide-' + platform + '-focused'
    receipt = json.loads((task / (name + '.json')).read_text())
    archive = task / (name + '.zip')
    assert receipt['candidate'] == candidate and receipt['status'] == 'PASS'
    assert receipt['archive_sha256'] == sha(archive)
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
    shutil.copy2(archive, output / archive.name)
    write_json(output / (name + '.json'), receipt)
    platforms[platform] = {'receipt': name + '.json', 'archive_sha256': sha(archive), 'cases': 102 if platform == 'air' else 101}
deliveries = {}
for name in ('windows-delivery', 'y26-wide-air-delivery'):
    receipt = json.loads((task / 'qualification' / (name + '.json')).read_text())
    archive = task / 'qualification' / (name + '.zip')
    assert receipt['candidate'] == candidate and receipt['status'] == 'PASS'
    assert receipt['archive_sha256'] == sha(archive)
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
    shutil.copy2(archive, output / archive.name)
    write_json(output / (name + '.json'), receipt)
    deliveries[receipt['platform']] = {'receipt': name + '.json', 'archive_sha256': sha(archive), 'deliveries': 3}
for name in ('windows-producer-cleanup.json', 'y26-wide-air-producer-cleanup.json'):
    receipt = json.loads((task / 'qualification' / name).read_text(encoding='utf-8-sig'))
    assert receipt['state'] == 'PASS' and receipt['candidate'] == candidate
    write_json(output / name, receipt)
for name in ('w1-run.ps1', 'queue-wide-delivery.ps1', 'verify-delivery.py', 'pack-delivery.py',
             'cleanup-windows-delivery.ps1', 'cleanup-air-delivery.py', 'prepare-fixture.py',
             'delivery-inputs.json', 'y26-wide-candidate.json', 'run-air-wide.py', 'run-mini-wide.py',
             'pack-wide.py', 'wide-correction-plan.json', 'archive-qualified.py'):
    raw['commands/' + name] = task / name
for name in ('prepare-norm-fixture.py', 'asset-status.json', 'norm-fixtures/receipt.json'):
    raw['input/prior/' + name] = root / '.scratch/validation/c1-real-weights' / name
raw['input/gather-fixture-receipt.json'] = task / 'real-fixtures/receipt.json'
raw['input/frozen-cases.json'] = root / 'tests/compute_models/qwen35_cases.json'
archive = output / 'w1-and-provenance.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as package:
    for name, path in raw.items():
        package.write(path, name)
    package.writestr('w1-result.json', json.dumps(windows, indent=2) + '\n')
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    assert all(hashlib.sha256(package.read(name)).hexdigest() == sha(path) for name, path in raw.items())
result = {'candidate': candidate, 'scope': 'Y26-F2 same-candidate Vulkan Gather regression and actual BF16 three-delivery subset',
          'status': 'PASS', 'native_cases': sum(r['cases'] for r in windows.values()) + sum(r['cases'] for r in platforms.values()),
          'windows': windows, 'macos': platforms, 'actual_bf16_deliveries': deliveries,
          'provenance_archive': archive.name, 'provenance_archive_sha256': sha(archive),
          'not_claimed': ['all global selector gates', 'complete C1', 'performance', 'model inference', '256 matrix cells']}
write_json(output / 'result.json', result)
print(json.dumps({'native_cases': result['native_cases'], 'actual_bf16_deliveries': 6,
                  'provenance_archive_sha256': result['provenance_archive_sha256']}))
