$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-gather'
$candidate = 'd54ddc5afb8f9df3a3b5b6444e0b8e2bf03cb18e'
if ((git rev-parse HEAD).Trim() -ne $candidate -or (git status --porcelain)) {
    throw 'Frozen candidate or clean worktree changed'
}
& (Join-Path $taskRoot 'w1-run.ps1') -Linkage static -Action Test -LogPrefix wide-correction-
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$receiptRoot = Join-Path $taskRoot 'wide-w1-static'
if (Test-Path -LiteralPath $receiptRoot) { throw 'Inspect previous focused receipt before rerunning' }
[IO.Directory]::CreateDirectory($receiptRoot) | Out-Null
$cases = 0
$receipts = @()
foreach ($factor in @('compute_provider_ggml_vulkan','compute_route_vulkan','graph_route_vulkan')) {
    $recordPath = Join-Path $taskRoot ('w1\static-' + $factor + '.json')
    $record = Get-Content -LiteralPath $recordPath -Encoding utf8 -Raw | ConvertFrom-Json
    if ($record.failures -ne 0 -or $record.disabled -ne 0) { throw ('Focused suite did not pass: ' + $factor) }
    $cases += $record.tests
    foreach ($suffix in @('.json','.log')) {
        Copy-Item -LiteralPath (Join-Path $taskRoot ('w1\static-' + $factor + $suffix)) -Destination $receiptRoot
    }
    $artifact = 'C:\hyle-scratch\active-vk\static\bin\hyle_' + $factor + '_test.exe'
    $receipts += @{factor=$factor; tests=$record.tests; executable_sha256=(Get-FileHash -LiteralPath $artifact -Algorithm SHA256).Hash.ToLowerInvariant()}
}
if ($cases -ne 102) { throw ('Expected 102 actual test cases, got ' + $cases) }
Copy-Item -LiteralPath (Join-Path $taskRoot 'w1\static-ctest.xml') -Destination $receiptRoot
Copy-Item -LiteralPath (Join-Path $taskRoot 'w1\wide-correction-static-test.log') -Destination $receiptRoot
@{candidate=$candidate; scope='Y26-F2 W1 static provider Direct Graph plus source/MASM checks'; status='PASS'; cases=$cases; suites=$receipts} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $receiptRoot 'result.json') -Encoding utf8
if ((git rev-parse HEAD).Trim() -ne $candidate -or (git status --porcelain)) { throw 'Candidate drift after tests' }
& ./scripts/hyle-windows.ps1 -Action Build -BinaryDir C:/hyle-scratch/active-vk/static -ExtraArgs @('--target','hyle_source_package','--parallel','2') > (Join-Path $taskRoot 'wide-source-package.log') 2>&1
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python (Join-Path $taskRoot 'refresh-delivery-inputs.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$inputs = Get-Content -LiteralPath (Join-Path $taskRoot 'delivery-inputs.json') -Raw -Encoding utf8 | ConvertFrom-Json
python (Join-Path $taskRoot 'verify-delivery.py') --root C:/hyle-scratch/active-vk/j --archive C:/hyle-scratch/active-vk/static/dist/hyle-0.1.0-source.zip --sha256 $inputs.source_archive_sha256 --candidate $candidate --consumer (Join-Path $taskRoot 'consumer') --fixtures (Join-Path $taskRoot 'real-fixtures') --resume-source-build
exit $LASTEXITCODE
