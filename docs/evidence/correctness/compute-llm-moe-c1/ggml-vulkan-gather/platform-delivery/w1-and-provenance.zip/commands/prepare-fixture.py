"""Actual local embedding fragment for Y26; no downloads or HYLE verdict."""
import hashlib,json,struct,shutil
from array import array
from pathlib import Path
root=Path(__file__).resolve().parents[3]
previous=root/'.scratch/validation/c1-real-weights/norm-fixtures'
receipt=json.loads((previous/'receipt.json').read_text())
assets=json.loads((previous.parent/'asset-status.json').read_text())
cases_path=root/'tests/compute_models/qwen35_cases.json'
assert hashlib.sha256(cases_path.read_bytes()).hexdigest()==receipt['frozen_cases_sha256']
source=Path(receipt['source_file'])
before=source.stat()
unique=sorted({t for case in receipt['cases'] for t in case['token_ids']})
lookup={token:row for row,token in enumerate(unique)}
out=Path(__file__).parent/'real-fixtures'
out.mkdir(exist_ok=False)
def file_record(name):
    p=out/name
    return {'file':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
with source.open('rb') as stream:
    header_size=struct.unpack('<Q',stream.read(8))[0]
    raw=stream.read(header_size)
    assert hashlib.sha256(raw).hexdigest()==assets['safetensors_header_sha256']
    header=json.loads(raw)
    name='model.language_model.embed_tokens.weight'
    tensor=header[name]
    assert tensor==receipt['tensor_sources'][name]
    assert tensor['dtype']=='BF16' and tensor['shape']==[248320,2048]
    rows=[]
    for token in unique:
        stream.seek(header_size+8+tensor['data_offsets'][0]+token*4096)
        row=stream.read(4096); assert len(row)==4096
        rows.append(row)
    (out/'table.bf16').write_bytes(b''.join(rows))
records=[]
for case in receipt['cases']:
    for entry in (case['input'],case['unrounded_oracle']):
        assert hashlib.sha256((previous/entry['file']).read_bytes()).hexdigest()==entry['sha256']
        shutil.copy2(previous/entry['file'],out/entry['file'])
    expected=(out/case['input']['file']).read_bytes()
    assert b''.join(rows[lookup[t]] for t in case['token_ids'])==expected
    indices=[lookup[t] for t in case['token_ids']]
    name=case['id']+'.i64'
    (out/name).write_bytes(array('q',indices).tobytes())
    records.append(dict(case,indices=file_record(name),local_indices=indices))
for key in ('parameter','scale'):
    entry=receipt[key]
    assert hashlib.sha256((previous/entry['file']).read_bytes()).hexdigest()==entry['sha256']
    shutil.copy2(previous/entry['file'],out/entry['file'])
assert source.stat().st_size==before.st_size and source.stat().st_mtime_ns==before.st_mtime_ns
result={'kind':'actual local embedding subset and frozen norm oracle; HYLE NOT_RUN',
        'source_id':receipt['source_id'],'original_source_file':str(source),
        'source_file_size':before.st_size,'source_file_mtime_ns':before.st_mtime_ns,
        'header_sha256':assets['safetensors_header_sha256'],
        'source_verification':receipt['original_verification'],
        'table':dict(file_record('table.bf16'),dtype='BF16',shape=[len(rows),2048]),
        'original_table':{'name':name if False else 'model.language_model.embed_tokens.weight',**tensor},
        'original_token_by_local_row':unique,'cases':records,'parameter':receipt['parameter'],
        'scale':receipt['scale'],'epsilon_f32':receipt['epsilon_f32'],
        'previous_norm_receipt_sha256':hashlib.sha256((previous/'receipt.json').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'limitation':'Compact actual embedding rows with explicit token-to-local-row map. This validates the C1 Gather/norm fragment, not a full vocabulary table, full C1, model execution or performance.'}
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'rows':len(rows),'width':2048,'cases':len(records),
                  'bytes':sum(p.stat().st_size for p in out.iterdir()),'hyle_execution':'NOT_RUN'}))
