$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL='2'
$env:TRACY_ONLY_LOCALHOST='1'
$env:VULKAN_SDK='C:/hyle-scratch/ggml-vulkan-region-20260918/sdk'
$ggmlY1Root='C:/hyle-scratch/ggml-vulkan-region-20260918'
foreach ($ggmlY1Mode in @('static','shared')) {
  & cmake -E copy_directory "$ggmlY1Root/install-$ggmlY1Mode" "$ggmlY1Root/relocated-$ggmlY1Mode"
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
  foreach ($ggmlY1Product in @('compute','graph')) {
    $ggmlY1Consumer="$ggmlY1Root/consumer-samples/$ggmlY1Product/cpp"
    & cmake -E copy_directory "C:/public/project-hyle/hyle/samples/package/$ggmlY1Product/cpp" "$ggmlY1Consumer"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    $ggmlY1Build="$ggmlY1Root/journey-$ggmlY1Mode-$ggmlY1Product"
    & cmake -S "$ggmlY1Consumer" -B "$ggmlY1Build" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$ggmlY1Root/relocated-$ggmlY1Mode;$env:VULKAN_SDK" *> "$ggmlY1Root/y1-consumer-$ggmlY1Mode-$ggmlY1Product-configure.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY1Root/y1-consumer-$ggmlY1Mode-$ggmlY1Product-configure.log" -Tail 25; exit $LASTEXITCODE }
    & cmake --build "$ggmlY1Build" --parallel 2 *> "$ggmlY1Root/y1-consumer-$ggmlY1Mode-$ggmlY1Product-build.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY1Root/y1-consumer-$ggmlY1Mode-$ggmlY1Product-build.log" -Tail 25; exit $LASTEXITCODE }
    & cmake -E env --unset=PATH "$ggmlY1Build/hyle_package_${ggmlY1Product}_cpp.exe" *> "$ggmlY1Root/y1-consumer-$ggmlY1Mode-$ggmlY1Product-run.log"
    if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY1Root/y1-consumer-$ggmlY1Mode-$ggmlY1Product-run.log" -Tail 25; exit $LASTEXITCODE }
    Get-Content "$ggmlY1Root/y1-consumer-$ggmlY1Mode-$ggmlY1Product-run.log"
  }
}
