$ErrorActionPreference='Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL='2'
$env:TRACY_ONLY_LOCALHOST='1'
$env:VULKAN_SDK='C:/hyle-scratch/ggml-vulkan-region-20260918/sdk'
$ggmlY1Root='C:/hyle-scratch/ggml-vulkan-region-20260918'
& cmake -S "$ggmlY1Root/source-consumer" -B "$ggmlY1Root/source-build" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_PREFIX_PATH=$env:VULKAN_SDK" -DHYLE_VULKAN_GLSLANG=C:/public/tools/glslang/glslangValidator.exe "-DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=$ggmlY1Root/upstream-clean" -DFETCHCONTENT_SOURCE_DIR_VULKAN_HEADERS=C:/hyle-scratch/r6-vulkan-20260917/locked-sources/vulkan_headers/Vulkan-Headers-e3b1eec08173d6b825cd3ac88c885a63b621504a -DFETCHCONTENT_FULLY_DISCONNECTED=ON *> "$ggmlY1Root/y1-source-configure.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY1Root/y1-source-configure.log" -Tail 30; exit $LASTEXITCODE }
& cmake --build "$ggmlY1Root/source-build" --target source_compute source_graph --parallel 2 *> "$ggmlY1Root/y1-source-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY1Root/y1-source-build.log" -Tail 30; exit $LASTEXITCODE }
foreach ($ggmlY1Product in @('compute','graph')) {
  & cmake -E env --unset=PATH "$ggmlY1Root/source-build/source_${ggmlY1Product}.exe" *> "$ggmlY1Root/y1-source-$ggmlY1Product-run.log"
  if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY1Root/y1-source-$ggmlY1Product-run.log" -Tail 30; exit $LASTEXITCODE }
}
Write-Output 'source Compute/Graph consumers passed'
