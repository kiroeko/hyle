$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:VULKAN_SDK = 'C:/hyle-scratch/ggml-vulkan-region-20260918/sdk'
$env:TRACY_ONLY_LOCALHOST = '1'
$env:PATH = "$env:VULKAN_SDK/Bin;$env:PATH"
$ggmlY1Root = 'C:/hyle-scratch/ggml-vulkan-region-20260918'
& cmake -S C:/public/project-hyle/hyle -B "$ggmlY1Root/hyle-static" -G Ninja -DCMAKE_BUILD_TYPE=Release -DHYLE_STATIC=ON -DHYLE_INSTALL=OFF -DHYLE_BUILD_TESTS=ON -DHYLE_BUILD_BENCH=OFF '-DHYLE_DEV_FACTORS=compute_route_vulkan;graph_route_vulkan' -DHYLE_COMPUTE_CPU=OFF -DHYLE_COMPUTE_ONEDNN=OFF -DHYLE_COMPUTE_CUDA=OFF -DHYLE_COMPUTE_APPLE=OFF -DHYLE_COMPUTE_VULKAN=ON -DHYLE_VULKAN_GLSLANG=C:/public/tools/glslang/glslangValidator.exe '-DFETCHCONTENT_SOURCE_DIR_GGML_VULKAN_RUNTIME=C:/hyle-scratch/ggml-vulkan-region-20260918/upstream-clean' "-DCMAKE_PREFIX_PATH=$env:VULKAN_SDK" "-DCMAKE_INSTALL_PREFIX=$ggmlY1Root/install-static" *> "$ggmlY1Root/y1-configure-static.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY1Root/y1-configure-static.log" -Tail 35; exit $LASTEXITCODE }
& cmake --build "$ggmlY1Root/hyle-static" --target hyle_compute_provider_ggml_vulkan_test --parallel 2 *> "$ggmlY1Root/y1-build-static.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$ggmlY1Root/y1-build-static.log" -Tail 35; exit $LASTEXITCODE }
Write-Output 'Y1 static provider build passed'
