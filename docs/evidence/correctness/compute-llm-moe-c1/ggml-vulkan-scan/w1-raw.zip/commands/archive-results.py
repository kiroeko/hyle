import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

task = Path(__file__).resolve().parent
root = task.parents[2]
candidate = '198cccba6d785132aace3e9744e9f1603dc342b0'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
meta = json.loads((task / 'y27-candidate.json').read_text())
output = root / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-scan'
output.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
raw = {}
windows = {}
logs = task.parent / 'vulkan-gather/w1'
for linkage in ('static', 'shared'):
    build = Path('C:/hyle-scratch/active-vk') / linkage
    suites = []
    for factor, expected in meta['expected_tests']['windows-' + linkage].items():
        report = logs / (linkage + '-' + factor + '.json')
        log = report.with_suffix('.log')
        data = json.loads(report.read_text())
        assert data['tests'] == expected and data['failures'] == 0 and data['errors'] == 0
        assert all(t['status'] == 'RUN' and t['result'] == 'COMPLETED' for s in data['testsuites'] for t in s['testsuite'])
        assert not any(m in log.read_text(encoding='utf-8', errors='replace') for m in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
        exe = build / 'bin' / ('hyle_' + factor + '_test.exe')
        suites.append({'factor': factor, 'tests': expected, 'executable_sha256': sha(exe),
                       'report_sha256': sha(report), 'log_sha256': sha(log)})
        raw[linkage + '/' + report.name] = report
        raw[linkage + '/' + log.name] = log
    ctest = logs / (linkage + '-ctest.xml')
    cases = ET.parse(ctest).getroot().findall('testcase')
    assert len(cases) == 2 and all(c.find('failure') is None and c.find('skipped') is None for c in cases)
    raw[linkage + '/ctest.xml'] = ctest
    raw[linkage + '/CMakeCache.txt'] = build / 'CMakeCache.txt'
    for action in ('configure', 'build', 'test'):
        raw[linkage + '/' + action + '.log'] = logs / ('scan-' + linkage + '-' + action + '.log')
    windows[linkage] = {'status': 'PASS', 'candidate': candidate, 'suites': suites,
                       'tests': sum(s['tests'] for s in suites), 'source_and_masm_checks': 2,
                       'dlls_adjacent': True, 'path_unset': True, 'error_mode': '0x8003'}
focused = json.loads((task / 'w1-static/result.json').read_text())
assert focused['status'] == 'PASS' and focused['candidate'] == candidate
for path in (task / 'w1-static').iterdir():
    if path.is_file():
        raw['first-focused/' + path.name] = path
for name in ('selected-plan.json', 'y27-candidate.json', 'run-focused.py', 'run-air.py', 'run-mini.py',
             'pack-platform.py', 'archive-results.py'):
    raw['commands/' + name] = task / name
raw['commands/w1-run.ps1'] = task.parent / 'vulkan-gather/w1-run.ps1'
archive = output / 'w1-raw.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as package:
    for name, path in raw.items():
        package.write(path, name)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    assert all(hashlib.sha256(package.read(name)).hexdigest() == sha(path) for name, path in raw.items())
platforms = {}
for platform in ('air', 'mini'):
    name = 'y27-' + platform + '-focused'
    receipt = json.loads((task / (name + '.json')).read_text())
    native_archive = task / (name + '.zip')
    assert receipt['status'] == 'PASS' and receipt['candidate'] == candidate
    assert receipt['archive_sha256'] == sha(native_archive)
    with zipfile.ZipFile(native_archive) as package:
        assert package.testzip() is None
    write_json(output / (name + '.json'), receipt)
    shutil.copy2(native_archive, output / native_archive.name)
    platforms[platform] = {'receipt': name + '.json', 'tests': sum(a['tests'] for a in receipt['result']['artifacts'])}
result = {'candidate': candidate, 'status': 'PASS', 'scope': 'Y27 F32 native Scan and existing provider/Direct/Graph regression',
          'windows': windows, 'macos': platforms,
          'cases': sum(w['tests'] for w in windows.values()) + sum(p['tests'] for p in platforms.values()),
          'first_focused_tests_not_added_again': 6, 'product_corrections': 0,
          'windows_archive': archive.name, 'windows_archive_sha256': sha(archive),
          'not_claimed': ['I32 Scan', 'Scatter', 'Scan three-delivery journey', 'complete C1', 'global package gates', 'P1']}
write_json(output / 'result.json', result)
print(json.dumps({'candidate': candidate, 'native_cases': result['cases'], 'product_corrections': 0,
                  'windows_archive_sha256': sha(archive)}))
