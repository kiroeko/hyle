import argparse
import hashlib
import json
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

identity = json.loads((root / 'logs/identity.json').read_text())
assert identity['state'] == 'PASS'
assert identity['snapshot'] == '351ec13d82057402594a96fcc862bcdc96b2d839'
assert all(x['exit_code'] == 0 for x in identity['records'])
assert identity['producer_paths_hidden_before_sdk_consumption']
assert len(identity['executables']) == 6
assert not any((root / x).exists() for x in ('bs', 'bd', 'complete-source', 'sdk-static', 'sdk-shared'))
assert all((root / x).is_dir() for x in ('bs-hidden', 'bd-hidden', 'complete-source-hidden'))
suffix = '.exe' if identity['platform'] == 'Windows' else ''
for label, expected in identity['executables'].items():
    directory, filename = label.split('/')
    if directory == 'bs':
        directory += '-hidden'
    assert digest(root / directory / (filename + suffix)) == expected
for name, expected in identity['logs'].items():
    assert digest(root / 'logs' / name) == expected

files = {}
def add_tree(directory, prefix):
    for p in sorted(directory.rglob('*')):
        if p.is_file():
            files[prefix + '/' + p.relative_to(directory).as_posix()] = p

add_tree(root / 'logs', 'logs')
for linkage in ('static', 'shared'):
    prefix = root / ('relocated-sdk-' + linkage)
    add_tree(prefix / 'lib/cmake/Hyle', linkage + '/exports')
    add_tree(prefix / 'share/licenses/Hyle', linkage + '/licenses')
for p in (root / 'complete-source-hidden').glob('hyle-*-source/SOURCE-MANIFEST.txt'):
    files['source/SOURCE-MANIFEST.txt'] = p
for name in ('verify-delivery.py', 'archive-delivery.py', 'relocate.ps1'):
    p = Path(__file__).with_name(name)
    if p.is_file():
        files['controller/' + name] = p
manifest = {name: {'sha256': digest(p), 'bytes': p.stat().st_size} for name, p in files.items()}
with zipfile.ZipFile(args.output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, p in files.items():
        archive.write(p, name)
    archive.writestr('archive-manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(args.output) as archive:
    for name, record in manifest.items():
        payload = archive.read(name)
        assert len(payload) == record['bytes']
        assert hashlib.sha256(payload).hexdigest() == record['sha256']
receipt = {
    'snapshot': identity['snapshot'], 'product_candidate': identity['product_candidate'],
    'platform': identity['platform'], 'status': 'PASS',
    'archive': str(args.output), 'sha256': digest(args.output),
    'files': len(manifest) + 1, 'bytes': args.output.stat().st_size,
    'source_archive_sha256': identity['source_archive_sha256'],
    'journeys': ['source Direct + Graph', 'relocated installed static Direct + Graph',
                 'relocated installed shared Direct + Graph'],
    'executable_count': len(identity['executables']),
    'limitations': 'F32 mixed native/ggml FFN + application SPIR-V, generated weights; no full C1, model, or performance verdict'
}
args.output.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
