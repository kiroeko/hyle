param([string]$Root, [string]$Source, [string]$Destination)
$ErrorActionPreference = 'Stop'
$boundary = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $Root).Path).TrimEnd('\') + '\'
$from = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $Source).Path)
$to = [IO.Path]::GetFullPath($Destination)
if (-not $from.StartsWith($boundary, [StringComparison]::OrdinalIgnoreCase) -or
    -not $to.StartsWith($boundary, [StringComparison]::OrdinalIgnoreCase)) { throw 'Move escaped delivery workspace' }
if (Test-Path -LiteralPath $to) { throw 'Destination already exists' }
if ((Get-Item -LiteralPath $from).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Refuse reparse source' }
Move-Item -LiteralPath $from -Destination $to
