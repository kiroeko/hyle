import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[4]
out = Path(__file__).resolve().parent / 'w1-static'
out.mkdir(exist_ok=False)
candidate = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert candidate.startswith('f0115f967f0e4ad302778ecd909b7f918d7c7845')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
build = Path('C:/hyle-scratch/active-vk/static')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ctypes.windll.kernel32.SetErrorMode(0x8003)
env = dict(os.environ, VK_LAYER_PATH='C:/public/tools/hyle-vulkan/1.4.357.0/Bin',
           VK_INSTANCE_LAYERS='VK_LAYER_KHRONOS_validation', VK_LOADER_LAYERS_DISABLE='~implicit~',
           HYLE_TEST_VULKAN_VALIDATE='1', HYLE_VULKAN_VALIDATION='1', TRACY_ONLY_LOCALHOST='1')
env.pop('PATH', None)
env.pop('GTEST_FILTER', None)
result = {'candidate': candidate, 'status': 'RUNNING', 'scope': 'Y28 first checked I32 Scan Direct/Graph regression, no P1',
          'cache_sha256': sha(build / 'CMakeCache.txt'), 'commands': []}
try:
    for factor, pattern, expected in [('compute_route_vulkan', 'VulkanIntegerScan.*', 8),
                                      ('graph_route_vulkan', 'VulkanGraph.IntegerScan*', 1)]:
        exe = build / 'bin' / ('hyle_' + factor + '_test.exe')
        log = out / (factor + '.log')
        report = out / (factor + '.json')
        command = [str(exe), '--gtest_filter=' + pattern, '--gtest_output=json:' + str(report)]
        started = time.monotonic()
        with log.open('w') as stream:
            done = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=360)
        row = {'factor': factor, 'command': command, 'exit_code': done.returncode,
               'seconds': time.monotonic() - started, 'log_sha256': sha(log), 'executable_sha256': sha(exe)}
        result['commands'].append(row)
        text = log.read_text(encoding='utf-8', errors='replace')
        print(text[-5000:], flush=True)
        done.check_returncode()
        assert not any(s in text for s in ('VUID-', 'Validation Error', 'SYNC-HAZARD'))
        data = json.loads(report.read_text())
        assert data['tests'] == expected and data['failures'] == 0 and data['errors'] == 0
        assert all(t['status'] == 'RUN' and t['result'] == 'COMPLETED' for s in data['testsuites'] for t in s['testsuite'])
        row['tests'] = data['tests']
        row['gtest_sha256'] = sha(report)
    result['status'] = 'PASS'
except BaseException as error:
    result['status'] = 'FAIL'
    result['failure'] = str(error)
    raise
finally:
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
