[CmdletBinding()]
param([ValidateSet('compute','graph')][string]$Component)
$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-cpu\aa')
$target = [IO.Path]::GetFullPath((Join-Path $taskRoot ('selected-' + $Component)))
if (-not $target.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Refuse a smoke root outside the active delivery directory'
}
$sourceRoot = 'C:\public\project-hyle\hyle'
$logRoot = Join-Path $sourceRoot '.scratch\validation\onednn-aa'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CMAKE_TOOLCHAIN_FILE = Join-Path $logRoot 'delivery-toolchain.cmake'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleAaProducerErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[HyleAaProducerErrorMode]::SetErrorMode(0x8003) | Out-Null
$log = Join-Path $logRoot ('delivery-' + $Component + '.log')
$before = & git -C $sourceRoot rev-parse HEAD
& (Join-Path $sourceRoot 'scripts\hyle-windows.ps1') -Action SelectedComponentSmoke -Component $Component -SmokeRoot $taskRoot -ExtraArgs @('-DCMAKE_CTEST_COMMAND=C:/public/project-hyle/hyle/.scratch/validation/onednn-aa/delivery-ctest.cmd') > $log 2>&1
$code = $LASTEXITCODE
$after = & git -C $sourceRoot rev-parse HEAD
if ($before -ne $after) {throw 'Product candidate changed during delivery'}
Get-Content -LiteralPath $log -Tail 26
exit $code
