$ErrorActionPreference = 'Stop'
$canonicalRoot = 'C:\public\project-hyle\hyle'
$taskRoot = [IO.Path]::GetFullPath('C:\hyle-scratch\active-cpu\aa')
$graphRoot = [IO.Path]::GetFullPath((Join-Path $taskRoot 'selected-graph'))
if (-not $graphRoot.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Resume target is outside the active task root'
}
foreach ($linkage in @('shared','static')) {
  foreach ($suffix in @('-sdk-staging','-sdk-relocated')) {
    if (Test-Path -LiteralPath (Join-Path $graphRoot ($linkage + $suffix))) {
      throw 'Graph resume is only valid before its first SDK installation'
    }
  }
}
$logRoot = Join-Path $canonicalRoot '.scratch\validation\onednn-aa'
$env:HYLE_DEP_SOURCE_CACHE = 'C:\public\tools\hyle-dependencies\v1'
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$env:CMAKE_TOOLCHAIN_FILE = Join-Path $logRoot 'delivery-toolchain.cmake'
Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public static class HyleGraphResumeErrorMode { [DllImport("kernel32.dll")] public static extern uint SetErrorMode(uint mode); }'
[HyleGraphResumeErrorMode]::SetErrorMode(0x8003) | Out-Null
$frozenCandidate = '0faf698c28457a87716b086b52dfcbea7ae57341'
if ((& git -C $canonicalRoot rev-parse HEAD) -ne $frozenCandidate) { throw 'Candidate changed before resume' }
if (& git -C $canonicalRoot status --porcelain) { throw 'Tracked workspace is not clean' }
$resumeLog = Join-Path $logRoot 'delivery-graph-resume.log'
& {
  Write-Output "Graph delivery resume candidate $frozenCandidate"
  # Import the standard compiler environment and incrementally rebuild the fixed sample.
  . (Join-Path $canonicalRoot 'scripts\hyle-windows.ps1') -Action Build -BinaryDir (Join-Path $graphRoot 'source-build') -ExtraArgs @('--parallel','2')
  if ($LASTEXITCODE -ne 0) { throw "Source incremental build failed: $LASTEXITCODE" }
  & (Join-Path $logRoot 'delivery-ctest.cmd') --test-dir (Join-Path $graphRoot 'source-build') -C Release --timeout 30 --output-on-failure
  if ($LASTEXITCODE -ne 0) { throw "Source consumer failed: $LASTEXITCODE" }
  # The source journey above has actually run. Keep every original SDK check unchanged.
  & 'C:\Program Files\CMake\bin\cmake.exe' "-DHYLE_SOURCE_DIR=$canonicalRoot" "-DHYLE_SMOKE_ROOT=$taskRoot" -DHYLE_SMOKE_COMPONENT=graph -DHYLE_SMOKE_GENERATOR=Ninja '-DCMAKE_CTEST_COMMAND=C:/public/project-hyle/hyle/.scratch/validation/onednn-aa/delivery-ctest.cmd' -P (Join-Path $logRoot 'delivery-graph-resume.cmake')
  if ($LASTEXITCODE -ne 0) { throw "Installed graph delivery failed: $LASTEXITCODE" }
} > $resumeLog 2>&1
if ((& git -C $canonicalRoot rev-parse HEAD) -ne $frozenCandidate) { throw 'Candidate changed during resume' }
if (& git -C $canonicalRoot status --porcelain) { throw 'Tracked workspace changed during resume' }
Get-Content -LiteralPath $resumeLog -Tail 26
