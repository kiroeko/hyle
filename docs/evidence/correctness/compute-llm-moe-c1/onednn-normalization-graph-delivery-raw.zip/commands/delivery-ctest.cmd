@echo off
"C:\Program Files\PowerShell\7\pwsh.exe" -NoProfile -File "C:\public\project-hyle\hyle\.scratch\validation\onednn-aa\delivery-ctest.ps1" %*
exit /b %errorlevel%
