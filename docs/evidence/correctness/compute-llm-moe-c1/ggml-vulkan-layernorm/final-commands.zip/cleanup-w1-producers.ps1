$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\public\project-hyle\hyle\.scratch\validation\vulkan-layernorm'
$expectedRoot = 'C:\hyle-scratch\active-vk\g33v'
$resolvedRoot = (Resolve-Path -LiteralPath $expectedRoot).Path
if (-not [string]::Equals($resolvedRoot,$expectedRoot,[StringComparison]::OrdinalIgnoreCase)) { throw 'Cleanup root drift' }
$proof = Get-Content -LiteralPath (Join-Path $taskRoot 'proof\windows-validation.json') -Raw | ConvertFrom-Json
$archive = Join-Path (Join-Path $taskRoot 'proof') $proof.archive
if ($proof.status -ne 'PASS' -or (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $proof.archive_sha256) { throw 'Qualification archive invalid' }
$active = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -in @('cmake.exe','ninja.exe','cl.exe','python.exe') -and $_.CommandLine -match 'active-vk[\\/]g33v[\\/]'
})
if ($active.Count -ne 0) { throw 'Producer or consumer still active' }
$targets = @()
$links = @()
foreach ($component in @('compute','graph')) {
    foreach ($build in @('source-build','shared-sdk-build','static-sdk-build')) {
        $requested = Join-Path $resolvedRoot ('delivery-' + $component + '\selected-' + $component + '\' + $build)
        $resolved = (Resolve-Path -LiteralPath $requested).Path
        if (-not [string]::Equals($resolved,$requested,[StringComparison]::OrdinalIgnoreCase) -or
            -not $resolved.StartsWith($resolvedRoot + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Producer target escaped' }
        $items = @(Get-ChildItem -LiteralPath $resolved -Force -Recurse)
        if ((Get-Item -LiteralPath $resolved).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Producer root is a reparse point' }
        foreach ($link in @($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })) {
            if ($link.PSIsContainer -or $link.LinkType -ne 'SymbolicLink' -or $link.Name -ne 'SYSTEM.md' -or $link.Directory.Name -ne '.pi') { throw 'Unexpected producer link' }
            $targetPath = [IO.Path]::GetFullPath((Join-Path $link.DirectoryName $link.Target))
            if (-not $targetPath.StartsWith($resolved + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Link target escapes producer' }
            $links += [ordered]@{path=$link.FullName;target=$targetPath}
        }
        $files = @($items | Where-Object { -not $_.PSIsContainer -and -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) })
        $targets += [ordered]@{path=$resolved;files=$files.Count;logical_bytes=($files | Measure-Object Length -Sum).Sum}
    }
}
foreach ($link in $links) { Remove-Item -LiteralPath $link.path -Force }
foreach ($target in $targets) {
    Remove-Item -LiteralPath $target.path -Recurse -Force
    if (Test-Path -LiteralPath $target.path) { throw 'Producer removal incomplete' }
}
$receipt = [ordered]@{
    candidate=$proof.candidate;status='PASS';scope='Six duplicate Vulkan delivery producers; qualified SDKs, installed consumers and active module caches retained'
    qualification_archive_sha256=$proof.archive_sha256;targets=$targets;local_vendor_links_removed=$links
    logical_bytes_removed=($targets | Measure-Object logical_bytes -Sum).Sum
}
$json = ($receipt | ConvertTo-Json -Depth 8) -replace "`r`n", "`n"
[IO.File]::WriteAllText((Join-Path $taskRoot 'proof\windows-producer-cleanup.json'),$json + "`n",[Text.UTF8Encoding]::new($false))
Write-Output $json
