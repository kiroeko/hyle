import hashlib,json,os,subprocess,time,zipfile
from pathlib import Path
ROOT=Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918')
META=json.loads((ROOT/'y33-candidate.json').read_text())
LOGS=ROOT/('y33-'+META['candidate'][:8])
SOURCE=ROOT/'source';BUILD=ROOT/'build-vulkan-static';TOOLS=ROOT/'t-mini-vulkan-tools'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((LOGS/'result.json').read_text())
assert record['candidate']==META['candidate'] and record['validation_layer'].startswith('not installed;')
assert [r['label'] for r in record['commands']]==['configure','build','source-contract','compute_provider_ggml_vulkan']
assert all(r['exit_code']==0 for r in record['commands'])
for path,digest in META['verified_implementation_files'].items():assert sha(SOURCE/path)==digest,path
report=json.loads((LOGS/'compute_provider_ggml_vulkan.json').read_text())
assert report['tests']==19 and report['failures']==report['errors']==0 and report.get('skipped',0)==1
skipped=[g['name']+'.'+t['name'] for g in report['testsuites'] for t in g['testsuite'] if t['result']=='SKIPPED']
assert skipped==['GgmlVulkanNative.ExplicitValidationUsesItsOwnInstance']
failure=ROOT/'y33-mini-initial-harness.zip';assert not failure.exists()
files={p.relative_to(LOGS).as_posix():p for p in LOGS.rglob('*') if p.is_file()}
files['commands/run-y33-mini.py']=ROOT/'run-y33-mini.py'
with zipfile.ZipFile(failure,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in files.items():z.write(p,name)
with zipfile.ZipFile(failure) as z:
 assert z.testzip() is None
 for name,p in files.items():assert z.read(name)==p.read_bytes()
record.update(verdict='RUNNING',
 initial_harness={'archive':failure.name,'sha256':sha(failure),'reason':'Harness incorrectly required validation-layer case on declared correctness-only Mini; source/build/18 provider cases passed; Direct/Graph not yet run'},
 excluded_cases=[{'name':skipped[0],'status':'SKIPPED','reason':'Validation layer not installed; dedicated layer risk is verified on W1 and Air, not claimed on Mini'}])
env=os.environ.copy()
env.update(PATH='/Users/kiro/hyle-verify-tools/bin:'+env['PATH'],CMAKE_BUILD_PARALLEL_LEVEL='2',
 CTEST_PARALLEL_LEVEL='1',TRACY_ONLY_LOCALHOST='1',DYLD_LIBRARY_PATH=str(TOOLS/'lib'),
 VK_ICD_FILENAMES=str(TOOLS/'MoltenVK_icd.json'),VK_LOADER_LAYERS_DISABLE='~implicit~')
def save():(LOGS/'result.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 save()
 for suite in ('compute_route_vulkan','graph_route_vulkan'):
  print('RUN '+suite,flush=True);log=LOGS/(suite+'.log');output=LOGS/(suite+'.json')
  assert not log.exists() and not output.exists()
  command=[str(BUILD/'bin'/('hyle_'+suite+'_test')),'--gtest_output=json:'+str(output)]
  start=time.monotonic()
  with log.open('wb') as stream:
   rc=subprocess.run(command,cwd=SOURCE,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=300).returncode
  record['commands'].append({'label':suite,'command':command,'exit_code':rc,'seconds':time.monotonic()-start,
   'log':str(log),'sha256':sha(log)})
  save();assert rc==0
  data=json.loads(output.read_text())
  assert data['tests']==META['expected_tests']['mini'][suite] and data['failures']==data['errors']==data.get('skipped',0)==0
  assert all(t['status']=='RUN' and t['result']=='COMPLETED' for g in data['testsuites'] for t in g['testsuite'])
 record['artifacts']=[]
 for suite in ('compute_provider_ggml_vulkan','compute_route_vulkan','graph_route_vulkan'):
  data=json.loads((LOGS/(suite+'.json')).read_text());exe=BUILD/'bin'/('hyle_'+suite+'_test')
  record['artifacts'].append({'path':str(exe),'sha256':sha(exe),'tests':data['tests'],
    'passed':data['tests']-data.get('skipped',0),'skipped':data.get('skipped',0)})
 record.update(verdict='PASS',scope='C1-Y33 Mini correctness/portability: 131 cases passed, one validation-layer case explicitly SKIPPED; no layer or performance claim')
except BaseException as error:
 record.update(verdict='FAIL',error=str(error));raise
finally:save()
print('Mini correctness: 131 PASS, 1 declared validation-layer SKIPPED',flush=True)
