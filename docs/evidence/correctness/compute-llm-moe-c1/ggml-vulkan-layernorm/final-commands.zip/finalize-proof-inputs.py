import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
proof = root / 'proof'
candidate = '4d255a5174825dc669de1684affd7729d3b430d7'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

for name in ('windows-validation', 'y33-air-focused', 'y33-mini-focused', 'air-delivery'):
    receipt = json.loads((proof / (name + '.json')).read_text(encoding='utf-8-sig'))
    assert receipt['candidate'] == candidate and receipt['status'] == 'PASS'
    archive = proof / receipt['archive']
    assert archive.stat().st_size == receipt['archive_bytes']
    assert sha(archive) == receipt['archive_sha256']
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
    print(name, 'PASS', archive.stat().st_size)

inputs = json.loads((root / 'inputs.json').read_text(encoding='utf-8'))
air = json.loads((proof / 'air-delivery.json').read_text(encoding='utf-8'))
for key in ('candidate', 'source_archive_sha256', 'fixture_receipt_sha256', 'consumer_files'):
    assert inputs[key] == air[key], key
assert len(air['tests']) == 3
assert all(t['cases'] == 60 and t['runs'] == 180 for t in air['tests'].values())

cleanup = proof / 'windows-producer-cleanup.json'
original = proof / 'windows-producer-cleanup-initial.json'
assert not original.exists()
original.write_bytes(cleanup.read_bytes())
data = json.loads(cleanup.read_text(encoding='utf-8'))
assert data['logical_bytes_removed'] is None
assert all(not Path(t['path']).exists() for t in data['targets'])
data['logical_bytes_removed'] = sum(int(t['logical_bytes']) for t in data['targets'])
data['receipt_correction'] = {
    'original': original.name,
    'sha256': sha(original),
    'reason': 'Measure-Object did not enumerate ordered-dictionary fields; aggregate corrected from unchanged per-target byte counts. No deletion repeated.',
}
cleanup.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')
print('windows duplicate producers logical bytes removed', data['logical_bytes_removed'])

source = root.parent / 'vulkan-c1-fragment/cleanup-air-delivery.py'
script = source.read_text(encoding='utf-8').replace('delivery-y31', 'delivery-y33').replace('y31-inputs', 'y33-inputs')
script = script.replace('a03f6786bfd9ecdcf0e158d5ea90f1a627f31236', candidate)
script = script.replace("'producers': records,", "'producers': records, 'logical_bytes_removed': sum(r['logical_bytes'] for r in records),")
(root / 'cleanup-air-delivery.py').write_text(script, encoding='utf-8', newline='\n')
