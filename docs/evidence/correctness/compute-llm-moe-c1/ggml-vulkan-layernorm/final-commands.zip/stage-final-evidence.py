import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parent
repo = root.parents[2]
proof = root / 'proof'
dest = repo / 'evidence/correctness/compute-llm-moe-c1/ggml-vulkan-layernorm'
assert (dest / 'source-audit.json').is_file()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
names = [
    'windows-validation.json', 'windows-raw.zip',
    'y33-air-focused.json', 'y33-air-focused.zip',
    'y33-mini-focused.json', 'y33-mini-focused.zip',
    'air-delivery.json', 'air-delivery.zip',
    'all-implementation-loc.json',
    'windows-producer-cleanup.json', 'windows-producer-cleanup-initial.json',
    'air-producer-cleanup.json',
]
for name in names:
    assert (proof / name).is_file() and not (dest / name).exists(), name
for name in names:
    shutil.copyfile(proof / name, dest / name)
    assert sha(proof / name) == sha(dest / name)
for name in ('aborted-delivery-cleanup.json', 'consumer-contract.json', 'inputs.json'):
    assert not (dest / name).exists()
    shutil.copyfile(root / name, dest / name)

commands = [
    'cleanup-w1-producers.ps1', 'cleanup-air-delivery.py', 'finalize-proof-inputs.py',
    'resume-y33-mini.py', 'resume-y33-mini-initial.py', 'pack-y33-mini.py',
    'stage-final-evidence.py',
]
archive = dest / 'final-commands.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as package:
    for name in commands:
        package.write(root / name, name)
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for name in commands:
        assert hashlib.sha256(package.read(name)).hexdigest() == sha(root / name)

w1 = read(dest / 'windows-validation.json')
air = read(dest / 'air-delivery.json')
air_focus = read(dest / 'y33-air-focused.json')
mini = read(dest / 'y33-mini-focused.json')
candidate = w1['candidate']
assert all(r['candidate'] == candidate and r['status'] == 'PASS' for r in (air, air_focus, mini))
assert len(w1['actual_layernorm_deliveries']) == len(air['tests']) == 3
loc = read(dest / 'all-implementation-loc.json')
metric = next(m for m in loc['metrics'] if m['id'] == 'module')
assert loc['self_check'] == 'pass' and metric['code'] == 48424 and metric['files'] == 196
cleanup_names = ('aborted-delivery-cleanup.json', 'windows-producer-cleanup.json', 'air-producer-cleanup.json')
cleanup = {name: int(read(dest / name)['logical_bytes_removed']) for name in cleanup_names}
assert sum(cleanup.values()) == 4207211641
summary = {
    'candidate': candidate,
    'scope': 'C1-Y33 qualified mature Vulkan LayerNorm integration, finite Y33-A through Y33-D only',
    'status': 'PASS',
    'module_cpp_tests': {
        'W1-static': {'passed': sum(w1['module_cpp_tests']['static'].values()), 'skipped': 0},
        'W1-shared': {'passed': sum(w1['module_cpp_tests']['shared'].values()), 'skipped': 0},
        'Air-static': {'passed': sum(a['tests'] for a in air_focus['result']['artifacts']), 'skipped': 0},
        'Mini-static': {'passed': sum(a['passed'] for a in mini['result']['artifacts']),
                        'skipped': sum(a['skipped'] for a in mini['result']['artifacts']),
                        'skip': 'GgmlVulkanNative.ExplicitValidationUsesItsOwnInstance: layer not installed; validation covered by W1 and Air'},
    },
    'selected_gates': {'passed': w1['selected_gates']['passed'], 'skipped_with_reasons': w1['selected_gates']['skipped']},
    'actual_layernorm_delivery': {
        'journeys': 6,
        'platforms': ['Windows RTX 4070', 'Air Mac16,12'],
        'linkages': ['source', 'static', 'shared'],
        'case_executions_across_journeys': 360,
        'runs': 1080,
        'retained_after_close': 360,
        'quota_zero': 360,
        'consumer': air['consumer_files'],
        'source_archive_sha256': air['source_archive_sha256'],
        'fixture_receipt_sha256': air['fixture_receipt_sha256'],
        'scope': 'Orthogonal foundation consumer on local Qwen3.5-2B inputs, not original model forward',
    },
    'corrections': {'product_and_tests': 2, 'algorithm': 0, 'external_consumer_compile': 1},
    'implementation_loc': {'code': metric['code'], 'files': metric['files'], 'self_check': 'pass', 'excludes': ['tests', 'bench', 'third_party']},
    'cleanup_logical_bytes': cleanup,
    'total_cleanup_logical_bytes': sum(cleanup.values()),
    'performance': {'executed': False, 'verdict': 'NOT_RUN', 'reason': 'Complete C1 provider-binding candidate not yet fixed; no winner or deletion decision'},
    'remaining': ['Mature Reduce/Softmax and other registered C1 integrations', 'CUDA/Apple coverage review',
                  'Full-cost performance qualification and routing/retirement', 'CPU Q2 independent measurement qualification BLOCKED',
                  'Full C1 and 64-row/256-cell matrix acceptance'],
    'milestone': 'C1 completion notification not triggered; do not enter C2',
    'supersedes_pending_fields_only': 'Windows receipt remaining and frozen input states are historical; later receipts qualify Air/Mini and actual delivery without rerunning W1',
    'evidence': [{'file': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p)}
                 for p in sorted(dest.iterdir()) if p.is_file() and p.name != 'README.md'],
}
(dest / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

registry = repo / 'docs/implementation/module-status.json'
data = read(registry)
owners = {'compute_route_vulkan', 'graph_route_vulkan', 'compute_provider_ggml_vulkan'}
changed = set()
for module in data['modules']:
    if module['module'] in owners:
        assert module['state'] == 'AUDITED'
        module['summary'] = ('LLM/MoE C1-Y33 AUDITED：4d255a51的成熟LayerNorm接入完成W1 static/shared 132/131、Air132、Mini131通过/验证层1跳过，W1/Air实际三交付360例/1080次执行通过；selected9门通过。归约/Softmax等接入、整包P1/优选/淘汰未签收，CPU Q2 BLOCKED保持。')
        changed.add(module['module'])
assert changed == owners
registry.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'status': 'PASS', 'staged': len(list(dest.iterdir())), 'logical_bytes_removed': sum(cleanup.values())}))
