import hashlib
import json
import os
from pathlib import Path
import shutil
import zipfile

base = Path('/Users/kiro/hyle-verify/llm-moe-c1-20260918').resolve()
root = (base / 'delivery-y33').resolve()
assert root.parent == base and not root.is_symlink()
archive = base / 'y33-inputs/air-delivery.zip'
receipt = json.loads((base / 'y33-inputs/air-delivery.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert receipt['status'] == 'PASS'
assert receipt['candidate'] == '4d255a5174825dc669de1684affd7729d3b430d7'
assert sha(archive) == receipt['archive_sha256']
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    for p in (root / 'logs').rglob('*'):
        if p.is_file():
            assert hashlib.sha256(package.read('logs/' + p.relative_to(root / 'logs').as_posix())).hexdigest() == sha(p)
records = []
for name in ('bs-hidden', 'bd-hidden', 'complete-source-hidden'):
    target = root / name
    assert target.is_dir() and not target.is_symlink() and target.resolve().parent == root
    logical_bytes = 0
    count = 0
    for current, directories, files in os.walk(target, followlinks=False):
        assert not any((Path(current) / d).is_symlink() for d in directories)
        for filename in files:
            p = Path(current) / filename
            logical_bytes += p.lstat().st_size
            count += 1
    records.append({'path': str(target), 'files': count, 'logical_bytes': logical_bytes})
for record in records:
    shutil.rmtree(record['path'])
    assert not Path(record['path']).exists()
result = {'state': 'PASS', 'candidate': receipt['candidate'],
          'archive_sha256': receipt['archive_sha256'], 'producers': records, 'logical_bytes_removed': sum(r['logical_bytes'] for r in records),
          'retained': ['relocated-sdk-static', 'relocated-sdk-shared', 'consumer-static',
                       'consumer-shared', 'fixtures', 'logs', 'independent-consumer']}
with (base / 'y33-inputs/air-producer-cleanup.json').open('w', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'state': 'PASS', 'removed_logical_bytes': sum(r['logical_bytes'] for r in records)}))
