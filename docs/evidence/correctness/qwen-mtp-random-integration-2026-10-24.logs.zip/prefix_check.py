from pathlib import Path
import importlib.util,os,json
O=Path(__file__).resolve().parent;R=O.parents[2];B=R/'.scratch/mtp-full-quant-20261024/engine-check'
s=importlib.util.spec_from_file_location('h',B/'check.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);h.OUT=O
I=O/'session-inputs';I.mkdir(exist_ok=True)
ids=(R/'.scratch/qwen-mtp-window-20261022/inputs/mtp/prompt.ids').read_text().split()
(I/'p15.ids').write_text(' '.join(ids[:15]));(I/'p23.ids').write_text(' '.join(ids[:23]))
for name,count in [('same',15),('longer',23)]: (I/(name+'.txt')).write_text('prompt p'+str(count)+'.ids\ngenerate 1\n')
(I/'full.txt').write_text('alice same.txt\nbob same.txt\n')
(I/'partial.txt').write_text('alice same.txt\nbob longer.txt\n')
ready=h.b.read(O/'ready-cuda.json');env=dict(os.environ,PATH=ready['PATH'])
for case in ['full','partial']:
 args=[ready['image']['path'],'--inputs',str(R/'.scratch/qwen-mtp-window-20261022/inputs/mtp'),'--mtp','on','--capacity','64','--max-sessions','1','--active-sequences','1','--prefix-cache','auto','--sampling','random','--temperature','1.5','--top-k','40','--top-p','0.95','--seed','123','--replay','commands','--session-schedules',str(I/(case+'.txt'))]
 h.execute(args,env,'prefix-'+case,180)
 p=json.loads((O/('prefix-'+case)/'stdout.log').read_text().strip().splitlines()[-1]);h.b.save(O/('prefix-'+case)/'parsed.json',p)
 print(case, json.dumps(p)[-6000:])
