"""One model TU, retained current ABI objects/runtime; no SDK build or download."""
import importlib.util,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent; R=O.parents[2]; B=R/'.scratch/mtp-full-quant-20261024/engine-check'
s=importlib.util.spec_from_file_location('h',B/'check.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);h.OUT=O;b=h.b

def build(backend):
    label='model'+('-cuda' if backend=='cuda' else '')
    old=b.read(B/label/'identity.json');cl=old['command'][0]
    native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=())
    folder=O/label;folder.mkdir(exist_ok=True)
    command=[a.replace(str(B/label),str(folder)) for a in old['command']]
    source=b.identity(R/'engine/models/qwen35/main.cc')
    h.execute(command,native.env,label,180)
    if b.identity(source['path'])!=source: raise RuntimeError('Model changed during compilation')
    b.save(folder/'identity.json',dict(source=source,object=b.identity(folder/'qwen.obj'),command=command))
    plan=b.read(B/('cuda-link-plan.json' if backend=='cuda' else 'link-plan.json'))
    image=O/'native-current'/('hyle-'+backend+'.exe');image.parent.mkdir(exist_ok=True)
    link=[]
    for arg in plan['command']:
        if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')): continue
        link.append(str(folder/'qwen.obj') if arg==str(B/label/'qwen.obj') else arg)
    link += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    b.save(O/('link-'+backend+'.json'),dict(command=link,closure=b.identity(B/('cuda-link-plan.json' if backend=='cuda' else 'link-plan.json')),fresh_TUs=1,downloads=0))
    h.execute(link,native.env,'link-'+backend,120)
    ready=b.read(B/('ready-cuda.json' if backend=='cuda' else 'ready.json'))
    runtime=b.read(B/'ready.json')['native_runtime'];b.require(runtime)
    target=image.parent/Path(runtime['path']).name
    if not target.exists(): os.link(runtime['path'],target)
    elif b.identity(target)['sha256']!=runtime['sha256']: raise RuntimeError('native runtime hash differs')
    b.save(O/('ready-'+backend+'.json'),dict(image=b.identity(image),PATH=str(image.parent)+os.pathsep+ready['PATH'],native_runtime=runtime))

if __name__=='__main__': build(sys.argv[1])
