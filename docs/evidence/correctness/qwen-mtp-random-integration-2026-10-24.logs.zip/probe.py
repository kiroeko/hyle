import importlib.util,os,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[2];B=R/'.scratch/mtp-full-quant-20261024/engine-check'
s=importlib.util.spec_from_file_location('h',B/'check.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);h.OUT=O;b=h.b
old=b.read(B/'model-cuda/identity.json');cl=old['command'][0]
native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=())
objects={}
for name,source in [('probe',R/'tests/tools/qwen_random_mtp_probe.cc'),('gate',R/'engine/models/qwen35/native_gate.cc')]:
 folder=O/name;folder.mkdir(exist_ok=True);command=[];skip=False
 for arg in old['command']:
  if skip: skip=False;continue
  if arg=='/sourceDependencies': skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith('.cc'): continue
  command.append(arg)
 command += ['/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(folder/(name+'.obj')),'/Fd'+str(folder/(name+'.pdb'))]
 h.execute(command,native.env,name,180)
 b.save(folder/'identity.json',dict(source=b.identity(source),object=b.identity(folder/(name+'.obj')),command=command))
 objects[name]=folder/(name+'.obj')
image=O/'native-current/random-probe.exe';plan=b.read(B/'cuda-link-plan.json');link=[]
for arg in plan['command']:
 if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')) or arg.endswith('\\entry\\entry.obj'): continue
 link.append(str(objects['probe']) if arg==str(B/'model-cuda/qwen.obj') else arg)
link += [str(objects['gate']),'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
b.save(O/'probe-link.json',dict(command=link,closure=b.identity(B/'cuda-link-plan.json'),fresh_TUs=2,downloads=0))
h.execute(link,native.env,'probe-link',120)
ready=b.read(O/'ready-cuda.json');env=dict(os.environ,PATH=ready['PATH'])
h.execute([str(image),'--inputs',str(R/'.scratch/qwen-mtp-window-20261022/inputs/mtp')],env,'probe-run',180)
print((O/'probe-run/stdout.log').read_text()[-2000:])
