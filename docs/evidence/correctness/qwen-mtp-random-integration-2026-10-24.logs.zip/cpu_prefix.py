from pathlib import Path
O=Path(__file__).resolve().parent
p=O/'prefix_check.py'
s=p.read_text().replace('ready-cuda.json','ready-cpu.json').replace("'prefix-'+case","'cpu-prefix-'+case").replace("print(case, json.dumps(p)[-6000:])", "print(case, [(row['session_id'], row['result']['generated_ids'], row['result']['sampling_draw_cursor'],row['result']['reused_tokens']) for row in p['sessions']], flush=True)")
exec(compile(s,str(p),'exec'))
