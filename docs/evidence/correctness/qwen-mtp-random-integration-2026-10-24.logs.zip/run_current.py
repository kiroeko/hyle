import importlib.util,os,sys,json
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[2];B=R/'.scratch/mtp-full-quant-20261024/engine-check'
s=importlib.util.spec_from_file_location('h',B/'check.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);h.OUT=O
backend=sys.argv[1];mode=sys.argv[2];tag=sys.argv[3] if len(sys.argv)>3 else backend+'-'+mode
ready=h.b.read(O/('ready-'+backend+'.json'));env=dict(os.environ,PATH=ready['PATH'])
args=[ready['image']['path'],'--inputs',str(R/'.scratch/qwen-mtp-window-20261022/inputs'/('mtp' if mode=='on' else 'text')),'--mtp',mode,'--capacity','512','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--sampling','random','--temperature','1.5','--top-k','40','--top-p','0.95','--seed','123','--replay','commands']
if tag.startswith('sessions'):
    args[args.index('--max-sessions')+1]=sys.argv[4];args[args.index('--active-sequences')+1]=sys.argv[5];args[args.index('--prefix-cache')+1]='auto'
    args += ['--session-schedules',str(R/'.scratch/mtp-full-quant-20261024/session-inputs/sessions.txt')]
else: args += ['--steps','8']
h.execute(args,env,tag,600)
p=json.loads((O/tag/'stdout.log').read_text().strip().splitlines()[-1]);h.b.save(O/tag/'parsed.json',p)
print(json.dumps(p)[-6000:])
