import importlib.util,json,os,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[2];B=R/'.scratch/mtp-full-quant-20261024/engine-check'
s=importlib.util.spec_from_file_location('h',B/'check.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);h.OUT=O
backend=sys.argv[1];ready=h.b.read(O/('ready-'+backend+'.json'));env=dict(os.environ,PATH=ready['PATH']);rows=[]
for sample in ['greedy','random']:
 for mode in ['off','on']:
  label='final-'+backend+'-'+sample+'-'+mode
  args=[ready['image']['path'],'--inputs',str(R/'.scratch/qwen-mtp-window-20261022/inputs'/('mtp' if mode=='on' else 'text')),'--mtp',mode,'--steps','4','--capacity','256','--max-sessions','1','--active-sequences','1','--prefix-cache','off','--replay','commands']
  if sample=='random': args += ['--sampling','random','--temperature','0.8','--top-k','40','--top-p','0.9','--seed','123']
  h.execute(args,env,label,600)
  p=json.loads((O/label/'stdout.log').read_text().strip().splitlines()[-1]);h.b.save(O/label/'parsed.json',p)
  assert (sample != 'greedy' or p['generated_ids']==[71093,12305,198,464]) and len(p['generated_ids'])==4 and all(0 <= token < 248320 for token in p['generated_ids']),p['generated_ids']
  assert p['sampling']==sample
  assert p['sampling_draw_cursor']==(0 if sample=='greedy' else 5 if mode=='on' else 4)
  assert p['cache_retained_output_backing_bytes']==0
  rows.append(dict(label=label,source_id=p['source_id'],ids=p['generated_ids'],draw=p['sampling_draw_cursor'],payload=p['cache_shared_backing_bytes'],metadata=p['cache_metadata_requested_bytes']))
  h.b.save(O/('final-'+backend+'.json'),dict(runs=rows,performance_claim=False,quality_claim=False,downloads=0))
  print(label,'PASS',p['generated_ids'],'draw',p['sampling_draw_cursor'],flush=True)
