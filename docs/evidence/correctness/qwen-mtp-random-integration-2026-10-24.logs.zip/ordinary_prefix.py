import importlib.util,os,json
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[2];B=R/'.scratch/mtp-full-quant-20261024/engine-check';I=O/'session-inputs'
s=importlib.util.spec_from_file_location('h',B/'check.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h);h.OUT=O
(I/'plain.txt').write_text('prompt p15.ids\n');(I/'plain-sessions.txt').write_text('alice plain.txt\nbob plain.txt\n')
ready=h.b.read(O/'ready-cuda.json');env=dict(os.environ,PATH=ready['PATH'])
args=[ready['image']['path'],'--inputs',str(R/'.scratch/qwen-mtp-window-20261022/inputs/text'),'--mtp','off','--capacity','64','--max-sessions','1','--active-sequences','1','--prefix-cache','auto','--sampling','random','--temperature','1.5','--top-k','40','--top-p','0.95','--seed','123','--replay','commands','--session-schedules',str(I/'plain-sessions.txt')]
h.execute(args,env,'ordinary-prefix-full',180)
p=json.loads((O/'ordinary-prefix-full/stdout.log').read_text().strip().splitlines()[-1]);h.b.save(O/'ordinary-prefix-full/parsed.json',p);print([(x['session_id'],x['generated_ids'],x['prefix_full_hits']) for x in p['sessions']])
