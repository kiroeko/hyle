param([ValidateSet('compute', 'graph')][string]$Mode = 'compute',
      [ValidateSet('v1','v2')][string]$Attempt = 'v1')
$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$env:CMAKE_BUILD_PARALLEL_LEVEL = '2'
$r4P1Root = 'C:/hyle-scratch/r4-cuda-20260916/qualification'
$r4P1Build = if ($Mode -eq 'compute') { "C:/hv4d1$Attempt" } else { "C:/hv4g1$Attempt" }
$r4P1Out = "$r4P1Root/p1-$Mode-$Attempt"
$r4P1Log = "$r4P1Root/p1-$Mode-$Attempt-console.log"
& python scripts/hyle-perf.py qualify-platform `
  --source C:/public/project-hyle/hyle `
  --contract "bench/contracts/$Mode-cuda-ffn-p1-v1.json" `
  --machine W1-WIN --peer sglang-precise=C:/public/project-hyle/sglang `
  --build $r4P1Build --output $r4P1Out *> $r4P1Log
if ($LASTEXITCODE -ne 0) {
  Get-Content -LiteralPath $r4P1Log -Tail 65
  throw "$Mode P1 command failed; raw evidence retained"
}
Write-Output "$Mode P1 command finished; inspect manifest/summary in $r4P1Out"
