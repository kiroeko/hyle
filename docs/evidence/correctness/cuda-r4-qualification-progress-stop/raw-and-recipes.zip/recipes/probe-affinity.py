import ctypes
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('C:/hyle-scratch/r4-cuda-20260916/qualification/affinity-probe')
root.mkdir(exist_ok=True)
k = ctypes.WinDLL('kernel32', use_last_error=True)
k.GetCurrentProcess.restype = ctypes.c_void_p
k.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
k.SetErrorMode(0x8003)
if not k.SetProcessAffinityMask(k.GetCurrentProcess(), 0x14):
    raise ctypes.WinError(ctypes.get_last_error())
env = {key: value for key, value in os.environ.items()
       if not key.startswith(('HYLE_BENCH_', 'HYLE_PERF_'))}
env['HYLE_PERF_CALLER_CPU'] = '2'
env['HYLE_PERF_RUN_NONCE'] = 'bounded-two-p-core-diagnostic'
start = time.monotonic()
result = {'process_mask':'0x14','caller_cpu':2,'timeout_seconds':30,
          'purpose':'cold progress diagnostic only; no performance qualification'}
try:
    r = subprocess.run(['C:/hv4d1v1/bin/hyle_compute_route_cuda_bench.exe'],
                       env=env,capture_output=True,timeout=30,
                       creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
    result.update(exit_code=r.returncode, timed_out=False)
    (root/'two-core.log').write_bytes(r.stdout+r.stderr)
except subprocess.TimeoutExpired as e:
    result.update(timed_out=True)
    (root/'two-core.log').write_bytes((e.stdout or b'')+(e.stderr or b''))
result['elapsed_seconds'] = time.monotonic()-start
(root/'two-core.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
