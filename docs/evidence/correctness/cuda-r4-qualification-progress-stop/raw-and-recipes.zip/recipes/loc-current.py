import json
from pathlib import Path
import subprocess
root=Path('C:/public/project-hyle/hyle')
paths=['include/hyle/compute','include/hyle/graph']
paths += sorted(p.relative_to(root).as_posix() for p in (root/'src').iterdir()
                if p.is_dir() and p.name.startswith(('compute','graph')))
command=['python','scripts/loc-report.py','--module','compute_graph','--self-check','--json','--commit','HEAD']
for path in paths: command += ['--module-path',path]
result=subprocess.run(command,cwd=root,capture_output=True,check=True)
target=Path('C:/hyle-scratch/r4-cuda-20260916/qualification/loc-7b3279c8.json')
target.write_bytes(result.stdout)
data=json.loads(result.stdout)
print(json.dumps({'receipt':str(target),'keys':list(data)}))
