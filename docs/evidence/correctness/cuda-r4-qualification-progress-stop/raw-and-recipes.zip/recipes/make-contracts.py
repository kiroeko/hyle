import copy
import hashlib
import json
from pathlib import Path

root = Path('C:/public/project-hyle/hyle')
base = json.loads((root/'bench/contracts/compute-cpu-route-p1-v3.json').read_text(encoding='utf-8'))
provenance = 'bench/compute_route_cuda/consumer_shapes_v1.json'
provenance_hash = hashlib.sha256((root/provenance).read_bytes()).hexdigest()
for mode in ('compute', 'graph'):
    c = copy.deepcopy(base)
    c['id'] = f'{mode}-cuda-ffn-p1-v1'
    c['module'] = f'{mode}_route_cuda'
    kind = 'Direct FFN' if mode == 'compute' else 'Graph captured FFN'
    c['claim'] = ('W1 SM89 engineering qualification of the complete CUDA FFN: identical HYLE '
                  'lifecycle and completion semantics, with only HYLE versus pinned precise SGLang '
                  'activation differing. A 5% NI pass alone does not establish a HYLE winner. '
                  'Hardware/software identity is frozen; no extrapolation to other GPUs or versions.')
    c['candidate'] = {'target':f'hyle_{mode}_route_cuda','delivery_shape':'source',
                      'revision':'runtime-bound','component':f'{mode}_route_cuda',
                      'entrypoint':f'include/hyle/{mode}/cuda.h'}
    c['peers'] = [{'id':'sglang-precise', 'revision':'06992c92ad4494fe9f9636e75be3e35040512447',
                   'configuration': {'delivery_shape':'source',
                    'role':'Pinned exact device arithmetic/indexing, HYLE public Provider adapter identical except kernel and its vector eligibility.',
                    'flags':'CUDA 13.3.73, SM89 native + SM80 PTX, relaxed-constexpr, no fast-math, no LTO',
                    'precision':'FP32 SiLU and multiply, final FP16 rounding; round_activation=false',
                    'scope':'Packed, out-of-place, 16-byte aligned; no PDL/filter/reuse',
                    'other_implementations':'Same immutable Marlin and cuBLASLt operations in both arms'}}]
    c['workloads'] = []
    for rows in (1,16):
        title = f'{kind} M={rows} K=4096 H=11008 N=4096'
        w = copy.deepcopy(base['workloads'][2])
        w.update(id='decode-q4-ffn-m1' if rows == 1 else 'short-prefill-q4-ffn-m16',
                 tier='consumer' if mode == 'compute' else 'replay', gate_role='product',
                 consumer_key=f'inference-runtime/{"decode" if rows == 1 else "short-prefill"}/group128-q4-ffn',
                 provenance={'path':provenance,'sha256':provenance_hash},
                 ownership_topology={
                  'candidate':'Ordinary HYLE CUDA factory, two independent resident invocation/output slots, shared immutable Q4/dense weights, fixed cold preparation.',
                  'peer':'The same public runtime with pinned precise SGLang activation replacing only the actual activation implementation, separate queues and slots.',
                  'equivalence':'Same resource domain, storage sizes, changed resident inputs, admission, error propagation, retained owner and actual terminal completion. Both Graph arms require successful native capture.'},
                 material_contribution={'frequency':1,'value':1,'unit':'complete-ffn','budget':5,
                    'denominator':'one complete resident FFN accepted through actual terminal completion',
                    'derivation':'PROVISIONAL_ARCHETYPE from pinned vLLM model dimensions; M1 primary, M16 holdout; not production frequency or model throughput'},
                 semantic_contract=f'Compute Y[{rows},4096] = down(SiLU(gate(X))*up(X)); X FP16, packed gate/up signed group128 Q4 with FP16 scales/dequant, FP32 reductions, FP16 stage/output rounding. Both arms complete before return.',
                 comparability='COMPARABLE',peer_id='sglang-precise',
                 input={'distribution':'Deterministic signed finite Q4/scales/dense weights and two distinct finite resident inputs, identical distributions and cold preparation on both arms.',
                        'scale':{'rows':rows,'inner':4096,'hidden':11008,'output':4096}},
                 setup='Cold allocation, Q4 pack/upload, descriptor/algorithm/kernel binding, two slots, output comparison and eight alternating complete warm calls; Graph cold capture on both arms.',
                 charged_phases= ['Three public operation submissions and three real Completion waits; no early buffer reuse'] if mode == 'compute' else ['One public captured Graph submission and actual Completion wait; no early buffer reuse'],
                 pair={'candidate':'HYLE CUDA '+title,'peer':'SGLang precise '+title})
        c['workloads'].append(w)
    # M16 is an orthogonal shape, not a statistical train/holdout split.
    c['experiment']['holdout'] = False
    c['artifacts']['validators'] = ['artifact-identity','build-contract','cuda-ffn-aa']
    runner = c['extensions']['runner']
    runner['cmake'] = {'cache':{
        'BUILD_SHARED_LIBS':'OFF','CMAKE_INTERPROCEDURAL_OPTIMIZATION':'OFF',
        'HYLE_BUILD_BENCH':'ON','HYLE_BUILD_TESTS':'OFF','HYLE_DEV_FACTORS':f'{mode}_route_cuda',
        'HYLE_COMPUTE_CUDA':'ON','HYLE_COMPUTE_CPU':'OFF','HYLE_COMPUTE_ONEDNN':'OFF',
        'HYLE_INSTALL':'OFF','HYLE_SANITIZER':'off','HYLE_SIMD_EXACT_TARGET':'',
        'HYLE_STATIC':'ON','HYLE_TEST_INSTRUMENTATION':'OFF','HYLE_TRACE':'OFF','HYLE_WERROR':'ON',
        'CMAKE_EXPORT_COMPILE_COMMANDS':'ON'},
        'peer_cache':{'sglang-precise':'HYLE_CUDA_SGLANG_SOURCE_DIR'}}
    runner['executables'] = []
    for variant,suffix in [('primary',''),('placement','_placement')]:
        target=f'hyle_{mode}_route_cuda_bench{suffix}'
        runner['executables'].append({'id':f'{mode}-cuda-{variant}','target':target,'stem':target,
            'target_variant':variant,'measurement_batch':1,'telemetry_prefixes':['# HYLE_CUDA_FFN_RUN '],
            'workloads':[{'id':w['id'],'title':w['pair']['candidate'][len('HYLE CUDA '):]} for w in c['workloads']]})
    runner['controlled_environment'].append('HYLE_BENCH_VERIFY_ONLY')
    runner['validators'][-1] = {'id':'cuda-ffn-aa','kind':'command',
        'command':['{python}','bench/compute_route_cuda/validate_aa.py','--build','{build}',
                   '--output','{output}','--mode',mode]}
    (root/f'bench/contracts/{c["id"]}.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
