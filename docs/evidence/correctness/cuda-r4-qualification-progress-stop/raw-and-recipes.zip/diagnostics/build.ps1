$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$r4AffinityRoot = 'C:/hyle-scratch/r4-cuda-20260916/qualification/affinity-probe'
Set-Location -LiteralPath $r4AffinityRoot
$r4CudaRoot = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3'
& cl /nologo /O2 /EHsc /std:c++20 /MD "/I$r4CudaRoot/include" native.cc /link "/LIBPATH:$r4CudaRoot/lib/x64" cudart.lib cublasLt.lib /OUT:native.exe *> build.log
if ($LASTEXITCODE -ne 0) { Get-Content build.log; throw 'native diagnostic build failed' }
foreach ($r4Dll in @('cudart64_13.dll', 'cublasLt64_13.dll', 'msvcp140.dll', 'msvcp140_atomic_wait.dll', 'vcruntime140.dll', 'vcruntime140_1.dll')) {
  Copy-Item -LiteralPath "C:/hv4d1v1/bin/$r4Dll" -Destination $r4AffinityRoot
}
