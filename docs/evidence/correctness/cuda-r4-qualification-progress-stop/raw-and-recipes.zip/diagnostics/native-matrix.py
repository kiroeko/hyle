import ctypes
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
root=Path(__file__).parent
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.GetCurrentProcess.restype=ctypes.c_void_p
k.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
k.SetErrorMode(0x8003)
results=[]
name=sys.argv[1] if len(sys.argv)>1 else 'native'
target = root/(name+'.exe')
arguments=[]
if name == 'priority':
    target=root/'hyle.exe'
    arguments=['low-caller']
environment = None
if name == 'original':
    target = Path('C:/hv4d1v1/bin/hyle_compute_route_cuda_bench.exe')
    spec=importlib.util.spec_from_file_location('cuda_aa', 'C:/public/project-hyle/hyle/bench/compute_route_cuda/validate_aa.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    environment=module.child_environment()
for mask in (0x4,0x14):
    if not k.SetProcessAffinityMask(k.GetCurrentProcess(),mask):
        raise ctypes.WinError(ctypes.get_last_error())
    start=time.monotonic()
    try:
        p=subprocess.run([str(target),*arguments],capture_output=True,timeout=12,env=environment,
                         creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
        output=p.stdout+p.stderr
        row={'mask':hex(mask),'exit_code':p.returncode,'timed_out':False}
    except subprocess.TimeoutExpired as e:
        output=(e.stdout or b'')+(e.stderr or b'')
        row={'mask':hex(mask),'timed_out':True}
    row['elapsed_seconds']=time.monotonic()-start
    (root/f'{name}-{mask:x}.log').write_bytes(output)
    results.append(row)
(root/(name+'-matrix.json')).write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps(results))
