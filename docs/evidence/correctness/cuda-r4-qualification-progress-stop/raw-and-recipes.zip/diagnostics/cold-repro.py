import ctypes as c
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root=Path(__file__).parent
out=root/'cold-repro'
out.mkdir()
k=c.WinDLL('kernel32',use_last_error=True)
k.GetCurrentProcess.restype=c.c_void_p
k.SetProcessAffinityMask.argtypes=[c.c_void_p,c.c_size_t]
k.SetErrorMode(0x8003)
if not k.SetProcessAffinityMask(k.GetCurrentProcess(),4):
    raise c.WinError(c.get_last_error())
spec=importlib.util.spec_from_file_location('cuda_aa', 'C:/public/project-hyle/hyle/bench/compute_route_cuda/validate_aa.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
env=module.child_environment()
env['HYLE_BENCH_RIVAL_FIRST']='1'
env['HYLE_BENCH_PEER_ALLOCATION_FIRST']='1'
rows=[]
for index in range(24):
    start=time.monotonic()
    p=subprocess.Popen(['C:/hv4d1v2/bin/hyle_compute_route_cuda_bench.exe'],env=env,
                       stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                       creationflags=subprocess.ABOVE_NORMAL_PRIORITY_CLASS)
    row={'index':index,'pid':p.pid,'limit_seconds':10}
    try:
        stdout,stderr=p.communicate(timeout=10)
        row.update(exit_code=p.returncode,timed_out=False)
    except subprocess.TimeoutExpired:
        row['timed_out']=True
        # The process is our direct child. Inspect its busiest thread, then
        # snapshot immediately while it is still at the cold stall.
        ps=f"(Get-Process -Id {p.pid}).Threads | Sort-Object TotalProcessorTime -Descending | Select-Object -First 1 -ExpandProperty Id"
        tid=int(subprocess.check_output(['pwsh','-NoProfile','-Command',ps],text=True).strip())
        capture=subprocess.run([sys.executable,str(root/'capture-hang.py'),str(p.pid),str(tid)],capture_output=True)
        (out/'capture.log').write_bytes(capture.stdout+capture.stderr)
        row.update(tid=tid,capture_exit=capture.returncode)
        p.kill(); stdout,stderr=p.communicate()
    row['elapsed_seconds']=time.monotonic()-start
    (out/f'run-{index:02d}.log').write_bytes(stdout+stderr)
    rows.append(row)
    (out/'result.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
    if row['timed_out'] or row.get('exit_code') != 0:
        print(json.dumps(row));break
else:
    print('24 cold starts completed; no capture, no root-cause verdict')
