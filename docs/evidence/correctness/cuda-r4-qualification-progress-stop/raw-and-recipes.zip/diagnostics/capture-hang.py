import ctypes as c
from ctypes import wintypes as w
import json
import msvcrt
from pathlib import Path
import struct
import sys

pid, tid = map(int, sys.argv[1:3])  # Supplied by the owned child launcher only.
root = Path(__file__).parent
k = c.WinDLL('kernel32',use_last_error=True)
p = c.WinDLL('psapi',use_last_error=True)
k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD]; k.OpenProcess.restype=w.HANDLE
k.OpenThread.argtypes=[w.DWORD,w.BOOL,w.DWORD]; k.OpenThread.restype=w.HANDLE
k.CloseHandle.argtypes=[w.HANDLE]
k.SuspendThread.argtypes=[w.HANDLE]; k.SuspendThread.restype=w.DWORD
k.ResumeThread.argtypes=[w.HANDLE]; k.ResumeThread.restype=w.DWORD
k.GetThreadContext.argtypes=[w.HANDLE,c.c_void_p]
k.ReadProcessMemory.argtypes=[w.HANDLE,c.c_void_p,c.c_void_p,c.c_size_t,c.POINTER(c.c_size_t)]
p.EnumProcessModulesEx.argtypes=[w.HANDLE,c.c_void_p,w.DWORD,c.POINTER(w.DWORD),w.DWORD]
class Module(c.Structure):
    _fields_=[('base',c.c_void_p),('size',w.DWORD),('entry',c.c_void_p)]
p.GetModuleInformation.argtypes=[w.HANDLE,w.HMODULE,c.POINTER(Module),w.DWORD]
p.GetModuleFileNameExW.argtypes=[w.HANDLE,w.HMODULE,w.LPWSTR,w.DWORD]
process=k.OpenProcess(0x410,False,pid)
if not process: raise c.WinError(c.get_last_error())
modules=[]
handles=(w.HMODULE*1024)(); needed=w.DWORD()
if not p.EnumProcessModulesEx(process,handles,c.sizeof(handles),c.byref(needed),3):
    raise c.WinError(c.get_last_error())
for handle in handles[:needed.value//c.sizeof(w.HMODULE)]:
    info=Module(); name=c.create_unicode_buffer(32768)
    if p.GetModuleInformation(process,handle,c.byref(info),c.sizeof(info)):
        p.GetModuleFileNameExW(process,handle,name,len(name))
        modules.append({'base':info.base,'size':info.size,'path':name.value})
def address(value):
    for module in modules:
        if module['base']<=value<module['base']+module['size']:
            return {'address':hex(value),'module':module['path'],'rva':hex(value-module['base'])}
    return {'address':hex(value)}
thread=k.OpenThread(0x4a,False,tid)
if not thread: raise c.WinError(c.get_last_error())
if k.SuspendThread(thread)==0xffffffff: raise c.WinError(c.get_last_error())
try:
    storage=c.create_string_buffer(1248)
    aligned=(c.addressof(storage)+15)&~15
    c.c_uint32.from_address(aligned+48).value=0x100003
    if not k.GetThreadContext(thread,aligned): raise c.WinError(c.get_last_error())
    raw=c.string_at(aligned,1232)
    rip,rsp=struct.unpack_from('<Q',raw,248)[0],struct.unpack_from('<Q',raw,152)[0]
    stack=c.create_string_buffer(1024); count=c.c_size_t()
    if not k.ReadProcessMemory(process,rsp,stack,len(stack),c.byref(count)):
        raise c.WinError(c.get_last_error())
    values=struct.unpack('<'+'Q'*(count.value//8),stack.raw[:count.value])
    report={'pid':pid,'tid':tid,'instruction':address(rip),'rsp':hex(rsp),
            'registers':{name:hex(struct.unpack_from('<Q',raw,120+i*8)[0])
                         for i,name in enumerate(('rax','rcx','rdx','rbx','rsp','rbp','rsi','rdi','r8','r9','r10','r11','r12','r13','r14','r15','rip'))},
            'stack_candidates':[{'slot':i,**address(v)} for i,v in enumerate(values) if 'module' in address(v)],
            'modules':modules}
    (root/'hung-context.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
finally:
    k.ResumeThread(thread); k.CloseHandle(thread)
dbg=c.WinDLL('dbghelp',use_last_error=True)
dbg.MiniDumpWriteDump.argtypes=[w.HANDLE,w.DWORD,w.HANDLE,w.DWORD,c.c_void_p,c.c_void_p,c.c_void_p]
with (root/'hung.dmp').open('wb') as out:
    if not dbg.MiniDumpWriteDump(process,pid,msvcrt.get_osfhandle(out.fileno()),0x1020,None,None,None):
        raise c.WinError(c.get_last_error())
k.CloseHandle(process)
print(json.dumps({'instruction':report['instruction'],'stack':report['stack_candidates'][:12]}))
