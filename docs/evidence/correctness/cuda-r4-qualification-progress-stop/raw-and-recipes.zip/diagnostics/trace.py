from pathlib import Path
root=Path(__file__).parent
source=Path('C:/public/project-hyle/hyle/bench/compute_route_cuda/route_p1_bench.cc').read_text(encoding='utf-8')
source=source.replace('void measure(std::size_t rows, bool peer_first, bool allocation_first,', 'void measure(std::size_t rows, bool peer_first, bool allocation_first,')
source=source.replace('  DataSet data(rows);', '  std::fprintf(stderr,"TRACE DataSet begin\\n");\n  DataSet data(rows);\n  std::fprintf(stderr,"TRACE DataSet end\\n");')
source=source.replace('  const auto cold_end =', '  std::fprintf(stderr,"TRACE Harness end\\n");\n  const auto cold_end =')
source=source.replace('    context = take(', '    std::fprintf(stderr,"TRACE context begin\\n");\n    context = take(')
source=source.replace('    quantized =', '    std::fprintf(stderr,"TRACE pack begin\\n");\n    quantized =')
source=source.replace('    down.create(', '    std::fprintf(stderr,"TRACE pack end, down allocation begin\\n");\n    down.create(')
source=source.replace('    down.write(', '    std::fprintf(stderr,"TRACE down write begin\\n");\n    down.write(')
source=source.replace('    for (std::size_t slot = 0; slot < kSlots; ++slot) {', '    std::fprintf(stderr,"TRACE inputs begin\\n");\n    for (std::size_t slot = 0; slot < kSlots; ++slot) {')
(root/'trace.cc').write_text(source,encoding='utf-8',newline='\n')
build=(root/'build-hyle.ps1').read_text(encoding='utf-8').replace(' hyle.cc ', ' trace.cc ').replace('/OUT:hyle.exe', '/OUT:trace.exe').replace('build-hyle.log','build-trace.log').replace('/DHYLE_STATIC ', '/DHYLE_STATIC /DHYLE_CUDA_GRAPH_BENCH=0 /Zc:preprocessor /I C:/public/project-hyle/hyle/bench/compute_route_cuda /I C:/public/project-hyle/hyle/third_party/nanobench ').replace('C:/hv4d1v1/bin/mimalloc_static.lib', 'C:/hv4d1v1/bin/mimalloc_static.lib C:/hv4d1v1/bin/nanobench.lib')
(root/'build-trace.ps1').write_text(build,encoding='utf-8',newline='\n')
