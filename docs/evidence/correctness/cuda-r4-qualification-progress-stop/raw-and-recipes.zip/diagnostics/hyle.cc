#include <cstdio>
#include <vector>
#include <windows.h>
#include "hyle/compute/cuda.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/providers/marlin.h"

int main(int argc, char **) {
  if (argc > 1 && !SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL)) return 10;
  namespace c = hyle::compute;
  std::fprintf(stderr, "begin create_context\n");
  auto context = c::cuda::create_context();
  if (!context) return 1;
  std::fprintf(stderr, "end create_context; begin resource\n");
  auto resource = c::cuda::MemoryResource::create(*context, c::cuda::MemoryKind::kDevice);
  if (!resource) return 2;
  std::fprintf(stderr, "end resource; begin host vectors\n");
  std::vector<std::int8_t> values(22016ULL * 4096, 1);
  std::vector<float> scales(22016ULL * 32, 1.0F/256);
  std::fprintf(stderr, "end vectors; begin pack\n");
  auto weights = c::cuda::QuantizedWeights::pack(*context, resource->ref(), 22016, 4096, values, scales);
  if (!weights) return 3;
  std::fprintf(stderr, "end pack; begin teardown\n");
}
