#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cuda_runtime_api.h>
#include <cublasLt.h>
#include <cstdio>
#include <vector>

#define STEP(expr) do { std::fprintf(stderr, "begin %s\n", #expr); \
  int result = static_cast<int>(expr); \
  std::fprintf(stderr, "end %s = %d\n", #expr, result); \
  if (result != 0) return result; } while (0)

int main() {
  SetErrorMode(0x8003);
  cudaDeviceProp props{};
  STEP(cudaGetDeviceProperties(&props, 0));
  constexpr size_t bytes = 46'497'792;
  void *buffer = nullptr;
  STEP(cudaMalloc(&buffer, bytes));
  std::vector<unsigned char> host(bytes, 7);
  STEP(cudaMemcpy(buffer, host.data(), bytes, cudaMemcpyHostToDevice));
  cudaStream_t stream = nullptr;
  cudaEvent_t event = nullptr;
  STEP(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking));
  STEP(cudaEventCreateWithFlags(&event, cudaEventDisableTiming));
  STEP(cudaMemsetAsync(buffer, 0, bytes, stream));
  STEP(cudaEventRecord(event, stream));
  STEP(cudaEventSynchronize(event));
  cublasLtHandle_t handle = nullptr;
  STEP(cublasLtCreate(&handle));
  cublasLtMatmulDesc_t operation = nullptr;
  STEP(cublasLtMatmulDescCreate(&operation, CUBLAS_COMPUTE_32F, CUDA_R_32F));
  cublasLtMatrixLayout_t a = nullptr, b = nullptr, c = nullptr;
  STEP(cublasLtMatrixLayoutCreate(&a, CUDA_R_16F, 1, 11008, 11008));
  STEP(cublasLtMatrixLayoutCreate(&b, CUDA_R_16F, 11008, 4096, 4096));
  STEP(cublasLtMatrixLayoutCreate(&c, CUDA_R_16F, 1, 4096, 4096));
  const auto order = CUBLASLT_ORDER_ROW;
  for (auto layout : {a, b, c}) {
    STEP(cublasLtMatrixLayoutSetAttribute(layout, CUBLASLT_MATRIX_LAYOUT_ORDER, &order, sizeof(order)));
  }
  cublasLtMatmulPreference_t pref = nullptr;
  STEP(cublasLtMatmulPreferenceCreate(&pref));
  const size_t maximum = 32 * 1024 * 1024;
  const unsigned reduction = CUBLASLT_REDUCTION_SCHEME_COMPUTE_TYPE;
  const unsigned alignment = 16;
  STEP(cublasLtMatmulPreferenceSetAttribute(pref, CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES, &maximum, sizeof(maximum)));
  STEP(cublasLtMatmulPreferenceSetAttribute(pref, CUBLASLT_MATMUL_PREF_REDUCTION_SCHEME_MASK, &reduction, sizeof(reduction)));
  for (auto attribute : {CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_A_BYTES, CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_B_BYTES, CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_C_BYTES, CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_D_BYTES}) {
    STEP(cublasLtMatmulPreferenceSetAttribute(pref, attribute, &alignment, sizeof(alignment)));
  }
  cublasLtMatmulHeuristicResult_t choice{};
  int count = 0;
  STEP(cublasLtMatmulAlgoGetHeuristic(handle, operation, a, b, c, c, pref, 1, &choice, &count));
  STEP(cublasLtMatmulPreferenceDestroy(pref));
  STEP(cublasLtMatmulDescDestroy(operation));
  for (auto layout : {a, b, c}) { STEP(cublasLtMatrixLayoutDestroy(layout)); }
  STEP(cublasLtDestroy(handle));
  STEP(cudaEventDestroy(event));
  STEP(cudaStreamDestroy(stream));
  STEP(cudaFree(buffer));
  STEP(cudaDeviceReset());
}
