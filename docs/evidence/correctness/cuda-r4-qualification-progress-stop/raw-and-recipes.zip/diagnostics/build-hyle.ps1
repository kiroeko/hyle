$ErrorActionPreference = 'Stop'
. C:/hyle-scratch/r3-cpu-20260916/msvc-env.ps1
$r4AffinityRoot = 'C:/hyle-scratch/r4-cuda-20260916/qualification/affinity-probe'
Set-Location -LiteralPath $r4AffinityRoot
$r4CudaRoot = 'C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3'
$r4Libraries = @(Get-ChildItem -LiteralPath C:/hv4d1v1/bin -Filter 'hyle_*.lib' | ForEach-Object FullName)
& cl /nologo /O2 /EHsc /std:c++latest /MD /utf-8 /DHYLE_STATIC /DHYLE_COMPUTE_CUDA=1 /DNOMINMAX /DWIN32_LEAN_AND_MEAN /I C:/public/project-hyle/hyle/include "/I$r4CudaRoot/include" hyle.cc /link "/LIBPATH:$r4CudaRoot/lib/x64" $r4Libraries cudart.lib cuda.lib cublasLt.lib bcrypt.lib advapi32.lib psapi.lib PowrProf.lib Synchronization.lib C:/hv4d1v1/bin/mimalloc_static.lib /NODEFAULTLIB:LIBCMT /OUT:hyle.exe *> build-hyle.log
if ($LASTEXITCODE -ne 0) { Get-Content build-hyle.log -Tail 25; throw 'HYLE cold diagnostic build failed' }
