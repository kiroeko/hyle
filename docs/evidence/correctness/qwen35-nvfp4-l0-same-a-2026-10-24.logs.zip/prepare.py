from pathlib import Path
import hashlib,json,re
import numpy as np
R=Path.cwd(); W=Path(__file__).resolve().parent; Q=W.parent
W.mkdir(exist_ok=True)
meta=json.loads((Q/'Q03-role-files.json').read_text()); roles={r['name']:r for r in meta['roles']}
read=[]
def raw(name):
 r=roles[name]; p=R/r['path']
 with p.open('rb') as f:f.seek(r['offset']); data=f.read(r['bytes'])
 if len(data)!=r['bytes'] or hashlib.sha256(data).hexdigest()!=r['sha256']:raise RuntimeError(name+' identity')
 read.append(dict(name=name,source=str(p),offset=r['offset'],bytes=len(data),sha256=r['sha256']))
 return data
manifest={}
for line in (Q/'inputs-Q03/weights.tsv').read_text().splitlines()[2:]:
 fields=[a or b for a,b in re.findall(r'"([^"]*)"|(\S+)',line)]
 manifest[fields[0]]=fields
ids=[int(x) for x in (Q/'inputs-Q03-P15/prompt.ids').read_text().split()]
e=manifest['model.language_model.embed_tokens.weight']; path=Path(e[-3]); offset=int(e[-2]); embeds=[]
for token in ids:
 with path.open('rb') as f:f.seek(offset+token*4096); data=f.read(4096)
 if len(data)!=4096:raise RuntimeError('embedding row')
 read.append(dict(name='embedding-row-'+str(token),source=str(path),offset=offset+token*4096,bytes=4096,sha256=hashlib.sha256(data).hexdigest()))
 embeds.append(np.frombuffer(data,dtype='<u2').astype('u4')<<16)
emb=np.asarray(embeds,dtype='u4').view('f4')
(W/'embedding15.bf16').write_bytes((emb.view('u4')>>16).astype('<u2').tobytes())
norm=np.frombuffer(raw('model.language_model.layers.0.input_layernorm.weight'),dtype='<u2').astype('u4')<<16
(W/'norm.bf16').write_bytes((norm>>16).astype('<u2').tobytes())
(W/'one.f32').write_bytes(np.asarray(1,dtype='<f4').tobytes())
(W/'conv.bf16').write_bytes(raw('model.language_model.layers.0.linear_attn.conv1d.weight'))
scale=np.asarray(norm.view('f4')+np.float32(1),dtype='f4')
# Deliberately fixed same-A fixture from actual source rows. F32 input/norm,
# F64 RMS reduction rounded once to F32; not a claim of exact backend RMS bits.
mean=np.asarray(np.mean(emb.astype('f8')**2,axis=1),dtype='f4')
inverse=np.asarray(1/np.sqrt(mean+np.float32(1e-6)),dtype='f4')
normalized=np.asarray(np.asarray(emb*inverse[:,None],dtype='f4')*scale,dtype='f4')
bits=normalized.view('u4'); a=((bits+0x7fff+((bits>>16)&1))>>16).astype('<u2')
(W/'a15.bf16').write_bytes(a.tobytes());(W/'a1.bf16').write_bytes(a[-1:].tobytes())
for short in ('in_proj_a','in_proj_b','in_proj_qkv','in_proj_z'):
 base='model.language_model.layers.0.linear_attn.'+short
 for source,dest in [('weight','w'),('weight_scale','sf'),('weight_scale_2','wg'),('input_scale','ig')]:
  (W/(short+'.'+dest)).write_bytes(raw(base+'.'+source))
(W/'source.json').write_text(json.dumps(dict(artifact={k:meta[k] for k in ('id','repository','revision')},prompt_ids=ids,source_ranges=read,
 input_fixture='Actual source embedding15 rows + source norm+1, independent F32 pointwise/F64 RMS reduction; identical stored BF16 A sent to both backends, not exact engine L0 norm trace.',
 local_activation_sha256=hashlib.sha256(a.tobytes()).hexdigest(),downloads=0),indent=2)+'\n')
print('Prepared',len(read),'bounded local source reads; no downloads')
