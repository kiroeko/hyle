from pathlib import Path
import hashlib,json,zipfile
import numpy as np
R=Path.cwd();W=Path(__file__).resolve().parent;D=R/'docs/evidence/correctness'
def read(name,dtype='<u2'):
 a=np.fromfile(W/name,dtype=dtype)
 return (a.astype('u4')<<16).view('f4') if dtype=='<u2' else a
def compare(left,right,dtype='<u2'):
 a=read(left,dtype);b=read(right,dtype);delta=a.astype('f8')-b
 return dict(elements=int(a.size),different=int(np.count_nonzero(a!=b)),finite=bool(np.isfinite(a).all() and np.isfinite(b).all()),
  max_absolute=float(np.abs(delta).max()),rms=float(np.sqrt(np.mean(delta*delta))))
def identity(p):return dict(path=str(p.relative_to(R)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
same=[];norm=[]
for rows in (1,15):
 norm.append(dict(boundary='delta RMS F32 -> BF16',rows=rows,**compare(f'cpu-rms{rows}.bf16',f'cuda-rms{rows}.bf16')))
 for name in ('in_proj_a','in_proj_b','in_proj_qkv','in_proj_z'):
  same.append(dict(name=name,rows=rows,reference='all outputs' if name in ('in_proj_a','in_proj_b') else 'existing independent candidate-output interval',
   **compare(f'cpu-{name}-M{rows}.bf16',f'cuda-{name}-M{rows}.bf16')))
  norm.append(dict(boundary=name,rows=rows,reference='all outputs' if name in ('in_proj_a','in_proj_b') else 'existing independent candidate-output interval',
   **compare(f'cpu-ownnorm-{name}-M{rows}.bf16',f'cuda-ownnorm-{name}-M{rows}.bf16')))
conv=[dict(boundary=suffix,**compare('cpu-'+suffix,'cuda-'+suffix,dtype))
 for suffix,dtype in [('conv.f32','<f4'),('conv.bf16','<u2'),('silu.bf16','<u2')]]
samples=np.zeros((18,6144),dtype='f8');samples[3:]=read('cpu-ownnorm-in_proj_qkv-M15.bf16').reshape(15,6144)
weights=read('conv.bf16').reshape(6144,4).astype('f8')
terms=np.stack([samples[i:i+15]*weights[:,i] for i in range(4)],axis=0)
center=np.sum(terms,axis=0);absolute=np.sum(abs(terms),axis=0)
gamma=(4*2**-24)/(1-4*2**-24);bound=gamma*absolute+np.finfo('f4').tiny
conv_oracle=[]
for backend in ('cpu','cuda'):
 actual=read(backend+'-conv.f32','<f4').reshape(15,6144).astype('f8');distance=abs(actual-center)
 if np.any(distance>bound):raise RuntimeError(backend+' causal conv outside independent4-product F64 interval')
 conv_oracle.append(dict(backend=backend,elements=int(actual.size),all_within_independent_F64_4product_F32_interval=True,
  max_absolute_from_F64=float(distance.max()),max_F32_interval=float(bound.max())))
source=json.loads((W/'source.json').read_text())
report=dict(scope='Bounded Q03 same-A original L0 norm/projection/causal-conv investigation, not complete model numerical certification',
 identity=source['artifact'],prompt_rows=15,prompt_ids=source['prompt_ids'],tests=2,failures=0,downloads=0,
 observations=dict(same_stored_BF16_A=same,actual_public_RMS_then_own_projections=norm,actual_public_causal_conv_then_SiLU=conv,independent_conv_oracle=conv_oracle),
 conclusions=['CPU/CUDA same-A L0 a/b/qkv/z results bitwise equal for M1 and M15.',
  'Actual public original delta RMS F32 -> BF16 agrees bitwise for all30720 P15 activation values; own-normalized original projections also agree.',
  'Actual public F32 CausalConv1d, BF16 cast and BF16 SiLU each agree bitwise for all92160 values.',
  'All N16 a/b original-weight outputs pass existing independent ModelOpt QDQ/BF16/F64 interval; large qkv/z use candidate intervals.',
  'No first divergence or root cause established after this boundary; no inference that whole-model difference is harmless or solely quantization amplification.'],
 boundaries=['The fixed same-A fixture independently derives actual source embedding rows and delta norm; exact backend RMS was checked separately.',
  'The causal-conv small graph uses identical actual qkv payload and zero3-row initial history; it is not an entire linear-attention layer.',
  'GDN, out_proj, FFN, later layers and final logits are outside this certificate.',
  'M1 slices last normalized P15 row; it is a matmul geometry check, not a complete cached one-token model continuation.',
  'No complete model, task quality, MTP acceptance-rate or performance claim.'],
 tools=dict(compile=identity(W/'compile-command.json'),link=identity(W/'link-plan.json'),image=identity(W/'checks.exe')))
for name,value in [('cross-backend.json',same),('norm-cross-backend.json',norm),('conv-cross-backend.json',conv),('result.json',report)]:
 (W/name).write_text(json.dumps(value,indent=2)+'\n')
dest=D/'qwen35-nvfp4-l0-same-a-2026-10-24.logs.zip'
files=['check.cc','prepare.py','run.py','report.py','source.json','result.json','cross-backend.json','norm-cross-backend.json','conv-cross-backend.json',
 'compile-command.json','link-plan.json','compile-process.json','link-process.json','run-process.json','compile.log','link.log','run.log','tests.xml','image.json']
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in files:z.write(W/name,name)
 for name in ('qwen_nvfp4_original_reference.h','qwen_bfloat_original_reference.h','nvfp4_reference_fixture.h'):
  z.write(R/'tests/compute_models'/name,'references/'+name)
report['evidence_archive']=identity(dest)
(D/'qwen35-nvfp4-l0-same-a-2026-10-24.json').write_text(json.dumps(report,indent=2)+'\n')
with zipfile.ZipFile(dest) as z:
 if z.testzip():raise RuntimeError('archive integrity')
print(json.dumps(dict(archive=identity(dest),tests=2,failures=0,all_compared_values_bitwise_equal=True,conv_oracle=conv_oracle),indent=2))
