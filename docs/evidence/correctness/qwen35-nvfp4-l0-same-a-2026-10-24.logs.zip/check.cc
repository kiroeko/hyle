#include "tests/compute_models/qwen_nvfp4_original_reference.h"
#include "hyle/graph/cpu.h"
#include "hyle/graph/cuda.h"
#include "hyle/compute/backends/cuda.h"
#include <filesystem>
#include <fstream>
#include <iostream>
namespace f=nvfp4_reference_test;
namespace ref=qwen_nvfp4_original_reference;
namespace c=hyle::compute; namespace g=hyle::graph; namespace m=hyle::mem;
const std::filesystem::path folder=std::filesystem::current_path()/".scratch/mtp-full-quant-20261024/q03-local";
std::vector<std::byte> load(const std::string &name) {
 std::ifstream in(folder/name,std::ios::binary|std::ios::ate);if(!in)throw std::runtime_error("missing "+name);
 const auto size=in.tellg();std::vector<std::byte> out(static_cast<std::size_t>(size));in.seekg(0);
 in.read(reinterpret_cast<char*>(out.data()),size);if(!in)throw std::runtime_error("short "+name);return out;
}
template<class Compile> void norm(std::string backend,m::MemoryResourceRef resource,
 std::span<const g::QueueBinding> queues,Compile compile,c::StorageOwner owner={}) {
 auto b=f::take(g::GraphBuilder::create(),"norm builder");
 const auto ad=f::dense(c::DataType::kBFloat16,{15,2048}),wd=f::dense(c::DataType::kBFloat16,{2048}),one=f::dense(c::DataType::kFloat32,{});
 const auto a=f::take(b.input(ad),"norm input"),w=f::take(b.constant(wd),"norm weight"),k=f::take(b.constant(one),"one");
 const auto wf=f::take(b.add(c::Cast{c::DataType::kFloat32},w),"norm cast");
 const auto scale=f::take(b.add(c::Binary{c::BinaryKind::kAdd},wf,k),"norm scale");
 const auto af=f::take(b.add(c::Cast{c::DataType::kFloat32},a),"input cast");
 const auto rms=f::take(b.add(c::RmsNorm{.epsilon=1.e-6F},af,scale),"RMS");
 const auto out=f::take(b.add(c::Cast{c::DataType::kBFloat16},rms),"BF16 norm");
 f::check(b.publish(out),"publish norm");const auto graph=f::take(std::move(b).finish(),"norm graph");
 const std::array payload{load("norm.bf16"),load("one.f32")};const std::array ports{w,k};const std::array desc{wd,one};
 std::array<c::ReadLease,2> leases;std::array<g::ConstantBinding,2> constants;
 for(std::size_t i=0;i<2;++i) {
  auto buffer=f::take(m::Buffer::create(resource,payload[i].size(),256),"norm constant buffer");f::check(buffer.view().write(payload[i]),"norm write");
  leases[i]=owner?f::take(owner.adopt_buffer(std::move(buffer)),"adopt"):f::take(c::ReadLease::adopt(std::move(buffer)),"adopt");
  constants[i]={ports[i],f::take(leases[i].tensor(desc[i]),"norm const"),g::ConstantPolicy::kMaterialize,owner,owner?leases[i]:c::ReadLease{}};
 }
 auto compiled=f::take(compile(graph,g::CompileOptions{.constants=constants}),"compile norm");
 auto invocation=f::take(compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"norm invocation");
 const auto embedded=load("embedding15.bf16");auto input=f::take(m::Buffer::create(resource,embedded.size(),256),"norm input buffer");
 f::check(input.view().write(embedded),"norm input write");f::check(invocation.bind(a,f::take(c::ConstTensorView::create(ad,input.view()),"norm tensor")),"norm bind");
 c::LeasePool pool;
 if(f::take(compiled.executable.output_ownership(),"norm ownership")==g::OutputOwnership::kCaller) {
  pool=f::take(c::LeasePool::create(resource,embedded.size(),{.max_blocks=1}),"norm output pool");
  f::check(invocation.bind(out,ad,f::take(pool.allocate(embedded.size()),"norm output")),"norm output bind");
 }
 f::check(invocation.prepare_replay(queues),"norm prepare");auto done=f::take(invocation.submit(queues),"norm submit");f::check(done.wait(),"norm complete");
 const auto output=f::take(invocation.result(out),"norm result");const auto tensor=f::take(output.tensor(),"norm result tensor");
 std::vector<std::byte> result(embedded.size());f::check(tensor.storage().read(result),"norm read");
 std::ofstream f15(folder/(backend+"-rms15.bf16"),std::ios::binary);f15.write(reinterpret_cast<const char*>(result.data()),static_cast<std::streamsize>(result.size()));
 std::ofstream f1(folder/(backend+"-rms1.bf16"),std::ios::binary);f1.write(reinterpret_cast<const char*>(result.data()+result.size()-4096),4096);
}
template<class Compile> void projections(std::string backend,m::MemoryResourceRef resource,
 std::span<const g::QueueBinding> queues,Compile compile,c::StorageOwner owner={},std::string a_prefix="a") {
 for(const auto rows:{1LL,15LL})for(const auto name:{"in_proj_a","in_proj_b","in_proj_qkv","in_proj_z"}) {
  SCOPED_TRACE(backend+" "+name+" M"+std::to_string(rows));
  const auto n=std::string_view(name)=="in_proj_qkv"?6144LL:std::string_view(name)=="in_proj_z"?2048LL:16LL;
  const std::array payload{load(a_prefix+std::to_string(rows)+".bf16"),load(std::string(name)+".w"),
    load(std::string(name)+".sf"),load(std::string(name)+".wg"),load(std::string(name)+".ig")};
  const std::array desc{f::dense(c::DataType::kBFloat16,{rows,2048}),f::dense(c::DataType::kUInt8,{n,1024}),
    f::dense(c::DataType::kFloat8E4M3FN,{n,128}),f::dense(c::DataType::kFloat32,{}),f::dense(c::DataType::kFloat32,{})};
  auto builder=f::take(g::GraphBuilder::create(),"builder");std::array<g::ValueId,5> ports;
  for(std::size_t i=0;i<5;++i)ports[i]=f::take(i?builder.constant(desc[i]):builder.input(desc[i]),"port");
  const auto output=f::take(builder.add(c::model_ops::nvfp4_linear(),ports[0],ports[1],ports[2],ports[3],ports[4]),"Nvfp4Linear");
  f::check(builder.publish(output),"publish");const auto graph=f::take(std::move(builder).finish(),"finish");
  std::array<c::ReadLease,4> leases;std::array<g::ConstantBinding,4> constants;
  for(std::size_t i=0;i<4;++i) {
   auto b=f::take(m::Buffer::create(resource,payload[i+1].size(),256),"constant allocation");
   f::check(b.view().write(payload[i+1]),"constant write");
   leases[i]=owner?f::take(owner.adopt_buffer(std::move(b)),"adopt"):f::take(c::ReadLease::adopt(std::move(b)),"adopt");
   constants[i]={ports[i+1],f::take(leases[i].tensor(desc[i+1]),"constant tensor"),g::ConstantPolicy::kMaterialize,owner,owner?leases[i]:c::ReadLease{}};
  }
  auto compiled=f::take(compile(graph,g::CompileOptions{.constants=constants}),"compile");
  auto invocation=f::take(compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"invocation");
  auto a=f::take(m::Buffer::create(resource,payload[0].size(),256),"activation");f::check(a.view().write(payload[0]),"input write");
  f::check(invocation.bind(ports[0],f::take(c::ConstTensorView::create(desc[0],a.view()),"input tensor")),"bind");
  c::LeasePool pool;
  if(f::take(compiled.executable.output_ownership(),"ownership")==g::OutputOwnership::kCaller) {
   const auto od=f::dense(c::DataType::kBFloat16,{rows,n});const auto bytes=f::take(od.required_bytes(),"output bytes");
   pool=f::take(c::LeasePool::create(resource,bytes,{.max_blocks=1}),"output pool");
   f::check(invocation.bind(output,od,f::take(pool.allocate(bytes),"output allocation")),"output bind");
  }
  f::check(invocation.prepare_replay(queues),"prepare");auto done=f::take(invocation.submit(queues),"submit");f::check(done.wait(),"complete");
  const auto out=f::take(invocation.result(output),"result");const auto tensor=f::take(out.tensor(),"result tensor");
  std::vector<std::uint16_t> result(static_cast<std::size_t>(rows*n));f::check(tensor.storage().read(std::as_writable_bytes(std::span(result))),"read");
  std::vector<std::uint16_t> input(payload[0].size()/2);std::memcpy(input.data(),payload[0].data(),payload[0].size());
  const bool passed=ref::expect_projection(result,input,payload[1],payload[2],payload[3],payload[4],static_cast<std::size_t>(n),2048,backend+" "+name,n==16);
  std::ofstream bin(folder/(backend+"-"+name+"-M"+std::to_string(rows)+".bf16"),std::ios::binary);
  bin.write(reinterpret_cast<const char*>(result.data()),static_cast<std::streamsize>(result.size()*2));
  std::cout<<backend<<" "<<name<<" M"<<rows<<" N"<<n<<" F64-interval="<<passed<<" full="<<(n==16)<<std::endl;
 }
}
template<class Compile> void conv(std::string backend,m::MemoryResourceRef resource,
 std::span<const g::QueueBinding> queues,Compile compile) {
 auto b=f::take(g::GraphBuilder::create(),"conv builder");
 const std::array desc{f::dense(c::DataType::kFloat32,{1,18,6144}),f::dense(c::DataType::kFloat32,{6144,4})};
 const std::array ports{f::take(b.input(desc[0]),"samples"),f::take(b.input(desc[1]),"conv weights")};
 const auto convolution=f::take(b.add(c::model_ops::causal_conv1d(),ports[0],ports[1]),"conv");
 const auto narrowed=f::take(b.add(c::Cast{c::DataType::kBFloat16},convolution),"conv BF16");
 const auto activated=f::take(b.add(c::Unary{c::UnaryKind::kSilu},narrowed),"Silu BF16");
 const std::array outputs{convolution,narrowed,activated};
 for(const auto output:outputs)f::check(b.publish(output),"conv publish");
 const auto graph=f::take(std::move(b).finish(),"conv graph");auto compiled=f::take(compile(graph,g::CompileOptions{}),"compile conv");
 auto invocation=f::take(compiled.executable.create_invocation({.resources=g::ResourceOptions{}}),"conv invocation");
 const auto projected=load(backend+"-ownnorm-in_proj_qkv-M15.bf16"),weight=load("conv.bf16");
 std::array<std::vector<float>,2> data;data[0].resize(18*6144);data[1].resize(6144*4);
 for(std::size_t i=0;i<projected.size()/2;++i)data[0][3*6144+i]=ref::bf::widen(ref::bf::read(projected,i));
 for(std::size_t i=0;i<weight.size()/2;++i)data[1][i]=ref::bf::widen(ref::bf::read(weight,i));
 std::array<m::Buffer,2> buffers;
 for(std::size_t i=0;i<2;++i) {
  const auto raw=std::as_bytes(std::span(data[i]));buffers[i]=f::take(m::Buffer::create(resource,raw.size(),256),"conv data");
  f::check(buffers[i].view().write(raw),"conv write");f::check(invocation.bind(ports[i],f::take(c::ConstTensorView::create(desc[i],buffers[i].view()),"conv view")),"conv bind");
 }
 c::LeasePool pool;
 if(f::take(compiled.executable.output_ownership(),"conv ownership")==g::OutputOwnership::kCaller) {
  pool=f::take(c::LeasePool::create(resource,15*6144*8,{.max_blocks=3}),"conv output pool");
  for(std::size_t i=0;i<3;++i) {
   const auto od=f::dense(i?c::DataType::kBFloat16:c::DataType::kFloat32,{1,15,6144});
   f::check(invocation.bind(outputs[i],od,f::take(pool.allocate(f::take(od.required_bytes(),"conv out bytes")),"conv out")),"conv out bind");
  }
 }
 f::check(invocation.prepare_replay(queues),"conv prepare");auto done=f::take(invocation.submit(queues),"conv submit");f::check(done.wait(),"conv complete");
 for(std::size_t i=0;i<3;++i) {
  const auto result=f::take(invocation.result(outputs[i]),"conv result");const auto tensor=f::take(result.tensor(),"conv tensor");
  std::vector<std::byte> bytes(15*6144*(i?2:4));f::check(tensor.storage().read(bytes),"conv read");
  const std::array labels{"conv.f32","conv.bf16","silu.bf16"};
  std::ofstream file(folder/(backend+"-"+labels[i]),std::ios::binary);file.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
 }
}
TEST(Q03SameAOriginalL0,Cpu) {
 const auto context=f::take(g::cpu::create_context(),"CPU");auto queue=f::take(context.create_queue(),"CPU queue");
 const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
 norm("cpu",m::system_resource(),queues,[&](const g::Graph &graph,g::CompileOptions opts){return g::cpu::compile(graph,context,opts);});
 projections("cpu",m::system_resource(),queues,[&](const g::Graph &graph,g::CompileOptions opts){return g::cpu::compile(graph,context,opts);});
 projections("cpu-ownnorm",m::system_resource(),queues,[&](const g::Graph &graph,g::CompileOptions opts){return g::cpu::compile(graph,context,opts);},{},"cpu-rms");
 conv("cpu",m::system_resource(),queues,[&](const g::Graph &graph,g::CompileOptions opts){return g::cpu::compile(graph,context,opts);});
}
TEST(Q03SameAOriginalL0,Cuda) {
 const auto context=f::take(g::cuda::create_context(),"CUDA");auto memory=f::take(c::cuda::MemoryResource::create(context,c::cuda::MemoryKind::kDevice),"device");
 const auto owner=f::take(c::StorageOwner::adopt(context,std::move(memory)),"owner");auto queue=f::take(context.create_queue(),"CUDA queue");
 const std::array queues{g::QueueBinding{g::ExecutionLaneId{0},&queue}};
 norm("cuda",owner.ref(),queues,[&](const g::Graph &graph,g::CompileOptions opts){return g::cuda::compile(graph,context,owner,opts);},owner);
 projections("cuda",owner.ref(),queues,[&](const g::Graph &graph,g::CompileOptions opts){return g::cuda::compile(graph,context,owner,opts);},owner);
 projections("cuda-ownnorm",owner.ref(),queues,[&](const g::Graph &graph,g::CompileOptions opts){return g::cuda::compile(graph,context,owner,opts);},owner,"cuda-rms");
 conv("cuda",owner.ref(),queues,[&](const g::Graph &graph,g::CompileOptions opts){return g::cuda::compile(graph,context,owner,opts);});
}
