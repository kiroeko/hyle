from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
R=Path.cwd();W=Path(__file__).resolve().parent;Q=W.parent;E=Q/'engine-check'
sys.path.insert(0,str(R/'scripts'));from hyle_environment import discover_environment
def save(name,x):(W/name).write_text(json.dumps(x,indent=2)+'\n')
def identity(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
cmd=json.loads((E/'model-cuda/identity.json').read_text())['command']
compile=[];skip=False
for x in cmd:
 if skip:skip=False;continue
 if x=='/sourceDependencies':skip=True;continue
 if x.endswith('main.cc') or x.startswith(('/Fo','/Fd')):continue
 compile.append(x)
compile+=['/DHYLE_COMPUTE_CPU=1',str(W/'check.cc'),'/Fo'+str(W/'check.obj'),'/Fd'+str(W/'check.pdb')]
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cmd[0],'CMAKE_CXX_COMPILER':cmd[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
old=json.loads((E/'link-plan.json').read_text())['command'];link=[]
for x in old:
 if x.endswith(('entry.obj','qwen.obj')) or x.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:')):continue
 link.append(x)
gtest=json.loads((R/'.scratch/dspark-block5-tail-20261024/link-command.json').read_text())
link += [x for x in gtest if Path(x).name.lower() in ('gtest.lib','gtest_main.lib')]
link += [str(W/'check.obj'),'/OUT:'+str(W/'checks.exe')]
ready=json.loads((E/'ready.json').read_text());dll=ready['native_runtime'];p=Path(dll['path'])
if identity(p)!=dll:raise RuntimeError('CPU DLL identity')
target=W/p.name
if target.exists():
 if identity(target)['sha256']!=dll['sha256']:raise RuntimeError('DLL target identity')
else:os.link(p,target)
save('link-plan.json',dict(command=link,retained=str(E/'link-plan.json'),DLL=dll))
save('compile-command.json',compile)
for name,command,timeout in [('compile',compile,180),('link',link,120),('run',[str(W/'checks.exe'),'--gtest_output=xml:'+str(W/'tests.xml')],180)]:
 print('START',name,flush=True);start=time.time()
 runenv=dict(env)
 if name=='run':runenv['PATH']=str(W)+os.pathsep+ready['PATH']
 p=subprocess.run(command,cwd=R,env=runenv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 (W/(name+'.log')).write_bytes(p.stdout);save(name+'-process.json',dict(exit=p.returncode,elapsed=time.time()-start))
 print('END',name,p.returncode,p.stdout.decode('utf8','replace')[-10000:],flush=True)
 if p.returncode:sys.exit(p.returncode)
save('image.json',identity(W/'checks.exe'))
