"""Compact explicit evidence only. No native process/build/download."""
from pathlib import Path
import datetime,hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
OUT=R/'docs/evidence/correctness/inference-cpu-ahead-2026-10-27'
def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
def pin(path):return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes()))
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

files=['build.py','run.py','publish.py','run-script-attempt1.py','script-setup-failure.json',
 'plan.json','source-freeze.json','retained-inputs.json','link-inputs.json','runtime.json','ready.json',
 'compile-plan.json','link-plan.json','run-plan.json','run-failure.json',
 'source/engine/models/qwen35/main.cc','source/tests/tools/qwen_cpu_ahead_test.cc','source/tests/CMakeLists.txt',
 'attempt2/source/tests/tools/qwen_cpu_ahead_test.cc','attempt2/plan.json','attempt2/source-freeze.json',
 'attempt2/link-inputs.json','attempt2/runtime.json','attempt2/ready.json','attempt2/summary.json',
 'attempt2/compile-plan.json','attempt2/link-plan.json','attempt2/run-plan.json']
for attempt in ('','attempt2/'):
    for stage in ('compile','link','run1'):
        files += [attempt+stage+'/'+name for name in ('command.json','process.json','stdout.log','stderr.log')]
    files += [attempt+'compile/'+name for name in ('dependencies.json','actual-dependencies.json')]
assert len(files)==len(set(files))
members=[]
archive=OUT.with_suffix('.zip');report=OUT.with_suffix('.json')
assert not archive.exists() and not report.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for relative in files:
        path=W/relative;data=path.read_bytes();z.writestr(relative,data)
        members.append(dict(name=relative,bytes=len(data),sha256=sha(data)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and z.namelist()==files
    for item in members:assert sha(z.read(item['name']))==item['sha256']
assert archive.stat().st_size<2_000_000
final=read(W/'attempt2/summary.json');ready=read(W/'attempt2/ready.json')
sources={name:pin(R/name) for name in ('engine/models/qwen35/main.cc','tests/tools/qwen_cpu_ahead_test.cc','tests/CMakeLists.txt')}
assert sources['engine/models/qwen35/main.cc']['sha256']==ready['main']['sha256']
assert sources['tests/tools/qwen_cpu_ahead_test.cc']['sha256']==ready['source']['sha256']
save(report,dict(schema=1,status='BOUNDED_FUNCTIONAL_PASS',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 changes=['Cold-budgeted per-Model weak identities and integer positions/page topology for complete ordinary B>1 decode batches.',
 'Original AfterSubmit control hook runs first. Next real prepare consumes only after owner/control-block/epoch/length/order/role/completion/sampler/T1 match.',
 'Layout version creation, budget checks, candidate/state/tail/native binding and publication remain in the next normal prepare. Singleton/MTP/ineligible batches skip ahead.',
 'Reordering, cancelled members, changed batch and predecessor failure discard optional metadata without retaining Session heads.'],
 sources=sources,final_ready=pin(W/'attempt2/ready.json'),final_image=ready['image'],result=final['facts'],
 counts=dict(distinct_CXX_TUs=1,compile_attempts=2,successful_compiles=2,links=2,native_processes=2,
 failed_fixture_processes=1,successful_consumer_processes=1,successful_graph_calls=10,successful_outputs=18,
 compared_nonclock_records=9,SDK_builds=0,NVCC=0,weights_builds=0,report_builds=0,downloads=0),
 failures=[dict(kind='script_setup',description='One unmatched Python closing parenthesis; parse failed before any native process. Original script retained.'),
 dict(kind='test_fixture',process=read(W/'run1/process.json'),description='New consumer omitted progress.begin_turn. Actual input validation rejected before any Graph execution. Only fixture initialization changed for attempt2; product source and all 222 retained inputs unchanged.')],
 reused=dict(reference='docs/evidence/correctness/inference-bounded-prefill-2026-10-27.json',baseline_ready=pin(R/'.scratch/inference-bounded-prefill-20261027/ready.json'),
 retained_inputs=222,removed='Previous formal Model object and engine entry object; one combined test+Model object supplies both.',
 ABI='Exact prior CUDA-only macro closure, including retained CUDA weights/report/SDK/native. No changed SDK or native math compiled in this batch.'),
 boundaries=['One cached untrained tiny GA fixture on RTX4070 CUDA; valid for resource/behavior regression, not task quality.',
 'A control clears the optional cache after each call; candidate exercises an actual next-prepare hit, member-order rejection and paused cancellation/subset rejection.',
 'Only integer topology CPU loops are moved. The 2us accumulated fixture preparation clock is not an end-to-end speedup or a claim that layout creation/whole cold_batch was hidden.',
 'No successor GPU submit, device overlap benchmark, full model performance, MTP, non-CUDA backend or concurrent service claim.',
 'No CMake reconfiguration/CTest run: direct cached strict /O2 /W4 /WX compile/link and one corrected native consumer.'],
 archive=pin(archive),members=members))
print(json.dumps(dict(report=pin(report),archive=pin(archive),members=len(members)),indent=2))
