"""One combined actual Model/test TU, one exact CUDA link; no SDK build."""
from pathlib import Path
import importlib.util,json,os,sys,traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
R=W.parents[1]
B=R/'.scratch/inference-bounded-prefill-20261027'
spec=importlib.util.spec_from_file_location('bounded_recipe',B/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m=old.b,old.m
MAIN=R/'engine/models/qwen35/main.cc'
SOURCE=R/'tests/tools/qwen_cpu_ahead_test.cc'
ENTRY=R/'.scratch/inference-current-closure-20261026/engine/entry/unit.obj'

def main():
    global W
    if len(sys.argv)!=2 or sys.argv[1] not in ('build','build2'):
        print('Prepared only. Explicit build compiles/links one combined TU, never runs inference.');return
    if sys.argv[1]=='build2':W=W/'attempt2'
    assert not (W/'plan.json').exists()
    baseline=b.read(B/'ready.json');b.exact(baseline['image'])
    assert baseline['image']['sha256']=='2989cd63aefe1c426eeb25593c116d8bd2502295d517ea387d5d87435316cca4'
    original=b.read(baseline['inputs']['path'])
    removed={b.key(ENTRY),b.key(baseline['object']['path'])}
    retained=[p for p in original if b.key(p['path']) not in removed]
    assert len(original)==224 and len(retained)==222
    command=m.command(B/'compile/command.json',SOURCE,W/'compile')
    image=W/'image/cpu-ahead-test.exe';link=[];replaced=skipped=0
    for arg in b.read(B/'link-plan.json')['command']:
        if b.key(arg)==b.key(ENTRY):skipped+=1;continue
        if b.key(arg)==b.key(baseline['object']['path']):arg=str(W/'compile/unit.obj');replaced+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        link.append(arg)
    assert replaced==skipped==1
    b.save(W/'compile-plan.json',dict(command=command,cwd=str(R),timeout_seconds=180))
    b.save(W/'link-plan.json',dict(command=link,cwd=str(R),timeout_seconds=120))
    frozen=m.c.closure([SOURCE,MAIN],[W/'compile-plan.json'])
    b.save(W/'source-freeze.json',frozen)
    b.save(W/'retained-inputs.json',retained)
    for source in (SOURCE,MAIN,R/'tests/CMakeLists.txt'):
        out=W/'source'/source.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(source.read_bytes())
    b.save(W/'plan.json',dict(baseline_ready=b.pin(B/'ready.json'),source=b.pin(SOURCE),main=b.pin(MAIN),
        source_freeze=b.pin(W/'source-freeze.json'),retained_inputs=b.pin(W/'retained-inputs.json'),
        removed=[p for p in original if b.key(p['path']) in removed],
        counts=dict(CXX_TUs=1,links=1,retained_inputs=222,SDK=0,NVCC=0,weights=0,report=0,downloads=0),
        scope='Cold-budgeted integer topology only; no schema/layout creation ahead, no payload/native binding or successor submission'))
    helper=b.helper();env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
    compiled=helper.execute(command,env,W/'compile',timeout=180)
    deps=old.actual_deps(W/'compile',frozen)
    for p in frozen:b.exact(p)
    for p in retained:b.exact(p)
    image.parent.mkdir(parents=True,exist_ok=True)
    linked=helper.execute(link,env,W/'link',timeout=120)
    b.save(W/'link-inputs.json',retained+[b.pin(W/'compile/unit.obj')])
    runtime=b.read(baseline['runtime']['path']);native=runtime['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    runtime['native_cpu_hardlink']=b.pin(alias);runtime['PATH']=str(image.parent)+';'+runtime['PATH']
    b.save(W/'runtime.json',runtime)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),object=b.pin(W/'compile/unit.obj'),
        source=b.pin(SOURCE),main=b.pin(MAIN),actual_dependencies=deps,compile=compiled,link=linked,
        inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json')))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)

if __name__=='__main__':
    try:main()
    except BaseException:
        b.save(W/'build-failure.json',dict(error=traceback.format_exc(),note='First failure retained; no automatic retry'))
        raise
