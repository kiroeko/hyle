"""One actual B2 CUDA functional consumer; no performance window or retry."""
from pathlib import Path
import importlib.util,json,sys,traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('ahead_build',W/'build.py')
build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
b,R=build.b,build.R

def main():
    if sys.argv[1:]!=['run']:print('Prepared only; explicit run after successful combined build.');return
    assert not (W/'run-plan.json').exists()
    ready=b.read(W/'ready.json')
    for field in ('source','main','image'):b.exact(ready[field])
    inputs=R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    manifest=inputs/'weights.tsv'
    command=[ready['image']['path'],str(inputs)]
    b.save(W/'run-plan.json',dict(command=command,image=ready['image'],source=ready['source'],main=ready['main'],
        inputs=[b.pin(manifest),b.pin(inputs/'untrained-bf16.bin')],timeout_seconds=120,
        scope='One CUDA process; same Model control/candidate ordinary B2, reorder and paused cancellation subset, 10 calls/18 outputs total; no benchmark/quality/MTP claim'))
    helper=b.helper();compiler=b.read(W/'compile-plan.json')['command'][0]
    env=helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':compiler,'CMAKE_CXX_COMPILER':compiler,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    env['PATH']=b.read(ready['runtime']['path'])['PATH'];env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    process=helper.execute(command,env,W/'run1',timeout=120)
    facts=json.loads((W/'run1/stdout.log').read_text(encoding='utf-8-sig'))
    assert facts['status']=='PASS' and facts['candidate_hits']==1 and facts['candidate_discarded']==2
    assert facts['physical_calls']==10 and facts['outputs']==18 and facts['records_compared']==9 and facts['final_versions']==0
    b.save(W/'summary.json',dict(status='ORDINARY_B2_INTEGER_AHEAD_FUNCTIONAL_PASS',ready=b.pin(W/'ready.json'),
        process=process,facts=facts,counts=dict(CXX_TUs=1,links=1,CUDA_processes=1,graph_calls=10,outputs=18,
        SDK=0,NVCC=0,weights_build=0,report_build=0,downloads=0),
        scope='Cold-budgeted integer topology only; schema/version and all native/state admission remain in the next successful ordinary prepare; no measured speedup/full-model/MTP/platform-matrix claim')))
    print('PASS',json.dumps(b.pin(W/'summary.json')),flush=True)

if __name__=='__main__':
    try:main()
    except BaseException:
        b.save(W/'run-failure.json',dict(error=traceback.format_exc(),note='First failure preserved; no automatic retry'))
        raise
