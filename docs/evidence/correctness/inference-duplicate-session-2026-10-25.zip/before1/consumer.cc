#include "source/engine/models/qwen35/main.cc"
#include "source/tests/tools/qwen_request_ledger_case.h"
int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("duplicate-session PREPARED_INPUTS");return qwen_request_ledger_case::run(argv[1]);}catch(const std::exception &e){std::cerr<<"duplicate_session_case_failure="<<e.what()<<"\n";return 1;}}
