"""Offline archive of the completed finite CPU pair; never builds/runs models."""
from pathlib import Path
import hashlib
import json
import re
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
DEST = WORK / "archive-private"
NAME = "inference-duplicate-session-2026-10-25"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def actual_map(phase):
    attempt = WORK / phase
    result = {}
    for item in read(attempt / "compile/repository-inputs.json"):
        path = Path(item["path"])
        raw = path.read_bytes()
        assert digest(raw) == {k: item[k] for k in ("bytes", "sha256")}, path
        if path.is_relative_to(attempt / "source"):
            key = "source/" + path.relative_to(attempt / "source").as_posix()
        elif path == attempt / "consumer.cc":
            key = "consumer.cc"
        else:
            key = "shared/" + path.relative_to(ROOT).as_posix()
        assert key not in result
        result[key] = {k: item[k] for k in ("bytes", "sha256")}
    return result


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    before, current = read(WORK / "before1/summary.json"), read(WORK / "current1/summary.json")
    assert before["status"] == "EXPECTED_OLD_REJECTION_SIDE_EFFECT_REPRODUCED"
    assert before["process"]["exit"] == 1 and before["duplicate_facts"] == [1, 0, 0, 1, 2, 1, 0]
    assert current["status"] == "FINITE_CPU_LEDGER_AND_DUPLICATE_REJECTION_PASS"
    assert current["process"]["exit"] == 0 and current["duplicate_facts"] == [1, 1, 0, 0, 2, 2, 1]
    result = current["results"][0]
    assert result["duplicate_Session_before_prefix_eviction"] and result["same_request_retry"]
    assert result["final_versions"] == 0 and result["A_ids"] == result["B_ids"] == [2, 8]
    old, new = actual_map("before1"), actual_map("current1")
    assert old.keys() == new.keys()
    differences = [p for p in old if old[p] != new[p]]
    assert differences == ["source/engine/models/qwen35/main.cc"], differences
    pins = read(WORK / "source-pins.json")
    products = {p["path"]: p for p in pins["files"]}
    for phase, expected in ((old, "before"), (new, "after")):
        actual = phase["source/engine/models/qwen35/main.cc"]
        assert actual == {k: products["engine/models/qwen35/main.cc"][expected][k] for k in actual}
        actual = phase["source/tests/tools/qwen_request_ledger_case.h"]
        assert actual == products["tests/tools/qwen_request_ledger_case.h"]["after"]
    plan_old, plan_new = read(WORK / "before1/recipe.json"), read(WORK / "current1/recipe.json")
    facts = re.compile(r'duplicate_session_rejection="([^"]*)" prefix_before=(\d+) prefix_after=(\d+) '
                       r'evictions_before=(\d+) evictions_after=(\d+) live_before=(\d+) live_after=(\d+) B_strong_owners=(\d+)')
    for phase, summary, plan in (("before1", before, plan_old), ("current1", current, plan_new)):
        raw_stderr = (WORK / phase / "run/stderr.log").read_text(errors="replace")
        rows = facts.findall(raw_stderr)
        assert len(rows) == 1 and list(map(int, rows[0][1:])) == summary["duplicate_facts"]
        assert rows[0][0] == summary["duplicate_rejection_message"]
        stdout_rows = [json.loads(line) for line in (WORK / phase / "run/stdout.log").read_text().splitlines()
                       if line.startswith("{")]
        assert stdout_rows == summary["results"]
        assert read(WORK / phase / "run/process.json") == summary["process"]
        for stage in ("compile", "link"):
            assert read(WORK / phase / stage / "command.json")["command"] == plan[stage]
            assert read(WORK / phase / stage / "process.json") == summary[stage]
    assert "duplicate rejection evicted B or changed A head/RNG/ledger/turn outputs" in (WORK / "before1/run/stderr.log").read_text()
    assert plan_old["common_inputs"] == plan_new["common_inputs"] and len(plan_old["common_inputs"]) == 129
    assert plan_old["native"] == plan_new["native"] and plan_old["fixture"] == plan_new["fixture"]
    assert plan_old["fixture_bodies"] == plan_new["fixture_bodies"]
    frozen_old = {p["relative"]: p["frozen"]["sha256"] for p in read(WORK / "before1/frozen-source.json")}
    frozen_new = {p["relative"]: p["frozen"]["sha256"] for p in read(WORK / "current1/frozen-source.json")}
    assert frozen_old.keys() == frozen_new.keys()
    frozen_diff = [p for p in frozen_old if frozen_old[p] != frozen_new[p]]
    assert frozen_diff == ["engine/models/qwen35/main.cc"]
    counterfactual = {
        "actual_repository_dependency_count_each": len(old),
        "actual_dependency_key_sets_equal": True,
        "different_actual_source": differences,
        "frozen_files_each": len(frozen_old), "only_frozen_difference": frozen_diff,
        "same_new_case_both_phases": products["tests/tools/qwen_request_ledger_case.h"]["after"],
        "main_before": old[differences[0]], "main_current": new[differences[0]],
        "same_common_link_inputs": 129, "same_native_fixture_and_raw_bodies": True,
        "before": {p: old[p] for p in differences}, "current": {p: new[p] for p in differences},
        "note": "Actual compiler dependency hashes are rechecked offline. Source trees are retained privately, excluded from the ZIP. Recipes retain complete link input pins. No binaries or payloads were read into the archive."}
    save(DEST / "counterfactual-source.json", counterfactual)
    report = {
        "schema": "hyle.correctness.duplicate-session-rejection.v1", "date": "2026-10-25",
        "status": "FINITE_CPU_RED_GREEN_PASS", "base_commit": read(WORK / "baseline.json")["base_commit"],
        "problem": "Invalid direct generation batch repeating one mutable Session could evict an unrelated prefix before the later Model duplicate guard rejected it.",
        "change": "Reject duplicate actual Session objects in the existing read-only full-member preflight, before version admission/eviction, proposal work or ledger mutation. Distinct Sessions sharing one immutable base remain legal; original Model guard stays.",
        "scope": "One existing tiny ordinary CPU A/H64/FFN128/V64 Model, N2/R2, Q1/Q2 families. Same new formal ledger case with old/current main only. No new executor or error policy.",
        "sources": pins["files"], "review": {"path": "review.json", **digest((WORK / "review.json").read_bytes())},
        "counterfactual": counterfactual,
        "facts_columns": ["prefix_before", "prefix_after", "evictions_before", "evictions_after", "live_before", "live_after", "B_strong_owners_after"],
        "before": before, "current": current,
        "work": "Current retains prefix-only B and all A head/RNG/ledger/turn/output facts on rejection, then retries the original A call. Original ledger neighbors, real R2 late trace failure observation, pending continuation, raw Session API and final0 versions all pass in that same run.",
        "validation": {"app_TUs": 2, "CPU_processes": 2, "core_provider_SDK_TUs": 0, "GPU": False, "HTTP": 0,
                       "watchdog_seconds_each": 120, "expected_old_failure_retained": True, "new_compile_link_failures": 0,
                       "reproduction": "Use archived check_cpu.py with the two recipe.json/frozen-source manifests and exact source.patch at the base commit. prepare only freezes; build and run are explicit per before1/current1. Original private source trees, inputs and caches remain outside ZIP."},
        "boundaries": ["Invalid direct-helper batch only: natural RequestWindow already selects unique participants.",
                       "Finite synthetic-weight CPU fixture, not full-model quality or a GPU/native-fault injection.",
                       "Times are validation durations, not throughput or latency benchmarks.",
                       "No MTP, backend matrix, new SDK or model acquisition was performed."]}
    files = ["baseline.json", "source.patch", "source-pins.json", "review.json", "case-scope.json",
             "check_cpu.py", "preparation-summary.json", "pack_private.py"]
    for phase in ("before1", "current1"):
        files += [f"{phase}/{name}" for name in ("recipe.json", "frozen-source.json", "consumer.cc", "ready.json", "summary.json")]
        for stage in ("compile", "link", "run"):
            names = ["command.json", "process.json", "stdout.log", "stderr.log"]
            if stage == "compile":
                names += ["dependencies.json", "repository-inputs.json"]
            files += [f"{phase}/{stage}/{name}" for name in names]
    payload = {p: (WORK / p).read_bytes() for p in files}
    payload["counterfactual-source.json"] = (DEST / "counterfactual-source.json").read_bytes()
    payload["report.json"] = (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode()
    manifest = [{"path": path, **digest(raw)} for path, raw in sorted(payload.items())]
    payload["archive-members.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    archive = DEST / (NAME + ".zip")
    assert not archive.exists(), "do not silently replace a previous archive"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for path, raw in sorted(payload.items()):
            assert not path.startswith(("source/", "before/", "test-source/"))
            assert Path(path).suffix.lower() not in (".obj", ".exe", ".dll", ".lib", ".exp", ".pdb", ".bin")
            target.writestr(path, raw)
    with zipfile.ZipFile(archive) as target:
        assert target.testzip() is None
        assert set(target.namelist()) == set(payload)
        for path, raw in payload.items():
            assert digest(target.read(path)) == digest(raw), path
    report["archive"] = {"path": archive.relative_to(ROOT).as_posix(), **digest(archive.read_bytes()),
                         "files": len(payload), "CRC": "PASS_ALL_MEMBERS", "member_SHA256": "PASS_ALL_MEMBERS"}
    final = DEST / (NAME + ".json")
    save(final, report)
    save(DEST / "verification.json", {"status": "PASS_OFFLINE_ARCHIVE_VERIFICATION", "archive": report["archive"],
         "report": {"path": final.relative_to(ROOT).as_posix(), **digest(final.read_bytes())},
         "source_two_pins_match_actual": True, "red_green_facts_match_raw_summaries": True,
         "source_tree_or_binary_or_model_or_SDK_in_zip": False, "new_build_or_process": False})
    print(json.dumps(report["archive"], indent=2))
    print(json.dumps(digest(final.read_bytes()), indent=2))


if __name__ == "__main__":
    main()
