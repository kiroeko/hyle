"""One thin CPU TU per phase; prepare only freezes sources and commands.

No SDK/core/provider rebuild. Build and run are separate explicit commands.
Before/current differ only in the pinned main.cc; both use the same new case.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys

sys.dont_write_bytecode = True
WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
spec = importlib.util.spec_from_file_location(
    "cached_cpu", ROOT / ".scratch/inference-e4-model-20261025/check_cpu.py")
cached = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cached)
read, save, pin = cached.read, cached.save, cached.pin
MAIN = "engine/models/qwen35/main.cc"
CASE = "tests/tools/qwen_request_ledger_case.h"
COMPILE_RECIPE = ROOT / ".scratch/inference-assembly-placement-20261025/consumer1/compile/command.json"
LINK_RECIPE = ROOT / ".scratch/inference-e4-model-20261025/cpu2/link/command.json"
NATIVE = ROOT / ".scratch/mtp-q27-fp8-20261024/engine-cpu-current2/bin/hyle_ggml_cpu_pure_ffa4_current.dll"
RUNTIME = ROOT / ".scratch/mtp-q27-fp8-20261024/engine-cpu-current2/runtime-environment.json"
FIXTURE = ROOT / ".scratch/inference-e4-model-20261025/fixture-preparation/bf16-original"
FACTS = re.compile(r'duplicate_session_rejection="([^"]*)" prefix_before=(\d+) prefix_after=(\d+) '
                   r'evictions_before=(\d+) evictions_after=(\d+) live_before=(\d+) live_after=(\d+) B_strong_owners=(\d+)')


def folder(name):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
        raise ValueError("attempt must be one local directory name")
    return WORK / name


def verify(items):
    for item in items:
        if pin(Path(item["path"])) != item:
            raise RuntimeError("input bytes changed: " + item["path"])


def environment(compiler):
    return cached.discover_environment(compiler="msvc", cache={
        "CMAKE_C_COMPILER": compiler, "CMAKE_CXX_COMPILER": compiler,
        "CMAKE_GENERATOR": "Ninja"}, backends=()).env


def prepare(args):
    attempt = folder(args.attempt)
    if attempt.exists():
        raise FileExistsError(attempt)
    main_source = WORK / "before" / MAIN if args.phase == "before" else ROOT / MAIN
    if pin(main_source)["sha256"] != args.main_sha:
        raise RuntimeError("main SHA does not match the requested frozen phase")
    if pin(ROOT / CASE)["sha256"] != args.case_sha:
        raise RuntimeError("canonical case SHA does not match the frozen test")
    tree = attempt / "source"
    search = [ROOT / "include", ROOT, ROOT / "engine", ROOT / "tests/tools",
              ROOT / "engine/models/qwen35"]
    queue, seen, frozen = [MAIN, CASE], set(), []
    while queue:
        rel = queue.pop()
        if rel in seen:
            continue
        seen.add(rel)
        canonical = ROOT / rel
        source = main_source if rel == MAIN else canonical
        raw = source.read_bytes()
        target = tree / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        frozen.append({"relative": rel, "original": pin(source), "frozen": pin(target)})
        for inc in re.findall(r'^\s*#\s*include\s*"([^"]+)"', raw.decode("utf-8-sig"), re.M):
            for base in [canonical.parent, *search]:
                child = (base / inc).resolve()
                if child.is_file() and child.is_relative_to(ROOT):
                    queue.append(child.relative_to(ROOT).as_posix())
                    break
    save(attempt / "frozen-source.json", frozen)
    consumer = attempt / "consumer.cc"
    consumer.write_text('#include "source/engine/models/qwen35/main.cc"\n'
                        '#include "source/tests/tools/qwen_request_ledger_case.h"\n'
                        'int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("duplicate-session PREPARED_INPUTS");'
                        'return qwen_request_ledger_case::run(argv[1]);}'
                        'catch(const std::exception &e){std::cerr<<"duplicate_session_case_failure="<<e.what()<<"\\n";return 1;}}\n',
                        encoding="utf-8")
    original = read(COMPILE_RECIPE)["command"]
    compiler, flags, skip = original[0], [], False
    canonical_dirs = {ROOT, ROOT / "include", ROOT / "engine", ROOT / "engine/models/qwen35"}
    for arg in original[1:]:
        if skip:
            skip = False
            continue
        if arg == "/sourceDependencies":
            skip = True
            continue
        if arg.lower().startswith(("/fo", "/fd")) or arg.lower().endswith((".cc", ".cpp")):
            continue
        if "inference-assembly-placement-20261025" in arg:
            continue
        if arg.startswith(("/I", "-I")) and Path(arg[2:]).resolve() in canonical_dirs:
            continue
        flags.append(arg)
    flags = ["/I" + str(tree / "include"), "/I" + str(tree),
             "/I" + str(tree / "engine"), "/I" + str(tree / "engine/models/qwen35"), *flags]
    assert "/W4" in flags and "/WX" in flags and any("HYLE_COMPUTE_CPU=1" in x for x in flags)
    assert not any("HYLE_COMPUTE_CUDA=1" in x for x in flags)
    obj, image = attempt / "compile/unit.obj", attempt / "link/component.exe"
    compile_command = [compiler, *flags, str(consumer), "/sourceDependencies",
                       str(attempt / "compile/dependencies.json"), "/Fo" + str(obj),
                       "/Fd" + str(attempt / "compile/unit.pdb")]
    replacements = {
        str(ROOT / ".scratch/inference-e4-model-20261025/cpu1/compile/unit.obj"): str(obj),
        str(ROOT / ".scratch/inference-e4-model-20261025/cpu2/compile-arena/unit.obj"):
            str(ROOT / ".scratch/inference-f32-append-20261025/cpu1/compile/cpu-arena/unit.obj"),
        str(ROOT / ".scratch/inference-e4-append-implementation-20261025/clean-final/compile/cpu-append/unit.obj"):
            str(ROOT / ".scratch/inference-f32-append-20261025/cpu1/compile/cpu-append/unit.obj"),
    }
    link, actual_replacements = [], []
    for arg in read(LINK_RECIPE)["command"]:
        if arg.lower().startswith(("/out:", "/pdb:", "/implib:", "/map:")):
            continue
        if arg in replacements:
            actual_replacements.append({"before": arg, "after": replacements[arg]})
            arg = replacements[arg]
        link.append(arg)
    assert len(actual_replacements) == 3
    common = [pin(Path(arg)) for arg in link if Path(arg).is_absolute()
              and Path(arg).suffix.lower() in (".obj", ".lib") and arg != str(obj)]
    assert len(common) == 129, len(common)
    link += ["/OUT:" + str(image), "/PDB:" + str(attempt / "link/component.pdb"),
             "/IMPLIB:" + str(attempt / "link/component.lib")]
    manifest = FIXTURE / "weights.tsv"
    bodies = sorted({Path(x) for x in re.findall(r'"([^"]+)"\s+\d+\s+\d+\s*$',
                                               manifest.read_text(encoding="utf-8"), re.M)})
    assert bodies
    plan = {"status": "PREPARED_NOT_BUILT_OR_RUN", "phase": args.phase,
            "main_source": pin(main_source), "case_source": pin(ROOT / CASE),
            "compile": compile_command, "link": link, "common_inputs": common,
            "replacements": actual_replacements, "native": pin(NATIVE), "runtime": pin(RUNTIME),
            "fixture": pin(manifest), "fixture_bodies": [pin(p) for p in bodies],
            "consumer": pin(consumer), "compiler_recipe": pin(COMPILE_RECIPE),
            "link_recipe": pin(LINK_RECIPE), "argv": [str(image), str(FIXTURE)],
            "app_TUs": 1, "core_provider_SDK_TUs": 0, "GPU": False, "HTTP": 0,
            "watchdog_seconds": 120, "expected_exit": 1 if args.phase == "before" else 0}
    save(attempt / "recipe.json", plan)
    print(json.dumps({"status": plan["status"], "phase": args.phase,
                      "recipe": str(attempt / "recipe.json"), "frozen_files": len(frozen),
                      "retained_inputs": len(common), "fixture": str(FIXTURE)}))


def build(args):
    attempt = folder(args.attempt)
    plan = read(attempt / "recipe.json")
    verify([*plan["common_inputs"], plan["native"], plan["runtime"], plan["fixture"],
            *plan["fixture_bodies"], plan["consumer"]])
    frozen = read(attempt / "frozen-source.json")
    verify([entry["frozen"] for entry in frozen])
    env = environment(plan["compile"][0])
    compiled = cached.execute(plan["compile"], env, attempt / "compile", 120)
    data = read(attempt / "compile/dependencies.json")["Data"]
    actual = [Path(p) for p in dict.fromkeys([data["Source"], *data["Includes"]])]
    for p in actual:
        if any(p.is_relative_to(ROOT / category) for category in ("engine", "tests", "include")):
            raise RuntimeError("canonical source/header escaped frozen tree: " + str(p))
    for rel in [MAIN, CASE, "engine/inference/request_progress.h",
                "engine/inference/sampling_graph.h", "engine/inference/retirement_observation.h"]:
        assert attempt / "source" / rel in actual, rel
    save(attempt / "compile/repository-inputs.json", [pin(p) for p in actual if p.is_relative_to(ROOT)])
    linked = cached.execute(plan["link"], env, attempt / "link", 90)
    image = attempt / "link/component.exe"
    os.link(NATIVE, image.parent / NATIVE.name)
    verify([entry["frozen"] for entry in frozen])
    save(attempt / "ready.json", {"image": pin(image), "object": pin(attempt / "compile/unit.obj"),
                                  "native": pin(image.parent / NATIVE.name), "compile": compiled, "link": linked})
    print("READY", args.attempt, "CPU only; not run")


def run(args):
    attempt = folder(args.attempt)
    plan, ready = read(attempt / "recipe.json"), read(attempt / "ready.json")
    verify([ready["image"], ready["object"], ready["native"], *plan["common_inputs"],
            plan["fixture"], *plan["fixture_bodies"]])
    env = environment(plan["compile"][0])
    env["PATH"] = str(attempt / "link") + ";" + read(RUNTIME)["PATH"]
    env["HF_HUB_OFFLINE"] = env["TRANSFORMERS_OFFLINE"] = "1"
    try:
        process = cached.execute(plan["argv"], env, attempt / "run", 120)
    except RuntimeError:
        process = read(attempt / "run/process.json")
        if plan["phase"] != "before" or process["exit"] != 1:
            raise
    stderr = (attempt / "run/stderr.log").read_text(errors="replace")
    matches = FACTS.findall(stderr)
    assert len(matches) == 1, "missing/ambiguous duplicate-session facts"
    rejection, *numbers = matches[0]
    numbers = list(map(int, numbers))
    results = [json.loads(line) for line in (attempt / "run/stdout.log").read_text().splitlines()
               if line.startswith("{")]
    if plan["phase"] == "before":
        assert process["exit"] == 1 and numbers == [1, 0, 0, 1, 2, 1, 0], numbers
        assert "duplicate rejection evicted B or changed A head/RNG/ledger/turn outputs" in stderr
        status = "EXPECTED_OLD_REJECTION_SIDE_EFFECT_REPRODUCED"
    else:
        assert process["exit"] == 0 and numbers == [1, 1, 0, 0, 2, 2, 1], numbers
        assert len(results) == 1 and results[0]["status"] == "PASS"
        assert results[0]["duplicate_Session_before_prefix_eviction"] is True
        assert results[0]["same_request_retry"] is True
        status = "FINITE_CPU_LEDGER_AND_DUPLICATE_REJECTION_PASS"
    save(attempt / "summary.json", {"status": status, "phase": plan["phase"], "process": process,
          "duplicate_rejection_message": rejection, "duplicate_facts": numbers, "results": results,
          "compile": ready["compile"], "link": ready["link"], "image": ready["image"],
          "app_TUs": 1, "common_link_inputs": 129, "core_provider_SDK_TUs": 0,
          "native": plan["native"], "fixture": plan["fixture"], "GPU": False, "HTTP": 0})
    print(status)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    prep = actions.add_parser("prepare")
    prep.add_argument("--phase", choices=("before", "current"), required=True)
    prep.add_argument("--attempt", required=True)
    prep.add_argument("--main-sha", required=True)
    prep.add_argument("--case-sha", required=True)
    for action in ("build", "run"):
        command = actions.add_parser(action)
        command.add_argument("--attempt", required=True)
    args = parser.parse_args()
    {"prepare": prepare, "build": build, "run": run}[args.action](args)
