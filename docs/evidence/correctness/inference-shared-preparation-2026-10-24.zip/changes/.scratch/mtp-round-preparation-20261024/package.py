"""Bounded shared preparation evidence; no binaries, SDKs or trained-model claims."""
from pathlib import Path
import difflib,hashlib,json,zipfile
D=Path(__file__).resolve().parent;R=D.parents[1];G=D/'regression'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
s=read(G/'summary.json');assert s['state']=='passed' and s['all_original_GA_state_bytes_equal']
main=R/'engine/models/qwen35/main.cc';assert pin(main)['sha256']==s['source']['sha256']
for name in ['main-syntax2','prefix-probe-syntax1']:
 x=read(D/name/'process.json');assert x['exit']==0 and not x['timeout']
assert read(D/'main-syntax1/process.json')['exit']!=0
out=R/'docs/evidence/correctness/inference-shared-preparation-2026-10-24';archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 with zipfile.ZipFile(G/'logs.zip')as source:
  assert source.testzip()is None
  for entry in source.infolist():
   if not entry.is_dir():z.writestr('regression/'+entry.filename,source.read(entry))
 for folder in ['main-syntax1','main-syntax2','prefix-probe-syntax1']:
  for p in(D/folder).iterdir():
   if p.suffix in{'.json','.log'}:z.write(p,'strict/'+folder+'/'+p.name)
 for p in[Path(__file__),D/'main-before.cc',D/'scratch-edit.json',D/'integration.json',R/'tests/tools/qwen_mtp_prefix_value_probe.cc']:
  z.write(p,'changes/'+p.relative_to(R).as_posix())
 delta=''.join(difflib.unified_diff((D/'main-before.cc').read_text().splitlines(True),main.read_text().splitlines(True),fromfile='before/main.cc',tofile='current/main.cc'))
 z.writestr('changes/main.patch',delta)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 assert not any(Path(name).suffix.lower()in{'.obj','.exe','.pdb','.lib','.dll'}for name in z.namelist())
result=dict(status='PASS bounded ordinary/MTP shared preparation',
 scope='Lower-level inference preparation and fixed configuration; original execution, sampling addresses, model state containers and retirement remain authoritative.',
 changes=[
  'One Model-owned integer upload scratch reuses packed IDs, target/draft positions, catchups and random identities. Actual cold Phase and prefix-sampler tensor extents reserve capacity; no per-Phase duplicate scratch or maximum-plan preallocation.',
  'Sampler, CPU FFN placement, cache plan, capacity, replay and diagnostic topology are constructor-fixed. DraftPolicy is read-only after the first preparation starts; cached graph keys remain unchanged.',
  'Single- and multi-request entry points share the existing recursive draft/prefix/head preparation. Target shape and replay-use discovery remain with their actual request plans.'
 ],
 checks=dict(strict_main=read(D/'main-syntax2/process.json'),strict_existing_prefix_probe=read(D/'prefix-probe-syntax1/process.json'),finite_journey={k:s[k]for k in['scope','actual_state_files','all_original_GA_state_bytes_equal','GA','A','input_scratch','configuration','successful_strict_compile','link','actual_run','distinct_private_TUs','strict_compile_attempts','successful_compiles','links','actual_processes','private_models','complete_models']if k in s},details=pin(G/'summary.json')),
 source=[pin(main),pin(R/'tests/tools/qwen_mtp_prefix_value_probe.cc')],
 first_failure=dict(reason=s['first_failure']['reason'],correction=s['correction'],preserved=True),
 limits=['The existing Model serial-call contract and one carrier still apply; no new cross-thread concurrency guarantee.',
         'Stable capacity/address observations cover the five upload vectors; other host metadata still allocates.',
         'GA consumed2 is an explicit complete-state control; A K2 acceptance is a separate natural small-model journey.',
         'No trained-model quality, full backend matrix, end-to-end speed or VRAM improvement is claimed.'],
 SDK_builds=0,HTTP=0,performance_claim=False,archive=pin(archive))
out.with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(result=pin(out.with_suffix('.json')),archive=pin(archive))))
