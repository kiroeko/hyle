// Actual untrained GA Model state regression. The T3 accepted prefix is an
// explicit consumed2 state control, not a natural acceptance/quality claim.
#include "engine/models/qwen35/main.cc"
#include "hyle/compute/detail/paged_arena_access.h"

namespace q = qwen35;
namespace c = q::c;
using Bytes = std::vector<std::byte>;
void require(bool yes, const char* message) { if (!yes) throw std::runtime_error(message); }
q::ModelGeometry geometry() {
  q::ModelGeometry s;
  s.hidden=64; s.intermediate=128; s.vocabulary=64;
  s.query_heads=s.kv_heads=1; s.key_depth=s.value_depth=s.rotary=64;
  s.gdn_key_heads=s.gdn_value_heads=1; s.gdn_key_depth=s.gdn_value_depth=64;
  s.conv_kernel=4; s.context_limit=16; s.rope_theta=10000; s.epsilon=1.e-6F;
  s.tied_head=true; s.layers="GA"; s.mtp_layers=1; s.validate(); return s;
}
std::pair<std::filesystem::path,std::size_t> weights(const std::filesystem::path& folder,const q::ModelGeometry& s) {
  std::size_t expected=0;
  for (const auto& [name,p] : q::prepared::parameter_inventory(true,s)) {
    const bool scalar_f32=p.allow_f32 && p.shape==std::vector<std::int64_t>{1} && (name.ends_with(".A_log") || name.ends_with(".dt_bias"));
    std::size_t n=1; for(auto d:p.shape) n*=static_cast<std::size_t>(d); expected+=n*(scalar_f32?4:2);
  }
  require(expected<1024*1024,"GA fixture exceeds1MiB");
  const auto body=folder/"untrained-bf16.bin", list=folder/"weights.tsv";
  if(std::filesystem::exists(list)) {
    require(std::filesystem::file_size(body)==expected,"shared fixture size changed");
    return {list,expected};
  }
  std::filesystem::create_directories(folder);
  std::ofstream payload(body,std::ios::binary), manifest(list);
  require(bool(payload)&&bool(manifest),"cannot create GA fixture");
  manifest<<"HYLE_QWEN_ROLE_FILES_V2\n"<<std::string(64,'6')<<'\n'
    <<"geometry 64 128 64 1 1 64 64 64 1 1 64 64 4 16 10000 1e-6 1 1 grouped \"GA\"\n";
  std::size_t offset=0,index=0;
  for(const auto& [name,p]:q::prepared::parameter_inventory(true,s)) {
    std::size_t n=1;for(auto d:p.shape)n*=static_cast<std::size_t>(d);
    std::vector<std::uint16_t> values(n);
    for(std::size_t i=0;i<n;++i) {
      const float value=p.shape.size()==1?0.F:.03F*std::sin(float(i+index*17)*.13F);
      auto bits=std::bit_cast<std::uint32_t>(value);bits+=0x7fffU+((bits>>16)&1U);
      values[i]=static_cast<std::uint16_t>(bits>>16);
    }
    const bool scalar_f32=p.allow_f32 && p.shape==std::vector<std::int64_t>{1} && (name.ends_with(".A_log") || name.ends_with(".dt_bias"));
    const std::size_t bytes=n*(scalar_f32?4:2);
    if(scalar_f32) { const float exact_zero=0.F; payload.write(reinterpret_cast<const char*>(&exact_zero),4); }
    else payload.write(reinterpret_cast<const char*>(values.data()),static_cast<std::streamsize>(bytes));
    manifest<<name<<(scalar_f32?" F32 ":" BF16 ")<<p.shape.size();for(auto d:p.shape)manifest<<' '<<d;
    manifest<<' '<<std::quoted(body.generic_string())<<' '<<offset<<' '<<bytes<<'\n';
    offset+=bytes;++index;
  }
  require(bool(payload)&&bool(manifest)&&offset==expected,"GA fixture write differs");return {list,expected};
}
Bytes read(q::Model& model,const c::ReadLease& lease) {
  if(!lease.valid())return{};
  Bytes result(lease.size());q::check(model.execution.read(q::take(lease.view()),result));return result;
}
void store(const std::filesystem::path& file,const Bytes& bytes) {
  std::filesystem::create_directories(file.parent_path());std::ofstream out(file,std::ios::binary);
  out.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
  require(bool(out),"cannot write actual state bytes");
}
Bytes logical_rows(q::Model& model,const c::PagedArena& arena,const c::PagedArenaRead& frame,std::size_t rows,std::size_t row_bytes) {
  const auto layout=frame.layout().host();const auto pages=(rows+15)/16;
  require(frame.valid()&&layout.page_indices.size()==pages&&frame.page_count()==pages,"logical state page footprint differs");
  Bytes result(rows*row_bytes);std::size_t at=0;
  const auto guards=c::detail::PagedArenaAccess::pages(frame);
  for(std::size_t i=0;i<pages;++i) {
    const c::ReadLease* selected=nullptr;
    for(const auto& guard:guards)if(q::take(c::detail::PagedArenaAccess::page(arena,guard))==static_cast<std::uint32_t>(layout.page_indices[i]))selected=&guard;
    require(selected!=nullptr,"logical page lost original read guard");
    const auto bytes=(std::min)(16*row_bytes,result.size()-at);
    q::check(model.execution.read(q::take(q::take(selected->view()).subview(0,bytes)),std::span(result).subspan(at,bytes)));at+=bytes;
  }
  return result;
}

static_assert(std::is_const_v<decltype(std::declval<q::Model>().sampler)>);
static_assert(std::is_const_v<decltype(std::declval<q::Model>().cpu_ffn_layers)>);
static_assert(std::is_const_v<decltype(std::declval<q::Model>().cache_plan)>);
static_assert(std::is_const_v<decltype(std::declval<q::Model>().capacity)>);
static_assert(std::is_const_v<decltype(std::declval<q::Model>().replay_policy)>);
struct ScratchObservation final {
  struct Entry { std::size_t capacity; const void* address; };
  std::array<Entry,5> entries;
  std::array<std::size_t,5> maximum_sizes{};
  std::size_t checks=0;
  static auto facts(const q::Model& model) {
    const auto& s=model.input_scratch;
    return std::array<Entry,5>{{{s.packed_ids.capacity(),s.packed_ids.data()},
      {s.positions.capacity(),s.positions.data()}, {s.draft_positions.capacity(),s.draft_positions.data()},
      {s.catchups.capacity(),s.catchups.data()}, {s.sampling_identities.capacity(),s.sampling_identities.data()}}};
  }
  explicit ScratchObservation(const q::Model& model):entries(facts(model)){}
  void check(const q::Model& model) {
    const auto now=facts(model); const auto& s=model.input_scratch;
    const std::array sizes{s.packed_ids.size(),s.positions.size(),s.draft_positions.size(),s.catchups.size(),s.sampling_identities.size()};
    for(std::size_t i=0;i<5;++i) {
      require(now[i].capacity==entries[i].capacity && now[i].address==entries[i].address,
        "prepared input scratch changed capacity or backing address in actual hot episode");
      maximum_sizes[i]=(std::max)(maximum_sizes[i],sizes[i]);
    }
    ++checks;
  }
  void report(const char* label) const {
    std::cout<<"{\"scratch\":\""<<label<<"\",\"checks\":"<<checks<<",\"capacity\":[";
    for(std::size_t i=0;i<5;++i)std::cout<<(i?",":"")<<entries[i].capacity;
    std::cout<<"],\"maximum_observed_size\":[";
    for(std::size_t i=0;i<5;++i)std::cout<<(i?",":"")<<maximum_sizes[i];
    std::cout<<"],\"capacity_and_address_stable\":true,\"whole_path_zero_allocation_claim\":false}\n";
  }
};
void reject_late_policy(q::Model& model) {
  const auto maximum=model.max_drafts(); const auto probability=model.min_draft_probability();
  const auto family_count=model.families.size(),phase_count=model.phases.size(),draft_count=model.draft_programs.size();
  const auto versions=model.snapshot_versions.live; const auto active=model.active_step.get();
  bool rejected=false;
  try {model.configure_draft_policy({.max_drafts=maximum==0?1u:0u,.minimum_probability=0.F});}
  catch(const std::runtime_error&) {rejected=true;}
  require(rejected,"late DraftPolicy modification was accepted after cold preparation");
  require(model.max_drafts()==maximum && model.min_draft_probability()==probability &&
    model.families.size()==family_count && model.phases.size()==phase_count &&
    model.draft_programs.size()==draft_count && model.snapshot_versions.live==versions &&
    model.active_step.get()==active,"late DraftPolicy rejection modified original model state or graph inventory");
}

using Image=std::map<std::string,Bytes>;
Image image(q::Model& model,const q::cache::Snapshot& head) {
  Image result;
  const auto add=[&](std::string name,const c::ReadLease& lease){if(lease.valid())result.emplace(std::move(name),read(model,lease));};
  for(std::size_t i=0;i<head.state.size();++i)if(model.geometry.is_gdn(i)) {
    add("gdn"+std::to_string(i)+".history.bf16",head.state[i].history);
    add("gdn"+std::to_string(i)+".recurrent.f32",head.state[i].recurrent);
  }
  for(std::size_t i=0;i<head.keys.size();++i) {
    result.emplace("target"+std::to_string(i)+".key.bf16",logical_rows(model,model.page_inventory.keys[i],head.keys[i],head.length,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("target"+std::to_string(i)+".value.bf16",logical_rows(model,model.page_inventory.values[i],head.values[i],head.length,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  add("carry.bf16",head.carry_hidden);add("prior.bf16",head.prior_hidden);
  if(head.draft) {
    result.emplace("draft.key.bf16",logical_rows(model,model.draft_inventory.keys[0],head.draft->key,head.draft->frontier,static_cast<std::size_t>(model.geometry.key_row_bytes())));
    result.emplace("draft.value.bf16",logical_rows(model,model.draft_inventory.values[0],head.draft->value,head.draft->frontier,static_cast<std::size_t>(model.geometry.value_row_bytes())));
  }
  std::ostringstream meta;
  meta<<"length="<<head.length<<" next="<<head.next_id<<" seed="<<head.sampling.seed<<" stream="<<head.sampling.stream<<" draw="<<head.sampling.draw;
  if(head.draft)meta<<" frontier="<<head.draft->frontier<<" lag="<<head.draft->lag<<" catchup="<<head.draft->catchup_token;
  const auto text=meta.str();result.emplace("metadata.txt",Bytes(reinterpret_cast<const std::byte*>(text.data()),reinterpret_cast<const std::byte*>(text.data()+text.size())));return result;
}
void dump(const std::filesystem::path& folder,const Image& data){for(const auto& [name,bytes]:data)store(folder/name,bytes);}
struct Prefix {c::ReadLease history,recurrent;};
std::vector<Prefix> retain_prefixes(q::Model& model) {
  auto& step=*model.active_step;q::check(step.completion.wait());
  const auto& ports=step.phase->layers[0].sequences[0];std::vector<Prefix> result;
  for(std::size_t row=0;row<ports.history_prefix.size();++row)
    result.push_back({q::take(q::take(step.run->result(ports.history_prefix[row])).storage_lease()),q::take(q::take(step.run->result(ports.recurrent_prefix[row])).storage_lease())});
  return result;
}
void check_prefix(q::Model& model,const q::cache::Snapshot& head,const Prefix& expected) {
  require(read(model,head.state[0].history)==read(model,expected.history),"published history is not the actual selected prefix");
  require(read(model,head.state[0].recurrent)==read(model,expected.recurrent),"published recurrent state is not the actual selected prefix");
}
void retire(std::shared_ptr<q::Session>& s){q::check(s->stop());q::check(s->drain());require(q::take(s->try_retire()),"actual session did not retire");s.reset();}
int ga_check(int argc,char** argv) {
  try {
    require(argc==3,"gdn-check SHARED_FIXTURE OUTPUT");const auto shape=geometry();const auto fixture=weights(argv[1],shape);const std::filesystem::path out=argv[2];
    std::filesystem::create_directories(out);std::int32_t ordinary_first=-1,ordinary_next=-1;std::size_t ordinary_peak=0;
    {
      const auto plan=q::cache::plan(shape,16,4,3,q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,1,false,true);
      q::Model model(fixture.first,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
        {.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
      const std::array chunks{std::size_t{2},std::size_t{1}};model.prepare_family(chunks);model.plan_execution(chunks);
      auto session=model.create_session(chunks);model.prepare_execution(chunks);ScratchObservation scratch(model);reject_late_policy(model);const std::array<std::int32_t,2> prompt{1,2};
      model.prepare_evaluation(*session,prompt);model.submit_evaluation(*session);auto expected=retain_prefixes(model);
      require(expected.size()==1,"ordinary T2 must expose one final state at row0");
      ordinary_first=model.finish_evaluation(*session,"ordinary-P2",{},false);scratch.check(model);check_prefix(model,*session->head,expected[0]);
      require(!session->head->draft&&session->head->length==2&&session->head->sampling.draw==1,"ordinary prefill state/RNG differs");
      auto base=session->head;const auto saved=image(model,*base);dump(out/"ordinary-base",saved);expected.clear();
      const std::array ids{ordinary_first};model.prepare_evaluation(*session,ids);model.submit_evaluation(*session);expected=retain_prefixes(model);
      require(expected.size()==1,"ordinary T1 must expose state row0");ordinary_next=model.finish_evaluation(*session,"ordinary-T1",{},false);scratch.check(model);check_prefix(model,*session->head,expected[0]);
      require(session->head->length==3&&session->head->sampling.draw==2&&!session->head->draft,"ordinary continuation state/RNG differs");
      require(saved==image(model,*base),"ordinary old Snapshot changed after append extraction");dump(out/"ordinary-final",image(model,*session->head));
      ordinary_peak=model.cache_usage().peak_bytes;require(ordinary_peak<=16*1024*1024,"ordinary finite budget escaped");
      require(saved==image(model,*base),"ordinary state changed before late-policy rejection");reject_late_policy(model);require(saved==image(model,*base),"late-policy failure changed ordinary original checkpoint");scratch.report("GA-ordinary");expected.clear();base.reset();retire(session);require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"ordinary resources remain admitted");
    }
    std::vector<std::int32_t> proposals,candidates;std::int32_t mtp_pending=-1;std::size_t mtp_peak=0;
    {
      const auto plan=q::cache::plan(shape,16,4,3,q::recurrent_bytes(q::state_schema_for(shape,16),shape),1,3,true,true);
      q::Model model(fixture.first,shape,16,plan,{},false,q::ReplayPolicy::kCommands,16*1024*1024,
        {.enabled=true,.policy={1.F,8,.9F},.seed=123},0,{.primary=hyle::inference::BackendKind::kVulkan});
      model.configure_draft_policy({.max_drafts=2});const std::array p2{std::size_t{2}},t3{std::size_t{3}},single{std::size_t{1}};
      model.prepare_family(p2,false,1,q::GraphRole::kMtpPrefill);model.plan_replay_uses(2,1,1,q::GraphRole::kMtpPrefill);
      model.prepare_family(t3,false,1,q::GraphRole::kVerify);model.plan_replay_uses(3,1,1,q::GraphRole::kVerify);
      model.prepare_family(single,false,1,q::GraphRole::kMtpCatchupSingle);model.plan_replay_uses(1,1,1,q::GraphRole::kMtpCatchupSingle);
      model.prepare_recursive_round_programs();
      auto session=model.create_session(p2,{},q::GraphRole::kMtpPrefill);model.prepare_execution(p2,1,q::GraphRole::kMtpPrefill);model.prepare_execution(t3,1,q::GraphRole::kVerify);model.prepare_execution(single,1,q::GraphRole::kMtpCatchupSingle);ScratchObservation scratch(model);reject_late_policy(model);const std::array<std::int32_t,2> prompt{1,2};
      model.prepare_evaluation(*session,prompt,nullptr,q::GraphRole::kMtpPrefill);model.submit_evaluation(*session);auto seed_prefix=retain_prefixes(model);
      model.finish_evaluation(*session,"mtp-P2",{},false);scratch.check(model);check_prefix(model,*session->head,seed_prefix.at(0));seed_prefix.clear();
      auto base=session->head;const auto saved=image(model,*base);dump(out/"mtp-base",saved);
      std::vector<c::ReadLease> qrows;proposals=model.propose_recursive(*session,2,{},&qrows);
      require(proposals.size()==3&&qrows.size()==2&&model.draft_program_graph_calls==2,"real two recursive proposals missing");scratch.check(model);
      model.prepare_evaluation(*session,proposals,nullptr,q::GraphRole::kVerify);model.submit_evaluation(*session);auto expected=retain_prefixes(model);
      require(expected.size()==3,"T3 did not publish all three complete GDN prefixes");
      require(read(model,expected[0].history)!=read(model,expected[1].history)&&read(model,expected[2].history)!=read(model,expected[1].history),"GDN selected-row history witness is degenerate");
      require(read(model,expected[0].recurrent)!=read(model,expected[1].recurrent),"GDN recurrent selected-row witness is degenerate");
      for(std::size_t row=0;row<3;++row){store(out/("verifier-prefix"+std::to_string(row)+".history.bf16"),read(model,expected[row].history));store(out/("verifier-prefix"+std::to_string(row)+".recurrent.f32"),read(model,expected[row].recurrent));}
      const std::array outputs{q::EvaluationOutput{.session=session,.name="forced-consumed2-T3",.trace_states=false}};std::array<std::int32_t,1> next{};
      model.finish_selected_evaluations(outputs,next,[&](std::span<const std::int32_t> actual,q::StepState& step,std::span<std::int32_t> selected){
        candidates.assign(actual.begin(),actual.end());require(candidates.size()==3,"real target candidate count differs");
        auto& member=step.members[0];member.accepted_tokens=2;selected[0]=actual[1];member.next->sampling=member.base->sampling.advanced(5);
      },[&](q::StepState& step){model.repair_recursive_draft(step);});
      scratch.check(model);mtp_pending=next[0];check_prefix(model,*session->head,expected[1]);
      require(session->head->length==4&&session->head->next_id==mtp_pending&&session->head->sampling.draw==6&&base->sampling.draw==1,"controlled prefix pending/RNG publication differs");
      require(model.draft_program_graph_calls==3&&session->head->draft->frontier==3&&session->head->draft->lag==1&&session->head->draft->catchup_token==proposals[1],"real head=false NextN repair did not retain complete selected prefix");
      model.validate_mtp_snapshot(*session->head);require(saved==image(model,*base),"MTP old Snapshot mutated by verifier/repair/take_append");dump(out/"mtp-final",image(model,*session->head));
      mtp_peak=model.cache_usage().peak_bytes;require(mtp_peak<=16*1024*1024,"MTP finite budget escaped");
      expected.clear();qrows.clear();reject_late_policy(model);require(saved==image(model,*base),"late-policy failure changed MTP original checkpoint");
      auto before_catchup=session->head;const std::array catchup_ids{before_catchup->next_id};model.prepare_evaluation(*session,catchup_ids,nullptr,q::GraphRole::kMtpCatchupSingle);model.submit_evaluation(*session);model.finish_evaluation(*session,"catchup-single",{},false);scratch.check(model);
      require(session->head->length==before_catchup->length+1&&session->head->sampling.draw==before_catchup->sampling.draw+1&&session->head->draft->lag==0,"actual pending catchup state differs");model.validate_mtp_snapshot(*session->head);require(saved==image(model,*base),"pending catchup changed old Snapshot");scratch.report("GA-MTP-catchup");before_catchup.reset();base.reset();retire(session);require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"MTP resources remain admitted");
    }
    std::cout<<"{\"state\":\"passed\",\"backend\":\"vulkan\",\"layers\":\"GA\",\"fixture_bytes\":"<<fixture.second<<",\"ordinary_ids\":["<<ordinary_first<<','<<ordinary_next<<"],\"ordinary_rng\":2,\"ordinary_state_prefix_row\":0,\"real_proposals\":[";
    for(std::size_t i=0;i<proposals.size();++i)std::cout<<(i?",":"")<<proposals[i];
    std::cout<<"],\"real_target_candidates\":[";for(std::size_t i=0;i<candidates.size();++i)std::cout<<(i?",":"")<<candidates[i];
    std::cout<<"],\"controlled_consumed\":2,\"selected_prefix_row\":1,\"mtp_pending\":"<<mtp_pending<<",\"mtp_rng\":6,\"draft_frontier\":3,\"draft_lag\":1,\"real_head_false_repair\":true,\"old_snapshots_unchanged\":true,\"leases_survive_take_append\":true,\"ordinary_cache_peak\":"<<ordinary_peak<<",\"mtp_cache_peak\":"<<mtp_peak<<",\"cache_limit\":16777216,\"natural_acceptance_claim\":false,\"quality_claim\":false,\"performance_claim\":false,\"HTTP\":0}\n";return 0;
  }catch(const std::exception& error){std::cerr<<"GA state regression: "<<error.what()<<'\n';return 1;}
}

namespace a_probe {
// One untrained, finite Model journey. Exercises product NextN/Graph/state;
// never a trained-model quality or performance test.


namespace q = qwen35;
void require(bool value, const char *message) {
  if (!value) throw std::runtime_error(message);
}
q::ModelGeometry geometry() {
  q::ModelGeometry shape;
  shape.hidden = 64; shape.intermediate = 128; shape.vocabulary = 64;
  shape.query_heads = shape.kv_heads = 1;
  shape.key_depth = shape.value_depth = shape.rotary = 64;
  shape.gdn_key_heads = shape.gdn_value_heads = 1;
  shape.gdn_key_depth = shape.gdn_value_depth = 64;
  shape.conv_kernel = 4; shape.context_limit = 16;
  shape.rope_theta = 10000; shape.epsilon = 1.e-6F;
  shape.tied_head = true; shape.layers = "A"; shape.mtp_layers = 1;
  shape.validate(); return shape;
}
std::pair<std::filesystem::path, std::size_t> weights(
    const std::filesystem::path &folder, const q::ModelGeometry &shape) {
  std::filesystem::create_directories(folder);
  const auto payload_path = folder / "untrained-bf16.bin";
  std::ofstream payload(payload_path, std::ios::binary), manifest(folder / "weights.tsv");
  if (!payload || !manifest) throw std::runtime_error("cannot create finite NextN fixture");
  manifest << "HYLE_QWEN_ROLE_FILES_V2\n" << std::string(64, '3') << '\n'
      << "geometry 64 128 64 1 1 64 64 64 1 1 64 64 4 16 10000 1e-6 1 1 grouped \"A\"\n";
  std::size_t offset = 0, role_index = 0;
  for (const auto &[name, parameter] : q::prepared::parameter_inventory(true, shape)) {
    std::size_t elements = 1;
    for (const auto extent : parameter.shape) elements *= static_cast<std::size_t>(extent);
    std::vector<std::uint16_t> values(elements);
    for (std::size_t n = 0; n < elements; ++n) {
      const float value = parameter.shape.size() == 1 ? 0.F
          : .03F * std::sin(float(n + role_index * 17) * .13F);
      auto bits = std::bit_cast<std::uint32_t>(value);
      bits += 0x7fffU + ((bits >> 16) & 1U);
      values[n] = static_cast<std::uint16_t>(bits >> 16);
    }
    payload.write(reinterpret_cast<const char *>(values.data()),
        static_cast<std::streamsize>(values.size() * sizeof(std::uint16_t)));
    manifest << name << " BF16 " << parameter.shape.size();
    for (const auto extent : parameter.shape) manifest << ' ' << extent;
    manifest << ' ' << std::quoted(payload_path.generic_string()) << ' ' << offset
        << ' ' << values.size() * sizeof(std::uint16_t) << '\n';
    offset += values.size() * sizeof(std::uint16_t); ++role_index;
  }
  require(offset < 256 * 1024, "tiny fixture accidentally grew beyond its declared bound");
  return {folder / "weights.tsv", offset};
}
int run(int argc, char **argv) {
  try {
    if (argc != 2) throw std::runtime_error("tiny-draft-readback PRIVATE_WORK_DIR");
    const auto shape = geometry();
    const auto fixture = weights(std::filesystem::path(argv[1]) / "fixture", shape);
    const auto plan = q::cache::plan(shape, 16, 4, 3,
        q::recurrent_bytes(q::state_schema_for(shape, 16), shape), 2, 3, true, true);
    q::Model model(fixture.first, shape, 16, plan, {}, false, q::ReplayPolicy::kCommands,
        16 * 1024 * 1024, {.enabled = true, .policy = {1.F, 8, .9F}, .seed = 123},
        0, {.primary = hyle::inference::BackendKind::kVulkan});
    model.configure_draft_policy({.max_drafts=2,.minimum_probability=1.e-4F});
    const std::array prefill{std::size_t{2}}, verifier{std::size_t{3}};
    model.prepare_family(prefill, false, 1, q::GraphRole::kMtpPrefill);
    model.plan_replay_uses(2, 1, 1, q::GraphRole::kMtpPrefill);
    model.prepare_family(verifier, false, 1, q::GraphRole::kVerify);
    model.plan_replay_uses(3, 1, 1, q::GraphRole::kVerify);
    model.prepare_family(prefill, false, 2, q::GraphRole::kMtpRound);
    model.plan_replay_uses(2, 2, 1, q::GraphRole::kMtpRound);
    for (std::size_t rows = 1; rows <= 3; ++rows) model.prepare_draft_program(rows, false);
    model.prepare_draft_program(1, true); model.prepare_draft_program(2, true);
    model.prepare_prefix_sampling(2);
    auto session = model.create_session(prefill, {}, q::GraphRole::kMtpPrefill);
    model.prepare_execution(prefill,1,q::GraphRole::kMtpPrefill);model.prepare_execution(verifier,1,q::GraphRole::kVerify);model.prepare_execution(prefill,2,q::GraphRole::kMtpRound);ScratchObservation scratch(model);reject_late_policy(model);
    const std::array<std::int32_t, 2> prompt{1, 2};
    model.prepare_evaluation(*session, prompt, nullptr, q::GraphRole::kMtpPrefill);
    model.submit_evaluation(*session);
    model.finish_evaluation(*session, "seed", {}, false);scratch.check(model);
    auto base = session->head;
    require(base->sampling == q::cache::SamplingCursor{123, 0, 1}, "seed cursor differs");
    const auto pending = base->next_id;
    std::vector<q::c::ReadLease> log_q;
    auto ids = model.propose_recursive(*session, 2, {}, &log_q);scratch.check(model);
    // Maximum probability after topK8 is >=1/8. The small positive threshold
    // therefore exercises actual probability readback without forcing a stop.
    require(ids.size() == 3 && log_q.size() == 2 && ids[0] == pending,
        "actual two-proposal categorical/threshold journey was not reached");
    require(model.draft_program_graph_calls == 2, "unexpected proposal program calls");
    auto &program = *model.draft_programs.at({1, true});
    require(program.id_value.facts.description.data_type() == q::Type::kInt32,
        "actual id readback description differs");
    require(program.valid_value.facts.description.data_type() == (model.execution.native_generated_storage() ? q::Type::kFloat32 : q::Type::kBool) &&
        program.probability_value.facts.description.data_type() == q::Type::kFloat32,
        "actual predicate/probability readback descriptions differ");
    const bool id_caller = program.id_value.facts.caller_owned();
    const bool valid_caller = program.valid_value.facts.caller_owned();
    const bool probability_caller = program.probability_value.facts.caller_owned();
    const std::array inputs{q::EvaluationRequest{session, ids}};
    const std::array outputs{q::EvaluationOutput{.session = session, .name = "verify", .trace_states = false}};
    const std::array selections{q::MtpGenerationSelection{session, pending, 3, log_q, 2}};
    std::array<q::MtpRoundResult, 1> results;
    model.prepare_evaluations(inputs, nullptr, q::GraphRole::kVerify); model.submit_evaluations();
    model.finish_recursive_mtp(selections, {}, outputs, results);scratch.check(model);
    const auto &result = results[0];
    require(result.proposal_count == 2 && result.verified_rows == 3 && result.processed_target >= 1 &&
        result.processed_target <= 3, "verifier selected an invalid complete prefix");
    require(model.draft_program_graph_calls == 3 && model.prefix_decision_graph_calls == 1,
        "real head=false prefix repair or stochastic decision did not execute");
    require(session->head != base && session->head->sampling.draw == 6 && base->sampling.draw == 1,
        "complete state/pending/RNG did not publish atomically");
    require(session->head->length == 2 + result.processed_target &&
        session->head->draft->frontier + session->head->draft->lag == session->head->length,
        "target and repaired NextN frontiers differ");
    model.validate_mtp_snapshot(*session->head);
    std::array classic_sessions{
        model.create_session({}, base, q::GraphRole::kMtpPrefill, q::cache::SamplingCursor{123, 0, 0}, true),
        model.create_session({}, base, q::GraphRole::kMtpPrefill, q::cache::SamplingCursor{123, 1, 0}, true)};
    require(classic_sessions[0]->head->state_identity() == base.get() &&
        classic_sessions[1]->head->state_identity() == base.get(), "R2 sampler forks lost canonical model state");
    const std::array classic_ids{classic_sessions[0]->head->next_id, classic_sessions[1]->head->next_id};
    const std::array classic_inputs{q::EvaluationRequest{classic_sessions[0], std::span(&classic_ids[0], 1)},
        q::EvaluationRequest{classic_sessions[1], std::span(&classic_ids[1], 1)}};
    const std::array classic_outputs{q::EvaluationOutput{.session = classic_sessions[0], .name = "classic0", .trace_states = false},
        q::EvaluationOutput{.session = classic_sessions[1], .name = "classic1", .trace_states = false}};
    const std::array classic_selection{q::MtpGenerationSelection{classic_sessions[0], classic_ids[0], 2},
        q::MtpGenerationSelection{classic_sessions[1], classic_ids[1], 2}};
    std::array<q::MtpRoundResult, 2> classic_results;
    model.prepare_evaluations(classic_inputs, nullptr, q::GraphRole::kMtpRound); model.submit_evaluations();
    model.finish_mtp_rounds(classic_selection, {}, classic_outputs, classic_results);scratch.check(model);reject_late_policy(model);scratch.report("A-natural-K2-R2");
    auto &phase = *model.phases.at({2, 2, q::GraphRole::kMtpRound});
    require(phase.sampling_valid.facts.description.data_type() == (model.execution.native_generated_storage() ? q::Type::kFloat32 : q::Type::kBool) &&
        phase.sampling_accept.facts.description.data_type() == (model.execution.native_generated_storage() ? q::Type::kFloat32 : q::Type::kBool),
        "classic R2 predicate readback facts differ");
    require(q::take(phase.sampling_valid.facts.description.required_bytes()) == 2 * sizeof(float) &&
        q::take(phase.sampling_accept.facts.description.required_bytes()) == 2 * sizeof(float) &&
        q::take(phase.draft_id.facts.description.required_bytes()) == 2 * sizeof(std::int32_t) &&
        q::take(phase.next_id.facts.description.required_bytes()) == 4 * sizeof(std::int32_t),
        "classic R2 scalar-array output extents differ");
    for (std::size_t n = 0; n < classic_sessions.size(); ++n) {
      require(classic_sessions[n]->head->sampling == q::cache::SamplingCursor{123, n, 4},
          "classic R2 mixed independent request sampling cursors");
      require(classic_results[n].processed_target >= 1 && classic_results[n].processed_target <= 2 &&
          classic_sessions[n]->head->length == base->length + classic_results[n].processed_target &&
          classic_sessions[n]->head->next_id == classic_results[n].next_id,
          "classic R2 selected pending/complete state differs");
      model.validate_mtp_snapshot(*classic_sessions[n]->head);
    }
    require(base->sampling.draw == 1, "classic R2 advanced old checkpoint RNG");
    std::cout << "{\"status\":\"PASS_TINY_PHASE_READBACK\",\"backend\":\"" << model.execution.name()
        << "\",\"fixture_bytes\":" << fixture.second << ",\"head_true_calls\":2,\"head_false_calls\":1"
        << ",\"id_caller_owned\":" << id_caller << ",\"valid_caller_owned\":" << valid_caller
        << ",\"probability_caller_owned\":" << probability_caller << ",\"proposals\":[" << ids[1] << ',' << ids[2]
        << "],\"consumed\":" << result.processed_target << ",\"pending\":" << session->head->next_id
        << ",\"cursor\":" << session->head->sampling.draw << ",\"draft_lag\":" << session->head->draft->lag
        << ",\"classic_R2\":true,\"classic_cursors\":[" << classic_sessions[0]->head->sampling.draw
        << ',' << classic_sessions[1]->head->sampling.draw << "],\"classic_pending\":["
        << classic_sessions[0]->head->next_id << ',' << classic_sessions[1]->head->next_id
        << "],\"classic_consumed\":[" << classic_results[0].processed_target << ',' << classic_results[1].processed_target
        << "],\"classic_valid_caller_owned\":" << phase.sampling_valid.facts.caller_owned()
        << ",\"classic_accept_caller_owned\":" << phase.sampling_accept.facts.caller_owned()
        << ",\"classic_draft_ids_caller_owned\":" << phase.draft_id.facts.caller_owned()
        << ",\"classic_next_ids_caller_owned\":" << phase.next_id.facts.caller_owned()
        << model.cache_report() << ",\"quality_claim\":false,\"performance_claim\":false}\n";
    log_q.clear(); base.reset();
    for (auto &classic : classic_sessions) {
      q::check(classic->stop()); q::check(classic->drain());
      require(q::take(classic->try_retire()), "classic R2 session did not retire"); classic.reset();
    }
    q::check(session->stop()); q::check(session->drain());
    require(q::take(session->try_retire()), "tiny original session did not retire"); session.reset();
    require(!model.active_step && !model.carrier_borrowed && model.snapshot_versions.live == 0,
        "tiny journey retained an uncommitted carrier or model state");
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "tiny draft readback: " << error.what() << '\n'; return 1;
  }
}

}

int main(int argc,char** argv) {
  if(argc!=4){std::cerr<<"round-regression GA_FIXTURE GA_STATE A_WORKDIR\n";return 1;}
  char* ga_args[]{argv[0],argv[1],argv[2]};if(ga_check(3,ga_args)!=0)return 1;
  char* a_args[]{argv[0],argv[3]};return a_probe::run(2,a_args);
}
