"""Collect the finite result plus the preserved first strict compile failure."""
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
old=D/'source/engine/models/qwen35/main.cc';new=D/'attempt2/source/engine/models/qwen35/main.cc'
before=old.read_bytes();after=new.read_bytes()
if before.replace(b'phase.requests > 1',b'phase.family->requests > 1')!=after:raise ValueError('First compile correction was not exactly the inspected real Family request count')
success=read(D/'attempt2/summary.json')
rows=success['reports'];scratch=[r for r in rows if 'scratch'in r]
result=dict(state='passed',scope=success['scope'],source=pin(new),probe=pin(D/'attempt2/source/regression.cc'),image=success['image'],
    successful_attempt=pin(D/'attempt2/summary.json'),first_failure=read(D/'first-failure.json'),
    first_failure_preserved=True,correction='Exactly Phase.requests -> Phase.family->requests; no fixture, mathematics or invariant relaxation.',
    successful_strict_compile=read(D/'attempt2/compile/process.json'),link=read(D/'attempt2/link/process.json'),actual_run=read(D/'attempt2/run/process.json'),
    actual_state_files=35,all_original_GA_state_bytes_equal=True,
    GA=dict(ordinary_ids=[36,8],real_proposal_input=[36,62,39],real_target_candidates=[2,25,39],forced_consumed=2,selected_state_row=1,pending=25,RNG=6,head_false_repair=True,old_checkpoints_unchanged=True,natural_acceptance_claim=False,
        extra_catchup='Same current GA model consumes the pending token once: length4 ->5, RNG6 ->7, draft lag1 ->0; original35 dumps remain before this additional episode.'),
    A=dict(actual_natural_K2=True,proposals=[31,39],consumed=1,pending=42,RNG=6,classic_R2=True,independent_classic_RNG=[4,4],classic_pending=[39,2],classic_consumed=[1,1],all_sampling_baseline_fields_equal=success['A_mathematical_fields_equal']),
    input_scratch=dict(vector_order=['packed_ids','positions','draft_positions','catchups','sampling_identities'],observations=scratch,total_postepisode_observations=sum(r['checks']for r in scratch),scope=success['scratch_scope']),
    configuration=dict(compiled_const_fields=['sampler','cpu_ffn_layers','cache_plan','capacity','replay_policy'],actual_late_modification_rejections=6,preserves='DraftPolicy getters, family/phase/draft maps, live version count, active episode pointer, original GA checkpoint bytes; actual subsequent ordinary/MTP episodes still pass.'),
    distinct_private_TUs=1,strict_compile_attempts=2,successful_compiles=1,links=1,actual_processes=1,private_models=3,complete_models=0,SDK_builds=0,HTTP=0,quality_claim=False,performance_claim=False)
save(D/'summary.json',result)
with zipfile.ZipFile(D/'logs.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
    for name in ['prepare.py','check.py','finalize.py','regression.cc','summary.json','first-failure.json','source-pins.json','baseline-pins.json']:
        p=D/name;z.write(p,p.relative_to(D).as_posix())
    z.write(old,old.relative_to(D).as_posix())
    for folder in [D/'compile',D/'attempt2']:
        for p in folder.rglob('*'):
            if p.is_file()and p.suffix.lower()in{'.cc','.h','.py','.json','.log','.bf16','.f32','.txt','.tsv','.bin'}:z.write(p,p.relative_to(D).as_posix())
print(json.dumps(dict(summary=pin(D/'summary.json'),archive=pin(D/'logs.zip'))))
