"""Prepare one finite combined GA + natural A consumer; no build or run."""
from pathlib import Path
import json

D=Path(__file__).resolve().parent; R=D.parents[2]
GA=R/'.scratch/mtp-state-ports-20261024/gdn-regression/gdn2'
A=R/'.scratch/mtp-runtime-backend-20261024/verification1'
def replace(text,old,new):
    if text.count(old)!=1: raise ValueError('Unexpected existing fixture source: '+old[:100])
    return text.replace(old,new)

instrument=r'''
static_assert(std::is_const_v<decltype(std::declval<q::Model>().sampler)>);
static_assert(std::is_const_v<decltype(std::declval<q::Model>().cpu_ffn_layers)>);
static_assert(std::is_const_v<decltype(std::declval<q::Model>().cache_plan)>);
static_assert(std::is_const_v<decltype(std::declval<q::Model>().capacity)>);
static_assert(std::is_const_v<decltype(std::declval<q::Model>().replay_policy)>);
struct ScratchObservation final {
  struct Entry { std::size_t capacity; const void* address; };
  std::array<Entry,5> entries;
  std::array<std::size_t,5> maximum_sizes{};
  std::size_t checks=0;
  static auto facts(const q::Model& model) {
    const auto& s=model.input_scratch;
    return std::array<Entry,5>{{{s.packed_ids.capacity(),s.packed_ids.data()},
      {s.positions.capacity(),s.positions.data()}, {s.draft_positions.capacity(),s.draft_positions.data()},
      {s.catchups.capacity(),s.catchups.data()}, {s.sampling_identities.capacity(),s.sampling_identities.data()}}};
  }
  explicit ScratchObservation(const q::Model& model):entries(facts(model)){}
  void check(const q::Model& model) {
    const auto now=facts(model); const auto& s=model.input_scratch;
    const std::array sizes{s.packed_ids.size(),s.positions.size(),s.draft_positions.size(),s.catchups.size(),s.sampling_identities.size()};
    for(std::size_t i=0;i<5;++i) {
      require(now[i].capacity==entries[i].capacity && now[i].address==entries[i].address,
        "prepared input scratch changed capacity or backing address in actual hot episode");
      maximum_sizes[i]=(std::max)(maximum_sizes[i],sizes[i]);
    }
    ++checks;
  }
  void report(const char* label) const {
    std::cout<<"{\"scratch\":\""<<label<<"\",\"checks\":"<<checks<<",\"capacity\":[";
    for(std::size_t i=0;i<5;++i)std::cout<<(i?",":"")<<entries[i].capacity;
    std::cout<<"],\"maximum_observed_size\":[";
    for(std::size_t i=0;i<5;++i)std::cout<<(i?",":"")<<maximum_sizes[i];
    std::cout<<"],\"capacity_and_address_stable\":true,\"whole_path_zero_allocation_claim\":false}\n";
  }
};
void reject_late_policy(q::Model& model) {
  const auto maximum=model.max_drafts(); const auto probability=model.min_draft_probability();
  const auto family_count=model.families.size(),phase_count=model.phases.size(),draft_count=model.draft_programs.size();
  const auto versions=model.snapshot_versions.live; const auto active=model.active_step.get();
  bool rejected=false;
  try {model.configure_draft_policy({.max_drafts=maximum==0?1u:0u,.minimum_probability=0.F});}
  catch(const std::runtime_error&) {rejected=true;}
  require(rejected,"late DraftPolicy modification was accepted after cold preparation");
  require(model.max_drafts()==maximum && model.min_draft_probability()==probability &&
    model.families.size()==family_count && model.phases.size()==phase_count &&
    model.draft_programs.size()==draft_count && model.snapshot_versions.live==versions &&
    model.active_step.get()==active,"late DraftPolicy rejection modified original model state or graph inventory");
}
'''

def prepare():
    ga=(GA/'gdn.cc').read_text(encoding='utf8')
    ga=replace(ga,'int main(int argc,char** argv) {','int ga_check(int argc,char** argv) {')
    ga=replace(ga,'using Image=std::map<std::string,Bytes>;',instrument+'\nusing Image=std::map<std::string,Bytes>;')
    ga=replace(ga,'auto session=model.create_session(chunks);const std::array<std::int32_t,2> prompt{1,2};',
      'auto session=model.create_session(chunks);model.prepare_execution(chunks);ScratchObservation scratch(model);reject_late_policy(model);const std::array<std::int32_t,2> prompt{1,2};')
    ga=replace(ga,'ordinary_first=model.finish_evaluation(*session,"ordinary-P2",{},false);check_prefix(model,*session->head,expected[0]);',
      'ordinary_first=model.finish_evaluation(*session,"ordinary-P2",{},false);scratch.check(model);check_prefix(model,*session->head,expected[0]);')
    ga=replace(ga,'ordinary_next=model.finish_evaluation(*session,"ordinary-T1",{},false);check_prefix(model,*session->head,expected[0]);',
      'ordinary_next=model.finish_evaluation(*session,"ordinary-T1",{},false);scratch.check(model);check_prefix(model,*session->head,expected[0]);')
    ga=replace(ga,'expected.clear();base.reset();retire(session);require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"ordinary resources remain admitted");',
      'require(saved==image(model,*base),"ordinary state changed before late-policy rejection");reject_late_policy(model);require(saved==image(model,*base),"late-policy failure changed ordinary original checkpoint");scratch.report("GA-ordinary");expected.clear();base.reset();retire(session);require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"ordinary resources remain admitted");')
    ga=replace(ga,'model.max_drafts=2;const std::array p2{std::size_t{2}},t3{std::size_t{3}};',
      'model.configure_draft_policy({.max_drafts=2});const std::array p2{std::size_t{2}},t3{std::size_t{3}},single{std::size_t{1}};')
    ga=replace(ga,'for(std::size_t rows=1;rows<=3;++rows)model.prepare_draft_program(rows,false);\n      model.prepare_draft_program(1,true);model.prepare_draft_program(2,true);',
      'model.prepare_family(single,false,1,q::GraphRole::kMtpCatchupSingle);model.plan_replay_uses(1,1,1,q::GraphRole::kMtpCatchupSingle);\n      model.prepare_recursive_round_programs();')
    ga=replace(ga,'auto session=model.create_session(p2,{},q::GraphRole::kMtpPrefill);const std::array<std::int32_t,2> prompt{1,2};',
      'auto session=model.create_session(p2,{},q::GraphRole::kMtpPrefill);model.prepare_execution(p2,1,q::GraphRole::kMtpPrefill);model.prepare_execution(t3,1,q::GraphRole::kVerify);model.prepare_execution(single,1,q::GraphRole::kMtpCatchupSingle);ScratchObservation scratch(model);reject_late_policy(model);const std::array<std::int32_t,2> prompt{1,2};')
    ga=replace(ga,'model.finish_evaluation(*session,"mtp-P2",{},false);check_prefix',
      'model.finish_evaluation(*session,"mtp-P2",{},false);scratch.check(model);check_prefix')
    ga=replace(ga,'require(proposals.size()==3&&qrows.size()==2&&model.draft_program_graph_calls==2,"real two recursive proposals missing");',
      'require(proposals.size()==3&&qrows.size()==2&&model.draft_program_graph_calls==2,"real two recursive proposals missing");scratch.check(model);')
    ga=replace(ga,'mtp_pending=next[0];check_prefix', 'scratch.check(model);mtp_pending=next[0];check_prefix')
    ga=replace(ga,'expected.clear();qrows.clear();base.reset();retire(session);require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"MTP resources remain admitted");',
      'expected.clear();qrows.clear();reject_late_policy(model);require(saved==image(model,*base),"late-policy failure changed MTP original checkpoint");\n'
      '      auto before_catchup=session->head;const std::array catchup_ids{before_catchup->next_id};model.prepare_evaluation(*session,catchup_ids,nullptr,q::GraphRole::kMtpCatchupSingle);model.submit_evaluation(*session);model.finish_evaluation(*session,"catchup-single",{},false);scratch.check(model);\n'
      '      require(session->head->length==before_catchup->length+1&&session->head->sampling.draw==before_catchup->sampling.draw+1&&session->head->draft->lag==0,"actual pending catchup state differs");model.validate_mtp_snapshot(*session->head);require(saved==image(model,*base),"pending catchup changed old Snapshot");scratch.report("GA-MTP-catchup");before_catchup.reset();base.reset();retire(session);require(model.snapshot_versions.live==0&&!model.active_step&&!model.carrier_borrowed,"MTP resources remain admitted");')
    # Shared observations run against the same original mathematics and real prepared extents.
    a=(A/'source/tiny.cc').read_text(encoding='utf8')
    a=replace(a,'#include "engine/models/qwen35/main.cc"','')
    a=replace(a,'int main(int argc, char **argv) {','int run(int argc, char **argv) {')
    a=replace(a,'model.max_drafts = 2; model.min_draft_probability = 1.e-4F;',
      'model.configure_draft_policy({.max_drafts=2,.minimum_probability=1.e-4F});')
    a=replace(a,'model.prepare_draft_program(1, true); model.prepare_draft_program(2, true);\n    model.prepare_prefix_sampling(2);',
      'model.prepare_draft_program(1, true); model.prepare_draft_program(2, true);\n    model.prepare_prefix_sampling(2);')
    a=replace(a,'const std::array<std::int32_t, 2> prompt{1, 2};',
      'model.prepare_execution(prefill,1,q::GraphRole::kMtpPrefill);model.prepare_execution(verifier,1,q::GraphRole::kVerify);model.prepare_execution(prefill,2,q::GraphRole::kMtpRound);ScratchObservation scratch(model);reject_late_policy(model);\n    const std::array<std::int32_t, 2> prompt{1, 2};')
    a=replace(a,'model.finish_evaluation(*session, "seed", {}, false);',
      'model.finish_evaluation(*session, "seed", {}, false);scratch.check(model);')
    a=replace(a,'auto ids = model.propose_recursive(*session, 2, {}, &log_q);',
      'auto ids = model.propose_recursive(*session, 2, {}, &log_q);scratch.check(model);')
    a=replace(a,'model.finish_recursive_mtp(selections, {}, outputs, results);',
      'model.finish_recursive_mtp(selections, {}, outputs, results);scratch.check(model);')
    a=replace(a,'model.finish_mtp_rounds(classic_selection, {}, classic_outputs, classic_results);',
      'model.finish_mtp_rounds(classic_selection, {}, classic_outputs, classic_results);scratch.check(model);reject_late_policy(model);scratch.report("A-natural-K2-R2");')
    tail=r'''
int main(int argc,char** argv) {
  if(argc!=4){std::cerr<<"round-regression GA_FIXTURE GA_STATE A_WORKDIR\n";return 1;}
  char* ga_args[]{argv[0],argv[1],argv[2]};if(ga_check(3,ga_args)!=0)return 1;
  char* a_args[]{argv[0],argv[3]};return a_probe::run(2,a_args);
}
'''
    result=ga+'\nnamespace a_probe {\n'+a+'\n}\n'+tail
    target=D/'regression.cc'
    with target.open('x',encoding='utf8',newline='\n')as out:out.write(result)
    print(json.dumps(dict(prepared=str(target),original_GA=str(GA/'gdn.cc'),original_A=str(A/'source/tiny.cc'),compiled=False,run=False)))

if __name__=='__main__':prepare()
