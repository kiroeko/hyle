"""One current private TU/image; compare retained GA state and natural A results."""
from pathlib import Path
import importlib.util,json,os,shutil,sys,zipfile
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
TEMPLATE=D
if len(sys.argv)>2:
    if not sys.argv[2].isalnum():raise ValueError('Private attempt must be alphanumeric')
    D=D/sys.argv[2]
GA=R/'.scratch/mtp-state-ports-20261024/gdn-regression/gdn2'
A=R/'.scratch/mtp-runtime-backend-20261024/verification1'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def require(ok,message):
    if not ok:raise ValueError(message)
def freeze():
    target=D/'source';target.mkdir(parents=True,exist_ok=False);records=[]
    if D!=TEMPLATE:shutil.copyfile(TEMPLATE/'regression.cc',D/'regression.cc')
    sources=[R/'engine/models/qwen35/main.cc',*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h')]
    for p in sources:
        out=target/p.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
        records.append(dict(original=b.pin(p),frozen=b.pin(out)))
    shutil.copyfile(D/'regression.cc',target/'regression.cc')
    records.append(dict(original=b.pin(D/'regression.cc'),frozen=b.pin(target/'regression.cc')))
    b.save(D/'source-pins.json',records)
    b.save(D/'baseline-pins.json',dict(GA_summary=b.pin(GA/'summary-final.json'),GA_fixture=[b.pin(p)for p in(GA/'shared-fixture').glob('*')],GA_state=[b.pin(p)for p in(GA/'current/state').rglob('*')if p.is_file()],A_report=b.pin(A/'tiny-run/stdout.log'),A_source=b.pin(A/'source/tiny.cc'),GA_source=b.pin(GA/'gdn.cc')))
def compile():
    target=D/'source';folder=D/'compile';original=b.args(GA/'current/compile/command.json')
    command=[original[0],'/I'+str(target)];skip=False
    for word in original[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        lower=word.lower().replace('\\','/')
        if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
        if lower.startswith('/i')and '/.scratch/'in lower and lower.endswith('/source'):continue
        command.append(word)
    command+=['/sourceDependencies',str(folder/'dependencies.json'),str(target/'regression.cc'),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    env=b.environment(command[0]);b.execute(command,folder,env,180)
    deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    leaks=[str(p)for p in deps if p.is_relative_to(R/'engine')or(p.is_relative_to(R/'.scratch')and not p.is_relative_to(target))]
    require(not leaks,'Frozen engine source leaked: '+repr(leaks))
    b.save(folder/'self-header-pins.json',[b.pin(p)for p in deps if p.is_relative_to(R)])
    prior={x['path'].lower():x for x in b.read(GA/'current/compile/self-header-pins.json')if Path(x['path']).is_relative_to(R/'include')}
    now={x['path'].lower():x for x in b.read(folder/'self-header-pins.json')if Path(x['path']).is_relative_to(R/'include')}
    require(all(k in prior and all(now[k][f]==prior[k][f]for f in['bytes','sha256'])for k in now),'Public ABI header changed from retained closure; inspect before link')
    previous=b.args(GA/'current/link/command.json');out=D/'link';old=str(GA/'current/compile/unit.obj')
    require(previous.count(old)==1,'Wrong retained app object')
    link=[str(folder/'unit.obj')if word==old else word for word in previous if not word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
    link+=['/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb')];b.execute(link,out,env,120)
    for dll in(GA/'current/link').glob('*.dll'):os.link(dll,out/dll.name)
    b.save(out/'pins.json',dict(image=b.pin(out/'probe.exe'),object=b.pin(folder/'unit.obj'),retained_closure=b.pin(GA/'current/link/command.json'),native=[b.pin(p)for p in out.glob('*.dll')],SDK_builds=0))
def run():
    runtime=b.read(b.VK/'runtime.json');env=b.environment(b.args(D/'compile/command.json')[0]);env.update({k:v for k,v in runtime.items()if isinstance(v,str)})
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1');env['PATH']=str(D/'link')+';'+env['PATH']
    for row in b.read(D/'baseline-pins.json')['GA_fixture']:
        actual=b.pin(Path(row['path']));require(all(actual[k]==row[k]for k in['bytes','sha256']),'GA fixture changed')
    b.execute([str(D/'link/probe.exe'),str(GA/'shared-fixture'),str(D/'state'),str(D/'A-work')],D/'run',env,60)
    audit()
def audit():
    result=b.read(D/'run/process.json');require(result['exit']==0 and not result['timeout'],'Actual process did not pass')
    rows=[json.loads(line)for line in(D/'run/stdout.log').read_text().splitlines()if line.startswith('{')]
    states={p.relative_to(D/'state').as_posix():b.pin(p)for p in(D/'state').rglob('*')if p.is_file()}
    prior={p.relative_to(GA/'current/state').as_posix():b.pin(p)for p in(GA/'current/state').rglob('*')if p.is_file()}
    require(states.keys()==prior.keys()and len(states)==35,'Original 35 GA state inventory differs')
    differences=[name for name in states if any(states[name][k]!=prior[name][k]for k in['bytes','sha256'])]
    require(not differences,'Original GA bytes changed: '+repr(differences))
    old_ga=json.loads((GA/'current/run/stdout.log').read_text().strip());ga=[r for r in rows if r.get('state')=='passed']
    require(len(ga)==1,'GA report missing')
    for key in old_ga:
        if key not in{'ordinary_cache_peak','mtp_cache_peak'}:require(ga[0].get(key)==old_ga[key],'GA mathematical report changed: '+key)
    old_a=json.loads((A/'tiny-run/stdout.log').read_text().strip());a=[r for r in rows if r.get('status')=='PASS_TINY_PHASE_READBACK']
    require(len(a)==1,'A natural K2/R2 report missing')
    keys=['proposals','consumed','pending','cursor','draft_lag','classic_cursors','classic_pending','classic_consumed','head_true_calls','head_false_calls','draft_program_graph_calls','prefix_decision_graph_calls','frontier_sampling_graph_calls']
    for key in keys:require(a[0].get(key)==old_a.get(key),'A natural sampling/RNG changed: '+key)
    scratch=[r for r in rows if 'scratch'in r]
    require(len(scratch)==3 and all(r['capacity_and_address_stable']and r['checks']>=2 for r in scratch),'Actual scratch stability observations missing')
    require(any(r['maximum_observed_size'][0]>0 for r in scratch),'Packed B2 input was not observed')
    require(any(r['maximum_observed_size'][3]>0 for r in scratch),'Actual catchup upload scratch was not observed')
    require(any(r['maximum_observed_size'][4]>=8 for r in scratch),'Independent R2 sampling identities were not observed')
    summary=dict(state='passed',scope='One current TU/image, GA ordinary P2/T1 and actual proposal/T3 consumed2 control plus pending catchup; A natural random K2 and classic B2/R2 Phase switch.',GA_state_files=states,all_35_GA_state_bytes_equal=True,GA_baseline=b.pin(GA/'summary-final.json'),A_mathematical_fields_equal=keys,reports=rows,scratch_scope='Observed five dedicated input vectors only; no whole-path zero-allocation claim.',late_policy='Real DraftPolicy modification rejected before/after actual episodes; policy, graph inventories, version count, active pointer and original GA checkpoint unchanged.',compiled_private_TUs=1,actual_processes=1,private_models=3,SDK_builds=0,HTTP=0,quality_claim=False,performance_claim=False,commands=dict(compile=b.pin(D/'compile/command.json'),link=b.pin(D/'link/command.json'),run=b.pin(D/'run/command.json')),image=b.pin(D/'link/probe.exe'))
    b.save(D/'summary.json',summary)
    with zipfile.ZipFile(D/'logs.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
        for p in D.rglob('*'):
            if p.is_file()and p.suffix.lower()in{'.cc','.h','.py','.json','.log','.bf16','.f32','.txt','.tsv','.bin'}:
                z.write(p,p.relative_to(D).as_posix())
    print(json.dumps(dict(state='passed',summary=b.pin(D/'summary.json'),archive=b.pin(D/'logs.zip'))),flush=True)
if __name__=='__main__':
    {'freeze':freeze,'compile':compile,'run':run,'audit':audit}[sys.argv[1]]()
