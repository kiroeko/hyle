# LoadedWeight 边界复核

只读 main 3e4769564eb250c1d74f1b48abfb5efcd51683ad36a37f3ead1c26652ce435c9；无新增产品改动、编译、运行或下载。

## Recipe 保留 loaded bank 合理
- Recipe::bank/main.cc:551 只在 weight_absolute :602–605 查找一次原角色，并将其 tensor 子对象交 operand；不读取 codec/group。
- embedding :615 使用该原 Tensor 的真实 storage_format 选择 checked Gather；未展开共享词表。
- norm_absolute :848 与 decay :857 读取原 norm/decay 角色，按独立 WeightMeanings 实施 HF delta/gamma、negative-exp 等模型数学。
- target GDN 建图 :2374/:2382 还需原 conv1d.weight、dt_bias；它们并非二维 linear projection，不能硬塞进 ProjectionBinding variant。
- 这些 lookup 仅发生在冷建图。运行请求、Invocation、状态捕获与 prefix 缓存不进行 weight bank 查找。
- 因而不需要再建通用 ParameterRegistry/WeightId、第二角色表或虚 resolver。强迫所有原角色成为“投影”会增加错误语义和维护面。

## 直接用户已覆盖
- 对 engine/ 与 tests/ 的 .cc/.h 检索 LoadedWeight、resolve_projection、prepare_projection_bindings、Recipe、原 Tensor bank、codec/group 字段；未扫描 .scratch。
- 改动后的 bank 类型声明/解析均在 main.cc 与 projection_binding.h；外部唯一直接自建 bank 用户为 tests/tools/qwen_mtp_projection_width_probe.cc 的两个组件，两处均已迁移。
- probe 的原 negative missing-input-scale 检查仍在 bindings 建立前 erase/reinsert；不会让有效绑定指向被移出的节点。
- mtp_session/retained_budget/retirement probes 只读取 model.weights.size()，未依赖 mapped value 或旧 codec 字段，无需改动。
- qwen_mtp_prefix_value_probe 等继续用 vector<Tensor> 保留普通结果，这是正确的无制品资源用途。
- fp8_weight_import.h、prepared_roles.h 和 qwen_prepared_roles_test 的 projection_codec/group_size 属于 prepared::Role，并非旧 Tensor 字段；应继续保留。
- 未发现其它 canonical 直接用户遗漏或旧 Tensor bank/字段兼容 alias。

## 本批职责与寿命
- LoadedWeight 是模型私有唯一物理权重节点：一个 Tensor 加源 reader 的 codec/group；没有第二 metadata map 或 descriptor/payload 副本。
- Tensor 仅持真实 TensorDesc、Buffer、ReadLease。storage_format 所声明的 GGUF/FP8 carrier 物理编码仍原样保留。
- ProjectionBinding 仅冷借 Tensor 子对象与原 typed Equation/params；同一数据派生逻辑形状、score_policy 和数学 emitter，未保存另一套 precision/backend policy。
- GraphAssembly 负责实际 Backend freeze/StorageOwner/retained lease、literal 分配及 typed placement/external contracts；数学仅借 assembly，不选择 Queue/Provider。
- 绑定在加载完成后建立；std::map 节点稳定，ColdResources 仍先销 projections 后销 weights，原 Backend/controller 保活与异常退出顺序不变。
- 不允许有效绑定存活时 erase/replace 其 LoadedWeight；这与旧 bank 合同相同，不新增可变 reload 能力。

## 有限扩展判定
- 同家族新 codec 的必要改动可限于源角色认证、冷 resolver/typed binding 和实际新数学 emitter；无需再给 Tensor、Phase/KV、请求/批次进度或 Backend 增格式字段。
- 新模型仍应声明真实 geometry/参数名/target-draft 数学及完整状态适配；不要求复用 Qwen LoadedWeight/Tensor/Snapshot 外形。
- 现 Backend 冷端点/域/队列、Graph/Compute typed operators 与 placement、PreparedOutputFacts/readback、RetainedResources、公共接受规则及 StateDraft/StateHead 已提供足够原语。
- main 无平台条件编译宏；Model 的 compile/queue/readback 是实际冷准备与原执行边界，未被重新塞回 Recipe 方程。
- 本批不需要新通用 loader registry、executor、发布器或端口表；也不代表完整跨模型编排或所有新格式已自动支持。
- 运行与严格编译结论由主代理的有限回归记录给出，本复核不替代或扩大其覆盖。

结论：当前权重/数学/冷资源边界无已确认阻断项；保留 Recipe 的冷原角色查找，不继续泛化。
