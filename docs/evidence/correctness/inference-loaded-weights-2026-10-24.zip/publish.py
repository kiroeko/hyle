from pathlib import Path
import hashlib, json, zipfile
R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
def pin(p):
    return dict(path=p.relative_to(R).as_posix(), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p): return json.loads(p.read_text(encoding='utf8'))
out = R / 'docs/evidence/correctness/inference-loaded-weights-2026-10-24.json'
archive = out.with_suffix('.zip')
assert not out.exists() and not archive.exists()
summary = read(D / 'regression/proof-summary.json')
assert summary['state'] == 'passed' and not summary['differences']
assert read(D / 'probe-syntax/process.json')['exit'] == 0
sources = read(D / 'after-pins.json')
for item in sources:
    current = pin(R / item['path'])
    assert current == item
files = [D / name for name in ['source-only.json', 'review.md', 'changes.patch',
    'after-pins.json', 'before/source-pins.json', 'regression/check.py',
    'regression/proof.zip', 'regression/proof-summary.json',
    'regression/proof-pins.json', 'regression/cleanup-candidates.json',
    'probe-syntax/command.json', 'probe-syntax/process.json',
    'probe-syntax/stdout.log', 'probe-syntax/stderr.log', 'publish.py']]
files += sorted((D / 'before/source').rglob('*'))
files = [p for p in files if p.is_file()]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files: z.write(p, p.relative_to(D).as_posix())
proof = dict(state='passed', date='2026-10-24',
    scope='LoadedWeight uniquely owns original Tensor plus source codec/group annotations; generic activation/state/literal Tensor has no source metadata. No new format, model or backend capability.',
    changes=['Stable loaded map nodes preserve Tensor child addresses borrowed by typed projection bindings.',
        'Physical TensorDesc/storage_format, source-role identity, pools, ready leases, graph equations and precision remain unchanged.',
        'The two Backend freeze calls remain at their original loader/GraphAssembly positions.',
        'The only direct external custom-bank probe now uses the same explicit LoadedWeight node.'],
    sources=sources, source_assertions=read(D / 'source-only.json'),
    source_review=pin(D / 'review.md'),
    actual=dict(consumer_TUs=1, reporting_TUs=1,
        strict_CPU_probe_syntax_TUs=1, actual_processes=1, old_runs=0,
        SDK_builds=0, HTTP=0, full_models=0, report_count=summary['report_count'],
        report_differences=summary['differences'], added_report_fields=summary['added_report_fields'],
        grouping=summary['request_groups']['counts'],
        late_IO_failures=summary['late_IO_failures_observed'],
        process={k:summary[k] for k in ['compile','reporting_compile','link','run']},
        summary=pin(D / 'regression/proof-summary.json')),
    limits=['The actual run uses the retained tiny A-only fixture and existing ordinary/MTP/multi-turn/N2-R2/cache/recovery/fixed-replay contracts.',
        'Packed codecs were source-reviewed and the direct packed/dense projection probe strictly compiled; no new packed-codec math run.',
        'No new GDN, mixed-platform, full-model quality, allocator-volume, throughput or memory-peak claim.'],
    cleanup=dict(exact_files=6,logical_bytes=83422872,contains_one_private_DLL_hardlink=True,
        original_cache_and_native_closure_retained=True,performed=False),
    archive=pin(archive))
out.write_text(json.dumps(proof, indent=2, ensure_ascii=False)+'\n', encoding='utf8')
print(json.dumps(dict(evidence=pin(out),archive=pin(archive))))
