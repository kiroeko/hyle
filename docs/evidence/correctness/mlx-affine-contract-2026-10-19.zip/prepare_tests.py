"""Freeze an existing Apple test owner overlay; never apply/build/run it."""
from pathlib import Path
import difflib
import hashlib
import json

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[2]
TARGET = 'tests/compute_route_apple/mlx_quantized_test.cc'
FRAGMENT = r'''

namespace {
namespace apple_affine_contract_test {
using namespace apple_tensor_test;

// Every quantity in this witness is exactly representable in F32. There are
// only two nonzero dot terms, so neither FMA nor a different F32 reduction tree
// can account for the -1 versus -2 distinction.
void matmul_witness(mx::Dtype dtype, int rows) {
  constexpr int k = 128, n = 16, group = 64;
  constexpr std::uint32_t first_word = 0x21U;
  constexpr auto code0 = first_word & 15U;
  constexpr auto code1 = (first_word >> 4) & 15U;
  const double bias = dtype == mx::bfloat16 ? 256.0 : 2048.0;
  ASSERT_EQ(rounded(bias, dtype), bias);
  const double expected = rounded((double(code0) + bias) -
                                  (double(code1) + bias), dtype);
  const double narrowed = rounded(rounded(double(code0) + bias, dtype) -
                                  rounded(double(code1) + bias, dtype), dtype);
  ASSERT_EQ(expected, -1.0);
  ASSERT_EQ(narrowed, -2.0);

  std::vector<std::uint32_t> words(n * k / 8, 0U);
  for (int column = 0; column < n; ++column)
    words[column * (k / 8)] = first_word;
  std::vector<double> input(rows * k, 0.0);
  for (int row = 0; row < rows; ++row) {
    input[row * k] = 1.0;
    input[row * k + 1] = -1.0;
  }
  const std::vector<double> scales(n * k / group, 1.0);
  const std::vector<double> biases(scales.size(), bias);
  std::vector<mx::array> ports{
      ready(make(input, {rows, k}, dtype)),
      ready(mx::array(words.data(), {n, k / 8}, mx::uint32)),
      ready(make(scales, {n, k / group}, dtype)),
      ready(make(biases, {n, k / group}, dtype))};
  auto context = a::Context::create().value();
  auto result = execute(context,
      c::model_ops::mlx_quantized_matmul(
          c::model_ops::MlxWeightFormat::kAffine4, group), ports);
  ASSERT_TRUE(result) << result.error().message();
  EXPECT_EQ(result->dtype(), dtype);
  EXPECT_EQ(result->shape(), (mx::Shape{rows, n}));
  const auto actual = values(*result);
  ASSERT_EQ(actual.size(), static_cast<std::size_t>(rows * n));
  EXPECT_EQ(actual, std::vector<double>(actual.size(), expected))
      << "F32 affine decoded operands require -1; pre-narrowed decoded "
         "weights produce -2. M1 is the source-qualified QMV control and "
         "M64 is the source-qualified split-K QMM case.";
}

// An embedding returns decoded values in the declared low dtype; it is not
// the F32 operand stream consumed by matmul. Multiplication by one is exact
// here, deliberately avoiding a claim about general mul/add contraction.
void embedding_control(mx::Dtype dtype) {
  constexpr int k = 128, group = 64;
  const double bias = dtype == mx::bfloat16 ? 256.0 : 2048.0;
  std::vector<std::uint32_t> words(k / 8, 0U);
  words[0] = 0x21U;
  const std::vector<double> scales(k / group, 1.0);
  const std::vector<double> biases(k / group, bias);
  std::vector<mx::array> ports{
      ready(mx::array(words.data(), {1, k / 8}, mx::uint32)),
      ready(make(scales, {1, k / group}, dtype)),
      ready(make(biases, {1, k / group}, dtype)),
      ready(mx::array({std::int32_t{0}}, {1}))};
  std::vector<double> expected(k);
  for (int index = 0; index < k; ++index) {
    const auto code = (words[index / 8] >> (4 * (index % 8))) & 15U;
    expected[index] = rounded(rounded(double(code), dtype) + bias, dtype);
  }
  ASSERT_EQ(expected[0], bias);
  ASSERT_EQ(expected[1], bias + 2.0);
  ASSERT_NE(expected[0], 1.0 + bias);
  auto context = a::Context::create().value();
  auto result = execute(context, c::model_ops::mlx_quantized_embedding(group), ports);
  ASSERT_TRUE(result) << result.error().message();
  EXPECT_EQ(result->dtype(), dtype);
  EXPECT_EQ(result->shape(), (mx::Shape{1, k}));
  EXPECT_EQ(values(*result), expected);
}
} // namespace apple_affine_contract_test

TEST(AppleMlxQuantized, AffineMatmulKeepsF32DecodedOperandsAcrossQmvAndQmm) {
  RecordProperty("contract", "F32 affine decode/dot, declared low output; no artifact-quality claim");
  for (const auto dtype : {mlx::core::bfloat16, mlx::core::float16})
    for (const int rows : {1, 64}) {
      SCOPED_TRACE(::testing::Message() << "dtype=" << dtype << " M=" << rows);
      apple_affine_contract_test::matmul_witness(dtype, rows);
    }
}

TEST(AppleMlxQuantized, AffineEmbeddingKeepsItsOwnDeclaredTypedOutput) {
  RecordProperty("contract", "Typed decoded embedding output; exact multiply control only");
  for (const auto dtype : {mlx::core::bfloat16, mlx::core::float16}) {
    SCOPED_TRACE(::testing::Message() << "dtype=" << dtype);
    apple_affine_contract_test::embedding_control(dtype);
  }
}
} // namespace
'''


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    before = (ROOT / TARGET).read_bytes()
    after = before + FRAGMENT.encode('utf-8')
    for directory, data in (('before', before), ('test-overlay', after)):
        path = STAGE / directory / TARGET
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    diff = ''.join(difflib.unified_diff(before.decode('utf-8').splitlines(True),
        after.decode('utf-8').splitlines(True), fromfile='a/' + TARGET, tofile='b/' + TARGET))
    (STAGE / 'tests.diff').write_text(diff, encoding='utf-8', newline='\n')
    freeze = dict(state='Scratch-only overlay; not applied, compiled or executed.',
        files=[dict(target=TARGET, before=identity(STAGE / 'before' / TARGET),
                    after=identity(STAGE / 'test-overlay' / TARGET))],
        diff=identity(STAGE / 'tests.diff'),
        tests=['AppleMlxQuantized.AffineMatmulKeepsF32DecodedOperandsAcrossQmvAndQmm',
               'AppleMlxQuantized.AffineEmbeddingKeepsItsOwnDeclaredTypedOutput'],
        CMake_change=False, shared_helper_change=False, product_source_change=False)
    (STAGE / 'tests-source-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(identity(STAGE / 'tests-source-freeze.json')))


if __name__ == '__main__':
    main()
