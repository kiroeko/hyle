"""Independent scalar IEEE oracle; no MLX, tensor backend or GPU import."""
import hashlib
import json
from pathlib import Path
import struct


def f32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]


def f16(value):
    return struct.unpack('<e', struct.pack('<e', value))[0]


def bf16(value):
    bits = struct.unpack('<I', struct.pack('<f', value))[0]
    bits = (bits + 0x7fff + ((bits >> 16) & 1)) & 0xffffffff
    return struct.unpack('<f', struct.pack('<I', bits & 0xffff0000))[0]


def main():
    records = []
    for name, narrow, bias in (('bf16', bf16, 256.0), ('f16', f16, 2048.0)):
        words = [0x21] + [0] * 15
        activation = [1.0, -1.0] + [0.0] * 126
        decoded, typed = [], []
        wide_dot = early_dot = 0.0
        for column, x in enumerate(activation):
            code = (words[column // 8] >> (4 * (column % 8))) & 15
            weight = f32(f32(float(code) * 1.0) + bias)
            decoded.append(weight)
            typed.append(narrow(weight))
            wide_dot = f32(wide_dot + f32(x * weight))
            early_dot = f32(early_dot + f32(x * typed[-1]))
        assert narrow(wide_dot) == -1.0 and narrow(early_dot) == -2.0
        assert typed[:2] == [bias, bias + 2.0]
        records.append(dict(dtype=name, rows=[1, 64], K=128, N=16, group=64,
            packed_first_word='0x21', nonzero_activation=[1.0, -1.0],
            scale=1.0, bias=bias, F32_decoded_first_two=decoded[:2],
            typed_embedding_first_two=typed[:2], F32_decode_dot=narrow(wide_dot),
            early_typed_decode_dot=narrow(early_dot)))
    path = Path(__file__).resolve()
    result = dict(scope='Pure scalar math only; no compile, MLX or GPU execution.',
        oracle_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), cases=records,
        FMA_and_F32_dot_tree_cannot_explain_difference=True,
        typed_embedding_control_does_not_prove_general_intermediate_rounding=True)
    text = json.dumps(result, indent=2) + '\n'
    path.with_name('math-oracle.json').write_text(text, encoding='utf-8')
    print(text, end='')


if __name__ == '__main__':
    main()
