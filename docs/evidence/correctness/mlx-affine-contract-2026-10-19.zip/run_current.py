import concurrent.futures, hashlib, json, os, pathlib, shlex, shutil, subprocess, sys, time

HERE = pathlib.Path(__file__).resolve().parent
CFG = json.loads((HERE/'current-config.json').read_text())
SRC = HERE/'current'
SDK = pathlib.Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
BUILD = pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build')
NATIVE = pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials')
mode = sys.argv[1] if len(sys.argv)>1 else 'control'
OUT = HERE/mode
OUT.mkdir(exist_ok=True)
(OUT/'objects').mkdir(exist_ok=True)
def ident(p):
    p=pathlib.Path(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(name, value): (OUT/name).write_text(json.dumps(value, indent=2)+'\n')
def execute(tag, argv):
    started=time.time()
    with (OUT/(tag+'.stdout.log')).open('w') as stdout, (OUT/(tag+'.stderr.log')).open('w') as stderr:
        p=subprocess.Popen(argv, stdout=stdout, stderr=stderr, cwd=HERE)
        record=dict(argv=argv, pid=p.pid, started=started)
        (OUT/(tag+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
        record.update(exit=p.wait(), elapsed=time.time()-started)
    (OUT/(tag+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(tag, record['exit'], round(record['elapsed'],2), flush=True)
    return record
for entry in json.loads((HERE/'current-source-manifest.json').read_text()):
    p=SRC/entry['path']
    # Candidate implementation is the one deliberate post-control source change.
    if mode=='fixed' and entry['path']=='src/compute_route_apple/apple_tensor.cc': continue
    assert ident(p)['sha256']==entry['sha256'], str(p)
save('host.json',dict(pid=os.getpid(), mode=mode, started=time.time(),
    uname=subprocess.check_output(['uname','-a'],text=True).strip(),
    hardware=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),
    clang=subprocess.check_output(['/usr/bin/clang++','--version'],text=True).splitlines()[0]))

def compile_argv(rel, target):
    recipes=CFG['recipes']
    template=recipes.get(rel)
    if template is None:
        if rel.endswith('.S'):
            return ['/usr/bin/clang','-arch','arm64','-c',str(SRC/rel),'-o',str(target)]
        module=rel.split('/')[1]
        template=next(v for k,v in recipes.items() if k.startswith('src/'+module+'/') and k.endswith('.cc'))
    result=[]; i=0
    while i<len(template):
        a=template[i]
        if a in ['-o','-c','-MF','-MT']:
            i+=2; continue
        if a in ['-MD','-MMD','-MP']: i+=1; continue
        a=a.replace(CFG['old'],str(SRC))
        result.append(a); i+=1
    # Current private/public roots first; generated build metadata and locked
    # external provider headers are inherited from the existing real recipe.
    result[1:1]=['-DHYLE_STATIC','-I'+str(SRC/'include'),'-I'+str(SRC),
        '-I'+str(SRC/'src/compute'),'-I'+str(SRC/'src/compute_route_apple'),
        '-I'+str(SRC/'third_party/ds4_quantization'),
        '-I'+str(SRC/'third_party/deepseek_quantization')]
    return result+['-MMD','-MF',str(target)+'.d','-c',str(SRC/rel),'-o',str(target)]
def compile_one(rel):
    tag=rel.replace('/','--').replace('.','-')
    obj=OUT/'objects'/(tag+'.o')
    result=execute('compile-'+tag,compile_argv(rel,obj))
    result['source']=ident(SRC/rel)
    if result['exit']==0: result['object']=ident(obj)
    return rel,result

if mode!='fixed':
    previous=HERE/sys.argv[2]/'compile-summary.json' if len(sys.argv)>2 else None
    results=json.loads(previous.read_text()) if previous and previous.exists() else {}
    pending=[rel for rel in CFG['sources'] if rel not in results or results[rel]['exit']
             or results[rel]['source']['sha256']!=ident(SRC/rel)['sha256']]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for rel,result in pool.map(compile_one,pending): results[rel]=result
    save('compile-summary.json',results)
    if any(r['exit'] for r in results.values()): sys.exit(2)
else:
    results=json.loads((HERE/sys.argv[2]/'compile-summary.json').read_text())
    rel='src/compute_route_apple/apple_tensor.cc'
    _,fixed=compile_one(rel)
    save('compile-summary.json',{rel:fixed})
    if fixed['exit']: sys.exit(2)
    results[rel]=fixed
objects=[r['object']['path'] for r in results.values()]
archive=OUT/'libcurrent-hyle.a'
r=execute('archive',['/usr/bin/ar','rcs',str(archive)]+objects)
if r['exit']: sys.exit(3)

test=OUT/'mlx-quantized-test.o'
template=compile_argv('src/compute_route_apple/apple_tensor.cc',test)
template[template.index('-c')+1]=str(SRC/CFG['test'])
template[1:1]=['-isystem',str(BUILD/'_deps/googletest-src/googletest/include'),
    '-isystem',str(BUILD/'_deps/googletest-src/googlemock/include')]
# The cached test recipe gives the actual existing gtest include location.
test_recipe=json.loads((HERE/'test-compile-command.json').read_text())
for index,a in enumerate(test_recipe):
    if 'googletest' in a or 'gtest' in a:
        if a.startswith('-I'): template[1:1]=[a]
        elif index and test_recipe[index-1]=='-isystem': template[1:1]=['-isystem',a]
r=execute('test-compile',template)
if r['exit']: sys.exit(4)

# Reuse the existing custom native host code together with its exact metallib.
# No stale Hyle SDK archives occur in this direct Apple-test link.
old=json.loads((HERE/'link-recipe.json').read_text())['link']['argv']
native=[x for x in old if x.endswith('.o') and ('native-host.f32.o' in x or any(
    y in x for y in ['/native-ops.o','/native-alloc.o','/fast.o','/steel_attention.o','/common.o','/primitives.o']))]
libraries=[str(SDK/'lib'/x) for x in ['libmimalloc_static.a','libggml-cpu.a','libggml.a','libggml-metal.a','libggml-base.a','libmlx.a']]
libraries += [str(BUILD/'lib/libgtest_main.a'),str(BUILD/'lib/libgtest.a')]
save('reused-inputs.json',[ident(p) for p in native+libraries])
shutil.copy2(NATIVE/'mlx.metallib',OUT/'mlx.metallib')
image=OUT/'mlx-quantized-tests'
argv=['/usr/bin/clang++','-arch','arm64','-O3','-std=c++23',str(test),str(archive)]+native+libraries+[
    '-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore',
    '-o',str(image),'-Wl,-map,'+str(OUT/'mlx-quantized-tests.map')]
r=execute('link',argv)
if r['exit']: sys.exit(5)
save('image.json',ident(image))
r=execute('tests',[str(image),'--gtest_filter=AppleMlxQuantized.*',
    '--gtest_output=xml:'+str(OUT/'tests.xml')])
save('summary.json',dict(mode=mode, exit=r['exit'], image=ident(image),
    source=ident(SRC/'src/compute_route_apple/apple_tensor.cc'),
    tests=ident(SRC/CFG['test']), metallib=ident(OUT/'mlx.metallib'),
    hyle_fresh_sources=len(results), stale_hyle_libraries=False))
sys.exit(r['exit'])
