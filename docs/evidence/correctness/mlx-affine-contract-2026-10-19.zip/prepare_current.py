import hashlib, json, pathlib, re, shlex, tarfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
STAGE = pathlib.Path(__file__).resolve().parent
REMOTE = '/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019'
OLD = '/Users/kiro/hyle-scratch/compute-unified/source-c8874688'
MODULES = ['error', 'time', 'platform', 'platform_thread', 'platform_fs', 'mem',
           'mem_vm', 'container', 'sched', 'simd', 'io_core', 'compute_ops',
           'compute', 'compute_batch', 'compute_state', 'compute_stream',
           'compute_route_apple', 'compute_provider_ggml_metal', 'compute_ggml_runtime']
db = json.loads((STAGE/'mac-compile-commands.json').read_text())
recipes = {}
for item in db:
    if item['file'].startswith(OLD+'/src/'):
        rel = item['file'][len(OLD)+1:]
        recipes[rel] = shlex.split(item['command'])
sources = [p for p in recipes if p.split('/')[1] in MODULES and (ROOT/p).is_file()]
# These are current CMake owners added since the cached compile database.
for rel in ['src/compute_batch/row_cache_paged_reader.cc',
            'src/compute_route_apple/apple_row_cache.cc',
            'src/compute_route_apple/apple_row_cache_paged.cc',
            'src/compute_route_apple/apple_row_cache_indexer.cc']:
    if rel not in sources: sources.append(rel)
# Obsolete file_stream.cc is not part of the current Apple module.
sources = sorted(p for p in sources if p != 'src/compute_route_apple/file_stream.cc')
for stem in ['jump', 'make', 'ontop']:
    sources.append(f'third_party/fcontext/asm/{stem}_arm64_aapcs_macho_gas.S')

config = dict(remote=REMOTE, old=OLD, sources=sources, recipes=recipes,
              test='tests/compute_route_apple/mlx_quantized_test.cc')
(STAGE/'current-config.json').write_text(json.dumps(config, indent=2)+'\n')
files = set()
for folder in ['include'] + ['src/'+x for x in MODULES] + [
        'tests/compute_route_apple', 'tests/compute_provider_native',
        'third_party/bitsandbytes_apple', 'third_party/awq_apple',
        'third_party/compressed_tensors_apple', 'third_party/ggml_q4k_apple',
        'third_party/ds4_quantization', 'third_party/deepseek_quantization',
        'third_party/random123_counter', 'third_party/mimalloc/include',
        'third_party/xxhash', 'third_party/wyhash', 'third_party/fcontext/asm']:
    for p in (ROOT/folder).rglob('*'):
        if p.is_file() and p.suffix in {'.h','.hpp','.inc','.in','.cc','.mm','.S','.def'}:
            files.add(p.relative_to(ROOT).as_posix())
manifest = [dict(path=p, bytes=(ROOT/p).stat().st_size,
                 sha256=hashlib.sha256((ROOT/p).read_bytes()).hexdigest()) for p in sorted(files)]
(STAGE/'current-source-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
with tarfile.open(STAGE/'current-source.tar.gz', 'w:gz') as archive:
    for p in sorted(files): archive.add(ROOT/p, arcname='current/'+p)
    for name in ['current-config.json', 'current-source-manifest.json', 'run_current.py']:
        archive.add(STAGE/name, arcname=name)
print(json.dumps(dict(source_count=len(sources), files=len(files),
    archive_bytes=(STAGE/'current-source.tar.gz').stat().st_size,
    remote=REMOTE)))
