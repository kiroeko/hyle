/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/control/objects/src--simd--sort--vqsort_hyle_neon-cc.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_hyle_neon.cc \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/environment.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_body.inc \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/kernels.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/simd/types.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_hyle/vqsort-inl.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_hyle/vqsort_ops.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/cache.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/compiler.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/detail/compiler_attributes.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/assert.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_hyle/shared-inl.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_hyle/sorting_networks-inl.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_hyle/traits-inl.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_hyle/traits128-inl.h
