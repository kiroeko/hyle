/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/control/objects/src--platform--random-cc.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/platform/random.cc \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/platform/random.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/error/status.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/platform/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/environment.h
