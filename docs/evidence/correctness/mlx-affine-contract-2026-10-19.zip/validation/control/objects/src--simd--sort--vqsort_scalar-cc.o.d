/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/control/objects/src--simd--sort--vqsort_scalar-cc.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/vqsort_scalar.cc \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/sort/kernels.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/simd/types.h
