/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/control/objects/src--simd--math--transcendental_scalar-cc.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/math/transcendental_scalar.cc \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/simd/math/kernels.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/simd/types.h
