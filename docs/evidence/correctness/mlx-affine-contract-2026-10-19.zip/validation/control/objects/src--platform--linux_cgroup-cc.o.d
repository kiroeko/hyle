/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/control/objects/src--platform--linux_cgroup-cc.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/platform/linux_cgroup.cc \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/platform/linux_cgroup_internal.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/environment.h
