/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/control/objects/src--container--bitset_ops_neon-cc.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/container/bitset_ops_neon.cc
