/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/control/objects/src--compute_ops--sampling_ops-cc.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/compute_ops/sampling_ops.cc \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/compute/sampling_ops.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/compute/operation.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/compute/ops_visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/compute/tensor_desc.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/error/result.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/compiler.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/detail/compiler_attributes.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/environment.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/assert.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/detail/preprocessor.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/error/status.h
