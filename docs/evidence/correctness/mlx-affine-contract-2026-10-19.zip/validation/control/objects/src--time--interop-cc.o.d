/Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/control/objects/src--time--interop-cc.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/src/time/interop.cc \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/environment.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/time/native_interop.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/time/clock.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/compiler.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/detail/compiler_attributes.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/core/assert.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/mlx-affine-contract-20261019/current/include/hyle/time/unix_timestamp.h
