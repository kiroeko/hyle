import hashlib, io, json, pathlib, tarfile, xml.etree.ElementTree as ET, zipfile

STAGE=pathlib.Path(__file__).resolve().parent
ROOT=STAGE.parents[2]
DEST=ROOT/'docs/evidence/correctness/mlx-affine-contract-2026-10-19.zip'
def identity(p):
    b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def save(name,value): (STAGE/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

proofs=STAGE/'validation'
proofs.mkdir(exist_ok=True)
with tarfile.open(STAGE/'remote-proofs.tar.gz') as archive:
    archive.extractall(proofs,filter='data')
control=read(proofs/'control-retry1/summary.json')
fixed=read(proofs/'fixed/summary.json')
assert control['exit']==1 and fixed['exit']==0
for name, failures in [('control-retry1',1),('fixed',0)]:
    xml=ET.parse(proofs/name/'tests.xml').getroot()
    assert int(xml.attrib['tests'])==4 and int(xml.attrib['failures'])==failures
    assert int(xml.attrib.get('disabled',0))==0
    assert not xml.findall('.//skipped')
assert control['metallib']['sha256']==fixed['metallib']['sha256']
assert len(read(proofs/'control-retry1/compile-summary.json'))==134
assert all(r['exit']==0 for r in read(proofs/'control-retry1/compile-summary.json').values())
for name in ['control-retry1','fixed']:
    argv=read(proofs/name/'link.command.json')['argv']
    assert not any('libhyle' in a for a in argv), name
for entry in read(STAGE/'source-freeze.json')['files']:
    assert identity(ROOT/entry['product'])['sha256']==entry['after']['sha256']
for entry in read(STAGE/'tests-source-freeze.json')['files']:
    assert identity(ROOT/entry['target'])['sha256']==entry['after']['sha256']
manifest=read(STAGE/'current-source-manifest.json')
with tarfile.open(STAGE/'current-source.tar.gz') as archive:
    for item in manifest:
        b=archive.extractfile('current/'+item['path']).read()
        assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
save('application.json',dict(product=identity(ROOT/'src/compute_route_apple/apple_tensor.cc'),
    tests=identity(ROOT/'tests/compute_route_apple/mlx_quantized_test.cc'),
    control=control,fixed=fixed, fresh_hyle_cpp_objcxx=131,vendored_fcontext_assembly=3,
    reused_native_resources=read(proofs/'fixed/reused-inputs.json'),
    observed='Original implementation: M64 BF16/F16 gives -2 instead of independent F32 decoded -1; M1 passes. Fixed: all four tests pass, no skips.',
    limits='Directed public affine4 regression, not all artifacts, full-model quality, general embedding two-RNE equivalence, performance, or workspace validation.'))
docs=['docs/user/apple-compute.md','docs/architecture/compute-design.md']
for rel in docs:
    dest=STAGE/'docs-context'/rel
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((ROOT/rel).read_bytes())
private=read(proofs/'rebuildable-private-files.json')
targets=[r for r in private if pathlib.PurePosixPath(r['path']).suffix in {'.map','.metallib'}
         or pathlib.PurePosixPath(r['path']).name=='mlx-quantized-tests']
save('cleanup-plan.json',dict(remote='kiro@172.22.10.198',targets=targets,
    retained_build_cache=[r for r in private if r not in targets],
    rule='Delete only these exact private images/maps/metallib copies. Keep fresh Hyle objects/archives for later incremental checks, and keep shared native resources, SDK, source, commands and logs. Root writes test.ps1 before execution.'))
excluded={'remote-proofs.tar.gz','archive-receipt.json'}
payload=[p for p in STAGE.rglob('*') if p.is_file() and p.name not in excluded
    and p.suffix not in {'.o','.obj','.a','.exe','.map','.lib','.exp','.pdb','.pyc','.dll','.metallib'}
    and '__pycache__' not in p.parts]
sha={p.relative_to(STAGE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in payload}
DEST.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in sorted(payload): archive.write(p,p.relative_to(STAGE).as_posix())
    archive.writestr('payload-sha256.json',json.dumps(sha,indent=2)+'\n')
with zipfile.ZipFile(DEST) as archive:
    assert archive.testzip() is None
    assert set(sha)==set(archive.namelist())-{'payload-sha256.json'}
    for name,digest in sha.items(): assert hashlib.sha256(archive.read(name)).hexdigest()==digest
save('archive-receipt.json',dict(**identity(DEST),payloads=len(sha),crc_verified=True,
    every_payload_sha256_verified=True,control_failures=1,fixed_tests_passed=4,skipped=0))
print(json.dumps(read(STAGE/'archive-receipt.json'),indent=2))
