import hashlib, json, pathlib, tarfile
root=pathlib.Path(__file__).resolve().parent
files=[]
for directory in ['control','control-retry1','fixed']:
    for p in (root/directory).rglob('*'):
        if p.is_file() and p.suffix in {'.json','.log','.xml','.d'}: files.append(p)
for p in root.glob('*driver.*.log'): files.append(p)
for name in ['run_current.py','current-config.json','current-source-manifest.json',
             'test-compile-command.json','link-recipe.json']:
    files.append(root/name)
# Record exact private rebuild outputs without copying them into evidence.
cleanup=[]
for directory in ['control','control-retry1','fixed']:
    for p in (root/directory).rglob('*'):
        if p.is_file() and (p.suffix in {'.o','.a','.map','.metallib'} or p.name=='mlx-quantized-tests'):
            cleanup.append(dict(path=str(p),bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(root/'rebuildable-private-files.json').write_text(json.dumps(cleanup,indent=2)+'\n')
files.append(root/'rebuildable-private-files.json')
with tarfile.open(root/'proofs.tar.gz','w:gz') as archive:
    for p in sorted(set(files)): archive.add(p,arcname=p.relative_to(root).as_posix())
print(json.dumps(dict(files=len(set(files)),cleanup_files=len(cleanup),
    cleanup_bytes=sum(x['bytes'] for x in cleanup),
    proof_bytes=(root/'proofs.tar.gz').stat().st_size)))
