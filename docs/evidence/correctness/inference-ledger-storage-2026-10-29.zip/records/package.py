"""Offline ledger-storage evidence only; no build, execution, cleanup or network."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import math
import sys
import zipfile

sys.dont_write_bytecode = True
BATCH = Path(__file__).resolve().parent
R = BATCH.parents[1]
W = BATCH / 'attempt2'
DEST = R / 'docs/evidence/correctness/inference-ledger-storage-2026-10-29'
spec = importlib.util.spec_from_file_location('ledger_storage_evidence_build', BATCH / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
CASES = ('varlen-cpu', 'varlen-cuda', 'natural-cuda', 'group-return-cpu')


def terminal(directory):
    value = t.read(directory / 'process.json')
    assert value['state'] == 'TERMINAL' and value['exit'] == 0 and not value['timed_out'], directory
    return value


def main():
    plan = b.validate()
    frozen = t.read(W / 'source-freeze.json'); assert len(frozen) == 241
    compiled = t.read(W / 'compile/tiny/compiled.json')
    ready = t.read(W / 'ready-tiny.json')
    cxx = terminal(W / 'logs/compile-tiny'); link = terminal(W / 'logs/link-tiny')
    assert compiled['process'] == cxx and ready['process'] == link and ready['compiled'] == compiled
    assert t.command(W / 'logs/compile-tiny/command.json') == plan['units']['tiny']['compile']
    assert t.command(W / 'logs/link-tiny/command.json') == plan['units']['tiny']['link']
    assert ready['source_freeze'] == t.pin(W / 'source-freeze.json')
    sdk = {t.key(row['path']): row for row in plan['retained']}; assert len(sdk) == 227
    suffixes = collections.Counter(Path(row['path']).suffix.lower() for row in sdk.values())
    assert suffixes == {'.obj': 202, '.lib': 25}, suffixes
    assert len(ready['inputs']) == 228
    for row in ready['inputs']:
        if t.key(row['path']) in sdk: assert row == sdk[t.key(row['path'])]
        else: assert row == compiled['object']
    assert len({t.key(row['path']) for row in ready['inputs']}) == 228
    source_index = {t.key(row['path']): row for row in frozen}
    for row in compiled['project_dependencies']:
        assert source_index[t.key(row['path'])] == row, row['path']
    actual_project = [row for row in compiled['actual_dependencies'] if t.project(row['path'])]
    assert actual_project == compiled['project_dependencies']
    runs, state_rows = {}, []
    for name in CASES:
        directory = W / 'runs' / name; process = terminal(directory)
        report = t.read(directory / 'report.json')
        raw = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        expected = [t.read(directory / 'host-report.json'), report] if name.startswith('varlen-') else [report]
        assert raw == expected and report['status'] == 'PASS'
        command = t.command(directory / 'command.json')
        _, backend, flag = b.b.CASES[name]
        fixture = plan['fixtures']['natural' if name == 'natural-cuda' else 'varlen']
        assert command == [ready['image']['path'], '--' + backend, fixture['directory'], flag]
        assert report['backend'] == backend and report['quality_claim'] is False and report['performance_claim'] is False
        assert report['final_versions'] == 0
        if name.startswith('varlen-'):
            assert report['ledger_reserved_width'] == 8 and report['ledger_record_storage_checks'] == 24
            assert report['ledger_cold_storage_reused'] and report['ledger_host_prepare_withdraw_reprepare']
            assert (report['target_submissions'], report['bounded_target_submissions']) == (11,3)
            assert len(report['state_checks']) == 6 and report['natural_rng_draws'] == [1,5]
            assert report['original_q_identity_and_release'] and report['natural_R1_results_equal']
            assert report['old_checkpoints_unchanged'] and report['accepted_prefixes_1_2_3']
            assert report['engine_unequal_lengths_one_submission'] and report['fixed_carrier_reused']
            facts = {key: report[key] for key in ('ledger_reserved_width', 'ledger_record_storage_checks',
                'ledger_cold_storage_reused', 'ledger_host_prepare_withdraw_reprepare', 'target_submissions',
                'bounded_target_submissions', 'natural_rng_draws', 'natural_processed_target', 'natural_processed_draft')}
        elif name == 'natural-cuda':
            assert report['natural_RequestLoop'] and report['controlled_acceptance'] is False
            assert (report['resident_capacity'], report['state_slots'], report['hidden_slots']) == (1,5,6)
            assert report['outputs'] == report['output_limit'] == len(report['ids']) == 40
            for key in ('original_ledger_equal', 'generated_ids_equal', 'greedy_rng_unchanged', 'all_sources_expired'):
                assert report[key] is True, key
            for key in ('successor_submissions', 'successor_publications', 'pending_pairs_before_A_publish',
                        'deferred_waves', 'reserved_two_grants'):
                assert report[key] > 0, key
            assert len(report['state_checks']) == 1
            facts = {key: report[key] for key in ('outputs', 'ledger_records', 'resident_capacity', 'state_slots',
                'hidden_slots', 'successor_submissions', 'successor_publications', 'successor_discards',
                'successor_refusals', 'accepted_drafts', 'rejected_drafts')}
        else:
            assert report['case'] == 'mtp-group-return' and report['logical_requests'] == 3 and report['actual_active_sequences'] == 2
            assert report['submitted_widths'] == [2,3] and report['actual_q_before_grouping'] == 5 and report['actual_q_after_failure'] == 4
            keys = ('original_calls_and_q_returned', 'earlier_group_commit_preserved', 'failed_heads_ledger_rng_unchanged',
                    'actual_retirement', 'same_key_host_restore_retry', 'no_proposal_regeneration')
            for key in keys: assert report[key] is True, key
            facts = {key: report[key] for key in ('logical_requests', 'actual_active_sequences', 'submitted_widths',
                'actual_q_before_grouping', 'actual_q_after_failure', *keys)}
        for row in report.get('state_checks', []):
            assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
            assert row['payloads_byte_equal'] == (not row['differences'])
            for diff in row['differences']:
                assert diff['role'] == 3 and diff['nonfinite_differences'] == 0
                assert math.isfinite(diff['maximum_absolute']) and 0 <= diff['maximum_absolute'] <= 3e-6
            state_rows.append(row)
        runs[name] = dict(process=process, facts=facts,
            report_member='records/attempt2/runs/' + name + '/report.json')
    assert len(state_rows) == 13
    failed_prepare = t.read(BATCH / 'prepare-attempt1.json')
    assert failed_prepare['exit_code'] == 1 and failed_prepare['native_processes'] == 0
    assert t.pin(BATCH / 'attempt1-helper.py')['sha256'] == failed_prepare['helper_sha256']
    members = {}
    def add(path, name, expected=None):
        path = Path(path); body = path.read_bytes()
        assert path.name.lower() not in ('environment.json', 'env.json'), path
        if expected: assert (len(body), hashlib.sha256(body).hexdigest()) == (expected['bytes'], expected['sha256']), path
        assert name not in members or members[name] == body, name
        members[name] = body
    for row in frozen:
        path = Path(row['path']); assert path.is_relative_to(R) and t.project(path)
        add(path, 'source/' + path.relative_to(R).as_posix(), row)
    for path in sorted((BATCH / 'before').rglob('*')):
        if path.is_file():
            assert path.suffix.lower() in ('.cc', '.h', '.md'), path
            add(path, 'before/' + path.relative_to(BATCH / 'before').as_posix())
    metadata_suffixes = {'.json', '.log', '.d'}
    for path in sorted(W.rglob('*')):
        if path.is_file() and path.suffix.lower() in metadata_suffixes and path.name.lower() not in ('environment.json', 'env.json'):
            add(path, 'records/attempt2/' + path.relative_to(W).as_posix())
    for path in (BATCH / 'build.py', BATCH / 'attempt1-helper.py', BATCH / 'prepare-attempt1.json', Path(__file__)):
        add(path, 'records/' + path.name)
    for row in plan['helpers']:
        add(row['path'], 'helpers/' + row['sha256'] + '/' + Path(row['path']).name, row)
    for field in ('base', 'previous_consumer', 'host_recipe'):
        row = plan[field]; add(row['path'], 'referenced/' + row['sha256'] + '/' + Path(row['path']).name, row)
    for name, fixture in plan['fixtures'].items():
        for key in ('manifest', 'prompt'):
            row = fixture[key]; add(row['path'], 'fixtures/' + name + '/' + Path(row['path']).name, row)
    manifest = dict(schema='hyle.inference-ledger-storage.archive.v1',
        source_freeze=t.pin(W / 'source-freeze.json'), frozen_project_files=len(frozen),
        actual_compiled_project_files=len(compiled['project_dependencies']),
        members={name: dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest()) for name, body in sorted(members.items())})
    members['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    archive = DEST.with_suffix('.zip'); DEST.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name, body in sorted(members.items()): output.writestr(name, body)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None and set(check.namelist()) == set(members)
        for name, body in members.items(): assert check.read(name) == body, name
    product = [row for row in frozen if Path(row['path']).name in ('main.cc', 'generation_ledger.h', 'qwen_mtp_varlen_verify_case.h')]
    assert {Path(row['path']).name for row in product} == {'main.cc','generation_ledger.h','qwen_mtp_varlen_verify_case.h'}
    compact = dict(schema='hyle.inference-ledger-storage.v1', status='PASS_FINITE_LEDGER_STORAGE_REUSE',
        product_sources=product, source_freeze=t.pin(W / 'source-freeze.json'),
        frozen_project_files=len(frozen), actual_compiled_project_files=len(compiled['project_dependencies']),
        image=ready['image'], object=compiled['object'],
        native_processes=runs, CXX=cxx, link=link,
        actual_process_counts=dict(CXX=1, link=1, native=4, failed_native=0, failed_prepare_metadata_only=1),
        SDK=dict(retained_inputs=227, objects=202, libraries=25, SDK_CXX=0, NVCC=0, downloads=0),
        ledger_storage=dict(vector_buffers_per_record=3, reserved_width=8, checks_per_backend=24, checked_backends=['cpu','cuda'],
            scope='Original record emitted/accepted/verified buffers retain cold capacity and data pointers through host prepare/withdraw/reprepare and actual unequal-width Engine verification.'),
        explicit_state_comparisons=dict(total=len(state_rows), byte_exact=sum(row['payloads_byte_equal'] for row in state_rows),
            numerically_equivalent=len(state_rows), F32_GDN_absolute_budget=3e-6),
        failed_tooling_prepare=failed_prepare,
        fixtures={name: dict(manifest=f['manifest'], prompt=f['prompt'], local_weight_sources=f['local_weight_sources']) for name,f in plan['fixtures'].items()},
        limits=['Finite CPU/CUDA K2 Verify3 component with controlled prefix tests and one original sampled real-q episode per backend.',
            'CUDA greedy real cached Qwen K1 RequestLoop is a regression: N1/R1/D2, 40 outputs; it does not extend pipeline applicability.',
            'CPU mixed-width group failure/host restore/retry is unchanged functional coverage, not a no-allocation claim.',
            'Three ledger vector buffers retain storage; no whole-process allocation-free or throughput claim.',
            'No quality/performance comparison, new downloads, arbitrary hardware/model guarantee or full goal completion.',
            'Archive contains project sources, receipts, logs, commands, small manifests/prompts and helper history; excludes environment values, tensor payloads, binaries, SDK objects/libraries.'],
        archive=t.pin(archive), archive_members=len(members), crc_and_member_sha256_readback=True)
    t.save(DEST.with_suffix('.json'), compact)
    print('ARCHIVE WRITTEN', archive.name, compact['archive']['bytes'], compact['archive']['sha256'])


if __name__ == '__main__': main()
