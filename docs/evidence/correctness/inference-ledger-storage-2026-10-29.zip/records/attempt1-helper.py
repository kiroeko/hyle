"""One fresh Tiny TU/link; root explicitly invokes each bounded native case."""
from pathlib import Path
import contextlib
import csv
import io
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-mtp-natural-20261029'
spec = importlib.util.spec_from_file_location('ledger_existing_tiny_build', OLD / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
t = b.t
b.W = t.W = W
b.OLD = OLD
b.BASE = OLD / 'model-link-base.json'
b.SOURCES = {'tiny': R / 'tests/tools/qwen_host_image_test.cc'}
b.CASES = {'varlen-cpu': ('tiny', 'cpu', '--mtp-varlen-verify'),
           'varlen-cuda': ('tiny', 'cuda', '--mtp-varlen-verify'),
           'natural-cuda': ('tiny', 'cuda', '--mtp-natural-relay')}


def local_fixture(directory):
    files = {}
    with (directory / 'weights.tsv').open(encoding='utf-8-sig', newline='') as stream:
        for fields in list(csv.reader(stream, delimiter='\t'))[3:]:
            if not fields: continue
            rank = int(fields[2]); path = Path(fields[3 + rank]).resolve()
            start, length = map(int, fields[4 + rank:6 + rank]); st = path.stat()
            assert start >= 0 and length >= 0 and start + length <= st.st_size
            files[t.key(path)] = dict(path=str(path), bytes=st.st_size,
                mtime_ns=st.st_mtime_ns, file_id=st.st_ino)
    assert files
    return dict(directory=str(directory), manifest=t.pin(directory / 'weights.tsv'),
        prompt=t.pin(directory / 'prompt.ids'), local_weight_sources=list(files.values()))


def quoted_closure(paths):
    found = {t.key(Path(path).resolve()): str(Path(path).resolve()) for path in paths}
    todo = list(found.values())
    while todo:
        current = Path(todo.pop())
        for inc in re.findall(r'^\s*#\s*include\s*"([^\"]+)"', current.read_text(encoding='utf-8-sig'), re.M):
            path = next((q.resolve() for root in (current.parent, R / 'include', R)
                         if (q := root / inc).is_file()), None)
            if path is not None and t.project(path) and t.key(path) not in found:
                found[t.key(path)] = str(path); todo.append(str(path))
    return sorted(found.values(), key=t.key)


def prepare():
    original_save = t.save
    def save(path, value):
        if Path(path) == W / 'plan.json':
            value['helpers'].append(t.pin(__file__))
            value['sources'] = quoted_closure(value['sources'])
            value['fixtures'] = dict(varlen=local_fixture(b.PLAIN), natural=local_fixture(b.NATURAL))
            value['counts'] = dict(CXX=1, links=1, SDK_CXX=0, NVCC=0,
                inputs_per_link=228, retained_inputs=227, planned_native_cases=3, downloads=0)
            value['scope'] = 'Explicit actions only; no retries, implicit compile, SDK build, download or cleanup.'
        original_save(path, value)
    t.save = save
    try:
        with contextlib.redirect_stdout(io.StringIO()): b.prepare()
    finally: t.save = original_save
    print("PREPARED one fresh Tiny CXX/link, 227 retained SDK inputs; no native execution")


_base_validate = b.validate

def validate():
    plan = _base_validate()
    for fixture in plan['fixtures'].values():
        t.exact(fixture['manifest']); t.exact(fixture['prompt'])
        for row in fixture['local_weight_sources']:
            st = Path(row['path']).stat()
            assert (st.st_size, st.st_mtime_ns, st.st_ino) == (row['bytes'], row['mtime_ns'], row['file_id'])
    return plan

b.validate = validate


def parse(name):
    validate()
    if name == 'natural-cuda': b.parse(name); return
    assert name in ('varlen-cpu', 'varlen-cuda')
    _, backend, _ = b.CASES[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json')
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(reports) == 2; host, report = reports
    assert host['status'] == 'PASS' and host['case'] == 'packed-prefix-rows' and host['models'] == 0 and host['manual_orders'] == 2
    for field in ('allocation_free_selector', 'zero_history', 'late_failure_preserves_outputs', 'overlap_preserves_outputs'):
        assert host[field] is True, field
    assert report['status'] == 'PASS' and report['backend'] == backend and report['mode'] == 'mtp_varlen_verify'
    assert report['models'] == 1 and report['requests'] == 2
    assert (report['physical_rows_per_member'], report['active_rows'], report['physical_rows']) == (3, 4, 6)
    assert report['length_orders'] == [[1,3],[3,1],[1,3]] and report['controlled_accepted'] == [[1,2],[3,1]]
    assert (report['target_submissions'], report['bounded_target_submissions']) == (11,3)
    assert report['ledger_reserved_width'] == 8 and report['ledger_record_storage_checks'] == 24
    assert report['ledger_cold_storage_reused'] is True and report['ledger_host_prepare_withdraw_reprepare'] is True
    assert report['natural_proposal_rows'] == [0,2] and report['natural_rng_draws'] == [1,5]
    for field in ('old_checkpoints_unchanged', 'accepted_prefixes_1_2_3', 'fixed_carrier_reused',
                  'engine_unequal_lengths_one_submission', 'original_q_identity_and_release', 'natural_R1_results_equal'):
        assert report[field] is True, field
    assert report['full_request_history_import_coverage'] is False and report['quality_claim'] is False
    assert report['performance_claim'] is False and report['synthetic_untrained'] is True and report['final_versions'] == 0
    assert len(report['natural_processed_target']) == len(report['natural_processed_draft']) == 2
    assert report['natural_processed_target'][0] == 1 and 1 <= report['natural_processed_target'][1] <= 3
    assert report['natural_processed_draft'][0] == 2
    rows = report['state_checks']; assert len(rows) == 6 and report['numerically_equivalent'] is True
    assert report['payloads_byte_equal'] == all(row['payloads_byte_equal'] for row in rows)
    for row in rows:
        assert row['boundary_equal'] and row['numerically_equivalent'] and row['exact_next'] == row['bucket_next']
        assert row['payloads_byte_equal'] == (not row['differences'])
        for diff in row['differences']:
            assert diff['role'] == 3 and diff['nonfinite_differences'] == 0 and 0 <= diff['maximum_absolute'] <= 3e-6
    t.save(out / 'host-report.json', host); t.save(out / 'report.json', report)
    print('PASS', name, 'PID', process['pid'], 'complete state comparisons', len(rows))


def run(name):
    plan = validate(); _, backend, flag = b.CASES[name]
    fixture = plan['fixtures']['natural' if name == 'natural-cuda' else 'varlen']
    ready = t.read(W / 'ready-tiny.json'); t.exact(ready['image'])
    t.execute([ready['image']['path'], '--' + backend, fixture['directory'], flag], W / 'runs' / name, 300)
    parse(name)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action in ('freeze', 'validate'): getattr(b, action)()
    elif action in ('compile', 'parse_compile', 'link'):
        assert len(sys.argv) == 3 and sys.argv[2] == 'tiny'; getattr(b, action)('tiny')
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
