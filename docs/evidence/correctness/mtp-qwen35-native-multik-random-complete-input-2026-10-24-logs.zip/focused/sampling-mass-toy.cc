#include "engine/models/qwen35/main.cc"
int main() { try {
 using namespace qwen35;
 auto execution=take(Backend::create());
 std::map<std::string,Tensor> bank; ModelGeometry geometry;geometry.hidden=2048;geometry.conv_kernel=4;
 Recipe r(bank,execution,geometry,1);
 auto input=r.input(dense(Type::kFloat32,{1,4}));
 auto q=r.input(dense(Type::kFloat32,{1,4}));auto bonus=r.input(dense(Type::kFloat32,{1,4}));
 auto id=r.input(dense(Type::kInt32,{1}));
 auto key=r.input(dense(Type::kUInt32,{1,4}));
 auto distribution=sampling::distribution(r,input);
 auto decision=sampling::decision(r,input,q,bonus,id,key,key);
 std::array ports{r.cast(distribution.valid,Type::kFloat32),r.cast(decision.valid,Type::kFloat32),r.cast(decision.p_valid,Type::kFloat32),r.cast(decision.q_valid,Type::kFloat32),r.cast(decision.bonus_valid,Type::kFloat32),r.cast(decision.accepted,Type::kFloat32),r.cast(decision.final_id,Type::kFloat32),r.cast(decision.proposal_valid,Type::kFloat32),r.cast(decision.residual_positive,Type::kFloat32)};
 for(auto value:ports)r.publish(value);
 auto graph=take(std::move(r.builder).finish());
 for(std::size_t n=55;n<std::min<std::size_t>(66,graph.node_count());++n){auto node=take(graph.node_id(n));std::cerr<<"TOY_NODE "<<n<<" kind="<<int(take(graph.operation_kind(node)));for(std::size_t i=0;i<take(graph.node_input_count(node));++i){auto v=take(graph.node_input(node,i));auto d=take(graph.value_description(v));std::cerr<<" ["<<int(d.data_type())<<":";for(auto dim:d.dimensions())std::cerr<<dim<<',';std::cerr<<']';}std::cerr<<'\n';}
 const std::array binding{g::ShapeBinding{r.last_row,0}};const std::array variants{g::ExactShapeVariant{binding}};
 auto compiled=take(execution.compile(graph,r.constants,r.options({.shape_policy=g::CompileShapePolicy::kFiniteExact,.exact_variants=variants,.constants=r.constants})));
 compiled.executable=take(compiled.executable.exact_variant(0));compiled.report=take(compiled.report.exact_variant(0));
 auto queues=prepare_queue_bindings(execution,compiled.report);auto run=take(compiled.executable.create_invocation());
 Tensor values(execution.device(),dense(Type::kFloat32,{1,4}));Tensor ids(execution.device(),dense(Type::kInt32,{1}));Tensor keys(execution.device(),dense(Type::kUInt32,{1,4}));
 const std::array<std::int32_t,1> proposal{0};ids.write<std::int32_t>(proposal);const std::array<std::uint32_t,4> identity{1234,5678,1,0};keys.write<std::uint32_t>(identity);
 check(run.bind(input,values.read()));check(run.bind(q,values.read()));check(run.bind(bonus,values.read()));check(run.bind(id,ids.read()));check(run.bind(key,keys.read()));
 constexpr float inf=std::numeric_limits<float>::infinity(),nan=std::numeric_limits<float>::quiet_NaN();
 struct Case{const char*name;std::array<float,4> row;bool valid;};
 const std::array cases{Case{"finite-non-power-mass",{0,std::log(0.14776f),-inf,-inf},true},Case{"finite-non-power-mass-2",{-.138f,-3.47f,-.7f,-7.9f},true},Case{"zero-mass",{-inf,-inf,-inf,-inf},false},Case{"nan-unselected-column",{0,-1,nan,-2},false},Case{"positive-infinity-unselected-column",{0,-1,inf,-2},false}};
 for(const auto &test:cases){
  values.write<float>(test.row);check(run.prepare_replay(queue_span(queues),{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}));auto done=take(run.submit(queue_span(queues)));check(done.wait());
  std::cerr<<test.name;
  std::size_t port_index=0;for(auto value:ports){auto output=take(run.result(value));auto lease=take(output.storage_lease());float actual=-1;check(execution.read(take(lease.view()),std::as_writable_bytes(std::span(&actual,1))));std::cerr<<' '<<actual;if(port_index++<5 && actual!=(test.valid?1.f:0.f))throw std::runtime_error("mass validity mismatch");}
  std::cerr<<" PASS\n";
 }
 std::cout<<"PASS 5 actual Vulkan mass validity cases (15 predicate checks)\n";return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
