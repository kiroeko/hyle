#include "../../engine/models/qwen35/host_predicates.h"

#include <array>
#include <cstdio>
#include <cstring>
#include <limits>

namespace {
std::size_t checks = 0;
void require(bool value) {
  if (!value) throw std::runtime_error("host predicate transport differs");
  ++checks;
}
template<class F> void rejects(F &&function) {
  try { function(); }
  catch (const std::runtime_error &) { ++checks; return; }
  throw std::runtime_error("nonbinary host predicate was accepted");
}
}
int main() {
  try {
    for (float value : {0.0f, 1.0f}) {
      std::uint8_t output = 9;
      qwen35::read_host_predicates<true>(std::span(&output, 1), [&](std::span<std::byte> bytes) {
        require(bytes.size() == sizeof(float)); std::memcpy(bytes.data(), &value, sizeof(value));
      });
      require(output == static_cast<std::uint8_t>(value));
    }
    const std::array<float, 3> wide{0, 1, -0.0f};
    std::array<std::uint8_t, 3> output{};
    qwen35::read_host_predicates<true>(output, [&](std::span<std::byte> bytes) {
      require(bytes.size() == sizeof(wide)); std::memcpy(bytes.data(), wide.data(), bytes.size());
    });
    require((output == std::array<std::uint8_t, 3>{0, 1, 0}));
    qwen35::read_host_predicates<false>(output, [&](std::span<std::byte> bytes) {
      require(bytes.size() == output.size());
      const std::array<std::uint8_t, 3> direct{1, 0, 1};
      std::memcpy(bytes.data(), direct.data(), bytes.size());
    });
    require((output == std::array<std::uint8_t, 3>{1, 0, 1}));
    std::array<float, 17> larger{};
    std::array<std::uint8_t, 17> larger_output{};
    for (std::size_t i = 0; i < larger.size(); ++i) larger[i] = static_cast<float>(i % 2);
    qwen35::read_host_predicates<true>(larger_output, [&](std::span<std::byte> bytes) {
      require(bytes.size() == sizeof(larger)); std::memcpy(bytes.data(), larger.data(), bytes.size());
    });
    for (std::size_t i = 0; i < larger.size(); ++i)
      require(larger_output[i] == static_cast<std::uint8_t>(i % 2));
    for (float invalid : {0.25f, -1.0f, 2.0f, std::numeric_limits<float>::infinity(),
                          std::numeric_limits<float>::quiet_NaN()}) {
      rejects([&] { qwen35::read_host_predicates<true>(std::span(output).first(1),
          [&](std::span<std::byte> bytes) { std::memcpy(bytes.data(), &invalid, sizeof(invalid)); }); });
    }
    rejects([&] { qwen35::read_host_predicates<false>(std::span(output).first(1),
        [](std::span<std::byte> bytes) { bytes[0] = std::byte{2}; }); });
    std::size_t calls = 0;
    qwen35::read_host_predicates<true>({}, [&](auto) { ++calls; });
    qwen35::read_host_predicates<false>({}, [&](auto) { ++calls; });
    require(calls == 0);
    std::printf("PASS %zu host predicate checks\n", checks);
    return 0;
  } catch (const std::exception &error) { std::fprintf(stderr, "%s\n", error.what()); return 1; }
}
