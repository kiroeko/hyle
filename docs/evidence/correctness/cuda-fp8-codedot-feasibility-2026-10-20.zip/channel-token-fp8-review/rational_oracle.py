"""Exact, CPU-only E4M3FN oracle for the first cuBLASLt smoke witness.
No floating arithmetic contributes to expected/error/bounds; no third-party imports.
"""
import argparse
from fractions import Fraction
import json


def decode(bits):
    """Decode finite E4M3FN bits by integer exponent and exact rational arithmetic."""
    if not 0 <= bits < 256:
        raise ValueError("not one byte")
    exponent, fraction = (bits >> 3) & 15, bits & 7
    if exponent == 15 and fraction == 7:
        raise ValueError("NaN is outside this finite witness")
    if exponent == 0:
        value = Fraction(fraction, 512)
    else:
        significand = 8 + fraction
        shift = exponent - 10
        value = Fraction(significand * (1 << shift)) if shift >= 0 else Fraction(significand, 1 << -shift)
    return -value if bits & 128 else value


def code(index, seed, weight):
    if seed == 1 and not weight:
        return 0
    magnitude = (index * (17 if weight else 13) + seed * 7) % 127
    return magnitude | (128 if (index + seed) & 1 else 0)


def ratio(value):
    return {"numerator": value.numerator, "denominator": value.denominator,
            "display_float_only": float(value)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--observed", default="250992")
    args = ap.parse_args()
    assert decode(0) == 0 and decode(1) == Fraction(1, 512)
    assert decode(0x38) == 1 and decode(0x7e) == 448 and decode(0xfe) == -448
    k, seed = 128, 0
    products = [decode(code(i, seed, False)) * decode(code(i, seed, True)) for i in range(k)]
    expected = sum(products, Fraction())
    sum_abs = sum(map(abs, products), Fraction())
    assert expected == Fraction(2057661549, 8192)
    assert expected == sum_abs  # Every nonzero product in this witness has positive sign.
    observed = Fraction(args.observed)
    error = abs(observed - expected)
    u = Fraction(1, 1 << 24)
    gamma = k * u / (1 - k * u)
    gamma_bound = gamma * sum_abs
    # The actual smoke's slightly looser coefficient, independently re-evaluated.
    smoke_bound = max(Fraction(1, 10_000_000), sum_abs * k * Fraction(6, 100_000_000))
    # All finite E4M3 products in this domain are exactly representable as F32.
    result = {"m": 1, "k": k, "n": 64, "seed": seed, "row": 0, "column": 0,
              "expected": ratio(expected), "sum_abs": ratio(sum_abs), "observed": ratio(observed),
              "absolute_error": ratio(error), "f32_gamma128_bound": ratio(gamma_bound),
              "original_smoke_bound": ratio(smoke_bound),
              "violates_f32_bound": error > gamma_bound,
              "violates_original_smoke_bound": error > smoke_bound,
              "cpu_only": True, "weight_payload_read": False,
              "limitation": "Verifies the supplied observed scalar against an exact oracle; does not execute or identify GPU arithmetic."}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
