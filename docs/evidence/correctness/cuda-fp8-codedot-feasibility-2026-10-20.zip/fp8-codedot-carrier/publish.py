"""Publish the failed strict-math probe and offline decode attribution honestly."""
import hashlib
import json
from pathlib import Path
import zipfile
S=Path(__file__).resolve().parent; A=S.parent; ROOT=S.parents[2]

def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def identity(path):
    p=Path(path).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(path,data):
    Path(path).parent.mkdir(parents=True,exist_ok=True);Path(path).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def seal(stem,folder,files,body):
    unique={str(p.resolve()):p.resolve() for p in files if p.is_file()}
    rows=[];destination=ROOT/'docs/evidence'/folder/(stem+'.zip')
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for path in unique.values():
            row=identity(path);row['member']=str(path.relative_to(A)).replace('\\','/')
            rows.append(row);archive.writestr(row['member'],path.read_bytes())
        archive.writestr('payload-sha256.json',json.dumps(rows,indent=2))
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        for row in rows:
            data=archive.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    body.update(archive=identity(destination),payloads=rows,archive_verified=dict(CRC=True,all_payload_SHA256=True))
    save(destination.with_suffix('.json'),body)
    print('PUBLISHED',stem,len(rows),destination.stat().st_size,flush=True)

summary=read(S/'smoke-summary.json');corrected=read(A/'channel-token-fp8-review/corrected-review.json')
assert corrected['actual_evidence']['summary']==identity(S/'smoke-summary.json')
assert not summary['strict_f32_passed'] and summary['api_execution_passed']
deps=read(S/'smoke/smoke-deps.json')['Data']
save(S/'actual-compile-closure.json',dict(files=[identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])],
    note='Actual /sourceDependencies closure; directory names are not an SDK-version assertion. SDK/header/DLL payloads are not duplicated.'))
fp8=[p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in ('.py','.cc','.json','.log') and 'tmp' not in p.parts]
fp8 += [p for p in (A/'channel-token-fp8-review').glob('*') if p.is_file() and p.suffix.lower() in ('.json','.py')]
seal('cuda-fp8-codedot-feasibility-2026-10-20','correctness',fp8,dict(
    date='2026-10-20',scope='Independent native SDK feasibility and numeric-contract diagnosis; no Hyle FP8 GEMM product route was added.',
    conclusion='Seven actual Windows SM89 shapes execute and capture/replay, but all violate the existing strict F32 coded-dot reference error bound. Do not replace the public FP8 Cast/Cast/F32 MatMul subgraph with this carrier.',
    actual=summary,decision=dict(ordinary_F32_MatMul_fusion='withdrawn',FP8_native_scaled_contract='requires explicit design and numerical validation',
        quantization='CT Python QDQ and deployment token-scale recipes differ; channel/token metadata is not block128.'),
    independent_review=identity(A/'channel-token-fp8-review/corrected-review.json'),
    oracle=read(A/'channel-token-fp8-review/rational-oracle-result.json'),
    primary_sources=[dict(url='https://docs.nvidia.com/cuda/cublas/index.html#cublasltmatmuldescattributes-t',fact='FAST_ACCUM controls periodic higher-precision promotion; the flag is not a proof of ordinary F32 dot equivalence.'),
        dict(url='https://docs.nvidia.com/cuda/parallel-thread-execution/index.html#warp-level-matrix-instructions-mma',fact='FP8 MMA order, rounding and subnormal handling are not an IEEE per-FMA promise.')],
    limits=['No new FP8 model inference, accuracy, throughput or whole-model peak-memory claim.',
        'No fixed internal accumulation bit width or vendor-bug attribution is inferred from the numeric witness.',
        'The probe exit2 is the recorded strict-math failure, not a passed implementation test.']))

stage=A/'decode-major-hotspots';review=read(stage/'review.json')
assert review['qualified_high_share_defects']==0
seal('decode-major-hotspots-2026-10-20','performance',list(stage.glob('*.py'))+list(stage.glob('*.json')),dict(
    date='2026-10-20',scope='Offline analysis of retained actual current596 and peer558 traces, without a new profiler or benchmark run.',
    conclusion=review['conclusion'],kernel_counts=review['kernel_count_correction'],
    comparison_contract=review['comparison_contract'],large_work=review['large_work'],
    full_review=identity(stage/'review.json'),
    retained_trace_rule='Actual SQLite traces stay in their original stages/previous evidence bundles. This archive retains commands, hashes and offline sample analysis without another SDK or trace copy.',
    limits=['These profiled durations are attribution from different instrumented processes, not contemporaneous throughput or recoverable wall time.',
        'No new high-share defect found is not proof that all remaining architecture or performance work is complete.']))
