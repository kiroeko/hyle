#include <cuda_runtime_api.h>
#include <cublasLt.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <stdexcept>
#include <string>
#include <vector>

void check(cudaError_t result, const char *name) {
  if (result != cudaSuccess)
    throw std::runtime_error(std::string(name) + ": " + cudaGetErrorString(result));
}
void check(cublasStatus_t result, const char *name) {
  if (result != CUBLAS_STATUS_SUCCESS)
    throw std::runtime_error(std::string(name) + ": " + std::to_string(result));
}
template<class T> struct DeviceBuffer {
  T *pointer = nullptr;
  explicit DeviceBuffer(std::size_t count) {
    check(cudaMalloc(reinterpret_cast<void **>(&pointer), count * sizeof(T)), "cudaMalloc");
  }
  ~DeviceBuffer() { if (pointer) (void)cudaFree(pointer); }
};
struct Resources {
  cublasLtHandle_t handle = nullptr;
  cublasLtMatmulDesc_t operation = nullptr;
  cublasLtMatmulPreference_t preference = nullptr;
  std::array<cublasLtMatrixLayout_t, 3> layouts{};
  cudaStream_t stream = nullptr;
  cudaGraph_t graph = nullptr;
  cudaGraphExec_t executable = nullptr;
  ~Resources() {
    if (stream) (void)cudaStreamSynchronize(stream);
    if (executable) (void)cudaGraphExecDestroy(executable);
    if (graph) (void)cudaGraphDestroy(graph);
    if (stream) (void)cudaStreamDestroy(stream);
    for (auto layout : layouts) if (layout) (void)cublasLtMatrixLayoutDestroy(layout);
    if (preference) (void)cublasLtMatmulPreferenceDestroy(preference);
    if (operation) (void)cublasLtMatmulDescDestroy(operation);
    if (handle) (void)cublasLtDestroy(handle);
  }
};

// Independent finite E4M3FN decode, including subnormals and signed zeros.
double decode(std::uint8_t bits) {
  const int exponent = (bits >> 3) & 15;
  const int mantissa = bits & 7;
  const double magnitude = exponent == 0 ? std::ldexp(double(mantissa), -9)
      : std::ldexp(1.0 + double(mantissa) / 8.0, exponent - 7);
  return (bits & 128) ? -magnitude : magnitude;
}
std::uint8_t code(std::size_t index, int seed, bool weight) {
  if (seed == 1 && !weight) return 0;
  const auto magnitude = std::uint8_t((index * (weight ? 17 : 13) +
                                      std::size_t(seed) * 7) % 127);
  return std::uint8_t(magnitude | (((index + std::size_t(seed)) & 1) ? 128 : 0));
}

void run(int m, int k, int n) {
  Resources r;
  check(cublasLtCreate(&r.handle), "cublasLtCreate");
  check(cudaStreamCreateWithFlags(&r.stream, cudaStreamNonBlocking), "stream create");
  check(cublasLtMatmulDescCreate(&r.operation, CUBLAS_COMPUTE_32F, CUDA_R_32F), "desc create");
  const cublasOperation_t transpose = CUBLAS_OP_T, normal = CUBLAS_OP_N;
  const std::int8_t fast_accum = 0;
  check(cublasLtMatmulDescSetAttribute(r.operation, CUBLASLT_MATMUL_DESC_TRANSA,
      &transpose, sizeof(transpose)), "transA");
  check(cublasLtMatmulDescSetAttribute(r.operation, CUBLASLT_MATMUL_DESC_TRANSB,
      &normal, sizeof(normal)), "transB");
  check(cublasLtMatmulDescSetAttribute(r.operation, CUBLASLT_MATMUL_DESC_FAST_ACCUM,
      &fast_accum, sizeof(fast_accum)), "fast accumulation false");
  // Vendor Y^T = transpose(Wcodes col[K,N]) * Acodes col[K,M].
  // These are the original row[M,K] and row[N,K] allocations, without copies.
  check(cublasLtMatrixLayoutCreate(&r.layouts[0], CUDA_R_8F_E4M3, k, n, k), "layout W");
  check(cublasLtMatrixLayoutCreate(&r.layouts[1], CUDA_R_8F_E4M3, k, m, k), "layout A");
  check(cublasLtMatrixLayoutCreate(&r.layouts[2], CUDA_R_32F, n, m, n), "layout Y");
  DeviceBuffer<std::uint8_t> a(std::size_t(m) * k), w(std::size_t(n) * k);
  DeviceBuffer<float> out(std::size_t(m) * n), scales(2);
  const std::array<float, 2> ones{1.f, 1.f};
  check(cudaMemcpy(scales.pointer, ones.data(), sizeof(ones), cudaMemcpyHostToDevice), "unit scales");
  auto *one_a = scales.pointer, *one_b = scales.pointer + 1;
  check(cublasLtMatmulDescSetAttribute(r.operation, CUBLASLT_MATMUL_DESC_A_SCALE_POINTER,
      &one_a, sizeof(one_a)), "scale A pointer");
  check(cublasLtMatmulDescSetAttribute(r.operation, CUBLASLT_MATMUL_DESC_B_SCALE_POINTER,
      &one_b, sizeof(one_b)), "scale B pointer");
  check(cublasLtMatmulPreferenceCreate(&r.preference), "preference create");
  const std::size_t maximum = 32u * 1024 * 1024;
  check(cublasLtMatmulPreferenceSetAttribute(r.preference, CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,
      &maximum, sizeof(maximum)), "workspace maximum");
  const std::uint32_t alignment = 16;
  for (const auto attribute : {CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_A_BYTES,
                              CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_B_BYTES,
                              CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_C_BYTES,
                              CUBLASLT_MATMUL_PREF_MIN_ALIGNMENT_D_BYTES})
    check(cublasLtMatmulPreferenceSetAttribute(r.preference, attribute,
        &alignment, sizeof(alignment)), "alignment");
  cublasLtMatmulHeuristicResult_t algorithm{};
  int count = 0;
  check(cublasLtMatmulAlgoGetHeuristic(r.handle, r.operation, r.layouts[0], r.layouts[1],
      r.layouts[2], r.layouts[2], r.preference, 1, &algorithm, &count), "heuristic");
  if (count != 1) throw std::runtime_error("no FP8/F32 algorithm for shape");
  check(algorithm.state, "selected algorithm");
  DeviceBuffer<std::uint8_t> workspace((std::max)(algorithm.workspaceSize, std::size_t{1}));
  const float alpha = 1.f, beta = 0.f;
  const auto launch = [&] {
    check(cublasLtMatmul(r.handle, r.operation, &alpha, w.pointer, r.layouts[0],
        a.pointer, r.layouts[1], &beta, out.pointer, r.layouts[2], out.pointer,
        r.layouts[2], &algorithm.algo, workspace.pointer, algorithm.workspaceSize,
        r.stream), "FP8 code dot");
  };
  std::vector<std::uint8_t> av(std::size_t(m) * k), wv(std::size_t(n) * k);
  std::vector<float> result(std::size_t(m) * n);
  double max_error = 0, max_relative = 0;
  std::size_t comparisons = 0;
  for (int seed = 0; seed < 3; ++seed) {
    for (std::size_t i = 0; i < av.size(); ++i) av[i] = code(i, seed, false);
    for (std::size_t i = 0; i < wv.size(); ++i) wv[i] = code(i, seed, true);
    check(cudaMemcpy(a.pointer, av.data(), av.size(), cudaMemcpyHostToDevice), "upload A");
    check(cudaMemcpy(w.pointer, wv.data(), wv.size(), cudaMemcpyHostToDevice), "upload W");
    if (seed == 0) {
      launch(); // Original vendor first-use initialization, outside capture.
      check(cudaStreamSynchronize(r.stream), "first use");
      check(cudaStreamBeginCapture(r.stream, cudaStreamCaptureModeThreadLocal), "begin capture");
      launch();
      check(cudaStreamEndCapture(r.stream, &r.graph), "end capture");
      check(cudaGraphInstantiate(&r.executable, r.graph, 0), "graph instantiate");
    }
    check(cudaGraphLaunch(r.executable, r.stream), "graph replay");
    check(cudaStreamSynchronize(r.stream), "replay terminal");
    check(cudaMemcpy(result.data(), out.pointer, result.size() * sizeof(float), cudaMemcpyDeviceToHost), "readback");
    for (int row = 0; row < m; ++row) for (int col = 0; col < n; ++col) {
      double expected = 0, absolute_sum = 0;
      for (int inner = 0; inner < k; ++inner) {
        const double product = decode(av[std::size_t(row) * k + inner]) *
                               decode(wv[std::size_t(col) * k + inner]);
        expected += product;
        absolute_sum += std::abs(product);
      }
      const double actual = result[std::size_t(row) * n + col];
      const double error = std::abs(actual - expected);
      // FP32 accumulation admits reassociation; this is a forward-error bound,
      // never equivalence to an unrelated FP32 GEMM reduction tree.
      const double tolerance = (std::max)(1.e-7, absolute_sum * double(k) * 6.e-8);
      if (!std::isfinite(actual) || error > tolerance)
        throw std::runtime_error("independent F64 dot mismatch at " +
            std::to_string(row) + "," + std::to_string(col));
      max_error = (std::max)(max_error, error);
      max_relative = (std::max)(max_relative, error / (std::max)(absolute_sum, 1.e-30));
      ++comparisons;
    }
  }
  std::size_t graph_nodes = 0;
  check(cudaGraphGetNodes(r.graph, nullptr, &graph_nodes), "graph node count");
  std::printf("{\"m\":%d,\"k\":%d,\"n\":%d,\"workspace_bytes\":%zu,"
      "\"graph_nodes\":%zu,\"seeds\":3,\"oracle_comparisons\":%zu,"
      "\"max_absolute_error\":%.12g,\"max_error_over_sum_abs\":%.12g,\"passed\":true}\n",
      m, k, n, algorithm.workspaceSize, graph_nodes, comparisons, max_error, max_relative);
  std::fflush(stdout);
}
int main() {
  try {
    cudaDeviceProp device{};
    check(cudaGetDeviceProperties(&device, 0), "actual device");
    int runtime = 0, driver = 0;
    check(cudaRuntimeGetVersion(&runtime), "runtime version");
    check(cudaDriverGetVersion(&driver), "driver version");
    std::printf("{\"device\":\"%s\",\"sm\":%d,\"cuda_runtime\":%d,\"cuda_driver\":%d}\n",
        device.name, device.major * 10 + device.minor, runtime, driver);
    for (const auto shape : {std::array{1,128,64}, std::array{17,128,64},
         std::array{128,128,64}, std::array{1,2048,16}, std::array{17,2048,16},
         std::array{1,2048,512}, std::array{1,6144,2048}})
      run(shape[0], shape[1], shape[2]);
    return 0;
  } catch (const std::exception &e) {
    std::fprintf(stderr, "FP8_CODEDOT_FAILURE %s\n", e.what());
    return 1;
  }
}
