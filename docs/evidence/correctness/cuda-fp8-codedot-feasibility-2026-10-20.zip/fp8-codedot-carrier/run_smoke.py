"""Independent SDK feasibility probe; no Hyle product or SDK compilation."""
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
spec = importlib.util.spec_from_file_location('codedot_helpers', A/'paired-projection-route/build.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
b, c = h.b, h.c
base = c.read(A/'paired-projection-route/checks/native1/qwen-link-plan.json')
meta = h.h.h.metadata({'qwen':base})
owner = next(meta[c.key(row['path'])] for row in base['inputs']
             if c.key(row['path']) in meta and Path(meta[c.key(row['path'])]['source_path']).name == 'cublas_provider.cc')
out = S/'smoke'; out.mkdir(parents=True, exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
source = b.identity(S/'smoke.cc')
compile_command = b.host_command(owner['command'], Path(source['path']), 'smoke', out)
libraries = [row for row in base['inputs'] if Path(row['path']).name.lower() in ('cudart.lib','cublaslt.lib')]
assert len(libraries) == 2
env, runtime = b.environment(base['command'], [row['path'] for row in libraries], out)
image = out/'smoke.exe'
link = [base['command'][0], '/NOLOGO', '/MACHINE:X64', '/SUBSYSTEM:CONSOLE',
        str(out/'smoke.obj'), *[row['path'] for row in libraries], 'kernel32.lib',
        '/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map'))]
c.save(S/'smoke-plan.json', dict(source=source,compile=compile_command,link=link,
    libraries=libraries,runtime=runtime,product_changes=False,SDK_rebuild=False,
    expectation='SM89 native E4M3FN code dot, unit scalar device scales, F32 output; no throughput or whole-model claim'))
c.execute('compile', compile_command, env, out)
assert b.same(source)
c.execute('link', link, env, out)
c.save(out/'image.json',b.identity(image))
try:
    c.execute('run', [str(image)], env, out)
except RuntimeError:
    assert c.read(out/'run.result.json')['exit'] == 2, 'Unexpected API/runtime failure'
lines = (out/'run.stdout.log').read_text(encoding='utf-8').splitlines()
rows = [json.loads(line) for line in lines if line.startswith('{')]
shapes = [row for row in rows if 'm' in row]
modules = [b.identity(line.removeprefix('LOADED_MODULE ')) for line in lines if line.startswith('LOADED_MODULE ')]
c.save(S/'smoke-summary.json',dict(api_execution_passed=len(shapes)==7 and all(r['api_execution_passed'] for r in shapes),
    strict_f32_passed=len(shapes)==7 and all(r['strict_f32_passed'] for r in shapes),
    source=source,image=b.identity(image),rows=rows,loaded_modules=modules,limitations=[
        'Independent cuBLASLt feasibility, not an installed Hyle route or selected model execution.',
        'No scale quantization policy, throughput/peak-memory/quality acceptance or cross-platform claim.',
        'Numerical oracle allows FP32 accumulation reassociation; no unrelated F32 GEMM bitwise promise.']))
print('FP8_CODEDOT_OBSERVED', len(shapes), 'STRICT_F32', all(r['strict_f32_passed'] for r in shapes), flush=True)
