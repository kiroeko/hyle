#include <array>
#include <atomic>
#include <cstdio>
#include <span>
#include <utility>

#include <hyle/compute/cpu.h>
#include <hyle/compute/prepared_operation.h>
#include <hyle/graph/detail/lease_submission.h>
#include <hyle/mem/buffer.h>

namespace c = hyle::compute;
namespace g = hyle::graph::detail;
using hyle::Status;
struct Parent final {
  std::atomic<unsigned> refs{1}, terminals{0};
  std::atomic<bool> accepted{false};
  Status terminal;
};
Status run() {
  HYLE_ASSIGN_OR_RETURN(auto context, c::cpu::create_context({.native_threads = 1}));
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto description, c::TensorDesc::dense(c::DataType::kFloat32,
      std::array<std::int64_t, 1>{8}));
  HYLE_ASSIGN_OR_RETURN(auto operation, c::prepare(context, c::Binary{c::BinaryKind::kAdd},
      description, description));
  HYLE_ASSIGN_OR_RETURN(auto invocation, operation.create_invocation());
  HYLE_ASSIGN_OR_RETURN(auto pool, c::LeasePool::create(hyle::mem::system_resource(), 1024,
      {.max_blocks = 3}));
  std::array<c::ReadLease, 2> reads;
  const std::array<float, 8> first{1,2,3,4,5,6,7,8}, second{8,7,6,5,4,3,2,1};
  for (std::size_t i = 0; i < reads.size(); ++i) {
    HYLE_ASSIGN_OR_RETURN(auto writer, pool.allocate(32));
    HYLE_RETURN_IF_ERROR(writer.view()->write(std::as_bytes(std::span(i == 0 ? first : second))));
    HYLE_ASSIGN_OR_RETURN(reads[i], writer.publish());
  }
  HYLE_ASSIGN_OR_RETURN(auto unused, pool.allocate(32));
  HYLE_ASSIGN_OR_RETURN(auto output, hyle::mem::Buffer::create(hyle::mem::system_resource(), 32, 64));
  HYLE_ASSIGN_OR_RETURN(auto destination, c::TensorView::create(description, output.view()));
  HYLE_ASSIGN_OR_RETURN(auto a, reads[0].tensor(description));
  HYLE_ASSIGN_OR_RETURN(auto b, reads[1].tensor(description));
  const std::array inputs{a,b};
  HYLE_ASSIGN_OR_RETURN(auto permission, g::LeaseSubmission::create(1, 1, {.max_page_reads = 2}));
  HYLE_RETURN_IF_ERROR(permission.bind_pages(0, reads));
  Parent parent;
  for (unsigned step = 0; step < 32; ++step) {
    HYLE_RETURN_IF_ERROR(permission.begin(&parent,
        [](void *p) noexcept { static_cast<Parent *>(p)->refs.fetch_add(1); },
        [](void *p) noexcept { static_cast<Parent *>(p)->refs.fetch_sub(1); },
        [](void *p, Status status, bool accepted) noexcept {
          auto &owner = *static_cast<Parent *>(p);
          owner.terminal = std::move(status); owner.accepted.store(accepted);
          owner.terminals.fetch_add(1, std::memory_order_release);
        }));
    if (pool.stats().active_uses != 2) return Status::Internal("exact guard admission differs");
    auto submitted = invocation.submit(queue, inputs, std::span(&destination, 1));
    if (!submitted) {
      permission.finish(submitted.error(), false);
      return submitted.error();
    }
    auto completion = std::move(*submitted);
    HYLE_RETURN_IF_ERROR(permission.protect(completion));
    permission.finish(Status::Ok(), true);
    HYLE_RETURN_IF_ERROR(completion.wait());
    if (parent.terminals.load(std::memory_order_acquire) != step + 1 ||
        parent.refs.load() != 1 || !parent.accepted.load() || !parent.terminal.ok() ||
        pool.stats().active_uses != 0)
      return Status::Internal("real CPU completion did not retire exact guards");
    std::array<float, 8> actual;
    HYLE_RETURN_IF_ERROR(output.view().read(std::as_writable_bytes(std::span(actual))));
    for (auto value : actual) if (value != 9) return Status::Internal("CPU add math differs");
    HYLE_RETURN_IF_ERROR(unused.view()->write(std::as_bytes(std::span(actual))));
  }
  permission.clear(0); reads = {};
  HYLE_RETURN_IF_ERROR(context.close());
  std::puts("G02 owned groups: public CPU math, 32 actual completion retirements, unused block writable PASS");
  return Status::Ok();
}
int main() {
  const auto status = run();
  if (!status.ok()) std::fprintf(stderr, "%.*s\n", int(status.message().size()), status.message().data());
  return status.ok() ? 0 : 1;
}
