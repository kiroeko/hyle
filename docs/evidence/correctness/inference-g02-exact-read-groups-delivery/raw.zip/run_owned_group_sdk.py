from pathlib import Path
import hashlib, json, os, subprocess, sys, time

root = Path.cwd()
folder = root / '.scratch/inference-gaps/g02'
mode = sys.argv[1]
assert mode in ('shared', 'static')
candidate = '5ce0bed8acb54d67cb70423134b73a6afea421dd'
producer = root / '.scratch/build-compute-v2-dev'
base = Path('C:/h7') / ('g02-owned-groups-' + mode + '-sdk')
stage, prefix = base / 'staging', base / 'relocated'
source, build = base / 'consumer-source', base / 'consumer-build'
source.mkdir(parents=True, exist_ok=True)
environment = os.environ.copy()
for line in subprocess.check_output(['cmd', '/d', '/c', str(root / '.scratch/inference-gaps/g01/cpu-ragged-env.cmd')], text=True).splitlines():
    if '=' in line and not line.startswith('='):
        key, value = line.split('=', 1)
        environment[key] = value
result_file = folder / ('owned-groups-' + mode + '-sdk-result.json')
records = json.loads(result_file.read_text(encoding='utf-8'))['stages'] if result_file.exists() else []

def done(name):
    return next((row for row in reversed(records) if row['stage'] == name), {}).get('exit_code') == 0

def run(name, args):
    number = 1 + sum(row['stage'] == name for row in records)
    log = folder / f'owned-groups-{mode}-sdk-{name}-{number}.log'
    start = time.monotonic()
    with log.open('w', encoding='utf-8') as output:
        result = subprocess.run(args, env=environment, stdout=output, stderr=subprocess.STDOUT)
    row = {'stage': name, 'command': args, 'exit_code': result.returncode,
           'elapsed_seconds': time.monotonic() - start, 'log': str(log)}
    records.append(row)
    result_file.write_text(json.dumps({'candidate': candidate, 'mode': mode,
        'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'scope': 'source and relocated Graph detail seam plus original public CPU math/completion',
        'stages': records}, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(row), flush=True)
    if result.returncode:
        with log.open('rb') as data:
            data.seek(max(0, log.stat().st_size - 3200))
            print(data.read().decode('utf-8', errors='replace'), flush=True)
        raise SystemExit(result.returncode)

consumer = folder / 'owned_group_consumer.cc'
hook = folder / 'owned-group-sdk-project.cmake'
body = '''if(PROJECT_NAME STREQUAL "hyle")
 function(g02_owned_group_producer)
  add_executable(g02_owned_group_producer "@SOURCE@")
  target_compile_features(g02_owned_group_producer PRIVATE cxx_std_23)
  target_compile_options(g02_owned_group_producer PRIVATE /utf-8 /W4 /WX /wd4324)
  target_link_libraries(g02_owned_group_producer PRIVATE hyle::compute hyle::graph)
  hyle_stage_runtime(g02_owned_group_producer)
 endfunction()
 cmake_language(DEFER CALL g02_owned_group_producer)
endif()
'''.replace('@SOURCE@', consumer.as_posix())
if not hook.exists() or hook.read_text(encoding='utf-8') != body:
    hook.write_text(body, encoding='utf-8')
if not done('configure'):
    run('configure', ['cmake', '-S', str(root), '-B', str(producer),
        '-DCMAKE_PROJECT_INCLUDE=' + str(hook), '-UCMAKE_PROJECT_TOP_LEVEL_INCLUDES',
        '-DHYLE_COMPONENTS=compute;graph', '-DHYLE_COMPUTE_ROUTES=cpu',
        '-DHYLE_BUILD_TESTS=OFF', '-DHYLE_BUILD_BENCH=OFF', '-DHYLE_INSTALL=ON',
        '-DHYLE_STATIC=' + ('ON' if mode == 'static' else 'OFF')])
if not done('producer-build'):
    run('producer-build', ['cmake', '--build', str(producer), '--target', 'g02_owned_group_producer', '--parallel', '4'])
if not done('source-run'):
    run('source-run', [str(producer / 'bin/g02_owned_group_producer.exe')])
if not done('install'):
    assert not prefix.exists()
    run('install', ['cmake', '--install', str(producer), '--prefix', str(stage)])
if stage.exists():
    assert not prefix.exists()
    stage.rename(prefix)
assert prefix.is_dir() and not stage.exists()
destination = source / 'consumer.cc'
data = consumer.read_bytes()
if not destination.exists() or destination.read_bytes() != data:
    destination.write_bytes(data)
header = source / 'header.cc'
header.write_text('#include <hyle/graph/detail/lease_submission.h>\nint main() { hyle::graph::detail::LeaseSubmission s; return s.valid(); }\n', encoding='utf-8')
cmake = source / 'CMakeLists.txt'
cmake.write_text('''cmake_minimum_required(VERSION 3.25)
project(g02_owned_groups LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS compute graph)
add_executable(consumer consumer.cc)
add_executable(header header.cc)
foreach(name consumer header)
 target_compile_features(${name} PRIVATE cxx_std_23)
 target_compile_options(${name} PRIVATE /utf-8 /W4 /WX /wd4324)
 target_link_libraries(${name} PRIVATE hyle::compute hyle::graph)
 hyle_stage_runtime(${name})
endforeach()
''', encoding='utf-8')
if not done('consumer-configure'):
    run('consumer-configure', ['cmake', '-S', str(source), '-B', str(build), '-G', 'Ninja',
        '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_PREFIX_PATH=' + str(prefix)])
if not done('consumer-build'):
    run('consumer-build', ['cmake', '--build', str(build), '--parallel', '4'])
for name in ['consumer', 'header']:
    if not done('run-' + name):
        run('run-' + name, [str(build / (name + '.exe'))])
files = [consumer, destination, header, cmake, hook, producer / 'CMakeCache.txt',
         prefix / 'include/hyle/graph/detail/lease_submission.h',
         *build.glob('*.exe'), *build.glob('*.dll'),
         *(prefix / 'lib').glob('hyle*.lib'), *(prefix / 'bin').glob('*.dll')]
(folder / ('owned-groups-' + mode + '-sdk-inputs.json')).write_text(json.dumps({
    'candidate': candidate, 'prefix': str(prefix), 'staging_absent': not stage.exists(),
    'hashes': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files if path.is_file()}
}, indent=2) + '\n', encoding='utf-8')
