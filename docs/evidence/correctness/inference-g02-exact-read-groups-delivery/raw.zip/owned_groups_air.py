from pathlib import Path
import hashlib, json, os, subprocess, time, zipfile

base = Path('/Users/kiro/hyle-scratch/compute-unified')
source = base / 'source-c8874688'
out = base / 'g02-owned-groups-native-consumers'
out.mkdir(exist_ok=True)
assert source.is_dir() and not (source / '.git').exists()
identity = {name: subprocess.check_output(args, text=True).strip() for name, args in [
    ('model', ['/usr/sbin/sysctl', '-n', 'hw.model']), ('arch', ['uname', '-m']),
    ('os', ['sw_vers']), ('compiler', ['xcrun', 'clang', '--version']),
    ('cpu', ['/usr/sbin/sysctl', '-n', 'hw.ncpu']), ('memory', ['/usr/sbin/sysctl', '-n', 'hw.memsize'])]}
assert identity['model'] == 'Mac16,12' and identity['arch'] == 'arm64'
with zipfile.ZipFile(out / 'input.zip') as archive:
    manifest = json.loads(archive.read('input-manifest.json'))
    copied = []
    for item in manifest:
        relative = Path(item['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        data = archive.read(item['path'])
        assert hashlib.sha256(data).hexdigest() == item['sha256']
        dest = source / relative
        if not dest.exists() or dest.read_bytes() != data:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)  # Changed bytes get this machine's current mtime.
            copied.append(item['path'])
        assert hashlib.sha256(dest.read_bytes()).hexdigest() == item['sha256']
(out / 'synced-inputs.json').write_text(json.dumps({'candidate': '5ce0bed8acb54d67cb70423134b73a6afea421dd',
    'one_way': True, 'source': str(source), 'inputs': manifest, 'copied': copied}, indent=2) + '\n')
env = os.environ.copy()
env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:' + env['PATH']
record = out / 'result.json'
rows = json.loads(record.read_text())['stages'] if record.exists() else []

def run(route, stage, args):
    number = 1 + sum(row['route'] == route and row['stage'] == stage for row in rows)
    log = out / f'{route}-{stage}-{number}.log'
    start = time.monotonic()
    with log.open('w') as output:
        result = subprocess.run(args, env=env, stdout=output, stderr=subprocess.STDOUT)
    row = {'route': route, 'stage': stage, 'command': args, 'exit_code': result.returncode,
           'elapsed_seconds': time.monotonic() - start, 'log': str(log)}
    rows.append(row)
    record.write_text(json.dumps({'candidate': '5ce0bed8acb54d67cb70423134b73a6afea421dd',
        'identity': identity, 'scope': 'original real CPU+Apple/Vulkan ordinary leased consumers; no new paged math claim',
        'stages': rows}, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if result.returncode:
        with log.open('rb') as data:
            data.seek(max(0, log.stat().st_size - 3000))
            print(data.read().decode('utf-8', errors='replace'), flush=True)
        raise SystemExit(result.returncode)

for route, target in [('apple', 'hyle_h2_contracts'), ('vulkan', 'hyle_h3_cpu_vulkan_contracts')]:
    build = base / f'a-cpu-{route}/selected-graph/source-build'
    parent = base / f'a-cpu-{route}/selected-graph/source-parent'
    cache = (build / 'CMakeCache.txt').read_text().splitlines()
    assert str(parent) == next(s.split('=', 1)[1] for s in cache if s.startswith('CMAKE_HOME_DIRECTORY:'))
    assert 'cpu' in next(s.split('=', 1)[1] for s in cache if s.startswith('HYLE_COMPUTE_ROUTES:')).split(';')
    run(route, 'build', ['/opt/homebrew/bin/cmake', '--build', str(build), '--target', target, '--parallel', '4'])
    exe = build / target
    assert exe.is_file(), str(exe)
    run(route, 'run', [str(exe)])
    commands = json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja', '-C', str(build), '-t', 'compdb'], text=True))
    checked = []
    for name in ['src/graph/lease_submission.cc', f'src/graph_route_cpu_{route}/invocation.cc', f'tests/graph/cpu_{route}_contracts.cc']:
        found = [item for item in commands if item['file'].endswith(name)]
        assert found, name
        checked.extend(found)
    (out / f'{route}-compiled-inputs.json').write_text(json.dumps(checked, indent=2) + '\n')
with zipfile.ZipFile(out / 'raw.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in out.iterdir():
        if path.is_file() and path.suffix in ['.json', '.log', '.py']:
            archive.write(path, path.name)
