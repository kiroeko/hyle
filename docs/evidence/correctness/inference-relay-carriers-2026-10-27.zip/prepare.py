"""Prepare bounded relay-carrier recipes. Never compile, link, freeze, or run."""
from pathlib import Path
import hashlib
import json

W = Path(__file__).resolve().parent
R = W.parents[1]
CLI = R / '.scratch/inference-engine-slot-state-20261027'
TEST = R / '.scratch/inference-pending-indexed-source-20261027'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def key(path):
    return str(Path(path).resolve()).lower()


def pin(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def dependency(row):
    obj = Path(row['path'])
    for path in (obj.parent / 'dependencies.json',
                 obj.with_name(obj.stem + '-deps.json'), obj.with_suffix('.deps.json')):
        if not path.is_file():
            continue
        data = read(path)
        data = data.get('Data', {}) if isinstance(data, dict) else {}
        if data.get('Source'):
            return path, data
    return None, None


def index(rows):
    result = {}
    for row in rows:
        path, data = dependency(row)
        if data:
            source = key(data['Source'])
            assert source not in result, ('duplicate compiler Source', source)
            result[source] = dict(object=row, dependencies=pin(path), data=data)
    return result


def recipe(record):
    path = Path(record['object']['path']).parent / 'command.json'
    assert path.is_file(), path
    argv = read(path)['command']
    # Identity is taken from compiler Data.Source, never the directory label.
    assert sum(key(arg) == key(record['data']['Source'])
               for arg in argv if arg.lower().endswith(('.cc', '.cpp', '.cxx'))) == 1
    return path, argv


def build_contract(argv):
    selected = ('/md', '/mt', '/o2', '/od', '/ehsc', '/dhyle_static',
                '/std:c++latest', '/std:c++20', '/std:c++23', '/permissive-')
    return dict(compiler=key(argv[0]),
                flags=sorted(arg.lower() for arg in argv if arg.lower() in selected),
                definitions=sorted(arg for arg in argv if arg.lower().startswith('/d')),
                abi_flags=sorted(arg.lower() for arg in argv
                                 if arg.lower().startswith(('/zc:', '/zp', '/gr', '/eh'))))


def compile_command(template, source, out):
    command = []
    for i, arg in enumerate(template):
        if i and template[i - 1].lower() == '/sourcedependencies':
            arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(out / 'unit.pdb')
        elif arg.lower().endswith(('.cc', '.cpp', '.cxx')):
            arg = str(source)
        command.append(arg)
    # Both model and weights must see the same Backend private endpoint layout.
    # The retained CLI was CUDA-only, while its closure already has CPU routes.
    if '/DHYLE_COMPUTE_CPU=1' not in command:
        command.insert(1, '/DHYLE_COMPUTE_CPU=1')
    assert '/DHYLE_COMPUTE_CUDA=1' in command
    assert '/DHYLE_STATIC' in command and '/MD' in command and '/O2' in command
    assert not any('HYLE_PREFIX_CACHE_STANDALONE' in arg for arg in command)
    for arg in command:
        if arg.lower().startswith('/i'):
            include = Path(arg[2:])
            assert not include.is_relative_to(R / '.scratch'), ('stale product include', arg)
    return command


def link_command(template, substitutions, added, image):
    command = []
    seen = set()
    for arg in template:
        mapped = substitutions.get(key(arg)) if arg.lower().endswith(('.obj', '.lib')) else None
        if mapped:
            seen.add(key(arg))
            arg = mapped
        elif arg.lower().startswith('/out:'):
            arg = '/OUT:' + str(image)
        elif arg.lower().startswith('/pdb:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.lower().startswith('/implib:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    assert seen == set(substitutions), ('missing original link inputs', set(substitutions) - seen)
    command.extend(added)
    for prefix in ('/out:', '/pdb:', '/implib:'):
        outputs = [arg for arg in command if arg.lower().startswith(prefix)]
        assert len(outputs) == 1 and Path(outputs[0][len(prefix):]).is_relative_to(W), outputs
    return command


def main():
    assert not (W / 'plan.json').exists(), 'Do not overwrite an earlier prepared attempt'
    old = read(CLI / 'formal2-link-inputs.json')
    current = read(TEST / 'link-inputs.json')
    assert len(old) == 224 and len(current) == 234
    # Verify retained objects/libraries only; old, deleted EXEs are not prerequisites.
    checked = {}
    for row in old + current:
        if key(row['path']) not in checked:
            checked[key(row['path'])] = pin(row['path'])
        assert checked[key(row['path'])] == row, row['path']
    old_index, new_index = index(old), index(current)
    replacements, review = {}, []
    for source, before in old_index.items():
        after = new_index.get(source)
        if not after or before['object'] == after['object']:
            continue
        old_recipe, old_argv = recipe(before)
        new_recipe, new_argv = recipe(after)
        assert build_contract(old_argv) == build_contract(new_argv), source
        replacements[key(before['object']['path'])] = after['object']
        review.append(dict(source=source, old=before['object'], replacement=after['object'],
                           old_dependencies=before['dependencies'],
                           replacement_dependencies=after['dependencies'],
                           old_recipe=pin(old_recipe), replacement_recipe=pin(new_recipe),
                           build_contract=build_contract(new_argv)))
    assert len(review) == 12
    current_by_path = {key(row['path']): row for row in current}
    unmapped = [row for row in old if key(row['path']) not in
                {key(entry['object']['path']) for entry in old_index.values()}]
    assert len(unmapped) == 67
    assert all(current_by_path.get(key(row['path'])) == row for row in unmapped)
    save(W / 'replacement-review.json', dict(replacements=review,
         unmapped_native_and_library_inputs=unmapped,
         boundary='All 67 non-Data.Source inputs are the same exact paths/bytes/hashes in both successful closures. No native ABI or SDK rebuild is inferred from directory names.'))

    header_names = {'session_state.h', 'readback.h'}
    consumers = []
    for label, entries in [('cli', old_index), ('test', new_index)]:
        for source, entry in entries.items():
            matching = [arg for arg in entry['data'].get('Includes', [])
                        if Path(arg).name.lower() in header_names]
            if matching:
                consumers.append(dict(closure=label, source=source,
                                      headers=matching, dependencies=entry['dependencies']))
    assert {Path(row['source']).name for row in consumers} == {'main.cc', 'weights.cc'}
    save(W / 'header-consumers.json', consumers)

    formal_template = read(CLI / 'recipes3/formal.json')['command']
    weights = old_index[key(R / 'engine/models/qwen35/weights.cc')]
    weights_recipe, weights_template = recipe(weights)
    units = []
    specifications = [
        ('model', 'engine/models/qwen35/main.cc', formal_template,
         old_index[key(R / 'engine/models/qwen35/main.cc')]['object']),
        ('weights', 'engine/models/qwen35/weights.cc', weights_template, weights['object']),
        ('cache-plan-test', 'tests/tools/qwen_prefix_cache_test.cc', formal_template, None),
        ('readback-test', 'tests/tools/qwen_backend_cpu_cuda_test.cc', formal_template, None),
    ]
    for name, source, template, previous in specifications:
        output = W / 'compile' / name
        command = compile_command(template, R / source, output)
        target = W / 'recipes' / (name + '.json')
        save(target, dict(command=command, cwd=str(R), timeout_seconds=180))
        units.append(dict(name=name, source=str(R / source), source_frozen=False,
                          command=pin(target), object=str(output / 'unit.obj'),
                          replaces=previous))

    cli_inputs = [replacements.get(key(row['path']), row) for row in old]
    cli_substitutions = {key(row['path']): replacements[key(row['path'])]['path']
                         for row in old if key(row['path']) in replacements}
    for unit in units[:2]:
        cli_substitutions[key(unit['replaces']['path'])] = unit['object']
        cli_inputs = [dict(path=unit['object'], status='PLANNED_NOT_BUILT')
                      if key(row['path']) == key(unit['replaces']['path']) else row for row in cli_inputs]
    cli_link_template = CLI / 'formal2-link/command.json'
    test_link_template = TEST / 'link/command.json'
    cli_image = W / 'bin/hyle.exe'
    test_image = W / 'bin/relay-carrier-test.exe'
    cli_command = link_command(read(cli_link_template)['command'], cli_substitutions, [], cli_image)
    test_command = link_command(read(test_link_template)['command'], {},
                                [unit['object'] for unit in units[2:]], test_image)
    save(W / 'recipes/link-cli.json', dict(command=cli_command, cwd=str(R), timeout_seconds=120))
    save(W / 'recipes/link-test.json', dict(command=test_command, cwd=str(R), timeout_seconds=120))
    save(W / 'planned-cli-inputs.json', cli_inputs)
    save(W / 'planned-test-inputs.json', current +
         [dict(path=unit['object'], status='PLANNED_NOT_BUILT') for unit in units[2:]])
    assert len(cli_inputs) == 224

    # Tiny input payloads remain in their already populated cache. New files are
    # only two short schedules and I32 prompts; no model files are copied.
    fixture = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    assert (fixture / 'weights.tsv').is_file() and (fixture / 'prompt.ids').is_file()
    case = W / 'case'
    case.mkdir(parents=True, exist_ok=True)
    for label, ids in [('A', '1 2 3\n'), ('B', '4 5 6\n')]:
        (case / (label + '.ids')).write_text(ids, encoding='utf-8')
        (case / (label + '.schedule')).write_text('prompt ' + label + '.ids\ngenerate 8\n', encoding='utf-8')
    sessions = case / 'sessions.tsv'
    sessions.write_text('A A.schedule\nB B.schedule\n', encoding='utf-8')
    journeys = []
    for backend in ['cpu', 'cuda']:
        for mtp in [False, True]:
            name = backend + ('-mtp-k3-b2' if mtp else '-ordinary-b2')
            argv = [str(cli_image), '--inputs', str(fixture), '--backend', backend,
                    '--session-schedules', str(sessions), '--capacity', '16',
                    '--max-sessions', '4', '--active-sequences', '2', '--prefix-cache', 'off',
                    '--sampling', 'greedy', '--mtp', 'on' if mtp else 'off',
                    '--progress', 'direct', '--replay', 'commands']
            if mtp:
                argv.extend(['--mtp-max-drafts', '3'])
            journeys.append(dict(name=name, command=argv, cwd=str(W), timeout_seconds=90,
                                 status='PROPOSED_NOT_RUN',
                                 expected=dict(backend=backend, mtp=mtp, session_count=2,
                                               generated_tokens_per_session=8,
                                               admitted_requests=2, retired_requests=2,
                                               live_committed_versions=0),
                                 check='Complete JSON output, actual logical batch widths, original final states and retirement; untrained fixture is not a quality oracle.'))
    tests = ['QwenSessionState.BatchCapacityPreservesSingleAndBoundsAllCandidates',
             'QwenBackendCpuCuda.ReadbackKeepsTheOriginalLeasedOutputAcrossReplayAndReclaim',
             'QwenBackendCpuCuda.ReadbackI32WriterSupportsTheOriginalSubmissionSource']
    save(W / 'run-plan.json', dict(status='PROPOSED_NOT_RUN',
         test=dict(command=[str(test_image), '--gtest_filter=' + ':'.join(tests),
                            '--gtest_output=xml:' + str(W / 'run-test/results.xml')],
                   cwd=str(W), timeout_seconds=120, expected_tests=tests),
         cli=journeys, ordering='One test process, then four CLI processes sequentially; stop at the first real failure.',
         environment=dict(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1'),
         scope='Finite CPU/CUDA carrier/readback and B2 ordinary/MTP functional checks; no full-model pipeline, throughput, capture, Apple/Vulkan, SDK/NVCC, or download claim.'))
    cli_runtime = read(CLI / 'formal2-runtime.json')
    test_runtime = read(read(TEST / 'ready.json')['runtime']['path'])
    native = cli_runtime['native_cpu']
    assert pin(native['path']) == native
    save(W / 'runtime-plan.json', dict(cli_record=pin(CLI / 'formal2-runtime.json'),
         test_record=pin(read(TEST / 'ready.json')['runtime']['path']),
         native_cpu=native, planned_alias=str(W / 'bin' / Path(native['path']).name),
         alias_action='Create a hardlink only when the new images are built; never copy/rebuild the SDK.',
         PATH=str(W / 'bin') + ';' + cli_runtime['PATH'],
         test_PATH=str(W / 'bin') + ';' + test_runtime['PATH']))
    save(W / 'plan.json', dict(status='PREPARED_NOT_FROZEN_NOT_BUILT_NOT_RUN',
         baseline=dict(cli_ready=pin(CLI / 'formal2-ready.json'),
                       cli_inputs=pin(CLI / 'formal2-link-inputs.json'),
                       cli_compile_template=pin(CLI / 'recipes3/formal.json'),
                       matching_weights_template=pin(weights_recipe),
                       cli_link_template=pin(cli_link_template),
                       component_ready=pin(TEST / 'ready.json'),
                       component_inputs=pin(TEST / 'link-inputs.json'),
                       component_link_template=pin(test_link_template)),
         units=units, compiler_contract=build_contract(formal_template),
         images=[str(test_image), str(cli_image)],
         counts=dict(CXX_TUs=4, links=2, test_processes=1, exact_GTests=3,
                     CLI_processes=4, CLI_link_inputs=224, test_link_inputs=236,
                     reused_product_replacements=12, SDK=0, NVCC=0, downloads=0),
         required_before_build=['Root confirms main/header/test source freeze.',
             'Record current complete source/dependency hashes and required snapshots then validate every frozen byte.',
             'Recheck any changed cached object against its original compiler Data.Source and matching flags.',
             'Run only after explicit root authorization; this prepare script has no build/run operation.'],
         model_source='Not hashed or frozen here: root is still editing main.cc.',
         header_scope='Plan/readback actual retained consumers are model+weights. Prefix and Backend tests are new objects in this image; no source-including probe object is linked.',
         private_ABI='All four newly compiled TUs share CPU+CUDA Backend defines. Plan and PreparedReadback consumers are recompiled; Graph/Compute/native objects come from the already validated 234-input closure.',
         output_paths='Every OUT/PDB/IMPLIB and new compiler output is under this scratch. Deleted old EXEs are never read or rebuilt.'))
    print('PREPARED: 4 CXX, 2 links, 3 GTests, 4 B2 tiny CLI journeys. No build/run/freeze.')


if __name__ == '__main__':
    main()
