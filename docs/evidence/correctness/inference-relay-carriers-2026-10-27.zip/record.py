from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
A = W / 'attempt2'
D = R / 'docs/evidence/correctness'

def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p, value):
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

summary = read(A/'summary.json')
assert summary['status'] == 'PASS' and len(summary['results']) == 5
ready = read(A/'ready.json')
files = []
allowed = {'.py', '.json', '.xml', '.log', '.cc', '.h', '.ids', '.schedule', '.tsv'}
for p in A.rglob('*'):
    if p.is_file() and p.suffix in allowed:
        files.append(p)
for name in ['prepare.py', 'check.py', 'plan.json', 'frozen-plan.json',
             'source-freeze.json', 'build-failure.json', 'record.py']:
    p = W/name
    if p.is_file(): files.append(p)
for p in (W/'compile/model').rglob('*'):
    if p.is_file() and p.suffix in {'.log', '.json'}: files.append(p)
assert not any(p.suffix in {'.obj', '.exe', '.dll', '.lib', '.pdb'} for p in files)
bundle = D/'inference-relay-carriers-2026-10-27.zip'
assert not bundle.exists()
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):
        z.write(p, p.relative_to(W).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    members = z.namelist()
    assert len(members) == len(set(members)) == len(set(files))
    for p in set(files):
        assert z.read(p.relative_to(W).as_posix()) == p.read_bytes()
report = dict(status='PASS', date='2026-10-27',
    scope='Per-slot IO, depth-aware capacity, original leased readback. Engine remains single-slot; no complete model overlap or throughput claim.',
    changes=['Plan N+K*D*R states, N+D*R versions and D*R COW tails; per-batch mathematical extents unchanged; default D=1.',
        'Phase owns IO/readback/layout per real execution slot. Ordinary Text [B*T,1] is viewed as [B*T] for embedding.',
        'Nonempty caller readback transfers full original WriteLease to Graph; repeated replay, source pin and reclaim/reset use original ownership gates.'],
    counts=dict(distinct_CXX_TUs=4, CXX_attempts=5, links=2, GTest_processes=1,
                GTests=3, CLI_processes=4, SDK_rebuilds=0, NVCC=0, downloads=0),
    results=summary['results'], images=ready['artifacts'],
    retained_failure='First model compile rejected !LeasePool, fixed to .valid(); no successful stale model object reused. Nested attempt script initially resolved repository root one level short, corrected before freeze/build.',
    cache_reuse=dict(cli_inputs=224, test_inputs=236, product_objects_updated_from_current_closure=12,
        note='Original compiler Data.Source and matching flags identify reused objects. main and weights both rebuilt with CPU+CUDA Backend configuration.'),
    source_freeze=read(A/'frozen-plan.json')['snapshots'],
    uncompiled_diagnostics=summary['uncompiled_diagnostics'],
    limitations=['Untrained tiny fixture verifies execution/retirement, not model quality.',
        'Commands replay only; no new capture, Apple, Vulkan, Linux or full performance run.',
        'Actual scheduler depth remains one; pending device token, full state Source rotation and ordered successor publication are not integrated.',
        'An additive copy queue query declaration was independently sampled during compilation; it was unused by these linked TUs, then removed. No layout change or new query use is claimed.'],
    next='Isolate metadata upload Queue using original Compute Queue/lease/retirement mechanisms, then integrate original Source and ordered model successor.',
    evidence=dict(bundle=pin(bundle), members=len(members)))
target = D/'inference-relay-carriers-2026-10-27.json'
assert not target.exists()
save(target, report)
print(json.dumps(dict(report=pin(target), bundle=pin(bundle), members=len(members))))
