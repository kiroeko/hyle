#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_midturn_resume_case.h"

int main(int argc, char **argv) {
  try {
    if (argc == 1) return 77;
    if (argc != 2) throw std::runtime_error("midturn-resume PRIVATE_CACHED_FIXTURE_DIRECTORY");
    return qwen_midturn_resume_case::run(std::filesystem::path(argv[1]));
  } catch (const std::exception &error) {
    std::cerr << "midturn_resume_failure=" << error.what() << '\n';
    return 1;
  }
}
