"""One finite CPU app/130-input retained link; no SDK/core/provider build."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
R = Path.cwd()
W = R/'.scratch/inference-midturn-resume-20261025/implementation'
OLD = R/'.scratch/inference-ordinary-boundaries-20261025/retirement-implementation'
CACHED = OLD/'attempt2'
SF = Path('engine/inference/sampling_graph.h')
spec = importlib.util.spec_from_file_location('cached_commands', R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')


def commands():
    original = b.args(CACHED/'compile/command.json')
    command = [original[0], '/I'+str(W/'source')]
    skip = False
    for arg in original[1:]:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        if 'retirement-implementation' in arg:
            continue
        command.append(arg)
    command += [str(W/'consumer.cc'), '/sourceDependencies', str(W/'attempt1/compile/dependencies.json'),
                '/Fo'+str(W/'attempt1/compile/unit.obj'), '/Fd'+str(W/'attempt1/compile/unit.pdb')]
    link, replaced = [], 0
    for arg in b.args(CACHED/'link/command.json'):
        if arg.lower().startswith(('/out:', '/pdb:', '/implib:')): continue
        if Path(arg) == CACHED/'compile/unit.obj':
            arg = str(W/'attempt1/compile/unit.obj'); replaced += 1
        link.append(arg)
    assert replaced == 1
    link += ['/OUT:'+str(W/'attempt1/link/component.exe'), '/PDB:'+str(W/'attempt1/link/component.pdb'),
             '/IMPLIB:'+str(W/'attempt1/link/component.lib')]
    return command, link


def prepare():
    # Reuse only the exact self-written header inventory consumed last time.
    # Borrow current canonical bytes, not the previous sampling implementation.
    support = []
    for item in b.read(CACHED/'compile/repository-inputs.json'):
        path = Path(item['path'])
        if not path.is_relative_to(OLD/'source'): continue
        relative = path.relative_to(OLD/'source')
        if relative == SF or (W/'source'/relative).exists(): continue
        if relative.parts[0] != 'engine': continue
        original = R/relative
        for base in [W/'before', W/'source']:
            target = base/relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(original.read_bytes())
        support.append(b.pin(W/'source'/relative))
    extra = Path('engine/inference/output_delivery.h')
    for base in [W/'before', W/'source']:
        target = base/extra
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((R/extra).read_bytes())
    command, link = commands()
    inputs = [b.pin(Path(x)) for x in link if Path(x).is_absolute() and
              Path(x).suffix.lower() in {'.obj', '.lib'} and Path(x) != W/'attempt1/compile/unit.obj']
    assert len(inputs) == 129
    prior = b.read(OLD/'execution-plan2.json')
    save(W/'recipe.json', dict(status='PREPARED_WAITING_ROOT_STABLE_SAMPLING_HEADER',
        compile=command, link=link, common_inputs=inputs, total_link_inputs=130,
        native=prior['native'], runtime=prior['runtime'], fixture=prior['fixture'], fixture_body=prior['fixture_body'],
        compile_template=b.pin(CACHED/'compile/command.json'), link_template=b.pin(CACHED/'link/command.json'),
        source_main=b.pin(W/'source/engine/models/qwen35/main.cc'),
        sampling_header='NOT_FROZEN; exclude old retirement sampling_graph.h; await root exact canonical stable SHA',
        process_argv=[str(W/'attempt1/link/component.exe'),str(Path(prior['fixture']['path']).parent)],
        watchdog_seconds=120, SDK_TUs=0, core_TUs=0, provider_TUs=0, GPU=False, HTTP=0))
    save(W/'support-pins.json', support)
    print('Recipe ready: one app TU +129 retained inputs; sampling header intentionally not frozen. No compile/run.')


def freeze_sampling(expected):
    assert b.pin(R/SF)['sha256'] == expected
    for base in [W/'before', W/'source']:
        target = base/SF
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((R/SF).read_bytes())
    save(W/'sampling-header.json', dict(canonical=b.pin(R/SF), frozen=b.pin(W/'source'/SF),
        root_stable_sha256=expected, changed_by_this_slice=False))
    print('Root stable canonical sampling header frozen; still no compile/run.')


def build():
    plan = b.read(W/'recipe.json')
    header = b.read(W/'sampling-header.json')
    for item in [header['canonical'], header['frozen'], *plan['common_inputs'], plan['native'],
                 plan['runtime'], plan['fixture'], plan['fixture_body']]:
        assert b.pin(Path(item['path'])) == item
    sources = [b.pin(p) for p in sorted((W/'source').rglob('*')) if p.is_file()]+[b.pin(W/'consumer.cc')]
    save(W/'attempt1/source-pins.json', sources)
    env = b.environment(plan['compile'][0])
    b.execute(plan['compile'], W/'attempt1/compile', env, 150)
    dep = b.read(W/'attempt1/compile/dependencies.json')['Data']
    own = []
    for name in [dep['Source'], *dep['Includes']]:
        path = Path(name)
        if path.is_relative_to(R): own.append(b.pin(path))
        assert not path.is_relative_to(R/'engine'), ('canonical engine include leak',path)
        assert not path.is_relative_to(OLD/'source'), ('old private include leak',path)
    assert any(Path(x['path']) == W/'source'/SF for x in own)
    save(W/'attempt1/compile/repository-inputs.json', own)
    b.execute(plan['link'], W/'attempt1/link', env, 90)
    native = Path(plan['native']['path'])
    os.link(native,W/'attempt1/link'/native.name)
    save(W/'attempt1/link/ready.json',dict(image=b.pin(W/'attempt1/link/component.exe'),
        app=b.pin(W/'attempt1/compile/unit.obj'),native=b.pin(native)))
    for item in sources: assert b.pin(Path(item['path'])) == item
    print('One CPU app build ready; private source dependencies checked.')


def run():
    plan = b.read(W/'recipe.json'); ready = b.read(W/'attempt1/link/ready.json')
    for item in [*ready.values(),*plan['common_inputs'],plan['fixture'],plan['fixture_body']]:
        assert b.pin(Path(item['path'])) == item
    env = b.environment(plan['compile'][0])
    env['PATH']=str(W/'attempt1/link')+';'+b.read(Path(plan['runtime']['path']))['PATH']
    env['HF_HUB_OFFLINE']=env['TRANSFORMERS_OFFLINE']='1'
    b.execute(plan['process_argv'],W/'attempt1/run',env,120)
    result=json.loads((W/'attempt1/run/stdout.log').read_text().strip().splitlines()[-1])
    assert result['status']=='PASS' and result['final_versions']==0 and not result['GPU'] and not result['HTTP']
    save(W/'attempt1/run/result.json',result)
    print(json.dumps(result))


if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='prepare':prepare()
    elif mode=='freeze-sampling':freeze_sampling(sys.argv[2])
    elif mode=='build':build()
    elif mode=='run':run()
    else:raise SystemExit('prepare | freeze-sampling SHA256 | build | run')
