from pathlib import Path
import os
import sys

sys.dont_write_bytecode = True
import check_cpu as c

OUT, ROOT = c.OUT, c.ROOT
closure = ROOT / '.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/attempt2/link'
ready = c.read(closure / 'ready.json')
native = Path(ready['native']['path'])
c.require(ready['native'])
plan = c.read(ROOT / '.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/execution-plan2.json')
runtime = c.read(plan['runtime']['path'])
env = dict(os.environ)
env['PATH'] = runtime['PATH']
env['HF_HUB_OFFLINE'] = env['TRANSFORMERS_OFFLINE'] = '1'
results = []
for arm, expected_exit, expected_tests, expected_failures in [('baseline', 1, 1, 1), ('candidate', 0, 5, 0)]:
    folder = OUT / 'cpu' / arm
    alias = folder / native.name
    if not alias.exists():
        os.link(native, alias)
    assert os.path.samefile(alias, native)
    assert c.identity(alias)['sha256'] == ready['native']['sha256']
    c.save(folder / 'native-runtime.json', dict(alias=c.identity(alias), original=ready['native'], same_file=True,
        reason='LOAD_LIBRARY_SEARCH_DEFAULT_DIRS requires the already consumed AVX2 program beside the executable; PATH alone is not a loader search contract.'))
    first = c.read(folder / 'run/process.json')
    command = c.read(folder / 'run/command.json')['command']
    command = [x if not x.startswith('--gtest_output=') else '--gtest_output=json:' + str(folder / 'tests-rerun.json') for x in command]
    image = c.identity(command[0])
    code = c.execute(command, env, folder / 'run2')
    report = c.read(folder / 'tests-rerun.json')
    stdout = (folder / 'run2/stdout.log').read_text(encoding='utf-8', errors='replace')
    assert 'exception' not in stdout.lower() and 'ggml CPU AVX2 program' not in stdout
    assert code == expected_exit and report['tests'] == expected_tests and report['failures'] == expected_failures
    results.append(dict(arm=arm, expected_exit=expected_exit, actual_exit=code, tests=report['tests'], failures=report['failures'],
        image=image, initial_loader_failure_process=first, initial_loader_failure_is_numerical_evidence=False,
        source_dependencies=c.identity(folder / 'source-identities.json'), raw_output=c.identity(folder / 'run2/stdout.log')))
    print(arm, 'exit', code, 'tests', report['tests'], 'failures', report['failures'], flush=True)
    print(stdout[-7000:], flush=True)
for pin in c.read(OUT / 'source-pins.json'):
    assert c.identity(ROOT / pin['path'])['sha256'] == pin['before']
    assert c.identity(OUT / 'source' / pin['path'])['sha256'] == pin['after']
c.save(OUT / 'cpu-summary.json', dict(status='BASELINE_REPRODUCED_CANDIDATE_POLICY_PASSED', results=results,
    reused_closure=c.identity(closure / 'ready.json'), reused_absolute_inputs=130, reused_common_absolute_inputs=129,
    relative_system_library_arguments=24,
    added_cached_gtest=[c.identity(ROOT / '.scratch/build-compute-v2-dev/lib' / name) for name in ('gtest_main.lib', 'gtest.lib')],
    native=ready['native'], runtime_environment=c.identity(plan['runtime']['path']),
    fresh_application_TUs=2, numerical_runtime_processes=2, initial_loader_failed_processes=2,
    source_sdk_provider_rebuilds=0, GPU=0, HTTP=0, canonical_changed=False,
    scope='CPU policy component: wide finite opposite logits and adjacent large-offset F32 oracle; original four Policy tests. Not a full model run, MTP matrix or native GPU qualification.'))
