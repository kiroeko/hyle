from pathlib import Path
import os
import sys

sys.dont_write_bytecode = True
import check_cpu as c

OUT, ROOT = c.OUT, c.ROOT
folder = OUT / 'cpu/candidate2'
prior = OUT / 'cpu/candidate'
pins = c.read(OUT / 'source-pins.json')
for pin in pins:
    assert c.identity(ROOT / pin['path'])['sha256'] == pin['before']
    assert c.identity(OUT / 'source' / pin['path'])['sha256'] == pin['after']
folder.mkdir(parents=True, exist_ok=True)
c.save(folder / 'source-pins.json', pins)
print('candidate2 source identities:', [(p['path'], p['after']) for p in pins], flush=True)
closure = ROOT / '.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/attempt2/link'
ready = c.read(closure / 'ready.json')
for row in [ready['native'], *ready['actual_inputs']]:
    c.require(row)
compile_old = c.read(prior / 'compile/command.json')['command']
compiler = compile_old[0]
env = c.discover_environment(compiler='msvc', cache=dict(CMAKE_C_COMPILER=compiler, CMAKE_CXX_COMPILER=compiler, CMAKE_GENERATOR='Ninja'), backends=()).env
command = [x.replace(str(prior), str(folder)) for x in compile_old]
assert c.execute(command, env, folder / 'compile') == 0, 'candidate2 compile failed; see raw logs'
deps = c.read(folder / 'dependencies.json')['Data']
dep_names = list(dict.fromkeys([deps['Source'], *deps['Includes']]))
header = OUT / 'source/engine/inference/sampling_graph.h'
assert any(str(Path(x).resolve()).casefold() == str(header.resolve()).casefold() for x in dep_names)
assert not any('retirement-implementation\\source' in str(x).casefold() for x in dep_names)
c.save(folder / 'source-identities.json', [c.identity(p) for p in dep_names])
command = [x.replace(str(prior), str(folder)) for x in c.read(prior / 'link/command.json')['command']]
assert c.execute(command, env, folder / 'link') == 0, 'candidate2 link failed; see raw logs'
native = Path(ready['native']['path'])
alias = folder / native.name
if not alias.exists():
    os.link(native, alias)
assert os.path.samefile(alias, native) and c.identity(alias)['sha256'] == ready['native']['sha256']
c.save(folder / 'native-runtime.json', dict(original=ready['native'], alias=c.identity(alias), same_file=True))
plan = c.read(ROOT / '.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/execution-plan2.json')
run_env = dict(env)
run_env['PATH'] = c.read(plan['runtime']['path'])['PATH']
run_env['HF_HUB_OFFLINE'] = run_env['TRANSFORMERS_OFFLINE'] = '1'
image = c.identity(folder / 'sampling.exe')
command = [image['path'], '--gtest_color=no', '--gtest_filter=QwenSamplingGraph.Policy*', '--gtest_output=json:' + str(folder / 'tests.json')]
code = c.execute(command, run_env, folder / 'run')
report = c.read(folder / 'tests.json')
print((folder / 'run/stdout.log').read_text(encoding='utf-8', errors='replace'), flush=True)
assert code == 0 and report['tests'] == 6 and report['failures'] == 0
for pin in pins:
    assert c.identity(ROOT / pin['path'])['sha256'] == pin['before']
    assert c.identity(OUT / 'source' / pin['path'])['sha256'] == pin['after']
c.save(OUT / 'candidate2-summary.json', dict(status='CANDIDATE2_POLICY_6_PASSED', tests=report['tests'], failures=report['failures'],
    source_pins=pins, image=image, source_dependencies=c.identity(folder / 'source-identities.json'),
    raw_output=c.identity(folder / 'run/stdout.log'),
    retained_baseline_wide_failure=c.identity(OUT / 'cpu/baseline/run2/stdout.log'),
    prior_candidate5_and_loader_failures=c.identity(OUT / 'cpu-summary.json'),
    reused_common_absolute_inputs=129, application_TUs=1, cached_gtest_libraries=2,
    runtime_processes=1, native=ready['native'], SDK_core_provider_rebuilds=0, GPU=0, HTTP=0, canonical_changed=False,
    scope='CPU policy component only: original four Policy cases, wide finite range/large-offset neighbours, and tiny raw TopK ranking. Existing baseline numerical failure retained without rerun.'))
print('candidate2: 6 tests, 0 failures; summary', OUT / 'candidate2-summary.json', flush=True)
