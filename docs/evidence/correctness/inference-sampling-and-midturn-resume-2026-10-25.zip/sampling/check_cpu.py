from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from hyle_environment import discover_environment


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def identity(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def require(row):
    actual = identity(row['path'])
    if actual['bytes'] != row['bytes'] or actual['sha256'] != row['sha256']:
        raise RuntimeError('Pinned file changed: ' + row['path'])


def execute(command, env, folder, timeout=60):
    folder.mkdir(parents=True, exist_ok=True)
    save(folder / 'command.json', dict(command=command, cwd=str(ROOT), timeout_seconds=timeout))
    start = time.monotonic()
    with (folder / 'stdout.log').open('wb') as stdout, (folder / 'stderr.log').open('wb') as stderr:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
    save(folder / 'process.json', dict(exit=result.returncode, seconds=time.monotonic()-start))
    return result.returncode


def main():
    # No source/SDK/provider build. Keep precisely the latest pinned CPU closure,
    # replacing its one application TU and adding the existing GTest libraries.
    closure = ROOT / '.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/attempt2/link'
    ready = read(closure / 'ready.json')
    old_command = read(closure / 'command.json')['command']
    old_app = Path(ready['app']['path'])
    for row in [ready['native'], *ready['actual_inputs']]:
        require(row)
    absolute_inputs = [x for x in old_command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    system_libraries = [x for x in old_command if not Path(x).is_absolute() and x.lower().endswith('.lib')]
    assert len(absolute_inputs) == 130 and len(system_libraries) == 24
    assert old_command.count(str(old_app)) == 1
    gtest = [ROOT / '.scratch/build-compute-v2-dev/lib' / name for name in ('gtest_main.lib', 'gtest.lib')]
    gtest_pins = [identity(path) for path in gtest]
    native = Path(ready['native']['path'])
    plan = read(ROOT / '.scratch/inference-ordinary-boundaries-20261025/retirement-implementation/execution-plan2.json')
    runtime = read(plan['runtime']['path'])
    compile_recipe = read(ROOT / '.scratch/mtp-random-20261024/component-check/test/command.json')['command']
    compiler = compile_recipe[0]
    env = discover_environment(compiler='msvc', cache=dict(CMAKE_C_COMPILER=compiler, CMAKE_CXX_COMPILER=compiler, CMAKE_GENERATOR='Ninja'), backends=()).env
    run_env = dict(env)
    run_env['PATH'] = str(native.parent) + ';' + runtime['PATH']
    flags = []
    skip = False
    for arg in compile_recipe[1:]:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
        elif not arg.startswith(('/Fo', '/Fd')) and not arg.lower().endswith('.cc'):
            flags.append(arg)
    flags.append('/I' + str(ROOT / 'tests/graph_route_cpu'))
    source_rel = Path('tests/graph_route_cpu/qwen_sampling_graph_test.cc')
    header_rel = Path('engine/inference/sampling_graph.h')
    pins = read(OUT / 'source-pins.json')
    for pin in pins:
        assert identity(ROOT / pin['path'])['sha256'] == pin['before']
        assert identity(OUT / 'source' / pin['path'])['sha256'] == pin['after']
    baseline_root = OUT / 'baseline-source'
    for rel, body in [(source_rel, (OUT / 'source' / source_rel).read_bytes()), (header_rel, (ROOT / header_rel).read_bytes())]:
        path = baseline_root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and path.read_bytes() != body:
            raise RuntimeError('Refusing to replace a different baseline source: ' + str(path))
        path.write_bytes(body)
    results = []
    for arm, tree, test_filter, expected_exit in [
        ('baseline', baseline_root, 'QwenSamplingGraph.PolicyPreservesWideFiniteRangeAndNearbyLargeLogits', 1),
        ('candidate', OUT / 'source', 'QwenSamplingGraph.Policy*', 0),
    ]:
        folder = OUT / 'cpu' / arm
        folder.mkdir(parents=True, exist_ok=True)
        source, header = tree / source_rel, tree / header_rel
        obj, image = folder / 'test.obj', folder / 'sampling.exe'
        command = [compiler, *flags, str(source), '/sourceDependencies', str(folder / 'dependencies.json'), '/Fo' + str(obj), '/Fd' + str(folder / 'test.pdb')]
        if execute(command, env, folder / 'compile'):
            raise RuntimeError(arm + ' compile failed; see raw logs')
        deps = read(folder / 'dependencies.json')['Data']
        dep_names = [deps['Source'], *deps['Includes']]
        resolved_header = str(header.resolve()).casefold()
        assert any(str(Path(x).resolve()).casefold() == resolved_header for x in dep_names)
        assert not any('retirement-implementation\\source' in str(x).casefold() for x in dep_names)
        save(folder / 'source-identities.json', [identity(path) for path in dict.fromkeys(dep_names)])
        command = []
        for arg in old_command:
            if arg.upper().startswith(('/OUT:', '/PDB:', '/IMPLIB:', '/MAP:')):
                continue
            command.append(str(obj) if arg == str(old_app) else arg)
        command += [str(x) for x in gtest] + ['/OUT:' + str(image), '/PDB:' + str(folder / 'sampling.pdb'), '/IMPLIB:' + str(folder / 'sampling.lib')]
        if execute(command, env, folder / 'link'):
            raise RuntimeError(arm + ' link failed; see raw logs')
        command = [str(image), '--gtest_color=no', '--gtest_filter=' + test_filter, '--gtest_output=json:' + str(folder / 'tests.json')]
        code = execute(command, run_env, folder / 'run')
        report = read(folder / 'tests.json')
        results.append(dict(arm=arm, expected_exit=expected_exit, actual_exit=code, tests=report['tests'], failures=report['failures'], image=identity(image)))
        print(arm, 'exit', code, 'tests', report['tests'], 'failures', report['failures'], flush=True)
        print((folder / 'run/stdout.log').read_text(encoding='utf-8', errors='replace')[-5000:], flush=True)
        if code != expected_exit:
            raise RuntimeError(arm + ' unexpected runtime result')
    for pin in pins:
        assert identity(ROOT / pin['path'])['sha256'] == pin['before']
        assert identity(OUT / 'source' / pin['path'])['sha256'] == pin['after']
    save(OUT / 'cpu-summary.json', dict(status='BASELINE_REPRODUCED_CANDIDATE_POLICY_PASSED', results=results,
        reused_closure=identity(closure / 'ready.json'), reused_absolute_inputs=130, reused_common_absolute_inputs=129,
        relative_system_library_arguments=24, added_cached_gtest=gtest_pins, native=ready['native'],
        runtime_environment=identity(plan['runtime']['path']), fresh_application_TUs=2, runtime_processes=2,
        source_sdk_provider_rebuilds=0, GPU=0, HTTP=0, canonical_changed=False,
        scope='CPU policy component: wide finite opposite logits and adjacent large-offset F32 oracle; original five Policy tests. Not a model run or native GPU qualification.'))


if __name__ == '__main__':
    main()
