import hashlib, json, subprocess
from pathlib import Path

repo=Path.cwd();fixture=repo/'.scratch/validation/cpu-aten-cast-stable-route'
for platform,source in [('windows',str(fixture/'consumer.cc').replace('\\','/')),
                       ('linux','/root/hyle-scratch/active-cpu-z/source/.scratch/validation/cpu-aten-cast-stable-route/consumer.cc')]:
    (fixture/(platform+'-overlay.cmake')).write_bytes(('''function(cpu_mature_consumer)
  add_executable(cpu_mature_consumer "'''+source+'''")
  target_compile_features(cpu_mature_consumer PRIVATE cxx_std_23)
  target_link_libraries(cpu_mature_consumer PRIVATE hyle::compute hyle::graph)
  hyle_stage_runtime_dependencies(cpu_mature_consumer)
endfunction()
if(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)
  cmake_language(DEFER CALL cpu_mature_consumer)
endif()
''').encode())
for name in ('windows.py','linux.py'):
    text=(repo/('.scratch/cpu-mn-'+name)).read_text(encoding='utf8')
    text=text.replace('cpu-aten-numeric','cpu-aten-cast-stable-route').replace('cpu-mn-','cpu-tc-').replace("stage+'-mn-consumer'","stage+'-tc-consumer'")
    text=text.replace("'hyle_compute_provider_native_tests','hyle_compute_route_cpu_tests'", "'hyle_compute_provider_native_tests','hyle_compute_provider_ggml_tests','hyle_compute_route_cpu_tests'")
    marker=" run('provider-tests',[build/"
    start=text.index(marker);end=text.index('\n',start)
    suffix='.exe' if name=='windows.py' else ''
    text=text[:end]+"\n run('ggml-provider-tests',[build/'bin/hyle_compute_provider_ggml_test"+suffix+"','--gtest_output=xml:'+str(out/'ggml.xml')])"+text[end:]
    start=text.index(' for factor,pattern in [')
    end=text.index(" run('"+('shared-source-ordinary' if name=='windows.py' else 'static-source-ordinary'),start)
    text=text[:start]+" for factor in ('compute_route_cpu','graph_route_cpu'):\n  run(factor+'-affected-tests',[build/('bin/hyle_'+factor+'_test"+suffix+"'),'--gtest_output=xml:'+str(out/(factor+'.xml'))])\n"+text[end:]
    (repo/('.scratch/cpu-tc-'+name)).write_bytes(text.encode())
files=subprocess.check_output(['git','ls-files'],text=True).splitlines()
files=[p for p in files if (p.startswith(('cmake/','include/','src/','tests/','scripts/')) or p in ('CMakeLists.txt','hyle-config.cmake.in')) and (repo/p).is_file()]
files+=['.scratch/validation/cpu-aten-cast-stable-route/'+p for p in ('consumer.cc','windows-overlay.cmake','linux-overlay.cmake','consumer/CMakeLists.txt')]
manifest=dict(candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),files={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in files})
(fixture/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
print(dict(candidate=manifest['candidate'],files=len(files)))
