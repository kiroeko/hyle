import hashlib,sys
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-aten-cast-stable-route/windows'
out.mkdir(parents=True,exist_ok=True)
records=json.loads((out/'receipt.json').read_text(encoding='utf-8')) if (out/'receipt.json').exists() else []
fixture=out.parent
manifest=json.loads((fixture/'manifest.json').read_text())
candidate=manifest['candidate']
for name,sha in manifest['files'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha,name
overlay=fixture/'windows-overlay.cmake'
if '--delivery-only' not in sys.argv:
 if '--resume-build' not in sys.argv:
  run('configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_BENCH=OFF','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(overlay)])
 run('batch-build',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','hyle_compute_provider_ggml_tests','hyle_compute_route_cpu_tests','hyle_graph_route_cpu_tests','cpu_mature_consumer','--parallel','2'])
 run('provider-tests',[build/'bin/hyle_compute_provider_native_test.exe','--gtest_output=xml:'+str(out/'provider.xml')])
 run('ggml-provider-tests',[build/'bin/hyle_compute_provider_ggml_test.exe','--gtest_output=xml:'+str(out/'ggml.xml')])
 for factor in ('compute_route_cpu','graph_route_cpu'):
  args=[build/('bin/hyle_'+factor+'_test.exe'),'--gtest_output=xml:'+str(out/(factor+'.xml'))]
  if factor=='compute_route_cpu' and '--retry-cpu-only-failures' in sys.argv:
   failed=json.loads((out/'initial-failure-summary.json').read_text())['failed'];assert len(failed)==37
   args+=['--gtest_filter='+':'.join(failed)]
  run(factor+'-affected-tests',args)
 run('shared-source-ordinary',[build/'bin/cpu_mature_consumer.exe'])
if '--tests-only' in sys.argv:raise SystemExit(0)
source=Path('C:/hv/d5cd/source-tree').resolve();assert source.is_relative_to(Path('C:/hv/d5cd').resolve())
changed=[]
for name,sha in manifest['files'].items():
 data=(repo/name).read_bytes();assert hashlib.sha256(data).hexdigest()==sha,name
 dest=(source/name).resolve();assert dest.is_relative_to(source)
 if not dest.exists() or dest.read_bytes()!=data:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);changed.append(name)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==sha,name
(out/'source-identity.json').write_text(json.dumps(dict(candidate=candidate,checked=len(manifest['files']),forward_updated=changed),indent=2)+'\n')
for stage in ('shared','static'):
 prefix=Path('C:/hv/cpu-ggml-isa-'+stage+'-sdk')
 if stage=='shared':
  run('shared-producer-configure',['cmake','-S',repo,'-B',build,'-DHYLE_BUILD_TESTS=OFF','-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 else:
  build=Path('C:/hv/d5cp/source-build')
  run('static-producer-configure',['cmake','-S','C:/hv/d5cp/consumer','-B',build,'-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_PROJECT_INCLUDE='+str(overlay)])
 run(stage+'-producer-build',['cmake','--build',build,'--target','cpu_mature_consumer','hyle_time','--parallel','2'])
 run(stage+'-source-ordinary',[build/('cpu_mature_consumer.exe' if stage=='static' else 'bin/cpu_mature_consumer.exe')])
 run(stage+'-install',['cmake','--install',build,'--prefix',prefix])
 consumer=Path('C:/hv/cpu-tc-'+stage+'-consumer')
 run(stage+'-consumer-configure',['cmake','-S',fixture/'consumer','-B',consumer,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
 run(stage+'-consumer-build',['cmake','--build',consumer,'--parallel','2'])
 run(stage+'-installed-ordinary',[consumer/'cpu_mature_consumer.exe'])
