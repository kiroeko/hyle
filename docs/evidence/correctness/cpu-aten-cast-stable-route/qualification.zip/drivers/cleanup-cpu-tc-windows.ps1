$ErrorActionPreference = 'Stop'
$cleanupRoot = (Resolve-Path -LiteralPath 'C:\hv').Path
$cleanupEvidence = Join-Path (Get-Location).Path '.scratch\validation\cpu-aten-cast-stable-route\windows\cleanup.json'
$cleanupRows = @()
foreach ($cleanupName in @('cpu-tc-shared-consumer', 'cpu-tc-static-consumer', 'cpu-tc-original-probe', 'cpu-ggml-finite-tail-probe')) {
    $cleanupTarget = (Resolve-Path -LiteralPath (Join-Path $cleanupRoot $cleanupName)).Path
    if ([IO.Path]::GetDirectoryName($cleanupTarget) -ne $cleanupRoot -or [IO.Path]::GetFileName($cleanupTarget) -ne $cleanupName) { throw 'Cleanup escaped its exact target' }
    if ((Get-Item -LiteralPath $cleanupTarget).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Unexpected reparse target' }
    $cleanupCache = Join-Path $cleanupTarget 'CMakeCache.txt'
    if (-not (Test-Path -LiteralPath $cleanupCache)) { throw 'Missing own consumer identity' }
    if ($cleanupName -eq 'cpu-ggml-finite-tail-probe') { $cleanupExpected = 'cpu-ggml-finite-tail' } else { $cleanupExpected = 'cpu-aten-cast-stable-route' }; if (-not ((Get-Content -LiteralPath $cleanupCache -Raw).Contains($cleanupExpected))) { throw 'Unexpected fixture identity' }
    $cleanupEntries = @(Get-ChildItem -LiteralPath $cleanupTarget -Recurse -Force)
    if (@($cleanupEntries | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count -ne 0) { throw 'Unexpected nested reparse point' }
    $cleanupFiles = @($cleanupEntries | Where-Object { -not $_.PSIsContainer })
    $cleanupDlls = @($cleanupFiles | Where-Object { $_.Extension -eq '.dll' } | ForEach-Object { @{name=$_.Name;bytes=$_.Length} })
    $cleanupBytes = ($cleanupFiles | Measure-Object -Property Length -Sum).Sum
    Remove-Item -LiteralPath $cleanupTarget -Recurse -Force
    $cleanupRows += @{path=$cleanupTarget;files=$cleanupFiles.Count;logical_bytes=$cleanupBytes;removed=(-not (Test-Path -LiteralPath $cleanupTarget));original_probe_hardlinks=($cleanupName -eq 'cpu-tc-original-probe');adjacent_runtime_dlls=$cleanupDlls}
}
$cleanupRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $cleanupEvidence -Encoding utf8
$cleanupRows | Select-Object path,files,logical_bytes,removed,original_probe_hardlinks | ConvertTo-Json
