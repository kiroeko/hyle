#include "../../../tests/compute_provider_native/aten_cast_reference.h"
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/compute/providers/native.h"
#include "hyle/compute/providers/onednn.h"
#include "hyle/graph/cpu.h"
#include "hyle/simd/dtype.h"
#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <numbers>
#include <vector>
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
template <class T> T take(hyle::Result<T> r) {
  if (!r) {
    std::fprintf(stderr, "%.*s\n", int(r.error().message().size()),
                 r.error().message().data());
    std::exit(2);
  }
  return std::move(*r);
}
void require(hyle::Status s) {
  if (!s.ok()) {
    std::fprintf(stderr, "%.*s\n", int(s.message().size()), s.message().data());
    std::exit(2);
  }
}
using Bytes = std::vector<std::byte>;
m::Buffer buffer(const c::TensorDesc &d) {
  return take(
      m::Buffer::create(m::system_resource(), take(d.required_bytes()), 64));
}
template <class Fill, class Check>
void journey(c::Operation op, std::vector<c::TensorDesc> ds, Fill fill,
             Check check) {
  const auto od = take(c::infer_single_output(op, ds));
  auto ctx = take(c::cpu::create_context());
  auto q = take(ctx.create_queue());
  std::vector<m::Buffer> inputs;
  std::vector<c::ConstTensorView> views;
  for (const auto &d : ds) {
    inputs.push_back(buffer(d));
    views.push_back(take(c::ConstTensorView::create(d, inputs.back().view())));
  }
  auto output = buffer(od);
  const auto dest = take(c::TensorView::create(od, output.view()));
  auto p =
      take(c::prepare(ctx, op, ds, std::span(&od, 1), m::system_resource()));
  const auto mature = [](c::ProviderId id) {
    return id == c::aten_cpu::kProviderId || id == c::ggml_cpu::kProviderId ||
           id == c::onednn::kProviderId;
  };
  const bool needs_aten =
      op.get_if<c::Binary>() || op.get_if<c::GatedActivation>() ||
      (op.get_if<c::Unary>() &&
       op.get_if<c::Unary>()->kind != c::UnaryKind::kSoftplus) ||
      (op.get_if<c::Reduce>() &&
       (op.get_if<c::Reduce>()->kind == c::ReductionKind::kMinimum ||
        op.get_if<c::Reduce>()->kind == c::ReductionKind::kMaximum));
  std::printf("Direct op=%d provider=%.*s\n", int(op.kind()),
              int(p.provider().name.size()), p.provider().name.data());
  if (!mature(p.provider().id) ||
      (needs_aten && p.provider().id != c::aten_cpu::kProviderId))
    std::exit(3);
  auto inv = take(p.create_invocation());
  auto builder = take(g::GraphBuilder::create());
  std::vector<g::ValueId> ids;
  for (const auto &d : ds)
    ids.push_back(take(builder.input(d)));
  auto node = take(builder.add_node(op, ids));
  auto value = take(builder.result(node));
  auto y = take(builder.add(c::Copy{}, value));
  require(builder.publish(y));
  auto graph = take(std::move(builder).finish());
  auto gc = take(g::cpu::create_context());
  auto compiled = take(g::compile(graph, gc));
  if (compiled.report.step_count() < 1 ||
      !mature(compiled.report.step(0)->provider.id) ||
      (needs_aten &&
       compiled.report.step(0)->provider.id != c::aten_cpu::kProviderId))
    std::exit(4);
  auto gq = take(gc.create_queue());
  auto lane = take(compiled.executable.create_invocation());
  for (std::size_t i = 0; i < ids.size(); ++i)
    require(lane.bind(ids[i], views[i]));
  require(lane.bind(y, dest));
  const std::array queues{
      g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &gq}};
  require(lane.prepare_replay(queues));
  for (int seed : {1, 7}) {
    fill(inputs, seed);
    auto done = take(inv.submit(q, views, std::span(&dest, 1)));
    require(done.wait());
    check(output, seed);
    auto whole = take(lane.submit(gq));
    require(whole.wait());
    check(output, seed);
  }
  require(ctx.close());
  require(gc.close());
}

c::TensorDesc desc(c::DataType type, std::initializer_list<std::int64_t> shape,
                   bool odd = true) {
  std::vector<std::int64_t> dims(shape), strides(dims.size());
  if (!odd)
    return take(c::TensorDesc::dense(type, dims));
  auto stride = static_cast<std::int64_t>(c::data_type_size(type)) + 1;
  for (std::size_t i = dims.size(); i-- != 0;) {
    strides[i] = stride;
    stride = stride * dims[i] + 1;
  }
  return take(c::TensorDesc::strided_bytes(type, dims, strides));
}
std::size_t offset(const c::TensorDesc &d, std::size_t linear) {
  std::size_t out = 0;
  for (std::size_t i = d.rank(); i-- != 0;) {
    const auto n = d.dimensions()[i];
    out += linear % n * d.byte_strides()[i];
    linear /= n;
  }
  return out;
}
std::vector<float> round(c::DataType type, const std::vector<float> &values) {
  auto result = values;
  for (auto &v : result)
    if (type == c::DataType::kFloat16)
      v = hyle::simd::f16_to_f32(hyle::simd::f32_to_f16(v));
    else if (type == c::DataType::kBFloat16)
      v = hyle::simd::bf16_to_f32(hyle::simd::f32_to_bf16(v));
  return result;
}
void write(m::Buffer &b, const c::TensorDesc &d,
           const std::vector<float> &values) {
  Bytes bytes(b.size(), std::byte{0xde});
  for (std::size_t i = 0; i < values.size(); ++i) {
    const auto position = offset(d, i);
    if (d.data_type() == c::DataType::kFloat32)
      std::memcpy(bytes.data() + position, &values[i], 4);
    else {
      const auto bits = d.data_type() == c::DataType::kFloat16
                            ? hyle::simd::f32_to_f16(values[i]).bits
                            : hyle::simd::f32_to_bf16(values[i]).bits;
      std::memcpy(bytes.data() + position, &bits, 2);
    }
  }
  require(b.view().write(bytes));
}
void expect(const m::Buffer &b, c::DataType type,
            const std::vector<float> &values) {
  Bytes bytes(b.size());
  require(b.view().read(bytes));
  const auto expected = round(type, values);
  for (std::size_t i = 0; i < expected.size(); ++i) {
    float value;
    if (type == c::DataType::kFloat32)
      std::memcpy(&value, bytes.data() + 4 * i, 4);
    else {
      std::uint16_t bits;
      std::memcpy(&bits, bytes.data() + 2 * i, 2);
      value =
          type == c::DataType::kFloat16
              ? hyle::simd::f16_to_f32(hyle::simd::float16_t::from_bits(bits))
              : hyle::simd::bf16_to_f32(
                    hyle::simd::bfloat16_t::from_bits(bits));
    }
    const auto e = expected[i];
    const bool okay =
        std::isnan(e) ? std::isnan(value)
        : std::isinf(e) || e == 0
            ? value == e && std::signbit(value) == std::signbit(e)
            : std::abs(double(value) - e) <=
                  std::abs(double(e)) *
                          (type == c::DataType::kFloat32 ? 3e-6 : 0.008) +
                      4 * std::numeric_limits<float>::denorm_min();
    if (!okay) {
      std::fprintf(stderr, "numeric[%zu] actual=%.12g expected=%.12g\n", i,
                   value, e);
      std::exit(5);
    }
  }
}
float activation(float x, c::GatedActivationKind kind) {
  if (x == -std::numeric_limits<float>::infinity())
    return 0;
  const double v = x;
  if (kind == c::GatedActivationKind::kGelu)
    return float(.5 * v * std::erfc(-v / std::numbers::sqrt2));
  const double t =
      kind == c::GatedActivationKind::kSilu
          ? v
          : 2 * std::sqrt(2 / std::numbers::pi) * (v + .044715 * v * v * v);
  const double e = std::exp(-std::abs(t));
  return float(v * (t < 0 ? e / (1 + e) : 1 / (1 + e)));
}
std::vector<float> inputs(int seed) {
  std::vector<float> values{-std::numeric_limits<float>::infinity(),
                            -100,
                            -8.3625F,
                            -5,
                            -0.F,
                            0,
                            1,
                            5,
                            20,
                            100,
                            std::numeric_limits<float>::infinity(),
                            std::numeric_limits<float>::quiet_NaN()};
  for (std::size_t i = 0; i < values.size(); ++i)
    if (std::isfinite(values[i]) && values[i] != 0)
      values[i] += float(seed - 1) * .125F;
  return values;
}
void stable_tail_downstream() {
  const auto d = take(c::TensorDesc::dense(c::DataType::kFloat32,
                                           std::array<std::int64_t, 2>{1, 8}));
  const auto rhs = take(c::TensorDesc::dense(
      c::DataType::kFloat32, std::array<std::int64_t, 2>{8, 1}));
  const auto out = take(c::TensorDesc::dense(
      c::DataType::kFloat32, std::array<std::int64_t, 2>{1, 1}));
  auto make = [](std::size_t n) {
    return take(m::Buffer::create(m::system_resource(), n, 64));
  };
  auto a = make(32), b = make(32), y = make(32), weights = make(32),
       z = make(4);
  auto ctx = take(c::cpu::create_context());
  auto q = take(ctx.create_queue());
  const std::array inputs{take(c::ConstTensorView::create(d, a.view())),
                          take(c::ConstTensorView::create(d, b.view()))};
  const auto dest = take(c::TensorView::create(d, y.view()));
  const c::GatedActivation op{.activation = c::GatedActivationKind::kSilu,
                              .inputs = c::GatedInputKind::kSeparate};
  auto p = take(c::prepare(ctx, c::Operation{op}, inputs, std::span(&dest, 1)));
  auto lane = take(p.create_invocation());
  auto unary = take(c::prepare(ctx, c::Unary{c::UnaryKind::kSigmoid}, d));
  auto ui = take(unary.create_invocation());
  auto builder = take(g::GraphBuilder::create());
  const auto ga = take(builder.input(d)), gb = take(builder.input(d)),
             gw = take(builder.input(rhs));
  const auto activated = take(builder.add(op, ga, gb));
  const auto projected = take(builder.add(c::MatMul{}, activated, gw));
  require(builder.publish(projected));
  auto graph = take(std::move(builder).finish());
  auto gc = take(g::cpu::create_context());
  auto compiled = take(g::compile(graph, gc));
  auto gq = take(gc.create_queue());
  auto gi = take(compiled.executable.create_invocation());
  require(gi.bind(ga, inputs[0]));
  require(gi.bind(gb, inputs[1]));
  require(gi.bind(gw, take(c::ConstTensorView::create(rhs, weights.view()))));
  require(gi.bind(projected, take(c::TensorView::create(out, z.view()))));
  const std::array queues{
      g::QueueBinding{.lane = g::ExecutionLaneId{0}, .queue = &gq}};
  require(gi.prepare_replay(queues));
  std::array<float, 8> w{};
  w.fill(1);
  require(weights.view().write(std::as_bytes(std::span(w))));
  std::printf("Direct gate=%.*s sigmoid=%.*s Graph steps=%zu first=%.*s\n",
              int(p.provider().name.size()), p.provider().name.data(),
              int(unary.provider().name.size()), unary.provider().name.data(),
              compiled.report.step_count(),
              int(compiled.report.step(0)->provider.name.size()),
              compiled.report.step(0)->provider.name.data());
  if (p.provider().id != c::aten_cpu::kProviderId ||
      unary.provider().id != c::aten_cpu::kProviderId ||
      compiled.report.step(0)->provider.id != c::aten_cpu::kProviderId)
    std::exit(5);
  int mismatches = 0;
  for (float x : {-80.F, -90.F, -100.F})
    for (float v : {1e38F, std::numeric_limits<float>::infinity()}) {
      std::array<float, 8> gate{}, values{};
      gate[0] = x;
      values[0] = v;
      require(a.view().write(std::as_bytes(std::span(gate))));
      require(b.view().write(std::as_bytes(std::span(values))));
      require(take(lane.submit(q, inputs, std::span(&dest, 1))).wait());
      std::array<float, 8> actual{};
      require(y.view().read(std::as_writable_bytes(std::span(actual))));
      require(take(gi.submit(gq)).wait());
      float projected_actual = 0;
      require(z.view().read(
          std::as_writable_bytes(std::span(&projected_actual, 1))));
      const auto e = std::exp(double(x));
      const float activation = static_cast<float>(double(x) * (e / (1 + e)));
      const float expected = activation * v;
      const auto matches = [&](float value) {
        return std::isinf(expected)
                   ? value == expected
                   : std::abs(value - expected) <=
                         3e-6 * std::abs(expected) +
                             4 * std::numeric_limits<float>::denorm_min();
      };
      const bool good = matches(actual[0]) && matches(projected_actual);
      mismatches += !good;
      std::printf(
          "x=%g value=%g direct=%+.9g downstream=%+.9g oracle=%+.9g %s\n", x, v,
          actual[0], projected_actual, expected, good ? "MATCH" : "MISMATCH");
      require(take(ui.submit(q, inputs[0], dest)).wait());
      require(y.view().read(std::as_writable_bytes(std::span(actual))));
      std::printf("sigmoid x=%g actual=%+.9g oracle=%+.9g\n", x, actual[0],
                  static_cast<float>(e / (1 + e)));
    }
  if (mismatches != 0)
    std::exit(6);
  require(ctx.close());
  require(gc.close());
  std::printf("finite-tail diagnostic mismatches=%d (no timing, no Native "
              "comparison)\n",
              mismatches);
  for (auto dtype : {c::DataType::kFloat16, c::DataType::kBFloat16}) {
    auto fresh = take(c::cpu::create_context());
    auto queue = take(fresh.create_queue());
    auto pcast = take(c::prepare(fresh, c::Cast{dtype}, d));
    auto result = make(16);
    auto ci = take(pcast.create_invocation());
    std::array<float, 8> source{};
    source[0] = std::bit_cast<float>(std::uint32_t{0x7fc12345});
    source[1] = std::bit_cast<float>(std::uint32_t{0xffc12345});
    require(a.view().write(std::as_bytes(std::span(source))));
    require(
        take(ci.submit(queue, inputs[0],
                       take(c::TensorView::create(
                           take(pcast.output_description(0)), result.view()))))
            .wait());
    std::array<std::uint16_t, 8> bits{};
    require(result.view().read(std::as_writable_bytes(std::span(bits))));
    if (bits[0] != (dtype == c::DataType::kFloat16 ? 0x7fff : 0x7fc0) ||
        bits[1] != (dtype == c::DataType::kFloat16 ? 0xffff : 0xffc0))
      std::exit(7);
    std::printf("Cast target=%d qualified-provider=%.*s NaN bits=%04x/%04x\n",
                int(dtype), int(pcast.provider().name.size()),
                pcast.provider().name.data(), unsigned(bits[0]),
                unsigned(bits[1]));
    require(fresh.close());
  }
}

int main() {
  for (auto type :
       {c::DataType::kFloat32, c::DataType::kFloat16, c::DataType::kBFloat16}) {
    const auto d = desc(type, {3, 4});
    for (auto kind :
         {c::UnaryKind::kSigmoid, c::UnaryKind::kSilu, c::UnaryKind::kGelu,
          c::UnaryKind::kGeluTanh, c::UnaryKind::kSoftplus})
      journey(
          c::Operation(c::Unary{kind}), {d},
          [&](auto &b, int seed) { write(b[0], d, inputs(seed)); },
          [&](auto &b, int seed) {
            auto values = round(type, inputs(seed));
            for (auto &v : values)
              v = kind == c::UnaryKind::kSigmoid
                      ? static_cast<float>(v < 0
                                               ? std::exp(double(v)) /
                                                     (1 + std::exp(double(v)))
                                               : 1 / (1 + std::exp(-double(v))))
                  : kind == c::UnaryKind::kSoftplus
                      ? float(std::max(double(v), 0.0) +
                              std::log1p(std::exp(-std::abs(double(v)))))
                      : activation(v, kind == c::UnaryKind::kSilu
                                          ? c::GatedActivationKind::kSilu
                                      : kind == c::UnaryKind::kGelu
                                          ? c::GatedActivationKind::kGelu
                                          : c::GatedActivationKind::kGeluTanh);
            expect(b, type, values);
          });
    for (auto kind :
         {c::GatedActivationKind::kSilu, c::GatedActivationKind::kGelu,
          c::GatedActivationKind::kGeluTanh})
      for (bool packed : {false, true}) {
        const auto pd = desc(type, {3, 8});
        const c::GatedActivation op{kind, packed
                                              ? c::GatedInputKind::kPackedHalves
                                              : c::GatedInputKind::kSeparate};
        const auto shape = packed ? std::vector<c::TensorDesc>{pd}
                                  : std::vector<c::TensorDesc>{d, d};
        const float scale = type == c::DataType::kFloat16 ? 60000.F : 1e30F;
        journey(
            c::Operation(op), shape,
            [&](auto &b, int seed) {
              auto v = inputs(seed);
              if (packed) {
                std::vector<float> both;
                for (int row = 0; row < 3; ++row) {
                  both.insert(both.end(), v.begin() + row * 4,
                              v.begin() + row * 4 + 4);
                  both.insert(both.end(), 4, scale);
                }
                write(b[0], pd, both);
              } else {
                write(b[0], d, v);
                write(b[1], d, std::vector<float>(12, scale));
              }
            },
            [&](auto &b, int seed) {
              auto v = round(type, inputs(seed));
              const auto s = round(type, {scale})[0];
              for (auto &x : v)
                x = activation(x, kind) * s;
              expect(b, type, v);
            });
      }
    const auto bd = desc(type, {1, 4});
    for (auto kind : {c::BinaryKind::kMinimum, c::BinaryKind::kMaximum})
      journey(
          c::Operation(c::Binary{kind}), {d, bd},
          [&](auto &b, int seed) {
            write(b[0], d,
                  {0, -0.F, std::numeric_limits<float>::quiet_NaN(),
                   float(seed), -0.F, 0, 1,
                   std::numeric_limits<float>::quiet_NaN(), 2, 3, 4, 5});
            write(b[1], bd,
                  {-0.F, 0, float(seed),
                   std::numeric_limits<float>::quiet_NaN()});
          },
          [&](auto &b, int seed) {
            std::vector<float> a{0,
                                 -0.F,
                                 std::numeric_limits<float>::quiet_NaN(),
                                 float(seed),
                                 -0.F,
                                 0,
                                 1,
                                 std::numeric_limits<float>::quiet_NaN(),
                                 2,
                                 3,
                                 4,
                                 5},
                z{-0.F, 0, float(seed),
                  std::numeric_limits<float>::quiet_NaN()};
            for (std::size_t i = 0; i < a.size(); ++i) {
              auto x = a[i], y = z[i % 4];
              a[i] = kind == c::BinaryKind::kMinimum ? std::fmin(x, y)
                                                     : std::fmax(x, y);
              if (x == 0 && y == 0)
                a[i] = (kind == c::BinaryKind::kMinimum
                            ? std::signbit(x) || std::signbit(y)
                            : std::signbit(x) && std::signbit(y))
                           ? -0.F
                           : 0.F;
            }
            expect(b, type, a);
          });
    const auto rd = desc(type, {2, 2, 4});
    const auto axes = take(c::Axes::from(std::array<std::int32_t, 2>{0, -1}));
    for (auto kind : {c::ReductionKind::kSum, c::ReductionKind::kMean,
                      c::ReductionKind::kMinimum, c::ReductionKind::kMaximum})
      journey(
          c::Operation(c::Reduce{.kind = kind,
                                 .axes = axes,
                                 .accumulation_type = c::DataType::kFloat32}),
          {rd},
          [&](auto &b, int seed) {
            std::vector<float> v;
            for (int i = 0; i < 16; ++i)
              v.push_back(float(i + seed) / 4);
            write(b[0], rd, v);
          },
          [&](auto &b, int seed) {
            std::vector<float> v{0, 0};
            for (int i = 0; i < 2; ++i) {
              std::vector<float> row;
              for (int block = 0; block < 2; ++block)
                for (int j = 0; j < 4; ++j)
                  row.push_back(float(block * 8 + i * 4 + j + seed) / 4);
              if (kind == c::ReductionKind::kMinimum)
                v[i] = row.front();
              else if (kind == c::ReductionKind::kMaximum)
                v[i] = row.back();
              else {
                for (auto x : row)
                  v[i] += x;
                if (kind == c::ReductionKind::kMean)
                  v[i] /= 8;
              }
            }
            expect(b, type, v);
          });
  }
  for (const auto &source : cast_reference::formats)
    for (const auto &destination : cast_reference::formats) {
      const auto input_desc = desc(source.type, {8});
      const std::array<std::uint32_t, 8> input_codes =
          source.width == 4
              ? std::array<std::uint32_t, 8>{0,          0x80000000, 0x7f800000,
                                             0xff800000, 0x7fc12345, 0xffc12345,
                                             0x47800000, 0x3f801000}
          : source.width == 2
              ? std::array<std::uint32_t, 8>{0,      0x8000, 0x7c00, 0xfc00,
                                             0x7fc1, 0xffc1, 0x3c00, 0x8001}
              : std::array<std::uint32_t, 8>{0,    0x80, 0x7c, 0xfc,
                                             0x7f, 0xff, 0x3c, 0x01};
      journey(
          c::Operation(c::Cast{destination.type}), {input_desc},
          [&](auto &b, int seed) {
            Bytes bytes(b[0].size());
            for (std::size_t i = 0; i < input_codes.size(); ++i) {
              auto bits = input_codes[i];
              if (seed == 7 && i == 6)
                bits = 0;
              std::memcpy(bytes.data() + offset(input_desc, i), &bits,
                          source.width);
            }
            require(b[0].view().write(bytes));
          },
          [&](auto &b, int seed) {
            Bytes bytes(b.size());
            require(b.view().read(bytes));
            for (std::size_t i = 0; i < input_codes.size(); ++i) {
              auto bits = input_codes[i];
              if (seed == 7 && i == 6)
                bits = 0;
              const auto wide = cast_reference::float_bits(bits, source);
              const auto expected =
                  source.type == destination.type ? bits
                  : destination.width == 4
                      ? wide
                      : cast_reference::encode(std::bit_cast<float>(wide),
                                               destination, (wide >> 31) != 0);
              std::uint32_t actual = 0;
              std::memcpy(&actual, bytes.data() + i * destination.width,
                          destination.width);
              if (actual != expected)
                std::exit(8);
            }
          });
    }
  stable_tail_downstream();
  std::puts("ordinary CPU numeric Direct and Graph downstream changed-input "
            "replay PASS");
}
