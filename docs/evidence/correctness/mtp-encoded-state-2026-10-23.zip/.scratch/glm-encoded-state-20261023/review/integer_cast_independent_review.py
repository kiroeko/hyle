"""Source/bit-table audit only; never imports or runs Hyle/CUDA binaries."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
BF = ROOT / ".scratch/glm-encoded-state-20261023"
S = BF / "integer-cast-source"
freeze = json.loads((S / "freeze.json").read_text(encoding="utf-8-sig"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


identities = []
current = {}
before = {}
for item in freeze["files"]:
    rel = item["path"]
    data = (ROOT / rel).read_bytes()
    frozen_data = (S / "frozen" / rel).read_bytes()
    match = len(data) == item["bytes"] and sha(data) == item["sha256"]
    assert match and data == frozen_data, rel
    identities.append({**item, "current_matches_freeze": match,
                       "snapshot_matches_current": data == frozen_data})
    current[rel] = data.decode("utf-8-sig").replace("\r\n", "\n")
    before[rel] = (S / "before" / rel).read_text(encoding="utf-8-sig")


def block(text, marker):
    start = text.index(marker)
    opening = text.index("{", start)
    depth = 1
    cursor = opening + 1
    while depth:
        depth += (text[cursor] == "{") - (text[cursor] == "}")
        cursor += 1
    return text[start:cursor]


provider = "src/compute_provider_cuda/tensor_provider.cc"
kernel = "src/compute_provider_cuda/tensor_kernel.cu"
header = "src/compute_provider_cuda/tensor_kernel.h"
unchanged = []
for rel, marker in [
    (provider, "bool numeric("),
    (provider, "bool floating("),
    (provider, "native::TensorElementType element_type("),
    (provider, "if (const auto *view = operation.get_if<View>())"),
    (kernel, "__device__ T read("),
    (kernel, "__device__ void tensor_element("),
    (kernel, "__global__ void tensor("),
    (kernel, "cudaError_t tensor_launch("),
    (header, "struct TensorLayout final"),
    (header, "struct TensorProgram final"),
]:
    old = block(before[rel], marker)
    new = block(current[rel], marker)
    same = old == new
    assert same, marker
    unchanged.append({"path": rel, "marker": marker, "unchanged": same,
                      "text_sha256": sha(new.encode())})


def int32_to_ieee_rne(n):
    """Build binary32 using integer shifts, quotient/remainder and tie parity."""
    assert -(1 << 31) <= n < (1 << 31)
    if not n:
        return 0
    negative = n < 0
    magnitude = abs(n)
    exponent = magnitude.bit_length() - 1
    if exponent <= 23:
        significand = magnitude << (23 - exponent)
    else:
        denominator = 1 << (exponent - 23)
        significand, remainder = divmod(magnitude, denominator)
        twice = 2 * remainder
        if twice > denominator or (twice == denominator and significand & 1):
            significand += 1
        if significand == 1 << 24:
            significand >>= 1
            exponent += 1
    return (int(negative) << 31) | ((exponent + 127) << 23) | (significand & 0x7fffff)


values = [0, 1, -1, 16777215, 16777216, 16777217, -16777215, -16777216,
          -16777217, 16777219, -16777219, -(1 << 31), (1 << 31) - 1]
bits = [0x00000000, 0x3f800000, 0xbf800000, 0x4b7fffff, 0x4b800000,
        0x4b800000, 0xcb7fffff, 0xcb800000, 0xcb800000, 0x4b800002,
        0xcb800002, 0xcf000000, 0x4f000000]
rows = []
for n, wanted in zip(values, bits):
    actual = int32_to_ieee_rne(n)
    assert wanted == actual, n
    rows.append({"int32": n, "expected_binary32": f"0x{wanted:08x}",
                 "independent_integer_oracle": f"0x{actual:08x}", "matches": True})

report = {
    "scope": "Independent source-only audit of the four frozen CUDA I32-to-F32 files.",
    "native_build_run_ssh_download": False,
    "source_files": identities,
    "conclusion": "No confirmed correctness, ABI, storage-operation, addressing, rounding, or resource-lifetime defect found in this minimal change.",
    "unchanged_blocks": unchanged,
    "dispatch": {
        "domain": "Only public Cast I32 source to F32 output is newly qualified; other integer conversion directions remain unsupported.",
        "copy_fill_view": "element_type is unchanged; only a selected non-view Cast overrides its I32 input enum. Copy/Fill still dispatch by storage width, and View returns its existing alias selection before numerical preparation.",
        "abi": "kInt32 is appended after the six old enum values. TensorKind, TensorLayout, TensorProgram, tensor_prepare and tensor_launch declarations are unchanged.",
        "alias": "No Cast alias mask was added; input/output permissions and existing submission alignment checks are unchanged."
    },
    "addressing": {
        "dense": "Dense source loads typed int32 elements; its required alignment stays 4 bytes. Dense destination is typed float with 4-byte alignment.",
        "strided": "Non-dense reads assemble four bytes at size_t offsets; odd 5-byte source strides require alignment 1 and do not perform a misaligned int32 load.",
        "width": "The unchanged Cast path uses uint64 elements/index/grid-stride, size_t byte offsets and a 65535-block cap; its subtraction-before-increment guard prevents tail index overflow.",
        "test_bounds": "13 dense elements occupy 52 bytes; stride 5 occupies the descriptor's 64-byte span (last element at byte 60). Existing index<elements guard bounds all writes.",
        "not_executed": "This review does not claim a native huge-address allocation or execution test."
    },
    "rounding": {
        "kernel": "__int2float_rn explicitly selects nearest, ties to even; int32 values are finite and need no nonfinite, FTZ, saturation or NaN special case.",
        "oracle": "Independent integer-only binary32 construction, using bit length, quotient/remainder and tie parity; no float conversion, float packing or Hyle codec is used.",
        "table": rows,
        "tie_cases": "+/-16777217 rounds toward even 2^24, +/-16777219 toward even 16777220; INT32_MAX rounds to +2^31 and INT32_MIN is exact."
    },
    "resources": "No workspace, private invocation bytes, staging buffers, host sync, shadow state, new ownership, or concurrent invocation state was introduced; original context/stream/Completion lifecycle is reused.",
    "test_review": {
        "case": "CudaTensor.Int32ToFloat32RoundsTiesToEvenAndPreservesInputOnReplay",
        "scope": "13 exact output-bit checks for both dense and odd-stride input; replay twice after poisoning the destination, preserving every original input and padding byte; asserts zero workspace/private bytes and capture compatibility.",
        "submits_in_source": 4,
        "native_result": "Owned and reported by root; not run by this reviewer."
    },
    "required_followup": []
}
out = BF / "review/integer-cast-independent.json"
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report": str(out.relative_to(ROOT)), "sha256": sha(out.read_bytes()),
                  "sources_match": len(identities), "unchanged_blocks": len(unchanged),
                  "integer_bit_patterns": len(rows), "confirmed_issues": 0}))
