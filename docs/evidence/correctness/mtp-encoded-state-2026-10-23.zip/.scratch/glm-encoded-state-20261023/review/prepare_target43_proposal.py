"""Source-only patch proposal; never mutates the active consumer TU."""
from pathlib import Path
import difflib
import hashlib
import json

R = Path(__file__).resolve().parents[3]
S = Path(__file__).resolve().parent
source = R / 'tests/compute_models/glm_mtp_state_consumer_test.cc'
original = source.read_text(encoding='utf-8')
begin = original.index('  auto qa = glm::projection(f, nx, kQueryRank, kHidden, 197, false);',
                       original.index('Recipe build(bool fresh,'))
end_marker = '  r.output_reference = [vb = std::move(vb), out = std::move(out)](auto x) { return out.reference(vb.reference(x)); };'
end = original.index(end_marker, begin) + len(end_marker)
body = original[begin:end]
assert body.count('  changed(kPending, next_pending, true);') == 1
body = body.replace('  changed(kPending, next_pending, true);\n', '')
body = body.replace('  if (fresh) {', '  if (r.fresh) {')
body = body.replace('const auto pool_count = (position + 1) / 4;',
                    'const auto pool_count = (r.position + 1) / 4;')
body = body.replace('append_history(r, state, nx, cursor)',
                    'append_history(r, state, nx, cursor, role_offset)')
for seed in [197, 199, 223, 211, 239, 251, 227, 229]:
    body = body.replace(', ' + str(seed) + ', false)', ', ' + str(seed) + ' + role_offset, false)')
    body = body.replace(', ' + str(seed) + ');', ', ' + str(seed) + ' + role_offset);')
shared = '''// Shared test construction, not a runtime executor or a model dispatch.
// nx is the actual layer's normalized attention input. State values belong
// to that layer; target43 supplies independent banks and always uses fresh.
Value append_sparse_attention(Recipe &r,
    const std::array<Value, kResources> &state, Value nx, int role_offset = 0) {
  auto &f = r.fragment;
  const auto publish = [&](Value value, bool copy = false) {
    return expose(r, value, copy);
  };
  const auto changed = [&](Entry entry, Value value, bool copy = false) {
    return change(r, entry, value, copy);
  };
''' + body + '\n  return out.output;\n}\n'
new = original[:begin] + '''  changed(kPending, next_pending, true);
  const auto attention_output = append_sparse_attention(r, state, nx);''' + original[end:]
new = new.replace('glm::binary(f, c::BinaryKind::kAdd, eh, out.output)',
                  'glm::binary(f, c::BinaryKind::kAdd, eh, attention_output)', 1)
insertion = new.index('Recipe build(bool fresh,')
new = new[:insertion] + shared + '\n' + new[insertion:]
old_signature = 'Value nx, Value next_index_cursor) {'
assert new.count(old_signature) == 1
new = new.replace(old_signature, 'Value nx, Value next_index_cursor, int role_offset = 0) {', 1)
history_begin = new.index('EncodedPool append_history(')
history_end = new.index('// Shared test construction', history_begin)
history = new[history_begin:history_end]
history = history.replace(', 241, false)', ', 241 + role_offset, false)')
history = history.replace(', 257);', ', 257 + role_offset);')
new = new[:history_begin] + history + new[history_end:]
assert new.count('Value append_sparse_attention(') == 1
assert new.count('  auto qa = glm::projection(') == original.count('  auto qa = glm::projection(')
assert 'const auto pool_count = (position + 1) / 4;' not in shared
patch = ''.join(difflib.unified_diff(original.splitlines(True), new.splitlines(True),
    fromfile='a/tests/compute_models/glm_mtp_state_consumer_test.cc',
    tofile='b/tests/compute_models/glm_mtp_state_consumer_test.cc'))
(S / 'target43-attention-extract.proposal.diff').write_text(patch, encoding='utf-8', newline='')
helper = R / 'tests/compute_models/glm_mtp_target43_component.h'
(S / 'glm_mtp_target43_component.h').write_bytes(helper.read_bytes())
facts = dict(
    status='unapplied source-only proposal, no native compilation or execution',
    basis=dict(path=str(source), bytes=source.stat().st_size,
               sha256=hashlib.sha256(source.read_bytes()).hexdigest()),
    patch='target43-attention-extract.proposal.diff',
    proposal_sha256=hashlib.sha256(new.encode()).hexdigest(),
    helper=dict(path=str(helper), bytes=helper.stat().st_size,
                sha256=hashlib.sha256(helper.read_bytes()).hexdigest()),
    native_builds=0, native_runs=0, downloads=0)
(S / 'target43-proposal-source.json').write_text(json.dumps(facts, indent=2) + '\n')
print(json.dumps(facts, indent=2))
