from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional

import torch

from sglang.kernels.ops.kvcache.cache_ops import absorbed_bmm_concat_cast_q_fp8
from sglang.kernels.ops.quantization.fp8_kernel import (
    per_tensor_quant_mla_fp8,
    per_token_group_quant_mla_deep_gemm_masked_fp8,
)
from sglang.srt.compilation.compilation_config import register_split_op
from sglang.srt.environ import envs
from sglang.srt.layers import deep_gemm_wrapper
from sglang.srt.layers.attention.dsa.utils import is_graph_dsa_split_op_surface
from sglang.srt.layers.attention.dsa_backend import prepare_kv_for_attention
from sglang.srt.layers.communicator import get_attn_tp_context
from sglang.srt.layers.dcp import (
    all_gather_kv_cache_for_mla_extend,
    all_gather_q_for_mla_decode,
    cp_lse_ag_out_rs_mla,
    dcp_a2a_lse_reduce,
)
from sglang.srt.layers.logits_processor import get_in_autotune_dummy_run
from sglang.srt.layers.radix_attention import unified_attention_with_output
from sglang.srt.lora.deepseek_mla_correction import (
    apply_q_correction as apply_kv_b_lora_q_correction,
)
from sglang.srt.lora.deepseek_mla_correction import (
    apply_v_correction as apply_kv_b_lora_v_correction,
)
from sglang.srt.lora.deepseek_mla_correction import (
    is_kv_b_lora_active,
)
from sglang.srt.model_executor.forward_batch_info import ForwardBatch
from sglang.srt.model_executor.forward_context import (
    get_attn_backend,
    get_token_to_kv_pool,
)
from sglang.srt.model_executor.runner_backend_utils.breakable_cuda_graph import (
    eager_on_graph,
)
from sglang.srt.model_executor.runner_backend_utils.breakable_cuda_graph.context import (
    is_in_breakable_cuda_graph,
)
from sglang.srt.model_executor.runner_backend_utils.tc_piecewise_cuda_graph import (
    get_tc_piecewise_forward_context,
    is_in_tc_piecewise_cuda_graph,
)
from sglang.srt.models.deepseek_common.utils import (
    FORWARD_ABSORB_CORE_ATTENTION_BACKENDS,
    _is_cpu,
    _is_cublas_ge_129,
    _is_cuda,
    _is_hip,
    _is_musa,
)
from sglang.srt.runtime_context import get_exec, get_parallel
from sglang.srt.state_capturer.indexer_topk import (
    maybe_capture_indexer_topk,
)
from sglang.srt.utils import BumpAllocator
from sglang.srt.utils.custom_op import register_custom_op

logger = logging.getLogger(__name__)
_SGLANG_EXPERIMENTAL_LORA_OPTI = envs.SGLANG_EXPERIMENTAL_LORA_OPTI.get()
_ENABLE_DSA_Q8KV8_BORN_FP8_Q = envs.SGLANG_ENABLE_DSA_Q8KV8_BORN_FP8_Q.get()
_ENABLE_DSA_Q8KV8_QPREP_OVERLAP = envs.SGLANG_ENABLE_DSA_Q8KV8_QPREP_OVERLAP.get()

if TYPE_CHECKING:
    from sglang.srt.models.deepseek_v2 import DeepseekV2AttentionMLA


@dataclass(frozen=True)
class MlaBmmFusionPlan:
    q_nope_t: torch.Tensor
    q_nope_out_buf: torch.Tensor
    q_nope_out_view: torch.Tensor
    attn_output_buf: torch.Tensor


def _select_local_dcp_heads_for_autotune(
    attn_output: torch.Tensor, num_local_heads: int
) -> torch.Tensor:
    """Select this rank's head shard without communicating dummy outputs."""
    rank = get_parallel().attn_dcp_rank
    return attn_output.narrow(1, rank * num_local_heads, num_local_heads)


def is_dcp_mla_decode_phase(forward_batch: ForwardBatch) -> bool:
    if not get_parallel().dcp_enabled:
        return False
    return (
        forward_batch.forward_mode.is_decode()
        or forward_batch.forward_mode.is_target_verify()
    )


def is_mla_dcp_lse_base_on_e(attention_backend: Optional[str]) -> bool:
    return attention_backend in {"flashmla", "cutedsl_mla", "aiter"}


if _is_cuda:
    from sglang.kernels.ops.gemm import bmm_fp8


def should_defer_dsa_cp_kv_gather(
    *,
    dsa_prefill_cp: bool,
    fuse_rope_for_trtllm_mla: bool,
) -> bool:
    """Compatibility predicate imported by the unchanged ROCm MLA path."""
    return dsa_prefill_cp and fuse_rope_for_trtllm_mla


def _apply_attention_output_gate(module, attn_output, gate):
    apply_gate = getattr(module, "apply_attention_output_gate", None)
    if apply_gate is not None:
        return apply_gate(attn_output, gate)
    if hasattr(module, "_apply_gated"):
        return module._apply_gated(attn_output, gate)
    raise RuntimeError(
        "Prepared MLA attention gates are unsigmoided and require a "
        "model-specific application hook"
    )


class DeepseekMLAForwardMixin:
    def init_mla_forward(self: DeepseekV2AttentionMLA):
        self.flashinfer_mla_disable_ragged = (
            get_exec().kernel.flashinfer_mla_disable_ragged
        )

    def should_run_indexer(
        self: DeepseekV2AttentionMLA,
        prev_topk_indices: Optional[torch.Tensor] = None,
    ) -> bool:
        """Whether this layer runs its own indexer vs reusing carried topk.

        skip_topk (shared) layers carry no indexer weights in the checkpoint,
        so they must reuse the carried topk and never run the indexer. Do NOT
        widen this to `or prev_topk_indices is None` (the upstream gate): that
        recomputes with an uninitialized indexer whenever cross-layer
        propagation is unavailable (e.g. the TBO op path drops topk_indices),
        reintroducing the >index_topk garbling. The is_nextn clause is the
        sole intentional fallback (the NextN layer has its own weights).

        Eager-MHA prefill calls this with no argument: it needs no topk for
        the current forward, but producer layers must still fill their indexer
        K cache for later MLA/decode; shared layers' cache is never read, so
        filling it is dead work.
        """
        return not self.skip_topk or (self.is_nextn and prev_topk_indices is None)

    def _can_fuse_bmm_into_attention(
        self: DeepseekV2AttentionMLA, forward_batch: ForwardBatch
    ) -> bool:
        if getattr(self, "_kimi_split_gguf_kv_b", False):
            return False
        # Shared activation surface with the DSA indexer graph dispatch
        # (in piecewise/breakable graph + non-speculative extend). Like the indexer
        # dispatch, this fusion is on by default on that surface.
        if not is_graph_dsa_split_op_surface(forward_batch):
            return False
        if not self.use_dsa:
            return False
        if self.use_deep_gemm_bmm:
            return False
        if is_kv_b_lora_active(self):
            return False
        if getattr(self, "learnable_sink_param", None) is not None:
            return False
        # The isolated 1-kernel graph is the bf16 fallback BMM. The fp8 and
        # DeepGEMM branches already use different fused paths.
        if self.w_kc.dtype == torch.float8_e4m3fn:
            return False
        if self.current_attention_backend not in FORWARD_ABSORB_CORE_ATTENTION_BACKENDS:
            return False
        return True

    def _split_q_nope_pe(
        self: DeepseekV2AttentionMLA,
        q: torch.Tensor,
        latent_cache: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        q_nope, q_pe = q.split([self.qk_nope_head_dim, self.qk_rope_head_dim], dim=-1)
        k_pe = latent_cache[..., self.kv_lora_rank :].unsqueeze(1)
        return q_nope, q_pe, k_pe

    def _make_mla_bmm_fusion_plan(
        self: DeepseekV2AttentionMLA,
        q: torch.Tensor,
        q_nope: torch.Tensor,
    ) -> MlaBmmFusionPlan:
        q_nope_out_buf = q.new_empty(
            (
                self.num_local_heads,
                q.shape[0],
                self.kv_lora_rank,
            )
        )
        q_nope_out_view = q_nope_out_buf.transpose(0, 1)
        attn_output_buf = q.new_empty(
            (
                q.shape[0],
                self.num_local_heads * self.kv_lora_rank,
            )
        )
        return MlaBmmFusionPlan(
            q_nope_t=q_nope.transpose(0, 1),
            q_nope_out_buf=q_nope_out_buf,
            q_nope_out_view=q_nope_out_view,
            attn_output_buf=attn_output_buf,
        )

    def _q8kv8_born_fp8_q_backend(
        self: DeepseekV2AttentionMLA,
        forward_batch: ForwardBatch,
        llama_4_scaling: Optional[torch.Tensor],
    ):
        """Return the DSA backend iff the born-fp8 q fast path can run.

        Gated by SGLANG_ENABLE_DSA_Q8KV8_BORN_FP8_Q (checked by the caller).
        When this returns a backend, the bf16 absorbed bmm + the standalone
        concat_and_cast_q_fp8_pad are replaced by one fused kernel that writes
        the fp8 q directly into the backend's q8kv8 buffer; q_nope_out becomes
        a NaN sentinel.  Every condition here must therefore guarantee that
        forward_extend consumes q via _forward_flashmla_sparse_q8kv8 and that
        nothing else reads q_nope_out's payload.
        """
        from sglang.srt.model_executor.runner import get_is_capture_mode

        if llama_4_scaling is not None:
            return None
        if _is_hip or _is_cpu:
            return None
        if self.current_attention_backend not in FORWARD_ABSORB_CORE_ATTENTION_BACKENDS:
            return None
        if self.use_deep_gemm_bmm:
            return None
        w_kc = self.w_kc
        if w_kc is None or w_kc.dtype != torch.bfloat16:
            return None
        if is_kv_b_lora_active(self) or _SGLANG_EXPERIMENTAL_LORA_OPTI:
            return None
        # The fused kernel consumes the post-rope q_pe, so the eager rope
        # apply below must run (mirror of its condition).
        if self.rotary_emb is None:
            return None
        if self._fuse_rope_for_trtllm_mla(forward_batch):
            return None
        # Graph/compile surfaces run their own dispatch; the python-side
        # stash handshake is eager-only.
        if is_graph_dsa_split_op_surface(forward_batch):
            return None
        if get_tc_piecewise_forward_context() is not None:
            return None
        if is_in_breakable_cuda_graph():
            return None
        if get_is_capture_mode():
            return None
        if get_parallel().dcp_enabled:
            return None
        # Kernel shape constraints (tl.arange / tl.dot / block tiling).  K
        # (qk_nope_head_dim) needs only K % 16 == 0 and K <= 256: power-of-2
        # K (DeepSeek 128) takes the kernel's preload-once path, other K
        # (GLM-5 192) its split-K loop.
        k_dim = self.qk_nope_head_dim
        rope_dim = self.qk_rope_head_dim
        if k_dim < 16 or k_dim > 256 or k_dim % 16 != 0:
            return None
        if rope_dim <= 0 or (rope_dim & (rope_dim - 1)) != 0:
            return None
        if self.kv_lora_rank % 128 != 0:
            return None
        if tuple(w_kc.shape) != (self.num_local_heads, k_dim, self.kv_lora_rank):
            return None
        backend = get_attn_backend()
        eligible = getattr(backend, "q8kv8_born_fp8_q_eligible", None)
        if eligible is None or not eligible(forward_batch, self.num_local_heads):
            return None
        return backend

    def forward_absorb_prepare(
        self: DeepseekV2AttentionMLA,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        forward_batch: ForwardBatch,
        zero_allocator: BumpAllocator,
        llama_4_scaling: Optional[torch.Tensor] = None,
        prev_topk_indices: Optional[torch.Tensor] = None,
    ):
        from sglang.srt.model_executor.runner import get_is_capture_mode

        # Q8KV8 q-prep/indexer overlap handshake (see the fork site below):
        # True between the alt-stream fork and its consumption in the born
        # block; also suppresses the duplicate split/rope on that path.
        self._q8kv8_qprep_overlap_pending = False
        attention_output_gate = (
            self.prepare_attention_output_gate(hidden_states)
            if hasattr(self, "prepare_attention_output_gate")
            else None
        )

        fuse_bmm_attention = (
            self.q_lora_rank is not None
            and self._can_fuse_bmm_into_attention(forward_batch)
        )
        # --dcp-replicate-q-proj: project full-head Q locally from pre-gathered
        # weights and skip the per-layer Q all-gather (bf16 decode absorb only).
        q_replicate_active = (
            get_parallel().dcp_replicate_q_proj
            and is_dcp_mla_decode_phase(forward_batch)
            and not self.use_deep_gemm_bmm
            and self.w_kc_qrep is not None
            and self.q_b_proj_qrep_weight is not None
        )
        if q_replicate_active:
            # force standard absorb so the full-head w_kc bmm runs
            fuse_bmm_attention = False
        q_lora = None
        topk_indices = None
        q_nope = None
        q_pe = None
        k_pe = None
        fusion_plan: Optional[MlaBmmFusionPlan] = None
        if self.q_lora_rank is not None:
            q, latent_cache = (
                get_attn_tp_context()
                .fetch_qkv_latent()
                .split(
                    [self.q_lora_rank, self.kv_lora_rank + self.qk_rope_head_dim],
                    dim=-1,
                )
            )
            k_nope = latent_cache[..., : self.kv_lora_rank]

            # overlap qk norm
            if self.alt_stream is not None and get_is_capture_mode():
                current_stream = torch.cuda.current_stream()
                self.alt_stream.wait_stream(current_stream)
                q = self.q_a_layernorm(q)
                with torch.cuda.stream(self.alt_stream):
                    k_nope = self.kv_a_layernorm(k_nope)
                current_stream.wait_stream(self.alt_stream)
            else:
                q = self.q_a_layernorm(q)
                k_nope = self.kv_a_layernorm(k_nope)

            # q_lora needed by indexer
            if self.use_dsa:
                if q_lora is None:
                    q_lora = q

            # overlap q_b_proj and indexer during decode
            if (
                self.alt_stream is not None
                and get_is_capture_mode()
                and forward_batch.forward_mode.is_decode_or_idle()
                and q_lora is not None
                and not q_replicate_active
            ):
                current_stream = torch.cuda.current_stream()
                self.alt_stream.wait_stream(current_stream)
                with torch.cuda.stream(self.alt_stream):
                    k_nope = k_nope.unsqueeze(1)
                    q = self.q_b_proj_forward(q)
                if self.should_run_indexer(prev_topk_indices):
                    topk_indices = self.indexer(
                        x=hidden_states,
                        q_lora=q_lora,
                        positions=positions,
                        forward_batch=forward_batch,
                        layer_id=self.layer_id,
                    )
                else:
                    # skip_topk reuses prev layer's indices; mirror into this
                    # layer's slot so the captured buffer matches what's used.
                    topk_indices = maybe_capture_indexer_topk(
                        self.layer_id, prev_topk_indices
                    )
                current_stream.wait_stream(self.alt_stream)
            else:
                k_nope = k_nope.unsqueeze(1)
                if q_replicate_active:
                    # full-head Q from the gathered weight (skips Q all-gather)
                    q = torch.nn.functional.linear(q, self.q_b_proj_qrep_weight).view(
                        -1,
                        self.num_local_heads * get_parallel().attn_dcp_size,
                        self.qk_head_dim,
                    )
                else:
                    q = self.q_b_proj_forward(q)

                # Hoist these above the DSA indexer split op so the indexer
                # and the composite bmm+attention split op are adjacent in FX.
                if fuse_bmm_attention:
                    q_nope, q_pe, k_pe = self._split_q_nope_pe(q, latent_cache)
                    fusion_plan = self._make_mla_bmm_fusion_plan(q, q_nope)

                # Q8KV8 q-prep/indexer overlap (opt-in): the born-fp8 q-prep
                # chain (split -> rope -> fused absorbed-bmm+cast, ~173us)
                # and the indexer chain both fork from the q_a_layernorm
                # output and never touch each other's tensors, so the q-prep
                # can run on alt_stream underneath the indexer.  The fork
                # must be enqueued BEFORE the indexer (a later wait_stream
                # would serialize behind it).  The born predicate itself
                # guarantees eager-only and the plain-rope branch (all fused
                # /skip-rope variants make it return None), so applying rope
                # here is exactly what the skipped block below would do.
                if (
                    _ENABLE_DSA_Q8KV8_QPREP_OVERLAP
                    and _ENABLE_DSA_Q8KV8_BORN_FP8_Q
                    and fusion_plan is None
                    and self.alt_stream is not None
                    and q_lora is not None
                    and self.rotary_emb is not None
                ):
                    _born_backend_early = self._q8kv8_born_fp8_q_backend(
                        forward_batch, llama_4_scaling
                    )
                    if _born_backend_early is not None:
                        q_nope, q_pe, k_pe = self._split_q_nope_pe(q, latent_cache)
                        q_pe, k_pe = self.rotary_emb(positions, q_pe, k_pe)
                        _q_fp8 = _born_backend_early.q8kv8_acquire_born_q_buffer(
                            q_nope.shape[0],
                            self.num_local_heads,
                            self.kv_lora_rank + self.qk_rope_head_dim,
                            q_nope.device,
                        )
                        self.alt_stream.wait_stream(torch.cuda.current_stream())
                        with torch.cuda.stream(self.alt_stream):
                            absorbed_bmm_concat_cast_q_fp8(
                                _q_fp8,
                                q_nope,
                                self.w_kc,
                                q_pe,
                                self.num_local_heads,
                            )
                        self._q8kv8_qprep_overlap_pending = True

                if q_lora is not None:
                    if self.should_run_indexer(prev_topk_indices):
                        topk_indices = self.indexer(
                            x=hidden_states,
                            q_lora=q_lora,
                            positions=positions,
                            forward_batch=forward_batch,
                            layer_id=self.layer_id,
                        )
                    else:
                        topk_indices = maybe_capture_indexer_topk(
                            self.layer_id, prev_topk_indices
                        )
        else:
            if q_replicate_active:
                q = torch.nn.functional.linear(
                    hidden_states, self.q_b_proj_qrep_weight
                ).view(
                    -1,
                    self.num_local_heads * get_parallel().attn_dcp_size,
                    self.qk_head_dim,
                )
            else:
                q = self.q_proj(hidden_states)[0].view(
                    -1, self.num_local_heads, self.qk_head_dim
                )
            latent_cache = self.kv_a_proj_with_mqa(hidden_states)[0]
            k_nope = latent_cache[..., : self.kv_lora_rank]
            k_nope = self.kv_a_layernorm(k_nope).unsqueeze(1)

        if q_nope is None:
            q_nope, q_pe, k_pe = self._split_q_nope_pe(q, latent_cache)

        _kvb_q = None
        born_q_backend = None
        if (
            _ENABLE_DSA_Q8KV8_BORN_FP8_Q
            and fusion_plan is None
            and q_nope.dtype == torch.bfloat16
        ):
            born_q_backend = self._q8kv8_born_fp8_q_backend(
                forward_batch, llama_4_scaling
            )
        if q_replicate_active:
            # full-head absorb with the pre-gathered w_kc (q_nope already full-head)
            q_nope_out = (
                torch.bmm(q_nope.transpose(0, 1), self.w_kc_qrep)
                .transpose(0, 1)
                .contiguous()
            )
        elif getattr(self, "_kimi_split_gguf_kv_b", False):
            from sglang.srt.layers.quantization.gguf import fused_mul_mat_gguf

            k_type = int(self.k_b_qweight_type.weight_type)
            q_nope_out = torch.stack(
                [
                    fused_mul_mat_gguf(q_nope[:, head], self.k_b_qweight[head], k_type)
                    for head in range(self.num_local_heads)
                ],
                dim=1,
            )
        elif fusion_plan is not None:
            # The composite split op fills q_nope_out_buf and attention reads
            # this transposed alias directly.
            q_nope_out = fusion_plan.q_nope_out_view
        elif born_q_backend is not None:
            # Born-fp8 q: skip the bf16 absorbed bmm entirely; the fused
            # bmm+concat+cast kernel (launched after rope below) writes the
            # fp8 q directly into the q8kv8 backend buffer.
            q_nope_out = None
        else:
            if _SGLANG_EXPERIMENTAL_LORA_OPTI:
                # Fork the kv_b q-correction A-step onto the LoRA side stream to overlap the bmm.
                from sglang.srt.lora.trtllm_lora_temp.deepseek_mla_correction import (
                    kv_b_lora_q_prepare,
                )

                _kvb_q = kv_b_lora_q_prepare(self, q_nope)

            if self.use_deep_gemm_bmm:
                (
                    q_nope_val,
                    q_nope_scale,
                    masked_m,
                    expected_m,
                    aligned_m,
                ) = per_token_group_quant_mla_deep_gemm_masked_fp8(
                    q_nope.transpose(0, 1)
                )
                q_nope_out = q_nope.new_empty(
                    (self.num_local_heads, aligned_m, self.kv_lora_rank)
                )
                deep_gemm_wrapper.grouped_gemm_nt_f8f8bf16_masked(
                    (q_nope_val, q_nope_scale),
                    (self.w_kc, self.w_scale_k),
                    q_nope_out,
                    masked_m,
                    expected_m,
                )
                q_nope_out = q_nope_out[:, :expected_m, :]
            elif self.w_kc.dtype == torch.float8_e4m3fn:
                if _is_cpu:
                    q_nope_out = torch.bmm(
                        q_nope.to(torch.bfloat16).transpose(0, 1),
                        self.w_kc.to(torch.bfloat16) * self.w_scale,
                    )
                else:
                    # fix bmm_fp8 error under cublas12.9 caused by bumpallocator, detail in pr#11612
                    q_nope_val, q_nope_scale = per_tensor_quant_mla_fp8(
                        q_nope.transpose(0, 1),
                        (
                            torch.zeros((1,), dtype=torch.float32, device=q_nope.device)
                            if _is_cublas_ge_129
                            else zero_allocator.allocate(1)
                        ),
                    )
                    q_nope_out = bmm_fp8(
                        q_nope_val,
                        self.w_kc,
                        q_nope_scale,
                        self.w_scale,
                        torch.bfloat16,
                    )
            else:
                q_nope_out = torch.bmm(q_nope.transpose(0, 1), self.w_kc)

            q_nope_out = q_nope_out.transpose(0, 1)
            if _SGLANG_EXPERIMENTAL_LORA_OPTI:
                from sglang.srt.lora.trtllm_lora_temp.deepseek_mla_correction import (
                    kv_b_lora_q_apply,
                )

                q_nope_out = kv_b_lora_q_apply(self, q_nope, q_nope_out, _kvb_q)
            elif is_kv_b_lora_active(self):
                q_nope_out = apply_kv_b_lora_q_correction(self, q_nope, q_nope_out)

        fuse_rope_for_trtllm_mla = self._fuse_rope_for_trtllm_mla(forward_batch)
        if (
            self.rotary_emb is not None
            and not fuse_rope_for_trtllm_mla
            # Already applied at the q-prep/indexer overlap fork.
            and not self._q8kv8_qprep_overlap_pending
        ):
            q_pe, k_pe = self.rotary_emb(positions, q_pe, k_pe)

        if born_q_backend is not None:
            # Born-fp8 q (SGLANG_ENABLE_DSA_Q8KV8_BORN_FP8_Q): one fused
            # kernel replaces bmm -> bf16 q_nope_out ->
            # concat_and_cast_q_fp8_pad.  q_nope is the pre-absorb bf16 view
            # (rope only touched the disjoint q_pe columns) and q_pe carries
            # the post-rope values.  The stash is consumed by
            # _forward_flashmla_sparse_q8kv8; q_nope_out becomes a
            # NaN-poisoned shape-only sentinel.
            num_tokens = q_nope.shape[0]
            if self._q8kv8_qprep_overlap_pending:
                # q_fp8 was produced on alt_stream at the fork above; join so
                # everything downstream (incl. the next layer's fork, which
                # reuses the single born-q slot) orders after it.
                torch.cuda.current_stream().wait_stream(self.alt_stream)
                self._q8kv8_qprep_overlap_pending = False
            else:
                q_fp8 = born_q_backend.q8kv8_acquire_born_q_buffer(
                    num_tokens,
                    self.num_local_heads,
                    self.kv_lora_rank + self.qk_rope_head_dim,
                    q_nope.device,
                )
                absorbed_bmm_concat_cast_q_fp8(
                    q_fp8, q_nope, self.w_kc, q_pe, self.num_local_heads
                )
            born_q_backend.q8kv8_stash_born_q(num_tokens, self.attn_mqa.layer_id)
            q_nope_out = born_q_backend.q8kv8_born_q_sentinel(
                num_tokens, self.num_local_heads, self.kv_lora_rank, q_nope.device
            )

        k_nope, k_pe = prepare_kv_for_attention(
            self,
            forward_batch,
            k_nope,
            k_pe,
            defer_materialization=fuse_rope_for_trtllm_mla,
        )

        # all_gather q_pe, q_nope_out,take tp8 as an example， q_pe [B, H, ROPE_DIM], q_nope_out [B, H, NOPE_DIM] gathered to [B, H * dcp_world_size, ROPE_DIM] [B, H * dcp_world_size, NOPE_DIM] for decode batch, and all gather k_pe, k_nope for extend batch.
        if get_parallel().dcp_enabled:
            if is_dcp_mla_decode_phase(forward_batch):
                if not q_replicate_active:
                    q_nope_out, q_pe = all_gather_q_for_mla_decode(
                        q_nope_out=q_nope_out,
                        q_pe=q_pe,
                    )
            elif forward_batch.forward_mode.is_extend():
                # for extend, gather kv
                all_gather_kv_cache_for_mla_extend(
                    get_token_to_kv_pool(),
                    self.attn_mqa,
                    forward_batch.extend_prefix_lens_cpu,
                    forward_batch.attn_dcp_metadata.dcp_local_prefix_kv_indices,
                    forward_batch.attn_dcp_metadata.dcp_extend_prefix_lens_sum,
                    forward_batch.attn_dcp_metadata.dcp_kv_buffer,
                    self.kv_lora_rank,
                    k_nope,
                    k_pe,
                )
            else:
                logger.warning(
                    f"not supported forward_mode {forward_batch.forward_mode}"
                )

        return (
            q_pe,
            k_pe,
            q_nope_out,
            k_nope,
            forward_batch,
            zero_allocator,
            positions,
            topk_indices,
            llama_4_scaling,
            fusion_plan,
            # Bailing's DsV3MLA appends its own gate to inner_state, so this
            # slot is emitted only for models owning the gate hook.
            *(
                (attention_output_gate,)
                if hasattr(self, "prepare_attention_output_gate")
                else ()
            ),
        )

    def forward_absorb_core(
        self: DeepseekV2AttentionMLA,
        q_pe,
        k_pe,
        q_nope_out,
        k_nope,
        forward_batch,
        zero_allocator,
        positions,
        topk_indices,
        llama_4_scaling,
        fusion_plan: Optional[MlaBmmFusionPlan] = None,
        attention_output_gate: Optional[torch.Tensor] = None,
    ):
        save_kv_cache = True

        if self.current_attention_backend in FORWARD_ABSORB_CORE_ATTENTION_BACKENDS:
            extra_args = {}
            if getattr(self, "learnable_sink_param", None) is not None:
                extra_args["attn_sink"] = self.learnable_sink_param
            if self._fuse_rope_for_trtllm_mla(forward_batch):
                extra_args.update(
                    cos_sin_cache=self.rotary_emb.cos_sin_cache,
                    is_neox=self.rotary_emb.is_neox_style,
                    llama_4_scaling=llama_4_scaling,
                )
            if fusion_plan is not None:
                bmm_attention_fn = (
                    bcg_mla_bmm_then_unified_attention
                    if is_in_breakable_cuda_graph()
                    else mla_bmm_then_unified_attention
                )
                bmm_attention_fn(
                    fusion_plan.q_nope_t,
                    self.w_kc,
                    fusion_plan.q_nope_out_buf,
                    q_nope_out,
                    k_nope,
                    fusion_plan.attn_output_buf,
                    save_kv_cache,
                    self.layer_id,
                    q_pe,
                    k_pe,
                    cos_sin_cache=extra_args.get("cos_sin_cache"),
                    is_neox=extra_args.get("is_neox"),
                    llama_4_scaling=extra_args.get("llama_4_scaling"),
                    topk_indices=topk_indices,
                )
                attn_output = fusion_plan.attn_output_buf
            elif is_dcp_mla_decode_phase(forward_batch):
                # set return_lse=True to correct attn_output
                attn_output, lse = self.attn_mqa_for_dcp_decode(
                    q_nope_out,
                    k_nope,
                    k_nope,
                    forward_batch,
                    q_rope=q_pe,
                    k_rope=k_pe,
                    **extra_args,
                    **(
                        dict(topk_indices=topk_indices)
                        if topk_indices is not None
                        else {}
                    ),
                )
            else:
                attn_output = self.attn_mqa(
                    q_nope_out,
                    k_nope,
                    k_nope,
                    forward_batch,
                    q_rope=q_pe,
                    k_rope=k_pe,
                    **extra_args,
                    **(
                        dict(topk_indices=topk_indices)
                        if topk_indices is not None
                        else {}
                    ),
                )
        else:
            q = torch.cat([q_nope_out, q_pe], dim=-1)
            k = torch.cat([k_nope, k_pe], dim=-1)

            # Apply llama 4 scaling if provided
            if llama_4_scaling is not None:
                q *= llama_4_scaling

            attn_output = self.attn_mqa(
                q,
                k,
                k_nope,
                forward_batch,
                save_kv_cache=save_kv_cache,
                **(dict(topk_indices=topk_indices) if topk_indices is not None else {}),
            )

        # correct attn_output with respect to lse from other ranks
        if is_dcp_mla_decode_phase(forward_batch):
            attn_output = attn_output.view(
                -1,
                self.num_local_heads * get_parallel().attn_dcp_size,
                self.kv_lora_rank,
            )
            if get_in_autotune_dummy_run():
                # The synthetic FlashInfer MoE autotune pass discards model
                # outputs. Avoid an unnecessary cross-node MNNVL exchange of
                # zero attention partials.
                attn_output = _select_local_dcp_heads_for_autotune(
                    attn_output, self.num_local_heads
                )
            else:
                dcp_comm_backend = get_parallel().dcp_comm_backend
                is_lse_base_on_e = is_mla_dcp_lse_base_on_e(
                    self.current_attention_backend
                )
                if dcp_comm_backend in ("a2a", "fi_a2a"):
                    # A2A exchange of head partials + LSE, then local Triton combine.
                    attn_output = dcp_a2a_lse_reduce(
                        attn_output.contiguous(),
                        lse.contiguous(),
                        get_parallel().dcp_group,
                        is_lse_base_on_e=is_lse_base_on_e,
                        comm_backend=dcp_comm_backend,
                    )
                else:
                    attn_output = cp_lse_ag_out_rs_mla(
                        attn_output,
                        lse,
                        get_parallel().dcp_group,
                        is_lse_base_on_e=is_lse_base_on_e,
                    )
                    attn_output = attn_output.transpose(0, 1)
        attn_output = attn_output.view(-1, self.num_local_heads, self.kv_lora_rank)

        _kvb_v = None
        if _SGLANG_EXPERIMENTAL_LORA_OPTI:
            # Fork the kv_b v-correction A-step onto the LoRA side stream to overlap the bmm.
            from sglang.srt.lora.trtllm_lora_temp.deepseek_mla_correction import (
                kv_b_lora_v_prepare,
            )

            _kvb_v = kv_b_lora_v_prepare(self, attn_output)

        if getattr(self, "_kimi_split_gguf_kv_b", False):
            from sglang.srt.layers.quantization.gguf import fused_mul_mat_gguf

            v_type = int(self.v_b_qweight_type.weight_type)
            attn_bmm_output = torch.stack(
                [
                    fused_mul_mat_gguf(
                        attn_output[:, head], self.v_b_qweight[head], v_type
                    )
                    for head in range(self.num_local_heads)
                ],
                dim=1,
            ).flatten(1, 2)
        elif self.use_deep_gemm_bmm:
            (
                attn_output_val,
                attn_output_scale,
                masked_m,
                expected_m,
                aligned_m,
            ) = per_token_group_quant_mla_deep_gemm_masked_fp8(
                attn_output.transpose(0, 1)
            )
            attn_bmm_output = attn_output.new_empty(
                (self.num_local_heads, aligned_m, self.v_head_dim)
            )
            deep_gemm_wrapper.grouped_gemm_nt_f8f8bf16_masked(
                (attn_output_val, attn_output_scale),
                (self.w_vc, self.w_scale_v),
                attn_bmm_output,
                masked_m,
                expected_m,
            )
            attn_bmm_output = (
                attn_bmm_output[:, :expected_m, :].transpose(0, 1).flatten(1, 2)
            )
        elif self.w_vc.dtype == torch.float8_e4m3fn:
            if _is_cpu:
                attn_bmm_output = torch.bmm(
                    attn_output.to(torch.bfloat16).transpose(0, 1),
                    self.w_vc.to(torch.bfloat16) * self.w_scale,
                )
                attn_bmm_output = attn_bmm_output.transpose(0, 1).flatten(1, 2)
            else:
                attn_output_val, attn_output_scale = per_tensor_quant_mla_fp8(
                    attn_output.transpose(0, 1),
                    (
                        torch.zeros(
                            (1,), dtype=torch.float32, device=attn_output.device
                        )
                        if _is_cublas_ge_129
                        else zero_allocator.allocate(1)
                    ),
                )
                attn_bmm_output = bmm_fp8(
                    attn_output_val,
                    self.w_vc,
                    attn_output_scale,
                    self.w_scale,
                    torch.bfloat16,
                )
                attn_bmm_output = attn_bmm_output.transpose(0, 1).flatten(1, 2)
        elif _is_musa:
            attn_bmm_output = torch.bmm(
                attn_output.to(torch.bfloat16).transpose(0, 1), self.w_vc
            )
            attn_bmm_output = attn_bmm_output.transpose(0, 1).flatten(1, 2)
        else:
            if is_in_tc_piecewise_cuda_graph():
                # torch dynamo requires out= op was called where output tensor was non-contiguous
                attn_bmm_output = (
                    torch.bmm(attn_output.transpose(0, 1), self.w_vc)
                    .transpose(0, 1)
                    .flatten(1, 2)
                )
            else:
                attn_bmm_output = torch.empty(
                    (attn_output.shape[0], self.num_local_heads * self.v_head_dim),
                    dtype=attn_output.dtype,
                    device=attn_output.device,
                )
                torch.bmm(
                    attn_output.transpose(0, 1),
                    self.w_vc,
                    out=attn_bmm_output.view(
                        -1, self.num_local_heads, self.v_head_dim
                    ).transpose(0, 1),
                )
        if _SGLANG_EXPERIMENTAL_LORA_OPTI:
            from sglang.srt.lora.trtllm_lora_temp.deepseek_mla_correction import (
                kv_b_lora_v_apply,
            )

            attn_bmm_output = kv_b_lora_v_apply(
                self, attn_output, attn_bmm_output, _kvb_v
            )
        elif is_kv_b_lora_active(self):
            attn_bmm_output = apply_kv_b_lora_v_correction(
                self, attn_output, attn_bmm_output
            )
        if attention_output_gate is not None:
            attn_bmm_output = _apply_attention_output_gate(
                self, attn_bmm_output, attention_output_gate
            )
        output, _ = self.o_proj(attn_bmm_output)

        if self.next_skip_topk is None:
            return output

        # Return topk_indices for the next layer when enabling index cache
        if not self.next_skip_topk:
            return output, None
        else:
            return output, topk_indices

    def _fuse_rope_for_trtllm_mla(
        self: DeepseekV2AttentionMLA, forward_batch: ForwardBatch
    ) -> bool:
        """
        Check if we should skip rope and do fused rope+quantize for TRTLLM MLA decode in fp8_e4m3 path.
        """
        if self.rotary_emb is None:
            return False
        if self.current_attention_backend in ("dsa", "nsa"):
            return (
                get_exec().kernel.dsa_decode_backend == "trtllm"
                or get_exec().kernel.dsa_prefill_backend == "trtllm"
            ) and get_attn_backend().kv_cache_dtype == torch.float8_e4m3fn

        return (
            self.rotary_emb is not None
            and self.current_attention_backend
            in ("trtllm_mla", "tokenspeed_mla", "cutedsl_mla")
            and (
                forward_batch.forward_mode.is_decode_or_idle()
                or forward_batch.forward_mode.is_target_verify()
            )
            and get_attn_backend().data_type == torch.float8_e4m3fn
        )


# Fuses the absorb BMM (`q_nope @ w_kc`) with `unified_attention_with_output`
# into one eager split op under both PCG and BCG. Without this, the bf16
# fallback BMM is captured alone in its own single-kernel CUDA graph submodule,
# paying per-submodule host overhead with no fusion benefit.
#
# `q_nope_out_view` aliases `q_nope_out_buf` (transposed). The op writes
# `q_nope_out_buf` via `torch.bmm(..., out=...)` and then reads through
# `q_nope_out_view`, so the alias's storage is mutated too. Declare it in
# `mutates_args` to keep the schema honest.
@register_custom_op(
    mutates_args=["q_nope_out_buf", "q_nope_out_view", "attn_output_buf"]
)
@register_split_op()
def mla_bmm_then_unified_attention(
    q_nope_t: torch.Tensor,
    w_kc: torch.Tensor,
    q_nope_out_buf: torch.Tensor,
    q_nope_out_view: torch.Tensor,
    k_nope: torch.Tensor,
    attn_output_buf: torch.Tensor,
    save_kv_cache: bool,
    layer_id: int,
    q_pe: torch.Tensor,
    k_pe: torch.Tensor,
    cos_sin_cache: Optional[torch.Tensor] = None,
    is_neox: Optional[bool] = None,
    llama_4_scaling: Optional[torch.Tensor] = None,
    topk_indices: Optional[torch.Tensor] = None,
) -> None:
    torch.bmm(q_nope_t, w_kc, out=q_nope_out_buf)
    unified_attention_with_output(
        q_nope_out_view,
        k_nope,
        k_nope,
        attn_output_buf,
        save_kv_cache,
        layer_id,
        q_rope=q_pe,
        k_rope=k_pe,
        cos_sin_cache=cos_sin_cache,
        is_neox=is_neox,
        llama_4_scaling=llama_4_scaling,
        topk_indices=topk_indices,
    )


bcg_mla_bmm_then_unified_attention = eager_on_graph(True)(
    mla_bmm_then_unified_attention
)
