"""Incremental encoded-state consumers; root serializes native work."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BE = R / '.scratch/fp8-quant-output-20261023'
BD = R / '.scratch/glm-mtp-seed-cache-20261022'
spec = importlib.util.spec_from_file_location('encoded_cached_build', BE / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = BE / 'tests-link1'
CAST = R / '.scratch/architecture-refactor-2026-10-18/cuda-native-storage-cast'
SOURCES = {
    'glm-state': R / 'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'glm-cache': R / 'tests/compute_models/glm_official_index_cache_test.cc',
    'dspark-state': R / 'tests/compute_models/dspark_original_state_consumer_test.cc',
    'dspark-history': R / 'tests/compute_models/dspark_main_history_test.cc',
    'dspark-target': R / 'tests/compute_models/dspark_target_binding_test.cc',
    'tensor-provider': R / 'src/compute_provider_cuda/tensor_provider.cc',
    'tensor-test': R / 'tests/compute_provider_cuda/tensor_test.cc',
    'tensor-kernel': R / 'src/compute_provider_cuda/tensor_kernel.cu',
}
RECIPES = {
    'glm-state': BD / 'compile4/glm-state/identity.json',
    'glm-cache': BE / 'compile1/glm-cache/identity.json',
    'dspark-state': BD / 'compile8/dspark-history/identity.json',
    'dspark-history': BD / 'compile8/dspark-history/identity.json',
    'dspark-target': BD / 'compile1/dspark-target/identity.json',
    'tensor-provider': CAST / 'green/tensor-provider-identity.json',
    'tensor-test': BE / 'compile1/glm-cache/identity.json',
    'tensor-kernel': CAST / 'dense/tensor-kernel-identity.json',
}


def host(tag, attempt):
    recipe = c.read(RECIPES[tag])
    if tag == 'dspark-state':
        recipe['command'] = [x for x in recipe['command'] if not x.startswith('/DHYLE_TEST_DSPARK_HISTORY_')]
        recipe['command'] += ['/DHYLE_TEST_DSPARK_STATE_CPU=1', '/DHYLE_TEST_DSPARK_STATE_CUDA=1']
    if tag == 'tensor-test':
        recipe['command'] = [x for x in recipe['command'] if not x.startswith('/DHYLE_TEST_GLM_CACHE_')]
    path = S / 'recipes' / (tag + '.json')
    path.parent.mkdir(exist_ok=True)
    c.save(path, recipe)
    h.RECIPES[tag], h.SOURCES[tag] = path, SOURCES[tag]
    h.compile_one(tag, attempt)


def kernel(attempt):
    tag = 'tensor-kernel'
    recipe = c.read(RECIPES[tag])
    out = S / f'compile{attempt}' / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    command, skip = [], False
    for arg in recipe['command']:
        if skip:
            skip = False
            continue
        if arg in ('-c', '-o', '-MT', '-MF'):
            skip = True
        elif not arg.startswith('-Xcompiler=-Fd'):
            command.append(arg)
    host_recipe = c.read(RECIPES['tensor-provider'])
    command += ['-ccbin', str(Path(host_recipe['command'][0]).parent),
        '-MT', str(out / (tag + '.obj')), '-MF', str(out / (tag + '.d')),
        '-c', str(SOURCES[tag]), '-o', str(out / (tag + '.obj')),
        '-Xcompiler=-Fd' + str(out / (tag + '.pdb')) + ',-FS']
    assert '-std=c++20' in command
    assert '--generate-code=arch=compute_89,code=[sm_89]' in command
    frozen = b.identity(SOURCES[tag])
    snapshot = out / 'source' / SOURCES[tag].relative_to(R)
    snapshot.parent.mkdir(parents=True)
    snapshot.write_bytes(SOURCES[tag].read_bytes())
    c.save(out / 'plan.json', dict(source=frozen, command=command,
        recipe=b.identity(RECIPES[tag]), SDK_builds=0, NVCC_translation_units=1))
    env, _ = b.environment(host_recipe['command'], [], out)
    c.execute('compile', command, env, out)
    assert b.identity(SOURCES[tag]) == frozen
    c.save(out / 'identity.json', dict(source=frozen,
        object=b.identity(out / (tag + '.obj')), command=command,
        dependencies=[b.identity(SOURCES[tag]), b.identity(SOURCES[tag].with_suffix('.h'))],
        dependency_file=b.identity(out / (tag + '.d')), compiler=b.identity(command[0])))
    print('COMPILED tensor-kernel', flush=True)


def latest(tag):
    rows = sorted(S.glob(f'compile*/{tag}/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
    if not rows:
        raise RuntimeError('Missing compiled consumer: ' + tag)
    path = rows[-1]
    rec = c.read(path)
    assert all(b.identity(x['path']) == x for x in (rec['source'], rec['object'], *rec['dependencies']))
    return path, rec


def link(attempt, tags):
    base = c.read(BASE / 'link-plan.json')
    replaced = {c.key(str(SOURCES[tag])) for tag in tags}
    remove, records = set(), []
    for row in base['compiled_records']:
        rec = c.read(row['path'])
        if c.key(rec['source']['path']) in replaced:
            remove.add(c.key(rec['object']['path']))
        else:
            records.append(row)
    for tag in tags:
        if tag not in ('dspark-state', 'tensor-test'):
            old = c.key(c.read(RECIPES[tag])['object']['path'])
            if any(c.key(x['path']) == old for x in base['inputs']):
                remove.add(old)
    added = [latest(tag) for tag in tags]
    inputs = [rec['object'] for _, rec in added] + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [rec['object']['path'] for _, rec in added]
    out = S / f'tests-link{attempt}'
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    image = out / 'encoded-state-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        compiled_records=[b.identity(path) for path, _ in added] + records,
        base=b.identity(BASE / 'link-plan.json'), SDK_builds=0, native_CPU_builds=0,
        NVCC_translation_units=int('tensor-kernel' in tags), shaders=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(BASE / 'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path']) == dll
        os.link(dll['path'], out / Path(dll['path']).name)
    runtime['PATH'] = str(out) + ';' + ';'.join(p for p in runtime['PATH'].split(';') if c.key(p) != c.key(str(BASE)))
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=b.identity(image)))
    print('LINKED encoded state consumers', flush=True)


def run(link_attempt, attempt, test_filter, expected):
    spec_run = importlib.util.spec_from_file_location('encoded_run_helpers', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    q = importlib.util.module_from_spec(spec_run)
    spec_run.loader.exec_module(q)
    folder = S / f'tests-link{link_attempt}'
    image = c.read(folder / 'ready.json')['image']
    assert b.identity(image['path']) == image
    env = os.environ.copy()
    env['PATH'] = c.read(folder / 'runtime-environment.json')['PATH']
    env['HYLE_DSPARK_TARGET_ROLES_DIR'] = str(R / '.scratch/glm-mtp-catchup-20261022/original-dspark-target')
    env['HYLE_DSPARK_HISTORY_ROLES_DIR'] = str(BD / 'original-dspark-history')
    env['HYLE_DSPARK_MARKOV_DIR'] = str(R / '.scratch/dspark-mtp-integration-20261022/original-markov')
    env['HYLE_DSPARK_CONFIDENCE_BF16'] = str(R / '.scratch/qwen-mtp-next-20261022/original-confidence/conf_proj.weight.bf16')
    out = S / f'checks{attempt}'
    xml = out / 'results.xml'
    process = q.execute([image['path'], '--gtest_filter=' + test_filter, '--gtest_output=xml:' + str(xml)], env, out, timeout=600)
    result = dict(process=process, image=image, throughput_evidence=False, physical_memory_evidence=False, whole_original_model=False)
    if xml.is_file():
        tree = ET.parse(xml).getroot()
        result.update(tests=int(tree.attrib['tests']), failures=int(tree.attrib['failures']), errors=int(tree.attrib['errors']),
            disabled=int(tree.attrib['disabled']), skips=sum(case.find('skipped') is not None for case in tree.iter('testcase')),
            cases=[dict(attributes=case.attrib, properties={p.attrib['name']: p.attrib['value'] for p in case.iter('property')}) for case in tree.iter('testcase')])
    c.save(out / 'summary.json', result)
    assert process['exit'] == 0 and not process['timed_out'], process
    assert result.get('tests') == expected and not any(result[k] for k in ('failures', 'errors', 'disabled', 'skips')), result
    print('PASS encoded state checks', expected, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('actions', nargs='+', choices=[*SOURCES, 'link', 'run'])
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--only', nargs='+', choices=list(SOURCES), default=['glm-state', 'glm-cache'])
    parser.add_argument('--filter', default='*')
    parser.add_argument('--expected-tests', type=int, required=False, default=19)
    args = parser.parse_args()
    for action in args.actions:
        if action == 'link': link(args.attempt, args.only)
        elif action == 'run': run(args.link_attempt, args.attempt, args.filter, args.expected_tests)
        elif action == 'tensor-kernel': kernel(args.attempt)
        else: host(action, args.attempt)
