"""Attach final source review and exact cleanup facts, without native work."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
E = R / 'docs/evidence/correctness/mtp-encoded-state-2026-10-23.json'
Z = E.with_suffix('.zip')


def identity(p):
    p = Path(p)
    return dict(path=str(p.relative_to(R)), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


paths = [S / 'review/dspark-revision4-state-review.json',
         S / 'review/integer-cast-independent.json',
         S / 'review/integer_cast_independent_review.py',
         S / 'cleanup-result.json', R / 'test.ps1',
         R / 'docs/developer/current-work.md', Path(__file__)]
with zipfile.ZipFile(Z, 'a', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    existing = set(z.namelist())
    for p in paths:
        name = p.relative_to(R).as_posix()
        if name in existing:
            assert z.read(name) == p.read_bytes(), name
        else:
            z.write(p, name)
    count = len(z.namelist())
record = json.loads(E.read_text(encoding='utf-8'))
record.update(archive=identity(Z), archive_items=count,
              final_source_reviews=[identity(p) for p in paths[:3]],
              cleanup=json.loads((S / 'cleanup-result.json').read_text(encoding='utf-8-sig')),
              current_work=identity(R / 'docs/developer/current-work.md'))
E.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=identity(E), archive=identity(Z)),
    ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(evidence=identity(E), archive=identity(Z)), ensure_ascii=False))
