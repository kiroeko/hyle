"""Publish scoped BF correctness facts; never run native or remove outputs."""
from pathlib import Path
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
DEST = R / 'docs/evidence/correctness'


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def identity(p):
    p = Path(p)
    return dict(path=str(p.relative_to(R)), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())


final = [read(S / f'checks{i}/summary.json') for i in (5, 6)]
for run in final:
    assert run['process']['exit'] == 0 and not run['process']['timed_out']
    assert not any(run[k] for k in ('failures', 'errors', 'disabled', 'skips'))
assert sum(r['tests'] for r in final) == 26
cases = [case for run in final for case in run['cases']]
assert len({c['attributes']['classname']+'.'+c['attributes']['name'] for c in cases}) == 26
graphs = sum(int(case['properties'].get('actual_submissions', 0)) for case in cases)
quant_ok = sum(int(case['properties'].get('successful_submissions', 0)) for case in cases)
quant_failed = sum(int(case['properties'].get('failed_submissions', 0)) for case in cases)

sources = [
    'src/compute_provider_cuda/tensor_provider.cc',
    'src/compute_provider_cuda/tensor_kernel.h',
    'src/compute_provider_cuda/tensor_kernel.cu',
    'tests/compute_provider_cuda/tensor_test.cc',
    'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'tests/compute_models/glm_official_index_cache.h',
    'tests/compute_models/cpu_c4_model_branches.h',
    'tests/compute_models/dspark_complete_graph_fixture.h',
    'tests/compute_models/dspark_prepare_constants.h',
    'tests/compute_models/dspark_original_state_consumer.h',
    'tests/compute_models/dspark_original_state_consumer_test.cc',
    'tests/graph_route_cuda/dspark_cuda_consumer_fixture.h',
    'tests/graph_route_cpu/CMakeLists.txt',
    'tests/graph_route_cuda/CMakeLists.txt',
]
paths = [R / name for name in sources] + [S / 'build.py', Path(__file__)]
for folder in ('cmake-source', 'nextn-source', 'target43-working', 'dspark-source',
               'integer-cast-source', 'review', 'recipes'):
    paths += [p for p in (S / folder).rglob('*') if p.is_file() and
              p.suffix.lower() in ('.h', '.cc', '.cu', '.py', '.json', '.txt', '.diff')]
for prefix in ('checks', 'compile', 'tests-link'):
    for folder in S.glob(prefix+'*'):
        paths += [p for p in folder.rglob('*') if p.is_file() and
                  p.suffix.lower() in ('.h', '.cc', '.cu', '.py', '.json', '.log', '.xml', '.d')]
paths = sorted(set(p.resolve() for p in paths))
archive = DEST / 'mtp-encoded-state-2026-10-23.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for path in paths:
        z.write(path, path.relative_to(R).as_posix())

record = dict(
    date='2026-10-23', stage='BF', status='bounded implementation and correctness progress; broad goal incomplete',
    final_tests=26, final_failures=0, final_skips=0,
    model_graph_submissions=graphs, quant_graph_successes=quant_ok,
    quant_expected_NaN_completion_failures=quant_failed,
    graph_submission_attempts=graphs+quant_ok+quant_failed,
    graph_count_scope='Sum actual_submissions model properties plus successful_submissions/failed_submissions quant properties; Direct Cast invocations are not Graph submissions.',
    system='Windows local CPU and RTX4070 CUDA, cached toolchain/native workers; no Linux/macOS or Vulkan model suite this round',
    runs=final, earlier_runs=[read(S / f'checks{i}/summary.json') for i in (1, 2, 3, 4)],
    implementation=dict(
        glm='Default UE8M0 logical E4+F32 scale pool now in complete NextN state; BF16 raw key and compression-score rings; no F32 pool shadow. Shared real attention builder drives separate target43 MLA/index history, actual43 four-stream output lease feeds44, accepted44 tap feeds NextN. 34 resources plus epoch under one existing StateHead.',
        dspark='Three-stage full draft uses actual encoded128-row main history and real per-stage Q8 wkv/norm; five temporary proposal rows encoded584B then decoded through original reader for attention. Actual original Markov/confidence,11 trained roles192576000B. Prefix0/1/2, reject,wrap,branches,CAS,cancel,collect/old leases checked. Shared cold prepare extracted; caller-owned views explicitly Copy.',
        cuda='Public existing Cast I32 to F32 now supported through native provider, explicit __int2float_rn; old storage operations/enum values/Program layout and floating/Bool conversions preserved; no new buffer. Existing fixture checks13 exact IEEE boundaries, odd strides,replay,input unchanged.'),
    independent_math='Layered GLM BF16/Hadamard/codec and separate state reference. DSpark all3 actual M5 projections use independent Q8 decode and compensated FP64 dot/norm gates; BF16/RoPE/codec boundaries and actual decoded committed/proposal keys checked independently; no assertion of cross-backend bitwise full-network equivalence.',
    repaired_failures=['DSpark test ConstantBinding/auto/vexing-parse compile errors',
                       'Caller output write lease erroneously bound to view result; explicit Copy and ownership gate',
                       'CUDA public I32 to F32 Cast absent, exposed by actual target-capture boundary',
                       '/WX C4456 shadowed cold local; names only changed'],
    remaining=['GLM original roles/shared LM and applicable Pro geometry/confirmed quant supply',
               'DSpark trained target captures/shared LM/remaining original stage suppliers and Pro applicability',
               'Q27/Q24 complete state/original role and confirmed quant combinations',
               'Necessary final ordinary/MTP complete performance comparison before image path'],
    limitations=['GLM target/NextN component weights remain selected generated math, not original complete45-layer model',
                 'DSpark shared LM/embedding/other stage weights and target/verifier boundary remain generated; not trained target/natural acceptance',
                 'Logical codec storage checks do not certify vendor page ABI or peak GPU memory',
                 'No new throughput,load,physical CPU/GPU peak measurements; retain AV latest complete table',
                 'CMake source wiring reviewed but no fresh full configure/build; focused cached TU/link closure used'],
    final_image=read(S / 'tests-link4/ready.json')['image'],
    source_identities=[identity(R / p) for p in sources], archive=identity(archive),
    archive_items=len(paths), no_SDK_or_third_party_rebuild=True,
)
out = DEST / 'mtp-encoded-state-2026-10-23.json'
assert not out.exists()
out.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
(S / 'publication.json').write_text(json.dumps(dict(evidence=identity(out), archive=identity(archive)),
    ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(evidence=identity(out), archive=identity(archive), tests=26,
    graph_attempts=graphs+quant_ok+quant_failed), ensure_ascii=False))
