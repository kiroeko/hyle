import hashlib
import json
import re
import subprocess
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = '5b95fc210cc72abaad5ac303fa4eb2f678497a83'
PRODUCT = '669121418669b31f6849c74f64362aaf8d6eb919'
COMMON = '0a29d119426b2975d48c238c37a2994675e0ba9f'
CARD = 'docs/implementation/tasks/compute/inference-g06-final-closure.md'
OUT = ROOT / 'evidence/correctness/inference-g06-final-qualification'
SCRATCH = ROOT / '.scratch/inference-gaps/g06'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, check=True,
                          capture_output=True, text=True, encoding='utf-8').stdout.strip()


assert git('rev-parse', 'HEAD') == BASE
changed = git('diff', '--name-only', PRODUCT).splitlines()
assert all(p.startswith(('docs/', 'evidence/', 'tests/')) for p in changed), changed
product_delta = git('diff', '--name-only', COMMON, PRODUCT,
                    '--', 'include', 'src', 'cmake', 'CMakeLists.txt').splitlines()
assert product_delta == ['src/graph/lease_submission.cc', 'src/graph/leased_invocation.cc',
                         'src/graph/submission_internal.h'], product_delta

registry = read(ROOT / 'docs/implementation/module-status.json')['modules']
prior = json.loads(git('show', BASE + ':docs/implementation/module-status.json'))['modules']
by_id = {r['module']: r for r in registry}
closed = [r['module'] for r in registry if r.get('record') == CARD]
assert len(closed) == 10
for owner in closed:
    now = by_id[owner]
    old = next(r for r in prior if r['module'] == owner)
    assert old['state'] == 'CANDIDATE' and now['state'] == 'CLOSED'
    assert old['candidate'] == now['candidate'] == (PRODUCT if owner == 'graph' else COMMON)
assert by_id['compute_provider_flashinfer']['state'] == 'CANDIDATE'
assert by_id['compute_provider_flashinfer']['candidate'] == COMMON

paths = {'evidence/' + s for s in re.findall(
    r'\.\./\.\./\.\./\.\./evidence/([^\s)]+\.json)',
    (ROOT / CARD).read_text(encoding='utf-8'))}
paths.discard('evidence/correctness/inference-g06-final-qualification/validation-result.json')
paths.update('evidence/correctness/inference-g06-' + s + '/receipt.json' for s in (
    'final-windows-source', 'graph-page-host-asan', 'graph-page-host-ubsan',
    'graph-page-host-tsan', 'graph-page-cuda-risks', 'final-cuda-risks',
    'final-native-air-source'))
proofs = []
for name in sorted(paths):
    path = ROOT / name
    proof = read(path)
    state = proof.get('state', proof.get('verdict', proof.get('status')))
    assert state and state.startswith('PASS'), (name, state)
    expected = proof.get('raw_sha256', proof.get('raw_zip_sha256'))
    bundle = proof.get('bundle', {})
    expected = expected or bundle.get('sha256')
    assert expected, name
    archive_name = (path.stem + '-raw.zip') if path.stem in ('p0', 'loc') else bundle.get('path', 'raw.zip')
    archive = path.parent / archive_name
    assert sha(archive) == expected, name
    proofs.append({'path': name, 'sha256': sha(path), 'original_verdict': state,
                   'archive': archive.relative_to(ROOT).as_posix(), 'archive_sha256': expected})

plan_path = SCRATCH / 'final-closure-validation-plan.json'
plan = read(plan_path)
assert plan['verdict'] == 'READY'
assert {g['id'] for g in plan['selected_gates']} == {'docs', 'closure'}
checks = []
for name, command, marker in (
    ('write-status', ['python', '-X', 'utf8', 'scripts/check-module-closure.py', '--previous-ref', BASE, '--write-status'], 'updated generated module status:'),
    ('check', ['python', '-X', 'utf8', 'scripts/check-module-closure.py', '--previous-ref', BASE], 'module closure contract passed: 64 components, schema 4'),
    ('docs', ['python', '-X', 'utf8', 'scripts/check-docs.py'], 'documentation contract passed:'),
    ('diff-check', ['git', 'diff', '--check'], ''),
):
    log = SCRATCH / ('final-closure-' + name + '.log')
    data = log.read_bytes()
    output = data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')
    assert marker in output
    checks.append({'command': command, 'exit_code': 0, 'log': log.name,
                   'log_sha256': sha(log), 'output': output.strip()})

raw = OUT / 'raw.zip'
with zipfile.ZipFile(raw, 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(__file__, 'seal_final_qualification.py')
    archive.write(plan_path, 'validation-plan.json')
    for check in checks:
        archive.write(SCRATCH / check['log'], check['log'])

result = {
    'state': 'PASS_G06_FINITE_METADATA_DECODE_ACCEPTANCE',
    'timestamp_utc': datetime.now(timezone.utc).isoformat(),
    'record': CARD, 'previous_registry_ref': BASE, 'product_candidate': PRODUCT,
    'product_unchanged_since_candidate': True,
    'graph_only_product_delta_from_common': product_delta,
    'scope': 'Frozen G06 M/S/L/D only; source and risk facets retain their exact original limitations.',
    'goal': {'state': 'ACTIVE', 'accepted': ['G01', 'G02', 'G03', 'G06'],
             'accepted_count': 4, 'total': 10,
             'remaining': ['G04', 'G05', 'G07', 'G08', 'G09', 'G10']},
    'gates': {g: 'PASS' for g in ('scope', 'architecture', 'correctness', 'delivery',
                                 'usability_docs', 'red_team', 'engineering_performance')},
    'closed_owners': closed,
    'retained_candidate': {'module': 'compute_provider_flashinfer', 'candidate': COMMON,
        'record': by_id['compute_provider_flashinfer']['record'],
        'reason': 'G06 D6/D7 accepted; original G04/G05 CUDA prefill performance remains UNRESOLVED. No P1 retry, budget reset or new product FIX authorized.'},
    'registry_counts': dict(Counter(r['state'] for r in registry)),
    'primary_and_supporting_evidence': proofs,
    'validation': {'selected': ['docs', 'closure'], 'skipped_or_reused': len(plan['skipped_gates']),
                   'checks': checks, 'no_new_build_or_test_run': True},
    'private_sealer_setup_failure': 'Attempt1 verified all 20 receipt/archive hashes, then FileNotFoundError: PowerShell Tee-Object did not create the empty successful git diff --check log. No aggregate was written. Reran only git diff --check with direct output redirection to retain its actual empty output; no product/build/test change.',
    'limits': [
        'Original failures, UNKNOWN costs, sanitizer models and source-input reuse are preserved in linked receipts.',
        'Common Graph mirrors share before first upload; native Apple/Vulkan index banks remain per controller.',
        'Active versions still allocate/copy/refcount; cached full exports lock. Native prepare has a small version-owner allocation.',
        'Apple managed graph and Vulkan re-encoding costs remain; driver/shader/private-pool costs are not certified by host sanitizers.',
        'P0 structural acceptance gives no latency parity or speedup. Original G04/G05 5% time gate and exhausted [15,31] attempt14 remain unresolved.',
        'Outer Graph node-set cubic validation is unchanged baseline cost, separate from G06 grouped page admission.',
        'Complete engine, token/s and multi-GPU/multi-machine remain outside this finite acceptance.'
    ],
    'raw_sha256': sha(raw),
}
(OUT / 'validation-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(f"PASS G06: {len(proofs)} receipt/archive hashes verified; 10 owners closed; FI retained; goal 4/10 ACTIVE")
