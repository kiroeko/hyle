param([switch]$Delete)
$ErrorActionPreference = 'Stop'
# Default is a read-only identity check; -Delete removes only these exact files.
# Superseded images only; current case/test images and all link inputs remain.
$scope = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '.scratch')).TrimEnd('\') + '\'
$targets = @(
  @{ path='.scratch/inference-native-host-image-20261026/vulkan-model-attempt7/link/host-image-vulkan-test.exe'; bytes=69542400; sha256='61883bce7a2317021d81e919523bd89adc8b5a863c754a448e3b16d9356afacb' },
  @{ path='.scratch/inference-stream-padding-20261026/test2/link/padding-focused-test.exe'; bytes=69074432; sha256='9f8a5d98a1e36fbb0b41c66f8aad99e17868b48016f4e5ea7fe7b37ccfb614c4' }
)
foreach ($row in $targets) {
  $resolved = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot $row.path)).ProviderPath
  if (-not $resolved.StartsWith($scope,[StringComparison]::OrdinalIgnoreCase)) { throw 'Target escapes repository scratch' }
  $file = Get-Item -LiteralPath $resolved
  if ($file.PSIsContainer -or $file.Length -ne $row.bytes) { throw 'Target identity mismatch' }
  if ((Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash -ine $row.sha256) { throw 'Target digest changed' }
}
if (-not $Delete) {
  $targets | ForEach-Object { [pscustomobject]$_ } | Format-Table path,bytes
  Write-Output 'Read-only check completed. No files deleted.'
  return
}
$scriptHash = (Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
foreach ($row in $targets) { Remove-Item -LiteralPath (Join-Path $PSScriptRoot $row.path) -Force }
$receipt = [ordered]@{
  status='REMOVED_TWO_EXACT_SUPERSEDED_IMAGES'
  command='& .\test.ps1 -Delete'
  executed_script_sha256=$scriptHash
  logical_bytes=138616832
  targets=$targets
  current_case_present=(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-stream-padding-20261026/case/link/host-image-vulkan-test.exe'))
  current_focused_present=(Test-Path -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-stream-padding-20261026/test3/link/padding-focused-test.exe'))
}
$receipt | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $PSScriptRoot '.scratch/inference-stream-padding-20261026/cleanup-result.json') -Encoding UTF8
$receipt | ConvertTo-Json -Depth 4
