"""One test-only correction: three lane-free graphs use existing submit().

Compile one current graph test TU, relink the focused image, reuse the case image.
Preserve all earlier compiler/linker/run receipts. No model process is launched.
"""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch', W/'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, R = m.b, m.R


def build():
    source = R/'tests/graph/constant_artifact_cache_test.cc'
    pin = b.pin(source)
    assert pin['sha256'] == '61985df3cc82edb30d24145600063d46fd1ab6fe603e4d832559747ea86d6afa'
    old = b.read(W/'plan.json')
    unit = next(x for x in old['units'] if x['name'] == 'graph-test')
    for row in b.read(old['source_freeze']['path']):
        if b.key(row['path']) != b.key(source):
            b.exact(row)
    out = W/'compile2/graph-test'
    command = m.command(Path(unit['recipe']['path']),source,out,test=True)
    b.save(W/'graph-test2-plan.json',dict(reason='Test-only: three no-lane graphs use existing no-argument submit().',
        old_source=unit['source'],new_source=pin,old_run=b.pin(W/'test/run1/process.json'),
        command=command,compiled_TUs=1,product_compiles=0,case_relinks=0))
    helper = b.helper()
    cl = command[0]
    env = helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    process = helper.execute(command,env,out,timeout=180)
    deps = b.read(out/'dependencies.json')['Data']
    actual = [b.pin(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]
    b.save(out/'actual-dependencies.json',actual)
    obj = b.pin(out/'unit.obj')
    image = W/'test3/link/padding-focused-test.exe'
    args, replaced = [],0
    old_obj = W/'compile/graph-test/unit.obj'
    for arg in b.read(W/'test2/link/command.json')['command']:
        if b.key(arg) == b.key(old_obj):
            arg = obj['path']
            replaced += 1
        elif arg.upper().startswith('/OUT:'):
            arg = '/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):
            arg = '/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):
            arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert replaced == 1
    linked = helper.execute(args,env,image.parent,timeout=120)
    inputs = [obj if b.key(x['path']) == b.key(old_obj) else x for x in b.read(W/'test2/link-inputs.json')]
    b.save(W/'test3/link-inputs.json',inputs)
    b.save(W/'test3/runtime.json',b.read(W/'test2/runtime.json'))
    test = dict(status='LINKED_NOT_RUN',image=b.pin(image),inputs=b.pin(W/'test3/link-inputs.json'),
        runtime=b.pin(W/'test3/runtime.json'),link=linked,archive_rewrites=0)
    b.save(W/'test3/ready.json',test)
    ready = b.read(W/'ready.json')
    ready['previous_ready'] = b.pin(W/'ready.json')
    ready['test_only_correction'] = dict(plan=b.pin(W/'graph-test2-plan.json'),compile=process,
        object=obj,actual_dependencies=b.pin(out/'actual-dependencies.json'))
    ready['artifacts']['test'] = test
    b.save(W/'ready2.json',ready)
    print('READY2',json.dumps(b.pin(W/'ready2.json')),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['build']:
        build()
    else:
        print(__doc__)
