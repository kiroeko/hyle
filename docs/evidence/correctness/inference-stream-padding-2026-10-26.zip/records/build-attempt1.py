"""Explicit cached padding batch: plan, build, run. Default performs no action.

Only nine changed product TUs and four focused test TUs; no SDK/archive build.
Run is one focused GTest process and the unchanged tiny Vulkan ordinary/MTP and
lag-1 consumers. No original335, performance window, download, or automatic retry.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
H = R/'.scratch/inference-native-host-image-20261026'
V = H/'vulkan-model-attempt7'
G = R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1'
spec = importlib.util.spec_from_file_location('cached', R/'.scratch/inference-causal-conv-20261026/build.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
b = c.b
MODEL_RECIPE = H/'vulkan-model-attempt3/compile/model/command.json'
GTEST_INCLUDE = Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
TESTS = [('file-stream-test', 'tests/compute_stream/file_stream_test.cc'),
    ('tensor-test', 'tests/compute/tensor_test.cc'),
    ('graph-test', 'tests/graph/constant_artifact_cache_test.cc'),
    ('vulkan-test', 'tests/compute_route_vulkan/copy_recording_test.cc')]


def command(recipe, source, out, test=False):
    original = b.read(recipe)['command']
    old_source = next(x for x in original if x.lower().endswith('.cc'))
    result, skip = [], False
    for arg in original:
        if skip:
            skip = False
            continue
        if arg.lower() == '/sourcedependencies':
            skip = True
            continue
        if arg.lower().startswith(('/fo', '/fd')):
            continue
        result.append(str(source) if arg == old_source else arg)
    if test:
        result += ['/external:I'+str(GTEST_INCLUDE), '/I'+str(R/'src/compute'),
            '/I'+str(R/'src/graph'), '/I'+str(R/'src/compute_route_vulkan')]
    result += ['/sourceDependencies', str(out/'dependencies.json'),
        '/Fo'+str(out/'unit.obj'), '/Fd'+str(out/'unit.pdb')]
    assert '/W4' in result and '/WX' in result and '/O2' in result
    return result


def plan():
    assert not (W/'plan.json').exists(), 'Preserve the frozen attempt'
    tensor_origin = R/'.scratch/glm-mlx-flash-original-20261024/gdn-output-scale-validation/recipe-preparation/host-commands.json'
    tensor = next(x for x in b.read(tensor_origin)['jobs'] if x['name'] == 'compute--tensor_view')
    tensor_recipe = W/'retained-recipes/tensor-view.json'
    b.save(tensor_recipe, dict(command=tensor['command'], origin=b.pin(tensor_origin), selected_job=tensor['name']))
    units = [
        ('model', 'tests/tools/qwen_host_image_test.cc', MODEL_RECIPE,
            H/'vulkan-model-attempt3/compile/model/unit.obj'),
        ('weights', 'engine/models/qwen35/weights.cc', H/'vulkan-model-attempt3/compile/weights/command.json',
            H/'vulkan-model-attempt3/compile/weights/unit.obj'),
        ('file-stream', 'src/compute_stream/file_stream.cc', R/'.scratch/qwen-vulkan-k1-20261024/build1/stream-core-file_stream/command.json',
            R/'.scratch/qwen-vulkan-k1-20261024/build1/stream-core-file_stream/unit.obj'),
        ('tensor-view', 'src/compute/tensor_view.cc', tensor_recipe, None),
        ('graph-executable', 'src/graph/executable.cc', G/'records/graph--executable/run/command.json', None),
        ('graph-submission', 'src/graph/submission.cc', G/'records/graph--submission/run/command.json', G/'graph--submission.obj'),
        ('graph-resources', 'src/graph/resources.cc', R/'.scratch/inference-result-publication-screen-20261026/candidate/compile/command.json',
            H/'current-graph-resources/compile/unit.obj'),
        ('native-transform', 'src/compute_provider_native/transform.cc', G/'records/compute_provider_native--transform/run/command.json', G/'compute_provider_native--transform.obj'),
        ('vulkan-memory', 'src/compute_route_vulkan/vulkan_memory.cc', R/'.scratch/qwen-cpu-vulkan-20261024/memory-current1/command.json',
            R/'.scratch/qwen-cpu-vulkan-20261024/memory-current1/unit.obj')]
    units += [(name, source, MODEL_RECIPE, None) for name,source in TESTS]
    jobs = [dict(name=name, source=b.pin(R/source), recipe=b.pin(recipe),
        replaces=b.pin(old) if old else None, kind='test' if name.endswith('-test') else 'product',
        command=command(recipe, R/source, W/'compile'/name, name.endswith('-test')))
        for name,source,recipe,old in units]
    # Include dirs added only for current canonical test private headers.
    closure_recipe = W/'retained-recipes/test.json'
    b.save(closure_recipe, dict(command=jobs[-1]['command']))
    frozen = c.closure([j['source']['path'] for j in jobs], [*[recipe for _,_,recipe,_ in units], closure_recipe])
    b.save(W/'source-freeze.json', frozen)
    inputs = b.read(V/'link-inputs.json')
    assert len(inputs) == 132 and len({b.key(x['path']) for x in inputs}) == 132
    for row in inputs:
        b.exact(row)
    for job in jobs:
        if job['replaces']:
            assert sum(b.key(x['path']) == b.key(job['replaces']['path']) for x in inputs) == 1
    gtest = [b.pin(R/'.scratch/build-compute-v2-dev/lib'/name) for name in ('gtest_main.lib','gtest.lib')]
    report = next(x for x in inputs if b.key(x['path']).endswith('inference-review-fixes-20261026\\product2\\report\\unit.obj'))
    b.save(W/'plan.json', dict(status='FROZEN_NOT_BUILT', baseline_commit='33d488abe',
        baseline=dict(image=b.pin(V/'link/host-image-vulkan-test.exe'), ready=b.pin(V/'ready.json'),
            inputs=b.pin(V/'link-inputs.json'), link_recipe=b.pin(V/'link/command.json'), runtime=b.pin(V/'runtime.json')),
        units=jobs, source_freeze=b.pin(W/'source-freeze.json'), gtest_libraries=gtest,
        gtest_header=b.pin(GTEST_INCLUDE/'gtest/gtest.h'), neutral_report=report,
        exact_direct_replacements=7, appended_archive_overrides=['tensor-view','graph-executable'],
        product_TUs=9, test_TUs=4, archive_rewrites=0,
        limitations=['Cached native/vendor binaries remain unchanged.',
            'No original335 rerun, CPU consumer, performance window, or full build is planned.']))
    print('PLAN', json.dumps(b.pin(W/'plan.json')), flush=True)


def build():
    p = b.read(W/'plan.json')
    assert not (W/'compile').exists() and not (W/'ready.json').exists()
    b.exact(p['source_freeze'])
    frozen = b.read(p['source_freeze']['path'])
    for row in frozen:
        b.exact(row)
    for row in p['baseline'].values():
        b.exact(row)
    inputs = b.read(p['baseline']['inputs']['path'])
    for row in [*inputs, *p['gtest_libraries'], p['gtest_header']]:
        b.exact(row)
    helper = b.helper()
    cl = p['units'][0]['command'][0]
    env = helper.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl, 'CMAKE_GENERATOR':'Ninja'}, backends=()).env
    own = {b.key(row['path']):row for row in frozen}
    objects, results = {}, []
    for unit in p['units']:
        b.exact(unit['source'])
        b.exact(unit['recipe'])
        out = W/'compile'/unit['name']
        process = helper.execute(unit['command'], env, out, timeout=180)
        dep = b.read(out/'dependencies.json')['Data']
        actual = [b.pin(path) for path in dict.fromkeys([dep['Source'], *dep['Includes']])]
        for row in actual:
            path = Path(row['path'])
            if path.is_relative_to(R) and not path.is_relative_to(R/'.scratch'):
                assert b.key(path) in own and own[b.key(path)]['sha256'] == row['sha256'], str(path)
        b.save(out/'actual-dependencies.json', actual)
        objects[unit['name']] = b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'], source=unit['source'], object=objects[unit['name']],
            process=process, dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:
            b.exact(row)
    replacement = {b.key(u['replaces']['path']):objects[u['name']] for u in p['units'] if u['replaces']}
    override = [objects[name] for name in p['appended_archive_overrides']]
    artifacts = {}
    for name in ('test','case'):
        removed = [p['neutral_report'], *[u['replaces'] for u in p['units'] if u['name'] in ('model','weights')]] if name == 'test' else []
        removed_keys = {b.key(x['path']) for x in removed}
        added = override + ([objects[n] for n,_ in TESTS] + p['gtest_libraries'] if name == 'test' else [])
        image = W/name/'link'/('padding-focused-test.exe' if name == 'test' else 'host-image-vulkan-test.exe')
        args, replaced, discarded = [], 0, 0
        for arg in b.read(p['baseline']['link_recipe']['path'])['command']:
            if b.key(arg) in removed_keys:
                discarded += 1
                continue
            if b.key(arg) in replacement:
                arg = replacement[b.key(arg)]['path']
                replaced += 1
            elif arg.upper().startswith('/OUT:'):
                arg = '/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'):
                arg = '/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'):
                arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
            args.append(arg)
        args.extend(x['path'] for x in added)
        assert replaced == (5 if name == 'test' else 7) and discarded == len(removed)
        process = helper.execute(args, env, image.parent, timeout=120)
        final = [replacement.get(b.key(x['path']),x) for x in inputs if b.key(x['path']) not in removed_keys]+added
        assert len(final) == (137 if name == 'test' else 134)
        b.save(W/name/'link-inputs.json', final)
        runtime = b.read(p['baseline']['runtime']['path'])
        b.save(W/name/'runtime.json', runtime)
        ready = dict(status='LINKED_NOT_RUN', image=b.pin(image), inputs=b.pin(W/name/'link-inputs.json'),
            runtime=b.pin(W/name/'runtime.json'), link=process, archive_rewrites=0)
        b.save(W/name/'ready.json', ready)
        artifacts[name] = ready
    b.save(W/'ready.json', dict(status='BUILT_NOT_RUN', plan=b.pin(W/'plan.json'),
        source_freeze=p['source_freeze'], compiled=results, artifacts=artifacts, native_consumers=0))
    print('READY', json.dumps(b.pin(W/'ready.json')), flush=True)


def run():
    ready = b.read(W/'ready.json')
    helper = b.helper()
    env = os.environ.copy()
    env['PATH'] = b.read(ready['artifacts']['test']['runtime']['path'])['PATH']
    tests = ready['artifacts']['test']['image']
    b.exact(tests)
    selection = 'TensorDesc.*:StorageFormat.*:TensorView.*:FileStream.*:CanonicalConstantCache.*:ConstantArtifactCache.*:StorageOwner.*:VulkanCopyRecording.*'
    gtest = helper.execute([tests['path'], '--gtest_filter='+selection], env, W/'test/run1', timeout=120)
    case = ready['artifacts']['case']['image']
    b.exact(case)
    fixture = R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    manifest = fixture/'weights.tsv'
    b.save(W/'case/fixture.json', dict(manifest=b.pin(manifest), unchanged=True,
        description='Existing untrained GA/H64 fixture; byte/lifetime check, not quality oracle.'))
    runs = []
    for name,tail in (('run-tiny',[]),('run-lagged',['--mtp-lag1'])):
        runs.append(dict(name=name, process=helper.execute([case['path'],'--vulkan',str(fixture),*tail],env,W/'case'/name,timeout=60)))
    b.save(W/'run-summary.json', dict(status='FINITE_RUNS_EXIT_ZERO', gtest=gtest,
        case=runs, original335='NOT_RERUN', cpu='NOT_RUN', performance='NOT_MEASURED'))
    print('RUN_SUMMARY', json.dumps(b.pin(W/'run-summary.json')), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['plan']:
        plan()
    elif sys.argv[1:] == ['build']:
        build()
    elif sys.argv[1:] == ['run']:
        run()
    else:
        print(__doc__)
