"""One cause-backed relink only. Preserve the first duplicate-definition failure.

All thirteen compiled objects are reused; no compiler or model is launched.
"""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch', W/'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, R = m.b, m.R


def relink():
    p = b.read(W/'plan.json')
    assert not (W/'ready.json').exists()
    for row in b.read(p['source_freeze']['path']):
        b.exact(row)
    inputs = b.read(p['baseline']['inputs']['path'])
    shadow = R/'.scratch/q27-cold-search-20261024/fixed1/graph/graph.obj'
    assert sum(b.key(x['path']) == b.key(shadow) for x in inputs) == 1
    correction = dict(reason='Actual Vk7 direct graph.obj is the full old executable TU, not an archive member.',
        failed_link=b.pin(W/'test/link/process.json'), failed_command=b.pin(W/'test/link/command.json'),
        old=b.pin(shadow), old_dependency_record=b.pin(shadow.parent/'dependencies.json'),
        old_shadow_source=b.pin(shadow.parent/'executable.cc'),
        new=b.pin(W/'compile/graph-executable/unit.obj'), product_source=b.pin(R/'src/graph/executable.cc'),
        compile_repeats=0, duplicate_symbol_ignores=0, archive_rewrites=0)
    b.save(W/'link-correction.json', correction)
    objects, compiled = {}, []
    for u in p['units']:
        out = W/'compile'/u['name']
        process = b.read(out/'process.json')
        assert process['exit'] == 0
        actual = b.read(out/'actual-dependencies.json')
        for row in actual:
            b.exact(row)
        objects[u['name']] = b.pin(out/'unit.obj')
        compiled.append(dict(name=u['name'], source=u['source'], object=objects[u['name']],
            process=process, dependencies=b.pin(out/'actual-dependencies.json')))
    replacements = {b.key(u['replaces']['path']):objects[u['name']] for u in p['units'] if u['replaces']}
    replacements[b.key(shadow)] = objects['graph-executable']
    helper = b.helper()
    cl = p['units'][0]['command'][0]
    env = helper.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,
        'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
    artifacts = {}
    for name,folder in (('test','test2'),('case','case')):
        removed = [p['neutral_report'], *[u['replaces'] for u in p['units'] if u['name'] in ('model','weights')]] if name == 'test' else []
        removed_keys = {b.key(x['path']) for x in removed}
        added = [objects['tensor-view']] + ([objects[n] for n,_ in m.TESTS]+p['gtest_libraries'] if name == 'test' else [])
        image = W/folder/'link'/('padding-focused-test.exe' if name == 'test' else 'host-image-vulkan-test.exe')
        args, replaced, discarded = [],0,0
        for arg in b.read(p['baseline']['link_recipe']['path'])['command']:
            if b.key(arg) in removed_keys:
                discarded += 1
                continue
            if b.key(arg) in replacements:
                arg = replacements[b.key(arg)]['path']
                replaced += 1
            elif arg.upper().startswith('/OUT:'):
                arg = '/OUT:'+str(image)
            elif arg.upper().startswith('/PDB:'):
                arg = '/PDB:'+str(image.with_suffix('.pdb'))
            elif arg.upper().startswith('/IMPLIB:'):
                arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
            args.append(arg)
        args.extend(x['path'] for x in added)
        assert replaced == (6 if name == 'test' else 8) and discarded == len(removed)
        result = helper.execute(args,env,image.parent,timeout=120)
        final = [replacements.get(b.key(x['path']),x) for x in inputs if b.key(x['path']) not in removed_keys]+added
        assert len(final) == (136 if name == 'test' else 133)
        b.save(W/folder/'link-inputs.json',final)
        b.save(W/folder/'runtime.json',b.read(p['baseline']['runtime']['path']))
        artifact = dict(status='LINKED_NOT_RUN', image=b.pin(image),inputs=b.pin(W/folder/'link-inputs.json'),
            runtime=b.pin(W/folder/'runtime.json'),link=result,archive_rewrites=0)
        b.save(W/folder/'ready.json',artifact)
        artifacts[name] = artifact
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',plan=b.pin(W/'plan.json'),
        link_correction=b.pin(W/'link-correction.json'),source_freeze=p['source_freeze'],
        compiled=compiled,artifacts=artifacts,native_consumers=0))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['relink']:
        relink()
    else:
        print(__doc__)
