from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

work = Path(__file__).resolve().parent
repo = work.parents[1]
evidence = repo / 'docs/evidence/correctness/inference-stream-padding-2026-10-26.json'
archive = evidence.with_suffix('.zip')

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def pin(path):
    path = Path(path)
    return {'path': str(path.relative_to(repo)).replace('\\', '/'),
            'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

summary = read(work / 'final-summary.json')
assert summary['status'] == 'FINITE_SCOPE_PASSED_WITH_PRESERVED_FAILURES'
assert summary['focused_tests']['final_pass'] == 56
assert summary['focused_tests']['final_fail'] == 0
for name in ['focused_final', 'vulkan_ordinary_and_mtp', 'vulkan_lag1', 'cpu_lag1_final']:
    assert summary['runs'][name]['process']['exit'] == 0
    for kind in ['command', 'stdout', 'stderr']:
        record = summary['runs'][name][kind]
        assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256']
for record in read(work / 'final-source-freeze.json'):
    assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256'], record['path']
cleanup = read(work / 'cleanup-result.json')
for record in cleanup['targets']:
    assert not (repo / record['path']).exists()
assert cleanup['current_case_present'] and cleanup['current_focused_present']
subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
patch = subprocess.run(['git', 'diff', '--binary', '--', 'engine', 'include', 'src', 'tests'],
                       cwd=repo, check=True, stdout=subprocess.PIPE).stdout
(work / 'product.patch').write_bytes(patch)
suffixes = {'.json', '.log', '.py', '.patch'}
files = sorted(p for p in work.rglob('*') if p.is_file() and p.suffix in suffixes)
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for path in files:
        out.write(path, 'records/' + str(path.relative_to(work)).replace('\\', '/'))
    out.write(repo / 'test.ps1', 'records/test.ps1')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
document = {
    'status': summary['status'],
    'date': '2026-10-26',
    'source_base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'source_patch': 'records/product.patch',
    'purpose': 'Load non-four-byte original weight ranges through existing F3 padding and preserve only explicitly ready readonly storage through Tensor/Graph/Vulkan.',
    'contract': [
        'L remains the original file bytes and TensorDesc extent. Streamed carriers reserve checked P=ceil(L/4)*4 on every route; actual stream backing budgets use P.',
        'F3 reads L only and initializes the tail. output() remains L; initialized_storage() exposes exactly P and shares the original retirement lifetime.',
        'Existing ConstTensorView::create still clips L. Additive from_initialized_storage preserves the supplied initialized span without a member/layout change.',
        'Readonly Graph bindings and immutable aliases retain the declared ready span only. CPU/common mathematical copies use L; writable tensor views are not enlarged.',
        'Vulkan lease binding proves four-byte carrier capacity inside the original ReadLease span, never by assuming the rest of an allocation is initialized.'
    ],
    'fixture_inventory': read(work / 'fixture-inventory.json'),
    'build_and_runs': summary,
    'preserved_failures': [
        'First link used both the old direct shadow graph.obj and the new complete executable TU; exact direct replacement fixed it without suppressing duplicate definitions.',
        'Three new zero-lane tests initially used submit(queue). Tests now use the existing submit() overload; product submit policy was unchanged.',
        'CPU first run lacked its already cached variant DLL beside the executable. The same DLL was hardlinked to the app directory required by LoadLibraryEx; no source change, SDK copy or rebuild.'
    ],
    'cleanup': cleanup,
    'limits': [
        'The tiny GA/H64 fixture is unchanged and untrained. These are finite byte, continuation, snapshot, RNG and retirement checks; no task-quality or natural-MTP-acceptance claim.',
        'The full335 source has P=L and was not rerun in this batch. New Apple/CUDA odd-range consumers and device-failure injection were not run.',
        'No new throughput, peak-memory or load-speed comparison; no model download or SDK rebuild.'
    ],
    'archive': {**pin(archive), 'entries': len(files) + 1}
}
evidence.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'evidence': pin(evidence), 'archive': document['archive']}, ensure_ascii=False))
