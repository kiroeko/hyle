"""One CPU lag-1 rerun after adding the exact existing DLL app-dir hardlink.

The cached cpu_program OBJ's fixed DLL name uses LOAD_LIBRARY_SEARCH_DEFAULT_DIRS,
so PATH alone is insufficient. No build, SDK copy, source change, or model change.
"""
from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
sys.stdout.reconfigure(encoding='utf-8')
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch',W/'build.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, R = m.b, m.R


def run():
    ready = b.read(W/'ready2.json')
    image = ready['artifacts']['case']['image']
    b.exact(image)
    name = 'hyle_ggml_cpu_gdn_scale_v3.dll'
    obj = next(x for x in b.read(W/'case/link-inputs.json') if x['path'].endswith('compute_ggml_runtime--cpu_program.obj'))
    assert name.encode() in Path(obj['path']).read_bytes()
    native = b.pin(R/'.scratch/qwen-cpu-vulkan-20261024/smoke-attempt6'/name)
    prior = b.read(R/'.scratch/inference-host-image-20261026/cpu3/runtime.json')
    assert native['sha256'] == prior['native']['sha256'] == '6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f'
    alias = Path(image['path']).parent/name
    assert not alias.exists()
    os.link(native['path'],alias)
    runtime = b.read(ready['artifacts']['case']['runtime']['path'])
    runtime['native'] = native
    runtime['native_hardlink'] = b.pin(alias)
    b.save(W/'case/cpu-runtime2.json',runtime)
    b.save(W/'cpu-runtime-correction.json',dict(reason='LoadLibraryExA LOAD_LIBRARY_SEARCH_DEFAULT_DIRS searches app directory, not PATH.',
        prior_failure=b.pin(W/'case/run-cpu-lagged/process.json'),cached_cpu_program=obj,
        fixed_module_name=name,existing_cpu_success_runtime=b.pin(R/'.scratch/inference-host-image-20261026/cpu3/runtime.json'),
        existing_native=native,app_directory_hardlink=b.pin(alias),source_change=False,builds=0,sdk_copies=0))
    env = os.environ.copy()
    env['PATH'] = runtime['PATH']
    fixture = R/'.scratch/mtp-state-ports-20261024/gdn-regression/shared-fixture'
    process = b.helper().execute([image['path'],'--cpu',str(fixture),'--mtp-lag1'],env,W/'case/run-cpu-lagged2',timeout=60)
    b.save(W/'cpu-runtime2-result.json',dict(process=process,image=image,runtime=b.pin(W/'case/cpu-runtime2.json'),
        correction=b.pin(W/'cpu-runtime-correction.json')))
    print('CPU_LAG1_RESULT',json.dumps(process),flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['run']:
        run()
    else:
        print(__doc__)
