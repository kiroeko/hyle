"""Read completed same-B runs and selected baseline ZIP entries, without extraction."""
from pathlib import Path
from contextlib import ExitStack
import hashlib
import json
import zipfile

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
S = ROOT / ".scratch/qwen-mtp-weights-20261022"
MANIFEST = ROOT / "docs/evidence/performance/qwen-cli-batch-2026-10-22.json"


def parse(data):
    def pairs(items):
        result = {}
        for key, value in items:
            assert key not in result, f"duplicate JSON key: {key}"
            result[key] = value
        return result
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=pairs)


def read(path):
    return parse(path.read_bytes())


def cli(arguments):
    result = []
    index = 1
    while index < len(arguments):
        if arguments[index] == "--trace":
            index += 2
        else:
            result.append(arguments[index])
            index += 1
    return result


def session_signature(value):
    fields = ["session_id", "visible_tokens", "generated_ids", "decode_input_ids",
              "processed_tokens", "generated_tokens", "graph_participations", "graph_input_tokens"]
    phases = ["turn", "kind", "name", "input_tokens", "calls", "generated_tokens", "context_before", "context_after"]
    return {**{k: value[k] for k in fields if k in value},
            "phases": [{k: p[k] for k in phases} for p in value["phases"]]}


def execution_signature(value):
    fields = ["session_count", "processed_tokens", "generated_tokens", "graph_participations",
              "actual_graph_calls", "actual_graph_tokens", "max_batch_requests", "prefix_hits",
              "prefix_misses", "prefix_full_hits", "reused_tokens", "logical_dispatch_session_ids"]
    return {**{k: value[k] for k in fields if k in value},
            "batches": [{k: b[k] for k in ["kind", "restore", "query_rows", "requests", "session_ids"]}
                        for b in value["batches"]],
            "waves": [{k: w[k] for k in ["kind", "outputs", "logical_tokens", "actual_tokens", "graph_calls"]}
                      for w in value["waves"]],
            "sessions": [session_signature(s) for s in value.get("sessions", [value])]}


def ledger(value):
    batches = value["batches"]
    assert len(batches) == value["actual_graph_calls"]
    assert sum(b["requests"] for b in batches) == value["graph_participations"]
    assert sum(b["requests"] * b["query_rows"] for b in batches) == value["actual_graph_tokens"]
    assert sum(w["graph_calls"] for w in value["waves"]) == value["actual_graph_calls"]
    assert sum(w["actual_tokens"] for w in value["waves"]) == value["actual_graph_tokens"]
    assert sum(w["outputs"] for w in value["waves"]) == value["generated_tokens"]
    assert sum(s["graph_participations"] for s in value.get("sessions", [value])) == value["graph_participations"]
    return {k: value[k] for k in ["actual_graph_calls", "actual_graph_tokens", "graph_participations",
                                 "max_batch_requests", "processed_tokens", "generated_tokens"]}


def main():
    manifest = read(MANIFEST)
    current_ready = read(S / "qwen-ready-attempt1.json")
    entries = {item["entry"]: item for item in manifest["archive_files"]}
    with ExitStack() as stack:
        archives = [stack.enter_context(zipfile.ZipFile(item["path"])) for item in manifest["archives"]]
        locations = {}
        wanted = [".scratch/qwen-cli-batch-20261022/r1-run1/", ".scratch/qwen-cli-batch-20261022/batch-run2/"]
        for archive in archives:
            for name in archive.namelist():
                if any(name.startswith(prefix) for prefix in wanted):
                    assert name not in locations
                    locations[name] = archive
        checked_entries = set()

        def archived(name):
            data = locations[name].read(name)  # ZipFile validates the selected member's CRC.
            expected = entries[name]
            assert len(data) == expected["bytes"] and hashlib.sha256(data).hexdigest() == expected["sha256"]
            checked_entries.add(name)
            return data

        runs = []
        for after, before, count in [("r1-run1", "r1-run1", 18), ("batch-run1", "batch-run2", 72)]:
            prefix = ".scratch/qwen-cli-batch-20261022/" + before + "/"
            terminal = read(S / after / "run.result.json")
            prior_terminal = parse(archived(prefix + "result.json"))
            assert terminal["exit"] == prior_terminal["exit"] == 0 and terminal["terminal"] is True
            assert cli(terminal["command"]) == cli(prior_terminal["command"])
            current, previous = read(S / after / "run.stdout.log"), parse(archived(prefix + "stdout.log"))
            assert execution_signature(current) == execution_signature(previous)
            current_ledger = ledger(current)
            assert current_ledger == ledger(previous)
            trace = S / after / "trace"
            relative = sorted(p.relative_to(trace).as_posix() for p in trace.rglob("*")
                              if p.suffix in [".bf16", ".f32"])
            archived_relative = sorted(name[len(prefix + "trace/"):] for name in locations
                                      if name.startswith(prefix + "trace/") and name.endswith((".bf16", ".f32")))
            assert relative == archived_relative and len(relative) == count
            totals = {"BF16": {"files": 0, "elements": 0}, "F32": {"files": 0, "elements": 0}}
            for name in relative:
                expected = archived(prefix + "trace/" + name)
                actual = (trace / name).read_bytes()
                assert actual == expected, (after, name)
                bf16 = name.endswith(".bf16")
                codes = np.frombuffer(actual, dtype="<u2" if bf16 else "<u4")
                mask = 0x7F80 if bf16 else 0x7F800000
                assert not bool(np.any((codes & mask) == mask)), (after, name, "nonfinite")
                total = totals["BF16" if bf16 else "F32"]
                total["files"] += 1
                total["elements"] += int(codes.size)
            plan = read(S / after / "identity.json")
            assert plan["image"] == current_ready["image"]
            assert terminal["command"][0] == plan["image"]["path"]
            runs.append({"current": str((S / after).relative_to(ROOT)), "baseline_ZIP_prefix": prefix,
                         "terminal_exits": [0, 0], "same_input_and_configuration_except_image_trace_path": True,
                         "current_image": plan["image"], "baseline_image": prior_terminal["image"],
                         "vectors": {"files": count, "all_byte_exact": True, "all_finite": True, "types": totals},
                         "all_ids_contexts_and_execution_shape_ledgers_equal": True, "ledger": current_ledger})
        result = {"status": "PASS same-B before/after MTP weight opt-in, ordinary text finite model regression",
                  "current_ready": str((S / "qwen-ready-attempt1.json").relative_to(ROOT)),
                  "baseline_manifest": str(MANIFEST.relative_to(ROOT)),
                  "archives": manifest["archives"], "selected_ZIP_entries_SHA256_verified": len(checked_entries),
                  "runs": runs, "total_vector_pairs": 90,
                  "scope": ["Exactly R1-to-R1 (18) and B2 CLI-to-B2 CLI (72); no comparison between different B values.",
                            "Selected original archive bytes were checked against the published per-entry SHA256 and CRC. No complete archive was extracted or re-hashed.",
                            "Finite BF16/F32 follows raw exponent bits. Byte equality therefore proves both copies finite for these vectors.",
                            "JSON signatures preserve every generated/consumed ID, per-Session phase/context, Graph count/participation/token ledger and batch/wave grouping. Timing/capture latency is deliberately excluded.",
                            "This is a finite same-image-input regression, not broad quality, arbitrary-model support or a throughput result."],
                  "activity": {"native_processes": 0, "GPU_runs": 0, "builds": 0, "product_edits": 0,
                               "archives_extracted": 0}}
    output = S / "review/topone-model-regression.json"
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"report": str(output.relative_to(ROOT)), "vector_pairs": 90,
                      "verified_ZIP_entries": len(checked_entries), "ledgers": [r["ledger"] for r in runs]}, indent=2))


if __name__ == "__main__":
    main()
