from pathlib import Path
import ast
import copy
import hashlib
import json
import re
import runpy
import struct

ROOT = Path(__file__).resolve().parents[2]
STAGE = Path(__file__).resolve().parent
PREPARE = ROOT / "tools/qwen35_text/prepare.py"
CHECKPOINT = Path(r"C:\Users\kiro\Downloads\Qwen3.5-2B\model.safetensors-00001-of-00001.safetensors")


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def manifest(selected, signature, source_id):
    lines = [signature, CHECKPOINT.as_posix(), source_id]
    for name, dtype, shape, offset, count in selected:
        lines.append("\t".join(map(str, (name, dtype, len(shape), *shape, offset, count))))
    return ("\n".join(lines) + "\n").encode()


def main():
    # No tokenizer, model execution or full payload/hash read.
    compile(PREPARE.read_text(encoding="utf-8-sig"), str(PREPARE), "exec")
    namespace = runpy.run_path(str(PREPARE))
    choose = namespace["select_weights"]
    with CHECKPOINT.open("rb") as stream:
        raw_length = stream.read(8)
        length = struct.unpack("<Q", raw_length)[0]
        raw_header = stream.read(length)
    assert len(raw_header) == length
    header = json.loads(raw_header)
    size = CHECKPOINT.stat().st_size
    assert length == 76648 and size == 4548221488
    assert hashlib.sha256(raw_header).hexdigest() == "ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d"
    text = choose(header, length, size)
    combined = choose(header, length, size, True)

    # Execute the original selection AST, without old main's identity hash/tokenizer.
    old = STAGE / "before/tools/qwen35_text/prepare.py"
    old_tree = ast.parse(old.read_text(encoding="utf-8-sig"))
    old_main = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")
    start = next(i for i,n in enumerate(old_main.body)
                 if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "selected" for t in n.targets))
    body = old_main.body[start:start+3]
    assert isinstance(body[1], ast.For) and isinstance(body[2], ast.If)
    old_scope = dict(header=header, length=length, shard=CHECKPOINT)
    exec(compile(ast.Module(body=body, type_ignores=[]), str(old), "exec"), old_scope)
    assert text == old_scope["selected"]
    source = json.loads((ROOT / "docs/implementation/tasks/compute/qwen35-2b-local-input.json").read_text())["artifact_identity_sha256"]
    assert manifest(text, "HYLE_QWEN35_TEXT_V1", source) == manifest(old_scope["selected"], "HYLE_QWEN35_TEXT_V1", source)
    mtp = [v for v in combined if v[0].startswith("mtp.")]
    assert len(text) == 320 and sum(v[4] for v in text) == 3763655360
    assert len(combined) == 335 and sum(v[4] for v in combined) == 3885311680
    assert len(mtp) == 15 and sum(v[4] for v in mtp) == 121656320
    assert [v for v in combined if not v[0].startswith("mtp.")] == text
    audit = json.loads((ROOT / "docs/evidence/research/qwen35-mtp-next-2026-10-22.json").read_text())
    expected = [(t["name"], t["dtype"], t["shape"], t["absolute_file_offset"], t["bytes"])
                for t in audit["local_inventory"]["selected_tensors"]]
    assert mtp == expected

    cpp = (ROOT / "tools/qwen35_text/main.cc").read_text(encoding="utf-8-sig")
    table = {name: ((int(rows), int(cols)) if int(cols) else (int(rows),))
             for name, rows, cols in re.findall(r'MtpShape\{"([^"]+)", (\d+), (\d+)\}', cpp)}
    assert table == namespace["MTP_SHAPES"]
    rejects = []
    cases = {}
    bad = copy.deepcopy(header); del bad["mtp.fc.weight"]; cases["missing_mtp"] = bad
    bad = copy.deepcopy(header); bad["mtp.unknown.weight"] = bad.pop("mtp.fc.weight"); cases["unknown_mtp"] = bad
    bad = copy.deepcopy(header); bad["mtp.fc.weight"]["shape"] = [4096,2048]; cases["same_bytes_wrong_shape"] = bad
    bad = copy.deepcopy(header); bad["mtp.fc.weight"]["dtype"] = "F32"; cases["wrong_mtp_dtype"] = bad
    bad = copy.deepcopy(header); bad["mtp.norm.weight"]["data_offsets"][1] = size; cases["out_of_file_mtp"] = bad
    for label, bad in cases.items():
        try: choose(bad, length, size, True)
        except ValueError as error: rejects.append(dict(case=label,error=str(error)))
        else: raise AssertionError(label + " did not reject")
    # Default text selection does not silently add or depend on MTP metadata.
    assert choose(cases["missing_mtp"], length, size) == text
    assert choose(cases["same_bytes_wrong_shape"], length, size) == text
    inputs = STAGE / "inputs"; inputs.mkdir(exist_ok=True)
    mtp_manifest = inputs / "weights-mtp.tsv"
    mtp_manifest.write_bytes(manifest(combined, "HYLE_QWEN35_TEXT_MTP_V1", source))
    text_manifest = inputs / "weights-text.tsv"
    text_manifest.write_bytes(manifest(text, "HYLE_QWEN35_TEXT_V1", source))
    result = dict(status="PASS", kind="host_metadata_check_no_payload_or_execution",
                  prepare=identity(PREPARE), script=identity(Path(__file__)),
                  metadata_read_bytes=8+length, header_sha256=hashlib.sha256(raw_header).hexdigest(),
                  default_selection_and_manifest_equal_original=True,
                  text=dict(tensors=len(text),bytes=sum(v[4] for v in text),manifest=identity(text_manifest)),
                  text_plus_mtp=dict(tensors=len(combined),bytes=sum(v[4] for v in combined),manifest=identity(mtp_manifest)),
                  mtp=dict(tensors=len(mtp),bytes=sum(v[4] for v in mtp),audit_exact=True,cpp_python_shape_tables_equal=True),
                  rejection_cases=rejects,
                  not_executed=["prepare.py main/full original-file digest/tokenizer", "C++ compilation/loader", "GPU", "MTP inference"])
    (STAGE / "metadata-check.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(dict(status=result["status"],text=result["text"]["tensors"],combined=result["text_plus_mtp"]["tensors"],
                          rejects=len(rejects),report=identity(STAGE / "metadata-check.json"))))


if __name__ == "__main__":
    main()
