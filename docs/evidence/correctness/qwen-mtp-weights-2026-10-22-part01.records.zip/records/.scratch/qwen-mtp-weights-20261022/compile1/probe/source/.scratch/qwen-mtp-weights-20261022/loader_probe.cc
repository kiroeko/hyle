// Actual original MTP payload/load verification, no MTP model execution.
#define main hyle_qwen35_text_consumer_main
#include "../../tools/qwen35_text/main.cc"
#undef main

int main(int argc, char **argv) {
  namespace q = qwen35;
  try {
    if (argc != 2) throw std::runtime_error("usage: loader_probe MTP_weights.tsv");
    auto context = q::take(q::g::cuda::create_context());
    auto memory = q::take(q::c::StorageOwner::adopt(context,
        q::take(q::c::cuda::MemoryResource::create(context, q::c::cuda::MemoryKind::kDevice))));
    auto staging = q::take(q::c::cuda::MemoryResource::create(context, q::c::cuda::MemoryKind::kPinnedHost));
    auto queue = q::take(context.create_queue());
    std::vector<q::c::LeasePool> pools;
    std::map<std::string, q::Tensor> bank;
    bool default_rejected = false;
    try { (void)q::load_weight_bank(argv[1], memory, staging.ref(), queue, context, bank, pools); }
    catch (const std::runtime_error &) { default_rejected = true; }
    if (!default_rejected || !bank.empty() || !pools.empty())
      throw std::runtime_error("text-only loader must reject an MTP manifest before upload");
    const auto begin = q::Clock::now();
    const auto loaded = q::load_weight_bank(argv[1], memory, staging.ref(), queue,
        context, bank, pools, q::WeightSelection::kTextAndMtp);
    const auto seconds = std::chrono::duration<double>(q::Clock::now()-begin).count();
    if (loaded.bytes != 3885311680ULL || bank.size() != 335 || pools.size() != 335)
      throw std::runtime_error("real text+MTP uploaded inventory differs");
    std::ifstream manifest(argv[1]);
    std::string signature, shard, identity, line;
    std::getline(manifest, signature); std::getline(manifest, shard); std::getline(manifest, identity);
    std::ifstream source(shard, std::ios::binary);
    if (!source) throw std::runtime_error("cannot open original shard for payload oracle");
    std::size_t tensors = 0, bytes = 0;
    while (std::getline(manifest, line)) {
      std::istringstream fields(line);
      std::string name, type; std::size_t rank = 0, offset = 0, size = 0;
      fields >> name >> type >> rank;
      for (std::size_t i = 0; i < rank; ++i) { std::int64_t dimension = 0; fields >> dimension; }
      fields >> offset >> size;
      if (!fields) throw std::runtime_error("probe manifest parse failed");
      if (!name.starts_with("mtp.")) continue;
      std::vector<std::byte> original(size), uploaded(size);
      source.seekg(static_cast<std::streamoff>(offset));
      source.read(reinterpret_cast<char *>(original.data()), static_cast<std::streamsize>(size));
      if (!source) throw std::runtime_error("short original MTP range");
      q::check(bank.at(name).read().storage().read(uploaded));
      if (original != uploaded) throw std::runtime_error("MTP device payload differs: " + name);
      std::cerr << "payload_equal name=" << name << " bytes=" << size << '\n';
      ++tensors; bytes += size;
    }
    if (tensors != 15 || bytes != 121656320)
      throw std::runtime_error("MTP payload verification inventory differs");
    {
      q::Recipe recipe(bank, memory, 2);
      const auto relative = recipe.weight("embed_tokens.weight");
      const auto absolute = recipe.weight_absolute("model.language_model.embed_tokens.weight");
      if (relative != absolute || recipe.constants.size() != 1)
        throw std::runtime_error("target relative/absolute weight lookup duplicates a constant");
      const auto mtp = recipe.weight_absolute("mtp.fc.weight");
      if (mtp != recipe.weight_absolute("mtp.fc.weight") || recipe.constants.size() != 2)
        throw std::runtime_error("MTP absolute weight lookup duplicates a constant");
    }
    q::check(context.drain());
    std::cout << "{\"status\":\"PASS real MTP weights only\",\"total_tensors\":" << bank.size()
              << ",\"total_bytes\":" << loaded.bytes << ",\"mtp_tensors\":" << tensors
              << ",\"mtp_bytes\":" << bytes << ",\"all_mtp_device_bytes_equal_original\":true"
              << ",\"default_text_rejects_mtp_manifest_before_upload\":true"
              << ",\"absolute_and_relative_constants_deduplicated\":true"
              << ",\"staging_bytes\":" << loaded.stream.staging_bytes
              << ",\"load_seconds\":" << seconds << ",\"MTP_inference_executed\":false}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "loader probe failed: " << error.what() << '\n';
    return 1;
  }
}
