from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
M=Path(__file__).resolve().parent;R=M.parents[1]
sp=importlib.util.spec_from_file_location('build',M/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('mode',choices=('prepare','probe','r1','batch'));a=p.parse_args();out=M/(a.mode+'-run1');out.mkdir(exist_ok=False)
env=os.environ.copy()
if a.mode=='prepare':
 command=[sys.executable,str(R/'tools/qwen35_text/prepare.py'),'--model',r'C:/Users/kiro/Downloads/Qwen3.5-2B','--output',str(M/'prepared'),'--mtp']
else:
 ready=c.read(M/f'{"probe"if a.mode=="probe"else"qwen"}-ready-attempt1.json');assert b.identity(ready['image']['path'])==ready['image']
 env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
 if a.mode=='probe':command=[ready['image']['path'],str(M/'prepared/weights.tsv')]
 else:
  old=c.read(R/'.scratch/qwen-topone-prepared-20261022'/f'{a.mode}-run1/run.command.json');command=old['command'].copy();command[0]=ready['image']['path'];command[command.index('--trace')+1]=str(out/'trace')
 c.save(out/'identity.json',ready)
c.save(out/'plan.json',dict(command=command,throughput_evidence=False))
c.execute('run',command,env,out)
