#include <initializer_list>
#include <bit>
#include <cstdint>
#include <cstdio>
#include <immintrin.h>
using uint=std::uint32_t;
uint hyle_clz(uint x){return std::countl_zero(x);}
uint hyle_mul_hi(uint a,uint b){return uint((std::uint64_t(a)*b)>>32);}

uint hyle_shift_jam(uint value, uint distance) {
  if (distance == 0u) return value;
  if (distance >= 32u) return uint(value != 0u);
  return (value >> distance) | uint((value << (32u-distance)) != 0u);
}

uint hyle_f32_pack(uint sign, int exponent, uint significand) {
  if (significand == 0u) return sign;
  if (significand >= 0x08000000u) {
    significand = hyle_shift_jam(significand,1u);
    ++exponent;
  }
  while (significand < 0x04000000u && exponent > 1) {
    significand <<= 1u;
    --exponent;
  }
  if (exponent < 1) {
    significand = hyle_shift_jam(significand,uint(1-exponent));
    exponent = 1;
  }
  uint tail = significand & 7u;
  uint rounded = (significand >> 3u) +
      uint(tail > 4u || (tail == 4u && (significand & 8u) != 0u));
  if (rounded >= 0x01000000u) {
    rounded >>= 1u;
    ++exponent;
  }
  if (exponent >= 255) return sign | 0x7f800000u;
  uint field = exponent == 1 && rounded < 0x00800000u ? 0u : uint(exponent);
  return sign | (field << 23u) | (rounded & 0x007fffffu);
}

struct HyleF32Parts { uint significand; int exponent; };
HyleF32Parts hyle_f32_parts(uint bits) {
  HyleF32Parts value;
  value.significand = bits & 0x007fffffu;
  value.exponent = int((bits >> 23u) & 255u);
  if (value.exponent != 0) value.significand |= 0x00800000u;
  else {
    uint shift = hyle_clz(value.significand)-8u;
    value.significand <<= shift;
    value.exponent = 1-int(shift);
  }
  return value;
}

uint hyle_f32_nan(uint a, uint b) {
  if ((a & 0x7fffffffu) > 0x7f800000u) return a | 0x00400000u;
  if ((b & 0x7fffffffu) > 0x7f800000u) return b | 0x00400000u;
  return 0x7fc00000u;
}

uint hyle_f32_mul(uint a, uint b) {
  uint sign = (a ^ b) & 0x80000000u;
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa >= 0x7f800000u || bb >= 0x7f800000u) {
    if (aa > 0x7f800000u || bb > 0x7f800000u || aa == 0u || bb == 0u)
      return hyle_f32_nan(a,b);
    return sign | 0x7f800000u;
  }
  if (aa == 0u || bb == 0u) return sign;
  HyleF32Parts left = hyle_f32_parts(a), right = hyle_f32_parts(b);
  uint low = left.significand * right.significand;
  uint high = hyle_mul_hi(left.significand,right.significand);
  uint extended = (high << 12u) | (low >> 20u) | uint((low & 0x000fffffu) != 0u);
  return hyle_f32_pack(sign,left.exponent+right.exponent-127,extended);
}

uint hyle_f32_div(uint a, uint b) {
  uint sign = (a ^ b) & 0x80000000u;
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa > 0x7f800000u || bb > 0x7f800000u ||
      (aa == 0x7f800000u && bb == 0x7f800000u) || (aa == 0u && bb == 0u))
    return hyle_f32_nan(a,b);
  if (aa == 0x7f800000u || bb == 0u) return sign | 0x7f800000u;
  if (aa == 0u || bb == 0x7f800000u) return sign;
  HyleF32Parts left = hyle_f32_parts(a), right = hyle_f32_parts(b);
  int exponent = left.exponent-right.exponent+127;
  uint remainder = left.significand, quotient = 0u;
  if (remainder < right.significand) {
    remainder <<= 1u;
    --exponent;
  }
  for (uint bit = 0u; bit < 27u; ++bit) {
    uint next = uint(remainder >= right.significand);
    if (next != 0u) remainder -= right.significand;
    quotient = (quotient << 1u) | next;
    if (bit != 26u) remainder <<= 1u;
  }
  quotient |= uint(remainder != 0u);
  return hyle_f32_pack(sign,exponent,quotient);
}

uint hyle_f32_add(uint a, uint b) {
  uint aa = a & 0x7fffffffu, bb = b & 0x7fffffffu;
  if (aa >= 0x7f800000u || bb >= 0x7f800000u) {
    if (aa > 0x7f800000u || bb > 0x7f800000u ||
        (aa == 0x7f800000u && bb == 0x7f800000u && ((a ^ b) & 0x80000000u) != 0u))
      return hyle_f32_nan(a,b);
    return aa == 0x7f800000u ? a : b;
  }
  if (aa == 0u && bb == 0u) return (a & b) & 0x80000000u;
  if (aa == 0u) return b;
  if (bb == 0u) return a;
  // Larger magnitude first keeps subtraction nonnegative, including zeros.
  if (aa < bb) { uint temporary=a; a=b; b=temporary; }
  uint ea = (a >> 23u) & 255u, eb = (b >> 23u) & 255u;
  uint left = (a & 0x007fffffu) | (ea == 0u ? 0u : 0x00800000u);
  uint right = (b & 0x007fffffu) | (eb == 0u ? 0u : 0x00800000u);
  ea = ea == 0u ? 1u : ea;
  eb = eb == 0u ? 1u : eb;
  left <<= 3u;
  right = hyle_shift_jam(right << 3u,ea-eb);
  uint result = ((a ^ b) & 0x80000000u) == 0u ? left+right : left-right;
  // Exact cancellation under round-to-nearest produces positive zero.
  if (result == 0u) return 0u;
  return hyle_f32_pack(a & 0x80000000u,int(ea),result);
}

uint native(uint a,uint b,int op){
  volatile float x=std::bit_cast<float>(a), y=std::bit_cast<float>(b);
  volatile float result=op==0?x*y:op==1?x/y:x+y;
  return std::bit_cast<uint>(float(result));
}
bool nan(uint x){return (x&0x7fffffffU)>0x7f800000U;}
unsigned long long comparisons=0;
bool check(uint a,uint b){
  const uint actual[3]={hyle_f32_mul(a,b),hyle_f32_div(a,b),hyle_f32_add(a,b)};
  for(int op=0;op<3;++op){
    const uint expected=native(a,b,op);++comparisons;
    if(actual[op]!=expected && !(nan(actual[op])&&nan(expected))){
      std::printf("mismatch op=%d a=%08x b=%08x actual=%08x expected=%08x\n",op,a,b,actual[op],expected);return false;
    }
  }
  return true;
}
int main(){
  const unsigned csr=_mm_getcsr();_mm_setcsr(0x1f80);
  const uint edge[]={0,1,2,3,0x7fff,0x8000,0xffff,0x10000,0x3fffff,0x400000,0x7ffffe,0x7fffff,0x800000,0x800001,0xffffff,0x1000000,0x1ffffff,0x30000000,0x3e800000,0x3f000000,0x3f7fffff,0x3f800000,0x3f800001,0x3fc00000,0x40000000,0x4affffff,0x7f7ffffe,0x7f7fffff,0x7f800000,0x7f800001,0x7fc00000,0x7fffffff};
  for(uint a:edge)for(uint b:edge)for(uint sa:{0u,0x80000000u})for(uint sb:{0u,0x80000000u})
    if(!check(a|sa,b|sb))return 1;
  std::uint64_t state=0x9e3779b97f4a7c15ULL;
  auto random=[&](){state^=state<<13;state^=state>>7;state^=state<<17;return uint(state);};
  for(unsigned i=0;i<2000000;++i)if(!check(random(),random()))return 2;
  for(unsigned i=0;i<200000;++i){
    uint a=random(),b=random();a=(a&0x807fffffU)|((random()%32u)<<23);b=(b&0x807fffffU)|((random()%32u)<<23);
    if(!check(a,b)||!check(a,(a^0x80000000U)+(random()%3u)))return 3;
  }
  _mm_setcsr(csr);
  std::printf("{\"comparisons\":%llu,\"mismatches\":0,\"native_FTZ_DAZ\":false,\"NaN_payload_policy\":\"class_only\"}\n",comparisons);
}
