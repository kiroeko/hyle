"""Refresh only the shared-fixture owners, retaining the actual NVFP4 closure."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
N = A / 'nvfp4-reference-linear'
spec = importlib.util.spec_from_file_location('nvfp4_cross_helpers', A / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

def main():
    arm, mode = sys.argv[1:3]
    out = S / arm
    out.mkdir(exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    base_path = N / (arm + '-final/link-plan.json')
    base = c.read(base_path)
    old_test = c.read(N / ('tests/failure-lifecycle-fix/' + arm + '/test-identity.json'))['object']
    new_test = c.read(N / ('tests/subnormal-nonzero/' + arm + '/test-identity.json'))['object']
    replacements = {c.key(old_test['path']): new_test}
    if arm == 'cuda':
        metadata = h.metadata({arm: base})
        owners = [row for row in base['inputs'] if c.key(row['path']) in metadata and
                  Path(metadata[c.key(row['path'])]['source_path']).name == 'ggml_cuda_provider.cc']
        assert len(owners) == 1, owners
        replacements[c.key(owners[0]['path'])] = c.read(A / 'decode-retirement-query-reuse/checks/provider-identity.json')['object']
    inputs = [replacements.get(c.key(row['path']), row) for row in base['inputs']]
    for row in inputs:
        assert h.same_identity(row), row['path']
    image = out / (arm + '.exe')
    command = [replacements.get(c.key(arg), {}).get('path', arg) for arg in base['command']
               if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    env, runtime = b.environment(base['command'], [row['path'] for row in inputs], out)
    if mode == 'link':
        c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, replacements=replacements, base=b.identity(base_path)))
        c.execute('link', command, env, out)
        c.save(out / 'image.json', b.identity(image))
    elif mode == 'run':
        assert image.is_file()
        filt = 'CpuNvfp4ReferenceGraph.*:NativeNvfp4.*' if arm == 'cpu' else 'CudaNvfp4ReferenceGraph.*'
        c.execute('run', [str(image), '--gtest_filter=' + filt, '--gtest_output=xml:' + str(out / 'tests.xml')], env, out)
    else:
        raise ValueError(mode)

if __name__ == '__main__':
    main()
