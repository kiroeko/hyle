"""Seal this increment; keep the earlier CPU/CUDA reference report immutable."""
from pathlib import Path
import hashlib
import json
import zipfile
import xml.etree.ElementTree as ET

S = Path(__file__).resolve().parent
A = S.parent
ROOT = A.parents[1]
N = A / 'nvfp4-reference-linear'
V = A / 'nvfp4-vulkan-reference'
M = A / 'nvfp4-shader-math'
DEST = ROOT / 'docs/evidence/correctness'

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def identity(p):
    p = p.resolve()
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def checked(row):
    actual = identity(Path(row['path']))
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']

def xml_summary(path):
    root = ET.parse(path).getroot()
    assert int(root.get('failures')) == 0 and int(root.get('errors')) == 0
    assert not any(int(s.get('skipped', '0')) for s in root.findall('testsuite'))
    return dict(tests=int(root.get('tests')), failures=0, skipped=0, xml=identity(path),
        cases=[dict(suite=s.get('name'), name=t.get('name'),
            properties={p.get('name'):p.get('value') for p in t.findall('properties/property')})
            for s in root.findall('testsuite') for t in s.findall('testcase')])

def main():
    apple = read(N / 'apple/final-validation.json')
    vulkan = read(V / 'freeze.json')
    assert xml_summary(V / 'checks/constants-and-nvfp4.xml')['tests'] == 8
    assert xml_summary(V / 'checks/neighbors.xml')['tests'] == 9
    assert apple['final']['tests'] == 6 and apple['final']['failures'] == 0
    for row in vulkan['sources']:
        checked(row['canonical'])
        checked(row['snapshot'])
    for row in read(N / 'apple/source-freeze.json')['files']:
        checked(dict(row, path=str(ROOT / row['path'])))
    local = {arm: xml_summary(S / arm / 'tests.xml') for arm in ['cpu', 'cuda']}
    assert local['cpu']['tests'] == 3 and local['cuda']['tests'] == 2
    for arm in ['cpu', 'cuda']:
        for row in read(S / arm / 'link-plan.json')['inputs']:
            checked(row)
    for row in read(N / 'apple/source-freeze.json')['external_shared_dependencies']:
        checked(row)
    math = json.loads((M / 'run.stdout.log').read_text(encoding='utf-8'))
    assert math['comparisons'] == 7212288 and math['mismatches'] == 0
    sources = [
        'src/compute_shader_shared/nvfp4_f32.h',
        'src/compute_route_vulkan/build_shaders.py',
        'src/compute_route_vulkan/vulkan_nvfp4.cc',
        'src/compute_route_vulkan/shaders/nvfp4.comp',
        'src/compute_route_vulkan/vulkan_operations.cc',
        'src/compute_route_vulkan/vulkan_program.cc',
        'src/compute_route_vulkan/vulkan_tensor.h',
        'src/compute_route_vulkan/vulkan_memory.cc',
        'src/compute_route_vulkan/vulkan_transfer_slot.cc',
        'src/compute_route_vulkan/vulkan_transfer_internal.h',
        'src/compute_route_vulkan/vulkan_memory_internal.h',
        'src/compute_route_vulkan/CMakeLists.txt',
        'tests/graph_route_vulkan/nvfp4_reference_test.cc',
        'tests/graph_route_vulkan/CMakeLists.txt',
        'tests/graph_route_vulkan/native_region_test.cc',
        'tests/compute_models/nvfp4_reference_fixture.h',
        'src/compute_route_apple/apple_nvfp4.h',
        'src/compute_route_apple/apple_nvfp4.cc',
        'src/compute_route_apple/apple_operations.cc',
        'src/compute_route_apple/apple_mature_float.cc',
        'src/compute_route_apple/CMakeLists.txt',
        'tests/graph_route_apple/nvfp4_reference_test.cc',
        'tests/graph_route_apple/CMakeLists.txt',
        'docs/user/compute.md', 'docs/architecture/compute-design.md',
        'docs/developer/current-work.md', 'docs/implementation/model-operators.md',
        'docs/implementation/model-quantizations.json']
    report = dict(status='implemented_and_focused_execution_passed', date='2026-10-20',
        scope='Extend the existing ModelOpt group16 BF16 software-reference Nvfp4Linear to Apple/Vulkan; re-execute CPU/CUDA with an additional nonzero subnormal-weight witness. No model artifact, quality or speed acceptance.',
        previous_contract='docs/evidence/correctness/nvfp4-reference-linear-2026-10-20.json',
        integration=dict(public_operation_unchanged=True, core_or_executor_added=False,
            apple='Existing typed Apple native lowering and CheckTrace. Logical E4M3 scale uses byte storage only for this operation; ordinary arithmetic cannot reinterpret it as U8.',
            vulkan='Existing Program dispatches, original six bindings/status word. Two phases quantize A once then consume original packed W/scales; no dense W bank.',
            math='One private U32 IEEE F32 add/mul/div source string with small Metal/GLSL dialect wrappers. This preserves legal subnormal globals and BF16 operands without depending on native float division accuracy or F32 denormal preservation.',
            workspace='A QDQ uses2*M*K bytes in each backend. Apple also uses compact per-group/output status arrays and managed CheckTrace; Vulkan uses its existing status word and slot storage. These are not claims that all GPU temporary/opaque allocation equals2*M*K.',
            cold_constant_copy='An actual6-byte E4M3 constant exposed Vulkan non-four-byte D2D rejection. Owned padded carriers now use the existing single TransferSlot allocation for two compute-queue legs, with an intervening completion wait and explicit transfer-write/read visibility. It is cold constant materialization, not warm inference; no host payload copy. Aligned D2D remains direct and clipped spans remain rejected.',
            output_origin='Vulkan binding5 has no byte-origin push field, so descriptor_buffer rejects a nonzero alignment prefix and validates padded capacity. Storage is independently allocated at the same padded capacity; an odd BF16 final word writes authorized padding only.'),
        validation=dict(cpu=local['cpu'], cuda=local['cuda'],
            apple=apple, vulkan=vulkan, shared_host_math=dict(**math, receipt=identity(M / 'identity.json'),
                scope='Actual generated integer core vs independent strict native IEEE host arithmetic, RNE with FTZ/DAZ off. Directed edge pairs and random/tiny/cancellation cases; NaN class only. Actual Metal/Vulkan tests separately establish device execution.')),
        shared_fixture=dict(lifetime_successes=8, runtime_successes=25, failed_completions=18,
            geometries=['M2/N3/K32', 'M2/N16/K2048'],
            new_witness='Each row A256 QDQs264; packed code+1, E4M3scale1 and F32 weight_global2^-130 must yield BF16 bits0x0284. Nonzero BF16 subnormal weights must survive multiplication by normal A.',
            numerical_scope='Independent oracle isolates BF16 operand and QDQ boundaries using sparse exact dot witnesses. F32 reduction order is backend-specific; not universal bitwise cross-backend reduction equivalence.'),
        build_scope='Reuse existing local/Mac SDKs, native objects and dependency caches; focused product/test host owners, shader generation and relinks only. No SDK/full build, CI, model throughput or new CMake configure/install test.',
        failures_retained=['Old Apple products reject the new entry; initial two Metal shader compiles failed on the reserved identifier half, then only that product owner was corrected.',
            'Initial Vulkan lifetime graph failed cold materialization of the6-byte scale; runtime-domain test already passed. The cold constant resource seam was fixed without changing the mathematical fixture.',
            'Host math first link lacked its task-local tmp directory; same compiled object was relinked after creating it.'],
        source_freeze=[identity(ROOT / p) for p in sources],
        execution_limits=['Windows CPU/CUDA/Vulkan plus MacBook Air M4 only; no new Linux execution.',
            'No selected artifact weight payload, whole-model import, model quality, throughput or peak-memory verification.',
            'This strict software reference is not hardware-native FP4 GEMM and does not establish equivalent W4A4 hardware accumulation.',
            'No Qwen BF16 decode speedup is attributed to these separate reference capability additions.'])
    (S / 'final-validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
    payload = {}
    def add(p, name):
        data = p.read_bytes()
        assert name not in payload or payload[name] == data
        payload[name] = data
    for p in sources:
        add(ROOT / p, 'source/' + p)
    roots = [('cross', S), ('apple', N / 'apple'), ('vulkan', V), ('shared-math', M),
        ('cpu-test', N / 'tests/subnormal-nonzero/cpu'), ('cuda-test', N / 'tests/subnormal-nonzero/cuda')]
    for label, folder in roots:
        for p in folder.rglob('*'):
            if not p.is_file() or p.suffix.lower() not in {'.json','.xml','.log','.py','.ps1','.cc','.h','.comp','.diff','.txt'}:
                continue
            if p.stat().st_size > 3_000_000 or 'tmp' in p.relative_to(folder).parts or 'cleanup' in p.relative_to(folder).parts:
                continue
            add(p, 'work/' + label + '/' + p.relative_to(folder).as_posix())
    manifest = [dict(member=k, bytes=len(v), sha256=hashlib.sha256(v).hexdigest()) for k,v in sorted(payload.items())]
    payload['payload-manifest.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
    archive = DEST / 'nvfp4-cross-backend-reference-2026-10-20.zip'
    assert not archive.exists(), 'This publisher is intentionally one-shot.'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in sorted(payload.items()):
            z.writestr(name, data)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
        for row in manifest:
            data = z.read(row['member'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    public = dict(report, archive=dict(**identity(archive), payloads=len(manifest), CRC_checked=True, all_payload_SHA256_checked=True))
    out = DEST / 'nvfp4-cross-backend-reference-2026-10-20.json'
    out.write_text(json.dumps(public, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps(dict(report=identity(out), archive=identity(archive), payloads=len(manifest)), indent=2))

if __name__ == '__main__':
    main()
