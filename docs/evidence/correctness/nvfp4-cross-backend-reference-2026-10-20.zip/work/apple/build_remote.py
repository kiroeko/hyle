from pathlib import Path
import concurrent.futures,hashlib,json,shlex,subprocess,sys,time,xml.etree.ElementTree as E
R=Path(__file__).resolve().parent;O=R/'results';O.mkdir(exist_ok=True);(R/'objects').mkdir(exist_ok=True)
plan=json.loads((R/'plan.json').read_text());manifest=json.loads((R/'source-manifest.json').read_text());expected={x['path']:x for x in manifest}
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(name,v):(O/name).write_text(json.dumps(v,indent=2)+'\n')
def execute(tag,command):
 record=dict(argv=command,started=time.time());save(tag+'.command.json',record);p=subprocess.run(command,cwd=R,capture_output=True,text=True);(O/(tag+'.stdout.log')).write_text(p.stdout);(O/(tag+'.stderr.log')).write_text(p.stderr);record.update(exit=p.returncode,seconds=time.time()-record['started']);save(tag+'.result.json',record);print(tag,p.returncode,round(record['seconds'],2),flush=True);return record
for row in manifest:assert identity(R/row['path'])['sha256']==row['sha256'],row['path']
for row in plan['inputs']:assert identity(row['path'])==row,row['path']
headers={str((R/row['path']).parent)for row in manifest if row['path'].endswith(('.h','.hpp','.hh','.inc','.inl'))and not row['path'].startswith('include/')}
first=['-I'+str(R/'include'),'-I'+str(R),*['-I'+p for p in sorted(headers)]]
def compile_one(row):
 rel=row['source'];tag=rel.replace('/','--');obj=R/'objects'/(tag+'.o');dep=Path(str(obj)+'.d');command=row['recipe'].copy()
 for flag in ['-MF','-MT','-MQ']:
  while flag in command:
   i=command.index(flag);del command[i:i+2]
 command=[x for x in command if x not in ['-MD','-MMD']];command[command.index('-c')+1]=str(R/rel);command[command.index('-o')+1]=str(obj);command[1:1]=first;command+=['-MD','-MF',str(dep)]
 result=execute(tag+'-compile',command);record=dict(result,source=identity(R/rel),old_object=row['old_object'],object=str(obj),dependency=str(dep))
 if result['exit']:save(tag+'-identity.json',record);return record
 paths=list(dict.fromkeys(shlex.split(dep.read_text().split(': ',1)[1].replace('\\\n',' '))));deps=[identity(p)for p in paths];drift=[]
 for x in deps:
  p=Path(x['path'])
  if p.is_relative_to(R):
   rel=p.relative_to(R).as_posix()
   if rel in expected and expected[rel]['sha256']!=x['sha256']:drift.append(x)
 record.update(object_identity=identity(obj),dependencies=deps,source_drifts=drift);save(tag+'-identity.json',record);assert not drift;return record
if '--compile'in sys.argv:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:records=list(pool.map(compile_one,plan['compile']))
 save('compile-summary.json',dict(compiles=records,passed=all(x['exit']==0 for x in records),SDK=False,NVCC=False));raise SystemExit(int(any(x['exit']for x in records)))
records=json.loads((O/'compile-summary.json').read_text())['compiles'];assert all(x['exit']==0 for x in records)
mode='before'if'--before'in sys.argv else'after';command=plan['link'].copy()
for row in records:
 rel=Path(row['source']['path']).relative_to(R).as_posix()
 if mode=='before'and 'apple_'in Path(rel).name:continue
 if row['old_object']:
  assert command.count(row['old_object'])==1;command[command.index(row['old_object'])]=row['object']
 else:command.insert(1,row['object'])
image=R/('nvfp4-'+mode);command[command.index('-o')+1]=str(image);command=[('-Wl,-map,'+str(image)+'.map')if x.startswith('-Wl,-map,')else x for x in command]
save(mode+'-link-inputs.json',[identity(x)for x in command if Path(x).is_file()and Path(x).suffix in ['.o','.a','.dylib']]);result=execute(mode+'-link',command);save(mode+'-link.json',result)
if result['exit']:raise SystemExit(2)
link=R/'mlx.metallib'
if not link.exists():link.symlink_to(Path(plan['metallib']).resolve())
pattern='AppleNvfp4ReferenceGraph.*'if mode=='before'else'AppleNvfp4ReferenceGraph.*:AppleGraphMlxQuantized.*'
result=execute(mode+'-run',[str(image),'--gtest_filter='+pattern,'--gtest_output=xml:'+str(O/(mode+'-tests.xml'))]);cases=E.parse(O/(mode+'-tests.xml')).findall('.//testcase');fail=[x.attrib for x in cases if x.findall('failure')];skip=[x.attrib for x in cases if x.findall('skipped')]
save(mode+'-validation.json',dict(image=identity(image),tests=len(cases),failed=fail,skipped=skip,exit=result['exit'],names=[x.get('classname')+'.'+x.get('name')for x in cases],source_manifest=identity(R/'source-manifest.json')));print(mode,len(cases),'failure',len(fail),'skip',len(skip),flush=True);raise SystemExit(result['exit'])
