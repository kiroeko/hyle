from pathlib import Path
import base64,hashlib,json,re,subprocess,sys
R=Path.cwd();S=Path(__file__).resolve().parent;A=S.parents[1]
attempt=sys.argv[1] if len(sys.argv)>1 else 'v1';O=S/attempt;O.mkdir(exist_ok=True)
remote='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/nvfp4-reference-linear/apple/'+attempt
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def identity(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
old=A/'batch-query-extent/delegated/apple/results/summary.json';recipes={x['source']:x for x in json.loads(old.read_text(encoding='utf-8'))['compiles']}
previous=A/'mlx-grouped-shared-activation/apple-verification/remote/results'
weight=json.loads((previous/'src--compute_ops--weight_decode.cc-identity.json').read_text(encoding='utf-8'))
test=json.loads((previous/'tests--graph_route_apple--mlx_quantized_test.cc-identity.json').read_text(encoding='utf-8'))
rels=['src/compute_route_apple/apple_operations.cc','src/compute_route_apple/apple_mature_float.cc','src/compute_route_apple/apple_nvfp4.cc','src/compute_ops/weight_decode.cc','tests/graph_route_apple/nvfp4_reference_test.cc']
rows=[]
for rel in rels:
 x=test if rel.startswith('tests/') else weight if 'weight_decode' in rel else recipes['src/compute_route_apple/apple_mature_float.cc']if 'apple_nvfp4' in rel else recipes[rel]
 rows.append(dict(source=rel,recipe=x['argv'],old_object=''if rel.startswith('tests/')or'apple_nvfp4' in rel else x['object']))
search=[R,R/'include',*[p for p in (R/'src').iterdir()if p.is_dir()],*[p for p in(R/'third_party').iterdir()if p.is_dir()]]
seen=set();pattern=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M)
def visit(path):
 path=path.resolve()
 if path in seen or not path.is_relative_to(R)or not path.is_file():return
 seen.add(path)
 if path.suffix not in ['.h','.hh','.hpp','.cc','.mm','.inc','.inl']:return
 for inc in pattern.findall(path.read_text(encoding='utf-8',errors='replace')):
  candidate=next((p for p in[path.parent/inc,*[q/inc for q in search]]if p.is_file()),None)
  if candidate is not None:visit(candidate)
for rel in rels:visit(R/rel)
files=[]
for p in sorted(seen):
 b=p.read_bytes();row=identity(p);row['path']=p.relative_to(R).as_posix();row['data']=base64.b64encode(b).decode();files.append(row)
manifest=[{k:v for k,v in x.items()if k!='data'}for x in files];save(O/'source-manifest.json',manifest)
for row in manifest:
 p=O/'source'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/row['path']).read_bytes())
base=A/'mlx-moe-typed-inputs/apple-layout-verification/remote/results';link=json.loads((base/'link.json').read_text(encoding='utf-8'))['argv'];inputs=json.loads((base/'link-inputs.json').read_text(encoding='utf-8'))
if attempt!='v1':
 base=S/'v1/remote/results';link=json.loads((base/'after-link.json').read_text(encoding='utf-8'))['argv'];inputs=json.loads((base/'after-link-inputs.json').read_text(encoding='utf-8'))
 rows=[x for x in rows if x['source']=='src/compute_route_apple/apple_nvfp4.cc'];rows[0]['old_object']=remote.rsplit('/',1)[0]+'/v1/objects/src--compute_route_apple--apple_nvfp4.cc.o'
for row in rows:
 if row['old_object']:assert link.count(row['old_object'])==1,row['source']
plan=dict(remote=remote,compile=rows,link=link,inputs=inputs,base_link=identity(base/('link.json'if attempt=='v1'else'after-link.json')),metallib='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib');save(O/'plan.json',plan)
payload=dict(plan=plan,files=files,script=base64.b64encode((S/'build_remote.py').read_bytes()).decode())
code='''from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);plan=p['plan'];r=Path(plan['remote']);r.mkdir(parents=True,exist_ok=True)
for row in p['files']:
 b=base64.b64decode(row['data']);assert hashlib.sha256(b).hexdigest()==row['sha256'];q=r/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/'source-manifest.json').write_text(json.dumps([{k:v for k,v in x.items()if k!='data'}for x in p['files']],indent=2)+'\\n')
(r/'plan.json').write_text(json.dumps(plan,indent=2)+'\\n');(r/'build_remote.py').write_bytes(base64.b64decode(p['script']))
for row in plan['inputs']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
h={key:subprocess.check_output(cmd,text=True).strip()for key,cmd in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version']}.items()};assert h['model']=='Mac16,12'
(r/'hardware.json').write_text(json.dumps(h,indent=2)+'\\n')
print(json.dumps(dict(remote=str(r),files=len(p['files']),bytes=sum(x['bytes']for x in p['files']),cached_inputs=len(plan['inputs']),hardware=h)))
'''
encoded=base64.b64encode(code.encode()).decode();command=['ssh','-o','BatchMode=yes','kiro@172.22.10.198','python3 -c "import base64;exec(base64.b64decode(\''+encoded+'\'))"'];save(O/'sync.command.json',command)
result=subprocess.run(command,input=json.dumps(payload).encode(),capture_output=True);(O/'sync.stdout.log').write_bytes(result.stdout);(O/'sync.stderr.log').write_bytes(result.stderr);save(O/'sync.result.json',dict(exit=result.returncode));print(result.stdout.decode(),result.stderr.decode());raise SystemExit(result.returncode)
