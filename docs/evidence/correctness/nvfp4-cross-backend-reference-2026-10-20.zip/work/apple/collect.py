from pathlib import Path
import base64,hashlib,json,subprocess,sys
S=Path(__file__).resolve().parent;O=S/sys.argv[1];plan=json.loads((O/'plan.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import base64,json,sys,hashlib
r=Path(sys.argv[1]);files=[]
ps=[r/'plan.json',r/'source-manifest.json',r/'hardware.json',*sorted((r/'results').glob('*'))]
for p in ps:
 if not p.is_file()or p.suffix not in ['.json','.xml','.log']:continue
 b=p.read_bytes();files.append(dict(path=p.relative_to(r).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),data=base64.b64encode(b).decode()))
print(json.dumps(files))
'''
encoded=base64.b64encode(code.encode()).decode();command=['ssh','-o','BatchMode=yes','kiro@172.22.10.198','python3 -c "import base64;exec(base64.b64decode(\''+encoded+'\'))" '+plan['remote']]
p=subprocess.run(command,capture_output=True,check=True);rows=json.loads(p.stdout);manifest=[]
for row in rows:
 b=base64.b64decode(row['data']);assert hashlib.sha256(b).hexdigest()==row['sha256'];q=O/'remote'/row['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);manifest.append({k:v for k,v in row.items()if k!='data'})
(O/'collected.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print(len(rows),sum(x['bytes']for x in rows))
