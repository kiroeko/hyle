from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();a=root/'.scratch/architecture-refactor-2026-10-18';out=a/'nvfp4-vulkan-reference';out.mkdir(exist_ok=True);phase=sys.argv[1] if len(sys.argv)>1 else 'host';folder=out/'checks';folder.mkdir(exist_ok=True)
basepath=a/'vulkan-mlx-constant-bank-reuse/checks/link-plan.json';base=json.loads(basepath.read_bytes());env=os.environ.copy();r=subprocess.run(['cmd','/d','/c',str(a/'bf16-nan-cast-contract/compiler-env.bat')],text=True,capture_output=True,check=True)
for line in r.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
prior=json.loads((a/'vulkan-mlx-constant-bank-reuse/checks/runtime-environment.json').read_bytes());env['PATH']=';'.join(prior['runtime']+[env.get('PATH','')])
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(Path(p).read_bytes())
records=[]
def run(label,command):
 start=time.time();r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace');(folder/(label+'.stdout.log')).write_bytes(r.stdout.encode());(folder/(label+'.stderr.log')).write_bytes(r.stderr.encode());records.append(dict(label=label,command=command,exit_code=r.returncode,seconds=time.time()-start));(folder/('commands-'+phase+'.json')).write_bytes((json.dumps(records,indent=2)+'\n').encode());print(label,r.returncode,flush=True)
 if r.returncode:print((r.stdout+r.stderr)[-7000:]);raise SystemExit(r.returncode)
 return r

def compile_one(source,recipe,tag):
 source=Path(source);old=load(recipe)['command'];command=[];skip=False
 for arg in old:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  command.append(arg)
 command.insert(1,'-I'+str(out/'shaders'));obj=folder/(tag+'.obj');command+=['/W4','/WX','/sourceDependencies',str(folder/(tag+'-deps.json')),str(source),'/Fo'+str(obj),'/Fd'+str(folder/(tag+'.pdb'))];run(tag+'-compile',command);d=load(folder/(tag+'-deps.json'))['Data'];receipt=dict(command=command,source=ident(source),object=ident(obj),recipe=ident(recipe),dependencies=[ident(p)for p in dict.fromkeys([d['Source'],*d['Includes']])]);(folder/(tag+'-identity.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode());return receipt
ops=a/'mlx-moe-typed-inputs/vulkan/checks/compute_route_vulkan-vulkan_operations-identity.json';program=a/'mlx-moe-typed-inputs/vulkan/checks/compute_route_vulkan-vulkan_program-identity.json';test=a/'mlx-affine-widths/vulkan/refresh-20261019T140912/tests--graph_route_vulkan--iree_test-identity.json'
if phase=='host':
 compile_one(root/'src/compute_route_vulkan/vulkan_operations.cc',ops,'vulkan_operations');compile_one(root/'src/compute_route_vulkan/vulkan_program.cc',program,'vulkan_program');compile_one(root/'tests/graph_route_vulkan/nvfp4_reference_test.cc',test,'nvfp4-test')
elif phase=='shader-host':
 compile_one(root/'src/compute_route_vulkan/vulkan_nvfp4.cc',ops,'vulkan_nvfp4');compile_one(out/'shaders/vulkan_shaders.cc',ops,'vulkan_shaders')
elif phase=='fixture':
 receipt=compile_one(root/'tests/graph_route_vulkan/nvfp4_reference_test.cc',test,'nvfp4-test-current')
 (folder/'current-fixture.json').write_bytes((json.dumps(dict(fixture=ident(root/'tests/compute_models/nvfp4_reference_fixture.h'),wrapper=receipt['source'],object=receipt['object']),indent=2)+'\n').encode())
elif phase=='transfer-host':
 compile_one(root/'src/compute_route_vulkan/vulkan_memory.cc',a/'vulkan-view-root-owner/checks/vulkan_memory-identity.json','vulkan_memory');compile_one(root/'src/compute_route_vulkan/vulkan_transfer_slot.cc',ops,'vulkan_transfer_slot')
elif phase=='constant-test':
 compile_one(root/'src/compute_route_vulkan/vulkan_transfer_slot.cc',ops,'vulkan_transfer_slot');compile_one(root/'tests/graph_route_vulkan/native_region_test.cc',test,'native-region-test')
elif phase=='link':
 replacements={str(a/'mlx-moe-typed-inputs/vulkan/checks/compute_route_vulkan-vulkan_operations.obj'):str(folder/'vulkan_operations.obj'),str(a/'mlx-moe-typed-inputs/vulkan/checks/compute_route_vulkan-vulkan_program.obj'):str(folder/'vulkan_program.obj'),str(root/'.scratch/inference-foundation-review-2026-10-18/native-row-cache-padded/shaders.obj'):str(folder/'vulkan_shaders.obj'),str(a/'mlx-grouped-shared-activation/checks/weight-decode.obj'):str(a/'nvfp4-reference-linear/cuda/weight-decode.obj')}
 replacements.update({str(a/'vulkan-view-root-owner/checks/vulkan_memory.obj'):str(folder/'vulkan_memory.obj'),str(a/'gguf-nvfp4/windows-host/checks/20261019T201048/o4971cd07--compute_route_vulkan--vulkan_transfer_slot.obj'):str(folder/'vulkan_transfer_slot.obj')})
 removed=str(a/'paged-row-scorer/validation/windows-current/row-cache-paged-shader.obj');seen=set();command=[]
 for arg in base['command']:
  if arg==removed:seen.add(arg);continue
  if arg in replacements:seen.add(arg);arg=replacements[arg]
  if arg.startswith('/OUT:'):arg='/OUT:'+str(folder/'vulkan.exe')
  elif arg.startswith('/MAP:'):arg='/MAP:'+str(folder/'vulkan.map')
  elif arg.startswith('/IMPLIB:'):arg='/IMPLIB:'+str(folder/'vulkan.lib')
  command.append(arg)
 assert seen==set(replacements)|{removed},seen
 command[1:1]=[str(folder/'vulkan_nvfp4.obj'),str(folder/'nvfp4-test-current.obj'),str(folder/'native-region-test.obj')]
 inputs=[ident(arg)for arg in command[1:]if Path(arg).is_file()]
 for old in base['inputs']:
  if old['path'] in seen:continue
  if old['path'] in command:
   now=ident(old['path']);assert now['sha256']==old['sha256'],('baseline input changed',old['path'])
 (folder/'link-plan.json').write_bytes((json.dumps(dict(command=command,inputs=inputs,base=ident(basepath)),indent=2)+'\n').encode())
 run('link',command)
 (folder/'executable.json').write_bytes((json.dumps(ident(folder/'vulkan.exe'),indent=2)+'\n').encode())
 (folder/'runtime-environment.json').write_bytes((json.dumps(dict(runtime=prior['runtime']),indent=2)+'\n').encode())
else:raise ValueError(phase)
