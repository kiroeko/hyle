from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();out=root/'.scratch/architecture-refactor-2026-10-18/nvfp4-vulkan-reference';folder=out/'checks';environment=json.loads((folder/'runtime-environment.json').read_bytes());env=os.environ.copy();env['PATH']=';'.join(environment['runtime']+[env.get('PATH','')]);label=sys.argv[1]if len(sys.argv)>1 else 'nvfp4';filters=sys.argv[2]if len(sys.argv)>2 else 'VulkanNvfp4ReferenceGraph.*'
command=[str(folder/'vulkan.exe'),'--gtest_filter='+filters,'--gtest_output=xml:'+str(folder/(label+'.xml'))]
start=time.time();r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,errors='replace');(folder/(label+'.stdout.log')).write_bytes(r.stdout.encode());(folder/(label+'.stderr.log')).write_bytes(r.stderr.encode());print(r.stdout+r.stderr)
def ident(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
receipt=dict(command=command,exit_code=r.returncode,seconds=time.time()-start,executable=ident(folder/'vulkan.exe'),shared_fixture=ident(root/'tests/compute_models/nvfp4_reference_fixture.h'),stdout=ident(folder/(label+'.stdout.log')),stderr=ident(folder/(label+'.stderr.log')))
(folder/(label+'-run.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode());raise SystemExit(r.returncode)
