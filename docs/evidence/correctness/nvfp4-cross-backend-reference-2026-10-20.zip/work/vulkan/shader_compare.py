from pathlib import Path
import hashlib,json,subprocess,time
root=Path.cwd();out=root/'.scratch/architecture-refactor-2026-10-18/nvfp4-vulkan-reference';control=out/'shaders-control';source=root/'src/compute_route_vulkan/build_shaders.py'
def ident(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
line="        ('nvfp4', str((args.tensor_source / 'nvfp4.comp').resolve()), {}, {1}),\n"
original=source.read_text();assert original.count(line)==1
script=out/'build_shaders_control.py';script.write_bytes(original.replace(line,'').encode())
command=['python',str(script),'--compiler','C:/public/tools/glslang/glslangValidator.exe','--source',str(root/'third_party/ggml_vulkan_shaders/shaders'),'--tensor-source',str(root/'src/compute_route_vulkan/shaders'),'--output',str(control)]
start=time.time();r=subprocess.run(command,capture_output=True,text=True);(out/'checks/shader-control.stdout.log').write_bytes(r.stdout.encode());(out/'checks/shader-control.stderr.log').write_bytes(r.stderr.encode());print('shader control',r.returncode,flush=True)
if r.returncode:print(r.stdout+r.stderr);raise SystemExit(r.returncode)
checks=[]
for p in sorted(control.glob('*.spv')):
 current=out/'shaders'/p.name;checks.append(dict(control=ident(p),current=ident(current),equal=p.read_bytes()==current.read_bytes()))
assert len(checks)==12 and all(x['equal'] for x in checks)
receipt=dict(command=command,exit_code=r.returncode,seconds=time.time()-start,generator=ident(source),control_generator=ident(script),control_change='Remove only the NVFP4 variant entry; all twelve pre-existing variants use identical current sources and commands.',shared_numerical=ident(root/'src/compute_shader_shared/nvfp4_f32.h'),comparison=checks,nvfp4_shader=ident(out/'shaders/nvfp4.spv'))
(out/'checks/shader-comparison.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print('12/12 existing shader variants byte-identical',flush=True)
