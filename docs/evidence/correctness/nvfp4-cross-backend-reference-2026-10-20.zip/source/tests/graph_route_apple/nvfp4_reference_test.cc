#include "../compute_models/nvfp4_reference_fixture.h"
#include "hyle/compute/apple_memory.h"
#include "hyle/graph/apple.h"

namespace {
namespace f = nvfp4_reference_test;
namespace a = hyle::compute::apple;
template<class Run> void run_apple(Run run) {
  auto context = f::take(a::Context::create(), "Apple context");
  ::testing::Test::RecordProperty("device", context.environment()->device_name);
  auto memory = f::take(a::MemoryResource::create(context), "Apple shared memory");
  const std::array domains{f::g::StorageDomain{memory.ref()}};
  const std::array targets{f::g::ExecutionTarget{
      f::take(f::g::apple::execution_source(context), "Apple execution source"), f::g::StorageDomainId{0}}};
  run(memory.ref(), std::span<const f::g::QueueBinding>{},
      [&](const f::g::Graph &graph, f::g::CompileOptions options) {
        return f::g::compile(graph, {domains,targets}, options);
      },
      [](f::m::BufferView destination, std::span<const std::byte> source) { return destination.write(source); },
      [](f::m::ConstBufferView source, std::span<std::byte> destination) { return source.read(destination); },
      [](f::g::Invocation &invocation, std::span<const f::g::QueueBinding> bindings) { return invocation.prepare_replay(bindings); });
}
}

TEST(AppleNvfp4ReferenceGraph, OriginalPackedBanksAndBfloatBoundariesSurviveSlotsAndUpdates) {
  run_apple([](auto resource, auto queues, auto compile, auto write, auto read, auto prepare) {
    f::run_lifetimes(resource, queues, compile, write, read, prepare);
  });
}
TEST(AppleNvfp4ReferenceGraph, RuntimeDomainFailuresRecoverWithoutChangingTheReferenceTree) {
  run_apple([](auto resource, auto queues, auto compile, auto write, auto read, auto prepare) {
    f::run_runtime_domain(resource, queues, compile, write, read, prepare);
  });
}
TEST(AppleNvfp4ReferenceGraph, ByteCarrierDoesNotTurnLogicalFp8IntoIntegerArithmetic) {
  auto context = f::take(a::Context::create(), "Apple context");
  auto memory = f::take(a::MemoryResource::create(context), "Apple memory");
  const auto description = f::dense(f::Type::kFloat8E4M3FN, {2,2});
  auto spec = a::input_spec(description);
  ASSERT_TRUE(spec) << spec.error().message();
  EXPECT_EQ(spec->dtype, mlx::core::uint8);
  EXPECT_EQ(spec->logical_description, description);
  auto builder = f::take(f::g::GraphBuilder::create(), "FP8 graph builder");
  const auto input = f::take(builder.input(description), "logical FP8 input");
  const auto output = f::take(builder.add(f::c::Cast{f::Type::kFloat32}, input), "logical FP8 Cast");
  f::check(builder.publish(output), "publish logical FP8 Cast");
  const auto graph = f::take(std::move(builder).finish(), "finish logical FP8 graph");
  const std::array domains{f::g::StorageDomain{memory.ref()}};
  const std::array targets{f::g::ExecutionTarget{
      f::take(f::g::apple::execution_source(context), "Apple source"), f::g::StorageDomainId{0}}};
  const auto compiled = f::g::compile(graph, {domains,targets});
  EXPECT_FALSE(compiled) << "an unsupported FP8 Cast must not numerically cast unsigned codes";
}
