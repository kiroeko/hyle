#include "vulkan_tensor.h"

#include <algorithm>
#include <array>
#include <limits>
#include <new>

#include "hyle/compute/model_ops.h"
#include "vulkan_shaders.h"

namespace hyle::compute::vulkan::detail {
Status lower_nvfp4(ProgramState &program, const PlanStep &step) noexcept try {
  std::array<TensorDesc, 5> inputs;
  if (step.inputs.size() != inputs.size() || step.outputs.size() != 1)
    return Status::InvalidArgument("Vulkan NVFP4 port count differs");
  for (std::size_t i = 0; i < inputs.size(); ++i)
    inputs[i] = program.values[step.inputs[i]].description;
  std::array<TensorDesc, 1> inferred;
  HYLE_RETURN_IF_ERROR(infer_output_descriptions(step.operation, inputs, inferred));
  if (inferred[0] != program.values[step.outputs[0]].description)
    return Status::InvalidArgument("Vulkan NVFP4 output differs from schema");
  const auto &device = *program.runtime->device;
  const auto &limits = device.properties.limits;
  const auto rows = std::uint64_t(inputs[0].dimensions()[0]);
  const auto columns = std::uint64_t(inputs[1].dimensions()[0]);
  const auto depth = std::uint64_t(inputs[0].dimensions()[1]);
  constexpr auto maximum = std::uint64_t{UINT32_MAX};
  if (rows > maximum || columns > maximum || depth > maximum ||
      limits.maxComputeWorkGroupInvocations < 64 ||
      limits.maxComputeWorkGroupSize[0] < 64 || limits.maxComputeWorkGroupCount[0] == 0 ||
      limits.maxComputeWorkGroupCount[1] == 0)
    return Status::Unimplemented("Vulkan NVFP4 byte indexing or dispatch limit");
  // Check the original carriers, not the hypothetical dense weight bank.
  // The general plan also bounds each actual element count to INT32_MAX;
  // that keeps the shader's group/output products within its U32 index domain.
  const auto check_bytes = [&](const TensorDesc &description) -> Status {
    HYLE_ASSIGN_OR_RETURN(auto bytes, description.required_bytes());
    HYLE_ASSIGN_OR_RETURN(auto capacity, buffer_capacity(bytes));
    if (capacity > maximum || capacity > limits.maxStorageBufferRange)
      return Status::Unimplemented("Vulkan NVFP4 storage exceeds byte indexing or device limits");
    return Status::Ok();
  };
  for (const auto &description : inputs) HYLE_RETURN_IF_ERROR(check_bytes(description));
  HYLE_RETURN_IF_ERROR(check_bytes(inferred[0]));
  // Only one BF16 activation copy is materialized. Weights/scales stay packed;
  // each shader invocation owns one group or one pair of output scalars.
  const auto append = [&](const TensorDesc &description) {
    const auto id = static_cast<std::uint32_t>(program.values.size());
    program.values.push_back({description, {}});
    program.aliases.push_back({id, 0});
    return id;
  };
  const auto activation = append(inputs[0]);
  if (!program.status_value) {
    HYLE_ASSIGN_OR_RETURN(auto status, TensorDesc::dense(DataType::kInt32, {}));
    program.status_value = append(status);
  }
  const auto add_dispatch = [&](std::uint32_t phase,
      std::array<std::uint32_t, 6> values, std::uint64_t work) -> Status {
    const std::array<SpecializationConstant, 4> constants{{
        {0, phase}, {1, std::uint32_t(rows)}, {2, std::uint32_t(columns)},
        {3, std::uint32_t(depth)}}};
    Dispatch dispatch;
    HYLE_ASSIGN_OR_RETURN(dispatch.pipeline, create_pipeline(program.runtime->device,
        {shaders::nvfp4(), 6, 20, constants}));
    dispatch.values.assign(values.begin(), values.end());
    dispatch.tensor_byte_origins = true;
    dispatch.checked_status = true;
    dispatch.push.resize(20);
    const auto groups = (work + 63) / 64;
    const auto x = (std::min)(groups, std::uint64_t(limits.maxComputeWorkGroupCount[0]));
    const auto y = (groups + x - 1) / x;
    if (y > limits.maxComputeWorkGroupCount[1])
      return Status::Unimplemented("Vulkan NVFP4 dispatch grid exceeds native limits");
    dispatch.groups = {std::uint32_t(x), std::uint32_t(y), 1};
    program.dispatches.push_back(std::move(dispatch));
    return Status::Ok();
  };
  const auto status = *program.status_value;
  HYLE_RETURN_IF_ERROR(add_dispatch(0,
      {step.inputs[0], step.inputs[4], status, step.inputs[3], step.inputs[2], activation},
      (std::max)(rows * (depth / 16), columns * (depth / 16))));
  return add_dispatch(1,
      {activation, step.inputs[1], status, step.inputs[2], step.inputs[3], step.outputs[0]},
      (rows * columns + 1) / 2);
} catch (const std::bad_alloc &) {
  return Status::ResourceExhausted("Vulkan NVFP4 preparation metadata");
}
} // namespace hyle::compute::vulkan::detail
