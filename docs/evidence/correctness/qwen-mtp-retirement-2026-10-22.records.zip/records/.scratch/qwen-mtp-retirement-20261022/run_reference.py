from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
U=Path(__file__).resolve().parent;R=U.parents[1]
sp=importlib.util.spec_from_file_location('build',U/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
d=c.read(U/'reference/design.json');command=d['execution_next']['command'];command=[str((R/x).resolve())if i==1 else x for i,x in enumerate(command)]
source=Path(command[1]);out=U/'reference/run1';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false',CUDA_VISIBLE_DEVICES='-1')
c.save(out/'plan.json',dict(command=command,source=b.identity(source),design=b.identity(U/'reference/design.json'),device='cpu',throughput_comparison=False,candidate_feedback=False))
c.execute('reference',command,env,out)
