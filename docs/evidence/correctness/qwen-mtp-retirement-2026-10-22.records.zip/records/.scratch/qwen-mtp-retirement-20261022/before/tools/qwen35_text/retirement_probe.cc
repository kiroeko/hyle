// Explicit, non-timing consumer of the same Model/Session implementation.
#define main hyle_qwen35_text_consumer_main
#include "main.cc"
#undef main

#include <condition_variable>
#include "hyle/compute/detail/paged_arena_access.h"
#include <mutex>
#include <thread>

namespace {
namespace q = qwen35;
namespace c = q::c;
namespace cu = c::cuda;
namespace cb = q::benchmark;

void require(bool condition, const char *message) {
  if (!condition) throw std::runtime_error(message);
}

struct NativeGate final {
  std::mutex mutex;
  std::condition_variable condition;
  bool entered = false, open = false;
  static void CUDART_CB wait(void *opaque) {
    auto &gate = *static_cast<NativeGate *>(opaque);
    std::unique_lock lock(gate.mutex);
    gate.entered = true;
    gate.condition.notify_all();
    gate.condition.wait(lock, [&] { return gate.open; });
  }
  void wait_until_entered() {
    std::unique_lock lock(mutex);
    require(condition.wait_for(lock, std::chrono::seconds(30), [&] { return entered; }),
            "original CUDA Queue did not enter its native gate");
  }
  void release() noexcept {
    { std::lock_guard lock(mutex); open = true; }
    condition.notify_all();
  }
  ~NativeGate() { release(); }
};

// This guard dies before the gate, Session and Model on every exit path.
// The callback executes no CUDA call; the host joins its original work here.
struct ReleaseAndDrain final {
  NativeGate &gate;
  q::Model &model;
  ~ReleaseAndDrain() {
    gate.release();
    model.context.drain().IgnoreError();
  }
};

std::vector<std::byte> sample(const c::ReadLease &lease) {
  const auto bytes = (std::min)(lease.size(), std::size_t{64});
  std::vector<std::byte> result(bytes);
  auto view = q::take(lease.view());
  q::check(q::take(view.subview(0, bytes)).read(result));
  return result;
}

// Actual immutable guards, including their bounded views. This probe inspects
// internal permissions to verify retirement; ordinary consumers use the frame.
std::vector<std::vector<std::byte>> committed_pages(const q::cache::Snapshot &head) {
  std::vector<std::vector<std::byte>> result;
  const auto append = [&](const c::PagedArenaRead &frame) {
    for (const auto &lease : c::detail::PagedArenaAccess::pages(frame)) {
      auto &bytes = result.emplace_back(lease.size());
      q::check(q::take(lease.view()).read(bytes));
    }
  };
  for (std::size_t i = 0; i < head.keys.size(); ++i) { append(head.keys[i]); append(head.values[i]); }
  return result;
}

std::vector<std::vector<std::byte>> committed_recurrent(const q::cache::Snapshot &head) {
  std::vector<std::vector<std::byte>> result;
  for (const auto &state : head.state)
    for (const auto *lease : {&state.history, &state.recurrent}) if (lease->valid()) {
      auto &bytes = result.emplace_back(lease->size());
      q::check(q::take(lease->view()).read(bytes));
    }
  return result;
}

std::size_t head_lease_bytes(const q::cache::Snapshot &head, const q::Model &model) {
  std::size_t bytes = 0;
  for (const auto &state : head.state) {
    bytes = q::cache::add(bytes, state.history.size());
    bytes = q::cache::add(bytes, state.recurrent.size());
  }
  for (std::size_t i = 0; i < head.keys.size(); ++i) {
    bytes = q::cache::add(bytes, q::cache::multiply(head.keys[i].page_count(),
                                                model.page_inventory.keys[i].page_bytes()));
    bytes = q::cache::add(bytes, q::cache::multiply(head.values[i].page_count(),
                                                model.page_inventory.values[i].page_bytes()));
  }
  return bytes;
}

void run(const std::filesystem::path &inputs, const std::filesystem::path &tape_path) {
  const auto prompt = q::read_ids(inputs / "prompt.ids");
  const auto tape = q::read_ids(tape_path);
  require(prompt.size() == 128 && tape.size() >= 2, "probe needs original P128 and at least2decode inputs");
  for (const auto id : prompt) require(id >= 0 && id < q::vocabulary, "prompt token outside vocabulary");
  for (std::size_t i = 0; i < 2; ++i)
    require(tape[i] >= 0 && tape[i] < q::vocabulary, "decode token outside vocabulary");

  constexpr std::size_t capacity = 256;
  const auto plan = q::cache::plan(capacity, 1, prompt.size(),
                                  q::recurrent_bytes(q::state_schema_for(capacity)));
  q::Model model(inputs / "weights.tsv", capacity, plan);
  const std::array<std::size_t, 3> calls{128, 1, 1};
  model.prepare_family(calls);
  model.plan_execution(calls);
  cb::SessionCache directory({1, (std::numeric_limits<std::size_t>::max)()});
  auto session = model.create_session(calls);
  auto admission = directory.admit(0, 0, [](std::size_t) { return false; });
  require(admission.accepted(), "initial owner was not admitted");
  auto pin = directory.pin(0);
  require(static_cast<bool>(pin), "initial owner could not pin");
  (void)model.evaluate(*session, prompt, "retirement_prefill");
  (void)model.evaluate(*session, std::span(&tape[0], 1), "retirement_decode1");
  auto old_prefix = session->head;
  require(old_prefix && old_prefix->length == 129, "committed prefix is not P128+D1");
  const auto old_conv = sample(old_prefix->state[0].history);
  const auto old_gdn = sample(old_prefix->state[0].recurrent);
  const auto old_kv = committed_pages(*old_prefix);
  const auto old_recurrent = committed_recurrent(*old_prefix);
  require(old_recurrent.size() == 36, "probe did not retain all36conv/GDN state resources");
  const auto old_pages = old_prefix->pages.size();
  const auto retained_logical_bytes = head_lease_bytes(*old_prefix, model);

  // These idle logical owners alias one committed version; they allocate no
  // additional snapshot. Only the original active owner is in the directory.
  const std::array<std::size_t, 1> resume{1};
  auto idle = model.create_session(resume, old_prefix);
  auto waiting = model.create_session(resume, old_prefix);

  // All recording/materialization happens before placing the native blocker.
  const auto borrowed_parity = model.execution_parity;
  model.prepare_evaluation(*session, std::span(&tape[1], 1));
  require(session->pending && session->pending == model.active_step.get() &&
          session->pending->members.size() == 1 && session->pending->members[0].session == session &&
          session->pending->members[0].next && session->pending->members[0].base == old_prefix,
          "prepared candidate lost its original Model episode/base");
  auto *const shared_phase = session->pending->phase;
  auto *const shared_run = session->pending->run;
  require(shared_phase && shared_run && shared_run->valid() &&
          borrowed_parity < shared_phase->slots.size() &&
          shared_run == &shared_phase->slots[borrowed_parity],
          "prepared candidate did not borrow an actual Model execution slot");
  q::check(idle->stop());
  require(q::take(idle->try_retire()), "idle logical Session did not retire");
  idle.reset();
  require(session->pending->phase == shared_phase && session->pending->run == shared_run &&
          shared_run->valid() && model.carrier_borrowed && model.execution_parity == borrowed_parity,
          "stopping an idle Session disturbed another Session's shared execution loan");
  std::weak_ptr<const q::cache::Snapshot> candidate = session->pending->members[0].next;
  const auto *candidate_identity = session->pending->members[0].next.get();
  const auto dirty_page = session->pending->members[0].next->pages.back().page();
  require(dirty_page == old_prefix->pages.back().page(),
          "probe did not enter actual same-page exclusive suffix continuation");
  require(model.snapshot_versions.live == 2 && model.carrier_borrowed,
          "prepared N+1candidate is not actually retained or admitted serially");
  const auto pending_bytes = q::take(model.cache_budget.usage(model.memory.ref())).live_bytes;

  NativeGate gate;
  ReleaseAndDrain cleanup{gate, model};
  auto blocked = q::take(cu::submit(model.queue, [&](cudaStream_t stream) noexcept {
    return cudaLaunchHostFunc(stream, &NativeGate::wait, &gate);
  }));
  gate.wait_until_entered();
  model.submit_evaluation(*session);
  require(session->head == old_prefix && session->length() == 129,
          "submission prematurely published candidate state");
  std::size_t rejected_prepares = 0;
  const auto expect_borrow_busy = [&](const char *stage) {
    bool rejected = false;
    try { model.prepare_evaluation(*waiting, std::span(&tape[1], 1)); }
    catch (const std::exception &error) {
      rejected = true;
      std::cerr << "shared_execution_prepare_rejected stage=" << stage
                << " reason=" << error.what() << '\n';
    }
    require(rejected && !waiting->pending && !waiting->failed && !waiting->stopping &&
            waiting->head == old_prefix && model.execution_parity == borrowed_parity &&
            session->pending && session->pending == model.active_step.get() &&
            session->pending->phase == shared_phase && session->pending->run == shared_run &&
            model.carrier_borrowed,
            "another Session acquired or changed a native-pending shared execution loan");
    ++rejected_prepares;
  };
  expect_borrow_busy("native_pending");
  require(directory.begin_retire(0), "owner could not enter retiring state");
  require(!directory.contains(0) && directory.retiring(0) && !directory.pin(0),
          "retiring owner remained visible or pinnable");
  pin.reset();
  q::check(session->stop()); // Unimplemented cancellation is not GPU preemption.
  expect_borrow_busy("stopped_native_pending");
  std::size_t collector_calls = 0;
  const auto collect = [&] {
    return directory.collect_retired(0, [&](std::size_t owner) {
      require(owner == 0 && session, "collector lost the actual Session owner");
      ++collector_calls;
      const bool retired = q::take(session->try_retire());
      if (!retired) return false;
      require(!session->pending && !model.active_step,
              "retired Model episode left its borrowed Session pending link alive");
      session.reset();
      return true;
    });
  };
  require(!collect(), "collect reclaimed a native-blocked owner");
  const bool dropped_public_completion = session->pending->completion.valid();
  // One externally serialized owner abandons the public observation. The
  // original Graph/native reaper must retain all actual resource uses.
  session->pending->completion = {};
  expect_borrow_busy("dropped_completion_native_pending");
  require(!collect(), "dropping public Completion reclaimed native-blocked work");
  require(directory.retained_sessions() == 1 && !candidate.expired() &&
          session->pending && session->pending->members[0].next.get() == candidate_identity &&
          session->head == old_prefix && model.snapshot_versions.live == 2 &&
          model.carrier_borrowed,
          "pending retirement released candidate, visible head or finite version charge");
  require(q::take(model.cache_budget.usage(model.memory.ref())).live_bytes == pending_bytes,
          "blocked owner returned managed bytes before native retirement");
  const auto same_id = directory.admit(0, 0, [](std::size_t) { return true; });
  const auto other_id = directory.admit(1, 0, [](std::size_t) { return true; });
  require(same_id.status == cb::CacheAdmissionStatus::kRetirementUnproven &&
          other_id.status == cb::CacheAdmissionStatus::kRetirementUnproven,
          "resident limit1 readmitted a still-retiring owner or another owner");
  auto forbidden = model.page_inventory.keys[0].acquire(dirty_page);
  require(!forbidden && forbidden.error().IsUnavailable(),
          "pending dirty page was writable before real retirement");

  gate.release();
  q::check(blocked.wait());
  const auto deadline = q::Clock::now() + std::chrono::seconds(30);
  while (!collect()) {
    require(q::Clock::now() < deadline, "native retirement did not become collectible");
    std::this_thread::yield();
  }
  require(!session && !directory.retiring(0) && directory.retained_sessions() == 0 &&
          directory.retained_bytes() == 0 && candidate.expired() &&
          model.snapshot_versions.live == 1 && !model.carrier_borrowed && !model.active_step &&
          model.execution_parity == borrowed_parity && !shared_run->valid(),
          "actual retirement did not release the candidate/owner");
  require(old_prefix->length == 129 && old_prefix->pages.size() == old_pages &&
          sample(old_prefix->state[0].history) == old_conv &&
          sample(old_prefix->state[0].recurrent) == old_gdn &&
          committed_pages(*old_prefix) == old_kv && committed_recurrent(*old_prefix) == old_recurrent,
          "cancellation changed the retained committed prefix");
  for (std::size_t i = 0; i < model.page_inventory.keys.size(); ++i) {
    auto key = model.page_inventory.keys[i].acquire(dirty_page);
    auto value = model.page_inventory.values[i].acquire(dirty_page);
    require(!key && key.error().IsUnavailable() && !value && value.error().IsUnavailable(),
            "retained old prefix lost its original page after suffix retirement");
  }
  admission = directory.admit(1, 0, [](std::size_t) { return false; });
  require(admission.accepted(), "retired directory slot was not reusable");
  auto next_pin = directory.pin(1);
  require(static_cast<bool>(next_pin), "replacement owner could not pin");
  auto recovered = std::move(waiting);
  std::weak_ptr<const q::cache::Snapshot> retired_prefix = old_prefix;
  old_prefix.reset(); // N1 keeps only the new Session's original committed head.
  model.prepare_evaluation(*recovered, std::span(&tape[1], 1));
  require(recovered->pending && recovered->pending->phase == shared_phase &&
          recovered->pending->run == shared_run && shared_run->valid(),
          "the waiting Session did not rebuild the retired aborted slot in the original Model bundle");
  model.submit_evaluation(*recovered);
  const auto impossible_trace = inputs / "weights.tsv";
  require(std::filesystem::is_regular_file(impossible_trace), "probe trace rejection needs the original manifest file");
  bool post_commit_trace_rejected = false;
  try { (void)model.finish_evaluation(*recovered, "retirement_recovered", impossible_trace, false); }
  catch (const std::filesystem::filesystem_error &error) {
    post_commit_trace_rejected = true;
    std::cerr << "shared_execution_post_commit_trace_rejected reason=" << error.what() << '\n';
  }
  require(post_commit_trace_rejected && recovered->length() == 130 && !recovered->pending &&
          !recovered->failed && !model.carrier_borrowed && !model.active_step && retired_prefix.expired() &&
          model.snapshot_versions.live == 1,
          "post-commit diagnostic failure rolled back the head or retained its execution loan");

  // The reported IO failure follows the real head commit. Another logical owner
  // must be able to borrow the same Model carrier without resetting that head.
  auto after_report = model.create_session(resume, recovered->head);
  std::weak_ptr<const q::cache::Snapshot> report_head = recovered->head;
  q::check(recovered->stop());
  require(q::take(recovered->try_retire()), "reported-error Session did not retire its committed head alias");
  recovered.reset();
  const auto after_report_parity = model.execution_parity;
  model.prepare_evaluation(*after_report, std::span(&tape[1], 1));
  require(after_report->pending && after_report->pending->phase == shared_phase &&
          after_report_parity < shared_phase->slots.size() &&
          after_report->pending->run == &shared_phase->slots[after_report_parity],
          "a different Session did not recover the shared carrier at its actual Model parity");
  model.submit_evaluation(*after_report);
  (void)model.finish_evaluation(*after_report, "retirement_after_report_error");
  recovered = std::move(after_report);
  require(recovered->length() == 131 && !recovered->pending && !model.carrier_borrowed && !model.active_step &&
          report_head.expired() && model.snapshot_versions.live == 1,
          "a different Session could not continue after a committed diagnostic failure");
  require(retired_prefix.expired() &&
          model.snapshot_versions.live == 1,
          "retained old prefix was not a usable independent continuation");
  next_pin.reset();
  q::check(recovered->drain());
  recovered.reset();
  for (std::size_t i = 0; i < model.page_inventory.keys.size(); ++i) {
    auto key = q::take(model.page_inventory.keys[i].acquire(dirty_page));
    auto value = q::take(model.page_inventory.values[i].acquire(dirty_page));
    require(key.initialized_rows() == 0 && value.initialized_rows() == 0,
            "retired original page could not be reclaimed after all old readers released");
  }
  std::cout << "{\"status\":\"PASS\",\"capacity\":256,\"resident_limit\":1,"
            << "\"old_prefix_tokens\":129,\"cancelled_candidate_tokens\":130,"
            << "\"directory_reported_bytes\":0,\"old_prefix_logical_lease_bytes\":" << retained_logical_bytes
            << ",\"managed_bytes_while_native_pending\":" << pending_bytes
            << ",\"managed_backing_bytes\":" << model.cache_plan.backing_bytes
            << ",\"collector_calls\":" << collector_calls
            << ",\"dropped_live_public_completion\":" << (dropped_public_completion ? "true" : "false")
            << ",\"same_page_exclusive_suffix\":true,\"old_kv_guards_and_bytes_unchanged\":true"
            << ",\"idle_stop_preserved_other_execution_loan\":true"
            << ",\"busy_prepare_rejections\":" << rejected_prepares
            << ",\"retired_aborted_slot_rebuilt_in_same_model_bundle\":true"
            << ",\"retired_model_episode_detached_all_pending_links\":true"
            << ",\"execution_parity_before_cancel\":" << borrowed_parity
            << ",\"execution_parity_before_report_reuse\":" << after_report_parity
            << ",\"post_commit_trace_error_preserved_head_and_returned_loan\":true"
            << ",\"different_session_continued_after_report_error\":true,\"final_tokens\":" << 131
            << ",\"old_recurrent_resources_byte_unchanged\":" << old_recurrent.size()
            << ",\"head_alias_sessions_added_distinct_versions\":0,\"native_error_injected\":false"
            << ",\"cancel_means_native_preemption\":false,\"timing_comparison\":false}\n";
}
} // namespace

int main(int argc, char **argv) {
  try {
    std::filesystem::path inputs, tape;
    for (int i = 1; i < argc; i += 2) {
      if (i + 1 == argc) throw std::runtime_error("probe option lacks its value");
      const std::string_view option(argv[i]);
      if (option == "--inputs") inputs = argv[i + 1];
      else if (option == "--decode-ids") tape = argv[i + 1];
      else throw std::runtime_error("unknown retirement probe option");
    }
    if (inputs.empty() || tape.empty())
      throw std::runtime_error("usage: hyle_qwen35_retirement_probe --inputs DIR --decode-ids IDSFILE");
    run(inputs, tape);
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "Qwen retirement probe: " << error.what() << '\n';
    return 1;
  }
}
