"""Publish actual MTP retirement/reference/peer receipts, without copying model caches."""
from pathlib import Path
import difflib,hashlib,json,subprocess,zipfile
U=Path(__file__).resolve().parent;R=U.parents[1];O=R/'docs/evidence/correctness';NAME='qwen-mtp-retirement-2026-10-22'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def identity(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=h.hexdigest())

changed=['tools/qwen35_text/main.cc','tools/qwen35_text/retirement_probe.cc','tools/qwen35_text/README.md','docs/developer/current-work.md','docs/developer/performance/decode.md']
context=['tools/qwen35_text/session_state.h','tools/qwen35_text/mtp_graph.h','tools/qwen35_text/reference.py']
frozen=[]
for name in changed+context:
 p=R/name;snap=U/'current'/name;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(p.read_bytes())
 record=dict(source=identity(p),snapshot=identity(snap),modified_in_this_batch=name in changed);before=U/'before'/name
 if before.exists():
  diff=U/'product-diffs'/(name.replace('/','--')+'.diff');diff.parent.mkdir(exist_ok=True)
  diff.write_text(''.join(difflib.unified_diff(before.read_text(encoding='utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='before/'+name,tofile=name)),encoding='utf-8')
  result=subprocess.run(['git','diff','--no-index','--check',str(before),str(p)],capture_output=True,text=True,encoding='utf-8',errors='replace')
  assert result.returncode in(0,1)and not result.stdout.strip()and not result.stderr.strip(),(name,result.stdout,result.stderr)
  record.update(before=identity(before),diff=identity(diff),whitespace_diagnostics=[])
 frozen.append(record)
save(U/'product-freeze.json',dict(files=frozen))

reference=read(U/'reference/output-run1/report.json')
runtime_sources=[]
for key in ('implementation','config'):
 record=reference[key];p=Path(record['path']);assert identity(p)==record
 snap=U/'reference/runtime-source'/(key+p.suffix);snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(p.read_bytes())
 runtime_sources.append(dict(original=record,snapshot=identity(snap)))
save(U/'reference/runtime-source.json',dict(files=runtime_sources))

runs={}
for name,prefix in [('qwen-run1','run'),('retirement-run1','run'),('reference/run1','reference'),('peer/p15-two-round2','run'),('peer/p23-eos2','run')]:
 out=U/name;terminal=read(out/(prefix+'.result.json'));assert terminal['exit']==0 and terminal['terminal']is True
 runs[name]=dict(terminal=identity(out/(prefix+'.result.json')),stdout=identity(out/(prefix+'.stdout.log')),stderr=identity(out/(prefix+'.stderr.log')),command=terminal['command'])
retired=read(U/'retirement-run1/run.stdout.log');assert retired['status']=='PASS'and retired['bound_append_banks']==14 and retired['old_recurrent_resources_byte_unchanged']==36
assert retired['managed_bytes_while_native_pending']==retired['managed_backing_bytes']==80240691
assert retired['host_policy_error_injected']and not retired['native_error_injected']and not retired['selector_failure_published_head']
assert reference['candidate_values_used']is False and reference['generated_ids']==[198,248045,74455,271]
reports={p.name:read(p)for p in sorted((U/'review').glob('*.json'))if p.name not in ('protocol-reference-comparison-freeze.json',)}
summary=dict(status='Finite real-CUDA MTP cancellation/retirement, independent CPU protocol and fixed native MTP peer exercised; full goal remains active',
 changed_sources=changed,product_freeze=identity(U/'product-freeze.json'),runs=runs,retirement=retired,
 reference_report=reference,reports=reports,
 source_and_execution_scope=['Original shared Graph/Queue/Completion and fourteen real target/draft append permissions; no second Hyle executor or native kernel introduced.',
 'Native Queue actually blocked during stop/close/public Completion abandonment; no device readback attempted while blocked. Actual retirement precedes old-data comparisons and same-slot retries.',
 'Host selector throws after successful original terminal and before any append take/publication; old complete head remains and all fourteen dirty authorities are recovered.',
 'Independent CPU reference maps original335 once and derives all target/draft/hidden inputs itself. Natural finite decisions and extents match, but float outputs differ and no quality tolerance is invented.',
 'Fixed llama.cpp peer uses one335 model and two native contexts, target RS1/draftRS0 and explicit per-sequence GPU-sampling capacities2/1. Both P15 two-round and P23 EOS receipts are actual exit0.',
 'Peer effective contexts are256 for requested64. Native full-block draft prefill/catchup, host F32 carry and activation math differ from Hyle KV-only/device BF16 path; these differences are disclosed before comparison.',
 'No full performance window, no hot-replay improvement, no broad acceptance-rate/coding-quality conclusion, no new ordinary ninety-vector run in this batch. Previous same-B90 result remains in prior evidence.'],
 failures_preserved=['peer/p15-two-round exit1: original shim left public n_outputs_max_per_seq at default1; original fixed native backend supports multirow greedy. Revision2 sets target2/draft1; no CPU fallback or native library rebuild.'],
 persistent_model_cache=read(U/'peer-conversion1/artifact.json'),
 actual_artifact_checks=read(U/'review/peer-artifact.json'),
 build_scope=dict(fresh_Hyle_library_TUs=0,Hyle_consumer_TUs=['main.cc','retirement_probe.cc'],peer_TUs=1,peer_attempts=2,SDK_builds=0,NVCC_builds=0,full_configures=0),
 remaining=['Longer matched natural-generation MTP/no-MTP numerical/output assessment and complete prefill/decode/VRAM/overall comparison.',
 'Actual hot capture reuse and preparation costs under that workload; do not infer speed from capture count.',
 'Multi-session MTP entry, other systems/native backends, selected-model/quant coverage, image chain and broad architecture scope.'],
 limitations=['Finite C64/N2/R1 cancellation plus host-policy failure, not injected GPU device-error coverage; ordinary retirement mode was not rerun.',
 'CPU and native-peer outputs only prove the finite tested token prefixes/roles. They do not establish general model quality or multi-session/MTP service throughput.',
 'Model cache is retained once outside this batch; no checkpoint/GGUF/library binary is duplicated into this archive.'])
save(U/'actual-summary.json',summary)
excluded={'.exe','.dll','.obj','.map','.lib','.exp','.pdb','.pyc'}
files=sorted(p for p in U.rglob('*')if p.is_file()and p.suffix.lower()not in excluded and not any(x in('tmp','__pycache__')for x in p.relative_to(U).parts)and p.name not in('published.json','cleanup-plan.json','cleanup-result.json','cleanup_script.ps1'))
archive=O/(NAME+'.data.zip');assert not archive.exists();entries=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:
  e=identity(p);e['entry']=p.relative_to(R).as_posix();z.write(p,e['entry']);entries.append(e)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and z.namelist()==[e['entry']for e in entries]
 for e in entries:
  data=z.read(e['entry']);assert len(data)==e['bytes']and hashlib.sha256(data).hexdigest()==e['sha256']
manifest=O/(NAME+'.json');assert not manifest.exists()
save(manifest,dict(**summary,archives=[identity(archive)],archive_files=entries,archive_verified=dict(CRC=True,all_entry_SHA256=True,entries=len(entries),original_bytes=sum(e['bytes']for e in entries)),previous_evidence=['docs/evidence/correctness/qwen-mtp-round-2026-10-22.json']))
published=dict(manifest=identity(manifest),archives=[identity(archive)]);save(U/'published.json',published)
print(json.dumps(dict(**published,files=len(entries),raw_bytes=sum(e['bytes']for e in entries)),indent=2))
