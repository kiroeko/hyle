"""Independent, finite CPU Qwen3.5-2B target + K1 MTP protocol reference.

Only original checkpoint weights, config and prompt IDs are inputs. In particular
this program has no argument for candidate hidden tensors, caches or decisions.
Prepared for a separate root-owned execution; no accuracy threshold is assigned.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import struct
import time
import types

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                  HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false")

EXPECTED_IMPL_SHA = "0e7410f5251e5c324a5628c5340ee3551f7a6a505ce398569fcc3b5f3ac07f7a"
EXPECTED_CONFIG_SHA = "ed1c1723241f23f7f4e23430759cbd7dcfb4103cbdfe052bfe7626b57c2615b4"
EXPECTED_HEADER_SHA = "ccba2c1f645fe59268f89ee7ea552e02ce6bf0c8a087bf332fb0e3bd99bfee9d"
EMBEDDING = "model.language_model.embed_tokens.weight"
HIDDEN, VOCAB, HEADS, KV_HEADS, DIM = 2048, 248320, 8, 2, 256
MTP_SHAPES = {
    "mtp.fc.weight": [2048, 4096],
    "mtp.layers.0.input_layernorm.weight": [2048],
    "mtp.layers.0.mlp.down_proj.weight": [2048, 6144],
    "mtp.layers.0.mlp.gate_proj.weight": [6144, 2048],
    "mtp.layers.0.mlp.up_proj.weight": [6144, 2048],
    "mtp.layers.0.post_attention_layernorm.weight": [2048],
    "mtp.layers.0.self_attn.k_norm.weight": [256],
    "mtp.layers.0.self_attn.k_proj.weight": [512, 2048],
    "mtp.layers.0.self_attn.o_proj.weight": [2048, 2048],
    "mtp.layers.0.self_attn.q_norm.weight": [256],
    "mtp.layers.0.self_attn.q_proj.weight": [4096, 2048],
    "mtp.layers.0.self_attn.v_proj.weight": [512, 2048],
    "mtp.norm.weight": [2048],
    "mtp.pre_fc_norm_embedding.weight": [2048],
    "mtp.pre_fc_norm_hidden.weight": [2048],
}


def identity(path: Path) -> dict:
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def selection(pending: int, draft: int | None, target_ids: list[int], quota: int,
              eos: set[int]) -> dict:
    """Greedy K1 protocol only; no tensor/provider implementation is involved."""
    if pending in eos or quota < 1 or not 1 <= len(target_ids) <= 2:
        raise ValueError("stopped/quota-zero sessions must not execute a round")
    agreed = draft is not None and draft == target_ids[0]
    accepted = bool(agreed and len(target_ids) == 2 and quota >= 2 and target_ids[0] not in eos)
    committed = 2 if accepted else 1
    emitted = target_ids[:committed]
    return dict(agreed=agreed, accepted_draft=accepted, committed_target_rows=committed,
                emitted=emitted, next_id=emitted[-1], stopped=emitted[-1] in eos)


def policy_checks() -> None:
    eos = {90, 91}
    assert selection(1, 2, [2, 3], 2, eos)["committed_target_rows"] == 2
    assert selection(1, 7, [2, 3], 2, eos)["committed_target_rows"] == 1
    assert selection(1, 2, [2, 3], 1, eos)["emitted"] == [2]
    assert selection(1, 90, [90, 3], 2, eos)["emitted"] == [90]
    assert selection(1, 2, [2, 90], 2, eos)["stopped"]
    assert selection(1, None, [2], 1, eos)["committed_target_rows"] == 1


def recurrent_with_boundary(self, hidden_states, cache_params=None,
                            cache_position=None, attention_mask=None):
    """Existing reference.py recurrence, retaining row0 for target T2 commit.

    Each one-row call uses the pinned Transformers explicit recurrent formula.
    State updates are out of place: neither the old cache nor row0's checkpoint
    is modified by row1. No recomputed target forward is needed after rejection.
    """
    import torch
    import torch.nn.functional as f
    from transformers.models.qwen3_5 import modeling_qwen3_5 as impl
    del cache_position
    hidden_states = impl.apply_mask_to_padding_states(hidden_states, attention_mask)
    batch, tokens, _ = hidden_states.shape
    projected = self.in_proj_qkv(hidden_states).transpose(1, 2)
    old_conv = None if cache_params is None else cache_params.conv_states[self.layer_idx]
    state = None if cache_params is None else cache_params.recurrent_states[self.layer_idx]
    if old_conv is None or old_conv.numel() == 0:
        prefix = projected.new_zeros(batch, projected.shape[1], self.conv_kernel_size - 1)
    else:
        prefix = old_conv[:, :, -(self.conv_kernel_size - 1):]
    samples = torch.cat((prefix, projected), dim=-1)
    convolved = f.conv1d(samples, self.conv1d.weight, self.conv1d.bias,
                        groups=self.conv1d.groups)
    activated = f.silu(convolved).transpose(1, 2)
    q, k, v = torch.split(activated, [self.key_dim, self.key_dim, self.value_dim], dim=-1)
    q = q.reshape(batch, tokens, -1, self.head_k_dim)
    k = k.reshape(batch, tokens, -1, self.head_k_dim)
    v = v.reshape(batch, tokens, -1, self.head_v_dim)
    if self.num_v_heads != self.num_k_heads:
        q = q.repeat_interleave(self.num_v_heads // self.num_k_heads, dim=2)
        k = k.repeat_interleave(self.num_v_heads // self.num_k_heads, dim=2)
    beta = self.in_proj_b(hidden_states).sigmoid()
    decay = -self.A_log.float().exp() * f.softplus(self.in_proj_a(hidden_states).float() + self.dt_bias)
    if state is not None and state.numel() == 0:
        state = None
    rows = []
    for row in range(tokens):
        value, state = impl.torch_recurrent_gated_delta_rule(
            q[:, row:row + 1], k[:, row:row + 1], v[:, row:row + 1],
            decay[:, row:row + 1], beta[:, row:row + 1], initial_state=state,
            output_final_state=True, use_qk_l2norm_in_kernel=True)
        rows.append(value)
        if row == 0 and getattr(self, "_capture_row0", False):
            # Three prior projected rows + this row form the native four-row
            # reference rolling state. Next forward reads only the last three.
            self._row0_state = (samples[:, :, :self.conv_kernel_size].contiguous(), state)
    if cache_params is not None:
        cache_params.conv_states[self.layer_idx] = samples[:, :, -self.conv_kernel_size:].contiguous()
        cache_params.recurrent_states[self.layer_idx] = state
    combined = torch.cat(rows, dim=1)
    z = self.in_proj_z(hidden_states).reshape(-1, self.head_v_dim)
    combined = self.norm(combined.reshape(-1, self.head_v_dim), z)
    return self.out_proj(combined.reshape(batch, tokens, -1))


class Target:
    def __init__(self, model, config, impl, torch):
        self.model, self.config, self.impl, self.torch = model, config, impl, torch
        for layer in model.model.layers:
            if hasattr(layer, "linear_attn"):
                layer.linear_attn.forward = types.MethodType(recurrent_with_boundary, layer.linear_attn)

    def copy_cache(self, cache):
        result = self.impl.Qwen3_5DynamicCache(self.config)
        if cache is not None:
            # List ownership is separate. Pinned update() cats KV; our recurrent
            # function creates new tensors, so sharing old readonly tensors is safe.
            for name in ("conv_states", "recurrent_states", "key_cache", "value_cache"):
                setattr(result, name, list(getattr(cache, name)))
        return result

    def evaluate(self, ids, base_cache, need_row0=False, last_logits_only=False):
        torch = self.torch
        old_length = base_cache.get_seq_length() if base_cache is not None else 0
        if need_row0 and len(ids) != 2:
            raise ValueError("only target T2 needs a separate row0 cache")
        work = self.copy_cache(base_cache)
        for layer in self.model.model.layers:
            if hasattr(layer, "linear_attn"):
                layer.linear_attn._capture_row0 = need_row0
                layer.linear_attn._row0_state = None
        result = self.model.model(input_ids=torch.tensor([ids], dtype=torch.int64),
                                  past_key_values=work, use_cache=True)
        hidden = result.last_hidden_state[0]  # Actual POST-finalnorm rows.
        logits = self.model.lm_head(hidden[-1:] if last_logits_only else hidden).float()
        if not bool(torch.isfinite(hidden).all()) or not bool(torch.isfinite(logits).all()):
            raise ValueError("nonfinite independent target result")
        row0 = None
        if need_row0:
            row0 = self.copy_cache(work)
            for i, kind in enumerate(self.config.layer_types):
                if kind == "full_attention":
                    row0.key_cache[i] = work.key_cache[i][:, :, :old_length + 1, :]
                    row0.value_cache[i] = work.value_cache[i][:, :, :old_length + 1, :]
                else:
                    layer = self.model.model.layers[i].linear_attn
                    row0.conv_states[i], row0.recurrent_states[i] = layer._row0_state
                    layer._row0_state = None
        return dict(hidden=hidden, logits=logits, ids=logits.argmax(-1).tolist(),
                    cache=work, row0_cache=row0)


class Draft:
    """Generalized frozen G/mtp_reference.py math, with persistent own KV."""
    def __init__(self, weights, embedding, torch, functional):
        self.weights, self.embedding, self.torch, self.f = weights, embedding, torch, functional
        self.frequencies = torch.reciprocal(torch.pow(torch.tensor(10000000.0),
                                                     torch.arange(32, dtype=torch.float32) / 32.0))

    def norm(self, x, name):
        wide = x.float()
        inverse = self.torch.rsqrt((wide * wide).mean(-1, keepdim=True) + 1e-6)
        return ((wide * inverse) * (self.weights[name].float() + 1.0)).to(self.torch.bfloat16)

    def linear(self, x, name):
        return self.f.linear(x, self.weights[name]).to(self.torch.bfloat16)

    def evaluate(self, tokens, hidden, old_kv, head=True):
        torch = self.torch
        prior = 0 if old_kv is None else old_kv[0].shape[0]
        n = len(tokens)
        if n < 1 or list(hidden.shape) != [n, HIDDEN]:
            raise ValueError("draft requires one shifted target-hidden row per token")
        positions = torch.arange(prior, prior + n, dtype=torch.float32)
        embedded = self.embedding.index_select(0, torch.tensor(tokens, dtype=torch.int64))
        e = self.norm(embedded, "mtp.pre_fc_norm_embedding.weight")
        h = self.norm(hidden, "mtp.pre_fc_norm_hidden.weight")
        projected = self.linear(torch.cat((e, h), dim=-1), "mtp.fc.weight")
        x = self.norm(projected, "mtp.layers.0.input_layernorm.weight")
        k = self.linear(x, "mtp.layers.0.self_attn.k_proj.weight").reshape(n, KV_HEADS, DIM)
        k = self.norm(k, "mtp.layers.0.self_attn.k_norm.weight")
        v = self.linear(x, "mtp.layers.0.self_attn.v_proj.weight").reshape(n, KV_HEADS, DIM)

        def rope(value):
            wide = value.float()
            angle = positions[:, None, None] * self.frequencies[None, None, :]
            c, s = torch.cos(angle), torch.sin(angle)
            a, b = wide[..., :32], wide[..., 32:64]
            return torch.cat((a * c - b * s, b * c + a * s, wide[..., 64:]), -1).to(torch.bfloat16)

        k = rope(k)
        keys = k if old_kv is None else torch.cat((old_kv[0], k), 0)
        values = v if old_kv is None else torch.cat((old_kv[1], v), 0)
        # Prefill and quota/capacity-one fallback only need draft K/V. Avoid the
        # complete MTP attention/MLP/head on rows whose logits cannot be consumed.
        if not head:
            return dict(kv=(keys, values), ids=None, hidden=None, logits=None)
        q_full = self.linear(x, "mtp.layers.0.self_attn.q_proj.weight").reshape(n, HEADS, 2 * DIM)
        q = self.norm(q_full[..., :DIM], "mtp.layers.0.self_attn.q_norm.weight")
        q, gate = rope(q), q_full[..., DIM:]
        all_k = keys.float().repeat_interleave(HEADS // KV_HEADS, 1).permute(1, 0, 2)
        all_v = values.float().repeat_interleave(HEADS // KV_HEADS, 1).permute(1, 0, 2)
        scores = torch.matmul(q.float().permute(1, 0, 2), all_k.transpose(1, 2)) * 0.0625
        future = torch.arange(prior + n)[None, :] > positions.to(torch.int64)[:, None]
        attention = torch.matmul(torch.softmax(scores.masked_fill(future[None], float("-inf")), -1), all_v)
        attention = attention.permute(1, 0, 2).to(torch.bfloat16)
        sigmoid = torch.sigmoid(gate.float()).to(torch.bfloat16)
        gated = (attention * sigmoid).to(torch.bfloat16)
        attended = self.linear(gated.reshape(n, HIDDEN), "mtp.layers.0.self_attn.o_proj.weight")
        residual = (projected + attended).to(torch.bfloat16)
        x = self.norm(residual, "mtp.layers.0.post_attention_layernorm.weight")
        ff_gate = self.linear(x, "mtp.layers.0.mlp.gate_proj.weight")
        activated = self.f.silu(ff_gate.float()).to(torch.bfloat16)
        up = self.linear(x, "mtp.layers.0.mlp.up_proj.weight")
        down = self.linear((activated * up).to(torch.bfloat16), "mtp.layers.0.mlp.down_proj.weight")
        final = self.norm((residual + down).to(torch.bfloat16), "mtp.norm.weight")
        # K1 selects only the final draft row. A lag1 catchup row does not emit.
        logits = self.f.linear(final[-1:], self.embedding).to(torch.bfloat16).float()
        if not bool(torch.isfinite(logits).all()):
            raise ValueError("nonfinite independent MTP logits")
        return dict(kv=(keys, values), ids=logits.argmax(-1).tolist(), hidden=final, logits=logits)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--prompt-ids", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prompt-limit", type=int, default=15)
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--new-tokens", type=int, default=5,
                        help="total returned IDs including the prefill next ID")
    parser.add_argument("--capacity", type=int, default=64)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--eos", type=int, nargs="+", default=[248044, 248046])
    args = parser.parse_args()
    policy_checks()
    if args.output.exists():
        raise ValueError("reference output must be a new directory")
    if not (1 <= args.rounds <= 8 and 1 <= args.prompt_limit <= 32 and
            1 <= args.new_tokens <= 17 and 1 <= args.threads <= 8 and 1 <= args.capacity <= 256):
        raise ValueError("finite CPU reference requires rounds1..8/prompt1..32/output1..17/capacity1..256")
    prompt = [int(x) for x in args.prompt_ids.read_text(encoding="utf-8").split()][:args.prompt_limit]
    if not prompt or len(prompt) > args.capacity or any(not 0 <= x < VOCAB for x in prompt):
        raise ValueError("invalid finite prompt")
    if any(not 0 <= x < VOCAB for x in args.eos):
        raise ValueError("invalid EOS ID")
    model_dir = args.model.resolve()
    config_path = model_dir / "config.json"
    config_bytes = config_path.read_bytes()
    if hashlib.sha256(config_bytes).hexdigest() != EXPECTED_CONFIG_SHA:
        raise ValueError("fixed checkpoint config identity differs")
    shard = model_dir / "model.safetensors-00001-of-00001.safetensors"
    with shard.open("rb") as stream:
        count_raw = stream.read(8)
        if len(count_raw) != 8:
            raise ValueError("invalid safetensors extent")
        extent = struct.unpack("<Q", count_raw)[0]
        if extent > shard.stat().st_size - 8:
            raise ValueError("invalid safetensors header extent")
        header_raw = stream.read(extent)
    if hashlib.sha256(header_raw).hexdigest() != EXPECTED_HEADER_SHA:
        raise ValueError("fixed checkpoint tensor header differs")
    header = json.loads(header_raw)
    for name, shape in MTP_SHAPES.items():
        if header[name]["dtype"] != "BF16" or header[name]["shape"] != shape:
            raise ValueError("MTP geometry differs: " + name)

    # No Torch import or operation occurs during preparation/AST checking.
    import torch
    import torch.nn.functional as functional
    from safetensors import safe_open
    from transformers.models.qwen3_5 import modeling_qwen3_5 as impl
    from transformers.models.qwen3_5.configuration_qwen3_5 import Qwen3_5TextConfig
    if hashlib.sha256(Path(impl.__file__).read_bytes()).hexdigest() != EXPECTED_IMPL_SHA:
        raise ValueError("reference adapter requires its inspected Transformers cache/formula source")
    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    torch.set_default_dtype(torch.float32)
    config = Qwen3_5TextConfig(**json.loads(config_bytes)["text_config"])
    config._attn_implementation = "eager"
    # The installed optional FLA norm constructor otherwise queries a CUDA
    # device even inside meta construction. Select the explicit CPU formula.
    impl.FusedRMSNormGated = None
    with torch.device("meta"):
        model = impl.Qwen3_5ForCausalLM(config)
    model.model.rotary_emb = impl.Qwen3_5TextRotaryEmbedding(config, device="cpu")
    args.output.mkdir(parents=True)
    artifacts = {}

    def dump(name, tensor):
        tensor = tensor.detach().contiguous()
        if tensor.device.type != "cpu":
            raise ValueError("reference left CPU")
        suffix = {torch.bfloat16: "bf16", torch.float32: "f32", torch.int32: "i32"}[tensor.dtype]
        path = args.output / (name + "." + suffix)
        path.write_bytes(tensor.view(torch.uint8).numpy().tobytes())
        artifacts[name] = dict(shape=list(tensor.shape), dtype=str(tensor.dtype),
                               finite=bool(torch.isfinite(tensor).all()), **identity(path))

    def cache_summary(cache):
        rows = cache.get_seq_length()
        entries = []
        for i, kind in enumerate(config.layer_types):
            names = ("key_cache", "value_cache") if kind == "full_attention" else ("conv_states", "recurrent_states")
            for field in names:
                value = getattr(cache, field)[i]
                if value is None or not bool(torch.isfinite(value).all()):
                    raise ValueError("missing/nonfinite independent state")
                entries.append(dict(layer=i, field=field, shape=list(value.shape), dtype=str(value.dtype)))
        return dict(rows=rows, entries=entries)

    started = time.perf_counter()
    with torch.inference_mode(), safe_open(str(shard), framework="pt", device="cpu") as bank:
        # One CPU mapping for 320 text + 15 MTP. assign=True and tied identity
        # avoid another full model bank or embedding allocation/conversion.
        parameters = {name.replace("model.language_model.", "model.", 1): bank.get_tensor(name)
                      for name in bank.keys() if name.startswith("model.language_model.")}
        if len(parameters) != 320:
            raise ValueError("fixed text inventory differs")
        parameters["lm_head.weight"] = parameters["model.embed_tokens.weight"]
        model.load_state_dict(parameters, strict=True, assign=True)
        model.lm_head.weight = model.model.embed_tokens.weight
        del parameters
        model.eval()
        if any(p.is_meta or p.device.type != "cpu" for p in model.parameters()):
            raise ValueError("target weights were not bound directly on CPU")
        target = Target(model, config, impl, torch)
        draft = Draft({name: bank.get_tensor(name) for name in MTP_SHAPES},
                      model.model.embed_tokens.weight, torch, functional)
        prefill = target.evaluate(prompt, None, last_logits_only=True)
        hidden = prefill["hidden"]
        shifted = torch.cat((torch.zeros_like(hidden[:1]), hidden[:-1]), 0)
        draft_state = draft.evaluate(prompt, shifted, None, head=False)["kv"]
        target_state = prefill["cache"]
        length, lag = len(prompt), 0
        carry, prior_hidden, catchup = hidden[-1:].clone(), None, None
        next_id = prefill["ids"][-1]
        emitted = [next_id]
        dump("prefill_target_hidden", hidden)
        dump("prefill_target_logits", prefill["logits"])
        dump("prefill_shifted_hidden", shifted)
        events = [dict(name="prefill", target_inputs=prompt, positions=list(range(length)),
                       target_length=length, draft_length=length, lag=0, next_id=next_id,
                       emitted=[next_id], target_query_rows=length, draft_written_rows=length)]
        # Retain only the committed own cache/last two hidden rows, not all old
        # protocol versions. Reference state branching is private CPU ownership.
        del prefill, hidden, shifted
        eos = set(args.eos)
        for ordinal in range(args.rounds):
            quota = args.new_tokens - len(emitted)
            if quota == 0 or next_id in eos or length == args.capacity:
                break
            single = quota == 1 or args.capacity - length == 1
            name = f"round{ordinal}"
            base_length, old_lag, pending = length, lag, next_id
            if draft_state[0].shape[0] != length - lag:
                raise ValueError("draft frontier is not target length minus lag")
            if lag:
                if prior_hidden is None or catchup is None:
                    raise ValueError("lag1 lacks its actual target row0/catchup token")
                draft_tokens = [catchup, pending]
                draft_hidden = torch.cat((prior_hidden, carry), 0)
            else:
                draft_tokens, draft_hidden = [pending], carry
            proposal = draft.evaluate(draft_tokens, draft_hidden, draft_state, head=not single)
            proposal_id = None if single else proposal["ids"][-1]
            target_inputs = [pending] if single else [pending, proposal_id]
            verification = target.evaluate(target_inputs, target_state, need_row0=not single)
            decision = selection(pending, proposal_id, verification["ids"], quota, eos)
            committed = decision["committed_target_rows"]
            target_state = verification["cache"] if committed == len(target_inputs) else verification["row0_cache"]
            draft_state = proposal["kv"]
            length += committed
            lag = committed - 1
            carry = verification["hidden"][committed - 1:committed].clone()
            prior_hidden = verification["hidden"][:1].clone() if lag else None
            catchup = proposal_id if lag else None
            next_id = decision["next_id"]
            emitted.extend(decision["emitted"])
            if target_state.get_seq_length() != length or draft_state[0].shape[0] != length - lag:
                raise ValueError("selected target/draft cache extent mismatch")
            dump(name + "_target_hidden", verification["hidden"])
            dump(name + "_target_logits", verification["logits"])
            dump(name + "_target_ids", torch.tensor(verification["ids"], dtype=torch.int32))
            dump(name + "_carry_hidden", carry)
            dump(name + "_draft_shifted_hidden", draft_hidden)
            if prior_hidden is not None:
                dump(name + "_prior_hidden", prior_hidden)
            if not single:
                dump(name + "_draft_logits", proposal["logits"])
            events.append(dict(name=name, role=("MtpCatchup" if old_lag else "Mtp") + ("Single" if single else "Round"),
                               base_length=base_length, old_draft_frontier=base_length - old_lag,
                               target_inputs=target_inputs, target_positions=list(range(base_length, base_length + len(target_inputs))),
                               draft_inputs=draft_tokens, draft_positions=list(range(base_length - old_lag, base_length + 1)),
                               draft=proposal_id, target_ids=verification["ids"], **decision,
                               target_length=length, draft_length=draft_state[0].shape[0], lag=lag,
                               catchup_token=catchup, target_query_rows=len(target_inputs),
                               draft_written_rows=len(draft_tokens), remaining_output_quota=quota))
            del proposal, verification, draft_hidden
            print(json.dumps(events[-1]), flush=True)
        summary = cache_summary(target_state)
        dump("final_draft_key", draft_state[0])
        dump("final_draft_value", draft_state[1])
        dump("final_carry_hidden", carry)
        if prior_hidden is not None:
            dump("final_prior_hidden", prior_hidden)
        report = dict(status="independent_cpu_protocol_outputs_generated_not_candidate_verdict",
                      script=identity(Path(__file__)), config=identity(config_path),
                      prompt_source=identity(args.prompt_ids), prompt_limit=args.prompt_limit, prompt_ids=prompt,
                      checkpoint=dict(path=str(shard), bytes=shard.stat().st_size,
                                      header_bytes=extent, header_sha256=hashlib.sha256(header_raw).hexdigest(),
                                      full_payload_rehashed=False, full_payload_copied=False),
                      implementation=identity(Path(impl.__file__)),
                      runtime=dict(device="cpu", torch=torch.__version__,
                                   transformers=importlib.metadata.version("transformers"), threads=args.threads),
                      capacity=args.capacity, requested_rounds=args.rounds, output_quota=args.new_tokens,
                      eos_ids=sorted(eos), events=events, generated_ids=emitted,
                      target_cache=summary, target_length=length, draft_length=draft_state[0].shape[0], lag=lag,
                      artifacts=artifacts, elapsed_reference_seconds=time.perf_counter() - started,
                      candidate_values_used=False, forced_acceptance=False, quality_tolerance=None,
                      limitations=["CPU explicit reference, not Hyle execution or throughput evidence.",
                                   "Target uses pinned Transformers eager BF16 operations plus explicit recurrent state updates; MTP uses the frozen G BF16 node reference.",
                                   "CPU/GPU reduction and unary differences can change greedy decisions; align actual token prefixes before comparing tensors.",
                                   "A finite natural outcome count does not estimate model-wide acceptance or coding quality.",
                                   "CPU cache selection demonstrates protocol state, not device permissions, cancellation or native retirement."])
        (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(output=str(args.output), generated_ids=emitted,
                          target_length=length, draft_length=length - lag, lag=lag,
                          candidate_validation=False)))


if __name__ == "__main__":
    main()
