from pathlib import Path
p=Path('docs/developer/current-work.md');s=p.read_text(encoding='utf-8')
a=s.index('**当前正在做：');b=s.index('\n当前每进程',a)
s=s[:a]+'''**当前正在做：CUDA单会话K1 MTP已接通，并完成真实取消／退休与有限独立协议对照，接下来做较长生成的质量与完整性能窗口。** [本批结果](../evidence/correctness/qwen-mtp-retirement-2026-10-22.json)包含14份KV写事务取消、丢Completion、策略异常回收及同槽重试；独立CPU参考和固定llama.cpp MTP peer均实际执行。有限两轮的决策／接受／长度相同，浮点误差仍保留，不代表质量已验收。普通双路decode最近完整窗口仍168.15对186.50tok/s，本批不更新吞吐胜负。multi-session MTP、其它系统原生路径、已选模型完整覆盖和图片范围保持。'''+s[b:]
a=s.index('| 3 | MTP真实消费者');b=s.index('\n| 4 |',a)
s=s[:a]+'''| 3 | MTP真实消费者 | **CUDA单会话K1已接通，整体未完成**。[前批自然接受／拒绝、追赶、quota1与EOS](../evidence/correctness/qwen-mtp-round-2026-10-22.json)和[本批14份写事务取消／策略异常回收、独立CPU参考与真实MTP peer](../evidence/correctness/qwen-mtp-retirement-2026-10-22.json)已有结果。含MTP的335张量peer制品已一次生成；接下来做较长生成及四项性能对照。更大质量样本、multi-session入口与其它原生后端仍待处理 |'''+s[b:]
s=s.replace('多会话入口、质量、取消故障及可比性能仍未完成。','取消／丢Completion及host策略失败回收已实跑；多会话入口、完整质量及可比性能仍未完成。')
s=s.replace('下一批检查14份写事务的原生取消／失败退休，再核独立完整MTP参考与同权重peer制品，按prefill、decode、显存与总速度做完整对照。multi-session MTP与其它系统原生消费者、图片仍保留为必要实现；本批不重复普通TopK1完整性能窗。','''[本批退休与独立对照](../evidence/correctness/qwen-mtp-retirement-2026-10-22.json)进一步补充：

- 实际阻塞CUDA队列后，stop／close及丢弃Completion均未提前释放14份写事务、候选、槽与80,240,691B预算；原生退休后旧target／draft KV、36份conv/GDN与carry／prior全字节不变，同槽重建后可继续。成功terminal后的策略异常也未发布head，14份脏页回收后原lag1前缀可重试。未注入GPU设备错误，普通退休模式本批未重跑。
- 独立CPU从原335权重生成自己的prefill与两轮草拟／验证，不读取候选中间值。完整token、接受／拒绝、位置与lag相同；3个目标hidden边界相对L2约1.78%～2.73%，logits约1.37%～2.28%，10份浮点边界均非逐字节相同。参考算术树与设备归约差异已列明，不据此签完整质量。
- 固定llama.cpp新增K1消费者，复用原库缓存；335张量制品的320份目标载荷与旧no-MTP制品逐字节相同，15份MTP转换均核原权重。实际两轮及EOS决策相同；目标2行／草拟1行GPU greedy、RS1／0已接。peer实际context最小256、完整草拟prefill和F32 host carry等差异保留。短样例计时与三点内存记录不冒充完整对照。

下一批在较长自然生成上做MTP／无MTP的prefill、完整decode、显存与总速度对照，同时扩大有限数值／输出检查，核实际热重放及准备成本。multi-session MTP、其它系统原生消费者与图片仍是必要实现；不重复旧TopK1窗口或为追逐小中位数反复全量验证。''')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/developer/performance/decode.md');s=p.read_text(encoding='utf-8');s=s.replace('MTP质量、原生取消与可比peer性能仍待处理；不为追逐TPS重复当前普通窗口。','[本批](../../evidence/correctness/qwen-mtp-retirement-2026-10-22.json)已实跑14份KV事务取消／策略异常、独立CPU协议参考与固定MTP peer；有限决策相同但浮点误差保留。接下来做较长生成的质量与完整四项窗口，不把短样例计时或三点内存当性能结论，也不重复当前普通窗口。');p.write_text(s,encoding='utf-8',newline='\n')
