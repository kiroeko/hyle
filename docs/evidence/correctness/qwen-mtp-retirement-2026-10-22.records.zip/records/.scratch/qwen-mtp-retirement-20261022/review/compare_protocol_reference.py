"""Offline NumPy comparison: archived real CUDA K1 rounds vs own CPU protocol.

Reads selected ZIP entries with manifest SHA256 and ZIP CRC checks. Does not
import Torch, run a model, modify original data, or assign a quality threshold.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile
import zlib

import numpy as np


ROOT = Path(__file__).resolve().parents[3]
STAGE = Path(__file__).resolve().parents[1]
OLD_PREFIX = ".scratch/qwen-mtp-round-20261022/"


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw.decode("utf-8-sig"), object_pairs_hook=unique_object)


def load(path):
    return parse(path.read_bytes())


def identity(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while data := stream.read(1024 * 1024):
            digest.update(data)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size, sha256=digest.hexdigest())


def decode(raw, dtype):
    if dtype == "BF16":
        return (np.frombuffer(raw, "<u2").astype(np.uint32) << 16).view(np.float32).astype(np.float64)
    return np.frombuffer(raw, "<f4" if dtype == "F32" else "<i4").astype(np.float64)


def compare(actual, reference, dtype):
    a, r = decode(actual, dtype), decode(reference, dtype)
    if a.shape != r.shape:
        raise ValueError("different boundary extents")
    finite_a, finite_r = bool(np.isfinite(a).all()), bool(np.isfinite(r).all())
    if not finite_a or not finite_r:
        raise ValueError("nonfinite boundary; cannot produce normal finite metrics")
    delta = a - r
    an, rn = np.linalg.norm(a), np.linalg.norm(r)
    mismatch = int(np.count_nonzero(a != r))
    result = dict(dtype=dtype, elements=int(a.size), bytes=len(actual),
                  candidate_finite=finite_a, reference_finite=finite_r,
                  byte_equal=actual == reference, mismatched_elements=mismatch,
                  mismatch_fraction=mismatch / int(a.size),
                  max_absolute_error=float(np.abs(delta).max()),
                  relative_l2=float(np.linalg.norm(delta) / rn) if rn else None,
                  cosine=float(np.dot(a, r) / (an * rn)) if an and rn else None)
    if dtype == "I32":
        result.update(candidate_ids=a.astype(np.int64).tolist(), reference_ids=r.astype(np.int64).tolist())
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, default=ROOT / "docs/evidence/correctness/qwen-mtp-round-2026-10-22.json")
    parser.add_argument("--archive", type=Path, default=ROOT / "docs/evidence/correctness/qwen-mtp-round-2026-10-22.data.zip")
    parser.add_argument("--reference", type=Path, default=STAGE / "reference/output-run1")
    parser.add_argument("--output", type=Path, default=STAGE / "review/protocol-reference-comparison.json")
    args = parser.parse_args()
    manifest = load(args.manifest)
    archive_id = identity(args.archive)
    expected_archive = next(item for item in manifest["archives"]
                            if Path(item["path"]).name == args.archive.name)
    assert archive_id["bytes"] == expected_archive["bytes"]
    assert archive_id["sha256"] == expected_archive["sha256"]
    index = {row["entry"]: row for row in manifest["archive_files"]}
    assert len(index) == len(manifest["archive_files"])
    archive_reads, reference_reads = {}, {}
    cpu_path = args.reference / "report.json"
    cpu = load(cpu_path)
    cpu_terminal_path = STAGE / "reference/run1/reference.result.json"
    cpu_terminal = load(cpu_terminal_path)
    cpu_plan_path = STAGE / "reference/run1/plan.json"
    cpu_plan = load(cpu_plan_path)
    assert cpu_terminal["terminal"] and cpu_terminal["exit"] == 0
    assert cpu_plan["source"] == cpu["script"] == identity(Path(cpu["script"]["path"]))
    assert "--output" in cpu_terminal["command"]
    output_arg = cpu_terminal["command"][cpu_terminal["command"].index("--output") + 1]
    assert (Path(cpu_terminal["cwd"]) / output_arg).resolve() == args.reference.resolve()
    assert cpu["runtime"]["device"] == "cpu" and not cpu["candidate_values_used"]
    assert not cpu["forced_acceptance"] and cpu["quality_tolerance"] is None

    def ref(name):
        entry = cpu["artifacts"][name]
        path = args.reference / Path(entry["path"]).name
        actual = identity(path)
        assert actual["bytes"] == entry["bytes"] and actual["sha256"] == entry["sha256"]
        raw = path.read_bytes()
        reference_reads[name] = actual
        return raw

    with zipfile.ZipFile(args.archive) as archive:
        assert len({i.filename for i in archive.infolist()}) == len(archive.infolist())

        def old(relative):
            entry = OLD_PREFIX + relative
            info = archive.getinfo(entry)
            # ZipFile.read checks the actual uncompressed CRC; also recompute it
            # explicitly so this selected-entry receipt states the check made.
            raw = archive.read(info)
            sha = hashlib.sha256(raw).hexdigest()
            crc = zlib.crc32(raw) & 0xffffffff
            expected = index[entry]
            assert len(raw) == expected["bytes"] == info.file_size
            assert sha == expected["sha256"] and crc == info.CRC
            archive_reads[entry] = dict(entry=entry, bytes=len(raw), sha256=sha,
                                        crc32=f"{crc:08x}", manifest_SHA256_verified=True,
                                        ZIP_CRC_verified=True)
            return raw

        candidate = parse(old("round-output1/observation.json"))
        gpu_terminal = parse(old("round-run1/run.result.json"))
        assert gpu_terminal["terminal"] and gpu_terminal["exit"] == 0
        assert candidate["prompt_ids"] == cpu["prompt_ids"]
        assert candidate["eos_ids"] == cpu["eos_ids"] and candidate["capacity"] == cpu["capacity"] == 64
        names = [("prefill15", "prefill"), ("natural0", "round0"), ("natural1", "round1")]
        candidate_events = {event["name"]: event for event in candidate["events"]}
        cpu_events = {event["name"]: event for event in cpu["events"]}
        ledger, comparisons = [], []
        cpu_hidden = {}
        for gpu_name, cpu_name in names:
            g, c = candidate_events[gpu_name], cpu_events[cpu_name]
            assert g["length"] == c["target_length"] and g["draft_frontier"] == c["draft_length"]
            assert g["lag"] == c["lag"] and g["emitted"] == c["emitted"]
            assert g["next_id"] == c["next_id"]
            assert g["target_query_rows"] == c["target_query_rows"]
            assert g["draft_query_rows"] == c["draft_written_rows"]
            assert c["draft_length"] == c["target_length"] - c["lag"]
            if cpu_name != "prefill":
                assert g["pending"] == c["target_inputs"][0]
                assert g["draft"] == c["draft"]
                assert [g["target_first"], g["target_second"]] == c["target_ids"]
                assert g["agreed"] == c["agreed"] and g["accepted_draft"] == c["accepted_draft"]
                assert g["committed_target_rows"] == c["committed_target_rows"]
                assert (None if g["catchup_token"] == -1 else g["catchup_token"]) == c["catchup_token"]
            rows = 1 if cpu_name == "prefill" else 2
            prefix = "prefill" if cpu_name == "prefill" else cpu_name
            hidden_all = ref(prefix + "_target_hidden")
            hidden = hidden_all[-4096:] if cpu_name == "prefill" else hidden_all
            cpu_hidden[cpu_name] = hidden_all
            logits = ref(prefix + "_target_logits")
            ids = (np.asarray([c["next_id"]], dtype="<i4").tobytes() if cpu_name == "prefill"
                   else ref(prefix + "_target_ids"))
            # Candidate prefill publishes only its last row. CPU publishes all15
            # postnorm hidden rows, and only last-row logits. Slice is explicit.
            actual_hidden = old(f"round-output1/trace/{gpu_name}/all-hidden.bf16")
            actual_logits = old(f"round-output1/trace/{gpu_name}/all-logits.f32")
            actual_ids = old(f"round-output1/trace/{gpu_name}/target-ids.i32")
            assert len(actual_hidden) == rows * 4096 and len(actual_logits) == rows * 248320 * 4
            assert len(actual_ids) == rows * 4
            for side, data_logits, data_ids in (("GPU", actual_logits, actual_ids), ("CPU", logits, ids)):
                own = np.frombuffer(data_logits, "<f4").reshape(rows, 248320).argmax(-1)
                assert np.array_equal(own, np.frombuffer(data_ids, "<i4")), side + " own first argmax differs"
            for boundary, a, r, dtype in (("target_hidden", actual_hidden, hidden, "BF16"),
                                           ("target_logits", actual_logits, logits, "F32"),
                                           ("target_ids", actual_ids, ids, "I32")):
                row = dict(event=gpu_name, reference_event=cpu_name, boundary=boundary,
                           reference_selection=("last row14 of BF16[15,2048]" if boundary == "target_hidden" and rows == 1
                                                else "full published boundary"), **compare(a, r, dtype))
                comparisons.append(row)
            selected = 0 if cpu_name == "prefill" else c["committed_target_rows"] - 1
            carry = hidden[selected * 4096:(selected + 1) * 4096]
            if cpu_name != "prefill":
                assert carry == ref(prefix + "_carry_hidden")
            gpu_carry = old(f"round-output1/trace/{gpu_name}/carry.bf16")
            assert gpu_carry == actual_hidden[selected * 4096:(selected + 1) * 4096]
            comparisons.append(dict(event=gpu_name, reference_event=cpu_name, boundary="carry_hidden",
                                    reference_selection=f"selected target row{selected}; prefill uses original full row14",
                                    **compare(gpu_carry, carry, "BF16")))
            if c["lag"]:
                prior = ref(prefix + "_prior_hidden")
                assert prior == hidden[:4096]
                gpu_prior = old(f"round-output1/trace/{gpu_name}/prior.bf16")
                assert gpu_prior == actual_hidden[:4096]
                comparisons.append(dict(event=gpu_name, reference_event=cpu_name, boundary="prior_hidden",
                                        reference_selection="actual target T2 row0", **compare(gpu_prior, prior, "BF16")))
            else:
                assert OLD_PREFIX + f"round-output1/trace/{gpu_name}/prior.bf16" not in archive.namelist()
            ledger.append(dict(candidate=gpu_name, reference=cpu_name,
                               target_query_rows=c["target_query_rows"], draft_written_rows=c["draft_written_rows"],
                               committed_target_rows=(15 if cpu_name == "prefill" else c["committed_target_rows"]),
                               target_length=c["target_length"], draft_length=c["draft_length"], lag=c["lag"],
                               draft=c.get("draft"), target_ids=np.frombuffer(ids, "<i4").tolist(),
                               emitted=c["emitted"], next_id=c["next_id"],
                               accepted_draft=c.get("accepted_draft", False), same_protocol=True))

        # Verify independently that CPU future draft hidden is its own shifted
        # actual target result, without any reference to candidate bytes.
        assert ref("prefill_shifted_hidden") == bytes(4096) + cpu_hidden["prefill"][:-4096]
        assert ref("round0_draft_shifted_hidden") == cpu_hidden["prefill"][-4096:]
        assert ref("round1_draft_shifted_hidden") == cpu_hidden["round0"]
        assert ref("final_carry_hidden") == ref("round1_carry_hidden")
        natural = [candidate_events["natural0"], candidate_events["natural1"]]
        generated = candidate_events["prefill15"]["emitted"] + [v for e in natural for v in e["emitted"]]
        assert generated == cpu["generated_ids"] == [198, 248045, 74455, 271]
        assert sum(e["accepted_draft"] for e in natural) == 1
        assert cpu["target_length"] == cpu["target_cache"]["rows"] == 18
        assert cpu["draft_length"] == 18 and cpu["lag"] == 0
        assert len(cpu["target_cache"]["entries"]) == 48
        # These geometry facts do not imply equality of the unexported per-layer
        # states, device ownership or cancellation/retirement behavior.
        raw_float = [row for row in comparisons if row["dtype"] != "I32"]
        report = dict(
            status="finite independent complete CPU MTP protocol and archived GPU outputs compared; no quality threshold assigned",
            identities=dict(checker=identity(Path(__file__)), manifest=identity(args.manifest), archive=archive_id,
                            reference_report=identity(cpu_path), reference_script=cpu["script"],
                            reference_terminal=identity(cpu_terminal_path), reference_plan=identity(cpu_plan_path)),
            terminals=dict(candidate_GPU_exit=gpu_terminal["exit"], independent_CPU_reference_exit=cpu_terminal["exit"],
                           scope="Original recorded root runs; this checker performs no inference."),
            selected_archive_entries=list(archive_reads.values()), reference_artifacts=list(reference_reads.values()),
            provenance=dict(reference_reads_original_checkpoint_and_prompt=True,
                            reference_uses_own_target_prefill_hidden=True,
                            own_hidden_shift_bytes_verified=True, candidate_feedback=False,
                            original335_weights=dict(full_payload_copied=False, checkpoint=cpu["checkpoint"]),
                            prompt_ids=cpu["prompt_ids"], compared_prefixes="prefill15, then identical natural target inputs [198,248045] and [74455,198]",
                            prefill_hidden_slice="CPU full BF16[15,2048] -> byte offset14*4096 through15*4096; GPU only publishes the final row. CPU prefill logits already contain only that final row.",
                            prefill_ID="CPU derived from own prefill event next_id and independently checked against own last-row logits argmax; not claimed a separately written CPU ID artifact."),
            protocol=dict(events=ledger, generated_ids=generated, actual_natural_rounds=2,
                          accepted_drafts=1, rejected_drafts=1, forced_boundaries=0,
                          all_IDs_and_accept_reject_frontier_lag_match=True,
                          final_target_length=18, final_draft_frontier=18, final_lag=0),
            comparisons=comparisons,
            summary=dict(compared_boundaries=len(comparisons), all_compared_float_finite=True,
                         float_boundaries_byte_equal=sum(x["byte_equal"] for x in raw_float),
                         float_boundaries_total=len(raw_float),
                         ID_boundaries_byte_equal=all(x["byte_equal"] for x in comparisons if x["dtype"] == "I32"),
                         candidate_and_reference_own_argmax_verified=True,
                         selected_carry_and_prior_rows_verified_independently_on_each_side=True),
            limitations=[
                "P15 plus two naturally matching protocol rounds only. Matching IDs and one accept/one reject do not establish model-wide acceptance, broad coding quality, or full model correctness.",
                "Reference target uses pinned Transformers CPU eager BF16 score/probability boundaries; MTP uses G explicit F32 attention reference. CPU/GPU reduction, GEMM and unary trees differ. Numerical differences are retained without a retrospective tolerance or quality PASS.",
                "Carry/prior comparisons repeat selected target rows for state-transition auditing; they are not additional independent samples.",
                "No full target per-layer KV/conv/GDN or MTP KV numerical comparison is claimed here. Native state ownership, fourteen-bank atomic publication, cancellation and true retirement belong to the separate retirement evidence.",
                "Only selected archived entries were decompressed/CRC/SHA checked; no whole archive was extracted and frozen original records were unchanged."
            ],
            activity=dict(new_GPU_runs=0, new_Torch_imports=0, new_Torch_computation=0,
                          builds=0, product_edits=0, original_data_edits=0))
    assert "torch" not in sys.modules
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(output=str(args.output), generated_ids=generated,
                          boundaries=len(comparisons),
                          numeric=[{k: row[k] for k in ("event", "boundary", "max_absolute_error", "relative_l2", "cosine", "mismatched_elements")}
                                   for row in comparisons if row["boundary"] in ("target_hidden", "target_logits")],
                          quality_tolerance=None, torch_imported="torch" in sys.modules), indent=2))


if __name__ == "__main__":
    main()
