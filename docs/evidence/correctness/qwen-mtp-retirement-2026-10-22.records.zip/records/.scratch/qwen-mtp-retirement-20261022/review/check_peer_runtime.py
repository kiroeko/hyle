from pathlib import Path
import hashlib,json,re
R=Path.cwd();U=R/'.scratch/qwen-mtp-retirement-20261022';P=U/'peer'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
ready=read(U/'peer-ready-attempt2.json');ci=read(P/'checks/attempt2/identity.json');lp=read(P/'checks/attempt2/link-plan.json')
assert ci['source']==ready['source'] and ci['object']==lp['inputs'][0]
assert hashlib.sha256(Path(ready['source']['path']).read_bytes()).hexdigest()==ready['source']['sha256']
for f in ['compile.result.json','link.result.json']:
 x=read(P/'checks/attempt2'/f);assert x['exit']==0 and x['terminal'] is True
h15=read(R/'.scratch/qwen-mtp-round-20261022/round-output1/observation.json');h15rounds=[e for e in h15['events'] if e['stream']=='natural']; assert len(h15rounds)==2
h23=read(U/'qwen-run1/run.stdout.log'); assert read(U/'qwen-run1/run.result.json')['exit']==0
cases=[]
for name,known in [('p15-two-round2',15),('p23-eos2',23)]:
 q=P/name;terminal=read(q/'run.result.json');v=read(q/'result.json');stdout=read(q/'run.stdout.log');assert v==stdout
 assert terminal['exit']==0 and terminal['terminal'] is True
 assert read(q/'identity.json')==ready and terminal['command'][0]==ready['image']['path']
 assert len(v['prompt_ids'])==known and v['prefill_target_rows']==known and v['prefill_draft_rows']==known
 assert v['target_n_rs_seq']==1 and v['draft_n_rs_seq']==0 and v['target_effective_context']==v['draft_effective_context']==256
 assert v['shared_model_objects']==1 and v['native_contexts']==2
 generated=[v['prefill_first_id']];target=frontier=known;lag=0;rows=written=commit=agreed=accepted=proposals=0
 for i,b in enumerate(v['rounds']):
  assert b['index']==i and b['target_before']==target and b['draft_before']==frontier and b['lag_before']==lag
  assert b['pending']==generated[-1]
  assert b['draft_rows']==lag+1 and b['draft_compute']['rows']==lag+1
  assert b['target_compute']['rows']==b['verified_target_rows']==len(b['target_ids'])== (1 if b['single'] else 2)
  eq=not b['single'] and b['draft']==b['target_ids'][0]
  take2=eq and b['quota_before']>=2 and b['target_ids'][0] not in (248044,248046)
  assert b['agreed']==eq and b['accepted_draft']==take2
  assert b['committed_target_rows']==(2 if take2 else 1)
  assert b['emitted']==b['target_ids'][:b['committed_target_rows']]
  target+=b['committed_target_rows'];frontier+=b['draft_rows'];lag=target-frontier
  assert b['target_after']==target and b['draft_after']==frontier and b['lag_after']==lag
  assert b['native_target_pos_max']==target-1 and b['native_draft_pos_max']==frontier-1
  assert b['catchup_token']==(b['draft'] if take2 else -1)
  generated+=b['emitted'];rows+=b['verified_target_rows'];written+=b['draft_rows'];commit+=b['committed_target_rows'];agreed+=eq;accepted+=take2;proposals+=not b['single']
 assert generated==v['generated_ids'] and v['generated_decode_tokens']==len(generated)-1==commit
 assert [target,frontier,lag]==[v['visible_tokens'],v['draft_frontier'],v['draft_lag']]
 assert rows==v['verified_target_rows'] and written==v['draft_decode_rows'] and commit==v['committed_target_decode_rows']
 assert v['target_decode_calls']==v['draft_decode_calls']==len(v['rounds'])
 assert [proposals,agreed,accepted]==[v['proposals'],v['agreements'],v['accepted_drafts']]
 stderr=(q/'run.stderr.log').read_text(encoding='utf-8-sig');backend_rows=[int(x) for x in re.findall(r'Backend sampler selected token for idx (\d+)\. Skipping CPU samplers',stderr)]
 assert len(backend_rows)==1+proposals+rows
 assert 'offloaded 26/26 layers to GPU' in stderr and 'n_outputs_max_per_seq = 2' in stderr and 'n_outputs_max_per_seq = 1' in stderr
 assert not any(x in stderr for x in ['using CPU sampler','using CPU samplers','using CPU\n','could not be offloaded','backend sampling supports at most'])
 if known==15:
  assert v['prompt_ids']==h15['prompt_ids']
  for b,h in zip(v['rounds'],h15rounds):
   assert [b['pending'],b['draft'],*b['target_ids'],b['agreed'],b['accepted_draft'],b['emitted'],b['target_after'],b['draft_after'],b['lag_after'],b['catchup_token']]==[h['pending'],h['draft'],h['target_first'],h['target_second'],h['agreed'],h['accepted_draft'],h['emitted'],h['length'],h['draft_frontier'],h['lag'],h['catchup_token']]
  assert generated==[198,248045,74455,271] and [target,frontier,lag]==[18,18,0]
 else:
  assert generated==h23['generated_ids']==[20,248046] and [target,frontier,lag]==[24,24,0]
  b=v['rounds'][0];h=h23['rounds'][0];assert [b['pending'],b['draft'],*b['target_ids'],b['accepted_draft'],b['committed_target_rows'],b['draft_rows']]==[h['pending'],h['draft'],h['target_first'],h['target_second'],h['accepted_draft'],h['committed_target_rows'],h['draft_rows']]
 cases.append({'run':str(q.relative_to(R)),'run_receipt':ident(q/'run.result.json'),'result':ident(q/'result.json'),'stdout_equals_saved_result':True,'native_exit':0,'prompt_rows':known,'generated_ids':generated,'state_transitions':[{'before':[b['target_before'],b['draft_before'],b['lag_before']],'after':[b['target_after'],b['draft_after'],b['lag_after']],'draft':b['draft'],'target_ids':b['target_ids'],'accepted':b['accepted_draft'],'emitted':b['emitted']}for b in v['rounds']],'verified_target_decode_rows':rows,'committed_target_decode_rows':commit,'draft_decode_rows':written,'proposals':proposals,'agreements':agreed,'accepted_drafts':accepted,'native_sampler_skip_CPU_log_count':len(backend_rows),'native_sampler_output_indices':backend_rows,'actual_context_each':256,'target_RS':1,'draft_RS':0,'target_cache_bytes':v['target_cache_backing_bytes'],'draft_cache_bytes':v['draft_cache_backing_bytes'],'same_finite_Hyle_round_ID_and_boundary_contract':True})
audit=read(U/'review/peer-artifact.json');conv=read(U/'peer-conversion1/convert.result.json');assert conv['exit']==0 and conv['terminal'] is True
assert audit['tensor_count']==335 and audit['types']=={'BF16':195,'F32':140} and all(t['all_converted_bytes_equal'] for t in audit['MTP']) and len(audit['MTP'])==15
assert conv['command'][-1]==audit['artifact']['path'] and all('--mtp'!=x and '--no-mtp'!=x for x in conv['command'])
assert all(v['model']==audit['artifact']['path'] for v in [read(P/'p15-two-round2/result.json'),read(P/'p23-eos2/result.json')])
report={'status':'PASS finite actual fixed-source K1 peer runtime/ledger and native GPUgreedy review; no performance/quality acceptance','ready':ident(U/'peer-ready-attempt2.json'),'image':ready['image'],'source':ready['source'],'compiled_source_matches_current':True,'compile_exit':0,'link_exit':0,'new_native_libraries':0,'source_API_commit':'d9e03f1074dbd2979126d91dce1b5d304ec8394e','cases':cases,'first_failure_preserved':{'run':'peer/p15-two-round','exit':1,'cause':'Author omitted public n_outputs_max_per_seq2; default1 capacity blockedT2. Not evidence of missing multioutputGPUgreedy.','source':'peer/revisions/attempt1/peer_mtp.cc'},'sampling_proof':['Every sampled row first requires valid original llama_get_sampled_token_ith. The original public llama_sampler_sample then returns the same cached backendID, with one actual Skipping CPU samplers log per required row. P15 seven/P23 four rows all accounted; no fallback path silently accepted.','Fixed source llama-graph.cpp3775-3844 constructs each row sampler; llama-sampler.cpp1062-1089 uses original per-row GPUargmax; public output capacity target2/draft1 is fixed for T1/T2.','All26 model layers offloaded per actual log. Sampling/computation is on original CUDA path; host hidden transfer/control/synchronization still exists. No claim of a GPU-only transaction.'],'state_trim_proof':['Frozen source calls original seq_rm at selectedtarget length and actualdraft frontier, then requires native pos_max exactlylength-1. Both actualexit0 cases exercise these assertions.','P15 native targetRS1 rejection trims verified19 back18. Its bounded rollback is not merely JSONlength; actual native position assertion passed. Continuation after this finalreject is not part of these two rounds.','EOSagreement commit1 leaves24/24 and no bonus198. Proposalagreement and accepted count are distinct.'],'artifact':{'conversion_receipt':ident(U/'peer-conversion1/convert.result.json'),'artifact_audit':ident(U/'review/peer-artifact.json'),'identity':audit['artifact'],'tensor_count':335,'types':audit['types'],'all15_MTP_transforms_exact_from_root_audit':True,'target320_payload_identity':'Root independently checking original target payload; not re-read or inferred in this report.','command':conv['command']},'comparison_limits':['P15 is an explicit two-round probe; P23 terminates onEOS. These short timings and three self-sampled memory points are not a complete4-metric performance window, warm steady-state or speed comparison. No winner is evaluated.','One natural acceptance and one rejection plusEOS agreement establish finite state/ID paths, not an acceptance-rate or broad numerical-quality result.','Native peer executes the fullMTP block during draftprefill/catchup; Hyle executes only needed draftK/V prefill. Both costs remain charged; internal arithmetic work is not equivalent.','Peer hidden/carry isF32 with hostcopies; Hyle retainsBF16 hidden ondevice. GGUF weights also promote specified norms/conv toF32. Matching these finite IDs does not prove rawhidden/conv/GDN byteidentity acrossengines.','Peer requestedC64 but actually reserves256 each target/draft,nseq1,targetRS1,draftRS0. Hyle page/snapshot quotas reserve different structures; cachebacking43,548,672+524,288 is not physicalGPUprocess peak or equal-budget proof.','The P15 Hyle comparison uses earlier published T/round-output1 actual natural events; currentU retirement source separately asserts the same natural lag1 seed/retry. P23 uses currentU/qwen-run1. No unexecuted latestimage comparison is inferred.','No cancellation/nativefailure equivalence or remainingcapacity-one-output path is proven for this peer by these two runs.'], 'activity':{'GPU_runs':0,'builds':0,'product_edits':0,'reference_edits':0,'model_payload_reads':0,'full_archive_or_library_rehashes':0}}
out=U/'review/peer-runtime-review.json';out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({'report':str(out.relative_to(R)),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'cases':len(cases),'native_sampled_rows':[x['native_sampler_skip_CPU_log_count']for x in cases]}))
