"""Create one persistent combined MTP BF16 peer artifact from the original HF file."""
from pathlib import Path
import hashlib,importlib.util,json,os,shutil,sys
sys.dont_write_bytecode=True
U=Path(__file__).resolve().parent;R=U.parents[1]
sp=importlib.util.spec_from_file_location('build',U/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
plan=c.read(U/'review/peer-plan.json');a=plan['artifact'];output=Path(a['output']).resolve()
assert not output.exists(), 'Reuse existing model; never reconvert or overwrite it'
assert output.is_relative_to((R/'.scratch').resolve())
assert shutil.disk_usage(output.parent).free>5*1024**3
command=[str(Path(x).resolve())if ':/'in x or ':\\'in x else x for x in a['command_argv']]
assert '--mtp'not in command and '--no-mtp'not in command and command[command.index('--outtype')+1]=='bf16'
source=Path(a['source_checkpoint']);size=source.stat().st_size
with source.open('rb')as f:
 length=int.from_bytes(f.read(8),'little');header=f.read(length)
assert hashlib.sha256(header).hexdigest()==a['source_header_sha256_from_audit']
out=U/'peer-conversion1';out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',TOKENIZERS_PARALLELISM='false')
c.save(out/'plan.json',dict(command=command,peer_plan=b.identity(U/'review/peer-plan.json'),converter=b.identity(command[1]),source_checkpoint=dict(path=str(source),bytes=size,header_sha256=hashlib.sha256(header).hexdigest()),output=str(output),no_source_or_SDK_copy=True,new_native_builds=0))
c.execute('convert',command,env,out)
assert output.exists();c.save(out/'artifact.json',dict(artifact=b.identity(output),converter=b.identity(command[1]),source_header_sha256=hashlib.sha256(header).hexdigest(),GGUF_metadata_validation='pending next read-only check',persistent_cache=True))
print('COMBINED_MTP_ARTIFACT_READY',output,flush=True)
