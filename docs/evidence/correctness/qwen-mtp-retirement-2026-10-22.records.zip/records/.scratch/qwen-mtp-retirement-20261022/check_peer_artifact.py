"""Inspect one converted MTP cache; verify all15 converted payloads against original HF."""
from pathlib import Path
from collections import Counter
import hashlib,json,mmap,sys
import numpy as np
U=Path(__file__).resolve().parent;R=U.parents[1]
B=R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer';sys.path.insert(0,str(B/'source/gguf-py'))
import gguf
d=json.loads((U/'peer-conversion1/artifact.json').read_text());p=Path(d['artifact']['path']);reader=gguf.GGUFReader(p)
fields={k:reader.get_field(k).contents()for k in reader.fields if k.startswith('qwen35.')or k=='general.architecture'}
types=dict(Counter(t.tensor_type.name for t in reader.tensors));assert len(reader.tensors)==335 and types==dict(BF16=195,F32=140)
assert fields['general.architecture']=='qwen35'and fields['qwen35.block_count']==25 and fields['qwen35.nextn_predict_layers']==1
assert fields['qwen35.rope.dimension_count']==64 and fields['qwen35.rope.freq_base']==10000000 and fields['qwen35.rope.dimension_sections']==[11,11,10,0]
assert fields['qwen35.attention.recurrent_layers']==[i%4!=3 for i in range(24)]+[False]
mapping={'mtp.fc.weight':'nextn.eh_proj','mtp.pre_fc_norm_embedding.weight':'nextn.enorm','mtp.pre_fc_norm_hidden.weight':'nextn.hnorm','mtp.norm.weight':'nextn.shared_head_norm'}
for raw,converted in [('input_layernorm','attn_norm'),('post_attention_layernorm','post_attention_norm'),('mlp.down_proj','ffn_down'),('mlp.gate_proj','ffn_gate'),('mlp.up_proj','ffn_up'),('self_attn.q_proj','attn_q'),('self_attn.k_proj','attn_k'),('self_attn.v_proj','attn_v'),('self_attn.o_proj','attn_output'),('self_attn.q_norm','attn_q_norm'),('self_attn.k_norm','attn_k_norm')]:mapping['mtp.layers.0.'+raw+'.weight']=converted
manifest=(R/'.scratch/qwen-mtp-weights-20261022/prepared/weights.tsv').read_text().splitlines();source=Path(manifest[1]);converted={t.name:t for t in reader.tensors};checks=[]
with source.open('rb')as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)as mm:
 for line in manifest[3:]:
  a=line.split('\t');name=a[0]
  if not name.startswith('mtp.'):continue
  dtype=a[1];rank=int(a[2]);shape=list(map(int,a[3:3+rank]));offset,count=map(int,a[3+rank:]);assert dtype=='BF16'
  tensor=converted['blk.24.'+mapping[name]+'.weight'];raw=mm[offset:offset+count]
  assert list(map(int,tensor.shape))==shape[::-1]
  if tensor.tensor_type.name=='F32':
   assert rank==1
   expected=((np.frombuffer(raw,dtype='<u2').astype('<u4')<<16).view('<f4')+np.float32(1)).tobytes()
   transform='original BF16 delta -> F32 plus1 exactly once'
  else:expected=raw;transform='original BF16 bytes unchanged'
  actual=tensor.data.tobytes();assert expected==actual,name
  checks.append(dict(source=name,GGUF=tensor.name,source_shape=shape,GGUF_type=tensor.tensor_type.name,source_bytes=count,converted_bytes=len(actual),transform=transform,converted_SHA256=hashlib.sha256(actual).hexdigest(),all_converted_bytes_equal=True))
assert len(checks)==15
plan=json.loads((U/'review/peer-plan.json').read_text())
old_record=plan['cache_reuse']['existing_no_mtp_GGUF'];old_path=Path(old_record['path'])
assert old_path.stat().st_size==old_record['bytes']
old_reader=gguf.GGUFReader(old_path);assert len(old_reader.tensors)==320
target_names=[]
for old_tensor in old_reader.tensors:
 current=converted[old_tensor.name]
 assert current.tensor_type==old_tensor.tensor_type and np.array_equal(current.shape,old_tensor.shape),old_tensor.name
 assert np.array_equal(current.data,old_tensor.data),old_tensor.name
 target_names.append(old_tensor.name)
assert set(converted)-set(target_names)=={t['GGUF']for t in checks}
report=dict(status='Actual combined335 metadata and15 original MTP payload transforms verified',artifact=d['artifact'],source_checkpoint=str(source),fields=fields,types=types,tensor_count=len(reader.tensors),payload_bytes=sum(t.n_bytes for t in reader.tensors),MTP=checks,
 original_target_comparison=dict(no_MTP_artifact=old_record,source_record='peer-plan.cache_reuse; original artifact identity from preceding audit',actual_tensors_compared=320,all_types_shapes_and_payload_bytes_equal=True,names=target_names),
 scope=['No model execution, no precision/quality or performance pass.', 'Original320 target payload remains the preceding no-MTP artifact baseline; this adds15 verified MTP tensors.', 'One persistent combined cache; original no-MTP file retained; no SDK/source/checkpoint copy.'])
(U/'review/peer-artifact.json').write_text(json.dumps(report,indent=2)+'\n')
print('Actual GGUF335/195BF16+140F32; MTP payloads verified:',len(checks),'; cache bytes',p.stat().st_size)
