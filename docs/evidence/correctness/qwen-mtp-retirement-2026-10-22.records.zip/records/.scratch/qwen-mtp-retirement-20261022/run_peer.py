from pathlib import Path
import argparse,importlib.util,os,sys
sys.dont_write_bytecode=True
U=Path(__file__).resolve().parent;R=U.parents[1]
sp=importlib.util.spec_from_file_location('build',U/'build.py');h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h);b,c=h.b,h.c
p=argparse.ArgumentParser();p.add_argument('case',choices=tuple(x['name']for x in c.read(U/'peer/run-plan.json')['cases']));p.add_argument('--image-attempt',type=int,default=2);a=p.parse_args()
ready=c.read(U/f'peer-ready-attempt{a.image_attempt}.json');assert h.same(ready['image'])and h.same(ready['source'])
case=next(x for x in c.read(U/'peer/run-plan.json')['cases']if x['name']==a.case);command=case['command'];assert Path(command[0])==Path(ready['image']['path'])
out=Path(command[command.index('--output')+1]).parent;assert out.resolve().is_relative_to((U/'peer').resolve());out.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']=c.read(ready['runtime_environment']['path'])['PATH']
c.save(out/'identity.json',ready);c.save(out/'plan.json',dict(command=command,artifact=c.read(U/'peer-conversion1/artifact.json')['artifact'],throughput_comparison=False))
c.execute('run',command,env,out)
