from pathlib import Path
import hashlib, json, os, re, struct, subprocess, sys, time

root = Path.cwd()
a = root / '.scratch/architecture-refactor-2026-10-18'
out = a / 'grouped-nvfp4-vulkan'
checks = out / 'checks'
shaders = out / 'shaders'
checks.mkdir(exist_ok=True)
phase = sys.argv[1]
plan = json.loads((checks / 'proposed-plan.json').read_bytes())
env = os.environ.copy()
setup = subprocess.run(['cmd', '/d', '/c', str(a / 'bf16-nan-cast-contract/compiler-env.bat')],
                       capture_output=True, text=True, check=True)
for line in setup.stdout.splitlines():
    if '=' in line and not line.startswith('='):
        name, value = line.split('=', 1)
        env[name.upper()] = value
records = []

def ident(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def load(path):
    return json.loads(Path(path).read_bytes())

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')

def same(a, b):
    return a['bytes'] == b['bytes'] and a['sha256'] == b['sha256']

def run(label, command):
    start = time.time()
    result = subprocess.run(command, cwd=root, env=env, capture_output=True,
                            text=True, encoding='utf8', errors='replace')
    (checks / (label + '.stdout.log')).write_text(result.stdout, encoding='utf8')
    (checks / (label + '.stderr.log')).write_text(result.stderr, encoding='utf8')
    records.append(dict(label=label, command=command, exit_code=result.returncode,
                        seconds=time.time() - start))
    save(checks / ('commands-' + phase + '.json'), records)
    print(label, result.returncode, flush=True)
    if result.returncode:
        print((result.stdout + result.stderr)[-8000:])
        raise SystemExit(result.returncode)

def compile_one(item):
    run(item['tag'] + '-compile', item['command_not_executed'])
    dependencies = load(checks / (item['tag'] + '-deps.json'))['Data']
    paths = dict.fromkeys([dependencies['Source'], *dependencies['Includes']])
    receipt = dict(command=item['command_not_executed'], source=ident(item['source']),
                   object=ident(item['new_object']), recipe=item['recipe'],
                   dependencies=[ident(p) for p in paths])
    save(checks / (item['tag'] + '-identity.json'), receipt)

def check_spirv(data):
    assert len(data) >= 20 and len(data) % 4 == 0
    words = struct.unpack('<' + 'I' * (len(data) // 4), data)
    assert words[0] == 0x07230203 and words[1] <= 0x00010500
    at = 5
    while at < len(words):
        count, opcode = words[at] >> 16, words[at] & 65535
        assert count and at + count <= len(words)
        if opcode == 17:
            assert count == 2 and words[at + 1] == 1
        at += count
    return words

if phase == 'shaders':
    shaders.mkdir(exist_ok=True)
    # Only the two NVFP4 variants are compiled. The other 13 immutable SPVs
    # are consumed directly from the retained CT cache without copying them.
    previous = a / 'ct-packed-vulkan/shaders'
    names = re.findall(r'uint32_t> (\w+)\(\) noexcept;',
                       (previous / 'vulkan_shaders.h').read_text())
    assert len(names) == 14 and names.count('nvfp4') == 1
    names.insert(names.index('nvfp4') + 1, 'nvfp4_grouped')
    numerical = (root / 'src/compute_shader_shared/nvfp4_f32.h').read_text()
    numerical = numerical.split('R"HYLE_SHADER(', 1)[1].split(')HYLE_SHADER"', 1)[0]
    source = (root / 'src/compute_route_vulkan/shaders/nvfp4.comp').read_text()
    assert source.count('// HYLE_NVFP4_F32_SOURCE') == 1
    expanded = source.replace('// HYLE_NVFP4_F32_SOURCE', numerical)
    for name in ['nvfp4', 'nvfp4_grouped']:
        generated = shaders / (name + '.generated.comp')
        generated.write_bytes(expanded.encode('utf8'))
        command = ['C:/public/tools/glslang/glslangValidator.exe', '-V',
                   '--target-env', 'vulkan1.2', '--preamble-text',
                   '#extension GL_GOOGLE_include_directive : require\n',
                   '-I' + str(root / 'third_party/ggml_vulkan_shaders/shaders'), '-S', 'comp']
        if name == 'nvfp4_grouped':
            command += ['-DHYLE_NVFP4_GROUPED=1']
        command += ['-o', str(shaders / (name + '.spv')), str(generated)]
        run(name + '-shader', command)
    header = ['#pragma once', '#include <cstdint>', '#include <span>',
              'namespace hyle::compute::vulkan::detail::shaders {']
    cpp = ['#include "vulkan_shaders.h"',
           'namespace hyle::compute::vulkan::detail::shaders {']
    receipts = []
    for name in names:
        path = (shaders if name in ('nvfp4', 'nvfp4_grouped') else previous) / (name + '.spv')
        words = check_spirv(path.read_bytes())
        header.append('std::span<const std::uint32_t> ' + name + '() noexcept;')
        cpp.append('namespace { constexpr std::uint32_t ' + name + '_words[] = {')
        for offset in range(0, len(words), 8):
            cpp.append('  ' + ', '.join(f'0x{word:08x}u' for word in words[offset:offset + 8]) + ',')
        cpp.append('}; }')
        cpp.append('std::span<const std::uint32_t> ' + name + '() noexcept { return ' + name + '_words; }')
        receipts.append(dict(name=name, artifact=ident(path),
                             compiled=name in ('nvfp4', 'nvfp4_grouped')))
    header.append('} // namespace hyle::compute::vulkan::detail::shaders')
    cpp.append('} // namespace hyle::compute::vulkan::detail::shaders')
    (shaders / 'vulkan_shaders.h').write_bytes(('\n'.join(header) + '\n').encode())
    (shaders / 'vulkan_shaders.cc').write_bytes(('\n'.join(cpp) + '\n').encode())
    save(checks / 'shader-artifacts.json', dict(
        artifacts=receipts, shared_math=ident(root / 'src/compute_shader_shared/nvfp4_f32.h'),
        current_shader=ident(root / 'src/compute_route_vulkan/shaders/nvfp4.comp'),
        generated_header=ident(shaders / 'vulkan_shaders.h'),
        generated_source=ident(shaders / 'vulkan_shaders.cc'),
        reused=13, compiled=2, no_sdk_build=True))
elif phase in ['product', 'test']:
    for item in plan['recompile']:
        if (item['tag'] == 'grouped-nvfp4-test') == (phase == 'test'):
            compile_one(item)
elif phase == 'link':
    # Explicit shared public infer object is provided only after its owner has
    # frozen and compiled the shared schema; never compile it a second time.
    public_receipt = load(sys.argv[2])
    public_object = public_receipt['object']
    assert same(ident(public_object['path']), public_object)
    base = load(a / 'ct-packed-vulkan/checks/link-plan.json')
    replacements = {}
    for item in plan['recompile']:
        if item['tag'] != 'grouped-nvfp4-test':
            replacements[str(Path(item['previous_object']['path'])).lower()] = item['new_object']
    for item in plan['d1_generic_overlay']:
        old = a / 'layout-binding-lifetime/checks' / Path(item['object']['path']).name
        replacements[str(old).lower()] = item['object']['path']
    old_public = a / 'nvfp4-reference-linear/cuda/weight-decode.obj'
    replacements[str(old_public).lower()] = public_object['path']
    seen, command = set(), []
    for arg in base['command']:
        if arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:')):
            continue
        key = str(Path(arg)).lower()
        if key in replacements:
            seen.add(key)
            command.append(replacements[key])
        else:
            command.append(arg)
    assert seen == set(replacements), (seen, replacements)
    command.insert(1, str(checks / 'grouped-nvfp4-test.obj'))
    command += ['/OUT:' + str(checks / 'grouped-nvfp4-test.exe'),
                '/MAP:' + str(checks / 'grouped-nvfp4-test.map'),
                '/IMPLIB:' + str(checks / 'grouped-nvfp4-test.lib')]
    run('link', command)
    save(checks / 'link-plan.json', dict(command=command,
        public_receipt=ident(sys.argv[2]),
        inputs=[ident(p) for p in command[1:] if Path(p).is_file()],
        executable=ident(checks / 'grouped-nvfp4-test.exe')))
else:
    raise ValueError(phase)
