from pathlib import Path
import ast, hashlib, json

r = Path.cwd()
a = r / '.scratch/architecture-refactor-2026-10-18'
s = a / 'grouped-nvfp4-vulkan'
checks = s / 'checks'
checks.mkdir(exist_ok=True)

def load(p):
    return json.loads(Path(p).read_bytes())

def ident(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def same(a, b):
    return a['bytes'] == b['bytes'] and a['sha256'] == b['sha256']

basepath = a / 'ct-packed-vulkan/checks/link-plan.json'
base = load(basepath)
verified = []
for previous in base['inputs']:
    if previous['path'].lower().endswith('.obj'):
        actual = ident(previous['path'])
        verified.append(dict(expected=previous, actual=actual,
                             identity_equal=same(previous, actual)))
assert all(x['identity_equal'] for x in verified)

recipes = [
    ('vulkan_nvfp4', 'src/compute_route_vulkan/vulkan_nvfp4.cc',
     a / 'nvfp4-vulkan-reference/checks/vulkan_nvfp4-identity.json'),
    ('vulkan_program', 'src/compute_route_vulkan/vulkan_program.cc',
     a / 'nvfp4-vulkan-reference/checks/vulkan_program-identity.json'),
    ('vulkan_operations', 'src/compute_route_vulkan/vulkan_operations.cc',
     a / 'ct-packed-vulkan/checks/vulkan_operations-identity.json'),
    ('vulkan_shaders', s / 'shaders/vulkan_shaders.cc',
     a / 'ct-packed-vulkan/checks/vulkan_shaders-identity.json'),
    ('grouped-nvfp4-test', 'tests/graph_route_vulkan/grouped_nvfp4_reference_test.cc',
     a / 'nvfp4-vulkan-reference/checks/nvfp4-test-current-identity.json'),
]
compiles = []
for tag, source, recipe in recipes:
    rec = load(recipe)
    command, skip = [], False
    for arg in rec['command']:
        if skip:
            skip = False
            continue
        if arg == '/sourceDependencies':
            skip = True
            continue
        if arg.startswith(('/Fo', '/Fd')) or arg.lower().endswith(('.cc', '.cpp')):
            continue
        command.append(arg)
    command.insert(1, '-I' + str(s / 'shaders'))
    command += ['/sourceDependencies', str(checks / (tag + '-deps.json')),
                str(r / source), '/Fo' + str(checks / (tag + '.obj')),
                '/Fd' + str(checks / (tag + '.pdb'))]
    compiles.append(dict(tag=tag, source=str(r / source), recipe=ident(recipe),
                         previous_object=rec['object'], command_not_executed=command,
                         new_object=str(checks / (tag + '.obj'))))

abi_names = ['src/compute_route_vulkan/vulkan_internal.h',
             'src/compute_route_vulkan/vulkan_program_internal.h',
             'src/compute_provider_iree_vulkan/native_program.h',
             'include/hyle/compute/detail/vulkan_plan.h',
             'include/hyle/compute/tensor.h', 'include/hyle/compute/operation.h']
prior = load(a / 'nvfp4-vulkan-reference/checks/vulkan_program-identity.json')
old = {str(Path(x['path'])).lower(): x for x in prior['dependencies']}
abi_checks = []
for f in abi_names:
    actual = ident(r / f)
    previous = old[str(r / f).lower()]
    abi_checks.append(dict(actual=actual, previous_dependency=previous,
                           byte_equal=same(previous, actual)))
assert all(x['byte_equal'] for x in abi_checks)

overlay = []
macro_names = ['HYLE_COMPUTE_GGML_CPU', 'HYLE_TEST_GGML_CPU',
               'HYLE_GGML_CPU_PROVIDER_VERSION', 'HYLE_COMPUTE_VULKAN']
seen, macro_uses = set(), []
for tag in ['graph-executable', 'graph-resources']:
    receipt = a / 'decode-prepare-cost/cpu-regression' / (tag + '-identity.json')
    rec = load(receipt)
    actual_source, actual_object = ident(rec['source']['path']), ident(rec['object']['path'])
    assert same(rec['source'], actual_source) and same(rec['object'], actual_object)
    overlay.append(dict(receipt=ident(receipt), source=actual_source,
                        object=actual_object, source_and_object_equal=True,
                        macros=[x for x in rec['command'] if x.startswith(('/D', '-D'))]))
    for dep in rec['dependencies']:
        path = Path(dep['path'])
        if str(path).lower() in seen:
            continue
        seen.add(str(path).lower())
        for line, text in enumerate(path.read_text(encoding='utf8', errors='replace').splitlines(), 1):
            if any(name in text for name in macro_names):
                macro_uses.append(dict(path=str(path), line=line, text=text))
assert not macro_uses
ast.parse((r / 'src/compute_route_vulkan/build_shaders.py').read_text())
plan = dict(
    status='planned_only_no_compile_shader_compile_link_or_gpu', baseline=ident(basepath),
    baseline_object_identity_check=dict(count=len(verified), all_equal=True, objects=verified),
    recompile=compiles, private_abi_checks=abi_checks, d1_generic_overlay=overlay,
    d1_macro_scan=dict(unique_dependency_texts=len(seen), searched_macros=macro_names,
                       matching_uses=macro_uses,
                       conclusion='Recorded CPU macro differences have no use in either owner or its actual header dependency closure.'),
    shared_header_change='model_ops.h adds GroupedNvfp4Linear. Existing public/private structure layouts untouched; new weight_decode object required. CUDA private Program does not cross Vulkan ABI.',
    shader_incremental=dict(
        compiler='C:/public/tools/glslang/glslangValidator.exe',
        compile_only=['nvfp4', 'nvfp4_grouped'], reused_variant_count=13,
        reuse_byte_identical_spv_from=str(a / 'ct-packed-vulkan/shaders'),
        assembly='Assemble generated header/source from the retained 13 SPVs and newly compiled dense/grouped NVFP4 SPVs using the original generator array/function format. No SDK rebuild.',
        generator_current_parse='ast.parse succeeded; no shader compiled'),
    pending_before_link=['Shared fixture freeze and wrapper sourceDependencies',
                         'New public weight_decode object including grouped infer'],
    limits=['No claim all current tree built', 'No full model/Q24 payload coverage',
            'No GPU or validation layer run yet',
            'Keep INT32 carrier, UINT32 byte indexing and actual maxStorageBufferRange refusals'])
output = checks / 'proposed-plan.json'
output.write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps(dict(plan=ident(output), verified_objects=len(verified),
                      unchanged_private_abi_headers=len(abi_checks), d1_overlay=2), indent=2))
