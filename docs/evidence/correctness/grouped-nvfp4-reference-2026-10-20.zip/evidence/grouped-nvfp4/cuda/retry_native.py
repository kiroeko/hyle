"""Retain the first NVCC rejection; add the required standard host preprocessor."""
from pathlib import Path
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("products", S / "build_products.py")
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
b, c = p.b, p.c
checks = S / "checks"
out = checks / "native-retry1"
out.mkdir(exist_ok=False)
(out / "tmp").mkdir()
plan = c.read(checks / "plan.json")
row = next(row for row in plan["compile"] if row["source"]["path"].endswith(".cu"))
tag = row["tag"]
command = p.native_command(row["command"], tag, out)
command.append("-Xcompiler=/Zc:preprocessor")
assert b.same(row["source"])
assert all(b.same(item) for item in plan["frozen"])
host = next(row for row in plan["compile"] if row["source"]["path"].endswith(".cc"))
env, runtime = b.environment(host["command"], [], out)
c.save(out / "plan.json", dict(
    first_plan=b.identity(checks / "plan.json"), source=row["source"],
    command=command, change="Required /Zc:preprocessor for new CCCL atomic header",
    product_edited=False))
result = c.execute(tag + "-compile", command, env, out)
depfile = out / (tag + ".d")
dependencies = [b.identity(name) for name in p.native_dependencies(depfile)]
record = dict(command=command, source=row["source"],
              object=b.identity(out / (tag + ".obj")),
              source_dependencies=b.identity(depfile), dependencies=dependencies,
              old_object=row["old_object"], recipe=row["recipe"], result=result)
assert b.same(row["source"])
assert all(b.same(item) for item in plan["frozen"])
c.save(out / (tag + "-identity.json"), record)
records = c.read(checks / "product-objects-ready.json")["owners"]
assert len(records) == 2
c.save(checks / "product-objects-final.json", dict(owners=[*records, record]))
c.save(out / "summary.json", dict(passed=True, host_CXX_processes=2,
    NVCC_processes=2, first_NVCC_exit=2, final_NVCC_exit=0,
    links=0, GPU_runs=0, SDK_rebuilt=False, product_edited=False,
    final_objects=b.identity(checks / "product-objects-final.json")))
print("FINAL_PRODUCTS_READY", len(records) + 1, flush=True)
