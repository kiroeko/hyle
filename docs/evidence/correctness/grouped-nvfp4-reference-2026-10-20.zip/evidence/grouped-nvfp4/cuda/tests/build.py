"""Compile one CUDA Graph wrapper and link, never run GPU automatically."""
from pathlib import Path
import importlib.util,json,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parents[2];ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('grouped_cuda_test_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'nvfp4-cross-backend-reference/cuda/link-plan.json';PRODUCT=A/'grouped-nvfp4/cuda/checks/product-objects-final.json';COMMON=A/'grouped-nvfp4/common-cpu';RECIPE=A/'nvfp4-reference-linear/tests/subnormal-nonzero/cuda/test-identity.json'
SOURCE=ROOT/'tests/graph_route_cuda/grouped_nvfp4_reference_test.cc';FILTER='CudaGroupedNvfp4ReferenceGraph.*:CudaNvfp4ReferenceGraph.*'
def same(row):
 actual=b.identity(row['path']);assert actual['sha256']==row['sha256'] and actual['bytes']==row['bytes'],row['path']
def main():
 assert not (S/'test-compile.result.json').exists(),'Preserve prior attempt'
 S.mkdir(parents=True,exist_ok=True);(S/'tmp').mkdir(exist_ok=True)
 frozen=[b.identity(SOURCE),b.identity(ROOT/'tests/compute_models/grouped_nvfp4_reference_fixture.h'),b.identity(ROOT/'tests/compute_models/nvfp4_reference_fixture.h'),b.identity(ROOT/'include/hyle/compute/model_ops.h')]
 command=b.host_command(c.read(RECIPE)['command'],SOURCE,'test',S)
 c.save(S/'source-freeze.json',dict(files=frozen,common_source_freeze=b.identity(COMMON/'source-freeze.json'),product_receipt=b.identity(PRODUCT)))
 c.save(S/'plan.json',dict(command=command,recipe=b.identity(RECIPE),base=b.identity(BASE),source_freeze=b.identity(S/'source-freeze.json'),counts=dict(test_CXX=1,product_CXX=0,NVCC=0,SDK=0,GPU=0,links=1)))
 env,_=b.environment(command,[],S);c.execute('test-compile',command,env,S)
 deps=S/'test-deps.json';d=c.read(deps)['Data'];newtest=dict(source=b.identity(SOURCE),object=b.identity(S/'test.obj'),command=command,source_dependencies=b.identity(deps),dependencies=[b.identity(p) for p in dict.fromkeys([d['Source'],*d['Includes']])],recipe=b.identity(RECIPE))
 c.save(S/'test-identity.json',newtest)
 base=c.read(BASE);swaps={};proof=[]
 for r in c.read(PRODUCT)['owners']:
  same(r['object']);same(r['source']);swaps[c.key(r['old_object']['path'])]=r['object'];proof.append(dict(before=r['old_object'],after=r['object'],receipt=b.identity(PRODUCT)))
 wd=c.read(COMMON/'checks/weight-decode-identity.json');same(wd['object']);same(wd['source']);swaps[c.key(wd['old_object']['path'])]=wd['object'];proof.append(dict(before=wd['old_object'],after=wd['object'],receipt=b.identity(COMMON/'checks/weight-decode-identity.json')))
 for tag in ['graph-executable','graph-resources']:
  receipt=A/'decode-prepare-cost/cpu-regression'/(tag+'-identity.json');r=c.read(receipt);same(r['source']);same(r['object']);old=next(x for x in base['inputs'] if Path(x['path']).name==tag+'.obj');swaps[c.key(old['path'])]=r['object'];proof.append(dict(before=old,after=r['object'],receipt=b.identity(receipt)))
 assert len(swaps)==6
 basekeys={c.key(r['path']) for r in base['inputs']};assert set(swaps)<=basekeys
 inputs=[swaps.get(c.key(r['path']),r) for r in base['inputs']]+[newtest['object']]
 for r in inputs:same(r)
 image=S/'cuda.exe';command=[swaps[c.key(x)]['path'] if c.key(x) in swaps else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 command += [newtest['object']['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 lp=dict(command=command,inputs=inputs,base=b.identity(BASE),replacements=proof,additional_test=newtest['object'],source_freeze=b.identity(S/'source-freeze.json'),original_dense_test_retained=True)
 c.save(S/'link-plan.json',lp);env,runtime=b.environment(command,[r['path'] for r in inputs],S);c.save(S/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime));c.execute('link',command,env,S);c.save(S/'image.json',b.identity(image))
 for r in frozen:same(r)
 run=[str(image),'--gtest_filter='+FILTER,'--gtest_output=xml:'+str(S/'tests.xml')]
 c.save(S/'run-plan.json',dict(command=run,cwd=str(ROOT),runtime_environment=b.identity(S/'runtime-environment.json'),image=b.identity(image),link_plan=b.identity(S/'link-plan.json'),expected_cases=4,not_executed=True))
 c.save(S/'summary.json',dict(compilation_passed=True,link_passed=True,GPU_not_run=True,test_CXX=1,product_CXX=0,links=1,SDK=0,NVCC=0,link_inputs=len(inputs),image=b.identity(image),run_plan=b.identity(S/'run-plan.json')))
 print('READY_FOR_ROOT_GPU',image,flush=True)
if __name__=='__main__':main()
