"""Refresh only the three actual Grouped NVFP4 CUDA product owners."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import json
import re
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location(
    "grouped_host", A / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def native_command(recipe, tag, out):
    result = list(recipe)
    replacements = {
        "-MT": str(out / (tag + ".obj")),
        "-MF": str(out / (tag + ".d")),
        "-o": str(out / (tag + ".obj")),
    }
    for flag, value in replacements.items():
        result[result.index(flag) + 1] = value
    result = [
        "-Xcompiler=-Fd" + str(out / (tag + ".pdb")) + ",-FS"
        if arg.startswith("-Xcompiler=-Fd") else arg
        for arg in result
    ]
    return result


def native_dependencies(path):
    # nvcc's -MD escapes spaces and uses forward slashes in prerequisites.
    text = path.read_text(encoding="utf-8").replace("\\\n", " ")
    prerequisites = text.split(" : ", 1)[1]
    names = re.findall(r"(?:\\.|[^\s])+", prerequisites)
    return list(dict.fromkeys(
        str(Path(name.replace("\\ ", " ")).resolve()) for name in names))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    args = parser.parse_args()
    out = S / "checks"
    out.mkdir(exist_ok=True)
    (out / "tmp").mkdir(exist_ok=True)
    base = A / "nvfp4-cross-backend-reference/cuda/link-plan.json"
    inventory = S / "actual-owner-inventory.json"
    wanted = {"cuda_provider.cc", "nvfp4_provider.cc", "nvfp4_kernel.cu"}
    owners = [row for row in c.read(inventory)["owners"]
              if Path(row["recipe"]["source_path"]).name in wanted]
    assert len(owners) == 3
    base_inputs = {c.key(row["path"]): row for row in c.read(base)["inputs"]}
    rows = []
    for owner in owners:
        old = owner["input"]
        assert base_inputs[c.key(old["path"])] == old
        assert b.same(old), "retained original object changed"
        recipe = owner["recipe"]
        source = Path(recipe["source_path"])
        tag = source.stem.replace("_", "-")
        command = (native_command(recipe["command"], tag, out)
                   if source.suffix == ".cu"
                   else b.host_command(recipe["command"], source, tag, out))
        rows.append(dict(tag=tag, source=b.identity(source), old_object=old,
                         recipe=b.identity(recipe["recipe"]), command=command,
                         object=str(out / (tag + ".obj"))))
    frozen = [b.identity(ROOT / name) for name in [
        "src/compute_provider_cuda/nvfp4_kernel.h",
        "include/hyle/compute/model_ops.h"]]
    plan = dict(base=b.identity(base), inventory=b.identity(inventory),
                compile=rows, frozen=frozen,
                scope="2 CXX + 1 NVCC; no link, SDK, tests or GPU")
    c.save(out / "plan.json", plan)
    print("PLAN", len(rows), "owners", out / "plan.json", flush=True)
    if not args.build:
        return
    assert not any((out / (row["tag"] + "-identity.json")).exists()
                   for row in rows), "Do not overwrite successful receipts"
    host = next(row for row in rows if row["source"]["path"].endswith(".cc"))
    env, runtime = b.environment(host["command"], [], out)
    c.save(out / "runtime-environment.json",
           dict(PATH=env["PATH"], runtime=runtime))
    records, errors = [], []

    def compile_one(row):
        tag = row["tag"]
        job = out / "commands" / tag
        job.mkdir(parents=True, exist_ok=False)
        result = c.execute(tag + "-compile", row["command"], env, job)
        if row["source"]["path"].endswith(".cu"):
            depfile = out / (tag + ".d")
            paths = native_dependencies(depfile)
        else:
            depfile = out / (tag + "-deps.json")
            dep = c.read(depfile)["Data"]
            paths = list(dict.fromkeys([dep["Source"], *dep["Includes"]]))
        dependencies = [b.identity(path) for path in paths]
        record = dict(command=row["command"], source=row["source"],
                      object=b.identity(row["object"]),
                      source_dependencies=b.identity(depfile),
                      dependencies=dependencies, old_object=row["old_object"],
                      recipe=row["recipe"], result=result)
        assert b.same(row["source"])
        assert all(b.same(item) for item in frozen)
        c.save(out / (tag + "-identity.json"), record)
        return record

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(compile_one, row) for row in rows
                   if row["source"]["path"].endswith(".cc")]
        for future in futures:
            try:
                records.append(future.result())
            except Exception as error:
                errors.append(str(error))
    if not errors:
        try:
            records.append(compile_one(next(row for row in rows
                                           if row["source"]["path"].endswith(".cu"))))
        except Exception as error:
            errors.append(str(error))
    c.save(out / "product-objects-ready.json", dict(owners=records))
    c.save(out / "summary.json", dict(
        passed=not errors, host_CXX_successes=sum(
            record["source"]["path"].endswith(".cc") for record in records),
        NVCC_successes=sum(record["source"]["path"].endswith(".cu")
                           for record in records),
        errors=errors, links=0, GPU_runs=0, SDK_rebuilt=False,
        product_edited=False, plan=b.identity(out / "plan.json")))
    if errors:
        raise RuntimeError("; ".join(errors))
    print("PRODUCTS_READY", len(records), flush=True)


if __name__ == "__main__":
    main()
