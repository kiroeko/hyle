"""Recompile the sole status-carrier correction; retain the first Metal failure."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import time
import xml.etree.ElementTree as E
V = Path(__file__).resolve().parent
R = V.parent
O = V / "results"
O.mkdir(exist_ok=False)
(V / "objects").mkdir()
plan = json.loads((R / "plan.json").read_text())
extra = json.loads((R / "ct-leaf-reuse.json").read_text())
records = json.loads((R / "results/compile-summary.json").read_text())["compiles"]


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(name, value):
    (O / name).write_text(json.dumps(value, indent=2) + "\n")


def execute(tag, command):
    row = dict(argv=command, started=time.time())
    save(tag + ".command.json", row)
    p = subprocess.run(command, cwd=V, capture_output=True, text=True)
    (O / (tag + ".stdout.log")).write_text(p.stdout)
    (O / (tag + ".stderr.log")).write_text(p.stderr)
    row.update(exit=p.returncode, seconds=time.time() - row["started"])
    save(tag + ".result.json", row)
    print(tag, p.returncode, round(row["seconds"], 2), flush=True)
    return row


old = next(row for row in records if row["source"]["path"].endswith("/apple_nvfp4.cc"))
source = V / "src/compute_route_apple/apple_nvfp4.cc"
obj = V / "objects/apple_nvfp4.cc.o"
dep = V / "objects/apple_nvfp4.cc.o.d"
command = old["argv"].copy()
command[command.index("-c") + 1] = str(source)
command[command.index("-o") + 1] = str(obj)
command[command.index("-MF") + 1] = str(dep)
result = execute("apple-nvfp4-compile", command)
if result["exit"]:
    raise SystemExit(2)
dependencies = [identity(path) for path in dict.fromkeys(
    shlex.split(dep.read_text().split(": ", 1)[1].replace("\\\n", " ")))]
fresh = dict(result, source=identity(source), old_object=old["old_object"],
             object=str(obj), object_identity=identity(obj),
             dependency=str(dep), dependencies=dependencies)
save("apple-nvfp4-identity.json", fresh)
records = [fresh if row is old else row for row in records]
command = plan["link"].copy()
for row in records:
    assert identity(row["object"]) == row["object_identity"]
    if row["old_object"]:
        assert command.count(row["old_object"]) == 1
        command[command.index(row["old_object"])] = row["object"]
    else:
        command.insert(1, row["object"])
assert identity(extra["object"]["path"]) == extra["object"]
command.insert(1, extra["object"]["path"])
image = V / "grouped-nvfp4"
command[command.index("-o") + 1] = str(image)
command = [("-Wl,-map," + str(image) + ".map")
           if x.startswith("-Wl,-map,") else x for x in command]
save("link-inputs.json", [identity(path) for path in command
     if Path(path).is_file() and Path(path).suffix in [".o", ".a", ".dylib"]])
result = execute("link", command)
if result["exit"]:
    raise SystemExit(3)
(V / "mlx.metallib").symlink_to(Path(plan["metallib"]).resolve())
result = execute("run", [str(image), "--gtest_filter=" + plan["filter"],
                        "--gtest_output=xml:" + str(O / "tests.xml")])
cases = E.parse(O / "tests.xml").findall(".//testcase")
failed = [x.attrib for x in cases if x.findall("failure")]
skipped = [x.attrib for x in cases if x.findall("skipped")]
save("validation.json", dict(image=identity(image), tests=len(cases),
     failed=failed, skipped=skipped, exit=result["exit"],
     cases=[dict(suite=x.get("classname"), name=x.get("name"),
                 properties={p.get("name"): p.get("value")
                             for p in x.findall("./properties/property")}) for x in cases],
     source=identity(source), total_CXX_attempts=8, total_links=3,
     total_test_processes=2, SDK=False, NVCC=False))
print("VALIDATION", len(cases), "failed", len(failed), "skipped", len(skipped), flush=True)
raise SystemExit(result["exit"])
