"""Add the proved current CT leaf cache to the retained NVFP4 image."""
from pathlib import Path
import hashlib
import json
import subprocess
import time
import xml.etree.ElementTree as E
R = Path(__file__).resolve().parent
O = R / "results/link-retry1"
O.mkdir(exist_ok=False)
plan = json.loads((R / "plan.json").read_text())
extra = json.loads((R / "ct-leaf-reuse.json").read_text())


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def save(name, value):
    (O / name).write_text(json.dumps(value, indent=2) + "\n")


def execute(tag, command):
    record = dict(argv=command, started=time.time())
    save(tag + ".command.json", record)
    p = subprocess.run(command, cwd=R, capture_output=True, text=True)
    (O / (tag + ".stdout.log")).write_text(p.stdout)
    (O / (tag + ".stderr.log")).write_text(p.stderr)
    record.update(exit=p.returncode, seconds=time.time() - record["started"])
    save(tag + ".result.json", record)
    print(tag, p.returncode, round(record["seconds"], 2), flush=True)
    return record


for row in plan["inputs"]:
    assert identity(row["path"]) == row
assert identity(extra["object"]["path"]) == extra["object"]
records = json.loads((R / "results/compile-summary.json").read_text())["compiles"]
assert all(row["exit"] == 0 for row in records)
command = plan["link"].copy()
for row in records:
    assert identity(row["object"]) == row["object_identity"]
    if row["old_object"]:
        assert command.count(row["old_object"]) == 1
        command[command.index(row["old_object"])] = row["object"]
    else:
        command.insert(1, row["object"])
assert extra["object"]["path"] not in command
command.insert(1, extra["object"]["path"])
image = R / "grouped-nvfp4-retry1"
command[command.index("-o") + 1] = str(image)
command = [("-Wl,-map," + str(image) + ".map")
           if x.startswith("-Wl,-map,") else x for x in command]
save("link-inputs.json", [identity(x) for x in command
     if Path(x).is_file() and Path(x).suffix in [".o", ".a", ".dylib"]])
save("ct-leaf-reuse.json", extra)
result = execute("link", command)
if result["exit"]:
    raise SystemExit(2)
metallib = R / "mlx.metallib"
if not metallib.exists():
    metallib.symlink_to(Path(plan["metallib"]).resolve())
result = execute("run", [str(image), "--gtest_filter=" + plan["filter"],
                        "--gtest_output=xml:" + str(O / "tests.xml")])
cases = E.parse(O / "tests.xml").findall(".//testcase")
failed = [x.attrib for x in cases if x.findall("failure")]
skipped = [x.attrib for x in cases if x.findall("skipped")]
save("validation.json", dict(image=identity(image), tests=len(cases),
     failed=failed, skipped=skipped, exit=result["exit"],
     names=[x.get("classname") + "." + x.get("name") for x in cases],
     source_manifest=identity(R / "source-manifest.json")))
print("VALIDATION", len(cases), "failed", len(failed), "skipped", len(skipped), flush=True)
raise SystemExit(result["exit"])
