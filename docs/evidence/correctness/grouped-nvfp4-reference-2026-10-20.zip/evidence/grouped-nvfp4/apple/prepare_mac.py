"""Overlay only current Grouped NVFP4 owners on the retained Apple NVFP4 cache."""
from pathlib import Path
import base64
import hashlib
import json
import re
import subprocess
import sys
S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
OUT = S / "mac"
OUT.mkdir(exist_ok=True)
REMOTE = ("/Users/kiro/hyle-scratch/compute-unified/"
          "architecture-refactor-20261019-apple-page-invocation/grouped-nvfp4/apple")
BASE = A / "nvfp4-reference-linear/apple/v2/remote/results"


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest())


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def main():
    link = read(BASE / "after-link.json")["argv"]
    inputs = read(BASE / "after-link-inputs.json")
    recipes = {}
    for row in read(A / "nvfp4-reference-linear/apple/v1/remote/results/compile-summary.json")["compiles"]:
        name = row["source"]["path"].split("/v1/", 1)[1]
        recipes[name] = row
    for name in ["executable", "resources"]:
        rel = "src/graph/" + name + ".cc"
        recipes[rel] = read(A / ("mlx-moe-typed-inputs/apple-layout-verification/"
                               "remote/results/src--graph--" + name + ".cc-identity.json"))
    recipes["src/compute_route_apple/apple_nvfp4.cc"] = read(
        BASE / "src--compute_route_apple--apple_nvfp4.cc-identity.json")
    sources = [
        "src/compute_route_apple/apple_operations.cc",
        "src/compute_route_apple/apple_mature_float.cc",
        "src/compute_route_apple/apple_nvfp4.cc",
        "src/compute_ops/weight_decode.cc",
        "src/graph/executable.cc", "src/graph/resources.cc",
        "tests/graph_route_apple/grouped_nvfp4_reference_test.cc"]
    rows = []
    for rel in sources:
        recipe = recipes.get(rel, recipes["tests/graph_route_apple/nvfp4_reference_test.cc"])
        obj = recipe.get("object_identity", {}).get("path", recipe["object"])
        if isinstance(obj, dict):
            obj = obj["path"]
        old = "" if rel.startswith("tests/") else obj
        if old:
            assert link.count(old) == 1, (rel, old)
        rows.append(dict(source=rel, recipe=recipe["argv"], old_object=old))
    # This is a small current-source include closure, not a source/SDK checkout.
    search = [ROOT, ROOT / "include",
              *(p for p in (ROOT / "src").iterdir() if p.is_dir()),
              *(p for p in (ROOT / "third_party").iterdir() if p.is_dir())]
    seen = set()
    pattern = re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]', re.M)

    def visit(path):
        path = path.resolve()
        if path in seen or not path.is_relative_to(ROOT) or not path.is_file():
            return
        if path.suffix not in [".h", ".hpp", ".hh", ".cc", ".mm", ".inc", ".inl", ".cuh"]:
            return
        seen.add(path)
        for inc in pattern.findall(path.read_text(encoding="utf-8", errors="replace")):
            candidate = next((base / inc for base in [path.parent, *search]
                              if (base / inc).is_file()), None)
            if candidate is not None:
                visit(candidate)
    for rel in sources:
        visit(ROOT / rel)
    files = []
    for path in sorted(seen):
        row = identity(path)
        row["path"] = path.relative_to(ROOT).as_posix()
        row["data"] = base64.b64encode(path.read_bytes()).decode()
        files.append(row)
    manifest = [{k: v for k, v in row.items() if k != "data"} for row in files]
    save(OUT / "source-manifest.json", manifest)
    plan = dict(remote=REMOTE, compile=rows, link=link, inputs=inputs,
                base_link=identity(BASE / "after-link.json"),
                common_freeze=identity(A / "grouped-nvfp4/common-cpu/source-freeze.json"),
                metallib=("/Users/kiro/hyle-scratch/compute-unified/"
                          "architecture-refactor-20261019-apple-page-invocation/"
                          "f32-partials/mlx.metallib"),
                filter="AppleGroupedNvfp4ReferenceGraph.*:"
                       "AppleNvfp4ReferenceGraph.OriginalPackedBanksAndBfloatBoundariesSurviveSlotsAndUpdates:"
                       "AppleNvfp4ReferenceGraph.RuntimeDomainFailuresRecoverWithoutChangingTheReferenceTree")
    save(OUT / "plan.json", plan)
    payload = dict(plan=plan, files=files,
                   script=base64.b64encode((S / "build_mac.py").read_bytes()).decode())
    code = r'''
from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p["plan"]["remote"]);r.mkdir(parents=True,exist_ok=True)
assert not (r/"plan.json").exists(),"Do not overwrite an existing attempt"
for row in p["files"]:
 b=base64.b64decode(row["data"]);assert hashlib.sha256(b).hexdigest()==row["sha256"]
 q=r/row["path"];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/"source-manifest.json").write_text(json.dumps([{k:v for k,v in x.items()if k!="data"}for x in p["files"]],indent=2)+"\n")
(r/"plan.json").write_text(json.dumps(p["plan"],indent=2)+"\n")
(r/"build_mac.py").write_bytes(base64.b64decode(p["script"]))
for row in p["plan"]["inputs"]:
 q=Path(row["path"]);assert q.stat().st_size==row["bytes"]
 assert hashlib.sha256(q.read_bytes()).hexdigest()==row["sha256"],row["path"]
h={k:subprocess.check_output(v,text=True).strip()for k,v in{
 "model":["sysctl","-n","hw.model"],"cpu":["sysctl","-n","machdep.cpu.brand_string"],
 "memory":["sysctl","-n","hw.memsize"],"os":["sw_vers"],"compiler":["clang++","--version"],
 "space":["df","-h",str(r)]}.items()}
assert h["model"]=="Mac16,12"
(r/"hardware.json").write_text(json.dumps(h,indent=2)+"\n")
print(json.dumps(dict(remote=str(r),files=len(p["files"]),bytes=sum(x["bytes"]for x in p["files"]),
 cached_inputs=len(p["plan"]["inputs"]),compile_owners=len(p["plan"]["compile"]),hardware=h)))
'''
    encoded = base64.b64encode(code.encode()).decode()
    command = ["ssh", "-o", "BatchMode=yes", "kiro@172.22.10.198",
               'python3 -c "import base64;exec(base64.b64decode(\'' + encoded + '\'))"']
    save(OUT / "sync.command.json", command)
    result = subprocess.run(command, input=json.dumps(payload).encode(), capture_output=True)
    (OUT / "sync.stdout.log").write_bytes(result.stdout)
    (OUT / "sync.stderr.log").write_bytes(result.stderr)
    save(OUT / "sync.result.json", dict(exit=result.returncode))
    print(result.stdout.decode(), result.stderr.decode())
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
