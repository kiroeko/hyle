"""Grouped NVFP4 reference: 3 product + 2 test CXX, existing CPU closure only."""
from pathlib import Path
import argparse,importlib.util,json,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;G=S.parent;A=S.parents[2];ROOT=A.parents[1]
spec=importlib.util.spec_from_file_location('grouped_cpu_helpers',A/'grouped-shared-activation/build_host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
BASE=A/'ct-packed-pattern-shared/portable-closure/cpu/link-plan.json'
READY=G/'source-freeze.json'
ROWS=[
 ('weight-decode','src/compute_ops/weight_decode.cc','nvfp4-reference-linear/cuda/weight-decode-identity.json',True),
 ('native-provider','src/compute_provider_native/native_provider.cc','ct-packed-cross-platform/ranking/native/identity.json',True),
 ('native-nvfp4','src/compute_provider_native/nvfp4.cc','nvfp4-reference-linear/cpu/nvfp4-identity.json',True),
 ('direct-test','tests/compute_provider_native/grouped_nvfp4_test.cc','nvfp4-reference-linear/cpu/workspace-alias-test-identity.json',False),
 ('graph-test','tests/graph_route_cpu/grouped_nvfp4_reference_test.cc','nvfp4-reference-linear/tests/subnormal-nonzero/cpu/test-identity.json',False)]
FILTER='NativeGroupedNvfp4.*:CpuGroupedNvfp4ReferenceGraph.*:NativeNvfp4.*:CpuNvfp4ReferenceGraph.*'
def same(row):
 actual=b.identity(row['path']);assert actual['sha256']==row['sha256'] and actual['bytes']==row['bytes'],row['path']
def checkfreeze():
 for row in c.read(READY)['files']:same(dict(row,path=str(ROOT/row['path'])))
 same(dict(c.read(READY)['native_plan_unchanged'],path=str(ROOT/c.read(READY)['native_plan_unchanged']['path'])))
def makeplan():
 rows=[]
 for tag,src,recipe,replace in ROWS:
  original=c.read(A/recipe)
  rows.append(dict(tag=tag,source_path=str(ROOT/src),recipe=b.identity(A/recipe),old_object=original['object'] if replace else None,command=b.host_command(original['command'],ROOT/src,tag,S),object_path=str(S/(tag+'.obj'))))
 return dict(base=b.identity(BASE),ready=b.identity(READY),compile=rows,filter=FILTER,scope='ABI unchanged; new empty descriptor and added inference/CPU dispatch. Existing CT and D1 shared state retained by actual object identity.',counts=dict(product_CXX=3,test_CXX=2,SDK=0,NVCC=0,GPU=0))
def compileall():
 checkfreeze();plan=makeplan();c.save(S/'plan.json',plan)
 for row in plan['compile']:
  if (S/(row['tag']+'-identity.json')).exists():
   rec=c.read(S/(row['tag']+'-identity.json'));same(rec['source']);same(rec['object']);continue
  assert not (S/(row['tag']+'-compile.result.json')).exists(),'Preserve failed attempt in another directory before retry'
  checkfreeze();env,_=b.environment(row['command'],[],S)
  c.execute(row['tag']+'-compile',row['command'],env,S)
  dep=S/(row['tag']+'-deps.json');d=c.read(dep)['Data']
  rec=dict(source=b.identity(row['source_path']),object=b.identity(row['object_path']),command=row['command'],recipe=row['recipe'],dependencies=[b.identity(p) for p in dict.fromkeys([d['Source'],*d['Includes']])],source_dependencies=b.identity(dep),old_object=row['old_object'],source_freeze=b.identity(READY))
  c.save(S/(row['tag']+'-identity.json'),rec);print('COMPILED',row['tag'],rec['object']['sha256'],flush=True)
 checkfreeze();c.save(S/'compile-summary.json',dict(passed=True,product_CXX=3,test_CXX=2,SDK=0,NVCC=0,GPU=0))
def link():
 assert not (S/'link.result.json').exists()
 checkfreeze();plan=c.read(S/'plan.json');base=c.read(BASE);recs=[c.read(S/(r['tag']+'-identity.json')) for r in plan['compile']]
 swaps={c.key(r['old_object']['path']):r['object'] for r in recs if r['old_object']}
 for tag in ['graph-executable','graph-resources']:
  d=c.read(A/'decode-prepare-cost/cpu-regression'/(tag+'-identity.json'));same(d['object'])
  old=next(x for x in base['inputs'] if Path(x['path']).name==tag+'.obj');swaps[c.key(old['path'])]=d['object']
 extra=[r['object'] for r in recs if not r['old_object']]
 inputs=[swaps.get(c.key(row['path']),row) for row in base['inputs']]+extra
 for row in inputs:same(row)
 command=[swaps[c.key(x)]['path'] if c.key(x) in swaps else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 image=S/'cpu.exe';command += [x['path'] for x in extra]+['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 link=dict(command=command,inputs=inputs,base=b.identity(BASE),source_freeze=b.identity(READY),replacements=[dict(before=old,after=swaps[c.key(old['path'])]) for old in base['inputs'] if c.key(old['path']) in swaps],new_tests=extra)
 c.save(S/'link-plan.json',link);env,_=b.environment(command,[r['path'] for r in inputs],S);c.execute('link',command,env,S);c.save(S/'image.json',b.identity(image))
def run():
 assert not (S/'tests.result.json').exists()
 lp=c.read(S/'link-plan.json');image=c.read(S/'image.json');same(image)
 for row in lp['inputs']:same(row)
 env,_=b.environment(lp['command'],[r['path'] for r in lp['inputs']],S)
 c.execute('tests',[image['path'],'--gtest_filter='+FILTER,'--gtest_output=xml:'+str(S/'tests.xml')],env,S)
 cases=ET.parse(S/'tests.xml').findall('.//testcase');failed=[x.attrib for x in cases if x.find('failure') is not None];skipped=[x.attrib for x in cases if x.find('skipped') is not None]
 c.save(S/'summary.json',dict(passed=not failed and not skipped,cases=len(cases),failed=failed,skipped=skipped,names=[x.get('classname')+'.'+x.get('name') for x in cases],properties=[dict(case=x.get('classname')+'.'+x.get('name'),properties=[y.attrib for y in x.findall('./properties/property')]) for x in cases],image=image,link_plan=b.identity(S/'link-plan.json'),source_freeze=b.identity(READY),counts=dict(product_CXX=3,test_CXX=2,links=1,GPU=0,SDK=0,NVCC=0)))
 assert not failed and not skipped
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('mode',choices=['compile','link','run']);mode=p.parse_args().mode;S.mkdir(parents=True,exist_ok=True);(S/'tmp').mkdir(exist_ok=True)
 {'compile':compileall,'link':link,'run':run}[mode]()
