from pathlib import Path
import hashlib, json, zipfile, xml.etree.ElementTree as ET

ROOT = Path.cwd()
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
G = A / 'grouped-nvfp4'
V = A / 'grouped-nvfp4-vulkan'
DEST = ROOT / 'docs/evidence/correctness/grouped-nvfp4-reference-2026-10-20'
assert (G / 'cuda/final-source-freeze.json').is_file()
entries, origins, heavy = {}, {}, []

def load(path):
    return json.loads(Path(path).read_bytes())

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8')

def add(path, member=None):
    path = Path(path)
    if member is None:
        member = 'evidence/' + path.relative_to(A).as_posix()
    data = path.read_bytes()
    assert member not in entries or entries[member] == data, member
    entries[member] = data
    origins[member] = identity(path)
    return member

def project_receipt(path):
    path = Path(path)
    data = load(path)
    assert isinstance(data, dict), path
    # Keep actual command/source/object identity. Repeated SDK header lists are
    # represented by their original receipt identity and dependency count.
    kept = {key: value for key, value in data.items()
            if key not in ('dependencies', 'compiles', 'inputs')}
    if 'inputs' in data:
        kept['inputs'] = data['inputs']
    if 'dependencies' in data:
        deps = data['dependencies']
        kept['dependency_inventory'] = dict(
            count=len(deps), original_receipt=identity(path),
            omitted='Repeated per-TU header identity arrays; SDK files are not archived.')
    kept['projection_of'] = identity(path)
    member = 'receipts/' + path.relative_to(A).as_posix()
    entries[member] = encoded(kept)
    origins[member] = identity(path)
    heavy.append(dict(original=identity(path), compact_member=member))

def current_source(record):
    raw = record.get('original', record)
    path = Path(raw['path'])
    if not path.is_absolute():
        path = ROOT / path
    actual = identity(path)
    assert actual['bytes'] == raw['bytes'] and actual['sha256'] == raw['sha256'], path
    if 'snapshot' in record:
        snapshot = record['snapshot']
        snapshot = Path(snapshot['path'] if isinstance(snapshot, dict) else snapshot)
        if not snapshot.is_absolute():
            snapshot = ROOT / snapshot
        assert snapshot.read_bytes() == path.read_bytes(), snapshot
    add(path, 'source/' + path.relative_to(ROOT).as_posix())

freeze_paths = [G / 'common-cpu/source-freeze.json', G / 'cuda/final-source-freeze.json',
                G / 'apple/source-freeze.json', V / 'source-freeze.json']
for freeze in freeze_paths:
    data = load(freeze)
    for record in data.get('sources', data.get('files', [])):
        current_source(record)
    add(freeze)

for relative in [
    'tests/compute_models/nvfp4_reference_fixture.h',
    'tests/compute_provider_native/nvfp4_test.cc',
    'tests/graph_route_cpu/nvfp4_reference_test.cc',
    'tests/graph_route_cuda/nvfp4_reference_test.cc',
    'tests/graph_route_vulkan/nvfp4_reference_test.cc',
    'tests/graph_route_apple/nvfp4_reference_test.cc',
    'src/compute_shader_shared/nvfp4_f32.h',
    'src/compute_provider_cuda/packed_rows.cuh',
    'third_party/mlx_cuda_quant/mlx_cuda_quant.h',
    'third_party/mlx_cuda_quant/SOURCE.json',
    'third_party/mlx_cuda_quant/LICENSE',
]:
    add(ROOT / relative, 'source/' + relative)

for path in [
    G / 'common-cpu/before.json', G / 'common-cpu/implementation.diff',
    G / 'cuda/before.json', G / 'cuda/final-source.diff',
    G / 'apple/before.json', G / 'apple/source.diff',
    V / 'before.json', V / 'implementation.diff',
    G / 'common-cpu/checks/summary.json', G / 'common-cpu/checks/compile-summary.json',
    G / 'common-cpu/checks/link-plan.json',
    G / 'cuda/checks/summary.json', G / 'cuda/checks/native-retry1/summary.json',
    G / 'cuda/checks/product-build-contract.json',
    G / 'cuda/tests/summary.json', G / 'cuda/tests/link-plan.json',
    G / 'cuda/tests/runtime-environment.json', G / 'cuda/tests/source-freeze.json',
    G / 'cuda/independent-apple-review.json', G / 'cuda/independent-vulkan-review.json',
    G / 'apple/final-validation.json', G / 'apple/mac/allocator-drift.diff',
    G / 'apple/mac/remote/hardware.json', G / 'apple/mac/remote/runtime-identity.json',
    G / 'apple/mac/source-manifest.json',
    V / 'checks/build-receipt.json', V / 'checks/link-plan.json',
    V / 'checks/proposed-plan.json', V / 'checks/shader-artifacts.json',
    A / 'vulkan-mlx-constant-bank-reuse/checks/runtime-environment.json',
    G / 'run_windows_tests.py', G / 'common-cpu/checks/build.py',
    G / 'cuda/build_products.py', G / 'cuda/retry_native.py', G / 'cuda/tests/build.py',
    G / 'apple/prepare_mac.py', G / 'apple/build_mac.py', G / 'apple/collect_mac.py',
    G / 'apple/retry_mac_link.py', G / 'apple/retry_mac_status.py',
    V / 'prepare_plan.py', V / 'build.py', G / 'package.py',
]:
    add(path)

# Original process records/logs are small and retained without rewriting.
process_roots = [G / 'common-cpu/checks', G / 'cuda/checks/commands/cuda-provider',
                 G / 'cuda/checks/commands/nvfp4-provider', G / 'cuda/checks/commands/nvfp4-kernel',
                 G / 'cuda/checks/native-retry1', G / 'cuda/tests',
                 G / 'apple/mac/remote/results',
                 G / 'apple/mac/remote/results/link-retry1',
                 G / 'apple/mac/remote/status-carrier-v2/results', V / 'checks']
for folder in process_roots:
    for path in folder.iterdir():
        if path.is_file() and (path.name.endswith(('.command.json', '.result.json',
                '.stdout.log', '.stderr.log')) or path.name.startswith('commands-')
                or path.name in ('tests.xml', 'validation.json', 'link-inputs.json')):
            add(path)

for backend in ['cuda', 'vulkan']:
    for path in (G / backend / 'validation').iterdir():
        assert path.suffix in ('.json', '.txt', '.xml')
        add(path)

# Preserve the real failed scalar-carrier source and the first Vulkan failure.
for path in (V / 'revisions/first-compile-failure').iterdir():
    if path.is_file():
        add(path)
for relative in ['revisions/scalar-id-status-metal-failure/apple_nvfp4.cc',
                 'revisions/scalar-id-status-metal-failure/source-freeze.json',
                 'revisions/scalar-id-status-metal-failure/source.diff']:
    add(G / 'apple' / relative)

receipt_roots = [G / 'common-cpu/checks', G / 'cuda/checks',
                 G / 'cuda/checks/native-retry1', G / 'cuda/tests',
                 G / 'apple/mac/remote/results',
                 G / 'apple/mac/remote/status-carrier-v2/results', V / 'checks']
for folder in receipt_roots:
    for path in folder.glob('*-identity.json'):
        project_receipt(path)

for path in [G / 'cuda/actual-owner-inventory.json', G / 'cuda/checks/product-objects-final.json',
             G / 'apple/mac/remote/results/compile-summary.json',
             G / 'apple/mac/ct-leaf-reuse.json']:
    heavy.append(dict(original=identity(path),
                      omitted='Hash reference; duplicated complete dependency recipes are not included.'))
entries['recipe-provenance.json'] = encoded(heavy)

def parse_xml(path):
    document = ET.parse(path).getroot()
    cases = []
    for case in document.findall('.//testcase'):
        assert not case.findall('failure') and not case.findall('error') and not case.findall('skipped')
        assert case.attrib.get('status') == 'run' and case.attrib.get('result') == 'completed'
        cases.append(dict(suite=case.attrib['classname'], name=case.attrib['name'],
                          properties={p.attrib['name']: p.attrib['value']
                                      for p in case.findall('./properties/property')}))
    assert int(document.attrib['failures']) == 0 and int(document.attrib['errors']) == 0
    assert int(document.attrib['tests']) == len(cases)
    return dict(tests=len(cases), failures=0, skipped=0, cases=cases,
                xml=identity(path), xml_member='evidence/' + path.relative_to(A).as_posix())

validation = {
    'windows_cpu': parse_xml(G / 'common-cpu/checks/tests.xml'),
    'windows_cuda': parse_xml(G / 'cuda/validation/tests.xml'),
    'windows_vulkan': parse_xml(G / 'vulkan/validation/tests.xml'),
    'macos_apple': parse_xml(G / 'apple/mac/remote/status-carrier-v2/results/tests.xml'),
}
assert [v['tests'] for v in validation.values()] == [8, 4, 4, 4]
assert load(G / 'common-cpu/checks/tests.result.json')['exit'] == 0
assert load(G / 'cuda/validation/result.json')['exit_code'] == 0
assert load(G / 'vulkan/validation/result.json')['exit_code'] == 0
apple_final = load(G / 'apple/final-validation.json')
assert apple_final['actual_final']['exit'] == 0
validation['windows_cpu']['image'] = load(G / 'common-cpu/checks/summary.json')['image']
validation['windows_cuda']['image'] = load(G / 'cuda/validation/result.json')['image']
validation['windows_vulkan']['image'] = load(G / 'vulkan/validation/result.json')['image']
validation['macos_apple']['image'] = apple_final['actual_final']['image']

report = dict(
    status='implemented_and_targeted_execution_passed', date='2026-10-20',
    scope='Grouped ModelOpt group16 BF16 software-reference capability on Windows CPU/CUDA/Vulkan and macOS Apple Metal; includes dense NVFP4 regression. No model artifact or performance acceptance.',
    previous_contract='docs/evidence/correctness/nvfp4-cross-backend-reference-2026-10-20.json',
    header_design='docs/evidence/research/nvfp4-grouped-expert-contract-2026-10-20.json',
    operation=dict(name='model_ops::GroupedNvfp4Linear / grouped_nvfp4_linear()',
        id='0x48594c454d4f444c:0x4e56463447525001',
        ports=['BF16 A[T,A_slots,K]', 'U8 W[E,N,K/2]', 'E4M3FN SF[E,N,K/16]',
               'F32 WG[E]', 'F32 IG[E]', 'I32 IDs[T,S]'], output='BF16 Y[T,S,N]',
        geometry='Positive T/S/E/N/K, K%16=0; A_slots1 orS. A dense or existing shared zero-slot-stride contiguous-K proof with actual element-aligned token padding; remaining ports dense.',
        domain='IDs all in[0,E) before expert access. Finite A; selected SF finite/nonnegative including both zero signs; selected WG/IG positive finite including F32 subnormals. Unselected metadata is not scanned.',
        math='For each selected expert, original group16 A absmax/E4M3 scale rounding and 1e-5 guard; E2M1 RNE QDQ narrowed to BF16. W narrows BF16 after E2M1code * F32(E4M3SF*WG), with code8 positive zero. Backend F32 reduction then BF16 output; finite scaling overflow/NaN behavior retained.',
        failure='Accepted Completion reports invalid ID/numeric data, outputs unusable without rollback. Failed Graph Invocation is terminal; recovery uses a fresh Invocation.'),
    integration=dict(core_or_executor_added=False, public_layout_widened=False,
        resources='Existing prepared provider/native Program, caller/Invocation workspace, Queue, capture and result/retirement mechanisms.',
        qdq_payload_bytes='2*T*S*K, independent of E; selected IG makes slot QDQ distinct even when raw A is shared.',
        weight_storage='Original W/SF/WG/IG carriers; no persistent dense E*N*K decoded weight bank.',
        other_storage='Apple retains compact numeric/ID check arrays and reduction/status intermediates; CUDA/Vulkan retain existing device-status/runtime storage. QDQ payload is not a claim about total or opaque/private memory.',
        cuda='IDs check kernel precedes quantize and dot on the same stream; atomic status observation; grouped Rows1 avoids dense Rows4 cross-expert weight sharing. Both private Program owners refreshed.',
        vulkan='Separate internal grouped shader variant with7descriptors/24-byte origins; prior dense6/20 ABI preserved. IDs dispatch precedes QDQ/dot; selected SF validation and atomic status. Only declared SF port2 admits E4M3 carrier.',
        apple='Full GPU ID reduction gates both arithmetic kernels; rank1 status carrier and existing with_device_status. Shared integer F32 helpers preserve division/subnormal semantics.',
        cold_routing='One typed custom operation along original backend routes; no model whitelist, producer switch, new executor or user macro.'),
    validation=validation,
    totals=dict(tests=20, failures=0, skipped=0, grouped_cases=11, dense_neighbor_cases=9),
    coverage=['Shared A1, per-slot AS and real zero-slot/padded-token Graph View; E3/E17, T2/S3/N5/K32 and distinct selected IG.',
              'Duplicate/replaced IDs, current A updates, two slots, retained old results and owner destruction; selected-only invalid numeric metadata and fresh Invocation recovery.',
              'Each backend grouped Graph fixture records24 lifetime submissions plus26 successful runtime-domain submissions and20 intentional failed Completions; these are assertions within passing tests, not failed test cases.',
              'Native Direct additionally checks cold schema/workspace independence, actual layouts and input/workspace overlap rejection. Dense arithmetic/lifetime/alias neighbours re-executed.',
              'Nonzero BF16 subnormal-weight witness, signed scale zeros and valid finite inputs causing overflow/NaN retain the reference tree.'],
    machines=dict(windows='Actual retained Windows x64 local CPU/CUDA13.3 sm89/Vulkan closure; Vulkan XML records NVIDIA GeForce RTX4070.',
                  apple=apple_final['hardware']),
    retained_failures=[
        dict(stage='Vulkan first CXX', failure='C2440 optional descriptor cannot copy-initialize bool', correction='Explicit has_value(); no math/resource change.'),
        dict(stage='CUDA first NVCC', failure='CCCL rejected traditional MSVC preprocessor', correction='Existing per-source conforming-preprocessor contract now includes nvfp4_kernel.cu; actual retry uses /Zc:preprocessor, without suppressing the check.'),
        dict(stage='Apple first link', failure='Retained dense base omitted current CT lowerer leaf', correction='Add source/ABI-proven existing CT leaf cache; no SDK/leaf rebuild.'),
        dict(stage='Apple first actual Metal run', failure='2 grouped cases failed compiling scalar id_status[0]; dense2passed', correction='Reshape ID reduction to rank1 length1; original math/fixture unchanged; final4passed.')],
    reviews=['evidence/grouped-nvfp4/cuda/independent-apple-review.json',
             'evidence/grouped-nvfp4/cuda/independent-vulkan-review.json'],
    visibility=load(G / 'cuda/final-source-freeze.json')['visibility_check'],
    limitations=['No Linux run; Windows CPU/GPU and macOS Metal scopes only.',
                 'No Q24/or other full artifact payload, full model execution, quality or token-throughput acceptance; artifact_execution_verified remains false.',
                 'No hardware-native FP4 GEMM equivalence or performance claim.',
                 'Current backend INT32/UINT32/byte-span/maxStorageBufferRange and allocation limits remain; no whole4GiB expert-bank/multi-buffer capability claim.',
                 'No new validation-layer or external spirv-val run. Vulkan glslang compilation and SPIRV instruction/capability checks are distinct from GPU tests.',
                 'Only retained actual build closures were incrementally refreshed; this is not a whole-current-tree build or full test matrix.'],
    archive_policy='Current owned source and relevant small shared source, actual commands/XML/logs, scoped diffs, freezes and compact source/object identities. Heavy repeated dependency recipes referenced by original hash. No binaries, objects, libraries, SDK, model payloads or source archives.')
entries['report-core.json'] = encoded(report)

for name in entries:
    suffix = Path(name).suffix.lower()
    assert suffix not in ('.exe', '.obj', '.o', '.lib', '.a', '.dll', '.pdb', '.map', '.zip', '.tar', '.metallib', '.spv'), name
inventory = dict(schema='grouped-nvfp4-reference-archive-members-v1',
    members=[dict(member=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                  origin=origins.get(name)) for name, data in sorted(entries.items())],
    note='Inventory lists every member except this inventory itself; public JSON gives its identity. Compact receipts preserve provenance and label omitted repetitive header arrays.')
entries['inventory.json'] = encoded(inventory)
DEST.parent.mkdir(parents=True, exist_ok=True)
archive = DEST.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 20, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, data, compresslevel=9)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(entries)
    for name, expected in entries.items():
        assert z.read(name) == expected, name
report['archive'] = dict(path=archive.relative_to(ROOT).as_posix(), bytes=archive.stat().st_size,
    sha256=identity(archive)['sha256'], members=len(entries),
    uncompressed_bytes=sum(len(v) for v in entries.values()),
    inventory=dict(member='inventory.json', bytes=len(entries['inventory.json']),
                   sha256=hashlib.sha256(entries['inventory.json']).hexdigest()),
    verification='CRC all members and every member byte/SHA inventory verified after writing.')
public = DEST.with_suffix('.json')
public.write_bytes(encoded(report))
receipt = dict(public=identity(public), archive=identity(archive), members=len(entries),
               source_files=sum(name.startswith('source/') for name in entries),
               projected_recipes=len(heavy), all_member_bytes_verified=True)
(G / 'package-receipt.json').write_bytes(encoded(receipt))
print(json.dumps(receipt, indent=2))
