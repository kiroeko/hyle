from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
A = ROOT / '.scratch/architecture-refactor-2026-10-18'
G = A / 'grouped-nvfp4'

def identity(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def run(label, image, environment, test_filter, expected):
    out = G / label / 'validation'
    out.mkdir(parents=True, exist_ok=True)
    xml = out / 'tests.xml'
    if xml.exists():
        raise RuntimeError(f'Preserve previous run before retry: {xml}')
    environment = Path(environment)
    env = dict(os.environ)
    env['PATH'] = json.loads(environment.read_text())['PATH']
    command = [str(image), f'--gtest_filter={test_filter}', f'--gtest_output=xml:{xml}']
    start = time.time()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=120)
    (out / 'stdout.txt').write_bytes(result.stdout)
    (out / 'stderr.txt').write_bytes(result.stderr)
    receipt = {'command': command, 'cwd': str(ROOT), 'image': identity(image),
               'environment': identity(environment), 'exit_code': result.returncode,
               'seconds': time.time() - start, 'expected_cases': expected}
    if xml.exists():
        tree = ET.parse(xml).getroot()
        receipt['xml'] = identity(xml)
        receipt['counts'] = {key: int(tree.get(key, '0'))
                             for key in ('tests', 'failures', 'disabled', 'errors')}
        receipt['skipped'] = len(tree.findall('.//skipped'))
        receipt['cases'] = [dict(case.attrib) for case in tree.findall('.//testcase')]
    receipt['passed'] = (result.returncode == 0 and receipt.get('counts', {}).get('tests') == expected
                         and receipt['counts']['failures'] == 0 and receipt['counts']['errors'] == 0
                         and receipt['skipped'] == 0)
    (out / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'backend': label, 'passed': receipt['passed'], 'counts': receipt.get('counts'),
                      'skipped': receipt.get('skipped'), 'exit_code': result.returncode}), flush=True)
    if not receipt['passed']:
        print(result.stdout.decode(errors='replace')[-14000:], flush=True)
        print(result.stderr.decode(errors='replace')[-6000:], flush=True)
        raise RuntimeError(f'{label} tests failed; preserve evidence')

run('vulkan', A/'grouped-nvfp4-vulkan/checks/grouped-nvfp4-test.exe',
    A/'vulkan-mlx-constant-bank-reuse/checks/runtime-environment.json',
    'VulkanGroupedNvfp4ReferenceGraph.*:VulkanNvfp4ReferenceGraph.*', 4)
run('cuda', G/'cuda/tests/cuda.exe', G/'cuda/tests/runtime-environment.json',
    'CudaGroupedNvfp4ReferenceGraph.*:CudaNvfp4ReferenceGraph.*', 4)
