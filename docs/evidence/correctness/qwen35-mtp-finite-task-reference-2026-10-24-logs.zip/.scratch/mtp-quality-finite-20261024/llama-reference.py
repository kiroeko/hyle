"""One predeclared ordinary reference; no downloads, builds, or retries."""
from pathlib import Path
import hashlib,json,os,struct,subprocess,sys,time
for name in ['HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_DATASETS_OFFLINE']:os.environ[name]='1'
O=Path(__file__).resolve().parent;R=O.parents[1];D=O/'llama-arithmetic-reference';D.mkdir(exist_ok=True)
M=R/'.scratch/architecture-refactor-2026-10-18/llama-matched-consumer'
sys.path.insert(0,str(M/'source/gguf-py'));sys.path.insert(0,str(O))
import gguf,numpy as np,torch
from safetensors import safe_open
from transformers import AutoTokenizer
from judge import judge
def read(p):return json.loads(p.read_text(encoding='utf8'))
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf8')
def identity(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(8*1024*1024):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def verify():
 image=R/'.scratch/qwen-mtp-quality-20261022/peer-link1/peer.exe';model=M/'Qwen3.5-2B-text-BF16.gguf'
 assert identity(image)==read(image.parent/'ready.json')['image']
 assert identity(model)==read(M/'converted-file-identity.json')
 source=Path('C:/Users/kiro/Downloads/Qwen3.5-2B/model.safetensors-00001-of-00001.safetensors')
 with source.open('rb')as f:
  n=struct.unpack('<Q',f.read(8))[0];raw=f.read(n);header=json.loads(raw)
 assert hashlib.sha256(raw).hexdigest()==read(M/'conversion-plan.json')['safetensors_header_sha256']
 reader=gguf.GGUFReader(str(model));by={t.name:t for t in reader.tensors};mapping=read(M/'converted-tensor-mapping.json')
 assert len(mapping)==len(by)==320
 rows=[]
 with source.open('rb')as sf,safe_open(str(source),framework='pt',device='cpu')as tensors:
  for row in mapping:
   name=row['source'];t=by[row['gguf']];entry=header[name]
   assert entry['dtype']==row['source_dtype']and entry['shape']==row['source_shape']
   assert t.tensor_type.name==row['output_type']and t.n_bytes==row['bytes']
   if row['output_type']=='BF16':
    assert row['source_dtype']=='BF16'and not row['transforms']
    start,end=entry['data_offsets'];assert end-start==t.n_bytes
    sf.seek(8+n+start);v=memoryview(t.data).cast('B');h=hashlib.sha256()
    for offset in range(0,t.n_bytes,8*1024*1024):
     raw=sf.read(min(8*1024*1024,t.n_bytes-offset));assert raw==v[offset:offset+len(raw)],name;h.update(raw)
    rows.append(dict(source=name,gguf=t.name,codec='BF16',bytes=t.n_bytes,exact_bytes=True,sha256=h.hexdigest()))
   else:
    assert row['output_type']=='F32';expected=tensors.get_tensor(name).to(torch.float32)
    for transform in row['transforms']:
     if transform=='F32 -exp(A_log)':expected=-torch.exp(expected)
     elif transform=='F32 checkpoint delta + 1':expected=expected+1
     else:assert transform=='squeeze singleton axis only'
    actual=np.asarray(t.data).view(np.uint32).reshape(-1);exp=expected.contiguous().numpy().view(np.uint32).reshape(-1)
    assert np.array_equal(actual,exp),name
    rows.append(dict(source=name,gguf=t.name,codec='F32',bytes=t.n_bytes,exact_transformed_bits=True,transforms=row['transforms']))
 prompt=O/'inputs/arithmetic/prompt.ids';ids=list(map(int,prompt.read_text().split()));assert len(ids)==47
 original=read(O/'pre-generation-freeze.json');case=next(x for x in original['cases']if x['id']=='arithmetic');assert identity(prompt)==case['prompt']
 contract=dict(status='VERIFIED_BEFORE_ONE_REFERENCE_GENERATION',image=identity(image),source=identity(R/'.scratch/qwen-mtp-quality-20261022/source/peer_mtp.cc'),model=identity(model),
  original_HF_checkpoint=dict(path=str(source),bytes=source.stat().st_size,header_sha256=read(M/'conversion-plan.json')['safetensors_header_sha256']),
  text_tensor_comparison=rows,source_manifest=identity(Path(original['weights_manifest']['path'])),prompt=identity(prompt),prompt_ids=ids,
  input_policy='Existing peer reads this exact prompt.ids directly; no tokenize, BOS, template, truncation or prefix-cache path.',P=47,C=512,max_outputs=128,greedy=True,MTP=False,
  arithmetic_rule_frozen=identity(O/'judge.py'),original_nine_plan=identity(O/'plan.json'),new_reference_maximum_runs=1,HTTP=0,SDK_builds=0,
  qualification='Same original checkpoint tensor values after explicit GGUF F32 converter transforms. Original Hyle BF16 intermediates and llama F32 intermediates differ; comparison diagnoses common ordinary behavior, not MTP correctness or matched arithmetic paths.')
 save(D/'alignment.json',contract);print(json.dumps(dict(status=contract['status'],tensors=len(rows),BF16=sum(x['codec']=='BF16'for x in rows),F32=sum(x['codec']=='F32'for x in rows),P=47)),flush=True)
def run():
 aligned=read(D/'alignment.json');image=Path(aligned['image']['path']);assert identity(image)==aligned['image']
 ledger=D/'generation-ledger.json';assert not ledger.exists(),'Only one reference generation is authorized; failures are retained'
 assert identity(O/'plan.json')==aligned['original_nine_plan']and identity(O/'judge.py')==aligned['arithmetic_rule_frozen']
 report=D/'consumer-result.json';command=[str(image),'--model',aligned['model']['path'],'--inputs',str(O/'inputs/arithmetic'),'--steps','128','--capacity','512','--mtp','off','--memory-snapshots','off','--output',str(report)]
 save(ledger,dict(maximum_runs=1,started=time.time(),command=command,alignment=identity(D/'alignment.json')));save(D/'command.json',dict(command=command,cwd=str(R),throughput_evidence=False,performance_claim=False))
 environment=read(image.parent/'runtime-environment.json');env=dict(os.environ,PATH=environment['PATH'])
 with (D/'stdout.log').open('wb')as out,(D/'stderr.log').open('wb')as err:
  p=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW)
 save(D/'process.json',dict(exit=p.returncode));assert p.returncode==0
 native=read(report);assert native['prompt_ids']==aligned['prompt_ids']and native['requested_context']==512
 ids=native['generated_ids'];tokenizer=AutoTokenizer.from_pretrained(read(O/'plan.json')['tokenizer'],local_files_only=True,trust_remote_code=False)
 eos=next((i for i,t in enumerate(ids)if t in [248044,248046]),None);content=ids if eos is None else ids[:eos]
 raw=tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False);text=tokenizer.decode(content,skip_special_tokens=True,clean_up_tokenization_spaces=False)
 task=next(x for x in read(O/'plan.json')['tasks']if x['id']=='arithmetic');assessment=judge(task,text)
 hyle=read(O/'results/arithmetic-ordinary/task-result.json')
 result=dict(task='arithmetic',arm='llama.cpp ordinary',P=47,C=512,max_outputs=128,native_exit=p.returncode,generated_ids=ids,decoded_text=raw,judged_text=text,natural_EOS=eos is not None,EOS_id=ids[eos]if eos is not None else None,
  rule=assessment,Hyle_ordinary_generated_ids=hyle['generated_ids'],Hyle_ordinary_text=hyle['judged_text'],same_ids_as_Hyle=ids==hyle['generated_ids'],
  interpretation='This single aligned ordinary reference cannot isolate an internal operator cause or establish model-wide quality. A differing answer is a common ordinary-path clue, not an MTP-specific defect or automatic harmless precision conclusion.',performance_claim=False,new_HTTP=0,SDK_builds=0)
 save(D/'result.json',result);print(json.dumps(result,ensure_ascii=True),flush=True)
if __name__=='__main__':{'verify':verify,'run':run}[sys.argv[1]]()
