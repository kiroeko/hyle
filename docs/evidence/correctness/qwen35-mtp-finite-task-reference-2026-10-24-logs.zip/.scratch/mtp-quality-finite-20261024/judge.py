from pathlib import Path
from decimal import Decimal
import ast,json,re,subprocess,sys
O=Path(__file__).resolve().parent
def judge(task,text):
 if task['id']=='arithmetic':
  numbers=re.findall(r'[-+]?\d+(?:\.\d+)?',text)
  return dict(passed=bool(numbers)and Decimal(numbers[-1])==Decimal(task['expected']),numbers=numbers)
 if task['id']=='extraction':
  def pairs(items):
   d={}
   for k,v in items:
    if k in d:raise ValueError('Duplicate JSON key')
    d[k]=v
   return d
  decoder=json.JSONDecoder(object_pairs_hook=pairs)
  for match in re.finditer(r'\{',text):
   try:obj,_=decoder.raw_decode(text[match.start():])
   except(ValueError,json.JSONDecodeError):continue
   return dict(passed=obj==task['expected']and type(obj.get('age'))is int,parsed=obj)
  return dict(passed=False,error='No complete nonduplicate JSON object')
 blocks=re.findall(r'```(?:python|py)?\s*\n(.*?)```',text,re.S|re.I)
 code=next((b for b in blocks if re.search(r'\bdef\s+sum_even\s*\(',b)),None)
 if code is None:
  try:ast.parse(text);code=text
  except SyntaxError:
   match=re.search(r'^\s*(?:async\s+)?def\s+sum_even\s*\(',text,re.M)
   if not match:return dict(passed=False,error='No sum_even function source')
   code=text[match.start():]
 try:
  process=subprocess.run([sys.executable,'-I','-S',str(O/'python_judge.py')],input=json.dumps(dict(code=code,cases=task['cases'])),text=True,capture_output=True,timeout=2)
  return dict(code=code,**json.loads(process.stdout),child_exit=process.returncode)
 except subprocess.TimeoutExpired:return dict(passed=False,code=code,error='Fixed 2-second Python execution limit')
 except(ValueError,json.JSONDecodeError)as error:return dict(passed=False,code=code,error=str(error))
