from pathlib import Path
import json

W = Path(__file__).resolve().parent
p = json.loads((W / 'plan.json').read_text(encoding='utf-8'))
unit = p['consumers']['natural']
old = Path(unit['source'])
text = old.read_text(encoding='utf-8')
anchor = '    if (name == "batch")'
assert text.count(anchor) == 1
text = text.replace(anchor, '    if (name == "history") return qwen_history_control_case::run(argv[3], kind);\n' + anchor)
source = W / 'model.cc'
source.write_bytes(text.encode('utf-8'))
assert sum(x.lower() == str(old).lower() for x in unit['compile']) == 1
unit['compile'] = [str(source) if x.lower() == str(old).lower() else x for x in unit['compile']]
unit['source'] = str(source)
p['cases'].pop('natural')
p['cases']['history'] = dict(unit='natural', args=['history', 'cuda', p['cases']['batch']['args'][2]])
(W / 'plan.json').write_text(json.dumps(p, ensure_ascii=False, indent=2), encoding='utf-8')
print('Selected3 original private cases plus existing history-control dynamic outputs consumer.')
