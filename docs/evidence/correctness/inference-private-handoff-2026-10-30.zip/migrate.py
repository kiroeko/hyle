from pathlib import Path
import subprocess

R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent

def read(path):
    return path.read_bytes().decode('utf-8').replace('\r\n', '\n')

def write(path, text):
    path.write_bytes(text.replace('\r\n', '\n').encode('utf-8'))

main = R / 'engine/models/qwen35/main.cc'
io = R / 'engine/inference/program_io.h'
for path in (main, io):
    target = W / 'baseline' / path.relative_to(R)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + path.relative_to(R).as_posix()], cwd=R))

old = read(main)
start = old.index('      check(guard.execution.wait_success());', old.index('  DraftProposal execute_draft('))
observe = old.index('      if (head) {', start)
take_append = old.index('      check(guard.execution.append_transactions().subspan(draft_bank, 2).take(run));', observe)
complete = old.index('      if (head) {', take_append)
tails = old.index('      std::array<c::PagedPageAppender, 2> tails;\n', complete)
end = old.index('      check(program.io.release_inputs(program.carrier));\n', tails)
after = end + len('      check(program.io.release_inputs(program.carrier));\n')
complete_text = old[complete:tails] + old[tails + len('      std::array<c::PagedPageAppender, 2> tails;\n'):end]
assert complete_text.count('program.hidden_transactions.take(run, 0)') == 1
complete_text = complete_text.replace('program.hidden_transactions.take(run, 0)', 'program.hidden_transactions.returned(0)')
def indent(text):
    return ''.join('      ' + line if line.strip() else line for line in text.splitlines(keepends=True))
replacement = (
    '      std::array<c::PagedPageAppender, 2> tails;\n'
    '      check(guard.execution.finish_success(draft_bank, 2, take(program.io.withdrawal_values()),\n'
    '          [&]() noexcept { ++draft_program_graph_calls; },\n'
    '          [&]() -> hyle::Status {\n'
    + indent(old[observe:take_append])
    + '            return hyle::Status::Ok();\n'
    '          },\n'
    '          [&]() -> hyle::Status {\n'
    + indent(complete_text)
    + '            return hyle::Status::Ok();\n'
    '          }));\n'
)
write(main, old[:start] + replacement + old[after:])

old_io = read(io)
needle = '''  template<class Scope> Status release_inputs(ProgramCarrier<Scope> &carrier) const noexcept {
    if (!sealed_) return Status::FailedPrecondition("program IO is not sealed");
    return carrier.release_inputs(withdrawals_);
  }
'''
assert old_io.count(needle) == 1
write(io, old_io.replace(needle, '''  Result<std::span<const graph::ValueId>> withdrawal_values() const noexcept {
    if (!sealed_) return std::unexpected(Status::FailedPrecondition("program IO is not sealed"));
    return std::span<const graph::ValueId>(withdrawals_);
  }
  template<class Scope> Status release_inputs(ProgramCarrier<Scope> &carrier) const noexcept {
    HYLE_ASSIGN_OR_RETURN(auto values, withdrawal_values());
    return carrier.release_inputs(values);
  }
'''))
print('Moved private successful resource handoff to existing ExecutionEpisode; original cold IO inventory borrowed.')
