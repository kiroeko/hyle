from pathlib import Path
import importlib.util
import json
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def stable(value):
    if isinstance(value, dict):
        return {k: stable(v) for k, v in value.items()
                if not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list): return [stable(v) for v in value]
    return value

def mechanical_audit():
    path = Path('engine/models/qwen35/main.cc')
    old = (W / 'baseline' / path).read_text(encoding='utf-8')
    current = (R / path).read_text(encoding='utf-8')
    origin = old.index('  DraftProposal execute_draft(')
    start = old.index('      check(guard.execution.wait_success());', origin)
    observe = old.index('      if (head) {', start)
    appends = old.index('      check(guard.execution.append_transactions().subspan(draft_bank, 2).take(run));', observe)
    complete = old.index('      if (head) {', appends)
    tails = old.index('      std::array<c::PagedPageAppender, 2> tails;\n', complete)
    end = old.index('      check(program.io.release_inputs(program.carrier));\n', tails)
    after = end + len('      check(program.io.release_inputs(program.carrier));\n')
    begin = current.index('      std::array<c::PagedPageAppender, 2> tails;\n', current.index('  DraftProposal execute_draft('))
    new_observe = current.index('            if (head) {', begin)
    new_observe_end = current.index('            return hyle::Status::Ok();\n          },', new_observe)
    new_complete = current.index('            if (head) {', new_observe_end)
    new_complete_end = current.index('            return hyle::Status::Ok();\n          }));\n', new_complete)
    new_after = new_complete_end + len('            return hyle::Status::Ok();\n          }));\n')
    def dedent(text):
        return ''.join(line[6:] if line.strip() else line for line in text.splitlines(keepends=True))
    expected_complete = (old[complete:tails] + old[tails + len('      std::array<c::PagedPageAppender, 2> tails;\n'):end]).replace(
        'program.hidden_transactions.take(run, 0)', 'program.hidden_transactions.returned(0)')
    assert dedent(current[new_observe:new_observe_end]) == old[observe:appends]
    assert dedent(current[new_complete:new_complete_end]) == expected_complete
    assert old[:start] == current[:begin] and old[after:] == current[new_after:]
    return dict(original_observe_exact=True, original_complete_exact_except_common_Store_take=True,
        original_prepare_submit_accounting_publication_and_catches_exact=True,
        output_observe_lines=len(old[observe:appends].splitlines()),
        original_bulk_dynamic_IO_withdrawal_once=True,
        source=pin(R / path), baseline=pin(W / 'baseline' / path))

def prepare():
    p = read(W / 'plan.json')
    reports = {name: read(W / 'runs' / name / 'attempt1/report.json') for name in p['cases']}
    assert len(reports) == 4
    comparisons = []
    for name in ('batch', 'recursive', 'threshold'):
        anchor = b.PREV / 'runs' / name / 'attempt1/report.json'
        assert stable(read(anchor)) == stable(reports[name]), name
        comparisons.append(dict(case=name, anchor=pin(anchor), all_non_timing_fields_equal=True))
    assert reports['history']['status'] == 'PASS' and reports['history']['final_versions'] == 0
    consumers = {}
    for name in p['consumers']:
        receipt = read(W / 'compile' / name / 'receipt.json')
        for item in [receipt['object'], *receipt['source_identities']]: exact(item)
        consumers[name] = dict(receipt=pin(W / 'compile' / name / 'receipt.json'), object=receipt['object'])
    assert len(p['retained']) == 227 and not p['sdk_dependency_audit']['matches']
    for item in p['retained']: exact(item)
    analysis = dict(status='PASS_FINITE_PRIVATE_STAGE_HANDOFF_CHECKS',
        cases={name: pin(W / 'runs' / name / 'attempt1/report.json') for name in reports},
        original_non_timing_comparisons=comparisons, mechanical_audit=mechanical_audit(),
        finite_processes=4, affected_consumer_CXX_TUs=2, retained_SDK_engine_objects=227,
        SDK_CXX=0, NVCC=0, downloads=0, performance_experiments=0, performance_claim=False,
        history=dict(real_random_K2_R2=True, probability_and_next_counts_outputs=True,
            continuous_proposals_recovery_and_restore=True, direct_per_output_unbind_assertion=False,
            current_CUDA_same_schema_baseline=False),
        limits=['Finite Windows CUDA checks, not all platforms or complete GLM/DeepSeek/Kimi engines.',
            'History uses the existing synthetic component fixture; no model quality claim.',
            'No new native fault injection, throughput/peer/memory benchmark or speed claim.',
            'Head/RNG/ledger and page publication stay in their original model policy.'])
    save(W / 'analysis.json', analysis)
    base = read(p['base']['path'])
    base.update(schema='hyle.private-handoff.current-link-base.v1', base=p['base'],
        current_consumers={**base['current_consumers'], **consumers}, previous_consumer=consumers['cli']['receipt'],
        consumer_source=pin(p['consumers']['cli']['source']), compile=p['consumers']['cli']['compile'],
        link=[consumers['cli']['object']['path'] if key(arg) == key(p['original_consumer']) else arg for arg in p['original_link']])
    save(W / 'model-link-base.json', base)
    targets = []
    for path in sorted((W / 'bin').iterdir()):
        assert path.is_file() and path.suffix.lower() in ('.exe', '.dll', '.lib', '.exp')
        targets.append(pin(path))
    save(W / 'cleanup-targets.json', dict(boundary=str(W / 'bin'), targets=targets))
    (W / 'product.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', 'engine'], cwd=R))
    print('PASS4 finite processes;3 complete stable comparisons; original model order checked.')

def finish():
    p, a = read(W / 'plan.json'), read(W / 'analysis.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'REMOVED_EXACT_FLAT_BATCH_IMAGES'
    shutil.copyfile(R / 'test.ps1', W / 'cleanup.ps1')
    out = R / 'docs/evidence/correctness/inference-private-handoff-2026-10-30.json'
    save(out, dict(schema='hyle.correctness.private-handoff.v1', date='2026-10-30', base_commit=p['base_commit'],
        status='PRIVATE_NEXTN_USES_ORIGINAL_SHARED_SUCCESS_HANDOFF',
        changes=['Private NextN uses existing ExecutionEpisode::finish_success, including actual wait, selected Append and original Store return, and one bulk withdrawal.',
            'ProgramIo borrows its original sealed dynamic input and caller-owned output inventory; no second port list or permission owner.',
            'Original output observation, hidden publication, page-tail return, page publication, work replacement and all failure retirement remain in their original order.'],
        checks=a, cleanup=cleanup, retained_build_plan=pin(W / 'model-link-base.json'),
        source_files=[pin(R / x) for x in ('engine/inference/program_io.h','engine/models/qwen35/main.cc')],
        archive='inference-private-handoff-2026-10-30.zip'))
    files = [W / x for x in ('analysis.json','build.py','finish.py','migrate.py','select_cases.py','model.cc','product.diff','cleanup.ps1','cleanup-report.json','cleanup-targets.json')]
    for prefix in ('runs','compile','link'):
        files.extend(x for x in (W / prefix).rglob('*') if x.is_file() and x.suffix.lower() in ('.json','.log'))
    with zipfile.ZipFile(out.with_suffix('.zip'), 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(files)): archive.write(path, path.relative_to(W).as_posix())
    print('Recorded finite architecture handoff evidence; no performance claim.')

if __name__ == '__main__':
    {'prepare': prepare, 'finish': finish}[sys.argv[1]]()
