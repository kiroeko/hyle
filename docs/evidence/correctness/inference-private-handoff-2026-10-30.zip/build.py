from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import os
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
PREV = R / '.scratch/inference-stage-handoff-20261030'
spec = importlib.util.spec_from_file_location('previous', PREV / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.b.W = b.b.s.W = b.b.s.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def prepare():
    base = read(R / '.scratch/inference-glm-step-20261030/model-link-base.json')
    prior = read(PREV / 'plan.json')
    changed = {key(R / x) for x in subprocess.check_output(
        ['git', 'diff', '--name-only', '--', 'engine', 'include', 'src'], cwd=R, text=True).splitlines()}
    sdk = read(base['sdk_engine_dependencies']['path'])
    rows = {key(x['object']): x for x in sdk['inspected']}
    rows.update({key(x['object']): x for x in sdk['engine_consumers'] if 'dependencies' in x})
    inspected, unavailable, matches = [], [], []
    for item in base['retained']:
        exact(item)
        adjacent = Path(item['path']).parent / 'dependencies.json'
        row = rows.get(key(item['path']))
        path = adjacent if adjacent.is_file() and 'Data' in read(adjacent) else Path(row['dependencies']['path']) if row else None
        if path is None:
            unavailable.append(item['path'])
            continue
        data = read(path)['Data']
        inspected.append(dict(object=item['path'], dependencies=pin(path)))
        if any(key(x) in changed for x in [data['Source'], *data['Includes']]): matches.append(item['path'])
    assert not matches, matches
    consumers = {}
    for name in ('cli', 'natural'):
        unit = prior['consumers'][name]
        consumers[name] = dict(unit, compile=b.b.s.relocated(unit['compile'], name))
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    save(W / 'plan.json', dict(base=pin(R / '.scratch/inference-glm-step-20261030/model-link-base.json'),
        base_commit='9f66889ce', retained=base['retained'], runtime=base['runtime'],
        original_link=base['link'], original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        sdk_engine_dependencies=base['sdk_engine_dependencies'], consumers=consumers, units={},
        cases={name: prior['cases'][name] for name in ('recursive', 'threshold', 'batch', 'natural')},
        environments=prior['environments'],
        sdk_dependency_audit=dict(inspected=inspected, unavailable=unavailable, matches=matches),
        SDK_CXX=0, NVCC=0, downloads=0, performance_experiments=0))
    print('2 affected consumer TUs;227 original SDK/engine objects retained; no SDK/NVCC/download/benchmark.', flush=True)

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'compile': b.compile_group(sys.argv[2], sys.argv[3:])
    elif action == 'link':
        for name in sys.argv[3:]: b.link(name, sys.argv[2])
    elif action == 'run':
        for name in sys.argv[3:]: b.run(name, sys.argv[2])
    else: raise ValueError(action)
