from pathlib import Path
import subprocess,json,time,sys,os
mode=sys.argv[1];assert mode in ('asan','ubsan','tsan')
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';root=base/('foundation-f5-native-host-vulkan-'+mode);parent=root/'parent';build=root/'build';out=base/('g01-vp-'+mode);out.mkdir(exist_ok=True)
if mode=='asan':
 parent.mkdir(parents=True,exist_ok=True)
 (parent/'CMakeLists.txt').write_text((base/'foundation-f5-native-host-vulkan-ubsan/parent/CMakeLists.txt').read_text())
body=(parent/'CMakeLists.txt').read_text()
if 'g01_resident' not in body:
 body+='\nset(INSTALL_GTEST OFF CACHE BOOL "" FORCE)\nadd_subdirectory(/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-gtest EXCLUDE_FROM_ALL)\n'
 for target,file in [('g01_resident','tests/graph_route_vulkan/mature_tensor_test.cc'),('g01_cache','tests/compute_provider_ggml_vulkan/attention_cache_test.cc')]:
  body+='\nadd_executable('+target+' "'+str(source/file)+'")\ntarget_compile_features('+target+' PRIVATE cxx_std_23)\ntarget_link_libraries('+target+' PRIVATE hyle::graph GTest::gtest_main)\nhyle_apply_sanitizer('+target+')\nhyle_stage_runtime('+target+')\n'
 body+='\ntarget_include_directories(g01_cache PRIVATE "'+str(source/'src/compute_provider_ggml_vulkan')+'")\ntarget_link_libraries(g01_cache PRIVATE hyle_compute_provider_ggml_vulkan hyle_compute_ggml_runtime ggml)\n'
 (parent/'CMakeLists.txt').write_text(body)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update({'asan':{'ASAN_OPTIONS':'halt_on_error=1:detect_leaks=0'},'ubsan':{'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'tsan':{'TSAN_OPTIONS':'halt_on_error=1'}}[mode])
result_file=out/'result.json';old=json.loads(result_file.read_text()) if result_file.exists() else None;records=old['stages'] if old else []
def run(stage,args):
 attempt=1+sum(x['stage']==stage for x in records);log=out/(stage+'-'+str(attempt)+'.log');started=time.monotonic()
 with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)};records.append(row)
 result_file.write_text(json.dumps({'candidate':'3d92eee97a70f7788dfb9bbcda73f6e0f801959f','mode':mode,'scope':'actual MacBook Air host HYLE/native Vulkan objects and tiny GPU math; no shader/driver instrumentation','stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2000));print(f.read(2000).decode('utf-8',errors='replace'))
  raise SystemExit(r.returncode)
if mode=='asan' and next((x for x in reversed(records) if x['stage']=='configure'),{}).get('exit_code')!=0:
 run('configure',['/opt/homebrew/bin/cmake','-S',str(parent),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DHYLE_STATIC=ON','-DHYLE_COMPONENTS=compute;graph','-DHYLE_COMPUTE_ROUTES=vulkan','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=OFF','-DHYLE_WERROR=OFF','-DHYLE_SANITIZER=asan','-DHYLE_DEP_SOURCE_CACHE=/Users/kiro/Library/Caches/hyle/dependencies/v1'])
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_resident','g01_cache','--parallel','4'])
commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True));required=['src/compute_route_vulkan/vulkan_region.cc','src/ggml-vulkan/ggml-vulkan.cpp','src/compute_provider_ggml_vulkan/native_device.cc','src/compute_provider_ggml_vulkan/region.cc','tests/graph_route_vulkan/mature_tensor_test.cc','tests/compute_provider_ggml_vulkan/attention_cache_test.cc']
checked=[]
for name in required:
 rows=[x for x in commands if x['file'].endswith(name)];assert rows and all(('-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]) in x['command'] for x in rows),name;checked+=rows
(out/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2)+'\n')
run('resident',[str(build/'g01_resident'),'--gtest_filter=VulkanGraph.*'])
run('cache',[str(build/'g01_cache')])
