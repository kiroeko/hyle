"""Package existing owned-metadata receipts only; never builds or runs a consumer."""
from pathlib import Path
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
OUT = R / 'docs/evidence/correctness/inference-paged-owned-source-2026-10-27'


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def pin(path):
    data = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def publish():
    summary, ready, plan = (read(W / x) for x in ('summary.json', 'ready-final.json', 'plan.json'))
    xml = ET.parse(W / 'results.xml').getroot()
    assert summary['status'] == 'PASS' and summary['process']['exit'] == 0
    assert xml.attrib['tests'] == '12' and xml.attrib['failures'] == '0' and xml.attrib['errors'] == '0'
    assert len(ready['compiled']) == 4 and all(x['process']['exit'] == 0 for x in ready['compiled'])
    assert ready['link']['exit'] == ready['first_image_not_run']['link']['exit'] == 0
    sources = summary['sources']
    members = []
    for source in sources:
        relative = Path(source['path']).relative_to(R)
        snapshot = W / 'source' / relative
        actual = pin(snapshot)
        assert actual['sha256'] == source['sha256'] and actual['bytes'] == source['bytes']
        members.append((snapshot, 'source/' + relative.as_posix()))
    for name in ('evidence.py', 'check.py', 'complete.py', 'plan.json', 'selection.json',
                 'supplement.json', 'compiled.json', 'ready.json', 'ready-final.json',
                 'link-inputs.json', 'link-inputs-final.json', 'summary.json', 'results.xml'):
        members.append((W / name, 'records/' + name))
    for name in ('resources', 'batch', 'paged-test', 'append'):
        for leaf in ('command.json', 'dependencies.json', 'process.json', 'stdout.log', 'stderr.log'):
            relative = 'compile/' + name + '/' + leaf
            members.append((W / relative, 'records/' + relative))
    for name in ('link', 'link-final', 'run'):
        for leaf in ('command.json', 'process.json', 'stdout.log', 'stderr.log'):
            relative = name + '/' + leaf
            members.append((W / relative, 'records/' + relative))
    runtime = Path(ready['runtime']['path'])
    assert pin(runtime)['sha256'] == ready['runtime']['sha256']
    members.append((runtime, 'records/runtime.json'))
    archive = OUT.with_suffix('.zip')
    allowed = {'.py', '.h', '.cc', '.json', '.log', '.xml'}
    manifest = []
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for path, name in members:
            assert path.suffix in allowed
            row = pin(path)
            target.writestr(name, path.read_bytes())
            manifest.append({'member': name, 'bytes': row['bytes'], 'sha256': row['sha256']})
    with zipfile.ZipFile(archive) as target:
        assert target.namelist() == [x['member'] for x in manifest]
        for row in manifest:
            data = target.read(row['member'])
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert archive.stat().st_size < 2_000_000
    baseline = Path(plan['baseline']['path'])
    assert pin(baseline)['sha256'] == plan['baseline']['sha256']
    old, new = read(baseline), read(W / 'link-inputs-final.json')
    retained = len({(x['path'].lower(), x['sha256']) for x in old} &
                   {(x['path'].lower(), x['sha256']) for x in new})
    prior = R / 'docs/evidence/correctness/inference-paged-submission-source-2026-10-27.json'
    report = {
        'date': '2026-10-27', 'status': 'PASS',
        'scope': 'Original CUDA PagedAppend Source to attention using explicit or private owned-layout metadata; finite submission, permission and publication checks.',
        'environment': {'platform': 'Windows', 'gpu': 'NVIDIA GeForce RTX 4070',
            'compute_capability': '8.9', 'evidence': 'Actual run/stderr.log; no new hardware query or exclusive-clock claim.'},
        'build': {'CXX_TUs': 4, 'compile_attempts': 4, 'links': 2, 'images_built': 2,
            'test_processes': 1, 'NVCC_TUs': 0, 'SDK_rebuilds': 0, 'downloads': 0,
            'baseline_input_count': len(old), 'final_input_count': len(new),
            'retained_inputs': retained, 'replaced_inputs': len(new) - retained,
            'compiled': ready['compiled'], 'final_link': ready['link'],
            'first_link': ready['first_image_not_run']['link'],
            'closure_correction': 'ResourceReadyInput gained private region/ordinal fields. The first link omitted the TU owning its typed Source vector. That image was never run; paged_append.cc was compiled once and linked with the same first three successful objects.',
            'first_image_not_run': ready['first_image_not_run']['image'], 'final_image': ready['image']},
        'run': {**summary['process'], 'gtest_timestamp': xml.attrib['timestamp'],
            'tests': 12, 'passed': 12, 'failed': 0, 'skipped': 0,
            'cases': [x['classname'] + '.' + x['name'] for x in summary['tests']]},
        'checked': [
            'Explicit-metadata and three-port owned-layout attention both reuse the original pre-recorded CUDA range while producer A remains pending: zero new recordings, one reused range, one Source/device wait and zero host waits.',
            'Owned ready controls name the original selected region, with no synthetic Graph input. A complete two-entry bundle with its final private ordinal set to UINT32_MAX is rejected; the unchanged original bundle then binds successfully.',
            'A retires and detaches; original append transactions are taken and exact fresh/tail prefixes are published while B remains pending. Successor reserve remains blocked by the admitted reader.',
            'Attention BF16 values, exact changed pages and old COW/prefix bytes are checked. Retry publication retains original ready results.',
            'After B and its result retire, the same owned layout remains preparable; a same-geometry changed-page-ID layout is refused by the original mirror guard, whose complete bytes remain unchanged.',
            'Ten retained token/Store/Hybrid Source cases also pass in the same final process.'
        ],
        'failures': {'failed_compile_link_or_test_processes': 0,
            'expected_negative_checks_are_not_process_failures': True,
            'unexecuted_first_image_and_closure_correction_preserved': True},
        'not_checked': ['Successor B append or indexed-state path', 'Complete Qwen/model execution or task quality',
            'New performance or speedup', 'Other operating systems/backends', 'Injected driver faults'],
        'sources': sources,
        'reuse': {'prior_receipt': pin(prior), 'baseline_link_inputs': pin(baseline),
            'boundary': 'The previous locked native/SDK/Compute and unchanged token/Store test objects are reused. Four distinct CXX TUs replaced four inputs; no native-kernel, vendor or model rebuild. Actual dependencies and both full link manifests are archived.'},
        'archive': {**pin(archive), 'members': manifest},
    }
    OUT.with_suffix('.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'summary': pin(OUT.with_suffix('.json')), 'archive': pin(archive),
                      'members': len(manifest)}, indent=2))


if __name__ == '__main__':
    if sys.argv[1:] != ['publish']:
        raise SystemExit('usage: evidence.py publish (packages existing receipts only)')
    publish()
