from pathlib import Path
import importlib.util
import sys
import traceback
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-paged-source-20261027'
spec = importlib.util.spec_from_file_location('owned_recipe', W / 'check.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
p, b, h = q.p, q.p.b, q.p.h


def build():
    plan = b.read(W / 'plan.json')
    p.check(plan)
    assert not (W / 'supplement.json').exists()
    sources = [b.pin(R / x) for x in ('src/graph_batch/paged_append.cc', 'src/graph_batch/paged_append.h')]
    for row in sources:
        out = W / 'source' / Path(row['path']).relative_to(R)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(Path(row['path']).read_bytes())
    b.save(W / 'supplement.json', {'sources': sources,
        'reason': 'ResourceReadyInput element size changed: also replace the original typed Source vector TU. First image was never run; retain its 3 successful compiled units.'})
    first = b.read(W / 'ready.json')
    env = p.environment(plan['units'][0]['command'])
    out = W / 'compile/append'
    command = []
    argv = b.read(OLD / 'compile/append/command.json')['command']
    for i, arg in enumerate(argv):
        if i and argv[i - 1].lower() == '/sourcedependencies':
            arg = str(out / 'dependencies.json')
        elif arg.lower().startswith('/fo'):
            arg = '/Fo' + str(out / 'unit.obj')
        elif arg.lower().startswith('/fd'):
            arg = '/Fd' + str(out / 'unit.pdb')
        command.append(arg)
    compiled = h.execute(command, env, out, timeout=180)
    p.check(plan)
    for row in sources:
        b.exact(row)
    previous = OLD / 'compile/append/unit.obj'
    added = b.pin(out / 'unit.obj')
    inputs = b.read(W / 'link-inputs.json')
    assert sum(b.key(x['path']) == b.key(previous) for x in inputs) == 1
    inputs = [added if b.key(x['path']) == b.key(previous) else x for x in inputs]
    for row in inputs:
        b.exact(row)
    b.save(W / 'link-inputs-final.json', inputs)
    image = W / 'bin/owned-source-test.exe'
    command = []
    for arg in b.read(W / 'link/command.json')['command']:
        if b.key(arg) == b.key(previous):
            arg = added['path']
        elif arg.lower().startswith('/out:'):
            arg = '/OUT:' + str(image)
        elif arg.lower().startswith('/pdb:'):
            arg = '/PDB:' + str(image.with_suffix('.pdb'))
        elif arg.lower().startswith('/implib:'):
            arg = '/IMPLIB:' + str(image.with_suffix('.lib'))
        command.append(arg)
    link = h.execute(command, env, W / 'link-final', timeout=120)
    b.save(W / 'ready-final.json', {'image': b.pin(image), 'compiled': [*first['compiled'],
        {'name': 'append', 'object': added, 'process': compiled}], 'link': link,
        'inputs': b.pin(W / 'link-inputs-final.json'), 'plan': b.pin(W / 'plan.json'),
        'supplement': b.pin(W / 'supplement.json'), 'runtime': first['runtime'],
        'first_image_not_run': first})
    print('READY COMPLETE', flush=True)


def run():
    plan, ready = b.read(W / 'plan.json'), b.read(W / 'ready-final.json')
    p.check(plan)
    for row in b.read(W / 'supplement.json')['sources']:
        b.exact(row)
    b.exact(ready['image'])
    xml = W / 'results.xml'
    process = h.execute([ready['image']['path'], '--gtest_color=no',
        '--gtest_filter=' + ':'.join(plan['tests']), '--gtest_output=xml:' + str(xml)],
        p.environment(plan['units'][0]['command']), W / 'run', timeout=90)
    cases = ET.parse(xml).getroot().findall('./testsuite/testcase')
    actual = {x.attrib['classname'] + '.' + x.attrib['name'] for x in cases}
    ok = actual == set(plan['tests']) and all(x.attrib.get('status') == 'run' and
        not x.findall('failure') and not x.findall('error') and not x.findall('skipped') for x in cases)
    b.save(W / 'summary.json', {'status': 'PASS' if ok else 'FAIL', 'process': process,
        'tests': [x.attrib for x in cases], 'image': ready['image'],
        'sources': plan['sources'] + b.read(W / 'supplement.json')['sources']})
    assert ok
    print('PASS', len(cases), flush=True)


if __name__ == '__main__':
    try:
        {'build': build, 'run': run}[sys.argv[1]]()
    except Exception:
        b.save(W / (sys.argv[1] + '-complete-failure.json'), {'error': traceback.format_exc()})
        raise
