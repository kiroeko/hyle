from pathlib import Path
import importlib.util
import sys
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-paged-source-20261027'
spec = importlib.util.spec_from_file_location('paged_recipe', OLD / 'check.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
p.W, p.OLD = W, OLD
p.SPECS = [
    (name, source, OLD / 'compile' / name / 'command.json', OLD / 'compile' / name / 'unit.obj')
    for name, source in [
        ('resources', 'src/graph/resources.cc'),
        ('batch', 'src/graph_batch/batch.cc'),
        ('paged-test', 'tests/graph_batch/paged_append_source_test.cc')]
]
p.EXTRA = ['include/hyle/graph/detail/region_access.h',
    'include/hyle/graph/detail/resource_source.h',
    'include/hyle/graph/detail/output_source.h',
    'include/hyle/graph/detail/paged_append_source.h']


def freeze():
    tests = p.b.read(OLD / 'selection.json')['tests']
    tests = [x for x in tests if x.startswith('GraphOutputSourceCuda.') or
             x.startswith('GraphPagedAppendSourceCuda.')]
    tests.append('GraphPagedAppendSourceCuda.OwnedLayoutMirrorPreservesPendingPageSource')
    p.b.save(W / 'selection.json', {'tests': tests})
    p.freeze()
    plan = p.b.read(W / 'plan.json')
    plan['scope'] = ('Original selected-region owned-layout metadata guard, original CUDA '
        'PagedAppend Source attention reads, atomic rejection and mirror write backpressure. '
        'No successor append, complete model overlap or performance result.')
    p.b.save(W / 'plan.json', plan)


if __name__ == '__main__':
    try:
        {'freeze': freeze, 'build': p.build, 'run': p.run}[sys.argv[1]]()
    except Exception:
        p.b.save(W / (sys.argv[1] + '-failure.json'), {'error': traceback.format_exc()})
        raise
