# Selected Qwen ModelOpt static FP8 — source-only draft

No canonical edit, compile, model, GPU, network or new fixture. This is not full-artifact support.

## Confirmed input / coverage

- Artifact7: `nvidia/Qwen3.8-27B-NVFP4@482ca0f3832238542f8f5295dde86b5f22711d80`; original config + complete index agree on208 static-FP8 modules and193 NVFP4 modules. Both sets must stay distinct.
- Cached shard1/shard3 headers prove85 complete static triples: plain E4 `[N,K]` weight and independent F32 rank0 `input_scale`(SA)/`weight_scale`(SW). Remaining123 triples lack shard2 header; shapes derived from source geometry are expectations, not authenticated header facts.
- Example: layer0 `linear_attn.in_proj_qkv`: E4 `[10240,5120]`, SA/SW F32[]. Layer63 `self_attn.k_proj`: E4 `[1024,5120]`, SA/SW F32[]. Neither is block128 or CT dynamic-token/channel scale.
- The selected header/source caches contain0 verified original static-FP8 weight/scalar value bytes. Existing static-FP8 fixture is synthetic; original payload checks remain absent. No statement about unrelated uncatalogued private files.
- `header-source-audit.json` contains exact208 names, per-field header availability/shape/offset, fixed original identities, and the85 validations. Audit only reads metadata.

## Numerical policy must be explicit

- Exact producer suffix maps to ModelOpt `913f5e224cb2a9a7754bd2f17edd50395aad7bf7`; `quant_utils.py:225–241` exports F32 scale=`amax/maxbound` (448 for FP8), `:855–866` stores E4(weight/SW), `unified_export_hf.py:680–694` registers separate original SW/SA.
- Those serialized fields do not uniquely specify inference arithmetic. Producer fake-QDQ, ModelOpt dequantized BF16 fallback, and hardware scaled_mm are distinct rounding/reduction trees.
- Reuse the already chosen ordinary stored-scale software reference: `F32(A)*F32(1/SA)` → existing SATFINITE/RNE E4 Cast → widen codes F32 → code-domain MatMul(F32 accumulation) → separate F32 `*SA` then `*SW` → BF16 Cast. Head, if this codec is selected there, then explicitly widens BF16→F32.
- Cached SGLang HEAD `234ccba7f625e12639e621044496bcc6197c3758` and all3 source hashes still match the original research. `fp8_kernel.py:866–899` supplies static activation quantization; `fp8_utils.py:2510+` supplies explicit ordered unfused output scales. Native scalar scaled_mm is not asserted bit-equivalent.
- A future V2 policy must say this software arithmetic/reader, not merely 'modelopt' or 'FP8'. Do not reconstruct/re-encode W, combine SA*SW, apply BF16 operand QDQ, positivity/finite guards or dynamic absmax/floor.

## Private full cold-path draft (seven files; source only)

- `prepare.py`: the existing `--fp8-reader` accepts one explicit stored-SA/SW reader. It checks ModelOpt MIXED_PRECISION/static8-bit configuration, real declared BF16 compute, configured/actual role sets and exact three-role physical contract. One classification supplies the sets omitted from CT/block128 classification. No repository/revision/producer-version whitelist.
- Identity/receipt retain the exact producer provenance, so a producer string change changes source identity without selecting different math. Unknown quantizer semantics/dtype/shape remain rejected; explicit selected software reader determines arithmetic rather than guessing scale direction from FP8 names.
- `prepared_roles.h`: adds `kModelOptStaticFp8` and an exact V2 policy line; unchanged physical role row grammar already represents E4 matrix plus F32 scalar[]/[1]. Full original inventory is validated; only selected text/NextN roles are loaded. Policy cannot mix NF4/CT/block128/MLX, and absence/duplicate/misplacement/altered epilogue fail before IO.
- `precision_profile.h`: actual static codec requires the policy even for a source-bound component; incompatible F16/NF4 policies reject before the generic original loader. It retains BF16 activation/history/KV and existing F32 recurrence.
- `projection_binding.h`: `ModelOptStaticFp8Projection{Tensor* codes, Tensor* activation_scale, Tensor* weight_scale}` borrows existing stable LoadedWeight children. No resource owner, new operation, loader or route switch.
- `main.cc`: resolver requires original plain/dense E4 matrix, no group annotation, separate plain/dense F32 scalar[]/[1] SA/SW and exact auxiliaries; no tensor-content reads. Recipe emits the existing12 public nodes, including Fill(1) with EXACT SA scalar shape. Existing Graph `StaticFloat8Pattern` chooses contraction or original decomposition.
- Existing NF4/F16, CT token/channel, block128, CT local NVFP4, ModelOpt NVFP4, dense/GGUF, embedding/conv/GDN/cache paths stay unchanged outside these targeted additions. ModelOpt nonmixed/all-NVFP4 preparation returns before the new source-policy checks.
- R and T naturally flatten into original `[R*T,K]`; SA remains scalar, never row-dependent. No scheduler, shape padding or per-request state table.
- GPU packed carrier retains original E4 W and scalar owners; its transient quantized A is M*K bytes. Decomposition may materialize decoded W/workspace: actual CompileReport must distinguish it; source draft does not certify compressed-resident execution at every original shape/backend.

## Prepared focused regressions / finite next checks (NOT RUN)

1. Existing Python metadata tests gain one source case with one static triple plus one distinct NVFP4 group, ordinary/MTP inventory selection, explicit reader refusal before authenticate, missing/wrong-scale/ambiguous roles, non-BF16/dynamic/target mismatch, and producer-provenance-only changes. Existing standard-library C++ role test gains V2 roundtrip, unique codec, BF16 profile, no-policy/mixed-policy/no-role/altered-order and source-bound typed-policy rejection. Same nonexistent payload sources prove parser does no weight IO. Reuse current host compile cache only after root review; no SDK/core/provider build.
2. Then one CPU small-input component TU can call the actual new V2/load_selected_weight_roles/resolve_projection/Recipe chain. Reuse `static_fp8_reference_fixture.h::Case` (M2/N3/K32 BF16) data and its independent bit/scale oracle; original12-node graph and actual selected compressed/decomposed report must be checked. Use existing CPU130-input link closure/native DLL from the passed midturn/participant consumers, replacing only app. One process can execute two existing phase inputs with original output lease retention; no GPU or new model required. This is synthetic small input, not original cat07 numeric proof.
3. Only if original numeric payload is later explicitly obtained, authenticate the exact selected three-role slices and compare one original projection. No all-shard tensor acquisition or whole27B execution prerequisite;85 headers are not208 payloads. MTP numerical integration is not tested or claimed by metadata selection tests.

No implementation candidate beyond this one is proposed. Q24 MoE remains a separate model adapter/component boundary, not a newly declared missing codec in this draft.
