# Finite Qwen ordinary source scan

Scope: selected Qwen35/Qwen27 formats; core metadata/loader/Recipe/ordinary Family, original cached source contracts. Read-only, no compile/run/download. Current participant fix was already integrated by root before this snapshot.

One confirmed remaining format gap: selected ModelOpt mixed artifact7's208 static-FP8 Linear groups. `prepare.py:51–58` currently treats E4 W+weight_scale as CT and rejects F32 scalar; `prepared_roles.h:395–414` can instead enter NVFP4/CT checks; ProjectionBinding had no static stored-scale variant. Exact proof/design/private patch are in this same directory. Mixed NVFP4 modules must not be relabeled static FP8.

Excluded as new implementation gaps:

| Selected path | Existing actual implementation |
|---|---|
| Official BF16 | `prepared_roles.h:parameter_inventory/select_roles`; `main.cc:emit_projection` dense BF16/F32; ordinary Model builds embedding/attention/GDN/FFN/head with full source geometry. |
| GGUF mixed codecs | `prepared_gguf_roles.h`, `role_description`; encoded Gather decodes selected embedding rows, encoded MatMul keeps original compressed weights; parameter meanings distinguish raw norms/converted gamma and grouped/cyclic GDN. |
| Official block128 FP8 | `fp8_weight_import.h`, `load_selected_weight_roles` bounded per-group import, `BlockFp8Projection` fixed divide/floor policy. Original dense embedding/head remain separate. |
| CT token/channel + local NVFP4 | Separate `ChannelTokenFp8Projection` BF16 zero-only scale QDQ and `LocalNvfp4Projection` original globals/F32 pre-round. Calibration omission explicitly selects BF16 KV; not FP8 KV execution. |
| GPTQ / CT symmetric/asymmetric | Distinct original codes/zero/scale/group bindings and ArtifactDecode equations; CT source shape payload authenticated by existing loader. |
| BNB NF4 | Six original numeric operands + authenticated original state; explicit F16 activation/history/KV and F32 GDN recurrent; source-resident packed or decomposed Graph. Existing original component and tiny ordinary CPU/CUDA proofs are bounded, not full27B runs. |
| MLX affine4/8 | `Recipe::embedding` typed BF16 multiply/add, original codes/scales/biases; same operands for tied head, separate linear convention; sanitized convolution/norm meanings retained. |
| R/T / cache precision | `Recipe` symbolic packed rows=R*T; ordinary Family per-request GDN state; `prepare_cache` uses actual PrecisionProfile for Q/K/V and output; GDN recurrent remains F32. No new failure proved here; unrun combinations are not declared absent. |

Q24 MoE original target components exist in `tests/compute_models/qwen24_original_target_fragment.h` / `qwen_bfloat_moe_target_fragment.h`; Qwen35 geometry/role inventory is intentionally dense. No broad full-MoE adapter task is inferred from this scan or from inability to run the complete model.

Unreviewed: all artifact payloads, other models, all R/T/backend combinations, end-to-end quality/performance. Existing MTP component results are not counted as full ordinary integration proof.
