from pathlib import Path
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/inference-qwen-static-fp8-20261025';V=W/'verification';S=W/'source'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
def build():
    plan=b.read(V/'app-recipe.json')
    for item in [*plan['common_inputs'],plan['native'],plan['runtime']]:assert b.pin(Path(item['path']))==item
    sources=[b.pin(p)for p in sorted(S.rglob('*'))if p.is_file()]+[b.pin(V/'consumer.cc')]
    save(V/'app2/source-pins.json',sources)
    env=b.environment(plan['compile'][0]);b.execute(plan['compile'],V/'app2/compile',env,150)
    data=b.read(V/'app2/compile/dependencies.json')['Data'];inputs=[]
    for name in [data['Source'],*data['Includes']]:
        p=Path(name)
        if p.is_relative_to(R):inputs.append(b.pin(p))
        assert not p.is_relative_to(R/'engine'),p
        assert not p.is_relative_to(R/'tests'),p
    for rel in ['engine/models/qwen35/main.cc','engine/models/qwen35/prepared_roles.h',
                'engine/models/qwen35/projection_binding.h','tests/tools/qwen_static_fp8_case.h',
                'tests/compute_models/static_fp8_reference_fixture.h']:
        assert any(Path(x['path'])==S/rel for x in inputs),rel
    save(V/'app2/compile/repository-inputs.json',inputs)
    b.execute(plan['link'],V/'app2/link',env,90)
    native=Path(plan['native']['path']);os.link(native,V/'app2/link'/native.name)
    save(V/'app2/link/ready.json',dict(image=b.pin(V/'app2/link/component.exe'),app=b.pin(V/'app2/compile/unit.obj'),native=b.pin(native)))
    for item in sources:assert b.pin(Path(item['path']))==item
def run():
    plan=b.read(V/'app-recipe.json')
    for item in [*b.read(V/'app2/link/ready.json').values(),*plan['common_inputs']]:assert b.pin(Path(item['path']))==item
    env=b.environment(plan['compile'][0]);env['PATH']=str(V/'app2/link')+';'+b.read(Path(plan['runtime']['path']))['PATH']
    env['HF_HUB_OFFLINE']=env['TRANSFORMERS_OFFLINE']='1'
    b.execute(plan['process_argv'],V/'app2/run',env,120)
    result=json.loads((V/'app2/run/stdout.log').read_text().strip().splitlines()[-1]);assert result['status']=='PASS'
    save(V/'app2/run/result.json',result);print(json.dumps(result))
if __name__=='__main__':{'build':build,'run':run}[sys.argv[1]]()
