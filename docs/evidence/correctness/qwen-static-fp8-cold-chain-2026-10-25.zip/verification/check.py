"""Authorized focused private Python/host checks; reuse current caches."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/inference-qwen-static-fp8-20261025';V=W/'verification';S=W/'source'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def support():
    for name in ['engine/models/qwen35/geometry.py','engine/models/qwen35/nf4_state.py',
        'engine/models/qwen35/model_geometry.h','engine/models/qwen35/nf4_state.h',
        'tests/tools/qwen_geometry_fixture.h','tests/tooling/fixtures/qwen_nf4_quant_state.json']:
        for base in [W/'before',S]:
            p=base/name;p.parent.mkdir(parents=True,exist_ok=True)
            if not p.exists():p.write_bytes((R/name).read_bytes())

def py():
    support()
    env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
    b.execute([sys.executable,str(V/'python_suite.py')],V/'python2',env,120)

def host():
    support()
    compiler=b.read(R/'.scratch/inference-participant-failure-20261025/implementation/recipe.json')['compile'][0]
    env=b.environment(compiler)
    folder=V/'host2/compile'
    command=[compiler,'/nologo','/std:c++latest','/EHsc','/W4','/WX','/utf-8','/permissive-',
        '/Zc:__cplusplus','/O2','/MD','/DHYLE_STATIC','/I'+str(R/'include'),'/sourceDependencies',
        str(folder/'dependencies.json'),str(S/'tests/tools/qwen_prepared_roles_test.cc'),
        '/Fo'+str(folder/'unit.obj'),'/Fe'+str(folder/'checks.exe'),'/link','/INCREMENTAL:NO',
        str(R/'.scratch/build-compute-v2-dev/bin/hyle_error.lib')]
    save(V/'host2/source-pins.json',[b.pin(p)for p in sorted(S.rglob('*'))if p.is_file()])
    b.execute(command,folder,env,120)
    dependency=b.read(folder/'dependencies.json')['Data']
    inputs=[]
    for name in [dependency['Source'],*dependency['Includes']]:
        p=Path(name)
        if p.is_relative_to(R):inputs.append(b.pin(p))
        assert not p.is_relative_to(R/'engine')
    save(folder/'repository-inputs.json',inputs)
    b.execute([str(folder/'checks.exe'),str(V/'host2/fixtures')],V/'host2/run',env,120)

if __name__=='__main__':{'py':py,'host':host}[sys.argv[1]]()
