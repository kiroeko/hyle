"""Run actual private standard unittest module once, pin its actual imports."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import unittest

sys.dont_write_bytecode=True
V=Path(__file__).resolve().parent;S=V.parent/'source'
p=S/'tests/tooling/qwen_hf_roles_test.py'
spec=importlib.util.spec_from_file_location('private_hf_roles_test',p)
test=importlib.util.module_from_spec(spec);spec.loader.exec_module(test)
imports=[]
for module in [test.roles,test.roles.geometry,test.roles.nf4_state]:
    path=Path(module.__file__).resolve()
    assert path.is_relative_to(S),path
    imports.append(dict(module=module.__name__,path=str(path),bytes=path.stat().st_size,
        sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(test))
summary=dict(status='PASS'if result.wasSuccessful()else'FAIL',tests=result.testsRun,
    failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),imports=imports,
    GPU=False,HTTP=0)
(V/'python2/imports-and-result.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(json.dumps(summary),flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
