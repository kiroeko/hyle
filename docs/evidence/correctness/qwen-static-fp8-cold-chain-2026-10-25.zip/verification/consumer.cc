#include "../source/engine/models/qwen35/main.cc"
#include "../source/tests/tools/qwen_static_fp8_case.h"
int main(int argc,char **argv){try{if(argc!=2)throw std::runtime_error("component OUTPUT_DIRECTORY");return qwen_static_fp8_case::run(argv[1]);}catch(const std::exception &e){std::cerr<<"static_fp8_component_failure="<<e.what()<<"\n";return 1;}}
