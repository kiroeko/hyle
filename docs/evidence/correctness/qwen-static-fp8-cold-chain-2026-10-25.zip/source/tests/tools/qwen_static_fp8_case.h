#pragma once
#include "../compute_models/static_fp8_reference_fixture.h"
#include "qwen_geometry_fixture.h"

// Synthetic software-reader component. This does not authenticate any model
// payload or claim execution of a complete quantized model.
namespace qwen_static_fp8_case {
namespace q=qwen35;
namespace f=static_fp8_reference_test;
inline void require(bool condition,const char *message) {
  if(!condition)throw std::runtime_error(message);
}
inline int run(const std::filesystem::path &directory) {
  std::filesystem::create_directories(directory);
  const auto geometry=q::read_model_geometry("geometry 32 64 3 1 1 32 32 32 1 1 32 32 4 16 10000 0.000001 0 0 grouped \"A\"");
  const f::Case reference;
  const auto initial=reference.data(2);
  const auto payload=reference.payloads(initial);
  const auto body_path=std::filesystem::absolute(directory/"component.bin");
  const auto manifest_path=directory/"weights.tsv";
  std::ofstream body(body_path,std::ios::binary),manifest(manifest_path,std::ios::binary);
  require(bool(body)&&bool(manifest),"cannot create bounded static FP8 fixture");
  manifest<<q::prepared::role_signature<<'\n'<<std::string(64,'c')<<'\n'
      <<qwen_test::geometry_line(geometry)<<'\n'<<q::prepared::static_fp8_policy_line<<'\n';
  std::uint64_t offset=0;
  const auto append=[&](const std::string &name,std::string_view type,const std::vector<std::int64_t> &shape,
                       const std::vector<std::byte> &bytes) {
    manifest<<name<<'\t'<<type<<'\t'<<shape.size();for(auto d:shape)manifest<<'\t'<<d;
    manifest<<'\t'<<std::quoted(body_path.string())<<'\t'<<offset<<'\t'<<bytes.size()<<'\n';
    body.write(reinterpret_cast<const char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()));
    offset+=bytes.size();
  };
  for(const auto &[name,parameter]:q::prepared::parameter_inventory(false,geometry)) {
    if(name=="lm_head.weight") {
      append(name,"F8_E4M3",parameter.shape,payload[1]);
      append("lm_head.input_scale","F32",{},payload[2]);
      append("lm_head.weight_scale","F32",{},payload[3]);
    } else append(name,"BF16",parameter.shape,
        std::vector<std::byte>(q::prepared::physical_bytes("BF16",parameter.shape)));
  }
  body.close();manifest.close();require(bool(body)&&bool(manifest),"static FP8 fixture write failed");
  auto roles=q::read_weight_roles(manifest_path,false);
  auto backend=q::take(q::Backend::create({.primary=q::BackendKind::kCpu}));
  std::vector<q::c::LeasePool> weight_pools;std::map<std::string,q::LoadedWeight> bank;
  const auto loading=q::load_selected_weight_roles(roles,backend,bank,weight_pools);
  (void)loading;
  auto projections=q::prepare_projection_bindings(bank,false,geometry);
  require(std::holds_alternative<q::ModelOptStaticFp8Projection>(projections.at("lm_head.weight")),
      "original loader lost the static FP8 typed principal");
  const auto &projection=std::get<q::ModelOptStaticFp8Projection>(projections.at("lm_head.weight"));
  require(projection.codes->description.data_type()==q::Type::kFloat8E4M3FN &&
      projection.activation_scale->description.data_type()==q::Type::kFloat32 &&
      projection.weight_scale->description.data_type()==q::Type::kFloat32,
      "static FP8 import changed original storage types");
  q::GraphAssembly assembly(backend);q::Recipe recipe(bank,projections,assembly,geometry,2);
  const auto x=recipe.input(reference.descriptions[0]);
  const auto y=recipe.scores(x,"lm_head.weight");recipe.publish(y);
  const auto sa=recipe.operands.at(projection.activation_scale),sw=recipe.operands.at(projection.weight_scale);
  const auto graph=q::take(std::move(recipe.builder).finish());
  require(graph.node_count()==13,"static FP8 twelve-node equation plus score widening changed");
  const auto score_cast=q::take(graph.producer(y));
  const auto *score_op=q::take(graph.operation(score_cast)).get_if<q::c::Cast>();
  require(score_op && score_op->output_type==q::Type::kFloat32,"scores lost explicit F32 widening");
  const auto bf16=q::take(graph.node_input(score_cast,0));
  const auto bf16_node=q::take(graph.producer(bf16));
  const auto *store=q::take(graph.operation(bf16_node)).get_if<q::c::Cast>();
  require(store && store->output_type==q::Type::kBFloat16,"projection lost BF16 store");
  const auto sw_node=q::take(graph.producer(q::take(graph.node_input(bf16_node,0))));
  const auto sa_node=q::take(graph.producer(q::take(graph.node_input(sw_node,0))));
  require(q::take(graph.node_input(sw_node,1))==sw && q::take(graph.node_input(sa_node,1))==sa,
      "static FP8 ordered original SA then SW operands changed");
  const std::array shape{q::g::ShapeBinding{recipe.last_row,1}};
  const std::array variants{q::g::ExactShapeVariant{shape}};
  auto compiled=q::take(backend.compile(graph,assembly.constants,assembly.options({
      .shape_policy=q::g::CompileShapePolicy::kFiniteExact,.exact_variants=variants,.constants=assembly.constants})));
  compiled.executable=q::take(compiled.executable.exact_variant(0));
  compiled.report=q::take(compiled.report.exact_variant(0));
  const auto facts=q::take(hyle::inference::prepare_output(compiled,y));
  require(facts.description.data_type()==q::Type::kFloat32 &&
      facts.description.dimensions()[0]==2 && facts.description.dimensions()[1]==3,
      "static FP8 scores shape/type changed");
  auto queues=q::take(hyle::inference::prepare_queue_bindings(backend.queue_bindings(),compiled.report));
  const auto bindings=hyle::inference::queue_span(queues);
  auto run=q::take(compiled.executable.create_invocation());q::check(run.prepare_resources());
  std::array<q::Tensor,2> inputs;std::array<q::c::ReadLease,2> retained;
  q::c::LeasePool outputs;
  if(facts.caller_owned())outputs=q::take(q::c::LeasePool::create(
      q::take(backend.resource_for(facts.storage)),512,{.max_blocks=2}));
  std::array<std::array<float,6>,2> observed{};
  const auto read=[&](const q::c::ReadLease &lease) {
    std::array<float,6> values{};
    q::check(backend.read(q::take(lease.view()),std::as_writable_bytes(std::span(values))));return values;
  };
  double maximum_error=0;
  for(unsigned index=0;index<2;++index) {
    auto data=reference.data(2+index);data.w=initial.w;data.sa=initial.sa;data.sw=initial.sw;
    inputs[index]=q::Tensor(backend.device(),reference.descriptions[0]);
    inputs[index].write<std::byte>(reference.payloads(data)[0]);q::check(run.bind(x,inputs[index].read()));
    if(facts.caller_owned()) {
      q::check(run.bind(y,facts.description,q::take(outputs.allocate(q::take(facts.description.required_bytes())))));
    }
    q::check(run.prepare_replay(bindings,{.mode=q::g::ReplayMode::kCommands,.host_wait=q::g::HostWaitPolicy::kAllow}));
    {auto done=q::take(run.submit(bindings));q::check(done.wait());}
    retained[index]=q::take(hyle::inference::retain_output(run,facts));observed[index]=read(retained[index]);
    const auto expected=reference.oracle(data);
    for(std::size_t n=0;n<expected.size();++n) {
      maximum_error=(std::max)(maximum_error,std::abs(double(observed[index][n])-expected[n]));
      require(std::isfinite(observed[index][n]) && double(observed[index][n])==expected[n],
          "static FP8 graph differs from existing independent software oracle");
    }
    q::check(run.reset());
    require(read(retained[0])==observed[0],"retained old scores changed after reset/replay");
  }
  require(q::take(projection.codes->description.required_bytes())==96,
      "tiny original E4 bank expanded during import");
  std::ofstream route(directory/"route.tsv");route<<"step\tprovider\timplementation\toperation\n";
  for(std::size_t step=0;step<compiled.report.step_count();++step) {
    const auto s=q::take(compiled.report.step(step));route<<step<<'\t'<<s.provider.name<<'\t'<<s.implementation.value();
    for(std::size_t n=0;n<s.node_count;++n)route<<'\t'<<q::c::operation_name(q::take(graph.operation_kind(q::take(compiled.report.step_node(step,n)))));
    route<<'\n';
  }
  std::cout<<"{\"status\":\"PASS\",\"scope\":\"synthetic_static_fp8_V2_loader_binding_recipe_Graph\",\"physical_roles\":"<<roles.selected.size()
      <<",\"graph_nodes\":13,\"graph_calls\":2,\"checked_values\":12,\"max_abs_error\":"<<maximum_error
      <<",\"old_output_lease_preserved\":true,\"caller_owned\":"<<(facts.caller_owned()?"true":"false")
      <<",\"workspace_bytes\":"<<compiled.report.workspace_bytes()<<",\"original_artifact_payload_bytes\":0,\"full_model\":false,\"GPU\":false,\"HTTP\":0}\n";
  return 0;
}
} // namespace qwen_static_fp8_case
