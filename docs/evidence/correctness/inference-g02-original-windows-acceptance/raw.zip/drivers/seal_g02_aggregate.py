from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile,xml.etree.ElementTree as ET

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';evidence=root/'evidence/correctness'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
air=read(base/'ce16-air/receipt.json');assert air['verdict']=='PASS_FINITE_SOURCE_STATIC_SHARED' and sha(base/'ce16-air/qualification-raw.zip')==air['raw_zip_sha256']
with zipfile.ZipFile(base/'ce16-air/qualification-raw.zip') as z:
 assert z.testzip() is None
 for mode in ('source','static','shared'):
  r=json.loads(z.read(mode+'/result.json'));assert r['state']=='TERMINAL_FINITE_PASS'
  t=ET.fromstring(z.read(mode+'/public.xml'));assert t.attrib['tests']=='2' and t.attrib['failures']=='0' and t.attrib['errors']=='0' and not t.findall('.//skipped')
  if mode=='source':
   t=ET.fromstring(z.read(mode+'/provider.xml'));assert t.attrib['tests']=='4' and t.attrib['failures']=='0' and t.attrib['errors']=='0' and not t.findall('.//skipped')
dest=evidence/'inference-g02-vulkan-alias-phase-air';dest.mkdir(exist_ok=False);shutil.copyfile(base/'ce16-air/qualification-raw.zip',dest/'raw.zip');(dest/'receipt.json').write_text(json.dumps(air,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

cuda_path=base/'remaining-windows-cases-1/cuda/result.json';cuda=read(cuda_path);follow_path=base/'remaining-windows-cases-1/cuda-fixture-followup/result.json';follow=read(follow_path);build=read(base/'remaining-windows-build-1/result.json')
assert cuda['state']==follow['state']=='TERMINAL_ALL_DEFAULT_CASES_EXECUTED' and cuda['case_count']==len(cuda['cases'])==804
assert cuda['pass_cases']==797 and cuda['skipped_cases']==7 and follow['pass_cases']==7 and not follow['skipped_cases']
assert cuda['executable']['sha256']==follow['executable']['sha256']==sha(Path(cuda['executable']['path']))
assert follow['original_result_sha256']==sha(cuda_path)
old_skips=[r for r in cuda['cases'] if r['verdict']=='SKIPPED'];assert [r['name'] for r in old_skips]==[r['name'] for r in follow['cases']]
for row in cuda['cases']+follow['cases']:
 assert row['exit_code']==0 and row['verdict'] in ('PASS','SKIPPED')
 if row['verdict']=='SKIPPED':assert any('HYLE_D5_QWEN35_FIXTURE' in s.get('message','') for s in row['skipped']);continue
 t=ET.parse(row['xml']).getroot();assert t.attrib['tests']=='1' and t.attrib['failures']=='0' and t.attrib['errors']=='0' and not t.findall('.//skipped')
delta=subprocess.check_output(['git','diff','--name-only',cuda['product_source'],'HEAD'],text=True).splitlines();product=[p for p in delta if not p.startswith(('docs/','evidence/','tests/'))]
assert set(product)=={'cmake/HyleDependencyLock.json','src/compute_provider_ggml_vulkan/region.cc','third_party/ggml_vulkan_runtime/NOTICE.md','third_party/ggml_vulkan_runtime/patches.json'},product
vk=read(evidence/'inference-g02-vulkan-windows-default-acceptance/receipt.json');assert vk['effective_original_default_cases']==851 and vk['verdict'].startswith('PASS_ALL_851')
dest=evidence/'inference-g02-original-windows-acceptance';dest.mkdir(exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ('resume-windows-1','resume-windows-2','remaining-windows-build-1','remaining-windows-cases-1/cuda','remaining-windows-cases-1/cuda-fixture-followup'):
  for p in sorted((base/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(base).as_posix())
 for name in ('windows-resource-interruption.json','current-model-fixture.json','aggregate-acceptance-preparation.json','seal_g02_aggregate.py'):z.write(base/name,'drivers/'+name)
windows={'kind':'G02_ORIGINAL_THREE_WINDOWS_GATES','verdict':'PASS_ALL_ORIGINAL_SELECTED_DEFAULTS','original_monolithic_ctest_executed':False,'coverage':'Same original default GTest sets, one case/process, serial. No original case/shape/assertion removed. Missing fixture and incorrect private test references fixed explicitly, prior skips/failures preserved.','cuda':{'default':804,'initial_pass':797,'initial_fixture_skip':7,'actual_followup_pass':7,'effective_pass':804,'fixture':follow['real_fixture'],'executable':cuda['executable'],'original_result_sha256':sha(cuda_path),'followup_sha256':sha(follow_path),'execution':cuda['execution']},'vulkan':{'default':851,'effective_pass':851,'acceptance':'evidence/correctness/inference-g02-vulkan-windows-default-acceptance/receipt.json','sha256':sha(evidence/'inference-g02-vulkan-windows-default-acceptance/receipt.json')},'original_rebound_build':build,'cuda_reuse':'Only subsequent product deltas are Vulkan provider export handling, bounded native sin/cos and Vulkan manifest/notice hashes. CUDA exe exact SHA retained, all original main CUDA objects reused/verified and no CUDA math/route change; no repeat804.','subsequent_product_files':product,'old_interruption_and_all_failures_retained':True,'limits':'Correctness/build gates only; no whole-library test, performance or token/s. Actual CE15/16 Air qualification is separate.','raw_zip_sha256':sha(dest/'raw.zip')}
(dest/'receipt.json').write_text(json.dumps(windows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

names=['inference-g02-common','inference-g02-exact-read-groups-host','inference-g02-exact-read-groups-delivery','inference-g02-native-page-joint-source-stage','inference-g02-native-page-joint-long-stage','inference-g02-native-page-joint-risk-stage','inference-g02-native-page-joint-host-sanitizers','inference-g02-native-page-joint-sdk-stage','inference-g02-native-page-joint-windows-compile','inference-g02-original-windows-acceptance','inference-g02-vulkan-alias-phase-windows-stage','inference-g02-vulkan-windows-default-acceptance','inference-g02-vulkan-alias-phase-air']
records=[]
for name in names:
 p=evidence/name/'receipt.json';r=read(p)
 if 'raw_zip_sha256' in r:assert sha(p.parent/'raw.zip')==r['raw_zip_sha256']
 if 'raw_sha256' in r:
  candidates=[q for q in p.parent.glob('*.zip') if sha(q)==r['raw_sha256']];assert candidates
 records.append({'path':p.relative_to(root).as_posix(),'sha256':sha(p)})
dest=evidence/'inference-g02-aggregate-acceptance';dest.mkdir(exist_ok=False)
aggregate={'kind':'G02_FINITE_GOAL_ITEM_AGGREGATE','verdict':'PASS_G02_COMPLETE','evidence_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Original common CPU+CUDA multi-context/multi-queue and exact guard retirement, plus original public CPU+Apple/Vulkan exact page native composition. Actual original Windows gates and finite CE15/16 defect qualification complete. Goal item only, no blanket close of G04/G05 registry candidates.','authorities':['docs/implementation/tasks/graph/inference-g02-multi-queue-batch.md','docs/implementation/tasks/graph/inference-g02-native-paged-terminal.md','docs/implementation/tasks/compute/inference-g04-g05-cache-attention-domain.md'],'requirements':{'common':'Original per-lane Context/Queue/staging, full layout/node set, qualified shared metadata, F16/BF16 realCPU→CUDA→CPU, publicexactframes, three deliveries/hostrisks/36OOM and actual affectedAir interface.','exact_guards':'Original multiple exact ReadLease guards, unreferenced blocks writable, partial admission rollback and unknown native completion release only at actual retirement; source/static/shared/threehostsan/actualnativeconsumers.','native_joint':'Apple F16/BF16 andVulkan F16, D64/128/256, page16single/mixedtwo-requests, reorder/duplicate/tail/sentinel, twoattentionnodes/fixedactiveoutput; originalsource216,long1152episodes,fourSDK,sixhostsan,Windowscompile and precise refusal/failure/retirement checks.','remaining_windows':'CUDA804+Vulkan851 originaldefault correctness/build gates now pass, no removed tests or loosened tolerance; test-only numerical-reference/IQ1 fixture defects explicitly resolved and old failures preserved.','ce15_ce16':'Immutable provider2b60 independent export roots and bounded sin/cos: Windowsnormalfourtargeted, original851,andactualAirsource/static/shared publicphase/alias plusprivatemetadata risk.','engineering_performance':'OriginalP0 cold/warm/metadata/queue/copy/privateUNKNOWN accounting retained. Newcopyonlyconflictingexport, F32sin/cosboundedreductionthreeFMA/noextra dispatch. No newP1 required, originalencodednoSinCos/noexportconflict branch unmodified.'},'seven_gates':{k:'PASS' for k in ['scope','architecture','correctness','delivery','usability_docs','red_team','engineering_performance']},'records':records,'performance_tier':'P0','retained_limits':['No whole-mode symmetry, capture, overlap or token/s claim','VulkanBF16joint not enlarged beyond original admittedG02F16 domain','LeaseUsePool worstO(guards^2), metadata prepare/waits and vendorprivate upperbounds remain charged/UNKNOWN forG06/G10','Original host sanitizer models do not sign GPUdriver/shader/privatepool; source metadata alias qualification separately actual','All historicalFAIL/SKIP/resource interruption/stale-generated-input guard/elapsed retained; no budget reset'],'goal_progress_after_acceptance':{'completed_items':['G01','G02','G03'],'count':3,'total':10,'not_workload_percentage':True},'registry_unchanged':True,'stop':'Stop repeating originalG02finitegates. Resume currentG04/G05CUDAqualification, thenG06-G10. Reopen only reproducible admitted journey/permission/retirement/cost/delivery defects or named new consumer mechanism.'}
(dest/'receipt.json').write_text(json.dumps(aggregate,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(aggregate['verdict'],len(records),'evidence records')
