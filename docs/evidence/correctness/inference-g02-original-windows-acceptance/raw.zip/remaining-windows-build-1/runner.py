from pathlib import Path
import hashlib,json,os,subprocess,sys,time

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';prep=base/'resume-windows-2';build=Path('C:/h7/inference-g02-impacted')
out=base/'remaining-windows-build-1';out.mkdir(exist_ok=False)
j=json.loads((prep/'prepare.json').read_text());reuse=json.loads((prep/'native-reuse.json').read_text())
assert j['state']=='TERMINAL_PREPARATION_ONLY' and reuse['dry_plan_exit']==0 and len(reuse['reused'])==169
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
product_source=j['source_commit']
delta=subprocess.check_output(['git','diff','--name-only',product_source,'HEAD'],text=True).splitlines()
assert all(p.startswith(('docs/','evidence/')) for p in delta),'product changed since configured immutable input'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=prep/'reuse-build.ninja'
assert sha(manifest)==reuse['reused_manifest_sha256']
assert sha(build/'build.ninja')==j['frozen_manifest']['original_sha256']
for obj in reuse['reused']:assert sha(Path(obj['output']))==obj['sha256']
record={'state':'SETUP','product_source':product_source,'evidence_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'source_delta_docs_evidence_only':delta,'commands':[],'reused_native_objects':len(reuse['reused']),
 'reuse_receipt':str(prep/'native-reuse.json'),'reuse_receipt_sha256':sha(prep/'native-reuse.json'),
 'resource_policy':'Heavy tasks serial, below-normal priority, Ninja4, original validation CUDA target compile pool1; no GPU test concurrently',
 'scope':'Two original G02 selected test targets, necessary current input rebind only; original pressure interruption and completed gates preserved.'}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
env={k.upper():v for k,v in os.environ.items()}
for line in subprocess.check_output(['cmd','/d','/c',str(prep/'vs-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
args=['ninja','-C',str(build),'-f',str(manifest),'-j','4','hyle_graph_route_cuda_tests','hyle_graph_route_vulkan_tests']
started=time.monotonic()
with (out/'build.log').open('w',encoding='utf-8') as stream:
 child=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
 record.update(state='RUNNING',pid=child.pid,command=args);save();print(json.dumps({'state':record['state'],'pid':child.pid,'command':args}),flush=True)
 code=child.wait()
record.update(state='TERMINAL_PASS' if code==0 else 'TERMINAL_FAIL',exit_code=code,elapsed_seconds=time.monotonic()-started)
for obj in reuse['reused']:assert sha(Path(obj['output']))==obj['sha256'],'reused object unexpectedly changed'
record['reused_objects_unchanged_after_build']=True
if code==0:
 record['artifacts']=[{'route':r,'path':str(build/f'bin/hyle_graph_route_{r}_test.exe'),'sha256':sha(build/f'bin/hyle_graph_route_{r}_test.exe')} for r in ('cuda','vulkan')]
save();print(json.dumps(record),flush=True)
if code:print((out/'build.log').read_text(errors='replace')[-5000:],flush=True)
raise SystemExit(code)
