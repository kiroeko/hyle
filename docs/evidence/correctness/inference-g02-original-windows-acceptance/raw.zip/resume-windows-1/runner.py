from pathlib import Path
import hashlib,json,os,subprocess,sys,time

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';out=base/'resume-windows-1';build=Path('C:/h7/inference-g02-impacted')
out.mkdir(exist_ok=True)
air=json.loads((root/'.scratch/inference-gaps/g04-g05/apple-encoded-p1/5/launch.json').read_text())
assert air['state']=='TERMINAL' and air['remote_state']['state']=='TERMINAL'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip(),'freeze source and evidence first'
assert not (out/'prepare.json').exists(),'preserve original preparation attempts'
record={'state':'SETUP','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'stages':[],'scope':'Only original two G02 selected test targets; config and dry plan first. Native CUDA pool1/max4 build jobs. No product build or test launched by this preparation.'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():(out/'prepare.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();(out/'runner.py').write_bytes(Path(__file__).read_bytes())
batch=out/'vs-env.cmd'
batch.write_text('@echo off\ncall "C:\\Program Files\\Microsoft Visual Studio\\18\\Enterprise\\Common7\\Tools\\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul\nif errorlevel 1 exit /b 1\nset\n')
env=os.environ.copy()
for line in subprocess.check_output(['cmd','/d','/c',str(batch)],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k]=v
env['CMAKE_BUILD_PARALLEL_LEVEL']='4'
record['identity']={'compiler':subprocess.run(['cl'],env=env,text=True,capture_output=True).stderr.strip(),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,uuid,compute_cap,memory.used,memory.total','--format=csv,noheader'],text=True).strip()}
assert '19.50.35728' in record['identity']['compiler'] and 'RTX 4070' in record['identity']['gpu']
record['original_cache_sha256']=sha(build/'CMakeCache.txt')
hook=out/'job-pools.cmake'
hook.write_text('''if(PROJECT_NAME STREQUAL "hyle")
  function(g02_bound_cuda_targets dir)
    get_property(ts DIRECTORY "${dir}" PROPERTY BUILDSYSTEM_TARGETS)
    foreach(t IN LISTS ts)
      get_target_property(ss "${t}" SOURCES)
      foreach(s IN LISTS ss)
        if(s MATCHES "[.]cu($|>)")
          set_property(TARGET "${t}" PROPERTY JOB_POOL_COMPILE g02_cuda_compile)
          break()
        endif()
      endforeach()
    endforeach()
    get_property(ds DIRECTORY "${dir}" PROPERTY SUBDIRECTORIES)
    foreach(d IN LISTS ds)
      g02_bound_cuda_targets("${d}")
    endforeach()
  endfunction()
  function(g02_pool_finish)
    set_property(GLOBAL APPEND PROPERTY JOB_POOLS g02_cuda_compile=1)
    g02_bound_cuda_targets("${CMAKE_SOURCE_DIR}")
  endfunction()
  cmake_language(DEFER CALL g02_pool_finish)
endif()
''')
record['validation_hook']={'path':str(hook),'sha256':sha(hook),'purpose':'Validation-only scheduling cap; no compile flags, product source, public build logic or test semantics change'}
def run(stage,args):
 t=time.monotonic();log=out/(stage+'.log')
 with log.open('w',encoding='utf-8') as f:
  child=subprocess.Popen(args,env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  record.update(state='RUNNING',stage=stage,pid=child.pid);save();print(stage,child.pid,flush=True);code=child.wait()
 row={'stage':stage,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-t,'log':str(log)};record['stages'].append(row);save();print(json.dumps(row),flush=True)
 if code:
  record['state']='TERMINAL_FAIL';save();print(log.read_text(errors='replace')[-3000:]);raise SystemExit(code)
run('configure',['cmake','-S',str(root),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+hook.as_posix(),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'])
run('dry-plan',['ninja','-C',str(build),'-n','hyle_graph_route_cuda_tests','hyle_graph_route_vulkan_tests'])
text=(out/'dry-plan.log').read_text(errors='replace');counts={x:text.count(x) for x in ('Building CXX object','Building C object','Building CUDA object','Linking','Generating','Performing build step')}
record.update(state='TERMINAL_PREPARATION_ONLY',counts=counts,cache_sha256=sha(build/'CMakeCache.txt'),build_manifest_sha256=sha(build/'build.ninja'))
record['cuda_pool_assignments']=(build/'build.ninja').read_text().count('pool = g02_cuda_compile')
save();print(json.dumps({k:record[k] for k in ('state','source_commit','counts','cuda_pool_assignments')}),flush=True)
