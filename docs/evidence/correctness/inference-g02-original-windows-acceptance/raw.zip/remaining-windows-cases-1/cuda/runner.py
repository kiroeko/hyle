from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET

root=Path.cwd();base=root/'.scratch/inference-gaps/g02';prep=base/'resume-windows-2'
build=Path('C:/h7/inference-g02-impacted');out=base/'remaining-windows-cases-1'
assert sys.argv[1] in ('cuda','vulkan')
route=sys.argv[1];folder=out/route;folder.mkdir(parents=True,exist_ok=False)
build_record=json.loads((base/'remaining-windows-build-1/result.json').read_text())
assert build_record['state']=='TERMINAL_PASS'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
exe=build/f'bin/hyle_graph_route_{route}_test.exe'
record={'state':'SETUP','route':route,'product_source':build_record['product_source'],
 'evidence_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'original_ctest_recipe':['ctest','--test-dir',str(build),'-C','Release','--output-on-failure','--no-tests=error','-L',f'^graph_route_{route}$','-LE','headers'],
 'execution':'Complete default GTest set from the same rebuilt executable, one case per process, serial; original monolithic ctest command not claimed executed',
 'executable':{'path':str(exe),'sha256':sha(exe),'mtime_ns':exe.stat().st_mtime_ns,'bytes':exe.stat().st_size},'cases':[]}
def save():(folder/'result.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
save();(folder/'runner.py').write_bytes(Path(__file__).read_bytes())
child=None
def failed(kind,error,tb):
 record.update(state='OBSERVER_ERROR_CHILD_MAY_RUN' if child and child.poll() is None else 'TERMINAL_SETUP_OR_ANALYSIS_FAIL',error=repr(error));save()
 sys.__excepthook__(kind,error,tb)
sys.excepthook=failed
env={k.upper():v for k,v in os.environ.items() if not k.upper().startswith('GTEST_')}
for line in subprocess.check_output(['cmd','/d','/c',str(prep/'vs-env.cmd')],text=True).splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1)
  if not k.upper().startswith('GTEST_'):env[k.upper()]=v
working=build/f'tests/graph_route_{route}'
listing=subprocess.run([str(exe),'--gtest_list_tests'],cwd=working,env=env,text=True,capture_output=True)
(folder/'list.stdout.log').write_text(listing.stdout,encoding='utf-8')
(folder/'list.stderr.log').write_text(listing.stderr,encoding='utf-8')
assert listing.returncode==0,listing.stderr
names=[];disabled=[];suite=None
for line in listing.stdout.splitlines():
 name=line.split('#',1)[0].strip()
 if not name:continue
 if not line.startswith((' ','\t')) and name.endswith('.'):
  suite=name;continue
 if line.startswith((' ','\t')) and suite:
  full=suite+name
  if any(part.startswith('DISABLED_') for component in full.split('.') for part in component.split('/')):disabled.append(full)
  else:names.append(full)
assert names and len(names)==len(set(names))
record.update(expected_cases=names,disabled_default=disabled,case_count=len(names),list_exit=listing.returncode)
save()
for index,name in enumerate(names):
 assert exe.stat().st_mtime_ns==record['executable']['mtime_ns'] and exe.stat().st_size==record['executable']['bytes'],'test executable changed during fixed run'
 prefix=folder/f'{index:04d}';log=prefix.with_suffix('.log');xml=prefix.with_suffix('.xml')
 args=[str(exe),'--gtest_filter='+name,'--gtest_color=no','--gtest_output=xml:'+str(xml)]
 started=time.monotonic()
 with log.open('w',encoding='utf-8') as stream:
  child=subprocess.Popen(args,cwd=working,env=env,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
  record.update(state='RUNNING',current_case=name,pid=child.pid);save();print(route,index+1,len(names),name,child.pid,flush=True)
  code=child.wait()
 row={'name':name,'command':args,'exit_code':code,'elapsed_seconds':time.monotonic()-started,'log':str(log),'xml':str(xml)}
 if xml.is_file():
  tree=ET.parse(xml).getroot();cases=tree.findall('.//testcase')
  row['xml_tests']=tree.attrib.get('tests');row['xml_failures']=tree.attrib.get('failures');row['xml_errors']=tree.attrib.get('errors')
  row['skipped']=[{'message':s.attrib.get('message'),'text':s.text} for c in cases for s in c.findall('skipped')]
  row['verdict']='SKIPPED' if row['skipped'] else 'PASS' if code==0 and len(cases)==1 and tree.attrib.get('failures')=='0' and tree.attrib.get('errors')=='0' else 'FAIL'
 else:row['verdict']='FAIL_NO_XML'
 record['cases'].append(row);save()
 if code or row['verdict'].startswith('FAIL'):
  record['state']='TERMINAL_FAIL';save();print(log.read_text(errors='replace')[-4000:],flush=True);raise SystemExit(code or 1)
assert sha(exe)==record['executable']['sha256'],'test executable changed during fixed run'
record.update(state='TERMINAL_ALL_DEFAULT_CASES_EXECUTED',pass_cases=sum(r['verdict']=='PASS' for r in record['cases']),skipped_cases=sum(r['verdict']=='SKIPPED' for r in record['cases']))
save();print(json.dumps({k:record[k] for k in ('state','route','case_count','pass_cases','skipped_cases')}),flush=True)
