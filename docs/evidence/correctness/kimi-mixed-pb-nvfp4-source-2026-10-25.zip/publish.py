"""Archive this one finite CPU check; no build, model, download or new checks."""
from pathlib import Path
import hashlib
import json
import zipfile

WORK=Path(__file__).resolve().parent
ROOT=WORK.parents[1]
PUBLIC=ROOT/'docs/evidence/correctness/kimi-mixed-pb-nvfp4-source-2026-10-25.json'
ZIP=PUBLIC.with_suffix('.zip')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def encode(v):return (json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
sources=read(WORK/'source-pins.json')['files']
for e in sources:
    assert pin((ROOT/e['path']).read_bytes())==e['after']
    assert pin((WORK/'source'/e['path']).read_bytes())==e['after']
summary=read(WORK/'cpu1/summary.json')
assert summary['status']=='PASS' and summary['xml']==dict(tests=1,failures=0,errors=0,skipped=0)
source=read(WORK/'source-facts.json')
header=Path(source['header']['path'])
assert pin(header.read_bytes())=={k:source['header'][k] for k in ('bytes','sha256')}
original=json.loads(header.read_bytes())
assert all(original[k]==v for k,v in source['roles'].items())
report=dict(status='MIXED_STORED_F32_PB_AND_SELECTED_NVFP4_SOURCE_CPU_PASS',date='2026-10-25',
    change='Original layer12 attention f_a E4/F32-SF roles and selected expert W1 NVFP4 quartet roles now have one finite ordinary Graph source/lease consumer. Existing import_float8_block128_weight, Float8BlockLinear, GroupedNvfp4Linear and bounded CpuSupply/map are reused.',
    integration='Root independently reviewed and applied the three exact checked source paths before the CPU check. Packaging did not rebuild or rerun them.',sources=sources,
    scope=dict(repository=source['source_repository'],revision=source['source_revision'],shard='model-00013-of-000096.safetensors',header=source['header'],
        source_metadata_roles=18,original_numeric_payload_bytes=0,
        original_PB='Full E4[128,7168], independent raw F32[1,1,56,1] SF. Singleton removal is an explicit metadata view, then one cold bit-preserving import.',
        original_experts='Original W1 N3072/K3584 quartet roles for experts0..3; this consumer explicitly selects first N3 rows/full K3584. Original WG/IG are F32 scalars (rank0).',
        upstream='Distinct attention f_a BF16[1,7168] and post-routed-down/norm BF16[1,1,3584] inputs. No fabricated128-to3584 edge, complete router/down/norm/layer, or full model is claimed.'),
    math=dict(PB='Explicit existing stored-F32 software reader: dynamic group128 divide/floor1e-4, F32 scale and normalization. It is not power2, A16, CT BF16 pre-round or an inference from the PB_WO name.',
        experts='Existing ModelOpt NVFP4 quartet equation with independent per-expert WG/IG, group16 A QDQ, original BF16 A/W store points and F32 accumulation/BF16 output. This is separate from CT local-NVFP4 divisor math.',
        reference='Unchanged existing scalar E4/E2M1 and explicit F32/BF16 helpers. Sparse generated weights permit exact endpoint expectations; wrong A16/power2, shared IG, omitted A/W BF16 stores differ on these fixtures.'),
    geometry=dict(PB_N=128,PB_K=7168,expert_prefix_N=3,expert_K=3584,selected_capacity=2,global_domain=896,generations=[[0,1],[2,3]],
        PB_cold_imports=1,BF16_endpoints=268,successful_submissions=2,resident_logical_bytes_per_generation=15696),
    layout='The existing Layout now accepts positive plain dense source ranks0..7 and prepends capacity to the original dimensions. Existing rank2 resident descriptions are unchanged. Original rank0 WG/IG naturally become[E], eliminating the two artificial{1,1} planes and two Graph reshapes; no original rank1 format is flattened implicitly.',
    actual=summary,
    assertions=['Exact PB E4 bytes and every original F32 SF bit after cold import.',
        'Invalid PB SF span and invalid expert IG span reject source admission.',
        'Same CpuBatch supplies all four compressed quartet planes plus the checked global-to-local map.',
        'Two resident generations keep10 blocks; dropping public batch handles keeps10 Invocation-held blocks, dropping Invocations retires all10; escaped old output readers remain valid.'],
    verification='Root ran one existing CPU test TU with MSVC/W4/WX, cached core/native closure, one exact filter and120s watchdog. First CPU attempt passed. No SDK/core/provider rebuild, GPU, HTTP or performance measurement.',
    filter='CpuE8M0WeightImport.KimiMixedOriginalSourceRolesKeepDistinctReadersAndSelectedGenerations',
    limits=['All numerical bodies are explicitly generated original-shape fixtures. Exact cached header identities/spans and genuine readonly leases do not authenticate original publisher numeric contents.',
        'Only finite PB and W1 projections with two upstream boundaries are checked; no complete Kimi FFN/layer/Model, original quality, new MTP, native GPU or TPS qualification.',
        'Revision1 was a private unrun source proposal. Revision2 preserves the original scalar ranks in the existing common test supply. The generated values and numerical oracle are byte-identical between these proposals.',
        'Unchanged frozen source trees, SDK, binaries and model bodies are omitted; precise dependency/source/object pins and actual commands/raw/XML are retained.'])
members={}
def add(p,n):
    assert n not in members
    members[n]=p.read_bytes()
for n in ['source.patch','source-pins.json','scope.json','source-facts.json','patch-check.json','revision2-source-checks.json','check_cpu.py','publish.py']:
    add(WORK/n,n)
for e in sources:
    add(WORK/'source'/e['path'],'source/'+e['path'])
    if e['before']:add(WORK/'before'/e['path'],'before/'+e['path'])
for n in ['source-pins.json','scope.json']:add(WORK/'r1'/n,'history-r1/'+n)
for n in ['summary.json','tests.xml','frozen-project.json','actual-dependencies.json','link-inputs.json','runtime.json']:
    add(WORK/'cpu1'/n,'cpu1/'+n)
for phase in ['compile','link','run']:
    for n in ['command.json','process.json','stdout.log','stderr.log']:add(WORK/'cpu1'/phase/n,'cpu1/'+phase+'/'+n)
add(WORK/'cpu1/compile/dependencies.json','cpu1/compile/dependencies.json')
add(header,'original-source/header.json')
for n in ['e8m0_weight_import_fixture.h','nvfp4_reference_fixture.h']:
    p=ROOT/'tests/compute_models'/n
    members['original-source/'+n+'.pin.json']=encode(dict(path=p.relative_to(ROOT).as_posix(),**pin(p.read_bytes())))
add(ROOT/'.scratch/inference-e4-append-implementation-20261025/check_finite.py','runner-dependencies/check_finite.py')
add(ROOT/'scripts/hyle_environment.py','runner-dependencies/hyle_environment.py')
members['report-without-archive.json']=encode(report)
manifest=[dict(path=n,**pin(b)) for n,b in sorted(members.items())]
members['archive-manifest.json']=encode(dict(files=manifest,excludes='Manifest does not list itself.'))
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(members.items()):
        i=zipfile.ZipInfo(n,date_time=(2026,10,25,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,b)
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
    for e in manifest:assert pin(z.read(e['path']))=={k:e[k] for k in ('bytes','sha256')}
report['archive']=dict(path=ZIP.relative_to(ROOT).as_posix(),**pin(ZIP.read_bytes()),members=len(members),logical_bytes=sum(map(len,members.values())),CRC_and_member_SHA256_verified=True)
PUBLIC.write_bytes(encode(report))
result=dict(public=dict(path=PUBLIC.relative_to(ROOT).as_posix(),**pin(PUBLIC.read_bytes())),archive=report['archive'])
(WORK/'public-manifest.json').write_bytes(encode(result));print(json.dumps(result,indent=2))
