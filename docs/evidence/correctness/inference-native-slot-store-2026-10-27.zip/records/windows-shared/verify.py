"""One changed common CXX TU, one existing shared closure, eleven bounded cases."""
from pathlib import Path
import importlib.util,json,os,shutil,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
R=W.parents[2]
P=R/'.scratch/inference-slot-source-fallback-20261027'
spec=importlib.util.spec_from_file_location('slot_source_cached',P/'build.py')
cached=importlib.util.module_from_spec(spec);spec.loader.exec_module(cached)
m,b=cached.m,cached.b
EXPECTED={
 'src/graph/slots_region.cc':'9b739a59c2ff7dbd841238587a2bdea0039e60b0a7ec8dc75ea61b8516873c8c',
 'include/hyle/graph/slots.h':'49cc56a3fc05ce7a8c92dec5af8f2b532a7fa6ddc8e969b87d10e545c89871a8',
 'src/graph/slots_region.h':'edc897d5c0265a22228c159638def875bbf7c2d4acee7fc02c971f0d150ea622'}
GROUPS=[('cpu','GraphSlotsExecution.*',7),('cuda','GgmlCudaIndexedStateGraph.*',3),
        ('writer','GraphSlotsCudaExecution.*',1)]
def plan():
    assert not (W/'plan.json').exists()
    ready=b.read(P/'ready5.json')
    assert b.pin(P/'ready5.json')['sha256']=='6a0c2a4a53110c6f693d48392f6cd409d0f3a212b2de971f87d66fde3f976f72'
    for path,sha in EXPECTED.items():assert b.pin(R/path)['sha256']==sha,path
    for row in ready['compiled']:
        b.exact(row['object'])
        if row['name']!='store':b.exact(row['source'])
    inputs=b.read(ready['inputs']['path']);assert len(inputs)==226
    for row in inputs:b.exact(row)
    before=next(x for x in ready['compiled'] if x['name']=='store')
    recipe=Path(before['object']['path']).parent/'command.json'
    command=m.command(recipe,R/'src/graph/slots_region.cc',W/'compile/store')
    for flag in ['/O2','/W4','/WX','/DHYLE_STATIC']:assert flag in command,flag
    canonical=W/'canonical-recipe.json';b.save(canonical,{'command':command})
    freeze=m.c.closure([str(R/'src/graph/slots_region.cc')],[canonical])
    b.save(W/'source-freeze.json',freeze)
    sources=[]
    for path in dict.fromkeys([x['source']['path'] for x in ready['compiled']]+[str(R/p) for p in EXPECTED]):
        q=Path(path);dst=W/'sources'/q.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,dst)
        sources.append({'original':b.pin(q),'saved':b.pin(dst)})
    old_failures=[]
    for rel in ['run-cpu/stdout.log','results-cpu.xml','run-indexed/stdout.log','results-indexed.xml','results3-indexed.xml','run4-fallback/stdout.log','results4-fallback.xml']:
        q=P/rel
        if q.exists():
            dst=W/'oldfailure'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,dst)
            old_failures.append({'original':b.pin(q),'saved':b.pin(dst),'scope':'Previous batch only, not a result of this image.'})
    b.save(W/'plan.json',dict(status='SOURCE_FROZEN_NOT_BUILT',source=b.pin(R/'src/graph/slots_region.cc'),
       source_expected=EXPECTED,source_freeze=b.pin(W/'source-freeze.json'),sources=sources,
       recipe=b.pin(recipe),command=command,before=before['object'],old_failures=old_failures,
       baseline=dict(ready=b.pin(P/'ready5.json'),inputs=ready['inputs'],runtime=ready['runtime'],command=b.pin(P/'link5/command.json')),
       baseline_compiled=ready['compiled'],groups=GROUPS,CXX_TUs=1,images=1,
       SDK_NVCC_engine_perf_downloads=0,
       compatibility='Both headers differ from ready5 only in comments. Public/private wrapper, extension table, Node, Recipe and GraphState layouts unchanged; only StoreBinding pimpl and common implementation changed. Reuse 225 unchanged link inputs, replace one common object.',
       unverified='This shared run does not execute the new native/no-Queue path. Apple/Vulkan native checks are separate.'))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def environment(p):
    h=b.helper();cl=p['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def build():
    p=b.read(W/'plan.json');assert not (W/'compile').exists() and not (W/'ready.json').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for row in frozen:b.exact(row)
    inputs=b.read(p['baseline']['inputs']['path'])
    for row in inputs:b.exact(row)
    h,env=environment(p)
    result=h.execute(p['command'],env,W/'compile/store',timeout=180)
    dep=b.read(W/'compile/store/dependencies.json')['Data']
    actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    for row in actual:
        q=Path(row['path'])
        if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
            assert own[b.key(q)]['sha256']==row['sha256'],str(q)
    b.save(W/'compile/store/actual-dependencies.json',actual)
    obj=b.pin(W/'compile/store/unit.obj');replacement=b.key(p['before']['path'])
    image=W/'bin/shared-slot-test.exe';args=[];changed=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg)==replacement:arg=obj['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert changed==1;image.parent.mkdir(parents=True,exist_ok=True)
    linked=h.execute(args,env,W/'link',timeout=120)
    final=[obj if b.key(x['path'])==replacement else x for x in inputs]
    b.save(W/'link-inputs.json',final)
    rt=b.read(p['baseline']['runtime']['path']);native=rt['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;assert not alias.exists();os.link(native['path'],alias)
    rt['native_cpu_hardlink']=b.pin(alias)
    rt['PATH']=str(image.parent)+os.pathsep+rt['PATH']
    b.save(W/'runtime.json',rt)
    for row in frozen:b.exact(row)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),
      compiled=[dict(source=p['source'],object=obj,process=result,actual_dependencies=b.pin(W/'compile/store/actual-dependencies.json'))],
      link=linked,inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json'),
      baseline=p['baseline'],CXX_TUs=1,images=1))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def run():
    p=b.read(W/'plan.json');ready=b.read(W/'ready.json');b.exact(ready['image'])
    h,env=environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH'];groups=[]
    for name,selection,count in GROUPS:
        xml=W/('results-'+name+'.xml')
        process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+selection,
            '--gtest_output=xml:'+str(xml)],env,W/('run-'+name),timeout=90)
        root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
        assert int(root.attrib['tests'])==count and int(root.attrib['failures'])==0
        assert len(cases)==count and all(x.attrib.get('status')=='run' and not list(x) for x in cases)
        groups.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml)))
        b.save(W/'partial-results.json',groups);print('PASSED',name,count,flush=True)
    b.save(W/'summary.json',dict(status='SHARED_PATH_ELEVEN_PASS',tests=11,failures=0,groups=groups,
      ready=b.pin(W/'ready.json'),CXX_TUs=1,images=1,SDK_NVCC_engine_perf_downloads=0,
      native_no_queue_executed=False,scope=p['compatibility'],unverified=p['unverified']))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
