"""Retry only the one common TU after root's local shadow-name correction."""
from pathlib import Path
import importlib.util,json,os,shutil,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;A=W/'attempt2'
spec=importlib.util.spec_from_file_location('shared_first',W/'verify.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m,R=old.b,old.m,old.R
SHA='154b6d92d4a6b1e2a49411cdb2b801a1c13610cc3acf6854ed4a560c41de29f8'
def plan():
    assert not (A/'plan.json').exists()
    first=b.read(W/'plan.json');source=R/'src/graph/slots_region.cc'
    assert b.pin(source)['sha256']==SHA
    for path,sha in first['source_expected'].items():
        if path!='src/graph/slots_region.cc':assert b.pin(R/path)['sha256']==sha,path
    command=m.command(first['recipe']['path'],source,A/'compile/store')
    recipe=A/'canonical-recipe.json';b.save(recipe,{'command':command})
    freeze=m.c.closure([str(source)],[recipe]);b.save(A/'source-freeze.json',freeze)
    saved=A/'sources/src/graph/slots_region.cc';saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,saved)
    b.save(A/'plan.json',dict(status='ROOT_SHADOW_FIX_FROZEN',command=command,source=b.pin(source),saved_source=b.pin(saved),
      source_freeze=b.pin(A/'source-freeze.json'),baseline=first['baseline'],before=first['before'],groups=old.GROUPS,
      first_plan=b.pin(W/'plan.json'),first_failed_command=b.pin(W/'compile/store/command.json'),
      first_failed_log=b.pin(W/'compile/store/stdout.log'),
      correction='Root renamed only native scratch local bytes to scratch_bytes; no ABI or contract change.',
      compatibility=first['compatibility'],unverified=first['unverified']))
    print('PLAN',json.dumps(b.pin(A/'plan.json')),flush=True)
def build():
    p=b.read(A/'plan.json');assert not (A/'compile').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for row in frozen:b.exact(row)
    inputs=b.read(p['baseline']['inputs']['path'])
    for row in inputs:b.exact(row)
    h,env=old.environment(p);process=h.execute(p['command'],env,A/'compile/store',timeout=180)
    dep=b.read(A/'compile/store/dependencies.json')['Data']
    actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    for row in actual:
        q=Path(row['path'])
        if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
            assert own[b.key(q)]['sha256']==row['sha256'],str(q)
    b.save(A/'compile/store/actual-dependencies.json',actual)
    obj=b.pin(A/'compile/store/unit.obj');image=A/'bin/shared-slot-test.exe';args=[];changed=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg)==b.key(p['before']['path']):arg=obj['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert changed==1;image.parent.mkdir(parents=True,exist_ok=True)
    linked=h.execute(args,env,A/'link',timeout=120)
    final=[obj if b.key(x['path'])==b.key(p['before']['path']) else x for x in inputs]
    b.save(A/'link-inputs.json',final)
    rt=b.read(p['baseline']['runtime']['path']);native=rt['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    rt['native_cpu_hardlink']=b.pin(alias);rt['PATH']=str(image.parent)+os.pathsep+rt['PATH'];b.save(A/'runtime.json',rt)
    for row in frozen:b.exact(row)
    b.save(A/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=[dict(name='store',source=p['source'],object=obj,
      process=process,actual_dependencies=b.pin(A/'compile/store/actual-dependencies.json'))],link=linked,
      inputs=b.pin(A/'link-inputs.json'),runtime=b.pin(A/'runtime.json'),plan=b.pin(A/'plan.json'),
      original_baseline=p['baseline'],first_failure=p['first_failed_log'],CXX_TUs=1,CXX_attempts=2,images=1))
    print('READY',json.dumps(b.pin(A/'ready.json')),flush=True)
def run():
    p=b.read(A/'plan.json');ready=b.read(A/'ready.json');b.exact(ready['image'])
    h,env=old.environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH'];groups=[]
    for name,selection,count in old.GROUPS:
        xml=A/('results-'+name+'.xml')
        process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+selection,
            '--gtest_output=xml:'+str(xml)],env,A/('run-'+name),timeout=90)
        root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
        assert int(root.attrib['tests'])==count and int(root.attrib['failures'])==0
        assert len(cases)==count and all(x.attrib.get('status')=='run' and not list(x) for x in cases)
        groups.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml)))
        b.save(A/'partial-results.json',groups);print('PASSED',name,count,flush=True)
    b.save(A/'summary.json',dict(status='SHARED_PATH_ELEVEN_PASS',tests=11,failures=0,groups=groups,
      ready=b.pin(A/'ready.json'),CXX_TUs=1,CXX_attempts=2,images=1,SDK_NVCC_engine_perf_downloads=0,
      native_no_queue_executed=False,scope=p['compatibility'],unverified=p['unverified'],
      first_failure=p['first_failed_log']))
    print('SUMMARY',json.dumps(b.pin(A/'summary.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
