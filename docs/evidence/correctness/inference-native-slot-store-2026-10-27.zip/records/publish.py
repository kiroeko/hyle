"""Publish three finite native-Store checks without compiling or executing."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,sys,zipfile,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
S=W/'windows-shared';A=S/'attempt2';V=W/'windows-vulkan'
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    path=Path(path);raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=sha(raw))
def exact(row):
    got=pin(row['path']);assert all(got[k]==row[k] for k in ['bytes','sha256']),row['path']
def relative(path):return Path(path).relative_to(R).as_posix()
def publish():
    out=R/'docs/evidence/correctness/inference-native-slot-store-2026-10-27.json'
    archive=out.with_suffix('.zip');assert not out.exists() and not archive.exists()
    shared=read(A/'summary.json');sr=read(A/'ready.json');sp=read(A/'plan.json')
    vulkan=read(V/'summary.json');vr=read(V/'ready.json');vp=read(V/'plan2.json')
    apple=read(W/'receipt.json');ar=read(W/'records/ready4.json');ap=read(W/'plan4.json')
    assert shared['tests']==11 and vulkan['tests']==3 and apple['result']['tests']==3
    assert shared['failures']==vulkan['failures']==0 and apple['result']['status']=='PASS'
    assert len(sr['compiled'])==1 and len(vr['compiled'])==6 and ar['compiled_TUs']==8
    payload={};fileorigins={};catalog=[];bank={}
    def add(name,raw,origin):
        assert name not in payload or payload[name]==raw,name
        payload[name]=raw;fileorigins[name]=origin
        bank.setdefault(sha(raw),raw)
    def file(name,path):add(name,Path(path).read_bytes(),str(path))
    # Snapshot bytes are taken only from saved source archives, not substituted
    # from the current checkout for old executions.
    for group,folder in [('windows-shared/initial',S/'sources'),('windows-shared/final',A/'sources'),
                         ('windows-vulkan/initial',V/'sources'),('windows-vulkan/corrected',V/'sources2')]:
        for q in sorted(folder.rglob('*')):
            if q.is_file():file('source/'+group+'/'+q.relative_to(folder).as_posix(),q)
    applebytes={}
    for name in ['source.zip','overlay2.zip','overlay3.zip','overlay4.zip']:
        with zipfile.ZipFile(W/name) as z:
            assert z.testzip() is None
            for item in z.infolist():
                if item.filename.startswith('source/') and not item.is_dir():
                    raw=z.read(item.filename);applebytes[item.filename[7:]]=raw;bank.setdefault(sha(raw),raw)
    af=read(W/'source-freeze4.json')
    for row in af:
        raw=applebytes[row['path']];assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
        add('source/apple/final/'+row['path'],raw,'Layered original Mac source.zip plus overlays2/3/4; exact final source-freeze4 identity')
    def archive_records(prefix,folder):
        for q in sorted(folder.rglob('*')):
            if not q.is_file() or any(x in q.relative_to(folder).parts for x in ['sources','sources2','bin','oldfailure']):continue
            if q.suffix.lower() not in ['.json','.log','.xml','.py']:continue
            file('records/'+prefix+'/'+q.relative_to(folder).as_posix(),q)
    archive_records('windows-shared',S);archive_records('windows-vulkan',V)
    exact(apple['remote_records'])
    with zipfile.ZipFile(W/'records.zip') as z:
        assert z.testzip() is None
        for info in z.infolist():
            if info.is_dir():continue
            assert Path(info.filename).suffix.lower() in ['.json','.log','.xml','.py','.cc','.h','.d','.map'],info.filename
            raw=z.read(info.filename)
            local=W/'records'/info.filename
            assert local.read_bytes()==raw,info.filename
            add('records/apple/'+info.filename,raw,'Original records.zip '+apple['remote_records']['sha256'])
    file('records/apple/receipt.json',W/'receipt.json')
    for name in ['prepare.py','run-initial.py','run.py','run3.py','run4.py','run5.py','collect.py','finalize-local.py',
                 'update-common.py','update-common3.py','update-float.py','abi-boundaries.json']:
        file('records/apple/local-driver/'+name,W/name)
    file('records/publish.py',Path(__file__))
    # Retain all project source/header facts for both common Windows variants.
    # Resolve by content digest from saved snapshots, with no checkout fallback.
    for label,freeze in [('windows-shared/initial',read(S/'source-freeze.json')),
                         ('windows-shared/final',read(A/'source-freeze.json')),
                         ('windows-vulkan/final',read(V/'source-freeze2.json'))]:
        rows=[]
        for row in freeze:
            q=Path(row['path'])
            if not q.is_relative_to(R) or q.is_relative_to(R/'.scratch'):continue
            raw=bank.get(row['sha256']);assert raw is not None,'Missing saved original source '+str(q)
            assert len(raw)==row['bytes']
            name='source-closure/'+label+'/'+q.relative_to(R).as_posix()
            add(name,raw,'Verified source/header digest from original saved source snapshots')
            rows.append(dict(path=q.relative_to(R).as_posix(),archive_member=name,bytes=row['bytes'],sha256=row['sha256']))
        catalog.append(dict(execution=label,files=rows))
    for label,ready in [('windows-shared',sr),('windows-vulkan',vr)]:
        exact(ready['image']);exact(ready['inputs']);exact(ready['runtime'])
        for row in read(ready['inputs']['path']):exact(row)
        for unit in ready['compiled']:
            assert unit['process']['exit']==0;exact(unit['object'])
            assert unit['source']['sha256'] in bank,unit['source']
            for dep in read(unit['actual_dependencies']['path']):
                # Original source identity can intentionally differ from HEAD.
                if Path(dep['path']).is_relative_to(R) and not Path(dep['path']).is_relative_to(R/'.scratch'):
                    assert dep['sha256'] in bank,dep['path']
        baseline=sp['baseline'] if label=='windows-shared' else vp['baseline']
        for key in ['ready','inputs','command','runtime']:
            file('records/'+label+'/reuse/baseline-'+key+'.json',baseline[key]['path'])
    groups=[]
    for group,xmlpath,process in [
      ('windows-cpu',A/'results-cpu.xml',shared['groups'][0]['process']),
      ('windows-cuda-indexed-and-fallback',A/'results-cuda.xml',shared['groups'][1]['process']),
      ('windows-cuda-writer',A/'results-writer.xml',shared['groups'][2]['process']),
      ('windows-vulkan',V/'results.xml',vulkan['process']),
      ('macos-apple',W/'records/results2.xml',apple['result']['process'])]:
        root=ET.parse(xmlpath).getroot();cases=root.findall('./testsuite/testcase')
        expected={'windows-cpu':7,'windows-cuda-indexed-and-fallback':3,'windows-cuda-writer':1,'windows-vulkan':3,'macos-apple':3}[group]
        assert len(cases)==expected and int(root.attrib['tests'])==expected and int(root.attrib['failures'])==0
        assert all(x.attrib.get('status')=='run' and not list(x) for x in cases) and process['exit']==0
        groups.append(dict(group=group,tests=expected,process=process,cases=[x.attrib for x in cases],results=pin(xmlpath)))
    assert sum(x['tests'] for x in groups)==17
    # Stable metadata and original failed source are kept; no executable/cache
    # payload can enter the archive through this allowlist.
    forbidden={'.obj','.o','.exe','.dll','.dylib','.pdb','.lib','.a','.spv','.bin'}
    assert all(Path(name).suffix.lower() not in forbidden for name in payload)
    manifest=[dict(path=name,bytes=len(raw),sha256=sha(raw),origin=fileorigins[name]) for name,raw in sorted(payload.items())]
    add('manifest.json',(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode(),'Generated member manifest; excludes itself')
    archive.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted(payload.items()):z.writestr(name,raw)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and sorted(z.namelist())==sorted(payload)
        for name,raw in payload.items():
            got=z.read(name);assert len(got)==len(raw) and sha(got)==sha(raw),name
    result=dict(schema=1,batch='inference-native-slot-store-20261027',status='SEVENTEEN_FINITE_GRAPH_TEST_OBSERVATIONS_PASS',
      recorded_at=datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8))).isoformat(),
      scope='One shared StoreBinding owner across original Compute Queue and actual native Apple/Vulkan ExecutionSource consumers; finite Graph/lease/retirement/reset correctness only.',
      actual_results=dict(tests=17,failures=0,skipped=0,final_test_processes=5,distinct_actual_images=3,groups=groups,
        apple_small_variants=4,note='17 GTest observations across separate systems and actual images, not one universal image or throughput sample.'),
      images=[dict(system='Windows shared CPU/CUDA',image=sr['image'],ready=pin(A/'ready.json'),summary=pin(A/'summary.json'),
        common_source=sr['compiled'][0]['source'],compile_TUs=1,compile_attempts=2,link_attempts=1,link_inputs=226),
       dict(system='Windows Vulkan',image=vr['image'],ready=pin(V/'ready.json'),summary=pin(V/'summary.json'),
        common_source=vr['compiled'][0]['source'],compile_TUs=6,compile_attempts=7,link_attempts=2,link_inputs=143),
       dict(system='macOS Apple Mac16,12',image=ar['image'],ready=pin(W/'records/ready4.json'),receipt=pin(W/'receipt.json'),
        compile_unique_TUs=8,actual_link_map=pin(W/'records/linked-object-map.json'),compiled_sources=[dict(path=x['source'],sha256=next(r['sha256'] for r in af if r['path']==x['source'])) for x in ap['jobs'] if x.get('source')])],
      source_identity=dict(catalog=catalog,apple_final_freeze=apple['final_source_freeze'],
        common_variants=[dict(sha256='154b6d92d4a6b1e2a49411cdb2b801a1c13610cc3acf6854ed4a560c41de29f8',execution='Windows shared11 actual source'),
          dict(sha256='40d4ffad41303f89693b01a58c493f158e7b93e10658d9b7e34b4e946a054351',execution='Windows Vulkan and macOS Apple actual source')],
        common_difference='final40d4 only explicitly default-initializes preexisting Find aggregate fields; same layout and already-value-initialized semantics. shared11 was not rerun using40d4 and is not relabelled as that source.',
        apple_float_final='cd7913045dba73c1f16ad81919335e8225f1fb29561d40efa72dc73ad7c3d3a4',
        retained_originals='All compiled product sources and required project headers are from saved snapshots/archive overlays and checked by digest; old failed or passed source is not replaced by a current checkout snapshot.'),
      retained_failures=[
       dict(system='Windows shared',stage='first common compile',cause='MSVC /WX shadowed bytes local C4456/C2220',correction='Rename scratch_bytes only; source9b739 original retained.'),
       dict(system='Windows Vulkan',stage='first Store compile',cause='Missing region_access.h declaration include',correction='Vulkan owner added include only; source02db original retained, a072 corrected.'),
       dict(system='Windows Vulkan',stage='first link',cause='Validation recipe added current lease object without replacing baseline explicit resource_leases object; LNK2005',correction='Scratch link-only recipe removes the old explicit lease OBJ; no product change or recompile.'),
       *[dict(system='macOS Apple',**x) for x in apple['result']['failures']]],
      reuse=dict(windows_shared='Reuse225 unchanged members of the earlier226-input image, compile only common StoreBinding; one exact CPU ggml DLL hardlink. Headers add comments, pimpl unchanged.',
        windows_vulkan='Reuse original137-input CPU/Vulkan cached closure; remove Model main; replace current resources/batch/leases and two changed Vulkan objects, add current slots/common/newStore/lowerer/test/gtest. Final143 inputs. No SDK/shader/native ABI rebuild.',
        apple=apple['closure'],apple_locked_MLX_indexing=apple['locked_MLX_indexing'],
        old_failure_scope='Windows shared oldfailure/ copied from the previous batch is excluded; this receipt retains this batch actual failures only.'),
      verified=['Shared CPU/CUDA original eleven Graph ownership/projected source/metadata carrier/reset/retirement tests pass on source154b.',
        'Vulkan F32 dense and BF16 padded generated Gather rows write selected exact destination leases, preserve source/sentinel/gaps, and recover owners across reset; two-byte item is rejected cold.',
        'Apple three tests/four variants preserve F32/F16/BF16 checked-Gather bytes and padding, result retirement and reset authority; final ordinary float Gather lowerer uses its actual typed cold port rather than the FP8-only marker.',
        'One original StoreBinding pimpl owns leases and metadata in all consumer routes; no second executor, Compute Queue, pool payload, SDK or source checkout was introduced.'],
      limits=['Native Store in this batch supports only4-byte-aligned item copy geometry. Non4-byte items are an implementation restriction, not an absolute GPU hardware limitation; no wider copy permission is fabricated.',
        'CPU default GGML padded source-Gather remains a known real gap: the default route may select a lowerer that materializes the whole bank, while its projected-read inspector correctly refuses that permission. Native CPU tests do not establish that default path works.',
        'Ordinary/MTP complete engines and causal-conv are not wired to this native Store path. No engine inference, model task quality, speed/latency/memory benchmark, server, HTTP/download, SDK or shader rebuild.',
        'No native GPU fault injection or other platform/test matrix. Apple failed warmup run was a real cold rejection before native work, not a passed result.',
        'CMake source wiring is archived where frozen, but these were minimal retained-closure builds, not full CMake/package/install reconfiguration.'],
      performance_claim=False,engine_runs=0,model_runs=0,HTTP=0,SDK_shader_rebuilds=0,native_fault_injection=False,
      archive=dict(**pin(archive),archive_path=relative(archive),members=len(payload),verified_member_bytes_and_sha256=True,
        excludes=['EXE','OBJ/O','DLL/dylib','LIB/A','PDB','SPIRV/shader payload','SDK source','model payload'],files=manifest))
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(receipt=pin(out),archive=pin(archive),tests=17,members=len(payload)),indent=2))
if __name__=='__main__':publish()
