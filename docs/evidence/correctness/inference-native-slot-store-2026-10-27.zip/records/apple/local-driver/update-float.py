from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
name='src/compute_route_apple/apple_mature_float.cc'
with zipfile.ZipFile(W/'source.zip') as z:(W/'failed-float-warmup.cc').write_bytes(z.read('source/'+name))
raw=(R/name).read_bytes();digest=hashlib.sha256(raw).hexdigest()
assert digest=='cd7913045dba73c1f16ad81919335e8225f1fb29561d40efa72dc73ad7c3d3a4'
frozen=read(W/'source-freeze3.json')
for row in frozen:
 if row['path']==name:row.update(sha256=digest,bytes=len(raw))
save(W/'source-freeze4.json',frozen)
plan=read(W/'plan3.json')
for job in plan['jobs']:
 if job['tag']=='compile-float':
  job['tag']='compile2-float'
  job['command']=[a.replace('/float.o','/float2.o') for a in job['command']]
 if job['tag']=='link':
  job['tag']='link2';job['command']=[a.replace('/float.o','/float2.o').replace('/slot-store-test','/slot-store-test2').replace('/image.map','/image2.map') for a in job['command']]
plan['preserved_attempts'].append('run1 all3tests rejected cold descriptor-only warmup; exact original float source and image retained')
save(W/'plan4.json',plan)
script=(W/'run4.py').read_text().replace("'plan3.json'","'plan4.json'").replace("'source-freeze3.json'","'source-freeze4.json'").replace("'ready3.json'","'ready4.json'").replace("'slot-store-test'","'slot-store-test2'").replace("'run1'","'run2'").replace("'results.xml'","'results2.xml'").replace("'summary.json'","'summary2.json'")
(W/'run5.py').write_text(script,encoding='utf-8')
with zipfile.ZipFile(W/'overlay4.zip','x',zipfile.ZIP_DEFLATED) as z:
 z.writestr('source/'+name,raw)
 for n in ('failed-float-warmup.cc','source-freeze4.json','plan4.json','run5.py'):z.write(W/n,n)
print(digest)
