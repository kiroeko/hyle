from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-native-slot-store-20261027')
def read(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def execute(tag,args,timeout):
 d=W/tag;d.mkdir(exist_ok=False);p=read(W/'plan.json');env=os.environ.copy();env.update(p['environment'])
 save(d/'command.json',dict(command=args,cwd=str(W),environment=p['environment']))
 start=time.perf_counter()
 with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:
  process=subprocess.Popen(args,cwd=W,env=env,stdout=out,stderr=err)
  save(d/'running.json',dict(pid=process.pid))
  timedout=False
  try:code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:timedout=True;process.kill();code=process.wait(timeout=5)
 result=dict(pid=process.pid,exit=code,seconds=time.perf_counter()-start,timeout=timedout)
 save(d/'process.json',result);print(tag,json.dumps(result),flush=True)
 if code or timedout:raise RuntimeError(tag+' failed; no retry')
 return result
def build():
 plan=read(W/'plan.json');frozen={str(W/'source'/x['path']):x for x in read(W/'source-freeze.json')}
 for n,x in frozen.items():assert pin(Path(n))['sha256']==x['sha256'],n
 inputs=[Path(a) for a in plan['jobs'][-1]['command'] if a.endswith(('.o','.a','.dylib')) and not a.startswith(str(W)+'/')]
 save(W/'reused-inputs.json',[pin(p) for p in inputs])
 save(W/'hardware.json',dict(uname=subprocess.check_output(['uname','-a'],text=True),
  model=subprocess.check_output(['sysctl','-n','hw.model'],text=True),
  clang=subprocess.check_output(['/usr/bin/c++','--version'],text=True),
  sw_vers=subprocess.check_output(['sw_vers'],text=True)))
 results=[]
 for job in plan['jobs']:
  result=execute(job['tag'],job['command'],job['timeout']);results.append(dict(tag=job['tag'],process=result))
  if '-c' in job['command']:
   raw=Path(job['command'][job['command'].index('-MF')+1]).read_text()
   save(W/job['tag']/'dependencies.json',dict(makefile=raw))
   used=[]
   for name in re.split(r'\s+',raw.replace('\\\n',' ').split(': ',1)[1].strip()):
    if name.startswith(str(W)+'/source/'):
     assert name in frozen,name;actual=pin(Path(name));assert actual['sha256']==frozen[name]['sha256'],name;used.append(actual)
    elif '/source/include/hyle/' in name or '/source/src/' in name or '/source/engine/' in name:
     raise RuntimeError('old project shadow dependency: '+name)
   save(W/job['tag']/'actual-project-dependencies.json',used)
 save(W/'ready.json',dict(image=pin(W/'slot-store-test'),processes=results,compiled_TUs=plan['compiled_TUs'],SDK_builds=0))
def run():
 image=read(W/'ready.json')['image'];assert pin(Path(image['path']))==image
 result=execute('run1',[image['path'],'--gtest_filter=AppleSlotStore.*','--gtest_output=xml:'+str(W/'results.xml')],60)
 save(W/'summary.json',dict(process=result,scope=read(W/'plan.json')['scope'],performance_claim=False,quality_claim=False,HTTP=0))
if sys.argv[1:]==['build']:build()
elif sys.argv[1:]==['run']:run()
else:print('Explicit build or run only; no implicit retries.')
