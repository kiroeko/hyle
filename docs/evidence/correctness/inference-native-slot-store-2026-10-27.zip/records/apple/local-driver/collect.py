from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET,zipfile
W=Path('/Users/kiro/hyle-scratch/compute-unified/inference-native-slot-store-20261027')
def read(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
xml=ET.parse(W/'results2.xml').getroot()
assert int(xml.attrib['tests'])==3 and int(xml.attrib['failures'])==0 and int(xml.attrib['errors'])==0
plan=read(W/'plan4.json');ready=read(W/'ready4.json');assert pin(Path(ready['image']['path']))==ready['image']
src=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/_deps/mlx-91aee008db1a5528/source')
runtime=[src/'mlx/version.h',src/'mlx/backend/metal/indexing.cpp',src/'mlx/ops.cpp',src/'CMakeLists.txt',
 Path(plan['environment']['MLX_METAL_PATH'])]
identity=dict(MLX_locked_revision='1f8e74e3f12f31365464a6867c6579f0e9b29d85',MLX_lock_version='0.32.2',
 actual_version_header=(src/'mlx/version.h').read_text(),actual_files=[pin(p) for p in runtime],
 shared_libraries=subprocess.check_output(['otool','-L',ready['image']['path']],text=True),
 note='Actual SDK/source/library/metallib bytes pinned; no mutable checkout HEAD used as build identity.')
save(W/'runtime-identity.json',identity)
mapping=(W/'image2.map').read_text()
object_lines=mapping.split('# Object files:',1)[1].split('# Sections:',1)[0]
save(W/'linked-object-map.json',dict(raw=object_lines,source='actual final Mach-O link map',
 current_objects=[pin(W/(n+'.o')) for n in ('leases','resources','slots','slots_region','float2','native','store','test')],
 no_whole_archive=True,no_duplicate_ignore=True))
facts=dict(status='PASS',tests=3,small_variants=4,testcases=[x.attrib['name'] for x in xml.iter('testcase')],
 process=read(W/'run2/process.json'),image=ready['image'],compiled_unique_product_and_test_TUs=8,
 scope=plan['scope'],HTTP=0,SDK_builds=0,model_runs=0,performance_claim=False,
 failures=[dict(stage='initial driver after two compiler successes',reason='dependency path with /../ was not normalized before comparing frozen keys; script-only'),
  dict(stage='compile-slots_region',reason='Clang Werror missing facts initializer; original source retained'),
  dict(stage='compile2-slots_region',reason='Clang Werror missing lane initializer; original source retained'),
  dict(stage='run1',reason='all tests rejected cold descriptor-only warmup port; fixed ordinary Gather U8-only descriptor marker')],
 corrections='Common explicit aggregate default initialization keeps semantics/layout; Gather retains original typed checked-take mathematics and strides. No test relaxation.',
 unrun='No other tests, native GPU fault injection, model inference or performance benchmark in this batch.')
save(W/'final-summary.json',facts)
names=['plan.json','plan2.json','plan3.json','plan4.json','source-freeze.json','source-freeze2.json','source-freeze3.json','source-freeze4.json',
 'abi-boundaries.json','reused-inputs.json','hardware.json','ready3.json','ready4.json','results.xml','results2.xml','summary2.json',
 'runtime-identity.json','linked-object-map.json','final-summary.json','failed-slots_region.cc','failed-slots_region-attempt2.cc','failed-float-warmup.cc',
 'run.py','run2.py','run3.py','run4.py','run5.py']
for d in ('compile-leases','compile-resources','compile-slots','compile-slots_region','compile2-slots_region','compile3-slots_region',
 'compile-float','compile2-float','compile-native','compile-store','compile-test','link','link2','run1','run2'):
 names += [p.relative_to(W).as_posix() for p in (W/d).iterdir() if p.is_file()]
with zipfile.ZipFile(W/'records.zip','x',zipfile.ZIP_DEFLATED) as z:
 for n in names:
  p=W/n
  if p.is_file():z.write(p,n)
print(json.dumps(facts))
