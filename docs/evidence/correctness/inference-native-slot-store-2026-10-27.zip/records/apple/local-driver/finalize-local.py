from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent;D=W/'records'
def read(p):return json.loads(p.read_text())
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
runtime=read(D/'runtime-identity.json')
path='mlx/backend/metal/indexing.cpp'
locked=subprocess.check_output(['git','-C','C:/public/project-hyle/mlx','show',runtime['MLX_locked_revision']+':'+path])
expected=hashlib.sha256(locked).hexdigest();actual=next(x['sha256'] for x in runtime['actual_files'] if x['path'].endswith('/'+path))
assert expected==actual
mapping=read(D/'linked-object-map.json')['raw']
for name in ('leases','resources','slots','slots_region','float2','native','store','test'):
 assert '/inference-native-slot-store-20261027/'+name+'.o' in mapping,name
for line in mapping.splitlines():
 if 'libhyle_' in line:assert not any(x in line for x in ('(resource_leases','(native_region','(apple_mature_float')),line
receipt=dict(result=read(D/'final-summary.json'),remote_records=pin(W/'records.zip'),
 locked_MLX_indexing=dict(revision=runtime['MLX_locked_revision'],path=path,sha256=expected,actual_matches=True),
 final_source_freeze=pin(W/'source-freeze4.json'),final_plan=pin(W/'plan4.json'),
 closure='Actual image2.map contains all8 final current direct objects and no extracted old source member with matching resource_leases/native_region/apple_mature_float names. No whole-archive/duplicate-ignore.',
 harness_correction='First driver normalized ../ before frozen SHA lookup. Original script and failed attempts retained; already successful objects were not recompiled.',
 documentation_changed=False,git_commit_or_push=False)
(W/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',tests=3,variants=4,records=receipt['remote_records'],receipt=pin(W/'receipt.json'))))
