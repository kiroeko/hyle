from pathlib import Path
import difflib,hashlib,json,re,zipfile
R=Path(__file__).resolve().parents[2]
W=Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/inference-native-slot-store-20261027'
B=R/'.scratch/inference-paged-frame-20261026/mac'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
assert not (W/'plan.json').exists()
base=read(B/'plan.json'); command=next(j['command'] for j in base['jobs'] if j['tag']=='compile-resources')
specs=[('leases','src/compute/resource_leases.cc'),('resources','src/graph/resources.cc'),
 ('slots','src/graph/slots.cc'),('slots_region','src/graph/slots_region.cc'),
 ('float','src/compute_route_apple/apple_mature_float.cc'),('native','src/graph_route_apple/native_region.cc'),
 ('store','src/graph_route_apple/native_slot_store_region.cc'),('test','tests/graph_route_apple/slot_store_test.cc')]
roots=[R,R/'include',*[R/'src'/s for s in ('compute','graph','compute_batch','compute_provider_native','compute_stream','compute_route_apple','graph_route_apple')]]
files={}; todo=[R/p for _,p in specs]
while todo:
 p=todo.pop().resolve(); n=p.relative_to(R).as_posix()
 if n in files:continue
 raw=p.read_bytes();files[n]=raw
 for inc in re.findall(r'^\s*#\s*include\s*["<]([^">\r\n]+)[">]',raw.decode('utf-8-sig'),re.M):
  for d in [p.parent,*roots]:
   q=(d/inc).resolve()
   if q.is_file() and q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
    todo.append(q);break
jobs=[]
prefix=['-I'+REMOTE+'/source/include','-I'+REMOTE+'/source',*['-I'+REMOTE+'/source/src/'+p for p in ('compute','graph','compute_batch','compute_route_apple','graph_route_apple','compute_provider_native','compute_stream')]]
gtest='/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'
for tag,source in specs:
 args=[a for a in command if not(a.startswith('-I') and ('/source/include' in a or '/source/src/' in a or a.endswith('/source') or '/model' in a or a.endswith('/public')))]
 args=args[:1]+prefix+args[1:]
 if tag=='test':args=args[:1]+['-isystem',gtest]+args[1:]
 args[args.index('-c')+1]=REMOTE+'/source/'+source
 args[args.index('-o')+1]=REMOTE+'/'+tag+'.o'
 args[args.index('-MF')+1]=REMOTE+'/'+tag+'.o.d'
 jobs.append(dict(tag='compile-'+tag,source=source,command=args,timeout=180))
link=list(base['jobs'][-1]['command']); replacements=[]
for tag,tail in [('leases','inference-native-host-image-20261026/leases.o'),('resources','inference-paged-frame-20261026/resources.o'),('float','qwen-k1-functional-20261024/attempt1/objects/src--compute_route_apple--apple_mature_float.cc.o')]:
 matches=[a for a in link if a.endswith(tail)];assert len(matches)==1,(tag,matches)
 old=matches[0];link[link.index(old)]=REMOTE+'/'+tag+'.o';replacements.append(dict(before=old,after=REMOTE+'/'+tag+'.o'))
removed=[]
for tail in ('inference-paged-frame-20261026/model.o','inference-paged-frame-20261026/weights.o','inference-native-host-image-20261026/model-attempt2/report.o'):
 matches=[a for a in link if a.endswith(tail)];assert len(matches)==1,(tail,matches)
 link.remove(matches[0]);removed+=matches
link[1:1]=[REMOTE+'/'+t+'.o' for t,_ in specs if t not in ('leases','resources','float')]
gtest_lib='/Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/lib/'
link.extend([gtest_lib+'libgtest_main.a',gtest_lib+'libgtest.a'])
link[link.index('-o')+1]=REMOTE+'/slot-store-test'
link=[('-Wl,-map,'+REMOTE+'/image.map') if a.startswith('-Wl,-map,') else a for a in link]
assert not any('force_load' in a or 'all_load' in a or 'allow_duplicate' in a for a in link)
jobs.append(dict(tag='link',command=link,timeout=180))
abi=[]
z=zipfile.ZipFile(B/'source.zip')
for row in read(B/'source-freeze.json'):
 n=row['path'];p=R/n
 if not p.is_file() or not n.endswith('.h'):continue
 now=sha(p.read_bytes())
 if n.startswith('src/'):assert now==row['sha256'],('private header layout changed',n)
 if now!=row['sha256']:
  old=z.read('source/'+n).decode('utf-8-sig').splitlines(True)
  abi.append(dict(path=n,old_sha256=row['sha256'],current_sha256=now,
   diff=''.join(difflib.unified_diff(old,p.read_text(encoding='utf-8-sig').splitlines(True)))))
save(W/'abi-boundaries.json',dict(changed=abi,private_headers='all source-private headers in actual paged-frame freeze identical',
 explanation='ReadLease/WriteLease/LeasePool only LeaseSlotLayout forward/friends; LeaseAccess and RegionAccess only static declarations/comments. New slot classes are new types. ResourceEpisode is TU-private and rebuilt. Apple detail RowCacheAccessKind appends a value; facts/carriers/vtables keep layout. Entire LeaseDomain implementation rebuilt, no old domain source reused. Old direct objects/archives keep existing public/private ABI.'))
frozen=[dict(path=n,bytes=len(raw),sha256=sha(raw)) for n,raw in sorted(files.items())]
save(W/'source-freeze.json',frozen)
save(W/'plan.json',dict(remote=REMOTE,jobs=jobs,replacements=replacements,removed_engine_objects=removed,
 compiled_TUs=len(specs),baseline_link=str(B/'plan.json'),environment=base['environment'],
 scope='Only AppleSlotStore.* three tests/four small dtype/padding/reset variants. No model, quality, performance or other platform claim.',
 HTTP=0,SDK_builds=0,MLX_lock=next(x for x in read(R/'cmake/HyleDependencyLock.json')['dependencies'] if x['name']=='mlx') if isinstance(read(R/'cmake/HyleDependencyLock.json'),dict) and 'dependencies' in read(R/'cmake/HyleDependencyLock.json') else {}))
with zipfile.ZipFile(W/'source.zip','x',zipfile.ZIP_DEFLATED) as out:
 for n,raw in files.items():out.writestr('source/'+n,raw)
 for n in ('plan.json','source-freeze.json','abi-boundaries.json','run.py'):out.write(W/n,n)
print(json.dumps(dict(files=len(files),source_bytes=sum(map(len,files.values())),zip_bytes=(W/'source.zip').stat().st_size,compiled_TUs=len(specs))))
