from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
name='src/graph/slots_region.cc'
with zipfile.ZipFile(W/'source.zip') as old:
 raw=old.read('source/'+name);(W/'failed-slots_region.cc').write_bytes(raw)
assert hashlib.sha256(raw).hexdigest()=='154b6d92d4a6b1e2a49411cdb2b801a1c13610cc3acf6854ed4a560c41de29f8'
current=(R/name).read_bytes();digest=hashlib.sha256(current).hexdigest()
assert digest=='6a55f6c188d2add1cf9630b844a7c510f44ee37ff366a6f6e63cb55b2e05e2fb'
frozen=read(W/'source-freeze.json')
for row in frozen:
 if row['path']==name:row.update(sha256=digest,bytes=len(current))
save(W/'source-freeze2.json',frozen)
plan=read(W/'plan.json')
for job in plan['jobs']:
 if job['tag']=='compile-slots_region':job['tag']='compile2-slots_region'
plan['preserved_attempts']=['run.py original dependency-normalization assertion after 2 successful TUs','compile-slots_region Clang missing-field-initializers, failed source exact bytes retained']
save(W/'plan2.json',plan)
script=(W/'run.py').read_text().replace("'plan.json'","'plan2.json'").replace("'source-freeze.json'","'source-freeze2.json'").replace("'ready.json'","'ready2.json'")
(W/'run3.py').write_text(script,encoding='utf-8')
with zipfile.ZipFile(W/'overlay2.zip','x',zipfile.ZIP_DEFLATED) as z:
 z.writestr('source/'+name,current)
 for p in ('failed-slots_region.cc','source-freeze2.json','plan2.json','run3.py'):z.write(W/p,p)
print(digest)
