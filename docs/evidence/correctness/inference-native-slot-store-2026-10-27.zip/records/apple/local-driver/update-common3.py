from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
def read(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
name='src/graph/slots_region.cc'
with zipfile.ZipFile(W/'overlay2.zip') as z:old=z.read('source/'+name)
assert hashlib.sha256(old).hexdigest()=='6a55f6c188d2add1cf9630b844a7c510f44ee37ff366a6f6e63cb55b2e05e2fb'
(W/'failed-slots_region-attempt2.cc').write_bytes(old)
raw=(R/name).read_bytes();digest=hashlib.sha256(raw).hexdigest()
assert digest=='40d4ffad41303f89693b01a58c493f158e7b93e10658d9b7e34b4e946a054351'
frozen=read(W/'source-freeze2.json')
for row in frozen:
 if row['path']==name:row.update(sha256=digest,bytes=len(raw))
save(W/'source-freeze3.json',frozen)
plan=read(W/'plan2.json')
for job in plan['jobs']:
 if job['tag']=='compile2-slots_region':job['tag']='compile3-slots_region'
plan['preserved_attempts'].append('compile2-slots_region missing-field lane, exact failed source retained')
save(W/'plan3.json',plan)
script=(W/'run3.py').read_text().replace("'plan2.json'","'plan3.json'").replace("'source-freeze2.json'","'source-freeze3.json'").replace("'ready2.json'","'ready3.json'")
(W/'run4.py').write_text(script,encoding='utf-8')
with zipfile.ZipFile(W/'overlay3.zip','x',zipfile.ZIP_DEFLATED) as z:
 z.writestr('source/'+name,raw)
 for n in ('failed-slots_region-attempt2.cc','source-freeze3.json','plan3.json','run4.py'):z.write(W/n,n)
print(digest)
