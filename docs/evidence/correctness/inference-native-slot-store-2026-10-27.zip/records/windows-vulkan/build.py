"""Six frozen CXX TUs; one retained 137-input Vulkan closure; three tests once."""
from pathlib import Path
import importlib.util,json,os,shutil,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
R=W.parents[2]
spec=importlib.util.spec_from_file_location('native_store_shared',W.parent/'windows-shared/verify.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
m,b=old.m,old.b
BASE=R/'.scratch/inference-paged-frame-20261026/engine/cpu-vulkan'
V=R/'.scratch/qwen-vulkan-k1-20261024/build1'
EXPECTED={
 'src/graph/slots_region.cc':'40d4ffad41303f89693b01a58c493f158e7b93e10658d9b7e34b4e946a054351',
 'include/hyle/graph/slots.h':'49cc56a3fc05ce7a8c92dec5af8f2b532a7fa6ddc8e969b87d10e545c89871a8',
 'src/graph/slots_region.h':'edc897d5c0265a22228c159638def875bbf7c2d4acee7fc02c971f0d150ea622'}
VKFILES=['src/graph_route_vulkan/native_slot_store.h','src/graph_route_vulkan/native_slot_store.cc',
 'src/graph_route_vulkan/native_region.cc','src/graph_route_vulkan/CMakeLists.txt',
 'src/compute_route_vulkan/vulkan_program_internal.h','src/compute_route_vulkan/vulkan_region.cc',
 'src/compute_provider_ggml_vulkan/region.cc','tests/graph_route_vulkan/slot_store_test.cc',
 'tests/graph_route_vulkan/CMakeLists.txt']
PREFIX={
 'src/graph_route_vulkan/native_slot_store.cc':'02db4ddf',
 'src/graph_route_vulkan/native_region.cc':'964309f9',
 'src/compute_route_vulkan/vulkan_region.cc':'5d3a6699',
 'src/compute_provider_ggml_vulkan/region.cc':'92bf0178',
 'tests/graph_route_vulkan/slot_store_test.cc':'bb903e6c'}
def plan():
    assert not (W/'plan.json').exists()
    for path,sha in EXPECTED.items():assert b.pin(R/path)['sha256']==sha,path
    for path,prefix in PREFIX.items():assert b.pin(R/path)['sha256'].startswith(prefix),path
    ready=b.read(BASE/'ready.json');inputs=b.read(ready['inputs']['path']);assert len(inputs)==137
    for row in inputs:b.exact(row)
    inventory=b.read(W.parent/'windows-vulkan-preparation.json')
    overlays=[x for x in inventory['required_current_overlays'] if x['name']!='store']
    for x in overlays:b.exact(x['object'])
    for x in inventory['gtest']:b.exact(x)
    units=[]
    for name,source,recipe,before in [
      ('common','src/graph/slots_region.cc',W.parent/'windows-shared/attempt2/compile/store/command.json',None),
      ('native-region','src/graph_route_vulkan/native_region.cc',V/'src--graph_route_vulkan--native_region-cc/command.json',V/'src--graph_route_vulkan--native_region-cc/unit.obj'),
      ('native-store','src/graph_route_vulkan/native_slot_store.cc',V/'src--graph_route_vulkan--native_paged_append-cc/command.json',None),
      ('vulkan-region','src/compute_route_vulkan/vulkan_region.cc',R/'.scratch/inference-native-host-image-20261026/current-vulkan-program/compile/vulkan_program/command.json',None),
      ('ggml-region','src/compute_provider_ggml_vulkan/region.cc',R/'.scratch/qwen35-unsloth-mtp-20261024/dense-vulkan-check1/region/command.json',R/'.scratch/qwen35-unsloth-mtp-20261024/dense-vulkan-check1/region/region.obj'),
      ('test','tests/graph_route_vulkan/slot_store_test.cc',V/'src--graph_route_vulkan--native_region-cc/command.json',None)]:
        command=m.command(recipe,R/source,W/'compile'/name)
        for include in [R/'src/graph',R/'src/graph_route_vulkan']:
            if '/I'+str(include) not in command:command.insert(1,'/I'+str(include))
        normalized=['/'+x[1:] if x.startswith('-') else x for x in command]
        assert all(x in normalized for x in ['/O2','/W4','/WX','/DHYLE_STATIC']),name
        units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),command=command,
                          before=b.pin(before) if before else None))
    canonical=W/'canonical-recipes.json';b.save(canonical,{'command':[arg for u in units for arg in u['command']]})
    frozen=m.c.closure([x['source']['path'] for x in units],[canonical]);b.save(W/'source-freeze.json',frozen)
    saved=[]
    for q in dict.fromkeys([Path(x['path']) for x in frozen]+[R/p for p in VKFILES]):
        if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
            dst=W/'sources'/q.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,dst)
            saved.append(dict(original=b.pin(q),saved=b.pin(dst)))
    replacements={
      str(R/'.scratch/inference-bulk-append-20261026/compile/resources/unit.obj'):'resources',
      str(R/'.scratch/inference-current-closure-20261026/unresolved-host/compile/graph_batch--batch_cc/unit.obj'):'batch'}
    b.save(W/'plan.json',dict(status='SOURCE_FROZEN_NOT_BUILT',units=units,source_expected=EXPECTED,
      Vulkan_source=[b.pin(R/p) for p in VKFILES],source_freeze=b.pin(W/'source-freeze.json'),saved=saved,
      baseline=dict(ready=b.pin(BASE/'ready.json'),inputs=ready['inputs'],runtime=ready['runtime'],command=b.pin(BASE/'link/command.json')),
      overlays=overlays,replace_existing=replacements,remove_model=inventory['remove_model'],gtest=inventory['gtest'],
      CXX_TUs=6,images=1,selection='VulkanSlotStore.*',expected_tests=3,SDK_shader_model_perf_downloads=0,
      compatibility='StoreBinding remains pimpl. Public/private headers add declarations/comments only. Vulkan ProgramState unchanged; direct_gather_rows declaration added. Native region Artifact has TU-private GatherAccess fields. Original native shaders, SDK, Runtime, CopyRecording and other Graph execution/retirement objects reused. New explicit lease/slot objects satisfy references before legacy archives.',
      unverified='No engine/native indexed GDN/conv or performance claim. Two-byte native Store remains an implementation rejection. Shared 11 cases already passed source154b; current40d4 only initializes preexisting aggregate fields explicitly for Clang warnings.'))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def environment(p):
    h=b.helper();cl=p['units'][0]['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def build():
    p=b.read(W/'plan.json');assert not (W/'compile').exists() and not (W/'ready.json').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for x in frozen:b.exact(x)
    for x in p['Vulkan_source']:b.exact(x)
    inputs=b.read(p['baseline']['inputs']['path'])
    for x in inputs:b.exact(x)
    h,env=environment(p);objects={};compiled=[]
    for u in p['units']:
        out=W/'compile'/u['name'];process=h.execute(u['command'],env,out,timeout=180)
        d=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([d['Source'],*d['Includes']])]
        for x in actual:
            q=Path(x['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):
                assert own[b.key(q)]['sha256']==x['sha256'],str(q)
        b.save(out/'actual-dependencies.json',actual)
        objects[u['name']]=b.pin(out/'unit.obj')
        compiled.append(dict(name=u['name'],source=u['source'],object=objects[u['name']],process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
        b.save(W/'partial-compile.json',compiled)
        for x in frozen:b.exact(x)
        print('COMPILED',u['name'],json.dumps(process),flush=True)
    byname={x['name']:x['object'] for x in p['overlays']}
    replacements={b.key(path):byname[name] for path,name in p['replace_existing'].items()}
    replacements.update({b.key(u['before']['path']):objects[u['name']] for u in p['units'] if u['before']})
    image=W/'bin/vulkan-slot-store-test.exe';args=[];changed=set();removed=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg)==b.key(p['remove_model']):removed+=1;continue
        if b.key(arg) in replacements:changed.add(b.key(arg));arg=replacements[b.key(arg)]['path']
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert removed==1 and changed==set(replacements),(removed,changed,set(replacements))
    added=[objects[n] for n in ['common','native-store','vulkan-region','test']]+[byname['leases'],byname['bindings']]+p['gtest']
    args[1:1]=[x['path'] for x in added]
    image.parent.mkdir(parents=True,exist_ok=True)
    process=h.execute(args,env,W/'link',timeout=120)
    final=added+[replacements.get(b.key(x['path']),x) for x in inputs if b.key(x['path'])!=b.key(p['remove_model'])]
    assert len({b.key(x['path']) for x in final})==len(final)
    b.save(W/'link-inputs.json',final)
    rt=b.read(p['baseline']['runtime']['path']);native=rt['native'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    rt['native_hardlink']=b.pin(alias);rt['PATH']=str(image.parent)+os.pathsep+rt['PATH'];b.save(W/'runtime.json',rt)
    for x in frozen:b.exact(x)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=compiled,link=process,
      inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json'),CXX_TUs=6,images=1))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def run():
    p=b.read(W/'plan.json');ready=b.read(W/'ready.json');b.exact(ready['image'])
    h,env=environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH'];xml=W/'results.xml'
    process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+p['selection'],'--gtest_output=xml:'+str(xml)],env,W/'run',timeout=120)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
    assert int(root.attrib['tests'])==3 and int(root.attrib['failures'])==0 and len(cases)==3
    assert all(x.attrib.get('status')=='run' and not list(x) for x in cases)
    b.save(W/'summary.json',dict(status='VULKAN_NATIVE_STORE_THREE_PASS',tests=3,failures=0,process=process,
      cases=[x.attrib for x in cases],results=b.pin(xml),ready=b.pin(W/'ready.json'),CXX_TUs=6,images=1,
      SDK_shader_model_perf_downloads=0,scope=p['compatibility'],unverified=p['unverified']))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    {'plan':plan,'build':build,'run':run}[sys.argv[1]]()
