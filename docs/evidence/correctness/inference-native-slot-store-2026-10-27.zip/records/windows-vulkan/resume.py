"""Preserve the first missing-include failure; resume four pending CXX units."""
from pathlib import Path
import importlib.util,json,os,shutil,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('vulkan_first',W/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,m,R=old.b,old.m,old.R
SHA='a07243aa06551358d85a8dd46d87f97ff069266fb19a3a7309e962d79c33943f'
def plan():
    assert not (W/'plan2.json').exists()
    p=b.read(W/'plan.json');path=R/'src/graph_route_vulkan/native_slot_store.cc'
    assert b.pin(path)['sha256']==SHA
    for row in b.read(p['source_freeze']['path']):
        if b.key(row['path'])!=b.key(path):b.exact(row)
    unit=next(x for x in p['units'] if x['name']=='native-store')
    unit['source']=b.pin(path);unit['command']=m.command(unit['recipe']['path'],path,W/'compile2/native-store')
    for include in [R/'src/graph',R/'src/graph_route_vulkan']:
        if '/I'+str(include) not in unit['command']:unit['command'].insert(1,'/I'+str(include))
    canonical=W/'canonical-recipes2.json';b.save(canonical,{'command':[arg for u in p['units'] for arg in u['command']]})
    frozen=m.c.closure([x['source']['path'] for x in p['units']],[canonical]);b.save(W/'source-freeze2.json',frozen)
    saved=W/'sources2/src/graph_route_vulkan/native_slot_store.cc';saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,saved)
    p.update(source_freeze=b.pin(W/'source-freeze2.json'),first_plan=b.pin(W/'plan.json'),
      first_failed_log=b.pin(W/'compile/native-store/stdout.log'),correction='Vulkan owner added missing region_access.h include only.',
      saved_corrected_source=b.pin(saved),CXX_attempts=7)
    p['Vulkan_source']=[b.pin(row['path']) if b.key(row['path'])==b.key(path) else row for row in p['Vulkan_source']]
    b.save(W/'plan2.json',p);print('PLAN2',json.dumps(b.pin(W/'plan2.json')),flush=True)
def build():
    p=b.read(W/'plan2.json');assert not (W/'ready.json').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for x in frozen:b.exact(x)
    inputs=b.read(p['baseline']['inputs']['path'])
    for x in inputs:b.exact(x)
    h,env=old.environment(p);compiled=b.read(W/'partial-compile.json')
    assert [x['name'] for x in compiled]==['common','native-region']
    objects={x['name']:x['object'] for x in compiled}
    for x in compiled:b.exact(x['object']);b.exact(x['source'])
    for u in p['units']:
        if u['name'] in objects:continue
        out=W/('compile2' if u['name']=='native-store' else 'compile')/u['name']
        process=h.execute(u['command'],env,out,timeout=180)
        d=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([d['Source'],*d['Includes']])]
        for x in actual:
            q=Path(x['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):assert own[b.key(q)]['sha256']==x['sha256'],str(q)
        b.save(out/'actual-dependencies.json',actual);objects[u['name']]=b.pin(out/'unit.obj')
        compiled.append(dict(name=u['name'],source=u['source'],object=objects[u['name']],process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
        b.save(W/'partial-compile2.json',compiled)
        for x in frozen:b.exact(x)
        print('COMPILED',u['name'],json.dumps(process),flush=True)
    byname={x['name']:x['object'] for x in p['overlays']}
    replacements={b.key(path):byname[name] for path,name in p['replace_existing'].items()}
    replacements.update({b.key(u['before']['path']):objects[u['name']] for u in p['units'] if u['before']})
    image=W/'bin/vulkan-slot-store-test.exe';args=[];changed=set();removed=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg)==b.key(p['remove_model']):removed+=1;continue
        if b.key(arg) in replacements:changed.add(b.key(arg));arg=replacements[b.key(arg)]['path']
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert removed==1 and changed==set(replacements)
    added=[objects[n] for n in ['common','native-store','vulkan-region','test']]+[byname['leases'],byname['bindings']]+p['gtest']
    args[1:1]=[x['path'] for x in added]
    image.parent.mkdir(parents=True,exist_ok=True)
    process=h.execute(args,env,W/'link',timeout=120)
    final=added+[replacements.get(b.key(x['path']),x) for x in inputs if b.key(x['path'])!=b.key(p['remove_model'])]
    assert len({b.key(x['path']) for x in final})==len(final)
    b.save(W/'link-inputs.json',final)
    rt=b.read(p['baseline']['runtime']['path']);native=rt['native'];b.exact(native)
    alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
    rt['native_hardlink']=b.pin(alias);rt['PATH']=str(image.parent)+os.pathsep+rt['PATH'];b.save(W/'runtime.json',rt)
    for x in frozen:b.exact(x)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=compiled,link=process,
      inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan2.json'),
      first_failure=p['first_failed_log'],CXX_TUs=6,CXX_attempts=7,images=1))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
if __name__=='__main__':{'plan':plan,'build':build}[sys.argv[1]]()
