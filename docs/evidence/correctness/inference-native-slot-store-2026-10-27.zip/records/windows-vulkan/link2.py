"""Recipe-only correction: replace the baseline explicit lease OBJ, do not add two."""
from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('vulkan_build',W/'build.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,R=old.b,old.R
p=b.read(W/'plan2.json');assert not (W/'ready.json').exists()
frozen=b.read(p['source_freeze']['path'])
for x in frozen:b.exact(x)
compiled=b.read(W/'partial-compile2.json');assert len(compiled)==6
for x in compiled:b.exact(x['object']);b.exact(x['source'])
baseline=b.read(p['baseline']['inputs']['path'])
for x in baseline:b.exact(x)
objects={x['name']:x['object'] for x in compiled};byname={x['name']:x['object'] for x in p['overlays']}
replacements={b.key(path):byname[name] for path,name in p['replace_existing'].items()}
replacements.update({b.key(u['before']['path']):objects[u['name']] for u in p['units'] if u['before']})
previous=R/'.scratch/inference-storage-freeze-20261026/compile/core/unit.obj'
recipe=previous.parent/'command.json'
assert str(R/'src/compute/resource_leases.cc') in b.read(recipe)['command']
replacements[b.key(previous)]=byname['leases']
args=[x for x in b.read(W/'link/command.json')['command'] if b.key(x)!=b.key(previous)]
assert sum(b.key(x)==b.key(byname['leases']['path']) for x in args)==1
b.save(W/'link2-plan.json',dict(first_failure=b.pin(W/'link/stdout.log'),old_lease_recipe=b.pin(recipe),
 old_lease=b.pin(previous),replacement=byname['leases'],command=args,source_plan=b.pin(W/'plan2.json'),
 correction='The baseline already contained an explicit resource_leases object; remove the old OBJ while retaining the single current one. No source or object recompiled.'))
h,env=old.environment(p);linked=h.execute(args,env,W/'link2',timeout=120)
added=[objects[n] for n in ['common','native-store','vulkan-region','test']]+[byname['bindings']]+p['gtest']
final=added+[replacements.get(b.key(x['path']),x) for x in baseline if b.key(x['path'])!=b.key(p['remove_model'])]
assert len({b.key(x['path']) for x in final})==len(final)
b.save(W/'link-inputs.json',final)
image=W/'bin/vulkan-slot-store-test.exe';rt=b.read(p['baseline']['runtime']['path']);native=rt['native'];b.exact(native)
alias=image.parent/Path(native['path']).name;os.link(native['path'],alias)
rt['native_hardlink']=b.pin(alias);rt['PATH']=str(image.parent)+os.pathsep+rt['PATH'];b.save(W/'runtime.json',rt)
for x in frozen:b.exact(x)
b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=compiled,link=linked,
 inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan2.json'),
 link_recipe_correction=b.pin(W/'link2-plan.json'),first_compile_failure=p['first_failed_log'],
 first_link_failure=b.pin(W/'link/stdout.log'),CXX_TUs=6,CXX_attempts=7,link_attempts=2,images=1))
print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
