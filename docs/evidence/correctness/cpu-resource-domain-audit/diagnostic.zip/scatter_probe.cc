#include <ATen/ATen.h>
#include <ATen/core/grad_mode.h>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>

int main() {
  at::NoGradGuard no_grad;
  std::size_t checks = 0;
  const std::array<std::int64_t, 4> index{2, 0, 2, 3};
  for (auto type : {at::kFloat, at::kHalf, at::kBFloat16}) {
    for (auto index_type : {at::kInt, at::kLong}) {
      auto indices = at::from_blob(const_cast<std::int64_t *>(index.data()), {4}, at::kLong).to(index_type);
      for (int axis = 0; axis < 2; ++axis) {
        auto base = at::arange(12, at::kFloat).view({4, 3});
        auto updates = at::arange(12, at::kFloat).view({4, 3}).mul(.125);
        if (axis == 1) {base = base.transpose(0, 1); updates = updates.transpose(0, 1);}
        auto result = base.to(type).clone();
        result.index_add_(axis, indices, updates.to(type));
        auto actual = result.to(at::kFloat).contiguous();
        auto expected = base.clone();
        for (int item = 0; item < 4; ++item)
          expected.select(axis, index[item]).add_(updates.select(axis, item));
        auto reference = expected.to(type).to(at::kFloat).contiguous();
        for (int i = 0; i < 12; ++i) {
          ++checks;
          if (actual.data_ptr<float>()[i] != reference.data_ptr<float>()[i]) {
            std::printf("FAIL type=%d axis=%d item=%d actual=%g reference=%g\n", int(type), axis, i, actual.data_ptr<float>()[i], reference.data_ptr<float>()[i]);
            return 3;
          }
        }
        auto empty = indices.slice(0, 0, 0);
        auto unchanged = base.to(type).clone();
        unchanged.index_add_(axis, empty, updates.to(type).narrow(axis, 0, 0));
        ++checks;
        if (!at::equal(unchanged, base.to(type))) return 4;
      }
    }
  }
  std::printf("PASS original ATen index_add I32/I64 three floating storage two axes duplicate and empty checks=%zu\n", checks);
}
