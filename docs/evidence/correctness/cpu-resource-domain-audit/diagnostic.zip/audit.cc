#include <array>
#include "provider_internal.h"
#include "hyle/graph/cpu.h"
#include <cstdio>
#include <cstdlib>
#include <initializer_list>
#include <span>
#include <utility>
#include <vector>
#include "hyle/compute/backends/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/compute/providers/native.h"
#include "hyle/compute/providers/onednn.h"
namespace c=hyle::compute;
template<class T>T take(hyle::Result<T> r){if(!r){std::fprintf(stderr,"invalid diagnostic: %.*s\n",int(r.error().message().size()),r.error().message().data());std::exit(2);}return std::move(*r);}
c::TensorDesc d(c::DataType type,std::initializer_list<std::int64_t> shape){return take(c::TensorDesc::dense(type,{shape.begin(),shape.size()}));}
void desc(const c::TensorDesc &x){
 std::printf("dtype=%d;shape=",int(x.data_type()));for(auto n:x.dimensions())std::printf("%lld,",(long long)n);
 std::printf(";strides=");for(auto n:x.byte_strides())std::printf("%lld,",(long long)n);std::printf(";plain=%d;dense=%d",x.is_plain(),x.is_dense());
}
struct Audit {
 std::array<c::Context,4> contexts;
 const char *names[4]{"ggml","oneDNN","ATen","Native"};
 std::size_t rows=0,invalid=0;
 Audit():contexts{take(c::Context::create(c::cpu::device(),c::ggml_cpu::provider())),take(c::Context::create(c::cpu::device(),c::onednn::provider())),take(c::Context::create(c::cpu::device(),c::aten_cpu::provider())),take(c::Context::create(c::cpu::device(),c::native::provider()))}{}
 template<class Op> void test(const char *name,Op operation,std::initializer_list<c::TensorDesc> inputs){
  const c::Operation op(operation);
  const auto descriptions=std::span(inputs.begin(),inputs.size());
  const auto inferred=c::infer_single_output(op,descriptions);
  if(!inferred){++invalid;std::printf("%s\tSCHEMA_REJECT\t%.*s\n",name,int(inferred.error().message().size()),inferred.error().message().data());return;}
  for(std::size_t i=0;i<contexts.size();++i){
   auto prepared=c::prepare(contexts[i],op,descriptions,std::span(&*inferred,1),hyle::mem::system_resource());
   ++rows;std::printf("%s\t%s\t%s\t",name,names[i],prepared ? "ADMITTED" : prepared.error().IsUnimplemented() ? "UNIMPLEMENTED" : "OTHER_ERROR");
   for(auto &input:inputs){desc(input);std::printf("|");}std::printf("->");desc(*inferred);
   if(prepared) {
    auto facts=prepared->runtime_properties();
    auto bytes=[](std::optional<std::size_t> n){if(n) std::printf("%zu",*n);else std::printf("unknown");};
    std::printf("\treplay=%d;workspace_owner=%d;private_threads=%d;persistent=",int(facts.replay_class),int(facts.workspace_owner),facts.uses_private_threads);
    bytes(prepared->persistent_bytes());std::printf(";invocation_private=");bytes(prepared->invocation_private_bytes());
    std::printf(";caller_workspace=%zu;alias=",prepared->workspace_requirement().size);
    for(std::size_t j=0;j<inputs.size();++j)std::printf("%d,",take(prepared->alias_support(0,j)).supported);
    std::vector<c::detail::ResourceBindingRequirement> ir(inputs.size());
    std::array<c::detail::ResourceBindingRequirement,1> orq{};
    auto proposal=take(c::detail::OperationPreparationAccess::propose(contexts[i],0,op,descriptions,std::span(&*inferred,1),ir,orq));
    std::printf(";compile_resident=");bytes(proposal.cost.compilation_storage.resident_bytes);
    std::printf(";compile_peak=");bytes(proposal.cost.compilation_storage.peak_bytes);
   }
   if(!prepared&&!prepared.error().IsUnimplemented()) ++invalid;
   if(!prepared)std::printf("\t%.*s",int(prepared.error().message().size()),prepared.error().message().data());std::puts("");
  }
 }
};

namespace g=hyle::graph;
template<class Op> void graph_case(const char *name,Op operation,std::initializer_list<c::TensorDesc> inputs){
 const c::Operation op(operation);
 auto builder=take(g::GraphBuilder::create());std::vector<g::ValueId> ids;
 for(const auto &x:inputs)ids.push_back(take(builder.input(x)));
 auto node=take(builder.add_node(op,ids));auto result=take(builder.result(node));
 auto status=builder.publish(result);if(!status.ok())std::exit(4);
 auto graph=take(std::move(builder).finish());auto context=take(g::cpu::create_context());
 for(int mode=0;mode<5;++mode){
  g::CompileOptions options{};
  if(mode==1)options.provider_replay=g::ProviderReplayPolicy::kRequirePrepared;
  if(mode==2)options.compiled_storage.max_bytes=1<<20;
  if(mode==3)options.compilation_storage=g::CompilationStorageLimits{.max_resident_bytes=64<<20,.max_peak_bytes=64<<20};
  if(mode==4)options.invocation_storage=g::InvocationStorageLimits{.max_bytes=1<<20};
  auto compiled=g::compile(graph,context,options);
  std::printf("GRAPH\t%s\tmode=%d\t%s",name,mode,compiled?"ADMITTED":"REJECTED");
  if(compiled){
   for(std::size_t i=0;i<compiled->report.step_count();++i){auto step=take(compiled->report.step(i));std::printf("\t%.*s",int(step.provider.name.size()),step.provider.name.data());}
   auto inv=compiled->executable.create_invocation();std::printf("\tinvocation=%s",inv?"ADMITTED":"REJECTED");
   if(!inv)std::printf("\t%.*s",int(inv.error().message().size()),inv.error().message().data());
  }else std::printf("\t%.*s",int(compiled.error().message().size()),compiled.error().message().data());
  std::puts("");
 }
}
void bounded_cases(Audit &audit){
 const auto input=d(c::DataType::kFloat32,{4,8});
 std::array<c::detail::ShapeDimension,1> dimensions{};dimensions[0].bounds={1,4,1};
 std::array<c::detail::ProviderTensorAxes,1> ia{},oa{};ia[0].values[0]=oa[0].values[0]=0;
 const c::detail::ProviderShapeDomain domain{dimensions,ia,oa};
 const std::array<c::TensorDesc,1> in{input},out{input};
 for(const auto &op:{c::Operation(c::RmsNorm{}),c::Operation(c::Copy{}),c::Operation(c::Unary{.kind=c::UnaryKind::kExp})}){
  for(std::size_t i=0;i<audit.contexts.size();++i){
   std::array<c::detail::ResourceBindingRequirement,1> ir{},orq{};
   auto proposal=c::detail::OperationPreparationAccess::propose(audit.contexts[i],0,op,in,out,ir,orq,domain);
   std::printf("BOUNDED\top=%d\t%s\t%s",int(op.kind()),audit.names[i],proposal?"ADMITTED":"REJECTED");
   if(proposal) std::printf("\tcoverage=%d",int(proposal->shape_coverage));
   else std::printf("\t%.*s",int(proposal.error().message().size()),proposal.error().message().data());
   std::puts("");
  }
 }
}

int main(){
 Audit audit;
 const char *unary[]{"Abs","Neg","Exp","Log","Sqrt","Rsqrt","Tanh","Sigmoid","Relu","Gelu","GeluTanh","Silu","Softplus"};
 const char *binary[]{"Add","Subtract","Multiply","Divide","Minimum","Maximum"};
 const char *reduce[]{"ReduceSum","ReduceMean","ReduceMin","ReduceMax"};
 const char *gate[]{"GateSiluPacked","GateGeluPacked","GateGeluTanhPacked"};
 for(auto type:{c::DataType::kFloat32,c::DataType::kFloat16,c::DataType::kBFloat16}){
  const auto a=d(type,{2,8});
  for(int kind=0;kind<13;++kind)audit.test(unary[kind],c::Unary{c::UnaryKind(kind)},{a});
  for(int kind=0;kind<6;++kind)audit.test(binary[kind],c::Binary{c::BinaryKind(kind)},{a,d(type,{8})});
  for(int kind=0;kind<4;++kind)audit.test(reduce[kind],c::Reduce{.kind=c::ReductionKind(kind),.accumulation_type=c::DataType::kFloat32},{a});
  for(int kind=0;kind<3;++kind)audit.test(gate[kind],c::GatedActivation{.activation=c::GatedActivationKind(kind)},{d(type,{2,16})});
  audit.test("SelectBoolBroadcast",c::Select{},{d(c::DataType::kBool,{2,1}),a,d(type,{8})});
  audit.test("RmsNorm",c::RmsNorm{},{a,d(c::DataType::kFloat32,{8})});
  audit.test("LayerNorm",c::LayerNorm{},{a,d(c::DataType::kFloat32,{8}),d(c::DataType::kFloat32,{8})});
  audit.test("SoftmaxRank2",c::Softmax{},{a});
  audit.test("SoftmaxRank1",c::Softmax{},{d(type,{8})});
  audit.test("SoftmaxRank4Scale",c::Softmax{.scale=.5F},{d(type,{2,2,3,8})});
  audit.test("SoftmaxAxis0",c::Softmax{.axis=0},{a});
  audit.test("LogSoftmax",c::Softmax{.kind=c::SoftmaxKind::kLogSoftmax},{a});
  audit.test("SoftmaxBoolMask",c::Softmax{.mask=c::MaskKind::kBoolean},{a,d(c::DataType::kBool,{2,8})});
  audit.test("SoftmaxAdditiveMask",c::Softmax{.mask=c::MaskKind::kAdditive},{a,a});
  const auto q=d(type,{1,2,2,4}),kv=d(type,{1,3,2,4});
  audit.test("AttentionCausal",c::ScaledDotProductAttention{.causal=true},{q,kv,kv});
  audit.test("AttentionNonCausal",c::ScaledDotProductAttention{},{q,kv,kv});
  audit.test("AttentionBoolMask",c::ScaledDotProductAttention{.mask=c::MaskKind::kBoolean},{q,kv,kv,d(c::DataType::kBool,{1,2,2,3})});
  audit.test("AttentionHeadFirst",c::ScaledDotProductAttention{.layout=c::AttentionLayout::kBatchHeadSequenceDepth},{d(type,{1,2,2,4}),d(type,{1,2,3,4}),d(type,{1,2,3,4})});
  for(auto index:{c::DataType::kInt32,c::DataType::kInt64}){
   audit.test("Gather",c::Gather{},{d(type,{4,8}),d(index,{3})});
   audit.test("ScatterAdd",c::Scatter{.kind=c::ScatterKind::kAdd},{d(type,{4,8}),d(index,{3}),d(type,{3,8})});
   audit.test("ScatterAssign",c::Scatter{},{d(type,{4,8}),d(index,{3}),d(type,{3,8})});
   audit.test("RopeRank4Axis1",c::RoPE{.rotary_dimensions=8,.sequence_axis=1},{d(type,{1,3,2,8}),d(index,{3}),d(c::DataType::kFloat32,{4})});
   audit.test("RopeRank3Axis0",c::RoPE{.rotary_dimensions=8,.sequence_axis=0},{d(type,{3,2,8}),d(index,{3}),d(c::DataType::kFloat32,{4})});
  }
  audit.test("Concat",c::Concat{},{a,d(type,{1,8})});
  audit.test("Copy",c::Copy{},{a});
  audit.test("CastF32",c::Cast{.output_type=c::DataType::kFloat32},{a});
  audit.test("MatMulRowMajor",c::MatMul{},{a,d(type,{8,5})});
  audit.test("MatMulTransposed",c::MatMul{},{a,take(d(type,{5,8}).transposed())});
  audit.test("MatMulBatchTransposed",c::MatMul{},{d(type,{2,3,8}),take(d(type,{5,8}).transposed())});
  audit.test("MatMulBatchRowMajor",c::MatMul{},{d(type,{2,3,8}),d(type,{8,5})});
 }
 for(auto type:{c::DataType::kBool,c::DataType::kFloat64,c::DataType::kInt32,c::DataType::kInt64}){
  audit.test("WideCopy",c::Copy{},{d(type,{2,8})});
  audit.test("WideGather",c::Gather{},{d(type,{4,8}),d(c::DataType::kInt32,{3})});
  audit.test("WideConcat",c::Concat{},{d(type,{2,8}),d(type,{1,8})});
 }
 for(auto type:{c::DataType::kFloat16,c::DataType::kBFloat16,c::DataType::kFloat8E4M3FN,c::DataType::kFloat8E5M2})audit.test("CastNarrow",c::Cast{.output_type=type},{d(c::DataType::kFloat32,{2,8})});
 audit.test("FillF32",c::Fill{.output_shape=take(c::TensorShape::create(std::array<std::int64_t,2>{2,8})),.output_type=c::DataType::kFloat32,.value=c::ScalarValue(2.F)},{});
 
 audit.test("MatMulExplicitF32",c::MatMul{.accumulation_type=c::DataType::kFloat32},{d(c::DataType::kFloat32,{2,8}),d(c::DataType::kFloat32,{8,5})});
 for(auto type:{c::DataType::kFloat8E4M3FN,c::DataType::kFloat8E5M2}) audit.test("CastFP8Widen",c::Cast{.output_type=c::DataType::kFloat32},{d(type,{2,8})});
 graph_case("matrix",c::MatMul{.accumulation_type=c::DataType::kFloat32},{d(c::DataType::kFloat32,{2,8}),d(c::DataType::kFloat32,{8,5})});
 graph_case("stable-gate",c::GatedActivation{}, {d(c::DataType::kFloat32,{2,16})});
 graph_case("bool-softmax",c::Softmax{.mask=c::MaskKind::kBoolean},{d(c::DataType::kFloat32,{2,8}),d(c::DataType::kBool,{2,8})});
 graph_case("rms",c::RmsNorm{}, {d(c::DataType::kFloat32,{2,8})});
 graph_case("copy",c::Copy{}, {d(c::DataType::kFloat32,{2,8})});
 graph_case("i64-assign",c::Scatter{}, {d(c::DataType::kFloat32,{4,8}),d(c::DataType::kInt64,{3}),d(c::DataType::kFloat32,{3,8})});
 graph_case("fp8-widen",c::Cast{.output_type=c::DataType::kFloat32},{d(c::DataType::kFloat8E4M3FN,{2,8})});
 bounded_cases(audit);
 std::printf("SUMMARY provider_rows=%zu invalid_schema_cases=%zu\n",audit.rows,audit.invalid);
 return audit.invalid ? 3 : 0;
}
