import shutil
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-resource-domain-audit'
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
compiler=shutil.which('cl',path=env.get('Path',env.get('PATH','')));assert compiler
exe=build/'bin/cpu_resource_audit.exe'
libs=['graph_route_cpu','graph_provider_onednn','graph','compute_route_cpu','compute_provider_ggml','compute_provider_onednn','compute_provider_native','compute_backend_cpu','compute','compute_ops','mem','platform','error']
run('compile-cold-audit',[compiler,'/nologo','/std:c++latest','/Zc:__cplusplus','/Zc:preprocessor','/utf-8','/EHsc','/O2','/MD','/DHYLE_COMPUTE_GGML_CPU=1','/DHYLE_COMPUTE_ONEDNN=1','/I'+str(repo/'include'),'/I'+str(repo/'src/compute'),str(out/'audit.cc'),'/Fo'+str(out/'audit.obj'),'/Fe'+str(exe)]+[str(build/('bin/hyle_'+lib+'.lib')) for lib in libs])
run('actual-cold-resource-matrix',[exe])
