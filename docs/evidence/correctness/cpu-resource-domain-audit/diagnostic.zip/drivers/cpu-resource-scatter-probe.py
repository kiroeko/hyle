import shutil
exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-resource-domain-audit'
records=json.loads((out/'receipt.json').read_text())
sdk=Path('C:/Users/kiro/AppData/Local/hyle/dependencies/v1/sdks/torch-cpu/Windows-bf0079104e068dcbd60b2f8de589dc725282cbe865a85016cc5b8aa46cab519d/libtorch')
compiler=shutil.which('cl',path=env.get('Path',env.get('PATH','')));assert compiler
exe=Path('C:/hv/cpu-tm-original-probe/cpu_scatter_probe.exe')
assert all((exe.parent / p.name).exists() for p in (sdk/'lib').glob('*.dll'))
run('compile-original-scatter',[compiler,'/nologo','/std:c++20','/utf-8','/EHsc','/bigobj','/O2','/MD','/I'+str(sdk/'include'),'/I'+str(sdk/'include/torch/csrc/api/include'),str(out/'scatter_probe.cc'),'/Fo'+str(out/'scatter-probe.obj'),'/Fe'+str(exe)]+[str(sdk/'lib'/p) for p in ['torch.lib','torch_cpu.lib','c10.lib']])
run('original-scatter-three-storage-I32-I64',[exe])
