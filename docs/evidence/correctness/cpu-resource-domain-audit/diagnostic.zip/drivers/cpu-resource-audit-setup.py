from pathlib import Path
import json

repo = Path(__file__).resolve().parents[1]
out = repo / '.scratch/validation/cpu-resource-domain-audit'
out.mkdir(parents=True, exist_ok=True)
source = (repo / '.scratch/validation/cpu-ggml-mature-batch/cold_audit.cc').read_text(encoding='utf-8')
source = source.replace('#include <array>', '#include <array>\n#include "provider_internal.h"\n#include "hyle/graph/cpu.h"')
source = source.replace('std::array<c::Context,3>', 'std::array<c::Context,4>')
source = source.replace('const char *names[3]{"ggml","oneDNN","Native"}', 'const char *names[4]{"ggml","oneDNN","ATen","Native"}')
source = source.replace('take(c::Context::create(c::cpu::device(),c::native::provider()))', 'take(c::Context::create(c::cpu::device(),c::aten_cpu::provider())),take(c::Context::create(c::cpu::device(),c::native::provider()))')
source = source.replace('if(!prepared)std::printf', '''if(prepared) {
    auto facts=prepared->runtime_properties();
    auto bytes=[](std::optional<std::size_t> n){if(n) std::printf("%zu",*n);else std::printf("unknown");};
    std::printf("\\treplay=%d;workspace_owner=%d;private_threads=%d;persistent=",int(facts.replay_class),int(facts.workspace_owner),facts.uses_private_threads);
    bytes(prepared->persistent_bytes());std::printf(";invocation_private=");bytes(prepared->invocation_private_bytes());
    std::printf(";caller_workspace=%zu;alias=",prepared->workspace_requirement().size);
    for(std::size_t j=0;j<inputs.size();++j)std::printf("%d,",take(prepared->alias_support(0,j)).supported);
    std::vector<c::detail::ResourceBindingRequirement> ir(inputs.size());
    std::array<c::detail::ResourceBindingRequirement,1> orq{};
    auto proposal=take(c::detail::OperationPreparationAccess::propose(contexts[i],0,op,descriptions,std::span(&*inferred,1),ir,orq));
    std::printf(";compile_resident=");bytes(proposal.cost.compilation_storage.resident_bytes);
    std::printf(";compile_peak=");bytes(proposal.cost.compilation_storage.peak_bytes);
   }
   if(!prepared&&!prepared.error().IsUnimplemented()) ++invalid;
   if(!prepared)std::printf''')
extra = r'''
namespace g=hyle::graph;
template<class Op> void graph_case(const char *name,Op operation,std::initializer_list<c::TensorDesc> inputs){
 const c::Operation op(operation);
 auto builder=take(g::GraphBuilder::create());std::vector<g::ValueId> ids;
 for(const auto &x:inputs)ids.push_back(take(builder.input(x)));
 auto node=take(builder.add_node(op,ids));auto result=take(builder.result(node));
 auto status=builder.publish(result);if(!status.ok())std::exit(4);
 auto graph=take(std::move(builder).finish());auto context=take(g::cpu::create_context());
 for(int mode=0;mode<5;++mode){
  g::CompileOptions options{};
  if(mode==1)options.provider_replay=g::ProviderReplayPolicy::kRequirePrepared;
  if(mode==2)options.compiled_storage.max_bytes=1<<20;
  if(mode==3)options.compilation_storage=g::CompilationStorageLimits{.max_resident_bytes=64<<20,.max_peak_bytes=64<<20};
  if(mode==4)options.invocation_storage=g::InvocationStorageLimits{.max_bytes=1<<20};
  auto compiled=g::compile(graph,context,options);
  std::printf("GRAPH\t%s\tmode=%d\t%s",name,mode,compiled?"ADMITTED":"REJECTED");
  if(compiled){
   for(std::size_t i=0;i<compiled->report.step_count();++i){auto step=take(compiled->report.step(i));std::printf("\t%.*s",int(step.provider.name.size()),step.provider.name.data());}
   auto inv=compiled->executable.create_invocation();std::printf("\tinvocation=%s",inv?"ADMITTED":"REJECTED");
   if(!inv)std::printf("\t%.*s",int(inv.error().message().size()),inv.error().message().data());
  }else std::printf("\t%.*s",int(compiled.error().message().size()),compiled.error().message().data());
  std::puts("");
 }
}
void bounded_cases(Audit &audit){
 const auto input=d(c::DataType::kFloat32,{4,8});
 std::array<c::detail::ShapeDimension,1> dimensions{};dimensions[0].bounds={1,4,1};
 std::array<c::detail::ProviderTensorAxes,1> ia{},oa{};ia[0].values[0]=oa[0].values[0]=0;
 const c::detail::ProviderShapeDomain domain{dimensions,ia,oa};
 const std::array<c::TensorDesc,1> in{input},out{input};
 for(const auto &op:{c::Operation(c::RmsNorm{}),c::Operation(c::Copy{}),c::Operation(c::Unary{.kind=c::UnaryKind::kExp})}){
  for(std::size_t i=0;i<audit.contexts.size();++i){
   std::array<c::detail::ResourceBindingRequirement,1> ir{},orq{};
   auto proposal=c::detail::OperationPreparationAccess::propose(audit.contexts[i],0,op,in,out,ir,orq,domain);
   std::printf("BOUNDED\top=%d\t%s\t%s",int(op.kind()),audit.names[i],proposal?"ADMITTED":"REJECTED");
   if(proposal) std::printf("\tcoverage=%d",int(proposal->shape_coverage));
   else std::printf("\t%.*s",int(proposal.error().message().size()),proposal.error().message().data());
   std::puts("");
  }
 }
}
'''
source = source.replace('int main(){', extra + '\nint main(){')
source = source.replace('std::printf("SUMMARY', '''
 audit.test("MatMulExplicitF32",c::MatMul{.accumulation_type=c::DataType::kFloat32},{d(c::DataType::kFloat32,{2,8}),d(c::DataType::kFloat32,{8,5})});
 for(auto type:{c::DataType::kFloat8E4M3FN,c::DataType::kFloat8E5M2}) audit.test("CastFP8Widen",c::Cast{.output_type=c::DataType::kFloat32},{d(type,{2,8})});
 graph_case("matrix",c::MatMul{.accumulation_type=c::DataType::kFloat32},{d(c::DataType::kFloat32,{2,8}),d(c::DataType::kFloat32,{8,5})});
 graph_case("stable-gate",c::GatedActivation{}, {d(c::DataType::kFloat32,{2,16})});
 graph_case("bool-softmax",c::Softmax{.mask=c::MaskKind::kBoolean},{d(c::DataType::kFloat32,{2,8}),d(c::DataType::kBool,{2,8})});
 graph_case("rms",c::RmsNorm{}, {d(c::DataType::kFloat32,{2,8})});
 graph_case("copy",c::Copy{}, {d(c::DataType::kFloat32,{2,8})});
 graph_case("i64-assign",c::Scatter{}, {d(c::DataType::kFloat32,{4,8}),d(c::DataType::kInt64,{3}),d(c::DataType::kFloat32,{3,8})});
 graph_case("fp8-widen",c::Cast{.output_type=c::DataType::kFloat32},{d(c::DataType::kFloat8E4M3FN,{2,8})});
 bounded_cases(audit);
 std::printf("SUMMARY''')
(out/'audit.cc').write_text(source, encoding='utf-8', newline='\n')
