from pathlib import Path
import collections, hashlib, json, subprocess, zipfile

repo=Path(__file__).resolve().parents[1]
out=repo/'.scratch/validation/cpu-resource-domain-audit'
lines=(out/'5-actual-cold-resource-matrix.log').read_text(encoding='utf-8').splitlines()
rows=[line.split('\t') for line in lines if line and not line.startswith(('GRAPH\t','BOUNDED\t','SUMMARY'))]
assert len(rows)==764
assert all(row[2] in ('ADMITTED','UNIMPLEMENTED') for row in rows)
cases=[rows[i:i+4] for i in range(0,len(rows),4)]
native_only=[case[-1] for case in cases if case[-1][2]=='ADMITTED' and not any(row[2]=='ADMITTED' for row in case[:-1])]
counts={name:dict(collections.Counter(row[2] for row in rows if row[1]==name)) for name in ('ggml','oneDNN','ATen','Native')}
summary={'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'cases':len(cases),'provider_rows':len(rows),'counts':counts,'native_only_unconstrained':[{'operation':row[0],'ports':row[3]} for row in native_only], 'graph_rows':[line.split('\t') for line in lines if line.startswith('GRAPH\t')], 'bounded_rows':[line.split('\t') for line in lines if line.startswith('BOUNDED\t')], 'interpretation':'Cold proposal/prepare/graph compile and invocation creation only; no payload execution, correctness, performance or route-domain WIN/UNIQUE qualification.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('graph_rows','bounded_rows')},indent=2,ensure_ascii=False))
previous=json.loads((repo/'.scratch/validation/cpu-aten-transformer-matrix/manifest.json').read_text())
for name,digest in previous['files'].items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest,name
identity={'current_commit':summary['candidate'],'qualified_product_candidate':previous['candidate'],'unchanged_forward_inputs':len(previous['files']),'files':previous['files']}
(out/'product-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
dest=repo/'evidence/correctness/cpu-resource-domain-audit'
dest.mkdir(parents=True,exist_ok=True)
paths=[p for p in out.iterdir() if p.is_file() and p.suffix not in ('.obj',)]
drivers=[repo/'.scratch'/name for name in ('cpu-resource-audit-setup.py','cpu-resource-audit.py','cpu-resource-scatter-probe.py','collect-cpu-resource-audit.py')]
with zipfile.ZipFile(dest/'diagnostic.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(paths):archive.write(p,p.name)
    for p in drivers:archive.write(p,'drivers/'+p.name)
receipt={'candidate':summary['candidate'],'kind':'cold-resource-audit-and-original-mature-program-witness','qualified_product_candidate':previous['candidate'],'unchanged_forward_inputs':len(previous['files']),'provider_rows':764,'graph_cold_rows':35,'bounded_proposals':12,'original_scatter_assertions':156,'archive_sha256':hashlib.sha256((dest/'diagnostic.zip').read_bytes()).hexdigest(),'payload_qualification':False,'performance_measurement':False}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
