from pathlib import Path

root = Path(__file__).resolve().parents[2]
path = root / 'test.ps1'
text = path.read_text('utf-8-sig')
flag = 'RemovePublishedKimiWorkingSetBinaries'
assert flag not in text
start = text.index('if ($RemoveClosedF32TopOneBinaries) {')
end = text.index('\nif ($RemoveMtpNativeSupersededBinaries)', start)
block = text[start:end]
for old, new in {
    'RemoveClosedF32TopOneBinaries': flag,
    'f32TopOneTask': 'kimiWorkingSetTask',
    'closed F32 TopK1': 'published Kimi working set',
    '.scratch/mtp-single-row-prepared-20261025': '.scratch/kimi-mixed-working-set-20261025',
    '$kimiWorkingSetTaskPlan.deletion_executed': '$kimiWorkingSetTaskPlan.performed',
    '.files.Count -ne 11': '.files.Count -ne 10',
    '303158869L': '288146570L',
    'docs/evidence/performance/mtp-f32-single-row-prepared-screen-2026-10-25.json':
        'docs/evidence/correctness/kimi-mixed-selected-working-set-2026-10-25.json',
}.items():
    block = block.replace(old, new)
text = text.replace('[switch]$RemoveClosedF32TopOneBinaries)',
                    '[switch]$RemoveClosedF32TopOneBinaries, [switch]$' + flag + ')', 1)
insertion = text.index('\nif ($RemoveClosedF32TopOneBinaries)')
text = text[:insertion] + '\n' + block + text[insertion:]
with path.open('w', encoding='utf-8', newline='') as output:
    output.write(text.replace('\r\n', '\n').replace('\n', '\r\n'))
print('Prepared exact 10-file completed Kimi cleanup in test.ps1; no deletion executed.')
