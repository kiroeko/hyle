from pathlib import Path
import hashlib
import json
import zipfile

base = Path(__file__).resolve().parent
root = base.parents[1]
public = root / 'docs/evidence/correctness/kimi-mixed-selected-working-set-2026-10-25.json'
data = json.loads(public.read_text('utf-8'))
receipt = json.loads((base / 'cleanup-removed.json').read_text('utf-8-sig'))
assert receipt['applied'] and len(receipt['files']) == 10
assert receipt['logical_bytes'] == 288146570
for item in receipt['files']:
    path = Path(item['path'])
    assert path.is_relative_to(base) and not path.exists()
script = (root / 'test.ps1').read_text('utf-8-sig')
start = script.index('if ($RemovePublishedKimiWorkingSetBinaries) {')
end = script.index('\nif ($RemoveClosedF32TopOneBinaries)', start)
(base / 'cleanup-test-excerpt.ps1').write_text(
    'param([switch]$Apply, [switch]$RemovePublishedKimiWorkingSetBinaries)\n' + script[start:end], encoding='utf-8')
followup = dict(status='COMPLETED_GENERATED_COMPONENT_BINARIES_REMOVED',
                files=10, logical_bytes_removed=288146570,
                physical_bytes_freed_unknown=True,
                command_preview='.\\test.ps1 -RemovePublishedKimiWorkingSetBinaries',
                command_apply='.\\test.ps1 -RemovePublishedKimiWorkingSetBinaries -Apply',
                kept='Canonical tests, all source, generators, commands, logs, oracles, header inventories, SDK inputs, five reusable provider leaves and original native DLL.',
                validation='Every exact target was repository-contained, ordinary/no reparse ancestors, inactive, matched size/SHA256 and passed exclusive open before any removal.',
                note='Only two completed private build generations; no weight banks were written to disk. New publisher-router work uses its own source/build directory.')
(base / 'cleanup-followup.json').write_text(json.dumps(followup, indent=2) + '\n', encoding='utf-8')
archive = root / data['archive']['path']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == data['archive']['sha256']
with zipfile.ZipFile(archive, 'a', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name in ('prepare-cleanup.py', 'record-cleanup.py', 'cleanup-test-excerpt.ps1',
                 'cleanup-removed.json', 'cleanup-followup.json'):
        target = 'root-cleanup/' + name
        assert target not in stream.namelist()
        stream.write(base / name, target)
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    entries = len(stream.infolist())
    assert len(set(stream.namelist())) == entries
data['cleanup_execution'] = followup
data['archive'].update(bytes=archive.stat().st_size,
                       sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                       original_payload_count=data['archive']['payload_count'],
                       payload_count=entries,
                       root_cleanup_entries=5)
public.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(files=10, logical_bytes=288146570,
                     archive_entries=entries, archive_bytes=archive.stat().st_size), indent=2))
