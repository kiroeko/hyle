param([switch]$Apply, [switch]$RemovePublishedKimiWorkingSetBinaries)
if ($RemovePublishedKimiWorkingSetBinaries) {
  $ErrorActionPreference = 'Stop'
  $kimiWorkingSetTaskRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
  if ($kimiWorkingSetTaskRoot -ne 'C:\public\project-hyle\hyle') { throw 'Unexpected published Kimi working set workspace' }
  $kimiWorkingSetTaskBase = [IO.Path]::GetFullPath((Join-Path $kimiWorkingSetTaskRoot '.scratch/kimi-mixed-working-set-20261025'))
  $kimiWorkingSetTaskPlan = Get-Content -LiteralPath (Join-Path $kimiWorkingSetTaskBase 'cleanup-candidates.json') -Raw | ConvertFrom-Json
  $kimiWorkingSetTaskReceipt = Join-Path $kimiWorkingSetTaskBase 'cleanup-removed.json'
  if ((Test-Path -LiteralPath $kimiWorkingSetTaskReceipt) -or $kimiWorkingSetTaskPlan.performed -or $kimiWorkingSetTaskPlan.files.Count -ne 10 -or $kimiWorkingSetTaskPlan.logical_bytes -ne 288146570L) { throw 'published Kimi working set cleanup inventory changed/already executed' }
  $kimiWorkingSetTaskProof = Get-Content -LiteralPath (Join-Path $kimiWorkingSetTaskRoot 'docs/evidence/correctness/kimi-mixed-selected-working-set-2026-10-25.json') -Raw | ConvertFrom-Json
  $kimiWorkingSetTaskArchive = Join-Path $kimiWorkingSetTaskRoot $kimiWorkingSetTaskProof.archive.path
  if ((Get-FileHash -LiteralPath $kimiWorkingSetTaskArchive -Algorithm SHA256).Hash -ne $kimiWorkingSetTaskProof.archive.sha256) { throw 'Published published Kimi working set evidence differs' }
  $kimiWorkingSetTaskActive = @(Get-CimInstance Win32_Process | Select-Object -ExpandProperty ExecutablePath)
  $kimiWorkingSetTaskTargets = @(foreach ($entry in $kimiWorkingSetTaskPlan.files) {
    $kimiWorkingSetTaskPath = [IO.Path]::GetFullPath((Join-Path $kimiWorkingSetTaskRoot $entry.path))
    if (!$kimiWorkingSetTaskPath.StartsWith($kimiWorkingSetTaskBase+'\',[StringComparison]::OrdinalIgnoreCase) -or
        [IO.Path]::GetExtension($kimiWorkingSetTaskPath) -notin @('.exe','.obj','.exp','.lib','.dll')) { throw 'published Kimi working set target outside exact binary scope' }
    $kimiWorkingSetTaskResolved = (Resolve-Path -LiteralPath $kimiWorkingSetTaskPath).Path
    if ($kimiWorkingSetTaskResolved -ne $kimiWorkingSetTaskPath -or $kimiWorkingSetTaskActive -contains $kimiWorkingSetTaskPath) { throw 'published Kimi working set target changed or active' }
    for ($kimiWorkingSetTaskParent=$kimiWorkingSetTaskPath; $kimiWorkingSetTaskParent; $kimiWorkingSetTaskParent=[IO.Path]::GetDirectoryName($kimiWorkingSetTaskParent)) {
      if ((Get-Item -LiteralPath $kimiWorkingSetTaskParent -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'published Kimi working set cleanup path has reparse point' }
    }
    $kimiWorkingSetTaskItem = Get-Item -LiteralPath $kimiWorkingSetTaskPath
    if ($kimiWorkingSetTaskItem.PSIsContainer -or $kimiWorkingSetTaskItem.Length -ne $entry.bytes -or
        (Get-FileHash -LiteralPath $kimiWorkingSetTaskPath -Algorithm SHA256).Hash -ne $entry.sha256) { throw 'published Kimi working set target differs from recorded binary' }
    $kimiWorkingSetTaskFile = [IO.File]::Open($kimiWorkingSetTaskPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
    $kimiWorkingSetTaskFile.Dispose()
    [pscustomobject]@{path=$kimiWorkingSetTaskPath;bytes=$entry.bytes;sha256=$entry.sha256}
  })
  $kimiWorkingSetTaskResult = [ordered]@{applied=[bool]$Apply;files=$kimiWorkingSetTaskTargets;logical_bytes=$kimiWorkingSetTaskPlan.logical_bytes;physical_bytes_freed_unknown=$true}
  $kimiWorkingSetTaskResult | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $kimiWorkingSetTaskBase 'cleanup-preview.json') -Encoding utf8
  if ($Apply) {
    foreach ($entry in $kimiWorkingSetTaskTargets) { Remove-Item -LiteralPath $entry.path }
    foreach ($entry in $kimiWorkingSetTaskTargets) { if (Test-Path -LiteralPath $entry.path) { throw 'published Kimi working set binary still present' } }
    $kimiWorkingSetTaskResult | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $kimiWorkingSetTaskReceipt -Encoding utf8
  }
  [ordered]@{files=$kimiWorkingSetTaskTargets.Count;logical_bytes=$kimiWorkingSetTaskPlan.logical_bytes;applied=[bool]$Apply} | ConvertTo-Json
  exit 0
}

