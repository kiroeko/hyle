from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025'
def read(p):return json.loads(p.read_bytes())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
r=read(W/'run2/result.json');assert r['process']['exit']==0 and not r['process']['timeout'];assert read(W/'run1/process.json')['exit']==1
rows=r['rows'];assert rows[2]['status']=='PASS'and rows[2]['SiTU_wrong_rounding_witnesses']>0
for x in rows[:2]:
 assert x['status']=='PASS_GENERATED_FULL_AXES_COMPONENT'and x['banks']==7 and x['upload_generations']==2 and x['graph_submissions']==5 and len(x['source_plane_sha256'])==192
 assert x['old_reader_unchanged']and x['rejected_last_binding_preserved_and_executed']and not x['publisher_payload']
 for report in x['upload_reports']:assert report['logical_bytes']==report['staged_bytes']==report['submitted_bytes']==report['completed_bytes']==x['logical_bytes_per_slot']and not report['copied_bytes_unknown']
formal=read(W/'formal-migration.json');assert formal['executed_body_token_equal'];checks=read(W/'formal-check1/summary.json');assert all(x['process']['exit']==0 for x in checks['checks'])
for p in formal['pins']:assert(R/p['path']).read_text(encoding='utf8')==(W/'canonical-proposal'/p['path']).read_text(encoding='utf8')
base=R/'.scratch/mtp-performance-convergence-20261025/baseline/link/hyle.exe';baseline=pin(base);assert baseline['sha256']=='c343db76232c4b5bd34878820433057b8c23789cd1b170b6a3b86cd91bf82fa1'
source=Path(read(W/'build2/summary.json')['source']['path']);assert pin(source)['sha256']==read(W/'build2/summary.json')['source']['sha256']
# The exact cached native closure is unchanged except the consumer entry and output locations.
old=read(R/'.scratch/nf4-packed-contraction-20261025/component3/link/command.json')['command'];new=read(W/'build2/link/command.json')['command'];trim=lambda xs:[a for a in xs if not a.lower().startswith(('/out:','/pdb:','/map:','/implib:'))];old=trim(old);new=trim(new);deltas=[dict(position=j,before=a,after=b)for j,(a,b)in enumerate(zip(old,new))if a!=b];assert len(old)==len(new)and len(deltas)==1
cleanup=[]
for folder in('build1','build2'):
 for p in(W/folder).rglob('*'):
  if p.is_file()and p.suffix.lower()in('.obj','.exe','.dll','.lib','.exp','.pdb','.map'):cleanup.append(pin(p))
cleanup.sort(key=lambda x:x['path']);clean=dict(performed=False,files=cleanup,logical_bytes=sum(x['bytes']for x in cleanup),scope='Only two private entry OBJECT/image/link products and their private native-DLL hardlinks. No banks were written to disk. Canonical tests, original DLL/clean baseline, reusable5leaves, shared SDK, all source/commands/raw logs/inventory/oracles are retained.')
save(W/'cleanup-candidates.json',clean)
summary=dict(status='PASS_GENERATED_ORIGINAL_FORMAT_FULL_AXES_COMPONENT',scope='Ordinary Kimi selected-expert working-set composition for two distinct source codecs; generated numerical bytes, not publisher payload and not complete model inference.',axes=dict(hidden=7168,global_experts=896,top_k=16,latent=3584,expert_intermediate=3072,shared_intermediate=6144),
 generated_data=dict(storage='Generated only in process memory; no large numerical weight-bank files were created or archived.',generator=pin(W/'build2/source/component.cc'),seed='Fixed arithmetic generator with no RNG: each row has one nonzero encoded weight; column=(row*17+expert*13+leg*7)%K, code=1+(expert+leg)%3, fixed two BF16 input patterns.',original_format=True,original_publisher_numeric_payload=False,per_codec_plane_hashes=192,source_inventory=pin(W/'source-inventory.json'),inventory_is_future_missing_roles_not_download_authorization=True,new_HTTP_bytes=0),
 math=dict(Quark='U8 adjacent E2M1 W + U8 E8M0 SF; dynamic BF16 A32 quantize/dequantize, even scale and half-even codes; BF16 operands/Y, F32 dot. Shared FFN uses the same MX contract; latent/router remain BF16/F32.',K512='I32 low-nibble-first offset-binary W + F32 SF; original per512 BF16 scale/reciprocal/I8 truncation, I32 dot then ordered BF16 group products/sum. Shared and latent projections are BF16.',SiTU='Explicit BF16 gate/up -> Cast F32 -> 4*tanh(g/4)*sigmoid(g) times25*tanh(u/25) -> Cast BF16 once. Graph uses existing source-equation reciprocal-literal formation; independent nonlinear oracle checks F32/transcendental plus BF16 interval, not bitwise upstream runtime equality.',separate_FP8_branch='Quark f_a_proj is an independent [128,7168] E4 channel-W/token-A projection on original hidden input, not a fictitious FFN stage. Independent scalar E4/RNE oracle checks its256 values exactly; SW=1 in this fixture does not newly discriminate scale-product order.',router='Actual F32 logits/sigmoid+bias Top16; exact IDs and normalized uncorrected sigmoid weights checked before selected-only upload.',allocation_contract='Same existing WeightSlots/WeightBatch, Graph and retirement machinery; seven banks atomically bind. No new public op, IR, executor, registry or supplier.'),
 actual=dict(process=r['process'],codecs=rows[:2],SiTU_wrong_rounding_witnesses=rows[2]['SiTU_wrong_rounding_witnesses'],maximum_nonlinear_absolute_error=rows[2]['maximum_nonlinear_absolute_error'],exact_BF16_values=sum(x['exact_BF16_values']for x in rows[:2]),nonlinear_BF16_interval_values=sum(x['nonlinear_BF16_interval_values']for x in rows[:2]),route_ID_values_checked=64,normalized_route_F32_weights_checked=64,successful_graph_submissions=10,upload_batches=4,total_logical_staged_submitted_completed_bytes=sum(x['logical_bytes_per_slot']*2 for x in rows[:2]),GPU_released=True),
 failures=[dict(stage='strict1',kind='Private TopK convenience call supplied spec instead of explicit Operation',result='Compiler rejected; corrected only private typed API call, original log retained. The initial full bad TU was not frozen; final actual TU is fully archived.'),dict(stage='run1 actual',process=read(W/'run1/process.json'),kind='Expert down exact sparse-reference mismatch',scope='Quark first-generation gate/up/SiTU had passed; first down comparison stopped before K512 and safety tail. Two Graph completions occurred, without a claim that all outputs were numerically checked.',original_source=pin(W/'build1/source/component.cc'),actual_mismatch_bits_or_maximum_not_retained=True),dict(stage='reference correction',kind='Independent sparse dot omitted original +0 F32 accumulation initialization',proof=read(W/'oracle-zero-review.json'),source_delta=read(W/'oracle-correction.json'),result='Only reference +0 boundary and exact mismatch diagnostic changed; Graph, generated data, axes, precision gate, budgets and product implementation unchanged. Run2 passed; do not reconstruct unretained run1 values.')],
 formal_followup=dict(actual_run2_raw_source=pin(W/'build2/source/component.cc'),migration=formal,strict=checks,canonical_source_pins=[pin(R/x['path'])for x in formal['pins']],root_integration=read(W/'root-integration.json'),formal_gtest_GPU_rerun=False,CMake_configure_or_build_executed=False),
 closure=dict(clean_baseline=baseline,build=read(W/'build2/summary.json'),exact_link_delta=deltas,SDK_rebuilds=0,new_CUDA_kernel_TUs=0,canonical_algorithm_changes=0),
 execution_accounting=dict(actual_GPU_processes=2,failed_actual_processes=1,successful_actual_processes=1,failed_private_strict_compiles=1,successful_entry_compile_links=2,successful_formal_strict_compiles=2,profiler_processes=0,performance_measurement=False,HTTP_bytes=0),
 limits=['The fixture uses generated original-format sparse payloads, not publisher numerical weights. Artifact23/24 full publisher import/execution status is not upgraded.', 'No complete93-layer Kimi, attention/KDA chain, tokenizer/server, task quality, throughput or memory-peak result.', 'True actual Top16 sets change in this generated fixture; future authentic router IDs are unknown and must be observed before any expert fetch.', 'Quark and K512 use distinct numerical contracts; no generic GPTQ decode or BF16 W4A16 substitution.', 'Upload counters and header-derived logical bytes are not physical VRAM/traffic measurements; full source banks are never allocated.', 'Old immutable readers, busy-slot refusal and rejected final binding are exercised. No new arbitrary cancellation/unknown-retirement fault-injection claim.', 'Apple/Vulkan/CPU and a backend or publisher matrix were not added. The formal gtest entry is source-equivalent and strictly compiled, not GPU rerun.'],cleanup=clean)
save(W/'raw-summary.json',summary)
paths=set()
def include(p):
 if p.is_file():paths.add(p)
def tree(folder):
 for p in folder.rglob('*'):
  if p.is_file()and p.suffix.lower()not in('.obj','.exe','.dll','.lib','.exp','.pdb','.map','.zip','.pyc')and'__pycache__'not in p.parts:include(p)
for folder in('before','source','build1','build2','strict1','strict2','run1','run2','canonical-proposal','proposal-before','formal-check1'):tree(W/folder)
for p in W.iterdir():
 if p.is_file()and p.suffix.lower()in('.py','.json','.md','.patch')and p.name not in('proof-summary.json','proof-payloads.json','source-payload-aliases.json'):include(p)
for p in formal['pins']:include(R/p['path'])
# Shared model/source-equation helpers are archived as reading context, not as a claim of rebuilding the SDK.
for rel in('tests/compute_models/mxfp4_reference_fixture.h','tests/compute_models/blockwise_w4a8_fixture.h','tests/compute_models/static_fp8_reference_fixture.h','tests/compute_models/fp8_outer_scale_fixture.h','tests/compute_models/d5_moe_execution_cases.h','tests/compute_models/d5_moe_semantic_fragments.h'):include(R/rel)
by_sha={};payload=[];unique=set()
for p in sorted(paths):
 info=pin(p);canonical=by_sha.setdefault(info['sha256'],p);info['archive_path']=canonical.relative_to(R).as_posix();payload.append(info);unique.add(canonical)
save(W/'proof-payloads.json',payload);unique.add(W/'proof-payloads.json')
save(W/'source-payload-aliases.json',dict(method='Byte-exact SHA256 aliases for duplicate frozen headers/logs. Each logical path resolves through proof-payloads.json archive_path.',aliases=[dict(path=x['path'],archive_path=x['archive_path'],sha256=x['sha256'],bytes=x['bytes'])for x in payload if x['path']!=x['archive_path']],historical_path_resolution=[dict(path=read(W/'build-summary.json')['source']['path'],sha256=read(W/'build-summary.json')['source']['sha256'],archive_path=pin(W/'build1/source/component.cc')['path'],meaning='Original working path was advanced after run1; its frozen run1 bytes live at this snapshot path.')],external_source_pins='SDK binaries and pre-existing research archives are intentionally not copied. Their identities and original cached link/source-header paths are pinned; raw command/dependency paths outside this proof refer to those retained inputs.'))
unique.add(W/'source-payload-aliases.json');archive=W/'proof.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(unique):z.write(p,p.relative_to(R).as_posix())
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for row in payload:
  data=z.read(row['archive_path']);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
public=R/'docs/evidence/correctness/kimi-mixed-selected-working-set-2026-10-25.zip';shutil.copyfile(archive,public)
summary['archive']=dict(pin(public),CRC_verified=True,payload_count=len(unique),original_path_references=len(payload),duplicate_resolution='proof-payloads.json and source-payload-aliases.json')
save(W/'proof-summary.json',summary);save(public.with_suffix('.json'),summary)
print(json.dumps(dict(archive=pin(public),payload_count=len(unique),references=len(payload),cleanup_files=len(cleanup),cleanup_logical_bytes=clean['logical_bytes'],exact_values=summary['actual']['exact_BF16_values'],interval_values=summary['actual']['nonlinear_BF16_interval_values']),indent=2))
