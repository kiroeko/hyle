from pathlib import Path
import importlib.util,sys,re,json,shutil
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025';P=W/'canonical-proposal';A=W/'formal-check1';S=A/'source'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
# Current quoted Hyle closure, with exactly the proposed two direct-include fixes.
seen=set()
def freeze(rel):
 if rel in seen:return
 seen.add(rel);original=P/rel if(P/rel).is_file()else R/rel
 if not original.is_file():return
 out=S/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,out)
 for name in re.findall(r'^\s*#\s*include\s*"([^"]+)"',original.read_text(encoding='utf-8-sig'),flags=re.M):
  choices=[(R/rel).parent/name,R/name,R/'include'/name]
  for p in choices:
   if p.is_file():
    try:child=p.resolve().relative_to(R.resolve())
    except ValueError:continue
    if not str(child).startswith('.scratch'):freeze(child)
    break
freeze(Path('tests/compute_models/kimi_mixed_working_set_consumer_test.cc'))
# New test has no canonical counterpart yet: resolve its relative quote includes from desired location.
for rel in ['engine/inference/artifact_digest.h','engine/inference/prepared_output.h','tests/compute_models/model_plane_resident_weights.h'] : freeze(Path(rel))
freeze(Path('tests/compute_models/glm_mtp_state_consumer_test.cc'))
base1=R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json';base2=R/'.scratch/glm-mlx-flash-original-20261024/native-current/prepared-recipe2.json'
results=[]
for name,base,rel in [('kimi',base1,'tests/compute_models/kimi_mixed_working_set_consumer_test.cc'),('glm',base2,'tests/compute_models/glm_mtp_state_consumer_test.cc')]:
 old=b.args(base);cmd=[old[0],'/I'+str(S),'/I'+str(S/'include'),'/I'+str(R),'/Zs'];skip=False
 for word in old[1:]:
  if skip:skip=False;continue
  if word=='/sourceDependencies':skip=True;continue
  low=word.lower().replace('\\','/')
  if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp'))or low=='/zs':continue
  if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
  cmd.append(word)
 if name=='kimi':cmd.append('/external:IC:/Users/kiro/AppData/Local/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include')
 cmd+=['/sourceDependencies',str(A/name/'dependencies.json'),str(S/rel)]
 b.execute(cmd,A/name,b.environment(old[0]),90)
 results.append(dict(name=name,process=b.read(A/name/'process.json'),source=b.pin(S/rel)))
b.save(A/'summary.json',dict(status='BOTH_FORMAL_KIMI_AND_EXISTING_GLM_STRICT_PASS',checks=results,GPU_executed=False,math_body_identical_to_actual_run2=b.read(W/'formal-migration.json')['executed_body_token_equal'],direct_include_fixes_only_since_GPU=True,pins=[b.pin(P/x)for x in ['tests/compute_models/model_plane_resident_weights.h','tests/compute_models/glm_mlx_runtime_source.h','tests/compute_models/kimi_mixed_working_set_consumer_test.cc','tests/graph_route_cuda/CMakeLists.txt']]))
