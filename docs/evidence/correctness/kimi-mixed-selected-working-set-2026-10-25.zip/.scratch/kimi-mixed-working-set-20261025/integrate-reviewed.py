from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parent
root = base.parents[1]
proposal = base / 'canonical-proposal'
plan = json.loads((base / 'formal-migration.json').read_text('utf-8-sig'))
compiled = json.loads((base / 'formal-check1/summary.json').read_text('utf-8-sig'))
assert compiled['status'] == 'BOTH_FORMAL_KIMI_AND_EXISTING_GLM_STRICT_PASS'
assert all(check['process']['exit'] == 0 for check in compiled['checks'])
assert plan['executed_body_token_equal'] and compiled['math_body_identical_to_actual_run2']

def digest(data):
    return hashlib.sha256(data).hexdigest()

def lf(data):
    return data.replace(b'\r\n', b'\n')

for item in compiled['pins']:
    data = Path(item['path']).read_bytes()
    assert len(data) == item['bytes'] and digest(data) == item['sha256']

changes = []
for item in plan['pins']:
    name = item['path']
    destination = root / name
    old = destination.read_bytes() if destination.exists() else None
    expected_before = item['before_sha256']
    assert (old is None) == (expected_before is None), name
    if old is not None:
        assert digest(lf(old)) == expected_before, ('canonical changed', name)
    selected = (proposal / name).read_bytes()
    assert digest(lf(selected)) == item['after_sha256'], ('proposal changed', name)
    # Preserve the existing file's line-ending choice. The exact mathematical
    # body and headers already checked above differ only in CRLF/LF bytes.
    ending = b'\r\n' if old is not None and b'\r\n' in old else b'\n'
    output = lf(selected).replace(b'\n', ending)
    changes.append((destination, output, dict(path=name,
        before_sha256=digest(old) if old is not None else None,
        after_sha256=digest(output), bytes=len(output),
        same_normalized_source_as_strict_checked_proposal=True)))

for destination, output, _ in changes:
    destination.write_bytes(output)

result = dict(status='EXACT_REVIEWED_FOUR_PATH_INTEGRATION',
              files=[item for _, _, item in changes],
              new_GPU_or_build_run=False,
              boundary='Actual run2 used the unchanged generated mathematical body. Formal gtest entry/includes were strictly checked, not rerun on GPU; CMake registration was source-reviewed, not configured.')
(base / 'root-integration.json').write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
