from pathlib import Path
import difflib,json,hashlib
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025';rel=Path('tests/compute_models/model_plane_resident_weights.h');before=(R/rel).read_text();t=before
t=t.replace('#include "glm_original_moe_roles.h"','#include <array>\n#include <cstdint>\n#include <limits>\n#include <span>\n#include <utility>\n#include "hyle/compute/tensor_desc.h"')
t=t.replace('using Selection=glm_original_moe_roles::Selection;\n','')
t=t.replace('#if defined(HYLE_TEST_GLM_STATE_CUDA)','#if defined(HYLE_COMPUTE_CUDA)')
t=t.replace('  hyle::Status validate(const Selection &s)const {','  template<class Selection> hyle::Status validate(const Selection &s)const {')
t=t.replace('  std::int32_t global(const Selection &s,std::size_t slot)const','  template<class Selection> std::int32_t global(const Selection &s,std::size_t slot)const')
t=t.replace('template<class Source> hyle::Result<CpuBatch> upload(const Selection &selection','template<class Selection,class Source> hyle::Result<CpuBatch> upload(const Selection &selection')
t=t.replace('template<class Source> hyle::Result<c::cuda::WeightBatch> upload(std::size_t slot,const Selection &selection','template<class Selection,class Source> hyle::Result<c::cuda::WeightBatch> upload(std::size_t slot,const Selection &selection')
assert 'glm_original'not in t and 'HYLE_TEST_GLM'not in t
for d,text in[('before',before),('source',t)]:
 p=W/d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(text.encode())
(W/'supply-decoupling.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),t.splitlines(True),fromfile='a/'+rel.as_posix(),tofile='b/'+rel.as_posix())),encoding='utf-8')
(W/'supply-pins.json').write_text(json.dumps(dict(changed=str(rel),before_sha256=hashlib.sha256(before.encode()).hexdigest(),after_sha256=hashlib.sha256(t.encode()).hexdigest(),canonical_modified=False),indent=2)+'\n')
