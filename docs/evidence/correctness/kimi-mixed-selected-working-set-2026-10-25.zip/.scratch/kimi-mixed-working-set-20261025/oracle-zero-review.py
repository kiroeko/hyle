import struct,math,json
from pathlib import Path
f32=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
def bf(x):
 u=struct.unpack('<I',struct.pack('<f',f32(x)))[0]
 return (u+0x7fff+((u>>16)&1))>>16
def w(x):return struct.unpack('<f',struct.pack('<I',x<<16))[0]
def scale(maximum):
 if not maximum:return 2.**-127
 v,e=math.frexp(maximum)
 return 2.**max(-127,min(127,e-(2 if v>=.875 else 3)))
def quant(v,maximum):
 s=scale(maximum);q=w(bf(v/s));mag=(0,.5,1,1.5,2,3,4,6)
 best=min(range(8),key=lambda i:(abs(abs(q)-mag[i]),i&1,i))
 return w(bf(math.copysign(mag[best],q)*s))
def col(row,k,globalid,leg):return (row*17+globalid*13+leg*7)%k
x=[w(bf((1.,2.,-.75,-1.)[i%4]))for i in range(7168)]
for i in range(17):x[i]=w(bf((2.+i/8)/64.))
score=lambda i:f32(f32(1/(1+math.exp(-f32(x[i]*64))))+(i%3-1)/16.)if i<17 else-3.5
ids=sorted(range(896),key=lambda i:-score(i))[:16]
latent=[x[col(i,7168,33,0)]for i in range(3584)]
def projection(x,n,k,g,leg,include_initial_zero):
 mx=[max(abs(a)for a in x[j:j+32])for j in range(0,k,32)]
 out=[]
 for row in range(n):
  k0=col(row,k,g,leg);qa=quant(x[k0],mx[k0//32]);qw=(0,.5,1,1.5)[1+(g+leg)%3]*.25
  value=f32(qa*qw)
  if include_initial_zero:value=f32(0.+value)
  out.append(w(bf(value)))
 return out
count=0;first=None
for slot,g in enumerate(ids):
 gate=projection(latent,3072,3584,g,0,True);up=projection(latent,3072,3584,g,1,True);activated=[]
 for a,b in zip(gate,up):
  sg=f32(1/(1+math.exp(-a)));g0=f32(4*f32(math.tanh(f32(a*.25))));g1=f32(g0*sg);u0=f32(25*f32(math.tanh(f32(b*f32(.04)))));activated.append(w(bf(f32(g1*u0))))
 before=projection(activated,3584,3072,g,2,False);after=projection(activated,3584,3072,g,2,True)
 for row,(a,b)in enumerate(zip(before,after)):
  if bf(a)!=bf(b):
   count+=1
   if first is None:
    k0=col(row,3072,g,2)
    first=dict(slot=slot,global_expert=g,output_row=row,flattened=slot*3584+row,source_column=k0,SiTU_input_bits=bf(activated[k0]),original_sparse_bits=bf(a),F32_initial_plus_zero_bits=bf(b),magnitude_difference=abs(a-b),gate_bits=bf(gate[k0]),up_bits=bf(up[k0]))
result=dict(scope='HOST_ONLY_INDEPENDENT_ORACLE_SELF_AUDIT_NOT_MEASURED_GPU_MISMATCH',actual_run1_values_available=False,run1_message='expert down exact BF16 sparse projection mismatch',expected_epoch0_ids=ids,original_sparse_vs_initial_plus_zero_signed_zero_differences=count,first=first,maximum_numeric_absolute_change=0.0,product_or_Graph_math_changes=False)
p=Path('.scratch/kimi-mixed-working-set-20261025/oracle-zero-review.json');p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
