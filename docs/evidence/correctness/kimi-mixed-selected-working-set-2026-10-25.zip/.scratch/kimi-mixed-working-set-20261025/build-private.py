from pathlib import Path
import importlib.util,sys,json,os,hashlib,shutil
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025';A=W/(sys.argv[1]if len(sys.argv)>1 else'build1')
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
# Freeze only the actual Hyle header dependency closure already read by strict2.
dep=b.read(W/'strict2/dependencies.json')['Data']['Includes']; frozen=[]
for name in dep:
 p=Path(name)
 try:rel=p.resolve().relative_to(R.resolve())
 except ValueError:continue
 if not str(rel).lower().startswith(('include\\','engine\\')):continue
 target=W/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
 if not target.exists():shutil.copyfile(p,target)
 frozen.append(b.pin(target))
b.save(W/'frozen-header-pins.json',frozen)
shutil.copytree(W/'source',A/'source')
original=b.args(R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json')
cmd=[original[0],'/I'+str(A/'source'),'/I'+str(A/'source/include'),'/I'+str(R)];skip=False
for word in original[1:]:
 if skip:skip=False;continue
 if word=='/sourceDependencies':skip=True;continue
 low=word.lower().replace('\\','/')
 if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp'))or low=='/zs':continue
 if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(word)
cmd+=['/sourceDependencies',str(A/'compile/dependencies.json'),str(A/'source/component.cc'),'/Fo'+str(A/'compile/component.obj'),'/Fd'+str(A/'compile/component.pdb')]
env=b.environment(original[0]);b.execute(cmd,A/'compile',env,90)
old=b.args(R/'.scratch/nf4-packed-contraction-20261025/component3/link/command.json');entry=str(R/'.scratch/nf4-packed-contraction-20261025/component3/compile/component.obj');assert old.count(entry)==1
args=[str(A/'compile/component.obj')if x==entry else x for x in old if not x.lower().startswith(('/out:','/pdb:','/map:','/implib:'))]
for x in args[1:]:
 if Path(x).is_absolute()and x.lower().endswith(('.obj','.lib'))and not Path(x).is_file():raise RuntimeError('Missing cached link dependency: '+x)
args+=['/OUT:'+str(A/'link/component.exe'),'/PDB:'+str(A/'link/component.pdb'),'/IMPLIB:'+str(A/'link/component.lib')]
b.execute(args,A/'link',env,90)
native=R/'.scratch/mtp-performance-convergence-20261025/baseline/link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(native,A/'link'/native.name)
leafs=[R/'.scratch/nf4-packed-contraction-20261025'/x for x in ['host1/compute_provider_native--ct_packed/unit.obj','host1/graph_route_cpu--ct_packed_linear_region/unit.obj','host1/graph_route_cuda--ct_packed_linear_region/unit.obj','host1/compute_provider_torch_cuda--artifact_provider/unit.obj','cuda1/unit.obj']]
b.save(A/'summary.json',dict(status='PRIVATE_ENTRY_COMPILED_AND_LINKED_NO_GPU_RUN',compile=b.read(A/'compile/process.json'),link=b.read(A/'link/process.json'),source=b.pin(A/'source/component.cc'),private_supplier=b.pin(A/'source/tests/compute_models/model_plane_resident_weights.h'),image=b.pin(A/'link/component.exe'),native=b.pin(native),reused_low_level_leaves=[b.pin(p)for p in leafs],original_link=b.pin(R/'.scratch/nf4-packed-contraction-20261025/component3/link/command.json'),replacement={'removed_entry':entry,'added_entry':str(A/'compile/component.obj'),'only_entry_changed':True},GPU_started=False,HTTP_bytes=0))
