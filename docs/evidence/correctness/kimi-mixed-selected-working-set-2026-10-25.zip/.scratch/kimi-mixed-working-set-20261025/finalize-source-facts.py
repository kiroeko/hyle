from pathlib import Path
import json,hashlib,difflib
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025'
def read(p):return json.loads(p.read_bytes())
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
migration=read(W/'formal-migration.json');migration['actual_frozen_source_sha256_normalized_lf']=migration.pop('actual_frozen_source_sha256');migration['actual_frozen_raw_source']=pin(W/'build2/source/component.cc')
for row in migration['pins']:
 for old,new in [('before_sha256','before_sha256_normalized_lf'),('after_sha256','after_sha256_normalized_lf'),('after_bytes','after_bytes_normalized_lf')]:row[new]=row.pop(old)
 row['raw_proposal']=pin(W/'canonical-proposal'/row['path']);row['canonical_final_raw']=pin(R/row['path'])
save(W/'formal-migration.json',migration)
# Keep the reproduction script's future field meaning consistent, without rerunning it.
p=W/'prepare-formal.py';s=p.read_text(encoding='utf-8-sig').replace('before_sha256=','before_sha256_normalized_lf=').replace('after_sha256=','after_sha256_normalized_lf=').replace('after_bytes=','after_bytes_normalized_lf=').replace('actual_frozen_source_sha256=','actual_frozen_source_sha256_normalized_lf=');p.write_text(s,encoding='utf8')
p=W/'source-inventory.json';inventory=read(p)
for a in inventory['artifacts']:a['selection_scope']='Illustrative generated-test reservoir0..16 only. The actual generated selections are recorded in run2/result.json; original publisher numeric router IDs are NOT known. This is not an authorized acquisition plan. A publisher-payload phase must first execute the authentic router and resolve only its actual IDs.'
save(p,inventory)
p=W/'inspect-inventory.py';s=p.read_text(encoding='utf8').replace('Illustrative generated-test reservoir0..16 only, for generation sets0..15 and1..16. Original numerical router IDs are NOT known;','Illustrative generated-test reservoir0..16 only. Original numerical router IDs are NOT known;');p.write_text(s,encoding='utf8')
a=(W/'build1/source/component.cc').read_text(encoding='utf8');b=(W/'build2/source/component.cc').read_text(encoding='utf8');without_exact=lambda s:'\n'.join(line for line in s.splitlines()if not line.startswith('void exact('))
assert without_exact(a.replace('result=f32(double(qa)*qw);','result=f32(0.+double(qa)*qw);'))==without_exact(b)
(W/'oracle-correction.patch').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='build1/source/component.cc',tofile='build2/source/component.cc')),encoding='utf8')
save(W/'oracle-correction.json',dict(status='TWO_EXACT_ORACLE_HUNKS_ONLY',before=pin(W/'build1/source/component.cc'),after=pin(W/'build2/source/component.cc'),unchanged_Graph_generator_geometry_budget_and_product=True,changes=['Quark independent sparse dot includes original +0 F32 accumulation boundary','exact mismatch diagnostic prints first index/bits/count/sign-zero count/max absolute difference'],run1_tensor_raw_was_not_dumped=True,run1_actual_maximum_difference_unknown=True,independent_host_zero_review=pin(W/'oracle-zero-review.json')))
print('raw vs normalized pins fixed; exactly two reference-only hunks confirmed')
