from pathlib import Path
import importlib.util,sys,json
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025';A=W/'strict2'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
base=b.args(R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json');cmd=[base[0],'/I'+str(W/'source'),'/I'+str(R),'/Zs'];skip=False
for arg in base[1:]:
 if skip:skip=False;continue
 if arg=='/sourceDependencies':skip=True;continue
 low=arg.lower().replace('\\','/')
 if low.startswith(('/fo','/fd'))or low.endswith(('.cc','.cpp')):continue
 if low.startswith(('/i','-i'))and'/.scratch/'in low and low.endswith('/source'):continue
 cmd.append(arg)
cmd+=['/sourceDependencies',str(A/'dependencies.json'),str(W/'source/component.cc')];b.execute(cmd,A,b.environment(base[0]),60)
b.save(W/'strict-summary.json',dict(status='PRIVATE_SYNTAX_PREPARATION_PASS_NOT_EXECUTED',process=b.read(A/'process.json'),sources=[b.pin(p)for p in(W/'source/component.cc',W/'source/tests/compute_models/model_plane_resident_weights.h')],GPU_not_started=True,component_runtime_main_prepared=True))
