from pathlib import Path
import importlib.util,sys,json,os
sys.dont_write_bytecode=True
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025'
spec=importlib.util.spec_from_file_location('b',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
summary=b.read(W/'build-summary.json');exe=Path(summary['image']['path']);assert b.pin(exe)==summary['image'];assert b.pin(W/'source/component.cc')==summary['source']
base=R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json';runtime=b.read(base);env=os.environ.copy();env['PATH']=str(exe.parent)+os.pathsep+runtime['PATH']
b.save(W/'run-plan.json',dict(status='FROZEN_BEFORE_ACTUAL_RUN',command=[str(exe),'--run'],image=summary['image'],source=summary['source'],runtime=b.pin(base),maximum_processes=1,codecs=['QuarkA32','K512'],ordinary_only=True,generated_weights=True,original_publisher_payload=False,HTTP_bytes=0,profiler=False,performance_claim=False))
b.execute([str(exe),'--run'],W/'run1',env,240)
b.save(W/'run1/result.json',dict(status='ACTUAL_COMPONENT_PASS',process=b.read(W/'run1/process.json'),rows=[json.loads(x)for x in(W/'run1/stdout.log').read_text().splitlines()if x.startswith('{')],image=summary['image'],source=summary['source'],GPU_released=True))
