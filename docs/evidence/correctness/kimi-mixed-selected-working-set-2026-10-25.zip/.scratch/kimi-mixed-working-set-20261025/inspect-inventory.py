from pathlib import Path
import json,hashlib,zipfile
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025';W.mkdir(exist_ok=True)
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
artifacts=[(23,'amd/Kimi-K3-Quark-MXFP4-AttnFP8','398ecc22db3722ed6e416d22f8ddb491da32d566','docs/evidence/research/quark-mxfp4-contract-2026-10-20.zip','artifact/23/model-00002-of-000096.safetensors/','model-00002-of-000096.safetensors'),(24,'open-inference/Kimi-K3-W4A8-K512-GPTQ-Mixed-Cal72-Seq1024','dabd12ab69bf9c71fd219bae4c49a34f00249bd2','docs/evidence/research/fixed-role-binding-2026-10-21.zip','kimi/24/headers/quant-layer-001.safetensors/','quant-layer-001.safetensors')]
out=[]
for index,repo,revision,file,prefix,remote in artifacts:
 archive=R/file
 with zipfile.ZipFile(archive)as z:
  raw=z.read(prefix+'header.json');header=json.loads(raw);declared=int.from_bytes(z.read(prefix+'length.bin'),'little');assert len(raw)==declared
  receipt=json.loads(z.read(prefix+'header.json.http.json'));headers=receipt['headers'];base=8+declared
  total=int(headers['content-range'].split('/')[-1]);rows=[]
  p='language_model.model.layers.1.block_sparse_moe.'
  static=['gate.weight','gate.e_score_correction_bias','routed_expert_down_proj.weight','routed_expert_norm.weight','routed_expert_up_proj.weight']
  for leg in('gate_proj','up_proj','down_proj'):
   static.append('shared_experts.'+leg+'.weight')
   if index==23:static.append('shared_experts.'+leg+'.weight_scale')
  static=[p+s for s in static]
  if index==23:static+=['language_model.model.layers.1.self_attn.f_a_proj.weight','language_model.model.layers.1.self_attn.f_a_proj.weight_scale']
  wanted=[(name,'static',None)for name in static]
  for expert in range(17):
   for leg in('w1','w3','w2'):
    suffixes=('weight','weight_scale')if index==23 else('weight_packed','weight_scale','weight_shape')
    for suffix in suffixes:wanted.append((p+f'experts.{expert}.{leg}.{suffix}','expert',expert))
  for name,kind,expert in wanted:
   row=header[name];start,end=row['data_offsets'];assert 0<=start<end<=total-base
   rows.append(dict(name=name,scope=kind,expert=expert,dtype=row['dtype'],shape=row['shape'],range=[base+start,base+end-1],bytes=end-start,cached_numeric_file=None,payload_hash=None))
  per_expert=sum(x['bytes']for x in rows if x['expert']==0);static_bytes=sum(x['bytes']for x in rows if x['scope']=='static')
  out.append(dict(catalog_index=index,repository=repo,revision=revision,file=remote,url='https://hf-mirror.net/'+repo+'/resolve/'+revision+'/'+remote,source_bytes=total,source_etag=headers['etag'],source_archive=pin(archive),header=dict(entry=prefix+'header.json',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),data_base=base),
   selection_scope='Illustrative generated-test reservoir0..16 only. Original numerical router IDs are NOT known; this is not an authorized acquisition plan. Any original-payload phase must first run the authentic router and resolve only its actual IDs.',
   numeric_cache_review='No artifact23/24 numeric payload found in the authoritative fixed-role/Quark cache trees; those directories/archives contain metadata and generated primitive runs. No exhaustive whole-drive search claim.',
   missing_static_roles=len(static),missing_reservoir_roles=len(rows)-len(static),per_complete_expert_bytes=per_expert,static_bytes=static_bytes,illustrative_complete_reservoir_bytes=sum(x['bytes']for x in rows),
   minimal_authentic_router_frontier=[x for x in rows if x['name']in(p+'gate.weight',p+'gate.e_score_correction_bias')],roles=rows))
sources=[pin(R/p)for p in('include/hyle/compute/model_ops.h','include/hyle/compute/cuda_weights.h','include/hyle/compute/weight_assembly.h','include/hyle/graph/weight_binding.h','tests/compute_models/model_plane_resident_weights.h','tests/compute_models/expert_working_set_fixture.h','tests/compute_models/d5_moe_execution_fragments.h','tests/compute_models/blockwise_w4a8_fixture.h','tests/compute_models/mxfp4_reference_fixture.h')]
(W/'source-inventory.json').write_text(json.dumps(dict(status='READ_ONLY_HEADER_DERIVED_MISSING_ROLE_INVENTORY_NOT_A_DOWNLOAD_PLAN',new_HTTP_bytes=0,full_global_bank_required=False,artifacts=out,inspected_product_sources=sources),indent=2)+'\n')
print(json.dumps([dict(index=x['catalog_index'],static=x['static_bytes'],expert=x['per_complete_expert_bytes'],reservoir=x['illustrative_complete_reservoir_bytes'],roles=len(x['roles']),router_frontier=sum(r['bytes']for r in x['minimal_authentic_router_frontier']))for x in out],indent=2))
