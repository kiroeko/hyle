from pathlib import Path
import re,hashlib,difflib,json,subprocess,shutil
R=Path.cwd();W=R/'.scratch/kimi-mixed-working-set-20261025';P=W/'canonical-proposal';P.mkdir(exist_ok=True)
def save(path,text):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf8')
# Only direct include hygiene follows the actual frozen supplier implementation.
supplier=(W/'build2/source/tests/compute_models/model_plane_resident_weights.h').read_text(encoding='utf8').replace('#include <span>','#include <span>\n#include <stdexcept>')
rel=Path('tests/compute_models/model_plane_resident_weights.h');save(P/rel,supplier)
relglm=Path('tests/compute_models/glm_mlx_runtime_source.h');glm=(R/relglm).read_text(encoding='utf8').replace('#include "glm_mlx_mtp_fragment.h"','#include "glm_mlx_mtp_fragment.h"\n#include "glm_original_moe_roles.h"');save(P/relglm,glm)
old=(W/'build2/source/component.cc').read_text(encoding='utf8');body=old[old.index('namespace c='):old.index('int main(')]
include=old[:old.index('namespace c=')].replace('"engine/inference/','"../../engine/inference/').replace('"tests/compute_models/model_plane_resident_weights.h"','"model_plane_resident_weights.h"')
include+='#include <gtest/gtest.h>\n'
wrapper='''\n} // namespace\n\nTEST(CudaKimiMixedWorkingSet, OriginalFormatsKeepTwoGenerationsAndAtomicBanks) {\n  const auto devices = c::cuda::backend().device_count();\n  if (!devices) {\n    const auto native = devices.error().native_error();\n    if (native.domain == hyle::NativeErrorDomain::CudaRuntime &&\n        native.code == static_cast<std::int64_t>(cudaErrorNoDevice))\n      GTEST_SKIP() << "CUDA runtime reports no device";\n    FAIL() << devices.error().message();\n  }\n  if (*devices == 0)\n    GTEST_SKIP() << "CUDA runtime reports no device";\n  EXPECT_NO_THROW({\n    run(Codec::Quark);\n    run(Codec::K512);\n    require(situ_witnesses > 0, "fixture did not discriminate BF16-intermediate SiTU");\n  });\n}\n'''
new=include+'namespace {\n'+body+wrapper;reltest=Path('tests/compute_models/kimi_mixed_working_set_consumer_test.cc');save(P/reltest,new)
fmt=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/Llvm/x64/bin/clang-format.exe');subprocess.run([str(fmt),'-i','--style={BasedOnStyle: LLVM, SortIncludes: Never, ColumnLimit: 88, BreakStringLiterals: false}',str(P/reltest)],check=True)
# Compare the complete executed body token sequence, excluding only formatting/comments.
formatted=(P/reltest).read_text(encoding='utf8');newbody=formatted[formatted.index('namespace c ='):formatted.rindex('} // namespace')]
tokens=lambda s:re.findall(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_][A-Za-z_0-9]*|\d+(?:\.\d*)?(?:[eE][+-]?\d+)?[A-Za-z_0-9]*|::|->|\+\+|--|==|!=|<=|>=|&&|\|\||<<|>>|[^\s]',re.sub(r'//[^\n]*|/\*.*?\*/','',s,flags=re.S))
assert tokens(body)==tokens(newbody),'Executed component body changed in formal migration'
cmrel=Path('tests/graph_route_cuda/CMakeLists.txt');cm=(R/cmrel).read_text(encoding='utf8');addition='''\nif(_HYLE_COMPUTE_HAVE_CUDA)\n  hyle_add_test(graph_route_cuda NAME kimi_mixed_working_set\n    SOURCES ../compute_models/kimi_mixed_working_set_consumer_test.cc\n    DEPS hyle_compute_backend_cuda)\n  hyle_stage_runtime(hyle_graph_route_cuda_kimi_mixed_working_set_test)\n  set_tests_properties(hyle_graph_route_cuda_kimi_mixed_working_set_test PROPERTIES\n    RUN_SERIAL TRUE TIMEOUT 60 LABELS "graph_route_cuda;quantization;working-set")\nendif()\n''';save(P/cmrel,cm+addition)
changed=[rel,relglm,reltest,cmrel];patch=[];pins=[]
for item in changed:
 before=(R/item).read_text(encoding='utf8')if(R/item).exists()else'';after=(P/item).read_text(encoding='utf8');save(W/'proposal-before'/item,before)
 patch+=list(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+item.as_posix()if before else'/dev/null',tofile='b/'+item.as_posix()))
 pins.append(dict(path=item.as_posix(),before_sha256_normalized_lf=hashlib.sha256(before.encode()).hexdigest()if before else None,after_sha256_normalized_lf=hashlib.sha256(after.encode()).hexdigest(),after_bytes_normalized_lf=len(after.encode())))
save(W/'supply-and-formal-test.patch',''.join(patch));save(W/'formal-migration.json',json.dumps(dict(status='SOURCE_ONLY_FORMAL_ENTRY_MIGRATION_GPU_NOT_RERUN',actual_frozen_source_sha256_normalized_lf=hashlib.sha256(old.encode()).hexdigest(),executed_body_token_equal=True,only_deltas=['direct includes','anonymous namespace','gtest entry with exact no-device skip and driver-error failure','standalone CUDA CMake registration RUN_SERIAL/TIMEOUT60'],pins=pins),indent=2)+'\n')
print('proposed',len(changed),'paths; exact body token identity PASS')
