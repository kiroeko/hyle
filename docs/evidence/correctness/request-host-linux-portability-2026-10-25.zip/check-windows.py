from pathlib import Path
import importlib.util
import json

root = Path.cwd()
work = root / '.scratch/inference-host-linux-20261025/windows-host'
spec = importlib.util.spec_from_file_location('retained_host_build', root / '.scratch/engine-product-20261024/cpu-build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
recipe = build.read(root / '.scratch/inference-incremental-turns-20261025/host1/compile/command.json')['command']
env = build.discover_environment(compiler='msvc', cache={'CMAKE_C_COMPILER':recipe[0], 'CMAKE_CXX_COMPILER':recipe[0], 'CMAKE_GENERATOR':'Ninja'}, backends=()).env
for name in ('inference_request_window_test', 'inference_request_progress_test'):
    folder = work / name
    folder.mkdir(parents=True, exist_ok=False)
    command = []
    for index, arg in enumerate(recipe):
        if index and recipe[index-1] == '/sourceDependencies':
            command.append(str(folder/'dependencies.json'))
        elif arg.startswith('/Fo'):
            command.append('/Fo'+str(folder/'checks.obj'))
        elif arg.startswith('/Fe'):
            command.append('/Fe'+str(folder/'checks.exe'))
        elif arg.endswith('inference_request_progress_test.cc'):
            command.append(str(root/'tests/tools'/(name+'.cc')))
        else:
            command.append(arg)
    build.execute(command, env, folder/'compile', 60)
    build.execute([str(folder/'checks.exe')], env, folder/'run', 30)
    print((folder/'run/stdout.log').read_text())
