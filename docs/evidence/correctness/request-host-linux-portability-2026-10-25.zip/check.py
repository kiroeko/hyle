from pathlib import Path
import hashlib
import json
import platform
import shutil
import subprocess
import time

root = Path(__file__).resolve().parents[2]
work = Path(__file__).parent / 'attempt2'
work.mkdir(exist_ok=False)
compiler = shutil.which('g++')
assert compiler
tests = ['inference_request_window_test', 'inference_request_progress_test', 'inference_output_delivery_test']
headers = ['engine/inference/request_window.h', 'engine/inference/request_progress.h', 'engine/inference/output_delivery.h', 'engine/inference/sampling_cursor.h']
paths = headers + ['tests/tools/' + test + '.cc' for test in tests]
def pins():
    return {name: {'bytes': (root/name).stat().st_size, 'sha256': hashlib.sha256((root/name).read_bytes()).hexdigest()} for name in paths}
before = pins()
facts = {'system': platform.platform(), 'machine': platform.machine(), 'compiler': compiler,
         'version': subprocess.check_output([compiler, '--version'], text=True), 'source_pins': before,
         'GPU_runs': 0, 'SDK_builds': 0, 'HTTP': 0, 'results': {}}
for test in tests:
    folder = work / test
    folder.mkdir()
    image = folder / 'checks'
    command = [compiler, '-std=c++23', '-O2', '-Wall', '-Wextra', '-Wpedantic', '-Werror', '-MMD', '-MF', str(folder / 'dependencies.d'), str(root/'tests/tools'/ (test + '.cc')), '-o', str(image)]
    facts['results'][test] = {}
    for stage, args in [('compile', command), ('run', [str(image)])]:
        started = time.time()
        process = subprocess.run(args, cwd=root, text=True, capture_output=True, timeout=60 if stage=='compile' else 30)
        record = {'command': args, 'exit': process.returncode, 'seconds': time.time()-started}
        (folder/(stage + '-stdout.log')).write_text(process.stdout)
        (folder/(stage + '-stderr.log')).write_text(process.stderr)
        facts['results'][test][stage] = record
        if process.returncode:
            break
assert before == pins()
facts['status'] = 'HOST_COMPONENT_ONLY_PASS' if all(len(item)==2 and all(stage['exit']==0 for stage in item.values()) for item in facts['results'].values()) else 'HOST_CHECK_FAILED'
(work/'summary.json').write_text(json.dumps(facts, indent=2)+'\n')
print(json.dumps({'status': facts['status'], 'system': facts['system'], 'compiler': facts['version'].splitlines()[0], 'results': {key: {name: value['exit'] for name,value in item.items()} for key,item in facts['results'].items()}}, indent=2))
raise SystemExit(0 if facts['status']=='HOST_COMPONENT_ONLY_PASS' else 1)
