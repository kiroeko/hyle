Original fixed-revision Qwen3.5-2B-MTP GGUF structural headers only.
Raw10.96MB headers/tokenizer arrays are retained in local cache, not duplicated in this archive.
header.json contains the full physical tensor table and non-tokenizer metadata.
No tensor payload was downloaded/read/dequantized. Payload plans are unexecuted proposals.
GGUF norm/decay meaning follows the qwen35 model contract; no parameter values or quality were tested.
Full engine GGUF loading/graphs/MTP execution are not connected by these preparer-only changes.
