"""Get only two fixed Q35 MTP GGUF structural headers, via existing budget.py.

Default `check` is offline. This program has no tensor-payload download mode.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import re
import struct
import sys
import time
import urllib.parse
import urllib.request

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BUDGET = ROOT / '.scratch/mtp-download-budget-20261023/budget.py'
GRAMMAR = ROOT / 'engine/models/qwen35/gguf_header.py'
SCRIPT = Path(__file__).resolve().relative_to(ROOT).as_posix()
REPO = 'unsloth/Qwen3.5-2B-MTP-GGUF'
REVISION = 'e05864f8066d874d5f85aaff007ae57a2a7d1efe'
FILES = ('Qwen3.5-2B-UD-Q4_K_XL.gguf', 'Qwen3.5-2B-UD-Q8_K_XL.gguf')
HOST = 'hf-mirror.net'
METADATA_MAX = 131072
HEADER_MAX = 16777216
CHUNK_MAX = 262144
MAX_REQUESTS_PER_FILE = 512
METADATA_URL = f'https://{HOST}/api/models/{REPO}/tree/{REVISION}?recursive=false&expand=false'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def save(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.next')
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def identity(path):
    raw = Path(path).read_bytes()
    return dict(path=Path(path).relative_to(ROOT).as_posix(), bytes=len(raw), sha256=digest(raw))


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def check_plan():
    plan = load(HERE / 'header-range-plan.json')
    if (plan['repository'], plan['revision']) != (REPO, REVISION):
        raise ValueError('fixed header identity differs')
    if tuple(row['file'] for row in plan['files']) != FILES:
        raise ValueError('only the two selected profiles are permitted')
    if plan['maximum_header_bytes_two_files'] != 2 * HEADER_MAX:
        raise ValueError('header bound changed')
    for row in plan['files']:
        expected = f'https://{HOST}/{REPO}/resolve/{REVISION}/{row["file"]}'
        if (row['uri'] != expected or row['initial_exact_absolute_inclusive'] != [0, 23]
                or row['maximum_complete_structural_header_bytes'] != HEADER_MAX
                or row['maximum_range_chunk_bytes'] != CHUNK_MAX
                or row['tensor_payload_authorized_bytes'] != 0):
            raise ValueError('structural-only plan differs')
    cached = plan['cached_api_identity']
    if identity(ROOT / cached['path']) != cached:
        raise ValueError('cached model API identity changed')
    api = load(ROOT / cached['path'])
    if api['id'] != REPO or api['sha'] != REVISION:
        raise ValueError('cached model API revision differs')
    if not all(name in {row['rfilename'] for row in api['siblings']} for name in FILES):
        raise ValueError('a selected file is not in the pinned model revision')
    return plan


@contextmanager
def exclusive():
    with (HERE / 'header-acquisition.lock').open('a+b') as handle:
        handle.seek(0, 2)
        if not handle.tell():
            handle.write(b'0')
            handle.flush()
        handle.seek(0)
        if sys.platform == 'win32':
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            handle.seek(0)
            if sys.platform == 'win32':
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


class Fetch:
    def __init__(self, budget, timeout):
        self.budget, self.timeout = budget, timeout

    def get(self, url, first, last, *, size=None, etag=None, metadata=False):
        parsed = urllib.parse.urlsplit(url)
        if (parsed.scheme != 'https' or parsed.hostname != HOST or parsed.port not in (None, 443)
                or parsed.username or parsed.password or parsed.fragment):
            raise ValueError('not the fixed HTTPS mirror origin')
        maximum = METADATA_MAX if metadata else CHUNK_MAX
        amount = last - first + 1
        if first < 0 or not 0 < amount <= maximum:
            raise ValueError('range exceeds bounded request size')
        if metadata:
            if url != METADATA_URL or (first, last) != (0, METADATA_MAX - 1):
                raise ValueError('only fixed-revision tree metadata is permitted')
        elif size is None or etag is None or last >= min(size, HEADER_MAX):
            raise ValueError('range identity or structural bound is invalid')
        with self.budget.locked() as record:
            ordinal_floor = len(record['requests'])
        headers = {'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity',
                   'Cache-Control': 'no-transform', 'User-Agent': 'Hyle-MTP-GGUF-structural/2026-10-24'}
        if etag is not None:
            headers['If-Match'] = etag
        request = urllib.request.Request(url, headers=headers)
        received, raw, response_info = 0, bytearray(), None
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                self.budget.require_mirror_url(response.geturl())
                if response.headers.get('Content-Encoding', 'identity').lower() != 'identity':
                    raise ValueError('encoded response is not an exact source range')
                commit = response.headers.get('X-Repo-Commit')
                if commit is not None and commit != REVISION:
                    raise ValueError('response repository revision differs')
                if metadata:
                    if response.status not in (200, 206):
                        raise ValueError('metadata response status is invalid')
                    length = response.headers.get('Content-Length')
                    if length is not None and int(length) > METADATA_MAX:
                        raise ValueError('metadata body exceeds the explicit bound')
                else:
                    expected = f'bytes {first}-{last}/{size}'
                    if response.status != 206 or response.headers.get('Content-Range') != expected:
                        raise ValueError('not the exact206 range and original file size')
                    if response.headers.get('ETag') != etag:
                        raise ValueError(f"strong original API transport ETag differs: expected{etag}, got{response.headers.get('ETag')}")
                    length = response.headers.get('Content-Length')
                    if length is None or int(length) != amount:
                        raise ValueError('range Content-Length differs')
                read = getattr(response, 'read1', response.read)
                started = time.monotonic()
                limit = METADATA_MAX if metadata else amount
                while len(raw) < limit:
                    if time.monotonic() - started > 180:
                        raise TimeoutError('single structural request exceeded180s')
                    part = read(min(65536, limit - len(raw)))
                    if not part:
                        break
                    raw.extend(part)
                    received += len(part)
                # A structural request never reads one byte past its closed
                # range, including when that byte would be the first tensor.
                # Its exact Content-Length and Content-Range were checked
                # before reading. Only bounded JSON metadata needs EOF probing.
                if metadata:
                    extra = read(1)
                    received += len(extra)
                    if extra:
                        raise ValueError('response exceeds the explicit body bound')
                if not metadata and len(raw) != amount:
                    raise EOFError('structural range body ended early')
                if metadata and response.status == 206:
                    expected = f'bytes 0-{len(raw) - 1}/{len(raw)}'
                    if response.headers.get('Content-Range') != expected:
                        raise ValueError('metadata206 must contain the whole bounded JSON response')
                response_info = dict(status=response.status, final_url=response.geturl(),
                    etag=response.headers.get('ETag'), content_range=response.headers.get('Content-Range'),
                    revision=commit, received_bytes=len(raw), sha256=digest(raw))
            ordinal = self.reservation(ordinal_floor, url, first, last)
            self.budget.update(ordinal, outcome='downloaded', received_bytes=received,
                               sha256=digest(raw), verified_response=response_info)
            response_info['budget_request_id'] = ordinal
            return bytes(raw), response_info
        except BaseException as error:
            ordinal = self.reservation(ordinal_floor, url, first, last, required=False)
            if ordinal is not None:
                self.budget.update(ordinal, outcome='failed', received_bytes=received,
                                   error_type=type(error).__name__, error=str(error))
            raise

    def reservation(self, floor, url, first, last, required=True):
        with self.budget.locked() as record:
            found = [row['id'] for row in record['requests'][floor:]
                     if row['script'] == SCRIPT and row['url'] == url.split('?')[0]
                     and row['range'] == [first, last]]
        if len(found) > 1 or (required and len(found) != 1):
            raise RuntimeError('HTTP attempt has no unique matching budget receipt')
        return found[0] if found else None


def original_identities(raw):
    rows = json.loads(raw)
    if not isinstance(rows, list):
        raise ValueError('fixed tree API did not return an array')
    result = []
    for name in FILES:
        selected = [row for row in rows if row.get('path') == name]
        if len(selected) != 1 or selected[0].get('type') != 'file':
            raise ValueError('selected original file is not unique in metadata')
        row = selected[0]
        lfs = row.get('lfs', {})
        oid = lfs.get('oid', lfs.get('sha256'))
        if not isinstance(oid, str) or not re.fullmatch('[0-9a-f]{64}', oid):
            raise ValueError('original file has no unambiguous SHA256 LFS identity')
        if 'oid' in lfs and 'sha256' in lfs and lfs['oid'] != lfs['sha256']:
            raise ValueError('conflicting original LFS SHA256 values')
        size = row.get('size')
        if type(size) is not int or size < 24 or lfs.get('size') != size:
            raise ValueError('original API size and LFS size differ')
        xet = row.get('xetHash')
        if xet is not None and (not isinstance(xet, str) or not re.fullmatch('[0-9a-f]{64}', xet)):
            raise ValueError('original API Xet content identity is invalid')
        # Xet-backed transfers use their API-pinned Xet content identity as
        # ETag. It is distinct from the original file's LFS SHA256, retained
        # separately; neither is falsely described as a partial-range SHA.
        result.append(dict(file=name, size=size, lfs_sha256=oid, api_xet_hash=xet,
                           etag='"' + (xet or oid) + '"', etag_basis='API xetHash' if xet else 'API LFS SHA256',
                           uri=f'https://{HOST}/{REPO}/resolve/{REVISION}/{name}'))
    return result


def obtain_identities(fetch):
    body_path, receipt_path = HERE / 'fixed-tree-api.json', HERE / 'fixed-tree-api-receipt.json'
    if body_path.exists() or receipt_path.exists():
        receipt = load(receipt_path)
        if receipt['url'] != METADATA_URL or receipt['body'] != identity(body_path):
            raise ValueError('cached fixed-revision tree API identity differs')
        return original_identities(body_path.read_bytes())
    raw, response = fetch.get(METADATA_URL, 0, METADATA_MAX - 1, metadata=True)
    selected = original_identities(raw)
    body_path.write_bytes(raw)
    save(receipt_path, dict(repository=REPO, revision=REVISION, url=METADATA_URL,
                           response=response, body=identity(body_path), selected=selected))
    return selected


class Header:
    def __init__(self, fetch, source):
        self.fetch, self.source = fetch, source
        self.folder = HERE / source['file'].removesuffix('.gguf')
        self.folder.mkdir(exist_ok=True)
        self.body = self.folder / 'header.bin'
        self.receipt = self.folder / 'acquisition.json'
        self.state = load(self.receipt) if self.receipt.exists() else dict(
            repository=REPO, revision=REVISION, source=source, complete=False, blocks=[])
        if (self.state['source'] != source and not self.state['blocks'] and not self.body.exists()
                and all(self.state['source'].get(key) == source[key]
                        for key in ('file', 'size', 'lfs_sha256', 'uri'))):
            self.state['unstarted_transport_identity'] = self.state['source']
            self.state['source'] = source
        if (self.state['repository'], self.state['revision'], self.state['source']) != (REPO, REVISION, source):
            raise ValueError('partial header belongs to another original identity')
        self.raw = self.body.read_bytes() if self.body.exists() else b''
        cursor = 0
        for block in self.state['blocks']:
            first, last = block['absolute_inclusive']
            if first != cursor or digest(self.raw[first:last + 1]) != block['sha256']:
                raise ValueError('cached structural prefix identity differs')
            cursor = last + 1
        if len(self.raw) != cursor or cursor > HEADER_MAX:
            raise ValueError('uncommitted or oversize header prefix; do not silently redownload')
        save(self.receipt, self.state)

    def exact(self, url, first, last, *, total=None, etag=None):
        source = self.source
        if (url != source['uri'] or first < 0 or last < first or last >= HEADER_MAX
                or total not in (None, source['size']) or etag not in (None, source['etag'])):
            raise ValueError('structural reader requested another identity or bound')
        if last < len(self.raw):
            return self.raw[first:last + 1], source['size'], source['etag']
        if first != len(self.raw):
            raise ValueError('only a contiguous new structural suffix may be requested')
        if len(self.state['blocks']) >= MAX_REQUESTS_PER_FILE:
            raise ValueError('finite structural request-count bound reached')
        raw, response = self.fetch.get(url, first, last, size=source['size'], etag=source['etag'])
        with self.body.open('ab') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        self.raw += raw
        self.state['blocks'].append(dict(absolute_inclusive=[first, last], bytes=len(raw),
                                         sha256=digest(raw), response=response))
        save(self.receipt, self.state)
        print(f"{source['file']}: structural prefix {len(self.raw)}B", flush=True)
        return raw, source['size'], source['etag']

    def scan(self, grammar):
        prefix = self.exact(self.source['uri'], 0, 23)[0]
        magic, version, tensors, metadata_count = struct.unpack('<4sIQQ', prefix)
        if magic != b'GGUF' or version not in (2, 3) or not 0 < tensors <= 4096 or not 0 < metadata_count <= 1000:
            raise ValueError('GGUF preamble is outside this bounded model header task')
        raw, metadata, roles, count, total, etag = grammar.scan(self.exact,
            url=self.source['uri'], tensor_count=tensors, maximum_header_bytes=HEADER_MAX, chunk_bytes=CHUNK_MAX)
        if len(raw) != len(self.raw) or raw != self.raw or total != self.source['size'] or etag != self.source['etag']:
            raise ValueError('complete structural header identity differs')
        self.state.update(complete=True, header_bytes=len(raw), header_sha256=digest(raw),
                          tensor_count=tensors, metadata_count=count, tensor_payload_bytes_acquired=0)
        save(self.receipt, self.state)
        save(self.folder / 'header.json', dict(repository=REPO, revision=REVISION, file=self.source['file'],
            original_file=self.source, gguf_version=version, tensor_count=tensors, metadata_count=count,
            tensor_data_offset=len(raw), metadata=metadata, tensors=roles, header=identity(self.body),
            tensor_payload_bytes_acquired=0))
        return dict(file=self.source['file'], original_file=self.source, header=identity(self.body),
                    tensor_data_offset=len(raw), tensor_count=tensors, metadata_count=count)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('check', 'acquire'), default='check', nargs='?')
    parser.add_argument('--timeout', type=int, default=30)
    args = parser.parse_args()
    if not 1 <= args.timeout <= 60:
        parser.error('timeout must be1..60seconds')
    check_plan()
    print(json.dumps(dict(action=args.action, repository=REPO, revision=REVISION, files=FILES,
        metadata_body_bytes_bound=METADATA_MAX, two_header_bytes_bound=2 * HEADER_MAX,
        maximum_request_bytes=CHUNK_MAX, tensor_payload_authorized_bytes=0, retries=0)), flush=True)
    if args.action == 'check':
        return
    if Path(inspect.getsourcefile(urllib.request.urlopen) or '').resolve() != BUDGET.resolve():
        raise RuntimeError('acquire must run through the existing budget.py guard')
    budget = module('mtp_existing_budget', BUDGET)
    grammar = module('mtp_gguf_structural_grammar', GRAMMAR)
    with exclusive():
        fetch = Fetch(budget, args.timeout)
        sources = obtain_identities(fetch)
        headers = [Header(fetch, source).scan(grammar) for source in sources]
        save(HERE / 'header-acquisition-summary.json', dict(repository=REPO, revision=REVISION,
            complete=True, headers=headers, tensor_payload_bytes_acquired=0,
            original_file_SHA256_verified='Pinned API LFS SHA256 and size retained; strong206 ETag matches the same API Xet content identity (or LFS SHA for non-Xet). Entire multi-GB file was not read/hash-verified.'))


if __name__ == '__main__':
    main()
