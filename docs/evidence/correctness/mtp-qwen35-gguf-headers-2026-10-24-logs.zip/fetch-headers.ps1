param(
    [switch] $Execute,
    [string] $Python = 'python'
)
$ErrorActionPreference = 'Stop'
$headerDirectory = Split-Path -Parent $PSCommandPath
$repoRoot = (Resolve-Path -LiteralPath (Join-Path $headerDirectory '../..')).Path
$downloadScript = Join-Path $headerDirectory 'fetch-headers.py'
$budgetDirectory = Join-Path $repoRoot '.scratch/mtp-download-budget-20261023'
$budgetScript = Join-Path $budgetDirectory 'budget.py'
$pauseFile = Join-Path $budgetDirectory 'PAUSED'
$heldPause = Join-Path $budgetDirectory 'PAUSED.q35-gguf-headers-held'
Push-Location -LiteralPath $repoRoot
try {
    if (-not $Execute) {
        & $Python -B -X utf8 $downloadScript check
        if ($LASTEXITCODE -ne 0) { throw "Offline header plan check failed: $LASTEXITCODE" }
        return
    }
    if (-not (Test-Path -LiteralPath $pauseFile -PathType Leaf)) {
        throw 'Expected PAUSED before this explicit header batch; another batch may own acquisition.'
    }
    if (@(Get-ChildItem -LiteralPath $budgetDirectory -File |
            Where-Object { $_.Name.StartsWith('PAUSED.', [StringComparison]::Ordinal) }).Count -ne 0) {
        throw 'Another held pause marker exists; no request started.'
    }
    Move-Item -LiteralPath $pauseFile -Destination $heldPause
    try {
        & $Python -B -X utf8 $budgetScript run $downloadScript acquire
        if ($LASTEXITCODE -ne 0) { throw "Bounded structural acquisition stopped: $LASTEXITCODE" }
    }
    finally {
        if (-not (Test-Path -LiteralPath $pauseFile)) {
            Move-Item -LiteralPath $heldPause -Destination $pauseFile
        }
        else {
            Write-Warning "PAUSED was restored externally; original marker retained at $heldPause"
        }
    }
}
finally {
    Pop-Location
}
