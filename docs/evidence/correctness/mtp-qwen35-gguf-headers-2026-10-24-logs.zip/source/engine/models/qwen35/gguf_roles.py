"""Typed Qwen3.5-2B text/MTP GGUF header inventory, without payload conversion.

This is input preparation, not a generic GGUF loader or an inference executor.
The record is deliberately distinct from HYLE_QWEN35_ROLE_FILES_V1 (HF roles).
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re

if __package__:
    from .gguf_header import read_local_header, require
else:
    from gguf_header import read_local_header, require

SIGNATURE = 'HYLE_QWEN35_GGUF_HEADER_ROLES_V1'
# These are the actual physical formats in the two selected MTP profiles.
# They describe original storage, not activation precision or a Provider.
CODECS = {0: ('F32', 1, 4), 1: ('F16', 1, 2), 8: ('Q8_0', 32, 34), 12: ('Q4_K', 256, 144),
          13: ('Q5_K', 256, 176), 14: ('Q6_K', 256, 210)}


def role_specs():
    """Logical [N,K] matrices and their exact GGUF ne/source-role meaning."""
    result = {}

    def add(physical, logical, shape, semantic):
        result[physical] = dict(logical_name=logical, logical_shape=list(shape), semantic=semantic)

    add('token_embd.weight', 'model.language_model.embed_tokens.weight', (248320,2048), 'embedding_rows')
    add('output_norm.weight', 'model.language_model.norm.weight', (2048,), 'rms_effective_gamma')
    for layer in range(25):
        physical = f'blk.{layer}.'
        logical = f'model.language_model.layers.{layer}.' if layer < 24 else 'mtp.layers.0.'
        for source, target in (('attn_norm.weight','input_layernorm.weight'),
                               ('post_attention_norm.weight','post_attention_layernorm.weight')):
            add(physical+source, logical+target, (2048,), 'rms_effective_gamma')
        for leg, shape in (('gate',(6144,2048)), ('up',(6144,2048)), ('down',(2048,6144))):
            add(physical+f'ffn_{leg}.weight', logical+f'mlp.{leg}_proj.weight', shape, 'linear_weight')
        if layer == 24 or layer % 4 == 3:
            for source, target, shape in (
                ('attn_q.weight','q_proj.weight',(4096,2048)),
                ('attn_k.weight','k_proj.weight',(512,2048)),
                ('attn_v.weight','v_proj.weight',(512,2048)),
                ('attn_output.weight','o_proj.weight',(2048,2048))):
                add(physical+source, logical+'self_attn.'+target, shape, 'linear_weight')
            for axis in ('q','k'):
                add(physical+f'attn_{axis}_norm.weight', logical+f'self_attn.{axis}_norm.weight',
                    (256,), 'rms_effective_gamma')
        else:
            for source, target, shape, semantic in (
                ('ssm_a','A_log',(16,), 'gdn_negative_exp_A_log'),
                ('ssm_dt.bias','dt_bias',(16,), 'gdn_dt_bias'),
                ('ssm_norm.weight','norm.weight',(128,), 'gdn_effective_gamma'),
                ('ssm_conv1d.weight','conv1d.weight',(6144,1,4), 'gdn_convolution_kernel'),
                ('attn_qkv.weight','in_proj_qkv.weight',(6144,2048), 'linear_weight'),
                ('attn_gate.weight','in_proj_z.weight',(2048,2048), 'linear_weight'),
                ('ssm_alpha.weight','in_proj_a.weight',(16,2048), 'linear_weight'),
                ('ssm_beta.weight','in_proj_b.weight',(16,2048), 'linear_weight'),
                ('ssm_out.weight','out_proj.weight',(2048,2048), 'linear_weight')):
                add(physical+source, logical+'linear_attn.'+target, shape, semantic)
    for source, target, shape, semantic in (
        ('eh_proj','fc',(2048,4096),'linear_weight'),
        ('enorm','pre_fc_norm_embedding',(2048,),'rms_effective_gamma'),
        ('hnorm','pre_fc_norm_hidden',(2048,),'rms_effective_gamma'),
        ('shared_head_norm','norm',(2048,),'rms_effective_gamma')):
        add('blk.24.nextn.'+source+'.weight', 'mtp.'+target+'.weight', shape, semantic)
    return result


def _shape_ne(spec):
    shape = spec['logical_shape']
    if spec['semantic'] == 'gdn_convolution_kernel':
        return [4,6144]
    return list(reversed(shape))


def typed_inventory(header, source, *, header_sha256):
    """Validate a complete header; preserve physical names, bytes and meaning.

    Naming the decay's HF destination A_log does not make its bytes raw A_log:
    its explicit semantic tag requires direct negative-exp consumption. The
    caller must not pass this record to the existing HF-only role loader.
    """
    require(isinstance(source, dict) and bool(source.get('repository')) and
            re.fullmatch('[0-9a-f]{40}', source.get('revision','')) and
            re.fullmatch('[0-9a-f]{64}', source.get('lfs_sha256','')) and
            re.fullmatch('[0-9a-f]{64}', header_sha256) and
            isinstance(source.get('file'),str) and source['file'].endswith('.gguf') and
            type(source.get('size')) is int and source['size'] > 0,
            'GGUF inventory requires its fixed original file/revision/SHA/size identity')
    metadata = header['metadata']
    required = {'general.architecture':'qwen35', 'general.type':'model', 'qwen35.block_count':25,
                'qwen35.embedding_length':2048, 'qwen35.feed_forward_length':6144,
                'qwen35.attention.head_count':8, 'qwen35.attention.head_count_kv':2,
                'qwen35.attention.key_length':256, 'qwen35.attention.value_length':256,
                'qwen35.ssm.conv_kernel':4, 'qwen35.ssm.state_size':128,
                'qwen35.ssm.group_count':16, 'qwen35.ssm.time_step_rank':16,
                'qwen35.ssm.inner_size':2048, 'qwen35.full_attention_interval':4,
                'qwen35.rope.dimension_count':64, 'qwen35.nextn_predict_layers':1}
    for key, expected in required.items():
        require(metadata.get(key) == expected, f'unsupported Qwen3.5-2B GGUF geometry: {key}')
    require(type(metadata.get('qwen35.context_length')) is int and
            0 < metadata['qwen35.context_length'] <= 262144, 'invalid Qwen GGUF context limit')
    epsilon = metadata.get('qwen35.attention.layer_norm_rms_epsilon')
    require(isinstance(epsilon,(int,float)) and math.isfinite(epsilon) and abs(epsilon-1.e-6) < 1.e-12,
            'unsupported Qwen GGUF norm epsilon')
    require(metadata.get('qwen35.rope.dimension_sections') == [11,11,10,0] and
            metadata.get('qwen35.rope.freq_base') == 10000000.0, 'unsupported Qwen GGUF RoPE parameters')
    require(metadata.get('split.count',1) == 1 and metadata.get('split.no',0) == 0,
            'this input inventory requires a complete single-file GGUF header')
    specs = role_specs()
    tensors = header['tensors']
    names = [row['name'] for row in tensors]
    require(header['tensor_count'] == len(tensors) == len(specs) == 335 and len(set(names)) == len(names),
            'Qwen GGUF tensor inventory is incomplete or duplicated')
    require(set(names) == set(specs), 'Qwen GGUF has missing, extra, visual or independent-head roles')
    require(metadata.get('split.tensors.count',335) == 335, 'split GGUF tensor total differs')
    start = header['tensor_data_offset']
    require(type(start) is int and 24 <= start <= 16*1024*1024 and start <= source['size'],
            'invalid complete GGUF tensor-data offset')
    alignment = metadata.get('general.alignment',32)
    require(type(alignment) is int and 0 < alignment <= 4096 and start % alignment == 0,
            'invalid GGUF role/data alignment')
    roles = []
    for row in tensors:
        spec = specs[row['name']]
        require(row['shape'] == _shape_ne(spec), 'GGUF role shape differs: '+row['name'])
        code = row['dtype_code']
        require(type(code) is int and code in CODECS, 'unsupported physical GGUF codec: '+row['name'])
        codec, block_elements, block_bytes = CODECS[code]
        shape = spec['logical_shape']
        require(spec['semantic'] in ('linear_weight','embedding_rows') or code == 0,
                'GGUF scalar/norm/convolution must preserve its F32 representation: '+row['name'])
        require(row['shape'][0] % block_elements == 0, 'GGUF role has an incomplete physical K block')
        count = math.prod(row['shape'])
        extent = count // block_elements * block_bytes
        offset = row['offset']
        require(type(offset) is int and offset >= 0 and offset % alignment == 0 and
                extent <= source['size']-start-offset, 'GGUF role range exceeds its original source: '+row['name'])
        plain = block_elements == 1
        storage = dict(kind='plain' if plain else 'gguf_blocked', dtype=codec,
                       logical_dtype=codec if plain else 'F32', logical_shape=shape, original_ne=row['shape'])
        if not plain:
            storage.update(block_axis=1, elements_per_block=block_elements, bytes_per_block=block_bytes,
                           byte_strides=[shape[1]//block_elements*block_bytes, block_bytes])
        roles.append(dict(physical_name=row['name'], logical_name=spec['logical_name'],
                          semantic=spec['semantic'], dtype_code=code, storage=storage,
                          original_offset=offset, absolute_inclusive=[start+offset,start+offset+extent-1],
                          bytes=extent, materialization='none; original physical bytes and view-only layout'))
    ordered = sorted(roles,key=lambda row:row['absolute_inclusive'][0])
    require(all(a['absolute_inclusive'][1] < b['absolute_inclusive'][0] for a,b in zip(ordered,ordered[1:])),
            'GGUF physical role ranges overlap')
    counts = Counter(row['storage']['dtype'] for row in roles)
    return dict(signature=SIGNATURE, family='qwen35_2b', complete_header=True,
        source=dict(source, header_sha256=header_sha256, header_bytes=start),
        physical_role_count=len(roles), main_role_count=sum(not row['logical_name'].startswith('mtp.') for row in roles),
        mtp_role_count=sum(row['logical_name'].startswith('mtp.') for row in roles),
        physical_codecs=dict(sorted(counts.items())), selected_payload_bytes=sum(row['bytes'] for row in roles),
        geometry=dict(required, context_length=metadata['qwen35.context_length']),
        representation=dict(rms_norm='effective F32 gamma; do not add one',
            gdn_norm='original F32 gamma; no delta conversion', gdn_decay='ssm_a is negative exp(A_log); do not Exp/Neg again',
            gdn_convolution='GGUF ne[4,6144] viewed as logical[6144,1,4], no repacking',
            matrix_layout='logical[N,K] view of original GGUF rows; packed block axis1',
            activation_precision='not selected by this header inventory',
            convention_basis='qwen35 GGUF model contract; header identifies roles/storage, no parameter values were read'),
        vocabulary=dict(embedding_physical='token_embd.weight', target_head_physical='token_embd.weight',
            draft_embedding_physical='token_embd.weight', draft_head_physical='token_embd.weight',
            independent_head_present=False, scope='actual complete335-role inventory, not a source-family assumption'),
        roles=roles, tensor_payload_bytes_read=0)


def inspect_local(path, source):
    header, raw = read_local_header(path,whole_file_bytes=source['size'])
    return typed_inventory(header,source,header_sha256=hashlib.sha256(raw).hexdigest())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--header',type=Path,required=True)
    parser.add_argument('--source-identity',type=Path,required=True,
        help='JSON object: repository/revision/file/size/lfs_sha256; header-only source, no HTTP')
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    result = inspect_local(args.header,json.loads(args.source_identity.read_bytes()))
    with args.output.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(result,output,ensure_ascii=False,indent=2); output.write('\n')


if __name__ == '__main__':
    main()
