"""Offline W16/W17 correctness receipt; no build, consumer or download action."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
V = R/'.scratch/inference-wave-recovery-20261027'
P = R/'.scratch/inference-continuous-wave-20261027'
D = R/'docs/evidence/correctness'
STEM = 'inference-wave-recovery-2026-10-27'
FINAL_MAIN = '441ff48649cef90205d97f4fbbf71cdd73a4f06b1fdd9d85cbd4fd3ff64fffd3'
COMMON = '6c4e5e13232b10aff556a1396f943662715220170213011995e23643e589cc09'
FIXED_HOST = '80251057f96f49a16c1f9e9facff3a2fb57236dcbec59724a4204f1100445d8b'
CLI = ('cli-cpu-ordinary-b2', 'cli-cpu-mtp-k3-b2', 'cli-cuda-ordinary-b2', 'cli-cuda-mtp-k3-b2')
RUNS = ('two-turn-default', 'two-turn-budget', 'two-turn-off', 'controls', *CLI)
FORBIDDEN = {'.exe', '.obj', '.pdb', '.dll', '.lib', '.exp', '.bin', '.gguf', '.safetensors', '.pt', '.spv', '.db', '.sqlite', '.pyc', '.zip'}


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(data): return hashlib.sha256(data).hexdigest()


def pin(path):
    path = Path(path).resolve(); data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def compact(path, value):
    lines = ['{']
    for at, (key, item) in enumerate(value.items()):
        prefix = '  '+json.dumps(key)+': '; end = ',' if at+1 < len(value) else ''
        if isinstance(item, list):
            lines.append(prefix+'[')
            for j, row in enumerate(item):
                lines.append('    '+json.dumps(row, ensure_ascii=False, allow_nan=False, separators=(',', ': '))+(',' if j+1 < len(item) else ''))
            lines.append('  ]'+end)
        else: lines.append(prefix+json.dumps(item, ensure_ascii=False, allow_nan=False, separators=(',', ': '))+end)
    lines.append('}'); Path(path).write_text('\n'.join(lines)+'\n', encoding='utf-8')


def non_time(value):
    if isinstance(value, list): return [non_time(x) for x in value]
    if isinstance(value, dict):
        return {k: non_time(v) for k, v in value.items() if not any(s in k for s in ('seconds', 'per_second', 'clock_unix', 'unix_ns', 'unix_ms'))}
    return value


def diff(a, b, path=''):
    if type(a) is not type(b): return [dict(path=path, old=a, new=b)]
    if isinstance(a, dict):
        assert a.keys() == b.keys(), ('changed report schema', path)
        return [row for k in sorted(a) for row in diff(a[k], b[k], path+'/'+k)]
    if isinstance(a, list):
        assert len(a) == len(b), ('changed report cardinality', path)
        return [row for at, (x, y) in enumerate(zip(a, b)) for row in diff(x, y, path+'/'+str(at))]
    return [] if a == b else [dict(path=path, old=a, new=b)]


def build(path, label):
    ready = read(path)
    assert ready['compiled']['process']['exit'] == ready['link']['exit'] == 0
    for field in ('snapshot', 'command', 'compiler_dependencies', 'actual_dependencies'):
        exact(ready['compiled'][field])
    for field in ('inputs', 'recipe', 'runtime', 'plan'):
        if field in ready: exact(ready[field])
    return dict(label=label, ready=pin(path), image=ready['image'], source=ready['compiled']['source'],
        frozen_source=ready['compiled']['snapshot'], compile=ready['compiled']['process'], link=ready['link'],
        link_inputs=len(read(ready['inputs']['path'])), actual_dependencies=ready['compiled']['actual_dependencies'])


def collect(host_ready=None, host_run=None):
    builds = [build(V/'ready-model.json', 'W16 diagnostic Model'), build(W/'ready-model.json', 'W17 final Model'),
              build(W/'ready-probe.json', 'W17 16-arm combined probe'), build(W/'ready-host.json', 'W17 initial host oracle')]
    assert builds[1]['source']['sha256'] == FINAL_MAIN
    assert builds[1]['link_inputs'] == 224 and builds[2]['link_inputs'] == 223 and builds[3]['link_inputs'] == 2
    diagnostic = read(V/'runs/diagnostic-two-turn/summary.json')
    diagnostic_process = read(V/'runs/diagnostic-two-turn/process.json')
    assert diagnostic['status'] == 'PASS' and diagnostic_process['exit'] == 0
    assert diagnostic['original_non_time_producer_reports_equal'] is True
    old = R/'.scratch/inference-continuous-wave-window-20261027/attempt2/two-turn-timing/02-hyle_auto/stdout.log'
    assert non_time(read(old)) == non_time(read(V/'runs/diagnostic-two-turn/stdout.log'))
    assert len(diagnostic['refusals']) == 1
    expected_reason = 'pending outputs have no complete existing capture for their final physical tuple'
    assert expected_reason in diagnostic['refusals'][0]
    cases = []
    for name in RUNS:
        out = W/'runs'/name; result = read(out/'summary.json'); process = read(out/'process.json')
        assert result['status'] == 'PASS' and result['process'] == process and process['exit'] == 0
        exact(result['report'])
        report = read(result['report']['path'])
        if name == 'controls':
            assert report['status'] == 'PASS' and report['control_and_candidate_arms'] == 16
            assert report['synthetic_role_payload_bytes'] == 65536 and not report['model_eos_run']
            assert report['all_source_session_page_owners_retired'] and report['complete_prefix_state_epoch_rng_equal']
        else:
            exact(result['original'])
            actual = diff(non_time(read(result['original']['path'])), non_time(report))
            assert actual == result['complete_non_time_differences']
            assert report['live_committed_versions'] == 0
            if name == 'two-turn-default':
                assert {x['path'] for x in actual} == {'/decode_overlap_available', '/overlap_successor_publications', '/overlap_successor_submissions'}
                assert report['overlap_successor_publications'] == report['overlap_successor_submissions'] == 102
                assert report['overlap_successor_refusals'] == 1 and not report['overlap_successor_discards']
                assert report['decode_overlap_available'] is True
            else: assert not actual
            if name == 'two-turn-budget': assert not report['decode_overlap'] and not report['overlap_successor_submissions']
        cases.append(dict(name=name, process=process, report=result['report'],
                          comparison=result.get('complete_non_time_differences', '16 real CUDA control/candidate arms')))
    initial_host_process = read(W/'runs/host/process.json')
    assert initial_host_process['exit'] == 1
    assert 'common wave replaced the original exception/status or cleared unretired metadata' in (W/'runs/host/stderr.log').read_text()
    host = dict(status='PENDING_CORRECTED_HOST_RESULT', initial_process=initial_host_process,
                original_oracle='std::make_exception_ptr/rethrow/current_exception pointer identity is not portable on MSVC; preserve the failure, correct only the test oracle.')
    if host_ready is not None:
        assert host_run is not None
        final = build(host_ready, 'W17 corrected portable host oracle')
        assert final['source']['sha256'] == FIXED_HOST and final['link_inputs'] == 2
        process = read(host_run/'process.json')
        assert process['exit'] == 0 and '16 host contract groups passed' in (host_run/'stdout.log').read_text()
        builds.append(final)
        host.update(status='PASS_CORRECTED_ORACLE_ORIGINAL_FAILURE_RETAINED', final_process=process,
                    ready=pin(host_ready), run_directory=str(host_run),
                    corrected_oracle='Dynamic WaveFailure type, original payload0x41b2 and what(), original native status/retirement and surviving metadata assertions retained; common product header unchanged.')
    return builds, diagnostic, diagnostic_process, cases, host


def main(args):
    host_ready = Path(args.host_ready).resolve() if args.host_ready else None
    host_run = Path(args.host_run).resolve() if args.host_run else None
    if not args.draft: assert host_ready and host_run, 'Final package waits for root-confirmed corrected host result'
    builds, diagnostic, diagnostic_process, cases, host = collect(host_ready, host_run)
    controls = read(W/'runs/controls/report.json')
    baseline = R/'docs/evidence/performance/inference-continuous-wave-current-window-2026-10-27.json'
    previous = R/'docs/evidence/correctness/inference-continuous-wave-2026-10-27.json'
    result = dict(schema='hyle.correctness.wave-recovery.v1', date='2026-10-27',
        status='PENDING_CORRECTED_HOST_RESULT' if args.draft else 'PASS_FINAL_WITH_PRESERVED_INITIAL_HOST_ORACLE_FAILURE',
        scope='Original request-wave owner and Completion retirement; natural optional capture refusal diagnosis/recovery, auto budget selection and finite continuous controls. No new executor or performance measurement.',
        counts=dict(CXX=len(builds), links=len(builds), actual_model_processes=len(cases)+1, actual_host_processes=1 if args.draft else 2,
                    actual_processes=len(cases)+2 if args.draft else len(cases)+3, CUDA_control_candidate_arms=16, downloads=0, SDK_builds=0, NVCC=0),
        builds=builds,
        diagnosed_refusal=dict(process=diagnostic_process, actual_message=diagnostic['refusals'][0],
            code='Unavailable', native_error=False, predecessor_slot=1, successor_slot=2, members=1,
            committed_length=383, candidate_length=384,
            original_producer_non_time_report_equal=True,
            meaning='Existing final physical capture tuple was incomplete. Current evidence identifies the exact original rejection; it does not isolate which internal tuple component differed.'),
        recovery=dict(original_publications=59, final_publications=102, original_final_available=False, final_available=True,
            refusals_before_and_after=1, discards=0,
            policy='After refused B and genuine retirement, clear the failed warm continuation and allow later ready warming again; no pending re-record, permission or private tuple gate is weakened.',
            comparison='Complete original non-time producer report changes only final available flag and actual successor submissions/publications; IDs, ledger and other report facts remain identical.'),
        budget=dict(default='auto', explicit_D2_budget_unavailable='Use original D1 ordinary path when the provided cache budget cannot cover D2.',
            actual='Finite natural two-turn default under old off budget exactly matches the old off complete non-time stdout; no successor was submitted.'),
        common_wave=dict(header='engine/inference/request_wave_execution.h', sha256=COMMON,
            responsibility='Shared host cohort/credit/retirement transitions through static adapter methods; original Model retains Source, native work and deferred calls.',
            validation='Model, combined probe and standalone host unit compile the same frozen common header. No device Completion, permission or Source executor is copied into the common helper.'),
        checks=cases,
        continuous_controls=[dict(requests=x['requests'], mode=x['mode'], batches=x['actual_batches'],
            max_consecutive_pending=x['max_consecutive_pending'], accepted_before_observe=x['submit_before_observe'],
            stop_outputs=x['extra_stop_outputs'], stop_B_accepted=x['extra_stop_accepted_successor'],
            discarded_B=x['discarded_batches'], survivor_R1=x['survivor_r1_steps'],
            control_exceptions=x['control_exceptions'], aborted_submissions=x['aborted_actual_submissions']) for x in controls['candidates']],
        synthetic_fixture=dict(vocabulary=64, hidden=64, layers='GA', copied_role_payload_bytes=65536,
            real_state_roles_retained=True, original_extra_stop=True, actual_model_EOS=False,
            description='Only finite embedding/head/zero-residual roles are derived; original conv/GDN/KV roles, Graph permissions and CUDA kernels execute. Both R1/R2 actually accept B before A output12 extra-stop, then retire/discard B; the peer resumes under its original key.'),
        host_oracle=host,
        preserved_analysis_failure='W16 first comparison incorrectly used old normalized consumer-result against new raw producer stdout. Offline analyze_refusal.py compares both original stdout reports; successful PID51560 was not rerun.',
        reuse=[dict(role='W15 frozen unchanged project header/224+223 closure identities', receipt=pin(previous)),
               dict(role='Model3 40-process historical performance/window reference; no new speed claim', receipt=pin(baseline))],
        limits=[
            'No new TPS, memory-peak or throughput claim. Per-process elapsed values are functional run records only; historical Model3 speed window belongs to its own unchanged image.',
            'Synthetic extra-stop exercises the shared EOS-style retirement contract; this batch does not claim a real model EOS output, model quality or native hardware fault injection.',
            'Finite CUDA ordinary R1/R2 and tiny CPU/CUDA ordinary/MTP consumers only; no new multi-platform, arbitrary cohort width, random sampling or MTP cross-round device pipeline proof.',
            'Initial host failure is retained as a nonportable test-oracle defect; the corrected host test must pass separately before this receipt becomes final.'
        ], archive=dict(status='PENDING_OFFLINE_ZIP', filename=STEM+'.zip'))
    D.mkdir(parents=True, exist_ok=True)
    output = D/(STEM+'.json'); compact(output, result)
    if args.draft:
        print(json.dumps(dict(status='DRAFT_PENDING_HOST_RETRY', json=pin(output)))); return
    files = set()
    def add(path):
        p = Path(path).resolve()
        assert p.is_relative_to(R) and p.is_file() and p.suffix.lower() not in FORBIDDEN, str(p)
        files.add(p)
    # Receipts and original logs are small. Reuse old SDK/header payloads rather
    # than packaging any complete source, dependency, binary or model tree.
    for root in (V, W):
        for p in root.rglob('*'):
            if not p.is_file() or p.suffix.lower() in FORBIDDEN or p.name == 'package-result.json': continue
            if 'source' in p.relative_to(root).parts: continue
            if p.suffix.lower() in ('.json', '.py', '.log', '.xml', '.txt', '.tsv', '.ids'): add(p)
    # Every actually compiled TU, plus new/changed headers. Reused headers stay
    # represented by full source-freeze/actual-dependency receipts and prior ZIP.
    source_aliases = []; content = {}
    for item in builds:
        row = item['frozen_source']; exact(row)
        member = content.get(row['sha256'])
        if member is None:
            add(row['path']); member = Path(row['path']).relative_to(R).as_posix(); content[row['sha256']] = member
        source_aliases.append(dict(unit=item['label'], original_snapshot=row['path'], archived=member, sha256=row['sha256']))
    for source_freeze in (W/'source-freeze-model.json', W/'source-freeze-probe.json'):
        rows = read(source_freeze)['fresh']
        for row in rows:
            original = Path(row['original']['path'])
            if original.name not in ('request_wave_execution.h', 'qwen_continuous_generation_case.h',
                                      'qwen_generation_state_case.h', 'qwen_geometry_fixture.h'): continue
            record = row['snapshot']; exact(record)
            if record['sha256'] not in content:
                add(record['path']); content[record['sha256']] = Path(record['path']).relative_to(R).as_posix()
    for p in (previous, baseline, R/'.scratch/inference-current-review-profile-20261027/analyze.py'):
        add(p)
    # Original reference stdout is retained by the linked previous evidence;
    # pin those identities here without copying its entire 40-process window.
    reference_pins = [read(W/'runs'/name/'summary.json')['original'] for name in RUNS if name != 'controls']
    fixture = W/'inputs/controls/continuous-extra-stop-v64'
    save(W/'package-reuse-receipts.json', dict(reference_reports=reference_pins,
        previous_archives=[pin(previous.with_suffix('.zip')), pin(baseline.with_suffix('.zip'))],
        source_snapshot_aliases=source_aliases,
        synthetic_fixture=dict(manifest=pin(fixture/'weights.tsv'), payload_pin_only=pin(fixture/'chain-weights.bin')),
        no_binary_or_model_payload=True))
    add(W/'package-reuse-receipts.json')
    members = []
    for p in sorted(files):
        item = pin(p); members.append(dict(member=p.relative_to(R).as_posix(), bytes=item['bytes'], sha256=item['sha256']))
    manifest = (json.dumps(dict(schema='hyle.archive.manifest.v1', members=members, source_aliases=source_aliases,
        reused_payloads='Unchanged SDK/project headers and old report bytes remain pinned by existing archives and actual-dependency receipts; no binaries/models copied.'), indent=2) + '\n').encode()
    destination = D/(STEM+'.zip')
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for row in members:
            data = (R/row['member']).read_bytes()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            z.writestr(row['member'], data)
        z.writestr('manifest.json', manifest)
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None and len(z.namelist()) == len(members)+1
        for row in members:
            data = z.read(row['member']); assert len(data) == row['bytes'] and sha(data) == row['sha256']
        assert z.read('manifest.json') == manifest
    result['archive'] = dict(**pin(destination), members=len(members)+1, all_member_bytes_and_sha256_read_back=True)
    compact(output, result)
    final = dict(status='PACKAGED_VERIFIED', json=pin(output), zip=pin(destination), members=len(members)+1,
                 actual_processes=len(cases)+3, actual_model_processes=len(cases)+1, host_processes=2)
    save(W/'package-result.json', final); print(json.dumps(final))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--draft', action='store_true')
    parser.add_argument('--host-ready')
    parser.add_argument('--host-run')
    main(parser.parse_args())
