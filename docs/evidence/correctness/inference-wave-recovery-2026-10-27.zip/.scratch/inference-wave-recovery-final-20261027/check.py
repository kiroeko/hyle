"""Finite W17 preparation/freeze/CXX/link; no action runs a consumer.

Model: exact W15 Model3 CXX recipe, 224-input link. Probe: old combined TU,
223-input link, with its own current main and test-header snapshots. No SDK copy.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import sys
import time
import traceback

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
V = R / '.scratch/inference-continuous-wave-20261027'
H = R / '.scratch/inference-wave-ownership-20261027'
spec = importlib.util.spec_from_file_location('wave_recovery_retained_tools', V / 'check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
SOURCES = dict(model='engine/models/qwen35/main.cc', probe='tests/tools/qwen_generation_batch_relay_probe.cc',
               host='tests/tools/inference_request_loop_test.cc')
BASE = dict(model=V/'ready-model3.json', probe=V/'ready-probe.json', host=H/'ready-host2.json')
IMAGES = dict(model='hyle-wave-recovery-final.exe', probe='qwen-wave-recovery-final-probe.exe', host='request-wave-recovery-host.exe')
COMMON = R/'engine/inference/request_wave_execution.h'
COMMON_SHA = '6c4e5e13232b10aff556a1396f943662715220170213011995e23643e589cc09'
COUNTS = dict(model=224, probe=223, host=2)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def pin(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while data := stream.read(1 << 20): digest.update(data)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def exact(row):
    actual = pin(row['path'])
    assert (actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']), row['path']


def key(path):
    return str(path).replace('/', '\\').casefold()


def environment():
    value = b.environment()
    value['PATH'] = str(W/'bin') + ';' + read(V/'runtime-plan.json')['PATH']
    for name in ('HF_HUB_OFFLINE', 'HF_DATASETS_OFFLINE', 'TRANSFORMERS_OFFLINE'):
        value[name] = '1'
    return value


def prepare():
    units = {}
    for name in SOURCES:
        ready = read(BASE[name])
        assert ready['compiled']['process']['exit'] == ready['link']['exit'] == 0
        count = len(read(ready['inputs']['path']))
        assert count == COUNTS[name]
        units[name] = dict(source=str(R/SOURCES[name]), baseline=pin(BASE[name]),
            cxx_recipe=ready['compiled']['command'], compiler_dependencies=ready['compiled']['compiler_dependencies'],
            link_inputs=ready['inputs'], link_recipe=ready['recipe'], input_count=count,
            policy='One exact replacement OBJ only. Probe has no separate Model/CLI entry OBJ.')
    save(W/'preparation-plan.json', dict(status='PREPARED_NO_SOURCE_FREEZE_OR_BUILD', units=units,
        counts=dict(CXX=3, links=3, inference=0, SDK=0, NVCC=0, downloads=0),
        actions=['freeze UNIT EXPECTED_MAIN_SHA [EXPECTED_PROBE_SHA]', 'compile UNIT', 'link UNIT'],
        policy='Each action is explicit; outputs and failures are immutable. No automatic retry or consumer run.'))
    runtime = read(V/'runtime-plan.json')
    save(W/'runtime-plan.json', dict(original_native_cpu=runtime['original_native_cpu'],
        alias=str(W/'bin'/Path(runtime['original_native_cpu']['path']).name), PATH=environment()['PATH']))
    save(W/'environment.json', {k: environment().get(k, '') for k in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH')})
    print('PREPARED model224/probe223/host2; no freeze/CXX/link/GPU', flush=True)


def old_rows(name):
    if name == 'host': return read(H/'source-freeze-host2.json')
    if name == 'model':
        data = read(V/'source-freeze-model3.json')
        return [dict(original=data['original'], snapshot=data['snapshot']), *data['reused_project_headers']]
    return read(V/'source-freeze-probe.json')


def freeze(name, expected_main, expected_probe=None):
    assert name in SOURCES
    plan_path = W/('plan-'+name+'.json')
    assert not plan_path.exists() and not (W/'source'/name).exists(), 'Preserve prior frozen attempt'
    main = pin(R/('engine/models/qwen35/main.cc' if name != 'host' else SOURCES[name]))
    assert main['sha256'] == expected_main, ('source differs from authorized SHA', main)
    assert pin(COMMON)['sha256'] == COMMON_SHA, 'common helper differs from authorized freeze'
    if name == 'probe':
        assert expected_probe and pin(R/SOURCES[name])['sha256'] == expected_probe
        if (W/'plan-model.json').exists():
            assert read(W/'plan-model.json')['main_sha256'] == expected_main, 'Model/probe main mismatch'
    prepared = read(W/'preparation-plan.json')['units'][name]
    exact(prepared['baseline'])
    ready = read(prepared['baseline']['path'])
    for item in ('cxx_recipe', 'compiler_dependencies', 'link_inputs', 'link_recipe'):
        exact(prepared[item])
    rows = old_rows(name)
    fresh = {key(main['path']): Path(main['path']), key(COMMON): COMMON}
    fresh[key(R/SOURCES[name])] = R/SOURCES[name]
    # Only the finite combined-probe test headers are newly snapshotted. All
    # non-test headers must still exactly equal the existing immutable snapshot.
    if name == 'probe':
        for row in rows:
            original = Path(row['original']['path'])
            if original.is_relative_to(R/'tests/tools') and original.suffix == '.h':
                fresh[key(original)] = original
        # A newly introduced local test header may not be in the old compiler
        # closure yet; follow only real quoted includes below tests/tools.
        pending = list(fresh.values())
        visited = set()
        while pending:
            path = pending.pop()
            if key(path) in visited: continue
            visited.add(key(path))
            for include in re.findall(r'^\s*#\s*include\s*"([^"]+)"', path.read_text(encoding='utf-8-sig'), re.M):
                candidate = (path.parent/include).resolve()
                if candidate.is_file() and candidate.is_relative_to(R/'tests/tools'):
                    if key(candidate) not in fresh:
                        fresh[key(candidate)] = candidate
                        pending.append(candidate)
    reused = []
    for row in rows:
        exact(row['snapshot'])
        if key(row['original']['path']) not in fresh:
            exact(row['original'])
            reused.append(row)
    overlay = W/'source'/name
    frozen = []
    for path in fresh.values():
        original = pin(path)
        destination = overlay/path.relative_to(R)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream: stream.write(path.read_bytes())
        snapshot = pin(destination)
        assert (snapshot['bytes'], snapshot['sha256']) == (original['bytes'], original['sha256'])
        frozen.append(dict(original=original, snapshot=snapshot))
    source = overlay/SOURCES[name]
    out = W/'compile'/name
    template = read(prepared['cxx_recipe']['path'])['command']
    command = [template[0], *('/I'+str(overlay/p) for p in
        ('include', '', 'engine/models/qwen35', 'engine/inference', 'tests/tools', 'src/graph', 'src/compute'))]
    # The new helper quotes request_loop.h. Its unchanged sibling is reused
    # from the exact baseline directory, rather than copied with a header tree.
    sibling = next(Path(row['snapshot']['path']).parent for row in reused
                   if Path(row['original']['path']).name == 'request_loop.h')
    command.append('/I'+str(sibling))
    for i, arg in enumerate(template[1:], 1):
        if template[i-1].lower() == '/sourcedependencies': arg = str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'): arg = '/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd'+str(out/'unit.pdb')
        elif arg.lower().endswith(('.cc', '.cpp', '.cxx')): arg = str(source)
        command.append(arg)
    source_freeze = W/('source-freeze-'+name+'.json')
    save(source_freeze, dict(fresh=frozen, reused=reused,
        policy='Reuse exact immutable previous project-header snapshots. Only current main/combined-probe/host, new common wave helper and finite local test headers are new; no SDK copy.'))
    save(W/'recipes'/('compile-'+name+'.json'), dict(command=command, template=prepared['cxx_recipe']))
    save(plan_path, dict(status='FROZEN_NOT_BUILT', unit=name, main_sha256=expected_main,
        original=pin(R/SOURCES[name]), snapshot=pin(source), source_freeze=pin(source_freeze),
        overlay=str(overlay), baseline=ready, baseline_receipt=prepared['baseline'], command=command,
        original_object=ready['compiled']['object'], input_count=prepared['input_count']))
    print('FROZEN '+name+' main='+expected_main, flush=True)


def validate_frozen(plan):
    exact(plan['source_freeze'])
    frozen = read(plan['source_freeze']['path'])
    for row in frozen['fresh'] + frozen['reused']:
        exact(row['original']); exact(row['snapshot'])
    exact(plan['original']); exact(plan['snapshot'])
    return frozen


def compile_unit(name):
    plan = read(W/('plan-'+name+'.json'))
    frozen = validate_frozen(plan)
    out = W/'compile'/name
    out.mkdir(parents=True, exist_ok=False)
    process = b.h.execute(plan['command'], environment(), W/'logs'/name, timeout=240)
    data = read(out/'dependencies.json')['Data']
    assert key(data['Source']) == key(plan['snapshot']['path'])
    allowed = {key(x['snapshot']['path']): x['snapshot'] for x in frozen['fresh']+frozen['reused']}
    # Any former project overlay must have a pinned canonical/source record.
    actual = []
    for path in dict.fromkeys([data['Source'], *data['Includes']]):
        record = pin(path)
        assert not b.project(path), ('live project header escaped snapshot', path)
        if any(Path(path).is_relative_to(root) for root in
               (V/'source', H/'source', H/'source2', H/'source3', W/'source')):
            assert record == allowed[key(path)], ('unapproved/mismatched snapshot dependency', path)
        actual.append(record)
    if name == 'probe':
        assert key(Path(plan['overlay'])/'engine/models/qwen35/main.cc') in {key(p['path']) for p in actual}
    validate_frozen(plan)
    save(out/'actual-dependencies.json', actual)
    save(out/'compiled.json', dict(source=plan['original'], snapshot=plan['snapshot'], object=pin(out/'unit.obj'),
        process=process, command=pin(W/'logs'/name/'command.json'),
        compiler_dependencies=pin(out/'dependencies.json'), actual_dependencies=pin(out/'actual-dependencies.json')))
    print('CXX_PASS '+name, flush=True)


def link(name):
    plan = read(W/('plan-'+name+'.json'))
    validate_frozen(plan)
    compiled = read(W/'compile'/name/'compiled.json')
    assert compiled['process']['exit'] == 0
    exact(compiled['object'])
    base = plan['baseline']
    exact(base['inputs']); exact(base['recipe'])
    inputs = read(base['inputs']['path'])
    old = plan['original_object']
    assert len(inputs) == plan['input_count']
    assert sum(key(p['path']) == key(old['path']) for p in inputs) == 1
    inputs = [compiled['object'] if key(p['path']) == key(old['path']) else p for p in inputs]
    for row in inputs: exact(row)
    image = W/'bin'/IMAGES[name]
    image.parent.mkdir(parents=True, exist_ok=True)
    assert not image.exists() and not (W/('link-'+name)).exists(), 'preserve prior link attempt'
    command = []
    replaced = 0
    for arg in read(base['recipe']['path'])['command']:
        if key(arg) == key(old['path']): arg = compiled['object']['path']; replaced += 1
        elif arg.upper().startswith('/OUT:'): arg = '/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'): arg = '/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'): arg = '/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'): arg = '/MAP:'+str(image.with_suffix('.map'))
        command.append(arg)
    assert replaced == 1
    for option, suffix in (('/PDB:', '.pdb'), ('/IMPLIB:', '.lib')):
        if not any(arg.upper().startswith(option) for arg in command): command.append(option+str(image.with_suffix(suffix)))
    runtime = read(W/'runtime-plan.json')
    cpu = runtime['original_native_cpu']; exact(cpu)
    alias = Path(runtime['alias'])
    if not alias.exists(): os.link(cpu['path'], alias)
    assert pin(alias)['sha256'] == cpu['sha256']
    save(W/(name+'-link-inputs.json'), inputs)
    save(W/'recipes'/('link-'+name+'.json'), dict(command=command, template=base['recipe']))
    process = b.h.execute(command, environment(), W/('link-'+name), timeout=180)
    save(W/('ready-'+name+'.json'), dict(status='LINKED_NOT_RUN', image=pin(image), compiled=compiled,
        main_sha256=plan['main_sha256'], link=process, inputs=pin(W/(name+'-link-inputs.json')),
        recipe=pin(W/('link-'+name)/'command.json'), runtime=pin(W/'runtime-plan.json'), plan=pin(W/('plan-'+name+'.json'))))
    print('LINK_PASS '+name+' '+pin(image)['sha256'], flush=True)


if __name__ == '__main__':
    try:
        action = sys.argv[1]
        if action == 'prepare': prepare()
        elif action == 'freeze': freeze(*sys.argv[2:])
        elif action == 'compile': compile_unit(sys.argv[2])
        elif action == 'link': link(sys.argv[2])
        else: raise ValueError(action)
    except BaseException:
        W.mkdir(parents=True, exist_ok=True)
        (W/('failure-'+ '-'.join(sys.argv[1:3])+'-'+str(time.time_ns())+'.log')).write_text(traceback.format_exc(), encoding='utf-8')
        raise
