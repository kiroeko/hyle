"""One explicit host-only assertion repair; preserve the first image/run."""
from pathlib import Path
import importlib.util, json, sys, traceback
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent; R=W.parents[1]
spec=importlib.util.spec_from_file_location('host_retry_retained',W/'check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
EXPECTED='80251057f96f49a16c1f9e9facff3a2fb57236dcbec59724a4204f1100445d8b'

def main():
    source=R/'tests/tools/inference_request_loop_test.cc';original=b.pin(source)
    assert original['sha256']==EXPECTED
    old=b.read(W/'ready-host.json'); b.exact(old['image']);b.exact(old['compiled']['object'])
    assert b.read(W/'runs/host/process.json')['exit']==1
    headers=[x for x in b.read(old['compiled']['actual_dependencies']['path']) if b.key(x['path'])!=b.key(old['compiled']['snapshot']['path'])]
    for row in headers:b.exact(row)
    snapshot=W/'source/host-retry/tests/tools/inference_request_loop_test.cc'
    snapshot.parent.mkdir(parents=True,exist_ok=False)
    with snapshot.open('xb') as f:f.write(source.read_bytes())
    out=W/'compile/host-retry';out.mkdir(parents=True,exist_ok=False)
    command=[]
    for arg in b.read(old['compiled']['command']['path'])['command']:
        if b.key(arg)==b.key(old['compiled']['snapshot']['path']):arg=str(snapshot)
        elif b.key(arg)==b.key(old['compiled']['compiler_dependencies']['path']):arg=str(out/'dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
        command.append(arg)
    frozen=dict(source=original,snapshot=b.pin(snapshot),reused_actual_headers=headers,
        original_ready=b.pin(W/'ready-host.json'),original_failure=b.pin(W/'runs/host/process.json'),
        reason='MSVC CRT excptptr.cpp copies the exception on rethrow and current_exception; validate final WaveFailure type, payload and what, rather than exception_ptr owner equality. All native/status/retired/count/aborts/remaining assertions retained.')
    b.save(W/'source-freeze-host-retry.json',frozen)
    b.save(W/'host-retry-plan.json',dict(status='FROZEN_HOST_ONLY',source_freeze=b.pin(W/'source-freeze-host-retry.json'),command=command,original=old,counts=dict(CXX=1,links=1,host_processes=1,SDK=0,GPU=0)))
    process=b.b.h.execute(command,b.environment(),W/'logs/host-retry',timeout=180)
    data=b.read(out/'dependencies.json')['Data'];assert b.key(data['Source'])==b.key(snapshot)
    allowed={b.key(x['path']):x for x in headers}
    actual=[]
    for path in dict.fromkeys([data['Source'],*data['Includes']]):
        row=b.pin(path)
        if b.key(path)!=b.key(snapshot):assert row==allowed[b.key(path)],('dependency drift',path)
        actual.append(row)
    b.exact(original);b.exact(frozen['snapshot'])
    for row in headers:b.exact(row)
    b.save(out/'actual-dependencies.json',actual)
    compiled=dict(source=original,snapshot=b.pin(snapshot),object=b.pin(out/'unit.obj'),process=process,
        command=b.pin(W/'logs/host-retry/command.json'),compiler_dependencies=b.pin(out/'dependencies.json'),actual_dependencies=b.pin(out/'actual-dependencies.json'))
    b.save(out/'compiled.json',compiled)
    inputs=b.read(old['inputs']['path']);assert len(inputs)==2 and inputs[0]==old['compiled']['object']
    inputs[0]=compiled['object']
    for row in inputs:b.exact(row)
    b.save(W/'host-retry-link-inputs.json',inputs)
    image=W/'bin/request-wave-recovery-host-retry.exe';assert not image.exists()
    link=[]
    for arg in b.read(old['recipe']['path'])['command']:
        if b.key(arg)==b.key(old['compiled']['object']['path']):arg=compiled['object']['path']
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        link.append(arg)
    linked=b.b.h.execute(link,b.environment(),W/'link-host-retry',timeout=180)
    b.save(W/'ready-host-retry.json',dict(status='LINKED_NOT_RUN',image=b.pin(image),compiled=compiled,link=linked,
        inputs=b.pin(W/'host-retry-link-inputs.json'),recipe=b.pin(W/'link-host-retry/command.json'),runtime=old['runtime'],source_freeze=b.pin(W/'source-freeze-host-retry.json')))
    run=b.b.h.execute([str(image)],b.environment(),W/'runs/host-retry',timeout=180)
    assert '16 host contract groups passed' in (W/'runs/host-retry/stdout.log').read_text()
    b.save(W/'runs/host-retry/summary.json',dict(status='PASS',host_groups=16,process=run,ready=b.pin(W/'ready-host-retry.json'),
        first_failed_process=b.pin(W/'runs/host/process.json'),scope='Host contract checks only; no device/model work or product changes.'))
    print('PASS host-retry 16 groups',flush=True)

if __name__=='__main__':
    try:main()
    except BaseException:
        b.save(W/'failure-host-retry.json',dict(traceback=traceback.format_exc()));raise
