"""One explicit diagnostic journey; no timing or automatic retry."""
from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('recovery_build', W/'check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
spec = importlib.util.spec_from_file_location('prior_fact_parser', R/'.scratch/inference-current-review-profile-20261027/analyze.py')
facts = importlib.util.module_from_spec(spec); spec.loader.exec_module(facts)
old = R/'.scratch/inference-continuous-wave-window-20261027/attempt2/two-turn-timing/02-hyle_auto'
ready = b.read(W/'ready-model.json'); b.exact(ready['image'])
command = [ready['image']['path'], *b.read(old/'command.json')['command'][1:]]
out = W/'runs/diagnostic-two-turn'
assert not out.exists(), 'Preserve actual attempts; no rerun'
result = b.b.h.execute(command, b.environment(), out, timeout=180)
report = json.loads((out/'stdout.log').read_text(encoding='utf-8-sig'))
b.save(out/'report.json', report)
assert facts.non_time(report) == facts.non_time(b.read(old/'consumer-result.json')), 'Actual non-time report changed'
refusals = [line for line in (out/'stderr.log').read_text(encoding='utf-8-sig').splitlines()
            if line.startswith('decode_overlap_refused ')]
assert len(refusals) == report['overlap_successor_refusals'] == 1
b.save(out/'summary.json', dict(status='PASS',process=result,ready=b.pin(W/'ready-model.json'),
    exact_complete_non_time_report_equal=True,refusals=refusals,
    scope='One existing natural two-turn workload; diagnostic only, no performance claim'))
print(json.dumps(dict(status='PASS',refusals=refusals),ensure_ascii=False),flush=True)
