"""Offline correction: compare two original producer reports, not normalized wrapper vs raw."""
from pathlib import Path
import importlib.util, json, sys
sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('recovery_build_offline', W/'check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
spec = importlib.util.spec_from_file_location('prior_fact_parser_offline', R/'.scratch/inference-current-review-profile-20261027/analyze.py')
facts = importlib.util.module_from_spec(spec); spec.loader.exec_module(facts)
old = R/'.scratch/inference-continuous-wave-window-20261027/attempt2/two-turn-timing/02-hyle_auto'
out = W/'runs/diagnostic-two-turn'
actual = b.read(out/'stdout.log'); expected = b.read(old/'stdout.log')
assert facts.non_time(actual) == facts.non_time(expected), 'Original producer facts changed'
refusals = [line for line in (out/'stderr.log').read_text(encoding='utf-8-sig').splitlines()
            if line.startswith('decode_overlap_refused ')]
assert len(refusals) == actual['overlap_successor_refusals'] == 1
b.save(out/'summary.json', dict(status='PASS',ready=b.pin(W/'ready-model.json'),
    original_non_time_producer_reports_equal=True,refusals=refusals,
    parser_correction='Original first assertion compared normalized old consumer-result to raw producer. Offline correction compares both original stdout reports; successful process was not repeated.',
    scope='One existing natural two-turn workload; diagnostic only, no performance claim'))
print(json.dumps(dict(status='PASS',refusals=refusals),ensure_ascii=False),flush=True)
