"""Compare complete non-timing reports, excluding only the corrected actual facts."""
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin = b.read, b.save, b.pin
ACTUAL = {'actual_draft_rows', 'actual_draft_rows_scope', 'actual_restored_draft_rows'}
NATURAL = {'serial_actual_draft_rows', 'auto_actual_draft_rows', 'discarded_draft_rows'}


def stable(value, excluded=ACTUAL):
    if isinstance(value, dict):
        return {k: stable(v, excluded) for k, v in value.items()
                if k not in excluded and not k.endswith('_seconds') and not k.endswith('_per_second')}
    if isinstance(value, list):
        return [stable(v, excluded) for v in value]
    return value


def differences(a, c, path=''):
    if type(a) is not type(c):
        return [path + ': type mismatch']
    if isinstance(a, dict):
        return ([path + ': keys mismatch'] if set(a) != set(c) else []) + [x
            for k in a.keys() & c.keys() for x in differences(a[k], c[k], path + '/' + k)]
    if isinstance(a, list):
        return ([path + ': length mismatch'] if len(a) != len(c) else []) + [x
            for i, (av, cv) in enumerate(zip(a, c)) for x in differences(av, cv, path + '/' + str(i))]
    return [] if a == c else [path + ': value mismatch']


def main():
    reports = {name: read(W / 'runs' / name / 'attempt1/report.json')
               for name in read(W / 'plan.json')['cases']}
    anchors = {
        'single-auto': b.OLD / 'runs/cli/abba-2/report.json',
        'two-turn-auto': b.R / '.scratch/inference-plan-cold-facts-20261030/peer-window/two-turn-timing/02-hyle_mtp/stdout.log',
        'natural': b.OLD / 'runs/natural/attempt1/report.json',
        'ordinary': b.OLD / 'runs/ordinary/attempt2/report.json',
    }
    comparisons = []
    for name, path in anchors.items():
        exclusions = NATURAL if name == 'natural' else ACTUAL
        diff = differences(stable(read(path), exclusions), stable(reports[name], exclusions))
        comparisons.append(dict(case=name, anchor=pin(path), differences=diff))
        assert not diff, (name, diff)
    rows = {}
    for name, report in reports.items():
        if 'sessions' not in report:
            continue
        total = report['actual_draft_rows']
        assert total == sum(x['result']['actual_draft_rows'] for x in report['sessions']), name
        rows[name] = {k: report[k] for k in ('generated_tokens', 'draft_rounds', 'actual_draft_rows',
            'prefill_draft_rows', 'draft_rows', 'actual_target_rows', 'draft_program_graph_calls',
            'actual_restored_draft_rows', 'restore_count', 'overlap_successor_discards')}
        if name in ('single-auto', 'two-turn-auto'):
            assert total - report['prefill_draft_rows'] - report['draft_rows'] == 4
        elif name in ('single-off', 'two-turn-off', 'recursive', 'threshold'):
            assert total == report['prefill_draft_rows'] + report['draft_rows']
    assert rows['restore']['restore_count'] == 2 and rows['restore']['actual_restored_draft_rows'] == 322
    assert rows['restore']['actual_draft_rows'] == 968
    for name in ('natural', 'ordinary', 'batch', 'mixed'):
        assert reports[name]['status'] == 'PASS'
    natural = reports['natural']
    assert natural['auto_actual_draft_rows'] == natural['serial_actual_draft_rows'] + natural['discarded_draft_rows']
    value = dict(status='PASS_FINITE_ACCOUNTING_AND_ORIGINAL_CONSUMERS', comparisons=comparisons,
        excluded_timing='Only *_seconds and *_per_second recursive keys; all other old facts retained.',
        corrected_or_added_actual_keys=sorted(ACTUAL), new_natural_regression_keys=sorted(NATURAL),
        rows=rows, request_totals_equal_model=True,
        natural_accounting={k: natural[k] for k in sorted(NATURAL)},
        native_cases={name: pin(W / 'runs' / name / 'attempt1/report.json') for name in reports},
        scope='Original accepted Graph active input rows; excludes physical padding, provider preparation, partial submit without Completion and hardware kernel FLOPs.',
        performance_claim=False, limits=['No new peer, throughput ranking or memory window.',
            'MTP nonzero late observer retry is source-reviewed, not directly exercised by a new native injection.',
            'K2 and threshold complete consumers passed; this is not exhaustive all-model/platform coverage.'])
    save(W / 'analysis.json', value)
    print(value['status'], rows, flush=True)


if __name__ == '__main__':
    main()
