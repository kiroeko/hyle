"""Retain current objects/recipes and small evidence; discard only exact batch images."""
from pathlib import Path
import importlib.util
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
PROBE = R / '.scratch/inference-conditional-graph-20261030'
spec = importlib.util.spec_from_file_location('build', W / 'build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key
SOURCES = ['engine/models/qwen35/main.cc', 'tests/tools/qwen_mtp_natural_relay_case.h',
           'tests/tools/qwen_mtp_batch_state_case.h', 'tests/tools/qwen_mtp_mixed_lag_case.h']


def prepare():
    p = read(W / 'plan.json')
    base = read(p['base']['path'])
    for item in p['candidate_retained']:
        exact(item)
    consumers = {}
    for name in p['consumers']:
        path = W / 'compile' / name / 'receipt.json'
        receipt = read(path)
        exact(receipt['object'])
        for item in receipt['source_identities']:
            exact(item)
        consumers[name] = dict(receipt=pin(path), object=receipt['object'])
    base.update(schema='hyle.draft-accounting.current-link-base.v1', base=p['base'],
        current_consumers=consumers, previous_consumer=consumers['cli']['receipt'],
        consumer_source=pin(p['consumers']['cli']['source']), compile=p['consumers']['cli']['compile'])
    base['link'] = [consumers['cli']['object']['path'] if key(arg) == key(p['original_consumer'])
                    else arg for arg in p['original_link']]
    save(W / 'model-link-base.json', base)
    assert read(W / 'analysis.json')['status'] == 'PASS_FINITE_ACCOUNTING_AND_ORIGINAL_CONSUMERS'
    assert read(PROBE / 'result.json')['status'] == 'PASS'
    targets = []
    boundaries = [W / 'bin', PROBE / 'bin']
    for boundary in boundaries:
        for path in sorted(boundary.iterdir()):
            assert path.is_file() and path.suffix.lower() in ('.exe', '.dll', '.lib', '.exp')
            targets.append(pin(path))
    save(W / 'cleanup-targets.json', dict(boundaries=list(map(str, boundaries)), targets=targets))
    (W / 'product.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', *SOURCES], cwd=R))
    print('Retained current227 SDK inputs and3 consumer objects;exact flat image targets:', len(targets))


def archive(folder, output):
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(folder.rglob('*')):
            if not path.is_file() or any(x in ('bin', '__pycache__', 'ordinary-input') for x in path.relative_to(folder).parts):
                continue
            if path.suffix.lower() in ('.json', '.py', '.cc', '.cu', '.diff', '.log', '.turns', '.sessions'):
                z.write(path, path.relative_to(folder).as_posix())
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None


def finish():
    a, p = read(W / 'analysis.json'), read(W / 'plan.json')
    cleanup = read(W / 'cleanup-report.json')
    assert cleanup['status'] == 'REMOVED_EXACT_FLAT_BATCH_IMAGES'
    value = dict(schema='hyle.correctness.draft-work-accounting.v1', date='2026-10-30',
        status='ORIGINAL_SUBMIT_ACCOUNTING_IMPLEMENTED_AND_FINITE_CHECKED', base_commit=p['base_commit'],
        contract=dict(scope='admitted_active_input_rows',
            definition='Active draft inputs in original Graph submits that successfully return Completion, counted once at that submit, before wait/capture/observation/publication.',
            excluded=['Physical padding', 'Provider-internal preparation/JIT', 'Partial submit that does not return Completion', 'Hardware kernel FLOPs'],
            shared='Frozen per-member original Append query_rows, checked against the combined layout before submit.',
            private='Cold exact DraftProgram.rows for proposal/threshold/repair.',
            failure='Later failure, cancellation or successful discard does not erase accepted work; retirement/observation retries do not add it again.',
            ownership='Existing Model/Session monotonic scalars; original Session retirement and restore call scopes attribute request totals. No new owner, executor, allocation or RNG/snapshot payload.',
            ledger='Original draft_rows, acceptance ledger, pending, state and RNG semantics remain unchanged.'),
        implementation=dict(sources=[pin(R / x) for x in SOURCES], diff=pin(W / 'product.diff'),
            sdk_CXX_compiles=0, retained_SDK_engine_objects=227, current_consumer_TUs=3,
            consumer_CXX_invocations=4, note='Natural wrapper recompiled once after adding finite failure/padding assertions; no first native run used the earlier natural object.',
            product_NVCC_compiles=0, downloads=0, current_link_base=pin(W / 'model-link-base.json')),
        checks=dict(analysis=pin(W / 'analysis.json'), native_cases=a['native_cases'], rows=a['rows'],
            request_totals_equal_model=True, complete_non_timing_comparisons=a['comparisons'],
            natural_accounting=a['natural_accounting'],
            failure='Original checked negative-ID NextN submit counts1; valid retry totals2; standalone work does not increment unrelated Session counters.',
            padding='Original mixed-lag physical4 counts only3active draft rows, attributed1/2 to original Sessions.',
            restore='Two real evictions/rebuilds:968 total=484+484 request rows, including322 restore rows exactly once.'),
        limits=a['limits'], performance_claim=False,
        prior_report_correction='Old default-auto single/two-turn216/434 excluded4 discarded draft rows; current observed totals220/438. Old timing still includes that work; this does not change historical throughput.',
        analysis_attempt='First offline comparison selected normalized peer consumer-result with extra adapter keys; corrected to original producer stdout. Native consumers were not rerun and no non-time product checks were relaxed.',
        cleanup=dict(script=pin(R / 'test.ps1'), manifest=pin(W / 'cleanup-targets.json'), result=cleanup),
        evidence_archive='inference-draft-accounting-2026-10-30.zip')
    out = R / 'docs/evidence/correctness/inference-draft-accounting-2026-10-30.json'
    save(out, value)
    archive(W, out.with_suffix('.zip'))
    probe = read(PROBE / 'result.json')
    native = dict(schema='hyle.research.native-conditional-graph.v1', date='2026-10-30',
        status='NATIVE_CAPABILITY_PASS_PRODUCT_NOT_IMPLEMENTED',
        device=probe['device'], cases=probe['cases'], cuda_errors=probe['cuda_errors'],
        source=pin(PROBE / 'probe.cu'), compiler_and_image=read(PROBE / 'ready.json'),
        result=pin(PROBE / 'result.json'),
        scope='One tiny native graph, same executable false->true->no-set default false; no Hyle model, provider captured body, memory or performance claim.',
        source_review=dict(capture='src/compute_backend_cuda/cuda_backend.cc end_capture currently instantiates and destroys raw graph; CapturedCommandsState keeps Exec only.',
            topology='src/graph/submission.cc replays capture ranges and executes uncaptured gaps separately. A guarded range cannot suppress Hybrid gaps.',
            output='retire_invocation sets outputs_ready from terminal.ok(); successful native retirement cannot prove an If body wrote tensor/Store/Append outputs.',
            source='Pending Source currently promises actual producer data. An unresolved guarded B cannot be forwarded as a valid C input without propagating conditional validity.',
            minimum='Keep original Invocation/Completion/owners; distinguish executed versus skipped outcome and gate all outputs, Store and page publication; then add cold whole-graph predicate wrapping.',
            conservative_scope='Only a complete single-Queue captured body with supported node types; checked-status seeds/merges remain outside predicate; no swallowed native error or host recompute.',
            lifetime='Original artifact holds graph/conditional handle as necessary until actual retirement. Native probe does not establish arbitrary provider body compatibility.'),
        hyle_product_implemented=False, hyle_source_validity_claim=False, performance_claim=False,
        evidence_archive='inference-conditional-graph-2026-10-30.zip')
    out2 = R / 'docs/evidence/research/inference-conditional-graph-2026-10-30.json'
    save(out2, native)
    archive(PROBE, out2.with_suffix('.zip'))
    print('Evidence saved and archive integrity checked:', pin(out), pin(out.with_suffix('.zip')),
          pin(out2), pin(out2.with_suffix('.zip')))


if __name__ == '__main__':
    {'prepare': prepare, 'finish': finish}[sys.argv[1]]()
