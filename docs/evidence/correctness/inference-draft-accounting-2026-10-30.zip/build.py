"""Finite current-consumer accounting check, reusing the current 227 SDK inputs."""
from pathlib import Path
import importlib.util
import shutil
import sys

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
OLD = R / '.scratch/inference-source-binding-20261030'
spec = importlib.util.spec_from_file_location('source_build', OLD / 'build.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)
s.W = s.b.W = W
read, save, pin, exact, key = s.read, s.save, s.pin, s.exact, s.key


def replace(args, option, value):
    args = list(args)
    args[args.index(option) + 1] = str(value)
    return args


def prepare():
    assert not (W / 'plan.json').exists()
    base = read(OLD / 'model-link-base.json')
    prior = read(OLD / 'plan.json')
    assert len(base['retained']) == 227
    for item in base['retained']:
        exact(item)
    exact(base['runtime'])
    consumers = {}
    for name in ('cli', 'natural', 'ordinary'):
        previous = prior['consumers'][name]
        consumers[name] = dict(source=previous['source'],
            compile=s.relocated(previous['compile'], name), kind='consumer')
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    ordinary = W / 'ordinary-input'
    ordinary.mkdir(exist_ok=True)
    for name in ('weights.tsv', 'prompt.ids'):
        shutil.copyfile(OLD / 'ordinary-input' / name, ordinary / name)
    cases = dict(natural=['natural', *prior['cases']['natural']],
        ordinary=['ordinary', '--cuda-continuous', str(ordinary)])
    for scenario, args in [('single', prior['args']), ('two-turn', prior['two_turn_args'])]:
        for overlap in ('auto', 'off'):
            cases[scenario + '-' + overlap] = ['cli', *replace(args, '--decode-overlap', overlap)]
    cases['recursive'] = ['cli', *replace(prior['args'], '--mtp-max-drafts', 2)]
    cases['threshold'] = ['cli', *replace(prior['args'], '--mtp-max-drafts', 2),
        '--mtp-min-probability', '0.99']
    save(W / 'plan.json', dict(base=pin(OLD / 'model-link-base.json'), base_commit='290ec8c69',
        units={}, consumers=consumers, retained=base['retained'], candidate_retained=base['retained'],
        runtime=base['runtime'], original_link=base['link'],
        original_consumer=read(base['previous_consumer']['path'])['object']['path'],
        old_cli=base['current_consumers']['cli']['object'], cases=cases,
        sdk_engine_dependencies=base['sdk_engine_dependencies'], sdk_compiles=0, nvcc_compiles=0,
        downloads=0, scope='Original accepted Graph active input rows, not kernel FLOPs or provider preparation; no performance or peer-window claim.'))
    print('Prepared 3 current consumer TUs,227 retained SDK inputs; no SDK/NVCC or download.', flush=True)


def run(name, attempt):
    p = read(W / 'plan.json')
    unit, *args = p['cases'][name]
    image = read(W / ('ready-' + unit + '.json'))
    exact(image)
    folder = W / 'runs' / name / attempt
    s.b.execute([image['path'], *args], folder, 300)
    report = read(folder / 'stdout.log')
    if unit != 'cli':
        assert report['status'] == 'PASS'
    else:
        assert report['generated_tokens'] == (32 if name == 'restore' else 128 if name.startswith('two-turn') else 64)
        assert report['live_committed_versions'] == 0
        assert report['actual_draft_rows_scope'] == 'admitted_active_input_rows'
    save(folder / 'report.json', report)
    print('PASS', name, attempt, flush=True)


def extend():
    p = read(W / 'plan.json')
    old_source = Path(p['consumers']['natural']['source'])
    content = old_source.read_text(encoding='utf-8')
    marker = '    if (name == "natural") return qwen_mtp_natural_relay_case::run(argv[3], kind);'
    assert content.count(marker) == 1
    source = W / 'model.cc'
    source.write_text(content.replace(marker, marker + '\n    if (name == "mixed") return qwen_mtp_mixed_lag_case::run(argv[3], kind);'), encoding='utf-8')
    p['consumers']['natural']['source'] = str(source)
    p['consumers']['natural']['compile'] = s.relocated(p['consumers']['natural']['compile'], 'natural', source)
    fixture = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
    p['cases']['batch'] = ['natural', 'batch', 'cuda', str(fixture)]
    p['cases']['mixed'] = ['natural', 'mixed', 'cuda', str(fixture)]
    turns = W / 'restore.turns'
    prompt = Path(p['cases']['single-auto'][2]) / 'prompt.ids'
    turns.write_text(('prompt ' + prompt.as_posix() + '\ngenerate 8\n') * 2, encoding='utf-8')
    manifest = W / 'restore.sessions'
    manifest.write_text('first restore.turns\nsecond restore.turns\n', encoding='utf-8')
    args = p['cases']['single-auto'][1:]
    index = args.index('--steps')
    del args[index:index+2]
    p['cases']['restore'] = ['cli', *args, '--session-schedules', str(manifest)]
    p['restore_fixture'] = [pin(turns), pin(manifest), pin(prompt)]
    save(W / 'plan.json', p)
    print('Added original failure/mixed-padding cases and finite two-request restore check; preserved old source.', flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare':
        prepare()
    elif action == 'extend':
        extend()
    elif action == 'compile':
        s.compile_one(*sys.argv[2:])
    elif action == 'link':
        s.link(*sys.argv[2:])
    elif action == 'run':
        run(*sys.argv[2:])
    elif action == 'run-selected':
        for name in sys.argv[3:]:
            run(name, sys.argv[2])
    else:
        raise ValueError(action)
