# Separate cold configuration from stable caller bindings

Source review, 2026-10-20. This is implementation work for the current refactor,
not a new workflow or a second executor.

## Observed seam

`src/graph_batch/batch.cc::prepare_all` calls `Invocation::reset` before every
layout preparation. That resets all external tensors, owned leases and immutable
InputSource owners even when only KV/page metadata and permissions changed.
Qwen's finite family reuses compiled programs and capture, but currently has to
bind the stable ports again. BatchResources already owns the exact transient
layout/frame reset, and the original Invocation already provides the required
result, observation, native retirement and preparation exclusion gates.

## Intended behavior

Keep the existing `batch::prepare` entry points. They revoke the prior layout
episode and expire all its configuration metadata, projected ready/pending page
permissions and source controls. Ordinary caller input/output bindings, their
ReadLease/WriteLease owners and immutable InputSource owners survive. A caller
can still explicitly `Invocation::reset` to clear everything.

The common core must not recognize attention, row-cache, model, platform or
Provider IDs. Record the binding lifetime where the actual binding is committed:
caller, cold configuration or projected resources. Retain the old ready versus
pending replacement rules. The typed adapter resets its existing payload; the
common core clears only bindings tagged as configuration/projected resources.
No snapshot-and-rebind, second binding table, saved permissions or new executor.

Use one private `RegionAccess::reset_configuration(Invocation&)` bridge, not a
new public mode flag or a second family of user APIs. Its original gate must
reject while results, observers, native work, pending source controls or cold
preparation still own the slot. Invalidate affected recordings BEFORE releasing
their native import/lease owners. Ordinary stable recordings remain subject to
the existing port identity comparison in prepare_replay.

After a successful reset, old results are unpublished, replay is unprepared,
configuration/projected raw views are unbound, and anonymous page guard records
are removed. Stable bindings still participate in normal alias validation and
lease admission. Rebuild the original alias index from surviving bindings.
Preparing a new layout must not grant any old projected page permission.

A failed cold layout preparation keeps stable caller bindings, but leaves no
submit-capable layout. Repeated reset/cleanup uses the same lifetime-aware path.
An explicit full Invocation reset continues to release all binding categories.

## Relevant follow-up constraints

`RegionAccess::reserve_reads` currently rejects capacity growth after any owned
binding. Inspect whether that restriction is needed under the original cold
idle/observation gate; do not let preserving stable weights create a hidden
requirement to unbind them. Capacity allocation remains cold and must keep the
original pool alive until replacement succeeds.

The public Graph, PlanState and InvocationState layout need no new fields.
The binding category can replace the private ResourceEpisode LeaseBinding
configuration bool in resources.cc. Ordinary operators and backend providers
need no changes for this shared lifecycle correction.

## Focused validation

Use existing CPU graph/batch fixtures and cached object/link recipes. Establish
an actual old-implementation failure for a two-episode paged/ragged chain that
binds stable input and output once, changes owned layout and frame, and prepares
replay again. Check exact outputs and unchanged source-owner retention. A missing
new page frame must reject preparation/submission instead of reading an old page.
Retained result/Completion must block mutation; after release, the same original
slot is reusable. Include changed input buffers to prove preserved bindings read
current payload rather than captured values. Keep the explicit full-reset test.

Run only relevant configuration/input-source/batch lifecycle neighbors. Reuse
SDKs; no performance or whole-model claim follows from these correctness tests.
Do not mutate common source while the current MLX Apple/Vulkan closure builds
are using frozen receipts; finish that batch first, then refresh the few actual
common owners required by this change.
