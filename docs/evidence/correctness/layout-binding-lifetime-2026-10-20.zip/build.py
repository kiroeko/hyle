"""Refresh four changed owners, one stale factory and focused CPU tests."""
import concurrent.futures
import importlib.util
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('binding_lifetime_host', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

def main():
    out = S/'checks'
    out.mkdir(exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    base = c.read(S/'reproduction/link-plan.json')
    meta = h.metadata({'cpu': base})
    wanted = {str(ROOT/rel).casefold(): rel for rel in (
        'src/graph/executable.cc', 'src/graph/resources.cc',
        'src/graph/input_sources.cc', 'src/graph_batch/batch.cc',
        'src/compute/custom_kernel.cc')}
    rows = []
    for old in base['inputs']:
        recipe = meta.get(c.key(old['path']))
        if not recipe or str(Path(recipe['source_path']).resolve()).casefold() not in wanted:
            continue
        source = Path(recipe['source_path'])
        tag = source.parent.name+'-'+source.stem
        rows.append(dict(tag=tag, old_object=old, source=b.identity(source),
            object=str(out/(tag+'.obj')), command=b.host_command(recipe['command'], source, tag, out),
            recipe=recipe['recipe']))
    assert len(rows) == 5 and {Path(row['source']['path']).name for row in rows} == {
        'executable.cc', 'resources.cc', 'input_sources.cc', 'batch.cc', 'custom_kernel.cc'}
    test_recipe = c.read(A/'batch-output-tail/checks/typed-test-identity.json')
    for filename in ('configuration_input_test.cc', 'input_source_frontier_test.cc'):
        source = ROOT/'tests/graph'/filename
        tag = source.stem
        rows.append(dict(tag=tag, old_object=None, source=b.identity(source),
            object=str(out/(tag+'.obj')), command=b.host_command(test_recipe['command'], source, tag, out)))
    frozen = [row['source'] for row in rows] + [b.identity(ROOT/rel) for rel in (
        'src/graph/resource_episode.h', 'src/graph/input_sources.h',
        'include/hyle/graph/detail/region_access.h',
        'tests/graph_batch/typed_capability_graph_test.cc')]
    for row in base['inputs']:
        assert b.same(row), row['path']
    old_test = c.read(S/'reproduction/typed-test-identity.json')
    assert b.same(old_test['object']) and b.same(old_test['source'])
    env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
    c.save(out/'plan.json', dict(compile=rows, frozen=frozen, SDK_rebuild=False,
        product_CXX=5, changed_implementation_owners=4, stale_cache_owners=1,
        test_CXX=2, native_CXX=0,
        regression_object_reused=old_test['object'],
        interface_change='Additional private nonvirtual static methods/functions only; original PlanState/InvocationState and vtable layouts unchanged.'))
    c.save(out/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))
    if '--build' not in sys.argv:
        print('LAYOUT_BINDING_PLAN', len(rows), flush=True)
        return
    def check():
        for row in frozen:
            assert b.same(row), row['path']
    def compile_one(row):
        check()
        receipt = out/(row['tag']+'-identity.json')
        if receipt.exists():
            previous = c.read(receipt)
            if previous['command'] == row['command'] and b.same(previous['object']) and all(b.same(dep) for dep in previous['dependencies']):
                return row['tag'], previous
        c.execute(row['tag']+'-compile', row['command'], env, out)
        check()
        deps = c.read(out/(row['tag']+'-deps.json'))['Data']
        result = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
            dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
        c.save(receipt, result)
        return row['tag'], result
    finished, errors = {}, []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one, row) for row in rows]):
            try:
                tag, receipt = future.result()
                finished[tag] = receipt
            except Exception as error:
                errors.append(repr(error))
    c.save(out/'compile-summary.json', dict(passed=not errors, errors=errors, product_CXX=5,
        changed_implementation_owners=4, stale_cache_owners=1, test_CXX=2, SDK_rebuild=False))
    if errors:
        raise RuntimeError(errors)
    replacements = {c.key(row['old_object']['path']): finished[row['tag']]['object'] for row in rows if row['old_object']}
    additions = [finished[row['tag']]['object'] for row in rows if not row['old_object']]
    inputs = [replacements.get(c.key(row['path']), row) for row in base['inputs']] + additions
    image = out/'cpu.exe'
    command = [replacements.get(c.key(arg), {}).get('path', arg) for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += [row['path'] for row in additions]
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    for row in inputs:
        assert b.same(row), row['path']
    check()
    c.save(out/'link-plan.json', dict(command=command, inputs=inputs))
    c.execute('link', command, env, out)
    c.save(out/'image.json', b.identity(image))
    filter = 'TypedCapabilityGraph.*:ConfigurationInput.*:InputSourceFrontier.*'
    command = [str(image), '--gtest_filter='+filter, '--gtest_output=xml:'+str(out/'results.xml')]
    try:
        c.execute('tests', command, env, out)
    except RuntimeError:
        pass
    cases = ET.parse(out/'results.xml').findall('.//testcase')
    failed = [case.attrib['classname']+'.'+case.attrib['name'] for case in cases if case.findall('failure')]
    skipped = [case.attrib['name'] for case in cases if case.findall('skipped')]
    names = [case.attrib['classname']+'.'+case.attrib['name'] for case in cases]
    assert 'ConfigurationInput.LayoutResetPreservesCallerLeasesAndSourceButExpiresMetadata' in names
    assert 'TypedCapabilityGraph.SharedMetadataAcrossHostResourcesSurvivesLayoutUpdates' in names
    summary = dict(passed=not failed and not skipped and c.read(out/'tests.result.json')['exit'] == 0,
        cases=len(cases), failed=failed, skipped=skipped, names=names,
        product_CXX=5, changed_implementation_owners=4, stale_cache_owners=1,
        test_CXX=2, SDK_rebuild=False, GPU_runs=0,
        unchanged_red_test_object=old_test['object'])
    c.save(out/'summary.json', summary)
    print('LAYOUT_BINDING_RESULTS', summary, flush=True)
    if not summary['passed']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
