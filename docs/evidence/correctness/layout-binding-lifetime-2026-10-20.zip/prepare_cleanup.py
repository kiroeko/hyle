"""Write exact-file cleanup to root test.ps1; never execute deletion here."""
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
out = S/'cleanup'
out.mkdir(exist_ok=True)

def identity(path):
    path = path.resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

targets = []
for directory, stems in (
    (A/'mlx-grouped-shared-activation/checks', ('cpu', 'cuda')),
    (A/'mlx-grouped-shared-activation/reproduction', ('tests',)),
    (A/'mlx-grouped-shared-activation/apple-vulkan/host', ('vulkan',)),
    (A/'batch-output-tail/checks', ('cpu', 'cuda')),
    (S/'reproduction', ('cpu-before',)),
):
    for stem in stems:
        for suffix in ('.exe', '.map', '.lib', '.exp'):
            path = directory/(stem+suffix)
            if path.is_file():
                assert path.resolve().is_relative_to(A.resolve())
                targets.append(identity(path))
protected = []
for directory, stems in (
    (A/'mlx-grouped-shared-activation/checks/tests', ('cpu', 'cuda')),
    (A/'mlx-grouped-shared-activation/apple-vulkan/test-checks', ('vulkan-mlx',)),
    (S/'checks', ('cpu',)), (S/'cuda', ('capture',)),
    (A/'qwen-finite-family/product-checks', ('qwen',)),
    (A/'qwen-pinned-weight-load/product-checks', ('qwen',)),
    (A/'cuda-explicit-rope/performance-prepared', ('peer',)),
):
    for stem in stems:
        path = directory/(stem+'.exe')
        assert path.is_file(), path
        protected.append(identity(path))
for path in [*sorted((S/'checks').glob('*.obj')), *sorted((S/'cuda').glob('*.obj')),
    S/'reproduction/typed-test.obj',
    ROOT/'docs/evidence/correctness/mlx-grouped-shared-activation-2026-10-20.json',
    ROOT/'docs/evidence/correctness/mlx-grouped-shared-activation-2026-10-20.zip',
    ROOT/'docs/evidence/correctness/layout-binding-lifetime-2026-10-20.json',
    ROOT/'docs/evidence/correctness/layout-binding-lifetime-2026-10-20.zip']:
    protected.append(identity(path))
assert len(targets) == len({row['path'].casefold() for row in targets})
assert not {row['path'].casefold() for row in targets} & {row['path'].casefold() for row in protected}
plan = dict(workspace=str(ROOT), delete=targets, protected=protected,
    target_count=len(targets), target_bytes=sum(row['bytes'] for row in targets),
    scope='Exact superseded images/maps/import libraries only after both evidence archives sealed. Keep all SDKs, objects, sources, actual current and comparison images, unique vectors, models, commands and results.')
(out/'cleanup-plan.json').write_text(json.dumps(plan, indent=2)+'\n', encoding='utf-8')
script = ROOT/'test.ps1'
prior = script.read_text(encoding='utf-8-sig')
(out/'test.before.ps1').write_text(prior, encoding='utf-8')
old = '.scratch/architecture-refactor-2026-10-18/qwen-finite-family/cleanup-plan.json'
new = '.scratch/architecture-refactor-2026-10-18/layout-binding-lifetime/cleanup/cleanup-plan.json'
assert prior.count(old) == 1
script.write_text(prior.replace(old, new), encoding='utf-8')
(out/'script.json').write_text(json.dumps(identity(script), indent=2)+'\n', encoding='utf-8')
print('CLEANUP_WRITTEN_NOT_EXECUTED', len(targets), plan['target_bytes'], flush=True)
