"""Retain the layout-lifetime source, actual red/green and diagnostic evidence."""
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

S = Path(__file__).resolve().parent
ROOT = S.parents[2]

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def identity(path):
    path = path.resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

def exact(row):
    actual = identity(Path(row['path']))
    return all(actual[key] == row[key] for key in ('path', 'bytes', 'sha256'))

def xml(path):
    cases = ET.parse(path).findall('.//testcase')
    return dict(cases=len(cases), failures=sum(bool(case.findall('failure')) for case in cases),
        skipped=sum(bool(case.findall('skipped')) for case in cases), identity=identity(path))

def main():
    before, cpu = xml(S/'reproduction/results.xml'), xml(S/'checks/results.xml')
    assert before['cases'] == before['failures'] == 1 and before['skipped'] == 0
    assert cpu['cases'] == 11 and cpu['failures'] == cpu['skipped'] == 0
    assert read(S/'checks/summary.json')['passed']
    cuda_summary = read(S/'cuda/summary.json')
    assert cuda_summary['passed']
    cuda_xml = next(path for path in (S/'cuda').glob('*.xml') if 'results' in path.name or 'test' in path.name)
    cuda = xml(cuda_xml)
    assert cuda['cases'] >= 1 and cuda['failures'] == cuda['skipped'] == 0
    for row in read(S/'core/source-freeze.json')['files']:
        actual = identity(ROOT/row['path'])
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
    links = dict(cpu=S/'checks/link-plan.json', cuda=S/'cuda/link-plan.json')
    for path in links.values():
        for row in read(path)['inputs']:
            assert exact(row), row['path']
    old_test = read(S/'reproduction/typed-test-identity.json')['object']
    assert exact(old_test) and old_test in read(links['cpu'])['inputs']
    sources = [row['path'] for row in read(S/'core/source-freeze.json')['files']]
    sources += ['src/graph_batch/batch.cc', 'tests/graph_batch/typed_capability_graph_test.cc',
        'tests/graph_batch/batch_capture_test.cc', 'tests/graph/configuration_input_test.cc',
        'tests/graph/input_source_frontier_test.cc']
    docs = ['docs/architecture/compute-design.md', 'docs/architecture/graph-design.md',
        'docs/user/batch-attention.md', 'docs/developer/current-work.md']
    snapshots = []
    for rel in [*sources, *docs]:
        path, target = ROOT/rel, S/'snapshot'/rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        snapshots.append(dict(relative=rel, source=identity(path), snapshot=identity(target)))
    save(S/'snapshot-manifest.json', snapshots)
    files = sorted((path for path in S.rglob('*') if path.is_file() and
        path.suffix in {'.py', '.cc', '.h', '.json', '.log', '.xml', '.diff', '.md'} and
        not set(path.relative_to(S).parts) & {'tmp', '__pycache__'} and
        path.name not in {'publication.json', 'payload-sha256.json', 'cleanup-plan.json', 'cleanup-executed.json'}),
        key=lambda path: path.relative_to(S).as_posix())
    dest = ROOT/'docs/evidence/correctness/layout-binding-lifetime-2026-10-20.zip'
    payloads = []
    with zipfile.ZipFile(dest, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            row = dict(**identity(path), member=path.relative_to(S).as_posix())
            archive.writestr(row['member'], path.read_bytes())
            payloads.append(row)
        archive.writestr('payload-sha256.json', json.dumps(payloads, indent=2, ensure_ascii=False).encode())
    with zipfile.ZipFile(dest) as archive:
        assert archive.testzip() is None
        for row in payloads:
            assert hashlib.sha256(archive.read(row['member'])).hexdigest() == row['sha256']
    report = dict(date='2026-10-20', status='CPU_CUDA_layout_binding_lifetime_fix_executed',
        problem='batch::prepare reset the whole Invocation, dropping stable caller inputs/outputs/leases/InputSource owners on every layout change.',
        behavior='Existing batch::prepare revokes configuration and projected permissions, retains caller bindings and their owners. Explicit Invocation::reset still clears all bindings.',
        implementation=dict(changed_CXX_owners=4, new_user_modes=0, new_executors=0,
            public_PlanState_InvocationState_or_vtable_layout_changed=False,
            binding_scope='Private ResourceEpisode Caller/Configuration/Projected lifetime; all ready, pending, empty and generic projected commits are explicit.',
            prepared_source='Reset derived source preparation, retain binding owners, reroute under complete cold preparation.',
            mutation='Original result/observation/retirement/source-control gates; invalidate affected native imports before releasing owners; rebuild original alias index.',
            complexity='One native step/input-port pass resolving aliases and existing binding_slots, no per-configuration-port whole-graph scan or new index.',
            cleanup='One enclosing batch configuration transaction, selective failure cleanup, original strict replay remains revoked until successful preparation.'),
        actual=dict(before=before, cpu=cpu, cuda=cuda,
            unchanged_red_test_object=old_test, cpu_summary=identity(S/'checks/summary.json'),
            cuda_summary=identity(S/'cuda/summary.json'), core_freeze=identity(S/'core/source-freeze.json')),
        diagnostics=dict(stale_factory='Existing custom_kernel.obj used Provider contract16 while Context requires17. Recompiled only the original factory owner; no factory product source or version check changed.',
            fixture_errors='Initial Status assertion required .ok(); readonly adopted ReadLease is never writable, so promotion witness now uses an actual writable LeasePool. Original errors and sources retained.',
            rejected_candidate='Initial per-port recording invalidation was replaced before compilation with one shared pass.'),
        scope_limits=['Only Windows CPU/CUDA ran for the layout change; Apple/Linux/Vulkan still require relevant next-batch validation.',
            'The separately sealed four-backend shared-MLX batch predates this common change and is not cross-platform proof for this lifecycle change.',
            'No new whole-model, throughput, memory-peak or independent-quality conclusion.',
            'No whole-cache source freshness claim; this batch records actual compiled owners and link inputs.'],
        archive=dict(**identity(dest), payloads=len(payloads), CRC_checked=True, all_payload_SHA256_checked=True))
    save(dest.with_suffix('.json'), report)
    save(S/'publication.json', dict(report=identity(dest.with_suffix('.json')), archive=identity(dest), passed=True))
    print('LAYOUT_BINDING_EVIDENCE_PUBLISHED', len(payloads), dest.stat().st_size, flush=True)

if __name__ == '__main__':
    main()
