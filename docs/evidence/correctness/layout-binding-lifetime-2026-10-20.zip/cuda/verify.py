"""Focused CUDA capture regression, using actual retained host recipes only."""
from pathlib import Path
import concurrent.futures
import difflib
import importlib.util
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
S = OUT.parent
A = S.parent
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('binding_cuda_helpers', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASE = A/'mlx-grouped-shared-activation/checks/tests/cuda-link-plan.json'
PRODUCT = ('src/graph/executable.cc', 'src/graph/resources.cc',
    'src/graph/input_sources.cc', 'src/graph_batch/batch.cc')
TEST = 'tests/graph_batch/batch_capture_test.cc'
PRIVATE = ('src/graph/resource_episode.h', 'src/graph/input_sources.h',
    'include/hyle/graph/detail/region_access.h')

def main():
    OUT.mkdir(exist_ok=True)
    (OUT/'tmp').mkdir(exist_ok=True)
    base = c.read(BASE)
    recipes = h.metadata({'cuda': base})
    wanted = {c.key(ROOT/rel): rel for rel in (*PRODUCT, TEST)}
    owners = {}
    for old in base['inputs']:
        recipe = recipes.get(c.key(old['path']))
        if recipe and c.key(recipe['source_path']) in wanted:
            rel = wanted[c.key(recipe['source_path'])]
            assert rel not in owners, rel
            owners[rel] = dict(old=old, recipe=recipe)
    assert set(owners) == set(wanted.values()), (owners.keys(), wanted.values())
    frozen = []
    for rel in (*PRODUCT, TEST, *PRIVATE):
        src = ROOT/rel
        dst = OUT/'source'/b.identity(src)['sha256']/rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            assert dst.read_bytes() == src.read_bytes(), 'Source changed after snapshot: '+rel
        else:
            shutil.copyfile(src, dst)
        frozen.append(dict(source=b.identity(src), retained=b.identity(dst)))
    rows = []
    comparison = []
    for rel in (*PRODUCT, TEST):
        owner = owners[rel]
        source = ROOT/rel
        tag = source.parent.name+'-'+source.stem
        command = b.host_command(owner['recipe']['command'], source, tag, OUT)
        row = dict(tag=tag, source=b.identity(source), old_object=owner['old'],
            baseline_recipe=owner['recipe']['recipe'], command=command,
            object=str(OUT/(tag+'.obj')), action='compile')
        if rel in PRODUCT:
            shared_receipt = S/'checks'/(tag+'-identity.json')
            shared = c.read(shared_receipt)
            normalized = b.host_command(shared['command'], source, tag, OUT)
            equal = command == normalized
            dep_drift = [dict(recorded=dep, actual=b.identity(dep['path']))
                for dep in shared['dependencies'] if not b.same(dep)]
            assert b.same(shared['source']) and b.same(shared['object']), str(shared_receipt)
            assert not dep_drift, dep_drift
            comparison.append(dict(source=rel, cuda_recipe=owner['recipe']['recipe'],
                shared_receipt=str(shared_receipt), canonical_cuda=command,
                canonical_shared=normalized, equal=equal, shared_dependencies=len(shared['dependencies']),
                shared_source=shared['source'], shared_object=shared['object'],
                differences=list(difflib.unified_diff(command, normalized, fromfile='CUDA actual', tofile='CPU new'))))
            if equal:
                row.update(action='reuse_identical_canonical_recipe', object=shared['object']['path'],
                    reused_receipt=str(shared_receipt), reused_identity=shared['object'])
        rows.append(row)
    for old in base['inputs']:
        assert b.same(old), old['path']
    c.save(OUT/'source-freeze.json', dict(files=frozen, interface_change=
        'Private nonvirtual static declarations/functions only; no PlanState, InvocationState, or vtable layout change.'))
    c.save(OUT/'recipe-comparison.json', dict(owners=comparison,
        policy='Full canonical host argument equality is required to reuse CPU objects.'))
    env, runtime = b.environment(base['command'], [x['path'] for x in base['inputs']], OUT)
    c.save(OUT/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))
    c.save(OUT/'plan.json', dict(base=b.identity(BASE), rows=rows,
        compile_CXX=sum(r['action']=='compile' for r in rows), reuse_CXX=sum(r['action']!='compile' for r in rows),
        SDK_rebuild=False, NVCC=0, unrelated_owners_refreshed=0))
    print('CUDA_PLAN', [(r['tag'], r['action']) for r in rows], flush=True)
    if '--build' not in sys.argv:
        return
    def check():
        for row in frozen:
            assert b.same(row['source']) and b.same(row['retained']), row
    def compile_one(row):
        check()
        receipt = OUT/(row['tag']+'-identity.json')
        if row['action'] != 'compile':
            result = c.read(row['reused_receipt'])
            result = dict(result, actual_receipt=row['reused_receipt'], reuse_basis='Identical canonical full recipe; original source/object/all dependencies match current frozen files.')
            c.save(receipt, result)
            return row['tag'], result
        if receipt.exists():
            previous = c.read(receipt)
            if previous['command'] == row['command'] and b.same(previous['object']) and all(b.same(d) for d in previous['dependencies']):
                return row['tag'], previous
        c.execute(row['tag']+'-compile', row['command'], env, OUT)
        check()
        dep = c.read(OUT/(row['tag']+'-deps.json'))['Data']
        result = dict(source=row['source'], command=row['command'], object=b.identity(row['object']),
            dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'], *dep['Includes']])])
        c.save(receipt, result)
        return row['tag'], result
    results, errors = {}, []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one, row) for row in rows]):
            try:
                tag, receipt = future.result()
                results[tag] = receipt
            except Exception as error:
                errors.append(repr(error))
    c.save(OUT/'compile-summary.json', dict(passed=not errors, errors=errors,
        compile_CXX=sum(r['action']=='compile' for r in rows), reuse_CXX=sum(r['action']!='compile' for r in rows), SDK_rebuild=False, NVCC=0))
    if errors:
        raise RuntimeError(errors)
    replacements = {c.key(row['old_object']['path']): results[row['tag']]['object'] for row in rows}
    inputs = [replacements.get(c.key(row['path']), row) for row in base['inputs']]
    for row in inputs:
        assert b.same(row), row['path']
    command = [replacements.get(c.key(arg), {}).get('path', arg) for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    image = OUT/'capture.exe'
    command += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(OUT/'link-plan.json', dict(command=command, inputs=inputs))
    check()
    c.execute('link', command, env, OUT)
    c.save(OUT/'image.json', b.identity(image))
    if '--test' not in sys.argv:
        return
    filter = 'GraphBatchCapture.*:BatchOutputTail.*'
    command = [str(image), '--gtest_filter='+filter, '--gtest_output=xml:'+str(OUT/'results.xml')]
    try:
        c.execute('tests', command, env, OUT)
    except RuntimeError:
        pass
    cases = ET.parse(OUT/'results.xml').findall('.//testcase')
    failed = [x.attrib['classname']+'.'+x.attrib['name'] for x in cases if x.findall('failure')]
    skipped = [x.attrib['classname']+'.'+x.attrib['name'] for x in cases if x.findall('skipped')]
    names = [x.attrib['classname']+'.'+x.attrib['name'] for x in cases]
    passed = not failed and not skipped and len(cases) == 4 and c.read(OUT/'tests.result.json')['exit'] == 0
    summary = dict(passed=passed, cases=len(cases), failed=failed, skipped=skipped, names=names,
        compile_CXX=sum(r['action']=='compile' for r in rows), reuse_CXX=sum(r['action']!='compile' for r in rows),
        product_CXX=sum(r['action']=='compile' and r['source']['path']!=str(ROOT/TEST) for r in rows),
        test_CXX=1, links=1, GPU_runs=1, SDK_rebuild=False, NVCC=0)
    c.save(OUT/'summary.json', summary)
    print('CUDA_CAPTURE_RESULTS', summary, flush=True)
    if not passed:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
