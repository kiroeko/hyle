"""Retain actual focused CUDA inputs, receipt references, and first-failure proof."""
from pathlib import Path
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('binding_cuda_verify', OUT/'verify.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
b, c = v.b, v.c

def main():
    plan = c.read(OUT/'plan.json')
    link = c.read(OUT/'link-plan.json')
    summary = c.read(OUT/'summary.json')
    assert summary['passed'] and summary['cases'] == 4 and not summary['skipped']
    recipes = v.h.metadata({'cuda': link})
    inventory = []
    for row in link['inputs']:
        assert b.same(row), row
        record = recipes.get(c.key(row['path']))
        item = dict(input=row)
        if record:
            item['actual_owner'] = dict(recipe=b.identity(record['recipe']),
                source=record.get('source', record['source_path']), command=record['command'],
                recorded_dependencies=record.get('dependencies', []))
        else:
            item['actual_owner'] = 'Linked library or historical object without retained compiler recipe in this stage; input SHA is exact.'
        inventory.append(item)
    c.save(OUT/'actual-link-inputs.json', dict(inputs=inventory,
        note='All linked bytes verified against the actual link plan. Historical dependency records retain original identities; only the four changed owners and one newly compiled test are asserted current in closure-proof.json.'))
    owners = []
    for row in plan['rows']:
        receipt = c.read(OUT/(row['tag']+'-identity.json'))
        assert b.same(receipt['source']) and b.same(receipt['object'])
        deps = receipt['dependencies']
        drift = [dep for dep in deps if not b.same(dep)]
        assert not drift, drift
        owners.append(dict(tag=row['tag'], action=row['action'],
            receipt=b.identity(OUT/(row['tag']+'-identity.json')),
            source=receipt['source'], object=receipt['object'], dependencies=len(deps),
            current_dependency_drift=drift))
    freeze = c.read(OUT/'source-freeze.json')
    for row in freeze['files']:
        assert b.same(row['source']) and b.same(row['retained'])
    env, _ = b.environment(link['command'], [x['path'] for x in link['inputs']], OUT)
    c.execute('hardware', ['nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total,compute_cap', '--format=csv,noheader'], env, OUT)
    first = c.read(OUT/'attempt1/graph_batch-batch_capture_test-compile.result.json')
    assert first['exit'] == 2
    proof = dict(passed=True, owners=owners, actual_link_input_count=len(inventory),
        source_freeze=b.identity(OUT/'source-freeze.json'),
        exact_recipe_comparison=b.identity(OUT/'recipe-comparison.json'),
        actual_link_inputs=b.identity(OUT/'actual-link-inputs.json'),
        first_failure=dict(kind='New test passed Status directly to EXPECT_FALSE; gtest C2440/C2439.',
            result=b.identity(OUT/'attempt1/graph_batch-batch_capture_test-compile.result.json'),
            source=b.identity(OUT/'attempt1/source/tests/graph_batch/batch_capture_test.cc'),
            correction='Root added .ok() to the assertion; product owners and their compiled objects unchanged.'),
        no_product_source_edits_by_verifier=True, no_test_source_edits_by_verifier=True,
        ABI_basis='Only private static/nonvirtual declarations/functions added. PlanState/InvocationState/vtable layouts unchanged; no unrelated owner rebuild.',
        limitations=['Four focused tests on actual SM89 Windows hardware; no model, throughput, or cross-platform acceptance.',
            'Hardware queried in the same validation environment; fixture does not emit selected GPU UUID.',
            'Unchanged historical owner dependency records are retained as original receipt identities, not asserted rebuilt against all current source.'])
    c.save(OUT/'closure-proof.json', proof)
    result = dict(summary, hardware=(OUT/'hardware.stdout.log').read_text(encoding='utf-8').strip(),
        link_inputs=len(inventory), closure_proof=b.identity(OUT/'closure-proof.json'),
        artifacts=[b.identity(OUT/name) for name in (
            'source-freeze.json','recipe-comparison.json','actual-link-inputs.json','plan.json',
            'compile-summary.json','link-plan.json','image.json','results.xml','summary.json',
            'tests.command.json','tests.result.json','tests.stdout.log','tests.stderr.log',
            'hardware.command.json','hardware.result.json','hardware.stdout.log','hardware.stderr.log')])
    c.save(OUT/'final-validation.json', result)
    print(json.dumps(dict(summary=result['passed'], cases=result['cases'], link_inputs=len(inventory),
        final=b.identity(OUT/'final-validation.json')), ensure_ascii=False), flush=True)

if __name__ == '__main__':
    main()
