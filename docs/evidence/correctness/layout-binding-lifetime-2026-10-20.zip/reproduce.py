"""Run the bind-once regression against the actual pre-change CPU closure."""
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
spec = importlib.util.spec_from_file_location('layout_binding_helpers', A/'projected-bind-cold-index/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = S/'reproduction'
out.mkdir(exist_ok=True)
(out/'tmp').mkdir(exist_ok=True)
base = c.read(A/'mlx-grouped-shared-activation/checks/tests/cpu-link-plan.json')
recipe = c.read(A/'batch-output-tail/checks/typed-test-identity.json')
source = ROOT/'tests/graph_batch/typed_capability_graph_test.cc'
command = b.host_command(recipe['command'], source, 'typed-test', out)
env, runtime = b.environment(base['command'], [row['path'] for row in base['inputs']], out)
for row in base['inputs']:
    assert b.same(row), row['path']
c.execute('typed-test-compile', command, env, out)
deps = c.read(out/'typed-test-deps.json')['Data']
fresh = dict(command=command, source=b.identity(source), object=b.identity(out/'typed-test.obj'),
    dependencies=[b.identity(path) for path in dict.fromkeys([deps['Source'], *deps['Includes']])])
c.save(out/'typed-test-identity.json', fresh)
old = c.key(recipe['object']['path'])
assert sum(c.key(row['path']) == old for row in base['inputs']) == 1
image = out/'cpu-before.exe'
link = [fresh['object']['path'] if c.key(arg) == old else arg for arg in base['command']
        if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
link += ['/OUT:'+str(image), '/MAP:'+str(image.with_suffix('.map')), '/IMPLIB:'+str(image.with_suffix('.lib'))]
inputs = [fresh['object'] if c.key(row['path']) == old else row for row in base['inputs']]
c.save(out/'link-plan.json', dict(command=link, inputs=inputs))
c.execute('link', link, env, out)
c.save(out/'image.json', b.identity(image))
test = [str(image), '--gtest_filter=TypedCapabilityGraph.SharedMetadataAcrossHostResourcesSurvivesLayoutUpdates',
        '--gtest_output=xml:'+str(out/'results.xml')]
try:
    c.execute('test', test, env, out)
except RuntimeError:
    pass
cases = ET.parse(out/'results.xml').findall('.//testcase')
summary = dict(cases=len(cases), failures=sum(bool(case.findall('failure')) for case in cases),
    skipped=sum(bool(case.findall('skipped')) for case in cases),
    exit=c.read(out/'test.result.json')['exit'],
    source=fresh['source'], image=b.identity(image),
    scope='Same original CPU executable/Invocation, two actual resources and readers, stable bindings once, changed payload/layout, old result gate.')
c.save(out/'summary.json', summary)
assert summary['cases'] == summary['failures'] == 1 and summary['skipped'] == 0 and summary['exit'] != 0
print('BIND_ONCE_OLD_IMPLEMENTATION_RED', json.dumps(summary), flush=True)
