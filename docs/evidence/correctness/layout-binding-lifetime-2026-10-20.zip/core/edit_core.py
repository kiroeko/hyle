"""Prepare/apply only the six assigned core files against exact saved before."""
from pathlib import Path
import difflib,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[4];S=Path(__file__).resolve().parent
files=json.loads((S/'before.json').read_text())['files'];sources={}
for row in files:
 raw=(S/'before'/row['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];sources[row['path']]=raw.decode().replace('\r\n','\n')
def replace(path,old,new,count=1):
 text=sources[path];assert text.count(old)==count,(path,old,text.count(old),count);sources[path]=text.replace(old,new)
p='src/graph/resources.cc'
replace(p,'struct LeaseBinding final {','enum class BindingScope : std::uint8_t { kCaller, kConfiguration, kProjected };\n\nstruct LeaseBinding final {')
replace(p,'  bool configuration = false;','  BindingScope scope = BindingScope::kCaller;')
replace(p,'if (binding && binding->configuration)','if (binding && binding->scope == BindingScope::kConfiguration)')
old='''void reset_resource_bindings(InvocationState &state) noexcept {
  // Native imports can own carriers/arrays independently of their raw address.
  // Release their recording before withdrawing the old source or lease owner.
  invalidate_native_input_bindings(state);
  reset_input_source_bindings(state);
  if (!state.resources) return;
  state.resources.get()->input_lease_candidates.clear();
  auto &bindings = state.resources.get()->bindings;
  // All extra records are anonymous page guards; fixed ValueId slots never
  // move. Shrinking releases exactly the old projected permission suffix.
  bindings.resize(state.resources.get()->fixed_binding_count);
  for (auto &binding : bindings) {
    binding.read.reset(); binding.write.reset(); binding.description = {};
    binding.projection = {};
    binding.exclusive = false; binding.permissionless = false; binding.borrowed = true;
    binding.configuration = false;
  }
}'''
new='''void clear_binding_owner(LeaseBinding &binding) noexcept {
  binding.read.reset(); binding.write.reset(); binding.description = {};
  binding.projection = {};
  binding.exclusive = false; binding.permissionless = false; binding.borrowed = true;
  binding.scope = BindingScope::kCaller;
}
void reset_resource_bindings(InvocationState &state) noexcept {
  // Native imports can own carriers/arrays independently of their raw address.
  // Release their recording before withdrawing the old source or lease owner.
  invalidate_native_input_bindings(state);
  reset_input_source_bindings(state);
  if (!state.resources) return;
  auto &episode = *state.resources.get();
  episode.input_lease_candidates.clear();
  // All extra records are anonymous page guards; fixed ValueId slots never
  // move. Shrinking releases exactly the old projected permission suffix.
  episode.bindings.resize(episode.fixed_binding_count);
  for (auto &binding : episode.bindings) clear_binding_owner(binding);
}
void reset_configuration_bindings(InvocationState &state) noexcept {
  if (state.resources) {
    auto &episode = *state.resources.get();
    // Drop the covering recordings before any configuration lease or anonymous
    // page guard. Caller bindings and their native import owners survive.
    for (std::size_t i = 0; i < episode.fixed_binding_count; ++i) {
      const auto &binding = episode.bindings[i];
      if (binding.scope != BindingScope::kCaller)
        invalidate_native_input_bindings(state, binding.value);
    }
    episode.input_lease_candidates.clear();
    for (std::size_t i = 0; i < episode.fixed_binding_count; ++i) {
      auto &binding = episode.bindings[i];
      if (binding.scope == BindingScope::kCaller) continue;
      const auto instance = state.plan->external_instances[binding.value.ordinal()];
      state.readable[instance] = {};
      state.writable[instance] = {};
      state.bound[instance] = 0;
      clear_binding_owner(binding);
    }
    episode.bindings.resize(episode.fixed_binding_count);
  }
  // Sources remain bound; dependency routes and readiness belong to the old
  // preparation and must be derived again for the next layout episode.
  reset_input_source_preparation(state);
}'''
replace(p,old,new)
replace(p,"""    for (std::size_t i = 0; i < episode.fixed_binding_count; ++i) {
      const auto &binding = episode.bindings[i];
      if (binding.scope != BindingScope::kCaller)
        invalidate_native_input_bindings(state, binding.value);
    }""", """    const auto &plan = *state.plan;
    for (std::size_t index = 0; index < state.step_bindings.size(); ++index) {
      if (!state.step_bindings[index].native_inputs) continue;
      const auto &step = plan.steps[index];
      for (std::size_t port = 0; port < step.input_count; ++port) {
        auto input = plan.node_inputs[step.input_begin + port];
        while (plan.alias_sources[input] != kNoInPlaceSource)
          input = plan.alias_sources[input];
        const auto logical = plan.instance_values[input];
        if (logical >= episode.binding_slots.size()) continue;
        const auto slot = episode.binding_slots[logical];
        if (slot >= episode.fixed_binding_count ||
            episode.bindings[slot].scope == BindingScope::kCaller) continue;
        invalidate_step_recording(state, static_cast<std::uint32_t>(index));
        break;
      }
    }""")
replace(p,'(previous->read.valid() || previous->write.valid() || previous->configuration)))','(previous->read.valid() || previous->write.valid() ||\n       previous->scope != BindingScope::kCaller)))')
replace(p,'    binding->configuration = false;','    binding->scope = BindingScope::kCaller;')
replace(p,'const bool previous = std::exchange(binding->configuration, false);','const auto previous = std::exchange(binding->scope, BindingScope::kCaller);')
replace(p,'binding->configuration = previous;','binding->scope = previous;')
replace(p,'binding->configuration = true;','binding->scope = BindingScope::kConfiguration;')
replace(p,'  // Only actual capacity growth needs an unbound cold slot.','  // Growth is cold and idle-gated; existing leases do not refer to this pool.\n  // Keep the old pool until every replacement allocation has succeeded.')
replace(p,'''  for (const auto &binding : episode->bindings)
    if (binding.read.valid() || binding.write.valid())
      return Status::FailedPrecondition("reserve page permissions before owned bindings");
''','')
replace(p,'  binding->projection=pending?ValueId{}:value;','  binding->projection=pending?ValueId{}:value;\n  binding->scope=BindingScope::kProjected;')
replace(p,'episode->bindings.push_back({.projection=value,.read=pages[i],.borrowed=false});','episode->bindings.push_back({.projection=value,.read=pages[i],.borrowed=false,.scope=BindingScope::kProjected});')
replace(p,'  binding->read=pages.front();binding->description=tensor.description();binding->exclusive=false;binding->borrowed=false;','  binding->read=pages.front();binding->description=tensor.description();binding->exclusive=false;binding->borrowed=false;\n  binding->scope=BindingScope::kProjected;')
replace(p,'episode->bindings.push_back({.projection=capacity,.read=pages[i],.borrowed=false});','episode->bindings.push_back({.projection=capacity,.read=pages[i],.borrowed=false,.scope=BindingScope::kProjected});',2)
replace(p,'  binding->description=description;binding->exclusive=false;binding->borrowed=false;binding->permissionless=pages.empty()&&!pending;','  binding->description=description;binding->exclusive=false;binding->borrowed=false;binding->permissionless=pages.empty()&&!pending;\n  binding->scope=BindingScope::kProjected;')
p='src/graph/resource_episode.h'
replace(p,'HYLE_GRAPH_API void reset_resource_bindings(InvocationState &) noexcept;','''HYLE_GRAPH_API void reset_resource_bindings(InvocationState &) noexcept;
// Clears cold configuration/projected owners and views, retaining caller ports.
HYLE_GRAPH_API void reset_configuration_bindings(InvocationState &) noexcept;''')
p='src/graph/input_sources.h'
replace(p,'HYLE_GRAPH_API void reset_input_source_bindings(InvocationState &) noexcept;','''HYLE_GRAPH_API void reset_input_source_preparation(InvocationState &) noexcept;
HYLE_GRAPH_API void reset_input_source_bindings(InvocationState &) noexcept;''')
p='src/graph/input_sources.cc'
replace(p,'''void reset_input_source_bindings(InvocationState &state) noexcept {
  if (!state.input_sources) return;
  auto &sources = *state.input_sources.get();
  invalidate(sources);
  for (auto &binding : sources.bindings) binding.source.reset();
}''','''void reset_input_source_preparation(InvocationState &state) noexcept {
  if (!state.input_sources) return;
  auto &sources = *state.input_sources.get();
  invalidate(sources);
  sources.roots.clear(); sources.consumers.clear();
}
void reset_input_source_bindings(InvocationState &state) noexcept {
  reset_input_source_preparation(state);
  if (!state.input_sources) return;
  for (auto &binding : state.input_sources.get()->bindings) binding.source.reset();
}''')
p='src/graph/executable.cc'
replace(p,'''  invalidate_unproven_bindings(*state_);
  HYLE_RETURN_IF_ERROR(detail::reset_resource_payload(*this));
  invalidate_binding_cache(*state_);''','''  // The payload first rejects retained source controls without disturbing the
  // old episode. Its reset revokes readiness before changing native resources.
  HYLE_RETURN_IF_ERROR(detail::reset_resource_payload(*this));
  invalidate_unproven_bindings(*state_);
  invalidate_binding_cache(*state_);''')
replace(p,'Status Invocation::prepare_replay(std::span<const QueueBinding> queues,','''Status detail::RegionAccess::reset_configuration(Invocation &invocation) noexcept {
  auto *state = detail::InvocationAccess::state(invocation);
  HYLE_RETURN_IF_ERROR(detail::resource_control_ready(state));
  HYLE_RETURN_IF_ERROR(detail::reset_resource_payload(invocation));
  invalidate_unproven_bindings(*state);
  invalidate_binding_cache(*state);
  detail::reset_configuration_bindings(*state);
  rebuild_external_alias_index(*state);
  return Status::Ok();
}

Status Invocation::prepare_replay(std::span<const QueueBinding> queues,''')
p='include/hyle/graph/detail/region_access.h'
replace(p,'''  // The original slot lets this owner invalidate the selected commands before
  // releasing native configuration resources. It grants no new work admission.''','''  // Reject retained source controls before mutation, then revoke preparation
  // before changing native resources, including changes that may partly fail.
  // Invalidate selected commands before releasing their native configuration
  // owners. This grants no new work admission.''')
replace(p,'  HYLE_GRAPH_API static Status revoke_preparation(Invocation &) noexcept;','''  HYLE_GRAPH_API static Status revoke_preparation(Invocation &) noexcept;
  // Original idle/result/source-control gates; expires cold configuration and
  // projected permissions while retaining ordinary caller bindings/sources.
  HYLE_GRAPH_API static Status reset_configuration(Invocation &) noexcept;''')
rows=[];diffs=[]
for row in files:
 rel=row['path'];before=(S/'before'/rel).read_bytes();text=sources[rel];data=text.replace('\n','\r\n').encode()if b'\r\n'in before else text.encode()
 candidate=S/'candidate'/rel;candidate.parent.mkdir(parents=True,exist_ok=True);candidate.write_bytes(data)
 diff=''.join(difflib.unified_diff(before.decode().splitlines(True),data.decode().splitlines(True),fromfile='before/'+rel,tofile=rel))
 diffs.append(diff);rows.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
 if '--apply'in sys.argv:
  assert (ROOT/rel).read_bytes()==before,rel
  (ROOT/rel).write_bytes(data)
(S/'source.diff').write_bytes(''.join(diffs).encode());(S/'candidate.json').write_bytes((json.dumps(dict(files=rows,product_applied='--apply'in sys.argv,builds=0,GPU_runs=0),indent=2)+'\n').encode())
print(json.dumps(dict(files=rows,applied='--apply'in sys.argv)))
