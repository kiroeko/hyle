
from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();base=root/'.scratch/inference-gaps/g06';folder=base/'native-ragged-air'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],text=True)
rs={n:json.loads((folder/f'attempt-{n}'/'result.json').read_bytes()) for n in [1,2,3]}
a=rs[2];v=rs[3];assert rs[1]['state']==a['state']=='TERMINAL_FAIL' and v['state']=='TERMINAL_PASS' and v['candidate']==head
apple_stages=[s for s in a['stages'] if s['route']=='apple'];assert len(apple_stages)==17 and all(s['exit_code']==0 for s in apple_stages)
assert len(v['stages'])==18 and all(s['exit_code']==0 and s['route']=='vulkan' for s in v['stages'])
assert all(a['identity'][k]==v['identity'][k] for k in ['model','cpu','memory','arch','os','compiler','cmake','ninja'])
m2=json.loads((folder/'attempt-2/input-manifest.json').read_bytes());m3=json.loads((folder/'attempt-3/input-manifest.json').read_bytes());prior={x['path']:x['sha256'] for x in m2['inputs']}
different=[x['path'] for x in m3['inputs'] if prior.get(x['path'])!=x['sha256']]
assert sorted(different)==['src/compute_route_vulkan/vulkan_program.cc','src/compute_route_vulkan/vulkan_program_internal.h']
for x in m3['inputs']:assert sha(root/x['path'])==x['sha256'],x['path']
for route,n,count in [('apple',2,48),('vulkan',3,24)]:
 p=folder/f'attempt-{n}'/(route+'-g06_native_ragged.log');s=p.read_text();assert '[  PASSED  ] 3 tests.' in s and '[  FAILED  ]' not in s and '[  SKIPPED ]' not in s
 assert '[       OK ] NativeRaggedLayout.PublicRuntimeKvUpdatesKeepIndependentSlotsAndCheckedBoundaries' in s
 for target in ['g04_plain_native_control','g04_encoded_native_risks']:
  s=(folder/f'attempt-{n}'/(route+'-'+target+'.log')).read_text();assert 'cold create all' in s and 'exact backing cap' in s
for target,count in [('ce16_provider',10),('ce16_public',2)]:
 s=(folder/'attempt-3'/('vulkan-'+target+'.log')).read_text();assert f'[  PASSED  ] {count} tests.' in s and '[  FAILED  ]' not in s and '[  SKIPPED ]' not in s
cpu=json.loads((root/'evidence/correctness/inference-g06-cpu-ragged-runtime-source/receipt.json').read_bytes())
for item in cpu['source_inputs']:assert sha(root/item['path'])==item['sha256']
for item in cpu['windows']['artifacts']:assert sha(Path(item['path']))==item['sha256']
inputs=[dict(path=p,sha256=sha(root/p)) for p in subprocess.check_output(['git','diff','--name-only','2e3022c15',head],text=True).splitlines() if p.split('/')[0] in {'include','src','tests'}]
dest=root/'evidence/correctness/inference-g06-native-ragged-runtime-source';dest.mkdir(parents=True,exist_ok=False)
with zipfile.ZipFile(dest/'raw.zip','x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(folder.rglob('*')):
  if p.is_file():z.write(p,'air/'+p.relative_to(folder).as_posix())
 for name in ['native_ragged_air.py','launch_native_ragged_air.py','seal_native_ragged_source.py','native-ragged-plan.json']:z.write(base/name,'helpers-final/'+name)
 for item in inputs:z.write(root/item['path'],'source-final/'+item['path'])
record=dict(kind='G06_D5_NATIVE_RAGGED_PUBLIC_RUNTIME_SOURCE',verdict='PASS_SELECTED_APPLE_VULKAN_SOURCE_WITH_MATCHED_APPLE_REUSE',candidate=head,
 audit_commits=['2e3022c15','753e693be'],source_inputs=inputs,raw_zip_sha256=sha(dest/'raw.zip'),
 apple=dict(from_attempt=2,candidate=a['candidate'],passed_stages=apple_stages,binary_executions=14,identity=a['identity'],unchanged_for_final_candidate=True,only_manifest_differences_are_unselected_vulkan_sources=different),
 vulkan=dict(from_attempt=3,execution=v,binary_executions=15,provider_tests=10,public_alias_phase_tests=2),
 artifacts=json.loads((folder/'attempt-3/artifacts-after-run.json').read_bytes()),
 reused_windows_cpu=dict(receipt='evidence/correctness/inference-g06-cpu-ragged-runtime-source/receipt.json',candidate=cpu['candidate'],ordinary_tests=62,real_consumer_tests=26,pending_scenarios=18,all_cpu_source_inputs_and_original_artifacts_match=True),
 prior_failures=[dict(attempt=n,candidate=r['candidate'],state=r['state'],outer_elapsed_seconds_overlapping=r['outer_elapsed_seconds'],failed_stages=[s for s in r['stages'] if s['exit_code']]) for n,r in rs.items() if n<3],
 proven=['Public prepare_ragged_batch -> create_invocation -> explicit update_ragged_batch -> bind3 packed-capacity ports -> original submit/checked result works on actual M4 Apple and MoltenVK Vulkan.',
 'New Apple48/Vulkan24 configurations each64 episodes cover single Q1, multi Q1 and mixed17+1 with empty request; F16/BF16 Apple and F16 Vulkan, plain/Q8, D64/128/256, D64/Dv128 window16, causal/noncausal. KV grows/shrinks and subsequent request packed offsets move; independent uniform oracle with nonconstant V and poison unused last KV row retains original tolerances.',
 'Successful update unbinds old imports, requiring rebind. Foreign schema, changed Q topology, invalid causal KV, pending/owning completion, old owning output and closed Context reject update. Rejected metadata preserves original bound inputs and numeric output. Separate slot keeps original result through all64 updates.',
 'Apple reuses original per-invocation layout/immutable compiled and managed builder bridge, worker/check/native drain/completion. Vulkan preflights all regions then updates original scalar rows/offset and invalidates original recording, retains graph/gallocr/output; accepted suffix error marks original run failed.',
 'Original native/paged Direct, actual CPU/native/CPU, encoded single/multi separate/paired producers, pending Direct and two-node Graph64, late/multi-source/unknown/cancel/abandon/old-page writer reacquire and Vulkan provider/alias-phase source targets pass.',
 'Apple accepted subgates come from overall FAILED attempt2. Final manifest differs in exactly two Vulkan-private files; no Apple inputs changed. Vulkan-only attempt3 passes. No failed attempt is relabeled PASS; original logs/helpers/manifest/elapsed retained.'],
 limits=['Source correctness and finite P0 only; no full G06 acceptance, new P1, capture, complete headers/relocated static/shared or final sanitizer verdict.',
 'Apple changed KV lengths still construct managed native graph and check host-known layout. Vulkan changed scalars use original re-encoding. Native private/driver costs remain UNKNOWN; reuse does not imply capture/no allocation.',
 'Vulkan cold Program has a shared immutable ragged-contract pointer and ragged-only make_shared allocation; Recorder cold ProgramState copies share it. Compilation covers that copy seam; final appropriate runtime Recorder regression remains in the complete G06 risk batch.',
 'Original two build failures retained: first new GTest macro/Status assertions; second original Recorder copy rejected the initial unique_ptr. Corrected shared ownership was AUDITED before product edit. Source API/normal submit math/worker/vendor/shader/runtime/build tools unchanged.',
 'Apple attempt2 build6.316s; failed attempt1 outer15.211s and attempt2 outer81.335s retained. Vulkan attempt3 build12.945s / outer67.139s. Stage/outer costs overlap; observation, archive and launch gaps without a stopwatch remain UNKNOWN.',
 'Windows D4 CPU evidence is reused only after matching source and actual artifact hashes; it is not native GPU proof. FI Q1/capture, final G06 gates, G04/G05 original unresolved and G07-G10 remain intact.'])
(dest/'receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verdict=record['verdict'],candidate=head,native_binary_executions=29,new_apple_configs=48,new_vulkan_configs=24,steps_each=64,prior_failures=2,receipt=str(dest/'receipt.json'))))
