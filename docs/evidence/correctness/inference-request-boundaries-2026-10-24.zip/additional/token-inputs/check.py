from pathlib import Path
import importlib.util, json, sys, zipfile
sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[3]
D = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
before = D / 'before'; before.mkdir(parents=True,exist_ok=False)
old = R/'.scratch/mtp-request-unification-20261024/regression/current3/source/engine/models/qwen35/prefix_cache.h'
(before/'prefix_cache.h').write_bytes(old.read_bytes())
archive = R/'docs/evidence/correctness/inference-natural-requests-2026-10-24.zip'
with zipfile.ZipFile(archive) as z:
    (before/'qwen_prefix_cache_test.cc').write_bytes(z.read('canonical/tests/tools/qwen_prefix_cache_test.cc'))
b.save(before/'pins.json',[b.pin(p)for p in [old,archive]])
env=b.compile(D/'probe.cc',D/'compile')
image=b.link(D/'compile/unit.obj',D/'link',env)
env.update({k:v for k,v in b.read(b.CPU/'runtime-environment.json').items()if isinstance(v,str)})
b.execute([str(image)],D/'run',env,30)
b.save(D/'summary.json',{'state':'passed','scope':'Canonical prefix/cache tests including chunk-owned token input keys, actual aligned state pools, original Q35/Q27 budgets and allocation-free cache commits',
 'source':[b.pin(R/'engine/models/qwen35/prefix_cache.h'),b.pin(R/'tests/tools/qwen_prefix_cache_test.cc')],
 'SDK_builds':0,'model_execution':False,'HTTP':0})
print(json.dumps(b.read(D/'summary.json')))
