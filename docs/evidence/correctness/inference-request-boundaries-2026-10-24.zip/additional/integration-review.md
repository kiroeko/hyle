# 请求边界集成复审（只读）

- 当前 `engine/models/qwen35/main.cc`：`b06483f165e4ce51680187c20082e1ef687a30999591412d02d27c592923aa62`。
- 对照基线：`regression/current3/source/engine/models/qwen35/main.cc`（`.scratch/mtp-request-unification-20261024/`），SHA `1616e8c85571a60b35c3b6f0368f1345d6421e439f9a2b56812df398cc86aa5b`。
- 结论：本轮指定范围未发现实质新缺陷；以下为源码复审，不代替 agent3 的实际回归。未编译、运行或联网。

## 四处版本接纳

- `main.cc:4623` 自然单请求：selected 保存真实 Session 和 canonical state identity，fresh 为 null/null；requests 的 resident transform 只借用现有容器。`fits` 每次重新读取 live，目录一次淘汰后必重新查询，prefix-off 仍核真实容量，不擅自推断独占。
- `main.cc:4903` 自然批次：同一 helper 读取 calls/requests 的惰性视图；选中 canonical alias 去重、其他 Session/目录仍持有则不计释放。失败仍返回 false 供调用者缩批，未改成固定回放的抛错政策。
- `main.cc:6054` 固定 initial：fresh 只请求一个新 head，active episode 先拒绝；每次查询实时 live，目录淘汰不被假设为已释放一个版本。
- `main.cc:6069` 固定 batch：保留 stopped/failed/pending/head 守卫与 prefix-off 已证明 sole-owner 的原快路；prefix-on 才走 borrowed views，失败仍抛错。原 Model/Session 合法性和 native 退休门禁没有移入 helper 或被替代。
- helper 不保存 Session/Snapshot、不新建 vector/持有表、不扣第二份预算；这里的 transform/array 只在同步调用期间有效。查询期间无提交/Session 换头，evict 仅移除目录持有，selected 的 canonical 指针不会在该门禁内被换头失效。

## RequestProgress、轮次与观察者

- `request_progress.h` 仅组合 generated、借用 turns、轮索引/输出起点、初始采样身份与两个 host 标志；没有把当前 RNG、Snapshot、StateHead、lease 或 Graph 状态迁入公共进度对象。
- `main.cc:5240–5250` requests 在填充前 reserve 全部 schedule 数；turn span 借用 runner 外仍存活的 schedules。generated 的冷 reserve 与旧构造相同，不多拷贝 token；warm_inputs/history/round_emitted 的原 owning 容器和保留策略未变。
- `main.cc:5399–5405` 先恢复真实完整 head、写入上一轮 pending，再选择 warm input 并 begin_turn；begin_turn 仅重置 prefilled/turn_done/output_begin，保留累计输出、轮索引和原模型采样 cursor。
- `main.cc:4566–4614` observer 的 ledger_observed 单调消费与用户输出/导入记录分支保持原顺序；本轮只是字段限定到 progress。已提交 head/ledger 仍为事实源，晚诊断 IO 不重抽样、不重复发布。`main.cc:4924` full-hit 一次观察门禁仍在。
- `main.cc:5456–5463` 完成 checkpoint 发布后才移出 active 并递增 turn_index；没有让上一轮尚未观察的记录归入下一轮。单请求未新增 hash、Tensor 转换、Graph 调用或 CPU 数据往返；原 controller 已存在的临时 vector/map 不据此宣称全部消除。

## 模型与 Graph 定向对照

- 从 `struct Recipe final` 至 `struct GenerationRequest` 前的完整区块，统一换行后的文本 **247,921 B 完全相同**，SHA `92d865348fee207e9c3d05eac83f6f56a58dc8576fde3cb76491be8488b6a47c`。
- 该范围包含 Recipe 投影/数学、Model、prepare_evaluations、propose_recursive、finish_recursive_mtp、finish_evaluations 及原 prepare/submit/wait/finish；未把 progress 误迁入模型、Graph ports、采样或提交事务。
- 固定 runner 在接纳 helper 之后的正文亦与基线完全相同（38,997 B，SHA `73b7610bb2ac970760001472309ceeca0fff07aed72b86b3c98ea6dab225dd82`）。
- 配套 prefix token_plan 仅从 Phase 依赖改为 chunks/单 span：原顺序、hash、累计长度、checkpoint 边界与冷 reserve 保持；main 自然首 prompt 及 fixed 各 phase 按原顺序提供同一组 ids。新增 fixed chunks vector 仅启动预备，未进入 token 热路径。

边界：helper 依赖现 caller 的完整 resident/目录事实及串行门禁，不承诺识别调用范围外任意 escaped owners；原 Graph/Compute reader/退休保护仍保持。未由这次静态检查宣称整体架构完成或性能提高。
