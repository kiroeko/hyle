from pathlib import Path
import hashlib, json, zipfile
R = Path(__file__).resolve().parents[2]
D = Path(__file__).resolve().parent
O = R/'docs/evidence/correctness'
name = 'inference-request-boundaries-2026-10-24'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return {'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
regression=read(D/'regression/proof-summary.json')
admission=read(D/'check2/summary.json')
progress=read(D/'parser1/summary.json')
tokens=read(D/'token-inputs/summary.json')
assert all(x['state']=='passed'for x in[regression,admission,progress,tokens])
for key,relative in [('current_main','engine/models/qwen35/main.cc'),
    ('shared_request_progress','engine/inference/request_progress.h'),
    ('shared_admission','engine/inference/version_admission.h'),
    ('token_plan','engine/models/qwen35/prefix_cache.h')]:
    assert pin(R/relative)['sha256']==regression[key]['sha256']
archive=O/(name+'.zip');assert not archive.exists()
suffixes={'.cc','.h','.py','.md','.json','.log','.patch','.diff','.txt','.ps1','.ids'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
    with zipfile.ZipFile(D/'regression/proof.zip')as original:
        for item in original.infolist():
            assert not item.is_dir()and Path(item.filename).suffix in suffixes
            out.writestr('regression/'+item.filename,original.read(item))
    for folder in ['token-inputs','check1','check2','parser1','main-syntax1']:
        for p in sorted((D/folder).rglob('*')):
            if p.is_file()and p.suffix in suffixes:out.write(p,'additional/'+p.relative_to(D).as_posix())
    for p in [D/'integration-review.md',D/'before-pins.json',D/'after-pins.json',D/'changes.patch',D/'publish.py']:
        out.write(p,'additional/'+p.relative_to(D).as_posix())
    for relative in ['engine/inference/request_progress.h','engine/inference/version_admission.h',
        'engine/models/qwen35/prefix_cache.h','tests/tools/qwen_prefix_cache_test.cc',
        'tests/tools/qwen_generation_schedule_test.cc','tests/tools/inference_version_admission_test.cc','tests/CMakeLists.txt']:
        out.write(R/relative,'canonical/'+relative)
report={
 'state':'passed','date':'2026-10-24',
 'scope':'Shared host request progress, schema-independent token input plans and common retained-version admission; finite Windows CPU/Vulkan checks, not whole-architecture completion.',
 'changes':[
  'GenerationTurn and GenerationSessionSchedule belong to hyle::inference. Qwen Request composes host RequestProgress; no old namespace aliases.',
  'Host progress borrows stable turns and preserves existing cold output reserve. Authoritative model head, journal, RNG advancement and MTP repair stay in their original layer.',
  'One allocation-free borrowed-facts version query replaces natural single/batch and fixed initial/batch duplicate calculations; original caller retirement/sole-owner/eviction/error policies retained.',
  'TokenPlan copies actual token chunks independently of benchmark Phase; fixed tape converts its validated phase spans only during cold input preparation.'
 ],
 'request_progress_and_grammar':progress,'version_admission':admission,'token_input_cache_and_pool':tokens,
 'actual_natural_and_fixed_consumers':regression,
 'source_review':{
   'path':pin(D/'integration-review.md'),
   'math_and_Graph_unchanged_bytes':247921,
   'math_and_Graph_unchanged_sha256':'92d865348fee207e9c3d05eac83f6f56a58dc8576fde3cb76491be8488b6a47c',
   'fixed_body_after_admission_unchanged_bytes':38997,
   'fixed_body_after_admission_unchanged_sha256':'73b7610bb2ac970760001472309ceeca0fff07aed72b86b3c98ea6dab225dd82'
 },
 'limitations':[
  'Version query consumes complete serialized caller ownership/retainer facts; it does not discover arbitrary escaped owners or authorize native retirement.',
  'Actual consumer uses original small untrained A-only fixture. No trained-model quality/TPS/memory improvement or all-platform claim.',
  'Host request/report separation, model math/prepared-state separation and cross-family generation adapters remain unfinished.',
  'New standard-library-only test target registered in CMake; manual strict compilation/run passed, CMake registration not reconfigured.'
 ],
 'SDK_builds':0,'downloads_bytes':0,'HTTP_requests':0,
 'archive':pin(archive),
 'cleanup':'Rebuildable check objects/images will be removed via root test.ps1; source, commands, results and previous corrected production native cache retained.'
}
(O/(name+'.json')).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps({'report':pin(O/(name+'.json')),'archive':pin(archive)}))
