"""Compact finite architecture regression proof; no weights, executables or SDK."""
from pathlib import Path
import hashlib,json,zipfile
D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
result=read(D/'summary.json');assert result['state']=='passed'and not result['differences']
fixed=next(row for row in result['reports']if row.get('execution')=='equal_T_batched')
folder=D/'output/fixed'
save(D/'fixed-cli-arguments.json',dict(kind='In-process qwen35::run, not a second process or inference server',
  origin='Derived exactly from the frozen probe.cc and actual private output directory; actual success/geometry comes from raw report.',
  arguments=['private-fixed-replay','--inputs',str(folder),'--backend','vulkan','--mtp','off','--capacity','16','--max-sessions','2','--active-sequences','2','--cache-bytes','16777216','--prefix-cache','auto','--replay','commands','--session-schedules',str(folder/'sessions.txt')]))
summary=dict(state='passed',scope='Finite behavior-preserving host RequestProgress/turn schema/token-plan factory/version-admission migration, one current consumer TU and one actual process.',
  current_main=pin(D/'source/engine/models/qwen35/main.cc'),shared_request_progress=pin(D/'source/engine/inference/request_progress.h'),shared_admission=pin(D/'source/engine/inference/version_admission.h'),token_plan=pin(D/'source/engine/models/qwen35/prefix_cache.h'),
  previous_main=pin(D/'reference/main.cc'),baseline_reports=pin(D/'reference/reports.json'),complete_postrun_audit=pin(D/'summary.json'),image=pin(D/'link/probe.exe'),
  comparison=dict(existing_non_timing_report_fields_equal=True,committed_ledgers_math_RNG_geometry_and_resource_counts_equal=True,differences=0,added_fields=len(result['added_report_fields']),
    natural_Text='Same4 users x2 turns/N2R2/quota3+2/20 outputs/full+partial prefix/idle eviction+rebuild/pending journal; previous actual generated IDs and draw5 each unchanged.',
    MTP='Same natural2 users/N2R2/K2/4 outputs each; complete committed ledgers, outputs, draw10, actual dispatch and geometry unchanged.',
    greedy_and_late_IO='Same historicalpending vs canonical freshTop1 and both Graph-postcommit/host-fullhit-postcommit IO failure repeat-observation/repeat-call invariants unchanged.'),
  fixed_CLI=dict(scope='Wiring/resource check only; no old fixed numerical comparison.',actual_report=fixed,consumed_inputs=[1,2,3,4,5],users=2,per_user_consumed=5,actual_R2_batches=4,participations=8,prefix='auto',N=2,R=2,mtp=False,greedy=True),
  compile=result['compile'],link=result['link'],run=result['run'],compiled_private_TUs=1,actual_processes=1,old_versions_built=0,SDK_builds=0,HTTP=0,model_downloads=0,weight_payload_copies=0,
  original_corrected_closure=read(D/'baseline-pins.json')['closure'],quality_claim=False,performance_claim=False)
save(D/'proof-summary.json',summary)
files=[]
with zipfile.ZipFile(D/'proof.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in D.rglob('*'):
    if p.is_file()and p.suffix.lower()in{'.cc','.h','.py','.json','.log','.diff','.patch','.md','.txt','.ids'}and p.name!='proof-pins.json':
      z.write(p,p.relative_to(D).as_posix());files.append(p.relative_to(D).as_posix())
pins=dict(state='passed',summary=pin(D/'proof-summary.json'),postrun=pin(D/'summary.json'),archive=pin(D/'proof.zip'),files=len(files),excluded=['weight payloads/manifests','obj/exe/pdb/lib/dll','SDK'],current_TUs=1,current_runs=1,old_builds=0,SDK_builds=0,HTTP=0)
save(D/'proof-pins.json',pins);print(json.dumps(pins),flush=True)
