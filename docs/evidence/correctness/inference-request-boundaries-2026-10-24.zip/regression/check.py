"""One finite current consumer against the previous successful actual reports."""
from pathlib import Path
import importlib.util,json,os,shutil,sys,zipfile
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
BASE=R/'.scratch/mtp-request-unification-20261024/regression'
FIXTURE=R/'.scratch/mtp-runtime-backend-20261024/verification1/tiny-run/fixture'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def require(ok,message):
    if not ok:raise ValueError(message)
def prepare():
    expected={'summary.json':'0133767464805cf6f261765fef368bf5296b09feac1d8a305f00094f3d53f156',
      'proof-summary.json':'11a302a93ffb33e13a205eb13fa8446a187f4560cda41fae5817eca1dafda42f'}
    for name,sha in expected.items():require(b.pin(BASE/name)['sha256']==sha,'Previous successful finite evidence changed: '+name)
    target=D/'reference';target.mkdir(parents=True,exist_ok=False)
    originals=[BASE/'current4/reports.json',BASE/'current3/source/engine/models/qwen35/main.cc',BASE/'summary.json',BASE/'proof-summary.json',BASE/'current4/link/command.json',BASE/'current4/link/pins.json']
    names=['reports.json','main.cc','postrun-summary.json','proof-summary.json','link-command.json','link-pins.json'];records=[]
    for p,name in zip(originals,names):
        out=target/name;out.write_bytes(p.read_bytes());records.append(dict(original=b.pin(p),frozen=b.pin(out)))
    require(b.pin(target/'main.cc')['sha256']=='1616e8c85571a60b35c3b6f0368f1345d6421e439f9a2b56812df398cc86aa5b','Wrong successful shared-run baseline main')
    probe=(BASE/'current3/source/probe.cc').read_text(encoding='utf8')
    before='const std::array phases{q::benchmark::Phase{q::benchmark::PhaseKind::kPrompt,schedule.turns.front().prompt,1}};\n    result.push_back(q::cache::token_plan(phases,16));'
    require(probe.count(before)==1,'Unexpected original prompt token factory')
    probe=probe.replace(before,'result.push_back(q::cache::token_plan(schedule.turns.front().prompt,16));')
    before='const std::array phases{q::benchmark::Phase{q::benchmark::PhaseKind::kPrompt,*owner,1}};\n    const auto input=q::cache::token_plan(phases,16);'
    require(probe.count(before)==1,'Unexpected original full-hit token factory')
    probe=probe.replace(before,'const auto input=q::cache::token_plan(*owner,16);')
    with(D/'probe.cc').open('x',encoding='utf8',newline='\n')as out:out.write(probe)
    b.save(D/'baseline-pins.json',dict(scope='Previous actual successful current4 reports only; no unchangedold24c or capacity-only re-execution.',files=records,fixture=[b.pin(p)for p in FIXTURE.glob('*')if p.is_file()],closure=dict(route=b.pin(BASE/'native-program-fixed/archive/route.lib'),native_region=b.pin(BASE/'native-region-fixed2/compile/unit.obj')),current_compiles=0,current_runs=0,SDK_builds=0,HTTP=0))
def freeze():
    target=D/'source';target.mkdir(parents=True,exist_ok=False);records=[]
    for p in[R/'engine/models/qwen35/main.cc',*(R/'engine/models/qwen35').glob('*.h'),*(R/'engine/inference').glob('*.h')]:
        out=target/p.relative_to(R);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes());records.append(dict(original=b.pin(p),frozen=b.pin(out)))
    shutil.copyfile(D/'probe.cc',target/'probe.cc');records.append(dict(original=b.pin(D/'probe.cc'),frozen=b.pin(target/'probe.cc')))
    b.save(D/'source-pins.json',records)
def build():
    target=D/'source';folder=D/'compile';original=b.args(BASE/'current3/compile/command.json');command=[original[0],'/I'+str(target)];skip=False
    for word in original[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        lower=word.lower().replace('\\','/')
        if lower.startswith(('/fo','/fd'))or lower.endswith(('.cc','.cpp')):continue
        if lower.startswith('/i')and '/.scratch/'in lower and lower.endswith('/source'):continue
        command.append(word)
    command+=['/sourceDependencies',str(folder/'dependencies.json'),str(target/'probe.cc'),'/Fo'+str(folder/'unit.obj'),'/Fd'+str(folder/'unit.pdb')]
    env=b.environment(command[0]);b.execute(command,folder,env,180)
    deps=[Path(p).resolve()for p in b.read(folder/'dependencies.json')['Data']['Includes']]
    leaks=[str(p)for p in deps if p.is_relative_to(R/'engine')or(p.is_relative_to(R/'.scratch')and not p.is_relative_to(target))]
    require(not leaks,'Frozen engine/private headers leaked: '+repr(leaks))
    pins=[b.pin(p)for p in deps if p.is_relative_to(R)];b.save(folder/'self-header-pins.json',pins)
    prior={p['path'].lower():p for p in b.read(BASE/'current3/compile/self-header-pins.json')if Path(p['path']).is_relative_to(R/'include')}
    require(all(p['path'].lower()in prior and all(p[k]==prior[p['path'].lower()][k]for k in['bytes','sha256'])for p in pins if Path(p['path']).is_relative_to(R/'include')),'Public ABI inputs changed; inspect corrected retained closure before link')
    previous=b.args(D/'reference/link-command.json');old=str(BASE/'current3/compile/unit.obj');require(previous.count(old)==1,'Previous cleaned app entry is not uniquely recorded')
    out=D/'link';link=[str(folder/'unit.obj')if word==old else word for word in previous if not word.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
    link+=['/OUT:'+str(out/'probe.exe'),'/PDB:'+str(out/'probe.pdb')];b.execute(link,out,env,120)
    for native in b.read(D/'reference/link-pins.json').get('native',[]):
        path=Path(native['path']);os.link(path,out/path.name)
    # current4 pins records individual corrected objects, its actual native DLL
    # is the same small finite Vulkan runtime used in the previous link folder.
    if not list(out.glob('*.dll')):
        for path in(BASE/'current4/link').glob('*.dll'):os.link(path,out/path.name)
    b.save(out/'pins.json',dict(image=b.pin(out/'probe.exe'),object=b.pin(folder/'unit.obj'),baseline_link=b.pin(D/'reference/link-command.json'),native=[b.pin(p)for p in out.glob('*.dll')],SDK_builds=0))
def run():
    env=b.environment(b.args(D/'compile/command.json')[0]);env.update({k:v for k,v in b.read(b.VK/'runtime.json').items()if isinstance(v,str)})
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1');env['PATH']=str(D/'link')+';'+env['PATH']
    for row in b.read(D/'baseline-pins.json')['fixture']:
        now=b.pin(Path(row['path']));require(all(now[k]==row[k]for k in['bytes','sha256']),'Pinned cached A fixture changed')
    b.execute([str(D/'link/probe.exe'),str(FIXTURE/'weights.tsv'),str(D/'output')],D/'run',env,90)
    audit()
def audit():
    actual=[json.loads(line)for line in(D/'run/stdout.log').read_text().splitlines()if line.startswith('{')];expected=b.read(D/'reference/reports.json')
    markers=[i for i,row in enumerate(actual)if row.get('private_fixed_begin')]
    require(markers==[len(expected)],'Natural reports and fixed CLI scope boundary are not exact')
    natural=actual[:markers[0]];fixed=[row for row in actual[markers[0]+1:]if row.get('execution')=='equal_T_batched']
    require(len(fixed)==1,'Actual fixed replay multi-session report missing')
    fixed=fixed[0]
    for key,value in dict(session_count=2,processed_tokens=10,generated_tokens=8,graph_participations=8,actual_graph_calls=4,max_batch_requests=2,max_cached_sessions=2,active_sequences=2,effective_cache_sessions=2,cache_committed_version_limit=2).items():
        require(fixed.get(key)==value,'Fixed CLI actual count/geometry differs: '+key)
    require(fixed['cache_peak_committed_versions']<=2 and fixed['cache_live_snapshot_versions']<=2,'Fixed CLI exceeds actual committed-version N')
    require(len(fixed['batches'])==4 and all(row['requests']==2 and not row['restore']for row in fixed['batches']),'Fixed replay did not execute four actual R2 batches')
    require([row['kind']for row in fixed['batches']]==['prefill','decode','prefill','decode']and[row['query_rows']for row in fixed['batches']]==[2,1,1,1],'Fixed tape was reinterpreted into natural generation shapes')
    require({row['session_id']for row in fixed['sessions']}=={'f0','f1'},'Fixed CLI session identities differ')
    for row in fixed['sessions']:
        require(row['fixed_decode']and row['processed_tokens']==row['visible_tokens']==5 and row['decode_input_ids']==[3,5]and row['phase_count']==4 and row['turn_count']==2 and row['graph_participations']==4,'Fixed CLI did not consume exactly original input tape5 rows')
    ignored=[];additions=[];differences=[]
    def compare(before,after,path):
        if isinstance(before,dict):
            if not isinstance(after,dict):differences.append(path+':type');return
            additions.extend(path+'.'+k for k in after.keys()-before.keys())
            for key,value in before.items():
                child=path+'.'+key
                if key.endswith('_seconds')or'tokens_per_second'in key:ignored.append(child);continue
                if key not in after:differences.append(child+':missing');continue
                compare(value,after[key],child)
        elif isinstance(before,list):
            if not isinstance(after,list)or len(before)!=len(after):differences.append(path+':length/type');return
            for i,(left,right)in enumerate(zip(before,after)):compare(left,right,path+'['+str(i)+']')
        elif before!=after:differences.append(path+':'+repr(before)+' -> '+repr(after))
    compare(expected,natural,'reports')
    summary=dict(state='passed'if not differences else'failed_comparison',scope='One identical finite natural Text4x2 N2/R2+full/partial prefix+greedy recovery/lateIO+MTP K2/R2 consumer against previous successful actual reports, plus fixed CLI two-session original tape wiring/resource check.',baseline=b.pin(D/'reference/reports.json'),differences=differences,ignored_timing_fields=ignored,added_report_fields=additions,exact_existing_non_timing_report_fields_equal=not differences,committed_ledgers_math_RNG_geometry_equal=not differences,fixed_CLI=dict(scope='Actual wiring/resource only, no old fixed numerical baseline claim',original_consumed_ids=[1,2,3,4,5],actual_R2_batches=4,graph_participations=8,per_user_consumed=5,N=2,R=2,prefix='auto',mtp=False),reports=actual,compile=b.read(D/'compile/process.json'),link=b.read(D/'link/process.json'),run=b.read(D/'run/process.json'),compiled_private_TUs=1,actual_processes=1,SDK_builds=0,HTTP=0,quality_claim=False,performance_claim=False)
    b.save(D/'summary.json',summary);require(not differences,'Preserved actual non-timing report mismatch: '+repr(differences[:8]))
    print(json.dumps(dict(state='passed',summary=b.pin(D/'summary.json'))),flush=True)
if __name__=='__main__':{'prepare':prepare,'freeze':freeze,'build':build,'run':run,'audit':audit}[sys.argv[1]]()
