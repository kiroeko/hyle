#pragma once

#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

#include "sampling_cursor.h"

namespace hyle::inference {

struct GenerationTurn final {
  std::vector<std::int32_t> prompt;
  std::size_t max_outputs = 0;
};

struct GenerationSessionSchedule final {
  std::string id;
  std::vector<GenerationTurn> turns;
};

// Host progress only. The schedule owner outlives this borrowed turn span.
// The model's committed head/ledger remains authoritative for its next cursor;
// initial_sampling identifies a new request, not a second mutable RNG state.
struct RequestProgress final {
  std::vector<std::int32_t> generated;
  std::span<const GenerationTurn> turns{};
  std::size_t turn_index = 0, turn_output_begin = 0;
  SamplingCursor initial_sampling{};
  bool prefilled = false, turn_done = false;

  explicit RequestProgress(std::size_t maximum_outputs) {
    generated.reserve(maximum_outputs);
  }

  void begin_turn() noexcept {
    prefilled = false;
    turn_done = false;
    turn_output_begin = generated.size();
  }
};

} // namespace hyle::inference
