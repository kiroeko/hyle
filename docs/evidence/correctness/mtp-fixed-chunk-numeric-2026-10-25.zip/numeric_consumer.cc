#include <hyle/compute/batch_execution.h>
#include <hyle/compute/backends/cuda.h>
#include <hyle/compute/cuda.h>
#include <hyle/compute/providers/flashinfer.h>
#include <hyle/graph/batch.h>
#include <hyle/graph/cuda.h>
#include <hyle/simd/dtype.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <vector>

#if !defined(HYLE_COMPUTE_FLASHINFER)
#error public CUDA batch consumer requires qualified FlashInfer
#endif

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace gb = g::batch;
using hyle::Status;
Status check(bool value, const char *message) {
  return value ? Status::Ok() : Status::Internal(message);
}
std::uint16_t encode(float value, bool bf16) {
  return bf16 ? hyle::simd::f32_to_bf16(value).bits
              : hyle::simd::f32_to_f16(value).bits;
}
float decode(std::uint16_t value, bool bf16) {
  return bf16 ? hyle::simd::bf16_to_f32({value})
              : hyle::simd::f16_to_f32({value});
}
hyle::Result<c::ReadLease> load(c::LeasePool &pool,
                              std::span<const std::uint16_t> words) {
  HYLE_ASSIGN_OR_RETURN(auto writer, pool.allocate(words.size_bytes()));
  HYLE_RETURN_IF_ERROR(writer.view()->write(std::as_bytes(words)));
  return writer.publish();
}
Status oracle(const c::BatchCapacity &cap, const c::BatchLayoutVersion &layout,
              const std::vector<std::uint16_t> &q,
              const std::vector<std::uint16_t> &k,
              const std::vector<std::uint16_t> &v,
              const c::ReadLease &output, bool bf16) {
  std::vector<std::uint16_t> result(q.size());
  HYLE_RETURN_IF_ERROR(output.view()->read(std::as_writable_bytes(std::span(result))));
  const auto host = layout.host();
  double maximum = 0;
  for (unsigned r = 0; r < layout.facts().requests; ++r) {
    const int qlen = host.query_indptr[r + 1] - host.query_indptr[r];
    const int count = host.kv_indptr[r + 1] - host.kv_indptr[r];
    const int kvlen = cap.storage == c::BatchStorage::kPaged
                          ? (count - 1) * int(cap.page_size) + host.last_page_lengths[r]
                          : count;
    const auto row = [&](int i) {
      return cap.storage == c::BatchStorage::kPaged
                 ? host.page_indices[host.kv_indptr[r] + i / cap.page_size] *
                           int(cap.page_size) + i % cap.page_size
                 : host.kv_indptr[r] + i;
    };
    for (int qi = 0; qi < qlen; ++qi) {
      for (unsigned h = 0; h < cap.query_heads; ++h) {
        const int valid = kvlen - qlen + qi + 1;
        std::vector<double> scores(valid);
        double high = -1e100, sum = 0;
        const auto qbase = ((host.query_indptr[r] + qi) * cap.query_heads + h) * cap.qk_head_dim;
        const auto kvbase = [&](int i) {
          return (row(i) * cap.kv_heads + h / (cap.query_heads / cap.kv_heads)) * cap.qk_head_dim;
        };
        for (int i = 0; i < valid; ++i) {
          double dot = 0;
          for (unsigned d = 0; d < cap.qk_head_dim; ++d)
            dot += double(decode(q[qbase + d], bf16)) * decode(k[kvbase(i) + d], bf16);
          scores[i] = dot / std::sqrt(double(cap.qk_head_dim));
          high = std::max(high, scores[i]);
        }
        for (auto &value : scores) { value = std::exp(value - high); sum += value; }
        for (unsigned d = 0; d < cap.qk_head_dim; ++d) {
          double expected = 0;
          for (int i = 0; i < valid; ++i)
            expected += scores[i] / sum * decode(v[kvbase(i) + d], bf16);
          const double error = std::abs(decode(result[qbase + d], bf16) - expected);
          maximum = std::max(maximum, error);
          HYLE_RETURN_IF_ERROR(check(std::isfinite(error) && error < .007,
                                    "public CUDA independent attention oracle differs"));
        }
      }
    }
  }
  std::printf("public CUDA nonuniform oracle maxError=%.9g PASS\n", maximum);
  return Status::Ok();
}
Status record_output(const c::ReadLease &output, unsigned query_rows, unsigned kv_rows, const char *kind) {
  std::vector<std::uint16_t> words(query_rows*8u*256u);
  HYLE_RETURN_IF_ERROR(output.view()->read(std::as_writable_bytes(std::span(words))));
  char name[128]{};
  std::snprintf(name,sizeof(name),"output-Q%u-KV%u-%s.bf16",query_rows,kv_rows,kind);
  std::FILE *file=nullptr;
  if(fopen_s(&file,name,"wb") || !file) return Status::Internal("numeric output file open failed");
  const auto written=std::fwrite(words.data(),sizeof(words[0]),words.size(),file);
  const auto closed=std::fclose(file);
  return check(written==words.size() && closed==0,"numeric output file write failed");
}
Status exercise(unsigned query_rows, unsigned kv_rows) {
  constexpr bool paged = true, bf16 = true;
  constexpr unsigned page = 16, query_heads = 8, kv_heads = 2, depth = 256;
  const unsigned pages = kv_rows / page + (kv_rows % page != 0);
  std::printf("episode R1 Q%u KV%u H8/KV2 D256 page16 causal window-1 BF16 F32partials\n", query_rows, kv_rows);
  const c::BatchCapacity cap{
      .storage=c::BatchStorage::kPaged,
      .query_type=c::DataType::kBFloat16,.output_type=c::DataType::kBFloat16,
      .key_storage=c::CacheStorage::plain(c::DataType::kBFloat16).value(),
      .value_storage=c::CacheStorage::plain(c::DataType::kBFloat16).value(),
      .max_requests=1,.max_query_rows=query_rows,.max_kv_rows=pages*page,
      .max_pages=pages+1,.max_page_refs=pages,
      .query_heads=query_heads,.kv_heads=kv_heads,.qk_head_dim=depth,.value_head_dim=depth,
      .page_size=page};
  HYLE_ASSIGN_OR_RETURN(auto schema, c::BatchSchema::create(cap));
  const std::array<std::int32_t,2> qptr{0,static_cast<std::int32_t>(query_rows)},
      kvptr{0,static_cast<std::int32_t>(pages)};
  std::vector<std::int32_t> ids(pages);
  for(unsigned i=0;i<pages;++i) ids[i]=static_cast<std::int32_t>(pages-i);
  const std::array<std::int32_t,1> tails{static_cast<std::int32_t>((kv_rows-1)%page+1)};
  HYLE_ASSIGN_OR_RETURN(auto layout, schema.version({qptr,kvptr,ids,tails}));
  const c::BatchProgramOptions options{
      .resource={},
      .max_float_workspace_bytes = 8u << 20, .max_int_workspace_bytes = 64u << 10,
      .max_invocations = 2, .scale = 1.f / std::sqrt(float(depth))};
  HYLE_ASSIGN_OR_RETURN(auto context, g::cuda::create_context());
  HYLE_ASSIGN_OR_RETURN(auto queue, context.create_queue());
  HYLE_ASSIGN_OR_RETURN(auto device, c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice));
  HYLE_ASSIGN_OR_RETURN(auto host, c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kPinnedHost));
  struct Drain { c::Context &context; ~Drain() { context.drain().IgnoreError(); } } drain{context};
  auto direct_options = options;
  direct_options.resource = device.ref();
  direct_options.host_workspace = host.ref();
  HYLE_ASSIGN_OR_RETURN(auto program, c::BatchProgram::prepare(context, schema, direct_options));
  HYLE_ASSIGN_OR_RETURN(auto direct, c::BatchInvocation::create(program, queue));
  std::vector<std::uint16_t> q(cap.max_query_rows * cap.query_heads * depth);
  std::vector<std::uint16_t> k((paged ? cap.max_pages * page : cap.max_kv_rows) * cap.kv_heads * depth), v(k.size());
  for (unsigned i = 0; i < q.size(); ++i) q[i] = encode(.2f * std::sin(float(i) * .017f), bf16);
  // Poison the unused whole physical page and all unused tail rows. Only
  // logical valid rows are initialized; reverse page order is intentional.
  std::fill(k.begin(),k.end(),std::uint16_t{0x7fc0});
  std::fill(v.begin(),v.end(),std::uint16_t{0x7fc0});
  for(unsigned row=0;row<kv_rows;++row) for(unsigned h=0;h<kv_heads;++h)
    for(unsigned d=0;d<depth;++d) {
      const auto logical=(row*kv_heads+h)*depth+d;
      const auto physical=(static_cast<unsigned>(ids[row/page])*page+row%page)*kv_heads*depth+h*depth+d;
      k[physical]=encode(.3f*std::cos(float(logical)*.019f),bf16);
      v[physical]=encode(std::sin(float(logical)*.013f)+float(logical%11)*.01f,bf16);
      // Make the last valid row a visible causal-mask witness for Q2.
      if(row+1==kv_rows){ k[physical]=encode(0.f,bf16); v[physical]=encode(8.f+float(d%8)*.125f,bf16); }
    }
  HYLE_ASSIGN_OR_RETURN(auto pool, c::LeasePool::create(device.ref(), (q.size() * 3 + k.size() + v.size()) * 2 + 4096));
  HYLE_ASSIGN_OR_RETURN(auto rq, load(pool, q));
  HYLE_ASSIGN_OR_RETURN(auto rk, load(pool, k));
  HYLE_ASSIGN_OR_RETURN(auto rv, load(pool, v));
  const std::array leases{rq, rk, rv};
  HYLE_ASSIGN_OR_RETURN(auto prepared, direct.prepare_batch(layout));
#if defined(HYLE_G06_CAPTURE_REPLAY)
  HYLE_RETURN_IF_ERROR(prepared.prepare_replay(leases));
  HYLE_RETURN_IF_ERROR(check(direct.report().capture_compatible,"public Direct batch capture not prepared"));
#endif
  HYLE_ASSIGN_OR_RETURN(auto done, prepared.run(leases));
  HYLE_RETURN_IF_ERROR(done.wait());
  HYLE_ASSIGN_OR_RETURN(auto direct_output, direct.output());
  HYLE_RETURN_IF_ERROR(oracle(cap, layout, q, k, v, direct_output, bf16));
  HYLE_RETURN_IF_ERROR(record_output(direct_output, query_rows, kv_rows, "direct"));
  HYLE_RETURN_IF_ERROR(check(!direct.prepare_batch(layout), "public Direct old output allowed overwrite"));
  HYLE_RETURN_IF_ERROR(check(direct.report().layout_generation == layout.generation(), "public Direct mirror generation differs"));

  HYLE_ASSIGN_OR_RETURN(auto qdesc, c::TensorDesc::dense(cap.query_type, std::array<std::int64_t, 3>{cap.max_query_rows, cap.query_heads, depth}));
  c::TensorDesc kvdesc;
  if (paged) { HYLE_ASSIGN_OR_RETURN(kvdesc, c::TensorDesc::dense(cap.query_type, std::array<std::int64_t, 4>{cap.max_pages, page, cap.kv_heads, depth})); }
  else { HYLE_ASSIGN_OR_RETURN(kvdesc, c::TensorDesc::dense(cap.query_type, std::array<std::int64_t, 3>{cap.max_kv_rows, cap.kv_heads, depth})); }
  HYLE_ASSIGN_OR_RETURN(auto metadata_desc, schema.metadata_description());
  const std::array descriptions{qdesc, kvdesc, kvdesc, metadata_desc};
  HYLE_ASSIGN_OR_RETURN(auto builder, g::GraphBuilder::create());
  std::array<g::ValueId, 4> inputs;
  for (unsigned i = 0; i < inputs.size(); ++i) { HYLE_ASSIGN_OR_RETURN(inputs[i], builder.input(descriptions[i])); }
  const auto operation = paged ? c::Operation::custom(c::PagedAttention{cap, options.scale})
                               : c::Operation::custom(c::RaggedAttention{cap, options.scale});
  HYLE_ASSIGN_OR_RETURN(auto node, builder.add_node(operation, inputs));
  HYLE_ASSIGN_OR_RETURN(auto output_id, builder.result(node));
  HYLE_RETURN_IF_ERROR(builder.publish(output_id));
  HYLE_ASSIGN_OR_RETURN(auto second_node, builder.add_node(operation, inputs));
  HYLE_ASSIGN_OR_RETURN(auto second_output_id, builder.result(second_node));
  HYLE_RETURN_IF_ERROR(builder.publish(second_output_id));
  HYLE_ASSIGN_OR_RETURN(auto graph, std::move(builder).finish());
  HYLE_ASSIGN_OR_RETURN(auto compiled, g::cuda::compile(graph, context, device.ref(), {.operation_fallback = g::OperationFallbackPolicy::kReject}));
  HYLE_ASSIGN_OR_RETURN(auto invocation, compiled.executable.create_invocation({.resources=g::ResourceOptions{}}));
  const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
  const std::array layouts{gb::NodeLayout{node, layout},gb::NodeLayout{second_node,layout}};
  const gb::PrepareOptions preparation{.host_workspace=host.ref(),
      .max_float_workspace_bytes=options.max_float_workspace_bytes,
      .max_int_workspace_bytes=options.max_int_workspace_bytes};
  HYLE_RETURN_IF_ERROR(gb::prepare(invocation,queues,layouts,preparation));
  for (unsigned i = 0; i < leases.size(); ++i) HYLE_RETURN_IF_ERROR(invocation.bind(inputs[i], descriptions[i], leases[i]));
  HYLE_ASSIGN_OR_RETURN(auto writer, pool.allocate(q.size() * 2));
  HYLE_RETURN_IF_ERROR(invocation.bind(output_id, qdesc, std::move(writer)));
  HYLE_ASSIGN_OR_RETURN(auto second_writer, pool.allocate(q.size() * 2));
  HYLE_RETURN_IF_ERROR(invocation.bind(second_output_id, qdesc, std::move(second_writer)));
#if defined(HYLE_G06_CAPTURE_REPLAY)
  HYLE_RETURN_IF_ERROR(gb::prepare_replay(invocation,queues));
#endif
  HYLE_RETURN_IF_ERROR(invocation.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kReject}));
  HYLE_ASSIGN_OR_RETURN(auto graph_done, invocation.submit(queues));
  HYLE_RETURN_IF_ERROR(graph_done.wait());
  HYLE_ASSIGN_OR_RETURN(auto report, gb::report(invocation,node));
  HYLE_ASSIGN_OR_RETURN(auto second_report, gb::report(invocation,second_node));
  HYLE_RETURN_IF_ERROR(check(second_report.metadata_staging_bytes==0,
      "shared Graph metadata was uploaded a second time"));
  HYLE_ASSIGN_OR_RETURN(auto graph_output, invocation.result(output_id));
  HYLE_ASSIGN_OR_RETURN(auto result, graph_output.storage_lease());
  HYLE_RETURN_IF_ERROR(oracle(cap, layout, q, k, v, result, bf16));
  HYLE_RETURN_IF_ERROR(record_output(result, query_rows, kv_rows, "graph0"));
  HYLE_ASSIGN_OR_RETURN(auto second_graph_output, invocation.result(second_output_id));
  HYLE_ASSIGN_OR_RETURN(auto second_result, second_graph_output.storage_lease());
  HYLE_RETURN_IF_ERROR(oracle(cap, layout, q, k, v, second_result, bf16));
  HYLE_RETURN_IF_ERROR(record_output(second_result, query_rows, kv_rows, "graph1"));
  HYLE_RETURN_IF_ERROR(check(!gb::prepare(invocation,queues,layouts,preparation).ok(), "public Graph old output allowed overwrite"));
  HYLE_RETURN_IF_ERROR(check(report.layout_generation == layout.generation(), "public Graph mirror generation differs"));
  HYLE_RETURN_IF_ERROR(check(direct.report().cta_tile_q!=0 && report.cta_tile_q!=0 && second_report.cta_tile_q!=0,
      "numeric consumer did not obtain actual native batch plans"));
  HYLE_RETURN_IF_ERROR(check(!direct.report().bf16_partials && !report.bf16_partials && !second_report.bf16_partials,
      "numeric consumer unexpectedly enabled BF16 partials"));
  std::printf("native reports Q%u KV%u Direct CTA%u split%d Graph0 CTA%u split%d Graph1 CTA%u split%d fallback=reject old-leases=guarded\n",
      query_rows,kv_rows,direct.report().cta_tile_q,int(direct.report().split_kv),
      report.cta_tile_q,int(report.split_kv),second_report.cta_tile_q,int(second_report.split_kv));

#if defined(HYLE_G06_CAPTURE_REPLAY)
  HYLE_RETURN_IF_ERROR(check(report.capture_compatible,"public Graph native batch capture not prepared"));
  HYLE_RETURN_IF_ERROR(check(!gb::prepare_replay(invocation,queues).ok(),"public Graph captured replay ignored old output"));
#endif
  std::printf("public CUDA FlashInfer %s %s H%u/KV%u D%u CTA%u Direct/Graph GQA/causal/active-capacity/page-tail/old-output PASS\n",
              paged ? "paged" : "ragged", bf16 ? "BF16" : "F16", query_heads, kv_heads,
              depth, report.cta_tile_q);
  return Status::Ok();
}
Status run() {
  HYLE_RETURN_IF_ERROR(exercise(1,129));
  HYLE_RETURN_IF_ERROR(exercise(2,257));
  HYLE_RETURN_IF_ERROR(exercise(2,385));
  HYLE_RETURN_IF_ERROR(exercise(2,513));
  return Status::Ok();
}
} // namespace
int main() {
  std::setvbuf(stdout, nullptr, _IONBF, 0);
  const auto status = run();
  if (status.ok()) return 0;
  char message[768]{};
  status.ToString(message, sizeof(message));
  std::fprintf(stderr, "public CUDA batch: %s\n", message);
  return 1;
}
