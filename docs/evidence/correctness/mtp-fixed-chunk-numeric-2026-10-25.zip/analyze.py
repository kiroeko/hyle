from pathlib import Path
import hashlib,json,re,struct,zipfile
D=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def decoded(raw):return [struct.unpack('<f',struct.pack('<I',x<<16))[0]for x in struct.unpack('<'+'H'*(len(raw)//2),raw)]

episodes=[]
for i,(q,kv)in enumerate([(1,129),(2,257),(2,385),(2,513)]):
    paths={kind:{route:D/(kind+'-run')/f'output-Q{q}-KV{kv}-{route}.bf16' for route in ['direct','graph0','graph1']}
           for kind in ['candidate','baseline']}
    buffers={kind:{route:p.read_bytes()for route,p in routes.items()}for kind,routes in paths.items()}
    original=buffers['baseline']['direct'];candidate=buffers['candidate']['direct']
    a=struct.unpack('<'+'H'*(len(original)//2),original);b=struct.unpack('<'+'H'*(len(candidate)//2),candidate)
    differences=sum(x!=y for x,y in zip(a,b));max_delta=max(abs(x-y)for x,y in zip(decoded(original),decoded(candidate)))
    stats={kind:read(D/(kind+'-run')/'summary.json')for kind in ['candidate','baseline']}
    episodes.append(dict(Q=q,KV=kv,tail=1,values_per_route=len(a),
        candidate_max_abs_error_to_F64=stats['candidate']['per_output_max_abs_errors'][3*i:3*i+3],
        baseline_max_abs_error_to_F64=stats['baseline']['per_output_max_abs_errors'][3*i:3*i+3],
        candidate_vs_baseline_direct_BF16_different_values=differences,candidate_vs_baseline_max_abs_delta=max_delta,
        each_native_Direct_equals_both_Graph_outputs={kind:len(set(routes.values()))==1 for kind,routes in buffers.items()},
        candidate_split_kv=(kv>512),baseline_split_kv=True,
        outputs={kind:[pin(p)for p in routes.values()]for kind,routes in paths.items()}))

current_source=D.parents[2]/'tests/compute_batch/public_batch_cuda_consumer.cc'
source_pins=read(D/'source-pins.json');assert pin(current_source)==source_pins['original']
dep_pins=read(D/'compile/source-pins.json')
assert all(pin(Path(item['path']))==item for item in dep_pins)
summary=dict(status='PASS_bounded_numeric_check_not_performance_or_whole_model_certification',
    source_pins=pin(D/'source-pins.json'),oracle_byte_equal=source_pins['oracle_byte_equal'],
    dependency_pins_unchanged_after_runs=True,dependencies=pin(D/'compile/source-pins.json'),
    scope=dict(consumer_TUs_built=1,native_TUs_built_here=0,links=2,actual_processes=2,episodes_per_process=4,
        SDK_builds=0,HTTP=0,models=0,GPU_released=True,
        context='actual NVIDIA GeForce RTX 4070, compute capability 8.9, reported by runtime',
        data='deterministic source fixture, BF16 Q/K/V/Y, R1 H8/KV2 D256 page16 causal window-1, default F32 split partial policy',
        witness='Reverse physical page references, one unused whole page and all unused tail rows poisoned with BF16 NaN; last valid row V=8..8.875 and K=0 makes causal final-row exclusion visible.',
        native_route='Direct BatchProgram requires native BatchPlanning extension; Graph uses public PagedAttention with OperationFallbackPolicy::kReject and all three actual CTA16 plan reports; no SDPA/ggml operation fallback.',
        replay='Original Direct prepare/run and Graph kCommands prepare_replay/submit/wait. Original held-output prepare rejection and layout-generation checks retained. Optional HYLE_G06_CAPTURE_REPLAY path was not enabled, so no separate CUDA capture compatibility certification.',
        internal_F32_partial_error='unknown; no public internal partial tensor was read or compared'),
    gate=dict(original_independent_double_oracle_preserved=True,absolute_tolerance=.007,
        every_output_requires_finite_error=True,outputs_checked_per_process=43008,oracle_calls_per_process=12,
        candidate_max_abs_error=read(D/'candidate-run/summary.json')['max_abs_error'],
        baseline_max_abs_error=read(D/'baseline-run/summary.json')['max_abs_error']),
    compile=read(D/'compile/process.json'),candidate_link=read(D/'candidate-link/process.json'),
    baseline_link=read(D/'baseline-link/process.json'),
    candidate_process=read(D/'candidate-run/process.json'),baseline_process=read(D/'baseline-run/process.json'),
    compile_warning_count=len(re.findall(r'warning [A-Z]+[0-9]+', (D/'compile/stdout.log').read_text(errors='replace')+(D/'compile/stderr.log').read_text(errors='replace'))),
    episodes=episodes,
    conclusion='The four fixed episodes satisfy the unchanged public independent-double gate. Candidate and original native plans produce finite but not necessarily identical BF16 values; Direct and Graph agree within each native variant. This permits only the bounded numerical statement, not general attention accuracy or achieved performance.',
    process_elapsed_scope='Raw elapsed seconds retained for audit only; these mixed CPU oracle/IO/runtime processes are not a speed benchmark.',
    failures=[dict(kind='offline_analysis_script_setup',source='analyze-firstfailed.py.txt',
        error='LookupError: unknown encoding: utf8-sig; preceding SyntaxWarning: invalid decimal literal ==1for.',
        correction='Use utf-8-sig and separate integer literal from for keyword. No consumer compile or actual run repeated.')])
save(D/'proof-summary.json',summary)
cleanup=[pin(p)for folder in ['compile','candidate-link','baseline-link']for p in sorted((D/folder).iterdir())if p.is_file()and p.suffix.lower()in{'.obj','.exe','.pdb','.exp','.lib','.map','.ilk'}]
save(D/'cleanup-candidates.json',dict(count=len(cleanup),logical_bytes=sum(x['bytes']for x in cleanup),files=cleanup,
    policy='Parent test.ps1 only; do not remove shared native objects, baseline app/Graph/runtime, original or candidate source/commands/logs/output evidence.'))
items=[]
for p in D.rglob('*'):
    if not p.is_file()or p.suffix.lower()in{'.obj','.exe','.pdb','.exp','.lib','.map','.ilk','.zip'}or p.name in{'proof-package.json','live.json'}:continue
    items.append(p)
with zipfile.ZipFile(D/'proof.zip','w',zipfile.ZIP_DEFLATED)as z:
    for p in sorted(items):z.write(p,p.relative_to(D).as_posix())
save(D/'proof-package.json',dict(summary=pin(D/'proof-summary.json'),archive=pin(D/'proof.zip'),
    files=len(items),cleanup_count=len(cleanup),cleanup_logical_bytes=sum(x['bytes']for x in cleanup)))
print(json.dumps(dict(candidate_max=summary['gate']['candidate_max_abs_error'],baseline_max=summary['gate']['baseline_max_abs_error'],
    differences=[x['candidate_vs_baseline_direct_BF16_different_values']for x in episodes],
    max_deltas=[x['candidate_vs_baseline_max_abs_delta']for x in episodes],package=read(D/'proof-package.json')),indent=2))
