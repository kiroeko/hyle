from pathlib import Path
import difflib, hashlib, importlib.util, json, os, re, sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent; R=D.parents[2]
B=D.parent/'baseline'; F=R/'.scratch/mtp-fixed-chunk-20261025'
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec); spec.loader.exec_module(b)

def prepare():
    src=R/'tests/compute_batch/public_batch_cuda_consumer.cc'
    raw=src.read_bytes(); original=raw.decode('utf-8')
    assert hashlib.sha256(raw).hexdigest()=='1914f0ceb762e0645192d13c9f3c76010a0f6c31b1eda9832a9c6733e2e2333f'
    text=original
    start=text.index('Status exercise('); stop=text.index('  const c::BatchProgramOptions options{',start)
    text=text[:start]+'''Status exercise(unsigned query_rows, unsigned kv_rows) {
  constexpr bool paged = true, bf16 = true;
  constexpr unsigned page = 16, query_heads = 8, kv_heads = 2, depth = 256;
  const unsigned pages = kv_rows / page + (kv_rows % page != 0);
  std::printf("episode R1 Q%u KV%u H8/KV2 D256 page16 causal window-1 BF16 F32partials\\n", query_rows, kv_rows);
  const c::BatchCapacity cap{
      .storage=c::BatchStorage::kPaged,
      .query_type=c::DataType::kBFloat16,.output_type=c::DataType::kBFloat16,
      .key_storage=c::CacheStorage::plain(c::DataType::kBFloat16).value(),
      .value_storage=c::CacheStorage::plain(c::DataType::kBFloat16).value(),
      .max_requests=1,.max_query_rows=query_rows,.max_kv_rows=pages*page,
      .max_pages=pages+1,.max_page_refs=pages,
      .query_heads=query_heads,.kv_heads=kv_heads,.qk_head_dim=depth,.value_head_dim=depth,
      .page_size=page};
  HYLE_ASSIGN_OR_RETURN(auto schema, c::BatchSchema::create(cap));
  const std::array<std::int32_t,2> qptr{0,static_cast<std::int32_t>(query_rows)},
      kvptr{0,static_cast<std::int32_t>(pages)};
  std::vector<std::int32_t> ids(pages);
  for(unsigned i=0;i<pages;++i) ids[i]=static_cast<std::int32_t>(pages-i);
  const std::array<std::int32_t,1> tails{static_cast<std::int32_t>((kv_rows-1)%page+1)};
  HYLE_ASSIGN_OR_RETURN(auto layout, schema.version({qptr,kvptr,ids,tails}));
''' + text[stop:]
    start=text.index('  for (unsigned i = 0; i < k.size(); ++i) {');stop=text.index('  HYLE_ASSIGN_OR_RETURN(auto pool,',start)
    text=text[:start]+'''  // Poison the unused whole physical page and all unused tail rows. Only
  // logical valid rows are initialized; reverse page order is intentional.
  std::fill(k.begin(),k.end(),std::uint16_t{0x7fc0});
  std::fill(v.begin(),v.end(),std::uint16_t{0x7fc0});
  for(unsigned row=0;row<kv_rows;++row) for(unsigned h=0;h<kv_heads;++h)
    for(unsigned d=0;d<depth;++d) {
      const auto logical=(row*kv_heads+h)*depth+d;
      const auto physical=(static_cast<unsigned>(ids[row/page])*page+row%page)*kv_heads*depth+h*depth+d;
      k[physical]=encode(.3f*std::cos(float(logical)*.019f),bf16);
      v[physical]=encode(std::sin(float(logical)*.013f)+float(logical%11)*.01f,bf16);
      // Make the last valid row a visible causal-mask witness for Q2.
      if(row+1==kv_rows){ k[physical]=encode(0.f,bf16); v[physical]=encode(8.f+float(d%8)*.125f,bf16); }
    }
''' + text[stop:]
    # Keep the original oracle function byte-for-byte, including its fixed gate.
    oracle=original[original.index('Status oracle('):original.index('Status exercise(')]
    assert text[text.index('Status oracle('):text.index('Status exercise(')]==oracle
    recorder='''Status record_output(const c::ReadLease &output, unsigned query_rows, unsigned kv_rows, const char *kind) {
  std::vector<std::uint16_t> words(query_rows*8u*256u);
  HYLE_RETURN_IF_ERROR(output.view()->read(std::as_writable_bytes(std::span(words))));
  char name[128]{};
  std::snprintf(name,sizeof(name),"output-Q%u-KV%u-%s.bf16",query_rows,kv_rows,kind);
  std::FILE *file=nullptr;
  if(fopen_s(&file,name,"wb") || !file) return Status::Internal("numeric output file open failed");
  const auto written=std::fwrite(words.data(),sizeof(words[0]),words.size(),file);
  const auto closed=std::fclose(file);
  return check(written==words.size() && closed==0,"numeric output file write failed");
}
'''
    text=text.replace('Status exercise(',recorder+'Status exercise(',1)
    for lease,kind in [('direct_output','direct'),('result','graph0'),('second_result','graph1')]:
        anchor=f'  HYLE_RETURN_IF_ERROR(oracle(cap, layout, q, k, v, {lease}, bf16));'
        assert text.count(anchor)==1
        text=text.replace(anchor,anchor+f'\n  HYLE_RETURN_IF_ERROR(record_output({lease}, query_rows, kv_rows, "{kind}"));',1)
    anchor='  HYLE_RETURN_IF_ERROR(check(report.layout_generation == layout.generation(), "public Graph mirror generation differs"));'
    assert text.count(anchor)==1
    text=text.replace(anchor,anchor+'''
  HYLE_RETURN_IF_ERROR(check(direct.report().cta_tile_q!=0 && report.cta_tile_q!=0 && second_report.cta_tile_q!=0,
      "numeric consumer did not obtain actual native batch plans"));
  HYLE_RETURN_IF_ERROR(check(!direct.report().bf16_partials && !report.bf16_partials && !second_report.bf16_partials,
      "numeric consumer unexpectedly enabled BF16 partials"));
  std::printf("native reports Q%u KV%u Direct CTA%u split%d Graph0 CTA%u split%d Graph1 CTA%u split%d fallback=reject old-leases=guarded\\n",
      query_rows,kv_rows,direct.report().cta_tile_q,int(direct.report().split_kv),
      report.cta_tile_q,int(report.split_kv),second_report.cta_tile_q,int(second_report.split_kv));
''',1)
    # Remove unused broad capability examples and run only the four authorized episodes.
    start=text.index('Status default_context_exposes_batch(');stop=text.index('} // namespace',start)
    text=text[:start]+'''Status run() {
  HYLE_RETURN_IF_ERROR(exercise(1,129));
  HYLE_RETURN_IF_ERROR(exercise(2,257));
  HYLE_RETURN_IF_ERROR(exercise(2,385));
  HYLE_RETURN_IF_ERROR(exercise(2,513));
  return Status::Ok();
}
'''+text[stop:]
    assert text[text.index('Status oracle('):text.index('Status record_output(')]==oracle
    (D/'numeric_consumer.cc').write_text(text,encoding='utf8',newline='\n')
    (D/'before-public_batch_cuda_consumer.cc').write_bytes(raw)
    (D/'source.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='canonical/public_batch_cuda_consumer.cc',tofile='private/numeric_consumer.cc')),encoding='utf8')
    ready=b.read(F/'ready.json')
    for key in ['native_object','original_native_object']:
        assert b.pin(Path(ready[key]['path']))==ready[key]
    b.save(D/'source-pins.json',dict(original=b.pin(src),consumer=b.pin(D/'numeric_consumer.cc'),
        patch=b.pin(D/'source.patch'),oracle_byte_equal=True,
        oracle_sha256=hashlib.sha256(oracle.encode()).hexdigest(),fixed_tolerance=.007,
        candidate_native=ready['native_object'],original_native=ready['original_native_object'],
        candidate_native_source=b.pin(F/'overlay/native_batch.cu'),candidate_source_contract=b.pin(F/'source-pins.json'),
        provider_policy='Keep original uninstrumented provider object from clean baseline; actual BatchProgram requires native BatchPlanning and Graph fallback rejects.',
        compile_tus=1,SDK_builds=0,HTTP=0))
    print('PREPARED oracle byte-identical; four episodes',flush=True)

def build():
    original=b.args(B/'compile/command.json');cmd=[original[0]];skip=False
    for word in original[1:]:
        if skip:skip=False;continue
        if word=='/sourceDependencies':skip=True;continue
        if word.lower().startswith(('/fo','/fd')) or word.lower().endswith(('.cc','.cpp')):continue
        cmd.append(word)
    cmd+=['/DHYLE_COMPUTE_FLASHINFER=1',str(D/'numeric_consumer.cc'),'/sourceDependencies',str(D/'compile/dependencies.json'),'/Fo'+str(D/'compile/unit.obj')]
    assert [x for x in cmd if x.lower().endswith(('.cc','.cpp'))]==[str(D/'numeric_consumer.cc')]
    env=b.environment(cmd[0]);b.execute(cmd,D/'compile',env,120)
    deps=b.read(D/'compile/dependencies.json')['Data']['Includes']
    b.save(D/'compile/source-pins.json',[b.pin(Path(x))for x in deps if Path(x).is_relative_to(R)])
    link(False,env)

def link(baseline,env=None):
    if env is None:env=b.environment(b.args(B/'compile/command.json')[0])
    pins=b.read(D/'source-pins.json');kind='baseline'if baseline else'candidate'
    original=b.args(B/'link/command.json');app=str(B/'compile/unit.obj');report=str(D.parent/'current-cuda/report/unit.obj')
    native=pins['original_native']['path'];replacement=native if baseline else pins['candidate_native']['path']
    assert original.count(app)==original.count(report)==original.count(native)==1
    cmd=[str(D/'compile/unit.obj')if x==app else replacement if x==native else x for x in original
         if x!=report and not x.upper().startswith(('/OUT:','/PDB:','/MAP:','/IMPLIB:'))]
    cmd+=['/OUT:'+str(D/(kind+'-link')/'numeric.exe')]
    b.execute(cmd,D/(kind+'-link'),env,120)
    b.save(D/(kind+'-ready.json'),dict(image=b.pin(D/(kind+'-link')/'numeric.exe'),native=b.pin(Path(replacement)),
        app_object=b.pin(D/'compile/unit.obj'),runtime=b.pin(B/'runtime.json'),report_omitted=True,clean_link=b.pin(B/'link/command.json')))

def run(baseline=False):
    kind='baseline'if baseline else'candidate';ready=b.read(D/(kind+'-ready.json'))
    assert b.pin(Path(ready['image']['path']))==ready['image'];assert b.pin(Path(ready['native']['path']))==ready['native']
    env=dict(os.environ,PATH=b.read(B/'runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    # execute() uses repository cwd; relative binary outputs are redirected by this private process argument-free wrapper cwd.
    import subprocess,time
    folder=D/(kind+'-run');folder.mkdir(exist_ok=False)
    cmd=[ready['image']['path']];b.save(folder/'command.json',dict(command=cmd,cwd=str(folder),timeout_seconds=120))
    start=time.monotonic()
    with (folder/'stdout.log').open('wb')as out,(folder/'stderr.log').open('wb')as err:
        p=subprocess.Popen(cmd,cwd=folder,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        b.save(folder/'live.json',dict(pid=p.pid))
        try:code=p.wait(timeout=120);timed_out=False
        except subprocess.TimeoutExpired:p.kill();p.wait();code=p.returncode;timed_out=True
    result=dict(exit=code,seconds=time.monotonic()-start,timeout=timed_out)
    b.save(folder/'process.json',result);print(kind,json.dumps(result),flush=True)
    print((folder/'stdout.log').read_text(errors='replace'),flush=True)
    print((folder/'stderr.log').read_text(errors='replace'),flush=True)
    if code or timed_out:raise SystemExit(1)
    lines=(folder/'stdout.log').read_text().splitlines();errors=[float(m.group(1))for line in lines if(m:=re.search(r'oracle maxError=([^ ]+) PASS',line))]
    assert len(errors)==12 and all(x<.007 for x in errors)
    b.save(folder/'summary.json',dict(status='PASS',episodes=4,oracle_passes=12,max_abs_error=max(errors),per_output_max_abs_errors=errors,
        numeric_gate='original independent double oracle, finite abs(error)<0.007 for every output',
        actual_outputs=[b.pin(p)for p in sorted(folder.glob('output-*.bf16'))],process=result,
        internal_F32_partial_error='unknown; no public partial output inspected',TPS_evidence=False))

if __name__=='__main__':
    action=sys.argv[1]
    if action=='baseline-link':link(True)
    elif action=='baseline-run':run(True)
    else:globals()[action]()
