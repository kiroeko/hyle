from pathlib import Path
import importlib.util,json,os,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[1]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
A=D/'attempt2-workspace'
cmd=b.args(D/'compile/command.json');oldsource=str(D/'component.cc');oldobj=str(D/'compile/component.obj')
source=D/'component-v2.cc';obj=A/'compile/component.obj'
compile=[];skip=False
for word in cmd:
 if skip: skip=False;continue
 if word=='/sourceDependencies': skip=True;continue
 if word.lower().startswith(('/fo','/fd')) or word==oldsource: continue
 compile.append(word)
compile.extend(['/sourceDependencies',str(A/'compile/dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(A/'compile/component.pdb')])
env=b.environment(cmd[0]);b.execute(compile,A/'compile',env,60)
link=[]
for word in b.args(D/'link/command.json'):
 if word.lower().startswith(('/out:','/pdb:','/map:','/implib:')):continue
 link.append(str(obj) if word==oldobj else word)
assert sum(x==str(obj) for x in link)==1
link.extend(['/OUT:'+str(A/'link/component.exe'),'/PDB:'+str(A/'link/component.pdb'),'/IMPLIB:'+str(A/'link/component.lib')])
b.execute(link,A/'link',env,60)
runtime=b.read(R/'.scratch/mtp-performance-convergence-20261025/baseline/runtime.json')
native=Path(runtime['native']['path']);os.link(native,A/'link'/native.name)
runenv=env.copy();runenv['PATH']=str(A/'link')+';'+runtime['PATH']
inputs=R/'.scratch/inference-system-review-20261025/nf4-component-values'
b.save(A/'pins.json',{'source':b.pin(source),'workspace_diff':b.pin(D/'workspace-fix.patch'),'original_component':b.pin(D/'component.cc'),'original_reader_result':b.pin(D/'reference-result.json'),'oracle_payloads':[b.pin(D/name) for name in ('expected-f16.bin','activations-f16.bin','expected-projection-f16.bin','wrong-bf16-projection-f16.bin')],'native':b.pin(native)})
b.execute([str(A/'link/component.exe'),str(inputs),str(D)],A/'run',runenv,60)
raw=(A/'run/stdout.log').read_text(encoding='utf-8-sig');result=json.loads(next(line for line in raw.splitlines() if line.startswith('{')))
assert result['status']=='PASS' and result['decoded_values']==15360 and result['decode_invocations']==1
assert [(p['backend'],p['rows'])for p in result['projections']]==[('cpu',1),('cpu',2),('cuda',1),('cuda',2)]
assert all(p['rounding_witnesses']==3*p['rows']for p in result['projections'])
b.save(A/'summary.json',dict(status='PASS_corrected_consumer',consumer=result,image=b.pin(A/'link/component.exe'),compile=b.read(A/'compile/process.json'),link=b.read(A/'link/process.json'),run=b.read(A/'run/process.json'),first_failure_preserved='../component-run',reference_rerun=False,actual_total_processes={'independent_reader':1,'consumer_failed_workspace':1,'consumer_corrected':1},HTTP=0,SDK_builds=0))
print(json.dumps(result,indent=2))
