# 原 NF4 F16 小组件执行计划

固定 `unsloth/Qwen3.8-27B-unsloth-bnb-4bit@8aa5f05d26b7205477066e1449e0af13f762a299` 的 `layers.3.self_attn.k_proj.weight`。仅已有 171B JSON + 9,012B 正文，不网络。原 JSON 仍是 `[1024,5120]`；本组件单列首 3 行视图 `[3,5120]`，不伪造原角色 shape、不签其余351组或整27B。

六输入为 U8[3,2560] packed、U8[240] absmax codes、F32[1] nested_absmax、F32[256] nested_quant_map、F32 scalar offset `0x3d2fd550`、F32[16] quant_map。codebooks.bin 前1024B是nested表、后64B是NF4表。解析原 `nf4_state.h` 保 metadata身份，调用已有 `ArtifactWeightDecode{kNf4DoubleQuant,64,kFloat16}`，不用 Unknown 默认 BF16。

最多两个真实组件进程：

1. Python CPU reference：从已缓存固定 BNB `833649043474794b8fe7a4136e0c40faf077b2e0` 的 `bnb-default-ops.py` 原样抽取 `_dequantize_blockwise_compute`、`_dequantize_4bit_compute` 函数正文，去掉的是外部编译装饰，不改函数；原 F32 nested lookup×nested_absmax+offset → F32 NF4 lookup×scale → F16。输出全部15,360个F16原值。固定 A 的 row0只有列0=.25、1=-.125、5119=.5，row1为-.5、.125、.25；生成F16 A和独立F64/FP32一致的F16投影oracle。此三点模板来自旧fixture，不搜seed/列；标准库预读已见错经BF16会改12,361权重、六个投影全不同，但这不是HylePASS。
2. 一个小 C++ consumer：创建现 CPU Context，六ports显式F16 **只冷decode一次**，全部F16 bytes对reference，publish成唯一不可变 W lease。普通 Direct MatMul 的 A/W/Y均F16、FP32 accumulation，M1和M2各一次，W跨shape复用。然后同process若原CUDA闭包直接承载，上传同一已解码W一次，运行相同M1/M2真实cuBLAS；记录实际provider与runtime properties、输出和各舍入见证。没有整引擎/Graph/MTP/生成质量的通过宣称。

F16承载源码已核：CPU原公开cold-decode→ordinary MatMul在 `tests/compute_route_cpu/cpu_artifact_decode_test.cc:25–66`；CPU ATen MatMul接受F16（`aten_cpu_provider.cc:100–117,199,660`）。CUDA `cublas_provider.cc:131–160,181–220` 接受同行/列主序F16矩阵与同类型输出，`:495–523` 使用F32 accumulation与F32 split-K partial；`include/hyle/compute/providers/cublas.h:13–32` 明确合同。N3可能暴露vendor实际heuristic限制，首次失败保留即停，不padding、换精度或开第二矩阵。

复用确切缓存：compile模板 `.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json`；link模板同目录 `link/command.json`，仅替换其 `compile/unit.obj` 为组件1TU，删除不需要的report entry与输出文件参数，其余原OBJ/LIB不变。现闭包含CPU backend/context/torch_cpu_program、CUDA artifact/cuBLAS/CPU+CUDA runtime；不编SDK或backend。DLL与PATH复用 `.scratch/mtp-performance-convergence-20261025/baseline/runtime.json`，原 CPU GDN DLL可硬链到新image同目录，不复制库树。所有新源码、commands/dependency pins/log/results留本目录。首次失败不自动重试；只由root决定下一动作。

判定：15,360 F16解码值必须bit一致；固定稀疏A的各FP32 dot可由独立F64精确和复核，最终F16六个值必须一致并区别“先BF16再F16”的错误路径；明确colddecode count1、两个普通shape各真实提交、immutable W未再解码/覆写。CPU与CUDA分别记实际provider，不能用stub、BF16旧synthetic或未运行的准备结果代签。
