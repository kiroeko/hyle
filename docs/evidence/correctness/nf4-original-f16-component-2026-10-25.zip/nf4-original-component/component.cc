#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

#include "hyle/compute/cpu.h"
#include "hyle/compute/cuda.h"
#include "hyle/compute/backends/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/cublas.h"
#include "hyle/compute/resource_leases.h"
#include "hyle/compute/storage_owner.h"
#include "engine/models/qwen35/nf4_state.h"

namespace c = hyle::compute;
namespace m = hyle::mem;
namespace fs = std::filesystem;
using Type = c::DataType;

void require(bool value, const char *message) { if (!value) throw std::runtime_error(message); }
void check(hyle::Status status) { if (!status.ok()) throw std::runtime_error(std::string(status.message())); }
template<class T> T take(hyle::Result<T> result) {
  if (!result) throw std::runtime_error(std::string(result.error().message()));
  return std::move(*result);
}
c::TensorDesc dense(Type type, std::initializer_list<std::int64_t> shape) {
  return take(c::TensorDesc::dense(type, {shape.begin(), shape.size()}));
}
std::vector<std::byte> load(const fs::path &path) {
  std::ifstream file(path, std::ios::binary | std::ios::ate);
  if (!file) throw std::runtime_error("cannot open " + path.string());
  const auto end = file.tellg(); require(end >= 0, "negative input length");
  std::vector<std::byte> bytes(static_cast<std::size_t>(end));
  file.seekg(0); file.read(reinterpret_cast<char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
  require(bool(file), "short original component input"); return bytes;
}
m::Buffer buffer(m::MemoryResourceRef resource, std::span<const std::byte> bytes) {
  auto result = take(m::Buffer::create(resource, bytes.size(), 256));
  check(result.view().write(bytes)); return result;
}
std::uint64_t fingerprint(std::span<const std::byte> bytes) {
  std::uint64_t result = 14695981039346656037ULL;
  for (const auto value : bytes) { result ^= std::to_integer<unsigned char>(value); result *= 1099511628211ULL; }
  return result;
}
std::string identity(const c::PreparedOperation &prepared) {
  const auto provider = prepared.provider(); const auto runtime = prepared.runtime_properties();
  std::ostringstream out;
  out << "{\"name\":\"" << provider.name << "\",\"version\":\"" << provider.version
      << "\",\"namespace_id\":" << provider.id.namespace_id << ",\"provider_id\":" << provider.id.provider_id
      << ",\"replay_class\":" << static_cast<unsigned>(runtime.replay_class)
      << ",\"capture_compatible\":" << (runtime.capture_compatible ? "true" : "false") << '}';
  return out.str();
}

std::string project(c::Context &context, c::Queue &queue, m::MemoryResourceRef resource,
                    const c::ReadLease &weight, std::size_t rows,
                    std::span<const std::byte> activation, std::span<const std::byte> expected,
                    std::span<const std::byte> wrong, bool cuda) {
  const auto a_desc = dense(Type::kFloat16, {static_cast<std::int64_t>(rows),5120});
  const auto w_desc = take(dense(Type::kFloat16, {3,5120}).transposed());
  const auto y_desc = dense(Type::kFloat16, {static_cast<std::int64_t>(rows),3});
  auto a = buffer(resource, activation.first(rows * 5120 * 2));
  auto y = take(m::Buffer::create(resource, rows * 3 * 2, 256));
  const auto av = take(c::ConstTensorView::create(a_desc, a.view()));
  const auto wv = take(weight.tensor(w_desc));
  const auto output = take(c::TensorView::create(y_desc, y.view()));
  auto prepared = take(c::prepare(context, c::MatMul{.accumulation_type=Type::kFloat32}, a_desc, w_desc, resource));
  if (cuda) require(prepared.provider().id == c::cublas::kProviderId, "CUDA ordinary F16 projection did not select cuBLAS");
  auto invocation = take(prepared.create_invocation());
  auto done = take(invocation.submit(queue, av, wv, output)); check(done.wait());
  std::vector<std::byte> actual(rows * 3 * 2); check(y.view().read(actual));
  require(std::equal(actual.begin(), actual.end(), expected.begin()), "ordinary F16 projection differs from original independent reader oracle");
  std::size_t witnesses = 0;
  for (std::size_t at = 0; at < rows * 3; ++at)
    witnesses += actual[at*2] != wrong[at*2] || actual[at*2+1] != wrong[at*2+1];
  require(witnesses == rows * 3, "ordinary projection did not distinguish the forbidden BF16 intermediate");
  std::ostringstream out;
  out << "{\"backend\":\"" << (cuda ? "cuda" : "cpu") << "\",\"rows\":" << rows
      << ",\"provider\":" << identity(prepared) << ",\"A_W_Y_dtype\":\"F16\",\"accumulation\":\"F32\""
      << ",\"weight_generation\":" << weight.generation() << ",\"weight_fnv64\":";
  std::vector<std::byte> check_weight(30720); check(take(weight.view()).read(check_weight));
  out << fingerprint(check_weight) << ",\"output_f16_bits\":[";
  for (std::size_t at = 0; at < rows * 3; ++at) {
    if (at) out << ',';
    out << (std::to_integer<unsigned>(actual[at*2]) | (std::to_integer<unsigned>(actual[at*2+1]) << 8));
  }
  out << "],\"rounding_witnesses\":" << witnesses << '}';
  return out.str();
}

int main(int argc, char **argv) {
  try {
    require(argc == 3, "component requires original input directory and oracle directory");
    const fs::path input = argv[1], oracle = argv[2];
    const auto state_bytes = load(input.parent_path() / "nf4-quant-state/quant-state.bin");
    const auto state = qwen35::prepared::parse_nf4_state(std::string_view(
        reinterpret_cast<const char *>(state_bytes.data()), state_bytes.size()));
    require(state.logical_shape == std::array<std::int64_t,2>{1024,5120} && state.offset_f32_bits == 0x3d2fd550,
            "original NF4 metadata identity changed");
    auto codes = load(input / "weight.bin"), indices = load(input / "absmax.bin");
    auto nested_absmax = load(input / "nested_absmax.bin"), books = load(input / "codebooks.bin");
    require(codes.size()==7680 && indices.size()==240 && nested_absmax.size()==4 && books.size()==1088,
            "original component ranges have wrong sizes");
    const auto expected = load(oracle / "expected-f16.bin"), activation = load(oracle / "activations-f16.bin");
    const auto projection = load(oracle / "expected-projection-f16.bin"), wrong = load(oracle / "wrong-bf16-projection-f16.bin");
    require(expected.size()==30720 && activation.size()==20480 && projection.size()==12 && wrong.size()==12,
            "independent oracle extents differ");
    const auto offset = std::bit_cast<float>(state.offset_f32_bits);
    const std::array descriptions{dense(Type::kUInt8,{3,2560}),dense(Type::kUInt8,{240}),
        dense(Type::kFloat32,{1}),dense(Type::kFloat32,{256}),dense(Type::kFloat32,{}),dense(Type::kFloat32,{16})};
    const std::array<std::span<const std::byte>,6> payloads{codes,indices,nested_absmax,
        std::span<const std::byte>(books).first(1024),std::as_bytes(std::span(&offset,1)),
        std::span<const std::byte>(books).subspan(1024)};
    check(c::cpu::configure_runtime_threads(1));
    auto cpu = take(c::cpu::create_context()); auto cpu_queue = take(cpu.create_queue());
    std::vector<m::Buffer> original; original.reserve(6);
    std::vector<c::ConstTensorView> views; views.reserve(6);
    for (std::size_t index = 0; index < payloads.size(); ++index) {
      original.push_back(buffer(m::system_resource(), payloads[index]));
      views.push_back(take(c::ConstTensorView::create(descriptions[index], original.back().view())));
    }
    const auto operation = c::model_ops::artifact_weight_decode(c::model_ops::WeightArtifactFormat::kNf4DoubleQuant,64,Type::kFloat16);
    const auto decoded_desc = dense(Type::kFloat16,{3,5120});
    auto decoded_buffer = take(m::Buffer::create(m::system_resource(), 30720, 256));
    c::PreparedOperation decoder;
    {
      const auto destination = take(c::TensorView::create(decoded_desc, decoded_buffer.view()));
      decoder = take(c::prepare(cpu,operation,views,std::span(&destination,1)));
      auto decode_run = take(decoder.create_invocation());
      auto decoded = take(decode_run.submit(cpu_queue,views,std::span(&destination,1))); check(decoded.wait());
    } // No writable tensor alias or accepted decode use survives the import.
    std::vector<std::byte> actual(30720); check(decoded_buffer.view().read(actual));
    require(actual == expected, "explicit F16 ArtifactWeightDecode differs from all15360 original reader values");
    auto weight = take(c::ReadLease::adopt(std::move(decoded_buffer)));
    require(!weight.try_write(), "published cold CPU weight unexpectedly became mutable");
    std::vector<std::string> projections;
    for (std::size_t rows : {1u,2u}) projections.push_back(project(cpu,cpu_queue,m::system_resource(),weight,rows,activation,projection,wrong,false));
    auto cuda = take(c::cuda::create_context());
    auto resource = take(c::cuda::MemoryResource::create(cuda,c::cuda::MemoryKind::kDevice));
    auto owner = take(c::StorageOwner::adopt(cuda,std::move(resource)));
    auto cuda_weight_buffer = buffer(owner.ref(),actual);
    auto cuda_weight = take(owner.adopt_buffer(std::move(cuda_weight_buffer)));
    require(!cuda_weight.try_write(), "published cold CUDA weight unexpectedly became mutable");
    auto cuda_queue = take(cuda.create_queue());
    for (std::size_t rows : {1u,2u}) projections.push_back(project(cuda,cuda_queue,owner.ref(),cuda_weight,rows,activation,projection,wrong,true));
    std::vector<std::byte> final_weight(30720); check(take(weight.view()).read(final_weight));
    require(final_weight == expected, "cold CPU weight was overwritten by ordinary projections");
    std::cout << "{\"status\":\"PASS\",\"decode_invocations\":1,\"decoded_values\":15360,\"decode_provider\":"
        << identity(decoder) << ",\"decoded_fnv64\":" << fingerprint(actual)
        << ",\"original_shape\":[1024,5120],\"component_view\":[3,5120],\"decode_dtype\":\"F16\",\"projections\":[";
    for (std::size_t index = 0; index < projections.size(); ++index) { if (index) std::cout << ','; std::cout << projections[index]; }
    std::cout << "],\"scope\":\"Original cold-decode and ordinary Direct Compute component; not whole model/Graph/generation or all formats.\"}\n";
    return 0;
  } catch (const std::exception &error) {
    std::cerr << "NF4 original component: " << error.what() << '\n'; return 1;
  }
}
