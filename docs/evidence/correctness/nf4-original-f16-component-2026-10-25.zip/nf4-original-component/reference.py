"""One independent fixed BNB default CPU reader process; no Hyle decoder expected generation."""
import ast
import hashlib
import json
import math
from pathlib import Path
import struct
from typing import Sequence

import torch

D = Path(__file__).resolve().parent
R = D.parents[1]
P = R / '.scratch/inference-system-review-20261025/nf4-component-values'
S = R / '.scratch/inference-system-review-20261025/nf4-quant-state/quant-state.bin'
SOURCE = R / '.scratch/validation/cpu-quant-mtp-c1/non-gguf/bnb-default-ops.py'

def pin(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(R)), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

receipt = json.loads((P / 'complete.json').read_text())
for part in receipt['parts']:
    actual = pin(P / part['path'])
    assert actual['bytes'] == part['bytes'] and actual['sha256'] == part['sha256']
assert pin(S)['sha256'] == receipt['quant_state_reused_sha256']
state = json.loads(S.read_bytes())
assert state['shape'] == [1024, 5120] and state['dtype'] == 'float16'
assert state['blocksize'] == 64 and state['nested_blocksize'] == 256 and state['nested_dtype'] == 'float32'
offset = torch.tensor(state['nested_offset'], dtype=torch.float32)
assert struct.unpack('<I', struct.pack('<f', offset.item()))[0] == 0x3d2fd550
raw = SOURCE.read_text()
functions = []
for node in ast.parse(raw).body:
    if isinstance(node, ast.FunctionDef) and node.name in {'_dequantize_blockwise_compute', '_dequantize_4bit_compute'}:
        functions.append(ast.get_source_segment(raw, node))
assert len(functions) == 2
extracted = '\n\n'.join(functions) + '\n'
(D / 'original-reader-functions.py').write_text(extracted, encoding='utf-8')
scope = dict(torch=torch, prod=math.prod, Sequence=Sequence)
exec(compile(extracted, str(SOURCE), 'exec'), scope)
packed = torch.frombuffer(bytearray((P/'weight.bin').read_bytes()), dtype=torch.uint8)
indices = torch.frombuffer(bytearray((P/'absmax.bin').read_bytes()), dtype=torch.uint8)
nested_absmax = torch.frombuffer(bytearray((P/'nested_absmax.bin').read_bytes()), dtype=torch.float32)
books = torch.frombuffer(bytearray((P/'codebooks.bin').read_bytes()), dtype=torch.float32)
scales = scope['_dequantize_blockwise_compute'](indices, nested_absmax, books[:256], 256, torch.float32)
scales = scales + offset
decoded = scope['_dequantize_4bit_compute'](packed, scales, books[256:], 64, (3,5120), torch.float16)
assert decoded.shape == (3,5120) and decoded.dtype == torch.float16 and torch.isfinite(decoded).all()
a = torch.zeros((2,5120), dtype=torch.float16)
a[0,0],a[0,1],a[0,-1] = .25,-.125,.5
a[1,0],a[1,1],a[1,-1] = -.5,.125,.25
exact = a.to(torch.float64) @ decoded.to(torch.float64).T
fp32 = a.float() @ decoded.float().T
assert torch.equal(exact, fp32.to(torch.float64)), 'Fixed three-term projection was not exact in FP32'
y = fp32.to(torch.float16)
wrong = decoded.to(torch.bfloat16).to(torch.float16)
wrong_y = (a.float() @ wrong.float().T).to(torch.float16)
assert torch.count_nonzero(decoded != wrong).item() > 0 and torch.all(y != wrong_y)
def save_half(name, tensor):
    (D/name).write_bytes(struct.pack('<'+'e'*tensor.numel(), *tensor.reshape(-1).tolist()))
save_half('expected-f16.bin', decoded)
save_half('activations-f16.bin', a)
save_half('expected-projection-f16.bin', y)
save_half('wrong-bf16-projection-f16.bin', wrong_y)
result = dict(status='original_fixed_reader_reference_passed', torch_version=torch.__version__,
    original_reader=pin(SOURCE), extracted_functions=pin(D/'original-reader-functions.py'),
    extraction='Original function text without external decorators; no function body change or Hyle decoder.',
    metadata=pin(S), inputs=[pin(P/p['path']) for p in receipt['parts']],
    original_shape=state['shape'], component_view_shape=[3,5120], decode_dtype='F16',
    offset_f32_bits='3d2fd550', decoded_values=decoded.numel(),
    wrong_bf16_intermediate_changed_values=torch.count_nonzero(decoded != wrong).item(),
    projection_f16=y.tolist(), wrong_bf16_projection_f16=wrong_y.tolist(),
    projection_fp32_equals_f64_exact=True,
    outputs=[pin(D/n)for n in ('expected-f16.bin','activations-f16.bin','expected-projection-f16.bin','wrong-bf16-projection-f16.bin')])
(D/'reference-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
