"""One frozen consumer TU; one original-reader process and one CPU/CUDA component process."""
from pathlib import Path
import importlib.util
import json
import os
import shutil
import sys

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[1]
spec = importlib.util.spec_from_file_location('retained', R / '.scratch/mtp-extraction-regression-20261024/check.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
reference = R / '.scratch/inference-system-review-20261025/text-r2-suffix'
original_compile = b.args(reference / 'compile/command.json')
original_link = b.args(reference / 'link/command.json')
source = D / 'component.cc'
header = R / 'engine/models/qwen35/nf4_state.h'
frozen = D / 'source/engine/models/qwen35/nf4_state.h'
frozen.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(header, frozen)
sources = [source, D / 'reference.py', D / 'nf4-component-execution-plan.md', frozen]
b.save(D / 'source-pins.json', [b.pin(p) for p in sources])
command, skip = [], False
for word in original_compile:
    if skip:
        skip = False
        continue
    if word == '/sourceDependencies':
        skip = True
        continue
    if word.lower().startswith(('/fo', '/fd')) or word.lower().endswith('.cc'):
        continue
    command.append(word)
folder = D / 'compile'
command[1:1] = ['/I'+str(D/'source')]
command.extend(['/sourceDependencies', str(folder/'dependencies.json'), str(source),
                '/Fo'+str(folder/'component.obj'), '/Fd'+str(folder/'component.pdb')])
env = b.environment(original_compile[0])
b.execute(command, folder, env, 60)
old_entry = str(reference / 'compile/unit.obj')
assert sum(x.lower() == old_entry.lower() for x in original_link) == 1
link = []
for word in original_link:
    if word.lower().startswith(('/out:', '/pdb:', '/map:', '/implib:')):
        continue
    link.append(str(folder/'component.obj') if word.lower() == old_entry.lower() else word)
for word in link[1:]:
    if word.lower().endswith(('.obj','.lib')):
        assert Path(word).is_file(), 'Existing closure missing: '+word
link.extend(['/OUT:'+str(D/'link/component.exe'), '/PDB:'+str(D/'link/component.pdb'),
             '/IMPLIB:'+str(D/'link/component.lib')])
b.execute(link, D/'link', env, 60)
runtime = b.read(R / '.scratch/mtp-performance-convergence-20261025/baseline/runtime.json')
native = Path(runtime['native']['path'])
os.link(native, D/'link'/native.name)
b.save(D/'native.json', b.pin(native))
oracle_env = os.environ.copy(); oracle_env['OMP_NUM_THREADS'] = '1'
b.execute([sys.executable, str(D/'reference.py')], D/'reference-run', oracle_env, 90)
run_env = env.copy(); run_env['PATH'] = str(D/'link')+';'+runtime['PATH']
inputs = R / '.scratch/inference-system-review-20261025/nf4-component-values'
b.execute([str(D/'link/component.exe'), str(inputs), str(D)], D/'component-run', run_env, 60)
raw = (D/'component-run/stdout.log').read_text(encoding='utf-8-sig')
result = json.loads(next(line for line in raw.splitlines() if line.startswith('{')))
assert result['status'] == 'PASS' and result['decode_invocations'] == 1 and result['decoded_values'] == 15360
assert [(p['backend'],p['rows']) for p in result['projections']] == [('cpu',1),('cpu',2),('cuda',1),('cuda',2)]
reference_result = b.read(D/'reference-result.json')
for row in result['projections']:
    assert row['rounding_witnesses'] == 3*row['rows']
assert b.pin(header)['sha256'] == b.pin(frozen)['sha256'], 'Canonical metadata header drifted'
b.save(D/'summary.json', dict(status='PASS_original_N3_F16_component',
    consumer=result, independent_reference=reference_result,
    source_pins=[b.pin(p) for p in sources], image=b.pin(D/'link/component.exe'),
    compile=b.read(D/'compile/process.json'), link=b.read(D/'link/process.json'),
    reference_process=b.read(D/'reference-run/process.json'), component_process=b.read(D/'component-run/process.json'),
    actual_component_processes=2, cold_decode_invocations=1, ordinary_projection_submissions=4,
    SDK_builds=0, HTTP=0, whole_model_or_generation_claim=False,
    closure_recipe=b.pin(reference/'link/command.json'),
    closure_delta='Same cached closure; only original main entry object replaced and output artifacts redirected.'))
files = [b.pin(p) for directory in (D/'compile', D/'link') for p in directory.iterdir()
         if p.is_file() and p.suffix.lower() in {'.exe','.obj','.pdb','.lib','.exp'}]
b.save(D/'cleanup-candidates.json', dict(performed=False, files=files,
    logical_bytes=sum(p['bytes'] for p in files)))
print(json.dumps(dict(status='PASS', summary=str(D/'summary.json'), component=result), indent=2))
