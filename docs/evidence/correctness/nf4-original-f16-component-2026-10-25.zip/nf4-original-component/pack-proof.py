from pathlib import Path
import hashlib,json,zipfile,shutil
D=Path(__file__).resolve().parent;R=D.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
 b=p.read_bytes();return {'path':p.relative_to(R).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
ref=read(D/'reference-result.json');current=read(D/'attempt2-workspace/summary.json')
original=read(R/'.scratch/inference-system-review-20261025/text-r2-suffix/link/command.json')['command']
actual=read(D/'attempt2-workspace/link/command.json')['command']
oldentry=str(R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/unit.obj')
newentry=str(D/'attempt2-workspace/compile/component.obj')
def normalized(args,entry):return [('<consumer-entry>' if x.lower()==entry.lower()else x)for x in args if not x.lower().startswith(('/out:','/pdb:','/map:','/implib:'))]
assert normalized(original,oldentry)==normalized(actual,newentry)
assert (R/'engine/models/qwen35/nf4_state.h').read_bytes()==(D/'source/engine/models/qwen35/nf4_state.h').read_bytes()
# All reusable backend/vendor objects stay original. No original object or library is a cleanup target.
bins=[p for p in D.rglob('*')if p.is_file()and p.suffix.lower()in{'.obj','.exe','.lib','.exp','.pdb','.dll','.map'}]
cleanup={'performed':False,'files':[pin(p)for p in sorted(bins)],'logical_bytes':sum(p.stat().st_size for p in bins),'scope':'Only new private component artifacts, including two own-directory hardlinks of the retained original DLL; no original SDK/backend/app object/library.'}
save(D/'cleanup-candidates.json',cleanup)
fail={'classification':'private_consumer_missing_required_caller_workspace','process':read(D/'component-run/process.json'),'stderr':'component-run/stderr.log','product_source_changed':False,'fix':'Exact same original data/dtype/shapes; cold allocate actual workspace_requirement on same resource and retain until Completion/destruction.','patch':'workspace-fix.patch','source_order_argument':'CPU ordinary operations use zero caller workspace; CUDA cublasLt requires 171 B (M1) and 480 B (M2), alignment256. No library checks were weakened.'}
save(D/'attempt1-component-failure.json',fail)
base=R/'.scratch/inference-system-review-20261025/nf4-component-values'
reader=R/'.scratch/validation/cpu-quant-mtp-c1/non-gguf/bnb-default-ops.py'
payload=D/'provenance';payload.mkdir(exist_ok=True)
shutil.copyfile(reader,payload/'bnb-default-ops.py')
shutil.copyfile(base/'complete.json',payload/'original-ranges-complete.json')
shutil.copyfile(base.parent/'nf4-quant-state/quant-state.bin',payload/'quant-state.bin')
for n in ('weight.bin','absmax.bin','nested_absmax.bin','codebooks.bin'):shutil.copyfile(base/n,payload/n)
shutil.copyfile(R/'.scratch/inference-system-review-20261025/text-r2-suffix/compile/command.json',payload/'original-app-compile-command.json')
shutil.copyfile(R/'.scratch/inference-system-review-20261025/text-r2-suffix/link/command.json',payload/'original-app-link-command.json')
summary={'status':'PASS_ORIGINAL_NF4_F16_COMPONENT','scope':{'artifact':'unsloth/Qwen3.8-27B-unsloth-bnb-4bit','revision':'8aa5f05d26b7205477066e1449e0af13f762a299','role':'model.language_model.layers.3.self_attn.k_proj.weight','original_shape':[1024,5120],'component_view':[3,5120],'original_input_bytes':9183,'components_not_whole_model':True,'no_graph_or_generation_claim':True,'no_other_formats_or_activation_claim':True},'actual_accounting':{'reference_processes':1,'consumer_workspace_failure_processes':1,'corrected_consumer_processes':1,'total_component_processes':3,'consumer_TUs_compiled':2,'links':2,'private_runner_prelink_guard_failure':1,'SDK_builds':0,'HTTP':0,'all_processes_terminal':True,'GPU_released':True},'independent_reference':ref,'consumer':current['consumer'],'processes':{'reference':read(D/'reference-run/process.json'),'first_consumer':read(D/'component-run/process.json'),'corrected_consumer':read(D/'attempt2-workspace/run/process.json')},'decode':{'explicit_output_dtype':'F16','all_15360_f16_bytes_equal_original_reader':True,'cold_decode_invocations_in_successful_consumer':1,'freeze_after_decode':True,'ordinary_reuses_same_W_per_backend':True,'CPU_W_final_unchanged':True,'forbidden_BF16_intermediate_changed_values':12361},'projection':{'ordinary_M':[1,2],'A_W_Y_dtype':'F16','accumulation':'F32','independent_FP64_and_FP32_exact_for_fixed_sparse_A':True,'FP16_rounding_witnesses_per_backend':[3,6],'CUDA_selected_provider':'cublasLt13.6.0','CPU_selected_provider':'ggml-cpu','non_bitwise_broad_quality_claim':False},'closure':{'original_recipe':pin(R/'.scratch/inference-system-review-20261025/text-r2-suffix/link/command.json'),'retained_inputs_equal_after_only_entry_and_output_redirection':True,'retained_reporting_object':'Original command contains existing reporting OBJ; unused by this consumer, retained unchanged.','standard_libraries':'Bare bcrypt.lib and other standard LIB-search names remain unchanged and are resolved using original MSVC LIB environment.','native_DLL':read(D/'native.json'),'canonical_metadata_header_unchanged':True,'consumer_image':pin(D/'attempt2-workspace/link/component.exe')},'first_failures':{'runner':'attempt1-runner-failure/failure.json','component':'attempt1-component-failure.json','both_preserved':True},'limitations':['Finite real first3 rows, not all1024 rows or full27B.','Direct Compute cold decode plus ordinary CPU/CUDA projection only; no Graph capture, model generation, other encodings, or throughput claim.','No per-token decode: successful component decodes once; each backend shares its immutable decoded W across M1/M2.'],'cleanup':cleanup}
save(D/'proof-summary.json',summary)
# Preserve source/commands/raw and small original+oracle payloads, never SDK/native image files.
exclude={'.obj','.exe','.lib','.exp','.pdb','.dll','.map','.zip'}
paths=[p for p in D.rglob('*')if p.is_file()and p.suffix.lower()not in exclude and p.name not in {'archive.json','proof-inventory.json','live.json'}]
inventory=[pin(p)for p in sorted(paths)]
save(D/'proof-inventory.json',{'files':inventory,'scope':'All payload paths are archive-relative below nf4-original-component; external referenced SDK/image paths are identity pins or original command operands, deliberately not payload.'})
paths.append(D/'proof-inventory.json')
with zipfile.ZipFile(D/'proof.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(paths):z.write(p,'nf4-original-component/'+p.relative_to(D).as_posix())
save(D/'archive.json',{'summary':pin(D/'proof-summary.json'),'archive':pin(D/'proof.zip'),'cleanup':pin(D/'cleanup-candidates.json'),'zip_files':len(paths)})
print(json.dumps(read(D/'archive.json'),indent=2));print('cleanup',len(bins),cleanup['logical_bytes'])
