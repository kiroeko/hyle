from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/mnt/c/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps';attempt=sys.argv[1] if len(sys.argv)>1 else '1';source_attempt=sys.argv[2] if len(sys.argv)>2 else '4';out=scratch/('g07-cuda-device-risks-'+attempt)
out.mkdir(exist_ok=False); started=time.monotonic()
prior=json.loads((scratch/('g07-cuda-source-'+source_attempt)/'result.json').read_text())
assert prior['state']=='SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING'
binary=Path(prior['test_artifact']['path']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==prior['test_artifact']['sha256']
env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
r=dict(state='RUNNING',pid=os.getpid(),candidate=prior['candidate'],identity=prior['identity'],artifact=prior['test_artifact'],stages=[],scope='Changed native packed kernels and original nine dtype/scale equations; shipping binary, real device tools. Original ATen decode OOM is unchanged and passed ordinary tests; not a whole-library sanitizer claim.')
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
for tool in ['memcheck','racecheck']:
 cmd=['/usr/local/cuda-13.3/bin/compute-sanitizer','--tool',tool,'--error-exitcode','86',str(binary),
      '--gtest_filter=CudaPackedWeights.*:OriginalDtypes/CudaMlxPrecision.*','--gtest_output=xml:'+str(out/(tool+'.xml'))]
 stamp=time.monotonic();log=out/(tool+'.log')
 with log.open('w') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(stage=tool,child_pid=p.pid);save();print(tool,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=tool,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
 assert 'ERROR SUMMARY: 0 errors' in log.read_text() or tool=='racecheck' and 'RACECHECK SUMMARY: 0 hazards' in log.read_text()
r['state']='CUDA_DEVICE_RISKS_PASS';save();print(r['state'],flush=True)
