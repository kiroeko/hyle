from pathlib import Path
import json,subprocess,sys,time
source_attempt=sys.argv[1]
job='/Users/kiro/hyle-scratch/compute-unified/g07-p1-apple/qualification-job-3.json'
print('Waiting for the existing Apple qualification3 terminal record; no overlapping heavy run.',flush=True)
while True:
 r=json.loads(subprocess.check_output(['ssh','kiro@172.22.10.198','cat',job],text=True))
 if r['state']=='TERMINAL':break
 time.sleep(12)
print('Apple qualification3 terminal',r.get('qualification_exit'),r.get('verify_exit'),flush=True)
base='/mnt/c/public/project-hyle/hyle/.scratch/inference-gaps/'
commands=[
 ['g07_cuda_source.py',source_attempt,'--public'],
 ['g07_cuda_consumers.py','c1',source_attempt],
 ['g07_cuda_risk.py','c1',source_attempt],
]+[['g07_cuda_host_risk.py',mode,'c1',source_attempt] for mode in ['asan','ubsan','tsan']]
for command in commands:
 subprocess.run(['wsl','-d','Ubuntu-24.04','--','python3',base+command[0],*command[1:]],check=True)
print('CUDA_C1_SOURCE_PUBLIC_N2_DEVICE_AND_HOST_FACETS_PASS',flush=True)
