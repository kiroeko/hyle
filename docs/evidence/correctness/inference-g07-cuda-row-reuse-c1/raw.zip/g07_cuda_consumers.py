from pathlib import Path
import hashlib,json,os,subprocess,sys,time
attempt=sys.argv[1] if len(sys.argv)>1 else '1'
root=Path('/mnt/c/public/project-hyle/hyle');scratch=root/'.scratch/inference-gaps';out=scratch/f'g07-cuda-model-consumers-{attempt}';out.mkdir(exist_ok=False)
source_attempt=sys.argv[2] if len(sys.argv)>2 else '4'
prior=json.loads((scratch/('g07-cuda-source-'+source_attempt)/'result.json').read_text());assert prior['state']=='SOURCE_TEST_PASS_RISKS_DELIVERY_PERF_PENDING'
source=Path(prior['source']);build=Path(prior['build']);env=os.environ.copy();env['PATH']='/usr/local/cuda-13.3/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/usr/local/cuda-13.3/targets/x86_64-linux/lib:/usr/lib/wsl/lib'
started=time.monotonic();r=dict(state='SETUP',pid=os.getpid(),candidate=prior['candidate'],identity=prior['identity'],stages=[],scope='Unmodified N2 fixture at full actual row/K dimensions, original public Direct/Graph routes; other 700+ model/schema cases not rerun.',max_jobs=2)
def save():
 r['elapsed_seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(stage,cmd):
 stamp=time.monotonic();log=out/(stage+'.log')
 with log.open('w') as stream:
  p=subprocess.Popen(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT);r.update(state='RUNNING',stage=stage,child_pid=p.pid);save();print(stage,p.pid,flush=True);code=p.wait()
 r['stages'].append(dict(stage=stage,command=cmd,exit_code=code,elapsed_seconds=time.monotonic()-stamp,log=str(log)));r.pop('child_pid',None);save()
 if code:r['state']='FAIL';save();print(log.read_text(errors='replace')[-6000:],flush=True);raise SystemExit(code)
try:
 run('configure',['cmake','-S',str(source),'-B',str(build),'-DHYLE_INSTALL=OFF','-DHYLE_BUILD_TESTS=ON','-DHYLE_BUILD_BENCH=OFF','-DHYLE_TEST_INSTRUMENTATION=OFF','-DCMAKE_PROJECT_INCLUDE='+str(scratch/'g07_cuda_profile.cmake')])
 run('manifest',['ninja','-C',str(build),'build.ninja'])
 run('native-reuse',['python3',str(scratch/'g04-g05/ce28_shipping_native_reuse_wsl.py'),'shared','g07-consumers-'+attempt])
 folder=scratch/('g04-g05/ce28-shared-native-reuse-g07-consumers-'+attempt);r['native_reuse']=json.loads((folder/'result.json').read_text());preview=folder/'reuse.ninja'
 targets=['g07_cuda_mlx_compute','g07_cuda_mlx_graph']
 dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True);(out/'dry-run.log').write_text(dry)
 assert 'Building CUDA object' not in dry and 'Re-running CMake' not in dry
 run('build',['ninja','-C',str(build),'-f',str(preview),'-j','2',*targets])
 for target in targets:
  binary=build/'bin'/target;run(target,[str(binary),'--gtest_filter=*N2ActualMlx*','--gtest_output=xml:'+str(out/(target+'.xml'))])
 r['state']='N2_FULL_SHAPE_DIRECT_GRAPH_PASS';save();print(r['state'],flush=True)
except BaseException as e:
 if r['state']!='FAIL':r.update(state='SETUP_FAIL',error=repr(e));save()
 raise
