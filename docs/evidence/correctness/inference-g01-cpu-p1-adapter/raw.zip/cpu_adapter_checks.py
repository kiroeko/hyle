from pathlib import Path
import subprocess,json,time,os,hashlib
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';build=repo/'.scratch/build-compute-v2-dev';result_file=out/'cpu-adapter-result.json';rows=json.loads(result_file.read_text())['stages'] if result_file.exists() else []
def run(stage,args,extra=None):
    attempt=1+sum(x['stage']==stage for x in rows);log=out/f'cpu-adapter-{stage}-{attempt}.log';start=time.monotonic();env=os.environ.copy();env.update(extra or {})
    with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
    row={'stage':stage,'command':args,'extra_environment':extra,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
    sources={name:hashlib.sha256((repo/'bench/inference_resident_sdpa'/name).read_bytes()).hexdigest() for name in ('cpu_reference.h','cpu_reference.cc','cpu_bench.cc','cpu-CMakeLists.txt')}
    result_file.write_text(json.dumps({'product_candidate':'d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f','scope':'CPU independent original native flash via same public typed-kernel/PreparedOperation lifecycle; oracle-only, not qualified P1','source_inputs':sources,'stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
    if r.returncode:
        with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2000));print(f.read(2000).decode('utf-8',errors='replace'))
        raise SystemExit(r.returncode)
if next((x for x in reversed(rows) if x['stage']=='configure'),{}).get('exit_code') != 0:
    run('configure',['cmake','-S',str(repo),'-B',str(build),'-DCMAKE_PROJECT_INCLUDE='+str(out/'cpu-source-project.cmake')])
run('build',['cmake','--build',str(build),'--target','g01_cpu_resident_bench','--parallel','2'])
run('oracle',[str(build/'bin/g01_cpu_resident_bench.exe')],{'HYLE_BENCH_VERIFY_ONLY':'1'})
