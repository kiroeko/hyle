from pathlib import Path
import hashlib, importlib.util, json, subprocess, time

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'.scratch/build-compute-v2-dev'
OUT = Path(__file__).resolve().parent/'vulkan-state'
OUT.mkdir(exist_ok=True)
source_records = json.loads((OUT.parent/'vulkan/commands.json').read_text())
spec = importlib.util.spec_from_file_location('environment', ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
environment = importlib.util.module_from_spec(spec)
spec.loader.exec_module(environment)
env = dict(environment.ENV, DISABLE_VULKAN_OBS_CAPTURE='1', VK_LOADER_LAYERS_DISABLE='~all~')
records = []

def identity(path):
    path=Path(path)
    return dict(path=str(path),bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def run(label,command):
    command=list(map(str,command)); start=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT,timeout=180)
    (OUT/(label+'.log')).write_bytes(p.stdout)
    records.append(dict(label=label,command=command,cwd=str(ROOT),
                        exit_code=p.returncode,seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,p.returncode,p.stdout.decode(errors='replace')[-5000:],flush=True)
    if p.returncode:raise SystemExit(p.returncode)

template=next(x['command'] for x in source_records if x['label']=='compile-compute_route_vulkan-vulkan_program')
objects=[]
sources=[ROOT/'src/graph_route_vulkan/vulkan_lowering.cc',
         ROOT/'src/graph_route_vulkan/vulkan_batch.cc',
         ROOT/'tests/compute_state/public_state_consumer.cc']
for source in sources:
    obj=OUT/(source.stem+'.obj');command=list(template)
    command[command.index('/c')+1]=str(source)
    command=[('/Fo'+str(obj)) if x.startswith('/Fo') else x for x in command]
    run('compile-'+source.stem,command);objects.append(obj)
command=list(next(x['command'] for x in source_records if x['label']=='link'))
command=[x for x in command if not x.endswith('compute_route_vulkan-recurrent_test.obj')]
exe=OUT/'public-state-consumer.exe'
command=[('/OUT:'+str(exe)) if x.startswith('/OUT:') else
         ('/MAP:'+str(exe.with_suffix('.map'))) if x.startswith('/MAP:') else x
         for x in command]
command.extend(map(str,objects))
command.extend(str(BASE/'bin'/(n+'.lib')) for n in ['hyle_graph','hyle_graph_batch'])
run('link',command)
sources.append(ROOT/'tests/compute_state/mtp_prefix_consumer.h')
(OUT/'identities.json').write_text(json.dumps(dict(
    sources=[identity(p) for p in sources],executable=identity(exe),
    reused_component_manifest=str(OUT.parent/'vulkan/identities.json'),
    native_sdk_rebuilt=False),indent=2)+'\n')
run('consumer',[exe])
