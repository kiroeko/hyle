from pathlib import Path
import hashlib, json, subprocess, zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent

def identity(path):
    path=Path(path)
    return dict(path=str(path.resolve()),bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

measured=json.loads((OUT/'source-identities.json').read_text())
measured_payloads={}
for entry in measured:
    path=Path(entry['path']);payload=path.read_bytes()
    if hashlib.sha256(payload).hexdigest()!=entry['sha256']:
        assert path.name=='gdn_snapshot_fixture.h',path
        # A later, unused RecurrentFixture was appended for the Vulkan case.
        # Recover the exact measured header, then verify its pre-build SHA.
        payload=payload.split(b'\nstruct RecurrentFixture final {',1)[0]
        payload+=b'} // namespace gdn_snapshot_fixture\n'
        assert hashlib.sha256(payload).hexdigest()==entry['sha256']
    measured_payloads[str(path.relative_to(ROOT))]=payload

sources=[
    'include/hyle/compute/operation.h','include/hyle/compute/model_ops.h',
    'src/compute_ops/operation.cc','src/compute_provider_ggml/ggml_cpu_provider.cc',
    'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
    'src/compute_provider_ggml_cuda/tensor_program.cc',
    'src/compute_provider_ggml_cuda/tensor_program.h',
    'src/compute_provider_ggml_cuda/program.h',
    'src/compute_provider_ggml_vulkan/region.cc',
    'src/compute_route_vulkan/vulkan_region.cc',
    'src/compute_provider_ggml_metal/native_program.cc',
    'src/compute_provider_ggml_metal/native_program.h',
    'tests/compute_ops/operation_test.cc',
    'tests/compute_provider_ggml/cpu_provider_test.cc',
    'tests/compute_provider_ggml_cuda/tensor_test.cc',
    'tests/compute_route_vulkan/recurrent_test.cc',
    'tests/compute_route_apple/recurrent_test.cc',
    'tests/compute_models/gdn_snapshot_fixture.h',
    'tests/compute_state/public_state_consumer.cc',
    'tests/compute_state/mtp_prefix_consumer.h']
summary={
    'kind':'MTP recurrent computation correctness, not a complete model/MTP engine or performance claim',
    'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'contract':{'snapshot_count':'uint32 default 1; 1<=K<=T; six inputs/two outputs',
                'K1':'original rank-four final state and original copy/allocation path',
                'Kgt1':'F32 [B,K,Hv,Dv,Dk], chronological S(T-K+1)..ST, excluding S0',
                'implementation':'native K snapshots plus device GET_ROWS; no payload readback or per-token rerun',
                'head_mapping':'existing cyclic h%Hk; contiguous models explicitly expand/reorder',
                'fused_recurrent':'B1/T>0, existing D/head/F32 domain; raw a/b token axis, broadcast coefficient/dt; custom ID version 8'},
    'validation':{
        'schema':'6/6 targeted existing/new tests PASS',
        'CPU_FFA4_baseline':'4/4 PASS',
        'CPU_FFA4_AVX2':'4/4 PASS using retained current causal ABI2 module',
        'CPU_mixed456_baseline':'4/4 PASS',
        'CPU_case':'B2/T5/Hk2/Hv6/D32 K1/3/5 seed0/7 rebind and all outputs vs independent FP64; initial state unchanged',
        'CPU_fused_case':'B1/T3/H16/D128/K3 raw gates and broadcast parameters vs independent FP64; same 3e-6 budget',
        'Vulkan':'2/2 canonical targeted tests PASS, actual current provider and route host TUs',
        'Vulkan_public_consumer':'PASS: two-step state journey; accept0..4 GDN/conv/KV atomic prefix and own-state continuation Direct/Graph',
        'CUDA_Apple':'integrator/Metal-agent evidence is separate; these sources are frozen here but their results are not counted by this package'},
    'limits':[
        'No full SDK/native shader rebuild, download or SDK copy; no performance measurements.',
        'Vulkan uses its existing locked native library and generated shader object; all ordinary route host TUs were fresh.',
        'CPU flags inherit the historical diagnostic provider version string hadamard-unary-overlay; actual fresh source identities and new numerical cases establish this batch.',
        'CPU measured fixture header predates an unused RecurrentFixture declaration appended for Vulkan. Its exact pre-build SHA is preserved and verified separately.',
        'No end-to-end real-weight proposal sampling/target verification engine is claimed.'],
    'sources':[identity(ROOT/p) for p in sources]}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
artifacts=[identity(p) for p in OUT.rglob('*') if p.is_file() and p.suffix.lower() in ['.obj','.exe','.dll','.lib','.pdb','.exp']]
(OUT/'cleanup-candidates.json').write_text(json.dumps({'scope':str(OUT.resolve()),
    'execution':'Not deleted. Integrator may retain fresh mixed provider/selector/allocator and operation objects until integration finishes.',
    'files':artifacts,'count':len(artifacts),'logical_bytes':sum(x['bytes'] for x in artifacts),
    'preserve':'Sources, commands, logs, maps, data, source archive and all external SDK/native/foundation caches.'},indent=2)+'\n')
archive=OUT/'source-results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for relative,payload in measured_payloads.items():z.writestr('CPU-measured/'+relative.replace('\\','/'),payload)
    for relative in sources:z.write(ROOT/relative,'applied/'+relative)
    for path in sorted(OUT.rglob('*')):
        if path.is_file() and path.suffix.lower() in ['.py','.json','.log','.map']:
            z.write(path,'validation/'+path.relative_to(OUT).as_posix())
print(json.dumps({'summary':identity(OUT/'summary.json'),'archive':identity(archive),
                  'cleanup':identity(OUT/'cleanup-candidates.json')},indent=2))
