from pathlib import Path
import hashlib, importlib.util, json, os, shlex, subprocess, time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
HAD = ROOT / '.scratch/perf-review-2026-10-18/cpu-hadamard'
spec = importlib.util.spec_from_file_location('had', HAD / 'run.py')
had = importlib.util.module_from_spec(spec)
spec.loader.exec_module(had)
records = []

def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def run(label, command):
    command = list(map(str, command))
    begin = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=had.ENV,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=180)
    (OUT / (label + '.log')).write_bytes(result.stdout)
    records.append(dict(label=label, command=command, cwd=str(ROOT),
                        exit_code=result.returncode,
                        seconds=time.monotonic()-begin))
    (OUT / 'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(label, result.returncode, result.stdout.decode(errors='replace')[-2500:], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

def compile_cpp(cfg, path, name, extra=()):
    destination = cfg['folder'] / (name + '.obj')
    run(cfg['pin'] + '-' + name, [had.CL, *had.hyle_flags(cfg), *extra,
                                 path, '/Fo'+str(destination)])
    return destination

def link(cfg, name, objects, schema=False):
    destination = cfg['folder'] / (name + '.exe')
    native = ROOT / '.scratch/perf-review-2026-10-18/cpu-native-causal' / cfg['pin'] / 'native-baseline.obj'
    libs = had.common_libs(dict(cfg, folder=Path(cfg['pin'])))
    run(cfg['pin']+'-'+name+'-link', [had.LINK, '/nologo', '/MACHINE:X64',
        '/SUBSYSTEM:CONSOLE', '/INCREMENTAL:NO', '/NODEFAULTLIB:LIBCMT',
        '/OUT:'+str(destination), '/MAP:'+str(destination.with_suffix('.map')),
        *objects, *([] if schema else [native]), *libs,
        had.BASE/'lib/gtest.lib', had.BASE/'lib/gtest_main.lib', *had.SYSTEM])
    return destination

def allocator(cfg):
    source = ROOT / '.scratch/perf-review-2026-10-18/cpu-math-attention' / cfg['pin'] / 'ggml-alloc.fallible.c'
    db = json.loads(cfg['compdb'].read_text())
    row = next(x for x in db if Path(x['file']).name == 'ggml-alloc.c')
    args = [x.strip('"') for x in shlex.split(row['command'], posix=False)][1:]
    args = [x for x in args if x.lower() not in ['/c', '-c', '/fs']
            and not x.lower().startswith(('/fo', '/fd'))
            and x.replace('\\', '/') != row['file'].replace('\\', '/')]
    obj = cfg['folder'] / 'allocator.obj'
    run(cfg['pin']+'-allocator', [had.CL, *args, '/utf-8', '/c', source, '/Fo'+str(obj)])
    return obj

sources = [ROOT/'src/compute_ops/operation.cc',
           ROOT/'src/compute_provider_ggml/ggml_cpu_provider.cc',
           ROOT/'tests/compute_ops/operation_test.cc',
           ROOT/'tests/compute_provider_ggml/cpu_provider_test.cc',
           ROOT/'tests/compute_models/gdn_snapshot_fixture.h',
           ROOT/'include/hyle/compute/operation.h',
           ROOT/'include/hyle/compute/model_ops.h']
(OUT/'source-identities.json').write_text(json.dumps([identity(p) for p in sources], indent=2)+'\n')
shared_operation = None
for pin in ['ffa4', 'mixed']:
    cfg = dict(had.PINS[pin], pin=pin, folder=OUT/pin)
    cfg['folder'].mkdir(exist_ok=True)
    if shared_operation is None:
        shared_operation = compile_cpp(cfg, sources[0], 'operation')
        tests = compile_cpp(cfg, sources[2], 'schema-tests')
        schema_exe = link(cfg, 'schema', [shared_operation, tests], schema=True)
        run('schema-tests', [schema_exe, '--gtest_filter=OperationGatedDeltaNet.*:OperationModelOps.RecurrentRegion*'])
    provider = compile_cpp(cfg, sources[1], 'provider')
    tests = compile_cpp(cfg, sources[3], 'provider-tests')
    alloc = allocator(cfg)
    selector = compile_cpp(cfg, ROOT/'src/compute_ggml_runtime/cpu_program.cc', 'selector-baseline')
    exe = link(cfg, 'tests-baseline', [shared_operation, provider, tests, alloc, selector])
    filter = '--gtest_filter=GgmlCpuProvider.*GatedDeltaNet*:GgmlCpuProvider.MatureKda*:GgmlCpuProvider.RecurrentTokenBlock*'
    run(pin+'-tests-baseline', [exe, filter])
    if pin == 'ffa4':
        module = ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal'/pin/'hyle_ggml_cpu_avx2_ffa4_causal_overlay.dll'
        selected = compile_cpp(cfg, ROOT/'src/compute_ggml_runtime/cpu_program.cc', 'selector-selected',
            ['/DHYLE_GGML_CPU_AVX2_PROGRAM=1', '/DHYLE_GGML_CPU_PROGRAM_LIBRARY="'+str(module).replace('\\','/')+'"'])
        exe = link(cfg, 'tests-selected', [shared_operation, provider, tests, alloc, selected])
        run(pin+'-tests-selected', [exe, filter])
print('All targeted schema/CPU GDN tests completed.', flush=True)
