from pathlib import Path
import hashlib, importlib.util, json, os, shlex, subprocess, time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / 'vulkan'
OUT.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('cpu_gdn', ROOT/'.scratch/perf-review-2026-10-18/cpu-hadamard/run.py')
envmod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(envmod)
ENV = dict(envmod.ENV, DISABLE_VULKAN_OBS_CAPTURE='1', VK_LOADER_LAYERS_DISABLE='~all~')
CACHE = ROOT/'.scratch/bench-api-runtime/vulkan/build'
db = json.loads((CACHE/'compile_commands.json').read_text())
records = []

def identity(p):
    p = Path(p)
    return dict(path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def run(label, command):
    command = list(map(str, command))
    start = time.monotonic()
    p = subprocess.run(command, cwd=ROOT, env=ENV, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=180)
    (OUT/(label+'.log')).write_bytes(p.stdout)
    records.append(dict(label=label, command=command, cwd=str(ROOT),
                        exit_code=p.returncode, seconds=time.monotonic()-start))
    (OUT/'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    print(label, p.returncode, p.stdout.decode(errors='replace')[-2500:], flush=True)
    if p.returncode:
        raise SystemExit(p.returncode)

def compile(path, template=None):
    path = Path(path)
    key = '/'+str(path.relative_to(ROOT)).replace('\\','/')
    row = next((r for r in db if r['file'].replace('\\','/').endswith(key)), None)
    if row is None:
        row = next(r for r in db if r['file'].replace('\\','/').endswith(template or '/compute_route_vulkan/vulkan_program.cc'))
    words = [x.strip('"') for x in shlex.split(row['command'], posix=False)]
    args = [x for x in words[1:] if x.lower() not in ['/c','-c','/fs']
            and not x.lower().startswith(('/fo','/fd'))
            and x.replace('\\','/') != row['file'].replace('\\','/')]
    args += ['/I'+str(ROOT/'src/compute_provider_ggml_vulkan'),
             '/external:I'+str(envmod.GTEST), '/DNOMINMAX']
    obj = OUT/(path.parent.name+'-'+path.stem+'.obj')
    run('compile-'+obj.stem, [envmod.CL, *args, '/c', path, '/Fo'+str(obj)])
    return obj

objects=[]
sources=[]
for directory in ['compute_provider_ggml_vulkan', 'compute_route_vulkan']:
    for path in sorted((ROOT/'src'/directory).glob('*.cc')):
        sources.append(path)
        objects.append(compile(path))
test = ROOT/'tests/compute_route_vulkan/recurrent_test.cc'
sources.append(test)
objects.append(compile(test))
line = next(x for x in (CACHE/'build.ninja').read_text().splitlines() if x.startswith('  LINK_LIBRARIES = '))
libraries=[]
for word in shlex.split(line.split(' = ',1)[1], posix=False):
    p=Path(word.strip('"'))
    if p.stem in ['g01_nr_nanobench']:
        continue
    if p.stem.startswith('hyle_') or p.stem=='mimalloc_static':
        fresh=envmod.BASE/'bin'/p.name
        if fresh.exists():
            p=fresh
    if not p.is_absolute() and ('/' in str(p) or '\\' in str(p)):
        p=CACHE/p
    libraries.append(p)
libraries += [envmod.BASE/'bin/hyle_simd.lib', envmod.BASE/'lib/gtest.lib',
              envmod.BASE/'lib/gtest_main.lib']
exe=OUT/'recurrent-tests.exe'
run('link',[envmod.LINK,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE',
    '/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(exe),
    '/MAP:'+str(exe.with_suffix('.map')), ROOT/'.scratch/mtp-gdn-2026-10-18/ffa4/operation.obj',
    *objects,*libraries,*envmod.SYSTEM])
(OUT/'identities.json').write_text(json.dumps(dict(
    sources=[identity(p) for p in sources],
    libraries=[identity(p) for p in libraries if p.is_file()],
    executable=identity(exe), native_sdk_rebuilt=False,
    runtime_layers={'DISABLE_VULKAN_OBS_CAPTURE':'1','VK_LOADER_LAYERS_DISABLE':'~all~'}),indent=2)+'\n')
run('tests',[exe,'--gtest_filter=VulkanRecurrent.GatedDeltaNetSnapshotsKeepBatchAndTimeOrder:VulkanRecurrent.RecurrentTokenBlockBroadcastsParametersAndPublishesSnapshots'])
