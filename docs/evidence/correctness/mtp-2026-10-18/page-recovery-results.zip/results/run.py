from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path.cwd(); OUT=ROOT/'.scratch/mtp-page-recovery'; BUILD=ROOT/'.scratch/build-compute-v2-dev'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache=read_cache(BUILD); env=windows_compiler_environment(cache); env['VSLANG']='1033'
cl=cache['CMAKE_CXX_COMPILER']; link=str(Path(cl).with_name('link.exe'))
old=json.loads((ROOT/'.scratch/perf-review-2026-10-18/state-prefix/state_versions_test.cc-compile-command.json').read_text())
flags=old[1:next(i for i,a in enumerate(old) if a.startswith('/Fo'))]
# The earlier command already declares HYLE_STATIC and only needs gtest headers.
commands=[]
def run(name,argv):
 command={'argv':list(map(str,argv)),'cwd':str(BUILD),'timeout_seconds':90}
 (OUT/(name+'.command.json')).write_text(json.dumps(command,indent=2)+'\n')
 begin=time.monotonic(); p=subprocess.run(command['argv'],cwd=BUILD,env=env,capture_output=True,timeout=90)
 (OUT/(name+'.stdout.txt')).write_bytes(p.stdout); (OUT/(name+'.stderr.txt')).write_bytes(p.stderr)
 command.update(returncode=p.returncode,wall_seconds=time.monotonic()-begin); commands.append(command)
 (OUT/(name+'.result.json')).write_text(json.dumps(command,indent=2)+'\n')
 print(name,p.returncode,flush=True)
 if p.returncode:
  print(p.stdout.decode(errors='replace')); print(p.stderr.decode(errors='replace')); raise SystemExit(p.returncode)
 return p.stdout.decode(errors='replace')
for stem,source in [('paged_arena',ROOT/'src/compute_batch/paged_arena.cc'),('paged_arena_test',ROOT/'tests/compute_batch/paged_arena_test.cc')]:
 run(stem+'-compile',[cl,*flags,'/Fo'+str(OUT/(stem+'.obj')),str(source)])
libs=[BUILD/'lib/gtest_main.lib',BUILD/'lib/gtest.lib']+[BUILD/'bin'/(name+'.lib') for name in ['hyle_compute_batch','hyle_compute_state','hyle_compute_backend_cpu','hyle_compute','hyle_compute_ops','hyle_mem','hyle_platform','hyle_error','mimalloc_static']]
run('tests-link',[link,'/nologo','/machine:x64','/INCREMENTAL:NO','/subsystem:console','/out:'+str(OUT/'page-tests.exe'),'/MAP:'+str(OUT/'page-tests.map'),str(OUT/'paged_arena.obj'),str(OUT/'paged_arena_test.obj'),*libs,'bcrypt.lib','PowrProf.lib','advapi32.lib','ws2_32.lib','userenv.lib','psapi.lib'])
print(run('tests',[OUT/'page-tests.exe','--gtest_filter=PagedArena.*:PagedAdmission.*']))
def identity(p):
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(OUT/'identity.json').write_text(json.dumps({'scope':'Fresh paged_arena and its existing test TU only, cached static dependencies, no configure/native/GPU build. F1 use-lifetime controls are unit tests, not a real GPU fault experiment.','compiler':cl,'sources':[identity(ROOT/p) for p in ['include/hyle/compute/paged_arena.h','src/compute_batch/paged_arena.cc','tests/compute_batch/paged_arena_test.cc','docs/user/batch-attention.md']],'linked_libraries':[identity(p) for p in libs],'artifacts':[identity(OUT/p) for p in ['paged_arena.obj','paged_arena_test.obj','page-tests.exe']]},indent=2)+'\n')
