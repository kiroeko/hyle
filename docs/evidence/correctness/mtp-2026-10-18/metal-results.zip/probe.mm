#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>
#include "src/compute_provider_ggml_metal/native_program.h"
#include "tests/compute_models/gdn_snapshot_fixture.h"
#include "hyle/compute/model_ops.h"

namespace c = hyle::compute;
namespace m = c::ggml_metal;
struct Buffers {
  std::vector<id<MTLBuffer>> values;
  ~Buffers() { for (auto buffer : values) [buffer release]; }
};

bool run_case(id<MTLDevice> device, gdn_snapshot_fixture::Fixture fixture,
              std::uint32_t snapshots, bool fused) {
  auto descriptions = std::vector<c::TensorDesc>(fixture.inputs.begin(), fixture.inputs.end());
  auto values = std::vector<std::vector<float>>(fixture.data.begin(), fixture.data.end());
  auto operation = c::Operation(c::GatedDeltaNet{.snapshot_count = snapshots});
  if (fused) {
    const auto h = fixture.value_heads;
    std::vector<float> a(fixture.tokens*h), b(a.size()), negative(h), dt(h);
    for (std::int64_t head=0; head<h; ++head) {
      negative[head] = -0.15F-float(head%3)*0.025F;
      dt[head] = float(head%7-3)*0.03F;
    }
    for (std::int64_t t=0; t<fixture.tokens; ++t)
      for (std::int64_t head=0; head<h; ++head) {
        const auto i=t*h+head;
        a[i]=float(i%13-6)*0.07F; b[i]=float(i%11-5)*0.08F;
        fixture.data[3][i]=negative[head]*float(std::log1p(std::exp(double(a[i]+dt[head]))));
        fixture.data[4][i]=float(1.0/(1.0+std::exp(-double(b[i]))));
      }
    const std::array<std::int64_t,4> parameter_shape{1,1,h,1};
    const auto parameter=c::TensorDesc::dense(c::DataType::kFloat32,parameter_shape).value();
    descriptions={fixture.inputs[0],fixture.inputs[1],fixture.inputs[2],fixture.inputs[3],fixture.inputs[4],parameter,parameter,fixture.inputs[5]};
    values={fixture.data[0],fixture.data[1],fixture.data[2],a,b,negative,dt,fixture.data[5]};
    operation=c::model_ops::recurrent_gated_delta_net(snapshots);
  }
  const auto expected=fixture.oracle(snapshots);
  Buffers buffers;
  auto made=m::NativeProgram::create(operation,descriptions);
  if (!made) {
    const auto message=made.error().message();
    std::fprintf(stderr,"create failed: %.*s\n",int(message.size()),message.data());
    return false;
  }
  auto program=std::move(*made);
  std::vector<m::BufferView> ports;
  for (std::size_t i=0; i<descriptions.size(); ++i) {
    auto buffer=[device newBufferWithLength:descriptions[i].required_bytes().value() options:MTLResourceStorageModeShared];
    if (!buffer) return false;
    buffers.values.push_back(buffer);
    std::memcpy([buffer contents],values[i].data(),values[i].size()*sizeof(float));
    ports.push_back({(__bridge void*)buffer,0});
  }
  auto output=[device newBufferWithLength:program->output_bytes() options:MTLResourceStorageModeShared];
  if (!output) return false;
  buffers.values.push_back(output);
  ports.push_back({(__bridge void*)output,0});
  for (int repeat=0; repeat<2; ++repeat) {
    const auto status=program->run(ports);
    if (!status.ok()) {
      const auto message=status.message();
      std::fprintf(stderr,"run failed: %.*s\n",int(message.size()),message.data());
      return false;
    }
    for (std::size_t port=0; port<2; ++port) {
      auto *actual=reinterpret_cast<const float*>(static_cast<const std::byte*>([output contents])+program->output_offset(port));
      double maximum=0;
      for (std::size_t i=0; i<expected[port].size(); ++i) {
        if (!std::isfinite(actual[i])) return false;
        maximum=std::max(maximum,std::abs(double(actual[i])-expected[port][i]));
      }
      std::printf("fused=%d B=%lld T=%lld K=%u replay=%d port=%zu max_error=%.12g\n",fused,static_cast<long long>(fixture.batches),static_cast<long long>(fixture.tokens),snapshots,repeat,port,maximum);
      if (maximum>=3e-6) return false;
    }
  }
  const auto initial=values.size()-1;
  if (std::memcmp([buffers.values[initial] contents],values[initial].data(),values[initial].size()*sizeof(float))!=0) return false;
  return true;
}

int main() {
  @autoreleasepool {
    id<MTLDevice> device=MTLCreateSystemDefaultDevice();
    if (!device) return 2;
    bool good=true;
    for (auto k:{1U,3U,5U}) {
      for (auto seed:{0,7}) good=good && run_case(device,gdn_snapshot_fixture::Fixture(seed),k,false);
      good=good && run_case(device,gdn_snapshot_fixture::Fixture(0,1,5,16,16,128),k,true);
    }
    [device release];
    return good?0:3;
  }
}
