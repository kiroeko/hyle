import json
import pathlib
import re
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
sdk = pathlib.Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
vendor = pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-apple/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-da5abe30b13e6512')
common = ['/usr/bin/clang++', '-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64',
          '-DHYLE_STATIC', '-DMLX_STATIC', '-DHYLE_COMPUTE_APPLE=1',
          '-DHYLE_COMPUTE_ROUTE_APPLE_API=', '-DHYLE_GRAPH_ROUTE_APPLE_API=',
          '-Wall', '-Wextra', '-Wpedantic', '-Werror',
          '-I'+str(root/'include'), '-I'+str(root),
          '-I'+str(root/'src/compute_ops'), '-I'+str(root/'src/compute_ggml_runtime'),
          '-I'+str(root/'src/compute_route_apple'), '-I'+str(root/'src/compute'),
          '-I'+str(vendor/'include'), '-isystem', str(sdk/'include'),
          '-isystem', str(sdk/'include/metal_cpp')]
# Source headers use CMake-generated per-module visibility. These are all
# empty for this existing static SDK closure; no installed ABI is changed.
api_macros=set()
for header in (root/'include').rglob('*.h'):
    api_macros.update(re.findall(r'\bHYLE_[A-Z0-9_]+_API\b',header.read_text()))
common += ['-D'+macro+'=' for macro in sorted(api_macros)]

def call(name, command):
    (root/(name+'.command.json')).write_text(json.dumps(command, indent=2)+'\n')
    result = subprocess.run(command, cwd=root, text=True, capture_output=True)
    (root/(name+'.stdout.txt')).write_text(result.stdout)
    (root/(name+'.stderr.txt')).write_text(result.stderr)
    print(name, result.returncode, result.stdout[-4000:], result.stderr[-5000:], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

def run_consumer():
    metallib=root/'mlx.metallib'
    if not metallib.exists():
        metallib.symlink_to('/Users/kiro/hyle-scratch/compute-unified/library-review-20261018-apple-sink-q128/mlx.metallib')
    call('consumer-run',[str(root/'public_state_consumer')])

if '--run-only' in sys.argv:
    run_consumer()
    raise SystemExit(0)

objects=[]
for name, source in [('ops','src/compute_ops/operation.cc'),
                     ('native','src/compute_provider_ggml_metal/native_program.cc'),
                     ('state','src/compute_state/state_versions.cc'),
                     ('context','src/compute_route_apple/apple_context.cc'),
                     ('operations','src/compute_route_apple/apple_operations.cc'),
                     ('recurrent','src/compute_route_apple/apple_recurrent.cc'),
                     ('tensor','src/compute_route_apple/apple_tensor.cc'),
                     ('graph','src/graph_route_apple/apple_lowering.cc'),
                     ('consumer','tests/compute_state/public_state_consumer.cc')]:
    target=root/(name+'.o')
    call('consumer-compile-'+name, common+['-c',str(root/source),'-o',str(target)])
    objects.append(str(target))

def remainder(name, excluded):
    archive=sdk/'lib'/('libhyle_'+name+'.a')
    members=subprocess.check_output(['ar','-t',str(archive)],text=True).splitlines()
    paths=[]
    for member in members:
        if not member.endswith('.o') or member in excluded:
            continue
        path=root/(name+'-'+member)
        with path.open('wb') as output:
            subprocess.run(['ar','-p',str(archive),member],stdout=output,check=True)
        paths.append(str(path))
    target=root/(name+'-remainder.a')
    call('consumer-archive-'+name,['ar','rcs',str(target)]+paths)
    return str(target)

ops=remainder('compute_ops',{'operation.cc.o'})
route=remainder('compute_route_apple',{'apple_context.cc.o','apple_operations.cc.o','apple_recurrent.cc.o','apple_tensor.cc.o'})
link=['/usr/bin/clang++','-O3','-std=c++23','-arch','arm64','-o',str(root/'public_state_consumer')]+objects
link += [str(sdk/'lib/libhyle_graph.a'), route,
         str(sdk/'lib/libhyle_compute_stream.a'),
         str(sdk/'lib/libhyle_compute_batch.a'),str(sdk/'lib/libhyle_compute.a'),ops]
libraries=['compute_provider_ggml_metal','compute_ggml_runtime',
           'simd','sched','container','mem_vm','mem','platform_thread','time','platform','error']
link += [str(sdk/'lib'/('libhyle_'+name+'.a')) for name in libraries]
link += [str(sdk/'lib'/name) for name in ['libmimalloc_static.a','libggml.a','libggml-metal.a','libggml-base.a','libmlx.a']]
link += ['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore']
link += ['-Wl,-map,'+str(root/'public_state_consumer.map')]
call('consumer-link',link)
run_consumer()
