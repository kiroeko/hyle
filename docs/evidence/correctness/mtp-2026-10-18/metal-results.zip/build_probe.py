import json
import pathlib
import re
import subprocess

root = pathlib.Path(__file__).resolve().parent
sdk = pathlib.Path('/Users/kiro/hyle-scratch/g09-air-direct-20261017/final-1dbfce9a0/apple-sdk')
vendor = pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/a-apple/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-da5abe30b13e6512')
common = ['/usr/bin/clang++', '-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64',
          '-DHYLE_STATIC', '-DMLX_STATIC', '-DHYLE_COMPUTE_APPLE=1',
          '-Wall', '-Wextra', '-Wpedantic', '-Werror',
          '-I'+str(root/'include'), '-I'+str(root),
          '-I'+str(root/'src/compute_ops'), '-I'+str(root/'src/compute_ggml_runtime'),
          '-I'+str(vendor/'include'), '-isystem', str(sdk/'include')]
api_macros=set()
for header in (root/'include').rglob('*.h'):
    api_macros.update(re.findall(r'\bHYLE_[A-Z0-9_]+_API\b',header.read_text()))
common += ['-D'+macro+'=' for macro in sorted(api_macros)]

def call(name, command):
    (root/(name+'.command.json')).write_text(json.dumps(command, indent=2)+'\n')
    result = subprocess.run(command, cwd=root, text=True, capture_output=True)
    (root/(name+'.stdout.txt')).write_text(result.stdout)
    (root/(name+'.stderr.txt')).write_text(result.stderr)
    print(name, result.returncode, result.stdout[-2000:], result.stderr[-3500:], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

objects=[]
for name, source in [('ops','src/compute_ops/operation.cc'),
                     ('native','src/compute_provider_ggml_metal/native_program.cc'),
                     ('probe','probe.mm')]:
    target=root/(name+'.o')
    call('compile-'+name, common+['-c',str(root/source),'-o',str(target)])
    objects.append(str(target))
libraries=['compute_provider_ggml_metal','compute_ggml_runtime',
           'simd','container','mem_vm','mem','platform_thread','time','platform','error']
link=['/usr/bin/clang++','-std=c++23','-arch','arm64','-o',str(root/'probe')]+objects
for name in ['tensor_desc.cc.o','low_precision.cc.o','weight_decode.cc.o','sampling_ops.cc.o']:
    target=root/('ops-'+name)
    with target.open('wb') as output:
        subprocess.run(['ar','-p',str(sdk/'lib/libhyle_compute_ops.a'),name],stdout=output,check=True)
    link.append(str(target))
link += [str(sdk/'lib'/('libhyle_'+name+'.a')) for name in libraries]
link += [str(sdk/'lib'/name) for name in ['libmimalloc_static.a','libggml.a','libggml-metal.a','libggml-base.a']]
link += ['-framework','Foundation','-framework','Metal','-framework','MetalKit','-framework','QuartzCore']
call('link-probe',link)
call('run-probe',[str(root/'probe')])
