#define HYLE_GGML_CUDA_PROVIDER_VERSION "ggml-456172ec+legacy-native-4e1a7b2f39afe15d+q-block-review"
