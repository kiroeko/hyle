// Validation-only component assembly. This deliberately does not certify the
// full default CUDA provider distribution. All bindings/state use public APIs.
#include <hyle/graph/cuda.h>
#include <hyle/graph/providers/ggml_cuda.h>
#include <hyle/compute/backends/cuda.h>
#include <array>
namespace hyle::graph::cuda {
Result<compute::Context> create_context(compute::cuda::DefaultContextOptions options) noexcept {
 HYLE_ASSIGN_OR_RETURN(auto device,compute::cuda::device(options.device_ordinal));
 const std::array providers{compute::ProviderBinding{ggml_cuda::provider()}};
 return compute::Context::create(device,{.metadata_allocator=options.metadata_allocator,.providers=providers});
}
Result<CompiledGraph> compile(const Graph &graph,const compute::Context &context,mem::MemoryResourceRef resource,CompileOptions options) noexcept {
 const std::array storage{StorageDomain{.resource=resource}};
 const std::array targets{ExecutionTarget{.context=&context,.default_storage=StorageDomainId{0}}};
 const std::array lanes{ExecutionLane{.target=ExecutionTargetId{0}}};
 return graph::compile(graph,{.storage_domains=storage,.targets=targets,.lanes=lanes},options);
}
}

#if defined(HYLE_COMPUTE_CPU)
#include <hyle/graph/cpu.h>
#include <hyle/compute/providers/ggml_cpu.h>
namespace hyle::graph::cpu {
Result<compute::Context> create_context(compute::cpu::DefaultContextOptions options) noexcept {
 const std::array providers{compute::ProviderBinding{compute::ggml_cpu::provider({.executor=options.executor,.native_threads=options.native_threads})}};
 return compute::Context::create(compute::cpu::device(),{.metadata_allocator=options.metadata_allocator,.providers=providers});
}
}
#endif
