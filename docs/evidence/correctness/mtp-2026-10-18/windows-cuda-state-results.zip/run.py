from pathlib import Path
import json,os,re,subprocess,sys,time,hashlib
ROOT=Path.cwd();OUT=ROOT/'.scratch/mtp-completion';BASE=ROOT/'.scratch/build-compute-v2-dev';OLD=ROOT/'.scratch/perf-review-2026-10-18/ggml-attention-provider'
sys.path.insert(0,str(ROOT/'scripts'))
from hyle_environment import windows_compiler_environment
from hyle_support import read_cache
cache=read_cache(BASE);env=windows_compiler_environment(cache);env['VSLANG']='1033'
cl=Path(cache['CMAKE_CXX_COMPILER']);link=cl.with_name('link.exe')
toolkit=Path('C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA/v13.3')
native=ROOT/'.scratch/legacy-root/hyle-scratch/ggml-native-static'
source=native/'src/compute_ggml_runtime/source-4e1a7b2f39afe15d'
env['PATH']=str(toolkit/'bin/x64')+os.pathsep+str(BASE/'bin')+os.pathsep+env['PATH']
flags=['/nologo','/c','/std:c++latest','/EHsc','/Zc:preprocessor','/Zc:__cplusplus','/utf-8','/O2','/Ob2','/MD','/DNDEBUG','/permissive-','/bigobj','/W4','/WX','/wd4324','/wd4702','/DHYLE_STATIC','/DNOMINMAX','/DGGML_USE_CUDA','/DHYLE_COMPUTE_CUDA=1','/DHYLE_COMPUTE_GGML_CUDA=1',
'/FI'+str(OLD/'provider-version.h')]
for p in ['include','src/compute','src/compute_provider_ggml_cuda','src/compute_ggml_runtime','src/compute_backend_cuda','tests/compute_state']:
 flags+=['/I'+str(ROOT/p)]
flags+=['/external:I'+str(source/'include'),'/external:I'+str(toolkit/'include'),'/external:I'+str(toolkit/'include/cccl'),'/external:I'+str(Path(os.environ['LOCALAPPDATA'])/'hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6/googletest/include'),'/external:W0']
records=[]
def run(tag,cmd,timeout=180):
 cmd=list(map(str,cmd));start=time.monotonic();p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,timeout=timeout)
 (OUT/(tag+'.stdout.log')).write_bytes(p.stdout);(OUT/(tag+'.stderr.log')).write_bytes(p.stderr)
 record=dict(tag=tag,command=cmd,cwd=str(ROOT),exit=p.returncode,seconds=time.monotonic()-start);records.append(record)
 (OUT/(tag+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(tag,p.returncode,round(record['seconds'],2),flush=True)
 if p.returncode:print(p.stdout.decode(errors='replace')[-8000:]);print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
 return p

def comp(file,stem,extra=()):
 obj=OUT/(stem+'.obj');run(stem+'-compile',[cl,*flags,*extra,file,'/Fo'+str(obj)]);return obj
names=['hyle_graph','hyle_compute_backend_cuda','hyle_compute_state','hyle_compute_batch','hyle_compute_ggml_runtime','hyle_compute','hyle_compute_ops','hyle_container','hyle_mem','mimalloc_static','hyle_platform','hyle_error','hyle_platform_thread','hyle_time','hyle_simd']
libs=[BASE/'bin'/(s+'.lib') for s in names]
libs+=[native/'bin'/(s+'.lib') for s in ['ggml','ggml-cuda','ggml-base']]
libs+=[toolkit/'lib/x64'/(s+'.lib') for s in ['cudart','cublas','cublasLt','cuda']]
system=['bcrypt.lib','PowrProf.lib','Synchronization.lib','advapi32.lib','user32.lib','shell32.lib','ole32.lib','ws2_32.lib']
def linkexe(tag,objects,tests=False):
 more=[BASE/'lib/gtest_main.lib',BASE/'lib/gtest.lib'] if tests else []
 run(tag+'-link',[link,'/nologo','/MACHINE:X64','/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO','/NODEFAULTLIB:LIBCMT','/OUT:'+str(OUT/(tag+'.exe')),'/MAP:'+str(OUT/(tag+'.map')),*objects,OLD/'ggml-cuda.strict.obj',*libs,*more,*system])
if __name__=='__main__':
 action=sys.argv[1]
 if action=='build':
  data=(ROOT/'src/compute_provider_ggml_cuda/tensor_program.cc').read_text()
  for codec in ['IQ1_XS','IQ1_XXS','IQ1_XXXS']:
   assert data.count('return GGML_TYPE_'+codec+';')==1
   data=data.replace('return GGML_TYPE_'+codec+';','return GGML_TYPE_COUNT; // Validation-only: legacy native lacks this unrelated IQ1 codec.')
  (OUT/'tensor_program.probe.cc').write_text(data)
  for file,stem in [(ROOT/'src/compute_ops/operation.cc','operation'),(ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc','provider'),(OUT/'tensor_program.probe.cc','tensor'),(ROOT/'src/graph_provider_ggml_cuda/ggml_cuda_region.cc','region')]:comp(file,stem)
  comp(ROOT/'tests/compute_provider_ggml_cuda/tensor_test.cc','tensor-tests')
  linkexe('cuda-tests',[OUT/(s+'.obj') for s in ['operation','provider','tensor','region','tensor-tests']],True)
 elif action=='consumer':
  comp(ROOT/'tests/compute_state/public_state_consumer.cc','state-consumer')
  comp(OUT/'component_route.cc','component-route')
  linkexe('cuda-state-consumer',[OUT/(s+'.obj') for s in ['operation','provider','tensor','region','state-consumer','component-route']])
 elif action=='hybrid':
  flags+=['/DHYLE_COMPUTE_CPU=1','/DHYLE_COMPUTE_GGML_CPU=1']
  comp(ROOT/'tests/compute_state/public_state_consumer.cc','hybrid-state-consumer')
  comp(OUT/'component_route.cc','hybrid-component-route')
  mixed=ROOT/'.scratch/mtp-gdn-2026-10-18/mixed'
  causal=ROOT/'.scratch/perf-review-2026-10-18/cpu-native-causal/mixed'
  libs+=[BASE/'bin/hyle_compute_provider_ggml.lib',BASE/'bin/hyle_compute_backend_cpu.lib',ROOT/'.scratch/build-cpu-final-mixed-probe/ggml/src/ggml-cpu.lib']
  objects=[OUT/(stem+'.obj') for stem in ['operation','provider','tensor','region','hybrid-state-consumer','hybrid-component-route']]
  objects += [mixed/(stem+'.obj') for stem in ['provider','selector-baseline','allocator']]+[causal/'native-baseline.obj']
  linkexe('hybrid-state-consumer',objects)
  run('hybrid-state-consumer',[OUT/'hybrid-state-consumer.exe'])
 elif action=='test':
  run('cuda-tests',[OUT/'cuda-tests.exe','--gtest_filter=GgmlCudaTensor.*GatedDelta*:GgmlCudaTensor.*Recurrent*'])
  run('cuda-state-consumer',[OUT/'cuda-state-consumer.exe'])

