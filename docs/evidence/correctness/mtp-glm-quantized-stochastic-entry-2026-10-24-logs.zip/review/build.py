from pathlib import Path
import argparse, hashlib, importlib.util, json, os, subprocess, sys, time
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1]
sys.path.insert(0,str(R/'scripts'))
from hyle_environment import discover_environment
spec=importlib.util.spec_from_file_location('cpu_build',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def ident(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def build(kind):
 out=S/kind;out.mkdir(exist_ok=False)
 name='glm_pro_mtp_state_consumer_test.cc' if kind=='B09' else 'glm_mtp_state_consumer_test.cc'
 src=R/'tests/compute_models'/name
 base=R/'.scratch/glm-random-mtp-20261024'/('pro/compile1/command.json' if kind=='B09' else 'compile3/command.json')
 command=[];skip=False
 for x in read(base)['command']:
  if skip:skip=False;continue
  if x=='/sourceDependencies':skip=True;continue
  if x.startswith(('/Fo','/Fd')) or x.endswith(name):continue
  command.append(x)
 if kind=='Q30':
  actual=read(R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/consumer1/records/flash-state-attempt2/run/command.json')['command']
  command += [x for x in actual if x.startswith('/DHYLE_TEST_GLM_Q30_')]
 else:command+=['/I'+str(R/'.scratch/glm-gguf-selected-20261023/B09/generated')]
 command += ['/sourceDependencies',str(out/'deps.json'),str(src),'/Fo'+str(out/'consumer.obj')]
 env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':command[0],'CMAKE_CXX_COMPILER':command[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
 before=ident(src);b.execute(command,env,out/'compile',timeout=600)
 assert before==ident(src)
 save(out/'compile-identity.json',dict(source=before,object=ident(out/'consumer.obj'),dependencies=[ident(x) for x in read(out/'deps.json')['Data']['Includes']]))
 base=read(R/'.scratch/dspark-random-mtp-20261024/link-command.json')
 command=[x for x in base if not x.upper().startswith(('/OUT:','/IMPLIB:','/MAP:','/PDB:')) and not x.endswith('dspark-random-mtp-20261024\\consumer.obj')]
 assert len(command)<len(base)
 command.insert(1,str(out/'consumer.obj'));command+=['/OUT:'+str(out/'checks.exe'),'/IMPLIB:'+str(out/'checks.lib')]
 save(out/'link-inputs.json',[ident(x) for x in command if x.lower().endswith(('.obj','.lib')) and Path(x).is_absolute()])
 b.execute(command,env,out/'link',timeout=600)
 dll=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll';os.link(dll,out/dll.name)
 save(out/'ready.json',dict(image=ident(out/'checks.exe'),runtime_dll=ident(out/dll.name),SDK_TUs=0,consumer_TUs=1))
def run(kind,attempt=1):
 out=S/kind;run_name='run' if attempt==1 else f'run{attempt}';run_dir=out/run_name;assert not run_dir.exists();frontier=out/('frontier.json' if attempt==1 else f'frontier{attempt}.json');env=dict(os.environ,PATH=str(out)+';'+read(R/'.scratch/dspark-random-mtp-20261024/runtime.json')['PATH'],HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 if kind=='Q30':
  env.update(HYLE_GLM_Q30_ORIGINAL_DIR=str(R/'.scratch/glm-quark-selected-20261024/Q30'),HYLE_GLM_Q30_WAIT_FOR_EXPERTS='0',HYLE_GLM_Q30_FRONTIER_FILE=str(frontier))
  case='GlmMtpStateConsumer.CudaQuarkOriginalTarget43And44AndNextNRandomVerifierContinuesAtomically'
 else:
  env.update(HYLE_GLM_GGUF_B09_DIR=str(R/'.scratch/glm-gguf-selected-20261023/B09/original-static'),HYLE_GLM_GGUF_B09_EXPERT_DIR=str(R/'.scratch/glm-gguf-selected-20261023/B09/original-experts'),HYLE_GLM_GGUF_WAIT_FOR_EXPERTS='0',HYLE_GLM_GGUF_FRONTIER_FILE=str(frontier))
  case='GlmProMtpStateConsumer.CudaConvertedB09TargetAndNextNRandomVerifierContinuesAtomically'
 save(out/(run_name+'-inputs.json'),{k:v for k,v in env.items() if k.startswith(('HYLE_','HF_','TRANSFORMERS_'))})
 command=[str(out/'checks.exe'),'--gtest_filter='+case,'--gtest_output=xml:'+str(run_dir/'results.xml')]
 b.execute(command,env,run_dir,timeout=600)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['build','run']);p.add_argument('kind',choices=['Q30','B09']);p.add_argument('--attempt',type=int,default=1);a=p.parse_args();assert a.attempt>=1;run(a.kind,a.attempt) if a.action=='run' else build(a.kind)
