from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET,datetime
S=Path(__file__).resolve().parent;R=S.parents[1];E=R/'docs/evidence/correctness';E.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def ident(p):
 p=Path(p);return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def process_summary(p):
 j=read(p);return dict(exit=j['exit'],timed_out=j['timed_out'],seconds=j['process_wall_seconds'],command=ident(Path(p).parent/'command.json'))
def runs(kind):
 out=[]
 for p in sorted((S/kind).glob('run*/process.json'),key=lambda p:1 if p.parent.name=='run' else int(p.parent.name[3:])):
  result=read(p);xml=p.parent/'results.xml';root=ET.parse(xml).getroot() if xml.exists() else None
  leaf=next(root.iter('testcase')) if root is not None else None
  frontier=S/kind/('frontier.json' if p.parent.name=='run' else 'frontier'+p.parent.name[3:]+'.json')
  out.append(dict(attempt=p.parent.name,process_exit=result['exit'],timed_out=result['timed_out'],seconds=result['process_wall_seconds'],tests=int(root.get('tests')) if root is not None else None,failures=int(root.get('failures')) if root is not None else None,case=(leaf.get('classname')+'.'+leaf.get('name')) if leaf is not None else None,properties={x.get('name'):x.get('value') for x in leaf.iter('property') if x.get('name','').startswith(('random_','stochastic_','sampling_'))} if leaf is not None else {},all_properties_in_archived_results_xml=True,failure=[x.get('message') for x in leaf.iter('failure')] if leaf is not None else [],missing_frontier=read(frontier) if frontier.exists() else None,command=ident(p.parent/'command.json'),stdout=ident(p.parent/'stdout.log')))
 return out
scope=read(R/'docs/implementation/mtp-local-scope.json')['metadata_discovery']
rows=[dict(repository=x['repository'],mtp_presence=x['mtp_presence']) for x in scope['rows']]
result=dict(schema='hyle.mtp.functional-entry-review.v1',updated=datetime.datetime.now().isoformat(timespec='seconds'),scope=dict(metadata_identity_count=scope['count'],summary=scope['summary'],identity_facts=rows,meaning='17 additional fixed source identities; complete schema or complete absence is not full-model execution certification.'),finding=dict(id='glm-quantized-stochastic-entry',before='Official GLM Flash/Pro shared samplers and atomic StateHead+SamplingCursor controller existed; Flash Q30/MLX/GGUF wrappers omitted stochastic, and no selected converted Pro random entry was registered.',fix='Propagate the same stochastic boolean through the three Flash source wrappers. Reuse the existing Pro ConvertedRuntime stochastic controller and register representative B09 random entries. Quantized Flash uses the natural proposal0/accept1/final2 draw schedule without the optional opposite-address fixture search.',files=[dict(path='tests/compute_models/glm_mtp_state_consumer_test.cc',lines=[4132,4346,4801,4845,4865,4912,4928,4938,4986,5114]),dict(path='tests/compute_models/glm_pro_mtp_state_consumer_test.cc',lines=[1486,2086,2127])],unchanged='No duplicated probability mathematics, RNG, StateHead publication, runtime executor, provider routing, model format, or official controlled-address fixture default.'),builds={k:dict(compile=process_summary(S/k/'compile/process.json'),link=process_summary(S/k/'link/process.json'),ready=read(S/k/'ready.json')) for k in ['Q30','B09']},actual_runs={k:runs(k) for k in ['Q30','B09']},network=dict(http_requests_started_by_this_review=0,model_bytes_downloaded_by_this_review=0,implicit_supplier=False,wait_for_experts=False),limits=['Both CPU and CUDA registrations compile in the dual-backend consumer TUs; this review executes only the two selected CUDA cases.','A missing selected original expert is an explicit unfinished source frontier, never a sampler correctness pass. Original failed attempts are retained.','Finite original GLM target-tail/NextN/full-vocabulary consumers exercise library functionality; they are not complete whole-GLM model serving engines.','Other in-progress work is independent: Q24 shared stochastic controller/mixed source, DS typed Markov sidecars, and root original Q8/CT/Q27 complete-model journeys.','Source-specific tiles plus complete schema can establish functional format reuse; other publisher complete trained banks have not all run end to end.','This is a functional review with no throughput benchmark or architectural completion claim.'])
result['new_boundary_review_gap']=dict(scope='Old frozen natural random consumers only',finding='Flash manually chose accepted checkpoint and continued the next K1; Pro manually constructed K1Decision and continued target T1 without an EOS/output-quota/context selector.',locations={'Flash':[4369,4385,4405],'Pro':[1754,1764,1772,1839]},follow_up='Architecture agent owns the new common EOS/quota/context integration and separate new-image finite evidence. Old baseline source-frontier checks do not certify these boundaries.')
result['shared_boundary_follow_up']=dict(status='separate new-image official Flash/Pro boundary cases passed',proof=ident(R/'docs/evidence/correctness/mtp-glm-stochastic-output-boundaries-2026-10-24.json'),scope='New common EOS/quota/context handling is separate from these retained quantized natural baselines; no claim that the old image contains the new boundary code.')
result['status']=dict(wrapper_implementation='compiled in both selected CUDA/CPU consumer TUs',runtime={k:('passed' if v and v[-1]['process_exit']==0 and v[-1]['failures']==0 else 'unfinished_original_source_frontier' if v and v[-1]['missing_frontier'] else 'failed_or_not_run') for k,v in result['actual_runs'].items()},overall_completion_claim=False)
supplied=[]
for kind in ['Q30','B09']:
 for run in result['actual_runs'][kind]:
  f=run['missing_frontier']
  if not f:continue
  for id in f['missing_ids']:
   if kind=='Q30':
    section=f['section'];prefix='original-experts' if section=='nextn' else 'original-'+section+'/experts'
    p=R/'.scratch/glm-quark-selected-20261024/Q30'/prefix/f'expert{id:03}'/'acquisition.json'
   else:p=R/'.scratch/glm-gguf-selected-20261023/B09/original-experts'/f['section']/f"stage{f['stage']}"/f'expert{id:03}'/'acquisition.json'
   if p.exists():
    j=read(p)
    if j.get('complete') and not any(x['receipt']['path']==ident(p)['path'] for x in supplied):supplied.append(dict(kind=kind,section=f['section'],global_id=id,receipt=ident(p),role_payload_bytes=j.get('role_payload_bytes',j.get('bundle_bytes'))))
result['parent_source_supply']=dict(actor='Root, using existing bounded budget acquisition; not implicit native consumer HTTP.',completed=supplied)
name='mtp-glm-quantized-stochastic-entry-2026-10-24'
archive=E/(name+'-logs.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for rel in ['build.py','publish.py','dependencies-stable.json','frozen-source/identity.json']:
  z.write(S/rel,'review/'+rel)
 for kind in ['Q30','B09']:
  for p in (S/kind).rglob('*'):
   if p.is_file() and (p.suffix in ['.json','.xml','.log'] or p.name in ['stdout.log','stderr.log']):z.write(p,'review/'+str(p.relative_to(S)).replace('\\','/'))
 for rel in ['tests/compute_models/glm_mtp_state_consumer_test.cc','tests/compute_models/glm_pro_mtp_state_consumer_test.cc','tests/compute_models/model_sampling_fragment.h','tests/compute_models/glm_target_verifier_fragment.h','engine/inference/sampling_graph.h','engine/inference/sampling_cursor.h']:
  z.write(S/'frozen-source'/rel,'source/'+rel)
result['archive']=ident(archive)
p=E/(name+'.json');p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(ident(p));print(ident(archive))
