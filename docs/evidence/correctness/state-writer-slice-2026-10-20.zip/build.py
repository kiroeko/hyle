"""Fresh old/new state implementation plus the same public regression objects."""
import argparse
import concurrent.futures
import ctypes
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;A=S.parent;ROOT=S.parents[2]
spec=importlib.util.spec_from_file_location('state_slice_helpers',A/'projected-bind-cold-index/build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c

def split_windows(command):
    argc=ctypes.c_int();fn=ctypes.windll.shell32.CommandLineToArgvW
    fn.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];fn.restype=ctypes.POINTER(ctypes.c_wchar_p)
    ptr=fn(command,ctypes.byref(argc));assert ptr
    try:return [ptr[i] for i in range(argc.value)]
    finally:
        free=ctypes.windll.kernel32.LocalFree;free.argtypes=[ctypes.c_void_p];free.restype=ctypes.c_void_p
        free(ctypes.cast(ptr,ctypes.c_void_p))

def main():
    p=argparse.ArgumentParser();p.add_argument('--build',action='store_true');p.add_argument('--resume',action='store_true');args=p.parse_args()
    out=S/'checks';out.mkdir(exist_ok=True);(out/'tmp').mkdir(exist_ok=True)
    basepath=A/'projected-bind-cold-index/checks/host1/cpu-link-plan.json';base=c.read(basepath)
    recipes={row['source']:dict(row,argv=split_windows(row['original_command'])) for row in c.read(S/'cached-target-recipes.json')}
    products=[('before-state',S/'before/src/compute_state/state_versions.cc','src/compute_state/state_versions.cc'),
        ('after-state',ROOT/'src/compute_state/state_versions.cc','src/compute_state/state_versions.cc'),
        ('versions-test',ROOT/'tests/compute_state/state_versions_test.cc','tests/compute_state/state_versions_test.cc'),
        ('clone-test',ROOT/'tests/compute_state/state_clone_test.cc','tests/compute_state/state_clone_test.cc')]
    rows=[]
    for tag,source,recipe in products:
        rows.append(dict(tag=tag,source=b.identity(source),command=b.host_command(recipes[recipe]['argv'],source,tag,out),object=str(out/(tag+'.obj'))))
    frozen=[b.identity(S/'product-source-freeze.json'),b.identity(ROOT/'src/compute_state/state_internal.h'),*[row['source'] for row in rows]]
    plan=dict(compile=rows,base_path=str(basepath),frozen=frozen,links={},SDK_rebuild=False,native_TUs=0,
        note='Original static state library has one source member. Replace it with fresh before/after product object; same fresh two test objects in both images. Existing cache libraries/DLLs are not mutated.')
    c.save(out/'plan.json',plan);print('STATE_SLICE_PLAN',len(rows),flush=True)
    if not args.build:return
    def check():
        for row in frozen:assert b.same(row),row['path']
    for row in base['inputs']:assert b.same(row),row['path']
    env,runtime=b.environment(base['command'],[row['path'] for row in base['inputs']],out)
    c.save(out/'runtime-environment.json',dict(runtime=runtime,PATH=env['PATH']))
    def compile_one(row):
        check();receipt=out/(row['tag']+'-identity.json')
        if args.resume and receipt.exists():
            old=c.read(receipt)
            if old['command']==row['command'] and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
                print('REUSE',row['tag'],flush=True);return row['tag'],old
        c.execute(row['tag']+'-compile',row['command'],env,out);check()
        dependencies=c.read(out/(row['tag']+'-deps.json'))['Data']
        paths=[dependencies['Source'],*dependencies['Includes']]
        receipt=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=[b.identity(p) for p in dict.fromkeys(paths)])
        c.save(out/(row['tag']+'-identity.json'),receipt);return row['tag'],receipt
    finished={};errors=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(compile_one,row) for row in rows]):
            try:
                tag,result=future.result();finished[tag]=result
            except Exception as e:errors.append(repr(e))
    c.save(out/'compile-summary.json',dict(passed=not errors,errors=errors))
    if errors:raise RuntimeError(errors)
    removed=[row for row in base['inputs'] if Path(row['path']).name.lower()=='hyle_compute_state.lib'];assert len(removed)==1
    remove_key=c.key(removed[0]['path']);lookup={c.key(row['path']):row for row in base['inputs']}
    for arm in ('before','after'):
        tags=[arm+'-state','versions-test','clone-test'];added=[finished[tag]['object'] for tag in tags]
        lookup.update({c.key(row['path']):row for row in added})
        command=[arg for arg in base['command'] if c.key(arg)!=remove_key and not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command[1:1]=[row['path'] for row in added]
        image=out/(arm+'.exe');command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[lookup[c.key(arg)] for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        assert len(inputs)==len({c.key(row['path']) for row in inputs})
        for row in inputs:assert b.same(row),row['path']
        check();link=dict(command=command,inputs=inputs)
        prior=out/(arm+'-link-plan.json');imagepath=out/(arm+'-image.json')
        reuse=args.resume and prior.exists() and imagepath.exists() and c.read(prior)==link and b.same(c.read(imagepath))
        if reuse:print('REUSE_LINK',arm,flush=True)
        else:c.execute(arm+'-link',command,env,out)
        check();c.save(prior,link);c.save(imagepath,b.identity(image));plan['links'][arm]=dict(**link,image=str(image))
    c.save(out/'plan.json',plan);c.save(out/'summary.json',dict(passed=True,product_TUs=2,test_TUs=2,SDK_rebuild=False,native_TUs=0))
    print('STATE_SLICE_BUILT',flush=True)

if __name__=='__main__':main()
