param([Parameter(Mandatory = $true)][string]$Image)
$ErrorActionPreference = 'Stop'
$resolvedImage = (Resolve-Path -LiteralPath $Image).Path
& $resolvedImage '--gtest_filter=StateVersions.SlicedCloneWriterCannotPublishAnIncompleteMember' '--gtest_color=no'
exit $LASTEXITCODE
