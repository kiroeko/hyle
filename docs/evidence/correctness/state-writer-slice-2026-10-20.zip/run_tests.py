"""Actual expected-red repro, then all StateVersions/StateClone neighbors."""
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('state_slice_tests',S/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c;build=S/'checks';out=S/'tests';out.mkdir(exist_ok=False)
results={}
for arm,filters in [('before','StateVersions.SlicedCloneWriterCannotPublishAnIncompleteMember'),('after','StateVersions.*:StateClone.*')]:
    current=out/arm;current.mkdir();(current/'tmp').mkdir()
    image=c.read(build/(arm+'-image.json'));assert b.same(image)
    link=c.read(build/(arm+'-link-plan.json'));env,runtime=b.environment(link['command'],[row['path'] for row in link['inputs']],current)
    c.save(current/'inputs.json',dict(image=image,filter=filters,runtime=runtime))
    try:c.execute('tests',[image['path'],'--gtest_filter='+filters,'--gtest_output=xml:'+str(current/'results.xml')],env,current)
    except RuntimeError:
        assert arm=='before' and c.read(current/'tests.result.json')['exit']==1
    cases=ET.parse(current/'results.xml').findall('.//testcase')
    failures=[dict(name=r.attrib['classname']+'.'+r.attrib['name'],details=[f.text for f in r.findall('failure')]) for r in cases if r.find('failure') is not None]
    skipped=sum(r.find('skipped') is not None for r in cases)
    result=dict(image=image,cases=len(cases),skipped=skipped,failures=failures,actual=[r.attrib['classname']+'.'+r.attrib['name'] for r in cases])
    if arm=='before':
        result['expected_bug_reproduced']=len(cases)==1 and len(failures)==1 and not skipped
        assert result['expected_bug_reproduced']
    else:
        # Derive the expected suite count from the actual two source files,
        # including the one new public-API regression.
        import re
        expected=sum(len(re.findall(r'TEST\(\s*'+suite+r'\s*,',Path(path).read_text(encoding='utf-8'))) for suite,path in
            [('StateVersions',S.parents[2]/'tests/compute_state/state_versions_test.cc'),('StateClone',S.parents[2]/'tests/compute_state/state_clone_test.cc')])
        result['expected_cases']=expected;result['passed']=len(cases)==expected and not failures and not skipped
        assert result['passed']
    c.save(current/'summary.json',result);results[arm]=result
c.save(out/'summary.json',dict(passed=results['before']['expected_bug_reproduced'] and results['after']['passed'],arms=results,
    GPU_run=False,model_run=False,limits='Actual Windows CPU State public-API bug repro and related neighbors; no throughput or all-platform claim.'))
print('STATE_SLICE_REPRO_AND_REGRESSIONS',results['after']['cases'],'passed',flush=True)
