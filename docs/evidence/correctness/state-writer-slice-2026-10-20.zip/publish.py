"""Retain the public-API before/after witness and the minimal shipped fix."""
import hashlib
import json
from pathlib import Path
import zipfile
S=Path(__file__).resolve().parent;ROOT=S.parents[2]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def identity(p):
    p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
freeze=read(S/'product-source-freeze.json')
for row in freeze['files']:
    assert identity(ROOT/row['path'])['sha256']==row['after_sha256']==identity(ROOT/row['snapshot'])['sha256']
tests=read(S/'tests/summary.json');assert tests['passed']
assert tests['arms']['before']['expected_bug_reproduced'] and tests['arms']['after']['cases']==32
assert (S/'independent-review.json').is_file()
files=[p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in ('.py','.cc','.json','.log','.xml','.diff','.ps1') and 'tmp' not in p.parts]
rows=[];archive_path=ROOT/'docs/evidence/correctness/state-writer-slice-2026-10-20.zip'
with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in files:
        row=identity(p);row['member']=str(p.relative_to(S)).replace('\\','/');rows.append(row);archive.writestr(row['member'],p.read_bytes())
    archive.writestr('payload-sha256.json',json.dumps(rows,indent=2))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for row in rows:
        data=archive.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
body=dict(date='2026-10-20',scope='StateWriter mutable-handle publication through public lease API; common single-machine state storage.',
    defect='A legal readonly subview followed by exclusive try_write preserves block identity/generation but shortens the range. Old publish accepted that short writer and finalized an incomplete schema member.',
    witness=dict(expected_member_bytes=16,slices=[dict(offset=4,bytes=8),dict(offset=8,bytes=0)],
        before='Freshly compiled old implementation with the same new test objects actually publishes8/0-byte StateVersion members; gtest exits1 as expected.',
        after='Extent is rejected before tracking/lease consumption or pending clearance. Original base member remains16bytes and content37.'),
    fix='One shared private check_resource_extent reused by existing readonly validation and StateWriter::publish; original native-use/producer-failure observation remains solely in writer.publish.',
    freeze=freeze,independent_review=read(S/'independent-review.json'),build=read(S/'checks/summary.json'),actual_tests=tests,
    archive=identity(archive_path),payloads=rows,archive_verified=dict(CRC=True,all_payload_SHA256=True),
    limits=['Actual Windows CPU before/after and32 related StateVersions/StateClone cases, zero skips; no GPU/model/performance rerun was needed for this state-only change.',
        'Before/after use fresh respective product objects and the same test objects on the current retained CPU link closure; no stale shared library was mutated.',
        'This fixes a concrete publication invariant, not all cross-platform/state or inference architecture requirements.'])
save(archive_path.with_suffix('.json'),body)
print('STATE_SLICE_PUBLISHED',len(rows),archive_path.stat().st_size,flush=True)
