"""Prepare a focused test-only Metal branch; never modifies canonical source."""
import difflib
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[2]
REL = 'tests/compute_provider_native/gdn_output_scale_test.cc'
before = (R / REL).read_bytes()
text = before.decode('utf-8')
assert '\r' not in text


def replace_once(old, new):
    global text
    assert text.count(old) == 1, old
    text = text.replace(old, new, 1)


replace_once('#elif defined(HYLE_GDN_SCALE_APPLE)\n#include "hyle/compute/apple.h"',
             '#elif defined(HYLE_GDN_SCALE_METAL_NATIVE)\n'
             '#import <Metal/Metal.h>\n'
             '#include <cstring>\n'
             '#include "native_program.h"\n'
             '#include "../../src/compute_ggml_runtime/gated_delta_scale.h"\n'
             '#elif defined(HYLE_GDN_SCALE_APPLE)\n#include "hyle/compute/apple.h"')

cold_start = text.index('TEST(GdnOutputScale, ColdParameterIdentityRetainsPresenceAndSignedFloatBits) {')
cold_end = text.index('\n#else\nTEST(GdnOutputScale, RawDefaultAndFusedGatesKeepStateSnapshots)', cold_start)
cold = text[cold_start:cold_end]
text = text[:cold_start] + text[cold_end:]

metal = r'''#elif defined(HYLE_GDN_SCALE_METAL_NATIVE)
TEST(GdnOutputScale, RawDefaultAndFusedGatesKeepStateSnapshots) {
  @autoreleasepool {
    id<MTLDevice> device = MTLCreateSystemDefaultDevice();
    ASSERT_NE(device, nil);
    for (int mode = 0; mode != 3; ++mode) {
      const Fixture f(mode == 1, mode == 2);
      for (const std::optional<float> scale :
           {std::optional<float>{}, std::optional<float>{1.F}}) {
        SCOPED_TRACE(::testing::Message() << "mode=" << mode
                     << " explicit=" << scale.has_value());
        // These retain the actual Metal allocations until the NativeProgram
        // has retired and released its imported views (reverse declaration order).
        std::vector<id<MTLBuffer>> owners;
        owners.reserve(f.inputs.size());
        __attribute__((objc_precise_lifetime)) id<MTLBuffer> packed = nil;
        auto program = c::ggml_metal::NativeProgram::create(f.operation(scale), f.inputs);
        ASSERT_TRUE(program) << program.error().message();
        ASSERT_EQ((*program)->output_count(), 2U);
        const auto desc = f.outputs(scale);
        std::array<std::size_t, 2> extents{};
        for (std::size_t port = 0; port != 2; ++port) {
          const auto &actual = (*program)->output_description(port);
          EXPECT_EQ(actual.data_type(), desc[port].data_type());
          ASSERT_EQ(actual.dimensions().size(), desc[port].dimensions().size());
          EXPECT_TRUE(std::equal(actual.dimensions().begin(), actual.dimensions().end(),
                                 desc[port].dimensions().begin(), desc[port].dimensions().end()));
          extents[port] = desc[port].required_bytes().value();
          const auto offset = (*program)->output_offset(port);
          ASSERT_EQ(offset % sizeof(float), 0U);
          ASSERT_LE(offset, (*program)->output_bytes());
          ASSERT_LE(extents[port], (*program)->output_bytes() - offset);
        }
        EXPECT_EQ((*program)->output_offset(0), 0U);
        EXPECT_EQ((*program)->output_offset(1), extents[0]);
        std::vector<c::ggml_metal::BufferView> ports;
        ports.reserve(f.inputs.size() + 1);
        for (std::size_t port = 0; port != f.inputs.size(); ++port) {
          id<MTLBuffer> input = [device newBufferWithLength:f.inputs[port].required_bytes().value()
                                                  options:MTLResourceStorageModeShared];
          ASSERT_NE(input, nil);
          std::memcpy([input contents], f.data[port].data(), f.data[port].size() * sizeof(float));
          owners.push_back(input);
          EXPECT_FALSE((*program)->input_is_packed(port));
          ports.push_back({(__bridge void *)input, 0});
        }
        packed = [device newBufferWithLength:(*program)->output_bytes()
                                     options:MTLResourceStorageModeShared];
        ASSERT_NE(packed, nil);
        std::memset([packed contents], 0xCD, (*program)->output_bytes());
        // NativeProgram has one contiguous output allocation, with two
        // non-overlapping public views; it does not accept two output buffers.
        ports.push_back({(__bridge void *)packed, 0});
        const auto status = (*program)->run(ports);
        ASSERT_TRUE(status.ok()) << status.message();
        const auto *base = static_cast<const std::byte *>([packed contents]);
        f.check({reinterpret_cast<const float *>(base + (*program)->output_offset(0)),
                 extents[0] / sizeof(float)},
                {reinterpret_cast<const float *>(base + (*program)->output_offset(1)),
                 extents[1] / sizeof(float)}, scale);
        EXPECT_EQ(std::memcmp([owners.back() contents], f.data.back().data(),
                              f.data.back().size() * sizeof(float)), 0);
      }
    }
  }
}
'''
replace_once('#else\nTEST(GdnOutputScale, RawDefaultAndFusedGatesKeepStateSnapshots) {\n#if defined(HYLE_GDN_SCALE_APPLE)',
             metal + '#else\nTEST(GdnOutputScale, RawDefaultAndFusedGatesKeepStateSnapshots) {\n#if defined(HYLE_GDN_SCALE_APPLE)')
replace_once('\nTEST(GdnOutputScale, PublicInferenceRejectsNonfiniteAndRetainsExplicitDomain) {',
             '\n#if defined(HYLE_GDN_SCALE_CPU) || defined(HYLE_GDN_SCALE_CUDA) || defined(HYLE_GDN_SCALE_METAL_NATIVE)\n'
             + cold + '\n#endif\n\nTEST(GdnOutputScale, PublicInferenceRejectsNonfiniteAndRetainsExplicitDomain) {')
replace_once('#include <array>\n', '#include <algorithm>\n#include <array>\n')

# Fixture mathematics and inference-domain checks remain byte-for-byte original.
fixture_before = before.decode().split('struct Fixture final {', 1)[1].split('\n#if defined(HYLE_GDN_SCALE_CPU)', 1)[0]
fixture_after = text.split('struct Fixture final {', 1)[1].split('\n#if defined(HYLE_GDN_SCALE_CPU)', 1)[0]
assert fixture_before == fixture_after
assert text.count(cold) == 1
assert text.count('TEST(GdnOutputScale, PublicInferenceRejectsNonfiniteAndRetainsExplicitDomain)') == 1
output = S / 'next-source' / REL
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(text, encoding='utf-8', newline='\n')
patch = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
                                   text.splitlines(keepends=True),
                                   fromfile='a/' + REL, tofile='b/' + REL))
(S / 'focused-metal-helper.patch').write_text(patch, encoding='utf-8', newline='\n')


def identity(path):
    p = Path(path); raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


(S / 'helper-identities.json').write_text(json.dumps(dict(
    before=identity(R / REL), after=identity(output),
    patch=identity(S / 'focused-metal-helper.patch'),
    macro='HYLE_GDN_SCALE_METAL_NATIVE=1', expected_cases=3,
    unchanged=['Fixture and its independent check', 'CPU/CUDA/MLX/Vulkan math and execution',
               'cold scale presence/float-bit test body', 'public inference-domain test'],
    scope='Direct NativeProgram, no MLX or Graph Context. No compilation/native execution.'), indent=2) + '\n')
print(json.dumps(identity(S / 'focused-metal-helper.patch')))
