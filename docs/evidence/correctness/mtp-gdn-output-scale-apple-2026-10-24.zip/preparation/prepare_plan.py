"""Local metadata preparation only. No SSH, compiler, native run or download."""
import hashlib
import json
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[2]
PRIOR = S.parent / 'batched-bfloat-linear-apple-proposal'
NATIVE = S.parent / 'gdn-output-scale-proposal'


def identity(path):
    p = Path(path)
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


inv = read(S / 'remote-inventory.json')
prior = read(PRIOR / 'commands.json')
cpu_manifest = read(R / 'third_party/ggml_cpu_runtime/patches.json')
metal_manifest = read(R / 'third_party/ggml_runtime/metal-patches.json')
cpu_file = next(x for x in cpu_manifest['files'] if x['path'] == 'src/ggml-cpu/ops.cpp')
assert len(cpu_file['edits'][-3:]) == 3
assert 'gated_delta_scale.h' in cpu_file['edits'][-3]['after']
metal_files = [x for x in metal_manifest['files'] if x['path'] in (
    'src/ggml-metal/ggml-metal-ops.cpp', 'src/ggml-metal/ggml-metal-impl.h',
    'src/ggml-metal/kernels/gated_delta_net.metal')]
metal_edits = {}
for f in metal_files:
    edits = [e for e in f['edits'] if 'output_scale' in e['after'] or
             'has_output_scale' in e['after'] or 'gated_delta_scale.h' in e['after']]
    assert edits
    metal_edits[f['path']] = edits

host = read(S.parent / 'gdn-output-scale-validation/recipe-preparation/host-commands.json')
foundation = read(S.parent / 'gdn-output-scale-validation/recipe-preparation/foundation-commands.json')
cpu_sources = [Path(j['source']['path']).relative_to(R).as_posix() for j in host['jobs']
               if any(j['name'].startswith(p) for p in
                      ('compute--', 'compute_ops--', 'compute_backend_cpu--',
                       'compute_provider_ggml--', 'compute_ggml_runtime--'))]
cpu_sources += ['src/compute_provider_ggml/ggml_cpu_provider.cc']
cpu_sources += [Path(j['source']['path']).relative_to(R).as_posix()
                for j in foundation['jobs'] if j['name'] != 'cpu-hadamard']
assert len(cpu_sources) == 35 and len(set(cpu_sources)) == len(cpu_sources)
shared_sources = [x for x in cpu_sources if x.startswith(('src/compute/', 'src/compute_ops/'))]
assert len(shared_sources) == 27

plan = {
    'status': 'preparation_only_no_build_native_or_HTTP',
    'inventory': identity(S / 'remote-inventory.json'),
    'scope': 'Apple CPU explicit ggml_cpu provider and Metal direct NativeProgram GDN scale regression; no Graph/default Apple Context claim.',
    'remote': {'ssh': ['ssh', '-o', 'BatchMode=yes', 'kiro@172.22.10.198'],
               'hardware': 'actual Mac16,12 arm64 macOS27.0.1 clang21.0.0',
               'base': prior['remote_directory'],
               'new_output': prior['remote_directory'].split('/batched-bfloat-linear-20261024/')[0] + '/gdn-output-scale-20261024/attempt1'},
    'required_contracts': {'provider': 18, 'cpu_program_abi': 3,
                            'recurrent_custom_id': 9,
                            'native_gdn_scale_contract_hex': '0x48594732',
                            'cpu_program_selection': 'arm64 baseline kBaseline ABI3; no x86 AVX2 DLL'},
    'blockers_before_execution': [
        'Existing HYLE_GDN_SCALE_APPLE focused branch creates MLX apple::Context; it is not the cached direct GGML Metal NativeProgram seam. Adapt only the existing fixture execution to the prior Objective-C++ NativeProgram/MTLBuffer helper, or explicitly refresh the larger MLX Context closure. Do not link that branch against the old small Metal image.',
        'Native source edits must target the actual cached source family. CPU ops.cpp and Metal impl.h differ from Windows whole-file overlays; apply only the listed exact owning edits with count==1 and record new SHA. Never overwrite whole files from Windows or combine cpu0bae and metald851 archives.',
        'Current host/include dependency subset has not been synchronized to Mac, and current ABI3/provider18 objects do not yet exist there. Prior ABI2 cpu_program/cpu_execution and old provider/core objects are not reusable as refreshed implementations.'
    ],
    'not_a_blocker': {
        'metal_cli': 'xcrun --find metal exits72 on actual machine. Existing cache embeds source text and calls newLibraryWithSource; only GDN source embedding .s/.o needs regeneration. No Metal SDK download or offline metallib build required.',
        'no_weights': 'D128 K2 synthetic cancellation fixture, no model roles or weight download.'},
    'cpu': {
        'family': inv['families']['cpu_0bae'],
        'native_compile_recipe': next(e for e in inv['cpu_recipes'] if e['file'].endswith('/ggml-cpu/ops.cpp')),
        'native_changes': {'path': 'src/ggml-cpu/ops.cpp', 'edits': cpu_file['edits'][-3:],
                           'compile_extra_include': 'current-source/src/compute_ggml_runtime'},
        'host_sources': [identity(R / x) for x in cpu_sources],
        'host_source_count': 35,
        'test': {'source': identity(R / 'tests/compute_provider_native/gdn_output_scale_test.cc'),
                 'define': 'HYLE_GDN_SCALE_CPU=1', 'filter': 'GdnOutputScale.*', 'expected_cases': 3},
        'recipe_reuse': 'Use exact prior CPU-provider/test/runtime/helper commands; core compile flags from remote-inventory metal_and_core_recipes. Refresh 27 neutral compute/compute_ops sources, 8 CPU/runtime/batch helpers and focused test. CPU backend flags are neutral HYLE_STATIC/HYLE_COMPUTE_BACKEND_CPU_BUILD with current source include root.',
        'link_template': prior['cpu']['link'][0],
        'link_substitutions': [
            'Drop old test/provider/runtime/helper objects and libhyle_compute.a/libhyle_compute_ops.a/libhyle_compute_backend_cpu.a; use new current objects from the sources above.',
            'Keep the prior same-family cpu_hadamard.o (no Operation/CpuProgram ABI) and same-family SIMD/mem/platform/gtest libraries.',
            'Use only 0bae native libggml/libggml-base/libggml-cpu (and same0bae libggml-metal only if required by its original aggregate). Put fresh ops.cpp.o before libggml-cpu.a so the old ops member is not extracted; confirm link map contains only fresh ops implementation. A small replaced-member archive is an equally valid alternative.',
            'Do not link an old ABI2 compute_ggml_runtime archive or Windows AVX2 worker.'
        ]},
    'metal': {
        'family': inv['families']['metal_d851'],
        'native_compile_recipe': next(e for e in inv['metal_and_core_recipes'] if e['file'].endswith('/ggml-metal/ggml-metal-ops.cpp')),
        'native_changes': metal_edits,
        'native_extra_include': 'current-source/src/compute_ggml_runtime',
        'embed_recipe': inv['metal_ninja_gdn'],
        'native_refresh_count': {'cpp': 1, 'embedded_source_asm': 1},
        'host_sources': [identity(R / x) for x in ['src/compute_provider_ggml_metal/native_program.cc', 'src/compute_ggml_runtime/metadata_arena.cc']],
        'shared_current_host_sources': shared_sources,
        'test_preparation': 'Reuse Fixture/check/operation and the inference-domain test from canonical gdn_output_scale_test.cc. Replace only the Apple execution branch with prior batched_bfloat_apple_test.mm direct NativeProgram create/run and shared MTLBuffers for all inputs plus two outputs. Keep input state and compare after run, run modes scalar-GDN/KDA/Recurrent and explicit1/default. Add exact optional presence/signed-zero op_params test using gated_delta_scale.h if retaining three-case parity; otherwise declare exact2 cases.',
        'prior_helper': identity(PRIOR / 'batched_bfloat_apple_test.mm'),
        'link_template': prior['metal']['link'][0],
        'link_substitutions': [
            'Use current neutral host objects, fresh native_program.o and metadata_arena.o, and the new focused Metal test. Drop old core/ops/runtime archives when their symbols are covered by fresh objects.',
            'Keep only d851 libggml/libggml-base/libggml-metal and its own import/checked-sync bridge. Fresh metal-ops.o and fresh GDN embed .s.o precede libggml-metal.a; verify link map extracts no old versions.',
            'Re-embed only gated_delta_net.metal with its actual updated impl.h using the recorded custom command rewritten to new output paths. Existing unchanged kernel embed objects remain cached. Do not invoke the whole library Ninja target, because impl.h is conservatively a dependency of all shader embeds.'
        ]},
    'synchronization': 'Transfer only the current test/host sources and compiler dependency headers under a single new scratch source prefix. Reuse original native source include roots plus small edited native files; no SDK, full repository, archive family or whole-tree copy.',
    'result_guards': ['record actual Mac hardware/compiler/source/dependency identities',
                      'exact focused test count, process0, no skips',
                      'raw output preserves delta=2^-20; default uses original1/sqrt128',
                      'GDN/KDA/Recurrent two snapshots and original retained input state match',
                      'native scale contract symbol agrees with host0x48594732 and actual scale bits/presence',
                      'no model quality/TPS/Graph/default-provider qualification claim'],
}
(S / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'plan': identity(S / 'plan.json'), 'host_sources_cpu': len(cpu_sources),
                  'builds': 0, 'native_executions': 0, 'HTTP': 0}, indent=2))
