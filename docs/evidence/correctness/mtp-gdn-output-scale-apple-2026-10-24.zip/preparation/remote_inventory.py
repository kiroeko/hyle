"""Read-only inventory; run through SSH stdin. It builds or changes nothing."""
import hashlib
import json
import subprocess
from pathlib import Path

B = Path('/Users/kiro/hyle-scratch/compute-unified')
A = B / 'architecture-refactor-20261019-apple-page-invocation'
CPU_BUILD = B / 'a-cpu-apple/selected-graph/source-build'
METAL_BUILD = A / 'apple-current-sdk-2026-10-21/build'
CPU_SOURCE = CPU_BUILD / 'hyle/src/compute_ggml_runtime/source-0bae7e9e90b384d8'
METAL_SOURCE = METAL_BUILD / 'src/compute_ggml_runtime/source-d851e24e75c99c78'


def identity(path):
    p = Path(path)
    if not p.is_file():
        return {'path': str(p), 'exists': False}
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def command(args):
    r = subprocess.run(args, capture_output=True, text=True)
    return {'argv': args, 'exit_code': r.returncode,
            'stdout': r.stdout, 'stderr': r.stderr}


def recipes(build):
    wanted = []
    for e in json.loads((build / 'compile_commands.json').read_text()):
        f = e['file']
        if any('/src/' + x + '/' in f for x in
               ('compute', 'compute_ops', 'compute_backend_cpu',
                'compute_provider_ggml', 'compute_provider_ggml_metal',
                'compute_ggml_runtime')):
            if '/vendor/' not in f and '/source-' not in f:
                wanted.append(e)
        if f.endswith('/ggml-cpu/ops.cpp') or f.endswith('/ggml-metal/ggml-metal-ops.cpp'):
            wanted.append(e)
    return wanted


out = {
    'status': 'read_only_inventory_no_build_or_native_execution',
    'hardware': [command(['uname', '-m']), command(['sysctl', '-n', 'hw.model']),
                 command(['sw_vers']), command(['/usr/bin/clang++', '--version'])],
    'metal_cli': command(['/usr/bin/xcrun', '--find', 'metal']),
    'families': {},
    'recipe_databases': [identity(CPU_BUILD / 'compile_commands.json'),
                         identity(METAL_BUILD / 'compile_commands.json')],
    'cpu_recipes': recipes(CPU_BUILD),
    'metal_and_core_recipes': recipes(METAL_BUILD),
}
for name, root, rels in [
    ('cpu_0bae', CPU_SOURCE, ['include/ggml.h', 'src/ggml-cpu/ops.cpp']),
    ('metal_d851', METAL_SOURCE, ['include/ggml.h',
      'src/ggml-metal/ggml-metal-ops.cpp', 'src/ggml-metal/ggml-metal-impl.h',
      'src/ggml-metal/kernels/gated_delta_net.metal'])]:
    out['families'][name] = {'root': str(root), 'files': [identity(root / r) for r in rels]}
    for rel in rels:
        if rel.endswith('ops.cpp') or rel.endswith('.metal') or rel.endswith('metal-impl.h'):
            lines = (root / rel).read_text().splitlines()
            anchors = []
            for i, line in enumerate(lines):
                if any(k in line for k in ('const float scale = 1.0f / sqrt',
                                          '// ggml_compute_forward_gated_delta_net',
                                          '} ggml_metal_kargs_gated_delta_net;')):
                    anchors.append({'line': i + 1, 'text': '\n'.join(lines[max(0, i-2):i+3])})
            out['families'][name].setdefault('anchors', {})[rel] = anchors
lines = (METAL_BUILD / 'build.ninja').read_text().splitlines()
out['metal_ninja_gdn'] = []
for i, line in enumerate(lines):
    if line.startswith('build ') and 'ggml-metal-embed-gated_delta_net.s' in line:
        if 'phony' not in line and 'libggml-metal.a:' not in line:
            j = i + 1
            while j < len(lines) and lines[j].strip():
                j += 1
            out['metal_ninja_gdn'].append('\n'.join(lines[i:j]))
out['retained_libraries'] = []
for directory in [B / 'a-cpu-apple/selected-graph/static-sdk-relocated/lib',
                  A / 'apple-current-sdk-2026-10-21/relocated/sdk/lib']:
    for name in ['libggml.a', 'libggml-base.a', 'libggml-cpu.a', 'libggml-metal.a']:
        p = directory / name
        if p.is_file():
            out['retained_libraries'].append(identity(p))
print(json.dumps(out, indent=2))
