"""Publish this completed Apple focused regression, preserving Windows evidence."""
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

S=Path(__file__).resolve().parent
R=S.parents[2]
A=S/'actual-results'
DEST=R/'docs/evidence/correctness'
NAME='mtp-gdn-output-scale-apple-2026-10-24'

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def identity(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def relative_identity(path):
    x=identity(path);x['path']=Path(path).relative_to(R).as_posix();return x

protected=[identity(DEST/('mtp-gdn-output-scale-2026-10-24'+ext)) for ext in ('.json','.zip')]
summary=read(A/'actual-summary.json')
commands=read(A/'commands.json')
assert summary['status']=='passed'
assert summary['contracts']==dict(cpu_program_abi=3,cpu_provider_contract=18,recurrent_custom_id=9,native_gdn_scale_contract='0x48594732')
assert len(summary['host_compile_records'])==38
assert len(summary['successful_native_compile_records'])==3
for job in commands['host']:
    result=read(A/'logs'/job['name']/'result.json')
    assert result['exit_code']==0 and not result['timed_out']
for name in ('cpu-native-ops','metal-native-ops-recipe2','metal-gdn-embed-recipe2',
             'archive-compute','archive-compute_ops','cpu-link','metal-link','cpu-run','metal-run'):
    result=read(A/'logs'/name/'result.json')
    assert result['exit_code']==0 and not result['timed_out']
assert read(A/'logs/metal-native-ops/result.json')['exit_code']!=0
assert read(A/'preparation-failure-attempt1/logs/same-family-native-overlay-and-single-GDN-embed/result.json')['exit_code']!=0
results=[]
expected_names={'RawDefaultAndFusedGatesKeepStateSnapshots',
                'ColdParameterIdentityRetainsPresenceAndSignedFloatBits',
                'PublicInferenceRejectsNonfiniteAndRetainsExplicitDomain'}
for backend in ('cpu','metal'):
    xml=A/(backend+'-tests.xml');root=ET.parse(xml).getroot()
    assert int(root.get('tests'))==3
    assert all(int(root.get(k,'0'))==0 for k in ('failures','errors','disabled'))
    assert not list(root.iter('skipped'))
    assert {x.get('name') for x in root.iter('testcase')}==expected_names
    actual=next(x for x in summary['results'] if x['backend']==backend)
    assert identity(xml)['sha256']==actual['summary']['xml']['sha256']
    results.append(dict(backend=backend,tests=3,failures=0,skips=0,
        interface='Explicit Compute Context with ggml_cpu provider' if backend=='cpu' else 'Direct ggml_metal::NativeProgram with retained shared MTLBuffers',
        image=actual['summary']['image'],xml=dict(actual['summary']['xml'],archive='actual/'+xml.name),
        run_record='actual/logs/'+backend+'-run/result.json',
        source_manifest=summary['source_manifest'],case_names=actual['case_names']))

fixture=read(S/'helper-identities.json')
assert identity(R/'tests/compute_provider_native/gdn_output_scale_test.cc')==fixture['before']
assert identity(A/'source/tests/compute_provider_native/gdn_output_scale_test.cc')['sha256']==fixture['after']['sha256']
for item in read(A/'sync-manifest.json')['files']:
    actual=identity(A/item['archive'])
    assert (actual['bytes'],actual['sha256'])==(item['local']['bytes'],item['local']['sha256'])
for backend in ('cpu','metal'):
    text=(A/(backend+'-gdn-scale-checks.map')).read_text()
    assert '/'+backend+'-native-ops.o' in text
    if backend=='cpu':
        assert 'libggml-cpu.a(ops.cpp.o)' not in text
        assert '/apple-current-sdk-2026-10-21/relocated/sdk/lib/libggml-' not in text
    else:
        assert 'libggml-metal.a(ggml-metal-ops.cpp.o)' not in text
        assert 'libggml-metal.a(ggml-metal-embed-gated_delta_net.s.o)' not in text
        assert '/a-cpu-apple/selected-graph/static-sdk-relocated/lib/libggml-' not in text

archive=DEST/(NAME+'.zip');proof=DEST/(NAME+'.json')
assert not archive.exists() and not proof.exists()
files=[(p,'actual/'+p.relative_to(A).as_posix()) for p in A.rglob('*') if p.is_file()]
for name in ('focused-metal-helper.patch','helper-identities.json','remote-inventory.json',
             'prepare_helper.py','prepare_sync.py','prepare_plan.py','remote_inventory.py','plan.json',
             'publish.py'):
    files.append((S/name,'preparation/'+name))
files.append((R/'tests/compute_provider_native/gdn_output_scale_test.cc','before/tests/compute_provider_native/gdn_output_scale_test.cc'))
allowed={'.json','.py','.patch','.cc','.cpp','.h','.hpp','.mm','.metal','.s','.log','.xml','.d','.map'}
assert len({arc for _,arc in files})==len(files)
for p,arc in files:
    assert p.suffix in allowed or '/licenses/' in arc,p
    assert p.stat().st_size<2*1024*1024,p
    assert not p.read_bytes().startswith((b'MZ',b'\xcf\xfa\xed\xfe',b'!<arch>')),p
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,arc in files:z.write(p,arc)
assert archive.stat().st_size<4*1024*1024
evidence=dict(schema='hyle.correctness.gdn-output-scale.apple.v1',date='2026-10-24',
    recorded_at_utc=datetime.now(timezone.utc).isoformat(),status='passed',
    summary='Mac16,12 CPU explicit Compute provider and direct Metal NativeProgram each pass three focused GDN output-scale cases.',
    hardware=summary['hardware'],contracts=summary['contracts'],results=results,
    counts=dict(tests=6,failures=0,skips=0,host_compile_commands_passed=38,
                native_compile_commands_passed=3,native_compile_recipe_failures_retained=1,
                fresh_small_archives=2,links_passed=2,SDK_copies=0,SDK_builds=0,HTTP_requests=0,model_weight_bytes_downloaded=0),
    numeric_scope=[
        'D128/K2 independent cancellation fixture with actual F32 query 1+2^-20 and -1, default 1/sqrt(128) or explicit1 at the final dot output.',
        'Scalar GDN, channel-decay KDA and raw-gate Recurrent execute with two state snapshots and retained original input state.',
        'Cold optional presence and exact float bits cover explicit1, positive/negative zero and negative scale; inference rejects nonfinite scale. Runtime numeric execution covers default and explicit1.',
        'The original Fixture/check/inference test bodies are unchanged; a focused-only Objective-C++ branch substitutes the existing direct Metal execution seam for MLX Context.'
    ],
    native_families=dict(cpu=dict(cache='source-0bae7e9e90b384d8',before_ops_sha256='afd767b646b754106589ac83876935fcf56baaaf68e194438ba8e18f0f159def',
        delta='Only current manifest three GDN edits: shared scale metadata include, native contract query, final output scale selection. Arm64 baseline ABI3; no AVX2 module.'),
        metal=dict(cache='source-d851e24e75c99c78',before_ops_sha256='4046db2406469c0b1a2a590d51ee583839718c9e50c828bc911cbeebc85b892a',
        before_impl_sha256='832bc4a3e7581dcb01c94a2f716d75b0d5d3fae7e029fd8120b2c80ef686c768',
        delta='Apply only exact GDN kargs/ops/kernel edits to actual cache files. Preserve all other kargs. Compile one ops TU and one embedded GDN source ASM object; existing runtime MSL compilation, no offline Metal SDK.'),
        isolation='CPU and Metal images retain their own original ggml libraries. Link maps confirm fresh ops/GDN embed members and no old replacement members; original cached sources were rehashed unchanged.',
        proof='actual/native-preparation.json'),
    retained_failures=[
        dict(kind='preparation_script_compatibility',scope='Before any C++ compilation or test',
             reason='Mac Python3.9 Path.write_text has no newline argument. Attempt1 retained; attempt2 uses write_bytes.',
             record='actual/preparation-failure-attempt1/logs/same-family-native-overlay-and-single-GDN-embed/result.json'),
        dict(kind='native_compile_recipe',scope='Metal ops only; no source arithmetic change',
             reason='Moving one cpp into overlay required an explicit original-family sibling-header include. First failure and corrected actual command are retained.',
             failure='actual/logs/metal-native-ops/result.json',corrected='actual/logs/metal-native-ops-recipe2/command.json')],
    dependencies=dict(actual='actual/actual-dependencies.json',source_manifest='actual/sync-manifest.json',
        commands='actual/commands.json',host_records='actual/logs/',
        focused_helper_before=fixture['before'],focused_helper_after=fixture['after']),
    limits=['Metal is direct NativeProgram, not default Graph or MLX Context assembly.',
            'No MTP model/quality, Vulkan execution, throughput or physical memory-peak conclusion.',
            'CPU provider18 and baseline CpuProgram ABI3 are exercised; direct Metal does not instantiate or qualify the default ProviderVTable assembly.'],
    archive=relative_identity(archive),archive_files=len(files),
    previous_windows_evidence_unchanged=[dict(x,path=Path(x['path']).relative_to(R).as_posix()) for x in protected])
proof.write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
for old in protected:assert identity(old['path'])==old
(S/'publication.json').write_text(json.dumps(dict(proof=relative_identity(proof),archive=relative_identity(archive),
    cases=6,failures=0,skips=0,protected_windows=protected),indent=2)+'\n')
print(json.dumps(read(S/'publication.json'),indent=2))
