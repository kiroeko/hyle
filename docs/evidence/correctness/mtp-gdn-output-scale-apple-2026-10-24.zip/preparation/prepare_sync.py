"""Build the finite source bundle and command list locally. No remote actions."""
import hashlib
import json
import argparse
import re
import shlex
import tarfile
from pathlib import Path

S = Path(__file__).resolve().parent
R = S.parents[2]
P = S.parent / 'batched-bfloat-linear-apple-proposal'
plan = json.loads((S / 'plan.json').read_text())
prior = json.loads((P / 'commands.json').read_text())
inventory = json.loads((S / 'remote-inventory.json').read_text(encoding='utf-8-sig'))
helper = json.loads((S / 'helper-identities.json').read_text())
p = argparse.ArgumentParser(); p.add_argument('--attempt', type=int, default=1)
a = p.parse_args(); assert a.attempt > 0
D = plan['remote']['new_output'].rsplit('/attempt', 1)[0] + '/attempt' + str(a.attempt)
SRC = D + '/source'
CPU = inventory['families']['cpu_0bae']['root']
METAL = inventory['families']['metal_d851']['root']


def identity(path):
    p = Path(path); raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def checked(item):
    assert identity(item['path']) == item, item['path']


for info in plan['cpu']['host_sources']:
    checked(info)
checked(helper['before']); checked(helper['after']); checked(helper['patch'])
cpu_native = dict(root=CPU, relative='src/ggml-cpu/ops.cpp',
                  source=next(x for x in inventory['families']['cpu_0bae']['files']
                              if x['path'].endswith('/ops.cpp')),
                  edits=plan['cpu']['native_changes']['edits'])
metal_native = []
for rel, edits in plan['metal']['native_changes'].items():
    metal_native.append(dict(root=METAL, relative=rel, edits=edits,
       source=next(x for x in inventory['families']['metal_d851']['files']
                   if x['path'] == METAL + '/' + rel)))
(S / 'native-edits.json').write_text(json.dumps(dict(cpu=[cpu_native], metal=metal_native), indent=2) + '\n')

sources = [R / Path(x['path']).relative_to(R) for x in plan['cpu']['host_sources']]
sources += [R / 'src/compute_provider_ggml_metal/native_program.cc',
            R / 'src/compute_provider_ggml_metal/native_program.h']
test = S / 'next-source/tests/compute_provider_native/gdn_output_scale_test.cc'
files = set(p.resolve() for p in sources)
roots = [R / 'include', R / 'src/compute', R / 'src/compute_ops',
         R / 'src/compute_ggml_runtime', R / 'src/compute_provider_ggml',
         R / 'src/compute_provider_ggml_metal', R]
pending = list(files) + [test]
seen = set()
while pending:
    path = pending.pop()
    if path in seen:
        continue
    seen.add(path)
    for name in re.findall(r'^\s*#\s*(?:include|import)\s*["<]([^">]+)[">]',
                           path.read_text(errors='strict'), flags=re.M):
        for root in [path.parent, *roots]:
            candidate = (root / name).resolve()
            if candidate.is_file() and any(candidate.is_relative_to(R / d) for d in ('src', 'include')):
                if candidate not in files:
                    files.add(candidate); pending.append(candidate)
                break

manifest = dict(remote_directory=D, source_origin=str(R),
    scope='Finite current host/test dependency headers only; no SDK, GGML source tree or binaries.', files=[])
for f in sorted(files):
    rel = f.relative_to(R).as_posix()
    manifest['files'].append(dict(local=identity(f), archive='source/' + rel))
manifest['files'].append(dict(local=identity(test), archive='source/tests/compute_provider_native/gdn_output_scale_test.cc'))
for name in ['native-edits.json', 'prepare_native.py', 'run_commands.py']:
    manifest['files'].append(dict(local=identity(S / name), archive=name))
manifest['total_bytes'] = sum(x['local']['bytes'] for x in manifest['files'])
assert manifest['total_bytes'] < 8 * 1024 * 1024
assert len({x['archive'] for x in manifest['files']}) == len(manifest['files'])

common = ['-O3', '-DNDEBUG', '-std=c++23', '-arch', 'arm64', '-isysroot',
          '/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk', '-mmacosx-version-min=14.4',
          '-Wall', '-Wextra', '-Wpedantic', '-DHYLE_STATIC']
includes = ['-I' + SRC + '/include'] + ['-I' + SRC + '/src/' + x for x in (
    'compute', 'compute_ops', 'compute_ggml_runtime', 'compute_provider_ggml',
    'compute_provider_ggml_metal', 'compute_batch')]
cpu_inc = ['-I' + CPU + '/' + x for x in ('include', 'src', 'src/ggml-cpu')]
metal_inc = ['-I' + METAL + '/' + x for x in ('include', 'src', 'src/ggml-metal')]
gtest = next(x[2:] for x in prior['cpu']['compile'][1]['argv']
             if x.startswith('-I') and x.endswith('/googletest/include')) if any(
    x.startswith('-I') and x.endswith('/googletest/include') for x in prior['cpu']['compile'][1]['argv']) else next(
    prior['cpu']['compile'][1]['argv'][i+1] for i,x in enumerate(prior['cpu']['compile'][1]['argv']) if x == '-isystem')


def compile_cmd(name, flags, source, output):
    return dict(name=name, cwd=D, argv=flags + ['-MMD', '-MF', output + '.d', '-c', source, '-o', output],
                inputs=[source], outputs=[output, output + '.d'])


def strip_io(command):
    flags = shlex.split(command)
    for key in ['-o', '-c']:
        i = flags.index(key); del flags[i:i+2]
    return flags


commands = dict(remote_directory=D, required_contracts=plan['required_contracts'],
                preparation=[dict(name='same-family-native-overlay-and-single-GDN-embed', cwd=D,
                  argv=['python3', D + '/prepare_native.py'], inputs=[D + '/native-edits.json'],
                  outputs=[D + '/native-preparation.json'])],
                host=[], native=[], archive=[], link={}, run={})
provider_flags = [x for x in prior['cpu']['compile'][0]['argv'] if x.startswith('-D')]
assert not any('AVX2_PROGRAM' in x for x in provider_flags)
for item in plan['cpu']['host_sources']:
    rel = Path(item['path']).relative_to(R).as_posix()
    name = rel[4:-3].replace('/', '--')
    flags = ['/usr/bin/clang++', *common, *includes, *cpu_inc]
    if rel.startswith('src/compute/'):
        flags += ['-DHYLE_COMPUTE_BUILD']
    elif rel.startswith('src/compute_ops/'):
        flags += ['-DHYLE_COMPUTE_OPS_BUILD']
    elif rel.startswith('src/compute_backend_cpu/'):
        flags += ['-DHYLE_COMPUTE_BACKEND_CPU_BUILD']
    elif rel.startswith('src/compute_provider_ggml/'):
        flags += provider_flags
    elif rel.startswith('src/compute_ggml_runtime/'):
        flags += ['-DHYLE_COMPUTE_GGML_RUNTIME_BUILD']
    commands['host'].append(compile_cmd(name, flags, SRC + '/' + rel, D + '/' + name + '.o'))

commands['host'].append(compile_cmd('metal-provider', ['/usr/bin/clang++', *common, *includes, *metal_inc,
    '-DGGML_USE_METAL', '-DHYLE_COMPUTE_PROVIDER_GGML_METAL_BUILD', '-DHYLE_GGML_METAL_IQ1_EXTENSIONS=1'],
    SRC + '/src/compute_provider_ggml_metal/native_program.cc', D + '/metal-provider.o'))
for backend, macro, language in [('cpu', 'HYLE_GDN_SCALE_CPU=1', 'c++'),
                                  ('metal', 'HYLE_GDN_SCALE_METAL_NATIVE=1', 'objective-c++')]:
    flags = ['/usr/bin/clang++', *common, *includes, *(cpu_inc if backend == 'cpu' else metal_inc),
             '-D' + macro, '-isystem', gtest, '-x', language]
    if backend == 'metal': flags += ['-fobjc-arc']
    commands['host'].append(compile_cmd(backend + '-test', flags,
        SRC + '/tests/compute_provider_native/gdn_output_scale_test.cc', D + '/' + backend + '-test.o'))

for backend, original, rel in [
    ('cpu', plan['cpu']['native_compile_recipe'], 'src/ggml-cpu/ops.cpp'),
    ('metal', plan['metal']['native_compile_recipe'], 'src/ggml-metal/ggml-metal-ops.cpp')]:
    flags = strip_io(original['command']) + ['-I' + SRC + '/src/compute_ggml_runtime']
    if backend == 'metal': flags += ['-I' + D + '/native-metal/src/ggml-metal',
                                    '-I' + METAL + '/src/ggml-metal']
    commands['native'].append(compile_cmd(backend + '-native-ops', flags,
        D + '/native-' + backend + '/' + rel, D + '/' + backend + '-native-ops.o'))
commands['native'].append(compile_cmd('metal-gdn-embed', ['/usr/bin/clang', '-O3', '-DNDEBUG', '-arch', 'arm64',
    '-isysroot', '/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk', '-mmacosx-version-min=14.4', '-fPIC', '-x', 'assembler'],
    D + '/native-metal/autogenerated/ggml-metal-embed-gated_delta_net.s', D + '/metal-gdn-embed.o'))

core_objects = [D + '/' + Path(x['path']).relative_to(R).as_posix()[4:-3].replace('/', '--') + '.o'
                for x in plan['cpu']['host_sources']
                if '/src/compute/' in x['path'].replace('\\', '/') or '/src/compute_ops/' in x['path'].replace('\\', '/')]
assert len(core_objects) == 27
core_archives = []
for module in ('compute', 'compute_ops'):
    objects = [x for x in core_objects if Path(x).name.startswith(module + '--')]
    assert len(objects) == (21 if module == 'compute' else 6)
    archive = D + '/libhyle_' + module + '_gdn_scale.a'
    commands['archive'].append(dict(name='archive-' + module, cwd=D,
        argv=['/usr/bin/libtool', '-static', '-o', archive, *objects],
        inputs=objects, outputs=[archive]))
    core_archives.append(archive)
cpu_objects = [x['outputs'][0] for x in commands['host']
               if x['name'] not in ('metal-provider', 'metal-test')
               and x['outputs'][0] not in core_objects]
cpu_objects += [D + '/cpu-native-ops.o', prior['remote_directory'] + '/cpu_hadamard.o']
metal_objects = [D + '/compute_ggml_runtime--metadata_arena.o', D + '/metal-provider.o',
                 D + '/metal-test.o', D + '/metal-native-ops.o', D + '/metal-gdn-embed.o']
for backend, objects in [('cpu', cpu_objects), ('metal', metal_objects)]:
    old = prior[backend]['link'][0]['argv']
    first_obj = next(i for i,x in enumerate(old) if x.endswith('.o'))
    libs = [x for x in old if x.endswith('.a') and not any(x.endswith(y) for y in (
        'libhyle_compute.a', 'libhyle_compute_ops.a', 'libhyle_compute_backend_cpu.a', 'libhyle_compute_ggml_runtime.a'))]
    # Reuse only the explicitly selected backend's exact original family.
    for x in libs:
        if Path(x).name.startswith('libggml'):
            assert ('a-cpu-apple' in x) == (backend == 'cpu'), x
    image = D + '/' + backend + '-gdn-scale-checks'
    tail = ['-lm', '-framework', 'Foundation', '-framework', 'Metal', '-framework', 'MetalKit']
    if backend == 'cpu': tail += ['-framework', 'Accelerate']
    commands['link'][backend] = dict(name=backend + '-link', cwd=D,
        argv=old[:first_obj] + objects + core_archives + libs + tail + ['-o', image, '-Wl,-map,' + image + '.map'],
        inputs=objects+core_archives+libs, outputs=[image, image + '.map'])
    commands['run'][backend] = dict(name=backend + '-run', cwd=D,
        argv=[image, '--gtest_filter=GdnOutputScale.*', '--gtest_output=xml:' + D + '/' + backend + '-tests.xml'],
        inputs=[image], outputs=[D + '/' + backend + '-tests.xml'], expected_cases=3)

(S / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
manifest['files'].append(dict(local=identity(S / 'commands.json'), archive='commands.json'))
manifest['total_bytes'] += manifest['files'][-1]['local']['bytes']
(S / 'sync-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(S / 'focused-source.tar.gz', 'w:gz') as bundle:
    for item in manifest['files']:
        checked(item['local'])
        bundle.add(item['local']['path'], arcname=item['archive'], recursive=False)
    bundle.add(S / 'sync-manifest.json', arcname='sync-manifest.json', recursive=False)

print(json.dumps(dict(files=len(manifest['files']), source_bytes=manifest['total_bytes'],
    bundle=identity(S / 'focused-source.tar.gz'), commands=identity(S / 'commands.json'),
    host_jobs=len(commands['host']), native_jobs=len(commands['native']),
    builds=0, remote_writes=0, native_executions=0, HTTP=0), indent=2))
