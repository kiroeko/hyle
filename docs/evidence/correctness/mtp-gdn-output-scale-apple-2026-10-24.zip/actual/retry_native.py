"""Record the one copied-source include-path correction and finish native jobs."""
import hashlib
import json
import subprocess
import time
from pathlib import Path
S = Path(__file__).resolve().parent
plan = json.loads((S/'commands.json').read_text())

def identity(path):
    p=Path(path); raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

for original in plan['native'][1:]:
    job=dict(original)
    job['argv']=list(original['argv'])
    if job['name']=='metal-native-ops':
        family='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78'
        job['argv'].insert(1,'-I'+family+'/src/ggml-metal')
    out=S/'logs'/(job['name']+'-recipe2');out.mkdir(parents=True,exist_ok=False)
    (out/'command.json').write_text(json.dumps(dict(original=original,actual=job,
        correction='Moving the sole native cpp into a new overlay loses its original sibling-header search; explicitly add the same family src/ggml-metal include. No source change.'),indent=2)+'\n')
    start=time.monotonic()
    with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
        result=subprocess.run(job['argv'],cwd=job['cwd'],stdout=stdout,stderr=stderr,timeout=1800)
    (out/'result.json').write_text(json.dumps(dict(exit_code=result.returncode,timed_out=False,
        elapsed_seconds=time.monotonic()-start,inputs=[identity(x) for x in job['inputs']],
        outputs=[identity(x) for x in job['outputs'] if Path(x).is_file()]),indent=2)+'\n')
    assert result.returncode==0,job['name']
    print('Completed',job['name'],'recipe2',flush=True)
