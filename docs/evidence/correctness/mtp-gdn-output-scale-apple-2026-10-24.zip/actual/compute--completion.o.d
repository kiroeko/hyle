/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/compute--completion.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/src/compute/completion.cc \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/compute/completion.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/compute/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/error/result.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/compiler.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/detail/compiler_attributes.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/environment.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/assert.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/detail/preprocessor.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/error/status.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/obs/trace.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/src/compute/completion_internal.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/compute/detail/completion_access.h
