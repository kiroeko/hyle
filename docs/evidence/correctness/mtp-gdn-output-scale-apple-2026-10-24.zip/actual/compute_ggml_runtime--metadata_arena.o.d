/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/compute_ggml_runtime--metadata_arena.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/src/compute_ggml_runtime/metadata_arena.cc \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/src/compute_ggml_runtime/metadata_arena.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/error/result.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/compiler.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/detail/compiler_attributes.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/environment.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/assert.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/core/detail/preprocessor.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/error/status.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/mem/allocator.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/include/hyle/mem/visibility.h \
  /Users/kiro/hyle-scratch/compute-unified/a-cpu-apple/selected-graph/source-build/hyle/src/compute_ggml_runtime/source-0bae7e9e90b384d8/include/ggml.h
