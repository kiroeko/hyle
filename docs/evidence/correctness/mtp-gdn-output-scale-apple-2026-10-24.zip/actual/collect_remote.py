"""Collect only this completed focused run's text sources/metadata/logs."""
import hashlib
import json
import shlex
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path
S=Path(__file__).resolve().parent

def identity(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

plan=json.loads((S/'commands.json').read_text())
manifest=json.loads((S/'sync-manifest.json').read_text())
for row in manifest['files']:
    actual=identity(S/row['archive'])
    assert (actual['bytes'],actual['sha256'])==(row['local']['bytes'],row['local']['sha256'])
hosts=[]
for job in plan['host']:
    out=S/'logs'/job['name'];r=json.loads((out/'result.json').read_text())
    assert r['exit_code']==0 and not r['timed_out']
    hosts.append(dict(command=identity(out/'command.json'),result=identity(out/'result.json')))
assert len(hosts)==38
native=[]
for name in ['cpu-native-ops','metal-native-ops-recipe2','metal-gdn-embed-recipe2']:
    out=S/'logs'/name;r=json.loads((out/'result.json').read_text())
    assert r['exit_code']==0 and not r['timed_out']
    native.append(dict(command=identity(out/'command.json'),result=identity(out/'result.json')))
sources={}
for dep in S.glob('*.d'):
    tokens=shlex.split(dep.read_text().replace('\\\n',' '))
    assert tokens[0].endswith(':')
    for word in tokens[1:]:
        p=Path(word)
        assert p.is_file(),word
        sources[str(p)]=identity(p)
(S/'actual-dependencies.json').write_text(json.dumps(list(sources.values()),indent=2)+'\n')
family=json.loads((S/'native-edits.json').read_text())
originals=[]
for rows in family.values():
    for row in rows:
        assert identity(row['source']['path'])==row['source']
        originals.append(row['source'])
results=[]
for backend in ('cpu','metal'):
    run=S/'logs'/(backend+'-run');status=json.loads((run/'result.json').read_text())
    summary=json.loads((run/'summary.json').read_text())
    assert status['exit_code']==0 and not status['timed_out']
    root=ET.parse(S/(backend+'-tests.xml')).getroot()
    assert int(root.get('tests'))==3
    assert all(int(root.get(k,'0'))==0 for k in ('failures','errors','disabled'))
    assert not list(root.iter('skipped'))
    maps=(S/(backend+'-gdn-scale-checks.map')).read_text()
    assert '/'+backend+'-native-ops.o' in maps
    if backend=='cpu':
        assert 'libggml-cpu.a(ops.cpp.o)' not in maps
        assert '/apple-current-sdk-2026-10-21/relocated/sdk/lib/libggml-' not in maps
    else:
        assert 'libggml-metal.a(ggml-metal-ops.cpp.o)' not in maps
        assert 'libggml-metal.a(ggml-metal-embed-gated_delta_net.s.o)' not in maps
        assert '/a-cpu-apple/selected-graph/static-sdk-relocated/lib/libggml-' not in maps
    results.append(dict(backend=backend,summary=summary,
        case_names=[x.get('name') for x in root.iter('testcase')],
        process=identity(run/'result.json'),link_map=identity(S/(backend+'-gdn-scale-checks.map'))))
hardware=[]
for argv in [['uname','-m'],['sysctl','-n','hw.model'],['sysctl','-n','hw.memsize'],
             ['sysctl','-n','machdep.cpu.brand_string'],['sw_vers'],['/usr/bin/clang++','--version']]:
    p=subprocess.run(argv,capture_output=True,text=True)
    hardware.append(dict(argv=argv,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
data=dict(status='passed',scope='Focused CPU explicit Compute provider and direct Metal NativeProgram only.',
    contracts=dict(cpu_program_abi=3,cpu_provider_contract=18,recurrent_custom_id=9,native_gdn_scale_contract='0x48594732'),
    remote_directory=str(S),hardware=hardware,results=results,host_compile_records=hosts,
    successful_native_compile_records=native,successful_native_compile_commands=3,
    failed_native_recipe_command=identity(S/'logs/metal-native-ops/result.json'),
    source_manifest=identity(S/'sync-manifest.json'),native_preparation=identity(S/'native-preparation.json'),
    actual_dependencies=identity(S/'actual-dependencies.json'),original_native_sources_unchanged=originals,
    model_or_graph_qualification=False,throughput_evidence=False,memory_peak_evidence=False)
(S/'actual-summary.json').write_text(json.dumps(data,indent=2)+'\n')
files=[]
allowed={'.py','.json','.cc','.cpp','.h','.hpp','.mm','.metal','.s','.log','.xml','.d','.map'}
for base in [S/'source',S/'native-cpu',S/'native-metal',S/'logs']:
    for p in base.rglob('*'):
        if p.is_file() and p.suffix in allowed:files.append((p,p.relative_to(S).as_posix()))
for p in S.iterdir():
    if p.is_file() and p.suffix in allowed:files.append((p,p.name))
old=S.parent/'attempt1'
for rel in ['prepare_native.py','commands.json','sync-manifest.json']:
    p=old/rel
    if p.is_file():files.append((p,'preparation-failure-attempt1/'+rel))
for p in (old/'logs').rglob('*'):
    if p.is_file() and p.suffix in allowed:
        files.append((p,'preparation-failure-attempt1/logs/'+p.relative_to(old/'logs').as_posix()))
for name, rows in family.items():
    p=Path(rows[0]['root'])/'LICENSE'
    if p.is_file():files.append((p,'licenses/ggml-'+name+'-LICENSE'))
assert len({arc for _,arc in files})==len(files)
archive=S/'results.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for p,arc in files:t.add(p,arcname=arc,recursive=False)
print(json.dumps(dict(archive=identity(archive),files=len(files),summary=identity(S/'actual-summary.json'))))
