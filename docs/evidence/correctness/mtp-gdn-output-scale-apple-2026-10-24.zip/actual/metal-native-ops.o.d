/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/metal-native-ops.o: \
  /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/native-metal/src/ggml-metal/ggml-metal-ops.cpp \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/ggml-metal/ggml-metal-ops.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/ggml-metal/ggml-metal-device.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/../include/ggml.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/source/src/compute_ggml_runtime/gated_delta_scale.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/ggml-metal/../ggml-impl.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/../include/gguf.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/ggml-metal/../ggml-backend-impl.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/../include/ggml-backend.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/../include/ggml-alloc.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2/native-metal/src/ggml-metal/ggml-metal-impl.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/ggml-metal/ggml-metal-common.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/ggml-metal/ggml-metal-fusion.h \
  /Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/apple-current-sdk-2026-10-21/build/src/compute_ggml_runtime/source-d851e24e75c99c78/src/ggml-metal/ggml-metal-tuning.h
