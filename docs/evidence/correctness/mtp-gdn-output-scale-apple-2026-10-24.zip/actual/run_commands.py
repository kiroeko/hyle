"""Small root-invoked runner for the frozen local command list; no SSH/HTTP."""
import argparse
import hashlib
import json
import subprocess
import time
import xml.etree.ElementTree as ET
from pathlib import Path

S = Path(__file__).resolve().parent


def identity(path):
    p = Path(path); raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def verify_source():
    manifest = json.loads((S / 'sync-manifest.json').read_text())
    for item in manifest['files']:
        actual = identity(S / item['archive'])
        assert (actual['bytes'], actual['sha256']) == (item['local']['bytes'], item['local']['sha256']), item['archive']


p = argparse.ArgumentParser()
p.add_argument('stage', choices=('preparation', 'native', 'host', 'archive', 'link', 'run'))
p.add_argument('--backend', choices=('cpu', 'metal'))
a = p.parse_args()
verify_source()
plan = json.loads((S / 'commands.json').read_text())
assert Path(plan['remote_directory']) == S
assert plan['required_contracts']['cpu_program_abi'] == 3
assert plan['required_contracts']['provider'] == 18
assert plan['required_contracts']['recurrent_custom_id'] == 9
if a.stage in ('link', 'run'):
    assert a.backend
    jobs = [plan[a.stage][a.backend]]
else:
    assert a.backend is None
    jobs = plan[a.stage]
for job in jobs:
    out = S / 'logs' / job['name']
    out.mkdir(parents=True, exist_ok=False)
    (out / 'command.json').write_text(json.dumps(job, indent=2) + '\n')
    inputs = [identity(x) for x in job['inputs']]
    start = time.monotonic()
    try:
        with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
            result = subprocess.run(job['argv'], cwd=job['cwd'], stdout=stdout, stderr=stderr, timeout=1800)
        status = dict(exit_code=result.returncode, timed_out=False)
    except subprocess.TimeoutExpired:
        status = dict(exit_code=None, timed_out=True)
    status.update(elapsed_seconds=time.monotonic()-start,
                  scope='Focused command wall time, not model TPS.', inputs=inputs,
                  outputs=[identity(x) for x in job['outputs'] if Path(x).is_file()])
    (out / 'result.json').write_text(json.dumps(status, indent=2) + '\n')
    verify_source()
    assert status['exit_code'] == 0 and not status['timed_out'], job['name']
    if a.stage == 'run':
        root = ET.parse(job['outputs'][0]).getroot()
        assert int(root.get('tests')) == job['expected_cases'] == 3
        assert all(int(root.get(k, '0')) == 0 for k in ('failures', 'errors', 'disabled'))
        assert not list(root.iter('skipped'))
        (out / 'summary.json').write_text(json.dumps(dict(
            backend=a.backend, tests=3, failures=0, skips=0, xml=identity(job['outputs'][0]),
            image=inputs[0], source_manifest=identity(S / 'sync-manifest.json'),
            scope='CPU explicit ggml provider or direct Metal NativeProgram; default/raw GDN/KDA/Recurrent, two snapshots, retained state and cold optional/finite domains. No Graph/default Apple Context claim.',
            model_throughput_evidence=False), indent=2) + '\n')
    print('Completed', job['name'], flush=True)
