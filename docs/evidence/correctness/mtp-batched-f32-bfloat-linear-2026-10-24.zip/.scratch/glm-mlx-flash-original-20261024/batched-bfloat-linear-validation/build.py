from pathlib import Path
import argparse,importlib.util,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[2]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    out=importlib.util.module_from_spec(spec);spec.loader.exec_module(out);return out
h=module('batch_bf_build',R/'.scratch/native-paged-effects-20261022/build_windows.py');b,c=h.b,h.c
q=module('batch_bf_run',R/'.scratch/qwen-mtp-quality-20261022/run_quality.py')
BASE=S.parent/'f32-bfloat-linear-validation/tests-link1'
TAGS=('cpu-provider','tensor-program','cublas','cpu-test','cuda-test')
RECIPES={tag:BASE.parent/'compile1'/tag/'identity.json' for tag in TAGS}

def compile_all():
    h.S=S;h.RECIPES=RECIPES;h.SOURCES={}
    for tag in TAGS:h.compile_one(tag,1)

def link():
    base=c.read(BASE/'link-plan.json');replacements={};records=[]
    for tag in TAGS:
        old=c.read(RECIPES[tag]);path=S/'compile1'/tag/'identity.json';new=c.read(path)
        assert all(b.identity(x['path'])==x for x in (new['source'],new['object'],*new['dependencies']))
        replacements[old['object']['path'].lower()]=new['object']['path'];records.append(b.identity(path))
    out=S/'tests-link1';out.mkdir(exist_ok=False);(out/'tmp').mkdir();image=out/'batched-bfloat-checks.exe'
    command=[replacements.get(arg.lower(),arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
    assert all(sum(arg==value for arg in command)==1 for value in replacements.values())
    command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
    c.save(out/'link-plan.json',dict(command=command,base=b.identity(BASE/'link-plan.json'),compiled_records=records,
        retained_product_records=base['retained_product_records'],SDK_builds=0,NVCC_builds=0))
    env,_=b.environment(command,[],out);c.execute('link',command,env,out)
    runtime=c.read(BASE/'runtime-environment.json')
    for dll in runtime['staged_dlls']:
        assert b.identity(dll['path'])==dll;os.link(dll['path'],out/Path(dll['path']).name)
    runtime['PATH']=runtime['PATH'].replace(str(BASE),str(out));runtime['previous']=b.identity(BASE/'runtime-environment.json')
    runtime['staged_dlls']=[b.identity(x) for x in out.glob('*.dll')]
    c.save(out/'runtime-environment.json',runtime)
    c.save(out/'ready.json',dict(image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json')))
    print('LINKED current batched BF16',flush=True)

def run():
    image=S/'tests-link1';ready=c.read(image/'ready.json')
    assert b.identity(ready['image']['path'])==ready['image']
    env=os.environ.copy();env['PATH']=c.read(image/'runtime-environment.json')['PATH']
    cases=['GgmlCpuProvider.BatchedBfloatWeightsPreserveOriginalFloat32Rows',
        'GgmlCudaBfloatMatvec.BatchedBfloatWeightsPreserveOriginalFloat32Rows',
        'GgmlCpuProvider.BfloatWeightsPreserveFloat32ActivationCancellation',
        'GgmlCudaBfloatMatvec.BfloatWeightsPreserveFloat32ActivationCancellation',
        'GgmlCpuProvider.BfloatRouterMatMulRetainsNativeF32Score',
        'GgmlCudaBfloatMatvec.ExactRoundingForAlignedAndOddInnerWithBothRhsLayouts']
    out=S/'checks1';process=q.execute([ready['image']['path'],'--gtest_filter='+':'.join(cases),
        '--gtest_output=xml:'+str(out/'results.xml')],env,out,timeout=1800)
    if process['exit']:raise SystemExit(process['exit'])
    tree=ET.parse(out/'results.xml').getroot()
    assert int(tree.attrib['tests'])==len(cases)
    assert all(int(tree.attrib.get(k,0))==0 for k in ('failures','errors','disabled'))
    assert not tree.findall('.//skipped')
    c.save(out/'summary.json',dict(tests=len(cases),failures=0,skips=0,cases=cases,image=ready['image'],
        process=b.identity(out/'process.json'),xml=b.identity(out/'results.xml'),
        scope='CPU/CUDA mixed rank3 low-bit cancellation and existing rank2/BF16 regressions; Q32 original model not executed.',
        throughput_evidence=False,memory_evidence=False))
    print('PASSED',len(cases),'CPU/CUDA mixed tests',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=('compile','link','run'));args=p.parse_args()
    {'compile':compile_all,'link':link,'run':run}[args.action]()
