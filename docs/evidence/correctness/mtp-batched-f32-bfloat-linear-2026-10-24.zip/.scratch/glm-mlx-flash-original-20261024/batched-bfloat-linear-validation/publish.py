from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
S=Path(__file__).resolve().parent;R=S.parents[2]
P=S.parent/'batched-bfloat-linear-proposal'
D=R/'docs/evidence/correctness';NAME='mtp-batched-f32-bfloat-linear-2026-10-24'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):
    raw=p.read_bytes();return dict(path=p.relative_to(R).as_posix(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
summary=read(S/'checks1/summary.json');assert summary['tests']==6 and summary['failures']==summary['skips']==0
paths=set()
for p in S.rglob('*'):
    if p.is_file() and p.suffix in ('.json','.log','.xml','.cc','.py'):paths.add(p)
for name in ('source.patch','proposal.json','applied.json'):paths.add(P/name)
proposal=read(P/'proposal.json')
for row in proposal['files']:
    path=R/row['path'];assert ident(path)['sha256']==row['after_sha256'];paths.add(path)
archive=D/(NAME+'.zip');assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(paths):z.write(path,path.relative_to(R).as_posix())
record=dict(created_at=datetime.now(timezone.utc).isoformat(),
    scope='Shared BFloatLinearF32 exact aligned batched F32 activation and original BF16 weight capability required by the MLX source',
    public_contract='Dense rank2 A[M,K],W[N,K]->F32Y[M,N]; rank3 A[B,M,K],W[B,N,K]->F32Y[B,M,N]. No implicit batch broadcasting or F32-A narrowing.',
    native_lowering='Metadata-only A[K,1,M,B],W[K,N,1,B]->Y[N,1,M,B], single native mul_mat; CPU mixed SIMD dot uses actual batch weight pitch.',
    original_weights_retained=True,full_float32_weight_shadow=False,
    actual_windows=dict(tests=6,failures=0,skips=0,summary=ident(S/'checks1/summary.json'),
        xml=ident(S/'checks1/results.xml'),link=ident(S/'tests-link1/link-plan.json'),
        source_shape='Distinct actual test weight banks, F32 cancellation rows, M1/M2/M17; existing rank2 and BF16 paths also checked.',
        host_translation_units=5,SDK_builds=0,NVCC_builds=0),
    cold_only='Actual Q32 K/V-sized batch64 16MiB descriptors and unsupported CUDA N513/batch selector boundary are preparation checks, not original Q32 tensor execution.',
    limits=['CUDA B<=65535,M<=65535,evenK and B>1 requires N<=512 to retain native F32-A matvec without whole-W expansion.',
        'Metal paired-row and I16 batch-broadcast bounds retained; Metal/Vulkan code changed but not compiled or executed in this Windows batch.',
        'New rank3 BF16-A mathematical inference is accepted; CUDA/Metal/Vulkan explicitly decline that new device domain. Existing BF16-A rank2 behavior retained.',
        'No actual Q32 original weights/quality or end-to-end performance result.'],
    source_proposal=ident(P/'proposal.json'),source_patch=ident(P/'source.patch'),archive=ident(archive),
    archived_files=len(paths),throughput_evidence=False,memory_evidence=False)
out=D/(NAME+'.json');assert not out.exists();out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(evidence=ident(out),archive=ident(archive),tests=6)))
