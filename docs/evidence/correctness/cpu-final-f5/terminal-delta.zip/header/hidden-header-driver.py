import runpy,subprocess,sys
original=subprocess.run
def hidden(*a,**k):
 k['creationflags']=k.get('creationflags',0)|subprocess.CREATE_NO_WINDOW
 return original(*a,**k)
subprocess.run=hidden
sys.argv=sys.argv[1:]
runpy.run_path(sys.argv[0],run_name='__main__')
