exec(open('.scratch/cpu-ggml-isa-product-validate.py',encoding='utf-8').read().split("run('configure'")[0])
out=repo/'.scratch/validation/cpu-final-f5/header';out.mkdir(parents=True,exist_ok=True)
records=[]
compiler=Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/MSVC/14.50.35717/bin/Hostx64/x64/cl.exe')
# The public validator is unchanged. Inject the requested hidden-launch flag
# only into this invocation's subprocess calls to avoid Windows popups.
wrapper=out/'hidden-header-driver.py'
wrapper.write_text("import runpy,subprocess,sys\noriginal=subprocess.run\ndef hidden(*a,**k):\n k['creationflags']=k.get('creationflags',0)|subprocess.CREATE_NO_WINDOW\n return original(*a,**k)\nsubprocess.run=hidden\nsys.argv=sys.argv[1:]\nrunpy.run_path(sys.argv[0],run_name='__main__')\n",encoding='utf-8')
run('windows-native-header',['python',wrapper,repo/'scripts/header-self-contained.py',
    '--module','compute_provider_native','--header-dir','compute','--header','providers/native.h',
    '--include-dir',repo/'include','--cxx',compiler,'--cxx-compiler-id','MSVC','--cxx-frontend','MSVC'])
source='/root/hyle-scratch/active-cpu-z/source'
run('linux-native-header',['wsl.exe','-d','Ubuntu-24.04','--','python3',source+'/scripts/header-self-contained.py',
    '--module','compute_provider_native','--header-dir','compute','--header','providers/native.h',
    '--include-dir',source+'/include','--cxx','/usr/bin/g++-14','--cxx-compiler-id','GNU'])
import shlex
source='/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8/hyle-0.1.0-source'
command=['python3',source+'/scripts/header-self-contained.py','--module','compute_provider_native',
    '--header-dir','compute','--header','providers/native.h','--include-dir',source+'/include',
    '--cxx','/usr/bin/clang++','--cxx-compiler-id','AppleClang']
run('mac-native-header',['C:/Windows/System32/OpenSSH/ssh.exe','-o','BatchMode=yes','kiro@172.22.10.198',
    'export PATH=/opt/homebrew/bin:$PATH; '+shlex.join(command)])
