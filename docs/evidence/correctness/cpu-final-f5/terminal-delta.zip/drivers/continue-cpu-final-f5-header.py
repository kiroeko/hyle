import ctypes,json,subprocess,sys
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f5'
kernel=ctypes.windll.kernel32;kernel.SetErrorMode(32771)
kernel.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32]
kernel.OpenProcess.restype=ctypes.c_void_p
kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
kernel.CloseHandle.argtypes=[ctypes.c_void_p]
handle=kernel.OpenProcess(0x100000,False,80328)
if not handle:raise RuntimeError('Verified platform queue handle unavailable; inspect terminal receipt before resuming.')
print('Waiting on verified platform queue process 80328; independent header gate follows serially.',flush=True)
try:
    while True:
        state=kernel.WaitForSingleObject(handle,1000)
        if state==0:break
        if state!=258:raise RuntimeError('Cannot observe the original queue process')
finally:kernel.CloseHandle(handle)
records=json.loads((out/'platform-queue-receipt.json').read_text())
assert records[-1]['name']=='mixed-linux' and records[-1]['exit']==0,records[-1]
with (out/'header-driver.log').open('wb') as log:
    r=subprocess.run([sys.executable,'.scratch/validate-cpu-final-f5-native-header.py'],
        stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print({'name':'native-header-3-platform','exit':r.returncode},flush=True)
if r.returncode:print((out/'header-driver.log').read_text(errors='replace')[-4000:],flush=True)
raise SystemExit(r.returncode)
