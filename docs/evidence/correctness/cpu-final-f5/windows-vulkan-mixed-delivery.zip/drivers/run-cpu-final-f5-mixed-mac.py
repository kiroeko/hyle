import json,shlex,subprocess,time
from pathlib import Path

out=Path('.scratch/validation/cpu-final-f5/mixed-mac');remote='/Users/kiro/hyle-verify/cpu-final-mixed-e0388fbd'
source=remote+'/source';build=remote+'/build';consumer=remote+'/f5-consumer'
identity=json.loads((out/'sync.json').read_text());records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
ssh='C:/Windows/System32/OpenSSH/ssh.exe';flags={'creationflags':subprocess.CREATE_NO_WINDOW}
def run(name,args):
    start=time.monotonic();path=out/(str(len(records)+1)+'-'+name+'.log')
    with path.open('wb') as log:
        r=subprocess.run([ssh,'-o','BatchMode=yes','kiro@172.22.10.198',
            'export PATH=/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:$PATH OMP_NUM_THREADS=1 MKL_NUM_THREADS=1; '+shlex.join(args)],
            stdout=log,stderr=subprocess.STDOUT,**flags)
    records.append({'name':name,'args':args,'candidate':identity['candidate'],'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'log':path.name})
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
    if r.returncode:print(path.read_text(errors='replace')[-5500:],flush=True);r.check_returncode()
overlay=remote+'/f5-overlay.cmake'
content='function(f5_mixed_hook)\nadd_executable(f5_mixed_source "'+consumer+'/main.cc")\ntarget_compile_features(f5_mixed_source PRIVATE cxx_std_23)\ntarget_link_libraries(f5_mixed_source PRIVATE hyle::compute hyle::graph)\nhyle_stage_runtime_dependencies(f5_mixed_source)\nendfunction()\nif(CMAKE_CURRENT_SOURCE_DIR STREQUAL CMAKE_SOURCE_DIR)\ncmake_language(DEFER CALL f5_mixed_hook)\nendif()\n'
run('overlay',['python3','-c','from pathlib import Path;Path('+repr(overlay)+').write_text('+repr(content)+')'])
common=['-DHYLE_COMPONENTS=compute,graph','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_APPLE=ON','-DHYLE_COMPUTE_VULKAN=OFF','-DHYLE_COMPUTE_ONEDNN=AUTO','-DHYLE_COMPUTE_TORCH_CPU=AUTO','-DHYLE_BUILD_TESTS=OFF','-DHYLE_BUILD_BENCH=OFF','-DHYLE_INSTALL=ON','-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PROJECT_INCLUDE='+overlay]
for shape in ('static','shared'):
    prefix=remote+'/f5-'+shape+'-staging';relocated=remote+'/f5-'+shape+'-relocated'
    run(shape+'-configure',['cmake','-S',source,'-B',build,*common,'-DHYLE_STATIC='+('ON' if shape=='static' else 'OFF'),'-DCMAKE_INSTALL_PREFIX='+prefix])
    run(shape+'-build',['cmake','--build',build,'--parallel','2'])
    run(shape+'-source-43-48',[build+'/bin/f5_mixed_source'])
    run(shape+'-install',['cmake','--install',build])
    run(shape+'-relocate',['python3','-c','from pathlib import Path; a=Path('+repr(prefix)+'); b=Path('+repr(relocated)+'); root=Path('+repr(remote)+').resolve();assert a.resolve().parent==root and b.resolve().parent==root and a.is_dir() and not b.exists();a.rename(b)'])
    cb=remote+'/f5-'+shape+'-consumer'
    run(shape+'-consumer-configure',['cmake','-S',consumer,'-B',cb,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DCMAKE_PREFIX_PATH='+relocated,'-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
    run(shape+'-consumer-build',['cmake','--build',cb,'--parallel','2'])
    run(shape+'-consumer-43-48',[cb+'/cpu_final_delivery'])
    run(shape+'-loader',['otool','-L',cb+'/cpu_final_delivery'])
    if shape=='shared':run('shared-export',['python3',source+'/scripts/check-shared-export-hygiene.py','--root',relocated])
