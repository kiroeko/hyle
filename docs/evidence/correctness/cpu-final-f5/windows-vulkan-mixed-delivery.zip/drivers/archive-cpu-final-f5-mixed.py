import hashlib,json,zipfile
from pathlib import Path
repo=Path.cwd();base=repo/'.scratch/validation/cpu-final-f5';out=repo/'evidence/correctness/cpu-final-f5'
groups=[('windows-cuda','mixed-cuda-windows','returncode','shared-export'),
        ('windows-vulkan','mixed-vulkan-windows','returncode','shared-export'),
        ('mac-apple','mixed-mac','exit','shared-export'),
        ('linux-cuda','mixed-linux','exit','static-loader')]
accepted=[]
for name,folder,key,terminal in groups:
    raw=base/folder
    if not (raw/'receipt.json').exists():continue
    records=json.loads((raw/'receipt.json').read_text())
    # Linux ends static; Mac ends shared with export; Windows ends shared.
    if name=='mac-apple':terminal='shared-export'
    if records[-1]['name']!=terminal or any(r[key]!=0 for r in records):continue
    bundle=out/(name+'-mixed-delivery.zip')
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for path in raw.iterdir():
            if path.is_file():z.write(path,'raw/'+path.name)
        for path in (base/'delivery-consumer').iterdir():
            if path.is_file():z.write(path,'consumer/'+path.name)
        for path in repo.glob('.scratch/*cpu-final-f5*mixed*.py'):z.write(path,'drivers/'+path.name)
        for file in ('cleanup-delta.json','final-applicability.json'):
            if (base/file).exists():z.write(base/file,'input/'+file)
    item={'envelope':name,'product_candidate':'64b454fa23404d26bead60d495eda9475c802e32',
        'steps':records,'successful_steps':len(records),'consumer_contract':'43 exact cold requests x2 ordinary contexts; 48 numeric/replay checks per actual source/SDK consumer',
        'limits':'CPU seam delta only; no CPU-only WIN leak, no new GPU mathematical/performance/format qualification.',
        'bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()}
    (out/(name+'-mixed-delivery-receipt.json')).write_text(json.dumps(item,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    accepted.append({'envelope':name,'steps':len(records),'bytes':bundle.stat().st_size})
print(accepted)
