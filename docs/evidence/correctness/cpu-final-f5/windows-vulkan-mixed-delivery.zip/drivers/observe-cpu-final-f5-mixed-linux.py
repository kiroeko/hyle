import subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
code="from pathlib import Path;import json;root=Path('/root/hyle-scratch/active-cpu-z/f5-mixed-result');p=root/'receipt.json';r=json.loads(p.read_text()) if p.exists() else [];print(json.dumps(r[-3:],indent=2));logs=sorted(root.glob('*.log'),key=lambda x:x.stat().st_mtime);print(logs[-1].name if logs else 'no logs');print(logs[-1].read_text(errors='replace')[-2400:] if logs else '')"
r=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','-c',code],capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
print(r.stdout.decode('utf-8',errors='replace'));r.check_returncode()

