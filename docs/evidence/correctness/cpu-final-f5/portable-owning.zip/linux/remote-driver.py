
import json,os,subprocess,time
from pathlib import Path
root=Path('/root/hyle-scratch/active-cpu-z');source=root/'source';build=root/'build'
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/owning-linux')
identity=json.loads((root/'f5-sync.json').read_text())
assert identity['candidate']=='507bad9698f9988d371c59e5661a69e4394c580a'
env=dict(os.environ,CC='gcc-14',CXX='g++-14',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
env.pop('LD_LIBRARY_PATH',None)
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
def run(name,args):
 start=time.monotonic();args=list(map(str,args));log=out/(str(len(records)+1)+'-'+name+'.log')
 with log.open('wb') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,env=env)
 records.append({'name':name,'candidate':identity['candidate'],'args':args,'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name})
 (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
 if r.returncode:print(log.read_text(errors='replace')[-5000:],flush=True);r.check_returncode()
run('machine',['sh','-c','uname -a; g++-14 --version; cmake --version'])
run('configure',['cmake','-S',source,'-B',build,'-DCMAKE_BUILD_TYPE=Release','-DHYLE_COMPONENTS=compute,graph',
 '-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF','-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_CUDA=OFF',
 '-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_VULKAN=OFF','-U','CMAKE_PROJECT_INCLUDE','-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('build-owning',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','--parallel','2'])
run('owning',[build/'bin/hyle_compute_provider_native_test','--gtest_output=xml:'+str(out/'owning.xml')])
