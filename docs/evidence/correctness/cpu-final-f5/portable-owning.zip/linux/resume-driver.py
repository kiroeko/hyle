
import json,os,subprocess,time
from pathlib import Path
root=Path('/root/hyle-scratch/active-cpu-z');source=root/'source';build=root/'build'
out=Path('/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/owning-linux')
identity={'candidate':'64b454fa23404d26bead60d495eda9475c802e32'};import hashlib
digests={'src/compute_provider_native/indexing.cc': 'c30844646e56cf0d24188960f67f5a0d090f7130427ddece7faf8bd245d6a37b', 'src/compute_provider_native/reduction.cc': 'b855d6adcb8f388606a401d008d51fd16ffec81102c054b94f5ef1d2fb0ada28', 'src/compute_provider_native/transformer.cc': '2d70dc3595b146f6e2648dda4bdcc6030b47903eaaf11b9e42e3ace24fa43c11'}
for name,expected in digests.items():
 p=Path('/mnt/c/public/project-hyle/hyle')/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
 (source/name).write_bytes(p.read_bytes())
(out/'immutable-dead-code-delta.json').write_text(json.dumps({'candidate':identity['candidate'],'base':'507bad9698f9988d371c59e5661a69e4394c580a','sources':digests,'scope':'uncalled helper deletion and equivalent explicit NaN/return exits; canonical product diff verified'},indent=2)+'\n')
env=dict(os.environ,CC='gcc-14',CXX='g++-14',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
env.pop('LD_LIBRARY_PATH',None)
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
def run(name,args):
 start=time.monotonic();args=list(map(str,args));log=out/(str(len(records)+1)+'-'+name+'.log')
 with log.open('wb') as stream:r=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,env=env)
 records.append({'name':name,'candidate':identity['candidate'],'args':args,'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name})
 (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
 if r.returncode:print(log.read_text(errors='replace')[-5000:],flush=True);r.check_returncode()
run('build-owning',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','--parallel','2'])
run('owning',[build/'bin/hyle_compute_provider_native_test','--gtest_output=xml:'+str(out/'owning.xml')])
