import hashlib,json,subprocess,sys
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f5/owning-linux'
candidate=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
names=['src/compute_provider_native/indexing.cc','src/compute_provider_native/reduction.cc',
       'src/compute_provider_native/transformer.cc']
digests={name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in names}
delta=subprocess.check_output(['git','diff','--name-only','507bad9698f9988d371c59e5661a69e4394c580a',candidate,'--','src','include','cmake','third_party'],text=True).splitlines()
assert delta==names,delta
template=(repo/'.scratch/run-cpu-final-f5-linux-owning.py').read_text(encoding='utf-8')
code=template.split("code=r'''",1)[1].split("'''\ndriver=",1)[0]
start=code.index("run('machine'");code=code[:start]+code[code.index("run('build-owning'",start):]
code=code.replace("identity=json.loads((root/'f5-sync.json').read_text())\nassert identity['candidate']=='507bad9698f9988d371c59e5661a69e4394c580a'", 
 "identity={'candidate':"+repr(candidate)+"};import hashlib\ndigests="+repr(digests)+"\nfor name,expected in digests.items():\n p=Path('/mnt/c/public/project-hyle/hyle')/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected\n (source/name).write_bytes(p.read_bytes())\n(out/'immutable-dead-code-delta.json').write_text(json.dumps({'candidate':identity['candidate'],'base':'507bad9698f9988d371c59e5661a69e4394c580a','sources':digests,'scope':'uncalled helper deletion and equivalent explicit NaN/return exits; canonical product diff verified'},indent=2)+'\\n')")
driver=out/'resume-driver.py';driver.write_text(code,encoding='utf-8')
with (out/'resume-driver.log').open('wb') as stream:
    r=subprocess.run(['wsl.exe','-d','Ubuntu-24.04','--','python3','/mnt/c/public/project-hyle/hyle/.scratch/validation/cpu-final-f5/owning-linux/resume-driver.py'],stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print((out/'resume-driver.log').read_text(errors='replace')[-5500:],flush=True)
r.check_returncode()
