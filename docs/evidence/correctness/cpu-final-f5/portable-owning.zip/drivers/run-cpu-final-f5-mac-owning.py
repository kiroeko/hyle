import ctypes,hashlib,json,shlex,subprocess,time
from pathlib import Path
repo=Path.cwd();out=repo/'.scratch/validation/cpu-final-f5/owning-mac';out.mkdir(parents=True,exist_ok=True)
remote='/Users/kiro/hyle-verify/cpu-final-42898c37';source=remote+'/source';build=remote+'/build'
archive='/Users/kiro/hyle-verify/cpu-final-delivery-9a9936e8/f5-source.tar'
identity=json.loads((repo/'.scratch/validation/cpu-final-f5/source-identity.json').read_text())
ctypes.windll.kernel32.SetErrorMode(32771);flags={'creationflags':subprocess.CREATE_NO_WINDOW}
ssh='C:/Windows/System32/OpenSSH/ssh.exe';scp='C:/Windows/System32/OpenSSH/scp.exe'
records=json.loads((out/'receipt.json').read_text()) if (out/'receipt.json').exists() else []
def run(name,args):
    start=time.monotonic();log=out/(str(len(records)+1)+'-'+name+'.log')
    with log.open('wb') as stream:
        r=subprocess.run([ssh,'-o','BatchMode=yes','kiro@172.22.10.198',
            'export PATH=/opt/homebrew/bin:$PATH OMP_NUM_THREADS=1 MKL_NUM_THREADS=1; '+shlex.join(args)],
            stdout=stream,stderr=subprocess.STDOUT,**flags)
    records.append({'name':name,'candidate':identity['candidate'],'args':args,'exit':r.returncode,
        'seconds':round(time.monotonic()-start,3),'log':log.name})
    (out/'receipt.json').write_text(json.dumps(records,indent=2)+'\n')
    print(records[-1],flush=True)
    if r.returncode:print(log.read_text(errors='replace')[-5000:],flush=True);r.check_returncode()
# Reuse the audited forward-only sync body; no transfer or new source root.
text=(repo/'.scratch/sync-cpu-final-f5.py').read_text(encoding='utf-8')
body=text.split("code=r'''",1)[1].split("'''\nconsumer=",1)[0]
for key,value in [('ROOT',remote),('SOURCE',source),('ARCHIVE',archive),('SHA',identity['archive_sha256']),('CANDIDATE',identity['candidate'])]:
    body=body.replace(key,repr(value))
run('forward-sync',['python3','-c',body])
run('machine',['sh','-c','sysctl -n hw.model; sw_vers; clang++ --version; cmake --version'])
run('configure',['cmake','-S',source,'-B',build,'-DHYLE_BUILD_TESTS=ON','-DHYLE_INSTALL=OFF',
    '-DHYLE_COMPUTE_CPU=ON','-DHYLE_COMPUTE_APPLE=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_VULKAN=OFF',
    '-DFETCHCONTENT_FULLY_DISCONNECTED=ON'])
run('build-owning',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','--parallel','2'])
run('owning',[build+'/bin/hyle_compute_provider_native_test','--gtest_output=xml:'+remote+'/f5-owning.xml'])
subprocess.run([scp,'-q','-o','BatchMode=yes','kiro@172.22.10.198:'+remote+'/f5-owning.xml',str(out/'owning.xml')],
    check=True,capture_output=True,timeout=20,**flags)
