exec(open('.scratch/validate-cpu-final-f5-first.py',encoding='utf-8').read().split("\nrun('configure-tests'")[0])
run('build-owning-migration',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','--parallel','2'])
run('owning-migration-tests',[build/'bin/hyle_compute_provider_native_test.exe','--gtest_output=xml:'+str(out/'owning-migration.xml')])
