exec(open('.scratch/validate-cpu-final-f5-owning-migration.py',encoding='utf-8').read().split("\nrun('build-owning-migration'")[0])
run('build-owning-migration-corrected',['cmake','--build',build,'--target','hyle_compute_provider_native_tests','--parallel','2'])
run('owning-migration-tests-corrected',[build/'bin/hyle_compute_provider_native_test.exe','--gtest_output=xml:'+str(out/'owning-migration-corrected.xml')])
