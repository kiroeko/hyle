import hashlib,json,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
repo=Path.cwd();base=repo/'.scratch/validation/cpu-final-f5';out=repo/'evidence/correctness/cpu-final-f5'
out.mkdir(parents=True,exist_ok=True);results=[]
bundle=out/'portable-owning.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for platform in ('mac','linux'):
        raw=base/('owning-'+platform);xml=raw/'owning.xml'
        root=ET.parse(xml).getroot();cases=root.findall('.//testcase')
        assert len(cases)==144 and not any(c.find('failure') is not None or c.find('skipped') is not None for c in cases)
        records=json.loads((raw/'receipt.json').read_text());assert records[-1]['name']=='owning' and records[-1]['exit']==0
        results.append({'platform':platform,'product_candidate':records[-1]['candidate'],'tests':144,'failures':0,'skips':0,
            'successful_steps':sum(r['exit']==0 for r in records),'original_failures_retained':sum(r['exit']!=0 for r in records)})
        for p in raw.iterdir():
            if p.is_file():archive.write(p,platform+'/'+p.name)
    for name in ('cleanup-delta.json','mac-sync.json','linux-sync.json','source-identity.json'):
        archive.write(base/name,'input-identity/'+name)
    for p in repo.glob('.scratch/*cpu-final-f5*owning*.py'):archive.write(p,'drivers/'+p.name)
receipt={'scope':'F5 Mac ARM64 / Linux x86_64 retained-math and mature edge owning delta',
    'results':results,'equivalent_cleanup':json.loads((base/'cleanup-delta.json').read_text()),
    'reuse':'Windows/Mac pre-cleanup math/delivery proofs retained: only two uncalled helpers and equivalent private default exits changed.',
    'p1':'NOT_RUN; no math, ABI, data layout or qualified rules changed',
    'bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()}
(out/'portable-owning-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({'platform_results':results,'bundle_bytes':bundle.stat().st_size})
