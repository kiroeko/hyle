from pathlib import Path
import hashlib, json, subprocess, xml.etree.ElementTree as ET, zipfile

root = Path.cwd()
base = root / '.scratch/inference-gaps/g04-g05'
candidate = '9c9ab88bba3fca5dcc981a2a42100b08af1a45ae'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = json.loads((base/'ce21-source-2/result.json').read_text())
draft = json.loads((base/'ce21-source-1/result.json').read_text())
device = json.loads((base/'ce21-device-risks-1/result.json').read_text())
assert source['state'] == draft['state'] == device['state'] == 'TERMINAL_PASS'
assert device['product_commit'] == candidate
assert all(s['exit_code'] == 0 for r in (source, draft, device) for s in r['stages'])
assert device['source_result_sha256'] == sha(base/'ce21-source-2/result.json')
for name, count in [('ce21-source-1/tests.xml',17), ('ce21-source-2/tests.xml',17),
                    ('ce21-device-risks-1/memcheck.xml',10), ('ce21-device-risks-1/racecheck.xml',10),
                    ('ce21-device-risks-1/legacy-racecheck.xml',2)]:
    x = ET.parse(base/name).getroot()
    assert int(x.attrib['tests']) == count and x.attrib['failures'] == x.attrib['errors'] == '0'
    assert not any(c.find('skipped') is not None or c.attrib.get('status') == 'notrun' for c in x.findall('.//testcase'))
for row in source['inputs']:
    assert sha(root/row['path']) == row['sha256'], row['path']
for name in ['third_party/flashinfer_cache/patches.json', 'third_party/flashinfer_cache/NOTICE.md', 'cmake/HyleDependencyLock.json']:
    expected = hashlib.sha256(subprocess.check_output(['git','show',candidate+':'+name])).hexdigest()
    # Git's normalized text and the working file can differ in newline encoding.
    committed = subprocess.check_output(['git','show',candidate+':'+name]).replace(b'\r\n',b'\n')
    assert (root/name).read_bytes().replace(b'\r\n',b'\n') == committed
for label in ['memcheck','racecheck','legacy-racecheck']:
    text = (base/'ce21-device-risks-1'/(label+'.log')).read_text()
    assert not any(word in text.lower() for word in ['========= warning:', '========= error:', 'race reported'])
for path, expected in device['artifacts'].items():
    assert subprocess.check_output(['wsl','-e','sha256sum',path], text=True).split()[0] == expected
dest = root/'evidence/correctness/inference-g04-g05-cuda-ce21-register-source-device'
assert not dest.exists()
dest.mkdir()
with zipfile.ZipFile(dest/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for folder in ['ce21-source-1','ce21-source-2','ce21-device-risks-1']:
        for p in sorted((base/folder).rglob('*')):
            if p.is_file(): archive.write(p,p.relative_to(base).as_posix())
    for name in ['launch_ce21_source.py','ce21_source_wsl.py','ce19_cuda_compile.cmake',
                 'ce21_device_risks_wsl.py','ce21-lock-format-proof.json','seal_ce21_source_device.py']:
        archive.write(base/name,'runners/'+name)
    for number in [1,2]:
        with zipfile.ZipFile(base/f'ce21-source-{number}.zip') as package:
            archive.writestr(f'source{number}-manifest.json',package.read('source-manifest.json'))
receipt = dict(kind='G04_G05_CUDA_CE21_REGISTER_CONVERSION_SOURCE_DEVICE',
    verdict='PASS_FINAL_SOURCE17_CACHE_MEM10_RACE10_LEGACY_RACE2_ONLY', product_candidate=candidate,
    draft_six_edit_source=dict(tests=17,stages=draft['stages'],scope='Historical six-edit draft only; not final seven-edit acceptance'),
    source_tests=17, source_stages=source['stages'], source_input_count=len(source['inputs']),
    source_result_raw_sha256=sha(base/'ce21-source-2/result.json'), native_cuda_edges=source['native_cuda_edges'],
    device_stages=device['stages'],artifacts=device['artifacts'],
    measured_stage_seconds=dict(draft=sum(s['elapsed_seconds'] for s in draft['stages']),
        final_source=sum(s['elapsed_seconds'] for s in source['stages']),device=sum(s['elapsed_seconds'] for s in device['stages'])),
    limits=['Actual W1 WSL RTX4070 SM89 only; no other GPU or OS qualification.',
        'Original FP8 register conversion, unused F32 output tile capacity only; seven audited storage/trait/budget edits.',
        'All earlier qualified FAIL, hazards, diagnostic runs and measured costs remain immutable evidence.',
        'Static/shared SDK, three host facets, new numeric/P1 and aggregate G04/G05 remain pending.'],
    raw_zip_sha256=sha(dest/'raw.zip'))
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
p = root/'docs/implementation/module-status.json'
registry = json.loads(p.read_text(encoding='utf-8'))
m = next(x for x in registry['modules'] if x['module']=='compute_provider_flashinfer')
assert m['state']=='AUDITED' and 'candidate' not in m
m['state']='CANDIDATE';m['candidate']=candidate
m['summary']='G04/G05 CE21 CANDIDATE：原FP8寄存器转换与实际live shared容量七处有限修正；最终17数学、十cache mem/race与两普通case race全PASS/零warning。static/shared SDK、三宿主facet、新numeric/P1待验；旧qualified FAIL与累计成本保留。'
p.write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\r\n')
print(json.dumps(dict(path=str(dest),candidate=candidate,seconds=receipt['measured_stage_seconds'])))
