from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET,subprocess
P=Path(__file__).resolve().parents[1];R=P.parent.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(row):
 p=resolve(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

cases=[];receipts=[];gpu_success=0;gpu_fail=0;host_faults=0
def add_cases(arm,path):
 global gpu_success,gpu_fail,host_faults
 for x in ET.parse(path).findall('.//testcase'):
  assert x.find('failure') is None and x.find('skipped') is None
  name=x.get('classname')+'.'+x.get('name');new='ExpertWorkingSet.' in name or x.get('classname') in ('Int4ZeroImport','WeightAssembly','InputSourceBundle')
  props={p.get('name'):p.get('value') for p in x.findall('./properties/property')}
  cases.append(dict(backend=arm,name=name,new=new,properties=props))
  if new and arm!='cpu':
   gpu_success+=int(props.get('actual_graph_submissions',props.get('successful_grouped_submissions','0')))
   gpu_fail+=int(props.get('expected_failed_grouped_completions','0'))
   host_faults+=int(props.get('expected_partial_host_read_failures','0'))
for arm in ('cpu','cuda','vulkan'):
 p=P/arm/'validation/final1/receipt.json';d=read(p)
 assert d['passed'] and not d['failed'] and not d['skipped']
 for key in ('image','xml','link_plan'):check(d[key])
 add_cases(arm,resolve(d['xml']['path']));receipts.append(dict(backend=arm,receipt=ident(p)))
ap=P/'apple/final-validation.json';ad=read(ap);assert ad['tests']==4 and ad['failed']==ad['skipped']==0;check(ad['gtest'])
add_cases('apple',resolve(ad['gtest']['path']))
assert len(cases)==35 and sum(x['new'] for x in cases)==18 and (gpu_success,gpu_fail,host_faults)==(27,6,3)
closure=read(P/'root/current-closure.json');assert len(closure['objects'])==15
for x in closure['objects']:check(x['source']);check(x['object']);check(x['identity'])
hardware=[]
for command in (['powershell','-NoProfile','-Command','Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json -Compress'],['nvidia-smi','--query-gpu=name,driver_version,memory.total,compute_cap','--format=csv,noheader']):
 r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0;hardware.append(dict(command=command,exit=r.returncode,stdout=r.stdout,stderr=r.stderr))
save(P/'root/windows-hardware.json',hardware)
prep=read(P/'package-preparation.json')
sources={str(Path(x['path']).as_posix()) for key in ('minimum_source_inventory','reused_fixture_dependencies') for x in prep[key]}
sources.update(['docs/developer/current-work.md','docs/implementation/model-operators.md','docs/implementation/model-quantizations.json','docs/user/compute.md','docs/user/graph.md'])
assert all((R/s).is_file() for s in sources)
catalog=read(R/'docs/implementation/model-quantizations.json');assert len(catalog['artifacts'])==33 and all(x['provider_coverage']['artifact_execution_verified'] is False for x in catalog['artifacts'])
for arm in ('cuda','vulkan','apple'):assert 'expert_working_set_test.cc' in (R/f'tests/graph_route_{arm}/CMakeLists.txt').read_text()
entries={'source/'+s:R/s for s in sorted(sources)}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.cuh','.cpp','.c','.md','.cu','.d','.metal','.comp','.mm','.ps1'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
archive=R/'docs/evidence/correctness/expert-working-set-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='bounded_expert_resource_bridge_passed_three_native_GPU_backends_and_common_CPU_checks',
 architecture='Existing WeightSlots/catalog/immutable WeightBatch owners plus original Graph InputSource frontier. Shared cold metadata helper; native resource/transfer remains backend-owned. No new executor, model allowlist, cache/eviction policy, implicit converter or full-global-bank allocation.',
 assembly='WeightSlice id names local destination bank, not global expert. All dense plain same-dtype canonical host fragments preflight for exact nonoverlapping complete coverage, scalar alignment, capacity and fragment bound. Bank-only alignment leaves packed source bytes unchanged. Host readiness belongs to caller; successful synchronous staging allows original source buffers to be released.',
 binding='Native span<graph::WeightBinding> resolves all views and immutable owners before one atomic original InputAccess commit. Failed last binding preserves all old bindings and preparation, including first attempted immutable-source attachment. One batch owns W/SF/[WG/IG or Z]/global-local map together. Global ID->local slot uses original checked Gather before original grouped consumer.',
 geometry=dict(global_domain=512,resident_experts=4,NVFP4=dict(N=2048,K=8192,logical_bytes_per_generation=37750816,source_slices=17,banks=5,upload_generations=3),
 CT=dict(N=7,K=256,group=128,scale='F16',logical_bytes_per_generation=5776,source_slices=10,banks=4,upload_generations=3),
 global_bank_not_allocated='NVFP4 W4GiB plus SF512MiB only computed as a size illustration; actual allocations are two bounded four-expert slots. Finite generated source bytes with real role geometry, not publisher payload.'),
 cold_zero_pack='pack_int4_zero_rows explicitly concatenates independently padded I32 low-nibble-first rows into one tight flat EN grid, ignoring poisoned source padding and zeroing output padding. Handles odd rows and strided sources, validates geometry/capacity/canonical aliases before writing, returns flush/close errors. No implicit quantization or zero+1 transform.',
 accounting='WeightUploadReport distinguishes validated logical payload, complete successful host-read prefix, accepted native copy extent including inter-bank padding and successful retirement. Pending/failure/copied_bytes_unknown never proves zero traffic. Failed partial host read witnesses logical8/staged4/submitted0/completed0/unknown=true; second read may have copied2 unknown bytes.',
 regression=dict(new_cases=18,neighbors=17,total_cases=35,failed=0,skipped=0,windows=receipts,apple=ident(ap),cases=cases,
 new_GPU_successful_Graph_submissions=gpu_success,new_expected_GPU_failed_completions=gpu_fail,expected_partial_host_read_failures=host_faults,
 CPU_scope='9 new shared checks:3 cold zero-pack,3 metadata assembly,3 atomic bundles;11 existing Float8/E8 import and InputSource frontier neighbors. No CPU native WeightSlots expert-resource journey claimed.',
 GPU_scope='Each backend3 new cases: NVFP4 geometry, CT odd-row packed original Decode->Reshape->GroupedMatMul, invalid map/global IDs plus truthful partial staging. Vulkan5 original WeightBinding neighbors and Apple1. All fresh wrappers with current WeightSlotOptions. CUDA new cases require/assert actual captured replay.',
 lifetime='Two slots/three generations, nonidentity changing local selections and duplicate global IDs. Same-batch grouped binding; host sources released after staging. Old GraphOutput and independent storage_lease remain exact across newer generations and invocation destruction. Reuse rejected while batch/Invocation owns old selection; invalid IDs fail Completion and do not publish; fresh consumers recover.',
 numerics='Independent literal NVFP4/BF16 boundary oracle and full K CT F32 dot initialized+0, bitwise expected outputs. CT source-padding poison demonstrates naive byte concatenation is not equivalent. No tolerance loosening or expected-failure skips.'),
 fixes=['Failed first immutable bundle attachment now withdraws its new dependency state, preserving ordinary prepared Invocation replay.',
 'Native CUDA/Metal/Vulkan staging reads exact tensor-described subview, accepting legal logical4/storage8 views rather than demanding exact allocation capacity.',
 'Native report observations preserve unknown partial failed staging rather than letting an older completed upload clear it.'],
 first_errors='Actual Windows CPU attempts1/2 retained: third atomic test fixture supplied too many queues, then incorrectly asserted total lane cardinality. Corrected only queue fixture assumptions; final20 pass. Apple actual first CT red used expected decoded negative-zero shortcut instead of full F32 dot starting+0; corrected oracle without changing product math. Earlier strict/planning mistakes and source-found product fixes retained as such, not fabricated runtime failures.',
 closure=dict(windows=ident(P/'root/current-closure.json'),apple=ident(ap),reuse='Targeted product/wrapper owners only, existing dependency caches and original CUDA/SPIRV/Metal operator programs reused. No SDK/shader/NVCC/full build. Broad package8 and3delivery packages remain open.'),
 reviews=[ident(P/'graph-adapters/atomic-source-review.json'),ident(P/'apple-final-shared-source-review.json'),ident(P/'capability-residual-review.json')],
 limitations=['Selected finite resource composition, no whole-artifact/publisher payload, full model, Linux, quality, latency or throughput claim.',
 'Generic byte bridge now exists; exact MLX mixed MoE/head-bank, PB_WO and other codec/source-role consumers remain distinct work. No automatic equivalence between padded/encoded layouts.',
 'No native GPU device fault/cancellation injection in this batch. Intentional partial host-read and index/domain Completion failures are actual tested faults; accounting is not measured DRAM/bus traffic.',
 'Optional dynamic per128 DSA scale+BF16 KPE storage remains a separate unsupported format, not proven required for already-selected raw TRTLLM artifact path. Capability package8 and delivery3 not closed.'],
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],current_sources=len(sources),new_cases=18,neighbors=17)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
