from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parents[1];R=P.parent.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ident(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p))
def check(row):
 p=Path(row['path']);assert p.is_file() and p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],str(p)
records={}
for summary in sorted((P/'common/checks').glob('*/summary.json')):
 for row in read(summary)['identities']:
  rec=read(row['path']);records[rec['replaces']['path'].lower()]=Path(row['path'])
paths=list(records.values())
paths += [P/'cuda/checks/attempt3/cuda-weights-identity.json',P/'cuda/checks/attempt1/cuda-memory-identity.json',
 P/'graph-adapters/checks/attempt1/cuda-weight-binding-identity.json',P/'graph-adapters/checks/attempt1/vulkan-weight-binding-identity.json',
 P/'cuda/checks/wrapper2/test-identity.json',P/'vulkan/checks/test2/expert-test-identity.json']
paths += [Path(x['path']) for x in read(P/'vulkan/checks/objects-ready.json')['final_identities']]
deps={};owned=[]
for path in paths:
 d=read(path);check(d['source']);check(d['object']);owned.append(dict(identity=ident(path),source=d['source'],object=d['object']))
 for row in d['dependencies']:
  p=Path(row['path'])
  if p.is_relative_to(R):check(row);deps[str(p).lower()]=row
links=[]
for arm,link in [('cpu','link4'),('cuda','link1'),('vulkan','link1')]:
 p=P/arm/'checks'/link/'link-plan.json';d=read(p)
 for row in d['inputs']:check(row)
 links.append(dict(backend=arm,plan=ident(p),input_count=len(d['inputs'])))
report=dict(status='current_targeted_objects_and_repo_dependencies_match',objects=owned,repository_dependencies_checked=len(deps),links=links,
 scope='Fresh targeted Windows owners and their current repository dependencies; native Apple closure independently frozen in apple/final-validation.json. Reused external SDK source is not requalified.')
(P/'root/current-closure.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(dict(objects=len(owned),repository_dependencies_checked=len(deps),links=len(links)))
