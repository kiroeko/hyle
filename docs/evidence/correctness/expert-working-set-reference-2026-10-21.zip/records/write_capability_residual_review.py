from pathlib import Path
import hashlib,json

S=Path(__file__).resolve().parent
R=S.parents[2];A=S.parent

def identity(path):
    b=path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def ref(relative,needle):
    p=R/relative
    lines=p.read_text(encoding='utf-8').splitlines()
    return dict(path=relative,line=next(i+1 for i,l in enumerate(lines) if needle in l),text=needle,identity=identity(p))

catalog=json.loads((R/'docs/implementation/model-quantizations.json').read_text(encoding='utf-8'))
assert len(catalog['artifacts'])==33
assert all(r['provider_coverage']['artifact_execution_verified'] is False for r in catalog['artifacts'])
F='.scratch/architecture-refactor-2026-10-18/'
refs=dict(
 cache=ref('include/hyle/compute/low_precision.h','class CacheStorage final'),
 row=ref('include/hyle/compute/low_precision.h','enum class RowCacheFormat'),
 mla=ref('include/hyle/compute/batch_layout.h','struct MlaBatchCapacity final'),
 mla_guard=ref('src/compute_batch/batch_layout.cc','if(!c.cache_storage.format().is_plain())'),
 native_mla=ref('src/compute_provider_flashinfer/native_mla.cu','p.ckv_stride_page=p.kpe_stride_page=s.page_size*(512+Rope);'),
 dsa_quant=ref(F+'compact-mla-e4-2026-10-21/runtime/sglang/dsa_quant_k_cache.py','y_s = tl.max(tl.abs(y)) / FP8_MAX'),
 mla_producer=ref(F+'compact-mla-e4-2026-10-21/producer-review.json','CKV512_4F32Scales_KPE64BF16'),
 mlx_infer=ref('src/compute_ops/weight_decode.cc','if (affine && scale.data_type() != dtype) dtype = DataType::kFloat32;'),
 mlx_apple=ref('src/compute_route_apple/apple_tensor.cc','const auto compute_type = affine ? mx::float32 : type;'),
 mlx_upstream=ref('.scratch/validation/cpu-coverage-c3-origins/mlx-ops.cpp','dtype = promote_types(x.dtype(), dtype);'),
 mlx_upstream_grouped=ref('.scratch/validation/cpu-coverage-c3-origins/mlx-ops.cpp','out_type = promote_types(x.dtype(), out_type);'),
 mlx_math=ref('third_party/mlx_cpu_quant/mlx_cpu_quant.h','if (affine) {'),
 float_decode=ref('src/compute_route_apple/apple_mature_float.cc','if (operation.custom_as<model_ops::Float8WeightDecode>())'),
 f32_carrier=ref('src/compute_ops/low_precision.cc','const auto id = weight ? (f32 ? kFloat8WeightFloat32Block128'),
 import_e8=ref('include/hyle/compute/weight_import.h','HYLE_COMPUTE_API Status import_float8_block128_weight('),
 upload=ref('src/compute_route_vulkan/vulkan_weights.cc','fragment.source.description() != found->description'),
 cpu_moe=ref('tests/compute_models/mlx_moe_fixture.h','class Bank') if 'class Bank' in (R/'tests/compute_models/mlx_moe_fixture.h').read_text(encoding='utf-8') else ref('tests/compute_models/mlx_moe_fixture.h','struct Bank final'),
)
evidence=[
 'docs/evidence/research/fixed-role-binding-2026-10-21.json',
 'docs/evidence/research/compact-mla-e4-contract-2026-10-21.json',
 'docs/evidence/correctness/compact-mla-e4-reference-2026-10-21.json',
 'docs/evidence/correctness/e8m0-block128-import-reference-2026-10-21.json',
 'docs/evidence/correctness/mlx-moe-typed-inputs-2026-10-20.json',
 'docs/evidence/correctness/mxfp4-weight-only-reference-2026-10-21.json',
 'docs/evidence/correctness/ct-bf16-block128-reference-2026-10-21.json',
 'docs/evidence/correctness/ct-packed-grouped-space-2026-10-21.json',
]
doc=dict(
 observed_on='2026-10-21',status='Bounded current-source review; no product bug newly demonstrated',
 scope='Capability8 residual triage after compact-MLA and Inferact selected-reference packages. No product/docs/catalog edits, builds, GPU, network requests or model numeric payload reads.',
 summary=dict(
    mandatory_next='Independent expert source spans -> bounded resident working-set -> global/local IDs and ordinary typed inputs. This is delivery3 and is a real resource-consumer gap.',
    arithmetic='No newly proven absent scalar/MatMul/quantization arithmetic was found in the inspected PB_WO or mixed-MLX role families.',
    unsupported_format='Scaled-DSA CKV512 +4F32 token/group scales +BF16 KPE64 (656B; NoPE528B) is genuinely unrepresented by current MLA schema/readers. It is a conditional runtime-storage variant, not proven necessary for the already chosen raw TRTLLM route.',
    bounded_role_next='Run exact ordinary PB_WO/MLX head and mixed-dtype role consumers before inventing a new op or precision policy; only an actual admission/math/resource failure should promote one to a product fix.'),
 finite_residual_list=[
  dict(id='expert_resource_binding',classification='confirmed required resource/consumer gap; delivery3, not new quantization math',
    targets=[16,17,18,19,20,21,22,23,24,25,26,30,32],
    facts=['Stored experts are independent original tensors; current grouped math admits an E-prefixed dense bank, not a collection of independent source leases.',
      'Existing WeightSlots stages catalog-selected whole TensorDesc values at aligned offsets and preserves true transfer/owner generations; it does not assemble separate Q/SF/bias/global role sets into one bounded grouped carrier or remap model-global IDs.',
      'Blind full-bank assembly can exceed real device binding limits: the recorded CT512-expert example is4GiB Q plus512MiB SF; GLMFlash has37152 triples in129 banks. A tiny-E operator test cannot discharge this resource path.'],
    existing_reuse=[refs['upload']],
    next='Use current catalog, WeightSlots and Graph InputSource ownership to produce one bounded local resident bank from selected immutable per-expert role spans; explicit global->local mapping, original packing (including independently padded CT Z), byte/transfer accounting and two-slot old-result/failure retirement. Keep route/provider/model policy outside the common executor.',
    no_new_policy='Selection and residency are consumer/resource decisions; do not change arithmetic descriptors into a model allowlist or create a second executor.'),
  dict(id='precise_role_consumers',classification='finite integration/contract qualification remains; no confirmed new operation gap',
    subitems=[
      dict(role='ModelOpt Kimi FP8_PB_WO attention',catalog=[20],
        actual='g_proj E4[12288,7168], F32SF[96,1,56,1]; o_proj E4[7168,12288], F32SF[56,1,96,1]. These are per128x128 weight-only scales, not scalar SA/SW or activation FP8 QDQ.',
        executable_path='Singleton removal SF[NB,1,KB,1]->[NB,KB] is metadata-only with identical physical order. Ordinary E4->F32 Cast, reshape W[NB,128,KB,128], broadcast SF, multiply and explicit declared output Cast can express weight decode; existing Float8WeightDecode over canonical E4/F32block128 can express the same carrier-level materialization, followed by ordinary MatMul without activation QDQ.',
        distinction='Thus4D scale metadata does not demonstrate a missing MatMul/scalar op. Existing encoded carrier needs a real cold code+F32scale assembly from separate source buffers; import_float8_block128_weight is specifically E8->F32 and must not reinterpret these already-F32 scales as U8.',
        remaining='Exact original ModelOpt0.45 decode/output boundary should be bound to the cached/source-specific reference. Ordinary decode materializes NK floating W; a bounded closed weight-only decode->MatMul region would remove that spatial cost if compressed residency is required, but absent fusion is not absence of an executable mathematical path.',
        next='One small non-square ordinary stored-PB_WO consumer, actual4D singleton SF and BF16 operand boundary, no A quantization; prove its source tree and ownership. Then add bounded contraction only if that path currently creates an unacceptable persistent/hot NK bank.',
        refs=[refs['float_decode'],refs['f32_carrier'],refs['import_e8']]),
      dict(role='MLX F16 SF/bias with BF16 network and GLM head banks',catalog=[31,32],
        actual='Fixed complete metadata: Flash37338 triples allF16SF/bias (37152 independent experts+186ordinary); GLM156 rank3 attention head banks have BF16 SF/bias.',
        executable_path='Current MlxQuantized accepts F16/BF16/F32 A and same-typed floating SF/bias; different A/SF floating types promote result toF32. Pinned MLX ops.cpp actually promotes affine quantized_matmul and gather_qmm input/scale types and casts all affine inputs to that result type. Existing Apple F32-affine lowering already follows the explicit F32 decoded equation.',
        distinction='The F16 header alongside a BF16 network is not by itself an unsupported dtype. Do not add a low-precision policy that silently rounds F16 scales toBF16. F32 decoded affine multiplication/addition and output promotion exist.',
        remaining='Exact model-level casts before/after these projections, head order/strides, and original GLM forward have not been executed. Existing mixed MoE complete consumer usesF32A/BF16metadata and CPU/CUDA/Vulkan, so it does not certify Flash BF16A/F16metadata or Apple complete MoE.',
        next='Bind one BF16A/F16SF exact affine5/4/6 ordinary consumer through the same promotion/restoration path, then reuse complete MoE fixture for Apple. For rank3 head banks use explicit per-head IDs only after fixed forward verifies head/transpose order; no new grouped-math enum is justified by rank3 alone.',
        refs=[refs['mlx_infer'],refs['mlx_upstream'],refs['mlx_upstream_grouped'],refs['mlx_apple'],refs['mlx_math'],refs['cpu_moe']]),
      dict(role='Quark attention FP8 side branches',catalog=[16,23,30],
        actual='These artifacts are mixed. Quark MXFP4 reference does not certify their distinct per-channel axes or block128 FP8 weight/activation roles.',
        executable_path='Current ordinary typed Cast/Binary/Broadcast/MatMul leaves can express explicit vector/grid scale QDQ or weight-only decode. A same-named FP8 primitive need not have the same arithmetic.',
        remaining='Exact per-role source axes and pointwise rounding/reference consumer remain unqualified, especially Kimi channelaxis0/1. No current product rejection or wrong result has been observed by this review.',
        next='One source-bound ordinary side-role chain per distinct actual mathematical contract, not another model x dtype x backend matrix. Preserve Quark SF axes and explicit dtype boundaries; report any actual primitive admission/math failure before changing descriptors.')]),
  dict(id='scaled_DSA_cache_variant',classification='confirmed unsupported physical representation, conditional target-runtime requirement',
    targets=[28,29],
    fixed_runtime='SGLang82ac83a8d0ab50ea7c9fe8e5b5934c2fa5a224bf',
    actual='512 E4 CKV bytes +4F32 per-token/per128 scales +optional64 BF16 KPE=656B; NoPE528B. Source uses F32 groupabsmax/448 with no epsilon, quantized codes and original RoPE-copy bytes.',
    rejection='MlaBatchCapacity currently promises one scalar CacheStorage interpretation for all CKV/KPE/V. Native MLA uses one DataType row stride512+Rope. CacheStorage has only plain16/Q8/scalarE4. Existing RowCache.float8_block64_tail64 is a separate448+64 logical codec/584B physical row, not512/group128 DSA.',
    is_required_now='The fixed target29 README selects raw TRTLLM layout, now supported. Other runtime/backend choices using scaledDSA cannot bind their physical cache to that reader. Decide the intended backend/storage policy explicitly; do not infer that artifact28/29 weights themselves require656/528 or reopen uniform E4 as broken.',
    next='If this real runtime policy is included, introduce one explicit original row/cache encoding with CKVcode offset, four F32 scales and BF16 KPE tail, a matching encoder and reader that reuse the same cache/page/Invocation ownership. Source zero/nonfinite/tiny behavior must be fixed as an explicit finite reference before encoding; never substitute uniform fixedscale or rowcache448. No new executor or change to plain/rawE4 geometry.',
    refs=[refs['mla'],refs['cache'],refs['row'],refs['mla_guard'],refs['native_mla'],refs['dsa_quant'],refs['mla_producer']])],
 do_not_reopen_as_missing_functions=[
    'CT BF16 block128/group128 already has actual four-backend ordinary consumers; older fixed-role notes saying still needs qualification are historical.',
    'Grouped FP8 power2 and dense E8M0 block128 cold importer exist. Imported grouped role consumption remains an integration witness, not an absent grouped power2 or E8 codec.',
    'Inferact reader W4A16 and numeric GRS E8 cold conversion are now executed separately. Unknown original exporter/OAS does not invalidate the explicit finite reference or justify another guessed quantizer.',
    'No packed NF4 MatMul/tensorcore/wholeFFN fused kernel is not no-NF4 functionality: current artifact decode plus ordinary MatMul exists. Bounded space/performance may motivate a future cold packed candidate, kept separate from mathematical feature completeness.',
    'Ordinary E4 paired-pending producer and recent GPU state/retirement journeys are unexecuted regression scope, not a source-proven absent cache encoder/queue executor.',
    'All33 artifact_execution_verified=false, unread numeric payload/calibration scalars, Linux closure, quality and full-model throughput are evidence limits. Do not count each as an additional missing operation.'
 ],
 ordered_next_steps=[
    'Complete the expert working-set resource consumer already assigned to delivery3; it unlocks actual separate expert sources without enormous bank residency.',
    'Close the finite precise-role consumers above, beginning with PB_WO or mixedMLX promotion/head geometry. Use existing ordinary graph first and only fix observed failed admission/math/space.',
    'Keep scaledDSA656/528 explicitly unsupported. Implement it only as the chosen additional physical runtime policy, or retain the already functional raw TRTLLM policy with this precise limitation; do not conflate storage alternatives with missing model arithmetic.'
 ],
 source_identities=[identity(R/'docs/developer/current-work.md'),identity(R/'docs/implementation/model-quantizations.json'),
    identity(A/'fixed-role-binding-2026-10-21/kimi/review.json'),
    identity(A/'fixed-role-binding-2026-10-21/mlx/assessment.json')],
 evidence_identities=[identity(R/p) for p in evidence],
 work_counts=dict(canonical_edits=0,builds=0,GPU=0,model_numeric_payload_bytes=0),
 limitation='This is a bounded source/metadata/current-evidence review. No new numerical red/green, backend execution or whole-model completeness is asserted.'
)
out=S/'capability-residual-review.json';out.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8')
print(json.dumps(identity(out)))
