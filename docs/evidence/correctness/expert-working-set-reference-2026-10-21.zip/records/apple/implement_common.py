from pathlib import Path
R=Path.cwd();p=R/'include/hyle/graph/detail/input_source.h';s=p.read_text();s=s.replace('#include <utility>','#include <span>\n#include <utility>');s=s.replace('struct InputAccess final {','''struct InputSourceBinding final {
  ValueId value{};
  compute::ConstTensorView tensor{};
  InputSource source{};
};

struct InputAccess final {''');s=s.replace('      compute::ConstTensorView, InputSource) noexcept;','''      compute::ConstTensorView, InputSource) noexcept;
  // Validate all incoming bindings against their final ranges and immutable
  // owners before changing any binding. Failure preserves the old bindings
  // and preparation; successful commit cannot allocate or fail.
  HYLE_GRAPH_API static Status bind(Invocation &,
      std::span<const InputSourceBinding>) noexcept;''');p.write_text(s,newline='\n')
p=R/'src/graph/input_sources.h';s=p.read_text();s=s.replace('struct InputSourcesState;','''struct InputSourcesState;
struct InputSourceBinding;

// The original readonly binding checks and commit, shared by ordinary single
// binds and the atomic immutable-input bundle. Candidate ranges only override
// incoming inputs during alias validation; no physical Plan is duplicated.
HYLE_GRAPH_API Status validate_read_binding(InvocationState &, ValueId,
    compute::ConstTensorView, std::span<const InputSourceBinding> = {}) noexcept;
HYLE_GRAPH_API void commit_read_binding(InvocationState &, ValueId,
    compute::ConstTensorView) noexcept;''');p.write_text(s,newline='\n')
p=R/'src/graph/input_sources.cc';s=p.read_text();a=s.index('Status InputAccess::bind(');b=s.index('\nvoid note_borrowed_input_source',a)
s=s[:a]+'''Status InputAccess::bind(Invocation &invocation, ValueId value,
    compute::ConstTensorView tensor, InputSource source) noexcept {
  const InputSourceBinding binding{value, tensor, std::move(source)};
  return bind(invocation, std::span<const InputSourceBinding>(&binding, 1));
}
Status InputAccess::bind(Invocation &invocation,
    std::span<const InputSourceBinding> incoming) noexcept {
  auto *state = InvocationAccess::state(invocation);
  HYLE_RETURN_IF_ERROR(resource_control_ready(state));
  if (incoming.empty() || incoming.size() > state->plan->input_ids.size())
    return Status::InvalidArgument("immutable input bundle has an invalid size");
  for (std::size_t i = 0; i < incoming.size(); ++i) {
    const auto &item = incoming[i];
    HYLE_RETURN_IF_ERROR(check_binding_replacement(*state, item.value));
    if (!item.source.valid())
      return Status::InvalidArgument("immutable input source is empty");
    if (std::find(state->plan->input_ids.begin(), state->plan->input_ids.end(), item.value) ==
        state->plan->input_ids.end())
      return Status::InvalidArgument("immutable input source requires a graph input");
    for (std::size_t j = 0; j < i; ++j)
      if (incoming[j].value == item.value)
        return Status::InvalidArgument("immutable input bundle repeats a graph input");
  }
  HYLE_RETURN_IF_ERROR(require_owner(*state));
  HYLE_RETURN_IF_ERROR(prepare_submission_lifetime(*state, state->allocator));
  auto &sources = *state->input_sources.get();
  struct Previous final { Binding *binding = nullptr; InputSource source{}; };
  Vector<Previous> previous{mem::StdAllocator<Previous>(state->allocator)};
  try { previous.resize(incoming.size()); }
  catch (...) { return Status::ResourceExhausted("allocating immutable input bundle rollback owners"); }
  // All metadata allocation precedes the temporary immutable markers. Keep
  // every previous owner until all original recording invalidations finish.
  for (std::size_t i = 0; i < incoming.size(); ++i) {
    auto *binding = find_binding(sources, incoming[i].value);
    HYLE_FATAL_ASSERT(binding != nullptr);
    previous[i] = {binding, std::move(binding->source)};
    binding->source = incoming[i].source;
  }
  for (const auto &item : incoming) {
    auto status = validate_read_binding(*state, item.value, item.tensor, incoming);
    if (!status.ok()) {
      for (auto &old : previous) old.binding->source = std::move(old.source);
      return status;
    }
  }
  // No fallible operation remains. The original raw hook clears each marker
  // while invalidating old native imports; reinstall its already-retained
  // incoming source immediately, without allocation or producer observation.
  for (std::size_t i = 0; i < incoming.size(); ++i) {
    const auto &item = incoming[i];
    commit_read_binding(*state, item.value, item.tensor);
    previous[i].binding->source = item.source;
  }
  invalidate(sources);
  return Status::Ok();
}
''' +s[b:];p.write_text(s,newline='\n')
p=R/'src/graph/executable.cc';s=p.read_text();s=s.replace('#include "hyle/graph/detail/region_access.h"','#include "hyle/graph/detail/region_access.h"\n#include "hyle/graph/detail/input_source.h"',1);s=s.replace('                               ByteRange candidate) noexcept {','                               ByteRange candidate,\n                               std::span<const detail::InputSourceBinding> incoming = {}) noexcept {',1)
s=s.replace('''    if (other == ordinal || other_instance == detail::kNoWorkspaceRequest ||
        invocation.bound[other_instance] == 0) {''','''    const auto replacement = std::find_if(incoming.begin(), incoming.end(),
        [&](const auto &item) { return item.value == other_value; });
    if (other == ordinal || other_instance == detail::kNoWorkspaceRequest ||
        (replacement == incoming.end() && invocation.bound[other_instance] == 0)) {''',1);s=s.replace('    const ByteRange existing = bound_range(invocation, other);','''    const ByteRange existing = replacement == incoming.end()
        ? bound_range(invocation, other) : byte_range(replacement->tensor.storage());''',1)
s=s.replace('  return check_dynamic(true);\n}', '''  HYLE_RETURN_IF_ERROR(check_dynamic(true));
  // The old allocation index cannot enumerate a newly moved input range.
  // Scan only this bounded cold bundle using the same permission/alias gate.
  for (const auto &item : incoming) HYLE_RETURN_IF_ERROR(check(item.value));
  return Status::Ok();
}''',1)
a=s.index('Status Invocation::bind(ValueId value,\n                        compute::ConstTensorView tensor) noexcept {');b=s.index('\nStatus Invocation::bind(ValueId value, compute::TensorView tensor)',a)
old=s[a:b];body=old[old.index('  HYLE_RETURN_IF_ERROR'):old.rindex('\n}')];split=body.index('  invalidate_unproven_bindings(*state_);');validate=body[:split];commit=body[split:];validate=validate.replace('state_', '(&state)').replace('validate_external_alias(*(&state), ordinal, byte_range(tensor.storage()))','validate_external_alias(state, ordinal, byte_range(tensor.storage()), incoming)');validate+='  return Status::Ok();\n';commit=commit.replace('  return Status::Ok();\n','').replace('state_', '(&state)')
# Keep direct readable source form, without changing the original checks.
validate=validate.replace('*(&state)','state').replace('(&state)->','state.');commit=commit.replace('*(&state)','state').replace('(&state)->','state.')
new='''Status detail::validate_read_binding(InvocationState &state, ValueId value,
    compute::ConstTensorView tensor, std::span<const InputSourceBinding> incoming) noexcept {
'''+validate+'''}
void detail::commit_read_binding(InvocationState &state, ValueId value,
    compute::ConstTensorView tensor) noexcept {
  const auto ordinal = value.ordinal();
  const auto instance = state.plan->external_instances[ordinal];
'''+commit+'''}
Status Invocation::bind(ValueId value,
                        compute::ConstTensorView tensor) noexcept {
  HYLE_RETURN_IF_ERROR(detail::resource_control_ready(state_));
  HYLE_RETURN_IF_ERROR(detail::validate_read_binding(*state_, value, tensor));
  detail::commit_read_binding(*state_, value, tensor);
  return Status::Ok();
}
'''
s=s[:a]+new+s[b:];p.write_text(s,newline='\n')
print('common span and original readonly validate/commit split written')
