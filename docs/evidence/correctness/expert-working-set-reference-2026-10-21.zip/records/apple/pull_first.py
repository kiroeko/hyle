from pathlib import Path
import runpy,json,base64
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'expert-working-set-2026-10-21/apple'
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
code="""from pathlib import Path
import json,base64
r=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/expert-working-set-2026-10-21/apple');fs=[*r.glob('results/*'),r/'plan.json',r/'source-manifest.json',r/'hardware.json'];print(json.dumps([dict(path=p.relative_to(r).as_posix(),data=base64.b64encode(p.read_bytes()).decode())for p in fs if p.is_file()]))"""
result=ssh(code,{})
for row in result:
 p=S/'mac/attempt1'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(row['data']))
p=R/'src/graph/executable.cc';s=p.read_text();a=s.index('Status detail::validate_read_binding(');b=s.index('void detail::commit_read_binding',a);s=s[:a]+s[a:b].replace('!owns(plan, value)','!::hyle::graph::owns(plan, value)')+s[b:];p.write_text(s,newline='\n')
print('first strict error preserved; qualified original PlanState ownership helper')
