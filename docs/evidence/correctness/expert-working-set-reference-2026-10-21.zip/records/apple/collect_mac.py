from pathlib import Path
import runpy,json,base64,sys
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'expert-working-set-2026-10-21/apple';ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
code="""from pathlib import Path
import json,base64,sys
p=json.load(sys.stdin);r=Path(p['remote']);fs=[*r.glob('results/*'),r/'plan.json',r/'source-manifest.json',r/'hardware.json'];fs += [r/x for x in p.get('extra',[])];print(json.dumps([dict(path=p.relative_to(r).as_posix(),data=base64.b64encode(p.read_bytes()).decode())for p in fs if p.is_file()]))"""
remote=json.loads((S/'mac/plan.json').read_text())['remote'];dest=sys.argv[1]if len(sys.argv)>1 else'remote'
for row in ssh(code,dict(remote=remote,extra=['tests/compute_models/expert_working_set_fixture.h','tests/graph_route_apple/expert_working_set_test.cc','src/compute/weight_import.cc'])):
 p=S/'mac'/dest/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(row['data']))
print('collected '+dest)
