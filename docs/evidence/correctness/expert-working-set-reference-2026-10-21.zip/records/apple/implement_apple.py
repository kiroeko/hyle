from pathlib import Path
import hashlib,json
R=Path.cwd();S=R/'.scratch/architecture-refactor-2026-10-18/expert-working-set-2026-10-21/apple';(S/'before').mkdir(parents=True,exist_ok=True)
paths=['include/hyle/compute/apple_weights.h','src/compute_route_apple/apple_weights.mm','src/compute_route_apple/apple_memory.mm','include/hyle/graph/detail/input_source.h','src/graph/input_sources.h','src/graph/input_sources.cc','src/graph/executable.cc']
rows=[]
for s in paths:
 p=R/s;b=p.read_bytes();q=S/'before'/s;q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert q.read_bytes()==b,s
 else:q.write_bytes(b)
 rows.append(dict(path=s,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(S/'before.json').write_text(json.dumps(rows,indent=2)+'\n')
p=R/paths[0];s=p.read_text();s=s.replace('#include "hyle/compute/tensor.h"','#include "hyle/compute/tensor.h"\n#include "hyle/compute/weight_assembly.h"');s=s.replace('  ResourceBudget resource_budget{};','  ResourceBudget resource_budget{};\n  std::size_t max_fragments = 64;');s=s.replace('  HYLE_COMPUTE_ROUTE_APPLE_API Status wait() const noexcept;','  HYLE_COMPUTE_ROUTE_APPLE_API Status wait() const noexcept;\n  HYLE_COMPUTE_ROUTE_APPLE_API Result<WeightUploadReport> report() const noexcept;');s=s.replace('  HYLE_COMPUTE_ROUTE_APPLE_API Status close() noexcept;','  // Complete dense banks assembled from bounded, canonical host fragments.\n  HYLE_COMPUTE_ROUTE_APPLE_API Result<WeightBatch>\n  upload_slices(std::size_t slot, std::span<const compute::WeightSlice> slices) noexcept;\n  HYLE_COMPUTE_ROUTE_APPLE_API Result<WeightUploadReport> report(std::size_t slot) const noexcept;\n  HYLE_COMPUTE_ROUTE_APPLE_API Status close() noexcept;');p.write_text(s,newline='\n')
p=R/paths[2];s=p.read_text();s=s.replace('mem::MemoryProperty::kHostAccessible |','mem::MemoryProperty::kHostAccessible |\n                     mem::MemoryProperty::kHostAddressIdentity |',1);p.write_text(s,newline='\n')
p=R/paths[1];s=p.read_text();s=s.replace('#include <mutex>','#include <mutex>\n#include <limits>');s=s.replace('#include "completion_internal.h"','#include "completion_internal.h"\n#include "../compute/weight_assembly.h"');s=s.replace('  WeightCompletion *abandoned = nullptr;','  WeightCompletion *abandoned = nullptr;\n  WeightUploadReport report{};');s=s.replace('  std::size_t count = 0, capacity = 0;','  std::size_t count = 0, capacity = 0, max_fragments = 0;');s=s.replace('    progress.done = true;','    progress.done = true;\n    if (status.ok()) {\n      progress.report.completed_bytes = progress.report.submitted_bytes;\n      progress.report.copied_bytes_unknown = false;\n    } else if (progress.report.submitted_bytes != 0) {\n      progress.report.copied_bytes_unknown = true;\n    }',1)
s=s.replace('  if (!context.valid() || !memory.valid() || catalog.empty() || capacity == 0 ||','  if (options.max_fragments > static_cast<std::size_t>(PTRDIFF_MAX) / sizeof(WeightSlice))\n    return std::unexpected(Status::OutOfRange("Apple weight fragment capacity exceeds addressable range"));\n  if (!context.valid() || !memory.valid() || catalog.empty() || capacity == 0 ||\n      options.max_fragments == 0 ||');s=s.replace('      state->capacity = capacity;','      state->capacity = capacity;\n      state->max_fragments = options.max_fragments;')
a=s.index('  @autoreleasepool {',s.index('Result<WeightBatch> WeightSlots::upload('));b=s.index('  return WeightBatch(owner);',a)
body=s[a:b];body=body.replace('return std::unexpected(Status::ResourceExhausted("Metal weight command allocation failed"));','return Status::ResourceExhausted("Metal weight command allocation failed");').replace('state.count = selection.size();','state.count = banks;').replace('      state.progress->terminal = Status::Ok();','      state.progress->terminal = Status::Ok();\n      state.progress->report.submitted_bytes = transfer_bytes;\n      state.progress->report.copied_bytes_unknown = transfer_bytes != 0;').replace('detail::finish_weight','finish_weight').replace('detail::metal_status','metal_status')
helper='''Status submit_weight(WeightState &state, std::size_t used, std::size_t banks) noexcept {
  id<MTLBuffer> source = (__bridge id<MTLBuffer>)state.backing->staging.native_handle();
  id<MTLBuffer> destination = (__bridge id<MTLBuffer>)state.backing->destination.native_handle();
  const auto transfer_bytes = (used + 3) & ~std::size_t{3};
'''+body+'''  return Status::Ok();
}

Status writable_weight(WeightState &state) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto previous, poll_weight(state));
  if (previous == CompletionPoll::kPending || state.backing.use_count() != 1)
    return Status::FailedPrecondition("Apple weight transfer is still in flight");
  if (state.generation == UINT64_MAX)
    return Status::OutOfRange("Apple weight event generation exhausted");
  state.count = 0;
  std::lock_guard lock(state.progress->mutex);
  state.progress->report = {};
  return Status::Ok();
}

Status stage_weight(WeightState &state, ConstTensorView source,
                    std::byte *destination, std::size_t bytes) noexcept {
  const auto status = source.storage().read({destination, bytes});
  std::lock_guard lock(state.progress->mutex);
  if (status.ok()) state.progress->report.staged_bytes += bytes;
  else state.progress->report.copied_bytes_unknown = true;
  return status;
}

Status check_weight_aliases(const WeightState &state,
    std::span<const WeightSlice> slices) noexcept {
  id<MTLBuffer> staging = (__bridge id<MTLBuffer>)state.backing->staging.native_handle();
  id<MTLBuffer> destination = (__bridge id<MTLBuffer>)state.backing->destination.native_handle();
  const auto first = reinterpret_cast<std::uintptr_t>(staging.contents);
  const auto second = reinterpret_cast<std::uintptr_t>(destination.contents);
  if (!staging.contents || !destination.contents ||
      staging.length > UINTPTR_MAX - first || destination.length > UINTPTR_MAX - second)
    return Status::OutOfRange("Apple weight backing host address overflows");
  for (const auto &slice : slices) {
    HYLE_ASSIGN_OR_RETURN(auto bytes, slice.source.description().required_bytes());
    HYLE_ASSIGN_OR_RETURN(auto range, slice.source.storage().subview(0, bytes));
    HYLE_ASSIGN_OR_RETURN(auto mapping, range.map_host());
    const auto address = reinterpret_cast<std::uintptr_t>(mapping.bytes().data());
    Status status;
    if (!mapping.bytes().data() || bytes > UINTPTR_MAX - address)
      status = Status::OutOfRange("Apple weight source host address overflows");
    else if ((address < first + staging.length && first < address + bytes) ||
             (address < second + destination.length && second < address + bytes))
      status = Status::InvalidArgument("Apple weight source aliases private staging/backing");
    status.Update(mapping.close());
    if (!status.ok()) return status;
  }
  return Status::Ok();
}

'''
s=s[:a]+'  HYLE_RETURN_IF_ERROR(detail::submit_weight(state, used, selection.size()));\n'+s[b:]
s=s.replace('} // namespace detail\n\nResult<detail::WeightBinding>',helper+'} // namespace detail\n\nResult<detail::WeightBinding>',1)
a=s.index('  HYLE_ASSIGN_OR_RETURN(auto previous, detail::poll_weight(state));',s.index('Result<WeightBatch> WeightSlots::upload('));b=s.index('  const auto capacity = state.capacity;',a)
s=s[:a]+'''  HYLE_RETURN_IF_ERROR(detail::writable_weight(state));
  if (selection.size() > state.selected.size())
    return std::unexpected(Status::InvalidArgument("too many selected Apple weights"));
'''+s[b:]
s=s.replace('  id<MTLBuffer> destination = (__bridge id<MTLBuffer>)state.backing->destination.native_handle();\n  auto *pointer', '  {\n    std::lock_guard lock(state.progress->mutex);\n    for (std::size_t i = 0; i < selection.size(); ++i)\n      state.progress->report.logical_bytes += state.selected[i].bytes;\n  }\n  auto *pointer',1)
s=s.replace('HYLE_RETURN_IF_ERROR(selection[i].source.storage().read({pointer + entry.offset, entry.bytes}));','HYLE_RETURN_IF_ERROR(detail::stage_weight(state, selection[i].source, pointer + entry.offset, entry.bytes));')
insert='''Result<WeightUploadReport> WeightBatch::report() const noexcept {
  if (!state_) return std::unexpected(Status::FailedPrecondition("empty Apple weight batch"));
  std::lock_guard lock(state_->progress->mutex);
  return state_->progress->report;
}
Result<WeightUploadReport> WeightSlots::report(std::size_t slot) const noexcept {
  if (slot >= 2 || !states_[slot])
    return std::unexpected(Status::FailedPrecondition("invalid Apple weight slot"));
  std::lock_guard lock(states_[slot]->progress->mutex);
  return states_[slot]->progress->report;
}
Result<WeightBatch> WeightSlots::upload_slices(
    std::size_t slot, std::span<const compute::WeightSlice> slices) noexcept {
  if (closed_ || slot >= 2 || !states_[slot])
    return std::unexpected(Status::FailedPrecondition("invalid or closed Apple weight slot"));
  auto &owner = states_[slot];
  if (owner.use_count() != 1)
    return std::unexpected(Status::FailedPrecondition("Apple weight selection is still retained"));
  auto &state = *owner;
  HYLE_RETURN_IF_ERROR(detail::writable_weight(state));
  if (slices.size() > state.max_fragments)
    return std::unexpected(Status::ResourceExhausted("too many Apple weight fragments"));
  HYLE_ASSIGN_OR_RETURN(auto size, cd::prepare_weight_slices(
      std::span<const WeightSpec>(state.catalog), slices,
      std::span<detail::SelectedWeight>(state.selected), state.capacity, 16));
  {
    std::lock_guard lock(state.progress->mutex);
    state.progress->report.logical_bytes = size.logical_bytes;
  }
  HYLE_RETURN_IF_ERROR(detail::check_weight_aliases(state, slices));
  id<MTLBuffer> staging = (__bridge id<MTLBuffer>)state.backing->staging.native_handle();
  auto *pointer = static_cast<std::byte *>(staging.contents);
  const auto transfer_bytes = (size.physical_bytes + 3) & ~std::size_t{3};
  std::fill(pointer, pointer + transfer_bytes, std::byte{});
  const auto banks = std::span<const detail::SelectedWeight>(state.selected.data(), size.banks);
  for (const auto &slice : slices) {
    HYLE_ASSIGN_OR_RETURN(auto offset, cd::weight_slice_offset(banks, slice.id));
    HYLE_ASSIGN_OR_RETURN(auto bytes, slice.source.description().required_bytes());
    HYLE_RETURN_IF_ERROR(detail::stage_weight(state, slice.source,
        pointer + offset + slice.destination_offset, bytes));
  }
  HYLE_RETURN_IF_ERROR(detail::submit_weight(state, size.physical_bytes, size.banks));
  return WeightBatch(owner);
}

'''
s=s.replace('Status WeightSlots::close() noexcept {',insert+'Status WeightSlots::close() noexcept {');p.write_text(s,newline='\n')
print(json.dumps({'before':len(rows),'changed_apple':3}))
