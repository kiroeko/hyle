from pathlib import Path
import runpy,json,base64,hashlib,difflib
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'expert-working-set-2026-10-21/apple'
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh']
code="""from pathlib import Path
import json,base64
r=Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/expert-working-set-2026-10-21/apple');fs=[*r.glob('results/*'),r/'plan.json',r/'source-manifest.json',r/'hardware.json'];print(json.dumps([dict(path=p.relative_to(r).as_posix(),data=base64.b64encode(p.read_bytes()).decode())for p in fs if p.is_file()]))"""
for row in ssh(code,{}):
 p=S/'mac/remote'/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(row['data']))
rows=[]
for before in json.loads((S/'before.json').read_text()):
 p=R/before['path'];b=p.read_bytes();after=dict(path=before['path'],bytes=len(b),sha256=hashlib.sha256(b).hexdigest());rows.append(dict(before=before,after=after));q=S/'after'/before['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
old=(S/'before'/before['path']).read_text();new=p.read_text()
# One complete concise unified diff for actual review.
diff=''.join(''.join(difflib.unified_diff((S/'before'/x['before']['path']).read_text().splitlines(True),(R/x['before']['path']).read_text().splitlines(True),fromfile='before/'+x['before']['path'],tofile=x['before']['path']))for x in rows)
(S/'product.diff').write_text(diff,newline='\n');(S/'source-freeze.json').write_text(json.dumps(dict(sources=rows,compiles='mac/remote/results/compile-summary.json',gpu_run=False,SDK_build=False),indent=2)+'\n')
print(json.dumps(dict(source_freeze_sha256=hashlib.sha256((S/'source-freeze.json').read_bytes()).hexdigest(),compiles=[dict(source=x['source']['path'],exit=x['exit'])for x in json.loads((S/'mac/remote/results/compile-summary.json').read_text())['compiles']])))
