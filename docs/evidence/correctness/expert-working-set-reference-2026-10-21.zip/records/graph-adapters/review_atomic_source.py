"""Record a bounded source-only review; no compiler, GPU or product mutation."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
ROOT = S.parents[3]

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

paths = ['include/hyle/graph/detail/input_source.h', 'src/graph/input_sources.cc',
    'src/graph/executable.cc', 'src/graph/input_sources.h', 'src/graph/resources.cc',
    'tests/graph/input_source_frontier_test.cc']
sources = [identity(ROOT/p) for p in paths]
doc = dict(
    status='One source-confirmed first-owner rollback blocker reported to root; other bounded transaction/alias/lifetime paths have no additional blocker found.',
    scope='InputSource span atomic binding, shared validation/commit extraction and last three InputSourceBundle regressions; source-only, no build/runtime by reviewer.',
    sources=sources,
    blocker=dict(
        severity='Correctness: failed immutable-source bind can poison an already prepared ordinary Invocation',
        input='Invocation prepared using only ordinary borrowed inputs, with no prior InputSourcesState. First bundle has valid graph input IDs and valid immutable sources, but its last tensor has the wrong description.',
        path=['InputAccess::bind calls require_owner before tensor/range validation, attaching a new empty InputSourcesState.',
              'On last validation failure it restores each Binding::source, but keeps the newly attached InputSourcesState whose active.valid is false.',
              'Original replay_prepared remains true. The next submission now enters the source-aware path, and prepared_for/input_results_ready rejects unprepared input sources.'],
        evidence=[dict(path='src/graph/input_sources.cc', anchors=['require_owner', 'InputAccess::bind(Invocation &, std::span<const InputSourceBinding>)', 'prepared_for', 'input_results_ready']),
                  dict(path='src/graph/submission.cc', anchor='Invocation::submit(std::span<const QueueBinding>) routes state.input_sources to source-aware submission')],
        minimal_fix='Remember whether an input source owner existed before this attempt. A scope rollback removes only a newly attached owner on every failure, and is released only after successful commit. Declare rollback before temporary Previous records so retained rollback sources unwind first. Existing prepared state and existing owners must remain untouched.',
        regression='Reuse the existing Fixture/graph but bind all three input/output tensors with ordinary Invocation::bind, prepare once, attempt a wrong-last-tensor bundle, then inspect empty source report and submit the original prepared invocation successfully.',
        previous_scope='The old single-source path could also create an empty owner before a rejected first bind; the new public atomic preservation guarantee makes this a necessary finite correction, without a new transaction framework.'),
    confirmed=[
        dict(subject='No successful-prefix commit after all preflight succeeds',
             evidence='Every item is fully validate_read_binding-checked before the commit loop. The extracted commit body has no allocation, provider preparation, Status return, or tensor factory. It preserves the original bind invalidation/readable/bound/alias-index/note-borrowed sequence.'),
        dict(subject='Existing immutable owners survive old native imports/recordings',
             evidence='All previous Binding::source values move into Previous records before any incoming marker is installed. They remain alive while commit_read_binding invokes old recording/source invalidation; restored/new InputSourcesState bindings then retain incoming owners.'),
        dict(subject='Alias validation uses the complete final incoming ranges',
             evidence='validate_external_alias::check chooses incoming tensor range instead of old bound range for replaced values. Existing allocation index enumeration remains, and a final bounded incoming scan covers newly moved ranges including a future published input. Same original immutable/input-output/planned-alias gates apply.'),
        dict(subject='Old-result, running, failure, preparation and configuration gates remain',
             evidence='resource_control_ready and check_binding_replacement run before source markers, and again in shared read validation; they preserve the original result/observation/in-flight/failed/configuration restrictions.'),
        dict(subject='Single-bind complexity remains bounded',
             evidence='Single InputAccess bind wraps one InputSourceBinding and delegates to the span. Previous uses four inline SmallVector entries. Additional duplicate/overlay checks are constant for one input; no new full physical plan walk or per-submit transaction is added. Ordinary read bind now shares validation and original commit body.'),
        dict(subject='Public ABI and producer semantics',
             evidence='InputSourceBinding is a new same-build adapter record; no PlanState/InvocationState/provider vtable or producer identity layout was expanded. InputSource acquire/copy/release and source callbacks are unchanged.')
    ],
    test_review=[
        dict(name='InputSourceBundle.InvalidLastTensorPreservesOriginalPreparedBindings',
             proves='Existing source-aware prepared invocation rejects invalid final tensor without invalidating old replay/source report or observing the replacement producer; old output math is checked.',
             limitation='It starts with existing source owners, so does not cover first-owner creation rollback.'),
        dict(name='InputSourceBundle.SameProducerReplacesBothInputsAndDeduplicatesReadiness',
             proves='Both banks update together and old binding owners release; one actual producer identity yields one source/host-wait frontier and independent affine output math.'),
        dict(name='InputSourceBundle.FuturePublishedInputAliasAndDuplicatesRejectAsOneTransaction',
             proves='The next published-input range is checked even before it enters the old index; duplicate graph input IDs reject as a whole while old preparation and output remain valid.')
    ],
    limitations=['No runtime execution by reviewer. Existing test runs/first-owner reproduction and final correction are root-owned.',
                 'No broad alias-index, lease system, executor, numerical/provider or concurrency redesign reviewed or proposed.',
                 'Producer callback reentrant mutation of a thread-compatible Invocation is outside the existing API contract; no new concurrency claim.'])
(S/'atomic-source-review.json').write_text(json.dumps(doc, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print(json.dumps(identity(S/'atomic-source-review.json')))
