#include "hyle/graph/apple.h"

#include "hyle/graph/detail/input_source.h"
#include "hyle/util/ref_counted.h"
#include "../compute_route_apple/apple_weights_internal.h"

namespace hyle::graph::apple {
namespace {
namespace ad = compute::apple::detail;
namespace gd = graph::detail;
struct WeightSource final : util::RefCounted<WeightSource> {
  explicit WeightSource(ad::WeightBinding value) noexcept : binding(std::move(value)) {}
  void destroy() noexcept {
    const auto allocator = binding.allocator;
    allocator.destroy(this);
  }
  ad::WeightBinding binding;
};
const gd::InputSourceVTable weight_source{
    [](void *state) noexcept { static_cast<WeightSource *>(state)->incref(); },
    [](void *state) noexcept { static_cast<WeightSource *>(state)->decref(); },
    [](void *, const compute::detail::QueueRef *) noexcept
        -> Result<gd::InputDependencyRoute> {
      // The original Metal upload queue has no Compute QueueSequence import.
      // Keep its full terminal status on the original host-ready frontier.
      return gd::InputDependencyRoute::kHostWait;
    },
    [](void *state) noexcept {
      return ad::WeightAccess::poll(static_cast<WeightSource *>(state)->binding.owner.get());
    },
    [](void *state) noexcept {
      return ad::WeightAccess::wait(static_cast<WeightSource *>(state)->binding.owner.get());
    },
    [](void *, compute::detail::QueueSequence &) noexcept {
      return compute::detail::EnqueueResult::rejected(
          Status::Unimplemented("Apple weight source has no shared Queue import"));
    },
    [](void *) noexcept { return Status::Ok(); }};
} // namespace

Status bind(Invocation &invocation, ValueId value,
    const compute::apple::WeightBatch &batch, std::uint64_t id) noexcept {
  HYLE_ASSIGN_OR_RETURN(auto binding, ad::WeightAccess::binding(batch, id));
  const auto tensor = binding.tensor;
  const auto allocator = binding.allocator;
  auto *owner = allocator.construct<WeightSource>(std::move(binding));
  if (!owner) return Status::ResourceExhausted("Apple immutable input owner");
  auto source = gd::InputSource::acquire(owner, &weight_source, owner->binding.owner.get());
  owner->decref();
  if (!source) return std::move(source).error();
  return gd::InputAccess::bind(invocation, value, tensor, std::move(*source));
}
} // namespace hyle::graph::apple
