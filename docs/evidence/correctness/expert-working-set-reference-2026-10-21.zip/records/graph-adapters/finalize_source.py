"""Bounded adapter design/closure report; does not build, link, or execute."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent

def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(name, data):
    (S/name).write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

freeze = json.loads((S/'source-freeze.json').read_text())
for row in freeze['sources']+freeze['common_contract']:
    assert identity(row['path']) == row, ('source changed', row['path'])
save('design.json', dict(
    API='graph::WeightBinding{ValueId value; uint64_t id=0}; graph::{cuda,vulkan,apple}::bind(Invocation&,span<constgraph::WeightBinding>,constNativeWeightBatch&) noexcept.',
    transaction='Resolve every ID, tensor view and source owner into cold adapter metadata. Only after all succeed, call InputAccess::bind once with the entire span. No loop of individually committing input binds.',
    single='Existing single-bank bind remains and uses the original producer dependency semantics.',
    CUDA='Original WeightState pointer is the retained source state and stable producer identity; original queue route/poll/wait/enqueue/consumer_retired callbacks remain byte-for-byte unchanged.',
    Vulkan='Each WeightSource retains its own original detail::WeightBinding, including exported mem::Buffer storage, exact TensorView and shared immutable WeightState. The stable identity remains binding.owner.get(), while each retained adapter can have its own address.',
    Apple='Each WeightSource retains original native WeightBinding and allocator; all bank sources use original shared WeightState identity and host-ready dependency frontier.',
    allocation='SmallVector of InputSourceBinding with four inline entries. CUDA uses the existing zero-state system metadata allocator; Apple/Vulkan use the original allocator obtained from the first binding. Cold allocation uses try_resize and returns ResourceExhausted. Per-bank WeightSource construction uses original allocator.construct and checked acquire.',
    errors='Empty bundle returns InvalidArgument. Unknown ID, export, allocation or source-acquire failure destroys all prior temporary retained sources before any Invocation mutation. Duplicate values and final range/alias/mutability admission remain in the common atomic span implementation.',
    common='InputAccess span owns validation of all final ranges and atomic commit, preserving original bindings/preparation on rejection. No shadow plan, execution source, hidden upload wait or executor is introduced.',
    ownership='All bank sources derive from one const WeightBatch argument. The adapter does not rewrite global/local IDs or infer which graph ports an engine intended to include; engines pass their complete desired W/SF/remap bundle.',
    closure='Existing native weight/resource state layouts are not changed by this task. Only the new InputSourceBinding/span declaration is consumed. Header additions are new declarations/record only; actual adapter consumers refresh.',
    unverified='No graph integration runtime, rejection injection, GPU, throughput or model execution by this agent. Actual Apple adapter compilation is delegated to the Mac owner.'))
save('planning-error.json', dict(
    phase='Before compiler launch, bounded lookup of old CUDA same-source owner',
    command='python .scratch/architecture-refactor-2026-10-18/expert-working-set-2026-10-21/graph-adapters/build_adapters.py',
    result='AssertionError: (cuda, 0)',
    meaning='The actual retained CUDA 185-input image has no old graph_route_cuda/weight_binding object or graph-route archive. This was an inventory assumption in the build helper, not a source or compiler failure.',
    correction='Retain the same actual base; derive the new CUDA owner command from the real graph_route_cuda/cuda_context sibling recipe and current CMake target source/include declaration. No SDK, library, provider or source fallback.',
    compiler_invocations=0, links=0, GPU=0,
    limitation='The failure output was in the tool transcript; this compact receipt records the exact assertion and phase, not a new rerun.'))
summary = json.loads((S/'checks/attempt1/summary.json').read_text())
assert summary['passed'] and summary['CXX_successes'] == 2
save('source-review.json', dict(
    result='No source-only blocker found within the seven owned adapter/header files.',
    preserved=[
        'All three batch adapters call common InputAccess::bind exactly once after their resolution loops, never on a successful prefix.',
        'Original producer vtables, stable identity and queue/host dependency contracts remain unchanged.',
        'Vulkan does not reduce WeightBinding to TensorView: every source retains its exported storage Buffer through the original WeightSource.',
        'All early errors release temporary retained owners by RAII. Original single-bind paths preserve their native owner/status semantics.',
        'SmallVector resize multiplication overflow is rejected by its existing grow_to guard; element default/move/destruction are nonthrowing InputSourceBinding operations.',
        'Only one native batch is accepted per call; per-bank allocations do not alter its upload generation or permit native slot reuse.'
    ],
    limits=['Common InputAccess transaction internals are supplied by the Apple/common owner and are not modified here.',
            'CUDA metadata beyond four entries uses system allocator because the opaque batch exposes no allocator accessor; no new private ABI was introduced solely for this cold adapter.',
            'No GPU/integration execution or Apple compiler run by this agent.'],
    source_freeze=identity(S/'source-freeze.json')))
save('final-validation.json', dict(
    status='Source frozen; two Windows adapter owners compiled successfully, with Apple source handed to the actual Mac owner.',
    CXX_attempts=2, CXX_successes=2, CXX_failures=0, planning_failures_before_compiler=1,
    NVCC=0, SDK=0, links=0, GPU=0,
    source_freeze=identity(S/'source-freeze.json'), design=identity(S/'design.json'),
    source_review=identity(S/'source-review.json'), planning_error=identity(S/'planning-error.json'),
    plan=identity(S/'checks/attempt1/plan.json'),
    owner_identities=[identity(S/'checks/attempt1'/(backend+'-weight-binding-identity.json')) for backend in ['cuda','vulkan']],
    objects_ready=identity(S/'checks/attempt1/objects-ready.json'),
    summary=identity(S/'checks/attempt1/summary.json')))
print(json.dumps(identity(S/'final-validation.json')))
