"""Freeze the three adapters; build only the actual Windows CUDA/Vulkan owners."""
from pathlib import Path
import argparse
import concurrent.futures
import difflib
import importlib.util
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('atomic_weights_build', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
OWNED = ['include/hyle/graph/weight_binding.h',
    *['include/hyle/graph/'+backend+'.h' for backend in ['cuda','vulkan','apple']],
    *['src/graph_route_'+backend+'/weight_binding.cc' for backend in ['cuda','vulkan','apple']]]

def same(row):
    actual = b.identity(row['path'])
    return actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--attempt', default='attempt1')
    args = parser.parse_args()
    out = S/'checks'/args.attempt
    out.mkdir(parents=True, exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    source_rows = [b.identity(ROOT/path) for path in OWNED]
    common = [b.identity(ROOT/'include/hyle/graph/detail/input_source.h')]
    diffs = []
    for path in OWNED:
        source = ROOT/path
        target = S/'after'/path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
        before = S/'before'/path
        diffs.extend(difflib.unified_diff(
            before.read_text(encoding='utf-8').splitlines(True) if before.exists() else [],
            source.read_text(encoding='utf-8').splitlines(True),
            fromfile='before/'+path, tofile='after/'+path))
    (S/'implementation.diff').write_text(''.join(diffs), encoding='utf-8')
    c.save(S/'source-freeze.json', dict(sources=source_rows, common_contract=common,
        scope='Seven graph adapter/header files only; original producer vtables and native resource code are unchanged.'))
    plans = {backend: c.read(A/('mxfp4-weight-only-reference/'+backend+'/checks/link1/link-plan.json'))
        for backend in ['cuda','vulkan']}
    metadata = h.metadata(plans)
    owners = []
    for backend in plans:
        source = ROOT/('src/graph_route_'+backend+'/weight_binding.cc')
        found = [(old, metadata[c.key(old['path'])]) for old in plans[backend]['inputs']
            if c.key(old['path']) in metadata and c.key(metadata[c.key(old['path'])]['source_path']) == c.key(source)]
        if not found and backend == 'cuda':
            # This actual closure never linked the old CUDA weight adapter.
            # Derive the new owner command from its real sibling in the same
            # current CMake target; preserve that distinction in the receipt.
            recipe_path = A/'fp8-shared-prologue/checks/host1/graph_route_cuda--cuda_context-identity.json'
            recipe = c.read(recipe_path)
            recipe['recipe'] = str(recipe_path)
            old = None
            derivation = dict(kind='new actual owner, same-target command',
                target_cmake=b.identity(ROOT/'src/graph_route_cuda/CMakeLists.txt'),
                sibling_recipe=b.identity(recipe_path),
                note='CMake target graph_route_cuda lists cuda_context.cc and weight_binding.cc with the same private compute_route_cuda include. Only source/output/dependency destinations change.')
        else:
            assert len(found) == 1, (backend, len(found))
            old, recipe = found[0]
            assert same(old), ('Previous actual object changed', old)
            derivation = dict(kind='refresh actual same-source owner')
        tag = backend+'-weight-binding'
        command = b.host_command(recipe['command'], source, tag, out)
        command = [arg for arg in command if arg not in ['/W3','/W0']]
        if '/W4' not in command: command.append('/W4')
        if '/WX' not in command: command.append('/WX')
        owners.append(dict(tag=tag, source=b.identity(source), replaces=old,
            recipe=b.identity(recipe['recipe']), derivation=derivation, original_command=recipe['command'],
            command=command, object=str(out/(tag+'.obj'))))
    frozen = source_rows+common
    c.save(out/'plan.json', dict(owners=owners, frozen=frozen,
        bases={backend:b.identity(A/('mxfp4-weight-only-reference/'+backend+'/checks/link1/link-plan.json'))
               for backend in plans},
        scope='Two Windows host CXX only; Apple adapter is source-frozen for separate actual Mac compilation. No SDK/NVCC/link/GPU.'))
    if not args.build:
        print(S/'source-freeze.json', flush=True)
        return
    env, runtime = b.environment(owners[0]['command'], [], out)
    c.save(out/'runtime.json', dict(PATH=env['PATH'], runtime=runtime))
    def build(row):
        tag = row['tag']
        job = out/'commands'/tag
        job.mkdir(parents=True, exist_ok=False)
        (job/'source-before-compile.txt').write_bytes(Path(row['source']['path']).read_bytes())
        result = c.execute(tag+'-compile', row['command'], env, job)
        dep = out/(tag+'-deps.json')
        data = c.read(dep)['Data']
        paths = list(dict.fromkeys([data['Source'], *data['Includes']]))
        record = dict(row, result=result, object=b.identity(row['object']),
            source_dependencies=b.identity(dep), dependencies=[b.identity(p) for p in paths])
        assert all(same(x) for x in frozen), 'Source changed during compilation'
        c.save(out/(tag+'-identity.json'), record)
        print('COMPILED', tag, flush=True)
        return record
    success, errors = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(build, row) for row in owners]
        for future in futures:
            try: success.append(future.result())
            except Exception as error: errors.append(str(error))
    c.save(out/'objects-ready.json', dict(owners=success, errors=errors))
    c.save(out/'summary.json', dict(passed=not errors, CXX_attempts=2,
        CXX_successes=len(success), SDK=0, NVCC=0, links=0, GPU=0,
        Apple='Source only; actual Mac compile delegated to Apple owner.', errors=errors))
    if errors: raise RuntimeError('; '.join(errors))
    print('ATOMIC_WEIGHT_ADAPTERS_READY', out/'objects-ready.json', flush=True)

if __name__ == '__main__':
    main()
