"""Update only the two implementation records for the current working-set bridge."""
from pathlib import Path
import argparse
import copy
import difflib
import hashlib
import json

S = Path(__file__).resolve().parent
ROOT = S.parents[2]
OUT = S/'model-docs-update'
EVIDENCE = 'docs/evidence/correctness/expert-working-set-reference-2026-10-21.json'
LINK = '../evidence/correctness/expert-working-set-reference-2026-10-21.json'

def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(path, doc):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

REPLACEMENTS = {
 'Per-expert artifact tensors/catalog slots still need a resident working-set/bank-binding bridge: the grouped primitive currently accepts dense W[E,N,K/2]/SF[E,N,K/32] spans. Bounded decode removes floating expansion but does not solve whole-bank residency or backend single-buffer limits.':
 'Generic copy-only upload_slices and atomic same-generation bank binding are now available on CUDA/Apple/Vulkan. This Quark codec-specific selected-expert consumer journey, residency policy and native single-buffer limits remain unverified; no whole-bank residency is required by the generic bridge.',
 'Per-expert catalog/resident-working-set bridge to bind separate original banks under backend buffer limits without dense whole-bank residency':
 'Exact Quark per-expert import and bounded working-set consumer journey under native buffer limits; generic slice assembly and atomic bank binding are implemented, not a complete artifact importer',
 'Per-expert catalog/resident-working-set bridge for896 independent expert banks without whole-bank dense residency':
 'Exact896-expert Quark import and bounded working-set consumer journey; generic slice assembly and atomic bank binding are implemented, without proving this codec journey or whole artifact',
 'Per-expert catalog/resident-working-set bridge for separate original MXFP4 banks under backend buffer limits':
 'Exact mixed Quark MXFP4/FP8 bank import and bounded working-set consumer journey; generic slice assembly and atomic bank binding are implemented, not exact-role execution',
 'Delivery3: catalog/working-set bridge for separately stored expert tensors and global/local IDs, bounded uploads, old-result lifetime and actual copy accounting':
 'Delivery3: exact CT local-NVFP4 selected-expert consumer/import journey and working-set policy remain unverified. Generic upload_slices, atomic W/SF/map ownership and copy accounting now exist; the ModelOpt NVFP4 resource witness does not substitute this local-dynamic math.',
 'Delivery3: bind separately stored expert tensors into bounded working sets with immutable generation, global/local IDs, actual upload accounting and old-result/failed-prefix retirement.':
 'Delivery3: the generic sliced upload/atomic same-generation W/SF/map bridge is implemented; the Inferact W4A16 codec-specific expert working-set journey, exact import and residency policy remain unverified.',
 'Independent expert spans and working sets remain resource/import work, not proof that raw U8/F32 is an existing encoded Hyle carrier.':
 'Generic slice assembly/atomic bank binding is now implemented; exact Inferact expert import/working-set execution remains unverified and does not make raw U8/F32 an implicit encoded Hyle carrier.',
 'Bind independent expert WG/IG/SF spans through working sets; retain original F32 block128 PB_WO attention scales rather than scalar SA/SW or dynamic-A quantization.':
 'Generic ModelOpt NVFP4 selected-bank assembly/atomic binding has a synthetic Q24-shaped GPU witness, not this Kimi artifact journey. Exact Kimi expert import and original F32 block128 PB_WO attention scales remain separate from scalar SA/SW or dynamic-A quantization.',
 'Independent expert working-set binding and whole-artifact execution remain unverified.':
 'Generic slice assembly/atomic bank binding is implemented; this BF16 block128 FP8 expert working-set journey and whole-artifact execution remain unverified.',
 'Bounded E3 selected bank; independent expert working sets remain delivery3.':
 'Bounded E3 selected bank; generic slice assembly/atomic binding is implemented, while this BF16 block128 FP8 expert working-set journey remains delivery3.',
 'Independent expert spans and bounded working sets remain delivery3; numeric shape-field values and payloads were not read.':
 'The generic bridge and a synthetic CT asymmetric group128/oddN7 selected-bank journey are implemented. This artifact uses BF16 scales with its own group/packing metadata: exact source-span import, native-buffer residency policy and numeric payload binding remain delivery3.',
 'Five finite synthetic profiles include symmetric group128 and symmetric group512 with F32 scales; publisher binding, working-set bridge and performance remain separate.':
 'Five finite synthetic profiles include symmetric group128 and symmetric group512 with F32 scales. Generic slice assembly/atomic bank binding now also has a separate asymmetric group128/F16-scale/oddN7 GPU witness; exact publisher binding, this role-specific resource journey and performance remain separate.',
 'Bounded packed computation retains original packed banks; no full E*N*K floating-point decode or workspace in the contracted recipe. Original independently addressable expert banks and arbitrarily large native buffers still require the delivery3 resource bridge.':
 'Bounded packed computation retains original banks without full E*N*K floating decode. Generic slice assembly/atomic binding and explicit odd-row zero repacking now support bounded selected banks; exact artifact imports, residency policy and arbitrary native-buffer sizes remain unverified delivery3 work.',
 'Independent expert-span catalog/WeightSlots working-set bridge, native maximum-buffer constraints and global-to-local expert ID mapping (delivery3)':
 'Exact artifact expert-span import, native-buffer-limited residency policy and codec-specific global/local-ID consumer journey (delivery3); generic WeightSlots upload_slices and atomic same-generation bank binding are implemented',
 'No newly missing decode/grouped primitive established. Remaining independent-expert span/catalog binding and working sets are delivery3. Numeric shape-field payload, exact code/scale values and full-role binding are not inferred from a header.':
 'No newly missing decode/grouped primitive established. Generic selected-bank slice assembly/atomic binding and odd-row zero repacking are implemented; exact independent-expert import/residency/full-role binding remain delivery3. Numeric shape-field payload and exact code/scale values are not inferred from a header.',
 'Independent per-expert source spans and working sets remain delivery3; no artifact payload, whole model, Linux closure, hardware integer GEMM, quality or throughput acceptance.':
 'Generic slice assembly/atomic bank binding is implemented. The K512 BF16 W4A8 consumer has not executed through that resource journey; exact source-span import/residency remains delivery3, with no artifact payload, whole model, Linux, hardware integer GEMM, quality or throughput acceptance.',
 'NVFP4 independent expert working sets and full artifact execution remain delivery3.':
 'Generic ModelOpt NVFP4 selected-bank assembly/atomic binding has a synthetic Q24-shaped GPU witness. Exact GA expert working-set import/residency and full artifact execution remain delivery3.',
 '37152 independent expert triples require a bounded129-bank resource/working-set bridge, not blind whole-bank concatenation; Apple complete mixed MoE remains delivery3.':
 'Generic slice assembly/atomic bank binding is implemented. The actual37152-triple/129-bank MLX import, producer-typed consumer and full working-set journey remain unverified; Apple complete mixed MoE remains delivery3. Independently padded packed layouts still require explicit packing.'
}

def update_strings(value, counts):
    if isinstance(value, dict):
        return {key:update_strings(item, counts) for key,item in value.items()}
    if isinstance(value, list):
        return [update_strings(item, counts) for item in value]
    if isinstance(value, str) and value in REPLACEMENTS:
        counts[value] = counts.get(value, 0)+1
        return REPLACEMENTS[value]
    return value

def diff_paths(before, after, path=()):
    if type(before) != type(after): return [path]
    if isinstance(before, dict):
        return [p for key in before.keys()|after.keys() for p in (
            diff_paths(before[key],after[key],path+(key,)) if key in before and key in after else [path+(key,)])]
    if isinstance(before, list):
        if len(before) != len(after): return [path]
        return [p for i,(left,right) in enumerate(zip(before,after)) for p in diff_paths(left,right,path+(i,))]
    return [] if before == after else [path]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    relative = ['docs/implementation/model-operators.md','docs/implementation/model-quantizations.json']
    originals = {}
    for name in relative:
        source = ROOT/name
        before = OUT/'before'/name
        if not before.exists():
            before.parent.mkdir(parents=True, exist_ok=True)
            before.write_bytes(source.read_bytes())
        originals[name] = before.read_bytes()
        assert source.read_bytes() == originals[name], ('Concurrent canonical change',name)
    before = json.loads(originals[relative[1]])
    after = copy.deepcopy(before)
    counts = {}
    indices = [16,17,18,19,20,21,22,23,24,25,26,30,32]
    for index in indices:
        coverage = after['artifacts'][index]['provider_coverage']
        coverage = update_strings(coverage, counts)
        scope = 'Generic copy-only bridge is implemented; this codec/artifact-specific expert working-set consumer journey is not executed by this evidence.'
        if index == 17:
            scope = 'Synthetic ModelOpt NVFP4 group16: global expert domain512, select4 original-format experts, N2048/K8192, immutable W/SF/WG/IG/map generations on three GPUs. Matching role geometry is not publisher payload or complete-artifact execution.'
        if index == 22:
            scope = 'Separate synthetic CT asymmetric group128/F16-SF/oddN7 reference verifies explicit cross-expert zero-row packing plus atomic Q/Z/SF/map upload. This artifact BF16-SF/group/role payload journey remains unverified.'
        if index == 24:
            scope = 'Generic bridge plus a separate CT W4A16 asymmetric oddN7 resource witness. The actual K512 BF16 W4A8 consumer is not executed through the bridge by this evidence.'
        coverage['working_set_bridge_reference'] = dict(observed_on='2026-10-21', evidence=EVIDENCE,
            providers=['CUDA','Apple','Vulkan'], scope=scope, artifact_execution_verified=False)
        after['artifacts'][index]['provider_coverage'] = coverage
    assert all(counts.get(old,0) for old in REPLACEMENTS), [old for old in REPLACEMENTS if not counts.get(old,0)]
    after['followup_reviews'].append(dict(observed_on='2026-10-21', evidence=EVIDENCE,
        artifact_indices=indices,
        scope='Generic host WeightSlice assembly, explicit int4 zero-row packing, upload accounting and same-generation atomic W/SF/map Graph binding are implemented. Three GPU paths run synthetic ModelOpt NVFP4 global512/select4/N2048/K8192 and CT asymmetric group128/F16-SF/oddN7, with bounded uploads, old-result/two-slot/failure lifetimes. Other codecs and MLX exact-role consumers are not signed by this journey; delivery3 and all33 whole-artifact executions remain incomplete.'))
    changes = diff_paths(before, after)
    assert all(path == ('followup_reviews',) or
        (len(path)>2 and path[0]=='artifacts' and path[1] in indices and path[2]=='provider_coverage') for path in changes), changes
    assert len(after['artifacts']) == 33 and all(a['provider_coverage']['artifact_execution_verified'] is False for a in after['artifacts'])
    markdown = originals[relative[0]].decode('utf-8')
    md_newline = '\r\n' if '\r\n' in markdown else '\n'
    replacements = {
      '分立expert到working-set的资源桥及publisher绑定仍未完成。':
      '通用分片上传与同代W／SF／map原子绑定现已沿三GPU原WeightSlots／Invocation接通，见下表；各制品的精确publisher绑定仍未完成。',
      'E8M0 macroblock128冷导入另见下一行；专家工作集仍待。':
      'E8M0 macroblock128冷导入另见下一行；本FP8专家的working-set consumer旅程仍待。',
      '分立expert工作集桥仍归交付3，不套F32-scale code-dot':
      '本BF16 block128专家的working-set旅程仍归交付3，不套F32-scale code-dot',
      'working-set桥仍待；未验publisher binding':
      '通用working-set桥与oddN zero显式重打包已有上列实测；未验publisher binding',
      '512份分立专家tensor的完整工作集接线、任意大bank／整制品':
      '该CT local数学与512份分立专家tensor的完整工作集旅程、任意大bank／整制品',
      '分立expert到有界working-set的资源桥、所选payload／整模型':
      '本Quark分立expert的有界working-set consumer旅程、所选payload／整模型',
      '分立专家working-set桥仍待。不能由CT packing相同套W4A16或GPTQ-v1':
      '本W4A8专家consumer的working-set旅程仍待。不能由CT packing相同套W4A16或GPTQ-v1',
      '37152个专家碎片需129组working-set绑定；':
      '37152个专家碎片到129组working-set的实际MLX consumer旅程未验；'
    }
    for old,new in replacements.items():
        assert markdown.count(old) == 1, old
        markdown = markdown.replace(old,new)
    anchor=('| 模型 / 格式域 | 已核源码事实 | 最小下一步 |\n| --- | --- | --- |\n').replace('\n',md_newline)
    assert markdown.count(anchor) == 1
    row='| 分立expert的有界工作集／同代Graph绑定 | `WeightSlots::upload_slices`在写前校验完整覆盖、dtype、范围及别名，沿原上传和Completion保留不可变bank；`graph::{cuda,apple,vulkan}::bind`一次原子替换同批W／SF／map。三GPU已运行512专家域取4的ModelOpt NVFP4合成角色（N2048/K8192），另核CT asymmetric group128／F16 scale／oddN7显式zero重打包，含多代双槽、旧结果及失败计数。[本批实测]('+LINK+') | 通用资源桥已实现；不签其它codec、MLX exact-role旅程、具体权重payload、完整制品、任意大bank、Linux、质量或吞吐。引擎的选择／驻留／淘汰与精确publisher绑定仍归交付3 |\n'
    markdown=markdown.replace(anchor,anchor+row.replace('\n',md_newline))
    serialized=json.dumps(after,indent=2,ensure_ascii=False)+'\n'
    if b'\r\n' in originals[relative[1]]: serialized=serialized.replace('\n','\r\n')
    outputs = {relative[0]:markdown.encode('utf-8'), relative[1]:serialized.encode('utf-8')}
    diffs=[]
    for name,data in outputs.items():
        path=OUT/'after'/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
        diffs.extend(difflib.unified_diff(originals[name].decode('utf-8').splitlines(True),
            data.decode('utf-8').splitlines(True),fromfile='before/'+name,tofile='after/'+name))
    (OUT/'implementation.diff').write_text(''.join(diffs),encoding='utf-8')
    save(OUT/'validation.json',dict(changed_documents=relative,provider_coverage_indices=indices,
        JSON_changed_paths=[list(path) for path in changes], artifacts=33,
        artifact_execution_verified_true=0, metadata_outside_provider_coverage_unchanged=True,
        earlier_followup_reviews_unchanged=after['followup_reviews'][:-1]==before['followup_reviews'],
        only_new_followup=after['followup_reviews'][-1], applied=args.apply,
        new_reference='Synthetic original-format resource journey; no actual model weight payload.'))
    if args.apply:
        for name,data in outputs.items(): (ROOT/name).write_bytes(data)
        assert all((ROOT/name).read_bytes()==data for name,data in outputs.items())
    save(OUT/'source-freeze.json',dict(applied=args.apply,
        before=[identity(OUT/'before'/name) for name in relative],
        after=[identity((ROOT/name) if args.apply else (OUT/'after'/name)) for name in relative]))
    print(json.dumps(identity(OUT/'validation.json')))

if __name__=='__main__': main()
