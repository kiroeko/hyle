"""Compile only the CUDA weight adapter and canonical-address resource owner."""
from pathlib import Path
import argparse
import concurrent.futures
import difflib
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parents[1]
ROOT = A.parents[1]
spec = importlib.util.spec_from_file_location('weight_assembly_build', A/'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c

def same(row):
    actual = b.identity(row['path'])
    return actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--attempt', default='attempt1')
    parser.add_argument('--only', choices=['cuda-weights', 'cuda-memory'])
    args = parser.parse_args()
    base_path = A/'mxfp4-weight-only-reference/cuda/checks/link1/link-plan.json'
    base = c.read(base_path)
    metadata = h.metadata({'cuda': base})
    out = S/'checks'/args.attempt
    out.mkdir(parents=True, exist_ok=True)
    (out/'tmp').mkdir(exist_ok=True)
    owners = []
    for relative, tag in [
        ('src/compute_route_cuda/weights.cc', 'cuda-weights'),
        ('src/compute_backend_cuda/cuda_memory.cc', 'cuda-memory')]:
        if args.only and tag != args.only:
            continue
        source = ROOT/relative
        matches = [(old, metadata[c.key(old['path'])]) for old in base['inputs']
            if c.key(old['path']) in metadata and
            c.key(metadata[c.key(old['path'])]['source_path']) == c.key(source)]
        assert len(matches) == 1, (relative, len(matches))
        old, recipe = matches[0]
        assert same(old), ('retained actual object identity', old)
        command = b.host_command(recipe['command'], source, tag, out)
        command = [arg for arg in command if arg not in ['/W3', '/W0']]
        if '/W4' not in command: command.append('/W4')
        if '/WX' not in command: command.append('/WX')
        owners.append(dict(tag=tag, source=b.identity(source), replaces=old,
            recipe=b.identity(recipe['recipe']), original_command=recipe['command'],
            command=command, object=str(out/(tag+'.obj'))))
    frozen_paths = [ROOT/p for p in [
        'include/hyle/compute/cuda_weights.h', 'src/compute_route_cuda/weights.cc',
        'src/compute_backend_cuda/cuda_memory.cc', 'include/hyle/compute/weight_assembly.h',
        'src/compute/weight_assembly.h']]
    frozen = [b.identity(path) for path in frozen_paths]
    diffs = []
    for path in frozen_paths:
        relative = path.relative_to(ROOT)
        dest = S/'after'/relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(path.read_bytes())
        before = S/'before'/relative
        if before.is_file():
            diffs.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),
                path.read_text(encoding='utf-8').splitlines(True),
                fromfile='before/'+relative.as_posix(), tofile='after/'+relative.as_posix()))
    (S/'implementation.diff').write_text(''.join(diffs), encoding='utf-8')
    c.save(S/'source-freeze.json', dict(sources=frozen[:3], common_headers=frozen[3:],
        scope='Only cuda_weights.h, weights.cc, cuda_memory.cc edited by this agent. No private cross-TU layout or Graph/test edit.'))
    c.save(out/'plan.json', dict(base=b.identity(base_path), owners=owners, frozen=frozen,
        scope='Exactly two host CXX, strict W4/WX; no SDK/NVCC/link/GPU. Actual previous owner recipes retained.'))
    if not args.build:
        print(out/'plan.json', flush=True)
        return
    env, runtime = b.environment(owners[0]['command'], [], out)
    c.save(out/'runtime.json', dict(PATH=env['PATH'], runtime=runtime))
    def build(row):
        tag = row['tag']
        job = out/'commands'/tag
        job.mkdir(parents=True, exist_ok=False)
        (job/'source-before-compile.txt').write_bytes(Path(row['source']['path']).read_bytes())
        result = c.execute(tag+'-compile', row['command'], env, job)
        dep = out/(tag+'-deps.json')
        data = c.read(dep)['Data']
        paths = list(dict.fromkeys([data['Source'], *data['Includes']]))
        record = dict(row, result=result, object=b.identity(row['object']),
            source_dependencies=b.identity(dep), dependencies=[b.identity(path) for path in paths])
        assert all(same(identity) for identity in frozen), 'Source changed during compilation'
        c.save(out/(tag+'-identity.json'), record)
        print('COMPILED', tag, flush=True)
        return record
    successes, errors = [], []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(build, row) for row in owners]
        for future in futures:
            try: successes.append(future.result())
            except Exception as error: errors.append(str(error))
    c.save(out/'objects-ready.json', dict(owners=successes, errors=errors))
    c.save(out/'summary.json', dict(passed=not errors, CXX_attempts=len(owners),
        CXX_successes=len(successes), SDK=0, NVCC=0, links=0, GPU=0, errors=errors))
    if errors: raise RuntimeError('; '.join(errors))
    print('CUDA_WEIGHT_ASSEMBLY_READY', out/'objects-ready.json', flush=True)

if __name__ == '__main__':
    main()
