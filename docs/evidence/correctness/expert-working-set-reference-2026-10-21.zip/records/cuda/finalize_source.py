"""Save the bounded implementation/review receipts; never run native work."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
ROOT = S.parents[3]

def identity(path):
    path = Path(path)
    payload = path.read_bytes()
    return dict(path=str(path), bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())

def save(name, doc):
    (S/name).write_text(json.dumps(doc, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

save('design.json', dict(
    scope='CUDA weight working-set resource bridge. No graph policy, selected-expert routing, quantization, or executor change.',
    files=['include/hyle/compute/cuda_weights.h', 'src/compute_route_cuda/weights.cc',
           'src/compute_backend_cuda/cuda_memory.cc'],
    private_header='weights_internal.h remains unchanged; WeightState stays opaque and only weights.cc owns the new accounting and max_fragments fields.',
    assembly=dict(metadata='Original catalog/selected SmallVectors sized at cold create. New slices are consumed directly; no per-upload vector growth or payload allocation.',
        validation='Shared prepare_weight_slices validates registered dense plain bank/type, host accessibility and stable host address identity, exact complete nonoverlapping coverage, byte-range and scalar alignment before staging/native acceptance.',
        alignment='New bank starts align to max(16, registered required_alignment); original complete WeightFragment alignment is unchanged.',
        alias='All canonical source mappings are checked/closed before any staging write, rejecting overlap with the whole pinned staging backing and any host-accessible destination backing. Read-only sources may alias each other.',
        native='Original single cudaMemcpyAsync for the exact physical used prefix. Padding is zeroed privately; published selected TensorViews have exact registered bytes. Both full-fragment and slice reads explicitly use source.storage().subview(0,descriptor_bytes), preserving valid larger physical backing.',
        ID='Repeated slice IDs select one bank; original whole-entry API still rejects duplicate IDs. Global/local expert IDs and remap tensors are caller-defined bank contents, with no implicit rewriting.'),
    counters=dict(logical='All validated selected payload bytes, excluding inter-bank padding.',
        staged='Only complete successful source reads; a failed read sets copied_bytes_unknown and publishes no WeightBatch.',
        submitted='Exact physical extent only when cudaMemcpyAsync returns cudaSuccess.',
        completed='Exact submitted extent only after a successful observation/wait on the original upload Completion.',
        failure='Native errors/unknown copied prefixes set copied_bytes_unknown. poll/wait retain the original terminal Status; report returns accounting independently.',
        pending='report polls without waiting; accepted nonempty pending uploads set copied_bytes_unknown=true. Only this report submitted_bytes>0 plus successful retirement clears unknown; failed host reads cannot be cleared by an old completion.'),
    lifetime='Original two fixed backing slots and ContextRef, original batch/source/consumer refcount gate and upload native-prefix backing retention. State never retains itself via its Completion.',
    limits='max_fragments is checked only by upload_slices and not multiplied/allocated; zero is rejected at create. Existing full-entry selection capacity remains catalog.size. Both cold metadata try_resize paths reject sizeof multiplication overflow via SmallVector::grow_to.',
    resource_facts='Only CUDA PinnedHost and Managed add kHostAddressIdentity: map_host returns native_handle+offset with no temporary mapping or pointer translation; Device keeps no host identity bit.',
    verification='Two initial successful strict host CXX plus two weights-only refreshes for explicit pending/unknown accounting and exact logical source read extent. No SDK/NVCC/link/GPU. Numerical, upload, alias and lifetime execution are delegated to root on the real current closure.'))

save('source-review.json', dict(
    status='No source-only blocker found within owned scope; execution remains unverified by this agent.',
    findings=[
        'Shared geometry validates all fragments before padding or source reads, and alias preflight checks all source mappings before any host write.',
        'The preflight does not accept arbitrary host shadows: HostAddressIdentity is required by the common validator. CUDA identity is canonical across wrappers because map_host uses the exact allocation pointer plus offset.',
        'Original nonblocking state-unique, upload-ready, backing-unique and context-match gates precede mutation. New report fields do not relax existing old-result/source retention.',
        'Mutable upload accounting is always guarded by the original state mutex. No Completion callback captures the state beyond synchronous host enqueue; the only retained native lifetime remains WeightBacking.',
        'Each selected binding uses the exact registered description/range. New bank alignment padding is included in native submitted bytes but never exported in binding authority.',
        'Failed host reads do not publish selected_count or a WeightBatch. Reports preserve only complete successful read prefixes; failures set copied_bytes_unknown.',
        'CPU/Apple/Vulkan implementations, common schema/helpers, tests and consumer Graph wiring are outside this agent ownership.'
    ],
    limitations=[
        'No GPU, actual failure injection, alias execution, cross-queue ordering, or two-slot lifetime regression run by this agent.',
        'The existing CUDA composition resource admission remains pinned-host plus device-only, so the conditional host-visible destination alias branch is presently defensive for future admitted backing kinds.',
        'No whole-model artifact execution, expert eviction policy, capture throughput, memory bandwidth, or numerical quality claim.'
    ],
    source_freeze=identity(S/'source-freeze.json'),
    build_summaries=[identity(S/'checks'/attempt/'summary.json') for attempt in ['attempt1','attempt2','attempt3']],
    owner_identities=[identity(S/'checks'/attempt/name) for attempt,name in [('attempt3','cuda-weights-identity.json'),('attempt1','cuda-memory-identity.json')]]))

summaries = [json.loads((S/'checks'/attempt/'summary.json').read_text()) for attempt in ['attempt1','attempt2','attempt3']]
assert all(row['passed'] for row in summaries) and sum(row['CXX_successes'] for row in summaries) == 4
freeze = json.loads((S/'source-freeze.json').read_text())
for row in freeze['sources']+freeze['common_headers']:
    assert identity(row['path']) == row, ('Source freeze changed', row['path'])
save('final-validation.json', dict(
    status='Two affected host owners compile successfully, with two weights-only refreshes for pending/unknown accounting and exact logical read extent; no linking or runtime validation performed by this agent.',
    CXX_attempts=4, CXX_successes=4, CXX_failures=0, NVCC=0, SDK=0, links=0, GPU=0,
    source_freeze=identity(S/'source-freeze.json'), design=identity(S/'design.json'),
    source_review=identity(S/'source-review.json'),
    plans=[identity(S/'checks'/attempt/'plan.json') for attempt in ['attempt1','attempt2','attempt3']],
    objects_ready=[identity(S/'checks'/attempt/'objects-ready.json') for attempt in ['attempt1','attempt2','attempt3']],
    summaries=[identity(S/'checks'/attempt/'summary.json') for attempt in ['attempt1','attempt2','attempt3']]))
print(json.dumps(identity(S/'final-validation.json')))
