from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time
R=Path.cwd();A=R/'.scratch/architecture-refactor-2026-10-18';S=A/'expert-working-set-2026-10-21/vulkan';C=S/'checks/attempt1';C.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(Path(p).read_bytes())
def save(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def ident(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
audit=read(S/'checks/actual-owner-audit.json');env=os.environ.copy()
z=subprocess.run(['cmd','/d','/c',str(A/'bf16-nan-cast-contract/compiler-env.bat')],capture_output=True,text=True,check=True)
for line in z.stdout.splitlines():
 if '=' in line and not line.startswith('='):
  k,v=line.split('=',1);env[k.upper()]=v
(S/'tmp').mkdir(exist_ok=True);env['TMP']=env['TEMP']=str(S/'tmp')
plan=[]
for entry in audit['product_owners']:
 rp=Path(entry['recipe']);old=read(rp);source=Path(old['source']['path']);name=source.stem;command=[];skip=False
 for arg in old['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith(('.cc','.cpp')):continue
  command.append(arg)
 command+=['/W4','/WX','/sourceDependencies',str(C/(name+'-deps.json')),str(source),'/Fo'+str(C/(name+'.obj')),'/Fd'+str(C/(name+'.pdb'))]
 plan.append(dict(name=name,source=ident(source),recipe=ident(rp),replaces=entry['object'],command=command))
save(C/'product-plan.json',dict(audit=ident(S/'checks/actual-owner-audit.json'),items=plan,CXX=3,links=0,GPU=0,shaders=0,SDK=0))
def compile_one(item):
 name=item['name'];t=time.time();z=subprocess.run(item['command'],cwd=R,env=env,capture_output=True,text=True,encoding='utf8',errors='replace')
 save(C/(name+'-command.json'),dict(command=item['command'],cwd=str(R),exit_code=z.returncode,seconds=time.time()-t));(C/(name+'-stdout.txt')).write_text(z.stdout,encoding='utf8');(C/(name+'-stderr.txt')).write_text(z.stderr,encoding='utf8');print(name,z.returncode,flush=True)
 if z.returncode:raise RuntimeError(z.stdout+z.stderr)
 deps=read(C/(name+'-deps.json'))['Data'];data=dict(command=item['command'],source=ident(item['source']['path']),object=ident(C/(name+'.obj')),recipe=item['recipe'],replaces=item['replaces'],dependencies=[ident(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])]);save(C/(name+'-identity.json'),data);return ident(C/(name+'-identity.json'))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(compile_one,plan))
save(C/'objects-ready.json',dict(identities=records,successful_CXX=3,links=0,GPU=0,shaders=0,SDK_build=0))
