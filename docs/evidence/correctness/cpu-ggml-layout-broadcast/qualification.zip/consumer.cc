#include <array>
#include <bit>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <span>
#include <type_traits>
#include <vector>
#include "hyle/compute/cpu.h"
#include "hyle/compute/prepared_operation.h"
#include "hyle/compute/providers/ggml_cpu.h"
#include "hyle/graph/cpu.h"
#include "hyle/simd/dtype.h"
namespace c=hyle::compute;
namespace g=hyle::graph;
namespace m=hyle::mem;
template<class T>T take(hyle::Result<T> r){if(!r){std::fprintf(stderr,"%.*s\n",int(r.error().message().size()),r.error().message().data());std::exit(2);}return std::move(*r);}
void require(hyle::Status s){if(!s.ok()){std::fprintf(stderr,"%.*s\n",int(s.message().size()),s.message().data());std::exit(2);}}
m::Buffer buffer(const c::TensorDesc &d){return take(m::Buffer::create(m::system_resource(),take(d.required_bytes()),64));}
template<class T>constexpr c::DataType dtype(){if constexpr(std::is_same_v<T,float>)return c::DataType::kFloat32;else if constexpr(std::is_same_v<T,hyle::simd::float16_t>)return c::DataType::kFloat16;else return c::DataType::kBFloat16;}
template<class T>T integer(int value){if constexpr(std::is_same_v<T,float>)return float(value);else return T::from_bits(value==1 ? (dtype<T>()==c::DataType::kFloat16 ? 0x3c00 : 0x3f80) : 0x4000);}
template<class T>float decode(T value){if constexpr(std::is_same_v<T,float>)return value;else if constexpr(std::is_same_v<T,hyle::simd::bfloat16_t>)return std::bit_cast<float>(std::uint32_t(value.bits)<<16);else return float((value.bits&1023)+1024)*std::ldexp(1.F,int((value.bits>>10)&31)-25);}
template<class T>void write(m::Buffer &b,const std::vector<T>&v){require(b.view().write(std::as_bytes(std::span(v))));}

// Same ordinary entry, two-node whole region and changed-input replay in every delivery.
template<class Fill,class Verify>void journey(c::Operation op,const std::vector<c::TensorDesc>&ds,const c::TensorDesc &od,Fill fill,Verify verify){
  auto context=take(c::cpu::create_context({.native_threads=3}));auto queue=take(context.create_queue());
  std::vector<m::Buffer> inputs;std::vector<c::ConstTensorView> sources;
  for(const auto &d:ds){inputs.push_back(buffer(d));sources.push_back(take(c::ConstTensorView::create(d,inputs.back().view())));}
  auto output=buffer(od);const auto dest=take(c::TensorView::create(od,output.view()));
  auto prepared=take(c::prepare(context,op,ds,std::span(&od,1),m::system_resource()));
  if(prepared.provider().id!=c::ggml_cpu::kProviderId)std::exit(4);auto invocation=take(prepared.create_invocation());
  auto builder=take(g::GraphBuilder::create());std::vector<g::ValueId> ids;
  for(const auto &d:ds)ids.push_back(take(builder.input(d)));
  auto node=take(builder.add_node(op,ids));auto first=take(builder.result(node));auto y=take(builder.add(c::Copy{},first));require(builder.publish(y));
  auto graph=take(std::move(builder).finish());auto gc=take(g::cpu::create_context({.native_threads=3}));auto compiled=take(g::compile(graph,gc));
  if(compiled.report.step_count()!=1 || compiled.report.step(0)->provider.id!=c::ggml_cpu::kProviderId || compiled.report.step(0)->node_count!=2){std::fprintf(stderr,"graph mismatch op=%d steps=%zu regions=%zu ggml=%d nodes=%zu\n",int(op.kind()),compiled.report.step_count(),compiled.report.region_count(),compiled.report.step(0)->provider.id==c::ggml_cpu::kProviderId,std::size_t(compiled.report.step(0)->node_count));std::exit(5);}
  auto gq=take(gc.create_queue());auto lane=take(compiled.executable.create_invocation());
  for(std::size_t i=0;i<ids.size();++i)require(lane.bind(ids[i],sources[i]));require(lane.bind(y,dest));
  const std::array queues{g::QueueBinding{.lane=g::ExecutionLaneId{0},.queue=&gq}};require(lane.prepare_replay(queues));
  for(int seed:{1,2}){fill(inputs,seed);auto done=take(invocation.submit(queue,sources,std::span(&dest,1)));require(done.wait());verify(output,seed);
    auto whole=take(lane.submit(gq));require(whole.wait());verify(output,seed);}
  require(context.close());require(gc.close());
}
void matrix(){
  const auto d=[](std::array<std::int64_t,4>s){return take(c::TensorDesc::dense(c::DataType::kFloat32,s));};
  const auto a=d({2,1,3,7}),b=d({1,3,7,5}),out=d({2,3,3,5});
  journey(c::Operation(c::MatMul{}),{a,b},out,[](auto &buffers,int seed){std::vector<float> av(42),bv(105);
    for(std::size_t i=0;i<av.size();++i)av[i]=float(i/21+1);for(std::size_t i=0;i<bv.size();++i)bv[i]=float((i/35+1)*seed);write(buffers[0],av);write(buffers[1],bv);},
    [](const auto&buffer,int seed){std::vector<float> actual(90);require(buffer.view().read(std::as_writable_bytes(std::span(actual))));
      for(std::size_t i=0;i<actual.size();++i)if(actual[i]!=float(7*(i/45+1)*((i/15)%3+1)*seed))std::exit(6);});
  journey(c::Operation(c::MatMul{}),{d({2,1,3,0}),d({1,3,0,5})},out,[](auto &,int){},[](const auto&buffer,int){std::vector<float> actual(90);require(buffer.view().read(std::as_writable_bytes(std::span(actual))));for(auto v:actual)if(v!=0.F)std::exit(7);});
}
template<class T>void floats(){
  const auto desc=take(c::TensorDesc::dense(dtype<T>(),std::array<std::int64_t,3>{2,3,7}));
  const auto mask=take(c::TensorDesc::dense(dtype<T>(),std::array<std::int64_t,3>{1,3,1}));
  journey(c::Operation(c::Softmax{.axis=1,.scale=.5F,.mask=c::MaskKind::kAdditive}),{desc,mask},desc,
    [](auto&b,int seed){write(b[0],std::vector<T>(42,integer<T>(seed)));write(b[1],std::vector<T>(3,integer<T>(1)));},
    [](const auto&buffer,int){std::vector<T> actual(42);require(buffer.view().read(std::as_writable_bytes(std::span(actual))));for(auto v:actual)if(std::abs(decode(v)-1.F/3.F)>.002F)std::exit(8);});
  for(bool bshd:{false,true})for(bool causal:{false,true}){
    const std::int64_t nk=causal?4:2;
    const auto d=[=](std::int64_t t,std::int64_t h,std::int64_t depth){return take(c::TensorDesc::dense(dtype<T>(),bshd?std::array<std::int64_t,4>{2,t,h,depth}:std::array<std::int64_t,4>{2,h,t,depth}));};
    const auto q=d(3,4,7),k=d(nk,2,7),v=d(nk,2,5),out=d(3,4,5);
    journey(c::Operation(c::ScaledDotProductAttention{.layout=bshd?c::AttentionLayout::kBatchSequenceHeadDepth:c::AttentionLayout::kBatchHeadSequenceDepth,.scale=.5F,.causal=causal}),{q,k,v},out,
      [=](auto&b,int seed){write(b[0],std::vector<T>(168,integer<T>(1)));write(b[1],std::vector<T>(std::size_t(28*nk),integer<T>(1)));write(b[2],std::vector<T>(std::size_t(20*nk),integer<T>(seed)));},
      [](const auto&buffer,int seed){std::vector<T> actual(120);require(buffer.view().read(std::as_writable_bytes(std::span(actual))));for(auto value:actual)if(std::abs(decode(value)-float(seed))>.01F)std::exit(9);});
  }
}
void storage(){
  for(int raw=int(c::DataType::kBool);raw<=int(c::DataType::kUInt64);++raw){
    const auto type=static_cast<c::DataType>(raw);const auto size=c::data_type_size(type);
    const auto d=take(c::TensorDesc::dense(type,std::array<std::int64_t,2>{2,7})),out=take(c::TensorDesc::dense(type,std::array<std::int64_t,2>{2,14}));
    journey(c::Operation(c::Concat{.axis=1}),{d,d},out,[=](auto&b,int seed){std::vector<std::byte> bytes(14*size);for(std::size_t i=0;i<bytes.size();++i)bytes[i]=std::byte((i*19+seed)&255);require(b[0].view().write(bytes));require(b[1].view().write(bytes));},
      [=](const auto&buffer,int seed){std::vector<std::byte> actual(28*size);require(buffer.view().read(actual));for(std::size_t i=0;i<actual.size();++i){const auto element=i/size;const auto src=(element/14*7+element%7)*size+i%size;if(actual[i]!=std::byte((src*19+seed)&255))std::exit(10);}});
  }
}
int main(){matrix();floats<float>();floats<hyle::simd::float16_t>();floats<hyle::simd::bfloat16_t>();storage();std::puts("ordinary CPU Direct/Graph LB layouts, broadcasts, K0 and 15 scalar carriers replay PASS");}
