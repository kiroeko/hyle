exec(open('.scratch/cpu-lb-windows.py',encoding='utf-8').read().split("if '--delivery-only'")[0])
run('ordinary-build',['cmake','--build',build,'--target','cpu_mature_consumer','--parallel','2'])
run('shared-source-ordinary',[build/'bin/cpu_mature_consumer.exe'])
