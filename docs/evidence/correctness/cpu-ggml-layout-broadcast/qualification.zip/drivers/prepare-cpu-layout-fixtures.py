import hashlib, json, re, subprocess
from pathlib import Path

root = Path.cwd()
old = root / '.scratch/validation/cpu-ggml-transformer-fill'
out = root / '.scratch/validation/cpu-ggml-layout-broadcast'
out.mkdir(parents=True, exist_ok=True)
(out / 'consumer').mkdir(exist_ok=True)
def write_changed(path, data):
    if not path.exists() or path.read_bytes() != data:
        path.write_bytes(data)
for name in ('windows-overlay.cmake', 'linux-overlay.cmake', 'consumer/CMakeLists.txt'):
    text = (old / name).read_text().replace('cpu-ggml-transformer-fill', 'cpu-ggml-layout-broadcast')
    write_changed(out / name, text.encode())
for platform in ('windows', 'linux'):
    text = (root / f'.scratch/cpu-tf-{platform}.py').read_text()
    text = text.replace('cpu-ggml-transformer-fill', 'cpu-ggml-layout-broadcast')
    text = text.replace('cpu-tf-', 'cpu-lb-').replace('-tf-consumer', '-lb-consumer')
    write_changed(root / f'.scratch/cpu-lb-{platform}.py', text.encode())
formatter = Path('C:/Program Files/Microsoft Visual Studio/18/Enterprise/VC/Tools/Llvm/x64/bin/clang-format.exe')
for name in ('src/compute_provider_ggml/ggml_cpu_provider.cc', 'tests/compute_provider_ggml/cpu_provider_test.cc',
             'tests/compute_provider_ggml/mature_admission_test.cc', 'tests/compute_provider_ggml/transformer_fill_test.cc'):
    diff = subprocess.check_output(['git', 'diff', '--unified=0', '--', name], text=True)
    lines = []
    for start, count in re.findall(r'@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@', diff):
        first, size = int(start), int(count or 1)
        if size: lines.append(f'-lines={first}:{first+size-1}')
    if lines: subprocess.run([formatter, '-i', *lines, name], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
subprocess.run([formatter, '-i', 'tests/compute_provider_ggml/layout_broadcast_test.cc'], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
manifest = json.loads((old / 'manifest.json').read_bytes())
manifest['files']['tests/compute_provider_ggml/layout_broadcast_test.cc'] = ''
manifest['candidate'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
for name in manifest['files']:
    manifest['files'][name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
(out / 'manifest.json').write_bytes((json.dumps(manifest, indent=2)+'\n').encode())
