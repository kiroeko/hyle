"""Compact finite evidence; no binaries/raw/SDK payloads, no build/native."""
from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1];OLD=R/'.scratch/inference-m2-borrowed-alias-harness-20261030'
OUT=R/'docs/evidence/correctness/inference-auxiliary-warm-boundary-2026-10-31.json';ZIP=OUT.with_suffix('.zip')
read=lambda p:json.loads(Path(p).read_text())
def pin(p):
 p=Path(p);return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
assert not ZIP.exists() and not OUT.exists()
processes=[];totals={k:dict(passed=0,failed=0) for k in ('CXX','link','native')}
for p in sorted(W.rglob('process.json')):
 d=read(p);assert d['state']=='TERMINAL' and d['exit']==0 and not d.get('timed_out')
 kind={'compile':'CXX','link':'link','runs':'native'}[p.relative_to(W).parts[0]];totals[kind]['passed']+=1;processes.append(dict(kind=kind,receipt=pin(p)))
assert totals==dict(CXX=dict(passed=4,failed=0),link=dict(passed=3,failed=0),native=dict(passed=12,failed=0))
whole=read(W/'whole-cli-summary.json');session=read(W/'session-compare.json');assert whole['status']=='PASS_ALL_FOUR_DEFAULT_CASES' and session['status']=='PASS_EXACT_COMPLETE_SESSION'
assert session['saved_payload_files_per_arm']==378 and session['saved_payload_bytes_per_arm']==150761472
proposal=read(R/'.scratch/inference-auxiliary-warm-combined-20261030/plan.json');sources=[]
for row in proposal['source_pins']:
 p=R/row['relative'];actual=pin(p);assert all(actual[k]==row['candidate'][k] for k in ('bytes','sha256'));sources.append(actual)
checks={}
for case in ('auxiliary-preparation-cpu','sampling-policies-cpu','conditional-logits-cpu','history-logits-cpu','mtp-logits-cuda'):
 p=W/'runs/candidate'/case/'attempt1/report.json';assert read(p).get('status')=='PASS';checks[case]=pin(p)
body=dict(schema='hyle.inference.auxiliary-warm-boundary.v1',status='CURRENT_FINITE_CHECKS_PASS',base_commit='8c463c8d2d2ca011b018639508d26980c3515a6f',full_goal_complete=False,
 source_pins=sources,patch=pin(R/'.scratch/inference-auxiliary-warm-combined-20261030/auxiliary-warm-seven-source.patch'),
 build=dict(totals=totals,actual_processes=19,all_terminal=True,retained=232,reused=231,new_auxiliary_object=1,SDK_CXX=0,NVCC=0,downloads=0,processes=processes),
 checks=dict(cases=checks,cold_budget_refusals=3,same_key_retries=3,warm_original_programs=True,tracked_execution_live_restored=True,
  default_pairs_against_retained_M2=whole,Session=dict(files_per_arm=378,bytes_per_arm=150761472,all_SHA_and_direct_bytes_equal=True,complete_observation_equal_except_output_root=True,final_versions=0,report=pin(W/'session-compare.json'),manifest=pin(W/'session-vector-manifest.json'))),
 near_single_timing_diagnostic=read(W/'near-single-timing-diagnostic.json'),hardware=read(W/'hardware-toolchain.json'),
 implementation=dict(cold='Original draft/prefix/frontier graph math, constants, ports, finite bindings and physical IO remain Qwen-local out of line; stable unique programs and original carrier/Graph/lease budgets retained.',
  runtime='Original episode/guard declarations remain runtime dependencies, not pure cold data. Same-call Phase selection intentionally changes warm lookup wiring; no new permission/owner/executor.',
  proof='Cold3 and8declarations reuse independent source projections; originalaux11runtime proof applies to aux-only extraction. Warmv2 and combined review separately cover intentional hot caller changes.'),
 history=dict(sampling_offline_parser=read(W/'sampling-parser-schema-error.json'),seal_preparation=read(W/'seal-preparation-error.json'),
  root_test_preparation='Original LF-context patch attempt and corrected test plan retained. No native/CXX failure in this19process batch; offline parser corrections never reran native.'),
 scope='Current Windows CPU/singleCUDA finite architecture checks. Four retained-M2 timing references are not same-window performance; two fresh old single controls only support gross-regression observations. No stable speedup/full performance window, full CMake build, second complete model, Mac/multi-card or whole-goal completion. Optional head preparation/failure priority and scratch/diagnostic merge ordering remain explicit limits; no full-heap accounting or late projection-fault claim.')
save(W/'summary-draft.json',body)
files=set()
def add(p):
 p=Path(p)
 if p.is_file():files.add(p)
for p in W.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(W)
 if any(x in ('bin','tmp','__pycache__') for x in rel.parts) or p.suffix.lower() in ('.obj','.pdb','.exe','.dll','.lib','.exp','.map','.pyc','.f32','.bf16','.f16','.bin'):continue
 if p.name not in ('archive-receipt.json',):add(p)
external={
 'inference-auxiliary-warm-combined-20261030':['plan.json','applied.json','auxiliary-warm-seven-source.patch','combination-proof.json','independent-current-applied-review.json','README.md'],
 'inference-auxiliary-cold-program-extract-20261030':['independent-review-bridge.json','independent-review-bridge.py','static-proof.json','body-projections.json','outer-facts-rename-proof.json','static-proof-incomplete-signature-scope.json'],
 'inference-warm-phase-selection-20261030':['same-call-phase-v2.patch','plan-v2.json','independent-review-v2.json','README.md'],
 'inference-auxiliary-cold-program-test-20261030':['auxiliary-preparation-test.patch','plan.json','independent-review.json','lf-context-attempt1.patch','plan-attempt1.json'],
 'inference-joint-architecture-review-20261031':['README.md','sources.json']}
for directory,names in external.items():
 for name in names:add(R/'.scratch'/directory/name)
for case in ('ordinary-single','mtp-single','ordinary-two','mtp-two','session-cuda'):
 folder=OLD/'runs/candidate'/case/'attempt1'
 for name in ('report.json','command.json','process.json','image.json'):add(folder/name)
add(OLD/'runs/candidate/session-cuda/attempt1/vectors/observation.json')
manifest=[pin(p) for p in sorted(files)]
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
 z.writestr('archive-manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(ZIP) as z:
 assert len(z.namelist())==len(manifest)+1
 for item in manifest:
  raw=z.read(item['path']);assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'] and raw==(R/item['path']).read_bytes()
body['archive']=dict(**pin(ZIP),members=len(manifest)+1,all_members_readback=True);save(OUT,body);save(W/'archive-receipt.json',body['archive'])
print(json.dumps(dict(status='PUBLISHED_FINITE_EVIDENCE',summary=pin(OUT),archive=body['archive'])))
