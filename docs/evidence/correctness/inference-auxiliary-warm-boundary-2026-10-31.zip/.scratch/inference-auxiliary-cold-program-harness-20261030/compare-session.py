"""Offline exact default reports and complete Session payloads; no native."""
from pathlib import Path
import importlib.util,json
W=Path(__file__).resolve().parent
OLD=W.parents[1]/'.scratch/inference-m2-borrowed-alias-harness-20261030'
spec=importlib.util.spec_from_file_location('target_comparison_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin=b.read,b.save,b.pin
def norm(value,arm):
 if isinstance(value,str):return value.replace(str((OLD if arm=='baseline' else W)/'runs'/'candidate'/'session-cuda/attempt1/vectors'),'{VECTORS}')
 if isinstance(value,list):return [norm(item,arm) for item in value]
 if isinstance(value,dict):return {key:norm(item,arm) for key,item in value.items()}
 return value
def delta(old,new,path='$'):
 if isinstance(old,dict) and isinstance(new,dict):
  return [row for key in sorted(old.keys()|new.keys()) for row in delta(old.get(key),new.get(key),path+'.'+key)]
 if isinstance(old,list) and isinstance(new,list):
  if len(old)!=len(new):return [dict(path=path,old_length=len(old),new_length=len(new))]
  return [row for at,(a,z) in enumerate(zip(old,new)) for row in delta(a,z,path+'['+str(at)+']')]
 return [] if old==new else [dict(path=path,old=old,new=new)]
observations={};vectors={};reports={}
for arm in ('baseline','candidate'):
 folder=(OLD if arm=='baseline' else W)/'runs'/'candidate'/'session-cuda/attempt1/vectors'
 o=read(folder/'observation.json');observations[arm]=o;reports[arm]=read(folder.parent/'report.json')
 assert o['status']=='PASS_BYTE_EXACT' and o['all_vectors_byte_equal'] and o['all_finite']
 assert o['numerical_tolerance_policy'] is None and o['final_live_snapshot_versions']==0
 assert o['managed_backing_bytes']==o['planned_backing_bytes']==80240691
 assert o['idle_head_full_byte_checks']==4 and o['A_calls_after_B_stop']==3
 for row in o['vectors']:
  assert row['byte_equal'] and row['max_abs']==row['squared_error']==0
  assert row['nonfinite_baseline']==row['nonfinite_actual']==0
 vectors[arm]={path.relative_to(folder).as_posix():pin(path) for path in sorted(folder.rglob('*'))
  if path.is_file() and path.suffix in ('.f32','.bf16','.f16','.bin')}
 assert len(vectors[arm])==378
assert vectors['baseline'].keys()==vectors['candidate'].keys()
entries=[]
for name in vectors['baseline']:
 first,second=(vectors[arm][name] for arm in ('baseline','candidate'))
 assert first['bytes']==second['bytes'] and first['sha256']==second['sha256'],name
 with Path(first['path']).open('rb') as a,Path(second['path']).open('rb') as z:
  while True:
   x,y=a.read(1048576),z.read(1048576);assert x==y,name
   if not x:break
 entries.append(dict(relative=name,bytes=first['bytes'],baseline_sha256=first['sha256'],candidate_sha256=second['sha256'],byte_equal=True))
differences=delta(norm(observations['baseline'],'baseline'),norm(observations['candidate'],'candidate'))
report_differences=delta(reports['baseline'],reports['candidate'])
save(W/'session-vector-manifest.json',dict(status='PASS_EXACT_COMPLETE_VECTOR_BYTES',arms=vectors,file_count_per_arm=len(entries),
 bytes_per_arm=sum(row['bytes'] for row in entries),all_cross_arm_bytes_identical=True,numerical_tolerance=None,
 metadata_equal_except_output_root=not differences))
save(W/'session-compare.json',dict(status='PASS_EXACT_COMPLETE_SESSION' if not differences and not report_differences else 'FAIL',
 observation_equal_after_only_output_root_normalization=not differences,ignored_semantic_fields=[],
 normalization='Only each run-specific absolute vectors directory is replaced by {VECTORS}; every remaining field stays exact.',
 differences=differences,report_differences=report_differences,saved_payload_files_per_arm=len(entries),
 saved_payload_bytes_per_arm=sum(row['bytes'] for row in entries),payload_byte_equal=True,payloads=entries,
 scalar_facts={key:value for key,value in observations['candidate'].items() if not isinstance(value,(dict,list))}))
assert not differences and not report_differences,(differences,report_differences)
whole=read(W/'whole-cli-summary.json');assert whole['status']=='PASS_ALL_FOUR_DEFAULT_CASES'
assert all(row['all_non_timing_fields_equal'] and not row['differences'] for row in whole['checks'])
print(json.dumps(dict(default_scenarios=4,all_non_timing_exact=True,Session_payload_files_per_arm=len(entries),
 bytes_per_arm=sum(row['bytes'] for row in entries),byte_equal=True,metadata_differences=differences,final_versions=0)))
