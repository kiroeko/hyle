"""Five candidate processes vs retained M2 facts/raw; two fresh old single controls."""
from pathlib import Path
import importlib.util
W=Path(__file__).resolve().parent;R=W.parents[1];OLD=R/'.scratch/inference-m2-borrowed-alias-harness-20261030'
spec=importlib.util.spec_from_file_location('aux_default_phase',R/'.scratch/inference-phase-preparation-harness-20261030/run-native.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
n.W=W;n.R=R;n.h.s.b.W=W
read,save,pin,exact=n.read,n.save,n.pin,n.exact
plan=read(OLD/'default-plan.json');old_image=read(OLD/'ready-cli.json');exact(old_image)
for case in ('ordinary-single','mtp-single','ordinary-two','mtp-two','session-cuda'):
 row=plan['cases'][case];n.run(case,row,'candidate')
 if case=='session-cuda':continue
 old_path=OLD/'runs/candidate'/case/'attempt1/report.json';new_path=W/'runs/candidate'/case/'attempt1/report.json'
 old,new=read(old_path),read(new_path);different=n.delta(n.stable(old),n.stable(new));same=n.stable(old)==n.stable(new)
 save(W/('compare-'+case+'.json'),dict(status='PASS' if same else 'FAIL',differences=different,baseline_or_retained_reference=pin(old_path),candidate=pin(new_path),key_presence_preserved=True))
 assert same,different
 if case in ('ordinary-single','mtp-single'):
  folder=W/'runs/near-baseline'/case/'attempt1';save(folder/'image.json',old_image)
  save(folder/'source-binding.json',dict(model_base=pin(OLD/'model-link-base.json'),source_main_sha256='d76e2b006256d440b6f7682d291787fff7f97f9487b18ea7179696f4cb792336',source_Graph_sha256='8387c86edd64fcc2c5257664ce028d344a5133d8c6a1c2b8628adbdf375aec40',scope='Existing M2 candidate mirror; never label current product main as old source.'))
  n.h.s.b.execute([old_image['path'],*row['args']],folder,900);old_fresh=n.parse(folder,case,row)
  assert n.stable(old_fresh)==n.stable(new)
 print('PASS default',case,flush=True)
