"""Auxiliary factory baseline/source/dependency recipes only, no execution."""
from pathlib import Path
import importlib.util,json,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-constant-view-alignment-harness-20261030/model-link-base.json'
EXTRACT=R/'.scratch/inference-auxiliary-cold-program-extract-20261030'
spec=importlib.util.spec_from_file_location('auxiliary_baseline_prior',BASE.parent/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
assert not (W/'baseline-plan.json').exists()
base=read(BASE);proposal=read(EXTRACT/'plan.json');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='bc6556f8b1d4248df0dc0b47b11719b9b7341748'
assert len(base['retained'])==231
for item in [*base['retained'],base['runtime']]:exact(item)
snapshots=[]
for item in proposal['source_pins']:
 p=R/item['relative']
 if item['base'] is None:assert not p.exists();continue
 expected=dict(path=str(p),**item['base']);exact(expected)
 out=W/'baseline-source'/item['relative'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
 snapshots.append(dict(original=expected,snapshot=pin(out)))
changed={key(R/i['relative']) for i in proposal['source_pins']}
index=read(base['sdk_engine_dependencies']['path']);affected=[]
for row in index['inspected']:
 exact(row['dependencies']);dep=read(row['dependencies']['path'])['Data']
 overlap=[p for p in [dep['Source'],*dep['Includes']] if key(p) in changed]
 if overlap:affected.append(dict(**row,changed_sources=overlap))
assert not affected,affected
consumers={};unrelated={}
for name,row in base['current_consumers'].items():
 exact(row['receipt']);receipt=read(row['receipt']['path']);exact(receipt['object'])
 overlap=[i['path'] for i in receipt['source_identities'] if key(i['path']) in changed]
 mismatch=[i for i in receipt['source_identities'] if not Path(i['path']).exists() or pin(i['path'])!=i]
 if overlap:
  assert not mismatch,(name,mismatch)
  consumers[name]=dict(**row,source_identities=receipt['source_identities'],changed_sources=overlap)
 elif mismatch:unrelated[name]=dict(receipt=row['receipt'],mismatched_source_pins=mismatch)
assert set(consumers)=={'cli','tiny','session'},list(consumers)
assert set(unrelated)<= {'region'},list(unrelated)
units={}
def relocate(raw,name,old_source,new_source):
 out=W/'compile'/name/'attempt1';command=[];count=0
 for index,arg in enumerate(raw):
  if index and raw[index-1].lower()=='/sourcedependencies':arg=str(out/'dependencies.json')
  elif arg.lower().startswith('/fo'):arg='/Fo'+str(out/'unit.obj')
  elif arg.lower().startswith('/fd'):arg='/Fd'+str(out/'unit.pdb')
  elif key(arg)==key(old_source):arg=str(new_source);count+=1
  command.append(arg)
 assert count==1 and len([a for a in command if a.lower().endswith('.cc')])==1 and '/c' in command
 return command
wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
for name,source in [('cli',wrapper),('tiny',R/'tests/tools/qwen_host_image_test.cc'),('session',R/'engine/models/qwen35/mtp_session_probe.cc')]:
 receipt=read(consumers[name]['receipt']['path']);original_source=next(i['path'] for i in receipt['source_identities'] if i['path'].lower().endswith('.cc') and (Path(i['path']).name=='cli.cc' if name=='cli' else key(i['path'])==key(source)))
 raw,origin=b.s.command_for(receipt['object']['path'],original_source)
 units[name]=dict(source=str(source),compile=relocate(raw,name,original_source,source),origin=origin)
raw=base['compile'];original_source=base['consumer_source']
units['auxiliary']=dict(source=str(R/'engine/models/qwen35/auxiliary_programs.cc'),compile=relocate(raw,'auxiliary',original_source,R/'engine/models/qwen35/auxiliary_programs.cc'),origin=pin(BASE))
status=subprocess.check_output(['git','status','--short'],cwd=R,text=True).splitlines()
save(W/'baseline-plan.json',dict(status='PREPARED_SOURCE_BASELINE_ONLY_NO_EXECUTION',head=head,base=pin(BASE),proposal=pin(EXTRACT/'plan.json'),independent_review=pin(EXTRACT/'independent-review-bridge.json'),
 snapshots=snapshots,retained=base['retained'],runtime=base['runtime'],affected_consumers=consumers,unrelated_pending_consumer_source_mismatch=unrelated,
 affected_retained=affected,SDK_dependency_rows=len(index['inspected']),historical_unavailable_dependencies=index['unavailable'],observed_worktree_status=status,
 note='Pending M2 region test does not include/alter auxiliary cold source pins and is not an auxiliary input. No blanket clean-tree requirement; original main/inventory exact and new3absent.',CXX=0,links=0,native=0))
save(W/'recipes-prepared.json',dict(status='PREPARED_NOT_AUTHORIZED_TO_BUILD',units=units,retained=base['retained'],runtime=base['runtime'],original_link=base['link'],original_consumer=base['current_consumers']['cli']['object'],
 candidate_retained=232,reused_retained=231,new_auxiliary_CXX=1,consumer_CXX=3,old_SDK_CXX=0,old_model_cold_CXX=0,max_compilers=2,NVCC=0,downloads=0,
 header_self_containment='New auxiliary TU includes auxiliary_programs.h first, which includes episode_state.h; its actual compile covers both self-contained headers. No extra mirror leaf test proposed.',
 native_scope='Root will choose finite existing flags/failure checks after final freeze; this file executes no command.'))
print(json.dumps(dict(status='BASELINE_RECIPES_READY',head=head,retained=231,retained_affected=0,recompile_consumers=list(consumers),new_auxiliary=1,candidate_inputs=232,unrelated_pending=list(unrelated),CXX=0,links=0,native=0)))
