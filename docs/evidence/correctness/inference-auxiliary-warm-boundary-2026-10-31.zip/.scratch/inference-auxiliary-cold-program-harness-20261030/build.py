"""Aux+warm: one new cold object and three current main consumers; max2cl."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import importlib.util,json,shutil,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
BASE=R/'.scratch/inference-m2-borrowed-alias-harness-20261030/model-link-base.json'
spec=importlib.util.spec_from_file_location('aux_build_prior',BASE.parent/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
s=b.s;s.W=s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
def prepare():
 assert not (W/'plan.json').exists()
 p=read(W/'recipes-prepared.json');proposal=read(R/'.scratch/inference-auxiliary-warm-combined-20261030/plan.json');frozen=[]
 for row in proposal['source_pins']:
  source=R/row['relative'];actual=pin(source);assert all(actual[k]==row['candidate'][k] for k in ('bytes','sha256'))
  out=W/'source-frozen'/row['relative'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(source.read_bytes());frozen.append(dict(source=actual,snapshot=pin(out)))
 base=read(BASE)
 for item in [*base['retained'],base['runtime']]:exact(item)
 changed={key(row['source']['path']) for row in frozen};idx=read(base['sdk_engine_dependencies']['path']);affected=[]
 for row in idx['inspected']:
  dep=read(row['dependencies']['path'])['Data']
  if any(key(x) in changed for x in [dep['Source'],*dep['Includes']]):affected.append(row)
 assert not affected,affected
 p.update(status='ROOT_AUTHORIZED_CURRENT7SOURCE_FROZEN',base=pin(BASE),source_freeze=frozen,proposal=pin(R/'.scratch/inference-auxiliary-warm-combined-20261030/plan.json'),old_SDK_affected=affected)
 save(W/'plan.json',p);(W/'bin').mkdir(exist_ok=True);shutil.copyfile(base['runtime']['path'],W/'bin'/Path(base['runtime']['path']).name)
 print('FROZEN7:aux+3consumer,0SDK,232inputs',flush=True)
def compile(attempt,names):
 p=read(W/'plan.json')
 for row in p['source_freeze']:exact(row['source'])
 def one(name):
  u=p['units'][name];folder=W/'compile'/name/attempt;command=[a.replace(str(W/'compile'/name/'attempt1'),str(folder)) for a in u['compile']]
  s.b.execute(command,folder,900);dep=read(folder/'dependencies.json')['Data'];paths=sorted({Path(x).resolve() for x in [dep['Source'],*dep['Includes']] if Path(x).is_relative_to(R)})
  save(W/'compile'/name/'receipt.json',dict(object=pin(folder/'unit.obj'),dependencies=pin(folder/'dependencies.json'),process=pin(folder/'process.json'),source_identities=[pin(x) for x in paths]));print('COMPILED',name,flush=True)
 with ThreadPoolExecutor(max_workers=2) as pool:
  fs=[pool.submit(one,n) for n in names]
  for f in as_completed(fs):f.result()
def link(name,attempt):
 p=read(W/'plan.json');c=read(W/'compile'/name/'receipt.json');aux=read(W/'compile/auxiliary/receipt.json')
 for item in [c['object'],*c['source_identities'],aux['object'],*aux['source_identities'],*p['retained']]:exact(item)
 args=[];count=0
 for arg in p['original_link']:
  if key(arg)==key(p['original_consumer']['path']):arg=c['object']['path'];count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 assert count==1 and aux['object']['path'] not in args;args.append(aux['object']['path'])
 assert len(p['retained'])+1==232
 s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='compile':compile(sys.argv[2],sys.argv[3:])
 elif sys.argv[1]=='link':link(sys.argv[2],sys.argv[3])
 else:raise ValueError(sys.argv[1])
