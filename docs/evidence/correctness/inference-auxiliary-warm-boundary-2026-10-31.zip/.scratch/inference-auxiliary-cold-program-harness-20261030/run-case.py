"""Existing tiny finite cases; preserve every JSON and known sampling fact line."""
from pathlib import Path
import importlib.util,json,re,sys
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('aux_native_build',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ga=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
cases={'auxiliary-preparation-cpu':['--cpu',str(ga),'--auxiliary-preparation'],
 'sampling-policies-cpu':['--cpu',str(ga),'--sampling-policies'],
 'conditional-logits-cpu':['--cpu',str(ga),'--conditional-logits'],
 'history-logits-cpu':['--cpu',str(ga),'--history-logits'],
 'mtp-logits-cuda':['--cuda',str(ga),'--mtp-logits']}
parse_only=sys.argv[1:2]==['parse-only']
for name in sys.argv[2:] if parse_only else sys.argv[1:]:
 folder=W/'runs/candidate'/name/'attempt1';image=b.read(W/'ready-tiny.json');b.exact(image);b.save(folder/'image.json',image)
 if parse_only:assert b.read(folder/'process.json')['exit']==0
 else:b.s.b.execute([image['path'],*cases[name]],folder,900)
 text=(folder/'stdout.log').read_text(encoding='utf-8-sig');decoder=json.JSONDecoder();offset=0;values=[];facts=[]
 while offset<len(text):
  while offset<len(text) and text[offset].isspace():offset+=1
  if offset==len(text):break
  try:value,offset=decoder.raw_decode(text,offset);values.append(value)
  except json.JSONDecodeError:
   end=text.find('\n',offset);end=len(text) if end<0 else end;line=text[offset:end].strip()
   assert name=='sampling-policies-cpu' and re.fullmatch(r'batched_text_sampling=true flat_identity_rows=2 flat_identity_words=4 families=\d+ phases=\d+',line),line
   facts.append(line);offset=end
 assert values
 if name=='sampling-policies-cpu':
  assert len(values)==2 and len(facts)==1 and values[-1]['status']=='PASS' and values[-1]['case']=='sampling-policies'
  assert values[0]['generated_tokens']==values[0]['requested_output_tokens'] and values[0]['admitted_requests']==values[0]['retired_requests'] and 'sessions' in values[0]
 for value in values[1:] if name=='sampling-policies-cpu' else values:
  assert value.get('status')=='PASS' or (value.get('case')=='history-finite-math' and value.get('result')=='PASS'),(name,value.get('case'),value.get('status'))
 if name=='auxiliary-preparation-cpu':
  value=values[-1];assert value['cold_budget_refusals']==value['same_key_retries']==3 and value['warm_original_programs'] and value['tracked_execution_live_restored'] and value['submitted_model_graphs']==value['final_versions']==0
 b.save(folder/'report.json',values[0] if len(values)==1 and not facts else dict(status='PASS',reports=values,text_observations=facts))
 print('PASS',name,flush=True)
