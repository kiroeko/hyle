# 同次 warm Phase 选择：窄 scratch 候选

当前为 **v2**，只改 `main.cc` 的 `prepare_evaluations`，不应用、不构建、不 profile。精确 sourcebase 是 `plan-v2.json` 的当前 Phase6源码 pins（HEAD910a加已应用Phase/test），不是未来commit。只应用 `same-call-phase-v2.patch`；`verification-v2/`是scratch应用校验副本，禁止整文件覆盖后续main。v1全部原件保留，v2缩窄以完整保留原前置校验和step计时点。

变化：全部原前置检查和逐request验证完成，既有 `step_start` 已取得后，用 requests、physical_tokens、role、completion、sampling_index、relay/imported、packing 的完整 ExecutionShape 做一次只读 Phase lookup。存在原完整Phase时，复用其 family/child 事实，短路普通 exact admission 前重复的 Family/chunks 查找；稍后直接使用此同次Phase。cold miss仍走原find_child/admit_exact_shape/prepare_child；admission后从现map重resolve。三个 packed/compact Family availability检查完全不改。诊断路径返回null，完整保留原default/probe准备次序。successor原已初始化slot检查未动。

短证明：

1. 原 `prepare_child` 在相同完整key命中时已直接返回同一Phase，先于find_child。只有从完整Family成功构造并发布的Phase才能位于原map，因此warm命中可作Family availability事实；不代表实际输入或权限已合格。
2. Key在compact role/packing改写和所有验证之后捕获。sampling取首Session原配置index；逐Session原配置对象身份检查仍动态执行。所有packed/compact旧availability gate逐字节不改。
3. `step_start` 以前整块原文一致；没有新增clock，也不把lookup移到原step计时范围外。新增map.find只用内建字段的默认比较，无分配/原生调用。carrier取得之后的bind/layout/replay/submit/retire尾部逐字节相同，完整main逆3处恢复原bytes；未改实际lease/epoch/stop/角色/context/Source/candidate检查。
4. 指针仅此调用局部，未放入Session、Model或新owner。命中时该shape不需cold admission；miss时不持Phase指针，若admission退休/删除库存便重新查找。原串行Model接纳、eviction先retire两种Phase再删Family、后续active Step保护保持；不跨调用保存可被evict的裸指针。

范围限制：不改packed描述或modifier候选，不增加公用API/权限缓存/热虚表；不声称耗时收益。普通warm路径原Family lookup＋随后Phase lookup改为一个原Phase lookup和局部事实复用；packed路径不硬省其前置Family查找。cold miss可多一次只读Phase查询，仍保原完整冷接纳。静态校验含git apply check、scratch实际apply与逆check；CXX/native及实际warm/cold/eviction消费者尚未运行。
