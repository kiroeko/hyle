# 联合架构复审（2026-10-31，只读）

源码基线为 `8c463c8d2d2ca011b018639508d26980c3515a6f`，另含 root 已应用的 aux＋same-call warm 七源码；实际 bytes 与组合冻结 pins 全等（见 sources.json）。本审没有改产品、构建、原生运行或 profile；七源码的有限验证由当前 harness 负责，尚不能以本审代签。复用[四类接入矩阵](../inference-cross-model-boundary-review-20261030/review.md)的真实需求与消费者范围，下面更新其历史待办，不重开已完成项。

| 正面要求 | 当前实现入口 | 实际消费者／依据 | 适用边界 |
|---|---|---|---|
| 共用执行与清楚的模型职责 | `engine/inference/step_execution.h` 静态驱动；Qwen `main.cc:5469,5785`，GLM Pro `:1853,1906,2379,2713` | Qwen 普通、连续及同步目标；GLM ordinary／K1 同步分支，已有共同驱动、失败与提交见证证据 | GLM 的完整 StateVersion／journal、Kimi KDA→MLA、DeepSeek 多 frontier 与 Qwen Snapshot 差异留模型；不要求所有组件虚构 token／successor |
| 冷构图与真正独立编译 | Qwen 唯一 `cold_sources.cmake` 的 weights／graph_builder／target_graph／family_factory／phase_preparation／auxiliary_programs | Graph/cache facts/target/Family/Phase 已有有限归档；aux 三完整工厂已应用，Model `:1483,1678,1863` 只直接冷调用，当前验证中 | 私有 cc 数学修改不再使 15 个 include-main 消费者重编；头布局／Model 政策修改仍可传播。episode_state 含原运行时 guard，不能称全部头是纯冷数据 |
| 新模型接入复用原机制 | `program_io.h:52,92,127,139` 接 concrete route；`prepared_program_family.h:69–105` 接有限 exact inventory；共用 checked 输出池 | DSpark `dspark_native_consumer.h:112–117`，GLM Pro `:208–213`，Kimi `:274–287` 经 ColdProgram 直接调用原 ProgramIo；Kimi 还用原 ProgramCarrier | concrete／有限族是合法两种图形状。ColdProgram 是稳定持有＋fixture 政策，已共用 IO；[新 concrete admission API 提案已撤销](../inference-concrete-program-admission-20261030/README.md)，不是剩余缺项 |
| 冷计划直接供热执行，权限仍真实 | Family／Phase 冷保存 child、输出索引、IO、slots；`program_slots.h:103–116` warm 不构造初始化事实；当前 `main.cc:2817–2833,2873` 同次复用 Phase | 当前 aux/warm 静态逆恢复证明及既有 Phase/warm/预算/晚 layout 检查；admission 后重新 resolve，不跨 call 留裸指针 | 本次 lease／layout／Source reader_binding／Append、Session epoch／pending、carrier closing／retirement 仍动态；`main.cc:3030–3052` 等不能用冷 facts 取代。per-step 候选分配也不能未经测量就改成另一 owner |
| 每种模型保专用效率与合法快路径 | 模型独立数学／workload/profile／provider 资格；原 replay/capture、packed 路由、native／generated 输出与 Source 接力保留 | GLM Pro `:178–198` 冷检查实际 packed provider；Kimi `:365–445` 原 hidden Source→MLA；Qwen Family/Phase/aux 仍原 Graph／Invocation／预算 | 本片没有增加热虚表、执行器或模型名分支；不意味着各模型性能达标。默认完整词表普通／MTP 的实际 kernel、主机费用和完整输出／算量对照仍须继续 |

接入修改面：模型包负责几何／权重角色与变换、数学、实际状态 schema／发布／修复及静态步骤适配；应用装配目前是 `engine/CMakeLists.txt:37–40`、`engine/main.cc:1–4` 的 Qwen 薄入口，新模型需对应目标／入口与自己的验证接线。`engine/inference` 当前无 Qwen／GLM／Kimi／DeepSeek 名字分支；增加模型不应修改 Qwen 或重复 IO／退休算法，但新算子／新状态能力若确实缺失仍须在实际需求下补底层。这里只证明现有四类组件接缝，未交付第二完整引擎或稳定通用应用 API，也未实测任意新模型的总接入成本。

成熟源码依据已重新核实际本地 HEAD 和文件 bytes：llama.cpp `23b0202a189c44a54625aadcb37a946dd1d6278d` 的 `llama-context.cpp:1424–1472` 用完整参数判图复用，随后设置本次输入；TensorRT-LLM `46d9966b54d9d11998b712e732fb20f64d4d35c0` 的 decoder `runner.py:191–200,323–330` 分开 buffers／metadata／graphs 准备与 forward，`model_call.py:55–80` 仍借本次 metadata。它们支持准备事实与动态输入分责，不证明 Hyle 要复制 runtime rebuild、virtual／Python callback 或另一权限缓存；专用模型数学也不应被统一层抹平。实际 pins 在 sources.json。

**本次确认仍需先新增实现的共同架构缺项：0。** 当前最后的 aux／warm 验证通过后，应转默认 full-V 普通／MTP 性能根因与完整消费者对照；packed 描述的小重复、15 个 include-main 边或单一应用入口都不足以再启动纯整理片。后续实际发现的功能／模型适配／快路径缺项继续进入完整 goal；本结论不等于任意模型／拓扑或整体性能目标完成，不将架构百分比直接改成 100%。
