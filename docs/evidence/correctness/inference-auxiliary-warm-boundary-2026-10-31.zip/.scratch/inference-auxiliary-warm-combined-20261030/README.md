# 七源码组合：辅助冷边界＋同次warm Phase接线＋真实预算用例

仅scratch，不apply／CXX／native／profile。`plan.json`保存7份base/candidate pins及实际命令。
完整补丁 `auxiliary-warm-seven-source.patch` 为87412B，SHA
`6ae903f9b4e5f02c4b74e00db7777b74a2bfb6282dcd95729d8bb464c2e86b67`。
4个新文件均只出现一次；不含docs/progress、M2 Graph或M2 tests。

组合输入全部原样复用：auxiliary61323c70、warm-v2 2c00b6d3、root测试8dfbcc7e。
只有aux候选main叠加既有warm两hunks；其他6源码与原aux／root测试候选全bytes同。
合并main SHA `327873338c11e189746da36d09cf2df9d398a82c66b592b946182b18bbc4f8be`。

实际scratch窄应用warm后，逆warm恢复aux main的raw bytes；完整组合patch在另一scratch
镜像forward后7源码逐bytes回读相同，reverse后3旧文件恢复原raw bytes且4新文件不存在。
product仅执行git apply check，exit0。所有有写入的git apply均从repo根显式--directory指scratch。
首attempt1的嵌套cwd Git命令跳过了warm patch，已保留为未采用的attempt1-skipped-warm；
不把该exit0或85e179稿当组合成功。

`combination-proof.json`：3个cold body／8原类型仍是aux同一份源，另外10个真实完整runtime
方法全文不变；唯一改变的runtime方法prepare_evaluations单列既有warm的3处接线。

warm借用范围核对：

- 所有原请求／角色／packing／sampling预检之后、原step_start之后，才从完整ExecutionShape
  key查询原Phase；diagnostic直接null保原默认／probe路径。
- 查询到使用之间只有admit_exact_shape可改变Family/Phase库存，且仅miss时调用并立即重新
  resolve。原eviction先实际retire并删ordinary/imported Phase，再删Family。
- take_decode_ahead及prune只消费整数／weak-member元数据，不改上述map；候选／Session记账
  与predecessor initialized检查也不改库存。Phase pointer只在本次调用局部使用，没有跨call缓存。
- 实际carrier、lease、Source、epoch、stop、权限与retirement的原tail不变。此次架构接线没有
  新dispatch／owner／权限缓存；不据此报告性能收益。

root真实aux测试已由独立短审核Model/API与scope：三factory真实execution row满压拒绝、
同key重试、frontier不提前init、prefix/draft原Invocation及warm指针；16MiB是cache cap，
不是execution或全heap限额。early tracked failure不代签late Tensor/readback或native cold-copy。
数学／失败顺序差异仍按aux原说明保留，所有运行结果待后续实际验证。
