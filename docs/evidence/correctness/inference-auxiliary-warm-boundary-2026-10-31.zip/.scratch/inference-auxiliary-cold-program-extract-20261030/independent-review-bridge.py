"""Independent source-only extraction review. Does not import generator/proof or run CXX."""
from pathlib import Path
import hashlib,json,re,difflib
W=Path(__file__).resolve().parent;R=W.parents[1];C=W/'candidate/engine/models/qwen35'
original=(R/'engine/models/qwen35/main.cc').read_text();candidate=(C/'main.cc').read_text();aux=(C/'auxiliary_programs.cc').read_text()
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
def masked(s):
 out=list(s);i=0
 while i<len(s):
  end=None
  if s.startswith('//',i):end=s.find('\n',i);end=len(s) if end<0 else end
  elif s.startswith('/*',i):end=s.find('*/',i+2);assert end>=0;end+=2
  elif s.startswith('R"',i):
   p=s.find('(',i+2)
   if p>=0 and p-i<=18:
    terminator=')'+s[i+2:p]+'"';end=s.find(terminator,p+1);assert end>=0;end+=len(terminator)
  elif s[i] in ('"',"'") and not (s[i]=="'" and i and s[i-1].isalnum() and i+1<len(s) and s[i+1].isalnum()):
   quote=s[i];end=i+1
   while end<len(s):
    if s[end]=='\\':end+=2;continue
    if s[end]==quote:end+=1;break
    end+=1
  if end is not None:
   for j in range(i,min(end,len(s))):
    if s[j]!='\n':out[j]=' '
   i=end
  else:i+=1
 return ''.join(out)
def balanced(s,start,left,right):
 m=masked(s);assert m[start]==left;level=0
 for i in range(start,len(m)):
  if m[i]==left:level+=1
  elif m[i]==right:
   level-=1
   if level==0:return i+1
 raise AssertionError(('unclosed',s[start:start+60]))
def function(s,marker):
 at=s.index(marker);p=s.index('(',at);close=balanced(s,p,'(',')');body=masked(s).index('{',close);end=balanced(s,body,'{','}')
 return s[at:end]
def struct(s,name):
 m=re.search(r'\bstruct\s+'+name+r'\b[^;{]*\{',s);assert m,name
 end=balanced(s,s.index('{',m.start()),'{','}');return s[m.start():end+1]
def normalized(s):return s.strip()
types=[]
for name in ('StepMember','StepSources','StepState','DraftProgram','PrefixSamplingKey','PrefixSamplingProgram','SamplingFrontier','PreparedSampling'):
 target=(C/('episode_state.h' if name.startswith('Step') else 'auxiliary_programs.h')).read_text()
 a,z=struct(original,name),struct(target,name);assert a==z,name
 types.append(dict(name=name,bytes=len(a.encode()),normalized_newline_sha256=sha(a)))
runtime=[]
markers=['void initialize_draft_program(','hyle::Result<bool> recover_draft_program(','DraftProposal execute_draft(',
 'void initialize_prefix_sampling(','void recover_private_carrier(','void prepare_recursive_round_programs(',
 'PrefixSamplingResult sample_recursive_prefix(','cache::SnapshotRef sample_prefix(','void prepare_evaluations(',
 'void submit_evaluations(StepState &','bool StepState::withdrawn(']
for marker in markers:
 a,z=function(original,marker),function(candidate,marker);assert a==z,marker
 runtime.append(dict(marker=marker,complete_method_bytes=len(a.encode()),normalized_newline_sha256=sha(a)))
def project(s,kind):
 if kind=='draft':
  s=s[s.index('auto prepared = std::make_unique<DraftProgram>();'):s.index('    program.guard.execution.configure')]
  s=s.replace('    // No reliable auxiliary-use hint: Auto retains the original Commands path.\n    program.replay_mode = !selected_sampler.modifiers.history.empty() && head ? g::ReplayMode::kCommands\n        : select_replay_mode(replay_policy, 1, selected_sampler.enabled);','    program.replay_mode = build_request.replay_mode;')
  s=s.replace('      const bool subset = prepare_draft_vocabulary(selected_sampler);\n','')
  s=s.replace('draft_scores(recipe, selected, subset)','draft_scores(recipe, selected, draft_facts.projection)')
  s=s.replace('f(1)})})[1], subset);','f(1)})})[1], draft_facts.projection);')
  for name in ('hidden_slots','active_sequences','candidate_boundaries'):s=s.replace('cache_plan.'+name,'draft_facts.'+name)
  s=s.replace('min_draft_probability()','build_request.minimum_probability')
  s=s.replace('    input_scratch.draft_positions.reserve(rows);\n','')
 elif kind=='prefix':
  s=s[s.index('auto prepared = std::make_unique<PrefixSamplingProgram>();'):s.index('    initialize_prefix_sampling(program);')]
  s=s.replace('      input_scratch.sampling_identities.reserve(take(program.identity_values.description.required_bytes()) / sizeof(std::uint32_t));\n','')
 else:s=s[s.index('auto prepared = std::make_unique<SamplingFrontier>();'):s.index('        entry->frontier = std::move(prepared);')]
 s=s.replace('caller_tensor(','auxiliary_tensor(allocation_budget, ')
 s=s.replace('record_execution_plan(compiled_program.report, assembly.constants());','const auto plan = inspect_execution_plan(execution, model.cpu_ffn_layers, compiled_program.report, assembly.constants());')
 return normalized(s)
body_rows=[]
for kind,method,factory,type_name in [('draft','void prepare_draft_program(','build_draft_program(','DraftProgram'),('prefix','void prepare_prefix_sampling(','build_prefix_sampling(','PrefixSamplingProgram'),('frontier','void prepare_sampling_frontier(','build_sampling_frontier(','SamplingFrontier')]:
 a=project(function(original,method),kind);z=function(aux,factory);z=z[z.index('auto prepared = std::make_unique<'+type_name+'>();'):z.rindex('  return {std::move(prepared), plan};')];z=normalized(z)
 if a!=z:
  print('\n'.join(difflib.unified_diff(a.splitlines(),z.splitlines(),fromfile=kind+' original projection',tofile='factory')));raise AssertionError(kind)
 body_rows.append(dict(kind=kind,full_projected_cold_body_bytes=len(a.encode()),normalized_newline_sha256=sha(a),exact_projection=True))
assert 'return Tensor(resource, description, caller, allocation_budget);' in function(original,'Tensor caller_tensor(')
assert 'return Tensor(resource, description, caller, budget);' in function(aux,'Tensor auxiliary_tensor(')
for name in ('initialize_draft_program','initialize_prefix_sampling','recover_private_carrier'):
 assert name not in aux
for pattern in (r'\bguard\b',r'\binput_scratch\b',r'\bModel\b',r'\bSession\b',r'\bScope\b',r'carrier\.initialize',r'\.submit\('):
 assert not re.search(pattern,masked(aux)),pattern
old_cc=(W/'superseded-facts-f67/candidate/engine/models/qwen35/auxiliary_programs.cc').read_bytes();old_h=(W/'superseded-facts-f67/candidate/engine/models/qwen35/auxiliary_programs.h').read_bytes()
assert re.sub(rb'\bdraft_facts\b',b'facts',(C/'auxiliary_programs.cc').read_bytes())==old_cc
assert re.sub(rb'\bdraft_facts\b',b'facts',(C/'auxiliary_programs.h').read_bytes())==old_h
report=dict(status='STATIC_INDEPENDENT_PASS_NO_CXX_NATIVE',reviewer='bridge_evidence',source_base_main_sha256=hashlib.sha256((R/'engine/models/qwen35/main.cc').read_bytes()).hexdigest(),
 candidate_patch=dict(bytes=(W/'auxiliary-cold-programs.patch').stat().st_size,sha256=hashlib.sha256((W/'auxiliary-cold-programs.patch').read_bytes()).hexdigest()),
 complete_runtime_methods=runtime,complete_runtime_total_bytes=sum(i['complete_method_bytes'] for i in runtime),exact_original_layouts=types,cold_bodies=body_rows,
 fixed_findings=['Outer DraftProgramFacts parameter shadowed original two inner facts locals (/W4 /WX C4457); latest draft_facts inverse is byte-exact and resolves it.',
 'Initial producer runtime proof stopped at default-argument {} for four methods; this review independently balances full parameters then full bodies. All11actual methods match.'],
 boundary_review=['Original stable unique_ptr allocation precedes graph construction; no returned program-object move or second owner. Eight declarations retain field/destruction order.',
 'Factories only prepare original Graph/family/carrier/IO/slots and synchronously inspect constants before moving literals. No guard access/initialize/submit/recovery or Model/Session/Scope parameter.',
 'Caller retains prep latch, validation, keys, prepare_cache/optional projection, shared scratch, draft guard, initialize and final publication. Sampling frontier loop/skip/entry ownership remain Model-local.',
 'Physical Tensor constructor budget/resource/caller and all ProgramIo ports/fixed/readback/seal/transactions are preserved in the independently exact cold projections.'],
 explicit_semantic_limits=['Optional draft head may become ready earlier than original local graph and survives later failed preparation as originally permitted cold cache; no partial program map publication.',
 'Shared scratch reserve and Model workspace diagnostic merge occur after complete factory success; failure precedence/retained diagnostic peak are intentionally not byte-identical.',
 'episode_state.h remains runtime-state dependency with original embedded StepState; this is not total cold purity or private ABI isolation.',
 'Source-only review; no compiler/link/native/numerical/performance claim. Finite default/stochastic/conditional/history/retry/retirement checks remain necessary.'])
(W/'independent-review-bridge.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],runtime_methods=len(runtime),complete_runtime_bytes=report['complete_runtime_total_bytes'],types=len(types),cold_bodies=len(body_rows),patch=report['candidate_patch'])))
