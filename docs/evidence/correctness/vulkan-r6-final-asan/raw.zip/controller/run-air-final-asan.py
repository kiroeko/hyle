from pathlib import Path
import hashlib, json, os, shutil, subprocess, time
r=Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source=r/'native-a1329dd2'
build=r/'host-asan-a41d43d5'
logs=r/'logs/host-asan-a41d43d5'
logs.mkdir(parents=True, exist_ok=True)
commit='a41d43d531365a1fb8617d60113b37924e9a9864'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
env=os.environ.copy()
env['PATH']='/opt/homebrew/bin:'+env['PATH']
env['CMAKE_BUILD_PARALLEL_LEVEL']='2'
env['CTEST_PARALLEL_LEVEL']='1'
env['ASAN_OPTIONS']='halt_on_error=1'
env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
env['TSAN_OPTIONS']='halt_on_error=1'
for name in ('DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH','MLX_METAL_PATH'):
    env.pop(name,None)
env['DYLD_LIBRARY_PATH']='/opt/homebrew/opt/vulkan-loader/lib'
env['VK_LOADER_LAYERS_DISABLE']='~implicit~'
env['HYLE_VULKAN_VALIDATION']='0'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,args,directory,timeout=1800):
    print(label,flush=True)
    start=time.monotonic()
    with (directory/(label+'.log')).open('w') as log:
        p=subprocess.run([str(x) for x in args],cwd=source,env=env,
                         stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    print(label+': rc='+str(p.returncode)+' seconds='+str(round(time.monotonic()-start,2)),flush=True)
    if p.returncode:
        print((directory/(label+'.log')).read_text()[-12000:],flush=True)
    p.check_returncode()
for sanitizer,flag in (('asan','address'),):
    d=logs/sanitizer
    assert not d.exists(),'finite sanitizer attempt already has evidence; inspect before resuming'
    d.mkdir()
    run('configure',['/opt/homebrew/bin/cmake','-S',source,'-B',build,'-G','Ninja',
        '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
        '-DCMAKE_OSX_DEPLOYMENT_TARGET=14.4','-DHYLE_DEV_FACTORS=compute_route_vulkan;graph_route_vulkan',
        '-DHYLE_COMPUTE_CPU=OFF','-DHYLE_COMPUTE_CUDA=OFF','-DHYLE_COMPUTE_VULKAN=ON',
        '-DHYLE_STATIC=ON','-DHYLE_INSTALL=OFF','-DHYLE_BUILD_TESTS=ON',
        '-DHYLE_BUILD_BENCH=OFF','-DHYLE_WERROR=ON','-DHYLE_SANITIZER='+sanitizer,
        '-DFETCHCONTENT_FULLY_DISCONNECTED=ON','-DHYLE_VULKAN_GLSLANG=/opt/homebrew/bin/glslangValidator'],d)
    run('build',['/opt/homebrew/bin/cmake','--build',build,'--parallel','2','--target',
        'hyle_compute_route_vulkan_tests','hyle_graph_route_vulkan_tests'],d)
    commands=json.loads((build/'compile_commands.json').read_text())
    own=[x for x in commands if any('/'+p+'/' in x['file'] for p in (
        'src/compute_route_vulkan','src/graph_route_vulkan',
        'tests/compute_route_vulkan','tests/graph_route_vulkan'))]
    assert len(own)>=11,own
    assert all('-fsanitize='+flag in x['command'] for x in own)
    (d/'instrumented-commands.json').write_text(json.dumps(own,indent=2)+'\n')
    shutil.copyfile(build/'CMakeCache.txt',d/'CMakeCache.txt')
    record={'candidate':commit,'sanitizer':sanitizer,'scope':'HYLE host C++ and tests; Vulkan loader/driver and GPU uninstrumented',
        'instrumented_own_units':len(own),'native_vulkan_driver_instrumented':False,
        'commands_sha256':sha(build/'compile_commands.json'),
        'artifacts':{p.name:sha(p) for p in (build/'bin/hyle_compute_route_vulkan_test',build/'bin/hyle_graph_route_vulkan_test')},
        'result':'RUNNING'}
    (d/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    run('ctest',['/opt/homebrew/bin/ctest','--test-dir',build,'--output-on-failure',
        '--no-tests=error','--timeout','120','-L','^(compute_route_vulkan|graph_route_vulkan)$','-LE','headers'],d,timeout=300)
    shutil.copyfile(build/'Testing/Temporary/LastTest.log',d/'LastTest.log')
    record['result']='PASS'
    record['logs']={p.name:sha(p) for p in d.glob('*.log')}
    (d/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    print(sanitizer+' PASS',flush=True)
print('PASS final candidate HYLE host ASan; earlier unchanged UBSan/TSan paths retain their own evidence',flush=True)
