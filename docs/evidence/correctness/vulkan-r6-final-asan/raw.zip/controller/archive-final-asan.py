"""Retain only the completed final R6 HYLE-host ASan evidence."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

root = Path('/Users/kiro/hyle-verify/r6-vulkan-20260917')
source = root / 'native-a1329dd2'
logs = root / 'logs/host-asan-a41d43d5/asan'
build = root / 'host-asan-a41d43d5'
candidate = 'a41d43d531365a1fb8617d60113b37924e9a9864'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == candidate
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
assert subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip() == 'Mac16,12'
receipt = json.loads((logs / 'receipt.json').read_text(encoding='utf-8'))
assert receipt['result'] == 'PASS' and receipt['sanitizer'] == 'asan'
assert receipt['candidate'] == candidate
assert receipt['native_vulkan_driver_instrumented'] is False
commands = json.loads((logs / 'instrumented-commands.json').read_text(encoding='utf-8'))
assert len(commands) == receipt['instrumented_own_units'] == 12
assert all('-fsanitize=address' in row['command'] for row in commands)
ctest = (logs / 'ctest.log').read_text(encoding='utf-8')
assert '100% tests passed, 0 tests failed out of 2' in ctest
last = (logs / 'LastTest.log').read_text(encoding='utf-8')
counts = [int(x) for x in re.findall(r'\[\s+PASSED\s+\]\s+(\d+) tests?\.', last)]
assert sorted(counts) == [3, 14], counts


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(build / 'compile_commands.json') == receipt['commands_sha256']
for name, digest in receipt['artifacts'].items():
    assert sha(build / 'bin' / name) == digest, name
for name, digest in receipt['logs'].items():
    assert sha(logs / name) == digest, name
files = {'logs/' + p.name: p for p in logs.iterdir() if p.is_file()}
files['build/compile_commands.json'] = build / 'compile_commands.json'
for name in ('run-air-final-asan.py', 'archive-final-asan.py'):
    files['controller/' + name] = root / name
entries = {name: {'source': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}
           for name, p in sorted(files.items())}
output = root / 'archive-final-asan-a41d43d5'
output.mkdir(exist_ok=False)
with zipfile.ZipFile(output / 'raw.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name, p in sorted(files.items()):
        z.write(p, name)
    z.writestr('archive-manifest.json', json.dumps(entries, indent=2) + '\n')
with zipfile.ZipFile(output / 'raw.zip') as z:
    for name, item in entries.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == item['sha256']
identity = {'product_candidate': '8e45b10423686a0753aaa9d461c4ef3b117412c5',
    'verification_snapshot': candidate, 'host': 'Mac16,12 / M1-MAC',
    'result': 'PASS', 'sanitizer': 'ASan', 'gtest_cases': 17, 'ctest_programs': 2,
    'instrumented_own_units': len(commands),
    'scope': 'HYLE host implementation and tests; external loader/driver/GPU uninstrumented',
    'archive': {'file': 'raw.zip', 'sha256': sha(output / 'raw.zip'),
                'entries': len(entries), 'per_entry_integrity': 'PASS'}}
(output / 'identity.json').write_bytes((json.dumps(identity, indent=2) + '\n').encode())
print(json.dumps(identity, indent=2), flush=True)
