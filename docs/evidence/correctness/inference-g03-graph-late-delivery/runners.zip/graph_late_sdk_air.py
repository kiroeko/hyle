from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile

base=Path('/Users/kiro/hyle-scratch/compute-unified');canonical=base/'source-c8874688'
out=base/'g03-graph-late-sdk';out.mkdir(exist_ok=True)
identity={k:subprocess.check_output(a,text=True).strip() for k,a in [
    ('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),
    ('compiler',['xcrun','clang++','--version']),('memory',['sysctl','-n','hw.memsize'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
assert canonical.is_dir() and not (canonical/'.git').exists()
with zipfile.ZipFile(out/sys.argv[1]) as archive:
    inputs=json.loads(archive.read('source-manifest.json'))
    for item in inputs:
        path=Path(item['path']);assert not path.is_absolute() and '..' not in path.parts
        data=archive.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
        target=canonical/path
        if not target.exists() or target.read_bytes()!=data:
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
digest=hashlib.sha256(json.dumps(inputs,sort_keys=True).encode()).hexdigest()
rows=json.loads((out/'result.json').read_bytes())['stages'] if (out/'result.json').exists() else []
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']

def run(route,mode,stage,args):
    attempt=1+sum(r['route']==route and r['mode']==mode and r['stage']==stage for r in rows)
    log=out/f'{route}-{mode}-{stage}-{attempt}.log';start=time.monotonic()
    with log.open('w') as handle:
        process=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
        (out/'job.json').write_text(json.dumps(dict(state='RUNNING',route=route,mode=mode,stage=stage,pid=process.pid,log=str(log))))
        print('RUN',route,mode,stage,process.pid,flush=True);code=process.wait()
    row=dict(route=route,mode=mode,stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,input_manifest_sha256=digest,log=str(log));rows.append(row)
    (out/'result.json').write_text(json.dumps(dict(scope='G03 GL01-04 installed relocated public graph consumers and standalone headers; no repository headers/internal hooks, no new mathematics/P1/full model',identity=identity,inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
    (out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code)))
    print(json.dumps(row),flush=True)
    if code:print(log.read_text(errors='replace')[-6500:],flush=True);raise SystemExit(code)

def done(route,mode,stage):
    return any(r['route']==route and r['mode']==mode and r['stage']==stage and r['input_manifest_sha256']==digest and r['exit_code']==0 for r in rows)

for route in ['apple','vulkan']:
    if len(sys.argv)>2 and sys.argv[2]!='all' and sys.argv[2]!=route:continue
    for mode in ['static','shared']:
        if len(sys.argv)>3 and sys.argv[3]!='all' and sys.argv[3]!=mode:continue
        producer=base/f'a-cpu-{route}/selected-graph/{mode}-sdk-build'
        cache=(producer/'CMakeCache.txt').read_text()
        assert f'CMAKE_HOME_DIRECTORY:INTERNAL={canonical}' in cache and 'HYLE_SANITIZER:STRING=off' in cache
        folder=out/f'{route}-{mode}-{digest[:12]}';folder.mkdir(exist_ok=True)
        staging=folder/'staging';prefix=folder/'relocated';source=folder/'consumer';source.mkdir(exist_ok=True);build=folder/'build'
        targets=['hyle_compute','hyle_compute_batch','hyle_graph','hyle_graph_batch',f'hyle_compute_route_{route}',f'hyle_graph_route_{route}',f'hyle_graph_route_cpu_{route}']
        if not done(route,mode,'producer-build'):
            run(route,mode,'producer-build',['/opt/homebrew/bin/cmake','--build',str(producer),'--target',*targets,'--parallel','4'])
        if not prefix.exists():
            run(route,mode,'install',['/opt/homebrew/bin/cmake','--install',str(producer),'--prefix',str(staging)])
            staging.rename(prefix)
        assert not staging.exists()
        public=['compute/apple_memory.h' if route=='apple' else 'compute/vulkan_memory.h','compute/detail/copy_outcome_source.h','graph/batch.h',f'graph/cpu_{route}.h']
        for name in public:
            assert (prefix/'include/hyle'/name).read_bytes()==(canonical/'include/hyle'/name).read_bytes(),name
        for name in ['pending_paged_receiver_cpu_consumer.cc','pending_paged_receiver_native_consumer.cc']:
            (source/name).write_bytes((canonical/'tests/compute_batch'/name).read_bytes())
        headers=['graph/batch.h',f'graph/cpu_{route}.h',f'compute/{route}_memory.h','compute/detail/copy_outcome_source.h']
        for i,name in enumerate(headers):(source/f'header-{i}.cc').write_text(f'#include <hyle/{name}>\n')
        body='''cmake_minimum_required(VERSION 3.25)
project(g03_graph_late_sdk LANGUAGES CXX)
find_package(Hyle CONFIG REQUIRED COMPONENTS graph)
add_executable(cpu pending_paged_receiver_cpu_consumer.cc)
target_compile_definitions(cpu PRIVATE HYLE_PENDING_GRAPH_RECEIVER=1)
add_executable(native pending_paged_receiver_native_consumer.cc)
add_executable(joint pending_paged_receiver_native_consumer.cc)
add_executable(reduction pending_paged_receiver_native_consumer.cc)
target_compile_definitions(joint PRIVATE HYLE_PENDING_NATIVE_JOINT_GRAPH=1)
target_compile_definitions(reduction PRIVATE HYLE_PENDING_NATIVE_COPY_REDUCTION=1)
add_library(headers OBJECT header-0.cc header-1.cc header-2.cc header-3.cc)
foreach(t native joint reduction)
 target_compile_definitions(${t} PRIVATE HYLE_PENDING_NATIVE_RESULT_SOURCE=1)
endforeach()
foreach(t cpu native joint reduction headers)
 target_compile_features(${t} PRIVATE cxx_std_23)
 target_compile_options(${t} PRIVATE -Wall -Wextra -Wpedantic -Werror)
 target_link_libraries(${t} PRIVATE hyle::graph)
endforeach()
foreach(t cpu native joint reduction)
 hyle_stage_runtime(${t})
endforeach()
'''
        if route=='apple':body+='foreach(t native joint reduction)\n target_compile_definitions(${t} PRIVATE HYLE_PENDING_RECEIVER_APPLE=1)\nendforeach()\n'
        cmake=source/'CMakeLists.txt'
        if not cmake.exists() or cmake.read_text()!=body:cmake.write_text(body)
        (folder/'public-inputs.json').write_text(json.dumps(dict(headers=[dict(path=n,sha256=hashlib.sha256((prefix/'include/hyle'/n).read_bytes()).hexdigest()) for n in headers],consumers=[dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in source.glob('*.cc')]),indent=2)+'\n')
        for stage,args in [
            ('configure',['/opt/homebrew/bin/cmake','-S',str(source),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']),
            ('consumer-build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','cpu','native','joint','reduction','headers','--parallel','4'])]:
            if not done(route,mode,stage):run(route,mode,stage,args)
        commands=json.loads((build/'compile_commands.json').read_bytes())
        assert len(commands)==8
        for item in commands:
            assert str(canonical) not in item['command'] and str(producer) not in item['command'] and str(prefix/'include') in item['command'],item['command']
        (out/f'{route}-{mode}-public-compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        for name in ['cpu','native','joint','reduction']:
            if not done(route,mode,name):run(route,mode,name,[str(build/name)])
        libraries=[p for p in (prefix/'lib').rglob('*') if p.is_file() and p.suffix in ['.a','.dylib'] and p.name.startswith('libhyle')]
        assert libraries
        assert any(p.name=='libhyle_graph_batch.a' for p in libraries) if mode=='static' else any(p.name.startswith('libhyle_graph_batch.') and p.suffix=='.dylib' for p in libraries)
        (out/f'{route}-{mode}-artifacts.json').write_text(json.dumps([dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in libraries],indent=2)+'\n')
print('SDK selected profiles terminal; inspect complete matrix before acceptance',flush=True)
