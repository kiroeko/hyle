from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path.cwd();task=root/'.scratch/inference-gaps/g03'
out=root/'evidence/correctness/inference-g03-graph-late-delivery';out.mkdir(exist_ok=True)
sdk=json.loads((task/'graph-late-sdk/result.json').read_bytes())
latest={(r['route'],r['mode'],r['stage']):r for r in sdk['stages']}
for route in ['apple','vulkan']:
    for mode in ['static','shared']:
        for stage in ['producer-build','install','configure','consumer-build','cpu','native','joint','reduction']:
            assert latest[route,mode,stage]['exit_code']==0,(route,mode,stage)
        folder=task/'graph-late-sdk'
        commands=json.loads((folder/f'{route}-{mode}-public-compile-commands.json').read_bytes())
        assert len(commands)==8 and all('/relocated/include' in c['command'] and '/source-c8874688/' not in c['command'] for c in commands)
        shipping=json.loads((folder/f'{route}-{mode}-shipping-commands.json').read_bytes())
        assert len(shipping)==4 and all('HYLE_TESTING' not in c['command'] for c in shipping)
        count=2 if route=='apple' else 1
        for stage in ['native','joint']:
            log=(folder/Path(latest[route,mode,stage]['log']).name).read_text(encoding='utf-8')
            assert log.count('native pending receiver PASS:64')==count
        assert 'orthogonal reduction PASS:64' in (folder/Path(latest[route,mode,'reduction']['log']).name).read_text(encoding='utf-8')
for item in sdk['inputs']:
    if item['path'].startswith(('include/','src/')) or item['path'] in ['tests/compute_batch/pending_paged_receiver_cpu_consumer.cc','tests/compute_batch/pending_paged_receiver_native_consumer.cc']:
        assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
san=json.loads((task/'graph-late-sanitizers/result.json').read_bytes())
sl={(r['route'],r['mode'],r['stage']):r for r in san['stages']}
for route in ['apple','vulkan']:
    for mode in ['asan','ubsan','tsan']:
        assert sl[route,mode,'g03_gl_joint_risks']['exit_code']==0
        assert 'mode=10 final result/completion' in (task/'graph-late-sanitizers'/Path(sl[route,mode,'g03_gl_joint_risks']['log']).name).read_text(encoding='utf-8')
cuda=json.loads((task/'graph-late-cuda/result.json').read_bytes());cl={r['stage']:r for r in cuda['stages']}
assert cl['graph-risks']['exit_code']==0
log=(task/'graph-late-cuda'/Path(cl['graph-risks']['log']).name).read_text(encoding='utf-8')
assert log.count('PASS')==8
names=subprocess.check_output(['git','diff','--name-only','2bc71f56a'],text=True).splitlines()
changed=[n for n in names if n.startswith(('include/','src/','tests/'))]
for name in ['graph-late-sdk','graph-late-sanitizers','graph-late-air','graph-late-cuda']:
    with zipfile.ZipFile(out/(name+'-raw.zip'),'w',zipfile.ZIP_DEFLATED) as package:
        for path in (task/name).iterdir():
            if path.suffix in ['.json','.log']:package.write(path,path.name)
        for archive in (task/name).glob('source-*.zip'):
            with zipfile.ZipFile(archive) as old:
                for path in changed:
                    if path in old.namelist():package.writestr(archive.stem+'/'+path,old.read(path))
with zipfile.ZipFile(out/'runners.zip','w',zipfile.ZIP_DEFLATED) as package:
    for name in ['graph_late_sdk_air.py','run_graph_late_sdk_air.py','graph_late_cuda.py','run_graph_late_cuda.py','graph_late_san_air.py','run_graph_late_san_air.py','write_cuda_graph_risks.py','seal_graph_late_delivery_air.py']:
        package.write(task/name,name)
result=dict(kind='PARTIAL_GRAPH_LATE_INSTALLED_NATIVE_AND_COMMON_DELIVERY',state='AUDITED',whole_g03_completed=False,
    verified=['Apple/Vulkan relocated static/shared: public CPU Graph64, native accepted late source/F2/paged64, CPU+native Graph64 with required CPU fragments/two page nodes, independent reverse-range/reduction64 and four standalone public headers each',
        'Each SDK consumer compile command uses installed headers without canonical source or producer build paths; shipping product commands have no HYLE_TESTING',
        'New actual native joint shared metadata exhaustion refuses pending source cold owner and pending binding without consuming Update/page permissions/leaking charges; both routes source and three host sanitizer configurations pass, Apple nine/Vulkan eleven cases',
        'Actual CUDA Graph eight lifecycle cases: true gated numeric suffix/old output/page writer recovery, known/unknown/late source errors, abandonment, original CPU Queue rejection, two native cancel refusal boundaries'],
    limitations=['CUDA original native cancellation is Unimplemented. Refusal preserves accepted work and live permissions to actual retirement; not a cancellation support certificate. Requesting cancel on original Update also closes its slot, preventing successful mutable withdrawal.',
        'Readonly aliases and source range proof covered by prior risk checkpoint; independent mutable import of these native result allocations is absent from public HYLE API. Out-of-contract native mutation is not declared tested.',
        'CPU+CUDA full source/factor and installed CUDA static/shared qualification still running or unproven; old frozen archive diagnostic does not substitute.',
        'Host sanitizer model/private-driver limitations and original G01/G02 unresolved gates/G04-G10 retained'],
    failures='Original CUDA graph risk preflight required unwanted ggml CUDA closure and was refused; directed actual Queue dependency fixed. Initial cancellation assertions expected unsupported preemption; preserved original Unimplemented failures and corrected fixture to actual declared native contract. No product cancel weakening or budget reset.',
    cumulative_seconds=dict(installed_native=sdk['cumulative_seconds'],host_sanitizers=san['cumulative_seconds'],cuda_source=cuda['cumulative_seconds']),
    remaining=['CPU+CUDA full matching component archives, installed static/shared and lifecycle of required CPU/GPU fragments',
        'Finite remaining G03 gates and original G01/G02 unresolved acceptance; G04-G10 unchanged'])
(out/'validation-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result['cumulative_seconds']))
