from pathlib import Path
root=Path.cwd();source=root/'tests/compute_batch/pending_paged_receiver_cuda_risks.cc'
text=source.read_text(encoding='utf-8')
def replace(old,new):
    global text
    assert old in text,old[:80]
    text=text.replace(old,new,1)
replace('#include <hyle/compute/batch_execution.h>','#include <hyle/compute/batch_execution.h>\n#include <hyle/graph/batch.h>')
replace('namespace n=c::cuda;','namespace n=c::cuda;namespace g=hyle::graph;namespace b=g::batch;')
cap='''  const c::BatchCapacity cap{.data_type=c::DataType::kFloat16,.max_requests=1,.max_query_rows=1,.max_kv_rows=2,
      .max_pages=2,.max_page_refs=1,.query_heads=2,.kv_heads=1,.head_dim=64,.page_size=16};
  HYLE_ASSIGN_OR_RETURN(auto schema,c::BatchSchema::create(cap));
  const std::array<std::int32_t,2> ptr{0,1};const std::array<std::int32_t,1> pages{1},tail{2};
  HYLE_ASSIGN_OR_RETURN(auto layout,schema.version({ptr,ptr,pages,tail}));
'''
replace(cap,'')
replace('  HYLE_ASSIGN_OR_RETURN(auto context,c::Context::create(id,c::flashinfer::provider()));',cap+'''  HYLE_ASSIGN_OR_RETURN(auto wrapped,b::provider(c::flashinfer::provider(),schema,
      {.resource={},.host_workspace=hyle::mem::system_resource(),.max_float_workspace_bytes=8u<<20,
       .max_int_workspace_bytes=64u<<10,.max_invocations=1,.scale=.125F}));
  HYLE_ASSIGN_OR_RETURN(auto context,c::Context::create(id,wrapped));''')
replace('  HYLE_ASSIGN_OR_RETURN(auto receiver,c::PagedBatchReceiver::create(std::move(native),4));\n  HYLE_RETURN_IF_ERROR(receiver.prepare_batch(layout));','''  native={}; // Warmed original native math; Graph has its own original slot.
  HYLE_ASSIGN_OR_RETURN(auto qdesc,c::TensorDesc::dense(cap.data_type,std::array<std::int64_t,3>{1,2,64}));
  HYLE_ASSIGN_OR_RETURN(auto kvdesc,c::TensorDesc::dense(cap.data_type,std::array<std::int64_t,4>{2,16,1,64}));
  HYLE_ASSIGN_OR_RETURN(auto metadata_desc,schema.metadata_description());
  HYLE_ASSIGN_OR_RETURN(auto builder,g::GraphBuilder::create());
  const std::array descriptions{qdesc,kvdesc,kvdesc,metadata_desc};std::array<g::ValueId,4> inputs;
  for(unsigned i=0;i<4;++i){HYLE_ASSIGN_OR_RETURN(inputs[i],builder.input(descriptions[i]));}
  HYLE_ASSIGN_OR_RETURN(auto node,builder.add_node(c::Operation::custom(c::PagedAttention{cap,.125F}),inputs));
  HYLE_ASSIGN_OR_RETURN(auto output_id,builder.result(node));HYLE_RETURN_IF_ERROR(builder.publish(output_id));
  HYLE_ASSIGN_OR_RETURN(auto graph,std::move(builder).finish());
  const std::array storage{g::StorageDomain{resource}};
  const std::array targets{g::ExecutionTarget{&context,g::StorageDomainId{0}}};
  HYLE_ASSIGN_OR_RETURN(auto compiled,g::compile(graph,{.storage_domains=storage,.targets=targets},
      {.operation_fallback=g::OperationFallbackPolicy::kReject}));
  const std::array lanes{b::LaneBinding{g::ExecutionLaneId{0},&context,&queue,host.ref()}};
  const g::LeasedInvocationOptions options{.allocator=metadata.get()};
  HYLE_ASSIGN_OR_RETURN(auto original,b::Invocation::create(compiled.executable,lanes,options));
  HYLE_ASSIGN_OR_RETURN(auto receiver,b::PendingInvocation::create(std::move(original),4,options));
  const std::array versions{b::NodeLayout{node,layout}};
  HYLE_RETURN_IF_ERROR(receiver.prepare_batch(versions));''')
replace('  HYLE_ASSIGN_OR_RETURN(auto query,q.publish());','''  HYLE_ASSIGN_OR_RETURN(auto query,q.publish());
  HYLE_ASSIGN_OR_RETURN(auto output,pool.allocate(256));
  HYLE_RETURN_IF_ERROR(receiver.bind(inputs[0],qdesc,query));
  HYLE_RETURN_IF_ERROR(receiver.bind(output_id,qdesc,std::move(output)));''')
replace('  source_events.clear();recording=true;fail_source=false;','''  HYLE_RETURN_IF_ERROR(receiver.bind(inputs[1],k));HYLE_RETURN_IF_ERROR(receiver.bind(inputs[2],v));
  source_events.clear();recording=true;fail_source=false;''')
text=text.replace('receiver.submit(query,k,v,std::move(update))','receiver.submit(std::move(update))')
text=text.replace('receiver.output()','receiver.output(output_id)').replace('receiver.prepare_batch(layout)','receiver.prepare_batch(versions)')
text=text.replace('!c::BatchInvocation::create(program,queue)','!b::Invocation::create(compiled.executable,lanes,options)')
replace('    HYLE_ASSIGN_OR_RETURN(auto next,c::BatchInvocation::create(program,queue));HYLE_RETURN_IF_ERROR(next.drain());','    HYLE_ASSIGN_OR_RETURN(auto next,b::Invocation::create(compiled.executable,lanes,options));HYLE_RETURN_IF_ERROR(next.drain());')
text=text.replace('common CUDA receiver','CUDA pending Graph').replace('CUDA receiver risk=','CUDA pending Graph risk=')
replace('return n::status(cudaMemcpyAsync(src,staging,512,cudaMemcpyHostToDevice,stream));','return n::status(cudaMemcpyAsync(src,staging,512,cudaMemcpyHostToDevice,stream));')
(root/'tests/graph_batch/pending_cuda_graph_risks.cc').write_text(text,encoding='utf-8',newline='\n')
print('Created actual CUDA pending Graph lifecycle fixture using original gated source/events/math warm-up.')
