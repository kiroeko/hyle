from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688';out=base/'g03-graph-late-sanitizers';out.mkdir(exist_ok=True)
identity={k:subprocess.check_output(a,text=True).strip() for k,a in [
 ('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang++','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
assert source.is_dir() and not (source/'.git').exists()
with zipfile.ZipFile(out/sys.argv[1]) as package:
 inputs=json.loads(package.read('source-manifest.json'))
 for item in inputs:
  relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts
  data=package.read(item['path']);assert hashlib.sha256(data).hexdigest()==item['sha256']
  target=source/relative
  if not target.exists() or target.read_bytes()!=data:
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
digest=hashlib.sha256(json.dumps(inputs,sort_keys=True).encode()).hexdigest()
rows=json.loads((out/'result.json').read_bytes())['stages'] if (out/'result.json').exists() else []
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
def run(route,mode,stage,args):
 attempt=1+sum(r['route']==route and r['mode']==mode and r['stage']==stage for r in rows)
 log=out/f'{route}-{mode}-{stage}-{attempt}.log';start=time.monotonic()
 with log.open('w') as handle:
  child=subprocess.Popen(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
  (out/'job.json').write_text(json.dumps(dict(state='RUNNING',route=route,mode=mode,stage=stage,pid=child.pid,log=str(log))))
  print('RUN',route,mode,stage,child.pid,flush=True);code=child.wait()
 row=dict(route=route,mode=mode,stage=stage,command=args,exit_code=code,elapsed_seconds=time.monotonic()-start,input_manifest_sha256=digest,log=str(log));rows.append(row)
 (out/'result.json').write_text(json.dumps(dict(scope='G03 GL01-04 selected host sanitizer objects/real public source and new risks; no LSan/shader/driver/private-pool certificate; original qualified TSan host models retained',identity=identity,inputs=inputs,stages=rows,cumulative_seconds=sum(r['elapsed_seconds'] for r in rows)),indent=2)+'\n')
 (out/'job.json').write_text(json.dumps(dict(state='TERMINAL',exit_code=code)))
 print(json.dumps(row),flush=True)
 if code:print(log.read_text(errors='replace')[-7500:],flush=True);raise SystemExit(code)
for route in ['apple','vulkan']:
 if len(sys.argv)>2 and sys.argv[2]!='all' and sys.argv[2]!=route:continue
 for mode in ['asan','ubsan','tsan']:
  if len(sys.argv)>3 and sys.argv[3]!='all' and sys.argv[3]!=mode:continue
  folder=base/f'foundation-f5-native-host-{route}-{mode}';parent=folder/'parent';build=folder/'build'
  assert parent.exists() and build.exists()
  cmake=parent/'CMakeLists.txt';body=cmake.read_text()
  apple='HYLE_G01_PAGE_RISK_APPLE=1 HYLE_JOINT_PAGE_APPLE=1' if route=='apple' else ''
  native='HYLE_PENDING_NATIVE_RESULT_SOURCE=1'+(' HYLE_PENDING_RECEIVER_APPLE=1' if route=='apple' else '')
  cases=[('g03_gl_graph_risks','tests/graph_batch/pending_graph_risks.cc',''),
    ('g03_gl_source_risks','tests/compute_batch/native_result_copy_risks.cc',apple),
    ('g03_gl_joint_risks','tests/graph_batch/native_pending_joint_risks.cc',apple),
    ('g03_gl_graph64','tests/compute_batch/pending_paged_receiver_cpu_consumer.cc','HYLE_PENDING_GRAPH_RECEIVER=1'),
    ('g03_gl_source64','tests/compute_batch/pending_paged_receiver_native_consumer.cc',native),
    ('g03_gl_joint64','tests/compute_batch/pending_paged_receiver_native_consumer.cc',native+' HYLE_PENDING_NATIVE_JOINT_GRAPH=1')]
  if len(sys.argv)>4 and sys.argv[4]=='joint_risks':cases=[c for c in cases if c[0]=='g03_gl_joint_risks']
  for name,file,flags in cases:
   if f'add_executable({name} ' not in body:
    body+=f'\nadd_executable({name} {source}/{file})\ntarget_compile_features({name} PRIVATE cxx_std_23)\n'
    if flags:body+=f'target_compile_definitions({name} PRIVATE {flags})\n'
    body+=f'target_compile_options({name} PRIVATE -Wall -Wextra -Wpedantic -Werror)\ntarget_link_libraries({name} PRIVATE hyle::graph)\nhyle_apply_sanitizer({name})\nhyle_stage_runtime({name})\n'
    if mode=='tsan':
     body+=f'target_include_directories({name} BEFORE PRIVATE {base}/g02-refcount-fence-probe/tsan-headers)\n'
     if route=='apple':body+=f'target_include_directories({name} BEFORE PRIVATE {base}/g01-metal-callback-tsan-probe/tsan-metal-cpp)\n'
  if cmake.read_text()!=body:cmake.write_text(body)
  run(route,mode,'compile',['/opt/homebrew/bin/cmake','--build',str(build),'--target',*[c[0] for c in cases],'--parallel','4'])
  commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True))
  flag='-fsanitize='+dict(asan='address',ubsan='undefined',tsan='thread')[mode]
  endings=['src/graph/leased_invocation.cc','src/graph_batch/batch.cc',f'src/graph_route_cpu_{route}/invocation.cc',
       f'src/compute_route_{route}/{route}_copy_program.cc',f'src/compute_route_{route}/{route}_materialized_invocation.cc',*[c[1] for c in cases]]
  checked=[]
  for ending in set(endings):
   matches=[c for c in commands if c['file'].endswith(ending)]
   assert matches and all(flag in c['command'] for c in matches),ending;checked+=matches
  (out/f'{route}-{mode}-instrumentation.json').write_text(json.dumps(checked,indent=2)+'\n')
  if mode=='tsan':
   files=[base/'g02-refcount-fence-probe/tsan-headers/hyle/util/ref_counted.h']
   if route=='apple':files.append(base/'g01-metal-callback-tsan-probe/tsan-metal-cpp/Metal/MTLCommandBuffer.hpp')
   (out/f'{route}-{mode}-models.json').write_text(json.dumps([dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files],indent=2)+'\n')
  for name,_,_ in cases:run(route,mode,name,[str(build/name)])
