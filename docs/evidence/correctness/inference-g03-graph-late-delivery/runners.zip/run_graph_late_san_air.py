from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path.cwd();out=root/'.scratch/inference-gaps/g03/graph-late-sanitizers';out.mkdir(exist_ok=True)
attempt=1
while (out/f'source-{attempt}.zip').exists():attempt+=1
archive=out/f'source-{attempt}.zip';inputs=[]
paths=[p for p in subprocess.check_output(['git','ls-files'],text=True).splitlines() if not p.startswith(('evidence/','.scratch/','.git')) and (root/p).is_file()]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
 for path in paths:
  data=(root/path).read_bytes();inputs.append(dict(path=path,sha256=hashlib.sha256(data).hexdigest()));package.writestr(path,data)
 package.writestr('source-manifest.json',json.dumps(inputs,indent=2)+'\n')
(out/f'source-{attempt}-manifest.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8',newline='\n')
host='kiro@172.22.10.198';remote='/Users/kiro/hyle-scratch/compute-unified/g03-graph-late-sanitizers';script=root/'.scratch/inference-gaps/g03/graph_late_san_air.py'
options=['-o','BatchMode=yes','-o','ConnectTimeout=12']
subprocess.run(['ssh',*options,host,'mkdir -p '+remote],check=True)
subprocess.run(['scp',*options,str(archive),str(script),f'{host}:{remote}/'],check=True)
route=sys.argv[1] if len(sys.argv)>1 else 'all';mode=sys.argv[2] if len(sys.argv)>2 else 'all'
assert route in ('all','apple','vulkan') and mode in ('all','asan','ubsan','tsan')
selection=sys.argv[3] if len(sys.argv)>3 else 'all'
assert selection in ['all','joint_risks']
code=subprocess.run(['ssh',*options,host,f'python3 {remote}/{script.name} {archive.name} {route} {mode} {selection}']).returncode
for name in ['result.json','job.json']:
 subprocess.run(['scp',*options,f'{host}:{remote}/{name}',str(out/name)],check=True)
raise SystemExit(code)
