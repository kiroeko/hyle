from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

host, profile, mode, candidate = sys.argv[1:]
assert host in ['wsl', 'air'] and mode in ['static', 'shared'] and len(candidate) == 40
assert profile in (['cpu-cuda', 'vulkan'] if host == 'wsl' else ['cpu-apple', 'vulkan'])
base = Path('/root/hyle-scratch/compute-unified' if host == 'wsl' else '/Users/kiro/hyle-scratch/compute-unified')
source = base / ('source-7a7b4c3b' if host == 'wsl' else 'source-c8874688')
assert candidate in (source / 'SOURCE-MANIFEST.txt').read_text()
producer = base / (('l-' if host == 'wsl' else 'a-') + profile) / 'selected-graph' / (mode + '-sdk-build')
cache = (producer / 'CMakeCache.txt').read_text()
assert 'HYLE_STATIC:BOOL=' + ('ON' if mode == 'static' else 'OFF') in cache
root = base / ('foundation-f3-sdk-' + profile + '-' + mode + '-' + candidate[:9]); assert not root.exists(); root.mkdir()
stage, prefix, consumer, headers = [root / name for name in ['staging', 'relocated', 'consumer', 'headers']]
env = os.environ.copy()
if host == 'wsl':
    cmake = '/usr/bin/cmake'; compiler = '/usr/bin/g++-14'
    env['PATH'] = '/usr/local/cuda-13.3/bin:/usr/lib/wsl/lib:/usr/bin:/bin:/usr/sbin:/sbin'
    env.update(CUDA_HOME='/usr/local/cuda-13.3', CUDA_PATH='/usr/local/cuda-13.3', CUDAToolkit_ROOT='/usr/local/cuda-13.3', CUDACXX='/usr/local/cuda-13.3/bin/nvcc')
    identity = {'os': subprocess.check_output(['uname', '-a'], text=True), 'compiler': subprocess.check_output([compiler, '--version'], text=True)}
else:
    cmake = '/opt/homebrew/bin/cmake'; compiler = '/usr/bin/clang++'
    env['PATH'] = '/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    identity = {name: subprocess.check_output(command, text=True, env=env).strip() for name, command in [
        ('hardware', ['sysctl', '-n', 'hw.model']), ('os', ['sw_vers']), ('compiler', [compiler, '--version'])]}
    assert identity['hardware'] == 'Mac16,12'
routes = profile.replace('-', ';')
record = {'candidate': candidate, 'source': str(source), 'producer': str(producer), 'host': host,
          'profile': profile, 'mode': mode, 'identity': identity, 'parallel': 1,
          'scope': 'F3 ordinary relocated installed Graph file/GGUF/Qwen consumer and changed ON/OFF headers only', 'stages': []}
def available():
    if host == 'wsl': return int(re.search(r'MemAvailable:\s+(\d+)', Path('/proc/meminfo').read_text()).group(1)) * 1024
    page = int(subprocess.check_output(['sysctl', '-n', 'hw.pagesize'], text=True, env=env))
    stats = subprocess.check_output(['vm_stat'], text=True, env=env)
    return page * sum(int(re.search(r'Pages ' + name + r':\s*(\d+)', stats).group(1)) for name in ['free', 'inactive', 'speculative'])
def run(name, command, timeout=300, expected_failure=False):
    free = available(); assert free >= 4 * 1024**3, free
    if '--parallel' in command:
        parallel = 4 if free >= 12 * 1024**3 else 2 if free >= 8 * 1024**3 else 1
        command = list(command); command[command.index('--parallel') + 1] = str(parallel)
        record['parallel'] = parallel; record['test_parallel'] = 1
    log = root / (name + '.log')
    runtime = env.copy()
    if host == 'air' and mode == 'shared' and name in ['math', 'qwen']:
        runtime['DYLD_PRINT_LIBRARIES'] = '1'
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=source, env=runtime, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        row = {'name': name, 'command': command, 'pid': process.pid, 'state': 'running', 'available_bytes': free, 'log': log.name}
        record['stages'].append(row); (root / 'job.json').write_text(json.dumps(record, indent=2))
        try: code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(process.pid, signal.SIGKILL); process.wait(); row.update(state='terminal', verdict='TIMEOUT')
            (root / 'job.json').write_text(json.dumps(record, indent=2)); raise
        passed = code != 0 if expected_failure else code == 0
        row.update(state='terminal', exit_code=code, verdict=('PASS_EXPECTED_ABSENT' if expected_failure else 'PASS') if passed else 'FAIL', sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        (root / 'job.json').write_text(json.dumps(record, indent=2))
    print(name, code, flush=True)
    if not passed: raise SystemExit(code or 1)
    output_text = log.read_text()
    if host == 'air' and mode == 'shared' and name in ['math', 'qwen']:
        hyle_rows = [line for line in output_text.splitlines() if '/libhyle_' in line]
        assert hyle_rows and all(str(prefix / 'lib') in line for line in hyle_rows)
        record.setdefault('actual_dyld', {})[name] = hyle_rows
    return output_text
run('configure', [cmake, '-S', str(source), '-B', str(producer), '-DHYLE_BUILD_TESTS=OFF', '-DHYLE_INSTALL=ON', '-DHYLE_COMPONENTS=graph', '-DHYLE_COMPUTE_ROUTES=' + routes])
run('producer', [cmake, '--build', str(producer), '--parallel', '1'], 1800)
run('install', [cmake, '--install', str(producer), '--prefix', str(stage)], 600)
for path in [stage, prefix]: assert path.resolve().parent == root.resolve() and path.resolve().is_relative_to(base.resolve())
assert stage.exists() and not prefix.exists(); stage.rename(prefix)
for path in (prefix / 'lib/cmake/Hyle').rglob('*.cmake'):
    text = path.read_text(); assert all(str(value) not in text for value in [source, producer, stage]), path
record['relocation'] = {'original': str(stage), 'relocated': str(prefix), 'original_absent': not stage.exists(), 'Hyle_metadata_no_source_build_staging_paths': True}
run('consumer-configure', [cmake, '-S', str(source / 'samples/package/graph/file_streaming'), '-B', str(consumer), '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=' + compiler, '-DCMAKE_PREFIX_PATH=' + str(prefix), '-DHYLE_COMPUTE_ROUTES=' + routes])
run('consumer-build', [cmake, '--build', str(consumer), '--parallel', '1'], 1800)
if host == 'wsl' and profile == 'vulkan':
    record['gpu_math'] = 'NOT_APPLICABLE: actual WSL physical devices are software llvmpipe, no qualified native GPU. Installed consumer build/header/package/relocation gates remain applicable.'
else:
    run('math', [str(consumer / 'hyle_file_streaming_sample'), str(base / 'foundation-f3-gguf-input/gguf-ranges.tsv')], 180)
    run('qwen', [str(consumer / 'hyle_file_streaming_qwen'), str(base / 'foundation-f3-qwen-input/ranges.tsv')], 180)
for target in ['hyle_file_streaming_sample', 'hyle_file_streaming_qwen']:
    if host == 'wsl':
        linked = run('dependencies-' + target, ['/usr/bin/ldd', str(consumer / target)], 30)
        assert 'not found' not in linked
        if mode == 'shared':
            hyle_rows = [line for line in linked.splitlines() if 'libhyle_' in line]
            assert hyle_rows and all(str(prefix / 'lib') in line for line in hyle_rows)
    else:
        run('dependencies-' + target, ['/usr/bin/otool', '-L', str(consumer / target)], 30)
route_headers = {'cpu': 'cpu.h', 'cuda': 'backends/cuda.h', 'apple': 'apple_memory.h', 'vulkan': 'vulkan_memory.h'}
selected_routes = routes.split(';')
names = ['file_stream.h', 'detail/file_stream_access.h', 'detail/file_stream_copy.h', 'detail/copy_stream_access.h',
         'detail/lease_access.h'] + [route_headers[name] for name in selected_routes]
headers.mkdir(); files = []
for index, name in enumerate(names):
    path = headers / ('header-' + str(index) + '.cc'); path.write_text('#include <hyle/compute/' + name + '>\n'); files.append('"' + str(path) + '"')
(headers / 'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.25)\nproject(hyle_f3_headers LANGUAGES CXX)\n'
    'set(HYLE_COMPUTE_ROUTES "' + routes + '")\nfind_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph)\n'
    'add_library(headers OBJECT ' + ' '.join(files) + ')\ntarget_link_libraries(headers PRIVATE hyle::graph)\n')
header_build = root / 'header-build'
run('headers-configure', [cmake, '-S', str(headers), '-B', str(header_build), '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
    '-DCMAKE_CXX_COMPILER=' + compiler, '-DCMAKE_PREFIX_PATH=' + str(prefix)])
run('headers-build', [cmake, '--build', str(header_build), '--parallel', '1'], 300)
record['header_scope'] = {'count': len(names), 'routes': routes, 'source_include_directory_requested': False}
for route, header in route_headers.items():
    if route in selected_routes: continue
    assert not (prefix / 'include/hyle/compute' / header).exists()
    probe = root / ('absence-' + route); probe.mkdir()
    (probe / 'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.25)\nproject(hyle_absence LANGUAGES CXX)\n'
        'set(HYLE_COMPUTE_ROUTES "' + route + '")\nfind_package(Hyle 0.1.0 EXACT REQUIRED COMPONENTS graph)\n')
    output = run('absence-route-' + route, [cmake, '-S', str(probe), '-B', str(root / ('absence-build-' + route)), '-G', 'Ninja',
        '-DCMAKE_CXX_COMPILER=' + compiler, '-DCMAKE_PREFIX_PATH=' + str(prefix)], 300, True)
    assert "does not contain requested compute route '" + route + "'" in ' '.join(output.lower().split())
record['absent_headers_and_route_diagnostics'] = [name for name in route_headers if name not in selected_routes]
record['verdict'] = 'PASS_F3_' + host.upper() + '_' + profile.upper().replace('-', '_') + '_' + mode.upper() + '_RELOCATED_SDK_ONLY'
(root / 'job.json').write_text(json.dumps(record, indent=2)); print(str(root), flush=True)
