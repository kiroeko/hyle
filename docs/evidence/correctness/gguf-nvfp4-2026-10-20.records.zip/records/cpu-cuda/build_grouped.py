"""One native metadata TU + version owner + strengthened existing test TU."""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys
sys.dont_write_bytecode=True
STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('nvfp4_prior_builder',STAGE/'build_cuda.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
b,c=old.b,old.c
ROOT,ARCH=old.ROOT,old.ARCH
BASE=STAGE/'checks/20261019T201144'
COMMON=STAGE.parent/'windows-host/checks/20261019T201048'


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--build',action='store_true');args=p.parse_args()
    out=STAGE/'checks'/(dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-grouped-fix')
    out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
    owners=c.read(COMMON/'common-objects-ready.json')['owners']
    provider=next(r for r in owners if c.key(r['source']['path'])==c.key(ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc'))
    native=c.read(BASE/'native-main-identity.json');test=c.read(BASE/'nvfp4-test-identity.json')
    specs=[('native-mmid','native',native,STAGE/'native-source/src/ggml-cuda/mmid.cu',None),
        ('provider','host',provider,ROOT/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',provider['object']),
        ('nvfp4-test','host',test,ROOT/'tests/graph_route_cuda/gguf_nvfp4_test.cc',test['object'])]
    frozen=[b.identity(x) for x in [Path(__file__),STAGE/'build_cuda.py',STAGE/'native-source-freeze.json',
        STAGE/'cuda-host-source-freeze.json',STAGE/'provider-version.h',STAGE/'grouped-application.json',
        ROOT/'third_party/ggml_cuda_runtime/patches.json',ROOT/'third_party/ggml_cuda_runtime/NOTICE.md',ROOT/'cmake/HyleDependencyLock.json']]
    frozen.extend(b.identity(x) for x in (STAGE/'native-source').rglob('*') if x.is_file())
    rows=[]
    for tag,kind,recipe,source,previous in specs:
        if kind=='native':
            command=old.h.h.a.strip_ccbin(b.native_command(old.h.h.a.strip_ccbin(recipe['command']),source,tag,out))
        else:
            template=['/FI'+str(STAGE/'provider-version.h') if x.lower().startswith('/fi') else x for x in recipe['command']]
            command=b.host_command(template,source,tag,out)
            frozen.extend(b.identity(x) for x in b.host_dependencies(template))
        rows.append(dict(tag=tag,kind=kind,source=b.identity(source),command=command,object=str(out/(tag+'.obj')),old_object=previous))
        frozen.append(b.identity(source));snap=out/'compiled-source'/source.relative_to(ROOT);snap.parent.mkdir(parents=True,exist_ok=True);snap.write_bytes(source.read_bytes());frozen.append(b.identity(snap))
    qwen=c.read(BASE/'qwen-link-plan.json');cuda=c.read(BASE/'nvfp4-link-plan.json')
    cached={c.key(r['path']):r for r in [*qwen['inputs'],*cuda['inputs']]}
    replacements={c.key(r['old_object']['path']):r['object'] for r in rows if r['old_object']}
    assert set(replacements)<=set(cached)
    links={}
    for arm,base in [('qwen',qwen),('nvfp4',cuda)]:
        command=[replacements.get(c.key(x),x) for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command.insert(1,rows[0]['object']);image=out/(arm+'.exe')
        command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[x for x in command if Path(x).is_absolute() and x.lower().endswith(('.lib','.obj')) and not x.startswith('/')]
        assert len(inputs)==len(set(map(c.key,inputs)))
        links[arm]=dict(command=command,inputs=inputs,image=str(image))
    plan=dict(compile=rows,links=links,frozen=list({c.key(x['path']):x for x in frozen}.values()),cached_inputs=list(cached.values()),
        previous_plan=b.identity(BASE/'plan-fixture-correction.json'),source_id=c.read(STAGE/'native-source-freeze.json')['source_id'],
        native_TUs=1,host_TUs=2,SDK_build=False,GPU_run=False)
    path=out/'plan.json';c.save(path,plan);print('PLAN',path,flush=True)
    if not args.build:return
    def check():
        for x in plan['frozen']:assert b.same(x),x['path']
    check()
    for x in cached.values():assert b.same(x),x['path']
    env,_=b.environment(links['qwen']['command'],[x['path'] for x in cached.values()],out)
    for row in rows:
        c.execute(row['tag']+'-compile-1',row['command'],env,out);check()
        if row['kind']=='host':
            deps=c.read(out/(row['tag']+'-deps.json'))['Data'];deps=[b.identity(x) for x in [deps['Source'],*deps['Includes']]]
        else:deps=[x for x in plan['frozen'] if x['path'].lower().endswith(('.h','.cuh','.cu'))]
        receipt=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=deps)
        c.save(out/(row['tag']+'-identity.json'),receipt);cached[c.key(row['object'])]=receipt['object']
    for arm,link in links.items():
        c.execute(arm+'-link-1',link['command'],env,out);check()
        c.save(out/(arm+'-link-plan.json'),dict(command=link['command'],inputs=[cached[c.key(x)] for x in link['inputs']]))
        c.save(out/(arm+'-image.json'),b.identity(link['image']))
    c.save(out/'summary.json',dict(passed=True,native_TUs=1,host_TUs=2,SDK_build=False,GPU_run=False,source_id=plan['source_id']))
    c.save(STAGE/'latest-check.json',dict(plan=str(path)));print('BUILD_COMPLETE',path,flush=True)


if __name__=='__main__':main()
