"""Compile three changed native TUs + one focused test, then late-bind host inputs.

No model/test execution. --compile resumes a plan; --link additionally takes
the independently refreshed shared-host qwen-link-plan.json.
"""
from pathlib import Path
import argparse
import datetime as dt
import importlib.util
import sys

sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
ARCH = STAGE.parents[1]
ROOT = STAGE.parents[3]
BASE = ARCH / 'ct-asymmetric-int4/windows-host/checks/20261019T194607'
NATIVE_RECIPE = ARCH / 'cast-stable-silu/checks/20261019T180121/native-main-identity.json'
TEST_RECIPE = BASE / 'cuda-artifact-explicit-cast-identity.json'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


h = load('nvfp4_cuda_helpers', ARCH / 'conv-typed-load/build.py')
b, c = h.b, h.c


def check(plan):
    for row in plan['frozen']:
        assert b.same(row), 'Changed source/recipe: ' + row['path']


def prepare(out):
    source = STAGE / 'native-source'
    frozen = [b.identity(p) for p in [Path(__file__), NATIVE_RECIPE, TEST_RECIPE,
        STAGE/'native-source-freeze.json', STAGE/'native-header-closure.json',
        STAGE/'cuda-host-source-freeze.json', STAGE/'provider-version.h',
        ROOT/'third_party/ggml_cuda_runtime/patches.json', ROOT/'third_party/ggml_cuda_runtime/NOTICE.md']]
    frozen.extend(b.identity(p) for p in source.rglob('*') if p.is_file())
    rows = []
    native = c.read(NATIVE_RECIPE)
    for tag, name in [('native-main','ggml-cuda.cu'), ('native-getrows','getrows.cu'), ('native-convert','convert.cu')]:
        file = source/'src/ggml-cuda'/name
        command = h.h.a.strip_ccbin(b.native_command(h.h.a.strip_ccbin(native['command']), file, tag, out))
        command = [x for x in command if not (x.startswith('-I') and
            ('architecture-refactor-2026-10-18' in x or 'reference-windows' in x))]
        command[1:1] = ['-I'+str(source/'src/ggml-cuda'), '-I'+str(source/'src'), '-I'+str(source/'include'),
            '-I'+str(ROOT/'src/compute_provider_ggml_cuda')]
        rows.append(dict(tag=tag, kind='native', source=b.identity(file), recipe=b.identity(NATIVE_RECIPE),
            command=command, object=str(out/(tag+'.obj')),
            old_object=native['object'] if tag=='native-main' else None))
    test = c.read(TEST_RECIPE)
    file = ROOT/'tests/graph_route_cuda/gguf_nvfp4_test.cc'
    command = b.host_command(test['command'], file, 'nvfp4-test', out)
    rows.append(dict(tag='nvfp4-test', kind='host', source=b.identity(file), recipe=b.identity(TEST_RECIPE),
        command=command, object=str(out/'nvfp4-test.obj'), old_object=None))
    frozen += [b.identity(p) for p in b.host_dependencies(test['command'])]
    for row in rows:
        frozen.append(row['source'])
        snapshot = out/'compiled-source'/Path(row['source']['path']).relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True); snapshot.write_bytes(Path(row['source']['path']).read_bytes())
        frozen.append(b.identity(snapshot))
    qwen = c.read(BASE/'qwen-link-plan.json')
    return dict(compile=rows, frozen=list({c.key(r['path']):r for r in frozen}.values()),
        environment_link=qwen, source_id=c.read(STAGE/'native-source-freeze.json')['source_id'],
        native_TUs=3, host_test_TUs=1, SDK_build=False, GPU_run=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--link', type=Path, help='Fresh shared-host Qwen link-plan receipt')
    args = parser.parse_args()
    if args.resume:
        path=args.resume.resolve(); out=path.parent; plan=c.read(path)
    else:
        out=STAGE/'checks'/dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
        out.mkdir(parents=True, exist_ok=False); (out/'tmp').mkdir()
        plan=prepare(out); path=out/'plan.json'; c.save(path, plan)
    print('PLAN', path, flush=True)
    if not (args.compile or args.link): return
    check(plan)
    env_link=plan['environment_link']
    env, runtime=b.environment(env_link['command'], [r['path'] for r in env_link['inputs']], out)
    c.save(out/'runtime-environment.json', dict(runtime=runtime, PATH=env['PATH']))
    for row in plan['compile']:
        receipt=out/(row['tag']+'-identity.json')
        if receipt.exists():
            prior=c.read(receipt)
            if prior['command']==row['command'] and b.same(prior['object']) and all(b.same(d) for d in prior['dependencies']):
                print('REUSE', row['tag'], flush=True); continue
        attempt=1+len(list(out.glob(row['tag']+'-compile-*.result.json')))
        c.execute(row['tag']+'-compile-'+str(attempt), row['command'], env, out)
        check(plan)
        if row['kind']=='host':
            d=c.read(out/(row['tag']+'-deps.json'))['Data']
            dependencies=[b.identity(p) for p in [d['Source'],*d['Includes']]]
        else:
            dependencies=[r for r in plan['frozen'] if r['path'].lower().endswith(('.h','.cuh','.cu'))]
        c.save(receipt,dict(command=row['command'],source=row['source'],object=b.identity(row['object']),dependencies=dependencies))
        print('COMPILED', row['tag'], flush=True)
    c.save(out/'compile-summary.json', dict(passed=True,native_TUs=3,host_TUs=1,SDK_build=False,GPU_run=False))
    if not args.link: return
    shared_path=args.link.resolve(); shared=c.read(shared_path)
    for row in shared['inputs']: assert b.same(row), row['path']
    native_old=plan['compile'][0]['old_object']
    assert sum(c.key(r['path'])==c.key(native_old['path']) for r in shared['inputs'])==1
    assert next(r for r in shared['inputs'] if c.key(r['path'])==c.key(native_old['path']))==native_old
    originals={c.key(r['path']):r for r in shared['inputs']}
    fresh={r['tag']:c.read(out/(r['tag']+'-identity.json'))['object'] for r in plan['compile']}
    originals.update({c.key(r['path']):r for r in fresh.values()})
    # GetRows and conversion were archive members. Explicit complete-TU objects
    # replace those members naturally, without editing/extracting the SDK lib.
    main_source='tools/qwen35_text/main.cc'
    common_main=next(r for r in shared['inputs'] if Path(r['path']).suffix.lower()=='.obj' and
        ('qwen35_text-main' in Path(r['path']).name or Path(r['path']).name in ('main.obj','qwen-main.obj')))
    base_test=c.read(BASE/'cuda-link-plan.json')
    gtest=[r for r in base_test['inputs'] if Path(r['path']).name.lower() in ('gtest.lib','gtest_main.lib')]
    assert len(gtest)==2
    originals.update({c.key(r['path']):r for r in gtest})
    links={}
    for arm in ['qwen','nvfp4']:
        command=[fresh['native-main']['path'] if c.key(x)==c.key(native_old['path']) else x
            for x in shared['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command[1:1]=[fresh['native-getrows']['path'],fresh['native-convert']['path']]
        if arm=='nvfp4':
            command=[x for x in command if c.key(x)!=c.key(common_main['path'])]
            command[1:1]=[fresh['nvfp4-test']['path'],*(r['path'] for r in gtest)]
        image=out/(arm+'.exe')
        command+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        inputs=[x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj','.lib')) and not x.startswith('/')]
        assert len(inputs)==len(set(map(c.key,inputs)))
        links[arm]=dict(command=command,inputs=inputs,image=str(image))
        attempt=1+len(list(out.glob(arm+'-link-*.result.json')))
        c.execute(arm+'-link-'+str(attempt), command, env, out)
        c.save(out/(arm+'-link-plan.json'), dict(command=command,inputs=[originals[c.key(p)] for p in inputs]))
        c.save(out/(arm+'-image.json'), b.identity(image))
    plan['links']=links
    plan['shared_host_plan']=b.identity(shared_path)
    plan['frozen'].append(plan['shared_host_plan'])
    c.save(path,plan)
    c.save(out/'summary.json',dict(passed=True,native_TUs=3,host_TUs=1,SDK_build=False,GPU_run=False,
        qwen_inputs=len(links['qwen']['inputs']),nvfp4_inputs=len(links['nvfp4']['inputs']),source_id=plan['source_id']))
    c.save(STAGE/'latest-check.json',dict(plan=str(path)))
    print('LINK_COMPLETE', path, flush=True)


if __name__=='__main__': main()
