"""Append the reviewed MMID metadata repair to the existing CUDA manifest."""
from pathlib import Path
import importlib.util
import json

STAGE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('nvfp4_native_patch',STAGE/'prepare_native.py')
n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)


def main():
    assert not (STAGE/'grouped-application.json').exists()
    draft=n.read(STAGE/'grouped-replacements.json')['files'][0]
    name=draft['path']
    patches=n.VENDOR/'patches.json';notice=n.VENDOR/'NOTICE.md'
    manifest=n.read(patches)
    assert not any(row['path']==name for row in manifest['files'])
    old=(STAGE/'before-grouped-fix'/name).read_bytes()
    assert old==n.original(name)
    data=old
    for edit in draft['edits']:
        before,after=edit['before'].encode(),edit['after'].encode()
        assert data.count(before)==1;data=data.replace(before,after,1)
    assert data==(STAGE/'grouped-overlay'/name).read_bytes()
    manifest['files'].append(dict(path=name,before_sha256=n.sha(old),after_sha256=n.sha(data),edits=draft['edits']))
    n.save(patches,manifest)
    notice.write_text(notice.read_text(encoding='utf-8').rstrip()+'''

The native MUL_MAT_ID metadata sorter retains every (token, selected slot)
occurrence, including repeated expert IDs within one token. A two-pass warp
prefix builds the existing forward/inverse maps and expert bounds in the
original token/slot order. This removes the old per-token unique-expert/shared
store assumption without allocating a larger shared store or changing public
or native interfaces. A one-channel activation keeps the original broadcast
mapping. Quantization, decoded weights, matrix arithmetic and output rounding
are unchanged. Obsolete 22/10-bit packed-store limits are removed; flattened
I32 map capacity is checked and actual Hyle stride/capacity qualification stays. This applies to the original generic and fixed-slot
metadata paths; it does not flatten all model activations or copy weight banks.
''',encoding='utf-8',newline='\n')
    composer=n.load('prepare_cuda_iq1_manifest')
    composer.derive(n.UPSTREAM,STAGE/'mixed-cpu-manifest.json',patches,
        n.VENDOR/'iq1-patches.json',STAGE/'grouped-combined-manifest.json')
    before={r['path']:n.replay(r) for r in n.read(STAGE/'combined-manifest.json')['files']}
    after={r['path']:n.replay(r) for r in n.read(STAGE/'grouped-combined-manifest.json')['files']}
    assert {p for p in after if after[p]!=before.get(p,n.original(p))}=={name}
    target=STAGE/'native-source'/name;target.write_bytes(data)
    freeze=n.read(STAGE/'native-source-freeze.json')
    freeze['files'].append(dict(path=name,before=n.identity(STAGE/'before-grouped-fix'/name),after=n.identity(target)))
    freeze['sources'][name]=n.sha(data)
    for record in freeze['product_files']:
        record['after']=n.identity(n.ROOT/record['path'])
    lock=n.read(n.ROOT/'cmake/HyleDependencyLock.json');entries={r['name']:r for r in lock['dependencies']}
    tree=n.tree(n.VENDOR)
    sid=n.sha((entries['ggml_runtime_patches']['vendored']['tree_sha256']+
        entries['ggml_cpu_runtime_patches']['vendored']['tree_sha256']+
        n.sha((n.ROOT/'src/compute_ggml_runtime/prepare_mixed_cpu_manifest.py').read_bytes())+
        n.sha((n.ROOT/'src/compute_ggml_runtime/prepare_cuda_iq1_manifest.py').read_bytes())+tree).encode())[:16]
    freeze.update(source_id=sid,version_proposal='hyle-ggml-cuda-resource-iq1-inference-v27',
        native_TUs_requiring_refresh=['ggml-cuda.cu','getrows.cu','convert.cu','mmid.cu'],
        correction_native_TUs=['mmid.cu'],original_three_native_objects_reusable=True,
        metadata_sort_repair=True,original_failed_source_freeze=n.identity(STAGE/'before-grouped-fix/native-source-freeze.json'))
    n.save(STAGE/'native-source-freeze.json',freeze)
    (STAGE/'provider-version.h').write_text('#pragma once\n#define HYLE_GGML_CUDA_PROVIDER_VERSION "456172ec+iq1-46cbf0e9-resource-'+sid+'"\n',encoding='utf-8')
    n.save(STAGE/'cuda-lock-proposal.json',dict(dependency='ggml_cuda_runtime_patches',source_id=sid,
        version='hyle-ggml-cuda-resource-iq1-inference-v27',vendored_tree_sha256=tree,
        notice_sha256=n.sha(notice.read_bytes()),central_lock_modified=False))
    n.save(STAGE/'grouped-application.json',dict(source_id=sid,source=n.identity(target),
        source_freeze=n.identity(STAGE/'native-source-freeze.json'),patches=n.identity(patches),notice=n.identity(notice),
        only_new_canonical_delta=name,all_other_combined_bytes_identical=True,compile_run=False,GPU_run=False))
    print(json.dumps(n.read(STAGE/'cuda-lock-proposal.json')))


if __name__=='__main__':main()
