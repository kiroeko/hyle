#include <algorithm>
#include <array>
#include <cstdint>
#include <span>
#include <vector>

#include <gtest/gtest.h>

#include "hyle/compute/cuda.h"
#include "hyle/compute/model_ops.h"
#include "hyle/compute/providers/ggml_cuda.h"
#include "hyle/graph/cuda.h"
#include "../compute_models/gguf_nvfp4_fixture.h"
#include "../compute_provider_native/half_test_support.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace mem = hyle::mem;
using Weights = nvfp4_test::Fixture;

c::TensorDesc dense(c::DataType type, std::initializer_list<std::int64_t> shape) {
  return c::TensorDesc::dense(type, {shape.begin(), shape.size()}).value();
}

mem::Buffer upload(mem::MemoryResourceRef memory, std::span<const std::byte> bytes) {
  auto result = mem::Buffer::create(memory, bytes.size(), 256).value();
  EXPECT_TRUE(result.view().write(bytes).ok());
  return result;
}

std::vector<float> project(const Weights &weights, std::span<const float> input,
                           std::span<const std::int32_t> ids) {
  const auto count = input.size() / static_cast<std::size_t>(weights.columns);
  std::vector<float> output(count * static_cast<std::size_t>(weights.rows));
  for (std::size_t row = 0; row < count; ++row)
    for (std::int64_t n = 0; n < weights.rows; ++n) {
      double sum = 0;
      const auto expert = ids.empty() ? 0 : ids[row];
      for (std::int64_t k = 0; k < weights.columns; ++k)
        sum += double(input[row * weights.columns + k]) *
            weights.decoded[(expert * weights.rows + n) * weights.columns + k];
      output[row * weights.rows + n] = static_cast<float>(sum);
    }
  return output;
}

// Original public operations, ordinary default provider roster, real checked
// indices and caller-owned buffers. The independently written packed fixture
// uses sparse exact-Q8 activations; only this dyadic domain is compared exactly.
void exercise(const Weights &weights, std::int64_t tokens, bool grouped, bool gather) {
  constexpr std::int64_t slots = 2;
  const auto wd = grouped ? c::gguf_grouped_weight_description(c::GgufQuantizedType::kNvfp4,
      c::DataType::kFloat32, weights.experts, weights.rows, weights.columns).value() :
      c::gguf_weight_description(c::GgufQuantizedType::kNvfp4,
          c::DataType::kFloat32, weights.columns, weights.rows).value();
  const auto table = gather ? wd.transposed().value() : wd;
  const auto ad = grouped ? dense(c::DataType::kFloat32, {tokens, slots, weights.columns}) :
      dense(c::DataType::kFloat32, {tokens, weights.columns});
  const auto id = grouped ? dense(c::DataType::kInt32, {tokens, slots}) : dense(c::DataType::kInt32, {3});
  const auto yd = grouped ? dense(c::DataType::kFloat32, {tokens, slots, weights.rows}) :
      gather ? dense(c::DataType::kFloat32, {3, weights.columns}) : dense(c::DataType::kFloat32, {tokens, weights.rows});
  auto context = g::cuda::create_context().value();
  auto memory = c::cuda::MemoryResource::create(context, c::cuda::MemoryKind::kDevice).value();
  auto packed = upload(memory.ref(), std::as_bytes(std::span(weights.bytes)));
  auto builder = g::GraphBuilder::create().value();
  const auto weight = builder.constant(table).value();
  const auto argument = builder.input(gather ? id : ad).value();
  g::ValueId indices;
  g::ValueId output;
  if (grouped) {
    indices = builder.input(id).value();
    output = builder.result(builder.add_node(c::model_ops::grouped_matmul(),
        std::array{weight, argument, indices}).value()).value();
  } else if (gather) {
    output = builder.result(builder.add_node(c::Operation(c::Gather{}), std::array{weight, argument}).value()).value();
  } else {
    output = builder.add(c::MatMul{}, argument, weight).value();
  }
  ASSERT_TRUE(builder.publish(output).ok());
  const std::array constants{g::ConstantBinding{weight,
      c::ConstTensorView::create(table, packed.view()).value()}};
  auto compiled = g::cuda::compile(std::move(builder).finish().value(), context,
      memory.ref(), {.constants = constants});
  ASSERT_TRUE(compiled) << compiled.error().message();
  ASSERT_EQ(compiled->report.step_count(), 1U);
  EXPECT_EQ(compiled->report.step(0)->provider.id, c::ggml_cuda::kProviderId);
  std::vector<mem::Buffer> retained_inputs, retained_outputs;
  std::vector<std::vector<float>> retained_values;
  std::array queues{context.create_queue().value(), context.create_queue().value()};
  std::array calls{compiled->executable.create_invocation().value(),
      compiled->executable.create_invocation().value()};
  for (int round = 0; round < 2; ++round) {
    std::array<mem::Buffer, 2> activation, selected, outputs;
    std::array<std::vector<std::int32_t>, 2> ids;
    std::array<std::vector<float>, 2> expected;
    const auto bind = [&](std::size_t lane) {
      EXPECT_TRUE(calls[lane].bind(argument, c::ConstTensorView::create(
          gather ? id : ad, (gather ? selected[lane] : activation[lane]).view()).value()).ok());
      if (grouped) EXPECT_TRUE(calls[lane].bind(indices,
          c::ConstTensorView::create(id, selected[lane].view()).value()).ok());
      EXPECT_TRUE(calls[lane].bind(output,
          c::TensorView::create(yd, outputs[lane].view()).value()).ok());
      const auto status = g::cuda::prepare_replay(calls[lane], queues[lane],
          {.mode = g::ReplayMode::kRequireCapture, .host_wait = g::HostWaitPolicy::kReject});
      EXPECT_TRUE(status.ok()) << status.message();
    };
    for (std::size_t lane = 0; lane < calls.size(); ++lane) {
      SCOPED_TRACE(::testing::Message() << weights.columns << '/' << tokens << '/' << round << '/' << lane);
      if (grouped || gather) {
        ids[lane].resize(static_cast<std::size_t>(grouped ? tokens * slots : 3));
        for (std::size_t i = 0; i < ids[lane].size(); ++i)
          ids[lane][i] = static_cast<std::int32_t>((i / 2 + lane + static_cast<std::size_t>(round)) %
              static_cast<std::size_t>(grouped ? weights.experts : weights.rows));
        selected[lane] = upload(memory.ref(), std::as_bytes(std::span(ids[lane])));
      }
      if (gather) {
        for (const auto row : ids[lane]) expected[lane].insert(expected[lane].end(),
            weights.decoded.begin() + row * weights.columns,
            weights.decoded.begin() + (row + 1) * weights.columns);
      } else {
        auto values = weights.activations(grouped ? tokens * slots : tokens);
        if ((lane + static_cast<std::size_t>(round)) % 2) for (auto &value : values) value = -value;
        expected[lane] = project(weights, values, grouped ? std::span(ids[lane]) : std::span<const std::int32_t>{});
        activation[lane] = upload(memory.ref(), std::as_bytes(std::span(values)));
      }
      outputs[lane] = mem::Buffer::create(memory.ref(), yd.required_bytes().value(), 256).value();
      bind(lane);
    }
    std::array<c::Completion, 2> work;
    for (std::size_t lane = 0; lane < calls.size(); ++lane) {
      auto completion = calls[lane].submit(queues[lane]);
      ASSERT_TRUE(completion) << completion.error().message();
      work[lane] = std::move(*completion);
    }
    ASSERT_TRUE(work[1].wait().ok()); ASSERT_TRUE(work[0].wait().ok()); work = {};
    for (std::size_t lane = 0; lane < calls.size(); ++lane) {
      EXPECT_EQ(half_test::read<float>(outputs[lane]), expected[lane]);
      if (grouped || gather) {
        EXPECT_EQ(half_test::read<std::int32_t>(selected[lane]), ids[lane]);
        for (const auto bad : {std::int32_t{-1}, static_cast<std::int32_t>(grouped ? weights.experts : weights.rows)}) {
          auto invalid = ids[lane]; invalid.back() = bad;
          ASSERT_TRUE(selected[lane].view().write(std::as_bytes(std::span(invalid))).ok());
          auto failure = calls[lane].submit(queues[lane]); ASSERT_TRUE(failure);
          EXPECT_TRUE(failure->wait().IsOutOfRange()); *failure = {};
          EXPECT_EQ(half_test::read<float>(outputs[lane]), expected[lane]);
          EXPECT_EQ(half_test::read<std::int32_t>(selected[lane]), invalid);
          ASSERT_TRUE(selected[lane].view().write(std::as_bytes(std::span(ids[lane]))).ok());
          EXPECT_FALSE(calls[lane].reset().ok());
          calls[lane] = compiled->executable.create_invocation().value();
          bind(lane);
          auto recovered = calls[lane].submit(queues[lane]); ASSERT_TRUE(recovered);
          ASSERT_TRUE(recovered->wait().ok()); *recovered = {};
          EXPECT_EQ(half_test::read<float>(outputs[lane]), expected[lane]);
        }
      }
      retained_values.push_back(expected[lane]); retained_outputs.push_back(std::move(outputs[lane]));
      if (activation[lane].valid()) retained_inputs.push_back(std::move(activation[lane]));
      if (selected[lane].valid()) retained_inputs.push_back(std::move(selected[lane]));
    }
    for (std::size_t i = 0; i < retained_outputs.size(); ++i)
      EXPECT_EQ(half_test::read<float>(retained_outputs[i]), retained_values[i]);
  }
}

TEST(CudaNvfp4Graph, MatMulKeeps64BlockSubgroupsWithoutDenseWeightBank) {
  for (const auto k : {64, 128, 320})
    for (const auto tokens : {1, 9}) exercise(Weights(5, k), tokens, false, false);
}
TEST(CudaNvfp4Graph, GroupedExpertsKeepRepeatedReboundAndCheckedIds) {
  for (const auto tokens : {1, 9}) exercise(Weights(5, 128, 3), tokens, true, false);
}
TEST(CudaNvfp4Graph, SelectedRowsDecode64BlockWidthsAndRejectInvalidPublication) {
  for (const auto k : {64, 128, 320}) exercise(Weights(5, k), 1, false, true);
}
} // namespace
