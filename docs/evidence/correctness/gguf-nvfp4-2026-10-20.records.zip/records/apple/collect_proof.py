import hashlib,json,pathlib,subprocess,tarfile
STAGE=pathlib.Path(__file__).resolve().parent
REMOTE='/Users/kiro/hyle-scratch/compute-unified/gguf-nvfp4-20261020/apple'
code=r'''import pathlib,tarfile,json,hashlib
root=pathlib.Path(REMOTE);paths=[]
for name in ['checks','checks-retry1']:
 for p in (root/name).rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.d']:paths.append(p)
receipt=[]
with tarfile.open(root/'proofs.tar.gz','w:gz') as a:
 for p in sorted(paths):
  a.add(p,arcname=p.relative_to(root));d=p.read_bytes();receipt.append(dict(path=p.relative_to(root).as_posix(),bytes=len(d),sha256=hashlib.sha256(d).hexdigest()))
(root/'proof-payloads.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(files=len(paths),bytes=(root/'proofs.tar.gz').stat().st_size)))
'''.replace('REMOTE',repr(REMOTE))
x=subprocess.run(['ssh','-o','BatchMode=yes','kiro@172.22.10.198','python3','-'],input=code,text=True,capture_output=True);(STAGE/'collect-proof.stdout.log').write_text(x.stdout);(STAGE/'collect-proof.stderr.log').write_text(x.stderr);assert x.returncode==0,x.stderr
for name in ['proofs.tar.gz','proof-payloads.json']:
 subprocess.run(['scp','-q','kiro@172.22.10.198:'+REMOTE+'/'+name,str(STAGE/name)],check=True)
out=STAGE/'validation';out.mkdir(exist_ok=True)
with tarfile.open(STAGE/'proofs.tar.gz') as a:
 for item in a.getmembers():
  assert item.isfile() and not pathlib.PurePosixPath(item.name).is_absolute() and '..' not in pathlib.PurePosixPath(item.name).parts
  p=out/item.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(a.extractfile(item).read())
for row in json.loads((STAGE/'proof-payloads.json').read_text()):
 p=out/row['path'];d=p.read_bytes();assert (len(d),hashlib.sha256(d).hexdigest())==(row['bytes'],row['sha256'])
summary=json.loads((out/'checks-retry1/summary.json').read_text());assert summary['passed'] and summary['exit']==0
print(json.dumps(dict(passed=True,files=len(json.loads((STAGE/'proof-payloads.json').read_text())),image=summary['image'],summary=str(out/'checks-retry1/summary.json')),indent=2))
