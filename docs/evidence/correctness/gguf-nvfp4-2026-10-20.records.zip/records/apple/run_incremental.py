import argparse,concurrent.futures,hashlib,json,pathlib,shlex,shutil,subprocess,time
STAGE=pathlib.Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--resume');parser.add_argument('--out',default='checks');ARGS=parser.parse_args()
PLAN=json.loads((STAGE/'incremental-plan.json').read_text());OUT=STAGE/ARGS.out;OUT.mkdir(exist_ok=True);(OUT/'objects').mkdir(exist_ok=True)
def ident(p):
 p=pathlib.Path(p);d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
def save(name,x):(OUT/name).write_text(json.dumps(x,indent=2)+'\n')
def run(tag,args):
 record=dict(argv=args,pid=None,started=time.time())
 with (OUT/(tag+'.stdout.log')).open('w') as so,(OUT/(tag+'.stderr.log')).open('w') as se:
  p=subprocess.Popen(args,stdout=so,stderr=se,cwd=STAGE);record['pid']=p.pid;save(tag+'.command.json',record);record.update(exit=p.wait(),elapsed=time.time()-record['started']);save(tag+'.command.json',record)
 print(tag,record['exit'],round(record['elapsed'],2),flush=True);return record
for x in PLAN['sources']:
 actual=ident(STAGE/'current'/x['path']);assert (actual['bytes'],actual['sha256'])==(x['bytes'],x['sha256']),x['path']
inventory=json.loads((STAGE/PLAN['base_inventory']).read_text())
for rel,x in inventory['records'].items():assert ident(x['object']['path'])==x['object'],rel
save('host.json',dict(model=subprocess.check_output(['sysctl','-n','hw.model'],text=True).strip(),clang=subprocess.check_output(['/usr/bin/clang++','--version'],text=True).splitlines()[0]))
def remap(args,target,source,oldsource=None):
 prefixes=list(dict.fromkeys(x.rstrip('/') for x in PLAN['old_prefixes']))
 if oldsource:prefixes.append(oldsource[:-len(source)-1])
 result=[]
 for arg in args:
  for prefix in prefixes:arg=arg.replace(prefix,str(STAGE/'current'))
  result.append(arg)
 result[result.index('-o')+1]=str(target)
 result[result.index('-c')+1]=str(STAGE/'current'/source)
 if '-MF' in result:result[result.index('-MF')+1]=str(target)+'.d'
 else:result+=['-MMD','-MF',str(target)+'.d']
 return result
records=PLAN['base_records'].copy()
previous=json.loads((STAGE/ARGS.resume/'fresh-compile-summary.json').read_text()) if ARGS.resume else {}
def compile_one(rel):
 if rel in previous and previous[rel]['exit']==0:
  record=previous[rel];assert ident(record['object']['path'])==record['object'];assert ident(STAGE/'current'/rel)==record['source'];return rel,record
 target=OUT/'objects'/(rel.replace('/','--')+'.o')
 if rel in records:args=records[rel]['argv'];oldsource=None
 else:
  row=PLAN['extra_commands'][rel];args=shlex.split(row['command']);oldsource=row['file']
 record=run('compile-'+rel.replace('/','--'),remap(args,target,rel,oldsource));record['source']=ident(STAGE/'current'/rel)
 if record['exit']==0:record['object']=ident(target)
 return rel,record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:fresh=dict(p.map(compile_one,PLAN['fresh']))
save('fresh-compile-summary.json',fresh)
if any(x['exit'] for x in fresh.values()):raise SystemExit(2)
records.update(fresh);save('complete-object-closure.json',records)
archive=OUT/'libcurrent-hyle.a'
if run('archive',['ar','rcs',str(archive)]+[x['object']['path'] for x in records.values()])['exit']:raise SystemExit(3)
test=OUT/'admission-test.o';source='tests/compute_route_apple/nvfp4_admission/main.cc'
if run('test-compile',remap(PLAN['test_compile'],test,source))['exit']:raise SystemExit(4)
image=OUT/'nvfp4-admission-tests';args=PLAN['link'][:]
for i,arg in enumerate(args):
 if arg.endswith('/parity-test.o'):args[i]=str(test)
 elif arg.endswith('/libcurrent-hyle.a'):args[i]=str(archive)
 elif arg.startswith('-Wl,-map,'):args[i]='-Wl,-map,'+str(image)+'.map'
args[args.index('-o')+1]=str(image)
if run('link',args)['exit']:raise SystemExit(5)
native=pathlib.Path('/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/f32-partials/mlx.metallib');shutil.copy2(native,OUT/'mlx.metallib');save('native-pair.json',dict(metallib=ident(native),host=ident(native.parent/'native-host.f32.o')))
result=run('tests',[str(image)]);save('summary.json',dict(passed=result['exit']==0,exit=result['exit'],fresh=len(fresh),reused=len(PLAN['base_records'])-len(set(fresh)&set(PLAN['base_records'])),image=ident(image),source_freeze=ident(STAGE/'source-freeze.json'),header=ident(STAGE/'current/include/hyle/compute/model_ops.h'),descriptor_declines=4,no_payload_arrays=True,shared_sdk_rebuilt=False))
raise SystemExit(result['exit'])
