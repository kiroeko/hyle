"""Exercise real CLI imports without -B or an environment cache suppression."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
S = Path(__file__).resolve().parent
ROOT = S.parents[2]
programs = ROOT / 'third_party/iree_vulkan_runtime/programs'
out = S / 'offline-cache'
out.mkdir(exist_ok=False)
assert not list(programs.rglob('*.pyc'))
before = sorted(str(p.relative_to(programs)) for p in programs.rglob('*') if p.is_file())
env = os.environ.copy()
for name in ('PYTHONDONTWRITEBYTECODE', 'PYTHONPYCACHEPREFIX'):
    env.pop(name, None)
rows = []
for name in ('artifacts', 'mlx', 'official', 'iq1'):
    script = programs / ('compile_' + name + '.py')
    command = [sys.executable, str(script), '--help']
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
    (out / (name + '.stdout.log')).write_bytes(result.stdout)
    (out / (name + '.stderr.log')).write_bytes(result.stderr)
    rows.append(dict(command=command, exit=result.returncode,
        script_sha256=hashlib.sha256(script.read_bytes()).hexdigest()))
    assert result.returncode == 0
after = sorted(str(p.relative_to(programs)) for p in programs.rglob('*') if p.is_file())
assert before == after and not list(programs.rglob('*.pyc'))
(out / 'summary.json').write_text(json.dumps(dict(passed=True, runs=rows,
    command_line_B_used=False, environment_bytecode_suppression=False,
    vendor_file_list_unchanged=True, compiler_or_GPU_run=False), indent=2) + '\n', encoding='utf-8')
print('OFFLINE_IMPORT_CACHE_CHECK', len(rows), 'passed')
