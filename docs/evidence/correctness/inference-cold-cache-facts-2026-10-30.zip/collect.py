"""Seal this finite cache-facts check. No build, native run, download or cleanup."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
REVIEW = R / '.scratch/inference-cache-plan-review-20261030'
EXTRACTION = R / '.scratch/inference-cold-cache-facts-extract-20261030'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def pin(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            digest.update(block)
    return {'path': str(path.resolve()), 'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


verified = {}


def exact(item):
    path = str(Path(item['path']).resolve()).lower()
    if path not in verified:
        verified[path] = pin(item['path'])
    actual = verified[path]
    assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256'], item['path']
    return actual


def terminal(process):
    assert process['state'] == 'TERMINAL' and not process.get('timed_out'), process
    assert process['exit'] == 0, process


plan = read(W / 'plan.json')
base = read(W / 'model-link-base.json')
baseline = read(W / 'baseline-plan.json')
verification = read(W / 'verification-summary.json')
assert verification['status'] == 'PASS_FINITE_COLD_CACHE_FACTS_BOUNDARY'
assert verification['full_goal_complete'] is False
assert verification['attempts'] == {'total': 30, 'compile': 8, 'links': 7, 'native': 15, 'failures': 0}
assert len(plan['retained']) == len(base['retained']) == len(baseline['retained']) == 228
for item in [*plan['retained'], *base['retained'], *baseline['retained'], plan['runtime'], base['runtime']]:
    exact(item)
interpretation = read(W / 'baseline-interpretation.json')
assert interpretation['baseline_cached_inputs'] == 228
assert interpretation['baseline_CLI_CXX'] == interpretation['baseline_SESSION_CXX'] == 0
assert base['retained_categories']['unchanged_retained'] == 226

receipts = {}
source_proofs = []
for path in sorted((W / 'compile').glob('*/receipt.json')):
    receipt = read(path)
    for key in ('object', 'dependencies', 'process'):
        exact(receipt[key])
    terminal(read(receipt['process']['path']))
    for item in receipt['source_identities']:
        exact(item)
    receipts[path.parent.name] = {
        'receipt': pin(path), 'object': receipt['object'],
        'source_pin_count': len(receipt['source_identities']), 'all_source_pins_current_exact': True,
    }
    source_proofs.append({'unit': path.parent.name, 'sources': receipt['source_identities'],
                          'all_current_exact': True})
assert set(receipts) == {'weights', 'cold', 'cli', 'tiny', 'rows', 'session', 'math', 'leaf'}
save(W / 'source-receipt-proofs.json', source_proofs)

attempts = []
counts = {}
for directory in ('compile', 'link', 'runs'):
    paths = sorted((W / directory).rglob('process.json'))
    counts[directory] = len(paths)
    for path in paths:
        process = read(path)
        terminal(process)
        command = path.parent / 'command.json'
        assert command.is_file(), path
        row = {'name': path.parent.relative_to(W).as_posix(), 'process': pin(path),
               'actual': process, 'command': pin(command)}
        if directory == 'runs':
            row['report'] = pin(path.parent / 'report.json')
        attempts.append(row)
assert counts == {'compile': 8, 'link': 7, 'runs': 15}, counts

whole = read(W / 'whole-cli-summary.json')
assert whole['status'] == 'PASS_ALL_FOUR_DEFAULT_CASES'
assert len(whole['checks']) == 4
for row in whole['checks']:
    assert row['all_non_timing_fields_equal'] and not row['differences']
session = read(W / 'session-compare.json')
assert session['status'] == 'PASS_EXACT_COMPLETE_SESSION'
assert session['payload_byte_equal'] and session['observation_equal_after_only_output_root_normalization']
assert not session['ignored_semantic_fields'] and not session['differences'] and not session['report_differences']
manifest = read(W / 'session-vector-manifest.json')
assert manifest['status'] == 'PASS_EXACT_COMPLETE_VECTOR_BYTES'
assert manifest['file_count_per_arm'] == 378 and manifest['bytes_per_arm'] == 150761472
assert manifest['all_cross_arm_bytes_identical'] and manifest['numerical_tolerance'] is None
assert manifest['metadata_equal_except_output_root']

# Independently rehash every exported payload and compare every complete pair.
# The archive contains these hashes and original numeric observations, never payload bytes.
arms = manifest['arms']
assert arms['baseline'].keys() == arms['candidate'].keys()
for arm in ('baseline', 'candidate'):
    assert len(arms[arm]) == 378
    assert sum(item['bytes'] for item in arms[arm].values()) == 150761472
    for item in arms[arm].values():
        exact(item)
for name in arms['baseline']:
    left, right = arms['baseline'][name], arms['candidate'][name]
    assert left['bytes'] == right['bytes'] and left['sha256'] == right['sha256'], name
    with Path(left['path']).open('rb') as one, Path(right['path']).open('rb') as two:
        while True:
            first, second = one.read(4 << 20), two.read(4 << 20)
            assert first == second, name
            if not first:
                break
observations = {}
for arm in ('baseline', 'candidate'):
    folder = W / 'runs' / arm / 'session-cuda/attempt1/vectors'
    observation = read(folder / 'observation.json')
    assert observation['status'] == 'PASS_BYTE_EXACT' and observation['all_vectors_byte_equal']
    assert observation['all_finite'] and observation['numerical_tolerance_policy'] is None
    assert observation['final_live_snapshot_versions'] == 0
    assert observation['idle_head_full_byte_checks'] == 4 and observation['A_calls_after_B_stop'] == 3
    assert observation['managed_backing_bytes'] == observation['planned_backing_bytes'] == 80240691
    for vector in observation['vectors']:
        assert vector['byte_equal'] and vector['max_abs'] == vector['squared_error'] == 0
        assert vector['nonfinite_baseline'] == vector['nonfinite_actual'] == 0
    observations[arm] = observation


def normalize_output_root(value, root):
    if isinstance(value, str):
        return value.replace(str(root), '{VECTORS}')
    if isinstance(value, list):
        return [normalize_output_root(item, root) for item in value]
    if isinstance(value, dict):
        return {key: normalize_output_root(item, root) for key, item in value.items()}
    return value


assert normalize_output_root(observations['baseline'], W / 'runs/baseline/session-cuda/attempt1/vectors') == \
    normalize_output_root(observations['candidate'], W / 'runs/candidate/session-cuda/attempt1/vectors')
save(W / 'collector-vector-readback.json', {
    'status': 'PASS_INDEPENDENT_ALL_HASHES_AND_DIRECT_COMPLETE_BYTES',
    'files_per_arm': 378, 'bytes_per_arm': 150761472, 'all_complete_pairs_byte_equal': True,
    'all_original_numerical_checks_zero_error_finite': True, 'numerical_tolerance': None,
    'observation_normalization': 'Only the run-specific output root; all remaining fields exact.',
    'original_manifest': pin(W / 'session-vector-manifest.json'),
})

static = read(REVIEW / 'static-cache-facts-review.json')
assert static['status'] == 'PASS_STATIC_MODEL_PRIVATE_CACHE_FACTS_BOUNDARY'
assert static['cold_prefix_identical_normalized_bytes'] and static['runtime_Recurrent_through_end_identical']
assert static['weights_change_only_direct_include'] and static['main_explicit_runtime_state_include']
for item in static['source_pins']:
    exact(item)
references = read(REVIEW / 'reference-cache-boundaries.json')
assert references['status'] == 'ACTUAL_LOCAL_HEAD_SOURCE_BOUNDARIES_VERIFIED'
assert sum(len(item['files']) for item in references['references'].values()) == 6
for reference in references['references'].values():
    for item in reference['files']:
        exact(item)

deps = read(W / 'cold-dependency-proof.json')
for row in deps:
    if row['unit'] in ('leaf', 'weights', 'cold', 'rows'):
        assert row['no_qwen_state_and_no_runtime_paged_sequence']
leaf = next(row for row in deps if row['unit'] == 'leaf')
assert leaf['no_Compute_or_Graph_headers'] and leaf['count'] == 3

# Source snapshots are metadata evidence, not validation copies or new builds.
snapshot_sources = {
    'engine/models/qwen35/cache_plan.h', 'engine/models/qwen35/session_state.h',
    'engine/models/qwen35/weights.h', 'engine/models/qwen35/weights.cc',
    'engine/models/qwen35/graph_builder.h', 'engine/models/qwen35/graph_builder.cc',
    'engine/models/qwen35/model_geometry.h', 'engine/models/qwen35/main.cc',
    'engine/models/qwen35/mtp_session_probe.cc', 'engine/models/qwen35/cold_sources.cmake',
    'tests/tools/qwen_host_image_test.cc', 'tests/tools/qwen_draft_vocabulary_probe.cc',
    'tests/tools/qwen_prefix_cache_test.cc',
}
source_snapshots = []
for relative in sorted(snapshot_sources):
    source = R / relative
    target = W / 'source-current' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(source.read_bytes())
    exact_source = pin(source)
    assert pin(target)['sha256'] == exact_source['sha256']
    previous = subprocess.run(['git', 'show', plan['base_commit'] + ':' + relative], cwd=R,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    old = None
    if previous.returncode == 0:
        old_path = W / 'source-baseline-head' / relative
        old_path.parent.mkdir(parents=True, exist_ok=True)
        old_path.write_bytes(previous.stdout)
        old = pin(old_path)
    elif relative != 'engine/models/qwen35/cache_plan.h':
        raise AssertionError((relative, previous.stderr.decode(errors='replace')))
    source_snapshots.append({'relative': relative, 'current': exact_source, 'snapshot': pin(target),
                             'baseline_git_blob_snapshot': old,
                             'baseline_note': 'Git blob source; newline normalization can differ from original compiled working file.'})
save(W / 'source-snapshots.json', source_snapshots)
delta = subprocess.check_output(['git', 'diff', '--', 'engine/models/qwen35/session_state.h',
                                 'engine/models/qwen35/weights.h'], cwd=R)
(W / 'source-delta.patch').write_bytes(delta)
new_header = (R / 'engine/models/qwen35/cache_plan.h').read_text(encoding='utf-8-sig').splitlines(True)
new_delta = ''.join(difflib.unified_diff([], new_header, fromfile='/dev/null',
                                        tofile='b/engine/models/qwen35/cache_plan.h'))
(W / 'source-new-header.patch').write_text(new_delta, encoding='utf-8')

extensions = {'.py', '.json', '.jsonl', '.log', '.xml', '.txt', '.md', '.cc', '.h', '.cmake', '.patch', '.ids', '.tsv'}
external = []
for directory in (REVIEW, EXTRACTION):
    assert directory.is_dir(), directory
    for source in sorted(directory.rglob('*')):
        if source.is_file() and source.suffix in extensions and '__pycache__' not in source.parts:
            target = W / 'external-evidence' / directory.name / source.relative_to(directory)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
            external.append(pin(target))

summary = {
    'schema': 'hyle-inference-cold-cache-facts-v1',
    'status': 'PASS_FINITE_COLD_CACHE_FACTS_BOUNDARY',
    'base_commit': plan['base_commit'], 'full_goal_complete': False,
    'implementation': {'changed_product_files': 3,
                       'prefix_namespace_layout_defaults_inline_body_and_budget_formulas_unchanged': True,
                       'main_already_explicitly_includes_runtime_state': True,
                       'CMake_changed': False},
    'compile': {
        'CXX_processes': 8, 'model_owned_weights_CXX': 1, 'model_owned_graph_builder_CXX': 1,
        'consumer_CXX': 4, 'compile_only_leaf_CXX': 1, 'existing_math_host_CXX': 1,
        'NVCC': 0, 'downloads': 0, 'retained_inputs_per_link_closure': 228,
        'changed_retained_inputs': 2, 'unchanged_reused_inputs': 226,
        'baseline_cli_CXX': 0, 'baseline_session_CXX': 0,
        'note': 'Harness SDK_CXX=1 names the reused SDK/engine inventory weights.cc entry; it is model-owned engine cold code, not a rebuild of a generic SDK library module.',
    },
    'attempts': {'CXX': 8, 'link': 7, 'native': 15, 'failures': 0, 'all_terminal_exit_zero': True},
    'checks': verification,
    'native_count_scope': '15 native processes total: 8 default CLI, 2 Session, and 5 finite processes; math-cpu contains 24 existing host groups in ONE process.',
    'receipts': receipts, 'attempt_records': attempts,
    'baseline_interpretation': interpretation,
    'candidate_model_link_base': pin(W / 'model-link-base.json'),
    'baseline_source_plan': pin(W / 'baseline-plan.json'),
    'source_snapshots': pin(W / 'source-snapshots.json'),
    'all_receipt_source_pins_current_exact': True,
    'dependency_proof': pin(W / 'cold-dependency-proof.json'),
    'static_review': pin(REVIEW / 'static-cache-facts-review.json'),
    'reference_review': pin(REVIEW / 'reference-cache-boundaries.json'),
    'hardware_toolchain': pin(W / 'hardware-toolchain.json'),
    'whole_cli_comparison': pin(W / 'whole-cli-summary.json'),
    'session_comparison': pin(W / 'session-compare.json'),
    'session_vector_manifest': pin(W / 'session-vector-manifest.json'),
    'independent_vector_recheck': pin(W / 'collector-vector-readback.json'),
    'external_evidence': external,
    'limits': [
        'Only a model-private descriptive cache-facts boundary is verified, not all architecture or feature exhaustion.',
        'cache_plan.h is std plus model_geometry; actual compiler leaf closure has three repository files including the leaf source and no Compute/Graph.',
        'weights/graph_builder/rows lose Qwen session_state and paged_sequence includes; original generic Backend/Compute/Graph/read-lease dependencies remain valid.',
        'Manual exact CXX/link reused the existing cache. Full normal default CMake build/install was not run; no CMake source changes.',
        'Four single process CLI pairs use default full vocabulary. Timings diagnose obvious regressions only; no stable performance lead or improvement claim.',
        'No new model/reference download, GPU performance candidate or profile.',
        'Local llama.cpp 23b0202a and vLLM 276fbcff listed six file scopes justify facts versus mutable ownership, not universal Qwen Plan or identical engine implementations.',
        'Family/Phase design documents are proposed next work only. Runtime recovery/state owners were not moved in this slice.',
    ],
}
save(W / 'summary-draft.json', summary)

files = set()
for path in W.iterdir():
    if path.is_file() and path.suffix in extensions and path.name not in ('archive-draft.json', 'retention-manifest.json'):
        files.add(path)
for directory in ('compile', 'link', 'runs', 'baseline-source', 'source-current', 'source-baseline-head',
                  'external-evidence', 'session-input', 'metadata-cpu', 'metadata-cuda'):
    for path in (W / directory).rglob('*'):
        if path.is_file() and path.suffix in extensions and '__pycache__' not in path.parts:
            files.add(path)
member_manifest = [{'member': path.relative_to(W).as_posix(), 'bytes': path.stat().st_size,
                    'sha256': pin(path)['sha256']} for path in sorted(files)]
save(W / 'retention-manifest.json', {
    'members': member_manifest,
    'excluded': 'Raw f32/bf16/f16/bin vector payloads, EXE/OBJ/PDB/DLL/LIB/EXP, model weights, SDK/vendor copies. Full vector hashes, exact comparison, numerical observations and all commands/process/logs/reports retained.',
})
files.add(W / 'retention-manifest.json')
archive = W / 'evidence-draft.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as zipped:
    for path in sorted(files):
        zipped.write(path, path.relative_to(W).as_posix())
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    assert len(zipped.namelist()) == len(files)
    for item in member_manifest:
        body = zipped.read(item['member'])
        assert len(body) == item['bytes'] and hashlib.sha256(body).hexdigest() == item['sha256']
archive_record = {
    'archive': pin(archive), 'members': len(files), 'all_members_readback_bytes_sha256_verified': True,
    'summary': pin(W / 'summary-draft.json'), 'model_link_base': pin(W / 'model-link-base.json'),
    'session_vector_manifest': pin(W / 'session-vector-manifest.json'),
    'independent_vector_recheck': pin(W / 'collector-vector-readback.json'),
    'no_cleanup_performed': True,
}
save(W / 'archive-draft.json', archive_record)
print(json.dumps({'status': summary['status'], 'native_processes': 15, 'CXX': 8, 'links': 7,
                  'archive_bytes': archive_record['archive']['bytes'], 'members': len(files),
                  'archive_sha256': archive_record['archive']['sha256'], 'vector_files_per_arm': 378}))
