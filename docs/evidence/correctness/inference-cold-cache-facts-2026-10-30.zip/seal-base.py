"""Seal replacement228 cache; never mix historical consumer headers."""
from pathlib import Path
import copy,hashlib,importlib.util,json
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('cache_seal_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
p=read(W/'plan.json');base=read(p['base']['path']);sdk=read(base['sdk_engine_dependencies']['path'])
assert len(p['retained'])==228 and set(p['units'])=={'weights','cold'}
receipts={name:read(W/'compile'/name/'receipt.json') for name in ['weights','cold','cli','tiny','rows','session','math','leaf']}
for receipt in receipts.values():
 for item in [receipt['object'],receipt['dependencies'],receipt['process'],*receipt['source_identities']]:exact(item)
replacements={key(old['original']['path']):receipts[name]['object'] for name,old in p['units'].items()}
units_by_old={key(old['original']['path']):name for name,old in p['units'].items()}
updated=copy.deepcopy(sdk)
for section in ('inspected','engine_consumers','native_consumers'):
 for index,row in enumerate(updated[section]):
  if key(row['object']) not in units_by_old:continue
  name=units_by_old[key(row['object'])];receipt=receipts[name]
  if section=='inspected':
   updated[section][index]=dict(object=receipt['object']['path'],dependencies=receipt['dependencies'])
  else:
   updated[section][index]=dict(object=receipt['object']['path'],dependencies=receipt['dependencies'],
    receipt=pin(W/'compile'/name/'receipt.json'),source_identities=receipt['source_identities'],
    engine_dependencies=[item['path'] for item in receipt['source_identities'] if Path(item['path']).is_relative_to(R/'engine')])
updated['scope']='Current228 replacement closure. Actual changed includes affected weights and existing cold builder only;159 available dependency rows and69 unavailable native/library metadata entries preserved. Cold consumer dependency receipts no longer include Qwen session_state or runtime paged_sequence.'
save(W/'sdk-engine-dependencies.json',updated)
retained=[replacements.get(key(item['path']),item) for item in p['retained']]
assert len(retained)==228 and len({key(item['path']) for item in retained})==228
for item in retained:exact(item)
historical=copy.deepcopy(base.get('historical_consumers',{}));current={};previous={};audit=[]
for name,row in base['current_consumers'].items():
 exact(row['receipt']);exact(row['object']);receipt=read(row['receipt']['path'])
 mismatch=[]
 for item in receipt['source_identities']:
  path=Path(item['path'])
  if not path.is_file() or pin(path)!=item:mismatch.append(item)
 if name in ('cli','tiny','rows','session') or mismatch:
  previous[name]=dict(**row,status='HISTORICAL_NOT_CURRENT',reason='Current header dependency mismatch or replaced consumer',mismatched_source_pins=mismatch)
  audit.append(dict(name=name,status='HISTORICAL',mismatched_source_pin_count=len(mismatch)))
 else:
  current[name]=row;audit.append(dict(name=name,status='CURRENT_EXACT',source_pin_count=len(receipt['source_identities'])))
historical['before-cold-cache-facts-fdae8466b']=previous
for name in ('cli','tiny','rows','session','math'):
 current[name]=dict(receipt=pin(W/'compile'/name/'receipt.json'),object=receipts[name]['object'])
args=[]
for arg in p['original_link']:
 if key(arg)==key(p['original_consumer']):arg=receipts['cli']['object']['path']
 if key(arg) in replacements:arg=replacements[key(arg)]['path']
 for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
  if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/cli').with_suffix(suffix));break
 args.append(arg)
assert sum(key(arg)==key(receipts['cold']['object']['path']) for arg in args)==1
assert sum(key(arg)==key(receipts['weights']['object']['path']) for arg in args)==1
sealed=dict(schema='hyle.current-model-link-base.v1',base=p['base'],compile=p['consumers']['cli']['compile'],link=args,
 consumer_source=str(W/'cli.cc'),previous_consumer=p['original_consumer'],retained=retained,runtime=p['runtime'],
 sdk_engine_dependencies=pin(W/'sdk-engine-dependencies.json'),current_consumers=current,historical_consumers=historical,
 retained_categories=dict(cached_SDK_and_engine_inputs=227,existing_model_cold_object=1,total_retained=228,
  changed_weights_SDK=1,changed_existing_model_cold=1,unchanged_retained=226),
 model_cold_objects=[dict(source=str(R/'engine/models/qwen35/graph_builder.cc'),receipt=pin(W/'compile/cold/receipt.json'),object=receipts['cold']['object'])],
 current_compile_only=dict(leaf=dict(receipt=pin(W/'compile/leaf/receipt.json'),object=receipts['leaf']['object'])),
 note='Cache facts extraction:227 SDK/engine inputs incl current weights plus one current existing model cold builder. Recompiled both affected TUs with actual current cache_plan/weights header closure, remaining226 retained. Old main-including consumers and any other source-mismatched receipts remain historical. No old/new header consumers are marked current.')
save(W/'current-consumer-source-audit.json',audit)
save(W/'model-link-base.json',sealed)
save(W/'baseline-interpretation.json',dict(base_commit=p['base_commit'],baseline_cached_inputs=228,
 baseline_CLI_CXX=0,baseline_SESSION_CXX=0,baseline_link_processes=2,
 inherited_note_correction='baseline-plan.json inherited note mentions227 from earlier batch; authoritative retained array is228=227SDK/engine+1existing cold builder. Source proofs and objects are exact fdae pre-cache-extraction identities; baseline never used candidate header compilation.'))
print(json.dumps(dict(status='SEALED_CURRENT228',retained=len(retained),replaced=2,current_consumers=list(current),
 source_mismatched_historical={row['name']:row['mismatched_source_pin_count'] for row in audit if row['status']=='HISTORICAL'},
 inspected=len(updated['inspected']),unavailable=len(updated['unavailable'])),ensure_ascii=False))
