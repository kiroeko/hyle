from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def replace(relative, old, new):
    path = ROOT / relative
    raw = path.read_bytes()
    text = raw.decode('utf-8')
    newline = '\r\n' if b'\r\n' in raw else '\n'
    old, new = old.replace('\n', newline), new.replace('\n', newline)
    assert text.count(old) == 1, (relative, text.count(old), old[:80])
    path.write_bytes(text.replace(old, new).encode('utf-8'))

replace('docs/architecture/inference-design.md', '''本片不等于完整模型模块化：Family／Phase构图工厂、热Model与请求恢复仍在`main.cc`；
冷接口还经`weights.h`间接包含`session_state.h`以取得cache计划／row字节事实。
后续优先拆清这些冷事实与完整Snapshot状态的依赖，再处理家族工厂和真实跨模型复用；不把Qwen私有Recipe改名为通用模型接口。''', '''随后把Qwen私有容量、row字节、对齐及checked数学移入`cache_plan.h`；原命名、布局、默认值和公式保持，
`session_state.h`继续拥有Recurrent／StatePools／Version／Snapshot，`weights.h`不再为这些冷事实解析完整运行状态。
独立叶头的实际编译闭包只有自身与`model_geometry.h`；权重与构图实现仍保留真实Compute／Graph及ReadLease依赖。
本地llama.cpp `23b0202a`的hparams／cparams与memory边界、vLLM `276fbcff`的KVCacheSpec／Config与manager分责支持事实与运行所有者分离；
它们不证明Qwen的target／draft容量是通用缓存形状，也不要求所有动态缓存工作都在启动期结束。
[本片有限检查](../evidence/correctness/inference-cold-cache-facts-2026-10-30.json)覆盖实际编译依赖、既有24组主机合同、
默认完整词表普通／MTP四对及完整Session向量；只重编两个既有链接输入，226个复用，未运行完整默认CMake构建或独立性能候选。

当前异构消费者的接入面也已沿实际源码核对：

| 消费者 | 已复用的共同机制 | 仍保留的模型事实及验证边界 |
|---|---|---|
| Qwen完整文本引擎 | ColdShapePlan、PreparedProgramFamily、ProgramIo、ExecutionEpisode、drive_steps | 模型私有shape／端口、分页KV、conv／GDN、hidden与完整Snapshot；Family／Phase及请求恢复仍需分责 |
| GLM ordinary／K1原组件 | ProgramIo、实际drive_steps同步分支、RequestLoop与提交见证 | 单router具体图、压缩状态／lag／journal及原StateVersion；非第二完整引擎 |
| Kimi KDA→MLA原组件 | ProgramIo、ProgramCarrier、ExecutionEpisode及真实Source接力 | 异构递归／MLA状态与feature输出；没有生成token或请求驱动证明 |
| DeepSeek原组件及压缩侧车 | ProgramIo、普通Graph生命周期、接受与提交见证 | 三router／四phase及压缩状态／sidecar；没有完整请求驱动证明 |

后三者当前使用有限具体图，未消费ColdShapePlan／PreparedProgramFamily；不为接口外观伪造Qwen程序族，也不把IO复用扩大为完整冷工厂／调度复用。
下一步隔离Family模型数学和Phase物理准备，保留原Model的准入、状态准备、诊断及完整成功后发布；
特别保持prepare_cache与draft行银行准备的原失败顺序、literal／采样配置的原寿命，不机械搬整个函数或新增大ModelOps。''')

replace('docs/implementation/inference-roadmap.md', '''剩余的weights.h→session_state.h冷计划事实依赖、Family／Phase工厂和请求恢复继续处理，已完成共同owner／IO／退休机制不重复。''', '''冷cache事实现已独立为模型私有cache_plan.h，weights／构图头不再间接解析完整会话状态；原容量公式、布局与数值保持，实际依赖及有限默认消费者检查见[本片记录](../evidence/correctness/inference-cold-cache-facts-2026-10-30.json)。
Qwen／GLM／Kimi／DeepSeek的实际接入面已经核对：有限具体图不需要人为套入Qwen的程序族，IO／资源交接复用也不等于完整引擎接入。
Family数学／冷工厂、Phase物理准备和请求恢复继续处理；保原准备与失败发布时序，已完成共同owner／IO／退休机制不重复。''')

replace('docs/developer/inference-progress.md', '''- **本次完成：** 冷构图辅助已建立独立编译边界，一个探针脱离main；15项成功原生检查、默认普通／MTP四工况和378份跨拆分状态向量保持。整体架构仍未完成。''', '''- **本次完成：** 冷cache事实与完整会话状态头已分离；8次CXX、7次链接、15个有限原生进程均成功，默认普通／MTP四对全部非计时字段一致，两臂各378份状态向量逐字节一致。整体架构仍未完成。''')
replace('docs/developer/inference-progress.md', '''- **现在做：** 冷cache计划／row字节事实已从完整Snapshot状态头隔离，正在检查编译依赖、容量合同及默认数值／寿命；随后继续家族构图工厂及实际跨模型接入面。''', '''- **现在做：** 继续Family模型数学与Phase物理准备的边界，核原准备／失败发布顺序及异构组件接入；已完成cache事实拆分不再重开。''')
replace('docs/developer/inference-progress.md', '''  - 跨模型需求与低成本接入：约20%（需求与实际接入依赖已盘点，待对应调整）
  - 模型冷构图与独立编译边界：约60%（冷辅助片已验证，冷事实依赖与家族工厂仍待拆清）''', '''  - 跨模型需求与低成本接入：约25%（四类实际接入面已复审，待对应实现调整）
  - 模型冷构图与独立编译边界：约65%（冷辅助与cache事实片已验证，家族工厂仍待拆清）''')
replace('docs/developer/inference-progress.md', '''    - 冷cache事实与完整状态依赖：约80%（代码与静态闭包已分离，编译／有限验证进行中）''', '''    - 冷cache事实与完整状态依赖：100%（实际编译依赖、既有合同及有限默认消费者检查完成）''')
replace('docs/developer/inference-progress.md', '''| 跨模型需求与模块接入面 | 共同执行架构 | 约20% | 用Qwen／GLM／Kimi／DeepSeek的实际状态、阶段与装配列需求，检查新模型需要增加或改动哪些模块。 |
| 冷cache事实与状态头依赖 | 共同执行架构／冷构图边界 | 约80% | cache_plan.h已保原公式／布局，weights与构图头不再依赖Qwen会话状态；实际编译闭包、既有容量／溢出合同及默认消费者验证进行中。 |''', '''| 跨模型需求与模块接入面 | 共同执行架构 | 约25% | 四类实际接入面已核对，按真实状态、输出与owner差异调整；有限具体图不伪造Qwen程序族。 |
| Family数学与Phase物理准备 | 共同执行架构／冷构图边界 | 约10% | 显式输入／产物及原所有者职责已盘点，核原cache／draft准备与失败发布顺序，选择不扭曲模型的小边界。 |''')
replace('docs/developer/inference-progress.md', '''最近交付：[模型冷构图编译边界](../evidence/correctness/inference-cold-model-boundary-2026-10-30.json)。''', '''最近交付：[冷cache事实与完整状态依赖](../evidence/correctness/inference-cold-cache-facts-2026-10-30.json)。
Qwen私有cache_plan.h只含容量、物理row字节及原checked数学，不持状态／lease／owner；实际叶头编译不引入Compute／Graph，weights与构图实现不再引入Qwen session_state／paged_sequence。
8次CXX、7次链接及15个有限原生进程均成功，其中既有prefix-cache主机24组作为一个进程；只替换228输入中的weights与既有冷对象，226复用，零NVCC／下载，无完整默认CMake构建。
默认完整词表普通／MTP单轮64及双轮128四对全部非计时字段精确一致；两臂各378份／150,761,472字节向量逐字节一致，完整观察只归一输出目录，旧Head／EOS后继续／最终版本0和payload＝known＝plan保持。
单对decode耗时最大正差约0.40%，仅作明显退化诊断，不声明提速。技术依据核本地llama.cpp／vLLM实际源码；Family／Phase及整体跨模型模块化继续。

前片：[模型冷构图编译边界](../evidence/correctness/inference-cold-model-boundary-2026-10-30.json)。''')
replace('docs/developer/inference-progress.md', '''冷探针不再include main，边数16→15；仍有weights.h→session_state.h的传递依赖。''', '''冷探针不再include main，边数16→15；当时仍有weights.h→session_state.h传递依赖，后续已由上述cache事实片拆清。''')
print('UPDATED architecture, roadmap and progress; preserved original line endings')
