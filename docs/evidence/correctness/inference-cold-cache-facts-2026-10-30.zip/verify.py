"""Offline exact comparisons only; no build/native execution or cleanup."""
from pathlib import Path
import hashlib,importlib.util,json
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cache_facts_build',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin=b.read,b.save,b.pin
def norm(value,arm):
 if isinstance(value,str):return value.replace(str(W/'runs'/arm/'session-cuda/attempt1/vectors'),'{VECTORS}')
 if isinstance(value,list):return [norm(v,arm) for v in value]
 if isinstance(value,dict):return {k:norm(v,arm) for k,v in value.items()}
 return value
def delta(a,z,path='$'):
 if type(a)!=type(z):return [dict(path=path,old=a,new=z)]
 if isinstance(a,dict):
  return [item for key in sorted(a.keys()|z.keys()) for item in delta(a.get(key),z.get(key),path+'.'+key)]
 if isinstance(a,list):
  if len(a)!=len(z):return [dict(path=path,old_length=len(a),new_length=len(z))]
  return [item for at,(x,y) in enumerate(zip(a,z)) for item in delta(x,y,path+'['+str(at)+']')]
 return [] if a==z else [dict(path=path,old=a,new=z)]
observations={};vectors={};reports={}
for arm in ('baseline','candidate'):
 folder=W/'runs'/arm/'session-cuda/attempt1/vectors'
 o=read(folder/'observation.json');observations[arm]=o
 reports[arm]=read(folder.parent/'report.json')
 assert o['status']=='PASS_BYTE_EXACT' and o['all_vectors_byte_equal'] and o['all_finite']
 assert o['numerical_tolerance_policy'] is None and o['final_live_snapshot_versions']==0
 assert o['managed_backing_bytes']==o['planned_backing_bytes']==80240691
 assert o['idle_head_full_byte_checks']==4 and o['A_calls_after_B_stop']==3
 for row in o['vectors']:
  assert row['byte_equal'] and row['max_abs']==row['squared_error']==0
  assert row['nonfinite_baseline']==row['nonfinite_actual']==0
 vectors[arm]={path.relative_to(folder).as_posix():pin(path) for path in sorted(folder.rglob('*'))
  if path.is_file() and path.suffix in ('.f32','.bf16','.f16','.bin')}
 assert len(vectors[arm])==378
assert vectors['baseline'].keys()==vectors['candidate'].keys()
entries=[]
for name in vectors['baseline']:
 a,z=(vectors[arm][name] for arm in ('baseline','candidate'))
 assert a['bytes']==z['bytes'] and a['sha256']==z['sha256'],name
 with Path(a['path']).open('rb') as x,Path(z['path']).open('rb') as y:
  while True:
   first,second=x.read(1048576),y.read(1048576)
   assert first==second,name
   if not first:break
 entries.append(dict(relative=name,bytes=a['bytes'],baseline_sha256=a['sha256'],candidate_sha256=z['sha256'],byte_equal=True))
differences=delta(norm(observations['baseline'],'baseline'),norm(observations['candidate'],'candidate'))
report_differences=delta(reports['baseline'],reports['candidate'])
save(W/'session-vector-manifest.json',dict(status='PASS_EXACT_COMPLETE_VECTOR_BYTES',arms=vectors,
 file_count_per_arm=len(entries),bytes_per_arm=sum(row['bytes'] for row in entries),all_cross_arm_bytes_identical=True,
 numerical_tolerance=None,metadata_equal_except_output_root=not differences))
save(W/'session-compare.json',dict(status='PASS_EXACT_COMPLETE_SESSION' if not differences and not report_differences else 'FAIL',
 observation_equal_after_only_output_root_normalization=not differences,ignored_semantic_fields=[],
 normalization='Only each run-specific absolute vectors directory is replaced by {VECTORS}; every remaining field stays exact.',
 differences=differences,report_differences=report_differences,saved_payload_files_per_arm=len(entries),
 saved_payload_bytes_per_arm=sum(row['bytes'] for row in entries),payload_byte_equal=True,payloads=entries,
 scalar_facts={key:value for key,value in observations['candidate'].items() if not isinstance(value,(dict,list))}))
assert not differences and not report_differences,(differences,report_differences)
whole=read(W/'whole-cli-summary.json');assert whole['status']=='PASS_ALL_FOUR_DEFAULT_CASES'
assert all(row['all_non_timing_fields_equal'] and not row['differences'] for row in whole['checks'])
attempts=[]
for directory in ('compile','link','runs'):
 for path in sorted((W/directory).rglob('process.json')):
  process=read(path)
  assert process['state']=='TERMINAL' and not process['timed_out']
  attempts.append(dict(path=path.relative_to(W).as_posix(),exit=process['exit']))
assert not any(row['exit'] for row in attempts)
compact=dict(status='PASS_FINITE_COLD_CACHE_FACTS_BOUNDARY',base_commit=read(W/'baseline-plan.json')['base_commit'],
 full_goal_complete=False,compile=dict(SDK_CXX=1,model_cold_CXX=1,consumers_CXX=4,compile_only_leaf_CXX=1,
 existing_math_test_CXX=1,total_CXX=8,retained=228,unchanged_retained=226,NVCC=0,downloads=0),
 attempts=dict(total=len(attempts),compile=sum(r['path'].startswith('compile/') for r in attempts),
 links=sum(r['path'].startswith('link/') for r in attempts),native=sum(r['path'].startswith('runs/') for r in attempts),failures=0),
 CLI=dict(scenarios=4,processes=8,all_non_timing_fields_exact=True,differences=[],
 timing_diagnostics=[dict(case=r['case'],**r['timing_diagnostic']) for r in whole['checks']],
 scope='One process pair per case; obvious regression diagnostics only, no performance lead or stable timing claim.'),
 Session=dict(processes=2,payload_files_per_arm=len(entries),payload_bytes_per_arm=sum(r['bytes'] for r in entries),
 byte_equal=True,all_metadata_exact_except_output_root=True,differences=[],idle_full_head_checks=4,
 A_calls_after_B_stop=3,final_live_versions=0,payload_known_plan_bytes=80240691,
 metadata_requested_bytes=observations['candidate']['cache_metadata_requested_bytes'],
 live_requested_bytes=observations['candidate']['cache_live_requested_bytes']),
 other_native_checks=['rows-cpu','rows-cuda','history-cpu','natural-control-cuda','math-cpu:24-existing-groups'],
 boundaries=['Limited Qwen cold-facts extraction check, not full architecture or feature exhaustion.',
 'Manual exact CXX/link with reused current cache; full default CMake build was not run; no CMake changes.',
 'Full current source/default full-vocabulary local inputs only; no downloaded data or new performance candidates.'])
save(W/'verification-summary.json',compact)
print(json.dumps({key:compact[key] for key in ('status','attempts','Session')},ensure_ascii=False))
