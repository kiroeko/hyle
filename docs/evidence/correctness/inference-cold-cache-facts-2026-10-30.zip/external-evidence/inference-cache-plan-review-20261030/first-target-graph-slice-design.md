# 第一片：Qwen target 主干的冷构图函数（设计，未实现）

读取基线 `fdae8466b3f32584718234f3ff0e1f0480f76876`。本片只抽 `engine/models/qwen35/main.cc:1880–2083`：embedding → 各层 GDN / self-attention → FFN，返回尚未 final-norm 的 hidden rows 和最后一个真实 append/store 的依赖节点。不迁完整 Family、Phase、编译器或请求生命周期，也不把 Qwen loop 提升成全模型模板。

## 可实施接口

新增模型私有 `target_graph.h/.cc`。下列为具体建议签名；`StateSchema`、`StatePorts`、`Ports` 从 main 原样移到该头，其字段/顺序/default 不改；`FamilyPorts`、Family（含 programs/sampler）、Phase 全留原处。头只需标准库、现有 Graph/slots/TensorDesc、execution_mode；Recipe 可前置声明，实现在 cc include graph_builder/block_graph/cache_plan。

```cpp
// 三个现有描述类型，定义原样迁出；没有 State/Snapshot/LeasePool owner。
struct StateSchema final { c::TensorDesc history, recurrent; };
struct StatePorts final {
  V pool, source_ids, destination_ids;
  g::NodeId gather, store;
};
struct Ports final { V key, value; StatePorts history, recurrent; };

struct TargetGraphInputs final {
  V token_ids, positions, frequencies, attention_metadata;
  V sequence_offsets, history_select; // 仅 packed 分支读取
  std::size_t requests, prefix_rows;
  RowPacking packing;
  std::size_t state_slots;
  std::span<const StateSchema> recurrent_descriptions;
  const c::BatchSchema &plain_attention_schema;
  std::span<const c::BatchSchema> target_attention_schemas;
  std::size_t cpu_ffn_layers;
  g::NodeId preceding_append;
  bool has_preceding_append;
};
struct TargetGraphPorts final {
  std::span<Ports> layers;
  std::span<g::NodeId> attention_nodes;
  std::span<g::NodeId> append_nodes; // 只传 target 的前 2*N 个槽
  std::span<V> append_cache_inputs; // 同上，不给它 draft bank 槽
  std::vector<g::slots::SourceBinding> &state_sources;
  std::span<V, 9> layer0_probes; // 原九个 probe 值，未启用也保持原构图
};
struct TargetGraphResult final {
  V hidden_rows;
  g::NodeId last_append;
  bool has_append;
};
TargetGraphResult emit_target_graph(Recipe &recipe,
    const TargetGraphInputs &inputs, TargetGraphPorts ports);
```

`Recipe` 已借用实际 geometry、权重 bank/projections/meanings、原 GraphAssembly（`graph_builder.h:75–89`），并持有同一个 GraphBuilder/spec/packed-projection 记录；不再传一份 Model 字段集合。函数直接用 `recipe.geometry`、`token_rows/packed_rows`、`assembly` 和 `activation_type()`，无第二个 backend/budget/precision owner。`activation_type()` 来源仍是创建该 Recipe 的同一 GraphAssembly profile，不能额外接受一个可能不一致的 dtype。

这些参数逐项对应实际数学操作：token_ids→embedding，positions/frequencies→原 RoPE 实参，metadata→PagedAttention，sequence_offsets/history_select→packed conv/GDN，requests/prefix_rows/packing→维度与 snapshot_count，state_slots+两种描述→原 slots Schema，具体 attention schemas→目标每层原 cache dtype（含 E4M3），cpu_ffn_layers→原 `ffn_on_cpu(i) == i < cpu_layers()`（`ffn_placement.h:39`）。它们没有 active Step、Session、cache head、page inventory、borrow count、scheduler、map 或 Model 指针。引用/span 仅借到同步冷函数返回，不保存在新对象。

`plain_attention_schema` 与可选 per-target overrides 保留原 `target_attention_schema`（main:1071）选择规则：overrides 为空时用 plain，否则按 `geometry.attention_slot(i)` 选原元素；不能重建“同等”schema。公开形状前置由调用方现有 geometry/cache 准备保证。若实现增加防御校验，只在首次 emit 前检查 span 容量/描述数一致，不把运行接纳或 fallback 决策移入函数。

## 所有者及调用点

仍在 Model 的私有 `unique_ptr<Family>` 候选上分配原端口数组（main:1694–1703）。调用点只将这些数组投影成 span；函数写入它们并向同一 `state_sources` vector 追加真实 Gather/Store 配对。没有新的端口库、缓存、graph 或资源 owner。函数只向 caller 的同一 Recipe 追加节点；新返回的 `hidden_rows/last_append/has_append` 替代原局部 `x/prior_append/has_prior_append`。

传入的 `preceding_append` 是原 MTP draft 的真实尾 append（main:1883–1886），其布尔条件保持 `has_mtp(role) && !is_mtp_prefill(role)`；target append 的依赖排序仍逐字保留。函数不得创建/提交 Source ticket、访问 pending bytes 或“恢复”请求。权重、literal、read lease 的保存仍通过原 Recipe/GraphAssembly；常量归属不经这个接口转移。

前后顺序不变：原 hidden destination 输入已经在 main:1713–1721 创建，`prepare_cache()` 仍在 :1726，MTP projection / `prepare_draft_vocabulary` 仍在 :1846；再调用 target emit；:2084 起的 probe publish、final norm、MTP prefill maintenance、sampling/acceptance、successor outputs 仍使用上述结果。不为了干净接口提前创建 paged arenas 或 selected-row head。函数也不 finish Graph；main:2208 的 finish、literal/spec move、finite variants、compile、PreparedProgramFamily.prepare、统计、完整成功后 emplace（:2263）保持原位置。

因此任何 throw / compile failure / supported packed-route `false` 仍由原未发布候选和原 scope 清理，保留既有错误/fallback类别及重试规则。数学代码搬迁不等于可以调整 resource failure 顺序。

## 必须保持的细节与实际传播收益

`:1880–2083` 中 GDN history 保存原 activation bytes、F32 recurrent、Copy/reshape、packed prefix snapshot_count、gated-RMS/FFN 调用、RoPE half-split、target cache E4M3 encode、append-before-attend 依赖、九个 probe 填充和 CPU FFN Scope 全部保留；不顺手简化 cast 或把公共节点数当 native dispatch。首片只需要上述局部别名/输入投影的重命名比对，不应重写方程。

`target_graph.cc` 加到现有唯一 `cold_sources.cmake`，engine 与九个测试消费者自动沿原 inventory 获取它；不另建注册表/静态库/第二份清单。main include target_graph.h 并删除这三个描述类型和主干 body；完整 Family 不进入 graph_builder.h，因此不存在 Recipe↔Family↔Model 循环。独立模块配置不加载 Qwen inventory 的当前 guard 原封保留。

当前 main 是 canonical TU 加 15 个 include-main TU 的依赖。主干方程的私有 cc 修改之后只需重编该冷实现（及正常链接），不会使这些入口重新解析/编译 main；真正更改端口/描述合同才修改新头并重编使用方。该收益是依赖传播和所有者解耦，不宣称执行加速。Recipe 单独消费者无需 include target_graph.h；全量 cold inventory 仍可能给它链接一个未使用对象，这是现有 per-target 实现方式，应如实计入构建成本。

## 为什么这一片不能变成通用模型 loop

现有 GLM 组件给出了真实不同需求，而非另一个完整 engine：`tests/compute_models/d5_glm_remaining_fragments.h:211–228` 的 Flash trunk residual 是 `[1,4,H]` mHC；`:622–673` 的 MLA cache 是压缩 latent + 可选 64 RoPE（interleaved），不是 Qwen 每层 GDN history/recurrent 或 key/value 两个同形 bank；`:747–780` 明确 NextN 又用普通 residual、没有 trunk mHC。`glm_target_verifier_fragment.h:21–63` 的原头为 BF16 `[2,4096]` taps × `[154880,4096]`，要求 target final-norm 之后，不能复用 NextN shared-head norm。

所以本片不抽全局 `ModelLayer`/万能 FamilyPorts、统一“所有 cache 都 K/V”、或强制给有限具体 GLM 图制造 ColdShapePlan/PreparedProgramFamily。GLM/其他模型应复用既有 GraphBindings、原 Compute/Graph、slots/program/output 原语；只有实际相同的冷组合需求才继续上提。后续共同模块候选是有限 exact variants 与原 compile/report/output/resource-facts 配对；当前 `PreparedProgramFamily` 已是共用模块，额外提取需有第二个真实使用需要，不能为消除文件差异再复制它。

这片为后续模型提供的是可评估的“模型 emit → 原图/资源准备”边界与小描述端口合同；它尚未替所有模型消除冷装配重复。完整 Family 图（尤其 draft-head 的准备/投影事实）与 Phase IO/slot 准备仍列为下一片，不能记作已完成。

## 实施后的有限检查建议（当前未运行）

静态逐操作/端口顺序/字面量/常量绑定比较；新 cc 的实际编译依赖应无 main、Session/State/Snapshot headers；cold rows 原独立消费者保持可用。复用当前普通/MTP default 四对及真实 Session 完整向量严格比较，另保留含 GDN+attention、packed/verify 和 CPU placement 的现有有限消费者，不新增虚假全模型资格。性能只保留明显退化观察，不启动独立候选；构建与验证范围由 root 按最终 diff 选择。
