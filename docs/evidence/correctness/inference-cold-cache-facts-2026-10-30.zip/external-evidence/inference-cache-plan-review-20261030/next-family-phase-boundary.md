# Qwen Family / Phase 后续边界盘点（只读）

基线 `fdae8466b3f32584718234f3ff0e1f0480f76876`；本次读取的是 cache_plan 三文件修改后的当前工作树。本文只列下一步可用的边界，不启动迁移、构建或性能候选。`static-cache-facts-review.json` 单独记录这次事实头拆分的文本与依赖检查；`reference-cache-boundaries.json` 记录实际本地 llama.cpp / vLLM source pins 与有限技术依据。

## Family：数学定义与有限编译结果

实际载体在 `engine/models/qwen35/main.cc:399`（FamilyPorts）、`:419`（Family）；构造入口 `:1635`（prepare_family）。

| 分类 | 当前真实内容 | 拆分时应保留的职责 |
| --- | --- | --- |
| 模型事实 | geometry、precision、weights、projections、weight_meanings、target/draft cache schema、prepared sampling、显式 draft head/map | Qwen 数学、dtype、shape、端口顺序和字面量；借用同一份已经准备好的权重与采样配置 |
| 准备请求 | planned_chunks、requests、GraphRole、TextCompletion、sampling_index、RowPacking、diagnostic / admitted_exact | 精确 family signature 与有限 variants；校验支持的模型形状，不能把任意 hot shape 偷换成运行中编译 |
| 执行准备事实 | 原 Backend、CompileOptions、allocation/execution budgets、attention schema、cache_plan 容量 | 调用既有 Graph / Backend 编译并返回原 report/executable 配对；不复制运行器或资源控制器 |
| 结果 | FamilyPorts、graph、specs、literals、attention_schema、PreparedProgramFamily、last_row、chunks | 维持一次构造、多 child 借用；失败/不支持时不发布残缺 Family |

这不是单纯把整个 `prepare_family` 移到新文件：入口目前还访问 `preparation_started_`、`state_storage_prepared`、`active_step`、`carrier_borrowed`（`:1655–1659`），准备 cache（`:1726`）、更新诊断/compiled-storage 记录（`:2256`），并向 `ColdResources::families / probe_families` 发布（`:2263`）。这些是原 Model 的准入、状态准备、诊断及发布职责。可先提取一个显式输入的模型本地 Family 构造函数；调用方继续在原所有者处完成 idle/admission 检查及成功后发布，而不是让数学构造接口借用 Model / Session / active Step。

`GraphAssembly::literals` 在 `:2209` 移入 Family，`Family::literals` 的原注释明确要求 backing 活过 children/slots（`:426`）；prepared sampling 指针也指向原 `ColdResources` 持有的 stable 对象。这些寿命是边界的一部分，不能为了接口轻巧把它们改成临时 span 或复制第二份所有权。

## Phase：精确程序的物理载体准备

实际载体在 `main.cc:449`（PhaseIo）、`:466`（Phase）；入口 `:3297`（prepare_child），调用方 `:3567`（prepare_execution）。

| 分类 | 当前真实内容 | 拆分时应保留的职责 |
| --- | --- | --- |
| 选择结果 | FamilyChild 的 Family 引用和同一 PreparedProgram 引用；精确 query_rows / role / completion / packing / imported_sources | 继续用同一 executable/report/output facts，不重新猜输出或改变 exact child |
| 物理准备事实 | Backend queue bindings、storage domains、resource budgets、cache/state schema、shape_plan planned uses、ReplayPolicy、物理 slot count | 原 ProgramSlots / ProgramIo / SlotTransactionSpec，固定输入/readback/调用者输出绑定和资源布局 |
| 结果 | 复制的 FamilyPorts、state_banks、原 ProgramSlots<ColdResources,PhaseIo,3>、output-facts 指针、caller tensors、replay mode | 不新增 ledger 或 executor；原 slot/transaction/native retirement 持有并复用原资源 |

`prepare_child` 还负责查找/发布 `ColdResources::phases / probe_phases`（`:3302`、`:3561`）、模型允许的 imported-carrier 条件（`:3309` 起）、已准备 state pool 的 transaction layout 接线（`:3506`）、trace 文件和诊断（`:3507` 起），以及 `input_scratch.prepare(phase)`（`:3560`）。因此 Family 数学构造与 Phase 物理准备应是两个小边界；不能合成一个包含 Session、借用中的 snapshot 或运行中 request 的万能 factory。

Phase 可以引用 Family，因为 `ColdResources` 用 unique_ptr map 持有两者（`:895–896`），并将原 Backend retirement endpoint 留在同一寿命容器（`:872–876`）。成功完成后才 emplace 的当前规则必须继续成立；发布前失败应由原资源对象清理。

## 明确留在原边界的运行语义

`prepare_execution` 的 idle 检查与有限 exact admission、`prepare_relay_execution` 的合法形状检查、slot 初始化仍由原 Model orchestration 决定。当前 `detach_episode`、`try_retire_episode` 等 recovery、原 snapshot/page/version ownership 不属于这次 facts-header 拆分，也不应以“cold factory”名义移动或重写。下一片应先隔离 Family 的显式事实输入、完整构造结果和原资源寿命；之后再评估 Phase 准备所需接口。本文不声称整个架构已完成。

## 这次 cache_plan 的边界

新 `cache_plan.h` 保留原 `qwen35::cache` 全名、字段/default/inline checked 算法及公式；其 include closure 为标准库和 `model_geometry.h`。`weights.h` / `graph_builder.h` 不再通过它解析 Qwen `session_state.h`、Snapshot、VersionRef / StatePools 或 `paged_sequence.h`。它们仍有真实的 Compute / Graph / weight ReadLease 依赖；`.cc` / native probe 显式 Backend 还可能需要通用 runtime core 类型，这些依赖不是本片要伪装消失的内容。实际编译依赖与有限消费者验证由 harness 另行提供；本片静态检查不代签构建或性能。
