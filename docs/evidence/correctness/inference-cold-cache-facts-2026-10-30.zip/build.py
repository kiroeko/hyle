"""Cold cache-facts boundary: replace only actually affected cached objects."""
from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('prior_cold_model_build',R/'.scratch/inference-cold-model-boundary-20261030/build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.W=W;b.BASE=R/'.scratch/inference-cold-model-boundary-20261030/model-link-base.json';b.s.W=b.s.b.W=W
read,save,pin,exact,key=b.read,b.save,b.pin,b.exact,b.key
BASE=b.BASE
def baseline():
 b.prepare_baseline()
 p=read(W/'baseline-plan.json');base=read(BASE);receipt=read(base['current_consumers']['session']['receipt']['path'])
 proofs=[]
 for item in [receipt['object'],*p['retained']]:exact(item)
 for item in receipt['source_identities']:
  path=Path(item['path']);data=path.read_bytes()
  if len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']:proofs.append(dict(identity=item,proof='CURRENT_EXACT'))
  else:
   relative=path.relative_to(R).as_posix();old=subprocess.check_output(['git','show',p['base_commit']+':'+relative],cwd=R)
   assert len(old)==item['bytes'] and hashlib.sha256(old).hexdigest()==item['sha256'],relative
   target=W/'baseline-source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(old)
   proofs.append(dict(identity=item,proof='EXACT_COMMITTED_BASELINE_SNAPSHOT',snapshot=pin(target),commit=p['base_commit']))
 for relative in ('engine/models/qwen35/session_state.h','engine/models/qwen35/graph_builder.h','engine/models/qwen35/graph_builder.cc'):
  target=W/'baseline-source'/relative;target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(subprocess.check_output(['git','show',p['base_commit']+':'+relative],cwd=R))
 save(W/'baseline-session-plan.json',dict(receipt=base['current_consumers']['session']['receipt'],object=receipt['object'],source_proofs=proofs,
  closure='Exact original228 inputs including original cold builder; no candidate/new headers compiled into baseline objects.'))
 old=W.parent/'inference-cold-model-boundary-20261030/session-input';local=W/'session-input';local.mkdir()
 for name in ('weights.tsv','prompt.ids'):shutil.copyfile(old/name,local/name)
 fixture=R/'.scratch/inference-paged-frame-20261026/tiny-recursive-input'
 save(W/'extra-cases.json',{
  'rows-cpu':dict(consumer='rows',args=['cpu',str(fixture/'weights.tsv'),str(W/'metadata-cpu')]),
  'rows-cuda':dict(consumer='rows',args=['cuda',str(fixture/'weights.tsv'),str(W/'metadata-cuda')]),
  'natural-control-cuda':dict(consumer='tiny',args=['--cuda',str(fixture),'--natural-logits-control']),
  'session-cuda':dict(consumer='session',args=['--backend','cuda','--inputs',str(local),'--output','{OUTPUT}','--scenario','sessions'],expected_status='MTP_SESSION_PROBE_COMPLETED'),
  'math-cpu':dict(consumer='math',args=[])})
 print('BASELINE_SESSION_SOURCE_PROOFS',len(proofs),';228original cache inputs; no compile/native/download.')
def link_baseline_session(attempt):
 p=read(W/'baseline-plan.json');s=read(W/'baseline-session-plan.json')
 for item in [s['object'],*p['retained']]:exact(item)
 args=[];count=0
 for arg in p['link']:
  if key(arg)==key(p['cli_object']['path']):arg=s['object']['path'];count+=1
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/baseline-session').with_suffix(suffix));break
  args.append(arg)
 assert count==1;b.s.b.execute(args,W/'link/baseline-session'/attempt,240);save(W/'ready-baseline-session.json',pin(W/'bin/baseline-session.exe'))
def prepare():
 assert not (W/'plan.json').exists()
 base=read(BASE);sdk=read(base['sdk_engine_dependencies']['path']);baseline=read(W/'baseline-plan.json')
 changed={key(R/name) for name in subprocess.check_output(['git','diff','--name-only','--','include','src','engine'],cwd=R,text=True).splitlines()}
 rows={key(row['object']):row for row in sdk['inspected']}
 rows.update({key(row['object']):row for row in sdk['engine_consumers'] if 'dependencies' in row})
 units={};actual=[];unavailable=[]
 for item in base['retained']:
  exact(item);obj=Path(item['path']);row=rows.get(key(obj))
  for path in (obj.parent/'dependencies.json',obj.with_name(obj.stem+'-deps.json'),obj.with_suffix('.deps.json')):
   if path.is_file() and 'Data' in read(path):row=dict(object=str(obj),dependencies=pin(path));break
  if row is None:unavailable.append(str(obj));continue
  actual.append(row);deps=read(row['dependencies']['path'])['Data']
  if not any(key(path) in changed for path in [deps['Source'],*deps['Includes']]):continue
  command,recipe=b.s.command_for(obj,deps['Source'])
  name='cold' if Path(deps['Source']).name=='graph_builder.cc' else 'weights' if Path(deps['Source']).name=='weights.cc' else 'sdk-'+Path(deps['Source']).stem
  assert name not in units
  units[name]=dict(source=deps['Source'],original=item,recipe=recipe,old_dependencies=row['dependencies'],compile=b.s.relocated(command,name))
 assert {'weights','cold'}<=units.keys(),units
 wrapper=W/'cli.cc';wrapper.write_text('#include "../../engine/models/qwen35/main.cc"\nint main(int argc,char **argv){return qwen35::run(argc,argv);}\n')
 leaf=W/'cache-plan-header.cc';leaf.write_text('#include "../../engine/models/qwen35/cache_plan.h"\n')
 sources={'cli':wrapper,'tiny':R/'tests/tools/qwen_host_image_test.cc','rows':R/'tests/tools/qwen_draft_vocabulary_probe.cc',
  'session':R/'engine/models/qwen35/mtp_session_probe.cc','math':R/'tests/tools/qwen_prefix_cache_test.cc','leaf':leaf}
 consumers={name:dict(source=str(source),compile=b.s.relocated(base['compile'],name,source)) for name,source in sources.items()}
 consumers['math']['compile'].insert(1,'/DHYLE_PREFIX_CACHE_STANDALONE=1')
 save(W/'plan.json',dict(base=pin(BASE),base_commit=baseline['base_commit'],retained=base['retained'],runtime=base['runtime'],sdk=base['sdk_engine_dependencies'],
  original_link=base['link'],original_consumer=baseline['cli_object']['path'],actual_dependency_rows=actual,unavailable_dependencies=unavailable,
  units=units,engine_units={},consumers=consumers,cases=baseline['cases'],SDK_CXX=len(units)-1,model_cold_CXX=1,new_engine_objects=0,
  unchanged_retained=len(base['retained'])-len(units),NVCC=0,downloads=0,max_compilers=2,
  scope='Actual dependency scan of all228 inputs; existing weights/cold objects replaced in place, never duplicated or appended to closure.'))
 print('PREPARED affected',list(units),'unchanged',len(base['retained'])-len(units),'consumer recipes',list(consumers))
def link(name,attempt):
 p=read(W/'plan.json');receipt=read(W/'compile'/name/'receipt.json');replacements={}
 for unit,old in p['units'].items():
  current=read(W/'compile'/unit/'receipt.json')
  for item in [current['object'],*current['source_identities']]:exact(item)
  replacements[key(old['original']['path'])]=current['object']
 retained=[replacements.get(key(item['path']),item) for item in p['retained']]
 for item in [receipt['object'],*receipt['source_identities'],*retained]:exact(item)
 args=[];count=0
 for arg in p['original_link']:
  if key(arg)==key(p['original_consumer']):arg=receipt['object']['path'];count+=1
  if key(arg) in replacements:arg=replacements[key(arg)]['path']
  for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
   if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
  args.append(arg)
 assert count==1
 b.s.b.execute(args,W/'link'/name/attempt,240);save(W/('ready-'+name+'.json'),pin(W/'bin'/(name+'.exe')))
def run_math(attempt):
 image=read(W/'ready-math.json');exact(image);folder=W/'runs/candidate/math-cpu'/attempt
 save(folder/'image.json',image);b.s.b.execute([image['path']],folder,120)
 lines=[line for line in (folder/'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
 assert len(lines)==24 and all(line.startswith('PASS ') for line in lines),lines
 save(folder/'report.json',dict(status='PASS_EXISTING24_HOST_GROUPS',groups=24,checks=lines,
  scope='Existing qwen_prefix_cache_test standalone entry, actual cache math/capacity/overflow/heterogeometry and CPU permission contracts; no model or GPU inference.'))
 print('PASS math-cpu existing24groups')
if __name__=='__main__':
 action=sys.argv[1]
 if action=='baseline':baseline()
 elif action=='link-baseline':b.link_baseline(sys.argv[2])
 elif action=='link-baseline-session':link_baseline_session(sys.argv[2])
 elif action=='prepare':prepare()
 elif action=='compile':b.compile_group(sys.argv[2],sys.argv[3:])
 elif action=='link':link(sys.argv[2],sys.argv[3])
 elif action=='run':
  if sys.argv[2]=='math-cpu':run_math(sys.argv[3])
  else:b.run(sys.argv[2],sys.argv[3],len(sys.argv)>4 and sys.argv[4]=='baseline')
 else:raise ValueError(action)
