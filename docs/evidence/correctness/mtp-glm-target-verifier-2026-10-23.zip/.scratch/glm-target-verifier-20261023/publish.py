"""Publish completed BS checks; include no weight bodies or native binaries.

Prepared before native results. Root supplies actual successful run/link indices
and writes source-final/freeze.json before executing this publisher.
"""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
D = R / 'docs/evidence/correctness'
NEW = 'OriginalNextNFullVocabularyTargetVerifierPublishesActualPending'
RELATED = 'OriginalMoeCompletesNextNAndFeedsBackAcrossSeedAndCatchup'
TEXT_SUFFIXES = {'.h', '.hh', '.hpp', '.c', '.cc', '.cpp', '.py', '.mjs',
                 '.json', '.txt', '.log', '.xml', '.ps1', '.diff', '.rsp', '.cmd'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else R / path).resolve()


def identity(path):
    path = resolve(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(path=path.relative_to(R).as_posix() if path.is_relative_to(R) else str(path),
                bytes=path.stat().st_size, sha256=digest)


verified = {}


def verify(row):
    path = resolve(row['path'])
    if path not in verified:
        verified[path] = identity(path)
    actual = verified[path]
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']
    return path


def integer(properties, key):
    value = int(properties[key])
    assert value >= 0, (key, value)
    return value


def guard_pair(cases, suffix):
    expected = {f'Cpu{suffix}', f'Cuda{suffix}'}
    assert len(cases) == 2 and {case['attributes']['name'] for case in cases} == expected


def protect(before):
    protected = before['protected_qwen_image']
    # Deliberately hash again when called after publication: this is a protected
    # existing Qwen image, never an input copied into this evidence archive.
    protected = protected.get('image', protected)
    actual = identity(protected['path'])
    assert actual['bytes'] == protected['bytes'] and actual['sha256'] == protected['sha256']
    work = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8-sig')
    tail = work[work.index('## 最新完整性能对比'):]
    digest = hashlib.sha256(tail.encode()).hexdigest()
    assert digest == before['protected_performance_tail_sha256']
    return digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', type=int, nargs='+', required=True)
    parser.add_argument('--link-attempt', type=int, required=True)
    parser.add_argument('--freeze', default='source-final')
    args = parser.parse_args()
    indices = args.runs
    assert all(index > 0 for index in indices) and len(set(indices)) == len(indices)

    image_path = S / f'tests-link{args.link_attempt}/ready.json'
    image = read(image_path)['image']
    verify(image)
    summaries = [S / f'checks{index}/summary.json' for index in indices]
    runs = [read(path) for path in summaries]
    for run in runs:
        assert run['image'] == image
        assert run['process']['exit'] == 0 and not run['process']['timed_out']
        assert run['tests'] == len(run['cases'])
        assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
        assert run.get('throughput_evidence') is False and run.get('physical_memory_evidence') is False
        assert run.get('whole_original_model') is False
        for case in run['cases']:
            assert case['attributes'].get('status') == 'run'
            assert case['attributes'].get('result') == 'completed'

    all_cases = [case for run in runs for case in run['cases']]
    new = [case for case in all_cases if case['attributes']['name'].endswith(NEW)]
    related = [case for case in all_cases if case['attributes']['name'].endswith(RELATED)]
    assert len(all_cases) == len(new) + len(related)
    guard_pair(new, NEW)
    guard_pair(related, RELATED)
    for case in new:
        props = case['properties']
        expected = dict(full_original_nextn_roles='1762', full_original_nextn_source_bytes='10030953088',
                        target_full_vocabulary='154880', target_first_full_reference_values='309760',
                        target_verifier_submissions='3', natural_k1_trials='1',
                        controlled_matching_trials='1', controlled_rejection_trials='1')
        for key, value in expected.items():
            assert props[key] == value, (case['attributes']['name'], key, props.get(key), value)
        assert integer(props, 'natural_k1_accepted_drafts') in (0, 1)
        assert 0 <= integer(props, 'natural_k1_proposal') < 154880
        assert integer(props, 'accepted_zero_draft_checkpoints') > 0
        assert integer(props, 'accepted_one_draft_checkpoints') > 0
        assert integer(props, 'actual_pending_embedding_feedback_checks') > 0
        assert integer(props, 'peak_state_backing_bytes') <= integer(props, 'state_budget_bytes')
        if case['attributes']['name'].startswith('Cuda'):
            assert props['target_verifier_head_provider'] == 'cublasLt'
    for case in related:
        props = case['properties']
        assert props['original_roles'] == '1762' and props['original_role_bytes'] == '10030953088'
        assert props['moe_global_expert_domain'] == '288' and props['moe_resident_expert_capacity'] == '8'

    # Runtime counters are authoritative. Natural accept0/1 can change the new
    # journey's count; neither expected branch nor a previous run fixes it here.
    new_graphs = sum(integer(case['properties'], 'actual_submissions') for case in new)
    related_graphs = sum(integer(case['properties'], 'actual_submissions') for case in related)
    assert new_graphs > 0 and related_graphs > 0
    graphs = new_graphs + related_graphs

    freeze_path = S / args.freeze / 'freeze.json'
    freeze = read(freeze_path)
    frozen = {}
    for key in ('source', 'dependencies', 'fixed_dependencies', 'files'):
        for row in freeze.get(key, []):
            path = verify(row)
            if path in frozen:
                assert frozen[path]['sha256'] == row['sha256'] and frozen[path]['bytes'] == row['bytes']
            frozen[path] = row
    assert {R / 'tests/compute_models/glm_mtp_state_consumer_test.cc',
            R / 'tests/compute_models/glm_target_verifier_fragment.h'} <= frozen.keys()

    link_path = S / f'tests-link{args.link_attempt}/link-plan.json'
    runtime_path = link_path.with_name('runtime-environment.json')
    link = read(link_path)
    runtime = read(runtime_path)
    for key in ('SDK_builds', 'native_CPU_builds', 'NVCC_builds', 'shaders'):
        assert link[key] == 0
    for row in link['inputs']:
        verify(row)
    compiled_records = []
    for row in link['compiled_records']:
        path = verify(row)
        if path.is_relative_to(S):
            compiled = read(path)
            for item in (compiled['source'], compiled['object'], *compiled['dependencies']):
                verify(item)
            assert resolve(compiled['source']['path']) in frozen
            compiled_records.append(path)
    assert len(compiled_records) == 1
    for row in runtime['staged_dlls']:
        verify(row)

    before = read(S / 'before.json')
    tail_hash = protect(before)
    sources = sorted(frozen)
    # Reused metadata authenticates provenance without rehashing or archiving
    # the existing multi-GB weight bodies; native loaders already checked pins.
    provenance = [R / 'docs/evidence/correctness/mtp-glm-original-moe-2026-10-23.json',
                  R / '.scratch/glm-original-moe-20261023/original-moe/acquisition.json']
    assert all(path.is_file() for path in provenance)
    docs = [R / 'docs/developer/current-work.md', R / 'docs/implementation/model-operators.md']
    files = set(sources + provenance + compiled_records + docs)
    files.update(path for path in S.rglob('*') if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES)
    files.discard(S / 'publication.json')
    for path in files:
        assert path.resolve().is_relative_to(R)
        assert path.suffix.lower() in TEXT_SUFFIXES or path in docs, path
        assert path.stat().st_size < 10_000_000, path
    destination = D / 'mtp-glm-target-verifier-2026-10-23.json'
    archive = D / 'mtp-glm-target-verifier-2026-10-23.zip'
    assert D.is_dir() and not destination.exists() and not archive.exists()
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as zipped:
        for path in sorted(files):
            zipped.write(path, path.relative_to(R).as_posix())

    record = dict(date='2026-10-23', stage='BS', goal_complete=False,
        conclusion='The complete original Flash NextN and a full-vocabulary target verifier now supply actual K1 decisions and pending-token leases to the existing complete-state journey on the listed CPU/CUDA cases.',
        artifact=dict(original_nextn_roles=1762, original_nextn_source_bytes=10030953088,
            vocabulary=154880, hidden=4096, verifier_rows=2, reused_original_weights=True,
            new_weight_downloads=False, weight_bodies_archived=False),
        implementation=dict(
            verifier='Two actual final-normalized target taps cross an explicit BF16 store, then one BFloatLinearF32 projects both rows through the same original readonly full-V head used by NextN. StableTopK1 and independent I32[1] Copy outputs retain each predicted token as an actual output lease; no second sharednorm, F32 head shadow or per-Recipe vocabulary upload.',
            decision='K1 compares the actual original NextN proposal with target_id0. Zero accepted drafts select first after consuming the mandatory current token; one accepted draft selects second after consuming that actual proposal. nextpending retains row_ids[accepted_drafts] directly. Zero acceptance never selects the pre-current base.',
            state='Target43/44 and complete NextN outputs remain one34-resource StateDraft/expected-base StateHead. Fresh draft-extend uses the previous accepted target tap; accepted journal catchup precedes epoch8 fresh. The published fresh seed is activated and drives an actual same-epoch skip0 candidate, which remains unpublished pending verification.',
            controlled_cases='One natural finite fixture trial per backend is recorded separately from one controlled match and one controlled reject. Each control recomputes its own second target/draft checkpoint using the corresponding actual policy token; controls do not contribute to natural acceptance.',
            numerical_scope='Existing original-byte full-V BF16/F64 oracle checks both rows on the first verifier call; later actual candidates and every full-V greedy selection, stored tap, pending and original embedding feedback retain their local actual-predecessor checks. No new tolerance or native reference batches.',
            target_boundary='Layer42 upstream four-stream inputs, target43/44 parameter values and finite initial histories remain explicitly generated. Computed target43 MLA/indexer/mHC/FFN and target44 KDA/conv/mHC/finalnorm are executable fixtures, not authenticated original target layers.'),
        validation=dict(tests=len(new) + len(related), failures=0, errors=0, skips=0,
            graph_submissions=graphs, new_graph_submissions=new_graphs,
            related_graph_submissions=related_graphs, new_cases=new, related_cases=related,
            natural_trials=sum(integer(case['properties'], 'natural_k1_trials') for case in new),
            controlled_matching_trials=sum(integer(case['properties'], 'controlled_matching_trials') for case in new),
            controlled_rejection_trials=sum(integer(case['properties'], 'controlled_rejection_trials') for case in new),
            first_full_target_reference_values=sum(integer(case['properties'], 'target_first_full_reference_values') for case in new),
            results=[identity(path) for path in summaries], source_freeze=identity(freeze_path),
            linked_inputs=identity(link_path), runtime_cache=identity(runtime_path),
            compiled_records=[identity(path) for path in compiled_records], host_translation_units=1,
            host_compile_attempts=len(list(S.glob('compile*/*/plan.json'))),
            SDK_builds=0, native_CPU_builds=0, NVCC_builds=0, shaders=0),
        limitations=[
            'Finite Windows CPU/CUDA Flash H4096/V154880 R2 K1 integration only; parameterized helper support does not establish Pro execution.',
            'Target43/44 parameters, upstream layer42 inputs and initial history remain generated; no original complete target engine or full-model task-quality result.',
            'The single natural fixture is not a natural acceptance benchmark; controlled matching/rejection only cover decision/checkpoint branches.',
            'Local actual-predecessor mathematical checks and state/lease correctness do not prove all inputs, systems, quantizations or complete task quality.',
            'No new loading/TPS or measured memory/VRAM peak result. AV performance tail and the protected Qwen executable are unchanged.',
            'MTP, image projection and the broader goal remain incomplete.'],
        remaining='Authenticated original target producers/taps and confirmed applicable artifact adapters, including actual Pro geometry; necessary related regressions and a complete ordinary/MTP performance comparison before image projection.',
        final_image=image, sources=[identity(path) for path in sources],
        reused_provenance=[identity(path) for path in provenance],
        performance_tail_sha256=tail_hash, protected_qwen_image=before['protected_qwen_image'],
        archive=identity(archive), archive_items=len(files))
    destination.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    publication = dict(evidence=identity(destination), archive=identity(archive))
    (S / 'publication.json').write_text(json.dumps(publication, indent=2) + '\n', encoding='utf-8')
    assert protect(before) == tail_hash
    print(json.dumps(dict(**publication, tests=len(new) + len(related), graphs=graphs)))


if __name__ == '__main__':
    main()
