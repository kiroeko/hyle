from pathlib import Path
import hashlib,json,shutil
base=Path('.scratch/glm-target-verifier-20261023')
def ident(p):
 p=Path(p);b=p.read_bytes();return {'path':p.as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
p=Path('tests/compute_models/glm_target_verifier_fragment.h');q=base/'verifier-source/frozen'/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
r={'scope':'Source-only pure GLM finalnormalized targettap/fullVhead fragment and greedyK1 policy. No loader/executor/providerselection/new numericaloracle/tolerance/native/build/download.',
 'source':ident(p),'snapshot':ident(q),'contracts':{
 'input':'Exactly plain dense BF16[2,4096] AFTER target model.norm, and dense original untied BF16head[154880,4096]. InvalidValueId ordinals ordescriptor mismatch failcold. FixedR2/H/V andfitI32vocabulary avoiddynamicextent/indexoverflow. No implicit F32Cast, NextNsharednorm, secondRMS, callerheadcopyornewbank.',
 'graph':'Exactlyone publicBFloatLinearF32 produces F32[2,154880]; onestableTopK1 producesF32scores[2,1]/I32IDs[2,1]. Two ordinaryslice+reshape+Copy chains produce independentI32[1] row outputs. FragmentreturnsValueIDs only; callerdecidespublication/ordinaryimmutableconstantbinding. No aliasedView is advertisedasexternalwriteroutput.',
 'policy':'decide_k1 acceptsoneactualproposalI32 andtwoactualtargetIDs, rangechecksallagainstV. Equalityproposal==target0 givesaccepted_drafts1 else0. next_pending_row=accepted_drafts,next_pending=targetIDs[accepted_drafts]. Hostvalue isdiagnosticonly: callerbindsthecorrespondingactualrow_ids outputlease intoStateDraft pending, notuploading reconstructedtoken.',
 'checkpoint':'StrongCheckpointenum excludesprecurrentbase: kAfterCurrent=first consumedmandatorycurrenttoken t0, kAfterProposal=second consumedactualproposal1. Accepted0choosesfirst, accepted1second; thisisnotearlierbase/first finiteprefix selector. Candidate includesbothTarget/NextNstate andpendingcorrectionbeforeoneStateHeadpublish.',
 'math_validation':'Consumerreusesexisting glm_shared_vocabulary_reference::expect_logits multirow actualBF16/originalhead bytes andexpect_greedy actualfullVstableIDs/scores. No newgate. Runtimefinitevalues/quality are numericalconsumer checks, notpretendedcoldmetadata checks.'},
 'limits':'Pure sourcecontract only; trueupstream targetidentity/tapnormalization andactualproposal provenance are callerresponsibilities. Connectinggeneratedtarget43/44 tooriginalfullVhead provesdeclaredboundary math/state/policy, nottrainedtargetquality/naturalacceptance. Rootowns nativecompilation/runs.'}
out=base/'verifier-source/freeze.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(ident(out));print(ident(p))
