"""Prepare one cached-TU build for actual shared-head K1 target verification."""
from pathlib import Path
import ast
import datetime
import hashlib
import json

S=Path(__file__).resolve().parent
R=S.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def identity(p):
    with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=digest)
prior=read(R/'.scratch/q24-original-nextn-20261023/before.json')
work=(R/'docs/developer/current-work.md').read_text(encoding='utf-8')
tail=work[work.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest()==prior['protected_performance_tail_sha256']
before=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_goal_turn_classification='progress: BR authenticated originalQ24 full22roles,CPU/CUDA eightcases50Graphs anddurable evidence/currentfacts',
    prior_publication=read(R/'.scratch/q24-original-nextn-20261023/publication.json'),
    protected_performance_tail_sha256=prior['protected_performance_tail_sha256'],
    protected_qwen_image=prior['protected_qwen_image'],
    source=[identity(R/'tests/compute_models/glm_mtp_state_consumer_test.cc')])
(S/'before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
text=(R/'.scratch/glm-original-moe-20261023/build.py').read_text(encoding='utf-8')
changes=[
    ('Incremental original GLM MoE and shared resident-fragment consumers.', 'Incremental GLM actual target shared-head K1 verification and related state consumers.'),
    ("BH = R / '.scratch/glm-original-attention-20261023'", "BH = R / '.scratch/glm-original-moe-20261023'"),
    ("BASE = BH / 'tests-link2'", "BASE = R / '.scratch/q24-original-nextn-20261023/tests-link3'"),
    ("'glm-state': R / '.scratch/glm-original-attention-20261023/compile2/glm-state/identity.json'", "'glm-state': R / '.scratch/glm-original-moe-20261023/compile1/glm-state/identity.json'"),
    ("    'dspark-state': R / '.scratch/dspark-original-experts-20261023/compile4/dspark-state/identity.json',\n", ''),
    ("    'dspark-state': R / 'tests/compute_models/dspark_original_state_consumer_test.cc',\n", ''),
    ("str(S / 'original-moe')", "str(R / '.scratch/glm-original-moe-20261023/original-moe')"),
    ("str(BH / 'original-attention')", "str(R / '.scratch/glm-original-attention-20261023/original-attention')"),
    ('glm-original-moe-checks.exe', 'glm-target-verifier-checks.exe'),
    ('original GLM MoE and resident-fragment checks', 'GLM actual target verifier and related state consumers'),
]
for old,new in changes:
    assert old in text,old
    text=text.replace(old,new)
ast.parse(text)
output=S/'build.py'
assert not output.exists()
output.write_text(text,encoding='utf-8',newline='\n')
print('PREPARED',S,'onehostTU; BR coreclosure; reusecached originalGLM payloads; no newweight download')
