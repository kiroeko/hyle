"""Record completed BS results and terminal process state after publication."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

S = Path(__file__).resolve().parent
R = S.parents[1]
publication = json.loads((S / 'publication.json').read_text(encoding='utf-8'))
record = json.loads((R / publication['evidence']['path']).read_text(encoding='utf-8'))
run = json.loads((S / 'checks1/summary.json').read_text(encoding='utf-8'))
assert run['process']['exit'] == 0 and run['tests'] == 4
assert not any(run[key] for key in ('failures', 'errors', 'disabled', 'skips'))
for row in publication.values():
    path = R / row['path']
    assert path.stat().st_size == row['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
with zipfile.ZipFile(R / publication['archive']['path']) as archive:
    assert archive.testzip() is None
    assert not any(Path(name).suffix.lower() in {'.exe', '.obj', '.lib', '.dll', '.bf16', '.e4m3', '.bin'} for name in archive.namelist())
progress = dict(utc=datetime.now(timezone.utc).isoformat(), stage='BS', stage_complete=True,
    goal_complete=False, state='Source, one-TU build, four native cases, documentation and durable evidence complete for the listed finite scope.',
    previous_goal_turn_classification='progress: BR full original Q24 NextN and current BS source design',
    native_checks_run=True, tests=run['tests'], graph_submissions=record['validation']['graph_submissions'],
    failures=0, skips=0, native_process_status='completed_exit0_not_live', exec_session_status='completed',
    publication=publication, new_weight_downloads=False, new_TPS=False, physical_memory_peak=False,
    protected_AV_tail_unchanged=True,
    scope='Original1762-role NextN and original full-V154880 R2 verifier with actual pending leases, complete34-resource plus Epoch state and K1 continuation. Generated target43/44 parameters, layer42 inputs and initial histories remain explicit.',
    next='Authenticated target producer parameters and other applicable verifier adapters; actual Pro geometry; confirmed quantization; final ordinary/MTP performance before image projection. Goal remains active.')
(S / 'progress.json').write_text(json.dumps(progress, indent=2) + '\n', encoding='utf-8')
print('PUBLISHED BS', run['tests'], 'cases', record['validation']['graph_submissions'], 'Graphs; full MTP remains incomplete')
