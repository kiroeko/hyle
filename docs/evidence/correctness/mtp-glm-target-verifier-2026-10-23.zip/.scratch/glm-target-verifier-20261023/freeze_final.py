"""Snapshot the reviewed GLM verifier consumer and exact shared model helpers."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
manifest = json.loads((S / 'source/freeze.json').read_text(encoding='utf-8'))
destination = S / 'source-final'
destination.mkdir(exist_ok=False)
sources = []
for pinned in manifest['source'] + manifest['fixed_dependencies']:
    path = R / pinned['path']
    payload = path.read_bytes()
    assert len(payload) == pinned['bytes'] and hashlib.sha256(payload).hexdigest() == pinned['sha256'], path
    snapshot = destination / 'frozen' / pinned['path']
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(payload)
    sources.append(dict(path=pinned['path'], bytes=len(payload), sha256=pinned['sha256'],
                        snapshot=snapshot.relative_to(R).as_posix()))
record = dict(stage='BS', scope='Exact source snapshot before incremental native build; not a test result.', source=sources)
(destination / 'freeze.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print('FROZEN', len(sources), 'source inputs')
