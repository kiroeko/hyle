"""Update current facts only after the four actual BS native cases pass."""
from pathlib import Path
import hashlib
import json

S = Path(__file__).resolve().parent
R = S.parents[1]
result = json.loads((S / 'checks1/summary.json').read_text(encoding='utf-8'))
assert result['process']['exit'] == 0 and result['tests'] == 4
assert not any(result[key] for key in ('failures', 'errors', 'disabled', 'skips'))
cases = [case for case in result['cases'] if 'FullVocabularyTargetVerifier' in case['attributes']['name']]
assert len(cases) == 2
graphs = sum(int(case['properties']['actual_submissions']) for case in result['cases'])
new_graphs = sum(int(case['properties']['actual_submissions']) for case in cases)
before = json.loads((S / 'before.json').read_text(encoding='utf-8'))
work = R / 'docs/developer/current-work.md'
text = work.read_text(encoding='utf-8-sig')
tail = text[text.index('## 最新完整性能对比'):]
assert hashlib.sha256(tail.encode()).hexdigest() == before['protected_performance_tail_sha256']

def replace_once(text, old, new):
    assert text.count(old) == 1, (old[:100], text.count(old))
    return text.replace(old, new, 1)

text = replace_once(text,
    'GLM默认codec＋43→44→NextN共34资源＋epoch、DSpark三stage编码main ring＋完整draft已有CPU／CUDA检查。',
    'GLM默认codec＋43→44→NextN共34资源＋epoch已有CPU／CUDA检查；原NextN还已接实际计算target taps→原全词表双行验证→实际pending租约→同Head接受／续算。target43／44参数仍生成。DSpark三stage编码main ring＋完整draft原检查保留。')
text = replace_once(text,
    '下一步接真实target taps／verifier，适配Pro实际几何与其它已确认适用量化；最后做必要回归及普通／MTP完整性能对照，再进入图片。',
    'GLM已接实际计算target taps和原全词表verifier，但target43／44参数仍生成；下一步接原target参数和其它适用模型的producer／verifier，适配Pro实际几何与其它已确认量化。最后做必要回归及普通／MTP完整性能对照，再进入图片。')
latest = (
    '**最近已验证进展：** [GLM原全词表target验证与完整状态](../evidence/correctness/mtp-glm-target-verifier-2026-10-23.json)已在CPU／CUDA通过。实际执行的43→44产生最终归一化tap，显式BF16存储后，共用原BF16全V154880 head一次计算两行分数；每端首轮独立核全部309,760值，每次核全词表greedy。接受0份草稿保留已消费当前token的first，接受1份保留second；纠正／bonus直接绑定实际I32输出租约，34资源＋epoch由同一Head发布。\n\n'
    f'新两项共{new_graphs}次Graph，连同原NextN直接回归共4项、{graphs}次，0失败／0跳过。每端一轮自然夹具与明确的匹配／拒绝控制分列；接受后追赶、epoch8 fresh→实际seed→skip0、旧结果和失败取消均检查。target43／44参数、layer42输入及初始历史仍为生成夹具，尚非完整原target或任务质量结果；没有新TPS／物理显存峰，页末AV表不变。\n\n'
    '前批[Q24完整原NextN／词表]'
)
text = replace_once(text, '**最近已验证进展：** [Q24完整原NextN／词表]', latest)
text = replace_once(text,
    '生成参数的[43→44→NextN](../evidence/correctness/mtp-encoded-state-2026-10-23.json)34资源＋epoch组合旧证据保留。target hidden／verifier与初始历史仍生成，原45层target、Pro几何、其它量化及自然接受率未完成，',
    '[43→44→NextN](../evidence/correctness/mtp-encoded-state-2026-10-23.json)34资源＋epoch组合已续接[原全词表R2 verifier](../evidence/correctness/mtp-glm-target-verifier-2026-10-23.json)和实际K1 pending／Head续算。target taps由实际数学产生，但43／44参数、layer42输入和初始历史仍生成；原target参数、Pro几何、其它量化及真实任务自然接受率未完成，')
text = replace_once(text,
    '下一步真实target taps／verifier、Pro几何及其它已确认量化组合，最后完整性能对照；原角色数不是整模型MTP完成比例',
    'GLM计算tap／原全词表verifier及完整K1状态已接；下一步原target参数、其它适用producer／verifier、Pro几何与确认量化，最后完整性能对照；原角色数不是整模型MTP完成比例')
assert text[text.index('## 最新完整性能对比'):] == tail
work.write_text(text, encoding='utf-8')

operators = R / 'docs/implementation/model-operators.md'
text = operators.read_text(encoding='utf-8-sig')
text = replace_once(text,
    '默认ue8m0 cache及生成参数的target43→44→NextN共34资源＋epoch组合保留；真实target taps／verifier、Pro几何和其它确认量化未完成',
    '默认ue8m0 cache及target43→44→NextN共34资源＋epoch组合保留；[原全词表R2验证](../evidence/correctness/mtp-glm-target-verifier-2026-10-23.json)已消费实际计算tap，实际I32 pending与接受0／1由同Head发布并续算。target43／44参数及初始历史仍生成，原target参数、Pro几何和其它确认量化未完成')
text = replace_once(text,
    '真实target taps／verifier与初始历史仍为显式生成边界；有限局部数值和容量检查不代签完整原模型、全部量化、任务质量、自然接受率、TPS或物理显存峰值。',
    '后续[原全词表target验证](../evidence/correctness/mtp-glm-target-verifier-2026-10-23.json)已接实际43→44计算tap→显式BF16→同原head的双行全V154880验证；CPU／CUDA各首轮核309,760值，真实纠正／bonus输出租约与34资源＋epoch按接受0／1同Head发布。接受后追赶与fresh seed→skip0继续检查；自然夹具和匹配／拒绝控制分列。target43／44参数、layer42输入与初始历史仍生成；有限局部数值和容量检查不代签完整原模型、其它量化、任务质量、真实任务自然接受率、TPS或物理显存峰值。')
operators.write_text(text, encoding='utf-8')
print('UPDATED current facts after', result['tests'], 'cases and', graphs, 'actual Graphs; protected AV tail unchanged')
