"""Offline provenance check only; never edits source/lock or runs CMake/native."""
from pathlib import Path
import hashlib
import json

R = Path(__file__).resolve().parents[3]
S = R / '.scratch/inference-optional-aten-20261028/tooling'
V = R / 'third_party/sglang_activation'
OLD = '56a90e3b035652699746d3deba35bc7305160a375aa242ec681945500b19ae7d'
NEW = '4b4cff74b5e167e4a56e3be07a7f9420a1559f35b40b201471586cf71c630414'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def normalize(raw):
    return raw.replace(b'\r\n', b'\n').replace(b'\r', b'\n')

def pin(path):
    raw = path.read_bytes()
    return {'path': path.relative_to(R).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)}

def tree(rows):
    manifest = ''.join(name + '|' + sha(normalize(raw)) + '\n'
                       for name, raw in sorted(rows.items()))
    return sha(manifest.encode('utf-8'))

files = sorted((p for p in V.rglob('*') if p.is_file()),
               key=lambda p: p.relative_to(V).as_posix())
assert len(files) == 31 and not any(p.is_symlink() for p in files)
current = {p.relative_to(V).as_posix(): p.read_bytes() for p in files}
assert tree(current) == NEW
single_base = R / '.scratch/glm-mtp-carry-20261022'
group_base = R / '.scratch/glm-mtp-state-20261022'
single_before = {}
for directory in ('repair-headers/before', 'repair-metadata/before'):
    for path in sorted((single_base / directory).iterdir()):
        if path.is_file():
            single_before['fp8/' + path.name] = path
for name in ('source.json', 'rebuild.py'):
    single_before['fp8/' + name] = single_base / 'repair-source' / (name + '.before')
group_before = {'fp8/grouped/' + p.name: p
                for p in sorted((group_base / 'grouped-repair/before').iterdir()) if p.is_file()}
assert len(single_before) == 6 and len(group_before) == 4
before = dict(single_before, **group_before)
reconstructed = dict(current)
reconstructed.update({name: path.read_bytes() for name, path in before.items()})
assert tree(reconstructed) == OLD
changed = []
for name, path in sorted(before.items()):
    assert normalize(current[name]) != normalize(path.read_bytes())
    changed.append({'relative_path': name, 'before_snapshot': pin(path),
                    'current_source': pin(V / name),
                    'normalized_before_sha256': sha(normalize(path.read_bytes())),
                    'normalized_current_sha256': sha(normalize(current[name]))})

evidence = []
listed = set()
for basename, archive in (('glm-mtp-carry-2026-10-22.json', single_base),
                          ('glm-mtp-state-2026-10-22.json', group_base)):
    path = R / 'docs/evidence/correctness' / basename
    doc = json.loads(path.read_text(encoding='utf-8-sig'))
    rows = []
    for old_pin in doc['changes']:
        name = old_pin['path']
        if not name.startswith('third_party/sglang_activation/'):
            continue
        source = R / name
        snapshot = archive / 'source-current' / name
        actual = pin(source)
        assert actual['sha256'] == old_pin['sha256']
        assert snapshot.read_bytes() == source.read_bytes()
        relative = name.removeprefix('third_party/sglang_activation/')
        listed.add(relative)
        rows.append({'evidence_pin': old_pin, 'current_source': actual,
                     'archived_source_snapshot': pin(snapshot),
                     'changed_since_locked_snapshot': relative in before})
    evidence.append({'evidence': pin(path), 'recorded_status': doc['status'], 'files': rows})
assert len(listed) == 11 and set(before) < listed
assert listed - set(before) == {'fp8/original_kernels.py'}

lock = R / 'cmake/HyleDependencyLock.json'
raw = lock.read_bytes()
assert raw.count(NEW.encode()) == 1 and OLD.encode() not in raw
prior_raw = raw.replace(NEW.encode(), OLD.encode())
after_doc = json.loads(raw)
prior_doc = json.loads(prior_raw)
entry = next(x for x in after_doc['dependencies'] if x['name'] == 'sglang_activation')
old_entry = next(x for x in prior_doc['dependencies'] if x['name'] == 'sglang_activation')
assert entry['vendored']['tree_sha256'] == NEW
check = json.loads(json.dumps(after_doc))
next(x for x in check['dependencies'] if x['name'] == 'sglang_activation')['vendored']['tree_sha256'] = OLD
assert check == prior_doc
earlier = R / '.scratch/architecture-refactor-2026-10-18/quark-block128-scale-2026-10-21/lock-update.json'
old_update = next(x for x in json.loads(earlier.read_bytes())['updates'] if x['name'] == 'sglang_activation')
assert old_update['after'] == OLD

report = {
    'schema': 'hyle.sglang-vendored-lock-diagnosis.v1',
    'status': 'STALE_LOCK_EXACTLY_RECONSTRUCTED_AND_SINGLE_IDENTITY_REFRESHED',
    'method': 'Pure offline file/JSON reads and in-memory historical replacement; no CMake, Git, compiler, model, network or source rollback.',
    'algorithm': 'Sorted portable case-sensitive relative paths; SHA256(CRLF/CR-to-LF file bytes); SHA256(concatenated path|file-sha256\\n).',
    'current_tree_sha256': NEW, 'locked_prior_tree_sha256': OLD,
    'reconstructed_prior_tree_sha256': tree(reconstructed),
    'file_count': len(files), 'actual_changed_files': len(changed),
    'evidence_listed_files': len(listed),
    'evidence_listed_unchanged': ['fp8/original_kernels.py'],
    'cause': 'The 2026-10-21 lock identity omitted both already archived 2026-10-22 single/grouped FP8 BF16-dot repair updates. All 11 evidence source pins match current raw bytes.',
    'excluded_causes': ['Windows path sorting', 'CRLF normalization mismatch', 'extra generated/hidden files', 'this ATen migration mutating vendored source'],
    'changed_files': changed, 'prior_lock_generation_receipt': pin(earlier),
    'published_evidence': evidence,
    'current_tree_manifest': [{**pin(p), 'relative_path': p.relative_to(V).as_posix(),
                              'normalized_sha256': sha(normalize(p.read_bytes()))} for p in files],
    'lock_edit': {'after': pin(lock),
                  'before_reconstructed': {'bytes': len(prior_raw), 'sha256': sha(prior_raw),
                                           'qualification': 'Mechanically reconstructed predecessor by reversing the sole 64-byte tree identity replacement; not an independently saved pre-edit snapshot.'},
                  'json_path': 'dependencies[name=sglang_activation].vendored.tree_sha256',
                  'old': OLD, 'new': NEW, 'other_json_fields_unchanged': True,
                  'archive_revision_git_tree_license_fields_unchanged': entry['archive'] == old_entry['archive'] and entry['revision'] == old_entry['revision'] and entry['git_tree'] == old_entry['git_tree'] and entry['license'] == old_entry['license']},
    'original_configure_failure': {name: pin(R / '.scratch/inference-optional-aten-20261028/configure-off-run' / name)
                                   for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log')},
    'cpp_sources_headers_changed': False, 'configure_rerun_by_this_script': False,
    'script': pin(Path(__file__).resolve()),
}
output = S / 'sglang-lock-diagnosis.json'
assert not output.exists(), 'Do not overwrite a previous diagnostic receipt'
output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'receipt': pin(output), 'lock': pin(lock),
                  'changed': len(changed), 'evidence_listed': len(listed)}, indent=2))
