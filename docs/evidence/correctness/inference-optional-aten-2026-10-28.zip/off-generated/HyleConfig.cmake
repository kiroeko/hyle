
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was HyleConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)
include("${CMAKE_CURRENT_LIST_DIR}/HyleRuntimeStaging.cmake")
set(Hyle_FOUND TRUE)
unset(Hyle_NOT_FOUND_MESSAGE)

set(Hyle_AVAILABLE_COMPUTE_ROUTES "cpu;cuda")
set(Hyle_COMPUTE_RECIPE_ID "21ed1dd2b6d1ee55a6c12d9235821325ba418995cbb6adb9dc1fe7ef5329292b")
set(Hyle_AVAILABLE_COMPONENTS "core;error;simd;math;compute;graph")
set(Hyle_AVAILABLE_FEATURES "compute_ggml_cpu_program;compute_onednn;compute_cpu;compute_cuda;compute_ggml_cpu;compute_ggml_cuda;compute_flashinfer")
set(Hyle_STATIC ON)
# Imported targets are directory scoped. Check identities on targets visible
# here instead of using a process/global lock: sibling consumers may each use
# a different SDK, but one target closure must never mix source or SDK origins.
file(REAL_PATH "${CMAKE_CURRENT_LIST_DIR}" _Hyle_package_config_dir)
file(REAL_PATH "${PACKAGE_PREFIX_DIR}" _Hyle_package_prefix)
if(WIN32)
  string(TOLOWER "${_Hyle_package_config_dir}" _Hyle_package_config_dir)
  string(TOLOWER "${_Hyle_package_prefix}" _Hyle_package_prefix)
endif()
set(_Hyle_origin_targets hyle::_build_contract)
foreach(_Hyle_component IN LISTS Hyle_AVAILABLE_COMPONENTS)
  list(APPEND _Hyle_origin_targets "hyle::${_Hyle_component}")
endforeach()
foreach(_Hyle_target IN LISTS _Hyle_origin_targets)
  if(NOT TARGET "${_Hyle_target}")
    continue()
  endif()
  get_target_property(_Hyle_imported "${_Hyle_target}" IMPORTED)
  if(NOT _Hyle_imported)
    set(Hyle_FOUND FALSE)
    set(Hyle_NOT_FOUND_MESSAGE
      "Hyle target '${_Hyle_target}' already comes from an embedded source build; source and installed SDK targets cannot be mixed in one scope")
    return()
  endif()
  get_target_property(_Hyle_existing_config "${_Hyle_target}" HYLE_PACKAGE_CONFIG_DIR)
  get_target_property(_Hyle_existing_recipe "${_Hyle_target}" HYLE_PACKAGE_RECIPE_ID)
  if(NOT _Hyle_existing_config STREQUAL _Hyle_package_config_dir OR
     NOT _Hyle_existing_recipe STREQUAL Hyle_COMPUTE_RECIPE_ID)
    set(Hyle_FOUND FALSE)
    set(Hyle_NOT_FOUND_MESSAGE
      "Hyle target '${_Hyle_target}' is already loaded from another SDK configuration or recipe; use one SDK prefix and recipe per target scope")
    return()
  endif()
endforeach()
foreach(_Hyle_legacy IN ITEMS HYLE_COMPUTE_CPU HYLE_COMPUTE_CUDA HYLE_COMPUTE_APPLE
    HYLE_COMPUTE_VULKAN HYLE_COMPUTE_ONEDNN HYLE_COMPUTE_TORCH_CPU)
  if(DEFINED ${_Hyle_legacy})
    set(Hyle_FOUND FALSE)
    set(Hyle_NOT_FOUND_MESSAGE
      "${_Hyle_legacy} is no longer a public build option; request HYLE_COMPUTE_ROUTES or read this SDK's capabilities")
    return()
  endif()
endforeach()
unset(_Hyle_legacy)
# A requested set only asserts capabilities in this immutable SDK. It cannot
# download/recompile Providers or alter the imported target's presence macros.
if(DEFINED HYLE_COMPUTE_ROUTES)
  if(HYLE_COMPUTE_ROUTES STREQUAL "" OR
     HYLE_COMPUTE_ROUTES MATCHES "(^;|;;|;$)")
    set(Hyle_FOUND FALSE)
    set(Hyle_NOT_FOUND_MESSAGE "HYLE_COMPUTE_ROUTES must be a nonempty route requirement without empty items")
    return()
  endif()
  foreach(_Hyle_requested IN LISTS HYLE_COMPUTE_ROUTES)
    string(STRIP "${_Hyle_requested}" _Hyle_requested)
    string(TOLOWER "${_Hyle_requested}" _Hyle_requested)
    if(NOT _Hyle_requested IN_LIST Hyle_AVAILABLE_COMPUTE_ROUTES)
      set(Hyle_FOUND FALSE)
      set(Hyle_NOT_FOUND_MESSAGE
        "Hyle SDK does not contain requested Compute route '${_Hyle_requested}'; available: ${Hyle_AVAILABLE_COMPUTE_ROUTES}")
      return()
    endif()
  endforeach()
  unset(_Hyle_requested)
endif()

# Validate requested products before probing any of their external SDKs.
set(_Hyle_missing_components "")
set(_Hyle_requested_components "")
foreach(_Hyle_component IN LISTS Hyle_FIND_COMPONENTS)
  if(_Hyle_component IN_LIST Hyle_AVAILABLE_COMPONENTS)
    set(Hyle_${_Hyle_component}_FOUND TRUE)
    list(APPEND _Hyle_requested_components "${_Hyle_component}")
  else()
    set(Hyle_${_Hyle_component}_FOUND FALSE)
    list(APPEND _Hyle_missing_components "${_Hyle_component}")
    string(CONCAT Hyle_${_Hyle_component}_NOT_FOUND_MESSAGE
      "Hyle product '${_Hyle_component}' is not present in this installation; "
      "available products: ${Hyle_AVAILABLE_COMPONENTS}")
  endif()
endforeach()
if(_Hyle_missing_components)
  list(JOIN _Hyle_missing_components ", " _Hyle_missing_text)
  list(JOIN Hyle_AVAILABLE_COMPONENTS ", " _Hyle_available_text)
  string(CONCAT Hyle_NOT_FOUND_MESSAGE
    "missing requested component(s): ${_Hyle_missing_text}; available in this "
    "installation: ${_Hyle_available_text}")
endif()
check_required_components(Hyle)
if(NOT Hyle_FOUND AND _Hyle_missing_components)
  return()
endif()
# Omitting COMPONENTS retains the ordinary complete-SDK import. With explicit
# products, only their dependency closure is loaded. Available capabilities
# describe the SDK; loaded capabilities describe targets usable in this scope.
if(NOT Hyle_FIND_COMPONENTS)
  set(_Hyle_requested_components "${Hyle_AVAILABLE_COMPONENTS}")
endif()
include("${CMAKE_CURRENT_LIST_DIR}/HylePackageIndex.cmake")
set(_Hyle_requested_groups "")
foreach(_Hyle_component IN LISTS _Hyle_requested_components)
  list(APPEND _Hyle_requested_groups ${_Hyle_product_${_Hyle_component}_groups})
endforeach()
# Expose any additional public facade already complete in this closure (for
# example Core/Error in a Mem SDK), without pulling in a new factor or SDK.
foreach(_Hyle_component IN LISTS Hyle_AVAILABLE_COMPONENTS)
  set(_Hyle_complete TRUE)
  foreach(_Hyle_required IN LISTS _Hyle_product_${_Hyle_component}_required_groups)
    if(NOT _Hyle_required IN_LIST _Hyle_requested_groups)
      set(_Hyle_complete FALSE)
      break()
    endif()
  endforeach()
  if(_Hyle_complete)
    list(APPEND _Hyle_requested_groups "product_${_Hyle_component}")
  endif()
endforeach()
foreach(_Hyle_group IN LISTS _Hyle_package_group_order)
  if(NOT _Hyle_group IN_LIST _Hyle_requested_groups)
    continue()
  endif()
  foreach(_Hyle_spec IN LISTS _Hyle_group_${_Hyle_group}_find_dependencies)
    string(REPLACE "|" ";" _Hyle_args "${_Hyle_spec}")
    list(GET _Hyle_args 0 _Hyle_dependency)
    if(_Hyle_dependency MATCHES "^Hyle[A-Za-z0-9_]+$")
      # These private shims ship beside Hyle itself. Hyle_DIR is sufficient
      # to consume the SDK; external MODULE dependencies retain normal lookup.
      # Override only this lookup's normal variable: a sibling may have left
      # the same private package's cache entry pointing at another SDK copy.
      block(SCOPE_FOR VARIABLES PROPAGATE Hyle_FOUND Hyle_NOT_FOUND_MESSAGE
          "${_Hyle_dependency}_FOUND")
        set("${_Hyle_dependency}_DIR"
          "${CMAKE_CURRENT_LIST_DIR}/../${_Hyle_dependency}")
        find_dependency(${_Hyle_args} CONFIG
          PATHS "${CMAKE_CURRENT_LIST_DIR}/../${_Hyle_dependency}" NO_DEFAULT_PATH)
      endblock()
    else()
      find_dependency(${_Hyle_args})
    endif()
  endforeach()
  if(_Hyle_group_${_Hyle_group}_file)
    include("${CMAKE_CURRENT_LIST_DIR}/${_Hyle_group_${_Hyle_group}_file}")
    # A later optional/QUIET dependency lookup can return from this config.
    # Tag each imported portion immediately so a retry of another component
    # recognizes the targets already loaded from this same installation.
    foreach(_Hyle_target IN LISTS _Hyle_origin_targets)
      if(TARGET "${_Hyle_target}")
        set_target_properties("${_Hyle_target}" PROPERTIES
          HYLE_PACKAGE_CONFIG_DIR "${_Hyle_package_config_dir}"
          HYLE_PACKAGE_RECIPE_ID "${Hyle_COMPUTE_RECIPE_ID}")
      endif()
    endforeach()
  endif()
endforeach()
set(Hyle_LOADED_COMPONENTS "")
foreach(_Hyle_component IN LISTS Hyle_AVAILABLE_COMPONENTS)
  if(TARGET hyle::${_Hyle_component})
    list(APPEND Hyle_LOADED_COMPONENTS "${_Hyle_component}")
  endif()
endforeach()

# These expert/runtime helpers follow the targets actually imported above.
if(TARGET hyle::simd_expert)
  include("${CMAKE_CURRENT_LIST_DIR}/HyleIsa.cmake")
  include("${CMAKE_CURRENT_LIST_DIR}/HyleDispatch.cmake")
endif()
if(TARGET hyle::_mlx_native)
  include("${CMAKE_CURRENT_LIST_DIR}/HyleAppleRuntime.cmake")
  get_filename_component(_Hyle_metallib
    "${CMAKE_CURRENT_LIST_DIR}/../../mlx.metallib" ABSOLUTE)
  if(NOT EXISTS "${_Hyle_metallib}")
    message(FATAL_ERROR "Hyle Apple SDK is missing native resource '${_Hyle_metallib}'")
  endif()
  set_property(TARGET hyle::_mlx_native PROPERTY HYLE_APPLE_METALLIB "${_Hyle_metallib}")
  unset(_Hyle_metallib)
endif()
unset(_Hyle_missing_components)
unset(_Hyle_missing_text)
unset(_Hyle_available_text)
unset(_Hyle_requested_components)
unset(_Hyle_requested_groups)
unset(_Hyle_component)
unset(_Hyle_group)
unset(_Hyle_required)
unset(_Hyle_complete)
unset(_Hyle_spec)
unset(_Hyle_args)
unset(_Hyle_dependency)
# Older CMake package helpers may overwrite this variable in find_dependency.
set(PACKAGE_PREFIX_DIR "${_Hyle_package_prefix}")
unset(_Hyle_package_prefix)
unset(_Hyle_package_config_dir)
unset(_Hyle_origin_targets)
unset(_Hyle_target)
unset(_Hyle_imported)
unset(_Hyle_existing_config)
unset(_Hyle_existing_recipe)
