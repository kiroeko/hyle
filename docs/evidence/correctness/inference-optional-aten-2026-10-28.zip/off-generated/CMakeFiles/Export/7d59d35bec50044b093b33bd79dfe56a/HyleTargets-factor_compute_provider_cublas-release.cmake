#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_compute_provider_cublas" for configuration "Release"
set_property(TARGET hyle::_factor_compute_provider_cublas APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_provider_cublas PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_provider_cublas.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_provider_cublas )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_provider_cublas "${_IMPORT_PREFIX}/lib/hyle_compute_provider_cublas.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
