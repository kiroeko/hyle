#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_compute_ggml_runtime" for configuration "Release"
set_property(TARGET hyle::_factor_compute_ggml_runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_compute_ggml_runtime PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_compute_ggml_runtime.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_compute_ggml_runtime )
list(APPEND _cmake_import_check_files_for_hyle::_factor_compute_ggml_runtime "${_IMPORT_PREFIX}/lib/hyle_compute_ggml_runtime.lib" )

# Import target "hyle::_hyle_ggml_cpu_avx2_456172ec_f51f1a77e1c4b1a6" for configuration "Release"
set_property(TARGET hyle::_hyle_ggml_cpu_avx2_456172ec_f51f1a77e1c4b1a6 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_hyle_ggml_cpu_avx2_456172ec_f51f1a77e1c4b1a6 PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_RELEASE ""
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_ggml_cpu_avx2_456172ec_f51f1a77e1c4b1a6.dll"
  )

list(APPEND _cmake_import_check_targets hyle::_hyle_ggml_cpu_avx2_456172ec_f51f1a77e1c4b1a6 )
list(APPEND _cmake_import_check_files_for_hyle::_hyle_ggml_cpu_avx2_456172ec_f51f1a77e1c4b1a6 "${_IMPORT_PREFIX}/lib/hyle_ggml_cpu_avx2_456172ec_f51f1a77e1c4b1a6.dll" )

# Import target "hyle::_ggml_ggml" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/ggml.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml "${_IMPORT_PREFIX}/lib/ggml.lib" )

# Import target "hyle::_ggml_ggml-base" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-base PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/ggml-base.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-base )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-base "${_IMPORT_PREFIX}/lib/ggml-base.lib" )

# Import target "hyle::_ggml_ggml-cpu" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-cpu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-cpu PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/ggml-cpu.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-cpu )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-cpu "${_IMPORT_PREFIX}/lib/ggml-cpu.lib" )

# Import target "hyle::_ggml_ggml-cuda" for configuration "Release"
set_property(TARGET hyle::_ggml_ggml-cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_ggml_ggml-cuda PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CUDA"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/ggml-cuda.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_ggml_ggml-cuda )
list(APPEND _cmake_import_check_files_for_hyle::_ggml_ggml-cuda "${_IMPORT_PREFIX}/lib/ggml-cuda.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
