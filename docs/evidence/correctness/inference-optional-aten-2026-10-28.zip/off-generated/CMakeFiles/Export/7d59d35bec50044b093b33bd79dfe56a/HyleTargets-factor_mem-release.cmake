#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hyle::_factor_mem" for configuration "Release"
set_property(TARGET hyle::_factor_mem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_factor_mem PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/hyle_mem.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_factor_mem )
list(APPEND _cmake_import_check_files_for_hyle::_factor_mem "${_IMPORT_PREFIX}/lib/hyle_mem.lib" )

# Import target "hyle::_mimalloc" for configuration "Release"
set_property(TARGET hyle::_mimalloc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(hyle::_mimalloc PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/mimalloc_static.lib"
  )

list(APPEND _cmake_import_check_targets hyle::_mimalloc )
list(APPEND _cmake_import_check_files_for_hyle::_mimalloc "${_IMPORT_PREFIX}/lib/mimalloc_static.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
