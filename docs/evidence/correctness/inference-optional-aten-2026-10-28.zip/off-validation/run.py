"""Four OFF consumers. Native success is never rerun after a parser failure."""
from pathlib import Path
import importlib.util
import os
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('actual_off_validation', W / 'build.py')
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b); t = b.t


def prepare():
    p = b.plan()
    t.save(W / 'run-plan.json', dict(status='PLANNED_NOT_RUN', mode='ATen_OFF',
        plan=t.pin(W / 'plan.json'), processes=4, models=0,
        arms={name: dict(extra_arguments=(['--disabled'] if name == 'runtime-disabled' else
                    ['--gtest_output=xml:RESULTS'] if name == 'ct' else []),
                        expected_input_count=b.INPUT_COUNTS[name]) for name in b.TARGETS},
        policy='Each arm once, stop at first actual failure. Parser failure uses parse-only on preserved stdout/XML; no successful native rerun.',
        runtime=p['runtime'], limitations=['No model, performance or ATen fallback/decoder claims.',
            'Original CT5 sources + attention source run under actual OFF feature flags. Report actual XML cases and skips; do not inherit ON test counts.',
            'Runtime only --disabled; no ON foreign-thread/TF32/allocator scenarios.']))
    print('RUN PLAN PREPARED:4 processes; no execution')


def parse(target):
    assert target in b.TARGETS
    out = W / 'runs' / target; process = t.read(out / 'process.json')
    assert process['exit'] == 0 and not process['timed_out'], process
    stdout = (out / 'stdout.log').read_text(encoding='utf-8', errors='replace')
    stderr = (out / 'stderr.log').read_text(encoding='utf-8', errors='replace')
    if target == 'resident-direct':
        expected = 'PASS CUDA public resident packed consumer: 64 steps, two slots, retained output'
        assert stdout.splitlines().count(expected) == 1 and 'FAIL ' not in stderr
        summary = dict(status='PASS', process=process, report=expected, mode='ATen_OFF', models=0)
    elif target == 'resident-graph':
        lines = [line for line in stdout.splitlines() if line.startswith('PASS CUDA Graph packed ')]
        for shape in ('M=1 bits=4 group=32', 'M=17 bits=5 group=64', 'M=1 bits=6 group=128', 'M=64 bits=8 group=32'):
            assert sum(line.startswith('PASS CUDA Graph packed ' + shape + ':65 steps/') for line in lines) == 1, lines
        assert len(lines) == 4 and 'FAIL ' not in stderr
        summary = dict(status='PASS', process=process, reports=lines, mode='ATen_OFF', models=0,
            capture_test=False, scope='Original Commands replay. CT target separately checks capture.')
    elif target == 'runtime-disabled':
        lines = [line for line in stdout.splitlines() if line.startswith('PASS CPU runtime --disabled ')]
        assert len(lines) == 1 and 'FAIL CPU runtime:' not in stderr
        assert re.fullmatch(r'PASS CPU runtime --disabled backend=0 configured=0 observed=0 used=0', lines[0]), lines
        summary = dict(status='PASS', process=process, report=lines[0], mode='ATen_OFF', models=0,
            scope='Unavailable thread-runtime metadata/configure refusal; original ggml Abs native-thread budget and numerical replay.')
    else:
        root = ET.parse(out / 'results.xml').getroot()
        tests = int(root.attrib['tests']); failures = int(root.attrib['failures']); errors = int(root.attrib['errors'])
        assert tests > 0 and failures == 0 and errors == 0, (tests, failures, errors)
        cases = []
        for row in root.findall('.//testcase'):
            skip = row.find('skipped')
            cases.append(dict(suite=row.attrib['classname'], name=row.attrib['name'],
                status='SKIP' if skip is not None else 'PASS',
                skip_reason=(skip.attrib.get('message', '') or skip.text) if skip is not None else None))
        skipped = sum(row['status'] == 'SKIP' for row in cases)
        assert len(cases) == tests and tests > skipped
        # These two OFF branches are the positive absence tests, not skipped
        # substitutions for the optional decoder or broad BF16 attention.
        passed = {(row['suite'], row['name']) for row in cases if row['status'] == 'PASS'}
        for key in (('CudaCtPackedLinear', 'MissingIndependentDecoderRejectsPublishedViewAndControlEscapes'),
                    ('CudaDefaultGraph', 'MissingBroadBf16AttentionDoesNotChangePrecisionOrMaterializeScores'),
                    ('CudaDefaultGraph', 'MaturePrefillDecodeThroughNormalEntries')):
            assert key in passed, ('Required OFF case did not pass', key)
        summary = dict(status='PASS_WITH_SKIPS' if skipped else 'PASS', process=process, mode='ATen_OFF', models=0,
            tests=tests, passed=tests-skipped, failures=failures, errors=errors, skipped=skipped, cases=cases)
    t.save(out / 'summary.json', summary); print(target, summary['status'])


def run(target):
    b.validate(); assert target in b.TARGETS
    ready = t.read(W / f'ready-{target}.json'); t.exact(ready['image']); t.exact(ready['inputs']); t.exact(ready['runtime'])
    runtime = t.read(ready['runtime']['path']); native = runtime['native']
    assert (W / 'bin' / Path(native['path']).name).samefile(native['path'])
    env = os.environ.copy(); env.update(t.read(W / 'environment.json'))
    env.update(HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    assert not any(b.torch_sdk(env[name]) for name in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH'))
    out = W / 'runs' / target; out.mkdir(parents=True, exist_ok=False)
    args = [ready['image']['path']]
    if target == 'runtime-disabled': args.append('--disabled')
    if target == 'ct': args.append('--gtest_output=xml:' + str(out / 'results.xml'))
    t.save(out / 'command.json', dict(command=args, cwd=str(b.R), timeout_seconds=240,
        ready=t.pin(W / f'ready-{target}.json'), runtime=ready['runtime'], mode='ATen_OFF',
        environment_relevant={name: env[name] for name in ('CUDA_VISIBLE_DEVICES', 'CUDA_MODULE_LOADING', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS') if name in env},
        note='No thread limits/affinity injected. Explicit Torch SDK directories stripped from environment search paths.'))
    start = time.time(); timed_out = False
    with (out / 'stdout.log').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr:
        child = subprocess.Popen(args, cwd=b.R, env=env, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        t.save(out / 'running.json', dict(pid=child.pid, started=start))
        try: code = child.wait(timeout=240)
        except subprocess.TimeoutExpired:
            timed_out = True; child.terminate()
            try: code = child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.kill(); code = child.wait(timeout=10)
    process = dict(pid=child.pid, exit=code, started=start, seconds=time.time()-start, state='TERMINAL', timed_out=timed_out)
    t.save(out / 'process.json', process); assert code == 0 and not timed_out, process
    parse(target)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'run': run(sys.argv[2])
    elif action == 'parse-only': parse(sys.argv[2])
    else: raise ValueError(action)
