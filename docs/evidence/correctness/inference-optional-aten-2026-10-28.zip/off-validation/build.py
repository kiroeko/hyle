"""Actual ATen-OFF delta. Preparation/freezing are metadata-only; root executes builds."""
from pathlib import Path
import ctypes
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
R = Path('C:/public/project-hyle/hyle')
W = Path(__file__).resolve().parent
ON = W.parent / 'validation'
CONFIG = W.parent / 'configure-cpu-cuda-off'
spec = importlib.util.spec_from_file_location('off_original_windows_driver', R / '.scratch/inference-indexed-store-20261028/build.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t); t.W = W
SDK = {'native': 'src/compute_provider_native/native_provider.cc',
       'aten-stub': 'src/compute_provider_native/aten_cpu_provider.cc',
       'cuda-context': 'src/compute_route_cuda/cuda_context.cc'}
TESTS = {'resident-direct': 'tests/compute_provider_cuda/packed_resident_consumer.cc',
         'resident-graph': 'tests/graph_route_cuda/packed_resident_consumer.cc',
         'ct-grouped': 'tests/graph_route_cuda/ct_packed_grouped_test.cc',
         'ct-linear': 'tests/graph_route_cuda/ct_packed_linear_test.cc',
         'ct-gptq': 'tests/graph_route_cuda/gptq_reference_test.cc',
         'ct-fp8': 'tests/graph_route_cuda/static_fp8_reference_test.cc',
         'ct-scalar': 'tests/graph_route_cuda/scalar_float_test.cc',
         'attention': 'tests/graph_route_cuda/attention_test.cc',
         'runtime-disabled': 'tests/compute_route_cpu/thread_runtime_consumer.cc'}
TARGETS = {'resident-direct': ('resident-direct',), 'resident-graph': ('resident-graph',),
           'ct': ('ct-grouped', 'ct-linear', 'ct-gptq', 'ct-fp8', 'ct-scalar', 'attention'),
           'runtime-disabled': ('runtime-disabled',)}
INPUT_COUNTS = {'resident-direct': 221, 'resident-graph': 221, 'ct': 228, 'runtime-disabled': 221}


def torch_sdk(value):
    s = str(value).replace('/', '\\').lower()
    return any(part in s for part in ('\\sdks\\torch-', '\\libtorch\\', '\\torch\\include', '\\torch\\lib'))


def check_off_args(args):
    assert not any(torch_sdk(a) for a in args), 'Torch SDK directory retained'
    assert not any(re.search(r'(?:/|-)[DU](?:HYLE_COMPUTE_TORCH|HYLE_G10_TEST_VENDOR|HYLE_TEST_TORCH)', a, re.I) for a in args), 'Torch feature macro retained'


def winargs(value):
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
    shell.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    count = ctypes.c_int(); ptr = shell.CommandLineToArgvW(value, ctypes.byref(count))
    if not ptr: raise ctypes.WinError(ctypes.get_last_error())
    try: return [ptr[i] for i in range(count.value)]
    finally: kernel.LocalFree(ctypes.cast(ptr, ctypes.c_void_p))


def adapt(row, name, source, consumer=False, gtest_includes=()):
    before = winargs(row['command']); args = []
    for arg in before:
        if t.key(arg) == t.key(row['file']): arg = str(R / source)
        elif arg.lower().startswith('/fo'): arg = '/Fo' + str(W / f'compile/{name}/unit.obj')
        elif arg.lower().startswith('/fd'): arg = '/Fd' + str(W / f'compile/{name}/unit.pdb')
        elif consumer and re.match(r'[-/]DHYLE_.*_BUILD(?:=|$)', arg, re.I): continue
        args.append(arg)
    args += ['/sourceDependencies', str(W / f'compile/{name}/dependencies.json')]
    if consumer:
        # Original test targets can have many COMDAT sections. This does not
        # change operators, feature flags, runtime linkage or warning levels.
        args.append('/bigobj')
        args += list(gtest_includes)
    check_off_args(args)
    return dict(command=args, timeout_seconds=300, original_generated_command=row,
                amendments=['absolute OBJ/PDB', 'MSVC actual sourceDependencies'] +
                (['consumer source substitution; remove provider export macro', '/bigobj'] if consumer else []))


def prepare():
    review = t.read(W.parent / 'off-generated-review.json')
    assert review['status'] == 'PASS_OFF_GENERATED_DEPENDENCY_CLOSURE_ONLY'
    process = t.read(W.parent / 'configure-off-attempt3-run/process.json'); assert process['exit'] == 0
    ccpath = CONFIG / 'compile_commands.json'; database = t.read(ccpath)
    def generated(source):
        rows = [r for r in database if t.key(Path(r['file']).resolve()) == t.key(R / source)]
        assert len(rows) == 1, (source, len(rows)); return rows[0]
    # Parent ON handoff was subsequently amended for CMake license metadata.
    # Validate actual frozen C++/project-header inputs, not stale handoff bytes.
    onfreeze = t.read(ON / 'source-freeze.json'); t.exact(onfreeze['includes'])
    for row in t.read(onfreeze['includes']['path']): t.exact(row)
    for row in onfreeze['snapshots']: t.exact(row['original']); t.exact(row['snapshot'])
    ready = t.read(ON / 'ready-resident-direct.json'); t.exact(ready['inputs'])
    allrows = t.read(ready['inputs']['path']); assert len(allrows) == 228
    consumer = ready['compiled']['resident-direct']['object']
    assert allrows.count(consumer) == 1
    sdk = [r for r in allrows if r != consumer]; assert len(sdk) == 227
    removed = [r for r in sdk if (Path(r['path']).name.lower() in
        ('torch.lib', 'torch_cpu.lib', 'c10.lib', 'c10_cuda.lib', 'torch_cuda.lib')) or
        'compute_provider_native--torch_cpu_program_cc' in r['path'] or
        t.key(r['path']) == t.key(ON / 'compile/torch-artifact/unit.obj')]
    assert len(removed) == 7 and sum(Path(r['path']).suffix.lower() == '.lib' for r in removed) == 5
    offsdk = [r for r in sdk if r not in removed]; assert len(offsdk) == 220
    assert not any(torch_sdk(r['path']) for r in offsdk)
    cpu = R / '.scratch/inference-cpu-routing-20261028/validation'
    old = {n: t.read(cpu / f'compile/{c}/compiled.json')['object'] for n, c in (('native', 'native'), ('aten-stub', 'aten'))}
    old['cuda-context'] = next(r for r in offsdk if 'compute_route_cuda--cuda_context_cc' in r['path'])
    assert all(offsdk.count(row) == 1 for row in old.values())
    units = {}
    for name, source in SDK.items():
        row = generated(source); recipe = adapt(row, name, source)
        t.save(W / f'recipes/{name}.json', recipe)
        units[name] = dict(source=source, recipe=t.pin(W / f'recipes/{name}.json'),
                           generated_source=source, kind='CXX', old_object=old[name])
    gtest = t.read(ON / 'plan.json')['gtest']; assert len(gtest) == 2
    gtest_includes = [a for a in t.command(ON / 'recipes/ct-linear.json')
                     if a.lower().startswith(('/i', '/external:i')) and 'googletest' in a.lower()]
    assert gtest_includes
    for name, source in TESTS.items():
        template = SDK['native'] if name == 'runtime-disabled' else 'src/graph_route_cuda/cuda_context.cc'
        row = generated(template); includes = gtest_includes if name in TARGETS['ct'] else ()
        t.save(W / f'recipes/{name}.json', adapt(row, name, source, True, includes))
        units[name] = dict(source=source, recipe=t.pin(W / f'recipes/{name}.json'),
                           generated_source=template, kind='CXX', old_object=None)
    assert len(units) == 12
    exclusion = {t.key(r['path']) for r in removed + [consumer]}
    replacement = {t.key(row['path']): str(W / f'compile/{n}/unit.obj') for n, row in old.items()}
    for target, names in TARGETS.items():
        args = []
        for arg in t.command(ready['recipe']['path']):
            if t.key(arg) in exclusion: continue
            arg = replacement.get(t.key(arg), arg)
            for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
                if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin' / target).with_suffix(suffix)); break
            args.append(arg)
        args += [str(W / f'compile/{n}/unit.obj') for n in names]
        if target == 'ct': args += [row['path'] for row in gtest]
        check_off_args(args)
        t.save(W / f'link-recipes/{target}.json', dict(command=args, timeout_seconds=240))
    retained = []
    for row in [r for r in offsdk if t.key(r['path']) not in replacement] + gtest:
        st = Path(row['path']).stat(); assert st.st_size == row['bytes']
        retained.append(dict(path=row['path'], bytes=st.st_size, mtime_ns=st.st_mtime_ns, retained_sha256=row['sha256']))
    assert len(retained) == 219  # 217 original SDK +2 GTest; kernel is retained.
    common = {}
    for name in ('native-artifact', 'cuda-provider', 'cuda-policy', 'graph-packed', 'graph-dense', 'graph-context', 'native-kernel'):
        compiled = t.read(ON / f'compile/{name}/compiled.json'); dep = t.read(compiled['actual_dependencies']['path'])
        assert not any(torch_sdk(row['path']) for row in dep), name
        common[name] = dict(compiled=t.pin(ON / f'compile/{name}/compiled.json'), object=compiled['object'],
            actual_dependencies=compiled['actual_dependencies'],
            basis='Current source contains no Torch feature branch. Actual ON dependencies contain no Torch SDK. Reuse unchanged object; kernel not recompiled.')
    env = t.read(ON / 'environment.json'); removed_environment = {}
    for name in ('PATH', 'INCLUDE', 'LIB', 'LIBPATH'):
        pieces = env[name].split(';'); removed_environment[name] = [v for v in pieces if torch_sdk(v)]
        env[name] = ';'.join(v for v in pieces if not torch_sdk(v))
    env['PATH'] = str(W / 'bin') + ';' + env['PATH']
    assert all(not torch_sdk(value) for value in env.values())
    native = t.read(ON / 'runtime.json')['native']
    t.save(W / 'environment.json', env)
    t.save(W / 'runtime.json', dict(PATH=env['PATH'], native=native,
        removed_environment_directories=removed_environment,
        note='Runtime inherits normal environment but explicit Torch SDK search directories are removed; GGML CPU DLL is a same-file hardlink. No model/performance claim.'))
    t.save(W / 'off-sdk-inputs.json', offsdk); t.save(W / 'retained-stats.json', retained)
    t.save(W / 'plan.json', dict(status='PREPARED_NOT_FROZEN_ACTUAL_OFF',
        configure_process=t.pin(W.parent / 'configure-off-attempt3-run/process.json'),
        generated_review=t.pin(W.parent / 'off-generated-review.json'), compile_commands=t.pin(ccpath),
        baseline=t.pin(ON / 'ready-resident-direct.json'), baseline_inputs=ready['inputs'],
        baseline_source_freeze=t.pin(ON / 'source-freeze.json'),
        historical_handoff_amendment=t.pin(W.parent / 'verification-amendment.json'),
        removed=removed, removed_consumer=consumer, replacements=old, common_native_retained=common,
        units=units, gtest=gtest, targets=TARGETS,
        base_sdk=t.pin(W / 'off-sdk-inputs.json'), retained_stats=t.pin(W / 'retained-stats.json'),
        environment=t.pin(W / 'environment.json'), runtime=t.pin(W / 'runtime.json'),
        links={n: t.pin(W / f'link-recipes/{n}.json') for n in TARGETS},
        counts=dict(CXX=12, SDK_CXX=3, consumer_CXX=9, NVCC=0, links=4, native_processes=4,
                    ON_SDK=227, OFF_SDK=220, input_counts=INPUT_COUNTS),
        boundaries=['Actual OFF compile commands for3 SDK TUs; tests disabled in configure, so9 consumers explicitly adapt OFF native/Graph flags.',
                    'Reuse7 no-Torch ON native objects including kernel; this is a bounded incremental link, not full SDK build/install validation.',
                    'No optional ATen decoder/TF32/allocator claim in OFF. Original finite tests check native packed math/capture/lifetime, attention support/rejection, and runtime absence.',
                    'No model, download, performance or cross-platform run. ON results remain a separate image/batch.']))
    print('PREPARED ONLY:12CXX/0NVCC/4links/4runs; inputs221/221/228/221; no compiler/link/native started')


def plan():
    p = t.read(W / 'plan.json')
    for name in ('configure_process', 'generated_review', 'compile_commands', 'baseline', 'baseline_inputs', 'baseline_source_freeze',
                 'historical_handoff_amendment', 'base_sdk', 'retained_stats', 'environment', 'runtime'): t.exact(p[name])
    for row in p['units'].values(): t.exact(row['recipe'])
    for row in p['links'].values(): t.exact(row)
    return p


def project(path):
    p = Path(path).resolve()
    return t.project(p) or p.is_relative_to(R / 'third_party/mlx_cuda_quant')


def freeze():
    p = plan(); paths = {}; snapshots = []
    for unit in p['units'].values():
        roots = []
        for arg in t.command(unit['recipe']['path']):
            if arg.lower().startswith(('/external:i', '-external:i')): roots.append(Path(arg[len('/external:I'):]))
            elif arg.lower().startswith(('/i', '-i')): roots.append(Path(arg[2:]))
        pending = [R / unit['source']]; seen = set()
        while pending:
            path = pending.pop().resolve(); key = t.key(path)
            if key in seen: continue
            seen.add(key); paths[key] = path
            for kind, name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]', path.read_text(encoding='utf-8-sig'), re.M):
                child = next((q.resolve() for root in ([path.parent] if kind == '"' else []) + roots if (q := root / name).is_file()), None)
                if child is not None and project(child): pending.append(child)
    t.save(W / 'frozen-project-includes.json', [t.pin(path) for path in sorted(paths.values())])
    for source in (*SDK.values(), *TESTS.values()):
        target = W / 'source' / source; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write((R / source).read_bytes())
        snapshots.append(dict(original=t.pin(R / source), snapshot=t.pin(target)))
    t.save(W / 'source-freeze.json', dict(helper=t.pin(__file__), run_helper=t.pin(W / 'run.py'),
        run_plan=t.pin(W / 'run-plan.json'), plan=t.pin(W / 'plan.json'),
        includes=t.pin(W / 'frozen-project-includes.json'), snapshots=snapshots,
        boundary='Only OFF flag-sensitive3 SDK +9 actual consumers. Public layouts/vtables unchanged; external SDK headers recorded from actual CXX, not copied.'))
    print('FROZEN', len(paths), 'literal project inputs; metadata only')


def validate():
    p = plan(); f = t.read(W / 'source-freeze.json')
    for name in ('helper', 'run_helper', 'run_plan', 'plan', 'includes'): t.exact(f[name])
    for row in t.read(f['includes']['path']): t.exact(row)
    for row in f['snapshots']: t.exact(row['original']); t.exact(row['snapshot'])
    return p, f


def parse_compile(name):
    p, f = validate(); unit = p['units'][name]; out = W / f'compile/{name}'
    process = t.read(W / f'logs/{name}/process.json'); assert process['exit'] == 0 and not process['timed_out'], process
    deps = out / 'dependencies.json'; allowed = {t.key(row['path']): row for row in t.read(f['includes']['path'])}; actual = []
    for path in dict.fromkeys(t.dep_paths(deps)):
        path = path.resolve(); assert not torch_sdk(path), ('OFF acquired Torch SDK header', path)
        if project(path):
            assert t.key(path) in allowed, ('Compile succeeded; correct parser/freeze metadata without recompiling', str(path))
            t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out / 'actual-dependencies.json', actual)
    t.save(out / 'compiled.json', dict(source=t.pin(R / unit['source']), object=t.pin(out / 'unit.obj'), process=process,
        command=t.pin(W / f'logs/{name}/command.json'), dependencies=t.pin(deps), actual_dependencies=t.pin(out / 'actual-dependencies.json')))
    print('COMPILE PASS', name)


def compile_unit(name):
    p, _ = validate(); unit = p['units'][name]; (W / f'compile/{name}').mkdir(parents=True, exist_ok=False)
    t.execute(t.command(unit['recipe']['path']), W / f'logs/{name}', 300); parse_compile(name)


def link(target):
    p, _ = validate(); assert target in TARGETS
    compiled = {n: t.read(W / f'compile/{n}/compiled.json') for n in (*SDK, *TARGETS[target])}
    for row in compiled.values(): t.exact(row['object'])
    for row in t.read(p['retained_stats']['path']):
        st = Path(row['path']).stat(); assert (st.st_size, st.st_mtime_ns) == (row['bytes'], row['mtime_ns']), row['path']
    replacement = {t.key(row['path']): compiled[n]['object'] for n, row in p['replacements'].items()}
    rows = [replacement.get(t.key(row['path']), row) for row in t.read(p['base_sdk']['path'])]
    rows += [compiled[n]['object'] for n in TARGETS[target]]
    if target == 'ct': rows += p['gtest']
    assert len(rows) == INPUT_COUNTS[target] and len({t.key(row['path']) for row in rows}) == len(rows)
    assert not any(torch_sdk(row['path']) for row in rows)
    (W / 'bin').mkdir(exist_ok=True); native = t.read(p['runtime']['path'])['native']; alias = W / 'bin' / Path(native['path']).name
    if not alias.exists(): alias.hardlink_to(native['path'])
    assert alias.samefile(native['path']); t.save(W / f'inputs-{target}.json', rows)
    process = t.execute(t.command(p['links'][target]['path']), W / f'links/{target}', 240)
    t.save(W / f'ready-{target}.json', dict(image=t.pin(W / f'bin/{target}.exe'), inputs=t.pin(W / f'inputs-{target}.json'),
        compiled=compiled, process=process, recipe=t.pin(W / f'links/{target}/command.json'),
        runtime=p['runtime'], source_freeze=t.pin(W / 'source-freeze.json'), mode='ATen_OFF_ACTUAL_INCREMENTAL'))
    print('LINK PASS', target, len(rows))


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'prepare': prepare()
    elif action == 'freeze': freeze()
    elif action == 'preflight': validate(); print('PREFLIGHT PASS')
    elif action == 'compile': compile_unit(sys.argv[2])
    elif action == 'compile-all':
        for name in plan()['units']: compile_unit(name)
    elif action == 'parse-compile': parse_compile(sys.argv[2])
    elif action == 'link': link(sys.argv[2])
    elif action == 'link-all':
        for target in TARGETS: link(target)
    else: raise ValueError(action)
