"""Third CT attempt only; original lowering decides capture compatibility."""
from pathlib import Path
import importlib.util
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('off_attention_refinement',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);t=b.t


def parse():
    out=W/'runs/ct';process=t.read(out/'process.json')
    assert process['exit']==0 and not process['timed_out'],process
    root=ET.parse(out/'results.xml').getroot()
    tests=int(root.attrib['tests']);failures=int(root.attrib['failures']);errors=int(root.attrib['errors'])
    assert tests>0 and failures==0 and errors==0,(tests,failures,errors)
    cases=[]
    for row in root.findall('.//testcase'):
        skip=row.find('skipped')
        cases.append(dict(suite=row.attrib['classname'],name=row.attrib['name'],status='SKIP' if skip is not None else 'PASS',
            skip_reason=(skip.attrib.get('message','') or skip.text) if skip is not None else None))
    skipped=sum(row['status']=='SKIP' for row in cases);assert len(cases)==tests and tests>skipped
    passed={(row['suite'],row['name']) for row in cases if row['status']=='PASS'}
    for key in (('CudaCtPackedLinear','MissingIndependentDecoderRejectsPublishedViewAndControlEscapes'),
                ('CudaDefaultGraph','BroadBf16AttentionKeepsOriginalF32FallbackWithoutAten'),
                ('CudaDefaultGraph','MaturePrefillDecodeThroughNormalEntries')):
        assert key in passed,key
    t.save(out/'summary.json',dict(status='PASS_WITH_SKIPS' if skipped else 'PASS',process=process,mode='ATen_OFF',models=0,
        tests=tests,passed=tests-skipped,failures=failures,errors=errors,skipped=skipped,cases=cases,
        refinement='One attention test CXX; unchanged product. Existing legal ggml BF16/F32 managed fallback is checked numerically, not removed.',
        BF16_fallback=dict(provider='ggml_cuda',replay_class='Managed',capture_compatibility_asserted=False,Direct_and_Graph=True,
                           seeds=[0,3,9],last_query_scale=1048576,original_tolerance=0.01)))
    print('CT',tests-skipped,'PASS',skipped,'SKIP')


def run():
    p,_=b.validate();ready=t.read(W/'ready-ct.json');t.exact(ready['image']);t.exact(ready['inputs'])
    runtime=t.read(p['runtime']['path']);native=runtime['native']
    assert(W/'bin'/Path(native['path']).name).samefile(native['path'])
    out=W/'runs/ct';out.parent.mkdir(parents=True,exist_ok=True)
    t.execute([ready['image']['path'],'--gtest_output=xml:'+str(out/'results.xml')],out,240)
    t.save(out/'admission.json',dict(ready=t.pin(W/'ready-ct.json'),runtime=p['runtime'],models=0,
        note='Only corrected CT rerun. Both previous CT failures and other three successful OFF native records remain unchanged.'))
    parse()


if __name__=='__main__':
    if sys.argv[1]=='run':run()
    elif sys.argv[1]=='parse-only':parse()
    else:raise ValueError(sys.argv[1])
