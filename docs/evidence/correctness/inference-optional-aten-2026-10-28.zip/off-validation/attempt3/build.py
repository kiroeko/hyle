"""OFF attention third attempt: preserve both previous CT failures; one test CXX/link/run."""
from pathlib import Path
import difflib
import importlib.util
import re
import sys

sys.dont_write_bytecode = True
R=Path('C:/public/project-hyle/hyle');W=Path(__file__).resolve().parent;BASE=W.parent
SOURCE='tests/graph_route_cuda/attention_test.cc'
spec=importlib.util.spec_from_file_location('original_actual_off_driver',BASE/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);t=b.t;t.W=W


def prepare():
    ready=t.read(BASE/'ready-ct.json');t.exact(ready['inputs']);rows=t.read(ready['inputs']['path']);assert len(rows)==228
    frozen=t.read(BASE/'source-freeze.json');t.exact(frozen['includes'])
    old=ready['compiled']['attention']['object'];assert rows.count(old)==1
    process=t.read(BASE/'runs/ct/process.json');assert process['exit']==1 and process['state']=='TERMINAL'
    recipe=BASE/'recipes/attention.json';t.exact(t.read(BASE/'plan.json')['units']['attention']['recipe'])
    args=[]
    before=t.command(recipe)
    for i,arg in enumerate(before):
        if i and before[i-1].lower()=='/sourcedependencies':arg=str(W/'compile/attention/dependencies.json')
        elif arg.lower().startswith('/fo'):arg='/Fo'+str(W/'compile/attention/unit.obj')
        elif arg.lower().startswith('/fd'):arg='/Fd'+str(W/'compile/attention/unit.pdb')
        args.append(arg)
    b.check_off_args(args);t.save(W/'recipe-attention.json',dict(command=args,timeout_seconds=300))
    args=[]
    for arg in t.command(ready['recipe']['path']):
        if t.key(arg)==t.key(old['path']):arg=str(W/'compile/attention/unit.obj')
        for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
            if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/ct').with_suffix(suffix));break
        args.append(arg)
    assert sum(t.key(arg)==t.key(W/'compile/attention/unit.obj') for arg in args)==1
    b.check_off_args(args);t.save(W/'recipe-link.json',dict(command=args,timeout_seconds=240))
    retained=[]
    for row in rows:
        if row==old:continue
        st=Path(row['path']).stat();assert st.st_size==row['bytes']
        retained.append(dict(path=row['path'],bytes=st.st_size,mtime_ns=st.st_mtime_ns,retained_sha256=row['sha256']))
    assert len(retained)==227;t.save(W/'retained-stats.json',retained)
    env=t.read(BASE/'environment.json');env['PATH']=str(W/'bin')+';'+env['PATH'];t.save(W/'environment.json',env)
    runtime=t.read(BASE/'runtime.json');runtime['PATH']=env['PATH'];t.save(W/'runtime.json',runtime)
    t.save(W/'plan.json',dict(previous_attempt2_process=t.pin(BASE/'attempt2/runs/ct/process.json'),previous_attempt2_freeze=t.pin(BASE/'attempt2/source-freeze.json'),status='PREPARED_NOT_FROZEN',scope='Only attention test corrects its assumption about the existing legal ggml BF16/F32 fallback; no product CXX/math change.',
        source=SOURCE,parent_ready=t.pin(BASE/'ready-ct.json'),parent_inputs=ready['inputs'],parent_freeze=t.pin(BASE/'source-freeze.json'),
        original_failed_process=t.pin(BASE/'runs/ct/process.json'),old_object=old,original_recipe=t.pin(recipe),
        original_link=ready['recipe'],compile_recipe=t.pin(W/'recipe-attention.json'),link_recipe=t.pin(W/'recipe-link.json'),
        retained_stats=t.pin(W/'retained-stats.json'),environment=t.pin(W/'environment.json'),runtime=t.pin(W/'runtime.json'),
        counts=dict(CXX=1,NVCC=0,links=1,native_processes=1,inputs=228,retained=227),
        ON_attention_dependency=False,OFF_other_successes_reused=['resident-direct','resident-graph','runtime-disabled']))
    print('PREPARED attention1CXX/CT1link/1run;227 retained; no execution')


def plan():
    p=t.read(W/'plan.json')
    for name in ('parent_ready','parent_inputs','parent_freeze','original_failed_process','original_recipe','original_link',
                 'compile_recipe','link_recipe','retained_stats','environment','runtime','previous_attempt2_process','previous_attempt2_freeze'):t.exact(p[name])
    return p


def freeze():
    p=plan();old=t.read(p['parent_freeze']['path']);includes=t.read(old['includes']['path'])
    # Old snapshot bytes remain historical. Only this explicitly replaced TU
    # may differ; the successful SDK and other test inputs stay unchanged.
    for row in includes:
        if t.key(row['path'])!=t.key(R/SOURCE):t.exact(row)
    before=next(row['snapshot'] for row in old['snapshots'] if t.key(row['original']['path'])==t.key(R/SOURCE))
    t.exact(before);target=W/'source'/SOURCE;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as out:out.write((R/SOURCE).read_bytes())
    raw=''.join(difflib.unified_diff(Path(before['path']).read_text(encoding='utf-8').splitlines(keepends=True),
        (R/SOURCE).read_text(encoding='utf-8').splitlines(keepends=True),fromfile='a/'+SOURCE,tofile='b/'+SOURCE))
    with(W/'attention-oracle.diff').open('x',encoding='utf-8') as out:out.write(raw)
    pins=[t.pin(row['path']) if t.key(row['path'])==t.key(R/SOURCE) else row for row in includes]
    t.save(W/'frozen-project-includes.json',pins)
    t.save(W/'source-freeze.json',dict(helper=t.pin(__file__),run_helper=t.pin(W/'run.py'),plan=t.pin(W/'plan.json'),
        includes=t.pin(W/'frozen-project-includes.json'),source=t.pin(R/SOURCE),snapshot=t.pin(target),
        previous_source=before,patch=t.pin(W/'attention-oracle.diff')))
    print('FROZEN metadata only',len(pins),'existing project inputs, one changed test TU')


def validate():
    p=plan();f=t.read(W/'source-freeze.json')
    for name in ('helper','run_helper','plan','includes','source','snapshot','previous_source','patch'):t.exact(f[name])
    for row in t.read(f['includes']['path']):t.exact(row)
    return p,f


def parse_compile():
    p,f=validate();out=W/'compile/attention';process=t.read(W/'logs/attention/process.json')
    assert process['exit']==0 and not process['timed_out'],process
    allowed={t.key(row['path']):row for row in t.read(f['includes']['path'])};actual=[];deps=out/'dependencies.json'
    for path in dict.fromkeys(t.dep_paths(deps)):
        path=path.resolve();assert not b.torch_sdk(path)
        if b.project(path):assert t.key(path) in allowed,('Successful CXX metadata issue; parse only',str(path));t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out/'actual-dependencies.json',actual)
    t.save(out/'compiled.json',dict(source=f['source'],object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/'logs/attention/command.json'),dependencies=t.pin(deps),actual_dependencies=t.pin(out/'actual-dependencies.json')))
    print('COMPILE PASS attention')


def compile_unit():
    p,_=validate();(W/'compile/attention').mkdir(parents=True,exist_ok=False)
    t.execute(t.command(p['compile_recipe']['path']),W/'logs/attention',300);parse_compile()


def link():
    p,_=validate();compiled=t.read(W/'compile/attention/compiled.json');t.exact(compiled['object'])
    for row in t.read(p['retained_stats']['path']):
        st=Path(row['path']).stat();assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns']),row['path']
    rows=[compiled['object'] if row==p['old_object'] else row for row in t.read(p['parent_inputs']['path'])]
    assert len(rows)==228 and not any(b.torch_sdk(row['path']) for row in rows)
    native=t.read(p['runtime']['path'])['native'];(W/'bin').mkdir(exist_ok=True);alias=W/'bin'/Path(native['path']).name
    if not alias.exists():alias.hardlink_to(native['path'])
    assert alias.samefile(native['path']);t.save(W/'inputs-ct.json',rows)
    process=t.execute(t.command(p['link_recipe']['path']),W/'links/ct',240)
    parent=t.read(p['parent_ready']['path']);allcompiled=dict(parent['compiled']);allcompiled['attention']=compiled
    t.save(W/'ready-ct.json',dict(image=t.pin(W/'bin/ct.exe'),inputs=t.pin(W/'inputs-ct.json'),compiled=allcompiled,
        process=process,recipe=t.pin(W/'links/ct/command.json'),runtime=p['runtime'],source_freeze=t.pin(W/'source-freeze.json'),
        mode='ATen_OFF_ATTENTION_ORACLE_REFINEMENT'))
    print('LINK PASS CT228')


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze()
    elif action=='preflight':validate();print('PREFLIGHT PASS')
    elif action=='compile':compile_unit()
    elif action=='parse-compile':parse_compile()
    elif action=='link':link()
    else:raise ValueError(action)
