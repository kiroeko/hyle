"""Four explicit original consumers. No model, performance or automatic rerun."""
from pathlib import Path
import importlib.util
import os
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('optional_aten_windows_validation',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);t=b.t


def parse(target):
    assert target in b.TARGETS
    out=W/'runs'/target;process=t.read(out/'process.json')
    assert process['exit']==0 and not process['timed_out'],process
    stdout=(out/'stdout.log').read_text(encoding='utf-8',errors='replace')
    stderr=(out/'stderr.log').read_text(encoding='utf-8',errors='replace')
    if target=='resident-direct':
        expected='PASS CUDA public resident packed consumer: 64 steps, two slots, retained output'
        assert stdout.splitlines().count(expected)==1 and 'FAIL ' not in stderr
        summary=dict(status='PASS',process=process,original_report=expected,models=0,
            scope='One public native affine4/group64 geometry;64steps/two slots/retained caller output.')
    elif target=='resident-graph':
        lines=[line for line in stdout.splitlines() if line.startswith('PASS CUDA Graph packed ')]
        for geometry in ('M=1 bits=4 group=32','M=17 bits=5 group=64','M=1 bits=6 group=128','M=64 bits=8 group=32'):
            assert sum(line.startswith('PASS CUDA Graph packed '+geometry+':65 steps/') for line in lines)==1,lines
        assert len(lines)==4 and 'FAIL ' not in stderr
        summary=dict(status='PASS',process=process,original_reports=lines,models=0,capture_test=False,
            scope='Original Commands replay:4 geometries/65steps each/two queues+slots/concurrency/device IDs/checked failure/new-slot recovery/retained outputs. CT target separately tests capture.')
    else:
        root=ET.parse(out/'results.xml').getroot();tests=int(root.attrib['tests']);failures=int(root.attrib['failures']);errors=int(root.attrib['errors'])
        assert tests>0 and failures==0 and errors==0,(tests,failures,errors)
        cases=[]
        for row in root.findall('.//testcase'):
            skip=row.find('skipped')
            cases.append(dict(suite=row.attrib['classname'],name=row.attrib['name'],
                status='SKIP' if skip is not None else 'PASS',
                skip_reason=(skip.attrib.get('message','') or skip.text) if skip is not None else None))
        skipped=sum(row['status']=='SKIP' for row in cases);assert len(cases)==tests
        assert tests-skipped>0,'No actual test; do not report all-skipped as passed'
        summary=dict(status='PASS_WITH_SKIPS' if skipped else 'PASS',process=process,models=0,
            tests=tests,passed=tests-skipped,failures=failures,errors=errors,skipped=skipped,cases=cases)
    t.save(out/'summary.json',summary);print(target,summary['status'])


def run(target):
    b.validate();assert target in b.TARGETS;ready=t.read(W/f'ready-{target}.json')
    t.exact(ready['image']);t.exact(ready['inputs']);runtime=t.read(ready['runtime']['path'])
    native=runtime['native'];assert(W/'bin'/Path(native['path']).name).samefile(native['path'])
    env=os.environ.copy();env.update(PATH=runtime['PATH'],HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    out=W/'runs'/target;out.mkdir(parents=True,exist_ok=False);args=[ready['image']['path']]
    if target in ('ct','torch'):args.append('--gtest_output=xml:'+str(out/'results.xml'))
    t.save(out/'command.json',dict(command=args,cwd=str(b.R),timeout_seconds=240,
        ready=t.pin(W/f'ready-{target}.json'),runtime=ready['runtime'],
        environment_relevant={name:env[name] for name in ('CUDA_VISIBLE_DEVICES','CUDA_MODULE_LOADING','OMP_NUM_THREADS','MKL_NUM_THREADS') if name in env},
        scope='DefaultON related synthetic component only; no model, download or performance window.'))
    started=time.time();timed_out=False
    with(out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
        child=subprocess.Popen(args,cwd=b.R,env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        t.save(out/'running.json',dict(pid=child.pid,started=started))
        try:code=child.wait(timeout=240)
        except subprocess.TimeoutExpired:
            timed_out=True;child.terminate()
            try:code=child.wait(timeout=10)
            except subprocess.TimeoutExpired:child.kill();code=child.wait(timeout=10)
    process=dict(pid=child.pid,exit=code,started=started,seconds=time.time()-started,state='TERMINAL',timed_out=timed_out)
    t.save(out/'process.json',process);assert code==0 and not timed_out,process
    parse(target)


if __name__=='__main__':
    if sys.argv[1]=='run':run(sys.argv[2])
    elif sys.argv[1]=='parse-only':parse(sys.argv[2])
    else:raise ValueError(sys.argv[1])
