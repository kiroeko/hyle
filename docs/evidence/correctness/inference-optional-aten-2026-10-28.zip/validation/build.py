"""Default-ON native artifact migration, bounded recipes; root owns all execution."""
from pathlib import Path
import importlib.util
import re
import sys

sys.dont_write_bytecode=True
R=Path('C:/public/project-hyle/hyle');W=Path(__file__).resolve().parent
BASE=R/'.scratch/inference-cpu-routing-20261028/validation'
HANDOFF=W.parent/'handoff.json'
spec=importlib.util.spec_from_file_location('original_windows_artifact_driver',R/'.scratch/inference-indexed-store-20261028/build.py')
t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t);t.W=W
SDK={'native-artifact':'src/compute_provider_cuda/artifact_provider.cc',
 'cuda-provider':'src/compute_provider_cuda/cuda_provider.cc','cuda-policy':'src/compute_route_cuda/default_policy.cc',
 'graph-packed':'src/graph_route_cuda/ct_packed_linear_region.cc',
 'graph-dense':'src/graph_route_cuda/dense_bfloat_scores_region.cc','graph-context':'src/graph_route_cuda/cuda_context.cc',
 'torch-artifact':'src/compute_provider_torch_cuda/artifact_provider.cc','native-kernel':'src/compute_provider_cuda/artifact_kernel.cu'}
TESTS={'resident-direct':'tests/compute_provider_cuda/packed_resident_consumer.cc',
 'resident-graph':'tests/graph_route_cuda/packed_resident_consumer.cc',
 'ct-grouped':'tests/graph_route_cuda/ct_packed_grouped_test.cc','ct-linear':'tests/graph_route_cuda/ct_packed_linear_test.cc',
 'ct-gptq':'tests/graph_route_cuda/gptq_reference_test.cc','ct-fp8':'tests/graph_route_cuda/static_fp8_reference_test.cc',
 'ct-scalar':'tests/graph_route_cuda/scalar_float_test.cc',
 'torch-packed':'tests/compute_provider_torch_cuda/packed_test.cc','torch-precision':'tests/compute_provider_torch_cuda/mlx_precision_test.cc'}
TARGETS={'resident-direct':('resident-direct',),'resident-graph':('resident-graph',),
 'ct':('ct-grouped','ct-linear','ct-gptq','ct-fp8','ct-scalar'),'torch':('torch-packed','torch-precision')}


def prepare():
    ready=t.read(BASE/'ready-direct.json');t.exact(ready['inputs']);rows=t.read(ready['inputs']['path']);assert len(rows)==230
    removed=[ready['compiled'][n]['object'] for n in ('direct','direct-context')]
    removed += [row for row in rows if Path(row['path']).name.lower() in ('gtest.lib','gtest_main.lib')]
    assert len(removed)==4 and all(rows.count(row)==1 for row in removed)
    sdkrows=[row for row in rows if row not in removed];assert len(sdkrows)==226
    gtest=removed[2:];assert len(gtest)==2
    handoff=t.read(HANDOFF);candidates={row['source']:row for row in handoff['validation']['recipe_candidates']}
    units={};old={}
    for name,source in SDK.items():
        item=candidates[source];command=R/item['candidate']['path'];t.exact(dict(item['candidate'],path=str(command)))
        before=t.command(command)
        oldsource=next(arg for arg in before if not arg.startswith(('/','-')) and Path(arg).suffix.lower() in ('.cc','.cu'))
        if 'inference-packed-sequence-20261028' in str(command):
            deps=R/'.scratch/inference-packed-sequence-20261028/compile/cuda-provider/dependencies.json'
            obj=deps.parent/'unit.obj'
        else:
            deps=command.parent/('unit.d' if source.endswith('.cu') else 'dependencies.json');obj=command.parent/'unit.obj'
        if name!='native-artifact':
            matches=[row for row in sdkrows if t.key(row['path'])==t.key(obj)];assert len(matches)==1,(name,obj)
            old[name]=matches[0]
        args=[]
        if name=='native-kernel':
            i=0
            while i<len(before):
                arg=before[i]
                if arg in ('-isystem','-I') and i+1<len(before):
                    val=before[i+1]
                    if 'torch' in val.lower():i+=2;continue
                    args.extend((arg,val));i+=2;continue
                if any(s in arg for s in ('HYLE_COMPUTE_PROVIDER_TORCH_CUDA_BUILD','HYLE_COMPUTE_TORCH_CUDA','USE_C10D_GLOO','USE_DISTRIBUTED')):i+=1;continue
                if arg.startswith('-I') and 'src\\compute_provider_torch_cuda' in arg:
                    arg='-I'+str(R/'src/compute_provider_cuda')
                if arg.startswith('-I') and any(s in arg for s in ('bitsandbytes_cuda','awq_cuda','compressed_tensors_cuda')):i+=1;continue
                if t.key(arg)==t.key(oldsource):arg=str(R/source)
                elif i and before[i-1] in ('-o','-MT'):arg=str(W/f'compile/{name}/unit.obj')
                elif i and before[i-1]=='-MF':arg=str(W/f'compile/{name}/dependencies.d')
                elif '-Fd' in arg:arg=re.sub(r'-Fd[^,]+','-Fd'+str(W/f'compile/{name}/unit.pdb').replace('\\','/'),arg)
                args.append(arg);i+=1
            args.append('-DHYLE_COMPUTE_PROVIDER_CUDA_BUILD')
            assert not any('torch' in arg.lower() for arg in args),'Native kernel retained Torch recipe dependency'
            assert any('compute_89' in a and 'sm_89' in a for a in args) and '-std=c++20' in args
        else:
            for i,arg in enumerate(before):
                if t.key(arg)==t.key(oldsource):arg=str(R/source)
                elif i and before[i-1].lower()=='/sourcedependencies':arg=str(W/f'compile/{name}/dependencies.json')
                elif arg.lower().startswith('/fo'):arg='/Fo'+str(W/f'compile/{name}/unit.obj')
                elif arg.lower().startswith('/fd'):arg='/Fd'+str(W/f'compile/{name}/unit.pdb')
                args.append(arg)
            assert '/WX' in args and '/MD' in args and '/O2' in args
            if name=='native-artifact':
                assert not any('torch' in a.lower() for a in args),'Native adapter inherited Torch dependency'
        t.save(W/f'recipes/{name}.json',dict(command=args,timeout_seconds=300))
        units[name]=dict(source=source,kind='NVCC' if source.endswith('.cu') else 'CXX',
            original_command=t.pin(command),original_dependencies=t.pin(deps),original_source=oldsource,
            old_object=old.get(name),recipe=t.pin(W/f'recipes/{name}.json'))
    # Consumers use current public SDK contracts. The5 CT sources keep their
    # existing ON independent-decoder cases; Torch tests retain exact headers.
    for name,source in TESTS.items():
        template=units['torch-artifact' if name.startswith('torch-') else 'graph-context']
        before=t.command(template['original_command']['path']);args=[]
        for i,arg in enumerate(before):
            if t.key(arg)==t.key(template['original_source']):arg=str(R/source)
            elif i and before[i-1].lower()=='/sourcedependencies':arg=str(W/f'compile/{name}/dependencies.json')
            elif arg.lower().startswith('/fo'):arg='/Fo'+str(W/f'compile/{name}/unit.obj')
            elif arg.lower().startswith('/fd'):arg='/Fd'+str(W/f'compile/{name}/unit.pdb')
            args.append(arg)
        gtest_includes=[a for a in t.command(ready['compiled']['direct']['command']['path']) if 'googletest' in a.lower() and a.lower().startswith(('/i','/external:i'))]
        for arg in gtest_includes:
            if arg not in args:args.append(arg)
        if '/DHYLE_COMPUTE_TORCH_CUDA=1' not in args:args.append('/DHYLE_COMPUTE_TORCH_CUDA=1')
        assert '/WX' in args and '/MD' in args and '/O2' in args
        t.save(W/f'recipes/{name}.json',dict(command=args,timeout_seconds=300))
        units[name]=dict(source=source,kind='CXX',original_command=template['original_command'],
            original_dependencies=template['original_dependencies'],original_source=template['original_source'],
            recipe=t.pin(W/f'recipes/{name}.json'))
    assert len(old)==7 and len(units)==17
    exclusion={t.key(row['path']) for row in removed};replacements={t.key(row['path']):str(W/f'compile/{name}/unit.obj') for name,row in old.items()}
    for target,names in TARGETS.items():
        args=[]
        for arg in t.command(ready['recipe']['path']):
            if t.key(arg) in exclusion:continue
            arg=replacements.get(t.key(arg),arg)
            for prefix,suffix in (('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')):
                if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/target).with_suffix(suffix));break
            args.append(arg)
        args.append(str(W/'compile/native-artifact/unit.obj'))
        args.extend(str(W/f'compile/{name}/unit.obj') for name in names)
        if target in ('ct','torch'):args.extend(row['path'] for row in gtest)
        assert all(sum(t.key(a)==t.key(p) for a in args)==1 for p in replacements.values())
        t.save(W/f'link-recipes/{target}.json',dict(command=args,timeout_seconds=240))
    retained=[]
    for row in [r for r in sdkrows if t.key(r['path']) not in replacements]+gtest:
        st=Path(row['path']).stat();assert st.st_size==row['bytes']
        retained.append(dict(path=row['path'],bytes=st.st_size,mtime_ns=st.st_mtime_ns,retained_sha256=row['sha256']))
    assert len(retained)==221
    t.save(W/'base-sdk-inputs.json',sdkrows);t.save(W/'retained-stats.json',retained)
    env=t.read(BASE/'environment.json');env['PATH']=str(W/'bin')+';'+env['PATH'];t.save(W/'environment.json',env)
    t.save(W/'runtime.json',dict(PATH=env['PATH'],native=t.read(BASE/'runtime.json')['native']))
    t.save(W/'plan.json',dict(status='PREPARED_NOT_FROZEN_DEFAULT_ON',baseline=t.pin(BASE/'ready-direct.json'),
        inputs=ready['inputs'],removed_consumers_and_gtest=removed,base_sdk=t.pin(W/'base-sdk-inputs.json'),
        handoff=t.pin(HANDOFF),units=units,old_objects=old,gtest=gtest,
        environment=t.pin(W/'environment.json'),runtime=t.pin(W/'runtime.json'),retained_stats=t.pin(W/'retained-stats.json'),
        links={n:t.pin(W/f'link-recipes/{n}.json') for n in TARGETS},targets=TARGETS,
        counts=dict(CXX=16,NVCC=1,SDK_CXX=7,consumer_CXX=9,links=4,base_SDK=226,new_SDK=227,
            input_counts={'resident-direct':228,'resident-graph':228,'ct':234,'torch':231}),
        scope='DefaultON only. Replace7 SDK objects/add native artifact adapter1. Preserve CPU current5 and all other original SDK/input rosters. No model/whole SDK build; OFF requires a real separate lightweight CMake closure, not manifest subtraction.'))
    print('PREPARED16CXX+1NVCC/4links;228/228/234/231 inputs; no source freeze/compiler/native process')


def plan():
    p=t.read(W/'plan.json')
    for key in ('baseline','inputs','base_sdk','handoff','environment','runtime','retained_stats'):t.exact(p[key])
    for unit in p['units'].values():
        for key in ('original_command','original_dependencies','recipe'):t.exact(unit[key])
    for row in p['links'].values():t.exact(row)
    return p


def project(path):
    path=Path(path).resolve()
    return t.project(path) or path.is_relative_to(R/'third_party/mlx_cuda_quant')


def freeze():
    p=plan();paths={};snapshots=[]
    for unit in p['units'].values():
        args=t.command(unit['recipe']['path']);roots=[]
        for i,arg in enumerate(args):
            if arg.lower().startswith('/external:i'):roots.append(Path(arg[len('/external:I'):]))
            elif arg.lower().startswith('/i'):roots.append(Path(arg[2:]))
            elif arg.startswith('-I'):roots.append(Path(arg[2:]))
            elif arg=='-isystem':roots.append(Path(args[i+1]))
        pending=[R/unit['source']];seen=set()
        while pending:
            path=pending.pop().resolve();key=t.key(path)
            if key in seen:continue
            seen.add(key);paths[key]=path
            for kind,name in re.findall(r'^\s*#\s*include\s*([<"])([^>"\r\n]+)[>"]',path.read_text(encoding='utf-8-sig'),re.M):
                q=next((v.resolve() for root in ([path.parent] if kind=='"' else [])+roots if(v:=root/name).is_file()),None)
                if q is not None and project(q):pending.append(q)
    t.save(W/'frozen-project-includes.json',[t.pin(path) for path in sorted(paths.values())])
    for source in [*SDK.values(),*TESTS.values(),'src/compute_provider_cuda/artifact_provider.h',
                   'src/compute_provider_cuda/artifact_kernel.h','src/graph_route_cuda/ct_packed_linear_region.h']:
        target=W/'source'/source;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write((R/source).read_bytes())
        snapshots.append(dict(original=t.pin(R/source),snapshot=t.pin(target)))
    t.save(W/'source-freeze.json',dict(helper=t.pin(__file__),plan=t.pin(W/'plan.json'),
        includes=t.pin(W/'frozen-project-includes.json'),snapshots=snapshots,
        boundary='No public layout/vtable changes. Native target adapter/kernel use native macros; original ATen ON decoder remains separately compiled. Actual external SDK headers recorded after CXX/NVCC, not copied/prehashed here.'))
    print('FROZEN',len(paths),'literal project includes; metadata only')


def validate():
    p=plan();f=t.read(W/'source-freeze.json')
    for key in ('helper','plan','includes'):t.exact(f[key])
    for row in t.read(f['includes']['path']):t.exact(row)
    for row in f['snapshots']:t.exact(row['original']);t.exact(row['snapshot'])
    return p,f


def parse_compile(name):
    p,f=validate();unit=p['units'][name];out=W/f'compile/{name}';process=t.read(W/f'logs/{name}/process.json')
    assert process['exit']==0 and not process['timed_out'],process
    dep=out/('dependencies.d' if unit['kind']=='NVCC' else 'dependencies.json')
    allowed={t.key(row['path']):row for row in t.read(f['includes']['path'])};actual=[]
    for path in dict.fromkeys(t.dep_paths(dep)):
        path=path.resolve()
        if project(path):
            assert t.key(path) in allowed,('Successful compile metadata issue; parse only, never rebuild',str(path));t.exact(allowed[t.key(path)])
        actual.append(t.pin(path))
    t.save(out/'actual-dependencies.json',actual)
    t.save(out/'compiled.json',dict(source=t.pin(R/unit['source']),object=t.pin(out/'unit.obj'),process=process,
        command=t.pin(W/f'logs/{name}/command.json'),dependencies=t.pin(dep),actual_dependencies=t.pin(out/'actual-dependencies.json')))
    print('COMPILE metadata PASS',name)


def compile_unit(name):
    p,_=validate();unit=p['units'][name];(W/f'compile/{name}').mkdir(parents=True,exist_ok=False)
    t.execute(t.command(unit['recipe']['path']),W/f'logs/{name}',300);parse_compile(name)


def link(target):
    p,_=validate();assert target in TARGETS
    compiled={n:t.read(W/f'compile/{n}/compiled.json') for n in (*SDK,*TARGETS[target])}
    for row in compiled.values():t.exact(row['object'])
    for row in t.read(p['retained_stats']['path']):
        st=Path(row['path']).stat();assert(st.st_size,st.st_mtime_ns)==(row['bytes'],row['mtime_ns']),row['path']
    replacements={t.key(row['path']):compiled[n]['object'] for n,row in p['old_objects'].items()}
    rows=[replacements.get(t.key(row['path']),row) for row in t.read(p['base_sdk']['path'])]
    rows += [compiled['native-artifact']['object']]+[compiled[n]['object'] for n in TARGETS[target]]
    if target in ('ct','torch'):rows+=p['gtest']
    assert len(rows)==p['counts']['input_counts'][target]
    assert len({t.key(row['path']) for row in rows})==len(rows)
    (W/'bin').mkdir(exist_ok=True);native=t.read(p['runtime']['path'])['native'];alias=W/'bin'/Path(native['path']).name
    if not alias.exists():alias.hardlink_to(native['path'])
    assert alias.samefile(native['path']);t.save(W/f'inputs-{target}.json',rows)
    process=t.execute(t.command(p['links'][target]['path']),W/f'links/{target}',240)
    t.save(W/f'ready-{target}.json',dict(image=t.pin(W/f'bin/{target}.exe'),inputs=t.pin(W/f'inputs-{target}.json'),
        compiled=compiled,process=process,recipe=t.pin(W/f'links/{target}/command.json'),runtime=p['runtime'],source_freeze=t.pin(W/'source-freeze.json')))
    print('LINK PASS',target,len(rows))


if __name__=='__main__':
    action=sys.argv[1]
    if action=='prepare':prepare()
    elif action=='freeze':freeze()
    elif action=='preflight':validate();print('PREFLIGHT PASS')
    elif action=='compile':compile_unit(sys.argv[2])
    elif action=='compile-all':
        for name in plan()['units']:compile_unit(name)
    elif action=='parse-compile':parse_compile(sys.argv[2])
    elif action=='link':link(sys.argv[2])
    else:raise ValueError(action)
