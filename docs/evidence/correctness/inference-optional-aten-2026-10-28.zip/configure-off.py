from pathlib import Path
import json,os,subprocess,time
W=Path(__file__).resolve().parent
p=json.loads((W/'off-configure-plan.json').read_text(encoding='utf-8'))
for name in p['optional_file_api_query_files_to_create_before_future_configure']:
 f=Path(name);f.parent.mkdir(parents=True,exist_ok=True);f.write_text('',encoding='utf-8')
env=os.environ.copy();env.update(json.loads(Path(p['environment_source']['path']).read_text(encoding='utf-8')))
out=W/'configure-off-run';out.mkdir(exist_ok=False)
args=p['preferred_cmake_argv']
(out/'command.json').write_text(json.dumps({'command':args,'cwd':p['source'],'environment_source':p['environment_source'],'timeout_seconds':300},indent=2),encoding='utf-8')
start=time.time();timed_out=False
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 child=subprocess.Popen(args,cwd=p['source'],env=env,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
 (out/'running.json').write_text(json.dumps({'pid':child.pid,'started':start}),encoding='utf-8')
 try: code=child.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timed_out=True;child.terminate();code=child.wait(timeout=15)
result={'pid':child.pid,'exit':code,'started':start,'seconds':time.time()-start,'timed_out':timed_out,'state':'TERMINAL'}
(out/'process.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(result)
print((out/'stdout.log').read_text(encoding='utf-8',errors='replace')[-3000:]);print((out/'stderr.log').read_text(encoding='utf-8',errors='replace')[-3500:])
raise SystemExit(0 if code==0 and not timed_out else 1)
