"""Read one terminal OFF configure and its generated metadata. Never runs a tool."""
from pathlib import Path
import hashlib, json, re, sys
W=Path(__file__).resolve().parent
R=W.parents[1]
B=W/'configure-cpu-cuda-off'
A=W/(sys.argv[1] if len(sys.argv)>1 else 'configure-off-attempt4-run')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def pin(p):
 p=Path(p);v=p.read_bytes();return {'path':str(p),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def key(p):return str(p).replace('\\','/').lower()
def text(p):return Path(p).read_text(encoding='utf-8',errors='replace')
process=read(A/'process.json')
assert process.get('state')=='TERMINAL', 'configure is still active; do not read growing generated outputs'
if process.get('exit')!=0 or process.get('timed_out'):
 result={'status':'CONFIGURE_FAILED_NO_CLOSURE_CLAIM','process':process,
         'process_identity':pin(A/'process.json'),'stderr_tail':text(A/'stderr.log')[-5000:],
         'limit':'Generated outputs are not reviewed after a failed configure. No native run.'}
 out=W/('off-generated-review-'+A.name+'.json')
 out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':result['status'],'file':str(out)}));raise SystemExit(1)
cache={}
for line in text(B/'CMakeCache.txt').splitlines():
 m=re.match(r'^([^#/:][^:=]*):[^=]*=(.*)$',line)
 if m:cache[m[1]]=m[2]
assert cache.get('HYLE_WITH_ATEN')=='OFF'
assert cache.get('HYLE_COMPUTE_ROUTES')=='cpu;cuda'
assert cache.get('FETCHCONTENT_FULLY_DISCONNECTED')=='ON'
commands=read(B/'compile_commands.json')
sources={key(x['file']) for x in commands}
required=['src/compute_provider_cuda/artifact_provider.cc','src/compute_provider_cuda/artifact_kernel.cu',
 'src/compute_provider_cuda/sequence_provider.cc','src/compute_provider_cuda/sequence_kernel.cu',
 'src/compute_provider_cuda/causal_conv_provider.cc','src/compute_provider_cuda/causal_conv_kernel.cu',
 'src/compute_provider_cuda/fp8_provider.cc','src/compute_provider_native/aten_cpu_provider.cc',
 'src/compute_provider_native/native_provider.cc','src/compute_provider_native/sequence.cc']
for name in required:assert key(R/name) in sources, 'missing independent native source: '+name
for name in ['src/compute_provider_torch_cuda/artifact_provider.cc','src/compute_provider_native/torch_cpu_program.cc']:
 assert key(R/name) not in sources, 'ATen implementation remains: '+name
joined='\n'.join(str(x.get('command',x.get('arguments',''))) for x in commands)
for macro in ['HYLE_COMPUTE_TORCH_CPU','HYLE_COMPUTE_TORCH_CUDA']:
 assert macro not in joined, 'ATen compile capability remains: '+macro
sdk_include_tokens=[x for x in commands if re.search(r'(?:libtorch[/\\]include|sdks[/\\]torch-(?:cpu|cuda-leaf))',str(x),re.I)]
assert not sdk_include_tokens, 'ATen SDK includes remain'
reply=B/'.cmake/api/v1/reply'
indices=sorted(reply.glob('index-*.json'));assert indices,'missing File API index'
index=read(indices[-1]);cm=index['reply']['codemodel-v2'];model=read(reply/cm['jsonFile'])
rows=model['configurations'][0]['targets'];byname={x['name']:x for x in rows}
names=['hyle_compute_provider_native','hyle_compute_provider_cuda','hyle_compute_route_cpu','hyle_compute_route_cuda','hyle_graph_route_cuda']
selected=[]
for name in names:
 assert name in byname, 'missing actual target '+name
 j=read(reply/byname[name]['jsonFile'])
 selected.append({'name':name,'type':j['type'],'source_count':len(j.get('sources',[])),
  'sources':[s['path'] for s in j.get('sources',[])],
  'defines':sorted({d['define'] for g in j.get('compileGroups',[]) for d in g.get('defines',[])}),
  'dependency_ids':[d['id'] for d in j.get('dependencies',[])],
  'metadata':pin(reply/byname[name]['jsonFile'])})
assert all(not any('HYLE_COMPUTE_TORCH_' in d for d in x['defines']) for x in selected)
# Static source-only stubs and optional placeholder names are legal; actual ATen runtime imports are not.
runtime=re.compile(r'(?i)(?:torch(?:_cpu|_cuda)?|c10(?:_cuda)?)\.(?:lib|dll|so(?:\.\d+)*)')
for name in ['hyle_compute_provider_torch_cuda']:
 if name in byname:
  j=read(reply/byname[name]['jsonFile']);assert not j.get('sources'),'ATen provider still compiles sources'
ninja=text(B/'build.ninja');assert not runtime.search(ninja),'ATen vendor/runtime link remains in generated build'
exports=sorted((B/'CMakeFiles/Export').rglob('HyleTargets-*.cmake'));assert exports,'missing generated install exports'
package_paths=[B/'HylePackageIndex.cmake',B/'HyleConfig.cmake',*exports]
package='\n'.join(text(p) for p in package_paths)
assert not re.search(r'HyleTorch(?:Cpu|Cuda)Sdk|hyle_vendor_(?:torch|c10)',package,re.I),'ATen export/SDK dependency remains'
for line in package.splitlines():
 if re.search(r'INTERFACE_COMPILE_DEFINITIONS|HYLE_COMPUTE_CAPABILITIES',line):
  assert not re.search(r'HYLE_COMPUTE_TORCH_|torch_cpu|torch_cuda',line,re.I),'Enabled ATen export capability remains'
assert not runtime.search(package),'ATen import remains in installed export'
install=text(B/'cmake_install.cmake')
assert 'mlx_cuda_quant-LICENSE' in install and 'mlx_cuda_quant-NOTICE.md' in install,'native codec license assets missing'
assert not re.search(r'HyleTorch(?:Cpu|Cuda)Sdk|torch-(?:cpu|cuda)-sdk',install,re.I),'ATen SDK installation remains'
# Actual successful generation plus sole current registration prove the codec owner.
# Generated exports themselves do not serialize the registry OWNER property.
owner_sources=[R/'CMakeLists.txt',R/'src/compute_provider_cuda/CMakeLists.txt',R/'src/compute_provider_torch_cuda/CMakeLists.txt']
registrations=[]
for path in owner_sources:
 for body in re.findall(r'hyle_register_package_dependency\((.*?)\)',text(path),re.S):
  if re.search(r'\bNAME\s+mlx_cuda_quant\b',body):
   match=re.search(r'\bOWNER\s+([a-z_]+)',body);assert match
   registrations.append({'source':str(path),'owner':match[1]})
assert len(registrations)==1 and registrations[0]['owner']=='compute_provider_cuda','MLX registry owner is not uniquely native'
assert 'mlx_cuda_quant' not in text(R/'src/compute_provider_torch_cuda/CMakeLists.txt'),'Torch-only factor still depends on native codec'
assert install.count('third_party/mlx_cuda_quant/LICENSE')==1 and install.count('third_party/mlx_cuda_quant/NOTICE.md')==1,'Codec license install duplicated or lost'

compiler_facts={}
for language in ['CXX','CUDA']:
 for p in (B/'CMakeFiles').glob('*/CMake'+language+'Compiler.cmake'):
  vals={m[1]:m[2] for m in re.finditer(r'set\((CMAKE_'+language+r'_(?:COMPILER|COMPILER_VERSION|HOST_COMPILER|HOST_COMPILER_VERSION)) "([^"]*)"\)',text(p))}
  compiler_facts.update(vals)
result={'schema':'hyle.optional-aten.generated-review.v2','status':'PASS_OFF_GENERATED_DEPENDENCY_CLOSURE_ONLY','process':process,
 'configure_process':process,'configure_receipt':pin(A/'process.json'),'build_directory':str(B),
 'process_identity':pin(A/'process.json'),'command_identity':pin(A/'command.json'),
 'mode':{'routes':cache['HYLE_COMPUTE_ROUTES'],'ATen':cache['HYLE_WITH_ATEN'],'offline':cache['FETCHCONTENT_FULLY_DISCONNECTED'],'static':cache.get('HYLE_STATIC')},
 'compile_commands_count':len(commands),'required_independent_native_sources_present':required,
 'aten_implementation_sources':0,'aten_compile_capabilities':0,'aten_sdk_includes':0,
 'aten_generated_vendor_links':0,'aten_export_sdk_dependencies':0,
 'legacy_name_note':'HyleConfig.cmake rejection table still names retired HYLE_COMPUTE_TORCH_CPU input. This is not an enabled capability; actual compile_commands, codemodel defines and exported target capability fields contain no ATen.',
 'offline_parser_correction':pin(W/'off-generated-review-parser-attempt1.json'),
 'targets':selected,'generated_export_count':len(exports),'native_codec_license_assets':True,
 'codec_owner':{'registrations':registrations,'source_identities':list(map(pin,owner_sources)),'amendment':pin(W/'native-codec-owner-amendment.json'),'native_installed_license_files_once_each':True,'limit':'Owner is established by successful generated closure and exact sole current CMake registration. An exact Torch-only configuration was not run; no codec dependency remains in its source factor.'},
 'supersedes_generated_metadata_review':pin(W/'off-generated-review.json'),
 'metadata_identities':[pin(B/'CMakeCache.txt'),pin(B/'compile_commands.json'),pin(B/'build.ninja'),pin(indices[-1]),*map(pin,package_paths),pin(B/'cmake_install.cmake')],
 'compiler_facts':compiler_facts,
 'observed_host_version_equal':compiler_facts.get('CMAKE_CXX_COMPILER_VERSION')==compiler_facts.get('CMAKE_CUDA_HOST_COMPILER_VERSION'),
 'toolchain_limit':'This configure did not explicitly set CMAKE_CUDA_HOST_COMPILER. Actual CMake VERSION facts, not directory names, govern the observation: CXX and CUDA host both report 19.50.35728.0. The earlier directory-name inference of a mismatch was incorrect; no toolchain drift or new functionality task is established.',
 'scope':'Actual successful CMake configure/generation and installed-export metadata only. No product build, native execution, SDK install, numerical or throughput result. Existing aten_cpu_provider.cc is the expected no-ATen stub, not a retained ATen dependency.'}
out=W/'off-generated-review-v4.json';assert not out.exists(), 'Do not overwrite an existing final review';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'file':str(out),'compile_commands':len(commands),'exports':len(exports),'sha256':pin(out)['sha256']}))
