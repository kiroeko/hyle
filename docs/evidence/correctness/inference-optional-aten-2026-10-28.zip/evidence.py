"""Offline only. Root invokes after both actual ON/OFF finite batches finish."""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

R=Path('C:/public/project-hyle/hyle');W=Path(__file__).resolve().parent;V=W/'validation';O=W/'off-validation';A=O/'attempt3';Q=O/'attempt2'
DEST=R/'docs/evidence/correctness/inference-optional-aten-2026-10-28'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value):return(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def pin(path):
    p=Path(path);raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=digest(raw))
def exact(row):
    now=pin(row['path']);assert(now['bytes'],now['sha256'])==(row['bytes'],row['sha256']),row['path']
def success(path):
    row=read(path);assert row['state']=='TERMINAL' and row['exit']==0 and not row.get('timed_out',False),(str(path),row)
    return row


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--off-review',type=Path,default=W/'off-generated-review-v4.json')
    parser.add_argument('--patch',type=Path);args=parser.parse_args()
    off=read(args.off_review)
    assert off['status']=='PASS_OFF_GENERATED_DEPENDENCY_CLOSURE_ONLY','Final OFF review is not complete/passed'
    assert off['schema']=='hyle.optional-aten.generated-review.v2'
    assert off['configure_process']['exit']==0
    amendment=read(W/'verification-amendment.json');assert amendment['original_handoff_bytes_available'] is False
    exact(amendment['original_plan']);exact(amendment['original_freeze']);exact(amendment['current_handoff'])
    p=read(V/'plan.json');f=read(V/'source-freeze.json');exact(f['plan']);exact(f['helper']);exact(f['includes'])
    includes=read(f['includes']['path']);assert len(includes)==148
    for row in includes:exact(row)
    for pair in f['snapshots']:exact(pair['original']);exact(pair['snapshot'])
    assert p['handoff']==amendment['original_handoff_identity'],'Do not rewrite original historical admission pin'
    units=p['units'];assert(len(units),sum(row['kind']=='NVCC' for row in units.values()))==(17,1)
    compiles={name:success(V/f'logs/{name}/process.json') for name in units}
    targets=('resident-direct','resident-graph','ct','torch')
    links={name:success(V/f'links/{name}/process.json') for name in targets}
    reports={name:read(V/f'runs/{name}/summary.json') for name in targets}
    for name,row in reports.items():
        success(V/f'runs/{name}/process.json');assert row['status']=='PASS' and row['models']==0
    assert(reports['ct']['tests'],reports['ct']['passed'],reports['ct']['skipped'])==(16,16,0)
    assert(reports['torch']['tests'],reports['torch']['passed'],reports['torch']['skipped'])==(25,25,0)
    ready={name:read(V/f'ready-{name}.json') for name in targets}
    for name,row in ready.items():exact(row['inputs']);assert len(read(row['inputs']['path']))==p['counts']['input_counts'][name]
    op=read(O/'plan.json');of=read(O/'source-freeze.json')
    for key in ('helper','run_helper','run_plan','plan','includes'):exact(of[key])
    changed_attention='tests/graph_route_cuda/attention_test.cc'
    is_attention=lambda path:Path(path).resolve()==R/changed_attention
    for row in read(of['includes']['path']):
        if not is_attention(row['path']):exact(row)
    for pair in of['snapshots']:
        exact(pair['snapshot'])
        if not is_attention(pair['original']['path']):exact(pair['original'])
    af=read(A/'source-freeze.json');ap=read(A/'plan.json')
    for key in ('helper','run_helper','plan','includes','source','snapshot','previous_source','patch'):exact(af[key])
    for row in read(af['includes']['path']):exact(row)
    assert af['previous_source']==next(row['snapshot'] for row in of['snapshots'] if is_attention(row['original']['path']))
    assert not any(is_attention(row['path']) for row in includes),'ON batch should not have depended on changed attention TU'
    assert(op['counts']['CXX'],op['counts']['NVCC'],op['counts']['OFF_SDK'])==(12,0,220)
    ocompiles={name:success(O/f'logs/{name}/process.json') for name in op['units']}
    otargets=('resident-direct','resident-graph','ct','runtime-disabled')
    olinks={name:success(O/f'links/{name}/process.json') for name in otargets}
    correction_compile=success(A/'logs/attention/process.json');correction_link=success(A/'links/ct/process.json')
    odirs={name:A if name=='ct' else O for name in otargets}
    oreports={name:read(odirs[name]/f'runs/{name}/summary.json') for name in otargets}
    oready={name:read(odirs[name]/f'ready-{name}.json') for name in otargets}
    for name,row in oreports.items():
        success(odirs[name]/f'runs/{name}/process.json')
        assert row['status'] in ('PASS','PASS_WITH_SKIPS') and row['models']==0
        exact(oready[name]['inputs']);assert len(read(oready[name]['inputs']['path']))==op['counts']['input_counts'][name]
    assert oreports['ct']['passed']>0 and oreports['ct']['failures']==oreports['ct']['errors']==0
    failed_process=read(O/'runs/ct/process.json');assert failed_process['exit']==1 and failed_process['state']=='TERMINAL'
    xml=ET.parse(O/'runs/ct/results.xml').getroot();failed_cases=[]
    for row in xml.findall('.//testcase'):
        failures=row.findall('failure');skip=row.find('skipped')
        failed_cases.append(dict(suite=row.attrib['classname'],name=row.attrib['name'],
            status='FAIL' if failures else 'SKIP' if skip is not None else 'PASS',
            failures=[dict(message=v.attrib.get('message'),text=v.text) for v in failures]))
    assert(int(xml.attrib['tests']),int(xml.attrib['failures']),int(xml.attrib['errors']))==(16,1,0)
    assert [(row['suite'],row['name']) for row in failed_cases if row['status']=='FAIL']==[
        ('CudaDefaultGraph','MissingBroadBf16AttentionDoesNotChangePrecisionOrMaterializeScores')]
    failed_ct=dict(process=failed_process,tests=16,passed=15,failed=1,cases=failed_cases,
        classification='Test expectation error: legal existing ggml BF16 attention uses F32 Q/K/V/scores/softmax/PV and final BF16 output. Product/math unchanged.',
        test_assertion_owner='root',provider_or_math_changed=False,retained_original=True,successful_other_OFF_arms_not_rerun=True)
    qcompile=success(Q/'logs/attention/process.json');qlink=success(Q/'links/ct/process.json')
    qprocess=read(Q/'runs/ct/process.json');assert qprocess['exit']==1 and qprocess['state']=='TERMINAL'
    qxml=ET.parse(Q/'runs/ct/results.xml').getroot();qcases=[]
    for row in qxml.findall('.//testcase'):
        failures=row.findall('failure');skip=row.find('skipped')
        qcases.append(dict(suite=row.attrib['classname'],name=row.attrib['name'],
            status='FAIL' if failures else 'SKIP' if skip is not None else 'PASS',
            failures=[dict(message=v.attrib.get('message'),text=v.text) for v in failures]))
    assert(int(qxml.attrib['tests']),int(qxml.attrib['failures']),int(qxml.attrib['errors']))==(16,1,0)
    assert [(row['suite'],row['name']) for row in qcases if row['status']=='FAIL']==[
        ('CudaDefaultGraph','BroadBf16AttentionKeepsOriginalF32FallbackWithoutAten')]
    failed_ct2=dict(process=qprocess,tests=16,passed=15,failed=1,cases=qcases,CXX=qcompile,link=qlink,
        classification='Test expectation error: original lowered bridge::record_compatible reports true; the added capture_compatible=false assertion was unproved. Numerical three-seed/large-BF16 checks reported no other failure. Product/math unchanged.',
        test_assertion_owner='root',provider_or_math_changed=False,retained_original=True,successful_other_OFF_arms_not_rerun=True)
    archive={}
    def add(path,name=None):
        path=Path(path);assert path.is_file(),str(path);name=name or path.relative_to(W).as_posix();raw=path.read_bytes()
        assert name not in archive or archive[name]==raw,name
        archive[name]=raw
    def tree(path):
        # Explicit record directories only; exclude binaries, archives, SDK,
        # weights and complete inherited process environments.
        suffixes={'.py','.json','.log','.xml','.cc','.h','.cu','.cmake','.diff','.patch','.txt'}
        for child in sorted(Path(path).rglob('*')):
            if child.is_file() and child.suffix.lower() in suffixes and '__pycache__' not in child.parts and child.name!='environment.json':add(child)
    for name in ('handoff.json','verification-amendment.json','native-codec-owner-amendment.json','off-configure-plan.json','evidence.py'):
        add(W/name)
    add(args.off_review,'off-generated-review.json')
    add(W/'off-generated-review.json','off-generated-review-historical-attempt3.json')
    for name in ('off-generated-review.py','off-generated-review-v4.py','off-configure.py','configure-off.py','configure-off-attempt4.py'):
        if(W/name).is_file():add(W/name)
    for pattern in ('off-generated-review-attempt*.py','off-generated-review-parser-*.json'):
        for path in sorted(W.glob(pattern)):add(path)
    for name in ('build.py','run.py','plan.json','source-freeze.json','frozen-project-includes.json',
                 'base-sdk-inputs.json','retained-stats.json','runtime.json'):
        add(V/name)
    for directory in ('source','recipes','link-recipes','compile','logs','links','runs'):tree(V/directory)
    for name in targets:add(V/f'ready-{name}.json');add(V/f'inputs-{name}.json')
    for name in ('build.py','run.py','plan.json','run-plan.json','source-freeze.json','frozen-project-includes.json',
                 'off-sdk-inputs.json','retained-stats.json','runtime.json'):add(O/name)
    for directory in ('source','recipes','link-recipes','compile','logs','links','runs'):tree(O/directory)
    for name in otargets:add(O/f'ready-{name}.json');add(O/f'inputs-{name}.json')
    for name in ('build.py','run.py','plan.json','source-freeze.json','frozen-project-includes.json','retained-stats.json',
                 'recipe-attention.json','recipe-link.json','runtime.json','attention-oracle.diff','ready-ct.json','inputs-ct.json'):add(A/name)
    for directory in ('source','compile','logs','links','runs'):tree(A/directory)
    for name in ('build.py','run.py','plan.json','source-freeze.json','frozen-project-includes.json','retained-stats.json',
                 'recipe-attention.json','recipe-link.json','runtime.json','attention-oracle.diff','ready-ct.json','inputs-ct.json'):add(Q/name)
    for directory in ('source','compile','logs','links','runs'):tree(Q/directory)
    archive['OFF-original-CT-failure.json']=encoded(failed_ct)
    archive['OFF-attempt2-CT-failure.json']=encoded(failed_ct2)
    tree(W/'before');tree(W/'tooling')
    # Keep every real configure attempt, including missing-source-lock and
    # duplicate-license failures. No compiler-id binaries or entire build tree.
    configure=[]
    for directory in sorted(W.glob('configure*-run')):
        if not(directory/'process.json').is_file():continue
        configure.append(dict(label=directory.name,process=read(directory/'process.json')));tree(directory)
    configure.sort(key=lambda row:row['process']['started'])
    assert any(row['process']['exit']!=0 for row in configure)
    assert any(row['process']['exit']==0 for row in configure),'Final actual OFF configure receipt is missing'
    if 'configure_receipt' in off:
        receipt=off['configure_receipt'];path=Path(receipt['path'])
        assert pin(path)['sha256']==receipt['sha256'];add(path,'off-final-configure-receipt.json')
    # Generated target/flags/exports plus the separate bounded OFF native batch.
    builddir=Path(off['build_directory'])
    for name in ('CMakeCache.txt','compile_commands.json'):
        if(builddir/name).is_file():add(builddir/name,'off-generated/'+name)
    for row in off['metadata_identities']:
        exact(row);path=Path(row['path'])
        if path.is_relative_to(builddir) and path.suffix.lower() in ('.cmake','.json','.txt','.ninja'):
            add(path,'off-generated/'+path.relative_to(builddir).as_posix())
    # Current owned code only. Handoff documents retain the original author's
    # narrow doc hunks, while user dirty documentation/license files stay out.
    handoff=read(W/'handoff.json')
    owned=[row['path'] for row in handoff['owned_paths'] if row['path']=='CMakeLists.txt' or row['path'].split('/')[0] in ('src','include','cmake','scripts','tests')]
    owned.append('cmake/HyleDependencyLock.json')  # historical handoff omitted this root correction
    owned += [row['from'] for row in handoff['moves']];owned=list(dict.fromkeys(owned))
    identities=[]
    for relative in owned:
        path=R/relative
        if path.is_file():add(path,'product/'+relative);identities.append(pin(path))
    archive['owned-code-identities.json']=encoded(dict(present=identities,missing=[s for s in owned if not(R/s).exists()],excluded='Full user documentation/license contents; unrelated current worktree paths.'))
    if args.patch:patch=args.patch.read_bytes()
    else:
        tracked=set(subprocess.check_output(['git','ls-files','-z','--',*owned],cwd=R).decode('utf-8').split('\0'))
        patch=subprocess.check_output(['git','diff','--',*[s for s in owned if s in tracked]],cwd=R)
        for relative in owned:
            if relative in tracked or not(R/relative).is_file():continue
            text=(R/relative).read_text(encoding='utf-8')
            patch+=('diff --git a/'+relative+' b/'+relative+'\nnew file mode 100644\n'+''.join(difflib.unified_diff([],text.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+relative))).encode('utf-8')
    touched=set(re.findall(r'^diff --git a/(\S+) b/\S+$',patch.decode('utf-8'),re.M))
    assert touched and touched<=set(owned),touched-set(owned)
    lockpath='cmake/HyleDependencyLock.json'
    lockblock=next(block for block in patch.decode('utf-8').split('diff --git ') if block.startswith('a/'+lockpath+' b/'+lockpath+'\n'))
    lock_old=[line[1:] for line in lockblock.splitlines() if line.startswith('-') and not line.startswith('---')]
    lock_new=[line[1:] for line in lockblock.splitlines() if line.startswith('+') and not line.startswith('+++')]
    assert len(lock_old)==len(lock_new)==1 and '"tree_sha256"' in lock_old[0] and '"tree_sha256"' in lock_new[0], 'Unexpected broader dependency-lock patch'
    lock_correction=dict(source=pin(R/lockpath),dependency='sglang_activation',old_line=lock_old[0],new_line=lock_new[0],
        scope='Single tree_sha256 lock string matches the existing vendored content. First configure expected/actual mismatch is preserved; no source download or codec CXX change.')
    archive['optional-aten-code-only.diff']=patch
    whitelist=('PATH','INCLUDE','LIB','LIBPATH','VCToolsInstallDir','WindowsSdkDir','WindowsSDKVersion')
    env=read(V/'environment.json');archive['build-environment-relevant.json']=encoded(dict(identity=pin(V/'environment.json'),preserved={k:env[k] for k in whitelist if k in env}))
    oenv=read(O/'environment.json');archive['off-build-environment-relevant.json']=encoded(dict(identity=pin(O/'environment.json'),preserved={k:oenv[k] for k in whitelist if k in oenv}))
    manifest=[dict(name=name,bytes=len(raw),sha256=digest(raw)) for name,raw in sorted(archive.items())]
    manifest_raw=encoded(dict(members=manifest,self_digest='External summary archive.manifest_sha256'));archive['MANIFEST.json']=manifest_raw
    outzip=DEST.with_suffix('.zip');outjson=DEST.with_suffix('.json')
    assert not outzip.exists() and not outjson.exists(),'Do not overwrite prior evidence'
    DEST.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(outzip,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted(archive.items()):z.writestr(name,raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist())==set(archive)
        for name,raw in archive.items():assert digest(z.read(name))==digest(raw),name
    tooling=[dict(label=d.name,process=read(d/'process.json')) for d in sorted((W/'tooling').iterdir()) if d.is_dir() and(d/'process.json').is_file()]
    summary=dict(status='DEFAULT_ON_AND_OFF_FINITE_COMPONENTS_PASSED',
        totals=dict(CXX=dict(actual=30,passed=30),NVCC=dict(actual=1,passed=1),links=10,native_processes=10,
                    native_success=8,native_failed=2,
                    configure_attempts=len(configure),configure_failures=sum(row['process']['exit']!=0 for row in configure)),
        default_ON=dict(CXX=dict(actual=16,passed=16),NVCC=dict(actual=1,passed=1),links=links,
            input_counts=p['counts']['input_counts'],base_SDK=226,new_SDK=227,replaced_original_objects=7,new_native_adapter_objects=1,
            compile_processes=compiles,run_processes={name:row['process'] for name,row in reports.items()},
            resident_direct=reports['resident-direct'],resident_graph=reports['resident-graph'],
            original_GTest_cases=dict(CT=16,Torch=25,total=41),
            GTests={name:dict(passed=reports[name]['passed'],failed=reports[name]['failures'],skipped=reports[name]['skipped'],cases=reports[name]['cases']) for name in ('ct','torch')},
            images={name:row['image'] for name,row in ready.items()},models=0,performance_claim=False),
        OFF=dict(scope='One actual CPU+CUDA HYLE_WITH_ATEN=OFF CMake configuration plus separate bounded actual OFF CXX/link/native consumers.',
            status=off['status'],review_identity=pin(args.off_review),configure_process=off['configure_process'],
            mode=off['mode'],generated_compile_commands=off['compile_commands_count'],generated_exports=off['generated_export_count'],
            ATen_absence={key:off[key] for key in ('aten_implementation_sources','aten_compile_capabilities','aten_sdk_includes','aten_generated_vendor_links','aten_export_sdk_dependencies')},
            native_codec_license_assets=off['native_codec_license_assets'],compiler_facts=off['compiler_facts'],
            observed_host_version_equal=off['observed_host_version_equal'],configure_attempts=configure,
            actual_validation=dict(CXX=dict(actual=14,passed=14,SDK=3,consumers=11),NVCC=0,
                compile_processes=ocompiles,links=olinks,input_counts=op['counts']['input_counts'],SDK_inputs=220,
                removed_original_ON_inputs=op['removed'],recompiled_flag_sensitive_sources=[v['source'] for v in list(op['units'].values())[:3]],
                retained_common_native=op['common_native_retained'],run_processes={name:row['process'] for name,row in oreports.items()},
                resident_direct=oreports['resident-direct'],resident_graph=oreports['resident-graph'],
                GTests=oreports['ct'],thread_runtime_disabled=oreports['runtime-disabled'],
                original_CT_failure=failed_ct,second_CT_failure=failed_ct2,attention_oracle_refinement=dict(CXX=correction_compile,link=correction_link,
                    source=af['source'],previous_source=af['previous_source'],patch=af['patch'],
                    ON_attention_dependency=False,product_CXX_changed=False,
                    scope='Each correction rebuilt only one attention test TU and its CT image. Other three OFF successful native workflows preserved. Final test retains original actual capture compatibility without asserting false.'),
                images={name:row['image'] for name,row in oready.items()},runtime=read(O/'runtime.json'),
                consumer_recipe_boundary='Tests were disabled in the real OFF configure. Nine consumers explicitly adapt actual OFF native/Graph compiler flags; only six GTest sources add original GTest includes.',
                OFF_CXX_or_native_validation_claim=True)),
        post_ON_metadata_amendment=dict(receipt=pin(W/'verification-amendment.json'),original_handoff=p['handoff'],
            current_handoff=pin(W/'handoff.json'),original_handoff_bytes_retained=False,
            source_and_header_pins_verified=148,source_snapshots_verified=len(f['snapshots']),
            meaning='License registry duplication fixed in CMake metadata after ON validation; original plan/freeze pin stays historical. No CXX source/header change, rebuild or successful-native rerun.'),
        final_native_codec_owner=dict(amendment=pin(W/'native-codec-owner-amendment.json'),
            meaning='After the historical foundation ownership correction, the codec registry was moved to its sole actual consumer compute_provider_cuda. Final same-cache fourth configure/generated review verifies this CMake-only change; prior CXX/native results are not rerun.'),
        dependency_lock_correction=lock_correction,
        tooling=tooling,limits=['DefaultON and OFF use distinct binaries/feature flags and finite component batches; neither is a whole SDK rebuild/install-consumer validation.',
            'Two resident workflows plus41 original GTests, not43 interchangeable test cases. Graph resident uses Commands; originalCT cases cover capture.',
            'OFF has two resident workflows, the actual CT5+attention XML cases and one CPU --disabled process; ON optional decoder/TF32/allocator coverage is not claimed for OFF.',
            'Both initial OFF CT failures are preserved as15PASS/1FAIL. Final corrected CT numerical oracle is a distinct one-test-TU image; not all OFF workflows rerun on that image.',
            'No full-model inference, throughput, trained quality or new-platform runtime claim.',
            'Old handoff JSON bytes were not saved by its author; the original historical identity remains in recipes/plan/freeze and the amendment states that limit.',
            'Source/kernel snapshots, exact17recipes/actualdeps and unchanged148project pins preserve ON compiler inputs despite metadata handoff update.'],
        archive=dict(**pin(outzip),members=len(archive),manifest_sha256=digest(manifest_raw),CRC='PASS',all_member_SHA256='PASS'))
    with outjson.open('xb') as f:f.write(encoded(summary))
    with(W/'evidence-readback.json').open('xb') as f:f.write(encoded(dict(JSON=pin(outjson),ZIP=pin(outzip),members=len(archive),CRC='PASS',SHA256='PASS')))
    print(json.dumps(dict(JSON=pin(outjson),ZIP=pin(outzip),members=len(archive)),ensure_ascii=False))


if __name__=='__main__':main()
