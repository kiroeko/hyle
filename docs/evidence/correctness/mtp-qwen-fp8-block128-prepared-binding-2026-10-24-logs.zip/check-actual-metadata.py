from pathlib import Path
import json,sys,hashlib,subprocess
R=Path.cwd();sys.path.insert(0,str(R));from engine.models.qwen35 import prepare as p
W=R/'.scratch/mtp-q27-fp8-20261024';plan=json.loads((W/'cat06-text-mtp-range-plan.json').read_text());cfg=json.loads((R/'.scratch/model-quantization-discovery-2026-10-19/qwen-kimi/Qwen--Qwen3.8-27B-FP8/config.json').read_text())
original=dict(complete=True,repository=plan['repository'],revision=plan['revision'],roles=[dict(name=x['name'],dtype=x['dtype'],shape=x['shape'],bytes=x['bytes'],offset=x['closed_inclusive_range'][0],path='NOT_DOWNLOADED_'+x['file'],sha256='0'*64) for x in plan['selected_roles']])
# Deliberately metadata-only: no body identity or body-readiness claim.
lines,receipt=p._prepare_role_records(original,True,cfg,lambda r:(Path(r['path']),None),p.FP8_READER)
manifest=W/'cat06-actual-metadata-only.tsv';manifest.write_text('\n'.join(lines)+'\n')
result=dict(scope='All actual fixed original role metadata; payload authentication deliberately stubbed, not a usable prepared bank or body identity',original_plan_sha256=hashlib.sha256((W/'cat06-text-mtp-range-plan.json').read_bytes()).hexdigest(),physical_roles=receipt['physical_roles'],selected_weight_bytes=receipt['selected_weight_bytes'],text_weight_bytes=receipt['text_weight_bytes'],mtp_weight_bytes=receipt['mtp_weight_bytes'],groups=receipt['fp8_block128_groups'],policy=receipt['fp8_block128_policy'])
assert (result['physical_roles'],result['selected_weight_bytes'],result['groups'])==(1273,29945203072,407)
(W/'cat06-actual-metadata-only.json').write_text(json.dumps(result,indent=2)+'\n')
r=subprocess.run([str(W/'metadata/checks.exe'),str(W/'metadata/actual-fixtures'),str(manifest)],capture_output=True,text=True);(W/'metadata/actual-stdout.log').write_text(r.stdout);(W/'metadata/actual-stderr.log').write_text(r.stderr);print(r.stdout,r.stderr);r.check_returncode();print(result)
