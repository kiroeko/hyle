from pathlib import Path
import json,sys,hashlib,struct
R=Path.cwd();sys.path.insert(0,str(R));from engine.models.qwen35 import prepare as p
W=R/'.scratch/mtp-q27-fp8-20261024/loader';W.mkdir(exist_ok=True)
spec=__import__('importlib.util',fromlist=['']).spec_from_file_location('fixture',R/'tests/tooling/qwen_hf_roles_test.py');m=__import__('importlib.util',fromlist=['']).module_from_spec(spec);spec.loader.exec_module(m)
cfg=m.source_config();t=cfg['text_config'];t.update(hidden_size=128,intermediate_size=128,vocab_size=256,num_attention_heads=1,num_key_value_heads=1,linear_num_key_heads=1,linear_num_value_heads=1,num_hidden_layers=1,layer_types=['full_attention'])
cfg['quantization_config']=dict(quant_method='fp8',fmt='e4m3',activation_scheme='dynamic',weight_block_size=[128,128])
g=p.geometry.from_hf(cfg);rows=[];body=bytearray();filename=W/'source.bin'
for name,shape in p.geometry.role_shapes(g).items():
 fp8=name in ['model.language_model.layers.0.mlp.gate_proj.weight','mtp.layers.0.self_attn.k_proj.weight'];dtype='F8_E4M3' if fp8 else 'BF16';count=p.ROLE_SIZES[dtype]
 for d in shape:count*=d
 raw=bytes([0x38])*count if fp8 else bytes(count)
 rows.append(dict(name=name,dtype=dtype,shape=list(shape),bytes=count,path=str(filename),offset=len(body),sha256=hashlib.sha256(raw).hexdigest()));body.extend(raw)
 if fp8:
  n,k=shape;sfshape=[(n+127)//128,k//128];raw=struct.pack('<H',0x3f80)*(sfshape[0]*sfshape[1]);rows.append(dict(name=name[:-7]+'.weight_scale_inv',dtype='BF16',shape=sfshape,bytes=len(raw),path=str(filename),offset=len(body),sha256=hashlib.sha256(raw).hexdigest()));body.extend(raw)
filename.write_bytes(body);original=dict(complete=True,repository='synthetic/loader-lifetime-only',revision='a'*40,roles=rows)
lines,receipt=p._prepare_role_records(original,True,cfg,p.verify_role_source,p.FP8_READER);(W/'weights.tsv').write_text('\n'.join(lines)+'\n');(W/'fixture.json').write_text(json.dumps(receipt,indent=2)+'\n');print('synthetic loader roles/bytes',len(rows),len(body))
source=r'''#include "engine/models/qwen35/main.cc"
int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("manifest required");const auto geometry=qwen35::read_weight_geometry(argv[1]);auto backend=qwen35::take(qwen35::Backend::create());for(bool mtp:{false,true}){std::map<std::string,qwen35::Tensor>bank;std::vector<hyle::compute::LeasePool>pools;const auto roles=qwen35::prepared::read_roles(argv[1],mtp);const auto report=qwen35::load_weight_bank(argv[1],backend,bank,pools,geometry,mtp?qwen35::WeightSelection::kTextAndMtp:qwen35::WeightSelection::kText);const auto groups=mtp?2U:1U;if(report.bytes!=roles.bytes||report.physical_text_roles+report.physical_mtp_roles!=roles.selected.size()||report.fp8_groups!=groups||bank.size()+groups!=roles.selected.size()||!report.float8_policy)throw std::runtime_error("physical/canonical inventory differs");for(const auto&role:roles.selected)if(role.projection_codec==qwen35::prepared::ProjectionCodec::kFloat8Block128){const auto&weight=bank.at(role.name);if(weight.description.storage_format().is_plain()||!weight.ready)throw std::runtime_error("canonical projection not retained ready");if(bank.contains(role.name.substr(0,role.name.size()-7)+".weight_scale_inv"))throw std::runtime_error("original SF remained in weight bank");}std::cout<<"PASS loader mtp="<<mtp<<" original_roles="<<roles.selected.size()<<" canonical_tensors="<<bank.size()<<" original_bytes="<<report.bytes<<" canonical_bytes="<<report.canonical_bytes<<" groups="<<groups<<" bounded_group_bytes="<<report.import_peak_bytes<<'\n';}return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
'''
(W/'probe.cc').write_text(source)
