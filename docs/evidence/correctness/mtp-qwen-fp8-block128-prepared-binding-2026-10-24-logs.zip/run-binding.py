from pathlib import Path
import importlib.util,os,sys
R=Path.cwd();W=R/'.scratch/mtp-q27-fp8-20261024';backend=sys.argv[1];F=W/('binding-'+backend+'3')
spec=importlib.util.spec_from_file_location('buildhelper',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ready=b.read(F/'ready.json');b.require(ready['image'])
b.execute([ready['image']['path'],str(R/'.scratch/mtp-metadata-offline-20261024/components')],dict(os.environ,PATH=ready['PATH']),F/'run',120)
print((F/'run/stdout.log').read_text(),flush=True)
