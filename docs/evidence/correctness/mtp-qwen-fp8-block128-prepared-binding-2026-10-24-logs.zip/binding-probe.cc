#include "engine/models/qwen35/main.cc"
#include "tests/tools/qwen_geometry_fixture.h"
#include "tests/compute_models/nvfp4_reference_fixture.h"

namespace {
namespace q=qwen35;
namespace s=nvfp4_reference_test;
namespace c=hyle::compute;
namespace g=hyle::graph;
using Type=c::DataType;
std::vector<std::byte> bytes(const std::filesystem::path&p) {
 std::ifstream f(p,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("missing source");
 std::vector<std::byte>b(static_cast<std::size_t>(f.tellg()));f.seekg(0);
 if(!f.read(reinterpret_cast<char*>(b.data()),static_cast<std::streamsize>(b.size())))throw std::runtime_error("short source");return b;
}
std::uint16_t word(std::span<const std::byte>b,std::size_t i){return std::uint16_t(std::to_integer<unsigned>(b[i]))|std::uint16_t(std::to_integer<unsigned>(b[i+1])<<8);}
float mul(float a,float b){return s::f32(double(a)*double(b));}
float divide(float a,float b){return s::f32(double(a)/double(b));}
float decode(std::byte x){return s::e4m3(std::to_integer<std::uint8_t>(x));}
float scale(float a){return divide((std::max)(std::fabs(a),q::prepared::Float8BlockPolicy::floor),448.F);}
float quantized(float a){const auto normalized=divide(a,scale(a));return std::copysign(s::e4m3(s::encode_scale(std::fabs(normalized))),a);}
float expected(float a,float w,float sf){return s::rounded_bf16(mul(mul(mul(quantized(a),w),scale(a)),sf));}
float early(float a,float w,float sf){return s::rounded_bf16(mul(mul(quantized(a),scale(a)),s::rounded_bf16(mul(w,sf))));}
void one(const std::filesystem::path&root,const char*name,std::int64_t k) {
 const auto cb=bytes(root/name/"codes.bin"),sb=bytes(root/name/"scales.bin");
 if(cb.size()!=std::size_t(3*k)||sb.size()!=std::size_t(2*(k/128)))throw std::runtime_error("slice geometry mismatch");
 q::prepared::Role w{"mtp.layers.0.self_attn.k_proj.weight","F8_E4M3",{3,k},root/name/"codes.bin",0,cb.size()};
 w.projection_codec=q::prepared::ProjectionCodec::kFloat8Block128;w.projection_group_size=128;
 q::prepared::Role sf{"mtp.layers.0.self_attn.k_proj.weight_scale_inv","BF16",{1,k/128},root/name/"scales.bin",0,sb.size()};
 // Exercise precisely the cold original-role importer used by load_weight_bank.
 auto imported=q::take(q::import_float8_block128_roles(w,sf));
 std::vector<std::byte>canonical(imported.storage.size());q::check(imported.storage.view().read(canonical));
 if(!std::equal(cb.begin(),cb.end(),canonical.begin()))throw std::runtime_error("codes changed");
 for(std::size_t i=0;i<sb.size()/2;++i){std::uint32_t bits;std::memcpy(&bits,canonical.data()+cb.size()+4*i,4);if(bits!=std::uint32_t(word(sb,2*i))<<16)throw std::runtime_error("scale widening changed bits");}
 std::size_t product_witness=0;std::int64_t witness=0;float amplitude=1.0078125F;bool found=false;
 for(std::int64_t i=0;i<k;++i)for(std::int64_t n=0;n<3;++n){
  float ww=decode(cb[std::size_t(n*k+i)]),ss=s::wide(word(sb,std::size_t(i/128*2)));
  if(mul(ww,ss)!=s::rounded_bf16(mul(ww,ss)))++product_witness;
  for(float a:{1.0078125F,1.375F,3.25F,-2.75F,17.125F})if(!found&&expected(a,ww,ss)!=early(a,ww,ss)){witness=i;amplitude=a;found=true;}
 }
 if(!product_witness)throw std::runtime_error("no original nonBF16 weight product witness");
 auto backend=q::take(q::Backend::create());
 std::map<std::string,q::Tensor>bank;
 q::Tensor t; t.description=imported.description;t.projection_codec=w.projection_codec;t.projection_group_size=128;
 if(backend.device()==hyle::mem::system_resource())t.buffer=std::move(imported.storage);
 else {t.buffer=q::take(hyle::mem::Buffer::create(backend.device(),canonical.size(),256));q::check(backend.write(t.buffer.view(),canonical));}
 t.freeze(backend);bank.emplace(w.name,std::move(t));
 auto geometry=qwen_test::q35();q::Recipe r(bank,backend,geometry,3);
 const auto ad=q::dense(Type::kBFloat16,{3,k});const auto a=r.input(ad);
 const auto y=r.linear_absolute(a,w.name);q::check(r.builder.publish(y));
 auto graph=q::take(std::move(r.builder).finish());auto yd=q::take(graph.value_description(y));
 const std::array binding{g::ShapeBinding{r.last_row,2}}; const std::array variants{g::ExactShapeVariant{binding}};
 auto program=q::take(backend.compile(graph,r.constants,r.options({.shape_policy=g::CompileShapePolicy::kFiniteExact,.exact_variants=variants})));
 program.executable=q::take(program.executable.exact_variant(0)); auto slot=q::take(program.executable.create_invocation({.resources=g::ResourceOptions{}}));
 std::array<std::int64_t,3>pos{witness,129,k-1};std::array<float,3>amp{amplitude,-224.F,0.F};
 std::vector<std::uint16_t>ab(std::size_t(3*k),0);
 for(std::size_t i=0;i<3;++i)ab[i*std::size_t(k)+std::size_t(pos[i])]=s::bf16(amp[i]);
 q::Tensor input(backend.device(),ad);input.write(std::span<const std::uint16_t>(ab));input.freeze(backend);
 q::check(slot.bind(a,ad,input.ready));
 auto pool=q::take(c::LeasePool::create(backend.device(),q::take(yd.required_bytes()),{.max_blocks=1,.backing_alignment=256}));
 q::check(slot.bind(y,yd,q::take(pool.allocate(q::take(yd.required_bytes()),256))));
 auto queues=backend.queue_bindings();q::check(slot.prepare_replay(queues,{.mode=g::ReplayMode::kCommands,.host_wait=g::HostWaitPolicy::kAllow}));
 auto work=q::take(slot.submit(queues));q::check(work.wait());auto actual=q::take(slot.output(y));
 std::vector<std::byte>yb(q::take(yd.required_bytes()));q::check(actual.storage().read(yb));
 std::size_t output_witness=0;
 for(std::size_t row=0;row<3;++row)for(std::size_t n=0;n<3;++n){
  const auto ww=decode(cb[n*std::size_t(k)+std::size_t(pos[row])]);const auto ss=s::wide(word(sb,std::size_t(pos[row]/128*2)));
  const auto want=expected(amp[row],ww,ss),got=s::wide(word(yb,(row*3+n)*2));
  if(got!=want)throw std::runtime_error("Recipe/oracle difference row="+std::to_string(row)+" n="+std::to_string(n)+" got="+std::to_string(got)+" expected="+std::to_string(want));
  output_witness+=want!=early(amp[row],ww,ss);
 }
 if(found&&!output_witness)throw std::runtime_error("selected product rounding witness not preserved");
 std::cout<<"PASS source="<<name<<" backend="<<q::Backend::name()<<" code_bytes="<<cb.size()<<" original_BF16_SF_bytes="<<sb.size()<<" canonical_bytes="<<canonical.size()<<" outputs=9 policy=divide floor_f32_bits=2edbe6ff output=BF16 original_product_witnesses="<<product_witness<<" final_output_rounding_witnesses="<<output_witness<<"\n";
}
}
int main(int argc,char**argv){try{if(argc!=2)throw std::runtime_error("source root required");one(argv[1],"q27-fp8-bf16-sf",5120);one(argv[1],"q24-fp8-bf16-sf",2048);return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
