from pathlib import Path
import importlib.util,json,os,sys,shutil
R=Path.cwd();W=R/'.scratch/mtp-q27-fp8-20261024';backend=sys.argv[1];F=W/('binding-'+backend+'3');F.mkdir(exist_ok=False);source=F/'source'
for p in sorted([* (R/'engine/models/qwen35').glob('*.h'),R/'engine/models/qwen35/main.cc',*(R/'engine/inference').glob('*.h'),R/'tests/tools/qwen_geometry_fixture.h',R/'tests/compute_models/nvfp4_reference_fixture.h']):
 dest=source/p.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
shutil.copyfile(W/'binding-probe.cc',source/'probe.cc')
spec=importlib.util.spec_from_file_location('buildhelper',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
E=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check'
if backend=='cpu':
 original=R/'.scratch/qwen-multi-draft-20261024/geometry-cpu-check2';recipe=b.read(original/'compile-command.json');link=b.read(original/'link-command.json')
else:
 original=R/'.scratch/qwen-multi-draft-20261024/geometry-cuda-current1';recipe=b.read(original/'compile-command.json');link=b.read(original/'link-command.json')
command=[];skip=False
for a in recipe:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a.startswith(('/Fo','/Fd'))or a.lower().endswith('.cc'):continue
 command.append(a)
command += ['/I'+str(source),str(source/'probe.cc'),'/sourceDependencies',str(F/'dependencies.json'),'/Fo'+str(F/'probe.obj'),'/Fd'+str(F/'probe.pdb')]
# Source-relative includes must select this immutable source snapshot first.
command.remove('/I'+str(source));command.insert(1,'/I'+str(source))
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':recipe[0],'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
b.save(F/'sources.json',[b.identity(p)for p in source.rglob('*')if p.is_file()])
b.execute(command,env,F/'compile',240)
link=[a for a in link if not a.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:')) and a!=str(original/'test.obj')]
link += [str(F/'probe.obj'),'/OUT:'+str(F/'probe.exe')]
b.save(F/'link-plan.json',dict(command=link,retained_closure=str(original),fresh_TUs=1,SDK_builds=0,HTTP=0))
b.execute(link,env,F/'link',120)
ready=b.read(E/('ready-'+backend+'.json'));runtime=Path(ready['native_runtime']['path']);os.link(runtime,F/runtime.name)
b.save(F/'ready.json',dict(image=b.identity(F/'probe.exe'),PATH=str(F)+os.pathsep+ready['PATH'],native_runtime=b.identity(F/runtime.name)))
print('READY',backend,flush=True)
