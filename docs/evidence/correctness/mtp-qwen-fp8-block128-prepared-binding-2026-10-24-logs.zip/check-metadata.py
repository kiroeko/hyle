from pathlib import Path
import importlib.util,json,sys,os
R=Path.cwd();W=R/'.scratch/mtp-q27-fp8-20261024';W.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('buildhelper',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
recipe=b.read(R/'.scratch/mtp-full-quant-20261024/prepared-roles-final/compile/command.json')['command']
env=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':recipe[0],'CMAKE_CXX_COMPILER':recipe[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
folder=W/'metadata';folder.mkdir(exist_ok=True)
command=[]
for a in recipe:
 if a.startswith(('/Fe:','/Fo:','/Fd:')):continue
 command.append(a)
command[command.index('/link'):command.index('/link')]=['/Fe:'+str(folder/'checks.exe'),'/Fo:'+str(folder/'checks.obj'),'/Fd:'+str(folder/'checks.pdb')]
b.execute(command,env,folder/'compile',120)
b.execute([str(folder/'checks.exe'),str(folder/'fixtures')],env,folder/'run',30)
print((folder/'run/stdout.log').read_text())
