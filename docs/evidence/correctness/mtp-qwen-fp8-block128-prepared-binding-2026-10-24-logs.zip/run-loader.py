from pathlib import Path
import importlib.util,os
R=Path.cwd();W=R/'.scratch/mtp-q27-fp8-20261024';F=W/'loader-build'
spec=importlib.util.spec_from_file_location('buildhelper',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b);ready=b.read(F/'ready.json')
b.execute([ready['image']['path'],str(W/'loader/weights.tsv')],dict(os.environ,PATH=ready['PATH']),F/'run',60)
print((F/'run/stdout.log').read_text())
