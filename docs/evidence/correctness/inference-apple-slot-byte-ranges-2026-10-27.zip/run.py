from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

W = Path('/Users/kiro/hyle-scratch/compute-unified/inference-native-slot-byte-ranges-20261027')


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def pin(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


def execute(tag, command, timeout):
    target = W / tag
    target.mkdir(exist_ok=False)
    plan = read(W / 'plan.json')
    environment = os.environ.copy()
    environment.update(plan['environment'])
    save(target / 'command.json', dict(command=command, cwd=str(W), environment=plan['environment']))
    started = time.perf_counter()
    with (target / 'stdout.log').open('wb') as stdout, (target / 'stderr.log').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=W, env=environment, stdout=stdout, stderr=stderr)
        save(target / 'running.json', dict(pid=process.pid))
        timed_out = False
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.kill()
            code = process.wait(timeout=5)
    result = dict(pid=process.pid, exit=code, seconds=time.perf_counter() - started, timeout=timed_out)
    save(target / 'process.json', result)
    print(tag, json.dumps(result), flush=True)
    if code or timed_out:
        raise RuntimeError(tag + ' failed; no automatic retry')
    return result


def build():
    plan = read(W / 'plan.json')
    baseline = Path(plan['baseline_remote'])
    assert pin(baseline / 'source-freeze4.json')['sha256'] == plan['baseline_source_freeze_sha256']
    assert pin(baseline / 'plan4.json')['sha256'] == plan['baseline_plan_sha256']
    frozen = {str((baseline / 'source' / row['path']).resolve()): row
              for row in read(baseline / 'source-freeze4.json')}
    frozen.update({str((W / 'source' / row['path']).resolve()): row
                   for row in read(W / 'source-freeze.json')})
    for row in read(W / 'source-freeze.json'):
        assert pin(W / 'source' / row['path'])['sha256'] == row['sha256'], row['path']
    inherited = []
    for row in read(W / 'reused-expected.json'):
        actual = pin(Path(row['path']))
        assert actual == row, row['path']
        inherited.append(actual)
    save(W / 'reused-inputs.json', inherited)
    save(W / 'hardware.json', dict(
        uname=subprocess.check_output(['uname', '-a'], text=True),
        model=subprocess.check_output(['sysctl', '-n', 'hw.model'], text=True),
        clang=subprocess.check_output(['/usr/bin/c++', '--version'], text=True),
        os=subprocess.check_output(['sw_vers'], text=True)))
    results = []
    for job in plan['jobs']:
        result = execute(job['tag'], job['command'], job['timeout'])
        results.append(dict(tag=job['tag'], process=result))
        if '-c' not in job['command']:
            continue
        dependency_file = Path(job['command'][job['command'].index('-MF') + 1])
        raw = dependency_file.read_text()
        save(W / job['tag'] / 'dependencies.json', dict(makefile=raw))
        used = []
        for original in re.split(r'\s+', raw.replace('\\\n', ' ').split(': ', 1)[1].strip()):
            name = str(Path(original).resolve())
            if name in frozen:
                actual = pin(Path(name))
                assert actual['sha256'] == frozen[name]['sha256'], name
                used.append(actual)
            elif '/source/include/hyle/' in name or '/source/src/' in name or '/source/tests/' in name:
                raise RuntimeError('unfrozen project dependency: ' + name)
        save(W / job['tag'] / 'actual-project-dependencies.json', used)
    image = pin(W / 'slot-byte-ranges-test')
    mapping = (W / 'image.map').read_text().split('# Object files:', 1)[1].split('# Sections:', 1)[0]
    for name in ('copy.o', 'store.o', 'test.o'):
        assert str(W / name) in mapping, name
    assert 'apple_copy_recording.mm.o)' not in mapping, 'old private CopyRecording object extracted'
    assert str(baseline / 'store.o') not in mapping
    assert str(baseline / 'test.o') not in mapping
    save(W / 'linked-object-map.json', dict(raw=mapping, current_objects=[pin(W / (name + '.o'))
        for name in ('copy', 'store', 'test')], no_duplicate_ignore=True, no_whole_archive=True))
    save(W / 'ready.json', dict(image=image, processes=results, compiled_TUs=3, SDK_builds=0))


def run():
    image = read(W / 'ready.json')['image']
    assert pin(Path(image['path'])) == image
    result = execute('run1', [image['path'], '--gtest_filter=AppleSlotStore.*',
        '--gtest_output=xml:' + str(W / 'results.xml')], 60)
    xml = ET.parse(W / 'results.xml').getroot()
    assert int(xml.attrib['tests']) == 5 and int(xml.attrib['failures']) == 0 and int(xml.attrib['errors']) == 0
    save(W / 'summary.json', dict(status='PASS', process=result, tests=5,
        testcases=[item.attrib['name'] for item in xml.iter('testcase')],
        scope=read(W / 'plan.json')['scope'], performance_claim=False, model_runs=0,
        native_gpu_fault_injection=False, HTTP=0))


if sys.argv[1:] == ['build']:
    build()
elif sys.argv[1:] == ['run']:
    run()
else:
    print('Explicit build or run only; no implicit retries.')
