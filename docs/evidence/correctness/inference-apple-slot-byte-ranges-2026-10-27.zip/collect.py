from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

W = Path('/Users/kiro/hyle-scratch/compute-unified/inference-native-slot-byte-ranges-20261027')


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def pin(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest.hexdigest())


plan = read(W / 'plan3.json')
baseline = Path(plan['baseline_remote'])
ready = read(W / 'ready.json')
assert pin(Path(ready['image']['path'])) == ready['image']
xml = ET.parse(W / 'results.xml').getroot()
assert int(xml.attrib['tests']) == 5 and int(xml.attrib['failures']) == 0 and int(xml.attrib['errors']) == 0
identity = read(baseline / 'runtime-identity.json')
for row in identity['actual_files']:
    assert pin(Path(row['path'])) == row, row['path']
identity['inherited_actual_files_rechecked'] = True
identity['libraries'] = subprocess.check_output(['otool', '-L', ready['image']['path']], text=True)
save(W / 'runtime-identity.json', identity)
legacy = Path('/Users/kiro/hyle-scratch/compute-unified/apple-memory-lifetime-20261024/attempt1/source/src/compute_route_apple/apple_memory.mm')
old = legacy.read_text().splitlines()
assert 'buffer.storageMode != MTLStorageModeShared' in old[586]
save(W / 'legacy-shared-gate.json', dict(actual_cached_source=pin(legacy),
    lines='554-590', original_gate_lines='587-589',
    excerpt='\n'.join(f'{i+1}: {old[i]}' for i in range(553, 590)),
    conclusion='The existing single-destination path already called storage_info before accessing contents. Its nonempty native source was already required to be shared; the extracted resolver does not introduce a new storage-mode restriction. Empty nil backing still returns zero-byte storage and the resolver does not dereference it.'))
processes = {name: read(W / name / 'process.json') for name in
    ('compile-copy', 'compile2-copy', 'compile3-copy', 'compile-store', 'compile-test', 'link', 'run1')}
facts = dict(status='PASS', hardware=read(W / 'hardware.json'), processes=processes,
    compilation=dict(distinct_TUs=3, compiler_attempts=5, successful_compiler_processes=3,
        failed_compiler_processes=2, failures_are_validation_recipe_only=True),
    links=1, images=1, consumer_processes=1, tests=5,
    testcases=[item.attrib['name'] for item in xml.iter('testcase')],
    scope=plan['scope'], image=ready['image'],
    checked_contracts=[
        'Original dense/padded generated Gather-to-Store F32/F16/BF16 bytes and retirement/reset contracts remain passing.',
        'Generated BF16 one-element (2B) and three-element (6B) rows preserve exact bits, source/unused slots and separately authorized padding.',
        'Concrete aligned ranges record exactly two original native blit calls.',
        'Concrete 2B source/destination-offset ranges record zero native blit calls and copy exact bytes without modifying surrounding bytes.',
        'A final source range exceeding logical bytes is rejected before admission and leaves all destination bytes unchanged.'
    ], limitations=[
        'One Mac16,12 with the pinned original MLX/Metal runtime only; no claim for every Apple GPU or memory storage mode.',
        'No native GPU fault injection. The invalid-tail case is pre-submit descriptor/range rejection.',
        'All-ranges-before-write covers source success, descriptor/permission/range/alias checks; no transactional rollback is claimed after a transfer flush error or mid-copy cancellation.',
        'No model inference, quality assessment, performance benchmark, new SDK/MLX build or HTTP download.'
    ], failures=[
        dict(stage='compile-copy', reason='The previous 8-TU source snapshot did not include the existing completion_internal.h needed by this newly compiled .mm. No product parsing occurred.'),
        dict(stage='compile2-copy', reason='The supplied private header was not yet reachable because the new overlay src/compute directory was missing from the include path. Recipe-only correction; product source hashes unchanged.')
    ], HTTP=0, model_runs=0, SDK_builds=0, MLX_builds=0, performance_claim=False,
    native_gpu_fault_injection=False, inherited_link_inputs=114,
    source_freeze=read(W / 'source-freeze.json'), added_existing_private_header=read(W / 'source-freeze2.json')[-1],
    reused_input_verification='All 114 actual object/library hashes exactly match the prior native-slot-store evidence; no cached SDK/source payload is copied into this archive.')
save(W / 'receipt.json', facts)
names = ['plan.json', 'plan2.json', 'plan3.json', 'run.py', 'run2.py', 'run3.py', 'collect.py',
    'source-freeze.json', 'source-freeze2.json', 'reused-expected.json', 'hardware.json',
    'ready.json', 'results.xml', 'summary.json', 'runtime-identity.json',
    'legacy-shared-gate.json', 'linked-object-map.json', 'receipt.json']
names += ['source/' + row['path'] for row in read(W / 'source-freeze2.json')]
for name in processes:
    names += [path.relative_to(W).as_posix() for path in (W / name).iterdir() if path.is_file()]
with zipfile.ZipFile(W / 'records.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for name in names:
        archive.write(W / name, name)
print(json.dumps(dict(status='PASS', tests=5, archive=pin(W / 'records.zip'), image=ready['image'])))
