"""Publish the actual state composition, original roles, failure and correction."""
from pathlib import Path
import hashlib
import json
import zipfile
S = Path(__file__).resolve().parent
R = S.parents[1]
OUT = R / 'docs/evidence/correctness/mtp-target-state-2026-10-22.json'
ZIP = OUT.with_suffix('.logs.zip')
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def ident(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert not OUT.exists() and not ZIP.exists()
checks = read(S / 'checks5/summary.json')
assert checks['tests'] == 10 and checks['process']['exit'] == 0 and not checks['process']['timed_out']
assert not any(checks[k] for k in ('failures', 'errors', 'disabled', 'skips'))
assert sum(int(x['properties']['actual_submissions']) for x in checks['cases']) == 130
assert ident(checks['image']['path'])['sha256'] == checks['image']['sha256']
failed = read(S / 'checks4/summary.json')
assert failed['tests'] == 2 and failed['failures'] == 1 and failed['process']['exit'] == 1
assert failed['image']['sha256'] == checks['image']['sha256']
roles = read(S / 'original-dspark-target/acquisition.json')
assert roles['complete'] and roles['payload_bytes'] == 55_724_032 and len(roles['roles']) == 4
for item in roles['roles']:
    assert item['status'] == 'ACQUIRED_EXACT_ROLE' and item['http_status'] == 206
    assert item['etag'] == roles['expected_etag']
    assert ident(item['payload']['path'])['sha256'] == item['payload']['sha256']
changes = [
    'tests/compute_models/glm_mtp_state_consumer_test.cc',
    'tests/compute_models/glm_mtp_target_component.h',
    'tests/compute_models/d5_kda_full_fragments.h',
    'tests/compute_models/d5_moe_semantic_fragments.h',
    'tests/compute_models/dspark_target_binding.h',
    'tests/compute_models/dspark_target_binding_test.cc',
    'tests/graph_route_cpu/CMakeLists.txt',
    'tests/graph_route_cuda/CMakeLists.txt',
    'docs/developer/current-work.md',
    'docs/implementation/model-operators.md',
]
for name in changes:
    target = S / 'source-current' / name; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((R / name).read_bytes())
assert ident(R / changes[0])['sha256'] == read(S / 'target-source/freeze.json')['state_source']['sha256']
runtime = read(S / 'tests-link5/runtime-environment.json')
native = read(S / 'native-cpu-hc/ready.json')
assert any(x['sha256'] == native['image']['sha256'] for x in runtime['staged_dlls'])
assert ident(native['image']['path'])['sha256'] == native['image']['sha256']
doc = read(S / 'docs-update.json')
text = (R / 'docs/developer/current-work.md').read_text(encoding='utf-8')
perf = text[text.index('## 最新完整性能对比'):].encode('utf-8')
assert hashlib.sha256(perf).hexdigest() == doc['performance_utf8_sha256']
report = dict(date='2026-10-22', status='GLM_TARGET_NEXTN_COMPOSITION_AND_DSPARK_ORIGINAL_ROLES_PASS',
    goal_complete=False, checks=checks, actual_Graph_submissions=130, changes=[ident(R / p) for p in changes],
    predecessor=ident(R / 'docs/evidence/correctness/glm-mtp-state-2026-10-22.json'),
    GLM=dict(
        schema='16 native NextN/indexer resources including nx[2,4096] journal and I32 lag count,24-byte epoch policy, plus4 target resources: raw QKV history,KDA matrix,finalnorm tap,I32 cursor. One StateStore/Schema/Head/Draft.',
        catchup='Source-qualified whole-indexer skip retains actual raw rings/pools/cursors/full2051 I32 seed including its old tail. MLA/hidden advance and actual nx is journalled. Prefix1/2 selects the whole version. Between epochs only accepted lagged nx is projected/pool-written; rejected B is refused before prepare.',
        target='Actual generated final layer44 of45: attention mHC collapse->norm->full KDA/raw conv->mHC post->separate FFN mHC collapse/norm/MoE/post->4-stream mean->target final norm. The actual previous target tap is bound into fresh NextN hnorm/EH with next-token embedding; same-token new target tap is not prematurely consumed.',
        selection='Target verifies current pending while draft uses appropriate previous target/draft hidden. Actual target and draft results enter one StateDraft before publication. Partial/all accepted branches, rejected tail, correction token, next epoch fresh, old versions, stale CAS/cancel and independent base recomputation/direct-nx catchup passed.',
        executions_per_backend=dict(single_epoch=7, cross_epoch=14, target_plus_NextN=26,
            target_submissions_within_combination=12),
        budgets='NextN output pools default5 generations; target10 generations; combined StateStore512MiB actual root-capacity accounting, observed retained backing127777004B. This is state-budget accounting, not physical process/device memory measurement.',
        shared_test_code='Existing KDA independent reference can consume arbitrary actual input/history/state; existing mHC math exposes its real collapse before enclosing a branch. Original default mathematical graphs and accuracy gates retained.',
        limits='Preceding-layer4H and component parameters generated; no full45-layer original target, natural vocabulary acceptance or official encoded cache claim.'),
    DSpark=dict(
        selected='Formal Flash0731 Q8_0 sidecar at fbbb5b93fb787c21338159b0af3318bb3f4d9768, matching formal target identity.',
        original_parameters=roles,
        roles='Original fc.weight Q8_0[4096,12288], enc.output_norm F32[4096], stage0 attn_kv Q8_0[512,4096], kv norm F32[512]; original packed bytes and norm bits retained.',
        dependency='Actual generated HC producer ReadLeases -> qualified3-tap tuple -> ordinary mean/concat/originalfc/norm -> actual main_x ReadLease -> original stage0 wkv/norm512-wide pre-RoPE.',
        qualification='Readonly parameter owners/layouts and whole target/session/branch/epoch/position/rows/layer tuple checked before binding. GGUF hidden-state layer41/42/43 maps to official block40/41/42; labels are caller provenance, not proof of trained execution.',
        reference='Stock byte codec decodes one Q8 row at a time; independent compensated FP64 dot and original F32 norm. Actual-predecessor and whole-chain references; existing selected-sidecar gate unchanged. No native activation quantizer/vec-dot output is the oracle.',
        executions='Generated and original cases each run3 generations9 Graph submissions per backend, zero input, retained old outputs, immutable parameters, bounded2-generation output pools.',
        limits='HC captures generated; pre-RoPE only. No trained target captures, physical512-wide persistent rings, other original stages/shared LM or natural model acceptance claim.'),
    native_CPU_contract_correction=dict(
        initial_failure=failed,
        audit=read(S / 'review/cpu-target-failure.json'),
        source_control=read(S / 'native-cpu-hc/adaptation.json'),
        matched_worker=native,
        controlled_result='Same140781568B EXE SHA8cacc1c352c4646ca8b6e7e27dfe7f4cf6554fd7eebac63e12b431870f2b2bcb. Old worker4b574bc5... interpreted defaultzero op_params as scale0. Matching copied HC_PRE function to the actually linked constructor removes only that extension. Replacing the worker on the same EXE yields all10 cases passing.',
        only_replaced_native_math_function='ggml_compute_forward_dsv4_hc_pre_f32',
        COMB_POST_audit='COMB functions identical across pins; POST nonnull-combine formula/stride agrees for the declared public operation. Other retained overlay functions preserved.',
        confirmation='Source-grounded explanation plus same-EXE controlled native rerun; no direct op_params memory dump was performed.',
        product_provider_or_tolerance_changed=False,
        build_scope='One native CPU ops TU and tiny current ABI export compiled; retained17 objects/libraries reused for DLL link. No fullSDK,NVCC,shader rebuild; old DLL/cache files retained.'),
    source_audit=read(S / 'review/target-composition.json'),
    actual_remaining=read(S / 'review/glm-after-c2-remaining.json'),
    validation=dict(platform='Windows CPU/CUDA; no new Apple/Linux/Vulkan run or combination matrix.',
        consumer_host_TU_compilations=4, native_CPU_ops_TUs=1, native_CPU_ABI_export_TUs=1,
        full_SDK_builds=0, NVCC_builds=0, shader_builds=0,
        throughput_evidence=False, physical_memory_evidence=False, performance_section=doc),
    cleanup=read(S / 'cleanup-result.json'),
    remaining=['GLM normal accepted draft-extend capture->next-epoch step0 direct reuse; upstream target MLA/indexer state composition; official cache/query/scorer and applicable original role/profile suppliers.',
        'DSpark actual qualified target taps, remaining original stage/shared-head suppliers,512-wide verified-main rings and complete actual-parameter journey.',
        'Q27/Q24 applicable role/codec and complete state combination; confirmed-MTP selected quantized formats.',
        'Focused remaining regressions and final ordinary/MTP prefill/decode/combined/physical-memory comparison; image encoder/projector afterward.'],
    large_original_payloads_archived=False,
    original_payload_retention='All4 exact role bodies retained locally under original-dspark-target; archive includes authenticated ranges/hashes/commands and small F32 norms, not another55MiB packed-weight copy.')
save(S / 'report-before-archive.json', report)
extensions = {'.json','.py','.cc','.cpp','.h','.md','.diff','.log','.xml','.txt','.ps1'}
files = [p for p in S.rglob('*') if p.is_file() and p.suffix.lower() in extensions and '__pycache__' not in p.parts]
files += list((S / 'original-dspark-target').glob('*.f32'))
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files): archive.write(path, path.relative_to(S).as_posix())
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
report['sources_commands_and_results'] = ident(ZIP)
save(OUT, report)
receipt = dict(evidence=ident(OUT), archive=ident(ZIP), goal_complete=False)
save(S / 'publication-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
