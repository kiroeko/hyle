#include <gtest/gtest.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <limits>
#include <numeric>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "hyle/compute/resource_leases.h"
#include "hyle/compute/state_versions.h"
#include "hyle/compute/storage_owner.h"
#if defined(HYLE_TEST_GLM_STATE_CUDA)
#include "hyle/compute/backends/cuda.h"
#include "hyle/graph/cuda.h"
#endif
#if defined(HYLE_TEST_GLM_STATE_CPU)
#include "hyle/graph/cpu.h"
#endif
#include "d5_glm_remaining_fragments.h"

namespace {
namespace c = hyle::compute;
namespace g = hyle::graph;
namespace m = hyle::mem;
namespace glm = d5_glm_remaining_fragments;
namespace sem = d5_qwen38_24t_semantic_fragments;
using Bytes = std::vector<std::byte>;
using Value = sem::ValueId;
using Reference = std::function<std::vector<float>(std::span<const float>)>;
constexpr auto kModel = glm::kCases[4];
constexpr std::int64_t kHidden = 4096, kQueryRank = 1536, kLatent = 512;
constexpr std::int64_t kIndexDepth = 128, kIndexHeads = 32, kRing = 6;
constexpr std::int64_t kCapacity = 2060, kPoolCapacity = kCapacity / 4;
constexpr std::int32_t kBasePosition = 2055, kBasePools = 513;
constexpr std::int64_t kIds = 2051, kSelected = 2048;

// Generated primary-GGUF/F32 reader components, not original checkpoint or
// official BF16/Hadamard/FP8 index-cache storage. This connects one whole
// NextN layer: EH, sparse MLA, plain residual/MoE, normalized hidden and its
// complete declared component state. It does not attach target KDA/conv/mHC
// to NextN or claim a complete target model, vocabulary or natural acceptance.
// Pool4, draft-bound2 -> six raw key/gate rollback slots. A fresh indexer at
// position2055 closes one pool. Same-iteration reuse then skips the ENTIRE
// indexer: raw ring/pools and indexer cursor retain their actual old leases,
// while MLA cursor, latent cache, q-residual and hidden continue independently.
// Policy token IDs and the iteration epoch are explicit consumer decisions.
// Counters use existing I32 Scan/Gather; no host result is rebuilt for execution.
// Fixed SGLang06992c92ad4494fe9f9636e75be3e35040512447: forward_mla.py,
// index_topk_share.py and kpool_fp8_index.py establish the iteration/pool
// policy; existing generated GGUF fragments supply the F32 reader equations.
// New-iteration target catchup/reseed after accepted skip tokens remains a
// separate consumer requirement, as does target-side KDA/conv/mHC composition.
template<class T> T take(hyle::Result<T> result, const char *where) {
  if (!result) throw std::runtime_error(std::string(where) + ": " + std::string(result.error().message()));
  return std::move(*result);
}
void check(hyle::Status status, const char *where) {
  if (!status.ok()) throw std::runtime_error(std::string(where) + ": " + std::string(status.message()));
}
c::ReadLease upload(const c::StorageOwner &owner, std::span<const std::byte> values) {
  auto buffer = take(m::Buffer::create(owner.ref(), values.size(), 256), "initial/parameter backing");
  check(buffer.view().write(values), "explicit initial/parameter bytes");
  return take(owner.adopt_buffer(std::move(buffer)), "qualified readonly initial value");
}
Bytes read(const c::ReadLease &lease) {
  Bytes result(lease.size());
  check(take(lease.view(), "readonly actual state").read(result), "actual state read"); return result;
}
template<class T> std::vector<T> typed(const c::ReadLease &lease) {
  if (lease.size() % sizeof(T)) throw std::runtime_error("state scalar extent");
  std::vector<T> result(lease.size() / sizeof(T));
  check(take(lease.view(), "actual typed state view").read(std::as_writable_bytes(std::span(result))), "typed state read");
  return result;
}
enum Entry : std::size_t {
  kCache, kRawKey, kRawGate, kPool, kHiddenState, kQueryState, kPending,
  kMlaCursor, kIndexCursor, kPoolCount, kRingOffset, kTailValid, kTailStart,
  kSelection, kEpoch, kEntries
};
constexpr std::size_t kResources = kEpoch;
std::array<c::TensorDesc, kResources> descriptions() {
  const auto scalar = sem::dense({1}, c::DataType::kInt32);
  return {sem::dense({kCapacity, kLatent}), sem::dense({kRing, kIndexDepth}),
      sem::dense({kRing, kIndexDepth}), sem::dense({kPoolCapacity, kIndexDepth}),
      sem::dense({1, kHidden}), sem::dense({1, kQueryRank}), scalar, scalar,
      scalar, scalar, scalar, scalar, scalar, sem::dense({kIds}, c::DataType::kInt32)};
}
std::vector<float> embedding_values(std::int32_t token) {
  auto values = d5_gguf_test::activation(kHidden, 11 + 14 * token);
  for (auto &value : values) value = std::abs(value) + 0.5F;
  return values;
}
Value increment(sem::Fragment &f, Value old, std::int32_t delta = 1) {
  const auto amount = f.constant(sem::dense({1}, c::DataType::kInt32), sem::bytes(std::vector{delta}));
  const auto joined = f.one(c::Operation(c::Concat{.axis = 0}), {old, amount});
  const auto prefix = f.one(c::Operation(c::Scan{.axis = 0}), {joined});
  const auto last = f.constant(sem::dense({1}, c::DataType::kInt32), sem::bytes(std::vector<std::int32_t>{1}));
  return f.one(c::Operation(c::Gather{}), {prefix, last});
}
Value advance_ring(sem::Fragment &f, Value old, std::int32_t size) {
  std::vector<std::int32_t> values(std::size_t(size), 0);
  for (std::int32_t i = 0; i < size; ++i) values[std::size_t(i)] = (i + 1) % size;
  const auto table = f.constant(sem::dense({size}, c::DataType::kInt32), sem::bytes(values));
  return f.one(c::Operation(c::Gather{}), {table, old});
}
struct Recipe final {
  sem::Fragment fragment;
  std::array<std::size_t, kResources> state_ports;
  bool fresh = false;
  glm::InputReference input_reference;
  Reference query_reference, absorbed_query_reference, latent_reference, key_reference, gate_reference;
  Reference index_query_reference, score_weight_reference, output_reference;
  glm::moe::MoeReference moe_reference;
  std::vector<float> input_scale, query_scale, ffn_scale, head_scale;
  std::size_t embedding, eh, nx, query, latent, attention, output, residual, ffn_input, ffn_output;
  std::size_t key = 0, gate = 0, compressed = 0, index_query = 0, score_weight = 0, scores = 0;
};
Recipe build(bool fresh) {
  Recipe r;
  r.fresh = fresh;
  r.state_ports.fill(std::numeric_limits<std::size_t>::max());
  auto &f = r.fragment;
  f.profile = kModel.profile; f.region = fresh ? 0x474c4d5354465245ULL : 0x474c4d5354534b50ULL;
  f.quantized = true;
  const auto desc = descriptions();
  std::array<Value, kResources> state;
  for (std::size_t i = 0; i < state.size(); ++i) state[i] = f.input(desc[i]);
  const auto next_pending = f.input(sem::dense({1}, c::DataType::kInt32));
  const auto publish = [&](Value value, bool copy = false) {
    if (copy) value = f.one(c::Operation(c::Copy{}), {value});
    const auto port = f.outputs.size(); f.outputs.push_back(value); return port;
  };
  const auto changed = [&](Entry entry, Value value, bool copy = false) {
    r.state_ports[entry] = publish(value, copy); return value;
  };
  std::vector<float> embeddings;
  for (std::int32_t token = 0; token < 8; ++token) {
    const auto values = embedding_values(token); embeddings.insert(embeddings.end(), values.begin(), values.end());
  }
  const auto token_bank = f.constant(sem::dense({8, kHidden}), sem::bytes(embeddings));
  const auto embedding = f.one(c::Operation(c::Gather{}), {token_bank, state[kPending]});
  r.embedding = publish(embedding);
  const auto input = glm::attach(f, glm::mtp_input(kModel, &r.input_reference, false),
      {state[kHiddenState], embedding});
  const auto eh = input[3]; r.eh = publish(eh);
  r.input_scale = sem::oracle::scale(kHidden);
  auto input_scale = r.input_scale;
  const auto nx = glm::norm(f, eh, input_scale); r.nx = publish(nx);
  auto qa = glm::projection(f, nx, kQueryRank, kHidden, 197, false);
  r.query_scale = sem::oracle::scale(kQueryRank);
  auto query_scale = r.query_scale;
  const auto qr = changed(kQueryState, glm::norm(f, qa.output, query_scale));
  r.query_reference = [qa = std::move(qa), scale = r.query_scale](auto x) {
    return sem::oracle::rms_norm_rows(qa.reference(x), scale, kQueryRank, glm::kNormEpsilon);
  };
  auto qb = glm::projection(f, qr, glm::kHeads * 256, kQueryRank, 199, false);
  const auto query_nope = glm::kimi::slice_heads(f, qb.output, glm::kHeads, 256, 0, 256);
  auto kb = glm::head_projection(f, query_nope, kLatent, 256, 223);
  const auto query = glm::reshape(f, kb.output, {1, 1, glm::kHeads, kLatent});
  r.query = publish(query, true);
  r.absorbed_query_reference = [qb = std::move(qb), kb = std::move(kb)](auto x) {
    return kb.reference(qb.reference(x));
  };
  auto kva = glm::projection(f, nx, kLatent, kHidden, 211, false);
  auto latent_scale = sem::oracle::scale(kLatent);
  const auto latent = glm::norm(f, kva.output, latent_scale); r.latent = publish(latent);
  r.latent_reference = [kva = std::move(kva), scale = latent_scale](auto x) {
    return sem::oracle::rms_norm_rows(kva.reference(x), scale, kLatent, glm::kNormEpsilon);
  };
  const auto cache = changed(kCache, f.one(c::Operation(c::Scatter{}), {state[kCache], state[kMlaCursor], latent}));
  const auto cursor = changed(kMlaCursor, increment(f, state[kMlaCursor]));
  changed(kPending, next_pending, true);
  Value selected = state[kSelection];
  if (fresh) {
    // This finite preparation closes logical [2052,2055]; qualification checks
    // the actual scalar leases before bind. No rolling-history deletion occurs.
    auto wk = glm::projection(f, nx, kIndexDepth, kHidden, 241, false);
    auto scale = sem::oracle::scale(kIndexDepth);
    std::vector<float> bias(kIndexDepth);
    for (std::int64_t d = 0; d < kIndexDepth; ++d) bias[std::size_t(d)] = float(d % 7 - 3) / 32.0F;
    const auto sw = f.constant(sem::dense({kIndexDepth}), sem::bytes(scale));
    const auto bw = f.constant(sem::dense({kIndexDepth}), sem::bytes(bias));
    const auto key = f.one(c::Operation(c::LayerNorm{.epsilon = 1.0e-6F}), {wk.output, sw, bw});
    r.key = publish(key);
    r.key_reference = [wk = std::move(wk), scale, bias](auto x) { return glm::layer_norm(wk.reference(x), scale, bias); };
    auto wg = glm::linear::projection(f, nx, kIndexDepth, kHidden, glm::linear::Storage::kQ8_0, 257);
    const auto gate = wg.output; r.gate = publish(gate);
    r.gate_reference = [wg = std::move(wg)](auto x) { return wg.reference(x); };
    const auto keys = changed(kRawKey, f.one(c::Operation(c::Scatter{}), {state[kRawKey], state[kRingOffset], key}));
    const auto gates = changed(kRawGate, f.one(c::Operation(c::Scatter{}), {state[kRawGate], state[kRingOffset], gate}));
    const auto four = f.constant(sem::dense({1, 4}, c::DataType::kInt32), sem::bytes(std::vector<std::int32_t>{0, 1, 2, 3}));
    const auto grouped_key = f.one(c::Operation(c::Gather{}), {keys, four});
    const auto grouped_gate = f.one(c::Operation(c::Gather{}), {gates, four});
    std::vector<float> ape(4 * kIndexDepth);
    for (std::size_t i = 0; i < ape.size(); ++i) ape[i] = float(int(i * 7 % 19) - 9) / 16.0F;
    const auto positional = f.constant(sem::dense({1, 4, kIndexDepth}), sem::bytes(ape));
    const auto logits = glm::binary(f, c::BinaryKind::kAdd, grouped_gate, positional);
    const auto rows = f.one(c::Operation(c::Copy{}), {glm::permute(f, logits, {0, 2, 1})});
    auto probability = f.one(c::Operation(c::Softmax{}), {glm::reshape(f, rows, {kIndexDepth, 4})});
    probability = f.one(c::Operation(c::Copy{}), {glm::permute(f, glm::reshape(f, probability, {1, kIndexDepth, 4}), {0, 2, 1})});
    const auto pooled = glm::reduce(f, glm::binary(f, c::BinaryKind::kMultiply, probability, grouped_key), 1);
    r.compressed = publish(pooled);
    const auto pool = changed(kPool, f.one(c::Operation(c::Scatter{}), {state[kPool], state[kPoolCount], pooled}));
    changed(kIndexCursor, cursor, true);
    changed(kPoolCount, increment(f, state[kPoolCount]));
    changed(kRingOffset, advance_ring(f, state[kRingOffset], kRing));
    changed(kTailValid, advance_ring(f, state[kTailValid], 4));
    changed(kTailStart, increment(f, state[kTailStart], 4));
    auto wq = glm::projection(f, qr, kIndexHeads * kIndexDepth, kQueryRank, 239, false);
    const auto iq = glm::reshape(f, wq.output, {kIndexHeads, kIndexDepth});
    r.index_query = publish(iq, true);
    r.index_query_reference = [wq = std::move(wq)](auto x) { return wq.reference(x); };
    auto ws = glm::linear::projection(f, nx, kIndexHeads, kHidden, glm::linear::Storage::kF32, 251);
    const auto weights = glm::binary(f, c::BinaryKind::kMultiply, ws.output,
        glm::filled(f, sem::dense({1}), 1.0F / std::sqrt(float(kIndexHeads))));
    r.score_weight = publish(weights);
    r.score_weight_reference = [ws = std::move(ws)](auto x) {
      auto result = ws.reference(x); for (auto &v : result) v /= std::sqrt(float(kIndexHeads)); return result;
    };
    const auto visible = glm::core::rows(f, pool, 0, kBasePools + 1);
    auto dot = f.one(c::Operation(c::MatMul{}), {iq, glm::permute(f, visible, {1, 0})});
    dot = glm::binary(f, c::BinaryKind::kMultiply, dot,
        glm::filled(f, sem::dense({1}), 1.0F / std::sqrt(float(kIndexDepth))));
    dot = f.one(c::model_ops::clamp(0.0F, std::numeric_limits<float>::max()), {dot});
    const auto scores = glm::reshape(f, glm::reduce(f, glm::binary(f, c::BinaryKind::kMultiply,
        glm::reshape(f, weights, {kIndexHeads, 1}), dot), 0), {1, kBasePools + 1});
    r.scores = publish(scores, true);
    const auto top = f.append(c::Operation(c::TopK{.count = 512}), {scores}, 2);
    std::vector<std::int32_t> expanded(std::size_t((kBasePools + 1) * 4));
    std::iota(expanded.begin(), expanded.end(), 0);
    const auto table = f.constant(sem::dense({kBasePools + 1, 4}, c::DataType::kInt32), sem::bytes(expanded));
    const auto pool_ids = glm::reshape(f, f.one(c::Operation(c::Gather{}), {table, top[1]}), {2048});
    const auto empty_tail = f.constant(sem::dense({3}, c::DataType::kInt32), sem::bytes(std::vector<std::int32_t>(3, -1)));
    selected = f.one(c::Operation(c::Concat{.axis = 0}), {pool_ids, empty_tail});
    changed(kSelection, selected);
  } else {
    // No wq/wk/wg/pooling/TopK exists in this graph. The actual same-epoch IDs
    // from the StateVersion are the checked Gather's producer permission.
    selected = changed(kSelection, selected, true);
  }
  const auto valid = glm::reshape(f, glm::core::rows(f, glm::reshape(f, selected, {kIds, 1}), 0, kSelected), {kSelected});
  const auto chosen = f.one(c::Operation(c::Gather{}), {cache, valid});
  const auto attention = f.one(c::Operation(c::ScaledDotProductAttention{.scale = 1.0F / 16.0F,
      .causal = true, .accumulation_type = c::DataType::kFloat32}),
      {query, glm::reshape(f, chosen, {1, kSelected, 1, kLatent}), glm::reshape(f, chosen, {1, kSelected, 1, kLatent})});
  r.attention = publish(attention);
  auto vb = glm::head_projection(f, glm::reshape(f, attention, {1, glm::kHeads, kLatent}), glm::kValue, kLatent, 227);
  auto out = glm::projection(f, glm::reshape(f, vb.output, {1, glm::kHeads * glm::kValue}),
      kHidden, glm::kHeads * glm::kValue, 229, false);
  r.output = publish(out.output);
  r.output_reference = [vb = std::move(vb), out = std::move(out)](auto x) { return out.reference(vb.reference(x)); };
  const auto residual = glm::binary(f, c::BinaryKind::kAdd, eh, out.output); r.residual = publish(residual);
  r.ffn_scale = sem::oracle::scale(kHidden); auto ffn_scale = r.ffn_scale;
  const auto ffn_input = glm::norm(f, residual, ffn_scale); r.ffn_input = publish(ffn_input);
  auto moe = glm::moe::moe_chain(glm::moe::cases::kCases[11], false, false, &r.moe_reference, 0.5F);
  const auto ff = glm::attach(f, std::move(moe), {ffn_input});
  r.ffn_output = publish(ff[5]);
  const auto combined = glm::binary(f, c::BinaryKind::kAdd, residual, glm::reshape(f, ff[5], {1, kHidden}));
  r.head_scale = sem::oracle::scale(kHidden); std::reverse(r.head_scale.begin(), r.head_scale.end());
  auto head_scale = r.head_scale;
  changed(kHiddenState, glm::norm(f, combined, head_scale));
  return r;
}

struct Program final {
  Recipe recipe;
  sem::GraphCase logical;
  std::vector<c::ReadLease> parameters;
  g::CompiledGraph compiled;
  g::Invocation invocation;
  c::LeasePool outputs;
  static Program create(Recipe recipe, c::Context &context, const c::StorageOwner &owner, bool cuda) {
    Program p; p.recipe = std::move(recipe); p.logical = sem::make_graph(p.recipe.fragment);
    std::vector<g::ConstantBinding> constants;
    for (std::size_t i = 0; i < p.logical.constants.size(); ++i) {
      p.parameters.push_back(upload(owner, p.recipe.fragment.constant_bytes[i]));
      constants.push_back({p.logical.constants[i], take(p.parameters.back().tensor(
          p.recipe.fragment.description(p.recipe.fragment.constants[i])), "typed NextN constant")});
    }
    const c::WorkloadContext workload{take(c::ModelArtifactProfile::create(*kModel.profile), "primary GGUF profile"),
        c::WorkloadPhase::kDecode, {0x48594c454d4f444cULL, p.recipe.fragment.region, 1}};
    const g::CompileOptions options{.constants = constants, .workload = workload};
    const auto compile = [&]() -> hyle::Result<g::CompiledGraph> {
#if defined(HYLE_TEST_GLM_STATE_CPU)
      if (!cuda) return g::cpu::compile(p.logical.graph, context, options);
#endif
#if defined(HYLE_TEST_GLM_STATE_CUDA)
      if (cuda) return g::cuda::compile(p.logical.graph, context, owner, options);
#endif
      throw std::runtime_error("GLM state consumer backend not enabled");
    };
    p.compiled = take(compile(), "ordinary connected NextN Graph");
    p.invocation = take(p.compiled.executable.create_invocation({.resources = g::ResourceOptions{}}), "ordinary NextN Invocation");
    std::size_t footprint = 0;
    for (std::size_t i = 0; i < p.logical.outputs.size(); ++i) {
      if (take(p.compiled.executable.output_ownership(i), "NextN output ownership") != g::OutputOwnership::kCaller)
        throw std::runtime_error("NextN consumer requires caller-owned result storage");
      const auto extent = take(p.recipe.fragment.description(p.recipe.fragment.outputs[i]).required_bytes(), "NextN output extent");
      footprint += (extent + 255u) / 256u * 256u;
    }
    p.outputs = take(c::LeasePool::create(owner.ref(), footprint * 5,
        {.max_blocks = std::uint32_t(p.logical.outputs.size() * 5), .backing_alignment = 256}), "bounded five NextN output generations");
    return p;
  }
  std::vector<c::ReadLease> execute(c::Queue &queue, std::span<const c::ReadLease> inputs) {
    if (inputs.size() != logical.inputs.size()) throw std::runtime_error("complete NextN input count");
    for (std::size_t i = 0; i < inputs.size(); ++i)
      check(invocation.bind(logical.inputs[i], recipe.fragment.description(recipe.fragment.inputs[i]), inputs[i]), "bind actual NextN state lease");
    for (std::size_t i = 0; i < logical.outputs.size(); ++i) {
      const auto &desc = recipe.fragment.description(recipe.fragment.outputs[i]);
      check(invocation.bind(logical.outputs[i], desc, take(outputs.allocate(take(desc.required_bytes(), "NextN result bytes")), "fresh NextN result writer")), "bind NextN result");
    }
    const std::array queues{g::QueueBinding{g::ExecutionLaneId{0}, &queue}};
    check(invocation.prepare_replay(queues, {.mode = g::ReplayMode::kCommands, .host_wait = g::HostWaitPolicy::kAllow}), "prepare connected NextN invocation");
    { auto done = take(invocation.submit(queues), "strict NextN submit"); check(done.wait(), "complete NextN retirement"); }
    std::vector<c::ReadLease> result;
    for (auto output : logical.outputs) result.push_back(take(take(invocation.result(output), "actual NextN output").storage_lease(), "independent NextN output lease"));
    check(invocation.reset(), "withdraw NextN result permissions");
    if (invocation.submit(queues)) throw std::runtime_error("reset NextN invocation retained stale replay");
    return result;
  }
};

struct Epoch final { std::uint64_t epoch, producer_position, reuse_count; };
static_assert(sizeof(Epoch) == 24);
struct State final {
  c::StateSchema schema;
  c::StateStore store;
  std::array<c::StateEntryId, kEntries> entries;
  std::uint64_t epoch = 7;
  bool enabled = true;
  static State create(const c::StorageOwner &owner) {
    const auto desc = descriptions(); std::array<c::StateEntrySpec, kEntries> specs;
    for (std::size_t i = 0; i < kResources; ++i) specs[i] = {.description = desc[i], .resource = owner.ref()};
    specs[kEpoch] = {.kind = c::StateEntryKind::kHostMetadata, .metadata_bytes = sizeof(Epoch)};
    State result; result.schema = take(c::StateSchema::create(specs), "complete component schema");
    result.store = take(c::StateStore::create(result.schema, {.max_versions = 16, .max_drafts = 2,
        .max_retained_blocks = 256, .max_backing_bytes = 128u << 20}), "bounded complete component state store");
    for (std::size_t i = 0; i < kEntries; ++i) result.entries[i] = take(result.schema.entry(i), "complete schema entry");
    return result;
  }
  c::ReadLease member(const c::StateVersion &v, std::size_t i) const { return take(v.member(entries[i]), "actual complete state member"); }
  std::int32_t scalar(const c::StateVersion &v, Entry entry) const { return typed<std::int32_t>(member(v, entry)).at(0); }
  Epoch facts(const c::StateVersion &v) const {
    const auto bytes = read(member(v, kEpoch)); Epoch result{}; std::memcpy(&result, bytes.data(), sizeof(result)); return result;
  }
  bool qualifies(const c::StateVersion &v) const { return enabled && v.valid() && facts(v).epoch == epoch; }
  c::StateVersion initial(const c::StorageOwner &owner) {
    std::array<Bytes, kResources> values;
    std::vector<float> cache(kCapacity * kLatent, std::numeric_limits<float>::quiet_NaN());
    for (std::int64_t t = 0; t < kBasePosition; ++t) for (std::int64_t d = 0; d < kLatent; ++d)
      cache[std::size_t(t * kLatent + d)] = 0.25F + float(t % 97) / 64.0F + float(d % 11) / 128.0F;
    values[kCache] = sem::bytes(cache);
    std::vector<float> raw(kRing * kIndexDepth), gates(raw.size());
    for (std::int32_t p = kBasePosition - std::int32_t(kRing); p < kBasePosition; ++p)
      for (std::int64_t d = 0; d < kIndexDepth; ++d) {
        raw[std::size_t((p % kRing) * kIndexDepth + d)] = float((p * 3 + d * 7) % 97 - 48) / 32.0F;
        gates[std::size_t((p % kRing) * kIndexDepth + d)] = float((p * 7 + d * 11) % 29 - 14) / 8.0F;
      }
    values[kRawKey] = sem::bytes(raw); values[kRawGate] = sem::bytes(gates);
    std::vector<float> pools(kPoolCapacity * kIndexDepth, std::numeric_limits<float>::quiet_NaN());
    for (std::int64_t p = 0; p < kBasePools; ++p) for (std::int64_t d = 0; d < kIndexDepth; ++d)
      pools[std::size_t(p * kIndexDepth + d)] = (0.125F + float(p) / 64.0F) * (0.5F + float(d % 11) / 32.0F);
    values[kPool] = sem::bytes(pools);
    values[kHiddenState] = sem::bytes(embedding_values(0));
    values[kQueryState] = sem::bytes(std::vector<float>(kQueryRank, 0));
    const std::array<std::int32_t, 7> scalars{1, kBasePosition, kBasePosition, kBasePools,
        kBasePosition % std::int32_t(kRing), 3, kBasePosition - 3};
    for (std::size_t i = 0; i < scalars.size(); ++i) values[kPending + i] = sem::bytes(std::vector{scalars[i]});
    values[kSelection] = sem::bytes(std::vector<std::int32_t>(kIds, -1));
    std::array<c::StateMember, kEntries> members;
    for (std::size_t i = 0; i < kResources; ++i) members[i] = {entries[i], upload(owner, values[i])};
    const Epoch metadata{0, 0, 0}; members[kEpoch] = {entries[kEpoch], {}, std::as_bytes(std::span(&metadata, 1))};
    return take(store.import(members), "initial declared component checkpoint");
  }
  c::StateVersion stage(const c::StateVersion &from, const Recipe &recipe, std::span<const c::ReadLease> outputs) {
    auto draft = take(store.begin(from), "whole component draft");
    for (std::size_t i = 0; i < kResources; ++i)
      if (recipe.state_ports[i] != std::numeric_limits<std::size_t>::max())
        check(draft.replace(entries[i], outputs[recipe.state_ports[i]]), "stage actual component output");
    auto metadata = facts(from);
    if (recipe.fresh) metadata = {epoch, std::uint64_t(scalar(from, kMlaCursor)), 0};
    else ++metadata.reuse_count;
    check(draft.replace_metadata(entries[kEpoch], std::as_bytes(std::span(&metadata, 1))), "explicit component iteration policy");
    return take(draft.finalize(), "finalize all component state");
  }
};
using Image = std::array<Bytes, kEntries>;
Image image(const State &s, const c::StateVersion &v) {
  Image result; for (std::size_t i = 0; i < kEntries; ++i) result[i] = read(s.member(v, i)); return result;
}
void same_storage(const c::ReadLease &a, const c::ReadLease &b) {
  const auto av = take(a.view(), "first actual storage identity"), bv = take(b.view(), "second actual storage identity");
  EXPECT_EQ(av.resource(), bv.resource()); EXPECT_EQ(av.native_handle(), bv.native_handle());
  EXPECT_EQ(av.offset(), bv.offset()); EXPECT_EQ(av.size(), bv.size()); EXPECT_EQ(a.generation(), b.generation());
}
void quantified(const Recipe &recipe, std::span<const float> actual, std::span<const float> expected) {
  sem::expect_output(recipe.fragment, actual, expected);
}
void exact_scatter(const State &s, const c::StateVersion &from, const c::StateVersion &next,
                   Entry bank, std::size_t row, std::size_t width, const c::ReadLease &update) {
  auto expected = read(s.member(from, bank)); const auto actual_update = read(update);
  ASSERT_EQ(actual_update.size(), width * sizeof(float));
  std::copy(actual_update.begin(), actual_update.end(), expected.begin() + row * width * sizeof(float));
  EXPECT_EQ(read(s.member(next, bank)), expected) << "only the actual native-produced row may change";
}
void observe(const State &s, const c::StateVersion &from, const c::StateVersion &next,
             const Recipe &r, std::span<const c::ReadLease> output) {
  const auto fp = [&](std::size_t port) { return typed<float>(output[port]); };
  const auto hidden = typed<float>(s.member(from, kHiddenState));
  const auto embedding = fp(r.embedding), eh = fp(r.eh), nx = fp(r.nx);
  EXPECT_EQ(embedding, embedding_values(s.scalar(from, kPending)));
  quantified(r, eh, r.input_reference(hidden, embedding)[3]);
  sem::oracle::expect_close(nx, sem::oracle::rms_norm_rows(eh, r.input_scale, kHidden, glm::kNormEpsilon), 8e-5F, 4e-5F);
  const auto qr = typed<float>(s.member(next, kQueryState));
  quantified(r, qr, r.query_reference(nx));
  quantified(r, fp(r.latent), r.latent_reference(nx));
  exact_scatter(s, from, next, kCache, std::size_t(s.scalar(from, kMlaCursor)), kLatent, output[r.latent]);
  EXPECT_EQ(s.scalar(next, kMlaCursor), s.scalar(from, kMlaCursor) + 1);
  const auto ids = typed<std::int32_t>(s.member(next, kSelection));
  ASSERT_EQ(ids.size(), std::size_t(kIds));
  for (std::size_t i = kSelected; i < ids.size(); ++i) EXPECT_EQ(ids[i], -1);
  if (r.fresh) {
    quantified(r, fp(r.key), r.key_reference(nx)); quantified(r, fp(r.gate), r.gate_reference(nx));
    exact_scatter(s, from, next, kRawKey, std::size_t(s.scalar(from, kRingOffset)), kIndexDepth, output[r.key]);
    exact_scatter(s, from, next, kRawGate, std::size_t(s.scalar(from, kRingOffset)), kIndexDepth, output[r.gate]);
    const auto raw = typed<float>(s.member(next, kRawKey)), gates = typed<float>(s.member(next, kRawGate));
    std::vector<float> pooled(kIndexDepth);
    for (std::size_t d = 0; d < kIndexDepth; ++d) {
      std::array<double, 4> logits;
      for (std::size_t t = 0; t < 4; ++t) logits[t] = gates[t * kIndexDepth + d] + double(int((t * kIndexDepth + d) * 7 % 19) - 9) / 16.0;
      const auto maximum = *std::max_element(logits.begin(), logits.end()); double total = 0, result = 0;
      for (auto &value : logits) total += value = std::exp(value - maximum);
      for (std::size_t t = 0; t < 4; ++t) result += logits[t] / total * raw[t * kIndexDepth + d];
      pooled[d] = float(result);
    }
    sem::oracle::expect_close(fp(r.compressed), pooled, 8e-5F, 4e-5F);
    exact_scatter(s, from, next, kPool, kBasePools, kIndexDepth, output[r.compressed]);
    EXPECT_EQ(s.scalar(next, kIndexCursor), kBasePosition + 1);
    EXPECT_EQ(s.scalar(next, kPoolCount), kBasePools + 1);
    EXPECT_EQ(s.scalar(next, kRingOffset), 4); EXPECT_EQ(s.scalar(next, kTailValid), 0);
    EXPECT_EQ(s.scalar(next, kTailStart), kBasePosition + 1);
    quantified(r, fp(r.index_query), r.index_query_reference(qr));
    sem::oracle::expect_close(fp(r.score_weight), r.score_weight_reference(nx), 8e-5F, 4e-5F);
    const auto iq = fp(r.index_query), weights = fp(r.score_weight), pool = typed<float>(s.member(next, kPool));
    std::vector<float> expected_scores(kBasePools + 1);
    for (std::size_t p = 0; p < expected_scores.size(); ++p) {
      double score = 0;
      for (std::size_t h = 0; h < kIndexHeads; ++h) {
        double dot = 0; for (std::size_t d = 0; d < kIndexDepth; ++d) dot += double(iq[h * kIndexDepth + d]) * pool[p * kIndexDepth + d];
        score += weights[h] * std::max(0.0, dot / std::sqrt(double(kIndexDepth)));
      }
      expected_scores[p] = float(score);
    }
    const auto scores = fp(r.scores); sem::oracle::expect_close(scores, expected_scores, 8e-5F, 4e-5F);
    std::array<bool, kBasePools + 1> picked{}; float smallest = std::numeric_limits<float>::infinity();
    for (std::size_t t = 0; t < 512; ++t) {
      const auto pool_id = ids[t * 4] / 4;
      ASSERT_GE(pool_id, 0); ASSERT_LT(pool_id, kBasePools + 1); EXPECT_FALSE(picked[std::size_t(pool_id)]);
      picked[std::size_t(pool_id)] = true; smallest = std::min(smallest, scores[std::size_t(pool_id)]);
      for (std::size_t j = 0; j < 4; ++j) EXPECT_EQ(ids[t * 4 + j], pool_id * 4 + std::int32_t(j));
    }
    for (std::size_t p = 0; p < picked.size(); ++p) if (!picked[p]) EXPECT_GE(smallest, scores[p]);
  } else {
    for (const auto entry : {kRawKey, kRawGate, kPool, kIndexCursor, kPoolCount, kRingOffset, kTailValid, kTailStart})
      same_storage(s.member(next, entry), s.member(from, entry));
    EXPECT_EQ(read(s.member(next, kSelection)), read(s.member(from, kSelection)));
  }
  const auto query = fp(r.query), cache = typed<float>(s.member(next, kCache));
  quantified(r, query, r.absorbed_query_reference(qr));
  std::vector<float> selected(kSelected);
  for (std::size_t i = 0; i < selected.size(); ++i) selected[i] = float(ids[i]);
  const auto attention = fp(r.attention);
  sem::oracle::expect_close(attention, glm::attention_reference(query, cache, selected, kSelected, kLatent), 8e-5F, 4e-5F);
  const auto projected = fp(r.output); quantified(r, projected, r.output_reference(attention));
  auto residual = eh; for (std::size_t i = 0; i < residual.size(); ++i) residual[i] += projected[i];
  sem::oracle::expect_close(fp(r.residual), residual, 8e-5F, 4e-5F);
  const auto ffn_input = fp(r.ffn_input), ffn_output = fp(r.ffn_output);
  sem::oracle::expect_close(ffn_input, sem::oracle::rms_norm_rows(fp(r.residual), r.ffn_scale, kHidden, glm::kNormEpsilon), 8e-5F, 4e-5F);
  quantified(r, ffn_output, r.moe_reference(ffn_input)[5]);
  const auto actual_residual = fp(r.residual);
  for (std::size_t i = 0; i < residual.size(); ++i) residual[i] = actual_residual[i] + ffn_output[i];
  sem::oracle::expect_close(typed<float>(s.member(next, kHiddenState)),
      sem::oracle::rms_norm_rows(residual, r.head_scale, kHidden, glm::kNormEpsilon), 8e-5F, 4e-5F);
}

c::StateVersion execute(State &s, Program &p, c::Queue &queue, const c::StorageOwner &owner,
                        const c::StateVersion &from, std::int32_t pending) {
  if (!s.enabled || (!p.recipe.fresh && !s.qualifies(from)))
    throw std::runtime_error("consumer refused index carry outside its iteration before prepare");
  if (p.recipe.fresh && (s.scalar(from, kMlaCursor) != kBasePosition ||
      s.scalar(from, kIndexCursor) != kBasePosition || s.scalar(from, kPoolCount) != kBasePools ||
      s.scalar(from, kRingOffset) != 3 || s.scalar(from, kTailValid) != 3 || s.scalar(from, kTailStart) != kBasePosition - 3))
    throw std::runtime_error("fresh finite preparation does not match actual pool/cursor state");
  std::vector<c::ReadLease> arguments;
  for (std::size_t i = 0; i < kResources; ++i) arguments.push_back(s.member(from, i));
  arguments.push_back(upload(owner, sem::bytes(std::vector{pending})));
  const auto before = image(s, from);
  auto outputs = p.execute(queue, arguments);
  auto next = s.stage(from, p.recipe, outputs);
  observe(s, from, next, p.recipe, outputs);
  EXPECT_EQ(image(s, from), before);
  EXPECT_EQ(s.scalar(next, kPending), pending);
  for (std::size_t i = 0; i < kResources; ++i)
    if (p.recipe.state_ports[i] != std::numeric_limits<std::size_t>::max())
      same_storage(s.member(next, i), outputs[p.recipe.state_ports[i]]);
  return next;
}

// Engine policy can correct a rejected draft's next token. Even this small
// publication comes from an ordinary actual Graph output; no observed result
// is converted into a host-created replacement lease.
sem::Fragment pending_policy() {
  sem::Fragment f{.profile = kModel.profile, .region = 0x474c4d50454e44ULL};
  const auto input = f.input(sem::dense({1}, c::DataType::kInt32));
  f.outputs = {f.one(c::Operation(c::Copy{}), {input})}; return f;
}
void run(c::Context &context, const c::StorageOwner &owner, bool cuda) {
  auto fresh = Program::create(build(true), context, owner, cuda);
  auto skip = Program::create(build(false), context, owner, cuda);
  Recipe policy_recipe; policy_recipe.fragment = pending_policy();
  auto policy = Program::create(std::move(policy_recipe), context, owner, cuda);
  auto queue = take(context.create_queue(), "complete component queue");
  auto state = State::create(owner);
  std::size_t native_submissions = 0;
  {
    const auto base = state.initial(owner);
    const auto base_bytes = image(state, base);
    auto head = take(c::StateHead::create(state.store, base), "whole component shared head");
    const auto first = execute(state, fresh, queue, owner, base, 2); ++native_submissions;
    const auto first_bytes = image(state, first);
    const auto rejected_tail = execute(state, skip, queue, owner, first, 4); ++native_submissions;
    const auto rejected_bytes = image(state, rejected_tail);
    EXPECT_EQ(state.scalar(rejected_tail, kMlaCursor), kBasePosition + 2);
    EXPECT_EQ(state.scalar(rejected_tail, kIndexCursor), kBasePosition + 1);
    EXPECT_EQ(state.facts(rejected_tail).reuse_count, 1u);
    // An explicit target policy chooses token3 instead of the draft's token2.
    const std::array correction_input{upload(owner, sem::bytes(std::vector<std::int32_t>{3}))};
    auto correction = policy.execute(queue, correction_input); ++native_submissions;
    auto accepted_draft = take(state.store.begin(first), "accepted prefix plus explicit policy token");
    check(accepted_draft.replace(state.entries[kPending], correction[0]), "actual corrected pending output");
    const auto accepted = take(accepted_draft.finalize(), "complete accepted prefix1");
    check(head.publish(base.identity(), accepted), "atomically publish complete prefix1");
    EXPECT_FALSE(head.publish(base.identity(), rejected_tail).ok()) << "stale prefix2 must not replace the accepted head";
    EXPECT_EQ(image(state, take(head.current(), "actual accepted head")), image(state, accepted));
    // No part of token2's MLA append enters the accepted/draft continuation.
    EXPECT_EQ(image(state, first), first_bytes);
    const auto accepted_cache = read(state.member(accepted, kCache));
    const auto rejected_cache = read(state.member(rejected_tail, kCache));
    EXPECT_FALSE(std::equal(accepted_cache.begin() + (kBasePosition + 1) * kLatent * 4,
        accepted_cache.begin() + (kBasePosition + 2) * kLatent * 4,
        rejected_cache.begin() + (kBasePosition + 1) * kLatent * 4));
    const auto continued = execute(state, skip, queue, owner, take(head.current(), "continue actual accepted head"), 5); ++native_submissions;
    check(head.publish(accepted.identity(), continued), "publish prefix1 continuation as a whole");
    // Independent recomputation starts from the retained BASE leases, with
    // target-correct token3 already chosen. No first-run result is rebound.
    const auto independent_first = execute(state, fresh, queue, owner, base, 3); ++native_submissions;
    EXPECT_EQ(image(state, accepted), image(state, independent_first));
    const auto independent_next = execute(state, skip, queue, owner, independent_first, 5); ++native_submissions;
    EXPECT_EQ(image(state, continued), image(state, independent_next));
    EXPECT_NE(read(state.member(continued, kCache)), read(state.member(rejected_tail, kCache)));
    // Prefix2 is valid only when explicitly accepted on its own base branch.
    auto all = take(c::StateHead::create(state.store, base), "independent full-prefix branch");
    check(all.publish(base.identity(), rejected_tail), "explicitly accept prefix2 on its own branch");
    const auto branch = execute(state, skip, queue, owner, take(all.current(), "retained prefix2 branch"), 6); ++native_submissions;
    check(all.publish(rejected_tail.identity(), branch), "publish old branch continuation");
    EXPECT_EQ(state.scalar(branch, kMlaCursor), kBasePosition + 3);
    EXPECT_EQ(state.scalar(branch, kIndexCursor), kBasePosition + 1);
    EXPECT_EQ(image(state, rejected_tail), rejected_bytes);
    EXPECT_EQ(image(state, base), base_bytes);
    // A cancelled multi-member transaction after staging one actual resource
    // cannot expose it or the invalid pending extent through the shared head.
    const auto before_cancel = image(state, take(head.current(), "head before failed candidate"));
    auto cancelled = take(state.store.begin(continued), "failed whole-state candidate");
    check(cancelled.replace(state.entries[kHiddenState], state.member(first, kHiddenState)), "stage candidate hidden only");
    EXPECT_FALSE(cancelled.replace(state.entries[kPending], state.member(first, kHiddenState)).ok());
    check(cancelled.cancel(), "discard incomplete candidate");
    EXPECT_EQ(image(state, take(head.current(), "head after cancellation")), before_cancel);
    state.enabled = false;
    EXPECT_FALSE(state.qualifies(continued)); EXPECT_FALSE(state.qualifies(rejected_tail));
    EXPECT_THROW((void)execute(state, skip, queue, owner, continued, 6), std::runtime_error);
    EXPECT_EQ(image(state, first), first_bytes); EXPECT_EQ(image(state, base), base_bytes);
    EXPECT_FALSE(state.member(first, kCache).try_write());
  }
  check(state.store.collect(), "retire all complete component versions");
  EXPECT_EQ(state.store.stats().versions, 0u); EXPECT_EQ(state.store.stats().drafts, 0u);
  for (const auto *program : {&fresh, &skip, &policy}) {
    EXPECT_EQ(program->outputs.stats().live_blocks, 0u); EXPECT_EQ(program->outputs.stats().active_uses, 0u);
    for (std::size_t i = 0; i < program->parameters.size(); ++i)
      EXPECT_EQ(read(program->parameters[i]), program->recipe.fragment.constant_bytes[i]);
  }
  EXPECT_EQ(native_submissions, 7u);
  ::testing::Test::RecordProperty("actual_submissions", int(native_submissions));
  ::testing::Test::RecordProperty("backend", cuda ? "ordinary CUDA Graph" : "ordinary CPU Graph");
  ::testing::Test::RecordProperty("component_schema", "14 native resource entries plus explicit iteration policy; latent/rawK/rawgate/pools/hidden/qresidual/pending/MLAcursor/indexcursor/poolcount/ringoffset/tailvalid/tailstart/selection");
  ::testing::Test::RecordProperty("scope", "generated primary GGUF/F32 single complete NextN component; fresh K4 closepool->actual I32 sparse MLA/MoE; same-epoch entire-indexer skip; no original checkpoint/full target/KDA/mHC/official FP8cache/natural acceptance");
  ::testing::Test::RecordProperty("prefixes", "0 retained;1 corrected-pending atomic publish and independent base recomputation;2 independent branch; rejected tail/cancel/stale publish/old readonly ownership");
  ::testing::Test::RecordProperty("uncovered", "target KDA/conv/mHC composition; new-iteration accepted-skip catchup/reseed; original cache encodings; vocabulary/natural acceptance");
}
#if defined(HYLE_TEST_GLM_STATE_CUDA)
TEST(GlmMtpStateConsumer, CudaWholeNextNPrefixPublishesAndContinuesWithoutRejectedTail) {
  auto context = take(g::cuda::create_context(), "ordinary CUDA context");
  const auto owner = take(c::StorageOwner::adopt(context, take(c::cuda::MemoryResource::create(
      context, c::cuda::MemoryKind::kDevice), "ordinary CUDA memory")), "retained CUDA allocation domain");
  run(context, owner, true);
}
#endif
#if defined(HYLE_TEST_GLM_STATE_CPU)
struct SystemResource final { m::MemoryResourceRef ref() noexcept { return m::system_resource(); } };
TEST(GlmMtpStateConsumer, CpuWholeNextNPrefixPublishesAndContinuesWithoutRejectedTail) {
  auto context = take(g::cpu::create_context(), "ordinary CPU context");
  const auto owner = take(c::StorageOwner::adopt(context, SystemResource{}), "retained CPU allocation domain");
  run(context, owner, false);
}
#endif
} // namespace
