"""Incremental consumer-only host compilation on the retained BB closure."""
from pathlib import Path
import argparse
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
BB = R / '.scratch/glm-mtp-state-20261022'
spec = importlib.util.spec_from_file_location('catchup_cached', BB / 'build.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
b, c, h = a.b, a.c, a.h
h.S = S
BASE = BB / 'tests-link2'
SOURCES = {'glm-state': R / 'tests/compute_models/glm_mtp_state_consumer_test.cc',
           'dspark-target': R / 'tests/compute_models/dspark_target_binding_test.cc'}

def compile_one(name, attempt):
    old = c.read(BB / 'compile2/glm-state/identity.json')
    if name != 'glm-state':
        old['command'] = [x for x in old['command'] if not x.startswith('/DHYLE_TEST_GLM_STATE_')]
        old['command'] += ['/DHYLE_TEST_DSPARK_TARGET_CPU=1', '/DHYLE_TEST_DSPARK_TARGET_CUDA=1']
    recipe = S / 'recipes' / (name + '.json')
    recipe.parent.mkdir(parents=True, exist_ok=True)
    c.save(recipe, old)
    h.RECIPES[name], h.SOURCES[name] = recipe, SOURCES[name]
    h.compile_one(name, attempt)

def link(attempt, names=None):
    base = c.read(BASE / 'link-plan.json')
    remove = set()
    for item in base['compiled_records']:
        rec = c.read(item['path'])
        if '/tests/' in rec['source']['path'].replace('\\', '/'):
            remove.add(c.key(rec['object']['path']))
    added, compiled = [], []
    for name in (names or SOURCES):
        records = sorted(S.glob(f'compile*/{name}/identity.json'), key=lambda p: int(p.parents[1].name[7:]))
        if not records:
            continue
        path = records[-1]
        rec = c.read(path)
        assert all(b.identity(x['path']) == x for x in [rec['source'], rec['object'], *rec['dependencies']])
        added.append(rec['object']); compiled.append(b.identity(path))
    assert added
    inputs = added + [x for x in base['inputs'] if c.key(x['path']) not in remove]
    assert all(b.identity(x['path']) == x for x in inputs)
    command = [x for x in base['command'] if c.key(x) not in remove and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command[1:1] = [x['path'] for x in added]
    folder = S / f'tests-link{attempt}'
    folder.mkdir(); (folder / 'tmp').mkdir()
    image = folder / 'glm-catchup-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(folder / 'link-plan.json', dict(command=command, inputs=inputs, compiled_records=compiled,
        base=b.identity(BASE / 'link-plan.json'), SDK_builds=0, NVCC_builds=0, shader_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], folder)
    c.execute('link', command, env, folder)
    matched_runtime = S / 'tests-link5/runtime-environment.json'
    runtime = c.read(matched_runtime if matched_runtime.is_file() else BASE / 'runtime-environment.json')
    for item in runtime['staged_dlls']:
        os.link(item['path'], folder / Path(item['path']).name)
    runtime['staged_dlls'] = [b.identity(p) for p in folder.glob('*.dll')]
    c.save(folder / 'runtime-environment.json', runtime)
    c.save(folder / 'ready.json', dict(image=b.identity(image)))
    print('LINKED', image, flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('actions', nargs='+', choices=[*SOURCES, 'link'])
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--only', nargs='+', choices=list(SOURCES))
    args = parser.parse_args()
    for name in args.actions:
        link(args.attempt, args.only) if name == 'link' else compile_one(name, args.attempt)
