"""Retire old native image names; account protected hardlinks explicitly."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
R = S.parents[1]
keep = S / 'tests-link5/glm-catchup-checks.exe'
summary = json.loads((S / 'checks5/summary.json').read_text(encoding='utf-8'))
assert summary['tests'] == 10 and summary['process']['exit'] == 0
assert not any(summary[k] for k in ('failures', 'errors', 'disabled', 'skips'))
assert hashlib.sha256(keep.read_bytes()).hexdigest() == summary['image']['sha256']
parents = [R / '.scratch/glm-mtp-state-20261022/tests-link2',
           *(S / f'tests-link{i}' for i in (1, 2, 3, 4))]
entries, groups = [], {}
for parent in parents:
    assert parent.is_relative_to(R / '.scratch') and parent != keep.parent
    for path in sorted(parent.iterdir()):
        if path.suffix not in ('.exe', '.map'): continue
        raw = path.read_bytes(); st = path.stat()
        item = dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                    file_id=st.st_ino, device=st.st_dev, links=st.st_nlink)
        entries.append(item); groups.setdefault((st.st_dev, st.st_ino), []).append(item)
assert len(entries) == 10
known_reclaimable = sum(items[0]['bytes'] for items in groups.values() if len(items) == items[0]['links'])
protected = [keep, keep.with_suffix('.map'), R / '.scratch/qwen-mtp-next-20261022/hyle-link4/qwen.exe']
assert all(p.is_file() for p in protected)
plan = dict(keep=str(keep), allowed_parents=[str(p) for p in parents], entries=entries,
    removed_path_bytes=sum(x['bytes'] for x in entries),
    known_reclaimable_unique_bytes=known_reclaimable,
    protected=[str(p) for p in protected],
    retained='Final matched-worker image/map; all old source/objects/link inputs/plans/DLLs and original role bodies; actual AV Qwen benchmark image/map.',
    hardlink_note='The final image/map share file IDs with retired link4 names; removing those names does not reclaim their protected physical bytes.')
(S / 'cleanup-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
(S / 'prior-test.ps1').write_bytes((R / 'test.ps1').read_bytes())
script = r'''$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath '.scratch/glm-mtp-catchup-20261022').Path
$scratchPrefix = (Resolve-Path -LiteralPath '.scratch').Path.TrimEnd('\') + '\'
$plan = Get-Content -LiteralPath (Join-Path $taskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$allowed = @($plan.allowed_parents | ForEach-Object { (Resolve-Path -LiteralPath $_).Path })
foreach ($parent in $allowed) {
    if (-not $parent.StartsWith($scratchPrefix, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Outside workspace scratch: $parent" }
}
foreach ($keep in $plan.protected) {
    if (-not (Test-Path -LiteralPath $keep -PathType Leaf)) { throw "Protected reproduction input missing: $keep" }
}
$processes = @(Get-CimInstance Win32_Process)
foreach ($entry in $plan.entries) {
    $target = [System.IO.Path]::GetFullPath($entry.path)
    if ((Split-Path -Parent $target) -notin $allowed -or $target -in $plan.protected) { throw "Unplanned target: $target" }
    if ([System.IO.Path]::GetExtension($target) -notin @('.exe','.map')) { throw "Unexpected cleanup type: $target" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Missing planned file: $target" }
    if ((Get-Item -LiteralPath $target).Length -ne $entry.bytes) { throw "Changed planned size: $target" }
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Changed planned SHA: $target" }
    if (@($processes | Where-Object { $_.ExecutablePath -eq $target }).Count) { throw "Still running: $target" }
}
foreach ($entry in $plan.entries) { Remove-Item -LiteralPath $entry.path -Force }
$result = [pscustomobject]@{
    Removed = @($plan.entries)
    RemovedPathBytes = $plan.removed_path_bytes
    KnownReclaimableUniqueBytes = $plan.known_reclaimable_unique_bytes
    ProtectedInputsRetained = @($plan.protected | ForEach-Object { Test-Path -LiteralPath $_ })
    Retained = $plan.retained
    HardlinkNote = $plan.hardlink_note
}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object RemovedPathBytes, KnownReclaimableUniqueBytes, ProtectedInputsRetained
'''
(R / 'test.ps1').write_text(script, encoding='utf-8', newline='\r\n')
print(json.dumps(dict(files=len(entries), paths=[x['path'] for x in entries],
    removed_path_bytes=plan['removed_path_bytes'], known_reclaimable_unique_bytes=known_reclaimable), indent=2))
