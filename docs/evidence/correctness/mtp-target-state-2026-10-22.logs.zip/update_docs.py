"""Record the actual finite delivery; keep the AV performance window intact."""
from pathlib import Path
import hashlib
import json
S = Path(__file__).resolve().parent
R = S.parents[1]
checks = json.loads((S / 'checks5/summary.json').read_text(encoding='utf-8'))
assert checks['tests'] == 10 and checks['process']['exit'] == 0
assert not any(checks[k] for k in ('failures', 'errors', 'disabled', 'skips'))
assert sum(int(x['properties']['actual_submissions']) for x in checks['cases']) == 130
folder = S / 'docs-before'; folder.mkdir()

def one(text, before, after):
    assert text.count(before) == 1, before[:100]
    return text.replace(before, after, 1)

path = R / 'docs/developer/current-work.md'
old = path.read_bytes(); text = old.decode('utf-8')
performance = text[text.index('## 最新完整性能对比'):]
text = one(text,
'GLM原7角色输入／query链已接实际后继，并补grouped FP8同源数值修复；其它GLM／Q27／Q24适用角色、共享权重和已确认MTP量化接线仍待补。DSpark正式Flash／Pro原角色元数据已知，需接原stage／共享LM和实际target taps；按制品布局、scale与舍入，不由其它格式代签',
'GLM原7角色query链及FP8修复保留；DSpark正式Flash Q8 sidecar的原fc／norm／stage0 KV／KV norm四角色55,724,032B已CPU／CUDA执行。继续补其余stage／共享LM、GLM／Q27／Q24适用角色和已确认MTP量化的冷供给；GLM官方缓存的BF16／Hadamard／E4＋F32 scale及匹配query／scorer仍须接，不能用GGUF F32缓存代签')
text = one(text,
'GLM生成参数的一层NextN已将MLA／raw key／gate／pool／hidden／pending／I32选择／独立游标共14资源及epoch原子发布，CPU／CUDA接受prefix1后续算等有限检查通过。仍需target KDA／conv等状态组合、下一轮已接受skip的indexer追赶与重新选择；不能用单NextN代签完整target。Q27／Q24完整组合和DSpark各stage真实参数的verified-main历史仍待接',
'GLM实际nx进入有界接受记录，跨轮只追赶接受的skip并fresh重选；末层44的KDA／conv／双mHC／FFN／final-norm tap与NextN共20资源＋epoch已在同一Head原子选择、发布和续算，CPU／CUDA有限检查通过。正常draft-extend末接受位置的seed→下一轮step0直接skip、target43 MLA／index历史→44的实际组合仍待接。Q27／Q24完整组合、DSpark各stage真实参数的verified-main历史仍待接')
text = one(text,
'下一步补GLM跨轮indexer追赶／reseed及target状态组合，再接DSpark实际target taps／原stage／共享LM、Q27／Q24剩余角色与已确认MTP量化；最后补必要回归和普通／MTP四臂完整对照，再进入图片。沿现有Graph、权重绑定和状态机制推进；模型、量化与provider范围仍以[总表](../implementation/model-operators.md)为准。',
'下一步补GLM正常draft-extend seed旅程、官方缓存／query／scorer及必要target层间状态组合，继续DSpark各原stage／共享LM与真实target taps、Q27／Q24适用角色和已确认MTP量化；最后做必要回归和普通／MTP完整对照，再进入图片。固定源中正常seed来自NextN draft-extend，不把target43 IDs错接成它的来源。模型、量化与provider范围仍以[总表](../implementation/model-operators.md)为准。')
start = text.index('- **GLM-Flash**：'); end = text.index('\n## 执行顺序与近期进度', start)
text = text[:start] + '''- **GLM-Flash**：[本轮组合与原角色](../evidence/correctness/mtp-target-state-2026-10-22.json)最终10项检查、130次Graph全部通过，其中6项GLM：每端原单轮7次、跨轮追赶14次、target＋NextN组合26次。实际nx接受记录、split cursor、末层KDA／conv／完整mHC／FFN及正确final-norm tap均沿实际租约；partial／all接受、新epoch、独立base重算、旧版本、取消与stale提交通过。上层4H仍生成、未跑45层原模型，官方cache及正常draft-extend seed旅程仍待接。CPU首跑失败来自验证closure的旧constructor／新HC_PRE reader合同混用，已定点匹配原生实现；同一EXE复跑通过，原数值门不变。原输入与FP8修复见[前批证据](../evidence/correctness/glm-mtp-state-2026-10-22.json)。
- **DSpark**：本轮原fc／norm／stage0 wkv／KV norm四角色55,724,032B，在CPU／CUDA各三代9次Graph，实际HC输出→原投影／norm→实际main_x→原512维KV投影／norm；独立逐行Q8解码／FP64参考、零输入、旧结果及只读权重均核。它止于pre-RoPE，HC仍生成，未代签真实target captures、三stage rings或共享LM；[此前自然旅程](../evidence/correctness/mtp-natural-journey-2026-10-22.json)四轮均拒绝proposal，也不代表原模型接受率。
''' + text[end:]
text = one(text,
'当前优先；GLM整层NextN有限状态已CPU／CUDA通过，继续跨轮追赶／target组合、DSpark及Q27／Q24实际角色／codec接线，随后完整性能对照。已有Qwen K1和有限组件不代签全部制品',
'当前优先；GLM跨轮追赶／末target层＋NextN组合、DSpark原四角色均已CPU／CUDA通过。继续正常seed／官方cache及剩余实际角色／状态，再做完整性能对照；有限组件不代签全部制品')
assert text[text.index('## 最新完整性能对比'):] == performance
(folder / 'current-work.md').write_bytes(old); path.write_bytes(text.encode('utf-8'))

path = R / 'docs/implementation/model-operators.md'
old = path.read_bytes(); text = old.decode('utf-8')
text = one(text,
'K4窗口与尾部成套保留；生成参数一层NextN的14资源／epoch及prefix1续算已核，跨轮indexer追赶／target组合、原缓存编码及完整多会话仍待接',
'K4窗口／尾部及接受记录成套保留；NextN跨轮追赶与末target44层组合共20资源／epoch已CPU／CUDA核，正常draft-extend seed／官方cache和其余target状态仍待接')
start = text.index('[GLM本轮NextN状态与grouped FP8修复]'); end = text.index('\n## 25 个 custom descriptor', start)
text = text[:start] + '''[本轮target状态与原角色](../evidence/correctness/mtp-target-state-2026-10-22.json)：Windows CPU／CUDA最终10项、130次Graph通过，无失败／跳过。GLM实际nx进入[2,4096]接受记录及I32 lag计数；skip保整个indexer旧租约／完整2051 IDs含旧tail，MLA与indexer游标分开。accept1拒绝B后fresh2055闭池；accept2只从已接受Head追赶B，再fresh2056产新epoch seed和tail1，实际I32接MLA；独立实际nx输入路径作对照。

末target44层由实际mHC pre→input norm→完整KDA／raw conv history→post→另一mHC pre／norm／MoE／post→mean→model.norm产tap；tap与下一token embedding进入NextN自己的hnorm／EH。target history／matrix／tap／I32 cursor和NextN共20资源＋epoch在同一StateDraft／Head选择prefix，续算与独立base重算一致；mHC不是跨token递归状态。上层4H及参数仍生成，未代签45层原模型、正常draft-extend seed捕获或官方BF16→Hadamard→BF16→E4＋逐行F32 scale cache／query／scorer。固定06992正常seed来自NextN draft-extend的末接受位置，不是target43 IDs；target43 MLA／index历史到44的组合仍保边界。

CPU首次组合失败已定位为验证native closure语义漂移：旧ggml constructor未设置HC_PRE扩展scale，所选新AVX2 reader乘到零。只将验证副本该reader匹配到constructor的原合同；同一个EXE换匹配worker后全部通过。原产品数学、provider和误差门不改；源函数／两worker身份、失败和复跑保在证据。原7角色query链、single／grouped FP8精度修复及数值依据见[前批](../evidence/correctness/glm-mtp-state-2026-10-22.json)。

DSpark正式Flash Q8 sidecar原fc／enc norm／stage0 wkv／KV norm四角色55,724,032B已沿实际producer租约→原投影／norm→实际main_x→原512维KV投影／norm执行，CPU／CUDA各9次Graph；原字节SHA／精确HTTP206、逐行Q8解码／补偿FP64参考、零输入和旧lease均保留。typed role供给保只读owner与dtype／layout；target/session/branch/epoch/position及整组三层资格在bind前检查。GGUF[41,42,43]是converter layer+1，对应官方[40,41,42]。HC仍生成、边界止于pre-RoPE，真实target captures、其余stage／512维rings及共享embedding／LM仍需接；无新TPS或物理内存结论。
''' + text[end:]
(folder / 'model-operators.md').write_bytes(old); path.write_bytes(text.encode('utf-8'))
receipt = dict(final_cases=10, actual_Graph_submissions=130, performance_section_unchanged=True,
    performance_utf8_sha256=hashlib.sha256(performance.encode('utf-8')).hexdigest())
(S / 'docs-update.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
