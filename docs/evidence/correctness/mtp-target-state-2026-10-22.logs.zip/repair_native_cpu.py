"""Match HC_PRE in the retained CPU validation worker to its actual constructor.

Only a copied native ops TU and the tiny current ABI export are compiled.
No product provider patch, tolerance change, SDK tree copy or old-DLL overwrite.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[1]
spec = importlib.util.spec_from_file_location('native_cached', S / 'build.py')
a = importlib.util.module_from_spec(spec); spec.loader.exec_module(a)
b, c = a.b, a.c
N = S / 'native-cpu-hc'
OLD = R / '.scratch/validation/cpu-final-f1/mixed-iq1/source/src/ggml-cpu/ops.cpp'
ACTIVE = R / '.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/ops.cpp'
RECIPES = R / '.scratch/perf-review-2026-10-18/cpu-native-causal/commands.json'

def function(text):
    marker = 'static void ggml_compute_forward_dsv4_hc_pre_f32('
    assert text.count(marker) == 1
    first = text.index(marker); opened = text.index('{', first)
    depth = 1; end = opened + 1
    while depth:
        if text[end] == '{': depth += 1
        elif text[end] == '}': depth -= 1
        end += 1
    return first, end, text[first:end]

def prepare():
    N.mkdir()
    active, old = ACTIVE.read_text(encoding='utf-8'), OLD.read_text(encoding='utf-8')
    first, end, before = function(active)
    _, _, after = function(old)
    assert 'ggml_get_op_params_f32(dst, 0)' in before and 'scale*sum' in before.replace(' ', '')
    assert 'op_params' not in after and '= sum;' in after
    patched = active[:first] + after + active[end:]
    assert patched[:first] == active[:first] and patched[first + len(after):] == active[end:]
    (N / 'ops.cpp').write_text(patched, encoding='utf-8')
    (N / 'hc-pre-before.cc').write_text(before + '\n', encoding='utf-8')
    (N / 'hc-pre-matched.cc').write_text(after + '\n', encoding='utf-8')
    c.save(N / 'adaptation.json', dict(active=b.identity(ACTIVE), selected_pin=b.identity(OLD),
        source=b.identity(N / 'ops.cpp'),
        only_replaced_function='ggml_compute_forward_dsv4_hc_pre_f32',
        constructor='Retained old3-argument constructor does not initialize scale/gated slots; its matching reader has no such extension.',
        other_functions_unchanged=True, product_compatibility_code_added=False,
        full_SDK_builds=0, native_CPU_ops_TUs=1, native_ABI_export_TUs=1))

def compile_and_link():
    recipes = c.read(RECIPES)
    source = N / 'ops.cpp'; obj = N / 'native-avx2.obj'; export = N / 'program-export.obj'
    commands = [recipes[1]['argv'], recipes[2]['argv']]
    for index, command in enumerate(commands):
        command = list(command)
        old_source = Path(command[-2])
        new_source = source if index == 0 else R / 'src/compute_ggml_runtime/cpu_program_export.cc'
        new_object = obj if index == 0 else export
        command[-2] = str(new_source); command[-1] = '/Fo' + str(new_object)
        command += ['/sourceDependencies', str(N / ('ops-dependencies.json' if index == 0 else 'export-dependencies.json'))]
        folder = N / ('compile-ops' if index == 0 else 'compile-export')
        folder.mkdir()
        env, _ = b.environment(command, [str(new_source)], folder)
        c.execute('compile', command, env, folder)
        assert new_object.is_file()
    command = [x for x in recipes[3]['argv'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:'))]
    command = [str(obj) if x.lower().endswith('native-avx2.obj') else
               str(export) if x.lower().endswith('program-export.obj') else x for x in command]
    image = N / 'hyle_ggml_cpu_append_hyca.dll'
    command += ['/OUT:' + str(image), '/MAP:' + str(N / 'module.map'), '/IMPLIB:' + str(N / 'module.lib')]
    inputs = [Path(x) for x in command if Path(x).suffix.lower() in ('.obj', '.lib') and Path(x).is_absolute()]
    assert all(p.is_file() for p in inputs)
    folder = N / 'link'; folder.mkdir(); (folder / 'tmp').mkdir()
    c.save(N / 'link-plan.json', dict(command=command, inputs=[b.identity(p) for p in inputs], source=b.identity(source)))
    env, _ = b.environment(command, [str(p) for p in inputs], folder)
    c.execute('link', command, env, folder)
    assert image.is_file()
    c.save(N / 'ready.json', dict(image=b.identity(image), source=b.identity(source),
        export_source=b.identity(R / 'src/compute_ggml_runtime/cpu_program_export.cc'),
        full_SDK_builds=0, CPU_ops_TUs=1, CPU_export_TUs=1, NVCC_builds=0, shader_builds=0))
    print('MATCHED CPU WORKER', b.identity(image), flush=True)

def relink():
    plan = c.read(N / 'link-plan.json')
    assert all(b.identity(x['path']) == x for x in plan['inputs'])
    assert b.identity(plan['source']['path']) == plan['source']
    folder = N / 'link2'; folder.mkdir(); (folder / 'tmp').mkdir()
    env, _ = b.environment(plan['command'], [x['path'] for x in plan['inputs']], folder)
    c.execute('link', plan['command'], env, folder)
    image = N / 'hyle_ggml_cpu_append_hyca.dll'
    c.save(N / 'ready.json', dict(image=b.identity(image), source=plan['source'],
        export_source=b.identity(R / 'src/compute_ggml_runtime/cpu_program_export.cc'),
        full_SDK_builds=0, CPU_ops_TUs=1, CPU_export_TUs=1, NVCC_builds=0, shader_builds=0))
    print('MATCHED CPU WORKER', b.identity(image), flush=True)

def stage():
    base = S / 'tests-link4'; target = S / 'tests-link5'
    target.mkdir()
    ready = c.read(base / 'ready.json')
    image = target / Path(ready['image']['path']).name
    assert b.identity(ready['image']['path']) == ready['image']
    os.link(ready['image']['path'], image)
    native = c.read(N / 'ready.json')['image']
    runtime = c.read(base / 'runtime-environment.json')
    for item in runtime['staged_dlls']:
        path = Path(item['path'])
        source = Path(native['path']) if path.name == 'hyle_ggml_cpu_append_hyca.dll' else path
        os.link(source, target / path.name)
    c.save(target / 'runtime-environment.json', dict(PATH=str(target) + os.pathsep + runtime['PATH'],
        runtime=runtime['runtime'], staged_dlls=[b.identity(p) for p in target.glob('*.dll')],
        previous=b.identity(base / 'runtime-environment.json'),
        identical_executable=b.identity(Path(ready['image']['path'])), matched_HC_PRE_worker=native,
        full_SDK_builds=0, native_CPU_TUs=2, NVCC_builds=0))
    c.save(target / 'ready.json', dict(image=b.identity(image), native_cpu_contract=b.identity(N / 'ready.json')))
    print('STAGED identical executable with matched CPU worker', b.identity(image), flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('actions', nargs='+', choices=['prepare', 'compile', 'relink', 'stage'])
    args = parser.parse_args()
    for action in args.actions:
        {'prepare': prepare, 'compile': compile_and_link, 'relink': relink, 'stage': stage}[action]()
