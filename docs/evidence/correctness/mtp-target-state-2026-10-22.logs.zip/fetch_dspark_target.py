"""Exact original sidecar roles only; reject whole-file responses before read."""
from pathlib import Path
import hashlib
import json
import time
import urllib.request
S = Path(__file__).resolve().parent
source = json.loads((S / 'review/dspark-original-target-roles.json').read_text(encoding='utf-8'))
assert source['revision'] == 'fbbb5b93fb787c21338159b0af3318bb3f4d9768'
folder = S / 'original-dspark-target'
folder.mkdir(exist_ok=False)
receipt = dict(repository=source['repository'], revision=source['revision'], file=source['file'],
    tensor_table_sha256=source['tensor_table_sha256'], tensor_data_offset=source['tensor_data_offset'],
    whole_file_bytes=source['known_whole_file_bytes'], expected_etag=source['known_etag'],
    whole_file_download_allowed=False, roles=[], complete=False)
def save():
    (folder / 'acquisition.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
save()
for role in source['roles']:
    first, last = role['absolute_range_inclusive']
    count = role['payload_bytes']
    assert last - first + 1 == count
    suffix = '.q8_0' if role['dtype'] == 'Q8_0' else '.f32'
    path = folder / (role['name'] + suffix)
    record = dict(role=role, absolute_range=[first, last], requested_bytes=count,
                  started_unix=time.time(), status='REQUESTING')
    receipt['roles'].append(record); save()
    print('REQUEST', role['name'], count, flush=True)
    try:
        request = urllib.request.Request(source['url'], headers={
            'Range': f'bytes={first}-{last}', 'Accept-Encoding': 'identity',
            'If-Range': source['known_etag'], 'User-Agent': 'hyle-original-role-consumer/1'})
        with urllib.request.urlopen(request, timeout=45) as response:
            record.update(http_status=response.status, content_range=response.headers.get('Content-Range'),
                content_length=response.headers.get('Content-Length'), etag=response.headers.get('ETag'))
            assert response.status == 206 and record['content_range'] == role['expected_content_range'], \
                'Refuse whole file or incorrect range before reading a body'
            assert record['etag'] == source['known_etag'], 'Original file identity changed'
            if record['content_length'] is not None:
                assert int(record['content_length']) == count
            digest = hashlib.sha256(); remaining = count
            with path.open('xb') as output:
                while remaining:
                    chunk = response.read(min(1 << 20, remaining))
                    assert chunk, 'Truncated original role'
                    output.write(chunk); digest.update(chunk); remaining -= len(chunk)
                assert not response.read(1), 'Unexpected bytes after exact role'
        record.update(status='ACQUIRED_EXACT_ROLE', payload=dict(path=str(path), bytes=count, sha256=digest.hexdigest()))
        print('ACQUIRED', role['name'], digest.hexdigest(), flush=True)
    except Exception as error:
        record.update(status='ACQUISITION_FAILED_NO_WHOLE_FILE', error=repr(error))
        raise
    finally:
        record['finished_unix'] = time.time(); save()
receipt['complete'] = True
receipt['payload_bytes'] = sum(x['payload']['bytes'] for x in receipt['roles'])
assert receipt['payload_bytes'] == 55_724_032
save()
print('ALL FOUR EXACT ROLES', receipt['payload_bytes'], flush=True)
