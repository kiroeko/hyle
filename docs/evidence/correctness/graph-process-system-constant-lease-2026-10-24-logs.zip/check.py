from pathlib import Path
import importlib.util,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parents[1]
spec=importlib.util.spec_from_file_location('graph_host_helpers',R/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def execute(command,env,name,timeout=180):
 folder=O/name;folder.mkdir(parents=True,exist_ok=True);(folder/'tmp').mkdir(exist_ok=True)
 env=dict(env,TEMP=str(folder/'tmp'),TMP=str(folder/'tmp'))
 record=dict(command=command,cwd=str(R),started=time.time(),timeout_seconds=timeout);b.save(folder/'command.json',record)
 print('START',name,flush=True)
 with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
  result=subprocess.run(command,cwd=R,env=env,stdout=out,stderr=err,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
 record.update(exit=result.returncode,finished=time.time());b.save(folder/'process.json',record)
 print('END',name,result.returncode,flush=True)
 if result.returncode:raise RuntimeError('Failed; see '+str(folder))
 return record
def native_environment():
 old=b.read(R/'.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/records/graph--executable/identity.json');cc=old['command'][0]
 return b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
def compile_one(name,source,template,env):
 old=b.read(R/template);flags=[];skip=False
 for arg in old['command']:
  if skip:skip=False;continue
  if arg=='/sourceDependencies':skip=True;continue
  if arg.startswith(('/Fo','/Fd')) or arg.lower().endswith('.cc'):continue
  flags.append(arg)
 flags += ['/I'+str(R/'src/graph'),'/I'+str(R/'src/compute'),'/DHYLE_COMPUTE_CPU=1']
 folder=O/name;folder.mkdir(exist_ok=True);obj=folder/(name+'.obj');src=R/source
 frozen=b.identity(src)
 command=[*flags,'/sourceDependencies',str(folder/'dependencies.json'),str(src),'/Fo'+str(obj),'/Fd'+str(folder/(name+'.pdb'))]
 execute(command,env,name,240)
 if b.identity(src)!=frozen:raise ValueError('Source changed while compiling')
 deps=b.read(folder/'dependencies.json')['Data']
 b.save(folder/'identity.json',dict(command=command,source=frozen,object=b.identity(obj),dependencies=[b.identity(p)for p in dict.fromkeys([deps['Source'],*deps['Includes']])]))
 return obj
def build_product():
 native=native_environment();compile_one('executable','src/graph/executable.cc','.scratch/glm-quark-selected-20261024/Q30/graph-integration-preparation/host1/records/graph--executable/identity.json',native.env)
def build_tests(reuse_region=False):
 native=native_environment();template='.scratch/dense-linear-f32-20261024/test-ggml/identity.json'
 objects=[compile_one('test-executable','tests/graph/executable_test.cc',template,native.env)]
 if reuse_region:
  record=b.read(O/'test-region/identity.json')
  for item in (record['source'],record['object'],*record['dependencies']):b.require(item)
  objects.append(Path(record['object']['path']))
 else:objects.append(compile_one('test-region','tests/graph/region_provider_test.cc',template,native.env))
 command=[];original=R/'.scratch/dense-linear-f32-20261024/link-plan.json'
 for arg in b.read(original)['command']:
  if arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:')):continue
  if Path(arg).name in ('test-ggml.obj','test-cublas.obj','test-infer.obj'):continue
  if Path(arg).name=='graph--executable.obj':arg=str(O/'executable/executable.obj')
  command.append(arg)
 image=O/'checks.exe';command += [*[str(p)for p in objects],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 b.save(O/'link-plan.json',dict(command=command,closure=b.identity(original),fresh_TUs=3,SDK_builds=0,HTTP=0))
 execute(command,native.env,'link',150)
 runtime=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3/native-link/hyle_ggml_cpu_gdn_scale_v3.dll'
 if b.identity(runtime)['sha256']!='6652209e40620d8fd4281df984f543e03736661fd0f2a403e62b323e4057fe1f':raise RuntimeError('Wrong CPU runtime identity')
 staged=O/runtime.name
 if not staged.exists():os.link(runtime,staged)
 if b.identity(staged)['sha256']!=b.identity(runtime)['sha256']:raise RuntimeError('Wrong staged CPU runtime')
 ready=b.read(R/'.scratch/dense-linear-f32-20261024/ready.json');b.save(O/'ready.json',dict(image=b.identity(image),PATH=str(O)+os.pathsep+ready['PATH'],native_runtime=b.identity(staged)))
def run():
 ready=b.read(O/'ready.json');b.require(ready['image'])
 filters='GraphCompile.ProcessSystemConstantLease*:GraphCompile.OwnerlessConstantLease*:GraphCompile.ReadonlyResourceFamilyRequiresActualSourceAuthority:GraphRegions.ConstantViewPreparationKeepsEachPhysicalRootOwner:GraphRegions.OwnerlessSystemMaterializationRetainsLeaseUntilNativeRetirement:GraphRegions.UnknownMaterializationObservationRetainsOwnersUntilNativeRetirement:GraphRegions.QueuedMaterializationRejectsRawSourceBeforeCopy'
 execute([ready['image']['path'],'--gtest_filter='+filters,'--gtest_output=json:'+str(O/'tests.json')],dict(os.environ,PATH=ready['PATH']),'run',150)
 print((O/'run/stdout.log').read_text(),flush=True)
 b.save(O/'result.json',dict(tests=b.identity(O/'tests.json'),source=b.identity(R/'src/graph/executable.cc'),fresh_TUs=3,SDK_builds=0,HTTP=0,scope='Ownerless exact process-system ReadLease constants; Borrow/Materialize, exact allocator and view rejection, native queued retirement retention. Not full SDK or model test.'))
if __name__=='__main__':
 if sys.argv[1]in('product','all'):build_product()
 if sys.argv[1]in('tests','all'):build_tests()
 if sys.argv[1]=='refresh':build_tests(reuse_region=True)
 if sys.argv[1]in('run','all'):run()
