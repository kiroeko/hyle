"""Root-authorized CPU fixture correction only; one test TU and one group."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_batch',W/'build.py')
batch=importlib.util.module_from_spec(spec);spec.loader.exec_module(batch)
b,m,R=batch.b,batch.m,batch.R
def build():
    assert not (W/'ready2.json').exists()
    ready=b.read(W/'ready.json');plan=b.read(W/'plan.json')
    unit=next(x for x in plan['units'] if x['name']=='cpu-test')
    source=b.pin(unit['source']['path']);assert source['sha256']=='6e04b256970b89889e3967b30528fc67cf8a2ad412346537e82f5fbb031cab54'
    out=W/'compile2/cpu-test';command=m.command(Path(unit['recipe']['path']),Path(source['path']),out)
    for include in [R/'src/compute_provider_ggml_cuda',R/'src/graph']:
        if '/I'+str(include) not in command:command.insert(1,'/I'+str(include))
    frozen=m.c.closure([source['path']],[Path(unit['recipe']['path'])]);b.save(W/'cpu2-freeze.json',frozen)
    b.save(W/'cpu2-plan.json',dict(source=source,before_source=unit['source'],command=command,
      reason='Test supplies caller-owned published Gather output, preserving its actual GraphOutput retirement gate.',
      reused_ready=b.pin(W/'ready.json'),CXX_TUs=1,images=1))
    h,env=batch.environment(plan);process=h.execute(command,env,out,timeout=180)
    dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    b.save(out/'actual-dependencies.json',actual);obj=b.pin(out/'unit.obj')
    before=next(x for x in ready['compiled'] if x['name']=='cpu-test');image=W/'bin2/slot-source-fallback-test.exe'
    args=[];changed=0
    for arg in b.read(W/'link/command.json')['command']:
        if b.key(arg)==b.key(before['object']['path']):arg=obj['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed==1;image.parent.mkdir(parents=True,exist_ok=True)
    inputs=b.read(ready['inputs']['path'])
    for row in inputs:b.exact(row)
    linked=h.execute(args,env,W/'link2',timeout=120)
    b.save(W/'link2-inputs.json',[obj if b.key(x['path'])==b.key(before['object']['path']) else x for x in inputs])
    rt=b.read(ready['runtime']['path']);native=rt['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;assert not alias.exists();os.link(native['path'],alias)
    rt['native_cpu_hardlink']=b.pin(alias);b.save(W/'runtime2.json',rt)
    record=dict(name='cpu-test',source=source,object=obj,process=process,actual_dependencies=b.pin(out/'actual-dependencies.json'))
    ready['compiled']=[record if x['name']=='cpu-test' else x for x in ready['compiled']]
    ready.update(image=b.pin(image),link=linked,inputs=b.pin(W/'link2-inputs.json'),runtime=b.pin(W/'runtime2.json'),original_ready=b.pin(W/'ready.json'),test_retry=b.pin(W/'cpu2-plan.json'))
    b.save(W/'ready2.json',ready);print('READY2',json.dumps(b.pin(W/'ready2.json')),flush=True)
def run():
    ready=b.read(W/'ready2.json');b.exact(ready['image']);h,env=batch.environment(b.read(W/'plan.json'));env['PATH']=b.read(ready['runtime']['path'])['PATH']
    xml=W/'results2-cpu.xml'
    process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter=GraphSlotsExecution.*','--gtest_output=xml:'+str(xml)],env,W/'run2-cpu',timeout=90)
    root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
    assert int(root.attrib['tests'])==7 and int(root.attrib['failures'])==0 and len(cases)==7
    b.save(W/'summary-cpu2.json',dict(status='SEVEN_CPU_SLOT_TESTS_PASS',process=process,tests=[x.attrib for x in cases],results=b.pin(xml),ready=b.pin(W/'ready2.json')))
    print('SUMMARY',json.dumps(b.pin(W/'summary-cpu2.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
