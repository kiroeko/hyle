"""Actual default CCCL projected-reader fix plus diagnostic test; two CXX TUs."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_batch',W/'build.py')
batch=importlib.util.module_from_spec(spec);spec.loader.exec_module(batch)
b,m,R=batch.b,batch.m,batch.R
def build():
    assert not (W/'ready5.json').exists()
    ready=b.read(W/'ready4.json');plan=b.read(W/'plan.json')
    inputs=b.read(ready['inputs']['path']);assert len(inputs)==226
    cccl=next(x for x in inputs if 'compute_provider_cuda--collectives_provider_cc' in x['path'])
    old_test=next(x for x in ready['compiled'] if x['name']=='cuda-test')
    specs=[('cccl','src/compute_provider_cuda/collectives_provider.cc',cccl,
            '694220146d4229d6bc042aeb870b8e3b31296bac318fda52c06bfaa42ce18c66'),
           ('cuda-test','tests/graph_provider_ggml_cuda/indexed_state_test.cc',old_test['object'],
            'bdf985eb57091f0e9fc0ef903bad6f4e3bb2cf9ab256ae66aa7f1ade4d013273')]
    units=[]
    for name,source,old,expected in specs:
        pin=b.pin(R/source);assert pin['sha256']==expected,source
        recipe=Path(old['path']).parent/'command.json'
        command=m.command(recipe,Path(pin['path']),W/'compile5'/name)
        if name=='cccl' and '/I'+str(R/'src/compute') not in command:command.insert(1,'/I'+str(R/'src/compute'))
        units.append(dict(name=name,source=pin,before=old,recipe=b.pin(recipe),command=command))
    recipes=W/'cccl5-recipes.json';b.save(recipes,dict(command=[a for u in units for a in u['command']]))
    frozen=m.c.closure([u['source']['path'] for u in units],[recipes]);b.save(W/'cccl5-freeze.json',frozen)
    b.save(W/'cccl5-plan.json',dict(units=units,source_freeze=b.pin(W/'cccl5-freeze.json'),reused_ready=b.pin(W/'ready4.json'),
      reason='Default plain Gather selects CCCL. Give that actual original prepared reader its truthful projected-input capability; test reports selected provider without overriding route.',
      CXX_TUs=2,images=1,NVCC_SDK_model_perf_downloads=0))
    h,env=batch.environment(plan);objects={};records=[]
    for unit in units:
        out=W/'compile5'/unit['name'];process=h.execute(unit['command'],env,out,timeout=180)
        dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
        b.save(out/'actual-dependencies.json',actual);obj=b.pin(out/'unit.obj');objects[b.key(unit['before']['path'])]=obj
        records.append(dict(name=unit['name'],source=unit['source'],object=obj,process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:b.exact(row)
    image=W/'bin5/slot-source-fallback-test.exe';args=[];changed=0
    for arg in b.read(W/'link4/command.json')['command']:
        if b.key(arg) in objects:arg=objects[b.key(arg)]['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed==2;image.parent.mkdir(parents=True,exist_ok=True)
    for row in inputs:b.exact(row)
    linked=h.execute(args,env,W/'link5',timeout=120)
    b.save(W/'link5-inputs.json',[objects.get(b.key(x['path']),x) for x in inputs])
    rt=b.read(ready['runtime']['path']);native=rt['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;assert not alias.exists();os.link(native['path'],alias)
    rt['native_cpu_hardlink']=b.pin(alias);b.save(W/'runtime5.json',rt)
    test_record=next(x for x in records if x['name']=='cuda-test')
    ready['compiled']=[test_record if x['name']=='cuda-test' else x for x in ready['compiled']]
    ready['compiled'].append(next(x for x in records if x['name']=='cccl'))
    ready.update(image=b.pin(image),link=linked,inputs=b.pin(W/'link5-inputs.json'),runtime=b.pin(W/'runtime5.json'),original_ready=b.pin(W/'ready4.json'),cccl_fix=b.pin(W/'cccl5-plan.json'))
    b.save(W/'ready5.json',ready);print('READY5',json.dumps(b.pin(W/'ready5.json')),flush=True)
def run():
    ready=b.read(W/'ready5.json');b.exact(ready['image']);h,env=batch.environment(b.read(W/'plan.json'));env['PATH']=b.read(ready['runtime']['path'])['PATH']
    groups=[]
    for name,filter in [('fallback','GgmlCudaIndexedStateGraph.EscapingGatherUsesCheckedProjectedFallback'),('cuda-store','GraphSlotsCudaExecution.*')]:
        xml=W/('results5-'+name+'.xml')
        process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+filter,'--gtest_output=xml:'+str(xml)],env,W/('run5-'+name),timeout=90)
        root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
        assert int(root.attrib['tests'])==1 and int(root.attrib['failures'])==0 and len(cases)==1
        groups.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml),ready=b.pin(W/'ready5.json')))
        b.save(W/'partial-results5.json',groups);print('PASSED',name,flush=True)
    cpu=b.read(W/'partial-results3.json');assert len(cpu)==1 and cpu[0]['name']=='cpu';cpu[0]['ready']=b.pin(W/'ready3.json')
    fused=[x for x in ET.parse(W/'results3-indexed.xml').getroot().findall('./testsuite/testcase') if x.attrib['name']!='EscapingGatherUsesCheckedProjectedFallback']
    assert len(fused)==2 and all(not list(x) and x.attrib['result']=='completed' for x in fused)
    groups=cpu+[dict(name='indexed-fusion',process=b.read(W/'run3-indexed/process.json'),tests=[x.attrib for x in fused],
      results=b.pin(W/'results3-indexed.xml'),ready=b.pin(W/'ready3.json'),
      note='Two cases passed in a process whose separate fallback case failed. They used the prior ggml leaf object and do not validate its later projected-input extension.')]+groups
    b.save(W/'summary.json',dict(status='ELEVEN_SLOT_SOURCE_FALLBACK_TESTS_PASS',tests=11,failures=0,groups=groups,ready=b.pin(W/'ready5.json'),
      distinct_CXX_TUs=7,CXX_compile_attempts=11,linked_images=5,native_test_processes=8,
      observation_rule='CPU7 and fused2 from ready3; actual default checked Gather fallback1 and CUDAwriter1 from ready5. Not all11 rerun on final image.',
      ggml_leaf_projected_extension_direct_path_tested=False,
      SDK_NVCC_engine_perf_downloads=0))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
