"""Five frozen CXX TUs, one retained native closure, eleven focused tests."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent;R=W.parents[1]
B=R/'.scratch/inference-indexed-state-20261027/graph-integration'
spec=importlib.util.spec_from_file_location('passed_indexed',B.parent/'graph-build.py')
cached=importlib.util.module_from_spec(spec);spec.loader.exec_module(cached)
m,b=cached.m,cached.b
GROUPS=[('cpu','GraphSlotsExecution.*',7),('indexed','GgmlCudaIndexedStateGraph.*',3),
        ('cuda-store','GraphSlotsCudaExecution.*',1)]
EXPECTED={'src/graph/slots_region.cc':'f2fdde34dcf26f117e676c4e5860e10dda91f2228478ec13bb5fe908ef347ab5',
 'include/hyle/graph/slots.h':'0c4cdced8dc49b0576e2876b76baaf60a0f9c92c077c92625b797166f49473d1',
 'tests/graph/slots_execution_test.cc':'d56e398c1b62ebb0969154849d4a101412ddd4c4518013dfd2276adf73a81b6f',
 'src/graph_provider_ggml_cuda/ggml_cuda_region.cc':'bfc3de90b84b5048feba1464a9ad1e1c126ca532bbb583e1270efce6130ebdc4',
 'tests/graph_provider_ggml_cuda/indexed_state_test.cc':'6ae93fb26143c2409965a1dafab14dabbb2df883d09e1748b1dfd6632eec3b36'}
def plan():
    assert not (W/'plan.json').exists()
    for path,expected in EXPECTED.items():assert b.pin(R/path)['sha256']==expected,path
    ready=b.read(B/'ready5.json');old={x['name']:x for x in ready['compiled']}
    cpu_ready=b.read(R/'.scratch/inference-slot-store-20261027/attempt2/ready.json')
    cpu=next(x for x in cpu_ready['compiled'] if x['name']=='cpu-test')
    inputs=b.read(ready['inputs']['path']);assert len(inputs)==226
    for row in inputs:b.exact(row)
    units=[]
    for name,source,before in [('resources','src/graph/resources.cc',old['resources']),
      ('store','src/graph/slots_region.cc',old['store']),
      ('graph-provider','src/graph_provider_ggml_cuda/ggml_cuda_region.cc',old['graph-provider']),
      ('cpu-test','tests/graph/slots_execution_test.cc',cpu),
      ('cuda-test','tests/graph_provider_ggml_cuda/indexed_state_test.cc',old['test'])]:
        assert sum(b.key(x['path'])==b.key(before['object']['path']) for x in inputs)==1,name
        recipe=Path(before['object']['path']).parent/'command.json'
        command=m.command(recipe,R/source,W/'compile'/name)
        for include in [R/'src/compute_provider_ggml_cuda',R/'src/graph']:
            if '/I'+str(include) not in command:command.insert(1,'/I'+str(include))
        assert all(x in command for x in ['/O2','/W4','/WX','/DHYLE_STATIC'])
        units.append(dict(name=name,source=b.pin(R/source),recipe=b.pin(recipe),before=before['object'],command=command))
    recipes=W/'canonical-recipes.json';b.save(recipes,dict(command=[arg for x in units for arg in x['command']]))
    frozen=m.c.closure([x['source']['path'] for x in units],[recipes]);b.save(W/'source-freeze.json',frozen)
    b.save(W/'plan.json',dict(status='SOURCE_FROZEN_NOT_BUILT',units=units,source_freeze=b.pin(W/'source-freeze.json'),
      source_expected=EXPECTED,baseline=dict(ready=b.pin(B/'ready5.json'),inputs=ready['inputs'],
      runtime=ready['runtime'],command=b.pin(B/'link4/command.json')),reused_native=ready['reused_native'],
      groups=GROUPS,CXX_TUs=5,images=1,SDK_NVCC_engine_perf_downloads=0,
      compatibility='New SourceBinding/prepare and RegionAccess input-fact declarations are additive. Existing public and native layouts unchanged. Native/Compute objects and current indexed kernels reused. CUDA Artifact changes are local to its recompiled TU; Store owner changes stay in its pimpl.',
      CMake=[b.pin(R/'tests/graph/CMakeLists.txt'),b.pin(R/'tests/graph_provider_ggml_cuda/CMakeLists.txt')]))
    print('PLAN',json.dumps(b.pin(W/'plan.json')),flush=True)
def environment(p):
    h=b.helper();cl=p['units'][0]['command'][0]
    return h,h.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cl,'CMAKE_CXX_COMPILER':cl,'CMAKE_GENERATOR':'Ninja'},backends=()).env
def build():
    p=b.read(W/'plan.json');assert not (W/'compile').exists() and not (W/'ready.json').exists()
    frozen=b.read(p['source_freeze']['path']);own={b.key(x['path']):x for x in frozen}
    for row in frozen:b.exact(row)
    for row in b.read(p['baseline']['inputs']['path']):b.exact(row)
    h,env=environment(p);objects={};results=[]
    for unit in p['units']:
        out=W/'compile'/unit['name'];process=h.execute(unit['command'],env,out,timeout=180)
        dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
        for row in actual:
            q=Path(row['path'])
            if q.is_relative_to(R) and not q.is_relative_to(R/'.scratch'):assert own[b.key(q)]['sha256']==row['sha256'],str(q)
        b.save(out/'actual-dependencies.json',actual);objects[unit['name']]=b.pin(out/'unit.obj')
        results.append(dict(name=unit['name'],source=unit['source'],object=objects[unit['name']],process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:b.exact(row)
        print('COMPILED',unit['name'],json.dumps(process),flush=True)
    replacements={b.key(u['before']['path']):objects[u['name']] for u in p['units']}
    image=W/'bin/slot-source-fallback-test.exe';args=[];changed=0
    for arg in b.read(p['baseline']['command']['path'])['command']:
        if b.key(arg) in replacements:arg=replacements[b.key(arg)]['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        elif arg.upper().startswith('/MAP:'):continue
        args.append(arg)
    assert changed==5;image.parent.mkdir(parents=True,exist_ok=True)
    linked=h.execute(args,env,W/'link',timeout=120)
    b.save(W/'link-inputs.json',[replacements.get(b.key(x['path']),x) for x in b.read(p['baseline']['inputs']['path'])])
    rt=b.read(p['baseline']['runtime']['path']);native=rt['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;assert not alias.exists();os.link(native['path'],alias)
    rt['native_cpu_hardlink']=b.pin(alias);b.save(W/'runtime.json',rt)
    b.save(W/'ready.json',dict(status='BUILT_NOT_RUN',image=b.pin(image),compiled=results,link=linked,
      inputs=b.pin(W/'link-inputs.json'),runtime=b.pin(W/'runtime.json'),plan=b.pin(W/'plan.json'),reused_native=p['reused_native']))
    print('READY',json.dumps(b.pin(W/'ready.json')),flush=True)
def run(cuda_only=False):
    p=b.read(W/'plan.json');ready=b.read(W/'ready.json');b.exact(ready['image'])
    h,env=environment(p);env['PATH']=b.read(ready['runtime']['path'])['PATH'];groups=[]
    for name,filter,count in p['groups'][1 if cuda_only else 0:]:
        xml=W/('results-'+name+'.xml')
        process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+filter,'--gtest_output=xml:'+str(xml)],env,W/('run-'+name),timeout=90)
        root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
        assert int(root.attrib['tests'])==count and int(root.attrib['failures'])==0
        assert len(cases)==count and all(x.attrib.get('status')=='run' and not list(x) for x in cases)
        groups.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml)))
        b.save(W/('partial-cuda-results.json' if cuda_only else 'partial-results.json'),groups);print('PASSED',name,count,flush=True)
    target='summary-cuda.json' if cuda_only else 'summary.json'
    b.save(W/target,dict(status='FOUR_CUDA_TESTS_PASS' if cuda_only else 'ELEVEN_SLOT_SOURCE_FALLBACK_TESTS_PASS',tests=4 if cuda_only else 11,failures=0,groups=groups,
      ready=b.pin(W/'ready.json'),compiled_TUs=5,images=1,SDK_NVCC_engine_perf_downloads=0,scope=p['compatibility']))
    print('SUMMARY',json.dumps(b.pin(W/target)),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['plan']:plan()
    elif sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    elif sys.argv[1:]==['run-cuda']:run(True)
    else:print(__doc__)
