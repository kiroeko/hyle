"""Only the two root-authorized final test fixtures; product objects unchanged."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_batch',W/'build.py')
batch=importlib.util.module_from_spec(spec);spec.loader.exec_module(batch)
b,m,R=batch.b,batch.m,batch.R
EXPECTED={'cpu-test':'dc46f17be60ed81fcf443cfd1ea5175a81adf8d613594026b69a76bb2937d1e8',
          'cuda-test':'6d9436f1d1e6b4ba769b609f25a75d334d9b31f66a93644e36ecad0149052496'}
def build():
    assert not (W/'ready3.json').exists()
    ready=b.read(W/'ready2.json');plan=b.read(W/'plan.json');units=[]
    for name in ['cpu-test','cuda-test']:
        original=next(x for x in plan['units'] if x['name']==name)
        before=next(x for x in ready['compiled'] if x['name']==name)
        source=b.pin(original['source']['path']);assert source['sha256']==EXPECTED[name]
        recipe=Path(before['object']['path']).parent/'command.json'
        command=m.command(recipe,Path(source['path']),W/'compile3'/name)
        units.append(dict(name=name,source=source,before=before['object'],recipe=b.pin(recipe),command=command))
    recipes=W/'fixtures3-recipes.json';b.save(recipes,dict(command=[a for u in units for a in u['command']]))
    frozen=m.c.closure([u['source']['path'] for u in units],[recipes]);b.save(W/'fixtures3-freeze.json',frozen)
    b.save(W/'fixtures3-plan.json',dict(units=units,source_freeze=b.pin(W/'fixtures3-freeze.json'),reused_ready=b.pin(W/'ready2.json'),
      reason='CPU negative first prepares legally before replacing source IDs. CUDA restores original exact fused graph (dummy nodes were not pruned) and prints fallback bind Status.',CXX_TUs=2,images=1))
    h,env=batch.environment(plan);objects={};records=[]
    for u in units:
        out=W/'compile3'/u['name'];process=h.execute(u['command'],env,out,timeout=180)
        dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
        b.save(out/'actual-dependencies.json',actual);obj=b.pin(out/'unit.obj');objects[b.key(u['before']['path'])]=obj
        records.append(dict(name=u['name'],source=u['source'],object=obj,process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
        for row in frozen:b.exact(row)
    image=W/'bin3/slot-source-fallback-test.exe';args=[];changed=0
    for arg in b.read(W/'link2/command.json')['command']:
        if b.key(arg) in objects:arg=objects[b.key(arg)]['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed==2;image.parent.mkdir(parents=True,exist_ok=True)
    inputs=b.read(ready['inputs']['path'])
    for row in inputs:b.exact(row)
    linked=h.execute(args,env,W/'link3',timeout=120)
    b.save(W/'link3-inputs.json',[objects.get(b.key(x['path']),x) for x in inputs])
    rt=b.read(ready['runtime']['path']);native=rt['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;assert not alias.exists();os.link(native['path'],alias)
    rt['native_cpu_hardlink']=b.pin(alias);b.save(W/'runtime3.json',rt)
    by_name={x['name']:x for x in records};ready['compiled']=[by_name.get(x['name'],x) for x in ready['compiled']]
    ready.update(image=b.pin(image),link=linked,inputs=b.pin(W/'link3-inputs.json'),runtime=b.pin(W/'runtime3.json'),original_ready=b.pin(W/'ready2.json'),test_retry=b.pin(W/'fixtures3-plan.json'))
    b.save(W/'ready3.json',ready);print('READY3',json.dumps(b.pin(W/'ready3.json')),flush=True)
def run():
    plan=b.read(W/'plan.json');ready=b.read(W/'ready3.json');b.exact(ready['image'])
    h,env=batch.environment(plan);env['PATH']=b.read(ready['runtime']['path'])['PATH'];groups=[]
    for name,filter,count in plan['groups']:
        xml=W/('results3-'+name+'.xml')
        process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+filter,'--gtest_output=xml:'+str(xml)],env,W/('run3-'+name),timeout=90)
        root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
        assert int(root.attrib['tests'])==count and int(root.attrib['failures'])==0 and len(cases)==count
        groups.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml)))
        b.save(W/'partial-results3.json',groups);print('PASSED',name,count,flush=True)
    b.save(W/'summary.json',dict(status='ELEVEN_SLOT_SOURCE_FALLBACK_TESTS_PASS',tests=11,failures=0,groups=groups,ready=b.pin(W/'ready3.json'),
      distinct_CXX_TUs=5,CXX_compile_attempts=8,linked_images=3,SDK_NVCC_engine_perf_downloads=0,
      scope='CPU exact dense/padded source-Gather association, checked CUDA projected fallback, retained route6 fusion and adjacent writer-only Store.'))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1:]==['build']:build()
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
