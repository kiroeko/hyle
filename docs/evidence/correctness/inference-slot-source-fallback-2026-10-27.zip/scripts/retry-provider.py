"""One leaf-access provider correction; reuse all other passed objects."""
from pathlib import Path
import importlib.util,json,os,sys,xml.etree.ElementTree as ET
sys.dont_write_bytecode=True;sys.stdout.reconfigure(encoding='utf-8')
W=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_batch',W/'build.py')
batch=importlib.util.module_from_spec(spec);spec.loader.exec_module(batch)
b,m,R=batch.b,batch.m,batch.R
def build(expected):
    assert len(expected)==64 and not (W/'ready4.json').exists()
    ready=b.read(W/'ready3.json');plan=b.read(W/'plan.json')
    baseline=b.read(R/'.scratch/inference-indexed-state-20261027/graph-integration/ready5.json')
    old=next(x for x in baseline['compiled'] if x['name']=='provider')
    source=b.pin(R/'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc');assert source['sha256']==expected
    recipe=Path(old['object']['path']).parent/'command.json';out=W/'compile4/provider'
    command=m.command(recipe,Path(source['path']),out)
    frozen=m.c.closure([source['path']],[recipe]);b.save(W/'provider4-freeze.json',frozen)
    b.save(W/'provider4-plan.json',dict(source=source,before=old,recipe=b.pin(recipe),command=command,
      source_freeze=b.pin(W/'provider4-freeze.json'),reused_ready=b.pin(W/'ready3.json'),CXX_TUs=1,images=1,
      reason='Actual ordinary checked Gather leaf was selected but lacked its projected-read access extension. No Node/Recipe/native ABI or arithmetic change.'))
    h,env=batch.environment(plan);process=h.execute(command,env,out,timeout=180)
    dep=b.read(out/'dependencies.json')['Data'];actual=[b.pin(x) for x in dict.fromkeys([dep['Source'],*dep['Includes']])]
    b.save(out/'actual-dependencies.json',actual);obj=b.pin(out/'unit.obj')
    image=W/'bin4/slot-source-fallback-test.exe';args=[];changed=0
    for arg in b.read(W/'link3/command.json')['command']:
        if b.key(arg)==b.key(old['object']['path']):arg=obj['path'];changed+=1
        elif arg.upper().startswith('/OUT:'):arg='/OUT:'+str(image)
        elif arg.upper().startswith('/PDB:'):arg='/PDB:'+str(image.with_suffix('.pdb'))
        elif arg.upper().startswith('/IMPLIB:'):arg='/IMPLIB:'+str(image.with_suffix('.lib'))
        args.append(arg)
    assert changed==1;image.parent.mkdir(parents=True,exist_ok=True)
    inputs=b.read(ready['inputs']['path'])
    for row in inputs:b.exact(row)
    linked=h.execute(args,env,W/'link4',timeout=120)
    b.save(W/'link4-inputs.json',[obj if b.key(x['path'])==b.key(old['object']['path']) else x for x in inputs])
    rt=b.read(ready['runtime']['path']);native=rt['native_cpu'];b.exact(native)
    alias=image.parent/Path(native['path']).name;assert not alias.exists();os.link(native['path'],alias)
    rt['native_cpu_hardlink']=b.pin(alias);b.save(W/'runtime4.json',rt)
    ready['compiled'].append(dict(name='provider',source=source,object=obj,process=process,actual_dependencies=b.pin(out/'actual-dependencies.json')))
    ready.update(image=b.pin(image),link=linked,inputs=b.pin(W/'link4-inputs.json'),runtime=b.pin(W/'runtime4.json'),original_ready=b.pin(W/'ready3.json'),provider_fix=b.pin(W/'provider4-plan.json'))
    b.save(W/'ready4.json',ready);print('READY4',json.dumps(b.pin(W/'ready4.json')),flush=True)
def run():
    ready=b.read(W/'ready4.json');b.exact(ready['image']);h,env=batch.environment(b.read(W/'plan.json'));env['PATH']=b.read(ready['runtime']['path'])['PATH']
    groups=[]
    for name,filter in [('fallback','GgmlCudaIndexedStateGraph.EscapingGatherUsesCheckedProjectedFallback'),('cuda-store','GraphSlotsCudaExecution.*')]:
        xml=W/('results4-'+name+'.xml')
        process=h.execute([ready['image']['path'],'--gtest_color=no','--gtest_filter='+filter,'--gtest_output=xml:'+str(xml)],env,W/('run4-'+name),timeout=90)
        root=ET.parse(xml).getroot();cases=root.findall('./testsuite/testcase')
        assert int(root.attrib['tests'])==1 and int(root.attrib['failures'])==0 and len(cases)==1
        groups.append(dict(name=name,process=process,tests=[x.attrib for x in cases],results=b.pin(xml)))
        b.save(W/'partial-results4.json',groups);print('PASSED',name,flush=True)
    cpu=b.read(W/'partial-results3.json');assert len(cpu)==1 and cpu[0]['name']=='cpu'
    tree=ET.parse(W/'results3-indexed.xml').getroot()
    fused=[x for x in tree.findall('./testsuite/testcase') if x.attrib['name']!='EscapingGatherUsesCheckedProjectedFallback']
    assert len(fused)==2 and all(not list(x) and x.attrib['result']=='completed' for x in fused)
    groups=cpu+[dict(name='indexed-fusion',process=b.read(W/'run3-indexed/process.json'),tests=[x.attrib for x in fused],
      results=b.pin(W/'results3-indexed.xml'),note='These two cases passed in the process whose other fallback case failed; the fallback was corrected and checked separately.')]+groups
    b.save(W/'summary.json',dict(status='ELEVEN_SLOT_SOURCE_FALLBACK_TESTS_PASS',tests=11,failures=0,groups=groups,ready=b.pin(W/'ready4.json'),
      distinct_CXX_TUs=6,CXX_compile_attempts=9,linked_images=4,
      observation_rule='CPU7 and fused2 from ready3; fallback1 and CUDAwriter1 from ready4. Only projected-read provider extension object differs; not all11 rerun in final image.',
      SDK_NVCC_engine_perf_downloads=0))
    print('SUMMARY',json.dumps(b.pin(W/'summary.json')),flush=True)
if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='build':build(sys.argv[2])
    elif sys.argv[1:]==['run']:run()
    else:print(__doc__)
