"""Archive this bounded source-association/fallback batch; no native action."""
from pathlib import Path
import hashlib,json,sys,zipfile
W=Path(__file__).resolve().parent;R=W.parents[1]
OUT=R/'docs/evidence/correctness/inference-slot-source-fallback-2026-10-27'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def pin(p):
    p=Path(p);data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=sha(data))
def publish():
    ready=read(W/'ready5.json');summary=read(W/'summary.json');members={}
    def add(p,name=None,expected=None):
        p=Path(p);data=p.read_bytes()
        if expected:assert sha(data)==expected,str(p)
        if name is None:name='records/'+p.relative_to(W).as_posix()
        assert name not in members,name
        members[name]=data
    source_pins={}
    for unit in ready['compiled']:
        for row in read(unit['actual_dependencies']['path']):source_pins[row['path'].lower()]=row
        source_pins[unit['source']['path'].lower()]=unit['source']
    sources=['include/hyle/graph/slots.h','include/hyle/graph/detail/region_access.h',
      'src/graph/resources.cc','src/graph/slots_region.h','src/graph/slots_region.cc',
      'src/graph_provider_ggml_cuda/ggml_cuda_region.cc',
      'src/compute_provider_ggml_cuda/ggml_cuda_provider.cc',
      'src/compute_provider_cuda/collectives_provider.cc','src/compute/operation_cold.h',
      'tests/graph/slots_execution_test.cc','tests/graph_provider_ggml_cuda/indexed_state_test.cc']
    for source in sources:
        p=R/source;add(p,'source/'+source,source_pins[str(p).lower()]['sha256'])
    for row in read(W/'plan.json')['CMake']:
        p=Path(row['path']);add(p,'source/'+p.relative_to(R).as_posix(),row['sha256'])
    # This unchanged source explains the default route; not a newly built TU.
    add(R/'src/compute_route_cuda/default_policy.cc','context-only/src/compute_route_cuda/default_policy.cc')
    for name in ['publish.py','build.py','retry-cpu.py','retry-fixtures.py','retry-provider.py','retry-cccl.py']:
        add(W/name,'scripts/'+name)
    for name in ['preparation.json','plan.json','source-freeze.json','canonical-recipes.json',
      'cpu2-plan.json','cpu2-freeze.json','fixtures3-plan.json','fixtures3-freeze.json','fixtures3-recipes.json',
      'provider4-plan.json','provider4-freeze.json','cccl5-plan.json','cccl5-freeze.json','cccl5-recipes.json',
      'ready.json','ready2.json','ready3.json','ready4.json','ready5.json',
      'link-inputs.json','link2-inputs.json','link3-inputs.json','link4-inputs.json','link5-inputs.json',
      'runtime.json','runtime2.json','runtime3.json','runtime4.json','runtime5.json',
      'summary-cpu2.json','summary.json','partial-results3.json','partial-results5.json',
      'results-cpu.xml','results-indexed.xml','results2-cpu.xml','results3-cpu.xml','results3-indexed.xml',
      'results4-fallback.xml','results5-fallback.xml','results5-cuda-store.xml']:
        add(W/name)
    compile_dirs=['compile/'+x for x in ['resources','store','graph-provider','cpu-test','cuda-test']]
    compile_dirs+=['compile2/cpu-test','compile3/cpu-test','compile3/cuda-test','compile4/provider','compile5/cccl','compile5/cuda-test']
    for directory in compile_dirs:
        for name in ['command.json','process.json','stdout.log','stderr.log','actual-dependencies.json']:add(W/directory/name)
    for directory in ['link','link2','link3','link4','link5','run-cpu','run-indexed','run2-cpu','run3-cpu',
                      'run3-indexed','run4-fallback','run5-fallback','run5-cuda-store']:
        for name in ['command.json','process.json','stdout.log','stderr.log']:add(W/directory/name)
    parent_receipt=R/'docs/evidence/correctness/inference-indexed-gdn-graph-2026-10-27.json'
    native_receipt=R/'docs/evidence/correctness/inference-indexed-gdn-native-2026-10-27.json'
    add(parent_receipt,'references/prior-graph-receipt.json')
    # Native sources/patches/SDK are already in the prior native archive.
    add(native_receipt,'references/prior-native-receipt.json')
    # All shared Graph owner/resource/provider objects stayed fixed through retries.
    shared=[]
    for name in ['resources','store','graph-provider']:
        rows=[next(x for x in read(W/('ready'+suffix+'.json'))['compiled'] if x['name']==name) for suffix in ['', '2','3','4','5']]
        assert len({x['object']['sha256'] for x in rows})==1
        shared.append(dict(name=name,source=rows[0]['source'],object=rows[0]['object']))
    manifest=[dict(path=name,bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())]
    OUT.parent.mkdir(parents=True,exist_ok=True);zpath=OUT.with_suffix('.zip')
    assert not zpath.exists() and not OUT.with_suffix('.json').exists()
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(members.items()):z.writestr(name,data)
    with zipfile.ZipFile(zpath) as z:
        assert z.namelist()==[x['path'] for x in manifest]
        for row in manifest:
            data=z.read(row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
    assert zpath.stat().st_size<2_000_000
    result=dict(status='ELEVEN_BOUNDED_SLOT_SOURCE_FALLBACK_TESTS_PASS',date='2026-10-27',
      scope='Cold logical Store-to-source Gather association; common exact lease/ID owner; actual checked CUDA Gather projected-read capability and retained indexed fusion.',
      tests=11,groups=summary['groups'],
      observation_rule=summary['observation_rule'],
      fusion_observation_limit='The two fused cases passed inside run3-indexed whose separate fallback case failed. Those fused cases used the prior ggml leaf object and do not validate the later ggml projected-input extension.',
      final_ready=pin(W/'ready5.json'),raw_summary=pin(W/'summary.json'),
      shared_original_product_objects=shared,
      distinct_CXX_TUs=7,CXX_compile_attempts=11,link_attempts=5,linked_images=5,native_test_processes=8,
      native_objects_reused=ready['reused_native'],native_receipt=pin(native_receipt),prior_graph_receipt=pin(parent_receipt),
      source_contract=['SourceBinding/prepare overload and parent input-fact query are additive; original public/native layouts unchanged.',
        'Source/control aliases alone do not authorize reads: common owner checks original projected source guards plus actual pool/source-ID binding before prepare/seal.',
        'Graph Store writer authority remains separate from source Gather projection; source/destination IDs share the original metadata carrier.',
        'CCCL ordinary checked axis0 Gather qualifies its actual indexed reader; default routing is not forced to ggml. Bounds checks remain active.'],
      coverage=['CPU dense/padded exact sources and original destinations, result/retirement gate, two ID-slice reuse and source mutation/rebinding',
        'Invalid source association/count/private source-ID replacement rejection, with valid prepare checked before the negative',
        'CUDA escaping Gather forces a checked projected fallback rather than indexed fusion; Y/state/source/unused/padding bits checked',
        'Existing exact route6 single-region fusion, effect-only/reset recovery and writer-only CUDA Store adjacent behavior'],
      failed_attempts=[
        dict(process=read(W/'run-cpu/process.json'),kind='CPU test fixture',reason='Two new source Gather tests published an output without a caller buffer binding; original5 other cases passed.'),
        dict(process=read(W/'run-indexed/process.json'),kind='Mixed test and real missing capability',reason='Added dummy metadata nodes were not pruned, invalidating total-step expectation in two fusion fixtures. New fallback also lacked actual selected prepared access; later Status diagnostics separated it.'),
        dict(process=read(W/'run3-indexed/process.json'),kind='Actual default leaf capability gap',reason='Fusion2 passed after restoring original graph. Fallback bind returned selected prepared has no access capability.'),
        dict(process=read(W/'run4-fallback/process.json'),kind='Wrong-path first product correction',reason='Truthful ggml leaf extension compiled, but default plain Gather uses CCCL; that change did not fix the selected CCCL path. The same failure remained and was preserved.')],
      ggml_leaf_extension=dict(source=next(x['source'] for x in ready['compiled'] if x['name']=='provider'),
        direct_path_tested=False,note='Compiled but not independently exercised as a projected Gather in this batch. Existing fusion observations predate this object and do not provide that coverage.'),
      default_selection_evidence='Read-only default_policy.cc selects CCCL for plain Gather; correcting only that actual CCCL capability plus diagnostic test made unchanged default fallback succeed. Provider name is printed on assertion failure only, so passing stdout does not independently log its name.',
      historical_source_limit='Earlier failed fixture byte snapshots are incomplete. Their source hashes/freezes, exact commands and raw results are retained; final canonical sources are not claimed to be old failed source bytes. Scripts include later retry support.',
      context_only_source='src/compute_route_cuda/default_policy.cc is explanatory current source, not a TU compiled in this batch.',
      exclusions=['No engine/model integration or model-quality claim','No indexed convolution integration','No performance or speedup measurement',
        'No full-platform, broad shape or arbitrary device-ID qualification','No full SDK/third-party rebuild or native NVCC compile',
        'No downloads or copied SDK/model trees','Unchanged region8 suite was not rerun'],
      NVCC_builds=0,SDK_builds=0,model_runs=0,downloads=0,performance_claim=False,
      archive=dict(path=zpath.relative_to(R).as_posix(),bytes=zpath.stat().st_size,sha256=sha(zpath.read_bytes()),members=len(manifest)),members=manifest)
    OUT.with_suffix('.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    for p in [OUT.with_suffix('.json'),zpath]:print(json.dumps(pin(p)))
if __name__=='__main__':
    if sys.argv[1:]!=['publish']:raise SystemExit('Explicit action required: publish')
    publish()
