"""Root-invoked, offline-only package of the six completed installation cases."""
from pathlib import Path
import hashlib
import json
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[1]
DEST = R / 'docs/evidence/correctness/inference-program-installation-2026-10-28'
CASES = {
    'carrier-cpu': ('cpu', '--program-carrier'),
    'carrier-cuda': ('cuda', '--program-carrier'),
    'ordinary-cpu': ('cpu', '--sampling-policies'),
    'ordinary-cuda': ('cuda', '--sampling-policies'),
    'mtp-sampling-cpu': ('cpu', '--mtp-sampling'),
    'mtp-logits-cuda': ('cuda', '--mtp-logits'),
}
SOURCES = ('engine/inference/program_carrier.h', 'engine/inference/program_io.h',
           'engine/models/qwen35/main.cc', 'tests/tools/inference_program_carrier_case.h',
           'tests/tools/qwen_host_image_test.cc')
PARSERS = {
    'carrier': R / '.scratch/inference-program-carrier-20261028/run.py',
    'sampling': R / '.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py',
    'modifiers': R / '.scratch/inference-mtp-logits-20261028/refinement/run.py',
}


def read(path): return json.loads(Path(path).read_bytes())
def encoded(value): return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    path = Path(path); raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=sha(raw))
def exact(row):
    current = pin(row['path'])
    assert (current['bytes'], current['sha256']) == (row['bytes'], row['sha256']), row['path']
def key(path): return str(path).replace('/', '\\').casefold()
def terminal(process):
    assert process['state'] == 'TERMINAL' and process['exit'] == 0 and process['timed_out'] is False, process
def one(reports, name):
    selected = [report for report in reports if report.get('case') == name]
    assert len(selected) == 1, name
    return selected[0]


def check_report(name, backend, reports, report):
    checks = []
    if name.startswith('carrier-'):
        assert report == one(reports, 'program-carrier') and len(reports) == 1
        assert (report['status'], report['backend'], report['models'], report['native_submissions'], report['carriers']) == (
            'PASS', backend, 0, 2, 2)
        for field in ('cold_failure_atomic', 'independent_fixed_bindings', 'real_completion_retirement',
                      'GraphOutput_pin_preserved', 'closed_handle_not_reused', 'teardown_handoff_irreversible',
                      'typed_io_installation', 'unsealed_io_rejected', 'foreign_io_rejected',
                      'standalone_exact_rejected', 'partial_installation_failed', 'valid_io_retry_output_checked'):
            assert report[field] is True, field
        assert type(report['pending_observed']) is bool
        assert type(report['partial_caller_writer_tested']) is bool
        assert report['partial_caller_writer_recovered'] is (True if report['partial_caller_writer_tested'] else None)
    elif name.startswith('ordinary-'):
        assert report == one(reports, 'sampling-policies')
        assert report['status'] == 'PASS' and report['ordinary'] is True and report['same_model'] is True
        assert (report['configurations'], report['requests'], report['turns'], report['N'], report['R']) == (4, 6, 12, 2, 2)
        assert report['quality_claim'] is False and report['performance_claim'] is False
    elif name == 'mtp-sampling-cpu':
        manual, final = one(reports, 'mtp-sampling-manual'), one(reports, 'mtp-sampling-policies')
        natural = [value for value in reports if 'sessions' in value]
        assert len(reports) == 3 and len(natural) == 1
        assert report == dict(manual=manual, natural=natural[0], final=final)
        assert all(value['status'] == 'PASS' and value['backend'] == backend for value in (manual, final))
        assert (manual['configurations'], manual['interleaved_K1'], manual['interleaved_recursive'],
                manual['state_only_policy'], manual['final_versions']) == (3, 3, 3, 2, 0)
        for field in ('same_loaded_model', 'prefix_new_policy', 'strict_replay', 'same_key_rebuild',
                      'rebuild_sampling_wrapper', 'host_image_identity', 'completed_q_released'):
            assert manual[field] is True, field
        assert manual['actual_B2_simultaneous_q'] == final['actual_B2_simultaneous_q'] == 4
        assert final['manual_state_checks'] == len(manual['state_checks']) > 0
        assert (final['sequential_models'], final['natural_requests'], final['natural_configurations'], final['final_versions']) == (2, 3, 3, 0)
        for field in ('natural_recursive_cold_plan', 'natural_default_random_extra_greedy', 'completed_q_released', 'synthetic_untrained'):
            assert final[field] is True, field
        assert final['quality_claim'] is False and final['performance_claim'] is False
        checks = manual['state_checks']
        assert all(row['boundary_equal'] and row['numerically_equivalent'] and row['payloads_byte_equal'] for row in checks)
    else:
        assert name == 'mtp-logits-cuda' and report == one(reports, 'mtp-logits-modifiers') and len(reports) == 1
        assert report['status'] == 'PASS' and report['backend'] == backend
        assert (report['models'], report['configurations'], report['finite_math_branches'], report['numeric_q_failures'], report['final_versions']) == (1, 2, 2, 2, 0)
        for field in ('K1_greedy_random', 'recursive_greedy_random', 'already_normalized_q_not_reprocessed',
                      'original_B2_snapshots', 'StateOnly_no_input_or_draw', 'partial_HostImage',
                      'prefix_frontier_numeric_failure', 'new_prefix_policy_payload', 'strict_modifier_replay_rejected',
                      'historical_StateOnly_rebuild', 'known_key_metadata_zero_native', 'same_key_retry', 'synthetic_untrained',
                      'target_terminal_numeric_failure', 'target_terminal_retired_without_publish', 'target_terminal_resources_returned'):
            assert report[field] is True, field
        assert report['quality_claim'] is False and report['performance_claim'] is False
        checks = report['state_checks']; assert len(checks) == 10
        for row in checks:
            assert row['boundary_equal'] and row['numerically_equivalent']
            for part in row['differences']:
                assert part['role'] == 3 and part['maximum_absolute'] <= 3e-6 and part['nonfinite_differences'] == 0
    return dict(state_checks=len(checks), byte_exact_state_checks=sum(row['payloads_byte_equal'] for row in checks),
        maximum_GDN_absolute_difference=max((part['maximum_absolute'] for row in checks for part in row['differences']), default=0))


def main():
    assert not DEST.with_suffix('.json').exists() and not DEST.with_suffix('.zip').exists(), 'Preserve existing evidence'
    plan, frozen, compiled, ready = map(read, (W / 'plan.json', W / 'source-freeze.json', W / 'compile/compiled.json', W / 'ready.json'))
    expected_counts = dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, inputs=228, retained_inputs=227, native_processes=6, downloads=0)
    assert plan['counts'] == expected_counts
    cxx, link = read(W / 'logs/compile/process.json'), read(W / 'logs/link/process.json')
    terminal(cxx); terminal(link)
    assert compiled['process'] == cxx and ready['compiled'] == compiled and ready['process'] == link
    assert read(W / 'logs/compile/command.json')['command'] == plan['compile']
    assert read(W / 'logs/link/command.json')['command'] == plan['link']
    assert ready['inputs'] == plan['retained'] + [compiled['object']] and len(ready['inputs']) == 228
    assert len({key(row['path']) for row in ready['inputs']}) == 228
    assert len(plan['retained']) == 227 and ready['runtime'] == plan['runtime']
    exact(plan['base']); exact(plan['compile_template']); exact(plan['fixture']); exact(ready['source_freeze'])
    assert {key(row['path']) for row in frozen} == {key(R / relative) for relative in SOURCES}
    project_dependencies = {key(row['path']): row for row in compiled['project_dependencies']}
    for row in frozen:
        exact(row); assert project_dependencies[key(row['path'])] == row
    for row in compiled['project_dependencies']: exact(row)
    archive = {}
    def add(path, name=None):
        path = Path(path); name = name or 'validation/' + path.relative_to(W).as_posix()
        assert name not in archive
        assert path.suffix.lower() not in ('.exe', '.obj', '.dll', '.lib', '.pdb', '.bin', '.bf16', '.f32', '.safetensors', '.gguf')
        assert path.name != 'environment.json', 'Never archive process environment variables'
        archive[name] = path.read_bytes()
    for name in ('package.py', 'run.py', 'plan.json', 'source-freeze.json', 'compile/compiled.json',
                 'compile/dependencies.json', 'ready.json'):
        add(W / name)
    for category in ('compile', 'link'):
        for name in ('command.json', 'process.json', 'stdout.log', 'stderr.log'): add(W / 'logs' / category / name)
    for row in frozen:
        relative = Path(row['path']).relative_to(R).as_posix(); add(row['path'], 'source/' + relative)
    for name, path in PARSERS.items(): add(path, 'helpers/original-' + name + '-parser.py')
    executor = R / '.scratch/inference-indexed-store-20261028/build.py'
    add(executor, 'helpers/original-process-recorder.py')
    archive['identity/fixture.json'] = encoded(dict(manifest=plan['fixture'], payloads_included=False))
    cases, ownership = [], []
    assert {path.name for path in (W / 'runs').iterdir() if path.is_dir()} == set(CASES)
    for name, (backend, flag) in CASES.items():
        directory = W / 'runs' / name; process = read(directory / 'process.json'); terminal(process)
        command = read(directory / 'command.json')['command']
        expected = [ready['image']['path'], '--' + backend]
        if flag != '--program-carrier': expected.append(str(Path(plan['fixture']['path']).parent))
        assert command == expected + [flag]
        reports = [json.loads(line) for line in (directory / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
        report = read(directory / 'report.json'); numerical = check_report(name, backend, reports, report)
        cases.append(dict(name=name, backend=backend, flag=flag, process=process,
                          report=pin(directory / 'report.json'), numerical=numerical))
        if name.startswith('carrier-'):
            ownership.append(dict(case=name, caller_writer_tested=report['partial_caller_writer_tested'],
                caller_writer_recovered=report['partial_caller_writer_recovered'],
                native_owned_not_applicable=not report['partial_caller_writer_tested']))
        for filename in ('command.json', 'process.json', 'stdout.log', 'stderr.log', 'report.json'): add(directory / filename)
    assert len({(row['process']['pid'], row['process']['started']) for row in cases}) == 6
    manifest = encoded(dict(members=[dict(name=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(archive.items())],
                            self_hash='External JSON archive.manifest_sha256'))
    archive['MANIFEST.json'] = manifest
    outzip, outjson = DEST.with_suffix('.zip'), DEST.with_suffix('.json')
    with zipfile.ZipFile(outzip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name, raw in sorted(archive.items()): z.writestr(name, raw)
    with zipfile.ZipFile(outzip) as z:
        assert z.testzip() is None and set(z.namelist()) == set(archive)
        for name, raw in archive.items(): assert sha(z.read(name)) == sha(raw), name
    result = dict(schema='hyle.correctness.program-installation.v1', date='2026-10-28',
        status='PASS_SIX_FINITE_CURRENT_MODEL_AND_CARRIER_CASES',
        change='Use one typed ProgramInitialization recipe for original ProgramCarrier/ProgramIo installation; '
               'check exact expectation, progress, fixed IO, slots and publish only the fully installed original Invocation.',
        counts=dict(**expected_counts, carrier_processes=2, model_processes=4),
        build=dict(compile_process=cxx, link_process=link, source=compiled['source'], image=ready['image'],
                   source_freeze=pin(W / 'source-freeze.json'), receipt=pin(W / 'compile/compiled.json'),
                   retained_base=plan['base'], unchanged_SDK_weights_inputs=227),
        sources=frozen, cases=cases, carrier_ownership=ownership,
        installation_scope='Finite current include-main consumer journeys cover ordinary Phase, NextN draft, '
                           'private prefix sampling and frontier auxiliary installation with their original Graph/Compute owners. '
                           'This is a shared installation boundary, not extraction of the complete execution engine.',
        numerical=dict(state_checks=sum(case['numerical']['state_checks'] for case in cases),
            byte_exact_state_checks=sum(case['numerical']['byte_exact_state_checks'] for case in cases),
            maximum_GDN_absolute_difference=max(case['numerical']['maximum_GDN_absolute_difference'] for case in cases),
            policy='Original sampler byte-equality checks and modifier finite GDN 3e-6 budget are unchanged; no new tolerance.'),
        limitations=['Synthetic untrained GA/H64/V64/C16 fixture; no trained-model quality or performance conclusion.',
            'Ordinary sampling uses Commands replay with R2; it does not certify D2 overlap or a real Qwen BF16 benchmark.',
            'Two direct carrier cases each retain exactly two native submissions. Failed cold install, IO/exact rejection '
            'and partial writer recovery add no native submission. Caller/native ownership is reported separately; null means inapplicable.',
            'Invalid metadata/numerical payloads are finite failures, not injected device failure or proof of unknown native retirement.',
            'CPU/CUDA only and only these six consumers were run; no Apple/Vulkan, complete orchestration or exhaustive platform claim.',
            'No SDK/NVCC recompilation or downloads. No executable, object, DLL, weights, tensor bodies or process environment values in the archive.'],
        archive=dict(**pin(outzip), members=len(archive), manifest_sha256=sha(manifest), CRC='PASS', all_member_SHA256='PASS'))
    with outjson.open('xb') as out: out.write(encoded(result))
    receipt = dict(JSON=pin(outjson), ZIP=pin(outzip), members=len(archive), CRC='PASS', all_member_SHA256='PASS')
    with (W / 'package-readback.json').open('xb') as out: out.write(encoded(receipt))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == '__main__': main()
