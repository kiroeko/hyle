"""One current include-main CXX/link and six finite consumers; no SDK copy."""
from pathlib import Path
import importlib.util
import json
import os
import sys

sys.dont_write_bytecode = True
R = Path(__file__).resolve().parents[2]
W = Path(__file__).resolve().parent
BASE = R / '.scratch/inference-view-spans-20261028/validation'
TEMPLATE = R / '.scratch/inference-selected-cold-demand-20261028/validation/final'
FIXTURE = R / '.scratch/inference-paged-frame-20261026/tiny-recursive-input'
SOURCES = ('engine/inference/program_carrier.h', 'engine/inference/program_io.h',
           'engine/models/qwen35/main.cc', 'tests/tools/inference_program_carrier_case.h',
           'tests/tools/qwen_host_image_test.cc')
CASES = {'carrier-cpu': ('cpu', '--program-carrier'), 'carrier-cuda': ('cuda', '--program-carrier'),
         'ordinary-cpu': ('cpu', '--sampling-policies'), 'ordinary-cuda': ('cuda', '--sampling-policies'),
         'mtp-sampling-cpu': ('cpu', '--mtp-sampling'), 'mtp-logits-cuda': ('cuda', '--mtp-logits')}

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value

t = module(R / '.scratch/inference-indexed-store-20261028/build.py', 'installation_executor')
t.W = W

def prepare():
    baseline = t.read(BASE / 'ready-normal.json')
    t.exact(baseline['inputs']); t.exact(baseline['recipe'])
    rows = t.read(baseline['inputs']['path']); assert len(rows) == 229
    assert rows[227] == baseline['compiled']['object']
    retained = rows[:227]
    changed = {t.key(R / path) for path in SOURCES}
    for row in retained:
        t.exact(row)
        metadata = t.retained_metadata(row)
        if metadata:
            assert not changed.intersection(map(t.key, metadata['includes'])), row['path']
    compile_args = t.command(TEMPLATE / 'logs/tiny/command.json')
    args = []
    for n, arg in enumerate(compile_args):
        if n and compile_args[n-1].casefold() == '/sourcedependencies':
            arg = str(W / 'compile/dependencies.json')
        elif arg.casefold().startswith('/fo'): arg = '/Fo' + str(W / 'compile/unit.obj')
        elif arg.casefold().startswith('/fd'): arg = '/Fd' + str(W / 'compile/unit.pdb')
        args.append(arg)
    assert str(R / 'tests/tools/qwen_host_image_test.cc') in args
    link = []
    for arg in t.command(baseline['recipe']['path']):
        if t.key(arg) == t.key(rows[228]['path']): continue
        if t.key(arg) == t.key(rows[227]['path']): arg = str(W / 'compile/unit.obj')
        for prefix, suffix in (('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')):
            if arg.upper().startswith(prefix): arg = prefix + str((W / 'bin/installation').with_suffix(suffix)); break
        link.append(arg)
    env = t.read(BASE / 'environment.json')
    native = t.read(BASE / 'runtime.json')['native']; t.exact(native)
    env['PATH'] = str(W / 'bin') + ';' + str(Path(native['path']).parent) + ';' + env['PATH']
    t.save(W / 'environment.json', env)
    t.save(W / 'plan.json', dict(base=t.pin(BASE / 'ready-normal.json'), retained=retained,
        compile=args, link=link, runtime=native, compile_template=t.pin(TEMPLATE / 'logs/tiny/command.json'),
        fixture=t.pin(FIXTURE / 'weights.tsv'), counts=dict(CXX=1, links=1, SDK_CXX=0, NVCC=0, inputs=228,
            retained_inputs=227, native_processes=6, downloads=0)))
    print('PREPARED: current Tiny CXX 1, link 1, retained inputs 227; no compiler/run started')

def freeze():
    rows = [t.pin(R / path) for path in SOURCES]
    t.save(W / 'source-freeze.json', rows)
    print('SOURCE FROZEN', len(rows))

def validate():
    for row in t.read(W / 'source-freeze.json'): t.exact(row)
    return t.read(W / 'plan.json')

def compile():
    plan = validate(); (W / 'compile').mkdir()
    process = t.execute(plan['compile'], W / 'logs/compile', 300)
    validate()
    dependencies = [t.pin(p) for p in t.dep_paths(W / 'compile/dependencies.json') if t.project(p)]
    t.save(W / 'compile/compiled.json', dict(source=t.pin(R / 'tests/tools/qwen_host_image_test.cc'),
        object=t.pin(W / 'compile/unit.obj'), process=process, project_dependencies=dependencies))
    print('CXX PASS', process['pid'])

def link():
    plan = validate(); compiled = t.read(W / 'compile/compiled.json'); t.exact(compiled['object'])
    for row in plan['retained']: t.exact(row)
    (W / 'bin').mkdir()
    native = plan['runtime']; alias = W / 'bin' / Path(native['path']).name
    alias.hardlink_to(native['path']); assert alias.samefile(native['path'])
    process = t.execute(plan['link'], W / 'logs/link', 240)
    rows = plan['retained'] + [compiled['object']]; assert len(rows) == 228
    t.save(W / 'ready.json', dict(image=t.pin(W / 'bin/installation.exe'), inputs=rows,
        compiled=compiled, process=process, runtime=native, source_freeze=t.pin(W / 'source-freeze.json')))
    print('LINK PASS', process['pid'])

def parse(name):
    backend, flag = CASES[name]; out = W / 'runs' / name
    process = t.read(out / 'process.json'); assert process['exit'] == 0 and not process['timed_out']
    reports = [json.loads(line) for line in (out / 'stdout.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    if flag == '--program-carrier':
        parser = module(R / '.scratch/inference-program-carrier-20261028/run.py', 'installation_carrier_parser')
        report = parser.carrier_report(reports, backend)
        for field in ('typed_io_installation', 'unsealed_io_rejected', 'foreign_io_rejected',
                      'standalone_exact_rejected', 'partial_installation_failed', 'valid_io_retry_output_checked'):
            assert report[field] is True, field
        assert type(report['partial_caller_writer_tested']) is bool
        if report['partial_caller_writer_tested']: assert report['partial_caller_writer_recovered'] is True
        else: assert report['partial_caller_writer_recovered'] is None
    elif flag == '--mtp-sampling':
        parser = module(R / '.scratch/inference-mtp-sampling-20261028/refinement-v4/run.py', 'installation_sampler_parser')
        report = parser.sampler_reports(reports, backend)
    elif flag == '--mtp-logits':
        parser = module(R / '.scratch/inference-mtp-logits-20261028/refinement/run.py', 'installation_logits_parser')
        report = parser.modifiers_report(reports, backend)
        for field in ('target_terminal_numeric_failure', 'target_terminal_retired_without_publish', 'target_terminal_resources_returned'):
            assert report[field] is True, field
    else:
        finals = [row for row in reports if row.get('case') == 'sampling-policies']; assert len(finals) == 1
        report = finals[0]
        assert report['status'] == 'PASS' and report['ordinary'] and report['same_model']
        assert (report['configurations'], report['requests'], report['turns'], report['N'], report['R']) == (4, 6, 12, 2, 2)
        assert report['quality_claim'] is False and report['performance_claim'] is False
    t.save(out / 'report.json', report)
    print('PASS', name, 'PID', process['pid'])

def run(name):
    plan = validate(); ready = t.read(W / 'ready.json'); t.exact(ready['image']); t.exact(plan['fixture'])
    backend, flag = CASES[name]; args = [ready['image']['path'], '--' + backend]
    if flag != '--program-carrier': args.append(str(FIXTURE))
    args.append(flag)
    t.execute(args, W / 'runs' / name, 300)
    parse(name)

if __name__ == '__main__':
    action = sys.argv[1]
    if action in ('prepare', 'freeze', 'compile', 'link'): globals()[action]()
    elif action in ('run', 'parse'): globals()[action](sys.argv[2])
    else: raise ValueError(action)
