from pathlib import Path
import json,os,subprocess,time,sys
R=Path.cwd();W=R/'.scratch/qwen-multi-draft-20261024';E=R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check';inputs=R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original';summary=[]
cases=[('cuda','ordinary','off',0,'greedy',0),('cuda','mtp-K4','on',4,'greedy',0),('cuda','hybrid-K1-random','on',1,'random',2),('cpu','mtp-K1','on',1,'greedy',0)]
if len(sys.argv)>1:cases=[c for c in cases if c[1] in sys.argv[1:]]
for backend,name,mtp,k,mode,layers in cases:
 F=W/('geometry-'+backend+'-check1');C=F/name;C.mkdir(exist_ok=True);ready=json.loads((E/('ready-'+backend+'.json')).read_text());env=dict(os.environ,PATH=str(F)+os.pathsep+ready['PATH']);args=[str(F/'recursive-probe.exe'),'--inputs',str(inputs),'--capacity','256','--steps','8','--prefix-cache','off','--replay','commands','--mtp',mtp,'--sampling',mode,'--cpu-ffn-layers',str(layers)]
 if mtp=='on':args+=['--mtp-max-drafts',str(k)]
 if mode=='random':args+=['--top-k','8','--seed','123']
 (C/'command.json').write_text(json.dumps(args,indent=2)+'\n');print('START',backend,name,flush=True);start=time.time()
 with (C/'stdout.log').open('wb') as out,(C/'stderr.log').open('wb') as err:p=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=err,timeout=180)
 info=dict(exit=p.returncode,seconds=time.time()-start);(C/'process.json').write_text(json.dumps(info,indent=2)+'\n');print('END',backend,name,info,flush=True)
 if p.returncode:print((C/'stderr.log').read_text(encoding='utf8',errors='replace')[-6000:],flush=True)
 else:
  parsed=[json.loads(line) for line in (C/'stdout.log').read_text(encoding='utf8',errors='replace').splitlines() if line.startswith('{')];(C/'parsed.json').write_text(json.dumps(parsed,indent=2)+'\n');print([(v.get('generated_ids'),v.get('original_host_weight_bytes')) for v in parsed],flush=True)
 summary.append(dict(backend=backend,case=name,**info))
 if p.returncode:break
(W/'geometry-complete-input-summary.json').write_text(json.dumps(summary,indent=2)+'\n');sys.exit(1 if any(v['exit'] for v in summary) else 0)
