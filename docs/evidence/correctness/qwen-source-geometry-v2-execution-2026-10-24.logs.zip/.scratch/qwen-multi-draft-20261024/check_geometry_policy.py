from pathlib import Path
import json,subprocess,sys,os,time
R=Path.cwd();W=R/'.scratch/qwen-multi-draft-20261024/geometry-policy-check1';W.mkdir(exist_ok=True)
old=R/'.scratch/qwen35-unsloth-mtp-20261024/consumed-checkpoint-check1';recipe=json.loads((old/'compile/command.json').read_text())['command'];args=[];skip=False
for a in recipe:
 if skip:skip=False;continue
 if a=='/sourceDependencies':skip=True;continue
 if a.startswith(('/Fo','/Fd')):continue
 args.append(a)
args+=['/Fo'+str(W/'policy.obj')]
sys.path.insert(0,str(R/'scripts'));from hyle_environment import discover_environment
env=discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':args[0],'CMAKE_CXX_COMPILER':args[0],'CMAKE_GENERATOR':'Ninja'},backends=()).env
link=json.loads((old/'link-plan.json').read_text())['command'];link=[str(W/'policy.obj') if a.endswith('prefix.obj') else a for a in link if not a.upper().startswith('/OUT:')];link+=['/OUT:'+str(W/'policy.exe')]
summary=[]
for name,cmd in [('compile',args),('link',link),('run',[str(W/'policy.exe')])]:
 (W/(name+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n');begin=time.time();p=subprocess.run(cmd,cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60);(W/(name+'.log')).write_bytes(p.stdout);summary.append(dict(name=name,exit=p.returncode,seconds=time.time()-begin));print(name,p.returncode,p.stdout.decode('utf8','replace'))
 if p.returncode:break
(W/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');sys.exit(p.returncode)
