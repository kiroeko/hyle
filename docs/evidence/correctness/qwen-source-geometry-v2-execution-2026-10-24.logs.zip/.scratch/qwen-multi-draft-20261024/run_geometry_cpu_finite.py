from pathlib import Path
import json,subprocess,os,time
R=Path.cwd();W=R/'.scratch/qwen-multi-draft-20261024/geometry-cpu-check2';C=W/'mtp-K1-finite';C.mkdir(exist_ok=True)
ready=json.loads((R/'.scratch/qwen35-unsloth-mtp-20261024/engine-check/ready-cpu.json').read_text());env=dict(os.environ,PATH=str(W)+os.pathsep+ready['PATH'])
args=[str(W/'recursive-probe.exe'),'--inputs',str(R/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check/original'),'--capacity','256','--cache-bytes','134217728','--steps','2','--prefix-cache','off','--replay','commands','--mtp','on','--mtp-max-drafts','1','--sampling','greedy']
(C/'command.json').write_text(json.dumps(args,indent=2)+'\n');start=time.time()
with (C/'stdout.log').open('wb') as out,(C/'stderr.log').open('wb') as err:p=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=err,timeout=120)
record=dict(exit=p.returncode,seconds=time.time()-start);(C/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
if p.returncode:print((C/'stderr.log').read_text(encoding='utf8',errors='replace')[-6000:])
else:
 parsed=[json.loads(line) for line in (C/'stdout.log').read_text().splitlines() if line.startswith('{')];(C/'parsed.json').write_text(json.dumps(parsed,indent=2)+'\n');print([{k:v.get(k) for k in ['generated_ids','original_host_weight_bytes','original_device_weight_bytes','cache_requested_byte_limit','workspace_domains','native_execution_private_bytes_unknown']} for v in parsed]);assert parsed[0]['generated_ids']==[71093,12305]
raise SystemExit(p.returncode)
