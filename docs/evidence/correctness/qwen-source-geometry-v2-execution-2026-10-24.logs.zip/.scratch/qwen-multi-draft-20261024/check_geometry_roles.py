from pathlib import Path
import json,importlib.util,sys,subprocess,time,os
sys.dont_write_bytecode=True
ROOT=Path.cwd();HERE=ROOT/'.scratch/mtp-metadata-offline-20261024';OUT=ROOT/'.scratch/qwen-multi-draft-20261024/geometry-roles-check1';OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('host_helpers',ROOT/'.scratch/engine-product-20261024/cpu-build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def execute(command,env,folder,timeout):
    folder.mkdir(parents=True,exist_ok=True);(folder/'tmp').mkdir(exist_ok=True)
    env=dict(env,TEMP=str(folder/'tmp'),TMP=str(folder/'tmp'))
    record=dict(command=command,cwd=str(ROOT),started=time.time(),timeout_seconds=timeout)
    b.save(folder/'command.json',record)
    with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
        result=subprocess.run(command,cwd=ROOT,env=env,stdout=out,stderr=err,timeout=timeout,
          creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    record.update(exit=result.returncode,finished=time.time());b.save(folder/'process.json',record)
    if result.returncode:raise RuntimeError('Native check failed: '+str(folder))
    return record
cc=b.read(ROOT/'.scratch/qwen35-unsloth-mtp-20261024/prepared-roles-check2/compile/command.json')['command'][0]
native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
source=ROOT/'tests/tools/qwen_prepared_roles_test.cc';obj=OUT/'compile/roles.obj';image=OUT/'link/roles-check.exe'
cmd=[cc,'/nologo','/c','/std:c++latest','/EHsc','/MD','/O2','/W4','/WX','/permissive-','/Zc:preprocessor','/utf-8','/sourceDependencies',str(OUT/'compile/dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(OUT/'compile/roles.pdb')]
execute(cmd,native.env,OUT/'compile',120)
execute([str(Path(cc).with_name('link.exe')),'/NOLOGO','/MACHINE:X64','/INCREMENTAL:NO',str(obj),'/OUT:'+str(image)],native.env,OUT/'link',30)
actual=[str(ROOT/'.scratch/qwen35-unsloth-mtp-20261024/geometry-v2-check'/profile/'weights.tsv') for profile in ['original','Q01','Q03']]
result=execute([str(image),str(OUT/'fixtures'),*actual],native.env,OUT/'run',30)
b.save(OUT/'summary.json',dict(process=result,image=b.identity(image),source=b.identity(source),product_headers=[b.identity(ROOT/'engine/models/qwen35'/name)for name in ['prepared_roles.h','prepared_gguf_roles.h']],SDK_builds=0,model_bytes_read=0,HTTP=0))
print((OUT/'run/stdout.log').read_text())
