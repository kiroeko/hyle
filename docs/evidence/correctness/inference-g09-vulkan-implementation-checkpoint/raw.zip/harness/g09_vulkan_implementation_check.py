from pathlib import Path
import ctypes,hashlib,json,os,re,subprocess,time,sys

root=Path(__file__).resolve().parents[2]
out=root/'.scratch/inference-gaps/g09-vulkan-implementation-check-1'
resume='--resume-fixture' in sys.argv or '--resume' in sys.argv
attempt=1+len(list(out.glob('retry*-build.log'))) if resume else 0
out.mkdir(exist_ok=resume)
retained=None
if resume:
    retained=json.loads((out/'result.json').read_text())
    (out/f'result-before-retry{attempt}.json').write_text(json.dumps(retained,indent=2)+'\n',encoding='utf8')
build=Path('C:/h7/w-cpu-vulkan/selected-graph/source-build')
parent=Path('C:/h7/w-cpu-vulkan/selected-graph/source-parent')
cmake=parent/'CMakeLists.txt'
if not resume:
    (out/'original-parent-CMakeLists.txt').write_bytes(cmake.read_bytes())
    text=cmake.read_text(encoding='utf8')
    for target,source in [('hyle_cpu_vulkan_pipeline','native_joint_pipeline.cc'),('hyle_cpu_vulkan_contracts','cpu_vulkan_contracts.cc')]:
        assert f'add_executable({target}' not in text
        text+=f'\nadd_executable({target} "{(root/"tests/graph"/source).as_posix()}")\n'
        text+=f'target_compile_features({target} PRIVATE cxx_std_23)\n'
        text+=f'target_link_libraries({target} PRIVATE hyle::graph)\n'
        text+=f'hyle_stage_runtime({target})\n'
    cmake.write_text(text,encoding='utf8')
setup=subprocess.check_output(['cmd','/d','/c',str(root/'.scratch/inference-gaps/g01/cpu-ragged-env.cmd')],text=True,encoding='utf8',errors='replace')
env={k.upper():v for k,v in os.environ.items()}
env.update((k.upper(),v) for k,v in (line.split('=',1) for line in setup.splitlines() if '=' in line and not line.startswith('=')))
env.update(VSLANG='1033',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
r={'state':'SETUP','stages':[],'pid':os.getpid(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
   'scope':'Partial Graph/common and CPU+Vulkan CXX owner compile and real public-consumer runtime using unchanged prior G08 source-integration leaf archives. No hardware-overlap/P1/aggregate or fresh delivery verdict.',
   'max_jobs':4,'logical_cpu_limit':4,'priority':'BELOW_NORMAL','input_hashes':[],'borrowed_archives':[]}
for p in ['src/graph/executable.cc','src/graph/submission_internal.h','src/graph/native_analysis.h','src/graph/joint_pipeline.h',
          'src/graph_route_cpu_vulkan/compile.cc','src/graph_route_cpu_vulkan/plan.h','src/graph_route_cpu_vulkan/invocation.cc',
          'tests/graph/native_joint_pipeline.cc','tests/graph/cpu_vulkan_contracts.cc']:
    r['input_hashes'].append({'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()})
if resume:
    current_inputs=r['input_hashes']
    r=retained
    r['input_hashes']=current_inputs
    r['retained_initial_record']='result-initial.json'
    r['retained_previous_record']=f'result-before-retry{attempt}.json'
    r['scope']='Partial real Windows shared CPU+Vulkan source-integration owner/direct-consumer check, reused unchanged qualified leaf libraries; initial test-fixture compile failure and cumulative cost retained. No aggregate/P1/SDK delivery verdict.'
started=time.monotonic()-(retained['elapsed_seconds'] if resume else 0)
def save():
    r['elapsed_seconds']=time.monotonic()-started
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8')
def run(stage,args,timeout=1800,extra_env=None):
    stage=(f'retry{attempt}-' if resume else '')+stage
    log=out/(stage+'.log');stamp=time.monotonic()
    with log.open('wb') as stream:
        job=subprocess.Popen([str(a) for a in args],cwd=root,env=env if extra_env is None else dict(env,**extra_env),stdout=stream,stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW|subprocess.BELOW_NORMAL_PRIORITY_CLASS)
        kernel=ctypes.windll.kernel32
        kernel.GetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
        kernel.SetProcessAffinityMask.argtypes=[ctypes.c_void_p,ctypes.c_size_t]
        available=ctypes.c_size_t();system=ctypes.c_size_t();handle=ctypes.c_void_p(int(job._handle))
        if not kernel.GetProcessAffinityMask(handle,ctypes.byref(available),ctypes.byref(system)):raise OSError('read affinity')
        mask=sum([1<<i for i in range(64) if available.value&(1<<i)][:4])
        if not kernel.SetProcessAffinityMask(handle,mask):raise OSError('set affinity')
        r.update(state='RUNNING',stage=stage,child_pid=job.pid);save();print(stage,job.pid,flush=True)
        try:code=job.wait(timeout=timeout)
        except subprocess.TimeoutExpired:job.kill();job.wait();code=124
    r['stages'].append({'stage':stage,'command':[str(a) for a in args],'exit_code':code,'elapsed_seconds':time.monotonic()-stamp})
    r.pop('child_pid',None);save()
    if code:
        r['state']='FAIL';save();print(log.read_text(encoding='utf8',errors='replace')[-10000:],flush=True);raise SystemExit(code)
if not resume:run('manifest',['ninja','-C',build,'build.ninja'])
source=(build/'build.ninja').read_text(encoding='utf8');lines=[]
keep=('hyle/src/graph/hyle_graph.lib','hyle/src/graph_route_cpu_vulkan/hyle_graph_route_cpu_vulkan.lib')
for line in source.splitlines(keepends=True):
    match=re.match(r'^build ([^:]+): (?:CXX|CUDA)_STATIC_LIBRARY_LINKER',line)
    if match and match[1].replace('\\','/') not in keep:
        output=match[1];path=build/output.replace('\\','/')
        if path.is_file():
            r['borrowed_archives'].append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size})
            line=f'build {output}: phony\n'
    lines.append(line)
preview=out/'unchanged-leaf-reuse.ninja';preview.write_text(''.join(lines),encoding='utf8')
targets=['hyle_cpu_vulkan_pipeline','hyle_cpu_vulkan_contracts','joint']
dry=subprocess.check_output(['ninja','-C',str(build),'-f',str(preview),'-n',*targets],env=env,text=True,encoding='utf8',errors='replace')
(out/'dry-run.log').write_text(dry,encoding='utf8');r['dry_run_edges']=len(dry.splitlines());save()
assert len(dry.splitlines())<90 and 'Re-running CMake' not in dry and 'Building CUDA object' not in dry,dry
run('build',['ninja','-C',build,'-f',preview,'-j','4',*targets])
def binary(target):
    p=build/(target+'.exe')
    if not p.exists():p=build/'bin'/(target+'.exe')
    assert p.is_file(),p
    return p
run('contracts',[binary('hyle_cpu_vulkan_contracts')],600)
run('g08-joint-regression',[binary('joint')],600)
run('pipeline-correctness',[binary('hyle_cpu_vulkan_pipeline')],600)
for item in r['input_hashes']:
    assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item
for item in r['borrowed_archives']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'],item
r['state']='PARTIAL_VULKAN_IMPLEMENTATION_CHECK_PASS'
r['binaries']=[{'target':t,'path':str(binary(t)),'sha256':hashlib.sha256(binary(t).read_bytes()).hexdigest()} for t in targets]
save();print(json.dumps({k:r[k] for k in ['state','elapsed_seconds','stages','dry_run_edges']}),flush=True)
