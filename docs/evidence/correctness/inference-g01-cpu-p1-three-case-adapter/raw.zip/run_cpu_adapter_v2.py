from pathlib import Path
import subprocess, os, time, json, hashlib
repo=Path.cwd();out=repo/'.scratch/inference-gaps/g01';build=repo/'.scratch/build-compute-v2-dev'
batch=out/'cpu-adapter-v2-env.cmd';batch.write_text('@echo off\ncall "C:\\Program Files\\Microsoft Visual Studio\\18\\Enterprise\\Common7\\Tools\\VsDevCmd.bat" -arch=x64 -host_arch=x64 >nul\nif errorlevel 1 exit /b 1\nset\n')
environment=subprocess.check_output(['cmd','/d','/c',str(batch)],text=True);env=os.environ.copy()
for line in environment.splitlines():
 if '=' in line and not line.startswith('='):
  key,value=line.split('=',1);env[key]=value
result_file=out/'cpu-adapter-v2-result.json';records=json.loads(result_file.read_text())['stages'] if result_file.exists() else []
def run(stage,args,extra=None):
 attempt=1+sum(x['stage']==stage for x in records);log=out/f'cpu-adapter-v2-{stage}-{attempt}.log';started=time.monotonic();child=env.copy();child.update(extra or {})
 with log.open('w',encoding='utf-8') as f:r=subprocess.run(args,env=child,stdout=f,stderr=subprocess.STDOUT)
 row={'stage':stage,'command':args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)};records.append(row)
 files=list((repo/'bench/inference_resident_sdpa').glob('cpu*.*'))+list((repo/'bench/inference_resident_sdpa/cpu_p1').glob('*'))
 result_file.write_text(json.dumps({'product_candidate':'d91a523df9bce21eb81c13d9bf2a8f3f7d3ea80f','scope':'CPU adapter v2 three cases and placement/control compile/oracle only; not qualified P1','source_inputs':{str(f.relative_to(repo)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files if f.is_file()},'stages':records},indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  with log.open('rb') as f:f.seek(max(0,log.stat().st_size-2200));print(f.read(2200).decode(errors='replace'))
  raise SystemExit(r.returncode)
run('build',['cmake','--build',str(build),'--target','g01_cpu_resident_bench','g01_cpu_resident_bench_placement','g01_cpu_perf_control','--parallel','2'])
run('oracle',[str(build/'bin/g01_cpu_resident_bench.exe')],{'HYLE_BENCH_VERIFY_ONLY':'1'})
