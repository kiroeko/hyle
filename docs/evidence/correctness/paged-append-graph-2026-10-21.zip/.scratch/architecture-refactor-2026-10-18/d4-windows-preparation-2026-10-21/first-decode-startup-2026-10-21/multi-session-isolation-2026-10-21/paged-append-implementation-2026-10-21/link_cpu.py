from pathlib import Path
import importlib.util
import os
import sys
import argparse
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('append_build',S/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c,R,B=h.b,h.c,h.R,h.B
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--tag',required=True);args=parser.parse_args()
 out=B/args.tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
 ready=c.read(S.parents[1]/'layout-preparation-diagnostic-2026-10-21/ready-for-root.json')
 base=c.read(ready['link_plan']['path'])
 records=[]
 for path in sorted(S.glob('compiles-attempt*.json'),key=lambda p:int(p.stem.split('attempt')[1])):records+=c.read(path)['records']
 latest={Path(x['source']['path']).name:x for x in records}
 patterns={'resource_leases.cc':'resource_leases','paged_arena.cc':'paged_arena','resources.cc':'graph-resources',
   'execution_source.cc':'execution_source','executable.cc':'graph--executable','batch.cc':'graph_batch--batch'}
 replace={}
 for source,pattern in patterns.items():
  matches=[x for x in base['inputs'] if pattern in Path(x['path']).stem]
  assert len(matches)==1,(source,matches)
  replace[c.key(matches[0]['path'])]=latest[source]['object']
 old_main=base['inputs'][0]
 assert Path(old_main['path']).name=='main.obj',old_main
 replace[c.key(old_main['path'])]=latest['paged_append_graph_test.cc']['object']
 # The CUDA/model closure left CPU math in an old archive. Override its
 # provider TU explicitly for a real CPU test; current native_batch is already
 # a retained, source-identical independent object in that closure.
 cpu_provider=latest['ggml_cpu_provider.cc']['object']
 cpu_old=R/'.scratch/architecture-refactor-2026-10-18/paged-e4-kv-reference/cpu/checks/products/attempt1/provider/provider.obj'
 assert sum(c.key(row['path'])==c.key(cpu_old) for row in base['inputs'])==1
 replace[c.key(cpu_old)]=cpu_provider
 selector=latest['cpu_program.cc']['object']
 baseline=b.identity(R/'.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/native-baseline.obj')
 inputs=[selector,baseline]+[replace.get(c.key(row['path']),row) for row in base['inputs']]+[latest['paged_append.cc']['object']]
 assert len(inputs)==193 and len({c.key(x['path']) for x in inputs})==193
 for row in inputs:assert all(b.identity(row['path'])[k]==row[k] for k in ('bytes','sha256')),row
 for row in latest.values():
  for dep in row['dependencies']:assert all(b.identity(dep['path'])[k]==dep[k] for k in ('bytes','sha256')),dep
 command=[replace[c.key(x)]['path'] if c.key(x) in replace else x for x in base['command']
  if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 command[1:1]=[selector['path'],baseline['path']]
 image=out/'append-cpu.exe';command +=[latest['paged_append.cc']['object']['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.save(out/'link-plan.json',dict(command=command,inputs=inputs,base=b.identity(ready['link_plan']['path']),
   fresh_sources=[x['source'] for x in latest.values()],GPU_runs=0,SDK_builds=0))
 env,runtime=b.environment(command,[x['path'] for x in inputs],out);c.execute('link',command,env,out)
 original=next(Path(ready['image']['path']).parent.glob('hyle_ggml_cpu_avx2_*.dll'));target=out/original.name;os.link(original,target)
 assert os.path.samefile(original,target)
 overlay=R/'.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/hyle_ggml_cpu_avx2_ffa4_causal_overlay.dll'
 selected=out/'hyle_ggml_cpu_append_hyca.dll';os.link(overlay,selected);assert os.path.samefile(overlay,selected)
 c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime,CPU_DLL=dict(source=b.identity(original),destination=b.identity(target),hardlink=True),
  CPU_native_overlay=dict(source=b.identity(overlay),destination=b.identity(selected),hardlink=True,selector=latest['cpu_program.cc']['source'],
   recipe=b.identity(R/'.scratch/perf-review-2026-10-18/cpu-native-causal/commands.json'),
   boundary='Plain F16/BF16 append/attention only. Explicit ABI-v2 HYCA selector and matching native overlay. No E4 pass claimed. Old cached DLL untouched.')))
 c.save(S/'cpu-ready.json',dict(image=b.identity(image),link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),GPU_runs=0,SDK_builds=0))
 print('CPU_READY',image,flush=True)
if __name__=='__main__':main()
