from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location('append_b',Path(__file__).with_name('build.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c,R,S=h.b,h.c,h.R,h.S
records=[]
for path in sorted(S.glob('compiles-attempt*.json'),key=lambda p:int(p.stem.split('attempt')[1])):records+=c.read(path)['records']
latest={Path(x['source']['path']).name:x for x in records}
products=[latest[Path(source).name] for source in h.SOURCES]
headers=['include/hyle/graph/batch.h','include/hyle/graph/detail/region_access.h','include/hyle/graph/detail/execution_source.h',
 'include/hyle/compute/paged_arena.h','include/hyle/compute/detail/paged_arena_access.h','include/hyle/compute/detail/lease_access.h']
for row in products:
 for item in [row['source'],row['object'],*row['dependencies']]:
  assert all(b.identity(item['path'])[key]==item[key] for key in ['bytes','sha256']),item
ready=c.read(S/'cpu-ready.json')
report=dict(status='product_sources_and_headers_frozen_host_compile_and_link_pass_cpu_oracle_unresolved',
 products=products,headers=[b.identity(R/p) for p in headers],
 source=latest['paged_append_graph_test.cc']['source'],CPU_consumer=ready,
 link_plan=ready['link_plan'],runtime_environment=ready['runtime_environment'],
 validation=dict(run_directory=str(h.B/'run4'),terminal=1,
  reason='Both ordinary same-Graph append and an independent ready-page attention Graph return noncausal mean0.39990234 for query0; required causal oracle0.3125 is unchanged. Actual staged CPU native DLL lacks current HYCA patch, independently source diagnosed. No CPU numerical pass claimed.'),
 boundary='Existing ordinary Graph/Invocation/QueueSequence. Exact page writers and direct DAG ordering; first implementation fresh F16/BF16 COW pages. Encoded caches, delegated native runtimes, exclusive in-place append and automatic failed-owner-drop recovery are not claimed.',
 CXX_products=7,NVCC=0,SDK_builds=0,GPU_runs=0)
c.save(S/'ready-for-root.json',report)
print(b.identity(S/'ready-for-root.json'))
