from pathlib import Path
import concurrent.futures
import importlib.util
import argparse
import sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent
R=next(p for p in S.parents if (p/'AGENTS.md').is_file() and (p/'src').is_dir())
B=R/'.scratch/paged-append-20261021'
D=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21'
spec=importlib.util.spec_from_file_location('append_retained_helpers',D/'build.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
recipe=R/'.scratch/architecture-refactor-2026-10-18/ga-ratio4-producer-2026-10-21/common/checks/root-resources1/identity.json'
SOURCES=['src/compute/resource_leases.cc','src/compute_batch/paged_arena.cc','src/graph/resources.cc',
 'src/graph/execution_source.cc','src/graph/executable.cc','src/graph_batch/batch.cc','src/graph_batch/paged_append.cc']
def one(job):
 source,attempt=job;source=R/source;tag=source.parent.name+'--'+source.stem
 out=B/'checks'/attempt/tag;out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
 original=c.read(recipe);command=b.host_command(original['command'],source,tag,out)
 if source.name=='paged_append_graph_test.cc':command.append('/DHYLE_APPEND_STANDALONE=1')
 if source.name=='cpu_program.cc':command += ['/DHYLE_GGML_CPU_AVX2_PROGRAM=1','/DHYLE_GGML_CPU_PROGRAM_LIBRARY="hyle_ggml_cpu_append_hyca.dll"']
 frozen=b.identity(source)
 c.save(out/'compile-plan.json',dict(command=command,source=frozen,recipe=b.identity(recipe),GPU_runs=0,SDK_builds=0))
 env,_=b.environment(command,[],out);c.execute('compile',command,env,out)
 deps=c.read(out/(tag+'-deps.json'))['Data']
 record=dict(source=frozen,object=b.identity(out/(tag+'.obj')),command=command,
   dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'],*deps['Includes']])],GPU_runs=0,SDK_builds=0)
 c.save(out/'identity.json',record);return record
def main():
 p=argparse.ArgumentParser();p.add_argument('--attempt',required=True);p.add_argument('--source',action='append');a=p.parse_args()
 sources=a.source or SOURCES
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  records=list(pool.map(one,[(source,a.attempt) for source in sources]))
 c.save(S/('compiles-'+a.attempt+'.json'),dict(records=records,CXX=len(records),NVCC=0,GPU_runs=0,SDK_builds=0))
 print('COMPILED',len(records),flush=True)
if __name__=='__main__':main()
