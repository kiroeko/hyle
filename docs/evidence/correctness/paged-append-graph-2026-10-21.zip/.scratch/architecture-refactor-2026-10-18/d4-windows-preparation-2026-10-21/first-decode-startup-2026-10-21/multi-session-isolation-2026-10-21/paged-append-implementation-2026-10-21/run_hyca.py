from pathlib import Path
import importlib.util
import os
spec=importlib.util.spec_from_file_location('append_b',Path(__file__).with_name('build.py'))
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c,R,S,B=h.b,h.c,h.R,h.S,h.B
ready=c.read(S/'cpu-ready.json');runtime=c.read(ready['runtime_environment']['path'])
stage=B/'cpu-hyca-runtime';stage.mkdir(exist_ok=False)
original=Path(ready['image']['path']);image=stage/original.name;os.link(original,image)
assert os.path.samefile(original,image)
overlay=R/'.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/hyle_ggml_cpu_avx2_ffa4_causal_overlay.dll'
expected_name=Path(runtime['CPU_DLL']['destination']['path']).name
mapped=stage/expected_name;os.link(overlay,mapped)
assert os.path.samefile(overlay,mapped)
assert b.identity(overlay)['sha256']=='4b574bc5b1b90d223cc0dd3fa29013320d1198b871a9f401b7b0205542755546'
receipt=R/'.scratch/perf-review-2026-10-18/cpu-native-causal/commands.json'
ops=R/'.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/ops.cpp'
c.save(stage/'runtime-closure.json',dict(image=b.identity(image),same_image_as=ready['image'],hardlink=True,
 native_DLL_source=b.identity(overlay),mapped_loader_basename=b.identity(mapped),actual_native_recipe=b.identity(receipt),
 native_ops_source=b.identity(ops),retained_runtime=runtime,
 scope='Only plain F16/BF16 paged append/attention. Same-family HYCA native overlay predates E4 changes; no E4 or all-runtime pass claimed. Old DLL/cache untouched.',
 source_frozen=True,SDK_builds=0,NVCC=0,GPU_runs=0))
env=dict(os.environ);env['PATH']=runtime['PATH']
out=B/'run-hyca1';out.mkdir(exist_ok=False)
c.execute('run',[str(image)],env,out)
c.save(S/'cpu-hyca-result.json',dict(runtime_closure=b.identity(stage/'runtime-closure.json'),
 run_result=b.identity(out/'run.result.json'),stdout=b.identity(out/'run.stdout.log'),stderr=b.identity(out/'run.stderr.log'),
 GPU_runs=0,SDK_builds=0))
print('PLAIN_CPU_APPEND_PASS',str(out),flush=True)
