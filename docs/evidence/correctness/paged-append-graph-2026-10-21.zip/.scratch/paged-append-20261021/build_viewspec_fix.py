"""Four host TUs for a confirmed mixed-DAG discovery regression; no SDK/NVCC."""
from pathlib import Path
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
R = P.parents[1]
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_helpers', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
sources = (
    ('src/graph_batch/batch.cc', P / 'checks/attempt3/graph_batch--batch/identity.json'),
    ('src/graph_batch/paged_append.cc', P / 'checks/attempt8/graph_batch--paged_append/identity.json'),
    ('tests/graph_batch/paged_append_graph_test.cc', P / 'checks/attempt6/graph_batch--paged_append_graph_test/identity.json'),
    ('tests/graph_batch/paged_append_cuda_consumer.cc', P / 'cuda-check1/identity.json'),
)
def compile_one(job):
    source, recipe_path = job
    source = R / source
    tag = source.parent.name + '--' + source.stem
    out = P / 'checks/attempt9' / tag
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    recipe = c.read(recipe_path)
    command = b.host_command(recipe['command'], source, tag, out)
    frozen = b.identity(source)
    c.save(out / 'compile-plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe_path), CXX=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    deps = c.read(out / (tag + '-deps.json'))['Data']
    record = dict(source=frozen, object=b.identity(out / (tag + '.obj')), command=command,
                  dependencies=[b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])])
    assert h.same(frozen) and all(h.same(x) for x in record['dependencies'])
    c.save(out / 'identity.json', record)
    return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(compile_one, sources))
c.save(P / 'viewspec-compile.json', dict(records=records, CXX=4, NVCC=0, SDK_builds=0, GPU_runs=0))
print('Four related TUs compiled; no native/SDK rebuild.', flush=True)
