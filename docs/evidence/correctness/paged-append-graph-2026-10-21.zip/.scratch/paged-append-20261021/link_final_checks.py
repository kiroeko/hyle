"""Final current append object; reuse tested CUDA/main objects, zero CXX/NVCC."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parents[1];C=R/'.scratch/multi-session-capacity-20261021'
W=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec=importlib.util.spec_from_file_location('existing_build',W/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);b,c=h.b,h.c
base_path=P/'cuda-check1/link-plan.json';base=c.read(base_path);assert all(h.same(x) for x in base['inputs'])
fresh=c.read(P/'checks/attempt8/graph_batch--paged_append/identity.json');assert h.same(fresh['source']) and h.same(fresh['object'])
append=[x for x in base['inputs'] if x['path'].endswith('graph_batch--paged_append.obj')];assert len(append)==1
cpu=c.read(P/'cuda-check1/runtime-environment.json')['CPU_DLL']['destination'];assert h.same(cpu)
for name,main in (('cuda',None),('qwen',c.read(C/'checks/attempt1/identity.json')['object'])):
 out=P/('final-'+name+'1');out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
 replacements={c.key(append[0]['path']):fresh['object']}
 if main:
  assert h.same(main);old=[x for x in base['inputs'] if x['path'].endswith('cuda-test.obj')];assert len(old)==1;replacements[c.key(old[0]['path'])]=main
 inputs=[replacements.get(c.key(x['path']),x) for x in base['inputs']]
 image=out/(name+'.exe');link=[replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
 link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
 c.save(out/'link-plan.json',dict(command=link,inputs=inputs,base=b.identity(base_path),fresh_append=fresh['source'],CXX=0,links=1,NVCC=0,SDK_builds=0))
 env,runtime=b.environment(link,[x['path'] for x in inputs],out);c.execute('link',link,env,out)
 target=out/Path(cpu['path']).name;os.link(cpu['path'],target)
 c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime,CPU_DLL=dict(source=cpu,destination=b.identity(target),hardlink=True),scope='Shared CUDA only; CPU math closure is independently qualified by cpu-link7/run7.'))
 assert all(h.same(x) for x in inputs)
 source=c.read(P/'cuda-ready-for-root.json')['source'] if name=='cuda' else c.read(C/'ready-for-root.json')['source']
 c.save(P/('final-'+name+'-ready.json'),dict(image=b.identity(image),source=source,link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),append_source=fresh['source'],CXX=0,links=1,NVCC=0,SDK_builds=0,GPU_runs=0))
 print('FINAL_READY',name,image,flush=True)
