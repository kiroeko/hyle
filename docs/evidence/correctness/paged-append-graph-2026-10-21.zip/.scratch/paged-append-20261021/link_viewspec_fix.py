"""Replace only two current common objects and the changed test entry TU."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
R = P.parents[1]
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('retained_helpers', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
fresh = {Path(x['source']['path']).name: x for x in c.read(P / 'viewspec-compile.json')['records']}
for x in fresh.values():
    assert h.same(x['source']) and h.same(x['object']) and all(h.same(d) for d in x['dependencies'])
for mode, base_folder in (('qwen', 'final-qwen1'), ('cpu', 'cpu-link7'), ('cuda', 'final-cuda1')):
    base_path = P / base_folder / 'link-plan.json'
    base = c.read(base_path)
    assert all(h.same(x) for x in base['inputs'])
    replacements = {}
    for name, stem in (('batch.cc', 'graph_batch--batch'), ('paged_append.cc', 'graph_batch--paged_append')):
        old = [x for x in base['inputs'] if Path(x['path']).stem == stem]
        assert len(old) == 1
        replacements[c.key(old[0]['path'])] = fresh[name]['object']
    if mode != 'qwen':
        name = 'paged_append_' + ('graph_test.cc' if mode == 'cpu' else 'cuda_consumer.cc')
        old = [x for x in base['inputs'] if Path(x['path']).stem == ('graph_batch--paged_append_graph_test' if mode == 'cpu' else 'cuda-test')]
        assert len(old) == 1
        replacements[c.key(old[0]['path'])] = fresh[name]['object']
    out = P / ('viewspec-' + mode + '1')
    out.mkdir(parents=True, exist_ok=False)
    (out / 'tmp').mkdir()
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']]
    image = out / (mode + '.exe')
    command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x for x in base['command']
               if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs, base=b.identity(base_path),
        replacements=list(replacements.values()), CXX=0, links=1, NVCC=0, SDK_builds=0))
    env, _ = b.environment(command, [x['path'] for x in inputs], out)
    c.execute('link', command, env, out)
    runtime = c.read(P / base_folder / 'runtime-environment.json')
    for dll in (P / base_folder).glob('*.dll'):
        os.link(dll, out / dll.name)
    runtime['staged_dlls'] = [b.identity(p) for p in out.glob('*.dll')]
    runtime['previous_environment'] = b.identity(P / base_folder / 'runtime-environment.json')
    runtime['PATH'] = env['PATH']
    c.save(out / 'runtime-environment.json', runtime)
    source = fresh['paged_append_graph_test.cc' if mode == 'cpu' else 'paged_append_cuda_consumer.cc']['source'] if mode != 'qwen' else c.read(P / 'final-qwen-ready.json')['source']
    c.save(P / ('viewspec-' + mode + '-ready.json'), dict(image=b.identity(image), source=source,
        link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'),
        append_source=fresh['paged_append.cc']['source'], batch_source=fresh['batch.cc']['source'],
        CXX=0, links=1, NVCC=0, SDK_builds=0, GPU_runs=0))
    print('READY', mode, image, flush=True)
