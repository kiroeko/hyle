"""Reuse the verified cache-consumer main; integrate the new common core only."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parents[1];C=R/'.scratch/multi-session-capacity-20261021'
W=R/'.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec=importlib.util.spec_from_file_location('existing_build',W/'build.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
b,c=h.b,h.c
out=P/'qwen-core-link2';out.mkdir(parents=True,exist_ok=False);(out/'tmp').mkdir()
base_path=P/'cuda-check1/link-plan.json';base=c.read(base_path)
assert all(h.same(x) for x in base['inputs'])
obj=c.read(C/'checks/attempt1/identity.json')['object'];assert h.same(obj)
old_inputs=[x for x in base['inputs'] if x['path'].endswith('cuda-test.obj')];assert len(old_inputs)==1
old=c.key(old_inputs[0]['path']);inputs=[obj if c.key(x['path'])==old else x for x in base['inputs']]
image=out/'qwen.exe';link=[obj['path'] if c.key(x)==old else x for x in base['command'] if not x.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
link+=['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
c.save(out/'link-plan.json',dict(command=link,inputs=inputs,base=b.identity(base_path),CXX=0,links=1,NVCC=0,SDK_builds=0))
env,runtime=b.environment(link,[x['path'] for x in inputs],out);c.execute('link',link,env,out)
cpu=c.read(P/'cuda-check1/runtime-environment.json')['CPU_DLL']['destination'];assert h.same(cpu);target=out/Path(cpu['path']).name;os.link(cpu['path'],target)
c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime,CPU_DLL=dict(source=cpu,destination=b.identity(target),hardlink=True)))
assert all(h.same(x) for x in inputs)
c.save(P/'qwen-core-ready-for-root.json',dict(image=b.identity(image),source=c.read(C/'ready-for-root.json')['source'],link_plan=b.identity(out/'link-plan.json'),runtime_environment=b.identity(out/'runtime-environment.json'),CXX=0,links=1,NVCC=0,SDK_builds=0,scope='New shared projection/append core integrated; Qwen still uses original dense Scatter path, no Qwen paged prefix claim.'))
print('QWEN_NEW_CORE_READY',image,flush=True)
