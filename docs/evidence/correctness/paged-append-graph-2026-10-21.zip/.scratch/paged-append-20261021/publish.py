"""Archive this exact ordinary-Graph bridge window, including actual failures."""
from pathlib import Path
import hashlib
import json
import zipfile
P = Path(__file__).resolve().parent
R = P.parents[1]
S = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/multi-session-isolation-2026-10-21'
C = R / '.scratch/multi-session-capacity-20261021'
E = R / 'docs/evidence/correctness'
name = 'paged-append-graph-2026-10-21'
artifact, bundle = E / (name + '.json'), E / (name + '.zip')
assert not artifact.exists() and not bundle.exists()
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def identity(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def same(record): return identity(record['path']) == record
viewspec = read(P / 'viewspec-compile.json')['records']
latest = {Path(x['source']['path']).name: x for x in viewspec}
earlier = read(S / 'paged-append-implementation-2026-10-21/ready-for-root.json')
products = [latest.get(Path(x['source']['path']).name, x) for x in earlier['products']]
for record in products + viewspec:
    assert same(record['source']) and same(record['object'])
    assert all(same(d) for d in record['dependencies'])
results = {}
for mode in ('cpu', 'cuda', 'qwen'):
    ready = read(P / ('viewspec-' + mode + '-ready.json'))
    assert same(ready['image']) and same(ready['source'])
    plan = read(ready['link_plan']['path'])
    assert all(same(x) for x in plan['inputs'])
    run = read(P / ('viewspec-' + mode + '-run1/result.json'))
    assert run['exit'] == 0 and not run.get('timeout') and run['image'] == ready['image']
    results[mode] = dict(ready=ready, run=run,
        stdout=identity(P / ('viewspec-' + mode + '-run1/stdout.log')),
        stderr=identity(P / ('viewspec-' + mode + '-run1/stderr.log')))
summary = read(P / 'viewspec-qwen-run1/summary.json')
assert summary['passed'] and summary['vector_count'] == 72
assert all(pair['byte_equal'] for s in summary['sessions'].values() for pair in s['vectors'])
first_red = read(P / 'final-qwen-run1/result.json')
assert first_red['exit'] == 1
assert 'logical ViewSpec requires specialization' in (P / 'final-qwen-run1/stderr.log').read_text(encoding='utf-8')
files = set()
extensions = {'.json', '.py', '.cc', '.h', '.log', '.diff', '.txt'}
for folder in (P, S / 'paged-append-implementation-2026-10-21', S / 'inputs'):
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix in extensions:
            files.add(path)
for path in (
    S / 'run.py', S / 'qwen-snapshot-next-review.json',
    S.parent / 'multiturn/multiturn_run.py',
    C / 'cpu-runtime-mismatch.json', C / 'cpu-cache-identity-review.json',
    C / 'paged-append-review.json',
    R / '.scratch/perf-review-2026-10-18/cpu-native-causal/commands.json',
    R / '.scratch/perf-review-2026-10-18/cpu-native-causal/ffa4/ops.cpp',
    R / 'src/compute_ggml_runtime/cpu_program.cc',
    R / 'src/compute_ggml_runtime/ggml_native_program_abi.h',
    R / 'src/graph_batch/paged_append.h', R / 'src/graph_batch/CMakeLists.txt',
    R / 'tests/graph_batch/CMakeLists.txt'):
    if path.is_file(): files.add(path)
for record in products + viewspec:
    files.add(Path(record['source']['path']))
for header in earlier['headers']: files.add(Path(header['path']))
for path in (R / 'docs/architecture/compute-design.md', R / 'docs/architecture/graph-design.md'):
    files.add(path)
source_files = [identity(p) for p in sorted(files) if p.suffix in ('.cc', '.h') and not '.scratch' in p.parts]
with zipfile.ZipFile(bundle, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(files): archive.write(path, path.relative_to(R).as_posix())
record = dict(date='2026-10-21',
    scope='Ordinary Graph exact paged append -> causal attention, with original Queue/Invocation/Completion and page lease permissions. Real Qwen common-core regression separately retains existing dense math.',
    throughput_evidence=False, product_sources=source_files, product_compiles=products,
    results=results, qwen_regression=summary,
    mechanism=dict(operation='Typed external effect, one packed new-row input and no tensor outputs; explicit DAG dependency to each actual reader.',
        permission='Original arena/root/generation/dirty-page proof, selected writer and reader artifacts, exact original write/read leases retained by original Graph episode; whole-bank pointer grants no write permission.',
        queue='COW prefix copies and new rows enqueue into the same original QueueSequence; no nested submit, host producer loop, secondary executor or custom kernel.',
        publication='Take only after actual retirement. Whole Graph success authorizes all its append transactions; ready publishes complete exact page frames. Old snapshots remain live.',
        failure='Rejected binding retains caller ownership. Accepted Graph error cannot publish; after retirement take original owners, reset failed writer leases and explicitly discard poisoned pages.',
        budget='PagedArena original backing now uses LeasePool::create so quota is reserved before backing allocation, not Buffer::create then adopt.'),
    coverage=dict(cpu=['F16 and BF16 causal means .3125 then .4 across partial-tail COW and page boundary',
        'logical ViewSpec in original source DAG', 'foreign arena and missing dependency reject without ownership transfer',
        'old partial page remains unchanged', 'accepted write prefix followed by terminal failure retains old head, rejects ready and explicitly recovers pages'],
        cuda=['Actual RTX4070 shared CUDA source, BF16 causal .3125/.4',
            'logical ViewSpec, actual upstream Copy, cross-page COW, unchanged old partial page/NaN tail', 'missing direct dependency rejects without consuming pages'],
        qwen=['One weight bank and compiled family, four real sessions, two retained/active',
            'Six idle evictions,18 original-chunk restore calls/185 restored tokens,84,443,136 requested state-byte peak',
            '72 hidden/logit vectors byte-identical to canonical independently executed baseline; original generated IDs and contexts']),
    failures_preserved=[dict(kind='CPU manual validation closure mismatch',
        diagnosis='Old native CPU DLL did not implement the host HYCA causal descriptor. An independent ready-attention reference was equally noncausal; unchanged numerical oracle. Explicit cached matching plain HYCA native module plus ABI2 selector/baseline object fixes the validation closure. Normal current CMake cache/ABI refresh checked separately, no product cache bug inferred.',
        details=identity(C / 'cpu-runtime-mismatch.json'), normal_build_review=identity(C / 'cpu-cache-identity-review.json')),
        dict(kind='Real Qwen product regression', run=first_red,
        diagnosis='New has_append pre-scan called Graph::operation on logical ViewSpec before specialization. Three batch/custom discovery loops now inspect operation_kind and only retrieve custom Operation descriptors. No math, tolerance, input or specialization behavior relaxed; CPU/CUDA source-DAG fixtures now include logical views.')],
    source_review=read(C / 'paged-append-review.json'),
    pre_fix_independent_review=read(P / 'final-independent-review.json'),
    next_integration_review=read(S / 'qwen-snapshot-next-review.json'),
    limits=['Only shared Compute CPU/CUDA plain F16/BF16 append is implemented; native Apple/Vulkan and encoded cache writes remain pending.',
        'Actual Qwen still uses its original dense Scatter/Ragged state math. Small paged consumers and common-core regression do not prove Qwen shared-prefix inference.',
        'Descriptor fixed rows must be derived from each specialized input before one symbolic finite family can use multiple T shapes.',
        'Fresh/COW pages only, no exclusive in-place append or automatic failed-owner-drop recovery. Original poisoned block has whole-page semantics.',
        'Current singleton/direct-edge selected-artifact proof intentionally rejects wider fused readers/writers. Extending it requires actual physical ports, exact effects and internal ordering proof.',
        'Append is currently not capture-compatible and copies by ranges. No speedup, memory-peak improvement, concurrent GPU batching or service throughput result claimed.',
        'Full KV+conv/GDN+position atomic snapshots/prefix directory, async page retirement, actual MTP and image encoder/projector remain pending.'],
    bundle=identity(bundle), bundle_files=len(files), binary_tensor_payloads_archived=False,
    reproduction='Frozen product/test source, inputs, exact compiler/link/runtime identities, commands, failures, unchanged oracle and raw final logs are archived. Matching existing cached dependencies/model required; no weights, SDK, exes, object files, maps or duplicate endpoint tensor payloads are archived.')
artifact.write_text(json.dumps(record, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
print(identity(artifact))
print(identity(bundle), len(files), 'members')
