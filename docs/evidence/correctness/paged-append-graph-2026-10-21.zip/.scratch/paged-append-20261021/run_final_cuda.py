"""Run final linked ordinary Graph append consumer once; correctness only."""
from pathlib import Path
P = Path(__file__).resolve().parent
source = (P / 'run_cuda_check.py').read_text(encoding='utf-8')
source = source.replace("P / 'cuda-ready-for-root.json'", "P / 'final-cuda-ready.json'")
source = source.replace("P / 'cuda-run1'", "P / 'final-cuda-run1'")
exec(compile(source, str(P / 'run_cuda_check.py'), 'exec'))
