"""Final CUDA fixture now includes an original logical ViewSpec node."""
from pathlib import Path
P = Path(__file__).resolve().parent
source = (P / 'run_cuda_check.py').read_text(encoding='utf-8')
source = source.replace("P / 'cuda-ready-for-root.json'", "P / 'viewspec-cuda-ready.json'")
source = source.replace("P / 'cuda-run1'", "P / 'viewspec-cuda-run1'")
exec(compile(source, str(P / 'run_cuda_check.py'), 'exec'))
