"""Final CPU mixed-DAG consumer, matching explicit ABI2/HYCA native closure."""
from pathlib import Path
P = Path(__file__).resolve().parent
source = (P / 'run_cuda_check.py').read_text(encoding='utf-8')
source = source.replace("P / 'cuda-ready-for-root.json'", "P / 'viewspec-cpu-ready.json'")
source = source.replace("P / 'cuda-run1'", "P / 'viewspec-cpu-run1'")
source = source.replace('Actual shared CUDA Context created by consumer', 'Actual shared CPU Context, explicit ABI2/HYCA native module, plain F16/BF16 only')
source = source.replace('CUDA consumer failed', 'CPU consumer failed')
exec(compile(source, str(P / 'run_cuda_check.py'), 'exec'))
