"""Real-model regression after the confirmed logical-View discovery fix."""
from pathlib import Path
P = Path(__file__).resolve().parent
source = (P / 'qwen_core_check.py').read_text(encoding='utf-8')
source = source.replace("P / 'final-qwen-ready.json'", "P / 'viewspec-qwen-ready.json'")
source = source.replace("P / 'final-qwen-run1'", "P / 'viewspec-qwen-run1'")
exec(compile(source, str(P / 'qwen_core_check.py'), 'exec'))
