"""Root: one CUDA consumer host TU, same current seven core objects, no NVCC."""
from pathlib import Path
import importlib.util
import os
import sys
sys.dont_write_bytecode = True
P = Path(__file__).resolve().parent
R = P.parents[1]
C = R / '.scratch/multi-session-capacity-20261021'
spec = importlib.util.spec_from_file_location('capacity_build_helpers', C / 'build.py')
# Import only its helper module, never execute the prior build's top-level work.
W = R / '.scratch/architecture-refactor-2026-10-18/d4-windows-preparation-2026-10-21/first-decode-startup-2026-10-21/layout-workspace-facts-reuse-2026-10-21'
spec = importlib.util.spec_from_file_location('existing_build', W / 'build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = P / 'cuda-check1'
out.mkdir(parents=True, exist_ok=False)
(out / 'tmp').mkdir()
recipe_path = C / 'checks/attempt1/identity.json'
recipe = c.read(recipe_path)
source = R / 'tests/graph_batch/paged_append_cuda_consumer.cc'
frozen = b.identity(source)
command = b.host_command(recipe['command'], source, 'cuda-test', out)
command.insert(1, '/DHYLE_APPEND_STANDALONE=1')
c.save(out / 'compile-plan.json', dict(command=command, source=frozen, recipe=b.identity(recipe_path), CXX=1, NVCC=0, SDK_builds=0))
env, _ = b.environment(command, [], out)
c.execute('compile', command, env, out)
deps_path = out / 'cuda-test-deps.json'
deps = c.read(deps_path)['Data']
dependencies = [b.identity(p) for p in dict.fromkeys([deps['Source'], *deps['Includes']])]
assert h.same(frozen) and all(h.same(x) for x in dependencies)
obj = b.identity(out / 'cuda-test.obj')
c.save(out / 'identity.json', dict(source=frozen, command=command, object=obj, dependencies=dependencies, source_dependencies=b.identity(deps_path)))
base_path = P / 'cpu-link4/link-plan.json'
base = c.read(base_path)
assert all(h.same(x) for x in base['inputs'])
old_inputs = [x for x in base['inputs'] if 'graph_batch--paged_append_graph_test.obj' in x['path']]
assert len(old_inputs) == 1
old = c.key(old_inputs[0]['path'])
inputs = [obj if c.key(x['path']) == old else x for x in base['inputs']]
image = out / 'append-cuda.exe'
link = [obj['path'] if c.key(x) == old else x for x in base['command'] if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
link += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
c.save(out / 'link-plan.json', dict(command=link, inputs=inputs, base=b.identity(base_path), CXX=1, links=1, NVCC=0, SDK_builds=0, qualification='current sameGraph append core, shared CUDA source; not a CPU-native-math claim'))
env, runtime = b.environment(link, [x['path'] for x in inputs], out)
c.execute('link', link, env, out)
cpu = c.read(P / 'cpu-link4/runtime-environment.json')['CPU_DLL']['destination']
assert h.same(cpu)
target = out / Path(cpu['path']).name
os.link(cpu['path'], target)
c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime, CPU_DLL=dict(source=cpu, destination=b.identity(target), hardlink=True), qualifier='CPU attention is not invoked by this CUDA consumer.'))
assert all(h.same(x) for x in inputs) and all(h.same(x) for x in dependencies)
c.save(P / 'cuda-ready-for-root.json', dict(image=b.identity(image), source=frozen, identity=b.identity(out / 'identity.json'), link_plan=b.identity(out / 'link-plan.json'), runtime_environment=b.identity(out / 'runtime-environment.json'), GPU_runs=0, CXX=1, links=1, NVCC=0, SDK_builds=0))
print('CUDA_APPEND_READY', image, flush=True)
