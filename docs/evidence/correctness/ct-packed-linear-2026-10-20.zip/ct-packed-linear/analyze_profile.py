"""Summarize the real CUDA trace; do not turn a diagnostic into a benchmark."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import xml.etree.ElementTree as ET

stage = Path(__file__).resolve().parent
out = stage / "profile"

def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

for operation in ("profile", "export"):
    result = read(out / (operation + ".result.json"))
    assert result["exit"] == 0, result
xml = ET.parse(out / "results.xml").getroot()
cases = list(xml.iter("testcase"))
assert len(cases) == 1
assert not any(list(case.iter("failure")) or list(case.iter("skipped")) for case in cases)
conn = sqlite3.connect(out / "packed.sqlite")
conn.row_factory = sqlite3.Row

def rows(query):
    return [dict(row) for row in conn.execute(query)]

kernels = rows("SELECT k.*,s.value AS name FROM CUPTI_ACTIVITY_KIND_KERNEL k "
               "JOIN StringIds s ON k.demangledName=s.id ORDER BY start")
api = rows("SELECT r.*,s.value AS name FROM CUPTI_ACTIVITY_KIND_RUNTIME r "
           "JOIN StringIds s ON r.nameId=s.id ORDER BY start")
copies = rows("SELECT m.*,e.name AS copy_name FROM CUPTI_ACTIVITY_KIND_MEMCPY m "
              "LEFT JOIN ENUM_CUDA_MEMCPY_OPER e ON m.copyKind=e.id ORDER BY start")
graph = [row for row in api if "Graph" in row["name"]]
launches = [row for row in graph if row["name"].startswith("cudaGraphLaunch")]
assert len(kernels) == 1, kernels
assert "ct_packed<float, (unsigned int)4>" in kernels[0]["name"]
assert len(launches) == 1 and launches[0]["returnValue"] == 0, launches
assert kernels[0]["correlationId"] == launches[0]["correlationId"]
assert kernels[0]["graphNodeId"] and kernels[0]["graphId"]
assert kernels[0]["staticSharedMemory"] == kernels[0]["dynamicSharedMemory"] == 0
begin, end = launches[0]["start"], kernels[0]["end"]
overlap = lambda row: row["start"] < end and row["end"] > begin
memory_api = [row for row in api if "Alloc" in row["name"] or "Free" in row["name"]]
window_memory = [row for row in memory_api if overlap(row)]
window_copies = [row for row in copies if overlap(row)]
assert not window_memory and not window_copies
summary = dict(
    passed=True,
    recorded_utc=datetime.now(timezone.utc).isoformat(),
    scope="One actual N257,K1024,M3 packed-constant public Graph invocation on RTX4070",
    image=read(out / "runtime.json")["image"],
    profiler=read(out / "runtime.json")["profiler"],
    inputs=[identity(out / name) for name in ("packed.nsys-rep", "packed.sqlite", "results.xml")],
    physical_kernels=kernels,
    graph_runtime=graph,
    copies=copies,
    whole_process_memory_api_counts=dict(Counter(row["name"] for row in memory_api)),
    launch_to_kernel_end_window_ns=dict(start=begin, end=end,
        allocation_or_free_api=window_memory, copies=window_copies),
    conclusions=[
        "Exactly one CT packed kernel is physically executed through cudaGraphLaunch",
        "No independent whole-weight decoder kernel is present in this process trace",
        "No traced allocation/free API or memory copy overlaps this launch-to-kernel-end window",
        "Four fixture H2D input uploads precede launch; one output D2H follows it",
    ],
    limitations=[
        "Single correctness invocation under profiler, not a throughput comparison",
        "The process includes fixture, context, allocation and cleanup operations",
        "An allocation-free launch interval does not prove all prepare/bind phases allocation-free",
        "No full-model artifact payload, quality or total host/device peak measurement",
        "Nsight localMemoryTotal is not a measured whole-model or allocation peak",
    ],
)
(stage / "profile-analysis.json").write_text(
    json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(passed=True, kernels=len(kernels), graph_launches=len(launches),
                     launch_interval_allocations=len(window_memory),
                     launch_interval_copies=len(window_copies))))
