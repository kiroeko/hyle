#include "ct_packed_linear_region.h"

#if defined(HYLE_COMPUTE_TORCH_CUDA)
#include "hyle/compute/providers/torch_cuda.h"
#include "hyle/container/small_vector.h"
#include "hyle/graph/region_provider.h"
#include "../compute/provider_internal.h"
#include "../compute_provider_torch_cuda/ct_packed_linear.h"

#include <algorithm>
#include <array>
#include <limits>
#include <new>
#include <optional>

namespace hyle::graph::cuda::internal {
namespace {
namespace c = compute;
namespace native = c::torch_cuda::internal;
using c::detail::ProviderAccess;
inline constexpr c::RoutePolicyId kPolicy{0x48594c454354504cULL, 1, 1};
inline constexpr std::size_t kMaxNodes = 4;

const c::detail::ProviderVTable &original() noexcept {
  static const auto *table = ProviderAccess::vtable(c::torch_cuda::provider());
  return *table;
}
template <class T>
std::optional<T> operation(const Graph &graph, NodeId node) noexcept {
  if (!node.valid()) return std::nullopt;
  const auto op = graph.operation(node);
  if (!op) return std::nullopt;
  const auto *value = op->get_if<T>();
  return value ? std::optional<T>{*value} : std::nullopt;
}
NodeId producer(const Graph &graph, ValueId value) noexcept {
  if (value.kind() != ValueKind::kNodeOutput) return {};
  const auto node = graph.producer(value);
  return node ? *node : NodeId{};
}
bool arity(const Graph &graph, NodeId node, std::size_t inputs) noexcept {
  if (!node.valid()) return false;
  const auto in = graph.node_input_count(node), out = graph.node_output_count(node),
             resources = graph.node_resource_count(node);
  return in && out && resources && *in == inputs && *out == 1 && *resources == 0;
}

// One cold reader index; neither permissions nor payload addresses are cached.
struct Uses final {
  container::SmallVector<std::uint8_t, 16, mem::AllocatorRef> data;
  container::SmallVector<NodeId, 16, mem::AllocatorRef> reader;
  container::SmallVector<std::size_t, 16, mem::AllocatorRef> control;
  explicit Uses(mem::AllocatorRef allocator) noexcept
      : data(allocator), reader(allocator), control(allocator) {}
  Status initialize(const Graph &graph) noexcept {
    if (!data.try_resize(graph.value_count()) || !reader.try_resize(graph.value_count()) ||
        !control.try_resize(graph.node_count()))
      return Status::ResourceExhausted("CT packed region discovery metadata allocation failed");
    std::ranges::fill(data, std::uint8_t{0});
    std::ranges::fill(reader, NodeId{});
    std::ranges::fill(control, std::size_t{0});
    for (std::size_t i = 0; i < graph.node_count(); ++i) {
      HYLE_ASSIGN_OR_RETURN(auto node, graph.node_id(i));
      HYLE_ASSIGN_OR_RETURN(auto inputs, graph.node_input_count(node));
      for (std::size_t n = 0; n < inputs; ++n) {
        HYLE_ASSIGN_OR_RETURN(auto value, graph.node_input(node, n));
        auto &count = data[value.ordinal()];
        if (count == 0) reader[value.ordinal()] = node;
        if (count < 2) ++count;
      }
      HYLE_ASSIGN_OR_RETURN(auto dependencies, graph.node_dependency_count(node));
      for (std::size_t n = 0; n < dependencies; ++n) {
        HYLE_ASSIGN_OR_RETURN(auto before, graph.node_dependency(node, n));
        if (control[before.ordinal()] == SIZE_MAX)
          return Status::OutOfRange("CT packed control reader count overflows");
        ++control[before.ordinal()];
      }
    }
    for (std::size_t n = 0; n < graph.output_count(); ++n) {
      HYLE_ASSIGN_OR_RETURN(auto value, graph.output_id(n));
      data[value.ordinal()] = 2;
    }
    return Status::Ok();
  }
};
struct Pattern final {
  std::array<NodeId, kMaxNodes> nodes{};
  std::size_t size = 0;
  std::array<ValueId, 4> inputs{}; // Original A,codes[,Z],scale.
  std::size_t input_count = 0;
  ValueId output{};
  native::CtPackedLinear descriptor{};
  std::span<const NodeId> span() const noexcept { return {nodes.data(), size}; }
  bool contains(NodeId node) const noexcept {
    return std::ranges::find(span(), node) != span().end();
  }
  void append(NodeId node) noexcept { nodes[size++] = node; }
  std::size_t boundary_count() const noexcept {
    std::size_t count = 0;
    for (std::size_t n = 0; n < input_count; ++n) {
      const auto prefix = std::span(inputs).first(n);
      count += std::ranges::find(prefix, inputs[n]) == prefix.end();
    }
    return count;
  }
  c::Operation composite() const noexcept { return c::Operation::custom(descriptor); }
};

bool pattern(const Graph &graph, NodeId matrix, Pattern &p) noexcept {
  const auto mm = operation<c::MatMul>(graph, matrix);
  if (!mm || !arity(graph, matrix, 2) || mm->accumulation_type != c::DataType::kFloat32)
    return false;
  const auto activation = graph.node_input(matrix, 0).value();
  const auto weight = graph.node_input(matrix, 1).value();
  const auto operand = graph.value_description(weight);
  if (!operand || operand->rank() != 2) return false;

  auto value = weight;
  NodeId after_cast;
  auto node = producer(graph, value);
  if (operation<c::Cast>(graph, node)) {
    if (!arity(graph, node, 1)) return false;
    after_cast = node;
    value = graph.node_input(node, 0).value();
  }
  const auto transpose = producer(graph, value);
  const auto view = operation<c::View>(graph, transpose);
  if (!view || !arity(graph, transpose, 1) || view->kind() != c::ViewKind::kPermute)
    return false;
  const auto axes = view->permutation();
  if (axes.size() != 2 || (axes[0] != 1 && axes[0] != -1) ||
      (axes[1] != 0 && axes[1] != -2)) return false;
  value = graph.node_input(transpose, 0).value();
  const auto before_view = graph.value_description(value);
  const auto after_view = graph.value_description(graph.result(transpose).value());
  if (!before_view || !after_view || before_view->rank() != 2) return false;
  const auto expected_view = before_view->transposed();
  if (!expected_view || *expected_view != *after_view) return false;

  NodeId before_cast;
  node = producer(graph, value);
  if (operation<c::Cast>(graph, node)) {
    if (after_cast.valid() || !arity(graph, node, 1)) return false;
    before_cast = node;
    value = graph.node_input(node, 0).value();
  }
  const auto decode = producer(graph, value);
  if (!decode.valid()) return false;
  const auto decode_operation = graph.operation(decode);
  if (!decode_operation) return false;
  const auto artifact = decode_operation->custom_as<c::model_ops::ArtifactWeightDecode>();
  if (!artifact ||
      (artifact->format != c::model_ops::WeightArtifactFormat::kCompressedTensorsSymmetric4 &&
       artifact->format != c::model_ops::WeightArtifactFormat::kCompressedTensorsAsymmetric4))
    return false;
  const auto count = artifact->operation_traits().inputs.minimum;
  if (!arity(graph, decode, count)) return false;
  const auto decoded = graph.value_description(value);
  if (!decoded || decoded->rank() != 2) return false;
  p.descriptor = {artifact->format, artifact->group_size, decoded->data_type(), operand->data_type()};
  p.inputs[0] = activation;
  p.input_count = std::size_t(count) + 1;
  for (std::size_t n = 0; n < count; ++n)
    p.inputs[n + 1] = graph.node_input(decode, n).value();
  p.output = graph.result(matrix).value();
  p.append(decode);
  if (before_cast.valid()) p.append(before_cast);
  p.append(transpose);
  if (after_cast.valid()) p.append(after_cast);
  p.append(matrix);
  std::ranges::sort(std::span(p.nodes).first(p.size), {}, &NodeId::ordinal);
  return true;
}
bool closed(const Graph &graph, const Pattern &p, const Uses &uses,
            std::span<const std::uint8_t> allowed) noexcept {
  const auto terminal = producer(graph, p.output);
  for (const auto node : p.span()) {
    if (!allowed.empty() && !allowed[node.ordinal()]) return false;
    if (node == terminal) continue;
    const auto output = graph.result(node).value();
    if (uses.data[output.ordinal()] != 1 || !p.contains(uses.reader[output.ordinal()]))
      return false;
    std::size_t internal_controls = 0;
    for (const auto after : p.span())
      for (std::size_t n = 0; n < graph.node_dependency_count(after).value(); ++n)
        internal_controls += graph.node_dependency(after, n).value() == node;
    if (uses.control[node.ordinal()] != internal_controls) return false;
  }
  return true;
}

struct Artifact final {
  c::detail::ProviderPrepared native;
  std::array<std::size_t, 4> ports{};
  std::size_t count = 0, boundary_count = 0;
};
struct Invocation final {
  const c::detail::ProviderPreparedVTable *vtable = nullptr;
  void *state = nullptr;
};
Status native_proposal(void *context, const Graph &graph, const Pattern &p,
    std::array<c::TensorDesc, 4> &inputs, c::TensorDesc &output,
    std::array<c::detail::ResourceBindingRequirement, 4> &requirements,
    c::detail::ResourceBindingRequirement &destination,
    c::detail::ProviderOperationProposal &proposal, const c::WorkloadContext &workload = {}) noexcept {
  for (std::size_t n = 0; n < p.input_count; ++n)
    inputs[n] = graph.value_description(p.inputs[n]).value();
  output = graph.value_description(p.output).value();
  std::array<c::TensorDesc, 1> inferred;
  const auto op = p.composite();
  HYLE_RETURN_IF_ERROR(c::infer_output_descriptions(op, std::span(inputs).first(p.input_count), inferred));
  if (inferred[0] != output)
    return Status::Unimplemented("CT packed composite output differs from the public graph");
  HYLE_RETURN_IF_ERROR(original().propose(context,
      {.operation = op, .inputs = std::span(inputs).first(p.input_count),
       .outputs = std::span(&output, 1), .workload = workload},
      std::span(requirements).first(p.input_count), std::span(&destination, 1), &proposal));
  if (proposal.cost.persistent_bytes) {
    if (*proposal.cost.persistent_bytes > SIZE_MAX - sizeof(Artifact))
      return Status::OutOfRange("CT packed region metadata bytes overflow");
    *proposal.cost.persistent_bytes += sizeof(Artifact);
  }
  return Status::Ok();
}
Status propose(void *context, const RegionDiscoveryRequest &request,
    mem::AllocatorRef allocator, RegionProposalWriter &writer) noexcept {
  const auto &graph = request.graph;
  if (!request.allowed_nodes.empty() && request.allowed_nodes.size() != graph.node_count())
    return Status::InvalidArgument("CT packed allowed-node count differs");
  Uses uses(allocator);
  HYLE_RETURN_IF_ERROR(uses.initialize(graph));
  for (std::size_t i = 0; i < graph.node_count(); ++i) {
    HYLE_ASSIGN_OR_RETURN(auto node, graph.node_id(i));
    Pattern p;
    if (!pattern(graph, node, p) || !closed(graph, p, uses, request.allowed_nodes)) continue;
    std::array<c::TensorDesc, 4> inputs;
    c::TensorDesc output;
    std::array<c::detail::ResourceBindingRequirement, 4> requirements;
    c::detail::ResourceBindingRequirement destination;
    c::detail::ProviderOperationProposal proposal;
    const auto status = native_proposal(context, graph, p, inputs, output, requirements, destination, proposal);
    if (!status.ok()) {
      if (status.IsUnimplemented() || status.IsInvalidArgument()) continue;
      return status;
    }
    HYLE_ASSIGN_OR_RETURN(auto more, writer.try_add({.nodes = p.span(), .cost = proposal.cost,
        .route = 1, .replay_class = proposal.runtime.replay_class,
        .implementation = c::ProviderImplementationId{1}, .policy = kPolicy, .preference = 200}));
    if (!more) return Status::Ok();
  }
  return Status::Ok();
}

// Only the chosen bounded node set is reconstructed here. Graph's exact
// boundary/contractibility check preserves escapes; discovery checked readers.
Status qualify(const RegionCompileRequest &request, Pattern &result) noexcept {
  if (!request.graph || request.route != 1 || request.outputs.size() != 1 ||
      request.nodes.size() < 3 || request.nodes.size() > kMaxNodes ||
      request.has_unknown_effects || !request.effect_accesses.empty())
    return Status::Unimplemented("CT packed region boundary differs");
  for (const auto node : request.nodes) {
    Pattern p;
    if (!pattern(*request.graph, node, p) || p.size != request.nodes.size() ||
        p.output != request.outputs[0] || p.boundary_count() != request.inputs.size()) continue;
    const auto logical_inputs = std::span(p.inputs).first(p.input_count);
    if (!std::ranges::all_of(p.span(), [&](NodeId id) {
          return std::ranges::count(request.nodes, id) == 1;
        }) || !std::ranges::all_of(request.inputs, [&](ValueId id) {
          return std::ranges::find(logical_inputs, id) != logical_inputs.end();
        })) continue;
    result = p;
    return Status::Ok();
  }
  return Status::Unimplemented("CT packed region does not preserve the exact public recipe");
}
bool same_requirement(const c::ResourceRequirement &a, const c::ResourceRequirement &b) noexcept {
  return a.required_properties == b.required_properties && a.forbidden_properties == b.forbidden_properties &&
      a.minimum_alignment == b.minimum_alignment && a.exact_resource == b.exact_resource &&
      a.exact_domain == b.exact_domain && a.requires_exact_domain == b.requires_exact_domain;
}
Status resources(void *context, const RegionCompileRequest &request, mem::AllocatorRef,
    std::span<RegionInputRequirement> inputs, std::span<RegionOutputRequirement> outputs,
    RegionResourceProposal *result) noexcept {
  *result = {};
  Pattern p;
  HYLE_RETURN_IF_ERROR(qualify(request, p));
  if (inputs.size() != request.inputs.size() || outputs.size() != 1)
    return Status::InvalidArgument("CT packed resource count differs");
  std::array<c::TensorDesc, 4> descriptions;
  c::TensorDesc output;
  std::array<c::detail::ResourceBindingRequirement, 4> requirements;
  c::detail::ResourceBindingRequirement destination;
  c::detail::ProviderOperationProposal proposal;
  HYLE_RETURN_IF_ERROR(native_proposal(context, *request.graph, p, descriptions, output,
      requirements, destination, proposal, request.workload));
  const auto logical_inputs = std::span(p.inputs).first(p.input_count);
  for (std::size_t port = 0; port < request.inputs.size(); ++port) {
    const auto first = std::size_t(std::ranges::find(
        logical_inputs, request.inputs[port]) - logical_inputs.begin());
    for (std::size_t n = first + 1; n < p.input_count; ++n)
      if (p.inputs[n] == request.inputs[port] && !same_requirement(requirements[first], requirements[n]))
        return Status::Unimplemented("CT packed shared port has different native resource requirements");
    inputs[port] = {.resource = requirements[first]};
  }
  outputs[0] = {.resource = destination};
  *result = {.runtime = proposal.runtime, .workspace_resource = proposal.workspace_resource,
      .compilation_storage = proposal.cost.compilation_storage};
  return Status::Ok();
}

void destroy(void *value, mem::AllocatorRef allocator) noexcept {
  auto *a = static_cast<Artifact *>(value);
  if (!a) return;
  if (a->native.vtable && a->native.vtable->destroy_prepared)
    a->native.vtable->destroy_prepared(a->native.state, allocator);
  a->~Artifact(); allocator.deallocate(a, sizeof(Artifact), alignof(Artifact));
}
c::AliasSupport alias(void *value, std::size_t output, std::size_t input) noexcept {
  auto &a = *static_cast<Artifact *>(value);
  for (std::size_t n = 0; n < a.count; ++n)
    if (a.ports[n] == input) return a.native.vtable->alias_support(a.native.state, output, n);
  return {};
}
Status create_invocation(void *value, mem::AllocatorRef allocator, mem::BufferView workspace,
                         void **output) noexcept {
  *output = nullptr;
  auto &a = *static_cast<Artifact *>(value);
  void *storage = allocator.allocate(sizeof(Invocation), alignof(Invocation));
  if (!storage) return Status::ResourceExhausted("CT packed region invocation allocation failed");
  auto *invocation = ::new (storage) Invocation{a.native.vtable, nullptr};
  *output = invocation;
  return a.native.vtable->create_invocation(a.native.state, allocator, workspace, &invocation->state);
}
void destroy_invocation(void *value, mem::AllocatorRef allocator) noexcept {
  auto *i = static_cast<Invocation *>(value);
  if (!i) return;
  if (i->state) i->vtable->destroy_invocation(i->state, allocator);
  i->~Invocation(); allocator.deallocate(i, sizeof(Invocation), alignof(Invocation));
}
c::detail::EnqueueResult submit(void *value, void *lane, c::detail::QueueSequence &sequence,
    std::span<const c::ConstTensorView> inputs, std::span<const c::TensorView> outputs) noexcept {
  const auto &a = *static_cast<Artifact *>(value);
  if (inputs.size() != a.boundary_count || outputs.size() != 1)
    return c::detail::EnqueueResult::rejected(Status::InvalidArgument("CT packed submit port count differs"));
  std::array<c::ConstTensorView, 4> ordered;
  for (std::size_t n = 0; n < a.count; ++n) ordered[n] = inputs[a.ports[n]];
  return a.native.vtable->shared_submit(a.native.state, static_cast<Invocation *>(lane)->state,
      sequence, std::span(ordered).first(a.count), outputs);
}
const ProviderRegionPreparedVTable kPrepared{
    .destroy_prepared = &destroy, .alias_support = &alias, .create_invocation = &create_invocation,
    .destroy_invocation = &destroy_invocation, .shared_submit = &submit};

c::ProviderPrepareOutcome compile(void *context, const RegionCompileRequest &request,
    mem::AllocatorRef allocator, ProviderRegionPrepared *result) noexcept {
  *result = {};
  Pattern p;
  const auto qualification = qualify(request, p);
  if (!qualification.ok()) return c::ProviderPrepareOutcome::unsupported(qualification);
  if (request.input_resources.size() != request.inputs.size() || request.output_resources.size() != 1)
    return c::ProviderPrepareOutcome::error(Status::InvalidArgument("CT packed physical resource count differs"));
  std::array<c::TensorDesc, 4> inputs;
  c::TensorDesc output;
  std::array<c::detail::ResourceBindingRequirement, 4> requirements;
  c::detail::ResourceBindingRequirement destination;
  c::detail::ProviderOperationProposal proposal;
  const auto status = native_proposal(context, *request.graph, p, inputs, output,
      requirements, destination, proposal, request.workload);
  if (!status.ok()) return status.IsUnimplemented() ? c::ProviderPrepareOutcome::unsupported(status)
                                                  : c::ProviderPrepareOutcome::error(status);
  if (!proposal.cost.dispatch_count || !proposal.cost.copy_bytes || !proposal.cost.synchronization_count ||
      proposal.runtime.mode != c::ProviderRuntimeMode::kSharedQueue)
    return c::ProviderPrepareOutcome::error(Status::Internal("CT packed native runtime facts are incomplete"));
  void *storage = allocator.allocate(sizeof(Artifact), alignof(Artifact));
  if (!storage) return c::ProviderPrepareOutcome::error(
      Status::ResourceExhausted("CT packed region artifact allocation failed"));
  auto *a = ::new (storage) Artifact;
  a->count = p.input_count;
  a->boundary_count = request.inputs.size();
  std::array<mem::MemoryResourceRef, 4> resources;
  for (std::size_t n = 0; n < a->count; ++n) {
    a->ports[n] = std::size_t(std::ranges::find(request.inputs, p.inputs[n]) - request.inputs.begin());
    resources[n] = request.input_resources[a->ports[n]];
  }
  const auto outcome = original().prepare(context,
      {.operation = p.composite(), .inputs = std::span(inputs).first(a->count),
       .outputs = std::span(&output, 1), .input_resources = std::span(resources).first(a->count),
       .output_resources = request.output_resources, .workspace_resource = request.workspace_resource,
       .route = proposal.route, .workload = request.workload}, allocator, &a->native);
  if (outcome.kind != c::ProviderPrepareOutcomeKind::kPrepared) {
    destroy(a, allocator);
    return outcome;
  }
  if (!a->native.vtable || !a->native.vtable->destroy_prepared || !a->native.vtable->alias_support ||
      !a->native.vtable->create_invocation || !a->native.vtable->destroy_invocation ||
      !a->native.vtable->shared_submit || a->native.vtable->prepare_bindings) {
    destroy(a, allocator);
    return c::ProviderPrepareOutcome::error(Status::Internal("CT packed native artifact requires an unsupported binding route"));
  }
  auto persistent = a->native.persistent_bytes;
  if (persistent) {
    if (*persistent > SIZE_MAX - sizeof(Artifact)) {
      destroy(a, allocator);
      return c::ProviderPrepareOutcome::error(Status::OutOfRange("CT packed region metadata bytes overflow"));
    }
    *persistent += sizeof(Artifact);
  }
  *result = {.vtable = &kPrepared, .state = a,
      .properties = {.workspace = a->native.workspace, .persistent_bytes = persistent,
          .copy_bytes = *proposal.cost.copy_bytes, .synchronization_count = *proposal.cost.synchronization_count,
          .dispatch_count = *proposal.cost.dispatch_count, .runtime = a->native.runtime,
          .invocation_private_bytes = a->native.invocation_private_bytes}};
  return outcome;
}
const RegionProviderVTable kRegion{.propose = &propose, .propose_resources = &resources, .compile = &compile};
const void *query_extension(void *context, c::ProviderExtensionId id) noexcept {
  if (id == kRegionProviderExtensionId) return &kRegion;
  return original().query_extension ? original().query_extension(context, id) : nullptr;
}
const c::detail::ProviderVTable &decorated() noexcept {
  static const auto table = [] {
    auto value = original(); value.query_extension = &query_extension; return value;
  }();
  return table;
}
} // namespace

c::Provider ct_packed_linear_provider() noexcept {
  return ProviderAccess::with_vtable(c::torch_cuda::provider(), &decorated());
}
} // namespace hyle::graph::cuda::internal
#else
namespace hyle::graph::cuda::internal {
compute::Provider ct_packed_linear_provider() noexcept { return {}; }
} // namespace hyle::graph::cuda::internal
#endif
