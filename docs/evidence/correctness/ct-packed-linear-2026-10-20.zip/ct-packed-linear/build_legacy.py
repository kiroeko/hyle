"""Refresh one existing MLX regression TU against the final current CUDA owners."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
root = stage.parents[2]
spec = importlib.util.spec_from_file_location(
    "ct_legacy_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = stage / "checks/legacy-mlx"
out.mkdir(parents=True, exist_ok=False)
(out / "tmp").mkdir()
base = c.read(stage / "checks/attempt2/link-plan.json")
old = c.read(stage.parent / "mlx-affine-widths/cuda/checks/20261019T135721/packed-test-identity.json")
source = root / "tests/compute_provider_torch_cuda/packed_test.cc"
command = b.host_command(old["command"], source, "legacy-mlx-tests", out)
env, runtime = b.environment(base["command"], [p["path"] for p in base["inputs"]], out)
c.save(out / "runtime-environment.json", dict(runtime=runtime, PATH=env["PATH"]))
before = b.identity(source)
c.execute("compile", command, env, out)
assert b.same(before)
deps = c.read(out / "legacy-mlx-tests-deps.json")["Data"]
obj = b.identity(out / "legacy-mlx-tests.obj")
c.save(out / "test-identity.json", dict(command=command, source=before, object=obj,
    dependencies=[b.identity(p) for p in dict.fromkeys([deps["Source"], *deps["Includes"]])]))
target = c.read(stage / "checks/attempt2/tests--graph_route_cuda--ct_packed_linear_test-identity.json")["object"]
lookup = {c.key(p["path"]): p for p in base["inputs"]}
assert target in base["inputs"]
for item in base["inputs"]:
    assert b.same(item), item["path"]
command = [obj["path"] if c.key(arg) == c.key(target["path"]) else arg
           for arg in base["command"] if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
image = out / "ct-packed-tests.exe"
command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
            "/IMPLIB:" + str(image.with_suffix(".lib"))]
lookup[c.key(obj["path"])] = obj
inputs = [p for p in command if Path(p).is_absolute() and Path(p).suffix.lower() in (".obj", ".lib")]
c.execute("link", command, env, out)
c.save(out / "link-plan.json", dict(command=command, inputs=[lookup[c.key(p)] for p in inputs]))
c.save(out / "image.json", b.identity(image))
c.save(out / "plan.json", dict(source=before, SDK_build=False, fresh_test_TUs=1,
    product_TUs=0, baseline=str(stage / "checks/attempt2/link-plan.json")))
print("LEGACY_MLX_BUILT", image, flush=True)
