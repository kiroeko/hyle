"""Keep actual CT evidence and source history without copying build/SDK payloads."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

stage = Path(__file__).resolve().parent
root = stage.parents[2]
forwarding = stage.parent / "prepared-forwarding"
parser = argparse.ArgumentParser()
parser.add_argument("--build", type=Path, required=True)
parser.add_argument("--run", required=True)
args = parser.parse_args()
build = args.build.resolve()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")

def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def matches(item, path=None):
    path = Path(item["path"]) if path is None else path
    return (path.is_file() and path.stat().st_size == item["bytes"] and
            identity(path)["sha256"] == item["sha256"])

actual = read(stage / "runs" / args.run / "summary.json")
initial = read(stage / "runs/second-actual/summary.json")
legacy = read(stage / "runs/legacy-mlx/summary.json")
profile = read(stage / "profile-analysis.json")
ptx = read(stage / "ptx-math-check-final.json")
for item, count in ((actual, 8), (initial, 4), (legacy, 5)):
    assert item["passed"] and item["cases"] == count and item["skipped"] == 0
    assert matches(item["image"]), item["image"]
assert actual["image"] == read(build / "image.json")
assert profile["passed"] and ptx["passed"]
assert len(profile["physical_kernels"]) == 1
assert profile["image"] == initial["image"]
properties = actual["properties"]["OriginalPackedConstantsDoNotRetainOrWorkspaceADenseWeightBank"]
assert properties == dict(compiled_known_bytes="1512", workspace_bytes="0",
                          excluded_dense_f32_bank_bytes="1052672"), properties

plan = read(build / "plan.json")
forwarding_freeze = read(forwarding / "source-freeze.json")
forwarding_review = read(forwarding / "independent-review.json")
assert all(row["match"] for row in forwarding_review["files"])
assert all(row["byte_text_equal"] for row in forwarding_review["unchanged_mathematical_and_resource_sections"])
assert identity(forwarding / "source-freeze.json")["sha256"] == forwarding_review["freeze"]["sha256"]
for row in forwarding_freeze["files"]:
    assert matches(row["current"]) and matches(row["after"])
compile_results = [read(p) for p in build.glob("*-compile.result.json")]
assert all(row["exit"] == 0 for row in compile_results)
save(stage / "cache-reuse-correction.json", dict(
    issue="A reused receipt points to an older object/command directory; normalizing against the copied receipt directory caused avoidable recompilation",
    correction="Normalize cached commands against the actual cached object directory; retain original source/dependency/command equality checks",
    actual_fresh_host_owners=6, actual_fresh_native_owners=1, cached_test_owners=2,
    actual_compile_processes=len(compile_results), SDK_rebuilt=False,
    note="Already running incremental commands were observed through their actual terminal handles, not restarted; no extra verification run was added"))
current_checks = []
for item in plan["frozen"]:
    relative = Path(item["path"]).relative_to(root)
    snapshot = build / "compiled-source" / relative
    assert matches(item) and matches(item, snapshot), relative
    current_checks.append(dict(source=item, snapshot=identity(snapshot)))
historical_checks = []
for name in ("attempt1", "attempt2"):
    old = stage / "checks" / name
    for item in read(old / "plan.json")["frozen"]:
        snapshot = old / "compiled-source" / Path(item["path"]).relative_to(root)
        assert matches(item, snapshot), snapshot
        historical_checks.append(dict(attempt=name, source=item, snapshot=identity(snapshot)))

docs = ["docs/user/compute.md", "docs/implementation/model-operators.md",
        "docs/implementation/model-quantizations.json", "docs/developer/current-work.md"]
doc_changes = read(stage / "docs-agent-result.json")
for item in doc_changes["files"]:
    assert matches(item, root / item["path"]), item
quant = read(root / docs[2])
def visit(value):
    if isinstance(value, dict):
        yield value
        for v in value.values():
            yield from visit(v)
    elif isinstance(value, list):
        for v in value:
            yield from visit(v)
flags = [v["artifact_execution_verified"] for v in visit(quant)
         if "artifact_execution_verified" in v]
assert len(flags) == 33 and not any(flags)

files = sorted({str(Path(item["path"]).relative_to(root)) for item in plan["frozen"]} | set(docs))
check = subprocess.run(["git", "diff", "--check", "--", *files], cwd=root,
                       capture_output=True, text=True)
save(stage / "diff-check.json", dict(command=check.args, exit=check.returncode,
    stdout=check.stdout, stderr=check.stderr))
assert check.returncode == 0
for rel in files:
    source = root / rel
    target = stage / "final-source" / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)

root_check = dict(passed=True, recorded_utc=datetime.now(timezone.utc).isoformat(),
    scope="CT packed implementation plus private mapped Prepared forwarding only",
    current_compiled_source=current_checks, historical_compiled_source=historical_checks,
    final_image=actual["image"], initial_graph=initial, after_forwarding=actual,
    forwarding_source_freeze=identity(forwarding / "source-freeze.json"),
    forwarding_independent_review=identity(forwarding / "independent-review.json"),
    actual_fresh_host_owners=6, actual_fresh_native_owners=1,
    related_MLX=legacy, trace_image=profile["image"],
    current_docs=[identity(root / p) for p in docs],
    selected_artifact_execution_flags=dict(count=len(flags), all_false=True),
    diff_check_exit=check.returncode, no_SDK_rebuild=True,
    full_goal_status="active")
save(stage / "root-final-check.json", root_check)

destination = root / "docs/evidence/correctness/ct-packed-linear-2026-10-20.zip"
assert not destination.exists(), destination
suffixes = {".json", ".py", ".cc", ".h", ".cu", ".cmake", ".txt", ".xml",
            ".log", ".diff", ".ps1", ".md", ".nsys-rep", ".sqlite", ".d"}
selected = {}
for base in (stage, forwarding):
    for path in base.rglob("*"):
        if path.is_file() and path.suffix.lower() in suffixes and "tmp" not in path.relative_to(base).parts:
            selected[base.name + "/" + path.relative_to(base).as_posix()] = path
support = [
    "include/hyle/compute/prepared_operation.h", "include/hyle/graph/region_provider.h",
    "src/compute/provider_internal.h", "src/graph_route_cuda/dense_bfloat_scores_region.h",
    "tests/compute_provider_native/half_test_support.h", "third_party/mlx_cuda_quant/mlx_cuda_quant.h",
    "cmake/HyleDependencyLock.json", "THIRD_PARTY_NOTICES.md", "third_party/mlx_cuda_quant/NOTICE.md",
    ".scratch/architecture-refactor-2026-10-18/grouped-shared-activation/build_host.py",
    ".scratch/architecture-refactor-2026-10-18/gguf-nvfp4/windows-host/build.py",
    ".scratch/architecture-refactor-2026-10-18/ct-asymmetric-int4/windows-host/build.py",
    ".scratch/architecture-refactor-2026-10-18/view-projection-reuse/build.py",
    ".scratch/architecture-refactor-2026-10-18/cccl-single-row-topk/build_host.py",
    ".scratch/architecture-refactor-2026-10-18/cold-constant-retirement/cold_check.py",
]
for rel in support:
    source = root / rel
    assert source.is_file(), source
    selected["support/" + rel] = source
manifest = {name: dict(bytes=path.stat().st_size, sha256=identity(path)["sha256"])
            for name, path in sorted(selected.items())}
with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, path in sorted(selected.items()):
        z.write(path, name)
    z.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(manifest) | {"manifest.json"}
    for name, item in manifest.items():
        data = z.read(name)
        assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"]
archive = dict(**identity(destination), payload_files=len(manifest),
               CRC_and_payload_hashes_verified=True, SDK_executable_object_or_library_payloads=False,
               actual_Nsight_trace_and_SQLite_included=True)
report = dict(passed=True, recorded_utc=datetime.now(timezone.utc).isoformat(),
    scope="CT symmetric/asymmetric INT4 packed CUDA linear and backend-local Prepared sharing; not overall architecture completion",
    changes=[
        "Ordinary public same-graph Decode[/Cast]/exact transpose View/MatMul can contract to original packed CT input execution",
        "Preserve scale-type product rounding, decode-type cast, actual operand-type cast, F32 accumulation and output rounding; the reduction tree may differ from dense MatMul",
        "Three/four semantic inputs share deduplicated Graph boundaries; escape/published/extra-reader chains retain the original decomposition",
        "One packed kernel; no retained whole dense weight bank, workspace, repack or implicit ATen temporary in this native path",
        "A single private mapped Prepared helper replaces actual duplicate CT/scorer ownership, alias translation, partial cleanup and shared_submit forwarding",
        "Public operations, shared Graph executor and caller-owned resource/permission contracts unchanged",
    ],
    hardware=dict(gpu="NVIDIA GeForce RTX4070", device_memory_MiB=12282,
                  driver="617.14", CUDA="13.3", target="compute89/sm89", host="MSVC14.50.35717"),
    results=dict(initial_CT_cases=4, related_MLX_cases=5,
        after_private_forwarding_CT_plus_dense_scorer_cases=8, all_actual_cases_skipped=0,
        actual_final_image=actual["image"], actual_trace_image=profile["image"]),
    physical_trace=dict(kernels=1, graph_launches=1,
        kernel=profile["physical_kernels"][0]["name"], launch_interval_allocation_or_free_API=0,
        launch_interval_copies=0, inputs_H2D=4, output_D2H=1,
        interpretation="One correctness invocation before the mechanical forwarding extraction; not a throughput benchmark or proof all prepare/bind phases allocate nothing"),
    space_fixture=dict(M=3, N=257, K=1024, compiled_known_metadata_and_storage_bytes=1512,
        caller_workspace_bytes=0, excluded_dense_F32_bank_bytes=1052672,
        interpretation="Known compiled metadata/storage excludes caller-borrowed packed inputs; not total device/host memory or measured peak"),
    emitted_code=dict(CT_entries=6, explicit_mul_rn_F32=True, explicit_FMA_rn_F32=True,
        explicit_F16_BF16_RNE=True, FTZ_modifier_present=False,
        interpretation="Actual emitted compute89 PTX only, not exhaustive float/subnormal payload coverage"),
    preserved_failures=[
        "Pre-build test output fixture used immutable adopted buffers; corrected to existing public LeasePool mutable writers",
        "First actual run: 1/4 passed; Direct ATen fixture supplied workspace to a provider-owned route and dynamic fixture changed the fixed StorageDomain",
        "Corrected fixture ownership/workspace calls without changing numeric oracle or tolerance; final CT 4/4 passed",
        "Earlier review double-counted allocator-backed Invocation metadata as outside-allocator private bytes; public contract reread, mistaken judgment withdrawn and original snapshots retained",
    ],
    limitations=[
        "Selected publisher 27B tensor payload/importer/full-model execution, quality, throughput and peak memory not verified",
        "Small shared operation fixtures primarily group32; this batch does not execute all supported natural groups or model roles",
        "This warp-row packed carrier is not a mature tensor-core prefill GEMM; no all-shape speedup claimed",
        "CPU/Apple/Vulkan CT packed execution, GPTQ/permutation/other packing, W4A4 and packed expert/FFN remain separate gaps",
        "A separately cold-decoded dense constant has no original codec recipe for automatic packed contraction",
        "No Linux run, updated full-Qwen throughput or whole-model numerical quality acceptance in this batch",
    ],
    root_checks="root-final-check.json in archive", full_goal_status="active",
    evidence_archive=archive)
save(root / "docs/evidence/correctness/ct-packed-linear-2026-10-20.json", report)
save(stage / "publication.json", dict(archive=archive,
    report=identity(root / "docs/evidence/correctness/ct-packed-linear-2026-10-20.json")))
print(json.dumps(dict(passed=True, files=len(manifest), archive_bytes=archive["bytes"],
                     current_CT_and_dense_cases=actual["cases"])))
