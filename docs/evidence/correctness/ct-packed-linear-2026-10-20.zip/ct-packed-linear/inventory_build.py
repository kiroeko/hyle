"""Locate the real cached CUDA link closure and exact changed-owner recipes."""
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
arch = stage.parent
spec = importlib.util.spec_from_file_location(
    "ct_build_metadata", arch / "grouped-shared-activation/build_host.py")
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
base_path = arch / "grouped-shared-activation/corrections/20261019T210159/grouped-link-plan.json"
base = helpers.c.read(base_path)
metadata = helpers.metadata({"cuda": base})
targets = [
    "src/compute_provider_torch_cuda/artifact_provider.cc",
    "src/compute_provider_torch_cuda/mlx_packed_kernel.cu",
    "src/compute_route_cuda/cuda_context.cc",
    "src/compute_route_cuda/default_policy.cc",
    "src/compute_route_cuda/best_of.cc",
    "src/graph_route_cuda/cuda_context.cc",
    "src/graph_route_cuda/dense_bfloat_scores_region.cc",
    "tests/graph_route_cuda/grouped_shared_activation_test.cc"]
owners = {}
missing_objects = []
for item in base["inputs"]:
    path = Path(item["path"])
    if not path.is_file():
        missing_objects.append(item)
    row = metadata.get(helpers.c.key(item["path"]))
    if not row:
        continue
    normalized = Path(row["source_path"]).as_posix()
    for target in targets:
        if normalized.endswith(target):
            owners[target] = dict(row, old_object=item)
out = dict(base=str(base_path), inputs=len(base["inputs"]), metadata=len(metadata),
           owners=owners, missing_objects=missing_objects,
           unresolved_requested_owners=[p for p in targets if p not in owners])
(stage / "build-inventory.json").write_text(json.dumps(out, indent=2) + chr(10))
print(json.dumps(dict(inputs=out["inputs"], metadata=out["metadata"],
                      found_owners=list(owners),
                      missing_objects=len(missing_objects),
                      unresolved_requested_owners=out["unresolved_requested_owners"])))
