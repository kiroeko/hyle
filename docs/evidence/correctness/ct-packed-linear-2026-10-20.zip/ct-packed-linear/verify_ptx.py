"""Inspect the emitted CT device entries, rather than infer math from flags."""
import argparse
import hashlib
import json
from pathlib import Path
import re
stage = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--build", type=Path, default=stage / "checks/attempt1")
parser.add_argument("--out", type=Path, default=stage / "ptx-math-check.json")
args = parser.parse_args()
path = args.build / "kernel.ptx.txt"
data = path.read_bytes()
text = data.decode("utf-8-sig")
entries = list(re.finditer(r"[.]entry\s+([^\s(]+)\s*[(]", text))
rows = []
for index, entry in enumerate(entries):
    name = entry.group(1)
    if "ct_packed" not in name:
        continue
    body = text[entry.start():entries[index + 1].start() if index + 1 < len(entries) else len(text)]
    facts = dict(name=name, mul_rn_f32="mul.rn.f32" in body,
        fma_rn_f32="fma.rn.f32" in body, cvt_rn_f16="cvt.rn.f16.f32" in body,
        cvt_rn_bf16="cvt.rn.bf16.f32" in body, has_ftz=".ftz" in body)
    assert all(facts[k] for k in ("mul_rn_f32", "fma_rn_f32", "cvt_rn_f16", "cvt_rn_bf16"))
    assert not facts["has_ftz"]
    rows.append(facts)
assert len(rows) == 6
result = dict(passed=True, entries=rows, source_object=str(args.build / "ct-packed-kernel.obj"),
              emitted_ptx=dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()),
              claim="Emitted compute89 CT entries retain explicit rounding and contain no FTZ modifier; not exhaustive floating payload or device testing.")
args.out.write_text(json.dumps(result, indent=2) + chr(10))
print(json.dumps(dict(passed=True, CT_entries=len(rows), any_FTZ=False)))
