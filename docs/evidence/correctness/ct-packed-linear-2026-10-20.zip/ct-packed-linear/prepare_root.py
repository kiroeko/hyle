"""Keep the current document baseline and the actual preceding-batch result."""
import hashlib
import json
from pathlib import Path
import shutil

stage = Path(__file__).resolve().parent
root = stage.parents[2]
def save(path, value):
    path.write_text(json.dumps(value, indent=2) + chr(10), encoding="utf-8")
def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
receipt = stage / "root-before.json"
if receipt.exists():
    raise RuntimeError("Preserve this batch's original baseline")
rows = []
for relative in ["docs/user/compute.md", "docs/implementation/model-operators.md",
                 "docs/implementation/model-quantizations.json",
                 "docs/developer/current-work.md"]:
    source = root / relative
    snapshot = stage / "root-before" / relative
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, snapshot)
    rows.append(dict(source=identity(source), snapshot=identity(snapshot)))
save(receipt, dict(files=rows))
previous = root / "docs/evidence/correctness/apple-gguf-nvfp4-2026-10-20.json"
facts = json.loads(previous.read_text(encoding="utf-8"))
assert facts["passed"] and facts["cleanup"]["passed"]
save(stage / "goal-turn.json", dict(
    status="active", previous_goal_turn="progress",
    previous_evidence=identity(previous),
    previous_reason="Actual Apple packed implementation,13 native/common Graph domains,16 legacy controls, bounded coverage updates and83,192,097-byte cleanup completed.",
    current_work="Implement exact CT symmetric/asymmetric INT4 packed linear in the existing Torch CUDA provider and private Graph region; preserve normal public Decode/Transpose/MatMul graph and all source-type conversion boundaries.",
    verification="Reuse actual Windows CUDA/Graph owner closure and SDK caches; only changed owners plus focused tests and one useful physical space/performance comparison." ))
print("CT_PACKED_ROOT_BASELINE", len(rows))
