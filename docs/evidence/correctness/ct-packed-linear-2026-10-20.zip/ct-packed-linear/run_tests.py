"""One serialized actual CUDA run with its exact image/link/source identities."""
import argparse
import importlib.util
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "ct_test_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
parser = argparse.ArgumentParser()
parser.add_argument("--build", type=Path, required=True)
parser.add_argument("--name", required=True)
parser.add_argument("--filter", default="CudaCtPackedLinear.*")
parser.add_argument("--count", type=int, default=4)
args = parser.parse_args()
assert Path(args.name).name == args.name
out = stage / "runs" / args.name
out.mkdir(parents=True, exist_ok=False)
(out / "tmp").mkdir()
build = args.build.resolve()
link = c.read(build / "link-plan.json")
image = c.read(build / "image.json")
assert b.same(image)
for item in link["inputs"]:
    assert b.same(item), item["path"]
env, runtime = b.environment(link["command"], [r["path"] for r in link["inputs"]], out)
c.save(out / "runtime.json", dict(image=image, link=b.identity(build / "link-plan.json"),
    source_plan=b.identity(build / "plan.json"), runtime_library_directories=runtime))
passed = False
try:
    c.execute("tests", [image["path"], "--gtest_filter=" + args.filter,
        "--gtest_output=xml:" + str(out / "results.xml")], env, out)
finally:
    cases = ET.parse(out / "results.xml").findall(".//testcase") if (out / "results.xml").exists() else []
    names = [r.attrib["classname"] + "." + r.attrib["name"] for r in cases]
    passed = (len(cases) == args.count and len(names) == len(set(names)) and
              all(r.find(tag) is None for r in cases for tag in ("failure", "error", "skipped")))
    c.save(out / "summary.json", dict(passed=passed, cases=len(cases), expected=args.count,
        names=names, skipped=sum(r.find("skipped") is not None for r in cases), image=image,
        properties={r.attrib["name"]: {p.attrib["name"]: p.attrib["value"] for p in r.findall("properties/property")}
                    for r in cases}))
if not passed:
    raise SystemExit("Inspect retained actual XML and logs")
print("CT_ACTUAL_TESTS", len(cases), "passed", flush=True)
