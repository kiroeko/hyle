"""Compile only this batch's exact owners, then reuse the current CUDA closure."""
import argparse
import concurrent.futures
import importlib.util
import json
from pathlib import Path
import shutil
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
root = stage.parents[2]
spec = importlib.util.spec_from_file_location(
    "ct_cached_build", stage.parent / "grouped-shared-activation/build_host.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
b, c = helper.b, helper.c
parser = argparse.ArgumentParser()
parser.add_argument("--out", type=Path, required=True)
parser.add_argument("--build", action="store_true")
parser.add_argument("--reuse", type=Path)
args = parser.parse_args()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
(out / "tmp").mkdir(exist_ok=True)
inventory = c.read(stage / "build-inventory.json")
base = c.read(inventory["base"])
owners = inventory["owners"]
rows = []
host_sources = [
    "src/compute_provider_torch_cuda/artifact_provider.cc",
    "src/compute_route_cuda/cuda_context.cc",
    "src/compute_route_cuda/default_policy.cc",
    "src/compute_route_cuda/best_of.cc",
    "src/graph_route_cuda/cuda_context.cc",
    "src/graph_route_cuda/dense_bfloat_scores_region.cc",
    "src/graph_route_cuda/ct_packed_linear_region.cc",
    "tests/graph_route_cuda/ct_packed_linear_test.cc"]
for rel in host_sources:
    source = root / rel
    recipe_key = rel
    if rel.endswith("ct_packed_linear_region.cc"):
        recipe_key = "src/graph_route_cuda/dense_bfloat_scores_region.cc"
    elif rel.startswith("tests/"):
        recipe_key = "tests/graph_route_cuda/grouped_shared_activation_test.cc"
    record = owners[recipe_key]
    tag = rel.replace("/", "--").rsplit(".", 1)[0]
    command = b.host_command(record["command"], source, tag, out)
    # Current CMake gives Graph CUDA the actual private Torch provider target.
    # Its available capability must accompany these formerly cached recipes.
    if rel.startswith("src/graph_route_cuda/") and not any(
            arg == "/DHYLE_COMPUTE_TORCH_CUDA=1" for arg in command):
        command.insert(1, "/DHYLE_COMPUTE_TORCH_CUDA=1")
    if rel.startswith("src/graph_route_cuda/"):
        command.insert(1, "/I" + str(root / "src/compute_provider_torch_cuda"))
    rows.append(dict(tag=tag, kind="host", source=b.identity(source),
                     command=command, object=str(out / (tag + ".obj")),
                     old_object=None if rel.endswith("ct_packed_linear_region.cc")
                                else record["old_object"]))
rel = "src/compute_provider_torch_cuda/mlx_packed_kernel.cu"
record = owners[rel]
source = root / rel
tag = "ct-packed-kernel"
command = []
skip = False
for arg in record["command"]:
    if skip:
        skip = False
        continue
    if arg in ("-c", "-o", "-MT", "-MF", "-ccbin"):
        skip = True
    elif not arg.startswith("-Xcompiler=-Fd"):
        command.append(arg)
assert "-std=c++20" in command
assert "--generate-code=arch=compute_89,code=[compute_89,sm_89]" in command
assert "--use_fast_math" not in command
compiler = Path(owners[host_sources[0]]["command"][0])
command += ["-ccbin", str(compiler.parent), "-MT", str(out / (tag + ".obj")),
            "-MF", str(out / (tag + ".d")), "-c", str(source),
            "-o", str(out / (tag + ".obj")),
            "-Xcompiler=-Fd" + str(out / (tag + ".pdb")) + ",-FS"]
rows.append(dict(tag=tag, kind="native", source=b.identity(source), command=command,
                 object=str(out / (tag + ".obj")), old_object=record["old_object"]))
cached_tests = [c.read(stage.parent / "ga-dense-indexer/checks/20261019T182917/graph-test-identity.json")]
for test in cached_tests:
    assert b.same(test["source"]) and b.same(test["object"])
    for dependency in test["dependencies"]:
        assert b.same(dependency), dependency["path"]
c.save(out / "cached-tests.json", cached_tests)
frozen = [b.identity(root / rel) for rel in host_sources + [
    "src/compute_provider_torch_cuda/mlx_packed_kernel.cu",
    "src/compute_provider_torch_cuda/mlx_packed_kernel.h",
    "src/compute_provider_torch_cuda/ct_packed_linear.h",
    "src/graph_route_cuda/ct_packed_linear_region.h",
    "src/graph_route_cuda/mapped_native_region.h",
    "tests/compute_models/ct_packed_linear_fixture.h",
    "tests/graph_route_cuda/ga_dense_indexer_test.cc",
    "src/compute_route_cuda/default_context.h",
    "cmake/HyleComponents.cmake", "src/graph_route_cuda/CMakeLists.txt",
    "tests/graph_route_cuda/CMakeLists.txt"]]
for item in frozen:
    source = Path(item["path"])
    snapshot = out / "compiled-source" / source.relative_to(root)
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, snapshot)
plan = dict(compile=rows, frozen=frozen, base=inventory["base"],
            input_count=len(base["inputs"]), SDK_build=False, GPU_run=False)
c.save(out / "plan.json", plan)
print("CT_PLAN", out, "host", len(host_sources), "native", 1, flush=True)
if not args.build:
    raise SystemExit(0)
def check():
    for item in frozen:
        assert b.same(item), item["path"]
check()
for item in base["inputs"]:
    assert b.same(item), item["path"]
env, runtime = b.environment(base["command"], [r["path"] for r in base["inputs"]], out)
c.save(out / "runtime-environment.json", dict(runtime=runtime, PATH=env["PATH"]))
def normalized(command, directory):
    return [arg.replace(str(directory), "<OUT>") for arg in command]
def compile_one(row):
    check()
    if args.reuse:
        previous = args.reuse.resolve() / (row["tag"] + "-identity.json")
        if previous.exists():
            cached = c.read(previous)
            # A receipt may itself refer to an older, reused object. Compare
            # against that actual object's directory, not the receipt's copy.
            cached_out = Path(cached["object"]["path"]).parent
            if (normalized(cached["command"], cached_out) == normalized(row["command"], out)
                and b.same(cached["source"]) and b.same(cached["object"])
                and all(b.same(d) for d in cached["dependencies"])):
                cached["reused_by"] = str(out)
                c.save(out / (row["tag"] + "-identity.json"), cached)
                return row, cached
    c.execute(row["tag"] + "-compile", row["command"], env, out)
    check()
    if row["kind"] == "host":
        deps = c.read(out / (row["tag"] + "-deps.json"))["Data"]
        paths = list(dict.fromkeys([deps["Source"], *deps["Includes"]]))
    else:
        paths = [str(root / name) for name in [
            "src/compute_provider_torch_cuda/mlx_packed_kernel.cu",
            "src/compute_provider_torch_cuda/mlx_packed_kernel.h",
            "src/compute_backend_cuda/device_status_kernel.h",
            "third_party/mlx_cuda_quant/mlx_cuda_quant.h"]]
    result = dict(command=row["command"], source=row["source"],
                  object=b.identity(row["object"]), dependencies=[b.identity(p) for p in paths])
    c.save(out / (row["tag"] + "-identity.json"), result)
    return row, result
fresh = []
failures = []
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    futures = [pool.submit(compile_one, row) for row in rows]
    for future in concurrent.futures.as_completed(futures):
        try:
            fresh.append(future.result())
        except BaseException as error:
            failures.append(repr(error))
c.save(out / "compile-summary.json", dict(passed=not failures,
    fresh_or_reused=len(fresh), errors=failures, SDK_build=False))
if failures:
    raise SystemExit("Inspect retained compiler output: " + repr(failures))
replacement = {c.key(row["old_object"]["path"]): result["object"]
               for row, result in fresh if row["old_object"]}
addition = [result["object"] for row, result in fresh if not row["old_object"]]
addition += [test["object"] for test in cached_tests]
objects = {c.key(item["path"]): item for item in base["inputs"]}
objects.update({c.key(result["object"]["path"]): result["object"] for _, result in fresh})
objects.update({c.key(test["object"]["path"]): test["object"] for test in cached_tests})
command = [replacement[c.key(arg)]["path"] if c.key(arg) in replacement else arg
           for arg in base["command"] if not arg.upper().startswith(("/OUT:", "/MAP:", "/IMPLIB:", "/PDB:"))]
command[1:1] = [item["path"] for item in addition]
image = out / "ct-packed-tests.exe"
command += ["/OUT:" + str(image), "/MAP:" + str(image.with_suffix(".map")),
            "/IMPLIB:" + str(image.with_suffix(".lib"))]
inputs = [arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in (".obj", ".lib")]
assert len(inputs) == len(set(map(c.key, inputs)))
for path in inputs:
    assert b.same(objects[c.key(path)]), path
link = dict(command=command, inputs=[objects[c.key(p)] for p in inputs])
c.execute("link", command, env, out)
check()
c.save(out / "link-plan.json", link)
c.save(out / "image.json", b.identity(image))
c.save(out / "summary.json", dict(passed=True, image=b.identity(image),
       host_owners=len(host_sources), native_owners=1, SDK_build=False, GPU_run=False))
print("CT_BUILT", image, flush=True)
