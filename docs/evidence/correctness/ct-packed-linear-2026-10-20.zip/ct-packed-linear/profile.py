"""Inspect one real public captured packed-constant journey, without GPU counters."""
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
stage = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "ct_profile_helpers", stage.parent / "grouped-shared-activation/build_host.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
out = stage / "profile"
out.mkdir(exist_ok=False)
(out / "tmp").mkdir()
build = stage / "checks/attempt2"
link = c.read(build / "link-plan.json")
image = c.read(build / "image.json")
assert b.same(image)
for item in link["inputs"]:
    assert b.same(item), item["path"]
env, runtime = b.environment(link["command"], [r["path"] for r in link["inputs"]], out)
nsys = Path("C:/Program Files/NVIDIA Corporation/Nsight Systems 2026.1.3/target-windows-x64/nsys.exe")
c.save(out / "runtime.json", dict(image=image, profiler=b.identity(nsys),
    runtime_library_directories=runtime, counter_sampling=False))
prefix = out / "packed"
c.execute("profile", [str(nsys), "profile", "--trace=cuda", "--sample=none",
    "--cpuctxsw=none", "--cuda-graph-trace=node", "--output=" + str(prefix),
    image["path"], "--gtest_filter=CudaCtPackedLinear.OriginalPackedConstantsDoNotRetainOrWorkspaceADenseWeightBank",
    "--gtest_output=xml:" + str(out / "results.xml")], env, out)
c.execute("export", [str(nsys), "export", "--type=sqlite",
    "--output=" + str(prefix.with_suffix(".sqlite")), str(prefix.with_suffix(".nsys-rep"))], env, out)
print("CT_PROFILE", prefix.with_suffix(".sqlite"), flush=True)
