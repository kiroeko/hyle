#pragma once

#include <cstdint>
#include <cuda_runtime_api.h>

namespace hyle::compute::torch_cuda::native {
enum class MlxFormat { kAffine, kMxfp4, kMxfp8 };
enum class MlxKind { kLinear, kGrouped, kEmbedding };
enum class Scalar { kFloat16, kBFloat16, kFloat32 };
struct MlxPacked final {
  MlxFormat format;
  MlxKind kind;
  Scalar activation_type, scale_type, output_type;
  std::uint32_t bits, group;
  std::uint64_t rows, columns, depth, experts;
};
struct CtPacked final {
  bool asymmetric;
  Scalar scale_type, decode_type, operand_type;
  std::uint32_t group;
  std::uint64_t rows, columns, depth;
};
cudaError_t mlx_packed_launch(const MlxPacked &program,
    const void *const *inputs, void *output, unsigned *status,
    cudaStream_t stream) noexcept;
cudaError_t ct_packed_linear_launch(const CtPacked &program,
    const void *const *inputs, void *output, cudaStream_t stream) noexcept;
} // namespace hyle::compute::torch_cuda::native
