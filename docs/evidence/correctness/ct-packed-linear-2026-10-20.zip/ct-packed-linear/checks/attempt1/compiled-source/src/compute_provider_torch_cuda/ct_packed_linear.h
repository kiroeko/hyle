#pragma once

#include "hyle/compute/model_ops.h"

#include <array>

namespace hyle::compute::torch_cuda::internal {

// Same-build contraction of the actual public Decode[/Cast]/Transpose/MatMul
// chain. The two types record real rounding boundaries, not a precision policy.
struct CtPackedLinear final {
  model_ops::WeightArtifactFormat format =
      model_ops::WeightArtifactFormat::kCompressedTensorsSymmetric4;
  std::uint32_t group_size = 32;
  DataType decode_type = DataType::kBFloat16;
  DataType operand_type = DataType::kBFloat16;
  static constexpr OperationId operation_id{0x48594c4543554441ULL,
                                             0x43545041434b0001ULL};
  static constexpr std::string_view operation_name =
      "private-cuda-ct-packed-linear";
  constexpr OperationTraits operation_traits() const noexcept {
    const auto count = std::uint16_t(
        format == model_ops::WeightArtifactFormat::kCompressedTensorsAsymmetric4
            ? 4 : 3);
    return {{count, count}, 1, AliasPolicy::kNone, EffectKind::kPure,
            PrecisionPolicy::kAccumulateInDeclaredType, DataType::kFloat32,
            true};
  }
  Status infer_output_descriptions(std::span<const TensorDesc> in,
                                   std::span<TensorDesc> out) const noexcept {
    const auto floating = [](DataType type) {
      return type == DataType::kFloat16 || type == DataType::kBFloat16 ||
             type == DataType::kFloat32;
    };
    if ((format != model_ops::WeightArtifactFormat::kCompressedTensorsSymmetric4 &&
         format != model_ops::WeightArtifactFormat::kCompressedTensorsAsymmetric4) ||
        !floating(decode_type) || !floating(operand_type) ||
        in.size() != operation_traits().inputs.minimum || out.size() != 1)
      return Status::InvalidArgument("private CT packed linear ports/types differ");
    std::array<TensorDesc, 1> decoded;
    HYLE_RETURN_IF_ERROR((model_ops::ArtifactWeightDecode{
        format, group_size, decode_type}.infer_output_descriptions(
            in.subspan(1), decoded)));
    HYLE_ASSIGN_OR_RETURN(auto weight, TensorDesc::dense(operand_type,
        std::array{decoded[0].dimensions()[1], decoded[0].dimensions()[0]}));
    const std::array operands{in[0], weight};
    return hyle::compute::infer_output_descriptions(Operation(MatMul{}), operands, out);
  }
};
static_assert(detail::InlineCustomOperationDescriptor<CtPackedLinear>);

} // namespace hyle::compute::torch_cuda::internal
