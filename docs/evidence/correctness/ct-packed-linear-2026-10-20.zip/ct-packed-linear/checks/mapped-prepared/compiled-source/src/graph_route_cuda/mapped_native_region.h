#pragma once

#include "hyle/graph/region_provider.h"
#include "../compute/provider_internal.h"

#include <array>
#include <cstdint>
#include <new>
#include <span>

namespace hyle::graph::cuda::internal::mapped_native_region {
namespace c = compute;

// Only the ordinary four-input, one-output SharedQueue carrier. Callers own
// their pattern, exact boundary and native resource qualification.
struct Artifact final {
  c::detail::ProviderPrepared native;
  std::array<std::size_t, 4> ports{};
  std::size_t count = 0, boundary_count = 0;
};
struct Invocation final {
  const c::detail::ProviderPreparedVTable *vtable = nullptr;
  void *state = nullptr;
};
inline constexpr std::size_t kArtifactBytes = sizeof(Artifact);

inline void destroy(void *value, mem::AllocatorRef allocator) noexcept {
  auto *a = static_cast<Artifact *>(value);
  if (!a) return;
  if (a->native.vtable && a->native.vtable->destroy_prepared)
    a->native.vtable->destroy_prepared(a->native.state, allocator);
  a->~Artifact(); allocator.deallocate(a, sizeof(Artifact), alignof(Artifact));
}
inline c::AliasSupport alias(void *value, std::size_t output, std::size_t input) noexcept {
  auto &a = *static_cast<Artifact *>(value);
  for (std::size_t n = 0; n < a.count; ++n)
    if (a.ports[n] == input) return a.native.vtable->alias_support(a.native.state, output, n);
  return {};
}
inline Status create_invocation(void *value, mem::AllocatorRef allocator,
                               mem::BufferView workspace, void **output) noexcept {
  *output = nullptr;
  auto &a = *static_cast<Artifact *>(value);
  void *storage = allocator.allocate(sizeof(Invocation), alignof(Invocation));
  if (!storage) return Status::ResourceExhausted("mapped native region invocation allocation failed");
  auto *invocation = ::new (storage) Invocation{a.native.vtable, nullptr};
  *output = invocation;
  return a.native.vtable->create_invocation(a.native.state, allocator, workspace, &invocation->state);
}
inline void destroy_invocation(void *value, mem::AllocatorRef allocator) noexcept {
  auto *i = static_cast<Invocation *>(value);
  if (!i) return;
  if (i->state) i->vtable->destroy_invocation(i->state, allocator);
  i->~Invocation(); allocator.deallocate(i, sizeof(Invocation), alignof(Invocation));
}
inline c::detail::EnqueueResult submit(void *value, void *lane, c::detail::QueueSequence &sequence,
    std::span<const c::ConstTensorView> inputs, std::span<const c::TensorView> outputs) noexcept {
  const auto &a = *static_cast<Artifact *>(value);
  if (inputs.size() != a.boundary_count || outputs.size() != 1)
    return c::detail::EnqueueResult::rejected(Status::InvalidArgument("mapped native submit port count differs"));
  std::array<c::ConstTensorView, 4> ordered;
  for (std::size_t n = 0; n < a.count; ++n) ordered[n] = inputs[a.ports[n]];
  return a.native.vtable->shared_submit(a.native.state, static_cast<Invocation *>(lane)->state,
      sequence, std::span(ordered).first(a.count), outputs);
}
inline constexpr ProviderRegionPreparedVTable kPrepared{
    .destroy_prepared = &destroy, .alias_support = &alias, .create_invocation = &create_invocation,
    .destroy_invocation = &destroy_invocation, .shared_submit = &submit};

inline c::ProviderPrepareOutcome prepare(const c::detail::ProviderVTable &provider, void *context,
    const c::detail::ProviderPrepareRequest &request, const c::detail::ProviderOperationProposal &proposal,
    std::span<const std::size_t> ports, std::size_t boundary_count,
    mem::AllocatorRef allocator, ProviderRegionPrepared *result) noexcept {
  *result = {};
  if (ports.empty() || ports.size() > 4 || ports.size() != request.inputs.size() ||
      request.input_resources.size() != ports.size() || request.outputs.size() != 1 ||
      request.output_resources.size() != 1 || boundary_count == 0 || boundary_count > ports.size())
    return c::ProviderPrepareOutcome::error(Status::InvalidArgument("mapped native region port count differs"));
  for (const auto port : ports)
    if (port >= boundary_count)
      return c::ProviderPrepareOutcome::error(Status::InvalidArgument("mapped native region input is outside its boundary"));
  if (!proposal.cost.dispatch_count || !proposal.cost.copy_bytes || !proposal.cost.synchronization_count ||
      proposal.runtime.mode != c::ProviderRuntimeMode::kSharedQueue)
    return c::ProviderPrepareOutcome::error(Status::Internal("mapped native runtime facts are incomplete"));
  void *storage = allocator.allocate(sizeof(Artifact), alignof(Artifact));
  if (!storage) return c::ProviderPrepareOutcome::error(
      Status::ResourceExhausted("mapped native region artifact allocation failed"));
  auto *a = ::new (storage) Artifact;
  a->count = ports.size(); a->boundary_count = boundary_count;
  for (std::size_t n = 0; n < a->count; ++n) a->ports[n] = ports[n];
  const auto outcome = provider.prepare(context, request, allocator, &a->native);
  if (outcome.kind != c::ProviderPrepareOutcomeKind::kPrepared) {
    destroy(a, allocator); return outcome;
  }
  if (!a->native.vtable || !a->native.vtable->destroy_prepared || !a->native.vtable->alias_support ||
      !a->native.vtable->create_invocation || !a->native.vtable->destroy_invocation ||
      !a->native.vtable->shared_submit || a->native.vtable->prepare_bindings) {
    destroy(a, allocator);
    return c::ProviderPrepareOutcome::error(Status::Internal("mapped native artifact requires an unsupported binding route"));
  }
  auto persistent = a->native.persistent_bytes;
  if (persistent) {
    if (*persistent > SIZE_MAX - sizeof(Artifact)) {
      destroy(a, allocator);
      return c::ProviderPrepareOutcome::error(Status::OutOfRange("mapped native region metadata bytes overflow"));
    }
    *persistent += sizeof(Artifact);
  }
  // Invocation is tracked by the supplied allocator, outside this opaque bound.
  *result = {.vtable = &kPrepared, .state = a,
      .properties = {.workspace = a->native.workspace, .persistent_bytes = persistent,
          .copy_bytes = *proposal.cost.copy_bytes, .synchronization_count = *proposal.cost.synchronization_count,
          .dispatch_count = *proposal.cost.dispatch_count, .runtime = a->native.runtime,
          .invocation_private_bytes = a->native.invocation_private_bytes}};
  return outcome;
}
} // namespace hyle::graph::cuda::internal::mapped_native_region
