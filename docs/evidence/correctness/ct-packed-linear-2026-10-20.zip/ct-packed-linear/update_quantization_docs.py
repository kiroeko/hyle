import json
from pathlib import Path

path = Path('docs/implementation/model-quantizations.json')
document = json.loads(path.read_text(encoding='utf-8'))
artifacts = document['artifacts']
evidence = '../evidence/correctness/ct-packed-linear-2026-10-20.json'
new_code = [
    'src/graph_route_cuda/ct_packed_linear_region.cc',
    'src/compute_provider_torch_cuda/ct_packed_linear.h',
    'src/compute_provider_torch_cuda/mlx_packed_kernel.cu',
]


def packed_entry(group, asymmetric=False):
    return {
        'provider': 'CUDA Graph CT packed linear',
        'operation': 'Ordinary ArtifactWeightDecode -> exact rank2 transpose View -> MatMul with F32 accumulation; one optional weight Cast before or after View',
        'exact_requirements': f'Natural group{group}, dense activation/output; original I32 low-first codes[N,K/8], floating scales[N,K/group]'
            + (', and I32 zero[ceil(N/8),K/group] packed along N' if asymmetric else '; symmetric offset-binary nibble minus8')
            + '. Preserve source-scale product rounding, decode output dtype and actual operand Cast. Intermediate values must remain unpublished with one reader and no escaping control dependency.',
        'execution': 'Cold region contraction to one native packed kernel, no retained dense weight bank or workspace; escaped intermediates keep the original decomposition. A separately cold-decoded dense constant has no codec identity for this contraction.',
        'qualification': 'Shared synthetic group32 F16/BF16/F32 operation cases passed, including RequireCapture positive paths and original decomposition fallbacks; group128/512 and publisher payloads were not executed in this batch. No mature tensor-core GEMM, fused FFN, expert or W4A4 coverage inferred.',
        'evidence': evidence,
    }


for index, repository in {
    0: 'cyankiwi/Qwen3.5-2B-AWQ-4bit',
    9: 'cyankiwi/Qwen3.8-27B-AWQ-INT4',
    22: 'RedHatAI/Kimi-K3-INT4',
    24: 'open-inference/Kimi-K3-W4A8-K512-GPTQ-Mixed-Cal72-Seq1024',
}.items():
    artifact = artifacts[index]
    assert artifact['repository'] == repository
    coverage = artifact['provider_coverage']
    assert coverage['artifact_execution_verified'] is False
    coverage['reachable_entry_points'].append(packed_entry({0: 32, 9: 32, 22: 128, 24: 512}[index], index == 9))
    coverage['code'].extend(code for code in new_code if code not in coverage['code'])
    if index != 9:
        coverage['review'] = 'static_contract_and_shared_operator_regressions'
        coverage['review_scope'] = ('Saved exact-revision metadata and local source mapping, plus shared synthetic CUDA group32 CT packed Graph operation regressions; '
            'no tensor-header binding, publisher payload, importer or full artifact execution. The shared operator tests do not verify every artifact group or role.')
    if index in (22, 24):
        coverage['reachable_entry_points'][0]['execution'] = coverage['reachable_entry_points'][0]['execution'].replace('Cold decode only:', 'Explicit cold decode:').replace('; no packed CT4 GEMM mapped', '')

coverage = artifacts[0]['provider_coverage']
coverage['mapping_status'] = 'Conditional CT symmetric INT4 group32 cold decode and CUDA same-graph packed linear contraction; publisher tensor bindings remain unverified'
coverage['artifact_unaligned_or_unverified'][1] = 'Explicit cold decode with retained dense constants remains valid; CUDA packed contraction requires the decode recipe and packed inputs in the same execution graph'
coverage['missing_capabilities'] = ['Packed CT linear on CPU/Apple/Vulkan; mature CUDA tensor-core GEMM, packed FFN/expert execution and artifact importer binding remain separate gaps']
coverage['fusion_coverage'] = 'CUDA exact Decode[/Cast]/Transpose/MatMul contraction retains source-scale, decode and operand rounding without a dense bank; no GLU/FFN fusion or artifact execution claimed'

coverage = artifacts[9]['provider_coverage']
coverage['review'] = 'pinned_tensor_headers_and_operator_regressions'
coverage['review_scope'] = ('Pinned five safetensor headers/index and fixed upstream recipe; synthetic cold-decode regressions on Windows CPU/CUDA/Vulkan and Mac16,12 Apple, '
    'plus CUDA symmetric/asymmetric group32 packed Graph numerical, capture and lifetime regressions. No publisher tensor payload, importer or full quantized model execution.')
coverage['mapping_status'] = 'CT asymmetric INT4 natural-group cold decode on four routes; CUDA same-graph packed linear now contracts the public decode/transpose/optional-cast/matmul recipe without a dense weight bank'
coverage['missing_capabilities'] = ['Packed CT linear on CPU/Apple/Vulkan; mature CUDA tensor-core GEMM and packed grouped/FFN execution', 'Publisher payload import and full selected 27B execution, quality, throughput and memory qualification']
coverage['packed_graph_evidence'] = {
    'summary': evidence,
    'CUDA_graph_cases_passed': 4,
    'CUDA_graph_cases_skipped': 0,
    'capture': 'RequireCapture for selected positive packed chains, dynamic slots and borrowed constants; escaped intermediate cases execute the original decomposition without requiring capture',
    'related_MLX_cases_passed': 5,
    'space_fixture': {
        'M': 3,
        'N': 257,
        'K': 1024,
        'compiled_known_bytes': 1512,
        'workspace_bytes': 0,
        'scope': 'Known compiled metadata/storage excludes caller-borrowed packed inputs; not total GPU allocation, model memory or measured peak',
    },
    'publisher_tensor_payload_bytes_read': 0,
    'publisher_artifact_run': False,
    'throughput_measured': False,
}
coverage['fusion_coverage'] = 'CUDA same-graph packed linear contraction is operation-verified; exact source-scale product/decode/operand rounding retained, with F32 accumulation whose reduction tree can differ from dense MatMul. No packed FFN/expert fusion or artifact execution claimed.'

coverage = artifacts[22]['provider_coverage']
coverage['mapping_status'] = 'Conditional CT symmetric INT4 group128 cold decode and structurally admitted CUDA same-graph rank2 packed linear; exact publisher binding and group128 execution remain unverified'
coverage['missing_capabilities'] = ['Packed CT grouped/expert execution; CPU/Apple/Vulkan packed linear and mature CUDA tensor-core/FFN paths', 'Exact artifact packing/dtype/role binding and group128 packed numerical execution remain unverified']
coverage['fusion_coverage'] = 'CUDA public rank2 decode/transpose/optional-cast/matmul can contract after exact binding; shared group32 tests do not establish this artifact, its experts or any packed GLU fusion'

coverage = artifacts[24]['provider_coverage']
coverage['mapping_status'] = 'Conditional CT symmetric INT4 group512 cold decode and structurally admitted CUDA same-graph rank2 packed linear; routed expert execution and custom A8 contract remain unmapped'
coverage['missing_capabilities'] = ['Packed CT group512 grouped/expert execution and separately specified A8 runtime contract if required', 'CPU/Apple/Vulkan packed linear and mature CUDA tensor-core/FFN paths; exact artifact binding and group512 packed numerical execution remain unverified']
coverage['fusion_coverage'] = 'CUDA public rank2 decode/transpose/optional-cast/matmul contraction is available after exact binding; this does not bind routed experts, verify group512 or establish custom W4A8/GLU fusion'

assert len(artifacts) == 33
assert all(not a['provider_coverage']['artifact_execution_verified'] for a in artifacts if a.get('provider_coverage'))
path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print('Updated four CT provider_coverage rows; all 33 artifact execution flags remain false')
