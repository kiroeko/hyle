"""Reuse actual NVFP4 link inputs; refresh changed host owners and focused fixtures."""
from pathlib import Path
import argparse
import concurrent.futures
import datetime as dt
import hashlib
import importlib.util
import json
import re
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
A = S.parent
ROOT = S.parents[2]
NV = A / 'gguf-nvfp4'
spec = importlib.util.spec_from_file_location('grouped_host_helpers', NV / 'windows-host/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
BASES = {arm: NV / 'windows-host/checks/20261019T201048' / (arm + '-link-plan.json')
    for arm in ['cpu-direct', 'cpu-graph', 'vulkan']}
BASES['qwen'] = NV / 'cpu-cuda/checks/20261019T202628-grouped-fix/qwen-link-plan.json'

def visit(value):
    if isinstance(value, dict):
        yield value
        for item in value.values():
            yield from visit(item)
    elif isinstance(value, list):
        for item in value:
            yield from visit(item)

def metadata(plans):
    directories = {Path(row['path']).parent for plan in plans.values() for row in plan['inputs']
        if Path(row['path']).suffix.lower() == '.obj'}
    result = {}
    paths = [p for directory in sorted(directories) for p in directory.glob('*.json')]
    paths += [A/'immutable-constant-alias/object-inventory.json',
        A/'native-ready-pages/schema/commands.json', NV/'windows-host/legacy-nonowners.json']
    for path in dict.fromkeys(paths):
            if path.stat().st_size > 8_000_000:
                continue
            try:
                doc = c.read(path)
            except (ValueError, OSError):
                continue
            for row in visit(doc):
                command = row.get('command') or row.get('argv')
                if not isinstance(command,list) or not command:
                    continue
                obj = row.get('object')
                source = row.get('source')
                if not obj:
                    obj = next((arg[3:] for arg in command if arg.lower().startswith('/fo') and len(arg)>3),None)
                    if not obj and '-o' in command:
                        obj = command[command.index('-o')+1]
                if not source:
                    candidates = [arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.cc','.cpp','.c','.cu','.mm')]
                    source = candidates[0] if len(candidates)==1 else None
                if not obj or not source:
                    continue
                obj_path = obj.get('path') if isinstance(obj, dict) else obj
                source_path = source.get('path') if isinstance(source, dict) else source
                if not isinstance(obj_path,str) or not isinstance(source_path,str):
                    continue
                if not isinstance(source,dict):
                    source = next((x for x in row.get('sources_before',[]) if c.key(x.get('path',''))==c.key(source_path)),source)
                key = c.key(obj_path)
                dependencies = row.get('dependencies') or row.get('hyle_headers') or []
                if not isinstance(dependencies,list):
                    dependencies = []
                score = (4 if isinstance(source,dict) and source.get('sha256') else 0) + (2 if row.get('source_dependencies') else 0) + bool(dependencies)
                # Prefer the actual complete owner receipt to a plan row.
                if key not in result or score > result[key].get('metadata_score',-1):
                    result[key] = dict(row, command=command, recipe=str(path), source_path=source_path,
                        dependencies=dependencies,metadata_score=score)
    return result

def local_header_member(source, command, header):
    """Bounded fallback for early owners without retained sourceDependencies."""
    roots = []
    for arg in command:
        for prefix in ('/external:I', '/I', '-I'):
            if arg.lower().startswith(prefix.lower()):
                roots.append(Path(arg[len(prefix):]))
                break
    pending, seen = [source], set()
    while pending:
        path = pending.pop().resolve()
        key = c.key(path)
        if key in seen or not path.is_file():
            continue
        seen.add(key)
        if key == header:
            return True, sorted(seen)
        if not path.is_relative_to(ROOT):
            continue
        for include in re.findall(r'^\s*#\s*include\s*[<"]([^>"\n]+)', path.read_text(errors='replace'), re.M):
            candidate = next((base/include for base in [path.parent,*roots] if (base/include).is_file()),None)
            if candidate is not None:
                pending.append(candidate)
    return False, sorted(seen)

def same_identity(row):
    if not isinstance(row,dict) or not row.get('sha256'):
        return False
    actual = b.identity(row['path'])
    return actual.get('sha256') == row.get('sha256') and actual.get('bytes') == row.get('bytes')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--link', action='store_true')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    out = args.out.resolve() if args.out else S / 'windows-host/checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    plans = {arm:c.read(path) for arm,path in BASES.items()}
    recipes = metadata(plans)
    objects = {}
    for arm, plan in plans.items():
        for row in plan['inputs']:
            if Path(row['path']).suffix.lower() != '.obj':
                continue
            entry = objects.setdefault(c.key(row['path']),dict(old_object=row,arms=[]))
            entry['arms'].append(arm)
    changed = c.key(ROOT / 'include/hyle/compute/model_ops.h')
    version = S / 'provider-version.h'
    rows, native, reused, unresolved = [], [], [], []
    def add(source, command, tag, old, arms, recipe):
        command = list(command)
        if version.exists():
            command = ['/FI'+str(version) if arg.lower().startswith('/fi') and Path(arg[3:]).name=='provider-version.h' else arg for arg in command]
        rows.append(dict(tag=tag, source=b.identity(source), old_object=old, arms=arms,
            recipe=str(recipe), command=b.host_command(command,source,tag,out), object=str(out/(tag+'.obj'))))
    for key, entry in objects.items():
        record = recipes.get(key)
        if not record:
            unresolved.append(entry)
            continue
        source = Path(record['source_path'])
        command = record['command']
        if source.suffix.lower() == '.cu':
            dep = Path(command[command.index('-MF')+1]) if '-MF' in command else None
            hit = bool(dep and dep.exists() and 'model_ops.h' in dep.read_text(errors='replace'))
            native.append(dict(entry, source=str(source), recipe=record['recipe'],
                model_ops_header_member=hit if dep and dep.exists() else None,
                dependency_file=str(dep) if dep else None))
            continue
        dependencies = record.get('dependencies',[])
        member = any(c.key(x['path']) == changed for x in dependencies)
        if not dependencies:
            paths = b.host_dependencies(command)
            member = changed in {c.key(p) for p in paths}
            if not paths:
                member, closure = local_header_member(source,command,changed)
                if not member and not source.is_relative_to(ROOT/'src') and not source.is_relative_to(ROOT/'tests'):
                    reused.append(dict(entry,source=str(source),recipe=record['recipe'],
                        limitation='No original dependency identities; unchanged vendor owner, current local include closure excludes model_ops.h',
                        checked_local_include_paths=closure))
                    continue
        source_changed = isinstance(record.get('source'),dict) and not same_identity(record['source'])
        deps_changed = any(not same_identity(x) for x in dependencies)
        version_changed = any(arg.lower().startswith('/fi') and Path(arg[3:]).name=='provider-version.h' and c.key(arg[3:])!=c.key(version) for arg in command)
        if not member and not source_changed and not deps_changed and not version_changed:
            reused.append(dict(entry,source=str(source),recipe=record['recipe']))
            continue
        tag = 'o'+hashlib.sha256(key.encode()).hexdigest()[:8]+'--'+source.parent.name+'--'+source.stem
        add(source,command,tag,entry['old_object'],entry['arms'],record['recipe'])
    # Current public regressions compile once per actual Direct/Graph recipe.
    recipes_dir = NV / 'windows-host/checks/20261019T201048'
    extras = [
        ('grouped-cpu-direct',ROOT/'tests/compute_route_cpu/grouped_shared_activation_test.cc',recipes_dir/'nvfp4-cpu-direct-identity.json',['cpu-direct']),
        ('grouped-cpu-graph',ROOT/'tests/compute_route_cpu/grouped_shared_activation_test.cc',recipes_dir/'nvfp4-cpu-graph-identity.json',['cpu-graph']),
        ('grouped-vulkan',ROOT/'tests/compute_route_vulkan/grouped_shared_activation_test.cc',recipes_dir/'nvfp4-vulkan-identity.json',['vulkan'])]
    for tag,source,recipe,arms in extras:
        add(source,c.read(recipe)['command'],tag,None,arms,recipe)
    frozen = [b.identity(ROOT / name) for name in ['include/hyle/compute/model_ops.h',
        'tests/compute_models/grouped_shared_activation_fixture.h']]
    if version.exists():
        frozen.append(b.identity(version))
    plan = dict(compile=rows,bases={arm:str(path) for arm,path in BASES.items()},frozen=frozen,
        reused_hosts=reused,native_inputs=native,unresolved_inputs=unresolved,
        SDK_rebuilt=False,GPU_run=False)
    c.save(out/'plan.json',plan)
    c.save(S/'host-latest-check.json',dict(plan=str(out/'plan.json')))
    print('HOST_PLAN',out/'plan.json','fresh',len(rows),'reused',len(reused),'native_header_hits',sum(r['model_ops_header_member'] is True for r in native),'unresolved',len(unresolved),flush=True)
    if not args.build:
        return
    assert not [r for r in native if r['model_ops_header_member']], 'Refresh actual native header owners separately before linking'
    env,runtime = b.environment(rows[0]['command'],[],out)
    c.save(out/'runtime-environment.json',dict(PATH=env['PATH'],runtime=runtime))
    def compile_one(row):
        receipt=out/(row['tag']+'-identity.json')
        if receipt.exists():
            old=c.read(receipt)
            if old['command']==row['command'] and b.same(old['source']) and b.same(old['object']) and all(b.same(d) for d in old['dependencies']):
                return old
        job=out/'commands'/row['tag']
        if job.exists():
            attempt = 2
            while (job/f'attempt{attempt}').exists():
                attempt += 1
            job = job/f'attempt{attempt}'
        job.mkdir(parents=True,exist_ok=True)
        print('COMPILE',row['tag'],flush=True)
        c.execute(row['tag']+'-compile',row['command'],env,job)
        depfile=out/(row['tag']+'-deps.json')
        dep=c.read(depfile)['Data']
        dependencies=[]
        for name in dict.fromkeys([dep['Source'],*dep['Includes']]):
            path=Path(name).resolve()
            if any(path.is_relative_to(ROOT/prefix) for prefix in ['src','include','tests','third_party','.scratch/architecture-refactor-2026-10-18']):
                dependencies.append(b.identity(path))
        record=dict(command=row['command'],source=row['source'],object=b.identity(row['object']),
            source_dependencies=b.identity(depfile),dependencies=dependencies,old_object=row['old_object'],arms=row['arms'])
        assert b.same(row['source'])
        c.save(receipt,record)
        print('COMPILED',row['tag'],flush=True)
        return record
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records=list(pool.map(compile_one,rows))
    for row in frozen:
        assert b.same(row)
    c.save(out/'common-objects-ready.json',dict(owners=records,plan=str(out/'plan.json')))
    c.save(out/'compile-summary.json',dict(passed=True,fresh_host_TUs=len(records),native_TUs=0,SDK_rebuilt=False))
    links={}
    for arm,base in plans.items():
        swaps={c.key(r['old_object']['path']):r['object'] for r in rows if r['old_object'] and arm in r['arms']}
        command=[swaps.get(c.key(arg),arg) for arg in base['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/IMPLIB:','/PDB:'))]
        command[1:1]=[r['object'] for r in rows if not r['old_object'] and arm in r['arms']]
        image=out/(arm+'.exe')
        command += ['/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map')),'/IMPLIB:'+str(image.with_suffix('.lib'))]
        ids={c.key(r['path']):r for r in base['inputs']}
        ids.update({c.key(r['object']['path']):r['object'] for r in records})
        paths=[arg for arg in command if Path(arg).is_absolute() and Path(arg).suffix.lower() in ('.obj','.lib')]
        assert len(paths)==len(set(map(c.key,paths)))
        link=dict(command=command,inputs=[ids[c.key(p)] for p in paths],base=b.identity(BASES[arm]),host_plan=b.identity(out/'plan.json'),status='HOST_READY_NATIVE_SWAP_PENDING' if arm=='qwen' else 'PREPARED')
        for row in link['inputs']:
            assert Path(row['path']).is_file() and Path(row['path']).stat().st_size==row['bytes']
        c.save(out/(arm+'-link-plan.json'),link)
        links[arm]=link
    if not args.link:
        return
    for arm in ['cpu-direct','cpu-graph','vulkan']:
        link=links[arm]
        link_env,_=b.environment(link['command'],[r['path'] for r in link['inputs']],out)
        c.execute(arm+'-link',link['command'],link_env,out)
        c.save(out/(arm+'-image.json'),b.identity(out/(arm+'.exe')))
    c.save(out/'summary.json',dict(passed=True,fresh_host_TUs=len(rows),linked=['cpu-direct','cpu-graph','vulkan'],GPU_run=False,SDK_rebuilt=False))
    print('HOST_READY',out,flush=True)

if __name__=='__main__':
    main()
