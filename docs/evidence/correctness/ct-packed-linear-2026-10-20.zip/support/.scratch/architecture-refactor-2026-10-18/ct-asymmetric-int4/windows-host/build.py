"""Refresh actual linked model_ops host owners; no SDK/native CUDA build or GPU run."""
from pathlib import Path
import argparse
import concurrent.futures
import datetime as dt
import importlib.util
import json
import sys
sys.dont_write_bytecode = True
STAGE = Path(__file__).resolve().parent
CT = STAGE.parent
ARCH = CT.parent
ROOT = ARCH.parents[1]
BASE = ARCH / 'view-projection-reuse/checks/20261019T191627'
spec = importlib.util.spec_from_file_location('ct_host_helpers', ARCH / 'view-projection-reuse/build.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def local(path):
    p = Path(path).resolve()
    return any(p.is_relative_to(ROOT / x) for x in ('src', 'include', 'tests', 'third_party'))


def prepare(out):
    bases = {arm: c.read(BASE / (arm + '-link-plan.json')) for arm in ('cpu', 'qwen')}
    specs = c.read(STAGE / 'owners-initial.json')['owners']
    rows, excluded, frozen = [], [], {}
    def keep(path):
        row = b.identity(path)
        frozen[c.key(row['path'])] = row
    keep(Path(__file__))
    for seal in ('root-source-freeze.json', 'cuda-source-freeze.json'):
        data = c.read(CT / seal)
        for row in data['files']:
            p = Path(row['source'])
            if p.suffix not in ('.h', '.cc'):
                continue
            actual = b.identity(p)
            assert actual['sha256'] == row['after']['sha256'], p
            keep(p)
    for entry in specs:
        recipe_path = Path(entry['recipe'])
        recipe = c.read(recipe_path)
        source = Path(recipe['source']['path'])
        if source.suffix == '.cu':
            command = recipe['command']
            depfile = Path(command[command.index('-MF') + 1])
            assert 'model_ops.h' not in depfile.read_text(encoding='utf-8').lower()
            excluded.append(dict(object=entry['old_object'], actual_depfile=b.identity(depfile),
                                 reason='Receipt freezes wider project headers; actual nvcc dependencies omit model_ops.h.'))
            continue
        assert source.suffix == '.cc'
        old = recipe['object']
        assert old == entry['old_object'] and b.same(old)
        dep = Path(recipe['command'][recipe['command'].index('/sourceDependencies') + 1])
        includes = c.read(dep)['Data']['Includes']
        assert c.key(ROOT / 'include/hyle/compute/model_ops.h') in set(map(c.key, includes))
        tag = f'{len(rows):02d}-' + source.parent.name + '-' + source.stem
        rows.append(dict(tag=tag, source=b.identity(source), recipe=b.identity(recipe_path),
                         old_object=old, arms=entry['arms'],
                         command=b.host_command(recipe['command'], source, tag, out),
                         object=str(out / (tag + '.obj')), actual_previous_dependencies=b.identity(dep)))
        for p in b.host_dependencies(recipe['command']):
            keep(p)
        keep(source)
    extra = [
        ('cpu-direct-artifact', '02-compute_route_cpu-cpu_mlx_quantized_test-identity.json',
         ROOT / 'tests/compute_route_cpu/cpu_artifact_decode_test.cc', ['cpu-direct']),
        ('cpu-graph-artifact', '03-compute_route_cpu-cpu_mlx_quantized_test-identity.json',
         ROOT / 'tests/compute_route_cpu/cpu_artifact_decode_test.cc', ['cpu-graph']),
        ('cuda-artifact', None, ROOT / 'tests/graph_route_cuda/artifact_test.cc', ['cuda'])]
    for tag, name, source, arms in extra:
        path = (ARCH / 'decode-next-cold/checks/20261019T155819' / name if name else
                ARCH / 'ga-dense-indexer/checks/20261019T182917/graph-test-identity.json')
        recipe = c.read(path)
        command = b.host_command(recipe['command'], source, tag, out)
        if tag == 'cuda-artifact':
            command.insert(1, '/DHYLE_COMPUTE_TORCH_CUDA=1')
        rows.append(dict(tag=tag, source=b.identity(source), recipe=b.identity(path),
                         old_object=None, arms=arms, command=command,
                         object=str(out / (tag + '.obj'))))
        for p in b.host_dependencies(recipe['command']):
            keep(p)
        keep(source)
    for p in [ROOT / 'tests/compute_models/ct_asymmetric_int4_fixture.h',
              ROOT / 'third_party/compressed_tensors_cpu/compressed_tensors_cpu.h',
              ROOT / 'third_party/compressed_tensors_cuda/compressed_tensors_cuda.h']:
        keep(p)
    for row in rows:
        p = Path(row['source']['path'])
        q = out / 'compiled-source' / p.relative_to(ROOT)
        q.parent.mkdir(parents=True, exist_ok=True)
        q.write_bytes(p.read_bytes())
    cached = {c.key(x['path']): x for base in bases.values() for x in base['inputs']}
    gtests = [x for x in bases['cpu']['inputs'] if Path(x['path']).name.lower() in ('gtest.lib', 'gtest_main.lib')]
    assert len(gtests) == 2
    main = next(row for row in rows if c.key(row['source']['path']) == c.key(ROOT / 'tools/qwen35_text/main.cc'))
    links = {}
    for arm in ('cpu-direct', 'cpu-graph', 'qwen', 'cuda'):
        base_arm = 'cpu' if arm.startswith('cpu') else 'qwen'
        base = bases[base_arm]
        replace = {c.key(row['old_object']['path']): row['object'] for row in rows
                   if row['old_object'] and base_arm in row['arms']}
        command = [replace.get(c.key(x), x) for x in base['command']
                   if not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        if arm == 'cuda':
            command = [x for x in command if c.key(x) != c.key(main['object'])]
            command[1:1] = [x['path'] for x in gtests]
        command[1:1] = [row['object'] for row in rows if not row['old_object'] and arm in row['arms']]
        image = out / (arm + '.exe')
        command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                    '/IMPLIB:' + str(image.with_suffix('.lib'))]
        inputs = [x for x in command if Path(x).is_absolute() and x.lower().endswith(('.obj', '.lib'))
                  and not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
        assert len(inputs) == len(set(map(c.key, inputs)))
        links[arm] = dict(command=command, inputs=inputs, image=str(image))
    plan = dict(compile=rows, links=links, frozen=list(frozen.values()), cached_inputs=list(cached.values()),
                original_links={a: b.identity(BASE / (a + '-link-plan.json')) for a in bases},
                excluded_native_receipt_false_positives=excluded,
                host_TUs=len(rows), native_TUs=0, SDK_rebuild=False, GPU_run=False)
    c.save(out / 'owners.json', dict(owners=rows, excluded_native=excluded))
    c.save(out / 'plan.json', plan)
    return plan


def check(plan):
    for row in plan['frozen']:
        assert b.same(row), row['path']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--resume', type=Path)
    args = parser.parse_args()
    if args.resume:
        plan_path = args.resume.resolve()
        out = plan_path.parent
        plan = c.read(plan_path)
    else:
        out = STAGE / 'checks' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')
        out.mkdir(parents=True, exist_ok=False)
        (out / 'tmp').mkdir()
        plan = prepare(out)
        plan_path = out / 'plan.json'
    print('PLAN', plan_path, flush=True)
    if not args.build:
        return
    check(plan)
    cached = {c.key(x['path']): x for x in plan['cached_inputs']}
    for row in cached.values():
        assert b.same(row), row['path']
    env, runtime = b.environment(plan['links']['qwen']['command'], list(x['path'] for x in cached.values()), out)
    c.save(out / 'runtime-environment.json', dict(PATH=env.get('PATH'), runtime=runtime))
    def compile_one(row):
        record_path = out / (row['tag'] + '-identity.json')
        if record_path.exists():
            record = c.read(record_path)
            if record['command'] == row['command'] and b.same(record['object']):
                return record
        job = out / 'commands' / row['tag']
        job.mkdir(parents=True, exist_ok=True)
        c.execute(row['tag'] + '-compile', row['command'], env, job)
        dep = c.read(out / (row['tag'] + '-deps.json'))['Data']
        paths = [dep['Source'], *dep['Includes']]
        record = dict(command=row['command'], source=row['source'], object=b.identity(row['object']),
                      source_dependencies=b.identity(out / (row['tag'] + '-deps.json')),
                      dependencies=[b.identity(p) for p in dict.fromkeys(paths) if local(p)])
        c.save(record_path, record)
        print('COMPILED', row['tag'], flush=True)
        return record
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for record in pool.map(compile_one, plan['compile']):
            cached[c.key(record['object']['path'])] = record['object']
    check(plan)
    c.save(out / 'common-objects-ready.json', dict(owners=[c.read(out / (r['tag'] + '-identity.json')) for r in plan['compile']], plan=str(plan_path)))
    print('ALL_HOST_OBJECTS_READY', out, flush=True)
    for arm, link in plan['links'].items():
        c.execute(arm + '-link', link['command'], env, out)
        check(plan)
        c.save(out / (arm + '-link-plan.json'), dict(command=link['command'], inputs=[cached[c.key(p)] for p in link['inputs']]))
        c.save(out / (arm + '-image.json'), b.identity(link['image']))
    c.save(out / 'summary.json', dict(passed=True, host_TUs=len(plan['compile']), native_TUs=0,
            SDK_rebuild=False, GPU_run=False, images={a: b.identity(v['image']) for a,v in plan['links'].items()}))
    c.save(STAGE / 'latest-check.json', dict(plan=str(plan_path), summary=str(out / 'summary.json')))
    print('BUILD_COMPLETE', plan_path, flush=True)


if __name__ == '__main__':
    main()
