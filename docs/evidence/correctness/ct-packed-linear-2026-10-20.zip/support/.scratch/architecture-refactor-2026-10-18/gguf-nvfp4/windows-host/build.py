"""Compile the retained public-header owners and focused CPU/Vulkan fixtures."""
import argparse
import concurrent.futures
import datetime as dt
import hashlib
import importlib.util
from pathlib import Path
import sys
sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parents[1]
R = A.parents[1]
spec = importlib.util.spec_from_file_location("nv_host_helpers", A / "ct-asymmetric-int4/windows-host/build.py")
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    out = args.out.resolve() if args.out else S / "checks" / dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S")
    out.mkdir(parents=True, exist_ok=True)
    (out / "tmp").mkdir(exist_ok=True)
    inventory = c.read(S / "owner-inventory.json")
    rows, dropped = [], []
    version = S.parent / "cpu-cuda/provider-version.h"
    def add(source, template, tag, old, arms, recipe):
        template = list(template)
        for flag in ("/W4", "/WX"):
            if flag not in template: template.append(flag)
        template = ["/FI" + str(version) if arg.lower().startswith("/fi") and Path(arg[3:]).name == "provider-version.h" else arg for arg in template]
        rows.append(dict(tag=tag, source=b.identity(source), old_object=old, arms=arms,
            recipe=str(recipe), command=b.host_command(template, source, tag, out),
            object=str(out / (tag + ".obj"))))
    for entry in inventory["owners"]:
        source = Path(entry["source"])
        if source.name in ("cpu_artifact_decode_test.cc", "iree_test.cc"):
            dropped.append(entry)
            continue
        tag = "o" + hashlib.sha256(entry["old_object"]["path"].encode()).hexdigest()[:8] + "--" + source.parent.name + "--" + source.stem
        add(source, entry["command_template"], tag, entry["old_object"], entry["arms"], entry["recipe"])
    # New public Graph fixture references the eight original Vulkan adapters.
    old_vk = c.read(A / "mlx-affine-widths/vulkan/checks-20261019T141537/vulkan-link-plan.json")
    for entry in old_vk["inputs"][:43]:
        obj = Path(entry["path"])
        recipe = obj.with_name(obj.stem + "-identity.json")
        record = c.read(recipe)
        source = Path(record["source"]["path"])
        if source.is_relative_to(R / "src/graph_route_vulkan"):
            add(source, record["command"], "add--graph_route_vulkan--" + source.stem,
                None, ["vulkan"], recipe)
    ct = A / "ct-asymmetric-int4/windows-host/checks/20261019T194607"
    vk = A / "ct-asymmetric-int4/vulkan/windows-host/checks/20261019T194520"
    extras = [
        ("schema", R / "tests/compute_ops/low_precision_test.cc", ct / "01-compute_ops-operation_test-identity.json", ["cpu-direct", "cpu-graph"]),
        ("nvfp4-cpu-direct", R / "tests/compute_route_cpu/gguf_nvfp4_test.cc", ct / "cpu-direct-artifact-explicit-cast-identity.json", ["cpu-direct"]),
        ("nvfp4-cpu-graph", R / "tests/compute_route_cpu/gguf_nvfp4_test.cc", ct / "cpu-graph-artifact-explicit-cast-identity.json", ["cpu-graph"]),
        ("nvfp4-vulkan", R / "tests/compute_route_vulkan/gguf_nvfp4_test.cc", vk / "tests--compute_route_vulkan--iree_test-identity.json", ["vulkan"])]
    for tag, source, recipe, arms in extras:
        command = list(c.read(recipe)["command"])
        if tag == "nvfp4-cpu-graph": command.insert(1, "/DHYLE_TEST_GRAPH_ROUTE_CPU=1")
        add(source, command, tag, None, arms, recipe)
    frozen = [b.identity(R / name) for name in ("include/hyle/compute/low_precision.h", "src/compute_ops/low_precision.cc", "tests/compute_models/gguf_nvfp4_fixture.h")]
    frozen.append(b.identity(version))
    plan = dict(compile=rows, bases=inventory["bases"], dropped_old_fixtures=dropped,
        frozen=frozen, host_TUs=len(rows), native_TUs=0, SDK_rebuilt=False, GPU_run=False)
    c.save(out / "plan.json", plan)
    c.save(S / "latest-check.json", dict(plan=str(out / "plan.json")))
    print("PLAN", out / "plan.json", "TUs", len(rows), flush=True)
    if not args.build: return
    env, runtime = b.environment(rows[0]["command"], [], out)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    c.save(out / "runtime-environment.json", dict(PATH=env["PATH"], runtime=runtime))
    def compile_one(row):
        receipt = out / (row["tag"] + "-identity.json")
        if receipt.exists():
            old = c.read(receipt)
            if old["command"] == row["command"] and b.same(old["source"]) and b.same(old["object"]) and all(b.same(d) for d in old["dependencies"]):
                return old
        job = out / "commands" / row["tag"]
        job.mkdir(parents=True, exist_ok=True)
        c.execute(row["tag"] + "-compile", row["command"], env, job)
        depfile = out / (row["tag"] + "-deps.json")
        dep = c.read(depfile)["Data"]
        paths = [dep["Source"], *dep["Includes"]]
        dependencies = []
        for name in dict.fromkeys(paths):
            path = Path(name).resolve()
            if any(path.is_relative_to(R / prefix) for prefix in ("src", "include", "tests", "third_party", ".scratch/architecture-refactor-2026-10-18/gguf-nvfp4")):
                dependencies.append(b.identity(path))
        record = dict(command=row["command"], source=row["source"], object=b.identity(row["object"]),
            source_dependencies=b.identity(depfile), dependencies=dependencies,
            old_object=row["old_object"], arms=row["arms"])
        assert b.same(row["source"])
        c.save(receipt, record)
        return record
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = list(pool.map(compile_one, rows))
    for entry in frozen: assert b.same(entry), entry["path"]
    c.save(out / "common-objects-ready.json", dict(owners=records, plan=str(out / "plan.json")))
    c.save(out / "compile-summary.json", dict(passed=True, host_TUs=len(records), native_TUs=0, SDK_rebuilt=False, GPU_run=False))
    print("ALL_HOST_OBJECTS_READY", out, flush=True)


if __name__ == "__main__": main()
