# 有限扩展检查准备

2026-10-25，源码审查；不代表新模型整机运行或正式性能测量。

| 改动方向 | 当前真实接点 | 有限判断 |
|---|---|---|
| 同家族新量化 | `prepared_roles.h` 的来源／完整物理组，`LoadedWeight` 与冷 `ProjectionBinding`，Recipe 对应数学 | 量化数学可能确实不同，应修改制品绑定和所需数学；无需改 FIFO、目录、ledger 或多请求生命周期 |
| 新家族完整状态 | 模型自有完整检查点、原状态事务、实际资源／容量查询；复用 `RequestWindow`、`PrefixDirectory<Payload>`、接受结果 | Qwen Snapshot 与 GLM StateVersion 的实际消费者已存在；无需把不同状态放进 any 或复制目录算法 |
| 后端／融合 | `engine/inference/backend.h` 的冷端点装配，原 Graph 能力与 Provider／冷资格 | 当前 Qwen 数学、请求窗口、目录和接受规则没有平台宏；不能让新的融合实现穿透请求层 |
| 多用户服务 | 现有有限 schedule 的接纳、完整 turn、共享模型／状态与真实 batch | 在线协议、等待输入／输出背压和并发槽仍须应用层明确；当前一个串行 carrier 不等于多个并行 Invocation |

共享请求窗口和目录只依赖标准库；Compute／Graph 的公开头与核心实现未反向包含引擎目录、Qwen 或 inference 策略。
`RequestProgress` 只持主机输出进度和首次采样身份；完整 pending／RNG 仍只有模型的发布边界推进。
codec 分支在冷构图而非逐 token Provider 路由中；数学差异不因抽象而丢失。

本批完成事实／入口 IO 迁移后，最后检查真实调用点是否仍向共享层泄露名字、文件路径或模型状态容器；
不为通过扩展检查新增示范模型、registry、控制器、完整模型重跑或测试矩阵。
