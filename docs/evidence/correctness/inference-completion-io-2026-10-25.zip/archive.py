"""Preserve this finite source change and its existing bounded terminal results."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,zipfile
D=Path(__file__).resolve().parent;R=D.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
proof=read(D/'verification/proof-summary.json');syntax=read(D/'caller-syntax/summary.json')
assert proof['state']=='passed' and not proof['differences'] and syntax['state']=='passed'
files=read(D/'implementation/before-pins.json')['files']
final=[pin(R/r['path'])for r in files];save(D/'final-source-pins.json',final)
patch=R/'tests/tools/qwen_mtp_prefix_value_probe.cc'
assert final[0]['sha256']=='8dfff21459d59388f231da9ddc2968b53c80c971bc3751780bf045cd4a437d13'
save(D/'syntax-fix.json',dict(source=pin(patch),scope='One preexisting diagnostic API omission found by actual caller syntax check. Original Backend.freeze keeps the original buffer-to-ReadLease ownership transfer; no compatibility Tensor API.',first_failure=syntax['first_failure'],successful_actual_caller_TUs=6))
allowed={'.cc','.h','.json','.py','.log','.patch','.md','.txt','.inc'}
chosen=[]
for sub in ['implementation','caller-syntax']:
    chosen.extend(p for p in(D/sub).rglob('*')if p.is_file()and p.suffix in allowed and p.name!='live.json')
chosen.extend(D/n for n in['independent-review.md','independent-review-pins.json','extension-scan.md','final-source-pins.json','syntax-fix.json','archive.py'])
chosen.extend(D/'verification'/n for n in['proof-summary.json','proof-pins.json','cleanup-candidates.json','proof.zip'])
archive=R/'docs/evidence/correctness/inference-completion-io-2026-10-25.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for p in sorted(chosen):z.write(p,p.relative_to(D).as_posix())
    for p in final:z.write(R/p['path'],'final-source/'+p['path'])
with zipfile.ZipFile(archive)as z:
    assert not any(Path(n).suffix.lower()in{'.obj','.exe','.dll','.lib','.pdb','.safetensors'}for n in z.namelist())
manifest=read(D/'verification/cleanup-candidates.json')
evidence=dict(state='passed',date='2026-10-25',
    scope='Global inference architecture batch: ordinary/MTP natural and fixed requests, replay, complete model state and synchronous completion-to-entry IO.',
    changes=['Completion target carries only original session/commit/fact destinations and two capture demands.',
      'Static synchronous observer borrows existing step facts, committed state and original output views within original native lease/carrier guard.',
      'Entry owns names/paths/default reporting/trace IO; raw Model finish owns original state/ledger publication. No Model IO compatibility methods.',
      'Natural/fixed observers use existing request/call storage; no added hot IO table, tensor copy, provider lookup or callback owner.',
      'Six real probe callers migrated; one preexisting stale Tensor.freeze call corrected to the original Backend.freeze.'],
    sources=final,source_checks=read(D/'implementation/source-only.json'),
    independent_review=pin(D/'independent-review.md'),
    syntax=dict(state=syntax['state'],actual_caller_TUs=6,attempts=7,first_failure=syntax['first_failure'],runtime=False),
    actual_regression={k:proof[k]for k in['state','differences','added_report_fields','report_count','baseline','late_IO_failures_observed','trace_results','trace_file_count','trace_bytes']},
    verification_archive=pin(D/'verification/proof.zip'),archive=pin(archive),
    limits=['Existing finite tiny fixtures only; no full-model quality claim or formal throughput measurement.',
      'Synchronous views may not escape, mutate state or reenter preparation. Original retirement remains authoritative.',
      'Cold graph/route diagnostics remain outside this completion-IO slice.',
      'Logical generation progress is ledger-idempotent; no byte-level exactly-once promise after partial filesystem/stream failure.',
      'Whole architecture extension review and ordinary/MTP performance remain separate goal tasks.'],
    HTTP=0,SDK_builds=0,performance_claim=False,
    cleanup=dict(performed=False,manifest=pin(D/'verification/cleanup-candidates.json'),count=manifest['count'],logical_bytes=manifest['logical_bytes'],
      scope='Only this batch rebuildable binaries and two private DLL hardlinks; retain original caches, sources, logs and traces.'))
target=R/'docs/evidence/correctness/inference-completion-io-2026-10-25.json';save(target,evidence)
board=R/'docs/developer/mtp-progress.md';text=board.read_text(encoding='utf8')
stamp=datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M')
import re
text=re.sub(r'更新：[^（]+（北京时间）',f'更新：{stamp}（北京时间）',text,count=1)
board.write_bytes(text.encode('utf8'))
print(json.dumps(dict(evidence=pin(target),archive=pin(archive),cleanup_count=manifest['count']),ensure_ascii=False))
