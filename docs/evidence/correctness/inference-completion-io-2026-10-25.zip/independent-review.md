# Independent completion / entry IO review

Result: no concrete defect found in this finite source pass. Product files were read only; no tests, builds, downloads or extra validation matrix were run by this reviewer.

Baseline: `.scratch/inference-completion-io-20261025/implementation/before` and the frozen old consumer source. Current main SHA256 `8dfff21459d59388f231da9ddc2968b53c80c971bc3751780bf045cd4a437d13`.
Reviewed the exact seven-file implementation diff, `docs/architecture/inference-design.md`, prior `next-completion-io.md`, and this batch's `extension-scan.md`.

Boundary and authority:
- EvaluationOutput now carries original session/ledger/expected-episode destinations, existing timing/observation destinations and only two explicit capture demands. Names, trace paths and trace-state policy are in entry-owned EvaluationIO.
- Model retains target/draft selection, repair, state validation, expected-base checks, no-throw all-member head swaps, pending/RNG and authoritative reserved commit witnesses. The observer receives no publication function or alternate commit state.
- CompletedEvaluationView is a synchronous borrow: one existing StepObservation reference, the already committed const Snapshot reference, actual row/batch geometry and optional original tensor/probe views. It does not add a SnapshotRef, executor, provider lookup, registry or second statistics table.
- Model convenience IO methods are deleted. The qwen35 free functions implement the actual single-call entry adapter; no old compatibility methods or aliases remain.

Output and retirement lifetimes:
- Generated logits/hidden and all nine probe ReadLeases are still retained before take_append/unbind revokes output observation. They remain on the same Model finish stack until all synchronous observers return or throw.
- Caller-owned output views still borrow the original phase buffers. ReturnReadback keeps candidate_admission/carrier protection after detach_episode and throughout the observer; it clears only on function exit.
- Captured state views borrow the newly committed Snapshot, whose original output Session shared owner stays alive for the entire call. No extra version/N-budget ownership is acquired for reporting.
- The observer explicitly cannot escape these borrowed views or reenter preparation. Unknown device retirement and all original abort/retention mechanisms are unchanged; IO completion does not become a retirement proof.

Failure and cost:
- All ledger endpoint/step_seconds facts are filled after commit and before the first observer. Preparation-report queries remain postcommit at their original point, so a query/file/stream error cannot be reclassified as an unpublished episode.
- The observer remains outside the model commit try/catch. Natural execute_generation_calls preserves its catch-side observe_generation_commits path and original observation cursor, so late IO cannot resample, recommit or duplicate logical output.
- This retains logical progress idempotence; it does not promise byte-level exactly-once file/ostream output after a partial IO failure.
- capture_tensors exactly replaces the prior nonempty-trace demand; capture_probes replaces the prior nonempty model L0-probe demand. When disabled there is no new retain, tensor readback, trace byte allocation or output-view conversion. Static stack lambdas add no callback heap/dispatch table.
- Existing fallback printing and caller-provided StepObservation behavior remain equivalent. Optional preparation observations still query only when requested.

Actual call sites:
- Natural ordinary/MTP, strict replay, committed-token rebuild, fixed-tape buckets and single convenience entries all invoke the same synchronous handoff.
- Fixed bucket IO uses the original selected member index; natural IO reads existing calls directly. No per-R duplicate IO owner array is introduced in these hot callers.
- batch_probe, mtp_session_probe, retained_budget_probe, retirement_probe, qwen_random_mtp_probe and qwen_mtp_prefix_value_probe were checked against their exact before files. Their original names/paths/trace flags/ledger expectations and actual single/R2 roles are preserved, including explicit policy-rejection and late-IO cases.
- Full prefix hits remain the original no-Graph observation path, not a fabricated tensor capture. Cold route/initialization diagnostics remain outside this finite slice as explicitly scoped.

Finite extension conclusion:
- The extension-scan conclusion is supported: shared RequestWindow/PrefixDirectory have no model dependency; new codecs may require real distinct cold math; model checkpoints retain their actual state/transaction identities; Graph/Compute core has no reverse engine coupling introduced here.
- The design does not claim arbitrary GLM prompt support, online server backpressure, multiple concurrent Invocations or full backend coverage. No new interface, sample model or matrix is needed for this review.
- Source review is complete without a concrete blocker. The already assigned bounded old/current consumer and diagnostic/late-IO checks must supply their actual terminal results before the batch is called behavior-preserving; this note does not substitute source reading for execution.

Supplemental source check (root syntax correction): the exact before source also calls removed `Tensor::freeze`. The replacement at prefix_value:97, `check(model.execution.freeze(retained.back().buffer, retained.back().ready))`, uses the actual Backend resource owner to move the freshly written device Buffer into its ReadLease and checks the returned Status. Both `retained` and `shifted` hold that original lease through synchronous `execute_draft`; no weight annotation, extra copy, compatibility API or lifetime escape is added. Final prefix-value source SHA256 `cf6fa0262448d49ac44441c6af8016ccda1584f87cde7f882c043d0f3cef208e`; main remains `8dfff21459d59388f231da9ddc2968b53c80c971bc3751780bf045cd4a437d13`. Root reports the one failed TU's strict syntax rerun passed and actual eight reports, byte comparisons for 44 trace files and late-IO controls passed; this supplemental check added no execution.
