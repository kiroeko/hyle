# Completion facts / entry IO source handoff

- Exact before source, changes.patch, after-pins.json and source-only.json describe seven canonical files. No compile/model/network was run by this agent.
- EvaluationOutput is completion-only: original SessionRef, two capture demands, original timing/report destinations, GenerationLedger and expected episode.
- CompletedEvaluationView borrows the existing mutable StepObservation, const committed Snapshot, member index/batch width and optional read-only logits/hidden/probe views. It owns no Snapshot, native lease or runtime pointer.
- Model finish_selected_evaluations and plain/classic/recursive finish entry points require a statically typed synchronous observer. There is no default observer, dynamic callback owner or compatibility Model IO wrapper.
- wait/selection/export/repair/ledger validation/expected-base/batch publication/abort/admission-guard body is the original code; only diagnostic capture gates now consume the two explicit demands.
- All committed record endpoints are still written before the first potentially failing observer. Preparation report queries and StepObservation fields remain in their original postcommit order.
- ReturnReadback and generated native ReadLease owners remain on the finish stack through all observers and exception unwinding. Caller-owned phase outputs cannot be reused until that scope ends.
- Entry observe_completed_evaluation reuses execution_report.cc and the original Qwen trace names/dtypes/errors; Backend::read and true committed-state storage remain authoritative.
- No trace/probe demand creates no additional capture, native readback or heap output owner. The new completion view is stack metadata only.
- Natural/fixed/replay observers derive IO from existing calls/runs. No new batch-sized IO vector is introduced; fixed diagnostic probes use small original bounded arrays.
- Genuine entry free functions are evaluate(Model&,Session&,...), finish_evaluation(Model&,Session&,...), finish_mtp_round(Model&,Session&,pending,quota,eos,output*,io).
- evaluation_output(model,SessionRef,io,timing,endpoint,observation,preparation,ledger,expected) builds the target; observe_completed_evaluation(model,target,io,view) performs entry IO.
- Existing logical observation idempotence remains GenerationLedger/ledger_observed; no new exactly-once guarantee for partially failed filesystem/ostream bytes.
- Synchronous views must not escape, reenter preparation, retire or mutate request/state. Asynchronous reporting or an external callback API is outside this slice.
- Cold Model graph/route diagnostics remain explicitly outside the completion-IO slice. Model math, source precision, state containers and public Graph/Compute APIs were not changed.
