"""Parse only the six real changed consumers; no linking or inference."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import importlib.util,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent; R=D.parents[2]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=b.args(R/'.scratch/qwen-mtp-final-window-20261024/preparation-segments-proposal/actual/compile1/qwen/compile.command.json')
flags=[];skip=False
for word in old[1:]:
    if skip:skip=False;continue
    if word=='/sourceDependencies':skip=True;continue
    lower=word.lower().replace('\\','/')
    if lower.startswith(('/fo','/fd')) or lower.endswith(('.cc','.cpp')):continue
    if lower.startswith('/i') and lower.endswith('/tools/qwen35_text'):continue
    flags.append(word)
env=b.environment(old[0]); flags.append('/Zs')
records=b.read(D.parent/'implementation/before-pins.json')['files'][1:]
sources=[R/p['path']for p in records]
before=[b.pin(R/'engine/models/qwen35/main.cc'),*[b.pin(p)for p in sources]]
if before[0]['sha256']!='8dfff21459d59388f231da9ddc2968b53c80c971bc3751780bf045cd4a437d13':raise ValueError('Implementation changed; inspect it')
def run(source):
    folder=D/source.stem
    b.execute([old[0],*flags,'/sourceDependencies',str(folder/'dependencies.json'),str(source)],folder,env,90)
    return dict(source=b.pin(source),process=b.read(folder/'process.json'))
with ThreadPoolExecutor(max_workers=2)as pool: results=list(pool.map(run,sources))
after=[b.pin(R/'engine/models/qwen35/main.cc'),*[b.pin(p)for p in sources]]
if before!=after:raise ValueError('Canonical source changed during syntax check')
b.save(D/'summary.json',dict(state='passed',checks=results,before=before,after=after,
    scope='Actual changed six caller TUs, MSVC /W4 /WX /Zs using retained CUDA include/toolchain flags. No object generation, link, runtime, matrix, SDK build, or HTTP.',
    inference_runs=0,SDK_builds=0,HTTP=0))
