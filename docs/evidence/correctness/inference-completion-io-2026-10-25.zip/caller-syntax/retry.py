"""Only repeat the failed actual TU after replacing its stale Tensor helper."""
from pathlib import Path
import importlib.util,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2]
spec=importlib.util.spec_from_file_location('retained',R/'.scratch/mtp-extraction-regression-20261024/check.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
prior=b.read(D.parent/'implementation/after-pins.json')['files']
source=R/'tests/tools/qwen_mtp_prefix_value_probe.cc'
command=b.args(D/'qwen_mtp_prefix_value_probe/command.json')
folder=D/'qwen_mtp_prefix_value_probe_retry'
command=[str(folder/'dependencies.json')if x==str(D/'qwen_mtp_prefix_value_probe/dependencies.json')else x for x in command]
before=b.pin(source)
b.execute(command,folder,b.environment(command[0]),90)
if before!=b.pin(source):raise ValueError('Source changed during syntax check')
records=[]
for row in prior[1:]:
    p=R/row['path'];location=folder if p==source else D/p.stem
    actual=b.pin(p)
    if p!=source and actual['sha256']!=row['sha256']:raise ValueError('Unrelated caller changed')
    process=b.read(location/'process.json')
    if process['exit'] or process['timeout']:raise ValueError('Syntax consumer did not pass')
    records.append(dict(source=actual,process=process,command=b.pin(location/'command.json')))
b.save(D/'summary.json',dict(state='passed',checks=records,
    main=b.pin(R/'engine/models/qwen35/main.cc'),
    first_failure=dict(source_before=[r for r in prior if r['path']==source.relative_to(R).as_posix()][0],
        process=b.read(D/'qwen_mtp_prefix_value_probe/process.json'),
        output=b.pin(D/'qwen_mtp_prefix_value_probe/stdout.log'),
        cause='Preexisting Tensor::freeze call in diagnostic consumer; also present in exact before source. Use original Backend.freeze(buffer,ready) directly.',
        after=before),
    syntax_TUs=6,attempts=7,linked=False,runtime=False,SDK_builds=0,HTTP=0))
