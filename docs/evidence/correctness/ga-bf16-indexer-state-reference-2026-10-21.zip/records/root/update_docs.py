from pathlib import Path
import json
P=Path(__file__).resolve().parents[1]; R=P.parents[2]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
for arm in ('cpu','cuda','vulkan'):
    d=read(P/arm/'validation/final1/receipt.json'); assert d['passed'] and d['cases']==4 and not d['skipped']
a=read(P/'apple/final-validation.json'); assert a['failed']==a['skipped']==0
pending={}
def change(path,old,new):
    p=R/path; text=pending.get(p,p.read_text(encoding='utf8')); assert text.count(old)==1,(path,old)
    pending[p]=text.replace(old,new)
e='../evidence/correctness/ga-bf16-indexer-state-reference-2026-10-21.json'
change('docs/developer/current-work.md',
 '第8包进行中；普通E4成对pending生产／页读取已四端闭环，修复未提交copy槽的原生产者退休检查；下一项核正式GA非CUDA indexer／状态链',
 '第8包进行中；GA BF16缓存评分／Top512／I32映射与同代状态已四端消费；下一项补ratio4 F32重叠压缩生产者')
change('docs/developer/current-work.md',
 '**当前下一动作**：核交付3的正式GA非CUDA BF16 indexer→score／TopK→压缩状态旅程，继续对齐精确角色与原公共执行链，不扩大为33整模型验收。',
 '**当前下一动作**：补正式GA ratio4的F32重叠压缩生产者，衔接真实BF16 indexcache与已有score／TopK消费者；核增量窗口、跨压缩边界与接受前缀后续算，随后继续mHC／路由／专家等精确组合。\n'
 f'本批[GA角色边界与通用缺口]({e})四端共17项通过、0跳过：12项新增、5项相邻检查；共享普通Graph共52次成功提交。\n'
 '补TopK(0)、I32 GatherElements及CUDA准入／Vulkan原码恢复，Vulkan还补真实batch pitch的BF16 RHS内部布局适配。\n'
 'B2/H64/D128、active515/pitch520、Top512，score保三处BF16边界、同代StateVersion／Head与旧结果；省略中间舍入会改变4104个参考值。\n'
 '这些是固定正式源的post-QAT角色边界，未签F32 compressor、完整attention／模型、Pro Top1024整链、Linux或吞吐。\n'
 '清理本轮镜像并保增量对象／共享缓存的范围见[实录](../evidence/correctness/ga-bf16-indexer-state-reference-2026-10-21.cleanup.json)。')
change('docs/developer/current-work.md',
 'Apple完整通用mixed-width MoE已补实际闭环；精确模型的路由／shared／mHC组合与GA非CUDA新角色仍待核，不能由通用softmax路由或旧F32／FP4载体代签。',
 'Apple完整通用mixed-width MoE、GA四端BF16 score／Top512与同代cache／几何消费已补实际闭环；精确模型的F32压缩生产者、路由／shared／mHC组合仍待核，不能由通用softmax路由或旧F32／FP4载体代签。')
change('docs/user/compute.md',
 '该操作保留F32/F16/BF16值类型，',
 '该操作保留F32/F16/BF16或I32数据原码，')
change('docs/user/compute.md',
 'CUDA默认图已接通CCCL TopK→ggml GatherElements；',
 'I32候选表可直接保存偏移后的ID或数据值`-1`，不经过浮点转换；Checked检查的是indices，data中的负数合法。\n'
 'CUDA默认图已接通CCCL TopK→ggml GatherElements；')
change('docs/user/compute.md',
 '真正 variadic 的 descriptor span。两者都把 provider/route 选择移出热路径。',
 '真正 variadic 的 descriptor span。TopK的`count=0`合法，即使输入所选轴非空，也返回该轴为0的values／I32 indices，\n'
 '不读取或排序payload；其它axis、类型与范围检查照常。原生零字节结果可用`GraphOutput::description()`检查，不要求导出零字节lease。\n'
 '两者都把 provider/route 选择移出热路径。')
change('docs/implementation/model-operators.md',
 '这只补该 CUDA 复合承载；四后端 FP4 RowCache bank 仍与正式 BF16 cache 分开，完整 GA 模型及其它平台的新承载仍待完成。',
 '这只补该 CUDA 复合承载；四后端 FP4 RowCache bank 仍与正式 BF16 cache 分开。\n'
 f'后续[四端BF16角色消费者]({e})已核同一普通图：H64/D128、B2 active515/pitch520、Top512、三处BF16舍入、causal mask、I32 offset／-1映射与同代StateVersion／Head。\n'
 '17项含12项新增与5项邻居，0跳过；共享Graph共52次成功提交。修TopK(0)、I32 GatherElements及Vulkan BF16 prefix准入；\n'
 'CPU现ATen会在provider内打包／转换，Vulkan按实际stride在原lowerer整理唯一RHS，不展开共享T/H，均不称零内部复制。\n'
 'F32重叠压缩生产者、完整attention／GA模型、Pro Top1024整链、Linux、质量及吞吐仍未签；不是所选权重payload执行。')
change('docs/implementation/model-operators.md',
 '通用axis/bounds能力保留，实际GA ID与stride合同另核',
 f'通用axis/bounds能力保留，已补I32原码与[同代GA候选映射]({e})；GPU当前rank2末轴，B/T可元数据展平，完整模型仍未验')
change('docs/implementation/model-operators.md',
 '保留该承载并核GA BF16舍入/接线；模型fixture未直接调用，不能把GLM H32或合成测试称GA支持',
 '保留原F32承载，GA三BF16边界另沿已核普通图／CUDA复合承载；不扩该旧descriptor或以GLM H32代签GA模型')
for p,text in pending.items(): p.write_text(text,encoding='utf8')
print('Updated plan, user contracts and exact role table; full compressor/model remain open.')
