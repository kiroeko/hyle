from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parents[1]; R=P.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resolve(p):p=Path(p);return p if p.is_absolute() else R/p
def ident(p):return dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def check(d):
 p=resolve(d['path']);assert p.is_file() and p.stat().st_size==d['bytes'] and sha(p)==d['sha256'],str(p)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
cases=[];receipts=[]
def collect(arm,p):
 for x in ET.parse(p).findall('.//testcase'):
  assert x.find('failure') is None and x.find('skipped') is None
  name=x.get('classname')+'.'+x.get('name')
  cases.append(dict(backend=arm,name=name,neighbor='PositiveSelection' in name or name.startswith('AppleReduction.'),
    properties={i.get('name'):i.get('value') for i in x.findall('./properties/property')}))
for arm in ('cpu','cuda','vulkan'):
 p=P/arm/'validation/final1/receipt.json';d=read(p)
 assert d['passed'] and d['cases']==4 and not d['skipped'] and not d['failed']
 for k in ('image','link_plan','xml'):check(d[k])
 for row in read(resolve(d['link_plan']['path']))['inputs']:check(row)
 for row in read(p.parent/'runtime-environment.json').get('private_modules',[]):
  check(row['source']);check(row['destination']);assert row['hardlink'] and row['source']['sha256']==row['destination']['sha256']
 collect(arm,resolve(d['xml']['path']));receipts.append(dict(backend=arm,receipt=ident(p)))
ap=P/'apple/final-validation.json';a=read(ap);assert a['tests']==5 and a['failed']==a['skipped']==0
for k in ('source_freeze','gtest','run','link'):check(a[k])
collect('apple',resolve(a['gtest']['path']))
assert len(cases)==17 and sum(not x['neighbor'] for x in cases)==12
roles=[x for x in cases if x['name'].endswith('.BfloatCacheScoresSelectionAndVersionedIntegerGeometry')]
assert len(roles)==4 and all(x['properties']['rounding_counterfactual_differences']=='4104' for x in roles)
assert all(x['properties']['successful_submissions']=='2' and x['properties']['TopK']=='512' for x in roles)
empty=[x for x in cases if x['name'].endswith('.EmptySelectionKeepsTwoShapesAndIndependentResults')]
mapping=[x for x in cases if x['name'].endswith('.OriginalIntegerCandidatesKeepEveryBitAndOldResults')]
assert len(empty)==len(mapping)==4
assert all(x['properties']['successful_submissions']=='8' for x in empty)
assert all(x['properties']['successful_submissions']=='2' for x in mapping)
catalog=read(R/'docs/implementation/model-quantizations.json');assert len(catalog['artifacts'])==33
assert all(x['provider_coverage']['artifact_execution_verified'] is False for x in catalog['artifacts'])
sources=['include/hyle/compute/model_ops.h','include/hyle/compute/state_versions.h',
 'src/compute_ops/operation.cc','src/compute_provider_ggml/standard_index.cc',
 'src/compute_provider_cuda/collectives_provider.cc','src/compute_provider_ggml_cuda/tensor_program.cc',
 'src/compute_route_vulkan/vulkan_region.cc','src/compute_provider_ggml_vulkan/region.cc',
 'src/compute_state/state_versions.cc','src/compute_state/state_internal.h',
 'tests/compute_models/ga_indexer_state_fixture.h','tests/compute_models/nvfp4_reference_fixture.h',
 'tests/compute_ops/operation_test.cc','tests/compute_provider_cuda/collectives_test.cc',
 'tests/compute_route_vulkan/topk_test.cc','tests/compute_route_apple/reduction_test.cc',
 'docs/developer/current-work.md','docs/user/compute.md','docs/implementation/model-operators.md']
sources += [f'tests/graph_route_{arm}/{name}' for arm in ('cpu','cuda','vulkan','apple') for name in ('ga_indexer_state_test.cc','CMakeLists.txt')]
entries={'source/'+s:R/s for s in sources}
suffixes={'.json','.py','.log','.txt','.xml','.diff','.cc','.h','.hpp','.md','.mm','.ps1','.cmake','.in','.d'}
for p in P.rglob('*'):
 if p.is_file() and p.suffix.lower() in suffixes and not p.name.startswith(('package-summary','cleanup-plan','cleanup-script','final-package')):
  entries['records/'+p.relative_to(P).as_posix()]=p
for name in ('deepseek-v4-ga-2026-10-19.zip','ga-indexer-gap-2026-10-20.json','ga-indexer-design-2026-10-20.json'):
 entries['provenance/'+name]=R/'docs/evidence/research'/name
archive=R/'docs/evidence/correctness/ga-bf16-indexer-state-reference-2026-10-21.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for name,p in sorted(entries.items()):z.write(p,name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(entries)
 for name,p in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p),name
doc=dict(observed_on='2026-10-21',status='four_backend_BF16_score_state_boundary_and_zero_selection_passed',
 scope='Fixed official GA Indexer numerical/resource boundary, not a whole model: actual BF16 Q/K/W at post-QAT boundary, H64/D128, B2, active515 with physical batch pitch520, ordinary BF16 MatMul/Relu/Multiply/F32-accumulated sum, mask, exact final F32 widening, Top512, original I32 candidate mapping and StateVersion/Head.',
 math='Independent F32 steps and BF16 RNE. Q/K nonzero terms are E2M1 times power2 in separate group32 blocks0/32, permitting original QAT values without claiming a producer run; prescaled weights are BF16. Masked score bytes match exactly. Removing intermediate rounds changes4104 reference values per backend. TopK compares sorted score multiset, valid unique local IDs and exact mapped I32 words without imposing an unspecified vendor tie ordering.',
 fixes=dict(TopK='Public count0 now yields two zero-length-axis descriptions for empty/nonempty source. CPU standard-index reuses original no-op and zero scratch; CUDA reuses original zero-count Program before CUB planning/payload pointer access; Vulkan skips managed argsort and returns two original no-work outputs; Apple already has the corresponding native empty branch.',
  GatherElements='Public pure data gather also admits I32. CPU ATen byte gather and Apple native take already preserve original words. CUDA allows I32 source storage only for existing Concat/GatherElements paths, retaining original integer GET_ROWS. Vulkan restores raw I32 word carrier instead of numerically casting its rawbits as F32. Actual tests include >2^24, INT32 extrema, -1 and floating NaN/subnormal bit patterns.',
  prefix='Vulkan now qualifies the actual rank2-4 transposed row-contiguous, nonoverlapping positive batch pitches within scalar/native byte capacity. Its existing cold lowerer generates a typed stride layout Copy of only the unique active RHS, not a T/H-expanded bank. CPU existing ATen fallback packs logical bytes/converts numerically internally. No caller-side Copy, new public scorer, provider/model branch or executor is introduced.'),
 lifetime='Cache BF16 storage, F16 mask, I32 map and host geometry belong to one StateVersion. Both generations execute through independent original Graph invocations; successful second Completion precedes StateHead compare-publish, stale-head publication rejects. Old results survive the second generation and invocation/executable/state-store destruction. Empty results retain descriptions without demanding independent zero-byte leases.',
 regression=dict(total=17,new_cases=12,neighbors=5,failed=0,skipped=0,shared_Graph_successful_submissions=52,
  new_Graph_successful_submissions=48,positive_neighbor_Graph_submissions=4,expected_failure_submissions=0,
  windows=receipts,apple=ident(ap),cases=cases),
 build='Windows9 strict CXX plus3 focused links; Apple4 strict CXX plus1link. No SDK/NVCC/shader build. Reuse actual current products and caches, remove unselected old test-only objects to avoid old GatherElements inline infer thunks; bounded defined-symbol audit refreshes only the two remaining actual constructor owners. Mac and Vulkan replace the old single-owner state archive with current state_versions object. Canonical four route tests are registered; full canonical reconfiguration/install and unrelated updated test TUs are not claimed run.',
 limitations=['Post-QAT consumer/resource boundary only: F32 overlapping compressor producer, its norm/RoPE/Hadamard/FP4 path and incremental publication still need the next complete journey.',
  'No projection/weight payload, Pro Top1024 complete role chain, full sparse attention/model, Linux, quality, capture or throughput acceptance. Existing packed68B indexer is a separate storage contract.',
  'No claim of zero provider-internal copies/conversions or one physical fused kernel. No new checked-invalid-index failure submission in this selected run; original error code paths are source-reviewed and preserved.',
  'Capability7/8 and delivery0/3 remain open. All33 artifact_execution_verified remainfalse. Final current-source/install/Linux closure remains pending.'],
 remaining_required='Continue ratio4 F32 overlap compressor -> genuine BF16 indexcache across first-empty/prefill/decode/compression boundaries and accepted-prefix continuation; then remaining exact role combinations, states and delivery packages.',
 current_sources=[ident(R/s) for s in sorted(sources)],archive=dict(**ident(archive),members=len(entries)),
 archive_entries=[dict(entry=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(entries.items())])
save(archive.with_suffix('.json'),doc)
summary=dict(evidence=ident(archive.with_suffix('.json')),archive=doc['archive'],sources=len(sources),cases=17)
save(P/'root/package-summary.json',summary);print(json.dumps(summary,ensure_ascii=False))
