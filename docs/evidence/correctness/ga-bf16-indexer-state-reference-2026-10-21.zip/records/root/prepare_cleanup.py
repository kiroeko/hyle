from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parents[1];R=P.parents[2]
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def ident(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
report=R/'docs/evidence/correctness/ga-bf16-indexer-state-reference-2026-10-21.json'
d=read(report);archive=R/d['archive']['path'];assert ident(archive)['sha256']==d['archive']['sha256']
remove=[ident(p) for p in P.rglob('*') if p.is_file() and p.suffix.lower() in ('.exe','.map')]
keep=[ident(p) for p in P.rglob('*.obj')]
runtime=read(P/'cuda/validation/final1/runtime-environment.json')
assert len(runtime['private_modules'])==1
staging=runtime['private_modules'][0]
staged=Path(staging['destination']['path']);cache=Path(staging['source']['path'])
assert staged.resolve().is_relative_to(P.resolve()) and staged.suffix.lower()=='.dll'
assert ident(staged)==staging['destination'] and ident(cache)==staging['source']
remove.append(ident(staged))
keep_cache=[ident(cache)]
assert remove and keep
mac_base='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/ga-bf16-indexer-state-2026-10-21'
m=read(P/'apple/cleanup-readonly-inventory.json')
mac_base=m['remote_root']
mac_remove=m['deletable_files'];mac_keep=m['retained_objects']
assert len({x['path'] for x in mac_remove})==len(mac_remove)
plan=dict(allowed_windows=str(P.resolve()),allowed_mac=mac_base,remove_windows=remove,keep_windows=keep,keep_runtime_cache=keep_cache,
          remove_mac=mac_remove,keep_mac=mac_keep,evidence=ident(report),archive=ident(archive))
planpath=P/'root/cleanup-plan.json';save(planpath,plan)
mac_program='''import pathlib,hashlib,json,subprocess
plan=json.loads(PLAN_TEXT)
base=pathlib.Path(plan['allowed_mac']); assert base.is_dir() and not base.is_symlink()
def verify(row):
 p=pathlib.Path(row['path']); assert p.is_absolute() and not p.is_symlink() and p.resolve().is_relative_to(base.resolve())
 assert p.is_file() and p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],str(p)
 return p
paths=[verify(x) for x in plan['remove_mac']]
for row in plan['keep_mac']:verify(row)
active=subprocess.check_output(['ps','-axo','command='],text=True)
assert not any(str(p) in command for p in paths for command in active.splitlines() if not command.startswith('python3 -')), 'test executable is running'
for p in paths:p.unlink()
for row in plan['keep_mac']:verify(row)
print(json.dumps(dict(removed=len(paths),bytes=sum(x['bytes'] for x in plan['remove_mac']),kept_objects=len(plan['keep_mac']))))
'''.replace('PLAN_TEXT',repr(json.dumps({k:v for k,v in plan.items() if k in ('allowed_mac','remove_mac','keep_mac')})))
script=r'''# Exact GA typed score/state test-artifact cleanup. No recursive directory removal.
$ErrorActionPreference = 'Stop'
$plan = Get-Content -LiteralPath '__PLAN__' -Raw | ConvertFrom-Json
$separator = [IO.Path]::DirectorySeparatorChar
$allowed = [IO.Path]::GetFullPath($plan.allowed_windows).TrimEnd($separator) + $separator
function Assert-Identity($row) {
  $file = Get-Item -LiteralPath $row.path -ErrorAction Stop
  if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not a regular file: $($row.path)" }
  if ($file.Length -ne $row.bytes -or (Get-FileHash -LiteralPath $row.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $row.sha256) { throw "Identity changed: $($row.path)" }
}
Assert-Identity $plan.evidence
Assert-Identity $plan.archive
foreach ($row in $plan.remove_windows) {
  $full = [IO.Path]::GetFullPath($row.path)
  if (-not $full.StartsWith($allowed, [StringComparison]::OrdinalIgnoreCase) -or [IO.Path]::GetExtension($full) -notin '.exe','.map','.dll') { throw "Outside exact artifact scope: $full" }
  Assert-Identity $row
}
foreach ($row in $plan.keep_windows) { Assert-Identity $row }
foreach ($row in $plan.keep_runtime_cache) { Assert-Identity $row }
$active = @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($allowed, [StringComparison]::OrdinalIgnoreCase) })
if ($active.Count) { throw 'A test executable in this exact workspace is still running' }
foreach ($row in $plan.remove_windows) { Remove-Item -LiteralPath $row.path -Force }
foreach ($row in $plan.keep_windows) { Assert-Identity $row }
foreach ($row in $plan.keep_runtime_cache) { Assert-Identity $row }
$macProgram = @'
__MAC__
'@
$macResult = $macProgram | & ssh kiro@172.22.10.198 python3 -
if ($LASTEXITCODE -ne 0) { throw 'Mac exact-file cleanup failed; do not report both platforms completed' }
$result = [ordered]@{
  completed = $true
  windows_removed = @($plan.remove_windows).Count
  windows_bytes = ($plan.remove_windows | Measure-Object -Property bytes -Sum).Sum
  windows_kept_objects = @($plan.keep_windows).Count
  mac = ($macResult | ConvertFrom-Json)
  evidence_sha256 = $plan.evidence.sha256
  archive_sha256 = $plan.archive.sha256
  exact_plan = $plan
  source_script = [IO.File]::ReadAllText($PSCommandPath)
}
$result | ConvertTo-Json -Depth 18 | Set-Content -LiteralPath '__RECEIPT__' -Encoding utf8
[pscustomobject]$result | Select-Object completed,windows_removed,windows_bytes,windows_kept_objects,mac | ConvertTo-Json -Depth 5
'''
receipt=R/'docs/evidence/correctness/ga-bf16-indexer-state-reference-2026-10-21.cleanup.json'
assert not receipt.exists()
script=script.replace('__PLAN__',str(planpath.resolve())).replace('__MAC__',mac_program.strip()).replace('__RECEIPT__',str(receipt))
(R/'test.ps1').write_text(script,encoding='utf8')
save(P/'root/cleanup-script-identity.json',ident(R/'test.ps1'))
print(json.dumps(dict(windows_files=len(remove),windows_bytes=sum(x['bytes'] for x in remove),
    windows_objects=len(keep),mac_files=len(mac_remove),mac_bytes=sum(x['bytes'] for x in mac_remove)),ensure_ascii=False))
