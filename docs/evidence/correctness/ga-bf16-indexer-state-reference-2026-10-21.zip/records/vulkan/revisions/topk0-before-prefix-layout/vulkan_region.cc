#include "vulkan_iree.h"
#include "vulkan_mlx.h"
#include "vulkan_program_internal.h"
#include "vulkan_tensor.h"
#include "hyle/compute/model_ops.h"

#include <algorithm>
#include <array>
#include <bit>
#include <new>

namespace hyle::compute::vulkan::detail {
namespace provider = ggml_vulkan::detail;
namespace {
bool layout_limits(const ProgramState &program, const PlanStep &step) noexcept {
  const auto &limits = program.runtime->device->properties.limits;
  const auto paged=step.operation.custom_as<provider::PagedAttentionRead>();
  const auto fits = [&](std::uint32_t value) {
    const auto& description=program.values[value].description;
    const auto count = *description.element_count();
    if(paged && (paged->paged || paged->compact_mla) && paged->float8_cache &&
       (value==step.inputs[1] || (!paged->compact_mla && value==step.inputs[2]))) {
      // This tagged reader loads original E4 bytes per tile; no F32 bank is
      // materialized. Q conversion and the F32 result retain the old limits.
      const auto bytes=description.required_bytes();
      return bytes && *bytes<=limits.maxStorageBufferRange && count<=INT32_MAX;
    }
    return count <= limits.maxStorageBufferRange / sizeof(float) &&
           (count + 262143) / 262144 <= limits.maxComputeWorkGroupCount[2];
  };
  // The original cont/repeat/concat adapters use 512-lane flattened dispatches.
  // Check the intermediate F32 materialization as well as the public output.
  return limits.maxComputeWorkGroupInvocations >= 512 &&
         limits.maxComputeWorkGroupSize[0] >= 512 &&
         limits.maxComputeWorkGroupCount[0] >= 512 &&
         limits.maxComputeWorkGroupCount[1] >= 512 &&
         std::ranges::all_of(step.inputs, fits) &&
         std::ranges::all_of(step.outputs, fits);
}
bool topk_limits(const ProgramState &program, const TensorDesc &input,
                 const TopK &selection) noexcept {
  const auto axis = static_cast<std::size_t>(
      selection.axis < 0
          ? selection.axis + static_cast<std::int32_t>(input.rank())
          : selection.axis);
  const auto width = static_cast<std::uint32_t>(input.dimensions()[axis]);
  const auto rows = *input.element_count() / width;
  const auto padded = std::bit_ceil(width);
  const auto &limits = program.runtime->device->properties.limits;
  const auto max_group = std::bit_floor(limits.maxComputeWorkGroupInvocations);
  if (max_group == 0 || limits.maxComputeWorkGroupCount[1] == 0)
    return false;
  const auto exponent = std::bit_width(padded) - 1u;
  const auto pipeline = (std::min)(exponent, 10u);
  const auto block = (std::min)(1u << pipeline, max_group);
  const bool small =
      padded <= max_group &&
      std::uint64_t{block} * 8 <= limits.maxComputeSharedMemorySize;
  if (small)
    return padded == block && block <= limits.maxComputeWorkGroupSize[0] &&
           limits.maxComputeWorkGroupCount[0] != 0;
  // The large kernel stores ivec2 for each padded element and unrolls two
  // elements per lane. Later cross-workgroup passes use pipeline index - 2.
  const auto smallest_block =
      padded <= max_group
          ? block
          : (std::min)(1u << (pipeline > 2 ? pipeline - 2 : 0), max_group);
  const auto lanes = block > 1 ? block / 2 : 1;
  return std::uint64_t{padded} * rows <= limits.maxStorageBufferRange / 8 &&
         lanes <= limits.maxComputeWorkGroupSize[0] &&
         (padded + smallest_block - 1) / smallest_block <=
             limits.maxComputeWorkGroupCount[0];
}

bool scan_limits(const ProgramState &program,
                 const TensorDesc &matrix) noexcept {
  const auto &limits = program.runtime->device->properties.limits;
  const std::uint64_t elements = *matrix.element_count();
  const auto width = static_cast<std::uint64_t>(matrix.dimensions().back());
  const auto rows = elements / width;
  const auto lanes = width <= 512 ? 128U : 256U;
  if (elements > INT32_MAX || elements > limits.maxStorageBufferRange / 4 ||
      lanes > limits.maxComputeWorkGroupInvocations ||
      lanes > limits.maxComputeWorkGroupSize[0] ||
      (std::min)(rows, std::uint64_t{512}) >
          limits.maxComputeWorkGroupCount[0] ||
      (std::min)((rows + 511) / 512, std::uint64_t{512}) >
          limits.maxComputeWorkGroupCount[1] ||
      (rows + 262143) / 262144 > limits.maxComputeWorkGroupCount[2])
    return false;
  // The original device rule may select two passes for wide, short matrices.
  // Admit only shapes legal for either native choice; never dispatch then
  // discover that the selected pipeline exceeds the physical grid limits.
  return width <= 4096 ||
         ((width + 127) / 128 <= limits.maxComputeWorkGroupCount[0] &&
          rows <= limits.maxComputeWorkGroupCount[1]);
}
bool transposed_dense_matrix(const TensorDesc &description) noexcept {
  if (!description.is_plain() || description.rank() < 2 || description.rank() > 4 ||
      description.is_dense())
    return false;
  const auto physical = description.transposed();
  return physical && physical->is_dense();
}
bool region_operation(const ProgramState &program, const PlanStep &step,
                      bool promote_bfloat) noexcept {
  const auto max_inputs =
      step.operation.custom_as<model_ops::RecurrentGatedDeltaNet>() ? 8U : 6U;
  if (step.custom || step.inputs.size() > max_inputs || step.outputs.size() > 2)
    return false;
  std::array<TensorDesc, 8> inputs;
  std::size_t input_count = 0;
  for (const auto input : step.inputs) {
    const auto &description = program.values[input].description;
    // Empty Concat ports retain their public binding contract but have no
    // storage to import into the original backend.
    if (!step.operation.get_if<Concat>() || *description.element_count() != 0)
      inputs[input_count++] = description;
  }
  std::array<TensorDesc, 2> outputs;
  for (std::size_t i = 0; i < step.outputs.size(); ++i)
    outputs[i] = program.values[step.outputs[i]].description;
  if (const auto *softmax = step.operation.get_if<Softmax>();
      softmax && softmax->mask == MaskKind::kAdditive && input_count == 2 &&
      inputs[0].data_type() != inputs[1].data_type())
    return false;
  const auto &features = program.runtime->device->provider.native();
  const auto low_precision = [](const TensorDesc &description) {
    return description.data_type() == DataType::kFloat16 ||
           description.data_type() == DataType::kBFloat16;
  };
  if ((std::ranges::any_of(std::span(inputs).first(input_count),
                           low_precision) ||
       std::ranges::any_of(std::span(outputs).first(step.outputs.size()),
                           low_precision)) &&
      (!features.shader_float16 || !features.storage_buffer16))
    return false;
  if (promote_bfloat) {
    for (std::size_t i = 0; i < input_count; ++i) {
      if (step.operation.get_if<RoPE>() && i == 1 &&
          inputs[i].data_type() == DataType::kInt32)
        continue;
      // Only the immutable MatMul RHS can already own a cold F32 pack.
      // Its native transpose is contiguous; preserve that exact layout.
      if (i == 1 && step.operation.get_if<MatMul>() &&
          inputs[i].data_type() == DataType::kFloat32) {
        const auto transposed = inputs[i].transposed();
        if (program.values[step.inputs[i]].constant && transposed && transposed->is_dense())
          continue;
      }
      if (!inputs[i].is_plain() || !inputs[i].is_dense() ||
          (inputs[i].data_type() != DataType::kFloat32 &&
           !low_precision(inputs[i])))
        return false;
      const auto wide =
          TensorDesc::dense(DataType::kFloat32, inputs[i].dimensions());
      if (!wide)
        return false;
      inputs[i] = *wide;
    }
    const auto wide =
        TensorDesc::dense(DataType::kFloat32, outputs[0].dimensions());
    if (!wide)
      return false;
    outputs[0] = *wide;
  }
  // ggml Vulkan imports canonical external ports. Preserve HYLE's natural
  // transposed-weight API by qualifying the exact contiguous matrix view
  // against the canonical description that lower_managed_region materializes.
  // This does not introduce another MatMul implementation or a runtime route.
  if (step.operation.get_if<MatMul>() && input_count == 2 &&
      transposed_dense_matrix(inputs[0])) {
    const auto canonical =
        TensorDesc::dense(inputs[0].data_type(), inputs[0].dimensions());
    if (!canonical)
      return false;
    // Pack only the unique A storage before its native batch broadcast view.
    inputs[0] = *canonical;
  }
  if (step.operation.get_if<MatMul>() && input_count == 2 &&
      transposed_dense_matrix(inputs[1])) {
    const auto canonical =
        TensorDesc::dense(inputs[1].data_type(), inputs[1].dimensions());
    if (!canonical)
      return false;
    inputs[1] = *canonical;
  }
  if (!provider::region_supports(step.operation,
                                 std::span(inputs).first(input_count),
                                 std::span(outputs).first(step.outputs.size())))
    return false;
  if (step.operation.get_if<MatMul>()) {
    const auto &limits = program.runtime->device->properties.limits;
    const auto columns =
        static_cast<std::uint64_t>(inputs[1].dimensions().back());
    // Output batches can exceed A's physical batches when A is shared.
    // Bound actual native result/split-K workspace, not A's smaller storage.
    const auto rows = static_cast<std::uint64_t>(*outputs[0].element_count() / columns);
    const auto matrix_rows = static_cast<std::uint64_t>(
        inputs[0].dimensions()[inputs[0].rank() - 2]);
    const auto batches = rows / matrix_rows;
    // Original matmul may choose up to eight split-K pieces. Bound both its
    // F32 partial workspace and all grids before native graph allocation.
    // The locked MAT pipelines tile at least 32 columns. Split-K multiplies
    // that tile count, not each scalar column; the final reduction tiles 1024.
    if (rows > limits.maxComputeWorkGroupCount[1] ||
        batches > limits.maxComputeWorkGroupCount[2] ||
        (columns + 31) / 32 > limits.maxComputeWorkGroupCount[0] / 8 ||
        columns > limits.maxComputeWorkGroupCount[0] ||
        rows * columns > limits.maxStorageBufferRange / (8 * sizeof(float)) ||
        (rows * columns + 1023) / 1024 > limits.maxComputeWorkGroupCount[0])
      return false;
  }
  if (step.operation.get_if<GatedDeltaNet>() ||
      step.operation.custom_as<model_ops::RecurrentGatedDeltaNet>()) {
    const auto dimensions = inputs[2].dimensions();
    const auto &limits = program.runtime->device->properties.limits;
    const auto score_elements = *outputs[0].element_count();
    const auto state_elements = *outputs[1].element_count();
    const auto packed_limit = limits.maxStorageBufferRange / sizeof(float);
    if (score_elements > packed_limit ||
        state_elements > packed_limit - score_elements)
      return false;
    if (static_cast<std::uint64_t>(dimensions[2]) >
            limits.maxComputeWorkGroupCount[0] ||
        static_cast<std::uint64_t>(dimensions[0]) >
            limits.maxComputeWorkGroupCount[1] ||
        static_cast<std::uint64_t>(dimensions[3]) >
            limits.maxComputeWorkGroupCount[2] ||
        limits.maxPerStageDescriptorStorageBuffers < 7 ||
        limits.maxDescriptorSetStorageBuffers < 7)
      return false;
    for (const auto &input : std::span(inputs).first(input_count))
      if (*input.element_count() > limits.maxStorageBufferRange / sizeof(float))
        return false;
    const auto snapshots = step.operation.get_if<GatedDeltaNet>()
        ? step.operation.get_if<GatedDeltaNet>()->snapshot_count
        : step.operation.custom_as<model_ops::RecurrentGatedDeltaNet>()->snapshot_count;
    // GET_ROWS uses 512 threads along one complete [H,Dv,Dk] state row.
    // Its row/batch grid dimensions are bounded by the original kernel.
    const auto state_row = *inputs[input_count - 1].element_count() /
                           static_cast<std::uint64_t>(dimensions[0]);
    if (snapshots > 1 &&
        (state_row + 511) / 512 > limits.maxComputeWorkGroupCount[0])
      return false;
  }
  if ((step.operation.get_if<Unary>() || step.operation.get_if<Binary>() ||
       step.operation.get_if<GatedActivation>() ||
       step.operation.custom_as<model_ops::Clamp>()) &&
      !managed_elementwise_limits(program, step))
    return false;
  if ((promote_bfloat || step.operation.get_if<Copy>() ||
       step.operation.get_if<Cast>() || step.operation.get_if<Concat>() ||
       step.operation.get_if<Binary>() || step.operation.get_if<Reduce>() ||
       step.operation.get_if<Softmax>() || step.operation.get_if<Scatter>() ||
       std::ranges::any_of(std::span(inputs).first(input_count),
                           low_precision) ||
       low_precision(outputs[0])) &&
      !layout_limits(program, step))
    return false;
  // Original RMSNorm uses ne1/ne2/ne3 as workgroup counts. Other admitted
  // elementwise kernels split their flattened domain into bounded XYZ tiles.
  if (step.operation.get_if<RmsNorm>()) {
    const auto dimensions = outputs[0].dimensions();
    const auto &limits = program.runtime->device->properties.limits;
    if (dimensions.size() > 4) {
      if (*outputs[0].element_count() / dimensions.back() >
          limits.maxComputeWorkGroupCount[0])
        return false;
    } else {
      for (std::size_t axis = 1; axis < dimensions.size(); ++axis)
        if (static_cast<std::uint64_t>(
                dimensions[dimensions.size() - axis - 1]) >
            limits.maxComputeWorkGroupCount[axis - 1])
          return false;
    }
  }
  if (step.operation.get_if<Gather>()) {
    const auto &limits = program.runtime->device->properties.limits;
    if (limits.maxComputeWorkGroupInvocations < 512 ||
        limits.maxComputeWorkGroupSize[0] < 512 ||
        static_cast<std::uint64_t>(inputs[0].dimensions()[1]) >
            std::uint64_t{limits.maxComputeWorkGroupCount[0]} * 512)
      return false;
  }
  if (const auto *scatter = step.operation.get_if<Scatter>()) {
    const auto &base = inputs[0];
    const auto axis = static_cast<std::size_t>(
        scatter->axis < 0
            ? scatter->axis + static_cast<std::int32_t>(base.rank())
            : scatter->axis);
    const auto extent = static_cast<std::uint64_t>(base.dimensions()[axis]);
    const auto count = *inputs[1].element_count();
    const auto inner_outer = *base.element_count() / extent;
    const auto &limits = program.runtime->device->properties.limits;
    if (extent > INT32_MAX || count > INT32_MAX || inner_outer > INT32_MAX ||
        limits.maxComputeWorkGroupInvocations < 512 ||
        limits.maxComputeWorkGroupSize[0] < 512)
      return false;
  }
  if (step.operation.get_if<Scan>() && !scan_limits(program, inputs[0]))
    return false;
  if (step.operation.get_if<LayerNorm>() &&
      !layer_norm_limits(program, inputs[0]))
    return false;
  if ((step.operation.get_if<Reduce>() || step.operation.get_if<Softmax>()) &&
      !managed_reduction_limits(program, step.operation,
                                program.values[step.inputs[0]].description))
    return false;
  if (const auto *selection = step.operation.get_if<TopK>();
      selection && !topk_limits(program, inputs[0], *selection))
    return false;
  return true;
}
} // namespace

bool managed_operation(const ProgramState &program,
                       const PlanStep &step) noexcept {
  // Empty selections retain both published ports without importing payload
  // or constructing a vendor argsort, including a zero-length input axis.
  if (const auto *selection = step.operation.get_if<TopK>();
      selection && selection->count == 0)
    return false;
  // The row-wise single-selection carrier keeps the original TopK schema,
  // while avoiding this mature region's full argsort and its buffers.
  if (single_topk_operation(program, step)) return false;
  // Dynamic expert IDs need the same checked publication boundary as Gather.
  return !step.operation.custom_as<model_ops::GroupedMatMul>() &&
         region_operation(program, step, false);
}

bool checked_grouped_operation(const ProgramState &program,
                                const PlanStep &step) noexcept {
  return step.operation.custom_as<model_ops::GroupedMatMul>() &&
         region_operation(program, step, false);
}

Status lower_checked_grouped(ProgramState &program,
                              const PlanStep &step) noexcept {
  try {
    if (!checked_grouped_operation(program, step))
      return Status::Unimplemented("ggml Vulkan checked grouped domain");
    while (program.aliases.size() < program.values.size()) {
      const auto id = static_cast<std::uint32_t>(program.aliases.size());
      program.aliases.push_back({id, 0});
    }
    const auto append = [&](const TensorDesc &description) {
      const auto id = static_cast<std::uint32_t>(program.values.size());
      program.values.push_back({description, {}});
      program.aliases.push_back({id, 0});
      return id;
    };
    const auto indices = program.values[step.inputs[2]].description;
    const auto result = program.values[step.outputs[0]].description;
    const auto extent = static_cast<std::uint64_t>(
        program.values[step.inputs[0]].description.dimensions()[0]);
    if (!program.status_value) {
      HYLE_ASSIGN_OR_RETURN(auto status, TensorDesc::dense(DataType::kInt32, {}));
      program.status_value = append(status);
    }
    const auto safe = append(indices);
    const auto intermediate = append(result);
    HYLE_RETURN_IF_ERROR(
        lower_index_check(program, step.inputs[2], safe, extent, true));
    Plan local;
    local.outputs = {intermediate};
    local.steps.push_back({step.operation,
                           {step.inputs[0], step.inputs[1], safe},
                           {intermediate}, {}, {1, 1, 1}, {}});
    const std::vector<std::size_t> last_uses(program.values.size(), 0);
    HYLE_RETURN_IF_ERROR(lower_region(program, local, 0, 1, last_uses));
    return lower_checked_copy(program, intermediate, step.outputs[0]);
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("ggml Vulkan checked grouped metadata");
  }
}

bool quantized_gather_operation(const ProgramState &program,
                                const PlanStep &step) noexcept {
  const auto *gather = step.operation.get_if<Gather>();
  if (!gather || gather->bounds != IndexBoundsPolicy::kChecked ||
      step.inputs.size() != 2 || step.outputs.size() != 1)
    return false;
  const std::array inputs{program.values[step.inputs[0]].description,
                          program.values[step.inputs[1]].description};
  const std::array outputs{program.values[step.outputs[0]].description};
  const Operation unchecked(
      Gather{gather->axis, IndexBoundsPolicy::kUnchecked});
  if (!provider::region_supports(unchecked, inputs, outputs))
    return false;
  const auto &limits = program.runtime->device->properties.limits;
  return limits.maxComputeWorkGroupInvocations >= 512 &&
         limits.maxComputeWorkGroupSize[0] >= 512 &&
         static_cast<std::uint64_t>(inputs[0].dimensions()[1]) <=
             std::uint64_t{limits.maxComputeWorkGroupCount[0]} * 512;
}

bool bfloat_region_operation(const ProgramState &program,
                             const PlanStep &step) noexcept {
  if (step.outputs.size() != 1) return false;
  const auto type = program.values[step.outputs[0]].description.data_type();
  const bool convolution = step.operation.custom_as<model_ops::CausalConv1d>() &&
      (type == DataType::kFloat16 || type == DataType::kBFloat16);
  if ((!convolution && type != DataType::kBFloat16) ||
      !(convolution || step.operation.get_if<Unary>() || step.operation.get_if<Binary>() ||
        step.operation.get_if<GatedActivation>() ||
        step.operation.get_if<RmsNorm>() ||
        step.operation.get_if<LayerNorm>() || step.operation.get_if<Reduce>() ||
        step.operation.get_if<Softmax>() || step.operation.get_if<MatMul>() ||
        step.operation.get_if<RoPE>() || step.operation.get_if<Hadamard>() ||
        step.operation.get_if<ScaledDotProductAttention>()))
    return false;
  const auto wide = TensorDesc::dense(
      DataType::kFloat32,
      program.values[step.outputs[0]].description.dimensions());
  if (!wide || (type == DataType::kBFloat16 &&
                !iree_precision_supported(*program.runtime->device, *wide)))
    return false;
  return region_operation(program, step, true);
}

Status lower_bfloat_region(ProgramState &program,
                           const PlanStep &step) noexcept {
  try {
    const auto append =
        [&](const TensorDesc &description) -> Result<std::uint32_t> {
      HYLE_ASSIGN_OR_RETURN(
          auto wide,
          TensorDesc::dense(DataType::kFloat32, description.dimensions()));
      const auto id = static_cast<std::uint32_t>(program.values.size());
      program.values.push_back({wide, {}});
      program.aliases.push_back({id, 0});
      return id;
    };
    Plan local;
    PlanStep wide = step;
    for (auto &input : wide.inputs) {
      const auto type = program.values[input].description.data_type();
      if (type == DataType::kFloat32 || type == DataType::kInt32)
        continue;
      HYLE_ASSIGN_OR_RETURN(auto converted,
                            append(program.values[input].description));
      local.steps.push_back({Operation(Cast{DataType::kFloat32}),
                             {input},
                             {converted},
                             {},
                             {1, 1, 1},
                             {}});
      input = converted;
    }
    HYLE_ASSIGN_OR_RETURN(auto result,
                          append(program.values[step.outputs[0]].description));
    wide.outputs = {result};
    local.steps.push_back(std::move(wide));
    local.outputs = {result};
    const std::vector<std::size_t> last_uses(program.values.size(), 0);
    HYLE_RETURN_IF_ERROR(
        lower_region(program, local, 0, local.steps.size(), last_uses));
    // The public F16/BF16 port is the source rounding boundary, using the
    // already qualified original conversion on this same native device.
    return lower_native_cast(program, result, step.outputs[0]);
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("Vulkan BF16 region metadata");
  }
}

bool mature_scatter_add_operation(const ProgramState &program,
                                  const PlanStep &step) noexcept {
  const auto *scatter = step.operation.get_if<Scatter>();
  if (step.custom || !scatter || scatter->kind != ScatterKind::kAdd ||
      step.inputs.size() != 3 || step.outputs.size() != 1)
    return false;
  const auto &base = program.values[step.inputs[0]].description;
  const auto &indices = program.values[step.inputs[1]].description;
  const auto &updates = program.values[step.inputs[2]].description;
  const auto &output = program.values[step.outputs[0]].description;
  if (!base.is_plain() || !base.is_dense() || !indices.is_plain() ||
      !indices.is_dense() || !updates.is_plain() || !updates.is_dense() ||
      !output.is_plain() || !output.is_dense() ||
      indices.data_type() != DataType::kInt32 ||
      (base.data_type() != DataType::kFloat32 &&
       base.data_type() != DataType::kFloat16 &&
       base.data_type() != DataType::kBFloat16) ||
      updates.data_type() != base.data_type() ||
      output.data_type() != base.data_type() || !base.element_count() ||
      *base.element_count() == 0 || !indices.element_count() ||
      !updates.element_count() || !output.element_count() ||
      *output.element_count() == 0)
    return false;
  const auto axis = static_cast<std::size_t>(
      scatter->axis < 0 ? scatter->axis + static_cast<std::int32_t>(base.rank())
                        : scatter->axis);
  const auto extent = static_cast<std::uint64_t>(base.dimensions()[axis]);
  const auto count = *indices.element_count();
  const auto inner_outer = *base.element_count() / extent;
  const auto &device = *program.runtime->device;
  const auto &limits = device.properties.limits;
  const auto maximum = (std::min)(
      std::uint64_t{INT32_MAX},
      static_cast<std::uint64_t>(limits.maxStorageBufferRange) / sizeof(float));
  if (extent > INT32_MAX || count > INT32_MAX || inner_outer > INT32_MAX ||
      *base.element_count() > maximum || *updates.element_count() > maximum ||
      *output.element_count() > maximum || count > maximum ||
      limits.maxComputeWorkGroupInvocations < 512 ||
      limits.maxComputeWorkGroupSize[0] < 512 || !layout_limits(program, step))
    return false;
  const auto &features = device.provider.native();
  if (base.data_type() != DataType::kFloat32 &&
      (!features.shader_float16 || !features.storage_buffer16))
    return false;
  if (base.data_type() == DataType::kBFloat16 && count != 0) {
    const auto wide =
        TensorDesc::dense(DataType::kFloat32, output.dimensions());
    return wide && iree_precision_supported(device, *wide);
  }
  return true;
}

Status lower_mature_scatter_add(ProgramState &program,
                                const PlanStep &step) noexcept {
  try {
    if (!mature_scatter_add_operation(program, step))
      return Status::Unimplemented("ggml Vulkan Scatter add domain");
    while (program.aliases.size() < program.values.size()) {
      const auto id = static_cast<std::uint32_t>(program.aliases.size());
      program.aliases.push_back({id, 0});
    }
    const auto append = [&](const TensorDesc &description) {
      const auto id = static_cast<std::uint32_t>(program.values.size());
      program.values.push_back({description, {}});
      program.aliases.push_back({id, 0});
      return id;
    };
    const auto indices = program.values[step.inputs[1]].description;
    if (*indices.element_count() == 0) {
      Plan copy;
      copy.outputs = step.outputs;
      copy.steps.push_back({Operation(Copy{}),
                            {step.inputs[0]},
                            step.outputs,
                            {},
                            {1, 1, 1},
                            {}});
      const std::vector<std::size_t> last_uses(program.values.size(), 0);
      return lower_region(program, copy, 0, 1, last_uses);
    }
    const auto scatter = *step.operation.get_if<Scatter>();
    const auto base = program.values[step.inputs[0]].description;
    const auto update_description = program.values[step.inputs[2]].description;
    const auto output_description = program.values[step.outputs[0]].description;
    const auto axis = static_cast<std::size_t>(
        scatter.axis < 0 ? scatter.axis + static_cast<std::int32_t>(base.rank())
                         : scatter.axis);
    const auto extent = static_cast<std::uint64_t>(base.dimensions()[axis]);
    const bool checked = scatter.bounds == IndexBoundsPolicy::kChecked;
    if (checked && !program.status_value) {
      HYLE_ASSIGN_OR_RETURN(auto status,
                            TensorDesc::dense(DataType::kInt32, {}));
      program.status_value = append(status);
    }
    HYLE_ASSIGN_OR_RETURN(
        auto safe_description,
        TensorDesc::dense(DataType::kInt32, indices.dimensions()));
    const auto safe = append(safe_description);
    HYLE_RETURN_IF_ERROR(
        lower_index_check(program, step.inputs[1], safe, extent, checked));

    Plan local;
    auto base_value = step.inputs[0];
    auto update_value = step.inputs[2];
    const bool bfloat = base.data_type() == DataType::kBFloat16;
    if (bfloat) {
      HYLE_ASSIGN_OR_RETURN(
          auto wide_base,
          TensorDesc::dense(DataType::kFloat32, base.dimensions()));
      HYLE_ASSIGN_OR_RETURN(auto wide_updates,
                            TensorDesc::dense(DataType::kFloat32,
                                              update_description.dimensions()));
      base_value = append(wide_base);
      update_value = append(wide_updates);
      local.steps.push_back({Operation(Cast{DataType::kFloat32}),
                             {step.inputs[0]},
                             {base_value},
                             {},
                             {1, 1, 1},
                             {}});
      local.steps.push_back({Operation(Cast{DataType::kFloat32}),
                             {step.inputs[2]},
                             {update_value},
                             {},
                             {1, 1, 1},
                             {}});
    }
    TensorDesc provider_output = output_description;
    if (bfloat) {
      HYLE_ASSIGN_OR_RETURN(
          provider_output,
          TensorDesc::dense(DataType::kFloat32, provider_output.dimensions()));
    }
    const auto provider_result =
        (!bfloat && !checked) ? step.outputs[0] : append(provider_output);
    local.steps.push_back({Operation(Scatter{scatter.axis, ScatterKind::kAdd,
                                             IndexBoundsPolicy::kUnchecked}),
                           {base_value, safe, update_value},
                           {provider_result},
                           {},
                           {1, 1, 1},
                           {}});
    local.outputs = {provider_result};
    const std::vector<std::size_t> last_uses(program.values.size(), 0);
    HYLE_RETURN_IF_ERROR(
        lower_region(program, local, 0, local.steps.size(), last_uses));
    auto published = provider_result;
    if (bfloat) {
      if (checked)
        published = append(output_description);
      else
        published = step.outputs[0];
      HYLE_RETURN_IF_ERROR(
          lower_iree(program, {Operation(Cast{DataType::kBFloat16}),
                               {provider_result},
                               {published},
                               {},
                               {1, 1, 1},
                               {}}));
    }
    return checked ? lower_checked_copy(program, published, step.outputs[0])
                   : Status::Ok();
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("ggml Vulkan Scatter add metadata");
  }
}

Status lower_region(ProgramState &program, const Plan &plan, std::size_t first,
                    std::size_t end,
                    std::span<const std::size_t> last_uses) noexcept {
  try {
    std::vector<std::uint32_t> ids;
    const auto has_payload = [&](const PlanStep &step, std::uint32_t input) {
      return !step.operation.get_if<Concat>() ||
             *program.values[input].description.element_count() != 0;
    };
    for (auto i = first; i < end; ++i) {
      for (const auto input : plan.steps[i].inputs)
        if (has_payload(plan.steps[i], input))
          ids.push_back(input);
      ids.insert(ids.end(), plan.steps[i].outputs.begin(),
                 plan.steps[i].outputs.end());
    }
    std::ranges::sort(ids);
    const auto duplicate = std::ranges::unique(ids);
    ids.erase(duplicate.begin(), duplicate.end());
    const auto local = [&](std::uint32_t value) {
      return static_cast<std::uint32_t>(std::ranges::lower_bound(ids, value) -
                                        ids.begin());
    };
    auto recipe = std::make_shared<provider::RegionRecipe>();
    for (const auto id : ids)
      recipe->values.push_back(program.values[id].description);
    struct ValueUses final {
      bool produced = false;
      bool descriptor_aligned = false;
      bool resident_attention = false;
      bool other_reader = false;
      bool grouped_activation = false;
      bool other_grouped_reader = false;
    };
    std::vector<ValueUses> uses(ids.size());
    for (auto i = first; i < end; ++i) {
      const auto &step = plan.steps[i];
      provider::RegionNode node{step.operation, {}, {}};
      for (const auto input : step.inputs)
        if (has_payload(step, input))
          node.inputs.push_back(local(input));
      const auto *attention = step.operation.get_if<ScaledDotProductAttention>();
      const auto depth =
          attention
              ? program.values[step.inputs[0]].description.dimensions().back()
              : 0;
      const bool resident =
          attention &&
          attention->layout == AttentionLayout::kBatchSequenceHeadDepth &&
          (depth == 64 || depth == 128 || depth == 256) &&
          program.values[step.inputs[1]].description.dimensions().back() == depth &&
          program.values[step.inputs[2]].description.dimensions().back() == depth;
      for (const auto input : node.inputs) {
        uses[input].resident_attention |= resident;
        uses[input].other_reader |= !resident;
      }
      const bool grouped =
          step.operation.custom_as<model_ops::GroupedMatMul>().has_value() &&
          region_operation(program, step, false);
      for (std::size_t port = 0; port < node.inputs.size(); ++port) {
        const bool activation = grouped && port == 1;
        uses[node.inputs[port]].grouped_activation |= activation;
        uses[node.inputs[port]].other_grouped_reader |= !activation;
      }
      // Argsort, indexed rows, GroupNorm, Softmax and multi-pass Scan need
      // aligned descriptors. Other admitted operations retain their
      // offset-aware input contract.
      if (step.operation.get_if<TopK>() || step.operation.get_if<Scan>() ||
          step.operation.get_if<LayerNorm>())
        uses[local(step.inputs[0])].descriptor_aligned = true;
      if (step.operation.get_if<Softmax>())
        for (const auto input : step.inputs)
          uses[local(input)].descriptor_aligned = true;
      if (step.operation.get_if<GatedDeltaNet>() ||
          step.operation.custom_as<model_ops::RecurrentGatedDeltaNet>())
        for (const auto input : step.inputs)
          uses[local(input)].descriptor_aligned = true;
      if (step.operation.get_if<MatMul>())
        for (const auto input : step.inputs)
          uses[local(input)].descriptor_aligned = true;
      if (step.operation.get_if<Scatter>())
        for (const auto input : step.inputs)
          uses[local(input)].descriptor_aligned = true;
      for (const auto output : step.outputs) {
        node.outputs.push_back(local(output));
        uses[local(output)].produced = true;
        if (last_uses[output] >= end ||
            std::ranges::find(plan.outputs, output) != plan.outputs.end())
          recipe->outputs.push_back(local(output));
      }
      recipe->nodes.push_back(std::move(node));
    }
    for (std::uint32_t i = 0; i < ids.size(); ++i)
      if (!uses[i].produced)
        recipe->inputs.push_back(i);
    // A dead-only region can occur only in a manually supplied private Plan;
    // still keep a concrete output so the original allocator can own its work.
    if (recipe->outputs.empty())
      recipe->outputs.push_back(local(plan.steps[end - 1].outputs[0]));
    Dispatch dispatch;
    while (program.aliases.size() < program.values.size()) {
      const auto value = static_cast<std::uint32_t>(program.aliases.size());
      program.aliases.push_back({value, 0});
    }
    for (const auto input : recipe->inputs) {
      const auto value = ids[input];
      const auto alias = program.aliases[value];
      const auto &constant = program.values[alias.root].constant;
      if (!program.values[value].description.is_plain()) {
        // Preserve compressed bytes. Borrowed compressed ports require native
        // descriptor alignment, checked before binding; no scalar Copy can
        // interpret a block encoding as its logical F16 elements.
        dispatch.values.push_back(value);
        continue;
      }
      const auto &description = program.values[value].description;
      if (uses[input].grouped_activation && !uses[input].other_grouped_reader &&
          !description.is_dense()) {
        // The qualified Grouped port retains its real token pitch and slot0
        // layout. The native Provider validates descriptor-origin alignment
        // on every bind; canonicalizing here would copy S activation rows.
        // Dense ports keep their existing offset-aware alignment adapter.
        dispatch.values.push_back(value);
        continue;
      }
      bool resident =
          uses[input].resident_attention && !uses[input].other_reader &&
          description.rank() == 4 &&
          (description.data_type() == DataType::kFloat32 ||
           description.data_type() == DataType::kFloat16) &&
          description.byte_strides()[3] == static_cast<std::int64_t>(
              data_type_size(description.data_type()));
      for (std::size_t axis = 0; resident && axis < 3; ++axis)
        resident = description.dimensions()[axis] <= 1 ||
                   description.byte_strides()[axis] % 16 == 0;
      if (resident) {
        // The Provider validates the actual bound origin before admission.
        // Keep native nb and the resident owner; no warm canonical KV copy.
        dispatch.values.push_back(value);
        continue;
      }
      // ggml external ports describe canonical dense storage.  HYLE also
      // treats a permuted contiguous tensor as dense, so materialize only that
      // exact residual layout before entering the mature region.  The MatMul
      // itself remains owned by ggml; this is the ordinary byte-addressed
      // boundary adapter already used for other non-native layouts.
      HYLE_ASSIGN_OR_RETURN(
          auto canonical,
          TensorDesc::dense(program.values[value].description.data_type(),
                            program.values[value].description.dimensions()));
      // A captured RHS or an internally produced, unescaped RHS can already
      // own the exact transposed matrix/batch payload. Preserve that layout
      // only when every reader here is MatMul's RHS. External mutable ports
      // and published views keep the original canonical boundary adapter.
      bool packed_matrix = program.values[value].constant.valid();
      if (!packed_matrix &&
          std::ranges::find(program.inputs, alias.root) == program.inputs.end() &&
          std::ranges::find(plan.outputs, value) == plan.outputs.end() &&
          std::ranges::find(plan.outputs, alias.root) == plan.outputs.end())
        packed_matrix = true;
      const auto transposed = description.transposed();
      packed_matrix &= transposed && transposed->is_dense();
      for (auto i = first; packed_matrix && i < end; ++i)
        for (std::size_t port = 0; port < plan.steps[i].inputs.size(); ++port)
          if (plan.steps[i].inputs[port] == value &&
              (!plan.steps[i].operation.get_if<MatMul>() || port != 1))
            packed_matrix = false;
      if (canonical != description && !packed_matrix) {
        const auto adapted =
            static_cast<std::uint32_t>(program.values.size());
        program.values.push_back({canonical, {}});
        program.aliases.push_back({adapted, 0});
        HYLE_RETURN_IF_ERROR(lower_tensor(
            program,
            {Operation(Copy{}), {value}, {adapted}, {}, {1, 1, 1}, {}}));
        recipe->values[input] = canonical;
        dispatch.values.push_back(adapted);
        continue;
      }
      const auto alignment =
          uses[input].descriptor_aligned
              ? (std::max)(VkDeviceSize{sizeof(float)},
                           program.runtime->device->properties.limits
                               .minStorageBufferOffsetAlignment)
              : sizeof(float);
      // Private layout aliases retain the root's storage, not a separate
      // constant Tensor. Include both origins, without overflowing their sum.
      const auto origin_remainder =
          (constant ? constant.native_offset() % alignment : 0) +
          alias.byte_offset % alignment;
      const bool aligned = std::ranges::find(program.inputs, alias.root) ==
                               program.inputs.end() &&
                           origin_remainder % alignment == 0;
      if (aligned) {
        dispatch.values.push_back(value);
        continue;
      }
      // A dense description says nothing about a bound View's byte origin.
      // Freeze a storage adapter now, using the existing byte-addressed Copy;
      // binding never changes Provider or rebuilds the native region graph.
      const auto adapted = static_cast<std::uint32_t>(program.values.size());
      program.values.push_back({program.values[value].description, {}});
      program.aliases.push_back({adapted, 0});
      HYLE_RETURN_IF_ERROR(lower_tensor(
          program, {Operation(Copy{}), {value}, {adapted}, {}, {1, 1, 1}, {}}));
      dispatch.values.push_back(adapted);
    }
    for (const auto output : recipe->outputs)
      dispatch.values.push_back(ids[output]);
    dispatch.region = std::move(recipe);
    program.dispatches.push_back(std::move(dispatch));
    return Status::Ok();
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("Vulkan region boundary plan");
  }
}

Status lower_gather_elements(ProgramState &program, const PlanStep &step) noexcept {
  try {
    const auto gather=step.operation.custom_as<model_ops::GatherElements>();
    if(!gather || step.inputs.size()!=2 || step.outputs.size()!=1)
      return Status::InvalidArgument("Vulkan GatherElements ports are invalid");
    const auto input=program.values[step.inputs[0]].description;
    const auto indices=program.values[step.inputs[1]].description;
    const auto output=program.values[step.outputs[0]].description;
    if(input.rank()!=2 || (gather->axis!=-1 && gather->axis!=1))
      return Status::Unimplemented("Vulkan GatherElements requires rank-two last-axis data");
    const auto count=*indices.element_count();
    if(!count)return Status::Ok();
    const auto& limits=program.runtime->device->properties.limits;
    // GET_ROWS and a possible narrow-float conversion use four-byte carriers.
    if(count>INT32_MAX || count>limits.maxStorageBufferRange/4 ||
       *input.element_count()>limits.maxStorageBufferRange/4 ||
       limits.maxComputeWorkGroupInvocations<512 || limits.maxComputeWorkGroupSize[0]<512)
      return Status::Unimplemented("Vulkan GatherElements exceeds native buffer or workgroup limits");
    while(program.aliases.size()<program.values.size()) {
      const auto id=static_cast<std::uint32_t>(program.aliases.size());
      program.aliases.push_back({id,0});
    }
    const auto append=[&](TensorDesc description){
      const auto id=static_cast<std::uint32_t>(program.values.size());
      program.values.push_back({description,{}});program.aliases.push_back({id,0});return id;
    };
    const bool checked=gather->bounds==IndexBoundsPolicy::kChecked;
    if(checked && !program.status_value){
      HYLE_ASSIGN_OR_RETURN(auto status,TensorDesc::dense(DataType::kInt32,{}));
      program.status_value=append(status);
    }
    const auto safe=append(indices);
    HYLE_RETURN_IF_ERROR(lower_index_check(program,step.inputs[1],safe,
        static_cast<std::uint64_t>(input.dimensions()[1]),checked));
    const auto selected=append(output);
    Plan local;local.outputs={selected};
    local.steps.push_back({model_ops::gather_elements(gather->axis,IndexBoundsPolicy::kUnchecked),
                          {step.inputs[0],safe},{selected},{},{1,1,1},{}});
    const std::vector<std::size_t> uses(program.values.size(),0);
    HYLE_RETURN_IF_ERROR(lower_region(program,local,0,1,uses));
    return checked ? lower_checked_copy(program,selected,step.outputs[0])
                   : lower_tensor(program,{Operation(Copy{}),{selected},step.outputs,{},{1,1,1},{}});
  } catch(const std::bad_alloc&) {
    return Status::ResourceExhausted("Vulkan GatherElements lowering metadata");
  }
}

Status lower_gather(ProgramState &program, const PlanStep &step) noexcept {
  try {
    const auto input = program.values[step.inputs[0]].description;
    const auto indices = program.values[step.inputs[1]].description;
    const auto output = program.values[step.outputs[0]].description;
    const auto gather = *step.operation.get_if<Gather>();
    const auto count = *indices.element_count();
    if (count == 0)
      return Status::Ok();
    const auto &limits = program.runtime->device->properties.limits;
    if (count > limits.maxStorageBufferRange / 4)
      return Status::Unimplemented("Vulkan Gather indices exceed device range");
    const auto axis = static_cast<std::size_t>(
        gather.axis < 0 ? gather.axis + static_cast<std::int32_t>(input.rank())
                        : gather.axis);
    const auto extent = static_cast<std::uint64_t>(input.dimensions()[axis]);
    const bool checked = gather.bounds == IndexBoundsPolicy::kChecked;
    while (program.aliases.size() < program.values.size()) {
      const auto id = static_cast<std::uint32_t>(program.aliases.size());
      program.aliases.push_back({id, 0});
    }
    const auto append = [&](const TensorDesc &description) {
      const auto id = static_cast<std::uint32_t>(program.values.size());
      program.values.push_back({description, {}});
      program.aliases.push_back({id, 0});
      return id;
    };
    const auto alias = [&](const TensorDesc &description,
                           std::uint32_t source) {
      const auto owner = program.aliases[source];
      const auto id = append(description);
      program.aliases[id] = owner;
      return id;
    };
    if (checked && !program.status_value) {
      HYLE_ASSIGN_OR_RETURN(auto status,
                            TensorDesc::dense(DataType::kInt32, {}));
      program.status_value = append(status);
    }
    HYLE_ASSIGN_OR_RETURN(
        auto safe_desc,
        TensorDesc::dense(DataType::kInt32, indices.dimensions()));
    const auto safe = append(safe_desc);
    HYLE_RETURN_IF_ERROR(
        lower_index_check(program, step.inputs[1], safe, extent, checked));
    // Nonempty indices still require validation when another dimension is
    // empty. Never hand an empty source axis to the unchecked vendor kernel.
    if (*input.element_count() == 0 || *output.element_count() == 0)
      return Status::Ok();
    if (quantized_gather_operation(program, step)) {
      const auto provider_output = append(output);
      Plan local;
      local.outputs = {provider_output};
      local.steps.push_back(
          {Operation(Gather{gather.axis, IndexBoundsPolicy::kUnchecked}),
           {step.inputs[0], safe},
           {provider_output},
           {},
           {1, 1, 1},
           {}});
      const std::vector<std::size_t> last_uses(program.values.size(), 0);
      HYLE_RETURN_IF_ERROR(lower_region(program, local, 0, 1, last_uses));
      return lower_checked_copy(program, provider_output, step.outputs[0]);
    }
    if (limits.maxComputeWorkGroupInvocations < 512 ||
        limits.maxComputeWorkGroupSize[0] < 512)
      return Status::Unimplemented("ggml Vulkan GetRows requires 512 lanes");
    const auto size = data_type_size(input.data_type());
    const auto row_elements = *input.element_count() / extent;
    const auto row_bytes = row_elements * size;
    const auto padded_bytes = (row_bytes + 3) / 4 * 4;
    if (extent > limits.maxStorageBufferRange / padded_bytes ||
        count > limits.maxStorageBufferRange / padded_bytes ||
        padded_bytes / 4 >
            std::uint64_t{limits.maxComputeWorkGroupCount[0]} * 512 ||
        extent * (padded_bytes / size) > INT32_MAX ||
        count * (padded_bytes / size) > INT32_MAX)
      return Status::Unimplemented(
          "Vulkan Gather row adapter exceeds buffer or dispatch range");
    std::array<std::int32_t, kMaxTensorRank> axes{};
    axes[0] = static_cast<std::int32_t>(axis);
    std::size_t next = 1;
    for (std::size_t dim = 0; dim < input.rank(); ++dim)
      if (dim != axis)
        axes[next++] = static_cast<std::int32_t>(dim);
    HYLE_ASSIGN_OR_RETURN(auto permute,
                          View::permute(std::span(axes).first(input.rank())));
    HYLE_ASSIGN_OR_RETURN(auto rows, infer_single_output(Operation(permute),
                                                         std::span(&input, 1)));
    auto source = alias(rows, step.inputs[0]);
    if (!rows.is_dense()) {
      HYLE_ASSIGN_OR_RETURN(
          auto dense, TensorDesc::dense(input.data_type(), rows.dimensions()));
      const auto packed = append(dense);
      HYLE_RETURN_IF_ERROR(lower_tensor(
          program, {Operation(Copy{}), {source}, {packed}, {}, {1, 1, 1}, {}}));
      source = packed;
    }
    HYLE_ASSIGN_OR_RETURN(
        auto matrix,
        TensorDesc::dense(input.data_type(),
                          std::array<std::int64_t, 2>{
                              static_cast<std::int64_t>(extent),
                              static_cast<std::int64_t>(row_elements)}));
    source = alias(matrix, source);
    const auto padding = (padded_bytes - row_bytes) / size;
    if (padding != 0) {
      HYLE_ASSIGN_OR_RETURN(
          auto tail_desc,
          TensorDesc::dense(
              input.data_type(),
              std::array<std::int64_t, 2>{static_cast<std::int64_t>(extent),
                                          static_cast<std::int64_t>(padding)}));
      const auto tail = append(tail_desc);
      HYLE_ASSIGN_OR_RETURN(auto tail_shape,
                            TensorShape::create(tail_desc.dimensions()));
      HYLE_RETURN_IF_ERROR(lower_tensor(
          program, {Operation(Fill{
                        .output_shape = tail_shape,
                        .output_type = input.data_type(),
                        .value = ScalarValue::from_bits(input.data_type(), 0)}),
                    {},
                    {tail},
                    {},
                    {1, 1, 1},
                    {}}));
      HYLE_ASSIGN_OR_RETURN(
          auto padded_desc,
          TensorDesc::dense(
              input.data_type(),
              std::array<std::int64_t, 2>{
                  static_cast<std::int64_t>(extent),
                  static_cast<std::int64_t>(row_elements + padding)}));
      const auto padded = append(padded_desc);
      HYLE_RETURN_IF_ERROR(lower_tensor(program, {Operation(Concat{-1}),
                                                  {source, tail},
                                                  {padded},
                                                  {},
                                                  {1, 1, 1},
                                                  {}}));
      source = padded;
    }
    HYLE_ASSIGN_OR_RETURN(
        auto raw_desc,
        TensorDesc::dense(DataType::kInt32,
                          std::array<std::int64_t, 2>{
                              static_cast<std::int64_t>(extent),
                              static_cast<std::int64_t>(padded_bytes / 4)}));
    const auto raw = alias(raw_desc, source);
    HYLE_ASSIGN_OR_RETURN(
        auto flat_indices,
        TensorDesc::dense(
            DataType::kInt32,
            std::array<std::int64_t, 1>{static_cast<std::int64_t>(count)}));
    const auto index_rows = alias(flat_indices, safe);
    HYLE_ASSIGN_OR_RETURN(
        auto gathered_desc,
        TensorDesc::dense(DataType::kInt32,
                          std::array<std::int64_t, 2>{
                              static_cast<std::int64_t>(count),
                              static_cast<std::int64_t>(padded_bytes / 4)}));
    const auto gathered = append(gathered_desc);
    Plan local;
    local.outputs = {gathered};
    local.steps.push_back({Operation(Gather{0, IndexBoundsPolicy::kUnchecked}),
                           {raw, index_rows},
                           {gathered},
                           {},
                           {1, 1, 1},
                           {}});
    std::vector<std::size_t> last_uses(program.values.size(), 0);
    HYLE_RETURN_IF_ERROR(lower_region(program, local, 0, 1, last_uses));
    // The provider publishes indices-first rows. Reinterpret exact scalar
    // bits, discard only row padding, and restore prefix/indices/suffix axes.
    std::array<std::int64_t, kMaxTensorRank> shape{}, strides{};
    next = indices.rank();
    std::ranges::copy(indices.dimensions(), shape.begin());
    for (std::size_t dim = 0; dim < input.rank(); ++dim)
      if (dim != axis)
        shape[next++] = input.dimensions()[dim];
    auto stride = static_cast<std::int64_t>(size);
    for (auto dim = next; dim > indices.rank(); --dim) {
      strides[dim - 1] = stride;
      stride *= shape[dim - 1];
    }
    stride = static_cast<std::int64_t>(padded_bytes);
    for (auto dim = indices.rank(); dim > 0; --dim) {
      strides[dim - 1] = stride;
      stride *= shape[dim - 1];
    }
    HYLE_ASSIGN_OR_RETURN(auto expanded,
                          TensorDesc::strided_bytes(
                              input.data_type(), std::span(shape).first(next),
                              std::span(strides).first(next)));
    std::size_t position = 0;
    for (std::size_t dim = 0; dim < axis; ++dim)
      axes[position++] = static_cast<std::int32_t>(indices.rank() + dim);
    for (std::size_t dim = 0; dim < indices.rank(); ++dim)
      axes[position++] = static_cast<std::int32_t>(dim);
    for (auto dim = indices.rank() + axis; dim < next; ++dim)
      axes[position++] = static_cast<std::int32_t>(dim);
    HYLE_ASSIGN_OR_RETURN(auto restore,
                          View::permute(std::span(axes).first(next)));
    HYLE_ASSIGN_OR_RETURN(
        auto reordered,
        infer_single_output(Operation(restore), std::span(&expanded, 1)));
    const auto result = alias(reordered, gathered);
    if (checked)
      return lower_checked_copy(program, result, step.outputs[0]);
    return lower_tensor(
        program,
        {Operation(Copy{}), {result}, {step.outputs[0]}, {}, {1, 1, 1}, {}});
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("Vulkan Gather adapter metadata");
  }
}

Status lower_scan(ProgramState &program, const PlanStep &step) noexcept {
  try {
    const auto input = program.values[step.inputs[0]].description;
    const bool integer = input.data_type() == DataType::kInt32;
    if (!integer && input.data_type() != DataType::kFloat32)
      return Status::Unimplemented("Vulkan Scan requires I32 or F32");
    if (*input.element_count() == 0)
      return Status::Ok();
    const auto scan = *step.operation.get_if<Scan>();
    const auto rank = input.rank();
    const auto axis = static_cast<std::size_t>(
        scan.axis < 0 ? scan.axis + static_cast<std::int32_t>(rank)
                      : scan.axis);
    const auto width = input.dimensions()[axis];
    const auto rows = static_cast<std::int64_t>(*input.element_count()) / width;
    HYLE_ASSIGN_OR_RETURN(
        auto matrix,
        TensorDesc::dense(input.data_type(),
                          std::array<std::int64_t, 2>{rows, width}));
    if (!integer && !scan_limits(program, matrix))
      return Status::Unimplemented(
          "Vulkan Scan exceeds native buffer or grid limits");
    if (scan.exclusive && width == 1) {
      HYLE_ASSIGN_OR_RETURN(auto shape,
                            TensorShape::create(input.dimensions()));
      return lower_tensor(
          program, {Operation(Fill{
                        .output_shape = shape,
                        .output_type = input.data_type(),
                        .value = ScalarValue::from_bits(input.data_type(), 0)}),
                    {},
                    step.outputs,
                    {},
                    {1, 1, 1},
                    {}});
    }
    if (integer && width == 1)
      return lower_tensor(
          program,
          {Operation(Copy{}), step.inputs, step.outputs, {}, {1, 1, 1}, {}});
    while (program.aliases.size() < program.values.size()) {
      const auto id = static_cast<std::uint32_t>(program.aliases.size());
      program.aliases.push_back({id, 0});
    }
    const auto append = [&](const TensorDesc &description) {
      const auto id = static_cast<std::uint32_t>(program.values.size());
      program.values.push_back({description, {}});
      program.aliases.push_back({id, 0});
      return id;
    };
    const auto alias = [&](const TensorDesc &description,
                           std::uint32_t source) {
      const auto owner = program.aliases[source];
      const auto id = append(description);
      program.aliases[id] = owner;
      return id;
    };
    std::array<std::int32_t, kMaxTensorRank> axes{}, inverse{};
    std::size_t next = 0;
    for (std::size_t i = 0; i < rank; ++i)
      if (i != axis)
        axes[next++] = static_cast<std::int32_t>(i);
    axes[next] = static_cast<std::int32_t>(axis);
    for (std::size_t i = 0; i < rank; ++i)
      inverse[axes[i]] = static_cast<std::int32_t>(i);
    HYLE_ASSIGN_OR_RETURN(auto permute,
                          View::permute(std::span(axes).first(rank)));
    HYLE_ASSIGN_OR_RETURN(
        auto permuted,
        infer_single_output(Operation(permute), std::span(&input, 1)));
    auto source = alias(permuted, step.inputs[0]);
    if (!permuted.is_dense()) {
      HYLE_ASSIGN_OR_RETURN(
          auto dense,
          TensorDesc::dense(input.data_type(), permuted.dimensions()));
      const auto packed = append(dense);
      HYLE_RETURN_IF_ERROR(lower_tensor(
          program, {Operation(Copy{}), {source}, {packed}, {}, {1, 1, 1}, {}}));
      source = packed;
    }
    source = alias(matrix, source);
    const bool final_layout = axis + 1 == rank;
    auto result = !integer && !scan.exclusive && final_layout
                      ? alias(matrix, step.outputs[0])
                      : append(matrix);
    if (integer) {
      HYLE_RETURN_IF_ERROR(
          lower_integer_scan(program, source, result, scan.exclusive));
    } else {
      Plan local;
      local.outputs = {result};
      local.steps.push_back(
          {Operation(Scan{}), {source}, {result}, {}, {1, 1, 1}, {}});
      std::vector<std::size_t> last_uses(program.values.size(), 0);
      HYLE_RETURN_IF_ERROR(lower_region(program, local, 0, 1, last_uses));
    }
    if (!integer && scan.exclusive) {
      HYLE_ASSIGN_OR_RETURN(auto prefix,
                            TensorDesc::strided_bytes(
                                DataType::kFloat32,
                                std::array<std::int64_t, 2>{rows, width - 1},
                                std::array<std::int64_t, 2>{width * 4, 4}));
      const auto prefix_value = alias(prefix, result);
      HYLE_ASSIGN_OR_RETURN(
          auto zero_desc,
          TensorDesc::dense(DataType::kFloat32,
                            std::array<std::int64_t, 2>{rows, 1}));
      const auto zero = append(zero_desc);
      HYLE_ASSIGN_OR_RETURN(auto shape,
                            TensorShape::create(zero_desc.dimensions()));
      HYLE_RETURN_IF_ERROR(lower_tensor(
          program, {Operation(Fill{.output_shape = shape,
                                   .output_type = DataType::kFloat32,
                                   .value = ScalarValue(0.0F)}),
                    {},
                    {zero},
                    {},
                    {1, 1, 1},
                    {}}));
      result = final_layout ? alias(matrix, step.outputs[0]) : append(matrix);
      HYLE_RETURN_IF_ERROR(lower_tensor(program, {Operation(Concat{-1}),
                                                  {zero, prefix_value},
                                                  {result},
                                                  {},
                                                  {1, 1, 1},
                                                  {}}));
    }
    if (!final_layout) {
      HYLE_ASSIGN_OR_RETURN(
          auto expanded,
          TensorDesc::dense(input.data_type(), permuted.dimensions()));
      HYLE_ASSIGN_OR_RETURN(auto restore,
                            View::permute(std::span(inverse).first(rank)));
      HYLE_ASSIGN_OR_RETURN(
          auto reordered,
          infer_single_output(Operation(restore), std::span(&expanded, 1)));
      result = alias(reordered, result);
      if (!integer)
        HYLE_RETURN_IF_ERROR(lower_tensor(
            program,
            {Operation(Copy{}), {result}, step.outputs, {}, {1, 1, 1}, {}}));
    }
    if (integer) {
      if (final_layout) {
        HYLE_ASSIGN_OR_RETURN(
            auto expanded,
            TensorDesc::dense(input.data_type(), input.dimensions()));
        result = alias(expanded, result);
      }
      // Restore and publish only after every global prefix has been checked.
      return lower_checked_copy(program, result, step.outputs[0]);
    }
    return Status::Ok();
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("Vulkan Scan layout metadata");
  }
}

Status lower_topk(ProgramState &program, const PlanStep &step) noexcept {
  try {
    const auto input = program.values[step.inputs[0]].description;
    auto selection = *step.operation.get_if<TopK>();
    // prepare_plan has validated arity, axis and both inferred descriptions.
    // Empty selection needs no numeric conversion or vendor comparison domain.
    if (selection.count == 0)
      return Status::Ok();
    if (input.data_type() != DataType::kFloat32)
      return Status::Unimplemented("Vulkan TopK requires F32 router scores");
    if (*input.element_count() == 0)
      return Status::Ok(); // Distinct empty published owners, no GPU payload.
    if (*input.element_count() >
        program.runtime->device->properties.limits.maxStorageBufferRange / 4)
      return Status::Unimplemented(
          "Vulkan TopK dense adapter exceeds device limits");
    if (!topk_limits(program, input, selection))
      return Status::Unimplemented(
          "Vulkan TopK padded sort exceeds native limits");
    const auto rank = input.rank();
    const auto axis = static_cast<std::size_t>(
        selection.axis < 0 ? selection.axis + static_cast<std::int32_t>(rank)
                           : selection.axis);
    const auto width = input.dimensions()[axis];
    const auto rows = static_cast<std::int64_t>(*input.element_count()) / width;
    selection.axis = -1;
    while (program.aliases.size() < program.values.size()) {
      const auto id = static_cast<std::uint32_t>(program.aliases.size());
      program.aliases.push_back({id, 0});
    }
    const auto append = [&](const TensorDesc &description) {
      const auto id = static_cast<std::uint32_t>(program.values.size());
      program.values.push_back({description, {}});
      program.aliases.push_back({id, 0});
      return id;
    };
    const auto alias = [&](const TensorDesc &description,
                           std::uint32_t source) {
      const auto owner = program.aliases[source];
      const auto id = append(description);
      program.aliases[id] = owner;
      return id;
    };
    std::array<std::int32_t, kMaxTensorRank> axes{}, inverse{};
    std::size_t next = 0;
    for (std::size_t i = 0; i < rank; ++i)
      if (i != axis)
        axes[next++] = static_cast<std::int32_t>(i);
    axes[next] = static_cast<std::int32_t>(axis);
    for (std::size_t i = 0; i < rank; ++i)
      inverse[axes[i]] = static_cast<std::int32_t>(i);
    HYLE_ASSIGN_OR_RETURN(auto permute,
                          View::permute(std::span(axes).first(rank)));
    HYLE_ASSIGN_OR_RETURN(
        auto permuted,
        infer_single_output(Operation(permute), std::span(&input, 1)));
    auto source = alias(permuted, step.inputs[0]);
    if (!permuted.is_dense()) {
      HYLE_ASSIGN_OR_RETURN(
          auto dense,
          TensorDesc::dense(DataType::kFloat32, permuted.dimensions()));
      const auto packed = append(dense);
      HYLE_RETURN_IF_ERROR(lower_tensor(
          program, {Operation(Copy{}), {source}, {packed}, {}, {1, 1, 1}, {}}));
      source = packed;
    }
    HYLE_ASSIGN_OR_RETURN(
        auto matrix,
        TensorDesc::dense(DataType::kFloat32,
                          std::array<std::int64_t, 2>{rows, width}));
    const auto matrix_input = alias(matrix, source);
    std::array<TensorDesc, 2> results;
    HYLE_RETURN_IF_ERROR(infer_output_descriptions(
        Operation(selection), std::span(&matrix, 1), results));
    std::array<std::uint32_t, 2> output_ids{};
    for (std::size_t port = 0; port < output_ids.size(); ++port)
      output_ids[port] = axis + 1 == rank
                             ? alias(results[port], step.outputs[port])
                             : append(results[port]);
    Plan local;
    local.outputs.assign(output_ids.begin(), output_ids.end());
    local.steps.push_back({Operation(selection),
                           {matrix_input},
                           local.outputs,
                           {},
                           {1, 1, 1},
                           {}});
    std::vector<std::size_t> last_uses(program.values.size(), 0);
    HYLE_RETURN_IF_ERROR(lower_region(program, local, 0, 1, last_uses));
    if (axis + 1 == rank)
      return Status::Ok();
    // Provider rows are the other axes in their original order. Restore the
    // selected axis with ordinary View/Copy; both materializations are counted.
    std::array<std::int64_t, kMaxTensorRank> shape{};
    std::ranges::copy(permuted.dimensions(), shape.begin());
    shape[rank - 1] = static_cast<std::int64_t>(selection.count);
    HYLE_ASSIGN_OR_RETURN(auto restore,
                          View::permute(std::span(inverse).first(rank)));
    for (std::size_t port = 0; port < output_ids.size(); ++port) {
      HYLE_ASSIGN_OR_RETURN(auto expanded,
                            TensorDesc::dense(results[port].data_type(),
                                              std::span(shape).first(rank)));
      HYLE_ASSIGN_OR_RETURN(
          auto reordered,
          infer_single_output(Operation(restore), std::span(&expanded, 1)));
      const auto view = alias(reordered, output_ids[port]);
      HYLE_RETURN_IF_ERROR(lower_tensor(program, {Operation(Copy{}),
                                                  {view},
                                                  {step.outputs[port]},
                                                  {},
                                                  {1, 1, 1},
                                                  {}}));
    }
    return Status::Ok();
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("Vulkan TopK layout metadata");
  }
}

void refresh_region_bindings(Run &run) noexcept {
  for (auto &stage : run.stages) {
    if (stage.managed) {
      for (std::size_t port = 0; port < stage.values.size(); ++port) {
        const auto &buffer = run.retained_buffers[stage.values[port]];
        stage.bindings[port] =
            buffer && buffer->handle
                ? provider::RegionBinding{buffer->handle,
                                          static_cast<std::size_t>(
                                              buffer->offset),
                                          static_cast<std::size_t>(
                                              buffer->bytes),
                                          buffer}
                : provider::RegionBinding{};
      }
    }
  }
}

Status bind_regions(Run &run) noexcept {
  refresh_region_bindings(run);
  for (auto &stage : run.stages) {
    if (stage.managed) {
      HYLE_RETURN_IF_ERROR(stage.managed->bind(stage.bindings));
    } else if (stage.iree) {
      HYLE_RETURN_IF_ERROR(stage.iree->bind());
    } else {
      for (std::size_t i = 0; i < stage.values.size(); ++i)
        stage.native->retained_buffers[i] =
            run.retained_buffers[stage.values[i]];
      if (origins_changed(*stage.native, stage.encoding->dispatches))
        HYLE_RETURN_IF_ERROR(
            encode_commands(*stage.native, stage.encoding->dispatches));
    }
  }
  return Status::Ok();
}

Status record_regions(const std::shared_ptr<Run> &run,
                      std::span<const PlanValue> values,
                      std::span<const Dispatch> dispatches,
                      std::vector<DescriptorBinding> *dynamic) noexcept {
  try {
    for (std::size_t first = 0; first < dispatches.size();) {
      RunStage stage;
      if (dispatches[first].iree) {
        const auto &dispatch = dispatches[first++];
        stage.values = dispatch.values;
        HYLE_ASSIGN_OR_RETURN(stage.iree,
                              create_iree_stage(run, dispatch, values));
      } else if (dispatches[first].region) {
        const auto &dispatch = dispatches[first++];
        stage.values = dispatch.values;
        stage.bindings.resize(stage.values.size());
        std::lock_guard lock(run->runtime->mutex);
        HYLE_ASSIGN_OR_RETURN(
            auto region, provider::Region::create(
                             run->runtime->device->provider, *dispatch.region));
        stage.managed = std::make_unique<provider::Region>(std::move(region));
      } else {
        auto end = first + 1;
        while (end < dispatches.size() && !dispatches[end].region &&
               !dispatches[end].iree)
          ++end;
        for (auto i = first; i < end; ++i)
          stage.values.insert(stage.values.end(), dispatches[i].values.begin(),
                              dispatches[i].values.end());
        std::ranges::sort(stage.values);
        const auto duplicate = std::ranges::unique(stage.values);
        stage.values.erase(duplicate.begin(), duplicate.end());
        stage.encoding = std::make_shared<NativeEncoding>();
        stage.encoding->dispatches.assign(dispatches.begin() + first,
                                          dispatches.begin() + end);
        for (auto &dispatch : stage.encoding->dispatches)
          for (auto &value : dispatch.values)
            value = static_cast<std::uint32_t>(
                std::ranges::lower_bound(stage.values, value) -
                stage.values.begin());
        HYLE_ASSIGN_OR_RETURN(stage.native, create_run(run->runtime));
        std::vector<PlanValue> compact;
        for (const auto value : stage.values) {
          compact.push_back(values[value]);
          stage.native->retained_buffers.push_back(
              run->retained_buffers[value]);
        }
        std::vector<DescriptorBinding> bindings;
        HYLE_RETURN_IF_ERROR(record(stage.native, compact,
                                    stage.encoding->dispatches,
                                    dynamic ? &bindings : nullptr));
        if (dynamic)
          for (auto &binding : bindings) {
            binding.value = stage.values[binding.value];
            dynamic->push_back(binding);
          }
        first = end;
      }
      run->stages.push_back(std::move(stage));
    }
    std::lock_guard lock(run->runtime->mutex);
    HYLE_RETURN_IF_ERROR(bind_regions(*run));
    const auto &last = run->stages.back();
    run->completion_fence = last.managed ? last.managed->fence() : run->fence;
    run->encoding_valid = true;
    return Status::Ok();
  } catch (const std::bad_alloc &) {
    return Status::ResourceExhausted("Vulkan composed native regions");
  }
}
} // namespace hyle::compute::vulkan::detail
