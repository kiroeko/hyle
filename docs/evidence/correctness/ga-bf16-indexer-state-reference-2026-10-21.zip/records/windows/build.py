"""Refresh scoped GA ordinary-graph owners from the retained Windows closure."""
from pathlib import Path
import argparse
import concurrent.futures
import importlib.util
import sys
sys.dont_write_bytecode = True

S = Path(__file__).resolve().parent
P = S.parent
A = P.parent
R = A.parents[1]
spec = importlib.util.spec_from_file_location('ga_host_helpers', A / 'grouped-shared-activation/build_host.py')
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
b, c = h.b, h.c
OLD = A / 'e4-paired-pending-2026-10-21'
Q = A / 'mlx-head-payload-2026-10-21'
BASES = {arm: OLD / arm / 'checks' / directory / 'link-plan.json'
         for arm, directory in [('cpu', 'final-link2'), ('cuda', 'final-link2'), ('vulkan', 'final-link1')]}
AUDIT = c.read(S / 'base-recipe-audit.json')
PRODUCTS = {
    'operation': ('cpu', 'src/compute_ops/operation.cc'),
    'standard-index': ('cpu', 'src/compute_provider_ggml/standard_index.cc'),
    'cuda-collectives': ('cuda', 'src/compute_provider_cuda/collectives_provider.cc'),
    'cuda-tensor': ('cuda', 'src/compute_provider_ggml_cuda/tensor_program.cc'),
    'vulkan-region': ('vulkan', 'src/compute_route_vulkan/vulkan_region.cc'),
    'vulkan-provider-region': ('vulkan', 'src/compute_provider_ggml_vulkan/region.cc'),
}


def product_row(tag):
    arm, source = PRODUCTS[tag]
    return next(x for x in AUDIT['arms'][arm]['relevant_owners'] if x['source'] == source)


def compile_one(tag, source, template, recipe, old, out):
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'compile.result.json').exists(), out
    source = R / source
    command = b.host_command(template, source, tag, out)
    identity = b.identity(source)
    c.save(out / 'compile-plan.json', dict(source=identity, command=command,
        recipe=recipe, replaced_object=old, SDK_builds=0, GPU_runs=0))
    env, _ = b.environment(command, [], out)
    c.execute('compile', command, env, out)
    data = c.read(out / (tag + '-deps.json'))['Data']
    deps = [b.identity(p) for p in dict.fromkeys([data['Source'], *data['Includes']])]
    record = dict(source=identity, object=b.identity(out / (tag + '.obj')),
        command=command, recipe=recipe, replaced_object=old,
        source_dependencies=b.identity(out / (tag + '-deps.json')), dependencies=deps)
    assert b.same(identity) and all(b.same(x) for x in deps)
    c.save(out / 'identity.json', record)
    print('COMPILED', tag, flush=True)
    return record


def compile_product(tag, attempt):
    row = product_row(tag)
    return compile_one(tag, row['source'], row['command'], row['recipe'], row['object'],
                       P / 'common/checks' / attempt / tag)


def compile_test(arm, attempt):
    path = Q / arm / 'checks/attempt3/test-identity.json'
    recipe = c.read(path)
    return compile_one('ga-indexer-test', 'tests/graph_route_' + arm + '/ga_indexer_state_test.cc',
                       recipe['command'], str(path), None, P / arm / 'checks' / attempt)


def link_one(arm, product_attempt, test_attempt, link_dir):
    base = c.read(BASES[arm])
    assert all(b.same(x) for x in base['inputs'])
    drops = {c.key(x['object']['path']) for x in AUDIT['test_only_drop']['arms'][arm]}
    replacements = {}
    records = []
    for tag, (_, source) in PRODUCTS.items():
        matched = [x for x in AUDIT['arms'][arm]['relevant_owners'] if x['source'] == source]
        if not matched:
            continue
        assert len(matched) == 1
        record = c.read(P / 'common/checks' / product_attempt / tag / 'identity.json')
        assert b.same(record['source']) and b.same(record['object'])
        replacements[c.key(matched[0]['object']['path'])] = record['object']
        records.append(record)
    if arm == 'vulkan':
        # This target has exactly one implementation source. Replace its old
        # archive with the current object already used by the other two arms.
        state = c.read(A / 'state-clone-slot-ownership/checks/after-state_versions-identity.json')
        old = [x for x in base['inputs'] if Path(x['path']).name == 'hyle_compute_state.lib']
        assert len(old) == 1 and b.same(state['object'])
        replacements[c.key(old[0]['path'])] = state['object']
    test = c.read(P / arm / 'checks' / test_attempt / 'identity.json')
    assert b.same(test['source']) and b.same(test['object'])
    inputs = [replacements.get(c.key(x['path']), x) for x in base['inputs']
              if c.key(x['path']) not in drops]
    inputs.insert(0, test['object'])
    assert len({c.key(x['path']) for x in inputs}) == len(inputs)
    command = [replacements[c.key(x)]['path'] if c.key(x) in replacements else x
               for x in base['command']
               if c.key(x) not in drops and
               not x.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    command.insert(1, test['object']['path'])
    out = P / arm / 'checks' / link_dir
    out.mkdir(parents=True, exist_ok=True)
    (out / 'tmp').mkdir(exist_ok=True)
    assert not (out / 'link.result.json').exists()
    image = out / (arm + '.exe')
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')),
                '/IMPLIB:' + str(image.with_suffix('.lib'))]
    paths = [x for x in command if Path(x).is_absolute() and Path(x).suffix.lower() in ('.obj', '.lib')]
    assert [c.key(x) for x in paths] == [c.key(x['path']) for x in inputs]
    c.save(out / 'link-plan.json', dict(command=command, inputs=inputs,
        base=b.identity(BASES[arm]), replacements=replacements, test=test['object'],
        dropped_old_test_objects=AUDIT['test_only_drop']['arms'][arm],
        reuse_proof=b.identity(S / 'base-recipe-audit.json'),
        state_reuse=b.identity(S / 'state-owner-audit.json'), SDK_builds=0, GPU_runs=0))
    env, runtime = b.environment(command, [x['path'] for x in inputs], out)
    c.save(out / 'runtime-environment.json', dict(PATH=env['PATH'], runtime=runtime))
    c.execute('link', command, env, out)
    c.save(out / 'image.json', b.identity(image))
    print('LINKED', arm, flush=True)
    return dict(arm=arm, image=b.identity(image), link_plan=b.identity(out / 'link-plan.json'),
                runtime_environment=b.identity(out / 'runtime-environment.json'))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--products', action='store_true')
    p.add_argument('--tests', action='store_true')
    p.add_argument('--link', action='store_true')
    p.add_argument('--product-attempt', default='attempt1')
    p.add_argument('--test-attempt', default='attempt1')
    p.add_argument('--link-dir', default='link1')
    args = p.parse_args()
    if args.products:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(lambda tag: compile_product(tag, args.product_attempt), PRODUCTS))
    if args.tests:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(lambda arm: compile_test(arm, args.test_attempt), BASES))
    if args.link:
        rows = [link_one(arm, args.product_attempt, args.test_attempt, args.link_dir) for arm in BASES]
        c.save(S / 'ready-for-root-run.json', dict(status='compiled_linked_not_run', arms=rows,
            agent_CPU_runs=0, agent_GPU_runs=0, SDK_builds=0, NVCC_compiles=0))


if __name__ == '__main__':
    main()
