from pathlib import Path
import json,hashlib,base64,re,runpy
ROOT=Path.cwd();A=ROOT/'.scratch/architecture-refactor-2026-10-18';P=A/'ga-bf16-indexer-state-2026-10-21/apple';O=P/'mac';O.mkdir(exist_ok=True)
def read(p):return json.loads(Path(p).read_text())
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
OLD=A/'e4-paired-pending-2026-10-21/apple/mac/remote';oldplan=read(OLD/'plan.json');oldroot=oldplan['remote'];remote=oldroot.replace('/e4-paired-pending-2026-10-21/apple','/ga-bf16-indexer-state-2026-10-21/apple')
sources=['src/compute_ops/operation.cc','src/compute_state/state_versions.cc','tests/compute_route_apple/reduction_test.cc','tests/graph_route_apple/ga_indexer_state_test.cc']
product=read(A/'batch-query-extent/delegated/apple/results/src--compute_ops--operation.cc.json')
test_recipe=read(A/'mlx-head-payload-2026-10-21/apple/mac/remote/results/tests--graph_route_apple--native_region_test.cc-compile.command.json')['argv']
link=read(OLD/'results/link.command.json')['argv']
# Do not mix old test-emitted inline GE inference/vtables with the new schema.
excluded_tests=[x for x in link if x.endswith('.o') and ('/tests--' in x or '/tests/' in x or x.endswith('/static_fp8_test.o'))]
link=[x for x in link if x not in excluded_tests]
inputs=[x for x in read(OLD/'results/link-inputs.json') if x['path'] in link]
plan=dict(oldplan,remote=remote,image='ga-bf16-indexer-state',filter='AppleGaIndexer.*:AppleReduction.EmptyResultsAndPreparationRejections',compile=[],link=link,inputs=inputs,run_environment={},excluded_test_objects=excluded_tests)
state_archives=[x for x in link if x.endswith('/libhyle_compute_state.a')];assert len(state_archives)==1
plan['state_archive']=state_archives[0]
for source in sources:
 if source=='src/compute_ops/operation.cc':
  recipe=product['argv'];old_object=product['object'];assert link.count(old_object)==1
 elif source=='src/compute_state/state_versions.cc':
  recipe=[x.replace('HYLE_COMPUTE_OPS_BUILD','HYLE_COMPUTE_STATE_BUILD').replace('hyle_compute_ops_EXPORTS','hyle_compute_state_EXPORTS') for x in product['argv']]
  old_object=state_archives[0]
 else:
  recipe=test_recipe;old_object=None
 plan['compile'].append(dict(source=source,recipe=recipe,old_object=old_object))
plan['state_recipe_origin']='Actual retained common operation CXX recipe, changing only component build/export definitions; actual current compute_state CMake module owns one state_versions.cc TU.'
plan['include_roots']=list(dict.fromkeys(['tests/compute_route_apple',*oldplan['include_roots'],*[oldroot+'/'+x for x in oldplan['include_roots']if not x.startswith('/')],oldroot+'/tests/compute_models']))
previous={x['path']:dict(x,remote_path=oldroot+'/'+x['path'])for x in read(OLD/'source-manifest.json')}
previous.update({x['path']:x for x in read(OLD/'reused-source-manifest.json')})
search=[ROOT,ROOT/'include',*[x for x in(ROOT/'src').iterdir()if x.is_dir()],*[x for x in(ROOT/'third_party').iterdir()if x.is_dir()]];seen=set();include=re.compile(r'^\s*#\s*include\s*[<"]([^">]+)[">]',re.M)
def visit(p):
 p=p.resolve()
 if p in seen or not p.is_relative_to(ROOT)or not p.is_file():return
 if p.suffix not in ['.h','.hpp','.hh','.cc','.mm','.inc','.inl','.cuh']:return
 seen.add(p)
 for name in include.findall(p.read_text(encoding='utf-8',errors='replace')):
  target=next((b/name for b in[p.parent,*search]if(b/name).is_file()),None)
  if target:visit(target)
for source in sources:visit(ROOT/source)
files=[];reuse=[]
for p in sorted(seen):
 b=p.read_bytes();key=p.relative_to(ROOT).as_posix();row=dict(path=key,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 if key in previous and row['sha256']==previous[key]['sha256']:reuse.append(dict(row,remote_path=previous[key]['remote_path']))
 else:files.append(dict(row,data=base64.b64encode(b).decode()))
save(O/'source-manifest.json',[{k:v for k,v in x.items()if k!='data'}for x in files]);save(O/'reused-source-manifest.json',reuse);save(O/'plan.json',plan)
script=(P/'build_mac.py').read_bytes()
code=r"""from pathlib import Path
import base64,hashlib,json,sys,subprocess
p=json.load(sys.stdin);r=Path(p['plan']['remote']);r.mkdir(parents=True,exist_ok=True);assert not r.is_symlink()
for x in p['reuse']:
 q=Path(x['remote_path']);b=q.read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'],str(q)
for x in p['files']:
 b=base64.b64decode(x['data']);assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'];q=r/x['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
(r/'source-manifest.json').write_text(json.dumps([{k:v for k,v in x.items()if k!='data'}for x in p['files']],indent=2)+'\n');(r/'reused-source-manifest.json').write_text(json.dumps(p['reuse'],indent=2)+'\n');(r/'plan.json').write_text(json.dumps(p['plan'],indent=2)+'\n');(r/'build_mac.py').write_bytes(base64.b64decode(p['script']))
for x in p['plan']['inputs']:
 q=Path(x['path']);b=q.read_bytes();assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'],str(q)
members=subprocess.check_output(['ar','-t',p['plan']['state_archive']],text=True).splitlines();real=[x for x in members if not x.startswith('__.SYMDEF')];assert len(real)==1 and 'state_versions' in real[0],members;(r/'state-archive-members.json').write_text(json.dumps(dict(archive=p['plan']['state_archive'],members=members,replace_entire_archive_with_current_single_object=True),indent=2)+'\n')
h={k:subprocess.check_output(v,text=True).strip()for k,v in {'model':['sysctl','-n','hw.model'],'cpu':['sysctl','-n','machdep.cpu.brand_string'],'memory':['sysctl','-n','hw.memsize'],'os':['sw_vers'],'compiler':['clang++','--version'],'space':['df','-h',str(r)]}.items()};assert h['model']=='Mac16,12';(r/'hardware.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(remote=str(r),delta_files=len(p['files']),delta_bytes=sum(x['bytes']for x in p['files']),reuse_files=len(p['reuse']),hardware=h)))
"""
__import__('ast').parse(code);__import__('ast').parse(script.decode())
ssh=runpy.run_path(str(A/'batch-query-extent/delegated/apple/validate.py'))['ssh'];result=ssh(code,dict(plan=plan,files=files,reuse=reuse,script=base64.b64encode(script).decode()));save(O/'sync.result.json',result);print(json.dumps(result,indent=2))
