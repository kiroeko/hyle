#include "../compute_models/ga_indexer_state_fixture.h"
#include "hyle/compute/apple_memory.h"
#include "hyle/graph/apple.h"

TEST(AppleGaIndexer, EmptySelectionKeepsTwoShapesAndIndependentResults) {
  run_apple([](auto... args) { ga_indexer_state_test::run_empty(args...); });
}
TEST(AppleGaIndexer, PositiveSelectionKeepsExistingValuesAndIds) {
  run_apple([](auto... args) { ga_indexer_state_test::run_positive(args...); });
}
