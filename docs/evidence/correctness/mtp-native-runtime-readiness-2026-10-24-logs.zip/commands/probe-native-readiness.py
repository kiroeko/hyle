from pathlib import Path
import json,shlex,subprocess
S=Path(__file__).resolve().parent;OUT=S/'native-runtime-readiness';OUT.mkdir(exist_ok=False)
remote='/Users/kiro/hyle-scratch/compute-unified/architecture-refactor-20261019-apple-page-invocation/gdn-output-scale-20261024/attempt2'
code='''from pathlib import Path
import hashlib,json,subprocess
S=Path(REMOTE)
def identity(p):
 p=Path(p)
 if not p.is_file():return dict(path=str(p),exists=False)
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
preparation=json.loads((S/'native-preparation.json').read_text())
checks=[]
for item in preparation['files']:
 checks.append(dict(original=identity(item['source']['path']),edited=identity(item['output']['path']),
  original_still_matches=identity(item['source']['path'])==item['source'],edited_still_matches=identity(item['output']['path'])==item['output']))
symbols=[]
for name in ['metal-native-ops.o','metal-gdn-embed.o']:
 p=S/name;r=subprocess.run(['/usr/bin/nm','-gU',str(p)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 symbols.append(dict(object=identity(p),exit=r.returncode,relevant=[s for s in r.stdout.decode().splitlines() if 'gdn_output_scale' in s or 'metallib_gated_delta_net' in s]))
records=[]
for name in ['metal-native-ops-recipe2','metal-gdn-embed-recipe2','metal-run']:
 p=S/'logs'/name/'result.json';records.append(dict(path=str(p),record=json.loads(p.read_text())))
print(json.dumps(dict(remote_directory=str(S),native_sources=checks,symbols=symbols,
 archives=[identity(S/n) for n in ['libhyle_compute_gdn_scale.a','libhyle_compute_ops_gdn_scale.a']],
 records=records,source_preparation=preparation,read_only=True),indent=2))
'''.replace('REMOTE',repr(remote))
cmd=['ssh','-oBatchMode=yes','-oConnectTimeout=10','kiro@172.22.10.198','python3 -c '+shlex.quote(code)]
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
(OUT/'air-inventory.json').write_bytes(r.stdout)
(OUT/'air-probe-command.json').write_text(json.dumps(dict(command=cmd,exit=r.returncode),indent=2)+'\n')
if r.returncode:print(r.stderr.decode());raise SystemExit(r.returncode)
d=json.loads(r.stdout)
print(json.dumps(dict(unchanged_originals=all(x['original_still_matches'] for x in d['native_sources']),unchanged_edits=all(x['edited_still_matches'] for x in d['native_sources']),symbols=d['symbols']),indent=2))
