from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];OUT=S/'native-runtime-readiness/vulkan-real'
if OUT.exists() and any(OUT.iterdir()):raise RuntimeError('Output is not empty')
OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
BASE=R/'.scratch/gdn-vulkan-output-scale-20261024'
old=b.read(BASE/'link1/link-plan.json')
old_region=b.read(BASE/'compile1/compute_provider_ggml_vulkan--region/identity.json')
new_region=b.read(S/'dense-vulkan-check1/region/identity.json')
test=b.read(S/'dense-vulkan-check1/test/identity.json')
native_rec=b.read(BASE/'compile1/native/identity.json')
for rec in (new_region,test,native_rec):b.require(rec['source']);b.require(rec['object'])
replacement={old_region['object']['path']:new_region['object']['path']}
# The prior host Region is a member of its small ggml.lib. Supplying the
# complete new Region object directly keeps that old member unextracted.
assert old['command'].count(old_region['object']['path'])==0
assert old['command'].count(native_rec['object']['path'])==1
cmd=[arg for arg in old['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
cmd.insert(1,new_region['object']['path'])
assert not any('absent-gdn' in arg for arg in cmd)
image=OUT/'link/dense-gdn-vulkan.exe';cmd +=[test['object']['path'],'/OUT:'+str(image),'/MAP:'+str(image.with_suffix('.map'))]
cc=new_region['command'][0]
environment=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
b.save(OUT/'link-plan.json',dict(command=cmd,base=b.identity(BASE/'link1/link-plan.json'),
    native=native_rec['object'],new_dense_region=new_region['object'],new_dense_test=test['object'],
    source_header_boundary='Same original GGML Vulkan source-bdb6226828f5304e / ggml.h SHA9ac7ee3d; current Dense Region/test plus actual GDN host native scale selection.',
    fresh_product_TUs=0,fresh_native_TUs=0,SDK_builds=0,absent_contract_probes=0))
b.execute(cmd,environment.env,OUT/'link',90)
ready=b.read(BASE/'link1/ready.json')
print('BASE READY',list(ready),flush=True)
runtime_path=ready.get('PATH')
if not runtime_path:
    for p in (BASE/'link1/runtime-environment.json',BASE/'link1/runtime.json'):
        if p.is_file():
            d=b.read(p);runtime_path=d.get('PATH') or os.pathsep.join([*d.get('runtime',[]),environment.env['PATH']]);break
if not runtime_path:raise RuntimeError('Missing original native runtime PATH')
b.save(OUT/'ready.json',dict(image=b.identity(image),PATH=runtime_path))
result=b.execute([str(image),'--gtest_filter=GdnOutputScale.*:GgmlVulkanRegion.*DenseLinear*:GgmlVulkanRegion.*BfloatRouter*',
    '--gtest_output=json:'+str(OUT/'gtest-results.json')],dict(environment.env,PATH=runtime_path),OUT/'run',180)
b.save(OUT/'summary.json',dict(process=result,image=b.identity(image),scope='Focused real GDN scale plus current Dense provider; readiness only, no full model/MTP claim',
    absent_contract_probes=0,new_native_builds=0,SDK_builds=0,HTTP=0))
print((OUT/'run/stdout.log').read_text())
