from pathlib import Path
import importlib.util,json,re,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];OUT=S/'native-runtime-readiness/cmake-regeneration';OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
source=OUT/'source';source.mkdir(exist_ok=True)
script='''cmake_minimum_required(VERSION 3.24)
project(hyle_dependency_regeneration NONE)
include("MODULE")
get_property(_deps DIRECTORY PROPERTY CMAKE_CONFIGURE_DEPENDS)
if(NOT "LOCK" IN_LIST _deps)
  message(FATAL_ERROR "The actual central lock was not registered for regeneration")
endif()
file(WRITE "${CMAKE_BINARY_DIR}/registered-inputs.txt" "${_deps}\\n")
'''.replace('MODULE',(R/'cmake/HyleDependencyVersions.cmake').as_posix()).replace('LOCK',(R/'cmake/HyleDependencyLock.json').as_posix())
if (source/'CMakeLists.txt').exists():assert (source/'CMakeLists.txt').read_text()==script
else:(source/'CMakeLists.txt').write_text(script)
import os
if (OUT/'configure/process.json').exists():assert b.read(OUT/'configure/process.json')['exit']==0
else:b.execute(['cmake','-S',str(source),'-B',str(OUT/'build'),'-G','Ninja'],os.environ,OUT/'configure',60)
ninja=(OUT/'build/build.ninja').read_text()
regeneration=next(line for line in ninja.splitlines() if line.startswith('build ') and ': RERUN_CMAKE' in line)
assert 'HyleDependencyLock.json' in regeneration
b.save(OUT/'summary.json',dict(passed=True,project_languages='NONE',dependency_downloads=0,SDK_builds=0,
    actual_central_module=b.identity(R/'cmake/HyleDependencyVersions.cmake'),
    runtime_canonical_inputs_source=b.identity(R/'src/compute_ggml_runtime/CMakeLists.txt'),
    registered=(OUT/'build/registered-inputs.txt').read_text().splitlines(),ninja_regeneration_edge=regeneration,
    limits='Exercises actual central module and generated Ninja regeneration edge; no native SDK configuration/build.'))
(source/'include-check.cmake').write_text(script[script.index('include('):script.index('file(WRITE')])
b.execute(['cmake','-P',str(source/'include-check.cmake')],os.environ,OUT/'script-include',60)
print('PASS: real central JSON lock is a generated Ninja regeneration input; no compiler or SDK used')
