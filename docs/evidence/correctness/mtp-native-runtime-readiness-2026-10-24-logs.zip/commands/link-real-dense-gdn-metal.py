from pathlib import Path
import importlib.util,json,shlex,subprocess,sys,tarfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];OUT=S/'native-runtime-readiness/metal-real';OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
original=b.read(R/'.scratch/glm-mlx-flash-original-20261024/apple-gdn-scale-preparation/commands.json')
base=original['remote_directory']
dense=b.read(S/'dense-metal-check1/commands.json')['remote_directory']
remote='/Users/kiro/hyle-scratch/compute-unified/dense-linear-20261024/real-runtime1'
old=original['link']['metal']['argv']
cmd=[dense+'/metal-provider.o' if arg==base+'/metal-provider.o' else
    remote+'/dense-gdn-metal' if arg==base+'/metal-gdn-scale-checks' else
    '-Wl,-map,'+remote+'/dense-gdn-metal.map' if arg.startswith('-Wl,-map,') else arg for arg in old]
cmd +=[dense+'/metal-test.o']
assert not any('absent-gdn' in arg for arg in cmd)
b.save(OUT/'commands.json',dict(link=cmd,base=b.identity(R/'.scratch/glm-mlx-flash-original-20261024/apple-gdn-scale-preparation/commands.json'),
    native_new_compiles=0,SDK_builds=0,absent_contract_probes=0))
expected=b.read(S/'native-runtime-readiness/air-inventory.json')['symbols']
code='''from pathlib import Path
import hashlib,json,subprocess,tarfile,time
S=Path(REMOTE);S.mkdir(parents=True,exist_ok=False)
cmd=LINK
expected=EXPECTED
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
for row in expected:assert identity(row['object']['path'])==row['object']
def run(name,args):
 start=time.time()
 with (S/(name+'.stdout.log')).open('wb') as out,(S/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.run(args,cwd=S,stdout=out,stderr=err,timeout=180)
 (S/(name+'.json')).write_text(json.dumps(dict(command=args,exit=p.returncode,seconds=time.time()-start),indent=2)+'\\n')
 print(name,p.returncode,flush=True)
 if p.returncode:
  print((S/(name+'.stdout.log')).read_text(errors='replace')[-12000:]);print((S/(name+'.stderr.log')).read_text(errors='replace')[-12000:]);raise SystemExit(p.returncode)
run('link',cmd)
run('run',[str(S/'dense-gdn-metal'),'--gtest_filter=GdnOutputScale.*:GgmlMetalProgram.*DenseLinear*:GgmlMetalProgram.*BfloatRouter*','--gtest_output=json:'+str(S/'gtest-results.json')])
print((S/'run.stdout.log').read_text())
data=json.loads((S/'gtest-results.json').read_text());assert data['tests']==5 and data['failures']==0
maps=(S/'dense-gdn-metal.map').read_text()
assert '/metal-native-ops.o' in maps and '/metal-gdn-embed.o' in maps and 'absent-gdn' not in maps
(S/'link-facts.json').write_text(json.dumps(dict(native_objects=expected,
  actual_link_inputs=[identity(p) for p in cmd if p.endswith(('.o','.a'))],
  image=identity(S/'dense-gdn-metal'),map=identity(S/'dense-gdn-metal.map'),
  new_native_builds=0,SDK_builds=0,absent_contract_probes=0,
  anchors=[s for s in maps.splitlines() if 'ggml_hyle_metal_gdn_output_scale_contract' in s or 'metallib_gated_delta_net_' in s]),indent=2)+'\\n')
with tarfile.open(S/'results.tar.gz','w:gz') as tar:
 for p in S.iterdir():
  if p.is_file() and p.suffix in ('.json','.log'):tar.add(p,arcname=p.name)
'''.replace('REMOTE',repr(remote)).replace('LINK',repr(cmd)).replace('EXPECTED',repr(expected))
argv=['ssh','-oBatchMode=yes','-oConnectTimeout=10','kiro@172.22.10.198','python3 -c '+shlex.quote(code)]
with (OUT/'ssh.stdout.log').open('wb') as out,(OUT/'ssh.stderr.log').open('wb') as err:
    result=subprocess.run(argv,stdout=out,stderr=err,timeout=240)
b.save(OUT/'ssh-process.json',dict(command=argv,exit=result.returncode))
print((OUT/'ssh.stdout.log').read_text(errors='replace'))
if result.returncode:print((OUT/'ssh.stderr.log').read_text(errors='replace'));raise SystemExit(result.returncode)
subprocess.run(['scp','-oBatchMode=yes','-oConnectTimeout=10','kiro@172.22.10.198:'+remote+'/results.tar.gz',str(OUT/'results.tar.gz')],check=True)
with tarfile.open(OUT/'results.tar.gz') as tar:
    assert all(m.isfile() and Path(m.name).name==m.name for m in tar.getmembers());tar.extractall(OUT/'results',filter='data')
b.save(OUT/'summary.json',dict(tests=5,failures=0,absent_contract_probes=0,new_native_builds=0,SDK_builds=0,HTTP=0,
    scope='Current Dense NativeProgram + true GDN native ops/embed; runtime preparation, no full MTP model claim',
    result_archive=b.identity(OUT/'results.tar.gz')))
