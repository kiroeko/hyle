from pathlib import Path
import importlib.util,json,re,shlex,subprocess,sys,tarfile
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];OUT=S/'dense-metal-check1'
OUT.mkdir(exist_ok=False)
OLD=R/'.scratch/glm-mlx-flash-original-20261024/batched-bfloat-linear-apple-proposal'
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
old=b.read(OLD/'commands.json');previous=old['remote_directory']
remote='/Users/kiro/hyle-scratch/compute-unified/dense-linear-20261024/attempt1'
source=remote+'/source';host='kiro@172.22.10.198'
files={Path(x['local_path']) for x in b.read(OLD/'sync-manifest.json')['files']
    if Path(x['local_path']).is_file() and str(Path(x['local_path'])).startswith(str(R))}
files.update(R/p for p in ('src/compute_provider_ggml_metal/native_program.cc','tests/compute_provider_ggml_metal/native_program_test.mm'))
queue=list(files)
while queue:
    path=queue.pop()
    for inc in re.findall(r'^\s*#\s*include\s+"([^"]+)"',path.read_text(encoding='utf-8-sig'),re.M):
        choices=[path.parent/inc,R/'include'/inc,R/'src/compute_ggml_runtime'/inc,R/inc]
        match=next((p.resolve() for p in choices if p.is_file()),None)
        if match and match.is_relative_to(R) and match not in files:files.add(match);queue.append(match)
rows=[]
for row in old['metal']['compile']:
    argv=[arg.replace(previous,remote) for arg in row['argv'] if arg!='-fobjc-arc']
    argv=[arg.replace(source+'/focused/batched_bfloat_apple_test.mm',source+'/tests/compute_provider_ggml_metal/native_program_test.mm') for arg in argv]
    if row['name']=='metal-test-compile':argv.insert(1,'-I'+old['metal']['compile'][0]['argv'][10][2:])
    rows.append(dict(name=row['name'],argv=argv))
link=[arg.replace(previous,remote) for arg in old['metal']['link'][0]['argv']]
commands=dict(remote_directory=remote,compile=rows,link=link,
    run=[remote+'/metal-bfloat-checks','--gtest_filter=GgmlMetalProgram.*DenseLinear*:GgmlMetalProgram.*BfloatRouter*',
        '--gtest_output=json:'+remote+'/gtest-results.json'])
b.save(OUT/'commands.json',commands)
b.save(OUT/'sync-manifest.json',dict(files=[b.identity(p) for p in sorted(files)],SDK_copies=0,dependency_builds=0))
runner='''from pathlib import Path
import hashlib,json,subprocess,sys,time
S=Path(__file__).resolve().parent
d=json.loads((S/'commands.json').read_text())
def identity(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(name,args):
 start=time.time()
 with (S/(name+'.stdout.log')).open('wb') as out,(S/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.run(args,cwd=S,stdout=out,stderr=err,timeout=180)
 (S/(name+'.json')).write_text(json.dumps(dict(command=args,exit=p.returncode,seconds=time.time()-start,outputs=[identity(p) for p in S.glob('*.o')]),indent=2)+'\\n')
 print(name,p.returncode,flush=True)
 if p.returncode:
  print((S/(name+'.stdout.log')).read_text(errors='replace')[-12000:]);print((S/(name+'.stderr.log')).read_text(errors='replace')[-12000:]);raise SystemExit(p.returncode)
if sys.argv[1]=='compile':
 for row in d['compile']:run(row['name'],row['argv'])
elif sys.argv[1]=='link':run('link',d['link'])
elif sys.argv[1]=='run':run('run',d['run']);print((S/'run.stdout.log').read_text())
'''
(OUT/'build.py').write_text(runner)
archive=OUT/'focused-source.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(files):tar.add(p,arcname='source/'+p.relative_to(R).as_posix())
    for name in ('build.py','commands.json','sync-manifest.json'):tar.add(OUT/name,arcname=name)
def execute(name,args):
    folder=OUT/name;folder.mkdir(exist_ok=False)
    with (folder/'stdout.log').open('wb') as out,(folder/'stderr.log').open('wb') as err:
        p=subprocess.run(args,stdout=out,stderr=err,timeout=240)
    b.save(folder/'process.json',dict(command=args,exit=p.returncode))
    print(name,p.returncode,flush=True)
    print((folder/'stdout.log').read_text(errors='replace')[-12000:])
    if p.returncode:print((folder/'stderr.log').read_text(errors='replace')[-12000:]);raise SystemExit(p.returncode)
execute('mkdir',['ssh','-oBatchMode=yes','-oConnectTimeout=10',host,'python3 -c '+shlex.quote('from pathlib import Path;Path('+repr(remote)+').mkdir(parents=True,exist_ok=False)')])
execute('upload',['scp','-oBatchMode=yes','-oConnectTimeout=10',str(archive),host+':'+remote+'/source.tar.gz'])
code='from pathlib import Path;import hashlib,tarfile;p=Path('+repr(remote)+');a=p/"source.tar.gz";assert hashlib.sha256(a.read_bytes()).hexdigest()=='+repr(b.identity(archive)['sha256'])+';t=tarfile.open(a);assert all(m.isfile() and not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in t.getmembers());t.extractall(p)'
execute('extract',['ssh','-oBatchMode=yes','-oConnectTimeout=10',host,'python3 -c '+shlex.quote(code)])
for action in ('compile','link','run'):
    execute(action,['ssh','-oBatchMode=yes','-oConnectTimeout=10',host,'python3 '+shlex.quote(remote+'/build.py')+' '+action])
