from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
S=Path(__file__).resolve().parent;R=S.parents[1];OUT=S/'dense-vulkan-check1'
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
rec=b.read(OUT/'region/identity.json');cc=rec['command'][0]
native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
source=OUT/'absent-gdn-contract-i32.cc'
source.write_text('// Test closure only: absent GDN capability. Dense math is native.\n#include <cstdint>\nextern "C" std::int32_t ggml_hyle_vulkan_gdn_output_scale_contract() { return 0; }\n')
folder=OUT/'absent-gdn-contract-i32';obj=folder/'absent-gdn-contract.obj'
cmd=[cc,'/nologo','/c','/MD','/O2',str(source),'/Fo'+str(obj)]
b.execute(cmd,native.env,folder,30)
b.save(folder/'identity.json',dict(source=b.identity(source),object=b.identity(obj),command=cmd,
    purpose='int32 absent-contract=0 rejects all scale-contract GDN; does not replace any Dense math'))
cmd=[arg for arg in b.read(OUT/'link-plan.json')['command'] if not arg.upper().startswith('/OUT:')]
image=OUT/'link3/dense-vulkan-check.exe';cmd +=[str(obj),'/OUT:'+str(image)]
b.save(OUT/'link3-plan.json',dict(command=cmd,test_only_absent_contract=b.identity(source)))
b.execute(cmd,native.env,OUT/'link3',90)
runtime=b.read(R/'.scratch/native-paged-effects-20261022/vulkan-link1/runtime-environment.json')
runtime_path=runtime.get('PATH') or os.pathsep.join([*runtime['runtime'],native.env['PATH']])
b.save(OUT/'ready.json',dict(image=b.identity(image),PATH=runtime_path))
result=b.execute([str(image),'--gtest_filter=GgmlVulkanRegion.*DenseLinear*:GgmlVulkanRegion.*BfloatRouter*',
    '--gtest_output=json:'+str(OUT/'gtest-results-final.json')],dict(native.env,PATH=runtime_path),OUT/'run-final',240)
b.save(OUT/'summary-final.json',dict(process=result,image=b.identity(image),SDK_builds=0,model_downloads=0,
    native_GDN_claim=False,absent_GDN_contract_probe=0))
print((OUT/'run-final/stdout.log').read_text())
