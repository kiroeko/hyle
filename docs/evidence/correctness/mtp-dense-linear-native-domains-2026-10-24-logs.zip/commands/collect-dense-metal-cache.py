from pathlib import Path
import json,shlex,subprocess
S=Path(__file__).resolve().parent;O=S/'dense-metal-check1'
d=json.loads((O/'commands.json').read_text());remote=d['remote_directory']
code='''from pathlib import Path
import hashlib,json,subprocess
S=Path(REMOTE)
d=json.loads((S/'commands.json').read_text())
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
facts=[]
for cmd in [['uname','-m'],['sysctl','-n','hw.model'],['sysctl','-n','hw.memsize'],['/usr/bin/c++','--version']]:
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);facts.append(dict(command=cmd,exit=r.returncode,output=r.stdout.decode()))
print(json.dumps(dict(hardware=facts,static_link_inputs=[identity(p) for p in d['link'] if p.endswith('.a')],sdk_builds=0),indent=2))
'''.replace('REMOTE',repr(remote))
r=subprocess.run(['ssh','-oBatchMode=yes','-oConnectTimeout=10','kiro@172.22.10.198','python3 -c '+shlex.quote(code)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45,check=True)
(O/'cache-identities.json').write_bytes(r.stdout)
print('recorded native/SDK identity only; no build/download')
