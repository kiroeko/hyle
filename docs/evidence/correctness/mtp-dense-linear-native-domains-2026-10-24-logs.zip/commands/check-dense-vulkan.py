from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
OUT=Path(__file__).resolve().parent/'dense-vulkan-check1';OUT.mkdir(exist_ok=False)
recipes={
 'region':R/'.scratch/paged-append-20261021/unbind-native/checks/attempt1/provider-region/identity.json',
 'test':R/'.scratch/native-paged-effects-20261022/compile2/vk-test/identity.json'}
units={'region':'src/compute_provider_ggml_vulkan/region.cc','test':'tests/compute_provider_ggml_vulkan/region_test.cc'}
replacements={}
for name,path in recipes.items():
    rec=b.read(path);cc=rec['command'][0]
    native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
    flags=[];skip=False
    for arg in rec['command'][1:]:
        if skip:skip=False;continue
        if arg.lower()=='/sourcedependencies':skip=True;continue
        if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith('.cc'):continue
        flags.append(arg)
    folder=OUT/name;source=R/units[name];obj=folder/(name+'.obj');frozen=b.identity(source)
    cmd=[cc,*flags,'/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(folder/(name+'.pdb'))]
    b.execute(cmd,native.env,folder,180)
    assert frozen==b.identity(source)
    dep=b.read(folder/'dependencies.json')['Data']
    b.save(folder/'identity.json',dict(source=frozen,object=b.identity(obj),command=cmd,
        dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]))
    replacements[rec['object']['path']]=str(obj)
base=R/'.scratch/native-paged-effects-20261022/vulkan-link1'
old=b.read(base/'link-plan.json')
assert all(old['command'].count(arg)==1 for arg in replacements)
cmd=[replacements.get(arg,arg) for arg in old['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
image=OUT/'link/dense-vulkan-check.exe';cmd +=['/OUT:'+str(image)]
b.save(OUT/'link-plan.json',dict(command=cmd,replacements=replacements))
b.execute(cmd,native.env,OUT/'link',90)
runtime=b.read(base/'runtime-environment.json')
runtime_path=runtime.get('PATH') or os.pathsep.join([*runtime['runtime'],native.env['PATH']])
b.save(OUT/'ready.json',dict(image=b.identity(image),PATH=runtime_path))
if '--run' in sys.argv:
    result=b.execute([str(image),'--gtest_filter=GgmlVulkanRegion.*DenseLinear*:GgmlVulkanRegion.*BfloatRouter*',
        '--gtest_output=json:'+str(OUT/'gtest-results.json')],dict(native.env,PATH=runtime_path),OUT/'run',240)
    b.save(OUT/'summary.json',dict(process=result,image=b.identity(image),SDK_builds=0,model_downloads=0))
    print((OUT/'run/stdout.log').read_text())
