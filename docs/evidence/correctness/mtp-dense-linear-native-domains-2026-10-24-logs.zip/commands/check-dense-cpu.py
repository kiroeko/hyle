from pathlib import Path
import importlib.util,os,sys
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('helpers',R/'.scratch/engine-product-20261024/cpu-build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
OUT=Path(__file__).resolve().parent/'dense-cpu-check1'
OUT.mkdir(exist_ok=False)
recipe=b.read(R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt2/provider/identity.json')
cc=recipe['command'][0]
native=b.discover_environment(compiler='msvc',cache={'CMAKE_C_COMPILER':cc,'CMAKE_CXX_COMPILER':cc,'CMAKE_GENERATOR':'Ninja'},backends=())
flags=[];skip=False
for arg in recipe['command'][1:]:
    if skip:skip=False;continue
    if arg.lower()=='/sourcedependencies':skip=True;continue
    if arg.lower().startswith(('/fo','/fd')) or arg.lower().endswith('.cc'):continue
    flags.append(arg)
for name,rel in [('provider','src/compute_provider_ggml/ggml_cpu_provider.cc'),('test','tests/compute_provider_ggml/cpu_provider_test.cc')]:
    folder=OUT/name;source=R/rel;obj=folder/(name+'.obj');frozen=b.identity(source)
    cmd=[cc,*flags,'/sourceDependencies',str(folder/'dependencies.json'),str(source),'/Fo'+str(obj),'/Fd'+str(folder/(name+'.pdb'))]
    b.execute(cmd,native.env,folder,180)
    assert frozen==b.identity(source)
    dep=b.read(folder/'dependencies.json')['Data']
    b.save(folder/'identity.json',dict(source=frozen,object=b.identity(obj),command=cmd,
        dependencies=[b.identity(p) for p in dict.fromkeys([dep['Source'],*dep['Includes']])]))
base=R/'.scratch/mtp-full-quant-20261024/f32-paged-check/attempt3'
old=b.read(base/'link-plan.json')
replace={recipe['object']['path']:str(OUT/'provider/provider.obj')}
assert old['command'].count(recipe['object']['path'])==1
cmd=[replace.get(arg,arg) for arg in old['command'] if not arg.upper().startswith(('/OUT:','/MAP:','/PDB:','/IMPLIB:'))]
image=OUT/'link/dense-cpu-check.exe'
cmd +=[str(OUT/'test/test.obj'),'/OUT:'+str(image)]
b.save(OUT/'link-plan.json',dict(command=cmd,replacements=replace))
b.execute(cmd,native.env,OUT/'link',90)
for dll in (base/'link').glob('*.dll'):
    os.link(dll,OUT/'link'/dll.name)
ready=b.read(base/'ready.json')
result=b.execute([str(image),'--gtest_filter=GgmlCpuProvider.*Bfloat*:*DenseLinear*',
    '--gtest_output=json:'+str(OUT/'gtest-results.json')],dict(native.env,PATH=ready['PATH']),OUT/'run',180)
b.save(OUT/'summary.json',dict(process=result,image=b.identity(image),SDK_builds=0,model_downloads=0))
print((OUT/'run/stdout.log').read_text())
