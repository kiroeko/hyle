// Test closure only: absent GDN capability. Dense math is native.
#include <cstdint>
extern "C" std::int32_t ggml_hyle_vulkan_gdn_output_scale_contract() { return 0; }
