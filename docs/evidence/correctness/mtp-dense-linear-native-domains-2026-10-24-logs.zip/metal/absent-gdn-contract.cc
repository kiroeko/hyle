// Focused closure only: missing native GDN scale contract must decline.
#include <cstdint>
extern "C" std::int32_t ggml_hyle_metal_gdn_output_scale_contract() { return 0; }
