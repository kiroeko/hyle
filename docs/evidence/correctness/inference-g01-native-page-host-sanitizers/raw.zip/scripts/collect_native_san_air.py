from pathlib import Path
import hashlib,json,zipfile
base=Path('/Users/kiro/hyle-scratch/compute-unified')
out=base/'g01-native-page-host-sanitizers'
out.mkdir(exist_ok=True)
rows=[]
with zipfile.ZipFile(out/'raw.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for route in ['apple','vulkan']:
        for mode in ['asan','ubsan','tsan']:
            directory=base/f'g01-native-page-{route}-{mode}'
            receipt=json.loads((directory/'result.json').read_text())
            for stage in ['build','g01_page_public','g01_page_risks']:
                attempts=[r for r in receipt['stages'] if r['stage']==stage]
                assert attempts and attempts[-1]['exit_code']==0,(route,mode,stage)
            for path in directory.iterdir():
                if path.is_file():archive.write(path,path.relative_to(base))
            tree=base/f'foundation-f5-native-host-{route}-{mode}'
            archive.write(tree/'parent/CMakeLists.txt',f'{route}-{mode}/parent.cmake')
            commands=json.loads((directory/'instrumented-inputs.json').read_text())
            selected=[]
            for command in commands:
                name=command['file']
                if any(s in name for s in ['batch_paged_native.cc','materialized_invocation.cc','native_paged_','compute_paged_arena/','compute_provider_ggml_vulkan/region.cc']):
                    assert '-fsanitize='+({'asan':'address','ubsan':'undefined','tsan':'thread'}[mode]) in command['command'],name
                    selected.append(command)
                if route=='apple' and mode=='tsan' and any(s in name for s in ['/mlx/array.cpp','/backend/metal/metal.cpp','/backend/metal/scaled_dot_product_attention.cpp']):
                    assert '-fsanitize=thread' in command['command'],name
                    selected.append(command)
            assert selected,(route,mode)
            archive.writestr(f'{route}-{mode}/selected-compile-commands.json',json.dumps(selected,indent=2)+'\n')
            rows.append(receipt)
    probe=base/'g01-metal-callback-tsan-probe'
    for path in probe.iterdir():
        if path.is_file() and path.name!='probe':archive.write(path,path.relative_to(base))
    archive.write(probe/'tsan-metal-cpp/Metal/MTLCommandBuffer.hpp','metal-tsan-boundary/MTLCommandBuffer.hpp')
    for name in ['native_page_san_air.py','prepare_boundary.py','metal_callback_tsan_probe.py','collect_native_san_air.py']:
        path=base/name
        if path.is_file():archive.write(path,'scripts/'+name)
    boundary=json.loads((probe/'tsan-boundary.json').read_text())
    assert hashlib.sha256(Path(boundary['original']).read_bytes()).hexdigest()==boundary['before_sha256']
    assert hashlib.sha256(Path(boundary['copy']).read_bytes()).hexdigest()==boundary['after_sha256']
failures=[dict(route=r['route'],mode=r['mode'],**stage) for r in rows for stage in r['stages'] if stage['exit_code']]
names=['cmake/HyleDependencyLock.json','include/hyle/compute/batch_paged_native.h',
 'include/hyle/compute/detail/materialized_native_controller.h','src/compute_batch/batch_paged_native.cc',
 'third_party/mlx_cast/patches.json','third_party/ggml_vulkan_runtime/patches.json']
for route in ['apple','vulkan']:
    names += [f'include/hyle/compute/{route}_batch.h',f'include/hyle/compute/detail/{route}_batch_access.h',
      f'src/compute_route_{route}/{route}_batch.cc',f'src/compute_route_{route}/{route}_materialized_invocation.cc',
      f'tests/compute_batch/native_paged_{route}_consumer.cc',f'tests/compute_batch/native_paged_{route}_risks.cc']
names += ['tests/compute_batch/native_paged_risk_fixture.h','src/compute_provider_ggml_vulkan/region.cc','src/compute_provider_ggml_vulkan/region.h']
inputs=[{'path':name,'sha256':hashlib.sha256((base/'source-c8874688'/name).read_bytes()).hexdigest()} for name in names]
receipt={'candidate':'520027a57ff41da96ac908ad0d35896e2dda9734','verdict':'PASS_WITH_EXPLICIT_METAL_TSAN_MODEL',
 'scope':'Apple/Vulkan actual native host ASan/UBSan/TSan; no LSan, shader, driver or native private-pool instrumentation qualification',
 'apple_tsan':'Raw runs fail at opaque upstream Metal completed-handler handoff, reproduced by independent no-HYLE/no-MLX probe. Final pass instruments MLX host and models release(commit)/acquire(completion) on the same actual command buffer in a validation-only copied header; no suppressions; original dependency cache unchanged.',
 'metal_boundary':boundary,'runs':rows,'retained_failures':failures,'inputs':inputs,
 'test_input_revision':'951cc8ffa843047ebced49bd0aae9bfa7028c312',
 'test_input_note':'Product hashes bind candidate520; later test-only dead local removal a4ffd retained in SDK stage; no product/candidate change.',
 'cumulative_run_seconds':sum(s['elapsed_seconds'] for r in rows for s in r['stages']),
 'raw_sha256':hashlib.sha256((out/'raw.zip').read_bytes()).hexdigest()}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'verdict':receipt['verdict'],'runs':len(rows),'retained_failures':len(failures),'cumulative_run_seconds':receipt['cumulative_run_seconds'],'raw':str(out/'raw.zip')}))
