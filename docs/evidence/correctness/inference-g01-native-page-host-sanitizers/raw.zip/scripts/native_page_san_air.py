from pathlib import Path
import json,os,subprocess,time,sys
route,mode=sys.argv[1:];assert route in ['apple','vulkan'] and mode in ['asan','ubsan','tsan']
base=Path('/Users/kiro/hyle-scratch/compute-unified');source=base/'source-c8874688'
root=base/f'foundation-f5-native-host-{route}-{mode}';parent=root/'parent';build=root/'build'
out=base/f'g01-native-page-{route}-{mode}';out.mkdir(exist_ok=True)
assert parent.is_dir() and build.is_dir()
identity={n:subprocess.check_output(a,text=True).strip() for n,a in [('model',['sysctl','-n','hw.model']),('arch',['uname','-m']),('os',['sw_vers']),('compiler',['xcrun','clang','--version'])]}
assert identity['model']=='Mac16,12' and identity['arch']=='arm64'
targets=[('g01_page_public',f'tests/compute_batch/native_paged_{route}_consumer.cc'),('g01_page_risks',f'tests/compute_batch/native_paged_{route}_risks.cc')]
body=(parent/'CMakeLists.txt').read_text()
if route=='apple' and mode=='tsan' and 'hyle_apply_sanitizer(mlx)' not in body:
    # MLX shared_ptr publication/release across Metal callbacks must be
    # instrumented too; mixing instrumented inline templates with an opaque
    # vendor host can hide its synchronization. Test-parent change only.
    body+='\nhyle_apply_sanitizer(mlx)\n'
for target,name in targets:
    if f'add_executable({target} ' not in body:
        body+=f'\nadd_executable({target} "{source/name}")\ntarget_compile_features({target} PRIVATE cxx_std_23)\ntarget_link_libraries({target} PRIVATE hyle::compute hyle::graph)\nhyle_apply_sanitizer({target})\nhyle_stage_runtime({target})\n'
(parent/'CMakeLists.txt').write_text(body)
env=os.environ.copy();env['PATH']='/Users/kiro/hyle-verify-tools/metal-17F109/shim:/opt/homebrew/bin:'+env['PATH']
env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1')
record=out/'result.json';rows=json.loads(record.read_text())['stages'] if record.exists() else []
def run(stage,args):
    number=1+sum(r['stage']==stage for r in rows);log=out/f'{stage}-{number}.log';start=time.monotonic()
    with log.open('w') as handle:result=subprocess.run(args,env=env,stdout=handle,stderr=subprocess.STDOUT)
    row={'stage':stage,'command':args,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)}
    rows.append(row);record.write_text(json.dumps({'candidate':'520027a57ff41da96ac908ad0d35896e2dda9734','route':route,'mode':mode,'identity':identity,
        'scope':'actual native host objects, owned metadata/shared controller/ready-page guards/native failures and tiny GPU oracle; no LSan/shader/driver/private native instrumentation qualification',
        'mlx_host_tsan':route=='apple' and mode=='tsan',
        'stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
    if result.returncode:
        with log.open('rb') as data:data.seek(max(0,log.stat().st_size-4500));print(data.read().decode(errors='replace'),flush=True)
        raise SystemExit(result.returncode)
run('build',['/opt/homebrew/bin/cmake','--build',str(build),'--target','g01_page_public','g01_page_risks','--parallel','4'])
commands=json.loads(subprocess.check_output(['/opt/homebrew/bin/ninja','-C',str(build),'-t','compdb'],env=env,text=True))
flag='-fsanitize='+{'asan':'address','ubsan':'undefined','tsan':'thread'}[mode];checked=[]
names=[f'src/compute_route_{route}/{route}_batch.cc',f'src/compute_route_{route}/{route}_materialized_invocation.cc','src/compute_batch/batch_paged_native.cc','src/compute_batch/paged_arena.cc']+[n for _,n in targets]
if route=='vulkan':names+=['src/compute_provider_ggml_vulkan/region.cc']
if route=='apple' and mode=='tsan':names+=['mlx/array.cpp','mlx/backend/metal/metal.cpp','mlx/backend/metal/scaled_dot_product_attention.cpp']
for name in names:
    selected=[c for c in commands if c['file'].endswith(name)];assert selected and all(flag in c['command'] for c in selected),name
    checked.extend(selected)
(out/'instrumented-inputs.json').write_text(json.dumps(checked,indent=2)+'\n')
for target,_ in targets:run(target,[str(build/target)])
print('TERMINAL PASS',route,mode,'native host facets',flush=True)
