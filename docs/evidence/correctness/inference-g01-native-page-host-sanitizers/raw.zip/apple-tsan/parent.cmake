cmake_minimum_required(VERSION 3.25)
project(f5_native_host_san LANGUAGES CXX)
set(CMAKE_OSX_DEPLOYMENT_TARGET 14.4)
add_subdirectory("/Users/kiro/hyle-scratch/compute-unified/source-c8874688" hyle)
add_executable(native "/Users/kiro/hyle-scratch/compute-unified/source-c8874688/tests/compute_batch/materialized_native_consumer.cc")
target_compile_features(native PRIVATE cxx_std_23)
target_link_libraries(native PRIVATE hyle::compute hyle::graph)
hyle_apply_sanitizer(native)
hyle_stage_runtime(native)
add_executable(public_native "/Users/kiro/hyle-scratch/compute-unified/source-c8874688/tests/compute_batch/public_batch_native_consumer.cc")
target_compile_features(public_native PRIVATE cxx_std_23)
target_link_libraries(public_native PRIVATE hyle::compute hyle::graph)
hyle_apply_sanitizer(public_native)
hyle_stage_runtime(public_native)
target_compile_definitions(native PRIVATE HYLE_F5_APPLE_TEST=1)

set(INSTALL_GTEST OFF CACHE BOOL "" FORCE)
add_subdirectory(/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/googletest-063de7e9578f-162765170ae6 g01-native-ragged-gtest EXCLUDE_FROM_ALL)

add_executable(g01_native_ragged "/Users/kiro/hyle-scratch/compute-unified/source-c8874688/tests/compute_route_apple/native_ragged_test.cc")
target_compile_features(g01_native_ragged PRIVATE cxx_std_23)
target_link_libraries(g01_native_ragged PRIVATE hyle::compute GTest::gtest_main)
hyle_apply_sanitizer(g01_native_ragged)
hyle_stage_runtime(g01_native_ragged)

add_executable(g01_native_memory /Users/kiro/hyle-scratch/compute-unified/source-c8874688/tests/compute_batch/native_memory_owner_consumer.cc)
target_compile_features(g01_native_memory PRIVATE cxx_std_23)
target_link_libraries(g01_native_memory PRIVATE hyle::compute)
hyle_apply_sanitizer(g01_native_memory)
hyle_stage_runtime(g01_native_memory)
target_compile_definitions(g01_native_memory PRIVATE HYLE_NATIVE_MEMORY_APPLE=1)

add_executable(g01_page_public "/Users/kiro/hyle-scratch/compute-unified/source-c8874688/tests/compute_batch/native_paged_apple_consumer.cc")
target_compile_features(g01_page_public PRIVATE cxx_std_23)
target_link_libraries(g01_page_public PRIVATE hyle::compute hyle::graph)
hyle_apply_sanitizer(g01_page_public)
hyle_stage_runtime(g01_page_public)

add_executable(g01_page_risks "/Users/kiro/hyle-scratch/compute-unified/source-c8874688/tests/compute_batch/native_paged_apple_risks.cc")
target_compile_features(g01_page_risks PRIVATE cxx_std_23)
target_link_libraries(g01_page_risks PRIVATE hyle::compute hyle::graph)
hyle_apply_sanitizer(g01_page_risks)
hyle_stage_runtime(g01_page_risks)

hyle_apply_sanitizer(mlx)

target_include_directories(mlx BEFORE PRIVATE "/Users/kiro/hyle-scratch/compute-unified/g01-metal-callback-tsan-probe/tsan-metal-cpp")

target_include_directories(hyle_compute_route_apple BEFORE PRIVATE "/Users/kiro/hyle-scratch/compute-unified/g01-metal-callback-tsan-probe/tsan-metal-cpp")

target_include_directories(g01_page_public BEFORE PRIVATE "/Users/kiro/hyle-scratch/compute-unified/g01-metal-callback-tsan-probe/tsan-metal-cpp")

target_include_directories(g01_page_risks BEFORE PRIVATE "/Users/kiro/hyle-scratch/compute-unified/g01-metal-callback-tsan-probe/tsan-metal-cpp")
