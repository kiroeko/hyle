from pathlib import Path
import subprocess,time,json,os
base=Path('/Users/kiro/hyle-scratch/compute-unified')
out=base/'g01-metal-callback-tsan-probe';out.mkdir(exist_ok=True)
header=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/metal_cpp-f567ed836e4c-3874e9e28e8e')
if len(__import__('sys').argv)>1:header=out/'tsan-metal-cpp'
record=out/'result.json';rows=json.loads(record.read_text())['stages'] if record.exists() else []
env=os.environ.copy();env['TSAN_OPTIONS']='halt_on_error=1'
for stage,args in [('compile',['xcrun','clang++','-std=c++20','-O1','-g','-fno-omit-frame-pointer','-fsanitize=thread',
    '-I'+str(header),str(out/'probe.mm'),'-framework','Foundation','-framework','Metal','-o',str(out/'probe')]),('run',[str(out/'probe')])]:
    start=time.monotonic();number=1+sum(r['stage']==stage for r in rows);log=out/(stage+'-'+str(number)+'.log')
    with log.open('w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
    row={'stage':stage,'command':args,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':str(log)};rows.append(row)
    (out/'result.json').write_text(json.dumps({'scope':'isolate exact upstream Apple metal-cpp completed-handler publication with no HYLE/MLX, not a product gate','stages':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
    if r.returncode:
        print(log.read_text(errors='replace')[-9000:],flush=True);break
