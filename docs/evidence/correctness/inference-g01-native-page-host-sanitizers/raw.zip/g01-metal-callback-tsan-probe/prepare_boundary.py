from pathlib import Path
import hashlib,json,shutil,subprocess
base=Path('/Users/kiro/hyle-scratch/compute-unified')
out=base/'g01-metal-callback-tsan-probe'
original=Path('/Users/kiro/Library/Caches/hyle/dependencies/v1/sources/metal_cpp-f567ed836e4c-3874e9e28e8e')
copy=out/'tsan-metal-cpp'
assert copy.resolve().is_relative_to(out.resolve())
if not copy.exists():shutil.copytree(original,copy)
relative=Path('Metal/MTLCommandBuffer.hpp');before=(original/relative).read_bytes()
text=before.decode()
signature='_MTL_INLINE void MTL::CommandBuffer::commit()'
position=text.index(signature);end=text.index('\n}',position)+2
chunk=text[position:end]
assert 'Object::sendMessage' in chunk
adapted=chunk.replace('{\n','{\n    __tsan_release(this); // Native commit precedes every completed callback.\n',1)
text=text.replace(chunk,adapted,1)
callback='addCompletedHandler(^(MTL::CommandBuffer* pCommandBuffer) { blockFunction(pCommandBuffer); });'
assert text.count(callback)==1
text=text.replace(callback,'addCompletedHandler(^(MTL::CommandBuffer* pCommandBuffer) { __tsan_acquire(pCommandBuffer); blockFunction(pCommandBuffer); });',1)
anchor='#pragma once';assert text.count(anchor)==1
text=text.replace(anchor,anchor+'\n\n// Validation-only model of the opaque Metal commit/completion edge.\nextern "C" void __tsan_release(void*);\nextern "C" void __tsan_acquire(void*);',1)
after=text.encode();(copy/relative).write_bytes(after)
receipt={'scope':'validation-only per-command-buffer happens-before edge; no race suppression or product/header/cache change',
    'original':str(original/relative),'copy':str(copy/relative),
    'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),
    'edge':'release on commandBuffer.commit before native submission, acquire on the same callback argument before accessing the copied handler; only this native completion relationship is modeled'}
(out/'tsan-boundary.json').write_text(json.dumps(receipt,indent=2)+'\n')
parent=base/'foundation-f5-native-host-apple-tsan/parent/CMakeLists.txt'
body=parent.read_text()
for target in ['mlx','hyle_compute_route_apple','g01_page_public','g01_page_risks']:
    directive=f'target_include_directories({target} BEFORE PRIVATE "{copy}")'
    if directive not in body:body+='\n'+directive+'\n'
parent.write_text(body)
print(json.dumps(receipt),flush=True)
