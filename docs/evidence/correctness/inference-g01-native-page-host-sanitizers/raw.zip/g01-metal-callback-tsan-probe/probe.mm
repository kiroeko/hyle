#define NS_PRIVATE_IMPLEMENTATION
#define MTL_PRIVATE_IMPLEMENTATION
#include <Foundation/Foundation.hpp>
#include <Metal/Metal.hpp>
#include <atomic>
#include <cstdio>
#include <memory>
#include <vector>

int main(){
  auto* pool=NS::AutoreleasePool::alloc()->init();
  auto* device=MTL::CreateSystemDefaultDevice();
  auto* queue=device->newCommandQueue();
  std::atomic<unsigned> completed{0};
  auto* buffer=device->newBuffer(4096,MTL::ResourceStorageModeShared);
  for(unsigned i=0;i<512;++i){
    auto* command=queue->commandBufferWithUnretainedReferences();
    auto* encoder=command->blitCommandEncoder();
    encoder->fillBuffer(buffer,NS::Range::Make(0,4096),0);encoder->endEncoding();
    auto captured=std::make_shared<std::vector<unsigned>>(64,i);
    MTL::HandlerFunction handler=[&completed,captured](MTL::CommandBuffer*){
      if((*captured)[0]==999999)std::abort();
      completed.fetch_add(1,std::memory_order_release);
    };
    command->addCompletedHandler(handler);
    command->commit();command->waitUntilCompleted();
    while(completed.load(std::memory_order_acquire)<i+1){}
  }
  std::printf("direct Apple metal-cpp callback, no HYLE/MLX: completed=%u\n",completed.load());
  buffer->release();queue->release();device->release();pool->release();return 0;
}
