#include "../../engine/models/qwen35/main.cc"
#include "qwen_host_image_case.h"
#include "inference_program_carrier_case.h"

int main(int argc, char **argv) {
  try {
    if(argc!=2)throw std::runtime_error("usage: carrier cpu|cuda");
    const std::string_view kind(argv[1]);
    if(kind!="cpu"&&kind!="cuda")throw std::runtime_error("unknown backend");
    return inference_program_carrier_case::run(kind=="cpu"?qwen35::BackendKind::kCpu:qwen35::BackendKind::kCuda);
  } catch(const std::exception &error) {
    std::cerr<<error.what()<<'\n';return 1;
  }
}
