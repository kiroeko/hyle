from pathlib import Path
import importlib.util
import shutil

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json')
for path in W.rglob('process.json'):
    assert b.read(path)['state']=='TERMINAL',str(path)
base=dict(schema='hyle.program-io-consumers.current-link-base.v1',base=plan['base'],
          compile=plan['units']['carrier']['compile'],link=plan['units']['carrier']['link'],
          consumer_source=b.pin(W/'carrier.cc'),previous_consumer=b.pin(W/'compile/carrier/receipt.json'),
          retained=plan['retained'],runtime=plan['runtime'],sdk_engine_dependencies=plan['sdk'],
          indexer_provider_refresh=plan['indexer_provider_refresh'])
for item in [*base['retained'],base['runtime'],base['previous_consumer'],base['sdk_engine_dependencies']]:b.exact(item)
b.save(W/'model-link-base.json',base)
paths=sorted(p for p in (W/'bin').iterdir() if p.is_file())
paths += [p for p in (W/'compile/ds-early-baseline').iterdir() if p.is_file() and p.suffix.lower() in ('.obj','.pdb')]
allowed=[str(W/'bin'),str(W/'compile/ds-early-baseline')]
for p in paths:assert p.parent in (W/'bin',W/'compile/ds-early-baseline')
b.save(W/'cleanup-plan.json',dict(allowed_roots=allowed,files=[b.pin(p) for p in paths],bytes=sum(p.stat().st_size for p in paths)))
script=r'''param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$TaskRoot = 'C:\public\project-hyle\hyle\.scratch\inference-program-io-consumers-20261030'
$ExpectedRoots = @((Join-Path $TaskRoot 'bin'), (Join-Path $TaskRoot 'compile\ds-early-baseline'))
$Plan = Get-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$AllowedRoots = @($Plan.allowed_roots | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') })
if ($AllowedRoots.Count -ne 2 -or @($AllowedRoots | Where-Object { $_ -notin $ExpectedRoots }).Count) { throw 'Unexpected cleanup roots' }
foreach ($Receipt in Get-ChildItem -LiteralPath $TaskRoot -Filter 'process.json' -File -Recurse) {
    if ((Get-Content -LiteralPath $Receipt.FullName -Raw | ConvertFrom-Json).state -ne 'TERMINAL') { throw "Process still running: $($Receipt.FullName)" }
}
foreach ($Entry in $Plan.files) {
    $TargetPath = [IO.Path]::GetFullPath($Entry.path)
    if ([IO.Path]::GetDirectoryName($TargetPath) -notin $AllowedRoots) { throw "Outside exact cleanup roots: $TargetPath" }
    $Item = Get-Item -LiteralPath $TargetPath
    if ($Item.PSIsContainer -or ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not an ordinary file: $TargetPath" }
    if ($Item.Length -ne $Entry.bytes -or (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Entry.sha256) { throw "File identity changed: $TargetPath" }
}
if (-not $Execute) {
    [pscustomobject]@{Files=$Plan.files.Count; Bytes=$Plan.bytes; Roots=$AllowedRoots -join ', '}
    return
}
foreach ($Entry in $Plan.files) { Remove-Item -LiteralPath $Entry.path -Force }
$Report = [pscustomobject]@{status='COMPLETE'; files=$Plan.files.Count; bytes=$Plan.bytes; scope='Only this batch native images/link outputs and disposable baseline object; current consumer/provider objects and 226 original SDK/engine inputs retained.'}
$Report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-report.json') -Encoding utf8
$Report
'''
(R/'test.ps1').write_text(script,encoding='utf-8-sig')
shutil.copyfile(R/'test.ps1',W/'test.ps1')
print('Prepared exact cleanup:',len(paths),'files',sum(p.stat().st_size for p in paths),'bytes; script not executed.')
