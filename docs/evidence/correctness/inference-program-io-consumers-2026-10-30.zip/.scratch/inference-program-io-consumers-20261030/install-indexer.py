from pathlib import Path
import importlib.util

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json');b.save(W/'plan-before-indexer-fix.json',plan)
old=[x for x in plan['retained'] if 'compute_provider_cuda--row_cache_indexer_provider_cc' in x['path']]
assert len(old)==1
new=b.b.receipt('indexer-provider')['object'];old=old[0]
for unit in plan['units'].values():
    unit['link']=[new['path'] if b.key(arg)==b.key(old['path']) else arg for arg in unit['link']]
plan['retained']=[new if b.key(item['path'])==b.key(old['path']) else item for item in plan['retained']]
plan['indexer_provider_refresh']=dict(old=old,new=new,recipe=b.pin(W/'compile/indexer-provider/receipt.json'))
plan['cases']['indexer-all-cuda']=dict(unit='indexer-test',filter='CudaRowCacheIndexer.*',tests=4)
b.save(W/'plan.json',plan)
print('Replaced sole indexer provider object; 226 original SDK/engine inputs retained, native kernels unchanged.')
