from pathlib import Path
import importlib.util

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
plan=b.read(W/'plan.json')
old=plan['units']['runner'];name='indexer-test';folder=W/'compile'/name;folder.mkdir(parents=True,exist_ok=True)
source=R/'tests/compute_provider_cuda/row_cache_indexer_test.cc';command=[]
for index,arg in enumerate(old['compile']):
    if index and old['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
    elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
    elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
    elif b.key(arg)==b.key(old['source']):arg=str(source)
    command.append(arg)
link=[]
for arg in old['link']:
    if b.key(arg)==b.key(W/'compile/runner/unit.obj'):arg=str(folder/'unit.obj')
    for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
        if arg.upper().startswith(prefix):arg=prefix+str((W/'bin'/name).with_suffix(suffix));break
    link.append(arg)
plan['units'][name]=dict(source=str(source),compile=command,link=link)
for case in ['indexer-old-cuda','indexer-fixed-cuda']:
    plan['cases'][case]=dict(unit=name,filter='CudaRowCacheIndexer.ZeroFirstHeadStillReducesDistinctHeadsTokensAndMaskedRows',tests=1)
name='indexer-provider';folder=W/'compile'/name;folder.mkdir(parents=True,exist_ok=True)
original=R/'.scratch/inference-current-closure-20261026/headers79/compute_provider_cuda--row_cache_indexer_provider_cc/command.json'
recipe=b.read(original);command=recipe['command'] if isinstance(recipe,dict) else recipe
compiled=[]
for index,arg in enumerate(command):
    if index and command[index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
    elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
    elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
    compiled.append(arg)
source=R/'src/compute_provider_cuda/row_cache_indexer_provider.cc'
assert sum(b.key(arg)==b.key(source) for arg in compiled)==1
if not any(arg.lower()=='/sourcedependencies' for arg in compiled):compiled+=['/sourceDependencies',str(folder/'dependencies.json')]
plan['units'][name]=dict(source=str(source),compile=compiled,link=[])
b.save(W/'plan.json',plan)
print('Prepared one finite CUDA regression and one provider CXX object; no NVCC or SDK rebuild.')
