from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess
import zipfile

W=Path(__file__).resolve().parent
R=W.parents[1]
spec=importlib.util.spec_from_file_location('current',W/'build.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
read,save,pin,exact=b.read,b.save,b.pin,b.exact
plan=read(W/'plan.json')
builds=[]
for name in plan['units']:
    receipt=b.b.receipt(name)
    builds.append(dict(unit=name,receipt=pin(W/'compile'/name/'receipt.json'),
                       source_count=len(receipt['source_identities']),object=receipt['object'],
                       linked=name not in ('ds-original','indexer-provider')))
cases=[]
names=['runner-cpu','ds-pro-cpu','ds-flash-cpu','ds-early-cuda','glm-cuda',
       'glm-early-cuda','glm-flash-cuda','kimi-cuda','carrier-cpu','carrier-cuda','indexer-all-cuda']
for name in names:
    case=plan['cases'][name]
    attempt=('fixed' if name in ('ds-early-cuda','glm-cuda','glm-early-cuda','glm-flash-cuda') else
             'attempt2' if name in ('runner-cpu','ds-pro-cpu') else 'attempt1')
    folder=W/'runs'/name/attempt
    process=read(folder/'process.json');report=read(folder/'report.json')
    assert process['state']=='TERMINAL' and process['exit']==0 and not process['timed_out']
    assert report['status']=='PASS'
    cases.append(dict(name=name,unit=case['unit'],tests=report.get('tests'),
                      process=pin(folder/'process.json'),report=pin(folder/'report.json')))
comparisons={}
for name in ('ds-pro-cpu','ds-flash-cpu','glm-cuda'):
    attempt='attempt2' if name=='ds-pro-cpu' else 'attempt1'
    current=pin(W/'runs'/name/attempt/'report.json')
    before=R/'.scratch/inference-multimodel-observation-20261029/runs'/name/'attempt1/report.json'
    assert read(current['path'])==read(before)
    comparisons[name]=dict(before_indexer_math_fix_all_recorded_properties_identical=True,
                           current_IO_migration_report=current,previous=pin(before))
attempts=[]
for group in ('compile','link','runs'):
    for path in sorted((W/group).rglob('process.json')):
        process=read(path)
        assert process['state']=='TERMINAL',str(path)
        attempts.append(dict(kind=group,path=str(path.relative_to(W)),exit=process['exit'],seconds=process['seconds']))
assert sum(c['tests'] or 0 for c in cases)==18
assert len(cases)==11
assert len(plan['retained'])==227
for item in [*plan['retained'],plan['runtime'],plan['sdk']]:exact(item)
for unit in read(plan['sdk']['path'])['engine_consumers']:
    for item in unit['source_identities']:exact(item)
save(W/'verification.json',dict(builds=builds,cases=cases,comparisons=comparisons,
     attempts=attempts,indexer_provider_refresh=plan['indexer_provider_refresh']))
changed=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines()
snapshot=W/'sources'
for name in changed:
    if Path(name).suffix not in ('.h','.cc'):continue
    target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,target)
bundle=R/'docs/evidence/correctness/inference-program-io-consumers-2026-10-30.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in sorted(W.rglob('*')):
        if not path.is_file() or path.suffix.lower() not in ('.py','.ps1','.json','.log','.xml','.cc','.h'):continue
        if any(part in ('bin','tmp','__pycache__') for part in path.relative_to(W).parts):continue
        archive.write(path,str(path.relative_to(R)).replace('\\','/'))
    archive.write(plan['sdk']['path'],'.scratch/inference-program-io-consumers-20261030/sdk-engine-dependencies.json')
    for name,comparison in comparisons.items():
        archive.write(comparison['previous']['path'],f'.scratch/inference-program-io-consumers-20261030/previous/{name}.json')
summary=dict(
    schema='hyle.correctness.program-io-consumers.v1',date='2026-10-30',status='PASS',
    base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    changes=[
        'Real GLM Flash/Pro, DSpark formal Flash/Pro and Kimi component programs use existing product ProgramIo for cold input handles, prepared output ownership/bytes, binding and retain.',
        'A test-local stable ColdProgram replaces the original compiled graph holder; the original CompiledGraph, Invocation, caller LeasePool, Commands replay, counters, Head/state, resident supply and true retirement remain authoritative.',
        'External resident bank/map port search, input masks and WeightBinding order are prepared once per actual phase. No per-execution output byte arithmetic or runtime port-index search remains in the shared runner.',
        'Synchronous consumers keep the original reset-only success cleanup. An initially added redundant unbind and unnecessary product overload were removed before final regression; no new binding-release requirement or doubled cleanup scan.',
        'Cold plans reject duplicate/out-of-range ports, missing binder and foreign program before modifying an original prepared Invocation. Original pool refusal, native checked failure, retained-source refusal and unknown exception type retain their old recovery contracts.',
        'Real first-compression DSpark history exposed an existing CUDA indexer bug. Exact HEAD consumer/runner/native-header A/B with the same SDK reproduced identical incorrect scores, excluding the IO migration as cause.',
        'Indexer BF16 head reduction used a strided Sum with zero input_strides, repeating the first dot product. Set physical key/token/head byte strides; shared packed/paged/dense tile math, rounding stages and buffers remain unchanged.',
        'New exact finite zero-first-head T2/L3 regression fails against old provider object and passes against the single refreshed provider CXX object. Existing three indexer tests also pass; no native kernel recompile.'
    ],
    counts=dict(current_consumer_TUs=10,current_linked_consumers=9,retained_SDK_engine_inputs=226,
                CXX_attempts=sum(a['kind']=='compile' for a in attempts),
                link_attempts=sum(a['kind']=='link' for a in attempts),
                native_attempts=sum(a['kind']=='runs' for a in attempts),
                current_passed_processes=11,current_GTests=18,current_carrier_processes=2,
                SDK_CXX=1,NVCC=0,downloads=0,full_builds=0),
    preserved_failures=[
        'GLM Flash initial strict /W4 /WX compile failed C4456: new phase boundary shadowed outer cold ResidentBoundary. Renamed router; no warning suppression.',
        'GLM early initial strict compile failed C4456: new plane loop index shadowed existing bank lambda. Renamed plane; no warning suppression.',
        'Current and exact HEAD baseline DSpark early-history CUDA consumers both fail the same independent index-score bounds at position3/layers40 and42 before any resident-bank binding.',
        'New indexer regression with old provider returns zero for visible scores instead of 0.99609375, 3.03125 and 4.5625; independent oracle and masks unchanged.'
    ],
    cases=[dict(name=c['name'],tests=c['tests'],status='PASS') for c in cases],
    IO_migration_identical_reports=list(comparisons),
    indexer_provider_refresh=dict(old_sha256=plan['indexer_provider_refresh']['old']['sha256'],
                                  new_sha256=plan['indexer_provider_refresh']['new']['sha256']),
    reproduction=dict(directory=str(W),details='verification.json, plan.json, build.py and original process/source/dependency receipts in evidence ZIP'),
    limitations=[
        'These are finite real source-role/state consumers, not whole GLM/DeepSeek/Kimi engines or large-model task-quality certification. Their original initial history and upstream fixtures remain.',
        'DSpark original_state standalone TU was compile-only in this slice. Shared Native/Routed helpers execute in the selected Pro/formal Flash and early-history consumers; this does not certify every standalone runtime variant.',
        'No new throughput, allocation-peak, kernel-count or cross-platform claim. Latest full performance window remains 2026-10-28.',
        'Cross-pump continuation and complete multi-model execution orchestration remain unfinished; ProgramIo reuse does not claim the whole common engine is complete.'
    ],evidence_bundle=pin(bundle))
save(R/'docs/evidence/correctness/inference-program-io-consumers-2026-10-30.json',summary)
print(json.dumps(dict(status=summary['status'],counts=summary['counts'],bundle_bytes=bundle.stat().st_size)))
