from pathlib import Path
import hashlib
import json
import zipfile

W=Path(__file__).resolve().parent;R=W.parents[1]
report=json.loads((W/'cleanup-report.json').read_text(encoding='utf-8-sig'))
assert report['status']=='COMPLETE'
summary_path=R/'docs/evidence/correctness/inference-program-io-consumers-2026-10-30.json'
summary=json.loads(summary_path.read_text())
bundle=Path(summary['evidence_bundle']['path'])
with zipfile.ZipFile(bundle,'a',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    archive.write(W/'cleanup-report.json',str((W/'cleanup-report.json').relative_to(R)).replace('\\','/'))
    archive.write(Path(__file__),str(Path(__file__).relative_to(R)).replace('\\','/'))
summary['cleanup']=dict(files=report['files'],bytes=report['bytes'],status='COMPLETE')
summary['evidence_bundle']=dict(path=str(bundle.resolve()),bytes=bundle.stat().st_size,
    sha256=hashlib.file_digest(bundle.open('rb'),'sha256').hexdigest())
summary_path.write_text(json.dumps(summary,indent=2)+'\n')
print('Final evidence and cleanup receipt:',bundle.stat().st_size,'bytes')
