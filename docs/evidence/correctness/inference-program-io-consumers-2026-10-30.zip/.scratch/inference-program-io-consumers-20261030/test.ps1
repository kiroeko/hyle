﻿param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$TaskRoot = 'C:\public\project-hyle\hyle\.scratch\inference-program-io-consumers-20261030'
$ExpectedRoots = @((Join-Path $TaskRoot 'bin'), (Join-Path $TaskRoot 'compile\ds-early-baseline'))
$Plan = Get-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$AllowedRoots = @($Plan.allowed_roots | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') })
if ($AllowedRoots.Count -ne 2 -or @($AllowedRoots | Where-Object { $_ -notin $ExpectedRoots }).Count) { throw 'Unexpected cleanup roots' }
foreach ($Receipt in Get-ChildItem -LiteralPath $TaskRoot -Filter 'process.json' -File -Recurse) {
    if ((Get-Content -LiteralPath $Receipt.FullName -Raw | ConvertFrom-Json).state -ne 'TERMINAL') { throw "Process still running: $($Receipt.FullName)" }
}
foreach ($Entry in $Plan.files) {
    $TargetPath = [IO.Path]::GetFullPath($Entry.path)
    if ([IO.Path]::GetDirectoryName($TargetPath) -notin $AllowedRoots) { throw "Outside exact cleanup roots: $TargetPath" }
    $Item = Get-Item -LiteralPath $TargetPath
    if ($Item.PSIsContainer -or ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Not an ordinary file: $TargetPath" }
    if ($Item.Length -ne $Entry.bytes -or (Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Entry.sha256) { throw "File identity changed: $TargetPath" }
}
if (-not $Execute) {
    [pscustomobject]@{Files=$Plan.files.Count; Bytes=$Plan.bytes; Roots=$AllowedRoots -join ', '}
    return
}
foreach ($Entry in $Plan.files) { Remove-Item -LiteralPath $Entry.path -Force }
$Report = [pscustomobject]@{status='COMPLETE'; files=$Plan.files.Count; bytes=$Plan.bytes; scope='Only this batch native images/link outputs and disposable baseline object; current consumer/provider objects and 226 original SDK/engine inputs retained.'}
$Report | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $TaskRoot 'cleanup-report.json') -Encoding utf8
$Report
