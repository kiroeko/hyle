from pathlib import Path
import importlib.util
import os
import shutil
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parent
R = W.parents[1]
spec = importlib.util.spec_from_file_location('shared', R / '.scratch/inference-multimodel-observation-20261029/build.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
b.W = b.b.W = W
read, save, pin, exact, key = b.read, b.save, b.pin, b.exact, b.key

def prepare():
    base_path = R / '.scratch/inference-paged-append-cohort-20261029/model-link-base.json'
    base = read(base_path)
    assert len(base['retained']) == 227
    for item in [*base['retained'], base['runtime'], base['sdk_engine_dependencies']]:
        exact(item)
    for unit in read(base['sdk_engine_dependencies']['path'])['engine_consumers']:
        for item in unit['source_identities']:
            exact(item)
    old_source = base['consumer_source']['path']
    old_object = read(base['previous_consumer']['path'])['object']['path']
    definitions = {
        'ds': ['/DHYLE_TEST_DSPARK_STATE_CPU=1', '/DHYLE_TEST_DSPARK_STATE_CUDA=1'],
        'glm': ['/DHYLE_TEST_GLM_STATE_CPU=1', '/DHYLE_TEST_GLM_STATE_CUDA=1'],
        'kimi': ['/DHYLE_TEST_KIMI_STATE_CUDA=1'],
    }
    files = [
        ('runner', 'model_graph_run_test.cc', []),
        ('ds', 'dspark_pro_mtp_state_consumer_test.cc', definitions['ds']),
        ('ds-original', 'dspark_original_state_consumer_test.cc', definitions['ds']),
        ('ds-early', 'dspark_original_early_history_test.cc', definitions['ds']),
        ('glm', 'glm_pro_mtp_state_consumer_test.cc', definitions['glm']),
        ('glm-early', 'glm_pro_original_early_history_test.cc', definitions['glm']),
        ('glm-flash', 'glm_mtp_state_consumer_test.cc', definitions['glm']),
        ('kimi', 'kimi_heterogeneous_state_consumer_test.cc', definitions['kimi']),
        ('carrier', 'carrier.cc', []),
    ]
    units = {}
    for name, file, macros in files:
        folder = W / 'compile' / name
        folder.mkdir(parents=True, exist_ok=True)
        source = W / file if name == 'carrier' else R / 'tests/compute_models' / file
        command = []
        for index, arg in enumerate(base['compile']):
            if index and base['compile'][index-1].lower() == '/sourcedependencies':
                arg = str(folder / 'dependencies.json')
            elif arg.lower().startswith('/fo'):
                arg = '/Fo' + str(folder / 'unit.obj')
            elif arg.lower().startswith('/fd'):
                arg = '/Fd' + str(folder / 'unit.pdb')
            elif key(arg) == key(old_source):
                arg = str(source)
            command.append(arg)
        command += ['/external:I' + str(R / '.scratch/validation/cpu-final-f1/mixed-iq1/source/src'), *macros]
        link = []
        for arg in base['link']:
            if key(arg) == key(old_object):
                arg = str(folder / 'unit.obj')
            for prefix, suffix in [('/OUT:', '.exe'), ('/PDB:', '.pdb'), ('/IMPLIB:', '.lib'), ('/MAP:', '.map')]:
                if arg.upper().startswith(prefix):
                    arg = prefix + str((W / 'bin' / name).with_suffix(suffix))
                    break
            link.append(arg)
        if name != 'carrier':
            for lib in ['gtest_main.lib', 'gtest.lib']:
                path = R / '.scratch/build-compute-v2-dev/lib' / lib
                assert path.is_file()
                if not any(key(arg) == key(path) for arg in link):
                    link.append(str(path))
        assert sum(key(arg) == key(source) for arg in command) == 1
        assert sum(key(arg) == key(folder / 'unit.obj') for arg in link) == 1
        units[name] = dict(source=str(source), compile=command, link=link)
    (W / 'bin').mkdir(exist_ok=True)
    shutil.copyfile(base['runtime']['path'], W / 'bin' / Path(base['runtime']['path']).name)
    previous = read(R / '.scratch/inference-multimodel-observation-20261029/plan.json')
    glm_early = {**previous['glm_environment'], **read(R / '.scratch/inference-system-review-20261025/glm-pro-early-history/attempt7/actual-inputs.json')}
    glm_flash = read(R / '.scratch/glm-random-mtp-20261024/run1-inputs.json')
    glm_flash = {k:v for k,v in glm_flash.items() if k.startswith('HYLE_GLM_')}
    kimi = dict(HYLE_KIMI_ORIGINAL_ATTENTION_DIR=str(R / '.scratch/inference-kimi-original-binding-20261025/payload-only/attempt1'))
    environments = {'ds': previous['ds_environment'], 'glm': previous['glm_environment'], 'glm-early':glm_early,
                    'glm-flash': glm_flash, 'kimi':kimi}
    for env in environments.values():
        for name, value in env.items():
            if name.endswith('_DIR'): assert Path(value).is_dir(), name
    cases = {
        'runner-cpu': dict(unit='runner', filter='ModelGraphRun.*', tests=4),
        'ds-pro-cpu': dict(unit='ds', env='ds', filter='DSparkProOriginalState.CpuNaturalRandomMarkovPrefixAndPendingContinue', tests=1),
        'ds-flash-cpu': dict(unit='ds', env='ds', filter='DSparkFlashFormalState.CpuRandomMarkovPrefixCommitsActualStateAndCursor', tests=1),
        'ds-early-cuda': dict(unit='ds-early', env='ds', filter='DSparkEarlyHistoryPlan.*:DSparkOriginalEarlyHistory.CudaOrdinaryStartFirstCompressionAndWindowWrap', tests=2),
        'glm-cuda': dict(unit='glm', env='glm', filter='GlmProMtpStateConsumer.CudaOriginalTarget77AndNextNRandomVerifierContinuesAtomically', tests=1),
        'glm-early-cuda': dict(unit='glm-early', env='glm-early', filter='GlmProOrdinaryEarlyHistoryPlan.*:GlmProOrdinaryEarlyHistory.*', tests=3),
        'glm-flash-cuda': dict(unit='glm-flash', env='glm-flash', filter='GlmMtpStateConsumer.CudaOriginalTarget43And44AndNextNRandomVerifierContinuesAtomically', tests=1),
        'kimi-cuda': dict(unit='kimi', env='kimi', filter='KimiHeterogeneousState.CudaOriginalParametersKdaMlaKeepCompleteStateAcrossContinuation', tests=1),
        'carrier-cpu': dict(unit='carrier', args=['cpu']),
        'carrier-cuda': dict(unit='carrier', args=['cuda']),
    }
    save(W/'plan.json',dict(base=pin(base_path), units=units, retained=base['retained'], runtime=base['runtime'],
                          sdk=base['sdk_engine_dependencies'], environments=environments, cases=cases))
    print('Prepared 9 current consumer TUs; original 227 SDK/engine link inputs retained; no downloads or SDK rebuild.')

def run(name, attempt):
    plan = read(W/'plan.json'); case = plan['cases'][name]
    b.receipt(case['unit'])
    image = read(W/('ready-'+case['unit']+'.json')); exact(image)
    os.environ.update(plan['environments'].get(case.get('env'), {}))
    folder = W/'runs'/name/attempt
    os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1',
        HYLE_DSPARK_PRO_WAIT_FOR_EXPERTS='0', HYLE_DSPARK_FLASH_WAIT_FOR_EXPERTS='0', HYLE_DSPARK_BFLOAT_WAIT_FOR_EXPERTS='0',
        HYLE_GLM_Q30_WAIT_FOR_EXPERTS='0', HYLE_GLM_MLX_WAIT_FOR_EXPERTS='0', HYLE_GLM_GGUF_FLASH_WAIT_FOR_EXPERTS='0',
        HYLE_DSPARK_PRO_FRONTIER_FILE=str(folder/'missing-pro.json'), HYLE_DSPARK_FLASH_FRONTIER_FILE=str(folder/'missing-flash.json'),
        HYLE_DSPARK_BFLOAT_FRONTIER_FILE=str(folder/'missing-bfloat.json'))
    save(folder/'image.json',image)
    if 'filter' in case:
        b.b.execute([image['path'], '--gtest_color=no','--gtest_filter='+case['filter'],
                     '--gtest_output=xml:'+str(folder/'results.xml')],folder,600)
        result=ET.parse(folder/'results.xml').getroot()
        assert result.get('tests')==str(case['tests']) and result.get('failures')=='0' and result.get('errors','0')=='0'
        assert not result.findall('.//skipped')
        report=dict(status='PASS',tests=case['tests'],failures=0,skipped=0,
                    properties={p.get('name'):p.get('value') for p in result.findall('.//property')})
    else:
        b.b.execute([image['path'],*case['args']],folder,300)
        report=read(folder/'stdout.log'); assert report['status']=='PASS'
    save(folder/'report.json',report)
    print('PASS',name)

if __name__=='__main__':
    if sys.argv[1]=='prepare': prepare()
    elif sys.argv[1]=='run': run(sys.argv[2],sys.argv[3] if len(sys.argv)>3 else 'attempt1')
    else: b.main()
