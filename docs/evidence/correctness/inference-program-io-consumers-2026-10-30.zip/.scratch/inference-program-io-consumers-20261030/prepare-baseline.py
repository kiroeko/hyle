from pathlib import Path
import importlib.util
import subprocess

W=Path(__file__).resolve().parent;R=W.parents[1]
spec=importlib.util.spec_from_file_location('b',W/'build.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
for name in ['dspark_original_early_history_test.cc','dspark_native_consumer.h','model_graph_run.h']:
    path=W/'baseline/tests/compute_models'/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(subprocess.check_output(['git','show','HEAD:tests/compute_models/'+name],cwd=R))
plan=b.read(W/'plan.json');original=plan['units']['ds-early'];source=W/'baseline/tests/compute_models/dspark_original_early_history_test.cc'
folder=W/'compile/ds-early-baseline';folder.mkdir(parents=True,exist_ok=True)
command=[]
for index,arg in enumerate(original['compile']):
    if index and original['compile'][index-1].lower()=='/sourcedependencies':arg=str(folder/'dependencies.json')
    elif arg.lower().startswith('/fo'):arg='/Fo'+str(folder/'unit.obj')
    elif arg.lower().startswith('/fd'):arg='/Fd'+str(folder/'unit.pdb')
    elif b.key(arg)==b.key(original['source']):arg=str(source)
    command.append(arg)
link=[]
for arg in original['link']:
    if b.key(arg)==b.key(W/'compile/ds-early/unit.obj'):arg=str(folder/'unit.obj')
    for prefix,suffix in [('/OUT:','.exe'),('/PDB:','.pdb'),('/IMPLIB:','.lib'),('/MAP:','.map')]:
        if arg.upper().startswith(prefix):arg=prefix+str((W/'bin/ds-early-baseline').with_suffix(suffix));break
    link.append(arg)
plan['units']['ds-early-baseline']=dict(source=str(source),compile=command,link=link)
plan['cases']['ds-early-baseline-cuda']={**plan['cases']['ds-early-cuda'],'unit':'ds-early-baseline'}
b.save(W/'plan.json',plan)
print('Prepared exact HEAD consumer/runner/native headers with identical current SDK and runtime inputs; no product source changed.')
