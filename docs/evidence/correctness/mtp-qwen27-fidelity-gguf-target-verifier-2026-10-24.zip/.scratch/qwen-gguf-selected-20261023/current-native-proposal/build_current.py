"""B04/B07 cold adapters to the existing Qwen one-TU lifecycle.

The pinned flat MMQ closure supplies actual product records and no model TU.
One new Qwen consumer object is appended; no retired/dummy TU is substituted.
The existing one-TU compiler and owned process runner remain in use.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
G = S.parent
R = G.parents[1]
LIFECYCLE = R / '.scratch/qwen-bfloat-selected-20261023/derived/native_build_current.py'
LIFECYCLE_SHA = 'fc0bea30eabdf82286447fe29549bcf430204958c886007fb0963237ce764eb8'
CLOSURE = R / '.scratch/mtp-packed-head-20261024/orin-proposal/mmq-query-proposal/current_closure.py'
CLOSURE_SHA = '3749aa7a5767faad27653b133aad83994a13126db2b4cd17ea4452780f4a973d'
SUFFIX = 'FidelityOriginalTargetAndNextNFullVocabularyVerifierPublishesRepairedPrefix'


def identity(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def load(name, path, pin=None):
    if pin is not None and identity(path)['sha256'] != pin:
        raise ValueError('Frozen helper changed: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


class Adapter:
    def __init__(self, tag):
        self.ARTIFACT_TAG = tag
        self.DATA = self.Q01 = G / tag  # Q01 is the existing lifecycle's data-root field.
        self.S = self.DATA / 'native-current'
        self.HEADER = self.DATA / 'generated' / ('qwen_gguf_' + tag.lower() + '_artifacts.h')
        self.MACRO = '/DHYLE_TEST_QWEN_' + tag + '_ARTIFACTS_HEADER='
        self.EXPECTED_ROLES = 29 if tag == 'B04' else 33
        self.EXPECTED_BYTES = 4927328256 if tag == 'B04' else 5497491456
        self.ENVIRONMENT = 'HYLE_QWEN27_FIDELITY_DIR' if tag == 'B04' else 'HYLE_QWEN24_FIDELITY_DIR'
        self.CASES = {x: 'QwenMtpStateConsumer.' + x.title() + ('Q27' if tag == 'B04' else 'Q24') + SUFFIX for x in ('cpu', 'cuda')}
        self.GENERATOR = self.DATA / ('generate_artifacts.py' if tag == 'B04' else 'tooling-proposal/generate_artifacts.py')

    def schema(self):
        path = self.DATA / ('prepare_loose_plan.py' if self.ARTIFACT_TAG == 'B04' else 'tooling-proposal/prepare_plans.py')
        module = load('_gguf_actual_schema', path)
        plan_path, plan = module.checked_plan() if self.ARTIFACT_TAG == 'B04' else module.checked_plan('static')
        if len(plan['roles']) != self.EXPECTED_ROLES or sum(x['bytes'] for x in plan['roles']) != self.EXPECTED_BYTES:
            raise ValueError('Actual original static extent differs')
        return module, plan_path, plan

    def artifacts(self, header):
        if Path(header).resolve() != self.HEADER.resolve() or not self.HEADER.is_file():
            raise RuntimeError(self.ARTIFACT_TAG + ' requires its completed real generated pin header')
        generator = load('_gguf_actual_pin_generator', self.GENERATOR)
        paths = [self.HEADER, self.HEADER.with_suffix('.json'), self.GENERATOR,
                 self.DATA / 'original-roles/acquisition.json', self.DATA / 'original-roles/manifest.json', self.DATA / 'loose-plan.json']
        if self.ARTIFACT_TAG == 'B04':
            plan, pins, receipt, manifest = generator.checked_metadata()
            expected = generator.header(plan, pins, receipt, manifest)
            paths += [self.DATA / 'header.json', self.DATA / 'original-header.bin']
        else:
            schema = generator.schema()
            plan, pins, experts, facts = generator.checked_metadata(schema)
            expected = generator.header(schema, plan, pins, experts, facts)
            paths += [self.DATA / 'expert-source-plan.json']
        if self.HEADER.read_text(encoding='utf-8-sig') != expected:
            raise ValueError('Generated pins differ from the complete real acquisition')
        return [identity(path) for path in paths]


def context(args):
    if not args.closure_helper or not args.closure_sha:
        raise RuntimeError('Supply the new actual MMQ closure helper and its SHA; old parity is not a default')
    helper = load('_gguf_actual_current_closure', args.closure_helper, args.closure_sha)
    base = helper.closure()
    if len(base) != 5 or base[3] is not None or not base[0].get('append_consumer'):
        raise ValueError('Require actual flat closure without a model consumer')
    core = load('_gguf_compiler_utility_owner', LIFECYCLE, LIFECYCLE_SHA)
    c = load('_gguf_existing_compiler_utility', core.SHARED, core.SHARED_SHA)
    # Reuse the existing host compiler utility; never call its historical closure.
    c.native_inputs = helper.native_inputs
    c.retained_record = helper.check_record
    return c, base


def link(adapter, args):
    actual = adapter.artifacts(adapter.HEADER)
    c, (plan, base_ready, runtime_path, _, paths) = context(args)
    fresh_path = adapter.S / f'compile{args.compile_attempt}/qwen-state/identity.json'
    fresh = c.check_record(fresh_path)
    if fresh['artifact_inputs'] != actual or fresh['artifact'] != adapter.ARTIFACT_TAG:
        raise ValueError('Compiled original artifact inputs changed')
    command = [arg for arg in plan['command'] if not arg.upper().startswith(('/OUT:', '/MAP:', '/IMPLIB:', '/PDB:'))]
    fresh_object = str(c.resolve(fresh['object']['path'])).lower()
    if any(arg.lower().endswith('.obj') and str(c.resolve(arg)).lower() == fresh_object for arg in command):
        raise ValueError('New consumer must not already occur in the product closure')
    command.append(fresh['object']['path'])
    objects = {str(c.resolve(arg)).lower() for arg in command if arg.lower().endswith('.obj')}
    native = c.native_inputs(); known = {fresh_object}; checked = []
    for row in native:
        value = str(c.resolve(row['object']['path'])).lower()
        if sum(arg.lower().endswith('.obj') and str(c.resolve(arg)).lower() == value for arg in command) != 1:
            raise ValueError('Each actual native object must occur exactly once')
        known.add(value)
    for row in plan['retained_inputs']:
        c.require(row); known.add(str(c.resolve(row['path'])).lower())
    for path in paths:
        record = c.read(path)
        value = str(c.resolve(record['object']['path'])).lower()
        if value in objects:
            c.retained_record(path); checked.append(c.identity(path)); known.add(value)
    if not objects <= known: raise ValueError('Unaccounted actual product object: ' + repr(objects - known))
    out = adapter.S / f'tests-link{args.attempt}'; out.mkdir(exist_ok=False); (out / 'tmp').mkdir()
    image = out / 'qwen-gguf-checks.exe'
    command += ['/OUT:' + str(image), '/MAP:' + str(image.with_suffix('.map')), '/IMPLIB:' + str(image.with_suffix('.lib'))]
    c.save(out / 'link-plan.json', dict(command=command, base=plan['actual_flat_link'],
        base_image=base_ready['image'], closure_helper=identity(args.closure_helper),
        consumer_record=c.identity(fresh_path), retained_current_records=checked,
        retained_inputs=plan['retained_inputs'], native_inputs=plan['native_inputs'],
        retained_native_objects=[row['object'] for row in native], removed_focused_test_records=plan['removed_focused_test_records'],
        append_consumer=True, actual_artifact_inputs=actual, entry=identity(args.entry), shared_helper=identity(__file__),
        consumer_translation_units=1, product_translation_units=0, SDK_builds=0, NVCC_builds=0))
    h = c.helpers(); env, _ = h.b.environment(command, [], out); h.c.execute('link', command, env, out)
    runtime = c.read(runtime_path); old_directory = str(Path(base_ready['image']['path']).parent)
    for row in runtime['staged_dlls']:
        c.require(row); source = c.resolve(row['path']); os.link(source, out / source.name)
    runtime['PATH'] = str(out) + os.pathsep + runtime['PATH'].replace(old_directory, str(out))
    runtime['previous_matched_HC_PRE_worker'] = runtime.get('matched_HC_PRE_worker')
    runtime.update(previous=c.identity(runtime_path), staged_dlls=[c.identity(path) for path in out.glob('*.dll')])
    runtime['matched_HC_PRE_worker'] = runtime['staged_dlls'][0]
    c.save(out / 'runtime-environment.json', runtime)
    c.save(out / 'ready.json', dict(image=c.identity(image), link_plan=c.identity(out / 'link-plan.json'),
        runtime_environment=c.identity(out / 'runtime-environment.json'), consumer_record=c.identity(fresh_path),
        artifact=adapter.ARTIFACT_TAG, actual_artifact_inputs=actual))


def facts(adapter, args):
    schema, plan_path, plan = adapter.schema()
    actual = adapter.artifacts(adapter.HEADER) if adapter.HEADER.is_file() else None
    result = dict(prepared_only=True, entry=identity(args.entry), shared_helper=identity(__file__),
        lifecycle=identity(LIFECYCLE), closure_helper=None if not args.closure_helper else identity(args.closure_helper),
        closure_required=True, old_parity_closure_allowed=False, source=identity(R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc'),
        original_range_plan=identity(plan_path), repository=plan['repository'], revision=plan['revision'],
        static_roles=len(plan['roles']), static_bytes=sum(x['bytes'] for x in plan['roles']),
        dtype_counts={dtype: sum(x['dtype'] == dtype for x in plan['roles']) for dtype in sorted({x['dtype'] for x in plan['roles']})},
        cases=adapter.CASES, macro=adapter.MACRO, generated_header=str(adapter.HEADER),
        environment={adapter.ENVIRONMENT: str(adapter.DATA / 'original-roles')},
        actual_artifact_inputs=actual, blocked_pending_actual_body_pins=actual is None,
        required_consumer_TUs=1, product_TUs=0, SDK_builds=0, NVCC_builds=0, HTTP=0,
        validation='Own static source/receipts plus same K1, fullV, repair, state/budget properties; no Q09/Q10 seven-recipe assumptions.')
    if adapter.ARTIFACT_TAG == 'B07':
        expert_path, experts = schema.checked_plan('experts')
        result.update(expert_plan=identity(expert_path), expert_domain=512, resident_experts=10,
            sections=['nextn', 'target91'], per_ID_legs=3, per_ID_bytes=53477376,
            whole_expert_banks_allowed=False,
            expert_environment={'HYLE_QWEN_GGUF_24_EXPERT_DIR': str(adapter.DATA / 'original-experts')},
            owned_driver=identity(adapter.DATA / 'tooling-proposal/run_with_supply.py'),
            selected_supply=identity(adapter.DATA / 'tooling-proposal/supply_experts.py'))
    return result


def run(adapter, args):
    actual = adapter.artifacts(adapter.HEADER)
    c, _ = context(args)
    folder = adapter.S / f'tests-link{args.link_attempt}'
    ready = c.read(folder / 'ready.json')
    if ready['artifact'] != adapter.ARTIFACT_TAG or ready['actual_artifact_inputs'] != actual:
        raise ValueError('Compiled own original identity/pins differ')
    for key in ('image', 'link_plan', 'runtime_environment', 'consumer_record'): c.require(ready[key])
    c.check_record(c.resolve(ready['consumer_record']['path']))
    runtime = c.read(folder / 'runtime-environment.json')
    for item in runtime['staged_dlls']: c.require(item)
    out = adapter.S / f'checks{args.attempt}-{args.backend}'; out.mkdir(exist_ok=False)
    native = [ready['image']['path'], '--gtest_filter=' + adapter.CASES[args.backend],
              '--gtest_throw_on_failure=1', '--gtest_output=xml:' + str(out / 'results.xml')]
    env = {key: value for key, value in os.environ.items() if not key.startswith('HYLE_QWEN')}
    env.update(PATH=runtime['PATH'], **{adapter.ENVIRONMENT: str(adapter.DATA / 'original-roles')})
    command, driver = native, None
    if adapter.ARTIFACT_TAG == 'B07':
        env.update(HYLE_QWEN_GGUF_24_EXPERT_DIR=str(adapter.DATA / 'original-experts'),
            HYLE_QWEN_GGUF_24_EXPERT_REQUEST_FILE=str(out / 'frontier.json'), HYLE_QWEN_GGUF_24_WAIT_FOR_EXPERTS='0')
        if args.supply:
            env['HYLE_QWEN_GGUF_24_WAIT_FOR_EXPERTS'] = '1'
            driver = adapter.DATA / 'tooling-proposal/run_with_supply.py'
            command = [sys.executable, str(driver), '--image', native[0], '--frontier-file', str(out / 'frontier.json'), '--', *native[1:]]
    elif args.supply:
        raise ValueError('B04 is dense and has no expert supply hook')
    c.save(out / 'plan.json', dict(command=command, native_command=native, image=ready['image'],
        consumer_record=ready['consumer_record'], artifacts=actual, entry=identity(args.entry),
        shared_helper=identity(__file__), closure_helper=identity(args.closure_helper),
        environment={k: v for k, v in env.items() if k == 'PATH' or k.startswith('HYLE_QWEN')},
        driver=None if driver is None else identity(driver), cached_only=driver is None, automatic_supply=driver is not None))
    q = load('_gguf_existing_process_runner', R / '.scratch/qwen-mtp-quality-20261022/run_quality.py')
    process = q.execute(command, env, out / 'run', timeout=args.timeout)
    result = dict(process=process, passed=False, image=ready['image'], consumer_record=ready['consumer_record'],
        artifacts=actual, cached_only=driver is None, automatic_supply=driver is not None,
        scope='Own original GGUF target/draft/vocabulary; finite upstream/history fixtures, no full-model quality/TPS claim.')
    try:
        if process['exit'] or process['timed_out']: raise RuntimeError('Actual native/owned supply failed')
        tree = ET.parse(out / 'results.xml').getroot(); nodes = list(tree.iter('testcase'))
        if len(nodes) != 1 or list(tree.iter('skipped')) or list(tree.iter('failure')) or any(int(tree.get(k, '0')) for k in ('failures', 'errors', 'disabled')):
            raise ValueError('Require exactly one actual passing case, zero skip/failure')
        node = nodes[0]
        if node.get('classname') + '.' + node.get('name') != adapter.CASES[args.backend] or node.get('status') != 'run' or node.get('result') != 'completed':
            raise ValueError('Wrong or unexecuted case')
        props = {x.get('name'): x.get('value') for x in node.iter('property')}
        expected = dict(original_source_roles=str(adapter.EXPECTED_ROLES), original_source_bytes=str(adapter.EXPECTED_BYTES),
            original_manifest_sha256=identity(adapter.DATA / 'original-roles/manifest.json')['sha256'],
            original_acquisition_sha256=identity(adapter.DATA / 'original-roles/acquisition.json')['sha256'],
            target_verifier_full_vocabulary='248320', target_verifier_rows='2', target_verifier_matmuls='1', complete_target_draft_resources='12')
        if any(props.get(k) != value for k, value in expected.items()): raise ValueError('Actual own-source/K1/fullV fields differ')
        for key in ('actual_submissions', 'accepted_target_conditioned_repairs', 'actual_accepted_kv_repair_submissions',
                    'accepted_zero_drafts', 'accepted_one_draft', 'whole_state_publications', 'cancelled_unpublished_drafts', 'rejected_stale_publishes'):
            if int(props[key]) <= 0: raise ValueError('Missing actual complete-prefix behavior: ' + key)
        if int(props['peak_state_backing_bytes']) > int(props['state_budget_bytes']): raise ValueError('Actual state budget exceeded')
        if adapter.ARTIFACT_TAG == 'B07':
            if props['target_expert_domain'] != '512' or props['target_resident_capacity'] != '10' or any(props[k].lower() != 'q8_0' for k in ('target_expert_source_codec', 'nextn_expert_source_codec')):
                raise ValueError('Actual selected Q8 expert contract differs')
        if driver is not None:
            owned = c.read(out / 'frontier.driver.json')
            if owned['native']['exit'] or owned['native']['stopped_by_driver'] or owned['job_cleanup']['remaining_descendants'] or any(row['exit'] or row.get('stopped_by_driver', False) for row in owned['fetches']):
                raise ValueError('Owned native/supply descendants did not finish successfully')
            result['driver'] = identity(out / 'frontier.driver.json')
        result.update(passed=True, case=adapter.CASES[args.backend], tests=1, failures=0, skips=0,
                      properties=props, actual_graph_submissions=int(props['actual_submissions']))
    except Exception as error:
        result['error'] = dict(type=type(error).__name__, message=str(error))
    c.save(out / 'summary.json', result)
    if not result['passed']: raise SystemExit(process['exit'] or 1)


def main(tag, entry):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('plan', 'compile', 'link', 'run'))
    parser.add_argument('--attempt', type=int, required=True)
    parser.add_argument('--compile-attempt', type=int, default=1)
    parser.add_argument('--link-attempt', type=int, default=1)
    parser.add_argument('--backend', choices=('cpu', 'cuda'), default='cpu')
    parser.add_argument('--closure-helper', type=Path, default=CLOSURE)
    parser.add_argument('--closure-sha', default=CLOSURE_SHA)
    parser.add_argument('--supply', action='store_true', help='B07 only: explicit existing owned frontier supplier')
    parser.add_argument('--timeout', type=int, default=14400)
    args = parser.parse_args(); args.entry = Path(entry)
    if min(args.attempt, args.compile_attempt, args.link_attempt, args.timeout) <= 0: raise ValueError('Positive attempts/timeouts required')
    adapter = Adapter(tag)
    core = load('_gguf_existing_current_lifecycle', LIFECYCLE, LIFECYCLE_SHA)
    core.closure = lambda: context(args)  # The only current-closure connection.
    if args.action == 'plan':
        print(json.dumps(facts(adapter, args), indent=2)); return 0
    if args.action == 'compile':
        core.compile_one(adapter, args.entry, args.attempt)
        path = adapter.S / f'compile{args.attempt}/qwen-state/identity.json'
        record = json.loads(path.read_text(encoding='utf-8-sig'))
        record.update(cold_adapter=identity(__file__), closure_helper=identity(args.closure_helper), append_consumer=True)
        path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
    elif args.action == 'link': link(adapter, args)
    else: run(adapter, args)
    return 0
