"""Root-only optional body entry after B04 headers/plans authenticate.

Reuse the existing bounded/resumable downloader. No networking on import.
Do not run while the user/root acquisition pause is active.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group', choices=('draft', 'target', 'vocabulary', 'all'), required=True)
    args = parser.parse_args()
    path = S / f'{args.group}-plan.json'
    plan = json.loads(path.read_text(encoding='utf-8-sig'))
    assert (plan['repository'], plan['revision'], plan['file']) == (
        'unsloth/Qwen3.8-27B-GGUF', '4ca720788d1e01f1bff70c033e0d0028fd02e502', 'Qwen3.8-27B-UD-Q8_K_XL.gguf')
    source = R / '.scratch/dspark-pro-target-draft-20261023/fetch_dense.py'
    spec = importlib.util.spec_from_file_location('b04_existing_dense_downloader', source)
    common = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(common)
    common.COUNT, common.BODY_BYTES = plan['original_roles'], plan['bundle_bytes']
    common.WORKERS = 3
    common.main(path, S / f'original-{args.group}')


if __name__ == '__main__':
    main()
