"""Publish B04 only after its actual current CPU and CUDA cases both pass.

Reads the existing one-TU lifecycle records. No build, inference, network,
weight-body hashing, scope update, or replacement of an earlier proof.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
import zipfile

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
A = S.parent
G = A.parent
R = G.parents[1]
D = R / 'docs/evidence/correctness'
NAME = 'mtp-qwen27-fidelity-gguf-target-verifier-2026-10-24'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


tools = module('_b04_existing_small_archive', R / '.scratch/glm-quark-selected-20261024/Q30/publish.py')
read, resolve, identity, require = tools.read, tools.resolve, tools.identity, tools.require


def integer(properties, key, minimum=0):
    value = int(properties[key])
    if value < minimum:
        raise ValueError('Invalid actual property: ' + key)
    return value


def collect_build(ready, actual_inputs, archive):
    for key in ('link_plan', 'consumer_record', 'runtime_environment'):
        require(ready[key]); archive.add(ready[key]['path'])
    link = read(ready['link_plan']['path'])
    record_path = resolve(ready['consumer_record']['path'])
    record = read(record_path)
    if (ready['artifact'] != 'B04' or record['artifact'] != 'B04' or
            ready['actual_artifact_inputs'] != actual_inputs or record['artifact_inputs'] != actual_inputs or
            link['consumer_record'] != ready['consumer_record'] or link['actual_artifact_inputs'] != actual_inputs):
        raise ValueError('The actual compiled/link artifact input closure differs')
    if (link['append_consumer'] is not True or link['consumer_translation_units'] != 1 or
            any(link[key] != 0 for key in ('product_translation_units', 'SDK_builds', 'NVCC_builds'))):
        raise ValueError('Expected one fresh consumer on the actual retained flat product closure')
    if resolve(record['source']['path']) != R / 'tests/compute_models/qwen_mtp_state_consumer_test.cc':
        raise ValueError('Unexpected consumer source')
    image = resolve(ready['image']['path'])
    obj = str(resolve(record['object']['path'])).lower()
    command = link['command']
    if (sum(arg.lower().endswith('.obj') and str(resolve(arg)).lower() == obj for arg in command) != 1 or
            sum(arg.upper().startswith('/OUT:') and resolve(arg[5:]) == image for arg in command) != 1):
        raise ValueError('Actual link must append the consumer once and produce the executed image')
    # Preserve the actual consumer/model source, not a second full provider/SDK tree.
    archive.source(record['source'], record_path)
    for info in record['dependencies']:
        path = resolve(info['path'])
        if path.is_relative_to(R / 'tests/compute_models'):
            archive.source(info, record_path)
    for directory, prefix in ((record_path.parent, 'compile'), (image.parent, 'link')):
        for name in ('plan.json', prefix + '.command.json', prefix + '.result.json',
                     prefix + '.stdout.log', prefix + '.stderr.log'):
            path = directory / name
            if path.is_file(): archive.add(path)
    for info in (link['entry'], link['shared_helper'], link['closure_helper']):
        require(info); archive.add(info['path'])
    compile_result = read(record_path.parent / 'compile.result.json')
    link_result = read(image.parent / 'link.result.json')
    if compile_result['exit'] != 0 or link_result['exit'] != 0:
        raise ValueError('Actual compile/link did not complete successfully')
    runtime = read(ready['runtime_environment']['path'])
    for row in runtime['staged_dlls']:
        if resolve(row['path']).stat().st_size != row['bytes']:
            raise ValueError('Actual staged runtime extent differs')
    return dict(consumer_record=ready['consumer_record'], link_plan=ready['link_plan'],
        runtime=ready['runtime_environment'], image=ready['image'],
        native_inputs=link['native_inputs'], retained_native_objects=link['retained_native_objects'],
        retained_host_records=len(link['retained_current_records']),
        consumer_TUs=1, product_TUs=0, SDK_builds=0, NVCC_builds=0)


def completed_run(backend, attempt, adapter, inputs, plan, manifest, archive):
    folder = S / f'checks{attempt}-{backend}'
    summary, run_plan = read(folder / 'summary.json'), read(folder / 'plan.json')
    process = read(folder / 'run/process.json')
    if (not summary['passed'] or process['exit'] != 0 or process['timed_out'] is not False or
            summary['process'] != process or process['command'] != run_plan['command'] or
            run_plan['command'] != run_plan['native_command'] or run_plan['driver'] is not None or
            run_plan['automatic_supply'] is not False):
        raise ValueError('Require a completed successful dense native process, without a supplier')
    if (run_plan['artifacts'] != inputs or summary['artifacts'] != inputs or
            run_plan['image'] != summary['image'] or
            run_plan['consumer_record'] != summary['consumer_record']):
        raise ValueError('Run source/image inputs differ from their actual records')
    environment = run_plan['environment']
    selected = {key: value for key, value in environment.items() if key.startswith('HYLE_QWEN')}
    if set(selected) != {adapter.ENVIRONMENT} or resolve(selected[adapter.ENVIRONMENT]) != A / 'original-roles':
        raise ValueError('Run must select only its own B04 original role directory')
    expected_case = adapter.CASES[backend]
    if '--gtest_filter=' + expected_case not in process['command']:
        raise ValueError('Actual native case filter differs')
    tree = ET.parse(folder / 'results.xml').getroot()
    cases = list(tree.iter('testcase'))
    if (len(cases) != 1 or any(list(tree.iter(name)) for name in ('failure', 'error', 'skipped')) or
            any(int(tree.get(key, '0')) for key in ('failures', 'errors', 'disabled'))):
        raise ValueError('Require exactly one actual passing case, zero failure/error/skip')
    case = cases[0]
    if (case.get('classname') + '.' + case.get('name') != expected_case or
            case.get('status') != 'run' or case.get('result') != 'completed' or
            summary['case'] != expected_case or
            (summary['tests'], summary['failures'], summary['skips']) != (1, 0, 0)):
        raise ValueError('Actual CPU/CUDA case identity differs')
    properties = {row.get('name'): row.get('value') for row in case.iter('property')}
    if properties != summary['properties']:
        raise ValueError('Actual XML and summary properties differ')
    expected = dict(original_source_roles='29', original_source_bytes=str(plan['source_bytes']),
        original_artifact=plan['file'], original_manifest_sha256=manifest['sha256'],
        original_acquisition_sha256=identity(A / 'original-roles/acquisition.json')['sha256'],
        original_header_sha256=plan['shards'][0]['header']['sha256'],
        original_target_roles='12', target_verifier_full_vocabulary='248320',
        target_verifier_rows='2', target_verifier_matmuls='1', complete_target_draft_resources='12')
    if any(properties.get(key) != value for key, value in expected.items()):
        raise ValueError('Actual own-source/K1/full-vocabulary contract differs')
    for key in ('accepted_target_conditioned_repairs', 'actual_accepted_kv_repair_submissions',
                'accepted_zero_drafts', 'accepted_one_draft', 'actual_pending_embedding_feedback_checks',
                'whole_state_publications', 'cancelled_unpublished_drafts', 'rejected_stale_publishes',
                'controlled_matching_trials', 'controlled_rejection_trials',
                'first_full_target_projection_values', 'first_full_target_verifier_values',
                'first_full_nextn_head_values'):
        integer(properties, key, 1)
    if (integer(properties, 'natural_k1_trials') != 1 or integer(properties, 'natural_accepted_drafts') not in (0, 1) or
            integer(properties, 'peak_state_backing_bytes') > integer(properties, 'state_budget_bytes')):
        raise ValueError('Natural trial/state-budget scope differs')
    graphs = integer(properties, 'actual_submissions', 1)
    if (graphs != summary['actual_graph_submissions'] or
            graphs != sum(integer(properties, key, 1) for key in ('target_submissions', 'nextn_submissions', 'target_verifier_submissions'))):
        raise ValueError('Actual Graph counters differ')
    image = resolve(run_plan['image']['path'])
    ready_path = image.parent / 'ready.json'
    ready = read(ready_path)
    if (image.stat().st_size != run_plan['image']['bytes'] or ready['image'] != run_plan['image'] or
            ready['consumer_record'] != run_plan['consumer_record'] or resolve(process['command'][0]) != image):
        raise ValueError('Actual image/consumer identity differs')
    archive.metadata_tree(folder)
    archive.add(ready_path)
    build = collect_build(ready, inputs, archive)
    return dict(backend=backend.upper(), case=expected_case, tests=1, failures=0, skips=0,
        graph_submissions=graphs, properties=properties, build=build,
        summary=identity(folder / 'summary.json'), XML=identity(folder / 'results.xml'),
        process=identity(folder / 'run/process.json'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cpu-attempt', type=int, required=True)
    parser.add_argument('--cuda-attempt', type=int, required=True)
    parser.add_argument('--source-root', type=Path, action='append', default=[],
        help='Optional exact compiled-source snapshots when current model headers have changed')
    args = parser.parse_args()
    if min(args.cpu_attempt, args.cuda_attempt) <= 0:
        raise ValueError('Positive actual run attempts are required')
    output, zip_path = D / (NAME + '.json'), D / (NAME + '.zip')
    if output.exists() or zip_path.exists():
        raise ValueError('Do not overwrite old evidence')
    common = module('_b04_actual_current_adapter', G / 'current-native-proposal/build_current.py')
    adapter = common.Adapter('B04')
    # Existing generator authenticates ranges, complete receipts, shape, names,
    # SHA pins and file extents; it never rehashes GB weight bodies here.
    inputs = adapter.artifacts(adapter.HEADER)
    generator = module('_b04_completed_pin_reader', adapter.GENERATOR)
    plan, roles, acquisition, manifest = generator.checked_metadata()
    archive = tools.Archive([path.resolve() for path in args.source_root])
    executions = [completed_run(backend, attempt, adapter, inputs, plan, manifest, archive)
        for backend, attempt in (('cpu', args.cpu_attempt), ('cuda', args.cuda_attempt))]
    acquisition_run = R / '.scratch/mtp-download-budget-20261023/static-umbrella-20261024/batches/attempt1/children/B04'
    actual_child = read(acquisition_run / 'summary.json')
    if actual_child['passed'] is not True or any(row['process']['exit'] != 0 or row['process']['timed_out'] for row in actual_child['steps']):
        raise ValueError('The selected original acquisition child has not actually succeeded')
    archive.metadata_tree(acquisition_run)
    archive.metadata_tree(S / 'pins-generation1')
    archive.add(__file__)
    for item in inputs:
        if resolve(item['path']).name != 'original-header.bin': archive.add(item['path'])
    for name in ('prepare_loose_plan.py', 'fetch_roles.py', 'fetch_loose_roles.py', 'fetch_headers.py', 'header.json'):
        archive.add(A / name)
    shared = [identity(D / name) for name in
        ('mtp-packed-mmq-workspace-2026-10-24.json', 'mtp-cpu-native-family-2026-10-24.json')]
    if any(path.stat().st_size > 2 * 1024 * 1024 for path in archive.files.values()):
        raise ValueError('Archive only small source/commands/logs/receipt metadata')
    with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED) as target:
        for name, path in sorted(archive.files.items()): target.write(path, name)
    result = dict(created_at=datetime.now(timezone.utc).isoformat(), status='passed',
        identity=dict(id='B04', repository=plan['repository'], revision=plan['revision'],
            file=plan['file'], variant='UD-Q8_K_XL'),
        scope='Original target63, NextN64 and own Q8_0 embedding/BF16 full head; shared K1/12-resource StateHead with finite upstream/history fixtures.',
        original_roles=29, original_bytes=plan['source_bytes'],
        original_parameters=dict(acquisition=acquisition, manifest=manifest,
            acquisition_execution=identity(acquisition_run / 'summary.json'),
            pin_generation=identity(S / 'pins-generation1/process.json'),
            plan=identity(A / 'loose-plan.json'), generated_pins=identity(adapter.HEADER),
            roles=[dict(name=row['name'], codec=row['dtype'], shape=row['shape'], bytes=row['bytes'],
                sha256=roles[row['name']]['sha256']) for row in plan['roles']], body_rehashed=False,
            header=plan['shards'][0]['header'], etag=plan['shards'][0]['etag'],
            etag_meaning='HTTP object identity; no whole-file SHA or LFS SHA inferred'),
        executions=executions, actual_Graph_submissions=sum(run['graph_submissions'] for run in executions),
        shared_product_evidence=shared, compiled_consumer_sources=list(archive.sources.values()),
        limitations=['Finite layer62 input/history fixtures do not execute the preceding trained trunk or full model.',
            'The one natural trial remains separate from controlled match/rejection and is not an acceptance-rate result.',
            'Per-role original codec, actual provider choices and mathematical observations are retained in each XML; no cross-provider bit identity is inferred.',
            'No TPS, task-quality, physical-memory peak or new platform/device claim.'],
        throughput_evidence=False, memory_evidence=False, whole_model_quality=False,
        files=[dict(archive_path=name, **identity(path)) for name, path in sorted(archive.files.items())],
        archive=identity(zip_path))
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps(dict(evidence=identity(output), archive=identity(zip_path),
        graphs=result['actual_Graph_submissions']), ensure_ascii=False))


if __name__ == '__main__':
    main()
