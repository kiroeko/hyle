#pragma once

#include <array>
#include <cstdint>
#include <string_view>
#include "qwen27_original_nextn_roles.h"
#include "d5_qwen38_gdn_fixture.h"

// Pins generated only from the completed fixed-revision loose acquisition.
// Raw GGUF BF16/F32/Q8_0 bytes; no repack, fallback or duplicate vocabulary.
namespace qwen_gguf_original_artifacts::b04 {
namespace roles=qwen27_original_nextn_roles;
namespace c=hyle::compute;
inline constexpr qwen_original_mtp_roles::Identity kIdentity{
    "unsloth/Qwen3.8-27B-GGUF","4ca720788d1e01f1bff70c033e0d0028fd02e502","UD-Q8_K_XL","Qwen3.8-27B-UD-Q8_K_XL.gguf"};
inline constexpr auto &kProfile=d5_qwen38_gdn_fixture::kFidelityGgufProfile;
inline constexpr std::uint64_t kOriginalBytes=4927328256ULL;
inline constexpr std::string_view kReceiptSha256="90663645083db496aff6d48f77e5a4ae0d38ef2d73564ac0c3e78f7b9dbf4c4c";
inline constexpr std::string_view kManifestSha256="ac329c17dc17653f6ba61fecd944e50852212fd65f4465a414f86f04cf442098";
inline constexpr std::string_view kHeaderSha256="a44332a12bc9a8bf7417a263629f38ead21f6b85c07f485d477f3a2435b58905";
inline constexpr std::string_view kPlanSha256="2021cea6b5ae43ec04768812efaa0b77a5a7555f5b7b9fcc2878009b673cf156";
inline std::array<roles::ManifestSpec,29> manifest() {
  return {{
    {"output.weight","output.weight.bin","d922b751f014ee1139488cb94c0e164a1eb3da5c14048070ed1b784e00f92723",GGML_TYPE_BF16,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{248320,5120}),"B04 original plain role")},
    {"output_norm.weight","output_norm.weight.bin","b3ba4f3231a21b1559f52115d3bffc7c28dcd03e4be22df269ef97a3f5d4bfbf",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"token_embd.weight","token_embd.weight.bin","b755d0b974c318092e3f80dfd8d857b86f3778d2ebe0c58258912018a17ce889",GGML_TYPE_Q8_0,roles::original::detail::take((roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,5120,248320),"B04 original Q8_0 RHS")).transposed(),"B04 original Q8_0 Gather rows")},
    {"blk.63.attn_k.weight","blk.63.attn_k.weight.bin","80f1eff496440c0f23001bfc0e9548715172bb9c895dbc6e7b3f9f6f13e23011",GGML_TYPE_BF16,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{1024,5120}),"B04 original plain role")},
    {"blk.63.attn_k_norm.weight","blk.63.attn_k_norm.weight.bin","dd2837b022e7bb5f24223f7937c377658d72258baf44072def2bff47fbf5c039",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{256}),"B04 original plain role")},
    {"blk.63.attn_norm.weight","blk.63.attn_norm.weight.bin","fff0b300a720e0626a1b5982729a66769cfcb796f9cfbfe2e02293a7e448b073",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.63.attn_output.weight","blk.63.attn_output.weight.bin","a586c855fc0a242d8eb11c97c3f666eb93b13e3b0818de43bba283c4dd16339c",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,6144,5120),"B04 original Q8_0 RHS")},
    {"blk.63.attn_q.weight","blk.63.attn_q.weight.bin","244299e7cbfe6fbec4bb845bc308142fb802c6e4542a0bbc46fdf930487c6206",GGML_TYPE_BF16,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{12288,5120}),"B04 original plain role")},
    {"blk.63.attn_q_norm.weight","blk.63.attn_q_norm.weight.bin","4d82f12e9d3e60003032eee0c0a413b85588b9253ba3bfe43456eed32a91960c",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{256}),"B04 original plain role")},
    {"blk.63.attn_v.weight","blk.63.attn_v.weight.bin","0a2b4e4a3dab11844e0f597f02c1fc8720d142e1f53d3e25aeb40db5b1537f5c",GGML_TYPE_BF16,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{1024,5120}),"B04 original plain role")},
    {"blk.63.ffn_down.weight","blk.63.ffn_down.weight.bin","1a2449598c3a9052059133dd77a40293f0796c40069d9361499e2c3bf79d8627",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,17408,5120),"B04 original Q8_0 RHS")},
    {"blk.63.ffn_gate.weight","blk.63.ffn_gate.weight.bin","db95ddc45f91e695196cf57d4efa0fbc86d4ce5d9a287d5a9f242013f03c4cdb",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,5120,17408),"B04 original Q8_0 RHS")},
    {"blk.63.ffn_up.weight","blk.63.ffn_up.weight.bin","1d18e631cdfeb69f55fe9f7041c6d49ac6686b98c69ca73a83d7eb9dff3bd89d",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,5120,17408),"B04 original Q8_0 RHS")},
    {"blk.63.post_attention_norm.weight","blk.63.post_attention_norm.weight.bin","bd1d77170441438d96258413ed00462a96a4290341dbcc78cf66c9990aa06506",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.attn_k.weight","blk.64.attn_k.weight.bin","0ab4e67930451a2f1140e865d2e3e7e23cd752a3bb25042c36e7e546361073d0",GGML_TYPE_BF16,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{1024,5120}),"B04 original plain role")},
    {"blk.64.attn_k_norm.weight","blk.64.attn_k_norm.weight.bin","13e8086a61052d510f01a7984b2ac7c5012337887e80594331ddef3a6a0f05c7",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{256}),"B04 original plain role")},
    {"blk.64.attn_norm.weight","blk.64.attn_norm.weight.bin","afb539011550a9d32f6cfb14db69b9aaed81e63fbd732124e020ae9903e0f275",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.attn_output.weight","blk.64.attn_output.weight.bin","73644f7b5999c191684e7e86493c14c65585e32c16561bf38b4495a2bef6be23",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,6144,5120),"B04 original Q8_0 RHS")},
    {"blk.64.attn_q.weight","blk.64.attn_q.weight.bin","8b27ef96b91e0b0564f82f11d9010efee6aa40a0eaa1900336bf597f767e7c98",GGML_TYPE_BF16,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{12288,5120}),"B04 original plain role")},
    {"blk.64.attn_q_norm.weight","blk.64.attn_q_norm.weight.bin","4a7f959094211b3dade3324736bb75e25c61a9197e025102646e7f74bd094a48",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{256}),"B04 original plain role")},
    {"blk.64.attn_v.weight","blk.64.attn_v.weight.bin","9606be457a48d7d9a78d72f255246f4e346845d752c1e82e41e14728255c5e13",GGML_TYPE_BF16,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{1024,5120}),"B04 original plain role")},
    {"blk.64.ffn_down.weight","blk.64.ffn_down.weight.bin","d1f5d04915e5fca63513a90e8e812d65ddc7a1aaa6ea15866cb8e991f5360e5f",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,17408,5120),"B04 original Q8_0 RHS")},
    {"blk.64.ffn_gate.weight","blk.64.ffn_gate.weight.bin","9f5d2d1b2ff1bd0ef74773d6f711f59dcd170ced75334bf458292954515c59c9",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,5120,17408),"B04 original Q8_0 RHS")},
    {"blk.64.ffn_up.weight","blk.64.ffn_up.weight.bin","5db0e88f2ba85a6616fe023888fe87f931391d8988dfd6337f77ad2896b7b928",GGML_TYPE_Q8_0,roles::original::detail::take(c::gguf_weight_description(c::GgufQuantizedType::kQ8_0,c::DataType::kFloat32,5120,17408),"B04 original Q8_0 RHS")},
    {"blk.64.nextn.eh_proj.weight","blk.64.nextn.eh_proj.weight.bin","4eee377b67ec2122cf214dbe6946d16261873441f1851d64409d9c7566bb20cc",GGML_TYPE_BF16,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kBFloat16,std::array<std::int64_t,2>{5120,10240}),"B04 original plain role")},
    {"blk.64.nextn.enorm.weight","blk.64.nextn.enorm.weight.bin","d96abe72c938e866b5a8bdaa8aa9f8590577f55bef6281c2e9fce892db518d97",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.nextn.hnorm.weight","blk.64.nextn.hnorm.weight.bin","e9247e9fc08ebd0ca8f14a610cfd1046a0115143f6967de9d520647149890ac2",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.nextn.shared_head_norm.weight","blk.64.nextn.shared_head_norm.weight.bin","afdf2c4845dcce4470aeaf40e1726690b606eb642c5a4145a0e3f2598b0734d0",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
    {"blk.64.post_attention_norm.weight","blk.64.post_attention_norm.weight.bin","fcfcdbdb492b9a1c31ca44997a188982a68e0741df67f36080c0562da6b7c6dd",GGML_TYPE_F32,roles::original::detail::take(c::TensorDesc::dense(c::DataType::kFloat32,std::array<std::int64_t,1>{5120}),"B04 original plain role")},
  }};
}
} // namespace qwen_gguf_original_artifacts::b04
