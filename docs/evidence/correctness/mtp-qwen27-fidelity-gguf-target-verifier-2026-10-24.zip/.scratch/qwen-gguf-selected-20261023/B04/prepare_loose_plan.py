"""Derive B04's29 loose roles only from the authenticated866-tensor header.

Offline only. This never calls the header acquisition or any downloader.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
S = Path(__file__).resolve().parent
R = S.parents[2]
COUNT, BODY = 29, 4927328256


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(R).as_posix(), bytes=len(raw), sha256=sha(raw))


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def checked_header():
    fetch = module('b04_original_header_schema', S / 'fetch_headers.py')
    expected, review = fetch.expected()
    receipt = read(S / 'header.json')
    assert receipt['complete'] is True and receipt['http_status'] == 206
    assert (receipt['repository'], receipt['revision'], receipt['file'], receipt['url']) == (
        fetch.REPO, fetch.REV, fetch.FILE, fetch.URL)
    assert receipt['tensor_payload_bytes'] == 0 and receipt['tensor_count'] == 866
    assert receipt['header'] == identity(S / 'original-header.bin')
    assert receipt['physical_table'] == identity(S / 'physical-table.json')
    raw = (S / 'original-header.bin').read_bytes()
    assert len(raw) == receipt['data_base'] <= fetch.LIMIT
    assert receipt['etag'].startswith('"') and receipt['etag'].endswith('"')
    parser = fetch.module('b04_loose_reused_gguf_parser', fetch.PARSER)
    metadata, tensors, count = parser.parse_header(raw, 866, len(raw),
        read(S / 'physical-table.json')['metadata'])
    assert count == receipt['metadata_count'] and len(tensors) == len(expected)
    table = {}
    for row in tensors:
        name, shape, code = row['name'], row['shape'], row['dtype_code']
        dtype, block, stored = fetch.TYPES[code]
        assert name not in table and expected[name] == (shape, dtype)
        assert shape[0] % block == 0 and row['offset'] % metadata.get('general.alignment', 32) == 0
        size = math.prod(shape) // block * stored
        first = len(raw) + row['offset']
        assert len(raw) <= first and first + size <= receipt['whole_file_bytes']
        table[name] = dict(row, dtype=dtype, bytes=size)
    assert set(table) == set(expected)
    # Tensor-table order need not be source offset order. No pair may overlap.
    ordered = sorted(table.values(), key=lambda row: row['offset'])
    assert all(left['offset'] + left['bytes'] <= right['offset']
        for left, right in zip(ordered, ordered[1:]))
    return fetch, receipt, table, review


def plan():
    fetch, receipt, table, review = checked_header()
    roles = []
    selected = sorted(review['role_manifest'], key=lambda row: table[row['name']]['offset'])
    for spec in selected:
        row = table[spec['name']]
        assert (row['shape'], row['dtype'], row['bytes']) == (spec['gguf_shape'], spec['native'], spec['bytes'])
        first = receipt['data_base'] + row['offset']
        section = 'target63' if spec['group'] == 'target63_and_global_norm' else 'nextn'
        roles.append(dict(index=len(roles), name=row['name'], filename=row['name'] + '.bin',
            section=section, dtype=row['dtype'], dtype_code=row['dtype_code'], shape=row['shape'],
            bytes=row['bytes'], source_shard=0,
            data_relative_half_open=[row['offset'], row['offset'] + row['bytes']],
            absolute_inclusive=[first, first + row['bytes'] - 1]))
    assert len(roles) == COUNT and sum(row['bytes'] for row in roles) == BODY
    assert sum(row['section'] == 'nextn' for row in roles) == 17
    assert sum(row['section'] == 'target63' for row in roles) == 12
    shard = dict(file=fetch.FILE, url=fetch.URL, data_base=receipt['data_base'],
        whole_file_bytes=receipt['whole_file_bytes'], etag=receipt['etag'],
        header=identity(S / 'original-header.bin'))
    return dict(repository=fetch.REPO, revision=fetch.REV, file=fetch.FILE,
        original_roles=COUNT, source_bytes=BODY, shards=[shard], roles=roles,
        complete_absolute_ranges=True, metadata_only=True, tensor_payload_bytes=0,
        header_receipt=identity(S / 'header.json'), census=identity(fetch.CENSUS),
        artifact_executed=False, whole_shard_downloaded=False)


def checked_plan():
    path = S / 'loose-plan.json'
    actual = read(path)
    assert actual == plan(), 'Loose role plan differs from the current authenticated original header'
    return path, actual


def main():
    value = plan()  # Missing or unverified header fails before writing a plan.
    path = S / 'loose-plan.json'
    text = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path.exists():
        assert path.read_text(encoding='utf-8-sig') == text
    else:
        path.write_text(text, encoding='utf-8')
    print(json.dumps(dict(plan=identity(path), roles=COUNT, source_bytes=BODY, network_requests=0)))


if __name__ == '__main__':
    main()
